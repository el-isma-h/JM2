# Données personnelles : conservation, sous-traitants, sécurité

Next RH traite des données de salariés pour le compte de ses clients (employeurs et cabinets) : le client est
**responsable de traitement**, Next RH agit en **sous-traitant** (article 28 du RGPD). Le registre des traitements est tenu
dans **Admin, Registre des traitements** (table `processing_registry`, données initiales : `src/server/registry/data.ts`).

## 1. Politique de conservation

Sources : référentiel CNIL « Durées de conservation des données personnelles : gestion des ressources humaines »
(publié le 2 avril 2026, https://cnil.fr/fr/referentiel-durees-conservation-donnees-rh) et textes cités. La CNIL rappelle
que certaines durées sont imposées par la loi et que le référentiel n'est pas exhaustif : chaque client reste responsable
de vérifier les durées applicables à sa situation.

| Catégorie | Base active | Archivage intermédiaire | Texte |
| --- | --- | --- | --- |
| Dossier du personnel (identité, contrat, carrière) | durée de la relation de travail | 5 ans après le départ (prescription) | Référentiel CNIL RH ; art. 2224 du code civil |
| Registre unique du personnel | présence dans les effectifs | 5 ans après le départ | art. R1221-26 du code du travail |
| Données de calcul de la paie (assiette des cotisations) | le temps du calcul, 1 mois au maximum | 6 ans | art. L243-16 du code de la sécurité sociale |
| Bulletins de paie (double employeur) | | 5 ans à compter de la remise | art. L3243-4 du code du travail |
| Bulletins électroniques mis à disposition du salarié | | 50 ans ou jusqu'aux 75 ans du salarié | art. D3243-8 du code du travail |
| Éléments de preuve des salaires versés | | 3 ans | art. L3245-1 du code du travail |
| Déclarations sociales (DSN) et cotisations | jusqu'au certificat de conformité | 6 ans | art. R133-13 et L243-16 du code de la sécurité sociale |
| Taux de prélèvement à la source, données fiscales | | 6 ans | art. L102 B du livre des procédures fiscales |
| Temps de travail, heures | jusqu'au bulletin de la période | 1 an (ou la période de référence) ; forfait : 3 ans | art. D3171-16 et L3245-1 du code du travail |
| Congés et absences | jusqu'au bulletin de la période | 3 ans | art. L3245-1 du code du travail |
| Justificatifs de notes de frais (pièces comptables) | | 10 ans après la clôture de l'exercice | art. L123-22 du code de commerce |
| Candidats non retenus | durée du recrutement | 5 ans (preuve en cas d'action en discrimination) ; CVthèque : 2 ans | art. L1134-5 du code du travail |
| Conversations avec l'assistant IA | 12 mois recommandés | | minimisation (art. 5.1.c RGPD) |
| Journal d'envoi des e-mails | 12 mois recommandés | | |
| Journal d'audit (accès et actions) | 6 mois à 1 an | | recommandation CNIL sur la journalisation |
| Sauvegardes | 30 jours glissants recommandés | | art. 32 RGPD |

État de l'implémentation, à dire tel quel aux clients :

- les documents créés par `createDocument()` portent une date `retention_until` quand le module appelant la fournit ;
- **la purge automatique à échéance n'est pas encore implémentée** pour les données RH, les conversations IA, le journal
  d'envoi et le journal d'audit : elle doit être ajoutée comme tâche de fond (point d'extension : `registerJobHandler`
  dans `src/server/jobs/handlers.ts`). D'ici là, la suppression se fait à la demande du client ;
- les espaces de démonstration sont supprimés automatiquement après 24 heures (tâche `demo:cleanup`).

## 2. Sous-traitants ultérieurs

| Service | Usage | Activation | Localisation | Données transmises |
| --- | --- | --- | --- | --- |
| Hébergeur (à définir) | application, base PostgreSQL, stockage des fichiers | toujours | à définir : Union européenne recommandée | toutes les données |
| Anthropic PBC (API Claude) | assistant IA et aide à la rédaction | uniquement si `ANTHROPIC_API_KEY` est définie | États-Unis | questions et contexte minimisé (voir §3) |
| Resend | e-mails transactionnels | uniquement si `RESEND_API_KEY` est définie | États-Unis par défaut | adresse, nom, contenu de l'e-mail |
| Signature électronique (à définir) | signature des documents | uniquement si `ESIGN_PROVIDER` et `ESIGN_API_KEY` sont définies | selon le prestataire | document et signataires |

Sans ces clés, aucune donnée ne quitte l'hébergement : les e-mails restent dans la boîte d'envoi locale, l'assistant
fonctionne sur ses règles internes. L'état réel est visible dans **Admin, Intégrations**. Les transferts hors Union
européenne doivent être encadrés par les garanties contractuelles du fournisseur (article 46 du RGPD) et figurer dans le
contrat de sous-traitance signé avec chaque client.

## 3. Mesures de sécurité réellement implémentées

Chaque point renvoie au code qui le met en oeuvre.

**Chiffrement des données sensibles.** NIR, IBAN et secrets TOTP sont chiffrés en AES-256-GCM (IV aléatoire de 96 bits,
tag d'authentification), avec une clé dérivée d'`APP_SECRET` par HKDF-SHA256 et par usage (`src/lib/crypto.ts`). Seuls les
4 derniers caractères de l'IBAN sont stockés en clair pour l'affichage masqué.

**Authentification.** Mots de passe hachés avec bcrypt (coût 12), 12 caractères minimum avec majuscule, minuscule et chiffre ;
réponse identique que le compte existe ou non (`src/server/auth.ts`, `src/server/actions/auth.ts`). Double authentification
TOTP facultative avec codes de secours hachés.

**Sessions.** Cookie `nextrh_session` `httpOnly`, `SameSite=Lax`, `Secure` en production, durée 14 jours ; seul le haché
sha256 du jeton est stocké en base ; sessions fermées à la réinitialisation du mot de passe, à la désactivation du compte et
au changement de droits d'administration.

**Accès renforcé.** Les permissions sensibles (coordonnées bancaires, envoi des déclarations, clôture de paie) exigent une
vérification récente (TOTP ou mot de passe) valable 15 minutes (`src/server/authz.ts`, `SENSITIVE`).

**Isolation par entreprise.** Chaque accès passe par `getCompanyContext()` / `requireCompany()` : l'utilisateur doit être
affecté à l'entreprise, ou membre du cabinet propriétaire (lecture seule), ou administrateur plateforme. Les requêtes
filtrent par `company_id`. Les salariés n'accèdent qu'à leur espace personnel.

**Liens temporaires.** Téléchargements par jeton à usage limité de 15 minutes lié à l'utilisateur ; jetons de vérification,
de réinitialisation (30 minutes) et d'invitation (7 jours) stockés hachés, à usage unique (`src/server/documents/store.ts`,
`issueToken`). Aucun fichier n'est servi depuis `/public` ; le stockage est privé (`src/server/storage.ts`).

**Journal d'audit.** Les lectures et écritures sensibles sont journalisées avec l'utilisateur, l'entreprise, l'objet, l'état
avant et après, l'adresse IP et le navigateur (`src/server/audit.ts`). Consultation filtrée et export CSV réservés aux
administrateurs plateforme ; l'export lui-même est journalisé.

**En-têtes de sécurité.** `Content-Security-Policy`, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`,
`Referrer-Policy`, `Permissions-Policy`, HSTS en production (`src/proxy.ts`).

**Démonstration.** Les espaces de démonstration sont isolés (`is_demo`), avec des identifiants fictifs (SIREN préfixé 000,
IBAN de la banque 99999) ; aucun e-mail, aucune déclaration, aucun paiement ne part (`sendMail({ isDemo })`,
`assertNotDemo()` dans `src/server/demo/guard.ts`).

**Assistant IA.** Aucune donnée RH n'est utilisée pour entraîner un modèle : Next RH n'entraîne aucun modèle, et par défaut Anthropic
n'utilise pas les entrées et sorties de son API commerciale pour l'entraînement (sauf envoi volontaire de retours ou accord
explicite du client : https://privacy.claude.com/en/articles/7996868). Next RH n'envoie aucun retour de ce type. Avant chaque envoi, les NIR, IBAN,
adresses e-mail et numéros de téléphone sont remplacés par des jetons opaques, restaurés localement après la réponse ; les
montants sont masqués si l'utilisateur n'est pas habilité à voir les salaires (`maskSensitive()` dans
`src/server/documents/ai-guard.ts`). Le contenu fourni par les utilisateurs est balisé comme donnée, jamais comme instruction.
L'assistant agit sous les permissions de l'utilisateur et le calcul de paie n'est jamais confié au modèle.

**Sauvegardes.** Sauvegarde par organisation avec empreinte sha256 vérifiée avant restauration ; restauration uniquement vers
une nouvelle organisation ; aucun mot de passe ni secret dans les sauvegardes (`src/server/backup/index.ts`,
`docs/sauvegarde.md`).

## 4. Droits des personnes

Les demandes d'accès, de rectification ou d'effacement des salariés sont adressées à leur employeur (responsable de
traitement). L'espace salarié permet de consulter ses informations et de demander une correction (demande RH « correction
d'informations »). L'effacement d'un salarié reste soumis aux durées légales du §1.
