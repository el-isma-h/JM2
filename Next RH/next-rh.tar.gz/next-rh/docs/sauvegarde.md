# Sauvegarde et restauration

Next RH propose deux niveaux de sauvegarde, complémentaires.

| Niveau | Contenu | Outil | Restauration |
| --- | --- | --- | --- |
| Organisation (tenant) | Toutes les lignes liées au tenant et ses fichiers de stockage | Admin, Sauvegardes (ou tâche `backup:tenant`) | Vers une **nouvelle** organisation, identifiants remappés |
| Base complète | Toute la base PostgreSQL + le dossier de stockage | `pg_dump` + archive de `STORAGE_DIR` | Sur une base vide (reprise après sinistre) |

## 1. Sauvegarde d'une organisation

Depuis **Admin, Sauvegardes** (ou **Admin, Organisations, fiche, Sauvegarder maintenant**), ou en planifiant la tâche
`backup:tenant` (payload `{ "tenantId": "<uuid>" }`).

Ce qui est fait (`src/server/backup/index.ts`) :

1. lecture cohérente (transaction `REPEATABLE READ READ ONLY`) de toutes les tables liées par `tenant_id`, `company_id`,
   `employee_id`, `contract_id`, `period_id`, `report_id`, `document_id`, `conversation_id` (liste : `BACKUP_TABLES`) ;
2. ajout des fichiers de stockage référencés (`documents.storage_key`, `employees.photo_key`, `payroll_filings.file_key`), en base64 ;
3. identités des utilisateurs référencés (identifiant, e-mail, nom) **sans** mot de passe, secret TOTP, session ni jeton ;
4. compression gzip, écriture dans le stockage privé sous `backups/<tenantId>/<date>.json.gz` ;
5. ligne `backups` avec la taille et l'empreinte **sha256** du fichier compressé.

Les champs chiffrés (NIR, IBAN) restent chiffrés dans la sauvegarde : ils ne sont lisibles qu'avec le même `APP_SECRET`.

## 2. Restauration d'une organisation

**Admin, Sauvegardes, Restaurer** (confirmation par saisie de `RESTAURER`).

- l'empreinte sha256 du fichier est recalculée et comparée : une sauvegarde altérée est refusée ;
- une **nouvelle** organisation est créée : chaque identifiant de ligne reçoit un nouvel UUID, et toutes les références
  (colonnes et contenus JSON) sont réécrites. L'organisation d'origine n'est jamais modifiée ;
- les comptes utilisateurs ne sont pas recréés : les affectations sont conservées pour les comptes qui existent encore ;
- les invitations en attente sont révoquées dans la copie (nouveau jeton), pour qu'un ancien lien ne donne pas accès à la copie ;
- les fichiers sont réécrits sous de nouvelles clés de stockage.

Vérification de bout en bout (sauvegarde puis restauration d'une démonstration, comparaison des comptes de lignes table par
table, recherche des identifiants d'origine, fichier de stockage, refus d'une empreinte altérée) :

```bash
npx tsx --conditions=react-server src/scripts/backup-roundtrip.ts
```

## 3. Sauvegarde complète de la base (pg_dump)

À planifier chaque nuit sur le serveur, en plus des sauvegardes par organisation.

```bash
# Variables
export PGURL="postgresql://nextrh:<mot-de-passe>@<hôte>:5432/nextrh"
export STAMP=$(date -u +%Y%m%dT%H%M%SZ)
export DEST=/var/backups/nextrh

# Base : format custom (compressé, restauration sélective possible)
pg_dump --format=custom --no-owner --no-privileges --file "$DEST/nextrh-$STAMP.dump" "$PGURL"

# Fichiers privés (documents, sauvegardes d'organisation)
tar -czf "$DEST/storage-$STAMP.tar.gz" -C /chemin/vers/next-rh storage

# Empreintes
sha256sum "$DEST/nextrh-$STAMP.dump" "$DEST/storage-$STAMP.tar.gz" > "$DEST/SHA256SUMS-$STAMP"
```

Avec Docker Compose :

```bash
docker compose exec -T db pg_dump -U nextrh --format=custom nextrh > "nextrh-$(date -u +%Y%m%dT%H%M%SZ).dump"
docker compose run --rm -v "$PWD:/out" app tar -czf /out/storage.tar.gz -C /app storage
```

Bonnes pratiques :

- copier les fichiers hors du serveur (stockage objet chiffré, autre région) ;
- conserver 30 jours glissants (voir `docs/donnees-personnelles.md`) ;
- **sauvegarder `APP_SECRET` séparément** (coffre de secrets) : sans lui, NIR, IBAN et secrets TOTP sont illisibles ;
- tester une restauration chaque trimestre.

## 4. Restauration complète (reprise après sinistre)

```bash
# Base vide
createdb -U postgres -O nextrh nextrh
pg_restore --no-owner --role=nextrh --dbname "$PGURL" nextrh-<date>.dump
sha256sum -c SHA256SUMS-<date>

# Fichiers
tar -xzf storage-<date>.tar.gz -C /chemin/vers/next-rh

# Même APP_SECRET que la base sauvegardée, puis :
npm run setup   # migrations éventuelles, idempotent
```

## 5. Tâches automatiques liées

| Tâche | Fréquence | Effet |
| --- | --- | --- |
| `demo:cleanup` | toutes les heures | supprime les organisations de démonstration de plus de 24 h (lignes, fichiers, comptes de démo) |
| `backup:tenant` | à la demande | sauvegarde d'une organisation |
| `deadlines:remind` | chaque jour | récapitulatif des échéances à 14 jours aux gestionnaires |

Le runner (`src/server/jobs/runner.ts`) est déclenché par `POST /api/cron` avec l'en-tête `x-cron-secret: $CRON_SECRET`,
par exemple chaque minute :

```cron
* * * * * curl -fsS -X POST -H "x-cron-secret: $CRON_SECRET" https://<hôte>/api/cron > /dev/null
```
