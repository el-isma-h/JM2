CREATE TYPE "public"."company_role" AS ENUM('owner', 'admin', 'hr', 'payroll', 'manager', 'accountant', 'employee', 'viewer');--> statement-breakpoint
CREATE TYPE "public"."contact_role" AS ENUM('dirigeant', 'rh', 'paie', 'comptable', 'informatique', 'autre');--> statement-breakpoint
CREATE TYPE "public"."legal_form" AS ENUM('SAS', 'SASU', 'SARL', 'EURL', 'SA', 'SCI', 'SNC', 'EI', 'ASSOCIATION', 'AUTRE');--> statement-breakpoint
CREATE TYPE "public"."organism_kind" AS ENUM('urssaf', 'retraite', 'mutuelle', 'prevoyance', 'medecine_travail', 'formation', 'autre');--> statement-breakpoint
CREATE TYPE "public"."tenant_kind" AS ENUM('company', 'firm', 'group');--> statement-breakpoint
CREATE TYPE "public"."invitation_status" AS ENUM('pending', 'accepted', 'revoked', 'expired');--> statement-breakpoint
CREATE TYPE "public"."job_status" AS ENUM('queued', 'running', 'done', 'failed');--> statement-breakpoint
CREATE TYPE "public"."mail_status" AS ENUM('queued', 'sent', 'failed', 'skipped_not_configured');--> statement-breakpoint
CREATE TYPE "public"."platform_role" AS ENUM('user', 'platform_admin');--> statement-breakpoint
CREATE TYPE "public"."token_purpose" AS ENUM('verify_email', 'reset_password', 'invite', 'download');--> statement-breakpoint
CREATE TYPE "public"."contract_type" AS ENUM('CDI', 'CDD', 'APPRENTISSAGE', 'PROFESSIONNALISATION', 'STAGE', 'INTERIM', 'MANDAT');--> statement-breakpoint
CREATE TYPE "public"."employee_category" AS ENUM('non_cadre', 'cadre', 'cadre_dirigeant', 'apprenti', 'stagiaire');--> statement-breakpoint
CREATE TYPE "public"."employee_status" AS ENUM('draft', 'active', 'suspended', 'left');--> statement-breakpoint
CREATE TYPE "public"."gender" AS ENUM('F', 'M', 'X');--> statement-breakpoint
CREATE TYPE "public"."salary_basis" AS ENUM('monthly', 'hourly', 'annual');--> statement-breakpoint
CREATE TYPE "public"."work_time_mode" AS ENUM('heures', 'forfait_jours', 'forfait_heures');--> statement-breakpoint
CREATE TYPE "public"."anomaly_severity" AS ENUM('blocking', 'warning', 'info');--> statement-breakpoint
CREATE TYPE "public"."anomaly_status" AS ENUM('open', 'acknowledged', 'resolved', 'ignored');--> statement-breakpoint
CREATE TYPE "public"."filing_kind" AS ENUM('dsn_mensuelle', 'dsn_evenement', 'export_comptable', 'virement_sepa', 'etat_charges', 'journal_paie', 'recap_etablissement', 'documents_sortie');--> statement-breakpoint
CREATE TYPE "public"."filing_status" AS ENUM('prepared', 'controlled', 'send_requested', 'sent', 'accepted', 'rejected');--> statement-breakpoint
CREATE TYPE "public"."payroll_period_status" AS ENUM('open', 'collecting', 'checking', 'computed', 'controlled', 'validated', 'finalized', 'exported', 'distributed', 'closed');--> statement-breakpoint
CREATE TYPE "public"."payslip_status" AS ENUM('computed', 'blocked', 'controlled', 'validated', 'finalized', 'distributed');--> statement-breakpoint
CREATE TYPE "public"."variable_kind" AS ENUM('prime', 'commission', 'heures_sup', 'heures_comp', 'absence', 'avantage_nature', 'titres_restaurant', 'indemnite', 'acompte', 'saisie', 'regularisation', 'autre');--> statement-breakpoint
CREATE TYPE "public"."variable_status" AS ENUM('draft', 'submitted', 'validated', 'rejected');--> statement-breakpoint
CREATE TYPE "public"."hr_request_kind" AS ENUM('correction_informations', 'attestation', 'justificatif', 'acompte', 'question', 'autre');--> statement-breakpoint
CREATE TYPE "public"."interview_kind" AS ENUM('annuel', 'professionnel', 'fin_periode_essai', 'retour_absence', 'recadrage', 'autre');--> statement-breakpoint
CREATE TYPE "public"."request_status" AS ENUM('draft', 'pending', 'approved', 'rejected', 'cancelled');--> statement-breakpoint
CREATE TYPE "public"."workflow_kind" AS ENUM('onboarding', 'offboarding', 'mobility', 'return');--> statement-breakpoint
CREATE TYPE "public"."document_category" AS ENUM('bulletin', 'contrat', 'avenant', 'attestation', 'courrier', 'justificatif', 'identite', 'kbis', 'entreprise', 'fiche_poste', 'offre_emploi', 'convocation', 'compte_rendu', 'note_interne', 'procedure', 'export', 'autre');--> statement-breakpoint
CREATE TYPE "public"."document_visibility" AS ENUM('company', 'employee', 'restricted');--> statement-breakpoint
CREATE TYPE "public"."draft_status" AS ENUM('questions', 'drafted', 'in_review', 'validated', 'exported', 'signed', 'archived');--> statement-breakpoint
CREATE TYPE "public"."signature_status" AS ENUM('not_configured', 'requested', 'sent', 'signed', 'declined', 'expired');--> statement-breakpoint
CREATE TYPE "public"."assistant_role" AS ENUM('user', 'assistant', 'tool');--> statement-breakpoint
CREATE TYPE "public"."import_status" AS ENUM('uploaded', 'mapped', 'validated', 'applied', 'failed');--> statement-breakpoint
CREATE TYPE "public"."pricing_unit" AS ENUM('par_salarie_mois', 'par_declarant_mois', 'par_document', 'par_facture', 'forfait_mois', 'sur_devis', 'inclus');--> statement-breakpoint
CREATE TABLE "companies" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"legal_name" text NOT NULL,
	"trade_name" text,
	"siren" text,
	"legal_form" "legal_form",
	"ape_code" text,
	"activity" text,
	"idcc" text,
	"collective_agreement" text,
	"idcc_confirmed" boolean DEFAULT false NOT NULL,
	"headcount" integer,
	"address_line1" text,
	"address_line2" text,
	"postal_code" text,
	"city" text,
	"country" text DEFAULT 'FR' NOT NULL,
	"payroll_settings" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"onboarding_step" text DEFAULT 'company' NOT NULL,
	"onboarding_completed_at" timestamp with time zone,
	"is_demo" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "company_contacts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"full_name" text NOT NULL,
	"role" "contact_role" DEFAULT 'autre' NOT NULL,
	"email" text,
	"phone" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "company_memberships" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"role" "company_role" DEFAULT 'viewer' NOT NULL,
	"permissions" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "company_organisms" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"kind" "organism_kind" NOT NULL,
	"name" text NOT NULL,
	"reference" text,
	"contract_number" text,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "establishments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"name" text NOT NULL,
	"siret" text,
	"nic" text,
	"is_head_office" boolean DEFAULT false NOT NULL,
	"address_line1" text,
	"postal_code" text,
	"city" text,
	"urssaf_code" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tenants" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"kind" "tenant_kind" DEFAULT 'company' NOT NULL,
	"slug" text NOT NULL,
	"is_demo" boolean DEFAULT false NOT NULL,
	"settings" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "tenants_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid,
	"company_id" uuid,
	"user_id" uuid,
	"action" text NOT NULL,
	"entity_type" text,
	"entity_id" uuid,
	"before" jsonb,
	"after" jsonb,
	"ip" "inet",
	"user_agent" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "invitations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"company_id" uuid,
	"email" text NOT NULL,
	"role" text DEFAULT 'viewer' NOT NULL,
	"employee_id" uuid,
	"invited_by" uuid,
	"status" "invitation_status" DEFAULT 'pending' NOT NULL,
	"token_hash" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"accepted_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "invitations_token_hash_unique" UNIQUE("token_hash")
);
--> statement-breakpoint
CREATE TABLE "jobs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"kind" text NOT NULL,
	"payload" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"status" "job_status" DEFAULT 'queued' NOT NULL,
	"attempts" text DEFAULT '0' NOT NULL,
	"result" jsonb,
	"error" text,
	"tenant_id" uuid,
	"company_id" uuid,
	"run_after" timestamp with time zone DEFAULT now() NOT NULL,
	"started_at" timestamp with time zone,
	"finished_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "mail_outbox" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"to" text NOT NULL,
	"subject" text NOT NULL,
	"html" text NOT NULL,
	"text" text,
	"status" "mail_status" DEFAULT 'queued' NOT NULL,
	"provider_id" text,
	"error" text,
	"is_demo" boolean DEFAULT false NOT NULL,
	"sent_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "one_time_tokens" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"purpose" "token_purpose" NOT NULL,
	"token_hash" text NOT NULL,
	"user_id" uuid,
	"email" text,
	"payload" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"used_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "one_time_tokens_token_hash_unique" UNIQUE("token_hash")
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"token_hash" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"elevated_until" timestamp with time zone,
	"ip" "inet",
	"user_agent" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "sessions_token_hash_unique" UNIQUE("token_hash")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" text NOT NULL,
	"password_hash" text NOT NULL,
	"first_name" text NOT NULL,
	"last_name" text NOT NULL,
	"platform_role" "platform_role" DEFAULT 'user' NOT NULL,
	"tenant_id" uuid,
	"email_verified_at" timestamp with time zone,
	"totp_secret_enc" text,
	"totp_enabled_at" timestamp with time zone,
	"recovery_codes_hash" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"locale" text DEFAULT 'fr' NOT NULL,
	"last_login_at" timestamp with time zone,
	"disabled_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "contract_amendments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"contract_id" uuid NOT NULL,
	"effective_date" date NOT NULL,
	"subject" text NOT NULL,
	"changes" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"document_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "compensations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"contract_id" uuid,
	"effective_date" date NOT NULL,
	"end_date" date,
	"basis" "salary_basis" DEFAULT 'monthly' NOT NULL,
	"gross_amount_cents" integer NOT NULL,
	"currency" text DEFAULT 'EUR' NOT NULL,
	"reason" text,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "contracts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"type" "contract_type" DEFAULT 'CDI' NOT NULL,
	"category" "employee_category" DEFAULT 'non_cadre' NOT NULL,
	"start_date" date NOT NULL,
	"end_date" date,
	"trial_end_date" date,
	"trial_renewed_until" date,
	"job_title" text,
	"classification" text,
	"coefficient" text,
	"work_time_mode" "work_time_mode" DEFAULT 'heures' NOT NULL,
	"weekly_hours" numeric(6, 2) DEFAULT '35.00' NOT NULL,
	"monthly_hours" numeric(7, 2) DEFAULT '151.67' NOT NULL,
	"annual_days" integer,
	"is_part_time" boolean DEFAULT false NOT NULL,
	"is_executive" boolean DEFAULT false NOT NULL,
	"cdd_reason" text,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "employee_bank_accounts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"holder_name" text NOT NULL,
	"iban_enc" text NOT NULL,
	"iban_last4" text NOT NULL,
	"bic" text,
	"bank_name" text,
	"is_primary" boolean DEFAULT true NOT NULL,
	"valid_from" date,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "employee_carryovers" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"year" integer NOT NULL,
	"through_month" integer NOT NULL,
	"gross_ytd_cents" integer DEFAULT 0 NOT NULL,
	"net_taxable_ytd_cents" integer DEFAULT 0 NOT NULL,
	"net_paid_ytd_cents" integer DEFAULT 0 NOT NULL,
	"pas_ytd_cents" integer DEFAULT 0 NOT NULL,
	"employee_contrib_ytd_cents" integer DEFAULT 0 NOT NULL,
	"employer_contrib_ytd_cents" integer DEFAULT 0 NOT NULL,
	"hours_ytd" numeric(9, 2) DEFAULT '0' NOT NULL,
	"paid_leave_acquired" numeric(6, 2) DEFAULT '0' NOT NULL,
	"paid_leave_taken" numeric(6, 2) DEFAULT '0' NOT NULL,
	"paid_leave_prev_balance" numeric(6, 2) DEFAULT '0' NOT NULL,
	"source" text,
	"confirmed_at" timestamp with time zone,
	"confirmed_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "employee_events" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"kind" text NOT NULL,
	"effective_date" date NOT NULL,
	"title" text NOT NULL,
	"details" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"affects_payroll" boolean DEFAULT false NOT NULL,
	"payroll_processed_period_id" uuid,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "employees" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"establishment_id" uuid,
	"user_id" uuid,
	"manager_id" uuid,
	"employee_number" text,
	"status" "employee_status" DEFAULT 'draft' NOT NULL,
	"civility" text,
	"first_name" text NOT NULL,
	"last_name" text NOT NULL,
	"birth_name" text,
	"gender" "gender",
	"birth_date" date,
	"birth_place" text,
	"birth_country" text,
	"nationality" text,
	"nir_enc" text,
	"email" text,
	"personal_email" text,
	"phone" text,
	"address_line1" text,
	"address_line2" text,
	"postal_code" text,
	"city" text,
	"country" text DEFAULT 'FR' NOT NULL,
	"job_title" text,
	"department" text,
	"hire_date" date,
	"leave_date" date,
	"leave_reason" text,
	"custom_fields" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"photo_key" text,
	"is_demo" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "pas_rates" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"rate" numeric(5, 2) NOT NULL,
	"kind" text DEFAULT 'personnalise' NOT NULL,
	"effective_date" date NOT NULL,
	"source" text,
	"is_neutral" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payroll_anomalies" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"period_id" uuid NOT NULL,
	"employee_id" uuid,
	"code" text NOT NULL,
	"severity" "anomaly_severity" NOT NULL,
	"status" "anomaly_status" DEFAULT 'open' NOT NULL,
	"title" text NOT NULL,
	"explanation" text NOT NULL,
	"details" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"resolved_by" uuid,
	"resolved_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payroll_filings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"period_id" uuid NOT NULL,
	"kind" "filing_kind" NOT NULL,
	"status" "filing_status" DEFAULT 'prepared' NOT NULL,
	"content" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"file_key" text,
	"controls" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"send_requested_by" uuid,
	"send_requested_at" timestamp with time zone,
	"sent_at" timestamp with time zone,
	"acknowledgement" jsonb,
	"rejection_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payroll_periods" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"year" integer NOT NULL,
	"month" integer NOT NULL,
	"status" "payroll_period_status" DEFAULT 'open' NOT NULL,
	"payment_date" date,
	"rule_set_version" text,
	"computed_at" timestamp with time zone,
	"validated_at" timestamp with time zone,
	"validated_by" uuid,
	"closed_at" timestamp with time zone,
	"closed_by" uuid,
	"summary" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payroll_rule_sets" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"version" text NOT NULL,
	"effective_from" date NOT NULL,
	"effective_to" date,
	"rules" jsonb NOT NULL,
	"sources" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"checksum" text NOT NULL,
	"published_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "payroll_rule_sets_version_unique" UNIQUE("version")
);
--> statement-breakpoint
CREATE TABLE "payroll_variables" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"period_id" uuid NOT NULL,
	"employee_id" uuid NOT NULL,
	"kind" "variable_kind" NOT NULL,
	"label" text NOT NULL,
	"quantity" numeric(9, 2),
	"rate" numeric(9, 4),
	"amount_cents" integer,
	"status" "variable_status" DEFAULT 'draft' NOT NULL,
	"source" text DEFAULT 'manual' NOT NULL,
	"source_id" uuid,
	"note" text,
	"created_by" uuid,
	"validated_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payslips" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"period_id" uuid NOT NULL,
	"employee_id" uuid NOT NULL,
	"contract_id" uuid,
	"status" "payslip_status" DEFAULT 'computed' NOT NULL,
	"rule_set_version" text NOT NULL,
	"inputs" jsonb NOT NULL,
	"lines" jsonb NOT NULL,
	"gross_cents" integer NOT NULL,
	"employee_contrib_cents" integer NOT NULL,
	"employer_contrib_cents" integer NOT NULL,
	"net_taxable_cents" integer NOT NULL,
	"net_before_tax_cents" integer NOT NULL,
	"pas_rate" numeric(5, 2) DEFAULT '0' NOT NULL,
	"pas_amount_cents" integer DEFAULT 0 NOT NULL,
	"net_paid_cents" integer NOT NULL,
	"employer_cost_cents" integer NOT NULL,
	"hours_worked" numeric(8, 2) DEFAULT '0' NOT NULL,
	"cumulative" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"variance" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"anomalies" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"blocking_reason" text,
	"document_id" uuid,
	"compute_hash" text NOT NULL,
	"distributed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "deadlines" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"employee_id" uuid,
	"kind" text NOT NULL,
	"title" text NOT NULL,
	"due_date" date NOT NULL,
	"status" text DEFAULT 'upcoming' NOT NULL,
	"source_type" text,
	"source_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "expense_lines" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"report_id" uuid NOT NULL,
	"date" date NOT NULL,
	"category" text NOT NULL,
	"label" text NOT NULL,
	"amount_cents" integer NOT NULL,
	"vat_cents" integer DEFAULT 0 NOT NULL,
	"receipt_document_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "expense_reports" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"title" text NOT NULL,
	"status" "request_status" DEFAULT 'draft' NOT NULL,
	"total_cents" integer DEFAULT 0 NOT NULL,
	"currency" text DEFAULT 'EUR' NOT NULL,
	"approved_by" uuid,
	"decided_at" timestamp with time zone,
	"reimbursed_in_period_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "hr_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"employee_id" uuid,
	"kind" "hr_request_kind" NOT NULL,
	"title" text NOT NULL,
	"body" text,
	"payload" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"status" "request_status" DEFAULT 'pending' NOT NULL,
	"assigned_to" uuid,
	"answer" text,
	"decided_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "interviews" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"kind" "interview_kind" NOT NULL,
	"scheduled_at" timestamp with time zone,
	"conducted_by" uuid,
	"status" text DEFAULT 'planned' NOT NULL,
	"objectives" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"notes" text,
	"report_document_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "leave_balances" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"leave_type_id" uuid NOT NULL,
	"period_start" date NOT NULL,
	"period_end" date NOT NULL,
	"acquired" numeric(7, 2) DEFAULT '0' NOT NULL,
	"taken" numeric(7, 2) DEFAULT '0' NOT NULL,
	"pending" numeric(7, 2) DEFAULT '0' NOT NULL,
	"adjustment" numeric(7, 2) DEFAULT '0' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "leave_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"leave_type_id" uuid NOT NULL,
	"start_date" date NOT NULL,
	"end_date" date NOT NULL,
	"start_half_day" boolean DEFAULT false NOT NULL,
	"end_half_day" boolean DEFAULT false NOT NULL,
	"duration" numeric(6, 2) NOT NULL,
	"status" "request_status" DEFAULT 'pending' NOT NULL,
	"reason" text,
	"proof_document_id" uuid,
	"approved_by" uuid,
	"decided_at" timestamp with time zone,
	"decision_note" text,
	"payroll_variable_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "leave_types" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"code" text NOT NULL,
	"label" text NOT NULL,
	"is_paid" boolean DEFAULT true NOT NULL,
	"affects_payroll" boolean DEFAULT true NOT NULL,
	"requires_proof" boolean DEFAULT false NOT NULL,
	"unit" text DEFAULT 'jours_ouvres' NOT NULL,
	"monthly_accrual" numeric(6, 2),
	"color" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "lifecycle_workflows" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"kind" "workflow_kind" NOT NULL,
	"target_date" date NOT NULL,
	"status" text DEFAULT 'in_progress' NOT NULL,
	"tasks" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "remote_work_policies" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"max_days_per_week" integer DEFAULT 2 NOT NULL,
	"requires_approval" boolean DEFAULT true NOT NULL,
	"allowance_cents_per_day" integer DEFAULT 0 NOT NULL,
	"rules" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "remote_work_policies_company_id_unique" UNIQUE("company_id")
);
--> statement-breakpoint
CREATE TABLE "remote_work_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"date" date NOT NULL,
	"status" "request_status" DEFAULT 'pending' NOT NULL,
	"approved_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "timesheets" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"year" integer NOT NULL,
	"month" integer NOT NULL,
	"status" "request_status" DEFAULT 'draft' NOT NULL,
	"entries" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"total_hours" numeric(7, 2) DEFAULT '0' NOT NULL,
	"overtime_hours" numeric(7, 2) DEFAULT '0' NOT NULL,
	"approved_by" uuid,
	"decided_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "trainings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" uuid NOT NULL,
	"title" text NOT NULL,
	"provider" text,
	"kind" text DEFAULT 'formation' NOT NULL,
	"start_date" date,
	"end_date" date,
	"expires_at" date,
	"cost_cents" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'requested' NOT NULL,
	"certificate_document_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "document_drafts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"employee_id" uuid,
	"template_id" uuid,
	"category" "document_category" NOT NULL,
	"title" text NOT NULL,
	"status" "draft_status" DEFAULT 'questions' NOT NULL,
	"answers" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"missing" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"body" text DEFAULT '' NOT NULL,
	"versions" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"reviewers" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"validated_by" uuid,
	"validated_at" timestamp with time zone,
	"pdf_document_id" uuid,
	"docx_document_id" uuid,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "document_templates" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid,
	"code" text NOT NULL,
	"category" "document_category" NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"body" text NOT NULL,
	"questions" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"legal_review_points" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"is_legal" boolean DEFAULT false NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"verified_at" timestamp with time zone,
	"verified_note" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "documents" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"employee_id" uuid,
	"category" "document_category" DEFAULT 'autre' NOT NULL,
	"visibility" "document_visibility" DEFAULT 'company' NOT NULL,
	"title" text NOT NULL,
	"file_name" text NOT NULL,
	"mime_type" text NOT NULL,
	"size_bytes" integer DEFAULT 0 NOT NULL,
	"storage_key" text NOT NULL,
	"sha256" text,
	"version" integer DEFAULT 1 NOT NULL,
	"previous_version_id" uuid,
	"source_type" text,
	"source_id" uuid,
	"retention_until" timestamp with time zone,
	"uploaded_by" uuid,
	"is_demo" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "signature_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"document_id" uuid NOT NULL,
	"provider" text,
	"provider_ref" text,
	"status" "signature_status" DEFAULT 'not_configured' NOT NULL,
	"signers" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"proof" jsonb,
	"requested_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "assistant_conversations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"company_id" uuid,
	"title" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "assistant_messages" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"conversation_id" uuid NOT NULL,
	"role" "assistant_role" NOT NULL,
	"content" text NOT NULL,
	"meta" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "backups" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid,
	"scope" text DEFAULT 'tenant' NOT NULL,
	"storage_key" text NOT NULL,
	"size_bytes" integer DEFAULT 0 NOT NULL,
	"sha256" text,
	"status" text DEFAULT 'done' NOT NULL,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "data_imports" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"kind" text NOT NULL,
	"file_name" text NOT NULL,
	"status" "import_status" DEFAULT 'uploaded' NOT NULL,
	"preview" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"mapping" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"rows" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"errors" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"duplicates" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"applied_count" integer DEFAULT 0 NOT NULL,
	"created_by" uuid,
	"applied_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "pricing_plans" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"is_service" boolean DEFAULT false NOT NULL,
	"unit" "pricing_unit" NOT NULL,
	"price_cents" integer,
	"reference_price_cents" integer,
	"reference_label" text,
	"reference_url" text,
	"reference_checked_at" date,
	"discount_rate_bp" integer DEFAULT 1000 NOT NULL,
	"calculation_note" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "pricing_plans_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "processing_registry" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"purpose" text NOT NULL,
	"data_categories" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"processor" text,
	"location" text,
	"retention" text NOT NULL,
	"legal_basis" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "subscriptions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"company_id" uuid NOT NULL,
	"plan_code" text NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"billing_cycle" text DEFAULT 'monthly' NOT NULL,
	"started_at" date DEFAULT now() NOT NULL,
	"ended_at" date,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "companies" ADD CONSTRAINT "companies_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_contacts" ADD CONSTRAINT "company_contacts_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_memberships" ADD CONSTRAINT "company_memberships_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "company_organisms" ADD CONSTRAINT "company_organisms_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "establishments" ADD CONSTRAINT "establishments_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invitations" ADD CONSTRAINT "invitations_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invitations" ADD CONSTRAINT "invitations_invited_by_users_id_fk" FOREIGN KEY ("invited_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "one_time_tokens" ADD CONSTRAINT "one_time_tokens_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "users" ADD CONSTRAINT "users_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contract_amendments" ADD CONSTRAINT "contract_amendments_contract_id_contracts_id_fk" FOREIGN KEY ("contract_id") REFERENCES "public"."contracts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "compensations" ADD CONSTRAINT "compensations_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "compensations" ADD CONSTRAINT "compensations_contract_id_contracts_id_fk" FOREIGN KEY ("contract_id") REFERENCES "public"."contracts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contracts" ADD CONSTRAINT "contracts_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "employee_bank_accounts" ADD CONSTRAINT "employee_bank_accounts_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "employee_carryovers" ADD CONSTRAINT "employee_carryovers_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "employee_events" ADD CONSTRAINT "employee_events_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "employees" ADD CONSTRAINT "employees_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "employees" ADD CONSTRAINT "employees_establishment_id_establishments_id_fk" FOREIGN KEY ("establishment_id") REFERENCES "public"."establishments"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "employees" ADD CONSTRAINT "employees_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pas_rates" ADD CONSTRAINT "pas_rates_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payroll_anomalies" ADD CONSTRAINT "payroll_anomalies_period_id_payroll_periods_id_fk" FOREIGN KEY ("period_id") REFERENCES "public"."payroll_periods"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payroll_anomalies" ADD CONSTRAINT "payroll_anomalies_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payroll_filings" ADD CONSTRAINT "payroll_filings_period_id_payroll_periods_id_fk" FOREIGN KEY ("period_id") REFERENCES "public"."payroll_periods"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payroll_periods" ADD CONSTRAINT "payroll_periods_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payroll_variables" ADD CONSTRAINT "payroll_variables_period_id_payroll_periods_id_fk" FOREIGN KEY ("period_id") REFERENCES "public"."payroll_periods"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payroll_variables" ADD CONSTRAINT "payroll_variables_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payslips" ADD CONSTRAINT "payslips_period_id_payroll_periods_id_fk" FOREIGN KEY ("period_id") REFERENCES "public"."payroll_periods"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payslips" ADD CONSTRAINT "payslips_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "deadlines" ADD CONSTRAINT "deadlines_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "deadlines" ADD CONSTRAINT "deadlines_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "expense_lines" ADD CONSTRAINT "expense_lines_report_id_expense_reports_id_fk" FOREIGN KEY ("report_id") REFERENCES "public"."expense_reports"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "expense_reports" ADD CONSTRAINT "expense_reports_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "hr_requests" ADD CONSTRAINT "hr_requests_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "hr_requests" ADD CONSTRAINT "hr_requests_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "interviews" ADD CONSTRAINT "interviews_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leave_balances" ADD CONSTRAINT "leave_balances_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leave_balances" ADD CONSTRAINT "leave_balances_leave_type_id_leave_types_id_fk" FOREIGN KEY ("leave_type_id") REFERENCES "public"."leave_types"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leave_requests" ADD CONSTRAINT "leave_requests_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leave_requests" ADD CONSTRAINT "leave_requests_leave_type_id_leave_types_id_fk" FOREIGN KEY ("leave_type_id") REFERENCES "public"."leave_types"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leave_types" ADD CONSTRAINT "leave_types_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "lifecycle_workflows" ADD CONSTRAINT "lifecycle_workflows_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "remote_work_policies" ADD CONSTRAINT "remote_work_policies_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "remote_work_requests" ADD CONSTRAINT "remote_work_requests_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "timesheets" ADD CONSTRAINT "timesheets_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "trainings" ADD CONSTRAINT "trainings_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_drafts" ADD CONSTRAINT "document_drafts_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_drafts" ADD CONSTRAINT "document_drafts_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_drafts" ADD CONSTRAINT "document_drafts_template_id_document_templates_id_fk" FOREIGN KEY ("template_id") REFERENCES "public"."document_templates"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "document_templates" ADD CONSTRAINT "document_templates_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "documents" ADD CONSTRAINT "documents_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "documents" ADD CONSTRAINT "documents_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "signature_requests" ADD CONSTRAINT "signature_requests_document_id_documents_id_fk" FOREIGN KEY ("document_id") REFERENCES "public"."documents"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "assistant_conversations" ADD CONSTRAINT "assistant_conversations_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "assistant_conversations" ADD CONSTRAINT "assistant_conversations_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "assistant_messages" ADD CONSTRAINT "assistant_messages_conversation_id_assistant_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "public"."assistant_conversations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "backups" ADD CONSTRAINT "backups_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "data_imports" ADD CONSTRAINT "data_imports_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_company_id_companies_id_fk" FOREIGN KEY ("company_id") REFERENCES "public"."companies"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "companies_tenant_idx" ON "companies" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "companies_siren_idx" ON "companies" USING btree ("siren");--> statement-breakpoint
CREATE INDEX "company_contacts_company_idx" ON "company_contacts" USING btree ("company_id");--> statement-breakpoint
CREATE UNIQUE INDEX "company_memberships_unique" ON "company_memberships" USING btree ("company_id","user_id");--> statement-breakpoint
CREATE INDEX "company_memberships_user_idx" ON "company_memberships" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "company_organisms_company_idx" ON "company_organisms" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "establishments_company_idx" ON "establishments" USING btree ("company_id");--> statement-breakpoint
CREATE INDEX "audit_logs_company_idx" ON "audit_logs" USING btree ("company_id","created_at");--> statement-breakpoint
CREATE INDEX "audit_logs_user_idx" ON "audit_logs" USING btree ("user_id","created_at");--> statement-breakpoint
CREATE INDEX "audit_logs_entity_idx" ON "audit_logs" USING btree ("entity_type","entity_id");--> statement-breakpoint
CREATE INDEX "invitations_tenant_idx" ON "invitations" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "invitations_email_idx" ON "invitations" USING btree ("email");--> statement-breakpoint
CREATE INDEX "jobs_status_idx" ON "jobs" USING btree ("status","run_after");--> statement-breakpoint
CREATE INDEX "mail_outbox_status_idx" ON "mail_outbox" USING btree ("status","created_at");--> statement-breakpoint
CREATE INDEX "one_time_tokens_purpose_idx" ON "one_time_tokens" USING btree ("purpose","expires_at");--> statement-breakpoint
CREATE INDEX "sessions_user_idx" ON "sessions" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "users_tenant_idx" ON "users" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "amendments_contract_idx" ON "contract_amendments" USING btree ("contract_id","effective_date");--> statement-breakpoint
CREATE INDEX "compensations_employee_idx" ON "compensations" USING btree ("employee_id","effective_date");--> statement-breakpoint
CREATE INDEX "contracts_employee_idx" ON "contracts" USING btree ("employee_id","start_date");--> statement-breakpoint
CREATE INDEX "employee_bank_employee_idx" ON "employee_bank_accounts" USING btree ("employee_id");--> statement-breakpoint
CREATE UNIQUE INDEX "employee_carryovers_unique" ON "employee_carryovers" USING btree ("employee_id","year");--> statement-breakpoint
CREATE INDEX "employee_events_employee_idx" ON "employee_events" USING btree ("employee_id","effective_date");--> statement-breakpoint
CREATE INDEX "employees_company_idx" ON "employees" USING btree ("company_id","status");--> statement-breakpoint
CREATE INDEX "employees_establishment_idx" ON "employees" USING btree ("establishment_id");--> statement-breakpoint
CREATE INDEX "employees_user_idx" ON "employees" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "employees_name_idx" ON "employees" USING btree ("company_id","last_name","first_name");--> statement-breakpoint
CREATE UNIQUE INDEX "employees_number_unique" ON "employees" USING btree ("company_id","employee_number");--> statement-breakpoint
CREATE INDEX "pas_rates_employee_idx" ON "pas_rates" USING btree ("employee_id","effective_date");--> statement-breakpoint
CREATE INDEX "payroll_anomalies_period_idx" ON "payroll_anomalies" USING btree ("period_id","status");--> statement-breakpoint
CREATE INDEX "payroll_filings_period_idx" ON "payroll_filings" USING btree ("period_id","kind");--> statement-breakpoint
CREATE UNIQUE INDEX "payroll_periods_unique" ON "payroll_periods" USING btree ("company_id","year","month");--> statement-breakpoint
CREATE INDEX "payroll_rule_sets_effective_idx" ON "payroll_rule_sets" USING btree ("effective_from");--> statement-breakpoint
CREATE INDEX "payroll_variables_period_idx" ON "payroll_variables" USING btree ("period_id","employee_id");--> statement-breakpoint
CREATE UNIQUE INDEX "payroll_variables_source_unique" ON "payroll_variables" USING btree ("period_id","employee_id","source","source_id");--> statement-breakpoint
CREATE UNIQUE INDEX "payslips_unique" ON "payslips" USING btree ("period_id","employee_id");--> statement-breakpoint
CREATE INDEX "payslips_employee_idx" ON "payslips" USING btree ("employee_id");--> statement-breakpoint
CREATE INDEX "deadlines_company_idx" ON "deadlines" USING btree ("company_id","due_date");--> statement-breakpoint
CREATE UNIQUE INDEX "deadlines_source_unique" ON "deadlines" USING btree ("source_type","source_id","kind");--> statement-breakpoint
CREATE INDEX "expense_lines_report_idx" ON "expense_lines" USING btree ("report_id");--> statement-breakpoint
CREATE INDEX "expense_reports_employee_idx" ON "expense_reports" USING btree ("employee_id","status");--> statement-breakpoint
CREATE INDEX "hr_requests_company_idx" ON "hr_requests" USING btree ("company_id","status");--> statement-breakpoint
CREATE INDEX "interviews_employee_idx" ON "interviews" USING btree ("employee_id","scheduled_at");--> statement-breakpoint
CREATE UNIQUE INDEX "leave_balances_unique" ON "leave_balances" USING btree ("employee_id","leave_type_id","period_start");--> statement-breakpoint
CREATE INDEX "leave_requests_employee_idx" ON "leave_requests" USING btree ("employee_id","start_date");--> statement-breakpoint
CREATE INDEX "leave_requests_status_idx" ON "leave_requests" USING btree ("status");--> statement-breakpoint
CREATE UNIQUE INDEX "leave_types_unique" ON "leave_types" USING btree ("company_id","code");--> statement-breakpoint
CREATE INDEX "lifecycle_workflows_employee_idx" ON "lifecycle_workflows" USING btree ("employee_id");--> statement-breakpoint
CREATE UNIQUE INDEX "remote_work_unique" ON "remote_work_requests" USING btree ("employee_id","date");--> statement-breakpoint
CREATE UNIQUE INDEX "timesheets_unique" ON "timesheets" USING btree ("employee_id","year","month");--> statement-breakpoint
CREATE INDEX "trainings_employee_idx" ON "trainings" USING btree ("employee_id");--> statement-breakpoint
CREATE INDEX "trainings_expiry_idx" ON "trainings" USING btree ("expires_at");--> statement-breakpoint
CREATE INDEX "document_drafts_company_idx" ON "document_drafts" USING btree ("company_id","status");--> statement-breakpoint
CREATE INDEX "document_templates_company_idx" ON "document_templates" USING btree ("company_id","category");--> statement-breakpoint
CREATE INDEX "documents_company_idx" ON "documents" USING btree ("company_id","category");--> statement-breakpoint
CREATE INDEX "documents_employee_idx" ON "documents" USING btree ("employee_id");--> statement-breakpoint
CREATE INDEX "documents_source_idx" ON "documents" USING btree ("source_type","source_id");--> statement-breakpoint
CREATE INDEX "signature_requests_document_idx" ON "signature_requests" USING btree ("document_id");--> statement-breakpoint
CREATE INDEX "assistant_conversations_user_idx" ON "assistant_conversations" USING btree ("user_id","updated_at");--> statement-breakpoint
CREATE INDEX "assistant_messages_conversation_idx" ON "assistant_messages" USING btree ("conversation_id","created_at");--> statement-breakpoint
CREATE INDEX "backups_tenant_idx" ON "backups" USING btree ("tenant_id","created_at");--> statement-breakpoint
CREATE INDEX "data_imports_company_idx" ON "data_imports" USING btree ("company_id","created_at");--> statement-breakpoint
CREATE INDEX "pricing_plans_active_idx" ON "pricing_plans" USING btree ("is_active","sort_order");--> statement-breakpoint
CREATE INDEX "subscriptions_company_idx" ON "subscriptions" USING btree ("company_id");