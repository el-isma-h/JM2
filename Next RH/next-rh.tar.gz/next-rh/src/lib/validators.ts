/**
 * Contrôles de format des identifiants administratifs français.
 * Fonctions pures, sans dépendance : utilisables côté serveur, côté client et dans les tests.
 */

/** Retire espaces, points et tirets (saisie « 123 456 789 » ou « FR76-3000… »). */
export function compact(value: string | null | undefined): string {
  return (value ?? "").replace(/[\s.\-_]/g, "");
}

/** Clé de Luhn : true si la somme pondérée est un multiple de 10. */
export function luhnValid(digits: string): boolean {
  if (!/^\d+$/.test(digits)) return false;
  let sum = 0;
  let double = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = digits.charCodeAt(i) - 48;
    if (double) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
    double = !double;
  }
  return sum % 10 === 0;
}

export type CheckResult = { ok: true; value: string } | { ok: false; error: string };

/** SIREN : 9 chiffres, clé de Luhn. */
export function checkSiren(input: string): CheckResult {
  const v = compact(input);
  if (!/^\d{9}$/.test(v)) return { ok: false, error: "Le SIREN comporte exactement 9 chiffres." };
  if (!luhnValid(v)) return { ok: false, error: "Ce SIREN n'existe pas : un chiffre est probablement mal saisi (contrôle de clé)." };
  return { ok: true, value: v };
}

/** La Poste (SIREN 356000000) : ses SIRET suivent une règle propre (somme des chiffres multiple de 5). */
const LA_POSTE_SIREN = "356000000";

/** SIRET : 14 chiffres (SIREN + NIC), clé de Luhn ; si `siren` est fourni, le SIRET doit commencer par lui. */
export function checkSiret(input: string, siren?: string | null): CheckResult {
  const v = compact(input);
  if (!/^\d{14}$/.test(v)) return { ok: false, error: "Le SIRET comporte exactement 14 chiffres (SIREN + NIC à 5 chiffres)." };
  const s = siren ? compact(siren) : null;
  if (s && !v.startsWith(s)) return { ok: false, error: `Le SIRET doit commencer par le SIREN de l'entreprise (${s}).` };
  if (v.startsWith(LA_POSTE_SIREN)) {
    const sum = [...v].reduce((a, c) => a + Number(c), 0);
    if (sum % 5 !== 0) return { ok: false, error: "Ce SIRET n'est pas valide (contrôle de clé)." };
    return { ok: true, value: v };
  }
  if (!luhnValid(v)) return { ok: false, error: "Ce SIRET n'est pas valide : un chiffre est probablement mal saisi (contrôle de clé)." };
  return { ok: true, value: v };
}

/** Compose un SIRET à partir du SIREN et du NIC (5 chiffres). */
export function buildSiret(siren: string, nic: string): string {
  return `${compact(siren)}${compact(nic).padStart(5, "0")}`;
}

/** Code APE / NAF : 4 chiffres + 1 lettre, normalisé « 62.01Z ». */
export function checkApe(input: string): CheckResult {
  const v = compact(input).toUpperCase();
  if (!/^\d{4}[A-Z]$/.test(v)) return { ok: false, error: "Format attendu : 4 chiffres et une lettre, par exemple 62.01Z." };
  return { ok: true, value: `${v.slice(0, 2)}.${v.slice(2)}` };
}

/** IDCC : identifiant de convention collective, 4 chiffres (« 1486 » pour Syntec). */
export function checkIdcc(input: string): CheckResult {
  const v = compact(input);
  if (!/^\d{1,4}$/.test(v)) return { ok: false, error: "L'IDCC comporte 4 chiffres, par exemple 1486." };
  return { ok: true, value: v.padStart(4, "0") };
}

/**
 * NIR (numéro de sécurité sociale) : 13 caractères + clé de 2 chiffres.
 * Clé = 97 - (nombre mod 97). Corse : 2A devient 19, 2B devient 18 pour le calcul.
 */
export function checkNir(input: string): CheckResult {
  const v = compact(input).toUpperCase();
  if (!/^[1-478][0-9]{2}(0[1-9]|1[0-2]|[2-9][0-9])(\d{2}|2A|2B)\d{6}\d{2}$/.test(v)) {
    return { ok: false, error: "Format attendu : 15 caractères (13 chiffres et la clé), par exemple 2 84 05 69 123 456 78." };
  }
  const body = v.slice(0, 13);
  const key = Number(v.slice(13));
  const numeric = body.replace("2A", "19").replace("2B", "18");
  const expected = 97 - Number(BigInt(numeric) % BigInt(97));
  if (key !== expected) return { ok: false, error: "La clé du numéro de sécurité sociale ne correspond pas : vérifiez chaque chiffre." };
  return { ok: true, value: v };
}

/** Clé NIR attendue pour les 13 premiers caractères (utile pour les tests et l'aide à la saisie). */
export function nirKey(body13: string): number {
  const numeric = body13.toUpperCase().replace("2A", "19").replace("2B", "18");
  return 97 - Number(BigInt(numeric) % BigInt(97));
}

export function maskNir(nir: string | null | undefined): string {
  if (!nir) return "-";
  const v = compact(nir);
  return `${v[0] ?? "*"} ** ** ** *** *** ${v.slice(-2)}`;
}

const IBAN_LENGTHS: Record<string, number> = {
  FR: 27, MC: 27, DE: 22, BE: 16, ES: 24, IT: 27, LU: 20, NL: 18, PT: 25, CH: 21, GB: 22, IE: 22, AT: 20, PL: 28, GP: 27, MQ: 27, RE: 27, GF: 27, YT: 27, NC: 27, PF: 27,
};

/** IBAN : longueur selon le pays, contrôle modulo 97 (ISO 13616). */
export function checkIban(input: string): CheckResult {
  const v = compact(input).toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(v)) return { ok: false, error: "Format attendu : 2 lettres de pays, 2 chiffres de clé puis le numéro de compte, par exemple FR76 ..." };
  const expectedLength = IBAN_LENGTHS[v.slice(0, 2)];
  if (expectedLength && v.length !== expectedLength) return { ok: false, error: `Un IBAN ${v.slice(0, 2)} comporte ${expectedLength} caractères (ici ${v.length}).` };
  const rearranged = v.slice(4) + v.slice(0, 4);
  let remainder = 0;
  for (const ch of rearranged) {
    const code = ch >= "A" && ch <= "Z" ? String(ch.charCodeAt(0) - 55) : ch;
    for (const d of code) remainder = (remainder * 10 + Number(d)) % 97;
  }
  if (remainder !== 1) return { ok: false, error: "Cet IBAN n'est pas valide : un caractère est probablement mal saisi (contrôle de clé)." };
  return { ok: true, value: v };
}

/** BIC : 8 ou 11 caractères. */
export function checkBic(input: string): CheckResult {
  const v = compact(input).toUpperCase();
  if (!/^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/.test(v)) return { ok: false, error: "Le BIC comporte 8 ou 11 caractères, par exemple BNPAFRPPXXX." };
  return { ok: true, value: v };
}

export function formatIbanGroups(iban: string): string {
  return compact(iban).toUpperCase().replace(/(.{4})/g, "$1 ").trim();
}

/** Code postal français (métropole et outre-mer). */
export function checkPostalCode(input: string): CheckResult {
  const v = compact(input);
  if (!/^\d{5}$/.test(v)) return { ok: false, error: "Le code postal comporte 5 chiffres." };
  return { ok: true, value: v };
}

/**
 * Date saisie ou importée : accepte AAAA-MM-JJ, JJ/MM/AAAA, JJ-MM-AAAA, JJ.MM.AAAA.
 * Retourne l'ISO AAAA-MM-JJ ou null si la date est invalide (31/02 refusé).
 */
export function parseDateInput(input: string | null | undefined): string | null {
  const v = (input ?? "").trim();
  if (!v) return null;
  let y: number, m: number, d: number;
  let match = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(v);
  if (match) {
    [y, m, d] = [Number(match[1]), Number(match[2]), Number(match[3])];
  } else {
    match = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(v);
    if (!match) return null;
    [d, m, y] = [Number(match[1]), Number(match[2]), Number(match[3])];
  }
  if (y < 1900 || y > 2100 || m < 1 || m > 12 || d < 1) return null;
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  if (d > last) return null;
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

/**
 * Montant en euros saisi à la française (« 2 450,30 », « 2450.3 », « 2 450,30 € ») vers centimes entiers.
 * Retourne null si la saisie n'est pas un montant.
 */
export function parseAmountToCents(input: string | null | undefined): number | null {
  let v = (input ?? "").replace(/[\s  €]/g, "").replace(/EUR$/i, "");
  if (!v) return null;
  if (/^-?\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(v)) v = v.replace(/\./g, "");
  v = v.replace(",", ".");
  if (!/^-?\d+(\.\d{1,2})?$/.test(v)) return null;
  const [int, dec = ""] = v.replace("-", "").split(".");
  const cents = Number(int) * 100 + Number(dec.padEnd(2, "0"));
  return v.startsWith("-") ? -cents : cents;
}

/** Nombre décimal (heures, jours, taux) saisi à la française vers chaîne normalisée « 151.67 ». */
export function parseDecimal(input: string | null | undefined, maxDecimals = 2): string | null {
  const v = (input ?? "").replace(/[\s %]/g, "").replace(",", ".");
  if (!v) return null;
  const re = new RegExp(`^-?\\d+(\\.\\d{1,${maxDecimals}})?$`);
  if (!re.test(v)) return null;
  return v;
}

/** Taux en pourcentage (AT/MP, versement mobilité) : 0 à 100 avec 4 décimales max. */
export function checkRate(input: string, label = "Le taux"): CheckResult {
  const v = parseDecimal(input, 4);
  if (v === null) return { ok: false, error: `${label} s'écrit en pourcentage, par exemple 1,30.` };
  const n = Number(v);
  if (n < 0 || n > 100) return { ok: false, error: `${label} doit être compris entre 0 et 100 %.` };
  const decimals = (v.split(".")[1] ?? "").length;
  return { ok: true, value: n.toFixed(Math.max(2, decimals)) };
}

export function isEmail(v: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());
}
