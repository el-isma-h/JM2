import { describe, expect, it } from "vitest";
import {
  buildSiret,
  checkApe,
  checkBic,
  checkIban,
  checkIdcc,
  checkNir,
  checkRate,
  checkSiren,
  checkSiret,
  luhnValid,
  maskNir,
  nirKey,
  parseAmountToCents,
  parseDateInput,
  parseDecimal,
} from "../validators";

describe("Luhn", () => {
  it("valide et rejette", () => {
    expect(luhnValid("552032534")).toBe(true);
    expect(luhnValid("552032535")).toBe(false);
    expect(luhnValid("abc")).toBe(false);
  });
});

describe("SIREN", () => {
  it("accepte un SIREN valide, avec espaces", () => {
    expect(checkSiren("552 032 534")).toEqual({ ok: true, value: "552032534" });
    expect(checkSiren("732829320").ok).toBe(true);
  });
  it("rejette une mauvaise longueur ou une mauvaise clé", () => {
    expect(checkSiren("55203253").ok).toBe(false);
    expect(checkSiren("552032535").ok).toBe(false);
    expect(checkSiren("ABCDEFGHI").ok).toBe(false);
  });
});

describe("SIRET", () => {
  it("accepte un SIRET valide et vérifie l'appartenance au SIREN", () => {
    expect(checkSiret("552 032 534 00646").ok).toBe(true);
    expect(checkSiret("55203253400646", "552032534").ok).toBe(true);
    const wrongCompany = checkSiret("73282932000074", "552032534");
    expect(wrongCompany.ok).toBe(false);
  });
  it("rejette une clé fausse", () => {
    expect(checkSiret("55203253400647").ok).toBe(false);
    expect(checkSiret("5520325340064").ok).toBe(false);
  });
  it("applique la règle particulière de La Poste", () => {
    expect(checkSiret("35600000049837").ok).toBe(true);
    expect(checkSiret("35600000000048").ok).toBe(false);
  });
  it("compose SIREN + NIC", () => {
    expect(buildSiret("552032534", "646")).toBe("55203253400646");
  });
});

describe("APE et IDCC", () => {
  it("normalise le code APE", () => {
    expect(checkApe("6201z")).toEqual({ ok: true, value: "62.01Z" });
    expect(checkApe("62.01Z")).toEqual({ ok: true, value: "62.01Z" });
    expect(checkApe("620Z").ok).toBe(false);
    expect(checkApe("62011").ok).toBe(false);
  });
  it("normalise l'IDCC sur 4 chiffres", () => {
    expect(checkIdcc("1486")).toEqual({ ok: true, value: "1486" });
    expect(checkIdcc("16")).toEqual({ ok: true, value: "0016" });
    expect(checkIdcc("14865").ok).toBe(false);
  });
});

describe("NIR", () => {
  it("calcule la clé 97 - (n mod 97)", () => {
    expect(nirKey("1840569123456")).toBe(90);
    expect(checkNir("1 84 05 69 123 456 90")).toEqual({ ok: true, value: "184056912345690" });
  });
  it("rejette une clé incorrecte", () => {
    expect(checkNir("184056912345691").ok).toBe(false);
  });
  it("gère la Corse (2A / 2B)", () => {
    const key = String(nirKey("185072A123456")).padStart(2, "0");
    expect(checkNir(`185072A123456${key}`).ok).toBe(true);
    const keyB = String(nirKey("290012B054321")).padStart(2, "0");
    expect(checkNir(`290012B054321${keyB}`).ok).toBe(true);
  });
  it("rejette un format invalide", () => {
    expect(checkNir("584056912345690").ok).toBe(false);
    expect(checkNir("18405691234569").ok).toBe(false);
    expect(checkNir("184136912345690").ok).toBe(false);
  });
  it("masque le NIR", () => {
    expect(maskNir("184056912345690")).toBe("1 ** ** ** *** *** 90");
  });
});

describe("IBAN et BIC", () => {
  it("valide un IBAN français et allemand", () => {
    expect(checkIban("FR76 3000 6000 0112 3456 7890 189")).toEqual({ ok: true, value: "FR7630006000011234567890189" });
    expect(checkIban("DE89370400440532013000").ok).toBe(true);
  });
  it("rejette une clé ou une longueur incorrecte", () => {
    expect(checkIban("FR7630006000011234567890188").ok).toBe(false);
    expect(checkIban("FR763000600001123456789018").ok).toBe(false);
    expect(checkIban("1234").ok).toBe(false);
  });
  it("valide le BIC", () => {
    expect(checkBic("BNPAFRPP").ok).toBe(true);
    expect(checkBic("bnpafrppxxx")).toEqual({ ok: true, value: "BNPAFRPPXXX" });
    expect(checkBic("BNP").ok).toBe(false);
  });
});

describe("Dates, montants, taux", () => {
  it("lit les dates françaises et ISO", () => {
    expect(parseDateInput("31/01/2026")).toBe("2026-01-31");
    expect(parseDateInput("2026-1-5")).toBe("2026-01-05");
    expect(parseDateInput("5.3.1987")).toBe("1987-03-05");
    expect(parseDateInput("30/02/2026")).toBeNull();
    expect(parseDateInput("2026-13-01")).toBeNull();
    expect(parseDateInput("")).toBeNull();
  });
  it("convertit les montants en centimes", () => {
    expect(parseAmountToCents("2 450,30")).toBe(245030);
    expect(parseAmountToCents("2450.3")).toBe(245030);
    expect(parseAmountToCents("2.450,30 €")).toBe(245030);
    expect(parseAmountToCents("1 812")).toBe(181200);
    expect(parseAmountToCents("-12,5")).toBe(-1250);
    expect(parseAmountToCents("abc")).toBeNull();
    expect(parseAmountToCents("12,345")).toBeNull();
  });
  it("lit les décimaux et les taux", () => {
    expect(parseDecimal("151,67")).toBe("151.67");
    expect(parseDecimal("35")).toBe("35");
    expect(checkRate("1,3")).toEqual({ ok: true, value: "1.30" });
    expect(checkRate("2.9500")).toEqual({ ok: true, value: "2.9500" });
    expect(checkRate("120").ok).toBe(false);
    expect(checkRate("x").ok).toBe(false);
  });
});
