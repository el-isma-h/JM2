/** Montants en centimes, arrondis au centime au plus proche (règle bancaire : demi vers le haut). */
export function roundCents(value: number): number {
  return Math.round(value + Number.EPSILON);
}

export function formatCents(cents: number | null | undefined, opts: { signed?: boolean } = {}): string {
  if (cents === null || cents === undefined) return "-";
  const s = new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(cents / 100);
  return opts.signed && cents > 0 ? `+${s}` : s;
}

export function formatNumber(n: number | string | null | undefined, digits = 2): string {
  if (n === null || n === undefined) return "-";
  return new Intl.NumberFormat("fr-FR", { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(Number(n));
}

export function formatPercent(rate: number | string, digits = 2): string {
  return `${formatNumber(rate, digits)} %`;
}

/** Tronque au centime inférieur : utilisé pour les tarifs à −10 % (ne jamais rogner la remise). */
export function floorCents(value: number): number {
  return Math.floor(value + 1e-9);
}
