/** État de configuration des services externes : utilisé pour afficher « configuration manquante » au lieu de boutons morts. */
export const integrations = {
  mail: () => Boolean(process.env.RESEND_API_KEY),
  ai: () => Boolean(process.env.ANTHROPIC_API_KEY),
  s3: () => Boolean(process.env.S3_ENDPOINT && process.env.S3_BUCKET && process.env.S3_ACCESS_KEY),
  esign: () => Boolean(process.env.ESIGN_PROVIDER && process.env.ESIGN_API_KEY),
};

export const appUrl = () => process.env.APP_URL ?? "http://localhost:3000";

export type IntegrationName = keyof typeof integrations;

export const integrationLabels: Record<IntegrationName, { label: string; envVars: string[]; effect: string }> = {
  mail: {
    label: "E-mail transactionnel (Resend)",
    envVars: ["RESEND_API_KEY", "MAIL_FROM"],
    effect: "Les e-mails sont journalisés dans la boîte d'envoi mais ne partent pas.",
  },
  ai: {
    label: "Assistant IA et rédaction (Anthropic)",
    envVars: ["ANTHROPIC_API_KEY"],
    effect: "L'assistant répond avec ses règles internes uniquement ; la rédaction utilise les modèles sans reformulation.",
  },
  s3: {
    label: "Stockage documentaire S3",
    envVars: ["S3_ENDPOINT", "S3_BUCKET", "S3_ACCESS_KEY", "S3_SECRET_KEY"],
    effect: "Les documents sont stockés sur le disque local du serveur (STORAGE_DIR), hors du dossier public.",
  },
  esign: {
    label: "Signature électronique",
    envVars: ["ESIGN_PROVIDER", "ESIGN_API_KEY"],
    effect: "Les demandes de signature sont enregistrées avec le statut « non configuré ».",
  },
};
