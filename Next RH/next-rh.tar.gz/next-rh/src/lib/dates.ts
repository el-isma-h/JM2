import { format, parseISO } from "date-fns";
import { fr } from "date-fns/locale";

export function fmtDate(d: string | Date | null | undefined, pattern = "d MMM yyyy"): string {
  if (!d) return "-";
  const date = typeof d === "string" ? parseISO(d) : d;
  return format(date, pattern, { locale: fr });
}

export function fmtDateTime(d: string | Date | null | undefined): string {
  return fmtDate(d, "d MMM yyyy 'à' HH:mm");
}

export function monthLabel(year: number, month: number): string {
  return format(new Date(year, month - 1, 1), "MMMM yyyy", { locale: fr });
}

export function isoToday(): string {
  return format(new Date(), "yyyy-MM-dd");
}

export function daysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

/** Jours ouvrés (lun–ven) entre deux dates ISO incluses, hors jours fériés fournis. */
export function workingDaysBetween(startIso: string, endIso: string, holidays: string[] = []): number {
  const start = parseISO(startIso);
  const end = parseISO(endIso);
  let n = 0;
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const wd = d.getDay();
    const iso = format(d, "yyyy-MM-dd");
    if (wd !== 0 && wd !== 6 && !holidays.includes(iso)) n++;
  }
  return n;
}

/** Jours fériés France métropolitaine (calcul de Pâques inclus). */
export function frenchHolidays(year: number): string[] {
  const a = year % 19, b = Math.floor(year / 100), c = year % 100, d = Math.floor(b / 4), e = b % 4;
  const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31), day = ((h + l - 7 * m + 114) % 31) + 1;
  const easter = new Date(year, month - 1, day);
  const plus = (n: number) => { const x = new Date(easter); x.setDate(x.getDate() + n); return format(x, "yyyy-MM-dd"); };
  return [
    `${year}-01-01`, plus(1), `${year}-05-01`, `${year}-05-08`, plus(39), plus(50),
    `${year}-07-14`, `${year}-08-15`, `${year}-11-01`, `${year}-11-11`, `${year}-12-25`,
  ];
}

/** « de septembre 2026 » / « d'août 2026 » : élision devant voyelle (avril, août, octobre). */
export function deMonth(label: string): string {
  return /^[aeiouyàâéèêh]/i.test(label) ? `d'${label}` : `de ${label}`;
}
