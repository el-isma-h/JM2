import { db, schema } from "@/db";
import { asc, eq } from "drizzle-orm";
import { formatCents } from "@/lib/money";
import { getCurrentUser } from "@/server/auth";
import { Marketing } from "@/components/marketing/home";

export const dynamic = "force-dynamic";

const unitLabel: Record<string, string> = {
  par_salarie_mois: "par salarié et par mois",
  par_declarant_mois: "par déclarant et par mois",
  par_document: "par document",
  par_facture: "par facture",
  forfait_mois: "par mois",
  sur_devis: "sur devis",
  inclus: "inclus",
};

export default async function Home() {
  const user = await getCurrentUser();
  const plans = await db.select().from(schema.pricingPlans).where(eq(schema.pricingPlans.isActive, true)).orderBy(asc(schema.pricingPlans.sortOrder));
  return (
    <Marketing
      isLoggedIn={Boolean(user)}
      plans={plans.map((p) => ({
        code: p.code,
        name: p.name,
        description: p.description ?? "",
        isService: p.isService,
        price: p.unit === "inclus" ? "Inclus" : p.priceCents === null ? "Sur devis" : formatCents(p.priceCents),
        unit: unitLabel[p.unit] ?? p.unit,
        reference: p.referencePriceCents !== null && p.unit !== "inclus" ? formatCents(p.referencePriceCents) : null,
      }))}
    />
  );
}
