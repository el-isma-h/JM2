import { redirect } from "next/navigation";
import { requireUser } from "@/server/auth";
import { listAccessibleCompanies } from "@/server/authz";
import { db, schema } from "@/db";
import { and, eq } from "drizzle-orm";

/** Point d'entrée : salarié → son espace ; une entreprise → son tableau de bord ; plusieurs → la liste des dossiers. */
export default async function AppIndex() {
  const user = await requireUser();
  const companies = await listAccessibleCompanies(user);
  if (companies.length === 0) {
    // Salarié rattaché sans affectation d'entreprise ?
    const [emp] = await db
      .select({ id: schema.employees.id })
      .from(schema.employees)
      .where(and(eq(schema.employees.userId, user.id)))
      .limit(1);
    if (emp) redirect("/moi");
    redirect("/app/entreprises");
  }
  if (companies.length === 1) {
    const [m] = await db
      .select({ role: schema.companyMemberships.role })
      .from(schema.companyMemberships)
      .where(and(eq(schema.companyMemberships.companyId, companies[0].id), eq(schema.companyMemberships.userId, user.id)))
      .limit(1);
    if (m?.role === "employee") redirect("/moi");
    redirect(`/app/${companies[0].id}`);
  }
  redirect("/app/entreprises");
}
