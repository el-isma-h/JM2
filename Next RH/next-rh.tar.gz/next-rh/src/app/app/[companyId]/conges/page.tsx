import Link from "next/link";
import { and, desc, eq, gte, inArray, lte } from "drizzle-orm";
import { CalendarBlank, GearSix, Paperclip, Plus } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { listEmployees, monthParam, parseMonthParam, todayIso, fullName } from "@/server/hr/common";
import { getLeaveTypes, isLeaveSelectable, recomputeBalances } from "@/server/hr/leave";
import { cpReferencePeriod } from "@/server/hr/calc";
import { adjustBalanceAction, attachLeaveProofAction, cancelLeaveAction, createLeaveForEmployeeAction, decideLeaveAction } from "@/server/actions/leave";
import { proofLinkAction } from "@/server/actions/requests";
import { ActionButton, ActionForm, DialogForm } from "@/components/hr/action-form";
import { LinkTabs, MonthNav, Person } from "@/components/hr/bits";
import { LeaveFields } from "@/components/hr/leave-fields";
import { EmptyState, PageHeader, Panel, PanelHeader, Notice } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { daysInMonth, fmtDate, frenchHolidays } from "@/lib/dates";
import { formatNumber } from "@/lib/money";
import { cn } from "@/lib/utils";

type Search = Promise<{ vue?: string; mois?: string }>;

export default async function CongesPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Search }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/conges`;
  const ctx = await guardCompany(companyId, base, "employees.read");
  const canApprove = ctx.permissions.has("requests.approve");
  const view = sp.vue === "demandes" || sp.vue === "soldes" ? sp.vue : "planning";
  const { year, month } = parseMonthParam(sp.mois);

  const [employees, types] = await Promise.all([listEmployees(companyId), getLeaveTypes(companyId)]);
  const selectable = types.filter(isLeaveSelectable);
  const empIds = employees.map((e) => e.id);
  const empById = new Map(employees.map((e) => [e.id, e]));
  const typeById = new Map(types.map((t) => [t.id, t]));

  const pending = empIds.length
    ? await db
        .select()
        .from(schema.leaveRequests)
        .where(and(inArray(schema.leaveRequests.employeeId, empIds), eq(schema.leaveRequests.status, "pending")))
        .orderBy(schema.leaveRequests.startDate)
    : [];

  const hidden = { companyId };
  const header = (
    <PageHeader
      title="Congés et absences"
      description="Planning de l'équipe, demandes à valider et soldes. Les absences validées qui ont un effet sur la paie sont transmises automatiquement aux variables du mois."
      actions={
        <>
          {ctx.permissions.has("company.manage") ? (
            <Button asChild variant="secondary">
              <Link href={`${base}/types`}>
                <GearSix size={16} /> Types d&apos;absence
              </Link>
            </Button>
          ) : null}
          {canApprove && employees.length ? (
            <DialogForm
              trigger={
                <>
                  <Plus size={16} /> Saisir une absence
                </>
              }
              title="Saisir une absence"
              description="Pour un salarié, au nom du service RH."
              action={createLeaveForEmployeeAction}
              hidden={hidden}
              submitLabel="Enregistrer l'absence"
              closeOnSuccess={false}
            >
              <LeaveFields rh types={selectable} employees={employees.map((e) => ({ id: e.id, name: fullName(e) }))} />
            </DialogForm>
          ) : null}
        </>
      }
    />
  );

  const tabs = (
    <LinkTabs
      label="Vues des congés"
      current={view}
      items={[
        { key: "planning", label: "Planning", href: `${base}?mois=${monthParam(year, month)}` },
        { key: "demandes", label: "Demandes à traiter", href: `${base}?vue=demandes`, count: pending.length },
        { key: "soldes", label: "Soldes", href: `${base}?vue=soldes` },
      ]}
    />
  );

  if (!employees.length) {
    return (
      <>
        {header}
        <Panel>
          <EmptyState
            icon={<CalendarBlank size={28} />}
            title="Aucun salarié pour l'instant"
            description="Ajoutez vos salariés pour suivre leurs congés, absences et soldes."
            action={
              <Button asChild>
                <Link href={`/app/${companyId}/salaries`}>Ajouter des salariés</Link>
              </Button>
            }
          />
        </Panel>
      </>
    );
  }

  // ---------- Demandes ----------
  if (view === "demandes") {
    const recent = await db
      .select()
      .from(schema.leaveRequests)
      .where(and(inArray(schema.leaveRequests.employeeId, empIds), inArray(schema.leaveRequests.status, ["approved", "rejected", "cancelled"])))
      .orderBy(desc(schema.leaveRequests.updatedAt))
      .limit(30);
    const balancesByEmp = new Map<string, Awaited<ReturnType<typeof recomputeBalances>>>();
    for (const eid of [...new Set(pending.map((p) => p.employeeId))]) balancesByEmp.set(eid, await recomputeBalances(db, companyId, eid));

    return (
      <>
        {header}
        {tabs}
        <Panel>
          <PanelHeader title="En attente de décision" description="Validez ou refusez en un clic. Le solde affiché tient compte de la demande." />
          {pending.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Salarié</Th>
                  <Th>Absence</Th>
                  <Th>Période</Th>
                  <Th num>Durée</Th>
                  <Th num>Solde après</Th>
                  <Th>Justificatif</Th>
                  <Th className="text-right">Décision</Th>
                </tr>
              </thead>
              <tbody>
                {pending.map((r) => {
                  const e = empById.get(r.employeeId)!;
                  const t = typeById.get(r.leaveTypeId);
                  const bal = balancesByEmp.get(r.employeeId)?.find((b) => b.leaveTypeId === r.leaveTypeId);
                  return (
                    <tr key={r.id}>
                      <Td>
                        <Person first={e.firstName} last={e.lastName} sub={e.jobTitle ?? undefined} />
                      </Td>
                      <Td>
                        {t?.label}
                        {r.reason ? <span className="block max-w-[28ch] truncate text-[12px] text-ink-3">{r.reason}</span> : null}
                      </Td>
                      <Td className="whitespace-nowrap">
                        {fmtDate(r.startDate)}
                        {r.startDate !== r.endDate ? ` au ${fmtDate(r.endDate)}` : ""}
                        {r.startHalfDay || r.endHalfDay ? <span className="block text-[12px] text-ink-3">{[r.startHalfDay && "début après-midi", r.endHalfDay && "fin à midi"].filter(Boolean).join(", ")}</span> : null}
                      </Td>
                      <Td num>{formatNumber(r.duration, Number(r.duration) % 1 ? 1 : 0)} j</Td>
                      <Td num className={cn(bal && bal.available < 0 && "text-danger-ink")}>{bal ? `${formatNumber(bal.available, 2)} j` : "-"}</Td>
                      <Td>
                        {r.proofDocumentId ? (
                          <ActionButton action={proofLinkAction} hidden={{ companyId, documentId: r.proofDocumentId }} label="Ouvrir" variant="link" icon={<Paperclip size={14} />} />
                        ) : t?.requiresProof ? (
                          canApprove ? (
                            <ProofUpload companyId={companyId} requestId={r.id} />
                          ) : (
                            <Badge tone="warn">Manquant</Badge>
                          )
                        ) : (
                          <span className="text-ink-3">Non requis</span>
                        )}
                      </Td>
                      <Td className="text-right">
                        {canApprove ? (
                          <div className="flex flex-wrap justify-end gap-1.5">
                            <ActionButton action={decideLeaveAction} hidden={{ companyId, requestId: r.id, decision: "approve" }} label="Valider" variant="primary" />
                            <ActionButton
                              action={decideLeaveAction}
                              hidden={{ companyId, requestId: r.id, decision: "reject" }}
                              label="Refuser"
                              variant="ghost"
                              confirm={{ title: "Refuser la demande", description: `${fullName(e)} sera informé du refus.`, confirmLabel: "Refuser", withNote: "Motif (visible par le salarié)" }}
                            />
                          </div>
                        ) : (
                          <span className="text-ink-3">Lecture seule</span>
                        )}
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune demande en attente" description="Les nouvelles demandes de congé des salariés apparaîtront ici." />
          )}
        </Panel>

        <Panel className="mt-6">
          <PanelHeader title="Décisions récentes" description="Une absence validée peut être annulée : la variable de paie est retirée, ou régularisée le mois suivant si la paie est déjà validée." />
          {recent.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Salarié</Th>
                  <Th>Absence</Th>
                  <Th>Période</Th>
                  <Th num>Durée</Th>
                  <Th>Statut</Th>
                  <Th>Paie</Th>
                  <Th className="text-right">Action</Th>
                </tr>
              </thead>
              <tbody>
                {recent.map((r) => {
                  const e = empById.get(r.employeeId)!;
                  const t = typeById.get(r.leaveTypeId);
                  return (
                    <tr key={r.id}>
                      <Td>{fullName(e)}</Td>
                      <Td>{t?.label}</Td>
                      <Td className="whitespace-nowrap">
                        {fmtDate(r.startDate)}
                        {r.startDate !== r.endDate ? ` au ${fmtDate(r.endDate)}` : ""}
                      </Td>
                      <Td num>{formatNumber(r.duration, Number(r.duration) % 1 ? 1 : 0)} j</Td>
                      <Td>
                        <StatusBadge status={r.status} />
                      </Td>
                      <Td>{r.payrollVariableId ? <Badge tone="info">Transmise</Badge> : t?.affectsPayroll ? <span className="text-ink-3">-</span> : <span className="text-ink-3">Sans effet</span>}</Td>
                      <Td className="text-right">
                        {canApprove && r.status === "approved" ? (
                          <ActionButton
                            action={cancelLeaveAction}
                            hidden={{ companyId, requestId: r.id }}
                            label="Annuler"
                            variant="ghost"
                            confirm={{
                              title: "Annuler cette absence",
                              description: "Le solde sera recrédité. Si la paie du mois est déjà validée, une régularisation sera prévue le mois suivant.",
                              confirmLabel: "Annuler l'absence",
                              withNote: "Motif",
                            }}
                          />
                        ) : null}
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune décision récente" />
          )}
        </Panel>
      </>
    );
  }

  // ---------- Soldes ----------
  if (view === "soldes") {
    const accrualTypes = types.filter((t) => t.monthlyAccrual !== null && Number(t.monthlyAccrual) > 0);
    const rows = await Promise.all(employees.map(async (e) => ({ e, balances: await recomputeBalances(db, companyId, e.id) })));
    const cp = cpReferencePeriod(todayIso());
    return (
      <>
        {header}
        {tabs}
        <Notice tone="info" className="mb-4">
          Congés payés : 2,08 jours ouvrés acquis par mois travaillé, période de référence du 1er juin au 31 mai (en cours : {fmtDate(cp.start)} au {fmtDate(cp.end)}). Les jours posés consomment d&apos;abord le reliquat de la période précédente.
        </Notice>
        {accrualTypes.length ? (
          <Panel>
            <PanelHeader
              title="Soldes par salarié"
              description="Acquis, pris, en attente et disponible, par type d'absence à solde."
              actions={
                ctx.permissions.has("employees.write") ? (
                  <DialogForm trigger="Ajuster un solde" triggerVariant="secondary" title="Ajuster un solde" description="Reprise d'historique ou correction. L'ajustement remplace le précédent pour la période." action={adjustBalanceAction} hidden={hidden} submitLabel="Enregistrer l'ajustement">
                    <AdjustFields employees={employees.map((e) => ({ id: e.id, name: fullName(e) }))} types={accrualTypes} />
                  </DialogForm>
                ) : null
              }
            />
            <Table>
              <thead>
                <tr>
                  <Th>Salarié</Th>
                  {accrualTypes.map((t) => (
                    <Th key={t.id} num>
                      {t.label}
                    </Th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map(({ e, balances }) => (
                  <tr key={e.id}>
                    <Td>
                      <Person first={e.firstName} last={e.lastName} sub={e.hireDate ? `Entrée le ${fmtDate(e.hireDate)}` : "Date d'entrée à renseigner"} />
                    </Td>
                    {accrualTypes.map((t) => {
                      const b = balances.find((x) => x.leaveTypeId === t.id);
                      if (!b) return <Td key={t.id} num>-</Td>;
                      const [prev, cur] = b.periods;
                      return (
                        <Td key={t.id} num>
                          <span className={cn("text-[14px] font-medium", b.available < 0 ? "text-danger-ink" : "text-ink")}>{formatNumber(b.available, 2)} j</span>
                          <span className="block text-[11.5px] text-ink-3">
                            N-1 : {formatNumber(prev.remaining, 2)} ; en cours : {formatNumber(cur.acquired, 2)} acquis
                            {cur.taken + prev.taken > 0 ? `, ${formatNumber(cur.taken + prev.taken, 1)} pris` : ""}
                            {cur.pending + prev.pending > 0 ? `, ${formatNumber(cur.pending + prev.pending, 1)} en attente` : ""}
                          </span>
                        </Td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </Table>
          </Panel>
        ) : (
          <Panel>
            <EmptyState title="Aucun type d'absence à solde" description="Indiquez une acquisition mensuelle (par exemple 2,08 pour les congés payés) dans les types d'absence." action={<Button asChild><Link href={`${base}/types`}>Paramétrer les types</Link></Button>} />
          </Panel>
        )}
      </>
    );
  }

  // ---------- Planning ----------
  const first = `${monthParam(year, month)}-01`;
  const nDays = daysInMonth(year, month);
  const last = `${monthParam(year, month)}-${String(nDays).padStart(2, "0")}`;
  const monthRequests = await db
    .select()
    .from(schema.leaveRequests)
    .where(
      and(
        inArray(schema.leaveRequests.employeeId, empIds),
        inArray(schema.leaveRequests.status, ["approved", "pending"]),
        lte(schema.leaveRequests.startDate, last),
        gte(schema.leaveRequests.endDate, first),
      ),
    );
  const holidays = new Set(frenchHolidays(year));
  const days = Array.from({ length: nDays }, (_, i) => {
    const iso = `${monthParam(year, month)}-${String(i + 1).padStart(2, "0")}`;
    const wd = new Date(year, month - 1, i + 1).getDay();
    return { iso, n: i + 1, wd, off: wd === 0 || wd === 6 || holidays.has(iso), holiday: holidays.has(iso) };
  });
  const wdLetter = ["D", "L", "M", "M", "J", "V", "S"];
  const today = todayIso();
  const absentToday = monthRequests.filter((r) => r.status === "approved" && r.startDate <= today && r.endDate >= today).length;

  return (
    <>
      {header}
      {tabs}
      <Panel>
        <PanelHeader
          title="Planning de l'équipe"
          description={`${monthRequests.filter((r) => r.status === "approved").length} absence(s) validée(s) ce mois, ${monthRequests.filter((r) => r.status === "pending").length} en attente${absentToday ? `, ${absentToday} absent(s) aujourd'hui` : ""}.`}
          actions={<MonthNav base={base} year={year} month={month} />}
        />
        <div className="overflow-x-auto">
          <table className="w-full border-separate border-spacing-0 text-[12px]">
            <caption className="sr-only">Absences par salarié et par jour</caption>
            <thead>
              <tr>
                <th scope="col" className="sticky left-0 z-[2] min-w-[180px] border-b border-line-strong bg-bg-sunken px-3 py-2 text-left font-medium text-ink-2">
                  Salarié
                </th>
                {days.map((d) => (
                  <th
                    key={d.iso}
                    scope="col"
                    className={cn("min-w-[26px] border-b border-line-strong px-0 py-1.5 text-center font-medium", d.off ? "bg-bg-muted text-ink-3" : "bg-bg-sunken text-ink-2", d.iso === today && "text-accent-strong")}
                    title={d.holiday ? "Jour férié" : undefined}
                  >
                    <span className="block text-[10.5px] font-normal">{wdLetter[d.wd]}</span>
                    <span className="num">{d.n}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {employees.map((e) => {
                const reqs = monthRequests.filter((r) => r.employeeId === e.id);
                return (
                  <tr key={e.id}>
                    <th scope="row" className="sticky left-0 z-[1] border-b border-line bg-bg-elev px-3 py-1.5 text-left font-normal">
                      <span className="block truncate text-[13px] text-ink">{fullName(e)}</span>
                    </th>
                    {days.map((d) => {
                      const r = reqs.find((x) => x.startDate <= d.iso && x.endDate >= d.iso);
                      const t = r ? typeById.get(r.leaveTypeId) : undefined;
                      const label = r && t ? `${fullName(e)} : ${t.label}${r.status === "pending" ? " (en attente)" : ""}, ${fmtDate(d.iso)}` : undefined;
                      return (
                        <td key={d.iso} className={cn("h-8 border-b border-line p-[2px] text-center", d.off && "bg-bg-muted")}>
                          {r && t && !d.off ? (
                            <span
                              title={label}
                              aria-label={label}
                              className={cn(
                                "flex h-full w-full items-center justify-center rounded-none text-[10px] font-semibold",
                                r.status === "approved" ? "bg-accent-soft text-accent-strong" : "border border-dashed border-warn bg-warn-soft text-warn-ink",
                              )}
                            >
                              {t.code.slice(0, 3)}
                            </span>
                          ) : null}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-line px-5 py-3 text-[12.5px] text-ink-2">
          <span className="flex items-center gap-1.5">
            <span aria-hidden className="h-3 w-4 rounded-none bg-accent-soft" /> Validée
          </span>
          <span className="flex items-center gap-1.5">
            <span aria-hidden className="h-3 w-4 rounded-none border border-dashed border-warn bg-warn-soft" /> En attente
          </span>
          <span className="flex items-center gap-1.5">
            <span aria-hidden className="h-3 w-4 rounded-none bg-bg-muted" /> Week-end ou jour férié
          </span>
          <span className="text-ink-3">Codes : {selectable.map((t) => `${t.code.slice(0, 3)} ${t.label.toLowerCase()}`).join(", ")}</span>
        </div>
      </Panel>
    </>
  );
}

function ProofUpload({ companyId, requestId }: { companyId: string; requestId: string }) {
  return (
    <ActionForm action={attachLeaveProofAction} hidden={{ companyId, requestId }} submitLabel="Joindre" submitVariant="secondary" className="flex flex-wrap items-center gap-2 space-y-0">
      <label className="sr-only" htmlFor={`proof-${requestId}`}>
        Justificatif
      </label>
      <Input id={`proof-${requestId}`} name="proof" type="file" required accept="application/pdf,image/jpeg,image/png,image/webp,image/heic" className="h-8 w-[180px] py-1 text-[12px]" />
    </ActionForm>
  );
}

function AdjustFields({ employees, types }: { employees: { id: string; name: string }[]; types: { id: string; label: string; code: string }[] }) {
  const cur = cpReferencePeriod(todayIso());
  const prevStart = `${Number(cur.start.slice(0, 4)) - 1}-06-01`;
  const year = new Date().getFullYear();
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Salarié" required htmlFor="adj-emp" className="sm:col-span-2">
        <Select id="adj-emp" name="employeeId" required defaultValue="">
          <option value="" disabled>
            Choisir
          </option>
          {employees.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Type" required htmlFor="adj-type">
        <Select id="adj-type" name="leaveTypeId" required>
          {types.map((t) => (
            <option key={t.id} value={t.id}>
              {t.label}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Période" required htmlFor="adj-period" help="CP : période juin à mai. Autres : année civile.">
        <Select id="adj-period" name="periodStart" required>
          <option value={cur.start}>CP en cours (depuis le {fmtDate(cur.start)})</option>
          <option value={prevStart}>CP période précédente (depuis le {fmtDate(prevStart)})</option>
          <option value={`${year}-01-01`}>Année civile {year}</option>
          <option value={`${year - 1}-01-01`}>Année civile {year - 1}</option>
        </Select>
      </Field>
      <Field label="Ajustement en jours" required htmlFor="adj-val" help="Positif pour créditer, négatif pour débiter. Ex. 3,5">
        <Input id="adj-val" name="adjustment" inputMode="decimal" required />
      </Field>
      <Field label="Motif" htmlFor="adj-reason">
        <Input id="adj-reason" name="reason" placeholder="Reprise du logiciel précédent" />
      </Field>
    </div>
  );
}
