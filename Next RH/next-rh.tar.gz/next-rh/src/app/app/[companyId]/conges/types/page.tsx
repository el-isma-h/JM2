import { guardCompany } from "@/server/guard";
import { getLeaveTypes } from "@/server/hr/leave";
import { unitLabels } from "@/server/hr/calc";
import { saveLeaveTypeAction } from "@/server/actions/leave";
import { DialogForm } from "@/components/hr/action-form";
import { PageHeader, Panel, PanelHeader, EmptyState } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { formatNumber } from "@/lib/money";
import { Plus } from "@phosphor-icons/react/ssr";

type LeaveType = Awaited<ReturnType<typeof getLeaveTypes>>[number];

function TypeFields({ t }: { t?: LeaveType }) {
  const k = t?.id ?? "new";
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Code" required htmlFor={`code-${k}`} help="Transmis à la paie (ex. CP, RTT, MAL).">
        <Input id={`code-${k}`} name="code" defaultValue={t?.code} required maxLength={12} className="uppercase" />
      </Field>
      <Field label="Libellé" required htmlFor={`label-${k}`}>
        <Input id={`label-${k}`} name="label" defaultValue={t?.label} required />
      </Field>
      <Field label="Unité de décompte" htmlFor={`unit-${k}`}>
        <Select id={`unit-${k}`} name="unit" defaultValue={t?.unit ?? "jours_ouvres"}>
          {Object.entries(unitLabels).map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Acquisition mensuelle (jours)" htmlFor={`acc-${k}`} help="Laisser vide si le type n'a pas de solde. Congés payés : 2,08.">
        <Input id={`acc-${k}`} name="monthlyAccrual" inputMode="decimal" defaultValue={t?.monthlyAccrual ? String(Number(t.monthlyAccrual)).replace(".", ",") : ""} />
      </Field>
      <Field label="Ordre d'affichage" htmlFor={`order-${k}`}>
        <Input id={`order-${k}`} name="sortOrder" type="number" min={0} max={99} defaultValue={t?.sortOrder ?? 10} />
      </Field>
      <div className="space-y-2 sm:col-span-2">
        <Checkbox name="isPaid" defaultChecked={t?.isPaid ?? true} label="Absence rémunérée par l'employeur" />
        <Checkbox name="affectsPayroll" defaultChecked={t?.affectsPayroll ?? true} label="Effet sur la paie : transmise aux variables du mois à la validation" />
        <Checkbox name="requiresProof" defaultChecked={t?.requiresProof ?? false} label="Justificatif obligatoire avant validation" />
      </div>
    </div>
  );
}

export default async function LeaveTypesPage({ params }: { params: Promise<{ companyId: string }> }) {
  const { companyId } = await params;
  await guardCompany(companyId, `/app/${companyId}/conges/types`, "company.manage");
  const types = await getLeaveTypes(companyId);
  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Congés et absences", href: `/app/${companyId}/conges` }, { label: "Types d'absence" }]}
        title="Types d'absence"
        description="Le code de chaque type est transmis à la paie avec la variable d'absence. Modifier un type ne change pas les absences déjà validées."
        actions={
          <DialogForm trigger={<><Plus size={16} /> Nouveau type</>} title="Nouveau type d'absence" action={saveLeaveTypeAction} hidden={{ companyId }} submitLabel="Créer le type" wide>
            <TypeFields />
          </DialogForm>
        }
      />
      <Panel>
        <PanelHeader title={`${types.length} type(s) paramétré(s)`} />
        {types.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Code</Th>
                <Th>Libellé</Th>
                <Th>Décompte</Th>
                <Th num>Acquisition</Th>
                <Th>Paie</Th>
                <Th>Justificatif</Th>
                <Th className="text-right">Modifier</Th>
              </tr>
            </thead>
            <tbody>
              {types.map((t) => (
                <tr key={t.id}>
                  <Td>
                    <span className="num font-medium">{t.code}</span>
                  </Td>
                  <Td>
                    {t.label}
                    {!t.isPaid ? <span className="block text-[12px] text-ink-3">Non rémunérée par l&apos;employeur</span> : null}
                  </Td>
                  <Td>{unitLabels[t.unit] ?? t.unit}</Td>
                  <Td num>{t.monthlyAccrual ? `${formatNumber(t.monthlyAccrual, 2)} j / mois` : "-"}</Td>
                  <Td>{t.affectsPayroll ? <Badge tone="info">Transmise</Badge> : <span className="text-ink-3">Sans effet</span>}</Td>
                  <Td>{t.requiresProof ? <Badge tone="warn">Requis</Badge> : <span className="text-ink-3">Non</span>}</Td>
                  <Td className="text-right">
                    <DialogForm trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title={`Modifier : ${t.label}`} action={saveLeaveTypeAction} hidden={{ companyId, typeId: t.id }} submitLabel="Enregistrer" wide>
                      <TypeFields t={t} />
                    </DialogForm>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun type d'absence" description="Créez au moins les congés payés (code CP, 2,08 jours par mois)." />
        )}
      </Panel>
    </>
  );
}
