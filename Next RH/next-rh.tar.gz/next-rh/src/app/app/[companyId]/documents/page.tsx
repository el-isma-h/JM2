import Link from "next/link";
import { Files, FunnelSimple, LockSimple } from "@phosphor-icons/react/ssr";
import { guardCompany } from "@/server/guard";
import { employeesForFilter, listDocuments } from "@/server/documents/library";
import { canSeeRestricted, CATEGORY_LABELS, SALARY_CATEGORIES, VISIBILITY_LABELS } from "@/server/documents/visibility";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Table, Td, Th } from "@/components/ui/table";
import { UploadDialog } from "@/components/documents/upload-dialog";
import { DownloadButton } from "@/components/documents/download-button";
import { fmtDate } from "@/lib/dates";

function size(bytes: number) {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toLocaleString("fr-FR", { maximumFractionDigits: 0 })} Ko`;
  return `${(bytes / 1024 / 1024).toLocaleString("fr-FR", { maximumFractionDigits: 1 })} Mo`;
}

export default async function DocumentsPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<{ q?: string; categorie?: string; salarie?: string; du?: string; au?: string }>;
}) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/documents`;
  const ctx = await guardCompany(companyId, base, "documents.read");
  const restricted = canSeeRestricted(ctx.permissions);
  const canWrite = ctx.permissions.has("documents.write");
  const filters = { q: sp.q?.slice(0, 80), category: sp.categorie, employeeId: sp.salarie, from: sp.du, to: sp.au };
  const [rows, employees] = await Promise.all([listDocuments(ctx, filters), ctx.permissions.has("employees.read") ? employeesForFilter(companyId) : Promise.resolve([])]);
  const filtered = Boolean(filters.q || filters.category || filters.employeeId || filters.from || filters.to);

  const categories = Object.entries(CATEGORY_LABELS)
    .filter(([k]) => restricted || !(SALARY_CATEGORIES as readonly string[]).includes(k))
    .map(([value, label]) => ({ value, label }));
  const empOpts = employees.map((e) => ({ value: e.id, label: `${e.lastName} ${e.firstName}` }));

  return (
    <>
      <PageHeader
        title="Documents"
        description="Bibliothèque des documents de l'entreprise. Chaque téléchargement passe par un lien temporaire et chaque accès est journalisé."
        actions={canWrite ? <UploadDialog companyId={companyId} categories={categories} employees={empOpts} canRestricted={restricted} /> : null}
      />

      <form action={base} role="search" className="mb-4 grid gap-3 rounded-[var(--radius-md)] border border-line bg-bg-elev p-4 sm:grid-cols-2 lg:grid-cols-[minmax(0,2fr)_repeat(4,minmax(0,1fr))_auto] lg:items-end">
        <Field label="Recherche" htmlFor="q">
          <Input id="q" name="q" defaultValue={filters.q ?? ""} placeholder="Titre, fichier, salarié" />
        </Field>
        <Field label="Catégorie" htmlFor="categorie">
          <Select id="categorie" name="categorie" defaultValue={filters.category ?? ""}>
            <option value="">Toutes</option>
            {categories.map((c) => (
              <option key={c.value} value={c.value}>
                {c.label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Salarié" htmlFor="salarie">
          <Select id="salarie" name="salarie" defaultValue={filters.employeeId ?? ""} disabled={!empOpts.length}>
            <option value="">Tous</option>
            {empOpts.map((e) => (
              <option key={e.value} value={e.value}>
                {e.label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Déposé à partir de" htmlFor="du">
          <Input id="du" name="du" type="month" defaultValue={filters.from ?? ""} />
        </Field>
        <Field label="Jusqu'à" htmlFor="au">
          <Input id="au" name="au" type="month" defaultValue={filters.to ?? ""} />
        </Field>
        <div className="flex gap-2">
          <Button type="submit" variant="secondary">
            <FunnelSimple size={16} />
            Filtrer
          </Button>
          {filtered ? (
            <Button asChild variant="ghost">
              <Link href={base}>Effacer</Link>
            </Button>
          ) : null}
        </div>
      </form>

      {!restricted ? (
        <p className="mb-3 flex items-center gap-1.5 text-[12.5px] text-ink-2">
          <LockSimple size={14} />
          Les bulletins et documents restreints ne sont visibles qu&apos;avec l&apos;habilitation salaires ou validation de paie.
        </p>
      ) : null}

      <Panel>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Document</Th>
                <Th>Catégorie</Th>
                <Th>Salarié</Th>
                <Th>Visibilité</Th>
                <Th>Version</Th>
                <Th>Déposé le</Th>
                <Th>Conservation</Th>
                <Th num>Taille</Th>
                <Th>
                  <span className="sr-only">Actions</span>
                </Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ d, e }) => (
                <tr key={d.id}>
                  <Td className="max-w-[28ch]">
                    <Link href={`${base}/${d.id}`} className="font-medium text-ink hover:text-accent hover:underline">
                      {d.title}
                    </Link>
                    <div className="truncate text-[12px] text-ink-3">{d.fileName}</div>
                  </Td>
                  <Td>{CATEGORY_LABELS[d.category] ?? d.category}</Td>
                  <Td>{e?.id ? `${e.firstName} ${e.lastName}` : <span className="text-ink-3">Entreprise</span>}</Td>
                  <Td>
                    <Badge tone={d.visibility === "restricted" ? "warn" : d.visibility === "employee" ? "info" : "neutral"}>{VISIBILITY_LABELS[d.visibility].label}</Badge>
                  </Td>
                  <Td className="num">v{d.version}</Td>
                  <Td className="whitespace-nowrap">{fmtDate(d.createdAt)}</Td>
                  <Td className="whitespace-nowrap text-ink-2">{d.retentionUntil ? `jusqu'au ${fmtDate(d.retentionUntil)}` : "Non définie"}</Td>
                  <Td num>{size(d.sizeBytes)}</Td>
                  <Td className="text-right">
                    <DownloadButton companyId={companyId} documentId={d.id} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState
            icon={<Files size={28} />}
            title={filtered ? "Aucun document ne correspond aux filtres" : "Aucun document pour le moment"}
            description={
              filtered
                ? "Élargissez la période ou retirez un filtre."
                : "Déposez les contrats, justificatifs et documents d'entreprise, ou générez-les depuis l'atelier de rédaction."
            }
            action={
              filtered ? (
                <Button asChild variant="secondary">
                  <Link href={base}>Effacer les filtres</Link>
                </Button>
              ) : canWrite ? (
                <Button asChild variant="secondary">
                  <Link href={`/app/${companyId}/atelier`}>Ouvrir l&apos;atelier de rédaction</Link>
                </Button>
              ) : undefined
            }
          />
        )}
      </Panel>
      {rows.length >= 300 ? <p className="mt-2 text-[12.5px] text-ink-3">Affichage limité aux 300 documents les plus récents : affinez les filtres.</p> : null}
    </>
  );
}
