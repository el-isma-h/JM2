import Link from "next/link";
import { notFound } from "next/navigation";
import { guardCompany } from "@/server/guard";
import { audit } from "@/server/audit";
import { getDocumentDetail, retentionLabel } from "@/server/documents/library";
import { canSeeRestricted, CATEGORY_LABELS, SALARY_CATEGORIES, VISIBILITY_LABELS } from "@/server/documents/visibility";
import { KeyValue, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/ui/table";
import { DownloadButton } from "@/components/documents/download-button";
import { UploadDialog } from "@/components/documents/upload-dialog";
import { VisibilityForm } from "@/components/documents/visibility-form";
import { fmtDate, fmtDateTime } from "@/lib/dates";

const ACCESS_LABELS: Record<string, string> = {
  "document.download": "Téléchargement",
  "document.link_issued": "Lien de téléchargement émis",
  "document.view": "Consultation de la fiche",
  "document.upload": "Dépôt",
  "document.new_version": "Nouvelle version",
  "document.visibility": "Changement de visibilité",
};

export default async function DocumentDetailPage({ params }: { params: Promise<{ companyId: string; documentId: string }> }) {
  const { companyId, documentId } = await params;
  const base = `/app/${companyId}/documents`;
  const ctx = await guardCompany(companyId, `${base}/${documentId}`, "documents.read");
  const detail = await getDocumentDetail(ctx, documentId);
  if (!detail) notFound();
  const { doc, employee, versions, access, signatures, draft } = detail;
  await audit({ action: "document.view", userId: ctx.user.id, companyId, entityType: "document", entityId: doc.id });
  const restricted = canSeeRestricted(ctx.permissions);
  const canWrite = ctx.permissions.has("documents.write");
  const retention = retentionLabel(doc);
  const latest = versions[0]?.id === doc.id;
  const categories = Object.entries(CATEGORY_LABELS)
    .filter(([k]) => restricted || !(SALARY_CATEGORIES as readonly string[]).includes(k))
    .map(([value, label]) => ({ value, label }));

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Documents", href: base }, { label: doc.title }]}
        title={doc.title}
        description={`${CATEGORY_LABELS[doc.category] ?? doc.category}, version ${doc.version}${latest ? "" : " (une version plus récente existe)"}.`}
        actions={
          <>
            <DownloadButton companyId={companyId} documentId={doc.id} variant="secondary" />
            {canWrite && latest ? (
              <UploadDialog
                companyId={companyId}
                categories={categories}
                employees={[]}
                canRestricted={restricted}
                previous={{ id: doc.id, title: doc.title, category: doc.category, visibility: doc.visibility, employeeId: doc.employeeId }}
                triggerLabel="Déposer une nouvelle version"
              />
            ) : null}
          </>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)]">
        <Panel>
          <PanelHeader title="Informations" />
          <div className="space-y-5 px-5 py-4">
            <KeyValue
              items={[
                { k: "Fichier", v: doc.fileName },
                { k: "Type", v: doc.mimeType },
                { k: "Salarié", v: employee ? `${employee.firstName} ${employee.lastName}` : "Document d'entreprise" },
                { k: "Déposé le", v: fmtDateTime(doc.createdAt) },
                { k: "Origine", v: draft ? <Link className="text-accent hover:underline" href={`/app/${companyId}/atelier/${draft.id}`}>Atelier : {draft.title}</Link> : doc.sourceType === "upload" ? "Dépôt manuel" : (doc.sourceType ?? "-") },
                { k: "Empreinte SHA-256", v: <span className="num break-all text-[12px] text-ink-2">{doc.sha256 ?? "-"}</span> },
                {
                  k: "Conservation",
                  v: (
                    <span>
                      {retention.until ? `Jusqu'au ${fmtDate(retention.until)}` : "Non définie"}
                      <span className="block text-[12px] text-ink-3">Durée indicative : {retention.basis}.</span>
                    </span>
                  ),
                },
              ]}
            />
            <div>
              <p className="mb-1.5 text-[13px] font-medium text-ink">Visibilité</p>
              <p className="mb-2 text-[12.5px] text-ink-2">{VISIBILITY_LABELS[doc.visibility].help}</p>
              {canWrite ? (
                <VisibilityForm companyId={companyId} documentId={doc.id} current={doc.visibility} hasEmployee={Boolean(doc.employeeId)} canRestricted={restricted} />
              ) : (
                <Badge>{VISIBILITY_LABELS[doc.visibility].label}</Badge>
              )}
            </div>
          </div>
        </Panel>

        <div className="space-y-5">
          <Panel>
            <PanelHeader title="Versions" description="Chaque nouvelle version conserve les précédentes." />
            <Table>
              <thead>
                <tr>
                  <Th>Version</Th>
                  <Th>Fichier</Th>
                  <Th>Date</Th>
                  <Th>
                    <span className="sr-only">Télécharger</span>
                  </Th>
                </tr>
              </thead>
              <tbody>
                {versions.map((v) => (
                  <tr key={v.id}>
                    <Td className="num">
                      {v.id === doc.id ? <strong>v{v.version}</strong> : <Link href={`${base}/${v.id}`} className="hover:text-accent hover:underline">v{v.version}</Link>}
                    </Td>
                    <Td className="max-w-[26ch] truncate">{v.fileName}</Td>
                    <Td className="whitespace-nowrap">{fmtDateTime(v.createdAt)}</Td>
                    <Td className="text-right">
                      <DownloadButton companyId={companyId} documentId={v.id} />
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Panel>

          {signatures.length ? (
            <Panel>
              <PanelHeader title="Signature électronique" />
              <Table>
                <thead>
                  <tr>
                    <Th>Demandée le</Th>
                    <Th>Prestataire</Th>
                    <Th>Statut</Th>
                  </tr>
                </thead>
                <tbody>
                  {signatures.map((s) => (
                    <tr key={s.id}>
                      <Td>{fmtDateTime(s.createdAt)}</Td>
                      <Td>{s.provider ?? "Aucun"}</Td>
                      <Td>
                        <StatusBadge status={s.status} />
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Panel>
          ) : null}

          <Panel>
            <PanelHeader title="Journal des accès" description="Consultations, liens émis et téléchargements, toutes versions confondues." />
            {access.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Date</Th>
                    <Th>Personne</Th>
                    <Th>Action</Th>
                  </tr>
                </thead>
                <tbody>
                  {access.map(({ a, u }) => (
                    <tr key={a.id}>
                      <Td className="whitespace-nowrap">{fmtDateTime(a.createdAt)}</Td>
                      <Td>{u?.firstName ? `${u.firstName} ${u.lastName}` : "Système"}</Td>
                      <Td>{ACCESS_LABELS[a.action] ?? a.action}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <p className="px-5 py-4 text-[13px] text-ink-2">Aucun accès enregistré.</p>
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}
