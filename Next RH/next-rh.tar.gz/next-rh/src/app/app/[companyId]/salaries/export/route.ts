import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { audit } from "@/server/audit";
import { pickCurrentCompensation, pickCurrentContract } from "@/server/employees/queries";
import { categoryLabels, contractTypeLabels, salaryBasisLabels, statusLabels } from "@/components/employees/labels";

const esc = (v: unknown) => {
  const s = v === null || v === undefined ? "" : String(v);
  return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const frDate = (d: string | null) => (d ? d.split("-").reverse().join("/") : "");

/** Export CSV de la sélection (séparateur « ; »). Les montants ne sont inclus qu'avec l'habilitation « salaires ». */
export async function POST(req: Request, { params }: { params: Promise<{ companyId: string }> }) {
  const { companyId } = await params;
  let ctx;
  try {
    ctx = await requireCompany(companyId, "employees.read");
  } catch (e) {
    return new Response(authErrorMessage(e) ?? "Accès refusé", { status: 403 });
  }
  const origin = req.headers.get("origin");
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  if (origin && host && new URL(origin).host !== host) return new Response("Origine refusée", { status: 403 });
  const fd = await req.formData();
  const ids = fd
    .getAll("ids")
    .map(String)
    .filter((id) => /^[0-9a-f-]{36}$/.test(id))
    .slice(0, 5000);
  if (!ids.length) return new Response("Aucun salarié sélectionné", { status: 400 });
  const canSeeSalary = ctx.permissions.has("salaries.read");
  const emps = await db.select().from(schema.employees).where(and(eq(schema.employees.companyId, companyId), inArray(schema.employees.id, ids))).orderBy(schema.employees.lastName);
  const found = emps.map((e) => e.id);
  const [contracts, comps, establishments] = await Promise.all([
    found.length ? db.select().from(schema.contracts).where(inArray(schema.contracts.employeeId, found)) : [],
    canSeeSalary && found.length ? db.select().from(schema.compensations).where(inArray(schema.compensations.employeeId, found)) : [],
    db.select().from(schema.establishments).where(eq(schema.establishments.companyId, companyId)),
  ]);
  const est = new Map(establishments.map((e) => [e.id, e.name]));
  const header = ["Matricule", "Nom", "Prénom", "E-mail", "Téléphone", "Poste", "Service", "Établissement", "Statut", "Date d'entrée", "Date de sortie", "Contrat", "Catégorie", "Heures hebdomadaires"];
  if (canSeeSalary) header.push("Salaire de base brut", "Base");
  const lines = [header.map(esc).join(";")];
  for (const e of emps) {
    const c = pickCurrentContract(contracts.filter((x) => x.employeeId === e.id));
    const row: unknown[] = [
      e.employeeNumber,
      e.lastName,
      e.firstName,
      e.email,
      e.phone,
      e.jobTitle,
      e.department,
      e.establishmentId ? est.get(e.establishmentId) : "",
      statusLabels[e.status],
      frDate(e.hireDate),
      frDate(e.leaveDate),
      c ? contractTypeLabels[c.type] : "",
      c ? categoryLabels[c.category] : "",
      c ? c.weeklyHours.replace(".", ",") : "",
    ];
    if (canSeeSalary) {
      const p = pickCurrentCompensation(comps.filter((x) => x.employeeId === e.id));
      row.push(p ? (p.grossAmountCents / 100).toFixed(2).replace(".", ",") : "", p ? salaryBasisLabels[p.basis] : "");
    }
    lines.push(row.map(esc).join(";"));
  }
  await audit({ action: "employee.export", userId: ctx.user.id, companyId, entityType: "employee", after: { count: emps.length, withSalaries: canSeeSalary } });
  const stamp = new Date().toISOString().slice(0, 10);
  return new Response(`﻿${lines.join("\r\n")}\r\n`, {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="salaries-${stamp}.csv"`,
      "cache-control": "no-store",
    },
  });
}
