import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq, inArray } from "drizzle-orm";
import { LockKey } from "@phosphor-icons/react/dist/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { getEmployeeDossier } from "@/server/employees/queries";
import { decrypt, maskIban } from "@/lib/crypto";
import { maskNir } from "@/lib/validators";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { formatCents, formatNumber } from "@/lib/money";
import { cn } from "@/lib/utils";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { IdentityForm, JobForm } from "@/components/employees/forms";
import { AmendDialog, CompensationDialog, ExitDialog, NewContractDialog, SituationDialog } from "@/components/employees/dialogs";
import { EmployeeDocuments } from "@/components/employees/documents";
import { auditActionLabels, categoryLabels, contractTypeLabels, eventKindLabels, exitReasonLabel, salaryBasisLabels, workTimeModeLabels } from "@/components/employees/labels";

export const metadata: Metadata = { title: "Dossier salarié" };

const TABS = [
  { key: "identite", label: "Identité et coordonnées" },
  { key: "poste", label: "Poste et établissement" },
  { key: "contrat", label: "Contrat et avenants" },
  { key: "classification", label: "Classification" },
  { key: "temps", label: "Temps de travail" },
  { key: "remuneration", label: "Rémunération" },
  { key: "banque", label: "Coordonnées bancaires" },
  { key: "conges", label: "Congés et absences" },
  { key: "documents", label: "Documents" },
  { key: "evenements", label: "Événements" },
  { key: "historique", label: "Historique des actions" },
] as const;
type TabKey = (typeof TABS)[number]["key"];

const amendFieldLabels: Record<string, string> = {
  jobTitle: "Poste",
  classification: "Classification",
  coefficient: "Coefficient",
  category: "Catégorie",
  workTimeMode: "Organisation",
  weeklyHours: "Heures hebdomadaires",
  monthlyHours: "Heures mensuelles",
  annualDays: "Jours du forfait",
  endDate: "Fin du contrat",
  trialRenewedUntil: "Essai renouvelé jusqu'au",
  isPartTime: "Temps partiel",
  isExecutive: "Cadre",
};

function fmtChange(k: string, v: unknown) {
  if (v === null || v === undefined || v === "") return "vide";
  if (k === "category") return categoryLabels[String(v)] ?? String(v);
  if (k === "workTimeMode") return workTimeModeLabels[String(v)] ?? String(v);
  if (k === "endDate" || k === "trialRenewedUntil") return fmtDate(String(v));
  if (typeof v === "boolean") return v ? "oui" : "non";
  return String(v).replace(".", ",");
}

export default async function EmployeeDossierPage({ params, searchParams }: { params: Promise<{ companyId: string; employeeId: string }>; searchParams: Promise<{ onglet?: string; cree?: string }> }) {
  const { companyId, employeeId } = await params;
  const sp = await searchParams;
  const ctx = await guardCompany(companyId, `/app/${companyId}/salaries/${employeeId}`, "employees.read");
  const d = await getEmployeeDossier(companyId, employeeId);
  if (!d) notFound();
  const { employee: e, currentContract: cc, currentCompensation: comp } = d;
  const tab: TabKey = (TABS.find((t) => t.key === sp.onglet)?.key ?? "identite") as TabKey;
  const canWrite = ctx.permissions.has("employees.write");
  const canSeeSalary = ctx.permissions.has("salaries.read");
  const canSeeBank = ctx.permissions.has("employees.bank.read");
  const base = `/app/${companyId}/salaries/${employeeId}`;
  const name = `${e.firstName} ${e.lastName}`;
  const estName = d.establishments.find((x) => x.id === e.establishmentId)?.name ?? null;

  let maskedNir: string | null = null;
  if (e.nirEnc) {
    try {
      maskedNir = maskNir(decrypt(e.nirEnc));
    } catch {
      maskedNir = "illisible (à ressaisir)";
    }
  }

  const contractInfo = cc
    ? { id: cc.id, type: cc.type, jobTitle: cc.jobTitle, classification: cc.classification, coefficient: cc.coefficient, category: cc.category, workTimeMode: cc.workTimeMode, weeklyHours: cc.weeklyHours, annualDays: cc.annualDays, endDate: cc.endDate, trialRenewedUntil: cc.trialRenewedUntil }
    : null;
  const editable = canWrite && e.status !== "left";

  let content: React.ReactNode = null;
  if (tab === "identite") {
    const identity = {
      civility: e.civility,
      firstName: e.firstName,
      lastName: e.lastName,
      birthName: e.birthName,
      gender: e.gender,
      birthDate: e.birthDate,
      birthPlace: e.birthPlace,
      birthCountry: e.birthCountry,
      nationality: e.nationality,
      email: e.email,
      personalEmail: e.personalEmail,
      phone: e.phone,
      addressLine1: e.addressLine1,
      addressLine2: e.addressLine2,
      postalCode: e.postalCode,
      city: e.city,
    };
    content = <IdentityForm companyId={companyId} employeeId={employeeId} values={identity} maskedNir={maskedNir} readOnly={!canWrite} />;
  } else if (tab === "poste") {
    const managers = await db
      .select({ id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName })
      .from(schema.employees)
      .where(and(eq(schema.employees.companyId, companyId), inArray(schema.employees.status, ["active", "suspended"])))
      .orderBy(schema.employees.lastName);
    content = (
      <JobForm
        companyId={companyId}
        employeeId={employeeId}
        values={{ jobTitle: e.jobTitle, department: e.department, establishmentId: e.establishmentId, managerId: e.managerId, employeeNumber: e.employeeNumber }}
        establishments={d.establishments.map((x) => ({ value: x.id, label: x.name }))}
        managers={managers.filter((m) => m.id !== employeeId).map((m) => ({ value: m.id, label: `${m.lastName.toUpperCase()} ${m.firstName}` }))}
        readOnly={!canWrite}
      />
    );
  } else if (tab === "contrat") {
    content = (
      <div className="space-y-6">
        <Panel>
          <PanelHeader
            title="Contrats"
            description="Le contrat en cours est utilisé pour la paie. Les contrats précédents restent consultables."
            actions={
              editable ? (
                <>
                  {contractInfo ? <AmendDialog companyId={companyId} employeeId={employeeId} contract={contractInfo} scope="general" label="Avenant (poste, terme, essai)" /> : null}
                  <NewContractDialog companyId={companyId} employeeId={employeeId} />
                </>
              ) : null
            }
          />
          {d.contracts.length === 0 ? (
            <EmptyState title="Aucun contrat" description="Sans contrat, ce salarié bloque la première paie. Ajoutez-en un." />
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>Type</Th>
                  <Th>Poste</Th>
                  <Th>Début</Th>
                  <Th>Fin</Th>
                  <Th>Fin d&apos;essai</Th>
                  <Th>Catégorie</Th>
                  <Th num>Heures / semaine</Th>
                </tr>
              </thead>
              <tbody>
                {d.contracts.map((c) => (
                  <tr key={c.id}>
                    <Td>
                      <span className="font-medium">{contractTypeLabels[c.type]}</span> {c.id === cc?.id ? <Badge tone="ok">En cours</Badge> : null}
                      {c.cddReason ? <span className="block text-[12px] text-ink-3">{c.cddReason}</span> : null}
                    </Td>
                    <Td>{c.jobTitle ?? "-"}</Td>
                    <Td className="num">{fmtDate(c.startDate)}</Td>
                    <Td className="num">{fmtDate(c.endDate)}</Td>
                    <Td className="num">
                      {fmtDate(c.trialRenewedUntil ?? c.trialEndDate)}
                      {c.trialRenewedUntil ? <span className="block text-[12px] text-ink-3">renouvelée</span> : null}
                    </Td>
                    <Td>{categoryLabels[c.category]}</Td>
                    <Td num>{c.workTimeMode === "forfait_jours" ? `${c.annualDays ?? "-"} j/an` : formatNumber(c.weeklyHours)}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Panel>
        <Panel>
          <PanelHeader title="Avenants et modifications" description="Chaque modification est datée et garde la valeur précédente." />
          {d.amendments.length === 0 ? (
            <EmptyState title="Aucun avenant" description="Les modifications de poste, de classification ou de temps de travail apparaîtront ici." />
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>Date d&apos;effet</Th>
                  <Th>Objet</Th>
                  <Th>Changements</Th>
                </tr>
              </thead>
              <tbody>
                {d.amendments.map((a) => (
                  <tr key={a.id}>
                    <Td className="num whitespace-nowrap">{fmtDate(a.effectiveDate)}</Td>
                    <Td className="font-medium">{a.subject}</Td>
                    <Td className="text-ink-2">
                      {Object.entries((a.changes as Record<string, { from: unknown; to: unknown }>) ?? {})
                        .filter(([k]) => k !== "monthlyHours" && k !== "isExecutive")
                        .map(([k, v]) => `${amendFieldLabels[k] ?? k} : ${fmtChange(k, v.from)} vers ${fmtChange(k, v.to)}`)
                        .join(" ; ")}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Panel>
      </div>
    );
  } else if (tab === "classification") {
    content = (
      <Panel>
        <PanelHeader title="Classification et convention collective" description="La classification détermine le salaire minimum conventionnel applicable." actions={editable && contractInfo ? <AmendDialog companyId={companyId} employeeId={employeeId} contract={contractInfo} scope="classification" label="Modifier la classification" /> : null} />
        <div className="p-5">
          <KeyValue
            items={[
              { k: "Convention collective", v: ctx.company.idcc ? `${ctx.company.collectiveAgreement ?? "Convention"} (IDCC ${ctx.company.idcc})${ctx.company.idccConfirmed ? "" : ", non confirmée"}` : "Non renseignée" },
              { k: "Catégorie", v: cc ? categoryLabels[cc.category] : "-" },
              { k: "Classification", v: cc?.classification ?? "Non renseignée" },
              { k: "Coefficient", v: cc?.coefficient ? <span className="num">{cc.coefficient}</span> : "-" },
            ]}
          />
          {!cc ? <Notice tone="warn" className="mt-4">Aucun contrat en cours : ajoutez un contrat pour renseigner la classification.</Notice> : null}
        </div>
      </Panel>
    );
  } else if (tab === "temps") {
    content = (
      <Panel>
        <PanelHeader title="Temps de travail contractuel" description="La durée prévue au contrat. Les heures réellement effectuées se saisissent dans le module Temps de travail." actions={editable && contractInfo ? <AmendDialog companyId={companyId} employeeId={employeeId} contract={contractInfo} scope="time" label="Modifier le temps de travail" /> : null} />
        <div className="p-5">
          {cc ? (
            <KeyValue
              items={[
                { k: "Organisation", v: workTimeModeLabels[cc.workTimeMode] },
                ...(cc.workTimeMode === "forfait_jours"
                  ? [{ k: "Jours par an", v: <span className="num">{cc.annualDays ?? "-"}</span> }]
                  : [
                      { k: "Heures par semaine", v: <span className="num">{formatNumber(cc.weeklyHours)}</span> },
                      { k: "Heures par mois", v: <span className="num">{formatNumber(cc.monthlyHours)}</span> },
                    ]),
                { k: "Temps partiel", v: cc.isPartTime ? "Oui" : "Non" },
              ]}
            />
          ) : (
            <EmptyState title="Aucun contrat en cours" />
          )}
          <p className="mt-4 text-[13px] text-ink-2">
            Saisie des heures : <Link className="text-accent hover:underline" href={`/app/${companyId}/temps`}>module Temps de travail</Link>.
          </p>
        </div>
      </Panel>
    );
  } else if (tab === "remuneration") {
    content = canSeeSalary ? (
      <Panel>
        <PanelHeader
          title="Rémunération et historique"
          description="Chaque changement est une nouvelle ligne avec sa date d'effet et son motif. Rien n'est jamais écrasé."
          actions={editable ? <CompensationDialog companyId={companyId} employeeId={employeeId} currentLabel={comp ? `${formatCents(comp.grossAmountCents)} (${salaryBasisLabels[comp.basis].toLowerCase()})` : null} /> : null}
        />
        {d.compensations.length === 0 ? (
          <EmptyState title="Aucune rémunération" description="Sans rémunération, ce salarié bloque la première paie." />
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Date d&apos;effet</Th>
                <Th>Jusqu&apos;au</Th>
                <Th num>Montant brut</Th>
                <Th>Base</Th>
                <Th>Motif</Th>
                <Th num>Évolution</Th>
              </tr>
            </thead>
            <tbody>
              {d.compensations.map((c, i) => {
                const prev = d.compensations[i + 1];
                const delta = prev && prev.basis === c.basis ? ((c.grossAmountCents - prev.grossAmountCents) / prev.grossAmountCents) * 100 : null;
                return (
                  <tr key={c.id}>
                    <Td className="num whitespace-nowrap">
                      {fmtDate(c.effectiveDate)} {c.id === comp?.id ? <Badge tone="ok">En vigueur</Badge> : null}
                    </Td>
                    <Td className="num">{c.endDate ? fmtDate(c.endDate) : "-"}</Td>
                    <Td num className="font-medium">{formatCents(c.grossAmountCents)}</Td>
                    <Td>{salaryBasisLabels[c.basis]}</Td>
                    <Td className="text-ink-2">{c.reason ?? "-"}</Td>
                    <Td num className={cn(delta !== null && delta > 0 ? "text-ok-ink" : delta !== null && delta < 0 ? "text-danger-ink" : "text-ink-3")}>{delta === null ? "-" : `${delta > 0 ? "+" : ""}${formatNumber(delta, 1)} %`}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        )}
      </Panel>
    ) : (
      <Panel>
        <EmptyState icon={<LockKey size={28} />} title="Montants masqués" description="Votre rôle ne donne pas accès aux salaires. Demandez l'habilitation « salaires » à un administrateur de l'entreprise." />
      </Panel>
    );
  } else if (tab === "banque") {
    const primary = d.banks.find((b) => b.isPrimary) ?? d.banks[0];
    content = (
      <Panel>
        <PanelHeader title="Coordonnées bancaires" description="Accès restreint : l'IBAN complet n'est visible qu'avec l'habilitation dédiée et une vérification renforcée. Chaque consultation est journalisée." />
        <div className="p-5">
          <KeyValue
            items={[
              { k: "IBAN", v: primary ? <span className="num">{maskIban(primary.last4)}</span> : "Non renseigné" },
              { k: "Banque", v: primary?.bankName ?? "-" },
              { k: "Depuis le", v: fmtDate(primary?.validFrom) },
            ]}
          />
          <div className="mt-5">
            {canSeeBank ? (
              <Button asChild variant="secondary">
                <Link href={`${base}/banque`}>
                  <LockKey size={16} /> {primary ? "Afficher ou modifier l'IBAN" : "Saisir l'IBAN"}
                </Link>
              </Button>
            ) : (
              <Notice tone="info">Votre rôle ne permet pas de consulter les coordonnées bancaires complètes.</Notice>
            )}
          </div>
        </div>
      </Panel>
    );
  } else if (tab === "conges") {
    const [balances, requests] = await Promise.all([
      db
        .select({ b: schema.leaveBalances, t: schema.leaveTypes })
        .from(schema.leaveBalances)
        .innerJoin(schema.leaveTypes, eq(schema.leaveTypes.id, schema.leaveBalances.leaveTypeId))
        .where(and(eq(schema.leaveBalances.employeeId, employeeId), eq(schema.leaveTypes.companyId, companyId)))
        .orderBy(desc(schema.leaveBalances.periodStart)),
      db
        .select({ r: schema.leaveRequests, t: schema.leaveTypes })
        .from(schema.leaveRequests)
        .innerJoin(schema.leaveTypes, eq(schema.leaveTypes.id, schema.leaveRequests.leaveTypeId))
        .where(and(eq(schema.leaveRequests.employeeId, employeeId), eq(schema.leaveTypes.companyId, companyId)))
        .orderBy(desc(schema.leaveRequests.startDate))
        .limit(12),
    ]);
    content = (
      <div className="space-y-6">
        <Panel>
          <PanelHeader
            title="Soldes"
            actions={
              <Button asChild variant="secondary" size="sm">
                <Link href={`/app/${companyId}/conges`}>Ouvrir le module Congés</Link>
              </Button>
            }
          />
          {balances.length === 0 ? (
            <EmptyState title="Aucun solde enregistré" description="Les soldes se créent avec les acquisitions mensuelles ou par l'import de reprise." />
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>Type</Th>
                  <Th>Période</Th>
                  <Th num>Acquis</Th>
                  <Th num>Pris</Th>
                  <Th num>En attente</Th>
                  <Th num>Ajustement</Th>
                  <Th num>Solde</Th>
                </tr>
              </thead>
              <tbody>
                {balances.map(({ b, t }) => (
                  <tr key={b.id}>
                    <Td className="font-medium">{t.label}</Td>
                    <Td className="num whitespace-nowrap">
                      {fmtDate(b.periodStart)} au {fmtDate(b.periodEnd)}
                    </Td>
                    <Td num>{formatNumber(b.acquired)}</Td>
                    <Td num>{formatNumber(b.taken)}</Td>
                    <Td num>{formatNumber(b.pending)}</Td>
                    <Td num>{formatNumber(b.adjustment)}</Td>
                    <Td num className="font-medium">{formatNumber(Number(b.acquired) + Number(b.adjustment) - Number(b.taken))}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Panel>
        <Panel>
          <PanelHeader title="Dernières demandes" />
          {requests.length === 0 ? (
            <EmptyState title="Aucune demande" />
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>Type</Th>
                  <Th>Du</Th>
                  <Th>Au</Th>
                  <Th num>Durée</Th>
                  <Th>Statut</Th>
                </tr>
              </thead>
              <tbody>
                {requests.map(({ r, t }) => (
                  <tr key={r.id}>
                    <Td>{t.label}</Td>
                    <Td className="num">{fmtDate(r.startDate)}</Td>
                    <Td className="num">{fmtDate(r.endDate)}</Td>
                    <Td num>{formatNumber(r.duration, 1)} j</Td>
                    <Td>
                      <StatusBadge status={r.status} />
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Panel>
      </div>
    );
  } else if (tab === "documents") {
    const docs = ctx.permissions.has("documents.read")
      ? await db.select().from(schema.documents).where(and(eq(schema.documents.companyId, companyId), eq(schema.documents.employeeId, employeeId))).orderBy(desc(schema.documents.createdAt))
      : [];
    content = ctx.permissions.has("documents.read") ? (
      <EmployeeDocuments
        companyId={companyId}
        employeeId={employeeId}
        canWrite={ctx.permissions.has("documents.write")}
        docs={docs.map((x) => ({ id: x.id, title: x.title, category: x.category, visibility: x.visibility, createdAt: x.createdAt.toISOString(), sizeBytes: x.sizeBytes, version: x.version }))}
      />
    ) : (
      <Panel>
        <EmptyState title="Accès aux documents non autorisé" />
      </Panel>
    );
  } else if (tab === "evenements") {
    content = (
      <Panel>
        <PanelHeader title="Événements administratifs" description="Entrée, changements de situation, rémunération, sortie. Ceux qui ont un effet sur la paie sont repris dans le mois concerné." />
        {d.events.length === 0 ? (
          <EmptyState title="Aucun événement" />
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Date d&apos;effet</Th>
                <Th>Type</Th>
                <Th>Événement</Th>
                <Th>Effet sur la paie</Th>
                <Th>Saisi le</Th>
              </tr>
            </thead>
            <tbody>
              {d.events.map((ev) => (
                <tr key={ev.id}>
                  <Td className="num whitespace-nowrap">{fmtDate(ev.effectiveDate)}</Td>
                  <Td className="text-ink-2">{eventKindLabels[ev.kind] ?? ev.kind}</Td>
                  <Td>{canSeeSalary || ev.kind !== "remuneration" ? ev.title : "Rémunération modifiée"}</Td>
                  <Td>{ev.affectsPayroll ? ev.payrollProcessedPeriodId ? <Badge tone="ok">Pris en compte</Badge> : <Badge tone="warn">À reprendre en paie</Badge> : <span className="text-ink-3">Aucun</span>}</Td>
                  <Td className="num whitespace-nowrap text-ink-3">{fmtDateTime(ev.createdAt)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Panel>
    );
  } else if (tab === "historique") {
    const logs = await db
      .select({ l: schema.auditLogs, firstName: schema.users.firstName, lastName: schema.users.lastName })
      .from(schema.auditLogs)
      .leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId))
      .where(and(eq(schema.auditLogs.companyId, companyId), eq(schema.auditLogs.entityType, "employee"), eq(schema.auditLogs.entityId, employeeId)))
      .orderBy(desc(schema.auditLogs.createdAt))
      .limit(200);
    const hideAmounts = (action: string) => !canSeeSalary && (action === "compensation.create" || action === "employee.create");
    const summary = (v: unknown) => {
      if (!v || typeof v !== "object") return "";
      return Object.entries(v as Record<string, unknown>)
        .filter(([, x]) => x !== null && typeof x !== "object")
        .slice(0, 6)
        .map(([k, x]) => `${k} : ${String(x)}`)
        .join(", ");
    };
    content = (
      <Panel>
        <PanelHeader title="Historique des actions" description="Qui a fait quoi sur ce dossier, et quand. Journal non modifiable." />
        {logs.length === 0 ? (
          <EmptyState title="Aucune action enregistrée" />
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th>Par</Th>
                <Th>Action</Th>
                <Th>Détail</Th>
              </tr>
            </thead>
            <tbody>
              {logs.map(({ l, firstName, lastName }) => (
                <tr key={l.id}>
                  <Td className="num whitespace-nowrap">{fmtDateTime(l.createdAt)}</Td>
                  <Td>{firstName ? `${firstName} ${lastName}` : "Système"}</Td>
                  <Td className="font-medium">{auditActionLabels[l.action] ?? l.action}</Td>
                  <Td className="max-w-[420px] text-[12.5px] text-ink-2">
                    {hideAmounts(l.action) ? "Détail masqué (salaires)" : (
                      <>
                        {l.before ? <span className="block">Avant : {summary(l.before) || "-"}</span> : null}
                        {l.after ? <span className="block">Après : {summary(l.after) || "-"}</span> : null}
                      </>
                    )}
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Panel>
    );
  }

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Salariés", href: `/app/${companyId}/salaries` }, { label: name }]}
        title={
          <span className="inline-flex flex-wrap items-center gap-2">
            {e.lastName.toUpperCase()} {e.firstName} <StatusBadge status={e.status} />
          </span>
        }
        description={[e.jobTitle, estName, e.employeeNumber ? `matricule ${e.employeeNumber}` : null, e.hireDate ? `entré le ${fmtDate(e.hireDate)}` : null].filter(Boolean).join(", ")}
        actions={
          editable ? (
            <>
              {e.status === "active" || e.status === "suspended" ? <SituationDialog companyId={companyId} employeeId={employeeId} status={e.status} /> : null}
              {!e.leaveDate ? <ExitDialog companyId={companyId} employeeId={employeeId} name={name} /> : null}
            </>
          ) : null
        }
      />
      {sp.cree ? <Notice tone="ok" className="mb-4">Dossier créé. L&apos;entrée est enregistrée et sera reprise dans la paie du mois.</Notice> : null}
      {e.leaveDate ? (
        <Notice tone={e.status === "left" ? "info" : "warn"} className="mb-4">
          {e.status === "left" ? "Sorti" : "Sortie prévue"} le {fmtDate(e.leaveDate)} ({exitReasonLabel(e.leaveReason)}).{" "}
          <Link href={`/app/${companyId}/atelier?salarie=${employeeId}&motif=${e.leaveReason ?? ""}`} className="font-medium underline underline-offset-2">
            Préparer les documents de fin de contrat
          </Link>
        </Notice>
      ) : null}
      <nav aria-label="Rubriques du dossier" className="mb-5 -mx-1 flex gap-1 overflow-x-auto border-b border-line pb-px">
        {TABS.map((t) => (
          <Link
            key={t.key}
            href={`${base}?onglet=${t.key}`}
            scroll={false}
            aria-current={t.key === tab ? "page" : undefined}
            className={cn(
              "shrink-0 whitespace-nowrap border-b-2 px-3 py-2 text-[13.5px] transition-colors",
              t.key === tab ? "border-accent font-medium text-accent-strong" : "border-transparent text-ink-2 hover:text-ink",
            )}
          >
            {t.label}
          </Link>
        ))}
      </nav>
      <FadeIn key={tab}>{content}</FadeIn>
    </>
  );
}
