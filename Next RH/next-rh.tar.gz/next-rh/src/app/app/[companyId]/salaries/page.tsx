import type { Metadata } from "next";
import Link from "next/link";
import { Plus, UploadSimple } from "@phosphor-icons/react/dist/ssr";
import { guardCompany } from "@/server/guard";
import { listEmployees } from "@/server/employees/queries";
import { PageHeader } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EmployeeFilters, EmployeeTable } from "@/components/employees/list";

export const metadata: Metadata = { title: "Salariés" };

const anomalyLabels: Record<string, string> = {
  contrat: "Salariés actifs sans contrat",
  remuneration: "Salariés actifs sans rémunération",
  nir: "Salariés actifs sans N° de sécurité sociale",
  banque: "Salariés actifs sans IBAN",
};

export default async function EmployeesPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const ctx = await guardCompany(companyId, `/app/${companyId}/salaries`, "employees.read");
  const canSeeSalary = ctx.permissions.has("salaries.read");
  const canWrite = ctx.permissions.has("employees.write");
  const { rows, establishments, total } = await listEmployees(companyId, {
    q: sp.q,
    status: sp.statut,
    establishmentId: sp.etablissement,
    contractType: sp.contrat,
    category: sp.categorie,
    anomaly: sp.anomalie,
    sort: canSeeSalary || sp.tri !== "salaire" ? sp.tri : "nom",
  });
  const active = rows.filter((r) => r.status === "active").length;

  return (
    <>
      <PageHeader
        title="Salariés"
        description={sp.anomalie && anomalyLabels[sp.anomalie] ? anomalyLabels[sp.anomalie] : `${active} actif(s) affiché(s) sur ${total} dossier(s). Cliquez sur un nom pour ouvrir le dossier.`}
        actions={
          canWrite ? (
            <>
              {ctx.permissions.has("company.manage") ? (
                <Button asChild variant="secondary">
                  <Link href={`/app/${companyId}/onboarding?etape=reprise`}>
                    <UploadSimple size={16} /> Importer
                  </Link>
                </Button>
              ) : null}
              <Button asChild>
                <Link href={`/app/${companyId}/salaries/nouveau`}>
                  <Plus size={16} /> Ajouter un salarié
                </Link>
              </Button>
            </>
          ) : null
        }
      />
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <EmployeeFilters establishments={establishments.map((e) => ({ id: e.id, name: e.name }))} />
        {!canSeeSalary ? <Badge>Montants masqués : habilitation « salaires » requise</Badge> : null}
      </div>
      <EmployeeTable companyId={companyId} rows={rows} canSeeSalary={canSeeSalary} canWrite={canWrite} hasAny={total > 0} />
    </>
  );
}
