import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { audit } from "@/server/audit";
import { getEmployee } from "@/server/employees/queries";
import { decrypt } from "@/lib/crypto";
import { formatIbanGroups } from "@/lib/validators";
import { fmtDate } from "@/lib/dates";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Badge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/ui/table";
import { BankForm } from "@/components/employees/bank-form";

export const metadata: Metadata = { title: "Coordonnées bancaires" };

/** Sous-page à accès restreint : exige employees.bank.read et une session renforcée (guardCompany redirige vers /securite). */
export default async function BankPage({ params }: { params: Promise<{ companyId: string; employeeId: string }> }) {
  const { companyId, employeeId } = await params;
  const ctx = await guardCompany(companyId, `/app/${companyId}/salaries/${employeeId}/banque`, "employees.bank.read");
  const emp = await getEmployee(companyId, employeeId);
  if (!emp) notFound();
  const accounts = await db.select().from(schema.employeeBankAccounts).where(eq(schema.employeeBankAccounts.employeeId, employeeId)).orderBy(desc(schema.employeeBankAccounts.isPrimary), desc(schema.employeeBankAccounts.createdAt));
  const rows = accounts.map((a) => {
    let iban: string | null = null;
    try {
      iban = formatIbanGroups(decrypt(a.ibanEnc));
    } catch {
      iban = null;
    }
    return { ...a, iban };
  });
  await audit({ action: "bank.view", userId: ctx.user.id, companyId, tenantId: ctx.company.tenantId, entityType: "employee", entityId: employeeId, after: { accounts: rows.length } });
  const name = `${emp.firstName} ${emp.lastName}`;
  const canWrite = ctx.permissions.has("employees.write") && emp.status !== "left";

  return (
    <>
      <PageHeader
        breadcrumb={[
          { label: "Salariés", href: `/app/${companyId}/salaries` },
          { label: name, href: `/app/${companyId}/salaries/${employeeId}?onglet=banque` },
          { label: "Coordonnées bancaires" },
        ]}
        title="Coordonnées bancaires"
        description={`${name}. Cette consultation est enregistrée dans le journal d'audit.`}
      />
      <Notice tone="info" className="mb-5">
        Données sensibles : ne copiez pas l&apos;IBAN dans un e-mail ou un document non protégé. Il est utilisé uniquement pour le virement des salaires.
      </Notice>
      <div className="space-y-6">
        <Panel>
          <PanelHeader title="Comptes enregistrés" />
          {rows.length === 0 ? (
            <EmptyState title="Aucun IBAN enregistré" description="Sans IBAN, le salaire devra être versé par un autre moyen (chèque, virement manuel)." />
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>IBAN</Th>
                  <Th>BIC</Th>
                  <Th>Titulaire</Th>
                  <Th>Banque</Th>
                  <Th>Depuis le</Th>
                  <Th>Usage</Th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <Td className="num whitespace-nowrap">{r.iban ?? <span className="text-danger-ink">Illisible : à ressaisir</span>}</Td>
                    <Td className="num">{r.bic ?? "-"}</Td>
                    <Td>{r.holderName}</Td>
                    <Td>{r.bankName ?? "-"}</Td>
                    <Td className="num">{fmtDate(r.validFrom)}</Td>
                    <Td>{r.isPrimary ? <Badge tone="ok">Utilisé pour la paie</Badge> : <Badge>Ancien compte</Badge>}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Panel>
        {canWrite ? <BankForm companyId={companyId} employeeId={employeeId} holderName={name} /> : null}
      </div>
    </>
  );
}
