import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { PageHeader } from "@/components/ui/surface";
import { CreateEmployeeForm } from "@/components/employees/forms";

export const metadata: Metadata = { title: "Nouveau salarié" };

export default async function NewEmployeePage({ params }: { params: Promise<{ companyId: string }> }) {
  const { companyId } = await params;
  const ctx = await guardCompany(companyId, `/app/${companyId}/salaries/nouveau`, "employees.write");
  const establishments = await db
    .select({ id: schema.establishments.id, name: schema.establishments.name })
    .from(schema.establishments)
    .where(eq(schema.establishments.companyId, companyId))
    .orderBy(desc(schema.establishments.isHeadOffice), schema.establishments.name);
  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Salariés", href: `/app/${companyId}/salaries` }, { label: "Nouveau salarié" }]}
        title="Nouveau salarié"
        description="Les informations marquées d'un astérisque suffisent pour créer le dossier. Le reste peut être complété ensuite. L'entrée est datée et reprise dans la paie du mois."
      />
      <CreateEmployeeForm companyId={companyId} establishments={establishments.map((e) => ({ value: e.id, label: e.name }))} canSeeSalary={ctx.permissions.has("salaries.read")} />
    </>
  );
}
