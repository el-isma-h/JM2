import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { guardCompany } from "@/server/guard";
import { getImport, type ImportPreview } from "@/server/onboarding/import-service";
import { autoMap, IMPORT_SPECS, isImportKind, type Duplicate, type RowIssue } from "@/server/onboarding/import-spec";
import { PageHeader } from "@/components/ui/surface";
import { StatusBadge } from "@/components/ui/badge";
import { ImportWizard } from "@/components/onboarding/import-wizard";

export const metadata: Metadata = { title: "Reprise des données" };

export default async function ImportPage({ params }: { params: Promise<{ companyId: string; importId: string }> }) {
  const { companyId, importId } = await params;
  await guardCompany(companyId, `/app/${companyId}/onboarding/import/${importId}`, "company.manage", "employees.write");
  if (!/^[0-9a-f-]{36}$/.test(importId)) notFound();
  const imp = await getImport(companyId, importId);
  if (!imp || !isImportKind(imp.kind)) notFound();
  const spec = IMPORT_SPECS[imp.kind];
  const preview = imp.preview as ImportPreview;
  const auto = autoMap(imp.kind, preview.headers ?? []);
  const mapping = { ...auto, ...((imp.mapping as Record<string, string | null>) ?? {}) };

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Onboarding", href: `/app/${companyId}/onboarding?etape=reprise` }, { label: "Reprise des données" }]}
        title={spec.label}
        description={`Fichier « ${imp.fileName} ». Étapes : vérifier la correspondance des colonnes, lancer le contrôle, puis importer.`}
        actions={<StatusBadge status={imp.status} />}
      />
      <ImportWizard
        companyId={companyId}
        importId={importId}
        status={imp.status}
        kind={imp.kind}
        headers={preview.headers ?? []}
        sample={preview.sample ?? []}
        totalRows={preview.totalRows ?? 0}
        fields={spec.fields.map((f) => ({ key: f.key, label: f.label, required: Boolean(f.required), help: f.help, auto: Boolean(auto[f.key]) && auto[f.key] === mapping[f.key] }))}
        mapping={mapping}
        issues={(imp.errors as RowIssue[]) ?? []}
        duplicates={(imp.duplicates as Duplicate[]) ?? []}
        validated={imp.status === "validated" || imp.status === "mapped" || imp.status === "failed"}
        appliedCount={imp.appliedCount}
      />
    </>
  );
}
