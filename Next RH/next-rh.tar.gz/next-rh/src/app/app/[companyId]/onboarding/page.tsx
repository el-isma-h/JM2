import type { Metadata } from "next";
import { and, desc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { getOnboardingChecklist, checklistGroupLabels, type ChecklistItem } from "@/server/onboarding/checklist";
import { isMidYearTakeover, readPayrollSettings } from "@/server/onboarding/payroll-settings";
import { IMPORT_KINDS, IMPORT_SPECS } from "@/server/onboarding/import-spec";
import { importKindLabel } from "@/server/onboarding/import-service";
import { listManagers } from "@/server/employees/queries";
import { PageHeader, Notice } from "@/components/ui/surface";
import { Badge } from "@/components/ui/badge";
import { OnboardingShell } from "@/components/onboarding/shell";
import { normalizeStep, type OnboardingStepKey } from "@/components/onboarding/steps";
import { AgreementForm, CompanyIdentityForm } from "@/components/onboarding/company-form";
import { ContactsEditor, EstablishmentsEditor, OrganismsEditor } from "@/components/onboarding/editors";
import { CompanyDocuments } from "@/components/onboarding/company-documents";
import { PayrollSettingsForm } from "@/components/onboarding/payroll-form";
import { ImportPanel } from "@/components/onboarding/import-panel";
import { ChecklistView } from "@/components/onboarding/checklist-view";

export const metadata: Metadata = { title: "Onboarding" };

/** Statut d'une étape dérivé de la checklist serveur. */
function stepStatuses(items: ChecklistItem[]): Record<OnboardingStepKey, "ok" | "todo" | "blocking"> {
  const byKey = new Map(items.map((i) => [i.key, i.status]));
  const worst = (...keys: string[]) => {
    const st = keys.map((k) => byKey.get(k)).filter(Boolean);
    if (!st.length) return "todo" as const;
    if (st.includes("blocking")) return "blocking" as const;
    if (st.includes("todo")) return "todo" as const;
    return "ok" as const;
  };
  const blocking = items.some((i) => i.status === "blocking");
  return {
    entreprise: worst("siren", "identity"),
    etablissements: worst("establishments"),
    convention: worst("idcc"),
    interlocuteurs: worst("contacts", "kbis"),
    paie: worst("headcount", "atRate", "mobility", "paymentDay", "workTime", "mutuelle", "prevoyance", "validators", "preparers"),
    organismes: worst("organisms"),
    reprise: worst("employees", "contracts", "compensations", "carryovers"),
    verification: blocking ? "blocking" : "todo",
  };
}

export default async function OnboardingPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ etape?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const ctx = await guardCompany(companyId, `/app/${companyId}/onboarding`, "company.manage");
  const company = ctx.company;
  const step = normalizeStep(sp.etape ?? company.onboardingStep);
  const checklist = await getOnboardingChecklist(companyId);
  const statuses = stepStatuses(checklist.items);

  let content: React.ReactNode = null;
  if (step === "entreprise") {
    content = (
      <CompanyIdentityForm
        companyId={companyId}
        values={{
          legalName: company.legalName,
          tradeName: company.tradeName,
          siren: company.siren,
          legalForm: company.legalForm,
          activity: company.activity,
          apeCode: company.apeCode,
          addressLine1: company.addressLine1,
          addressLine2: company.addressLine2,
          postalCode: company.postalCode,
          city: company.city,
          headcount: company.headcount,
          idcc: company.idcc,
          collectiveAgreement: company.collectiveAgreement,
        }}
      />
    );
  } else if (step === "etablissements") {
    const rows = await db.select().from(schema.establishments).where(eq(schema.establishments.companyId, companyId)).orderBy(desc(schema.establishments.isHeadOffice), schema.establishments.name);
    content = (
      <div className="space-y-4">
        {!company.siren ? <Notice tone="warn">Renseignez d&apos;abord le SIREN à l&apos;étape Identité : chaque SIRET commence par lui.</Notice> : null}
        <EstablishmentsEditor companyId={companyId} siren={company.siren} rows={rows} />
      </div>
    );
  } else if (step === "convention") {
    content = <AgreementForm companyId={companyId} idcc={company.idcc} name={company.collectiveAgreement} confirmed={company.idccConfirmed} apeCode={company.apeCode} />;
  } else if (step === "interlocuteurs") {
    const [contacts, docs] = await Promise.all([
      db.select().from(schema.companyContacts).where(eq(schema.companyContacts.companyId, companyId)).orderBy(schema.companyContacts.fullName),
      db
        .select()
        .from(schema.documents)
        .where(and(eq(schema.documents.companyId, companyId), inArray(schema.documents.category, ["kbis", "entreprise", "justificatif"])))
        .orderBy(desc(schema.documents.createdAt)),
    ]);
    content = (
      <div className="space-y-6">
        <ContactsEditor companyId={companyId} rows={contacts} />
        <CompanyDocuments companyId={companyId} docs={docs.filter((d) => !d.employeeId).map((d) => ({ id: d.id, title: d.title, category: d.category, createdAt: d.createdAt.toISOString(), sizeBytes: d.sizeBytes }))} />
      </div>
    );
  } else if (step === "paie") {
    const [members, establishments] = await Promise.all([
      listManagers(companyId),
      db.select({ id: schema.establishments.id, name: schema.establishments.name, siret: schema.establishments.siret }).from(schema.establishments).where(eq(schema.establishments.companyId, companyId)),
    ]);
    content = <PayrollSettingsForm companyId={companyId} settings={readPayrollSettings(company.payrollSettings)} members={members} establishments={establishments} headcount={company.headcount} />;
  } else if (step === "organismes") {
    const rows = await db.select().from(schema.companyOrganisms).where(eq(schema.companyOrganisms.companyId, companyId)).orderBy(schema.companyOrganisms.kind);
    content = <OrganismsEditor companyId={companyId} rows={rows} />;
  } else if (step === "reprise") {
    const settings = readPayrollSettings(company.payrollSettings);
    const take = isMidYearTakeover(settings.firstPeriod);
    const imports = await db.select().from(schema.dataImports).where(eq(schema.dataImports.companyId, companyId)).orderBy(desc(schema.dataImports.createdAt)).limit(30);
    content = (
      <ImportPanel
        companyId={companyId}
        midYear={take?.midYear ? { year: take.year, month: take.month } : null}
        kinds={IMPORT_KINDS.map((k) => ({ kind: k, label: IMPORT_SPECS[k].label, description: IMPORT_SPECS[k].description, required: k === "carryovers" && Boolean(take?.midYear) }))}
        imports={imports.map((i) => ({
          id: i.id,
          kind: i.kind,
          kindLabel: importKindLabel(i.kind),
          fileName: i.fileName,
          status: i.status,
          totalRows: (i.preview as { totalRows?: number }).totalRows ?? 0,
          appliedCount: i.appliedCount,
          createdAt: i.createdAt.toISOString(),
        }))}
      />
    );
  } else {
    const groups = (Object.keys(checklistGroupLabels) as (keyof typeof checklistGroupLabels)[])
      .map((g) => ({ key: g, label: checklistGroupLabels[g], items: checklist.items.filter((i) => i.group === g) }))
      .filter((g) => g.items.length);
    content = <ChecklistView companyId={companyId} groups={groups} blockingCount={checklist.blockingCount} progress={checklist.progress} completedAt={company.onboardingCompletedAt?.toISOString() ?? null} />;
  }

  return (
    <>
      <PageHeader
        title="Mise en route de l'entreprise"
        description="Chaque information est enregistrée automatiquement : vous pouvez vous arrêter et reprendre plus tard à la même étape."
        actions={company.isDemo ? <Badge tone="warn">Démo</Badge> : company.onboardingCompletedAt ? <Badge tone="ok">Terminé</Badge> : null}
      />
      <OnboardingShell companyId={companyId} step={step} stepStatus={statuses} progress={checklist.progress}>
        {content}
      </OnboardingShell>
    </>
  );
}
