import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { buildTemplateCsv, isImportKind } from "@/server/onboarding/import-spec";

/** Modèle CSV d'exemple pour la reprise des données (séparateur « ; », UTF-8 avec BOM pour Excel). */
export async function GET(_req: Request, { params }: { params: Promise<{ companyId: string; kind: string }> }) {
  const { companyId, kind } = await params;
  try {
    await requireCompany(companyId, "company.manage");
  } catch (e) {
    return new Response(authErrorMessage(e) ?? "Accès refusé", { status: 403 });
  }
  if (!isImportKind(kind)) return new Response("Modèle inconnu", { status: 404 });
  const names: Record<string, string> = { employees: "salaries", compensations: "historique-remunerations", carryovers: "cumuls-annuels", leave_balances: "soldes-conges" };
  return new Response(buildTemplateCsv(kind), {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="modele-${names[kind]}.csv"`,
      "cache-control": "no-store",
    },
  });
}
