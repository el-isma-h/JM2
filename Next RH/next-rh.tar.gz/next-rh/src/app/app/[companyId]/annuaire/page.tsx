import { asc, eq } from "drizzle-orm";
import { AddressBook, MagnifyingGlass } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, listEmployees } from "@/server/hr/common";
import { Initials, LinkTabs } from "@/components/hr/bits";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Input } from "@/components/ui/field";
import { Button } from "@/components/ui/button";

type Emp = Awaited<ReturnType<typeof listEmployees>>[number];

function normalize(s: string) {
  return s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}

export default async function AnnuairePage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ q?: string; vue?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/annuaire`;
  await guardCompany(companyId, base, "employees.read");
  const view = sp.vue === "organigramme" ? "organigramme" : "trombinoscope";
  const q = (sp.q ?? "").trim().slice(0, 80);
  const [employees, establishments] = await Promise.all([
    listEmployees(companyId),
    db.select({ id: schema.establishments.id, name: schema.establishments.name }).from(schema.establishments).where(eq(schema.establishments.companyId, companyId)).orderBy(asc(schema.establishments.name)),
  ]);
  const estName = new Map(establishments.map((e) => [e.id, e.name]));
  const nq = normalize(q);
  const filtered = q
    ? employees.filter((e) => normalize([e.firstName, e.lastName, e.jobTitle, e.department, e.email, e.establishmentId ? estName.get(e.establishmentId) : ""].filter(Boolean).join(" ")).includes(nq))
    : employees;

  return (
    <>
      <PageHeader title="Annuaire" description={`${employees.length} personne(s). Coordonnées professionnelles et rattachement hiérarchique.`} />
      <LinkTabs
        label="Vues de l'annuaire"
        current={view}
        items={[
          { key: "trombinoscope", label: "Trombinoscope", href: base },
          { key: "organigramme", label: "Organigramme", href: `${base}?vue=organigramme` },
        ]}
      />
      {!employees.length ? (
        <Panel>
          <EmptyState icon={<AddressBook size={28} />} title="Annuaire vide" description="Les salariés apparaissent ici dès leur fiche créée." />
        </Panel>
      ) : view === "trombinoscope" ? (
        <>
          <form action={base} role="search" className="mb-4 flex max-w-lg gap-2">
            <label htmlFor="dir-q" className="sr-only">
              Rechercher
            </label>
            <div className="relative flex-1">
              <MagnifyingGlass size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-3" />
              <Input id="dir-q" name="q" defaultValue={q} placeholder="Nom, poste, service, établissement" className="pl-9" />
            </div>
            <Button type="submit" variant="secondary">
              Rechercher
            </Button>
          </form>
          <Panel>
            {filtered.length ? (
              <ul className="grid sm:grid-cols-2 xl:grid-cols-3">
                {filtered.map((e) => {
                  const manager = e.managerId ? employees.find((m) => m.id === e.managerId) : undefined;
                  return (
                    <li key={e.id} className="flex gap-3 border-b border-line px-5 py-4 sm:[&:nth-child(2n)]:border-l xl:[&:nth-child(2n)]:border-l-0 xl:[&:not(:nth-child(3n+1))]:border-l">
                      <Initials first={e.firstName} last={e.lastName} size="lg" />
                      <div className="min-w-0 text-[13px]">
                        <p className="truncate text-[14px] font-medium text-ink">{fullName(e)}</p>
                        <p className="truncate text-ink-2">{[e.jobTitle, e.department].filter(Boolean).join(", ") || "Poste non renseigné"}</p>
                        {e.establishmentId ? <p className="truncate text-ink-3">{estName.get(e.establishmentId)}</p> : null}
                        {e.email ? (
                          <a href={`mailto:${e.email}`} className="block truncate text-accent hover:underline">
                            {e.email}
                          </a>
                        ) : null}
                        {e.phone ? (
                          <a href={`tel:${e.phone.replace(/\s/g, "")}`} className="num block text-ink-2 hover:text-ink">
                            {e.phone}
                          </a>
                        ) : null}
                        {manager ? <p className="mt-1 text-[12px] text-ink-3">Responsable : {fullName(manager)}</p> : null}
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <EmptyState title="Aucun résultat" description={`Personne ne correspond à « ${q} ».`} />
            )}
          </Panel>
        </>
      ) : (
        <OrgChart employees={employees} />
      )}
    </>
  );
}

function OrgChart({ employees }: { employees: Emp[] }) {
  const ids = new Set(employees.map((e) => e.id));
  const children = new Map<string, Emp[]>();
  const roots: Emp[] = [];
  for (const e of employees) {
    if (e.managerId && ids.has(e.managerId) && e.managerId !== e.id) {
      const list = children.get(e.managerId) ?? [];
      list.push(e);
      children.set(e.managerId, list);
    } else roots.push(e);
  }
  // Personnes sans responsable mais ayant une équipe en tête, puis les autres.
  roots.sort((a, b) => (children.get(b.id)?.length ?? 0) - (children.get(a.id)?.length ?? 0));
  const leaders = roots.filter((r) => children.has(r.id));
  const loose = roots.filter((r) => !children.has(r.id));
  const seen = new Set<string>();

  return (
    <Panel>
      <div className="overflow-x-auto p-5">
        {leaders.length ? (
          <ul role="tree" aria-label="Organigramme hiérarchique" className="space-y-3">
            {leaders.map((r) => (
              <OrgNode key={r.id} e={r} depth={0} tree={children} seen={seen} />
            ))}
          </ul>
        ) : (
          <p className="text-[13.5px] text-ink-2">Aucun rattachement hiérarchique renseigné. Indiquez le responsable de chaque salarié dans sa fiche pour construire l&apos;organigramme.</p>
        )}
        {loose.length ? (
          <div className="mt-6 border-t border-line pt-4">
            <h2 className="mb-2 text-[13px] font-medium text-ink-2">Sans responsable renseigné ({loose.length})</h2>
            <ul className="flex flex-wrap gap-2">
              {loose.map((e) => (
                <li key={e.id} className="inline-flex items-center gap-2 rounded-[var(--radius-sm)] border border-line px-2.5 py-1.5 text-[13px]">
                  <Initials first={e.firstName} last={e.lastName} size="sm" />
                  {fullName(e)}
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
    </Panel>
  );
}

function OrgNode({ e, depth, tree, seen }: { e: Emp; depth: number; tree: Map<string, Emp[]>; seen: Set<string> }) {
  if (seen.has(e.id) || depth > 12) return null;
  seen.add(e.id);
  const team = (tree.get(e.id) ?? []).sort((a, b) => a.lastName.localeCompare(b.lastName));
  const card = (
    <span className="inline-flex min-w-0 items-center gap-2.5 rounded-[var(--radius-sm)] border border-line bg-bg-elev px-3 py-2">
      <Initials first={e.firstName} last={e.lastName} size="sm" />
      <span className="min-w-0">
        <span className="block truncate text-[13.5px] font-medium text-ink">{fullName(e)}</span>
        <span className="block truncate text-[12px] text-ink-3">{e.jobTitle ?? "Poste non renseigné"}</span>
      </span>
      {team.length ? <span className="num ml-2 rounded-none bg-bg-muted px-1.5 text-[11.5px] text-ink-2" aria-label={`${team.length} collaborateur(s) direct(s)`}>{team.length}</span> : null}
    </span>
  );
  return (
    <li role="treeitem" aria-expanded={team.length ? true : undefined} aria-selected={false} className="relative">
      {team.length ? (
        <details open={depth < 3}>
          <summary className="cursor-pointer list-none [&::-webkit-details-marker]:hidden">{card}</summary>
          <ul role="group" className="ml-5 mt-2 space-y-2 border-l border-line-strong pl-5">
            {team.map((c) => (
              <OrgNode key={c.id} e={c} depth={depth + 1} tree={tree} seen={seen} />
            ))}
          </ul>
        </details>
      ) : (
        card
      )}
    </li>
  );
}
