import { and, desc, eq, inArray } from "drizzle-orm";
import { Paperclip, Tray } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { listMembers, usersByIds } from "@/server/hr/common";
import { CORRECTABLE_FIELDS, hrRequestKindLabel, HR_REQUEST_KINDS, isCorrectable } from "@/server/hr/requests";
import { answerHrRequestAction, assignHrRequestAction, proofLinkAction } from "@/server/actions/requests";
import { ActionButton, ActionForm, SubmitButton } from "@/components/hr/action-form";
import { LinkTabs, Person } from "@/components/hr/bits";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Field, Select, Textarea } from "@/components/ui/field";
import { fmtDateTime } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";

export default async function DemandesPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ vue?: string; type?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/demandes`;
  const ctx = await guardCompany(companyId, base, "requests.approve");
  const view = sp.vue === "traitees" ? "traitees" : sp.vue === "miennes" ? "miennes" : "a-traiter";
  const kind = HR_REQUEST_KINDS.some((k) => k.value === sp.type) ? sp.type! : "";

  const rows = await db
    .select({ r: schema.hrRequests, e: schema.employees })
    .from(schema.hrRequests)
    .leftJoin(schema.employees, eq(schema.employees.id, schema.hrRequests.employeeId))
    .where(
      and(
        eq(schema.hrRequests.companyId, companyId),
        view === "traitees" ? inArray(schema.hrRequests.status, ["approved", "rejected", "cancelled"]) : eq(schema.hrRequests.status, "pending"),
        view === "miennes" ? eq(schema.hrRequests.assignedTo, ctx.user.id) : undefined,
        kind ? eq(schema.hrRequests.kind, kind as (typeof schema.hrRequestKindEnum.enumValues)[number]) : undefined,
      ),
    )
    .orderBy(desc(schema.hrRequests.createdAt))
    .limit(150);
  const [members, counts] = await Promise.all([
    listMembers(companyId),
    db.select({ status: schema.hrRequests.status, assignedTo: schema.hrRequests.assignedTo }).from(schema.hrRequests).where(and(eq(schema.hrRequests.companyId, companyId), eq(schema.hrRequests.status, "pending"))),
  ]);
  const names = await usersByIds(rows.map((x) => x.r.assignedTo));
  const tab = (v: string) => `${base}?${new URLSearchParams({ ...(v !== "a-traiter" ? { vue: v } : {}), ...(kind ? { type: kind } : {}) }).toString()}`;

  return (
    <>
      <PageHeader title="Demandes RH" description="Boîte de réception des demandes des salariés : correction d'informations, attestations, justificatifs, acomptes et questions. Une correction acceptée met à jour la fiche (coordonnées et adresse uniquement)." />
      <LinkTabs
        label="Filtre des demandes"
        current={view}
        items={[
          { key: "a-traiter", label: "À traiter", href: tab("a-traiter"), count: counts.length },
          { key: "miennes", label: "Assignées à moi", href: tab("miennes"), count: counts.filter((c) => c.assignedTo === ctx.user.id).length },
          { key: "traitees", label: "Traitées", href: tab("traitees") },
        ]}
      />
      <form className="mb-4 flex flex-wrap items-end gap-2" action={base}>
        {view !== "a-traiter" ? <input type="hidden" name="vue" value={view} /> : null}
        <Field label="Type de demande" htmlFor="rq-type" className="w-64">
          <Select id="rq-type" name="type" defaultValue={kind}>
            <option value="">Tous les types</option>
            {HR_REQUEST_KINDS.map((k) => (
              <option key={k.value} value={k.value}>
                {k.label}
              </option>
            ))}
          </Select>
        </Field>
        <button type="submit" className="h-9.5 rounded-[var(--radius-sm)] border border-line-strong bg-bg-elev px-4 text-sm font-medium text-ink hover:bg-bg-sunken">
          Filtrer
        </button>
      </form>

      {rows.length ? (
        <Panel>
          <ul className="divide-y divide-line">
            {rows.map(({ r, e }) => {
              const payload = (r.payload as Record<string, unknown>) ?? {};
              const changes = (payload.changes as Record<string, string> | undefined) ?? {};
              return (
                <li key={r.id}>
                  <details className="group" open={rows.length <= 3 && r.status === "pending"}>
                    <summary className="flex cursor-pointer list-none flex-wrap items-center gap-x-4 gap-y-2 px-5 py-3.5 hover:bg-bg-sunken">
                      <span className="w-[200px] shrink-0">{e ? <Person first={e.firstName} last={e.lastName} sub={e.jobTitle ?? undefined} /> : <span className="text-ink-3">Sans salarié</span>}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate font-medium text-ink">{r.title}</span>
                        <span className="block text-[12px] text-ink-3">
                          {hrRequestKindLabel(r.kind)}, reçue le {fmtDateTime(r.createdAt)}
                        </span>
                      </span>
                      <span className="text-[12.5px] text-ink-2">{r.assignedTo ? names.get(r.assignedTo) : <span className="text-ink-3">Non assignée</span>}</span>
                      <StatusBadge status={r.status} />
                    </summary>
                    <div className="grid gap-6 border-t border-line bg-bg-sunken/50 px-5 py-4 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
                      <div className="space-y-3 text-[13.5px]">
                        {r.body ? <p className="whitespace-pre-wrap text-ink">{r.body}</p> : <p className="text-ink-3">Pas de message.</p>}
                        {r.kind === "correction_informations" ? (
                          <table className="data-table text-[13px]">
                            <caption className="sr-only">Modifications demandées</caption>
                            <thead>
                              <tr>
                                <th scope="col">Champ</th>
                                <th scope="col">Actuel</th>
                                <th scope="col">Demandé</th>
                              </tr>
                            </thead>
                            <tbody>
                              {Object.entries(changes)
                                .filter(([k]) => isCorrectable(k))
                                .map(([k, v]) => (
                                  <tr key={k}>
                                    <td>{CORRECTABLE_FIELDS[k as keyof typeof CORRECTABLE_FIELDS].label}</td>
                                    <td className="text-ink-3">{(e as Record<string, unknown> | null)?.[k] ? String((e as Record<string, unknown>)[k]) : "-"}</td>
                                    <td className="font-medium text-ink">{v}</td>
                                  </tr>
                                ))}
                            </tbody>
                          </table>
                        ) : null}
                        {r.kind === "acompte" && typeof payload.amountCents === "number" ? (
                          <p>
                            Montant demandé : <span className="num font-medium">{formatCents(payload.amountCents)}</span>. Un acompte accepté est à saisir dans les variables de paie du mois.
                          </p>
                        ) : null}
                        {typeof payload.documentId === "string" ? <ActionButton action={proofLinkAction} hidden={{ companyId, documentId: payload.documentId }} label="Ouvrir le justificatif" variant="link" icon={<Paperclip size={14} />} /> : null}
                        {r.answer ? (
                          <div className={cn("rounded-[var(--radius-sm)] px-3 py-2", r.status === "rejected" ? "bg-danger-soft text-danger-ink" : "bg-ok-soft text-ok-ink")}>
                            <p className="text-[12px] font-medium">Réponse envoyée{r.decidedAt ? ` le ${fmtDateTime(r.decidedAt)}` : ""}</p>
                            <p className="whitespace-pre-wrap">{r.answer}</p>
                          </div>
                        ) : null}
                      </div>
                      {r.status === "pending" ? (
                        <div className="space-y-4">
                          <ActionForm action={assignHrRequestAction} hidden={{ companyId, requestId: r.id }} submitLabel="Assigner" submitVariant="secondary" resetOnSuccess={false} className="flex flex-wrap items-end gap-2 space-y-0">
                            <Field label="Assignée à" htmlFor={`as-${r.id}`} className="min-w-[200px] flex-1">
                              <Select id={`as-${r.id}`} name="assignedTo" defaultValue={r.assignedTo ?? ""}>
                                <option value="">Personne</option>
                                {members.map((m) => (
                                  <option key={m.id} value={m.id}>
                                    {m.firstName} {m.lastName}
                                  </option>
                                ))}
                              </Select>
                            </Field>
                          </ActionForm>
                          <ActionForm action={answerHrRequestAction} hidden={{ companyId, requestId: r.id }} submitLabel={null}>
                            <Field label="Réponse au salarié" htmlFor={`an-${r.id}`} help={r.kind === "correction_informations" ? "Accepter applique les modifications à la fiche salarié." : undefined}>
                              <Textarea id={`an-${r.id}`} name="answer" className="min-h-20" />
                            </Field>
                            <div className="flex flex-wrap gap-2">
                              <SubmitButton name="decision" value="approve">
                                {r.kind === "correction_informations" ? "Accepter et mettre à jour la fiche" : "Marquer traitée"}
                              </SubmitButton>
                              <SubmitButton name="decision" value="reject" variant="secondary">
                                Refuser
                              </SubmitButton>
                            </div>
                          </ActionForm>
                        </div>
                      ) : (
                        <div className="text-[13px] text-ink-2">
                          <Badge tone="neutral">Demande close</Badge>
                        </div>
                      )}
                    </div>
                  </details>
                </li>
              );
            })}
          </ul>
        </Panel>
      ) : (
        <Panel>
          <EmptyState icon={<Tray size={28} />} title={view === "traitees" ? "Aucune demande traitée" : "Aucune demande à traiter"} description="Les salariés envoient leurs demandes depuis leur espace personnel." />
        </Panel>
      )}
    </>
  );
}
