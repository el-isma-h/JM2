import Link from "next/link";
import { and, asc, count, desc, eq, gte, inArray, lte, ne } from "drizzle-orm";
import { ArrowRight, CheckCircle, WarningCircle } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { audit } from "@/server/audit";
import { employeeIdsOf, todayIso } from "@/server/hr/common";
import { addDaysIso, daysUntil } from "@/server/hr/calc";
import { syncDeadlines, deadlineKindLabels } from "@/server/hr/deadlines";
import { buildSocialReport } from "@/server/hr/reports";
import { getOnboardingChecklist } from "@/server/onboarding/checklist";
import { AssistantBar } from "@/components/assistant/assistant-bar";
import { CountUpNumber } from "@/components/dashboard/count";
import { PayrollSteps } from "@/components/dashboard/payroll-steps";
import { DueIn } from "@/components/hr/bits";
import { FadeIn } from "@/components/ui/motion";
import { Panel, PanelHeader, EmptyState } from "@/components/ui/surface";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { fmtDate, monthLabel, deMonth } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";

export default async function CompanyDashboard({ params }: { params: Promise<{ companyId: string }> }) {
  const { companyId } = await params;
  const base = `/app/${companyId}`;
  const ctx = await guardCompany(companyId, base);
  const can = (p: Parameters<typeof ctx.permissions.has>[0]) => ctx.permissions.has(p);
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const today = todayIso();
  const empIds = await employeeIdsOf(companyId);
  const name = ctx.company.tradeName ?? ctx.company.legalName;

  // Paie du mois
  const [period] = can("payroll.prepare")
    ? await db
        .select()
        .from(schema.payrollPeriods)
        .where(and(eq(schema.payrollPeriods.companyId, companyId), eq(schema.payrollPeriods.year, year), eq(schema.payrollPeriods.month, month)))
        .limit(1)
    : [];
  const companyPeriods = can("payroll.prepare") ? await db.select({ id: schema.payrollPeriods.id }).from(schema.payrollPeriods).where(eq(schema.payrollPeriods.companyId, companyId)) : [];
  const periodIds = companyPeriods.map((p) => p.id);
  const [anomalies, slipsToCheck, variablesCount] = await Promise.all([
    periodIds.length
      ? db
          .select({ id: schema.payrollAnomalies.id, severity: schema.payrollAnomalies.severity, title: schema.payrollAnomalies.title, periodId: schema.payrollAnomalies.periodId })
          .from(schema.payrollAnomalies)
          .where(and(inArray(schema.payrollAnomalies.periodId, periodIds), eq(schema.payrollAnomalies.status, "open")))
          .orderBy(asc(schema.payrollAnomalies.severity), desc(schema.payrollAnomalies.createdAt))
      : [],
    period ? db.select({ status: schema.payslips.status }).from(schema.payslips).where(and(eq(schema.payslips.periodId, period.id), inArray(schema.payslips.status, ["computed", "blocked"]))) : [],
    period ? db.select({ n: count() }).from(schema.payrollVariables).where(eq(schema.payrollVariables.periodId, period.id)) : [],
  ]);
  const blocking = anomalies.filter((a) => a.severity === "blocking").length;
  const warnings = anomalies.filter((a) => a.severity === "warning").length;
  const infos = anomalies.filter((a) => a.severity === "info").length;
  const blockedSlips = slipsToCheck.filter((s) => s.status === "blocked").length;
  const computedSlips = slipsToCheck.filter((s) => s.status === "computed").length;

  // Demandes en attente
  const canApprove = can("requests.approve");
  const [pendingLeaves, pendingExpenses, pendingRemote, pendingHr, pendingSheets] = canApprove && empIds.length
    ? await Promise.all([
        db.select({ n: count() }).from(schema.leaveRequests).where(and(inArray(schema.leaveRequests.employeeId, empIds), eq(schema.leaveRequests.status, "pending"))),
        db.select({ n: count() }).from(schema.expenseReports).where(and(inArray(schema.expenseReports.employeeId, empIds), eq(schema.expenseReports.status, "pending"))),
        db.select({ n: count() }).from(schema.remoteWorkRequests).where(and(inArray(schema.remoteWorkRequests.employeeId, empIds), eq(schema.remoteWorkRequests.status, "pending"), gte(schema.remoteWorkRequests.date, today))),
        db.select({ n: count() }).from(schema.hrRequests).where(and(eq(schema.hrRequests.companyId, companyId), eq(schema.hrRequests.status, "pending"))),
        db.select({ n: count() }).from(schema.timesheets).where(and(inArray(schema.timesheets.employeeId, empIds), eq(schema.timesheets.status, "pending"))),
      ])
    : [[{ n: 0 }], [{ n: 0 }], [{ n: 0 }], [{ n: 0 }], [{ n: 0 }]];
  const pendingItems = [
    { label: "Congés et absences", n: pendingLeaves[0]?.n ?? 0, href: `${base}/conges?vue=demandes` },
    { label: "Notes de frais", n: pendingExpenses[0]?.n ?? 0, href: `${base}/frais` },
    { label: "Jours de télétravail", n: pendingRemote[0]?.n ?? 0, href: `${base}/teletravail` },
    { label: "Feuilles de temps", n: pendingSheets[0]?.n ?? 0, href: `${base}/temps` },
    { label: "Demandes RH", n: pendingHr[0]?.n ?? 0, href: `${base}/demandes` },
  ];
  const pendingTotal = pendingItems.reduce((s, i) => s + i.n, 0);

  // Échéances
  let deadlines: (typeof schema.deadlines.$inferSelect)[] = [];
  if (can("employees.read")) {
    await syncDeadlines(companyId);
    deadlines = await db
      .select()
      .from(schema.deadlines)
      .where(and(eq(schema.deadlines.companyId, companyId), ne(schema.deadlines.status, "done"), lte(schema.deadlines.dueDate, addDaysIso(today, 30))))
      .orderBy(asc(schema.deadlines.dueDate))
      .limit(7);
  }

  // Effectif et masse salariale
  const withPayroll = can("salaries.read");
  const report = can("employees.read") || can("reports.read") ? await buildSocialReport(companyId, { withPayroll }) : null;
  if (withPayroll && report?.payroll) await audit({ action: "dashboard.payroll_view", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id });
  const mass = report?.payroll?.months ?? [];
  const massNow = mass.at(-1)?.grossCents ?? 0;
  const massPrev = mass.at(-2)?.grossCents ?? 0;
  const monthKey = `${year}-${String(month).padStart(2, "0")}`;
  const entriesThisMonth = report?.movements.find((m) => m.key === monthKey)?.entries ?? 0;
  const exitsThisMonth = report?.movements.find((m) => m.key === monthKey)?.exits ?? 0;

  // Documents à valider
  const drafts = can("documents.read")
    ? await db
        .select({ id: schema.documentDrafts.id, title: schema.documentDrafts.title, updatedAt: schema.documentDrafts.updatedAt })
        .from(schema.documentDrafts)
        .where(and(eq(schema.documentDrafts.companyId, companyId), eq(schema.documentDrafts.status, "in_review")))
        .orderBy(desc(schema.documentDrafts.updatedAt))
        .limit(5)
    : [];

  // Mise en route
  const onboarding = !ctx.company.onboardingCompletedAt && can("company.manage") ? await getOnboardingChecklist(companyId) : null;
  const todo = onboarding?.items.filter((i) => i.status !== "ok").sort((a, b) => (a.status === b.status ? 0 : a.status === "blocking" ? -1 : 1)) ?? [];

  return (
    <div className="space-y-6">
      <AssistantBar companyId={companyId} />

      <FadeIn>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-[22px] font-semibold tracking-tight text-ink">Bonjour {ctx.user.firstName}</h1>
            <p className="mt-1 text-[13.5px] text-ink-2">
              {name}, <span className="capitalize">{monthLabel(year, month)}</span>.{" "}
              {pendingTotal ? `${pendingTotal} demande(s) attendent une décision.` : canApprove ? "Aucune demande en attente." : ""}
            </p>
          </div>
          {ctx.company.isDemo ? <Badge tone="warn">Démonstration : aucune déclaration, aucun paiement, aucun e-mail ne part</Badge> : null}
        </div>
      </FadeIn>

      {onboarding && todo.length ? (
        <FadeIn delay={0.03}>
          <Panel>
            <PanelHeader
              title="Mise en route"
              description={`${onboarding.progress} % terminé${onboarding.blockingCount ? `, ${onboarding.blockingCount} point(s) bloquent la première paie` : ""}.`}
              actions={
                <Button asChild size="sm">
                  <Link href={`${base}/onboarding`}>
                    Continuer <ArrowRight size={14} />
                  </Link>
                </Button>
              }
            />
            <ul className="grid divide-y divide-line md:grid-cols-2 md:divide-y-0">
              {todo.slice(0, 6).map((i) => (
                <li key={i.key} className="md:border-b md:border-line md:[&:nth-child(2n)]:border-l">
                  <Link href={i.href} className="flex items-start gap-3 px-5 py-3 hover:bg-bg-sunken">
                    <WarningCircle size={18} weight={i.status === "blocking" ? "fill" : "regular"} className={cn("mt-0.5 shrink-0", i.status === "blocking" ? "text-danger" : "text-warn")} />
                    <span className="min-w-0">
                      <span className="block text-[13.5px] font-medium text-ink">{i.label}</span>
                      <span className="line-clamp-2 block text-[12.5px] text-ink-2">{i.help}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
            {todo.length > 6 ? <p className="px-5 py-2.5 text-[12.5px] text-ink-3">Et {todo.length - 6} autre(s) point(s).</p> : null}
          </Panel>
        </FadeIn>
      ) : null}

      <FadeIn delay={0.06} className="grid gap-6 xl:grid-cols-[minmax(0,1.7fr)_minmax(0,1fr)]">
        {can("payroll.prepare") ? (
          <Panel>
            <PanelHeader
              title={<span>Paie {deMonth(monthLabel(year, month))}</span>}
              description={period ? `Période ${period.paymentDate ? `payée le ${fmtDate(period.paymentDate)}` : "ouverte"}.` : "La période n'est pas encore ouverte : elle le sera à la première variable ou depuis la page Paie."}
              actions={
                <>
                  {period ? <StatusBadge status={period.status} /> : null}
                  <Button asChild size="sm">
                    <Link href={`${base}/paie`}>
                      Ouvrir la paie <ArrowRight size={14} />
                    </Link>
                  </Button>
                </>
              }
            />
            <div className="px-5 py-5">
              <PayrollSteps status={period?.status ?? null} />
            </div>
            <dl className="grid grid-cols-2 border-t border-line sm:grid-cols-4 sm:divide-x sm:divide-line">
              <div className="px-5 py-4">
                <dt className="text-[12.5px] text-ink-2">Anomalies bloquantes</dt>
                <dd className={cn("mt-0.5 text-[22px] font-medium", blocking ? "text-danger-ink" : "text-ink")}>
                  <CountUpNumber value={blocking} />
                </dd>
              </div>
              <div className="px-5 py-4">
                <dt className="text-[12.5px] text-ink-2">Points à vérifier</dt>
                <dd className="mt-0.5 text-[22px] font-medium text-ink">
                  <CountUpNumber value={warnings + infos} />
                </dd>
                {infos ? <dd className="text-[12px] text-ink-3">dont {infos} information(s)</dd> : null}
              </div>
              <div className="px-5 py-4">
                <dt className="text-[12.5px] text-ink-2">Bulletins à contrôler</dt>
                <dd className="mt-0.5 text-[22px] font-medium text-ink">
                  <CountUpNumber value={computedSlips + blockedSlips} />
                </dd>
                {blockedSlips ? <dd className="text-[12px] text-danger-ink">{blockedSlips} bloqué(s)</dd> : null}
              </div>
              <div className="px-5 py-4">
                <dt className="text-[12.5px] text-ink-2">Variables du mois</dt>
                <dd className="mt-0.5 text-[22px] font-medium text-ink">
                  <CountUpNumber value={variablesCount[0]?.n ?? 0} />
                </dd>
                <dd className="text-[12px] text-ink-3">Absences, heures, frais, primes</dd>
              </div>
            </dl>
            {anomalies.length ? (
              <ul className="border-t border-line">
                {anomalies.slice(0, 4).map((a) => (
                  <li key={a.id} className="flex items-center gap-3 border-b border-line px-5 py-2.5 text-[13px] last:border-b-0">
                    <StatusBadge status={a.severity} />
                    <span className="min-w-0 flex-1 truncate text-ink">{a.title}</span>
                  </li>
                ))}
              </ul>
            ) : null}
          </Panel>
        ) : (
          <Panel>
            <PanelHeader title="Effectif" />
            <div className="px-5 py-5 text-[13.5px] text-ink-2">La préparation de la paie est réservée aux gestionnaires de paie.</div>
          </Panel>
        )}

        <Panel className="self-start">
          <PanelHeader title="À traiter" description={canApprove ? undefined : "Vous ne validez pas les demandes dans cette entreprise."} />
          {canApprove ? (
            <ul>
              {pendingItems.map((i) => (
                <li key={i.label} className="border-b border-line last:border-b-0">
                  <Link href={i.href} className="flex items-center justify-between gap-3 px-5 py-3 text-[13.5px] hover:bg-bg-sunken">
                    <span className={cn(i.n ? "text-ink" : "text-ink-3")}>{i.label}</span>
                    {i.n ? <span className="num rounded-none bg-warn-soft px-2 py-0.5 text-[12.5px] font-medium text-warn-ink">{i.n}</span> : <CheckCircle size={16} className="text-ok" aria-label="Rien en attente" />}
                  </Link>
                </li>
              ))}
            </ul>
          ) : null}
          {drafts.length ? (
            <div className="border-t border-line">
              <p className="px-5 pt-3 text-[12.5px] font-medium text-ink-2">Documents en relecture</p>
              <ul>
                {drafts.map((d) => (
                  <li key={d.id}>
                    <Link href={`${base}/atelier`} className="flex items-center justify-between gap-3 px-5 py-2 text-[13px] hover:bg-bg-sunken">
                      <span className="truncate text-ink">{d.title}</span>
                      <span className="shrink-0 text-[12px] text-ink-3">{fmtDate(d.updatedAt)}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ) : can("documents.read") ? (
            <p className="border-t border-line px-5 py-3 text-[12.5px] text-ink-3">Aucun document en attente de relecture.</p>
          ) : null}
        </Panel>
      </FadeIn>

      <FadeIn delay={0.09} className="grid gap-6 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        {can("employees.read") ? (
          <Panel>
            <PanelHeader
              title="Échéances des 30 prochains jours"
              actions={
                <Button asChild variant="ghost" size="sm">
                  <Link href={`${base}/echeances`}>Tout voir</Link>
                </Button>
              }
            />
            {deadlines.length ? (
              <ul>
                {deadlines.map((d) => (
                  <li key={d.id} className="flex items-center gap-3 border-b border-line px-5 py-2.5 text-[13px] last:border-b-0">
                    <span className="num w-[74px] shrink-0 text-ink-2">{fmtDate(d.dueDate, "d MMM")}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-ink">{d.title}</span>
                      <span className="block text-[11.5px] text-ink-3">{deadlineKindLabels[d.kind] ?? d.kind}</span>
                    </span>
                    <DueIn days={daysUntil(d.dueDate, today)} />
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState className="py-8" title="Rien dans les 30 jours" description="Fins de période d'essai, fins de CDD et habilitations apparaîtront ici." />
            )}
          </Panel>
        ) : null}

        {report ? (
          <Panel className="self-start">
            <PanelHeader
              title="Effectif"
              actions={
                can("reports.read") ? (
                  <Button asChild variant="ghost" size="sm">
                    <Link href={`${base}/rapports`}>Rapports</Link>
                  </Button>
                ) : null
              }
            />
            <div className="grid grid-cols-2 gap-x-6 gap-y-4 px-5 py-4">
              <div>
                <p className="text-[12.5px] text-ink-2">Salariés actifs</p>
                <p className="text-[26px] font-medium leading-tight text-ink">
                  <CountUpNumber value={report.headcount} />
                </p>
                <p className="text-[12px] text-ink-3">
                  {entriesThisMonth || exitsThisMonth ? `Ce mois : +${entriesThisMonth} / -${exitsThisMonth}` : "Aucun mouvement ce mois"}
                </p>
              </div>
              {withPayroll ? (
                <div>
                  <p className="text-[12.5px] text-ink-2">Masse salariale brute du mois</p>
                  <p className="text-[20px] font-medium leading-tight text-ink">
                    <CountUpNumber value={massNow} cents />
                  </p>
                  <p className="text-[12px] text-ink-3">
                    {report.payroll?.source === "payslips" ? "D'après les bulletins" : "Estimée depuis les contrats"}
                    {massPrev ? `, ${massNow >= massPrev ? "+" : ""}${formatCents(massNow - massPrev)} sur un mois` : ""}
                  </p>
                </div>
              ) : (
                <div>
                  <p className="text-[12.5px] text-ink-2">Ancienneté moyenne</p>
                  <p className="text-[20px] font-medium leading-tight text-ink">{report.avgSeniority === null ? "-" : <CountUpNumber value={report.avgSeniority} digits={1} suffix=" ans" />}</p>
                </div>
              )}
              <div>
                <p className="text-[12.5px] text-ink-2">Absentéisme sur 12 mois</p>
                <p className="text-[16px] font-medium text-ink">{report.absenteeism === null ? "-" : <CountUpNumber value={report.absenteeism} digits={2} suffix=" %" />}</p>
              </div>
              <div>
                <p className="text-[12.5px] text-ink-2">Fiches en préparation</p>
                <p className="text-[16px] font-medium text-ink">
                  {report.drafts ? (
                    <Link href={`${base}/salaries`} className="hover:underline">
                      <CountUpNumber value={report.drafts} />
                    </Link>
                  ) : (
                    <CountUpNumber value={0} />
                  )}
                </p>
              </div>
            </div>
          </Panel>
        ) : null}
      </FadeIn>
    </div>
  );
}
