import Link from "next/link";
import { desc, inArray } from "drizzle-orm";
import { ArrowsLeftRight, CheckSquare, Plus, Square } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, listEmployees, todayIso } from "@/server/hr/common";
import { daysUntil } from "@/server/hr/calc";
import { kindLabels, ownerLabels, targetDateLabels, type WorkflowKind, type WorkflowTask } from "@/server/hr/lifecycle";
import { addWorkflowTaskAction, cancelWorkflowAction, createWorkflowAction, toggleWorkflowTaskAction } from "@/server/actions/lifecycle";
import { ActionButton, ActionForm, DialogForm } from "@/components/hr/action-form";
import { DueIn, LinkTabs, Person } from "@/components/hr/bits";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { fmtDate } from "@/lib/dates";
import { cn } from "@/lib/utils";

export default async function CycleDeViePage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ vue?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/cycle-de-vie`;
  await guardCompany(companyId, base, "employees.write");
  const view = sp.vue === "termines" ? "termines" : "en-cours";
  const employees = await listEmployees(companyId, { includeLeft: true });
  const ids = employees.map((e) => e.id);
  const empById = new Map(employees.map((e) => [e.id, e]));
  const all = ids.length ? await db.select().from(schema.lifecycleWorkflows).where(inArray(schema.lifecycleWorkflows.employeeId, ids)).orderBy(desc(schema.lifecycleWorkflows.targetDate)) : [];
  const open = all.filter((w) => w.status === "in_progress").sort((a, b) => a.targetDate.localeCompare(b.targetDate));
  const closed = all.filter((w) => w.status !== "in_progress");
  const shown = view === "termines" ? closed : open;
  const today = todayIso();

  return (
    <>
      <PageHeader
        title="Arrivées et départs"
        description="Parcours d'arrivée, de départ, de mobilité et de retour : une liste de tâches modèle partagée entre RH, manager et informatique, avec échéances calculées depuis la date cible."
        actions={
          employees.length ? (
            <DialogForm trigger={<><Plus size={16} /> Nouveau parcours</>} title="Nouveau parcours" description="Les tâches modèles sont créées automatiquement ; vous pourrez en ajouter." action={createWorkflowAction} hidden={{ companyId }} submitLabel="Créer le parcours">
              <Field label="Salarié" required htmlFor="wf-emp" help="Le salarié doit exister : créez d'abord sa fiche pour une arrivée.">
                <Select id="wf-emp" name="employeeId" required defaultValue="">
                  <option value="" disabled>
                    Choisir
                  </option>
                  {employees.map((e) => (
                    <option key={e.id} value={e.id}>
                      {fullName(e)}
                      {e.status === "draft" ? " (fiche en préparation)" : e.status === "left" ? " (sorti)" : ""}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Type de parcours" required htmlFor="wf-kind">
                <Select id="wf-kind" name="kind" required>
                  {(Object.keys(kindLabels) as WorkflowKind[]).map((k) => (
                    <option key={k} value={k}>
                      {kindLabels[k]}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Date cible" required htmlFor="wf-date" help="Arrivée, dernier jour, prise de poste ou retour.">
                <Input id="wf-date" name="targetDate" type="date" required />
              </Field>
            </DialogForm>
          ) : null
        }
      />
      <LinkTabs
        label="Filtre des parcours"
        current={view}
        items={[
          { key: "en-cours", label: "En cours", href: base, count: open.length },
          { key: "termines", label: "Terminés ou annulés", href: `${base}?vue=termines` },
        ]}
      />
      {!shown.length ? (
        <Panel>
          <EmptyState
            icon={<ArrowsLeftRight size={28} />}
            title={view === "en-cours" ? "Aucun parcours en cours" : "Aucun parcours terminé"}
            description={employees.length ? "Créez un parcours d'arrivée dès la signature du contrat, ou de départ dès la notification." : "Ajoutez d'abord un salarié."}
            action={!employees.length ? <Button asChild><Link href={`/app/${companyId}/salaries`}>Ajouter un salarié</Link></Button> : undefined}
          />
        </Panel>
      ) : (
        <div className="space-y-4">
          {shown.map((w) => {
            const e = empById.get(w.employeeId)!;
            const tasks = (w.tasks as WorkflowTask[]) ?? [];
            const done = tasks.filter((t) => t.done).length;
            const kind = w.kind as WorkflowKind;
            const overdue = tasks.filter((t) => !t.done && t.dueDate < today).length;
            return (
              <Panel key={w.id}>
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-4">
                  <div className="flex min-w-0 items-center gap-4">
                    <Person first={e.firstName} last={e.lastName} sub={e.jobTitle ?? undefined} />
                    <div className="text-[13px] text-ink-2">
                      <span className="font-medium text-ink">{kindLabels[kind]}</span>
                      <span className="block">
                        {targetDateLabels[kind]} : {fmtDate(w.targetDate)}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {w.status === "in_progress" ? <DueIn days={daysUntil(w.targetDate, today)} /> : <StatusBadge status={w.status === "done" ? "done" : "cancelled"} />}
                    {overdue ? <Badge tone="danger">{overdue} tâche(s) en retard</Badge> : null}
                    <span className="num text-[13px] text-ink-2">
                      {done} / {tasks.length}
                    </span>
                    {w.status === "in_progress" ? (
                      <ActionButton action={cancelWorkflowAction} hidden={{ companyId, workflowId: w.id }} label="Annuler" variant="ghost" confirm={{ title: "Annuler le parcours", description: "Les tâches restent consultables.", confirmLabel: "Annuler le parcours", withNote: "Motif" }} />
                    ) : null}
                  </div>
                </div>
                <div className="grid gap-x-8 md:grid-cols-3">
                  {(["rh", "manager", "it"] as const).map((owner) => {
                    const list = tasks.filter((t) => t.owner === owner).sort((a, b) => a.dueDate.localeCompare(b.dueDate));
                    return (
                      <div key={owner} className="px-5 py-4">
                        <h3 className="mb-2 text-[12.5px] font-medium text-ink-2">{ownerLabels[owner]}</h3>
                        {list.length ? (
                          <ul className="space-y-1">
                            {list.map((t) => (
                              <li key={t.id} className="flex items-start gap-2">
                                <ActionButton
                                  action={toggleWorkflowTaskAction}
                                  hidden={{ companyId, workflowId: w.id, taskId: t.id }}
                                  label=""
                                  ariaLabel={t.done ? `Marquer comme à faire : ${t.label}` : `Marquer comme faite : ${t.label}`}
                                  variant="ghost"
                                  size="icon"
                                  className="-ml-2 shrink-0"
                                  icon={t.done ? <CheckSquare size={18} weight="fill" className="text-accent" /> : <Square size={18} />}
                                />
                                <span className="min-w-0 pt-2 text-[13px] leading-snug">
                                  <span className={cn(t.done ? "text-ink-3 line-through" : "text-ink")}>{t.label}</span>
                                  <span className={cn("block text-[11.5px]", !t.done && t.dueDate < today ? "text-danger-ink" : "text-ink-3")}>
                                    {t.done ? `Faite le ${fmtDate(t.doneAt ?? null)}` : `Avant le ${fmtDate(t.dueDate)}`}
                                  </span>
                                </span>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-[12.5px] text-ink-3">Aucune tâche.</p>
                        )}
                      </div>
                    );
                  })}
                </div>
                {w.status === "in_progress" ? (
                  <details className="border-t border-line px-5 py-3">
                    <summary className="cursor-pointer text-[13px] font-medium text-accent">Ajouter une tâche</summary>
                    <ActionForm action={addWorkflowTaskAction} hidden={{ companyId, workflowId: w.id }} submitLabel="Ajouter" className="mt-3">
                      <div className="grid gap-3 sm:grid-cols-[minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)]">
                        <Field label="Tâche" required htmlFor={`t-l-${w.id}`}>
                          <Input id={`t-l-${w.id}`} name="label" required />
                        </Field>
                        <Field label="Responsable" htmlFor={`t-o-${w.id}`}>
                          <Select id={`t-o-${w.id}`} name="owner">
                            <option value="rh">RH</option>
                            <option value="manager">Manager</option>
                            <option value="it">Informatique</option>
                          </Select>
                        </Field>
                        <Field label="Échéance" required htmlFor={`t-d-${w.id}`}>
                          <Input id={`t-d-${w.id}`} name="dueDate" type="date" required defaultValue={w.targetDate} />
                        </Field>
                      </div>
                    </ActionForm>
                  </details>
                ) : null}
              </Panel>
            );
          })}
        </div>
      )}
    </>
  );
}
