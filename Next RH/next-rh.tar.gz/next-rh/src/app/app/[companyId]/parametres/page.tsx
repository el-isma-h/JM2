import type { Metadata } from "next";
import Link from "next/link";
import { and, desc, eq, inArray, isNull, ne } from "drizzle-orm";
import { ShieldCheck } from "@phosphor-icons/react/dist/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { integrationLabels, integrations, type IntegrationName } from "@/lib/env";
import { cn } from "@/lib/utils";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { AgreementForm, CompanyIdentityForm } from "@/components/onboarding/company-form";
import { ContactsEditor, EstablishmentsEditor, OrganismsEditor } from "@/components/onboarding/editors";
import { CompanyDocuments } from "@/components/onboarding/company-documents";
import { MembersPanel } from "@/components/onboarding/members-panel";

export const metadata: Metadata = { title: "Paramètres" };

const SECTIONS = [
  { key: "entreprise", label: "Informations société" },
  { key: "convention", label: "Convention collective" },
  { key: "etablissements", label: "Établissements" },
  { key: "organismes", label: "Organismes" },
  { key: "interlocuteurs", label: "Interlocuteurs et documents" },
  { key: "membres", label: "Membres et invitations" },
  { key: "securite", label: "Sécurité et intégrations" },
] as const;

export default async function SettingsPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ section?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const ctx = await guardCompany(companyId, `/app/${companyId}/parametres`, "company.manage");
  const company = ctx.company;
  const section = SECTIONS.find((s) => s.key === sp.section)?.key ?? "entreprise";
  const base = `/app/${companyId}/parametres`;
  const canManageMembers = ctx.permissions.has("members.manage");

  let content: React.ReactNode = null;
  if (section === "entreprise") {
    content = (
      <CompanyIdentityForm
        companyId={companyId}
        values={{
          legalName: company.legalName,
          tradeName: company.tradeName,
          siren: company.siren,
          legalForm: company.legalForm,
          activity: company.activity,
          apeCode: company.apeCode,
          addressLine1: company.addressLine1,
          addressLine2: company.addressLine2,
          postalCode: company.postalCode,
          city: company.city,
          headcount: company.headcount,
          idcc: company.idcc,
          collectiveAgreement: company.collectiveAgreement,
        }}
      />
    );
  } else if (section === "convention") {
    content = <AgreementForm companyId={companyId} idcc={company.idcc} name={company.collectiveAgreement} confirmed={company.idccConfirmed} apeCode={company.apeCode} />;
  } else if (section === "etablissements") {
    const rows = await db.select().from(schema.establishments).where(eq(schema.establishments.companyId, companyId)).orderBy(desc(schema.establishments.isHeadOffice), schema.establishments.name);
    content = <EstablishmentsEditor companyId={companyId} siren={company.siren} rows={rows} />;
  } else if (section === "organismes") {
    const rows = await db.select().from(schema.companyOrganisms).where(eq(schema.companyOrganisms.companyId, companyId)).orderBy(schema.companyOrganisms.kind);
    content = <OrganismsEditor companyId={companyId} rows={rows} />;
  } else if (section === "interlocuteurs") {
    const [contacts, docs] = await Promise.all([
      db.select().from(schema.companyContacts).where(eq(schema.companyContacts.companyId, companyId)).orderBy(schema.companyContacts.fullName),
      db
        .select()
        .from(schema.documents)
        .where(and(eq(schema.documents.companyId, companyId), isNull(schema.documents.employeeId), inArray(schema.documents.category, ["kbis", "entreprise", "justificatif"])))
        .orderBy(desc(schema.documents.createdAt)),
    ]);
    content = (
      <div className="space-y-6">
        <ContactsEditor companyId={companyId} rows={contacts} />
        <CompanyDocuments companyId={companyId} docs={docs.map((d) => ({ id: d.id, title: d.title, category: d.category, createdAt: d.createdAt.toISOString(), sizeBytes: d.sizeBytes }))} />
      </div>
    );
  } else if (section === "membres") {
    const [members, invitations] = await Promise.all([
      db
        .select({ m: schema.companyMemberships, u: schema.users })
        .from(schema.companyMemberships)
        .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
        .where(and(eq(schema.companyMemberships.companyId, companyId), ne(schema.companyMemberships.role, "employee")))
        .orderBy(schema.users.lastName),
      db
        .select({ i: schema.invitations, by: schema.users })
        .from(schema.invitations)
        .leftJoin(schema.users, eq(schema.users.id, schema.invitations.invitedBy))
        .where(and(eq(schema.invitations.companyId, companyId), ne(schema.invitations.role, "employee")))
        .orderBy(desc(schema.invitations.createdAt))
        .limit(100),
    ]);
    content = (
      <MembersPanel
        companyId={companyId}
        currentUserId={ctx.user.id}
        canManage={canManageMembers}
        mailConfigured={integrations.mail()}
        isDemo={company.isDemo}
        members={members.map(({ m, u }) => ({ membershipId: m.id, userId: u.id, name: `${u.firstName} ${u.lastName}`, email: u.email, role: m.role, totp: Boolean(u.totpEnabledAt), lastLoginAt: u.lastLoginAt?.toISOString() ?? null }))}
        invitations={invitations.map(({ i, by }) => ({ id: i.id, email: i.email, role: i.role, status: i.status, expiresAt: i.expiresAt.toISOString(), createdAt: i.createdAt.toISOString(), invitedBy: by ? `${by.firstName} ${by.lastName}` : null }))}
      />
    );
  } else {
    content = (
      <div className="space-y-6">
        <Panel>
          <PanelHeader title="Votre authentification renforcée" description="Un code à usage unique, généré par une application sur votre téléphone, est demandé pour les accès sensibles : coordonnées bancaires, clôture de la paie, envoi des déclarations." />
          <div className="flex flex-wrap items-center justify-between gap-4 p-5">
            <div className="flex items-center gap-3">
              <ShieldCheck size={22} className={ctx.user.totpEnabled ? "text-accent" : "text-ink-3"} />
              <div>
                <p className="text-[13.5px] font-medium text-ink">{ctx.user.totpEnabled ? "Activée" : "Non activée"}</p>
                <p className="text-[12.5px] text-ink-2">{ctx.user.totpEnabled ? "Votre compte est protégé par une double vérification." : "Sans elle, les accès sensibles demandent votre mot de passe à chaque fois."}</p>
              </div>
            </div>
            <Button asChild variant={ctx.user.totpEnabled ? "secondary" : "primary"}>
              <Link href="/securite?setup=1">{ctx.user.totpEnabled ? "Gérer la double vérification" : "Activer la double vérification"}</Link>
            </Button>
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Intégrations" description="Services externes. Sans configuration, Next RH fonctionne avec un comportement de repli explicite." />
          <Table>
            <thead>
              <tr>
                <Th>Service</Th>
                <Th>État</Th>
                <Th>Si non configuré</Th>
              </tr>
            </thead>
            <tbody>
              {(Object.keys(integrationLabels) as IntegrationName[]).map((k) => {
                const ok = integrations[k]();
                return (
                  <tr key={k}>
                    <Td className="font-medium">{integrationLabels[k].label}</Td>
                    <Td>{ok ? <Badge tone="ok">Configuré</Badge> : <Badge tone="warn">Non configuré</Badge>}</Td>
                    <Td className="text-[12.5px] text-ink-2">
                      {ok ? "-" : (
                        <>
                          {integrationLabels[k].effect} <span className="num text-ink-3">Variables : {integrationLabels[k].envVars.join(", ")}.</span>
                        </>
                      )}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Panel>
        {company.isDemo ? <Notice tone="warn">Entreprise de démonstration : aucun e-mail, aucune déclaration et aucun paiement ne partent, même si les services sont configurés.</Notice> : null}
        <Panel>
          <PanelHeader title="Dossier" />
          <div className="p-5">
            <KeyValue
              items={[
                { k: "Onboarding", v: company.onboardingCompletedAt ? "Terminé" : <Link href={`/app/${companyId}/onboarding`} className="text-accent hover:underline">En cours : reprendre</Link> },
                { k: "Identifiant interne", v: <span className="num text-ink-3">{company.id}</span> },
              ]}
            />
          </div>
        </Panel>
      </div>
    );
  }

  return (
    <>
      <PageHeader title="Paramètres de l'entreprise" description={company.tradeName ?? company.legalName} actions={company.isDemo ? <Badge tone="warn">Démo</Badge> : null} />
      <div className="grid gap-8 lg:grid-cols-[208px_minmax(0,1fr)]">
        <nav aria-label="Rubriques des paramètres" className="lg:sticky lg:top-20 lg:self-start">
          <ul className="flex gap-1 overflow-x-auto lg:flex-col lg:gap-0.5">
            {SECTIONS.map((s) => (
              <li key={s.key} className="shrink-0">
                <Link
                  href={`${base}?section=${s.key}`}
                  aria-current={s.key === section ? "page" : undefined}
                  className={cn("block whitespace-nowrap rounded-[var(--radius-sm)] px-2.5 py-1.5 text-[13.5px] transition-colors", s.key === section ? "bg-accent-soft font-medium text-accent-strong" : "text-ink-2 hover:bg-bg-sunken hover:text-ink")}
                >
                  {s.label}
                  {s.key === "securite" && !ctx.user.totpEnabled ? <span className="ml-1.5 text-[11.5px] text-warn-ink">à activer</span> : null}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <FadeIn key={section} className="min-w-0">
          {content}
        </FadeIn>
      </div>
    </>
  );
}
