import Link from "next/link";
import { desc, eq, inArray } from "drizzle-orm";
import { DownloadSimple, PaperPlaneTilt } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { downloadLinkAction, filingAction, recordAcknowledgementAction } from "@/server/actions/payroll";
import { FILING_LABELS, SENDABLE } from "@/server/payroll/filings";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge, StatusBadge, type Tone } from "@/components/ui/badge";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { FadeIn } from "@/components/ui/motion";
import { fmtDateTime, monthLabel } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";
import { ActionButton, ConfirmAction, DialogFormAction, DownloadButton } from "../paie/_components/forms";

const FILING_STATUS: Record<string, { label: string; tone: Tone; help: string }> = {
  prepared: { label: "Document préparé", tone: "neutral", help: "Fichier généré, à relire et contrôler." },
  controlled: { label: "Document contrôlé", tone: "info", help: "Relu et contrôlé : prêt à être déposé." },
  send_requested: { label: "Envoi demandé", tone: "warn", help: "À déposer par vos soins, puis enregistrer l'accusé." },
  sent: { label: "Envoi effectué", tone: "info", help: "Dépôt déclaré avec sa référence ; en attente d'accusé de réception." },
  accepted: { label: "Acceptation confirmée", tone: "ok", help: "Accusé d'acceptation enregistré." },
  rejected: { label: "Rejet à corriger", tone: "danger", help: "Rejet enregistré : corrigez puis préparez à nouveau." },
};

type Control = { level: "error" | "warning" | "info"; code: string; message: string };

export default async function DeclarationsPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ periode?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const ctx = await guardCompany(companyId, `/app/${companyId}/declarations`, "payroll.prepare");
  const canSend = ctx.permissions.has("filings.send");

  const periods = await db.select().from(schema.payrollPeriods).where(eq(schema.payrollPeriods.companyId, companyId)).orderBy(desc(schema.payrollPeriods.year), desc(schema.payrollPeriods.month));
  const selected = periods.filter((p) => !sp.periode || p.id === sp.periode);
  const ids = selected.map((p) => p.id);
  const filings = ids.length ? await db.select().from(schema.payrollFilings).where(inArray(schema.payrollFilings.periodId, ids)).orderBy(schema.payrollFilings.kind) : [];
  const withFilings = selected.filter((p) => filings.some((f) => f.periodId === p.id));
  const counts = Object.fromEntries(Object.keys(FILING_STATUS).map((k) => [k, filings.filter((f) => f.status === k).length]));

  return (
    <div>
      <PageHeader
        title="Déclarations et exports"
        description="Fichiers préparés à partir des périodes validées : journal de paie, état des charges, récapitulatif par établissement, écritures comptables, virements SEPA et DSN mensuelle."
        actions={ctx.company.isDemo ? <Badge tone="warn">Démo : aucun envoi possible</Badge> : null}
      />
      <Notice tone="info" className="mb-6" title="Aucune transmission automatique">
        Next RH ne se connecte ni à net-entreprises.fr ni à votre banque. Un document n&apos;est « envoyé » ou « accepté » que lorsque vous enregistrez la référence de dépôt ou l&apos;accusé reçu (fichier de retour).
      </Notice>

      <FadeIn>
        <div className="mb-6 flex flex-wrap gap-x-8 gap-y-3 border-b border-line pb-5">
          {Object.entries(FILING_STATUS).map(([k, v]) => (
            <div key={k} className="min-w-[120px]">
              <p className="text-[12.5px] text-ink-2">{v.label}</p>
              <p className={cn("num mt-0.5 text-[20px] font-medium", counts[k] ? "text-ink" : "text-ink-3")}>{counts[k]}</p>
            </div>
          ))}
        </div>
      </FadeIn>

      {periods.length ? (
        <nav className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]" aria-label="Filtrer par période">
          <Link href={`/app/${companyId}/declarations`} className={cn("rounded-[var(--radius-sm)] px-2.5 py-1", !sp.periode ? "bg-bg-sunken text-ink" : "text-ink-2 hover:text-ink")}>
            Toutes les périodes
          </Link>
          {periods.slice(0, 12).map((p) => (
            <Link key={p.id} href={`/app/${companyId}/declarations?periode=${p.id}`} className={cn("rounded-[var(--radius-sm)] px-2.5 py-1 capitalize", sp.periode === p.id ? "bg-bg-sunken text-ink" : "text-ink-2 hover:text-ink")}>
              {monthLabel(p.year, p.month)}
            </Link>
          ))}
        </nav>
      ) : null}

      {withFilings.length ? (
        withFilings.map((p) => (
          <Panel key={p.id} className="mb-6">
            <PanelHeader
              title={<span className="capitalize">{monthLabel(p.year, p.month)}</span>}
              description={<>Période <StatusBadge status={p.status} className="ml-1" /></>}
              actions={
                <Link href={`/app/${companyId}/paie/${p.id}`} className="text-[13px] text-accent hover:underline">
                  Ouvrir la paie du mois
                </Link>
              }
            />
            <Table>
              <thead>
                <tr>
                  <Th>Document</Th>
                  <Th>Statut</Th>
                  <Th>Contrôles</Th>
                  <Th>Suivi</Th>
                  <Th />
                </tr>
              </thead>
              <tbody>
                {filings
                  .filter((f) => f.periodId === p.id)
                  .map((f) => {
                    const st = FILING_STATUS[f.status];
                    const content = (f.content ?? {}) as { documentId?: string; fileName?: string; preparedAt?: string; totalCents?: number; count?: number; notice?: string };
                    const controls = (f.controls ?? []) as Control[];
                    const errors = controls.filter((c) => c.level === "error");
                    const warnings = controls.filter((c) => c.level === "warning");
                    const ack = f.acknowledgement as { reference?: string | null; recordedAt?: string; outcome?: string } | null;
                    const sendable = SENDABLE.includes(f.kind);
                    const fields = { companyId, filingId: f.id };
                    return (
                      <tr key={f.id}>
                        <Td>
                          <p className="font-medium text-ink">{FILING_LABELS[f.kind] ?? f.kind}</p>
                          <p className="text-[12.5px] text-ink-3">
                            {content.fileName}
                            {content.preparedAt ? ` : préparé le ${fmtDateTime(content.preparedAt)}` : ""}
                            {f.kind === "virement_sepa" && content.totalCents !== undefined ? ` : ${content.count} virement(s), ${formatCents(content.totalCents)}` : ""}
                          </p>
                          {f.kind === "dsn_mensuelle" ? <p className="text-[12.5px] font-medium text-warn-ink">Fichier préparé, non transmis.</p> : null}
                        </Td>
                        <Td>
                          <Badge tone={st.tone}>{st.label}</Badge>
                          <p className="mt-1 max-w-[220px] text-[12px] text-ink-3">{st.help}</p>
                        </Td>
                        <Td className="max-w-[380px]">
                          {controls.length ? (
                            <details>
                              <summary className={cn("cursor-pointer text-[13px]", errors.length ? "text-danger-ink" : warnings.length ? "text-warn-ink" : "text-ink-2")}>
                                {errors.length ? `${errors.length} erreur(s)` : "Aucune erreur"}
                                {warnings.length ? `, ${warnings.length} point(s) à vérifier` : ""}
                              </summary>
                              <div className="mt-2 space-y-1 text-[12.5px] text-ink-2">
                                {controls.map((c, i) => (
                                  <p key={i} className={c.level === "error" ? "text-danger-ink" : undefined}>
                                    {c.message}
                                  </p>
                                ))}
                              </div>
                            </details>
                          ) : (
                            <span className="text-[13px] text-ink-3">Aucune remarque</span>
                          )}
                        </Td>
                        <Td className="text-[12.5px] text-ink-2">
                          {f.sendRequestedAt ? <p>Envoi demandé le {fmtDateTime(f.sendRequestedAt)}</p> : null}
                          {ack?.reference ? <p>Référence : <span className="num">{ack.reference}</span></p> : null}
                          {f.rejectionReason ? <p className="text-danger-ink">Motif : {f.rejectionReason}</p> : null}
                          {!f.sendRequestedAt && !ack ? (sendable ? "Pas encore d'envoi" : "Export interne") : null}
                        </Td>
                        <Td>
                          <div className="flex flex-col items-end gap-1.5">
                            {content.documentId ? (
                              <DownloadButton action={downloadLinkAction} companyId={companyId} documentId={content.documentId}>
                                <DownloadSimple size={15} /> Télécharger
                              </DownloadButton>
                            ) : null}
                            {f.status === "prepared" ? (
                              <ActionButton inline size="sm" variant="secondary" action={filingAction} fields={{ ...fields, op: "control" }} disabled={errors.length > 0}>
                                Marquer comme contrôlé
                              </ActionButton>
                            ) : null}
                            {f.status === "controlled" && sendable ? (
                              ctx.company.isDemo ? (
                                <span className="text-[12px] text-ink-3">Démonstration : envoi impossible.</span>
                              ) : canSend ? (
                                <ConfirmAction action={filingAction} fields={{ ...fields, op: "request_send" }} trigger={<><PaperPlaneTilt size={15} /> Demander l&apos;envoi</>} variant="secondary" title="Demander l'envoi ?" description={f.kind === "dsn_mensuelle" ? "Vous déposerez ensuite le fichier sur net-entreprises.fr, puis enregistrerez la référence de dépôt et l'accusé." : "Vous transmettrez ensuite le fichier à votre banque, puis enregistrerez sa confirmation."} confirmLabel="Demander l'envoi" />
                              ) : (
                                <span className="text-[12px] text-ink-3">Habilitation « envoi des déclarations » nécessaire.</span>
                              )
                            ) : null}
                            {(f.status === "send_requested" || f.status === "sent") && canSend ? (
                              <DialogFormAction action={recordAcknowledgementAction} fields={fields} trigger="Enregistrer un accusé" triggerSize="sm" title="Enregistrer un accusé" description="Saisissez la référence fournie par net-entreprises.fr ou par la banque, ou importez le fichier de retour." submitLabel="Enregistrer">
                                <div className="grid gap-4">
                                  <Field label="Type d'accusé" htmlFor="outcome" required>
                                    <Select id="outcome" name="outcome" defaultValue={f.status === "send_requested" ? "sent" : "accepted"}>
                                      {f.status === "send_requested" ? <option value="sent">Dépôt effectué (référence de dépôt)</option> : null}
                                      <option value="accepted">Accusé d&apos;acceptation</option>
                                      <option value="rejected">Accusé de rejet</option>
                                    </Select>
                                  </Field>
                                  <Field label="Référence" htmlFor="reference" help="Numéro de dépôt ou identifiant de l'accusé.">
                                    <Input id="reference" name="reference" maxLength={120} />
                                  </Field>
                                  <Field label="Fichier de retour" htmlFor="file" help="Facultatif si la référence est saisie. 5 Mo au plus.">
                                    <Input id="file" name="file" type="file" className="py-1.5" />
                                  </Field>
                                  <Field label="Motif du rejet" htmlFor="reason" help="Obligatoire pour un accusé de rejet.">
                                    <Textarea id="reason" name="reason" maxLength={500} />
                                  </Field>
                                </div>
                              </DialogFormAction>
                            ) : null}
                          </div>
                        </Td>
                      </tr>
                    );
                  })}
              </tbody>
            </Table>
          </Panel>
        ))
      ) : (
        <Panel>
          <EmptyState
            icon={<PaperPlaneTilt size={28} />}
            title="Aucun document préparé"
            description="Les exports se préparent depuis l'espace mensuel de paie, une fois la période validée et les bulletins finalisés."
            action={periods[0] ? <Link href={`/app/${companyId}/paie/${periods[0].id}`} className="text-[13.5px] text-accent hover:underline">Ouvrir la dernière période</Link> : <Link href={`/app/${companyId}/paie`} className="text-[13.5px] text-accent hover:underline">Ouvrir une période</Link>}
          />
        </Panel>
      )}
    </div>
  );
}
