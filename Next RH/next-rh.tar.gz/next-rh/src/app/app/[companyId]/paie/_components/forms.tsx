"use client";

import * as React from "react";
import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle, WarningCircle } from "@phosphor-icons/react";
import type { ActionState } from "@/server/actions/auth";
import { Button, type ButtonProps } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

type Action = (prev: ActionState, fd: FormData) => Promise<ActionState>;

function Hidden({ fields }: { fields: Record<string, string> }) {
  return (
    <>
      {Object.entries(fields).map(([k, v]) => (
        <input key={k} type="hidden" name={k} value={v} />
      ))}
    </>
  );
}

export function ActionMessage({ state, className }: { state: ActionState; className?: string }) {
  if (state.error)
    return (
      <p role="alert" className={cn("flex items-start gap-1.5 text-[12.5px] text-danger-ink", className)}>
        <WarningCircle size={15} className="mt-px shrink-0" /> {state.error}
      </p>
    );
  if (state.ok && state.message)
    return (
      <p role="status" className={cn("flex items-start gap-1.5 text-[12.5px] text-ok-ink", className)}>
        <CheckCircle size={15} className="mt-px shrink-0" /> {state.message}
      </p>
    );
  return null;
}

/** Bouton qui déclenche une server action et affiche le résultat sous le bouton. */
export function ActionButton({
  action,
  fields,
  children,
  variant = "primary",
  size = "md",
  disabled,
  className,
  inline,
}: {
  action: Action;
  fields: Record<string, string>;
  children: React.ReactNode;
  variant?: ButtonProps["variant"];
  size?: ButtonProps["size"];
  disabled?: boolean;
  className?: string;
  inline?: boolean;
}) {
  const [state, run, pending] = useActionState(action, {});
  return (
    <form action={run} className={cn(inline ? "inline-flex items-center gap-2" : "flex flex-col items-start gap-2", className)}>
      <Hidden fields={fields} />
      <Button type="submit" variant={variant} size={size} loading={pending} disabled={disabled}>
        {children}
      </Button>
      <ActionMessage state={state} />
    </form>
  );
}

/** Action sensible : confirmation explicite dans une boîte de dialogue avant exécution. */
export function ConfirmAction({
  action,
  fields,
  trigger,
  title,
  description,
  confirmLabel,
  children,
  variant = "primary",
  disabled,
}: {
  action: Action;
  fields: Record<string, string>;
  trigger: React.ReactNode;
  title: string;
  description?: string;
  confirmLabel: string;
  children?: React.ReactNode;
  variant?: ButtonProps["variant"];
  disabled?: boolean;
}) {
  const [open, setOpen] = React.useState(false);
  const [state, run, pending] = useActionState(async (p: ActionState, fd: FormData) => {
    const r = await action(p, fd);
    if (r.ok) setOpen(false);
    return r;
  }, {});
  return (
    <div className="flex flex-col items-start gap-2">
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant={variant} disabled={disabled}>
            {trigger}
          </Button>
        </DialogTrigger>
        <DialogContent title={title} description={description}>
          <form action={run} className="space-y-4">
            <Hidden fields={fields} />
            {children}
            <ActionMessage state={state} />
            <div className="flex justify-end gap-2">
              <DialogClose asChild>
                <Button type="button" variant="ghost">
                  Annuler
                </Button>
              </DialogClose>
              <Button type="submit" variant={variant === "danger" ? "danger" : "primary"} loading={pending}>
                {confirmLabel}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      {!open ? <ActionMessage state={state} /> : null}
    </div>
  );
}

/** Formulaire dans une boîte de dialogue (ajout, modification). */
export function DialogFormAction({
  action,
  fields,
  trigger,
  triggerVariant = "secondary",
  triggerSize = "md",
  title,
  description,
  submitLabel,
  children,
}: {
  action: Action;
  fields: Record<string, string>;
  trigger: React.ReactNode;
  triggerVariant?: ButtonProps["variant"];
  triggerSize?: ButtonProps["size"];
  title: string;
  description?: string;
  submitLabel: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = React.useState(false);
  const [state, run, pending] = useActionState(async (p: ActionState, fd: FormData) => {
    const r = await action(p, fd);
    if (r.ok) setOpen(false);
    return r;
  }, {});
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={triggerVariant} size={triggerSize}>
          {trigger}
        </Button>
      </DialogTrigger>
      <DialogContent title={title} description={description} className="max-w-xl">
        <form action={run} className="space-y-4">
          <Hidden fields={fields} />
          {children}
          <ActionMessage state={state} />
          <div className="flex justify-end gap-2">
            <DialogClose asChild>
              <Button type="button" variant="ghost">
                Annuler
              </Button>
            </DialogClose>
            <Button type="submit" loading={pending}>
              {submitLabel}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/** Ouvre une période puis navigue vers son espace. */
export function OpenPeriodForm({ action, companyId, defaultMonth }: { action: Action; companyId: string; defaultMonth: string }) {
  const router = useRouter();
  const [state, run, pending] = useActionState(async (p: ActionState, fd: FormData) => {
    const r = await action(p, fd);
    if (r.ok && r.data?.periodId) router.push(`/app/${companyId}/paie/${r.data.periodId}`);
    return r;
  }, {});
  return (
    <form action={run} className="flex flex-wrap items-end gap-2">
      <input type="hidden" name="companyId" value={companyId} />
      <div>
        <label htmlFor="month" className="mb-1.5 block text-[13px] font-medium text-ink">
          Mois de paie
        </label>
        <input
          id="month"
          name="month"
          type="month"
          defaultValue={defaultMonth}
          required
          className="h-9.5 rounded-[var(--radius-sm)] border border-line-strong bg-bg-elev px-3 text-sm text-ink focus:border-accent focus:outline-none focus:ring-2 focus:ring-focus/35"
        />
      </div>
      <Button type="submit" loading={pending}>
        Ouvrir la période
      </Button>
      <ActionMessage state={state} className="basis-full" />
    </form>
  );
}

/** Télécharge un document via un lien temporaire signé. */
export function DownloadButton({ action, companyId, documentId, children, size = "sm", variant = "secondary" }: { action: Action; companyId: string; documentId: string; children: React.ReactNode; size?: ButtonProps["size"]; variant?: ButtonProps["variant"] }) {
  const [state, run, pending] = useActionState(async (p: ActionState, fd: FormData) => {
    const r = await action(p, fd);
    if (r.ok && r.data?.url) window.location.assign(r.data.url);
    return r;
  }, {});
  return (
    <form action={run} className="inline-flex flex-col items-start gap-1">
      <input type="hidden" name="companyId" value={companyId} />
      <input type="hidden" name="documentId" value={documentId} />
      <Button type="submit" size={size} variant={variant} loading={pending}>
        {children}
      </Button>
      {state.error ? <ActionMessage state={state} /> : null}
    </form>
  );
}
