import Link from "next/link";
import { desc, eq, inArray, sql } from "drizzle-orm";
import { Receipt } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { openPeriodAction } from "@/server/actions/payroll";
import { EmptyState, PageHeader, Panel, PanelHeader, Notice } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { FadeIn } from "@/components/ui/motion";
import { formatCents } from "@/lib/money";
import { monthLabel } from "@/lib/dates";
import { OpenPeriodForm } from "./_components/forms";

export default async function PaiePage({ params }: { params: Promise<{ companyId: string }> }) {
  const { companyId } = await params;
  const ctx = await guardCompany(companyId, `/app/${companyId}/paie`, "payroll.prepare");
  const canSeeSalaries = ctx.permissions.has("salaries.read");

  const periods = await db.select().from(schema.payrollPeriods).where(eq(schema.payrollPeriods.companyId, companyId)).orderBy(desc(schema.payrollPeriods.year), desc(schema.payrollPeriods.month));
  const ids = periods.map((p) => p.id);
  const stats = ids.length
    ? await db
        .select({ periodId: schema.payslips.periodId, n: sql<number>`count(*)::int`, gross: sql<number>`coalesce(sum(${schema.payslips.grossCents}),0)::bigint`, cost: sql<number>`coalesce(sum(${schema.payslips.employerCostCents}),0)::bigint`, blocked: sql<number>`count(*) filter (where ${schema.payslips.status} = 'blocked')::int` })
        .from(schema.payslips)
        .where(inArray(schema.payslips.periodId, ids))
        .groupBy(schema.payslips.periodId)
    : [];
  const open = ids.length
    ? await db
        .select({ periodId: schema.payrollAnomalies.periodId, n: sql<number>`count(*)::int`, blocking: sql<number>`count(*) filter (where ${schema.payrollAnomalies.severity} = 'blocking')::int` })
        .from(schema.payrollAnomalies)
        .where(sql`${inArray(schema.payrollAnomalies.periodId, ids)} and ${schema.payrollAnomalies.status} = 'open'`)
        .groupBy(schema.payrollAnomalies.periodId)
    : [];
  const statOf = (id: string) => stats.find((s) => s.periodId === id);
  const openOf = (id: string) => open.find((s) => s.periodId === id);

  const latest = periods[0];
  const now = new Date();
  const next = latest ? (latest.month === 12 ? { y: latest.year + 1, m: 1 } : { y: latest.year, m: latest.month + 1 }) : { y: now.getFullYear(), m: now.getMonth() + 1 };
  const defaultMonth = `${next.y}-${String(next.m).padStart(2, "0")}`;

  return (
    <div>
      <PageHeader
        title="Paie"
        description="Une période par mois : collecte des variables, calcul des bulletins par le moteur Next RH, contrôle, validation, documents et déclarations."
        actions={ctx.company.isDemo ? <Badge tone="warn">Démo : aucun envoi réel</Badge> : null}
      />
      <FadeIn>
        <Panel className="mb-6">
          <PanelHeader title="Ouvrir une période" description="Si la période existe déjà, vous êtes redirigé vers elle. Les congés, temps et frais validés y sont rattachés automatiquement." />
          <div className="px-5 py-4">
            <OpenPeriodForm action={openPeriodAction} companyId={companyId} defaultMonth={defaultMonth} />
          </div>
        </Panel>
      </FadeIn>
      <FadeIn delay={0.05}>
        <Panel>
          <PanelHeader title="Périodes de paie" description={periods.length ? `${periods.length} période(s)` : undefined} />
          {periods.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Mois</Th>
                  <Th>Statut</Th>
                  <Th num>Bulletins</Th>
                  <Th num>Anomalies ouvertes</Th>
                  {canSeeSalaries ? <Th num>Masse salariale brute</Th> : null}
                  {canSeeSalaries ? <Th num>Coût employeur</Th> : null}
                  <Th>Règles</Th>
                </tr>
              </thead>
              <tbody>
                {periods.map((p) => {
                  const s = statOf(p.id);
                  const o = openOf(p.id);
                  return (
                    <tr key={p.id}>
                      <Td>
                        <Link href={`/app/${companyId}/paie/${p.id}`} className="font-medium text-ink capitalize hover:text-accent">
                          {monthLabel(p.year, p.month)}
                        </Link>
                      </Td>
                      <Td>
                        <StatusBadge status={p.status} />
                      </Td>
                      <Td num>
                        {s?.n ?? 0}
                        {s?.blocked ? <span className="ml-1 text-danger-ink">({s.blocked} bloqué{s.blocked > 1 ? "s" : ""})</span> : null}
                      </Td>
                      <Td num>{o ? <span className={o.blocking ? "text-danger-ink" : "text-warn-ink"}>{o.n}</span> : <span className="text-ink-3">0</span>}</Td>
                      {canSeeSalaries ? <Td num>{s ? formatCents(Number(s.gross)) : "-"}</Td> : null}
                      {canSeeSalaries ? <Td num>{s ? formatCents(Number(s.cost)) : "-"}</Td> : null}
                      <Td className="text-[12.5px] text-ink-2">{p.ruleSetVersion ?? "-"}</Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          ) : (
            <EmptyState icon={<Receipt size={28} />} title="Aucune période de paie" description="Ouvrez le premier mois traité dans Next RH. En reprise en cours d'année, renseignez d'abord les cumuls des salariés dans l'onboarding." />
          )}
        </Panel>
      </FadeIn>
      {!canSeeSalaries ? (
        <Notice tone="info" className="mt-4">
          Les montants sont masqués : votre habilitation ne comprend pas la consultation des salaires.
        </Notice>
      ) : null}
    </div>
  );
}
