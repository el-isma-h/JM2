"use client";

import * as React from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Check, LockSimple, WarningOctagon } from "@phosphor-icons/react";
import { cn } from "@/lib/utils";

export type StepView = {
  key: string;
  label: string;
  state: "done" | "current" | "upcoming" | "blocked";
  /** Ce que fait l'étape, en clair. */
  description: string;
  /** Résultat ou résumé de l'étape une fois franchie. */
  summary?: string | null;
  /** Ce qui empêche d'avancer. */
  blockers: string[];
  /** Motif quand l'action n'est pas disponible (habilitation, étape précédente). */
  unavailable?: string | null;
};

export function PayrollStepper({ steps, actions }: { steps: StepView[]; actions: Record<string, React.ReactNode> }) {
  const reduce = useReducedMotion();
  const currentIdx = Math.max(0, steps.findIndex((s) => s.state === "current" || s.state === "blocked"));
  const [selected, setSelected] = React.useState(steps[currentIdx]?.key ?? steps[0].key);
  const step = steps.find((s) => s.key === selected) ?? steps[0];
  const idx = steps.findIndex((s) => s.key === step.key);

  return (
    <div>
      <ol className="flex gap-1 overflow-x-auto border-b border-line px-3 py-2.5" aria-label="Étapes de la paie du mois">
        {steps.map((s, i) => {
          const active = s.key === selected;
          return (
            <li key={s.key} className="shrink-0">
              <button
                type="button"
                onClick={() => setSelected(s.key)}
                aria-current={s.state === "current" ? "step" : undefined}
                className={cn(
                  "flex items-center gap-2 rounded-[var(--radius-sm)] px-2.5 py-1.5 text-[12.5px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-focus/35",
                  active ? "bg-bg-sunken text-ink" : "text-ink-2 hover:bg-bg-sunken hover:text-ink",
                )}
              >
                <span
                  className={cn(
                    "num flex h-5 w-5 items-center justify-center rounded-none text-[11px]",
                    s.state === "done" && "bg-accent text-accent-ink",
                    s.state === "current" && "border border-accent text-accent",
                    s.state === "blocked" && "bg-danger-soft text-danger-ink",
                    s.state === "upcoming" && "border border-line-strong text-ink-3",
                  )}
                  aria-hidden
                >
                  {s.state === "done" ? <Check size={11} weight="bold" /> : s.state === "blocked" ? <WarningOctagon size={12} /> : i + 1}
                </span>
                <span className={cn(s.state === "current" && "font-medium text-ink")}>{s.label}</span>
              </button>
            </li>
          );
        })}
      </ol>
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={step.key}
          initial={reduce ? false : { opacity: 0, x: 8 }}
          animate={{ opacity: 1, x: 0 }}
          exit={reduce ? undefined : { opacity: 0, x: -8 }}
          transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
          className="grid gap-5 px-5 py-4 md:grid-cols-[1fr_auto]"
        >
          <div className="min-w-0">
            <p className="text-[12.5px] text-ink-3">
              Étape {idx + 1} sur {steps.length}
              {step.state === "done" ? " : terminée" : step.state === "blocked" ? " : bloquée" : step.state === "current" ? " : en cours" : ""}
            </p>
            <h3 className="mt-0.5 text-[15px] font-semibold text-ink">{step.label}</h3>
            <p className="mt-1 max-w-[72ch] text-[13.5px] text-ink-2">{step.description}</p>
            {step.summary ? <p className="mt-2 text-[13px] text-ink">{step.summary}</p> : null}
            {step.blockers.length ? (
              <div className="mt-3 rounded-[var(--radius-sm)] bg-warn-soft px-3 py-2 text-[13px] text-warn-ink">
                <p className="font-medium">Ce qui bloque</p>
                <ul className="mt-1 list-disc space-y-0.5 pl-5">
                  {step.blockers.slice(0, 6).map((b) => (
                    <li key={b}>{b}</li>
                  ))}
                </ul>
                {step.blockers.length > 6 ? <p className="mt-1">Et {step.blockers.length - 6} autre(s) : voir la liste des anomalies.</p> : null}
              </div>
            ) : null}
          </div>
          <div className="flex min-w-[220px] flex-col items-start gap-2 md:items-end">
            {step.unavailable ? (
              <p className="flex items-center gap-1.5 text-[12.5px] text-ink-3">
                <LockSimple size={14} /> {step.unavailable}
              </p>
            ) : (
              actions[step.key] ?? null
            )}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
