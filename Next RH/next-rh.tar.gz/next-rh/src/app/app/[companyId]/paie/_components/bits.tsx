"use client";

import * as React from "react";
import * as Popover from "@radix-ui/react-popover";
import { Info } from "@phosphor-icons/react";
import { Field, Input, Select } from "@/components/ui/field";
import { cn } from "@/lib/utils";

/** Écart vs mois précédent, avec l'explication détaillée au clic. */
export function VarianceCell({ pct, deltaLabel, explanations, previous }: { pct: number | null; deltaLabel: string; explanations: string[]; previous: string | null }) {
  if (pct === null) return <span className="text-ink-3">-</span>;
  const strong = Math.abs(pct) > 10;
  return (
    <Popover.Root>
      <Popover.Trigger
        className={cn(
          "num inline-flex items-center gap-1 rounded-[var(--radius-sm)] px-1.5 py-0.5 text-[13px] hover:bg-bg-sunken focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-focus/35",
          strong ? "text-warn-ink" : "text-ink-2",
        )}
        aria-label="Voir l'explication de l'écart"
      >
        {pct > 0 ? "+" : ""}
        {String(pct).replace(".", ",")} %
        <Info size={13} />
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content sideOffset={6} align="end" className="z-50 w-[340px] rounded-[var(--radius-md)] border border-line bg-bg-elev p-4 text-[13px] text-ink shadow-[var(--shadow-2)]">
          <p className="font-medium">
            Brut {deltaLabel} par rapport à {previous ?? "le mois précédent"}
          </p>
          <div className="mt-2 space-y-1.5 text-ink-2">
            {explanations.map((e) => (
              <p key={e}>{e}</p>
            ))}
          </div>
          <Popover.Arrow className="fill-[var(--bg-elev)]" />
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}

export const VARIABLE_KINDS: { value: string; label: string; help: string }[] = [
  { value: "prime", label: "Prime", help: "Montant brut soumis à cotisations et à l'impôt." },
  { value: "commission", label: "Commission", help: "Montant brut soumis à cotisations et à l'impôt." },
  { value: "heures_sup", label: "Heures supplémentaires", help: "Heures au-delà de 35 h par semaine pour un temps plein. Majoration de 25 % pour les 8 premières heures de la semaine, 50 % au-delà." },
  { value: "heures_comp", label: "Heures complémentaires", help: "Temps partiel : 10 % dans la limite du dixième de l'horaire du contrat, 25 % au-delà." },
  { value: "absence", label: "Absence", help: "Nombre de jours ouvrés. Seul le congé sans solde entraîne une retenue." },
  { value: "avantage_nature", label: "Avantage en nature", help: "Montant de l'avantage (véhicule, logement, repas) : ajouté au brut puis déduit du net." },
  { value: "titres_restaurant", label: "Titres-restaurant", help: "Nombre de titres, valeur d'un titre et part patronale (entre 50 et 60 %, 7,32 € au plus en 2026)." },
  { value: "indemnite", label: "Remboursement de frais", help: "Ajouté au net, sans cotisations ni impôt." },
  { value: "acompte", label: "Acompte versé", help: "Déduit du net à payer." },
  { value: "regularisation", label: "Régularisation", help: "Montant brut positif ou négatif (rappel ou trop-perçu)." },
];

export function VariableFields({
  employees,
  initial,
}: {
  employees: { id: string; name: string }[];
  initial?: { employeeId: string; kind: string; label: string; quantity: string | null; rate: string | null; amount: string | null; note: string | null };
}) {
  const [kind, setKind] = React.useState(initial?.kind ?? "prime");
  const meta = VARIABLE_KINDS.find((k) => k.value === kind)!;
  const qty = ["heures_sup", "heures_comp", "absence", "titres_restaurant"].includes(kind);
  const amount = !["heures_sup", "heures_comp", "absence"].includes(kind);
  const rate = ["heures_sup", "heures_comp", "titres_restaurant"].includes(kind);
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Field label="Salarié" htmlFor="v-emp" required>
        <Select id="v-emp" name="employeeId" defaultValue={initial?.employeeId} required>
          {employees.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Type d'élément" htmlFor="v-kind" help={meta.help} required>
        <Select id="v-kind" name="kind" value={kind} onChange={(e) => setKind(e.target.value)}>
          {VARIABLE_KINDS.map((k) => (
            <option key={k.value} value={k.value}>
              {k.label}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Libellé sur le bulletin" htmlFor="v-label" className="sm:col-span-2" required>
        <Input id="v-label" name="label" defaultValue={initial?.label ?? meta.label} maxLength={120} required />
      </Field>
      {kind === "absence" ? (
        <Field label="Type d'absence" htmlFor="v-note" required>
          <Select id="v-note" name="note" defaultValue={initial?.note ?? "CSS"}>
            <option value="CSS">Congé sans solde (retenue)</option>
            <option value="CP">Congés payés (maintien)</option>
            <option value="RTT">RTT (maintien)</option>
            <option value="EVF">Événement familial (maintien)</option>
          </Select>
        </Field>
      ) : null}
      {qty ? (
        <Field label={kind === "absence" ? "Nombre de jours" : kind === "titres_restaurant" ? "Nombre de titres" : "Nombre d'heures"} htmlFor="v-qty" required>
          <Input id="v-qty" name="quantity" inputMode="decimal" defaultValue={initial?.quantity ?? ""} className="num" required />
        </Field>
      ) : null}
      {rate ? (
        <Field
          label={kind === "titres_restaurant" ? "Part patronale (%)" : "Majoration (%)"}
          htmlFor="v-rate"
          help={kind === "titres_restaurant" ? "Entre 50 et 60 %." : "Laissez vide pour appliquer la majoration légale de base (à vérifier)."}
          required={kind === "titres_restaurant"}
        >
          <Input id="v-rate" name="rate" inputMode="decimal" defaultValue={initial?.rate ?? (kind === "titres_restaurant" ? "50" : "")} className="num" />
        </Field>
      ) : null}
      {amount ? (
        <Field label={kind === "titres_restaurant" ? "Valeur d'un titre (€)" : "Montant (€)"} htmlFor="v-amount" required>
          <Input id="v-amount" name="amount" inputMode="decimal" defaultValue={initial?.amount ?? ""} className="num" required />
        </Field>
      ) : null}
    </div>
  );
}
