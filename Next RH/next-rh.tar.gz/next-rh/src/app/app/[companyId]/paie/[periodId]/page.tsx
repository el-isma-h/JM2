import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, eq, sql } from "drizzle-orm";
import { ArrowRight, Calculator, Plus, Scales } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { decideAnomalyAction, deleteVariableAction, prepareFilingsAction, runStepAction, saveVariableAction } from "@/server/actions/payroll";
import { isPeriodFresh, statusIndex, type CollectSummary } from "@/server/payroll/cycle";
import { EDITABLE_STATUSES, employeesInScope } from "@/server/payroll/inputs";
import { payrollScope } from "@/server/payroll/scope";
import { getRuleSet } from "@/server/payroll/rules";
import type { Variance } from "@/server/payroll/variance";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { FadeIn } from "@/components/ui/motion";
import { formatCents, formatNumber } from "@/lib/money";
import { fmtDate, fmtDateTime, monthLabel, deMonth } from "@/lib/dates";
import { ActionButton, ConfirmAction, DialogFormAction } from "../_components/forms";
import { PayrollStepper, type StepView } from "../_components/stepper";
import { VARIABLE_KINDS, VarianceCell, VariableFields } from "../_components/bits";

const SOURCE_LABELS: Record<string, string> = {
  manual: "Saisie paie",
  leave: "Congés",
  timesheet: "Temps",
  expense: "Frais",
  leave_annulation: "Annulation congé",
  timesheet_annulation: "Annulation temps",
  expense_annulation: "Annulation frais",
};

export default async function PeriodPage({ params }: { params: Promise<{ companyId: string; periodId: string }> }) {
  const { companyId, periodId } = await params;
  if (!/^[0-9a-f-]{36}$/.test(periodId)) notFound();
  const base = `/app/${companyId}/paie/${periodId}`;
  const ctx = await guardCompany(companyId, base, "payroll.prepare");
  const [period] = await db.select().from(schema.payrollPeriods).where(and(eq(schema.payrollPeriods.id, periodId), eq(schema.payrollPeriods.companyId, companyId))).limit(1);
  if (!period) notFound();

  const can = (p: Parameters<typeof ctx.permissions.has>[0]) => ctx.permissions.has(p);
  const canSeeSalaries = can("salaries.read");
  const editable = EDITABLE_STATUSES.has(period.status);
  const sIdx = statusIndex(period.status);
  const label = monthLabel(period.year, period.month);
  const summary = (period.summary ?? {}) as { collect?: CollectSummary; compute?: { at: string; payslips: number; computed: number; blocked: number; totals: { gross: number; net: number; cost: number; pas: number } } };

  const [slips, anomalies, variables, scope, filings] = await Promise.all([
    db
      .select({ s: schema.payslips, e: { id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName, jobTitle: schema.employees.jobTitle } })
      .from(schema.payslips)
      .innerJoin(schema.employees, eq(schema.employees.id, schema.payslips.employeeId))
      .where(and(eq(schema.payslips.periodId, periodId), eq(schema.employees.companyId, companyId)))
      .orderBy(asc(schema.employees.lastName), asc(schema.employees.firstName)),
    db
      .select({ a: schema.payrollAnomalies, firstName: schema.employees.firstName, lastName: schema.employees.lastName })
      .from(schema.payrollAnomalies)
      .leftJoin(schema.employees, eq(schema.employees.id, schema.payrollAnomalies.employeeId))
      .where(eq(schema.payrollAnomalies.periodId, periodId))
      .orderBy(sql`case ${schema.payrollAnomalies.severity} when 'blocking' then 0 when 'warning' then 1 else 2 end`, asc(schema.payrollAnomalies.status), asc(schema.payrollAnomalies.createdAt)),
    db
      .select({ v: schema.payrollVariables, firstName: schema.employees.firstName, lastName: schema.employees.lastName })
      .from(schema.payrollVariables)
      .innerJoin(schema.employees, eq(schema.employees.id, schema.payrollVariables.employeeId))
      .where(and(eq(schema.payrollVariables.periodId, periodId), eq(schema.employees.companyId, companyId)))
      .orderBy(asc(schema.employees.lastName), asc(schema.payrollVariables.createdAt)),
    employeesInScope(companyId, period),
    db.select({ id: schema.payrollFilings.id, kind: schema.payrollFilings.kind, status: schema.payrollFilings.status }).from(schema.payrollFilings).where(eq(schema.payrollFilings.periodId, periodId)),
  ]);
  const fresh = period.status === "computed" || period.status === "controlled" ? await isPeriodFresh(periodId) : true;
  const open = anomalies.filter((x) => x.a.status === "open");
  const openBlocking = open.filter((x) => x.a.severity === "blocking");
  const openWarnings = open.filter((x) => x.a.severity === "warning");
  const ruleSet = period.ruleSetVersion ? getRuleSet(period.ruleSetVersion) : null;
  const fields = { companyId, periodId };
  const empOptions = scope.included.map((e) => ({ id: e.id, name: `${e.lastName} ${e.firstName}` }));
  const name = (x: { firstName: string | null; lastName: string | null }) => (x.firstName ? `${x.firstName} ${x.lastName}` : "Toute l'entreprise");

  // ---------- Étapes ----------
  const noPerm = (p: string) => `Habilitation « ${p} » nécessaire.`;
  const collectBlocking = (summary.collect?.items ?? []).filter((i) => i.severity === "blocking").map((i) => `${i.name} : ${i.message}`);
  const done = {
    open: true,
    collect: Boolean(summary.collect) || sIdx >= statusIndex("checking"),
    check: sIdx >= statusIndex("checking"),
    compute: sIdx >= statusIndex("computed") && Boolean(summary.compute),
    control: sIdx >= statusIndex("controlled"),
    validate: sIdx >= statusIndex("validated"),
    finalize: sIdx >= statusIndex("finalized"),
    export: sIdx >= statusIndex("exported"),
    distribute: sIdx >= statusIndex("distributed"),
    close: sIdx >= statusIndex("closed"),
  };
  const raw: Omit<StepView, "state">[] = [
    { key: "open", label: "Ouvrir", description: `Période de ${label}, paiement prévu le ${fmtDate(period.paymentDate)}. Les variables des autres modules (congés, temps, frais) y sont rattachées dès leur validation.`, summary: `Ouverte le ${fmtDateTime(period.createdAt)}.`, blockers: [] },
    {
      key: "collect",
      label: "Collecter les variables",
      description: "Rassemble les absences, heures et frais validés, et liste ce qui manque : contrat, rémunération, taux d'impôt, coordonnées bancaires, éléments encore en attente de validation.",
      summary: summary.collect ? `${summary.collect.variables.total} variable(s) pour ${summary.collect.employees} salarié(s), collecte du ${fmtDateTime(summary.collect.at)}.` : null,
      blockers: [],
      unavailable: !editable ? "Période validée." : null,
    },
    {
      key: "check",
      label: "Vérifier",
      description: "Examinez la liste des points relevés lors de la collecte (tableau ci-dessous), complétez les fiches si besoin, puis confirmez.",
      summary: summary.collect ? `${summary.collect.items.length} point(s) relevé(s), dont ${collectBlocking.length} bloquant(s).` : null,
      blockers: collectBlocking,
      unavailable: !summary.collect ? "Collectez d'abord les variables." : !editable ? "Période validée." : null,
    },
    {
      key: "compute",
      label: "Calculer",
      description: "Le moteur calcule chaque bulletin à partir des règles légales datées. Le calcul peut être relancé autant de fois que nécessaire tant que la période n'est pas validée.",
      summary: summary.compute ? `${summary.compute.computed} bulletin(s) calculé(s), ${summary.compute.blocked} bloqué(s), le ${fmtDateTime(summary.compute.at)}.${!fresh ? " Des données ont changé depuis : recalculez." : ""}` : null,
      blockers: !fresh ? ["Des données ont changé depuis le dernier calcul."] : [],
      unavailable: sIdx < statusIndex("checking") ? "Vérifiez d'abord la collecte." : !editable ? "Période validée." : null,
    },
    {
      key: "control",
      label: "Contrôler les anomalies",
      description: "Chaque anomalie bloquante doit être corrigée à la source puis recalculée. Chaque point à vérifier doit être examiné et pris en compte.",
      summary: done.control ? "Toutes les anomalies ont été traitées." : null,
      blockers: [
        ...(openBlocking.length ? [`${openBlocking.length} anomalie(s) bloquante(s) ouverte(s).`] : []),
        ...(openWarnings.length ? [`${openWarnings.length} point(s) à vérifier non pris en compte.`] : []),
        ...(!fresh ? ["Des données ont changé depuis le calcul : recalculez."] : []),
      ],
      unavailable: sIdx < statusIndex("computed") ? "Calculez d'abord les bulletins." : null,
    },
    {
      key: "validate",
      label: "Valider",
      description: "La validation fige les bulletins du mois. Toute correction ultérieure passera par une régularisation sur une période suivante.",
      summary: period.validatedAt ? `Validée le ${fmtDateTime(period.validatedAt)}.` : null,
      blockers: openBlocking.length ? [`${openBlocking.length} anomalie(s) bloquante(s) ouverte(s).`] : [],
      unavailable: !can("payroll.validate") ? noPerm("valider la paie") : sIdx < statusIndex("controlled") ? "Contrôlez d'abord les anomalies." : null,
    },
    {
      key: "finalize",
      label: "Finaliser les documents",
      description: "Génère les bulletins PDF, classés dans le dossier de chaque salarié (catégorie bulletin, conservation 50 ans).",
      summary: done.finalize ? `${slips.filter((x) => x.s.documentId).length} bulletin(s) PDF générés.` : null,
      blockers: [],
      unavailable: !can("payroll.validate") ? noPerm("valider la paie") : sIdx < statusIndex("validated") ? "Validez d'abord la paie." : null,
    },
    {
      key: "export",
      label: "Préparer exports et déclarations",
      description: "Journal de paie, état des charges, récapitulatif par établissement, écritures comptables, virements SEPA et DSN mensuelle préparée (jamais transmise automatiquement).",
      summary: filings.length ? `${filings.length} document(s) préparé(s).` : null,
      blockers: [],
      unavailable: sIdx < statusIndex("finalized") ? "Finalisez d'abord les documents." : null,
    },
    {
      key: "distribute",
      label: "Distribuer",
      description: ctx.company.isDemo ? "Met les bulletins à disposition dans l'espace de chaque salarié. Démonstration : aucun e-mail n'est envoyé." : "Met les bulletins à disposition dans l'espace de chaque salarié et prévient par e-mail ceux qui ont un compte.",
      summary: done.distribute ? `${slips.filter((x) => x.s.distributedAt).length} bulletin(s) distribué(s).` : null,
      blockers: [],
      unavailable: !can("payroll.validate") ? noPerm("valider la paie") : sIdx < statusIndex("exported") ? "Préparez d'abord les exports." : null,
    },
    {
      key: "close",
      label: "Clôturer",
      description: "Clôt définitivement la période. Les cumuls de l'année sont repris par le mois suivant.",
      summary: period.closedAt ? `Clôturée le ${fmtDateTime(period.closedAt)}.` : null,
      blockers: [],
      unavailable: !can("payroll.close") ? noPerm("clôturer la paie") : sIdx < statusIndex("distributed") ? "Distribuez d'abord les bulletins." : null,
    },
  ];
  let currentFound = false;
  const steps: StepView[] = raw.map((s) => {
    const isDone = done[s.key as keyof typeof done];
    if (isDone && !(s.key === "compute" && !fresh)) return { ...s, state: "done" };
    if (!currentFound) {
      currentFound = true;
      return { ...s, state: s.blockers.length ? "blocked" : "current" };
    }
    return { ...s, state: "upcoming" };
  });

  const stepActions: Record<string, React.ReactNode> = {
    collect: <ActionButton action={runStepAction} fields={{ ...fields, step: "collect" }} variant={done.collect ? "secondary" : "primary"}>{done.collect ? "Relancer la collecte" : "Collecter les variables"}</ActionButton>,
    check: <ActionButton action={runStepAction} fields={{ ...fields, step: "check" }} variant={done.check ? "secondary" : "primary"}>{done.check ? "Vérification confirmée" : "Confirmer la vérification"}</ActionButton>,
    compute: (
      <ActionButton action={runStepAction} fields={{ ...fields, step: "compute" }} variant={done.compute && fresh ? "secondary" : "primary"}>
        <Calculator size={16} /> {summary.compute ? "Recalculer les bulletins" : "Calculer les bulletins"}
      </ActionButton>
    ),
    control: <ActionButton action={runStepAction} fields={{ ...fields, step: "control" }} disabled={done.control}>Marquer la paie comme contrôlée</ActionButton>,
    validate: done.validate ? null : (
      <ConfirmAction action={runStepAction} fields={{ ...fields, step: "validate" }} trigger="Valider la paie" title={`Valider la paie de ${label} ?`} description="Les bulletins seront figés. Les corrections ultérieures se feront par régularisation sur un mois suivant." confirmLabel="Valider définitivement">
        {summary.compute && canSeeSalaries ? (
          <KeyValue items={[{ k: "Bulletins", v: <span className="num">{summary.compute.payslips}</span> }, { k: "Brut total", v: <span className="num">{formatCents(summary.compute.totals.gross)}</span> }, { k: "Net payé total", v: <span className="num">{formatCents(summary.compute.totals.net)}</span> }, { k: "Coût employeur", v: <span className="num">{formatCents(summary.compute.totals.cost)}</span> }]} />
        ) : null}
      </ConfirmAction>
    ),
    finalize: done.finalize ? null : (
      <ConfirmAction action={runStepAction} fields={{ ...fields, step: "finalize" }} trigger="Générer les bulletins PDF" title="Finaliser les documents ?" description="Un bulletin PDF est généré pour chaque salarié et rangé dans son dossier. Il ne pourra pas être modifié." confirmLabel="Générer les bulletins" />
    ),
    export: (
      <div className="flex flex-col items-start gap-2 md:items-end">
        <DialogFormAction action={prepareFilingsAction} fields={fields} trigger={done.export ? "Préparer à nouveau" : "Préparer les exports"} triggerVariant={done.export ? "secondary" : "primary"} title="Préparer exports et déclarations" description="Les fichiers sont stockés de façon restreinte. La DSN est préparée, jamais transmise automatiquement." submitLabel="Préparer les fichiers">
          {can("employees.bank.read") ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="IBAN du compte émetteur" htmlFor="debtorIban" help="Facultatif : nécessaire pour le fichier de virements SEPA. Il n'est pas conservé." className="sm:col-span-2">
                <Input id="debtorIban" name="debtorIban" autoComplete="off" placeholder="FR76 ..." className="num" />
              </Field>
              <Field label="BIC" htmlFor="debtorBic" help="Facultatif.">
                <Input id="debtorBic" name="debtorBic" autoComplete="off" />
              </Field>
              <Field label="Nom du titulaire" htmlFor="debtorName" help={`Par défaut : ${ctx.company.legalName}`}>
                <Input id="debtorName" name="debtorName" />
              </Field>
            </div>
          ) : (
            <Notice tone="info">Le fichier de virements nécessite l&apos;habilitation « coordonnées bancaires ». Les autres fichiers seront préparés.</Notice>
          )}
        </DialogFormAction>
        {filings.length ? (
          <Link href={`/app/${companyId}/declarations?periode=${periodId}`} className="inline-flex items-center gap-1 text-[13px] text-accent hover:underline">
            Voir les déclarations <ArrowRight size={14} />
          </Link>
        ) : null}
      </div>
    ),
    distribute: done.distribute ? null : <ActionButton action={runStepAction} fields={{ ...fields, step: "distribute" }}>Distribuer les bulletins</ActionButton>,
    close: done.close ? null : ctx.user.elevated ? (
      <ConfirmAction action={runStepAction} fields={{ ...fields, step: "close" }} trigger="Clôturer la période" title={`Clôturer ${label} ?`} description="La période ne pourra plus évoluer. Cette action est journalisée." confirmLabel="Clôturer" />
    ) : (
      <Button asChild variant="secondary">
        <Link href={`/securite?next=${encodeURIComponent(base)}`}>Confirmer mon identité pour clôturer</Link>
      </Button>
    ),
  };

  const totals = summary.compute?.totals;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Paie", href: `/app/${companyId}/paie` }, { label }]}
        title={<span>Paie {deMonth(label)}</span>}
        description={`Paiement prévu le ${fmtDate(period.paymentDate)}. Règles légales ${period.ruleSetVersion ?? "non déterminées"}.`}
        actions={
          <>
            <StatusBadge status={period.status} />
            {ctx.company.isDemo ? <Badge tone="warn">Démo</Badge> : null}
          </>
        }
      />

      <FadeIn>
        <Panel className="mb-6">
          <PayrollStepper steps={steps} actions={stepActions} />
        </Panel>
      </FadeIn>

      {totals && canSeeSalaries ? (
        <FadeIn delay={0.04}>
          <div className="mb-6 grid grid-cols-2 gap-6 border-b border-line pb-5 md:grid-cols-4">
            <Stat label="Brut total" value={formatCents(totals.gross)} hint={`${summary.compute!.payslips} bulletin(s)`} />
            <Stat label="Net payé total" value={formatCents(totals.net)} />
            <Stat label="Impôt prélevé" value={formatCents(totals.pas)} />
            <Stat label="Coût employeur" value={formatCents(totals.cost)} />
          </div>
        </FadeIn>
      ) : null}

      {summary.collect && !summary.compute ? (
        <Panel className="mb-6">
          <PanelHeader title="Points relevés à la collecte" description="À examiner avant le calcul. Les points bloquants empêchent le calcul du bulletin concerné." />
          {summary.collect.items.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Niveau</Th>
                  <Th>Concerne</Th>
                  <Th>Constat</Th>
                </tr>
              </thead>
              <tbody>
                {summary.collect.items.map((i, k) => (
                  <tr key={k}>
                    <Td>
                      <StatusBadge status={i.severity} />
                    </Td>
                    <Td className="whitespace-nowrap">{i.employeeId ? <Link className="hover:text-accent" href={`/app/${companyId}/salaries/${i.employeeId}`}>{i.name}</Link> : i.name}</Td>
                    <Td className="text-ink-2">{i.message}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Rien à signaler" description="Tous les salariés ont un contrat, une rémunération, un taux d'impôt et un RIB." />
          )}
        </Panel>
      ) : null}

      {/* Bulletins */}
      <Panel className="mb-6">
        <PanelHeader title="Bulletins du mois" description={slips.length ? "Cliquez sur un salarié pour voir le détail du calcul. L'écart compare le brut au mois précédent." : undefined} />
        {slips.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Salarié</Th>
                <Th>Statut</Th>
                <Th num>Brut</Th>
                <Th num>Cotisations salariales</Th>
                <Th num>Net payé</Th>
                <Th num>Coût employeur</Th>
                <Th num>Écart vs M-1</Th>
              </tr>
            </thead>
            <tbody>
              {slips.map(({ s, e }) => {
                const v = s.variance as Partial<Variance>;
                return (
                  <tr key={s.id}>
                    <Td>
                      <Link href={`${base}/bulletins/${s.id}`} className="font-medium text-ink hover:text-accent">
                        {e.lastName} {e.firstName}
                      </Link>
                      {s.blockingReason ? <p className="text-[12.5px] text-danger-ink">{s.blockingReason}</p> : <p className="text-[12.5px] text-ink-3">{e.jobTitle ?? ""}</p>}
                    </Td>
                    <Td>
                      <StatusBadge status={s.status} />
                    </Td>
                    <Td num>{canSeeSalaries && s.status !== "blocked" ? formatCents(s.grossCents) : "-"}</Td>
                    <Td num>{canSeeSalaries && s.status !== "blocked" ? formatCents(s.employeeContribCents) : "-"}</Td>
                    <Td num>{canSeeSalaries && s.status !== "blocked" ? formatCents(s.netPaidCents) : "-"}</Td>
                    <Td num>{canSeeSalaries && s.status !== "blocked" ? formatCents(s.employerCostCents) : "-"}</Td>
                    <Td num>
                      {canSeeSalaries && s.status !== "blocked" ? (
                        <VarianceCell pct={v.grossDeltaPct ?? null} deltaLabel={formatCents(v.grossDeltaCents ?? 0, { signed: true })} explanations={v.explanations ?? []} previous={v.previousPeriod ?? null} />
                      ) : (
                        "-"
                      )}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState icon={<Calculator size={26} />} title="Aucun bulletin calculé" description={`${scope.included.length} salarié(s) concerné(s) ce mois. Collectez les variables, vérifiez, puis lancez le calcul.`} />
        )}
      </Panel>

      {/* Anomalies */}
      <Panel className="mb-6">
        <PanelHeader
          title="Anomalies"
          description={anomalies.length ? `${openBlocking.length} bloquante(s), ${openWarnings.length} à vérifier, sur ${anomalies.length} au total.` : "Les anomalies apparaissent après le calcul."}
        />
        {anomalies.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Niveau</Th>
                <Th>Concerne</Th>
                <Th>Explication</Th>
                <Th>Suite donnée</Th>
              </tr>
            </thead>
            <tbody>
              {anomalies.map(({ a, firstName, lastName }) => (
                <tr key={a.id}>
                  <Td>
                    <StatusBadge status={a.severity} />
                  </Td>
                  <Td className="whitespace-nowrap">{name({ firstName, lastName })}</Td>
                  <Td className="max-w-[640px]">
                    <p className="font-medium text-ink">{a.title}</p>
                    <p className="mt-0.5 text-[13px] text-ink-2">{a.explanation}</p>
                  </Td>
                  <Td>
                    <div className="flex flex-col items-start gap-1.5">
                      <StatusBadge status={a.status} />
                      {editable && a.severity !== "blocking" ? (
                        a.status === "open" ? (
                          <ActionButton inline size="sm" variant="secondary" action={decideAnomalyAction} fields={{ ...fields, anomalyId: a.id, decision: a.severity === "warning" ? "acknowledged" : "resolved" }}>
                            {a.severity === "warning" ? "Prendre en compte" : "Marquer comme lue"}
                          </ActionButton>
                        ) : (
                          <ActionButton inline size="sm" variant="ghost" action={decideAnomalyAction} fields={{ ...fields, anomalyId: a.id, decision: "open" }}>
                            Rouvrir
                          </ActionButton>
                        )
                      ) : a.severity === "blocking" && a.status === "open" ? (
                        <span className="text-[12.5px] text-ink-3">Corrigez la donnée, puis recalculez.</span>
                      ) : null}
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : null}
      </Panel>

      {/* Variables */}
      <Panel className="mb-6">
        <PanelHeader
          title="Variables du mois"
          description="Éléments qui modifient la paie : primes, heures, absences, avantages, frais. Les variables venant des congés, des temps et des frais se modifient dans leur module."
          actions={
            editable && empOptions.length ? (
              <DialogFormAction action={saveVariableAction} fields={fields} trigger={<><Plus size={16} /> Ajouter une variable</>} title="Ajouter une variable" description={`Paie ${deMonth(label)}. Relancez le calcul ensuite.`} submitLabel="Enregistrer">
                <VariableFields employees={empOptions} />
              </DialogFormAction>
            ) : null
          }
        />
        {variables.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Salarié</Th>
                <Th>Élément</Th>
                <Th num>Quantité</Th>
                <Th num>Taux</Th>
                <Th num>Montant</Th>
                <Th>Origine</Th>
                <Th>Statut</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {variables.map(({ v, firstName, lastName }) => {
                const kind = VARIABLE_KINDS.find((k) => k.value === v.kind)?.label ?? v.kind;
                return (
                  <tr key={v.id}>
                    <Td className="whitespace-nowrap">
                      {lastName} {firstName}
                    </Td>
                    <Td>
                      <p className="text-ink">{v.label}</p>
                      <p className="text-[12.5px] text-ink-3">
                        {kind}
                        {v.note ? ` : ${v.note}` : ""}
                      </p>
                    </Td>
                    <Td num>{v.quantity !== null ? formatNumber(v.quantity) : "-"}</Td>
                    <Td num>{v.rate !== null ? `${formatNumber(v.rate)} %` : "-"}</Td>
                    <Td num>{v.amountCents !== null ? formatCents(v.amountCents) : "-"}</Td>
                    <Td>
                      <Badge>{SOURCE_LABELS[v.source] ?? v.source}</Badge>
                    </Td>
                    <Td>
                      <StatusBadge status={v.status} />
                    </Td>
                    <Td className="whitespace-nowrap text-right">
                      {editable && v.source === "manual" ? (
                        <div className="inline-flex items-center gap-1">
                          <DialogFormAction
                            action={saveVariableAction}
                            fields={{ ...fields, variableId: v.id }}
                            trigger="Modifier"
                            triggerVariant="ghost"
                            triggerSize="sm"
                            title="Modifier la variable"
                            submitLabel="Enregistrer"
                          >
                            <VariableFields
                              employees={empOptions}
                              initial={{ employeeId: v.employeeId, kind: v.kind, label: v.label, quantity: v.quantity, rate: v.rate === null ? null : String(Number(v.rate)), amount: v.amountCents === null ? null : (v.amountCents / 100).toFixed(2), note: v.note }}
                            />
                          </DialogFormAction>
                          <ConfirmAction action={deleteVariableAction} fields={{ ...fields, variableId: v.id }} trigger="Supprimer" variant="ghost" title="Supprimer cette variable ?" description={`${v.label} (${lastName} ${firstName}). Relancez le calcul ensuite.`} confirmLabel="Supprimer" />
                        </div>
                      ) : null}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune variable ce mois" description="Sans variable, chaque salarié est payé sur la base de son salaire contractuel." />
        )}
      </Panel>

      {/* Périmètre */}
      <Panel>
        <PanelHeader
          title={
            <span className="inline-flex items-center gap-2">
              <Scales size={17} /> Périmètre couvert par le moteur
            </span>
          }
          description={ruleSet ? `Règles ${ruleSet.version} : ${ruleSet.label}. Paramètres vérifiés le ${fmtDate(ruleSet.consultedAt)} sur les sources officielles.` : "Aucun jeu de règles ne couvre ce mois : les bulletins seront bloqués."}
        />
        <div className="grid gap-8 px-5 py-4 md:grid-cols-2">
          <div>
            <h3 className="mb-2 text-[13px] font-semibold text-ink">Calculé par Next RH</h3>
            <dl className="space-y-2 text-[13px]">
              {payrollScope.covered.map((c) => (
                <div key={c.label}>
                  <dt className="font-medium text-ink">{c.label}</dt>
                  <dd className="text-ink-2">{c.detail}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div>
            <h3 className="mb-2 text-[13px] font-semibold text-ink">Non couvert : bulletin bloqué avec explication</h3>
            <dl className="space-y-2 text-[13px]">
              {payrollScope.notCovered.map((c) => (
                <div key={c.label}>
                  <dt className="font-medium text-ink">{c.label}</dt>
                  <dd className="text-ink-2">{c.detail}</dd>
                </div>
              ))}
            </dl>
            <h3 className="mb-2 mt-5 text-[13px] font-semibold text-ink">Conventions de calcul</h3>
            <dl className="space-y-2 text-[13px]">
              {payrollScope.conventions.map((c) => (
                <div key={c.label}>
                  <dt className="font-medium text-ink">{c.label}</dt>
                  <dd className="text-ink-2">{c.detail}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
        {ruleSet ? (
          <details className="border-t border-line px-5 py-3 text-[13px]">
            <summary className="cursor-pointer text-ink-2 hover:text-ink">Paramètres légaux et sources ({Object.keys(ruleSet.params).length})</summary>
            <Table className="mt-3">
              <thead>
                <tr>
                  <Th>Paramètre</Th>
                  <Th>Valeur</Th>
                  <Th>En vigueur depuis</Th>
                  <Th>Sources</Th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(ruleSet.params).map(([k, p]) => (
                  <tr key={k}>
                    <Td className="whitespace-nowrap text-ink">{k}</Td>
                    <Td className="num max-w-[280px] truncate text-[12.5px]" title={JSON.stringify(p.value)}>
                      {typeof p.value === "object" ? JSON.stringify(p.value).slice(0, 90) : String(p.value)}
                    </Td>
                    <Td className="whitespace-nowrap">{fmtDate(p.effectiveFrom)}</Td>
                    <Td className="text-[12.5px]">
                      {p.sources.map((u) => (
                        <a key={u} href={u} target="_blank" rel="noreferrer" className="mr-2 text-accent hover:underline">
                          {new URL(u).hostname.replace("www.", "")}
                        </a>
                      ))}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </details>
        ) : null}
      </Panel>
      {scope.suspended.length ? (
        <Notice tone="warn" className="mt-4">
          {scope.suspended.length} salarié(s) au contrat suspendu ne reçoivent pas de bulletin ce mois.
        </Notice>
      ) : null}
    </div>
  );
}
