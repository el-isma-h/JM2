import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { DownloadSimple } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { downloadLinkAction } from "@/server/actions/payroll";
import type { EngineCumuls, PayslipInput, PayslipLine, PayslipResult, PayslipTotals } from "@/server/payroll/engine/types";
import type { Variance } from "@/server/payroll/variance";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { StatusBadge } from "@/components/ui/badge";
import { FadeIn } from "@/components/ui/motion";
import { formatCents, formatNumber } from "@/lib/money";
import { fmtDate, monthLabel } from "@/lib/dates";
import { DownloadButton } from "../../../_components/forms";

const SECTIONS: { key: string; label: string }[] = [
  { key: "brut", label: "Rémunération brute" },
  { key: "info", label: "Absences rémunérées et informations" },
  { key: "sante", label: "Santé" },
  { key: "atmp", label: "Accidents du travail - maladies professionnelles" },
  { key: "retraite", label: "Retraite" },
  { key: "famille", label: "Famille" },
  { key: "chomage", label: "Assurance chômage" },
  { key: "autres_contributions", label: "Autres contributions dues par l'employeur" },
  { key: "csg", label: "CSG et CRDS" },
  { key: "exonerations", label: "Exonérations, écrêtements et allègements" },
  { key: "net", label: "Éléments du net" },
  { key: "impot", label: "Impôt sur le revenu" },
];

const pct = (r: string | null) => (r ? `${formatNumber(r, r.includes(".") && r.split(".")[1].length > 2 ? r.split(".")[1].length : 2)}` : "");

export default async function PayslipPage({ params }: { params: Promise<{ companyId: string; periodId: string; payslipId: string }> }) {
  const { companyId, periodId, payslipId } = await params;
  if (!/^[0-9a-f-]{36}$/.test(payslipId)) notFound();
  const ctx = await guardCompany(companyId, `/app/${companyId}/paie/${periodId}/bulletins/${payslipId}`, "payroll.prepare", "salaries.read");
  const [row] = await db
    .select({ s: schema.payslips, p: schema.payrollPeriods, e: schema.employees })
    .from(schema.payslips)
    .innerJoin(schema.payrollPeriods, eq(schema.payrollPeriods.id, schema.payslips.periodId))
    .innerJoin(schema.employees, eq(schema.employees.id, schema.payslips.employeeId))
    .where(and(eq(schema.payslips.id, payslipId), eq(schema.payslips.periodId, periodId), eq(schema.payrollPeriods.companyId, companyId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!row) notFound();
  const { s, p, e } = row;
  const lines = s.lines as PayslipLine[];
  const input = s.inputs as PayslipInput;
  const cum = s.cumulative as EngineCumuls & { totals?: PayslipTotals; details?: PayslipResult["details"]; pasRuleSetVersion?: string | null };
  const t = cum.totals;
  const variance = s.variance as Partial<Variance>;
  const anomalies = s.anomalies as PayslipResult["anomalies"];
  const label = monthLabel(p.year, p.month);
  const blocked = s.status === "blocked";

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Paie", href: `/app/${companyId}/paie` }, { label, href: `/app/${companyId}/paie/${periodId}` }, { label: `${e.firstName} ${e.lastName}` }]}
        title={`Bulletin de ${e.firstName} ${e.lastName}`}
        description={`Période de ${label}, paiement le ${fmtDate(p.paymentDate)}. ${e.jobTitle ?? ""}`}
        actions={
          <>
            <StatusBadge status={s.status} />
            {s.documentId ? (
              <DownloadButton action={downloadLinkAction} companyId={companyId} documentId={s.documentId} size="md">
                <DownloadSimple size={16} /> Télécharger le PDF
              </DownloadButton>
            ) : null}
          </>
        }
      />
      {!s.documentId && !blocked ? <Notice tone="info" className="mb-4">Le PDF sera disponible après validation et finalisation de la période.</Notice> : null}
      {blocked ? (
        <Notice tone="danger" title="Bulletin bloqué" className="mb-6">
          {anomalies
            .filter((a) => a.severity === "blocking")
            .map((a) => (
              <p key={a.code + a.explanation} className="mt-1">
                <span className="font-medium">{a.title}.</span> {a.explanation}
              </p>
            ))}
        </Notice>
      ) : null}

      {t && !blocked ? (
        <FadeIn>
          <div className="mb-6 grid grid-cols-2 gap-6 border-b border-line pb-5 md:grid-cols-5">
            <Stat label="Brut" value={formatCents(t.grossCents)} />
            <Stat label="Net avant impôt" value={formatCents(t.netBeforeTaxCents)} />
            <Stat label="Impôt prélevé" value={formatCents(t.pasAmountCents)} hint={`Taux ${t.pasKind === "neutre" ? "non personnalisé" : "personnalisé"} ${formatNumber(t.pasRate, 1)} %`} />
            <Stat label="Net payé" value={formatCents(t.netPaidCents)} />
            <Stat label="Coût employeur" value={formatCents(t.employerCostCents)} hint={`Allègements : ${formatCents(t.employerReliefCents)}`} />
          </div>
        </FadeIn>
      ) : null}

      {!blocked ? (
        <Panel className="mb-6">
          <PanelHeader title="Lignes du bulletin" description="Survolez une ligne pour lire la règle d'arrondi appliquée. Part salariale : retenue sur le salaire ; part patronale : charge de l'employeur." />
          <Table>
            <thead>
              <tr>
                <Th>Rubrique</Th>
                <Th num>Base</Th>
                <Th num>Taux salarial</Th>
                <Th num>Part salariale</Th>
                <Th num>Taux patronal</Th>
                <Th num>Part patronale</Th>
              </tr>
            </thead>
            <tbody>
              {SECTIONS.map((sec) => {
                const ls = lines.filter((l) => l.section === sec.key);
                if (!ls.length) return null;
                return [
                  <tr key={`h-${sec.key}`}>
                    <Td colSpan={6} className="bg-bg-sunken pt-3 text-[12.5px] font-medium text-ink-2">
                      {sec.label}
                    </Td>
                  </tr>,
                  ...ls.map((l, i) => (
                    <tr key={`${sec.key}-${i}`} title={l.rounding}>
                      <Td>
                        <p className="text-ink">{l.label}</p>
                        <p className="text-[12px] text-ink-3">{l.rounding}</p>
                      </Td>
                      <Td num>{l.section === "brut" ? (l.quantity ? formatNumber(l.quantity) : "") : l.base !== null ? formatCents(l.base) : ""}</Td>
                      <Td num>{l.section === "brut" ? (l.rate_employee ? formatNumber(l.rate_employee, 4) : "") : pct(l.rate_employee)}</Td>
                      <Td num>{l.amount_employee ? formatCents(l.section === "brut" || l.section === "net" ? l.amount_employee : -l.amount_employee) : ""}</Td>
                      <Td num>{pct(l.rate_employer)}</Td>
                      <Td num>{l.amount_employer ? formatCents(l.amount_employer) : ""}</Td>
                    </tr>
                  )),
                ];
              })}
            </tbody>
            {t ? (
              <tfoot>
                <tr>
                  <Td className="font-semibold">Total des cotisations et contributions</Td>
                  <Td />
                  <Td />
                  <Td num className="font-semibold">{formatCents(-t.employeeContribCents)}</Td>
                  <Td />
                  <Td num className="font-semibold">{formatCents(t.employerContribCents)}</Td>
                </tr>
              </tfoot>
            ) : null}
          </Table>
        </Panel>
      ) : null}

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Totaux et cumuls" />
          <div className="px-5 py-4">
            {t ? (
              <KeyValue
                items={[
                  { k: "Montant net social", v: <span className="num">{formatCents(t.netSocialCents)}</span> },
                  { k: "Net imposable", v: <span className="num">{formatCents(t.netTaxableCents)}</span> },
                  { k: "Heures supplémentaires exonérées (net)", v: <span className="num">{formatCents(t.hsExemptNetCents)}</span> },
                  { k: "Heures payées", v: <span className="num">{formatNumber(t.hoursWorked)}</span> },
                  { k: `Cumul brut ${cum.year}`, v: <span className="num">{formatCents(cum.grossCents)}</span> },
                  { k: "Cumul net imposable", v: <span className="num">{formatCents(cum.netTaxableCents)}</span> },
                  { k: "Cumul impôt prélevé", v: <span className="num">{formatCents(cum.pasCents)}</span> },
                  { k: "Cumul net payé", v: <span className="num">{formatCents(cum.netPaidCents)}</span> },
                  { k: "Réduction générale cumulée", v: cum.rgdu ? <span className="num">{formatCents(cum.rgdu.reductionCents)}</span> : "-" },
                ]}
              />
            ) : (
              <p className="text-[13.5px] text-ink-2">Aucun total : le bulletin est bloqué.</p>
            )}
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Écart avec le mois précédent" />
          <div className="space-y-1.5 px-5 py-4 text-[13.5px] text-ink-2">
            {variance.hasPrevious ? (
              <p className="text-ink">
                Brut <span className="num">{formatCents(variance.grossDeltaCents ?? 0, { signed: true })}</span>
                {variance.grossDeltaPct !== null && variance.grossDeltaPct !== undefined ? ` (${String(variance.grossDeltaPct).replace(".", ",")} %)` : ""}, net payé <span className="num">{formatCents(variance.netPaidDeltaCents ?? 0, { signed: true })}</span>.
              </p>
            ) : null}
            {(variance.explanations ?? []).map((x) => (
              <p key={x}>{x}</p>
            ))}
          </div>
        </Panel>
      </div>

      <Panel className="mb-6">
        <PanelHeader title="Entrées du calcul" description="Données figées au moment du calcul : elles permettent de reproduire le bulletin à l'identique." />
        <div className="grid gap-6 px-5 py-4 lg:grid-cols-2">
          <KeyValue
            items={[
              { k: "Règles légales", v: `${s.ruleSetVersion}${cum.pasRuleSetVersion && cum.pasRuleSetVersion !== s.ruleSetVersion ? ` (barème d'impôt ${cum.pasRuleSetVersion})` : ""}` },
              { k: "Version du moteur", v: input.engineVersion },
              { k: "Empreinte du calcul", v: <code className="num break-all text-[12px]">{s.computeHash}</code> },
              { k: "Contrat", v: input.contract ? `${input.contract.type}, ${input.contract.category === "cadre" ? "cadre" : "non-cadre"}, ${input.contract.workTimeMode === "forfait_jours" ? `forfait ${input.contract.annualDays ?? 218} jours` : `${formatNumber(input.contract.weeklyHours)} h/semaine, ${formatNumber(input.contract.monthlyHours)} h/mois`}, depuis le ${fmtDate(input.contract.startDate)}${input.contract.endDate ? ` jusqu'au ${fmtDate(input.contract.endDate)}` : ""}` : "aucun" },
              { k: "Rémunération", v: input.compensations.length ? input.compensations.map((c) => `${formatCents(c.grossAmountCents)} ${c.basis === "monthly" ? "par mois" : c.basis === "hourly" ? "par heure" : "par an"} depuis le ${fmtDate(c.effectiveDate)}`).join(" ; ") : "aucune" },
              { k: "Taux d'impôt", v: input.pas ? `${formatNumber(input.pas.rate)} %${input.pas.isNeutral ? " (neutre)" : ""} depuis le ${fmtDate(input.pas.effectiveDate)}` : "aucun : barème neutre" },
            ]}
          />
          <KeyValue
            items={[
              { k: "Tranche d'effectif", v: input.company.headcountBracket ?? "à confirmer" },
              { k: "Taux AT/MP", v: input.company.atRate ? `${formatNumber(input.company.atRate)} %` : "à confirmer" },
              { k: "Versement mobilité", v: input.company.mobilityRate ? `${formatNumber(input.company.mobilityRate)} %` : "à confirmer" },
              { k: "Mutuelle", v: input.company.mutuelle ? `${input.company.mutuelle.name} : ${formatCents(input.company.mutuelle.employerCents)} employeur, ${formatCents(input.company.mutuelle.employeeCents)} salarié` : input.company.mutuelleConfigured ? "aucune" : "à confirmer" },
              { k: "Prévoyance", v: input.company.prevoyance ? input.company.prevoyance.name : input.company.prevoyanceConfigured ? "aucune" : "à confirmer" },
              { k: "Cumuls repris", v: input.cumulsBefore.source === "none" ? "aucun (premier mois de l'année)" : `${input.cumulsBefore.source === "carryover" ? "reprise" : "bulletins Next RH"} jusqu'au mois ${input.cumulsBefore.throughMonth} : brut ${formatCents(input.cumulsBefore.grossCents)}` },
            ]}
          />
        </div>
        {input.variables.length ? (
          <Table className="border-t border-line">
            <thead>
              <tr>
                <Th>Variable prise en compte</Th>
                <Th num>Quantité</Th>
                <Th num>Taux</Th>
                <Th num>Montant</Th>
                <Th>Origine</Th>
              </tr>
            </thead>
            <tbody>
              {input.variables.map((v) => (
                <tr key={v.id}>
                  <Td>
                    {v.label}
                    {v.note ? <span className="text-ink-3"> : {v.note}</span> : null}
                  </Td>
                  <Td num>{v.quantity ?? "-"}</Td>
                  <Td num>{v.rate ? `${v.rate} %` : "-"}</Td>
                  <Td num>{v.amountCents !== null ? formatCents(v.amountCents) : "-"}</Td>
                  <Td>{v.source}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : null}
      </Panel>

      {anomalies.length && !blocked ? (
        <Panel>
          <PanelHeader title="Remarques du moteur sur ce bulletin" />
          <Table>
            <tbody>
              {anomalies.map((a) => (
                <tr key={a.code + a.explanation}>
                  <Td className="w-32">
                    <StatusBadge status={a.severity} />
                  </Td>
                  <Td>
                    <p className="font-medium text-ink">{a.title}</p>
                    <p className="text-[13px] text-ink-2">{a.explanation}</p>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>
      ) : null}
      {ctx.company.isDemo ? <p className="mt-4 text-[12.5px] text-ink-3">Données de démonstration fictives.</p> : null}
    </div>
  );
}
