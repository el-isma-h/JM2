import Link from "next/link";
import { notFound } from "next/navigation";
import { ChatsCircle, Plus } from "@phosphor-icons/react/ssr";
import { guardCompany } from "@/server/guard";
import { getConversationMessages, listConversations } from "@/server/assistant/orchestrator";
import { allowedTools, TOOL_LABELS } from "@/server/assistant/policy";
import { integrations } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { cn } from "@/lib/utils";
import { PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import { AssistantChat } from "@/components/assistant/assistant-chat";
import type { ChatMessage } from "@/components/assistant/message-view";

export default async function AssistantPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ c?: string }> }) {
  const { companyId } = await params;
  const { c } = await searchParams;
  const base = `/app/${companyId}/assistant`;
  const ctx = await guardCompany(companyId, base);
  if (ctx.role === "employee") notFound();
  const [conversations, current] = await Promise.all([listConversations(ctx), c ? getConversationMessages(ctx, c) : Promise.resolve(null)]);
  if (c && !current) notFound();
  const tools = allowedTools(ctx.permissions);
  const initial: ChatMessage[] = (current?.messages ?? [])
    .filter((m) => m.role !== "tool")
    .map((m) => ({ id: m.id, role: m.role, content: m.content, meta: (m.meta ?? {}) as ChatMessage["meta"], createdAt: m.createdAt.toISOString() }));

  return (
    <>
      <PageHeader
        title="Assistant Next RH"
        description="Il propose un plan, exécute les tâches que vos habilitations autorisent et demande votre confirmation avant toute écriture. Les calculs de paie restent au moteur de paie."
        actions={
          <Button asChild variant="secondary">
            <Link href={base}>
              <Plus size={16} />
              Nouvelle conversation
            </Link>
          </Button>
        }
      />
      <div className="grid gap-5 lg:grid-cols-[280px_minmax(0,1fr)]">
        <div className="space-y-5">
          <Panel>
            <PanelHeader title="Historique" description={`${conversations.length} conversation(s)`} />
            {conversations.length ? (
              <nav aria-label="Conversations" className="max-h-[50dvh] overflow-y-auto py-1">
                {conversations.map((cv) => (
                  <Link
                    key={cv.id}
                    href={`${base}?c=${cv.id}`}
                    aria-current={cv.id === c ? "page" : undefined}
                    className={cn("block px-5 py-2 text-[13px] transition-colors hover:bg-bg-sunken", cv.id === c ? "bg-bg-muted font-medium text-ink" : "text-ink-2")}
                  >
                    <span className="line-clamp-2">{cv.title ?? "Sans titre"}</span>
                    <span className="mt-0.5 block text-[11.5px] text-ink-3">{fmtDateTime(cv.updatedAt)}</span>
                  </Link>
                ))}
              </nav>
            ) : (
              <p className="flex items-center gap-2 px-5 py-4 text-[13px] text-ink-2">
                <ChatsCircle size={16} />
                Aucune conversation.
              </p>
            )}
          </Panel>
          <Panel>
            <PanelHeader title="Ce que l'assistant peut faire pour vous" />
            <div className="px-5 py-4 text-[13px] text-ink-2">
              {tools.length ? (
                <ul className="list-disc space-y-1 pl-5">
                  {tools.map((t) => (
                    <li key={t}>{TOOL_LABELS[t]}</li>
                  ))}
                </ul>
              ) : (
                <p>Votre rôle ne donne accès à aucune action de l&apos;assistant.</p>
              )}
              <p className="mt-3 text-[12px] text-ink-3">
                {integrations.ai()
                  ? "Questions libres traitées par Claude (Anthropic), avec les mêmes outils et les mêmes habilitations. Les données RH ne sont jamais utilisées pour entraîner un modèle."
                  : "Mode règles : configurez ANTHROPIC_API_KEY pour les questions libres."}
              </p>
            </div>
          </Panel>
        </div>
        <Panel className="min-w-0">
          <PanelHeader title={current?.conversation.title ?? "Nouvelle conversation"} />
          <AssistantChat key={c ?? "new"} companyId={companyId} conversationId={current?.conversation.id ?? null} initial={initial} />
        </Panel>
      </div>
    </>
  );
}
