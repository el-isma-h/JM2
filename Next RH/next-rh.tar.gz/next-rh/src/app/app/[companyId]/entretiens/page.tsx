import Link from "next/link";
import { desc, inArray } from "drizzle-orm";
import { ChatsCircle, Plus } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, listEmployees, listMembers, todayIso, usersByIds } from "@/server/hr/common";
import { addDaysIso } from "@/server/hr/calc";
import { createInterviewAction } from "@/server/actions/interviews";
import { DialogForm } from "@/components/hr/action-form";
import { LinkTabs, Person } from "@/components/hr/bits";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { fmtDateTime } from "@/lib/dates";
import { interviewKindTitle, interviewStatus } from "@/components/hr/labels";

export default async function EntretiensPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ vue?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/entretiens`;
  const ctx = await guardCompany(companyId, base, "employees.read");
  const canWrite = ctx.permissions.has("employees.write") || ctx.permissions.has("requests.approve");
  const view = sp.vue === "realises" ? "realises" : "a-venir";
  const [employees, members] = await Promise.all([listEmployees(companyId, { includeLeft: true }), listMembers(companyId)]);
  const ids = employees.map((e) => e.id);
  const empById = new Map(employees.map((e) => [e.id, e]));
  const all = ids.length ? await db.select().from(schema.interviews).where(inArray(schema.interviews.employeeId, ids)).orderBy(desc(schema.interviews.scheduledAt)) : [];
  const upcoming = all.filter((i) => i.status === "planned").sort((a, b) => (a.scheduledAt?.getTime() ?? Infinity) - (b.scheduledAt?.getTime() ?? Infinity));
  const past = all.filter((i) => i.status !== "planned");
  const shown = view === "realises" ? past : upcoming;
  const conductors = await usersByIds(shown.map((i) => i.conductedBy));
  const now = todayIso();

  // Entretien professionnel tous les 2 ans (art. L6315-1) : salariés sans entretien professionnel réalisé depuis 24 mois.
  const twoYearsAgo = new Date(`${addDaysIso(now, -730)}T00:00:00`);
  const lastPro = new Map<string, Date>();
  for (const i of all) if (i.kind === "professionnel" && i.status === "done" && i.scheduledAt) {
    const prev = lastPro.get(i.employeeId);
    if (!prev || i.scheduledAt > prev) lastPro.set(i.employeeId, i.scheduledAt);
  }
  const duePro = employees.filter((e) => e.status === "active" && e.hireDate && new Date(e.hireDate) < twoYearsAgo && !(lastPro.get(e.id) && lastPro.get(e.id)! > twoYearsAgo) && !upcoming.some((u) => u.employeeId === e.id && u.kind === "professionnel"));

  return (
    <>
      <PageHeader
        title="Entretiens"
        description="Planification, objectifs et compte rendu des entretiens annuels, professionnels et de fin de période d'essai."
        actions={
          canWrite && employees.length ? (
            <DialogForm trigger={<><Plus size={16} /> Planifier</>} title="Planifier un entretien" action={createInterviewAction} hidden={{ companyId }} submitLabel="Planifier" wide>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Salarié" required htmlFor="iv-emp">
                  <Select id="iv-emp" name="employeeId" required defaultValue="">
                    <option value="" disabled>
                      Choisir
                    </option>
                    {employees
                      .filter((e) => e.status !== "left")
                      .map((e) => (
                        <option key={e.id} value={e.id}>
                          {fullName(e)}
                        </option>
                      ))}
                  </Select>
                </Field>
                <Field label="Type" required htmlFor="iv-kind">
                  <Select id="iv-kind" name="kind" required>
                    {schema.interviewKindEnum.enumValues.map((k) => (
                      <option key={k} value={k}>
                        {interviewKindTitle[k]}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Date et heure" htmlFor="iv-when">
                  <Input id="iv-when" name="scheduledAt" type="datetime-local" />
                </Field>
                <Field label="Mené par" htmlFor="iv-by">
                  <Select id="iv-by" name="conductedBy" defaultValue={ctx.user.id}>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.firstName} {m.lastName}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Objectifs à aborder" htmlFor="iv-obj" className="sm:col-span-2" help="Un objectif par ligne.">
                  <Textarea id="iv-obj" name="objectives" />
                </Field>
              </div>
            </DialogForm>
          ) : null
        }
      />
      {duePro.length ? (
        <p className="mb-4 rounded-[var(--radius-sm)] bg-warn-soft px-4 py-3 text-[13.5px] text-warn-ink">
          {duePro.length} salarié(s) sans entretien professionnel depuis plus de deux ans : {duePro.slice(0, 4).map(fullName).join(", ")}
          {duePro.length > 4 ? "…" : ""}. Il est obligatoire tous les deux ans.
        </p>
      ) : null}
      <LinkTabs
        label="Filtre des entretiens"
        current={view}
        items={[
          { key: "a-venir", label: "Planifiés", href: base, count: upcoming.length },
          { key: "realises", label: "Réalisés ou annulés", href: `${base}?vue=realises` },
        ]}
      />
      <Panel>
        {shown.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Salarié</Th>
                <Th>Type</Th>
                <Th>Date</Th>
                <Th>Mené par</Th>
                <Th num>Objectifs</Th>
                <Th>Statut</Th>
              </tr>
            </thead>
            <tbody>
              {shown.map((i) => {
                const e = empById.get(i.employeeId)!;
                const st = interviewStatus(i.status);
                const objectives = (i.objectives as { done: boolean }[]) ?? [];
                const late = i.status === "planned" && i.scheduledAt && i.scheduledAt.toISOString().slice(0, 10) < now;
                return (
                  <tr key={i.id}>
                    <Td>
                      <Person first={e.firstName} last={e.lastName} sub={e.jobTitle ?? undefined} />
                    </Td>
                    <Td>
                      <Link href={`${base}/${i.id}`} className="font-medium text-ink hover:underline">
                        {interviewKindTitle[i.kind]}
                      </Link>
                    </Td>
                    <Td className="whitespace-nowrap">{i.scheduledAt ? fmtDateTime(i.scheduledAt) : <span className="text-ink-3">À fixer</span>}</Td>
                    <Td>{i.conductedBy ? conductors.get(i.conductedBy) ?? "-" : "-"}</Td>
                    <Td num>
                      {objectives.filter((o) => o.done).length} / {objectives.length}
                    </Td>
                    <Td>{late ? <Badge tone="danger">Date passée</Badge> : <Badge tone={st.tone}>{st.label}</Badge>}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState icon={<ChatsCircle size={28} />} title={view === "a-venir" ? "Aucun entretien planifié" : "Aucun entretien réalisé"} description="Planifiez les entretiens annuels et professionnels pour en garder la trace et le compte rendu." />
        )}
      </Panel>
    </>
  );
}
