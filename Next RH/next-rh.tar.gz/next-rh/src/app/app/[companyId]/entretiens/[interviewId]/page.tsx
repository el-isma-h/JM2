import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, UUID_RE, usersByIds } from "@/server/hr/common";
import { updateInterviewAction } from "@/server/actions/interviews";
import { ActionForm } from "@/components/hr/action-form";
import { Person } from "@/components/hr/bits";
import { interviewKindTitle, interviewStatus } from "@/components/hr/labels";
import { KeyValue, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Badge } from "@/components/ui/badge";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { fmtDateTime } from "@/lib/dates";
import { format } from "date-fns";

export default async function InterviewPage({ params }: { params: Promise<{ companyId: string; interviewId: string }> }) {
  const { companyId, interviewId } = await params;
  const ctx = await guardCompany(companyId, `/app/${companyId}/entretiens/${interviewId}`, "employees.read");
  if (!UUID_RE.test(interviewId)) notFound();
  const [row] = await db
    .select({ i: schema.interviews, e: schema.employees })
    .from(schema.interviews)
    .innerJoin(schema.employees, eq(schema.employees.id, schema.interviews.employeeId))
    .where(and(eq(schema.interviews.id, interviewId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!row) notFound();
  const { i, e } = row;
  const canWrite = ctx.permissions.has("employees.write") || ctx.permissions.has("requests.approve");
  const objectives = (i.objectives as { label: string; done: boolean }[]) ?? [];
  const users = await usersByIds([i.conductedBy]);
  const st = interviewStatus(i.status);

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Entretiens", href: `/app/${companyId}/entretiens` }, { label: fullName(e) }]}
        title={`${interviewKindTitle[i.kind]} : ${fullName(e)}`}
        actions={<Badge tone={st.tone}>{st.label}</Badge>}
      />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,2fr)]">
        <Panel className="self-start">
          <PanelHeader title="Informations" />
          <div className="space-y-4 p-5">
            <Person first={e.firstName} last={e.lastName} sub={e.jobTitle ?? undefined} />
            <KeyValue
              items={[
                { k: "Date", v: i.scheduledAt ? fmtDateTime(i.scheduledAt) : "À fixer" },
                { k: "Mené par", v: i.conductedBy ? users.get(i.conductedBy) ?? "-" : "-" },
                { k: "Objectifs", v: `${objectives.filter((o) => o.done).length} atteint(s) sur ${objectives.length}` },
              ]}
            />
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Objectifs et compte rendu" description="Le compte rendu est requis pour marquer l'entretien comme réalisé." />
          <div className="p-5">
            {canWrite ? (
              <ActionForm action={updateInterviewAction} hidden={{ companyId, interviewId: i.id }} resetOnSuccess={false} submitLabel="Enregistrer">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Statut" htmlFor="iv-status">
                    <Select id="iv-status" name="status" defaultValue={i.status}>
                      <option value="planned">Planifié</option>
                      <option value="done">Réalisé</option>
                      <option value="cancelled">Annulé</option>
                    </Select>
                  </Field>
                  <Field label="Date et heure" htmlFor="iv-when">
                    <Input id="iv-when" name="scheduledAt" type="datetime-local" defaultValue={i.scheduledAt ? format(i.scheduledAt, "yyyy-MM-dd'T'HH:mm") : ""} />
                  </Field>
                </div>
                <fieldset>
                  <legend className="mb-2 text-[13px] font-medium text-ink">Objectifs</legend>
                  {objectives.length ? (
                    <div className="space-y-2">
                      {objectives.map((o, idx) => (
                        <div key={idx} className="flex items-center gap-3">
                          <Checkbox name={`objectiveDone_${idx}`} defaultChecked={o.done} aria-label={`Atteint : ${o.label}`} />
                          <label className="sr-only" htmlFor={`obj-${idx}`}>
                            Objectif {idx + 1}
                          </label>
                          <Input id={`obj-${idx}`} name="objective" defaultValue={o.label} className="h-8" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[13px] text-ink-3">Aucun objectif pour l&apos;instant.</p>
                  )}
                  <Field label="Ajouter des objectifs" htmlFor="iv-new" help="Un par ligne. Videz un objectif existant pour le retirer." className="mt-3">
                    <Textarea id="iv-new" name="newObjectives" className="min-h-16" />
                  </Field>
                </fieldset>
                <Field label="Compte rendu" htmlFor="iv-notes" help="Points abordés, souhaits d'évolution, besoins de formation, décisions.">
                  <Textarea id="iv-notes" name="notes" defaultValue={i.notes ?? ""} className="min-h-48" />
                </Field>
              </ActionForm>
            ) : (
              <div className="space-y-4 text-[13.5px]">
                <ul className="space-y-1">
                  {objectives.map((o, idx) => (
                    <li key={idx}>
                      {o.done ? "Atteint : " : "En cours : "}
                      {o.label}
                    </li>
                  ))}
                </ul>
                <p className="whitespace-pre-wrap text-ink">{i.notes ?? "Pas encore de compte rendu."}</p>
              </div>
            )}
          </div>
        </Panel>
      </div>
    </>
  );
}
