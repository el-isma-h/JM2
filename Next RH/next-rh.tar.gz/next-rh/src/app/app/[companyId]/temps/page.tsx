import Link from "next/link";
import { and, eq, inArray } from "drizzle-orm";
import { Clock } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { activeContract, fullName, listEmployees, monthParam, parseMonthParam, UUID_RE } from "@/server/hr/common";
import { computeOvertime, type TimesheetEntry } from "@/server/hr/calc";
import { decideTimesheetAction, reopenTimesheetAction, saveTimesheetAction } from "@/server/actions/time";
import { ActionButton, ActionForm, SubmitButton } from "@/components/hr/action-form";
import { MonthNav, Person } from "@/components/hr/bits";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { daysInMonth, fmtDate, frenchHolidays } from "@/lib/dates";
import { formatNumber } from "@/lib/money";
import { cn } from "@/lib/utils";

const wdNames = ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."];

export default async function TempsPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ mois?: string; salarie?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/temps`;
  const ctx = await guardCompany(companyId, base, "employees.read");
  const canEdit = ctx.permissions.has("requests.approve");
  const { year, month } = parseMonthParam(sp.mois);
  const ym = monthParam(year, month);
  const employees = await listEmployees(companyId);
  const ids = employees.map((e) => e.id);
  const sheets = ids.length
    ? await db
        .select()
        .from(schema.timesheets)
        .where(and(inArray(schema.timesheets.employeeId, ids), eq(schema.timesheets.year, year), eq(schema.timesheets.month, month)))
    : [];
  const byEmp = new Map(sheets.map((s) => [s.employeeId, s]));
  const selected = sp.salarie && UUID_RE.test(sp.salarie) ? employees.find((e) => e.id === sp.salarie) : undefined;

  const header = (
    <PageHeader
      title="Temps de travail"
      description="Feuilles de temps mensuelles saisies jour par jour. Les heures au-delà de la durée hebdomadaire du contrat sont signalées comme heures supplémentaires et transmises à la paie à la validation."
      actions={<MonthNav base={base} year={year} month={month} params={{ salarie: selected?.id }} />}
    />
  );

  if (!employees.length) {
    return (
      <>
        {header}
        <Panel>
          <EmptyState icon={<Clock size={28} />} title="Aucun salarié" description="Ajoutez des salariés pour saisir leurs feuilles de temps." action={<Button asChild><Link href={`/app/${companyId}/salaries`}>Ajouter des salariés</Link></Button>} />
        </Panel>
      </>
    );
  }

  const toValidate = sheets.filter((s) => s.status === "pending");

  return (
    <>
      {header}
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.25fr)]">
        <Panel className="self-start">
          <PanelHeader title="Feuilles du mois" description={`${sheets.length} feuille(s) sur ${employees.length} salarié(s), ${toValidate.length} à valider.`} />
          <Table>
            <thead>
              <tr>
                <Th>Salarié</Th>
                <Th>Statut</Th>
                <Th num>Heures</Th>
                <Th num>Heures sup</Th>
              </tr>
            </thead>
            <tbody>
              {employees.map((e) => {
                const s = byEmp.get(e.id);
                const active = selected?.id === e.id;
                return (
                  <tr key={e.id} className={cn(active && "[&>td]:bg-accent-soft")}>
                    <Td>
                      <Person first={e.firstName} last={e.lastName} href={`${base}?mois=${ym}&salarie=${e.id}`} sub={e.jobTitle ?? undefined} />
                    </Td>
                    <Td>{s ? <StatusBadge status={s.status} /> : <span className="text-ink-3">Non saisie</span>}</Td>
                    <Td num>{s ? formatNumber(s.totalHours, 2) : "-"}</Td>
                    <Td num className={cn(s && Number(s.overtimeHours) > 0 && "font-medium text-warn-ink")}>{s ? formatNumber(s.overtimeHours, 2) : "-"}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Panel>

        {selected ? (
          <TimesheetEditor companyId={companyId} employee={selected} year={year} month={month} sheet={byEmp.get(selected.id) ?? null} canEdit={canEdit} />
        ) : (
          <Panel className="self-start">
            <EmptyState title="Choisissez un salarié" description="Sélectionnez un salarié dans la liste pour saisir ou valider sa feuille de temps du mois." />
          </Panel>
        )}
      </div>
    </>
  );
}

async function TimesheetEditor({
  companyId,
  employee,
  year,
  month,
  sheet,
  canEdit,
}: {
  companyId: string;
  employee: Awaited<ReturnType<typeof listEmployees>>[number];
  year: number;
  month: number;
  sheet: typeof schema.timesheets.$inferSelect | null;
  canEdit: boolean;
}) {
  const ym = monthParam(year, month);
  const contract = await activeContract(employee.id, `${ym}-15`);
  const weekly = contract ? Number(contract.weeklyHours) : 35;
  const forfait = contract?.workTimeMode === "forfait_jours";
  const entries = ((sheet?.entries as TimesheetEntry[]) ?? []).reduce<Record<string, number>>((acc, e) => ((acc[e.date] = e.hours), acc), {});
  const holidays = new Set(frenchHolidays(year));
  const n = daysInMonth(year, month);
  const days = Array.from({ length: n }, (_, i) => {
    const iso = `${ym}-${String(i + 1).padStart(2, "0")}`;
    const wd = new Date(year, month - 1, i + 1).getDay();
    return { iso, wd, weekend: wd === 0 || wd === 6, holiday: holidays.has(iso) };
  });
  const locked = sheet?.status === "approved" || sheet?.status === "pending";
  const ot = computeOvertime((sheet?.entries as TimesheetEntry[]) ?? [], weekly, year, month);
  const hidden = { companyId, employeeId: employee.id, year: String(year), month: String(month) };

  return (
    <Panel className="self-start">
      <PanelHeader
        title={`Feuille de ${fullName(employee)}`}
        description={contract ? `Contrat ${contract.type}, ${formatNumber(weekly, 2)} h par semaine${forfait ? ", forfait jours (pas d'heures supplémentaires)" : ""}.` : "Aucun contrat renseigné : 35 h par semaine retenues par défaut."}
        actions={sheet ? <StatusBadge status={sheet.status} /> : <Badge>Non saisie</Badge>}
      />
      <div className="p-5">
        {sheet?.status === "pending" && canEdit ? (
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-[var(--radius-sm)] bg-warn-soft px-4 py-3 text-[13.5px] text-warn-ink">
            <span>
              Soumise : {formatNumber(sheet.totalHours, 2)} h dont {formatNumber(sheet.overtimeHours, 2)} h supplémentaires.
            </span>
            <span className="flex gap-1.5">
              <ActionButton action={decideTimesheetAction} hidden={{ companyId, timesheetId: sheet.id, decision: "approve" }} label="Valider" variant="primary" />
              <ActionButton action={decideTimesheetAction} hidden={{ companyId, timesheetId: sheet.id, decision: "reject" }} label="Refuser" variant="ghost" />
            </span>
          </div>
        ) : null}
        {sheet?.status === "approved" ? (
          <Notice tone="ok" className="mb-4">
            Validée le {fmtDate(sheet.decidedAt)}. {Number(sheet.overtimeHours) > 0 ? `${formatNumber(sheet.overtimeHours, 2)} h supplémentaires transmises à la paie.` : "Aucune heure supplémentaire."}
            {canEdit ? (
              <span className="mt-2 block">
                <ActionButton
                  action={reopenTimesheetAction}
                  hidden={{ companyId, timesheetId: sheet.id }}
                  label="Rouvrir pour correction"
                  variant="secondary"
                  confirm={{ title: "Rouvrir la feuille", description: "La variable d'heures supplémentaires sera retirée de la paie, ou régularisée le mois suivant si la paie est déjà validée.", confirmLabel: "Rouvrir" }}
                />
              </span>
            ) : null}
          </Notice>
        ) : null}
        <ActionForm action={saveTimesheetAction} hidden={hidden} submitLabel={null} resetOnSuccess={false}>
          <div className="overflow-x-auto">
            <table className="data-table text-[13px]">
              <caption className="sr-only">Heures travaillées par jour</caption>
              <thead>
                <tr>
                  <th scope="col">Jour</th>
                  <th scope="col" className="num">
                    Heures
                  </th>
                  <th scope="col">Remarque</th>
                </tr>
              </thead>
              <tbody>
                {days.map((d) => (
                  <tr key={d.iso} className={cn((d.weekend || d.holiday) && "[&>td]:bg-bg-sunken", d.wd === 1 && "[&>td]:border-t [&>td]:border-t-line-strong")}>
                    <td className="whitespace-nowrap py-1.5">
                      <label htmlFor={`h-${d.iso}`} className="text-ink">
                        <span className="inline-block w-9 text-ink-3">{wdNames[d.wd]}</span>
                        {fmtDate(d.iso, "d MMMM")}
                      </label>
                    </td>
                    <td className="py-1 text-right">
                      <input
                        id={`h-${d.iso}`}
                        name={`h_${d.iso}`}
                        inputMode="decimal"
                        defaultValue={entries[d.iso] !== undefined ? String(entries[d.iso]).replace(".", ",") : ""}
                        disabled={locked || !canEdit}
                        placeholder={d.weekend || d.holiday ? "" : "0"}
                        className="num h-8 w-20 rounded-[var(--radius-sm)] border border-line-strong bg-bg-elev px-2 text-right text-[13px] focus:border-accent focus:outline-none focus:ring-2 focus:ring-focus/35 disabled:bg-bg-sunken disabled:text-ink-3"
                      />
                    </td>
                    <td className="py-1.5 text-[12px] text-ink-3">{d.holiday ? "Jour férié" : d.weekend ? "Week-end" : ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!locked && canEdit ? (
            <div className="flex flex-wrap gap-2">
              <SubmitButton name="intent" value="draft" variant="secondary">
                Enregistrer le brouillon
              </SubmitButton>
              <SubmitButton name="intent" value="submit">
                Soumettre à validation
              </SubmitButton>
            </div>
          ) : null}
        </ActionForm>

        {sheet && ot.totalHours > 0 ? (
          <div className="mt-6">
            <h3 className="mb-2 text-[13.5px] font-semibold text-ink">Décompte par semaine</h3>
            <Table>
              <thead>
                <tr>
                  <Th>Semaine</Th>
                  <Th num>Heures</Th>
                  <Th num>Seuil contractuel</Th>
                  <Th num>Heures sup</Th>
                </tr>
              </thead>
              <tbody>
                {ot.weeks.map((w) => (
                  <tr key={w.key}>
                    <Td>{w.label.replace(/\d{4}-\d{2}-\d{2}/, (m) => fmtDate(m, "d MMMM"))}</Td>
                    <Td num>{formatNumber(w.hours, 2)}</Td>
                    <Td num>{formatNumber(w.threshold, 2)}</Td>
                    <Td num className={cn(w.overtime > 0 && "font-medium text-warn-ink")}>{formatNumber(forfait ? 0 : w.overtime, 2)}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <p className="mt-2 text-[12.5px] text-ink-3">
              {forfait
                ? "Forfait jours : les heures ne génèrent pas d'heures supplémentaires."
                : `Majoration légale à défaut d'accord : 25 % pour les 8 premières heures de la semaine (${formatNumber(ot.at25, 2)} h), 50 % au-delà (${formatNumber(ot.at50, 2)} h). Les semaines à cheval sur deux mois ont un seuil proratisé.`}
            </p>
          </div>
        ) : null}
      </div>
    </Panel>
  );
}
