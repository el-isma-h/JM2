import { desc, inArray } from "drizzle-orm";
import { GraduationCap, Paperclip, Plus } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, listEmployees, todayIso } from "@/server/hr/common";
import { addDaysIso, daysUntil } from "@/server/hr/calc";
import { TRAINING_KINDS, TRAINING_STATUSES, trainingKind, trainingStatus } from "@/server/hr/trainings";
import { createTrainingAction, updateTrainingAction } from "@/server/actions/trainings";
import { proofLinkAction } from "@/server/actions/requests";
import { ActionButton, DialogForm } from "@/components/hr/action-form";
import { DueIn, LinkTabs, Person } from "@/components/hr/bits";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Field, Input, Select } from "@/components/ui/field";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";

export default async function FormationsPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ vue?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/formations`;
  const ctx = await guardCompany(companyId, base, "employees.read");
  const canWrite = ctx.permissions.has("employees.write") || ctx.permissions.has("requests.approve");
  const view = sp.vue === "habilitations" || sp.vue === "toutes" ? sp.vue : "demandes";
  const employees = await listEmployees(companyId, { includeLeft: true });
  const ids = employees.map((e) => e.id);
  const empById = new Map(employees.map((e) => [e.id, e]));
  const all = ids.length ? await db.select().from(schema.trainings).where(inArray(schema.trainings.employeeId, ids)).orderBy(desc(schema.trainings.createdAt)) : [];
  const today = todayIso();
  const soon = addDaysIso(today, 90);
  const requests = all.filter((t) => t.status === "requested" || t.status === "approved" || t.status === "planned");
  const expiring = all.filter((t) => t.expiresAt && t.status !== "cancelled" && t.status !== "rejected").sort((a, b) => a.expiresAt!.localeCompare(b.expiresAt!));
  const alerts = expiring.filter((t) => t.expiresAt! <= soon);
  const shown = view === "habilitations" ? expiring : view === "toutes" ? all : requests;
  const yearCost = all.filter((t) => t.status === "done" && (t.endDate ?? t.startDate ?? "").startsWith(today.slice(0, 4))).reduce((s, t) => s + t.costCents, 0);

  return (
    <>
      <PageHeader
        title="Formations et habilitations"
        description="Demandes, suivi, coût et dates d'expiration des habilitations. Les habilitations qui expirent apparaissent dans les échéances."
        actions={
          canWrite && employees.length ? (
            <DialogForm trigger={<><Plus size={16} /> Nouvelle formation</>} title="Nouvelle formation ou habilitation" action={createTrainingAction} hidden={{ companyId }} submitLabel="Enregistrer" wide>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Salarié" required htmlFor="tr-emp">
                  <Select id="tr-emp" name="employeeId" required defaultValue="">
                    <option value="" disabled>
                      Choisir
                    </option>
                    {employees
                      .filter((e) => e.status !== "left")
                      .map((e) => (
                        <option key={e.id} value={e.id}>
                          {fullName(e)}
                        </option>
                      ))}
                  </Select>
                </Field>
                <Field label="Type" htmlFor="tr-kind">
                  <Select id="tr-kind" name="kind">
                    {TRAINING_KINDS.map((k) => (
                      <option key={k.value} value={k.value}>
                        {k.label}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Intitulé" required htmlFor="tr-title" className="sm:col-span-2">
                  <Input id="tr-title" name="title" required placeholder="Habilitation électrique B1V" />
                </Field>
                <Field label="Organisme" htmlFor="tr-prov">
                  <Input id="tr-prov" name="provider" />
                </Field>
                <Field label="Coût (euros HT)" htmlFor="tr-cost">
                  <Input id="tr-cost" name="cost" inputMode="decimal" />
                </Field>
                <Field label="Début" htmlFor="tr-start">
                  <Input id="tr-start" name="startDate" type="date" />
                </Field>
                <Field label="Fin" htmlFor="tr-end">
                  <Input id="tr-end" name="endDate" type="date" />
                </Field>
                <Field label="Expiration" htmlFor="tr-exp" className="sm:col-span-2" help="Pour une habilitation ou une certification à renouveler.">
                  <Input id="tr-exp" name="expiresAt" type="date" />
                </Field>
              </div>
            </DialogForm>
          ) : null
        }
      />
      {alerts.length ? (
        <p className="mb-4 rounded-[var(--radius-sm)] bg-warn-soft px-4 py-3 text-[13.5px] text-warn-ink">
          {alerts.length} habilitation(s) expirée(s) ou expirant dans les 90 jours. Planifiez le recyclage pour éviter qu&apos;un salarié travaille sans habilitation valide.
        </p>
      ) : null}
      <LinkTabs
        label="Vues des formations"
        current={view}
        items={[
          { key: "demandes", label: "Demandes et à venir", href: base, count: requests.length },
          { key: "habilitations", label: "Habilitations", href: `${base}?vue=habilitations`, count: alerts.length },
          { key: "toutes", label: "Historique", href: `${base}?vue=toutes` },
        ]}
      />
      <Panel>
        <PanelHeader title={`${shown.length} formation(s)`} description={`Coût des formations réalisées cette année : ${formatCents(yearCost)}.`} />
        {shown.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Salarié</Th>
                <Th>Formation</Th>
                <Th>Dates</Th>
                <Th>Expiration</Th>
                <Th num>Coût</Th>
                <Th>Statut</Th>
                {canWrite ? <Th className="text-right">Suivi</Th> : null}
              </tr>
            </thead>
            <tbody>
              {shown.map((t) => {
                const e = empById.get(t.employeeId)!;
                const st = trainingStatus(t.status);
                return (
                  <tr key={t.id}>
                    <Td>
                      <Person first={e.firstName} last={e.lastName} />
                    </Td>
                    <Td>
                      <span className="font-medium text-ink">{t.title}</span>
                      <span className="block text-[12px] text-ink-3">
                        {trainingKind(t.kind)}
                        {t.provider ? `, ${t.provider}` : ""}
                      </span>
                      {t.certificateDocumentId ? <ActionButton action={proofLinkAction} hidden={{ companyId, documentId: t.certificateDocumentId }} label="Attestation" variant="link" icon={<Paperclip size={13} />} /> : null}
                    </Td>
                    <Td className="whitespace-nowrap">{t.startDate ? `${fmtDate(t.startDate)}${t.endDate && t.endDate !== t.startDate ? ` au ${fmtDate(t.endDate)}` : ""}` : <span className="text-ink-3">À fixer</span>}</Td>
                    <Td className="whitespace-nowrap">
                      {t.expiresAt ? (
                        <span className="flex flex-col items-start gap-1">
                          {fmtDate(t.expiresAt)}
                          {t.expiresAt <= soon ? <DueIn days={daysUntil(t.expiresAt, today)} /> : null}
                        </span>
                      ) : (
                        "-"
                      )}
                    </Td>
                    <Td num>{t.costCents ? formatCents(t.costCents) : "-"}</Td>
                    <Td>
                      <Badge tone={st.tone}>{st.label}</Badge>
                    </Td>
                    {canWrite ? (
                      <Td className="text-right">
                        <DialogForm trigger="Mettre à jour" triggerVariant="ghost" triggerSize="sm" title={t.title} description={fullName(e)} action={updateTrainingAction} hidden={{ companyId, trainingId: t.id }} submitLabel="Enregistrer">
                          <Field label="Statut" htmlFor={`st-${t.id}`}>
                            <Select id={`st-${t.id}`} name="status" defaultValue={t.status}>
                              {TRAINING_STATUSES.map((s) => (
                                <option key={s.value} value={s.value}>
                                  {s.label}
                                </option>
                              ))}
                            </Select>
                          </Field>
                          <Field label="Expiration" htmlFor={`ex-${t.id}`}>
                            <Input id={`ex-${t.id}`} name="expiresAt" type="date" defaultValue={t.expiresAt ?? ""} />
                          </Field>
                          <Field label="Coût (euros HT)" htmlFor={`co-${t.id}`}>
                            <Input id={`co-${t.id}`} name="cost" inputMode="decimal" defaultValue={t.costCents ? String(t.costCents / 100).replace(".", ",") : ""} />
                          </Field>
                          <Field label="Attestation" htmlFor={`ce-${t.id}`} help="PDF ou image, 10 Mo maximum.">
                            <Input id={`ce-${t.id}`} name="certificate" type="file" accept="application/pdf,image/jpeg,image/png,image/webp" className="py-1.5" />
                          </Field>
                        </DialogForm>
                      </Td>
                    ) : null}
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState icon={<GraduationCap size={28} />} title={view === "habilitations" ? "Aucune habilitation suivie" : "Aucune formation"} description="Enregistrez les demandes de formation et les habilitations avec leur date d'expiration pour être alerté à temps." />
        )}
      </Panel>
    </>
  );
}
