import Link from "next/link";
import { notFound } from "next/navigation";
import { Check, Circle, WarningCircle } from "@phosphor-icons/react/ssr";
import { guardCompany } from "@/server/guard";
import {
  DraftError,
  listReviewCandidates,
  listSignatureRequests,
  loadDraft,
  templateMeta,
  type DraftVersion,
  type Reviewer,
} from "@/server/documents/drafting";
import { listMarkers, type MissingItem } from "@/server/documents/render";
import type { TemplateQuestion } from "@/server/documents/templates-data";
import { canSeeRestricted } from "@/server/documents/visibility";
import { AI_DATA_NOTICE, AI_NOT_CONFIGURED } from "@/server/documents/ai";
import { integrations, integrationLabels } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { cn } from "@/lib/utils";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { StatusBadge } from "@/components/ui/badge";
import { Table, Td, Th } from "@/components/ui/table";
import { LegalNotice } from "@/components/documents/legal-notice";
import { QuestionsForm } from "@/components/documents/questions-form";
import { DraftEditor } from "@/components/documents/draft-editor";
import { DecideReviewForm, ExportForm, ImproveButton, SignatureButton, SubmitReviewForm } from "@/components/documents/workflow-panels";
import { ActionButton } from "@/components/documents/action-form";
import { DownloadButton } from "@/components/documents/download-button";
import { archiveDraftAction, refreshSignatureAction, restoreVersionAction } from "@/server/actions/drafting";

type StepState = "done" | "current" | "todo";

const ORDER = ["questions", "drafted", "in_review", "validated", "exported", "signed"];

export default async function DraftPage({ params }: { params: Promise<{ companyId: string; draftId: string }> }) {
  const { companyId, draftId } = await params;
  const base = `/app/${companyId}/atelier`;
  const ctx = await guardCompany(companyId, `${base}/${draftId}`, "documents.write");
  let loaded;
  try {
    loaded = await loadDraft(ctx, draftId);
  } catch (e) {
    if (e instanceof DraftError && e.message.includes("rémunération")) {
      return (
        <>
          <PageHeader breadcrumb={[{ label: "Atelier de rédaction", href: base }]} title="Accès restreint" />
          <Notice tone="warn">{e.message}</Notice>
        </>
      );
    }
    notFound();
  }
  const { draft, template } = loaded;
  const questions = ((template?.questions ?? []) as TemplateQuestion[]) ?? [];
  const answers = (draft.answers ?? {}) as Record<string, string>;
  const versions = ((draft.versions ?? []) as DraftVersion[]).slice().reverse();
  const reviewers = (draft.reviewers ?? []) as Reviewer[];
  const pendingReview = reviewers.find((r) => !r.decision);
  const lastDecision = [...reviewers].reverse().find((r) => r.decision === "approved" || r.decision === "rejected");
  const markers = listMarkers(draft.body);
  const missing = (draft.missing ?? []) as MissingItem[];
  const withheld = missing.filter((m) => m.reason);
  const isLegal = Boolean(template?.isLegal);
  const meta = template ? templateMeta(template) : null;
  const locked = ["signed", "archived"].includes(draft.status);
  const ids = { companyId, draftId: draft.id };
  const [candidates, signatures] = await Promise.all([listReviewCandidates(ctx), listSignatureRequests(draft.pdfDocumentId ? [draft.pdfDocumentId] : [])]);
  const idx = ORDER.indexOf(draft.status);
  const state = (i: number): StepState => (draft.status === "archived" ? "done" : idx > i ? "done" : idx === i ? "current" : "todo");
  const generations = ((draft.versions ?? []) as DraftVersion[]).filter((v) => !v.note.startsWith("Modification manuelle")).length;
  const canRestricted = canSeeRestricted(ctx.permissions);
  const defaultVisibility = answers._containsSalary === "1" || isLegal ? (canRestricted ? "restricted" : "company") : "company";

  const steps: { label: string; s: StepState }[] = [
    { label: "Type de document", s: "done" },
    { label: "Questions", s: state(0) === "current" ? "current" : "done" },
    { label: "Informations autorisées", s: idx >= 1 ? "done" : "todo" },
    { label: "Éléments manquants", s: idx >= 1 ? (markers.length ? "current" : "done") : "todo" },
    { label: "Brouillon modifiable", s: idx >= 1 ? (idx === 1 ? "current" : "done") : "todo" },
    { label: "Validation", s: idx >= 3 ? "done" : idx === 2 ? "current" : "todo" },
    { label: "Export PDF et DOCX", s: idx >= 4 ? "done" : idx === 3 ? "current" : "todo" },
    { label: "Versions archivées", s: versions.length ? "done" : "todo" },
  ];

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Atelier de rédaction", href: base }, { label: draft.title }]}
        title={draft.title}
        description={template ? `Modèle : ${template.title}, v${template.version}.` : "Modèle supprimé."}
        actions={
          <>
            <StatusBadge status={draft.status} />
            {!locked ? (
              <ActionButton
                action={archiveDraftAction}
                fields={ids}
                label="Archiver"
                variant="ghost"
                confirm={{ title: "Archiver ce brouillon", description: "Il ne sera plus modifiable. Ses versions et fichiers exportés restent consultables.", confirmLabel: "Archiver" }}
              />
            ) : null}
          </>
        }
      />

      <ol aria-label="Parcours de rédaction" className="mb-5 flex flex-wrap gap-x-5 gap-y-2 rounded-[var(--radius-md)] border border-line bg-bg-elev px-5 py-3 text-[13px]">
        {steps.map((st) => (
          <li key={st.label} className={cn("flex items-center gap-1.5", st.s === "done" ? "text-ok-ink" : st.s === "current" ? "font-medium text-ink" : "text-ink-3")} aria-current={st.s === "current" ? "step" : undefined}>
            {st.s === "done" ? <Check size={14} weight="bold" /> : st.s === "current" ? <WarningCircle size={14} /> : <Circle size={14} />}
            {st.label}
          </li>
        ))}
      </ol>

      {isLegal ? <LegalNotice points={(template?.legalReviewPoints as string[]) ?? []} verifiedNote={template?.verifiedNote ?? null} /> : null}

      <div className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1.6fr)_minmax(320px,1fr)]">
        <div className="min-w-0 space-y-5">
          {template ? (
            <Panel>
              <PanelHeader title="Questions" description={draft.status === "questions" ? "Répondez pour générer le brouillon." : "Modifier une réponse regénère le brouillon (la version actuelle reste dans l'historique)."} />
              <div className="px-5 py-4">
                <QuestionsForm companyId={companyId} draftId={draft.id} questions={questions} answers={answers} regenerate={draft.status !== "questions"} disabled={locked} />
              </div>
            </Panel>
          ) : null}

          {draft.status !== "questions" ? (
            <Panel>
              <PanelHeader title="Brouillon" description="Modifiable, avec aperçu. Chaque enregistrement crée une version." />
              <DraftEditor key={generations} companyId={companyId} draftId={draft.id} body={draft.body} locked={locked} />
            </Panel>
          ) : null}
        </div>

        <div className="min-w-0 space-y-5">
          {draft.status !== "questions" ? (
            <Panel>
              <PanelHeader title="Éléments manquants" description="Rien n'est inventé : ces informations restent à compléter dans le brouillon." />
              <div className="px-5 py-4">
                {markers.length ? (
                  <ul className="space-y-1.5 text-[13.5px]">
                    {markers.map((m) => (
                      <li key={m} className="flex items-start gap-2">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-none bg-warn" aria-hidden />
                        <span>{m}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-[13.5px] text-ok-ink">Tous les éléments sont renseignés.</p>
                )}
                {withheld.length ? (
                  <p className="mt-3 text-[12.5px] text-ink-2">
                    Certaines données n&apos;ont pas été reprises faute d&apos;habilitation ({[...new Set(withheld.map((w) => w.reason))].join(", ")}). Une personne habilitée peut les compléter.
                  </p>
                ) : null}
              </div>
            </Panel>
          ) : null}

          <Panel>
            <PanelHeader title="Relecture et validation" />
            <div className="space-y-3 px-5 py-4">
              {lastDecision ? (
                <Notice tone={lastDecision.decision === "approved" ? "ok" : "warn"} title={lastDecision.decision === "approved" ? `Validé par ${lastDecision.name}` : `Refusé par ${lastDecision.name}`}>
                  {lastDecision.comment ? `« ${lastDecision.comment} »` : "Sans commentaire."} <span className="opacity-80">{fmtDateTime(lastDecision.decidedAt ?? null)}</span>
                </Notice>
              ) : null}
              {draft.status === "in_review" && pendingReview ? (
                pendingReview.userId === ctx.user.id ? (
                  <>
                    <p className="text-[13px] text-ink-2">
                      {pendingReview.requestedByName} vous a demandé de relire ce document{pendingReview.message ? ` : « ${pendingReview.message} »` : "."}
                    </p>
                    <DecideReviewForm ids={ids} canApprove={!markers.length} />
                  </>
                ) : (
                  <p className="text-[13px] text-ink-2">En relecture chez {pendingReview.name} depuis le {fmtDateTime(pendingReview.requestedAt)}.</p>
                )
              ) : draft.status === "drafted" ? (
                <SubmitReviewForm ids={ids} candidates={candidates} />
              ) : draft.status === "questions" ? (
                <p className="text-[13px] text-ink-2">Disponible une fois le brouillon généré.</p>
              ) : (
                <p className="text-[13px] text-ink-2">{draft.validatedAt ? `Validé le ${fmtDateTime(draft.validatedAt)}.` : "Aucune relecture en cours."}</p>
              )}
            </div>
          </Panel>

          <Panel>
            <PanelHeader title="Export et signature" />
            <div className="space-y-4 px-5 py-4">
              {["validated", "exported"].includes(draft.status) ? (
                <ExportForm ids={ids} isLegal={isLegal} defaultVisibility={defaultVisibility} hasEmployee={Boolean(draft.employeeId)} canRestricted={canRestricted} />
              ) : (
                <p className="text-[13px] text-ink-2">L&apos;export en PDF et DOCX est possible après validation en relecture.</p>
              )}
              {draft.pdfDocumentId ? (
                <div className="flex flex-wrap gap-2 border-t border-line pt-3">
                  <DownloadButton companyId={companyId} documentId={draft.pdfDocumentId} label="PDF" variant="secondary" />
                  {draft.docxDocumentId ? <DownloadButton companyId={companyId} documentId={draft.docxDocumentId} label="DOCX" variant="secondary" /> : null}
                  <Link href={`/app/${companyId}/documents/${draft.pdfDocumentId}`} className="self-center text-[13px] text-accent hover:underline">
                    Voir dans les documents
                  </Link>
                </div>
              ) : null}
              <div className="space-y-2 border-t border-line pt-3">
                <SignatureButton ids={ids} configured={integrations.esign()} isLegal={isLegal} isDemo={ctx.company.isDemo} disabled={draft.status !== "exported"} />
                {!integrations.esign() ? (
                  <p className="text-[12.5px] text-ink-3">
                    {integrationLabels.esign.label} non configurée : variables {integrationLabels.esign.envVars.join(" et ")}.
                  </p>
                ) : null}
                {signatures.length ? (
                  <Table>
                    <thead>
                      <tr>
                        <Th>Demande</Th>
                        <Th>Statut</Th>
                        <Th>Preuve</Th>
                      </tr>
                    </thead>
                    <tbody>
                      {signatures.map((s) => {
                        const proof = s.proof as { signedAt?: string; evidenceUrl?: string; sha256?: string } | null;
                        return (
                          <tr key={s.id}>
                            <Td className="whitespace-nowrap">{fmtDateTime(s.createdAt)}</Td>
                            <Td>
                              <StatusBadge status={s.status} />
                            </Td>
                            <Td className="text-[12.5px]">
                              {proof?.signedAt ? (
                                <>
                                  Signé le {fmtDateTime(proof.signedAt)}
                                  {proof.evidenceUrl ? (
                                    <a href={proof.evidenceUrl} className="ml-1 text-accent hover:underline" rel="noreferrer noopener" target="_blank">
                                      Dossier de preuve
                                    </a>
                                  ) : null}
                                </>
                              ) : s.status === "not_configured" ? (
                                "Aucune (rien n'a été envoyé)"
                              ) : s.providerRef ? (
                                <ActionButton action={refreshSignatureAction} fields={{ ...ids, requestId: s.id }} label="Actualiser" variant="ghost" />
                              ) : (
                                "-"
                              )}
                            </Td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </Table>
                ) : null}
              </div>
            </div>
          </Panel>

          {meta ? (
            <Panel>
              <PanelHeader title="Améliorer la rédaction" />
              <div className="space-y-2 px-5 py-4">
                <ImproveButton ids={ids} aiConfigured={integrations.ai()} allowed={meta.aiRewrite} notConfiguredMessage={AI_NOT_CONFIGURED} disabled={locked || draft.status === "questions"} />
                {meta.aiRewrite ? <p className="text-[12px] text-ink-3">{AI_DATA_NOTICE}</p> : null}
              </div>
            </Panel>
          ) : null}

          <Panel>
            <PanelHeader title="Versions archivées" description={`${versions.length} version(s).`} />
            {versions.length ? (
              <div className="max-h-80 overflow-y-auto">
                <Table>
                  <thead>
                    <tr>
                      <Th>Version</Th>
                      <Th>Par</Th>
                      <Th>Date</Th>
                      <Th>
                        <span className="sr-only">Restaurer</span>
                      </Th>
                    </tr>
                  </thead>
                  <tbody>
                    {versions.map((v, i) => (
                      <tr key={v.version}>
                        <Td>
                          <span className="num">v{v.version}</span>
                          <span className="block text-[12px] text-ink-3">{v.note}</span>
                        </Td>
                        <Td>{v.byName}</Td>
                        <Td className="whitespace-nowrap">{fmtDateTime(v.at)}</Td>
                        <Td className="text-right">
                          {i > 0 && !locked ? <ActionButton action={restoreVersionAction} fields={{ ...ids, version: v.version }} label="Restaurer" variant="ghost" /> : null}
                        </Td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </div>
            ) : (
              <p className="px-5 py-4 text-[13px] text-ink-2">Aucune version : générez le brouillon.</p>
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}
