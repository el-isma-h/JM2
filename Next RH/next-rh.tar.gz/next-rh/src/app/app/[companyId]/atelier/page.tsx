import Link from "next/link";
import { PencilLine, Scales } from "@phosphor-icons/react/ssr";
import { guardCompany } from "@/server/guard";
import { listDrafts, listTemplates, templateMeta } from "@/server/documents/drafting";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, Td, Th } from "@/components/ui/table";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { listMarkers } from "@/server/documents/render";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";

/** Documents proposés au départ d'un salarié (lien depuis le formulaire de sortie). */
const DEPARTURE_CODES = ["certificat-travail", "recu-solde-tout-compte", "attestation-france-travail-preparation"];

const GROUP_ORDER = ["Contrats et avenants", "Attestations", "Arrivée et départ", "Entretiens", "Courriers et réponses", "Recrutement", "Organisation interne"];

export default async function AtelierPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ salarie?: string; motif?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/atelier`;
  const ctx = await guardCompany(companyId, base, "documents.write");
  const [templates, drafts] = await Promise.all([listTemplates(companyId), listDrafts(companyId)]);
  // Pré-sélection d'un salarié (ex. depuis le formulaire de sortie) : contrôle d'appartenance et d'habilitation.
  const preselected =
    sp.salarie && /^[0-9a-f-]{36}$/.test(sp.salarie) && ctx.permissions.has("employees.read")
      ? ((
          await db
            .select({ id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName, leaveDate: schema.employees.leaveDate })
            .from(schema.employees)
            .where(and(eq(schema.employees.id, sp.salarie), eq(schema.employees.companyId, companyId)))
            .limit(1)
        )[0] ?? null)
      : null;
  const departureTemplates = preselected ? DEPARTURE_CODES.map((c) => templates.find((t) => t.code === c)).filter((t): t is (typeof templates)[number] => Boolean(t)) : [];
  const empQuery = preselected ? `?salarie=${preselected.id}` : "";
  const groups = new Map<string, typeof templates>();
  for (const t of templates) {
    const g = templateMeta(t).group;
    groups.set(g, [...(groups.get(g) ?? []), t]);
  }
  const ordered = [...groups.entries()].sort((a, b) => GROUP_ORDER.indexOf(a[0]) - GROUP_ORDER.indexOf(b[0]));
  const active = drafts.filter((d) => d.d.status !== "archived");

  return (
    <>
      <PageHeader
        title="Atelier de rédaction"
        description="Choisissez un type de document. L'atelier pose les questions utiles, n'utilise que les informations auxquelles vous avez accès, signale ce qui manque, puis organise la relecture, l'export et la signature."
      />

      {preselected ? (
        <Panel className="mb-6">
          <PanelHeader
            title={`Départ de ${preselected.firstName} ${preselected.lastName}`}
            description={`${preselected.leaveDate ? `Sortie le ${fmtDate(preselected.leaveDate)}. ` : ""}${sp.motif ? `Motif : ${sp.motif.replace(/[_-]+/g, " ").slice(0, 60)}. ` : ""}Documents de fin de contrat à préparer ; le salarié est déjà sélectionné.`}
          />
          <div className="divide-y divide-line">
            {departureTemplates.map((t) => (
              <div key={t.id} className="flex items-start justify-between gap-4 px-5 py-3">
                <div className="min-w-0">
                  <p className="text-[14px] font-medium text-ink">{t.title}</p>
                  <p className="mt-0.5 text-[13px] text-ink-2">{t.description}</p>
                </div>
                <Button asChild size="sm">
                  <Link href={`${base}/nouveau/${t.code}${empQuery}`}>Préparer</Link>
                </Button>
              </div>
            ))}
          </div>
        </Panel>
      ) : null}

      {active.length ? (
        <Panel className="mb-6">
          <PanelHeader title="Brouillons en cours" description={`${active.length} brouillon(s). Les versions de chaque brouillon sont archivées.`} />
          <Table>
            <thead>
              <tr>
                <Th>Document</Th>
                <Th>Statut</Th>
                <Th num>À compléter</Th>
                <Th>Modifié le</Th>
              </tr>
            </thead>
            <tbody>
              {active.slice(0, 30).map(({ d }) => (
                <tr key={d.id}>
                  <Td>
                    <Link href={`${base}/${d.id}`} className="font-medium text-ink hover:text-accent hover:underline">
                      {d.title}
                    </Link>
                  </Td>
                  <Td>
                    <StatusBadge status={d.status} />
                  </Td>
                  <Td num>{d.status === "questions" ? "-" : listMarkers(d.body).length}</Td>
                  <Td className="whitespace-nowrap">{fmtDateTime(d.updatedAt)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>
      ) : null}

      <h2 className="mb-3 text-[15px] font-semibold text-ink">Quel document voulez-vous préparer ?</h2>
      {!templates.length ? (
        <Panel>
          <EmptyState
            icon={<PencilLine size={28} />}
            title="Aucun modèle disponible"
            description="Les modèles plateforme ne sont pas encore chargés. Un administrateur doit exécuter le chargement des modèles (seedDocumentTemplates)."
          />
        </Panel>
      ) : (
        <div className="grid gap-5 lg:grid-cols-2">
          {ordered.map(([group, list]) => (
            <Panel key={group}>
              <PanelHeader title={group} />
              <div className="divide-y divide-line">
                {list.map((t) => (
                  <div key={t.id} className="flex items-start justify-between gap-4 px-5 py-3">
                    <div className="min-w-0">
                      <p className="flex flex-wrap items-center gap-2 text-[14px] font-medium text-ink">
                        {t.title}
                        {t.isLegal ? (
                          <Badge tone="warn">
                            <Scales size={12} />
                            Validation juridique requise
                          </Badge>
                        ) : null}
                        {t.companyId ? <Badge tone="info">Modèle de l&apos;entreprise</Badge> : null}
                      </p>
                      <p className="mt-0.5 text-[13px] text-ink-2">{t.description}</p>
                      {t.verifiedAt ? <p className="mt-0.5 text-[12px] text-ink-3">Mentions vérifiées le {fmtDate(t.verifiedAt)}</p> : null}
                    </div>
                    <Button asChild variant="secondary" size="sm">
                      <Link href={`${base}/nouveau/${t.code}${empQuery}`} aria-label={`Préparer : ${t.title}`}>
                        Préparer
                      </Link>
                    </Button>
                  </div>
                ))}
              </div>
            </Panel>
          ))}
        </div>
      )}
    </>
  );
}
