import { notFound } from "next/navigation";
import { asc, eq, ne, and } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { getTemplate, needsSalary, templateMeta } from "@/server/documents/drafting";
import type { TemplateQuestion } from "@/server/documents/templates-data";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { LegalNotice } from "@/components/documents/legal-notice";
import { StartDraftForm } from "@/components/documents/start-draft-form";
import { CATEGORY_LABELS } from "@/server/documents/visibility";

export default async function NewDraftPage({ params, searchParams }: { params: Promise<{ companyId: string; templateCode: string }>; searchParams: Promise<{ salarie?: string }> }) {
  const { companyId, templateCode } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/atelier`;
  const ctx = await guardCompany(companyId, `${base}/nouveau/${templateCode}`, "documents.write");
  const template = await getTemplate(companyId, decodeURIComponent(templateCode));
  if (!template) notFound();
  const meta = templateMeta(template);
  const questions = (template.questions ?? []) as TemplateQuestion[];
  const canEmployees = ctx.permissions.has("employees.read");
  const employees =
    meta.needsEmployee && canEmployees
      ? await db
          .select({ id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName, status: schema.employees.status })
          .from(schema.employees)
          .where(and(eq(schema.employees.companyId, companyId), ne(schema.employees.status, "draft")))
          .orderBy(asc(schema.employees.lastName), asc(schema.employees.firstName))
      : [];

  return (
    <>
      <PageHeader breadcrumb={[{ label: "Atelier de rédaction", href: base }, { label: template.title }]} title={template.title} description={template.description ?? undefined} />
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          {template.isLegal ? <LegalNotice points={(template.legalReviewPoints as string[]) ?? []} verifiedNote={template.verifiedNote} /> : null}
          <Panel>
            <PanelHeader title="Démarrer" description="Étape 1 : type de document identifié. Étape 2 : questions." />
            <div className="space-y-4 px-5 py-4">
              {meta.needsEmployee && !canEmployees ? (
                <Notice tone="warn">Ce document concerne un salarié : l&apos;habilitation à consulter les salariés est nécessaire.</Notice>
              ) : (
                <StartDraftForm
                  companyId={companyId}
                  templateId={template.id}
                  needsEmployee={meta.needsEmployee}
                  defaultEmployeeId={sp.salarie}
                  employees={employees.map((e) => ({ id: e.id, label: `${e.lastName} ${e.firstName}${e.status === "left" ? " (sorti)" : ""}` }))}
                />
              )}
              {needsSalary(template.body) && !ctx.permissions.has("salaries.read") ? (
                <Notice tone="info">Vous n&apos;êtes pas habilité à consulter les salaires : la rémunération restera un élément à compléter par une personne habilitée.</Notice>
              ) : null}
            </div>
          </Panel>
        </div>
        <Panel>
          <PanelHeader title="Ce que l'atelier va vous demander" />
          <div className="px-5 py-4">
            <KeyValue
              className="mb-4"
              items={[
                { k: "Catégorie", v: CATEGORY_LABELS[template.category] ?? template.category },
                { k: "Version du modèle", v: `v${template.version}` },
                { k: "Reformulation IA", v: meta.aiRewrite ? "Proposée (parties non juridiques)" : "Désactivée" },
              ]}
            />
            {questions.length ? (
              <ul className="list-disc space-y-1 pl-5 text-[13.5px] text-ink">
                {questions.map((q) => (
                  <li key={q.key}>
                    {q.label}
                    {q.required ? null : <span className="text-ink-3"> (facultatif)</span>}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-[13px] text-ink-2">Aucune question : les données de l&apos;entreprise et du salarié suffisent.</p>
            )}
            <p className="mt-4 text-[12.5px] text-ink-3">
              Les données de l&apos;entreprise, du salarié et de son contrat sont reprises automatiquement selon vos habilitations. Le numéro de sécurité sociale et les coordonnées bancaires ne sont jamais utilisés.
            </p>
          </div>
        </Panel>
      </div>
    </>
  );
}
