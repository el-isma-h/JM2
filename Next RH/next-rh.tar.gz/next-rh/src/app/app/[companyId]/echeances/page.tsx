import Link from "next/link";
import { and, asc, eq, lte, ne } from "drizzle-orm";
import { Bell, Plus } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, listEmployees, todayIso } from "@/server/hr/common";
import { addDaysIso, daysUntil } from "@/server/hr/calc";
import { deadlineKindLabels, syncDeadlines } from "@/server/hr/deadlines";
import { createDeadlineAction, syncDeadlinesAction, toggleDeadlineAction } from "@/server/actions/deadlines";
import { ActionButton, DialogForm } from "@/components/hr/action-form";
import { DueIn, LinkTabs } from "@/components/hr/bits";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Field, Input, Select } from "@/components/ui/field";
import { fmtDate } from "@/lib/dates";
import { cn } from "@/lib/utils";

const HORIZONS = { "30": 30, "60": 60, "90": 90 } as const;

export default async function EcheancesPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ horizon?: string; type?: string; faites?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/echeances`;
  const ctx = await guardCompany(companyId, base, "employees.read");
  const canWrite = ctx.permissions.has("employees.write");
  await syncDeadlines(companyId);

  const horizonKey = (sp.horizon && sp.horizon in HORIZONS ? sp.horizon : "90") as keyof typeof HORIZONS;
  const horizon = HORIZONS[horizonKey];
  const type = sp.type && sp.type in deadlineKindLabels ? sp.type : "";
  const showDone = sp.faites === "1";
  const today = todayIso();
  const until = addDaysIso(today, horizon);

  const rows = await db
    .select()
    .from(schema.deadlines)
    .where(and(eq(schema.deadlines.companyId, companyId), lte(schema.deadlines.dueDate, until), type ? eq(schema.deadlines.kind, type) : undefined, showDone ? undefined : ne(schema.deadlines.status, "done")))
    .orderBy(asc(schema.deadlines.dueDate));
  const employees = await listEmployees(companyId);
  const empById = new Map(employees.map((e) => [e.id, e]));
  const qs = (over: Record<string, string>) => {
    const q = new URLSearchParams({ horizon: horizonKey, ...(type ? { type } : {}), ...(showDone ? { faites: "1" } : {}), ...over });
    for (const [k, v] of [...q.entries()]) if (!v) q.delete(k);
    return `${base}?${q.toString()}`;
  };
  const overdue = rows.filter((r) => r.status !== "done" && r.dueDate < today);
  const counts = Object.fromEntries(Object.keys(deadlineKindLabels).map((k) => [k, rows.filter((r) => r.kind === k).length]));

  return (
    <>
      <PageHeader
        title="Périodes d'essai et échéances"
        description="Calculées automatiquement depuis les contrats (fin d'essai, renouvellement, fin de CDD), les habilitations qui expirent et les entretiens planifiés. Ajoutez les autres échéances à la main (visite médicale, titre de séjour…)."
        actions={
          <>
            <ActionButton action={syncDeadlinesAction} hidden={{ companyId }} label="Recalculer" variant="secondary" size="md" showSuccess />
            {canWrite ? (
              <DialogForm trigger={<><Plus size={16} /> Ajouter</>} title="Ajouter une échéance" action={createDeadlineAction} hidden={{ companyId }} submitLabel="Ajouter">
                <Field label="Type" required htmlFor="dl-kind">
                  <Select id="dl-kind" name="kind" defaultValue="visite_medicale">
                    {Object.entries(deadlineKindLabels).map(([k, l]) => (
                      <option key={k} value={k}>
                        {l}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Intitulé" required htmlFor="dl-title">
                  <Input id="dl-title" name="title" required placeholder="Visite d'information et de prévention" />
                </Field>
                <Field label="Salarié" htmlFor="dl-emp" help="Facultatif.">
                  <Select id="dl-emp" name="employeeId" defaultValue="">
                    <option value="">Aucun (échéance d&apos;entreprise)</option>
                    {employees.map((e) => (
                      <option key={e.id} value={e.id}>
                        {fullName(e)}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Date" required htmlFor="dl-date">
                  <Input id="dl-date" name="dueDate" type="date" required />
                </Field>
              </DialogForm>
            ) : null}
          </>
        }
      />
      <LinkTabs
        label="Horizon"
        current={horizonKey}
        items={[
          { key: "30", label: "30 jours", href: qs({ horizon: "30" }) },
          { key: "60", label: "60 jours", href: qs({ horizon: "60" }) },
          { key: "90", label: "90 jours", href: qs({ horizon: "90" }) },
        ]}
      />
      <div className="mb-4 flex flex-wrap items-center gap-2 text-[13px]" role="group" aria-label="Filtrer par type">
        <Link href={qs({ type: "" })} aria-current={!type ? "true" : undefined} className={cn("rounded-none border px-3 py-1", !type ? "border-accent bg-accent-soft text-accent-strong" : "border-line-strong text-ink-2 hover:text-ink")}>
          Tous les types
        </Link>
        {Object.entries(deadlineKindLabels).map(([k, l]) =>
          counts[k] || type === k ? (
            <Link key={k} href={qs({ type: k })} aria-current={type === k ? "true" : undefined} className={cn("rounded-none border px-3 py-1", type === k ? "border-accent bg-accent-soft text-accent-strong" : "border-line-strong text-ink-2 hover:text-ink")}>
              {l} <span className="num text-ink-3">{counts[k]}</span>
            </Link>
          ) : null,
        )}
        <Link href={qs({ faites: showDone ? "" : "1" })} className="ml-auto text-ink-2 underline-offset-4 hover:underline">
          {showDone ? "Masquer les échéances traitées" : "Afficher les échéances traitées"}
        </Link>
      </div>
      <Panel>
        {overdue.length ? (
          <p className="border-b border-line bg-danger-soft px-5 py-2.5 text-[13.5px] text-danger-ink">
            {overdue.length} échéance(s) dépassée(s) non traitée(s). Une période d&apos;essai dépassée sans rupture notifiée vaut confirmation dans le poste.
          </p>
        ) : null}
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th>Délai</Th>
                <Th>Échéance</Th>
                <Th>Type</Th>
                <Th>Salarié</Th>
                <Th className="text-right">Suivi</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((d) => {
                const e = d.employeeId ? empById.get(d.employeeId) : undefined;
                return (
                  <tr key={d.id} className={cn(d.status === "done" && "text-ink-3")}>
                    <Td className="num whitespace-nowrap">{fmtDate(d.dueDate)}</Td>
                    <Td>{d.status === "done" ? <span className="text-ok-ink">Traitée</span> : <DueIn days={daysUntil(d.dueDate, today)} />}</Td>
                    <Td className={cn(d.status === "done" && "line-through")}>{d.title}</Td>
                    <Td className="text-ink-2">{deadlineKindLabels[d.kind] ?? d.kind}</Td>
                    <Td>{e ? fullName(e) : <span className="text-ink-3">Entreprise</span>}</Td>
                    <Td className="text-right">
                      {canWrite ? <ActionButton action={toggleDeadlineAction} hidden={{ companyId, deadlineId: d.id }} label={d.status === "done" ? "Rouvrir" : "Marquer traitée"} variant="ghost" /> : null}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState icon={<Bell size={28} />} title={`Aucune échéance dans les ${horizon} prochains jours`} description="Renseignez les dates de fin de période d'essai et de fin de contrat dans les fiches salariés pour les voir apparaître ici." />
        )}
      </Panel>
    </>
  );
}
