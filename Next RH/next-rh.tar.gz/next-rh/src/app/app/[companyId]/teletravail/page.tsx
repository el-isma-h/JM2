import Link from "next/link";
import { and, eq, gte, inArray, lte } from "drizzle-orm";
import { HouseLine, Plus } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, listEmployees, monthParam, parseMonthParam, todayIso } from "@/server/hr/common";
import { isoWeekKey } from "@/server/hr/calc";
import { createRemoteDaysAction, decideRemoteAction, saveRemotePolicyAction } from "@/server/actions/remote";
import { ActionButton, ActionForm, DialogForm } from "@/components/hr/action-form";
import { MonthNav, Person } from "@/components/hr/bits";
import { EmptyState, KeyValue, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { daysInMonth, fmtDate, frenchHolidays } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";

export default async function TeletravailPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ mois?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/teletravail`;
  const ctx = await guardCompany(companyId, base, "employees.read");
  const canApprove = ctx.permissions.has("requests.approve");
  const canPolicy = ctx.permissions.has("company.manage");
  const { year, month } = parseMonthParam(sp.mois);
  const ym = monthParam(year, month);
  const [employees, [policyRow]] = await Promise.all([
    listEmployees(companyId),
    db.select().from(schema.remoteWorkPolicies).where(eq(schema.remoteWorkPolicies.companyId, companyId)).limit(1),
  ]);
  const policy = policyRow ?? { maxDaysPerWeek: 2, requiresApproval: true, allowanceCentsPerDay: 0, rules: null };
  const ids = employees.map((e) => e.id);
  const empById = new Map(employees.map((e) => [e.id, e]));
  const first = `${ym}-01`;
  const last = `${ym}-${String(daysInMonth(year, month)).padStart(2, "0")}`;
  const today = todayIso();
  const [monthDays, pending] = ids.length
    ? await Promise.all([
        db
          .select()
          .from(schema.remoteWorkRequests)
          .where(and(inArray(schema.remoteWorkRequests.employeeId, ids), gte(schema.remoteWorkRequests.date, first), lte(schema.remoteWorkRequests.date, last), inArray(schema.remoteWorkRequests.status, ["pending", "approved"]))),
        db
          .select()
          .from(schema.remoteWorkRequests)
          .where(and(inArray(schema.remoteWorkRequests.employeeId, ids), eq(schema.remoteWorkRequests.status, "pending"), gte(schema.remoteWorkRequests.date, today)))
          .orderBy(schema.remoteWorkRequests.date)
          .limit(100),
      ])
    : [[], []];

  // Jours approuvés de la semaine de chaque demande en attente, pour afficher le contrôle du maximum.
  const approvedAround = pending.length
    ? await db
        .select({ employeeId: schema.remoteWorkRequests.employeeId, date: schema.remoteWorkRequests.date })
        .from(schema.remoteWorkRequests)
        .where(and(inArray(schema.remoteWorkRequests.employeeId, [...new Set(pending.map((p) => p.employeeId))]), eq(schema.remoteWorkRequests.status, "approved"), gte(schema.remoteWorkRequests.date, pending[0].date)))
    : [];

  const holidays = new Set(frenchHolidays(year));
  const days = Array.from({ length: daysInMonth(year, month) }, (_, i) => {
    const iso = `${ym}-${String(i + 1).padStart(2, "0")}`;
    const wd = new Date(year, month - 1, i + 1).getDay();
    return { iso, n: i + 1, wd, holiday: holidays.has(iso) };
  }).filter((d) => d.wd !== 0 && d.wd !== 6);
  const wdLetter = ["D", "L", "M", "M", "J", "V", "S"];

  return (
    <>
      <PageHeader
        title="Télétravail"
        description={`Politique de l'entreprise : ${policy.maxDaysPerWeek} jour(s) maximum par semaine${policy.requiresApproval ? ", avec validation" : ", sans validation préalable"}.`}
        actions={
          canApprove && employees.length ? (
            <DialogForm trigger={<><Plus size={16} /> Poser des jours</>} title="Poser des jours de télétravail" description="Le maximum hebdomadaire est contrôlé jour par jour." action={createRemoteDaysAction} hidden={{ companyId }} submitLabel="Enregistrer" closeOnSuccess={false}>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Salarié" required htmlFor="rw-emp" className="sm:col-span-2">
                  <Select id="rw-emp" name="employeeId" required defaultValue="">
                    <option value="" disabled>
                      Choisir
                    </option>
                    {employees.map((e) => (
                      <option key={e.id} value={e.id}>
                        {fullName(e)}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Du" required htmlFor="rw-start">
                  <Input id="rw-start" name="startDate" type="date" required />
                </Field>
                <Field label="Au" htmlFor="rw-end" help="Laisser vide pour un seul jour.">
                  <Input id="rw-end" name="endDate" type="date" />
                </Field>
                <fieldset className="sm:col-span-2">
                  <legend className="mb-1.5 text-[13px] font-medium text-ink">Jours de la semaine</legend>
                  <div className="flex flex-wrap gap-4">
                    {["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"].map((l, i) => (
                      <Checkbox key={l} name="weekday" value={String(i + 1)} label={l} />
                    ))}
                  </div>
                  <p className="mt-1.5 text-[12.5px] text-ink-3">Aucun jour coché : tous les jours ouvrés de la période.</p>
                </fieldset>
                <div className="space-y-2 sm:col-span-2">
                  <Checkbox name="approveNow" defaultChecked label="Valider immédiatement" />
                  <Checkbox name="override" label="Dépasser exceptionnellement le maximum hebdomadaire" />
                </div>
              </div>
            </DialogForm>
          ) : null
        }
      />

      {!employees.length ? (
        <Panel>
          <EmptyState icon={<HouseLine size={28} />} title="Aucun salarié" action={<Button asChild><Link href={`/app/${companyId}/salaries`}>Ajouter des salariés</Link></Button>} />
        </Panel>
      ) : (
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Planning du mois" description={`${monthDays.filter((d) => d.status === "approved").length} jour(s) validé(s), ${monthDays.filter((d) => d.status === "pending").length} en attente.`} actions={<MonthNav base={base} year={year} month={month} />} />
            <div className="overflow-x-auto">
              <table className="w-full border-separate border-spacing-0 text-[12px]">
                <caption className="sr-only">Jours de télétravail par salarié</caption>
                <thead>
                  <tr>
                    <th scope="col" className="sticky left-0 z-[2] min-w-[180px] border-b border-line-strong bg-bg-sunken px-3 py-2 text-left font-medium text-ink-2">
                      Salarié
                    </th>
                    {days.map((d, i) => (
                      <th key={d.iso} scope="col" className={cn("min-w-[28px] border-b border-line-strong bg-bg-sunken py-1.5 text-center font-medium text-ink-2", d.wd === 1 && i > 0 && "border-l border-l-line-strong", d.holiday && "bg-bg-muted text-ink-3")}>
                        <span className="block text-[10.5px] font-normal">{wdLetter[d.wd]}</span>
                        <span className="num">{d.n}</span>
                      </th>
                    ))}
                    <th scope="col" className="border-b border-line-strong bg-bg-sunken px-3 text-right font-medium text-ink-2">
                      Total
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {employees.map((e) => {
                    const mine = monthDays.filter((d) => d.employeeId === e.id);
                    return (
                      <tr key={e.id}>
                        <th scope="row" className="sticky left-0 z-[1] border-b border-line bg-bg-elev px-3 py-1.5 text-left text-[13px] font-normal text-ink">
                          {fullName(e)}
                        </th>
                        {days.map((d, i) => {
                          const r = mine.find((x) => x.date === d.iso);
                          const label = r ? `${fullName(e)} : télétravail ${r.status === "pending" ? "en attente" : "validé"} le ${fmtDate(d.iso)}` : undefined;
                          return (
                            <td key={d.iso} className={cn("h-8 border-b border-line p-[2px]", d.wd === 1 && i > 0 && "border-l border-l-line-strong", d.holiday && "bg-bg-muted")}>
                              {r ? <span title={label} aria-label={label} className={cn("block h-full w-full rounded-none", r.status === "approved" ? "bg-accent-soft" : "border border-dashed border-warn bg-warn-soft")} /> : null}
                            </td>
                          );
                        })}
                        <td className="num border-b border-line px-3 text-right text-ink">{mine.filter((d) => d.status === "approved").length}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Panel>

          <div className="grid gap-6 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
            <Panel>
              <PanelHeader title="Demandes à valider" description="Jours à venir en attente. Le compteur indique les jours déjà validés la même semaine." />
              {pending.length ? (
                <Table>
                  <thead>
                    <tr>
                      <Th>Salarié</Th>
                      <Th>Jour</Th>
                      <Th num>Semaine</Th>
                      <Th className="text-right">Décision</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {pending.map((r) => {
                      const e = empById.get(r.employeeId)!;
                      const wk = approvedAround.filter((a) => a.employeeId === r.employeeId && isoWeekKey(a.date) === isoWeekKey(r.date)).length;
                      const full = wk >= policy.maxDaysPerWeek;
                      return (
                        <tr key={r.id}>
                          <Td>
                            <Person first={e.firstName} last={e.lastName} />
                          </Td>
                          <Td className="whitespace-nowrap">{fmtDate(r.date, "EEEE d MMMM")}</Td>
                          <Td num className={cn(full && "text-danger-ink")}>
                            {wk} / {policy.maxDaysPerWeek}
                          </Td>
                          <Td className="text-right">
                            {canApprove ? (
                              <div className="flex flex-wrap justify-end gap-1.5">
                                <ActionButton action={decideRemoteAction} hidden={{ companyId, requestId: r.id, decision: "approve" }} label="Valider" variant="primary" />
                                <ActionButton action={decideRemoteAction} hidden={{ companyId, requestId: r.id, decision: "reject" }} label="Refuser" variant="ghost" />
                              </div>
                            ) : null}
                          </Td>
                        </tr>
                      );
                    })}
                  </tbody>
                </Table>
              ) : (
                <EmptyState title="Aucune demande en attente" description="Les jours posés avec validation requise apparaîtront ici." />
              )}
            </Panel>

            <Panel className="self-start">
              <PanelHeader title="Politique de télétravail" />
              <div className="p-5">
                {canPolicy ? (
                  <ActionForm action={saveRemotePolicyAction} hidden={{ companyId }} resetOnSuccess={false} submitLabel="Enregistrer la politique">
                    <Field label="Maximum de jours par semaine" htmlFor="pol-max">
                      <Input id="pol-max" name="maxDaysPerWeek" type="number" min={0} max={5} defaultValue={policy.maxDaysPerWeek} required />
                    </Field>
                    <Checkbox name="requiresApproval" defaultChecked={policy.requiresApproval} label="Chaque jour doit être validé par un responsable" />
                    <Field label="Indemnité par jour télétravaillé (euros)" htmlFor="pol-allow" help="Allocation forfaitaire exonérée dans la limite fixée par l'URSSAF. Indicatif : elle n'est pas encore transmise automatiquement à la paie.">
                      <Input id="pol-allow" name="allowance" inputMode="decimal" defaultValue={policy.allowanceCentsPerDay ? String(policy.allowanceCentsPerDay / 100).replace(".", ",") : ""} />
                    </Field>
                    <Field label="Règles et charte" htmlFor="pol-rules">
                      <Textarea id="pol-rules" name="rules" defaultValue={policy.rules ?? ""} placeholder="Jours exclus, plages de joignabilité, équipement fourni…" />
                    </Field>
                  </ActionForm>
                ) : (
                  <KeyValue
                    items={[
                      { k: "Maximum par semaine", v: `${policy.maxDaysPerWeek} jour(s)` },
                      { k: "Validation", v: policy.requiresApproval ? "Requise" : "Non requise" },
                      { k: "Indemnité par jour", v: policy.allowanceCentsPerDay ? formatCents(policy.allowanceCentsPerDay) : "Aucune" },
                      { k: "Règles", v: policy.rules ?? "-" },
                    ]}
                  />
                )}
              </div>
            </Panel>
          </div>
        </div>
      )}
    </>
  );
}
