import { DownloadSimple } from "@phosphor-icons/react/ssr";
import { guardCompany } from "@/server/guard";
import { audit } from "@/server/audit";
import { buildSocialReport } from "@/server/hr/reports";
import { BarList, ColumnChart, SplitBar } from "@/components/hr/charts";
import { CountUpNumber } from "@/components/dashboard/count";
import { Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { formatCents, formatNumber } from "@/lib/money";

export default async function RapportsPage({ params }: { params: Promise<{ companyId: string }> }) {
  const { companyId } = await params;
  const base = `/app/${companyId}/rapports`;
  const ctx = await guardCompany(companyId, base, "reports.read");
  const withPayroll = ctx.permissions.has("salaries.read");
  const r = await buildSocialReport(companyId, { withPayroll });
  if (withPayroll) await audit({ action: "reports.payroll_view", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id });
  const entries = r.movements.reduce((s, m) => s + m.entries, 0);
  const exits = r.movements.reduce((s, m) => s + m.exits, 0);
  const exp = (type: string) => `${base}/export?type=${type}`;

  return (
    <>
      <PageHeader
        title="Tableaux de bord sociaux"
        description="Effectif, mouvements, absentéisme et ancienneté sur les 12 derniers mois. Chaque tableau s'exporte en CSV (séparateur point-virgule, lisible dans Excel)."
        actions={
          <Button asChild variant="secondary">
            <a href={exp("effectif")}>
              <DownloadSimple size={16} /> Registre de l&apos;effectif (CSV)
            </a>
          </Button>
        }
      />

      <Panel className="mb-6">
        <dl className="grid grid-cols-2 divide-line md:grid-cols-5 md:divide-x">
          <div className="px-5 py-4">
            <dt className="text-[12.5px] text-ink-2">Effectif actif</dt>
            <dd className="mt-0.5 text-[26px] font-medium text-ink">
              <CountUpNumber value={r.headcount} />
            </dd>
            <dd className="text-[12px] text-ink-3">{r.drafts ? `${r.drafts} fiche(s) en préparation` : "Fiches en préparation exclues"}</dd>
          </div>
          <div className="px-5 py-4">
            <dt className="text-[12.5px] text-ink-2">Entrées sur 12 mois</dt>
            <dd className="mt-0.5 text-[20px] font-medium text-ink">
              <CountUpNumber value={entries} />
            </dd>
            <dd className="text-[12px] text-ink-3">Sorties : {exits}</dd>
          </div>
          <div className="px-5 py-4">
            <dt className="text-[12.5px] text-ink-2">Taux d&apos;absentéisme</dt>
            <dd className="mt-0.5 text-[20px] font-medium text-ink">{r.absenteeism === null ? "-" : <CountUpNumber value={r.absenteeism} digits={2} suffix=" %" />}</dd>
            <dd className="text-[12px] text-ink-3">{formatNumber(r.absenceDays, 1)} j sur {formatNumber(r.theoreticalDays, 0)} j ouvrés</dd>
          </div>
          <div className="px-5 py-4">
            <dt className="text-[12.5px] text-ink-2">Ancienneté moyenne</dt>
            <dd className="mt-0.5 text-[20px] font-medium text-ink">{r.avgSeniority === null ? "-" : <CountUpNumber value={r.avgSeniority} digits={1} suffix=" ans" />}</dd>
            <dd className="text-[12px] text-ink-3">Salariés actifs avec date d&apos;entrée</dd>
          </div>
          <div className="px-5 py-4">
            <dt className="text-[12.5px] text-ink-2">Répartition femmes / hommes</dt>
            <dd className="mt-2">
              <SplitBar
                caption={`${r.gender.F} femmes, ${r.gender.M} hommes, ${r.gender.other} non renseigné`}
                parts={[
                  { label: "Femmes", value: r.gender.F, tone: "accent" },
                  { label: "Hommes", value: r.gender.M, tone: "ink" },
                  ...(r.gender.other ? [{ label: "Non renseigné", value: r.gender.other, tone: "muted" as const }] : []),
                ]}
              />
            </dd>
          </div>
        </dl>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel>
          <PanelHeader title="Par établissement" />
          <div className="px-5 py-4">
            <BarList caption="Effectif actif par établissement" items={r.byEstablishment} />
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Par type de contrat" />
          <div className="px-5 py-4">
            <BarList caption="Effectif actif par type de contrat" items={r.byContract} />
          </div>
        </Panel>
        <Panel>
          <PanelHeader title="Par catégorie" />
          <div className="px-5 py-4">
            <BarList caption="Effectif actif par catégorie" items={r.byCategory} />
          </div>
        </Panel>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <Panel>
          <PanelHeader
            title="Entrées et sorties"
            description="12 derniers mois, d'après les dates d'entrée et de sortie des fiches."
            actions={
              <Button asChild variant="ghost" size="sm">
                <a href={exp("mouvements")}>
                  <DownloadSimple size={14} /> CSV
                </a>
              </Button>
            }
          />
          <Table>
            <thead>
              <tr>
                <Th>Mois</Th>
                <Th num>Entrées</Th>
                <Th num>Sorties</Th>
                <Th num>Solde</Th>
              </tr>
            </thead>
            <tbody>
              {r.movements.map((m) => (
                <tr key={m.key}>
                  <Td className="capitalize">{m.longLabel}</Td>
                  <Td num>{m.entries || "-"}</Td>
                  <Td num>{m.exits || "-"}</Td>
                  <Td num className={m.entries - m.exits < 0 ? "text-danger-ink" : undefined}>{m.entries - m.exits > 0 ? `+${m.entries - m.exits}` : m.entries - m.exits || "-"}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>
        <Panel className="self-start">
          <PanelHeader
            title="Absences non planifiées"
            description="Jours ouvrés sur 12 mois glissants, hors congés payés, RTT, télétravail, événements familiaux et congés de naissance."
            actions={
              <Button asChild variant="ghost" size="sm">
                <a href={exp("absences")}>
                  <DownloadSimple size={14} /> CSV
                </a>
              </Button>
            }
          />
          <div className="px-5 py-4">
            <BarList caption="Jours d'absence non planifiée par type" items={r.absenceByType} format={(n) => `${formatNumber(n, 1)} j`} />
          </div>
        </Panel>
      </div>

      <Panel className="mt-6">
        <PanelHeader
          title="Masse salariale brute par mois"
          description={
            r.payroll
              ? r.payroll.source === "payslips"
                ? "Somme des salaires bruts des bulletins calculés."
                : "Estimation depuis les rémunérations contractuelles (aucun bulletin calculé pour l'instant) : primes et variables non incluses."
              : undefined
          }
          actions={
            r.payroll ? (
              <Button asChild variant="ghost" size="sm">
                <a href={exp("masse")}>
                  <DownloadSimple size={14} /> CSV
                </a>
              </Button>
            ) : null
          }
        />
        <div className="px-5 py-4">
          {r.payroll ? (
            <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
              <ColumnChart title="Masse salariale brute des 12 derniers mois" data={r.payroll.months.map((m) => ({ label: m.label, value: m.grossCents / 100 }))} format={(n) => formatCents(Math.round(n * 100))} />
              <dl className="space-y-3 text-[13.5px]">
                <div>
                  <dt className="text-ink-2">Mois en cours</dt>
                  <dd className="num text-[18px] font-medium text-ink">{formatCents(r.payroll.months.at(-1)?.grossCents ?? 0)}</dd>
                </div>
                <div>
                  <dt className="text-ink-2">Cumul 12 mois</dt>
                  <dd className="num text-[18px] font-medium text-ink">{formatCents(r.payroll.months.reduce((s, m) => s + m.grossCents, 0))}</dd>
                </div>
                {r.payroll.source === "payslips" ? (
                  <div>
                    <dt className="text-ink-2">Coût employeur cumulé</dt>
                    <dd className="num text-[18px] font-medium text-ink">{formatCents(r.payroll.months.reduce((s, m) => s + (m.employerCostCents ?? 0), 0))}</dd>
                  </div>
                ) : null}
              </dl>
            </div>
          ) : (
            <Notice tone="info">La masse salariale est réservée aux personnes habilitées à consulter les salaires.</Notice>
          )}
        </div>
      </Panel>
    </>
  );
}
