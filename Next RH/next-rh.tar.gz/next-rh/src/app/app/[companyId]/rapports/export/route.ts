import { NextResponse } from "next/server";
import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { audit } from "@/server/audit";
import { buildSocialReport } from "@/server/hr/reports";
import { contractTypeLabels, categoryLabels } from "@/components/hr/labels";
import { todayIso } from "@/server/hr/common";

function csv(rows: (string | number | null | undefined)[][]): string {
  const esc = (v: string | number | null | undefined) => {
    const s = v === null || v === undefined ? "" : String(v);
    return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return "﻿" + rows.map((r) => r.map(esc).join(";")).join("\r\n");
}
const dec = (n: number, d = 2) => n.toFixed(d).replace(".", ",");

/** Export CSV des tableaux de bord sociaux (registre d'effectif, mouvements, absences, masse salariale). */
export async function GET(req: Request, { params }: { params: Promise<{ companyId: string }> }) {
  const { companyId } = await params;
  const type = new URL(req.url).searchParams.get("type") ?? "effectif";
  let ctx;
  try {
    ctx = await requireCompany(companyId, "reports.read");
  } catch (e) {
    return new NextResponse(authErrorMessage(e) ?? "Accès refusé.", { status: 403 });
  }
  const withPayroll = ctx.permissions.has("salaries.read");
  if (type === "masse" && !withPayroll) return new NextResponse("Habilitation « salaires » requise.", { status: 403 });
  const r = await buildSocialReport(companyId, { withPayroll: type === "masse" });
  let rows: (string | number | null)[][];
  switch (type) {
    case "mouvements":
      rows = [["Mois", "Entrées", "Sorties", "Solde"], ...r.movements.map((m) => [m.longLabel, m.entries, m.exits, m.entries - m.exits])];
      break;
    case "absences":
      rows = [
        ["Type d'absence", "Jours ouvrés (12 mois)"],
        ...r.absenceByType.map((a) => [a.label, dec(a.value, 1)]),
        [],
        ["Taux d'absentéisme (%)", r.absenteeism === null ? "" : dec(r.absenteeism)],
        ["Jours d'absence", dec(r.absenceDays, 1)],
        ["Jours ouvrés théoriques", r.theoreticalDays],
      ];
      break;
    case "masse":
      rows = [
        ["Mois", "Masse salariale brute (EUR)", "Coût employeur (EUR)", "Source"],
        ...(r.payroll?.months ?? []).map((m) => [m.longLabel, dec(m.grossCents / 100), m.employerCostCents === null ? "" : dec(m.employerCostCents / 100), r.payroll?.source === "payslips" ? "Bulletins" : "Rémunérations contractuelles"]),
      ];
      break;
    default:
      rows = [
        ["Matricule", "Nom", "Prénom", "Sexe", "Emploi", "Service", "Établissement", "Contrat", "Catégorie", "Date d'entrée", "Date de sortie", "Statut"],
        ...r.employees
          .filter((e) => e.status !== "draft")
          .sort((a, b) => (a.hireDate ?? "").localeCompare(b.hireDate ?? ""))
          .map((e) => {
            const c = r.currentContract.get(e.id);
            return [
              e.employeeNumber,
              e.lastName,
              e.firstName,
              e.gender,
              e.jobTitle,
              e.department,
              e.establishmentId ? r.estName.get(e.establishmentId) ?? "" : "",
              c ? contractTypeLabels[c.type] ?? c.type : "",
              c ? categoryLabels[c.category] ?? c.category : "",
              e.hireDate,
              e.leaveDate,
              e.status === "left" ? "Sorti" : e.status === "suspended" ? "Suspendu" : "Actif",
            ];
          }),
      ];
  }
  await audit({ action: "reports.export", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, after: { type } });
  const name = `${type}-${todayIso()}.csv`;
  return new NextResponse(csv(rows), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}"`,
      "Cache-Control": "private, no-store",
    },
  });
}
