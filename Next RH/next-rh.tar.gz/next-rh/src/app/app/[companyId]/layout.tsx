import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { requireUser } from "@/server/auth";
import { getCompanyContext, listAccessibleCompanies } from "@/server/authz";
import { AppShell } from "@/components/app/shell";
import { companyNav } from "@/components/app/nav";
import { CompanySwitcher } from "@/components/app/company-switcher";
import { Badge } from "@/components/ui/badge";
import { Logo } from "@/components/ui/logo";

export default async function CompanyLayout({ children, params }: { children: React.ReactNode; params: Promise<{ companyId: string }> }) {
  const { companyId } = await params;
  if (!/^[0-9a-f-]{36}$/.test(companyId)) notFound();
  const user = await requireUser();
  const ctx = await getCompanyContext(companyId);
  if (!ctx) notFound();
  if (ctx.role === "employee") redirect("/moi");
  const companies = await listAccessibleCompanies(user);
  const items = companyNav.filter((it) => !it.perm || ctx.permissions.has(it.perm)).filter((it) => it.href !== "/onboarding" || !ctx.company.onboardingCompletedAt);

  return (
    <AppShell
      base={`/app/${companyId}`}
      items={items}
      brand={
        <Link href="/app" className="flex items-center gap-3 text-ink">
          <Logo />
          {ctx.company.isDemo ? <Badge tone="warn">Démo</Badge> : null}
        </Link>
      }
      context={<CompanySwitcher companies={companies.map((c) => ({ id: c.id, name: c.tradeName ?? c.legalName }))} currentId={companyId} isDemo={ctx.company.isDemo} />}
      user={{ name: `${user.firstName} ${user.lastName}`, email: user.email, isAdmin: user.platformRole === "platform_admin" }}
    >
      {children}
    </AppShell>
  );
}
