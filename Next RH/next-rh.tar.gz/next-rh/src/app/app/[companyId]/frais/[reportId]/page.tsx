import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, HrError, UUID_RE } from "@/server/hr/common";
import { loadReport } from "@/server/hr/expenses";
import { addExpenseLineAction, decideExpenseReportAction, removeExpenseLineAction, submitExpenseReportAction } from "@/server/actions/expenses";
import { proofLinkAction } from "@/server/actions/requests";
import { ActionButton } from "@/components/hr/action-form";
import { ExpenseLines } from "@/components/hr/expense-report";
import { Notice, PageHeader } from "@/components/ui/surface";
import { StatusBadge } from "@/components/ui/badge";
import { fmtDate, monthLabel } from "@/lib/dates";
import { formatCents } from "@/lib/money";

export default async function ExpenseReportPage({ params }: { params: Promise<{ companyId: string; reportId: string }> }) {
  const { companyId, reportId } = await params;
  const ctx = await guardCompany(companyId, `/app/${companyId}/frais/${reportId}`, "employees.read");
  if (!UUID_RE.test(reportId)) notFound();
  let row;
  try {
    row = await loadReport(companyId, reportId);
  } catch (e) {
    if (e instanceof HrError) notFound();
    throw e;
  }
  const { r, e } = row;
  const canApprove = ctx.permissions.has("requests.approve");
  const lines = await db.select().from(schema.expenseLines).where(eq(schema.expenseLines.reportId, r.id)).orderBy(asc(schema.expenseLines.date));
  const [period] = r.reimbursedInPeriodId ? await db.select().from(schema.payrollPeriods).where(eq(schema.payrollPeriods.id, r.reimbursedInPeriodId)).limit(1) : [];
  const editable = canApprove && (r.status === "draft" || r.status === "rejected");
  const hidden = { companyId, reportId: r.id };

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Notes de frais", href: `/app/${companyId}/frais` }, { label: r.title }]}
        title={r.title}
        description={`${fullName(e)}, créée le ${fmtDate(r.createdAt)}.`}
        actions={
          <>
            <StatusBadge status={r.status} />
            {editable && lines.length ? <ActionButton action={submitExpenseReportAction} hidden={hidden} label="Soumettre à validation" variant="primary" size="md" /> : null}
            {canApprove && r.status === "pending" ? (
              <>
                <ActionButton action={decideExpenseReportAction} hidden={{ ...hidden, decision: "approve" }} label="Valider" variant="primary" size="md" confirm={{ title: "Valider la note de frais", description: `${formatCents(r.totalCents)} seront ajoutés aux variables de paie.`, confirmLabel: "Valider et transmettre" }} />
                <ActionButton action={decideExpenseReportAction} hidden={{ ...hidden, decision: "reject" }} label="Refuser" variant="secondary" size="md" confirm={{ title: "Refuser la note", confirmLabel: "Refuser", withNote: "Motif" }} />
              </>
            ) : null}
          </>
        }
      />
      {r.status === "approved" ? (
        <Notice tone="ok" className="mb-6">
          Validée le {fmtDate(r.decidedAt)} : {formatCents(r.totalCents)} ajoutés à la paie{period ? ` de ${monthLabel(period.year, period.month)}` : ""} (libellé « Remboursement de frais : {r.title} »).
        </Notice>
      ) : null}
      {r.status === "rejected" ? (
        <Notice tone="warn" className="mb-6">
          Note refusée : elle peut être corrigée puis soumise à nouveau.
        </Notice>
      ) : null}
      <ExpenseLines
        lines={lines}
        totalCents={r.totalCents}
        editable={editable}
        hidden={hidden}
        addAction={addExpenseLineAction}
        removeAction={removeExpenseLineAction}
        linkAction={proofLinkAction}
        linkHidden={{ companyId }}
      />
    </>
  );
}
