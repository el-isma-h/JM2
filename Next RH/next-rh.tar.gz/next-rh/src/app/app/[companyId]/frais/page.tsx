import Link from "next/link";
import { desc, inArray } from "drizzle-orm";
import { Plus, Wallet } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardCompany } from "@/server/guard";
import { fullName, listEmployees } from "@/server/hr/common";
import { createExpenseReportAction, decideExpenseReportAction } from "@/server/actions/expenses";
import { ActionButton, DialogForm } from "@/components/hr/action-form";
import { LinkTabs, Person } from "@/components/hr/bits";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";

export default async function FraisPage({ params, searchParams }: { params: Promise<{ companyId: string }>; searchParams: Promise<{ vue?: string }> }) {
  const { companyId } = await params;
  const sp = await searchParams;
  const base = `/app/${companyId}/frais`;
  const ctx = await guardCompany(companyId, base, "employees.read");
  const canApprove = ctx.permissions.has("requests.approve");
  const view = sp.vue === "toutes" ? "toutes" : "a-valider";
  const employees = await listEmployees(companyId, { includeLeft: true });
  const ids = employees.map((e) => e.id);
  const empById = new Map(employees.map((e) => [e.id, e]));
  const reports = ids.length
    ? await db.select().from(schema.expenseReports).where(inArray(schema.expenseReports.employeeId, ids)).orderBy(desc(schema.expenseReports.updatedAt)).limit(200)
    : [];
  const pending = reports.filter((r) => r.status === "pending");
  const shown = view === "toutes" ? reports : pending;
  const lineCounts = shown.length
    ? await db.select({ reportId: schema.expenseLines.reportId, receipt: schema.expenseLines.receiptDocumentId, category: schema.expenseLines.category }).from(schema.expenseLines).where(inArray(schema.expenseLines.reportId, shown.map((r) => r.id)))
    : [];
  const pendingTotal = pending.reduce((s, r) => s + r.totalCents, 0);

  return (
    <>
      <PageHeader
        title="Notes de frais"
        description="À la validation, le total est ajouté aux variables de paie du mois comme indemnité de remboursement (non soumise à cotisations)."
        actions={
          canApprove && employees.length ? (
            <DialogForm trigger={<><Plus size={16} /> Nouvelle note</>} title="Nouvelle note de frais" description="Créée au nom d'un salarié ; vous ajouterez ensuite les dépenses." action={createExpenseReportAction} hidden={{ companyId }} submitLabel="Créer la note">
              <Field label="Salarié" required htmlFor="ex-emp">
                <Select id="ex-emp" name="employeeId" required defaultValue="">
                  <option value="" disabled>
                    Choisir
                  </option>
                  {employees
                    .filter((e) => e.status !== "left")
                    .map((e) => (
                      <option key={e.id} value={e.id}>
                        {fullName(e)}
                      </option>
                    ))}
                </Select>
              </Field>
              <Field label="Titre" required htmlFor="ex-title" help="Ex. « Salon Batimat, novembre ».">
                <Input id="ex-title" name="title" required />
              </Field>
            </DialogForm>
          ) : null
        }
      />
      <LinkTabs
        label="Filtre des notes"
        current={view}
        items={[
          { key: "a-valider", label: "À valider", href: base, count: pending.length },
          { key: "toutes", label: "Toutes les notes", href: `${base}?vue=toutes` },
        ]}
      />
      <Panel>
        {view === "a-valider" && pending.length ? (
          <p className="border-b border-line px-5 py-3 text-[13.5px] text-ink-2">
            {pending.length} note(s) en attente pour un total de <span className="num font-medium text-ink">{formatCents(pendingTotal)}</span>.
          </p>
        ) : null}
        {shown.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Salarié</Th>
                <Th>Note</Th>
                <Th>Mise à jour</Th>
                <Th>Justificatifs</Th>
                <Th>Statut</Th>
                <Th num>Total</Th>
                <Th className="text-right">Action</Th>
              </tr>
            </thead>
            <tbody>
              {shown.map((r) => {
                const e = empById.get(r.employeeId)!;
                const lines = lineCounts.filter((l) => l.reportId === r.id);
                const missing = lines.filter((l) => !l.receipt && l.category !== "kilometrique").length;
                return (
                  <tr key={r.id}>
                    <Td>
                      <Person first={e.firstName} last={e.lastName} />
                    </Td>
                    <Td>
                      <Link href={`${base}/${r.id}`} className="font-medium text-ink hover:underline">
                        {r.title}
                      </Link>
                      <span className="block text-[12px] text-ink-3">{lines.length} dépense(s)</span>
                    </Td>
                    <Td className="whitespace-nowrap">{fmtDate(r.updatedAt)}</Td>
                    <Td>{lines.length ? (missing ? <span className="text-warn-ink">{missing} manquant(s)</span> : <span className="text-ok-ink">Complets</span>) : "-"}</Td>
                    <Td>
                      <StatusBadge status={r.status} />
                    </Td>
                    <Td num className="font-medium">
                      {formatCents(r.totalCents)}
                    </Td>
                    <Td className="text-right">
                      {canApprove && r.status === "pending" ? (
                        <div className="flex flex-wrap justify-end gap-1.5">
                          <ActionButton
                            action={decideExpenseReportAction}
                            hidden={{ companyId, reportId: r.id, decision: "approve" }}
                            label="Valider"
                            variant="primary"
                            confirm={{ title: "Valider la note de frais", description: `${formatCents(r.totalCents)} seront ajoutés aux variables de paie de ${fullName(e)}.`, confirmLabel: "Valider et transmettre" }}
                          />
                          <ActionButton action={decideExpenseReportAction} hidden={{ companyId, reportId: r.id, decision: "reject" }} label="Refuser" variant="ghost" confirm={{ title: "Refuser la note", confirmLabel: "Refuser", withNote: "Motif" }} />
                        </div>
                      ) : (
                        <Button asChild variant="ghost" size="sm">
                          <Link href={`${base}/${r.id}`}>Ouvrir</Link>
                        </Button>
                      )}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState
            icon={<Wallet size={28} />}
            title={view === "a-valider" ? "Aucune note à valider" : "Aucune note de frais"}
            description="Les salariés soumettent leurs notes depuis leur espace. Vous pouvez aussi en créer une à leur place."
          />
        )}
      </Panel>
    </>
  );
}
