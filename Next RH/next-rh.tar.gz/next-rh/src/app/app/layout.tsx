import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth";

export default async function AppRootLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/connexion?next=/app");
  if (!user.emailVerified) redirect("/verification");
  return <>{children}</>;
}
