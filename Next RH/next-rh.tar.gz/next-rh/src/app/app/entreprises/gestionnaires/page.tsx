import { and, desc, eq, inArray, ne, or } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireUser } from "@/server/auth";
import { getCompanyContext } from "@/server/authz";
import { listManagedCompanies } from "@/server/firm/dossiers";
import { assignManagerAction, inviteManagerAction, revokeInvitationAction } from "@/server/actions/firm";
import { fmtDate } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { RoleCell } from "@/components/firm/role-cell";
import { FIRM_ROLES } from "@/components/firm/roles";

export const dynamic = "force-dynamic";

const roleLabel: Record<string, string> = Object.fromEntries(FIRM_ROLES.map((r) => [r.value, r.label]));

export default async function ManagersPage() {
  const user = await requireUser();
  const companies = await listManagedCompanies(user);
  // Seules les entreprises où l'utilisateur gère les accès sont modifiables (vérifié aussi côté action).
  const contexts = await Promise.all(companies.map((c) => getCompanyContext(c.id)));
  const manageable = companies.filter((_, i) => contexts[i]?.permissions.has("members.manage"));
  const ids = companies.map((c) => c.id);
  const manageableIds = new Set(manageable.map((c) => c.id));
  const tenantIds = [...new Set(companies.map((c) => c.tenantId))];

  const [memberships, tenantUsers, invitations] = ids.length
    ? await Promise.all([
        db
          .select({ m: schema.companyMemberships, u: schema.users })
          .from(schema.companyMemberships)
          .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
          .where(and(inArray(schema.companyMemberships.companyId, ids), ne(schema.companyMemberships.role, "employee"))),
        // Membres du cabinet (même tenant) qui peuvent être affectés, même sans affectation actuelle.
        user.tenantId && tenantIds.includes(user.tenantId)
          ? db
              .select()
              .from(schema.users)
              .where(and(eq(schema.users.tenantId, user.tenantId), ne(schema.users.platformRole, "platform_admin")))
          : Promise.resolve([] as (typeof schema.users.$inferSelect)[]),
        manageable.length
          ? db
              .select()
              .from(schema.invitations)
              .where(and(inArray(schema.invitations.companyId, [...manageableIds]), eq(schema.invitations.status, "pending")))
              .orderBy(desc(schema.invitations.createdAt))
          : Promise.resolve([] as (typeof schema.invitations.$inferSelect)[]),
      ])
    : [[], [], []];

  // Salariés de démo et comptes salariés : exclus de la matrice des gestionnaires.
  const employeeOnly = new Set(
    (ids.length
      ? await db
          .select({ userId: schema.employees.userId })
          .from(schema.employees)
          .where(and(inArray(schema.employees.companyId, ids), or(eq(schema.employees.status, "active"), eq(schema.employees.status, "draft"))))
      : []
    )
      .map((e) => e.userId)
      .filter(Boolean) as string[],
  );
  const people = new Map<string, typeof schema.users.$inferSelect>();
  for (const { u } of memberships) people.set(u.id, u);
  for (const u of tenantUsers) if (!employeeOnly.has(u.id) || memberships.some((m) => m.u.id === u.id)) people.set(u.id, u);
  const roleOf = (userId: string, companyId: string) => memberships.find((m) => m.u.id === userId && m.m.companyId === companyId)?.m.role ?? "none";
  const name = (c: (typeof companies)[number]) => c.tradeName ?? c.legalName;
  const sorted = [...people.values()].sort((a, b) => a.lastName.localeCompare(b.lastName));

  return (
    <>
      <PageHeader title="Gestionnaires" description="Qui gère quel dossier, avec quel rôle. Chaque gestionnaire n'accède qu'aux entreprises où il est affecté. Un membre du cabinet sans affectation garde un accès en lecture seule aux entreprises du cabinet." />
      {!companies.length ? (
        <Panel>
          <EmptyState title="Aucun dossier" description="Vous n'êtes affecté à aucune entreprise." />
        </Panel>
      ) : (
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Affectations" description={manageable.length ? "Changez un rôle dans la liste : une confirmation est demandée avant tout changement." : "Vous consultez les affectations : seul un propriétaire ou un administrateur du dossier peut les modifier."} />
            {sorted.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th className="min-w-[200px]">Gestionnaire</Th>
                    {companies.map((c) => (
                      <Th key={c.id} className="min-w-[160px]">
                        {name(c)}
                      </Th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((u) => (
                    <tr key={u.id}>
                      <Td>
                        <p className="font-medium">
                          {u.firstName} {u.lastName}
                          {u.id === user.id ? <span className="font-normal text-ink-3"> (vous)</span> : null}
                        </p>
                        <p className="text-[12px] text-ink-3">{u.email}</p>
                        {u.disabledAt ? <Badge tone="danger">Désactivé</Badge> : null}
                      </Td>
                      {companies.map((c) => (
                        <Td key={c.id}>
                          <RoleCell action={assignManagerAction} companyId={c.id} companyName={name(c)} userId={u.id} userName={`${u.firstName} ${u.lastName}`} current={roleOf(u.id, c.id)} disabled={!manageableIds.has(c.id) || u.id === user.id} />
                        </Td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucun gestionnaire" description="Invitez un premier gestionnaire ci-dessous." />
            )}
          </Panel>

          <div className="grid gap-6 lg:grid-cols-2">
            <Panel className="self-start">
              <PanelHeader title="Inviter un gestionnaire" description="Une invitation par entreprise, valable 7 jours. Sans service e-mail, le lien s'affiche pour être transmis." />
              {manageable.length ? (
                <ActionForm action={inviteManagerAction} submitLabel="Envoyer l'invitation" className="px-5 py-4" footerClassName="mt-4">
                  <div className="space-y-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="Adresse e-mail" required htmlFor="i-email">
                        <Input id="i-email" name="email" type="email" required />
                      </Field>
                      <Field label="Rôle" htmlFor="i-role">
                        <Select id="i-role" name="role" defaultValue="payroll">
                          {FIRM_ROLES.filter((r) => r.value !== "none").map((r) => (
                            <option key={r.value} value={r.value}>
                              {r.label}
                            </option>
                          ))}
                        </Select>
                      </Field>
                    </div>
                    <fieldset>
                      <legend className="mb-1.5 text-[13px] font-medium text-ink">Entreprises</legend>
                      <div className="grid gap-2 sm:grid-cols-2">
                        {manageable.map((c) => (
                          <Checkbox key={c.id} name="companyIds" value={c.id} label={name(c)} defaultChecked={manageable.length === 1} />
                        ))}
                      </div>
                    </fieldset>
                  </div>
                </ActionForm>
              ) : (
                <Notice tone="info" className="m-5">
                  Vous n&apos;êtes propriétaire ou administrateur d&apos;aucun dossier : vous ne pouvez pas inviter.
                </Notice>
              )}
            </Panel>

            <Panel className="self-start">
              <PanelHeader title="Invitations en attente" />
              {invitations.length ? (
                <Table>
                  <tbody>
                    {invitations.map((i) => (
                      <tr key={i.id}>
                        <Td>
                          {i.email}
                          <p className="text-[12px] text-ink-3">
                            {roleLabel[i.role] ?? i.role} sur {name(companies.find((c) => c.id === i.companyId)!)}, expire le {fmtDate(i.expiresAt)}
                          </p>
                        </Td>
                        <Td className="text-right">
                          <ActionButton action={revokeInvitationAction} fields={{ invitationId: i.id }} label="Révoquer" variant="ghost" confirm={{ title: "Révoquer l'invitation", description: `Le lien envoyé à ${i.email} ne fonctionnera plus.`, confirmLabel: "Révoquer", danger: true }} />
                        </Td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              ) : (
                <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune invitation en attente.</p>
              )}
            </Panel>
          </div>
        </div>
      )}
    </>
  );
}
