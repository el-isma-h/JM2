import Link from "next/link";
import { addDays, format } from "date-fns";
import { requireUser } from "@/server/auth";
import { canCreateFirmCompany, listManagedCompanies, loadDossiers } from "@/server/firm/dossiers";
import { createFirmCompanyAction } from "@/server/actions/firm";
import { fmtDate, isoToday, monthLabel } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { FormDialog } from "@/components/admin/form-dialog";

export const dynamic = "force-dynamic";

const roleLabel: Record<string, string> = { owner: "Propriétaire", admin: "Administrateur", hr: "RH", payroll: "Paie", manager: "Manager", accountant: "Comptable", viewer: "Lecture seule" };

export default async function DossiersPage() {
  const user = await requireUser();
  const companies = await listManagedCompanies(user);
  const [dossiers, allowed] = await Promise.all([loadDossiers(user, companies), canCreateFirmCompany(user)]);
  const now = new Date();
  const today = isoToday();
  const inTwoWeeks = format(addDays(now, 14), "yyyy-MM-dd");

  const create = allowed.ok ? (
    <FormDialog action={createFirmCompanyAction} trigger="Nouveau dossier" title="Nouveau dossier d'entreprise" description={`L'entreprise est créée dans ${allowed.tenant.name}. Vous en êtes propriétaire ; l'onboarding guidé complète ensuite les paramètres de paie.`} submitLabel="Créer le dossier">
      <Field label="Raison sociale" required htmlFor="f-legal">
        <Input id="f-legal" name="legalName" required />
      </Field>
      <Field label="Nom commercial" htmlFor="f-trade">
        <Input id="f-trade" name="tradeName" />
      </Field>
      <Field label="SIREN" htmlFor="f-siren" help="9 chiffres. Facultatif à ce stade : il sera demandé pendant l'onboarding.">
        <Input id="f-siren" name="siren" inputMode="numeric" />
      </Field>
    </FormDialog>
  ) : null;

  return (
    <FadeIn>
      <PageHeader
        title="Dossiers"
        description={`Toutes les entreprises auxquelles vous avez accès, avec la paie de ${monthLabel(now.getFullYear(), now.getMonth() + 1)} et la prochaine échéance.`}
        actions={create}
      />
      <Panel>
        {dossiers.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Entreprise</Th>
                <Th>Onboarding</Th>
                <Th>Paie du mois</Th>
                <Th num>Anomalies</Th>
                <Th>Prochaine échéance</Th>
                <Th>Gestionnaires</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {dossiers.map((d) => {
                const c = d.company;
                const soon = d.nextDeadline && d.nextDeadline.dueDate <= inTwoWeeks;
                return (
                  <tr key={c.id}>
                    <Td>
                      <Link href={`/app/${c.id}`} className="font-medium text-ink hover:underline">
                        {c.tradeName ?? c.legalName}
                      </Link>
                      {c.isDemo ? (
                        <Badge tone="warn" className="ml-2">
                          Démo
                        </Badge>
                      ) : null}
                      <p className="text-[12px] text-ink-3">
                        <span className="num">{c.siren ?? "SIREN à compléter"}</span>, {d.activeEmployees} salarié{d.activeEmployees > 1 ? "s" : ""} actif{d.activeEmployees > 1 ? "s" : ""}
                        {d.myRole ? `, vous : ${roleLabel[d.myRole] ?? d.myRole}` : ""}
                      </p>
                    </Td>
                    <Td>{c.onboardingCompletedAt ? <Badge tone="ok">Terminé</Badge> : <Badge tone="warn">À terminer</Badge>}</Td>
                    <Td>
                      {d.period ? (
                        <>
                          <StatusBadge status={d.period.status} />
                          {d.period.paymentDate ? <p className="mt-0.5 text-[12px] text-ink-3">Paiement le {fmtDate(d.period.paymentDate)}</p> : null}
                        </>
                      ) : (
                        <span className="text-[13px] text-ink-3">Non ouverte</span>
                      )}
                    </Td>
                    <Td num>
                      {d.openAnomalies ? <span className={d.blockingAnomalies ? "font-medium text-danger-ink" : "text-warn-ink"}>{d.openAnomalies}</span> : <span className="text-ink-3">0</span>}
                      {d.blockingAnomalies ? <p className="text-[11.5px] text-danger-ink">dont {d.blockingAnomalies} bloquante{d.blockingAnomalies > 1 ? "s" : ""}</p> : null}
                    </Td>
                    <Td className="max-w-[260px]">
                      {d.nextDeadline ? (
                        <>
                          <p className={soon ? "text-[13px] font-medium text-warn-ink" : "text-[13px]"}>{d.nextDeadline.dueDate === today ? "Aujourd'hui" : fmtDate(d.nextDeadline.dueDate)}</p>
                          <p className="line-clamp-1 text-[12px] text-ink-2">{d.nextDeadline.title}</p>
                        </>
                      ) : (
                        <span className="text-[13px] text-ink-3">Aucune</span>
                      )}
                    </Td>
                    <Td className="max-w-[220px] text-[12.5px] text-ink-2">{d.managers.length ? d.managers.map((m) => m.name).join(", ") : <span className="text-ink-3">Aucun</span>}</Td>
                    <Td className="text-right">
                      <Button asChild variant="secondary" size="sm">
                        <Link href={`/app/${c.id}`}>Ouvrir</Link>
                      </Button>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState
            title="Aucun dossier"
            description={allowed.ok ? "Créez le premier dossier d'entreprise de votre cabinet." : "Vous n'êtes affecté à aucune entreprise. Demandez une invitation au responsable du dossier."}
            action={create}
          />
        )}
      </Panel>
      {!allowed.ok && dossiers.length ? <p className="mt-3 text-[12.5px] text-ink-3">{allowed.reason}</p> : null}
    </FadeIn>
  );
}
