import Link from "next/link";
import { and, asc, eq, gte, inArray, lte, or } from "drizzle-orm";
import { addDays, format } from "date-fns";
import { db, schema } from "@/db";
import { requireUser } from "@/server/auth";
import { listManagedCompanies } from "@/server/firm/dossiers";
import { fmtDate, isoToday, monthLabel } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";

export const dynamic = "force-dynamic";

const kindLabel: Record<string, string> = {
  periode_essai: "Fin de période d'essai",
  fin_cdd: "Fin de CDD",
  habilitation: "Habilitation",
  entretien: "Entretien",
  visite_medicale: "Visite médicale",
  formation: "Formation",
};

export default async function FirmDeadlinesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const user = await requireUser();
  const sp = await searchParams;
  const companies = await listManagedCompanies(user);
  const only = typeof sp.entreprise === "string" ? sp.entreprise : "";
  const horizon = Number(typeof sp.horizon === "string" ? sp.horizon : 60) || 60;
  // Isolation : on ne lit que les entreprises accessibles, même si un identifiant est passé dans l'URL.
  const ids = companies.map((c) => c.id).filter((id) => !only || id === only);
  const names = new Map(companies.map((c) => [c.id, c.tradeName ?? c.legalName]));
  const today = isoToday();
  const until = format(addDays(new Date(), horizon), "yyyy-MM-dd");
  const now = new Date();
  const thisMonth = { y: now.getFullYear(), m: now.getMonth() + 1 };
  const next = now.getMonth() === 11 ? { y: now.getFullYear() + 1, m: 1 } : { y: now.getFullYear(), m: now.getMonth() + 2 };

  const [deadlines, periods] = ids.length
    ? await Promise.all([
        db
          .select({ d: schema.deadlines, first: schema.employees.firstName, last: schema.employees.lastName })
          .from(schema.deadlines)
          .leftJoin(schema.employees, eq(schema.employees.id, schema.deadlines.employeeId))
          .where(and(inArray(schema.deadlines.companyId, ids), lte(schema.deadlines.dueDate, until), or(gte(schema.deadlines.dueDate, today), eq(schema.deadlines.status, "upcoming"))))
          .orderBy(asc(schema.deadlines.dueDate)),
        db
          .select()
          .from(schema.payrollPeriods)
          .where(and(inArray(schema.payrollPeriods.companyId, ids), or(and(eq(schema.payrollPeriods.year, thisMonth.y), eq(schema.payrollPeriods.month, thisMonth.m)), and(eq(schema.payrollPeriods.year, next.y), eq(schema.payrollPeriods.month, next.m)))))
          .orderBy(asc(schema.payrollPeriods.year), asc(schema.payrollPeriods.month)),
      ])
    : [[], []];

  return (
    <>
      <PageHeader title="Échéances" description="Échéances RH et calendrier de paie de tous vos dossiers. Les échéances dépassées encore ouvertes restent affichées." />
      <form method="get" className="mb-6 flex flex-wrap items-end gap-3">
        <Field label="Entreprise" htmlFor="entreprise" className="w-64">
          <Select id="entreprise" name="entreprise" defaultValue={only}>
            <option value="">Tous les dossiers</option>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>
                {c.tradeName ?? c.legalName}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Horizon" htmlFor="horizon" className="w-44">
          <Select id="horizon" name="horizon" defaultValue={String(horizon)}>
            <option value="14">14 jours</option>
            <option value="30">30 jours</option>
            <option value="60">60 jours</option>
            <option value="120">120 jours</option>
          </Select>
        </Field>
        <Button type="submit" variant="secondary">
          Afficher
        </Button>
      </form>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
        <Panel>
          <PanelHeader title="Échéances RH" description={`Jusqu'au ${fmtDate(until)}.`} />
          {deadlines.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Date</Th>
                  <Th>Échéance</Th>
                  <Th>Entreprise</Th>
                </tr>
              </thead>
              <tbody>
                {deadlines.map(({ d, first, last }) => {
                  const late = d.dueDate < today;
                  return (
                    <tr key={d.id}>
                      <Td className="whitespace-nowrap">
                        <span className={late ? "font-medium text-danger-ink" : undefined}>{fmtDate(d.dueDate)}</span>
                        {late ? <p className="text-[11.5px] text-danger-ink">Dépassée</p> : null}
                      </Td>
                      <Td>
                        <p className="text-[13px]">{d.title}</p>
                        <p className="text-[12px] text-ink-3">
                          {kindLabel[d.kind] ?? d.kind}
                          {first ? `, ${first} ${last}` : ""}
                        </p>
                      </Td>
                      <Td>
                        <Link href={`/app/${d.companyId}/echeances`} className="text-[13px] text-ink-2 hover:underline">
                          {names.get(d.companyId)}
                        </Link>
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune échéance" description="Rien à prévoir sur cette période." />
          )}
        </Panel>

        <Panel className="self-start">
          <PanelHeader title="Calendrier de paie" description={`${monthLabel(thisMonth.y, thisMonth.m)} et ${monthLabel(next.y, next.m)}.`} />
          {ids.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Entreprise</Th>
                  <Th>Mois</Th>
                  <Th>Statut</Th>
                </tr>
              </thead>
              <tbody>
                {ids.map((id) => {
                  const ps = periods.filter((p) => p.companyId === id);
                  return (
                    <tr key={id}>
                      <Td className="text-[13px]">
                        <Link href={`/app/${id}/paie`} className="hover:underline">
                          {names.get(id)}
                        </Link>
                      </Td>
                      <Td className="text-[13px] text-ink-2">{ps.length ? ps.map((p) => monthLabel(p.year, p.month)).join(", ") : monthLabel(thisMonth.y, thisMonth.m)}</Td>
                      <Td>
                        {ps.length ? (
                          <div className="flex flex-col gap-1">
                            {ps.map((p) => (
                              <span key={p.id} className="flex items-center gap-1">
                                <StatusBadge status={p.status} />
                                {p.paymentDate ? <span className="text-[11.5px] text-ink-3">paiement {fmtDate(p.paymentDate, "d MMM")}</span> : null}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <Badge tone="neutral">Non ouverte</Badge>
                        )}
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucun dossier" />
          )}
        </Panel>
      </div>
    </>
  );
}
