import Link from "next/link";
import { requireUser } from "@/server/auth";
import { AppShell } from "@/components/app/shell";
import { Logo } from "@/components/ui/logo";

export default async function FirmLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  return (
    <AppShell
      base="/app/entreprises"
      items={[
        { label: "Dossiers", href: "", icon: "Buildings" },
        { label: "Échéances", href: "/echeances", icon: "Bell" },
        { label: "Gestionnaires", href: "/gestionnaires", icon: "UsersThree" },
      ]}
      brand={
        <Link href="/app" className="text-ink" aria-label="Next RH">
          <Logo />
        </Link>
      }
      user={{ name: `${user.firstName} ${user.lastName}`, email: user.email, isAdmin: user.platformRole === "platform_admin" }}
    >
      {children}
    </AppShell>
  );
}
