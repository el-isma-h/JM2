import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Next RH", template: "%s · Next RH" },
  description: "La paie, les ressources humaines et vos documents réunis dans une seule plateforme.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `try{var t=localStorage.getItem('nextrh-theme');if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('dark')}catch(e){}`,
          }}
        />
      </head>
      <body className="min-h-[100dvh]">{children}</body>
    </html>
  );
}
