import { asc } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { deleteRegistryAction, reseedRegistryAction, saveRegistryAction } from "@/server/actions/admin";
import { integrations } from "@/lib/env";
import { fmtDate } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Field, Input, Textarea } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";

export const dynamic = "force-dynamic";

type Cat = { name: string; retention?: string; basis?: string };
type Row = typeof schema.processingRegistry.$inferSelect;

function RegistryFields({ row }: { row?: Row }) {
  const cats = (Array.isArray(row?.dataCategories) ? row.dataCategories : []) as Cat[];
  return (
    <>
      {row ? <input type="hidden" name="id" value={row.id} /> : null}
      <Field label="Traitement" required htmlFor={`r-name-${row?.id ?? "new"}`}>
        <Input id={`r-name-${row?.id ?? "new"}`} name="name" defaultValue={row?.name} required />
      </Field>
      <Field label="Finalité" required htmlFor={`r-purpose-${row?.id ?? "new"}`}>
        <Textarea id={`r-purpose-${row?.id ?? "new"}`} name="purpose" defaultValue={row?.purpose} required className="min-h-16" />
      </Field>
      <Field label="Catégories de données et durée de conservation" required htmlFor={`r-cats-${row?.id ?? "new"}`} help="Une ligne par catégorie : catégorie | durée de conservation | texte de référence.">
        <Textarea id={`r-cats-${row?.id ?? "new"}`} name="categories" defaultValue={cats.map((c) => [c.name, c.retention, c.basis].filter(Boolean).join(" | ")).join("\n")} required className="num min-h-28 text-[12.5px]" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Sous-traitant" htmlFor={`r-proc-${row?.id ?? "new"}`}>
          <Input id={`r-proc-${row?.id ?? "new"}`} name="processor" defaultValue={row?.processor ?? ""} />
        </Field>
        <Field label="Localisation des données" htmlFor={`r-loc-${row?.id ?? "new"}`}>
          <Input id={`r-loc-${row?.id ?? "new"}`} name="location" defaultValue={row?.location ?? ""} />
        </Field>
      </div>
      <Field label="Durée de conservation (synthèse)" required htmlFor={`r-ret-${row?.id ?? "new"}`}>
        <Textarea id={`r-ret-${row?.id ?? "new"}`} name="retention" defaultValue={row?.retention} required className="min-h-14" />
      </Field>
      <Field label="Base légale" required htmlFor={`r-basis-${row?.id ?? "new"}`}>
        <Input id={`r-basis-${row?.id ?? "new"}`} name="legalBasis" defaultValue={row?.legalBasis} required />
      </Field>
    </>
  );
}

export default async function RegistryPage() {
  await guardAdmin("/admin/registre");
  const rows = await db.select().from(schema.processingRegistry).orderBy(asc(schema.processingRegistry.createdAt));
  const active = (processor: string | null) => {
    if (!processor) return null;
    if (/anthropic/i.test(processor)) return integrations.ai();
    if (/resend/i.test(processor)) return integrations.mail();
    return null;
  };
  return (
    <>
      <PageHeader
        title="Registre des traitements"
        description="Registre RGPD (article 30) des traitements mis en oeuvre par Next RH, avec durées de conservation par catégorie et sous-traitants. Politique détaillée : docs/donnees-personnelles.md."
        actions={
          <>
            <ActionButton action={reseedRegistryAction} fields={{}} label="Compléter avec les traitements de l'application" />
            <FormDialog action={saveRegistryAction} trigger="Nouveau traitement" title="Nouveau traitement" submitLabel="Enregistrer" wide>
              <RegistryFields />
            </FormDialog>
          </>
        }
      />
      <Panel>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Traitement et finalité</Th>
                <Th>Catégories et conservation</Th>
                <Th>Sous-traitant</Th>
                <Th>Base légale</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const cats = (Array.isArray(r.dataCategories) ? r.dataCategories : []) as Cat[];
                const on = active(r.processor);
                return (
                  <tr key={r.id} className="align-top">
                    <Td className="max-w-[260px] align-top">
                      <p className="font-medium">{r.name}</p>
                      <p className="mt-1 text-[12.5px] text-ink-2">{r.purpose}</p>
                      <p className="mt-1 text-[11.5px] text-ink-3">Mis à jour le {fmtDate(r.updatedAt)}</p>
                    </Td>
                    <Td className="max-w-[380px] align-top">
                      {cats.map((c, i) => (
                        <div key={i} className={i ? "mt-2" : undefined}>
                          <p className="text-[12.5px] text-ink">{c.name}</p>
                          <p className="text-[12px] text-ink-2">
                            {c.retention}
                            {c.basis ? <span className="text-ink-3"> ({c.basis})</span> : null}
                          </p>
                        </div>
                      ))}
                    </Td>
                    <Td className="max-w-[220px] align-top text-[12.5px] text-ink-2">
                      {r.processor ?? "-"}
                      {on !== null ? (
                        <div className="mt-1">
                          <Badge tone={on ? "ok" : "neutral"}>{on ? "Activé" : "Non activé"}</Badge>
                        </div>
                      ) : null}
                      {r.location ? <p className="mt-1 text-ink-3">{r.location}</p> : null}
                    </Td>
                    <Td className="max-w-[200px] align-top text-[12.5px] text-ink-2">{r.legalBasis}</Td>
                    <Td className="align-top">
                      <div className="flex flex-col items-end gap-1">
                        <FormDialog action={saveRegistryAction} trigger="Modifier" triggerVariant="ghost" triggerSize="sm" title={`Modifier : ${r.name}`} submitLabel="Enregistrer" wide>
                          <RegistryFields row={r} />
                        </FormDialog>
                        <ActionButton action={deleteRegistryAction} fields={{ id: r.id }} label="Supprimer" variant="ghost" confirm={{ title: `Supprimer « ${r.name} »`, description: "Le traitement est retiré du registre. Le registre doit rester complet : ne supprimez que les traitements arrêtés.", phrase: "SUPPRIMER", danger: true, confirmLabel: "Supprimer" }} />
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Registre vide" description="Chargez les traitements réellement mis en oeuvre par l'application." action={<ActionButton action={reseedRegistryAction} fields={{}} label="Charger les traitements" variant="primary" size="md" />} />
        )}
      </Panel>
    </>
  );
}
