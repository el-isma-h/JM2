import Link from "next/link";
import { asc, desc, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { auditWhere, readAuditFilters } from "@/server/admin/audit-query";
import { fmtDateTime } from "@/lib/dates";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Pagination, readPage } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
const PAGE = 50;

function summarize(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = JSON.stringify(v);
  return s.length > 140 ? `${s.slice(0, 139)}…` : s;
}

export default async function AuditPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await guardAdmin("/admin/audit");
  const sp = await searchParams;
  const f = readAuditFilters(sp);
  const page = readPage(sp.page);
  const where = auditWhere(f);

  const [rows, [{ total }], companies] = await Promise.all([
    db
      .select({ a: schema.auditLogs, email: schema.users.email, company: schema.companies.legalName })
      .from(schema.auditLogs)
      .leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId))
      .leftJoin(schema.companies, eq(schema.companies.id, schema.auditLogs.companyId))
      .where(where)
      .orderBy(desc(schema.auditLogs.createdAt))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.auditLogs).leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId)).where(where),
    db.select({ id: schema.companies.id, name: schema.companies.legalName }).from(schema.companies).where(eq(schema.companies.isDemo, false)).orderBy(asc(schema.companies.legalName)).limit(500),
  ]);
  const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v) as [string, string][]).toString();

  return (
    <>
      <PageHeader
        title="Journal d'audit"
        description="Toutes les actions sensibles, lues ou écrites. Le journal n'est jamais modifié depuis l'interface."
        actions={
          <Button asChild variant="secondary">
            <a href={`/admin/audit/export${qs ? `?${qs}` : ""}`}>Exporter en CSV</a>
          </Button>
        }
      />
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Utilisateur" htmlFor="user" className="w-56">
            <Input id="user" name="user" defaultValue={f.user} placeholder="E-mail ou identifiant" />
          </Field>
          <Field label="Entreprise" htmlFor="company" className="w-56">
            <Select id="company" name="company" defaultValue={f.company ?? ""}>
              <option value="">Toutes</option>
              {companies.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Action" htmlFor="action" className="w-44">
            <Input id="action" name="action" defaultValue={f.action} placeholder="ex. payroll, admin." />
          </Field>
          <Field label="Du" htmlFor="from" className="w-40">
            <Input id="from" name="from" type="date" defaultValue={f.from} />
          </Field>
          <Field label="Au" htmlFor="to" className="w-40">
            <Input id="to" name="to" type="date" defaultValue={f.to} />
          </Field>
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
          {qs ? (
            <Button asChild variant="ghost">
              <Link href="/admin/audit">Effacer</Link>
            </Button>
          ) : null}
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th>Action</Th>
                <Th>Utilisateur</Th>
                <Th>Entreprise</Th>
                <Th>Objet</Th>
                <Th>Détail</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ a, email, company }) => (
                <tr key={a.id}>
                  <Td className="whitespace-nowrap text-ink-2">{fmtDateTime(a.createdAt)}</Td>
                  <Td className="num text-[12.5px] font-medium">{a.action}</Td>
                  <Td className="text-ink-2">
                    {a.userId ? (
                      <Link href={`/admin/utilisateurs/${a.userId}`} className="hover:underline">
                        {email ?? "Compte supprimé"}
                      </Link>
                    ) : (
                      "Système"
                    )}
                    {a.ip ? <p className="num text-[11.5px] text-ink-3">{a.ip}</p> : null}
                  </Td>
                  <Td className="text-ink-2">{company ?? "-"}</Td>
                  <Td className="num text-[12px] text-ink-3">{a.entityType ? `${a.entityType}${a.entityId ? ` ${a.entityId.slice(0, 8)}` : ""}` : "-"}</Td>
                  <Td className="num max-w-[320px] truncate text-[11.5px] text-ink-3" title={summarize(a.after)}>
                    {summarize(a.after ?? a.before)}
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune entrée" description="Aucune action ne correspond à ces filtres." />
        )}
        <Pagination basePath="/admin/audit" params={{ ...f }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
