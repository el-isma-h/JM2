import Link from "next/link";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { integrations } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
const PAGE = 50;
const STATUSES = schema.mailStatusEnum.enumValues;

export default async function OutboxPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await guardAdmin("/admin/boite-envoi");
  const sp = await searchParams;
  const q = readParam(sp.q);
  const status = readParam(sp.status);
  const demo = readParam(sp.demo) === "1";
  const page = readPage(sp.page);
  const conds: SQL[] = [];
  if (!demo) conds.push(eq(schema.mailOutbox.isDemo, false));
  if (status && (STATUSES as readonly string[]).includes(status)) conds.push(eq(schema.mailOutbox.status, status as (typeof STATUSES)[number]));
  if (q) conds.push(or(ilike(schema.mailOutbox.to, `%${q}%`), ilike(schema.mailOutbox.subject, `%${q}%`))!);
  const where = conds.length ? and(...conds) : undefined;
  const [rows, [{ total }]] = await Promise.all([
    db
      .select({ id: schema.mailOutbox.id, to: schema.mailOutbox.to, subject: schema.mailOutbox.subject, status: schema.mailOutbox.status, error: schema.mailOutbox.error, isDemo: schema.mailOutbox.isDemo, createdAt: schema.mailOutbox.createdAt, sentAt: schema.mailOutbox.sentAt })
      .from(schema.mailOutbox)
      .where(where)
      .orderBy(desc(schema.mailOutbox.createdAt))
      .limit(PAGE)
      .offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.mailOutbox).where(where),
  ]);

  return (
    <>
      <PageHeader title="Boîte d'envoi" description="Chaque e-mail de l'application est journalisé ici, qu'il soit parti ou non." />
      {!integrations.mail() ? (
        <Notice tone="warn" className="mb-6" title="Service e-mail non configuré">
          Les e-mails ne partent pas (RESEND_API_KEY absente). Ouvrez un e-mail pour copier le lien de vérification, de réinitialisation ou d&apos;invitation qu&apos;il contient et le transmettre à la personne.
        </Notice>
      ) : null}
      <Panel>
        <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
          <Field label="Recherche" htmlFor="q" className="w-full max-w-xs">
            <Input id="q" name="q" defaultValue={q} placeholder="Destinataire ou objet" />
          </Field>
          <Field label="Statut" htmlFor="status" className="w-56">
            <Select id="status" name="status" defaultValue={status ?? ""}>
              <option value="">Tous</option>
              <option value="sent">Envoyés</option>
              <option value="failed">En échec</option>
              <option value="skipped_not_configured">Non envoyés (non configuré)</option>
              <option value="queued">En file</option>
            </Select>
          </Field>
          <Checkbox name="demo" value="1" defaultChecked={demo} label="Inclure les démonstrations" className="mb-2" />
          <Button type="submit" variant="secondary">
            Filtrer
          </Button>
        </form>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Objet</Th>
                <Th>Destinataire</Th>
                <Th>Statut</Th>
                <Th>Date</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((m) => (
                <tr key={m.id}>
                  <Td>
                    <Link href={`/admin/boite-envoi/${m.id}`} className="font-medium hover:underline">
                      {m.subject}
                    </Link>
                    {m.error && m.error !== "demo" ? <p className="line-clamp-1 text-[12px] text-danger-ink">{m.error}</p> : null}
                  </Td>
                  <Td className="text-ink-2">{m.to}</Td>
                  <Td>
                    <div className="flex gap-1">
                      <StatusBadge status={m.status} />
                      {m.isDemo ? <Badge tone="warn">Démo</Badge> : null}
                    </div>
                  </Td>
                  <Td className="whitespace-nowrap text-ink-2">{fmtDateTime(m.sentAt ?? m.createdAt)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun e-mail" description="Aucun e-mail ne correspond à ces critères." />
        )}
        <Pagination basePath="/admin/boite-envoi" params={{ q, status, demo: demo ? "1" : undefined }} page={page} pageSize={PAGE} total={total} />
      </Panel>
    </>
  );
}
