import Link from "next/link";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { fmtDate } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";

export const dynamic = "force-dynamic";

export default async function TemplatesPage() {
  await guardAdmin("/admin/modeles");
  const rows = await db
    .select({ t: schema.documentTemplates, company: schema.companies.legalName })
    .from(schema.documentTemplates)
    .leftJoin(schema.companies, eq(schema.companies.id, schema.documentTemplates.companyId))
    .orderBy(asc(schema.documentTemplates.category), asc(schema.documentTemplates.title));
  return (
    <>
      <PageHeader title="Modèles de documents" description="Modèles communs à la plateforme et modèles propres à une entreprise. Consultation seule : les modèles sont publiés par le module documents." />
      <Panel>
        {rows.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Modèle</Th>
                <Th>Catégorie</Th>
                <Th>Portée</Th>
                <Th num>Version</Th>
                <Th num>Questions</Th>
                <Th>Vérification</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ t, company }) => (
                <tr key={t.id}>
                  <Td>
                    <Link href={`/admin/modeles/${t.id}`} className="font-medium hover:underline">
                      {t.title}
                    </Link>
                    <p className="num text-[12px] text-ink-3">{t.code}</p>
                  </Td>
                  <Td className="text-ink-2">{t.category}</Td>
                  <Td>{t.companyId ? <span className="text-ink-2">{company}</span> : <Badge tone="neutral">Plateforme</Badge>}</Td>
                  <Td num>{t.version}</Td>
                  <Td num>{Array.isArray(t.questions) ? t.questions.length : 0}</Td>
                  <Td>
                    <div className="flex flex-wrap gap-1">
                      {t.verifiedAt ? <Badge tone="ok">Vérifié le {fmtDate(t.verifiedAt)}</Badge> : <Badge tone="warn">Non vérifié</Badge>}
                      {t.isLegal ? <Badge tone="info">Juridique</Badge> : null}
                    </div>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun modèle" description="Les modèles communs sont chargés par l'initialisation (npm run setup)." />
        )}
      </Panel>
    </>
  );
}
