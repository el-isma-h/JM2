import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { KeyValue, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";

export const dynamic = "force-dynamic";

type Question = { key?: string; label?: string; type?: string; required?: boolean; help?: string };

export default async function TemplateDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) notFound();
  await guardAdmin(`/admin/modeles/${id}`);
  const [t] = await db.select().from(schema.documentTemplates).where(eq(schema.documentTemplates.id, id)).limit(1);
  if (!t) notFound();
  const questions = (Array.isArray(t.questions) ? t.questions : []) as Question[];
  const points = (Array.isArray(t.legalReviewPoints) ? t.legalReviewPoints : []) as (string | { label?: string; text?: string })[];
  return (
    <>
      <PageHeader breadcrumb={[{ label: "Modèles de documents", href: "/admin/modeles" }, { label: t.title }]} title={t.title} description={t.description ?? undefined} />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Modèle" />
            <KeyValue
              className="px-5 py-4"
              items={[
                { k: "Code", v: <span className="num">{t.code}</span> },
                { k: "Catégorie", v: t.category },
                { k: "Version", v: <span className="num">{t.version}</span> },
                { k: "Portée", v: t.companyId ? "Entreprise" : "Plateforme" },
                { k: "Vérification", v: t.verifiedAt ? `${fmtDateTime(t.verifiedAt)}${t.verifiedNote ? `, ${t.verifiedNote}` : ""}` : <Badge tone="warn">Non vérifié</Badge> },
              ]}
            />
          </Panel>
          <Panel>
            <PanelHeader title="Questions posées avant génération" />
            {questions.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Question</Th>
                    <Th>Type</Th>
                  </tr>
                </thead>
                <tbody>
                  {questions.map((q, i) => (
                    <tr key={q.key ?? i}>
                      <Td>
                        {q.label}
                        {q.required ? <span className="text-danger"> *</span> : null}
                        {q.help ? <p className="text-[12px] text-ink-3">{q.help}</p> : null}
                      </Td>
                      <Td className="num text-[12px] text-ink-2">{q.type}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune question.</p>
            )}
          </Panel>
          {points.length ? (
            <Panel>
              <PanelHeader title="Points à faire valider" description="Clauses nécessitant l'avis d'une personne compétente." />
              <Table>
                <tbody>
                  {points.map((p, i) => (
                    <tr key={i}>
                      <Td>{typeof p === "string" ? p : (p.label ?? p.text)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Panel>
          ) : null}
        </div>
        <Panel>
          <PanelHeader title="Corps du modèle" description="Markdown avec variables entre doubles accolades." />
          <pre className="max-h-[75dvh] overflow-auto whitespace-pre-wrap px-5 py-4 text-[13px] leading-relaxed text-ink">{t.body}</pre>
        </Panel>
      </div>
    </>
  );
}
