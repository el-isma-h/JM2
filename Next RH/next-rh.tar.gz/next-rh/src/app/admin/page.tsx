import Link from "next/link";
import { desc, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { integrationLabels, integrations, type IntegrationName } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PageHeader, Panel, PanelHeader, Stat, EmptyState } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";

export const dynamic = "force-dynamic";

const count = sql<number>`count(*)::int`;

export default async function AdminOverview() {
  await guardAdmin("/admin");
  const [
    [tenants],
    [companies],
    [users],
    [employees],
    periods,
    [mailFailed],
    [mailSkipped],
    [jobsFailed],
    [jobsQueued],
    recentFailedJobs,
    recentFailedMails,
  ] = await Promise.all([
    db.select({ all: count, demo: sql<number>`count(*) filter (where ${schema.tenants.isDemo})::int`, firms: sql<number>`count(*) filter (where ${schema.tenants.kind} <> 'company' and not ${schema.tenants.isDemo})::int` }).from(schema.tenants),
    db.select({ all: count, real: sql<number>`count(*) filter (where not ${schema.companies.isDemo})::int`, onboarded: sql<number>`count(*) filter (where ${schema.companies.onboardingCompletedAt} is not null and not ${schema.companies.isDemo})::int` }).from(schema.companies),
    db.select({ all: count, disabled: sql<number>`count(*) filter (where ${schema.users.disabledAt} is not null)::int`, admins: sql<number>`count(*) filter (where ${schema.users.platformRole} = 'platform_admin')::int`, unverified: sql<number>`count(*) filter (where ${schema.users.emailVerifiedAt} is null)::int` }).from(schema.users),
    db.select({ all: count, active: sql<number>`count(*) filter (where ${schema.employees.status} = 'active' and not ${schema.employees.isDemo})::int` }).from(schema.employees),
    db
      .select({ status: schema.payrollPeriods.status, n: count })
      .from(schema.payrollPeriods)
      .innerJoin(schema.companies, eq(schema.companies.id, schema.payrollPeriods.companyId))
      .where(eq(schema.companies.isDemo, false))
      .groupBy(schema.payrollPeriods.status),
    db.select({ n: count }).from(schema.mailOutbox).where(eq(schema.mailOutbox.status, "failed")),
    db.select({ n: count }).from(schema.mailOutbox).where(sql`${schema.mailOutbox.status} = 'skipped_not_configured' and not ${schema.mailOutbox.isDemo}`),
    db.select({ n: count }).from(schema.jobs).where(eq(schema.jobs.status, "failed")),
    db.select({ n: count }).from(schema.jobs).where(eq(schema.jobs.status, "queued")),
    db.select().from(schema.jobs).where(eq(schema.jobs.status, "failed")).orderBy(desc(schema.jobs.createdAt)).limit(5),
    db.select({ id: schema.mailOutbox.id, to: schema.mailOutbox.to, subject: schema.mailOutbox.subject, error: schema.mailOutbox.error, createdAt: schema.mailOutbox.createdAt }).from(schema.mailOutbox).where(eq(schema.mailOutbox.status, "failed")).orderBy(desc(schema.mailOutbox.createdAt)).limit(5),
  ]);

  const statusOrder = schema.payrollPeriodStatusEnum.enumValues;
  const periodRows = statusOrder.map((s) => ({ status: s, n: periods.find((p) => p.status === s)?.n ?? 0 })).filter((r) => r.n > 0);
  const integrationNames = Object.keys(integrations) as IntegrationName[];
  const cronConfigured = Boolean(process.env.CRON_SECRET && process.env.CRON_SECRET.length >= 16);

  return (
    <FadeIn>
      <PageHeader title="Vue d'ensemble" description="État de la plateforme : organisations, comptes, paie, envois et tâches. Les organisations de démonstration sont comptées à part." />

      <Panel className="mb-6">
        <div className="grid grid-cols-2 gap-x-6 gap-y-5 px-5 py-5 md:grid-cols-4">
          <Stat label="Organisations" value={tenants.all - tenants.demo} hint={`${tenants.firms} cabinet(s) ou groupe(s), ${tenants.demo} démo(s) active(s)`} />
          <Stat label="Entreprises" value={companies.real} hint={`${companies.onboarded} avec onboarding terminé`} />
          <Stat label="Utilisateurs" value={users.all} hint={`${users.admins} admin(s), ${users.disabled} désactivé(s), ${users.unverified} non vérifié(s)`} />
          <Stat label="Salariés actifs" value={employees.active} hint="hors démonstration" />
        </div>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel>
          <PanelHeader title="Périodes de paie par statut" description="Entreprises réelles uniquement." />
          {periodRows.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Statut</Th>
                  <Th num>Périodes</Th>
                </tr>
              </thead>
              <tbody>
                {periodRows.map((r) => (
                  <tr key={r.status}>
                    <Td>
                      <StatusBadge status={r.status} />
                    </Td>
                    <Td num>{r.n}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune période de paie" description="Les périodes apparaissent quand une entreprise ouvre sa première paie." />
          )}
        </Panel>

        <Panel>
          <PanelHeader
            title="Envois et tâches"
            actions={
              <Button asChild variant="secondary" size="sm">
                <Link href="/admin/taches">Voir les tâches</Link>
              </Button>
            }
          />
          <div className="grid grid-cols-2 gap-x-6 gap-y-5 px-5 py-5">
            <Stat label="E-mails en échec" value={<Link href="/admin/boite-envoi?status=failed" className={mailFailed.n ? "text-danger-ink hover:underline" : "hover:underline"}>{mailFailed.n}</Link>} />
            <Stat label="E-mails non envoyés" value={<Link href="/admin/boite-envoi?status=skipped_not_configured" className="hover:underline">{mailSkipped.n}</Link>} hint={integrations.mail() ? undefined : "service e-mail non configuré"} />
            <Stat label="Tâches en échec" value={<Link href="/admin/taches?status=failed" className={jobsFailed.n ? "text-danger-ink hover:underline" : "hover:underline"}>{jobsFailed.n}</Link>} />
            <Stat label="Tâches en file" value={jobsQueued.n} hint={cronConfigured ? "déclencheur /api/cron configuré" : "CRON_SECRET absent : déclencheur désactivé"} />
          </div>
          {recentFailedJobs.length || recentFailedMails.length ? (
            <Table className="border-t border-line">
              <tbody>
                {recentFailedJobs.map((j) => (
                  <tr key={j.id}>
                    <Td className="w-[140px]">
                      <Badge tone="danger">Tâche</Badge>
                    </Td>
                    <Td>
                      <span className="num text-[12.5px]">{j.kind}</span>
                      <p className="line-clamp-1 text-[12.5px] text-ink-3">{j.error}</p>
                    </Td>
                    <Td className="whitespace-nowrap text-ink-3">{fmtDateTime(j.createdAt)}</Td>
                  </tr>
                ))}
                {recentFailedMails.map((m) => (
                  <tr key={m.id}>
                    <Td className="w-[140px]">
                      <Badge tone="danger">E-mail</Badge>
                    </Td>
                    <Td>
                      <Link href={`/admin/boite-envoi/${m.id}`} className="hover:underline">
                        {m.subject}
                      </Link>
                      <p className="line-clamp-1 text-[12.5px] text-ink-3">
                        {m.to} : {m.error}
                      </p>
                    </Td>
                    <Td className="whitespace-nowrap text-ink-3">{fmtDateTime(m.createdAt)}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : null}
        </Panel>
      </div>

      <Panel className="mt-6">
        <PanelHeader
          title="Intégrations"
          description="Services externes : sans configuration, l'application fonctionne en mode dégradé explicite."
          actions={
            <Button asChild variant="secondary" size="sm">
              <Link href="/admin/integrations">Détail</Link>
            </Button>
          }
        />
        <Table>
          <tbody>
            {integrationNames.map((k) => (
              <tr key={k}>
                <Td className="font-medium">{integrationLabels[k].label}</Td>
                <Td className="w-[160px]">{integrations[k]() ? <Badge tone="ok">Configuré</Badge> : <Badge tone="warn">Non configuré</Badge>}</Td>
                <Td className="text-ink-2">{integrations[k]() ? "Actif." : integrationLabels[k].effect}</Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Panel>
    </FadeIn>
  );
}
