import Link from "next/link";
import { desc } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { fmtDate, fmtDateTime, isoToday } from "@/lib/dates";
import { countLeaves } from "@/components/admin/utils";
import { Badge } from "@/components/ui/badge";
import { EmptyState, PageHeader, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";

export const dynamic = "force-dynamic";

export default async function RuleSetsPage() {
  await guardAdmin("/admin/regles-paie");
  const sets = await db.select().from(schema.payrollRuleSets).orderBy(desc(schema.payrollRuleSets.effectiveFrom));
  const today = isoToday();
  return (
    <>
      <PageHeader
        title="Règles de paie"
        description="Paramètres légaux datés et versionnés (SMIC, plafond de la sécurité sociale, taux de cotisations, barème du prélèvement à la source). Consultation seule : les jeux de règles sont publiés par le moteur de paie."
      />
      <Panel>
        {sets.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Version</Th>
                <Th>Effet</Th>
                <Th num>Paramètres</Th>
                <Th num>Sources</Th>
                <Th>Empreinte</Th>
                <Th>Publication</Th>
              </tr>
            </thead>
            <tbody>
              {sets.map((s) => {
                const current = s.effectiveFrom <= today && (!s.effectiveTo || s.effectiveTo >= today);
                const sources = Array.isArray(s.sources) ? s.sources.length : 0;
                return (
                  <tr key={s.id}>
                    <Td>
                      <Link href={`/admin/regles-paie/${s.id}`} className="num font-medium hover:underline">
                        {s.version}
                      </Link>
                      {current ? (
                        <Badge tone="ok" className="ml-2">
                          En vigueur
                        </Badge>
                      ) : null}
                    </Td>
                    <Td className="whitespace-nowrap">
                      du {fmtDate(s.effectiveFrom)}
                      {s.effectiveTo ? ` au ${fmtDate(s.effectiveTo)}` : ", sans date de fin"}
                    </Td>
                    <Td num>{countLeaves(s.rules)}</Td>
                    <Td num>{sources}</Td>
                    <Td className="num text-[12px] text-ink-2" title={s.checksum}>
                      {s.checksum.slice(0, 16)}…
                    </Td>
                    <Td className="whitespace-nowrap text-ink-2">{fmtDateTime(s.publishedAt)}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucun jeu de règles publié" description="Les règles sont chargées par l'initialisation (npm run setup) quand le module de paie fournit sa fonction de chargement." />
        )}
      </Panel>
    </>
  );
}
