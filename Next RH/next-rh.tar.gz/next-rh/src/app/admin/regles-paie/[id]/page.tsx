import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { KeyValue, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td } from "@/components/ui/table";
import { countLeaves } from "@/components/admin/utils";

export const dynamic = "force-dynamic";

type Source = { label?: string; title?: string; url?: string; checkedAt?: string; date?: string } | string;

export default async function RuleSetDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) notFound();
  await guardAdmin(`/admin/regles-paie/${id}`);
  const [s] = await db.select().from(schema.payrollRuleSets).where(eq(schema.payrollRuleSets.id, id)).limit(1);
  if (!s) notFound();
  const sources = (Array.isArray(s.sources) ? s.sources : []) as Source[];
  return (
    <>
      <PageHeader breadcrumb={[{ label: "Règles de paie", href: "/admin/regles-paie" }, { label: s.version }]} title={`Jeu de règles ${s.version}`} description="Consultation seule. Toute modification passe par une nouvelle version publiée par le moteur de paie." />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Version" />
            <KeyValue
              className="px-5 py-4"
              items={[
                { k: "Effet", v: `du ${fmtDate(s.effectiveFrom)}${s.effectiveTo ? ` au ${fmtDate(s.effectiveTo)}` : ""}` },
                { k: "Paramètres", v: <span className="num">{countLeaves(s.rules)}</span> },
                { k: "Publication", v: fmtDateTime(s.publishedAt) },
                { k: "Empreinte", v: <span className="num break-all text-[12px]">{s.checksum}</span> },
              ]}
            />
          </Panel>
          <Panel>
            <PanelHeader title="Sources" description="Textes et barèmes officiels dont sont issues les valeurs." />
            {sources.length ? (
              <Table>
                <tbody>
                  {sources.map((src, i) => {
                    const o = typeof src === "string" ? { label: src } : src;
                    return (
                      <tr key={i}>
                        <Td>
                          {o.url ? (
                            <a href={o.url} target="_blank" rel="noopener noreferrer" className="hover:underline">
                              {o.label ?? o.title ?? o.url}
                            </a>
                          ) : (
                            (o.label ?? o.title)
                          )}
                          {o.checkedAt || o.date ? <p className="text-[12px] text-ink-3">Consultée le {o.checkedAt ?? o.date}</p> : null}
                        </Td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            ) : (
              <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune source déclarée.</p>
            )}
          </Panel>
        </div>
        <Panel>
          <PanelHeader title="Paramètres" description="Contenu brut du jeu de règles." />
          <pre className="num max-h-[70dvh] overflow-auto px-5 py-4 text-[12px] leading-relaxed text-ink-2">{JSON.stringify(s.rules, null, 2)}</pre>
        </Panel>
      </div>
    </>
  );
}
