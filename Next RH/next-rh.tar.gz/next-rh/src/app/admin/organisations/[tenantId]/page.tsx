import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq, inArray, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { archiveTenantAction, createCompanyAdminAction, deleteTenantAction, unarchiveTenantAction } from "@/server/actions/admin";
import { backupTenantAction } from "@/server/actions/backup";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { EmptyState, KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { FormDialog } from "@/components/admin/form-dialog";

export const dynamic = "force-dynamic";

const kindLabel: Record<string, string> = { company: "Entreprise seule", firm: "Cabinet", group: "Groupe" };
const roleLabel: Record<string, string> = { owner: "Propriétaire", admin: "Administrateur", hr: "RH", payroll: "Paie", manager: "Manager", accountant: "Comptable", employee: "Salarié", viewer: "Lecture seule" };

export default async function TenantDetail({ params }: { params: Promise<{ tenantId: string }> }) {
  const { tenantId } = await params;
  if (!/^[0-9a-f-]{36}$/.test(tenantId)) notFound();
  await guardAdmin(`/admin/organisations/${tenantId}`);
  const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, tenantId)).limit(1);
  if (!tenant) notFound();
  const archive = (tenant.settings as { archive?: { archivedAt: string; disabledUserIds: string[] } }).archive;
  const restoredFrom = (tenant.settings as { restoredFrom?: { backupId: string; at: string } }).restoredFrom;

  const companies = await db
    .select({
      c: schema.companies,
      employees: sql<number>`(select count(*)::int from ${schema.employees} e where e.company_id = "companies"."id" and e.status = 'active')`,
      period: sql<string | null>`(select p.status::text from ${schema.payrollPeriods} p where p.company_id = ${schema.companies.id} order by p.year desc, p.month desc limit 1)`,
    })
    .from(schema.companies)
    .where(eq(schema.companies.tenantId, tenantId))
    .orderBy(schema.companies.legalName);
  const companyIds = companies.map((r) => r.c.id);

  const [members, invitations, backups] = await Promise.all([
    db
      .select({ u: schema.users, role: schema.companyMemberships.role, companyId: schema.companyMemberships.companyId })
      .from(schema.users)
      .leftJoin(schema.companyMemberships, and(eq(schema.companyMemberships.userId, schema.users.id), companyIds.length ? inArray(schema.companyMemberships.companyId, companyIds) : sql`false`))
      .where(or(eq(schema.users.tenantId, tenantId), companyIds.length ? inArray(schema.companyMemberships.companyId, companyIds) : sql`false`)),
    db.select().from(schema.invitations).where(and(eq(schema.invitations.tenantId, tenantId), eq(schema.invitations.status, "pending"))).orderBy(desc(schema.invitations.createdAt)),
    db.select().from(schema.backups).where(eq(schema.backups.tenantId, tenantId)).orderBy(desc(schema.backups.createdAt)).limit(5),
  ]);

  const byUser = new Map<string, { u: (typeof members)[number]["u"]; roles: string[] }>();
  for (const m of members) {
    const e = byUser.get(m.u.id) ?? { u: m.u, roles: [] };
    if (m.role && m.companyId) {
      const c = companies.find((x) => x.c.id === m.companyId)?.c;
      e.roles.push(`${roleLabel[m.role] ?? m.role}${companies.length > 1 && c ? ` (${c.tradeName ?? c.legalName})` : ""}`);
    }
    byUser.set(m.u.id, e);
  }
  const canDelete = tenant.isDemo || Boolean(archive);

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Organisations", href: "/admin/organisations" }, { label: tenant.name }]}
        title={
          <span className="flex flex-wrap items-center gap-2">
            {tenant.name}
            {tenant.isDemo ? <Badge tone="warn">Démo</Badge> : null}
            {archive ? <Badge tone="neutral">Archivée</Badge> : null}
          </span>
        }
        description={`${kindLabel[tenant.kind]}, créée le ${fmtDate(tenant.createdAt)}.`}
        actions={
          <>
            <ActionButton action={backupTenantAction} fields={{ tenantId }} label="Sauvegarder maintenant" />
            {archive ? (
              <ActionButton action={unarchiveTenantAction} fields={{ tenantId }} label="Réactiver" confirm={{ title: "Réactiver l'organisation", description: `Les ${archive.disabledUserIds.length} compte(s) désactivés à l'archivage seront réactivés.`, confirmLabel: "Réactiver" }} />
            ) : !tenant.isDemo ? (
              <ActionButton
                action={archiveTenantAction}
                fields={{ tenantId }}
                label="Archiver"
                confirm={{
                  title: "Archiver l'organisation",
                  description: "Opération réversible : les comptes rattachés à cette organisation sont désactivés et leurs sessions fermées. Aucune donnée n'est supprimée.",
                  phrase: tenant.slug,
                  confirmLabel: "Archiver",
                  danger: true,
                }}
              />
            ) : null}
          </>
        }
      />

      {archive ? (
        <Notice tone="warn" className="mb-6" title="Organisation archivée">
          Depuis le {fmtDateTime(archive.archivedAt)}. Les comptes rattachés ne peuvent plus se connecter. Les données sont conservées.
        </Notice>
      ) : null}
      {restoredFrom ? (
        <Notice tone="info" className="mb-6" title="Organisation restaurée">
          Copie créée le {fmtDateTime(restoredFrom.at)} à partir d&apos;une sauvegarde. Identifiants remappés ; l&apos;organisation d&apos;origine n&apos;a pas été modifiée.
        </Notice>
      ) : null}

      <Panel className="mb-6">
        <PanelHeader
          title="Entreprises"
          description="Accès direct à l'espace de chaque entreprise (en tant qu'administrateur plateforme, chaque ouverture est journalisée par les modules)."
          actions={
            <FormDialog action={createCompanyAdminAction} trigger="Ajouter une entreprise" triggerVariant="secondary" triggerSize="sm" title="Ajouter une entreprise" submitLabel="Ajouter">
              <input type="hidden" name="tenantId" value={tenantId} />
              <Field label="Raison sociale" required htmlFor="c-legal">
                <Input id="c-legal" name="legalName" required />
              </Field>
              <Field label="Nom commercial" htmlFor="c-trade">
                <Input id="c-trade" name="tradeName" />
              </Field>
              <Field label="SIREN" htmlFor="c-siren" help="9 chiffres, contrôlé par la clé de Luhn. Facultatif.">
                <Input id="c-siren" name="siren" inputMode="numeric" />
              </Field>
            </FormDialog>
          }
        />
        {companies.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Entreprise</Th>
                <Th>SIREN</Th>
                <Th>Onboarding</Th>
                <Th>Dernière paie</Th>
                <Th num>Salariés actifs</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {companies.map(({ c, employees, period }) => (
                <tr key={c.id}>
                  <Td>
                    <span className="font-medium">{c.tradeName ?? c.legalName}</span>
                    {c.tradeName ? <p className="text-[12px] text-ink-3">{c.legalName}</p> : null}
                  </Td>
                  <Td className="num">{c.siren ?? "-"}</Td>
                  <Td>{c.onboardingCompletedAt ? <Badge tone="ok">Terminé</Badge> : <Badge tone="warn">En cours</Badge>}</Td>
                  <Td>{period ? <StatusBadge status={period} /> : <span className="text-ink-3">Aucune</span>}</Td>
                  <Td num>{employees}</Td>
                  <Td className="text-right">
                    <Button asChild variant="secondary" size="sm">
                      <Link href={`/app/${c.id}`}>Ouvrir l&apos;espace</Link>
                    </Button>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState title="Aucune entreprise" description="Ajoutez la première entreprise de cette organisation." />
        )}
      </Panel>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
        <Panel>
          <PanelHeader title="Comptes" description="Comptes rattachés à l'organisation et personnes affectées à ses entreprises." />
          {byUser.size ? (
            <Table>
              <thead>
                <tr>
                  <Th>Personne</Th>
                  <Th>Rôles</Th>
                  <Th>Dernière connexion</Th>
                </tr>
              </thead>
              <tbody>
                {[...byUser.values()].map(({ u, roles }) => (
                  <tr key={u.id}>
                    <Td>
                      <Link href={`/admin/utilisateurs/${u.id}`} className="font-medium hover:underline">
                        {u.firstName} {u.lastName}
                      </Link>
                      <p className="text-[12px] text-ink-3">{u.email}</p>
                    </Td>
                    <Td className="text-ink-2">
                      {roles.join(", ") || "Aucune affectation"}
                      {u.disabledAt ? (
                        <Badge tone="danger" className="ml-2">
                          Désactivé
                        </Badge>
                      ) : null}
                    </Td>
                    <Td className="whitespace-nowrap text-ink-2">{u.lastLoginAt ? fmtDateTime(u.lastLoginAt) : "Jamais"}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucun compte" description="Invitez un propriétaire lors de la création ou depuis l'espace de l'entreprise." />
          )}
        </Panel>

        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Invitations en attente" />
            {invitations.length ? (
              <Table>
                <tbody>
                  {invitations.map((i) => (
                    <tr key={i.id}>
                      <Td>
                        {i.email}
                        <p className="text-[12px] text-ink-3">
                          {roleLabel[i.role] ?? i.role}, expire le {fmtDate(i.expiresAt)}
                        </p>
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune invitation en attente.</p>
            )}
          </Panel>
          <Panel>
            <PanelHeader
              title="Sauvegardes récentes"
              actions={
                <Button asChild variant="ghost" size="sm">
                  <Link href="/admin/sauvegardes">Toutes</Link>
                </Button>
              }
            />
            {backups.length ? (
              <Table>
                <tbody>
                  {backups.map((b) => (
                    <tr key={b.id}>
                      <Td className="whitespace-nowrap">{fmtDateTime(b.createdAt)}</Td>
                      <Td num>{(b.sizeBytes / 1024).toFixed(1)} Ko</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune sauvegarde pour cette organisation.</p>
            )}
          </Panel>
          <Panel>
            <PanelHeader title="Informations" />
            <KeyValue className="px-5 py-4" items={[{ k: "Identifiant", v: <span className="num text-[12.5px]">{tenant.id}</span> }, { k: "Slug", v: <span className="num">{tenant.slug}</span> }, { k: "Mise à jour", v: fmtDateTime(tenant.updatedAt) }]} />
          </Panel>
        </div>
      </div>

      <Panel className="mt-6">
        <PanelHeader title="Suppression définitive" description={canDelete ? "Supprime toutes les données, les fichiers et les comptes rattachés sans autre accès. Une sauvegarde est créée juste avant (sauf démonstration)." : "Disponible uniquement après archivage : archivez d'abord l'organisation."} />
        <div className="px-5 py-4">
          {canDelete ? (
            <ActionButton
              action={deleteTenantAction}
              fields={{ tenantId }}
              label="Supprimer définitivement"
              variant="danger"
              confirm={{
                title: "Supprimer définitivement l'organisation",
                description: "Cette opération est irréversible. Le journal d'audit est conservé.",
                phrase: tenant.slug,
                confirmLabel: "Supprimer définitivement",
                danger: true,
                checkbox: { name: "understood", label: "Je comprends que les données de cette organisation seront supprimées." },
              }}
            />
          ) : (
            <Button variant="secondary" size="sm" disabled>
              Supprimer définitivement
            </Button>
          )}
        </div>
      </Panel>
    </>
  );
}
