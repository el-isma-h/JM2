import { asc } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { deletePricingPlanAction, reseedPricingAction, savePricingPlanAction, togglePricingActiveAction } from "@/server/actions/admin";
import { checkPrice, proposePrice, pricingUnitLabels } from "@/server/pricing/compute";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";
import { PricingDialog } from "@/components/admin/pricing-dialog";

export const dynamic = "force-dynamic";

export default async function PricingAdmin() {
  await guardAdmin("/admin/tarifs");
  const plans = await db.select().from(schema.pricingPlans).orderBy(asc(schema.pricingPlans.sortOrder), asc(schema.pricingPlans.name));
  const checks = plans.map((p) => ({ p, check: checkPrice(p), proposed: proposePrice(p.referencePriceCents, p.discountRate) }));
  const flagged = checks.filter((c) => c.check.level === "danger");
  const groups: { title: string; description: string; rows: typeof checks }[] = [
    { title: "Fonctions du logiciel", description: "Prix par module, calculés depuis la référence publique.", rows: checks.filter((c) => !c.p.isService && c.p.unit !== "inclus") },
    { title: "Inclus sans surcoût", description: "Fonctions incluses sans surcoût chez la référence, donc chez Next RH.", rows: checks.filter((c) => !c.p.isService && c.p.unit === "inclus") },
    { title: "Services d'accompagnement", description: "Prestations humaines, séparées des fonctions incluses.", rows: checks.filter((c) => c.p.isService) },
  ];

  return (
    <>
      <PageHeader
        title="Tarifs"
        description="Grille affichée sur la page publique. Règle : prix Next RH = référence × (1 - remise), tronqué au centime inférieur. Chaque ligne garde sa source et sa date de consultation."
        actions={
          <>
            <ActionButton action={reseedPricingAction} fields={{ overwrite: "0" }} label="Compléter depuis la grille sourcée" />
            <ActionButton
              action={reseedPricingAction}
              fields={{ overwrite: "1" }}
              label="Réaligner sur la grille sourcée"
              confirm={{ title: "Réaligner toutes les lignes", description: "Les lignes de la grille sourcée (replica/pricing.md) écrasent vos modifications sur ces codes. Les lignes ajoutées à la main sont conservées.", phrase: "REALIGNER", danger: true, confirmLabel: "Réaligner" }}
            />
            <PricingDialog action={savePricingPlanAction} trigger="Nouvelle ligne" triggerVariant="primary" />
          </>
        }
      />

      {flagged.length ? (
        <Notice tone="danger" className="mb-6" title={`${flagged.length} ligne(s) au-dessus du plafond`}>
          {flagged.map((f) => `${f.p.name} : ${f.check.message}`).join(" ")}
        </Notice>
      ) : plans.length ? (
        <Notice tone="ok" className="mb-6">
          Contrôle : aucune ligne ne dépasse 90 % de son prix de référence.
        </Notice>
      ) : null}

      {!plans.length ? (
        <Panel>
          <EmptyState title="Aucun tarif" description="Chargez la grille sourcée pour commencer." action={<ActionButton action={reseedPricingAction} fields={{ overwrite: "0" }} label="Charger la grille sourcée" variant="primary" size="md" />} />
        </Panel>
      ) : (
        <div className="space-y-6">
          {groups.map((g) =>
            g.rows.length ? (
              <Panel key={g.title}>
                <PanelHeader title={g.title} description={g.description} />
                <Table>
                  <thead>
                    <tr>
                      <Th>Ligne</Th>
                      <Th>Unité</Th>
                      <Th num>Référence</Th>
                      <Th num>Remise</Th>
                      <Th num>Proposé</Th>
                      <Th num>Prix Next RH</Th>
                      <Th>Contrôle</Th>
                      <Th>Calcul et source</Th>
                      <Th />
                    </tr>
                  </thead>
                  <tbody>
                    {g.rows.map(({ p, check, proposed }) => (
                      <tr key={p.id} className={p.isActive ? undefined : "opacity-60"}>
                        <Td>
                          <span className="font-medium">{p.name}</span>
                          <p className="num text-[12px] text-ink-3">
                            {p.code}, ordre {p.sortOrder}
                          </p>
                          {!p.isActive ? (
                            <Badge tone="neutral" className="mt-1">
                              Non publié
                            </Badge>
                          ) : null}
                        </Td>
                        <Td className="text-ink-2">{pricingUnitLabels[p.unit] ?? p.unit}</Td>
                        <Td num>{p.unit === "sur_devis" ? "-" : formatCents(p.referencePriceCents)}</Td>
                        <Td num>{p.unit === "sur_devis" || p.unit === "inclus" ? "-" : `${(p.discountRate / 100).toLocaleString("fr-FR")} %`}</Td>
                        <Td num>{p.unit === "sur_devis" || p.unit === "inclus" ? "-" : formatCents(proposed)}</Td>
                        <Td num className="font-medium">
                          {p.unit === "sur_devis" ? "Sur devis" : p.unit === "inclus" ? "Inclus" : formatCents(p.priceCents)}
                        </Td>
                        <Td>
                          <Badge tone={check.level === "ok" ? "ok" : check.level === "danger" ? "danger" : "info"} title={check.message}>
                            {check.level === "ok" ? "Conforme" : check.level === "danger" ? "Au-dessus du plafond" : "À vérifier"}
                          </Badge>
                        </Td>
                        <Td className="max-w-[340px] text-[12.5px] text-ink-2">
                          <p>{p.calculationNote ?? "-"}</p>
                          <p className="mt-1 text-ink-3">
                            {p.referenceLabel ? `${p.referenceLabel}. ` : ""}
                            {p.referenceUrl ? (
                              <a href={p.referenceUrl} target="_blank" rel="noopener noreferrer" className="underline-offset-2 hover:underline">
                                {p.referenceUrl.replace(/^https?:\/\//, "")}
                              </a>
                            ) : (
                              "Source non renseignée"
                            )}
                            {p.referenceCheckedAt ? `, consultée le ${fmtDate(p.referenceCheckedAt)}` : ""}
                          </p>
                        </Td>
                        <Td>
                          <div className="flex flex-col items-end gap-1">
                            <PricingDialog
                              action={savePricingPlanAction}
                              trigger="Modifier"
                              triggerVariant="ghost"
                              plan={{
                                id: p.id,
                                code: p.code,
                                name: p.name,
                                description: p.description ?? "",
                                isService: p.isService,
                                unit: p.unit,
                                priceCents: p.priceCents,
                                referencePriceCents: p.referencePriceCents,
                                referenceLabel: p.referenceLabel ?? "",
                                referenceUrl: p.referenceUrl ?? "",
                                referenceCheckedAt: p.referenceCheckedAt ?? "",
                                discountRate: p.discountRate,
                                calculationNote: p.calculationNote ?? "",
                                isActive: p.isActive,
                                sortOrder: p.sortOrder,
                              }}
                            />
                            <ActionButton action={togglePricingActiveAction} fields={{ id: p.id }} label={p.isActive ? "Masquer" : "Publier"} variant="ghost" />
                            <ActionButton
                              action={deletePricingPlanAction}
                              fields={{ id: p.id }}
                              label="Supprimer"
                              variant="ghost"
                              confirm={{ title: `Supprimer « ${p.name} »`, description: "La ligne disparaît de la page tarifs. Préférez « Masquer » pour la retirer temporairement.", phrase: p.code, danger: true, confirmLabel: "Supprimer" }}
                            />
                          </div>
                        </Td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Panel>
            ) : null,
          )}
        </div>
      )}
    </>
  );
}
