import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq, gt, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { forceVerifyEmailAction, revokeSessionsAction, sendPasswordResetAction, setPlatformRoleAction, setUserDisabledAction } from "@/server/actions/admin";
import { fmtDateTime } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState, KeyValue, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton } from "@/components/admin/action-form";

export const dynamic = "force-dynamic";

const roleLabel: Record<string, string> = { owner: "Propriétaire", admin: "Administrateur", hr: "RH", payroll: "Paie", manager: "Manager", accountant: "Comptable", employee: "Salarié", viewer: "Lecture seule" };

export default async function UserDetail({ params }: { params: Promise<{ userId: string }> }) {
  const { userId } = await params;
  if (!/^[0-9a-f-]{36}$/.test(userId)) notFound();
  const admin = await guardAdmin(`/admin/utilisateurs/${userId}`);
  const [row] = await db
    .select({ u: schema.users, tenant: schema.tenants })
    .from(schema.users)
    .leftJoin(schema.tenants, eq(schema.tenants.id, schema.users.tenantId))
    .where(eq(schema.users.id, userId))
    .limit(1);
  if (!row) notFound();
  const { u, tenant } = row;

  const [memberships, [{ sessions }], employeeLinks, recent] = await Promise.all([
    db
      .select({ m: schema.companyMemberships, c: schema.companies })
      .from(schema.companyMemberships)
      .innerJoin(schema.companies, eq(schema.companies.id, schema.companyMemberships.companyId))
      .where(eq(schema.companyMemberships.userId, userId))
      .orderBy(schema.companies.legalName),
    db.select({ sessions: sql<number>`count(*)::int` }).from(schema.sessions).where(and(eq(schema.sessions.userId, userId), gt(schema.sessions.expiresAt, new Date()))),
    db.select({ e: schema.employees, c: schema.companies }).from(schema.employees).innerJoin(schema.companies, eq(schema.companies.id, schema.employees.companyId)).where(eq(schema.employees.userId, userId)),
    db.select().from(schema.auditLogs).where(eq(schema.auditLogs.userId, userId)).orderBy(desc(schema.auditLogs.createdAt)).limit(12),
  ]);
  const isSelf = admin.id === u.id;
  const isAdmin = u.platformRole === "platform_admin";

  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Utilisateurs", href: "/admin/utilisateurs" }, { label: `${u.firstName} ${u.lastName}` }]}
        title={
          <span className="flex flex-wrap items-center gap-2">
            {u.firstName} {u.lastName}
            {isAdmin ? <Badge tone="info">Admin plateforme</Badge> : null}
            {u.disabledAt ? <Badge tone="danger">Désactivé</Badge> : null}
          </span>
        }
        description={u.email}
      />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Compte" />
            <KeyValue
              className="px-5 py-4"
              items={[
                { k: "Organisation", v: tenant ? <Link href={`/admin/organisations/${tenant.id}`} className="hover:underline">{tenant.name}</Link> : "Aucune" },
                { k: "Adresse e-mail", v: u.emailVerifiedAt ? `Vérifiée le ${fmtDateTime(u.emailVerifiedAt)}` : <Badge tone="warn">Non vérifiée</Badge> },
                { k: "Double authentification", v: u.totpEnabledAt ? `Activée le ${fmtDateTime(u.totpEnabledAt)}` : "Non activée" },
                { k: "Codes de secours restants", v: <span className="num">{Array.isArray(u.recoveryCodesHash) ? u.recoveryCodesHash.length : 0}</span> },
                { k: "Dernière connexion", v: u.lastLoginAt ? fmtDateTime(u.lastLoginAt) : "Jamais" },
                { k: "Sessions actives", v: <span className="num">{sessions}</span> },
                { k: "Création", v: fmtDateTime(u.createdAt) },
              ]}
            />
          </Panel>

          <Panel>
            <PanelHeader title="Affectations" description="Entreprises auxquelles ce compte a accès, et son rôle dans chacune." />
            {memberships.length ? (
              <Table>
                <thead>
                  <tr>
                    <Th>Entreprise</Th>
                    <Th>Rôle</Th>
                    <Th>Depuis</Th>
                    <Th />
                  </tr>
                </thead>
                <tbody>
                  {memberships.map(({ m, c }) => (
                    <tr key={m.id}>
                      <Td>
                        {c.tradeName ?? c.legalName}
                        {c.isDemo ? (
                          <Badge tone="warn" className="ml-2">
                            Démo
                          </Badge>
                        ) : null}
                      </Td>
                      <Td>{roleLabel[m.role] ?? m.role}</Td>
                      <Td className="whitespace-nowrap text-ink-2">{fmtDateTime(m.createdAt)}</Td>
                      <Td className="text-right">
                        <Button asChild variant="ghost" size="sm">
                          <Link href={`/admin/organisations/${c.tenantId}`}>Organisation</Link>
                        </Button>
                      </Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <EmptyState title="Aucune affectation" description="Ce compte n'a accès à aucune entreprise." />
            )}
            {employeeLinks.length ? (
              <p className="border-t border-line px-5 py-3 text-[13px] text-ink-2">
                Fiche salarié liée : {employeeLinks.map(({ e, c }) => `${e.firstName} ${e.lastName} (${c.tradeName ?? c.legalName})`).join(", ")}
              </p>
            ) : null}
          </Panel>

          <Panel>
            <PanelHeader
              title="Activité récente"
              actions={
                <Button asChild variant="ghost" size="sm">
                  <Link href={`/admin/audit?user=${u.id}`}>Tout le journal</Link>
                </Button>
              }
            />
            {recent.length ? (
              <Table>
                <tbody>
                  {recent.map((a) => (
                    <tr key={a.id}>
                      <Td className="num text-[12.5px]">{a.action}</Td>
                      <Td className="whitespace-nowrap text-right text-ink-2">{fmtDateTime(a.createdAt)}</Td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            ) : (
              <p className="px-5 py-4 text-[13.5px] text-ink-2">Aucune action journalisée.</p>
            )}
          </Panel>
        </div>

        <Panel className="self-start">
          <PanelHeader title="Actions" description="Chaque action est journalisée." />
          <div className="divide-y divide-line">
            <div className="px-5 py-4">
              <p className="mb-2 text-[13px] text-ink-2">Envoie un lien de réinitialisation valable 30 minutes. Sans service e-mail, le lien s&apos;affiche ici.</p>
              <ActionButton action={sendPasswordResetAction} fields={{ userId }} label="Envoyer une réinitialisation" confirm={{ title: "Envoyer une réinitialisation", description: `Un lien de réinitialisation sera adressé à ${u.email}.`, confirmLabel: "Envoyer" }} />
            </div>
            {!u.emailVerifiedAt ? (
              <div className="px-5 py-4">
                <p className="mb-2 text-[13px] text-ink-2">À utiliser seulement après avoir vérifié l&apos;identité de la personne par un autre moyen.</p>
                <ActionButton action={forceVerifyEmailAction} fields={{ userId }} label="Marquer l'adresse comme vérifiée" confirm={{ title: "Forcer la vérification de l'adresse", description: `L'adresse ${u.email} sera considérée comme vérifiée sans clic sur le lien.`, confirmLabel: "Confirmer" }} />
              </div>
            ) : null}
            <div className="px-5 py-4">
              <p className="mb-2 text-[13px] text-ink-2">Ferme toutes les sessions ouvertes sur tous les appareils.</p>
              <ActionButton action={revokeSessionsAction} fields={{ userId }} label="Fermer les sessions" confirm={{ title: "Fermer toutes les sessions", description: "La personne devra se reconnecter.", confirmLabel: "Fermer les sessions" }} />
            </div>
            {!isSelf ? (
              <div className="px-5 py-4">
                {u.disabledAt ? (
                  <ActionButton action={setUserDisabledAction} fields={{ userId, disable: "0" }} label="Réactiver le compte" confirm={{ title: "Réactiver le compte", description: "La personne pourra de nouveau se connecter.", confirmLabel: "Réactiver" }} />
                ) : (
                  <>
                    <p className="mb-2 text-[13px] text-ink-2">Bloque la connexion et ferme les sessions. Réversible.</p>
                    <ActionButton action={setUserDisabledAction} fields={{ userId, disable: "1" }} label="Désactiver le compte" variant="danger" confirm={{ title: "Désactiver le compte", description: `${u.firstName} ${u.lastName} ne pourra plus se connecter. Ses données et affectations sont conservées.`, confirmLabel: "Désactiver", danger: true }} />
                  </>
                )}
              </div>
            ) : null}
            {!isSelf ? (
              <div className="px-5 py-4">
                <p className="mb-2 text-[13px] text-ink-2">
                  {isAdmin ? "Retire l'accès à toute la console d'administration." : "Donne accès à toutes les organisations et à cette console. À réserver à l'équipe d'exploitation."}
                </p>
                <ActionButton
                  action={setPlatformRoleAction}
                  fields={{ userId, role: isAdmin ? "user" : "platform_admin" }}
                  label={isAdmin ? "Retirer les droits d'administration" : "Promouvoir administrateur plateforme"}
                  variant={isAdmin ? "danger" : "secondary"}
                  confirm={{
                    title: isAdmin ? "Retirer les droits d'administration" : "Promouvoir administrateur plateforme",
                    description: "Opération sensible. Les sessions de la personne seront fermées pour appliquer le changement.",
                    phrase: u.email,
                    phraseLabel: "Pour confirmer, saisissez l'adresse e-mail du compte",
                    confirmLabel: isAdmin ? "Retirer les droits" : "Promouvoir",
                    danger: true,
                  }}
                />
              </div>
            ) : null}
          </div>
        </Panel>
      </div>
    </>
  );
}
