import { and, asc, desc, eq, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardAdmin } from "@/server/guard";
import { enqueueJobAction, retryJobAction, runJobsNowAction } from "@/server/actions/admin";
import { knownJobKinds } from "@/server/jobs/handlers";
import { MAX_ATTEMPTS, RECURRING_JOBS } from "@/server/jobs/runner";
import { fmtDateTime } from "@/lib/dates";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { EmptyState, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionButton, ActionForm } from "@/components/admin/action-form";
import { Pagination, readPage, readParam } from "@/components/admin/pagination";

export const dynamic = "force-dynamic";
const PAGE = 50;

const kindHelp: Record<string, string> = {
  "demo:cleanup": "Supprime les espaces de démonstration de plus de 24 heures (toutes les heures).",
  "backup:tenant": "Sauvegarde complète d'une organisation (lignes et fichiers).",
  "deadlines:remind": "Envoie aux gestionnaires le récapitulatif des échéances des 14 prochains jours (chaque jour).",
};

export default async function JobsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await guardAdmin("/admin/taches");
  const sp = await searchParams;
  const status = readParam(sp.status);
  const kind = readParam(sp.kind);
  const page = readPage(sp.page);
  const conds: SQL[] = [];
  if (status && (schema.jobStatusEnum.enumValues as readonly string[]).includes(status)) conds.push(eq(schema.jobs.status, status as "queued"));
  if (kind) conds.push(eq(schema.jobs.kind, kind));
  const where = conds.length ? and(...conds) : undefined;
  const [rows, [{ total }], tenants, kinds] = await Promise.all([
    db.select().from(schema.jobs).where(where).orderBy(desc(schema.jobs.createdAt)).limit(PAGE).offset((page - 1) * PAGE),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.jobs).where(where),
    db.select({ id: schema.tenants.id, name: schema.tenants.name }).from(schema.tenants).where(eq(schema.tenants.isDemo, false)).orderBy(asc(schema.tenants.name)),
    db.selectDistinct({ kind: schema.jobs.kind }).from(schema.jobs),
  ]);
  const cronConfigured = Boolean(process.env.CRON_SECRET && process.env.CRON_SECRET.length >= 16);
  const allKinds = [...new Set([...knownJobKinds(), ...kinds.map((k) => k.kind)])].sort();

  return (
    <>
      <PageHeader
        title="Tâches"
        description={`Tâches de fond exécutées par le runner : ${MAX_ATTEMPTS} tentatives au maximum, nouvel essai différé en cas d'erreur, aucune tâche prise deux fois.`}
        actions={<ActionButton action={runJobsNowAction} fields={{}} label="Exécuter les tâches dues" variant="primary" size="md" />}
      />
      {!cronConfigured ? (
        <Notice tone="warn" className="mb-6" title="Déclencheur automatique désactivé">
          CRON_SECRET n&apos;est pas défini : les tâches ne s&apos;exécutent que depuis ce bouton. En production, appelez POST /api/cron chaque minute avec l&apos;en-tête x-cron-secret.
        </Notice>
      ) : (
        <Notice tone="info" className="mb-6">
          Déclencheur configuré : un planificateur doit appeler POST /api/cron (en-tête x-cron-secret) chaque minute.
        </Notice>
      )}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,3fr)_minmax(0,1.3fr)]">
        <Panel>
          <form method="get" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
            <Field label="Statut" htmlFor="status" className="w-44">
              <Select id="status" name="status" defaultValue={status ?? ""}>
                <option value="">Tous</option>
                <option value="queued">En file</option>
                <option value="running">En cours</option>
                <option value="done">Terminées</option>
                <option value="failed">En échec</option>
              </Select>
            </Field>
            <Field label="Type" htmlFor="kind" className="w-52">
              <Select id="kind" name="kind" defaultValue={kind ?? ""}>
                <option value="">Tous</option>
                {allKinds.map((k) => (
                  <option key={k} value={k}>
                    {k}
                  </option>
                ))}
              </Select>
            </Field>
            <Button type="submit" variant="secondary">
              Filtrer
            </Button>
          </form>
          {rows.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Tâche</Th>
                  <Th>Statut</Th>
                  <Th num>Tentatives</Th>
                  <Th>Planifiée</Th>
                  <Th>Terminée</Th>
                  <Th />
                </tr>
              </thead>
              <tbody>
                {rows.map((j) => (
                  <tr key={j.id}>
                    <Td>
                      <span className="num text-[13px] font-medium">{j.kind}</span>
                      {j.error ? <p className="line-clamp-2 max-w-[44ch] text-[12px] text-danger-ink">{j.error}</p> : null}
                      {j.result && j.status === "done" ? <p className="num line-clamp-1 max-w-[44ch] text-[11.5px] text-ink-3">{JSON.stringify(j.result)}</p> : null}
                    </Td>
                    <Td>
                      <StatusBadge status={j.status} />
                    </Td>
                    <Td num>
                      {j.attempts}/{MAX_ATTEMPTS}
                    </Td>
                    <Td className="whitespace-nowrap text-ink-2">{fmtDateTime(j.runAfter)}</Td>
                    <Td className="whitespace-nowrap text-ink-2">{j.finishedAt ? fmtDateTime(j.finishedAt) : "-"}</Td>
                    <Td className="text-right">{j.status === "failed" ? <ActionButton action={retryJobAction} fields={{ id: j.id }} label="Relancer" /> : null}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune tâche" description="Les tâches récurrentes sont planifiées au premier passage du runner." />
          )}
          <Pagination basePath="/admin/taches" params={{ status, kind }} page={page} pageSize={PAGE} total={total} />
        </Panel>

        <Panel className="self-start">
          <PanelHeader title="Planifier une tâche" />
          <ActionForm action={enqueueJobAction} submitLabel="Ajouter à la file" className="px-5 py-4" footerClassName="mt-4">
            <div className="space-y-4">
              <Field label="Type" htmlFor="j-kind">
                <Select id="j-kind" name="kind" defaultValue="demo:cleanup">
                  {knownJobKinds().map((k) => (
                    <option key={k} value={k}>
                      {k}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Organisation" htmlFor="j-tenant" help="Requis pour une sauvegarde.">
                <Select id="j-tenant" name="tenantId" defaultValue="">
                  <option value="">Aucune</option>
                  {tenants.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
          </ActionForm>
          <Table className="border-t border-line">
            <tbody>
              {knownJobKinds().map((k) => (
                <tr key={k}>
                  <Td>
                    <span className="num text-[12.5px] font-medium">{k}</span>
                    <p className="text-[12.5px] text-ink-2">
                      {kindHelp[k] ?? "Type déclaré par un module."}
                      {RECURRING_JOBS[k] ? ` Récurrente : toutes les ${RECURRING_JOBS[k] >= 60 ? `${RECURRING_JOBS[k] / 60} h` : `${RECURRING_JOBS[k]} min`}.` : ""}
                    </p>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>
      </div>
    </>
  );
}
