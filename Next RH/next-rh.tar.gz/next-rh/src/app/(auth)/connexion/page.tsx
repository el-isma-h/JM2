import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth";
import { LoginForm } from "./login-form";

export const metadata: Metadata = { title: "Connexion" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; reset?: string }> }) {
  const sp = await searchParams;
  if (await getCurrentUser()) redirect(sp.next?.startsWith("/") ? sp.next : "/app");
  return (
    <div>
      <h1 className="text-[30px] text-ink">Connexion</h1>
      <p className="mt-3 text-[14px] text-ink-2">
        Pas encore de compte ?{" "}
        <Link href="/inscription" className="font-medium text-accent hover:underline">
          Créer mon compte
        </Link>
      </p>
      <LoginForm next={sp.next} resetDone={sp.reset === "1"} />
    </div>
  );
}
