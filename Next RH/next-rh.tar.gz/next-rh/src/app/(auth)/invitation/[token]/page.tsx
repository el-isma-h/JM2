import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { getCurrentUser, peekToken } from "@/server/auth";
import { Notice } from "@/components/ui/surface";
import { InvitationForm } from "./form";

export const metadata: Metadata = { title: "Invitation" };

export default async function InvitationPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const row = await peekToken("invite", token);
  const payload = row?.payload as { invitationId?: string } | undefined;
  const [inv] = payload?.invitationId
    ? await db.select().from(schema.invitations).where(eq(schema.invitations.id, payload.invitationId)).limit(1)
    : [];
  const user = await getCurrentUser();
  if (!row || !inv || inv.status !== "pending") {
    return (
      <div>
        <h1 className="text-[30px] text-ink">Invitation</h1>
        <Notice tone="danger" className="mt-6">
          Cette invitation est invalide, expirée ou déjà utilisée.
        </Notice>
      </div>
    );
  }
  const [company] = inv.companyId ? await db.select().from(schema.companies).where(eq(schema.companies.id, inv.companyId)).limit(1) : [];
  return (
    <div>
      <h1 className="text-[30px] text-ink">Vous êtes invité</h1>
      <p className="mt-3 text-[14px] text-ink-2">
        Rejoignez <span className="font-medium text-ink">{company?.legalName ?? "l'organisation"}</span> avec le rôle{" "}
        <span className="font-medium text-ink">{inv.role}</span>, pour l&apos;adresse {inv.email}.
      </p>
      <InvitationForm token={token} isLoggedIn={Boolean(user)} />
    </div>
  );
}
