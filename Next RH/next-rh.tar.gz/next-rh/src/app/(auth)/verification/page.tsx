import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth";
import { verifyEmailAction } from "@/server/actions/auth";
import { Notice } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import { ResendButton } from "./resend-button";

export const metadata: Metadata = { title: "Vérification de l'adresse" };

export default async function VerifyPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  if (token) {
    const res = await verifyEmailAction(token);
    if (res.ok) {
      const u = await getCurrentUser();
      redirect(u ? "/app" : "/connexion");
    }
    return (
      <div>
        <h1 className="text-[30px] text-ink">Lien invalide</h1>
        <Notice tone="danger" className="mt-6">
          {res.error}
        </Notice>
        <Button asChild variant="secondary" className="mt-4">
          <Link href="/connexion">Se connecter</Link>
        </Button>
      </div>
    );
  }
  const user = await getCurrentUser();
  if (!user) redirect("/connexion");
  if (user.emailVerified) redirect("/app");
  return (
    <div>
      <h1 className="text-[30px] text-ink">Vérifiez votre adresse</h1>
      <p className="mt-3 text-[14px] text-ink-2">
        Un e-mail a été envoyé à <span className="font-medium text-ink">{user.email}</span>. Cliquez sur le lien qu&apos;il contient pour activer votre espace.
      </p>
      <div className="mt-6 flex flex-wrap items-center gap-3">
        <ResendButton />
        <form action="/deconnexion" method="post">
          <Button type="submit" variant="ghost">
            Se déconnecter
          </Button>
        </form>
      </div>
    </div>
  );
}
