"use client";

import { useActionState } from "react";
import { signupAction, type ActionState } from "@/server/actions/auth";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";

export function SignupForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(signupAction, {});
  return (
    <form action={action} className="mt-6 space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Prénom" htmlFor="firstName" required>
          <Input id="firstName" name="firstName" autoComplete="given-name" required />
        </Field>
        <Field label="Nom" htmlFor="lastName" required>
          <Input id="lastName" name="lastName" autoComplete="family-name" required />
        </Field>
      </div>
      <Field label="Adresse e-mail professionnelle" htmlFor="email" required>
        <Input id="email" name="email" type="email" autoComplete="email" required />
      </Field>
      <Field label="Mot de passe" htmlFor="password" required help="12 caractères minimum, avec majuscule, minuscule et chiffre.">
        <Input id="password" name="password" type="password" autoComplete="new-password" required minLength={12} />
      </Field>
      <div className="grid grid-cols-[1fr_auto] gap-3">
        <Field label="Entreprise ou cabinet" htmlFor="orgName" required>
          <Input id="orgName" name="orgName" autoComplete="organization" required />
        </Field>
        <Field label="Type" htmlFor="orgKind">
          <Select id="orgKind" name="orgKind" defaultValue="company">
            <option value="company">Entreprise</option>
            <option value="firm">Cabinet</option>
            <option value="group">Groupe</option>
          </Select>
        </Field>
      </div>
      <Checkbox
        name="consent"
        required
        label={
          <span className="text-[13px] text-ink-2">
            J&apos;accepte que Next RH traite mes données pour fournir le service. Les données RH ne sont jamais réutilisées pour entraîner des modèles.
          </span>
        }
      />
      {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
      <Button type="submit" size="lg" className="w-full" loading={pending}>
        Créer mon compte
      </Button>
    </form>
  );
}
