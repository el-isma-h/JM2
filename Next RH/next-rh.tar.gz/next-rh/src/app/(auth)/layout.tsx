import Link from "next/link";
import { FiletMarque, Logo } from "@/components/ui/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-[100dvh] lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
      <aside className="hidden flex-col justify-between bg-encre p-10 text-os lg:flex">
        <Link href="/" aria-label="Next RH">
          <Logo clair />
        </Link>
        <div className="max-w-[46ch]">
          <p className="etiquette !text-os/50">Paie, ressources humaines, documents</p>
          <p className="titre-geant mt-6 text-[40px] xl:text-[52px]">
            Une seule
            <br />
            plateforme.
          </p>
          <p className="mt-6 font-serif text-[22px] italic leading-snug text-os/75">
            Un onboarding guidé, des bulletins calculés par un moteur vérifié, une validation avant chaque envoi. Pour les entreprises et les cabinets qui en gèrent plusieurs.
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-4 font-mono text-[10px] uppercase tracking-[0.2em] text-os/40">
          <FiletMarque />
          <span>Données sensibles chiffrées au repos</span>
        </div>
      </aside>
      <main className="flex items-center justify-center px-5 py-12">
        <div className="w-full max-w-md">
          <Link href="/" className="mb-10 block lg:hidden" aria-label="Next RH">
            <Logo />
          </Link>
          {children}
        </div>
      </main>
    </div>
  );
}
