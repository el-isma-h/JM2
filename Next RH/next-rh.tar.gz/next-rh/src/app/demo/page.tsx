import Link from "next/link";
import type { Metadata } from "next";
import { Buildings, IdentificationCard, LockKey } from "@phosphor-icons/react/dist/ssr";
import { FadeIn } from "@/components/ui/motion";
import { DemoEntry } from "@/components/admin/demo-entry";

export const metadata: Metadata = {
  title: "Démonstration : Next RH",
  description: "Explorez Next RH avec une entreprise fictive : paie, congés, documents. Aucune donnée réelle, aucun envoi.",
};

const contents: [string, string][] = [
  ["Entreprise", "Lorvay Ingénierie, bureau d'études fictif à Lyon et Grenoble, convention Syntec, paramètres de paie confirmés."],
  ["Salariés", "14 personnes : cadres et non-cadres, CDI et CDD, un temps partiel, un organigramme complet."],
  ["À traiter", "Une période d'essai qui se termine dans 12 jours, un CDD qui prend fin dans 40 jours, une habilitation qui expire."],
  ["Demandes", "Congés en attente de validation, une feuille de temps avec heures supplémentaires, une note de frais, une demande d'attestation."],
];

export default function DemoPage() {
  return (
    <div className="min-h-[100dvh] bg-bg">
      <header className="border-b border-line">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 lg:px-8">
          <Link href="/" className="text-[16px] font-semibold tracking-tight text-ink">
            Next RH
          </Link>
          <Link href="/connexion" className="text-[13.5px] text-ink-2 hover:text-ink">
            Connexion
          </Link>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-12 px-4 py-14 lg:grid-cols-[minmax(0,5fr)_minmax(0,4fr)] lg:px-8 lg:py-20">
        <FadeIn>
          <h1 className="max-w-[22ch] text-[32px] font-semibold leading-[1.15] tracking-tight text-ink lg:text-[40px]" style={{ textWrap: "balance" }}>
            Explorez Next RH avec une entreprise fictive.
          </h1>
          <p className="mt-4 max-w-[52ch] text-[15.5px] leading-relaxed text-ink-2">
            Un espace neuf est préparé pour vous seul, avec des données inventées. Il est supprimé automatiquement au bout de 24 heures.
          </p>

          <div className="mt-8 space-y-6">
            <div className="flex gap-4">
              <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-sm)] bg-accent-soft text-accent-strong">
                <Buildings size={18} />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="text-[15px] font-semibold text-ink">Gestionnaire de paie</h2>
                <p className="mt-1 max-w-[50ch] text-[13.5px] text-ink-2">Tableau de bord, salariés, préparation de la paie, échéances et documents, avec tous les droits.</p>
                <div className="mt-3">
                  <DemoEntry as="manager" label="Entrer comme gestionnaire de paie" primary />
                </div>
              </div>
            </div>
            <div className="flex gap-4">
              <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-sm)] bg-bg-muted text-ink-2">
                <IdentificationCard size={18} />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="text-[15px] font-semibold text-ink">Salarié</h2>
                <p className="mt-1 max-w-[50ch] text-[13.5px] text-ink-2">L&apos;espace personnel de Mathis Perrin, technicien : ses documents, ses congés, ses demandes.</p>
                <div className="mt-3">
                  <DemoEntry as="employee" label="Entrer comme salarié" />
                </div>
              </div>
            </div>
          </div>
        </FadeIn>

        <FadeIn delay={0.08} className="lg:pt-2">
          <div className="rounded-[var(--radius-md)] border border-line bg-bg-elev">
            <p className="border-b border-line px-5 py-3.5 text-[13.5px] font-semibold text-ink">Ce que contient l&apos;espace</p>
            <dl className="divide-y divide-line">
              {contents.map(([k, v]) => (
                <div key={k} className="grid grid-cols-[96px_1fr] gap-4 px-5 py-3.5 text-[13.5px]">
                  <dt className="text-ink-3">{k}</dt>
                  <dd className="text-ink">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="mt-5 flex gap-3 rounded-[var(--radius-sm)] bg-warn-soft px-4 py-3.5 text-[13.5px] text-warn-ink">
            <LockKey size={18} className="mt-0.5 shrink-0" />
            <p>
              <span className="font-semibold">Rien n&apos;est envoyé.</span> Aucune déclaration, aucun virement, aucun e-mail ne quitte la démonstration. Les noms, le SIREN (préfixe 000) et les IBAN (banque 99999) sont fictifs.
            </p>
          </div>
        </FadeIn>
      </main>
    </div>
  );
}
