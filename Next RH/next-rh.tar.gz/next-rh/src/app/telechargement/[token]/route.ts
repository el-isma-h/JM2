import { NextResponse } from "next/server";
import { getCurrentUser } from "@/server/auth";
import { readDocument, resolveDownloadToken } from "@/server/documents/store";
import { audit } from "@/server/audit";

export async function GET(_req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const resolved = await resolveDownloadToken(token);
  if (!resolved) return new NextResponse("Lien expiré ou invalide.", { status: 404 });
  const user = await getCurrentUser();
  if (!user || (resolved.userId && resolved.userId !== user.id)) return new NextResponse("Accès refusé.", { status: 403 });
  const found = await readDocument(resolved.documentId);
  if (!found) return new NextResponse("Document introuvable.", { status: 404 });
  await audit({ action: "document.download", userId: user.id, companyId: found.doc.companyId, entityType: "document", entityId: found.doc.id });
  return new NextResponse(new Uint8Array(found.data), {
    headers: {
      "Content-Type": found.doc.mimeType,
      "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(found.doc.fileName)}`,
      "Cache-Control": "private, no-store",
    },
  });
}
