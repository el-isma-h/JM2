import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardSelf } from "@/server/hr/self";
import { HrError, UUID_RE } from "@/server/hr/common";
import { loadReport } from "@/server/hr/expenses";
import { selfAddExpenseLineAction, selfDownloadAction, selfRemoveExpenseLineAction, selfSubmitExpenseAction } from "@/server/actions/self";
import { ActionButton } from "@/components/hr/action-form";
import { ExpenseLines } from "@/components/hr/expense-report";
import { Notice, PageHeader } from "@/components/ui/surface";
import { StatusBadge } from "@/components/ui/badge";
import { fmtDate } from "@/lib/dates";

export default async function SelfExpenseReport({ params }: { params: Promise<{ reportId: string }> }) {
  const { reportId } = await params;
  const s = await guardSelf(`/moi/frais/${reportId}`);
  if (!UUID_RE.test(reportId)) notFound();
  let row;
  try {
    row = await loadReport(s.company.id, reportId, s.employee.id);
  } catch (e) {
    if (e instanceof HrError) notFound();
    throw e;
  }
  const { r } = row;
  const lines = await db.select().from(schema.expenseLines).where(eq(schema.expenseLines.reportId, r.id)).orderBy(asc(schema.expenseLines.date));
  const editable = r.status === "draft" || r.status === "rejected";
  const hidden = { reportId: r.id };
  return (
    <>
      <PageHeader
        breadcrumb={[{ label: "Mes notes de frais", href: "/moi/frais" }, { label: r.title }]}
        title={r.title}
        description={`Créée le ${fmtDate(r.createdAt)}.`}
        actions={
          <>
            <StatusBadge status={r.status} />
            {editable && lines.length ? (
              <ActionButton action={selfSubmitExpenseAction} hidden={hidden} label="Envoyer pour validation" variant="primary" size="md" confirm={{ title: "Envoyer la note", description: "Vous ne pourrez plus la modifier sauf si elle est refusée.", confirmLabel: "Envoyer" }} />
            ) : null}
          </>
        }
      />
      {r.status === "pending" ? <Notice className="mb-6">Note envoyée : en attente de validation par votre employeur.</Notice> : null}
      {r.status === "approved" ? <Notice tone="ok" className="mb-6">Note validée le {fmtDate(r.decidedAt)} : le remboursement sera versé avec votre prochain salaire.</Notice> : null}
      {r.status === "rejected" ? <Notice tone="warn" className="mb-6">Note refusée : corrigez-la puis envoyez-la à nouveau, ou contactez le service RH.</Notice> : null}
      <ExpenseLines lines={lines} totalCents={r.totalCents} editable={editable} hidden={hidden} addAction={selfAddExpenseLineAction} removeAction={selfRemoveExpenseLineAction} linkAction={selfDownloadAction} linkHidden={{}} />
    </>
  );
}
