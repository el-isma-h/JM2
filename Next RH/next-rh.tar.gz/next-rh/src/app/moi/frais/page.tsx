import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { Wallet } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardSelf } from "@/server/hr/self";
import { selfCreateExpenseAction } from "@/server/actions/self";
import { ActionForm } from "@/components/hr/action-form";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { StatusBadge } from "@/components/ui/badge";
import { Field, Input } from "@/components/ui/field";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";

export default async function SelfExpenses() {
  const s = await guardSelf("/moi/frais");
  const reports = await db.select().from(schema.expenseReports).where(eq(schema.expenseReports.employeeId, s.employee.id)).orderBy(desc(schema.expenseReports.updatedAt));
  return (
    <>
      <PageHeader title="Mes notes de frais" description="Créez une note, ajoutez vos dépenses avec leurs justificatifs, puis envoyez-la. Le remboursement est versé avec votre salaire." />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,2fr)]">
        <Panel className="self-start">
          <PanelHeader title="Nouvelle note" />
          <div className="p-5">
            <ActionForm action={selfCreateExpenseAction} submitLabel="Créer la note">
              <Field label="Titre" required htmlFor="sx-title" help="Ex. « Déplacement client Nantes, octobre ».">
                <Input id="sx-title" name="title" required />
              </Field>
            </ActionForm>
          </div>
        </Panel>
        <Panel className="self-start">
          <PanelHeader title="Mes notes" />
          {reports.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Note</Th>
                  <Th>Mise à jour</Th>
                  <Th>Statut</Th>
                  <Th num>Total</Th>
                </tr>
              </thead>
              <tbody>
                {reports.map((r) => (
                  <tr key={r.id}>
                    <Td>
                      <Link href={`/moi/frais/${r.id}`} className="font-medium text-ink hover:underline">
                        {r.title}
                      </Link>
                    </Td>
                    <Td className="whitespace-nowrap">{fmtDate(r.updatedAt)}</Td>
                    <Td>
                      <StatusBadge status={r.status} />
                    </Td>
                    <Td num className="font-medium">
                      {formatCents(r.totalCents)}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <EmptyState icon={<Wallet size={28} />} title="Aucune note de frais" description="Créez votre première note pour vous faire rembourser une dépense professionnelle." />
          )}
        </Panel>
      </div>
    </>
  );
}
