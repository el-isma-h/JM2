import { and, desc, eq } from "drizzle-orm";
import { Tray } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardSelf } from "@/server/hr/self";
import { HR_REQUEST_KINDS, hrRequestKindLabel } from "@/server/hr/requests";
import { selfCancelHrRequestAction, selfHrRequestAction } from "@/server/actions/self";
import { ActionButton, ActionForm } from "@/components/hr/action-form";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { StatusBadge } from "@/components/ui/badge";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { fmtDate, fmtDateTime } from "@/lib/dates";
import { cn } from "@/lib/utils";

export default async function SelfRequests() {
  const s = await guardSelf("/moi/demandes");
  const requests = await db
    .select()
    .from(schema.hrRequests)
    .where(and(eq(schema.hrRequests.employeeId, s.employee.id), eq(schema.hrRequests.companyId, s.company.id)))
    .orderBy(desc(schema.hrRequests.createdAt));
  const kinds = HR_REQUEST_KINDS.filter((k) => k.value !== "correction_informations");

  return (
    <>
      <PageHeader title="Mes demandes" description="Posez une question ou demandez une attestation, un justificatif ou un acompte au service RH, et suivez la réponse. Pour corriger vos coordonnées, passez par Mes informations." />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]">
        <Panel className="self-start">
          <PanelHeader title="Nouvelle demande" />
          <div className="p-5">
            <ActionForm action={selfHrRequestAction} submitLabel="Envoyer">
              <Field label="Type" required htmlFor="hr-kind">
                <Select id="hr-kind" name="kind" required defaultValue="question">
                  {kinds.map((k) => (
                    <option key={k.value} value={k.value}>
                      {k.label}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Objet" required htmlFor="hr-title">
                <Input id="hr-title" name="title" required placeholder="Attestation employeur pour mon bailleur" />
              </Field>
              <Field label="Montant de l'acompte (euros)" htmlFor="hr-amount" help="Uniquement pour une demande d'acompte : il sera retenu sur votre prochain salaire.">
                <Input id="hr-amount" name="amount" inputMode="decimal" />
              </Field>
              <Field label="Message" htmlFor="hr-body">
                <Textarea id="hr-body" name="body" />
              </Field>
            </ActionForm>
          </div>
        </Panel>
        <Panel className="self-start">
          <PanelHeader title="Suivi" />
          {requests.length ? (
            <ul>
              {requests.map((r) => (
                <li key={r.id} className="border-b border-line px-5 py-3.5 last:border-b-0">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-medium text-ink">{r.title}</p>
                      <p className="text-[12px] text-ink-3">
                        {hrRequestKindLabel(r.kind)}, envoyée le {fmtDate(r.createdAt)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge status={r.status} />
                      {r.status === "pending" ? <ActionButton action={selfCancelHrRequestAction} hidden={{ requestId: r.id }} label="Retirer" variant="ghost" /> : null}
                    </div>
                  </div>
                  {r.body ? <p className="mt-1.5 whitespace-pre-wrap text-[13px] text-ink-2">{r.body}</p> : null}
                  {r.answer ? (
                    <div className={cn("mt-2 rounded-[var(--radius-sm)] px-3 py-2 text-[13px]", r.status === "rejected" ? "bg-danger-soft text-danger-ink" : "bg-ok-soft text-ok-ink")}>
                      <p className="text-[12px] font-medium">Réponse du service RH{r.decidedAt ? `, ${fmtDateTime(r.decidedAt)}` : ""}</p>
                      <p className="whitespace-pre-wrap">{r.answer}</p>
                    </div>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState icon={<Tray size={28} />} title="Aucune demande" description="Vos demandes au service RH et leurs réponses apparaîtront ici." />
          )}
        </Panel>
      </div>
    </>
  );
}
