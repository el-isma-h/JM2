import Link from "next/link";
import { redirect } from "next/navigation";
import { getSelfContext } from "@/server/hr/self";
import { selectSelfRecordAction } from "@/server/actions/self";
import { AppShell } from "@/components/app/shell";
import { Logo } from "@/components/ui/logo";
import { employeeNav } from "@/components/app/nav";
import { SelfSwitcher } from "@/components/hr/self-switcher";
import { Badge } from "@/components/ui/badge";
import { EmptyState, Panel } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";

export default async function SelfLayout({ children }: { children: React.ReactNode }) {
  const ctx = await getSelfContext();
  if (!ctx) redirect("/connexion?next=/moi");
  if (!ctx.user.emailVerified) redirect("/verification");
  const user = ctx.user;
  if (!ctx.employee || !ctx.company) {
    return (
      <main className="mx-auto flex min-h-[100dvh] max-w-lg items-center px-4">
        <Panel className="w-full">
          <EmptyState
            title="Aucune fiche salarié rattachée à votre compte"
            description="Votre employeur doit vous inviter depuis votre fiche salarié pour ouvrir votre espace personnel. Contactez votre service RH."
            action={
              <Button asChild variant="secondary">
                <Link href="/app">Retour</Link>
              </Button>
            }
          />
        </Panel>
      </main>
    );
  }
  return (
    <AppShell
      base="/moi"
      items={employeeNav}
      brand={
        <Link href="/moi" className="flex items-center gap-3 text-ink">
          <Logo />
          {ctx.company.isDemo ? <Badge tone="warn">Démo</Badge> : null}
        </Link>
      }
      context={
        <SelfSwitcher
          action={selectSelfRecordAction}
          currentId={ctx.employee.id}
          records={ctx.records.map((r) => ({ id: r.e.id, label: `${r.c.tradeName ?? r.c.legalName}${r.e.status === "left" ? " (ancien employeur)" : ""}` }))}
        />
      }
      user={{ name: `${user.firstName} ${user.lastName}`, email: user.email, isAdmin: user.platformRole === "platform_admin" }}
    >
      {children}
    </AppShell>
  );
}
