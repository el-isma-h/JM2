import Link from "next/link";
import { and, desc, eq, inArray } from "drizzle-orm";
import { ArrowRight, CalendarPlus, FileArrowUp, Receipt, Wallet } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardSelf } from "@/server/hr/self";
import { todayIso } from "@/server/hr/common";
import { getLeaveTypes, recomputeBalances } from "@/server/hr/leave";
import { hrRequestKindLabel } from "@/server/hr/requests";
import { selfDownloadAction } from "@/server/actions/self";
import { ActionButton } from "@/components/hr/action-form";
import { CountUpNumber } from "@/components/dashboard/count";
import { FadeIn } from "@/components/ui/motion";
import { EmptyState, Panel, PanelHeader } from "@/components/ui/surface";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { fmtDate, monthLabel } from "@/lib/dates";
import { formatCents, formatNumber } from "@/lib/money";

export default async function SelfHome() {
  const s = await guardSelf("/moi");
  const { employee, company } = s;
  const today = todayIso();
  const [balances, types, leaves, hrReqs, expenses, slips] = await Promise.all([
    db.transaction((tx) => recomputeBalances(tx, company.id, employee.id)),
    getLeaveTypes(company.id),
    db.select().from(schema.leaveRequests).where(eq(schema.leaveRequests.employeeId, employee.id)).orderBy(desc(schema.leaveRequests.createdAt)).limit(20),
    db.select().from(schema.hrRequests).where(and(eq(schema.hrRequests.employeeId, employee.id), eq(schema.hrRequests.companyId, company.id))).orderBy(desc(schema.hrRequests.createdAt)).limit(5),
    db.select().from(schema.expenseReports).where(eq(schema.expenseReports.employeeId, employee.id)).orderBy(desc(schema.expenseReports.updatedAt)).limit(5),
    db
      .select({ s: schema.payslips, p: schema.payrollPeriods })
      .from(schema.payslips)
      .innerJoin(schema.payrollPeriods, eq(schema.payrollPeriods.id, schema.payslips.periodId))
      .where(and(eq(schema.payslips.employeeId, employee.id), eq(schema.payrollPeriods.companyId, company.id), inArray(schema.payslips.status, ["distributed"])))
      .orderBy(desc(schema.payrollPeriods.year), desc(schema.payrollPeriods.month))
      .limit(1),
  ]);
  const typeById = new Map(types.map((t) => [t.id, t]));
  const upcoming = leaves.filter((l) => (l.status === "approved" || l.status === "pending") && l.endDate >= today).sort((a, b) => a.startDate.localeCompare(b.startDate)).slice(0, 4);
  const lastSlip = slips[0];
  const [slipDoc] = lastSlip?.s.documentId
    ? await db
        .select({ id: schema.documents.id })
        .from(schema.documents)
        .where(and(eq(schema.documents.id, lastSlip.s.documentId), eq(schema.documents.employeeId, employee.id), eq(schema.documents.visibility, "employee")))
        .limit(1)
    : [];
  const recent = [
    ...leaves.slice(0, 5).map((l) => ({ id: l.id, at: l.createdAt, label: `${typeById.get(l.leaveTypeId)?.label ?? "Absence"} du ${fmtDate(l.startDate)}`, status: l.status, href: "/moi/conges" })),
    ...hrReqs.map((r) => ({ id: r.id, at: r.createdAt, label: `${hrRequestKindLabel(r.kind)} : ${r.title}`, status: r.status, href: "/moi/demandes" })),
    ...expenses.map((x) => ({ id: x.id, at: x.updatedAt, label: `Note de frais : ${x.title}`, status: x.status, href: `/moi/frais/${x.id}` })),
  ]
    .sort((a, b) => b.at.getTime() - a.at.getTime())
    .slice(0, 6);

  return (
    <div className="space-y-6">
      <FadeIn>
        <h1 className="text-[22px] font-semibold tracking-tight text-ink">Bonjour {employee.firstName}</h1>
        <p className="mt-1 text-[13.5px] text-ink-2">
          {company.tradeName ?? company.legalName}
          {employee.jobTitle ? `, ${employee.jobTitle}` : ""}.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button asChild>
            <Link href="/moi/conges">
              <CalendarPlus size={16} /> Demander un congé
            </Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href="/moi/frais">
              <Wallet size={16} /> Note de frais
            </Link>
          </Button>
          <Button asChild variant="secondary">
            <Link href="/moi/documents#justificatif">
              <FileArrowUp size={16} /> Déposer un justificatif
            </Link>
          </Button>
        </div>
      </FadeIn>

      <FadeIn delay={0.05} className="grid gap-6 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <Panel>
          <PanelHeader title="Mes soldes de congés" description="Jours disponibles, en tenant compte des demandes en attente." />
          {balances.length ? (
            <dl className="grid divide-y divide-line sm:grid-cols-2 sm:divide-x sm:divide-y-0">
              {balances.map((b) => {
                const [prev, cur] = b.periods;
                return (
                  <div key={b.leaveTypeId} className="px-5 py-4">
                    <dt className="text-[13px] text-ink-2">{b.label}</dt>
                    <dd className={b.available < 0 ? "text-danger-ink" : "text-ink"}>
                      <span className="text-[28px] font-medium leading-tight">
                        <CountUpNumber value={b.available} digits={b.available % 1 ? 2 : 0} />
                      </span>
                      <span className="ml-1 text-[13px] text-ink-2">jour(s)</span>
                    </dd>
                    <dd className="mt-1 text-[12px] text-ink-3">
                      {b.code === "CP" ? `Reliquat de l'an dernier : ${formatNumber(prev.remaining, 2)} j. Acquis depuis le ${fmtDate(cur.periodStart)} : ${formatNumber(cur.acquired, 2)} j.` : `Acquis : ${formatNumber(cur.acquired + prev.acquired, 2)} j.`}
                      {cur.pending + prev.pending > 0 ? ` En attente : ${formatNumber(cur.pending + prev.pending, 1)} j.` : ""}
                    </dd>
                  </div>
                );
              })}
            </dl>
          ) : (
            <EmptyState className="py-8" title="Aucun solde suivi" description="Votre employeur n'a pas encore paramétré de type d'absence à solde." />
          )}
          <div className="border-t border-line">
            <p className="px-5 pt-3 text-[12.5px] font-medium text-ink-2">Prochaines absences</p>
            {upcoming.length ? (
              <ul>
                {upcoming.map((l) => (
                  <li key={l.id} className="flex items-center justify-between gap-3 px-5 py-2 text-[13.5px]">
                    <span className="min-w-0 truncate text-ink">
                      {typeById.get(l.leaveTypeId)?.label} : {fmtDate(l.startDate)}
                      {l.endDate !== l.startDate ? ` au ${fmtDate(l.endDate)}` : ""}
                    </span>
                    <StatusBadge status={l.status} />
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-5 pb-3 pt-1 text-[13px] text-ink-3">Aucune absence prévue.</p>
            )}
          </div>
        </Panel>

        <Panel className="self-start">
          <PanelHeader title="Dernier bulletin de paie" />
          {lastSlip ? (
            <div className="px-5 py-4">
              <p className="text-[13px] capitalize text-ink-2">{monthLabel(lastSlip.p.year, lastSlip.p.month)}</p>
              <p className="mt-0.5 text-[26px] font-medium text-ink">
                <CountUpNumber value={lastSlip.s.netPaidCents} cents />
              </p>
              <p className="text-[12.5px] text-ink-3">
                Net payé{lastSlip.p.paymentDate ? ` le ${fmtDate(lastSlip.p.paymentDate)}` : ""}. Brut : <span className="num">{formatCents(lastSlip.s.grossCents)}</span>.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {slipDoc ? <ActionButton action={selfDownloadAction} hidden={{ documentId: slipDoc.id }} label="Télécharger le PDF" variant="secondary" icon={<Receipt size={15} />} /> : null}
                <Button asChild variant="ghost" size="sm">
                  <Link href="/moi/documents">
                    Tous mes documents <ArrowRight size={14} />
                  </Link>
                </Button>
              </div>
            </div>
          ) : (
            <EmptyState className="py-8" title="Pas encore de bulletin" description="Vos bulletins apparaîtront ici dès leur mise à disposition par votre employeur." />
          )}
        </Panel>
      </FadeIn>

      <FadeIn delay={0.1}>
        <Panel>
          <PanelHeader
            title="Mes dernières demandes"
            actions={
              <Button asChild variant="ghost" size="sm">
                <Link href="/moi/demandes">Suivre mes demandes</Link>
              </Button>
            }
          />
          {recent.length ? (
            <ul>
              {recent.map((r) => (
                <li key={r.id} className="border-b border-line last:border-b-0">
                  <Link href={r.href} className="flex items-center justify-between gap-3 px-5 py-2.5 text-[13.5px] hover:bg-bg-sunken">
                    <span className="min-w-0 truncate text-ink">{r.label}</span>
                    <span className="flex shrink-0 items-center gap-3">
                      <span className="text-[12px] text-ink-3">{fmtDate(r.at)}</span>
                      <StatusBadge status={r.status} />
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState className="py-8" title="Aucune demande" description="Congés, notes de frais et demandes au service RH apparaîtront ici." />
          )}
        </Panel>
      </FadeIn>
    </div>
  );
}
