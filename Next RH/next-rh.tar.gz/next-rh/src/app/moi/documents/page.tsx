import { and, desc, eq } from "drizzle-orm";
import { DownloadSimple, Files } from "@phosphor-icons/react/ssr";
import { db, schema } from "@/db";
import { guardSelf } from "@/server/hr/self";
import { selfDownloadAction, selfUploadProofAction } from "@/server/actions/self";
import { ActionButton, ActionForm } from "@/components/hr/action-form";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { fmtDate } from "@/lib/dates";

const categoryLabels: Record<string, string> = {
  bulletin: "Bulletin de paie",
  contrat: "Contrat",
  avenant: "Avenant",
  attestation: "Attestation",
  courrier: "Courrier",
  justificatif: "Justificatif",
  identite: "Pièce d'identité",
  convocation: "Convocation",
  compte_rendu: "Compte rendu",
  autre: "Autre",
};

const fmtSize = (b: number) => (b > 1024 * 1024 ? `${(b / 1024 / 1024).toFixed(1).replace(".", ",")} Mo` : `${Math.max(1, Math.round(b / 1024))} Ko`);

export default async function SelfDocuments({ searchParams }: { searchParams: Promise<{ type?: string }> }) {
  const s = await guardSelf("/moi/documents");
  const sp = await searchParams;
  const docs = await db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.companyId, s.company.id), eq(schema.documents.employeeId, s.employee.id), eq(schema.documents.visibility, "employee")))
    .orderBy(desc(schema.documents.createdAt));
  const type = sp.type && sp.type in categoryLabels ? sp.type : "";
  const shown = type ? docs.filter((d) => d.category === type) : docs;
  const present = [...new Set(docs.map((d) => d.category))];
  const pendingLeaves = await db
    .select({ id: schema.leaveRequests.id, start: schema.leaveRequests.startDate, label: schema.leaveTypes.label, proof: schema.leaveRequests.proofDocumentId })
    .from(schema.leaveRequests)
    .innerJoin(schema.leaveTypes, eq(schema.leaveTypes.id, schema.leaveRequests.leaveTypeId))
    .where(and(eq(schema.leaveRequests.employeeId, s.employee.id), eq(schema.leaveRequests.status, "pending")));

  return (
    <>
      <PageHeader title="Mes documents" description="Bulletins de paie, contrats, attestations et justificatifs mis à votre disposition. Les liens de téléchargement sont valables 15 minutes." />
      <Panel>
        <PanelHeader
          title={`${shown.length} document(s)`}
          actions={
            present.length > 1 ? (
              <form action="/moi/documents" className="flex items-center gap-2">
                <label htmlFor="doc-type" className="sr-only">
                  Type de document
                </label>
                <Select id="doc-type" name="type" defaultValue={type} className="h-8 w-48 text-[13px]">
                  <option value="">Tous les documents</option>
                  {present.map((c) => (
                    <option key={c} value={c}>
                      {categoryLabels[c] ?? c}
                    </option>
                  ))}
                </Select>
                <button type="submit" className="h-8 rounded-[var(--radius-sm)] border border-line-strong px-3 text-[13px] text-ink hover:bg-bg-sunken">
                  Filtrer
                </button>
              </form>
            ) : null
          }
        />
        {shown.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Document</Th>
                <Th>Type</Th>
                <Th>Date</Th>
                <Th num>Taille</Th>
                <Th className="text-right">Télécharger</Th>
              </tr>
            </thead>
            <tbody>
              {shown.map((d) => (
                <tr key={d.id}>
                  <Td className="font-medium text-ink">{d.title}</Td>
                  <Td>{categoryLabels[d.category] ?? d.category}</Td>
                  <Td className="whitespace-nowrap">{fmtDate(d.createdAt)}</Td>
                  <Td num>{fmtSize(d.sizeBytes)}</Td>
                  <Td className="text-right">
                    <ActionButton action={selfDownloadAction} hidden={{ documentId: d.id }} label="Télécharger" ariaLabel={`Télécharger ${d.title}`} variant="ghost" icon={<DownloadSimple size={15} />} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <EmptyState icon={<Files size={28} />} title="Aucun document pour l'instant" description="Vos bulletins et documents apparaîtront ici dès que votre employeur les mettra à disposition." />
        )}
      </Panel>

      <Panel className="mt-6" id="justificatif">
        <PanelHeader title="Déposer un justificatif" description="Arrêt de travail, acte de naissance, attestation : il est transmis au service RH." />
        <div className="p-5">
          <ActionForm action={selfUploadProofAction} submitLabel="Envoyer le justificatif">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Concerne" htmlFor="pr-leave" help="Rattachez-le à une absence en attente si c'est son justificatif.">
                <Select id="pr-leave" name="leaveRequestId" defaultValue="">
                  <option value="">Autre (envoyé au service RH)</option>
                  {pendingLeaves.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.label} du {fmtDate(l.start)}
                      {l.proof ? " (déjà fourni)" : ""}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Intitulé" htmlFor="pr-title">
                <Input id="pr-title" name="title" placeholder="Arrêt de travail du 14 octobre" />
              </Field>
              <Field label="Fichier" required htmlFor="pr-file" help="PDF ou photo, 10 Mo maximum." className="sm:col-span-2">
                <Input id="pr-file" name="file" type="file" required accept="application/pdf,image/jpeg,image/png,image/webp,image/heic" className="py-1.5" />
              </Field>
              <Field label="Message" htmlFor="pr-note" className="sm:col-span-2">
                <Textarea id="pr-note" name="note" className="min-h-16" placeholder="Facultatif" />
              </Field>
            </div>
          </ActionForm>
        </div>
      </Panel>
    </>
  );
}
