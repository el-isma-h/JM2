import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardSelf } from "@/server/hr/self";
import { getLeaveTypes, isLeaveSelectable, recomputeBalances } from "@/server/hr/leave";
import { selfCancelLeaveAction, selfRequestLeaveAction } from "@/server/actions/self";
import { ActionButton, ActionForm } from "@/components/hr/action-form";
import { LeaveFields } from "@/components/hr/leave-fields";
import { EmptyState, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { fmtDate } from "@/lib/dates";
import { formatNumber } from "@/lib/money";

export default async function SelfLeave() {
  const s = await guardSelf("/moi/conges");
  const [types, balances, requests] = await Promise.all([
    getLeaveTypes(s.company.id),
    db.transaction((tx) => recomputeBalances(tx, s.company.id, s.employee.id)),
    db.select().from(schema.leaveRequests).where(eq(schema.leaveRequests.employeeId, s.employee.id)).orderBy(desc(schema.leaveRequests.startDate)).limit(60),
  ]);
  const selectable = types.filter(isLeaveSelectable);
  const typeById = new Map(types.map((t) => [t.id, t]));
  const balanceMap = Object.fromEntries(balances.map((b) => [b.leaveTypeId, b.available]));

  return (
    <>
      <PageHeader title="Mes congés" description="Demandez un congé : la durée est calculée en jours ouvrés hors jours fériés et votre solde est vérifié avant l'envoi." />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)]">
        <Panel className="self-start">
          <PanelHeader title="Nouvelle demande" />
          <div className="p-5">
            {balances.length ? (
              <dl className="mb-5 flex flex-wrap gap-x-8 gap-y-2">
                {balances.map((b) => (
                  <div key={b.leaveTypeId}>
                    <dt className="text-[12.5px] text-ink-2">{b.label} disponibles</dt>
                    <dd className={`num text-[20px] font-medium ${b.available < 0 ? "text-danger-ink" : "text-ink"}`}>{formatNumber(b.available, b.available % 1 ? 2 : 0)} j</dd>
                  </div>
                ))}
              </dl>
            ) : null}
            {selectable.length ? (
              <ActionForm action={selfRequestLeaveAction} submitLabel="Envoyer la demande">
                <LeaveFields types={selectable} balances={balanceMap} />
              </ActionForm>
            ) : (
              <EmptyState title="Aucun type d'absence disponible" description="Votre employeur doit paramétrer les types d'absence." />
            )}
          </div>
        </Panel>
        <Panel className="self-start">
          <PanelHeader title="Mes demandes" description="Une demande en attente peut être annulée. Pour annuler un congé déjà validé, contactez le service RH." />
          {requests.length ? (
            <Table>
              <thead>
                <tr>
                  <Th>Absence</Th>
                  <Th>Période</Th>
                  <Th num>Durée</Th>
                  <Th>Statut</Th>
                  <Th className="text-right">Action</Th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r) => {
                  const t = typeById.get(r.leaveTypeId);
                  return (
                    <tr key={r.id}>
                      <Td>
                        {t?.label}
                        {t?.requiresProof && !r.proofDocumentId && r.status === "pending" ? (
                          <span className="mt-0.5 block">
                            <Badge tone="warn">Justificatif à déposer</Badge>
                          </span>
                        ) : null}
                        {r.decisionNote && r.status === "rejected" ? <span className="block text-[12px] text-danger-ink">Motif : {r.decisionNote}</span> : null}
                      </Td>
                      <Td className="whitespace-nowrap">
                        {fmtDate(r.startDate)}
                        {r.startDate !== r.endDate ? ` au ${fmtDate(r.endDate)}` : ""}
                      </Td>
                      <Td num>{formatNumber(r.duration, Number(r.duration) % 1 ? 1 : 0)} j</Td>
                      <Td>
                        <StatusBadge status={r.status} />
                      </Td>
                      <Td className="text-right">
                        {r.status === "pending" ? (
                          <ActionButton action={selfCancelLeaveAction} hidden={{ requestId: r.id }} label="Annuler" variant="ghost" confirm={{ title: "Annuler ma demande", description: `${t?.label} du ${fmtDate(r.startDate)}.`, confirmLabel: "Annuler la demande" }} />
                        ) : null}
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          ) : (
            <EmptyState title="Aucune demande" description="Vos demandes de congé et leur statut apparaîtront ici." />
          )}
        </Panel>
      </div>
    </>
  );
}
