import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guardSelf } from "@/server/hr/self";
import { activeContract } from "@/server/hr/common";
import { CORRECTABLE_FIELDS } from "@/server/hr/requests";
import { selfCorrectionRequestAction } from "@/server/actions/self";
import { ActionForm } from "@/components/hr/action-form";
import { contractTypeLabels } from "@/components/hr/labels";
import { KeyValue, Notice, PageHeader, Panel, PanelHeader } from "@/components/ui/surface";
import { Field, Input, Textarea } from "@/components/ui/field";
import { fmtDate } from "@/lib/dates";
import { maskIban } from "@/lib/crypto";
import { formatNumber } from "@/lib/money";

export default async function SelfInformation() {
  const s = await guardSelf("/moi/informations");
  const e = s.employee;
  const [contract, [bank], [pendingCorrection], establishment, manager] = await Promise.all([
    activeContract(e.id),
    db.select({ last4: schema.employeeBankAccounts.ibanLast4, bank: schema.employeeBankAccounts.bankName, holder: schema.employeeBankAccounts.holderName }).from(schema.employeeBankAccounts).where(and(eq(schema.employeeBankAccounts.employeeId, e.id), eq(schema.employeeBankAccounts.isPrimary, true))).limit(1),
    db
      .select({ id: schema.hrRequests.id, createdAt: schema.hrRequests.createdAt })
      .from(schema.hrRequests)
      .where(and(eq(schema.hrRequests.employeeId, e.id), eq(schema.hrRequests.companyId, s.company.id), eq(schema.hrRequests.kind, "correction_informations"), eq(schema.hrRequests.status, "pending")))
      .orderBy(desc(schema.hrRequests.createdAt))
      .limit(1),
    e.establishmentId ? db.select({ name: schema.establishments.name }).from(schema.establishments).where(and(eq(schema.establishments.id, e.establishmentId), eq(schema.establishments.companyId, s.company.id))).limit(1) : Promise.resolve([]),
    e.managerId ? db.select({ f: schema.employees.firstName, l: schema.employees.lastName }).from(schema.employees).where(and(eq(schema.employees.id, e.managerId), eq(schema.employees.companyId, s.company.id))).limit(1) : Promise.resolve([]),
  ]);
  const address = [e.addressLine1, e.addressLine2, [e.postalCode, e.city].filter(Boolean).join(" "), e.country !== "FR" ? e.country : null].filter(Boolean).join(", ");

  return (
    <>
      <PageHeader title="Mes informations" description="Les informations de votre dossier salarié. Pour modifier vos coordonnées ou votre adresse, envoyez une demande de correction : le service RH la vérifie puis l'applique." />
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <Panel>
            <PanelHeader title="Identité et coordonnées" />
            <div className="p-5">
              <KeyValue
                items={[
                  { k: "Nom", v: `${e.civility ? `${e.civility} ` : ""}${e.firstName} ${e.lastName}` },
                  { k: "Nom de naissance", v: e.birthName },
                  { k: "Date de naissance", v: e.birthDate ? fmtDate(e.birthDate) : null },
                  { k: "N° de sécurité sociale", v: e.nirEnc ? "Renseigné (masqué)" : "Non renseigné" },
                  { k: "E-mail professionnel", v: e.email },
                  { k: "E-mail personnel", v: e.personalEmail },
                  { k: "Téléphone", v: e.phone },
                  { k: "Adresse", v: address || null },
                ]}
              />
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Poste et contrat" />
            <div className="p-5">
              <KeyValue
                items={[
                  { k: "Poste", v: e.jobTitle ?? contract?.jobTitle },
                  { k: "Service", v: e.department },
                  { k: "Établissement", v: establishment[0]?.name },
                  { k: "Responsable", v: manager[0] ? `${manager[0].f} ${manager[0].l}` : null },
                  { k: "Date d'entrée", v: e.hireDate ? fmtDate(e.hireDate) : null },
                  { k: "Contrat", v: contract ? `${contractTypeLabels[contract.type] ?? contract.type}${contract.endDate ? ` jusqu'au ${fmtDate(contract.endDate)}` : ""}` : null },
                  { k: "Durée du travail", v: contract ? (contract.workTimeMode === "forfait_jours" ? `Forfait de ${contract.annualDays ?? 218} jours` : `${formatNumber(contract.weeklyHours, 2)} h par semaine`) : null },
                  { k: "Matricule", v: e.employeeNumber },
                ]}
              />
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Coordonnées bancaires" description="Affichées masquées. Pour changer de compte, envoyez un nouveau RIB via Mes demandes." />
            <div className="p-5">
              <KeyValue items={bank ? [{ k: "IBAN", v: <span className="num">{maskIban(bank.last4)}</span> }, { k: "Titulaire", v: bank.holder }, { k: "Banque", v: bank.bank }] : [{ k: "IBAN", v: "Non renseigné" }]} />
            </div>
          </Panel>
        </div>
        <Panel className="self-start">
          <PanelHeader title="Demander une correction" description="Renseignez uniquement les champs à modifier." />
          <div className="p-5">
            {pendingCorrection ? (
              <Notice tone="info" className="mb-4">
                Une demande de correction envoyée le {fmtDate(pendingCorrection.createdAt)} est en cours de traitement.
              </Notice>
            ) : null}
            <ActionForm action={selfCorrectionRequestAction} submitLabel="Envoyer la demande">
              <div className="grid gap-4 sm:grid-cols-2">
                {(Object.keys(CORRECTABLE_FIELDS) as (keyof typeof CORRECTABLE_FIELDS)[]).map((k) => (
                  <Field key={k} label={CORRECTABLE_FIELDS[k].label} htmlFor={`c-${k}`} className={k === "addressLine1" || k === "addressLine2" ? "sm:col-span-2" : undefined}>
                    <Input id={`c-${k}`} name={k} maxLength={CORRECTABLE_FIELDS[k].max} placeholder={(e[k] as string | null) ?? ""} type={k === "personalEmail" ? "email" : "text"} />
                  </Field>
                ))}
                <Field label="Précisions" htmlFor="c-note" className="sm:col-span-2" help="Pour un changement de nom ou d'état civil, joignez le justificatif via Mes documents.">
                  <Textarea id="c-note" name="note" className="min-h-16" />
                </Field>
              </div>
            </ActionForm>
          </div>
        </Panel>
      </div>
    </>
  );
}
