import { NextResponse, type NextRequest } from "next/server";

/**
 * Proxy (Next 16) : vérification optimiste de présence du cookie de session sur les espaces protégés,
 * et en-têtes de sécurité sur toutes les réponses. L'autorisation réelle reste côté serveur
 * (requireUser / guardCompany / guardAdmin) : ce filtre ne fait qu'éviter un rendu inutile.
 */
const SESSION_COOKIE = "nextrh_session";
const PROTECTED = ["/app", "/moi", "/admin"];

function isProtected(pathname: string) {
  return PROTECTED.some((p) => pathname === p || pathname.startsWith(`${p}/`));
}

function securityHeaders(res: NextResponse) {
  const dev = process.env.NODE_ENV !== "production";
  const csp = [
    "default-src 'self'",
    // Next.js injecte des scripts inline d'hydratation : 'unsafe-inline' est requis sans nonce ; 'unsafe-eval' en développement uniquement.
    `script-src 'self' 'unsafe-inline'${dev ? " 'unsafe-eval'" : ""}`,
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",
    `connect-src 'self'${dev ? " ws: wss:" : ""}`,
    "frame-src 'self'",
    "frame-ancestors 'none'",
    "form-action 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    ...(dev ? [] : ["upgrade-insecure-requests"]),
  ].join("; ");
  res.headers.set("Content-Security-Policy", csp);
  res.headers.set("X-Frame-Options", "DENY");
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  res.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()");
  res.headers.set("Cross-Origin-Opener-Policy", "same-origin");
  if (!dev) res.headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  return res;
}

export function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl;
  if (isProtected(pathname) && !request.cookies.get(SESSION_COOKIE)?.value) {
    const url = request.nextUrl.clone();
    url.pathname = "/connexion";
    url.search = `?next=${encodeURIComponent(pathname + search)}`;
    return securityHeaders(NextResponse.redirect(url));
  }
  return securityHeaders(NextResponse.next());
}

export const config = {
  matcher: [
    // Tout sauf les ressources statiques et l'optimisation d'images.
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:png|jpg|jpeg|svg|webp|ico|woff2?)$).*)",
  ],
};
