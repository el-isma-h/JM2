/**
 * Initialisation de Next RH : `npm run setup` (migrations + admin + données de référence) ou `npm run seed` (données seules).
 * Exécuté avec : tsx --conditions=react-server src/scripts/bootstrap.ts [--seed-only]
 *
 * Étapes :
 *  1. migrations Drizzle existantes (dossier ./drizzle, même journal que `drizzle-kit migrate`) ;
 *  2. administrateur plateforme depuis ADMIN_EMAIL / ADMIN_PASSWORD (idempotent, e-mail vérifié) ;
 *  3. grille tarifaire sourcée (seedPricing) ;
 *  4. registre des traitements (seedRegistry) ;
 *  5. modèles de documents (@/server/documents/templates-seed) et règles de paie (@/server/payroll/rule-sets-db : syncRuleSets) s'ils existent.
 */
import path from "node:path";
import { existsSync } from "node:fs";

try {
  if (existsSync(path.resolve(process.cwd(), ".env"))) process.loadEnvFile(path.resolve(process.cwd(), ".env"));
} catch {
  // variables déjà présentes dans l'environnement (Docker)
}

type Step = { step: string; status: "ok" | "skipped" | "missing" | "error"; detail?: string };
const report: Step[] = [];
const log = (s: Step) => {
  report.push(s);
  const mark = { ok: "OK      ", skipped: "IGNORÉ  ", missing: "ABSENT  ", error: "ERREUR  " }[s.status];
  console.log(`${mark}${s.step}${s.detail ? ` : ${s.detail}` : ""}`);
};

/** Import optionnel : chemin calculé à l'exécution pour ne pas casser `tsc` si le module n'existe pas encore. */
async function optionalImport(specifier: string): Promise<Record<string, unknown> | null> {
  try {
    return (await import(/* webpackIgnore: true */ specifier)) as Record<string, unknown>;
  } catch (e) {
    const code = (e as { code?: string }).code;
    if (code === "ERR_MODULE_NOT_FOUND" || code === "MODULE_NOT_FOUND" || /Cannot find (module|package)/.test(String(e))) return null;
    throw e;
  }
}

async function main() {
  const seedOnly = process.argv.includes("--seed-only");
  const { db, pool, schema } = await import("@/db");
  const { eq } = await import("drizzle-orm");

  if (!seedOnly) {
    const { migrate } = await import("drizzle-orm/node-postgres/migrator");
    await migrate(db, { migrationsFolder: path.resolve(process.cwd(), "drizzle") });
    log({ step: "Migrations", status: "ok" });

    const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
    const password = process.env.ADMIN_PASSWORD;
    if (!email || !password) {
      log({ step: "Administrateur plateforme", status: "skipped", detail: "ADMIN_EMAIL ou ADMIN_PASSWORD non défini" });
    } else {
      const { hashPassword, validatePasswordStrength } = await import("@/server/auth");
      const [existing] = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
      if (existing) {
        const patch: Partial<typeof schema.users.$inferInsert> = {};
        if (existing.platformRole !== "platform_admin") patch.platformRole = "platform_admin";
        if (!existing.emailVerifiedAt) patch.emailVerifiedAt = new Date();
        if (Object.keys(patch).length) await db.update(schema.users).set(patch).where(eq(schema.users.id, existing.id));
        log({ step: "Administrateur plateforme", status: "ok", detail: `${email} déjà présent${Object.keys(patch).length ? " (droits mis à jour)" : ""}, mot de passe inchangé` });
      } else {
        const weak = validatePasswordStrength(password);
        if (weak) console.warn(`Attention : ADMIN_PASSWORD faible (${weak}). Changez-le après la première connexion.`);
        await db.insert(schema.users).values({ email, passwordHash: await hashPassword(password), firstName: "Administrateur", lastName: "Next RH", platformRole: "platform_admin", emailVerifiedAt: new Date() });
        log({ step: "Administrateur plateforme", status: "ok", detail: `${email} créé` });
      }
    }
  }

  const { seedPricing } = await import("@/server/pricing/seed");
  const p = await seedPricing();
  log({ step: "Tarifs", status: "ok", detail: `${p.inserted} ajoutée(s), ${p.total - p.inserted} déjà présente(s)` });

  const { seedRegistry } = await import("@/server/registry/seed");
  const r = await seedRegistry();
  log({ step: "Registre des traitements", status: "ok", detail: `${r.inserted} ajouté(s) sur ${r.total}` });

  // Modèles de documents (équipe documents).
  const templates = await optionalImport("@/server/documents/templates-seed");
  if (!templates) log({ step: "Modèles de documents", status: "missing", detail: "@/server/documents/templates-seed introuvable" });
  else if (typeof templates.seedDocumentTemplates !== "function") log({ step: "Modèles de documents", status: "missing", detail: "seedDocumentTemplates() non exportée" });
  else {
    const res = await (templates.seedDocumentTemplates as () => Promise<unknown>)();
    log({ step: "Modèles de documents", status: "ok", detail: res === undefined ? undefined : JSON.stringify(res) });
  }

  // Règles de paie (équipe paie) : premier module trouvé exposant syncRuleSets() ou une fonction seed*/sync*.
  const candidates = ["@/server/payroll/rule-sets-db", "@/server/payroll/rules-seed", "@/server/payroll/seed", "@/server/payroll/rules/seed", "@/server/payroll/rules", "@/server/payroll/rule-sets", "@/server/payroll"];
  let payrollDone = false;
  for (const spec of candidates) {
    const mod = await optionalImport(spec);
    if (!mod) continue;
    const name = ["syncRuleSets", "seedPayrollRules", "seedPayrollRuleSets", "seedRuleSets", "seedRules", "loadRuleSets"].find((n) => typeof mod[n] === "function") ?? Object.keys(mod).find((k) => /^(seed|sync)/i.test(k) && typeof mod[k] === "function");
    if (!name) continue;
    const res = await (mod[name] as () => Promise<unknown>)();
    log({ step: "Règles de paie", status: "ok", detail: `${spec} → ${name}()${res === undefined ? "" : ` ${JSON.stringify(res)}`}` });
    payrollDone = true;
    break;
  }
  if (!payrollDone) log({ step: "Règles de paie", status: "missing", detail: `aucune fonction seed* ou sync* trouvée dans ${candidates.join(", ")}` });

  await pool.end();
  const errors = report.filter((s) => s.status === "error");
  if (errors.length) process.exitCode = 1;
}

main().catch((e) => {
  log({ step: "Initialisation", status: "error", detail: e instanceof Error ? e.message : String(e) });
  console.error(e);
  process.exit(1);
});
