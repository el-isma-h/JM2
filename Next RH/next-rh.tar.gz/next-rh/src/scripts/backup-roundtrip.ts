/**
 * Vérification de bout en bout : seedDemo() → sauvegarde → restauration vers un nouveau tenant → comparaison
 * des comptes de lignes table par table, puis suppression des deux tenants de test.
 *   npx tsx --conditions=react-server src/scripts/backup-roundtrip.ts
 * Code de sortie 0 si tout concorde.
 */
import path from "node:path";
import { existsSync } from "node:fs";

try {
  if (existsSync(path.resolve(process.cwd(), ".env"))) process.loadEnvFile(path.resolve(process.cwd(), ".env"));
} catch {}

async function main() {
  const { pool } = await import("@/db");
  const { seedDemo } = await import("@/server/demo/seed");
  const { backupTenant, exportTenant, readBackup, restoreTenant } = await import("@/server/backup");
  const { purgeTenant } = await import("@/server/backup/purge");

  const t0 = Date.now();
  const demo = await seedDemo();
  console.log(`seedDemo : tenant ${demo.tenantId} (${Date.now() - t0} ms)`);

  // Un document avec fichier, pour vérifier que les fichiers de stockage suivent la sauvegarde.
  const { createDocument, readDocument } = await import("@/server/documents/store");
  const fileContent = Buffer.from(`Attestation fictive ${Date.now()}`, "utf8");
  await createDocument({ companyId: demo.companyId, category: "attestation", title: "Attestation de test", fileName: "attestation.txt", mimeType: "text/plain", data: fileContent, isDemo: true });

  const b = await backupTenant(demo.tenantId, null);
  console.log(`Sauvegarde : ${b.storageKey}, ${b.sizeBytes} octets, sha256 ${b.sha256}`);
  await readBackup(b.backupId);
  console.log("Empreinte sha256 relue et vérifiée.");

  const restored = await restoreTenant(b.backupId);
  console.log(`Restauration : nouveau tenant ${restored.tenantId} « ${restored.tenantName} »`);

  const again = await exportTenant(restored.tenantId);
  let mismatches = 0;
  const rows: string[] = [];
  for (const [table, n] of Object.entries(b.counts)) {
    // Le journal d'audit du tenant restauré peut contenir des entrées postérieures : on compare les lignes copiées.
    const got = table === "audit_logs" ? restored.counts[table] : again.counts[table];
    const ok = got === n;
    if (!ok) mismatches++;
    if (n > 0 || !ok) rows.push(`${ok ? "=" : "≠"} ${table.padEnd(26)} ${String(n).padStart(4)} → ${String(got).padStart(4)}`);
  }
  console.log(rows.join("\n"));

  // Aucun identifiant d'origine ne doit subsister dans la copie (hors utilisateurs, qui ne sont pas dupliqués).
  const originalIds = new Set<string>();
  const original = await exportTenant(demo.tenantId);
  for (const list of Object.values(original.tables)) for (const r of list) if (typeof r.id === "string") originalIds.add(r.id);
  // Recherche profonde : colonnes de référence (manager_id, source_id…) et JSON compris.
  let leaked = 0;
  const scan = (v: unknown): void => {
    if (typeof v === "string") {
      if (originalIds.has(v)) leaked++;
    } else if (Array.isArray(v)) v.forEach(scan);
    else if (v && typeof v === "object") Object.values(v).forEach(scan);
  };
  // Exception attendue : tenants.settings.restoredFrom garde l'identifiant du tenant source (traçabilité).
  for (const [table, list] of Object.entries(again.tables)) {
    for (const r of list) scan(table === "tenants" ? { ...r, settings: { ...(r.settings as object), restoredFrom: null } } : r);
  }
  console.log(`Identifiants d'origine présents dans la copie (recherche profonde) : ${leaked}`);

  const { db: db0, schema: s0 } = await import("@/db");
  const { eq: eq0 } = await import("drizzle-orm");
  const [restoredCompany] = await db0.select().from(s0.companies).where(eq0(s0.companies.tenantId, restored.tenantId));
  const [restoredDoc] = await db0.select().from(s0.documents).where(eq0(s0.documents.companyId, restoredCompany.id));
  const restoredFile = restoredDoc ? await readDocument(restoredDoc.id) : null;
  const fileOk = Boolean(restoredFile && restoredFile.data.equals(fileContent) && restoredDoc.storageKey.startsWith(restoredCompany.id));
  console.log(`Fichier de stockage restauré sous la nouvelle clé : ${fileOk ? "oui" : "NON"} (${restoredDoc?.storageKey})`);
  if (!fileOk) leaked++;

  // Altération : la restauration doit refuser une empreinte différente.
  const { db, schema } = await import("@/db");
  const { eq } = await import("drizzle-orm");
  await db.update(schema.backups).set({ sha256: "0".repeat(64) }).where(eq(schema.backups.id, b.backupId));
  let rejected = false;
  try {
    await restoreTenant(b.backupId);
  } catch (e) {
    rejected = /sha256/.test(String(e));
  }
  console.log(`Sauvegarde altérée refusée : ${rejected ? "oui" : "NON"}`);

  await purgeTenant(restored.tenantId);
  await purgeTenant(demo.tenantId);
  console.log("Tenants de test supprimés.");
  await pool.end();

  const total = Object.values(b.counts).reduce((a, x) => a + x, 0);
  if (mismatches || leaked || !rejected) {
    console.error(`ÉCHEC : ${mismatches} table(s) divergente(s), ${leaked} identifiant(s) non remappé(s), altération ${rejected ? "détectée" : "non détectée"}.`);
    process.exit(1);
  }
  console.log(`SUCCÈS : ${total} lignes sur ${Object.keys(b.counts).length} tables restaurées à l'identique, identifiants remappés.`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
