import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { companies, establishments, timestamps } from "./tenancy";
import { users } from "./auth";

export const employeeStatusEnum = pgEnum("employee_status", ["draft", "active", "suspended", "left"]);
export const genderEnum = pgEnum("gender", ["F", "M", "X"]);

export const employees = pgTable(
  "employees",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    establishmentId: uuid("establishment_id").references(() => establishments.id, { onDelete: "set null" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    managerId: uuid("manager_id"),
    employeeNumber: text("employee_number"),
    status: employeeStatusEnum("status").notNull().default("draft"),
    // Identité
    civility: text("civility"),
    firstName: text("first_name").notNull(),
    lastName: text("last_name").notNull(),
    birthName: text("birth_name"),
    gender: genderEnum("gender"),
    birthDate: date("birth_date"),
    birthPlace: text("birth_place"),
    birthCountry: text("birth_country"),
    nationality: text("nationality"),
    /** NIR chiffré (AES-GCM) — jamais en clair. */
    nirEnc: text("nir_enc"),
    // Coordonnées
    email: text("email"),
    personalEmail: text("personal_email"),
    phone: text("phone"),
    addressLine1: text("address_line1"),
    addressLine2: text("address_line2"),
    postalCode: text("postal_code"),
    city: text("city"),
    country: text("country").notNull().default("FR"),
    // Poste
    jobTitle: text("job_title"),
    department: text("department"),
    hireDate: date("hire_date"),
    leaveDate: date("leave_date"),
    leaveReason: text("leave_reason"),
    /** Champs personnalisés définis par l'entreprise. */
    customFields: jsonb("custom_fields").notNull().default(sql`'{}'::jsonb`),
    photoKey: text("photo_key"),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [
    index("employees_company_idx").on(t.companyId, t.status),
    index("employees_establishment_idx").on(t.establishmentId),
    index("employees_user_idx").on(t.userId),
    index("employees_name_idx").on(t.companyId, t.lastName, t.firstName),
    uniqueIndex("employees_number_unique").on(t.companyId, t.employeeNumber),
  ],
);

/** Coordonnées bancaires : table séparée, accès restreint (permission canSeeBank + TOTP). */
export const employeeBankAccounts = pgTable(
  "employee_bank_accounts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    holderName: text("holder_name").notNull(),
    ibanEnc: text("iban_enc").notNull(),
    ibanLast4: text("iban_last4").notNull(),
    bic: text("bic"),
    bankName: text("bank_name"),
    isPrimary: boolean("is_primary").notNull().default(true),
    validFrom: date("valid_from"),
    ...timestamps,
  },
  (t) => [index("employee_bank_employee_idx").on(t.employeeId)],
);

export const contractTypeEnum = pgEnum("contract_type", [
  "CDI",
  "CDD",
  "APPRENTISSAGE",
  "PROFESSIONNALISATION",
  "STAGE",
  "INTERIM",
  "MANDAT",
]);
export const workTimeModeEnum = pgEnum("work_time_mode", ["heures", "forfait_jours", "forfait_heures"]);
export const employeeCategoryEnum = pgEnum("employee_category", [
  "non_cadre",
  "cadre",
  "cadre_dirigeant",
  "apprenti",
  "stagiaire",
]);

export const contracts = pgTable(
  "contracts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    type: contractTypeEnum("type").notNull().default("CDI"),
    category: employeeCategoryEnum("category").notNull().default("non_cadre"),
    startDate: date("start_date").notNull(),
    endDate: date("end_date"),
    trialEndDate: date("trial_end_date"),
    trialRenewedUntil: date("trial_renewed_until"),
    jobTitle: text("job_title"),
    classification: text("classification"),
    coefficient: text("coefficient"),
    workTimeMode: workTimeModeEnum("work_time_mode").notNull().default("heures"),
    /** Heures hebdomadaires contractuelles (ex. 35.00). */
    weeklyHours: numeric("weekly_hours", { precision: 6, scale: 2 }).notNull().default("35.00"),
    /** Heures mensuelles (151.67 pour 35h). */
    monthlyHours: numeric("monthly_hours", { precision: 7, scale: 2 }).notNull().default("151.67"),
    annualDays: integer("annual_days"),
    isPartTime: boolean("is_part_time").notNull().default(false),
    isExecutive: boolean("is_executive").notNull().default(false),
    cddReason: text("cdd_reason"),
    notes: text("notes"),
    ...timestamps,
  },
  (t) => [index("contracts_employee_idx").on(t.employeeId, t.startDate)],
);

export const amendments = pgTable(
  "contract_amendments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    contractId: uuid("contract_id")
      .notNull()
      .references(() => contracts.id, { onDelete: "cascade" }),
    effectiveDate: date("effective_date").notNull(),
    subject: text("subject").notNull(),
    changes: jsonb("changes").notNull().default(sql`'{}'::jsonb`),
    documentId: uuid("document_id"),
    ...timestamps,
  },
  (t) => [index("amendments_contract_idx").on(t.contractId, t.effectiveDate)],
);

/** Rémunération datée : chaque changement est une nouvelle ligne avec date d'effet (traçabilité paie). */
export const salaryBasisEnum = pgEnum("salary_basis", ["monthly", "hourly", "annual"]);

export const compensations = pgTable(
  "compensations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    contractId: uuid("contract_id").references(() => contracts.id, { onDelete: "set null" }),
    effectiveDate: date("effective_date").notNull(),
    endDate: date("end_date"),
    basis: salaryBasisEnum("basis").notNull().default("monthly"),
    /** Montant brut en centimes. */
    grossAmountCents: integer("gross_amount_cents").notNull(),
    currency: text("currency").notNull().default("EUR"),
    reason: text("reason"),
    createdBy: uuid("created_by"),
    ...timestamps,
  },
  (t) => [index("compensations_employee_idx").on(t.employeeId, t.effectiveDate)],
);

/** Événements administratifs du salarié (entrée, changement de poste, sortie, …), datés et traçables. */
export const employeeEvents = pgTable(
  "employee_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(),
    effectiveDate: date("effective_date").notNull(),
    title: text("title").notNull(),
    details: jsonb("details").notNull().default(sql`'{}'::jsonb`),
    affectsPayroll: boolean("affects_payroll").notNull().default(false),
    payrollProcessedPeriodId: uuid("payroll_processed_period_id"),
    createdBy: uuid("created_by"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("employee_events_employee_idx").on(t.employeeId, t.effectiveDate)],
);

/** Cumuls de reprise (reprise en cours d'année) : bruts, nets imposables, PAS, congés acquis… */
export const employeeCarryovers = pgTable(
  "employee_carryovers",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    year: integer("year").notNull(),
    throughMonth: integer("through_month").notNull(),
    grossYtdCents: integer("gross_ytd_cents").notNull().default(0),
    netTaxableYtdCents: integer("net_taxable_ytd_cents").notNull().default(0),
    netPaidYtdCents: integer("net_paid_ytd_cents").notNull().default(0),
    pasYtdCents: integer("pas_ytd_cents").notNull().default(0),
    employeeContribYtdCents: integer("employee_contrib_ytd_cents").notNull().default(0),
    employerContribYtdCents: integer("employer_contrib_ytd_cents").notNull().default(0),
    hoursYtd: numeric("hours_ytd", { precision: 9, scale: 2 }).notNull().default("0"),
    paidLeaveAcquired: numeric("paid_leave_acquired", { precision: 6, scale: 2 }).notNull().default("0"),
    paidLeaveTaken: numeric("paid_leave_taken", { precision: 6, scale: 2 }).notNull().default("0"),
    paidLeavePrevBalance: numeric("paid_leave_prev_balance", { precision: 6, scale: 2 }).notNull().default("0"),
    source: text("source"),
    confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
    confirmedBy: uuid("confirmed_by"),
    ...timestamps,
  },
  (t) => [uniqueIndex("employee_carryovers_unique").on(t.employeeId, t.year)],
);
