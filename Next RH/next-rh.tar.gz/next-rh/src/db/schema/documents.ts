import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { companies, timestamps } from "./tenancy";
import { employees } from "./employees";

export const documentCategoryEnum = pgEnum("document_category", [
  "bulletin",
  "contrat",
  "avenant",
  "attestation",
  "courrier",
  "justificatif",
  "identite",
  "kbis",
  "entreprise",
  "fiche_poste",
  "offre_emploi",
  "convocation",
  "compte_rendu",
  "note_interne",
  "procedure",
  "export",
  "autre",
]);

export const documentVisibilityEnum = pgEnum("document_visibility", ["company", "employee", "restricted"]);

/** Fichiers stockés (clé de stockage privée ; téléchargement via lien temporaire signé). */
export const documents = pgTable(
  "documents",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    employeeId: uuid("employee_id").references(() => employees.id, { onDelete: "cascade" }),
    category: documentCategoryEnum("category").notNull().default("autre"),
    visibility: documentVisibilityEnum("visibility").notNull().default("company"),
    title: text("title").notNull(),
    fileName: text("file_name").notNull(),
    mimeType: text("mime_type").notNull(),
    sizeBytes: integer("size_bytes").notNull().default(0),
    storageKey: text("storage_key").notNull(),
    sha256: text("sha256"),
    version: integer("version").notNull().default(1),
    previousVersionId: uuid("previous_version_id"),
    /** Période de paie / entité d'origine. */
    sourceType: text("source_type"),
    sourceId: uuid("source_id"),
    retentionUntil: timestamp("retention_until", { withTimezone: true }),
    uploadedBy: uuid("uploaded_by"),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [
    index("documents_company_idx").on(t.companyId, t.category),
    index("documents_employee_idx").on(t.employeeId),
    index("documents_source_idx").on(t.sourceType, t.sourceId),
  ],
);

/** Modèles de documents (vérifiés) : contrat CDI, attestation employeur, … avec variables. */
export const documentTemplates = pgTable(
  "document_templates",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    /** null = modèle plateforme (commun) ; sinon modèle propre à l'entreprise. */
    companyId: uuid("company_id").references(() => companies.id, { onDelete: "cascade" }),
    code: text("code").notNull(),
    category: documentCategoryEnum("category").notNull(),
    title: text("title").notNull(),
    description: text("description"),
    /** Corps en Markdown avec variables {{employee.firstName}} et sections conditionnelles. */
    body: text("body").notNull(),
    /** Questions à poser avant génération : [{key,label,type,required,help}] */
    questions: jsonb("questions").notNull().default(sql`'[]'::jsonb`),
    /** Points nécessitant une validation compétente (juridique). */
    legalReviewPoints: jsonb("legal_review_points").notNull().default(sql`'[]'::jsonb`),
    isLegal: boolean("is_legal").notNull().default(false),
    version: integer("version").notNull().default(1),
    verifiedAt: timestamp("verified_at", { withTimezone: true }),
    verifiedNote: text("verified_note"),
    ...timestamps,
  },
  (t) => [index("document_templates_company_idx").on(t.companyId, t.category)],
);

export const draftStatusEnum = pgEnum("draft_status", [
  "questions",
  "drafted",
  "in_review",
  "validated",
  "exported",
  "signed",
  "archived",
]);

/** Brouillons de l'atelier de rédaction. */
export const documentDrafts = pgTable(
  "document_drafts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    employeeId: uuid("employee_id").references(() => employees.id, { onDelete: "set null" }),
    templateId: uuid("template_id").references(() => documentTemplates.id, { onDelete: "set null" }),
    category: documentCategoryEnum("category").notNull(),
    title: text("title").notNull(),
    status: draftStatusEnum("status").notNull().default("questions"),
    answers: jsonb("answers").notNull().default(sql`'{}'::jsonb`),
    missing: jsonb("missing").notNull().default(sql`'[]'::jsonb`),
    body: text("body").notNull().default(""),
    /** Historique des versions : [{version, body, at, by}] */
    versions: jsonb("versions").notNull().default(sql`'[]'::jsonb`),
    reviewers: jsonb("reviewers").notNull().default(sql`'[]'::jsonb`),
    validatedBy: uuid("validated_by"),
    validatedAt: timestamp("validated_at", { withTimezone: true }),
    pdfDocumentId: uuid("pdf_document_id"),
    docxDocumentId: uuid("docx_document_id"),
    createdBy: uuid("created_by"),
    ...timestamps,
  },
  (t) => [index("document_drafts_company_idx").on(t.companyId, t.status)],
);

export const signatureStatusEnum = pgEnum("signature_status", [
  "not_configured",
  "requested",
  "sent",
  "signed",
  "declined",
  "expired",
]);

export const signatureRequests = pgTable(
  "signature_requests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    documentId: uuid("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    provider: text("provider"),
    providerRef: text("provider_ref"),
    status: signatureStatusEnum("status").notNull().default("not_configured"),
    signers: jsonb("signers").notNull().default(sql`'[]'::jsonb`),
    proof: jsonb("proof"),
    requestedBy: uuid("requested_by"),
    ...timestamps,
  },
  (t) => [index("signature_requests_document_idx").on(t.documentId)],
);
