import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export const timestamps = {
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
};

/** Un tenant = une entreprise seule, ou un cabinet / groupe gérant plusieurs entreprises. */
export const tenantKindEnum = pgEnum("tenant_kind", ["company", "firm", "group"]);

export const tenants = pgTable("tenants", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  kind: tenantKindEnum("kind").notNull().default("company"),
  slug: text("slug").notNull().unique(),
  isDemo: boolean("is_demo").notNull().default(false),
  settings: jsonb("settings").notNull().default(sql`'{}'::jsonb`),
  ...timestamps,
});

export const legalFormEnum = pgEnum("legal_form", [
  "SAS",
  "SASU",
  "SARL",
  "EURL",
  "SA",
  "SCI",
  "SNC",
  "EI",
  "ASSOCIATION",
  "AUTRE",
]);

export const companies = pgTable(
  "companies",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    legalName: text("legal_name").notNull(),
    tradeName: text("trade_name"),
    siren: text("siren"),
    legalForm: legalFormEnum("legal_form"),
    apeCode: text("ape_code"),
    activity: text("activity"),
    idcc: text("idcc"),
    collectiveAgreement: text("collective_agreement"),
    idccConfirmed: boolean("idcc_confirmed").notNull().default(false),
    headcount: integer("headcount"),
    addressLine1: text("address_line1"),
    addressLine2: text("address_line2"),
    postalCode: text("postal_code"),
    city: text("city"),
    country: text("country").notNull().default("FR"),
    /** Paramètres de paie confirmés lors de l'onboarding. */
    payrollSettings: jsonb("payroll_settings").notNull().default(sql`'{}'::jsonb`),
    onboardingStep: text("onboarding_step").notNull().default("company"),
    onboardingCompletedAt: timestamp("onboarding_completed_at", { withTimezone: true }),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [index("companies_tenant_idx").on(t.tenantId), index("companies_siren_idx").on(t.siren)],
);

export const establishments = pgTable(
  "establishments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    siret: text("siret"),
    nic: text("nic"),
    isHeadOffice: boolean("is_head_office").notNull().default(false),
    addressLine1: text("address_line1"),
    postalCode: text("postal_code"),
    city: text("city"),
    urssafCode: text("urssaf_code"),
    ...timestamps,
  },
  (t) => [index("establishments_company_idx").on(t.companyId)],
);

export const contactRoleEnum = pgEnum("contact_role", [
  "dirigeant",
  "rh",
  "paie",
  "comptable",
  "informatique",
  "autre",
]);

export const companyContacts = pgTable(
  "company_contacts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    fullName: text("full_name").notNull(),
    role: contactRoleEnum("role").notNull().default("autre"),
    email: text("email"),
    phone: text("phone"),
    ...timestamps,
  },
  (t) => [index("company_contacts_company_idx").on(t.companyId)],
);

/** Organismes sociaux, mutuelle, prévoyance, caisse de retraite… rattachés à une entreprise. */
export const organismKindEnum = pgEnum("organism_kind", [
  "urssaf",
  "retraite",
  "mutuelle",
  "prevoyance",
  "medecine_travail",
  "formation",
  "autre",
]);

export const companyOrganisms = pgTable(
  "company_organisms",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    kind: organismKindEnum("kind").notNull(),
    name: text("name").notNull(),
    reference: text("reference"),
    contractNumber: text("contract_number"),
    notes: text("notes"),
    ...timestamps,
  },
  (t) => [index("company_organisms_company_idx").on(t.companyId)],
);

/** Affectation d'un gestionnaire (user) à une entreprise, avec son rôle dans cette entreprise. */
export const companyRoleEnum = pgEnum("company_role", [
  "owner",
  "admin",
  "hr",
  "payroll",
  "manager",
  "accountant",
  "employee",
  "viewer",
]);

export const companyMemberships = pgTable(
  "company_memberships",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    userId: uuid("user_id").notNull(),
    role: companyRoleEnum("role").notNull().default("viewer"),
    /** Habilitations fines (ex. canValidatePayroll, canSeeBank, canSeeSalaries). */
    permissions: jsonb("permissions").notNull().default(sql`'{}'::jsonb`),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("company_memberships_unique").on(t.companyId, t.userId),
    index("company_memberships_user_idx").on(t.userId),
  ],
);
