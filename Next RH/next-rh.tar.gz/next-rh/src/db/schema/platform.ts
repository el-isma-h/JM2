import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { companies, tenants, timestamps } from "./tenancy";
import { users } from "./auth";

// ---------- Tarifs administrables ----------

export const pricingUnitEnum = pgEnum("pricing_unit", [
  "par_salarie_mois",
  "par_declarant_mois",
  "par_document",
  "par_facture",
  "forfait_mois",
  "sur_devis",
  "inclus",
]);

export const pricingPlans = pgTable(
  "pricing_plans",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    code: text("code").notNull().unique(),
    name: text("name").notNull(),
    description: text("description"),
    /** Fonction incluse (logiciel) vs service d'accompagnement humain. */
    isService: boolean("is_service").notNull().default(false),
    unit: pricingUnitEnum("unit").notNull(),
    /** Prix Next RH en centimes HT ; null si « Sur devis ». */
    priceCents: integer("price_cents"),
    /** Prix de référence public en centimes HT ; null si inexistant. */
    referencePriceCents: integer("reference_price_cents"),
    referenceLabel: text("reference_label"),
    referenceUrl: text("reference_url"),
    referenceCheckedAt: date("reference_checked_at"),
    discountRate: integer("discount_rate_bp").notNull().default(1000),
    calculationNote: text("calculation_note"),
    isActive: boolean("is_active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    ...timestamps,
  },
  (t) => [index("pricing_plans_active_idx").on(t.isActive, t.sortOrder)],
);

/** Modules activés par entreprise (abonnement). */
export const subscriptions = pgTable(
  "subscriptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    planCode: text("plan_code").notNull(),
    status: text("status").notNull().default("active"),
    billingCycle: text("billing_cycle").notNull().default("monthly"),
    startedAt: date("started_at").notNull().defaultNow(),
    endedAt: date("ended_at"),
    ...timestamps,
  },
  (t) => [index("subscriptions_company_idx").on(t.companyId)],
);

// ---------- Assistant IA ----------

export const assistantConversations = pgTable(
  "assistant_conversations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    companyId: uuid("company_id").references(() => companies.id, { onDelete: "cascade" }),
    title: text("title"),
    ...timestamps,
  },
  (t) => [index("assistant_conversations_user_idx").on(t.userId, t.updatedAt)],
);

export const assistantRoleEnum = pgEnum("assistant_role", ["user", "assistant", "tool"]);

export const assistantMessages = pgTable(
  "assistant_messages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => assistantConversations.id, { onDelete: "cascade" }),
    role: assistantRoleEnum("role").notNull(),
    content: text("content").notNull(),
    /** Plan proposé, outils appelés, validations demandées. */
    meta: jsonb("meta").notNull().default(sql`'{}'::jsonb`),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("assistant_messages_conversation_idx").on(t.conversationId, t.createdAt)],
);

// ---------- Imports ----------

export const importStatusEnum = pgEnum("import_status", ["uploaded", "mapped", "validated", "applied", "failed"]);

export const dataImports = pgTable(
  "data_imports",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(),
    fileName: text("file_name").notNull(),
    status: importStatusEnum("status").notNull().default("uploaded"),
    /** Entêtes détectées, aperçu des premières lignes. */
    preview: jsonb("preview").notNull().default(sql`'{}'::jsonb`),
    mapping: jsonb("mapping").notNull().default(sql`'{}'::jsonb`),
    rows: jsonb("rows").notNull().default(sql`'[]'::jsonb`),
    errors: jsonb("errors").notNull().default(sql`'[]'::jsonb`),
    duplicates: jsonb("duplicates").notNull().default(sql`'[]'::jsonb`),
    appliedCount: integer("applied_count").notNull().default(0),
    createdBy: uuid("created_by"),
    appliedAt: timestamp("applied_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [index("data_imports_company_idx").on(t.companyId, t.createdAt)],
);

// ---------- Sauvegardes ----------

export const backups = pgTable(
  "backups",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").references(() => tenants.id, { onDelete: "cascade" }),
    scope: text("scope").notNull().default("tenant"),
    storageKey: text("storage_key").notNull(),
    sizeBytes: integer("size_bytes").notNull().default(0),
    sha256: text("sha256"),
    status: text("status").notNull().default("done"),
    createdBy: uuid("created_by"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("backups_tenant_idx").on(t.tenantId, t.createdAt)],
);

/** Registre des traitements et sous-traitants (RGPD). */
export const processingRegistry = pgTable("processing_registry", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  purpose: text("purpose").notNull(),
  dataCategories: jsonb("data_categories").notNull().default(sql`'[]'::jsonb`),
  processor: text("processor"),
  location: text("location"),
  retention: text("retention").notNull(),
  legalBasis: text("legal_basis").notNull(),
  ...timestamps,
});
