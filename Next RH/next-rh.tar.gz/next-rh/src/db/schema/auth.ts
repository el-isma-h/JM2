import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  inet,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { tenants, timestamps } from "./tenancy";

export const platformRoleEnum = pgEnum("platform_role", ["user", "platform_admin"]);

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email").notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    firstName: text("first_name").notNull(),
    lastName: text("last_name").notNull(),
    platformRole: platformRoleEnum("platform_role").notNull().default("user"),
    /** Tenant principal ; un cabinet peut aussi recevoir des accès par entreprise via company_memberships. */
    tenantId: uuid("tenant_id").references(() => tenants.id, { onDelete: "set null" }),
    emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
    /** Secret TOTP chiffré (AES-256-GCM, clé dérivée d'APP_SECRET). */
    totpSecretEnc: text("totp_secret_enc"),
    totpEnabledAt: timestamp("totp_enabled_at", { withTimezone: true }),
    recoveryCodesHash: jsonb("recovery_codes_hash").notNull().default(sql`'[]'::jsonb`),
    locale: text("locale").notNull().default("fr"),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    disabledAt: timestamp("disabled_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [index("users_tenant_idx").on(t.tenantId)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull().unique(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    /** Horodatage de la dernière vérification TOTP (accès sensibles : RIB, salaires, exports). */
    elevatedUntil: timestamp("elevated_until", { withTimezone: true }),
    ip: inet("ip"),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const tokenPurposeEnum = pgEnum("token_purpose", [
  "verify_email",
  "reset_password",
  "invite",
  "download",
]);

export const oneTimeTokens = pgTable(
  "one_time_tokens",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    purpose: tokenPurposeEnum("purpose").notNull(),
    tokenHash: text("token_hash").notNull().unique(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
    email: text("email"),
    payload: jsonb("payload").notNull().default(sql`'{}'::jsonb`),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("one_time_tokens_purpose_idx").on(t.purpose, t.expiresAt)],
);

export const invitationStatusEnum = pgEnum("invitation_status", ["pending", "accepted", "revoked", "expired"]);

export const invitations = pgTable(
  "invitations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    companyId: uuid("company_id"),
    email: text("email").notNull(),
    role: text("role").notNull().default("viewer"),
    employeeId: uuid("employee_id"),
    invitedBy: uuid("invited_by").references(() => users.id, { onDelete: "set null" }),
    status: invitationStatusEnum("status").notNull().default("pending"),
    tokenHash: text("token_hash").notNull().unique(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    acceptedAt: timestamp("accepted_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [index("invitations_tenant_idx").on(t.tenantId), index("invitations_email_idx").on(t.email)],
);

/** Journal d'audit : toute action sensible, lue ou écrite. */
export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id"),
    companyId: uuid("company_id"),
    userId: uuid("user_id"),
    action: text("action").notNull(),
    entityType: text("entity_type"),
    entityId: uuid("entity_id"),
    before: jsonb("before"),
    after: jsonb("after"),
    ip: inet("ip"),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("audit_logs_company_idx").on(t.companyId, t.createdAt),
    index("audit_logs_user_idx").on(t.userId, t.createdAt),
    index("audit_logs_entity_idx").on(t.entityType, t.entityId),
  ],
);

/** Boîte d'envoi e-mail : chaque e-mail est journalisé ; envoyé par Resend si configuré. */
export const mailStatusEnum = pgEnum("mail_status", ["queued", "sent", "failed", "skipped_not_configured"]);

export const mailOutbox = pgTable(
  "mail_outbox",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    to: text("to").notNull(),
    subject: text("subject").notNull(),
    html: text("html").notNull(),
    text: text("text"),
    status: mailStatusEnum("status").notNull().default("queued"),
    providerId: text("provider_id"),
    error: text("error"),
    isDemo: boolean("is_demo").notNull().default(false),
    sentAt: timestamp("sent_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("mail_outbox_status_idx").on(t.status, t.createdAt)],
);

/** Tâches en arrière-plan (imports, génération PDF, sauvegardes, rappels). */
export const jobStatusEnum = pgEnum("job_status", ["queued", "running", "done", "failed"]);

export const jobs = pgTable(
  "jobs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    kind: text("kind").notNull(),
    payload: jsonb("payload").notNull().default(sql`'{}'::jsonb`),
    status: jobStatusEnum("status").notNull().default("queued"),
    attempts: text("attempts").notNull().default("0"),
    result: jsonb("result"),
    error: text("error"),
    tenantId: uuid("tenant_id"),
    companyId: uuid("company_id"),
    runAfter: timestamp("run_after", { withTimezone: true }).notNull().defaultNow(),
    startedAt: timestamp("started_at", { withTimezone: true }),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("jobs_status_idx").on(t.status, t.runAfter)],
);
