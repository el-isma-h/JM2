import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { companies, timestamps } from "./tenancy";
import { employees } from "./employees";

// ---------- Congés et absences ----------

export const leaveTypes = pgTable(
  "leave_types",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    code: text("code").notNull(),
    label: text("label").notNull(),
    isPaid: boolean("is_paid").notNull().default(true),
    affectsPayroll: boolean("affects_payroll").notNull().default(true),
    requiresProof: boolean("requires_proof").notNull().default(false),
    /** Unité : jours ouvrés, ouvrables, calendaires, heures. */
    unit: text("unit").notNull().default("jours_ouvres"),
    /** Acquisition mensuelle (ex. 2.08 CP) ; null = pas de solde. */
    monthlyAccrual: numeric("monthly_accrual", { precision: 6, scale: 2 }),
    color: text("color"),
    sortOrder: integer("sort_order").notNull().default(0),
    ...timestamps,
  },
  (t) => [uniqueIndex("leave_types_unique").on(t.companyId, t.code)],
);

export const leaveBalances = pgTable(
  "leave_balances",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    leaveTypeId: uuid("leave_type_id")
      .notNull()
      .references(() => leaveTypes.id, { onDelete: "cascade" }),
    /** Période de référence (ex. 2026-06-01 → 2027-05-31 pour les CP). */
    periodStart: date("period_start").notNull(),
    periodEnd: date("period_end").notNull(),
    acquired: numeric("acquired", { precision: 7, scale: 2 }).notNull().default("0"),
    taken: numeric("taken", { precision: 7, scale: 2 }).notNull().default("0"),
    pending: numeric("pending", { precision: 7, scale: 2 }).notNull().default("0"),
    adjustment: numeric("adjustment", { precision: 7, scale: 2 }).notNull().default("0"),
    ...timestamps,
  },
  (t) => [uniqueIndex("leave_balances_unique").on(t.employeeId, t.leaveTypeId, t.periodStart)],
);

export const requestStatusEnum = pgEnum("request_status", ["draft", "pending", "approved", "rejected", "cancelled"]);

export const leaveRequests = pgTable(
  "leave_requests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    leaveTypeId: uuid("leave_type_id")
      .notNull()
      .references(() => leaveTypes.id, { onDelete: "restrict" }),
    startDate: date("start_date").notNull(),
    endDate: date("end_date").notNull(),
    startHalfDay: boolean("start_half_day").notNull().default(false),
    endHalfDay: boolean("end_half_day").notNull().default(false),
    duration: numeric("duration", { precision: 6, scale: 2 }).notNull(),
    status: requestStatusEnum("status").notNull().default("pending"),
    reason: text("reason"),
    proofDocumentId: uuid("proof_document_id"),
    approvedBy: uuid("approved_by"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    decisionNote: text("decision_note"),
    payrollVariableId: uuid("payroll_variable_id"),
    ...timestamps,
  },
  (t) => [index("leave_requests_employee_idx").on(t.employeeId, t.startDate), index("leave_requests_status_idx").on(t.status)],
);

// ---------- Temps de travail ----------

export const timesheets = pgTable(
  "timesheets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    year: integer("year").notNull(),
    month: integer("month").notNull(),
    status: requestStatusEnum("status").notNull().default("draft"),
    /** [{date, hours, overtime, note}] */
    entries: jsonb("entries").notNull().default(sql`'[]'::jsonb`),
    totalHours: numeric("total_hours", { precision: 7, scale: 2 }).notNull().default("0"),
    overtimeHours: numeric("overtime_hours", { precision: 7, scale: 2 }).notNull().default("0"),
    approvedBy: uuid("approved_by"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [uniqueIndex("timesheets_unique").on(t.employeeId, t.year, t.month)],
);

// ---------- Télétravail ----------

export const remoteWorkPolicies = pgTable("remote_work_policies", {
  id: uuid("id").primaryKey().defaultRandom(),
  companyId: uuid("company_id")
    .notNull()
    .references(() => companies.id, { onDelete: "cascade" })
    .unique(),
  maxDaysPerWeek: integer("max_days_per_week").notNull().default(2),
  requiresApproval: boolean("requires_approval").notNull().default(true),
  allowanceCentsPerDay: integer("allowance_cents_per_day").notNull().default(0),
  rules: text("rules"),
  ...timestamps,
});

export const remoteWorkRequests = pgTable(
  "remote_work_requests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    date: date("date").notNull(),
    status: requestStatusEnum("status").notNull().default("pending"),
    approvedBy: uuid("approved_by"),
    ...timestamps,
  },
  (t) => [uniqueIndex("remote_work_unique").on(t.employeeId, t.date)],
);

// ---------- Notes de frais ----------

export const expenseReports = pgTable(
  "expense_reports",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    status: requestStatusEnum("status").notNull().default("draft"),
    totalCents: integer("total_cents").notNull().default(0),
    currency: text("currency").notNull().default("EUR"),
    approvedBy: uuid("approved_by"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    reimbursedInPeriodId: uuid("reimbursed_in_period_id"),
    ...timestamps,
  },
  (t) => [index("expense_reports_employee_idx").on(t.employeeId, t.status)],
);

export const expenseLines = pgTable(
  "expense_lines",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    reportId: uuid("report_id")
      .notNull()
      .references(() => expenseReports.id, { onDelete: "cascade" }),
    date: date("date").notNull(),
    category: text("category").notNull(),
    label: text("label").notNull(),
    amountCents: integer("amount_cents").notNull(),
    vatCents: integer("vat_cents").notNull().default(0),
    receiptDocumentId: uuid("receipt_document_id"),
    ...timestamps,
  },
  (t) => [index("expense_lines_report_idx").on(t.reportId)],
);

// ---------- Cycle de vie : arrivées, départs, tâches ----------

export const workflowKindEnum = pgEnum("workflow_kind", ["onboarding", "offboarding", "mobility", "return"]);

export const lifecycleWorkflows = pgTable(
  "lifecycle_workflows",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    kind: workflowKindEnum("kind").notNull(),
    targetDate: date("target_date").notNull(),
    status: text("status").notNull().default("in_progress"),
    /** [{id,label,owner,done,dueDate,doneAt,doneBy}] */
    tasks: jsonb("tasks").notNull().default(sql`'[]'::jsonb`),
    ...timestamps,
  },
  (t) => [index("lifecycle_workflows_employee_idx").on(t.employeeId)],
);

// ---------- Entretiens ----------

export const interviewKindEnum = pgEnum("interview_kind", [
  "annuel",
  "professionnel",
  "fin_periode_essai",
  "retour_absence",
  "recadrage",
  "autre",
]);

export const interviews = pgTable(
  "interviews",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    kind: interviewKindEnum("kind").notNull(),
    scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
    conductedBy: uuid("conducted_by"),
    status: text("status").notNull().default("planned"),
    objectives: jsonb("objectives").notNull().default(sql`'[]'::jsonb`),
    notes: text("notes"),
    reportDocumentId: uuid("report_document_id"),
    ...timestamps,
  },
  (t) => [index("interviews_employee_idx").on(t.employeeId, t.scheduledAt)],
);

// ---------- Formations et habilitations ----------

export const trainings = pgTable(
  "trainings",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    provider: text("provider"),
    kind: text("kind").notNull().default("formation"),
    startDate: date("start_date"),
    endDate: date("end_date"),
    expiresAt: date("expires_at"),
    costCents: integer("cost_cents").notNull().default(0),
    status: text("status").notNull().default("requested"),
    certificateDocumentId: uuid("certificate_document_id"),
    ...timestamps,
  },
  (t) => [index("trainings_employee_idx").on(t.employeeId), index("trainings_expiry_idx").on(t.expiresAt)],
);

// ---------- Demandes RH ----------

export const hrRequestKindEnum = pgEnum("hr_request_kind", [
  "correction_informations",
  "attestation",
  "justificatif",
  "acompte",
  "question",
  "autre",
]);

export const hrRequests = pgTable(
  "hr_requests",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    employeeId: uuid("employee_id").references(() => employees.id, { onDelete: "cascade" }),
    kind: hrRequestKindEnum("kind").notNull(),
    title: text("title").notNull(),
    body: text("body"),
    payload: jsonb("payload").notNull().default(sql`'{}'::jsonb`),
    status: requestStatusEnum("status").notNull().default("pending"),
    assignedTo: uuid("assigned_to"),
    answer: text("answer"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [index("hr_requests_company_idx").on(t.companyId, t.status)],
);

// ---------- Échéances (périodes d'essai, fins de CDD, visites médicales, habilitations…) ----------

export const deadlines = pgTable(
  "deadlines",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    employeeId: uuid("employee_id").references(() => employees.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(),
    title: text("title").notNull(),
    dueDate: date("due_date").notNull(),
    status: text("status").notNull().default("upcoming"),
    sourceType: text("source_type"),
    sourceId: uuid("source_id"),
    ...timestamps,
  },
  (t) => [index("deadlines_company_idx").on(t.companyId, t.dueDate), uniqueIndex("deadlines_source_unique").on(t.sourceType, t.sourceId, t.kind)],
);
