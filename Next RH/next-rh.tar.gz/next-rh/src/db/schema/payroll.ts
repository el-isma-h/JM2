import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { companies, timestamps } from "./tenancy";
import { employees } from "./employees";

/**
 * Jeux de règles de paie : paramètres légaux datés et versionnés (SMIC, PMSS, taux de cotisations, barème PAS…).
 * Chargés depuis src/server/payroll/rules/*.json ; jamais calculés par un modèle de langage.
 */
export const payrollRuleSets = pgTable(
  "payroll_rule_sets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    version: text("version").notNull().unique(),
    effectiveFrom: date("effective_from").notNull(),
    effectiveTo: date("effective_to"),
    rules: jsonb("rules").notNull(),
    sources: jsonb("sources").notNull().default(sql`'[]'::jsonb`),
    checksum: text("checksum").notNull(),
    publishedAt: timestamp("published_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("payroll_rule_sets_effective_idx").on(t.effectiveFrom)],
);

export const payrollPeriodStatusEnum = pgEnum("payroll_period_status", [
  "open",
  "collecting",
  "checking",
  "computed",
  "controlled",
  "validated",
  "finalized",
  "exported",
  "distributed",
  "closed",
]);

export const payrollPeriods = pgTable(
  "payroll_periods",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    companyId: uuid("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    year: integer("year").notNull(),
    month: integer("month").notNull(),
    status: payrollPeriodStatusEnum("status").notNull().default("open"),
    paymentDate: date("payment_date"),
    ruleSetVersion: text("rule_set_version"),
    computedAt: timestamp("computed_at", { withTimezone: true }),
    validatedAt: timestamp("validated_at", { withTimezone: true }),
    validatedBy: uuid("validated_by"),
    closedAt: timestamp("closed_at", { withTimezone: true }),
    closedBy: uuid("closed_by"),
    /** Résumé : totaux, nombre de bulletins, anomalies ouvertes. */
    summary: jsonb("summary").notNull().default(sql`'{}'::jsonb`),
    ...timestamps,
  },
  (t) => [uniqueIndex("payroll_periods_unique").on(t.companyId, t.year, t.month)],
);

export const variableKindEnum = pgEnum("variable_kind", [
  "prime",
  "commission",
  "heures_sup",
  "heures_comp",
  "absence",
  "avantage_nature",
  "titres_restaurant",
  "indemnite",
  "acompte",
  "saisie",
  "regularisation",
  "autre",
]);
export const variableStatusEnum = pgEnum("variable_status", ["draft", "submitted", "validated", "rejected"]);

export const payrollVariables = pgTable(
  "payroll_variables",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    periodId: uuid("period_id")
      .notNull()
      .references(() => payrollPeriods.id, { onDelete: "cascade" }),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    kind: variableKindEnum("kind").notNull(),
    label: text("label").notNull(),
    /** Quantité (heures, jours) le cas échéant. */
    quantity: numeric("quantity", { precision: 9, scale: 2 }),
    rate: numeric("rate", { precision: 9, scale: 4 }),
    amountCents: integer("amount_cents"),
    status: variableStatusEnum("status").notNull().default("draft"),
    /** Origine : manual, leave:<id>, timesheet:<id>, expense:<id>, import:<id>. */
    source: text("source").notNull().default("manual"),
    sourceId: uuid("source_id"),
    note: text("note"),
    createdBy: uuid("created_by"),
    validatedBy: uuid("validated_by"),
    ...timestamps,
  },
  (t) => [
    index("payroll_variables_period_idx").on(t.periodId, t.employeeId),
    uniqueIndex("payroll_variables_source_unique").on(t.periodId, t.employeeId, t.source, t.sourceId),
  ],
);

export const payslipStatusEnum = pgEnum("payslip_status", [
  "computed",
  "blocked",
  "controlled",
  "validated",
  "finalized",
  "distributed",
]);

export const payslips = pgTable(
  "payslips",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    periodId: uuid("period_id")
      .notNull()
      .references(() => payrollPeriods.id, { onDelete: "cascade" }),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    contractId: uuid("contract_id"),
    status: payslipStatusEnum("status").notNull().default("computed"),
    ruleSetVersion: text("rule_set_version").notNull(),
    /** Entrées du calcul (snapshot reproductible). */
    inputs: jsonb("inputs").notNull(),
    /** Lignes du bulletin : [{code,label,base,rate_employee,amount_employee,rate_employer,amount_employer,kind}]. */
    lines: jsonb("lines").notNull(),
    grossCents: integer("gross_cents").notNull(),
    employeeContribCents: integer("employee_contrib_cents").notNull(),
    employerContribCents: integer("employer_contrib_cents").notNull(),
    netTaxableCents: integer("net_taxable_cents").notNull(),
    netBeforeTaxCents: integer("net_before_tax_cents").notNull(),
    pasRate: numeric("pas_rate", { precision: 5, scale: 2 }).notNull().default("0"),
    pasAmountCents: integer("pas_amount_cents").notNull().default(0),
    netPaidCents: integer("net_paid_cents").notNull(),
    employerCostCents: integer("employer_cost_cents").notNull(),
    hoursWorked: numeric("hours_worked", { precision: 8, scale: 2 }).notNull().default("0"),
    /** Cumuls annuels après ce bulletin. */
    cumulative: jsonb("cumulative").notNull().default(sql`'{}'::jsonb`),
    /** Écarts par rapport au mois précédent, expliqués. */
    variance: jsonb("variance").notNull().default(sql`'{}'::jsonb`),
    anomalies: jsonb("anomalies").notNull().default(sql`'[]'::jsonb`),
    blockingReason: text("blocking_reason"),
    documentId: uuid("document_id"),
    computeHash: text("compute_hash").notNull(),
    distributedAt: timestamp("distributed_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [uniqueIndex("payslips_unique").on(t.periodId, t.employeeId), index("payslips_employee_idx").on(t.employeeId)],
);

export const anomalySeverityEnum = pgEnum("anomaly_severity", ["blocking", "warning", "info"]);
export const anomalyStatusEnum = pgEnum("anomaly_status", ["open", "acknowledged", "resolved", "ignored"]);

export const payrollAnomalies = pgTable(
  "payroll_anomalies",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    periodId: uuid("period_id")
      .notNull()
      .references(() => payrollPeriods.id, { onDelete: "cascade" }),
    employeeId: uuid("employee_id").references(() => employees.id, { onDelete: "cascade" }),
    code: text("code").notNull(),
    severity: anomalySeverityEnum("severity").notNull(),
    status: anomalyStatusEnum("status").notNull().default("open"),
    title: text("title").notNull(),
    explanation: text("explanation").notNull(),
    details: jsonb("details").notNull().default(sql`'{}'::jsonb`),
    resolvedBy: uuid("resolved_by"),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [index("payroll_anomalies_period_idx").on(t.periodId, t.status)],
);

/** Déclarations, exports et paiements : statut explicite, jamais « transmis » sans accusé. */
export const filingKindEnum = pgEnum("filing_kind", [
  "dsn_mensuelle",
  "dsn_evenement",
  "export_comptable",
  "virement_sepa",
  "etat_charges",
  "journal_paie",
  "recap_etablissement",
  "documents_sortie",
]);
export const filingStatusEnum = pgEnum("filing_status", [
  "prepared",
  "controlled",
  "send_requested",
  "sent",
  "accepted",
  "rejected",
]);

export const payrollFilings = pgTable(
  "payroll_filings",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    periodId: uuid("period_id")
      .notNull()
      .references(() => payrollPeriods.id, { onDelete: "cascade" }),
    kind: filingKindEnum("kind").notNull(),
    status: filingStatusEnum("status").notNull().default("prepared"),
    content: jsonb("content").notNull().default(sql`'{}'::jsonb`),
    fileKey: text("file_key"),
    controls: jsonb("controls").notNull().default(sql`'[]'::jsonb`),
    sendRequestedBy: uuid("send_requested_by"),
    sendRequestedAt: timestamp("send_requested_at", { withTimezone: true }),
    sentAt: timestamp("sent_at", { withTimezone: true }),
    acknowledgement: jsonb("acknowledgement"),
    rejectionReason: text("rejection_reason"),
    ...timestamps,
  },
  (t) => [index("payroll_filings_period_idx").on(t.periodId, t.kind)],
);

/** Taux de prélèvement à la source par salarié (reçu via DSN/TOPAze ou saisi), daté. */
export const pasRates = pgTable(
  "pas_rates",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    employeeId: uuid("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    rate: numeric("rate", { precision: 5, scale: 2 }).notNull(),
    kind: text("kind").notNull().default("personnalise"),
    effectiveDate: date("effective_date").notNull(),
    source: text("source"),
    isNeutral: boolean("is_neutral").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("pas_rates_employee_idx").on(t.employeeId, t.effectiveDate)],
);
