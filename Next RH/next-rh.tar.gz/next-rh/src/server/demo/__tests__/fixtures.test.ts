import { describe, expect, it } from "vitest";
import { demoIban, demoSiren, demoSiret, ibanValid, luhnOk, DEMO_SIREN_PREFIX } from "../fixtures";
import { assertNotDemo, DemoBlockedError } from "../guard";

describe("identifiants fictifs de démonstration", () => {
  it("génère des SIREN valides au contrôle de Luhn et préfixés 000", () => {
    for (let i = 0; i < 200; i++) {
      const s = demoSiren();
      expect(s).toMatch(/^000\d{6}$/);
      expect(s.startsWith(DEMO_SIREN_PREFIX)).toBe(true);
      expect(luhnOk(s)).toBe(true);
      const siret = demoSiret(s, "0001");
      expect(siret).toHaveLength(14);
      expect(luhnOk(siret)).toBe(true);
    }
  });

  it("génère des IBAN de test valides au mod 97", () => {
    for (let i = 0; i < 200; i++) {
      const iban = demoIban();
      expect(iban).toMatch(/^FR\d{2}99999\d{18}$/);
      expect(ibanValid(iban)).toBe(true);
    }
    expect(ibanValid("FR7630006000011234567890189")).toBe(true);
    expect(ibanValid("FR7630006000011234567890188")).toBe(false);
  });

  it("bloque les envois réels en démonstration", () => {
    expect(() => assertNotDemo({ isDemo: true }, "declaration")).toThrow(DemoBlockedError);
    expect(() => assertNotDemo({ isDemo: true }, "email")).toThrow(/Démonstration : aucun envoi réel/);
    expect(() => assertNotDemo({ isDemo: false }, "paiement")).not.toThrow();
  });
});
