/**
 * Garde-fou de démonstration : à appeler avant tout envoi réel (déclaration, paiement, e-mail).
 * Module pur, sans dépendance serveur : importable par toutes les équipes.
 *
 *   assertNotDemo(ctx.company, "declaration");
 */

export type DemoGuardedAction = "declaration" | "paiement" | "email" | (string & {});

const labels: Record<string, string> = {
  declaration: "la déclaration n'est pas transmise aux organismes",
  paiement: "aucun virement n'est émis",
  email: "aucun e-mail ne part",
};

export class DemoBlockedError extends Error {
  readonly code = "demo_blocked" as const;
  constructor(public action: DemoGuardedAction) {
    super(`Démonstration : aucun envoi réel. Dans cet espace fictif, ${labels[action] ?? `l'action « ${action} » n'est pas exécutée`}.`);
    this.name = "DemoBlockedError";
  }
}

/** Lève DemoBlockedError si l'entreprise (ou le tenant) est une démonstration. */
export function assertNotDemo(company: { isDemo: boolean } | null | undefined, action: DemoGuardedAction): void {
  if (company?.isDemo) throw new DemoBlockedError(action);
}

export function isDemoBlocked(e: unknown): e is DemoBlockedError {
  return e instanceof DemoBlockedError;
}
