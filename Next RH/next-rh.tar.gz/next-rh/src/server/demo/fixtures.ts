/**
 * Générateurs d'identifiants fictifs pour la démonstration. Module pur, testé.
 * - SIREN : préfixe « 000 » (jamais attribué par l'INSEE), clé de Luhn valide.
 * - IBAN : FR76, banque fictive « 99999 », clé RIB et clé IBAN (mod 97) valides.
 */
import { randomInt } from "node:crypto";

function luhnKey(partial: string): string {
  for (let d = 0; d <= 9; d++) {
    if (luhnOk(partial + d)) return String(d);
  }
  throw new Error("Clé de Luhn introuvable");
}

export function luhnOk(digits: string): boolean {
  let sum = 0;
  let dbl = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = digits.charCodeAt(i) - 48;
    if (dbl) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
    dbl = !dbl;
  }
  return sum % 10 === 0;
}

const digits = (n: number) => Array.from({ length: n }, () => String(randomInt(10))).join("");

export const DEMO_SIREN_PREFIX = "000";

/** SIREN de démonstration : « 000 » + 5 chiffres + clé de Luhn. */
export function demoSiren(): string {
  const base = DEMO_SIREN_PREFIX + digits(5);
  return base + luhnKey(base);
}

/** SIRET : SIREN + NIC (4 chiffres + clé) avec clé de Luhn sur les 14 chiffres. */
export function demoSiret(siren: string, nicPrefix: string): string {
  const base = siren + nicPrefix.padStart(4, "0").slice(0, 4);
  return base + luhnKey(base);
}

/** Reste de la division par 97 d'un grand nombre écrit en chiffres. */
export function mod97(numeric: string): number {
  let r = 0;
  for (const ch of numeric) r = (r * 10 + (ch.charCodeAt(0) - 48)) % 97;
  return r;
}

function ibanToNumeric(s: string): string {
  return s
    .toUpperCase()
    .split("")
    .map((c) => (/[A-Z]/.test(c) ? String(c.charCodeAt(0) - 55) : c))
    .join("");
}

export function ibanValid(iban: string): boolean {
  const s = iban.replace(/\s/g, "").toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]+$/.test(s)) return false;
  return mod97(ibanToNumeric(s.slice(4) + s.slice(0, 4))) === 1;
}

/** IBAN français de test : banque 99999 (inexistante), guichet et compte aléatoires. */
export function demoIban(): string {
  const bank = "99999";
  const branch = digits(5);
  const account = digits(11);
  const ribKey = String(97 - ((89 * Number(bank) + 15 * Number(branch) + 3 * mod97(account)) % 97)).padStart(2, "0");
  const bban = bank + branch + account + ribKey;
  const check = String(98 - mod97(ibanToNumeric(bban + "FR00"))).padStart(2, "0");
  return `FR${check}${bban}`;
}
