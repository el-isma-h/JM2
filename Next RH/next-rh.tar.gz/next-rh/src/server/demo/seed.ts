import "server-only";
import { and, eq, ne } from "drizzle-orm";
import { addDays, differenceInCalendarMonths, format, max as maxDate, parseISO, startOfMonth, subMonths } from "date-fns";
import { db, schema } from "@/db";
import { encrypt, randomToken } from "@/lib/crypto";
import { frenchHolidays, workingDaysBetween } from "@/lib/dates";
import { hashPassword } from "@/server/auth";
import { bootstrapCompanyDefaults } from "@/server/company-defaults";
import type { PayrollSettings } from "@/server/onboarding/payroll-settings";
import { demoIban, demoSiren, demoSiret } from "./fixtures";

export const DEMO_EMAIL_DOMAIN = "demo.nextrh.invalid";

type Category = "non_cadre" | "cadre";
type DemoEmployee = {
  key: string;
  firstName: string;
  lastName: string;
  gender: "F" | "M";
  birthDate: string;
  jobTitle: string;
  department: string;
  site: "lyon" | "grenoble";
  category: Category;
  classification: string;
  coefficient: string;
  type: "CDI" | "CDD";
  hireDate: string;
  endDate?: string;
  trialEndDate?: string;
  cddReason?: string;
  forfaitJours?: boolean;
  weeklyHours?: string;
  monthlyHours?: string;
  previousSalaryCents?: number;
  raiseDate?: string;
  salaryCents: number;
  manager?: string;
  pas: { rate: string; neutral?: boolean };
  phone: string;
  address: [string, string, string];
};

const iso = (d: Date) => format(d, "yyyy-MM-dd");

function mondayOnOrAfter(d: Date): Date {
  const x = new Date(d);
  while (x.getDay() !== 1) x.setDate(x.getDate() + 1);
  return x;
}

function leaveDays(start: string, end: string) {
  const years = new Set([parseISO(start).getFullYear(), parseISO(end).getFullYear()]);
  return workingDaysBetween(start, end, [...years].flatMap(frenchHolidays));
}

/** Les 14 salariés fictifs. Dates relatives à `today` pour la période d'essai et le CDD. */
function employeesFor(today: Date): DemoEmployee[] {
  const trialEnd = addDays(today, 12);
  const inesHire = addDays(subMonths(trialEnd, 4), 1);
  const cddEnd = addDays(today, 40);
  const cddStart = subMonths(today, 5);
  return [
    { key: "hm", firstName: "Hélène", lastName: "Marchetti", gender: "F", birthDate: "1974-03-12", jobTitle: "Directrice générale", department: "Direction", site: "lyon", category: "cadre", classification: "Position 3.2", coefficient: "210", type: "CDI", hireDate: "2014-09-01", forfaitJours: true, previousSalaryCents: 598000, raiseDate: "2026-01-01", salaryCents: 612500, pas: { rate: "9.80" }, phone: "06 41 27 83 19", address: ["12 rue Professeur Grignard", "69007", "Lyon"] },
    { key: "kb", firstName: "Karim", lastName: "Benali", gender: "M", birthDate: "1979-11-02", jobTitle: "Directeur technique", department: "Études", site: "lyon", category: "cadre", classification: "Position 3.1", coefficient: "170", type: "CDI", hireDate: "2017-02-06", forfaitJours: true, previousSalaryCents: 521000, raiseDate: "2026-01-01", salaryCents: 534000, manager: "hm", pas: { rate: "8.60" }, phone: "06 72 15 40 66", address: ["4 place Bellecour", "69002", "Lyon"] },
    { key: "sl", firstName: "Sophie", lastName: "Lemaire-Daviet", gender: "F", birthDate: "1983-06-24", jobTitle: "Responsable administrative et RH", department: "Administration", site: "lyon", category: "cadre", classification: "Position 2.2", coefficient: "130", type: "CDI", hireDate: "2019-04-15", previousSalaryCents: 377500, raiseDate: "2026-01-01", salaryCents: 387000, manager: "hm", pas: { rate: "5.10" }, phone: "06 18 92 57 30", address: ["27 cours Gambetta", "69003", "Lyon"] },
    { key: "tg", firstName: "Thibault", lastName: "Garnier", gender: "M", birthDate: "1986-01-30", jobTitle: "Ingénieur d'études senior", department: "Études", site: "lyon", category: "cadre", classification: "Position 2.3", coefficient: "150", type: "CDI", hireDate: "2018-10-01", forfaitJours: true, previousSalaryCents: 411000, raiseDate: "2026-01-01", salaryCents: 421500, manager: "kb", pas: { rate: "6.60" }, phone: "07 61 33 08 47", address: ["9 rue Duguesclin", "69006", "Lyon"] },
    { key: "ir", firstName: "Inès", lastName: "Roussel", gender: "F", birthDate: "1995-09-17", jobTitle: "Ingénieure d'études", department: "Études", site: "lyon", category: "cadre", classification: "Position 2.1", coefficient: "115", type: "CDI", hireDate: iso(inesHire), trialEndDate: iso(trialEnd), salaryCents: 348000, manager: "kb", pas: { rate: "3.90" }, phone: "06 05 71 29 84", address: ["31 rue Paul Bert", "69003", "Lyon"] },
    { key: "mp", firstName: "Mathis", lastName: "Perrin", gender: "M", birthDate: "1997-04-08", jobTitle: "Technicien dessinateur", department: "Études", site: "lyon", category: "non_cadre", classification: "ETAM 2.2", coefficient: "310", type: "CDI", hireDate: "2021-09-13", previousSalaryCents: 232000, raiseDate: "2026-04-01", salaryCents: 239500, manager: "tg", pas: { rate: "2.30" }, phone: "06 84 50 12 73", address: ["58 avenue Berthelot", "69007", "Lyon"] },
    { key: "nc", firstName: "Nadia", lastName: "Chérif", gender: "F", birthDate: "1988-12-03", jobTitle: "Assistante de gestion", department: "Administration", site: "lyon", category: "non_cadre", classification: "ETAM 1.3", coefficient: "250", type: "CDI", hireDate: "2020-01-06", weeklyHours: "28.00", monthlyHours: "121.33", previousSalaryCents: 187400, raiseDate: "2026-01-01", salaryCents: 191250, manager: "sl", pas: { rate: "0.00" }, phone: "06 29 64 81 05", address: ["7 rue de Marseille", "69007", "Lyon"] },
    { key: "lf", firstName: "Lucas", lastName: "Fontaine", gender: "M", birthDate: "2000-07-21", jobTitle: "Technicien d'études", department: "Études", site: "lyon", category: "non_cadre", classification: "ETAM 2.1", coefficient: "275", type: "CDD", hireDate: iso(cddStart), endDate: iso(cddEnd), cddReason: "Accroissement temporaire d'activité (projet de réhabilitation thermique)", salaryCents: 218000, manager: "tg", pas: { rate: "0.50", neutral: true }, phone: "07 52 18 39 60", address: ["15 rue Saint-Jérôme", "69007", "Lyon"] },
    { key: "ar", firstName: "Amandine", lastName: "Rigaud", gender: "F", birthDate: "1984-02-14", jobTitle: "Chargée d'affaires", department: "Agence de Grenoble", site: "grenoble", category: "cadre", classification: "Position 2.2", coefficient: "130", type: "CDI", hireDate: "2020-06-02", previousSalaryCents: 366500, raiseDate: "2026-01-01", salaryCents: 376000, manager: "hm", pas: { rate: "7.40" }, phone: "06 93 07 46 28", address: ["3 rue Lesdiguières", "38000", "Grenoble"] },
    { key: "bc", firstName: "Bastien", lastName: "Cordier", gender: "M", birthDate: "1993-10-11", jobTitle: "Technicien de mesure", department: "Agence de Grenoble", site: "grenoble", category: "non_cadre", classification: "ETAM 2.1", coefficient: "275", type: "CDI", hireDate: "2022-03-07", previousSalaryCents: 221500, raiseDate: "2026-01-01", salaryCents: 226800, manager: "ar", pas: { rate: "1.70" }, phone: "06 47 81 22 95", address: ["22 cours Jean Jaurès", "38000", "Grenoble"] },
    { key: "yh", firstName: "Yasmine", lastName: "Haddad", gender: "F", birthDate: "1996-05-29", jobTitle: "Ingénieure d'études", department: "Agence de Grenoble", site: "grenoble", category: "cadre", classification: "Position 2.1", coefficient: "115", type: "CDI", hireDate: "2023-11-20", previousSalaryCents: 352000, raiseDate: "2026-01-01", salaryCents: 361500, manager: "ar", pas: { rate: "4.20" }, phone: "07 66 30 15 82", address: ["11 avenue Alsace-Lorraine", "38000", "Grenoble"] },
    { key: "gl", firstName: "Grégoire", lastName: "Lambert-Ozanne", gender: "M", birthDate: "1981-08-05", jobTitle: "Projeteur", department: "Études", site: "lyon", category: "non_cadre", classification: "ETAM 3.1", coefficient: "400", type: "CDI", hireDate: "2016-05-23", previousSalaryCents: 258500, raiseDate: "2026-01-01", salaryCents: 264000, manager: "kb", pas: { rate: "3.10" }, phone: "06 11 58 74 36", address: ["40 rue Masséna", "69006", "Lyon"] },
    { key: "od", firstName: "Océane", lastName: "Dufresne", gender: "F", birthDate: "1992-03-19", jobTitle: "Comptable", department: "Administration", site: "lyon", category: "non_cadre", classification: "ETAM 2.3", coefficient: "355", type: "CDI", hireDate: "2022-09-05", previousSalaryCents: 239000, raiseDate: "2026-01-01", salaryCents: 245500, manager: "sl", pas: { rate: "2.80" }, phone: "06 38 27 90 14", address: ["18 rue Chevreul", "69007", "Lyon"] },
    { key: "re", firstName: "Romain", lastName: "Estève", gender: "M", birthDate: "1987-12-27", jobTitle: "Ingénieur méthodes", department: "Études", site: "lyon", category: "cadre", classification: "Position 2.2", coefficient: "130", type: "CDI", hireDate: "2019-01-14", previousSalaryCents: 383000, raiseDate: "2026-01-01", salaryCents: 392500, manager: "kb", pas: { rate: "5.70" }, phone: "07 49 02 63 71", address: ["6 quai Claude Bernard", "69007", "Lyon"] },
  ];
}

/**
 * Crée un tenant de démonstration neuf (données fictives, aucun envoi réel) et ses deux utilisateurs.
 * Le gestionnaire est owner de l'entreprise ; le salarié de démo est lié à la fiche de Mathis Perrin (rôle employee).
 */
type DemoSeed = { tenantId: string; companyId: string; ownerUserId: string; employeeUserId: string };

export async function seedDemo(): Promise<DemoSeed> {
  const demo = await seedDemoData();
  await seedDemoPayrollHistory(demo);
  return demo;
}

/**
 * Historique de paie de la démo, calculé par le moteur (jamais saisi à la main) après le commit des données :
 * les deux mois précédents sont menés jusqu'à la clôture, le mois en cours est ouvert et calculé
 * pour que le visiteur puisse contrôler, valider et finaliser lui-même. Aucun envoi réel (entreprise isDemo).
 */
async function seedDemoPayrollHistory(demo: DemoSeed) {
  const cycle = await import("@/server/payroll/cycle");
  const now = new Date();
  const months: { year: number; month: number; close: boolean }[] = [];
  for (let back = 2; back >= 0; back--) {
    const d = new Date(now.getFullYear(), now.getMonth() - back, 1);
    months.push({ year: d.getFullYear(), month: d.getMonth() + 1, close: back > 0 });
  }
  for (const m of months) {
    const uid = demo.ownerUserId;
    const { periodId } = await cycle.openPeriod(demo.companyId, m.year, m.month, uid);
    await cycle.collectVariables(periodId, uid);
    await cycle.checkPeriod(periodId, uid);
    await cycle.computePeriod(periodId, uid);
    if (!m.close) continue;
    // Les points « à vérifier » des mois passés sont considérés comme pris en compte par le gestionnaire fictif.
    await db
      .update(schema.payrollAnomalies)
      .set({ status: "acknowledged", resolvedBy: uid, resolvedAt: new Date() })
      .where(and(eq(schema.payrollAnomalies.periodId, periodId), ne(schema.payrollAnomalies.severity, "blocking"), eq(schema.payrollAnomalies.status, "open")));
    try {
      await cycle.controlPeriod(periodId, uid);
      await cycle.validatePeriod(periodId, uid);
      await cycle.finalizePeriod(periodId, uid);
      await cycle.markExported(periodId, uid);
      await cycle.distributePeriod(periodId, uid);
      await cycle.closePeriod(periodId, uid);
    } catch (e) {
      // Un bulletin bloqué (cas hors périmètre) laisse la période ouverte : c'est un comportement attendu et visible.
      console.warn("demo.payroll_history", m, e instanceof Error ? e.message : e);
    }
  }
}

async function seedDemoData(): Promise<DemoSeed> {
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  const suffix = randomToken(6).toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8) || String(Date.now());
  const siren = demoSiren();
  const [ownerHash, employeeHash] = await Promise.all([hashPassword(randomToken(24)), hashPassword(randomToken(24))]);
  const people = employeesFor(today);

  return db.transaction(async (tx) => {
    const [tenant] = await tx
      .insert(schema.tenants)
      .values({ name: "Lorvay Ingénierie (démonstration)", kind: "company", slug: `demo-${suffix}`, isDemo: true, settings: { demo: { createdAt: today.toISOString() } } })
      .returning();

    const [owner] = await tx
      .insert(schema.users)
      .values({ email: `gestionnaire-${suffix}@${DEMO_EMAIL_DOMAIN}`, passwordHash: ownerHash, firstName: "Camille", lastName: "Gestionnaire (démo)", tenantId: tenant.id, emailVerifiedAt: today })
      .returning();
    const [empUser] = await tx
      .insert(schema.users)
      .values({ email: `salarie-${suffix}@${DEMO_EMAIL_DOMAIN}`, passwordHash: employeeHash, firstName: "Mathis", lastName: "Perrin", tenantId: tenant.id, emailVerifiedAt: today })
      .returning();

    const settings: PayrollSettings = {
      paymentDay: 28,
      headcountBracket: "11to49",
      atRate: "0.69",
      mobilityRate: "2.00",
      mutuelle: { name: "Mutuelle Alvéa Santé (fictive)", employerCents: 4185, employeeCents: 2790 },
      prevoyance: { name: "Prévoyance Arcadie (fictive)", cadreEmployerRate: "1.50", cadreEmployeeRate: "0.37", nonCadreEmployerRate: "0.62", nonCadreEmployeeRate: "0.41" },
      workTime: "35h",
      preparers: [owner.id],
      validators: [owner.id],
      confirmed: { idcc: true, atRate: true, headcount: true },
    };

    const [company] = await tx
      .insert(schema.companies)
      .values({
        tenantId: tenant.id,
        legalName: "Lorvay Ingénierie SAS",
        tradeName: "Lorvay Ingénierie (entreprise fictive)",
        siren,
        legalForm: "SAS",
        apeCode: "7112B",
        activity: "Ingénierie, études techniques du bâtiment",
        idcc: "1486",
        collectiveAgreement: "Bureaux d'études techniques, cabinets d'ingénieurs-conseils et sociétés de conseils (Syntec)",
        idccConfirmed: true,
        headcount: people.length,
        addressLine1: "9 rue Duguesclin",
        postalCode: "69006",
        city: "Lyon",
        payrollSettings: settings,
        onboardingStep: "done",
        onboardingCompletedAt: today,
        isDemo: true,
      })
      .returning();

    await bootstrapCompanyDefaults(tx, company.id);
    await tx.insert(schema.companyMemberships).values([
      { companyId: company.id, userId: owner.id, role: "owner" },
      { companyId: company.id, userId: empUser.id, role: "employee" },
    ]);

    // Établissements : le siège créé par défaut est complété, l'agence de Grenoble est ajoutée.
    const [head] = await tx.select().from(schema.establishments).where(eq(schema.establishments.companyId, company.id)).limit(1);
    const headSiret = demoSiret(siren, "0001");
    await tx
      .update(schema.establishments)
      .set({ name: "Siège de Lyon", siret: headSiret, nic: headSiret.slice(9), addressLine1: "9 rue Duguesclin", postalCode: "69006", city: "Lyon", urssafCode: "827" })
      .where(eq(schema.establishments.id, head.id));
    const greSiret = demoSiret(siren, "0002");
    const [gre] = await tx
      .insert(schema.establishments)
      .values({ companyId: company.id, name: "Agence de Grenoble", siret: greSiret, nic: greSiret.slice(9), addressLine1: "3 rue Lesdiguières", postalCode: "38000", city: "Grenoble", urssafCode: "827" })
      .returning();

    await tx.insert(schema.companyOrganisms).values([
      { companyId: company.id, kind: "urssaf", name: "URSSAF Rhône-Alpes", reference: "Compte fictif 827 000 000 000" },
      { companyId: company.id, kind: "retraite", name: "Caisse de retraite complémentaire (démo)", contractNumber: "RC-DEMO-4471" },
      { companyId: company.id, kind: "mutuelle", name: "Mutuelle Alvéa Santé (fictive)", contractNumber: "MUT-DEMO-2093" },
      { companyId: company.id, kind: "prevoyance", name: "Prévoyance Arcadie (fictive)", contractNumber: "PREV-DEMO-1188" },
      { companyId: company.id, kind: "medecine_travail", name: "Service de prévention et de santé au travail (démo)" },
    ]);
    await tx.insert(schema.companyContacts).values([
      { companyId: company.id, fullName: "Hélène Marchetti", role: "dirigeant", email: `direction-${suffix}@${DEMO_EMAIL_DOMAIN}`, phone: "04 72 00 00 00" },
      { companyId: company.id, fullName: "Sophie Lemaire-Daviet", role: "rh", email: `rh-${suffix}@${DEMO_EMAIL_DOMAIN}` },
      { companyId: company.id, fullName: "Cabinet comptable Vernay (fictif)", role: "comptable", email: `comptable-${suffix}@${DEMO_EMAIL_DOMAIN}` },
    ]);

    const leaveTypes = await tx.select().from(schema.leaveTypes).where(eq(schema.leaveTypes.companyId, company.id));
    const cp = leaveTypes.find((t) => t.code === "CP")!;
    const rtt = leaveTypes.find((t) => t.code === "RTT")!;

    // ---------- Salariés ----------
    const ids = new Map<string, string>();
    const contractIds = new Map<string, string>();
    for (const [i, p] of people.entries()) {
      const [emp] = await tx
        .insert(schema.employees)
        .values({
          companyId: company.id,
          establishmentId: p.site === "lyon" ? head.id : gre.id,
          userId: p.key === "mp" ? empUser.id : null,
          employeeNumber: String(1001 + i),
          status: "active",
          civility: p.gender === "F" ? "Mme" : "M.",
          firstName: p.firstName,
          lastName: p.lastName,
          gender: p.gender,
          birthDate: p.birthDate,
          birthCountry: "FR",
          nationality: "FR",
          email: `${p.firstName}.${p.lastName}`.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z.]/g, "") + `-${suffix}@${DEMO_EMAIL_DOMAIN}`,
          phone: p.phone,
          addressLine1: p.address[0],
          postalCode: p.address[1],
          city: p.address[2],
          jobTitle: p.jobTitle,
          department: p.department,
          hireDate: p.hireDate,
          isDemo: true,
        })
        .returning({ id: schema.employees.id });
      ids.set(p.key, emp.id);

      const partTime = Boolean(p.weeklyHours && p.weeklyHours !== "35.00");
      const [contract] = await tx
        .insert(schema.contracts)
        .values({
          employeeId: emp.id,
          type: p.type,
          category: p.category,
          startDate: p.hireDate,
          endDate: p.endDate ?? null,
          trialEndDate: p.trialEndDate ?? null,
          jobTitle: p.jobTitle,
          classification: p.classification,
          coefficient: p.coefficient,
          workTimeMode: p.forfaitJours ? "forfait_jours" : "heures",
          weeklyHours: p.forfaitJours ? "35.00" : (p.weeklyHours ?? "35.00"),
          monthlyHours: p.forfaitJours ? "151.67" : (p.monthlyHours ?? "151.67"),
          annualDays: p.forfaitJours ? 218 : null,
          isPartTime: partTime,
          isExecutive: p.category === "cadre",
          cddReason: p.cddReason ?? null,
          notes: partTime ? "Temps partiel choisi à 80 % (mercredi non travaillé)." : null,
        })
        .returning({ id: schema.contracts.id });
      contractIds.set(p.key, contract.id);

      // Rémunération datée avec historique.
      if (p.previousSalaryCents && p.raiseDate) {
        await tx.insert(schema.compensations).values([
          { employeeId: emp.id, contractId: contract.id, effectiveDate: p.hireDate < "2025-01-01" ? "2025-01-01" : p.hireDate, endDate: iso(addDays(parseISO(p.raiseDate), -1)), basis: "monthly", grossAmountCents: p.previousSalaryCents, reason: "Salaire de base", createdBy: owner.id },
          { employeeId: emp.id, contractId: contract.id, effectiveDate: p.raiseDate, basis: "monthly", grossAmountCents: p.salaryCents, reason: "Augmentation annuelle", createdBy: owner.id },
        ]);
        await tx.insert(schema.employeeEvents).values({
          employeeId: emp.id,
          kind: "remuneration",
          effectiveDate: p.raiseDate,
          title: "Augmentation annuelle",
          details: { fromCents: p.previousSalaryCents, toCents: p.salaryCents },
          affectsPayroll: true,
          createdBy: owner.id,
        });
      } else {
        await tx.insert(schema.compensations).values({ employeeId: emp.id, contractId: contract.id, effectiveDate: p.hireDate, basis: "monthly", grossAmountCents: p.salaryCents, reason: "Salaire d'embauche", createdBy: owner.id });
      }
      await tx.insert(schema.employeeEvents).values({ employeeId: emp.id, kind: "entree", effectiveDate: p.hireDate, title: `Entrée : ${p.type} ${p.jobTitle}`, details: { contractId: contract.id }, affectsPayroll: true, createdBy: owner.id });

      // RIB fictif (IBAN de test valide au mod 97, chiffré).
      const iban = demoIban();
      await tx.insert(schema.employeeBankAccounts).values({
        employeeId: emp.id,
        holderName: `${p.firstName} ${p.lastName}`,
        ibanEnc: encrypt(iban),
        ibanLast4: iban.slice(-4),
        bic: "DEMOFRPPXXX",
        bankName: "Banque fictive de démonstration",
        isPrimary: true,
        validFrom: p.hireDate,
      });

      await tx.insert(schema.pasRates).values({
        employeeId: emp.id,
        rate: p.pas.rate,
        kind: p.pas.neutral ? "neutre" : "personnalise",
        effectiveDate: "2026-09-01",
        source: p.pas.neutral ? "Taux neutre (grille) en attente du taux personnalisé" : "Compte rendu métier DSN (fictif)",
        isNeutral: Boolean(p.pas.neutral),
      });
    }

    // Hiérarchie (organigramme).
    for (const p of people) {
      if (p.manager) await tx.update(schema.employees).set({ managerId: ids.get(p.manager)! }).where(eq(schema.employees.id, ids.get(p.key)!));
    }

    // ---------- Congés ----------
    const cpPrev = { start: "2025-06-01", end: "2026-05-31" };
    const cpCur = { start: "2026-06-01", end: "2027-05-31" };
    const requests: { key: string; start: Date; days: number; status: "approved" | "pending"; type: "CP" | "RTT"; reason?: string }[] = [
      { key: "hm", start: mondayOnOrAfter(addDays(today, -75)), days: 10, status: "approved", type: "CP" },
      { key: "gl", start: mondayOnOrAfter(addDays(today, -88)), days: 12, status: "approved", type: "CP" },
      { key: "od", start: mondayOnOrAfter(addDays(today, -20)), days: 5, status: "approved", type: "CP" },
      { key: "yh", start: mondayOnOrAfter(addDays(today, -40)), days: 1, status: "approved", type: "RTT" },
      { key: "mp", start: mondayOnOrAfter(addDays(today, 34)), days: 4, status: "pending", type: "CP", reason: "Congés de fin d'année" },
      { key: "yh", start: mondayOnOrAfter(addDays(today, 19)), days: 2, status: "pending", type: "CP", reason: "Déménagement" },
    ];
    const taken = new Map<string, number>();
    const pending = new Map<string, number>();
    for (const r of requests) {
      const startIso = iso(r.start);
      const endIso = iso(addDays(r.start, r.days - 1 + Math.floor((r.days - 1) / 5) * 2));
      const duration = leaveDays(startIso, endIso);
      await tx.insert(schema.leaveRequests).values({
        employeeId: ids.get(r.key)!,
        leaveTypeId: r.type === "CP" ? cp.id : rtt.id,
        startDate: startIso,
        endDate: endIso,
        duration: duration.toFixed(2),
        status: r.status,
        reason: r.reason ?? null,
        approvedBy: r.status === "approved" ? owner.id : null,
        decidedAt: r.status === "approved" ? addDays(r.start, -14) : null,
      });
      if (r.type === "CP") {
        const m = r.status === "approved" ? taken : pending;
        m.set(r.key, (m.get(r.key) ?? 0) + duration);
      }
    }
    for (const p of people) {
      const hired = parseISO(p.hireDate);
      // Mois complets acquis depuis le début de la période en cours (ou l'embauche), jusqu'au mois précédent.
      const monthsCur = Math.max(0, differenceInCalendarMonths(startOfMonth(today), startOfMonth(maxDate([parseISO(cpCur.start), hired]))));
      const monthsPrev = hired <= parseISO(cpPrev.start) ? 12 : Math.max(0, Math.min(12, differenceInCalendarMonths(parseISO(cpCur.start), startOfMonth(hired))));
      const prevAcquired = monthsPrev === 12 ? 25 : Math.round(monthsPrev * 2.08 * 100) / 100;
      const prevTaken = Math.min(prevAcquired, { hm: 18, kb: 20, sl: 17, tg: 21, mp: 15, nc: 19, ar: 16, bc: 22, yh: 14, gl: 20, od: 18, re: 23 }[p.key] ?? 0);
      if (prevAcquired > 0) {
        await tx.insert(schema.leaveBalances).values({ employeeId: ids.get(p.key)!, leaveTypeId: cp.id, periodStart: cpPrev.start, periodEnd: cpPrev.end, acquired: prevAcquired.toFixed(2), taken: prevTaken.toFixed(2) });
      }
      await tx.insert(schema.leaveBalances).values({
        employeeId: ids.get(p.key)!,
        leaveTypeId: cp.id,
        periodStart: cpCur.start,
        periodEnd: cpCur.end,
        acquired: (monthsCur * 2.08).toFixed(2),
        taken: (taken.get(p.key) ?? 0).toFixed(2),
        pending: (pending.get(p.key) ?? 0).toFixed(2),
      });
    }

    // ---------- Feuille de temps avec heures supplémentaires (mois précédent, en attente) ----------
    const prevMonth = subMonths(today, 1);
    const y = prevMonth.getFullYear();
    const m = prevMonth.getMonth() + 1;
    const holidays = frenchHolidays(y);
    const entries: { date: string; hours: number; overtime: number; note?: string }[] = [];
    for (let d = new Date(y, m - 1, 1); d.getMonth() === m - 1; d.setDate(d.getDate() + 1)) {
      const wd = d.getDay();
      const dIso = iso(d);
      if (wd === 0 || wd === 6 || holidays.includes(dIso)) continue;
      const extra = [3, 4, 11, 17].includes(d.getDate()) ? (d.getDate() === 11 ? 1.5 : 2) : 0;
      entries.push({ date: dIso, hours: 7 + extra, overtime: extra, note: extra ? "Remise du dossier de consultation" : undefined });
    }
    const totalHours = entries.reduce((a, e) => a + e.hours, 0);
    const overtime = entries.reduce((a, e) => a + e.overtime, 0);
    await tx.insert(schema.timesheets).values({ employeeId: ids.get("mp")!, year: y, month: m, status: "pending", entries, totalHours: totalHours.toFixed(2), overtimeHours: overtime.toFixed(2) });

    // ---------- Note de frais ----------
    const [report] = await tx
      .insert(schema.expenseReports)
      .values({ employeeId: ids.get("ar")!, title: "Déplacement chantier de Chambéry", status: "pending", totalCents: 6420 + 2380 + 9150 + 1270 })
      .returning({ id: schema.expenseReports.id });
    const tripDay = iso(addDays(today, -9));
    await tx.insert(schema.expenseLines).values([
      { reportId: report.id, date: tripDay, category: "transport", label: "Train Grenoble - Chambéry aller-retour", amountCents: 6420, vatCents: 584 },
      { reportId: report.id, date: tripDay, category: "repas", label: "Déjeuner sur chantier", amountCents: 2380, vatCents: 216 },
      { reportId: report.id, date: tripDay, category: "hebergement", label: "Hôtel (1 nuit)", amountCents: 9150, vatCents: 832 },
      { reportId: report.id, date: iso(addDays(today, -8)), category: "transport", label: "Stationnement gare", amountCents: 1270, vatCents: 212 },
    ]);

    // ---------- Demande RH ----------
    await tx.insert(schema.hrRequests).values({
      companyId: company.id,
      employeeId: ids.get("mp")!,
      kind: "attestation",
      title: "Attestation employeur pour un dossier de location",
      body: "Bonjour, pourriez-vous me fournir une attestation employeur mentionnant mon ancienneté et mon salaire ? Merci.",
      status: "pending",
    });

    // ---------- Entretiens ----------
    const trialMeeting = addDays(today, 7);
    trialMeeting.setHours(10, 0, 0, 0);
    const proMeeting = addDays(today, 19);
    proMeeting.setHours(14, 30, 0, 0);
    const [trialInterview] = await tx
      .insert(schema.interviews)
      .values({ employeeId: ids.get("ir")!, kind: "fin_periode_essai", scheduledAt: trialMeeting, conductedBy: owner.id, status: "planned", objectives: ["Bilan des quatre premiers mois", "Décision sur la confirmation de l'embauche"] })
      .returning({ id: schema.interviews.id });
    const [proInterview] = await tx
      .insert(schema.interviews)
      .values({ employeeId: ids.get("gl")!, kind: "professionnel", scheduledAt: proMeeting, conductedBy: owner.id, status: "planned", objectives: ["Perspectives d'évolution vers un poste de chef de projet", "Besoins de formation BIM"] })
      .returning({ id: schema.interviews.id });

    // ---------- Formations ----------
    const [hab] = await tx
      .insert(schema.trainings)
      .values({ employeeId: ids.get("re")!, title: "Habilitation électrique B1V-BR", provider: "Organisme de formation fictif", kind: "habilitation", startDate: "2023-11-27", endDate: "2023-11-29", expiresAt: iso(addDays(today, 25)), costCents: 84500, status: "done" })
      .returning({ id: schema.trainings.id });
    await tx.insert(schema.trainings).values({ employeeId: ids.get("bc")!, title: "Sauveteur secouriste du travail (SST)", provider: "Organisme de formation fictif", kind: "formation", startDate: iso(addDays(today, 30)), endDate: iso(addDays(today, 31)), costCents: 32000, status: "requested" });

    // ---------- Échéances ----------
    const lucas = people.find((p) => p.key === "lf")!;
    const ines = people.find((p) => p.key === "ir")!;
    await tx.insert(schema.deadlines).values([
      { companyId: company.id, employeeId: ids.get("ir")!, kind: "periode_essai", title: "Fin de période d'essai : Inès Roussel", dueDate: ines.trialEndDate!, sourceType: "contract", sourceId: contractIds.get("ir")! },
      { companyId: company.id, employeeId: ids.get("lf")!, kind: "fin_cdd", title: "Fin de CDD : Lucas Fontaine", dueDate: lucas.endDate!, sourceType: "contract", sourceId: contractIds.get("lf")! },
      { companyId: company.id, employeeId: ids.get("re")!, kind: "habilitation", title: "Expiration de l'habilitation électrique : Romain Estève", dueDate: iso(addDays(today, 25)), sourceType: "training", sourceId: hab.id },
      { companyId: company.id, employeeId: ids.get("ir")!, kind: "entretien", title: "Entretien de fin de période d'essai : Inès Roussel", dueDate: iso(trialMeeting), sourceType: "interview", sourceId: trialInterview.id },
      { companyId: company.id, employeeId: ids.get("gl")!, kind: "entretien", title: "Entretien professionnel : Grégoire Lambert-Ozanne", dueDate: iso(proMeeting), sourceType: "interview", sourceId: proInterview.id },
    ]);

    await tx.insert(schema.remoteWorkRequests).values([
      { employeeId: ids.get("tg")!, date: iso(mondayOnOrAfter(addDays(today, 3))), status: "approved", approvedBy: owner.id },
      { employeeId: ids.get("mp")!, date: iso(addDays(mondayOnOrAfter(addDays(today, 3)), 3)), status: "pending" },
    ]);

    // PAYROLL_HISTORY : calculé après le commit par seedDemoPayrollHistory() (le moteur n'utilise pas `tx`).

    return { tenantId: tenant.id, companyId: company.id, ownerUserId: owner.id, employeeUserId: empUser.id };
  });
}
