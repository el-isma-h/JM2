"use server";

import { revalidatePath } from "next/cache";
import { and, eq, gte, inArray, lte } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { audit } from "@/server/audit";
import { fmtDate, frenchHolidays } from "@/lib/dates";
import type { ActionState } from "./auth";
import { bool, employeeOf, euros, HrError, id, isoDate, optStr, runAction, str } from "@/server/hr/common";
import { addDaysIso, remoteDaysInWeek } from "@/server/hr/calc";
import { getISODay, parseISO } from "date-fns";

async function getPolicy(companyId: string) {
  const [p] = await db.select().from(schema.remoteWorkPolicies).where(eq(schema.remoteWorkPolicies.companyId, companyId)).limit(1);
  if (p) return p;
  const [created] = await db.insert(schema.remoteWorkPolicies).values({ companyId }).onConflictDoNothing().returning();
  if (created) return created;
  const [again] = await db.select().from(schema.remoteWorkPolicies).where(eq(schema.remoteWorkPolicies.companyId, companyId)).limit(1);
  return again;
}

export async function saveRemotePolicyAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "company.manage");
    const before = await getPolicy(companyId);
    const max = Number(str(fd, "maxDaysPerWeek"));
    if (!Number.isInteger(max) || max < 0 || max > 5) throw new HrError("Maximum hebdomadaire : entre 0 et 5 jours.");
    const values = {
      maxDaysPerWeek: max,
      requiresApproval: bool(fd, "requiresApproval"),
      allowanceCentsPerDay: str(fd, "allowance") ? euros(fd, "allowance", "Indemnité") : 0,
      rules: optStr(fd, "rules"),
    };
    await db.update(schema.remoteWorkPolicies).set(values).where(eq(schema.remoteWorkPolicies.id, before.id));
    await audit({ action: "remote_policy.update", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "remote_work_policy", entityId: before.id, before, after: values });
    revalidatePath(`/app/${companyId}/teletravail`);
    return { ok: true, message: "Politique de télétravail enregistrée." };
  });
}

/** Jours déjà posés (en attente ou validés) autour d'une période, pour le contrôle hebdomadaire. */
async function existingDays(employeeId: string, from: string, to: string, statuses: ("pending" | "approved")[]) {
  const rows = await db
    .select({ id: schema.remoteWorkRequests.id, date: schema.remoteWorkRequests.date, status: schema.remoteWorkRequests.status })
    .from(schema.remoteWorkRequests)
    .where(and(eq(schema.remoteWorkRequests.employeeId, employeeId), gte(schema.remoteWorkRequests.date, addDaysIso(from, -7)), lte(schema.remoteWorkRequests.date, addDaysIso(to, 7)), inArray(schema.remoteWorkRequests.status, statuses)));
  return rows;
}

/** Saisie de jours de télétravail pour un salarié (plage + jours de la semaine). */
export async function createRemoteDaysAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const employeeId = id(fd, "employeeId");
    await employeeOf(companyId, employeeId);
    const start = isoDate(fd, "startDate", "Du");
    const end = str(fd, "endDate") ? isoDate(fd, "endDate", "Au") : start;
    if (end < start) throw new HrError("La date de fin précède la date de début.");
    if (addDaysIso(start, 92) < end) throw new HrError("Période limitée à 3 mois par saisie.");
    const weekdays = new Set(fd.getAll("weekday").map(String));
    const policy = await getPolicy(companyId);
    const holidays = new Set([...frenchHolidays(Number(start.slice(0, 4))), ...frenchHolidays(Number(end.slice(0, 4)))]);
    const dates: string[] = [];
    for (let d = start; d <= end; d = addDaysIso(d, 1)) {
      const wd = getISODay(parseISO(d));
      if (wd > 5 || holidays.has(d)) continue;
      if (weekdays.size && !weekdays.has(String(wd))) continue;
      dates.push(d);
    }
    if (!dates.length) throw new HrError("Aucun jour ouvré retenu sur cette période.");
    const existing = await existingDays(employeeId, start, end, ["pending", "approved"]);
    const existingDates = existing.map((x) => x.date);
    const fresh = dates.filter((d) => !existingDates.includes(d));
    const accum = [...existingDates];
    const refused: string[] = [];
    const accepted: string[] = [];
    for (const d of fresh) {
      if (remoteDaysInWeek(accum, d) >= policy.maxDaysPerWeek && !bool(fd, "override")) {
        refused.push(d);
        continue;
      }
      accum.push(d);
      accepted.push(d);
    }
    const status = !policy.requiresApproval || bool(fd, "approveNow") ? ("approved" as const) : ("pending" as const);
    if (accepted.length) {
      await db
        .insert(schema.remoteWorkRequests)
        .values(accepted.map((date) => ({ employeeId, date, status, approvedBy: status === "approved" ? ctx.user.id : null })))
        .onConflictDoNothing();
    }
    await audit({ action: "remote.create", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "employee", entityId: employeeId, after: { dates: accepted, refused, status } });
    revalidatePath(`/app/${companyId}/teletravail`);
    if (!accepted.length) throw new HrError(`Maximum de ${policy.maxDaysPerWeek} jour(s) par semaine atteint : aucun jour ajouté.`);
    return {
      ok: true,
      message: `${accepted.length} jour(s) ${status === "approved" ? "validé(s)" : "en attente de validation"}.${refused.length ? ` ${refused.length} jour(s) écarté(s) car le maximum hebdomadaire de ${policy.maxDaysPerWeek} est atteint (premier : ${fmtDate(refused[0])}).` : ""}`,
    };
  });
}

export async function decideRemoteAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const reqId = id(fd, "requestId");
    const [row] = await db
      .select({ r: schema.remoteWorkRequests })
      .from(schema.remoteWorkRequests)
      .innerJoin(schema.employees, eq(schema.employees.id, schema.remoteWorkRequests.employeeId))
      .where(and(eq(schema.remoteWorkRequests.id, reqId), eq(schema.employees.companyId, companyId)))
      .limit(1);
    if (!row) throw new HrError("Demande introuvable.");
    const r = row.r;
    const decision = str(fd, "decision");
    let status: "approved" | "rejected" | "cancelled";
    if (decision === "approve") {
      if (r.status !== "pending") throw new HrError("Demande déjà traitée.");
      const policy = await getPolicy(companyId);
      const approved = await existingDays(r.employeeId, r.date, r.date, ["approved"]);
      if (remoteDaysInWeek(approved.map((x) => x.date), r.date) >= policy.maxDaysPerWeek) {
        throw new HrError(`Maximum de ${policy.maxDaysPerWeek} jour(s) validé(s) déjà atteint cette semaine.`);
      }
      status = "approved";
    } else if (decision === "reject") {
      if (r.status !== "pending") throw new HrError("Demande déjà traitée.");
      status = "rejected";
    } else if (decision === "cancel") {
      status = "cancelled";
    } else throw new HrError("Décision inconnue.");
    await db.update(schema.remoteWorkRequests).set({ status, approvedBy: ctx.user.id }).where(eq(schema.remoteWorkRequests.id, r.id));
    await audit({ action: `remote.${decision}`, userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "remote_work_request", entityId: r.id, before: { status: r.status }, after: { status } });
    revalidatePath(`/app/${companyId}/teletravail`);
    revalidatePath(`/app/${companyId}`);
    return { ok: true, message: { approved: "Jour validé.", rejected: "Jour refusé.", cancelled: "Jour annulé." }[status] };
  });
}
