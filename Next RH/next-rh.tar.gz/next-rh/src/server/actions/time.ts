"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { audit } from "@/server/audit";
import { monthLabel } from "@/lib/dates";
import type { ActionState } from "./auth";
import { activeContract, employeeOf, HrError, id, runAction, str } from "@/server/hr/common";
import { computeOvertime, type TimesheetEntry } from "@/server/hr/calc";
import { pushPayrollVariable, withdrawPayrollVariable } from "@/server/hr/payroll-link";

function parseYm(fd: FormData) {
  const year = Number(str(fd, "year"));
  const month = Number(str(fd, "month"));
  if (!Number.isInteger(year) || year < 2000 || year > 2100 || !Number.isInteger(month) || month < 1 || month > 12) throw new HrError("Mois invalide.");
  return { year, month };
}

async function loadTimesheet(companyId: string, timesheetId: string) {
  const [row] = await db
    .select({ t: schema.timesheets, e: schema.employees })
    .from(schema.timesheets)
    .innerJoin(schema.employees, eq(schema.employees.id, schema.timesheets.employeeId))
    .where(and(eq(schema.timesheets.id, timesheetId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!row) throw new HrError("Feuille de temps introuvable.");
  return row;
}

/** Enregistre (et soumet éventuellement) la feuille de temps mensuelle d'un salarié. */
export async function saveTimesheetAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const employeeId = id(fd, "employeeId");
    await employeeOf(companyId, employeeId);
    const { year, month } = parseYm(fd);
    const prefix = `${year}-${String(month).padStart(2, "0")}-`;
    const entries: TimesheetEntry[] = [];
    for (const [k, v] of fd.entries()) {
      if (!k.startsWith("h_") || typeof v !== "string") continue;
      const date = k.slice(2);
      if (!date.startsWith(prefix) || !/^\d{4}-\d{2}-\d{2}$/.test(date)) continue;
      const raw = v.trim().replace(",", ".");
      if (!raw) continue;
      const hours = Number(raw);
      if (!Number.isFinite(hours) || hours < 0 || hours > 24) throw new HrError(`Heures invalides le ${date.slice(8)} : entre 0 et 24.`);
      if (hours > 0) entries.push({ date, hours: Math.round(hours * 100) / 100 });
    }
    // Durée quotidienne maximale légale : 10 h (dérogations possibles) : signalée dans le message, sans blocage.
    const contract = await activeContract(employeeId, `${prefix}15`);
    const weekly = contract ? Number(contract.weeklyHours) : 35;
    const forfait = contract?.workTimeMode === "forfait_jours";
    const ot = computeOvertime(entries, weekly, year, month);
    const overtime = forfait ? 0 : ot.overtimeHours;
    const submit = str(fd, "intent") === "submit";

    const [existing] = await db
      .select()
      .from(schema.timesheets)
      .where(and(eq(schema.timesheets.employeeId, employeeId), eq(schema.timesheets.year, year), eq(schema.timesheets.month, month)))
      .limit(1);
    if (existing && existing.status === "approved") throw new HrError("Feuille déjà validée : rouvrez-la pour la modifier.");
    const values = {
      entries,
      totalHours: ot.totalHours.toFixed(2),
      overtimeHours: overtime.toFixed(2),
      status: submit ? ("pending" as const) : ("draft" as const),
    };
    let tsId: string;
    if (existing) {
      await db.update(schema.timesheets).set(values).where(eq(schema.timesheets.id, existing.id));
      tsId = existing.id;
    } else {
      const [row] = await db.insert(schema.timesheets).values({ employeeId, year, month, ...values }).returning({ id: schema.timesheets.id });
      tsId = row.id;
    }
    await audit({
      action: submit ? "timesheet.submit" : "timesheet.save",
      userId: ctx.user.id,
      companyId,
      tenantId: ctx.tenant.id,
      entityType: "timesheet",
      entityId: tsId,
      before: existing ? { totalHours: existing.totalHours, overtimeHours: existing.overtimeHours, status: existing.status } : null,
      after: { totalHours: values.totalHours, overtimeHours: values.overtimeHours, status: values.status },
    });
    revalidatePath(`/app/${companyId}/temps`);
    const warn = entries.filter((e) => e.hours > 10).length;
    return {
      ok: true,
      message: `${submit ? "Feuille soumise à validation" : "Brouillon enregistré"} : ${ot.totalHours.toLocaleString("fr-FR")} h${overtime > 0 ? `, dont ${overtime.toLocaleString("fr-FR")} h supplémentaires` : ""}.${forfait ? " Salarié au forfait jours : pas d'heures supplémentaires." : ""}${warn ? ` ${warn} journée(s) dépassent 10 h : vérifiez la dérogation.` : ""}`,
    };
  });
}

export async function decideTimesheetAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const { t, e } = await loadTimesheet(companyId, id(fd, "timesheetId"));
    const decision = str(fd, "decision");
    if (t.status !== "pending") throw new HrError("Seules les feuilles soumises peuvent être validées ou refusées.");
    if (decision === "reject") {
      await db.update(schema.timesheets).set({ status: "rejected", approvedBy: ctx.user.id, decidedAt: new Date() }).where(eq(schema.timesheets.id, t.id));
      await audit({ action: "timesheet.reject", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "timesheet", entityId: t.id, before: { status: t.status }, after: { status: "rejected" } });
      revalidatePath(`/app/${companyId}/temps`);
      return { ok: true, message: "Feuille refusée : elle repasse en saisie." };
    }
    if (decision !== "approve") throw new HrError("Décision inconnue.");
    const hours = Number(t.overtimeHours);
    const entries = (t.entries as TimesheetEntry[]) ?? [];
    const contract = await activeContract(t.employeeId, `${t.year}-${String(t.month).padStart(2, "0")}-15`);
    const ot = computeOvertime(entries, contract ? Number(contract.weeklyHours) : 35, t.year, t.month);
    const res = await db.transaction(async (tx) => {
      let p: Awaited<ReturnType<typeof pushPayrollVariable>> | null = null;
      if (hours > 0) {
        p = await pushPayrollVariable(tx, {
          companyId,
          employeeId: t.employeeId,
          year: t.year,
          month: t.month,
          kind: "heures_sup",
          label: `Heures supplémentaires ${monthLabel(t.year, t.month)}`,
          quantity: hours.toFixed(2),
          note: `25 % : ${ot.at25.toFixed(2)} h ; 50 % : ${ot.at50.toFixed(2)} h`,
          source: "timesheet",
          sourceId: t.id,
          userId: ctx.user.id,
          what: `Les heures supplémentaires de ${e.firstName} ${e.lastName}`,
        });
      }
      await tx.update(schema.timesheets).set({ status: "approved", approvedBy: ctx.user.id, decidedAt: new Date() }).where(eq(schema.timesheets.id, t.id));
      return p;
    });
    await audit({
      action: "timesheet.approve",
      userId: ctx.user.id,
      companyId,
      tenantId: ctx.tenant.id,
      entityType: "timesheet",
      entityId: t.id,
      before: { status: t.status },
      after: { status: "approved", overtimeHours: t.overtimeHours, payrollVariableId: res?.variableId ?? null, shifted: res?.shifted ?? false },
    });
    revalidatePath(`/app/${companyId}/temps`);
    revalidatePath(`/app/${companyId}`);
    return {
      ok: true,
      message: hours > 0 ? `Feuille validée : ${hours.toLocaleString("fr-FR")} h supplémentaires transmises à la paie${res?.shifted ? " (reportées au mois suivant, paie déjà validée)" : ""}.` : "Feuille validée, sans heures supplémentaires.",
    };
  });
}

/** Rouvre une feuille validée : retire la variable d'heures sup (ou crée une régularisation si la paie est validée). */
export async function reopenTimesheetAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const { t } = await loadTimesheet(companyId, id(fd, "timesheetId"));
    if (t.status !== "approved") throw new HrError("Seule une feuille validée peut être rouverte.");
    const out = await db.transaction(async (tx) => {
      const [v] = await tx
        .select({ id: schema.payrollVariables.id })
        .from(schema.payrollVariables)
        .where(and(eq(schema.payrollVariables.source, "timesheet"), eq(schema.payrollVariables.sourceId, t.id), eq(schema.payrollVariables.employeeId, t.employeeId)))
        .limit(1);
      const w = v ? await withdrawPayrollVariable(tx, { companyId, variableId: v.id, userId: ctx.user.id, what: "La réouverture d'une feuille de temps" }) : null;
      await tx.update(schema.timesheets).set({ status: "draft", approvedBy: null, decidedAt: null }).where(eq(schema.timesheets.id, t.id));
      return w;
    });
    await audit({ action: "timesheet.reopen", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "timesheet", entityId: t.id, before: { status: "approved" }, after: { status: "draft", variableRemoved: out?.removed ?? false, regularisationId: out?.regularisationId ?? null } });
    revalidatePath(`/app/${companyId}/temps`);
    return { ok: true, message: out?.regularisationId ? "Feuille rouverte. Paie déjà validée : régularisation prévue le mois suivant." : "Feuille rouverte." };
  });
}
