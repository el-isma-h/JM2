"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import type { ActionState } from "./auth";
import { employeeOf, euros, HrError, id, optStr, requireAnyPermission, runAction, str } from "@/server/hr/common";
import { syncDeadlines } from "@/server/hr/deadlines";
import { fileFrom, saveProof } from "@/server/hr/uploads";
import { TRAINING_KINDS, TRAINING_STATUSES } from "@/server/hr/trainings";

const optDate = (fd: FormData, key: string) => {
  const v = str(fd, key);
  if (!v) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new HrError("Date invalide.");
  return v;
};

export async function createTrainingAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireAnyPermission(companyId, ["employees.write", "requests.approve"]);
    const employeeId = id(fd, "employeeId");
    await employeeOf(companyId, employeeId);
    const title = str(fd, "title");
    if (title.length < 3) throw new HrError("Intitulé requis.");
    const kind = str(fd, "kind");
    if (!TRAINING_KINDS.some((k) => k.value === kind)) throw new HrError("Type invalide.");
    const values = {
      employeeId,
      title: title.slice(0, 160),
      provider: optStr(fd, "provider"),
      kind,
      startDate: optDate(fd, "startDate"),
      endDate: optDate(fd, "endDate"),
      expiresAt: optDate(fd, "expiresAt"),
      costCents: str(fd, "cost") ? euros(fd, "cost", "Coût") : 0,
      status: "requested",
    };
    if (values.startDate && values.endDate && values.endDate < values.startDate) throw new HrError("La fin précède le début.");
    const [row] = await db.insert(schema.trainings).values(values).returning({ id: schema.trainings.id });
    await audit({ action: "training.create", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "training", entityId: row.id, after: values });
    await syncDeadlines(companyId);
    revalidatePath(`/app/${companyId}/formations`);
    return { ok: true, message: "Formation enregistrée." };
  });
}

export async function updateTrainingAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireAnyPermission(companyId, ["employees.write", "requests.approve"]);
    const trainingId = id(fd, "trainingId");
    const [row] = await db
      .select({ t: schema.trainings })
      .from(schema.trainings)
      .innerJoin(schema.employees, eq(schema.employees.id, schema.trainings.employeeId))
      .where(and(eq(schema.trainings.id, trainingId), eq(schema.employees.companyId, companyId)))
      .limit(1);
    if (!row) throw new HrError("Formation introuvable.");
    const before = row.t;
    const status = str(fd, "status");
    if (!TRAINING_STATUSES.some((s) => s.value === status)) throw new HrError("Statut invalide.");
    const values: Partial<typeof schema.trainings.$inferInsert> = { status };
    if (fd.has("expiresAt")) values.expiresAt = optDate(fd, "expiresAt");
    if (fd.has("cost") && str(fd, "cost")) values.costCents = euros(fd, "cost", "Coût");
    const file = fileFrom(fd, "certificate");
    if (file) {
      const doc = await saveProof(file, {
        companyId,
        employeeId: before.employeeId,
        title: `Attestation de formation : ${before.title}`,
        sourceType: "training",
        sourceId: before.id,
        userId: ctx.user.id,
        isDemo: ctx.company.isDemo,
      });
      values.certificateDocumentId = doc.id;
    }
    await db.update(schema.trainings).set(values).where(eq(schema.trainings.id, before.id));
    await audit({ action: "training.update", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "training", entityId: before.id, before: { status: before.status, expiresAt: before.expiresAt, costCents: before.costCents }, after: values });
    await syncDeadlines(companyId);
    revalidatePath(`/app/${companyId}/formations`);
    return { ok: true, message: "Formation mise à jour." };
  });
}
