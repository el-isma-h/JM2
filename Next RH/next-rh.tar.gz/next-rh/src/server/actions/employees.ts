"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, desc, eq, inArray, isNull, lt, ne, or, gt } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { audit } from "@/server/audit";
import { encrypt, decrypt } from "@/lib/crypto";
import { isoToday } from "@/lib/dates";
import { createDocument, issueDownloadLink } from "@/server/documents/store";
import { getEmployee } from "@/server/employees/queries";
import { inviteEmployeeInternal } from "@/server/employees/invitations";
import { exitReasons } from "@/components/employees/labels";
import { checkBic, checkIban, checkNir, checkPostalCode, isEmail, parseAmountToCents, parseDateInput, parseDecimal } from "@/lib/validators";
import type { ActionState } from "./auth";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const opt = (fd: FormData, k: string, max = 200) => str(fd, k).slice(0, max) || null;

function dayBefore(iso: string): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() - 1);
  return d.toISOString().slice(0, 10);
}

const CONTRACT_TYPES = schema.contractTypeEnum.enumValues as readonly string[];
const CATEGORIES = schema.employeeCategoryEnum.enumValues as readonly string[];
const WORK_MODES = schema.workTimeModeEnum.enumValues as readonly string[];
const BASES = schema.salaryBasisEnum.enumValues as readonly string[];
const GENDERS = ["F", "M", "X"];

function fail(e: unknown, fallback = "Erreur") {
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message.startsWith("!") ? e.message.slice(1) : fallback) };
}

function revalidateEmployee(companyId: string, employeeId?: string) {
  revalidatePath(`/app/${companyId}/salaries`);
  if (employeeId) revalidatePath(`/app/${companyId}/salaries/${employeeId}`);
}

async function event(tx: Tx | typeof db, e: { employeeId: string; kind: string; effectiveDate: string; title: string; details?: Record<string, unknown>; affectsPayroll: boolean; userId: string }) {
  await tx.insert(schema.employeeEvents).values({ employeeId: e.employeeId, kind: e.kind, effectiveDate: e.effectiveDate, title: e.title, details: e.details ?? {}, affectsPayroll: e.affectsPayroll, createdBy: e.userId });
}

async function existingNirs(companyId: string, exceptId?: string) {
  const rows = await db
    .select({ id: schema.employees.id, nirEnc: schema.employees.nirEnc, firstName: schema.employees.firstName, lastName: schema.employees.lastName })
    .from(schema.employees)
    .where(and(eq(schema.employees.companyId, companyId), exceptId ? ne(schema.employees.id, exceptId) : undefined));
  const out = new Map<string, string>();
  for (const r of rows) {
    if (!r.nirEnc) continue;
    try {
      out.set(decrypt(r.nirEnc), `${r.firstName} ${r.lastName}`);
    } catch {}
  }
  return out;
}

/** Contrôles communs identité + coordonnées. Renvoie les valeurs prêtes à enregistrer. */
function readIdentity(fd: FormData) {
  const firstName = str(fd, "firstName");
  const lastName = str(fd, "lastName");
  if (!firstName || !lastName) throw new Error("!Le prénom et le nom sont obligatoires.");
  const gender = str(fd, "gender");
  if (gender && !GENDERS.includes(gender)) throw new Error("!Sexe inconnu.");
  const birthRaw = str(fd, "birthDate");
  const birthDate = birthRaw ? parseDateInput(birthRaw) : null;
  if (birthRaw && !birthDate) throw new Error("!Date de naissance invalide.");
  const email = str(fd, "email").toLowerCase();
  if (email && !isEmail(email)) throw new Error("!E-mail professionnel invalide.");
  const personalEmail = str(fd, "personalEmail").toLowerCase();
  if (personalEmail && !isEmail(personalEmail)) throw new Error("!E-mail personnel invalide.");
  const postal = str(fd, "postalCode");
  if (postal && !checkPostalCode(postal).ok) throw new Error("!Le code postal comporte 5 chiffres.");
  const nirRaw = str(fd, "nir");
  let nir: string | null = null;
  if (nirRaw) {
    const r = checkNir(nirRaw);
    if (!r.ok) throw new Error(`!N° de sécurité sociale : ${r.error}`);
    nir = r.value;
    if (gender && ((gender === "F" && nir[0] === "1") || (gender === "M" && nir[0] === "2"))) throw new Error("!Le premier chiffre du N° de sécurité sociale (1 homme, 2 femme) ne correspond pas au sexe indiqué.");
    if (birthDate && nir.slice(1, 3) !== birthDate.slice(2, 4)) throw new Error("!L'année de naissance du N° de sécurité sociale ne correspond pas à la date de naissance.");
  }
  return {
    values: {
      civility: opt(fd, "civility", 10),
      firstName: firstName.slice(0, 80),
      lastName: lastName.slice(0, 80),
      birthName: opt(fd, "birthName", 80),
      gender: (gender || null) as "F" | "M" | "X" | null,
      birthDate,
      birthPlace: opt(fd, "birthPlace", 120),
      birthCountry: opt(fd, "birthCountry", 80),
      nationality: opt(fd, "nationality", 80),
      email: email || null,
      personalEmail: personalEmail || null,
      phone: opt(fd, "phone", 30),
      addressLine1: opt(fd, "addressLine1"),
      addressLine2: opt(fd, "addressLine2"),
      postalCode: postal || null,
      city: opt(fd, "city", 120),
    },
    nir,
  };
}

function readContract(fd: FormData, startDate: string) {
  const type = str(fd, "contractType") || "CDI";
  if (!CONTRACT_TYPES.includes(type)) throw new Error("!Type de contrat inconnu.");
  const category = str(fd, "category") || "non_cadre";
  if (!CATEGORIES.includes(category)) throw new Error("!Catégorie inconnue.");
  const workTimeMode = str(fd, "workTimeMode") || "heures";
  if (!WORK_MODES.includes(workTimeMode)) throw new Error("!Mode de temps de travail inconnu.");
  const endRaw = str(fd, "endDate");
  const endDate = endRaw ? parseDateInput(endRaw) : null;
  if (endRaw && !endDate) throw new Error("!Date de fin de contrat invalide.");
  if (type === "CDD" && !endDate) throw new Error("!Un CDD doit avoir une date de fin (ou une durée minimale) : indiquez-la.");
  if (endDate && endDate < startDate) throw new Error("!La fin du contrat précède son début.");
  const trialRaw = str(fd, "trialEndDate");
  const trialEndDate = trialRaw ? parseDateInput(trialRaw) : null;
  if (trialRaw && !trialEndDate) throw new Error("!Date de fin de période d'essai invalide.");
  if (trialEndDate && trialEndDate < startDate) throw new Error("!La fin de période d'essai précède le début du contrat.");
  const weekly = parseDecimal(str(fd, "weeklyHours") || "35");
  if (weekly === null || Number(weekly) <= 0 || Number(weekly) > 48) throw new Error("!Durée hebdomadaire invalide (entre 0 et 48 heures).");
  const annualDaysRaw = str(fd, "annualDays");
  const annualDays = annualDaysRaw ? Number(annualDaysRaw) : null;
  if (annualDaysRaw && (!Number.isInteger(annualDays) || annualDays! < 1 || annualDays! > 218)) throw new Error("!Le forfait jours est limité à 218 jours par an.");
  if (workTimeMode === "forfait_jours" && !annualDays) throw new Error("!Indiquez le nombre de jours du forfait (218 au maximum).");
  const w = Number(weekly);
  return {
    type: type as (typeof schema.contractTypeEnum.enumValues)[number],
    category: category as (typeof schema.employeeCategoryEnum.enumValues)[number],
    startDate,
    endDate,
    trialEndDate,
    jobTitle: opt(fd, "jobTitle", 120),
    classification: opt(fd, "classification", 120),
    coefficient: opt(fd, "coefficient", 30),
    workTimeMode: workTimeMode as (typeof schema.workTimeModeEnum.enumValues)[number],
    weeklyHours: w.toFixed(2),
    monthlyHours: ((w * 52) / 12).toFixed(2),
    annualDays,
    isPartTime: workTimeMode === "heures" && w < 35,
    isExecutive: category === "cadre" || category === "cadre_dirigeant",
    cddReason: opt(fd, "cddReason", 200),
  };
}

// ---------- Création (entrée) ----------

export async function createEmployeeAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  let newId: string | null = null;
  try {
    const ctx = await requireCompany(companyId, "employees.write");
    const { values: identity, nir } = readIdentity(fd);
    const hireDate = parseDateInput(str(fd, "hireDate"));
    if (!hireDate) return { error: "La date d'entrée est obligatoire." };
    const contract = readContract(fd, hireDate);
    const gross = parseAmountToCents(str(fd, "grossAmount"));
    if (gross === null || gross <= 0) return { error: "Indiquez le salaire de base brut (par exemple 2187,40)." };
    const basis = str(fd, "basis") || "monthly";
    if (!BASES.includes(basis)) return { error: "Base de rémunération inconnue." };
    const establishmentId = str(fd, "establishmentId");
    if (establishmentId) {
      const [est] = await db.select({ id: schema.establishments.id }).from(schema.establishments).where(and(eq(schema.establishments.id, establishmentId), eq(schema.establishments.companyId, companyId))).limit(1);
      if (!est) return { error: "Établissement inconnu." };
    }
    const employeeNumber = opt(fd, "employeeNumber", 30);
    if (employeeNumber) {
      const [dup] = await db.select({ id: schema.employees.id }).from(schema.employees).where(and(eq(schema.employees.companyId, companyId), eq(schema.employees.employeeNumber, employeeNumber))).limit(1);
      if (dup) return { error: `Le matricule ${employeeNumber} est déjà utilisé.` };
    }
    if (nir) {
      const nirs = await existingNirs(companyId);
      if (nirs.has(nir)) return { error: `Ce N° de sécurité sociale est déjà celui de ${nirs.get(nir)} : vérifiez qu'il ne s'agit pas d'un doublon.` };
    }
    if (identity.birthDate) {
      const [same] = await db
        .select({ id: schema.employees.id })
        .from(schema.employees)
        .where(and(eq(schema.employees.companyId, companyId), eq(schema.employees.lastName, identity.lastName), eq(schema.employees.firstName, identity.firstName), eq(schema.employees.birthDate, identity.birthDate), ne(schema.employees.status, "left")))
        .limit(1);
      if (same) return { error: "Un salarié actif porte déjà ces nom, prénom et date de naissance." };
    }
    const today = isoToday();
    newId = await db.transaction(async (tx) => {
      const [emp] = await tx
        .insert(schema.employees)
        .values({
          companyId,
          ...identity,
          nirEnc: nir ? encrypt(nir) : null,
          establishmentId: establishmentId || null,
          employeeNumber,
          jobTitle: contract.jobTitle,
          department: opt(fd, "department", 120),
          hireDate,
          status: hireDate > today ? "draft" : "active",
          isDemo: ctx.company.isDemo,
        })
        .returning({ id: schema.employees.id });
      const [c] = await tx.insert(schema.contracts).values({ employeeId: emp.id, ...contract }).returning({ id: schema.contracts.id });
      await tx.insert(schema.compensations).values({ employeeId: emp.id, contractId: c.id, effectiveDate: hireDate, basis: basis as "monthly" | "hourly" | "annual", grossAmountCents: gross, reason: "Rémunération à l'embauche", createdBy: ctx.user.id });
      await event(tx, {
        employeeId: emp.id,
        kind: "entree",
        effectiveDate: hireDate,
        title: `Entrée : ${contract.type}${contract.jobTitle ? `, ${contract.jobTitle}` : ""}`,
        details: { contractId: c.id, contractType: contract.type, trialEndDate: contract.trialEndDate },
        affectsPayroll: true,
        userId: ctx.user.id,
      });
      return emp.id;
    });
    await audit({ action: "employee.create", userId: ctx.user.id, companyId, entityType: "employee", entityId: newId, after: { ...identity, nir: nir ? "renseigné" : null, hireDate, contract: contract.type, grossCents: gross } });
    revalidateEmployee(companyId);
  } catch (e) {
    return fail(e);
  }
  redirect(`/app/${companyId}/salaries/${newId}?cree=1`);
}

// ---------- Identité et coordonnées ----------

export async function updateIdentityAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "employees.write");
    const before = await getEmployee(companyId, employeeId);
    if (!before) return { error: "Salarié introuvable." };
    const { values, nir } = readIdentity(fd);
    const set: Partial<typeof schema.employees.$inferInsert> = { ...values };
    let nirChanged = false;
    if (nir) {
      const current = before.nirEnc ? (() => { try { return decrypt(before.nirEnc!); } catch { return null; } })() : null;
      if (current !== nir) {
        const nirs = await existingNirs(companyId, employeeId);
        if (nirs.has(nir)) return { error: `Ce N° de sécurité sociale est déjà celui de ${nirs.get(nir)}.` };
        set.nirEnc = encrypt(nir);
        nirChanged = true;
      }
    }
    const changedKeys = Object.keys(values).filter((k) => (before as Record<string, unknown>)[k] !== (values as Record<string, unknown>)[k]);
    if (!changedKeys.length && !nirChanged) return { ok: true, message: "Aucune modification." };
    await db.update(schema.employees).set(set).where(and(eq(schema.employees.id, employeeId), eq(schema.employees.companyId, companyId)));
    const b = Object.fromEntries(changedKeys.map((k) => [k, (before as Record<string, unknown>)[k]]));
    const a = Object.fromEntries(changedKeys.map((k) => [k, (values as Record<string, unknown>)[k]]));
    if (nirChanged) {
      b.nir = before.nirEnc ? "ancien numéro" : null;
      a.nir = "nouveau numéro";
    }
    const payrollRelevant = nirChanged || changedKeys.some((k) => ["firstName", "lastName", "birthName", "birthDate", "addressLine1", "postalCode", "city"].includes(k));
    await event(db, { employeeId, kind: "identite", effectiveDate: isoToday(), title: nirChanged ? "N° de sécurité sociale modifié" : "Identité ou coordonnées modifiées", details: { fields: [...changedKeys, ...(nirChanged ? ["nir"] : [])] }, affectsPayroll: payrollRelevant, userId: ctx.user.id });
    await audit({ action: "employee.update_identity", userId: ctx.user.id, companyId, entityType: "employee", entityId: employeeId, before: b, after: a });
    revalidateEmployee(companyId, employeeId);
    return { ok: true, message: "Modifications enregistrées." };
  } catch (e) {
    return fail(e);
  }
}

// ---------- Poste et établissement ----------

export async function updateJobAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "employees.write");
    const before = await getEmployee(companyId, employeeId);
    if (!before) return { error: "Salarié introuvable." };
    const effectiveDate = parseDateInput(str(fd, "effectiveDate")) ?? isoToday();
    const establishmentId = str(fd, "establishmentId") || null;
    if (establishmentId) {
      const [est] = await db.select({ id: schema.establishments.id }).from(schema.establishments).where(and(eq(schema.establishments.id, establishmentId), eq(schema.establishments.companyId, companyId))).limit(1);
      if (!est) return { error: "Établissement inconnu." };
    }
    const managerId = str(fd, "managerId") || null;
    if (managerId) {
      if (managerId === employeeId) return { error: "Un salarié ne peut pas être son propre responsable." };
      const m = await getEmployee(companyId, managerId);
      if (!m) return { error: "Responsable inconnu." };
    }
    const employeeNumber = opt(fd, "employeeNumber", 30);
    if (employeeNumber && employeeNumber !== before.employeeNumber) {
      const [dup] = await db.select({ id: schema.employees.id }).from(schema.employees).where(and(eq(schema.employees.companyId, companyId), eq(schema.employees.employeeNumber, employeeNumber))).limit(1);
      if (dup) return { error: `Le matricule ${employeeNumber} est déjà utilisé.` };
    }
    const values = { jobTitle: opt(fd, "jobTitle", 120), department: opt(fd, "department", 120), establishmentId, managerId, employeeNumber };
    const changed = Object.keys(values).filter((k) => (before as Record<string, unknown>)[k] !== (values as Record<string, unknown>)[k]);
    if (!changed.length) return { ok: true, message: "Aucune modification." };
    await db.update(schema.employees).set(values).where(and(eq(schema.employees.id, employeeId), eq(schema.employees.companyId, companyId)));
    const b = Object.fromEntries(changed.map((k) => [k, (before as Record<string, unknown>)[k]]));
    const a = Object.fromEntries(changed.map((k) => [k, (values as Record<string, unknown>)[k]]));
    await event(db, { employeeId, kind: "poste", effectiveDate, title: changed.includes("establishmentId") ? "Changement d'établissement" : "Poste modifié", details: { before: b, after: a }, affectsPayroll: changed.includes("establishmentId"), userId: ctx.user.id });
    await audit({ action: "employee.update_job", userId: ctx.user.id, companyId, entityType: "employee", entityId: employeeId, before: b, after: { ...a, effectiveDate } });
    revalidateEmployee(companyId, employeeId);
    return { ok: true, message: "Poste mis à jour." };
  } catch (e) {
    return fail(e);
  }
}

// ---------- Contrats et avenants ----------

async function loadContract(companyId: string, employeeId: string, contractId: string) {
  const emp = await getEmployee(companyId, employeeId);
  if (!emp) return null;
  const [c] = await db.select().from(schema.contracts).where(and(eq(schema.contracts.id, contractId), eq(schema.contracts.employeeId, employeeId))).limit(1);
  return c ? { emp, contract: c } : null;
}

const AMENDABLE = ["jobTitle", "classification", "coefficient", "category", "workTimeMode", "weeklyHours", "annualDays", "endDate", "trialRenewedUntil"] as const;

/** Avenant : modification datée des clauses du contrat (classification, temps de travail, poste, terme…). */
export async function amendContractAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "employees.write");
    const found = await loadContract(companyId, employeeId, str(fd, "contractId"));
    if (!found) return { error: "Contrat introuvable." };
    const { contract } = found;
    const effectiveDate = parseDateInput(str(fd, "effectiveDate"));
    if (!effectiveDate) return { error: "Indiquez la date d'effet de la modification." };
    if (effectiveDate < contract.startDate) return { error: "La date d'effet précède le début du contrat." };
    const subject = str(fd, "subject").slice(0, 160);
    if (!subject) return { error: "Indiquez l'objet de la modification (par exemple « Passage à 4/5e »)." };
    const set: Record<string, unknown> = {};
    for (const k of AMENDABLE) {
      if (!fd.has(k)) continue;
      const raw = str(fd, k);
      if (k === "category") {
        if (!CATEGORIES.includes(raw)) return { error: "Catégorie inconnue." };
        set.category = raw;
        set.isExecutive = raw === "cadre" || raw === "cadre_dirigeant";
      } else if (k === "workTimeMode") {
        if (!WORK_MODES.includes(raw)) return { error: "Mode de temps de travail inconnu." };
        set.workTimeMode = raw;
      } else if (k === "weeklyHours") {
        const w = parseDecimal(raw);
        if (w === null || Number(w) <= 0 || Number(w) > 48) return { error: "Durée hebdomadaire invalide (entre 0 et 48 heures)." };
        set.weeklyHours = Number(w).toFixed(2);
        set.monthlyHours = ((Number(w) * 52) / 12).toFixed(2);
      } else if (k === "annualDays") {
        if (!raw) set.annualDays = null;
        else {
          const n = Number(raw);
          if (!Number.isInteger(n) || n < 1 || n > 218) return { error: "Le forfait jours est limité à 218 jours par an." };
          set.annualDays = n;
        }
      } else if (k === "endDate" || k === "trialRenewedUntil") {
        if (!raw) set[k] = null;
        else {
          const d = parseDateInput(raw);
          if (!d) return { error: "Date invalide." };
          if (d < contract.startDate) return { error: "La date précède le début du contrat." };
          set[k] = d;
        }
      } else {
        set[k] = raw.slice(0, 120) || null;
      }
    }
    const mode = (set.workTimeMode ?? contract.workTimeMode) as string;
    const weekly = Number(set.weeklyHours ?? contract.weeklyHours);
    set.isPartTime = mode === "heures" && weekly < 35;
    if (mode === "forfait_jours" && !(set.annualDays ?? contract.annualDays)) return { error: "Indiquez le nombre de jours du forfait." };
    const changes: Record<string, { from: unknown; to: unknown }> = {};
    for (const [k, v] of Object.entries(set)) {
      const prev = (contract as Record<string, unknown>)[k];
      if (String(prev ?? "") !== String(v ?? "")) changes[k] = { from: prev ?? null, to: v };
    }
    if (!Object.keys(changes).length) return { error: "Aucune clause modifiée." };
    const kind = changes.weeklyHours || changes.workTimeMode || changes.annualDays ? "temps_travail" : changes.classification || changes.coefficient || changes.category ? "classification" : "avenant";
    await db.transaction(async (tx) => {
      const [am] = await tx.insert(schema.amendments).values({ contractId: contract.id, effectiveDate, subject, changes }).returning({ id: schema.amendments.id });
      await tx.update(schema.contracts).set(set).where(eq(schema.contracts.id, contract.id));
      if (changes.jobTitle) await tx.update(schema.employees).set({ jobTitle: (set.jobTitle as string | null) ?? null }).where(eq(schema.employees.id, employeeId));
      await event(tx, { employeeId, kind, effectiveDate, title: `Avenant : ${subject}`, details: { contractId: contract.id, amendmentId: am.id, changes }, affectsPayroll: true, userId: ctx.user.id });
    });
    await audit({
      action: "contract.amend",
      userId: ctx.user.id,
      companyId,
      entityType: "employee",
      entityId: employeeId,
      before: Object.fromEntries(Object.entries(changes).map(([k, v]) => [k, v.from])),
      after: { ...Object.fromEntries(Object.entries(changes).map(([k, v]) => [k, v.to])), effectiveDate, subject, contractId: contract.id },
    });
    revalidateEmployee(companyId, employeeId);
    return { ok: true, message: "Modification enregistrée et datée. Elle sera prise en compte dans la paie du mois concerné." };
  } catch (e) {
    return fail(e);
  }
}

/** Nouveau contrat (CDD vers CDI, fin d'apprentissage suivie d'une embauche…). */
export async function newContractAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "employees.write");
    const emp = await getEmployee(companyId, employeeId);
    if (!emp) return { error: "Salarié introuvable." };
    const startDate = parseDateInput(str(fd, "startDate"));
    if (!startDate) return { error: "Indiquez la date de début du nouveau contrat." };
    const contract = readContract(fd, startDate);
    const [overlap] = await db
      .select({ id: schema.contracts.id })
      .from(schema.contracts)
      .where(and(eq(schema.contracts.employeeId, employeeId), eq(schema.contracts.startDate, startDate)))
      .limit(1);
    if (overlap) return { error: "Un contrat commence déjà à cette date." };
    await db.transaction(async (tx) => {
      // Clôture du contrat précédent encore ouvert.
      const open = await tx
        .select()
        .from(schema.contracts)
        .where(and(eq(schema.contracts.employeeId, employeeId), lt(schema.contracts.startDate, startDate), or(isNull(schema.contracts.endDate), gt(schema.contracts.endDate, dayBefore(startDate)))));
      for (const c of open) await tx.update(schema.contracts).set({ endDate: dayBefore(startDate) }).where(eq(schema.contracts.id, c.id));
      const [c] = await tx.insert(schema.contracts).values({ employeeId, ...contract }).returning({ id: schema.contracts.id });
      if (contract.jobTitle) await tx.update(schema.employees).set({ jobTitle: contract.jobTitle }).where(eq(schema.employees.id, employeeId));
      await event(tx, { employeeId, kind: "contrat", effectiveDate: startDate, title: `Nouveau contrat : ${contract.type}`, details: { contractId: c.id, closed: open.map((o) => o.id) }, affectsPayroll: true, userId: ctx.user.id });
    });
    await audit({ action: "contract.create", userId: ctx.user.id, companyId, entityType: "employee", entityId: employeeId, after: contract });
    revalidateEmployee(companyId, employeeId);
    return { ok: true, message: "Nouveau contrat enregistré." };
  } catch (e) {
    return fail(e);
  }
}

// ---------- Rémunération (jamais d'écrasement) ----------

export async function addCompensationAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "employees.write", "salaries.read");
    const emp = await getEmployee(companyId, employeeId);
    if (!emp) return { error: "Salarié introuvable." };
    const effectiveDate = parseDateInput(str(fd, "effectiveDate"));
    if (!effectiveDate) return { error: "Indiquez la date d'effet." };
    if (emp.hireDate && effectiveDate < emp.hireDate) return { error: "La date d'effet précède l'entrée du salarié." };
    const gross = parseAmountToCents(str(fd, "grossAmount"));
    if (gross === null || gross <= 0) return { error: "Montant brut invalide (par exemple 2312,15)." };
    const basis = str(fd, "basis") || "monthly";
    if (!BASES.includes(basis)) return { error: "Base inconnue." };
    const reason = str(fd, "reason").slice(0, 200);
    if (!reason) return { error: "Indiquez le motif (augmentation annuelle, promotion, passage à temps partiel…)." };
    const [same] = await db.select({ id: schema.compensations.id }).from(schema.compensations).where(and(eq(schema.compensations.employeeId, employeeId), eq(schema.compensations.effectiveDate, effectiveDate))).limit(1);
    if (same) return { error: "Une rémunération existe déjà à cette date d'effet. Choisissez une autre date : l'historique n'est jamais écrasé." };
    const [prevComp] = await db
      .select()
      .from(schema.compensations)
      .where(and(eq(schema.compensations.employeeId, employeeId), lt(schema.compensations.effectiveDate, effectiveDate)))
      .orderBy(desc(schema.compensations.effectiveDate))
      .limit(1);
    const [nextComp] = await db
      .select()
      .from(schema.compensations)
      .where(and(eq(schema.compensations.employeeId, employeeId), gt(schema.compensations.effectiveDate, effectiveDate)))
      .orderBy(schema.compensations.effectiveDate)
      .limit(1);
    const contracts = await db.select().from(schema.contracts).where(eq(schema.contracts.employeeId, employeeId)).orderBy(desc(schema.contracts.startDate));
    const contract = contracts.find((c) => c.startDate <= effectiveDate) ?? null;
    const [row] = await db.transaction(async (tx) => {
      if (prevComp && (!prevComp.endDate || prevComp.endDate >= effectiveDate)) await tx.update(schema.compensations).set({ endDate: dayBefore(effectiveDate) }).where(eq(schema.compensations.id, prevComp.id));
      const inserted = await tx
        .insert(schema.compensations)
        .values({ employeeId, contractId: contract?.id ?? null, effectiveDate, endDate: nextComp ? dayBefore(nextComp.effectiveDate) : null, basis: basis as "monthly" | "hourly" | "annual", grossAmountCents: gross, reason, createdBy: ctx.user.id })
        .returning();
      await event(tx, {
        employeeId,
        kind: "remuneration",
        effectiveDate,
        title: `Rémunération : ${reason}`,
        details: { compensationId: inserted[0].id, fromCents: prevComp?.grossAmountCents ?? null, toCents: gross, basis },
        affectsPayroll: true,
        userId: ctx.user.id,
      });
      return inserted;
    });
    await audit({ action: "compensation.create", userId: ctx.user.id, companyId, entityType: "employee", entityId: employeeId, before: prevComp ? { grossCents: prevComp.grossAmountCents, effectiveDate: prevComp.effectiveDate } : null, after: { grossCents: gross, effectiveDate, basis, reason, id: row.id } });
    revalidateEmployee(companyId, employeeId);
    return { ok: true, message: "Nouvelle rémunération enregistrée. L'ancienne reste visible dans l'historique." };
  } catch (e) {
    return fail(e);
  }
}

// ---------- Coordonnées bancaires (accès restreint) ----------

export async function saveBankAccountAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "employees.write", "employees.bank.read");
    const emp = await getEmployee(companyId, employeeId);
    if (!emp) return { error: "Salarié introuvable." };
    const iban = checkIban(str(fd, "iban"));
    if (!iban.ok) return { error: iban.error };
    const bicRaw = str(fd, "bic");
    let bic: string | null = null;
    if (bicRaw) {
      const b = checkBic(bicRaw);
      if (!b.ok) return { error: b.error };
      bic = b.value;
    }
    const holderName = str(fd, "holderName").slice(0, 120) || `${emp.firstName} ${emp.lastName}`;
    const validFrom = parseDateInput(str(fd, "validFrom")) ?? isoToday();
    const previous = await db.select({ id: schema.employeeBankAccounts.id, last4: schema.employeeBankAccounts.ibanLast4 }).from(schema.employeeBankAccounts).where(and(eq(schema.employeeBankAccounts.employeeId, employeeId), eq(schema.employeeBankAccounts.isPrimary, true)));
    const [row] = await db.transaction(async (tx) => {
      if (previous.length) await tx.update(schema.employeeBankAccounts).set({ isPrimary: false }).where(inArray(schema.employeeBankAccounts.id, previous.map((p) => p.id)));
      const r = await tx
        .insert(schema.employeeBankAccounts)
        .values({ employeeId, holderName, ibanEnc: encrypt(iban.value), ibanLast4: iban.value.slice(-4), bic, bankName: opt(fd, "bankName", 120), isPrimary: true, validFrom })
        .returning({ id: schema.employeeBankAccounts.id });
      await event(tx, { employeeId, kind: "banque", effectiveDate: validFrom, title: "Coordonnées bancaires modifiées", details: { bankAccountId: r[0].id, last4: iban.value.slice(-4) }, affectsPayroll: true, userId: ctx.user.id });
      return r;
    });
    await audit({ action: "bank.update", userId: ctx.user.id, companyId, entityType: "employee", entityId: employeeId, before: previous.length ? { last4: previous.map((p) => p.last4) } : null, after: { last4: iban.value.slice(-4), bankAccountId: row.id, validFrom } });
    revalidateEmployee(companyId, employeeId);
    revalidatePath(`/app/${companyId}/salaries/${employeeId}/banque`);
    return { ok: true, message: "Coordonnées bancaires enregistrées. Les virements suivants utiliseront ce compte." };
  } catch (e) {
    return fail(e);
  }
}

// ---------- Sortie et changements de situation ----------

export async function exitEmployeeAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "employees.write");
    const emp = await getEmployee(companyId, employeeId);
    if (!emp) return { error: "Salarié introuvable." };
    if (emp.status === "left") return { error: "Ce salarié est déjà sorti." };
    const leaveDate = parseDateInput(str(fd, "leaveDate"));
    if (!leaveDate) return { error: "Indiquez le dernier jour du contrat." };
    if (emp.hireDate && leaveDate < emp.hireDate) return { error: "La date de sortie précède la date d'entrée." };
    const reason = str(fd, "reason");
    const r = exitReasons.find((x) => x.value === reason);
    if (!r) return { error: "Choisissez le motif de sortie." };
    const notes = str(fd, "notes").slice(0, 500) || null;
    const today = isoToday();
    await db.transaction(async (tx) => {
      await tx.update(schema.employees).set({ leaveDate, leaveReason: reason, status: leaveDate <= today ? "left" : emp.status }).where(eq(schema.employees.id, employeeId));
      const open = await tx.select().from(schema.contracts).where(and(eq(schema.contracts.employeeId, employeeId), or(isNull(schema.contracts.endDate), gt(schema.contracts.endDate, leaveDate))));
      for (const c of open) if (c.startDate <= leaveDate) await tx.update(schema.contracts).set({ endDate: leaveDate }).where(eq(schema.contracts.id, c.id));
      await event(tx, { employeeId, kind: "sortie", effectiveDate: leaveDate, title: `Sortie : ${r.label}`, details: { reason, notes, documents: r.docs }, affectsPayroll: true, userId: ctx.user.id });
    });
    await audit({ action: "employee.exit", userId: ctx.user.id, companyId, entityType: "employee", entityId: employeeId, before: { status: emp.status, leaveDate: emp.leaveDate }, after: { leaveDate, reason, notes } });
    revalidateEmployee(companyId, employeeId);
    return { ok: true, message: leaveDate <= today ? "Sortie enregistrée. Le salarié est passé au statut « Sorti »." : `Sortie programmée au ${leaveDate.split("-").reverse().join("/")} : le statut passera à « Sorti » à cette date.`, data: { reason } };
  } catch (e) {
    return fail(e);
  }
}

/** Suspension du contrat (congé parental, sabbatique, longue maladie…) ou reprise d'activité. */
export async function changeSituationAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "employees.write");
    const emp = await getEmployee(companyId, employeeId);
    if (!emp) return { error: "Salarié introuvable." };
    const kind = str(fd, "kind");
    const date = parseDateInput(str(fd, "effectiveDate"));
    if (!date) return { error: "Indiquez la date d'effet." };
    const reason = str(fd, "reason").slice(0, 200);
    if (!reason) return { error: "Précisez le motif." };
    let status: "active" | "suspended";
    if (kind === "suspension") {
      if (emp.status !== "active") return { error: "Seul un salarié actif peut voir son contrat suspendu." };
      status = "suspended";
    } else if (kind === "reprise_activite") {
      if (emp.status !== "suspended" && emp.status !== "draft") return { error: "Ce salarié n'est pas en suspension." };
      status = "active";
    } else return { error: "Changement inconnu." };
    await db.transaction(async (tx) => {
      await tx.update(schema.employees).set({ status }).where(eq(schema.employees.id, employeeId));
      await event(tx, { employeeId, kind, effectiveDate: date, title: kind === "suspension" ? `Suspension du contrat : ${reason}` : `Reprise d'activité : ${reason}`, details: { reason }, affectsPayroll: true, userId: ctx.user.id });
    });
    await audit({ action: `employee.${kind}`, userId: ctx.user.id, companyId, entityType: "employee", entityId: employeeId, before: { status: emp.status }, after: { status, date, reason } });
    revalidateEmployee(companyId, employeeId);
    return { ok: true, message: "Situation mise à jour et datée." };
  } catch (e) {
    return fail(e);
  }
}

// ---------- Documents du salarié ----------

const EMPLOYEE_DOC_CATEGORIES = ["contrat", "avenant", "attestation", "courrier", "justificatif", "identite", "fiche_poste", "autre"] as const;

export async function uploadEmployeeDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = str(fd, "companyId");
  const employeeId = str(fd, "employeeId");
  try {
    const ctx = await requireCompany(companyId, "documents.write");
    const emp = await getEmployee(companyId, employeeId);
    if (!emp) return { error: "Salarié introuvable." };
    const file = fd.get("file");
    if (!(file instanceof File) || file.size === 0) return { error: "Choisissez un fichier." };
    if (file.size > 8 * 1024 * 1024) return { error: "Fichier trop lourd (8 Mo maximum)." };
    if (!["application/pdf", "image/png", "image/jpeg", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"].includes(file.type)) return { error: "Formats acceptés : PDF, PNG, JPEG, DOCX." };
    const category = str(fd, "category");
    if (!(EMPLOYEE_DOC_CATEGORIES as readonly string[]).includes(category)) return { error: "Catégorie inconnue." };
    const visibility = str(fd, "visibility") === "employee" ? "employee" : "restricted";
    const title = (str(fd, "title") || file.name).slice(0, 160);
    const doc = await createDocument({
      companyId,
      employeeId,
      category: category as (typeof EMPLOYEE_DOC_CATEGORIES)[number],
      visibility,
      title,
      fileName: file.name,
      mimeType: file.type,
      data: Buffer.from(await file.arrayBuffer()),
      uploadedBy: ctx.user.id,
      sourceType: "employee_file",
      sourceId: employeeId,
      isDemo: ctx.company.isDemo,
    });
    await audit({ action: "document.upload", userId: ctx.user.id, companyId, entityType: "employee", entityId: employeeId, after: { documentId: doc.id, category, title, visibility } });
    revalidateEmployee(companyId, employeeId);
    return { ok: true, message: visibility === "employee" ? "Document ajouté et visible par le salarié dans son espace." : "Document ajouté (visible des gestionnaires uniquement)." };
  } catch (e) {
    return fail(e);
  }
}

/** Lien de téléchargement temporaire (15 min) pour un document de l'entreprise. */
export async function getDocumentLinkAction(companyId: string, documentId: string): Promise<{ url?: string; error?: string }> {
  try {
    const ctx = await requireCompany(companyId, "documents.read");
    const [doc] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, documentId), eq(schema.documents.companyId, companyId))).limit(1);
    if (!doc) return { error: "Document introuvable." };
    const url = await issueDownloadLink(doc.id, ctx.user.id);
    await audit({ action: "document.download_link", userId: ctx.user.id, companyId, entityType: "document", entityId: doc.id });
    return { url };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

// ---------- Actions groupées ----------

export async function inviteEmployeesAction(companyId: string, employeeIds: string[]): Promise<ActionState & { links?: { name: string; link: string }[] }> {
  try {
    const ctx = await requireCompany(companyId, "employees.write");
    const ids = employeeIds.filter((id) => /^[0-9a-f-]{36}$/.test(id)).slice(0, 500);
    if (!ids.length) return { error: "Sélectionnez au moins un salarié." };
    const emps = await db.select().from(schema.employees).where(and(eq(schema.employees.companyId, companyId), inArray(schema.employees.id, ids)));
    let sent = 0;
    const skipped: string[] = [];
    const links: { name: string; link: string }[] = [];
    for (const e of emps) {
      const name = `${e.firstName} ${e.lastName}`;
      if (e.userId) {
        skipped.push(`${name} (déjà inscrit)`);
        continue;
      }
      if (e.status === "left") {
        skipped.push(`${name} (sorti)`);
        continue;
      }
      const email = e.email ?? e.personalEmail;
      if (!email) {
        skipped.push(`${name} (pas d'e-mail)`);
        continue;
      }
      const r = await inviteEmployeeInternal(ctx, { id: e.id, email });
      if (r.status === "sent") sent++;
      else links.push({ name, link: r.link });
    }
    revalidateEmployee(companyId);
    const parts = [];
    if (sent) parts.push(`${sent} invitation(s) envoyée(s) par e-mail.`);
    if (links.length) parts.push(ctx.company.isDemo ? `${links.length} invitation(s) créée(s) sans envoi (démonstration).` : `${links.length} invitation(s) créée(s) sans envoi d'e-mail (service non configuré) : liens à transmettre ci-dessous.`);
    if (skipped.length) parts.push(`Non invités : ${skipped.join(", ")}.`);
    return { ok: true, message: parts.join(" "), links };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}
