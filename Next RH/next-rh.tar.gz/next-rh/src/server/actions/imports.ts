"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { audit } from "@/server/audit";
import { applyImport, createImportFromFile, getImport, validateImport } from "@/server/onboarding/import-service";
import { IMPORT_SPECS, isImportKind } from "@/server/onboarding/import-spec";
import type { ActionState } from "./auth";

const MAX = 5 * 1024 * 1024;

export async function uploadImportAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = String(fd.get("companyId") ?? "");
  let importId: string | null = null;
  try {
    const ctx = await requireCompany(companyId, "employees.write", "company.manage");
    const kind = String(fd.get("kind") ?? "");
    if (!isImportKind(kind)) return { error: "Type d'import inconnu." };
    const file = fd.get("file");
    if (!(file instanceof File) || file.size === 0) return { error: "Choisissez un fichier CSV." };
    if (file.size > MAX) return { error: "Fichier trop lourd (5 Mo maximum)." };
    const res = await createImportFromFile({ companyId, kind, fileName: file.name, data: new Uint8Array(await file.arrayBuffer()), userId: ctx.user.id });
    if ("error" in res) return { error: res.error };
    importId = res.importRow.id;
    await audit({ action: "import.upload", userId: ctx.user.id, companyId, entityType: "data_import", entityId: importId, after: { kind, fileName: file.name, rows: (res.importRow.preview as { totalRows?: number }).totalRows } });
    revalidatePath(`/app/${companyId}/onboarding`);
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Chargement impossible." };
  }
  redirect(`/app/${companyId}/onboarding/import/${importId}`);
}

export async function validateImportAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = String(fd.get("companyId") ?? "");
  const importId = String(fd.get("importId") ?? "");
  try {
    const ctx = await requireCompany(companyId, "employees.write", "company.manage");
    const imp = await getImport(companyId, importId);
    if (!imp || !isImportKind(imp.kind)) return { error: "Import introuvable." };
    const headers = ((imp.preview as { headers?: string[] }).headers ?? []) as string[];
    const mapping: Record<string, string | null> = {};
    for (const f of IMPORT_SPECS[imp.kind].fields) {
      const v = String(fd.get(`map.${f.key}`) ?? "");
      mapping[f.key] = v && headers.includes(v) ? v : null;
    }
    const used = Object.values(mapping).filter(Boolean);
    if (new Set(used).size !== used.length) return { error: "Une même colonne est associée à plusieurs champs : corrigez la correspondance." };
    const res = await validateImport(companyId, importId, mapping);
    if ("error" in res) return { error: res.error };
    await audit({ action: "import.validate", userId: ctx.user.id, companyId, entityType: "data_import", entityId: importId, after: { errors: res.issues.filter((i) => i.level === "error").length, duplicates: res.duplicates.length, valid: res.validLines.length } });
    revalidatePath(`/app/${companyId}/onboarding/import/${importId}`);
    return { ok: true, message: `Contrôle terminé : ${res.validLines.length} ligne(s) prête(s), ${res.errorLines.length} en erreur, ${new Set(res.duplicates.map((d) => d.line)).size} en doublon.` };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

export async function applyImportAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = String(fd.get("companyId") ?? "");
  const importId = String(fd.get("importId") ?? "");
  try {
    const ctx = await requireCompany(companyId, "employees.write", "company.manage");
    const res = await applyImport(companyId, importId, ctx.user.id, { skipInvalid: fd.get("skipInvalid") === "on" });
    if ("error" in res) return { error: res.error };
    await audit({ action: "import.apply", userId: ctx.user.id, companyId, entityType: "data_import", entityId: importId, after: { applied: res.applied, skipped: res.skipped, kind: res.kind } });
    revalidatePath(`/app/${companyId}`, "layout");
    return { ok: true, message: `${res.applied} ligne(s) importée(s)${res.skipped ? `, ${res.skipped} ignorée(s)` : ""}.` };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}
