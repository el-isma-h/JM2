"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { audit } from "@/server/audit";
import type { ActionState } from "./auth";
import { employeeOf, HrError, id, isoDate, runAction, str, UUID_RE } from "@/server/hr/common";
import { deadlineKindLabels, syncDeadlines } from "@/server/hr/deadlines";

export async function syncDeadlinesAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "employees.read");
    const res = await syncDeadlines(companyId);
    await audit({ action: "deadlines.sync", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, after: res });
    revalidatePath(`/app/${companyId}/echeances`);
    return { ok: true, message: `Échéances recalculées : ${res.upserted} suivie(s)${res.removed ? `, ${res.removed} retirée(s)` : ""}.` };
  });
}

export async function createDeadlineAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "employees.write");
    const kind = str(fd, "kind");
    if (!(kind in deadlineKindLabels)) throw new HrError("Type d'échéance invalide.");
    const title = str(fd, "title");
    if (title.length < 3) throw new HrError("Décrivez l'échéance.");
    const employeeId = str(fd, "employeeId");
    if (employeeId) {
      if (!UUID_RE.test(employeeId)) throw new HrError("Salarié invalide.");
      await employeeOf(companyId, employeeId);
    }
    const dueDate = isoDate(fd, "dueDate", "Échéance");
    const [row] = await db
      .insert(schema.deadlines)
      .values({ companyId, employeeId: employeeId || null, kind, title: title.slice(0, 200), dueDate, status: "upcoming", sourceType: "manual", sourceId: null })
      .returning({ id: schema.deadlines.id });
    await audit({ action: "deadline.create", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "deadline", entityId: row.id, after: { kind, dueDate } });
    revalidatePath(`/app/${companyId}/echeances`);
    return { ok: true, message: "Échéance ajoutée." };
  });
}

export async function toggleDeadlineAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "employees.write");
    const deadlineId = id(fd, "deadlineId");
    const [d] = await db.select().from(schema.deadlines).where(and(eq(schema.deadlines.id, deadlineId), eq(schema.deadlines.companyId, companyId))).limit(1);
    if (!d) throw new HrError("Échéance introuvable.");
    const status = d.status === "done" ? "upcoming" : "done";
    await db.update(schema.deadlines).set({ status }).where(eq(schema.deadlines.id, d.id));
    await audit({ action: "deadline.toggle", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "deadline", entityId: d.id, before: { status: d.status }, after: { status } });
    await syncDeadlines(companyId);
    revalidatePath(`/app/${companyId}/echeances`);
    revalidatePath(`/app/${companyId}`);
    return { ok: true, message: status === "done" ? "Échéance traitée." : "Échéance rouverte." };
  });
}
