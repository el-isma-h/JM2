"use server";

import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import {
  checkUserTotp,
  consumeToken,
  createSession,
  destroySession,
  elevateSession,
  enableTotp,
  generateTotpSecret,
  getCurrentUser,
  hashPassword,
  issueToken,
  peekToken,
  requireUser,
  totpUri,
  validatePasswordStrength,
  verifyPassword,
} from "@/server/auth";
import { layoutMail, sendMail } from "@/server/mail";
import { audit } from "@/server/audit";
import { appUrl } from "@/lib/env";
import { slugify } from "@/lib/utils";
import { bootstrapCompanyDefaults } from "@/server/company-defaults";

export type ActionState = { error?: string; ok?: boolean; message?: string; data?: Record<string, string> };

const signupSchema = z.object({
  firstName: z.string().trim().min(1, "Prénom requis").max(80),
  lastName: z.string().trim().min(1, "Nom requis").max(80),
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide"),
  password: z.string(),
  orgName: z.string().trim().min(2, "Nom de l'entreprise ou du cabinet requis").max(120),
  orgKind: z.enum(["company", "firm", "group"]),
  consent: z.literal("on", { message: "Vous devez accepter les conditions." }),
});

export async function signupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = signupSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Formulaire invalide" };
  const d = parsed.data;
  const pwErr = validatePasswordStrength(d.password);
  if (pwErr) return { error: `Mot de passe : ${pwErr}` };

  const [existing] = await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, d.email)).limit(1);
  if (existing) return { error: "Un compte existe déjà avec cette adresse. Connectez-vous ou réinitialisez votre mot de passe." };

  const userId = await db.transaction(async (tx) => {
    let slug = slugify(d.orgName) || "organisation";
    const [clash] = await tx.select({ id: schema.tenants.id }).from(schema.tenants).where(eq(schema.tenants.slug, slug)).limit(1);
    if (clash) slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;
    const [tenant] = await tx.insert(schema.tenants).values({ name: d.orgName, kind: d.orgKind, slug }).returning();
    const [user] = await tx
      .insert(schema.users)
      .values({ email: d.email, passwordHash: await hashPassword(d.password), firstName: d.firstName, lastName: d.lastName, tenantId: tenant.id })
      .returning();
    const [company] = await tx
      .insert(schema.companies)
      .values({ tenantId: tenant.id, legalName: d.orgName, onboardingStep: "company" })
      .returning();
    await tx.insert(schema.companyMemberships).values({ companyId: company.id, userId: user.id, role: "owner" });
    await bootstrapCompanyDefaults(tx, company.id);
    return user.id;
  });

  const token = await issueToken("verify_email", { userId, email: d.email, ttlMinutes: 60 * 24 });
  await sendMail({
    to: d.email,
    subject: "Vérifiez votre adresse e-mail",
    html: layoutMail("Bienvenue sur Next RH", `<p>Bonjour ${d.firstName},</p><p>Confirmez votre adresse e-mail pour activer votre espace.</p>`, {
      label: "Vérifier mon adresse",
      url: `${appUrl()}/verification?token=${token}`,
    }),
  });
  await audit({ action: "auth.signup", userId });
  await createSession(userId);
  redirect("/verification");
}

export async function loginAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const code = String(formData.get("code") ?? "").trim();
  if (!email || !password) return { error: "E-mail et mot de passe requis." };
  const [user] = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
  // Délai constant : pas d'indication si le compte existe.
  const ok = user ? await verifyPassword(password, user.passwordHash) : await verifyPassword(password, "$2a$12$abcdefghijklmnopqrstuuWqkV5l7Xb3Q7h7n9zq2Yq5wWnI7cmF1a");
  if (!user || !ok || user.disabledAt) {
    await audit({ action: "auth.login_failed", after: { email } });
    return { error: "Identifiants incorrects." };
  }
  if (user.totpEnabledAt) {
    if (!code) return { data: { needCode: "1" }, error: undefined };
    if (!(await checkUserTotp(user.id, code))) return { data: { needCode: "1" }, error: "Code de vérification incorrect." };
  }
  await createSession(user.id);
  await audit({ action: "auth.login", userId: user.id });
  const next = String(formData.get("next") ?? "");
  redirect(next.startsWith("/") ? next : "/app");
}

export async function logoutAction() {
  const u = await getCurrentUser();
  await destroySession();
  if (u) await audit({ action: "auth.logout", userId: u.id });
  redirect("/connexion");
}

export async function resendVerificationAction(): Promise<ActionState> {
  const user = await requireUser();
  if (user.emailVerified) return { ok: true, message: "Adresse déjà vérifiée." };
  const token = await issueToken("verify_email", { userId: user.id, email: user.email, ttlMinutes: 60 * 24 });
  const res = await sendMail({
    to: user.email,
    subject: "Vérifiez votre adresse e-mail",
    html: layoutMail("Vérification de votre adresse", `<p>Cliquez pour confirmer votre adresse e-mail.</p>`, {
      label: "Vérifier mon adresse",
      url: `${appUrl()}/verification?token=${token}`,
    }),
  });
  return {
    ok: true,
    message:
      res.status === "sent"
        ? "E-mail envoyé."
        : "E-mail journalisé dans la boîte d'envoi (service e-mail non configuré) : un administrateur peut récupérer le lien dans Admin → Boîte d'envoi.",
  };
}

export async function verifyEmailAction(token: string): Promise<ActionState> {
  const row = await consumeToken("verify_email", token);
  if (!row?.userId) return { error: "Lien invalide ou expiré." };
  await db.update(schema.users).set({ emailVerifiedAt: new Date() }).where(eq(schema.users.id, row.userId));
  await audit({ action: "auth.email_verified", userId: row.userId });
  return { ok: true };
}

export async function forgotPasswordAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!email) return { error: "Adresse requise." };
  const [user] = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
  if (user) {
    const token = await issueToken("reset_password", { userId: user.id, email, ttlMinutes: 30 });
    await sendMail({
      to: email,
      subject: "Réinitialisation de votre mot de passe",
      html: layoutMail("Réinitialiser votre mot de passe", `<p>Ce lien est valable 30 minutes. Si vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail.</p>`, {
        label: "Choisir un nouveau mot de passe",
        url: `${appUrl()}/reinitialiser?token=${token}`,
      }),
    });
    await audit({ action: "auth.reset_requested", userId: user.id });
  }
  return { ok: true, message: "Si un compte existe pour cette adresse, un e-mail de réinitialisation a été envoyé." };
}

export async function resetPasswordAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const token = String(formData.get("token") ?? "");
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");
  if (password !== confirm) return { error: "Les deux mots de passe diffèrent." };
  const pwErr = validatePasswordStrength(password);
  if (pwErr) return { error: `Mot de passe : ${pwErr}` };
  const row = await consumeToken("reset_password", token);
  if (!row?.userId) return { error: "Lien invalide ou expiré." };
  await db.update(schema.users).set({ passwordHash: await hashPassword(password) }).where(eq(schema.users.id, row.userId));
  await db.delete(schema.sessions).where(eq(schema.sessions.userId, row.userId));
  await audit({ action: "auth.password_reset", userId: row.userId });
  return { ok: true, message: "Mot de passe modifié. Vous pouvez vous connecter." };
}

// ---------- TOTP ----------

export async function startTotpSetupAction(): Promise<ActionState> {
  const user = await requireUser();
  const secret = generateTotpSecret();
  return { ok: true, data: { secret, uri: totpUri(user.email, secret) } };
}

export async function confirmTotpSetupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await requireUser();
  const secret = String(formData.get("secret") ?? "");
  const code = String(formData.get("code") ?? "");
  const ok = await enableTotp(user.id, secret, code);
  if (!ok) return { error: "Code incorrect. Vérifiez l'heure de votre téléphone et réessayez." };
  await elevateSession(user.sessionId);
  await audit({ action: "auth.totp_enabled", userId: user.id });
  const [u] = await db.select({ codes: schema.users.recoveryCodesHash }).from(schema.users).where(eq(schema.users.id, user.id));
  void u;
  return { ok: true, message: "Authentification renforcée activée." };
}

/** Vérification renforcée pour un accès sensible (RIB, exports, clôture). */
export async function elevateAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await requireUser();
  const code = String(formData.get("code") ?? "");
  const password = String(formData.get("password") ?? "");
  if (user.totpEnabled) {
    if (!(await checkUserTotp(user.id, code))) return { error: "Code incorrect." };
  } else {
    const [u] = await db.select().from(schema.users).where(eq(schema.users.id, user.id)).limit(1);
    if (!u || !(await verifyPassword(password, u.passwordHash))) return { error: "Mot de passe incorrect." };
  }
  await elevateSession(user.sessionId);
  await audit({ action: "auth.elevated", userId: user.id });
  const next = String(formData.get("next") ?? "");
  if (next.startsWith("/")) redirect(next);
  return { ok: true };
}

// ---------- Invitations ----------

export async function acceptInvitationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const token = String(formData.get("token") ?? "");
  const inv = await peekToken("invite", token);
  if (!inv) return { error: "Invitation invalide ou expirée." };
  const payload = inv.payload as { invitationId: string };
  const [invitation] = await db.select().from(schema.invitations).where(eq(schema.invitations.id, payload.invitationId)).limit(1);
  if (!invitation || invitation.status !== "pending") return { error: "Invitation déjà utilisée ou révoquée." };

  const current = await getCurrentUser();
  let userId = current?.id;
  if (!userId) {
    const firstName = String(formData.get("firstName") ?? "").trim();
    const lastName = String(formData.get("lastName") ?? "").trim();
    const password = String(formData.get("password") ?? "");
    if (!firstName || !lastName) return { error: "Prénom et nom requis." };
    const pwErr = validatePasswordStrength(password);
    if (pwErr) return { error: `Mot de passe : ${pwErr}` };
    const [existing] = await db.select().from(schema.users).where(eq(schema.users.email, invitation.email)).limit(1);
    if (existing) {
      if (!(await verifyPassword(password, existing.passwordHash))) return { error: "Un compte existe pour cette adresse : saisissez son mot de passe." };
      userId = existing.id;
    } else {
      const [u] = await db
        .insert(schema.users)
        .values({
          email: invitation.email,
          passwordHash: await hashPassword(password),
          firstName,
          lastName,
          tenantId: invitation.tenantId,
          emailVerifiedAt: new Date(),
        })
        .returning();
      userId = u.id;
    }
  } else if (current && current.email !== invitation.email) {
    return { error: `Cette invitation est destinée à ${invitation.email}. Déconnectez-vous pour l'accepter.` };
  }

  await db.transaction(async (tx) => {
    if (invitation.companyId) {
      const [m] = await tx
        .select()
        .from(schema.companyMemberships)
        .where(and(eq(schema.companyMemberships.companyId, invitation.companyId), eq(schema.companyMemberships.userId, userId!)))
        .limit(1);
      if (!m)
        await tx.insert(schema.companyMemberships).values({
          companyId: invitation.companyId,
          userId: userId!,
          role: invitation.role as (typeof schema.companyRoleEnum.enumValues)[number],
        });
      if (invitation.employeeId) await tx.update(schema.employees).set({ userId: userId! }).where(eq(schema.employees.id, invitation.employeeId));
    }
    await tx.update(schema.invitations).set({ status: "accepted", acceptedAt: new Date() }).where(eq(schema.invitations.id, invitation.id));
  });
  await consumeToken("invite", token);
  await audit({ action: "auth.invitation_accepted", userId, companyId: invitation.companyId, tenantId: invitation.tenantId });
  if (!current) await createSession(userId!);
  redirect("/app");
}
