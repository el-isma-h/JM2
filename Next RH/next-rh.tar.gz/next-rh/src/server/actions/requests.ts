"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { audit } from "@/server/audit";
import type { ActionState } from "./auth";
import { HrError, id, optStr, requireAnyPermission, runAction, str, UUID_RE } from "@/server/hr/common";
import { issueDownloadLink } from "@/server/documents/store";
import { CORRECTABLE_FIELDS, sanitizeChanges, type CorrectableField } from "@/server/hr/requests";

async function loadRequest(companyId: string, requestId: string) {
  const [r] = await db.select().from(schema.hrRequests).where(and(eq(schema.hrRequests.id, requestId), eq(schema.hrRequests.companyId, companyId))).limit(1);
  if (!r) throw new HrError("Demande introuvable.");
  return r;
}

export async function assignHrRequestAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const r = await loadRequest(companyId, id(fd, "requestId"));
    const assignee = str(fd, "assignedTo");
    let assignedTo: string | null = null;
    if (assignee) {
      if (!UUID_RE.test(assignee)) throw new HrError("Destinataire invalide.");
      const [m] = await db
        .select({ id: schema.companyMemberships.id })
        .from(schema.companyMemberships)
        .where(and(eq(schema.companyMemberships.companyId, companyId), eq(schema.companyMemberships.userId, assignee)))
        .limit(1);
      if (!m) throw new HrError("Cette personne n'a pas accès à l'entreprise.");
      assignedTo = assignee;
    }
    await db.update(schema.hrRequests).set({ assignedTo }).where(eq(schema.hrRequests.id, r.id));
    await audit({ action: "hr_request.assign", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "hr_request", entityId: r.id, before: { assignedTo: r.assignedTo }, after: { assignedTo } });
    revalidatePath(`/app/${companyId}/demandes`);
    return { ok: true, message: assignedTo ? "Demande assignée." : "Assignation retirée." };
  });
}

/**
 * Réponse à une demande. Pour une correction d'informations acceptée, les champs autorisés (coordonnées, adresse)
 * sont appliqués à la fiche salarié, avec trace avant/après.
 */
export async function answerHrRequestAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const r = await loadRequest(companyId, id(fd, "requestId"));
    if (r.status !== "pending") throw new HrError("Demande déjà traitée.");
    const decision = str(fd, "decision");
    const answer = optStr(fd, "answer");
    if (!["approve", "reject"].includes(decision)) throw new HrError("Décision inconnue.");
    if (decision === "reject" && !answer) throw new HrError("Expliquez le refus au salarié.");
    const status = decision === "approve" ? ("approved" as const) : ("rejected" as const);

    let applied: Partial<Record<CorrectableField, string>> = {};
    if (status === "approved" && r.kind === "correction_informations") {
      if (!r.employeeId) throw new HrError("Demande sans salarié rattaché.");
      const payload = (r.payload as { changes?: Record<string, unknown> }) ?? {};
      applied = sanitizeChanges(payload.changes ?? {});
      if (!Object.keys(applied).length) throw new HrError("Aucune modification valide à appliquer.");
      const [emp] = await db.select().from(schema.employees).where(and(eq(schema.employees.id, r.employeeId), eq(schema.employees.companyId, companyId))).limit(1);
      if (!emp) throw new HrError("Salarié introuvable.");
      const before: Record<string, string | null> = {};
      for (const k of Object.keys(applied) as CorrectableField[]) before[k] = emp[k] ?? null;
      await db.update(schema.employees).set(applied).where(eq(schema.employees.id, emp.id));
      await audit({ action: "employee.update", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "employee", entityId: emp.id, before, after: { ...applied, via: `hr_request:${r.id}` } });
    }
    await db.update(schema.hrRequests).set({ status, answer, decidedAt: new Date(), assignedTo: r.assignedTo ?? ctx.user.id }).where(eq(schema.hrRequests.id, r.id));
    await audit({ action: `hr_request.${decision}`, userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "hr_request", entityId: r.id, before: { status: r.status }, after: { status, applied: Object.keys(applied) } });
    revalidatePath(`/app/${companyId}/demandes`);
    revalidatePath(`/app/${companyId}`);
    const n = Object.keys(applied).length;
    return {
      ok: true,
      message: n ? `Demande acceptée : ${n} champ(s) mis à jour (${Object.keys(applied).map((k) => CORRECTABLE_FIELDS[k as CorrectableField].label.toLowerCase()).join(", ")}).` : status === "approved" ? "Demande traitée." : "Demande refusée.",
    };
  });
}

/** Lien de téléchargement d'un justificatif (absence, frais, formation, dépôt salarié) pour le service RH. */
export async function proofLinkAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireAnyPermission(companyId, ["documents.read", "requests.approve"]);
    const documentId = id(fd, "documentId");
    const [doc] = await db
      .select({ id: schema.documents.id, category: schema.documents.category })
      .from(schema.documents)
      .where(and(eq(schema.documents.id, documentId), eq(schema.documents.companyId, companyId)))
      .limit(1);
    if (!doc || doc.category !== "justificatif") throw new HrError("Justificatif introuvable.");
    const url = await issueDownloadLink(doc.id, ctx.user.id);
    await audit({ action: "document.link", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "document", entityId: doc.id });
    return { ok: true, data: { url } };
  });
}
