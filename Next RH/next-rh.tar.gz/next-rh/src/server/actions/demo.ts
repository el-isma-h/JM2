"use server";

import { redirect } from "next/navigation";
import { and, eq, gt, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { createSession } from "@/server/auth";
import { audit } from "@/server/audit";
import { seedDemo } from "@/server/demo/seed";
import type { ActionState } from "./auth";

/** Plafond global de démonstrations créées par heure (protection contre l'abus). */
const MAX_DEMOS_PER_HOUR = 300;

/**
 * Crée un espace de démonstration neuf pour ce visiteur, ouvre une session et redirige.
 * L'espace est supprimé automatiquement après 24 heures (tâche demo:cleanup).
 */
export async function enterDemoAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const as = formData.get("as") === "employee" ? "employee" : "manager";
  const [{ n }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.tenants)
    .where(and(eq(schema.tenants.isDemo, true), gt(schema.tenants.createdAt, new Date(Date.now() - 3600_000))));
  if (n >= MAX_DEMOS_PER_HOUR) return { error: "Trop de démonstrations ont été ouvertes ces dernières minutes. Réessayez dans un moment." };

  let target: string;
  try {
    const demo = await seedDemo();
    const userId = as === "employee" ? demo.employeeUserId : demo.ownerUserId;
    await createSession(userId);
    await audit({ action: "demo.enter", userId, tenantId: demo.tenantId, companyId: demo.companyId, entityType: "tenant", entityId: demo.tenantId, after: { as } });
    target = as === "employee" ? "/moi" : `/app/${demo.companyId}`;
  } catch (e) {
    console.error("demo.enter", e);
    return { error: "La démonstration n'a pas pu être préparée. Réessayez dans un instant." };
  }
  redirect(target);
}
