"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authErrorMessage } from "@/server/guard";
import { AssistantError, confirmMessageAction, handleMessage } from "@/server/assistant/orchestrator";
import { DraftError } from "@/server/documents/drafting";
import type { ActionState } from "./auth";

const uuid = z.string().regex(/^[0-9a-f-]{36}$/);

function fail(e: unknown): ActionState {
  const auth = authErrorMessage(e);
  if (auth) return { error: auth };
  if (e instanceof AssistantError || e instanceof DraftError) return { error: e.message };
  if (e instanceof z.ZodError) return { error: "Requête invalide." };
  console.error("[assistant]", e);
  return { error: "L'assistant n'a pas pu traiter la demande. Réessayez." };
}

export async function sendAssistantMessageAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const companyId = uuid.parse(fd.get("companyId"));
    const convRaw = String(fd.get("conversationId") ?? "");
    const res = await handleMessage(companyId, convRaw ? uuid.parse(convRaw) : null, String(fd.get("text") ?? ""));
    revalidatePath(`/app/${companyId}/assistant`);
    return { ok: true, data: { conversationId: res.conversationId, message: JSON.stringify(res.message) } };
  } catch (e) {
    return fail(e);
  }
}

export async function confirmAssistantAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const companyId = uuid.parse(fd.get("companyId"));
    const res = await confirmMessageAction(companyId, uuid.parse(fd.get("messageId")));
    revalidatePath(`/app/${companyId}/assistant`);
    return { ok: true, message: "Action confirmée et exécutée.", data: { conversationId: res.conversationId, message: JSON.stringify(res.message) } };
  } catch (e) {
    return fail(e);
  }
}
