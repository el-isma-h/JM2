"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { audit } from "@/server/audit";
import { createDocument, issueDownloadLink } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { canSeeDocument, canSeeRestricted, RETENTION_YEARS, SALARY_CATEGORIES } from "@/server/documents/visibility";
import type { ActionState } from "./auth";

const uuid = z.string().regex(/^[0-9a-f-]{36}$/, "Identifiant invalide");
const visibility = z.enum(["company", "employee", "restricted"]);
const category = z.enum(schema.documentCategoryEnum.enumValues);

const uploadSchema = z.object({
  companyId: uuid,
  category,
  visibility,
  title: z.string().trim().max(200).optional(),
  employeeId: uuid.optional().or(z.literal("").transform(() => undefined)),
  previousVersionId: uuid.optional().or(z.literal("").transform(() => undefined)),
});

const fail = (e: unknown): ActionState => ({ error: authErrorMessage(e) ?? (e instanceof Error && e.name === "UserError" ? e.message : "Une erreur est survenue. Réessayez.") });
class UserError extends Error {
  name = "UserError";
}

/** Upload d'un ou plusieurs fichiers (contrôle MIME, signature, 20 Mo max), ou d'une nouvelle version. */
export async function uploadDocumentsAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const parsed = uploadSchema.safeParse(Object.fromEntries([...fd.entries()].filter(([, v]) => typeof v === "string")));
    if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Formulaire invalide." };
    const input = parsed.data;
    const ctx = await requireCompany(input.companyId, "documents.write");
    const restrictedNeeded = input.visibility === "restricted" || (SALARY_CATEGORIES as readonly string[]).includes(input.category);
    if (restrictedNeeded && !canSeeRestricted(ctx.permissions)) throw new UserError("Ce type de document est réservé aux personnes habilitées aux salaires ou à la validation de paie.");
    if (input.visibility === "employee" && !input.employeeId) throw new UserError("Choisissez le salarié pour une visibilité « Salarié ».");
    if (input.employeeId) {
      const [e] = await db.select({ id: schema.employees.id }).from(schema.employees).where(and(eq(schema.employees.id, input.employeeId), eq(schema.employees.companyId, ctx.company.id))).limit(1);
      if (!e) throw new UserError("Salarié introuvable dans cette entreprise.");
    }
    let previous: typeof schema.documents.$inferSelect | undefined;
    if (input.previousVersionId) {
      [previous] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, input.previousVersionId), eq(schema.documents.companyId, ctx.company.id))).limit(1);
      if (!previous || !canSeeDocument(previous, ctx.permissions)) throw new UserError("Document d'origine introuvable.");
    }
    const files = fd.getAll("files").filter((f): f is File => typeof f === "object" && f !== null && "arrayBuffer" in f && (f as File).size > 0);
    if (!files.length) throw new UserError("Sélectionnez au moins un fichier.");
    if (files.length > 10) throw new UserError("10 fichiers maximum par envoi.");
    if (previous && files.length > 1) throw new UserError("Une nouvelle version se dépose un fichier à la fois.");
    // Contrôle de tous les fichiers avant d'en enregistrer un seul.
    const checked: { file: File; data: Buffer; mime: string }[] = [];
    for (const file of files) {
      const data = Buffer.from(await file.arrayBuffer());
      const res = checkUpload({ name: file.name, type: file.type, size: data.length, head: new Uint8Array(data.subarray(0, 16)) });
      if (!res.ok) throw new UserError(`${file.name} : ${res.error}`);
      checked.push({ file, data, mime: res.mime });
    }
    const created: string[] = [];
    for (const { file, data, mime } of checked) {
      const doc = await createDocument({
        companyId: ctx.company.id,
        employeeId: input.employeeId ?? previous?.employeeId ?? null,
        category: input.category,
        visibility: input.visibility,
        title: input.title?.trim() || previous?.title || file.name.replace(/\.[^.]+$/, ""),
        fileName: file.name,
        mimeType: mime,
        data,
        sourceType: "upload",
        uploadedBy: ctx.user.id,
        previousVersionId: previous?.id ?? null,
        retentionYears: RETENTION_YEARS[input.category]?.years,
        isDemo: ctx.company.isDemo,
      });
      created.push(doc.id);
      await audit({ action: previous ? "document.new_version" : "document.upload", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document", entityId: doc.id, after: { fileName: file.name, category: input.category, visibility: input.visibility, version: doc.version } });
    }
    revalidatePath(`/app/${ctx.company.id}/documents`);
    return { ok: true, message: previous ? "Nouvelle version enregistrée." : `${created.length} document(s) enregistré(s).`, data: { id: created[0] } };
  } catch (e) {
    return fail(e);
  }
}

/** Lien de téléchargement temporaire (15 minutes, lié à l'utilisateur). */
export async function downloadLinkAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const companyId = uuid.parse(fd.get("companyId"));
    const documentId = uuid.parse(fd.get("documentId"));
    const ctx = await requireCompany(companyId, "documents.read");
    const [doc] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, documentId), eq(schema.documents.companyId, ctx.company.id))).limit(1);
    if (!doc || !canSeeDocument(doc, ctx.permissions)) throw new UserError("Document introuvable.");
    const url = await issueDownloadLink(doc.id, ctx.user.id);
    await audit({ action: "document.link_issued", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document", entityId: doc.id });
    return { ok: true, message: "Lien valable 15 minutes.", data: { url } };
  } catch (e) {
    if (e instanceof z.ZodError) return { error: "Requête invalide." };
    return fail(e);
  }
}

/** Changement de visibilité (audité). */
export async function updateVisibilityAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const companyId = uuid.parse(fd.get("companyId"));
    const documentId = uuid.parse(fd.get("documentId"));
    const next = visibility.parse(fd.get("visibility"));
    const ctx = await requireCompany(companyId, "documents.write");
    const [doc] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, documentId), eq(schema.documents.companyId, ctx.company.id))).limit(1);
    if (!doc || !canSeeDocument(doc, ctx.permissions)) throw new UserError("Document introuvable.");
    if (next === "employee" && !doc.employeeId) throw new UserError("Ce document n'est rattaché à aucun salarié.");
    if (next === "restricted" && !canSeeRestricted(ctx.permissions)) throw new UserError("Vous ne pourriez plus consulter ce document : la visibilité restreinte est réservée aux habilités salaires ou validation de paie.");
    await db.update(schema.documents).set({ visibility: next }).where(eq(schema.documents.id, doc.id));
    await audit({ action: "document.visibility", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document", entityId: doc.id, before: { visibility: doc.visibility }, after: { visibility: next } });
    revalidatePath(`/app/${ctx.company.id}/documents`);
    revalidatePath(`/app/${ctx.company.id}/documents/${doc.id}`);
    return { ok: true, message: "Visibilité mise à jour." };
  } catch (e) {
    if (e instanceof z.ZodError) return { error: "Requête invalide." };
    return fail(e);
  }
}
