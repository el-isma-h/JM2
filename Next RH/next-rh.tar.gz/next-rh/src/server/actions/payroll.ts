"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireCompany, type Permission } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { audit } from "@/server/audit";
import { createDocument, issueDownloadLink } from "@/server/documents/store";
import type { ActionState } from "@/server/actions/auth";
import {
  checkPeriod,
  closePeriod,
  collectVariables,
  computePeriod,
  controlPeriod,
  distributePeriod,
  finalizePeriod,
  openPeriod,
  PayrollError,
  validatePeriod,
} from "@/server/payroll/cycle";
import { controlFiling, prepareFilings, recordFilingAcknowledgement, requestFilingSend } from "@/server/payroll/filings";
import { EDITABLE_STATUSES } from "@/server/payroll/inputs";

const uuid = z.string().uuid();

function fail(e: unknown): ActionState {
  const auth = authErrorMessage(e);
  if (auth) return { error: auth };
  if (e instanceof PayrollError) return { error: e.message };
  console.error("[payroll]", e);
  return { error: "Erreur inattendue : l'opération n'a pas été réalisée. Réessayez ou contactez le support." };
}

async function periodOf(companyId: string, periodId: string) {
  const [p] = await db
    .select()
    .from(schema.payrollPeriods)
    .where(and(eq(schema.payrollPeriods.id, periodId), eq(schema.payrollPeriods.companyId, companyId)))
    .limit(1);
  if (!p) throw new PayrollError("Période introuvable pour cette entreprise.");
  return p;
}

function refresh(companyId: string, periodId?: string) {
  revalidatePath(`/app/${companyId}/paie`);
  if (periodId) revalidatePath(`/app/${companyId}/paie/${periodId}`);
  revalidatePath(`/app/${companyId}/declarations`);
}

// ---------------------------------------------------------------- Périodes

export async function openPeriodAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = z.object({ companyId: uuid, month: z.string().regex(/^\d{4}-\d{2}$/, "Choisissez un mois.") }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Formulaire invalide" };
  try {
    const ctx = await requireCompany(parsed.data.companyId, "payroll.prepare");
    const [y, m] = parsed.data.month.split("-").map(Number);
    const { periodId } = await openPeriod(ctx.company.id, y, m, ctx.user.id);
    refresh(ctx.company.id, periodId);
    return { ok: true, message: "Période ouverte.", data: { periodId } };
  } catch (e) {
    return fail(e);
  }
}

const STEP_PERMS: Record<string, Permission> = {
  collect: "payroll.prepare",
  check: "payroll.prepare",
  compute: "payroll.prepare",
  control: "payroll.prepare",
  validate: "payroll.validate",
  finalize: "payroll.validate",
  distribute: "payroll.validate",
  close: "payroll.close",
};

export async function runStepAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = z.object({ companyId: uuid, periodId: uuid, step: z.enum(["collect", "check", "compute", "control", "validate", "finalize", "distribute", "close"]) }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: "Action invalide." };
  const { companyId, periodId, step } = parsed.data;
  try {
    const ctx = await requireCompany(companyId, STEP_PERMS[step]);
    await periodOf(ctx.company.id, periodId);
    const u = ctx.user.id;
    let message = "";
    switch (step) {
      case "collect": {
        const s = await collectVariables(periodId, u);
        message = `${s.variables.total} variable(s) collectée(s) pour ${s.employees} salarié(s), ${s.items.length} point(s) à examiner.`;
        break;
      }
      case "check":
        await checkPeriod(periodId, u);
        message = "Vérification enregistrée : vous pouvez calculer la paie.";
        break;
      case "compute": {
        const r = await computePeriod(periodId, u);
        message = `${r.computed} bulletin(s) calculé(s), ${r.blocked} bloqué(s), ${r.anomalies} anomalie(s) ouverte(s).`;
        break;
      }
      case "control":
        await controlPeriod(periodId, u);
        message = "Contrôle terminé : la paie peut être validée.";
        break;
      case "validate":
        await validatePeriod(periodId, u);
        message = "Paie validée. Les bulletins ne peuvent plus être modifiés.";
        break;
      case "finalize": {
        const r = await finalizePeriod(periodId, u);
        message = `${r.documents} bulletin(s) PDF généré(s).`;
        break;
      }
      case "distribute": {
        const r = await distributePeriod(periodId, u);
        message = r.demo
          ? `${r.distributed} bulletin(s) mis à disposition. Démonstration : aucun e-mail n'a été envoyé.`
          : `${r.distributed} bulletin(s) mis à disposition, ${r.mailed} notification(s) envoyée(s).`;
        break;
      }
      case "close":
        await closePeriod(periodId, u);
        message = "Période clôturée.";
        break;
    }
    refresh(companyId, periodId);
    return { ok: true, message };
  } catch (e) {
    return fail(e);
  }
}

// ---------------------------------------------------------------- Variables

const KINDS = ["prime", "commission", "heures_sup", "heures_comp", "absence", "avantage_nature", "titres_restaurant", "indemnite", "acompte", "regularisation"] as const;

const decimalOpt = z
  .string()
  .trim()
  .transform((s) => s.replace(",", "."))
  .refine((s) => s === "" || /^-?\d+(\.\d{1,2})?$/.test(s), "Nombre invalide (2 décimales au plus).")
  .optional();

const variableSchema = z.object({
  companyId: uuid,
  periodId: uuid,
  variableId: uuid.optional(),
  employeeId: uuid,
  kind: z.enum(KINDS),
  label: z.string().trim().min(2, "Indiquez un libellé.").max(120),
  quantity: decimalOpt,
  rate: decimalOpt,
  amount: decimalOpt,
  note: z.string().trim().max(200).optional(),
});

function toCents(s: string | undefined) {
  if (!s) return null;
  return Math.round(Number(s) * 100);
}

export async function saveVariableAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = variableSchema.safeParse(Object.fromEntries([...fd.entries()].filter(([, v]) => v !== "")));
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Formulaire invalide" };
  const d = parsed.data;
  try {
    const ctx = await requireCompany(d.companyId, "payroll.prepare");
    const period = await periodOf(ctx.company.id, d.periodId);
    if (!EDITABLE_STATUSES.has(period.status)) return { error: "La période est validée : ajoutez la variable sur le mois suivant." };
    const [emp] = await db.select({ id: schema.employees.id }).from(schema.employees).where(and(eq(schema.employees.id, d.employeeId), eq(schema.employees.companyId, ctx.company.id))).limit(1);
    if (!emp) return { error: "Salarié introuvable." };
    const needsQty = ["heures_sup", "heures_comp", "absence", "titres_restaurant"].includes(d.kind);
    const needsAmount = !["heures_sup", "heures_comp", "absence"].includes(d.kind);
    if (needsQty && !d.quantity) return { error: d.kind === "absence" ? "Indiquez le nombre de jours." : d.kind === "titres_restaurant" ? "Indiquez le nombre de titres." : "Indiquez le nombre d'heures." };
    if (needsAmount && !d.amount) return { error: d.kind === "titres_restaurant" ? "Indiquez la valeur d'un titre." : "Indiquez le montant." };
    if (d.kind === "absence" && !["CP", "RTT", "CSS", "EVF"].includes((d.note ?? "").toUpperCase())) return { error: "Choisissez le type d'absence." };
    if (d.kind === "titres_restaurant" && !d.rate) return { error: "Indiquez la part patronale en %." };
    const values = {
      kind: d.kind,
      label: d.label,
      quantity: d.quantity || null,
      rate: d.rate || null,
      amountCents: toCents(d.amount),
      note: d.kind === "absence" ? (d.note ?? "").toUpperCase() : d.note || null,
      status: "validated" as const,
      validatedBy: ctx.user.id,
    };
    if (d.variableId) {
      const [v] = await db.select().from(schema.payrollVariables).where(and(eq(schema.payrollVariables.id, d.variableId), eq(schema.payrollVariables.periodId, period.id))).limit(1);
      if (!v) return { error: "Variable introuvable." };
      if (v.source !== "manual") return { error: "Cette variable vient d'un autre module (congés, temps, frais) : modifiez-la à la source." };
      await db.update(schema.payrollVariables).set({ ...values, employeeId: d.employeeId }).where(eq(schema.payrollVariables.id, v.id));
      await audit({ action: "payroll.variable.update", userId: ctx.user.id, companyId: ctx.company.id, entityType: "payroll_variable", entityId: v.id, before: v, after: values });
    } else {
      const [row] = await db
        .insert(schema.payrollVariables)
        .values({ ...values, periodId: period.id, employeeId: d.employeeId, source: "manual", createdBy: ctx.user.id })
        .returning({ id: schema.payrollVariables.id });
      await audit({ action: "payroll.variable.create", userId: ctx.user.id, companyId: ctx.company.id, entityType: "payroll_variable", entityId: row.id, after: values });
    }
    refresh(ctx.company.id, period.id);
    return { ok: true, message: "Variable enregistrée. Relancez le calcul pour la prendre en compte." };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteVariableAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = z.object({ companyId: uuid, periodId: uuid, variableId: uuid }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: "Action invalide." };
  try {
    const ctx = await requireCompany(parsed.data.companyId, "payroll.prepare");
    const period = await periodOf(ctx.company.id, parsed.data.periodId);
    if (!EDITABLE_STATUSES.has(period.status)) return { error: "La période est validée : la variable ne peut plus être supprimée." };
    const [v] = await db.select().from(schema.payrollVariables).where(and(eq(schema.payrollVariables.id, parsed.data.variableId), eq(schema.payrollVariables.periodId, period.id))).limit(1);
    if (!v) return { error: "Variable introuvable." };
    if (v.source !== "manual") return { error: "Cette variable vient d'un autre module : annulez l'élément d'origine (congé, feuille de temps, note de frais)." };
    await db.delete(schema.payrollVariables).where(eq(schema.payrollVariables.id, v.id));
    await audit({ action: "payroll.variable.delete", userId: ctx.user.id, companyId: ctx.company.id, entityType: "payroll_variable", entityId: v.id, before: v });
    refresh(ctx.company.id, period.id);
    return { ok: true, message: "Variable supprimée." };
  } catch (e) {
    return fail(e);
  }
}

// ---------------------------------------------------------------- Anomalies

export async function decideAnomalyAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = z.object({ companyId: uuid, periodId: uuid, anomalyId: uuid, decision: z.enum(["acknowledged", "resolved", "open"]) }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: "Action invalide." };
  try {
    const ctx = await requireCompany(parsed.data.companyId, "payroll.prepare");
    const period = await periodOf(ctx.company.id, parsed.data.periodId);
    if (!EDITABLE_STATUSES.has(period.status)) return { error: "La période est validée." };
    const [a] = await db.select().from(schema.payrollAnomalies).where(and(eq(schema.payrollAnomalies.id, parsed.data.anomalyId), eq(schema.payrollAnomalies.periodId, period.id))).limit(1);
    if (!a) return { error: "Anomalie introuvable." };
    if (a.severity === "blocking" && parsed.data.decision !== "open") return { error: "Une anomalie bloquante se lève en corrigeant les données, puis en relançant le calcul." };
    await db
      .update(schema.payrollAnomalies)
      .set({ status: parsed.data.decision, resolvedBy: parsed.data.decision === "open" ? null : ctx.user.id, resolvedAt: parsed.data.decision === "open" ? null : new Date() })
      .where(eq(schema.payrollAnomalies.id, a.id));
    // Une décision rend le contrôle à refaire.
    if (period.status === "controlled") await db.update(schema.payrollPeriods).set({ status: "computed" }).where(eq(schema.payrollPeriods.id, period.id));
    await audit({ action: `payroll.anomaly.${parsed.data.decision}`, userId: ctx.user.id, companyId: ctx.company.id, entityType: "payroll_anomaly", entityId: a.id, before: { status: a.status }, after: { status: parsed.data.decision } });
    refresh(ctx.company.id, period.id);
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

// ---------------------------------------------------------------- Déclarations et exports

export async function prepareFilingsAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = z
    .object({ companyId: uuid, periodId: uuid, debtorIban: z.string().trim().max(40).optional(), debtorBic: z.string().trim().max(11).optional(), debtorName: z.string().trim().max(70).optional() })
    .safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: "Formulaire invalide." };
  const d = parsed.data;
  try {
    const ctx = await requireCompany(d.companyId, ...(d.debtorIban ? (["payroll.prepare", "employees.bank.read"] as Permission[]) : (["payroll.prepare"] as Permission[])));
    await periodOf(ctx.company.id, d.periodId);
    const res = await prepareFilings(d.periodId, ctx.user.id, { debtorIban: d.debtorIban || null, debtorBic: d.debtorBic || null, debtorName: d.debtorName || null });
    if (d.debtorIban) await audit({ action: "bank.view", userId: ctx.user.id, companyId: ctx.company.id, entityType: "payroll_period", entityId: d.periodId, after: { purpose: "virement_sepa" } });
    refresh(ctx.company.id, d.periodId);
    const skipped = res.filter((r) => r.skipped).length;
    return { ok: true, message: `${res.length - skipped} document(s) préparé(s)${skipped ? `, ${skipped} conservé(s) car un envoi est en cours` : ""}.` };
  } catch (e) {
    return fail(e);
  }
}

export async function filingAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = z.object({ companyId: uuid, filingId: uuid, op: z.enum(["control", "request_send"]) }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: "Action invalide." };
  const { companyId, filingId, op } = parsed.data;
  try {
    const ctx = await requireCompany(companyId, op === "request_send" ? "filings.send" : "payroll.prepare");
    if (op === "control") await controlFiling(filingId, ctx.company.id, ctx.user.id);
    else await requestFilingSend(filingId, ctx.company.id, ctx.user.id, ctx.company.isDemo);
    refresh(ctx.company.id);
    return { ok: true, message: op === "control" ? "Document marqué comme contrôlé." : "Envoi demandé. Déposez le fichier puis enregistrez l'accusé." };
  } catch (e) {
    return fail(e);
  }
}

export async function recordAcknowledgementAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = z
    .object({ companyId: uuid, filingId: uuid, outcome: z.enum(["sent", "accepted", "rejected"]), reference: z.string().trim().max(120).optional(), reason: z.string().trim().max(500).optional() })
    .safeParse(Object.fromEntries([...fd.entries()].filter(([k]) => k !== "file")));
  if (!parsed.success) return { error: "Formulaire invalide." };
  const d = parsed.data;
  try {
    const ctx = await requireCompany(d.companyId, "filings.send");
    let fileDocumentId: string | null = null;
    const file = fd.get("file");
    if (file instanceof File && file.size > 0) {
      if (file.size > 5 * 1024 * 1024) return { error: "Fichier de retour trop volumineux (5 Mo au plus)." };
      const doc = await createDocument({
        companyId: ctx.company.id,
        category: "export",
        visibility: "restricted",
        title: `Accusé : ${file.name}`,
        fileName: file.name,
        mimeType: file.type || "application/octet-stream",
        data: Buffer.from(await file.arrayBuffer()),
        sourceType: "payroll_filing_ack",
        sourceId: d.filingId,
        uploadedBy: ctx.user.id,
        isDemo: ctx.company.isDemo,
      });
      fileDocumentId = doc.id;
    }
    await recordFilingAcknowledgement(d.filingId, ctx.company.id, ctx.user.id, { outcome: d.outcome, reference: d.reference || null, fileDocumentId, reason: d.reason || null });
    refresh(ctx.company.id);
    return { ok: true, message: "Accusé enregistré." };
  } catch (e) {
    return fail(e);
  }
}

/** Lien de téléchargement temporaire d'un document de paie (bulletin ou export) de l'entreprise. */
export async function downloadLinkAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = z.object({ companyId: uuid, documentId: uuid }).safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: "Action invalide." };
  try {
    const ctx = await requireCompany(parsed.data.companyId, "payroll.prepare");
    const [doc] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, parsed.data.documentId), eq(schema.documents.companyId, ctx.company.id))).limit(1);
    if (!doc || (doc.category !== "bulletin" && doc.category !== "export")) return { error: "Document introuvable." };
    if (doc.category === "bulletin" && !ctx.permissions.has("salaries.read")) return { error: "Vous n'avez pas l'habilitation pour consulter les bulletins." };
    const url = await issueDownloadLink(doc.id, ctx.user.id);
    await audit({ action: "document.download_link", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document", entityId: doc.id });
    return { ok: true, data: { url } };
  } catch (e) {
    return fail(e);
  }
}
