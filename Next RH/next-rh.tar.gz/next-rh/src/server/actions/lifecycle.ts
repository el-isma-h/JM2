"use server";

import { revalidatePath } from "next/cache";
import { randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { audit } from "@/server/audit";
import type { ActionState } from "./auth";
import { employeeOf, HrError, id, isoDate, optStr, runAction, str } from "@/server/hr/common";
import { addDaysIso } from "@/server/hr/calc";
import { TEMPLATES, type TaskOwner, type WorkflowKind, type WorkflowTask } from "@/server/hr/lifecycle";

const KINDS: WorkflowKind[] = ["onboarding", "offboarding", "mobility", "return"];
const OWNERS: TaskOwner[] = ["rh", "manager", "it"];

async function loadWorkflow(companyId: string, workflowId: string) {
  const [row] = await db
    .select({ w: schema.lifecycleWorkflows })
    .from(schema.lifecycleWorkflows)
    .innerJoin(schema.employees, eq(schema.employees.id, schema.lifecycleWorkflows.employeeId))
    .where(and(eq(schema.lifecycleWorkflows.id, workflowId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!row) throw new HrError("Parcours introuvable.");
  return row.w;
}

export async function createWorkflowAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "employees.write");
    const employeeId = id(fd, "employeeId");
    const emp = await employeeOf(companyId, employeeId);
    const kind = str(fd, "kind") as WorkflowKind;
    if (!KINDS.includes(kind)) throw new HrError("Type de parcours invalide.");
    const targetDate = isoDate(fd, "targetDate", "Date cible");
    const tasks: WorkflowTask[] = TEMPLATES[kind].map((t) => ({ id: randomUUID(), label: t.label, owner: t.owner, dueDate: addDaysIso(targetDate, t.offset), done: false }));
    const [row] = await db.insert(schema.lifecycleWorkflows).values({ employeeId, kind, targetDate, status: "in_progress", tasks }).returning({ id: schema.lifecycleWorkflows.id });
    await audit({ action: "lifecycle.create", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "lifecycle_workflow", entityId: row.id, after: { kind, targetDate, employee: `${emp.firstName} ${emp.lastName}`, tasks: tasks.length } });
    revalidatePath(`/app/${companyId}/cycle-de-vie`);
    return { ok: true, message: `Parcours créé avec ${tasks.length} tâches.` };
  });
}

async function saveTasks(companyId: string, userId: string, tenantId: string, w: typeof schema.lifecycleWorkflows.$inferSelect, tasks: WorkflowTask[], action: string, detail: unknown) {
  const allDone = tasks.length > 0 && tasks.every((t) => t.done);
  const status = w.status === "cancelled" ? "cancelled" : allDone ? "done" : "in_progress";
  await db.update(schema.lifecycleWorkflows).set({ tasks, status }).where(eq(schema.lifecycleWorkflows.id, w.id));
  await audit({ action, userId, companyId, tenantId, entityType: "lifecycle_workflow", entityId: w.id, before: { status: w.status }, after: { status, detail } });
  revalidatePath(`/app/${companyId}/cycle-de-vie`);
  return status;
}

export async function toggleWorkflowTaskAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "employees.write");
    const w = await loadWorkflow(companyId, id(fd, "workflowId"));
    if (w.status === "cancelled") throw new HrError("Parcours annulé.");
    const taskId = str(fd, "taskId");
    const tasks = ((w.tasks as WorkflowTask[]) ?? []).map((t) =>
      t.id === taskId ? { ...t, done: !t.done, doneAt: !t.done ? new Date().toISOString() : null, doneBy: !t.done ? ctx.user.id : null } : t,
    );
    if (!tasks.some((t) => t.id === taskId)) throw new HrError("Tâche introuvable.");
    const status = await saveTasks(companyId, ctx.user.id, ctx.tenant.id, w, tasks, "lifecycle.task_toggle", { taskId });
    return { ok: true, message: status === "done" ? "Toutes les tâches sont faites : parcours terminé." : "Tâche mise à jour." };
  });
}

export async function addWorkflowTaskAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "employees.write");
    const w = await loadWorkflow(companyId, id(fd, "workflowId"));
    const label = str(fd, "label");
    if (label.length < 3) throw new HrError("Décrivez la tâche.");
    const owner = str(fd, "owner") as TaskOwner;
    if (!OWNERS.includes(owner)) throw new HrError("Responsable invalide.");
    const dueDate = isoDate(fd, "dueDate", "Échéance");
    const tasks = [...((w.tasks as WorkflowTask[]) ?? []), { id: randomUUID(), label: label.slice(0, 200), owner, dueDate, done: false }];
    await saveTasks(companyId, ctx.user.id, ctx.tenant.id, { ...w, status: w.status === "done" ? "in_progress" : w.status }, tasks, "lifecycle.task_add", { label });
    return { ok: true, message: "Tâche ajoutée." };
  });
}

export async function cancelWorkflowAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "employees.write");
    const w = await loadWorkflow(companyId, id(fd, "workflowId"));
    await db.update(schema.lifecycleWorkflows).set({ status: "cancelled" }).where(eq(schema.lifecycleWorkflows.id, w.id));
    await audit({ action: "lifecycle.cancel", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "lifecycle_workflow", entityId: w.id, before: { status: w.status }, after: { status: "cancelled", reason: optStr(fd, "reason") } });
    revalidatePath(`/app/${companyId}/cycle-de-vie`);
    return { ok: true, message: "Parcours annulé." };
  });
}
