"use server";

import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { issueDownloadLink } from "@/server/documents/store";
import type { ActionState } from "./auth";
import { bool, euros, HrError, id, isoDate, optStr, runAction, str } from "@/server/hr/common";
import { attachLeaveProof, cancelLeave, createLeaveRequest } from "@/server/hr/leave-flow";
import { addLine, createReport, EXPENSE_CATEGORIES, removeLine, submitReport } from "@/server/hr/expenses";
import { fileFrom, saveProof } from "@/server/hr/uploads";
import { requireSelf, SELF_COOKIE } from "@/server/hr/self";
import { CORRECTABLE_FIELDS, HR_REQUEST_KINDS, sanitizeChanges } from "@/server/hr/requests";

async function selfActor() {
  const s = await requireSelf();
  return {
    s,
    actor: { userId: s.user.id, companyId: s.company.id, tenantId: s.company.tenantId, isDemo: s.company.isDemo },
  };
}

const refresh = () => revalidatePath("/moi", "layout");

export async function selectSelfRecordAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const s = await requireSelf();
    const employeeId = id(fd, "employeeId");
    if (!s.records.some((r) => r.e.id === employeeId)) throw new HrError("Fiche introuvable.");
    const jar = await cookies();
    jar.set(SELF_COOKIE, employeeId, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/moi", maxAge: 60 * 60 * 24 * 180 });
    refresh();
    return { ok: true };
  });
}

export async function selfRequestLeaveAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s, actor } = await selfActor();
    const res = await createLeaveRequest(actor, {
      employeeId: s.employee.id,
      leaveTypeId: id(fd, "leaveTypeId"),
      startDate: isoDate(fd, "startDate", "Début"),
      endDate: isoDate(fd, "endDate", "Fin"),
      startHalfDay: bool(fd, "startHalfDay"),
      endHalfDay: bool(fd, "endHalfDay"),
      reason: optStr(fd, "reason"),
      proof: fileFrom(fd, "proof"),
    });
    refresh();
    const needsProof = res.type.requiresProof && !res.request.proofDocumentId;
    return {
      ok: true,
      message: `Demande envoyée : ${res.duration.toLocaleString("fr-FR")} jour(s). Vous serez informé de la décision.${needsProof ? " Pensez à déposer le justificatif : il est requis pour ce type d'absence." : ""}`,
    };
  });
}

export async function selfCancelLeaveAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s, actor } = await selfActor();
    const requestId = id(fd, "requestId");
    const [r] = await db
      .select({ status: schema.leaveRequests.status })
      .from(schema.leaveRequests)
      .where(and(eq(schema.leaveRequests.id, requestId), eq(schema.leaveRequests.employeeId, s.employee.id)))
      .limit(1);
    if (!r) throw new HrError("Demande introuvable.");
    if (r.status !== "pending") throw new HrError("Cette demande a déjà été traitée : contactez le service RH pour l'annuler.");
    await cancelLeave(actor, requestId, "Annulée par le salarié", { ownerEmployeeId: s.employee.id });
    refresh();
    return { ok: true, message: "Demande annulée." };
  });
}

/** Dépôt d'un justificatif : rattaché à une absence, ou transmis au service RH sous forme de demande. */
export async function selfUploadProofAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s, actor } = await selfActor();
    const file = fileFrom(fd, "file");
    if (!file) throw new HrError("Choisissez un fichier.");
    const leaveId = str(fd, "leaveRequestId");
    if (leaveId) {
      await attachLeaveProof(actor, id(fd, "leaveRequestId"), file, { ownerEmployeeId: s.employee.id });
      refresh();
      return { ok: true, message: "Justificatif joint à votre absence." };
    }
    const title = str(fd, "title") || "Justificatif";
    const doc = await saveProof(file, {
      companyId: s.company.id,
      employeeId: s.employee.id,
      title: title.slice(0, 120),
      sourceType: "self_upload",
      sourceId: null,
      userId: s.user.id,
      isDemo: s.company.isDemo,
    });
    const [req] = await db
      .insert(schema.hrRequests)
      .values({ companyId: s.company.id, employeeId: s.employee.id, kind: "justificatif", title: `Justificatif déposé : ${title.slice(0, 120)}`, body: optStr(fd, "note"), payload: { documentId: doc.id }, status: "pending" })
      .returning({ id: schema.hrRequests.id });
    await audit({ action: "self.proof_upload", userId: s.user.id, companyId: s.company.id, tenantId: s.company.tenantId, entityType: "hr_request", entityId: req.id, after: { documentId: doc.id } });
    refresh();
    return { ok: true, message: "Justificatif transmis au service RH." };
  });
}

export async function selfCreateExpenseAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s, actor } = await selfActor();
    const row = await createReport(actor, s.employee.id, str(fd, "title"));
    refresh();
    return { ok: true, message: "Note créée : ajoutez vos dépenses.", data: { href: `/moi/frais/${row.id}` } };
  });
}

export async function selfAddExpenseLineAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s, actor } = await selfActor();
    const category = str(fd, "category");
    if (!EXPENSE_CATEGORIES.some((c) => c.value === category)) throw new HrError("Catégorie invalide.");
    const label = str(fd, "label");
    if (!label) throw new HrError("Décrivez la dépense.");
    await addLine(
      actor,
      id(fd, "reportId"),
      {
        date: isoDate(fd, "date", "Date"),
        category,
        label,
        amountCents: euros(fd, "amount", "Montant TTC"),
        vatCents: str(fd, "vat") ? euros(fd, "vat", "TVA") : 0,
        receipt: fileFrom(fd, "receipt"),
      },
      s.employee.id,
    );
    refresh();
    return { ok: true, message: "Dépense ajoutée." };
  });
}

export async function selfRemoveExpenseLineAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s, actor } = await selfActor();
    await removeLine(actor, id(fd, "reportId"), id(fd, "lineId"), s.employee.id);
    refresh();
    return { ok: true, message: "Dépense retirée." };
  });
}

export async function selfSubmitExpenseAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s, actor } = await selfActor();
    const { missing } = await submitReport(actor, id(fd, "reportId"), s.employee.id);
    refresh();
    return { ok: true, message: missing ? `Note envoyée. ${missing} dépense(s) sans justificatif : le service RH pourra vous le demander.` : "Note envoyée pour validation." };
  });
}

/** Demande de correction des coordonnées ou de l'adresse : appliquée par le service RH après vérification. */
export async function selfCorrectionRequestAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s } = await selfActor();
    const raw: Record<string, string> = {};
    for (const k of Object.keys(CORRECTABLE_FIELDS)) raw[k] = str(fd, k);
    const proposed = sanitizeChanges(raw);
    const changes = Object.fromEntries(Object.entries(proposed).filter(([k, v]) => (s.employee as Record<string, unknown>)[k] !== v));
    if (!Object.keys(changes).length) throw new HrError("Aucune modification détectée (ou valeurs invalides).");
    const [req] = await db
      .insert(schema.hrRequests)
      .values({
        companyId: s.company.id,
        employeeId: s.employee.id,
        kind: "correction_informations",
        title: `Correction : ${Object.keys(changes).map((k) => CORRECTABLE_FIELDS[k as keyof typeof CORRECTABLE_FIELDS].label.toLowerCase()).join(", ")}`,
        body: optStr(fd, "note"),
        payload: { changes },
        status: "pending",
      })
      .returning({ id: schema.hrRequests.id });
    await audit({ action: "self.correction_request", userId: s.user.id, companyId: s.company.id, tenantId: s.company.tenantId, entityType: "hr_request", entityId: req.id, after: { fields: Object.keys(changes) } });
    refresh();
    return { ok: true, message: "Demande de correction envoyée au service RH." };
  });
}

export async function selfHrRequestAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s } = await selfActor();
    const kind = str(fd, "kind");
    if (!HR_REQUEST_KINDS.some((k) => k.value === kind) || kind === "correction_informations") throw new HrError("Type de demande invalide.");
    const title = str(fd, "title");
    if (title.length < 3) throw new HrError("Donnez un objet à votre demande.");
    const payload: Record<string, unknown> = {};
    if (kind === "acompte") payload.amountCents = euros(fd, "amount", "Montant de l'acompte");
    const [req] = await db
      .insert(schema.hrRequests)
      .values({ companyId: s.company.id, employeeId: s.employee.id, kind: kind as (typeof schema.hrRequestKindEnum.enumValues)[number], title: title.slice(0, 160), body: optStr(fd, "body"), payload, status: "pending" })
      .returning({ id: schema.hrRequests.id });
    await audit({ action: "self.hr_request", userId: s.user.id, companyId: s.company.id, tenantId: s.company.tenantId, entityType: "hr_request", entityId: req.id, after: { kind } });
    refresh();
    return { ok: true, message: "Demande envoyée au service RH." };
  });
}

export async function selfCancelHrRequestAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s } = await selfActor();
    const requestId = id(fd, "requestId");
    const [r] = await db
      .select()
      .from(schema.hrRequests)
      .where(and(eq(schema.hrRequests.id, requestId), eq(schema.hrRequests.employeeId, s.employee.id), eq(schema.hrRequests.companyId, s.company.id)))
      .limit(1);
    if (!r) throw new HrError("Demande introuvable.");
    if (r.status !== "pending") throw new HrError("Demande déjà traitée.");
    await db.update(schema.hrRequests).set({ status: "cancelled" }).where(eq(schema.hrRequests.id, r.id));
    await audit({ action: "self.hr_request_cancel", userId: s.user.id, companyId: s.company.id, tenantId: s.company.tenantId, entityType: "hr_request", entityId: r.id, before: { status: r.status }, after: { status: "cancelled" } });
    refresh();
    return { ok: true, message: "Demande retirée." };
  });
}

/** Lien de téléchargement d'un document du salarié (visibilité « salarié » uniquement). */
export async function selfDownloadAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const { s } = await selfActor();
    const documentId = id(fd, "documentId");
    const [doc] = await db
      .select({ id: schema.documents.id })
      .from(schema.documents)
      .where(
        and(
          eq(schema.documents.id, documentId),
          eq(schema.documents.companyId, s.company.id),
          eq(schema.documents.employeeId, s.employee.id),
          inArray(schema.documents.visibility, ["employee"]),
        ),
      )
      .limit(1);
    if (!doc) throw new HrError("Document introuvable.");
    const url = await issueDownloadLink(doc.id, s.user.id);
    await audit({ action: "self.document_link", userId: s.user.id, companyId: s.company.id, tenantId: s.company.tenantId, entityType: "document", entityId: doc.id });
    return { ok: true, data: { url } };
  });
}
