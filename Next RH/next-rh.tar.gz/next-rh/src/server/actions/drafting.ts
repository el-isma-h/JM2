"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import {
  archiveDraft,
  createDraft,
  decideReview,
  DraftError,
  exportDraft,
  generateDraft,
  improveDraft,
  refreshSignature,
  requestSignature,
  restoreVersion,
  saveDraftBody,
  submitForReview,
} from "@/server/documents/drafting";
import { TemplateError } from "@/server/documents/render";
import type { ActionState } from "./auth";

const uuid = z.string().regex(/^[0-9a-f-]{36}$/, "Identifiant invalide");

function fail(e: unknown): ActionState {
  const auth = authErrorMessage(e);
  if (auth) return { error: auth };
  if (e instanceof DraftError || e instanceof TemplateError) return { error: e.message };
  if (e instanceof z.ZodError) return { error: "Requête invalide." };
  console.error("[atelier]", e);
  return { error: "Une erreur est survenue. Réessayez." };
}

const ids = (fd: FormData) => ({ companyId: uuid.parse(fd.get("companyId")), draftId: uuid.parse(fd.get("draftId")) });
const touch = (companyId: string, draftId?: string) => {
  revalidatePath(`/app/${companyId}/atelier`);
  if (draftId) revalidatePath(`/app/${companyId}/atelier/${draftId}`);
};

/** Étape 1 : type de document choisi (et salarié le cas échéant) : crée le brouillon puis ouvre les questions. */
export async function startDraftAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  let target: string;
  try {
    const companyId = uuid.parse(fd.get("companyId"));
    const templateId = uuid.parse(fd.get("templateId"));
    const employeeRaw = String(fd.get("employeeId") ?? "");
    const ctx = await requireCompany(companyId, "documents.write");
    const draft = await createDraft(ctx, { templateId, employeeId: employeeRaw ? uuid.parse(employeeRaw) : null });
    target = `/app/${companyId}/atelier/${draft.id}`;
    touch(companyId);
  } catch (e) {
    return fail(e);
  }
  redirect(target);
}

/** Étapes 2 à 5 : réponses aux questions, génération du brouillon avec marqueurs. */
export async function answerQuestionsAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    const answers: Record<string, string> = {};
    for (const [k, v] of fd.entries()) if (k.startsWith("q_") && typeof v === "string") answers[k.slice(2)] = v;
    const { missing } = await generateDraft(ctx, draftId, answers);
    touch(companyId, draftId);
    return { ok: true, message: missing.length ? `Brouillon généré. ${missing.length} élément(s) restent à compléter.` : "Brouillon généré, aucun élément manquant." };
  } catch (e) {
    return fail(e);
  }
}

export async function saveDraftAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    const res = await saveDraftBody(ctx, draftId, String(fd.get("body") ?? ""), String(fd.get("note") ?? ""));
    touch(companyId, draftId);
    return { ok: true, message: res.changed ? `Version enregistrée. ${res.missing.length ? `${res.missing.length} élément(s) à compléter.` : "Plus aucun élément à compléter."}` : "Aucune modification à enregistrer." };
  } catch (e) {
    return fail(e);
  }
}

export async function restoreVersionAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    await restoreVersion(ctx, draftId, Number(fd.get("version")));
    touch(companyId, draftId);
    return { ok: true, message: "Version restaurée (enregistrée comme nouvelle version)." };
  } catch (e) {
    return fail(e);
  }
}

export async function submitReviewAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    const reviewer = await submitForReview(ctx, draftId, uuid.parse(fd.get("reviewerId")), String(fd.get("message") ?? ""));
    touch(companyId, draftId);
    return { ok: true, message: `Brouillon envoyé en relecture à ${reviewer.name}${ctx.company.isDemo ? " (démonstration : aucun e-mail envoyé)" : ""}.` };
  } catch (e) {
    return fail(e);
  }
}

export async function decideReviewAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    const decision = z.enum(["approved", "rejected"]).parse(fd.get("decision"));
    await decideReview(ctx, draftId, decision, String(fd.get("comment") ?? ""));
    touch(companyId, draftId);
    return { ok: true, message: decision === "approved" ? "Brouillon validé." : "Brouillon renvoyé au rédacteur avec votre commentaire." };
  } catch (e) {
    return fail(e);
  }
}

export async function exportDraftAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    const visibility = z.enum(["company", "employee", "restricted"]).parse(fd.get("visibility"));
    const { pdfDoc } = await exportDraft(ctx, draftId, { visibility, legalAcknowledged: fd.get("legalAck") === "on" });
    touch(companyId, draftId);
    revalidatePath(`/app/${companyId}/documents`);
    return { ok: true, message: `PDF et DOCX enregistrés dans les documents (version ${pdfDoc.version}).` };
  } catch (e) {
    return fail(e);
  }
}

export async function requestSignatureAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    const { request, message } = await requestSignature(ctx, draftId);
    touch(companyId, draftId);
    return request.status === "not_configured" ? { error: message } : { ok: true, message };
  } catch (e) {
    return fail(e);
  }
}

export async function refreshSignatureAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    const res = await refreshSignature(ctx, draftId, uuid.parse(fd.get("requestId")));
    touch(companyId, draftId);
    return { ok: true, message: res.message };
  } catch (e) {
    return fail(e);
  }
}

export async function improveDraftAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    const res = await improveDraft(ctx, draftId);
    touch(companyId, draftId);
    return { ok: true, message: res.changed ? "Rédaction améliorée et enregistrée comme nouvelle version. Relisez-la : la version précédente reste restaurable." : "La reformulation n'a rien changé." };
  } catch (e) {
    return fail(e);
  }
}

export async function archiveDraftAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const { companyId, draftId } = ids(fd);
    const ctx = await requireCompany(companyId, "documents.write");
    await archiveDraft(ctx, draftId);
    touch(companyId, draftId);
    return { ok: true, message: "Brouillon archivé. Ses versions restent consultables." };
  } catch (e) {
    return fail(e);
  }
}
