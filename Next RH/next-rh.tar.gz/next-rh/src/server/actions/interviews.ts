"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import type { ActionState } from "./auth";
import { employeeOf, HrError, id, optStr, requireAnyPermission, runAction, str, UUID_RE } from "@/server/hr/common";
import { syncDeadlines } from "@/server/hr/deadlines";

const KINDS = schema.interviewKindEnum.enumValues;
const STATUSES = ["planned", "done", "cancelled"] as const;
type Objective = { label: string; done: boolean };

function parseObjectives(raw: string): Objective[] {
  return raw
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .slice(0, 20)
    .map((label) => ({ label: label.slice(0, 200), done: false }));
}

function parseWhen(raw: string): Date | null {
  if (!raw) return null;
  // <input type="datetime-local"> : heure locale de Paris.
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) throw new HrError("Date et heure invalides.");
  return d;
}

async function loadInterview(companyId: string, interviewId: string) {
  const [row] = await db
    .select({ i: schema.interviews })
    .from(schema.interviews)
    .innerJoin(schema.employees, eq(schema.employees.id, schema.interviews.employeeId))
    .where(and(eq(schema.interviews.id, interviewId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!row) throw new HrError("Entretien introuvable.");
  return row.i;
}

export async function createInterviewAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireAnyPermission(companyId, ["employees.write", "requests.approve"]);
    const employeeId = id(fd, "employeeId");
    await employeeOf(companyId, employeeId);
    const kind = str(fd, "kind") as (typeof KINDS)[number];
    if (!KINDS.includes(kind)) throw new HrError("Type d'entretien invalide.");
    const conductedBy = str(fd, "conductedBy");
    const [row] = await db
      .insert(schema.interviews)
      .values({
        employeeId,
        kind,
        scheduledAt: parseWhen(str(fd, "scheduledAt")),
        conductedBy: UUID_RE.test(conductedBy) ? conductedBy : ctx.user.id,
        status: "planned",
        objectives: parseObjectives(str(fd, "objectives")),
      })
      .returning({ id: schema.interviews.id });
    await audit({ action: "interview.create", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "interview", entityId: row.id, after: { kind, employeeId } });
    await syncDeadlines(companyId);
    revalidatePath(`/app/${companyId}/entretiens`);
    return { ok: true, message: "Entretien planifié.", data: { href: `/app/${companyId}/entretiens/${row.id}` } };
  });
}

export async function updateInterviewAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireAnyPermission(companyId, ["employees.write", "requests.approve"]);
    const before = await loadInterview(companyId, id(fd, "interviewId"));
    const status = str(fd, "status") as (typeof STATUSES)[number];
    if (!STATUSES.includes(status)) throw new HrError("Statut invalide.");
    const prevObjectives = (before.objectives as Objective[]) ?? [];
    const labels = fd.getAll("objective").map(String);
    const objectives: Objective[] = labels
      .map((label, i) => ({ label: label.trim().slice(0, 200), done: fd.get(`objectiveDone_${i}`) === "on" }))
      .filter((o) => o.label);
    const extra = parseObjectives(str(fd, "newObjectives"));
    const values = {
      status,
      scheduledAt: str(fd, "scheduledAt") ? parseWhen(str(fd, "scheduledAt")) : before.scheduledAt,
      notes: optStr(fd, "notes"),
      objectives: [...objectives, ...extra],
    };
    if (status === "done" && !values.notes) throw new HrError("Rédigez le compte rendu avant de marquer l'entretien comme réalisé.");
    await db.update(schema.interviews).set(values).where(eq(schema.interviews.id, before.id));
    await audit({
      action: "interview.update",
      userId: ctx.user.id,
      companyId,
      tenantId: ctx.tenant.id,
      entityType: "interview",
      entityId: before.id,
      before: { status: before.status, objectives: prevObjectives.length, hasNotes: Boolean(before.notes) },
      after: { status, objectives: values.objectives.length, hasNotes: Boolean(values.notes) },
    });
    await syncDeadlines(companyId);
    revalidatePath(`/app/${companyId}/entretiens`);
    revalidatePath(`/app/${companyId}/entretiens/${before.id}`);
    return { ok: true, message: "Entretien enregistré." };
  });
}
