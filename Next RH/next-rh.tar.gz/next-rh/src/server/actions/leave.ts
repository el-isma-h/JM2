"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { audit } from "@/server/audit";
import type { ActionState } from "./auth";
import { bool, employeeOf, HrError, id, isoDate, optStr, runAction, str } from "@/server/hr/common";
import { approveLeave, attachLeaveProof, cancelLeave, createLeaveRequest, rejectLeave } from "@/server/hr/leave-flow";
import { recomputeBalances } from "@/server/hr/leave";
import { fileFrom } from "@/server/hr/uploads";

const paths = (companyId: string) => {
  revalidatePath(`/app/${companyId}/conges`);
  revalidatePath(`/app/${companyId}`);
};

/** Saisie d'une absence par RH pour un salarié (approuvée immédiatement si demandé). */
export async function createLeaveForEmployeeAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const employeeId = id(fd, "employeeId");
    await employeeOf(companyId, employeeId);
    const actor = { userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, isDemo: ctx.company.isDemo };
    const res = await createLeaveRequest(actor, {
      employeeId,
      leaveTypeId: id(fd, "leaveTypeId"),
      startDate: isoDate(fd, "startDate", "Début"),
      endDate: isoDate(fd, "endDate", "Fin"),
      startHalfDay: bool(fd, "startHalfDay"),
      endHalfDay: bool(fd, "endHalfDay"),
      reason: optStr(fd, "reason"),
      proof: fileFrom(fd, "proof"),
      allowNegative: bool(fd, "allowNegative"),
    });
    let msg = `Absence enregistrée : ${res.duration.toLocaleString("fr-FR")} jour(s).`;
    if (bool(fd, "approveNow")) {
      const p = await approveLeave(actor, res.request.id, "Saisie par le service RH", { allowMissingProof: true });
      msg += p ? (p.shifted ? " Validée ; la paie du mois étant validée, la variable est reportée au mois suivant." : " Validée et transmise à la paie.") : " Validée (sans effet sur la paie).";
    }
    paths(companyId);
    return { ok: true, message: msg };
  });
}

export async function decideLeaveAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const actor = { userId: ctx.user.id, companyId, tenantId: ctx.tenant.id };
    const requestId = id(fd, "requestId");
    const decision = str(fd, "decision");
    const note = optStr(fd, "note");
    if (decision === "approve") {
      const p = await approveLeave(actor, requestId, note);
      paths(companyId);
      return { ok: true, message: p?.shifted ? "Validée. Paie du mois déjà validée : régularisation placée sur le mois suivant." : "Demande validée." };
    }
    if (decision === "reject") {
      await rejectLeave(actor, requestId, note);
      paths(companyId);
      return { ok: true, message: "Demande refusée." };
    }
    throw new HrError("Décision inconnue.");
  });
}

export async function cancelLeaveAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const res = await cancelLeave({ userId: ctx.user.id, companyId, tenantId: ctx.tenant.id }, id(fd, "requestId"), optStr(fd, "note"));
    paths(companyId);
    return {
      ok: true,
      message: res?.regularisationId
        ? "Absence annulée. La paie concernée étant validée, une régularisation est prévue le mois suivant."
        : res?.removed
          ? "Absence annulée et retirée des variables de paie."
          : "Absence annulée.",
    };
  });
}

export async function attachLeaveProofAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "requests.approve");
    const file = fileFrom(fd, "proof");
    if (!file) throw new HrError("Choisissez un fichier.");
    await attachLeaveProof({ userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, isDemo: ctx.company.isDemo }, id(fd, "requestId"), file);
    paths(companyId);
    return { ok: true, message: "Justificatif ajouté." };
  });
}

/** Ajustement manuel d'un solde (reprise d'historique, correction). */
export async function adjustBalanceAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "employees.write");
    const employeeId = id(fd, "employeeId");
    await employeeOf(companyId, employeeId);
    const leaveTypeId = id(fd, "leaveTypeId");
    const periodStart = isoDate(fd, "periodStart", "Période");
    const value = Number(str(fd, "adjustment").replace(",", "."));
    if (!Number.isFinite(value) || Math.abs(value) > 100) throw new HrError("Ajustement invalide (entre -100 et 100 jours).");
    const [t] = await db.select().from(schema.leaveTypes).where(and(eq(schema.leaveTypes.id, leaveTypeId), eq(schema.leaveTypes.companyId, companyId))).limit(1);
    if (!t) throw new HrError("Type introuvable.");
    const [before] = await db
      .select()
      .from(schema.leaveBalances)
      .where(and(eq(schema.leaveBalances.employeeId, employeeId), eq(schema.leaveBalances.leaveTypeId, leaveTypeId), eq(schema.leaveBalances.periodStart, periodStart)))
      .limit(1);
    if (!before) throw new HrError("Solde introuvable pour cette période.");
    await db.update(schema.leaveBalances).set({ adjustment: value.toFixed(2) }).where(eq(schema.leaveBalances.id, before.id));
    await db.transaction((tx) => recomputeBalances(tx, companyId, employeeId));
    await audit({
      action: "leave.balance_adjust",
      userId: ctx.user.id,
      companyId,
      tenantId: ctx.tenant.id,
      entityType: "leave_balance",
      entityId: before.id,
      before: { adjustment: before.adjustment },
      after: { adjustment: value.toFixed(2), reason: optStr(fd, "reason") },
    });
    paths(companyId);
    return { ok: true, message: "Solde ajusté." };
  });
}

const typeSchema = z.object({
  code: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z0-9_]{2,12}$/, "Code : 2 à 12 lettres majuscules, chiffres ou _"),
  label: z.string().trim().min(2, "Libellé requis").max(80),
  unit: z.enum(["jours_ouvres", "jours_ouvrables", "jours_calendaires", "heures"]),
  monthlyAccrual: z
    .string()
    .trim()
    .transform((v) => v.replace(",", "."))
    .refine((v) => v === "" || (/^\d{1,2}(\.\d{1,2})?$/.test(v) && Number(v) <= 30), "Acquisition mensuelle invalide"),
  sortOrder: z.coerce.number().int().min(0).max(99).default(0),
});

export async function saveLeaveTypeAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const ctx = await requireCompany(companyId, "company.manage");
    const parsed = typeSchema.safeParse({
      code: str(fd, "code"),
      label: str(fd, "label"),
      unit: str(fd, "unit"),
      monthlyAccrual: str(fd, "monthlyAccrual"),
      sortOrder: str(fd, "sortOrder") || "0",
    });
    if (!parsed.success) throw new HrError(parsed.error.issues[0]?.message ?? "Formulaire invalide");
    const d = parsed.data;
    const values = {
      code: d.code,
      label: d.label,
      unit: d.unit,
      monthlyAccrual: d.monthlyAccrual === "" ? null : Number(d.monthlyAccrual).toFixed(2),
      isPaid: bool(fd, "isPaid"),
      affectsPayroll: bool(fd, "affectsPayroll"),
      requiresProof: bool(fd, "requiresProof"),
      sortOrder: d.sortOrder,
    };
    const typeId = str(fd, "typeId");
    if (typeId) {
      const [before] = await db.select().from(schema.leaveTypes).where(and(eq(schema.leaveTypes.id, typeId), eq(schema.leaveTypes.companyId, companyId))).limit(1);
      if (!before) throw new HrError("Type introuvable.");
      const [clash] = await db.select({ id: schema.leaveTypes.id }).from(schema.leaveTypes).where(and(eq(schema.leaveTypes.companyId, companyId), eq(schema.leaveTypes.code, d.code))).limit(1);
      if (clash && clash.id !== typeId) throw new HrError(`Le code ${d.code} est déjà utilisé.`);
      await db.update(schema.leaveTypes).set(values).where(eq(schema.leaveTypes.id, typeId));
      await audit({ action: "leave_type.update", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "leave_type", entityId: typeId, before, after: values });
    } else {
      const [clash] = await db.select({ id: schema.leaveTypes.id }).from(schema.leaveTypes).where(and(eq(schema.leaveTypes.companyId, companyId), eq(schema.leaveTypes.code, d.code))).limit(1);
      if (clash) throw new HrError(`Le code ${d.code} est déjà utilisé.`);
      const [row] = await db.insert(schema.leaveTypes).values({ companyId, ...values }).returning({ id: schema.leaveTypes.id });
      await audit({ action: "leave_type.create", userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, entityType: "leave_type", entityId: row.id, after: values });
    }
    revalidatePath(`/app/${companyId}/conges/types`);
    paths(companyId);
    return { ok: true, message: "Type d'absence enregistré." };
  });
}
