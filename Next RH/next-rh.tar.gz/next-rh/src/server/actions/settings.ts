"use server";

import { revalidatePath } from "next/cache";
import { and, eq, ne, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { audit } from "@/server/audit";
import { issueInvitation } from "@/server/employees/invitations";
import { integrations } from "@/lib/env";
import { randomToken, sha256 } from "@/lib/crypto";
import { checkPostalCode, checkSiret, isEmail } from "@/lib/validators";
import { roleLabels } from "@/components/employees/labels";
import type { ActionState } from "./auth";

const s = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const opt = (fd: FormData, k: string) => s(fd, k) || null;

function revalidateCompany(companyId: string) {
  revalidatePath(`/app/${companyId}/parametres`);
  revalidatePath(`/app/${companyId}/onboarding`);
}

// ---------- Établissements ----------

export async function saveEstablishmentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const id = s(fd, "id");
    const name = s(fd, "name");
    if (!name) return { error: "Donnez un nom à l'établissement (par exemple « Siège » ou « Agence de Lyon »)." };
    let siret: string | null = null;
    const rawSiret = s(fd, "siret");
    if (rawSiret) {
      if (!ctx.company.siren) return { error: "Renseignez d'abord le SIREN de l'entreprise (étape Identité)." };
      const r = checkSiret(rawSiret, ctx.company.siren);
      if (!r.ok) return { error: r.error };
      siret = r.value;
    }
    const postal = s(fd, "postalCode");
    if (postal && !checkPostalCode(postal).ok) return { error: "Le code postal comporte 5 chiffres." };
    const values = {
      name: name.slice(0, 120),
      siret,
      nic: siret ? siret.slice(9) : null,
      isHeadOffice: fd.get("isHeadOffice") === "on",
      addressLine1: opt(fd, "addressLine1"),
      postalCode: postal || null,
      city: opt(fd, "city"),
      urssafCode: opt(fd, "urssafCode"),
    };
    if (siret) {
      const [dup] = await db
        .select({ id: schema.establishments.id })
        .from(schema.establishments)
        .where(and(eq(schema.establishments.companyId, companyId), eq(schema.establishments.siret, siret), id ? ne(schema.establishments.id, id) : sql`true`))
        .limit(1);
      if (dup) return { error: "Un autre établissement porte déjà ce SIRET." };
    }
    await db.transaction(async (tx) => {
      if (values.isHeadOffice) await tx.update(schema.establishments).set({ isHeadOffice: false }).where(eq(schema.establishments.companyId, companyId));
      if (id) {
        const [before] = await tx.select().from(schema.establishments).where(and(eq(schema.establishments.id, id), eq(schema.establishments.companyId, companyId))).limit(1);
        if (!before) throw new Error("Établissement introuvable.");
        await tx.update(schema.establishments).set(values).where(eq(schema.establishments.id, id));
        await audit({ action: "establishment.update", userId: ctx.user.id, companyId, entityType: "establishment", entityId: id, before, after: values });
      } else {
        const [row] = await tx.insert(schema.establishments).values({ companyId, ...values }).returning({ id: schema.establishments.id });
        await audit({ action: "establishment.create", userId: ctx.user.id, companyId, entityType: "establishment", entityId: row.id, after: values });
      }
    });
    revalidateCompany(companyId);
    return { ok: true, message: id ? "Établissement mis à jour." : "Établissement ajouté." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? (e instanceof Error ? e.message : "Erreur") };
  }
}

export async function deleteEstablishmentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const id = s(fd, "id");
    const [est] = await db.select().from(schema.establishments).where(and(eq(schema.establishments.id, id), eq(schema.establishments.companyId, companyId))).limit(1);
    if (!est) return { error: "Établissement introuvable." };
    const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.employees).where(eq(schema.employees.establishmentId, id));
    if (n > 0) return { error: `${n} salarié(s) sont rattachés à cet établissement : changez d'abord leur établissement.` };
    await db.delete(schema.establishments).where(eq(schema.establishments.id, id));
    await audit({ action: "establishment.delete", userId: ctx.user.id, companyId, entityType: "establishment", entityId: id, before: est });
    revalidateCompany(companyId);
    return { ok: true, message: "Établissement supprimé." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

// ---------- Organismes ----------

const organismSchema = z.object({
  kind: z.enum(schema.organismKindEnum.enumValues),
  name: z.string().trim().min(1, "Indiquez le nom de l'organisme.").max(160),
  reference: z.string().trim().max(80).optional(),
  contractNumber: z.string().trim().max(80).optional(),
  notes: z.string().trim().max(500).optional(),
});

export async function saveOrganismAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const parsed = organismSchema.safeParse({ kind: s(fd, "kind"), name: s(fd, "name"), reference: s(fd, "reference"), contractNumber: s(fd, "contractNumber"), notes: s(fd, "notes") });
    if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Formulaire invalide" };
    const id = s(fd, "id");
    const values = { ...parsed.data, reference: parsed.data.reference || null, contractNumber: parsed.data.contractNumber || null, notes: parsed.data.notes || null };
    if (id) {
      const [before] = await db.select().from(schema.companyOrganisms).where(and(eq(schema.companyOrganisms.id, id), eq(schema.companyOrganisms.companyId, companyId))).limit(1);
      if (!before) return { error: "Organisme introuvable." };
      await db.update(schema.companyOrganisms).set(values).where(eq(schema.companyOrganisms.id, id));
      await audit({ action: "organism.update", userId: ctx.user.id, companyId, entityType: "organism", entityId: id, before, after: values });
    } else {
      const [row] = await db.insert(schema.companyOrganisms).values({ companyId, ...values }).returning({ id: schema.companyOrganisms.id });
      await audit({ action: "organism.create", userId: ctx.user.id, companyId, entityType: "organism", entityId: row.id, after: values });
    }
    revalidateCompany(companyId);
    return { ok: true, message: "Organisme enregistré." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

export async function deleteOrganismAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const id = s(fd, "id");
    const [row] = await db.delete(schema.companyOrganisms).where(and(eq(schema.companyOrganisms.id, id), eq(schema.companyOrganisms.companyId, companyId))).returning();
    if (!row) return { error: "Organisme introuvable." };
    await audit({ action: "organism.delete", userId: ctx.user.id, companyId, entityType: "organism", entityId: id, before: row });
    revalidateCompany(companyId);
    return { ok: true, message: "Organisme retiré." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

// ---------- Interlocuteurs ----------

export async function saveContactAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const fullName = s(fd, "fullName");
    if (!fullName) return { error: "Indiquez le nom de l'interlocuteur." };
    const email = s(fd, "email");
    if (email && !isEmail(email)) return { error: "Adresse e-mail invalide." };
    const role = s(fd, "role");
    if (!(schema.contactRoleEnum.enumValues as readonly string[]).includes(role)) return { error: "Rôle inconnu." };
    const values = { fullName: fullName.slice(0, 120), role: role as (typeof schema.contactRoleEnum.enumValues)[number], email: email.toLowerCase() || null, phone: opt(fd, "phone") };
    const id = s(fd, "id");
    if (id) {
      const [before] = await db.select().from(schema.companyContacts).where(and(eq(schema.companyContacts.id, id), eq(schema.companyContacts.companyId, companyId))).limit(1);
      if (!before) return { error: "Interlocuteur introuvable." };
      await db.update(schema.companyContacts).set(values).where(eq(schema.companyContacts.id, id));
      await audit({ action: "contact.update", userId: ctx.user.id, companyId, entityType: "contact", entityId: id, before, after: values });
    } else {
      const [row] = await db.insert(schema.companyContacts).values({ companyId, ...values }).returning({ id: schema.companyContacts.id });
      await audit({ action: "contact.create", userId: ctx.user.id, companyId, entityType: "contact", entityId: row.id, after: values });
    }
    revalidateCompany(companyId);
    return { ok: true, message: "Interlocuteur enregistré." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

export async function deleteContactAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const id = s(fd, "id");
    const [row] = await db.delete(schema.companyContacts).where(and(eq(schema.companyContacts.id, id), eq(schema.companyContacts.companyId, companyId))).returning();
    if (!row) return { error: "Interlocuteur introuvable." };
    await audit({ action: "contact.delete", userId: ctx.user.id, companyId, entityType: "contact", entityId: id, before: row });
    revalidateCompany(companyId);
    return { ok: true, message: "Interlocuteur retiré." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

// ---------- Membres et rôles ----------

const ASSIGNABLE_ROLES = ["owner", "admin", "hr", "payroll", "manager", "accountant", "viewer"] as const;

async function ownerCount(companyId: string) {
  const [{ n }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.companyMemberships)
    .where(and(eq(schema.companyMemberships.companyId, companyId), eq(schema.companyMemberships.role, "owner")));
  return n;
}

export async function updateMemberRoleAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "members.manage");
    const membershipId = s(fd, "membershipId");
    const role = s(fd, "role");
    if (!(ASSIGNABLE_ROLES as readonly string[]).includes(role)) return { error: "Rôle inconnu." };
    const [m] = await db.select().from(schema.companyMemberships).where(and(eq(schema.companyMemberships.id, membershipId), eq(schema.companyMemberships.companyId, companyId))).limit(1);
    if (!m) return { error: "Membre introuvable." };
    if (m.role === "employee") return { error: "Les salariés gèrent leur accès depuis leur dossier." };
    if (role === "owner" && ctx.role !== "owner" && ctx.user.platformRole !== "platform_admin") return { error: "Seul un propriétaire peut désigner un autre propriétaire." };
    if (m.role === "owner" && role !== "owner" && (await ownerCount(companyId)) <= 1) return { error: "L'entreprise doit garder au moins un propriétaire." };
    await db.update(schema.companyMemberships).set({ role: role as (typeof ASSIGNABLE_ROLES)[number] }).where(eq(schema.companyMemberships.id, membershipId));
    await audit({ action: "member.role_change", userId: ctx.user.id, companyId, entityType: "membership", entityId: membershipId, before: { role: m.role, userId: m.userId }, after: { role } });
    revalidateCompany(companyId);
    return { ok: true, message: `Rôle modifié : ${roleLabels[role]}.` };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

export async function removeMemberAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "members.manage");
    const membershipId = s(fd, "membershipId");
    const [m] = await db.select().from(schema.companyMemberships).where(and(eq(schema.companyMemberships.id, membershipId), eq(schema.companyMemberships.companyId, companyId))).limit(1);
    if (!m) return { error: "Membre introuvable." };
    if (m.role === "owner" && (await ownerCount(companyId)) <= 1) return { error: "Impossible de retirer le dernier propriétaire." };
    if (m.userId === ctx.user.id) return { error: "Vous ne pouvez pas retirer votre propre accès. Demandez à un autre administrateur." };
    await db.delete(schema.companyMemberships).where(eq(schema.companyMemberships.id, membershipId));
    await audit({ action: "member.remove", userId: ctx.user.id, companyId, entityType: "membership", entityId: membershipId, before: m });
    revalidateCompany(companyId);
    return { ok: true, message: "Accès retiré." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

// ---------- Invitations ----------

function sentMessage(status: string, isDemo: boolean) {
  if (status === "sent") return "Invitation envoyée par e-mail.";
  if (isDemo) return "Mode démonstration : aucun e-mail n'est parti. Copiez le lien ci-dessous si besoin.";
  if (!integrations.mail()) return "Le service e-mail n'est pas configuré : copiez le lien ci-dessous et transmettez-le à la personne.";
  return "L'envoi de l'e-mail a échoué : copiez le lien ci-dessous et transmettez-le à la personne.";
}

export async function createInvitationAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "members.manage");
    const email = s(fd, "email").toLowerCase();
    const role = s(fd, "role");
    if (!isEmail(email)) return { error: "Adresse e-mail invalide." };
    if (!(ASSIGNABLE_ROLES as readonly string[]).includes(role)) return { error: "Rôle inconnu." };
    if (role === "owner" && ctx.role !== "owner" && ctx.user.platformRole !== "platform_admin") return { error: "Seul un propriétaire peut inviter un autre propriétaire." };
    const [existingMember] = await db
      .select({ id: schema.companyMemberships.id })
      .from(schema.companyMemberships)
      .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
      .where(and(eq(schema.companyMemberships.companyId, companyId), eq(schema.users.email, email)))
      .limit(1);
    if (existingMember) return { error: "Cette personne a déjà accès à l'entreprise." };
    const [pending] = await db
      .select()
      .from(schema.invitations)
      .where(and(eq(schema.invitations.companyId, companyId), eq(schema.invitations.email, email), eq(schema.invitations.status, "pending")))
      .limit(1);
    if (pending) return { error: "Une invitation est déjà en attente pour cette adresse : utilisez « Renvoyer »." };
    const [inv] = await db
      .insert(schema.invitations)
      .values({ tenantId: ctx.company.tenantId, companyId, email, role, invitedBy: ctx.user.id, tokenHash: sha256(randomToken(32)), expiresAt: new Date(Date.now() + 7 * 86400_000) })
      .returning();
    const { link, status } = await issueInvitation(ctx, inv);
    await audit({ action: "invitation.create", userId: ctx.user.id, companyId, tenantId: ctx.company.tenantId, entityType: "invitation", entityId: inv.id, after: { email, role, mail: status } });
    revalidateCompany(companyId);
    return { ok: true, message: sentMessage(status, ctx.company.isDemo), data: status === "sent" ? {} : { link } };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

export async function resendInvitationAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "members.manage");
    const id = s(fd, "id");
    const [inv] = await db.select().from(schema.invitations).where(and(eq(schema.invitations.id, id), eq(schema.invitations.companyId, companyId))).limit(1);
    if (!inv) return { error: "Invitation introuvable." };
    if (inv.status === "accepted") return { error: "Cette invitation a déjà été acceptée." };
    const { link, status } = await issueInvitation(ctx, inv);
    await audit({ action: "invitation.resend", userId: ctx.user.id, companyId, entityType: "invitation", entityId: id, after: { mail: status } });
    revalidateCompany(companyId);
    return { ok: true, message: sentMessage(status, ctx.company.isDemo), data: status === "sent" ? {} : { link } };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

export async function revokeInvitationAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const companyId = s(fd, "companyId");
  try {
    const ctx = await requireCompany(companyId, "members.manage");
    const id = s(fd, "id");
    const [inv] = await db.select().from(schema.invitations).where(and(eq(schema.invitations.id, id), eq(schema.invitations.companyId, companyId))).limit(1);
    if (!inv) return { error: "Invitation introuvable." };
    if (inv.status !== "pending") return { error: "Seule une invitation en attente peut être révoquée." };
    await db.update(schema.invitations).set({ status: "revoked" }).where(eq(schema.invitations.id, id));
    await db
      .update(schema.oneTimeTokens)
      .set({ usedAt: new Date() })
      .where(and(eq(schema.oneTimeTokens.purpose, "invite"), sql`${schema.oneTimeTokens.payload}->>'invitationId' = ${id}`, sql`${schema.oneTimeTokens.usedAt} is null`));
    await audit({ action: "invitation.revoke", userId: ctx.user.id, companyId, entityType: "invitation", entityId: id, before: { status: inv.status, email: inv.email } });
    revalidateCompany(companyId);
    return { ok: true, message: "Invitation révoquée : le lien ne fonctionne plus." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}
