"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { audit } from "@/server/audit";
import { createDocument } from "@/server/documents/store";
import { lookupCompany } from "@/server/onboarding/company-lookup";
import type { CompanySuggestion } from "@/server/onboarding/lookup-parse";
import { getOnboardingChecklist } from "@/server/onboarding/checklist";
import { CONFIRMABLE, headcountBracketLabels, readPayrollSettings, workTimeLabels, type PayrollSettings } from "@/server/onboarding/payroll-settings";
import { normalizeStep } from "@/components/onboarding/steps";
import { checkApe, checkIdcc, checkPostalCode, checkRate, checkSiren, checkSiret, parseAmountToCents } from "@/lib/validators";
import type { ActionState } from "./auth";

export type AutosaveResult = { ok: boolean; errors: Record<string, string>; savedAt?: string; error?: string };

const LEGAL_FORMS = schema.legalFormEnum.enumValues as readonly string[];

export type CompanyPatch = Partial<Record<
  "legalName" | "tradeName" | "siren" | "legalForm" | "activity" | "apeCode" | "addressLine1" | "addressLine2" | "postalCode" | "city" | "headcount" | "idcc" | "collectiveAgreement" | "idccConfirmed",
  string | boolean | null
>>;

/** Enregistrement automatique des informations société (champ par champ, valeurs invalides refusées). */
export async function autosaveCompanyAction(companyId: string, patch: CompanyPatch): Promise<AutosaveResult> {
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const errors: Record<string, string> = {};
    const set: Partial<typeof schema.companies.$inferInsert> = {};
    const text = (v: unknown, max = 200) => (typeof v === "string" ? v.trim().slice(0, max) || null : null);
    for (const [key, raw] of Object.entries(patch)) {
      switch (key) {
        case "legalName": {
          const v = text(raw);
          if (!v) errors.legalName = "La raison sociale est obligatoire.";
          else set.legalName = v;
          break;
        }
        case "tradeName":
        case "activity":
        case "addressLine1":
        case "addressLine2":
        case "city":
        case "collectiveAgreement":
          (set as Record<string, unknown>)[key] = text(raw);
          break;
        case "siren": {
          const v = text(raw);
          if (!v) set.siren = null;
          else {
            const r = checkSiren(v);
            if (r.ok) set.siren = r.value;
            else errors.siren = r.error;
          }
          break;
        }
        case "legalForm": {
          const v = text(raw);
          if (!v) set.legalForm = null;
          else if (LEGAL_FORMS.includes(v)) set.legalForm = v as (typeof schema.legalFormEnum.enumValues)[number];
          else errors.legalForm = "Forme juridique inconnue.";
          break;
        }
        case "apeCode": {
          const v = text(raw);
          if (!v) set.apeCode = null;
          else {
            const r = checkApe(v);
            if (r.ok) set.apeCode = r.value;
            else errors.apeCode = r.error;
          }
          break;
        }
        case "postalCode": {
          const v = text(raw);
          if (!v) set.postalCode = null;
          else {
            const r = checkPostalCode(v);
            if (r.ok) set.postalCode = r.value;
            else errors.postalCode = r.error;
          }
          break;
        }
        case "headcount": {
          const v = text(raw);
          if (!v) set.headcount = null;
          else if (/^\d{1,6}$/.test(v)) set.headcount = Number(v);
          else errors.headcount = "Indiquez un nombre entier de salariés.";
          break;
        }
        case "idcc": {
          const v = text(raw);
          if (!v) set.idcc = null;
          else {
            const r = checkIdcc(v);
            if (r.ok) set.idcc = r.value;
            else errors.idcc = r.error;
          }
          break;
        }
        case "idccConfirmed":
          set.idccConfirmed = raw === true;
          break;
      }
    }
    const before = ctx.company;
    // Toute modification de la convention annule sa confirmation.
    if (("idcc" in set && set.idcc !== before.idcc) || ("collectiveAgreement" in set && set.collectiveAgreement !== before.collectiveAgreement)) {
      if (!("idccConfirmed" in patch)) set.idccConfirmed = false;
    }
    if (set.idccConfirmed && !(set.idcc ?? before.idcc)) {
      errors.idccConfirmed = "Renseignez l'IDCC avant de confirmer.";
      delete set.idccConfirmed;
    }
    const changed = Object.fromEntries(Object.entries(set).filter(([k, v]) => (before as Record<string, unknown>)[k] !== v));
    if (Object.keys(changed).length) {
      await db.update(schema.companies).set(changed).where(eq(schema.companies.id, companyId));
      await audit({
        action: "company.update",
        userId: ctx.user.id,
        companyId,
        tenantId: ctx.company.tenantId,
        entityType: "company",
        entityId: companyId,
        before: Object.fromEntries(Object.keys(changed).map((k) => [k, (before as Record<string, unknown>)[k]])),
        after: changed,
      });
      revalidatePath(`/app/${companyId}`, "layout");
    }
    return { ok: Object.keys(errors).length === 0, errors, savedAt: new Date().toISOString() };
  } catch (e) {
    return { ok: false, errors: {}, error: authErrorMessage(e) ?? "Enregistrement impossible." };
  }
}

export type SettingsPatch = {
  paymentDay?: string;
  headcountBracket?: string;
  atRate?: string;
  mobilityRate?: string;
  mutuelle?: { enabled: boolean; name?: string; employer?: string; employee?: string };
  prevoyance?: { enabled: boolean; name?: string; cadreEmployerRate?: string; cadreEmployeeRate?: string; nonCadreEmployerRate?: string; nonCadreEmployeeRate?: string };
  workTime?: string;
  previousProvider?: string;
  preparers?: string[];
  validators?: string[];
  establishmentIds?: string[];
  firstPeriod?: string;
  confirmed?: Record<string, boolean>;
};

/** Enregistrement automatique de companies.payroll_settings (contrat partagé avec la paie). */
export async function autosavePayrollSettingsAction(companyId: string, patch: SettingsPatch): Promise<AutosaveResult> {
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const current = readPayrollSettings(ctx.company.payrollSettings);
    const next: Record<string, unknown> = { ...(ctx.company.payrollSettings as Record<string, unknown>), ...current };
    const errors: Record<string, string> = {};
    const confirmed = { ...current.confirmed };
    const touch = (k: string) => {
      if (k in CONFIRMABLE && !(patch.confirmed && k in patch.confirmed)) confirmed[k] = false;
    };

    if (patch.paymentDay !== undefined) {
      const n = Number(patch.paymentDay);
      if (!Number.isInteger(n) || n < 1 || n > 31) errors.paymentDay = "Indiquez un jour entre 1 et 31.";
      else if (n !== current.paymentDay) {
        next.paymentDay = n;
        touch("paymentDay");
      }
    }
    if (patch.headcountBracket !== undefined) {
      if (!(patch.headcountBracket in headcountBracketLabels)) errors.headcountBracket = "Tranche inconnue.";
      else if (patch.headcountBracket !== current.headcountBracket) {
        next.headcountBracket = patch.headcountBracket;
        touch("headcountBracket");
      }
    }
    for (const k of ["atRate", "mobilityRate"] as const) {
      const raw = patch[k];
      if (raw === undefined) continue;
      if (raw.trim() === "") {
        if (current[k] !== undefined) {
          delete next[k];
          touch(k);
        }
        continue;
      }
      const r = checkRate(raw, k === "atRate" ? "Le taux AT/MP" : "Le taux de versement mobilité");
      if (!r.ok) errors[k] = r.error;
      else if (k === "atRate" && Number(r.value) === 0) errors[k] = "Le taux AT/MP ne peut pas être nul : il figure sur votre notification annuelle.";
      else if (r.value !== current[k]) {
        next[k] = r.value;
        touch(k);
      }
    }
    if (patch.mutuelle) {
      let value: PayrollSettings["mutuelle"] = null;
      if (patch.mutuelle.enabled) {
        const er = parseAmountToCents(patch.mutuelle.employer ?? "0") ?? NaN;
        const ee = parseAmountToCents(patch.mutuelle.employee ?? "0") ?? NaN;
        if (Number.isNaN(er) || er < 0) errors.mutuelleEmployer = "Montant mensuel invalide, par exemple 38,60.";
        if (Number.isNaN(ee) || ee < 0) errors.mutuelleEmployee = "Montant mensuel invalide, par exemple 25,74.";
        value = { name: (patch.mutuelle.name ?? "").trim().slice(0, 120), employerCents: Number.isNaN(er) ? 0 : er, employeeCents: Number.isNaN(ee) ? 0 : ee };
        if (!errors.mutuelleEmployer && !errors.mutuelleEmployee && er > 0 && ee > 0 && er < ee) errors.mutuelleEmployer = "L'employeur doit financer au moins 50 % de la mutuelle (part employeur ≥ part salarié).";
      }
      if (!errors.mutuelleEmployer && !errors.mutuelleEmployee && JSON.stringify(value) !== JSON.stringify(current.mutuelle ?? undefined)) {
        next.mutuelle = value;
        touch("mutuelle");
      }
    }
    if (patch.prevoyance) {
      let value: PayrollSettings["prevoyance"] = null;
      if (patch.prevoyance.enabled) {
        const p = patch.prevoyance;
        const rates = { cadreEmployerRate: p.cadreEmployerRate ?? "0", cadreEmployeeRate: p.cadreEmployeeRate ?? "0", nonCadreEmployerRate: p.nonCadreEmployerRate ?? "0", nonCadreEmployeeRate: p.nonCadreEmployeeRate ?? "0" };
        const normalized: Record<string, string> = {};
        for (const [k, v] of Object.entries(rates)) {
          const r = checkRate(v || "0", "Le taux");
          if (!r.ok) errors[`prevoyance.${k}`] = r.error;
          else normalized[k] = r.value;
        }
        if (!Object.keys(errors).some((k) => k.startsWith("prevoyance."))) {
          if (Number(normalized.cadreEmployerRate) > 0 && Number(normalized.cadreEmployerRate) < 1.5) errors["prevoyance.cadreEmployerRate"] = "Pour les cadres, l'employeur doit verser au moins 1,50 % de la tranche A.";
          value = { name: (p.name ?? "").trim().slice(0, 120), ...(normalized as Omit<NonNullable<PayrollSettings["prevoyance"]>, "name">) };
        }
      }
      if (!Object.keys(errors).some((k) => k.startsWith("prevoyance.")) && JSON.stringify(value) !== JSON.stringify(current.prevoyance ?? undefined)) {
        next.prevoyance = value;
        touch("prevoyance");
      }
    }
    if (patch.workTime !== undefined) {
      if (!(patch.workTime in workTimeLabels)) errors.workTime = "Organisation inconnue.";
      else if (patch.workTime !== current.workTime) {
        next.workTime = patch.workTime;
        touch("workTime");
      }
    }
    if (patch.previousProvider !== undefined) {
      const v = patch.previousProvider.trim().slice(0, 120);
      if (v) next.previousProvider = v;
      else delete next.previousProvider;
    }
    if (patch.firstPeriod !== undefined) {
      if (patch.firstPeriod === "") delete next.firstPeriod;
      else if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(patch.firstPeriod)) errors.firstPeriod = "Choisissez un mois.";
      else next.firstPeriod = patch.firstPeriod;
    }
    if (patch.preparers || patch.validators || patch.establishmentIds) {
      const members = await db.select({ userId: schema.companyMemberships.userId }).from(schema.companyMemberships).where(eq(schema.companyMemberships.companyId, companyId));
      const valid = new Set(members.map((m) => m.userId));
      if (patch.preparers) next.preparers = patch.preparers.filter((id) => valid.has(id));
      if (patch.validators) next.validators = patch.validators.filter((id) => valid.has(id));
      if (patch.establishmentIds) {
        const est = await db.select({ id: schema.establishments.id }).from(schema.establishments).where(eq(schema.establishments.companyId, companyId));
        const ok = new Set(est.map((e) => e.id));
        next.establishmentIds = patch.establishmentIds.filter((id) => ok.has(id));
      }
    }
    if (patch.confirmed) {
      for (const [k, v] of Object.entries(patch.confirmed)) {
        if (!(k in CONFIRMABLE)) continue;
        const has = k === "mutuelle" || k === "prevoyance" ? next[k] !== undefined : next[k] !== undefined && next[k] !== "";
        if (v && !has) errors[`confirm.${k}`] = "Renseignez la valeur avant de la confirmer.";
        else confirmed[k] = v === true;
      }
    }
    next.confirmed = confirmed;
    if (!next.preparers) next.preparers = [];
    if (!next.validators) next.validators = [];

    const before = ctx.company.payrollSettings;
    if (JSON.stringify(before) !== JSON.stringify(next)) {
      await db.update(schema.companies).set({ payrollSettings: next }).where(eq(schema.companies.id, companyId));
      await audit({ action: "company.payroll_settings", userId: ctx.user.id, companyId, tenantId: ctx.company.tenantId, entityType: "company", entityId: companyId, before, after: next });
    }
    return { ok: Object.keys(errors).length === 0, errors, savedAt: new Date().toISOString() };
  } catch (e) {
    return { ok: false, errors: {}, error: authErrorMessage(e) ?? "Enregistrement impossible." };
  }
}

export async function setOnboardingStepAction(companyId: string, step: string): Promise<ActionState> {
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const s = normalizeStep(step);
    if (ctx.company.onboardingStep !== s) await db.update(schema.companies).set({ onboardingStep: s }).where(eq(schema.companies.id, companyId));
    return { ok: true };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}

/** Recherche dans le répertoire public : renvoie une suggestion, n'enregistre rien. */
export async function lookupSirenAction(companyId: string, siren: string): Promise<{ suggestion?: CompanySuggestion; error?: string }> {
  try {
    await requireCompany(companyId, "company.manage");
    const r = await lookupCompany(siren);
    return r.ok ? { suggestion: r.suggestion } : { error: r.message };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Suggestion indisponible, saisissez manuellement." };
  }
}

/** Applique uniquement les suggestions cochées par l'utilisateur. L'IDCC reste à confirmer. */
export async function applySuggestionAction(companyId: string, fields: Record<string, string>): Promise<AutosaveResult> {
  const allowed = ["legalName", "tradeName", "apeCode", "legalForm", "addressLine1", "postalCode", "city", "idcc"];
  const patch: CompanyPatch = {};
  for (const k of allowed) if (typeof fields[k] === "string") (patch as Record<string, string>)[k] = fields[k];
  if (patch.idcc) patch.idccConfirmed = false;
  const res = await autosaveCompanyAction(companyId, patch);
  if (res.error) return res;
  if (fields.headOfficeSiret) {
    try {
      const ctx = await requireCompany(companyId, "company.manage");
      const r = checkSiret(fields.headOfficeSiret, ctx.company.siren);
      if (r.ok) {
        const [head] = await db
          .select()
          .from(schema.establishments)
          .where(and(eq(schema.establishments.companyId, companyId), eq(schema.establishments.isHeadOffice, true)))
          .limit(1);
        if (head && !head.siret) {
          await db
            .update(schema.establishments)
            .set({ siret: r.value, nic: r.value.slice(9), addressLine1: head.addressLine1 ?? fields.addressLine1 ?? null, postalCode: head.postalCode ?? fields.postalCode ?? null, city: head.city ?? fields.city ?? null })
            .where(eq(schema.establishments.id, head.id));
          await audit({ action: "establishment.update", userId: ctx.user.id, companyId, entityType: "establishment", entityId: head.id, before: { siret: null }, after: { siret: r.value, source: "suggestion" } });
        }
      }
    } catch {
      // la suggestion SIRET est facultative
    }
  }
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    await audit({ action: "company.suggestion_applied", userId: ctx.user.id, companyId, entityType: "company", entityId: companyId, after: { fields: Object.keys(fields), source: "recherche-entreprises.api.gouv.fr" } });
  } catch {
    // déjà contrôlé par autosaveCompanyAction
  }
  revalidatePath(`/app/${companyId}/onboarding`);
  return res;
}

const MAX_UPLOAD = 8 * 1024 * 1024;

/** Dépôt d'un document d'entreprise (Kbis, statuts, notification AT…). */
export async function uploadCompanyDocumentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const companyId = String(formData.get("companyId") ?? "");
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const file = formData.get("file");
    const category = String(formData.get("category") ?? "entreprise");
    if (!(file instanceof File) || file.size === 0) return { error: "Choisissez un fichier." };
    if (file.size > MAX_UPLOAD) return { error: "Fichier trop lourd (8 Mo maximum)." };
    if (!["application/pdf", "image/png", "image/jpeg"].includes(file.type)) return { error: "Formats acceptés : PDF, PNG ou JPEG." };
    if (!["kbis", "entreprise", "justificatif"].includes(category)) return { error: "Catégorie inconnue." };
    const title = String(formData.get("title") ?? "").trim() || (category === "kbis" ? "Extrait Kbis" : file.name);
    const doc = await createDocument({
      companyId,
      category: category as "kbis" | "entreprise" | "justificatif",
      visibility: "restricted",
      title: title.slice(0, 160),
      fileName: file.name,
      mimeType: file.type,
      data: Buffer.from(await file.arrayBuffer()),
      uploadedBy: ctx.user.id,
      sourceType: "onboarding",
      isDemo: ctx.company.isDemo,
    });
    await audit({ action: "document.upload", userId: ctx.user.id, companyId, entityType: "document", entityId: doc.id, after: { category, title } });
    revalidatePath(`/app/${companyId}/onboarding`);
    return { ok: true, message: "Document enregistré." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Dépôt impossible." };
  }
}

/** Pose onboarding_completed_at si aucun élément bloquant ne reste. */
export async function completeOnboardingAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const companyId = String(formData.get("companyId") ?? "");
  try {
    const ctx = await requireCompany(companyId, "company.manage");
    const checklist = await getOnboardingChecklist(companyId);
    if (checklist.blockingCount > 0) {
      const list = checklist.items.filter((i) => i.status === "blocking").map((i) => i.label).join(", ");
      return { error: `Il reste ${checklist.blockingCount} élément(s) bloquant(s) pour la première paie : ${list}.` };
    }
    await db.update(schema.companies).set({ onboardingCompletedAt: new Date(), onboardingStep: "verification" }).where(eq(schema.companies.id, companyId));
    await audit({ action: "company.onboarding_completed", userId: ctx.user.id, companyId, entityType: "company", entityId: companyId, after: { progress: checklist.progress } });
    revalidatePath(`/app/${companyId}`, "layout");
    return { ok: true, message: "Onboarding terminé. Vous pouvez préparer la première paie." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Erreur" };
  }
}
