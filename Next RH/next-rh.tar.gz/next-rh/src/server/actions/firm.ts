"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { and, eq, inArray } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { sha256 } from "@/lib/crypto";
import { appUrl } from "@/lib/env";
import { checkSiren } from "@/lib/validators";
import { issueToken, requireUser } from "@/server/auth";
import { requireCompany } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { layoutMail, sendMail } from "@/server/mail";
import { bootstrapCompanyDefaults } from "@/server/company-defaults";
import { canCreateFirmCompany } from "@/server/firm/dossiers";
import type { ActionState } from "./auth";

const uuid = z.string().uuid();
const MANAGER_ROLES = ["admin", "payroll", "hr", "accountant", "manager", "viewer"] as const;

const companySchema = z.object({
  legalName: z.string().trim().min(2, "Raison sociale requise").max(160),
  tradeName: z.string().trim().max(160).optional().or(z.literal("")),
  siren: z.string().trim().optional().or(z.literal("")),
});

/** Nouvelle entreprise dans le tenant du cabinet : companies + membership owner + paramètres par défaut. */
export async function createFirmCompanyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const user = await requireUser();
    if (!user.emailVerified) return { error: "Vérifiez votre adresse e-mail avant de continuer." };
    const allowed = await canCreateFirmCompany(user);
    if (!allowed.ok) return { error: allowed.reason };
    const parsed = companySchema.safeParse(Object.fromEntries(formData));
    if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Formulaire invalide" };
    let siren: string | null = null;
    if (parsed.data.siren) {
      const s = checkSiren(parsed.data.siren);
      if (!s.ok) return { error: s.error };
      siren = s.value;
      const [dup] = await db
        .select({ id: schema.companies.id })
        .from(schema.companies)
        .where(and(eq(schema.companies.tenantId, allowed.tenant.id), eq(schema.companies.siren, siren)))
        .limit(1);
      if (dup) return { error: "Une entreprise avec ce SIREN existe déjà dans votre cabinet." };
    }
    const company = await db.transaction(async (tx) => {
      const [c] = await tx
        .insert(schema.companies)
        .values({ tenantId: allowed.tenant.id, legalName: parsed.data.legalName, tradeName: parsed.data.tradeName || null, siren, onboardingStep: "company", isDemo: allowed.tenant.isDemo })
        .returning();
      await tx.insert(schema.companyMemberships).values({ companyId: c.id, userId: user.id, role: "owner" });
      await bootstrapCompanyDefaults(tx, c.id);
      return c;
    });
    await audit({ action: "company.create", userId: user.id, tenantId: allowed.tenant.id, companyId: company.id, entityType: "company", entityId: company.id, after: { legalName: company.legalName, siren } });
    revalidatePath("/app/entreprises");
    return { ok: true, message: `Dossier « ${company.legalName} » créé.`, data: { companyId: company.id } };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Création impossible." };
  }
}

/** Affecte (ou retire) un membre du cabinet à une entreprise avec un rôle. */
export async function assignManagerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const companyId = uuid.parse(formData.get("companyId"));
    const userId = uuid.parse(formData.get("userId"));
    const role = String(formData.get("role") ?? "");
    const ctx = await requireCompany(companyId, "members.manage");

    const [target] = await db.select().from(schema.users).where(eq(schema.users.id, userId)).limit(1);
    if (!target) return { error: "Utilisateur introuvable." };
    const [current] = await db
      .select()
      .from(schema.companyMemberships)
      .where(and(eq(schema.companyMemberships.companyId, companyId), eq(schema.companyMemberships.userId, userId)))
      .limit(1);
    // Isolation : seuls les membres du même tenant (ou déjà affectés) peuvent être affectés.
    if (target.tenantId !== ctx.company.tenantId && !current) return { error: "Cette personne ne fait pas partie de votre organisation : invitez-la par e-mail." };
    if (current?.role === "employee") return { error: "Ce compte est un accès salarié : il se gère depuis la fiche du salarié." };

    if (role === "none") {
      if (!current) return { ok: true, message: "Aucune affectation à retirer." };
      if (current.role === "owner") {
        const owners = await db
          .select({ id: schema.companyMemberships.id })
          .from(schema.companyMemberships)
          .where(and(eq(schema.companyMemberships.companyId, companyId), eq(schema.companyMemberships.role, "owner")));
        if (owners.length <= 1) return { error: "Impossible de retirer le dernier propriétaire de l'entreprise." };
      }
      await db.delete(schema.companyMemberships).where(eq(schema.companyMemberships.id, current.id));
      await audit({ action: "membership.remove", userId: ctx.user.id, companyId, tenantId: ctx.company.tenantId, entityType: "company_membership", entityId: current.id, before: { userId, role: current.role } });
    } else {
      if (!(MANAGER_ROLES as readonly string[]).includes(role) && !(role === "owner" && current?.role === "owner")) return { error: "Rôle non autorisé." };
      if (current?.role === "owner" && role !== "owner") {
        const owners = await db
          .select({ id: schema.companyMemberships.id })
          .from(schema.companyMemberships)
          .where(and(eq(schema.companyMemberships.companyId, companyId), eq(schema.companyMemberships.role, "owner")));
        if (owners.length <= 1) return { error: "Impossible de changer le rôle du dernier propriétaire." };
      }
      const r = role as (typeof schema.companyRoleEnum.enumValues)[number];
      if (current) {
        await db.update(schema.companyMemberships).set({ role: r }).where(eq(schema.companyMemberships.id, current.id));
      } else {
        await db.insert(schema.companyMemberships).values({ companyId, userId, role: r });
      }
      await audit({ action: current ? "membership.update" : "membership.assign", userId: ctx.user.id, companyId, tenantId: ctx.company.tenantId, entityType: "company_membership", entityId: current?.id ?? null, before: current ? { userId, role: current.role } : null, after: { userId, role } });
    }
    revalidatePath("/app/entreprises/gestionnaires");
    revalidatePath("/app/entreprises");
    return { ok: true, message: role === "none" ? "Affectation retirée." : "Affectation enregistrée." };
  } catch (e) {
    if (e instanceof z.ZodError) return { error: "Paramètres invalides." };
    return { error: authErrorMessage(e) ?? "Modification impossible." };
  }
}

const inviteSchema = z.object({
  companyIds: z.array(z.string().uuid()).min(1, "Choisissez au moins une entreprise."),
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide"),
  role: z.enum(MANAGER_ROLES),
});

/** Invitation d'un gestionnaire sur une ou plusieurs entreprises (une invitation par entreprise). */
export async function inviteManagerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const parsed = inviteSchema.safeParse({ companyIds: formData.getAll("companyIds").map(String), email: formData.get("email"), role: formData.get("role") });
    if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Formulaire invalide" };
    const { email, role, companyIds } = parsed.data;
    const links: string[] = [];
    let sent = 0;
    for (const companyId of companyIds) {
      const ctx = await requireCompany(companyId, "members.manage");
      const [already] = await db
        .select({ id: schema.companyMemberships.id })
        .from(schema.companyMemberships)
        .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
        .where(and(eq(schema.companyMemberships.companyId, companyId), eq(schema.users.email, email)))
        .limit(1);
      if (already) continue;
      await db
        .update(schema.invitations)
        .set({ status: "revoked" })
        .where(and(eq(schema.invitations.companyId, companyId), eq(schema.invitations.email, email), inArray(schema.invitations.status, ["pending"])));
      const invitationId = randomUUID();
      const token = await issueToken("invite", { email, payload: { invitationId }, ttlMinutes: 7 * 24 * 60 });
      await db.insert(schema.invitations).values({
        id: invitationId,
        tenantId: ctx.company.tenantId,
        companyId,
        email,
        role,
        invitedBy: ctx.user.id,
        tokenHash: sha256(token),
        expiresAt: new Date(Date.now() + 7 * 86400_000),
      });
      const url = `${appUrl()}/invitation/${token}`;
      const name = ctx.company.tradeName ?? ctx.company.legalName;
      const res = await sendMail({
        to: email,
        subject: `Invitation à gérer ${name} sur Next RH`,
        html: layoutMail(`Invitation : ${name}`, `<p>${ctx.user.firstName} ${ctx.user.lastName} vous invite à rejoindre le dossier ${name} sur Next RH. Ce lien est valable 7 jours.</p>`, { label: "Accepter l'invitation", url }),
        text: `Invitation à rejoindre ${name} sur Next RH : ${url}`,
        isDemo: ctx.company.isDemo,
      });
      if (res.status === "sent") sent++;
      else links.push(`${name} : ${url}`);
      await audit({ action: "invitation.create", userId: ctx.user.id, companyId, tenantId: ctx.company.tenantId, entityType: "invitation", entityId: invitationId, after: { email, role, mail: res.status } });
    }
    revalidatePath("/app/entreprises/gestionnaires");
    if (!sent && !links.length) return { ok: true, message: "Cette personne a déjà accès aux entreprises choisies." };
    return {
      ok: true,
      message: links.length
        ? "Invitation enregistrée. L'e-mail n'est pas parti (service e-mail non configuré ou démonstration) : transmettez le lien ci-dessous."
        : `Invitation envoyée à ${email}.`,
      data: links.length ? { links: links.join("\n") } : undefined,
    };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Invitation impossible." };
  }
}

/** Révoque une invitation en attente. */
export async function revokeInvitationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const id = uuid.parse(formData.get("invitationId"));
    const [inv] = await db.select().from(schema.invitations).where(eq(schema.invitations.id, id)).limit(1);
    if (!inv?.companyId) return { error: "Invitation introuvable." };
    const ctx = await requireCompany(inv.companyId, "members.manage");
    await db.update(schema.invitations).set({ status: "revoked" }).where(eq(schema.invitations.id, id));
    await audit({ action: "invitation.revoke", userId: ctx.user.id, companyId: inv.companyId, tenantId: inv.tenantId, entityType: "invitation", entityId: id, before: { email: inv.email } });
    revalidatePath("/app/entreprises/gestionnaires");
    return { ok: true, message: "Invitation révoquée." };
  } catch (e) {
    return { error: authErrorMessage(e) ?? "Révocation impossible." };
  }
}
