"use server";

import { revalidatePath } from "next/cache";
import { requireCompany } from "@/server/authz";
import type { ActionState } from "./auth";
import { employeeOf, euros, HrError, id, isoDate, optStr, runAction, str } from "@/server/hr/common";
import { addLine, approveReport, createReport, EXPENSE_CATEGORIES, rejectReport, removeLine, submitReport } from "@/server/hr/expenses";
import { fileFrom } from "@/server/hr/uploads";

async function actorFor(companyId: string) {
  const ctx = await requireCompany(companyId, "requests.approve");
  return { ctx, actor: { userId: ctx.user.id, companyId, tenantId: ctx.tenant.id, isDemo: ctx.company.isDemo } };
}

const refresh = (companyId: string, reportId?: string) => {
  revalidatePath(`/app/${companyId}/frais`);
  if (reportId) revalidatePath(`/app/${companyId}/frais/${reportId}`);
  revalidatePath(`/app/${companyId}`);
};

export async function createExpenseReportAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const { actor } = await actorFor(companyId);
    const employeeId = id(fd, "employeeId");
    await employeeOf(companyId, employeeId);
    const row = await createReport(actor, employeeId, str(fd, "title"));
    refresh(companyId);
    return { ok: true, message: "Note créée : ajoutez les dépenses.", data: { reportId: row.id, href: `/app/${companyId}/frais/${row.id}` } };
  });
}

export async function addExpenseLineAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const { actor } = await actorFor(companyId);
    const reportId = id(fd, "reportId");
    const category = str(fd, "category");
    if (!EXPENSE_CATEGORIES.some((c) => c.value === category)) throw new HrError("Catégorie invalide.");
    const label = str(fd, "label");
    if (!label) throw new HrError("Décrivez la dépense.");
    await addLine(actor, reportId, {
      date: isoDate(fd, "date", "Date"),
      category,
      label,
      amountCents: euros(fd, "amount", "Montant TTC"),
      vatCents: str(fd, "vat") ? euros(fd, "vat", "TVA") : 0,
      receipt: fileFrom(fd, "receipt"),
    });
    refresh(companyId, reportId);
    return { ok: true, message: "Dépense ajoutée." };
  });
}

export async function removeExpenseLineAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const { actor } = await actorFor(companyId);
    const reportId = id(fd, "reportId");
    await removeLine(actor, reportId, id(fd, "lineId"));
    refresh(companyId, reportId);
    return { ok: true, message: "Dépense retirée." };
  });
}

export async function submitExpenseReportAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const { actor } = await actorFor(companyId);
    const reportId = id(fd, "reportId");
    const { missing } = await submitReport(actor, reportId);
    refresh(companyId, reportId);
    return { ok: true, message: missing ? `Note soumise. ${missing} dépense(s) sans justificatif.` : "Note soumise à validation." };
  });
}

export async function decideExpenseReportAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return runAction(async () => {
    const companyId = id(fd, "companyId");
    const { actor } = await actorFor(companyId);
    const reportId = id(fd, "reportId");
    const decision = str(fd, "decision");
    if (decision === "approve") {
      const res = await approveReport(actor, reportId);
      refresh(companyId, reportId);
      return { ok: true, message: res.shifted ? "Note validée. Paie du mois déjà validée : remboursement placé sur le mois suivant." : "Note validée : remboursement ajouté aux variables de paie." };
    }
    if (decision === "reject") {
      await rejectReport(actor, reportId, optStr(fd, "note"));
      refresh(companyId, reportId);
      return { ok: true, message: "Note refusée : le salarié peut la corriger et la soumettre à nouveau." };
    }
    throw new HrError("Décision inconnue.");
  });
}
