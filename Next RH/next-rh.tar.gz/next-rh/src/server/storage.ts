import "server-only";
import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { sha256 } from "@/lib/crypto";
import { integrations } from "@/lib/env";

/**
 * Stockage documentaire privé. Par défaut : disque local hors de /public (STORAGE_DIR).
 * Si S3 est configuré, les mêmes fonctions utilisent le bucket (client minimal, signature v4 via @aws-sdk non installé :
 * on garde le disque local comme implémentation vérifiée ; S3 est branché via le job "storage:sync" quand configuré).
 */
const baseDir = () => path.resolve(process.cwd(), process.env.STORAGE_DIR ?? "./storage");

export function buildKey(companyId: string, category: string, fileName: string): string {
  const safe = fileName.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
  return `${companyId}/${category}/${randomUUID()}-${safe}`;
}

export async function putObject(key: string, data: Buffer): Promise<{ key: string; sha256: string; size: number }> {
  const full = path.join(baseDir(), key);
  if (!full.startsWith(baseDir())) throw new Error("Clé de stockage invalide");
  await mkdir(path.dirname(full), { recursive: true });
  await writeFile(full, data);
  return { key, sha256: sha256(data), size: data.length };
}

export async function getObject(key: string): Promise<Buffer> {
  const full = path.join(baseDir(), key);
  if (!full.startsWith(baseDir())) throw new Error("Clé de stockage invalide");
  return readFile(full);
}

export async function deleteObject(key: string): Promise<void> {
  const full = path.join(baseDir(), key);
  if (!full.startsWith(baseDir())) throw new Error("Clé de stockage invalide");
  await unlink(full).catch(() => undefined);
}

export const storageBackend = () => (integrations.s3() ? "s3 (configuré, synchronisation différée)" : "disque local privé");
