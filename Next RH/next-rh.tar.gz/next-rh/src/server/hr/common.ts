import "server-only";
import { and, asc, desc, eq, inArray, lte, ne, or, isNull, gte } from "drizzle-orm";
import { unstable_rethrow } from "next/navigation";
import { db, schema } from "@/db";
import { authErrorMessage } from "@/server/guard";
import { requireCompany, type Permission } from "@/server/authz";
import { AuthError } from "@/server/auth";
import type { ActionState } from "@/server/actions/auth";
import { format } from "date-fns";

export type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
export type DbLike = typeof db | Tx;

/** Erreur métier affichable telle quelle à l'utilisateur. */
export class HrError extends Error {}

export const todayIso = () => format(new Date(), "yyyy-MM-dd");

export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Enveloppe commune des server actions : erreurs d'accès et métier converties en message. */
export async function runAction(fn: () => Promise<ActionState>): Promise<ActionState> {
  try {
    return await fn();
  } catch (e) {
    unstable_rethrow(e);
    const auth = authErrorMessage(e);
    if (auth) return { error: auth };
    if (e instanceof HrError) return { error: e.message };
    console.error("[hr action]", e);
    return { error: "Une erreur inattendue est survenue. Réessayez ou contactez le support." };
  }
}

export function str(fd: FormData, key: string): string {
  const v = fd.get(key);
  return typeof v === "string" ? v.trim() : "";
}
export function optStr(fd: FormData, key: string): string | null {
  const v = str(fd, key);
  return v ? v : null;
}
export function bool(fd: FormData, key: string): boolean {
  const v = fd.get(key);
  return v === "on" || v === "true" || v === "1";
}
export function id(fd: FormData, key: string): string {
  const v = str(fd, key);
  if (!UUID_RE.test(v)) throw new HrError("Identifiant invalide.");
  return v;
}
export function isoDate(fd: FormData, key: string, label: string): string {
  const v = str(fd, key);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new HrError(`${label} : date invalide.`);
  return v;
}
/** Montant saisi en euros (« 12,50 ») vers centimes. */
export function euros(fd: FormData, key: string, label: string): number {
  const raw = str(fd, key).replace(/\s/g, "").replace(",", ".");
  const n = Number(raw);
  if (!raw || !Number.isFinite(n) || n < 0) throw new HrError(`${label} : montant invalide.`);
  return Math.round(n * 100);
}

export const fullName = (e: { firstName: string; lastName: string }) => `${e.firstName} ${e.lastName}`;

/** Vérifie qu'un salarié appartient bien à l'entreprise (isolation). */
export async function employeeOf(companyId: string, employeeId: string, tx: DbLike = db) {
  const [e] = await tx
    .select()
    .from(schema.employees)
    .where(and(eq(schema.employees.id, employeeId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!e) throw new HrError("Salarié introuvable dans cette entreprise.");
  return e;
}

/** Salariés de l'entreprise (actifs et brouillons par défaut, sortis exclus). */
export async function listEmployees(companyId: string, opts: { includeLeft?: boolean } = {}) {
  return db
    .select({
      id: schema.employees.id,
      firstName: schema.employees.firstName,
      lastName: schema.employees.lastName,
      jobTitle: schema.employees.jobTitle,
      department: schema.employees.department,
      status: schema.employees.status,
      managerId: schema.employees.managerId,
      establishmentId: schema.employees.establishmentId,
      hireDate: schema.employees.hireDate,
      leaveDate: schema.employees.leaveDate,
      gender: schema.employees.gender,
      email: schema.employees.email,
      phone: schema.employees.phone,
      userId: schema.employees.userId,
    })
    .from(schema.employees)
    .where(and(eq(schema.employees.companyId, companyId), opts.includeLeft ? undefined : ne(schema.employees.status, "left")))
    .orderBy(asc(schema.employees.lastName), asc(schema.employees.firstName));
}

/** Contrat en vigueur à une date (le plus récent commencé, non terminé). */
export async function activeContract(employeeId: string, asOf = todayIso(), tx: DbLike = db) {
  const [c] = await tx
    .select()
    .from(schema.contracts)
    .where(
      and(
        eq(schema.contracts.employeeId, employeeId),
        lte(schema.contracts.startDate, asOf),
        or(isNull(schema.contracts.endDate), gte(schema.contracts.endDate, asOf)),
      ),
    )
    .orderBy(desc(schema.contracts.startDate))
    .limit(1);
  if (c) return c;
  const [latest] = await tx.select().from(schema.contracts).where(eq(schema.contracts.employeeId, employeeId)).orderBy(desc(schema.contracts.startDate)).limit(1);
  return latest ?? null;
}

/** Membres (gestionnaires) de l'entreprise : pour l'assignation et les conducteurs d'entretien. */
export async function listMembers(companyId: string) {
  return db
    .select({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, role: schema.companyMemberships.role })
    .from(schema.companyMemberships)
    .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
    .where(and(eq(schema.companyMemberships.companyId, companyId), ne(schema.companyMemberships.role, "employee")))
    .orderBy(asc(schema.users.lastName));
}

export async function usersByIds(ids: (string | null | undefined)[]) {
  const clean = [...new Set(ids.filter((x): x is string => Boolean(x)))];
  if (!clean.length) return new Map<string, string>();
  const rows = await db.select({ id: schema.users.id, f: schema.users.firstName, l: schema.users.lastName }).from(schema.users).where(inArray(schema.users.id, clean));
  return new Map(rows.map((r) => [r.id, `${r.f} ${r.l}`]));
}

/** Identifiants des salariés de l'entreprise : utilisé pour filtrer les tables rattachées au salarié. */
export async function employeeIdsOf(companyId: string): Promise<string[]> {
  const rows = await db.select({ id: schema.employees.id }).from(schema.employees).where(eq(schema.employees.companyId, companyId));
  return rows.map((r) => r.id);
}

/** Lit `?mois=2026-10` ou renvoie le mois courant. */
export function parseMonthParam(v: string | string[] | undefined): { year: number; month: number } {
  const s = Array.isArray(v) ? v[0] : v;
  const m = s?.match(/^(\d{4})-(\d{2})$/);
  if (m) {
    const month = Number(m[2]);
    if (month >= 1 && month <= 12) return { year: Number(m[1]), month };
  }
  const now = new Date();
  return { year: now.getFullYear(), month: now.getMonth() + 1 };
}

export const monthParam = (y: number, m: number) => `${y}-${String(m).padStart(2, "0")}`;

/** Exige au moins une des permissions (ex. RH ou manager). */
export async function requireAnyPermission(companyId: string, perms: Permission[]) {
  const ctx = await requireCompany(companyId);
  if (!perms.some((p) => ctx.permissions.has(p))) throw new AuthError("forbidden");
  return ctx;
}
