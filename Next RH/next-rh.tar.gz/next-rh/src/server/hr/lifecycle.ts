/** Modèles de parcours d'arrivée, de départ, de mobilité et de retour (tâches par responsable). */
export type TaskOwner = "rh" | "manager" | "it";
export type WorkflowKind = "onboarding" | "offboarding" | "mobility" | "return";
export type WorkflowTask = {
  id: string;
  label: string;
  owner: TaskOwner;
  dueDate: string;
  done: boolean;
  doneAt?: string | null;
  doneBy?: string | null;
};

export const ownerLabels: Record<TaskOwner, string> = { rh: "RH", manager: "Manager", it: "Informatique" };

export const kindLabels: Record<WorkflowKind, string> = {
  onboarding: "Arrivée",
  offboarding: "Départ",
  mobility: "Mobilité interne",
  return: "Retour d'absence longue",
};

export const targetDateLabels: Record<WorkflowKind, string> = {
  onboarding: "Date d'arrivée",
  offboarding: "Dernier jour",
  mobility: "Date de prise de poste",
  return: "Date de retour",
};

/** Tâches modèles : décalage en jours par rapport à la date cible (négatif = avant). */
export const TEMPLATES: Record<WorkflowKind, { label: string; owner: TaskOwner; offset: number }[]> = {
  onboarding: [
    { label: "Déclaration préalable à l'embauche (DPAE) envoyée à l'URSSAF", owner: "rh", offset: -8 },
    { label: "Contrat de travail signé par les deux parties", owner: "rh", offset: -5 },
    { label: "Dossier salarié complet (pièce d'identité, numéro de sécurité sociale, RIB)", owner: "rh", offset: -3 },
    { label: "Affiliation mutuelle et prévoyance", owner: "rh", offset: 5 },
    { label: "Visite d'information et de prévention planifiée", owner: "rh", offset: 30 },
    { label: "Poste de travail et matériel prêts", owner: "it", offset: -2 },
    { label: "Comptes et accès créés (messagerie, outils)", owner: "it", offset: -1 },
    { label: "Programme de la première semaine préparé", owner: "manager", offset: -3 },
    { label: "Accueil et présentation à l'équipe", owner: "manager", offset: 0 },
    { label: "Point d'étonnement à un mois", owner: "manager", offset: 30 },
  ],
  offboarding: [
    { label: "Notification écrite du départ (démission, rupture, fin de contrat) archivée", owner: "rh", offset: -20 },
    { label: "Solde de tout compte calculé", owner: "rh", offset: -3 },
    { label: "Certificat de travail et attestation France Travail préparés", owner: "rh", offset: 0 },
    { label: "Portabilité mutuelle et prévoyance communiquée", owner: "rh", offset: 0 },
    { label: "Passation des dossiers organisée", owner: "manager", offset: -10 },
    { label: "Entretien de départ réalisé", owner: "manager", offset: -3 },
    { label: "Matériel restitué (ordinateur, badge, téléphone)", owner: "it", offset: 0 },
    { label: "Accès désactivés", owner: "it", offset: 1 },
  ],
  mobility: [
    { label: "Avenant au contrat rédigé et signé", owner: "rh", offset: -10 },
    { label: "Mise à jour de la fiche salarié (poste, rattachement)", owner: "rh", offset: 0 },
    { label: "Passation avec le poste précédent", owner: "manager", offset: -5 },
    { label: "Droits d'accès adaptés au nouveau poste", owner: "it", offset: 0 },
    { label: "Point à un mois dans le nouveau poste", owner: "manager", offset: 30 },
  ],
  return: [
    { label: "Visite de reprise planifiée auprès de la médecine du travail", owner: "rh", offset: -5 },
    { label: "Entretien de retour planifié", owner: "manager", offset: 3 },
    { label: "Accès et matériel vérifiés", owner: "it", offset: -1 },
    { label: "Soldes de congés et rémunération vérifiés", owner: "rh", offset: 0 },
  ],
};
