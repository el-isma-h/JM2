/** Demandes RH : libellés et champs de fiche corrigeables par demande du salarié (non sensibles uniquement). */
export const HR_REQUEST_KINDS = [
  { value: "correction_informations", label: "Correction d'informations" },
  { value: "attestation", label: "Attestation (employeur, salaire…)" },
  { value: "justificatif", label: "Justificatif à transmettre" },
  { value: "acompte", label: "Demande d'acompte" },
  { value: "question", label: "Question" },
  { value: "autre", label: "Autre demande" },
] as const;

export const hrRequestKindLabel = (v: string) => HR_REQUEST_KINDS.find((k) => k.value === v)?.label ?? v;

/** Coordonnées et adresse : jamais l'identité, le NIR, le RIB, le contrat ou la rémunération. */
export const CORRECTABLE_FIELDS = {
  phone: { label: "Téléphone", max: 30 },
  personalEmail: { label: "E-mail personnel", max: 160 },
  addressLine1: { label: "Adresse", max: 160 },
  addressLine2: { label: "Complément d'adresse", max: 160 },
  postalCode: { label: "Code postal", max: 10 },
  city: { label: "Ville", max: 80 },
  country: { label: "Pays (code ISO, ex. FR)", max: 2 },
} as const;

export type CorrectableField = keyof typeof CORRECTABLE_FIELDS;
export const isCorrectable = (k: string): k is CorrectableField => k in CORRECTABLE_FIELDS;

/** Nettoie et valide les modifications proposées ; renvoie uniquement des champs autorisés. */
export function sanitizeChanges(raw: Record<string, unknown>): Partial<Record<CorrectableField, string>> {
  const out: Partial<Record<CorrectableField, string>> = {};
  for (const [k, v] of Object.entries(raw)) {
    if (!isCorrectable(k) || typeof v !== "string") continue;
    const val = v.trim();
    if (!val) continue;
    const spec = CORRECTABLE_FIELDS[k];
    if (val.length > spec.max) continue;
    if (k === "personalEmail" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) continue;
    if (k === "postalCode" && !/^[0-9A-Za-z -]{3,10}$/.test(val)) continue;
    if (k === "country" && !/^[A-Za-z]{2}$/.test(val)) continue;
    out[k] = k === "country" ? val.toUpperCase() : val;
  }
  return out;
}
