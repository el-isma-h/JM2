/**
 * Logique RH pure (sans base de données) : durée d'absence, périodes de référence, acquisition des congés,
 * imputation sur les soldes, heures supplémentaires, contrôle du télétravail.
 * Importée par le serveur et par les tests : pas d'alias `@/` ni de `server-only` ici.
 */
import { addDays, differenceInCalendarDays, endOfMonth, format, getISODay, getISOWeek, getISOWeekYear, parseISO, startOfDay } from "date-fns";
import { frenchHolidays } from "../../lib/dates";

export type LeaveUnit = "jours_ouvres" | "jours_ouvrables" | "jours_calendaires" | "heures";

export const unitLabels: Record<string, string> = {
  jours_ouvres: "Jours ouvrés (lundi au vendredi)",
  jours_ouvrables: "Jours ouvrables (lundi au samedi)",
  jours_calendaires: "Jours calendaires",
  heures: "Heures",
};

const iso = (d: Date) => format(d, "yyyy-MM-dd");
const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/** Jours fériés couvrant toutes les années d'une plage. */
export function holidaysBetween(startIso: string, endIso: string): string[] {
  const y1 = parseISO(startIso).getFullYear();
  const y2 = parseISO(endIso).getFullYear();
  const out: string[] = [];
  for (let y = y1; y <= y2; y++) out.push(...frenchHolidays(y));
  return out;
}

function countsForUnit(d: Date, unit: LeaveUnit, holidays: Set<string>): boolean {
  if (unit === "jours_calendaires") return true;
  const wd = getISODay(d); // 1 = lundi, 7 = dimanche
  if (holidays.has(iso(d))) return false;
  if (unit === "jours_ouvrables") return wd !== 7;
  return wd <= 5;
}

/**
 * Durée d'une absence dans l'unité du type : jours ouvrés hors fériés par défaut.
 * Une demi-journée de début ou de fin retire 0,5 jour si ce jour est décompté.
 * Pour l'unité « heures », chaque jour ouvré vaut la durée hebdomadaire / 5.
 */
export function leaveDuration(input: {
  start: string;
  end: string;
  startHalfDay?: boolean;
  endHalfDay?: boolean;
  unit?: string;
  weeklyHours?: number;
}): number {
  const unit = (input.unit ?? "jours_ouvres") as LeaveUnit;
  if (input.end < input.start) return 0;
  const holidays = new Set(holidaysBetween(input.start, input.end));
  const countUnit: LeaveUnit = unit === "heures" ? "jours_ouvres" : unit;
  let days = 0;
  const start = parseISO(input.start);
  const end = parseISO(input.end);
  for (let d = start; d <= end; d = addDays(d, 1)) if (countsForUnit(d, countUnit, holidays)) days++;
  const startCounts = countsForUnit(start, countUnit, holidays);
  const endCounts = countsForUnit(end, countUnit, holidays);
  if (input.start === input.end) {
    if (startCounts && (input.startHalfDay || input.endHalfDay)) days = 0.5;
  } else {
    if (input.startHalfDay && startCounts) days -= 0.5;
    if (input.endHalfDay && endCounts) days -= 0.5;
  }
  if (unit === "heures") return round2(days * ((input.weeklyHours ?? 35) / 5));
  return Math.max(0, days);
}

export type Period = { start: string; end: string };

/** Période de référence des congés payés : 1er juin au 31 mai. */
export function cpReferencePeriod(dateIso: string): Period {
  const d = parseISO(dateIso);
  const y = d.getMonth() >= 5 ? d.getFullYear() : d.getFullYear() - 1;
  return { start: `${y}-06-01`, end: `${y + 1}-05-31` };
}

/** CP : 1er juin au 31 mai ; autres types à solde : année civile. */
export function referencePeriodFor(code: string, dateIso: string): Period {
  if (code === "CP") return cpReferencePeriod(dateIso);
  const y = parseISO(dateIso).getFullYear();
  return { start: `${y}-01-01`, end: `${y}-12-31` };
}

export function previousPeriod(p: Period): Period {
  const s = parseISO(p.start);
  const e = parseISO(p.end);
  return { start: iso(new Date(s.getFullYear() - 1, s.getMonth(), s.getDate())), end: iso(new Date(e.getFullYear() - 1, e.getMonth(), e.getDate())) };
}

/**
 * Droits acquis sur une période de référence à une date donnée.
 * Chaque mois civil terminé de la période compte pour `monthlyRate` jours, au prorata des jours de présence
 * (embauche ou sortie en cours de mois). Une fois la période close, le total est arrondi au jour supérieur
 * (art. L3141-7 du Code du travail) et plafonné à 12 mois d'acquisition.
 */
export function acquiredLeave(input: {
  monthlyRate: number;
  period: Period;
  asOf: string;
  hireDate?: string | null;
  leaveDate?: string | null;
}): number {
  const { monthlyRate, period, asOf } = input;
  if (!monthlyRate) return 0;
  let months = 0;
  let cursor = parseISO(period.start);
  const periodEnd = parseISO(period.end);
  const asOfD = parseISO(asOf);
  while (cursor <= periodEnd) {
    const mStart = cursor;
    const mEnd = startOfDay(endOfMonth(cursor));
    if (mEnd >= asOfD) break; // mois non terminé
    let from = mStart;
    let to = mEnd;
    if (input.hireDate) {
      const h = parseISO(input.hireDate);
      if (h > from) from = h;
    }
    if (input.leaveDate) {
      const l = parseISO(input.leaveDate);
      if (l < to) to = l;
    }
    if (to >= from) {
      const present = differenceInCalendarDays(to, from) + 1;
      const total = mEnd.getDate();
      months += Math.min(1, present / total);
    }
    cursor = addDays(mEnd, 1);
  }
  const cap = Math.ceil(monthlyRate * 12);
  const raw = monthlyRate * months;
  const closed = asOfD > periodEnd;
  const value = closed ? Math.ceil(round2(raw)) : round2(raw);
  return Math.min(cap, value);
}

export type BalanceBucket = { periodStart: string; acquired: number; adjustment: number };
export type ConsumingRequest = { id: string; start: string; duration: number; status: "approved" | "pending" };

/**
 * Impute les demandes sur les soldes suivis : une demande posée pendant la période P consomme d'abord
 * le reliquat de la période P-1 (acquis l'an passé), puis les droits en cours d'acquisition de P.
 * Retourne, par période, les jours pris (approuvés) et en attente.
 */
export function allocateRequests(
  code: string,
  buckets: BalanceBucket[],
  requests: ConsumingRequest[],
): Record<string, { taken: number; pending: number }> {
  const out: Record<string, { taken: number; pending: number }> = {};
  const remaining: Record<string, number> = {};
  for (const b of buckets) {
    out[b.periodStart] = { taken: 0, pending: 0 };
    remaining[b.periodStart] = b.acquired + b.adjustment;
  }
  const sorted = [...requests].sort((a, b) => (a.status === b.status ? a.start.localeCompare(b.start) : a.status === "approved" ? -1 : 1));
  for (const r of sorted) {
    const cur = referencePeriodFor(code, r.start);
    const candidates = [previousPeriod(cur).start, cur.start].filter((k) => k in out);
    if (!candidates.length) continue;
    let left = r.duration;
    for (let i = 0; i < candidates.length && left > 0; i++) {
      const k = candidates[i];
      const isLast = i === candidates.length - 1;
      const use = isLast ? left : Math.max(0, Math.min(left, remaining[k]));
      if (use <= 0) continue;
      remaining[k] -= use;
      left -= use;
      if (r.status === "approved") out[k].taken = round2(out[k].taken + use);
      else out[k].pending = round2(out[k].pending + use);
    }
  }
  return out;
}

/** Solde disponible = acquis + ajustement - pris - en attente. */
export function remainingOf(b: { acquired: number; adjustment: number; taken: number; pending: number }): number {
  return round2(b.acquired + b.adjustment - b.taken - b.pending);
}

// ---------- Temps de travail ----------

export type TimesheetEntry = { date: string; hours: number; note?: string };

export type OvertimeResult = {
  totalHours: number;
  overtimeHours: number;
  at25: number;
  at50: number;
  weeks: { key: string; label: string; hours: number; threshold: number; overtime: number }[];
};

/**
 * Heures supplémentaires d'un mois : décompte par semaine civile (lundi au dimanche).
 * Seuil = durée hebdomadaire contractuelle ; pour une semaine à cheval sur deux mois, le seuil est proratisé
 * selon le nombre de jours du lundi au vendredi tombant dans le mois. Les 8 premières heures supplémentaires
 * d'une semaine sont majorées à 25 %, les suivantes à 50 % (taux légaux à défaut d'accord).
 */
export function computeOvertime(entries: TimesheetEntry[], weeklyHours: number, year: number, month: number): OvertimeResult {
  const weeks = new Map<string, { hours: number; weekdaysInMonth: number; first: string }>();
  const first = new Date(year, month - 1, 1);
  const last = endOfMonth(first);
  for (let d = first; d <= last; d = addDays(d, 1)) {
    const key = `${getISOWeekYear(d)}-S${String(getISOWeek(d)).padStart(2, "0")}`;
    const w = weeks.get(key) ?? { hours: 0, weekdaysInMonth: 0, first: iso(d) };
    if (getISODay(d) <= 5) w.weekdaysInMonth++;
    weeks.set(key, w);
  }
  let total = 0;
  for (const e of entries) {
    const d = parseISO(e.date);
    if (d.getFullYear() !== year || d.getMonth() !== month - 1) continue;
    const h = Number(e.hours) || 0;
    if (h <= 0) continue;
    total += h;
    const key = `${getISOWeekYear(d)}-S${String(getISOWeek(d)).padStart(2, "0")}`;
    const w = weeks.get(key);
    if (w) w.hours += h;
  }
  let ot = 0;
  let at25 = 0;
  let at50 = 0;
  const out: OvertimeResult["weeks"] = [];
  for (const [key, w] of weeks) {
    const threshold = round2((weeklyHours * w.weekdaysInMonth) / 5);
    const over = round2(Math.max(0, w.hours - threshold));
    const a25 = Math.min(8, over);
    at25 += a25;
    at50 += over - a25;
    ot += over;
    out.push({ key, label: `Semaine du ${w.first}`, hours: round2(w.hours), threshold, overtime: over });
  }
  return { totalHours: round2(total), overtimeHours: round2(ot), at25: round2(at25), at50: round2(at50), weeks: out };
}

// ---------- Télétravail ----------

export function isoWeekKey(dateIso: string): string {
  const d = parseISO(dateIso);
  return `${getISOWeekYear(d)}-S${String(getISOWeek(d)).padStart(2, "0")}`;
}

/** Nombre de jours de télétravail déjà posés dans la semaine de `dateIso` (hors ce jour). */
export function remoteDaysInWeek(existing: string[], dateIso: string): number {
  const key = isoWeekKey(dateIso);
  return existing.filter((d) => d !== dateIso && isoWeekKey(d) === key).length;
}

// ---------- Divers ----------

export function daysUntil(dueIso: string, todayIso: string): number {
  return differenceInCalendarDays(parseISO(dueIso), parseISO(todayIso));
}

export function yearsBetween(fromIso: string, toIso: string): number {
  return (parseISO(toIso).getTime() - parseISO(fromIso).getTime()) / (365.25 * 86400_000);
}

export function addMonthsIso(year: number, month: number, delta: number): { year: number; month: number } {
  const idx = year * 12 + (month - 1) + delta;
  return { year: Math.floor(idx / 12), month: (idx % 12) + 1 };
}

export function addDaysIso(dateIso: string, n: number): string {
  return iso(addDays(parseISO(dateIso), n));
}
