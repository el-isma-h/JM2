import "server-only";
import { and, asc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { acquiredLeave, allocateRequests, previousPeriod, referencePeriodFor, remainingOf } from "./calc";
import { todayIso, type DbLike } from "./common";

export async function getLeaveTypes(companyId: string, tx: DbLike = db) {
  return tx.select().from(schema.leaveTypes).where(eq(schema.leaveTypes.companyId, companyId)).orderBy(asc(schema.leaveTypes.sortOrder), asc(schema.leaveTypes.label));
}

/** Types d'absence affichés dans les demandes (le télétravail a son propre module). */
export const isLeaveSelectable = (t: { code: string }) => t.code !== "TT";

export type BalanceView = {
  leaveTypeId: string;
  code: string;
  label: string;
  periods: { periodStart: string; periodEnd: string; acquired: number; adjustment: number; taken: number; pending: number; remaining: number }[];
  available: number;
};

/**
 * Recalcule les soldes d'un salarié (période précédente et période en cours) pour chaque type à acquisition :
 * acquis selon les mois terminés, pris et en attente selon les demandes. Idempotent ; l'ajustement manuel est conservé.
 */
export async function recomputeBalances(tx: DbLike, companyId: string, employeeId: string, asOf = todayIso()): Promise<BalanceView[]> {
  const [emp] = await tx
    .select({ hireDate: schema.employees.hireDate, leaveDate: schema.employees.leaveDate })
    .from(schema.employees)
    .where(and(eq(schema.employees.id, employeeId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!emp) return [];
  const types = (await getLeaveTypes(companyId, tx)).filter((t) => t.monthlyAccrual !== null && Number(t.monthlyAccrual) > 0);
  if (!types.length) return [];
  const existing = await tx
    .select()
    .from(schema.leaveBalances)
    .where(and(eq(schema.leaveBalances.employeeId, employeeId), inArray(schema.leaveBalances.leaveTypeId, types.map((t) => t.id))));
  const requests = await tx
    .select()
    .from(schema.leaveRequests)
    .where(and(eq(schema.leaveRequests.employeeId, employeeId), inArray(schema.leaveRequests.status, ["approved", "pending"])));

  const out: BalanceView[] = [];
  for (const t of types) {
    const cur = referencePeriodFor(t.code, asOf);
    const prev = previousPeriod(cur);
    const rate = Number(t.monthlyAccrual);
    const buckets = [prev, cur].map((p) => {
      const row = existing.find((b) => b.leaveTypeId === t.id && b.periodStart === p.start);
      return {
        period: p,
        periodStart: p.start,
        acquired: acquiredLeave({ monthlyRate: rate, period: p, asOf, hireDate: emp.hireDate, leaveDate: emp.leaveDate }),
        adjustment: Number(row?.adjustment ?? 0),
      };
    });
    const alloc = allocateRequests(
      t.code,
      buckets,
      requests
        .filter((r) => r.leaveTypeId === t.id)
        .map((r) => ({ id: r.id, start: r.startDate, duration: Number(r.duration), status: r.status as "approved" | "pending" })),
    );
    const periods: BalanceView["periods"] = [];
    for (const b of buckets) {
      const a = alloc[b.periodStart] ?? { taken: 0, pending: 0 };
      const values = {
        acquired: b.acquired.toFixed(2),
        taken: a.taken.toFixed(2),
        pending: a.pending.toFixed(2),
      };
      await tx
        .insert(schema.leaveBalances)
        .values({ employeeId, leaveTypeId: t.id, periodStart: b.period.start, periodEnd: b.period.end, adjustment: b.adjustment.toFixed(2), ...values })
        .onConflictDoUpdate({ target: [schema.leaveBalances.employeeId, schema.leaveBalances.leaveTypeId, schema.leaveBalances.periodStart], set: values });
      const v = { acquired: b.acquired, adjustment: b.adjustment, taken: a.taken, pending: a.pending };
      periods.push({ periodStart: b.period.start, periodEnd: b.period.end, ...v, remaining: remainingOf(v) });
    }
    out.push({
      leaveTypeId: t.id,
      code: t.code,
      label: t.label,
      periods,
      available: Math.round(periods.reduce((s, p) => s + p.remaining, 0) * 100) / 100,
    });
  }
  return out;
}

/** Solde disponible pour un type (null si le type n'a pas de solde suivi). */
export async function availableFor(tx: DbLike, companyId: string, employeeId: string, leaveTypeId: string): Promise<number | null> {
  const views = await recomputeBalances(tx, companyId, employeeId);
  const v = views.find((x) => x.leaveTypeId === leaveTypeId);
  return v ? v.available : null;
}
