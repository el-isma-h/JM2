import "server-only";
import { and, eq, gte, inArray, lte } from "drizzle-orm";
import { db, schema } from "@/db";
import { addMonthsIso, leaveDuration, yearsBetween } from "./calc";
import { monthParam, todayIso } from "./common";
import { daysInMonth, fmtDate, monthLabel, workingDaysBetween } from "@/lib/dates";
import { holidaysBetween } from "./calc";
import { contractTypeLabels, categoryLabels } from "@/components/hr/labels";

/** Types exclus du taux d'absentéisme (absences planifiées ou légales non assimilées à de l'absentéisme). */
const PLANNED_CODES = new Set(["CP", "RTT", "TT", "EVF", "MAT"]);

export type SocialReport = Awaited<ReturnType<typeof buildSocialReport>>;

export async function buildSocialReport(companyId: string, opts: { withPayroll: boolean }) {
  const today = todayIso();
  const employees = await db.select().from(schema.employees).where(eq(schema.employees.companyId, companyId));
  const establishments = await db.select({ id: schema.establishments.id, name: schema.establishments.name }).from(schema.establishments).where(eq(schema.establishments.companyId, companyId));
  const estName = new Map(establishments.map((e) => [e.id, e.name]));
  const active = employees.filter((e) => e.status === "active");
  const ids = employees.map((e) => e.id);
  const contracts = ids.length ? await db.select().from(schema.contracts).where(inArray(schema.contracts.employeeId, ids)) : [];
  const currentContract = new Map<string, (typeof contracts)[number]>();
  for (const c of contracts.sort((a, b) => a.startDate.localeCompare(b.startDate))) {
    if (c.startDate <= today && (!c.endDate || c.endDate >= today)) currentContract.set(c.employeeId, c);
  }

  const group = <T,>(items: T[], key: (t: T) => string) => {
    const m = new Map<string, number>();
    for (const it of items) m.set(key(it), (m.get(key(it)) ?? 0) + 1);
    return [...m.entries()].map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
  };

  const byEstablishment = group(active, (e) => (e.establishmentId ? estName.get(e.establishmentId) ?? "Établissement supprimé" : "Non rattaché"));
  const byContract = group(active, (e) => {
    const c = currentContract.get(e.id);
    return c ? contractTypeLabels[c.type] ?? c.type : "Contrat non renseigné";
  });
  const byCategory = group(active, (e) => {
    const c = currentContract.get(e.id);
    return c ? categoryLabels[c.category] ?? c.category : "Non renseignée";
  });
  const gender = {
    F: active.filter((e) => e.gender === "F").length,
    M: active.filter((e) => e.gender === "M").length,
    other: active.filter((e) => e.gender !== "F" && e.gender !== "M").length,
  };
  const withHire = active.filter((e) => e.hireDate);
  const avgSeniority = withHire.length ? withHire.reduce((s, e) => s + yearsBetween(e.hireDate!, today), 0) / withHire.length : null;

  // 12 derniers mois (mois courant inclus)
  const now = new Date();
  const months = Array.from({ length: 12 }, (_, i) => addMonthsIso(now.getFullYear(), now.getMonth() + 1, i - 11));
  const movements = months.map(({ year, month }) => {
    const p = monthParam(year, month);
    return {
      key: p,
      label: fmtDate(new Date(year, month - 1, 1), "MMM"),
      longLabel: monthLabel(year, month),
      entries: employees.filter((e) => e.hireDate?.startsWith(p)).length,
      exits: employees.filter((e) => e.leaveDate?.startsWith(p)).length,
    };
  });

  // Absentéisme sur 12 mois glissants : jours ouvrés d'absence non planifiée / jours ouvrés théoriques.
  const windowStart = `${monthParam(months[0].year, months[0].month)}-01`;
  const windowEnd = today;
  const types = await db.select().from(schema.leaveTypes).where(eq(schema.leaveTypes.companyId, companyId));
  const unplannedTypeIds = types.filter((t) => !PLANNED_CODES.has(t.code)).map((t) => t.id);
  const absences = ids.length && unplannedTypeIds.length
    ? await db
        .select()
        .from(schema.leaveRequests)
        .where(and(inArray(schema.leaveRequests.employeeId, ids), inArray(schema.leaveRequests.leaveTypeId, unplannedTypeIds), eq(schema.leaveRequests.status, "approved"), lte(schema.leaveRequests.startDate, windowEnd), gte(schema.leaveRequests.endDate, windowStart)))
    : [];
  let absenceDays = 0;
  for (const a of absences) {
    const s = a.startDate < windowStart ? windowStart : a.startDate;
    const e = a.endDate > windowEnd ? windowEnd : a.endDate;
    absenceDays += leaveDuration({ start: s, end: e, unit: "jours_ouvres" });
  }
  const holidays = holidaysBetween(windowStart, windowEnd);
  let theoretical = 0;
  for (const e of employees) {
    const s = [windowStart, e.hireDate ?? windowStart].sort().at(-1)!;
    const end = [windowEnd, e.leaveDate ?? windowEnd].sort()[0];
    if (end >= s && e.status !== "draft") theoretical += workingDaysBetween(s, end, holidays);
  }
  const absenteeism = theoretical ? (absenceDays / theoretical) * 100 : null;
  const absenceByType = types
    .filter((t) => unplannedTypeIds.includes(t.id))
    .map((t) => ({
      label: t.label,
      value: Math.round(absences.filter((a) => a.leaveTypeId === t.id).reduce((s, a) => s + leaveDuration({ start: a.startDate < windowStart ? windowStart : a.startDate, end: a.endDate > windowEnd ? windowEnd : a.endDate }), 0) * 10) / 10,
    }))
    .filter((x) => x.value > 0);

  // Masse salariale (uniquement avec salaries.read) : bulletins si présents, sinon rémunérations contractuelles.
  let payroll: { source: "payslips" | "compensations"; months: { key: string; label: string; longLabel: string; grossCents: number; employerCostCents: number | null }[] } | null = null;
  if (opts.withPayroll && ids.length) {
    const periods = await db.select().from(schema.payrollPeriods).where(eq(schema.payrollPeriods.companyId, companyId));
    const periodIds = periods.map((p) => p.id);
    const slips = periodIds.length ? await db.select({ periodId: schema.payslips.periodId, gross: schema.payslips.grossCents, cost: schema.payslips.employerCostCents }).from(schema.payslips).where(inArray(schema.payslips.periodId, periodIds)) : [];
    if (slips.length) {
      const byPeriod = new Map(periods.map((p) => [p.id, monthParam(p.year, p.month)]));
      payroll = {
        source: "payslips",
        months: movements.map((m) => {
          const s = slips.filter((x) => byPeriod.get(x.periodId) === m.key);
          return { key: m.key, label: m.label, longLabel: m.longLabel, grossCents: s.reduce((a, x) => a + x.gross, 0), employerCostCents: s.reduce((a, x) => a + x.cost, 0) };
        }),
      };
    } else {
      const comps = await db.select().from(schema.compensations).where(inArray(schema.compensations.employeeId, ids));
      const empById = new Map(employees.map((e) => [e.id, e]));
      payroll = {
        source: "compensations",
        months: months.map(({ year, month }, i) => {
          const first = `${monthParam(year, month)}-01`;
          const last = `${monthParam(year, month)}-${String(daysInMonth(year, month)).padStart(2, "0")}`;
          let gross = 0;
          for (const [eid, list] of groupBy(comps, (c) => c.employeeId)) {
            const e = empById.get(eid);
            if (!e || e.status === "draft") continue;
            if (e.hireDate && e.hireDate > last) continue;
            if (e.leaveDate && e.leaveDate < first) continue;
            const c = list.filter((x) => x.effectiveDate <= last && (!x.endDate || x.endDate >= first)).sort((a, b) => b.effectiveDate.localeCompare(a.effectiveDate))[0];
            if (!c) continue;
            gross += c.basis === "annual" ? Math.round(c.grossAmountCents / 12) : c.basis === "hourly" ? Math.round(c.grossAmountCents * 151.67) : c.grossAmountCents;
          }
          return { key: movements[i].key, label: movements[i].label, longLabel: movements[i].longLabel, grossCents: gross, employerCostCents: null };
        }),
      };
    }
  }

  return {
    headcount: active.length,
    drafts: employees.filter((e) => e.status === "draft").length,
    left: employees.filter((e) => e.status === "left").length,
    byEstablishment,
    byContract,
    byCategory,
    gender,
    avgSeniority,
    movements,
    absenteeism,
    absenceDays,
    theoreticalDays: theoretical,
    absenceByType,
    payroll,
    employees,
    currentContract,
    estName,
  };
}

function groupBy<T>(items: T[], key: (t: T) => string) {
  const m = new Map<string, T[]>();
  for (const it of items) {
    const k = key(it);
    const l = m.get(k) ?? [];
    l.push(it);
    m.set(k, l);
  }
  return m;
}
