import "server-only";
import { cookies } from "next/headers";
import { asc, eq } from "drizzle-orm";
import { cache } from "react";
import { db, schema } from "@/db";
import { AuthError, getCurrentUser } from "@/server/auth";
import { handleAuthError } from "@/server/guard";

export const SELF_COOKIE = "nextrh_moi_fiche";

/**
 * Contexte de l'espace salarié : le salarié est identifié par employees.user_id = utilisateur connecté.
 * S'il a plusieurs fiches (plusieurs employeurs gérés dans Next RH), la fiche choisie est mémorisée dans un cookie.
 * Toutes les requêtes de /moi filtrent par `employee.id` et `company.id` issus de ce contexte, jamais par un paramètre client.
 */
export const getSelfContext = cache(async () => {
  const user = await getCurrentUser();
  if (!user) return null;
  const records = await db
    .select({ e: schema.employees, c: schema.companies })
    .from(schema.employees)
    .innerJoin(schema.companies, eq(schema.companies.id, schema.employees.companyId))
    .where(eq(schema.employees.userId, user.id))
    .orderBy(asc(schema.companies.legalName));
  if (!records.length) return { user, records, employee: null, company: null };
  const jar = await cookies();
  const pick = jar.get(SELF_COOKIE)?.value;
  const current = records.find((r) => r.e.id === pick) ?? records.find((r) => r.e.status !== "left") ?? records[0];
  return { user, records, employee: current.e, company: current.c };
});

export async function requireSelf() {
  const ctx = await getSelfContext();
  if (!ctx) throw new AuthError("unauthenticated");
  if (!ctx.user.emailVerified) throw new AuthError("email_unverified");
  if (!ctx.employee || !ctx.company) throw new AuthError("forbidden");
  return { user: ctx.user, employee: ctx.employee, company: ctx.company, records: ctx.records };
}

/** Pour les pages de /moi : redirige proprement (connexion, vérification) au lieu de lever une erreur. */
export async function guardSelf(nextPath: string) {
  try {
    return await requireSelf();
  } catch (e) {
    handleAuthError(e, nextPath);
  }
}
