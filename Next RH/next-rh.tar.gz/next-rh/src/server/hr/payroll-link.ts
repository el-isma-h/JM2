import "server-only";
import { and, eq } from "drizzle-orm";
import { schema } from "@/db";
import { addMonthsIso } from "./calc";
import type { Tx } from "./common";
import { monthLabel } from "@/lib/dates";

/**
 * Pont entre les modules RH et la paie : écriture des variables de paie.
 * Contrat partagé avec l'équipe paie (ne pas modifier sans elle) :
 *  - absence  : kind "absence", label = libellé du type, quantity = jours, note = code du type, source "leave"
 *  - heures   : kind "heures_sup", quantity = heures, source "timesheet"
 *  - frais    : kind "indemnite", amountCents = total, source "expense", label « Remboursement de frais : <titre> »
 *  - status "validated", sourceId = id de l'objet d'origine ; idempotent via la contrainte unique
 *    (period_id, employee_id, source, source_id).
 * Si la période visée est validée ou au-delà, la variable va sur le premier mois ouvert suivant et une
 * anomalie d'information « Régularisation à prévoir le mois suivant » est créée sur la période verrouillée.
 */

export const LOCKED_STATUSES = new Set(["validated", "finalized", "exported", "distributed", "closed"]);

type Period = typeof schema.payrollPeriods.$inferSelect;

export async function getOrCreatePeriod(tx: Tx, companyId: string, year: number, month: number): Promise<Period> {
  await tx.insert(schema.payrollPeriods).values({ companyId, year, month, status: "open" }).onConflictDoNothing();
  const [p] = await tx
    .select()
    .from(schema.payrollPeriods)
    .where(and(eq(schema.payrollPeriods.companyId, companyId), eq(schema.payrollPeriods.year, year), eq(schema.payrollPeriods.month, month)))
    .limit(1);
  return p;
}

/** Première période non verrouillée à partir de (year, month). */
async function firstOpenPeriod(tx: Tx, companyId: string, year: number, month: number) {
  const requested = await getOrCreatePeriod(tx, companyId, year, month);
  if (!LOCKED_STATUSES.has(requested.status)) return { target: requested, locked: null as Period | null };
  let cursor = { year, month };
  for (let i = 0; i < 24; i++) {
    cursor = addMonthsIso(cursor.year, cursor.month, 1);
    const p = await getOrCreatePeriod(tx, companyId, cursor.year, cursor.month);
    if (!LOCKED_STATUSES.has(p.status)) return { target: p, locked: requested };
  }
  throw new Error("Aucune période de paie ouverte dans les 24 mois suivants.");
}

async function regularisationAnomaly(tx: Tx, locked: Period, target: Period, employeeId: string, what: string, details: Record<string, unknown>) {
  const [a] = await tx
    .insert(schema.payrollAnomalies)
    .values({
      periodId: locked.id,
      employeeId,
      code: "REGULARISATION_MOIS_SUIVANT",
      severity: "info",
      status: "open",
      title: "Régularisation à prévoir le mois suivant",
      explanation: `${what} concerne ${monthLabel(locked.year, locked.month)}, période déjà validée. L'élément est reporté sur ${monthLabel(target.year, target.month)}.`,
      details: { ...details, targetPeriodId: target.id },
    })
    .returning({ id: schema.payrollAnomalies.id });
  return a.id;
}

export type PushInput = {
  companyId: string;
  employeeId: string;
  year: number;
  month: number;
  kind: "absence" | "heures_sup" | "indemnite";
  label: string;
  quantity?: string | null;
  amountCents?: number | null;
  note?: string | null;
  source: "leave" | "timesheet" | "expense";
  sourceId: string;
  userId: string;
  /** Phrase d'explication pour l'anomalie éventuelle (« L'absence du 3 au 7 mars »). */
  what: string;
};

export async function pushPayrollVariable(tx: Tx, input: PushInput) {
  // Idempotence : si une variable existe déjà pour cette origine, on la met à jour (période ouverte) ou on la garde.
  const [existing] = await tx
    .select({ v: schema.payrollVariables, p: schema.payrollPeriods })
    .from(schema.payrollVariables)
    .innerJoin(schema.payrollPeriods, eq(schema.payrollPeriods.id, schema.payrollVariables.periodId))
    .where(
      and(
        eq(schema.payrollPeriods.companyId, input.companyId),
        eq(schema.payrollVariables.employeeId, input.employeeId),
        eq(schema.payrollVariables.source, input.source),
        eq(schema.payrollVariables.sourceId, input.sourceId),
      ),
    )
    .limit(1);
  const values = {
    kind: input.kind,
    label: input.label,
    quantity: input.quantity ?? null,
    amountCents: input.amountCents ?? null,
    note: input.note ?? null,
    status: "validated" as const,
    validatedBy: input.userId,
  };
  if (existing) {
    if (!LOCKED_STATUSES.has(existing.p.status)) {
      await tx.update(schema.payrollVariables).set(values).where(eq(schema.payrollVariables.id, existing.v.id));
    }
    return { variableId: existing.v.id, periodId: existing.p.id, shifted: false, anomalyId: null as string | null };
  }

  const { target, locked } = await firstOpenPeriod(tx, input.companyId, input.year, input.month);
  const [row] = await tx
    .insert(schema.payrollVariables)
    .values({
      periodId: target.id,
      employeeId: input.employeeId,
      source: input.source,
      sourceId: input.sourceId,
      createdBy: input.userId,
      ...values,
    })
    .onConflictDoUpdate({
      target: [schema.payrollVariables.periodId, schema.payrollVariables.employeeId, schema.payrollVariables.source, schema.payrollVariables.sourceId],
      set: values,
    })
    .returning({ id: schema.payrollVariables.id });
  let anomalyId: string | null = null;
  if (locked) {
    anomalyId = await regularisationAnomaly(tx, locked, target, input.employeeId, input.what, {
      source: input.source,
      sourceId: input.sourceId,
      variableId: row.id,
    });
  }
  return { variableId: row.id, periodId: target.id, shifted: Boolean(locked), anomalyId };
}

/**
 * Retire une variable après annulation de l'élément d'origine.
 * Période non validée : suppression. Période validée : variable de régularisation (quantité ou montant opposés)
 * sur le premier mois ouvert suivant + anomalie d'information.
 */
export async function withdrawPayrollVariable(tx: Tx, input: { companyId: string; variableId: string; userId: string; what: string }) {
  const [found] = await tx
    .select({ v: schema.payrollVariables, p: schema.payrollPeriods })
    .from(schema.payrollVariables)
    .innerJoin(schema.payrollPeriods, eq(schema.payrollPeriods.id, schema.payrollVariables.periodId))
    .where(and(eq(schema.payrollVariables.id, input.variableId), eq(schema.payrollPeriods.companyId, input.companyId)))
    .limit(1);
  if (!found) return { removed: false, regularisationId: null as string | null };
  const { v, p } = found;
  if (!LOCKED_STATUSES.has(p.status)) {
    await tx.delete(schema.payrollVariables).where(eq(schema.payrollVariables.id, v.id));
    return { removed: true, regularisationId: null };
  }
  const next = addMonthsIso(p.year, p.month, 1);
  const { target } = await firstOpenPeriod(tx, input.companyId, next.year, next.month);
  const negQty = v.quantity !== null ? String(-Number(v.quantity)) : null;
  const negAmt = v.amountCents !== null ? -v.amountCents : null;
  const regValues = {
    kind: "regularisation" as const,
    label: `Régularisation : annulation ${v.label}`,
    quantity: negQty,
    amountCents: negAmt,
    note: v.note,
    status: "validated" as const,
    validatedBy: input.userId,
  };
  const [row] = await tx
    .insert(schema.payrollVariables)
    .values({
      periodId: target.id,
      employeeId: v.employeeId,
      source: `${v.source}_annulation`,
      sourceId: v.sourceId,
      createdBy: input.userId,
      ...regValues,
    })
    .onConflictDoUpdate({
      target: [schema.payrollVariables.periodId, schema.payrollVariables.employeeId, schema.payrollVariables.source, schema.payrollVariables.sourceId],
      set: regValues,
    })
    .returning({ id: schema.payrollVariables.id });
  await regularisationAnomaly(tx, p, target, v.employeeId, input.what, { cancelledVariableId: v.id, regularisationVariableId: row.id, originalKind: v.kind });
  return { removed: false, regularisationId: row.id };
}
