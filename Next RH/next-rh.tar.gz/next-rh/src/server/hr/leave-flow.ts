import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { fmtDate } from "@/lib/dates";
import { audit } from "@/server/audit";
import { activeContract, HrError } from "./common";
import { leaveDuration } from "./calc";
import { saveProof } from "./uploads";
import { pushPayrollVariable, withdrawPayrollVariable } from "./payroll-link";
import { availableFor, recomputeBalances } from "./leave";

type Actor = { userId: string; companyId: string; tenantId: string };

/** Charge une demande d'absence en vérifiant qu'elle appartient à l'entreprise. */
export async function loadLeaveRequest(companyId: string, requestId: string) {
  const [row] = await db
    .select({ r: schema.leaveRequests, t: schema.leaveTypes, e: schema.employees })
    .from(schema.leaveRequests)
    .innerJoin(schema.employees, eq(schema.employees.id, schema.leaveRequests.employeeId))
    .innerJoin(schema.leaveTypes, eq(schema.leaveTypes.id, schema.leaveRequests.leaveTypeId))
    .where(and(eq(schema.leaveRequests.id, requestId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!row) throw new HrError("Demande introuvable.");
  return row;
}

const describe = (r: { startDate: string; endDate: string }, label: string) =>
  r.startDate === r.endDate ? `${label} du ${fmtDate(r.startDate)}` : `${label} du ${fmtDate(r.startDate)} au ${fmtDate(r.endDate)}`;

/**
 * Approuve une absence : statut, variable de paie si le type a un effet paie (mois de début), soldes, audit.
 */
export async function approveLeave(actor: Actor, requestId: string, note: string | null, opts: { allowMissingProof?: boolean } = {}) {
  const { r, t } = await loadLeaveRequest(actor.companyId, requestId);
  if (r.status !== "pending") throw new HrError("Seules les demandes en attente peuvent être validées.");
  if (t.requiresProof && !r.proofDocumentId && !opts.allowMissingProof) {
    throw new HrError(`Justificatif requis pour « ${t.label} » : ajoutez-le avant de valider.`);
  }
  const result = await db.transaction(async (tx) => {
    let payroll: Awaited<ReturnType<typeof pushPayrollVariable>> | null = null;
    if (t.affectsPayroll) {
      const [y, m] = r.startDate.split("-").map(Number);
      payroll = await pushPayrollVariable(tx, {
        companyId: actor.companyId,
        employeeId: r.employeeId,
        year: y,
        month: m,
        kind: "absence",
        label: t.label,
        quantity: Number(r.duration).toFixed(2),
        note: t.code,
        source: "leave",
        sourceId: r.id,
        userId: actor.userId,
        what: describe(r, `L'absence « ${t.label} »`),
      });
    }
    await tx
      .update(schema.leaveRequests)
      .set({ status: "approved", approvedBy: actor.userId, decidedAt: new Date(), decisionNote: note, payrollVariableId: payroll?.variableId ?? null })
      .where(eq(schema.leaveRequests.id, r.id));
    await recomputeBalances(tx, actor.companyId, r.employeeId);
    return payroll;
  });
  await audit({
    action: "leave.approve",
    userId: actor.userId,
    companyId: actor.companyId,
    tenantId: actor.tenantId,
    entityType: "leave_request",
    entityId: r.id,
    before: { status: r.status },
    after: { status: "approved", payrollVariableId: result?.variableId ?? null, shiftedToNextMonth: result?.shifted ?? false },
  });
  return result;
}

export async function rejectLeave(actor: Actor, requestId: string, note: string | null) {
  const { r } = await loadLeaveRequest(actor.companyId, requestId);
  if (r.status !== "pending") throw new HrError("Seules les demandes en attente peuvent être refusées.");
  await db.transaction(async (tx) => {
    await tx.update(schema.leaveRequests).set({ status: "rejected", approvedBy: actor.userId, decidedAt: new Date(), decisionNote: note }).where(eq(schema.leaveRequests.id, r.id));
    await recomputeBalances(tx, actor.companyId, r.employeeId);
  });
  await audit({ action: "leave.reject", userId: actor.userId, companyId: actor.companyId, tenantId: actor.tenantId, entityType: "leave_request", entityId: r.id, before: { status: r.status }, after: { status: "rejected", note } });
}

/**
 * Annule une absence. Après approbation : la variable de paie est supprimée si la période n'est pas validée,
 * sinon une régularisation est créée sur le mois ouvert suivant.
 */
export async function cancelLeave(actor: Actor, requestId: string, note: string | null, opts: { ownerEmployeeId?: string } = {}) {
  const { r, t } = await loadLeaveRequest(actor.companyId, requestId);
  if (opts.ownerEmployeeId && r.employeeId !== opts.ownerEmployeeId) throw new HrError("Demande introuvable.");
  if (r.status === "cancelled" || r.status === "rejected") throw new HrError("Cette demande est déjà close.");
  const outcome = await db.transaction(async (tx) => {
    let withdraw: Awaited<ReturnType<typeof withdrawPayrollVariable>> | null = null;
    if (r.status === "approved" && r.payrollVariableId) {
      withdraw = await withdrawPayrollVariable(tx, {
        companyId: actor.companyId,
        variableId: r.payrollVariableId,
        userId: actor.userId,
        what: describe(r, `L'annulation de l'absence « ${t.label} »`),
      });
    }
    await tx
      .update(schema.leaveRequests)
      .set({ status: "cancelled", decidedAt: new Date(), decisionNote: note ?? r.decisionNote, payrollVariableId: withdraw?.removed ? null : r.payrollVariableId })
      .where(eq(schema.leaveRequests.id, r.id));
    await recomputeBalances(tx, actor.companyId, r.employeeId);
    return withdraw;
  });
  await audit({
    action: "leave.cancel",
    userId: actor.userId,
    companyId: actor.companyId,
    tenantId: actor.tenantId,
    entityType: "leave_request",
    entityId: r.id,
    before: { status: r.status, payrollVariableId: r.payrollVariableId },
    after: { status: "cancelled", variableRemoved: outcome?.removed ?? false, regularisationVariableId: outcome?.regularisationId ?? null },
  });
  return outcome;
}

/**
 * Crée une demande d'absence avec calcul de durée (jours ouvrés hors fériés selon l'unité du type),
 * contrôle du solde, contrôle des chevauchements et justificatif éventuel.
 */
export async function createLeaveRequest(
  actor: Actor & { isDemo: boolean },
  input: {
    employeeId: string;
    leaveTypeId: string;
    startDate: string;
    endDate: string;
    startHalfDay: boolean;
    endHalfDay: boolean;
    reason: string | null;
    proof: File | null;
    /** Saisie RH : autorise un solde insuffisant (le solde devient négatif, visible). */
    allowNegative?: boolean;
  },
) {
  const [t] = await db
    .select()
    .from(schema.leaveTypes)
    .where(and(eq(schema.leaveTypes.id, input.leaveTypeId), eq(schema.leaveTypes.companyId, actor.companyId)))
    .limit(1);
  if (!t) throw new HrError("Type d'absence introuvable.");
  if (input.endDate < input.startDate) throw new HrError("La date de fin précède la date de début.");
  const contract = await activeContract(input.employeeId, input.startDate);
  const duration = leaveDuration({
    start: input.startDate,
    end: input.endDate,
    startHalfDay: input.startHalfDay,
    endHalfDay: input.endHalfDay,
    unit: t.unit,
    weeklyHours: contract ? Number(contract.weeklyHours) : 35,
  });
  if (duration <= 0) throw new HrError("La période choisie ne contient aucun jour décompté (week-end ou jour férié).");

  const overlapping = await db
    .select({ id: schema.leaveRequests.id, s: schema.leaveRequests.startDate, e: schema.leaveRequests.endDate, st: schema.leaveRequests.status })
    .from(schema.leaveRequests)
    .where(eq(schema.leaveRequests.employeeId, input.employeeId));
  const clash = overlapping.find((o) => (o.st === "pending" || o.st === "approved") && o.s <= input.endDate && o.e >= input.startDate);
  if (clash) throw new HrError(`Une autre absence couvre déjà cette période (du ${fmtDate(clash.s)} au ${fmtDate(clash.e)}).`);

  const available = await availableFor(db, actor.companyId, input.employeeId, t.id);
  if (available !== null && duration > available && !input.allowNegative) {
    throw new HrError(
      `Solde insuffisant : ${duration.toLocaleString("fr-FR")} jour(s) demandé(s), ${available.toLocaleString("fr-FR")} disponible(s) en « ${t.label} ».`,
    );
  }

  const [row] = await db
    .insert(schema.leaveRequests)
    .values({
      employeeId: input.employeeId,
      leaveTypeId: t.id,
      startDate: input.startDate,
      endDate: input.endDate,
      startHalfDay: input.startHalfDay,
      endHalfDay: input.endHalfDay,
      duration: duration.toFixed(2),
      status: "pending",
      reason: input.reason,
    })
    .returning();
  if (input.proof) {
    const doc = await saveProof(input.proof, {
      companyId: actor.companyId,
      employeeId: input.employeeId,
      title: `Justificatif : ${t.label} du ${fmtDate(input.startDate)}`,
      sourceType: "leave_request",
      sourceId: row.id,
      userId: actor.userId,
      isDemo: actor.isDemo,
    });
    await db.update(schema.leaveRequests).set({ proofDocumentId: doc.id }).where(eq(schema.leaveRequests.id, row.id));
    row.proofDocumentId = doc.id;
  }
  await db.transaction((tx) => recomputeBalances(tx, actor.companyId, input.employeeId));
  await audit({
    action: "leave.request",
    userId: actor.userId,
    companyId: actor.companyId,
    tenantId: actor.tenantId,
    entityType: "leave_request",
    entityId: row.id,
    after: { type: t.code, startDate: input.startDate, endDate: input.endDate, duration, available },
  });
  return { request: row, type: t, duration, available };
}

/** Joint un justificatif à une demande existante. */
export async function attachLeaveProof(actor: Actor & { isDemo: boolean }, requestId: string, file: File, opts: { ownerEmployeeId?: string } = {}) {
  const { r, t } = await loadLeaveRequest(actor.companyId, requestId);
  if (opts.ownerEmployeeId && r.employeeId !== opts.ownerEmployeeId) throw new HrError("Demande introuvable.");
  const doc = await saveProof(file, {
    companyId: actor.companyId,
    employeeId: r.employeeId,
    title: `Justificatif : ${t.label} du ${fmtDate(r.startDate)}`,
    sourceType: "leave_request",
    sourceId: r.id,
    userId: actor.userId,
    isDemo: actor.isDemo,
  });
  await db.update(schema.leaveRequests).set({ proofDocumentId: doc.id }).where(eq(schema.leaveRequests.id, r.id));
  await audit({ action: "leave.proof_attach", userId: actor.userId, companyId: actor.companyId, tenantId: actor.tenantId, entityType: "leave_request", entityId: r.id, after: { documentId: doc.id } });
  return doc;
}
