import "server-only";
import { and, eq, inArray, isNotNull, ne } from "drizzle-orm";
import { db, schema } from "@/db";
import { fmtDate } from "@/lib/dates";
import { todayIso } from "./common";

export const deadlineKindLabels: Record<string, string> = {
  fin_periode_essai: "Fin de période d'essai",
  fin_renouvellement_essai: "Fin du renouvellement d'essai",
  fin_contrat: "Fin de contrat à durée déterminée",
  expiration_habilitation: "Expiration d'habilitation",
  entretien: "Entretien planifié",
  visite_medicale: "Visite médicale",
  autre: "Autre échéance",
};

const AUTO_SOURCES = ["contract", "training", "interview"];

type Computed = { employeeId: string; kind: string; title: string; dueDate: string; sourceType: string; sourceId: string };

const contractLabel: Record<string, string> = {
  CDD: "CDD",
  APPRENTISSAGE: "contrat d'apprentissage",
  PROFESSIONNALISATION: "contrat de professionnalisation",
  STAGE: "stage",
  INTERIM: "mission d'intérim",
  MANDAT: "mandat",
  CDI: "contrat",
};

/**
 * Calcule les échéances depuis les contrats, formations et entretiens, puis synchronise la table `deadlines`
 * (idempotent : contrainte unique source_type + source_id + kind). Les échéances marquées « faites » sont conservées ;
 * les échéances automatiques dont la source a disparu sont retirées.
 */
export async function syncDeadlines(companyId: string) {
  const today = todayIso();
  const emps = await db
    .select({ id: schema.employees.id, f: schema.employees.firstName, l: schema.employees.lastName })
    .from(schema.employees)
    .where(and(eq(schema.employees.companyId, companyId), ne(schema.employees.status, "left")));
  if (!emps.length) return { upserted: 0, removed: 0 };
  const name = new Map(emps.map((e) => [e.id, `${e.f} ${e.l}`]));
  const ids = emps.map((e) => e.id);
  const computed: Computed[] = [];

  const contracts = await db.select().from(schema.contracts).where(inArray(schema.contracts.employeeId, ids));
  for (const c of contracts) {
    const who = name.get(c.employeeId)!;
    if (c.trialRenewedUntil) {
      computed.push({ employeeId: c.employeeId, kind: "fin_renouvellement_essai", title: `Fin du renouvellement de période d'essai : ${who}`, dueDate: c.trialRenewedUntil, sourceType: "contract", sourceId: c.id });
    } else if (c.trialEndDate) {
      computed.push({ employeeId: c.employeeId, kind: "fin_periode_essai", title: `Fin de période d'essai : ${who}`, dueDate: c.trialEndDate, sourceType: "contract", sourceId: c.id });
    }
    if (c.endDate && c.type !== "CDI") {
      computed.push({ employeeId: c.employeeId, kind: "fin_contrat", title: `Fin de ${contractLabel[c.type] ?? "contrat"} : ${who}`, dueDate: c.endDate, sourceType: "contract", sourceId: c.id });
    }
  }
  const trainings = await db
    .select()
    .from(schema.trainings)
    .where(and(inArray(schema.trainings.employeeId, ids), isNotNull(schema.trainings.expiresAt), ne(schema.trainings.status, "cancelled")));
  for (const t of trainings) {
    computed.push({ employeeId: t.employeeId, kind: "expiration_habilitation", title: `Expiration : ${t.title} (${name.get(t.employeeId)})`, dueDate: t.expiresAt!, sourceType: "training", sourceId: t.id });
  }
  const interviews = await db
    .select()
    .from(schema.interviews)
    .where(and(inArray(schema.interviews.employeeId, ids), eq(schema.interviews.status, "planned"), isNotNull(schema.interviews.scheduledAt)));
  for (const i of interviews) {
    const due = i.scheduledAt!.toISOString().slice(0, 10);
    computed.push({ employeeId: i.employeeId, kind: "entretien", title: `Entretien ${interviewKindLabels[i.kind] ?? ""} : ${name.get(i.employeeId)} (${fmtDate(due)})`.replace("  ", " "), dueDate: due, sourceType: "interview", sourceId: i.id });
  }

  let upserted = 0;
  for (const c of computed) {
    const status = c.dueDate < today ? "overdue" : "upcoming";
    await db
      .insert(schema.deadlines)
      .values({ companyId, employeeId: c.employeeId, kind: c.kind, title: c.title, dueDate: c.dueDate, status, sourceType: c.sourceType, sourceId: c.sourceId })
      .onConflictDoUpdate({
        target: [schema.deadlines.sourceType, schema.deadlines.sourceId, schema.deadlines.kind],
        set: { title: c.title, dueDate: c.dueDate, employeeId: c.employeeId },
      });
    upserted++;
  }
  // Statut à jour pour les échéances non faites (passées → en retard).
  const existing = await db.select().from(schema.deadlines).where(eq(schema.deadlines.companyId, companyId));
  const keys = new Set(computed.map((c) => `${c.sourceType}|${c.sourceId}|${c.kind}`));
  const stale = existing.filter((d) => d.sourceType && AUTO_SOURCES.includes(d.sourceType) && !keys.has(`${d.sourceType}|${d.sourceId}|${d.kind}`) && d.status !== "done");
  if (stale.length) await db.delete(schema.deadlines).where(inArray(schema.deadlines.id, stale.map((d) => d.id)));
  for (const d of existing) {
    if (d.status === "done") continue;
    const s = d.dueDate < today ? "overdue" : "upcoming";
    if (s !== d.status) await db.update(schema.deadlines).set({ status: s }).where(eq(schema.deadlines.id, d.id));
  }
  return { upserted, removed: stale.length };
}

export const interviewKindLabels: Record<string, string> = {
  annuel: "annuel",
  professionnel: "professionnel",
  fin_periode_essai: "de fin de période d'essai",
  retour_absence: "de retour d'absence",
  recadrage: "de recadrage",
  autre: "",
};
