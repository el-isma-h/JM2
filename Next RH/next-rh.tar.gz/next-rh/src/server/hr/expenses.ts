import "server-only";
import { and, eq, sum } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { fmtDate } from "@/lib/dates";
import { HrError } from "./common";
import { pushPayrollVariable } from "./payroll-link";
import { saveProof } from "./uploads";

type Actor = { userId: string; companyId: string; tenantId: string; isDemo: boolean };

export const EXPENSE_CATEGORIES: { value: string; label: string }[] = [
  { value: "transport", label: "Transport (train, taxi, péage)" },
  { value: "kilometrique", label: "Indemnités kilométriques" },
  { value: "repas", label: "Repas" },
  { value: "hebergement", label: "Hébergement" },
  { value: "fournitures", label: "Fournitures et petit matériel" },
  { value: "telephone", label: "Téléphone et internet" },
  { value: "autre", label: "Autre" },
];
export const categoryLabel = (v: string) => EXPENSE_CATEGORIES.find((c) => c.value === v)?.label ?? v;

export async function loadReport(companyId: string, reportId: string, ownerEmployeeId?: string) {
  const [row] = await db
    .select({ r: schema.expenseReports, e: schema.employees })
    .from(schema.expenseReports)
    .innerJoin(schema.employees, eq(schema.employees.id, schema.expenseReports.employeeId))
    .where(and(eq(schema.expenseReports.id, reportId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!row || (ownerEmployeeId && row.r.employeeId !== ownerEmployeeId)) throw new HrError("Note de frais introuvable.");
  return row;
}

const editable = (s: string) => s === "draft" || s === "rejected";

async function refreshTotal(reportId: string) {
  const [t] = await db.select({ total: sum(schema.expenseLines.amountCents) }).from(schema.expenseLines).where(eq(schema.expenseLines.reportId, reportId));
  const total = Number(t?.total ?? 0);
  await db.update(schema.expenseReports).set({ totalCents: total }).where(eq(schema.expenseReports.id, reportId));
  return total;
}

export async function createReport(actor: Actor, employeeId: string, title: string) {
  if (title.length < 2) throw new HrError("Donnez un titre à la note (ex. « Déplacement client Lyon »).");
  const [row] = await db.insert(schema.expenseReports).values({ employeeId, title: title.slice(0, 120), status: "draft" }).returning();
  await audit({ action: "expense.create", userId: actor.userId, companyId: actor.companyId, tenantId: actor.tenantId, entityType: "expense_report", entityId: row.id, after: { title } });
  return row;
}

export async function addLine(
  actor: Actor,
  reportId: string,
  line: { date: string; category: string; label: string; amountCents: number; vatCents: number; receipt: File | null },
  ownerEmployeeId?: string,
) {
  const { r } = await loadReport(actor.companyId, reportId, ownerEmployeeId);
  if (!editable(r.status)) throw new HrError("Note déjà soumise : elle ne peut plus être modifiée.");
  if (line.amountCents <= 0) throw new HrError("Le montant doit être positif.");
  if (line.vatCents > line.amountCents) throw new HrError("La TVA ne peut pas dépasser le montant TTC.");
  let receiptId: string | null = null;
  if (line.receipt) {
    const doc = await saveProof(line.receipt, {
      companyId: actor.companyId,
      employeeId: r.employeeId,
      title: `Justificatif de frais : ${line.label} (${fmtDate(line.date)})`,
      sourceType: "expense_report",
      sourceId: r.id,
      userId: actor.userId,
      isDemo: actor.isDemo,
    });
    receiptId = doc.id;
  }
  const [row] = await db
    .insert(schema.expenseLines)
    .values({ reportId: r.id, date: line.date, category: line.category, label: line.label.slice(0, 160), amountCents: line.amountCents, vatCents: line.vatCents, receiptDocumentId: receiptId })
    .returning();
  const total = await refreshTotal(r.id);
  await audit({ action: "expense.line_add", userId: actor.userId, companyId: actor.companyId, tenantId: actor.tenantId, entityType: "expense_report", entityId: r.id, after: { lineId: row.id, amountCents: line.amountCents, total } });
  return row;
}

export async function removeLine(actor: Actor, reportId: string, lineId: string, ownerEmployeeId?: string) {
  const { r } = await loadReport(actor.companyId, reportId, ownerEmployeeId);
  if (!editable(r.status)) throw new HrError("Note déjà soumise : elle ne peut plus être modifiée.");
  const [before] = await db.select().from(schema.expenseLines).where(and(eq(schema.expenseLines.id, lineId), eq(schema.expenseLines.reportId, r.id))).limit(1);
  if (!before) throw new HrError("Ligne introuvable.");
  await db.delete(schema.expenseLines).where(eq(schema.expenseLines.id, before.id));
  const total = await refreshTotal(r.id);
  await audit({ action: "expense.line_remove", userId: actor.userId, companyId: actor.companyId, tenantId: actor.tenantId, entityType: "expense_report", entityId: r.id, before, after: { total } });
}

export async function submitReport(actor: Actor, reportId: string, ownerEmployeeId?: string) {
  const { r } = await loadReport(actor.companyId, reportId, ownerEmployeeId);
  if (!editable(r.status)) throw new HrError("Note déjà soumise.");
  const lines = await db.select().from(schema.expenseLines).where(eq(schema.expenseLines.reportId, r.id));
  if (!lines.length) throw new HrError("Ajoutez au moins une dépense avant de soumettre.");
  const missing = lines.filter((l) => !l.receiptDocumentId && l.category !== "kilometrique").length;
  await db.update(schema.expenseReports).set({ status: "pending" }).where(eq(schema.expenseReports.id, r.id));
  await audit({ action: "expense.submit", userId: actor.userId, companyId: actor.companyId, tenantId: actor.tenantId, entityType: "expense_report", entityId: r.id, before: { status: r.status }, after: { status: "pending", missingReceipts: missing } });
  return { missing };
}

/** Validation : variable de paie « indemnité » du montant total, sur le mois de la décision. */
export async function approveReport(actor: Actor, reportId: string) {
  const { r, e } = await loadReport(actor.companyId, reportId);
  if (r.status !== "pending") throw new HrError("Seules les notes soumises peuvent être validées.");
  const total = await refreshTotal(r.id);
  if (total <= 0) throw new HrError("Note vide.");
  const now = new Date();
  const res = await db.transaction(async (tx) => {
    const p = await pushPayrollVariable(tx, {
      companyId: actor.companyId,
      employeeId: r.employeeId,
      year: now.getFullYear(),
      month: now.getMonth() + 1,
      kind: "indemnite",
      label: `Remboursement de frais : ${r.title}`,
      amountCents: total,
      source: "expense",
      sourceId: r.id,
      userId: actor.userId,
      what: `Le remboursement de frais « ${r.title} » de ${e.firstName} ${e.lastName}`,
    });
    await tx
      .update(schema.expenseReports)
      .set({ status: "approved", approvedBy: actor.userId, decidedAt: now, reimbursedInPeriodId: p.periodId })
      .where(eq(schema.expenseReports.id, r.id));
    return p;
  });
  await audit({
    action: "expense.approve",
    userId: actor.userId,
    companyId: actor.companyId,
    tenantId: actor.tenantId,
    entityType: "expense_report",
    entityId: r.id,
    before: { status: r.status },
    after: { status: "approved", totalCents: total, payrollVariableId: res.variableId, periodId: res.periodId, shifted: res.shifted },
  });
  return res;
}

export async function rejectReport(actor: Actor, reportId: string, note: string | null) {
  const { r } = await loadReport(actor.companyId, reportId);
  if (r.status !== "pending") throw new HrError("Seules les notes soumises peuvent être refusées.");
  await db.update(schema.expenseReports).set({ status: "rejected", approvedBy: actor.userId, decidedAt: new Date() }).where(eq(schema.expenseReports.id, r.id));
  await audit({ action: "expense.reject", userId: actor.userId, companyId: actor.companyId, tenantId: actor.tenantId, entityType: "expense_report", entityId: r.id, before: { status: r.status }, after: { status: "rejected", note } });
}
