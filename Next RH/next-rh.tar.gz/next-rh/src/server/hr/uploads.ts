import "server-only";
import { createDocument } from "@/server/documents/store";
import { HrError } from "./common";

const ALLOWED = new Set(["application/pdf", "image/jpeg", "image/png", "image/webp", "image/heic"]);
const MAX_BYTES = 10 * 1024 * 1024;

/** Retourne le fichier du formulaire s'il est présent (taille > 0), sinon null. */
export function fileFrom(fd: FormData, key: string): File | null {
  const f = fd.get(key);
  if (!f || typeof f === "string") return null;
  if (f.size === 0) return null;
  return f;
}

/** Enregistre un justificatif (catégorie « justificatif », visible du salarié concerné). */
export async function saveProof(
  file: File,
  input: { companyId: string; employeeId: string; title: string; sourceType: string; sourceId: string | null; userId: string; isDemo: boolean },
) {
  if (file.size > MAX_BYTES) throw new HrError("Fichier trop volumineux : 10 Mo maximum.");
  if (!ALLOWED.has(file.type)) throw new HrError("Format non accepté : PDF, JPEG, PNG, WebP ou HEIC.");
  const data = Buffer.from(await file.arrayBuffer());
  return createDocument({
    companyId: input.companyId,
    employeeId: input.employeeId,
    category: "justificatif",
    visibility: "employee",
    title: input.title,
    fileName: file.name || "justificatif",
    mimeType: file.type,
    data,
    sourceType: input.sourceType,
    sourceId: input.sourceId,
    uploadedBy: input.userId,
    retentionYears: 6,
    isDemo: input.isDemo,
  });
}
