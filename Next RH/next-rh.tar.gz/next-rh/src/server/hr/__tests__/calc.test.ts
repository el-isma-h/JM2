import { describe, expect, it } from "vitest";
import {
  acquiredLeave,
  allocateRequests,
  computeOvertime,
  cpReferencePeriod,
  leaveDuration,
  previousPeriod,
  remainingOf,
  remoteDaysInWeek,
} from "../calc";

describe("leaveDuration", () => {
  it("compte les jours ouvrés d'une semaine complète", () => {
    // lundi 5 au dimanche 11 octobre 2026
    expect(leaveDuration({ start: "2026-10-05", end: "2026-10-11" })).toBe(5);
  });

  it("exclut les jours fériés (1er et 11 novembre 2026)", () => {
    // du lundi 2 au vendredi 13 novembre 2026 : 10 jours ouvrés dont le 11 (mercredi) férié
    expect(leaveDuration({ start: "2026-11-02", end: "2026-11-13" })).toBe(9);
  });

  it("exclut le lundi de Pâques et l'Ascension calculés", () => {
    // Pâques 2027 : 28 mars ; lundi 29 mars férié
    expect(leaveDuration({ start: "2027-03-29", end: "2027-04-02" })).toBe(4);
    // Ascension 2027 : jeudi 6 mai
    expect(leaveDuration({ start: "2027-05-03", end: "2027-05-07" })).toBe(4); // 8 mai 2027 tombe un samedi
  });

  it("gère les demi-journées", () => {
    expect(leaveDuration({ start: "2026-10-05", end: "2026-10-09", startHalfDay: true })).toBe(4.5);
    expect(leaveDuration({ start: "2026-10-05", end: "2026-10-09", startHalfDay: true, endHalfDay: true })).toBe(4);
    expect(leaveDuration({ start: "2026-10-06", end: "2026-10-06", startHalfDay: true })).toBe(0.5);
  });

  it("une demi-journée sur un week-end ne retire rien", () => {
    expect(leaveDuration({ start: "2026-10-10", end: "2026-10-16", startHalfDay: true })).toBe(5);
  });

  it("jours ouvrables et calendaires", () => {
    expect(leaveDuration({ start: "2026-10-05", end: "2026-10-11", unit: "jours_ouvrables" })).toBe(6);
    expect(leaveDuration({ start: "2026-10-05", end: "2026-10-11", unit: "jours_calendaires" })).toBe(7);
  });

  it("heures : durée hebdomadaire / 5 par jour ouvré", () => {
    expect(leaveDuration({ start: "2026-10-05", end: "2026-10-06", unit: "heures", weeklyHours: 35 })).toBe(14);
    expect(leaveDuration({ start: "2026-10-05", end: "2026-10-05", unit: "heures", weeklyHours: 39 })).toBe(7.8);
  });

  it("dates inversées : 0", () => {
    expect(leaveDuration({ start: "2026-10-09", end: "2026-10-05" })).toBe(0);
  });
});

describe("période de référence CP", () => {
  it("1er juin au 31 mai", () => {
    expect(cpReferencePeriod("2026-10-21")).toEqual({ start: "2026-06-01", end: "2027-05-31" });
    expect(cpReferencePeriod("2026-05-31")).toEqual({ start: "2025-06-01", end: "2026-05-31" });
    expect(cpReferencePeriod("2026-06-01")).toEqual({ start: "2026-06-01", end: "2027-05-31" });
    expect(previousPeriod({ start: "2026-06-01", end: "2027-05-31" })).toEqual({ start: "2025-06-01", end: "2026-05-31" });
  });
});

describe("acquiredLeave", () => {
  const period = { start: "2026-06-01", end: "2027-05-31" };

  it("2,08 jours par mois terminé", () => {
    // au 21 octobre 2026 : juin, juillet, août, septembre terminés
    expect(acquiredLeave({ monthlyRate: 2.08, period, asOf: "2026-10-21" })).toBe(8.32);
  });

  it("aucun mois terminé le 1er juin", () => {
    expect(acquiredLeave({ monthlyRate: 2.08, period, asOf: "2026-06-15" })).toBe(0);
  });

  it("prorata pour une embauche en cours de mois", () => {
    // embauche le 16 septembre : 15 jours / 30 en septembre
    expect(acquiredLeave({ monthlyRate: 2.08, period, asOf: "2026-10-21", hireDate: "2026-09-16" })).toBe(1.04);
  });

  it("période close : arrondi au jour supérieur et plafond de 25 jours", () => {
    expect(acquiredLeave({ monthlyRate: 2.08, period, asOf: "2027-06-15" })).toBe(25);
    expect(acquiredLeave({ monthlyRate: 2.08, period, asOf: "2027-06-15", hireDate: "2026-12-01" })).toBe(13); // décembre à mai : 6 x 2,08 = 12,48, arrondi à 13
  });

  it("sortie en cours de période", () => {
    // sortie le 31 août : juin, juillet, août
    expect(acquiredLeave({ monthlyRate: 2.08, period, asOf: "2026-10-21", leaveDate: "2026-08-31" })).toBe(6.24);
  });
});

describe("allocateRequests", () => {
  it("consomme d'abord le reliquat N-1 puis la période en cours", () => {
    const buckets = [
      { periodStart: "2025-06-01", acquired: 25, adjustment: 0 },
      { periodStart: "2026-06-01", acquired: 8.32, adjustment: 0 },
    ];
    const res = allocateRequests("CP", buckets, [
      { id: "a", start: "2026-07-20", duration: 20, status: "approved" },
      { id: "b", start: "2026-12-21", duration: 8, status: "pending" },
    ]);
    expect(res["2025-06-01"]).toEqual({ taken: 20, pending: 5 });
    expect(res["2026-06-01"]).toEqual({ taken: 0, pending: 3 });
    expect(remainingOf({ acquired: 8.32, adjustment: 0, ...res["2026-06-01"] })).toBe(5.32);
  });

  it("un dépassement reste imputé sur la dernière période (solde négatif visible)", () => {
    const res = allocateRequests("CP", [{ periodStart: "2026-06-01", acquired: 2, adjustment: 0 }], [
      { id: "a", start: "2026-10-05", duration: 5, status: "approved" },
    ]);
    expect(res["2026-06-01"].taken).toBe(5);
  });
});

describe("computeOvertime", () => {
  it("aucune heure sup à 35 h par semaine", () => {
    // octobre 2026 : semaines complètes du 5 au 25
    const entries = [] as { date: string; hours: number }[];
    for (let d = 5; d <= 9; d++) entries.push({ date: `2026-10-0${d}`, hours: 7 });
    const r = computeOvertime(entries, 35, 2026, 10);
    expect(r.totalHours).toBe(35);
    expect(r.overtimeHours).toBe(0);
  });

  it("détecte les heures au-delà de 35 h et répartit 25 % / 50 %", () => {
    const entries = [
      { date: "2026-10-05", hours: 10 },
      { date: "2026-10-06", hours: 10 },
      { date: "2026-10-07", hours: 10 },
      { date: "2026-10-08", hours: 10 },
      { date: "2026-10-09", hours: 7 },
    ];
    const r = computeOvertime(entries, 35, 2026, 10);
    expect(r.totalHours).toBe(47);
    expect(r.overtimeHours).toBe(12);
    expect(r.at25).toBe(8);
    expect(r.at50).toBe(4);
  });

  it("semaine à cheval : seuil proratisé", () => {
    // jeudi 1er et vendredi 2 octobre 2026 : 2 jours ouvrés dans le mois, seuil 14 h
    const r = computeOvertime(
      [
        { date: "2026-10-01", hours: 9 },
        { date: "2026-10-02", hours: 8 },
      ],
      35,
      2026,
      10,
    );
    expect(r.overtimeHours).toBe(3);
  });

  it("ignore les dates hors du mois", () => {
    const r = computeOvertime([{ date: "2026-09-30", hours: 12 }], 35, 2026, 10);
    expect(r.totalHours).toBe(0);
  });

  it("respecte un contrat à 39 h", () => {
    const entries = ["05", "06", "07", "08", "09"].map((d) => ({ date: `2026-10-${d}`, hours: 8 }));
    expect(computeOvertime(entries, 39, 2026, 10).overtimeHours).toBe(1);
  });
});

describe("remoteDaysInWeek", () => {
  it("compte les jours de la même semaine civile", () => {
    expect(remoteDaysInWeek(["2026-10-05", "2026-10-07", "2026-10-12"], "2026-10-09")).toBe(2);
    expect(remoteDaysInWeek(["2026-10-05"], "2026-10-05")).toBe(0);
  });
});
