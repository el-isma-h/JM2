export const TRAINING_KINDS = [
  { value: "formation", label: "Formation" },
  { value: "habilitation", label: "Habilitation (électrique, CACES, SST…)" },
  { value: "certification", label: "Certification" },
  { value: "obligatoire", label: "Formation obligatoire (sécurité, hygiène)" },
] as const;

export const TRAINING_STATUSES = [
  { value: "requested", label: "Demandée", tone: "warn" },
  { value: "approved", label: "Acceptée", tone: "info" },
  { value: "planned", label: "Planifiée", tone: "info" },
  { value: "done", label: "Réalisée", tone: "ok" },
  { value: "rejected", label: "Refusée", tone: "danger" },
  { value: "cancelled", label: "Annulée", tone: "neutral" },
] as const;

export const trainingStatus = (v: string) => TRAINING_STATUSES.find((s) => s.value === v) ?? { value: v, label: v, tone: "neutral" as const };
export const trainingKind = (v: string) => TRAINING_KINDS.find((s) => s.value === v)?.label ?? v;
