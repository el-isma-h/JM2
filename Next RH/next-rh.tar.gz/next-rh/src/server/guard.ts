import "server-only";
import { notFound, redirect } from "next/navigation";
import { AuthError } from "./auth";
import { requireCompany, requirePlatformAdmin, type CompanyContext, type Permission } from "./authz";

/**
 * À utiliser dans les pages serveur : vérifie l'accès et redirige proprement
 * (connexion, vérification e-mail, vérification renforcée) au lieu de lever une erreur.
 */
export async function guardCompany(companyId: string, nextPath: string, ...perms: Permission[]): Promise<CompanyContext> {
  try {
    return await requireCompany(companyId, ...perms);
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}

export async function guardAdmin(nextPath: string) {
  try {
    return await requirePlatformAdmin();
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}

export function handleAuthError(e: unknown, nextPath: string): never {
  if (e instanceof AuthError) {
    if (e.code === "unauthenticated") redirect(`/connexion?next=${encodeURIComponent(nextPath)}`);
    if (e.code === "email_unverified") redirect("/verification");
    if (e.code === "elevation_required") redirect(`/securite?next=${encodeURIComponent(nextPath)}`);
    notFound();
  }
  throw e;
}

/** Dans une server action : convertit une AuthError en message lisible. */
export function authErrorMessage(e: unknown): string | null {
  if (e instanceof AuthError) {
    return {
      unauthenticated: "Session expirée : reconnectez-vous.",
      forbidden: "Vous n'avez pas l'habilitation nécessaire pour cette action.",
      elevation_required: "Cette action demande une vérification renforcée (code d'authentification).",
      email_unverified: "Vérifiez votre adresse e-mail avant de continuer.",
    }[e.code];
  }
  return null;
}
