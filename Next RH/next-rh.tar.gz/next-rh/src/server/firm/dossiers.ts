import "server-only";
import { and, asc, eq, gte, inArray, ne, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { isoToday } from "@/lib/dates";
import type { SessionUser } from "@/server/auth";
import { listAccessibleCompanies } from "@/server/authz";

export type Company = typeof schema.companies.$inferSelect;

/**
 * Entreprises gérées par l'utilisateur dans la vue cabinet : entreprises accessibles (affectations + tenant
 * cabinet/groupe, logique de `listAccessibleCompanies`), hors celles où il n'est que salarié.
 */
export async function listManagedCompanies(user: SessionUser): Promise<Company[]> {
  const all = await listAccessibleCompanies(user);
  if (!all.length) return [];
  const own = await db
    .select({ companyId: schema.companyMemberships.companyId, role: schema.companyMemberships.role })
    .from(schema.companyMemberships)
    .where(and(eq(schema.companyMemberships.userId, user.id), inArray(schema.companyMemberships.companyId, all.map((c) => c.id))));
  const employeeOnly = new Set(own.filter((m) => m.role === "employee").map((m) => m.companyId));
  return all.filter((c) => !employeeOnly.has(c.id));
}

export type Dossier = {
  company: Company;
  myRole: string | null;
  period: { year: number; month: number; status: string; paymentDate: string | null } | null;
  openAnomalies: number;
  blockingAnomalies: number;
  nextDeadline: { title: string; dueDate: string } | null;
  managers: { userId: string; name: string; role: string }[];
  activeEmployees: number;
};

export async function loadDossiers(user: SessionUser, companies: Company[]): Promise<Dossier[]> {
  if (!companies.length) return [];
  const ids = companies.map((c) => c.id);
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const today = isoToday();

  const [periods, anomalies, deadlines, managers, headcounts] = await Promise.all([
    db
      .select()
      .from(schema.payrollPeriods)
      .where(and(inArray(schema.payrollPeriods.companyId, ids), eq(schema.payrollPeriods.year, year), eq(schema.payrollPeriods.month, month))),
    db
      .select({
        companyId: schema.payrollPeriods.companyId,
        open: sql<number>`count(*)::int`,
        blocking: sql<number>`count(*) filter (where ${schema.payrollAnomalies.severity} = 'blocking')::int`,
      })
      .from(schema.payrollAnomalies)
      .innerJoin(schema.payrollPeriods, eq(schema.payrollPeriods.id, schema.payrollAnomalies.periodId))
      .where(and(inArray(schema.payrollPeriods.companyId, ids), eq(schema.payrollAnomalies.status, "open")))
      .groupBy(schema.payrollPeriods.companyId),
    db
      .selectDistinctOn([schema.deadlines.companyId], { companyId: schema.deadlines.companyId, title: schema.deadlines.title, dueDate: schema.deadlines.dueDate })
      .from(schema.deadlines)
      .where(and(inArray(schema.deadlines.companyId, ids), gte(schema.deadlines.dueDate, today), eq(schema.deadlines.status, "upcoming")))
      .orderBy(schema.deadlines.companyId, asc(schema.deadlines.dueDate)),
    db
      .select({ companyId: schema.companyMemberships.companyId, userId: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, role: schema.companyMemberships.role })
      .from(schema.companyMemberships)
      .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
      .where(and(inArray(schema.companyMemberships.companyId, ids), ne(schema.companyMemberships.role, "employee"))),
    db
      .select({ companyId: schema.employees.companyId, n: sql<number>`count(*)::int` })
      .from(schema.employees)
      .where(and(inArray(schema.employees.companyId, ids), eq(schema.employees.status, "active")))
      .groupBy(schema.employees.companyId),
  ]);

  return companies.map((c) => {
    const p = periods.find((x) => x.companyId === c.id);
    const a = anomalies.find((x) => x.companyId === c.id);
    const d = deadlines.find((x) => x.companyId === c.id);
    const ms = managers.filter((m) => m.companyId === c.id);
    return {
      company: c,
      myRole: ms.find((m) => m.userId === user.id)?.role ?? null,
      period: p ? { year: p.year, month: p.month, status: p.status, paymentDate: p.paymentDate } : null,
      openAnomalies: a?.open ?? 0,
      blockingAnomalies: a?.blocking ?? 0,
      nextDeadline: d ? { title: d.title, dueDate: d.dueDate } : null,
      managers: ms.map((m) => ({ userId: m.userId, name: `${m.firstName} ${m.lastName}`, role: m.role })),
      activeEmployees: headcounts.find((h) => h.companyId === c.id)?.n ?? 0,
    };
  });
}

/** Le tenant de l'utilisateur peut-il recevoir une nouvelle entreprise créée par lui ? */
export async function canCreateFirmCompany(user: SessionUser): Promise<{ ok: true; tenant: typeof schema.tenants.$inferSelect } | { ok: false; reason: string }> {
  if (!user.tenantId) return { ok: false, reason: "Votre compte n'est rattaché à aucun cabinet ou groupe." };
  const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, user.tenantId)).limit(1);
  if (!tenant) return { ok: false, reason: "Organisation introuvable." };
  if (tenant.kind === "company") return { ok: false, reason: "Votre organisation est une entreprise seule : la création de dossiers est réservée aux cabinets et aux groupes." };
  const [m] = await db
    .select({ id: schema.companyMemberships.id })
    .from(schema.companyMemberships)
    .innerJoin(schema.companies, eq(schema.companies.id, schema.companyMemberships.companyId))
    .where(and(eq(schema.companyMemberships.userId, user.id), eq(schema.companies.tenantId, tenant.id), inArray(schema.companyMemberships.role, ["owner", "admin"])))
    .limit(1);
  if (!m) return { ok: false, reason: "Seul un propriétaire ou un administrateur d'une entreprise du cabinet peut créer un nouveau dossier." };
  return { ok: true, tenant };
}
