import "server-only";

/**
 * Accès au cycle de paie (module de l'équipe paie). L'assistant n'effectue AUCUN calcul réglementaire :
 * il délègue l'ouverture, la collecte et le calcul au moteur via ces trois fonctions.
 * Import dynamique : si le module est indisponible, l'assistant l'indique au lieu d'échouer.
 */
export type PayrollCycle = {
  openPeriod(companyId: string, year: number, month: number, userId: string): Promise<{ periodId: string }>;
  collectVariables(periodId: string, userId: string): Promise<unknown>;
  computePeriod(periodId: string, userId: string): Promise<{ computed: number; blocked: number; anomalies: number }>;
};

export async function loadPayrollCycle(): Promise<PayrollCycle | null> {
  try {
    const mod = (await import("@/server/payroll/cycle")) as Partial<PayrollCycle>;
    if (typeof mod.openPeriod !== "function" || typeof mod.collectVariables !== "function" || typeof mod.computePeriod !== "function") return null;
    return mod as PayrollCycle;
  } catch {
    return null;
  }
}
