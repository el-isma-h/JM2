import type { Permission } from "@/server/authz";
import type { ToolName } from "./intents";

/**
 * Politique d'accès de l'assistant (pure, testée). Chaque outil vérifie en plus `requireCompany`
 * avec ces permissions côté serveur : ce filtre n'est pas qu'une consigne donnée au modèle.
 */

export const TOOL_PERMISSIONS: Record<ToolName, Permission[]> = {
  payrollStatus: ["payroll.prepare"],
  preparePayroll: ["payroll.prepare"],
  explainVariance: ["salaries.read"],
  draftDocument: ["documents.write"],
  upcomingTrialPeriods: ["employees.read"],
  missingItems: ["payroll.prepare"],
};

/** Outils qui écrivent : exécution uniquement après confirmation explicite. */
export const WRITE_TOOLS: ToolName[] = ["preparePayroll", "draftDocument"];

export const TOOL_LABELS: Record<ToolName, string> = {
  payrollStatus: "État de la paie du mois",
  preparePayroll: "Préparer la paie",
  explainVariance: "Expliquer un écart de bulletin",
  draftDocument: "Préparer un document",
  upcomingTrialPeriods: "Périodes d'essai à échéance",
  missingItems: "Éléments manquants avant validation",
};

export function canUseTool(tool: ToolName, perms: Set<Permission>): boolean {
  return TOOL_PERMISSIONS[tool].every((p) => perms.has(p));
}

export function allowedTools(perms: Set<Permission>): ToolName[] {
  return (Object.keys(TOOL_PERMISSIONS) as ToolName[]).filter((t) => canUseTool(t, perms));
}

export function missingPermissionMessage(tool: ToolName): string {
  const need = TOOL_PERMISSIONS[tool];
  const names: Partial<Record<Permission, string>> = {
    "payroll.prepare": "préparation de la paie",
    "salaries.read": "consultation des salaires",
    "documents.write": "rédaction de documents",
    "employees.read": "consultation des salariés",
  };
  return `« ${TOOL_LABELS[tool]} » demande l'habilitation ${need.map((p) => names[p] ?? p).join(" et ")}. Demandez-la à un administrateur de l'entreprise.`;
}

const AMOUNT_IN_TEXT = /-?\d{1,3}(?:[   .]\d{3})*(?:,\d{1,2})?\s?(?:€|euros?)/gi;

/** Masque les montants d'un texte libre (ex. explication d'anomalie) pour un utilisateur non habilité aux salaires. */
export function maskAmounts(text: string, perms: Set<Permission>): string {
  return perms.has("salaries.read") ? text : text.replace(AMOUNT_IN_TEXT, "[montant masqué]");
}

/** Champs de rémunération qu'un enregistrement peut contenir. */
const PAY_FIELDS = [
  "grossCents",
  "netPaidCents",
  "netTaxableCents",
  "netBeforeTaxCents",
  "employerCostCents",
  "employeeContribCents",
  "employerContribCents",
  "pasAmountCents",
  "variance",
  "lines",
  "compensation",
  "grossAmountCents",
] as const;

/** Retire de l'objet tout champ de rémunération si l'utilisateur n'a pas `salaries.read`. */
export function filterPayFields<T extends Record<string, unknown>>(row: T, perms: Set<Permission>): Partial<T> {
  if (perms.has("salaries.read")) return row;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(row)) if (!(PAY_FIELDS as readonly string[]).includes(k)) out[k] = v;
  return out as Partial<T>;
}

/** Données d'un salarié transmissibles à l'assistant ou à l'IA : jamais NIR ni IBAN, rémunération seulement si habilité. */
export function employeeForAssistant(
  e: { id: string; firstName: string; lastName: string; jobTitle?: string | null; [k: string]: unknown },
  perms: Set<Permission>,
) {
  const base = { id: e.id, name: `${e.firstName} ${e.lastName}`, jobTitle: e.jobTitle ?? null };
  if (perms.has("salaries.read") && typeof e.grossAmountCents === "number") return { ...base, grossAmountCents: e.grossAmountCents };
  return base;
}
