/**
 * Routeur d'intentions déterministe (pur, sans IA) : expressions et mots-clés normalisés.
 * Il fonctionne seul ; l'IA, si elle est configurée, ne sert qu'aux formulations libres non reconnues.
 */

export type ToolName = "payrollStatus" | "preparePayroll" | "explainVariance" | "draftDocument" | "upcomingTrialPeriods" | "missingItems";

export type Intent = {
  tool: ToolName | null;
  /** Arguments extraits du texte. */
  args: { employeeQuery?: string; templateCode?: string; days?: number; month?: number; year?: number };
  /** Règle ayant produit la correspondance (traçabilité). */
  rule: string | null;
};

export function normalize(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[’']/g, " ")
    .replace(/[^a-z0-9 -]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Types de documents reconnus -> code de modèle de l'atelier. Ordre : du plus spécifique au plus général. */
export const DOC_KEYWORDS: { re: RegExp; code: string }[] = [
  { re: /attestation (de )?salaire|attestation de remuneration/, code: "attestation-salaire" },
  { re: /attestation (de )?travail/, code: "attestation-travail" },
  { re: /attestation france travail|attestation pole emploi/, code: "attestation-france-travail-preparation" },
  { re: /attestation (employeur)?/, code: "attestation-employeur" },
  { re: /certificat de travail/, code: "certificat-travail" },
  { re: /solde de tout compte/, code: "recu-solde-tout-compte" },
  { re: /renouvellement (de (la )?)?periode d essai/, code: "renouvellement-periode-essai" },
  { re: /\bcdd\b|duree determinee/, code: "contrat-cdd" },
  { re: /\bcdi\b|contrat de travail/, code: "contrat-cdi" },
  { re: /avenant/, code: "avenant-contrat" },
  { re: /compte rendu .*prealable/, code: "compte-rendu-entretien-prealable" },
  { re: /compte rendu .*annuel/, code: "compte-rendu-entretien-annuel" },
  { re: /convocation .*prealable|entretien prealable/, code: "convocation-entretien-prealable" },
  { re: /convocation .*annuel|entretien annuel/, code: "convocation-entretien-annuel" },
  { re: /fiche de poste/, code: "fiche-poste" },
  { re: /offre d emploi|annonce/, code: "offre-emploi" },
  { re: /note (interne|de service)/, code: "note-interne" },
  { re: /procedure/, code: "procedure-rh" },
  { re: /reponse|repondre/, code: "reponse-salarie" },
  { re: /courrier|lettre/, code: "courrier-administratif" },
];

const MONTHS = ["janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre"];

function extractEmployee(raw: string): string | undefined {
  // « pour Camille Rousseau », « de Camille Rousseau », « l'écart de Mme Rousseau »
  const m = raw.match(/\b(?:pour|de|d'|du salarié|de la salariée)\s+((?:M\.|Mme|Mlle)?\s*[A-ZÀ-Ý][\p{L}'-]+(?:\s+[A-ZÀ-Ý][\p{L}'-]+){0,2})/u);
  if (!m) return undefined;
  const name = m[1].replace(/^(M\.|Mme|Mlle)\s*/, "").trim();
  const stop = ["Ce", "Cette", "Le", "La", "Les", "Mois"];
  return stop.includes(name.split(/\s+/)[0]) ? undefined : name;
}

function extractPeriod(n: string): { month?: number; year?: number } {
  for (let i = 0; i < MONTHS.length; i++) {
    const m = n.match(new RegExp(`\\b${MONTHS[i]}(?: (20\\d{2}))?\\b`));
    if (m) return { month: i + 1, year: m[1] ? Number(m[1]) : undefined };
  }
  return {};
}

type Rule = { name: string; tool: ToolName; test: (n: string) => boolean };

const has = (n: string, ...words: string[]) => words.some((w) => n.includes(w));

const RULES: Rule[] = [
  { name: "essai", tool: "upcomingTrialPeriods", test: (n) => has(n, "periode d essai", "periodes d essai", "fin d essai", "fins d essai") && !has(n, "redige", "prepare un", "prepare une", "renouvellement de") },
  { name: "manquants", tool: "missingItems", test: (n) => has(n, "manque", "manquant", "avant validation", "bloquant", "bloque la paie", "a completer") },
  { name: "ecart", tool: "explainVariance", test: (n) => has(n, "ecart", "variation", "difference") || (has(n, "explique") && has(n, "mois precedent", "bulletin")) },
  { name: "preparer-paie", tool: "preparePayroll", test: (n) => has(n, "paie", "bulletins") && has(n, "prepare", "lance", "calcule", "ouvre", "demarre") },
  { name: "statut-paie", tool: "payrollStatus", test: (n) => has(n, "paie") && has(n, "statut", "ou en est", "etat", "avancement", "point sur") },
  {
    name: "document",
    tool: "draftDocument",
    test: (n) => has(n, "redige", "rediger", "prepare", "genere", "ecris", "cree", "fais") && DOC_KEYWORDS.some((k) => k.re.test(n)),
  },
];

export function routeIntent(raw: string): Intent {
  const n = normalize(raw);
  for (const r of RULES) {
    if (!r.test(n)) continue;
    const args: Intent["args"] = {};
    const emp = extractEmployee(raw);
    if (emp) args.employeeQuery = emp;
    if (r.tool === "draftDocument") args.templateCode = DOC_KEYWORDS.find((k) => k.re.test(n))?.code;
    if (r.tool === "upcomingTrialPeriods") {
      const d = n.match(/(\d{1,3}) (prochains )?jours/);
      args.days = d ? Math.min(180, Number(d[1])) : 30;
    }
    if (r.tool === "preparePayroll" || r.tool === "payrollStatus" || r.tool === "missingItems") Object.assign(args, extractPeriod(n));
    return { tool: r.tool, args, rule: r.name };
  }
  return { tool: null, args: {}, rule: null };
}

export const SUGGESTIONS = [
  "Prépare la paie de ce mois-ci.",
  "Quels éléments manquent avant validation ?",
  "Explique cet écart avec le mois précédent.",
  "Prépare une attestation pour ce salarié.",
  "Quelles périodes d'essai se terminent bientôt ?",
];
