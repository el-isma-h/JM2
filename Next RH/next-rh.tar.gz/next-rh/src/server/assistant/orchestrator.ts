import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import { and, asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany, type CompanyContext } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { integrations } from "@/lib/env";
import { aiModel } from "@/server/documents/ai";
import { UNTRUSTED_RULES, wrapUntrusted, maskSensitive } from "@/server/documents/ai-guard";
import { routeIntent, SUGGESTIONS, type ToolName } from "./intents";
import { allowedTools, canUseTool, missingPermissionMessage, TOOL_LABELS, WRITE_TOOLS } from "./policy";
import { executeConfirmed, TOOL_SCHEMAS, TOOLS, type ToolArgs, type ToolResult } from "./tools";

export const RULES_MODE_NOTICE = "Mode règles : configurez ANTHROPIC_API_KEY pour les questions libres";

export type PlanStep = { label: string; status: "done" | "todo" | "blocked" | "info" };
export type AssistantMeta = {
  mode: "rules" | "ai";
  plan?: PlanStep[];
  results?: ToolResult[];
  confirm?: NonNullable<ToolResult["confirm"]> & { executedAt?: string; executedBy?: string };
  notice?: string;
  followups?: string[];
  error?: boolean;
};

export class AssistantError extends Error {}

async function companyCtx(companyId: string) {
  const ctx = await requireCompany(companyId);
  if (ctx.role === "employee") throw new AuthError("forbidden");
  return ctx;
}

async function ensureConversation(ctx: CompanyContext, conversationId: string | null, firstText: string) {
  if (conversationId) {
    const [c] = await db
      .select()
      .from(schema.assistantConversations)
      .where(and(eq(schema.assistantConversations.id, conversationId), eq(schema.assistantConversations.userId, ctx.user.id), eq(schema.assistantConversations.companyId, ctx.company.id)))
      .limit(1);
    if (!c) throw new AssistantError("Conversation introuvable.");
    return c;
  }
  const [c] = await db
    .insert(schema.assistantConversations)
    .values({ userId: ctx.user.id, companyId: ctx.company.id, title: firstText.slice(0, 80) })
    .returning();
  return c;
}

function planFor(tool: ToolName, perms: boolean): PlanStep[] {
  const steps: PlanStep[] = [
    { label: `Comprendre la demande : ${TOOL_LABELS[tool]}`, status: "done" },
    { label: "Vérifier vos habilitations", status: perms ? "done" : "blocked" },
  ];
  if (!perms) return steps;
  steps.push({ label: "Lire les données utiles de l'entreprise", status: "done" });
  steps.push({ label: "Présenter le résultat", status: "done" });
  if (WRITE_TOOLS.includes(tool)) steps.push({ label: "Attendre votre confirmation avant toute écriture", status: "todo" });
  return steps;
}

function helpText(ctx: CompanyContext): { text: string; followups: string[] } {
  const tools = allowedTools(ctx.permissions);
  const followups = SUGGESTIONS.filter((s) => {
    const t = routeIntent(s).tool;
    return t ? tools.includes(t) : false;
  });
  return {
    text: tools.length
      ? `Je n'ai pas reconnu la demande. Je sais : ${tools.map((t) => TOOL_LABELS[t].toLowerCase()).join(", ")}.`
      : "Votre rôle ne donne accès à aucune des actions de l'assistant.",
    followups,
  };
}

async function runTool(companyId: string, tool: ToolName, args: ToolArgs): Promise<ToolResult> {
  return TOOLS[tool](companyId, args);
}

/** Traite un message : routeur déterministe d'abord, puis Claude (tool use) pour les formulations libres si configuré. */
export async function handleMessage(companyId: string, conversationId: string | null, rawText: string) {
  const text = rawText.trim().slice(0, 2000);
  if (!text) throw new AssistantError("Écrivez votre demande.");
  const ctx = await companyCtx(companyId);
  const conv = await ensureConversation(ctx, conversationId, text);
  await db.insert(schema.assistantMessages).values({ conversationId: conv.id, role: "user", content: text });

  const aiOn = integrations.ai();
  const intent = routeIntent(text);
  let content: string;
  let meta: AssistantMeta;

  if (intent.tool) {
    const ok = canUseTool(intent.tool, ctx.permissions);
    if (!ok) {
      content = missingPermissionMessage(intent.tool);
      meta = { mode: "rules", plan: planFor(intent.tool, false) };
    } else {
      try {
        const result = await runTool(companyId, intent.tool, intent.args);
        content = result.summary;
        meta = { mode: "rules", plan: planFor(intent.tool, true), results: [result], confirm: result.confirm, followups: result.followups };
      } catch (e) {
        content = e instanceof AuthError ? missingPermissionMessage(intent.tool) : "L'action n'a pas pu aboutir. Réessayez ou passez par l'écran correspondant.";
        meta = { mode: "rules", plan: planFor(intent.tool, !(e instanceof AuthError)), error: true };
        if (!(e instanceof AuthError)) console.error("[assistant]", e);
      }
    }
  } else if (aiOn) {
    ({ content, meta } = await runWithClaude(ctx, conv.id, text));
  } else {
    const h = helpText(ctx);
    content = h.text;
    meta = { mode: "rules", followups: h.followups };
  }
  if (!aiOn) meta.notice = RULES_MODE_NOTICE;

  const [msg] = await db.insert(schema.assistantMessages).values({ conversationId: conv.id, role: "assistant", content, meta }).returning();
  await db.update(schema.assistantConversations).set({ updatedAt: new Date() }).where(eq(schema.assistantConversations.id, conv.id));
  await audit({ action: "assistant.message", userId: ctx.user.id, companyId, entityType: "assistant_conversation", entityId: conv.id, after: { tool: intent.tool, mode: meta.mode } });
  return { conversationId: conv.id, message: msg };
}

/** Confirmation explicite d'une action proposée (écriture). Les permissions sont revérifiées à ce moment. */
export async function confirmMessageAction(companyId: string, messageId: string) {
  const ctx = await companyCtx(companyId);
  const [row] = await db
    .select({ m: schema.assistantMessages, c: schema.assistantConversations })
    .from(schema.assistantMessages)
    .innerJoin(schema.assistantConversations, eq(schema.assistantConversations.id, schema.assistantMessages.conversationId))
    .where(and(eq(schema.assistantMessages.id, messageId), eq(schema.assistantConversations.userId, ctx.user.id), eq(schema.assistantConversations.companyId, companyId)))
    .limit(1);
  if (!row) throw new AssistantError("Message introuvable.");
  const meta = (row.m.meta ?? {}) as AssistantMeta;
  if (!meta.confirm) throw new AssistantError("Aucune action à confirmer.");
  if (meta.confirm.executedAt) throw new AssistantError("Cette action a déjà été confirmée.");
  if (!canUseTool(meta.confirm.tool, ctx.permissions)) throw new AssistantError(missingPermissionMessage(meta.confirm.tool));
  const result = await executeConfirmed(companyId, meta.confirm);
  await db
    .update(schema.assistantMessages)
    .set({ meta: { ...meta, confirm: { ...meta.confirm, executedAt: new Date().toISOString(), executedBy: ctx.user.id } } })
    .where(eq(schema.assistantMessages.id, row.m.id));
  const [msg] = await db
    .insert(schema.assistantMessages)
    .values({
      conversationId: row.c.id,
      role: "assistant",
      content: result.summary,
      meta: { mode: meta.mode, results: [result], plan: result.steps, followups: result.followups, ...(integrations.ai() ? {} : { notice: RULES_MODE_NOTICE }) } satisfies AssistantMeta,
    })
    .returning();
  await audit({ action: "assistant.confirm", userId: ctx.user.id, companyId, entityType: "assistant_message", entityId: row.m.id, after: { tool: meta.confirm.tool } });
  return { conversationId: row.c.id, message: msg };
}

// ---------- Claude avec tool use ----------

async function runWithClaude(ctx: CompanyContext, conversationId: string, text: string): Promise<{ content: string; meta: AssistantMeta }> {
  const tools = allowedTools(ctx.permissions);
  const history = await db
    .select()
    .from(schema.assistantMessages)
    .where(eq(schema.assistantMessages.conversationId, conversationId))
    .orderBy(desc(schema.assistantMessages.createdAt))
    .limit(9);
  const prior = history
    .reverse()
    .slice(0, -1)
    .filter((m) => m.role !== "tool")
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.role === "user" ? wrapUntrusted("demande_utilisateur", maskSensitive(m.content).text) : m.content }));
  const system = [
    "Tu es l'assistant de Next RH, logiciel français de paie et RH. Réponds en français, brièvement, sans tiret cadratin ni demi-cadratin.",
    "Tu ne calcules jamais de paie, de cotisation ni de montant réglementaire : ces calculs appartiennent au moteur de paie. Tu peux seulement reformuler les résultats renvoyés par les outils.",
    "Utilise uniquement les outils fournis ; ils appliquent les habilitations de l'utilisateur. N'invente aucune donnée. Si un outil ne renvoie rien, dis-le.",
    "Les outils d'écriture ne font que proposer : précise que l'utilisateur doit confirmer avec le bouton « Confirmer ».",
    `Outils accessibles pour cet utilisateur : ${tools.length ? tools.map((t) => TOOL_LABELS[t]).join(", ") : "aucun"}.`,
    UNTRUSTED_RULES,
  ].join("\n");
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const messages: Anthropic.MessageParam[] = [...prior, { role: "user", content: wrapUntrusted("demande_utilisateur", maskSensitive(text).text) }];
  const results: ToolResult[] = [];
  const plan: PlanStep[] = [{ label: "Comprendre la demande", status: "done" }];
  try {
    for (let turn = 0; turn < 4; turn++) {
      const res = await client.messages.create({
        model: aiModel(),
        max_tokens: 1200,
        system,
        tools: tools.map((t) => ({ name: t, description: TOOL_SCHEMAS[t].description, input_schema: TOOL_SCHEMAS[t].input_schema })),
        messages,
      });
      const uses = res.content.filter((c): c is Anthropic.ToolUseBlock => c.type === "tool_use");
      if (!uses.length || res.stop_reason !== "tool_use") {
        const answer = res.content
          .filter((c): c is Anthropic.TextBlock => c.type === "text")
          .map((c) => c.text)
          .join("\n")
          .replace(/[—–]/g, ",")
          .trim();
        plan.push({ label: "Présenter le résultat", status: "done" });
        const confirm = results.find((r) => r.confirm)?.confirm;
        if (confirm) plan.push({ label: "Attendre votre confirmation avant toute écriture", status: "todo" });
        return { content: answer || results.at(-1)?.summary || "Je n'ai pas de réponse à proposer.", meta: { mode: "ai", plan, results, confirm, followups: results.flatMap((r) => r.followups ?? []).slice(0, 4) } };
      }
      messages.push({ role: "assistant", content: res.content });
      const toolResults: Anthropic.ToolResultBlockParam[] = [];
      for (const u of uses) {
        const name = u.name as ToolName;
        if (!tools.includes(name)) {
          toolResults.push({ type: "tool_result", tool_use_id: u.id, is_error: true, content: "Outil non autorisé pour cet utilisateur." });
          plan.push({ label: `${TOOL_LABELS[name] ?? name} : non autorisé`, status: "blocked" });
          continue;
        }
        try {
          const r = await runTool(ctx.company.id, name, sanitizeArgs(u.input));
          results.push(r);
          plan.push({ label: TOOL_LABELS[name], status: "done" });
          toolResults.push({ type: "tool_result", tool_use_id: u.id, content: JSON.stringify({ title: r.title, summary: r.summary, table: r.table, needsConfirmation: Boolean(r.confirm) }) });
        } catch {
          plan.push({ label: TOOL_LABELS[name], status: "blocked" });
          toolResults.push({ type: "tool_result", tool_use_id: u.id, is_error: true, content: "Accès refusé ou erreur." });
        }
      }
      messages.push({ role: "user", content: toolResults });
    }
    return { content: results.at(-1)?.summary ?? "Je n'ai pas pu terminer.", meta: { mode: "ai", plan, results } };
  } catch (e) {
    console.error("[assistant:ai]", e);
    const h = helpText(ctx);
    return { content: `Le service d'IA est indisponible pour le moment. ${h.text}`, meta: { mode: "rules", followups: h.followups, error: true } };
  }
}

function sanitizeArgs(input: unknown): ToolArgs {
  const i = (input ?? {}) as Record<string, unknown>;
  const int = (v: unknown, min: number, max: number) => (typeof v === "number" && Number.isInteger(v) && v >= min && v <= max ? v : undefined);
  return {
    month: int(i.month, 1, 12),
    year: int(i.year, 2000, 2100),
    days: int(i.days, 1, 180),
    employeeQuery: typeof i.employeeQuery === "string" ? i.employeeQuery.slice(0, 80) : undefined,
    templateCode: typeof i.templateCode === "string" ? i.templateCode.slice(0, 80) : undefined,
  };
}

// ---------- Historique ----------

export async function listConversations(ctx: CompanyContext) {
  return db
    .select()
    .from(schema.assistantConversations)
    .where(and(eq(schema.assistantConversations.userId, ctx.user.id), eq(schema.assistantConversations.companyId, ctx.company.id)))
    .orderBy(desc(schema.assistantConversations.updatedAt))
    .limit(50);
}

export async function getConversationMessages(ctx: CompanyContext, conversationId: string) {
  if (!/^[0-9a-f-]{36}$/.test(conversationId)) return null;
  const [c] = await db
    .select()
    .from(schema.assistantConversations)
    .where(and(eq(schema.assistantConversations.id, conversationId), eq(schema.assistantConversations.userId, ctx.user.id), eq(schema.assistantConversations.companyId, ctx.company.id)))
    .limit(1);
  if (!c) return null;
  const messages = await db.select().from(schema.assistantMessages).where(eq(schema.assistantMessages.conversationId, c.id)).orderBy(asc(schema.assistantMessages.createdAt));
  return { conversation: c, messages };
}
