import "server-only";
import { and, asc, between, desc, eq, ilike, inArray, isNull, ne, notExists, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCompany, type CompanyContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { fmtDate, monthLabel, deMonth } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { createDraft, getTemplate, templateMeta } from "@/server/documents/drafting";
import { TEMPLATES } from "@/server/documents/templates-data";
import { maskAmounts, TOOL_LABELS, TOOL_PERMISSIONS } from "./policy";
import type { Intent, ToolName } from "./intents";
import { loadPayrollCycle } from "./payroll-cycle";

/**
 * Outils de l'assistant. Chaque outil appelle requireCompany avec ses permissions (TOOL_PERMISSIONS) :
 * le filtrage est fait côté serveur, quelle que soit la demande ou la consigne donnée au modèle.
 * Les outils qui écrivent (preparePayroll, draftDocument) ne font que PROPOSER ; l'exécution passe par executeConfirmed().
 */

export type ToolArgs = Intent["args"];

export type ToolResult = {
  tool: ToolName;
  title: string;
  summary: string;
  steps?: { label: string; status: "done" | "todo" | "blocked" | "info" }[];
  table?: { columns: string[]; rows: string[][]; numeric?: number[] };
  links?: { label: string; href: string }[];
  followups?: string[];
  confirm?: { label: string; tool: ToolName; args: ToolArgs & { templateId?: string; employeeId?: string } };
};

const ctxFor = (companyId: string, tool: ToolName) => requireCompany(companyId, ...TOOL_PERMISSIONS[tool]);

function currentPeriod(args: ToolArgs) {
  const now = new Date();
  const month = args.month ?? now.getMonth() + 1;
  const year = args.year ?? (args.month && args.month > now.getMonth() + 2 ? now.getFullYear() - 1 : now.getFullYear());
  return { year, month };
}

async function findPeriod(companyId: string, year: number, month: number) {
  const [p] = await db
    .select()
    .from(schema.payrollPeriods)
    .where(and(eq(schema.payrollPeriods.companyId, companyId), eq(schema.payrollPeriods.year, year), eq(schema.payrollPeriods.month, month)))
    .limit(1);
  return p ?? null;
}

export async function findEmployees(companyId: string, query: string, limit = 5) {
  const parts = query.trim().split(/\s+/).filter(Boolean).slice(0, 3);
  if (!parts.length) return [];
  const conds = parts.map((p) => or(ilike(schema.employees.firstName, `%${p.replace(/[%_]/g, "")}%`), ilike(schema.employees.lastName, `%${p.replace(/[%_]/g, "")}%`)));
  return db
    .select({ id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName, jobTitle: schema.employees.jobTitle })
    .from(schema.employees)
    .where(and(eq(schema.employees.companyId, companyId), ...conds))
    .limit(limit);
}

const STEP_ORDER = ["open", "collecting", "checking", "computed", "controlled", "validated", "finalized", "exported", "distributed", "closed"];
const reached = (status: string | undefined, target: string) => (status ? STEP_ORDER.indexOf(status) >= STEP_ORDER.indexOf(target) : false);

// ---------- payrollStatus ----------

export async function payrollStatus(companyId: string, args: ToolArgs): Promise<ToolResult> {
  await ctxFor(companyId, "payrollStatus");
  const { year, month } = currentPeriod(args);
  const label = monthLabel(year, month);
  const period = await findPeriod(companyId, year, month);
  if (!period) {
    return {
      tool: "payrollStatus",
      title: `Paie ${deMonth(label)}`,
      summary: `La période de ${label} n'est pas encore ouverte.`,
      links: [{ label: "Ouvrir la paie", href: `/app/${companyId}/paie` }],
      followups: ["Prépare la paie de ce mois-ci."],
    };
  }
  const anomalies = await db
    .select({ severity: schema.payrollAnomalies.severity, n: sql<number>`count(*)::int` })
    .from(schema.payrollAnomalies)
    .where(and(eq(schema.payrollAnomalies.periodId, period.id), eq(schema.payrollAnomalies.status, "open")))
    .groupBy(schema.payrollAnomalies.severity);
  const slips = await db
    .select({ status: schema.payslips.status, n: sql<number>`count(*)::int` })
    .from(schema.payslips)
    .where(eq(schema.payslips.periodId, period.id))
    .groupBy(schema.payslips.status);
  const [pendingVars] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.payrollVariables)
    .where(and(eq(schema.payrollVariables.periodId, period.id), inArray(schema.payrollVariables.status, ["draft", "submitted"])));
  const count = (rows: { n: number }[]) => rows.reduce((s, r) => s + r.n, 0);
  const sev = (k: string) => anomalies.find((a) => a.severity === k)?.n ?? 0;
  const blockedSlips = slips.find((s) => s.status === "blocked")?.n ?? 0;
  return {
    tool: "payrollStatus",
    title: `Paie ${deMonth(label)}`,
    summary: `Statut de la période : ${STATUS_FR[period.status] ?? period.status}. ${count(slips)} bulletin(s) calculé(s), dont ${blockedSlips} bloqué(s).`,
    table: {
      columns: ["Indicateur", "Nombre"],
      numeric: [1],
      rows: [
        ["Anomalies bloquantes ouvertes", String(sev("blocking"))],
        ["Anomalies à vérifier", String(sev("warning"))],
        ["Variables en attente de validation", String(pendingVars?.n ?? 0)],
        ["Bulletins bloqués", String(blockedSlips)],
      ],
    },
    links: [{ label: "Ouvrir la période", href: `/app/${companyId}/paie` }],
    followups: sev("blocking") ? ["Quels éléments manquent avant validation ?"] : [],
  };
}

const STATUS_FR: Record<string, string> = {
  open: "ouverte",
  collecting: "collecte des éléments",
  checking: "vérification",
  computed: "calculée",
  controlled: "contrôlée",
  validated: "validée",
  finalized: "finalisée",
  exported: "exportée",
  distributed: "distribuée",
  closed: "clôturée",
};

// ---------- preparePayroll ----------

export async function preparePayroll(companyId: string, args: ToolArgs): Promise<ToolResult> {
  await ctxFor(companyId, "preparePayroll");
  const { year, month } = currentPeriod(args);
  const label = monthLabel(year, month);
  const period = await findPeriod(companyId, year, month);
  const s = period?.status;
  const steps: ToolResult["steps"] = [
    { label: "Ouvrir la période de paie", status: period ? "done" : "todo" },
    { label: "Collecter les variables (absences, temps, frais, primes)", status: reached(s, "checking") ? "done" : "todo" },
    { label: "Calculer les bulletins avec le moteur de paie", status: reached(s, "computed") ? "done" : "todo" },
    { label: "Contrôler les anomalies puis valider (étape humaine, dans la paie)", status: "info" },
  ];
  if (reached(s, "validated")) {
    return { tool: "preparePayroll", title: `Paie ${deMonth(label)}`, summary: `La paie ${deMonth(label)} est déjà ${STATUS_FR[s!]} : aucune préparation à relancer.`, steps, links: [{ label: "Voir la paie", href: `/app/${companyId}/paie` }] };
  }
  return {
    tool: "preparePayroll",
    title: `Préparer la paie de ${label}`,
    summary: "Voici le plan. Les calculs sont réalisés par le moteur de paie, jamais par l'assistant. Rien n'est lancé sans votre confirmation.",
    steps,
    confirm: { label: `Confirmer la préparation de ${label}`, tool: "preparePayroll", args: { year, month } },
  };
}

async function executePreparePayroll(ctx: CompanyContext, args: ToolArgs): Promise<ToolResult> {
  const { year, month } = currentPeriod(args);
  const label = monthLabel(year, month);
  const cycle = await loadPayrollCycle();
  if (!cycle) {
    return {
      tool: "preparePayroll",
      title: `Préparer la paie de ${label}`,
      summary: "Le moteur de cycle de paie n'est pas encore disponible sur cette installation : rien n'a été lancé. Utilisez l'écran Paie.",
      links: [{ label: "Ouvrir la paie", href: `/app/${ctx.company.id}/paie` }],
    };
  }
  const existing = await findPeriod(ctx.company.id, year, month);
  const periodId = existing?.id ?? (await cycle.openPeriod(ctx.company.id, year, month, ctx.user.id)).periodId;
  await cycle.collectVariables(periodId, ctx.user.id);
  const res = await cycle.computePeriod(periodId, ctx.user.id);
  await audit({ action: "assistant.prepare_payroll", userId: ctx.user.id, companyId: ctx.company.id, entityType: "payroll_period", entityId: periodId, after: res });
  return {
    tool: "preparePayroll",
    title: `Paie ${deMonth(label)} préparée`,
    summary: `Calcul effectué par le moteur de paie : ${res.computed} bulletin(s) calculé(s), ${res.blocked} bloqué(s), ${res.anomalies} anomalie(s) à examiner. La validation reste à faire dans l'écran Paie.`,
    steps: [
      { label: "Ouvrir la période de paie", status: "done" },
      { label: "Collecter les variables", status: "done" },
      { label: "Calculer les bulletins avec le moteur de paie", status: res.blocked ? "blocked" : "done" },
      { label: "Contrôler les anomalies puis valider", status: "todo" },
    ],
    links: [{ label: "Contrôler la paie", href: `/app/${ctx.company.id}/paie` }],
    followups: res.anomalies ? ["Quels éléments manquent avant validation ?"] : [],
  };
}

// ---------- explainVariance ----------

function describeVariance(v: unknown): string[] {
  if (!v || typeof v !== "object") return [];
  const out: string[] = [];
  const obj = v as Record<string, unknown>;
  for (const key of ["items", "lines", "explanations", "reasons", "details"]) {
    const arr = obj[key];
    if (Array.isArray(arr)) {
      for (const it of arr.slice(0, 12)) {
        if (typeof it === "string") out.push(it);
        else if (it && typeof it === "object") {
          const r = it as Record<string, unknown>;
          const lbl = String(r.label ?? r.title ?? r.code ?? "Élément");
          const delta = typeof r.deltaCents === "number" ? formatCents(r.deltaCents, { signed: true }) : typeof r.amountCents === "number" ? formatCents(r.amountCents, { signed: true }) : null;
          const why = r.explanation ?? r.reason ?? r.cause;
          out.push([lbl, delta, typeof why === "string" ? why : null].filter(Boolean).join(" : "));
        }
      }
    }
  }
  // Format du moteur de paie (src/server/payroll/variance.ts) : valeurs reprises telles quelles, jamais recalculées.
  if (obj.hasPrevious === true && typeof obj.grossDeltaCents === "number" && typeof obj.netPaidDeltaCents === "number") {
    const pct = (v: unknown) => (typeof v === "number" ? ` (${v.toLocaleString("fr-FR")} %)` : "");
    out.unshift(
      `Par rapport à ${typeof obj.previousPeriod === "string" ? obj.previousPeriod : "le mois précédent"} : brut ${formatCents(obj.grossDeltaCents, { signed: true })}${pct(obj.grossDeltaPct)}, net payé ${formatCents(obj.netPaidDeltaCents, { signed: true })}${pct(obj.netPaidDeltaPct)}`,
    );
  }
  if (typeof obj.summary === "string") out.unshift(obj.summary);
  if (typeof obj.explanation === "string") out.unshift(obj.explanation);
  if (!out.length) {
    for (const [k, val] of Object.entries(obj)) {
      if (typeof val === "number" && /cents$/i.test(k)) out.push(`${VAR_LABELS[k] ?? k} : ${formatCents(val, { signed: /delta|diff/i.test(k) })}`);
      else if (typeof val === "string") out.push(`${VAR_LABELS[k] ?? k} : ${val}`);
    }
  }
  return out;
}

const VAR_LABELS: Record<string, string> = {
  grossDeltaCents: "Écart de brut",
  netDeltaCents: "Écart de net payé",
  netPaidDeltaCents: "Écart de net payé",
  previousGrossCents: "Brut du mois précédent",
  previousNetPaidCents: "Net payé du mois précédent",
  employerCostDeltaCents: "Écart de coût employeur",
};

export async function explainVariance(companyId: string, args: ToolArgs): Promise<ToolResult> {
  await ctxFor(companyId, "explainVariance");
  // Période : celle demandée, sinon la plus récente ayant des bulletins.
  let period = args.month ? await findPeriod(companyId, currentPeriod(args).year, currentPeriod(args).month) : null;
  if (!period) {
    const [p] = await db
      .select({ p: schema.payrollPeriods })
      .from(schema.payrollPeriods)
      .innerJoin(schema.payslips, eq(schema.payslips.periodId, schema.payrollPeriods.id))
      .where(eq(schema.payrollPeriods.companyId, companyId))
      .orderBy(desc(schema.payrollPeriods.year), desc(schema.payrollPeriods.month))
      .limit(1);
    period = p?.p ?? null;
  }
  if (!period) return { tool: "explainVariance", title: "Écarts de bulletin", summary: "Aucun bulletin calculé pour le moment : il n'y a pas d'écart à expliquer." };
  const label = monthLabel(period.year, period.month);

  if (!args.employeeQuery) {
    const rows = await db
      .select({ e: { firstName: schema.employees.firstName, lastName: schema.employees.lastName }, variance: schema.payslips.variance })
      .from(schema.payslips)
      .innerJoin(schema.employees, eq(schema.employees.id, schema.payslips.employeeId))
      .where(and(eq(schema.payslips.periodId, period.id), eq(schema.employees.companyId, companyId), sql`${schema.payslips.variance} <> '{}'::jsonb`))
      .orderBy(asc(schema.employees.lastName))
      .limit(20);
    if (!rows.length) return { tool: "explainVariance", title: `Écarts de ${label}`, summary: `Aucun écart enregistré par le moteur de paie pour ${label}.` };
    return {
      tool: "explainVariance",
      title: `Écarts de ${label}`,
      summary: `${rows.length} bulletin(s) présentent un écart avec le mois précédent. Choisissez un salarié pour le détail.`,
      table: { columns: ["Salarié", "Écart relevé par le moteur"], rows: rows.map((r) => [`${r.e.firstName} ${r.e.lastName}`, describeVariance(r.variance)[0] ?? "Détail disponible"]) },
      followups: rows.slice(0, 4).map((r) => `Explique l'écart de ${r.e.firstName} ${r.e.lastName}.`),
    };
  }

  const matches = await findEmployees(companyId, args.employeeQuery);
  if (matches.length !== 1) {
    return {
      tool: "explainVariance",
      title: "Écart de bulletin",
      summary: matches.length ? "Plusieurs salariés correspondent : précisez lequel." : `Aucun salarié ne correspond à « ${args.employeeQuery} ».`,
      followups: matches.map((m) => `Explique l'écart de ${m.firstName} ${m.lastName}.`),
    };
  }
  const emp = matches[0];
  const [slip] = await db
    .select({ variance: schema.payslips.variance, grossCents: schema.payslips.grossCents, netPaidCents: schema.payslips.netPaidCents })
    .from(schema.payslips)
    .where(and(eq(schema.payslips.periodId, period.id), eq(schema.payslips.employeeId, emp.id)))
    .limit(1);
  if (!slip) return { tool: "explainVariance", title: `${emp.firstName} ${emp.lastName}`, summary: `Pas de bulletin calculé pour ${label}.` };
  const lines = describeVariance(slip.variance);
  return {
    tool: "explainVariance",
    title: `Écart de ${emp.firstName} ${emp.lastName}, ${label}`,
    summary: lines.length
      ? `Explication reprise du calcul du moteur de paie (aucun recalcul par l'assistant). Bulletin : brut ${formatCents(slip.grossCents)}, net payé ${formatCents(slip.netPaidCents)}.`
      : "Le moteur de paie n'a enregistré aucun écart pour ce bulletin.",
    table: lines.length ? { columns: ["Explication"], rows: lines.map((l) => [l]) } : undefined,
    links: [{ label: "Ouvrir la paie", href: `/app/${companyId}/paie` }],
  };
}

// ---------- draftDocument ----------

export async function draftDocument(companyId: string, args: ToolArgs): Promise<ToolResult> {
  const ctx = await ctxFor(companyId, "draftDocument");
  const code = args.templateCode ?? "attestation-employeur";
  const template = await getTemplate(companyId, code);
  if (!template) {
    return {
      tool: "draftDocument",
      title: "Préparer un document",
      summary: "Ce type de document n'existe pas dans l'atelier. Choisissez un modèle.",
      links: [{ label: "Ouvrir l'atelier", href: `/app/${companyId}/atelier` }],
    };
  }
  const meta = templateMeta(template);
  const steps: ToolResult["steps"] = [
    { label: `Type de document : ${template.title}`, status: "done" },
    { label: "Créer le brouillon dans l'atelier", status: "todo" },
    { label: "Répondre aux questions du modèle", status: "todo" },
    { label: "Compléter les éléments manquants, relire et faire valider", status: "todo" },
  ];
  if (template.isLegal) steps.push({ label: "À faire valider par un juriste ou un avocat avant signature", status: "info" });

  let employee: { id: string; firstName: string; lastName: string } | null = null;
  if (meta.needsEmployee) {
    if (!ctx.permissions.has("employees.read")) {
      return { tool: "draftDocument", title: template.title, summary: "Ce document concerne un salarié : l'habilitation à consulter les salariés est nécessaire.", steps };
    }
    const candidates = args.employeeQuery ? await findEmployees(companyId, args.employeeQuery) : [];
    if (candidates.length !== 1) {
      const sample = candidates.length
        ? candidates
        : await db
            .select({ id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName })
            .from(schema.employees)
            .where(and(eq(schema.employees.companyId, companyId), ne(schema.employees.status, "left")))
            .orderBy(asc(schema.employees.lastName))
            .limit(4);
      const kind = template.title.toLowerCase();
      return {
        tool: "draftDocument",
        title: template.title,
        summary: candidates.length ? "Plusieurs salariés correspondent : précisez lequel." : "Pour quel salarié ? Précisez son nom, ou choisissez-le directement dans l'atelier.",
        steps,
        followups: sample.map((s) => `Prépare ${kind.startsWith("a") || kind.startsWith("é") ? "l'" : "le "}${kind} pour ${s.firstName} ${s.lastName}.`),
        links: [{ label: "Choisir dans l'atelier", href: `/app/${companyId}/atelier/nouveau/${template.code}` }],
      };
    }
    employee = candidates[0];
  }
  return {
    tool: "draftDocument",
    title: employee ? `${template.title} pour ${employee.firstName} ${employee.lastName}` : template.title,
    summary: "Je peux créer le brouillon. Il n'utilisera que les informations auxquelles vous avez accès ; ce qui manque restera signalé par des marqueurs visibles.",
    steps,
    confirm: { label: "Confirmer la création du brouillon", tool: "draftDocument", args: { templateId: template.id, employeeId: employee?.id } },
  };
}

async function executeDraftDocument(ctx: CompanyContext, args: NonNullable<ToolResult["confirm"]>["args"]): Promise<ToolResult> {
  if (!args.templateId) throw new Error("Modèle manquant");
  const draft = await createDraft(ctx, { templateId: args.templateId, employeeId: args.employeeId ?? null });
  return {
    tool: "draftDocument",
    title: "Brouillon créé",
    summary: `Le brouillon « ${draft.title} » est prêt : répondez aux questions pour le générer.`,
    steps: [
      { label: "Créer le brouillon dans l'atelier", status: "done" },
      { label: "Répondre aux questions du modèle", status: "todo" },
    ],
    links: [{ label: "Ouvrir le brouillon", href: `/app/${ctx.company.id}/atelier/${draft.id}` }],
  };
}

// ---------- upcomingTrialPeriods ----------

export async function upcomingTrialPeriods(companyId: string, args: ToolArgs): Promise<ToolResult> {
  await ctxFor(companyId, "upcomingTrialPeriods");
  const days = args.days ?? 30;
  const today = new Date().toISOString().slice(0, 10);
  const until = new Date(Date.now() + days * 86400_000).toISOString().slice(0, 10);
  const end = sql<string>`coalesce(${schema.contracts.trialRenewedUntil}, ${schema.contracts.trialEndDate})`;
  const rows = await db
    .select({
      e: { id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName, jobTitle: schema.employees.jobTitle },
      type: schema.contracts.type,
      renewed: schema.contracts.trialRenewedUntil,
      end,
    })
    .from(schema.contracts)
    .innerJoin(schema.employees, eq(schema.employees.id, schema.contracts.employeeId))
    .where(and(eq(schema.employees.companyId, companyId), ne(schema.employees.status, "left"), between(end, today, until)))
    .orderBy(asc(end))
    .limit(50);
  if (!rows.length) return { tool: "upcomingTrialPeriods", title: "Périodes d'essai", summary: `Aucune période d'essai ne se termine dans les ${days} prochains jours.` };
  return {
    tool: "upcomingTrialPeriods",
    title: `Périodes d'essai se terminant d'ici ${days} jours`,
    summary: `${rows.length} période(s) d'essai arrivent à échéance. Une décision (confirmation, renouvellement si un accord de branche étendu le permet, ou rupture) doit être prise avant la date de fin.`,
    table: {
      columns: ["Salarié", "Poste", "Contrat", "Fin de l'essai"],
      rows: rows.map((r) => [`${r.e.firstName} ${r.e.lastName}`, r.e.jobTitle ?? "-", r.type, `${fmtDate(r.end)}${r.renewed ? " (renouvelée)" : ""}`]),
    },
    followups: rows.filter((r) => !r.renewed).slice(0, 2).map((r) => `Prépare le renouvellement de période d'essai pour ${r.e.firstName} ${r.e.lastName}.`),
    links: [{ label: "Voir les échéances", href: `/app/${companyId}/echeances` }],
  };
}

// ---------- missingItems ----------

export async function missingItems(companyId: string, args: ToolArgs): Promise<ToolResult> {
  const ctx = await ctxFor(companyId, "missingItems");
  const { year, month } = currentPeriod(args);
  const label = monthLabel(year, month);
  const period = await findPeriod(companyId, year, month);
  const rows: string[][] = [];
  if (period) {
    const blocking = await db
      .select({ a: schema.payrollAnomalies, e: { firstName: schema.employees.firstName, lastName: schema.employees.lastName } })
      .from(schema.payrollAnomalies)
      .leftJoin(schema.employees, eq(schema.employees.id, schema.payrollAnomalies.employeeId))
      .where(and(eq(schema.payrollAnomalies.periodId, period.id), eq(schema.payrollAnomalies.status, "open"), eq(schema.payrollAnomalies.severity, "blocking")))
      .limit(40);
    for (const b of blocking) {
      rows.push(["Anomalie bloquante", b.e?.firstName ? `${b.e.firstName} ${b.e.lastName}` : "Entreprise", maskAmounts(`${b.a.title}. ${b.a.explanation}`, ctx.permissions)]);
    }
  }
  if (ctx.permissions.has("employees.read")) {
    const active = and(eq(schema.employees.companyId, companyId), inArray(schema.employees.status, ["active", "draft"]));
    const noContract = await db
      .select({ firstName: schema.employees.firstName, lastName: schema.employees.lastName })
      .from(schema.employees)
      .where(and(active, notExists(db.select({ x: sql`1` }).from(schema.contracts).where(eq(schema.contracts.employeeId, schema.employees.id)))))
      .limit(30);
    const noComp = await db
      .select({ firstName: schema.employees.firstName, lastName: schema.employees.lastName })
      .from(schema.employees)
      .where(and(active, notExists(db.select({ x: sql`1` }).from(schema.compensations).where(and(eq(schema.compensations.employeeId, schema.employees.id), isNull(schema.compensations.endDate))))))
      .limit(30);
    const noBank = await db
      .select({ firstName: schema.employees.firstName, lastName: schema.employees.lastName })
      .from(schema.employees)
      .where(and(active, notExists(db.select({ x: sql`1` }).from(schema.employeeBankAccounts).where(eq(schema.employeeBankAccounts.employeeId, schema.employees.id)))))
      .limit(30);
    for (const e of noContract) rows.push(["Contrat manquant", `${e.firstName} ${e.lastName}`, "Aucun contrat enregistré dans la fiche."]);
    for (const e of noComp) rows.push(["Rémunération manquante", `${e.firstName} ${e.lastName}`, "Aucune rémunération en vigueur dans la fiche."]);
    for (const e of noBank) rows.push(["RIB manquant", `${e.firstName} ${e.lastName}`, "Coordonnées bancaires non renseignées (virement impossible)."]);
  }
  return {
    tool: "missingItems",
    title: `Éléments manquants avant validation, ${label}`,
    summary: rows.length
      ? `${rows.length} point(s) à régler avant de valider la paie.${period ? "" : ` La période de ${label} n'est pas encore ouverte : seules les fiches salariés ont été vérifiées.`}`
      : `Aucun élément bloquant relevé pour ${label}.${period ? "" : " La période n'est pas encore ouverte."}`,
    table: rows.length ? { columns: ["Type", "Concerné", "Détail"], rows } : undefined,
    links: [
      { label: "Ouvrir la paie", href: `/app/${companyId}/paie` },
      { label: "Voir les salariés", href: `/app/${companyId}/salaries` },
    ],
  };
}

// ---------- Exécution ----------

export const TOOLS: Record<ToolName, (companyId: string, args: ToolArgs) => Promise<ToolResult>> = {
  payrollStatus,
  preparePayroll,
  explainVariance,
  draftDocument,
  upcomingTrialPeriods,
  missingItems,
};

/** Exécute une action d'écriture après confirmation explicite de l'utilisateur (permissions revérifiées). */
export async function executeConfirmed(companyId: string, confirm: NonNullable<ToolResult["confirm"]>): Promise<ToolResult> {
  const ctx = await ctxFor(companyId, confirm.tool);
  if (confirm.tool === "preparePayroll") return executePreparePayroll(ctx, confirm.args);
  if (confirm.tool === "draftDocument") return executeDraftDocument(ctx, confirm.args);
  throw new Error(`Action non confirmable : ${TOOL_LABELS[confirm.tool]}`);
}

/** Description des outils pour Claude (tool use), limitée aux outils autorisés. */
export const TOOL_SCHEMAS: Record<ToolName, { description: string; input_schema: { type: "object"; properties: Record<string, unknown>; required?: string[] } }> = {
  payrollStatus: {
    description: "État de la période de paie d'un mois : statut, anomalies ouvertes, variables en attente, bulletins bloqués.",
    input_schema: { type: "object", properties: { month: { type: "integer", minimum: 1, maximum: 12 }, year: { type: "integer" } } },
  },
  preparePayroll: {
    description: "Propose le plan de préparation de la paie d'un mois (ouverture, collecte, calcul par le moteur). N'exécute rien : l'utilisateur confirme ensuite.",
    input_schema: { type: "object", properties: { month: { type: "integer", minimum: 1, maximum: 12 }, year: { type: "integer" } } },
  },
  explainVariance: {
    description: "Reformule l'écart calculé par le moteur de paie entre le bulletin d'un salarié et le mois précédent. Sans salarié, liste les bulletins avec écart.",
    input_schema: { type: "object", properties: { employeeQuery: { type: "string", description: "Nom du salarié" }, month: { type: "integer" }, year: { type: "integer" } } },
  },
  draftDocument: {
    description: `Propose la création d'un brouillon dans l'atelier de rédaction. Codes de modèles : ${TEMPLATES.map((t) => t.code).join(", ")}.`,
    input_schema: { type: "object", properties: { templateCode: { type: "string" }, employeeQuery: { type: "string" } }, required: ["templateCode"] },
  },
  upcomingTrialPeriods: {
    description: "Liste les périodes d'essai se terminant dans les prochains jours (30 par défaut).",
    input_schema: { type: "object", properties: { days: { type: "integer", minimum: 1, maximum: 180 } } },
  },
  missingItems: {
    description: "Liste les éléments bloquants avant validation : anomalies bloquantes, salariés sans contrat, sans rémunération ou sans RIB.",
    input_schema: { type: "object", properties: { month: { type: "integer" }, year: { type: "integer" } } },
  },
};
