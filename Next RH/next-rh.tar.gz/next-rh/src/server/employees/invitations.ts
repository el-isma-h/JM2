import "server-only";
import { and, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import type { requireCompany } from "@/server/authz";
import { audit } from "@/server/audit";
import { issueToken } from "@/server/auth";
import { layoutMail, sendMail } from "@/server/mail";
import { appUrl } from "@/lib/env";
import { randomToken, sha256 } from "@/lib/crypto";
import { roleLabels } from "@/components/employees/labels";

export type InviteCtx = Awaited<ReturnType<typeof requireCompany>>;

/** Crée (ou renouvelle) le jeton d'une invitation et envoie l'e-mail. Retourne le lien et l'état d'envoi. */
export async function issueInvitation(ctx: InviteCtx, invitation: typeof schema.invitations.$inferSelect) {
  await db
    .update(schema.oneTimeTokens)
    .set({ usedAt: new Date() })
    .where(and(eq(schema.oneTimeTokens.purpose, "invite"), sql`${schema.oneTimeTokens.payload}->>'invitationId' = ${invitation.id}`, sql`${schema.oneTimeTokens.usedAt} is null`));
  const ttl = 60 * 24 * 7;
  const token = await issueToken("invite", { email: invitation.email, payload: { invitationId: invitation.id }, ttlMinutes: ttl });
  await db
    .update(schema.invitations)
    .set({ tokenHash: sha256(token), expiresAt: new Date(Date.now() + ttl * 60_000), status: "pending" })
    .where(eq(schema.invitations.id, invitation.id));
  const link = `${appUrl()}/invitation/${token}`;
  const companyName = ctx.company.tradeName ?? ctx.company.legalName;
  const isEmployee = invitation.role === "employee";
  const res = await sendMail({
    to: invitation.email,
    subject: isEmployee ? `Votre espace salarié ${companyName}` : `Invitation à rejoindre ${companyName} sur Next RH`,
    html: layoutMail(
      isEmployee ? "Votre espace salarié" : "Vous êtes invité",
      isEmployee
        ? `<p>${ctx.user.firstName} ${ctx.user.lastName} vous ouvre l'accès à votre espace salarié ${companyName} : bulletins de paie, congés, notes de frais et documents.</p><p>Ce lien est valable 7 jours.</p>`
        : `<p>${ctx.user.firstName} ${ctx.user.lastName} vous invite à rejoindre ${companyName} avec le rôle « ${roleLabels[invitation.role] ?? invitation.role} ».</p><p>Ce lien est valable 7 jours.</p>`,
      { label: isEmployee ? "Activer mon espace" : "Accepter l'invitation", url: link },
    ),
    text: `Lien d'activation (7 jours) : ${link}`,
    isDemo: ctx.company.isDemo,
  });
  return { link, status: res.status };
}

/** Utilisé par les actions groupées des dossiers salariés : invitation à l'espace salarié. */
export async function inviteEmployeeInternal(ctx: InviteCtx, employee: { id: string; email: string }) {
  const [pending] = await db
    .select()
    .from(schema.invitations)
    .where(and(eq(schema.invitations.companyId, ctx.company.id), eq(schema.invitations.employeeId, employee.id), eq(schema.invitations.status, "pending")))
    .limit(1);
  const inv =
    pending ??
    (
      await db
        .insert(schema.invitations)
        .values({ tenantId: ctx.company.tenantId, companyId: ctx.company.id, email: employee.email.toLowerCase(), role: "employee", employeeId: employee.id, invitedBy: ctx.user.id, tokenHash: sha256(randomToken(32)), expiresAt: new Date(Date.now() + 7 * 86400_000) })
        .returning()
    )[0];
  const r = await issueInvitation(ctx, inv);
  await audit({ action: "invitation.create", userId: ctx.user.id, companyId: ctx.company.id, entityType: "invitation", entityId: inv.id, after: { email: inv.email, role: "employee", employeeId: employee.id, mail: r.status } });
  return r;
}
