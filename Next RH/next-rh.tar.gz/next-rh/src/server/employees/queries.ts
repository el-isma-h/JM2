import "server-only";
import { and, asc, desc, eq, inArray, lte, ne } from "drizzle-orm";
import { db, schema } from "@/db";
import { isoToday } from "@/lib/dates";

export type EmployeeFilters = {
  q?: string;
  status?: string;
  establishmentId?: string;
  contractType?: string;
  category?: string;
  anomaly?: string;
  sort?: string;
};

/**
 * Statuts datés : « sorti » quand la date de sortie est atteinte, « actif » quand la date d'entrée
 * d'un salarié créé à l'avance (statut brouillon) est atteinte.
 */
export async function syncLeavingStatuses(companyId: string) {
  const today = isoToday();
  await db
    .update(schema.employees)
    .set({ status: "left" })
    .where(and(eq(schema.employees.companyId, companyId), lte(schema.employees.leaveDate, today), ne(schema.employees.status, "left")));
  await db
    .update(schema.employees)
    .set({ status: "active" })
    .where(and(eq(schema.employees.companyId, companyId), eq(schema.employees.status, "draft"), lte(schema.employees.hireDate, today)));
}

export type Contract = typeof schema.contracts.$inferSelect;
export type Compensation = typeof schema.compensations.$inferSelect;

/** Contrat en cours à une date : le plus récent ayant commencé, sinon le prochain. */
export function pickCurrentContract(contracts: Contract[], at = isoToday()): Contract | null {
  const sorted = [...contracts].sort((a, b) => (a.startDate < b.startDate ? 1 : -1));
  return sorted.find((c) => c.startDate <= at) ?? sorted[sorted.length - 1] ?? null;
}

/** Rémunération en vigueur à une date (dernière date d'effet atteinte). */
export function pickCurrentCompensation(comps: Compensation[], at = isoToday()): Compensation | null {
  const sorted = [...comps].sort((a, b) => (a.effectiveDate < b.effectiveDate ? 1 : -1));
  return sorted.find((c) => c.effectiveDate <= at) ?? sorted[sorted.length - 1] ?? null;
}

export async function listEmployees(companyId: string, f: EmployeeFilters) {
  await syncLeavingStatuses(companyId);
  const employees = await db.select().from(schema.employees).where(eq(schema.employees.companyId, companyId)).orderBy(asc(schema.employees.lastName), asc(schema.employees.firstName));
  const ids = employees.map((e) => e.id);
  const [contracts, comps, banks, establishments] = await Promise.all([
    ids.length ? db.select().from(schema.contracts).where(inArray(schema.contracts.employeeId, ids)) : Promise.resolve([] as Contract[]),
    ids.length ? db.select().from(schema.compensations).where(inArray(schema.compensations.employeeId, ids)) : Promise.resolve([] as Compensation[]),
    ids.length ? db.selectDistinct({ id: schema.employeeBankAccounts.employeeId }).from(schema.employeeBankAccounts).where(inArray(schema.employeeBankAccounts.employeeId, ids)) : Promise.resolve([] as { id: string }[]),
    db.select().from(schema.establishments).where(eq(schema.establishments.companyId, companyId)).orderBy(desc(schema.establishments.isHeadOffice), asc(schema.establishments.name)),
  ]);
  const byEmp = <T extends { employeeId: string }>(rows: T[]) => {
    const m = new Map<string, T[]>();
    for (const r of rows) m.set(r.employeeId, [...(m.get(r.employeeId) ?? []), r]);
    return m;
  };
  const cMap = byEmp(contracts);
  const pMap = byEmp(comps);
  const bSet = new Set(banks.map((b) => b.id));
  const eMap = new Map(establishments.map((e) => [e.id, e]));

  let rows = employees.map((e) => {
    const contract = pickCurrentContract(cMap.get(e.id) ?? []);
    const comp = pickCurrentCompensation(pMap.get(e.id) ?? []);
    return {
      id: e.id,
      employeeNumber: e.employeeNumber,
      firstName: e.firstName,
      lastName: e.lastName,
      email: e.email,
      jobTitle: e.jobTitle,
      department: e.department,
      status: e.status,
      hireDate: e.hireDate,
      leaveDate: e.leaveDate,
      userId: e.userId,
      establishmentId: e.establishmentId,
      establishmentName: e.establishmentId ? eMap.get(e.establishmentId)?.name ?? null : null,
      contractType: contract?.type ?? null,
      category: contract?.category ?? null,
      grossCents: comp?.grossAmountCents ?? null,
      basis: comp?.basis ?? null,
      hasNir: Boolean(e.nirEnc),
      hasBank: bSet.has(e.id),
      hasContract: Boolean(contract),
      hasCompensation: Boolean(comp),
    };
  });

  const q = f.q?.trim().toLowerCase();
  if (q) rows = rows.filter((r) => [r.firstName, r.lastName, r.employeeNumber, r.email, r.jobTitle, r.department].some((x) => x?.toLowerCase().includes(q)));
  if (f.status && f.status !== "all") rows = rows.filter((r) => r.status === f.status);
  else if (!f.status) rows = rows.filter((r) => r.status !== "left");
  if (f.establishmentId) rows = rows.filter((r) => r.establishmentId === f.establishmentId);
  if (f.contractType) rows = rows.filter((r) => r.contractType === f.contractType);
  if (f.category) rows = rows.filter((r) => r.category === f.category);
  if (f.anomaly === "contrat") rows = rows.filter((r) => r.status === "active" && !r.hasContract);
  if (f.anomaly === "remuneration") rows = rows.filter((r) => r.status === "active" && !r.hasCompensation);
  if (f.anomaly === "nir") rows = rows.filter((r) => r.status === "active" && !r.hasNir);
  if (f.anomaly === "banque") rows = rows.filter((r) => r.status === "active" && !r.hasBank);

  const sort = f.sort ?? "nom";
  const cmp = (a: string | number | null, b: string | number | null) => (a === b ? 0 : a === null ? 1 : b === null ? -1 : a < b ? -1 : 1);
  const sorters: Record<string, (a: (typeof rows)[number], b: (typeof rows)[number]) => number> = {
    nom: (a, b) => cmp(a.lastName.toLowerCase(), b.lastName.toLowerCase()) || cmp(a.firstName.toLowerCase(), b.firstName.toLowerCase()),
    matricule: (a, b) => cmp(a.employeeNumber, b.employeeNumber),
    entree: (a, b) => cmp(b.hireDate, a.hireDate),
    salaire: (a, b) => cmp(b.grossCents, a.grossCents),
    poste: (a, b) => cmp(a.jobTitle, b.jobTitle),
  };
  rows.sort(sorters[sort] ?? sorters.nom);
  return { rows, establishments, total: employees.length };
}

export async function getEmployee(companyId: string, employeeId: string) {
  if (!/^[0-9a-f-]{36}$/.test(employeeId)) return null;
  const [e] = await db
    .select()
    .from(schema.employees)
    .where(and(eq(schema.employees.id, employeeId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  return e ?? null;
}

export async function getEmployeeDossier(companyId: string, employeeId: string) {
  await syncLeavingStatuses(companyId);
  const employee = await getEmployee(companyId, employeeId);
  if (!employee) return null;
  const [contracts, comps, banks, events, establishments] = await Promise.all([
    db.select().from(schema.contracts).where(eq(schema.contracts.employeeId, employeeId)).orderBy(desc(schema.contracts.startDate)),
    db.select().from(schema.compensations).where(eq(schema.compensations.employeeId, employeeId)).orderBy(desc(schema.compensations.effectiveDate), desc(schema.compensations.createdAt)),
    db
      .select({ id: schema.employeeBankAccounts.id, last4: schema.employeeBankAccounts.ibanLast4, bankName: schema.employeeBankAccounts.bankName, isPrimary: schema.employeeBankAccounts.isPrimary, validFrom: schema.employeeBankAccounts.validFrom })
      .from(schema.employeeBankAccounts)
      .where(eq(schema.employeeBankAccounts.employeeId, employeeId)),
    db.select().from(schema.employeeEvents).where(eq(schema.employeeEvents.employeeId, employeeId)).orderBy(desc(schema.employeeEvents.effectiveDate), desc(schema.employeeEvents.createdAt)),
    db.select().from(schema.establishments).where(eq(schema.establishments.companyId, companyId)).orderBy(desc(schema.establishments.isHeadOffice), asc(schema.establishments.name)),
  ]);
  const amendments = contracts.length
    ? await db.select().from(schema.amendments).where(inArray(schema.amendments.contractId, contracts.map((c) => c.id))).orderBy(desc(schema.amendments.effectiveDate))
    : [];
  return {
    employee,
    contracts,
    currentContract: pickCurrentContract(contracts),
    amendments,
    compensations: comps,
    currentCompensation: pickCurrentCompensation(comps),
    banks,
    events,
    establishments,
  };
}

/** Membres non salariés (gestionnaires), pour les choix « préparateur », « valideur », « manager ». */
export async function listManagers(companyId: string) {
  return db
    .select({ userId: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, email: schema.users.email, role: schema.companyMemberships.role })
    .from(schema.companyMemberships)
    .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
    .where(and(eq(schema.companyMemberships.companyId, companyId), ne(schema.companyMemberships.role, "employee")))
    .orderBy(asc(schema.users.lastName));
}
