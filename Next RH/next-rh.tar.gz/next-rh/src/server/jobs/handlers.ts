import "server-only";
import { and, asc, eq, gte, inArray, isNull, lt, lte } from "drizzle-orm";
import { addDays, format } from "date-fns";
import { db, schema } from "@/db";
import { appUrl } from "@/lib/env";
import { fmtDate } from "@/lib/dates";
import { layoutMail, sendMail } from "@/server/mail";
import { backupTenant } from "@/server/backup";
import { purgeTenant } from "@/server/backup/purge";

export type JobContext = { id: string; kind: string; payload: Record<string, unknown>; tenantId: string | null; companyId: string | null };
export type JobHandler = (job: JobContext) => Promise<Record<string, unknown> | void>;

const handlers = new Map<string, JobHandler>();

/** Point d'extension : une autre équipe peut déclarer un type de tâche (ex. « payroll:compute », « documents:pdf »). */
export function registerJobHandler(kind: string, handler: JobHandler) {
  handlers.set(kind, handler);
}
export function getJobHandler(kind: string): JobHandler | undefined {
  return handlers.get(kind);
}
export function knownJobKinds(): string[] {
  return [...handlers.keys()].sort();
}

/**
 * Point d'extension des rappels d'échéances : un module RH peut enregistrer une fonction qui recalcule
 * les échéances d'une entreprise (périodes d'essai, fins de CDD, visites médicales, habilitations…)
 * avant l'envoi du rappel. Exemple, dans le module concerné :
 *   registerDeadlinesSync(async (companyId) => syncDeadlines(companyId));
 */
type DeadlinesSync = (companyId: string) => Promise<void>;
const deadlineSyncs: DeadlinesSync[] = [];
export function registerDeadlinesSync(fn: DeadlinesSync) {
  deadlineSyncs.push(fn);
}

export const DEMO_TTL_HOURS = 24;

// ---------- demo:cleanup ----------
registerJobHandler("demo:cleanup", async (job) => {
  const hours = Number(job.payload.olderThanHours ?? DEMO_TTL_HOURS);
  const cutoff = new Date(Date.now() - hours * 3600_000);
  const stale = await db
    .select({ id: schema.tenants.id })
    .from(schema.tenants)
    .where(and(eq(schema.tenants.isDemo, true), lt(schema.tenants.createdAt, cutoff)));
  let users = 0;
  let files = 0;
  for (const t of stale) {
    const r = await purgeTenant(t.id);
    users += r.users;
    files += r.files;
  }
  return { tenantsDeleted: stale.length, usersDeleted: users, filesDeleted: files, cutoff: cutoff.toISOString() };
});

// ---------- backup:tenant ----------
registerJobHandler("backup:tenant", async (job) => {
  const tenantId = String(job.payload.tenantId ?? job.tenantId ?? "");
  if (!/^[0-9a-f-]{36}$/.test(tenantId)) throw new Error("Paramètre tenantId manquant.");
  const createdBy = typeof job.payload.userId === "string" ? job.payload.userId : null;
  const r = await backupTenant(tenantId, createdBy);
  return { backupId: r.backupId, sizeBytes: r.sizeBytes, sha256: r.sha256 };
});

// ---------- deadlines:remind ----------
registerJobHandler("deadlines:remind", async (job) => {
  const horizonDays = Number(job.payload.horizonDays ?? 14);
  const today = format(new Date(), "yyyy-MM-dd");
  const until = format(addDays(new Date(), horizonDays), "yyyy-MM-dd");
  const companies = await db
    .select({ id: schema.companies.id, name: schema.companies.legalName, tradeName: schema.companies.tradeName })
    .from(schema.companies)
    .where(and(eq(schema.companies.isDemo, false), job.companyId ? eq(schema.companies.id, job.companyId) : undefined));

  let mails = 0;
  let notConfigured = 0;
  for (const c of companies) {
    // EXTENSION : recalcul des échéances par les modules RH qui se sont enregistrés (registerDeadlinesSync).
    for (const sync of deadlineSyncs) await sync(c.id);

    const due = await db
      .select({ title: schema.deadlines.title, dueDate: schema.deadlines.dueDate })
      .from(schema.deadlines)
      .where(and(eq(schema.deadlines.companyId, c.id), eq(schema.deadlines.status, "upcoming"), gte(schema.deadlines.dueDate, today), lte(schema.deadlines.dueDate, until)))
      .orderBy(asc(schema.deadlines.dueDate));
    if (!due.length) continue;

    const recipients = await db
      .select({ email: schema.users.email, firstName: schema.users.firstName })
      .from(schema.companyMemberships)
      .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
      .where(and(eq(schema.companyMemberships.companyId, c.id), inArray(schema.companyMemberships.role, ["owner", "admin", "hr", "payroll"]), isNull(schema.users.disabledAt)));

    const list = due.map((d) => `<li>${fmtDate(d.dueDate)} : ${escapeHtml(d.title)}</li>`).join("");
    for (const r of recipients) {
      const res = await sendMail({
        to: r.email,
        subject: `Échéances des ${horizonDays} prochains jours : ${c.tradeName ?? c.name}`,
        html: layoutMail(`Échéances à venir`, `<p>Bonjour ${escapeHtml(r.firstName)},</p><p>Voici les échéances des ${horizonDays} prochains jours pour ${escapeHtml(c.tradeName ?? c.name)} :</p><ul>${list}</ul>`, {
          label: "Voir les échéances",
          url: `${appUrl()}/app/${c.id}/echeances`,
        }),
        text: due.map((d) => `${d.dueDate} : ${d.title}`).join("\n"),
        isDemo: false,
      });
      mails++;
      if (res.status === "skipped_not_configured") notConfigured++;
    }
  }
  return { companies: companies.length, mails, notConfigured, horizonDays };
});

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
