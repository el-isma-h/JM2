import { and, eq, isNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { TEMPLATES, VERIFIED_DATE, type TemplateSeed } from "./templates-data";

/**
 * Charge les modèles plateforme (company_id = null). Idempotent par `code` :
 * crée les modèles absents, met à jour ceux dont la version du seed est supérieure, ne touche pas aux autres.
 * Exécution : npx tsx --conditions=react-server -e "import('./src/server/documents/templates-seed.ts').then(m=>m.seedDocumentTemplates()).then(console.log)"
 */
export async function seedDocumentTemplates(): Promise<{ created: number; updated: number; unchanged: number }> {
  let created = 0;
  let updated = 0;
  let unchanged = 0;
  for (const t of TEMPLATES) {
    const values = toRow(t);
    const [existing] = await db
      .select({ id: schema.documentTemplates.id, version: schema.documentTemplates.version })
      .from(schema.documentTemplates)
      .where(and(eq(schema.documentTemplates.code, t.code), isNull(schema.documentTemplates.companyId)))
      .limit(1);
    if (!existing) {
      await db.insert(schema.documentTemplates).values(values);
      created++;
    } else if (existing.version < t.version) {
      await db.update(schema.documentTemplates).set(values).where(eq(schema.documentTemplates.id, existing.id));
      updated++;
    } else unchanged++;
  }
  return { created, updated, unchanged };
}

function toRow(t: TemplateSeed) {
  return {
    companyId: null,
    code: t.code,
    category: t.category,
    title: t.title,
    description: t.description,
    body: t.body,
    questions: t.questions,
    legalReviewPoints: t.legalReviewPoints,
    isLegal: t.isLegal,
    version: t.version,
    verifiedAt: t.verifiedNote ? new Date(`${VERIFIED_DATE}T12:00:00Z`) : null,
    verifiedNote: t.verifiedNote,
  };
}
