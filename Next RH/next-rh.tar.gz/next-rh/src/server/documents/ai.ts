import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import { integrations } from "@/lib/env";
import { lostElements, maskSensitive, unmask, UNTRUSTED_RULES, wrapUntrusted } from "./ai-guard";

export const DEFAULT_MODEL = "claude-sonnet-5-5";
export const aiModel = () => process.env.ANTHROPIC_MODEL || DEFAULT_MODEL;

export const AI_NOT_CONFIGURED =
  "Reformulation indisponible : la variable ANTHROPIC_API_KEY n'est pas définie (et ANTHROPIC_MODEL pour choisir le modèle). Le brouillon reste utilisable tel quel.";

export const AI_DATA_NOTICE =
  "Seul le texte du brouillon est transmis, après masquage des numéros de sécurité sociale, IBAN, e-mails et téléphones. Les données RH ne sont jamais utilisées pour entraîner un modèle.";

/**
 * Reformule un brouillon non juridique. Le modèle ne voit jamais les données masquées ; sa réponse est
 * rejetée si un marqueur [À COMPLÉTER : …] ou un jeton de masquage a disparu.
 */
export async function improveWording(input: { body: string; kind: string; canSeeSalaries: boolean }): Promise<{ ok: true; body: string } | { ok: false; error: string }> {
  if (!integrations.ai()) return { ok: false, error: AI_NOT_CONFIGURED };
  const masked = maskSensitive(input.body, { maskAmounts: !input.canSeeSalaries });
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const system = [
    "Tu améliores la rédaction de documents RH français non juridiques (courriers, réponses, fiches de poste, offres d'emploi, notes, procédures).",
    "Règles strictes : n'invente aucun fait, aucune date, aucun nom, aucun montant, aucune clause, aucune signature.",
    "Conserve à l'identique chaque marqueur de la forme [À COMPLÉTER : …] et chaque jeton de la forme ⟦TYPE_N⟧.",
    "Conserve la structure Markdown (titres #, listes « - », gras **). N'utilise jamais de tiret cadratin ni demi-cadratin.",
    "Réponds uniquement avec le document reformulé, sans commentaire.",
    UNTRUSTED_RULES,
  ].join("\n");
  try {
    const res = await client.messages.create({
      model: aiModel(),
      max_tokens: 4000,
      system,
      messages: [{ role: "user", content: `Type de document : ${input.kind}.\nReformule le document suivant.\n\n${wrapUntrusted("document", masked.text)}` }],
    });
    const text = res.content
      .filter((c): c is Anthropic.TextBlock => c.type === "text")
      .map((c) => c.text)
      .join("")
      .trim()
      .replace(/[—–]/g, ",");
    if (!text) return { ok: false, error: "Le service de rédaction n'a renvoyé aucun texte." };
    const lost = lostElements(masked.text, text);
    if (lost.length) return { ok: false, error: `Reformulation rejetée : elle supprimait ${lost.length} élément(s) à conserver (marqueurs ou données masquées). Le brouillon n'a pas été modifié.` };
    return { ok: true, body: `${unmask(text, masked.tokens)}\n` };
  } catch (e) {
    return { ok: false, error: `Le service de rédaction a échoué : ${e instanceof Error ? e.message : "erreur inconnue"}.` };
  }
}
