import "server-only";
import { and, desc, eq, gte, ilike, inArray, lt, ne, notInArray, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import type { CompanyContext } from "@/server/authz";
import { canSeeDocument, canSeeRestricted, RETENTION_YEARS, SALARY_CATEGORIES } from "./visibility";

export type DocFilters = { q?: string; category?: string; employeeId?: string; from?: string; to?: string };

/** Condition SQL de visibilité : appliquée dans chaque requête de la bibliothèque. */
export function visibilityCondition(ctx: CompanyContext): SQL | undefined {
  if (canSeeRestricted(ctx.permissions)) return undefined;
  return and(ne(schema.documents.visibility, "restricted"), notInArray(schema.documents.category, [...SALARY_CATEGORIES]));
}

const CATEGORIES = schema.documentCategoryEnum.enumValues;
type Category = (typeof CATEGORIES)[number];

export async function listDocuments(ctx: CompanyContext, f: DocFilters) {
  const conds: (SQL | undefined)[] = [eq(schema.documents.companyId, ctx.company.id), visibilityCondition(ctx)];
  // Seules les dernières versions sont listées ; les précédentes restent accessibles depuis la fiche.
  conds.push(sql`not exists (select 1 from documents d2 where d2.previous_version_id = ${schema.documents.id} and d2.company_id = ${ctx.company.id})`);
  if (f.q?.trim()) {
    const like = `%${f.q.trim().replace(/[%_]/g, "")}%`;
    conds.push(or(ilike(schema.documents.title, like), ilike(schema.documents.fileName, like), ilike(schema.employees.lastName, like), ilike(schema.employees.firstName, like)));
  }
  if (f.category && (CATEGORIES as readonly string[]).includes(f.category)) conds.push(eq(schema.documents.category, f.category as Category));
  if (f.employeeId && /^[0-9a-f-]{36}$/.test(f.employeeId)) conds.push(eq(schema.documents.employeeId, f.employeeId));
  if (f.from && /^\d{4}-\d{2}$/.test(f.from)) conds.push(gte(schema.documents.createdAt, new Date(`${f.from}-01T00:00:00Z`)));
  if (f.to && /^\d{4}-\d{2}$/.test(f.to)) {
    const [y, m] = f.to.split("-").map(Number);
    conds.push(lt(schema.documents.createdAt, new Date(Date.UTC(m === 12 ? y + 1 : y, m === 12 ? 0 : m, 1))));
  }
  return db
    .select({ d: schema.documents, e: { id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName } })
    .from(schema.documents)
    .leftJoin(schema.employees, eq(schema.employees.id, schema.documents.employeeId))
    .where(and(...conds))
    .orderBy(desc(schema.documents.createdAt))
    .limit(300);
}

/** Document + chaîne de versions, avec contrôle de visibilité. Renvoie null si non visible (pas de fuite d'existence). */
export async function getDocumentDetail(ctx: CompanyContext, documentId: string) {
  if (!/^[0-9a-f-]{36}$/.test(documentId)) return null;
  const [row] = await db
    .select({ d: schema.documents, e: { id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName } })
    .from(schema.documents)
    .leftJoin(schema.employees, eq(schema.employees.id, schema.documents.employeeId))
    .where(and(eq(schema.documents.id, documentId), eq(schema.documents.companyId, ctx.company.id)))
    .limit(1);
  if (!row || !canSeeDocument(row.d, ctx.permissions)) return null;

  // Versions précédentes (remontée de la chaîne) et suivantes.
  const chain: (typeof schema.documents.$inferSelect)[] = [row.d];
  let prevId = row.d.previousVersionId;
  for (let i = 0; prevId && i < 50; i++) {
    const [p] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, prevId), eq(schema.documents.companyId, ctx.company.id))).limit(1);
    if (!p) break;
    chain.push(p);
    prevId = p.previousVersionId;
  }
  let nextOf = row.d.id;
  for (let i = 0; i < 50; i++) {
    const [n] = await db.select().from(schema.documents).where(and(eq(schema.documents.previousVersionId, nextOf), eq(schema.documents.companyId, ctx.company.id))).limit(1);
    if (!n) break;
    chain.unshift(n);
    nextOf = n.id;
  }
  const ids = chain.map((c) => c.id);
  const access = await db
    .select({ a: schema.auditLogs, u: { firstName: schema.users.firstName, lastName: schema.users.lastName } })
    .from(schema.auditLogs)
    .leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId))
    .where(and(eq(schema.auditLogs.companyId, ctx.company.id), eq(schema.auditLogs.entityType, "document"), inArray(schema.auditLogs.entityId, ids)))
    .orderBy(desc(schema.auditLogs.createdAt))
    .limit(100);
  const signatures = await db.select().from(schema.signatureRequests).where(inArray(schema.signatureRequests.documentId, ids)).orderBy(desc(schema.signatureRequests.createdAt));
  const draft =
    row.d.sourceType === "document_draft" && row.d.sourceId
      ? ((await db.select({ id: schema.documentDrafts.id, title: schema.documentDrafts.title }).from(schema.documentDrafts).where(and(eq(schema.documentDrafts.id, row.d.sourceId), eq(schema.documentDrafts.companyId, ctx.company.id))).limit(1))[0] ?? null)
      : null;
  return { doc: row.d, employee: row.e?.id ? row.e : null, versions: chain, access, signatures, draft };
}

export function retentionLabel(doc: { category: string; retentionUntil: Date | null }) {
  const r = RETENTION_YEARS[doc.category];
  return { until: doc.retentionUntil, basis: r?.basis ?? "Durée indicative" };
}

export async function employeesForFilter(companyId: string) {
  return db
    .select({ id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName })
    .from(schema.employees)
    .where(eq(schema.employees.companyId, companyId))
    .orderBy(schema.employees.lastName, schema.employees.firstName);
}
