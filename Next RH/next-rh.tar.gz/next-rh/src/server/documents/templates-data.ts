/**
 * Modèles plateforme de l'atelier de rédaction (données pures, chargées par seedDocumentTemplates()).
 *
 * Règles de rédaction :
 * - aucune clause, signature, date ou donnée personnelle inventée : tout ce qui n'est pas connu reste un
 *   marqueur [À COMPLÉTER : …] produit par le moteur de rendu ;
 * - les modèles à enjeu juridique (isLegal) portent la liste des points à faire valider par un juriste ou
 *   un avocat et la note de vérification (références consultées le 2026-10-21) ;
 * - aucun tiret cadratin ni demi-cadratin.
 */

export type TemplateQuestion = {
  key: string;
  label: string;
  type: "text" | "textarea" | "date" | "select" | "number";
  required?: boolean;
  help?: string;
  options?: { value: string; label: string }[];
};

export type TemplateSeed = {
  code: string;
  category:
    | "contrat"
    | "avenant"
    | "attestation"
    | "courrier"
    | "fiche_poste"
    | "offre_emploi"
    | "convocation"
    | "compte_rendu"
    | "note_interne"
    | "procedure";
  /** Regroupement affiché à l'étape 1 de l'atelier. */
  group: "Contrats et avenants" | "Attestations" | "Arrivée et départ" | "Courriers et réponses" | "Recrutement" | "Entretiens" | "Organisation interne";
  title: string;
  description: string;
  body: string;
  questions: TemplateQuestion[];
  isLegal: boolean;
  legalReviewPoints: string[];
  verifiedNote: string | null;
  /** Reformulation par IA autorisée (parties non juridiques uniquement). */
  aiRewrite: boolean;
  /** Le document concerne un salarié précis. */
  needsEmployee: boolean;
  version: number;
};

export const VERIFIED_DATE = "2026-10-21";

const yesNo = [
  { value: "oui", label: "Oui" },
  { value: "non", label: "Non" },
];

const signatoryTitle: TemplateQuestion = {
  key: "signatoryTitle",
  label: "Qualité du signataire",
  type: "text",
  required: true,
  help: "Exemple : gérante, président, directrice des ressources humaines.",
};
const signatureDate: TemplateQuestion = {
  key: "signatureDate",
  label: "Date du document",
  type: "date",
  required: true,
  help: "Date à laquelle le document sera signé ou remis. Laissez vide si elle n'est pas encore connue : un marqueur restera visible.",
};

const SIGN_BLOCK = `Fait à {{company.city}}, le {{answers.signatureDate}}.

Pour {{company.legalName}}, {{signatory.fullName}}, {{answers.signatoryTitle}}

Signature :`;

const PARTIES = `**Entre :**

{{company.legalName}}, {{company.legalForm}}, SIREN {{company.siren}}, dont le siège est situé {{company.address}}, représentée par {{signatory.fullName}} en qualité de {{answers.signatoryTitle}}, ci-après « l'employeur »,

**et :**

{{employee.civility}} {{employee.firstName}} {{employee.lastName}}, né(e) le {{employee.birthDate}} à {{employee.birthPlace}}, de nationalité {{employee.nationality}}, demeurant {{employee.address}}, ci-après « le salarié ».`;

const TRIAL_BLOCK = `{{#if answers.trial == "oui"}}Le présent contrat ne deviendra définitif qu'à l'issue d'une période d'essai de {{answers.trialDuration}}, se terminant le {{contract.trialEndDate}}, au cours de laquelle chaque partie pourra y mettre fin en respectant le délai de prévenance prévu par le code du travail.
{{#if answers.trialRenewable == "oui"}}
Cette période d'essai pourra être renouvelée une fois, pour une durée de {{answers.trialRenewalDuration}}, dans les conditions prévues par l'accord de branche étendu applicable ({{answers.trialBranchAgreement}}), sous réserve de l'accord écrit des deux parties avant le terme de la période initiale.
{{/if}}{{/if}}{{#if answers.trial == "non"}}Le présent contrat ne comporte pas de période d'essai.{{/if}}{{#unless answers.trial}}{{answers.trial}}{{/unless}}`;

const trialQuestions: TemplateQuestion[] = [
  { key: "trial", label: "Période d'essai prévue", type: "select", required: true, options: yesNo, help: "La période d'essai ne se présume pas : elle doit être écrite dans le contrat." },
  { key: "trialDuration", label: "Durée de la période d'essai", type: "text", help: "Exemple : 2 mois. Plafonds légaux en CDI : 2 mois (employés, ouvriers), 3 mois (agents de maîtrise, techniciens), 4 mois (cadres), sauf durées conventionnelles plus courtes." },
  { key: "trialRenewable", label: "Renouvellement prévu", type: "select", options: yesNo, help: "Possible une seule fois et uniquement si un accord de branche étendu le prévoit." },
  { key: "trialRenewalDuration", label: "Durée du renouvellement", type: "text" },
  { key: "trialBranchAgreement", label: "Accord de branche étendu autorisant le renouvellement", type: "text", help: "Référence de l'accord (intitulé et date)." },
];

const workplace: TemplateQuestion = { key: "workplace", label: "Lieu de travail", type: "text", required: true, help: "Adresse du ou des lieux de travail." };
const missions: TemplateQuestion = { key: "missions", label: "Missions confiées", type: "textarea", required: true };
const paymentMethod: TemplateQuestion = {
  key: "paymentMethod",
  label: "Mode de versement du salaire",
  type: "select",
  required: true,
  options: [
    { value: "virement", label: "Virement" },
    { value: "chèque", label: "Chèque" },
  ],
};
const otherPay: TemplateQuestion = {
  key: "otherPay",
  label: "Autres éléments de rémunération",
  type: "textarea",
  help: "Primes, commissions, avantages, majorations. Laissez vide s'il n'y en a pas.",
};
const retirementAddress: TemplateQuestion = {
  key: "retirementFundAddress",
  label: "Adresse de la caisse de retraite complémentaire",
  type: "text",
  required: true,
};

export const TEMPLATES: TemplateSeed[] = [
  // ---------------- Contrats et avenants ----------------
  {
    code: "contrat-cdi",
    category: "contrat",
    group: "Contrats et avenants",
    title: "Contrat de travail à durée indéterminée",
    description: "CDI à temps plein ou partiel, avec les informations principales de la relation de travail.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [signatoryTitle, missions, workplace, ...trialQuestions, paymentMethod, otherPay, retirementAddress, signatureDate],
    legalReviewPoints: [
      "Durée de la période d'essai : conforme aux plafonds de l'article L1221-19 et à la convention collective applicable.",
      "Renouvellement de l'essai : uniquement si un accord de branche étendu le prévoit (art. L1221-21).",
      "Classification, coefficient et salaire : vérifier le minimum conventionnel de la classification retenue.",
      "Temps partiel : le contrat doit alors comporter des mentions spécifiques (répartition des horaires, heures complémentaires) non incluses dans ce modèle.",
      "Clauses particulières (non-concurrence, mobilité, exclusivité, dédit-formation) : non incluses, à rédiger par un juriste si nécessaire.",
      "Informations principales (art. R1221-34) : vérifier que celles qui ne figurent pas au contrat sont remises dans les délais (7 jours ou 1 mois).",
    ],
    verifiedNote:
      `Références vérifiées le ${VERIFIED_DATE} sur code.travail.gouv.fr (reprise de Légifrance) : art. L1221-3 (contrat écrit rédigé en français), ` +
      "L1221-19 (durées maximales de l'essai en CDI), L1221-21 (renouvellement unique si accord de branche étendu, 4, 6 ou 8 mois au total), " +
      "L1221-23 (l'essai doit être stipulé expressément), L1221-25 et L1221-26 (délais de prévenance), R1221-34 (14 informations principales de la relation de travail, en vigueur depuis le 1er novembre 2023).",
    body: `# Contrat de travail à durée indéterminée

${PARTIES}

Il a été convenu ce qui suit.

## Article 1 : Engagement

Le salarié est engagé pour une durée indéterminée à compter du {{contract.startDate}}. Le présent contrat est régi par le code du travail et par la convention collective {{company.collectiveAgreement}} (IDCC {{company.idcc}}).

## Article 2 : Poste et classification

Le salarié occupe le poste de {{contract.jobTitle}}, classification {{contract.classification}}, coefficient {{contract.coefficient}}, catégorie {{contract.categoryLabel}}.

Missions confiées : {{answers.missions}}

## Article 3 : Lieu de travail

{{answers.workplace}}

## Article 4 : Période d'essai

${TRIAL_BLOCK}

## Article 5 : Durée du travail

La durée du travail est de {{contract.weeklyHours}} heures par semaine ({{contract.workTimeLabel}}). Des heures supplémentaires ou complémentaires peuvent être demandées dans les conditions prévues par le code du travail et la convention collective.

## Article 6 : Rémunération

Le salarié perçoit une rémunération brute mensuelle de {{compensation.grossMonthly}} pour {{contract.monthlyHours}} heures mensuelles.
{{#if answers.otherPay}}
Autres éléments de rémunération : {{answers.otherPay}}
{{/if}}
La rémunération est versée mensuellement par {{answers.paymentMethod}}.

## Article 7 : Congés payés

Le salarié bénéficie des congés payés prévus par le code du travail et la convention collective applicable.

## Article 8 : Protection sociale

Caisse de retraite complémentaire : {{company.retirementFund}}, {{answers.retirementFundAddress}}.
{{#if company.providentFund}}
Organisme de prévoyance : {{company.providentFund}}.
{{/if}}{{#if company.healthFund}}
Complémentaire santé : {{company.healthFund}}.
{{/if}}

## Article 9 : Formation et fin du contrat

Le salarié bénéficie des droits à la formation assurés par l'employeur. En cas de rupture du contrat, les procédures et préavis prévus par le code du travail et la convention collective s'appliquent.

## Article 10 : Informations complémentaires

Les informations principales relatives à la relation de travail qui ne figurent pas au présent contrat sont remises au salarié dans les délais réglementaires.

${SIGN_BLOCK}

Signature du salarié :
`,
  },
  {
    code: "contrat-cdd",
    category: "contrat",
    group: "Contrats et avenants",
    title: "Contrat de travail à durée déterminée",
    description: "CDD avec toutes les mentions obligatoires de l'article L1242-12.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      signatoryTitle,
      {
        key: "cddReasonDetail",
        label: "Motif précis du recours au CDD",
        type: "textarea",
        required: true,
        help: "Le motif doit être précis (cas de recours de l'article L1242-2). À défaut, le contrat est réputé conclu à durée indéterminée.",
      },
      {
        key: "cddKind",
        label: "Type de terme",
        type: "select",
        required: true,
        options: [
          { value: "precis", label: "Terme précis (date de fin)" },
          { value: "imprecis", label: "Sans terme précis (durée minimale)" },
        ],
      },
      { key: "isReplacement", label: "Remplacement d'un salarié absent", type: "select", required: true, options: yesNo },
      { key: "replacedName", label: "Nom de la personne remplacée", type: "text" },
      { key: "replacedQualification", label: "Qualification de la personne remplacée", type: "text" },
      { key: "minimumDuration", label: "Durée minimale (terme imprécis)", type: "text" },
      { key: "renewalClause", label: "Clause de renouvellement", type: "textarea", help: "Conditions de renouvellement, le cas échéant. Laissez vide si aucune." },
      { key: "riskPost", label: "Le poste figure sur la liste des postes à risques", type: "select", required: true, options: yesNo, help: "Liste prévue à l'article L4154-2." },
      missions,
      workplace,
      { key: "trialDuration", label: "Durée de la période d'essai", type: "text", help: "Laissez vide si aucune période d'essai n'est prévue." },
      paymentMethod,
      otherPay,
      retirementAddress,
      signatureDate,
    ],
    legalReviewPoints: [
      "Motif de recours : doit correspondre à un cas autorisé et être précis ; un motif absent ou flou entraîne la requalification en CDI (art. L1242-12).",
      "Durée maximale et nombre de renouvellements : à vérifier selon le motif et la convention collective.",
      "Transmission : le contrat signé doit être remis au salarié dans les 2 jours ouvrables suivant l'embauche (art. L1242-13).",
      "Période d'essai : durée calculée selon la durée du contrat ou, sans terme précis, sa durée minimale (art. L1242-10).",
      "Poste à risques : vérifier la liste de l'article L4154-2 avant de répondre « non ».",
      "Indemnité de fin de contrat et délai de carence : à vérifier selon le motif.",
    ],
    verifiedNote:
      `Références vérifiées le ${VERIFIED_DATE} : art. L1242-12 (contrat écrit, motif précis à peine de requalification, 8 mentions obligatoires : personne remplacée, terme ou durée minimale, poste et liste des postes à risques, convention collective, période d'essai, rémunération et composantes, caisse de retraite complémentaire et prévoyance) sur code.travail.gouv.fr ; ` +
      "art. L1242-13 (transmission dans les 2 jours ouvrables) via Éditions Tissot ; art. L1242-10 (essai sans terme précis) via le précis ARTCENA.",
    body: `# Contrat de travail à durée déterminée

${PARTIES}

Il a été convenu ce qui suit.

## Article 1 : Motif du recours

Le présent contrat est conclu pour le motif suivant : {{answers.cddReasonDetail}}
{{#if answers.isReplacement == "oui"}}
Personne remplacée : {{answers.replacedName}}, qualification : {{answers.replacedQualification}}.
{{/if}}

## Article 2 : Durée

{{#if answers.cddKind == "precis"}}Le contrat prend effet le {{contract.startDate}} et se termine le {{contract.endDate}}.{{/if}}{{#if answers.cddKind == "imprecis"}}Le contrat prend effet le {{contract.startDate}} pour une durée minimale de {{answers.minimumDuration}}. Il prendra fin à la réalisation de son objet.{{/if}}{{#unless answers.cddKind}}{{answers.cddKind}}{{/unless}}
{{#if answers.renewalClause}}
Renouvellement : {{answers.renewalClause}}
{{/if}}

## Article 3 : Poste

Le salarié occupe l'emploi de {{contract.jobTitle}}, classification {{contract.classification}}, coefficient {{contract.coefficient}}. Missions : {{answers.missions}}

{{#if answers.riskPost == "oui"}}Ce poste figure sur la liste des postes présentant des risques particuliers pour la santé ou la sécurité prévue à l'article L4154-2 du code du travail.{{/if}}{{#if answers.riskPost == "non"}}Ce poste ne figure pas sur la liste des postes présentant des risques particuliers pour la santé ou la sécurité prévue à l'article L4154-2 du code du travail.{{/if}}{{#unless answers.riskPost}}{{answers.riskPost}}{{/unless}}

Lieu de travail : {{answers.workplace}}

## Article 4 : Convention collective

Convention collective applicable : {{company.collectiveAgreement}} (IDCC {{company.idcc}}).

## Article 5 : Période d'essai

{{#if answers.trialDuration}}Le contrat comporte une période d'essai de {{answers.trialDuration}}.{{else}}Le contrat ne comporte pas de période d'essai.{{/if}}

## Article 6 : Durée du travail et rémunération

La durée du travail est de {{contract.weeklyHours}} heures par semaine. Le salarié perçoit une rémunération brute mensuelle de {{compensation.grossMonthly}}.
{{#if answers.otherPay}}
Composantes et accessoires de salaire : {{answers.otherPay}}
{{/if}}
La rémunération est versée mensuellement par {{answers.paymentMethod}}.

## Article 7 : Retraite complémentaire et prévoyance

Caisse de retraite complémentaire : {{company.retirementFund}}, {{answers.retirementFundAddress}}.
{{#if company.providentFund}}
Organisme de prévoyance : {{company.providentFund}}.
{{/if}}

${SIGN_BLOCK}

Signature du salarié :
`,
  },
  {
    code: "avenant-contrat",
    category: "avenant",
    group: "Contrats et avenants",
    title: "Avenant au contrat de travail",
    description: "Modification d'un ou plusieurs éléments du contrat, acceptée par écrit par les deux parties.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      signatoryTitle,
      { key: "subject", label: "Objet de l'avenant", type: "text", required: true, help: "Exemple : passage à temps partiel, changement de poste." },
      { key: "effectiveDate", label: "Date d'effet", type: "date", required: true },
      { key: "changes", label: "Clauses modifiées et nouvelle rédaction", type: "textarea", required: true, help: "Indiquez l'article d'origine et sa nouvelle rédaction." },
      { key: "economicReason", label: "Modification pour motif économique", type: "select", required: true, options: yesNo, help: "Si oui, une procédure spécifique s'applique avant l'avenant (proposition par lettre recommandée, délai d'un mois)." },
      signatureDate,
    ],
    legalReviewPoints: [
      "Un élément essentiel du contrat (rémunération, durée du travail, qualification, lieu hors secteur) ne peut être modifié sans l'accord exprès du salarié.",
      "Motif économique : la proposition doit d'abord être faite par lettre recommandée avec avis de réception mentionnant le motif économique et le délai d'un mois pour refuser (art. L1222-6).",
      "Vérifier la cohérence de la nouvelle rédaction avec la convention collective (minimum conventionnel, classification).",
    ],
    verifiedNote:
      `Références vérifiées le ${VERIFIED_DATE} : art. L1222-6 (proposition de modification pour motif économique par LRAR, délai d'un mois, silence valant acceptation seulement si le motif économique est mentionné : Cass. soc. 8 novembre 2023, n° 22-11369), via Legisocial.`,
    body: `# Avenant au contrat de travail

${PARTIES}

Il a été convenu ce qui suit.

## Article 1 : Objet

Le présent avenant a pour objet : {{answers.subject}}.

## Article 2 : Modifications

À compter du {{answers.effectiveDate}}, les stipulations suivantes du contrat de travail sont modifiées :

{{answers.changes}}

## Article 3 : Autres stipulations

Les autres stipulations du contrat de travail demeurent inchangées.

${SIGN_BLOCK}

Signature du salarié :
`,
  },
  {
    code: "renouvellement-periode-essai",
    category: "avenant",
    group: "Contrats et avenants",
    title: "Accord de renouvellement de la période d'essai",
    description: "Accord écrit des deux parties, avant le terme de la période initiale.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      signatoryTitle,
      { key: "renewalDuration", label: "Durée du renouvellement", type: "text", required: true },
      { key: "newTrialEndDate", label: "Nouvelle date de fin de la période d'essai", type: "date", required: true },
      { key: "branchAgreement", label: "Accord de branche étendu autorisant le renouvellement", type: "text", required: true, help: "Intitulé et date de l'accord. Sans accord de branche étendu, le renouvellement est impossible." },
      signatureDate,
    ],
    legalReviewPoints: [
      "Le contrat de travail initial doit prévoir expressément la possibilité de renouvellement.",
      "Un accord de branche étendu doit autoriser le renouvellement et en fixer les conditions (art. L1221-21).",
      "Durée totale, renouvellement compris : 4 mois (employés, ouvriers), 6 mois (agents de maîtrise, techniciens), 8 mois (cadres) au maximum.",
      "L'accord du salarié doit être exprès et non équivoque, et intervenir avant la fin de la période initiale : une simple signature sur un courrier peut être jugée insuffisante.",
    ],
    verifiedNote:
      `Références vérifiées le ${VERIFIED_DATE} : art. L1221-21 (renouvellement unique, accord de branche étendu, plafonds de 4, 6 et 8 mois), L1221-23 (stipulation expresse) et exigence d'un accord exprès des deux parties (circulaire DGT 2009 et jurisprudence), via le précis ARTCENA.`,
    body: `# Accord de renouvellement de la période d'essai

${PARTIES}

Le contrat de travail conclu le {{contract.startDate}} prévoit une période d'essai prenant fin le {{contract.trialEndDate}} et la possibilité de son renouvellement.

En application de l'accord de branche étendu suivant : {{answers.branchAgreement}}, les parties conviennent de renouveler la période d'essai pour une durée de {{answers.renewalDuration}}. La période d'essai prendra fin le {{answers.newTrialEndDate}}.

Le salarié déclare donner son accord exprès à ce renouvellement.

${SIGN_BLOCK}

Signature du salarié, accompagnée de la mention manuscrite « Bon pour accord du renouvellement de la période d'essai » :
`,
  },

  // ---------------- Attestations ----------------
  {
    code: "attestation-employeur",
    category: "attestation",
    group: "Attestations",
    title: "Attestation employeur",
    description: "Attestation d'emploi destinée à un tiers (bailleur, banque, administration).",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      signatoryTitle,
      { key: "recipient", label: "Destinataire ou usage", type: "text", help: "Exemple : dossier de location. Laissez vide pour une attestation générale." },
      { key: "includeSalary", label: "Mentionner la rémunération", type: "select", required: true, options: yesNo, help: "Uniquement si le destinataire l'exige et si vous êtes habilité à consulter les salaires." },
      signatureDate,
    ],
    legalReviewPoints: [
      "Ne pas confondre avec l'attestation destinée à France Travail, établie par la DSN (signalement de fin de contrat) et non par ce modèle.",
      "Ne communiquer que les informations nécessaires à l'usage déclaré (minimisation des données personnelles).",
      "Une attestation inexacte engage la responsabilité de l'employeur et du signataire.",
    ],
    verifiedNote: `Vérifié le ${VERIFIED_DATE} : l'attestation employeur destinée à France Travail relève des articles R1234-9 à R1234-12 et se transmet par la DSN (francetravail.fr). Le présent modèle est une attestation d'emploi libre, sans formalisme légal propre.`,
    body: `# Attestation employeur

Je soussigné(e) {{signatory.fullName}}, {{answers.signatoryTitle}} de {{company.legalName}}, SIREN {{company.siren}}, dont le siège est situé {{company.address}},

atteste que {{employee.civility}} {{employee.firstName}} {{employee.lastName}} est employé(e) au sein de l'entreprise depuis le {{employee.hireDate}}, en qualité de {{contract.jobTitle}}, dans le cadre d'un {{contract.typeLabel}}.
{{#if answers.includeSalary == "oui"}}
Sa rémunération brute mensuelle est de {{compensation.grossMonthly}}.
{{/if}}{{#if answers.recipient}}
Cette attestation est établie à la demande de l'intéressé(e) pour servir auprès de : {{answers.recipient}}.
{{else}}
Cette attestation est établie à la demande de l'intéressé(e) pour servir et valoir ce que de droit.
{{/if}}

${SIGN_BLOCK}
`,
  },
  {
    code: "attestation-travail",
    category: "attestation",
    group: "Attestations",
    title: "Attestation de travail",
    description: "Attestation de présence dans l'effectif, sans rémunération.",
    isLegal: false,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [signatoryTitle, signatureDate],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `# Attestation de travail

Je soussigné(e) {{signatory.fullName}}, {{answers.signatoryTitle}} de {{company.legalName}}, atteste que {{employee.civility}} {{employee.firstName}} {{employee.lastName}} fait partie de l'effectif de l'entreprise depuis le {{employee.hireDate}} et y occupe actuellement le poste de {{contract.jobTitle}}.

Attestation établie à la demande de l'intéressé(e) pour servir et valoir ce que de droit.

${SIGN_BLOCK}
`,
  },
  {
    code: "attestation-salaire",
    category: "attestation",
    group: "Attestations",
    title: "Attestation de salaire",
    description: "Attestation de rémunération pour un tiers. Demande l'habilitation aux salaires.",
    isLegal: false,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      signatoryTitle,
      { key: "period", label: "Période concernée", type: "text", required: true, help: "Exemple : de janvier à juin 2026." },
      { key: "recipient", label: "Destinataire", type: "text", required: true },
      signatureDate,
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `# Attestation de salaire

Je soussigné(e) {{signatory.fullName}}, {{answers.signatoryTitle}} de {{company.legalName}}, atteste que {{employee.civility}} {{employee.firstName}} {{employee.lastName}}, employé(e) depuis le {{employee.hireDate}} en qualité de {{contract.jobTitle}}, perçoit une rémunération brute mensuelle de base de {{compensation.grossMonthly}} ({{compensation.basisLabel}}, en vigueur depuis le {{compensation.effectiveDate}}).

Période concernée : {{answers.period}}.

Attestation établie à la demande de l'intéressé(e) pour être remise à : {{answers.recipient}}. L'attestation de salaire destinée à l'Assurance maladie pour les indemnités journalières est transmise par la DSN et non par ce document.

${SIGN_BLOCK}
`,
  },

  // ---------------- Arrivée et départ ----------------
  {
    code: "certificat-travail",
    category: "attestation",
    group: "Arrivée et départ",
    title: "Certificat de travail",
    description: "Remis à la fin du contrat, avec exclusivement les mentions prévues par l'article D1234-6.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      signatoryTitle,
      {
        key: "jobsHistory",
        label: "Emplois successivement occupés et périodes",
        type: "textarea",
        help: "Une ligne par emploi : « - Poste, du 3 mars 2022 au 31 août 2024 ». Laissez vide si un seul emploi a été occupé : le poste du contrat sera repris.",
      },
      signatureDate,
    ],
    legalReviewPoints: [
      "Le certificat contient exclusivement : dates d'entrée et de sortie, nature du ou des emplois occupés et périodes correspondantes. N'ajoutez aucune appréciation ni motif de rupture.",
      "La date de sortie est celle de la fin du contrat, préavis inclus, qu'il soit effectué ou non.",
      "Il doit être remis au salarié à l'expiration du contrat, quel que soit le motif (art. L1234-19).",
    ],
    verifiedNote: `Références vérifiées le ${VERIFIED_DATE} sur code.travail.gouv.fr : art. L1234-19 (remise à l'expiration du contrat, contenu fixé par voie réglementaire) et D1234-6 (version à jour du 1er janvier 2015 : mentions exclusives, dates d'entrée et de sortie, nature des emplois et périodes ; 3° et 4° abrogés).`,
    body: `# Certificat de travail

Je soussigné(e) {{signatory.fullName}}, {{answers.signatoryTitle}} de {{company.legalName}}, SIREN {{company.siren}}, dont le siège est situé {{company.address}}, certifie avoir employé :

{{employee.civility}} {{employee.firstName}} {{employee.lastName}}

du {{employee.hireDate}} au {{employee.leaveDate}},

{{#if answers.jobsHistory}}en qualité de :

{{answers.jobsHistory}}{{else}}en qualité de {{contract.jobTitle}}, du {{employee.hireDate}} au {{employee.leaveDate}}.{{/if}}

${SIGN_BLOCK}
`,
  },
  {
    code: "recu-solde-tout-compte",
    category: "attestation",
    group: "Arrivée et départ",
    title: "Reçu pour solde de tout compte (en préparation)",
    description: "Inventaire des sommes versées à la rupture, à établir à partir du bulletin de sortie calculé.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      signatoryTitle,
      {
        key: "amountsInventory",
        label: "Inventaire des sommes versées",
        type: "textarea",
        required: true,
        help: "Reprenez les montants du bulletin de sortie calculé par le moteur de paie (salaire, indemnité compensatrice de congés payés, indemnités de rupture). Une ligne par somme.",
      },
      { key: "paymentDate", label: "Date de versement", type: "date", required: true },
      signatureDate,
    ],
    legalReviewPoints: [
      "Les montants doivent provenir du bulletin de sortie validé : ce modèle ne calcule aucune somme.",
      "Le reçu peut être dénoncé dans les 6 mois suivant sa signature ; passé ce délai, il n'est libératoire que pour les sommes qui y sont mentionnées (art. L1234-20).",
      "Établi en double exemplaire, dont un remis au salarié.",
      "Ne jamais faire signer un reçu comportant des marqueurs à compléter.",
    ],
    verifiedNote: `Références vérifiées le ${VERIFIED_DATE} : art. L1234-20 (inventaire des sommes versées lors de la rupture, dénonciation dans les 6 mois, effet libératoire limité aux sommes mentionnées) et double exemplaire, via la fiche Legisocial « Reçu pour solde de tout compte ».`,
    body: `# Reçu pour solde de tout compte

Je soussigné(e) {{employee.civility}} {{employee.firstName}} {{employee.lastName}}, employé(e) par {{company.legalName}} du {{employee.hireDate}} au {{employee.leaveDate}} en qualité de {{contract.jobTitle}},

reconnais avoir reçu de {{company.legalName}}, le {{answers.paymentDate}}, pour solde de tout compte, les sommes suivantes :

{{answers.amountsInventory}}

Ce reçu peut être dénoncé dans les six mois qui suivent sa signature, délai au-delà duquel il devient libératoire pour l'employeur pour les sommes qui y sont mentionnées.

Établi en double exemplaire, dont un m'a été remis.

Fait à {{company.city}}, le {{answers.signatureDate}}.

Signature du salarié :

Pour {{company.legalName}}, {{signatory.fullName}}, {{answers.signatoryTitle}}
`,
  },
  {
    code: "attestation-france-travail-preparation",
    category: "attestation",
    group: "Arrivée et départ",
    title: "Attestation France Travail (en préparation)",
    description: "Fiche de contrôle des éléments de fin de contrat. L'attestation officielle se fait via le service dédié.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      { key: "endReason", label: "Motif de la rupture", type: "text", required: true },
      { key: "lastDayWorked", label: "Dernier jour travaillé et payé", type: "date", required: true },
      { key: "noticeInfo", label: "Préavis (effectué, payé non effectué, dispense)", type: "text", required: true },
    ],
    legalReviewPoints: [
      "Ce document n'est pas l'attestation officielle : celle-ci est établie par le signalement de fin de contrat de travail dans la DSN (net-entreprises), ou en mode secours dans l'espace employeur francetravail.fr.",
      "Une version signée de l'attestation doit être remise au salarié en parallèle de sa transmission à France Travail.",
      "Le motif de rupture déclaré conditionne les droits du salarié : à vérifier avec le dossier de rupture.",
    ],
    verifiedNote: `Vérifié le ${VERIFIED_DATE} sur francetravail.fr (« L'attestation employeur destinée à France Travail ») : transmission par le signalement de fin de contrat en DSN, mode secours en ligne, remise d'une version signée au salarié, obligations des articles R1234-9 à R1234-12, amende jusqu'à 1 500 € en cas de manquement.`,
    body: `# Préparation de l'attestation France Travail

**Document interne de contrôle. L'attestation officielle se fait via le service dédié : signalement de fin de contrat dans la DSN, ou espace employeur francetravail.fr en cas d'impossibilité technique.**

## Salarié

{{employee.firstName}} {{employee.lastName}}, matricule {{employee.employeeNumber}}, entré(e) le {{employee.hireDate}}, sortie le {{employee.leaveDate}}.

Poste : {{contract.jobTitle}}, {{contract.typeLabel}}.

## Rupture

- Motif : {{answers.endReason}}
- Dernier jour travaillé et payé : {{answers.lastDayWorked}}
- Préavis : {{answers.noticeInfo}}

## À faire

- Vérifier que le bulletin de sortie est validé.
- Déclarer la fin de contrat dans la DSN.
- Remettre au salarié une version signée de l'attestation.
`,
  },

  // ---------------- Courriers et réponses ----------------
  {
    code: "courrier-administratif",
    category: "courrier",
    group: "Courriers et réponses",
    title: "Courrier administratif",
    description: "Courrier à un salarié ou à un organisme, rédigé à partir de vos éléments.",
    isLegal: false,
    aiRewrite: true,
    needsEmployee: false,
    version: 1,
    questions: [
      signatoryTitle,
      { key: "recipientName", label: "Destinataire", type: "text", required: true },
      { key: "recipientAddress", label: "Adresse du destinataire", type: "textarea" },
      { key: "subject", label: "Objet", type: "text", required: true },
      { key: "content", label: "Contenu du courrier", type: "textarea", required: true, help: "Les faits et demandes à exposer. La reformulation éventuelle ne rajoutera aucune information." },
      signatureDate,
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `{{company.legalName}}
{{company.address}}

{{answers.recipientName}}
{{#if answers.recipientAddress}}{{answers.recipientAddress}}{{/if}}

{{company.city}}, le {{answers.signatureDate}}

**Objet : {{answers.subject}}**

Madame, Monsieur,

{{answers.content}}

Nous vous prions d'agréer, Madame, Monsieur, l'expression de nos salutations distinguées.

{{signatory.fullName}}, {{answers.signatoryTitle}}
`,
  },
  {
    code: "reponse-salarie",
    category: "courrier",
    group: "Courriers et réponses",
    title: "Réponse à un salarié",
    description: "Réponse écrite à une question ou une demande d'un salarié.",
    isLegal: false,
    aiRewrite: true,
    needsEmployee: true,
    version: 1,
    questions: [
      { key: "question", label: "Question ou demande du salarié", type: "textarea", required: true, help: "Copiez la demande. Elle est traitée comme une donnée, jamais comme une consigne." },
      { key: "answer", label: "Éléments de réponse", type: "textarea", required: true },
      signatoryTitle,
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `Bonjour {{employee.firstName}},

Vous nous avez fait part de la demande suivante :

{{answers.question}}

Voici notre réponse :

{{answers.answer}}

Nous restons à votre disposition pour toute précision.

{{signatory.fullName}}, {{answers.signatoryTitle}}
{{company.legalName}}
`,
  },

  // ---------------- Recrutement ----------------
  {
    code: "fiche-poste",
    category: "fiche_poste",
    group: "Recrutement",
    title: "Fiche de poste",
    description: "Missions, rattachement, compétences attendues et conditions d'exercice.",
    isLegal: false,
    aiRewrite: true,
    needsEmployee: false,
    version: 1,
    questions: [
      { key: "jobTitle", label: "Intitulé du poste", type: "text", required: true },
      { key: "department", label: "Service", type: "text", required: true },
      { key: "reportsTo", label: "Rattachement hiérarchique", type: "text", required: true },
      { key: "missions", label: "Missions principales", type: "textarea", required: true, help: "Une mission par ligne, précédée d'un tiret." },
      { key: "skills", label: "Compétences attendues", type: "textarea", required: true },
      { key: "conditions", label: "Conditions d'exercice", type: "textarea", help: "Horaires, déplacements, télétravail." },
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `# Fiche de poste : {{answers.jobTitle}}

**Entreprise :** {{company.legalName}}
**Service :** {{answers.department}}
**Rattachement :** {{answers.reportsTo}}

## Missions principales

{{answers.missions}}

## Compétences attendues

{{answers.skills}}
{{#if answers.conditions}}
## Conditions d'exercice

{{answers.conditions}}
{{/if}}
`,
  },
  {
    code: "offre-emploi",
    category: "offre_emploi",
    group: "Recrutement",
    title: "Offre d'emploi",
    description: "Annonce de recrutement rédigée en français, sans critère discriminatoire.",
    isLegal: false,
    aiRewrite: true,
    needsEmployee: false,
    version: 1,
    questions: [
      { key: "jobTitle", label: "Intitulé du poste", type: "text", required: true },
      { key: "contractType", label: "Type de contrat", type: "text", required: true, help: "Exemple : CDI à temps plein." },
      { key: "location", label: "Lieu", type: "text", required: true },
      { key: "missions", label: "Missions", type: "textarea", required: true },
      { key: "profile", label: "Profil recherché", type: "textarea", required: true, help: "Compétences et expérience. Aucun critère lié à l'âge, au sexe, à l'origine, à la situation de famille ou à tout autre motif discriminatoire." },
      { key: "salaryRange", label: "Rémunération proposée", type: "text", help: "Fourchette ou montant. Laissez vide pour ne pas l'afficher." },
      { key: "applyHow", label: "Comment postuler", type: "text", required: true },
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `# {{answers.jobTitle}}

**{{company.legalName}}**, {{answers.location}}. {{answers.contractType}}.

## Missions

{{answers.missions}}

## Profil recherché

{{answers.profile}}
{{#if answers.salaryRange}}
## Rémunération

{{answers.salaryRange}}
{{/if}}
## Candidature

{{answers.applyHow}}
`,
  },

  // ---------------- Entretiens ----------------
  {
    code: "convocation-entretien-prealable",
    category: "convocation",
    group: "Entretiens",
    title: "Convocation à un entretien préalable",
    description: "Entretien préalable à une éventuelle sanction ou à un éventuel licenciement.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      signatoryTitle,
      {
        key: "measure",
        label: "Mesure envisagée",
        type: "select",
        required: true,
        options: [
          { value: "licenciement", label: "Éventuel licenciement" },
          { value: "sanction", label: "Éventuelle sanction disciplinaire" },
        ],
      },
      { key: "interviewDate", label: "Date de l'entretien", type: "date", required: true, help: "Au moins 5 jours ouvrables après la présentation de la lettre ou sa remise en main propre." },
      { key: "interviewTime", label: "Heure de l'entretien", type: "text", required: true },
      { key: "interviewPlace", label: "Lieu de l'entretien", type: "text", required: true },
      { key: "hasStaffRepresentatives", label: "L'entreprise dispose de représentants du personnel", type: "select", required: true, options: yesNo },
      { key: "advisorListAddresses", label: "Adresses où la liste des conseillers du salarié est consultable", type: "textarea", help: "Inspection du travail et mairie compétentes. À renseigner si l'entreprise n'a pas de représentants du personnel." },
      {
        key: "delivery",
        label: "Mode de remise",
        type: "select",
        required: true,
        options: [
          { value: "recommandé", label: "Lettre recommandée" },
          { value: "main propre", label: "Remise en main propre contre décharge" },
        ],
      },
      signatureDate,
    ],
    legalReviewPoints: [
      "Délai : l'entretien ne peut avoir lieu moins de 5 jours ouvrables après la présentation de la lettre recommandée ou la remise en main propre (art. L1232-2).",
      "Sans représentants du personnel, la lettre doit indiquer la possibilité d'être assisté par un conseiller du salarié et, selon la jurisprudence, les adresses où la liste des conseillers est consultable.",
      "Ne pas exposer les griefs de manière définitive : la lettre indique l'objet, la décision n'est pas prise.",
      "Mise à pied conservatoire éventuelle : non incluse, à rédiger séparément avec un juriste.",
      "Salarié protégé ou procédure conventionnelle spécifique : vérifier avant tout envoi.",
    ],
    verifiedNote:
      `Références vérifiées le ${VERIFIED_DATE} sur code.travail.gouv.fr : art. L1232-2 (convocation par lettre recommandée ou remise en main propre contre décharge, objet indiqué, délai de 5 jours ouvrables) et R1232-1 (objet, date, heure et lieu, rappel de la possibilité d'assistance par une personne de l'entreprise ou, sans représentants du personnel, par un conseiller du salarié).`,
    body: `{{company.legalName}}
{{company.address}}

{{employee.civility}} {{employee.firstName}} {{employee.lastName}}
{{employee.address}}

{{company.city}}, le {{answers.signatureDate}}

{{#if answers.delivery == "recommandé"}}Lettre recommandée avec avis de réception{{/if}}{{#if answers.delivery == "main propre"}}Lettre remise en main propre contre décharge{{/if}}{{#unless answers.delivery}}{{answers.delivery}}{{/unless}}

**Objet : convocation à un entretien préalable à {{#if answers.measure == "licenciement"}}un éventuel licenciement{{/if}}{{#if answers.measure == "sanction"}}une éventuelle sanction disciplinaire{{/if}}{{#unless answers.measure}}{{answers.measure}}{{/unless}}**

{{employee.civility}} {{employee.lastName}},

Nous envisageons à votre égard {{#if answers.measure == "licenciement"}}une mesure de licenciement{{/if}}{{#if answers.measure == "sanction"}}une sanction disciplinaire{{/if}}{{#unless answers.measure}}{{answers.measure}}{{/unless}}. Avant de prendre une décision, nous vous convoquons à un entretien préalable qui se tiendra le {{answers.interviewDate}} à {{answers.interviewTime}}, à l'adresse suivante : {{answers.interviewPlace}}.

Au cours de cet entretien, nous vous exposerons les motifs de la mesure envisagée et recueillerons vos explications.

{{#if answers.hasStaffRepresentatives == "oui"}}Vous pouvez vous faire assister lors de cet entretien par une personne de votre choix appartenant au personnel de l'entreprise.{{/if}}{{#if answers.hasStaffRepresentatives == "non"}}Vous pouvez vous faire assister lors de cet entretien par une personne de votre choix appartenant au personnel de l'entreprise ou par un conseiller du salarié. La liste des conseillers du salarié est consultable aux adresses suivantes : {{answers.advisorListAddresses}}{{/if}}{{#unless answers.hasStaffRepresentatives}}{{answers.hasStaffRepresentatives}}{{/unless}}

Veuillez agréer, {{employee.civility}} {{employee.lastName}}, l'expression de nos salutations distinguées.

{{signatory.fullName}}, {{answers.signatoryTitle}}
`,
  },
  {
    code: "compte-rendu-entretien-prealable",
    category: "compte_rendu",
    group: "Entretiens",
    title: "Compte rendu d'entretien préalable",
    description: "Trace factuelle de l'entretien : présents, motifs exposés, explications du salarié.",
    isLegal: true,
    aiRewrite: false,
    needsEmployee: true,
    version: 1,
    questions: [
      { key: "interviewDate", label: "Date de l'entretien", type: "date", required: true },
      { key: "attendees", label: "Personnes présentes", type: "textarea", required: true, help: "Y compris la personne qui assiste le salarié, le cas échéant." },
      { key: "reasonsExposed", label: "Motifs exposés par l'employeur", type: "textarea", required: true },
      { key: "employeeExplanations", label: "Explications du salarié", type: "textarea", required: true, help: "Retranscrivez fidèlement, sans interprétation." },
    ],
    legalReviewPoints: [
      "Le compte rendu doit rester factuel et fidèle : il peut être produit en justice.",
      "Délai minimal entre l'entretien et la notification de la décision : à vérifier selon la mesure (licenciement ou sanction).",
      "Aucune décision ne doit figurer dans ce compte rendu.",
    ],
    verifiedNote: `Vérifié le ${VERIFIED_DATE} : aucun texte n'impose de compte rendu ; document interne de preuve. Procédure de convocation : art. L1232-2 et R1232-1 (code.travail.gouv.fr).`,
    body: `# Compte rendu d'entretien préalable

**Salarié :** {{employee.firstName}} {{employee.lastName}}, {{employee.jobTitle}}
**Date de l'entretien :** {{answers.interviewDate}}

## Personnes présentes

{{answers.attendees}}

## Motifs exposés

{{answers.reasonsExposed}}

## Explications du salarié

{{answers.employeeExplanations}}
`,
  },
  {
    code: "convocation-entretien-annuel",
    category: "convocation",
    group: "Entretiens",
    title: "Convocation à l'entretien annuel",
    description: "Invitation à l'entretien annuel d'évaluation.",
    isLegal: false,
    aiRewrite: true,
    needsEmployee: true,
    version: 1,
    questions: [
      { key: "interviewDate", label: "Date de l'entretien", type: "date", required: true },
      { key: "interviewTime", label: "Heure", type: "text", required: true },
      { key: "interviewPlace", label: "Lieu ou lien de visioconférence", type: "text", required: true },
      { key: "interviewer", label: "Personne qui conduit l'entretien", type: "text", required: true },
      { key: "preparation", label: "Éléments à préparer", type: "textarea" },
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `Bonjour {{employee.firstName}},

Votre entretien annuel aura lieu le {{answers.interviewDate}} à {{answers.interviewTime}} ({{answers.interviewPlace}}), avec {{answers.interviewer}}.

Cet entretien est l'occasion de faire le point sur l'année écoulée, vos objectifs et vos besoins. Il est distinct de l'entretien de parcours professionnel, consacré à vos perspectives d'évolution et de formation.
{{#if answers.preparation}}
Pour le préparer : {{answers.preparation}}
{{/if}}
Bien cordialement,

{{signatory.fullName}}
{{company.legalName}}
`,
  },
  {
    code: "compte-rendu-entretien-annuel",
    category: "compte_rendu",
    group: "Entretiens",
    title: "Compte rendu d'entretien annuel",
    description: "Bilan de l'année, objectifs et commentaires des deux parties.",
    isLegal: false,
    aiRewrite: true,
    needsEmployee: true,
    version: 1,
    questions: [
      { key: "interviewDate", label: "Date de l'entretien", type: "date", required: true },
      { key: "interviewer", label: "Personne qui a conduit l'entretien", type: "text", required: true },
      { key: "review", label: "Bilan de l'année", type: "textarea", required: true },
      { key: "objectives", label: "Objectifs pour l'année à venir", type: "textarea", required: true },
      { key: "employeeComments", label: "Commentaires du salarié", type: "textarea" },
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `# Compte rendu d'entretien annuel

**Salarié :** {{employee.firstName}} {{employee.lastName}}, {{employee.jobTitle}}
**Date :** {{answers.interviewDate}}
**Conduit par :** {{answers.interviewer}}

## Bilan de l'année

{{answers.review}}

## Objectifs

{{answers.objectives}}

## Commentaires du salarié

{{#if answers.employeeComments}}{{answers.employeeComments}}{{else}}Aucun commentaire.{{/if}}

Signature du salarié :

Signature du responsable :
`,
  },

  // ---------------- Organisation interne ----------------
  {
    code: "note-interne",
    category: "note_interne",
    group: "Organisation interne",
    title: "Note interne",
    description: "Information diffusée au personnel ou à un service.",
    isLegal: false,
    aiRewrite: true,
    needsEmployee: false,
    version: 1,
    questions: [
      { key: "audience", label: "Destinataires", type: "text", required: true },
      { key: "subject", label: "Objet", type: "text", required: true },
      { key: "content", label: "Contenu", type: "textarea", required: true },
      signatureDate,
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `# Note interne

**Destinataires :** {{answers.audience}}
**Objet :** {{answers.subject}}
**Date :** {{answers.signatureDate}}

{{answers.content}}

{{signatory.fullName}}
{{company.legalName}}
`,
  },
  {
    code: "procedure-rh",
    category: "procedure",
    group: "Organisation interne",
    title: "Procédure RH",
    description: "Description d'un processus interne : objet, acteurs, étapes.",
    isLegal: false,
    aiRewrite: true,
    needsEmployee: false,
    version: 1,
    questions: [
      { key: "title", label: "Nom de la procédure", type: "text", required: true },
      { key: "scope", label: "Objet et périmètre", type: "textarea", required: true },
      { key: "actors", label: "Acteurs et responsabilités", type: "textarea", required: true },
      { key: "steps", label: "Étapes", type: "textarea", required: true, help: "Une étape par ligne, précédée d'un tiret." },
      { key: "effectiveDate", label: "Date d'entrée en vigueur", type: "date", required: true },
    ],
    legalReviewPoints: [],
    verifiedNote: null,
    body: `# Procédure : {{answers.title}}

**Entreprise :** {{company.legalName}}
**En vigueur à compter du :** {{answers.effectiveDate}}

## Objet et périmètre

{{answers.scope}}

## Acteurs

{{answers.actors}}

## Étapes

{{answers.steps}}
`,
  },
];
