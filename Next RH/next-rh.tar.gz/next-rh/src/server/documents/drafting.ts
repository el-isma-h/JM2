import "server-only";
import { and, desc, eq, inArray, isNull, or } from "drizzle-orm";
import { db, schema } from "@/db";
import type { CompanyContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { layoutMail, sendMail } from "@/server/mail";
import { appUrl } from "@/lib/env";
import { createDocument, readDocument } from "./store";
import { answersData, buildDraftData, questionLabels } from "./context";
import { listMarkers, renderTemplate, type MissingItem } from "./render";
import { TEMPLATES, type TemplateQuestion, type TemplateSeed } from "./templates-data";
import { renderDocx, renderPdf } from "./export";
import { getESignAdapter, ESIGN_NOT_CONFIGURED_MESSAGE } from "./esign";
import { improveWording } from "./ai";
import { RETENTION_YEARS } from "./visibility";

export class DraftError extends Error {}

export type DraftVersion = { version: number; body: string; at: string; by: string; byName: string; note: string };
export type Reviewer = {
  userId: string;
  name: string;
  requestedAt: string;
  requestedBy: string;
  requestedByName: string;
  message?: string;
  decision?: "approved" | "rejected" | "cancelled";
  comment?: string;
  decidedAt?: string;
};

export type Template = typeof schema.documentTemplates.$inferSelect;
export type Draft = typeof schema.documentDrafts.$inferSelect;

export const LEGAL_WARNING = "À faire valider par un juriste ou un avocat avant signature.";

/** Métadonnées d'affichage d'un modèle (groupe, IA autorisée, salarié requis). */
export function templateMeta(t: Pick<Template, "code" | "category" | "body" | "isLegal">): Pick<TemplateSeed, "group" | "aiRewrite" | "needsEmployee"> {
  const seed = TEMPLATES.find((s) => s.code === t.code);
  if (seed) return { group: seed.group, aiRewrite: seed.aiRewrite && !t.isLegal, needsEmployee: seed.needsEmployee };
  const nonLegalCats = ["courrier", "fiche_poste", "offre_emploi", "note_interne", "procedure"];
  return {
    group: "Organisation interne",
    aiRewrite: !t.isLegal && nonLegalCats.includes(t.category),
    needsEmployee: /\{\{\s*(employee|contract|compensation)\./.test(t.body),
  };
}

export const needsSalary = (body: string) => /\{\{\s*compensation\./.test(body);

// ---------- Lecture ----------

export async function listTemplates(companyId: string) {
  return db
    .select()
    .from(schema.documentTemplates)
    .where(or(isNull(schema.documentTemplates.companyId), eq(schema.documentTemplates.companyId, companyId)))
    .orderBy(schema.documentTemplates.title);
}

export async function getTemplate(companyId: string, idOrCode: string): Promise<Template | null> {
  const isUuid = /^[0-9a-f-]{36}$/.test(idOrCode);
  const [t] = await db
    .select()
    .from(schema.documentTemplates)
    .where(
      and(
        isUuid ? eq(schema.documentTemplates.id, idOrCode) : eq(schema.documentTemplates.code, idOrCode),
        or(isNull(schema.documentTemplates.companyId), eq(schema.documentTemplates.companyId, companyId)),
      ),
    )
    .orderBy(desc(schema.documentTemplates.companyId))
    .limit(1);
  return t ?? null;
}

/** Charge un brouillon de l'entreprise en vérifiant l'accès aux salaires si le brouillon en contient. */
export async function loadDraft(ctx: CompanyContext, draftId: string): Promise<{ draft: Draft; template: Template | null }> {
  if (!/^[0-9a-f-]{36}$/.test(draftId)) throw new DraftError("Brouillon introuvable.");
  const [draft] = await db
    .select()
    .from(schema.documentDrafts)
    .where(and(eq(schema.documentDrafts.id, draftId), eq(schema.documentDrafts.companyId, ctx.company.id)))
    .limit(1);
  if (!draft) throw new DraftError("Brouillon introuvable.");
  const answers = (draft.answers ?? {}) as Record<string, string>;
  if (answers._containsSalary === "1" && !ctx.permissions.has("salaries.read")) {
    throw new DraftError("Ce brouillon contient une rémunération : l'habilitation à consulter les salaires est nécessaire pour l'ouvrir.");
  }
  const template = draft.templateId
    ? ((await db.select().from(schema.documentTemplates).where(eq(schema.documentTemplates.id, draft.templateId)).limit(1))[0] ?? null)
    : null;
  return { draft, template };
}

export async function listDrafts(companyId: string) {
  return db
    .select({ d: schema.documentDrafts, e: { firstName: schema.employees.firstName, lastName: schema.employees.lastName } })
    .from(schema.documentDrafts)
    .leftJoin(schema.employees, eq(schema.employees.id, schema.documentDrafts.employeeId))
    .where(eq(schema.documentDrafts.companyId, companyId))
    .orderBy(desc(schema.documentDrafts.updatedAt))
    .limit(200);
}

/** Membres pouvant relire un brouillon (rôles rédacteurs, hors utilisateur courant). */
export async function listReviewCandidates(ctx: CompanyContext) {
  const rows = await db
    .select({ m: schema.companyMemberships, u: { id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, email: schema.users.email } })
    .from(schema.companyMemberships)
    .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
    .where(and(eq(schema.companyMemberships.companyId, ctx.company.id), inArray(schema.companyMemberships.role, ["owner", "admin", "hr", "payroll", "accountant"])));
  return rows
    .filter((r) => r.u.id !== ctx.user.id)
    .filter((r) => (r.m.permissions as Record<string, boolean>)?.["documents.write"] !== false)
    .map((r) => ({ id: r.u.id, name: `${r.u.firstName} ${r.u.lastName}`, email: r.u.email, role: r.m.role }));
}

// ---------- Écriture ----------

const userName = (ctx: CompanyContext) => `${ctx.user.firstName} ${ctx.user.lastName}`;

function pushVersion(draft: Draft, ctx: CompanyContext, body: string, note: string): DraftVersion[] {
  const versions = ((draft.versions ?? []) as DraftVersion[]).slice();
  const last = versions[versions.length - 1];
  if (last && last.body === body && note !== "Restauration") return versions;
  versions.push({ version: (last?.version ?? 0) + 1, body, at: new Date().toISOString(), by: ctx.user.id, byName: userName(ctx), note });
  return versions;
}

async function assertEmployee(companyId: string, employeeId: string) {
  const [e] = await db
    .select({ id: schema.employees.id, firstName: schema.employees.firstName, lastName: schema.employees.lastName, email: schema.employees.email })
    .from(schema.employees)
    .where(and(eq(schema.employees.id, employeeId), eq(schema.employees.companyId, companyId)))
    .limit(1);
  if (!e) throw new DraftError("Salarié introuvable dans cette entreprise.");
  return e;
}

/** Étape 1 : création du brouillon à partir du type de document choisi. */
export async function createDraft(ctx: CompanyContext, input: { templateId: string; employeeId: string | null }) {
  const t = await getTemplate(ctx.company.id, input.templateId);
  if (!t) throw new DraftError("Modèle introuvable.");
  const meta = templateMeta(t);
  if (meta.needsEmployee && !input.employeeId) throw new DraftError("Choisissez le salarié concerné par ce document.");
  if (input.employeeId && !ctx.permissions.has("employees.read")) throw new DraftError("Vous n'avez pas l'habilitation pour consulter les salariés.");
  const emp = input.employeeId ? await assertEmployee(ctx.company.id, input.employeeId) : null;
  const [draft] = await db
    .insert(schema.documentDrafts)
    .values({
      companyId: ctx.company.id,
      employeeId: emp?.id ?? null,
      templateId: t.id,
      category: t.category,
      title: emp ? `${t.title} : ${emp.firstName} ${emp.lastName}` : t.title,
      status: "questions",
      createdBy: ctx.user.id,
    })
    .returning();
  await audit({ action: "draft.create", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document_draft", entityId: draft.id, after: { template: t.code } });
  return draft;
}

/** Étapes 2 à 5 : réponses, données autorisées, éléments manquants, brouillon modifiable. */
export async function generateDraft(ctx: CompanyContext, draftId: string, rawAnswers: Record<string, string>) {
  const { draft, template } = await loadDraft(ctx, draftId);
  if (!template) throw new DraftError("Le modèle de ce brouillon n'existe plus.");
  if (["signed", "archived"].includes(draft.status)) throw new DraftError("Ce document est signé ou archivé : créez un nouveau brouillon.");
  const questions = (template.questions ?? []) as TemplateQuestion[];
  const clean: Record<string, string> = {};
  for (const q of questions) {
    const v = (rawAnswers[q.key] ?? "").toString().slice(0, 8000);
    if (q.type === "select" && v && q.options && !q.options.some((o) => o.value === v)) throw new DraftError(`Réponse invalide pour « ${q.label} ».`);
    if (q.type === "date" && v && !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new DraftError(`Date invalide pour « ${q.label} ».`);
    clean[q.key] = v;
  }
  const { data, withheld } = await buildDraftData(ctx, draft.employeeId);
  data.answers = answersData(questions, clean);
  const result = renderTemplate(template.body, data, { labels: questionLabels(questions), withheld });
  const containsSalary = needsSalary(template.body) && Boolean(data.compensation);
  const answers: Record<string, string> = { ...clean, ...(containsSalary ? { _containsSalary: "1" } : {}) };
  const versions = pushVersion(draft, ctx, result.text, draft.body ? "Nouvelle génération depuis le modèle" : "Génération depuis le modèle");
  await db
    .update(schema.documentDrafts)
    .set({ answers, missing: result.missing, body: result.text, versions, status: "drafted", validatedAt: null, validatedBy: null, reviewers: cancelPending(draft) })
    .where(eq(schema.documentDrafts.id, draft.id));
  await audit({
    action: "draft.generate",
    userId: ctx.user.id,
    companyId: ctx.company.id,
    entityType: "document_draft",
    entityId: draft.id,
    after: { missing: result.missing.length, withheld: Object.keys(withheld) },
  });
  return { missing: result.missing };
}

function cancelPending(draft: Draft): Reviewer[] {
  return ((draft.reviewers ?? []) as Reviewer[]).map((r) => (r.decision ? r : { ...r, decision: "cancelled" as const, decidedAt: new Date().toISOString(), comment: "Brouillon modifié avant décision" }));
}

function missingFromBody(body: string, previous: MissingItem[]): MissingItem[] {
  return listMarkers(body).map((label) => previous.find((m) => m.label === label) ?? { key: "manuel", label });
}

/** Enregistrement d'une modification manuelle : nouvelle version archivée, relecture et validation réinitialisées. */
export async function saveDraftBody(ctx: CompanyContext, draftId: string, body: string, note?: string) {
  const { draft } = await loadDraft(ctx, draftId);
  if (["signed", "archived"].includes(draft.status)) throw new DraftError("Ce document est signé ou archivé : il n'est plus modifiable.");
  if (draft.status === "questions") throw new DraftError("Générez d'abord le brouillon à partir des questions.");
  if (body.length > 200_000) throw new DraftError("Le brouillon est trop long.");
  const normalized = body.replace(/\r\n?/g, "\n").replace(/[—–]/g, "-");
  if (normalized === draft.body) return { changed: false, missing: (draft.missing as MissingItem[]) ?? [] };
  const versions = pushVersion(draft, ctx, normalized, note?.trim() || "Modification manuelle");
  const missing = missingFromBody(normalized, (draft.missing as MissingItem[]) ?? []);
  await db
    .update(schema.documentDrafts)
    .set({ body: normalized, versions, missing, status: "drafted", validatedAt: null, validatedBy: null, reviewers: cancelPending(draft) })
    .where(eq(schema.documentDrafts.id, draft.id));
  await audit({ action: "draft.update", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document_draft", entityId: draft.id, after: { version: versions.length, missing: missing.length } });
  return { changed: true, missing };
}

export async function restoreVersion(ctx: CompanyContext, draftId: string, version: number) {
  const { draft } = await loadDraft(ctx, draftId);
  const v = ((draft.versions ?? []) as DraftVersion[]).find((x) => x.version === version);
  if (!v) throw new DraftError("Version introuvable.");
  return saveDraftBody(ctx, draftId, v.body, `Restauration de la version ${version}`);
}

/** Étape 6a : envoi en relecture. */
export async function submitForReview(ctx: CompanyContext, draftId: string, reviewerId: string, message?: string) {
  const { draft } = await loadDraft(ctx, draftId);
  if (draft.status !== "drafted") throw new DraftError("Seul un brouillon généré et non encore en relecture peut être envoyé en relecture.");
  if (reviewerId === ctx.user.id) throw new DraftError("La relecture doit être faite par une autre personne que le rédacteur.");
  const candidates = await listReviewCandidates(ctx);
  const reviewer = candidates.find((c) => c.id === reviewerId);
  if (!reviewer) throw new DraftError("Ce membre ne peut pas relire les documents de l'entreprise.");
  const reviewers: Reviewer[] = [
    ...((draft.reviewers ?? []) as Reviewer[]),
    {
      userId: reviewer.id,
      name: reviewer.name,
      requestedAt: new Date().toISOString(),
      requestedBy: ctx.user.id,
      requestedByName: userName(ctx),
      ...(message?.trim() ? { message: message.trim().slice(0, 1000) } : {}),
    },
  ];
  await db.update(schema.documentDrafts).set({ reviewers, status: "in_review" }).where(eq(schema.documentDrafts.id, draft.id));
  const url = `${appUrl()}/app/${ctx.company.id}/atelier/${draft.id}`;
  await sendMail({
    to: reviewer.email,
    subject: `Relecture demandée : ${draft.title}`,
    html: layoutMail("Relecture demandée", `<p>${userName(ctx)} vous demande de relire « ${escapeHtml(draft.title)} ».</p>`, { label: "Ouvrir le brouillon", url }),
    text: `${userName(ctx)} vous demande de relire « ${draft.title} » : ${url}`,
    isDemo: ctx.company.isDemo,
  });
  await audit({ action: "draft.review_request", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document_draft", entityId: draft.id, after: { reviewer: reviewer.id } });
  return reviewer;
}

/** Étape 6b : validation ou refus par le relecteur désigné. */
export async function decideReview(ctx: CompanyContext, draftId: string, decision: "approved" | "rejected", comment: string) {
  const { draft } = await loadDraft(ctx, draftId);
  if (draft.status !== "in_review") throw new DraftError("Ce brouillon n'est pas en relecture.");
  const reviewers = ((draft.reviewers ?? []) as Reviewer[]).slice();
  const idx = reviewers.findIndex((r) => r.userId === ctx.user.id && !r.decision);
  if (idx < 0) throw new DraftError("Seul le relecteur désigné peut valider ou refuser ce brouillon.");
  if (decision === "rejected" && !comment.trim()) throw new DraftError("Indiquez la raison du refus pour que le rédacteur puisse corriger.");
  if (decision === "approved" && listMarkers(draft.body).length) {
    throw new DraftError("Validation impossible : des éléments restent à compléter dans le brouillon.");
  }
  reviewers[idx] = { ...reviewers[idx], decision, comment: comment.trim().slice(0, 2000), decidedAt: new Date().toISOString() };
  await db
    .update(schema.documentDrafts)
    .set({
      reviewers,
      status: decision === "approved" ? "validated" : "drafted",
      validatedBy: decision === "approved" ? ctx.user.id : null,
      validatedAt: decision === "approved" ? new Date() : null,
    })
    .where(eq(schema.documentDrafts.id, draft.id));
  await audit({ action: decision === "approved" ? "draft.validate" : "draft.reject", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document_draft", entityId: draft.id, after: { comment } });
}

/** Étape 7 : export PDF et DOCX, stockés comme documents et liés au brouillon (versions chaînées). */
export async function exportDraft(ctx: CompanyContext, draftId: string, opts: { visibility: "company" | "employee" | "restricted"; legalAcknowledged: boolean }) {
  const { draft, template } = await loadDraft(ctx, draftId);
  if (!["validated", "exported"].includes(draft.status)) throw new DraftError("Le brouillon doit être validé en relecture avant l'export.");
  if (listMarkers(draft.body).length) throw new DraftError("Export impossible : des éléments restent à compléter.");
  if (template?.isLegal && !opts.legalAcknowledged) throw new DraftError("Confirmez que ce document sera validé par un juriste ou un avocat avant signature.");
  const containsSalary = ((draft.answers ?? {}) as Record<string, string>)._containsSalary === "1";
  const visibility = containsSalary && opts.visibility !== "restricted" && !ctx.permissions.has("salaries.read") ? "restricted" : opts.visibility;
  const meta = { title: draft.title, footer: `${ctx.company.legalName}, ${draft.title}` };
  const [pdf, docx] = await Promise.all([renderPdf(draft.body, meta), renderDocx(draft.body, meta)]);
  const base = slug(draft.title);
  const retention = RETENTION_YEARS[draft.category]?.years ?? 5;
  const common = {
    companyId: ctx.company.id,
    employeeId: draft.employeeId,
    category: draft.category,
    visibility,
    title: draft.title,
    sourceType: "document_draft",
    sourceId: draft.id,
    uploadedBy: ctx.user.id,
    retentionYears: retention,
    isDemo: ctx.company.isDemo,
  };
  const pdfDoc = await createDocument({ ...common, fileName: `${base}.pdf`, mimeType: "application/pdf", data: pdf, previousVersionId: draft.pdfDocumentId });
  const docxDoc = await createDocument({
    ...common,
    fileName: `${base}.docx`,
    mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    data: docx,
    previousVersionId: draft.docxDocumentId,
  });
  const versions = ((draft.versions ?? []) as DraftVersion[]).slice();
  const last = versions[versions.length - 1];
  if (last) versions[versions.length - 1] = { ...last, note: `${last.note} ; exportée (PDF v${pdfDoc.version})` };
  await db
    .update(schema.documentDrafts)
    .set({ pdfDocumentId: pdfDoc.id, docxDocumentId: docxDoc.id, status: "exported", versions })
    .where(eq(schema.documentDrafts.id, draft.id));
  await audit({
    action: "draft.export",
    userId: ctx.user.id,
    companyId: ctx.company.id,
    entityType: "document_draft",
    entityId: draft.id,
    after: { pdf: pdfDoc.id, docx: docxDoc.id, version: pdfDoc.version, legalAcknowledged: opts.legalAcknowledged },
  });
  return { pdfDoc, docxDoc };
}

/** Signature électronique : crée la demande ; sans prestataire, statut « non configuré » et rien ne part. */
export async function requestSignature(ctx: CompanyContext, draftId: string) {
  const { draft, template } = await loadDraft(ctx, draftId);
  if (!draft.pdfDocumentId || draft.status !== "exported") throw new DraftError("Exportez d'abord le document validé en PDF.");
  const signers: { name: string; email: string | null; role: "employer" | "employee" }[] = [{ name: userName(ctx), email: ctx.user.email, role: "employer" }];
  if (draft.employeeId) {
    const e = await assertEmployee(ctx.company.id, draft.employeeId);
    signers.push({ name: `${e.firstName} ${e.lastName}`, email: e.email, role: "employee" });
  }
  const availability = getESignAdapter();
  if (ctx.company.isDemo || !availability.ok) {
    const notConfigured = availability.ok ? null : availability.message;
    const message = ctx.company.isDemo ? `Démonstration : aucune demande de signature n'est envoyée.${notConfigured ? ` ${notConfigured}` : ""}` : (notConfigured ?? ESIGN_NOT_CONFIGURED_MESSAGE);
    const [req] = await db
      .insert(schema.signatureRequests)
      .values({ documentId: draft.pdfDocumentId, provider: process.env.ESIGN_PROVIDER ?? null, status: "not_configured", signers, requestedBy: ctx.user.id, proof: null })
      .returning();
    await audit({ action: "signature.request", userId: ctx.user.id, companyId: ctx.company.id, entityType: "signature_request", entityId: req.id, after: { status: "not_configured" } });
    return { request: req, message };
  }
  const missingEmail = signers.find((s) => !s.email);
  if (missingEmail) throw new DraftError(`Adresse e-mail manquante pour ${missingEmail.name} : renseignez-la dans sa fiche avant l'envoi.`);
  const file = await readDocument(draft.pdfDocumentId);
  if (!file) throw new DraftError("Fichier PDF introuvable.");
  const sent = await availability.adapter.send({
    documentId: draft.pdfDocumentId,
    fileName: file.doc.fileName,
    data: file.data,
    title: draft.title,
    signers: signers.map((s) => ({ name: s.name, email: s.email as string, role: s.role })),
  });
  const [req] = await db
    .insert(schema.signatureRequests)
    .values({ documentId: draft.pdfDocumentId, provider: availability.adapter.name, providerRef: sent.providerRef, status: sent.status, signers, requestedBy: ctx.user.id })
    .returning();
  await audit({ action: "signature.request", userId: ctx.user.id, companyId: ctx.company.id, entityType: "signature_request", entityId: req.id, after: { status: sent.status, legal: template?.isLegal ?? false } });
  return { request: req, message: "Demande de signature envoyée au prestataire." };
}

/** Met à jour le statut et la preuve d'une demande auprès du prestataire. */
export async function refreshSignature(ctx: CompanyContext, draftId: string, requestId: string) {
  const { draft } = await loadDraft(ctx, draftId);
  const [req] = await db.select().from(schema.signatureRequests).where(eq(schema.signatureRequests.id, requestId)).limit(1);
  if (!req || req.documentId !== draft.pdfDocumentId) throw new DraftError("Demande de signature introuvable.");
  const availability = getESignAdapter();
  if (!availability.ok || !req.providerRef) return { status: req.status, message: availability.ok ? "Aucune référence prestataire pour cette demande." : availability.message };
  const status = await availability.adapter.status(req.providerRef);
  const proof = status === "signed" ? await availability.adapter.proof(req.providerRef) : null;
  await db.update(schema.signatureRequests).set({ status, proof }).where(eq(schema.signatureRequests.id, req.id));
  if (status === "signed") await db.update(schema.documentDrafts).set({ status: "signed" }).where(eq(schema.documentDrafts.id, draft.id));
  await audit({ action: "signature.refresh", userId: ctx.user.id, companyId: ctx.company.id, entityType: "signature_request", entityId: req.id, after: { status } });
  return { status, message: "Statut mis à jour." };
}

export async function listSignatureRequests(documentIds: string[]) {
  if (!documentIds.length) return [];
  return db.select().from(schema.signatureRequests).where(inArray(schema.signatureRequests.documentId, documentIds)).orderBy(desc(schema.signatureRequests.createdAt));
}

/** Reformulation IA (modèles non juridiques uniquement), enregistrée comme nouvelle version. */
export async function improveDraft(ctx: CompanyContext, draftId: string) {
  const { draft, template } = await loadDraft(ctx, draftId);
  if (!template || !templateMeta(template).aiRewrite) throw new DraftError("La reformulation n'est proposée que pour les documents non juridiques (courriers, réponses, fiches de poste, offres, notes, procédures).");
  if (["signed", "archived", "questions"].includes(draft.status)) throw new DraftError("Générez un brouillon modifiable avant de le reformuler.");
  const res = await improveWording({ body: draft.body, kind: template.title, canSeeSalaries: ctx.permissions.has("salaries.read") });
  if (!res.ok) throw new DraftError(res.error);
  await audit({ action: "draft.ai_rewrite", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document_draft", entityId: draft.id });
  return saveDraftBody(ctx, draftId, res.body, "Reformulation assistée (IA)");
}

export async function archiveDraft(ctx: CompanyContext, draftId: string) {
  const { draft } = await loadDraft(ctx, draftId);
  await db.update(schema.documentDrafts).set({ status: "archived" }).where(eq(schema.documentDrafts.id, draft.id));
  await audit({ action: "draft.archive", userId: ctx.user.id, companyId: ctx.company.id, entityType: "document_draft", entityId: draft.id, before: { status: draft.status } });
}

function slug(s: string) {
  return (
    s
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .replace(/[^a-zA-Z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
      .toLowerCase()
      .slice(0, 70) || "document"
  );
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);
}
