import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { buildKey, getObject, putObject } from "@/server/storage";
import { issueToken, peekToken } from "@/server/auth";
import { appUrl } from "@/lib/env";

type Category = (typeof schema.documentCategoryEnum.enumValues)[number];
type Visibility = (typeof schema.documentVisibilityEnum.enumValues)[number];

/** Enregistre un fichier dans le stockage privé et crée la ligne `documents`. Retourne la ligne. */
export async function createDocument(input: {
  companyId: string;
  employeeId?: string | null;
  category: Category;
  visibility?: Visibility;
  title: string;
  fileName: string;
  mimeType: string;
  data: Buffer;
  sourceType?: string;
  sourceId?: string | null;
  uploadedBy?: string | null;
  previousVersionId?: string | null;
  retentionYears?: number;
  isDemo?: boolean;
}) {
  const key = buildKey(input.companyId, input.category, input.fileName);
  const stored = await putObject(key, input.data);
  let version = 1;
  if (input.previousVersionId) {
    const [prev] = await db.select({ v: schema.documents.version }).from(schema.documents).where(eq(schema.documents.id, input.previousVersionId)).limit(1);
    version = (prev?.v ?? 0) + 1;
  }
  const retentionUntil = input.retentionYears ? new Date(Date.now() + input.retentionYears * 365.25 * 86400_000) : null;
  const [row] = await db
    .insert(schema.documents)
    .values({
      companyId: input.companyId,
      employeeId: input.employeeId ?? null,
      category: input.category,
      visibility: input.visibility ?? (input.employeeId ? "employee" : "company"),
      title: input.title,
      fileName: input.fileName,
      mimeType: input.mimeType,
      sizeBytes: stored.size,
      storageKey: key,
      sha256: stored.sha256,
      version,
      previousVersionId: input.previousVersionId ?? null,
      sourceType: input.sourceType,
      sourceId: input.sourceId ?? null,
      retentionUntil,
      uploadedBy: input.uploadedBy ?? null,
      isDemo: input.isDemo ?? false,
    })
    .returning();
  return row;
}

export async function readDocument(documentId: string) {
  const [doc] = await db.select().from(schema.documents).where(eq(schema.documents.id, documentId)).limit(1);
  if (!doc) return null;
  return { doc, data: await getObject(doc.storageKey) };
}

/** Lien de téléchargement temporaire (15 min), lié à l'utilisateur qui l'a demandé. */
export async function issueDownloadLink(documentId: string, userId: string, ttlMinutes = 15) {
  const token = await issueToken("download", { userId, payload: { documentId }, ttlMinutes });
  return `${appUrl()}/telechargement/${token}`;
}

export async function resolveDownloadToken(token: string) {
  const row = await peekToken("download", token);
  const payload = row?.payload as { documentId?: string } | undefined;
  if (!row || !payload?.documentId) return null;
  return { documentId: payload.documentId, userId: row.userId };
}

export async function listEmployeeDocuments(companyId: string, employeeId: string) {
  return db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.companyId, companyId), eq(schema.documents.employeeId, employeeId)))
    .orderBy(schema.documents.createdAt);
}
