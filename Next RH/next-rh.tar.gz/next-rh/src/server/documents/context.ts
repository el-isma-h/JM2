import "server-only";
import { and, desc, eq, lte } from "drizzle-orm";
import { db, schema } from "@/db";
import type { CompanyContext } from "@/server/authz";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import type { RenderData } from "./render";
import type { TemplateQuestion } from "./templates-data";

/**
 * Construit les données d'un document à partir des seules informations autorisées pour l'utilisateur :
 * - entreprise : toujours (l'utilisateur a accès à l'entreprise) ;
 * - salarié et contrat : uniquement avec `employees.read` ;
 * - rémunération : uniquement avec `salaries.read` ;
 * - jamais de NIR ni de coordonnées bancaires (non lus).
 * Les données non lues faute d'habilitation sont listées dans `withheld` (marqueur explicite dans le document).
 */
export async function buildDraftData(ctx: CompanyContext, employeeId: string | null): Promise<{ data: RenderData; withheld: Record<string, string> }> {
  const c = ctx.company;
  const withheld: Record<string, string> = {};
  const [head] = await db
    .select()
    .from(schema.establishments)
    .where(and(eq(schema.establishments.companyId, c.id), eq(schema.establishments.isHeadOffice, true)))
    .limit(1);
  const organisms = await db.select().from(schema.companyOrganisms).where(eq(schema.companyOrganisms.companyId, c.id));
  const orgName = (kind: string) => organisms.find((o) => o.kind === kind)?.name ?? null;
  const address = [c.addressLine1, c.addressLine2, [c.postalCode, c.city].filter(Boolean).join(" ")].filter(Boolean).join(", ");

  const data: RenderData = {
    company: {
      legalName: c.legalName,
      legalForm: c.legalForm && c.legalForm !== "AUTRE" ? c.legalForm : null,
      siren: c.siren,
      siret: head?.siret ?? null,
      address: address || null,
      city: c.city,
      collectiveAgreement: c.collectiveAgreement,
      idcc: c.idcc,
      retirementFund: orgName("retraite"),
      providentFund: orgName("prevoyance"),
      healthFund: orgName("mutuelle"),
    },
    signatory: { fullName: `${ctx.user.firstName} ${ctx.user.lastName}` },
  };

  if (!employeeId) return { data, withheld };

  if (!ctx.permissions.has("employees.read")) {
    withheld.employee = "habilitation salariés requise";
    withheld.contract = "habilitation salariés requise";
    withheld.compensation = "habilitation salariés requise";
    return { data, withheld };
  }

  const [e] = await db
    .select()
    .from(schema.employees)
    .where(and(eq(schema.employees.id, employeeId), eq(schema.employees.companyId, c.id)))
    .limit(1);
  if (!e) throw new Error("Salarié introuvable dans cette entreprise.");

  const [contract] = await db
    .select()
    .from(schema.contracts)
    .where(eq(schema.contracts.employeeId, e.id))
    .orderBy(desc(schema.contracts.startDate))
    .limit(1);

  const civ = e.civility ?? (e.gender === "F" ? "Madame" : e.gender === "M" ? "Monsieur" : null);
  data.employee = {
    civility: civ,
    firstName: e.firstName,
    lastName: e.lastName,
    fullName: `${e.firstName} ${e.lastName}`,
    birthDate: e.birthDate ? fmtDate(e.birthDate, "d MMMM yyyy") : null,
    birthPlace: e.birthPlace,
    nationality: e.nationality,
    address: [e.addressLine1, e.addressLine2, [e.postalCode, e.city].filter(Boolean).join(" ")].filter(Boolean).join(", ") || null,
    jobTitle: e.jobTitle,
    department: e.department,
    hireDate: e.hireDate ? fmtDate(e.hireDate, "d MMMM yyyy") : null,
    leaveDate: e.leaveDate ? fmtDate(e.leaveDate, "d MMMM yyyy") : null,
    leaveReason: e.leaveReason,
    employeeNumber: e.employeeNumber,
  };

  if (contract) {
    const typeLabels: Record<string, string> = {
      CDI: "contrat à durée indéterminée",
      CDD: "contrat à durée déterminée",
      APPRENTISSAGE: "contrat d'apprentissage",
      PROFESSIONNALISATION: "contrat de professionnalisation",
      STAGE: "stage",
      INTERIM: "contrat de mission",
      MANDAT: "mandat social",
    };
    const catLabels: Record<string, string> = {
      non_cadre: "non-cadre",
      cadre: "cadre",
      cadre_dirigeant: "cadre dirigeant",
      apprenti: "apprenti",
      stagiaire: "stagiaire",
    };
    const wt: Record<string, string> = { heures: "décompte en heures", forfait_jours: "forfait annuel en jours", forfait_heures: "forfait en heures" };
    data.contract = {
      type: contract.type,
      typeLabel: typeLabels[contract.type],
      categoryLabel: catLabels[contract.category],
      startDate: fmtDate(contract.startDate, "d MMMM yyyy"),
      endDate: contract.endDate ? fmtDate(contract.endDate, "d MMMM yyyy") : null,
      trialEndDate: contract.trialEndDate ? fmtDate(contract.trialEndDate, "d MMMM yyyy") : null,
      trialRenewedUntil: contract.trialRenewedUntil ? fmtDate(contract.trialRenewedUntil, "d MMMM yyyy") : null,
      jobTitle: contract.jobTitle ?? e.jobTitle,
      classification: contract.classification,
      coefficient: contract.coefficient,
      weeklyHours: Number(contract.weeklyHours).toLocaleString("fr-FR"),
      monthlyHours: Number(contract.monthlyHours).toLocaleString("fr-FR"),
      workTimeLabel: wt[contract.workTimeMode],
      isPartTime: contract.isPartTime,
      cddReason: contract.cddReason,
    };
  }

  if (!ctx.permissions.has("salaries.read")) {
    withheld.compensation = "habilitation salaires requise";
  } else {
    const today = new Date().toISOString().slice(0, 10);
    const [comp] = await db
      .select()
      .from(schema.compensations)
      .where(and(eq(schema.compensations.employeeId, e.id), lte(schema.compensations.effectiveDate, today)))
      .orderBy(desc(schema.compensations.effectiveDate))
      .limit(1);
    if (comp) {
      const basis: Record<string, string> = { monthly: "salaire mensuel", hourly: "taux horaire", annual: "salaire annuel" };
      data.compensation = {
        grossMonthly: formatCents(comp.grossAmountCents),
        basisLabel: basis[comp.basis],
        effectiveDate: fmtDate(comp.effectiveDate, "d MMMM yyyy"),
      };
    }
  }
  return { data, withheld };
}

/** Met en forme les réponses (dates en toutes lettres) et les place sous `answers`. */
export function answersData(questions: TemplateQuestion[], answers: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const q of questions) {
    const v = (answers[q.key] ?? "").trim();
    if (!v) continue;
    out[q.key] = q.type === "date" && /^\d{4}-\d{2}-\d{2}$/.test(v) ? fmtDate(v, "d MMMM yyyy") : v;
  }
  return out;
}

export function questionLabels(questions: TemplateQuestion[]): Record<string, string> {
  return Object.fromEntries(questions.map((q) => [`answers.${q.key}`, q.label]));
}
