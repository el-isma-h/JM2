import type { Permission } from "@/server/authz";

/**
 * Règles de visibilité documentaire (pures). Appliquées côté serveur dans chaque requête,
 * jamais seulement dans l'interface.
 */

export type DocLike = { visibility: "company" | "employee" | "restricted"; category: string; employeeId: string | null };

/** Catégories dont le contenu révèle une rémunération : traitées comme restreintes. */
export const SALARY_CATEGORIES = ["bulletin"] as const;

export function canSeeRestricted(perms: Set<Permission>): boolean {
  return perms.has("salaries.read") || perms.has("payroll.validate");
}

export function canSeeDocument(doc: DocLike, perms: Set<Permission>): boolean {
  if (!perms.has("documents.read")) return false;
  if (doc.visibility === "restricted" || (SALARY_CATEGORIES as readonly string[]).includes(doc.category)) return canSeeRestricted(perms);
  return true;
}

export const VISIBILITY_LABELS: Record<DocLike["visibility"], { label: string; help: string }> = {
  company: { label: "Entreprise", help: "Visible par les gestionnaires habilités à consulter les documents." },
  employee: { label: "Salarié", help: "Visible aussi par le salarié concerné dans son espace." },
  restricted: { label: "Restreint", help: "Réservé aux personnes habilitées aux salaires ou à la validation de paie." },
};

export const CATEGORY_LABELS: Record<string, string> = {
  bulletin: "Bulletin de paie",
  contrat: "Contrat",
  avenant: "Avenant",
  attestation: "Attestation",
  courrier: "Courrier",
  justificatif: "Justificatif",
  identite: "Pièce d'identité",
  kbis: "Extrait Kbis",
  entreprise: "Document d'entreprise",
  fiche_poste: "Fiche de poste",
  offre_emploi: "Offre d'emploi",
  convocation: "Convocation",
  compte_rendu: "Compte rendu",
  note_interne: "Note interne",
  procedure: "Procédure RH",
  export: "Export",
  autre: "Autre",
};

/**
 * Durée de conservation indicative par catégorie (années), affichée à titre d'information.
 * Les durées retenues sont les durées usuelles de prescription ; l'entreprise reste responsable de sa politique.
 */
export const RETENTION_YEARS: Record<string, { years: number; basis: string }> = {
  bulletin: { years: 50, basis: "Durée longue retenue pour les bulletins dématérialisés (droits retraite du salarié)" },
  contrat: { years: 5, basis: "5 ans après la fin du contrat" },
  avenant: { years: 5, basis: "5 ans après la fin du contrat" },
  attestation: { years: 5, basis: "5 ans" },
  courrier: { years: 5, basis: "5 ans" },
  justificatif: { years: 5, basis: "5 ans" },
  identite: { years: 5, basis: "5 ans après le départ du salarié" },
  kbis: { years: 5, basis: "5 ans" },
  entreprise: { years: 10, basis: "10 ans" },
  fiche_poste: { years: 5, basis: "5 ans" },
  offre_emploi: { years: 2, basis: "2 ans" },
  convocation: { years: 5, basis: "5 ans" },
  compte_rendu: { years: 5, basis: "5 ans" },
  note_interne: { years: 5, basis: "5 ans" },
  procedure: { years: 5, basis: "5 ans après son remplacement" },
  export: { years: 6, basis: "6 ans (pièces justificatives comptables et sociales)" },
  autre: { years: 5, basis: "5 ans" },
};
