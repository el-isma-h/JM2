import "server-only";
import type { Db } from "@/db";
import { schema } from "@/db";

type Tx = Parameters<Parameters<Db["transaction"]>[0]>[0];

/** Types d'absence standard créés pour chaque nouvelle entreprise (modifiables ensuite). */
export const DEFAULT_LEAVE_TYPES = [
  { code: "CP", label: "Congés payés", isPaid: true, affectsPayroll: true, requiresProof: false, unit: "jours_ouvres", monthlyAccrual: "2.08", color: "accent", sortOrder: 1 },
  { code: "RTT", label: "RTT", isPaid: true, affectsPayroll: true, requiresProof: false, unit: "jours_ouvres", monthlyAccrual: null, color: "info", sortOrder: 2 },
  { code: "MAL", label: "Arrêt maladie", isPaid: false, affectsPayroll: true, requiresProof: true, unit: "jours_calendaires", monthlyAccrual: null, color: "warn", sortOrder: 3 },
  { code: "CSS", label: "Congé sans solde", isPaid: false, affectsPayroll: true, requiresProof: false, unit: "jours_ouvres", monthlyAccrual: null, color: "neutral", sortOrder: 4 },
  { code: "EVF", label: "Événement familial", isPaid: true, affectsPayroll: false, requiresProof: true, unit: "jours_ouvres", monthlyAccrual: null, color: "neutral", sortOrder: 5 },
  { code: "MAT", label: "Congé maternité / paternité", isPaid: false, affectsPayroll: true, requiresProof: true, unit: "jours_calendaires", monthlyAccrual: null, color: "warn", sortOrder: 6 },
  { code: "TT", label: "Télétravail", isPaid: true, affectsPayroll: false, requiresProof: false, unit: "jours_ouvres", monthlyAccrual: null, color: "neutral", sortOrder: 7 },
] as const;

export async function bootstrapCompanyDefaults(tx: Tx | Db, companyId: string) {
  await tx.insert(schema.leaveTypes).values(DEFAULT_LEAVE_TYPES.map((t) => ({ ...t, companyId })));
  await tx.insert(schema.remoteWorkPolicies).values({ companyId });
  await tx.insert(schema.establishments).values({ companyId, name: "Siège", isHeadOffice: true });
}
