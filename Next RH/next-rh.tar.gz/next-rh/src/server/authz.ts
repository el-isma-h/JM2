import "server-only";
import { and, eq } from "drizzle-orm";
import { cache } from "react";
import { db, schema } from "@/db";
import { AuthError, getCurrentUser, requireUser, type SessionUser } from "./auth";

export type CompanyRole = (typeof schema.companyRoleEnum.enumValues)[number];

export type Permission =
  | "company.manage"
  | "members.manage"
  | "employees.read"
  | "employees.write"
  | "employees.bank.read"
  | "salaries.read"
  | "payroll.prepare"
  | "payroll.validate"
  | "payroll.close"
  | "filings.send"
  | "documents.read"
  | "documents.write"
  | "requests.approve"
  | "reports.read"
  | "self.read";

/** Matrice rôles → permissions. Les permissions fines en JSON (company_memberships.permissions) peuvent en ajouter/retirer. */
const matrix: Record<CompanyRole, Permission[]> = {
  owner: [
    "company.manage", "members.manage", "employees.read", "employees.write", "employees.bank.read", "salaries.read",
    "payroll.prepare", "payroll.validate", "payroll.close", "filings.send", "documents.read", "documents.write",
    "requests.approve", "reports.read", "self.read",
  ],
  admin: [
    "company.manage", "members.manage", "employees.read", "employees.write", "employees.bank.read", "salaries.read",
    "payroll.prepare", "payroll.validate", "payroll.close", "filings.send", "documents.read", "documents.write",
    "requests.approve", "reports.read", "self.read",
  ],
  hr: [
    "employees.read", "employees.write", "salaries.read", "payroll.prepare", "documents.read", "documents.write",
    "requests.approve", "reports.read", "self.read",
  ],
  payroll: [
    "employees.read", "employees.bank.read", "salaries.read", "payroll.prepare", "payroll.validate", "payroll.close",
    "filings.send", "documents.read", "documents.write", "reports.read", "self.read",
  ],
  accountant: [
    "employees.read", "employees.bank.read", "salaries.read", "payroll.prepare", "payroll.validate", "payroll.close",
    "filings.send", "documents.read", "documents.write", "reports.read", "self.read",
  ],
  manager: ["employees.read", "requests.approve", "documents.read", "self.read"],
  employee: ["self.read"],
  viewer: ["employees.read", "reports.read", "self.read"],
};

/** Permissions nécessitant une session renforcée (TOTP récent). */
export const SENSITIVE: Permission[] = ["employees.bank.read", "filings.send", "payroll.close"];

export type CompanyContext = {
  user: SessionUser;
  company: typeof schema.companies.$inferSelect;
  tenant: typeof schema.tenants.$inferSelect;
  role: CompanyRole;
  permissions: Set<Permission>;
  employeeId: string | null;
};

export const getCompanyContext = cache(async (companyId: string): Promise<CompanyContext | null> => {
  const user = await getCurrentUser();
  if (!user) return null;
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, companyId)).limit(1);
  if (!company) return null;
  const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, company.tenantId)).limit(1);
  if (!tenant) return null;

  let role: CompanyRole | null = null;
  let extra: Partial<Record<Permission, boolean>> = {};
  const [m] = await db
    .select()
    .from(schema.companyMemberships)
    .where(and(eq(schema.companyMemberships.companyId, companyId), eq(schema.companyMemberships.userId, user.id)))
    .limit(1);
  if (m) {
    role = m.role;
    extra = (m.permissions as Partial<Record<Permission, boolean>>) ?? {};
  } else if (user.platformRole === "platform_admin") {
    role = "admin";
  } else if (user.tenantId === company.tenantId && tenant.kind !== "company") {
    // Membre du cabinet sans affectation explicite : lecture seule.
    role = "viewer";
  }
  if (!role) return null;

  const permissions = new Set<Permission>(matrix[role]);
  for (const [k, v] of Object.entries(extra)) {
    if (v) permissions.add(k as Permission);
    else permissions.delete(k as Permission);
  }
  const [emp] = await db
    .select({ id: schema.employees.id })
    .from(schema.employees)
    .where(and(eq(schema.employees.companyId, companyId), eq(schema.employees.userId, user.id)))
    .limit(1);

  return { user, company, tenant, role, permissions, employeeId: emp?.id ?? null };
});

/** Contrôle côté serveur : lève AuthError si l'accès n'est pas autorisé. */
export async function requireCompany(companyId: string, ...perms: Permission[]): Promise<CompanyContext> {
  const user = await requireUser();
  if (!user.emailVerified) throw new AuthError("email_unverified");
  const ctx = await getCompanyContext(companyId);
  if (!ctx) throw new AuthError("forbidden");
  for (const p of perms) {
    if (!ctx.permissions.has(p)) throw new AuthError("forbidden");
    if (SENSITIVE.includes(p) && !ctx.user.elevated) throw new AuthError("elevation_required");
  }
  return ctx;
}

export async function requirePlatformAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.platformRole !== "platform_admin") throw new AuthError("forbidden");
  return user;
}

/** Entreprises accessibles à l'utilisateur courant (affectations + entreprises du tenant si cabinet/groupe). */
export async function listAccessibleCompanies(user: SessionUser) {
  if (user.platformRole === "platform_admin") {
    return db.select().from(schema.companies).orderBy(schema.companies.legalName);
  }
  const viaMembership = await db
    .select({ c: schema.companies })
    .from(schema.companyMemberships)
    .innerJoin(schema.companies, eq(schema.companies.id, schema.companyMemberships.companyId))
    .where(eq(schema.companyMemberships.userId, user.id));
  const result = new Map(viaMembership.map((r) => [r.c.id, r.c]));
  if (user.tenantId) {
    const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, user.tenantId)).limit(1);
    if (tenant && tenant.kind !== "company") {
      const own = await db.select().from(schema.companies).where(eq(schema.companies.tenantId, user.tenantId));
      for (const c of own) result.set(c.id, c);
    }
  }
  return [...result.values()].sort((a, b) => a.legalName.localeCompare(b.legalName));
}
