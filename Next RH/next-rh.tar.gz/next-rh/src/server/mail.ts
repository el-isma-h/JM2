import "server-only";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { integrations } from "@/lib/env";

type Mail = { to: string; subject: string; html: string; text?: string; isDemo?: boolean };

/**
 * Envoi d'e-mail : toujours journalisé dans mail_outbox. Envoyé via Resend si RESEND_API_KEY est défini.
 * En démonstration, rien ne part jamais (status skipped).
 */
export async function sendMail(mail: Mail): Promise<{ id: string; status: string }> {
  const [row] = await db
    .insert(schema.mailOutbox)
    .values({ to: mail.to, subject: mail.subject, html: mail.html, text: mail.text, isDemo: mail.isDemo ?? false })
    .returning({ id: schema.mailOutbox.id });

  if (mail.isDemo) {
    await db.update(schema.mailOutbox).set({ status: "skipped_not_configured", error: "demo" }).where(eq(schema.mailOutbox.id, row.id));
    return { id: row.id, status: "skipped_not_configured" };
  }
  if (!integrations.mail()) {
    await db.update(schema.mailOutbox).set({ status: "skipped_not_configured" }).where(eq(schema.mailOutbox.id, row.id));
    return { id: row.id, status: "skipped_not_configured" };
  }
  try {
    const { Resend } = await import("resend");
    const resend = new Resend(process.env.RESEND_API_KEY);
    const res = await resend.emails.send({
      from: process.env.MAIL_FROM ?? "Next RH <no-reply@example.com>",
      to: mail.to,
      subject: mail.subject,
      html: mail.html,
      text: mail.text,
    });
    if (res.error) throw new Error(res.error.message);
    await db
      .update(schema.mailOutbox)
      .set({ status: "sent", providerId: res.data?.id ?? null, sentAt: new Date() })
      .where(eq(schema.mailOutbox.id, row.id));
    return { id: row.id, status: "sent" };
  } catch (e) {
    await db
      .update(schema.mailOutbox)
      .set({ status: "failed", error: e instanceof Error ? e.message : String(e) })
      .where(eq(schema.mailOutbox.id, row.id));
    return { id: row.id, status: "failed" };
  }
}

export function layoutMail(title: string, bodyHtml: string, cta?: { label: string; url: string }) {
  return `<!doctype html><html lang="fr"><body style="font-family:Helvetica,Arial,sans-serif;background:#f4f3ef;padding:32px;color:#1d1c1a">
  <div style="max-width:560px;margin:0 auto;background:#fffdf9;border:1px solid #e3e0d8;border-radius:12px;padding:32px">
    <p style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#6b6760;margin:0 0 16px">Next RH</p>
    <h1 style="font-size:22px;margin:0 0 16px">${title}</h1>
    <div style="font-size:15px;line-height:1.6">${bodyHtml}</div>
    ${cta ? `<p style="margin:28px 0 0"><a href="${cta.url}" style="display:inline-block;background:#7a1f2b;color:#fffdf9;text-decoration:none;padding:12px 20px;border-radius:8px;font-weight:600">${cta.label}</a></p><p style="font-size:12px;color:#6b6760;margin-top:16px">Ou copiez ce lien : ${cta.url}</p>` : ""}
  </div></body></html>`;
}

