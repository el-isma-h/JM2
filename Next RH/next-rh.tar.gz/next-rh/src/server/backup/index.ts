import "server-only";
import { gunzipSync, gzipSync } from "node:zlib";
import { randomUUID } from "node:crypto";
import type { PoolClient } from "pg";
import { eq } from "drizzle-orm";
import { db, pool, schema } from "@/db";
import { randomToken, sha256 } from "@/lib/crypto";
import { getObject, putObject } from "@/server/storage";

/**
 * Sauvegarde et restauration d'un tenant.
 * - Sauvegarde : export JSON de toutes les lignes liées au tenant (via tenant_id, company_id, employee_id, period_id…)
 *   et des fichiers de stockage, compressé (gzip), stocké sous `backups/`, ligne `backups` avec sha256.
 * - Restauration : toujours vers un NOUVEAU tenant, tous les identifiants remappés, jamais d'écrasement.
 * Les mots de passe, secrets TOTP, sessions et jetons ne sont jamais exportés.
 */

export const BACKUP_FORMAT = "nextrh-tenant-backup";
export const BACKUP_VERSION = 1;

type Scope = "tenant" | "company" | "employee" | "contract" | "period" | "report" | "document" | "conversation";
type Spec = { table: string; column: string; scope: Scope; collect?: Scope };

/**
 * Tables exportées, dans l'ordre d'insertion (dépendances respectées).
 * `collect` : les identifiants de la table alimentent la portée indiquée (ex. employees → employee).
 */
export const BACKUP_TABLES: Spec[] = [
  { table: "tenants", column: "id", scope: "tenant" },
  { table: "companies", column: "tenant_id", scope: "tenant", collect: "company" },
  { table: "establishments", column: "company_id", scope: "company" },
  { table: "company_contacts", column: "company_id", scope: "company" },
  { table: "company_organisms", column: "company_id", scope: "company" },
  { table: "company_memberships", column: "company_id", scope: "company" },
  { table: "invitations", column: "tenant_id", scope: "tenant" },
  { table: "employees", column: "company_id", scope: "company", collect: "employee" },
  { table: "employee_bank_accounts", column: "employee_id", scope: "employee" },
  { table: "contracts", column: "employee_id", scope: "employee", collect: "contract" },
  { table: "contract_amendments", column: "contract_id", scope: "contract" },
  { table: "compensations", column: "employee_id", scope: "employee" },
  { table: "employee_events", column: "employee_id", scope: "employee" },
  { table: "employee_carryovers", column: "employee_id", scope: "employee" },
  { table: "pas_rates", column: "employee_id", scope: "employee" },
  { table: "leave_types", column: "company_id", scope: "company" },
  { table: "leave_balances", column: "employee_id", scope: "employee" },
  { table: "leave_requests", column: "employee_id", scope: "employee" },
  { table: "timesheets", column: "employee_id", scope: "employee" },
  { table: "remote_work_policies", column: "company_id", scope: "company" },
  { table: "remote_work_requests", column: "employee_id", scope: "employee" },
  { table: "expense_reports", column: "employee_id", scope: "employee", collect: "report" },
  { table: "expense_lines", column: "report_id", scope: "report" },
  { table: "lifecycle_workflows", column: "employee_id", scope: "employee" },
  { table: "interviews", column: "employee_id", scope: "employee" },
  { table: "trainings", column: "employee_id", scope: "employee" },
  { table: "hr_requests", column: "company_id", scope: "company" },
  { table: "deadlines", column: "company_id", scope: "company" },
  { table: "payroll_periods", column: "company_id", scope: "company", collect: "period" },
  { table: "payroll_variables", column: "period_id", scope: "period" },
  { table: "payslips", column: "period_id", scope: "period" },
  { table: "payroll_anomalies", column: "period_id", scope: "period" },
  { table: "payroll_filings", column: "period_id", scope: "period" },
  { table: "documents", column: "company_id", scope: "company", collect: "document" },
  { table: "signature_requests", column: "document_id", scope: "document" },
  { table: "document_templates", column: "company_id", scope: "company" },
  { table: "document_drafts", column: "company_id", scope: "company" },
  { table: "subscriptions", column: "company_id", scope: "company" },
  { table: "data_imports", column: "company_id", scope: "company" },
  { table: "assistant_conversations", column: "company_id", scope: "company", collect: "conversation" },
  { table: "assistant_messages", column: "conversation_id", scope: "conversation" },
  { table: "audit_logs", column: "company_id", scope: "company" },
];

/** Colonnes contenant une clé de stockage (fichier à embarquer dans la sauvegarde). */
const FILE_COLUMNS: Record<string, string[]> = { documents: ["storage_key"], employees: ["photo_key"], payroll_filings: ["file_key"] };

type Row = Record<string, unknown>;
export type BackupPayload = {
  format: typeof BACKUP_FORMAT;
  version: number;
  createdAt: string;
  tenantId: string;
  tenantName: string;
  tables: Record<string, Row[]>;
  /** Identités des utilisateurs référencés (sans mot de passe ni secret) : les comptes ne sont jamais recréés. */
  users: { id: string; email: string; first_name: string; last_name: string }[];
  /** Fichiers de stockage, encodés en base64, par clé d'origine. */
  files: Record<string, string>;
  counts: Record<string, number>;
};

async function withClient<T>(fn: (c: PoolClient) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    return await fn(c);
  } finally {
    c.release();
  }
}

/** Collecte toutes les lignes du tenant (lecture cohérente : transaction REPEATABLE READ). */
export async function exportTenant(tenantId: string): Promise<BackupPayload> {
  return withClient(async (c) => {
    await c.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");
    try {
      const scopes: Record<Scope, string[]> = { tenant: [tenantId], company: [], employee: [], contract: [], period: [], report: [], document: [], conversation: [] };
      const tables: Record<string, Row[]> = {};
      for (const spec of BACKUP_TABLES) {
        const ids = scopes[spec.scope];
        if (!ids.length) {
          tables[spec.table] = [];
          continue;
        }
        let rows: Row[];
        if (spec.table === "audit_logs") {
          const r = await c.query(`SELECT row_to_json(t) AS j FROM audit_logs t WHERE t.tenant_id = $1 OR t.company_id = ANY($2::uuid[]) ORDER BY t.created_at`, [tenantId, ids]);
          rows = r.rows.map((x) => x.j);
        } else {
          const r = await c.query(`SELECT row_to_json(t) AS j FROM "${spec.table}" t WHERE t."${spec.column}" = ANY($1::uuid[])`, [ids]);
          rows = r.rows.map((x) => x.j);
        }
        tables[spec.table] = rows;
        if (spec.collect) scopes[spec.collect] = rows.map((r) => String(r.id));
      }
      const [tenant] = tables.tenants;
      if (!tenant) throw new Error("Tenant introuvable.");

      const userIds = new Set<string>();
      for (const r of tables.company_memberships) userIds.add(String(r.user_id));
      for (const r of tables.employees) if (r.user_id) userIds.add(String(r.user_id));
      const u = await c.query(`SELECT id, email, first_name, last_name FROM users WHERE id = ANY($1::uuid[]) OR tenant_id = $2`, [[...userIds], tenantId]);
      await c.query("COMMIT");

      const files: Record<string, string> = {};
      for (const [table, cols] of Object.entries(FILE_COLUMNS)) {
        for (const r of tables[table] ?? []) {
          for (const col of cols) {
            const key = r[col];
            if (typeof key === "string" && key && !(key in files)) {
              try {
                files[key] = (await getObject(key)).toString("base64");
              } catch {
                // Fichier absent du stockage : la ligne est conservée, le fichier est signalé manquant à la restauration.
              }
            }
          }
        }
      }
      const counts = Object.fromEntries(Object.entries(tables).map(([k, v]) => [k, v.length]));
      return {
        format: BACKUP_FORMAT,
        version: BACKUP_VERSION,
        createdAt: new Date().toISOString(),
        tenantId,
        tenantName: String(tenant.name),
        tables,
        users: u.rows,
        files,
        counts,
      };
    } catch (e) {
      await c.query("ROLLBACK").catch(() => undefined);
      throw e;
    }
  });
}

/** Sauvegarde : export + gzip + stockage privé + ligne `backups` (sha256 du fichier compressé). */
export async function backupTenant(tenantId: string, createdBy: string | null): Promise<{ backupId: string; storageKey: string; sizeBytes: number; sha256: string; counts: Record<string, number> }> {
  const payload = await exportTenant(tenantId);
  const gz = gzipSync(Buffer.from(JSON.stringify(payload), "utf8"), { level: 9 });
  const stamp = payload.createdAt.replace(/[:.]/g, "-");
  const storageKey = `backups/${tenantId}/${stamp}-${randomUUID().slice(0, 8)}.json.gz`;
  const stored = await putObject(storageKey, gz);
  const [row] = await db
    .insert(schema.backups)
    .values({ tenantId, scope: "tenant", storageKey, sizeBytes: stored.size, sha256: stored.sha256, status: "done", createdBy })
    .returning({ id: schema.backups.id });
  return { backupId: row.id, storageKey, sizeBytes: stored.size, sha256: stored.sha256, counts: payload.counts };
}

/** Lit et vérifie une sauvegarde (sha256 puis format). */
export async function readBackup(backupId: string): Promise<{ backup: typeof schema.backups.$inferSelect; payload: BackupPayload; raw: Buffer }> {
  const [backup] = await db.select().from(schema.backups).where(eq(schema.backups.id, backupId)).limit(1);
  if (!backup) throw new Error("Sauvegarde introuvable.");
  const raw = await getObject(backup.storageKey);
  const digest = sha256(raw);
  if (!backup.sha256 || digest !== backup.sha256) throw new Error(`Empreinte sha256 différente : fichier altéré ou incomplet (attendu ${backup.sha256 ?? "?"}, obtenu ${digest}).`);
  const payload = JSON.parse(gunzipSync(raw).toString("utf8")) as BackupPayload;
  if (payload.format !== BACKUP_FORMAT || payload.version !== BACKUP_VERSION) throw new Error("Format de sauvegarde non reconnu.");
  return { backup, payload, raw };
}

const UUID_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi;

/** Remplace récursivement toute valeur égale à un identifiant connu (colonnes et JSON). */
function remap(value: unknown, map: Map<string, string>): unknown {
  if (typeof value === "string") return map.get(value) ?? value;
  if (Array.isArray(value)) return value.map((v) => remap(v, map));
  if (value && typeof value === "object") {
    const out: Row = {};
    for (const [k, v] of Object.entries(value as Row)) out[k] = remap(v, map);
    return out;
  }
  return value;
}

export type RestoreResult = { tenantId: string; tenantName: string; counts: Record<string, number>; skipped: Record<string, number>; missingFiles: number };

/**
 * Restaure une sauvegarde vers un nouveau tenant. Tous les UUID des lignes sont remplacés ;
 * les références aux utilisateurs sont conservées si le compte existe encore, retirées sinon.
 */
export async function restoreTenant(backupId: string, opts: { name?: string } = {}): Promise<RestoreResult> {
  const { payload } = await readBackup(backupId);

  const map = new Map<string, string>();
  for (const rows of Object.values(payload.tables)) for (const r of rows) if (typeof r.id === "string") map.set(r.id, randomUUID());

  return withClient(async (c) => {
    await c.query("BEGIN");
    try {
      const refUsers = new Set<string>();
      for (const r of payload.tables.company_memberships ?? []) refUsers.add(String(r.user_id));
      for (const t of ["employees", "invitations", "assistant_conversations"]) {
        for (const r of payload.tables[t] ?? []) {
          for (const col of ["user_id", "invited_by"]) if (typeof r[col] === "string") refUsers.add(String(r[col]));
        }
      }
      const existing = await c.query(`SELECT id FROM users WHERE id = ANY($1::uuid[])`, [[...refUsers]]);
      const liveUsers = new Set(existing.rows.map((x: { id: string }) => x.id));

      const counts: Record<string, number> = {};
      const skipped: Record<string, number> = {};
      const newKeys = new Map<string, string>();
      const restoredAt = new Date();
      const tenantName = opts.name?.trim() || `${payload.tenantName} (restauration du ${restoredAt.toLocaleDateString("fr-FR")})`;
      const droppedConversations = new Set<string>();

      for (const spec of BACKUP_TABLES) {
        const src = payload.tables[spec.table] ?? [];
        const rows: Row[] = [];
        for (const original of src) {
          const r = remap(original, map) as Row;
          if (spec.table === "tenants") {
            r.name = tenantName;
            r.slug = `restauration-${restoredAt.getTime().toString(36)}-${randomToken(4).toLowerCase().replace(/[^a-z0-9]/g, "")}`;
            const settings = (r.settings && typeof r.settings === "object" ? r.settings : {}) as Row;
            r.settings = { ...settings, archive: undefined, restoredFrom: { backupId, tenantId: payload.tenantId, at: restoredAt.toISOString() } };
          }
          if (spec.table === "company_memberships" && !liveUsers.has(String(r.user_id))) {
            skipped[spec.table] = (skipped[spec.table] ?? 0) + 1;
            continue;
          }
          if (spec.table === "assistant_conversations" && !liveUsers.has(String(r.user_id))) {
            droppedConversations.add(String(r.id));
            skipped[spec.table] = (skipped[spec.table] ?? 0) + 1;
            continue;
          }
          if (spec.table === "assistant_messages" && droppedConversations.has(String(r.conversation_id))) {
            skipped[spec.table] = (skipped[spec.table] ?? 0) + 1;
            continue;
          }
          if (spec.table === "employees" && r.user_id && !liveUsers.has(String(r.user_id))) r.user_id = null;
          if (spec.table === "invitations") {
            // Les invitations d'origine ne doivent pas devenir utilisables dans la copie.
            r.token_hash = sha256(randomToken(32));
            if (r.status === "pending") r.status = "revoked";
            if (r.invited_by && !liveUsers.has(String(r.invited_by))) r.invited_by = null;
          }
          for (const col of FILE_COLUMNS[spec.table] ?? []) {
            const oldKey = original[col];
            if (typeof oldKey === "string" && oldKey) {
              const nk = newKeys.get(oldKey) ?? oldKey.replace(UUID_RE, (m) => map.get(m) ?? m);
              newKeys.set(oldKey, nk === oldKey ? `restored/${randomUUID()}/${oldKey}` : nk);
              r[col] = newKeys.get(oldKey);
            }
          }
          rows.push(r);
        }
        if (rows.length) {
          // json_populate_recordset : types PostgreSQL natifs (date, numeric, jsonb, inet) sans conversion côté JS.
          for (let i = 0; i < rows.length; i += 500) {
            await c.query(`INSERT INTO "${spec.table}" SELECT * FROM json_populate_recordset(NULL::"${spec.table}", $1::json)`, [JSON.stringify(rows.slice(i, i + 500))]);
          }
        }
        counts[spec.table] = rows.length;
      }

      let missingFiles = 0;
      for (const [oldKey, nk] of newKeys) {
        const b64 = payload.files[oldKey];
        if (!b64) {
          missingFiles++;
          continue;
        }
        await putObject(nk, Buffer.from(b64, "base64"));
      }
      await c.query("COMMIT");
      return { tenantId: map.get(payload.tenantId)!, tenantName, counts, skipped, missingFiles };
    } catch (e) {
      await c.query("ROLLBACK").catch(() => undefined);
      throw e;
    }
  });
}
