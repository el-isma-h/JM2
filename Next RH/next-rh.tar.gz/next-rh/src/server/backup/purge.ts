import "server-only";
import { and, eq, inArray, isNotNull, notInArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { deleteObject } from "@/server/storage";

/**
 * Suppression définitive d'un tenant : lignes (cascade depuis `tenants`), fichiers de stockage,
 * utilisateurs rattachés qui n'ont aucun accès ailleurs. Les administrateurs plateforme ne sont jamais supprimés.
 * Le journal d'audit est conservé (pas de clé étrangère).
 */
export async function purgeTenant(tenantId: string): Promise<{ companies: number; users: number; files: number }> {
  const companies = await db.select({ id: schema.companies.id }).from(schema.companies).where(eq(schema.companies.tenantId, tenantId));
  const companyIds = companies.map((c) => c.id);

  const keys: string[] = [];
  if (companyIds.length) {
    const docs = await db.select({ k: schema.documents.storageKey }).from(schema.documents).where(inArray(schema.documents.companyId, companyIds));
    keys.push(...docs.map((d) => d.k));
    const photos = await db
      .select({ k: schema.employees.photoKey })
      .from(schema.employees)
      .where(and(inArray(schema.employees.companyId, companyIds), isNotNull(schema.employees.photoKey)));
    keys.push(...photos.map((p) => p.k!).filter(Boolean));
    const filings = await db
      .select({ k: schema.payrollFilings.fileKey })
      .from(schema.payrollFilings)
      .innerJoin(schema.payrollPeriods, eq(schema.payrollPeriods.id, schema.payrollFilings.periodId))
      .where(and(inArray(schema.payrollPeriods.companyId, companyIds), isNotNull(schema.payrollFilings.fileKey)));
    keys.push(...filings.map((f) => f.k!).filter(Boolean));
  }
  const backups = await db.select({ k: schema.backups.storageKey }).from(schema.backups).where(eq(schema.backups.tenantId, tenantId));
  keys.push(...backups.map((b) => b.k));

  // Utilisateurs du tenant : supprimés sauf s'ils ont un accès à une entreprise d'un autre tenant.
  const tenantUsers = await db
    .select({ id: schema.users.id, role: schema.users.platformRole })
    .from(schema.users)
    .where(eq(schema.users.tenantId, tenantId));
  let deletedUsers = 0;
  await db.transaction(async (tx) => {
    for (const u of tenantUsers) {
      if (u.role === "platform_admin") {
        await tx.update(schema.users).set({ tenantId: null }).where(eq(schema.users.id, u.id));
        continue;
      }
      const elsewhere = await tx
        .select({ id: schema.companyMemberships.id })
        .from(schema.companyMemberships)
        .where(
          companyIds.length
            ? and(eq(schema.companyMemberships.userId, u.id), notInArray(schema.companyMemberships.companyId, companyIds))
            : eq(schema.companyMemberships.userId, u.id),
        )
        .limit(1);
      if (elsewhere.length) {
        await tx.update(schema.users).set({ tenantId: null }).where(eq(schema.users.id, u.id));
      } else {
        await tx.delete(schema.users).where(eq(schema.users.id, u.id));
        deletedUsers++;
      }
    }
    // company_memberships.user_id n'a pas de clé étrangère : la cascade depuis companies les supprime.
    await tx.delete(schema.jobs).where(eq(schema.jobs.tenantId, tenantId));
    await tx.delete(schema.tenants).where(eq(schema.tenants.id, tenantId));
  });

  let files = 0;
  for (const k of new Set(keys)) {
    await deleteObject(k);
    files++;
  }
  return { companies: companyIds.length, users: deletedUsers, files };
}
