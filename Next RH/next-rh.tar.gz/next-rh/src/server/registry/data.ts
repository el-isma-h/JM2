/**
 * Registre des traitements de Next RH (art. 30 RGPD) : traitements réellement mis en oeuvre par l'application.
 * Durées : référentiel CNIL « Durées de conservation : gestion des ressources humaines » (avril 2026) et textes cités.
 * Module pur, chargé par seedRegistry().
 */

export type RetentionItem = { name: string; retention: string; basis: string };

export type RegistrySeedRow = {
  name: string;
  purpose: string;
  dataCategories: RetentionItem[];
  processor: string;
  location: string;
  retention: string;
  legalBasis: string;
};

const HOST = "Hébergeur à définir (application et base PostgreSQL)";
const HOST_LOC = "À définir : hébergement dans l'Union européenne recommandé";

export const REGISTRY_ROWS: RegistrySeedRow[] = [
  {
    name: "Gestion administrative du personnel",
    purpose: "Tenue du dossier salarié, contrats et avenants, registre unique du personnel, annuaire et organigramme, échéances (périodes d'essai, fins de CDD).",
    dataCategories: [
      { name: "Identité, coordonnées, situation familiale utile", retention: "Durée de la relation de travail, puis archivage 5 ans après le départ", basis: "Référentiel CNIL RH ; prescription de droit commun (art. 2224 du code civil)" },
      { name: "NIR (chiffré AES-256-GCM)", retention: "Durée de la relation de travail, puis 6 ans pour les obligations déclaratives", basis: "Art. L243-16 du code de la sécurité sociale" },
      { name: "Contrats, avenants, vie professionnelle", retention: "Durée de la relation de travail, puis archivage 5 ans après le départ", basis: "Référentiel CNIL RH" },
      { name: "Registre unique du personnel", retention: "Durée de présence dans les effectifs, puis 5 ans à compter du départ", basis: "Art. R1221-26 du code du travail" },
    ],
    processor: HOST,
    location: HOST_LOC,
    retention: "Durée de la relation de travail ; archivage intermédiaire 5 ans après le départ (registre du personnel : 5 ans après le départ).",
    legalBasis: "Obligation légale (art. 6.1.c RGPD) et exécution du contrat de travail (art. 6.1.b).",
  },
  {
    name: "Paie : calcul et bulletins",
    purpose: "Calcul des rémunérations par le moteur de paie, édition et mise à disposition des bulletins, virements des salaires.",
    dataCategories: [
      { name: "Données nécessaires au calcul (assiette, variables, absences)", retention: "Le temps du calcul (1 mois au maximum), puis archivage 6 ans", basis: "Art. L243-16 du code de la sécurité sociale" },
      { name: "Bulletins de paie (double employeur)", retention: "5 ans à compter de leur remise au salarié", basis: "Art. L3243-4 du code du travail" },
      { name: "Bulletins électroniques mis à disposition du salarié", retention: "50 ans ou jusqu'aux 75 ans du salarié", basis: "Art. D3243-8 du code du travail" },
      { name: "Coordonnées bancaires (IBAN chiffré AES-256-GCM)", retention: "Durée de la relation de travail", basis: "Exécution du contrat (paiement du salaire)" },
      { name: "Éléments de preuve des salaires versés", retention: "3 ans (action en paiement des salaires)", basis: "Art. L3245-1 du code du travail" },
    ],
    processor: HOST,
    location: HOST_LOC,
    retention: "Bulletins : 5 ans (employeur) ; données de calcul : 6 ans ; bulletins électroniques du salarié : 50 ans ou jusqu'à 75 ans.",
    legalBasis: "Obligation légale (art. 6.1.c) et exécution du contrat de travail (art. 6.1.b).",
  },
  {
    name: "Déclarations sociales (DSN)",
    purpose: "Préparation, contrôle et suivi des déclarations sociales nominatives et des cotisations.",
    dataCategories: [
      { name: "Contenu des déclarations et accusés", retention: "Jusqu'au certificat de conformité, puis archivage 6 ans", basis: "Art. R133-13 et L243-16 du code de la sécurité sociale" },
      { name: "Taux de prélèvement à la source", retention: "6 ans", basis: "Art. L102 B du livre des procédures fiscales" },
    ],
    processor: HOST,
    location: HOST_LOC,
    retention: "6 ans à compter de l'établissement ou de la réception des éléments.",
    legalBasis: "Obligation légale (art. 6.1.c).",
  },
  {
    name: "Congés, absences et télétravail",
    purpose: "Demandes et validation des congés, soldes, planning d'équipe, jours de télétravail et report en paie.",
    dataCategories: [
      { name: "Demandes, soldes, plannings", retention: "Jusqu'à l'édition du bulletin de la période, puis 3 ans", basis: "Art. L3245-1 du code du travail (prescription salariale)" },
      { name: "Justificatifs d'absence (sans diagnostic médical)", retention: "Jusqu'à l'édition du bulletin, puis 3 ans", basis: "Référentiel CNIL RH ; minimisation" },
    ],
    processor: HOST,
    location: HOST_LOC,
    retention: "Base active jusqu'au bulletin de la période ; archivage 3 ans.",
    legalBasis: "Exécution du contrat de travail (art. 6.1.b) et obligation légale (art. 6.1.c).",
  },
  {
    name: "Temps de travail",
    purpose: "Feuilles de temps, décompte des heures supplémentaires et complémentaires.",
    dataCategories: [
      { name: "Relevés d'heures", retention: "Jusqu'au bulletin de la période, puis 1 an (ou la période de référence si elle dépasse 1 an)", basis: "Art. D3171-16 du code du travail" },
      { name: "Décompte des salariés au forfait", retention: "3 ans", basis: "Art. L3245-1 du code du travail" },
    ],
    processor: HOST,
    location: HOST_LOC,
    retention: "1 an après le bulletin de la période (forfait : 3 ans).",
    legalBasis: "Obligation légale (art. 6.1.c).",
  },
  {
    name: "Notes de frais",
    purpose: "Saisie, justificatifs, validation et remboursement des frais professionnels.",
    dataCategories: [
      { name: "Pièces justificatives comptables", retention: "10 ans à compter de la clôture de l'exercice", basis: "Art. L123-22 du code de commerce" },
      { name: "Données fiscales associées", retention: "6 ans", basis: "Art. L102 B du livre des procédures fiscales" },
    ],
    processor: HOST,
    location: HOST_LOC,
    retention: "Justificatifs : 10 ans ; données fiscales : 6 ans.",
    legalBasis: "Obligation légale (art. 6.1.c) et exécution du contrat (art. 6.1.b).",
  },
  {
    name: "Assistant IA et aide à la rédaction",
    purpose: "Réponses aux questions des gestionnaires et aide à la rédaction de documents RH, sous les permissions de l'utilisateur. Activé uniquement si l'entreprise le configure.",
    dataCategories: [
      { name: "Questions et contexte strictement nécessaire : NIR, IBAN, e-mails et téléphones masqués avant envoi, montants masqués si l'utilisateur n'est pas habilité", retention: "12 mois recommandés dans l'application (purge à planifier)", basis: "Minimisation (art. 5.1.c RGPD)" },
      { name: "Données transmises au fournisseur d'IA", retention: "Selon les conditions commerciales de l'API Anthropic ; par défaut, pas d'entraînement des modèles sur ces données", basis: "Contrat de sous-traitance (art. 28 RGPD)" },
    ],
    processor: "Anthropic PBC (API Claude), uniquement si ANTHROPIC_API_KEY est configurée",
    location: "États-Unis : transfert encadré par les garanties contractuelles du fournisseur (art. 46 RGPD)",
    retention: "Conversations : 12 mois recommandés ; aucune réutilisation des données RH pour l'entraînement de modèles.",
    legalBasis: "Intérêt légitime de l'employeur (art. 6.1.f), activation explicite par le client.",
  },
  {
    name: "E-mails transactionnels",
    purpose: "Vérification d'adresse, réinitialisation de mot de passe, invitations, notifications et rappels d'échéances.",
    dataCategories: [
      { name: "Adresse e-mail, nom, contenu du message (liens à usage unique)", retention: "Journal d'envoi : 12 mois recommandés (purge à planifier)", basis: "Exécution du contrat (art. 6.1.b)" },
    ],
    processor: "Resend (Resend Inc.), uniquement si RESEND_API_KEY est configurée ; sinon aucun envoi, journal local uniquement",
    location: "États-Unis par défaut (région selon l'offre du fournisseur) : transfert encadré par les garanties contractuelles",
    retention: "Journal d'envoi : 12 mois recommandés.",
    legalBasis: "Exécution du contrat (art. 6.1.b).",
  },
  {
    name: "Hébergement, sauvegardes et journal d'audit",
    purpose: "Hébergement de l'application, stockage privé des documents, sauvegardes, journalisation des accès et actions sensibles.",
    dataCategories: [
      { name: "Ensemble des données des entreprises clientes (sauvegardes)", retention: "30 jours glissants recommandés pour les sauvegardes", basis: "Sécurité du traitement (art. 32 RGPD)" },
      { name: "Journal d'audit (utilisateur, action, date, adresse IP)", retention: "6 mois à 1 an", basis: "Recommandation CNIL sur la journalisation ; art. 32 RGPD" },
    ],
    processor: HOST,
    location: HOST_LOC,
    retention: "Sauvegardes : 30 jours glissants recommandés ; journal d'audit : 6 mois à 1 an.",
    legalBasis: "Obligation de sécurité (art. 32 RGPD) et intérêt légitime (art. 6.1.f).",
  },
];
