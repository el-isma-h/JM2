/** Lecture de fichiers CSV (UTF-8 ou Windows-1252, séparateur détecté). Module pur. */
import Papa from "papaparse";

export type ParsedCsv = { headers: string[]; rows: Record<string, string>[]; delimiter: string; encoding: "utf-8" | "windows-1252" };

export function decodeText(data: Uint8Array): { text: string; encoding: "utf-8" | "windows-1252" } {
  const utf8 = new TextDecoder("utf-8", { fatal: false }).decode(data);
  if (!utf8.includes("�")) return { text: utf8.replace(/^﻿/, ""), encoding: "utf-8" };
  return { text: new TextDecoder("windows-1252").decode(data), encoding: "windows-1252" };
}

export function parseCsv(data: Uint8Array): ParsedCsv | { error: string } {
  const { text, encoding } = decodeText(data);
  if (!text.trim()) return { error: "Le fichier est vide." };
  const firstLine = text.split(/\r?\n/, 1)[0] ?? "";
  const counts = [";", ",", "\t"].map((d) => ({ d, n: firstLine.split(d).length - 1 }));
  const delimiter = counts.sort((a, b) => b.n - a.n)[0].n > 0 ? counts[0].d : ";";
  const res = Papa.parse<string[]>(text, { delimiter, skipEmptyLines: "greedy" });
  const matrix = res.data.filter((r) => Array.isArray(r) && r.some((c) => String(c ?? "").trim() !== ""));
  if (matrix.length < 2) return { error: "Le fichier doit contenir une ligne d'en-têtes et au moins une ligne de données." };
  const rawHeaders = matrix[0].map((h) => String(h ?? "").trim());
  const headers: string[] = [];
  rawHeaders.forEach((h, i) => {
    let name = h || `Colonne ${i + 1}`;
    let n = 2;
    while (headers.includes(name)) name = `${h || "Colonne"} (${n++})`;
    headers.push(name);
  });
  if (matrix.length - 1 > 5000) return { error: "Le fichier dépasse 5 000 lignes : découpez-le en plusieurs imports." };
  const rows = matrix.slice(1).map((cells) => {
    const o: Record<string, string> = {};
    headers.forEach((h, i) => (o[h] = String(cells[i] ?? "").trim()));
    return o;
  });
  return { headers, rows, delimiter, encoding };
}
