/**
 * Reprise des données : définition des fichiers attendus, correspondance automatique des colonnes,
 * contrôle ligne par ligne et doublons internes au fichier. Module pur (aucun accès base), testable.
 */
import { checkBic, checkIban, checkNir, checkPostalCode, checkSiret, isEmail, parseAmountToCents, parseDateInput, parseDecimal } from "../../lib/validators";

export type ImportKind = "employees" | "compensations" | "carryovers" | "leave_balances";
type FieldType = "text" | "date" | "amount" | "decimal" | "int" | "nir" | "iban" | "bic" | "email" | "postal" | "siret" | "enum";

export type FieldDef = {
  key: string;
  label: string;
  type: FieldType;
  required?: boolean;
  aliases: string[];
  options?: Record<string, string>;
  example: string;
  help?: string;
};

export type ImportSpec = { kind: ImportKind; label: string; description: string; fields: FieldDef[] };

const contractTypes: Record<string, string> = {
  cdi: "CDI", cdd: "CDD", apprentissage: "APPRENTISSAGE", apprenti: "APPRENTISSAGE", professionnalisation: "PROFESSIONNALISATION",
  "contrat pro": "PROFESSIONNALISATION", pro: "PROFESSIONNALISATION", stage: "STAGE", stagiaire: "STAGE", interim: "INTERIM", mandat: "MANDAT",
  "mandat social": "MANDAT",
};
const categories: Record<string, string> = {
  cadre: "cadre", "non cadre": "non_cadre", noncadre: "non_cadre", "non-cadre": "non_cadre", employe: "non_cadre", ouvrier: "non_cadre",
  etam: "non_cadre", "agent de maitrise": "non_cadre", technicien: "non_cadre", "cadre dirigeant": "cadre_dirigeant", apprenti: "apprenti",
  stagiaire: "stagiaire",
};
const genders: Record<string, string> = { f: "F", femme: "F", mme: "F", madame: "F", m: "M", homme: "M", "m.": "M", mr: "M", monsieur: "M", x: "X" };
const bases: Record<string, string> = { mensuel: "monthly", mois: "monthly", monthly: "monthly", horaire: "hourly", heure: "hourly", hourly: "hourly", annuel: "annual", an: "annual", annual: "annual" };

export const IMPORT_SPECS: Record<ImportKind, ImportSpec> = {
  employees: {
    kind: "employees",
    label: "Salariés, contrats et rémunération actuelle",
    description: "Une ligne par salarié : identité, coordonnées, poste, contrat en cours et salaire de base actuel. Le matricule sert ensuite à rattacher les autres fichiers.",
    fields: [
      { key: "employeeNumber", label: "Matricule", type: "text", required: true, aliases: ["matricule", "numero salarie", "n salarie", "id salarie", "code salarie"], example: "S0142", help: "Identifiant unique du salarié dans votre ancien logiciel." },
      { key: "lastName", label: "Nom", type: "text", required: true, aliases: ["nom", "nom usage", "nom d usage", "last name"], example: "Lefebvre" },
      { key: "firstName", label: "Prénom", type: "text", required: true, aliases: ["prenom", "first name"], example: "Maëlle" },
      { key: "birthName", label: "Nom de naissance", type: "text", aliases: ["nom de naissance", "nom de jeune fille", "nom patronymique"], example: "Garnier" },
      { key: "gender", label: "Sexe", type: "enum", options: genders, aliases: ["sexe", "genre", "civilite"], example: "F" },
      { key: "birthDate", label: "Date de naissance", type: "date", aliases: ["date de naissance", "naissance", "ne le", "date naissance"], example: "14/03/1991" },
      { key: "birthPlace", label: "Lieu de naissance", type: "text", aliases: ["lieu de naissance", "commune de naissance"], example: "Nantes" },
      { key: "nationality", label: "Nationalité", type: "text", aliases: ["nationalite"], example: "Française" },
      { key: "nir", label: "N° de sécurité sociale", type: "nir", aliases: ["nir", "numero de securite sociale", "n securite sociale", "secu", "numero ss", "insee"], example: "291034412345649", help: "15 caractères, clé comprise. Chiffré dès l'import." },
      { key: "email", label: "E-mail professionnel", type: "email", aliases: ["email", "e mail", "mail", "email pro", "adresse email", "courriel"], example: "maelle.lefebvre@exemple.fr" },
      { key: "phone", label: "Téléphone", type: "text", aliases: ["telephone", "tel", "portable", "mobile"], example: "06 12 48 73 90" },
      { key: "addressLine1", label: "Adresse", type: "text", aliases: ["adresse", "adresse 1", "rue"], example: "18 rue des Olivettes" },
      { key: "postalCode", label: "Code postal", type: "postal", aliases: ["code postal", "cp"], example: "44000" },
      { key: "city", label: "Ville", type: "text", aliases: ["ville", "commune"], example: "Nantes" },
      { key: "jobTitle", label: "Poste", type: "text", aliases: ["poste", "emploi", "intitule du poste", "fonction"], example: "Chargée de clientèle" },
      { key: "department", label: "Service", type: "text", aliases: ["service", "departement", "equipe"], example: "Relation client" },
      { key: "establishment", label: "Établissement (nom ou SIRET)", type: "text", aliases: ["etablissement", "siret", "site", "siret etablissement"], example: "Siège", help: "Nom de l'établissement tel que saisi dans Next RH, ou son SIRET." },
      { key: "hireDate", label: "Date d'entrée", type: "date", required: true, aliases: ["date d entree", "entree", "date embauche", "date d embauche", "anciennete"], example: "02/09/2019" },
      { key: "contractType", label: "Type de contrat", type: "enum", required: true, options: contractTypes, aliases: ["type de contrat", "contrat", "nature du contrat"], example: "CDI" },
      { key: "category", label: "Catégorie", type: "enum", options: categories, aliases: ["categorie", "statut", "college", "statut cadre"], example: "Non cadre" },
      { key: "contractEndDate", label: "Date de fin de contrat", type: "date", aliases: ["date de fin", "fin de contrat", "date fin contrat"], example: "" },
      { key: "trialEndDate", label: "Fin de période d'essai", type: "date", aliases: ["fin periode d essai", "fin d essai", "periode d essai"], example: "" },
      { key: "weeklyHours", label: "Heures hebdomadaires", type: "decimal", aliases: ["heures hebdo", "horaire hebdomadaire", "duree hebdomadaire", "heures par semaine"], example: "35" },
      { key: "classification", label: "Classification", type: "text", aliases: ["classification", "niveau", "position", "echelon"], example: "Niveau 2" },
      { key: "coefficient", label: "Coefficient", type: "text", aliases: ["coefficient", "coef", "indice"], example: "250" },
      { key: "grossMonthly", label: "Salaire de base brut mensuel", type: "amount", required: true, aliases: ["salaire de base", "salaire brut", "brut mensuel", "salaire", "remuneration", "salaire mensuel"], example: "2187,40" },
      { key: "iban", label: "IBAN", type: "iban", aliases: ["iban", "rib"], example: "FR7630006000011234567890189", help: "Chiffré dès l'import, jamais affiché en clair." },
      { key: "bic", label: "BIC", type: "bic", aliases: ["bic", "swift"], example: "AGRIFRPP" },
    ],
  },
  compensations: {
    kind: "compensations",
    label: "Historique des rémunérations",
    description: "Une ligne par changement de salaire passé. Utile pour expliquer les écarts d'un mois à l'autre et pour l'ancienneté.",
    fields: [
      { key: "employeeNumber", label: "Matricule", type: "text", required: true, aliases: ["matricule", "numero salarie", "id salarie"], example: "S0142" },
      { key: "effectiveDate", label: "Date d'effet", type: "date", required: true, aliases: ["date d effet", "date", "a compter du", "effet"], example: "01/01/2026" },
      { key: "grossAmount", label: "Montant brut", type: "amount", required: true, aliases: ["montant", "salaire", "brut", "salaire brut", "montant brut"], example: "2187,40" },
      { key: "basis", label: "Base (mensuel, horaire, annuel)", type: "enum", options: bases, aliases: ["base", "periodicite", "unite"], example: "Mensuel" },
      { key: "reason", label: "Motif", type: "text", aliases: ["motif", "raison", "commentaire"], example: "Augmentation annuelle" },
    ],
  },
  carryovers: {
    kind: "carryovers",
    label: "Cumuls annuels (reprise en cours d'année)",
    description: "Une ligne par salarié : cumuls de l'année civile jusqu'au dernier mois payé par l'ancien logiciel. Indispensable si la première paie Next RH n'est pas celle de janvier.",
    fields: [
      { key: "employeeNumber", label: "Matricule", type: "text", required: true, aliases: ["matricule", "numero salarie", "id salarie"], example: "S0142" },
      { key: "year", label: "Année", type: "int", required: true, aliases: ["annee", "exercice"], example: "2026" },
      { key: "throughMonth", label: "Dernier mois inclus (1 à 12)", type: "int", required: true, aliases: ["mois", "dernier mois", "jusqu au mois", "mois de fin"], example: "9" },
      { key: "grossYtd", label: "Brut cumulé", type: "amount", required: true, aliases: ["brut cumule", "cumul brut", "brut"], example: "19686,60" },
      { key: "netTaxableYtd", label: "Net imposable cumulé", type: "amount", required: true, aliases: ["net imposable cumule", "cumul net imposable", "net imposable", "net fiscal"], example: "15412,08" },
      { key: "netPaidYtd", label: "Net payé cumulé", type: "amount", aliases: ["net paye cumule", "net a payer cumule", "net paye"], example: "14736,91" },
      { key: "pasYtd", label: "Impôt prélevé à la source cumulé", type: "amount", aliases: ["pas cumule", "prelevement a la source", "pas", "impot cumule"], example: "675,17" },
      { key: "employeeContribYtd", label: "Cotisations salariales cumulées", type: "amount", aliases: ["cotisations salariales", "charges salariales"], example: "4274,52" },
      { key: "employerContribYtd", label: "Cotisations patronales cumulées", type: "amount", aliases: ["cotisations patronales", "charges patronales"], example: "7681,33" },
      { key: "hoursYtd", label: "Heures cumulées", type: "decimal", aliases: ["heures cumulees", "heures", "heures travaillees"], example: "1365,03" },
      { key: "paidLeaveAcquired", label: "Congés acquis (période en cours)", type: "decimal", aliases: ["cp acquis", "conges acquis"], example: "8,32" },
      { key: "paidLeaveTaken", label: "Congés pris (période en cours)", type: "decimal", aliases: ["cp pris", "conges pris"], example: "3" },
      { key: "paidLeavePrevBalance", label: "Solde de congés N-1", type: "decimal", aliases: ["solde n-1", "cp n-1", "reliquat"], example: "12,5" },
    ],
  },
  leave_balances: {
    kind: "leave_balances",
    label: "Soldes de congés",
    description: "Une ligne par salarié et par type de congé (CP, RTT…) pour la période de référence en cours.",
    fields: [
      { key: "employeeNumber", label: "Matricule", type: "text", required: true, aliases: ["matricule", "numero salarie", "id salarie"], example: "S0142" },
      { key: "leaveCode", label: "Type de congé (code)", type: "text", required: true, aliases: ["type", "code", "type de conge", "code absence"], example: "CP", help: "Code du type d'absence dans Next RH : CP, RTT…" },
      { key: "periodStart", label: "Début de période", type: "date", required: true, aliases: ["debut", "debut de periode", "date debut", "du"], example: "01/06/2026" },
      { key: "periodEnd", label: "Fin de période", type: "date", required: true, aliases: ["fin", "fin de periode", "date fin", "au"], example: "31/05/2027" },
      { key: "acquired", label: "Acquis", type: "decimal", required: true, aliases: ["acquis", "droits"], example: "8,32" },
      { key: "taken", label: "Pris", type: "decimal", aliases: ["pris", "consommes"], example: "2" },
      { key: "adjustment", label: "Ajustement", type: "decimal", aliases: ["ajustement", "correction", "report"], example: "0" },
    ],
  },
};

export const IMPORT_KINDS = Object.keys(IMPORT_SPECS) as ImportKind[];

export function isImportKind(v: string): v is ImportKind {
  return v in IMPORT_SPECS;
}

/** Normalise un en-tête : minuscules, sans accents ni ponctuation. */
export function normalizeHeader(h: string): string {
  return h
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[°º]/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

/** Associe chaque champ attendu à une colonne du fichier (correspondance exacte, puis partielle). */
export function autoMap(kind: ImportKind, headers: string[]): Record<string, string | null> {
  const spec = IMPORT_SPECS[kind];
  const normalized = headers.map((h) => ({ raw: h, n: normalizeHeader(h) }));
  const used = new Set<string>();
  const out: Record<string, string | null> = {};
  for (const f of spec.fields) {
    const candidates = [normalizeHeader(f.label), normalizeHeader(f.key), ...f.aliases.map(normalizeHeader)];
    let hit = normalized.find((h) => !used.has(h.raw) && candidates.includes(h.n));
    if (!hit) hit = normalized.find((h) => !used.has(h.raw) && candidates.some((c) => c.length >= 4 && (h.n.startsWith(c) || h.n.endsWith(c))));
    out[f.key] = hit ? hit.raw : null;
    if (hit) used.add(hit.raw);
  }
  return out;
}

export type RowIssue = { line: number; field?: string; level: "error" | "warning"; message: string };
export type ParsedValue = string | number | null;
export type ParsedRow = { line: number; values: Record<string, ParsedValue> };
export type Duplicate = { line: number; otherLine?: number; existingEmployeeId?: string; reason: string };

export type ValidationContext = { siren?: string | null; firstPeriod?: string | null; leaveCodes?: string[] };

function parseValue(f: FieldDef, raw: string, ctx: ValidationContext): { value: ParsedValue; error?: string } {
  const v = raw.trim();
  if (!v) return { value: null };
  switch (f.type) {
    case "text":
      return { value: v.slice(0, 200) };
    case "date": {
      const d = parseDateInput(v);
      return d ? { value: d } : { value: null, error: `Date illisible « ${v} » : utilisez JJ/MM/AAAA.` };
    }
    case "amount": {
      const c = parseAmountToCents(v);
      return c === null ? { value: null, error: `Montant illisible « ${v} » : utilisez par exemple 2187,40.` } : { value: c };
    }
    case "decimal": {
      const d = parseDecimal(v, 2);
      return d === null ? { value: null, error: `Nombre illisible « ${v} ».` } : { value: d };
    }
    case "int": {
      return /^\d+$/.test(v) ? { value: Number(v) } : { value: null, error: `Nombre entier attendu, reçu « ${v} ».` };
    }
    case "nir": {
      const r = checkNir(v);
      return r.ok ? { value: r.value } : { value: null, error: r.error };
    }
    case "iban": {
      const r = checkIban(v);
      return r.ok ? { value: r.value } : { value: null, error: r.error };
    }
    case "bic": {
      const r = checkBic(v);
      return r.ok ? { value: r.value } : { value: null, error: r.error };
    }
    case "email":
      return isEmail(v) ? { value: v.toLowerCase() } : { value: null, error: `Adresse e-mail invalide « ${v} ».` };
    case "postal": {
      const r = checkPostalCode(v);
      return r.ok ? { value: r.value } : { value: null, error: r.error };
    }
    case "siret": {
      const r = checkSiret(v, ctx.siren);
      return r.ok ? { value: r.value } : { value: null, error: r.error };
    }
    case "enum": {
      const key = normalizeHeader(v);
      const opt = f.options?.[key] ?? f.options?.[v.toLowerCase()] ?? Object.values(f.options ?? {}).find((o) => o.toLowerCase() === v.toLowerCase());
      return opt ? { value: opt } : { value: null, error: `Valeur non reconnue « ${v} ».` };
    }
  }
}

/** Contrôle toutes les lignes selon la correspondance de colonnes choisie. */
export function validateRows(kind: ImportKind, rows: Record<string, string>[], mapping: Record<string, string | null>, ctx: ValidationContext = {}) {
  const spec = IMPORT_SPECS[kind];
  const issues: RowIssue[] = [];
  const parsed: ParsedRow[] = [];
  for (const f of spec.fields) {
    if (f.required && !mapping[f.key]) issues.push({ line: 1, field: f.key, level: "error", message: `Colonne obligatoire non associée : « ${f.label} ».` });
  }
  const takeover = ctx.firstPeriod ? ctx.firstPeriod.split("-").map(Number) : null;

  rows.forEach((row, i) => {
    const line = i + 2;
    const values: Record<string, ParsedValue> = {};
    for (const f of spec.fields) {
      const col = mapping[f.key];
      const raw = col ? String(row[col] ?? "") : "";
      const { value, error } = parseValue(f, raw, ctx);
      values[f.key] = value;
      if (error) issues.push({ line, field: f.key, level: "error", message: `${f.label} : ${error}` });
      else if (f.required && col && value === null) issues.push({ line, field: f.key, level: "error", message: `${f.label} : valeur manquante.` });
    }

    if (kind === "employees") {
      if (values.contractType === "CDD" && !values.contractEndDate) issues.push({ line, field: "contractEndDate", level: "warning", message: "CDD sans date de fin : à compléter dans le dossier." });
      if (values.contractEndDate && values.hireDate && String(values.contractEndDate) < String(values.hireDate)) issues.push({ line, field: "contractEndDate", level: "error", message: "La date de fin de contrat précède la date d'entrée." });
      if (values.trialEndDate && values.hireDate && String(values.trialEndDate) < String(values.hireDate)) issues.push({ line, field: "trialEndDate", level: "error", message: "La fin de période d'essai précède la date d'entrée." });
      if (values.birthDate && values.hireDate) {
        const age = (Date.parse(String(values.hireDate)) - Date.parse(String(values.birthDate))) / (365.25 * 86400_000);
        if (age < 14) issues.push({ line, field: "birthDate", level: "error", message: "Date de naissance incohérente avec la date d'entrée (moins de 14 ans)." });
      }
      if (typeof values.grossMonthly === "number" && values.grossMonthly <= 0) issues.push({ line, field: "grossMonthly", level: "error", message: "Le salaire de base doit être positif." });
      if (values.weeklyHours && (Number(values.weeklyHours) <= 0 || Number(values.weeklyHours) > 48)) issues.push({ line, field: "weeklyHours", level: "error", message: "Durée hebdomadaire hors limites (0 à 48 heures)." });
      if (!values.nir && mapping.nir) issues.push({ line, field: "nir", level: "warning", message: "N° de sécurité sociale absent : il sera demandé avant la première déclaration." });
      if (values.iban && !values.bic) issues.push({ line, field: "bic", level: "warning", message: "IBAN sans BIC : le BIC reste facultatif pour un compte en zone SEPA." });
      if (values.birthDate && values.nir && typeof values.nir === "string") {
        const yy = String(values.birthDate).slice(2, 4);
        const mm = String(values.birthDate).slice(5, 7);
        if (values.nir.slice(1, 3) !== yy || (Number(values.nir.slice(3, 5)) <= 12 && values.nir.slice(3, 5) !== mm)) {
          issues.push({ line, field: "nir", level: "warning", message: "Le N° de sécurité sociale ne correspond pas à l'année ou au mois de naissance : à vérifier." });
        }
        if (values.gender && ((values.gender === "F" && values.nir[0] === "1") || (values.gender === "M" && values.nir[0] === "2"))) {
          issues.push({ line, field: "nir", level: "warning", message: "Le premier chiffre du N° de sécurité sociale ne correspond pas au sexe indiqué." });
        }
      }
    }

    if (kind === "carryovers") {
      const m = Number(values.throughMonth);
      if (values.throughMonth !== null && (m < 1 || m > 12)) issues.push({ line, field: "throughMonth", level: "error", message: "Le dernier mois inclus doit être compris entre 1 et 12." });
      if (typeof values.grossYtd === "number" && typeof values.netTaxableYtd === "number" && values.grossYtd < values.netTaxableYtd) {
        issues.push({ line, field: "netTaxableYtd", level: "error", message: "Le net imposable cumulé dépasse le brut cumulé : les colonnes sont probablement inversées." });
      }
      if (typeof values.netPaidYtd === "number" && typeof values.grossYtd === "number" && values.netPaidYtd > values.grossYtd) {
        issues.push({ line, field: "netPaidYtd", level: "error", message: "Le net payé cumulé dépasse le brut cumulé." });
      }
      if (takeover && values.year !== null && values.throughMonth !== null) {
        const [ty, tm] = takeover;
        if (tm > 1) {
          if (Number(values.year) !== ty) issues.push({ line, field: "year", level: "error", message: `Année ${values.year} : la reprise porte sur ${ty} (première paie Next RH : ${String(tm).padStart(2, "0")}/${ty}).` });
          else if (m !== tm - 1) issues.push({ line, field: "throughMonth", level: "error", message: `Les cumuls doivent couvrir janvier à ${String(tm - 1).padStart(2, "0")}/${ty} (mois précédant la première paie), reçu jusqu'au mois ${m}.` });
        } else {
          issues.push({ line, level: "warning", message: "Première paie en janvier : les cumuls de l'année ne sont pas nécessaires." });
        }
      }
    }

    if (kind === "leave_balances") {
      if (values.periodStart && values.periodEnd && String(values.periodEnd) <= String(values.periodStart)) issues.push({ line, field: "periodEnd", level: "error", message: "La fin de période doit suivre le début." });
      if (values.leaveCode && ctx.leaveCodes && !ctx.leaveCodes.includes(String(values.leaveCode).toUpperCase())) {
        issues.push({ line, field: "leaveCode", level: "error", message: `Type de congé « ${values.leaveCode} » inconnu. Codes disponibles : ${ctx.leaveCodes.join(", ")}.` });
      }
      if (values.leaveCode) values.leaveCode = String(values.leaveCode).toUpperCase();
    }

    parsed.push({ line, values });
  });
  return { parsed, issues };
}

/** Doublons à l'intérieur du fichier : même NIR, même matricule, même nom + date de naissance. */
export function findFileDuplicates(kind: ImportKind, parsed: ParsedRow[]): Duplicate[] {
  const out: Duplicate[] = [];
  const seen = new Map<string, number>();
  const keyFns: { label: string; fn: (r: ParsedRow) => string | null }[] =
    kind === "employees"
      ? [
          { label: "même N° de sécurité sociale", fn: (r) => (r.values.nir ? `nir:${r.values.nir}` : null) },
          { label: "même matricule", fn: (r) => (r.values.employeeNumber ? `num:${String(r.values.employeeNumber).toLowerCase()}` : null) },
          {
            label: "même nom, prénom et date de naissance",
            fn: (r) => (r.values.lastName && r.values.firstName && r.values.birthDate ? `id:${normalizeHeader(String(r.values.lastName))}|${normalizeHeader(String(r.values.firstName))}|${r.values.birthDate}` : null),
          },
        ]
      : kind === "compensations"
        ? [{ label: "même matricule et même date d'effet", fn: (r) => (r.values.employeeNumber && r.values.effectiveDate ? `c:${String(r.values.employeeNumber).toLowerCase()}|${r.values.effectiveDate}` : null) }]
        : kind === "carryovers"
          ? [{ label: "même matricule et même année", fn: (r) => (r.values.employeeNumber && r.values.year ? `y:${String(r.values.employeeNumber).toLowerCase()}|${r.values.year}` : null) }]
          : [{ label: "même matricule, type et période", fn: (r) => (r.values.employeeNumber && r.values.leaveCode && r.values.periodStart ? `l:${String(r.values.employeeNumber).toLowerCase()}|${r.values.leaveCode}|${r.values.periodStart}` : null) }];
  for (const r of parsed) {
    for (const k of keyFns) {
      const key = k.fn(r);
      if (!key) continue;
      const prev = seen.get(key);
      if (prev !== undefined) out.push({ line: r.line, otherLine: prev, reason: `Doublon dans le fichier (${k.label} que la ligne ${prev}).` });
      else seen.set(key, r.line);
    }
  }
  return out;
}

/** Modèle CSV (séparateur « ; », compatible Excel français) avec une ligne d'exemple. */
export function buildTemplateCsv(kind: ImportKind): string {
  const spec = IMPORT_SPECS[kind];
  const esc = (s: string) => (/[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
  return `﻿${spec.fields.map((f) => esc(f.label)).join(";")}\r\n${spec.fields.map((f) => esc(f.example)).join(";")}\r\n`;
}
