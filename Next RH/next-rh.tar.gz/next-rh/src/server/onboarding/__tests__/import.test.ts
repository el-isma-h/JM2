import { describe, expect, it } from "vitest";
import { autoMap, buildTemplateCsv, findFileDuplicates, IMPORT_KINDS, IMPORT_SPECS, validateRows } from "../import-spec";
import { parseCsv } from "../csv";
import { parseCompanySearch } from "../lookup-parse";
import { isMidYearTakeover, readPayrollSettings } from "../payroll-settings";

const enc = (s: string) => new TextEncoder().encode(s);

describe("CSV", () => {
  it("détecte le point-virgule et retire le BOM", () => {
    const r = parseCsv(enc("﻿Matricule;Nom;Prénom\r\nS01;Lefebvre;Maëlle\r\n\r\n"));
    expect("error" in r).toBe(false);
    if ("error" in r) return;
    expect(r.delimiter).toBe(";");
    expect(r.headers).toEqual(["Matricule", "Nom", "Prénom"]);
    expect(r.rows).toEqual([{ Matricule: "S01", Nom: "Lefebvre", Prénom: "Maëlle" }]);
  });
  it("lit un fichier Windows-1252", () => {
    const bytes = new Uint8Array([...enc("Nom;Pr"), 0xe9, ...enc("nom\nGarnier;Ren"), 0xe9, ...enc("e\n")]);
    const r = parseCsv(bytes);
    if ("error" in r) throw new Error(r.error);
    expect(r.encoding).toBe("windows-1252");
    expect(r.rows[0]["Prénom"]).toBe("Renée");
  });
  it("refuse un fichier sans données", () => {
    expect("error" in parseCsv(enc("Nom;Prénom\n"))).toBe(true);
  });
});

describe("Correspondance des colonnes", () => {
  it("reconnaît les en-têtes usuels, accents et casse compris", () => {
    const m = autoMap("employees", ["MATRICULE", "Nom", "Prénom", "Date d'entrée", "N° Sécurité sociale", "Salaire de base", "Type de contrat", "IBAN"]);
    expect(m.employeeNumber).toBe("MATRICULE");
    expect(m.firstName).toBe("Prénom");
    expect(m.hireDate).toBe("Date d'entrée");
    expect(m.nir).toBe("N° Sécurité sociale");
    expect(m.grossMonthly).toBe("Salaire de base");
    expect(m.contractType).toBe("Type de contrat");
    expect(m.iban).toBe("IBAN");
    expect(m.bic).toBeNull();
  });
  it("le modèle CSV se relit et s'associe entièrement", () => {
    for (const k of IMPORT_KINDS) {
      const r = parseCsv(enc(buildTemplateCsv(k)));
      if ("error" in r) throw new Error(r.error);
      const m = autoMap(k, r.headers);
      for (const f of IMPORT_SPECS[k].fields) expect(m[f.key], `${k}.${f.key}`).toBe(f.label);
      const { issues } = validateRows(k, r.rows, m, { firstPeriod: "2026-10", leaveCodes: ["CP", "RTT"] });
      expect(issues.filter((i) => i.level === "error"), k).toEqual([]);
    }
  });
});

describe("Contrôles ligne par ligne", () => {
  const mapping = autoMap("employees", ["Matricule", "Nom", "Prénom", "Date d'entrée", "Type de contrat", "Salaire de base", "NIR", "IBAN", "Date de naissance"]);
  const row = (o: Partial<Record<string, string>>) => ({ Matricule: "S01", Nom: "Lefebvre", Prénom: "Maëlle", "Date d'entrée": "02/09/2019", "Type de contrat": "CDI", "Salaire de base": "2187,40", NIR: "", IBAN: "", "Date de naissance": "", ...o });

  it("accepte une ligne valide et convertit les valeurs", () => {
    const { parsed, issues } = validateRows("employees", [row({})], mapping);
    expect(issues.filter((i) => i.level === "error")).toEqual([]);
    expect(parsed[0].values.hireDate).toBe("2019-09-02");
    expect(parsed[0].values.grossMonthly).toBe(218740);
    expect(parsed[0].values.contractType).toBe("CDI");
  });
  it("signale NIR, IBAN, date et montant invalides avec le numéro de ligne", () => {
    const { issues } = validateRows("employees", [row({ NIR: "184056912345691", IBAN: "FR7630006000011234567890188", "Date d'entrée": "31/02/2020", "Salaire de base": "deux mille" })], mapping);
    const fields = issues.filter((i) => i.level === "error").map((i) => i.field);
    expect(fields).toEqual(expect.arrayContaining(["nir", "iban", "hireDate", "grossMonthly"]));
    expect(issues.every((i) => i.line === 2)).toBe(true);
  });
  it("exige les colonnes obligatoires", () => {
    const { issues } = validateRows("employees", [row({})], { ...mapping, grossMonthly: null });
    expect(issues.some((i) => i.line === 1 && i.field === "grossMonthly")).toBe(true);
  });
  it("détecte les doublons internes au fichier", () => {
    const { parsed } = validateRows("employees", [row({ "Date de naissance": "14/03/1991" }), row({ Matricule: "S02", "Date de naissance": "14/03/1991" }), row({ Matricule: "S01", Nom: "Garnier" })], mapping);
    const d = findFileDuplicates("employees", parsed);
    expect(d.map((x) => x.line)).toEqual([3, 4]);
    expect(d[0].reason).toContain("nom");
    expect(d[1].reason).toContain("matricule");
  });
});

describe("Cumuls de reprise", () => {
  const headers = ["Matricule", "Année", "Dernier mois inclus (1 à 12)", "Brut cumulé", "Net imposable cumulé"];
  const m = autoMap("carryovers", headers);
  const r = (o: Record<string, string>) => ({ Matricule: "S01", Année: "2026", "Dernier mois inclus (1 à 12)": "9", "Brut cumulé": "19686,60", "Net imposable cumulé": "15412,08", ...o });
  it("accepte des cumuls cohérents avec le mois de reprise", () => {
    const { issues } = validateRows("carryovers", [r({})], m, { firstPeriod: "2026-10" });
    expect(issues.filter((i) => i.level === "error")).toEqual([]);
  });
  it("refuse un net imposable supérieur au brut", () => {
    const { issues } = validateRows("carryovers", [r({ "Net imposable cumulé": "21000" })], m, { firstPeriod: "2026-10" });
    expect(issues.some((i) => i.field === "netTaxableYtd" && i.level === "error")).toBe(true);
  });
  it("refuse un mois de reprise incohérent", () => {
    const { issues } = validateRows("carryovers", [r({ "Dernier mois inclus (1 à 12)": "8" })], m, { firstPeriod: "2026-10" });
    expect(issues.some((i) => i.field === "throughMonth" && i.level === "error")).toBe(true);
    const y = validateRows("carryovers", [r({ Année: "2025" })], m, { firstPeriod: "2026-10" });
    expect(y.issues.some((i) => i.field === "year")).toBe(true);
  });
  it("identifie la reprise en cours d'année", () => {
    expect(isMidYearTakeover("2026-10")).toEqual({ midYear: true, year: 2026, month: 10 });
    expect(isMidYearTakeover("2027-01")?.midYear).toBe(false);
    expect(isMidYearTakeover(undefined)).toBeNull();
  });
});

describe("Paramètres de paie", () => {
  it("lit le jsonb de façon tolérante", () => {
    const s = readPayrollSettings({ paymentDay: 28, headcountBracket: "11to49", atRate: "1.30", mutuelle: null, preparers: ["a"], confirmed: { atRate: true, x: "oui" }, bogus: 1 });
    expect(s.paymentDay).toBe(28);
    expect(s.mutuelle).toBeNull();
    expect(s.prevoyance).toBeUndefined();
    expect(s.validators).toEqual([]);
    expect(s.confirmed).toEqual({ atRate: true, x: false });
    expect(readPayrollSettings(null).confirmed).toEqual({});
  });
});

describe("Suggestion du répertoire public", () => {
  it("extrait les informations utiles", () => {
    const json = {
      results: [
        {
          siren: "552032534",
          nom_complet: "DANONE",
          nom_raison_sociale: "DANONE",
          nature_juridique: "5599",
          activite_principale: "70.10Z",
          tranche_effectif_salarie: "21",
          siege: { siret: "55203253400646", numero_voie: "17", type_voie: "BD", libelle_voie: "HAUSSMANN", code_postal: "75009", libelle_commune: "PARIS", liste_idcc: ["2216", "9999"] },
          complements: { liste_idcc: ["2216"] },
        },
      ],
    };
    const s = parseCompanySearch(json, "552032534");
    expect(s).toMatchObject({ legalName: "DANONE", legalForm: "SA", apeCode: "70.10Z", addressLine1: "17 BD HAUSSMANN", postalCode: "75009", city: "PARIS", headOfficeSiret: "55203253400646", idccList: ["2216"], headcountLabel: "50 à 99 salariés" });
  });
  it("renvoie null pour une réponse inattendue", () => {
    expect(parseCompanySearch({ results: [] }, "552032534")).toBeNull();
    expect(parseCompanySearch("erreur", "552032534")).toBeNull();
    expect(parseCompanySearch({ results: [{ siren: "732829320" }] }, "552032534")).toBeNull();
  });
});
