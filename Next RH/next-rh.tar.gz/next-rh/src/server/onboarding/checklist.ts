import "server-only";
import { and, eq, inArray, isNotNull, ne, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { integrationLabels, integrations } from "@/lib/env";
import { checkSiren, checkSiret } from "@/lib/validators";
import { isMidYearTakeover, readPayrollSettings } from "./payroll-settings";
import { syncLeavingStatuses } from "@/server/employees/queries";

export type ChecklistStatus = "ok" | "todo" | "blocking";
export type ChecklistItem = { key: string; label: string; status: ChecklistStatus; href: string; help: string; group: ChecklistGroup };
export type ChecklistGroup = "informations" | "documents" | "paie" | "salaries" | "acces";

export const checklistGroupLabels: Record<ChecklistGroup, string> = {
  informations: "Informations de l'entreprise",
  documents: "Documents",
  paie: "Paramètres de paie",
  salaries: "Salariés et reprise des données",
  acces: "Accès et intégrations",
};

const plural = (n: number, one: string, many: string) => `${n} ${n > 1 ? many : one}`;

/**
 * Checklist de mise en route, calculée côté serveur. Utilisée par l'onboarding et par le tableau de bord.
 * `blocking` : empêche la première paie ; `todo` : recommandé ; `ok` : fait.
 */
export async function getOnboardingChecklist(companyId: string): Promise<{ items: ChecklistItem[]; blockingCount: number; progress: number }> {
  const base = `/app/${companyId}`;
  await syncLeavingStatuses(companyId);
  const ob = (step: string) => `${base}/onboarding?etape=${step}`;
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, companyId)).limit(1);
  if (!company) return { items: [], blockingCount: 0, progress: 0 };
  const settings = readPayrollSettings(company.payrollSettings);
  const c = settings.confirmed;

  const [establishments, contacts, organisms, kbis, members, employees] = await Promise.all([
    db.select().from(schema.establishments).where(eq(schema.establishments.companyId, companyId)),
    db.select({ id: schema.companyContacts.id }).from(schema.companyContacts).where(eq(schema.companyContacts.companyId, companyId)),
    db.select({ kind: schema.companyOrganisms.kind }).from(schema.companyOrganisms).where(eq(schema.companyOrganisms.companyId, companyId)),
    db.select({ id: schema.documents.id }).from(schema.documents).where(and(eq(schema.documents.companyId, companyId), eq(schema.documents.category, "kbis"))).limit(1),
    db
      .select({ userId: schema.companyMemberships.userId, role: schema.companyMemberships.role, totp: schema.users.totpEnabledAt })
      .from(schema.companyMemberships)
      .innerJoin(schema.users, eq(schema.users.id, schema.companyMemberships.userId))
      .where(and(eq(schema.companyMemberships.companyId, companyId), ne(schema.companyMemberships.role, "employee"))),
    db
      .select({ id: schema.employees.id, hireDate: schema.employees.hireDate, nirEnc: schema.employees.nirEnc })
      .from(schema.employees)
      .where(and(eq(schema.employees.companyId, companyId), eq(schema.employees.status, "active"))),
  ]);
  const activeIds = employees.map((e) => e.id);
  const [withContract, withComp, withBank, carry] = activeIds.length
    ? await Promise.all([
        db.selectDistinct({ id: schema.contracts.employeeId }).from(schema.contracts).where(inArray(schema.contracts.employeeId, activeIds)),
        db.selectDistinct({ id: schema.compensations.employeeId }).from(schema.compensations).where(and(inArray(schema.compensations.employeeId, activeIds), sql`${schema.compensations.endDate} is null`)),
        db.selectDistinct({ id: schema.employeeBankAccounts.employeeId }).from(schema.employeeBankAccounts).where(inArray(schema.employeeBankAccounts.employeeId, activeIds)),
        db.select({ id: schema.employeeCarryovers.employeeId, year: schema.employeeCarryovers.year }).from(schema.employeeCarryovers).where(and(inArray(schema.employeeCarryovers.employeeId, activeIds), isNotNull(schema.employeeCarryovers.employeeId))),
      ])
    : [[], [], [], []];

  const items: ChecklistItem[] = [];
  const push = (group: ChecklistGroup, key: string, label: string, status: ChecklistStatus, href: string, help: string) => items.push({ group, key, label, status, href, help });

  // Informations
  const sirenOk = company.siren ? checkSiren(company.siren).ok : false;
  push("informations", "siren", "SIREN de l'entreprise", sirenOk ? "ok" : "blocking", ob("entreprise"), sirenOk ? `SIREN ${company.siren}.` : "Le SIREN identifie l'entreprise dans toutes les déclarations sociales. Il figure sur le Kbis ou l'avis de situation INSEE.");
  const identityOk = Boolean(company.legalName && company.legalForm && company.addressLine1 && company.postalCode && company.city && company.apeCode);
  push("informations", "identity", "Identité et adresse du siège", identityOk ? "ok" : "todo", ob("entreprise"), identityOk ? "Raison sociale, forme juridique, APE et adresse renseignées." : "Complétez la forme juridique, le code APE et l'adresse du siège : ils apparaissent sur les bulletins.");
  const estabMissingSiret = establishments.filter((e) => !e.siret || !checkSiret(e.siret, company.siren).ok);
  push(
    "informations",
    "establishments",
    "Établissements et SIRET",
    establishments.length === 0 || estabMissingSiret.length > 0 ? "blocking" : "ok",
    ob("etablissements"),
    establishments.length === 0 ? "Ajoutez au moins un établissement : la paie est déclarée par établissement." : estabMissingSiret.length ? `${plural(estabMissingSiret.length, "établissement n'a pas de SIRET valide", "établissements n'ont pas de SIRET valide")} : ${estabMissingSiret.map((e) => e.name).join(", ")}.` : `${plural(establishments.length, "établissement", "établissements")} avec SIRET valide.`,
  );
  push("informations", "idcc", "Convention collective confirmée", company.idcc && company.idccConfirmed ? "ok" : "blocking", ob("convention"), company.idcc && company.idccConfirmed ? `IDCC ${company.idcc} confirmé.` : "La convention collective détermine les minima, primes et cotisations conventionnelles. Elle doit être confirmée explicitement.");
  push("informations", "headcount", "Effectif confirmé", settings.headcountBracket && c.headcountBracket ? "ok" : "blocking", ob("paie"), settings.headcountBracket && c.headcountBracket ? "Tranche d'effectif confirmée." : "L'effectif change certains taux (FNAL, versement mobilité, participation formation). Confirmez la tranche dans l'organisation de la paie.");
  push("informations", "contacts", "Interlocuteurs", contacts.length ? "ok" : "todo", ob("interlocuteurs"), contacts.length ? `${plural(contacts.length, "interlocuteur", "interlocuteurs")}.` : "Indiquez au moins la personne à contacter pour la paie.");

  // Documents
  push("documents", "kbis", "Extrait Kbis", kbis.length ? "ok" : "todo", ob("interlocuteurs"), kbis.length ? "Kbis déposé." : "Un Kbis de moins de 3 mois permet de vérifier la raison sociale et le SIREN.");

  // Paie
  push("paie", "atRate", "Taux accident du travail (AT/MP)", settings.atRate && c.atRate ? "ok" : "blocking", ob("paie"), settings.atRate && c.atRate ? `Taux ${settings.atRate.replace(".", ",")} % confirmé.` : "Le taux AT/MP est notifié chaque année par la CARSAT sur net-entreprises.fr. Sans lui, la cotisation patronale ne peut pas être calculée.");
  const mobilityRequired = settings.headcountBracket && settings.headcountBracket !== "lt11";
  const mobilityOk = settings.mobilityRate !== undefined && c.mobilityRate;
  push("paie", "mobility", "Versement mobilité", mobilityOk ? "ok" : mobilityRequired ? "blocking" : "todo", ob("paie"), mobilityOk ? `Taux ${String(settings.mobilityRate).replace(".", ",")} % confirmé.` : "Dû à partir de 11 salariés selon la commune de l'établissement. Indiquez 0 si l'entreprise n'est pas assujettie.");
  push("paie", "paymentDay", "Date de paiement des salaires", settings.paymentDay && c.paymentDay ? "ok" : "todo", ob("paie"), settings.paymentDay ? `Le ${settings.paymentDay} de chaque mois.` : "Elle fixe la date des virements et la période de déclaration.");
  push("paie", "workTime", "Organisation du temps de travail", settings.workTime && c.workTime ? "ok" : "todo", ob("paie"), settings.workTime ? "Renseignée." : "35 heures, forfait jours ou autre organisation.");
  const mutOk = settings.mutuelle !== undefined && c.mutuelle;
  push("paie", "mutuelle", "Mutuelle d'entreprise", mutOk ? "ok" : "todo", ob("paie"), mutOk ? (settings.mutuelle ? `${settings.mutuelle.name}.` : "Pas de mutuelle d'entreprise (confirmé).") : "La mutuelle est obligatoire pour les salariés du privé. Indiquez l'organisme et la répartition, ou confirmez qu'il n'y en a pas encore.");
  const prevOk = settings.prevoyance !== undefined && c.prevoyance;
  push("paie", "prevoyance", "Prévoyance", prevOk ? "ok" : "todo", ob("paie"), prevOk ? (settings.prevoyance ? `${settings.prevoyance.name}.` : "Pas de contrat de prévoyance (confirmé).") : "Obligatoire pour les cadres (1,50 % minimum à la charge de l'employeur). Vérifiez aussi votre convention collective.");
  const kinds = new Set(organisms.map((o) => o.kind));
  const missingOrg = (["urssaf", "retraite", "medecine_travail"] as const).filter((k) => !kinds.has(k));
  const orgLabels = { urssaf: "URSSAF", retraite: "caisse de retraite", medecine_travail: "médecine du travail" };
  push("paie", "organisms", "Organismes sociaux", missingOrg.length ? "todo" : "ok", ob("organismes"), missingOrg.length ? `À renseigner : ${missingOrg.map((k) => orgLabels[k]).join(", ")}.` : "URSSAF, retraite et médecine du travail renseignés.");
  const memberIds = new Set(members.map((m) => m.userId));
  const validators = settings.validators.filter((id) => memberIds.has(id));
  push("paie", "validators", "Personne habilitée à valider la paie", validators.length ? "ok" : "blocking", ob("paie"), validators.length ? `${plural(validators.length, "valideur désigné", "valideurs désignés")}.` : "Désignez au moins une personne qui valide les bulletins avant leur diffusion.");
  const preparers = settings.preparers.filter((id) => memberIds.has(id));
  push("paie", "preparers", "Personne chargée de préparer la paie", preparers.length ? "ok" : "todo", ob("paie"), preparers.length ? `${plural(preparers.length, "personne désignée", "personnes désignées")}.` : "Indiquez qui collecte les variables du mois.");

  // Salariés
  push("salaries", "employees", "Au moins un salarié actif", employees.length ? "ok" : "blocking", `${base}/salaries`, employees.length ? `${plural(employees.length, "salarié actif", "salariés actifs")}.` : "Créez les salariés un par un ou importez-les depuis votre ancien logiciel.");
  if (employees.length) {
    const cSet = new Set(withContract.map((x) => x.id));
    const noContract = employees.filter((e) => !cSet.has(e.id)).length;
    push("salaries", "contracts", "Chaque salarié a un contrat", noContract ? "blocking" : "ok", `${base}/salaries?anomalie=contrat`, noContract ? `${plural(noContract, "salarié actif n'a", "salariés actifs n'ont")} pas de contrat.` : "Tous les salariés actifs ont un contrat.");
    const pSet = new Set(withComp.map((x) => x.id));
    const noComp = employees.filter((e) => !pSet.has(e.id)).length;
    push("salaries", "compensations", "Chaque salarié a une rémunération", noComp ? "blocking" : "ok", `${base}/salaries?anomalie=remuneration`, noComp ? `${plural(noComp, "salarié actif n'a", "salariés actifs n'ont")} pas de rémunération en cours.` : "Toutes les rémunérations sont renseignées.");
    const noNir = employees.filter((e) => !e.nirEnc).length;
    push("salaries", "nir", "N° de sécurité sociale", noNir ? "todo" : "ok", `${base}/salaries?anomalie=nir`, noNir ? `${plural(noNir, "salarié n'a", "salariés n'ont")} pas de N° de sécurité sociale : indispensable pour la déclaration sociale.` : "Renseigné pour tous.");
    const bSet = new Set(withBank.map((x) => x.id));
    const noBank = employees.filter((e) => !bSet.has(e.id)).length;
    push("salaries", "bank", "Coordonnées bancaires", noBank ? "todo" : "ok", `${base}/salaries?anomalie=banque`, noBank ? `${plural(noBank, "salarié n'a", "salariés n'ont")} pas d'IBAN : le virement devra être fait manuellement.` : "IBAN renseigné pour tous.");
    const take = isMidYearTakeover(settings.firstPeriod);
    if (take?.midYear) {
      const startOfFirst = `${take.year}-${String(take.month).padStart(2, "0")}-01`;
      const cov = new Set(carry.filter((x) => x.year === take.year).map((x) => x.id));
      const missing = employees.filter((e) => (!e.hireDate || e.hireDate < startOfFirst) && !cov.has(e.id)).length;
      push("salaries", "carryovers", `Cumuls annuels ${take.year} (reprise en cours d'année)`, missing ? "blocking" : "ok", ob("reprise"), missing ? `${plural(missing, "salarié actif n'a", "salariés actifs n'ont")} pas de cumuls de janvier à ${String(take.month - 1).padStart(2, "0")}/${take.year} : les plafonds et la réduction générale seraient faux.` : "Cumuls importés pour tous les salariés concernés.");
    }
  }
  if (!settings.firstPeriod) push("paie", "firstPeriod", "Premier mois de paie dans Next RH", "todo", ob("paie"), "Indiquez le premier mois que Next RH calculera : il détermine si des cumuls de reprise sont nécessaires.");

  // Accès et intégrations
  const withTotp = members.filter((m) => m.totp).length;
  push("acces", "totp", "Authentification renforcée des gestionnaires", withTotp === members.length && members.length ? "ok" : "todo", "/securite?setup=1", withTotp === members.length ? "Tous les gestionnaires ont activé la double vérification." : `${plural(members.length - withTotp, "gestionnaire n'a", "gestionnaires n'ont")} pas activé la double vérification, nécessaire pour voir les RIB et clôturer la paie.`);
  push("acces", "mail", integrationLabels.mail.label, integrations.mail() ? "ok" : "todo", `${base}/parametres?section=securite`, integrations.mail() ? "Configuré." : `Non configuré (${integrationLabels.mail.envVars.join(", ")}). ${integrationLabels.mail.effect}`);
  push("acces", "esign", integrationLabels.esign.label, integrations.esign() ? "ok" : "todo", `${base}/parametres?section=securite`, integrations.esign() ? "Configurée." : `Non configurée (${integrationLabels.esign.envVars.join(", ")}). ${integrationLabels.esign.effect}`);

  const blockingCount = items.filter((i) => i.status === "blocking").length;
  const progress = items.length ? Math.round((items.filter((i) => i.status === "ok").length / items.length) * 100) : 0;
  return { items, blockingCount, progress };
}
