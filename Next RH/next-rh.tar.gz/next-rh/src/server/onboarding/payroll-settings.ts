/**
 * Contrat partagé avec l'équipe paie : forme exacte de `companies.payroll_settings`.
 * Module pur (pas de "server-only") : le type est importable partout.
 */

export type HeadcountBracket = "lt11" | "11to49" | "50to249" | "gte250";
export type WorkTimeOrganisation = "35h" | "forfait_jours" | "other";

export type PayrollSettings = {
  paymentDay: number;
  headcountBracket: HeadcountBracket;
  /** Taux AT/MP en %, ex "1.30". */
  atRate: string;
  /** Versement mobilité en % ("0" si non assujetti). */
  mobilityRate: string;
  mutuelle: { name: string; employerCents: number; employeeCents: number } | null;
  prevoyance: {
    name: string;
    cadreEmployerRate: string;
    cadreEmployeeRate: string;
    nonCadreEmployerRate: string;
    nonCadreEmployeeRate: string;
  } | null;
  workTime: WorkTimeOrganisation;
  previousProvider?: string;
  preparers: string[];
  validators: string[];
  confirmed: Record<string, boolean>;
  /**
   * Champs complémentaires (hors contrat strict, ignorables par la paie) :
   * établissements concernés par la paie et premier mois traité dans Next RH (AAAA-MM).
   */
  establishmentIds?: string[];
  firstPeriod?: string;
};

/** Clés de `confirmed` utilisées par l'onboarding et la checklist. */
export const CONFIRMABLE = {
  paymentDay: "Date de paiement",
  headcountBracket: "Tranche d'effectif",
  atRate: "Taux accident du travail",
  mobilityRate: "Versement mobilité",
  mutuelle: "Mutuelle",
  prevoyance: "Prévoyance",
  workTime: "Organisation du temps de travail",
} as const;
export type ConfirmableKey = keyof typeof CONFIRMABLE;

export const headcountBracketLabels: Record<HeadcountBracket, string> = {
  lt11: "Moins de 11 salariés",
  "11to49": "De 11 à 49 salariés",
  "50to249": "De 50 à 249 salariés",
  gte250: "250 salariés ou plus",
};

export const workTimeLabels: Record<WorkTimeOrganisation, string> = {
  "35h": "35 heures par semaine (ou horaire collectif en heures)",
  forfait_jours: "Forfait annuel en jours (cadres autonomes)",
  other: "Autre organisation (modulation, temps partiel majoritaire, horaires spécifiques)",
};

export function bracketFromHeadcount(n: number | null | undefined): HeadcountBracket | null {
  if (n === null || n === undefined || Number.isNaN(n)) return null;
  if (n < 11) return "lt11";
  if (n < 50) return "11to49";
  if (n < 250) return "50to249";
  return "gte250";
}

/** Lecture tolérante du jsonb : renvoie un objet partiel typé (jamais d'exception). */
export function readPayrollSettings(raw: unknown): Partial<PayrollSettings> & { confirmed: Record<string, boolean>; preparers: string[]; validators: string[] } {
  const o = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const arr = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);
  const out: Partial<PayrollSettings> = {};
  if (typeof o.paymentDay === "number" && o.paymentDay >= 1 && o.paymentDay <= 31) out.paymentDay = o.paymentDay;
  if (typeof o.headcountBracket === "string" && o.headcountBracket in headcountBracketLabels) out.headcountBracket = o.headcountBracket as HeadcountBracket;
  if (typeof o.atRate === "string") out.atRate = o.atRate;
  if (typeof o.mobilityRate === "string") out.mobilityRate = o.mobilityRate;
  if (o.mutuelle === null) out.mutuelle = null;
  else if (o.mutuelle && typeof o.mutuelle === "object") {
    const m = o.mutuelle as Record<string, unknown>;
    out.mutuelle = { name: String(m.name ?? ""), employerCents: Number(m.employerCents ?? 0) || 0, employeeCents: Number(m.employeeCents ?? 0) || 0 };
  }
  if (o.prevoyance === null) out.prevoyance = null;
  else if (o.prevoyance && typeof o.prevoyance === "object") {
    const p = o.prevoyance as Record<string, unknown>;
    out.prevoyance = {
      name: String(p.name ?? ""),
      cadreEmployerRate: String(p.cadreEmployerRate ?? "0"),
      cadreEmployeeRate: String(p.cadreEmployeeRate ?? "0"),
      nonCadreEmployerRate: String(p.nonCadreEmployerRate ?? "0"),
      nonCadreEmployeeRate: String(p.nonCadreEmployeeRate ?? "0"),
    };
  }
  if (typeof o.workTime === "string" && o.workTime in workTimeLabels) out.workTime = o.workTime as WorkTimeOrganisation;
  if (typeof o.previousProvider === "string") out.previousProvider = o.previousProvider;
  if (Array.isArray(o.establishmentIds)) out.establishmentIds = arr(o.establishmentIds);
  if (typeof o.firstPeriod === "string" && /^\d{4}-\d{2}$/.test(o.firstPeriod)) out.firstPeriod = o.firstPeriod;
  const confirmed: Record<string, boolean> = {};
  if (o.confirmed && typeof o.confirmed === "object") {
    for (const [k, v] of Object.entries(o.confirmed as Record<string, unknown>)) confirmed[k] = v === true;
  }
  return { ...out, preparers: arr(o.preparers), validators: arr(o.validators), confirmed };
}

/** Reprise en cours d'année : premier mois traité après janvier. */
export function isMidYearTakeover(firstPeriod: string | undefined): { midYear: boolean; year: number; month: number } | null {
  if (!firstPeriod) return null;
  const [y, m] = firstPeriod.split("-").map(Number);
  if (!y || !m) return null;
  return { midYear: m > 1, year: y, month: m };
}
