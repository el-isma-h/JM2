import "server-only";
import { checkSiren } from "@/lib/validators";
import { parseCompanySearch, type CompanySuggestion } from "./lookup-parse";

export type LookupResult = { ok: true; suggestion: CompanySuggestion } | { ok: false; reason: "invalid" | "not_found" | "unavailable"; message: string };

/**
 * Interroge l'API publique « Recherche d'entreprises » pour SUGGÉRER des informations.
 * Rien n'est enregistré ici : l'utilisateur confirme ensuite chaque suggestion.
 */
export async function lookupCompany(sirenInput: string): Promise<LookupResult> {
  const check = checkSiren(sirenInput);
  if (!check.ok) return { ok: false, reason: "invalid", message: check.error };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 6000);
  try {
    const res = await fetch(`https://recherche-entreprises.api.gouv.fr/search?q=${check.value}&page=1&per_page=5`, {
      signal: controller.signal,
      headers: { accept: "application/json" },
      cache: "no-store",
    });
    if (!res.ok) return { ok: false, reason: "unavailable", message: "Suggestion indisponible pour le moment, saisissez les informations manuellement." };
    const json = (await res.json()) as unknown;
    const suggestion = parseCompanySearch(json, check.value);
    if (!suggestion) return { ok: false, reason: "not_found", message: "Aucune entreprise trouvée pour ce SIREN dans le répertoire public. Saisissez les informations manuellement." };
    return { ok: true, suggestion };
  } catch {
    return { ok: false, reason: "unavailable", message: "Suggestion indisponible (service public injoignable depuis le serveur), saisissez les informations manuellement." };
  } finally {
    clearTimeout(timer);
  }
}
