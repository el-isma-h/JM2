/**
 * Lecture défensive de la réponse de l'API publique « Recherche d'entreprises »
 * (https://recherche-entreprises.api.gouv.fr/search?q=<siren>). Module pur, testable.
 */

export type CompanySuggestion = {
  siren: string;
  legalName?: string;
  tradeName?: string;
  apeCode?: string;
  legalForm?: string;
  addressLine1?: string;
  postalCode?: string;
  city?: string;
  headOfficeSiret?: string;
  idccList: string[];
  headcountLabel?: string;
};

const NATURE_JURIDIQUE: Record<string, string> = {
  "5710": "SAS",
  "5720": "SASU",
  "5498": "EURL",
  "5499": "SARL",
  "5410": "SARL",
  "5422": "SARL",
  "5505": "SA",
  "5510": "SA",
  "5599": "SA",
  "5699": "SA",
  "6540": "SCI",
  "5202": "SNC",
  "1000": "EI",
  "9210": "ASSOCIATION",
  "9220": "ASSOCIATION",
  "9221": "ASSOCIATION",
  "9222": "ASSOCIATION",
  "9230": "ASSOCIATION",
};

/** Tranches d'effectif INSEE (codes publics). */
const TRANCHES: Record<string, string> = {
  NN: "Non renseigné",
  "00": "0 salarié",
  "01": "1 ou 2 salariés",
  "02": "3 à 5 salariés",
  "03": "6 à 9 salariés",
  "11": "10 à 19 salariés",
  "12": "20 à 49 salariés",
  "21": "50 à 99 salariés",
  "22": "100 à 199 salariés",
  "31": "200 à 249 salariés",
  "32": "250 à 499 salariés",
  "41": "500 à 999 salariés",
  "42": "1 000 à 1 999 salariés",
  "51": "2 000 à 4 999 salariés",
  "52": "5 000 à 9 999 salariés",
  "53": "10 000 salariés et plus",
};

const str = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : undefined);

export function parseCompanySearch(json: unknown, siren: string): CompanySuggestion | null {
  if (!json || typeof json !== "object") return null;
  const results = (json as { results?: unknown }).results;
  if (!Array.isArray(results)) return null;
  const r = results.find((x) => x && typeof x === "object" && (x as { siren?: unknown }).siren === siren) as Record<string, unknown> | undefined;
  if (!r) return null;
  const siege = (r.siege && typeof r.siege === "object" ? r.siege : {}) as Record<string, unknown>;
  const complements = (r.complements && typeof r.complements === "object" ? r.complements : {}) as Record<string, unknown>;
  const idcc = new Set<string>();
  for (const src of [siege.liste_idcc, complements.liste_idcc]) {
    if (Array.isArray(src)) for (const i of src) if (typeof i === "string" && /^\d{1,4}$/.test(i) && i !== "9999") idcc.add(i.padStart(4, "0"));
  }
  const street = [str(siege.numero_voie), str(siege.indice_repetition), str(siege.type_voie), str(siege.libelle_voie)].filter(Boolean).join(" ");
  let addressLine1 = street || undefined;
  if (!addressLine1) {
    const full = str(siege.adresse);
    const cp = str(siege.code_postal);
    addressLine1 = full && cp ? full.split(cp)[0].trim().replace(/,$/, "") || undefined : full;
  }
  const ape = str(r.activite_principale) ?? str(siege.activite_principale);
  const nature = str(r.nature_juridique);
  const tranche = str(r.tranche_effectif_salarie);
  const name = str(r.nom_raison_sociale) ?? str(r.nom_complet);
  const sigle = str(r.sigle);
  const enseignes = Array.isArray(siege.liste_enseignes) ? siege.liste_enseignes.filter((x): x is string => typeof x === "string") : [];
  return {
    siren,
    legalName: name,
    tradeName: enseignes[0] ?? sigle,
    apeCode: ape && /^\d{2}\.\d{2}[A-Z]$/.test(ape) ? ape : undefined,
    legalForm: nature ? NATURE_JURIDIQUE[nature] ?? "AUTRE" : undefined,
    addressLine1,
    postalCode: str(siege.code_postal),
    city: str(siege.libelle_commune),
    headOfficeSiret: str(siege.siret),
    idccList: [...idcc],
    headcountLabel: tranche ? TRANCHES[tranche] : undefined,
  };
}
