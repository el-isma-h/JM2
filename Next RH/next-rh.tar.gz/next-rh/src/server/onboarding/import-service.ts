import "server-only";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { decrypt, encrypt } from "@/lib/crypto";
import { isoToday } from "@/lib/dates";
import { compact } from "@/lib/validators";
import { parseCsv } from "./csv";
import { autoMap, findFileDuplicates, IMPORT_SPECS, normalizeHeader, validateRows, type Duplicate, type ImportKind, type ParsedRow, type RowIssue } from "./import-spec";
import { isMidYearTakeover, readPayrollSettings } from "./payroll-settings";

export type ImportPreview = { headers: string[]; sample: Record<string, string>[]; totalRows: number; delimiter: string; encoding: string };

export async function createImportFromFile(input: { companyId: string; kind: ImportKind; fileName: string; data: Uint8Array; userId: string }) {
  const lower = input.fileName.toLowerCase();
  if (lower.endsWith(".xlsx") || lower.endsWith(".xls") || lower.endsWith(".ods")) {
    return { error: "Les fichiers Excel ne sont pas lus directement : dans Excel, utilisez « Enregistrer sous » puis « CSV UTF-8 (délimité par des points-virgules) »." } as const;
  }
  const parsed = parseCsv(input.data);
  if ("error" in parsed) return { error: parsed.error } as const;
  const mapping = autoMap(input.kind, parsed.headers);
  const preview: ImportPreview = { headers: parsed.headers, sample: parsed.rows.slice(0, 5), totalRows: parsed.rows.length, delimiter: parsed.delimiter, encoding: parsed.encoding };
  const [row] = await db
    .insert(schema.dataImports)
    .values({ companyId: input.companyId, kind: input.kind, fileName: input.fileName.slice(0, 200), status: "uploaded", preview, mapping, rows: parsed.rows, createdBy: input.userId })
    .returning();
  return { importRow: row } as const;
}

export async function getImport(companyId: string, importId: string) {
  const [row] = await db
    .select()
    .from(schema.dataImports)
    .where(and(eq(schema.dataImports.id, importId), eq(schema.dataImports.companyId, companyId)))
    .limit(1);
  return row ?? null;
}

type ExistingEmployee = { id: string; employeeNumber: string | null; firstName: string; lastName: string; birthDate: string | null; nir: string | null; status: string; hireDate: string | null };

async function loadEmployees(companyId: string): Promise<ExistingEmployee[]> {
  const rows = await db
    .select({
      id: schema.employees.id,
      employeeNumber: schema.employees.employeeNumber,
      firstName: schema.employees.firstName,
      lastName: schema.employees.lastName,
      birthDate: schema.employees.birthDate,
      nirEnc: schema.employees.nirEnc,
      status: schema.employees.status,
      hireDate: schema.employees.hireDate,
    })
    .from(schema.employees)
    .where(eq(schema.employees.companyId, companyId));
  return rows.map((r) => {
    let nir: string | null = null;
    if (r.nirEnc) {
      try {
        nir = decrypt(r.nirEnc);
      } catch {
        nir = null;
      }
    }
    return { id: r.id, employeeNumber: r.employeeNumber, firstName: r.firstName, lastName: r.lastName, birthDate: r.birthDate, nir, status: r.status, hireDate: r.hireDate };
  });
}

export type ValidationOutcome = { parsed: ParsedRow[]; issues: RowIssue[]; duplicates: Duplicate[]; errorLines: number[]; validLines: number[] };

/** Contrôle complet : format, cohérence, doublons (fichier et base), rattachement aux salariés existants. */
export async function validateImport(companyId: string, importId: string, mapping: Record<string, string | null>): Promise<ValidationOutcome | { error: string }> {
  const imp = await getImport(companyId, importId);
  if (!imp) return { error: "Import introuvable." };
  if (imp.status === "applied") return { error: "Cet import a déjà été appliqué." };
  const kind = imp.kind as ImportKind;
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, companyId)).limit(1);
  const settings = readPayrollSettings(company?.payrollSettings);
  const leaveTypes = await db.select({ code: schema.leaveTypes.code }).from(schema.leaveTypes).where(eq(schema.leaveTypes.companyId, companyId));
  const rows = (imp.rows as Record<string, string>[]) ?? [];
  const { parsed, issues } = validateRows(kind, rows, mapping, { siren: company?.siren, firstPeriod: settings.firstPeriod, leaveCodes: leaveTypes.map((l) => l.code) });
  const duplicates = findFileDuplicates(kind, parsed);
  const existing = await loadEmployees(companyId);
  const byNumber = new Map(existing.filter((e) => e.employeeNumber).map((e) => [e.employeeNumber!.toLowerCase(), e]));

  if (kind === "employees") {
    const byNir = new Map(existing.filter((e) => e.nir).map((e) => [e.nir!, e]));
    const byIdentity = new Map(existing.filter((e) => e.birthDate).map((e) => [`${normalizeHeader(e.lastName)}|${normalizeHeader(e.firstName)}|${e.birthDate}`, e]));
    const establishments = await db.select().from(schema.establishments).where(eq(schema.establishments.companyId, companyId));
    for (const r of parsed) {
      const v = r.values;
      const num = v.employeeNumber ? String(v.employeeNumber).toLowerCase() : null;
      const name = (e: ExistingEmployee) => `${e.firstName} ${e.lastName}`;
      if (num && byNumber.has(num)) duplicates.push({ line: r.line, existingEmployeeId: byNumber.get(num)!.id, reason: `Matricule déjà utilisé par ${name(byNumber.get(num)!)}.` });
      if (v.nir && byNir.has(String(v.nir))) duplicates.push({ line: r.line, existingEmployeeId: byNir.get(String(v.nir))!.id, reason: `N° de sécurité sociale déjà présent pour ${name(byNir.get(String(v.nir))!)}.` });
      if (v.lastName && v.firstName && v.birthDate) {
        const k = `${normalizeHeader(String(v.lastName))}|${normalizeHeader(String(v.firstName))}|${v.birthDate}`;
        if (byIdentity.has(k)) duplicates.push({ line: r.line, existingEmployeeId: byIdentity.get(k)!.id, reason: `Même nom et date de naissance que ${name(byIdentity.get(k)!)}, déjà dans Next RH.` });
      }
      if (v.establishment) {
        const s = String(v.establishment);
        const hit = establishments.find((e) => (e.siret && e.siret === compact(s)) || normalizeHeader(e.name) === normalizeHeader(s));
        if (!hit) issues.push({ line: r.line, field: "establishment", level: "error", message: `Établissement « ${s} » inconnu : créez-le dans l'étape Établissements ou corrigez la valeur (${establishments.map((e) => e.name).join(", ")}).` });
        else v.establishmentId = hit.id;
      } else if (establishments.length === 1) {
        v.establishmentId = establishments[0].id;
      } else {
        issues.push({ line: r.line, field: "establishment", level: "warning", message: "Établissement non précisé : le siège sera utilisé." });
        v.establishmentId = establishments.find((e) => e.isHeadOffice)?.id ?? establishments[0]?.id ?? null;
      }
    }
  } else {
    // Rattachement par matricule aux salariés déjà présents.
    for (const r of parsed) {
      const num = r.values.employeeNumber ? String(r.values.employeeNumber).toLowerCase() : null;
      const emp = num ? byNumber.get(num) : undefined;
      if (num && !emp) issues.push({ line: r.line, field: "employeeNumber", level: "error", message: `Aucun salarié avec le matricule « ${r.values.employeeNumber} » : importez d'abord le fichier des salariés.` });
      if (emp) r.values.employeeId = emp.id;
    }
    const empIds = [...new Set(parsed.map((r) => r.values.employeeId).filter((x): x is string => typeof x === "string"))];
    if (kind === "compensations" && empIds.length) {
      const comps = await db.select({ e: schema.compensations.employeeId, d: schema.compensations.effectiveDate }).from(schema.compensations).where(inArray(schema.compensations.employeeId, empIds));
      const set = new Set(comps.map((c) => `${c.e}|${c.d}`));
      for (const r of parsed) if (set.has(`${r.values.employeeId}|${r.values.effectiveDate}`)) duplicates.push({ line: r.line, existingEmployeeId: String(r.values.employeeId), reason: "Une rémunération existe déjà à cette date d'effet pour ce salarié." });
    }
    if (kind === "carryovers") {
      const existingCo = empIds.length ? await db.select().from(schema.employeeCarryovers).where(inArray(schema.employeeCarryovers.employeeId, empIds)) : [];
      const set = new Set(existingCo.map((c) => `${c.employeeId}|${c.year}`));
      for (const r of parsed) if (set.has(`${r.values.employeeId}|${r.values.year}`)) issues.push({ line: r.line, level: "warning", message: "Des cumuls existent déjà pour ce salarié et cette année : ils seront remplacés." });
      const take = isMidYearTakeover(settings.firstPeriod);
      if (take?.midYear) {
        const startOfFirst = `${take.year}-${String(take.month).padStart(2, "0")}-01`;
        const covered = new Set([...parsed.map((r) => r.values.employeeId), ...existingCo.filter((c) => c.year === take.year).map((c) => c.employeeId)]);
        for (const e of existing) {
          if (e.status === "active" && (!e.hireDate || e.hireDate < startOfFirst) && !covered.has(e.id)) {
            issues.push({ line: 0, level: "warning", message: `${e.firstName} ${e.lastName} (matricule ${e.employeeNumber ?? "non renseigné"}) est actif mais n'a pas de cumuls ${take.year} : la première paie sera bloquée.` });
          }
        }
      } else if (!settings.firstPeriod) {
        issues.push({ line: 0, level: "warning", message: "Le premier mois de paie dans Next RH n'est pas renseigné (étape Organisation de la paie) : la cohérence du mois de reprise n'a pas pu être contrôlée." });
      }
    }
    if (kind === "leave_balances") {
      const lt = await db.select().from(schema.leaveTypes).where(eq(schema.leaveTypes.companyId, companyId));
      for (const r of parsed) {
        const t = lt.find((x) => x.code === r.values.leaveCode);
        if (t) r.values.leaveTypeId = t.id;
      }
    }
  }

  const errorLines = [...new Set(issues.filter((i) => i.level === "error" && i.line > 1).map((i) => i.line))];
  const dupLines = new Set(duplicates.map((d) => d.line));
  const headerErrors = issues.some((i) => i.level === "error" && i.line === 1);
  const validLines = headerErrors ? [] : parsed.filter((r) => !errorLines.includes(r.line) && !dupLines.has(r.line)).map((r) => r.line);

  await db
    .update(schema.dataImports)
    .set({ mapping, errors: issues, duplicates, status: headerErrors ? "mapped" : "validated" })
    .where(eq(schema.dataImports.id, importId));
  return { parsed, issues, duplicates, errorLines, validLines };
}

/** Applique en une transaction les lignes valides (sans erreur ni doublon). Tout ou rien. */
export async function applyImport(companyId: string, importId: string, userId: string, opts: { skipInvalid: boolean }) {
  const imp = await getImport(companyId, importId);
  if (!imp) return { error: "Import introuvable." } as const;
  if (imp.status === "applied") return { error: "Cet import a déjà été appliqué." } as const;
  const mapping = (imp.mapping as Record<string, string | null>) ?? {};
  const outcome = await validateImport(companyId, importId, mapping);
  if ("error" in outcome) return outcome;
  const blocked = outcome.errorLines.length + new Set(outcome.duplicates.map((d) => d.line)).size;
  if (outcome.issues.some((i) => i.level === "error" && i.line === 1)) return { error: "Des colonnes obligatoires ne sont pas associées." } as const;
  if (blocked > 0 && !opts.skipInvalid) return { error: `${blocked} ligne(s) en erreur ou en doublon. Corrigez le fichier, ou cochez « Ignorer les lignes en erreur ou en doublon ».` } as const;
  const rows = outcome.parsed.filter((r) => outcome.validLines.includes(r.line));
  if (rows.length === 0) return { error: "Aucune ligne valide à importer." } as const;
  const kind = imp.kind as ImportKind;
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, companyId)).limit(1);
  const today = isoToday();
  const s = (v: unknown) => (v === null || v === undefined || v === "" ? null : String(v));
  const n = (v: unknown) => (typeof v === "number" ? v : 0);

  try {
    const count = await db.transaction(async (tx) => {
      let applied = 0;
      for (const r of rows) {
        const v = r.values;
        if (kind === "employees") {
          const hire = String(v.hireDate);
          const [emp] = await tx
            .insert(schema.employees)
            .values({
              companyId,
              establishmentId: s(v.establishmentId),
              employeeNumber: s(v.employeeNumber),
              status: hire > today ? "draft" : "active",
              firstName: String(v.firstName),
              lastName: String(v.lastName),
              birthName: s(v.birthName),
              gender: (s(v.gender) as "F" | "M" | "X" | null) ?? null,
              birthDate: s(v.birthDate),
              birthPlace: s(v.birthPlace),
              nationality: s(v.nationality),
              nirEnc: v.nir ? encrypt(String(v.nir)) : null,
              email: s(v.email),
              phone: s(v.phone),
              addressLine1: s(v.addressLine1),
              postalCode: s(v.postalCode),
              city: s(v.city),
              jobTitle: s(v.jobTitle),
              department: s(v.department),
              hireDate: hire,
              isDemo: company?.isDemo ?? false,
            })
            .returning({ id: schema.employees.id });
          const weekly = v.weeklyHours ? Number(v.weeklyHours) : 35;
          const category = (s(v.category) ?? (v.contractType === "APPRENTISSAGE" ? "apprenti" : v.contractType === "STAGE" ? "stagiaire" : "non_cadre")) as (typeof schema.employeeCategoryEnum.enumValues)[number];
          const [contract] = await tx
            .insert(schema.contracts)
            .values({
              employeeId: emp.id,
              type: String(v.contractType) as (typeof schema.contractTypeEnum.enumValues)[number],
              category,
              startDate: hire,
              endDate: s(v.contractEndDate),
              trialEndDate: s(v.trialEndDate),
              jobTitle: s(v.jobTitle),
              classification: s(v.classification),
              coefficient: s(v.coefficient),
              weeklyHours: weekly.toFixed(2),
              monthlyHours: ((weekly * 52) / 12).toFixed(2),
              isPartTime: weekly < 35,
              isExecutive: category === "cadre" || category === "cadre_dirigeant",
            })
            .returning({ id: schema.contracts.id });
          await tx.insert(schema.compensations).values({ employeeId: emp.id, contractId: contract.id, effectiveDate: hire, basis: "monthly", grossAmountCents: n(v.grossMonthly), reason: "Reprise des données (import)", createdBy: userId });
          if (v.iban) {
            const iban = String(v.iban);
            await tx.insert(schema.employeeBankAccounts).values({ employeeId: emp.id, holderName: `${v.firstName} ${v.lastName}`, ibanEnc: encrypt(iban), ibanLast4: iban.slice(-4), bic: s(v.bic), isPrimary: true, validFrom: today });
          }
          await tx.insert(schema.employeeEvents).values({ employeeId: emp.id, kind: "reprise", effectiveDate: today, title: "Reprise du dossier depuis l'ancien logiciel", details: { importId, line: r.line, hireDate: hire }, affectsPayroll: false, createdBy: userId });
        } else if (kind === "compensations") {
          const effective = String(v.effectiveDate);
          await tx.insert(schema.compensations).values({ employeeId: String(v.employeeId), effectiveDate: effective, basis: (s(v.basis) ?? "monthly") as "monthly" | "hourly" | "annual", grossAmountCents: n(v.grossAmount), reason: s(v.reason) ?? "Historique importé", createdBy: userId });
        } else if (kind === "carryovers") {
          const values = {
            employeeId: String(v.employeeId),
            year: Number(v.year),
            throughMonth: Number(v.throughMonth),
            grossYtdCents: n(v.grossYtd),
            netTaxableYtdCents: n(v.netTaxableYtd),
            netPaidYtdCents: n(v.netPaidYtd),
            pasYtdCents: n(v.pasYtd),
            employeeContribYtdCents: n(v.employeeContribYtd),
            employerContribYtdCents: n(v.employerContribYtd),
            hoursYtd: s(v.hoursYtd) ?? "0",
            paidLeaveAcquired: s(v.paidLeaveAcquired) ?? "0",
            paidLeaveTaken: s(v.paidLeaveTaken) ?? "0",
            paidLeavePrevBalance: s(v.paidLeavePrevBalance) ?? "0",
            source: `import:${importId}`,
            confirmedAt: new Date(),
            confirmedBy: userId,
          };
          await tx
            .insert(schema.employeeCarryovers)
            .values(values)
            .onConflictDoUpdate({ target: [schema.employeeCarryovers.employeeId, schema.employeeCarryovers.year], set: { ...values } });
        } else if (kind === "leave_balances") {
          const values = {
            employeeId: String(v.employeeId),
            leaveTypeId: String(v.leaveTypeId),
            periodStart: String(v.periodStart),
            periodEnd: String(v.periodEnd),
            acquired: s(v.acquired) ?? "0",
            taken: s(v.taken) ?? "0",
            adjustment: s(v.adjustment) ?? "0",
          };
          await tx
            .insert(schema.leaveBalances)
            .values(values)
            .onConflictDoUpdate({ target: [schema.leaveBalances.employeeId, schema.leaveBalances.leaveTypeId, schema.leaveBalances.periodStart], set: { periodEnd: values.periodEnd, acquired: values.acquired, taken: values.taken, adjustment: values.adjustment } });
        }
        applied++;
      }
      await tx.update(schema.dataImports).set({ status: "applied", appliedCount: applied, appliedAt: new Date() }).where(eq(schema.dataImports.id, importId));
      return applied;
    });
    return { applied: count, skipped: outcome.parsed.length - count, kind } as const;
  } catch (e) {
    await db.update(schema.dataImports).set({ status: "failed" }).where(eq(schema.dataImports.id, importId));
    return { error: `L'import a échoué et rien n'a été enregistré : ${e instanceof Error ? e.message : "erreur inconnue"}.` } as const;
  }
}

export const importKindLabel = (k: string) => (k in IMPORT_SPECS ? IMPORT_SPECS[k as ImportKind].label : k);
