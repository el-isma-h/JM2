/**
 * Calendrier de paie (pur, sans dépendance) : jours ouvrés lundi-vendredi hors jours fériés de métropole.
 * Convention du moteur : l'horaire hebdomadaire est réparti sur 5 jours ; les jours fériés tombant un jour ouvré
 * sont chômés et rémunérés, et exclus du décompte des heures réelles du mois (numérateur et dénominateur).
 */

export function isoDate(y: number, m: number, d: number): string {
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

export function daysInMonth(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function addDaysIso(iso: string, n: number): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/** Jours fériés légaux de métropole (Pâques par l'algorithme de Meeus/Butcher). */
export function frenchHolidays(year: number): string[] {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  const easter = isoDate(year, month, day);
  return [
    `${year}-01-01`,
    addDaysIso(easter, 1), // lundi de Pâques
    `${year}-05-01`,
    `${year}-05-08`,
    addDaysIso(easter, 39), // Ascension
    addDaysIso(easter, 50), // lundi de Pentecôte
    `${year}-07-14`,
    `${year}-08-15`,
    `${year}-11-01`,
    `${year}-11-11`,
    `${year}-12-25`,
  ];
}

/** Jours ouvrés (lun-ven, hors fériés) entre deux dates ISO incluses. */
export function workingDays(startIso: string, endIso: string): number {
  if (startIso > endIso) return 0;
  const years = new Set<number>();
  for (let y = Number(startIso.slice(0, 4)); y <= Number(endIso.slice(0, 4)); y++) years.add(y);
  const holidays = new Set([...years].flatMap(frenchHolidays));
  let n = 0;
  for (let d = startIso; d <= endIso; d = addDaysIso(d, 1)) {
    const wd = new Date(`${d}T00:00:00Z`).getUTCDay();
    if (wd !== 0 && wd !== 6 && !holidays.has(d)) n++;
  }
  return n;
}

/** Jours calendaires entre deux dates ISO incluses. */
export function calendarDays(startIso: string, endIso: string): number {
  if (startIso > endIso) return 0;
  const a = Date.parse(`${startIso}T00:00:00Z`);
  const b = Date.parse(`${endIso}T00:00:00Z`);
  return Math.round((b - a) / 86400_000) + 1;
}

export function maxIso(...d: (string | null | undefined)[]): string {
  return d.filter((x): x is string => Boolean(x)).sort().at(-1)!;
}

export function minIso(...d: (string | null | undefined)[]): string {
  return d.filter((x): x is string => Boolean(x)).sort()[0];
}

/** Nombre de mois calendaires couverts par un contrat (pour détecter les contrats courts). */
export function monthsBetween(startIso: string, endIso: string): number {
  return calendarDays(startIso, endIso) / 30.4375;
}
