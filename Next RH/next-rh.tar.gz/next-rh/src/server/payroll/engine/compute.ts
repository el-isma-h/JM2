/**
 * Moteur de paie déterministe (pur) : PayslipInput + jeu de règles daté -> lignes, totaux, cumuls, anomalies, hash.
 * Aucune base de données, aucun appel réseau, aucun modèle de langage. Montants en centimes entiers.
 *
 * Arrondis : chaque ligne est arrondie au centime le plus proche (demi-centime en s'éloignant de zéro), voir decimal.ts.
 * Le coefficient de réduction générale est arrondi à 4 décimales (texte officiel).
 */
import { createHash } from "node:crypto";
import { canonicalJson, loadRuleSet, ruleSetChecksum, type ContributionRate, type RuleSet } from "../rules";
import { calendarDays, maxIso, minIso, monthsBetween, workingDays } from "./calendar";
import { addRates, applyRate, compareDecimal, divRound, fromScaled, minDecimal, mulDiv, roundTo, toScaled } from "./decimal";
import type { EngineAnomaly, EngineCumuls, PayslipInput, PayslipLine, PayslipResult, PayslipTotals } from "./types";

export const ENGINE_VERSION = "1.0.0";

const ABSENCE_LABELS: Record<string, string> = {
  CP: "Congés payés",
  RTT: "Repos (RTT)",
  CSS: "Congé sans solde",
  EVF: "Événement familial",
  MAL: "Arrêt maladie",
  MAT: "Congé maternité ou paternité",
};

const ROUND = "arrondi au centime le plus proche";
const PAID_ABSENCES = new Set(["CP", "RTT", "EVF", "TT"]);

/**
 * Répartition des heures supplémentaires transmise par le module temps dans `note` :
 * « 25 % : 6.00 h ; 50 % : 2.00 h ». Renvoie null si la note ne suit pas ce format.
 */
export function parseOvertimeSplit(note: string | null): { rate: string; hours: string }[] | null {
  if (!note) return null;
  const re = /(\d+(?:[.,]\d+)?)\s*%\s*:\s*(\d+(?:[.,]\d+)?)\s*h/g;
  const out: { rate: string; hours: string }[] = [];
  for (const m of note.matchAll(re)) out.push({ rate: m[1].replace(",", "."), hours: m[2].replace(",", ".") });
  return out.length ? out : null;
}

/** Segments (heures, majoration) d'une variable d'heures : taux saisi, sinon répartition de la note, sinon défaut. */
function overtimeSegments(v: { quantity: string | null; rate: string | null; note: string | null }, defaultRate: string) {
  if (v.rate !== null) return { segments: [{ hours: v.quantity!, rate: v.rate }], assumed: false, fromNote: false };
  const split = parseOvertimeSplit(v.note);
  if (split) return { segments: split.filter((s) => compareDecimal(s.hours, "0") > 0), assumed: false, fromNote: true };
  return { segments: [{ hours: v.quantity!, rate: defaultRate }], assumed: true, fromNote: false };
}

function fmtEur(cents: number): string {
  const neg = cents < 0;
  const a = Math.abs(cents);
  const s = `${Math.floor(a / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ")},${String(a % 100).padStart(2, "0")} €`;
  return neg ? `-${s}` : s;
}

function emptyTotals(): PayslipTotals {
  return {
    grossCents: 0,
    employeeContribCents: 0,
    employerContribCents: 0,
    employerReliefCents: 0,
    netSocialCents: 0,
    netTaxableCents: 0,
    netBeforeTaxCents: 0,
    pasRate: "0",
    pasBaseCents: 0,
    pasAmountCents: 0,
    pasKind: "neutre",
    netPaidCents: 0,
    employerCostCents: 0,
    hoursWorked: "0",
    hsExemptNetCents: 0,
  };
}

export function computeHashOf(input: PayslipInput, rs: RuleSet | null, pasRs: RuleSet | null): string {
  const payload = {
    engineVersion: ENGINE_VERSION,
    ruleSetVersion: rs?.version ?? null,
    ruleSetChecksum: rs ? ruleSetChecksum(rs) : null,
    pasRuleSetVersion: pasRs?.version ?? null,
    pasRuleSetChecksum: pasRs ? ruleSetChecksum(pasRs) : null,
    input,
  };
  return createHash("sha256").update(canonicalJson(payload)).digest("hex");
}

/** Barème neutre (grille de taux par défaut) : taux de la tranche contenant la base mensuelle. */
export function neutralRate(rs: RuleSet, baseCents: number): string {
  const grid = rs.params["pas.neutralGrid"].value;
  let rate = "0";
  for (const row of grid) if (baseCents >= row.fromCents) rate = row.rate;
  return rate;
}

/** Coefficient RGDU (4 décimales) à partir de cumuls de SMIC et de rémunération. */
export function rgduCoefficient(rs: RuleSet, smicCents: number, grossCents: number, gte50: boolean): number {
  const p = rs.params.rgdu.value;
  if (grossCents <= 0 || smicCents <= 0) return 0;
  const threshold = Number(p.thresholdSmic);
  if (grossCents >= threshold * smicCents) return 0;
  const tmin = Number(p.tmin);
  const tdelta = Number(gte50 ? p.tdeltaGte50 : p.tdeltaLt50);
  const ratio = (threshold * smicCents) / grossCents;
  const inner = 0.5 * (ratio - 1);
  const raw = tmin + tdelta * Math.pow(inner, Number(p.p));
  const capped = Math.min(raw, tmin + tdelta);
  return roundTo(capped, p.coefficientDecimals);
}

export function computePayslip(input: PayslipInput, opts: { ruleSet?: RuleSet | null; pasRuleSet?: RuleSet | null } = {}): PayslipResult {
  const rs = opts.ruleSet !== undefined ? opts.ruleSet : loadRuleSet(input.period.end);
  const pasRs = opts.pasRuleSet !== undefined ? opts.pasRuleSet : loadRuleSet(input.period.paymentDate);
  const anomalies: EngineAnomaly[] = [];
  const block = (code: string, title: string, explanation: string, details?: Record<string, unknown>) =>
    anomalies.push({ code, severity: "blocking", title, explanation, details });
  const warn = (code: string, title: string, explanation: string, details?: Record<string, unknown>) =>
    anomalies.push({ code, severity: "warning", title, explanation, details });
  const info = (code: string, title: string, explanation: string, details?: Record<string, unknown>) =>
    anomalies.push({ code, severity: "info", title, explanation, details });

  const computeHash = computeHashOf(input, rs, pasRs);
  const { period, company, contract, employee, variables } = input;
  const before = input.cumulsBefore;

  const blockedResult = (reason: string): PayslipResult => ({
    status: "blocked",
    ruleSetVersion: rs?.version ?? "aucune",
    pasRuleSetVersion: pasRs?.version ?? null,
    lines: [],
    totals: emptyTotals(),
    cumulative: before,
    anomalies,
    blockingReason: reason,
    computeHash,
    details: {
      plafondCents: 0,
      workingDaysMonth: 0,
      workingDaysPresent: 0,
      calendarDaysPresent: 0,
      monthlyReferenceCents: 0,
      rgdu: null,
      hsHours: "0",
      hcHours: "0",
      hsGrossCents: 0,
      unpaidAbsenceDays: "0",
      paidLeaveDays: "0",
    },
  });

  // ---------- 1. Contrôles de périmètre (anomalies bloquantes) ----------
  if (!rs) {
    block(
      "REGLES_ABSENTES",
      "Aucune règle de paie pour cette période",
      `Le moteur ne dispose pas de paramètres légaux vérifiés pour ${String(period.month).padStart(2, "0")}/${period.year}. Les périodes couvertes commencent en janvier 2026.`,
    );
  }
  if (!pasRs) {
    block("REGLES_PAS_ABSENTES", "Barème d'impôt indisponible à la date de paiement", `Aucun barème de prélèvement à la source vérifié pour un paiement le ${period.paymentDate}.`);
  }
  if (!contract) {
    block("CONTRAT_MANQUANT", "Contrat de travail manquant", `${employee.fullName} est actif mais aucun contrat ne couvre la période. Ajoutez le contrat dans la fiche du salarié.`);
  }
  if (contract && !["CDI", "CDD"].includes(contract.type)) {
    const label = { APPRENTISSAGE: "contrat d'apprentissage", PROFESSIONNALISATION: "contrat de professionnalisation", STAGE: "convention de stage", INTERIM: "contrat d'intérim", MANDAT: "mandat social" }[contract.type as string] ?? contract.type;
    block("CONTRAT_HORS_PERIMETRE", "Type de contrat non couvert", `Le moteur calcule les CDI et CDD de droit commun. Un ${label} relève de règles spécifiques (exonérations, assiettes, gratification) qui ne sont pas couvertes : ce bulletin doit être établi hors de Next RH.`);
  }
  if (contract && !["non_cadre", "cadre"].includes(contract.category)) {
    block("STATUT_HORS_PERIMETRE", "Statut du salarié non couvert", "Seuls les statuts non-cadre et cadre sont couverts. Les cadres dirigeants, apprentis et stagiaires relèvent de règles spécifiques.");
  }
  if (contract?.workTimeMode === "forfait_heures") {
    block("FORFAIT_HEURES", "Forfait en heures non couvert", "Les conventions de forfait en heures (avec heures supplémentaires intégrées) ne sont pas calculées par le moteur.");
  }
  if (contract?.workTimeMode === "forfait_jours" && contract.annualDays !== null && contract.annualDays !== 218) {
    block("FORFAIT_JOURS_REDUIT", "Forfait jours différent de 218 jours", `Le forfait de ${contract.annualDays} jours demande une proratisation spécifique de la réduction générale qui n'est pas couverte. Seul le forfait de 218 jours est calculé.`);
  }
  if (contract?.workTimeMode === "heures") {
    if (compareDecimal(contract.weeklyHours, "35") > 0) {
      block("HORAIRE_SUP_35H", "Horaire contractuel supérieur à 35 heures", `Le contrat prévoit ${contract.weeklyHours} h par semaine. Les heures supplémentaires structurelles intégrées au contrat ne sont pas couvertes : ramenez le contrat à 35 h et déclarez les heures en plus comme variables.`);
    }
    if (compareDecimal(contract.weeklyHours, "0") <= 0 || compareDecimal(contract.monthlyHours, "0") <= 0) {
      block("HORAIRE_INVALIDE", "Horaire du contrat invalide", "Les heures hebdomadaires et mensuelles du contrat doivent être renseignées.");
    }
  }

  // Paramètres entreprise
  const missingSettings: string[] = [];
  if (!company.headcountBracket) missingSettings.push("tranche d'effectif");
  if (company.atRate === null || !/^\d+(\.\d+)?$/.test(company.atRate)) missingSettings.push("taux accident du travail");
  if (company.mobilityRate === null || !/^\d+(\.\d+)?$/.test(company.mobilityRate)) missingSettings.push("versement mobilité");
  if (!company.mutuelleConfigured) missingSettings.push("mutuelle (ou absence de mutuelle)");
  if (!company.prevoyanceConfigured) missingSettings.push("prévoyance (ou absence de prévoyance)");
  if (missingSettings.length) {
    block("PARAMETRE_A_CONFIRMER", "Paramètre de paie à confirmer dans l'onboarding", `Ces paramètres de l'entreprise déterminent le calcul et ne sont pas confirmés : ${missingSettings.join(", ")}. Complétez-les dans l'onboarding (étape paie).`, { missing: missingSettings });
  }
  const pc = company.establishmentPostalCode ?? "";
  if (/^(57|67|68)/.test(pc)) {
    block("ALSACE_MOSELLE", "Régime local d'Alsace-Moselle non couvert", "L'établissement est situé en Alsace-Moselle : la cotisation maladie salariale du régime local et la taxe d'apprentissage spécifique ne sont pas couvertes.");
  }
  if (/^9[78]/.test(pc)) {
    block("OUTRE_MER", "Établissement d'outre-mer non couvert", "Le moteur couvre la métropole uniquement (SMIC, barème d'impôt et exonérations différents outre-mer).");
  }

  // Rémunération
  const presenceStart = maxIso(period.start, contract?.startDate, employee.hireDate);
  const presenceEnd = minIso(period.end, contract?.endDate ?? period.end, employee.leaveDate ?? period.end);
  const comps = input.compensations.filter((c) => c.effectiveDate <= period.end && (c.endDate === null || c.endDate >= period.start));
  if (!comps.length) {
    block("REMUNERATION_MANQUANTE", "Rémunération manquante", `Aucun salaire de base en vigueur sur la période pour ${employee.fullName}. Renseignez la rémunération dans la fiche du salarié.`);
  } else if (comps.some((c) => c.effectiveDate > presenceStart && c.effectiveDate <= presenceEnd)) {
    block("CHANGEMENT_SALAIRE_EN_COURS_DE_MOIS", "Changement de salaire en cours de mois", "Une nouvelle rémunération prend effet en cours de mois. Le calcul au prorata de deux salaires n'est pas couvert : fixez la date d'effet au 1er du mois ou au mois suivant.");
  }
  const comp = comps.sort((a, b) => b.effectiveDate.localeCompare(a.effectiveDate))[0];
  if (comp && contract?.workTimeMode === "forfait_jours" && comp.basis === "hourly") {
    block("FORFAIT_JOURS_HORAIRE", "Salaire horaire incompatible avec un forfait jours", "Un salarié au forfait jours doit avoir une rémunération mensuelle ou annuelle.");
  }
  if (presenceStart > presenceEnd) {
    block("AUCUNE_PRESENCE", "Aucun jour de contrat sur la période", "Les dates d'entrée, de sortie ou de contrat ne couvrent aucun jour du mois.");
  }

  // Variables
  const isForfait = contract?.workTimeMode === "forfait_jours";
  const fullMonth = presenceStart === period.start && presenceEnd === period.end;
  if (isForfait && !fullMonth) {
    block("FORFAIT_JOURS_PRORATA", "Entrée ou sortie en cours de mois au forfait jours", "La proratisation d'un forfait jours en cours de mois n'est pas couverte.");
  }
  for (const v of variables) {
    const qtyOk = v.quantity !== null && /^-?\d+(\.\d+)?$/.test(v.quantity);
    switch (v.kind) {
      case "absence": {
        const code = (v.note ?? "").toUpperCase();
        if (code === "MAL") block("ABSENCE_MALADIE", "Arrêt maladie non couvert", `${v.label} : le maintien de salaire, les indemnités journalières et la subrogation ne sont pas calculés par le moteur.`, { variableId: v.id });
        else if (code === "MAT") block("ABSENCE_MATERNITE", "Congé maternité ou paternité non couvert", `${v.label} : les indemnités journalières et le maintien éventuel ne sont pas calculés par le moteur.`, { variableId: v.id });
        else if (!(code in ABSENCE_LABELS)) block("ABSENCE_INCONNUE", "Type d'absence inconnu", `${v.label} : le code d'absence « ${v.note ?? "vide"} » n'est pas reconnu (CP, RTT, CSS, EVF attendus).`, { variableId: v.id });
        else if (!qtyOk || compareDecimal(v.quantity!, "0") < 0) block("ABSENCE_QUANTITE", "Durée d'absence manquante", `${v.label} : indiquez le nombre de jours.`, { variableId: v.id });
        else if (isForfait && code === "CSS") block("FORFAIT_JOURS_ABSENCE", "Absence non rémunérée au forfait jours", "La retenue pour absence d'un salarié au forfait jours n'est pas couverte.", { variableId: v.id });
        break;
      }
      case "heures_sup":
      case "heures_comp": {
        if (!qtyOk || compareDecimal(v.quantity!, "0") <= 0) block("HEURES_QUANTITE", "Nombre d'heures manquant", `${v.label} : indiquez un nombre d'heures positif.`, { variableId: v.id });
        if (isForfait) block("FORFAIT_JOURS_HEURES", "Heures supplémentaires au forfait jours", "Un salarié au forfait jours n'effectue pas d'heures supplémentaires décomptées.", { variableId: v.id });
        else if (v.kind === "heures_sup" && contract?.isPartTime) block("HS_TEMPS_PARTIEL", "Heures supplémentaires sur un temps partiel", "Un salarié à temps partiel effectue des heures complémentaires : saisissez-les en heures complémentaires.", { variableId: v.id });
        else if (v.kind === "heures_comp" && contract && !contract.isPartTime) block("HC_TEMPS_PLEIN", "Heures complémentaires sur un temps plein", "Les heures complémentaires concernent les temps partiels. Pour un temps plein, saisissez des heures supplémentaires.", { variableId: v.id });
        if (v.rate !== null && !/^\d+(\.\d+)?$/.test(v.rate)) block("HEURES_MAJORATION", "Majoration invalide", `${v.label} : la majoration doit être un pourcentage (25 ou 50).`, { variableId: v.id });
        const split = v.rate === null ? parseOvertimeSplit(v.note) : null;
        if (split && qtyOk) {
          const sum = split.reduce((s, x) => s + toScaled(x.hours), BigInt(0));
          if (sum !== toScaled(v.quantity!)) {
            block("HEURES_REPARTITION", "Répartition des heures incohérente", `${v.label} : la répartition « ${v.note} » totalise ${fromScaled(sum, 2)} h alors que la variable indique ${v.quantity} h. Corrigez la feuille de temps ou saisissez la majoration.`, { variableId: v.id });
          }
        }
        break;
      }
      case "prime":
      case "commission":
      case "avantage_nature":
      case "indemnite":
      case "acompte":
        if (v.amountCents === null || v.amountCents < 0) block("MONTANT_MANQUANT", "Montant manquant", `${v.label} : indiquez un montant positif.`, { variableId: v.id });
        break;
      case "regularisation": {
        if (v.amountCents !== null) break;
        const code = (v.note ?? "").toUpperCase();
        if (v.source === "leave_annulation" && PAID_ABSENCES.has(code)) {
          // Annulation d'une absence rémunérée (maintien de salaire) : aucun effet sur la paie.
          info("REGULARISATION_ABSENCE_PAYEE", "Annulation d'une absence rémunérée", `${v.label} : l'absence annulée était rémunérée par maintien de salaire, la régularisation n'a pas d'effet sur le montant du bulletin. Les compteurs de congés sont mis à jour par le module congés.`, { variableId: v.id });
        } else if (v.source === "leave_annulation" && code === "CSS") {
          block("REGULARISATION_ABSENCE_A_VALORISER", "Remboursement d'une retenue pour absence à saisir", `${v.label} : le congé sans solde annulé (${v.quantity ?? "?"} j) avait été retenu sur un mois déjà validé. La retenue dépend du salaire et des heures réelles de ce mois-là : saisissez le montant exact à rembourser (variable « régularisation » en montant), puis supprimez cette ligne.`, { variableId: v.id });
        } else if (v.source === "leave_annulation" && (code === "MAL" || code === "MAT")) {
          block("REGULARISATION_ABSENCE_HORS_PERIMETRE", "Régularisation d'arrêt non couverte", `${v.label} : la régularisation d'un arrêt maladie ou d'un congé maternité ou paternité n'est pas couverte par le moteur.`, { variableId: v.id });
        } else if (v.source === "timesheet_annulation") {
          block("REGULARISATION_HS_A_VALORISER", "Régularisation d'heures supplémentaires à valoriser", `${v.label} : des heures supplémentaires payées sur un mois validé ont été annulées (${v.quantity ?? "?"} h). Saisissez le montant brut à reprendre (variable « régularisation » en montant négatif), puis supprimez cette ligne.`, { variableId: v.id });
        } else {
          block("REGULARISATION_A_VALORISER", "Régularisation à valoriser", `${v.label} : la régularisation est exprimée en quantité uniquement. Saisissez le montant à régulariser.`, { variableId: v.id });
        }
        break;
      }
      case "titres_restaurant": {
        const n = v.quantity;
        if (!qtyOk || v.amountCents === null || v.amountCents <= 0 || v.rate === null) {
          block("TR_INCOMPLET", "Titres-restaurant incomplets", `${v.label} : indiquez le nombre de titres, leur valeur unitaire et la part patronale en %.`, { variableId: v.id });
        } else if (rs) {
          const tr = rs.params.titresRestaurant.value;
          const employerShare = applyRate(v.amountCents, v.rate);
          if (compareDecimal(v.rate, tr.minShare) < 0 || compareDecimal(v.rate, tr.maxShare) > 0 || employerShare > tr.maxEmployerShareCents) {
            block("TR_HORS_EXONERATION", "Titres-restaurant hors limite d'exonération", `La part patronale (${v.rate} %, soit ${fmtEur(employerShare)} par titre) doit être comprise entre ${tr.minShare} et ${tr.maxShare} % et ne pas dépasser ${fmtEur(tr.maxEmployerShareCents)}. La réintégration de l'excédent dans l'assiette n'est pas couverte.`, { variableId: v.id, quantity: n });
          }
        }
        break;
      }
      case "saisie":
        block("SAISIE_SALAIRE", "Saisie sur salaire non couverte", "Le calcul de la fraction saisissable n'est pas couvert par le moteur.", { variableId: v.id });
        break;
      case "autre":
        block("VARIABLE_AUTRE", "Élément de paie non qualifié", `${v.label} : choisissez un type précis (prime, avantage en nature, indemnité de frais…) pour que le régime social soit connu.`, { variableId: v.id });
        break;
    }
  }

  // Contrat court sans taux transmis : abattement spécifique non couvert
  if (contract?.type === "CDD" && contract.endDate && monthsBetween(contract.startDate, contract.endDate) <= 2 && (!input.pas || input.pas.isNeutral)) {
    block("PAS_CONTRAT_COURT", "Contrat court sans taux d'imposition", "Un CDD de deux mois au plus sans taux transmis par l'administration bénéficie d'un abattement spécifique qui n'est pas appliqué par le moteur. Récupérez le taux personnalisé du salarié.");
  }

  // Seuil de 20 salariés pour la déduction forfaitaire heures supplémentaires
  const hsHoursTotal = variables.filter((v) => v.kind === "heures_sup" && v.quantity).reduce((s, v) => s + toScaled(v.quantity!), BigInt(0));
  let deductionPerHour: number | null = null;
  if (hsHoursTotal > BigInt(0) && rs) {
    const ded = rs.params["hs.deductionForfaitaire"].value;
    const n = company.headcount;
    const bracket = company.headcountBracket;
    // "unknown" : effectif insuffisamment précis (tranche 11 à 49 sans effectif exact) pour le seuil de 20 salariés.
    let resolved: number | null | "unknown";
    if (n !== null && n >= 0) resolved = n < 20 ? ded.lt20Cents : n < 250 ? ded.from20to249Cents : ded.gte250Cents;
    else if (bracket === "lt11") resolved = ded.lt20Cents;
    else if (bracket === "50to249") resolved = ded.from20to249Cents;
    else if (bracket === "gte250") resolved = ded.gte250Cents;
    else resolved = "unknown";
    if (resolved === "unknown") {
      block("EFFECTIF_20", "Effectif exact nécessaire pour les heures supplémentaires", "La déduction patronale sur les heures supplémentaires dépend du seuil de 20 salariés. Renseignez l'effectif exact de l'entreprise.");
    } else if (resolved === null) {
      block("HS_250_NON_CONFIRME", "Heures supplémentaires : entreprise de 250 salariés ou plus", "La déduction forfaitaire patronale pour les entreprises de 250 salariés et plus n'a pas pu être confirmée par une source officielle : ce cas n'est pas couvert.");
    } else {
      deductionPerHour = resolved;
    }
  }

  if (anomalies.some((a) => a.severity === "blocking") || !rs || !pasRs || !contract || !comp) {
    const first = anomalies.find((a) => a.severity === "blocking");
    return blockedResult(first ? first.title : "Calcul impossible");
  }

  // ---------- 2. Rémunération brute ----------
  const P = rs.params;
  const lines: PayslipLine[] = [];
  const monthlyHours = contract.monthlyHours;
  const weeklyHours = isForfait ? "35" : contract.weeklyHours;
  const monthlyRef =
    comp.basis === "monthly" ? comp.grossAmountCents : comp.basis === "annual" ? Number(divRound(BigInt(comp.grossAmountCents), BigInt(12))) : mulDiv(comp.grossAmountCents, monthlyHours, "1");
  const wdMonth = workingDays(period.start, period.end);
  const wdPresent = workingDays(presenceStart, presenceEnd);
  const cdPresent = calendarDays(presenceStart, presenceEnd);
  const hourlyDisplay = fromScaled(divRound(BigInt(monthlyRef) * BigInt(10) ** BigInt(12), toScaled(monthlyHours) * BigInt(100)), 4);

  const expectedMonthly = fromScaled(divRound(toScaled(weeklyHours) * BigInt(52), BigInt(12)), 2);
  if (!isForfait && Math.abs(Number(expectedMonthly) - Number(monthlyHours)) > 0.011) {
    warn("HEURES_MENSUELLES_INCOHERENTES", "Heures mensuelles à vérifier", `Le contrat indique ${monthlyHours} h par mois pour ${contract.weeklyHours} h par semaine (attendu : ${expectedMonthly} h, soit horaire x 52 / 12). Le taux horaire utilisé pour les heures supplémentaires et les retenues en dépend.`);
  }

  lines.push({
    code: "SALAIRE_BASE",
    label: isForfait ? "Salaire de base (forfait 218 jours)" : "Salaire de base",
    section: "brut",
    kind: "gain",
    base: null,
    quantity: isForfait ? null : monthlyHours,
    rate_employee: isForfait ? null : hourlyDisplay,
    amount_employee: monthlyRef,
    rate_employer: null,
    amount_employer: 0,
    rounding:
      comp.basis === "monthly"
        ? "Salaire mensuel contractuel."
        : comp.basis === "annual"
          ? `Salaire annuel / 12, ${ROUND}.`
          : `Taux horaire x ${monthlyHours} h, ${ROUND}.`,
  });

  let paidBase = monthlyRef;
  if (!fullMonth) {
    const prorated = Number(divRound(BigInt(monthlyRef) * BigInt(wdPresent), BigInt(wdMonth)));
    const diff = monthlyRef - prorated;
    paidBase = prorated;
    const isEntry = presenceStart > period.start;
    const isExit = presenceEnd < period.end;
    lines.push({
      code: "ENTREE_SORTIE",
      label: isEntry && isExit ? "Entrée et sortie en cours de mois" : isEntry ? `Entrée en cours de mois (le ${presenceStart.slice(8, 10)}/${presenceStart.slice(5, 7)})` : `Sortie en cours de mois (le ${presenceEnd.slice(8, 10)}/${presenceEnd.slice(5, 7)})`,
      section: "brut",
      kind: "gain",
      base: monthlyRef,
      quantity: `${wdMonth - wdPresent}`,
      rate_employee: null,
      amount_employee: -diff,
      rate_employer: null,
      amount_employer: 0,
      rounding: `Retenue = salaire x jours ouvrés d'absence au contrat (${wdMonth - wdPresent}) / jours ouvrés du mois (${wdMonth}), méthode des heures réelles (horaire réparti sur 5 jours), ${ROUND}.`,
    });
    if (isExit) {
      warn("SOLDE_TOUT_COMPTE", "Sortie : éléments du solde de tout compte à ajouter", `${employee.fullName} quitte l'entreprise le ${presenceEnd}. Le moteur ne calcule pas l'indemnité compensatrice de congés payés${contract.type === "CDD" ? ", l'indemnité de fin de contrat (précarité)" : ""} ni les indemnités de rupture : ajoutez les montants dus en variable « prime » (soumise) si besoin, ou traitez-les hors moteur.`);
    }
  }

  // Absences
  let unpaidDays = BigInt(0);
  let paidLeaveDays = BigInt(0);
  for (const v of variables.filter((x) => x.kind === "absence")) {
    const code = (v.note ?? "").toUpperCase();
    const days = toScaled(v.quantity!);
    if (code === "CSS") {
      unpaidDays += days;
      const retenue = mulDiv(monthlyRef, v.quantity!, String(wdMonth));
      lines.push({
        code: "ABSENCE_NON_REMUNEREE",
        label: `${v.label || ABSENCE_LABELS.CSS} (${fromScaled(days, 2)} j)`,
        section: "brut",
        kind: "gain",
        base: monthlyRef,
        quantity: fromScaled(days, 2),
        rate_employee: null,
        amount_employee: -retenue,
        rate_employer: null,
        amount_employer: 0,
        rounding: `Retenue au réel = salaire x heures d'absence (${fromScaled(days, 2)} j x ${fromScaled(divRound(toScaled(weeklyHours), BigInt(5)), 2)} h) / heures réelles du mois (${wdMonth} j x ${fromScaled(divRound(toScaled(weeklyHours), BigInt(5)), 2)} h), ${ROUND}.`,
      });
      paidBase -= retenue;
    } else {
      if (code === "CP") paidLeaveDays += days;
      lines.push({
        code: `ABSENCE_${code}`,
        label: `${v.label || ABSENCE_LABELS[code]} : ${fromScaled(days, 2)} j, salaire maintenu`,
        section: "info",
        kind: "info",
        base: null,
        quantity: fromScaled(days, 2),
        rate_employee: null,
        amount_employee: 0,
        rate_employer: null,
        amount_employer: 0,
        rounding: "Absence rémunérée : aucune retenue (maintien du salaire).",
      });
    }
  }
  if (unpaidDays > toScaled(wdPresent)) {
    block("ABSENCE_SUPERIEURE_PRESENCE", "Absences supérieures aux jours travaillés", `Les absences non rémunérées (${fromScaled(unpaidDays, 2)} j) dépassent les jours ouvrés de présence (${wdPresent} j).`);
    return blockedResult("Absences supérieures aux jours travaillés");
  }
  if (paidLeaveDays > BigInt(0)) {
    info("CP_MAINTIEN", "Congés payés indemnisés par maintien de salaire", `${fromScaled(paidLeaveDays, 2)} jour(s) de congés payés pris, indemnisés par maintien du salaire. La comparaison avec la règle du dixième se fait en fin de période de référence et n'est pas réalisée par le moteur.`);
  }

  // Heures supplémentaires et complémentaires
  let hsGross = 0;
  let hsHours = BigInt(0);
  let hcHours = BigInt(0);
  for (const v of variables.filter((x) => x.kind === "heures_sup" || x.kind === "heures_comp")) {
    const isHs = v.kind === "heures_sup";
    const defaultRate = isHs ? "25" : "10";
    const { segments, assumed, fromNote } = overtimeSegments(v, defaultRate);
    if (assumed) {
      warn(isHs ? "HS_MAJORATION_SUPPOSEE" : "HC_MAJORATION_SUPPOSEE", "Majoration supposée", `${v.label} : aucune majoration indiquée, ${defaultRate} % appliqués (${isHs ? "8 premières heures de la semaine" : "heures dans la limite du dixième de la durée contractuelle"}). Vérifiez la répartition par semaine.`, { variableId: v.id });
    }
    for (const seg of segments) {
    const maj = seg.rate;
    const hours = toScaled(seg.hours);
    if (isHs) hsHours += hours;
    else hcHours += hours;
    const amount = Number(divRound(BigInt(monthlyRef) * hours * toScaled(addRates("100", maj)), toScaled(monthlyHours) * toScaled("100")));
    hsGross += amount;
    lines.push({
      code: isHs ? `HEURES_SUP_${maj}` : `HEURES_COMP_${maj}`,
      label: `${isHs ? "Heures supplémentaires" : "Heures complémentaires"} majorées à ${maj} %`,
      section: "brut",
      kind: "gain",
      base: null,
      quantity: fromScaled(hours, 2),
      rate_employee: fromScaled(divRound(BigInt(monthlyRef) * toScaled(addRates("100", maj)) * BigInt(10) ** BigInt(6), toScaled(monthlyHours) * BigInt(100) * BigInt(100)), 4),
      amount_employee: amount,
      rate_employer: null,
      amount_employer: 0,
      rounding: `Salaire mensuel / ${monthlyHours} h x ${fromScaled(hours, 2)} h x ${addRates("100", maj)} %, ${ROUND} (calcul en une seule opération, sans arrondi intermédiaire du taux horaire)${fromNote ? ` ; répartition issue de la feuille de temps (${v.note})` : ""}.`,
    });
    }
  }

  for (const v of variables) {
    if (v.kind === "regularisation" && v.amountCents === null) {
      // Seul cas non bloquant : annulation d'une absence rémunérée, sans effet sur le montant.
      lines.push({ code: "REGULARISATION_INFO", label: `${v.label} (sans effet sur le montant)`, section: "info", kind: "info", base: null, quantity: v.quantity, rate_employee: null, amount_employee: 0, rate_employer: null, amount_employer: 0, rounding: "Absence rémunérée par maintien : l'annulation ne modifie pas le salaire." });
      continue;
    }
    if (v.kind === "prime" || v.kind === "commission" || v.kind === "regularisation") {
      lines.push({
        code: v.kind === "regularisation" ? "REGULARISATION" : v.kind === "commission" ? "COMMISSION" : "PRIME",
        label: v.label,
        section: "brut",
        kind: "gain",
        base: null,
        rate_employee: null,
        amount_employee: v.amountCents!,
        rate_employer: null,
        amount_employer: 0,
        rounding: "Montant saisi.",
      });
    }
    if (v.kind === "avantage_nature") {
      lines.push({
        code: "AVANTAGE_NATURE",
        label: `Avantage en nature : ${v.label}`,
        section: "brut",
        kind: "gain",
        base: null,
        rate_employee: null,
        amount_employee: v.amountCents!,
        rate_employer: null,
        amount_employer: 0,
        rounding: "Montant déclaré, intégré au brut soumis puis déduit du net.",
      });
    }
  }

  const gross = lines.filter((l) => l.section === "brut").reduce((s, l) => s + l.amount_employee, 0);
  if (gross < 0) {
    block("BRUT_NEGATIF", "Salaire brut négatif", "Les retenues dépassent la rémunération du mois. Vérifiez les absences et régularisations.");
    return blockedResult("Salaire brut négatif");
  }

  // ---------- 3. Plafond et tranches ----------
  const pmss = P.pmss.value;
  const plafond = fullMonth ? pmss : Math.min(pmss, Number(divRound(BigInt(pmss) * BigInt(cdPresent), BigInt(P["plafond.prorata"].value.divisor))));
  const T1 = Math.min(gross, plafond);
  const T2 = Math.min(Math.max(gross - plafond, 0), 7 * plafond);
  const fourP = Math.min(gross, 4 * plafond);
  const plafondNote = fullMonth ? `PMSS ${fmtEur(pmss)}` : `plafond proratisé ${fmtEur(plafond)} (PMSS x ${cdPresent} j calendaires / 30)`;
  const baseOf = (b: ContributionRate["base"]) => (b === "total" ? gross : b === "T1" ? T1 : b === "T2" ? T2 : b === "T1T2" ? T1 + T2 : b === "4P" ? fourP : 0);
  const baseText = (b: ContributionRate["base"]) =>
    b === "total" ? "totalité du brut" : b === "T1" ? `tranche 1 (jusqu'au ${plafondNote})` : b === "T2" ? "tranche 2 (de 1 à 8 plafonds)" : b === "T1T2" ? "tranches 1 et 2" : "brut dans la limite de 4 plafonds";

  const contrib = (
    key: keyof typeof P,
    code: string,
    label: string,
    section: PayslipLine["section"],
    organism: PayslipLine["organism"],
    opts2: { employer?: boolean; employee?: boolean } = {},
  ) => {
    const r = (P[key] as { value: ContributionRate }).value;
    const base = baseOf(r.base);
    const ae = opts2.employee === false ? 0 : applyRate(base, r.employee);
    const ar = opts2.employer === false ? 0 : applyRate(base, r.employer);
    if (base === 0 && ae === 0 && ar === 0 && r.base === "T2") return;
    lines.push({
      code,
      label,
      section,
      kind: "contribution",
      base,
      rate_employee: compareDecimal(r.employee, "0") === 0 ? null : r.employee,
      amount_employee: ae,
      rate_employer: compareDecimal(r.employer, "0") === 0 ? null : r.employer,
      amount_employer: ar,
      rounding: `Assiette : ${baseText(r.base)} ; montant = assiette x taux, ${ROUND}.`,
      rule: String(key),
      organism,
      deductible: true,
    });
  };

  const isCadre = contract.category === "cadre";
  const bracket = company.headcountBracket!;
  const gte11 = bracket !== "lt11";
  const gte50 = bracket === "50to249" || bracket === "gte250";

  // Santé
  contrib("contrib.maladie", "SS_MALADIE", "Sécurité sociale : maladie, maternité, invalidité, décès", "sante", "urssaf");
  let employerPrev = 0;
  if (company.prevoyance) {
    const pr = company.prevoyance;
    const re = isCadre ? pr.cadreEmployeeRate : pr.nonCadreEmployeeRate;
    const rr = isCadre ? pr.cadreEmployerRate : pr.nonCadreEmployerRate;
    const base = Math.min(gross, 8 * plafond);
    const ae = applyRate(base, re);
    employerPrev = applyRate(base, rr);
    lines.push({
      code: "PREVOYANCE",
      label: `Complémentaire incapacité, invalidité, décès (${pr.name})`,
      section: "sante",
      kind: "contribution",
      base,
      rate_employee: re,
      amount_employee: ae,
      rate_employer: rr,
      amount_employer: employerPrev,
      rounding: `Assiette : brut dans la limite de 8 plafonds (taux uniques du contrat) ; ${ROUND}.`,
      rule: "settings.prevoyance",
      organism: "prevoyance",
      deductible: true,
    });
    if (isCadre) {
      const min = applyRate(T1, P["prevoyance.cadreMinEmployerRateT1"].value);
      if (employerPrev < min) {
        warn("PREVOYANCE_CADRE_MINIMUM", "Prévoyance cadre sous le minimum de 1,50 %", `La part patronale de prévoyance (${fmtEur(employerPrev)}) est inférieure à 1,50 % de la tranche 1 (${fmtEur(min)}) prévue par l'accord national de 2017 pour les cadres.`);
      }
    }
  } else if (isCadre) {
    warn("PREVOYANCE_CADRE_ABSENTE", "Cadre sans prévoyance", "L'accord national de 2017 impose une prévoyance financée par l'employeur à hauteur de 1,50 % de la tranche 1 pour les cadres. Aucun contrat de prévoyance n'est renseigné.");
  }
  let employerMutuelle = 0;
  if (company.mutuelle) {
    const m = company.mutuelle;
    employerMutuelle = m.employerCents;
    lines.push({
      code: "MUTUELLE",
      label: `Complémentaire santé (${m.name})`,
      section: "sante",
      kind: "contribution",
      base: null,
      rate_employee: null,
      amount_employee: m.employeeCents,
      rate_employer: null,
      amount_employer: m.employerCents,
      rounding: "Cotisation forfaitaire mensuelle du contrat (montants fixes).",
      rule: "settings.mutuelle",
      organism: "mutuelle",
      deductible: true,
    });
  }

  // AT/MP
  {
    const r = company.atRate!;
    lines.push({
      code: "ATMP",
      label: "Accidents du travail et maladies professionnelles",
      section: "atmp",
      kind: "contribution",
      base: gross,
      rate_employee: null,
      amount_employee: 0,
      rate_employer: r,
      amount_employer: applyRate(gross, r),
      rounding: `Assiette : totalité du brut ; taux notifié à l'entreprise ; ${ROUND}.`,
      rule: "settings.atRate",
      organism: "urssaf",
      deductible: true,
    });
  }

  // Retraite
  contrib("contrib.vieillessePlafonnee", "SS_VIEILLESSE_PLAF", "Sécurité sociale plafonnée", "retraite", "urssaf");
  contrib("contrib.vieillesseDeplafonnee", "SS_VIEILLESSE_DEPLAF", "Sécurité sociale déplafonnée", "retraite", "urssaf");
  contrib("contrib.agircT1", "RC_T1", "Complémentaire tranche 1", "retraite", "retraite");
  contrib("contrib.cegT1", "CEG_T1", "Contribution d'équilibre général tranche 1", "retraite", "retraite");
  if (T2 > 0) {
    contrib("contrib.agircT2", "RC_T2", "Complémentaire tranche 2", "retraite", "retraite");
    contrib("contrib.cegT2", "CEG_T2", "Contribution d'équilibre général tranche 2", "retraite", "retraite");
  }
  if (gross > plafond) contrib("contrib.cet", "CET", "Contribution d'équilibre technique", "retraite", "retraite");

  // Famille
  contrib("contrib.allocationsFamiliales", "ALLOC_FAM", "Famille : allocations familiales", "famille", "urssaf");

  // Assurance chômage
  contrib("contrib.chomage", "CHOMAGE", "Assurance chômage", "chomage", "urssaf");
  if (isCadre) contrib("contrib.apec", "APEC", "APEC (cadres)", "chomage", "retraite");

  // Autres contributions dues par l'employeur
  contrib("contrib.ags", "AGS", "Garantie des salaires (AGS)", "autres_contributions", "urssaf");
  contrib("contrib.csa", "CSA", "Contribution solidarité autonomie", "autres_contributions", "urssaf");
  contrib(gte50 ? "contrib.fnalGte50" : "contrib.fnalLt50", "FNAL", "Fonds national d'aide au logement", "autres_contributions", "urssaf");
  contrib("contrib.dialogueSocial", "DIALOGUE_SOCIAL", "Contribution au dialogue social", "autres_contributions", "urssaf");
  contrib(gte11 ? "contrib.formationGte11" : "contrib.formationLt11", "FORMATION", "Contribution à la formation professionnelle", "autres_contributions", "urssaf");
  contrib("contrib.taxeApprentissage", "TAXE_APPRENTISSAGE", "Taxe d'apprentissage (part principale)", "autres_contributions", "urssaf");
  if (contract.type === "CDD") contrib("contrib.cpfCdd", "CPF_CDD", "Contribution CPF des CDD", "autres_contributions", "urssaf");
  if (compareDecimal(company.mobilityRate!, "0") > 0) {
    if (gte11) {
      lines.push({
        code: "VERSEMENT_MOBILITE",
        label: "Versement mobilité",
        section: "autres_contributions",
        kind: "contribution",
        base: gross,
        rate_employee: null,
        amount_employee: 0,
        rate_employer: company.mobilityRate!,
        amount_employer: applyRate(gross, company.mobilityRate!),
        rounding: `Assiette : totalité du brut ; taux de l'autorité organisatrice de la mobilité ; ${ROUND}.`,
        rule: "settings.mobilityRate",
        organism: "urssaf",
        deductible: true,
      });
    } else {
      info("VM_NON_ASSUJETTI", "Versement mobilité non appliqué", "Un taux de versement mobilité est renseigné mais l'entreprise compte moins de 11 salariés : elle n'y est pas assujettie.");
    }
  }
  const fsRule = P["contrib.forfaitSocialPrevoyance"].value;
  if (gte11 && employerPrev + employerMutuelle > 0) {
    const base = employerPrev + employerMutuelle;
    lines.push({
      code: "FORFAIT_SOCIAL",
      label: "Forfait social sur prévoyance et santé",
      section: "autres_contributions",
      kind: "contribution",
      base,
      rate_employee: null,
      amount_employee: 0,
      rate_employer: fsRule.employer,
      amount_employer: applyRate(base, fsRule.employer),
      rounding: `Assiette : parts patronales de prévoyance et de complémentaire santé ; ${ROUND}.`,
      rule: "contrib.forfaitSocialPrevoyance",
      organism: "urssaf",
      deductible: true,
    });
  }

  // ---------- 4. Exonérations heures supplémentaires ----------
  const sumEmployee = (pred: (l: PayslipLine) => boolean) => lines.filter(pred).reduce((s, l) => s + l.amount_employee, 0);
  let reductionSalariale = 0;
  if (hsGross > 0) {
    const maxRate = P["hs.reductionSalariale"].value.maxRate;
    const retirementCodes = new Set(["SS_VIEILLESSE_PLAF", "SS_VIEILLESSE_DEPLAF", "RC_T1", "CEG_T1", "RC_T2", "CEG_T2", "CET"]);
    if (gross <= plafond) {
      const r = addRates(
        P["contrib.vieillessePlafonnee"].value.employee,
        P["contrib.vieillesseDeplafonnee"].value.employee,
        P["contrib.agircT1"].value.employee,
        P["contrib.cegT1"].value.employee,
      );
      reductionSalariale = applyRate(hsGross, minDecimal(r, maxRate));
    } else {
      const retAmounts = sumEmployee((l) => retirementCodes.has(l.code));
      reductionSalariale = Math.min(applyRate(hsGross, maxRate), Number(divRound(BigInt(hsGross) * BigInt(retAmounts), BigInt(gross))));
    }
    lines.push({
      code: "REDUCTION_SALARIALE_HS",
      label: "Réduction de cotisations salariales heures supplémentaires",
      section: "exonerations",
      kind: "reduction",
      base: hsGross,
      rate_employee: gross <= plafond ? minDecimal(addRates(P["contrib.vieillessePlafonnee"].value.employee, P["contrib.vieillesseDeplafonnee"].value.employee, P["contrib.agircT1"].value.employee, P["contrib.cegT1"].value.employee), maxRate) : null,
      amount_employee: -reductionSalariale,
      rate_employer: null,
      amount_employer: 0,
      rounding:
        gross <= plafond
          ? `Rémunération des heures x taux effectif des cotisations salariales vieillesse et retraite complémentaire, plafonné à ${maxRate} %, ${ROUND}.`
          : `Rémunération des heures x (cotisations salariales vieillesse et retraite / brut), plafonné à ${maxRate} %, ${ROUND}.`,
      rule: "hs.reductionSalariale",
      organism: "urssaf",
      deductible: true,
    });
  }
  if (hsHours > BigInt(0) && deductionPerHour) {
    const amount = mulDiv(deductionPerHour, fromScaled(hsHours, 6), "1");
    lines.push({
      code: "DEDUCTION_FORFAITAIRE_HS",
      label: "Déduction forfaitaire patronale heures supplémentaires",
      section: "exonerations",
      kind: "reduction",
      base: null,
      quantity: fromScaled(hsHours, 2),
      rate_employee: null,
      amount_employee: 0,
      rate_employer: null,
      amount_employer: -amount,
      rounding: `${fmtEur(deductionPerHour)} par heure supplémentaire (${company.headcount !== null ? `effectif ${company.headcount}` : "tranche d'effectif"}) x ${fromScaled(hsHours, 2)} h, ${ROUND}.`,
      rule: "hs.deductionForfaitaire",
      organism: "urssaf",
      deductible: true,
    });
  }

  // Heures supplémentaires exonérées d'impôt (montant net), dans la limite annuelle
  let hsExemptNet = 0;
  let hsExemptGross = 0;
  if (hsGross > 0) {
    const rateBasedEmployee = sumEmployee((l) => l.kind === "contribution" && l.base !== null && l.section !== "csg");
    const contribOnHs = Number(divRound(BigInt(hsGross) * BigInt(rateBasedEmployee), BigInt(gross)));
    const uncapped = Math.max(0, hsGross - (contribOnHs - reductionSalariale));
    const limit = P["hs.exonerationFiscale"].value.annualLimitCents;
    const already = before.hsExemptNetCents ?? 0;
    if (before.hsExemptNetCents === null) {
      warn("HS_CUMUL_INCONNU", "Cumul d'heures supplémentaires exonérées inconnu", "Les cumuls repris ne précisent pas le montant d'heures supplémentaires déjà exonéré d'impôt cette année : la limite annuelle de 7 500 € est contrôlée sur les seuls bulletins Next RH.");
    }
    hsExemptNet = Math.max(0, Math.min(uncapped, limit - already));
    hsExemptGross = uncapped > 0 ? Number(divRound(BigInt(hsGross) * BigInt(hsExemptNet), BigInt(uncapped))) : 0;
    if (hsExemptNet < uncapped) {
      warn("HS_PLAFOND_ATTEINT", "Limite annuelle d'exonération des heures supplémentaires atteinte", `La part des heures supplémentaires au-delà de 7 500 € nets sur l'année (${fmtEur(uncapped - hsExemptNet)} ce mois) est imposable.`);
    }
  }

  // ---------- 5. CSG / CRDS ----------
  const csg = P.csg.value;
  const csgLimit = csg.abattementLimitPmss * plafond;
  const csgSalaryBase = applyRate(Math.min(gross, csgLimit), addRates("100", `-${csg.abattement}`)) + Math.max(0, gross - csgLimit);
  const csgExtra = employerPrev + employerMutuelle;
  const hsCsgBase = hsExemptGross > 0 ? Number(divRound(BigInt(csgSalaryBase) * BigInt(hsExemptGross), BigInt(gross))) : 0;
  const csgBase = csgSalaryBase + csgExtra - hsCsgBase;
  const csgRounding = `Assiette : 98,25 % du brut dans la limite de 4 plafonds, 100 % au-delà, plus parts patronales de prévoyance et santé (${fmtEur(csgExtra)})${hsCsgBase ? `, hors heures supplémentaires exonérées (${fmtEur(hsCsgBase)})` : ""} ; ${ROUND}.`;
  lines.push({
    code: "CSG_DEDUCTIBLE",
    label: "CSG déductible de l'impôt sur le revenu",
    section: "csg",
    kind: "contribution",
    base: csgBase,
    rate_employee: csg.deductible,
    amount_employee: applyRate(csgBase, csg.deductible),
    rate_employer: null,
    amount_employer: 0,
    rounding: csgRounding,
    rule: "csg",
    organism: "urssaf",
    deductible: true,
  });
  lines.push({
    code: "CSG_CRDS_NON_DEDUCTIBLE",
    label: "CSG et CRDS non déductibles de l'impôt sur le revenu",
    section: "csg",
    kind: "contribution",
    base: csgBase,
    rate_employee: addRates(csg.nonDeductible, csg.crds),
    amount_employee: applyRate(csgBase, csg.nonDeductible) + applyRate(csgBase, csg.crds),
    rate_employer: null,
    amount_employer: 0,
    rounding: `${csgRounding} CSG ${csg.nonDeductible} % et CRDS ${csg.crds} % arrondies séparément.`,
    rule: "csg",
    organism: "urssaf",
    deductible: false,
  });
  if (hsCsgBase > 0) {
    const r = addRates(csg.deductible, csg.nonDeductible, csg.crds);
    lines.push({
      code: "CSG_CRDS_HS",
      label: "CSG et CRDS sur heures supplémentaires exonérées",
      section: "csg",
      kind: "contribution",
      base: hsCsgBase,
      rate_employee: r,
      amount_employee: applyRate(hsCsgBase, csg.deductible) + applyRate(hsCsgBase, csg.nonDeductible) + applyRate(hsCsgBase, csg.crds),
      rate_employer: null,
      amount_employer: 0,
      rounding: `Assiette : 98,25 % de la rémunération des heures supplémentaires exonérées ; CSG ${csg.deductible} % + ${csg.nonDeductible} % et CRDS ${csg.crds} %, entièrement non déductibles, arrondies séparément.`,
      rule: "csg",
      organism: "urssaf",
      deductible: false,
    });
  }

  // ---------- 6. Réduction générale dégressive unique (régularisation progressive) ----------
  const rg = P.rgdu.value;
  const smicRgdu = toScaled(P["rgdu.smicHourly"].value); // x10^6 euros/heure
  const hoursRefScaled = isForfait ? divRound(toScaled(rg.annualHours), BigInt(12)) : divRound(toScaled(weeklyHours) * BigInt(52), BigInt(12));
  const smicFull = monthlyRef > 0 ? divRound(smicRgdu * hoursRefScaled * BigInt(100) * BigInt(paidBase), BigInt(10) ** BigInt(12) * BigInt(monthlyRef)) : BigInt(0);
  const smicHs = divRound(smicRgdu * (hsHours + hcHours) * BigInt(100), BigInt(10) ** BigInt(12));
  const smicMonth = Number(smicFull + smicHs);
  const progressive = !(before.source === "carryover" && before.rgdu === null);
  if (!progressive) {
    info("RGDU_MENSUELLE", "Réduction générale calculée sur le mois", "Les cumuls repris ne contiennent pas l'historique de la réduction générale : elle est calculée sur ce mois seul. Une régularisation annuelle sera à vérifier en fin d'année.");
  }
  const prev = progressive && before.rgdu ? before.rgdu : { baseCents: 0, smicCents: 0, reductionCents: 0 };
  const cumBase = prev.baseCents + gross;
  const cumSmic = prev.smicCents + smicMonth;
  const coef = rgduCoefficient(rs, cumSmic, cumBase, gte50);
  const coefStr = coef.toFixed(rg.coefficientDecimals);
  const reductionYtd = mulDiv(cumBase, coefStr, "1");
  const rgduMonth = reductionYtd - prev.reductionCents;
  const ircPart = coef > 0 ? Number(divRound(BigInt(rgduMonth) * toScaled(minDecimal(coefStr, rg.ircCap)), toScaled(coefStr))) : 0;
  if (rgduMonth !== 0) {
    lines.push({
      code: "RGDU",
      label: rgduMonth > 0 ? "Réduction générale dégressive unique des cotisations patronales" : "Régularisation de la réduction générale",
      section: "exonerations",
      kind: "reduction",
      base: gross,
      rate_employee: null,
      amount_employee: 0,
      rate_employer: coefStr,
      amount_employer: -rgduMonth,
      rounding: `Coefficient = ${rg.tmin} + ${gte50 ? rg.tdeltaGte50 : rg.tdeltaLt50} x [1/2 x (3 x SMIC ${progressive ? "cumulé" : "du mois"} ${fmtEur(cumSmic)} / brut ${progressive ? "cumulé" : "du mois"} ${fmtEur(cumBase)} - 1)]^${rg.p}, arrondi à 4 décimales ; réduction ${progressive ? "cumulée" : ""} = brut x coefficient, ${ROUND}${progressive ? ` ; réduction du mois = ${fmtEur(reductionYtd)} - ${fmtEur(prev.reductionCents)} déjà appliqués` : ""}. SMIC du mois : ${P["rgdu.smicHourly"].value} € x ${fromScaled(hoursRefScaled, 4)} h${paidBase !== monthlyRef ? " proratisé selon le salaire versé" : ""}${hsHours + hcHours > BigInt(0) ? ` + ${fromScaled(hsHours + hcHours, 2)} h supplémentaires ou complémentaires` : ""}.`,
      rule: "rgdu",
      organism: "urssaf",
      deductible: true,
    });
  }

  // ---------- 7. Totaux, net, impôt ----------
  const contribLines = lines.filter((l) => l.kind === "contribution" || l.kind === "reduction");
  const employeeContrib = contribLines.reduce((s, l) => s + l.amount_employee, 0);
  const employerContrib = contribLines.reduce((s, l) => s + l.amount_employer, 0);
  const employerRelief = -contribLines.filter((l) => l.kind === "reduction").reduce((s, l) => s + l.amount_employer, 0);
  const nonDeductible = contribLines.filter((l) => l.deductible === false).reduce((s, l) => s + l.amount_employee, 0);
  const deductibleEmployee = employeeContrib - nonDeductible;

  // Ajustements de net
  for (const v of variables) {
    if (v.kind === "avantage_nature") {
      lines.push({ code: "AVANTAGE_NATURE_DEDUCTION", label: `Avantage en nature déduit : ${v.label}`, section: "net", kind: "net_adjustment", base: null, rate_employee: null, amount_employee: -v.amountCents!, rate_employer: null, amount_employer: 0, rounding: "Avantage fourni en nature : réintégré dans le brut, déduit du net à payer." });
    } else if (v.kind === "titres_restaurant") {
      const employerShare = applyRate(v.amountCents!, v.rate!);
      const n = toScaled(v.quantity!);
      const employerTotal = Number(divRound(BigInt(employerShare) * n, BigInt(10) ** BigInt(6)));
      const total = Number(divRound(BigInt(v.amountCents!) * n, BigInt(10) ** BigInt(6)));
      lines.push({
        code: "TITRES_RESTAURANT",
        label: `Titres-restaurant : ${fromScaled(n, 2)} titres de ${fmtEur(v.amountCents!)}`,
        section: "net",
        kind: "net_adjustment",
        base: total,
        quantity: fromScaled(n, 2),
        rate_employee: null,
        amount_employee: -(total - employerTotal),
        rate_employer: v.rate,
        amount_employer: employerTotal,
        rounding: `Part patronale par titre = valeur x ${v.rate} % (${fmtEur(employerShare)}, exonérée) ; part salariale = total - part patronale, déduite du net.`,
        organism: "autre",
      });
    } else if (v.kind === "indemnite") {
      lines.push({ code: "INDEMNITE_FRAIS", label: v.label, section: "net", kind: "net_adjustment", base: null, rate_employee: null, amount_employee: v.amountCents!, rate_employer: null, amount_employer: 0, rounding: "Remboursement de frais professionnels : non soumis à cotisations ni à l'impôt." });
    } else if (v.kind === "acompte") {
      lines.push({ code: "ACOMPTE", label: v.label || "Acompte déjà versé", section: "net", kind: "net_adjustment", base: null, rate_employee: null, amount_employee: -v.amountCents!, rate_employer: null, amount_employer: 0, rounding: "Acompte versé dans le mois, déduit du net." });
    }
  }
  const netAdjust = lines.filter((l) => l.kind === "net_adjustment").reduce((s, l) => s + l.amount_employee, 0);
  const netBeforeTax = gross - employeeContrib + netAdjust;
  const netSocial = gross - employeeContrib;
  const netTaxable = gross - deductibleEmployee - hsExemptNet + employerMutuelle;

  const pasBase = Math.max(0, netTaxable);
  let pasRate: string;
  let pasKind: "personnalise" | "neutre";
  if (input.pas && !input.pas.isNeutral) {
    pasRate = input.pas.rate;
    pasKind = "personnalise";
  } else {
    pasRate = neutralRate(pasRs, pasBase);
    pasKind = "neutre";
    info("PAS_BAREME_NEUTRE", "Impôt : barème neutre appliqué", `Aucun taux personnalisé n'est disponible pour ${employee.fullName} : la grille de taux par défaut (${pasRs.version}) est appliquée à la base de ${fmtEur(pasBase)}, soit ${pasRate} %.`);
  }
  const pasAmount = applyRate(pasBase, pasRate);
  lines.push({
    code: "PAS",
    label: `Impôt sur le revenu prélevé à la source (taux ${pasKind === "neutre" ? "non personnalisé" : "personnalisé"})`,
    section: "impot",
    kind: "net_adjustment",
    base: pasBase,
    rate_employee: pasRate,
    amount_employee: pasAmount,
    rate_employer: null,
    amount_employer: 0,
    rounding: `Base = net imposable ; montant = base x taux, ${ROUND}.`,
    rule: pasKind === "neutre" ? "pas.neutralGrid" : "pas.personnalise",
    organism: "impots",
  });
  const netPaid = netBeforeTax - pasAmount;
  if (netPaid < 0) {
    block("NET_NEGATIF", "Net à payer négatif", `Le net à payer de ${employee.fullName} serait de ${fmtEur(netPaid)}. Vérifiez les acomptes, absences et régularisations.`);
  }

  // SMIC mensuel de comparaison : taux horaire x horaire hebdomadaire x 52 / 12 (1 823,03 € pour 35 h au 1er janvier 2026).
  const smicLegal = toScaled(P["smic.hourly"].value);
  const smicMonthlyLegal = Number(divRound(smicLegal * hoursRefScaled * BigInt(100), BigInt(10) ** BigInt(12)));
  if (monthlyRef < smicMonthlyLegal) {
    warn("SOUS_SMIC", "Salaire de base inférieur au SMIC", `Le salaire de base (${fmtEur(monthlyRef)} pour ${isForfait ? "un temps plein" : `${contract.weeklyHours} h par semaine`}) est inférieur au SMIC proratisé (${fmtEur(smicMonthlyLegal)} au taux de ${P["smic.hourly"].value} €). Vérifiez si des primes entrent dans la comparaison ou corrigez la rémunération.`);
  }

  const employerCost = gross + employerContrib;
  const hoursWorked = isForfait
    ? "0"
    : fromScaled(divRound(toScaled(monthlyHours) * BigInt(wdPresent), BigInt(wdMonth)) - divRound(unpaidDays * toScaled(weeklyHours), BigInt(5) * BigInt(10) ** BigInt(6)) + hsHours + hcHours, 2);

  const totals: PayslipTotals = {
    grossCents: gross,
    employeeContribCents: employeeContrib,
    employerContribCents: employerContrib,
    employerReliefCents: employerRelief,
    netSocialCents: netSocial,
    netTaxableCents: netTaxable,
    netBeforeTaxCents: netBeforeTax,
    pasRate,
    pasBaseCents: pasBase,
    pasAmountCents: pasAmount,
    pasKind,
    netPaidCents: netPaid,
    employerCostCents: employerCost,
    hoursWorked,
    hsExemptNetCents: hsExemptNet,
  };

  const cumulative: EngineCumuls = {
    year: period.year,
    throughMonth: period.month,
    source: "payslips",
    grossCents: before.grossCents + gross,
    netTaxableCents: before.netTaxableCents + netTaxable,
    netPaidCents: before.netPaidCents + netPaid,
    pasCents: before.pasCents + pasAmount,
    employeeContribCents: before.employeeContribCents + employeeContrib,
    employerContribCents: before.employerContribCents + employerContrib,
    hours: fromScaled(toScaled(before.hours) + toScaled(hoursWorked), 2),
    hsExemptNetCents: (before.hsExemptNetCents ?? 0) + hsExemptNet,
    rgdu: { baseCents: cumBase, smicCents: cumSmic, reductionCents: reductionYtd },
  };

  const blocking = anomalies.find((a) => a.severity === "blocking");
  return {
    status: blocking ? "blocked" : "computed",
    ruleSetVersion: rs.version,
    pasRuleSetVersion: pasRs.version,
    lines,
    totals,
    cumulative,
    anomalies,
    blockingReason: blocking ? blocking.title : null,
    computeHash,
    details: {
      plafondCents: plafond,
      workingDaysMonth: wdMonth,
      workingDaysPresent: wdPresent,
      calendarDaysPresent: cdPresent,
      monthlyReferenceCents: monthlyRef,
      rgdu: { coefficient: coefStr, smicMonthCents: smicMonth, reductionCents: rgduMonth, ircPartCents: ircPart, method: progressive ? "progressive" : "mensuelle" },
      hsHours: fromScaled(hsHours, 2),
      hcHours: fromScaled(hcHours, 2),
      hsGrossCents: hsGross,
      unpaidAbsenceDays: fromScaled(unpaidDays, 2),
      paidLeaveDays: fromScaled(paidLeaveDays, 2),
    },
  };
}

/** Cumuls vides pour un premier bulletin de l'année. */
export function emptyCumuls(year: number): EngineCumuls {
  return {
    year,
    throughMonth: 0,
    source: "none",
    grossCents: 0,
    netTaxableCents: 0,
    netPaidCents: 0,
    pasCents: 0,
    employeeContribCents: 0,
    employerContribCents: 0,
    hours: "0",
    hsExemptNetCents: 0,
    rgdu: { baseCents: 0, smicCents: 0, reductionCents: 0 },
  };
}
