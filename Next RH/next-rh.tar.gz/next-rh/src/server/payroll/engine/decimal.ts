/**
 * Arithmétique exacte pour la paie : centimes entiers et taux décimaux convertis en entiers (BigInt).
 * Aucune opération en virgule flottante sur les montants, sauf la puissance de la formule RGDU (voir rgdu.ts),
 * dont le résultat est arrondi à 4 décimales comme le prévoit le texte.
 *
 * Règle d'arrondi unique : au centime le plus proche, demi-centime arrondi en s'éloignant de zéro
 * (« arrondi commercial »). Chaque ligne du bulletin est arrondie séparément.
 */

const SCALE_DIGITS = 6;
const SCALE = BigInt(10) ** BigInt(SCALE_DIGITS);

/** Convertit une chaîne décimale ("6.90", "0.036", "-2,5") en entier mis à l'échelle 10^6. */
export function toScaled(value: string | number): bigint {
  const s = String(value).trim().replace(",", ".");
  if (!/^-?\d+(\.\d+)?$/.test(s)) throw new Error(`Valeur décimale invalide : ${value}`);
  const neg = s.startsWith("-");
  const [int, frac = ""] = (neg ? s.slice(1) : s).split(".");
  if (frac.length > SCALE_DIGITS) throw new Error(`Trop de décimales (max ${SCALE_DIGITS}) : ${value}`);
  const v = BigInt(int) * SCALE + BigInt(frac.padEnd(SCALE_DIGITS, "0"));
  return neg ? -v : v;
}

/** Division entière arrondie au plus proche, demi s'éloignant de zéro. */
export function divRound(num: bigint, den: bigint): bigint {
  if (den === BigInt(0)) throw new Error("Division par zéro");
  const neg = num < BigInt(0) !== den < BigInt(0);
  const n = num < BigInt(0) ? -num : num;
  const d = den < BigInt(0) ? -den : den;
  const q = (BigInt(2) * n + d) / (BigInt(2) * d);
  return neg ? -q : q;
}

/** montant = base x taux % arrondi au centime. `rate` est un pourcentage ("6.90" = 6,90 %). */
export function applyRate(baseCents: number, rate: string): number {
  return Number(divRound(BigInt(baseCents) * toScaled(rate), BigInt(100) * SCALE));
}

/** a x b / c arrondi au centime, pour les proratisations (toutes valeurs décimales acceptées en chaîne). */
export function mulDiv(aCents: number, b: string | number, c: string | number): number {
  return Number(divRound(BigInt(aCents) * toScaled(b), toScaled(c)));
}

/** Addition de taux exprimés en chaînes décimales, résultat en chaîne normalisée. */
export function addRates(...rates: string[]): string {
  return fromScaled(rates.reduce((s, r) => s + toScaled(r), BigInt(0)));
}

export function fromScaled(v: bigint, digits = 4): string {
  const neg = v < BigInt(0);
  const a = neg ? -v : v;
  const int = a / SCALE;
  const frac = (a % SCALE).toString().padStart(SCALE_DIGITS, "0").slice(0, digits).replace(/0+$/, "");
  return `${neg ? "-" : ""}${int}${frac ? `.${frac}` : ""}`;
}

export function compareDecimal(a: string, b: string): number {
  const x = toScaled(a);
  const y = toScaled(b);
  return x === y ? 0 : x < y ? -1 : 1;
}

export function minDecimal(a: string, b: string): string {
  return compareDecimal(a, b) <= 0 ? a : b;
}

/** Arrondi d'un nombre flottant à n décimales (utilisé uniquement pour le coefficient RGDU). */
export function roundTo(x: number, decimals: number): number {
  const f = 10 ** decimals;
  // Correction des représentations binaires (ex. 0.12345 stocké 0.1234499999).
  return Math.sign(x) * Math.round(Math.abs(x) * f + 1e-9) / f;
}
