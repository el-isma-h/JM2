/** Types d'entrée et de sortie du moteur de paie (module pur, importable côté client pour l'affichage). */

export type HeadcountBracket = "lt11" | "11to49" | "50to249" | "gte250";

export type EngineCompany = {
  /** Tranche d'effectif confirmée dans l'onboarding. */
  headcountBracket: HeadcountBracket | null;
  /** Effectif exact s'il est connu (sert au seuil de 20 salariés des heures supplémentaires). */
  headcount: number | null;
  /** Taux AT/MP en %. */
  atRate: string | null;
  /** Versement mobilité en % ("0" si non assujetti). */
  mobilityRate: string | null;
  mutuelle: { name: string; employerCents: number; employeeCents: number } | null;
  prevoyance: {
    name: string;
    cadreEmployerRate: string;
    cadreEmployeeRate: string;
    nonCadreEmployerRate: string;
    nonCadreEmployeeRate: string;
  } | null;
  /** Indique si mutuelle / prévoyance ont été renseignées dans l'onboarding (null explicite = pas de contrat). */
  mutuelleConfigured: boolean;
  prevoyanceConfigured: boolean;
  /** Code postal de l'établissement d'affectation (détection Alsace-Moselle et DOM). */
  establishmentPostalCode: string | null;
};

export type EngineContract = {
  id: string;
  type: "CDI" | "CDD" | "APPRENTISSAGE" | "PROFESSIONNALISATION" | "STAGE" | "INTERIM" | "MANDAT";
  category: "non_cadre" | "cadre" | "cadre_dirigeant" | "apprenti" | "stagiaire";
  startDate: string;
  endDate: string | null;
  workTimeMode: "heures" | "forfait_jours" | "forfait_heures";
  weeklyHours: string;
  monthlyHours: string;
  annualDays: number | null;
  isPartTime: boolean;
};

export type EngineCompensation = {
  basis: "monthly" | "hourly" | "annual";
  grossAmountCents: number;
  effectiveDate: string;
  endDate: string | null;
};

export type VariableKind =
  | "prime"
  | "commission"
  | "heures_sup"
  | "heures_comp"
  | "absence"
  | "avantage_nature"
  | "titres_restaurant"
  | "indemnite"
  | "acompte"
  | "saisie"
  | "regularisation"
  | "autre";

export type EngineVariable = {
  id: string;
  kind: VariableKind;
  label: string;
  quantity: string | null;
  rate: string | null;
  amountCents: number | null;
  note: string | null;
  source: string;
};

export type EngineCumuls = {
  year: number;
  /** Dernier mois inclus dans les cumuls (0 = aucun). */
  throughMonth: number;
  source: "none" | "payslips" | "carryover";
  grossCents: number;
  netTaxableCents: number;
  netPaidCents: number;
  pasCents: number;
  employeeContribCents: number;
  employerContribCents: number;
  hours: string;
  /** Heures supplémentaires exonérées d'impôt (montant net) cumulées ; null si inconnu (reprise). */
  hsExemptNetCents: number | null;
  /** Cumuls de la réduction générale (régularisation progressive) ; null si inconnus (reprise). */
  rgdu: { baseCents: number; smicCents: number; reductionCents: number } | null;
};

export type PayslipInput = {
  engineVersion: string;
  period: { year: number; month: number; start: string; end: string; paymentDate: string };
  company: EngineCompany;
  employee: { id: string; fullName: string; hireDate: string | null; leaveDate: string | null };
  contract: EngineContract | null;
  /** Rémunérations en vigueur sur la période (toutes celles qui chevauchent le mois). */
  compensations: EngineCompensation[];
  variables: EngineVariable[];
  pas: { rate: string; isNeutral: boolean; effectiveDate: string } | null;
  cumulsBefore: EngineCumuls;
};

export type LineSection =
  | "brut"
  | "sante"
  | "atmp"
  | "retraite"
  | "famille"
  | "chomage"
  | "autres_contributions"
  | "csg"
  | "exonerations"
  | "net"
  | "impot"
  | "info";

/**
 * Ligne de bulletin. Conventions de signe : `amount_employee` > 0 = retenue sur le salarié ; `amount_employer` > 0 = charge
 * patronale ; un allègement est négatif. Pour les lignes de rémunération (section brut), `amount_employee` est le gain
 * (positif) ou la retenue (négatif) ajouté au brut.
 */
export type PayslipLine = {
  code: string;
  label: string;
  section: LineSection;
  kind: "gain" | "contribution" | "reduction" | "net_adjustment" | "info";
  base: number | null;
  /** Quantité affichée (heures, jours) le cas échéant. */
  quantity?: string | null;
  rate_employee: string | null;
  amount_employee: number;
  rate_employer: string | null;
  amount_employer: number;
  /** Règle d'arrondi et formule appliquées, en clair. */
  rounding: string;
  /** Code de la règle utilisée dans le jeu de paramètres (traçabilité). */
  rule?: string;
  /** Organisme destinataire (pour l'état des charges et l'export comptable). */
  organism?: "urssaf" | "retraite" | "prevoyance" | "mutuelle" | "france_travail" | "impots" | "autre";
  deductible?: boolean;
};

export type EngineAnomaly = {
  code: string;
  severity: "blocking" | "warning" | "info";
  title: string;
  explanation: string;
  details?: Record<string, unknown>;
};

export type PayslipTotals = {
  grossCents: number;
  employeeContribCents: number;
  employerContribCents: number;
  /** Total des allègements patronaux (positif = montant de l'allègement). */
  employerReliefCents: number;
  netSocialCents: number;
  netTaxableCents: number;
  netBeforeTaxCents: number;
  pasRate: string;
  pasBaseCents: number;
  pasAmountCents: number;
  pasKind: "personnalise" | "neutre";
  netPaidCents: number;
  employerCostCents: number;
  hoursWorked: string;
  hsExemptNetCents: number;
};

export type PayslipResult = {
  status: "computed" | "blocked";
  ruleSetVersion: string;
  pasRuleSetVersion: string | null;
  lines: PayslipLine[];
  totals: PayslipTotals;
  cumulative: EngineCumuls;
  anomalies: EngineAnomaly[];
  blockingReason: string | null;
  computeHash: string;
  /** Données de calcul intermédiaires exposées pour l'affichage et la DSN. */
  details: {
    plafondCents: number;
    workingDaysMonth: number;
    workingDaysPresent: number;
    calendarDaysPresent: number;
    monthlyReferenceCents: number;
    rgdu: { coefficient: string; smicMonthCents: number; reductionCents: number; ircPartCents: number; method: "progressive" | "mensuelle" } | null;
    hsHours: string;
    hcHours: string;
    hsGrossCents: number;
    unpaidAbsenceDays: string;
    paidLeaveDays: string;
  };
};
