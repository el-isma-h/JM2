import { emptyCumuls } from "../compute";
import type { EngineCompany, EngineContract, EngineVariable, PayslipInput } from "../types";

export const companyLt11: EngineCompany = {
  headcountBracket: "lt11",
  headcount: 8,
  atRate: "1.30",
  mobilityRate: "0",
  mutuelle: null,
  prevoyance: null,
  mutuelleConfigured: true,
  prevoyanceConfigured: true,
  establishmentPostalCode: "69006",
};

export const company11to49: EngineCompany = { ...companyLt11, headcountBracket: "11to49", headcount: 12 };

export function contract(over: Partial<EngineContract> = {}): EngineContract {
  return {
    id: "c-1",
    type: "CDI",
    category: "non_cadre",
    startDate: "2021-09-13",
    endDate: null,
    workTimeMode: "heures",
    weeklyHours: "35.00",
    monthlyHours: "151.67",
    annualDays: null,
    isPartTime: false,
    ...over,
  };
}

let seq = 0;
export function variable(over: Partial<EngineVariable> & Pick<EngineVariable, "kind">): EngineVariable {
  seq += 1;
  return { id: `v-${seq}`, label: over.kind, quantity: null, rate: null, amountCents: null, note: null, source: "manual", ...over };
}

/** Mars 2026 : 22 jours ouvrés (aucun jour férié), paiement le 31. */
export function input(over: Partial<PayslipInput> & { salary?: number } = {}): PayslipInput {
  const { salary = 182303, ...rest } = over;
  return {
    engineVersion: "1.0.0",
    period: { year: 2026, month: 3, start: "2026-03-01", end: "2026-03-31", paymentDate: "2026-03-31" },
    company: companyLt11,
    employee: { id: "e-1", fullName: "Mathis Perrin", hireDate: "2021-09-13", leaveDate: null },
    contract: contract(),
    compensations: [{ basis: "monthly", grossAmountCents: salary, effectiveDate: "2026-01-01", endDate: null }],
    variables: [],
    pas: { rate: "1.50", isNeutral: false, effectiveDate: "2026-01-01" },
    cumulsBefore: emptyCumuls(2026),
    ...rest,
  };
}
