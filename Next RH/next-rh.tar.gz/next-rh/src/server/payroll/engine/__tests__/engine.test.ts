/**
 * Cas de référence du moteur de paie. Chaque montant attendu est calculé à la main dans les commentaires
 * (arrondi au centime le plus proche), à partir des taux du jeu de règles fr-2026.xx et de leurs sources :
 *  - SMIC 12,02 €/h (décret 2025-1228) ; 12,31 €/h au 1er juin 2026 (arrêté du 22 mai 2026)
 *  - PMSS 4 005 € (arrêté du 22 décembre 2025)
 *  - URSSAF secteur privé 2026 : maladie 13 %, vieillesse 8,55/6,90 (T1) et 2,11/0,40, AF 5,25 %, CSA 0,30 %,
 *    FNAL 0,10 % T1 (< 50), chômage 4,00 %, AGS 0,25 %, dialogue social 0,016 %, formation 0,55 % / 1 %, TA 0,59 %
 *  - Agirc-Arrco 2026 (circulaire 2025-16) : T1 4,72/3,15, T2 12,95/8,64, CEG 1,29/0,86 et 1,62/1,08, CET 0,21/0,14,
 *    APEC 0,036/0,024
 *  - CSG 6,80 % déductible, 2,40 % + CRDS 0,50 % non déductibles, assiette 98,25 % (economie.gouv.fr, URSSAF)
 *  - RGDU 2026 : Tmin 0,02, Tdelta 0,3781 (< 50) / 0,3821, P 1,75, 4 décimales (economie.gouv.fr, décret 2025-1446)
 * Aucune valeur attendue n'a été recopiée depuis une sortie du moteur.
 */
import { describe, expect, it } from "vitest";
import { computePayslip, emptyCumuls, neutralRate, rgduCoefficient } from "../compute";
import { getRuleSet, loadRuleSet } from "../../rules";
import type { PayslipResult } from "../types";
import { company11to49, companyLt11, contract, input, variable } from "./fixtures";

const line = (r: PayslipResult, code: string) => {
  const l = r.lines.find((x) => x.code === code);
  if (!l) throw new Error(`Ligne ${code} absente : ${r.lines.map((x) => x.code).join(", ")}`);
  return l;
};
const codes = (r: PayslipResult) => r.anomalies.map((a) => a.code);

describe("1. Non-cadre au SMIC (entreprise de moins de 11 salariés, mars 2026)", () => {
  // Brut = SMIC mensuel 35 h = 12,02 x 35 x 52 / 12 = 1 823,0333 -> 1 823,03 €
  const r = computePayslip(input({ salary: 182303 }));

  it("calcule les cotisations salariales", () => {
    expect(r.status).toBe("computed");
    expect(r.totals.grossCents).toBe(182303);
    // Vieillesse plafonnée 6,90 % x 1 823,03 = 125,78907 -> 125,79
    expect(line(r, "SS_VIEILLESSE_PLAF").amount_employee).toBe(12579);
    // Vieillesse déplafonnée 0,40 % = 7,29212 -> 7,29
    expect(line(r, "SS_VIEILLESSE_DEPLAF").amount_employee).toBe(729);
    // Retraite complémentaire T1 3,15 % = 57,425445 -> 57,43 ; CEG T1 0,86 % = 15,678058 -> 15,68
    expect(line(r, "RC_T1").amount_employee).toBe(5743);
    expect(line(r, "CEG_T1").amount_employee).toBe(1568);
    // Assiette CSG = 98,25 % x 1 823,03 = 1 791,126975 -> 1 791,13
    expect(line(r, "CSG_DEDUCTIBLE").base).toBe(179113);
    // CSG déductible 6,80 % x 1 791,13 = 121,79684 -> 121,80
    expect(line(r, "CSG_DEDUCTIBLE").amount_employee).toBe(12180);
    // CSG 2,40 % = 42,98712 -> 42,99 ; CRDS 0,50 % = 8,95565 -> 8,96 ; total 51,95
    expect(line(r, "CSG_CRDS_NON_DEDUCTIBLE").amount_employee).toBe(5195);
    // Total salarié = 125,79 + 7,29 + 57,43 + 15,68 + 121,80 + 51,95 = 379,94
    expect(r.totals.employeeContribCents).toBe(37994);
  });

  it("calcule le net, le net imposable et l'impôt", () => {
    // Net avant impôt = 1 823,03 - 379,94 = 1 443,09
    expect(r.totals.netBeforeTaxCents).toBe(144309);
    // Net imposable = brut - cotisations déductibles = 1 823,03 - (379,94 - 51,95) = 1 495,04
    expect(r.totals.netTaxableCents).toBe(149504);
    // PAS 1,50 % x 1 495,04 = 22,4256 -> 22,43 ; net payé = 1 443,09 - 22,43 = 1 420,66
    expect(r.totals.pasAmountCents).toBe(2243);
    expect(r.totals.netPaidCents).toBe(142066);
    // Montant net social = brut - cotisations salariales (circulaire CNAF 2023-221)
    expect(r.totals.netSocialCents).toBe(144309);
  });

  it("applique la réduction générale au coefficient maximal", () => {
    // SMIC RGDU du mois = 12,02 x 151,666667 h = 1 823,03 ; rapport 3 x SMIC / brut = 3 : C = 0,02 + 0,3781 x 1^1,75 = 0,3981
    expect(line(r, "RGDU").rate_employer).toBe("0.3981");
    // Réduction = 1 823,03 x 0,3981 = 725,748243 -> 725,75
    expect(line(r, "RGDU").amount_employer).toBe(-72575);
    // Cotisations patronales avant réduction : maladie 236,99 + AT 23,70 + vieillesse 155,87 + 38,47 + RC 86,05 + CEG 23,52
    // + AF 95,71 + chômage 72,92 + AGS 4,56 + CSA 5,47 + FNAL 1,82 + dialogue 0,29 + formation 10,03 + TA 10,76 = 766,16
    // Après réduction : 766,16 - 725,75 = 40,41 ; coût employeur = 1 823,03 + 40,41 = 1 863,44
    expect(r.totals.employerContribCents).toBe(4041);
    expect(r.totals.employerCostCents).toBe(186344);
    // Moins de 11 salariés : formation 0,55 % = 10,0267 -> 10,03 ; FNAL 0,10 % sur T1
    expect(line(r, "FORMATION").amount_employer).toBe(1003);
    expect(line(r, "FNAL").amount_employer).toBe(182);
  });
});

describe("2. Non-cadre à 2 800 € (11 à 49 salariés)", () => {
  const r = computePayslip(input({ salary: 280000, company: company11to49, pas: { rate: "4.20", isNeutral: false, effectiveDate: "2026-01-01" } }));
  it("calcule brut, net et coût", () => {
    // Salarié : 6,90 % 193,20 + 0,40 % 11,20 + 3,15 % 88,20 + 0,86 % 24,08 + CSG (98,25 % = 2 751,00) 6,80 % 187,068 -> 187,07
    //          + 2,40 % 66,024 -> 66,02 + 0,50 % 13,755 -> 13,76 => 583,53
    expect(r.totals.employeeContribCents).toBe(58353);
    expect(r.totals.netBeforeTaxCents).toBe(221647);
    // Net imposable = 2 800 - (583,53 - 79,78) = 2 296,25 ; PAS 4,20 % = 96,4425 -> 96,44
    expect(r.totals.netTaxableCents).toBe(229625);
    expect(r.totals.pasAmountCents).toBe(9644);
    expect(r.totals.netPaidCents).toBe(212003);
    // 11 salariés et plus : formation 1 % = 28,00
    expect(line(r, "FORMATION").amount_employer).toBe(2800);
  });
  it("calcule le coefficient dégressif", () => {
    // 3 x 1 823,03 / 2 800 = 1,953246 ; (0,5 x 0,953246)^1,75 = 0,47662^1,75 = 0,27300 ; C = 0,02 + 0,3781 x 0,27300 = 0,12322... -> 0,1234 (4 déc.)
    expect(line(r, "RGDU").rate_employer).toBe("0.1234");
    // Réduction = 2 800 x 0,1234 = 345,52
    expect(line(r, "RGDU").amount_employer).toBe(-34552);
    expect(r.totals.employerCostCents).toBe(364381);
  });
});

describe("3. Cadre à 4 500 € avec prévoyance et mutuelle (au-dessus du PMSS)", () => {
  const company = {
    ...company11to49,
    mutuelle: { name: "Mutuelle test", employerCents: 4185, employeeCents: 2790 },
    prevoyance: { name: "Prévoyance test", cadreEmployerRate: "1.50", cadreEmployeeRate: "0.37", nonCadreEmployerRate: "0.62", nonCadreEmployeeRate: "0.41" },
  };
  const r = computePayslip(input({ salary: 450000, company, contract: contract({ category: "cadre" }), pas: { rate: "7.40", isNeutral: false, effectiveDate: "2026-01-01" } }));
  it("découpe les tranches et applique CET et APEC", () => {
    // T1 = 4 005,00 ; T2 = 495,00
    expect(line(r, "SS_VIEILLESSE_PLAF").base).toBe(400500);
    expect(line(r, "RC_T2").base).toBe(49500);
    // RC T2 salarié 8,64 % x 495 = 42,768 -> 42,77 ; patronal 12,95 % = 64,1025 -> 64,10
    expect(line(r, "RC_T2").amount_employee).toBe(4277);
    expect(line(r, "RC_T2").amount_employer).toBe(6410);
    // CET (brut > plafond) sur T1 + T2 = 4 500 : 0,14 % = 6,30 ; 0,21 % = 9,45
    expect(line(r, "CET").amount_employee).toBe(630);
    expect(line(r, "CET").amount_employer).toBe(945);
    // APEC 0,024 % x 4 500 = 1,08 ; 0,036 % = 1,62
    expect(line(r, "APEC").amount_employee).toBe(108);
    expect(line(r, "APEC").amount_employer).toBe(162);
  });
  it("intègre prévoyance, mutuelle, forfait social et CSG sur parts patronales", () => {
    // Prévoyance 0,37 % x 4 500 = 16,65 ; 1,50 % = 67,50
    expect(line(r, "PREVOYANCE").amount_employee).toBe(1665);
    expect(line(r, "PREVOYANCE").amount_employer).toBe(6750);
    // Forfait social 8 % x (67,50 + 41,85) = 8,748 -> 8,75
    expect(line(r, "FORFAIT_SOCIAL").amount_employer).toBe(875);
    // Assiette CSG = 98,25 % x 4 500 (4 421,25) + 67,50 + 41,85 = 4 530,60
    expect(line(r, "CSG_DEDUCTIBLE").base).toBe(453060);
    // Net imposable = brut - déductibles + part patronale mutuelle = 4 500 - (994,46 - 131,38) + 41,85 = 3 678,77
    expect(r.totals.employeeContribCents).toBe(99446);
    expect(r.totals.netTaxableCents).toBe(367877);
    // PAS 7,40 % = 272,22898 -> 272,23 ; net payé = 3 505,54 - 272,23 = 3 233,31
    expect(r.totals.netPaidCents).toBe(323331);
    // RGDU : 3 x 1 823,03 / 4 500 = 1,21535 ; (0,107675)^1,75 = 0,020214 ; C = 0,02 + 0,3781 x 0,020214 = 0,02764 -> 0,0277
    expect(line(r, "RGDU").rate_employer).toBe("0.0277");
    expect(line(r, "RGDU").amount_employer).toBe(-12465);
    expect(r.totals.employerCostCents).toBe(641550);
  });
});

describe("4. Cadre à 18 000 € (au-delà de 4 PMSS, 50 à 249 salariés, versement mobilité 2 %)", () => {
  const r = computePayslip(
    input({ salary: 1800000, company: { ...company11to49, headcountBracket: "50to249", headcount: 64, mobilityRate: "2.00" }, contract: contract({ category: "cadre" }), pas: { rate: "20.10", isNeutral: false, effectiveDate: "2026-01-01" } }),
  );
  it("plafonne chômage, APEC et abattement CSG à 4 PMSS", () => {
    // 4 PMSS = 16 020 € : chômage 4 % x 16 020 = 640,80 ; AGS 0,25 % = 40,05
    expect(line(r, "CHOMAGE").amount_employer).toBe(64080);
    expect(line(r, "AGS").amount_employer).toBe(4005);
    // CSG : 98,25 % x 16 020 = 15 739,65 + (18 000 - 16 020) = 17 719,65
    expect(line(r, "CSG_DEDUCTIBLE").base).toBe(1771965);
    // T2 = 18 000 - 4 005 = 13 995 (< 7 PMSS) ; RC T2 salarié 8,64 % = 1 209,168 -> 1 209,17
    expect(line(r, "RC_T2").amount_employee).toBe(120917);
    // 50 salariés et plus : FNAL 0,50 % sur la totalité = 90,00 ; VM 2 % = 360,00
    expect(line(r, "FNAL").amount_employer).toBe(9000);
    expect(line(r, "VERSEMENT_MOBILITE").amount_employer).toBe(36000);
  });
  it("n'applique aucune réduction générale au-delà de 3 SMIC", () => {
    expect(r.lines.some((l) => l.code === "RGDU")).toBe(false);
    expect(r.totals.netBeforeTaxCents).toBe(1438288);
    expect(r.totals.netPaidCents).toBe(1138863);
    expect(r.totals.employerCostCents).toBe(2603850);
  });
});

describe("5. Temps partiel 24 h avec heures complémentaires", () => {
  const r = computePayslip(
    input({
      salary: 132600,
      contract: contract({ weeklyHours: "24.00", monthlyHours: "104.00", isPartTime: true }),
      variables: [variable({ kind: "heures_comp", label: "Heures complémentaires", quantity: "4" })],
      pas: { rate: "0", isNeutral: false, effectiveDate: "2026-01-01" },
    }),
  );
  it("valorise les heures complémentaires à 10 % par défaut et le signale", () => {
    // 1 326 / 104 h x 4 h x 110 % = 56,10
    expect(line(r, "HEURES_COMP_10").amount_employee).toBe(5610);
    expect(codes(r)).toContain("HC_MAJORATION_SUPPOSEE");
    expect(r.totals.grossCents).toBe(138210);
  });
  it("applique réduction salariale, CSG sur heures exonérées et SMIC proratisé", () => {
    // Réduction 11,31 % x 56,10 = 6,34491 -> 6,34
    expect(line(r, "REDUCTION_SALARIALE_HS").amount_employee).toBe(-634);
    // CSG/CRDS sur heures exonérées : assiette 98,25 % x 56,10 = 55,118 -> 55,12 ; 6,80 % 3,75 + 2,40 % 1,32 + 0,50 % 0,28 = 5,35
    expect(line(r, "CSG_CRDS_HS").base).toBe(5512);
    expect(line(r, "CSG_CRDS_HS").amount_employee).toBe(535);
    // Net imposable = 1 382,10 - (281,70 - 37,78 - 5,35) - 56,09 (heures exonérées nettes) = 1 087,44
    expect(r.totals.netTaxableCents).toBe(108744);
    // SMIC RGDU = 12,02 x 104 h + 12,02 x 4 h = 1 250,08 + 48,08 = 1 298,16 ; C = 0,3399 (4 déc.)
    expect(r.details.rgdu?.smicMonthCents).toBe(129816);
    expect(line(r, "RGDU").rate_employer).toBe("0.3399");
    // Réduction = 1 382,10 x 0,3399 = 469,77579 -> 469,78
    expect(line(r, "RGDU").amount_employer).toBe(-46978);
    expect(r.totals.netPaidCents).toBe(110040);
  });
});

describe("6. Entrée en cours de mois (16 mars)", () => {
  const r = computePayslip(input({ salary: 250000, employee: { id: "e-2", fullName: "Inès Roussel", hireDate: "2026-03-16", leaveDate: null }, contract: contract({ startDate: "2026-03-16" }), pas: { rate: "2.00", isNeutral: false, effectiveDate: "2026-03-16" } }));
  it("proratise au réel et réduit le plafond", () => {
    // Jours ouvrés de mars : 22 ; présence du 16 au 31 : 12 ; 2 500 x 12 / 22 = 1 363,636 -> 1 363,64 ; retenue 1 136,36
    expect(line(r, "ENTREE_SORTIE").amount_employee).toBe(-113636);
    expect(r.totals.grossCents).toBe(136364);
    // Plafond : 4 005 x 16 jours calendaires / 30 = 2 136,00
    expect(r.details.plafondCents).toBe(213600);
    // SMIC RGDU proratisé : 1 823,0333 x 1 363,64 / 2 500 = 994,38 ; C = 0,1719
    expect(r.details.rgdu?.smicMonthCents).toBe(99438);
    expect(line(r, "RGDU").amount_employer).toBe(-23441);
    expect(r.totals.netPaidCents).toBe(105709);
  });
});

describe("7. Sortie en cours de mois (13 mars)", () => {
  const r = computePayslip(input({ salary: 230000, employee: { id: "e-3", fullName: "Lucas Fontaine", hireDate: "2024-01-08", leaveDate: "2026-03-13" }, pas: { rate: "2.00", isNeutral: false, effectiveDate: "2026-01-01" } }));
  it("proratise et signale le solde de tout compte", () => {
    // Présence du 1er au 13 : 10 jours ouvrés ; 2 300 x 10 / 22 = 1 045,4545 -> 1 045,45
    expect(r.totals.grossCents).toBe(104545);
    // Plafond : 4 005 x 13 / 30 = 1 735,50
    expect(r.details.plafondCents).toBe(173550);
    expect(codes(r)).toContain("SOLDE_TOUT_COMPTE");
    // SMIC RGDU = 1 823,0333 x 1 045,45 / 2 300 = 828,65 ; C = 0,2170 ; réduction = 1 045,45 x 0,2170 = 226,86
    expect(line(r, "RGDU").amount_employer).toBe(-22686);
    expect(r.totals.netPaidCents).toBe(81042);
  });
});

describe("8. Heures supplémentaires (effectif 12, moins de 20 salariés)", () => {
  const r = computePayslip(
    input({
      salary: 220000,
      company: company11to49,
      variables: [variable({ kind: "heures_sup", label: "HS semaine 11", quantity: "8", rate: "25" }), variable({ kind: "heures_sup", label: "HS semaine 12", quantity: "2", rate: "50" })],
      pas: { rate: "1.00", isNeutral: false, effectiveDate: "2026-01-01" },
    }),
  );
  it("valorise les heures majorées", () => {
    // 2 200 / 151,67 x 8 x 125 % = 145,0517 -> 145,05 ; x 2 x 150 % = 43,5155 -> 43,52
    expect(line(r, "HEURES_SUP_25").amount_employee).toBe(14505);
    expect(line(r, "HEURES_SUP_50").amount_employee).toBe(4352);
    expect(r.totals.grossCents).toBe(238857);
  });
  it("applique les exonérations sociales et fiscales", () => {
    // Réduction salariale 11,31 % x 188,57 = 21,327 -> 21,33
    expect(line(r, "REDUCTION_SALARIALE_HS").amount_employee).toBe(-2133);
    // Déduction patronale 1,50 € x 10 h = 15,00
    expect(line(r, "DEDUCTION_FORFAITAIRE_HS").amount_employer).toBe(-1500);
    // Heures exonérées nettes : 188,57 - (cotisations proportionnelles sur HS 21,33 - réduction 21,33) = 188,57
    expect(r.totals.hsExemptNetCents).toBe(18857);
    // CSG/CRDS sur HS : assiette 98,25 % x 188,57 = 185,27 ; 12,60 + 4,45 + 0,93 = 17,98
    expect(line(r, "CSG_CRDS_HS").amount_employee).toBe(1798);
    // Net imposable = 2 388,57 - (476,46 - 62,69 - 17,98) - 188,57 = 1 804,21
    expect(r.totals.netTaxableCents).toBe(180421);
    // SMIC RGDU = 1 823,03 + 12,02 x 10 h = 1 943,23 ; C = 0,2330
    expect(r.details.rgdu?.smicMonthCents).toBe(194323);
    expect(line(r, "RGDU").amount_employer).toBe(-55654);
    expect(r.totals.netPaidCents).toBe(189407);
    expect(r.cumulative.hsExemptNetCents).toBe(18857);
  });
  it("lit la répartition 25 % / 50 % transmise par la feuille de temps", () => {
    const r3 = computePayslip(
      input({ salary: 220000, company: company11to49, variables: [variable({ kind: "heures_sup", label: "Heures supplémentaires", quantity: "8.00", note: "25 % : 6.00 h ; 50 % : 2.00 h", source: "timesheet" })] }),
    );
    // 2 200 / 151,67 x 6 h x 125 % = 108,7888 -> 108,79 ; 2 h x 150 % = 43,52 (comme ci-dessus)
    expect(line(r3, "HEURES_SUP_25").amount_employee).toBe(10879);
    expect(line(r3, "HEURES_SUP_50").amount_employee).toBe(4352);
    expect(codes(r3)).not.toContain("HS_MAJORATION_SUPPOSEE");
    // Déduction patronale sur 8 h : 8 x 1,50 = 12,00
    expect(line(r3, "DEDUCTION_FORFAITAIRE_HS").amount_employer).toBe(-1200);
    const bad = computePayslip(input({ salary: 220000, company: company11to49, variables: [variable({ kind: "heures_sup", quantity: "9", note: "25 % : 6.00 h ; 50 % : 2.00 h" })] }));
    expect(codes(bad)).toContain("HEURES_REPARTITION");
  });
  it("bloque si le seuil de 20 salariés ne peut pas être déterminé", () => {
    const r2 = computePayslip(input({ salary: 220000, company: { ...company11to49, headcount: null }, variables: [variable({ kind: "heures_sup", quantity: "3", rate: "25" })] }));
    expect(r2.status).toBe("blocked");
    expect(codes(r2)).toContain("EFFECTIF_20");
  });
});

describe("9. Absence non rémunérée (2 jours de congé sans solde)", () => {
  const r = computePayslip(input({ salary: 240000, variables: [variable({ kind: "absence", label: "Congé sans solde", quantity: "2", note: "CSS", source: "leave" })], pas: { rate: "2.50", isNeutral: false, effectiveDate: "2026-01-01" } }));
  it("retient au réel en heures", () => {
    // 2 400 x (2 j x 7 h) / (22 j x 7 h) = 218,1818 -> 218,18
    expect(line(r, "ABSENCE_NON_REMUNEREE").amount_employee).toBe(-21818);
    expect(r.totals.grossCents).toBe(218182);
    // Heures travaillées = 151,67 - 2 x 7 = 137,67
    expect(r.totals.hoursWorked).toBe("137.67");
    // SMIC RGDU proratisé = 1 823,0333 x 2 181,82 / 2 400 = 1 657,30
    expect(r.details.rgdu?.smicMonthCents).toBe(165730);
    expect(line(r, "RGDU").amount_employer).toBe(-42087);
    expect(r.totals.netPaidCents).toBe(168238);
  });
  it("maintient le salaire pour les congés payés", () => {
    const r2 = computePayslip(input({ salary: 240000, variables: [variable({ kind: "absence", label: "Congés payés", quantity: "3", note: "CP", source: "leave" })] }));
    expect(r2.totals.grossCents).toBe(240000);
    expect(codes(r2)).toContain("CP_MAINTIEN");
  });
});

describe("10. Prime exceptionnelle", () => {
  const r = computePayslip(input({ salary: 260000, variables: [variable({ kind: "prime", label: "Prime de projet", amountCents: 45000 })], pas: { rate: "3.00", isNeutral: false, effectiveDate: "2026-01-01" } }));
  it("soumet la prime à cotisations et à l'impôt", () => {
    // Brut = 2 600 + 450 = 3 050
    expect(r.totals.grossCents).toBe(305000);
    // Vieillesse plafonnée 6,90 % x 3 050 = 210,45
    expect(line(r, "SS_VIEILLESSE_PLAF").amount_employee).toBe(21045);
    // C = 0,0949 ; réduction = 3 050 x 0,0949 = 289,445 -> 289,45
    expect(line(r, "RGDU").amount_employer).toBe(-28945);
    // Net imposable 2 501,27 ; PAS 3 % = 75,0381 -> 75,04
    expect(r.totals.pasAmountCents).toBe(7504);
    expect(r.totals.netPaidCents).toBe(233933);
  });
});

describe("11. Prélèvement à la source : taux personnalisé et barème neutre", () => {
  it("applique le taux personnalisé transmis", () => {
    const r = computePayslip(input({ salary: 280000, company: company11to49, pas: { rate: "4.20", isNeutral: false, effectiveDate: "2026-01-01" } }));
    expect(r.totals.pasKind).toBe("personnalise");
    expect(r.totals.pasRate).toBe("4.20");
  });
  it("applique la grille 2025 pour un versement avant le 1er mai 2026", () => {
    // Net imposable 2 296,25 : grille 2025 (BOI-BAREME-000037-20250410) tranche 2 294 à 2 714 => 5,3 %
    // 2 296,25 x 5,3 % = 121,70125 -> 121,70
    const r = computePayslip(input({ salary: 280000, company: company11to49, pas: null }));
    expect(r.pasRuleSetVersion).toBe("fr-2026.01");
    expect(r.totals.pasRate).toBe("5.3");
    expect(r.totals.pasAmountCents).toBe(12170);
    expect(codes(r)).toContain("PAS_BAREME_NEUTRE");
  });
  it("applique la grille 2026 pour un versement à partir du 1er mai 2026", () => {
    // Même net imposable, avril payé le 5 mai : grille 2026 (BOI-BAREME-000037-20260407) tranche 2 170 à 2 315 => 4,1 %
    // 2 296,25 x 4,1 % = 94,14625 -> 94,15
    const r = computePayslip(
      input({ salary: 280000, company: company11to49, pas: null, period: { year: 2026, month: 4, start: "2026-04-01", end: "2026-04-30", paymentDate: "2026-05-05" } }),
    );
    expect(r.ruleSetVersion).toBe("fr-2026.01");
    expect(r.pasRuleSetVersion).toBe("fr-2026.05");
    expect(r.totals.netTaxableCents).toBe(229625);
    expect(r.totals.pasRate).toBe("4.1");
    expect(r.totals.pasAmountCents).toBe(9415);
  });
  it("lit les bornes de la grille (borne basse incluse)", () => {
    const rs = getRuleSet("fr-2026.05")!;
    expect(neutralRate(rs, 163499)).toBe("0");
    expect(neutralRate(rs, 163500)).toBe("0.5");
    expect(neutralRate(rs, 5555800)).toBe("43");
  });
});

describe("12. Cas hors périmètre : bulletin bloqué avec explication", () => {
  it("bloque un arrêt maladie", () => {
    const r = computePayslip(input({ variables: [variable({ kind: "absence", label: "Arrêt maladie", quantity: "5", note: "MAL", source: "leave" })] }));
    expect(r.status).toBe("blocked");
    expect(r.lines).toHaveLength(0);
    expect(r.anomalies.find((a) => a.code === "ABSENCE_MALADIE")?.severity).toBe("blocking");
    expect(r.blockingReason).toBe("Arrêt maladie non couvert");
  });
  it("bloque un apprenti", () => {
    const r = computePayslip(input({ contract: contract({ type: "APPRENTISSAGE", category: "apprenti" }) }));
    expect(r.status).toBe("blocked");
    expect(codes(r)).toEqual(expect.arrayContaining(["CONTRAT_HORS_PERIMETRE", "STATUT_HORS_PERIMETRE"]));
  });
  it("bloque si un paramètre de paie n'est pas confirmé", () => {
    const r = computePayslip(input({ company: { ...companyLt11, atRate: null, mutuelleConfigured: false } }));
    expect(r.status).toBe("blocked");
    const a = r.anomalies.find((x) => x.code === "PARAMETRE_A_CONFIRMER")!;
    expect(a.title).toBe("Paramètre de paie à confirmer dans l'onboarding");
    expect(a.details?.missing).toEqual(["taux accident du travail", "mutuelle (ou absence de mutuelle)"]);
  });
  it("bloque l'Alsace-Moselle et une période sans règles", () => {
    expect(codes(computePayslip(input({ company: { ...companyLt11, establishmentPostalCode: "67000" } })))).toContain("ALSACE_MOSELLE");
    const old = computePayslip(input({ period: { year: 2025, month: 12, start: "2025-12-01", end: "2025-12-31", paymentDate: "2025-12-31" } }));
    expect(codes(old)).toContain("REGLES_ABSENTES");
  });
  it("traite les régularisations d'absences annulées transmises par le module congés", () => {
    // Annulation d'un CP déjà payé par maintien : aucun effet sur le montant, information seulement
    const cp = computePayslip(input({ salary: 240000, variables: [variable({ kind: "regularisation", label: "Régularisation : annulation Congés payés", quantity: "-2", note: "CP", source: "leave_annulation" })] }));
    expect(cp.status).toBe("computed");
    expect(cp.totals.grossCents).toBe(240000);
    expect(codes(cp)).toContain("REGULARISATION_ABSENCE_PAYEE");
    // Annulation d'un congé sans solde retenu sur un mois validé : montant à saisir, bloquant
    const css = computePayslip(input({ variables: [variable({ kind: "regularisation", label: "Régularisation : annulation Congé sans solde", quantity: "-1", note: "CSS", source: "leave_annulation" })] }));
    expect(css.status).toBe("blocked");
    expect(codes(css)).toContain("REGULARISATION_ABSENCE_A_VALORISER");
    // Régularisation saisie en montant : intégrée au brut
    const amt = computePayslip(input({ salary: 240000, variables: [variable({ kind: "regularisation", label: "Remboursement retenue février", amountCents: 10909 })] }));
    expect(amt.totals.grossCents).toBe(250909);
  });
  it("bloque des titres-restaurant hors limite d'exonération", () => {
    // Part patronale 60 % x 13,00 = 7,80 € > 7,32 € (limite 2026)
    const r = computePayslip(input({ variables: [variable({ kind: "titres_restaurant", label: "Titres-restaurant", quantity: "18", amountCents: 1300, rate: "60" })] }));
    expect(codes(r)).toContain("TR_HORS_EXONERATION");
  });
});

describe("13. Reproductibilité du calcul", () => {
  it("produit le même hash et les mêmes lignes pour les mêmes entrées", () => {
    const a = input({ salary: 245500, variables: [variable({ kind: "prime", label: "Prime", amountCents: 12000 })] });
    const r1 = computePayslip(a);
    const r2 = computePayslip(JSON.parse(JSON.stringify(a)));
    expect(r1.computeHash).toMatch(/^[0-9a-f]{64}$/);
    expect(r2.computeHash).toBe(r1.computeHash);
    expect(r2.lines).toEqual(r1.lines);
  });
  it("change de hash si une entrée change", () => {
    const a = input({ salary: 245500 });
    const b = input({ salary: 245501 });
    expect(computePayslip(a).computeHash).not.toBe(computePayslip(b).computeHash);
  });
});

describe("14. Reprise en cours d'année et régularisation des cumuls", () => {
  const carry = {
    year: 2026,
    throughMonth: 6,
    source: "carryover" as const,
    grossCents: 1800000,
    netTaxableCents: 1476000,
    netPaidCents: 1372000,
    pasCents: 53100,
    employeeContribCents: 389000,
    employerContribCents: 552000,
    hours: "910.02",
    hsExemptNetCents: null,
    rgdu: null,
  };
  // Juillet 2026 : 22 jours ouvrés (14 juillet férié), règles fr-2026.06
  const r = computePayslip(
    input({ salary: 300000, period: { year: 2026, month: 7, start: "2026-07-01", end: "2026-07-31", paymentDate: "2026-07-31" }, cumulsBefore: carry, pas: { rate: "3.60", isNeutral: false, effectiveDate: "2026-01-01" } }),
  );
  it("ajoute le mois aux cumuls repris", () => {
    expect(r.ruleSetVersion).toBe("fr-2026.06");
    // Net payé du mois : 3 000 - 625,21 - 88,57 (3,60 % x 2 460,27) = 2 286,22
    expect(r.totals.netPaidCents).toBe(228622);
    // Cumuls = repris + mois
    expect(r.cumulative.grossCents).toBe(1800000 + 300000);
    expect(r.cumulative.netTaxableCents).toBe(1476000 + 246027);
    expect(r.cumulative.pasCents).toBe(53100 + 8857);
    expect(r.cumulative.netPaidCents).toBe(1372000 + 228622);
    expect(r.cumulative.hours).toBe("1061.69");
  });
  it("calcule la réduction générale sur le mois et le signale", () => {
    // Sans historique de réduction : calcul mensuel, SMIC RGDU gelé à 12,02 € ; C = 0,0999 ; 3 000 x 0,0999 = 299,70
    expect(codes(r)).toContain("RGDU_MENSUELLE");
    expect(line(r, "RGDU").amount_employer).toBe(-29970);
  });
  it("compare le salaire au SMIC revalorisé de juin", () => {
    // 12,31 x 151,666667 = 1 867,02 € : un salaire de 1 823,03 € est sous le SMIC à partir de juin
    const low = computePayslip(input({ salary: 182303, period: { year: 2026, month: 7, start: "2026-07-01", end: "2026-07-31", paymentDate: "2026-07-31" } }));
    expect(codes(low)).toContain("SOUS_SMIC");
    // ... mais pas en mars (SMIC 12,02 €)
    expect(codes(computePayslip(input({ salary: 182303 })))).not.toContain("SOUS_SMIC");
  });
  it("régularise progressivement la réduction générale d'un mois sur l'autre", () => {
    // Janvier au SMIC : réduction 725,75 (C = 0,3981). Février : 1 823,03 + prime 2 000.
    const jan = computePayslip(input({ salary: 182303, period: { year: 2026, month: 1, start: "2026-01-01", end: "2026-01-31", paymentDate: "2026-01-30" }, pas: { rate: "0", isNeutral: false, effectiveDate: "2026-01-01" } }));
    expect(jan.cumulative.rgdu).toEqual({ baseCents: 182303, smicCents: 182303, reductionCents: 72575 });
    const feb = computePayslip(
      input({
        salary: 182303,
        period: { year: 2026, month: 2, start: "2026-02-01", end: "2026-02-28", paymentDate: "2026-02-27" },
        variables: [variable({ kind: "prime", label: "Prime", amountCents: 200000 })],
        cumulsBefore: jan.cumulative,
        pas: { rate: "0", isNeutral: false, effectiveDate: "2026-01-01" },
      }),
    );
    // Cumuls : brut 5 646,06, SMIC 3 646,06 ; 3 x 3 646,06 / 5 646,06 = 1,93730 ; C = 0,1204
    // Réduction cumulée = 5 646,06 x 0,1204 = 679,785 -> 679,79 ; février = 679,79 - 725,75 = -45,96 (reprise)
    expect(line(feb, "RGDU").rate_employer).toBe("0.1204");
    expect(line(feb, "RGDU").amount_employer).toBe(4596);
    expect(feb.cumulative.rgdu?.reductionCents).toBe(67979);
  });
});

describe("15. Forfait annuel de 218 jours", () => {
  it("calcule un cadre au forfait sur un mois complet", () => {
    const r = computePayslip(
      input({ salary: 500000, company: company11to49, contract: contract({ category: "cadre", workTimeMode: "forfait_jours", annualDays: 218 }), pas: { rate: "9.80", isNeutral: false, effectiveDate: "2026-01-01" } }),
    );
    expect(r.status).toBe("computed");
    // SMIC RGDU = 12,02 x 1 820 / 12 = 1 823,03 ; 3 x 1 823,03 / 5 000 = 1,09382 ; C = 0,0218 ; 5 000 x 0,0218 = 109,00
    expect(line(r, "RGDU").amount_employer).toBe(-10900);
    expect(r.totals.netPaidCents).toBe(355942);
  });
  it("bloque une absence non rémunérée au forfait", () => {
    const r = computePayslip(input({ salary: 500000, contract: contract({ category: "cadre", workTimeMode: "forfait_jours", annualDays: 218 }), variables: [variable({ kind: "absence", quantity: "1", note: "CSS" })] }));
    expect(codes(r)).toContain("FORFAIT_JOURS_ABSENCE");
  });
});

describe("Jeux de règles", () => {
  it("choisit la version selon la date", () => {
    expect(loadRuleSet("2026-03-31")?.version).toBe("fr-2026.01");
    expect(loadRuleSet("2026-05-15")?.version).toBe("fr-2026.05");
    expect(loadRuleSet("2026-06-01")?.version).toBe("fr-2026.06");
    expect(loadRuleSet("2025-12-31")).toBeNull();
  });
  it("conserve les sources officielles et la date de consultation", () => {
    const rs = getRuleSet("fr-2026.06")!;
    expect(rs.consultedAt).toBe("2026-10-21");
    expect(rs.params["smic.hourly"].value).toBe("12.31");
    expect(rs.params["rgdu.smicHourly"].value).toBe("12.02");
    for (const p of Object.values(rs.params)) {
      expect(p.sources.length).toBeGreaterThan(0);
      for (const u of p.sources) expect(u).toMatch(/^https:\/\/([a-z0-9-]+\.)*(urssaf\.fr|service-public\.(fr|gouv\.fr)|legifrance\.gouv\.fr|agirc-arrco\.fr|boss\.gouv\.fr|impots\.gouv\.fr|economie\.gouv\.fr|info\.gouv\.fr|net-entreprises\.fr|caf\.fr|ags-garantie-salaires\.org|legifrance\.gouv\.fr)\//);
    }
  });
  it("calcule le coefficient RGDU de référence", () => {
    const rs = getRuleSet("fr-2026.01")!;
    expect(rgduCoefficient(rs, 182303, 182303, false)).toBe(0.3981);
    expect(rgduCoefficient(rs, 182303, 182303, true)).toBe(0.4021);
    // À 3 SMIC exactement : aucune réduction
    expect(rgduCoefficient(rs, 182303, 546909, false)).toBe(0);
  });
  it("expose des cumuls vides cohérents", () => {
    expect(emptyCumuls(2026).rgdu).toEqual({ baseCents: 0, smicCents: 0, reductionCents: 0 });
  });
});
