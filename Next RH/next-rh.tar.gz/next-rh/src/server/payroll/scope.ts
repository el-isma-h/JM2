/**
 * Périmètre explicite du moteur de paie (module pur, affiché dans l'interface).
 * Tout cas listé dans `notCovered` produit une anomalie bloquante expliquée : le bulletin passe au statut « bloqué ».
 */

export type ScopeItem = { label: string; detail: string };

export const payrollScope: { covered: ScopeItem[]; notCovered: ScopeItem[]; conventions: ScopeItem[] } = {
  covered: [
    { label: "Contrats CDI et CDD", detail: "Droit commun, régime général de sécurité sociale, France métropolitaine. Contribution CPF de 1 % pour les CDD." },
    { label: "Non-cadres et cadres", detail: "Retraite complémentaire tranches 1 et 2, CEG, CET au-delà du plafond, APEC pour les cadres." },
    { label: "Temps plein et temps partiel", detail: "Horaire contractuel jusqu'à 35 heures par semaine. Heures complémentaires pour les temps partiels." },
    { label: "Forfait annuel de 218 jours", detail: "Mois complet sans absence non rémunérée ni heures supplémentaires." },
    { label: "Salaire mensuel, horaire ou annuel", detail: "Une seule rémunération en vigueur sur le mois." },
    { label: "Primes, commissions et régularisations en montant", detail: "Soumises à cotisations et à l'impôt." },
    { label: "Heures supplémentaires et complémentaires", detail: "Majorations saisies (25 % ou 50 %, 10 % ou 25 %), réduction salariale de cotisations, déduction patronale forfaitaire (moins de 250 salariés), exonération d'impôt dans la limite annuelle de 7 500 € nets." },
    { label: "Absences non rémunérées", detail: "Congé sans solde : retenue au réel selon les heures du mois." },
    { label: "Congés payés, RTT, événements familiaux", detail: "Indemnisés par maintien du salaire, sans retenue." },
    { label: "Entrée et sortie en cours de mois", detail: "Proratisation au réel (jours ouvrés de présence), plafond de sécurité sociale proratisé en jours calendaires." },
    { label: "Avantages en nature déclarés en montant", detail: "Intégrés au brut et déduits du net." },
    { label: "Titres-restaurant", detail: "Part patronale exonérée dans les limites légales, part salariale déduite du net." },
    { label: "Remboursements de frais et acomptes", detail: "Ajoutés ou déduits du net, hors cotisations." },
    { label: "Mutuelle et prévoyance de l'entreprise", detail: "Montants et taux de l'onboarding, forfait social de 8 % à partir de 11 salariés, CSG sur les parts patronales." },
    { label: "Réduction générale dégressive unique 2026", detail: "Calcul mensuel avec régularisation progressive sur les cumuls de l'année, SMIC gelé à 12,02 €." },
    { label: "Prélèvement à la source", detail: "Taux personnalisé transmis, ou grille de taux par défaut de métropole selon la date de versement." },
  ],
  notCovered: [
    { label: "Arrêts maladie, accidents du travail, maternité et paternité", detail: "Maintien de salaire, indemnités journalières et subrogation." },
    { label: "Dispositions spécifiques des conventions collectives", detail: "Minima, primes et majorations conventionnels ne sont pas appliqués automatiquement (contrôle à faire à chaque période)." },
    { label: "Apprentis, contrats de professionnalisation, stagiaires, intérimaires", detail: "Régimes d'exonération et d'assiette spécifiques." },
    { label: "Dirigeants et mandataires sociaux", detail: "Statut assimilé salarié et cadres dirigeants." },
    { label: "Forfaits jours autres que 218 jours, forfaits en heures", detail: "Ainsi que les absences, entrées et sorties en cours de mois au forfait jours." },
    { label: "Horaire contractuel supérieur à 35 heures", detail: "Heures supplémentaires structurelles." },
    { label: "Alsace-Moselle et outre-mer", detail: "Régime local, SMIC et barèmes spécifiques." },
    { label: "Indemnités de rupture et solde de tout compte", detail: "Indemnité de licenciement, de rupture conventionnelle, de fin de CDD, compensatrice de congés payés : à ajouter en variable ou hors moteur." },
    { label: "Saisies sur salaire", detail: "Fraction saisissable." },
    { label: "Changement de salaire en cours de mois", detail: "Proratisation entre deux rémunérations." },
    { label: "Heures supplémentaires dans les entreprises de 250 salariés et plus", detail: "Déduction patronale non confirmée par une source officielle pour 2026." },
    { label: "CDD de deux mois au plus sans taux d'imposition", detail: "Abattement spécifique du prélèvement à la source." },
    { label: "Réintégration de l'excédent de titres-restaurant", detail: "Part patronale hors limites d'exonération." },
  ],
  conventions: [
    { label: "Arrondis", detail: "Chaque ligne est arrondie au centime le plus proche ; le coefficient de réduction générale à 4 décimales." },
    { label: "Heures réelles", detail: "Horaire hebdomadaire réparti sur 5 jours ouvrés ; jours fériés chômés et rémunérés, exclus du décompte." },
    { label: "Plafond de sécurité sociale", detail: "Mensuel, sans régularisation annuelle ; temps partiel sans abattement de plafond." },
    { label: "Prévoyance", detail: "Taux uniques du contrat appliqués au brut dans la limite de 8 plafonds." },
    { label: "Déclarations annuelles", detail: "Solde de taxe d'apprentissage, participation construction et contribution supplémentaire à l'apprentissage ne figurent pas sur le bulletin." },
  ],
};
