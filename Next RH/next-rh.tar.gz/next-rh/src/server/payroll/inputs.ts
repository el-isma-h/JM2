import "server-only";
import { and, desc, eq, gte, inArray, isNull, lt, lte, ne, or } from "drizzle-orm";
import { db, schema } from "@/db";
import { readPayrollSettings } from "@/server/onboarding/payroll-settings";
import { daysInMonth, isoDate } from "./engine/calendar";
import { emptyCumuls, ENGINE_VERSION } from "./engine/compute";
import type { EngineCumuls, PayslipInput, VariableKind } from "./engine/types";

type Period = typeof schema.payrollPeriods.$inferSelect;
type Company = typeof schema.companies.$inferSelect;
type Employee = typeof schema.employees.$inferSelect;

export const EDITABLE_STATUSES = new Set(["open", "collecting", "checking", "computed", "controlled"]);
/** Variables prises en compte par le calcul. Les brouillons et refus sont ignorés (et signalés). */
export const COUNTED_VARIABLE_STATUSES = ["validated", "submitted"] as const;

export function periodBounds(p: { year: number; month: number }) {
  return { start: isoDate(p.year, p.month, 1), end: isoDate(p.year, p.month, daysInMonth(p.year, p.month)) };
}

export function paymentDateFor(company: Company, year: number, month: number): string {
  const s = readPayrollSettings(company.payrollSettings);
  const last = daysInMonth(year, month);
  return isoDate(year, month, Math.min(s.paymentDay ?? last, last));
}

/** Salariés concernés par la période : non brouillon, non suspendus, présents au moins un jour du mois. */
export async function employeesInScope(companyId: string, period: { year: number; month: number }) {
  const { start, end } = periodBounds(period);
  const rows = await db
    .select()
    .from(schema.employees)
    .where(
      and(
        eq(schema.employees.companyId, companyId),
        ne(schema.employees.status, "draft"),
        or(isNull(schema.employees.hireDate), lte(schema.employees.hireDate, end)),
        or(isNull(schema.employees.leaveDate), gte(schema.employees.leaveDate, start)),
      ),
    )
    .orderBy(schema.employees.lastName, schema.employees.firstName);
  return {
    included: rows.filter((e) => e.status !== "suspended" && (e.status !== "left" || (e.leaveDate !== null && e.leaveDate >= start))),
    suspended: rows.filter((e) => e.status === "suspended"),
  };
}

function toCumuls(raw: unknown, year: number): EngineCumuls | null {
  if (!raw || typeof raw !== "object") return null;
  const c = raw as Partial<EngineCumuls>;
  if (c.year !== year || typeof c.grossCents !== "number") return null;
  const e = emptyCumuls(year);
  // Seules les clés de cumul sont reprises (le jsonb stocke aussi totaux et détails d'affichage).
  return {
    year,
    throughMonth: c.throughMonth ?? e.throughMonth,
    source: "payslips",
    grossCents: c.grossCents,
    netTaxableCents: c.netTaxableCents ?? 0,
    netPaidCents: c.netPaidCents ?? 0,
    pasCents: c.pasCents ?? 0,
    employeeContribCents: c.employeeContribCents ?? 0,
    employerContribCents: c.employerContribCents ?? 0,
    hours: c.hours ?? "0",
    hsExemptNetCents: c.hsExemptNetCents === undefined ? 0 : c.hsExemptNetCents,
    rgdu: c.rgdu === undefined ? e.rgdu : c.rgdu,
  };
}

/** Cumuls avant la période : dernier bulletin calculé de l'année, sinon cumuls de reprise, sinon vides. */
export async function cumulsBefore(companyId: string, employeeId: string, year: number, month: number): Promise<EngineCumuls> {
  const [prev] = await db
    .select({ cumulative: schema.payslips.cumulative, month: schema.payrollPeriods.month })
    .from(schema.payslips)
    .innerJoin(schema.payrollPeriods, eq(schema.payrollPeriods.id, schema.payslips.periodId))
    .where(
      and(
        eq(schema.payrollPeriods.companyId, companyId),
        eq(schema.payslips.employeeId, employeeId),
        eq(schema.payrollPeriods.year, year),
        lt(schema.payrollPeriods.month, month),
        ne(schema.payslips.status, "blocked"),
      ),
    )
    .orderBy(desc(schema.payrollPeriods.month))
    .limit(1);
  const fromSlip = prev ? toCumuls(prev.cumulative, year) : null;
  const [carry] = await db
    .select()
    .from(schema.employeeCarryovers)
    .where(and(eq(schema.employeeCarryovers.employeeId, employeeId), eq(schema.employeeCarryovers.year, year), lt(schema.employeeCarryovers.throughMonth, month)))
    .limit(1);
  if (fromSlip && (!carry || prev.month > carry.throughMonth)) return fromSlip;
  if (carry) {
    return {
      year,
      throughMonth: carry.throughMonth,
      source: "carryover",
      grossCents: carry.grossYtdCents,
      netTaxableCents: carry.netTaxableYtdCents,
      netPaidCents: carry.netPaidYtdCents,
      pasCents: carry.pasYtdCents,
      employeeContribCents: carry.employeeContribYtdCents,
      employerContribCents: carry.employerContribYtdCents,
      hours: String(carry.hoursYtd),
      hsExemptNetCents: null,
      rgdu: null,
    };
  }
  return emptyCumuls(year);
}

/** Construit l'entrée du moteur pour un salarié (snapshot reproductible). */
export async function buildPayslipInput(period: Period, company: Company, employee: Employee): Promise<{ input: PayslipInput; draftVariables: number; contractId: string | null }> {
  const { start, end } = periodBounds(period);
  const settings = readPayrollSettings(company.payrollSettings);
  const raw = (company.payrollSettings ?? {}) as Record<string, unknown>;

  let postalCode: string | null = null;
  if (employee.establishmentId) {
    const [est] = await db
      .select({ postalCode: schema.establishments.postalCode })
      .from(schema.establishments)
      .where(and(eq(schema.establishments.id, employee.establishmentId), eq(schema.establishments.companyId, company.id)))
      .limit(1);
    postalCode = est?.postalCode ?? null;
  }
  if (!postalCode) {
    const [head] = await db
      .select({ postalCode: schema.establishments.postalCode })
      .from(schema.establishments)
      .where(and(eq(schema.establishments.companyId, company.id), eq(schema.establishments.isHeadOffice, true)))
      .limit(1);
    postalCode = head?.postalCode ?? company.postalCode ?? null;
  }

  const contracts = await db
    .select()
    .from(schema.contracts)
    .where(and(eq(schema.contracts.employeeId, employee.id), lte(schema.contracts.startDate, end), or(isNull(schema.contracts.endDate), gte(schema.contracts.endDate, start))))
    .orderBy(desc(schema.contracts.startDate));
  const c = contracts[0] ?? null;

  const comps = await db
    .select()
    .from(schema.compensations)
    .where(and(eq(schema.compensations.employeeId, employee.id), lte(schema.compensations.effectiveDate, end), or(isNull(schema.compensations.endDate), gte(schema.compensations.endDate, start))))
    .orderBy(desc(schema.compensations.effectiveDate));
  // Une rémunération antérieure est remplacée par la suivante : on ne garde que celles en vigueur sur le mois.
  const effective = comps.filter((x, i) => i === 0 || x.effectiveDate > start || !comps.slice(0, i).some((y) => y.effectiveDate <= start));

  const vars = await db
    .select()
    .from(schema.payrollVariables)
    .where(and(eq(schema.payrollVariables.periodId, period.id), eq(schema.payrollVariables.employeeId, employee.id)))
    .orderBy(schema.payrollVariables.createdAt, schema.payrollVariables.id);
  const counted = vars.filter((v) => (COUNTED_VARIABLE_STATUSES as readonly string[]).includes(v.status));

  const [pas] = await db
    .select()
    .from(schema.pasRates)
    .where(and(eq(schema.pasRates.employeeId, employee.id), lte(schema.pasRates.effectiveDate, end)))
    .orderBy(desc(schema.pasRates.effectiveDate), desc(schema.pasRates.createdAt))
    .limit(1);

  const input: PayslipInput = {
    engineVersion: ENGINE_VERSION,
    period: { year: period.year, month: period.month, start, end, paymentDate: period.paymentDate ?? paymentDateFor(company, period.year, period.month) },
    company: {
      headcountBracket: settings.headcountBracket ?? null,
      headcount: company.headcount ?? null,
      atRate: settings.atRate ?? null,
      mobilityRate: settings.mobilityRate ?? null,
      mutuelle: settings.mutuelle ?? null,
      prevoyance: settings.prevoyance ?? null,
      mutuelleConfigured: "mutuelle" in raw,
      prevoyanceConfigured: "prevoyance" in raw,
      establishmentPostalCode: postalCode,
    },
    employee: { id: employee.id, fullName: `${employee.firstName} ${employee.lastName}`, hireDate: employee.hireDate, leaveDate: employee.leaveDate },
    contract: c
      ? {
          id: c.id,
          type: c.type,
          category: c.category,
          startDate: c.startDate,
          endDate: c.endDate,
          workTimeMode: c.workTimeMode,
          weeklyHours: String(c.weeklyHours),
          monthlyHours: String(c.monthlyHours),
          annualDays: c.annualDays,
          isPartTime: c.isPartTime,
        }
      : null,
    compensations: effective.map((x) => ({ basis: x.basis, grossAmountCents: x.grossAmountCents, effectiveDate: x.effectiveDate, endDate: x.endDate })),
    variables: counted.map((v) => ({
      id: v.id,
      kind: v.kind as VariableKind,
      label: v.label,
      quantity: v.quantity === null ? null : String(v.quantity),
      rate: v.rate === null ? null : String(Number(v.rate)),
      amountCents: v.amountCents,
      note: v.note,
      source: v.source,
    })),
    pas: pas ? { rate: String(pas.rate), isNeutral: pas.isNeutral, effectiveDate: pas.effectiveDate } : null,
    cumulsBefore: await cumulsBefore(company.id, employee.id, period.year, period.month),
  };
  return { input, draftVariables: vars.length - counted.length, contractId: c?.id ?? null };
}

export async function hasPrimaryBankAccount(employeeIds: string[]) {
  if (!employeeIds.length) return new Set<string>();
  const rows = await db.select({ e: schema.employeeBankAccounts.employeeId }).from(schema.employeeBankAccounts).where(inArray(schema.employeeBankAccounts.employeeId, employeeIds));
  return new Set(rows.map((r) => r.e));
}
