/**
 * Insère ou actualise la table `payroll_rule_sets` depuis src/server/payroll/rules/*.json.
 * Usage : npx tsx --conditions=react-server src/server/payroll/scripts/sync-rule-sets.ts
 */
import { syncRuleSets } from "../rule-sets-db";
import { pool } from "@/db";

syncRuleSets()
  .then((res) => {
    for (const r of res) console.log(`${r.version} : ${r.action} (${r.checksum.slice(0, 12)})`);
  })
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
