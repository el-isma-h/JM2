import { describe, expect, it } from "vitest";
import { computePayslip } from "../../engine/compute";
import { company11to49, input, variable } from "../../engine/__tests__/fixtures";
import { buildAccountingEntries, buildCharges, buildJournal, buildSepaXml, ibanValid, sepaText, type FilingSlip } from "../builders";
import { buildDsn, luhnValid, nirValid } from "../dsn";

const company = { ...company11to49, mutuelle: { name: "Mutuelle", employerCents: 4185, employeeCents: 2790 } };
function slip(salary: number, extra: Partial<Parameters<typeof input>[0]> = {}): FilingSlip {
  const r = computePayslip(input({ salary, company, ...extra }));
  return { employeeId: `e-${salary}`, employeeNumber: String(salary), firstName: "Océane", lastName: "Dufresne", establishmentId: "est-1", establishmentName: "Siège de Lyon", lines: r.lines, totals: r.totals, hoursWorked: r.totals.hoursWorked, rgduIrcPartCents: r.details.rgdu?.ircPartCents ?? 0 };
}

describe("Contrôles d'identifiants", () => {
  it("valide un IBAN par la clé modulo 97", () => {
    // IBAN d'exemple publié par la norme ISO 13616 pour la France
    expect(ibanValid("FR76 3000 6000 0112 3456 7890 189")).toBe(true);
    expect(ibanValid("FR76 3000 6000 0112 3456 7890 188")).toBe(false);
    expect(ibanValid("FR7630006000011234567890")).toBe(false);
  });
  it("valide SIREN, SIRET (Luhn) et NIR (clé 97)", () => {
    expect(luhnValid("732829320")).toBe(true);
    expect(luhnValid("732829321")).toBe(false);
    // NIR fictif : 1 89 05 69 123 456, clé = 97 - (1890569123456 mod 97)
    const body = "1890569123456";
    const key = String(97 - Number(BigInt(body) % BigInt(97))).padStart(2, "0");
    expect(nirValid(body + key)).toBe(true);
    expect(nirValid(body + (key === "01" ? "02" : "01"))).toBe(false);
  });
});

describe("Exports comptables et états", () => {
  const slips = [slip(245500), slip(182303, { variables: [variable({ kind: "indemnite", label: "Frais", amountCents: 6420 }), variable({ kind: "acompte", label: "Acompte", amountCents: 30000 })] })];
  it("produit des écritures équilibrées", () => {
    const acc = buildAccountingEntries(slips, { journal: "PAIE", date: "2026-03-31", label: "Paie mars 2026" });
    expect(acc.balanced).toBe(true);
    expect(acc.debit).toBe(acc.credit);
    // 421 = somme des nets payés
    expect(acc.entries.find((e) => e.account === "421000")?.credit).toBe(slips[0].totals.netPaidCents + slips[1].totals.netPaidCents);
    // 641 = somme des bruts
    expect(acc.entries.find((e) => e.account === "641100")?.debit).toBe(245500 + 182303);
    expect(acc.entries.find((e) => e.account === "425000")?.credit).toBe(30000);
  });
  it("ventile les charges par organisme et totalise le journal", () => {
    const ch = buildCharges(slips);
    const total = ch.summary.filter((s) => s.organism !== "impots").reduce((s, o) => s + o.total, 0);
    const expected = slips.reduce((s, x) => s + x.totals.employeeContribCents + x.totals.employerContribCents, 0);
    expect(total).toBe(expected);
    const j = buildJournal(slips);
    expect(j.totals.gross).toBe(427803);
    expect(j.csv.toString("utf8")).toContain("TOTAL");
  });
});

describe("Virements SEPA pain.001.001.03", () => {
  it("contient le nombre de transactions et la somme de contrôle", () => {
    const { xml, count, totalCents } = buildSepaXml({
      messageId: "PAIE-2026-03-TEST",
      createdAt: "2026-03-30T10:00:00",
      executionDate: "2026-03-31",
      debtorName: "Lorvay Ingénierie SAS",
      debtorIban: "FR7630006000011234567890189",
      debtorBic: null,
      label: "Salaire mars 2026",
      payments: [
        { employeeId: "a", name: "Océane Dufresne", iban: "FR7630006000011234567890189", bic: null, amountCents: 191211, reference: "SAL-1" },
        { employeeId: "b", name: "Zoé", iban: "FR7630006000011234567890189", bic: null, amountCents: 0, reference: "SAL-2" },
      ],
    });
    const s = xml.toString("utf8");
    expect(count).toBe(1);
    expect(totalCents).toBe(191211);
    expect(s).toContain("urn:iso:std:iso:20022:tech:xsd:pain.001.001.03");
    expect(s).toContain("<NbOfTxs>1</NbOfTxs>");
    expect(s).toContain("<CtrlSum>1912.11</CtrlSum>");
    expect(s).toContain("<Nm>Oceane Dufresne</Nm>");
    expect(sepaText("Lorvay Ingénierie & Cie")).toBe("Lorvay Ingenierie Cie");
  });
});

describe("Préparation DSN", () => {
  it("génère les blocs principaux et signale les données manquantes", () => {
    const s = slip(245500);
    const dsn = buildDsn({
      software: { name: "Next RH", version: "1.0.0" },
      company: { siren: "732829320", legalName: "Lorvay Ingénierie SAS", ape: "7112B", address: "9 rue Duguesclin", postalCode: "69006", city: "Lyon", idcc: "1486", headNic: "00011" },
      contact: { name: "Sophie Lemaire-Daviet", email: "rh@exemple.invalid", phone: null },
      establishments: [
        {
          siret: "73282932000074",
          ape: "7112B",
          address: "9 rue Duguesclin",
          postalCode: "69006",
          city: "Lyon",
          headcount: 1,
          urssafId: null,
          employees: [
            {
              nir: null,
              lastName: "Dufresne",
              birthName: null,
              firstName: "Océane",
              gender: "F",
              birthDate: "1992-03-19",
              birthPlace: "Lyon",
              address: "18 rue Chevreul",
              postalCode: "69007",
              city: "Lyon",
              contract: { id: "c-1", startDate: "2022-09-05", endDate: null, type: "CDI", category: "non_cadre", jobTitle: "Comptable", workTimeMode: "heures", weeklyHours: "35", monthlyHours: "151.67", isPartTime: false },
              establishmentSiret: "73282932000074",
              lines: s.lines,
              totals: s.totals,
              hoursWorked: s.hoursWorked,
              rgduCents: 0,
            },
          ],
        },
      ],
      period: { year: 2026, month: 3, start: "2026-03-01", end: "2026-03-31", paymentDate: "2026-03-31" },
      generatedAt: "2026-03-30T10:00:00.000Z",
    });
    const t = dsn.text.toString("latin1");
    expect(t).toContain("S10.G00.00.005,'01'");
    expect(t).toContain("S20.G00.05.005,'01032026'");
    expect(t).toContain(`S21.G00.50.002,'${(s.totals.netTaxableCents / 100).toFixed(2)}'`);
    expect(t).toContain("S21.G00.40.017,'1486'");
    expect(dsn.controls.some((c) => c.code === "NIR_ABSENT" && c.level === "error")).toBe(true);
    expect(dsn.controls.some((c) => c.code === "NON_TRANSMIS")).toBe(true);
  });
});
