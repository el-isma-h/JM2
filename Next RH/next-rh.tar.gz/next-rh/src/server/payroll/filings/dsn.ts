/**
 * Préparation de la DSN mensuelle au format texte de la norme NEODeS (une rubrique par ligne : `bloc.rubrique,'valeur'`).
 * Fichier PRÉPARÉ, NON TRANSMIS : il est marqué « fichier d'essai » (S10.G00.00.005 = 01) et aucune connexion à
 * net-entreprises n'existe dans Next RH. Il doit être contrôlé (DSN-VAL) et déposé par l'utilisateur.
 *
 * Couverture : blocs S10 (envoi, émetteur, contact), S20 (déclaration), S21.G00.06 (entreprise), .11 (établissement),
 * .20/.22/.23 (versement, bordereau et cotisations agrégées URSSAF), .30 (individu), .40 (contrat), .50 (versement),
 * .51 (rémunérations), .78 (bases assujetties), .81 (réduction générale), S90 (total).
 * Les codes types de personnel (CTP) et codes de cotisation doivent être revus avec le cahier technique en vigueur avant
 * tout dépôt : le moteur ne garantit pas leur exhaustivité.
 */
import type { PayslipLine, PayslipTotals } from "../engine/types";

export type DsnEmployee = {
  nir: string | null;
  lastName: string;
  birthName: string | null;
  firstName: string;
  gender: "F" | "M" | "X" | null;
  birthDate: string | null;
  birthPlace: string | null;
  address: string | null;
  postalCode: string | null;
  city: string | null;
  contract: {
    id: string;
    startDate: string;
    endDate: string | null;
    type: string;
    category: string;
    jobTitle: string | null;
    workTimeMode: string;
    weeklyHours: string;
    monthlyHours: string;
    isPartTime: boolean;
  } | null;
  establishmentSiret: string | null;
  lines: PayslipLine[];
  totals: PayslipTotals;
  hoursWorked: string;
  rgduCents: number;
};

export type DsnInput = {
  software: { name: string; version: string };
  company: { siren: string | null; legalName: string; ape: string | null; address: string | null; postalCode: string | null; city: string | null; idcc: string | null; headNic: string | null };
  contact: { name: string; email: string | null; phone: string | null };
  establishments: { siret: string | null; ape: string | null; address: string | null; postalCode: string | null; city: string | null; headcount: number; urssafId: string | null; employees: DsnEmployee[] }[];
  period: { year: number; month: number; start: string; end: string; paymentDate: string };
  generatedAt: string;
};

export type DsnControl = { level: "error" | "warning" | "info"; code: string; message: string };

const dd = (iso: string) => `${iso.slice(8, 10)}${iso.slice(5, 7)}${iso.slice(0, 4)}`;
const amt = (c: number) => (c / 100).toFixed(2);
const clean = (s: string | null | undefined, max = 80) =>
  (s ?? "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^A-Za-z0-9 \-/.,]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase()
    .slice(0, max);

export function luhnValid(digits: string): boolean {
  if (!/^\d+$/.test(digits)) return false;
  let sum = 0;
  let dbl = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = digits.charCodeAt(i) - 48;
    if (dbl) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
    dbl = !dbl;
  }
  return sum % 10 === 0;
}

/** NIR à 15 caractères (13 + clé) : clé = 97 - (NIR mod 97), Corse 2A -> 19 et 2B -> 18 pour le calcul. */
export function nirValid(raw: string): boolean {
  const s = raw.replace(/\s/g, "").toUpperCase();
  if (!/^[123478]\d{2}(0[1-9]|1[0-2]|[2-9]\d)(\d{2}|2A|2B)\d{6}\d{2}$/.test(s)) return false;
  const body = s.slice(0, 13).replace("2A", "19").replace("2B", "18");
  const key = Number(s.slice(13));
  return 97 - Number(BigInt(body) % BigInt(97)) === key;
}

export function buildDsn(input: DsnInput): { text: Buffer; controls: DsnControl[]; lines: number; individuals: number } {
  const out: string[] = [];
  const controls: DsnControl[] = [];
  const put = (rub: string, value: string | number | null | undefined) => {
    if (value === null || value === undefined || value === "") return;
    out.push(`${rub},'${String(value).replace(/'/g, " ")}'`);
  };
  const err = (code: string, message: string) => controls.push({ level: "error", code, message });
  const warn = (code: string, message: string) => controls.push({ level: "warning", code, message });

  const siren = input.company.siren?.replace(/\s/g, "") ?? "";
  if (!/^\d{9}$/.test(siren) || !luhnValid(siren)) err("SIREN", `SIREN absent ou invalide (${siren || "vide"}).`);
  const mm = String(input.period.month).padStart(2, "0");

  // S10 : envoi
  put("S10.G00.00.001", input.software.name);
  put("S10.G00.00.002", input.software.name);
  put("S10.G00.00.003", input.software.version);
  put("S10.G00.00.005", "01"); // 01 = fichier d'essai : jamais un envoi réel
  put("S10.G00.00.006", "P26V01");
  put("S10.G00.00.008", "01");
  put("S10.G00.01.001", siren);
  put("S10.G00.01.002", input.company.headNic);
  put("S10.G00.01.003", clean(input.company.legalName));
  put("S10.G00.01.004", clean(input.company.address, 50));
  put("S10.G00.01.005", input.company.postalCode);
  put("S10.G00.01.006", clean(input.company.city, 50));
  put("S10.G00.02.002", clean(input.contact.name));
  put("S10.G00.02.004", input.contact.email);
  put("S10.G00.02.005", input.contact.phone?.replace(/\s/g, ""));
  // S20 : déclaration
  put("S20.G00.05.001", "01");
  put("S20.G00.05.002", "01");
  put("S20.G00.05.003", "11");
  put("S20.G00.05.004", "1");
  put("S20.G00.05.005", `01${mm}${input.period.year}`);
  put("S20.G00.05.007", dd(input.generatedAt.slice(0, 10)));
  put("S20.G00.05.008", "01");
  put("S20.G00.05.010", "01");
  // S21.G00.06 : entreprise
  put("S21.G00.06.001", siren);
  put("S21.G00.06.002", input.company.headNic);
  put("S21.G00.06.003", input.company.ape?.replace(".", ""));
  put("S21.G00.06.004", clean(input.company.address, 50));
  put("S21.G00.06.005", input.company.postalCode);
  put("S21.G00.06.006", clean(input.company.city, 50));
  if (!input.company.ape) err("APE", "Code APE de l'entreprise manquant.");

  let individuals = 0;
  let totalTaxable = 0;
  let declaredTaxable = 0;
  for (const est of input.establishments) {
    const siret = est.siret?.replace(/\s/g, "") ?? "";
    if (!/^\d{14}$/.test(siret) || !luhnValid(siret)) err("SIRET", `SIRET d'établissement absent ou invalide (${siret || "vide"}).`);
    else if (siren && !siret.startsWith(siren)) err("SIRET_SIREN", `Le SIRET ${siret} ne commence pas par le SIREN ${siren}.`);
    put("S21.G00.11.001", siret.slice(9));
    put("S21.G00.11.002", est.ape?.replace(".", "") ?? input.company.ape?.replace(".", ""));
    put("S21.G00.11.003", clean(est.address, 50));
    put("S21.G00.11.004", est.postalCode);
    put("S21.G00.11.005", clean(est.city, 50));
    put("S21.G00.11.008", est.headcount);

    // Cotisations URSSAF agrégées de l'établissement
    const urssafLines = est.employees.flatMap((e) => e.lines.filter((l) => l.organism === "urssaf" && (l.kind === "contribution" || l.kind === "reduction")));
    const urssafTotal = urssafLines.reduce((s, l) => s + l.amount_employee + l.amount_employer, 0);
    if (!est.urssafId) warn("URSSAF_ID", "Identifiant de l'organisme URSSAF (SIRET de l'URSSAF) non renseigné : à compléter dans S21.G00.20.001 et S21.G00.22.001.");
    put("S21.G00.20.001", est.urssafId ?? "A_COMPLETER");
    put("S21.G00.20.005", amt(urssafTotal));
    put("S21.G00.20.006", dd(input.period.start));
    put("S21.G00.20.007", dd(input.period.end));
    put("S21.G00.20.010", "05");
    put("S21.G00.22.001", est.urssafId ?? "A_COMPLETER");
    put("S21.G00.22.003", dd(input.period.start));
    put("S21.G00.22.004", dd(input.period.end));
    put("S21.G00.22.005", amt(urssafTotal));
    const sumBase = (pred: (l: PayslipLine) => boolean) => est.employees.reduce((s, e) => s + e.lines.filter(pred).reduce((a, l) => a + (l.base ?? 0), 0), 0);
    const sumAmt = (pred: (l: PayslipLine) => boolean) => est.employees.reduce((s, e) => s + e.lines.filter(pred).reduce((a, l) => a + l.amount_employee + l.amount_employer, 0), 0);
    // L'assiette d'un CTP est celle d'une seule rubrique représentative (et non la somme des assiettes de chaque ligne).
    const ctp = (code: string, qualifier: string, pred: (l: PayslipLine) => boolean, baseCode?: string) => {
      const m = sumAmt(pred);
      if (!m) return;
      put("S21.G00.23.001", code);
      put("S21.G00.23.002", qualifier);
      put("S21.G00.23.004", amt(sumBase((l) => (baseCode ? l.code === baseCode : pred(l)) && l.base !== null)));
      put("S21.G00.23.005", amt(m));
    };
    ctp("100", "920", (l) => l.code === "SS_VIEILLESSE_PLAF");
    ctp("100", "921", (l) => ["SS_MALADIE", "SS_VIEILLESSE_DEPLAF", "ALLOC_FAM", "CSA", "ATMP"].includes(l.code), "SS_MALADIE");
    ctp("260", "921", (l) => l.code.startsWith("CSG"), "CSG_DEDUCTIBLE");
    ctp("772", "921", (l) => l.code === "CHOMAGE");
    ctp("937", "921", (l) => l.code === "AGS");
    ctp("332", "920", (l) => l.code === "FNAL" && l.rule === "contrib.fnalLt50");
    ctp("236", "921", (l) => l.code === "FNAL" && l.rule === "contrib.fnalGte50");
    ctp("027", "921", (l) => l.code === "DIALOGUE_SOCIAL");
    ctp("900", "921", (l) => l.code === "VERSEMENT_MOBILITE");
    ctp("668", "921", (l) => l.code === "RGDU", "RGDU");
    warn("CTP", "Codes types de personnel (CTP) agrégés : liste limitée aux cotisations courantes, à vérifier avec le référentiel URSSAF.");

    for (const e of est.employees) {
      individuals++;
      const who = `${e.firstName} ${e.lastName}`;
      const nir = e.nir?.replace(/\s/g, "").toUpperCase() ?? "";
      if (!nir) err("NIR_ABSENT", `${who} : numéro de sécurité sociale absent.`);
      else if (!nirValid(nir)) err("NIR_INVALIDE", `${who} : numéro de sécurité sociale invalide (clé de contrôle).`);
      if (!e.contract) err("CONTRAT", `${who} : aucun contrat.`);
      put("S21.G00.30.001", nir.slice(0, 13));
      put("S21.G00.30.002", clean(e.birthName ?? e.lastName));
      put("S21.G00.30.003", e.birthName && e.birthName !== e.lastName ? clean(e.lastName) : null);
      put("S21.G00.30.004", clean(e.firstName));
      put("S21.G00.30.005", e.gender === "M" ? "01" : e.gender === "F" ? "02" : null);
      put("S21.G00.30.006", e.birthDate ? dd(e.birthDate) : null);
      put("S21.G00.30.007", clean(e.birthPlace, 30));
      put("S21.G00.30.008", clean(e.address, 50));
      put("S21.G00.30.009", e.postalCode);
      put("S21.G00.30.010", clean(e.city, 50));
      if (!e.birthDate) err("NAISSANCE", `${who} : date de naissance absente.`);
      const c = e.contract;
      if (c) {
        put("S21.G00.40.001", dd(c.startDate));
        put("S21.G00.40.002", c.category === "cadre" ? "02" : "04");
        put("S21.G00.40.003", c.category === "cadre" ? "01" : "04");
        put("S21.G00.40.006", clean(c.jobTitle, 120));
        put("S21.G00.40.007", c.type === "CDD" ? "02" : "01");
        put("S21.G00.40.008", "99");
        put("S21.G00.40.009", c.id.replace(/-/g, "").slice(0, 20).toUpperCase());
        put("S21.G00.40.010", c.endDate ? dd(c.endDate) : null);
        const forfait = c.workTimeMode === "forfait_jours";
        put("S21.G00.40.011", forfait ? "12" : "10");
        put("S21.G00.40.012", forfait ? "218.00" : "151.67");
        put("S21.G00.40.013", forfait ? "218.00" : Number(c.monthlyHours).toFixed(2));
        put("S21.G00.40.014", forfait ? "10" : c.isPartTime ? "20" : "10");
        put("S21.G00.40.016", "99");
        put("S21.G00.40.017", input.company.idcc ?? "9999");
        put("S21.G00.40.018", "200");
        put("S21.G00.40.019", siret);
        put("S21.G00.40.020", "200");
        put("S21.G00.40.024", "99");
        warn("PCS", `${who} : code PCS-ESE (S21.G00.40.004) non géré par Next RH, à compléter.`);
      }
      // Versement individu
      put("S21.G00.50.001", dd(input.period.paymentDate));
      put("S21.G00.50.002", amt(e.totals.netTaxableCents));
      put("S21.G00.50.003", "1");
      put("S21.G00.50.004", amt(e.totals.netPaidCents));
      put("S21.G00.50.006", Number(e.totals.pasRate).toFixed(2));
      put("S21.G00.50.007", e.totals.pasKind === "personnalise" ? "01" : "07");
      put("S21.G00.50.009", amt(e.totals.pasAmountCents));
      put("S21.G00.50.013", amt(e.totals.pasBaseCents));
      totalTaxable += e.totals.netTaxableCents;
      declaredTaxable += Math.round(Number(amt(e.totals.netTaxableCents)) * 100);
      // Rémunérations
      const base = e.lines.find((l) => l.code === "SALAIRE_BASE");
      const rem = (type: string, cents: number, hours?: string) => {
        put("S21.G00.51.001", dd(input.period.start));
        put("S21.G00.51.002", dd(input.period.end));
        put("S21.G00.51.010", c?.id.replace(/-/g, "").slice(0, 20).toUpperCase());
        put("S21.G00.51.011", type);
        put("S21.G00.51.012", hours);
        put("S21.G00.51.013", amt(cents));
      };
      rem("001", e.totals.grossCents);
      rem("002", e.lines.find((l) => l.code === "CHOMAGE")?.base ?? e.totals.grossCents);
      rem("010", base?.amount_employee ?? 0, c?.workTimeMode === "forfait_jours" ? undefined : Number(e.hoursWorked).toFixed(2));
      const hs = e.lines.filter((l) => l.code.startsWith("HEURES_"));
      if (hs.length) rem("017", hs.reduce((s, l) => s + l.amount_employee, 0), hs.reduce((s, l) => s + Number(l.quantity ?? 0), 0).toFixed(2));
      // Bases assujetties
      const b78 = (code: string, cents: number) => {
        put("S21.G00.78.001", code);
        put("S21.G00.78.002", dd(input.period.start));
        put("S21.G00.78.003", dd(input.period.end));
        put("S21.G00.78.004", amt(cents));
      };
      b78("02", e.lines.find((l) => l.code === "SS_VIEILLESSE_PLAF")?.base ?? 0);
      b78("03", e.totals.grossCents);
      b78("04", e.lines.find((l) => l.code === "CSG_DEDUCTIBLE")?.base ?? 0);
      b78("07", e.lines.find((l) => l.code === "CHOMAGE")?.base ?? 0);
      if (e.rgduCents) {
        put("S21.G00.81.001", "018");
        put("S21.G00.81.004", amt(e.rgduCents));
      }
    }
  }
  if (totalTaxable !== declaredTaxable) err("NET_FISCAL", "Écart d'arrondi entre la somme des nets fiscaux et les montants déclarés.");
  out.push(`S90.G00.90.001,'${out.length + 2}'`);
  out.push(`S90.G00.90.002,'1'`);
  controls.push({ level: "info", code: "NON_TRANSMIS", message: "Fichier préparé, non transmis : marqué « fichier d'essai », à contrôler avec DSN-VAL puis à déposer sur net-entreprises.fr par vos soins." });
  return { text: Buffer.from(out.join("\n") + "\n", "latin1"), controls, lines: out.length, individuals };
}
