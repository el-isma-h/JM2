/**
 * Générateurs purs des exports de paie : journal, état des charges, récapitulatif par établissement, écritures
 * comptables, virements SEPA (pain.001.001.03). Aucun accès base : les données arrivent déjà déchiffrées et filtrées.
 */
import type { PayslipLine, PayslipTotals } from "../engine/types";

export type FilingSlip = {
  employeeId: string;
  employeeNumber: string | null;
  firstName: string;
  lastName: string;
  establishmentId: string | null;
  establishmentName: string;
  lines: PayslipLine[];
  totals: PayslipTotals;
  hoursWorked: string;
  rgduIrcPartCents: number;
};

const amount = (c: number) => (c / 100).toFixed(2).replace(".", ",");
const csvCell = (v: string | number) => {
  const s = String(v);
  return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
export function toCsv(rows: (string | number)[][]): Buffer {
  return Buffer.from("﻿" + rows.map((r) => r.map(csvCell).join(";")).join("\r\n") + "\r\n", "utf8");
}

// ---------------------------------------------------------------- Journal de paie

export function buildJournal(slips: FilingSlip[]) {
  const head = ["Matricule", "Nom", "Prénom", "Établissement", "Heures", "Brut", "Cotisations salariales", "Net imposable", "Impôt prélevé", "Net payé", "Cotisations patronales", "Allègements", "Coût employeur"];
  const rows = slips.map((s) => [
    s.employeeNumber ?? "",
    s.lastName,
    s.firstName,
    s.establishmentName,
    s.hoursWorked.replace(".", ","),
    amount(s.totals.grossCents),
    amount(s.totals.employeeContribCents),
    amount(s.totals.netTaxableCents),
    amount(s.totals.pasAmountCents),
    amount(s.totals.netPaidCents),
    amount(s.totals.employerContribCents),
    amount(s.totals.employerReliefCents),
    amount(s.totals.employerCostCents),
  ]);
  const sum = (k: keyof PayslipTotals) => slips.reduce((a, s) => a + (s.totals[k] as number), 0);
  rows.push(["", "TOTAL", "", "", "", amount(sum("grossCents")), amount(sum("employeeContribCents")), amount(sum("netTaxableCents")), amount(sum("pasAmountCents")), amount(sum("netPaidCents")), amount(sum("employerContribCents")), amount(sum("employerReliefCents")), amount(sum("employerCostCents"))]);
  return { csv: toCsv([head, ...rows]), totals: { gross: sum("grossCents"), net: sum("netPaidCents"), cost: sum("employerCostCents"), pas: sum("pasAmountCents"), count: slips.length } };
}

// ---------------------------------------------------------------- État des charges par organisme

export const ORGANISM_LABELS: Record<string, string> = {
  urssaf: "URSSAF (sécurité sociale, CSG/CRDS, chômage, AGS, contributions)",
  retraite: "Retraite complémentaire Agirc-Arrco (dont APEC)",
  prevoyance: "Organisme de prévoyance",
  mutuelle: "Organisme de complémentaire santé",
  impots: "DGFiP (prélèvement à la source)",
};

export function buildCharges(slips: FilingSlip[]) {
  type Acc = { base: number; employee: number; employer: number };
  const byOrg = new Map<string, Map<string, Acc & { label: string }>>();
  for (const s of slips) {
    for (const l of s.lines) {
      if (l.kind !== "contribution" && l.kind !== "reduction" && l.code !== "PAS") continue;
      const org = l.organism ?? "autre";
      if (org === "autre") continue;
      const m = byOrg.get(org) ?? new Map();
      const cur = m.get(l.code) ?? { label: l.label, base: 0, employee: 0, employer: 0 };
      cur.base += l.base ?? 0;
      cur.employee += l.amount_employee;
      cur.employer += l.amount_employer;
      m.set(l.code, cur);
      byOrg.set(org, m);
    }
    // Part de la réduction générale imputée sur la retraite complémentaire : transférée de l'URSSAF vers Agirc-Arrco.
    if (s.rgduIrcPartCents) {
      const u = byOrg.get("urssaf")?.get("RGDU");
      if (u) u.employer += s.rgduIrcPartCents;
      const m = byOrg.get("retraite") ?? new Map();
      const cur = m.get("RGDU_IRC") ?? { label: "Réduction générale imputée sur la retraite complémentaire", base: 0, employee: 0, employer: 0 };
      cur.employer -= s.rgduIrcPartCents;
      m.set("RGDU_IRC", cur);
      byOrg.set("retraite", m);
    }
  }
  const rows: (string | number)[][] = [["Organisme", "Cotisation", "Assiette", "Part salariale", "Part patronale", "Total à verser"]];
  const summary: { organism: string; label: string; employee: number; employer: number; total: number }[] = [];
  for (const [org, m] of byOrg) {
    let te = 0;
    let tr = 0;
    for (const [, v] of m) {
      rows.push([ORGANISM_LABELS[org] ?? org, v.label, amount(v.base), amount(v.employee), amount(v.employer), amount(v.employee + v.employer)]);
      te += v.employee;
      tr += v.employer;
    }
    rows.push([ORGANISM_LABELS[org] ?? org, "TOTAL", "", amount(te), amount(tr), amount(te + tr)]);
    summary.push({ organism: org, label: ORGANISM_LABELS[org] ?? org, employee: te, employer: tr, total: te + tr });
  }
  return { csv: toCsv(rows), summary };
}

// ---------------------------------------------------------------- Récapitulatif par établissement

export function buildEstablishmentRecap(slips: FilingSlip[]) {
  const m = new Map<string, { name: string; count: number; gross: number; employee: number; employer: number; net: number; cost: number; pas: number }>();
  for (const s of slips) {
    const k = s.establishmentId ?? "none";
    const cur = m.get(k) ?? { name: s.establishmentName, count: 0, gross: 0, employee: 0, employer: 0, net: 0, cost: 0, pas: 0 };
    cur.count++;
    cur.gross += s.totals.grossCents;
    cur.employee += s.totals.employeeContribCents;
    cur.employer += s.totals.employerContribCents;
    cur.net += s.totals.netPaidCents;
    cur.cost += s.totals.employerCostCents;
    cur.pas += s.totals.pasAmountCents;
    m.set(k, cur);
  }
  const rows: (string | number)[][] = [["Établissement", "Bulletins", "Brut", "Cotisations salariales", "Cotisations patronales", "Impôt prélevé", "Net payé", "Coût employeur"]];
  for (const v of m.values()) rows.push([v.name, v.count, amount(v.gross), amount(v.employee), amount(v.employer), amount(v.pas), amount(v.net), amount(v.cost)]);
  return { csv: toCsv(rows), establishments: [...m.values()] };
}

// ---------------------------------------------------------------- Écritures comptables

/**
 * Plan de comptes (PCG) utilisé :
 *  641100 Salaires et appointements (brut)            débit
 *  645100 Cotisations URSSAF (patronales, nettes des réductions)  débit
 *  645300 Cotisations retraite complémentaire          débit
 *  645800 Cotisations prévoyance et complémentaire santé débit
 *  633300 Participation formation professionnelle continue débit
 *  631200 Taxe d'apprentissage                         débit
 *  625100 Remboursements de frais (indemnités non soumises) débit
 *  431000 Sécurité sociale (URSSAF)                    crédit
 *  437100 Retraite complémentaire                      crédit
 *  437200 Prévoyance                                   crédit
 *  437300 Complémentaire santé                         crédit
 *  442100 Prélèvement à la source                      crédit
 *  425000 Personnel, avances et acomptes               crédit
 *  647500 Titres-restaurant (part salariale récupérée) crédit
 *  791000 Transferts de charges (avantages en nature)  crédit
 *  421000 Personnel, rémunérations dues (net payé)     crédit
 */
export const ACCOUNTS: Record<string, string> = {
  "641100": "Salaires et appointements",
  "645100": "Cotisations URSSAF",
  "645300": "Cotisations retraite complémentaire",
  "645800": "Cotisations prévoyance et santé",
  "633300": "Participation formation professionnelle",
  "631200": "Taxe d'apprentissage",
  "625100": "Remboursements de frais",
  "431000": "Sécurité sociale",
  "437100": "Retraite complémentaire",
  "437200": "Prévoyance",
  "437300": "Complémentaire santé",
  "442100": "Prélèvement à la source",
  "425000": "Avances et acomptes",
  "647500": "Titres-restaurant",
  "791000": "Transferts de charges",
  "421000": "Rémunérations dues",
};

export type Entry = { account: string; label: string; debit: number; credit: number };

export function buildAccountingEntries(slips: FilingSlip[], meta: { journal: string; date: string; label: string }) {
  const acc = new Map<string, { debit: number; credit: number }>();
  const add = (a: string, debit: number, credit: number) => {
    const c = acc.get(a) ?? { debit: 0, credit: 0 };
    c.debit += debit;
    c.credit += credit;
    acc.set(a, c);
  };
  for (const s of slips) {
    add("641100", s.totals.grossCents, 0);
    for (const l of s.lines) {
      if (l.kind === "contribution" || l.kind === "reduction") {
        const er = l.amount_employer;
        const ee = l.amount_employee;
        const expense = l.code === "FORMATION" || l.code === "CPF_CDD" ? "633300" : l.code === "TAXE_APPRENTISSAGE" ? "631200" : l.organism === "retraite" ? "645300" : l.organism === "prevoyance" || l.organism === "mutuelle" ? "645800" : "645100";
        const payable = l.organism === "retraite" ? "437100" : l.organism === "prevoyance" ? "437200" : l.organism === "mutuelle" ? "437300" : "431000";
        add(expense, er, 0);
        add(payable, 0, er + ee);
      } else if (l.code === "INDEMNITE_FRAIS") add("625100", l.amount_employee, 0);
      else if (l.code === "ACOMPTE") add("425000", 0, -l.amount_employee);
      else if (l.code === "TITRES_RESTAURANT") add("647500", 0, -l.amount_employee);
      else if (l.code === "AVANTAGE_NATURE_DEDUCTION") add("791000", 0, -l.amount_employee);
      else if (l.code === "PAS") add("442100", 0, l.amount_employee);
    }
    if (s.rgduIrcPartCents) {
      // La part de réduction imputée sur la retraite complémentaire diminue la dette Agirc-Arrco, pas la dette URSSAF.
      add("431000", 0, s.rgduIrcPartCents);
      add("437100", 0, -s.rgduIrcPartCents);
    }
    add("421000", 0, s.totals.netPaidCents);
  }
  const entries: Entry[] = [...acc.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([account, v]) => {
      const net = v.debit - v.credit;
      return { account, label: ACCOUNTS[account] ?? account, debit: net > 0 ? net : 0, credit: net < 0 ? -net : 0 };
    })
    .filter((e) => e.debit !== 0 || e.credit !== 0);
  const debit = entries.reduce((s, e) => s + e.debit, 0);
  const credit = entries.reduce((s, e) => s + e.credit, 0);
  const rows: (string | number)[][] = [["Journal", "Date", "Compte", "Libellé du compte", "Libellé", "Débit", "Crédit"]];
  for (const e of entries) rows.push([meta.journal, meta.date, e.account, e.label, meta.label, e.debit ? amount(e.debit) : "", e.credit ? amount(e.credit) : ""]);
  return { csv: toCsv(rows), entries, debit, credit, balanced: debit === credit };
}

// ---------------------------------------------------------------- IBAN et SEPA

export function mod97(numeric: string): number {
  let r = 0;
  for (const ch of numeric) r = (r * 10 + (ch.charCodeAt(0) - 48)) % 97;
  return r;
}

/** Contrôle IBAN : format, longueur française (27) et clé ISO 13616 (reste modulo 97 égal à 1). */
export function ibanValid(raw: string): boolean {
  const s = raw.replace(/\s/g, "").toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(s)) return false;
  if (s.startsWith("FR") && s.length !== 27) return false;
  const rearranged = s.slice(4) + s.slice(0, 4);
  const numeric = rearranged.replace(/[A-Z]/g, (c) => String(c.charCodeAt(0) - 55));
  return mod97(numeric) === 1;
}

/** Jeu de caractères SEPA (latin de base) : accents translittérés, caractères interdits retirés. */
export function sepaText(s: string, max = 70): string {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^A-Za-z0-9/\-?:().,'+ ]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
}

const xml = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");

export type SepaPayment = { employeeId: string; name: string; iban: string; bic: string | null; amountCents: number; reference: string };

export function buildSepaXml(input: { messageId: string; createdAt: string; executionDate: string; debtorName: string; debtorIban: string; debtorBic: string | null; label: string; payments: SepaPayment[] }) {
  const payments = input.payments.filter((p) => p.amountCents > 0);
  const total = payments.reduce((s, p) => s + p.amountCents, 0);
  const eur = (c: number) => (c / 100).toFixed(2);
  const tx = payments
    .map(
      (p) => `      <CdtTrfTxInf>
        <PmtId><EndToEndId>${xml(sepaText(p.reference, 35))}</EndToEndId></PmtId>
        <Amt><InstdAmt Ccy="EUR">${eur(p.amountCents)}</InstdAmt></Amt>
${p.bic ? `        <CdtrAgt><FinInstnId><BIC>${xml(p.bic.replace(/\s/g, "").toUpperCase())}</BIC></FinInstnId></CdtrAgt>\n` : ""}        <Cdtr><Nm>${xml(sepaText(p.name))}</Nm></Cdtr>
        <CdtrAcct><Id><IBAN>${p.iban.replace(/\s/g, "").toUpperCase()}</IBAN></Id></CdtrAcct>
        <Purp><Cd>SALA</Cd></Purp>
        <RmtInf><Ustrd>${xml(sepaText(input.label, 140))}</Ustrd></RmtInf>
      </CdtTrfTxInf>`,
    )
    .join("\n");
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <CstmrCdtTrfInitn>
    <GrpHdr>
      <MsgId>${xml(sepaText(input.messageId, 35))}</MsgId>
      <CreDtTm>${input.createdAt}</CreDtTm>
      <NbOfTxs>${payments.length}</NbOfTxs>
      <CtrlSum>${eur(total)}</CtrlSum>
      <InitgPty><Nm>${xml(sepaText(input.debtorName))}</Nm></InitgPty>
    </GrpHdr>
    <PmtInf>
      <PmtInfId>${xml(sepaText(`${input.messageId}-1`, 35))}</PmtInfId>
      <PmtMtd>TRF</PmtMtd>
      <BtchBookg>true</BtchBookg>
      <NbOfTxs>${payments.length}</NbOfTxs>
      <CtrlSum>${eur(total)}</CtrlSum>
      <PmtTpInf><SvcLvl><Cd>SEPA</Cd></SvcLvl><CtgyPurp><Cd>SALA</Cd></CtgyPurp></PmtTpInf>
      <ReqdExctnDt>${input.executionDate}</ReqdExctnDt>
      <Dbtr><Nm>${xml(sepaText(input.debtorName))}</Nm></Dbtr>
      <DbtrAcct><Id><IBAN>${input.debtorIban.replace(/\s/g, "").toUpperCase()}</IBAN></Id></DbtrAcct>
      <DbtrAgt><FinInstnId>${input.debtorBic ? `<BIC>${xml(input.debtorBic.replace(/\s/g, "").toUpperCase())}</BIC>` : "<Othr><Id>NOTPROVIDED</Id></Othr>"}</FinInstnId></DbtrAgt>
      <ChrgBr>SLEV</ChrgBr>
${tx}
    </PmtInf>
  </CstmrCdtTrfInitn>
</Document>
`;
  return { xml: Buffer.from(body, "utf8"), count: payments.length, totalCents: total };
}
