import "server-only";
import PDFDocument from "pdfkit";
import type { EngineCumuls, PayslipLine, PayslipTotals } from "./engine/types";

/**
 * Bulletin de paie PDF (pdfkit, polices standard). Mentions de l'article R. 3243-1 du code du travail et présentation
 * de l'arrêté du 25 février 2016 modifié : rubriques santé, accidents du travail, retraite, famille, assurance chômage,
 * autres contributions dues par l'employeur, CSG, exonérations, net à payer avant impôt, impôt prélevé à la source,
 * net payé, montant net social, cumuls, coût total employeur, mention de conservation sans limitation de durée.
 */

export type PayslipPdfData = {
  company: { name: string; address: string; siret: string | null; ape: string | null; idcc: string | null; collectiveAgreement: string | null; urssaf: string | null };
  employee: {
    name: string;
    address: string;
    jobTitle: string | null;
    classification: string | null;
    category: string;
    hireDate: string | null;
    employeeNumber: string | null;
    contractType: string;
    workTime: string;
  };
  period: { label: string; start: string; end: string; paymentDate: string };
  lines: PayslipLine[];
  totals: PayslipTotals;
  cumulative: EngineCumuls;
  leave: { paidLeaveTakenDays: string; datesText: string | null };
  ruleSetVersion: string;
  computeHash: string;
  isDemo: boolean;
};

const SECTION_LABELS: Record<string, string> = {
  sante: "Santé",
  atmp: "Accidents du travail - maladies professionnelles",
  retraite: "Retraite",
  famille: "Famille",
  chomage: "Assurance chômage",
  autres_contributions: "Autres contributions dues par l'employeur",
  csg: "CSG et CRDS",
  exonerations: "Exonérations, écrêtements et allègements de cotisations",
};
const ORDER = ["sante", "atmp", "retraite", "famille", "chomage", "autres_contributions", "csg", "exonerations"];

const eur = (c: number | null | undefined) => {
  if (c === null || c === undefined) return "";
  const neg = c < 0;
  const a = Math.abs(c);
  const s = `${Math.floor(a / 100)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, " ")},${String(a % 100).padStart(2, "0")}`;
  return neg ? `-${s}` : s;
};
const rate = (r: string | null) => {
  if (!r) return "";
  const [i, f = ""] = r.split(".");
  return `${i},${f.padEnd(2, "0")}`;
};
const d = (iso: string | null) => (iso ? `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}` : "-");

export async function renderPayslipPdf(data: PayslipPdfData): Promise<Buffer> {
  const doc = new PDFDocument({ size: "A4", margin: 36, info: { Title: `Bulletin de paie ${data.period.label} - ${data.employee.name}`, Author: data.company.name } });
  const chunks: Buffer[] = [];
  doc.on("data", (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve) => doc.on("end", () => resolve(Buffer.concat(chunks))));

  const ink = "#1d1c1a";
  const muted = "#6b6760";
  const line = "#d9d5cc";
  const L = 36;
  const W = doc.page.width - 72;

  // En-tête
  doc.fillColor(ink).font("Helvetica-Bold").fontSize(15).text("Bulletin de paie", L, 36);
  doc.font("Helvetica").fontSize(9).fillColor(muted).text(`Période du ${d(data.period.start)} au ${d(data.period.end)} (${data.period.label}) ; paiement le ${d(data.period.paymentDate)}`, L, 56);
  if (data.isDemo) doc.fillColor("#9a5b00").text("Document de démonstration : données fictives, sans valeur légale.", L, 68);

  const top = 88;
  const colW = W / 2 - 8;
  doc.fillColor(ink).font("Helvetica-Bold").fontSize(9.5).text("Employeur", L, top);
  doc.font("Helvetica").fontSize(8.5).fillColor(ink);
  doc.text(
    [
      data.company.name,
      data.company.address,
      `SIRET : ${data.company.siret ?? "à compléter"}   Code APE : ${data.company.ape ?? "à compléter"}`,
      data.company.urssaf ? `Cotisations versées à : ${data.company.urssaf}` : "Cotisations versées à l'URSSAF",
      `Convention collective : ${data.company.collectiveAgreement ? `${data.company.collectiveAgreement}${data.company.idcc ? ` (IDCC ${data.company.idcc})` : ""}` : "aucune déclarée"}`,
    ].join("\n"),
    L,
    top + 13,
    { width: colW, lineGap: 1.5 },
  );
  const rx = L + W / 2 + 8;
  doc.font("Helvetica-Bold").fontSize(9.5).text("Salarié", rx, top);
  doc.font("Helvetica").fontSize(8.5);
  doc.text(
    [
      data.employee.name,
      data.employee.address,
      `Emploi : ${data.employee.jobTitle ?? "-"}`,
      `Classification : ${data.employee.classification ?? "-"} ; statut ${data.employee.category}`,
      `Contrat : ${data.employee.contractType} ; ${data.employee.workTime}`,
      `Entrée le ${d(data.employee.hireDate)}${data.employee.employeeNumber ? ` ; matricule ${data.employee.employeeNumber}` : ""}`,
    ].join("\n"),
    rx,
    top + 13,
    { width: colW, lineGap: 1.5 },
  );

  // Tableau
  const cols = { label: L, base: L + 225, rs: L + 290, as: L + 340, rr: L + 400, ar: L + 455 };
  // Tronque un libellé à la largeur de colonne (une ligne par rubrique, jamais de chevauchement).
  const fit = (text: string, width: number) => {
    if (doc.widthOfString(text) <= width) return text;
    let t = text;
    while (t.length > 4 && doc.widthOfString(`${t}...`) > width) t = t.slice(0, -1);
    return `${t.trimEnd()}...`;
  };
  const right = (text: string, x: number, y: number, w: number) => doc.text(text, x, y, { width: w, align: "right" });
  let y = 178;
  const header = () => {
    doc.rect(L, y, W, 16).fill("#efece5");
    doc.fillColor(ink).font("Helvetica-Bold").fontSize(7.5);
    doc.text("Éléments de paie", cols.label + 4, y + 5);
    right("Base", cols.base, y + 5, 60);
    right("Taux sal.", cols.rs, y + 5, 45);
    right("Part salarié", cols.as, y + 5, 55);
    right("Taux pat.", cols.rr, y + 5, 50);
    right("Part employeur", cols.ar, y + 5, W - (cols.ar - L) - 4);
    y += 19;
  };
  const ensure = (h: number, withHeader = true) => {
    if (y + h > doc.page.height - 100) {
      doc.addPage();
      y = 36;
      if (withHeader) header();
    }
  };
  const row = (l: { label: string; base?: string; rs?: string; as?: string; rr?: string; ar?: string }, bold = false) => {
    ensure(12);
    doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(7.8).fillColor(ink);
    doc.text(fit(l.label, 218), cols.label + 4, y, { lineBreak: false });
    if (l.base) right(l.base, cols.base, y, 60);
    if (l.rs) right(l.rs, cols.rs, y, 45);
    if (l.as) right(l.as, cols.as, y, 55);
    if (l.rr) right(l.rr, cols.rr, y, 50);
    if (l.ar) right(l.ar, cols.ar, y, W - (cols.ar - L) - 4);
    y += 10.2;
  };
  const rule = () => {
    doc.moveTo(L, y + 1).lineTo(L + W, y + 1).strokeColor(line).lineWidth(0.6).stroke();
    y += 5;
  };
  header();

  for (const l of data.lines.filter((x) => x.section === "brut")) {
    row({ label: l.label, base: l.quantity ? rate(l.quantity) : "", rs: l.rate_employee ? rate(l.rate_employee) : "", as: eur(l.amount_employee) });
  }
  row({ label: "Salaire brut", as: eur(data.totals.grossCents) }, true);
  rule();

  for (const s of ORDER) {
    const ls = data.lines.filter((x) => x.section === s);
    if (!ls.length) continue;
    ensure(24);
    doc.font("Helvetica-Bold").fontSize(7.8).fillColor(muted).text(SECTION_LABELS[s], cols.label + 4, y);
    y += 11;
    for (const l of ls) {
      row({
        label: `   ${l.label}`,
        base: l.base !== null ? eur(l.base) : "",
        rs: rate(l.rate_employee),
        as: l.amount_employee ? eur(-l.amount_employee) : "",
        rr: rate(l.rate_employer),
        ar: l.amount_employer ? eur(l.amount_employer) : "",
      });
    }
  }
  rule();
  row({ label: "Total des cotisations et contributions", as: eur(-data.totals.employeeContribCents), ar: eur(data.totals.employerContribCents) }, true);
  rule();

  for (const l of data.lines.filter((x) => x.section === "net")) row({ label: l.label, as: eur(l.amount_employee) });
  row({ label: "Net à payer avant impôt sur le revenu", as: eur(data.totals.netBeforeTaxCents) }, true);
  rule();
  const pasLine = data.lines.find((l) => l.code === "PAS");
  row({ label: "Montant net imposable", as: eur(data.totals.netTaxableCents) });
  row({
    label: `Impôt sur le revenu prélevé à la source (taux ${data.totals.pasKind === "neutre" ? "non personnalisé" : "personnalisé"})`,
    base: eur(data.totals.pasBaseCents),
    rs: rate(data.totals.pasRate),
    as: eur(-(pasLine?.amount_employee ?? data.totals.pasAmountCents)),
  });
  ensure(30);
  doc.rect(L, y, W, 18).fill("#e4efe9");
  doc.fillColor(ink).font("Helvetica-Bold").fontSize(10).text("Net payé", cols.label + 4, y + 5);
  right(`${eur(data.totals.netPaidCents)} €`, cols.ar - 60, y + 5, W - (cols.ar - L) + 56);
  y += 24;
  doc.font("Helvetica").fontSize(7.8);
  row({ label: "Montant net social", as: eur(data.totals.netSocialCents) });
  row({ label: "Allègements de cotisations patronales du mois", ar: eur(data.totals.employerReliefCents) });
  row({ label: "Coût total pour l'employeur (brut + cotisations patronales)", ar: eur(data.totals.employerCostCents) }, true);
  rule();

  // Cumuls et congés
  ensure(46, false);
  doc.font("Helvetica-Bold").fontSize(7.8).fillColor(muted).text(`Cumuls de l'année ${data.cumulative.year}`, L + 4, y);
  y += 11;
  const cw = W / 5;
  const cum = [
    ["Brut", eur(data.cumulative.grossCents)],
    ["Net imposable", eur(data.cumulative.netTaxableCents)],
    ["Impôt prélevé", eur(data.cumulative.pasCents)],
    ["Net payé", eur(data.cumulative.netPaidCents)],
    ["Heures", rate(data.cumulative.hours)],
  ];
  cum.forEach(([k, v], i) => {
    doc.font("Helvetica").fontSize(7.2).fillColor(muted).text(k, L + 4 + i * cw, y, { width: cw - 8 });
    doc.font("Helvetica-Bold").fontSize(8.2).fillColor(ink).text(v, L + 4 + i * cw, y + 9, { width: cw - 8 });
  });
  y += 26;
  doc.font("Helvetica").fontSize(7.8).fillColor(ink).text(
    `Congés payés pris sur la période : ${data.leave.paidLeaveTakenDays.replace(".", ",")} jour(s)${data.leave.datesText ? ` (${data.leave.datesText})` : ""}, indemnisés par maintien du salaire.`,
    L + 4,
    y,
    { width: W - 8 },
  );
  y += 18;

  // Pied de page obligatoire
  const fy = doc.page.height - 92;
  doc.moveTo(L, fy).lineTo(L + W, fy).strokeColor(line).lineWidth(0.6).stroke();
  doc.font("Helvetica-Bold").fontSize(8).fillColor(ink).text("Dans votre intérêt et pour vous aider à faire valoir vos droits, conservez ce bulletin de paie sans limitation de durée.", L, fy + 6, { width: W });
  doc.font("Helvetica").fontSize(7).fillColor(muted).text(
    `Rubrique dédiée au bulletin de paie sur le portail www.service-public.fr. Calcul Next RH, règles ${data.ruleSetVersion}, empreinte de calcul ${data.computeHash.slice(0, 16)}. Le paiement des cotisations et la date de versement figurent ci-dessus ; toute réclamation est à adresser à l'employeur.`,
    L,
    fy + 20,
    { width: W, lineGap: 1 },
  );

  doc.end();
  return done;
}
