import "server-only";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { listRuleSets, ruleSetChecksum, ruleSetSources } from "./rules";

/** Upsert des jeux de règles versionnés dans `payroll_rule_sets` (idempotent : rien n'est réécrit si le checksum est identique). */
export async function syncRuleSets(): Promise<{ version: string; action: "inserted" | "updated" | "unchanged"; checksum: string }[]> {
  const out: { version: string; action: "inserted" | "updated" | "unchanged"; checksum: string }[] = [];
  for (const rs of listRuleSets()) {
    const checksum = ruleSetChecksum(rs);
    const [existing] = await db.select().from(schema.payrollRuleSets).where(eq(schema.payrollRuleSets.version, rs.version)).limit(1);
    const values = {
      version: rs.version,
      effectiveFrom: rs.effectiveFrom,
      effectiveTo: rs.effectiveTo,
      rules: rs,
      sources: ruleSetSources(rs),
      checksum,
    };
    if (!existing) {
      await db.insert(schema.payrollRuleSets).values(values);
      out.push({ version: rs.version, action: "inserted", checksum });
    } else if (existing.checksum !== checksum) {
      await db.update(schema.payrollRuleSets).set({ ...values, publishedAt: new Date() }).where(eq(schema.payrollRuleSets.id, existing.id));
      out.push({ version: rs.version, action: "updated", checksum });
    } else {
      out.push({ version: rs.version, action: "unchanged", checksum });
    }
  }
  return out;
}
