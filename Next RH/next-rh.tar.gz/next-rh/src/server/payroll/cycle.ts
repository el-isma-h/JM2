import "server-only";
import { createHash } from "node:crypto";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { createDocument } from "@/server/documents/store";
import { layoutMail, sendMail } from "@/server/mail";
import { appUrl } from "@/lib/env";
import { monthLabel } from "@/lib/dates";
import { computePayslip } from "./engine/compute";
import { loadRuleSet } from "./rules";
import type { EngineAnomaly, PayslipLine, PayslipResult, PayslipTotals } from "./engine/types";
import { buildPayslipInput, EDITABLE_STATUSES, employeesInScope, hasPrimaryBankAccount, paymentDateFor, periodBounds } from "./inputs";
import { computeVariance } from "./variance";
import { renderPayslipPdf } from "./pdf";

/**
 * Cycle mensuel de paie. Statuts dans l'ordre :
 * open -> collecting -> checking -> computed -> controlled -> validated -> finalized -> exported -> distributed -> closed.
 * Chaque transition est journalisée (audit). Les fonctions sont idempotentes : rappeler une étape déjà franchie ne crée
 * aucun doublon (contraintes uniques sur période, bulletin, variable).
 */

export class PayrollError extends Error {}

export const PERIOD_STATUSES = ["open", "collecting", "checking", "computed", "controlled", "validated", "finalized", "exported", "distributed", "closed"] as const;
export type PeriodStatus = (typeof PERIOD_STATUSES)[number];
export const statusIndex = (s: string) => PERIOD_STATUSES.indexOf(s as PeriodStatus);

/** Durée de conservation : l'employeur garantit la disponibilité du bulletin électronique pendant 50 ans ou jusqu'aux 75 ans du salarié (art. D. 3243-8 du code du travail). */
export const PAYSLIP_RETENTION_YEARS = 50;

const ORIGIN = "payroll";

async function loadPeriod(periodId: string) {
  const [period] = await db.select().from(schema.payrollPeriods).where(eq(schema.payrollPeriods.id, periodId)).limit(1);
  if (!period) throw new PayrollError("Période de paie introuvable.");
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, period.companyId)).limit(1);
  if (!company) throw new PayrollError("Entreprise introuvable.");
  return { period, company };
}

async function transition(periodId: string, companyId: string, from: string, to: PeriodStatus, userId: string, extra: Partial<typeof schema.payrollPeriods.$inferInsert> = {}, after: Record<string, unknown> = {}) {
  await db.update(schema.payrollPeriods).set({ status: to, ...extra }).where(eq(schema.payrollPeriods.id, periodId));
  await audit({ action: `payroll.${to === "collecting" ? "collect" : to === "checking" ? "check" : to === "computed" ? "compute" : to === "controlled" ? "control" : to === "validated" ? "validate" : to === "finalized" ? "finalize" : to === "exported" ? "export" : to === "distributed" ? "distribute" : to === "closed" ? "close" : "open"}`, userId, companyId, entityType: "payroll_period", entityId: periodId, before: { status: from }, after: { status: to, ...after } });
}

function requireEditable(status: string) {
  if (!EDITABLE_STATUSES.has(status)) throw new PayrollError("La période est validée : elle ne peut plus être modifiée. Les corrections passent par une régularisation sur le mois suivant.");
}

// ---------------------------------------------------------------- 1. Ouvrir

export async function openPeriod(companyId: string, year: number, month: number, userId: string): Promise<{ periodId: string }> {
  if (!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12 || year < 2000 || year > 2100) throw new PayrollError("Mois de paie invalide.");
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, companyId)).limit(1);
  if (!company) throw new PayrollError("Entreprise introuvable.");
  const { end } = periodBounds({ year, month });
  const inserted = await db
    .insert(schema.payrollPeriods)
    .values({ companyId, year, month, status: "open", paymentDate: paymentDateFor(company, year, month), ruleSetVersion: loadRuleSet(end)?.version ?? null })
    .onConflictDoNothing()
    .returning({ id: schema.payrollPeriods.id });
  if (inserted[0]) {
    await audit({ action: "payroll.open", userId, companyId, entityType: "payroll_period", entityId: inserted[0].id, after: { year, month } });
    return { periodId: inserted[0].id };
  }
  const [p] = await db
    .select({ id: schema.payrollPeriods.id, paymentDate: schema.payrollPeriods.paymentDate, status: schema.payrollPeriods.status })
    .from(schema.payrollPeriods)
    .where(and(eq(schema.payrollPeriods.companyId, companyId), eq(schema.payrollPeriods.year, year), eq(schema.payrollPeriods.month, month)))
    .limit(1);
  // Période créée par un autre module (variable poussée en avance) : compléter la date de paiement et la version de règles.
  if (p && !p.paymentDate && EDITABLE_STATUSES.has(p.status)) {
    await db.update(schema.payrollPeriods).set({ paymentDate: paymentDateFor(company, year, month), ruleSetVersion: loadRuleSet(end)?.version ?? null }).where(eq(schema.payrollPeriods.id, p.id));
  }
  return { periodId: p.id };
}

// ---------------------------------------------------------------- 2. Collecter

export type CollectItem = { employeeId: string | null; name: string; code: string; severity: "blocking" | "warning" | "info"; message: string };
export type CollectSummary = {
  at: string;
  employees: number;
  variables: { total: number; bySource: Record<string, number>; drafts: number };
  pending: { leaves: number; timesheets: number; expenses: number };
  items: CollectItem[];
};

export async function collectVariables(periodId: string, userId: string): Promise<CollectSummary> {
  const { period, company } = await loadPeriod(periodId);
  requireEditable(period.status);
  const { start, end } = periodBounds(period);
  const { included, suspended } = await employeesInScope(company.id, period);
  const ids = included.map((e) => e.id);
  const items: CollectItem[] = [];
  const name = (e: { firstName: string; lastName: string }) => `${e.firstName} ${e.lastName}`;

  const vars = await db.select().from(schema.payrollVariables).where(eq(schema.payrollVariables.periodId, periodId));
  const bySource: Record<string, number> = {};
  for (const v of vars) {
    const k = v.source.split(":")[0];
    bySource[k] = (bySource[k] ?? 0) + 1;
  }
  const drafts = vars.filter((v) => v.status === "draft").length;

  if (ids.length) {
    const contracts = await db.select({ e: schema.contracts.employeeId, start: schema.contracts.startDate, end: schema.contracts.endDate }).from(schema.contracts).where(inArray(schema.contracts.employeeId, ids));
    const comps = await db.select({ e: schema.compensations.employeeId, eff: schema.compensations.effectiveDate, end: schema.compensations.endDate }).from(schema.compensations).where(inArray(schema.compensations.employeeId, ids));
    const pas = await db.select({ e: schema.pasRates.employeeId, d: schema.pasRates.effectiveDate, n: schema.pasRates.isNeutral }).from(schema.pasRates).where(inArray(schema.pasRates.employeeId, ids));
    const banks = await hasPrimaryBankAccount(ids);
    for (const e of included) {
      if (!contracts.some((c) => c.e === e.id && c.start <= end && (!c.end || c.end >= start))) items.push({ employeeId: e.id, name: name(e), code: "CONTRAT_MANQUANT", severity: "blocking", message: "Aucun contrat ne couvre la période." });
      if (!comps.some((c) => c.e === e.id && c.eff <= end && (!c.end || c.end >= start))) items.push({ employeeId: e.id, name: name(e), code: "REMUNERATION_MANQUANTE", severity: "blocking", message: "Aucune rémunération en vigueur." });
      if (!pas.some((p) => p.e === e.id && p.d <= end && !p.n)) items.push({ employeeId: e.id, name: name(e), code: "PAS_ABSENT", severity: "info", message: "Pas de taux d'impôt personnalisé : le barème neutre sera appliqué." });
      if (!banks.has(e.id)) items.push({ employeeId: e.id, name: name(e), code: "RIB_MANQUANT", severity: "warning", message: "Coordonnées bancaires absentes : le salarié ne figurera pas dans le fichier de virement." });
      if (!e.nirEnc) items.push({ employeeId: e.id, name: name(e), code: "NIR_MANQUANT", severity: "warning", message: "Numéro de sécurité sociale absent : nécessaire pour la DSN." });
    }
  }
  for (const e of suspended) items.push({ employeeId: e.id, name: name(e), code: "SALARIE_SUSPENDU", severity: "warning", message: "Contrat suspendu : aucun bulletin ne sera calculé ce mois." });

  // Sources des autres modules : éléments en attente de validation sur le mois.
  const leaves = ids.length
    ? await db
        .select({ n: sql<number>`count(*)::int` })
        .from(schema.leaveRequests)
        .where(and(inArray(schema.leaveRequests.employeeId, ids), eq(schema.leaveRequests.status, "pending"), sql`${schema.leaveRequests.startDate} <= ${end} and ${schema.leaveRequests.endDate} >= ${start}`))
    : [{ n: 0 }];
  const sheets = ids.length
    ? await db
        .select({ n: sql<number>`count(*)::int` })
        .from(schema.timesheets)
        .where(and(inArray(schema.timesheets.employeeId, ids), eq(schema.timesheets.year, period.year), eq(schema.timesheets.month, period.month), inArray(schema.timesheets.status, ["draft", "pending"])))
    : [{ n: 0 }];
  const expenses = ids.length
    ? await db
        .select({ n: sql<number>`count(*)::int` })
        .from(schema.expenseReports)
        .where(and(inArray(schema.expenseReports.employeeId, ids), eq(schema.expenseReports.status, "pending")))
    : [{ n: 0 }];
  const pending = { leaves: leaves[0]?.n ?? 0, timesheets: sheets[0]?.n ?? 0, expenses: expenses[0]?.n ?? 0 };
  if (pending.leaves) items.push({ employeeId: null, name: "Congés", code: "CONGES_EN_ATTENTE", severity: "warning", message: `${pending.leaves} demande(s) de congé sur le mois attendent une décision : elles ne sont pas prises en compte.` });
  if (pending.timesheets) items.push({ employeeId: null, name: "Temps", code: "TEMPS_EN_ATTENTE", severity: "warning", message: `${pending.timesheets} feuille(s) de temps du mois ne sont pas validées : les heures supplémentaires correspondantes manquent.` });
  if (pending.expenses) items.push({ employeeId: null, name: "Frais", code: "FRAIS_EN_ATTENTE", severity: "info", message: `${pending.expenses} note(s) de frais attendent une décision.` });
  if (drafts) items.push({ employeeId: null, name: "Variables", code: "VARIABLES_BROUILLON", severity: "warning", message: `${drafts} variable(s) en brouillon ne seront pas prises en compte.` });

  const summary: CollectSummary = { at: new Date().toISOString(), employees: included.length, variables: { total: vars.length, bySource, drafts }, pending, items };
  const prevSummary = (period.summary ?? {}) as Record<string, unknown>;
  const nextStatus: PeriodStatus = statusIndex(period.status) < statusIndex("collecting") ? "collecting" : (period.status as PeriodStatus);
  await db.update(schema.payrollPeriods).set({ summary: { ...prevSummary, collect: summary } }).where(eq(schema.payrollPeriods.id, periodId));
  await transition(periodId, company.id, period.status, nextStatus, userId, {}, { employees: summary.employees, variables: summary.variables.total, items: items.length });
  return summary;
}

// ---------------------------------------------------------------- 3. Vérifier

export async function checkPeriod(periodId: string, userId: string) {
  const { period, company } = await loadPeriod(periodId);
  requireEditable(period.status);
  const summary = (period.summary ?? {}) as { collect?: CollectSummary };
  if (!summary.collect) throw new PayrollError("Collectez d'abord les variables du mois.");
  const next: PeriodStatus = statusIndex(period.status) < statusIndex("checking") ? "checking" : (period.status as PeriodStatus);
  await transition(periodId, company.id, period.status, next, userId, {}, { reviewed: summary.collect.items.length });
}

// ---------------------------------------------------------------- 4. Calculer

type BuiltSlip = {
  employee: typeof schema.employees.$inferSelect;
  contractId: string | null;
  input: Awaited<ReturnType<typeof buildPayslipInput>>["input"];
  result: PayslipResult;
  draftVariables: number;
};

async function computeAll(period: typeof schema.payrollPeriods.$inferSelect, company: typeof schema.companies.$inferSelect) {
  const { included, suspended } = await employeesInScope(company.id, period);
  const slips: BuiltSlip[] = [];
  for (const e of included) {
    const { input, draftVariables, contractId } = await buildPayslipInput(period, company, e);
    slips.push({ employee: e, contractId, input, result: computePayslip(input), draftVariables });
  }
  return { slips, suspended };
}

function digest(hashes: string[]) {
  return createHash("sha256").update([...hashes].sort().join("|")).digest("hex");
}

const fmt = (c: number) => `${(c / 100).toFixed(2).replace(".", ",")} €`;

export async function computePeriod(periodId: string, userId: string): Promise<{ computed: number; blocked: number; anomalies: number }> {
  const { period, company } = await loadPeriod(periodId);
  requireEditable(period.status);
  if (statusIndex(period.status) < statusIndex("checking")) {
    throw new PayrollError("Collectez et vérifiez les variables avant de calculer.");
  }
  const { slips, suspended } = await computeAll(period, company);
  const banks = await hasPrimaryBankAccount(slips.map((s) => s.employee.id));

  // Bulletins du mois précédent pour l'analyse des écarts.
  const prevYm = period.month === 1 ? { year: period.year - 1, month: 12 } : { year: period.year, month: period.month - 1 };
  const [prevPeriod] = await db
    .select()
    .from(schema.payrollPeriods)
    .where(and(eq(schema.payrollPeriods.companyId, company.id), eq(schema.payrollPeriods.year, prevYm.year), eq(schema.payrollPeriods.month, prevYm.month)))
    .limit(1);
  const prevSlips = prevPeriod ? await db.select().from(schema.payslips).where(eq(schema.payslips.periodId, prevPeriod.id)) : [];

  type NewAnomaly = EngineAnomaly & { employeeId: string | null };
  const anomalies: NewAnomaly[] = [];
  if (company.idcc || company.collectiveAgreement) {
    anomalies.push({
      employeeId: null,
      code: "CONVENTION_COLLECTIVE",
      severity: "warning",
      title: "Convention collective : dispositions à contrôler",
      explanation: `L'entreprise relève de la convention ${company.collectiveAgreement ?? ""}${company.idcc ? ` (IDCC ${company.idcc})` : ""}. Le moteur applique le code du travail et le régime général : il n'applique pas automatiquement les minima, primes, majorations ou garanties conventionnels. Vérifiez-les avant de valider.`,
    });
  }
  if (prevPeriod && statusIndex(prevPeriod.status) < statusIndex("validated")) {
    anomalies.push({ employeeId: null, code: "MOIS_PRECEDENT_NON_VALIDE", severity: "warning", title: "Mois précédent non validé", explanation: `La paie de ${monthLabel(prevYm.year, prevYm.month)} n'est pas validée : les cumuls de l'année utilisés ici pourront changer.` });
  }
  for (const e of suspended) {
    anomalies.push({ employeeId: e.id, code: "SALARIE_SUSPENDU", severity: "warning", title: "Contrat suspendu : pas de bulletin", explanation: `${e.firstName} ${e.lastName} a un contrat suspendu : aucun bulletin n'est calculé. Si une rémunération est due, réactivez le salarié.` });
  }

  const rows = slips.map((s) => {
    const prev = prevSlips.find((p) => p.employeeId === s.employee.id && p.status !== "blocked");
    const variance = computeVariance(
      { lines: s.result.lines, totals: s.result.totals, label: monthLabel(period.year, period.month) },
      prev ? { lines: prev.lines as PayslipLine[], totals: { grossCents: prev.grossCents, netPaidCents: prev.netPaidCents, employerCostCents: prev.employerCostCents, pasRate: String(prev.pasRate) }, label: monthLabel(prevYm.year, prevYm.month) } : null,
    );
    const name = `${s.employee.firstName} ${s.employee.lastName}`;
    for (const a of s.result.anomalies) anomalies.push({ ...a, employeeId: s.employee.id });
    if (s.result.status === "computed") {
      if (variance.hasPrevious && variance.grossDeltaPct !== null && Math.abs(variance.grossDeltaPct) > 10) {
        anomalies.push({
          employeeId: s.employee.id,
          code: "ECART_M1",
          severity: "warning",
          title: `Écart de ${variance.grossDeltaPct > 0 ? "+" : ""}${String(variance.grossDeltaPct).replace(".", ",")} % du brut par rapport au mois précédent`,
          explanation: `Le brut de ${name} passe de ${fmt(s.result.totals.grossCents - variance.grossDeltaCents)} à ${fmt(s.result.totals.grossCents)}. ${variance.explanations.join(" ")}`,
          details: { variance },
        });
      }
      if (!banks.has(s.employee.id)) {
        anomalies.push({ employeeId: s.employee.id, code: "RIB_MANQUANT", severity: "warning", title: "Coordonnées bancaires manquantes", explanation: `${name} n'a pas de RIB : son salaire ne figurera pas dans le fichier de virement et devra être payé autrement.` });
      }
    }
    if (s.draftVariables) {
      anomalies.push({ employeeId: s.employee.id, code: "VARIABLES_BROUILLON", severity: "warning", title: "Variables en brouillon ignorées", explanation: `${s.draftVariables} variable(s) de ${name} sont en brouillon et ne sont pas prises en compte.` });
    }
    const t: PayslipTotals = s.result.totals;
    return {
      periodId,
      employeeId: s.employee.id,
      contractId: s.contractId,
      status: s.result.status,
      ruleSetVersion: s.result.ruleSetVersion,
      inputs: s.input,
      lines: s.result.lines,
      grossCents: t.grossCents,
      employeeContribCents: t.employeeContribCents,
      employerContribCents: t.employerContribCents,
      netTaxableCents: t.netTaxableCents,
      netBeforeTaxCents: t.netBeforeTaxCents,
      pasRate: t.pasRate,
      pasAmountCents: t.pasAmountCents,
      netPaidCents: t.netPaidCents,
      employerCostCents: t.employerCostCents,
      hoursWorked: t.hoursWorked,
      cumulative: { ...s.result.cumulative, totals: t, details: s.result.details, pasRuleSetVersion: s.result.pasRuleSetVersion },
      variance,
      anomalies: s.result.anomalies,
      blockingReason: s.result.blockingReason,
      computeHash: s.result.computeHash,
      documentId: null,
    };
  });

  const key = (a: { code: string; employeeId: string | null; details?: unknown }) => `${a.code}|${a.employeeId ?? ""}|${(a.details as { variableId?: string } | undefined)?.variableId ?? ""}`;

  await db.transaction(async (tx) => {
    const keepIds = rows.map((r) => r.employeeId);
    const existing = await tx.select({ id: schema.payslips.id, employeeId: schema.payslips.employeeId }).from(schema.payslips).where(eq(schema.payslips.periodId, periodId));
    const stale = existing.filter((x) => !keepIds.includes(x.employeeId)).map((x) => x.id);
    if (stale.length) await tx.delete(schema.payslips).where(inArray(schema.payslips.id, stale));
    for (const r of rows) {
      await tx
        .insert(schema.payslips)
        .values(r)
        .onConflictDoUpdate({ target: [schema.payslips.periodId, schema.payslips.employeeId], set: { ...r, distributedAt: null } });
    }
    // Anomalies : on remplace les nôtres, en conservant les décisions déjà prises (prise en compte, ignorée).
    const old = await tx.select().from(schema.payrollAnomalies).where(and(eq(schema.payrollAnomalies.periodId, periodId), sql`${schema.payrollAnomalies.details}->>'origin' = ${ORIGIN}`));
    const decisions = new Map(old.filter((a) => a.status !== "open").map((a) => [key({ code: a.code, employeeId: a.employeeId, details: a.details }), a]));
    if (old.length) await tx.delete(schema.payrollAnomalies).where(inArray(schema.payrollAnomalies.id, old.map((a) => a.id)));
    if (anomalies.length) {
      await tx.insert(schema.payrollAnomalies).values(
        anomalies.map((a) => {
          const prev = a.severity === "blocking" ? undefined : decisions.get(key(a));
          return {
            periodId,
            employeeId: a.employeeId,
            code: a.code,
            severity: a.severity,
            status: prev?.status ?? "open",
            title: a.title,
            explanation: a.explanation,
            details: { ...(a.details ?? {}), origin: ORIGIN },
            resolvedBy: prev?.resolvedBy ?? null,
            resolvedAt: prev?.resolvedAt ?? null,
          };
        }),
      );
    }
  });

  const computed = rows.filter((r) => r.status === "computed").length;
  const blocked = rows.length - computed;
  const openCount = await countOpenAnomalies(periodId);
  const totals = rows.reduce(
    (s, r) => ({ gross: s.gross + r.grossCents, net: s.net + r.netPaidCents, cost: s.cost + r.employerCostCents, pas: s.pas + r.pasAmountCents }),
    { gross: 0, net: 0, cost: 0, pas: 0 },
  );
  const prevSummary = (period.summary ?? {}) as Record<string, unknown>;
  const now = new Date();
  await db
    .update(schema.payrollPeriods)
    .set({
      computedAt: now,
      ruleSetVersion: rows[0]?.ruleSetVersion ?? loadRuleSet(periodBounds(period).end)?.version ?? null,
      summary: { ...prevSummary, compute: { at: now.toISOString(), payslips: rows.length, computed, blocked, totals, inputsDigest: digest(rows.map((r) => r.computeHash)) } },
    })
    .where(eq(schema.payrollPeriods.id, periodId));
  await transition(periodId, company.id, period.status, "computed", userId, {}, { computed, blocked, anomalies: openCount });
  return { computed, blocked, anomalies: openCount };
}

async function countOpenAnomalies(periodId: string, severity?: "blocking" | "warning" | "info") {
  const [r] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.payrollAnomalies)
    .where(and(eq(schema.payrollAnomalies.periodId, periodId), eq(schema.payrollAnomalies.status, "open"), severity ? eq(schema.payrollAnomalies.severity, severity) : sql`true`));
  return r?.n ?? 0;
}

/** Vérifie que les entrées n'ont pas changé depuis le calcul (variables, contrats, salaires, paramètres). */
export async function isPeriodFresh(periodId: string): Promise<boolean> {
  const { period, company } = await loadPeriod(periodId);
  const stored = (period.summary as { compute?: { inputsDigest?: string } })?.compute?.inputsDigest;
  if (!stored) return false;
  const { slips } = await computeAll(period, company);
  return digest(slips.map((s) => s.result.computeHash)) === stored;
}

// ---------------------------------------------------------------- 5. Contrôler

export async function controlPeriod(periodId: string, userId: string) {
  const { period, company } = await loadPeriod(periodId);
  if (period.status !== "computed" && period.status !== "controlled") throw new PayrollError("Calculez la paie avant de la contrôler.");
  if (!(await isPeriodFresh(periodId))) throw new PayrollError("Des données ont changé depuis le calcul (variables, contrat, salaire ou paramètres) : relancez le calcul.");
  const blocking = await countOpenAnomalies(periodId, "blocking");
  if (blocking) throw new PayrollError(`${blocking} anomalie(s) bloquante(s) restent ouvertes : corrigez les données puis relancez le calcul.`);
  const warnings = await countOpenAnomalies(periodId, "warning");
  if (warnings) throw new PayrollError(`${warnings} point(s) à vérifier restent ouverts : prenez-les en compte un par un.`);
  if (period.status === "controlled") return;
  await db.update(schema.payslips).set({ status: "controlled" }).where(and(eq(schema.payslips.periodId, periodId), eq(schema.payslips.status, "computed")));
  await transition(periodId, company.id, period.status, "controlled", userId);
}

// ---------------------------------------------------------------- 6. Valider

export async function validatePeriod(periodId: string, userId: string) {
  const { period, company } = await loadPeriod(periodId);
  if (period.status === "validated") return;
  if (period.status !== "controlled") throw new PayrollError("La paie doit être contrôlée avant d'être validée.");
  const blocking = await countOpenAnomalies(periodId, "blocking");
  if (blocking) throw new PayrollError(`Validation refusée : ${blocking} anomalie(s) bloquante(s) ouverte(s).`);
  if (!(await isPeriodFresh(periodId))) throw new PayrollError("Des données ont changé depuis le calcul : relancez le calcul et le contrôle.");
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.payslips).where(and(eq(schema.payslips.periodId, periodId), eq(schema.payslips.status, "blocked")));
  if (n) throw new PayrollError(`Validation refusée : ${n} bulletin(s) bloqué(s).`);
  await db.update(schema.payslips).set({ status: "validated" }).where(eq(schema.payslips.periodId, periodId));
  await transition(periodId, company.id, period.status, "validated", userId, { validatedAt: new Date(), validatedBy: userId });
}

// ---------------------------------------------------------------- 7. Finaliser (PDF)

export async function finalizePeriod(periodId: string, userId: string): Promise<{ documents: number }> {
  const { period, company } = await loadPeriod(periodId);
  if (statusIndex(period.status) < statusIndex("validated")) throw new PayrollError("Validez la paie avant de générer les bulletins.");
  const slips = await db.select().from(schema.payslips).where(eq(schema.payslips.periodId, periodId));
  const [est] = await db.select().from(schema.establishments).where(and(eq(schema.establishments.companyId, company.id), eq(schema.establishments.isHeadOffice, true))).limit(1);
  const [urssaf] = await db.select().from(schema.companyOrganisms).where(and(eq(schema.companyOrganisms.companyId, company.id), eq(schema.companyOrganisms.kind, "urssaf"))).limit(1);
  const label = monthLabel(period.year, period.month);
  const { start, end } = periodBounds(period);
  let created = 0;
  for (const s of slips) {
    if (s.documentId) continue;
    const [e] = await db.select().from(schema.employees).where(and(eq(schema.employees.id, s.employeeId), eq(schema.employees.companyId, company.id))).limit(1);
    if (!e) continue;
    const [c] = s.contractId ? await db.select().from(schema.contracts).where(eq(schema.contracts.id, s.contractId)).limit(1) : [];
    const leaves = (s.lines as PayslipLine[]).filter((l) => l.code === "ABSENCE_CP");
    const cum = s.cumulative as PayslipResult["cumulative"] & { totals: PayslipTotals; details: PayslipResult["details"] };
    const pdf = await renderPayslipPdf({
      company: {
        name: company.legalName,
        address: [company.addressLine1, company.addressLine2, [company.postalCode, company.city].filter(Boolean).join(" ")].filter(Boolean).join(", "),
        siret: est?.siret ?? null,
        ape: company.apeCode,
        idcc: company.idcc,
        collectiveAgreement: company.collectiveAgreement,
        urssaf: urssaf?.name ?? null,
      },
      employee: {
        name: `${e.civility ? `${e.civility} ` : ""}${e.firstName} ${e.lastName}`,
        address: [e.addressLine1, e.addressLine2, [e.postalCode, e.city].filter(Boolean).join(" ")].filter(Boolean).join(", ") || "-",
        jobTitle: c?.jobTitle ?? e.jobTitle,
        classification: [c?.classification, c?.coefficient ? `coefficient ${c.coefficient}` : null].filter(Boolean).join(", ") || null,
        category: c?.category === "cadre" ? "cadre" : "non-cadre",
        hireDate: e.hireDate,
        employeeNumber: e.employeeNumber,
        contractType: c?.type ?? "-",
        workTime: c?.workTimeMode === "forfait_jours" ? `forfait de ${c.annualDays ?? 218} jours` : `${String(c?.weeklyHours ?? "35").replace(".", ",")} h par semaine (${String(c?.monthlyHours ?? "151.67").replace(".", ",")} h par mois)`,
      },
      period: { label, start, end, paymentDate: period.paymentDate ?? end },
      lines: s.lines as PayslipLine[],
      totals: cum.totals,
      cumulative: cum,
      leave: { paidLeaveTakenDays: cum.details?.paidLeaveDays ?? "0", datesText: leaves.length ? leaves.map((l) => l.label.split(" : ")[0]).join(", ") : null },
      ruleSetVersion: s.ruleSetVersion,
      computeHash: s.computeHash,
      isDemo: company.isDemo,
    });
    const doc = await createDocument({
      companyId: company.id,
      employeeId: e.id,
      category: "bulletin",
      visibility: "employee",
      title: `Bulletin de paie ${label}`,
      fileName: `bulletin-${period.year}-${String(period.month).padStart(2, "0")}-${e.lastName}-${e.firstName}.pdf`,
      mimeType: "application/pdf",
      data: pdf,
      sourceType: "payslip",
      sourceId: s.id,
      uploadedBy: userId,
      retentionYears: PAYSLIP_RETENTION_YEARS,
      isDemo: company.isDemo,
    });
    await db.update(schema.payslips).set({ documentId: doc.id, status: "finalized" }).where(eq(schema.payslips.id, s.id));
    created++;
  }
  if (period.status === "validated") await transition(periodId, company.id, period.status, "finalized", userId, {}, { documents: created });
  else await audit({ action: "payroll.finalize", userId, companyId: company.id, entityType: "payroll_period", entityId: periodId, after: { documents: created, status: period.status } });
  return { documents: created };
}

/** Passage au statut « exporté » après préparation des fichiers (appelé par filings.ts). */
export async function markExported(periodId: string, userId: string) {
  const { period, company } = await loadPeriod(periodId);
  if (period.status === "finalized") await transition(periodId, company.id, period.status, "exported", userId);
}

// ---------------------------------------------------------------- 9. Distribuer

export async function distributePeriod(periodId: string, userId: string): Promise<{ distributed: number; mailed: number; demo: boolean }> {
  const { period, company } = await loadPeriod(periodId);
  if (statusIndex(period.status) < statusIndex("exported")) throw new PayrollError("Préparez les exports et déclarations avant de distribuer les bulletins.");
  const slips = await db.select().from(schema.payslips).where(eq(schema.payslips.periodId, periodId));
  if (slips.some((s) => !s.documentId)) throw new PayrollError("Certains bulletins n'ont pas de PDF : relancez la finalisation.");
  const label = monthLabel(period.year, period.month);
  let mailed = 0;
  let distributed = 0;
  const now = new Date();
  for (const s of slips) {
    if (s.distributedAt) continue;
    await db.update(schema.payslips).set({ status: "distributed", distributedAt: now }).where(eq(schema.payslips.id, s.id));
    distributed++;
    if (company.isDemo) continue;
    const [e] = await db.select().from(schema.employees).where(and(eq(schema.employees.id, s.employeeId), eq(schema.employees.companyId, company.id))).limit(1);
    if (!e?.userId) continue;
    const [u] = await db.select({ email: schema.users.email }).from(schema.users).where(eq(schema.users.id, e.userId)).limit(1);
    if (!u?.email) continue;
    const r = await sendMail({
      to: u.email,
      subject: `Votre bulletin de paie de ${label} est disponible`,
      html: layoutMail(`Bulletin de paie de ${label}`, `<p>Bonjour ${e.firstName},</p><p>Votre bulletin de paie de ${label} est disponible dans votre espace. Conservez-le sans limitation de durée.</p>`, { label: "Ouvrir mon espace", url: `${appUrl()}/moi/documents` }),
      text: `Votre bulletin de paie de ${label} est disponible dans votre espace : ${appUrl()}/moi/documents`,
      isDemo: company.isDemo,
    });
    if (r.status === "sent") mailed++;
  }
  if (period.status === "exported") await transition(periodId, company.id, period.status, "distributed", userId, {}, { distributed, mailed, demo: company.isDemo });
  return { distributed, mailed, demo: company.isDemo };
}

// ---------------------------------------------------------------- 10. Clôturer

export async function closePeriod(periodId: string, userId: string) {
  const { period, company } = await loadPeriod(periodId);
  if (period.status === "closed") return;
  if (period.status !== "distributed") throw new PayrollError("Distribuez les bulletins avant de clôturer la période.");
  await transition(periodId, company.id, period.status, "closed", userId, { closedAt: new Date(), closedBy: userId });
}
