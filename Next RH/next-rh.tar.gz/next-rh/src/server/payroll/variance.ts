/**
 * Écarts d'un bulletin par rapport au mois précédent, expliqués en français (module pur).
 */
import type { PayslipLine, PayslipTotals } from "./engine/types";

export type Variance = {
  hasPrevious: boolean;
  previousPeriod: string | null;
  grossDeltaCents: number;
  grossDeltaPct: number | null;
  netPaidDeltaCents: number;
  netPaidDeltaPct: number | null;
  employerCostDeltaCents: number;
  explanations: string[];
};

type Snap = { lines: PayslipLine[]; totals: Pick<PayslipTotals, "grossCents" | "netPaidCents" | "employerCostCents" | "pasRate">; label: string };

const eur = (c: number) => {
  const s = (Math.abs(c) / 100).toFixed(2).replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${c < 0 ? "-" : "+"}${s} €`;
};

const groups: { name: string; match: (code: string) => boolean }[] = [
  { name: "Salaire de base", match: (c) => c === "SALAIRE_BASE" },
  { name: "Entrée ou sortie en cours de mois", match: (c) => c === "ENTREE_SORTIE" },
  { name: "Absences non rémunérées", match: (c) => c === "ABSENCE_NON_REMUNEREE" },
  { name: "Heures supplémentaires et complémentaires", match: (c) => c.startsWith("HEURES_") },
  { name: "Primes et commissions", match: (c) => c === "PRIME" || c === "COMMISSION" },
  { name: "Régularisations", match: (c) => c === "REGULARISATION" },
  { name: "Avantages en nature", match: (c) => c === "AVANTAGE_NATURE" },
];

const sumGroup = (lines: PayslipLine[], m: (c: string) => boolean) => lines.filter((l) => l.section === "brut" && m(l.code)).reduce((s, l) => s + l.amount_employee, 0);
const pct = (d: number, base: number) => (base ? Math.round((d / base) * 1000) / 10 : null);

export function computeVariance(current: Snap, previous: Snap | null): Variance {
  if (!previous) {
    return {
      hasPrevious: false,
      previousPeriod: null,
      grossDeltaCents: 0,
      grossDeltaPct: null,
      netPaidDeltaCents: 0,
      netPaidDeltaPct: null,
      employerCostDeltaCents: 0,
      explanations: ["Premier bulletin calculé dans Next RH pour ce salarié : aucune comparaison possible."],
    };
  }
  const gd = current.totals.grossCents - previous.totals.grossCents;
  const nd = current.totals.netPaidCents - previous.totals.netPaidCents;
  const cd = current.totals.employerCostCents - previous.totals.employerCostCents;
  const explanations: string[] = [];
  for (const g of groups) {
    const a = sumGroup(current.lines, g.match);
    const b = sumGroup(previous.lines, g.match);
    if (a !== b) explanations.push(`${g.name} : ${eur(a - b)} (${eur(b).replace("+", "")} le mois précédent, ${eur(a).replace("+", "")} ce mois).`);
  }
  if (current.totals.pasRate !== previous.totals.pasRate) {
    explanations.push(`Taux de prélèvement à la source : ${previous.totals.pasRate} % le mois précédent, ${current.totals.pasRate} % ce mois.`);
  }
  const rgduA = current.lines.find((l) => l.code === "RGDU")?.amount_employer ?? 0;
  const rgduB = previous.lines.find((l) => l.code === "RGDU")?.amount_employer ?? 0;
  if (rgduA !== rgduB) explanations.push(`Réduction générale des cotisations patronales : ${eur(-(rgduA - rgduB))} d'allègement par rapport au mois précédent (régularisation progressive sur l'année).`);
  if (!explanations.length && (gd !== 0 || nd !== 0)) explanations.push("Écart lié aux arrondis ou aux cotisations, sans changement des éléments de rémunération.");
  if (!explanations.length) explanations.push("Aucun écart avec le mois précédent.");
  return {
    hasPrevious: true,
    previousPeriod: previous.label,
    grossDeltaCents: gd,
    grossDeltaPct: pct(gd, previous.totals.grossCents),
    netPaidDeltaCents: nd,
    netPaidDeltaPct: pct(nd, previous.totals.netPaidCents),
    employerCostDeltaCents: cd,
    explanations,
  };
}
