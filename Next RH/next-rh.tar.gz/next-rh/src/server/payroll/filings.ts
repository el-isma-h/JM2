import "server-only";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { createDocument } from "@/server/documents/store";
import { decrypt } from "@/lib/crypto";
import { monthLabel } from "@/lib/dates";
import type { PayslipLine, PayslipResult, PayslipTotals } from "./engine/types";
import { ENGINE_VERSION } from "./engine/compute";
import { markExported, PayrollError, statusIndex } from "./cycle";
import { periodBounds } from "./inputs";
import { buildAccountingEntries, buildCharges, buildEstablishmentRecap, buildJournal, buildSepaXml, ibanValid, type FilingSlip, type SepaPayment } from "./filings/builders";
import { buildDsn, type DsnEmployee } from "./filings/dsn";

/**
 * Déclarations et exports d'une période validée. Statuts : prepared -> controlled -> send_requested -> sent -> accepted / rejected.
 * « sent » et « accepted » ne sont posés qu'à l'enregistrement d'un accusé fourni par l'utilisateur ; aucune transmission
 * automatique n'existe (pas de connexion net-entreprises ni bancaire).
 */

export type FilingKind = (typeof schema.filingKindEnum.enumValues)[number];
export const SENDABLE: FilingKind[] = ["dsn_mensuelle", "virement_sepa"];
export const FILING_LABELS: Record<string, string> = {
  journal_paie: "Journal de paie",
  etat_charges: "État des charges par organisme",
  recap_etablissement: "Récapitulatif par établissement",
  export_comptable: "Écritures comptables",
  virement_sepa: "Fichier de virements SEPA",
  dsn_mensuelle: "DSN mensuelle (préparation)",
  dsn_evenement: "DSN événementielle",
  documents_sortie: "Documents de sortie",
};
const LOCKED_FILING = new Set(["send_requested", "sent", "accepted"]);

async function loadPeriodForFilings(periodId: string) {
  const [period] = await db.select().from(schema.payrollPeriods).where(eq(schema.payrollPeriods.id, periodId)).limit(1);
  if (!period) throw new PayrollError("Période introuvable.");
  if (statusIndex(period.status) < statusIndex("validated")) throw new PayrollError("Les exports et déclarations se préparent à partir d'une période validée.");
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, period.companyId)).limit(1);
  return { period, company: company! };
}

async function collectSlips(period: typeof schema.payrollPeriods.$inferSelect) {
  const rows = await db
    .select({ s: schema.payslips, e: schema.employees })
    .from(schema.payslips)
    .innerJoin(schema.employees, eq(schema.employees.id, schema.payslips.employeeId))
    .where(and(eq(schema.payslips.periodId, period.id), eq(schema.employees.companyId, period.companyId)));
  const ests = await db.select().from(schema.establishments).where(eq(schema.establishments.companyId, period.companyId));
  const head = ests.find((x) => x.isHeadOffice) ?? ests[0] ?? null;
  return rows
    .filter((r) => r.s.status !== "blocked")
    .map((r) => {
      const est = ests.find((x) => x.id === r.e.establishmentId) ?? head;
      const cum = r.s.cumulative as { totals: PayslipTotals; details: PayslipResult["details"] };
      return { ...r, est, totals: cum.totals, details: cum.details };
    });
}

async function saveFiling(opts: {
  periodId: string;
  companyId: string;
  isDemo: boolean;
  kind: FilingKind;
  title: string;
  fileName: string;
  mimeType: string;
  data: Buffer;
  content: Record<string, unknown>;
  controls: unknown[];
  userId: string;
}) {
  const existing = await db.select().from(schema.payrollFilings).where(and(eq(schema.payrollFilings.periodId, opts.periodId), eq(schema.payrollFilings.kind, opts.kind)));
  const locked = existing.find((f) => LOCKED_FILING.has(f.status));
  if (locked) return { id: locked.id, skipped: true };
  const replace = existing[0];
  let filingId: string;
  if (replace) {
    filingId = replace.id;
  } else {
    const [f] = await db.insert(schema.payrollFilings).values({ periodId: opts.periodId, kind: opts.kind, status: "prepared" }).returning({ id: schema.payrollFilings.id });
    filingId = f.id;
  }
  const doc = await createDocument({
    companyId: opts.companyId,
    category: "export",
    visibility: "restricted",
    title: opts.title,
    fileName: opts.fileName,
    mimeType: opts.mimeType,
    data: opts.data,
    sourceType: "payroll_filing",
    sourceId: filingId,
    uploadedBy: opts.userId,
    previousVersionId: (replace?.content as { documentId?: string } | undefined)?.documentId ?? null,
    retentionYears: 6,
    isDemo: opts.isDemo,
  });
  await db
    .update(schema.payrollFilings)
    .set({ status: "prepared", content: { ...opts.content, documentId: doc.id, fileName: opts.fileName, preparedAt: new Date().toISOString(), preparedBy: opts.userId }, fileKey: doc.storageKey, controls: opts.controls, acknowledgement: null, rejectionReason: null, sentAt: null, sendRequestedAt: null, sendRequestedBy: null })
    .where(eq(schema.payrollFilings.id, filingId));
  await audit({ action: "filing.prepare", userId: opts.userId, companyId: opts.companyId, entityType: "payroll_filing", entityId: filingId, after: { kind: opts.kind, documentId: doc.id } });
  return { id: filingId, skipped: false };
}

export async function prepareFilings(periodId: string, userId: string, opts: { debtorIban?: string | null; debtorBic?: string | null; debtorName?: string | null } = {}) {
  const { period, company } = await loadPeriodForFilings(periodId);
  const slips = await collectSlips(period);
  if (!slips.length) throw new PayrollError("Aucun bulletin calculé sur la période.");
  const label = monthLabel(period.year, period.month);
  const ym = `${period.year}-${String(period.month).padStart(2, "0")}`;
  const { start, end } = periodBounds(period);
  const base = { periodId, companyId: company.id, isDemo: company.isDemo, userId };
  const results: { kind: FilingKind; id: string; skipped: boolean }[] = [];

  const fslips: FilingSlip[] = slips.map((r) => ({
    employeeId: r.e.id,
    employeeNumber: r.e.employeeNumber,
    firstName: r.e.firstName,
    lastName: r.e.lastName,
    establishmentId: r.est?.id ?? null,
    establishmentName: r.est?.name ?? "Établissement principal",
    lines: r.s.lines as PayslipLine[],
    totals: r.totals,
    hoursWorked: String(r.s.hoursWorked),
    rgduIrcPartCents: r.details?.rgdu?.ircPartCents ?? 0,
  }));

  const j = buildJournal(fslips);
  results.push({ kind: "journal_paie", ...(await saveFiling({ ...base, kind: "journal_paie", title: `Journal de paie ${label}`, fileName: `journal-paie-${ym}.csv`, mimeType: "text/csv", data: j.csv, content: { totals: j.totals }, controls: [] })) });

  const ch = buildCharges(fslips);
  results.push({ kind: "etat_charges", ...(await saveFiling({ ...base, kind: "etat_charges", title: `État des charges ${label}`, fileName: `etat-charges-${ym}.csv`, mimeType: "text/csv", data: ch.csv, content: { organisms: ch.summary }, controls: [] })) });

  const rec = buildEstablishmentRecap(fslips);
  results.push({ kind: "recap_etablissement", ...(await saveFiling({ ...base, kind: "recap_etablissement", title: `Récapitulatif par établissement ${label}`, fileName: `recap-etablissements-${ym}.csv`, mimeType: "text/csv", data: rec.csv, content: { establishments: rec.establishments }, controls: [] })) });

  const acc = buildAccountingEntries(fslips, { journal: "PAIE", date: end, label: `Paie ${label}` });
  results.push({
    kind: "export_comptable",
    ...(await saveFiling({
      ...base,
      kind: "export_comptable",
      title: `Écritures comptables ${label}`,
      fileName: `ecritures-paie-${ym}.csv`,
      mimeType: "text/csv",
      data: acc.csv,
      content: { debit: acc.debit, credit: acc.credit, balanced: acc.balanced, entries: acc.entries },
      controls: acc.balanced ? [] : [{ level: "error", code: "DESEQUILIBRE", message: "Écritures déséquilibrées : débit et crédit diffèrent." }],
    })),
  });

  // Virements SEPA : uniquement si le compte émetteur est fourni et valide, et pour les salariés avec RIB.
  if (opts.debtorIban) {
    const debtorIban = opts.debtorIban.replace(/\s/g, "").toUpperCase();
    if (!ibanValid(debtorIban)) throw new PayrollError("IBAN du compte émetteur invalide (contrôle de clé modulo 97).");
    const ids = slips.map((r) => r.e.id);
    const banks = await db.select().from(schema.employeeBankAccounts).where(inArray(schema.employeeBankAccounts.employeeId, ids));
    const payments: SepaPayment[] = [];
    const controls: { level: string; code: string; message: string }[] = [];
    for (const r of slips) {
      const name = `${r.e.firstName} ${r.e.lastName}`;
      const b = banks.filter((x) => x.employeeId === r.e.id).sort((a, c) => Number(c.isPrimary) - Number(a.isPrimary))[0];
      if (!b) {
        controls.push({ level: "warning", code: "RIB_MANQUANT", message: `${name} : pas de RIB, non inclus dans le fichier.` });
        continue;
      }
      let iban: string;
      try {
        iban = decrypt(b.ibanEnc);
      } catch {
        controls.push({ level: "error", code: "RIB_ILLISIBLE", message: `${name} : RIB illisible (déchiffrement impossible), non inclus.` });
        continue;
      }
      if (!ibanValid(iban)) {
        controls.push({ level: "error", code: "IBAN_INVALIDE", message: `${name} : IBAN se terminant par ${b.ibanLast4} invalide (clé modulo 97), non inclus.` });
        continue;
      }
      if (r.totals.netPaidCents <= 0) continue;
      payments.push({ employeeId: r.e.id, name: b.holderName || name, iban, bic: b.bic, amountCents: r.totals.netPaidCents, reference: `SAL-${ym}-${r.e.employeeNumber ?? r.e.id.slice(0, 8)}` });
    }
    const now = new Date().toISOString().slice(0, 19);
    const sepa = buildSepaXml({
      messageId: `PAIE-${ym}-${Date.now().toString(36).toUpperCase()}`,
      createdAt: now,
      executionDate: period.paymentDate ?? end,
      debtorName: opts.debtorName || company.legalName,
      debtorIban,
      debtorBic: opts.debtorBic || null,
      label: `Salaire ${label}`,
      payments,
    });
    results.push({
      kind: "virement_sepa",
      ...(await saveFiling({
        ...base,
        kind: "virement_sepa",
        title: `Virements des salaires ${label}`,
        fileName: `virements-salaires-${ym}.xml`,
        mimeType: "application/xml",
        data: sepa.xml,
        content: { count: sepa.count, totalCents: sepa.totalCents, debtorIbanLast4: debtorIban.slice(-4), format: "pain.001.001.03" },
        controls,
      })),
    });
  }

  // DSN mensuelle (préparation)
  const ests = await db.select().from(schema.establishments).where(eq(schema.establishments.companyId, company.id));
  const head = ests.find((x) => x.isHeadOffice) ?? ests[0] ?? null;
  const contractIds = slips.map((r) => r.s.contractId).filter((x): x is string => Boolean(x));
  const contracts = contractIds.length ? await db.select().from(schema.contracts).where(inArray(schema.contracts.id, contractIds)) : [];
  const [contact] = await db.select().from(schema.companyContacts).where(and(eq(schema.companyContacts.companyId, company.id), inArray(schema.companyContacts.role, ["paie", "rh", "dirigeant"]))).limit(1);
  const [urssaf] = await db.select().from(schema.companyOrganisms).where(and(eq(schema.companyOrganisms.companyId, company.id), eq(schema.companyOrganisms.kind, "urssaf"))).limit(1);
  const byEst = new Map<string, DsnEmployee[]>();
  for (const r of slips) {
    let nir: string | null = null;
    if (r.e.nirEnc) {
      try {
        nir = decrypt(r.e.nirEnc);
      } catch {
        nir = null;
      }
    }
    const c = contracts.find((x) => x.id === r.s.contractId) ?? null;
    const k = r.est?.id ?? "none";
    const list = byEst.get(k) ?? [];
    list.push({
      nir,
      lastName: r.e.lastName,
      birthName: r.e.birthName,
      firstName: r.e.firstName,
      gender: r.e.gender,
      birthDate: r.e.birthDate,
      birthPlace: r.e.birthPlace,
      address: r.e.addressLine1,
      postalCode: r.e.postalCode,
      city: r.e.city,
      contract: c ? { id: c.id, startDate: c.startDate, endDate: c.endDate, type: c.type, category: c.category, jobTitle: c.jobTitle ?? r.e.jobTitle, workTimeMode: c.workTimeMode, weeklyHours: String(c.weeklyHours), monthlyHours: String(c.monthlyHours), isPartTime: c.isPartTime } : null,
      establishmentSiret: r.est?.siret ?? null,
      lines: r.s.lines as PayslipLine[],
      totals: r.totals,
      hoursWorked: String(r.s.hoursWorked),
      rgduCents: r.details?.rgdu?.reductionCents ?? 0,
    });
    byEst.set(k, list);
  }
  const dsn = buildDsn({
    software: { name: "Next RH", version: ENGINE_VERSION },
    company: { siren: company.siren, legalName: company.legalName, ape: company.apeCode, address: company.addressLine1, postalCode: company.postalCode, city: company.city, idcc: company.idcc, headNic: head?.siret ? head.siret.slice(9) : head?.nic ?? null },
    contact: { name: contact?.fullName ?? company.legalName, email: contact?.email ?? null, phone: contact?.phone ?? null },
    establishments: [...byEst.entries()].map(([k, emps]) => {
      const est = ests.find((x) => x.id === k) ?? head;
      return { siret: est?.siret ?? null, ape: company.apeCode, address: est?.addressLine1 ?? null, postalCode: est?.postalCode ?? null, city: est?.city ?? null, headcount: emps.length, urssafId: urssaf?.reference && /^\d{14}$/.test(urssaf.reference.replace(/\s/g, "")) ? urssaf.reference.replace(/\s/g, "") : null, employees: emps };
    }),
    period: { year: period.year, month: period.month, start, end, paymentDate: period.paymentDate ?? end },
    generatedAt: new Date().toISOString(),
  });
  results.push({
    kind: "dsn_mensuelle",
    ...(await saveFiling({
      ...base,
      kind: "dsn_mensuelle",
      title: `DSN mensuelle ${label} (préparée, non transmise)`,
      fileName: `dsn-${ym}-essai.dsn`,
      mimeType: "text/plain",
      data: dsn.text,
      content: { individuals: dsn.individuals, lines: dsn.lines, norme: "P26V01", transmitted: false, notice: "Fichier préparé, non transmis." },
      controls: dsn.controls,
    })),
  });

  await markExported(periodId, userId);
  return results;
}

async function loadFiling(filingId: string, companyId: string) {
  const [row] = await db
    .select({ f: schema.payrollFilings, p: schema.payrollPeriods })
    .from(schema.payrollFilings)
    .innerJoin(schema.payrollPeriods, eq(schema.payrollPeriods.id, schema.payrollFilings.periodId))
    .where(and(eq(schema.payrollFilings.id, filingId), eq(schema.payrollPeriods.companyId, companyId)))
    .limit(1);
  if (!row) throw new PayrollError("Déclaration introuvable.");
  return row;
}

async function setFilingStatus(filingId: string, companyId: string, userId: string, from: string, to: string, set: Partial<typeof schema.payrollFilings.$inferInsert>, after: Record<string, unknown> = {}) {
  await db.update(schema.payrollFilings).set({ status: to as typeof schema.payrollFilings.$inferInsert.status, ...set }).where(eq(schema.payrollFilings.id, filingId));
  await audit({ action: `filing.${to}`, userId, companyId, entityType: "payroll_filing", entityId: filingId, before: { status: from }, after: { status: to, ...after } });
}

export async function controlFiling(filingId: string, companyId: string, userId: string) {
  const { f } = await loadFiling(filingId, companyId);
  if (f.status !== "prepared") throw new PayrollError("Seul un document préparé peut être marqué comme contrôlé.");
  const errors = ((f.controls as { level: string; message: string }[]) ?? []).filter((c) => c.level === "error");
  if (errors.length) throw new PayrollError(`${errors.length} erreur(s) de contrôle à corriger avant de valider ce document : ${errors[0].message}`);
  await setFilingStatus(filingId, companyId, userId, f.status, "controlled", {});
}

export async function requestFilingSend(filingId: string, companyId: string, userId: string, isDemo: boolean) {
  const { f } = await loadFiling(filingId, companyId);
  if (isDemo) throw new PayrollError("Démonstration : aucune déclaration ni aucun virement ne peut être envoyé. Le fichier reste disponible au téléchargement.");
  if (!SENDABLE.includes(f.kind)) throw new PayrollError("Ce document est un export interne : il n'a pas d'envoi à suivre.");
  if (f.status !== "controlled") throw new PayrollError("Contrôlez le document avant de demander son envoi.");
  await setFilingStatus(filingId, companyId, userId, f.status, "send_requested", { sendRequestedBy: userId, sendRequestedAt: new Date() });
}

/**
 * Enregistre un accusé fourni par l'utilisateur. `sent` : référence de dépôt (ou fichier) après dépôt manuel ;
 * `accepted` / `rejected` : accusé technique ou de réception. Jamais déclenché automatiquement.
 */
export async function recordFilingAcknowledgement(
  filingId: string,
  companyId: string,
  userId: string,
  ack: { outcome: "sent" | "accepted" | "rejected"; reference: string | null; fileDocumentId: string | null; reason: string | null },
) {
  const { f } = await loadFiling(filingId, companyId);
  if (!ack.reference && !ack.fileDocumentId) throw new PayrollError("Indiquez la référence de l'accusé ou importez le fichier de retour.");
  const allowed: Record<string, string[]> = { sent: ["send_requested"], accepted: ["send_requested", "sent"], rejected: ["send_requested", "sent"] };
  if (!allowed[ack.outcome].includes(f.status)) throw new PayrollError("Cet accusé ne correspond pas à l'état du document (un envoi doit d'abord être demandé).");
  if (ack.outcome === "rejected" && !ack.reason) throw new PayrollError("Indiquez le motif du rejet indiqué dans l'accusé.");
  const record = { ...ack, recordedBy: userId, recordedAt: new Date().toISOString(), previous: f.acknowledgement ?? null };
  await setFilingStatus(
    filingId,
    companyId,
    userId,
    f.status,
    ack.outcome,
    { acknowledgement: record, sentAt: ack.outcome === "sent" || !f.sentAt ? new Date() : f.sentAt, rejectionReason: ack.outcome === "rejected" ? ack.reason : null },
    { reference: ack.reference, fileDocumentId: ack.fileDocumentId },
  );
}
