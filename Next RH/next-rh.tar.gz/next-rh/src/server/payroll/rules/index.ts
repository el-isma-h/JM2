/**
 * Jeux de règles de paie versionnés et datés (module pur : aucun accès base, aucun appel externe).
 * Chaque fichier JSON contient tous les paramètres applicables sur sa plage de dates, avec date d'effet,
 * sources officielles et niveau de vérification. La table `payroll_rule_sets` est alimentée depuis ces fichiers
 * par `src/server/payroll/scripts/sync-rule-sets.ts`.
 */
import { createHash } from "node:crypto";
import r202601 from "./fr-2026.01.json";
import r202605 from "./fr-2026.05.json";
import r202606 from "./fr-2026.06.json";

export type Param<T> = {
  value: T;
  unit: string;
  effectiveFrom: string;
  sources: string[];
  verification: string;
  note?: string;
};

export type ContributionRate = { employer: string; employee: string; base: "total" | "T1" | "T2" | "T1T2" | "4P" | "prevoyance_patronale"; minHeadcount?: number };
export type GridRow = { fromCents: number; rate: string };

export type RuleParams = {
  "smic.hourly": Param<string>;
  "rgdu.smicHourly": Param<string>;
  pmss: Param<number>;
  "plafond.prorata": Param<{ divisor: number }>;
  "contrib.maladie": Param<ContributionRate>;
  "contrib.vieillessePlafonnee": Param<ContributionRate>;
  "contrib.vieillesseDeplafonnee": Param<ContributionRate>;
  "contrib.allocationsFamiliales": Param<ContributionRate>;
  "contrib.csa": Param<ContributionRate>;
  "contrib.fnalLt50": Param<ContributionRate>;
  "contrib.fnalGte50": Param<ContributionRate>;
  "contrib.chomage": Param<ContributionRate>;
  "contrib.ags": Param<ContributionRate>;
  "contrib.agircT1": Param<ContributionRate>;
  "contrib.agircT2": Param<ContributionRate>;
  "contrib.cegT1": Param<ContributionRate>;
  "contrib.cegT2": Param<ContributionRate>;
  "contrib.cet": Param<ContributionRate>;
  "contrib.apec": Param<ContributionRate>;
  "contrib.dialogueSocial": Param<ContributionRate>;
  "contrib.formationLt11": Param<ContributionRate>;
  "contrib.formationGte11": Param<ContributionRate>;
  "contrib.cpfCdd": Param<ContributionRate>;
  "contrib.taxeApprentissage": Param<ContributionRate>;
  "contrib.forfaitSocialPrevoyance": Param<ContributionRate>;
  csg: Param<{ deductible: string; nonDeductible: string; crds: string; abattement: string; abattementLimitPmss: number }>;
  rgdu: Param<{
    tmin: string;
    tdeltaLt50: string;
    tdeltaGte50: string;
    p: string;
    thresholdSmic: string;
    annualHours: string;
    coefficientDecimals: number;
    ircCap: string;
    atmpCap: string;
    forfaitJoursReference: number;
  }>;
  "hs.reductionSalariale": Param<{ maxRate: string }>;
  "hs.exonerationFiscale": Param<{ annualLimitCents: number }>;
  "hs.deductionForfaitaire": Param<{ lt20Cents: number; from20to249Cents: number; gte250Cents: number | null }>;
  titresRestaurant: Param<{ maxEmployerShareCents: number; minShare: string; maxShare: string }>;
  "prevoyance.cadreMinEmployerRateT1": Param<string>;
  "pas.neutralGrid": Param<GridRow[]>;
  "pas.shortContractAbattement": Param<number>;
  "netSocial.definition": Param<string>;
  "bulletin.mentions": Param<string>;
};

export type RuleSet = {
  version: string;
  label: string;
  jurisdiction: string;
  regime: string;
  effectiveFrom: string;
  effectiveTo: string | null;
  consultedAt: string;
  params: RuleParams;
  notCovered: string[];
};

const ALL: RuleSet[] = [r202601, r202605, r202606].map((r) => r as unknown as RuleSet).sort((a, b) => a.effectiveFrom.localeCompare(b.effectiveFrom));

/** Sérialisation canonique (clés triées) pour un checksum stable. */
export function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value ?? null);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  const o = value as Record<string, unknown>;
  return `{${Object.keys(o)
    .filter((k) => o[k] !== undefined)
    .sort()
    .map((k) => `${JSON.stringify(k)}:${canonicalJson(o[k])}`)
    .join(",")}}`;
}

export function ruleSetChecksum(rs: RuleSet): string {
  return createHash("sha256").update(canonicalJson(rs)).digest("hex");
}

export function listRuleSets(): RuleSet[] {
  return ALL;
}

export function getRuleSet(version: string): RuleSet | null {
  return ALL.find((r) => r.version === version) ?? null;
}

/** Choisit le jeu de règles applicable à une date ISO (AAAA-MM-JJ). Renvoie null si aucune version ne couvre la date. */
export function loadRuleSet(date: string): RuleSet | null {
  return ALL.find((r) => r.effectiveFrom <= date && (r.effectiveTo === null || date <= r.effectiveTo)) ?? null;
}

/** Toutes les sources officielles citées par un jeu de règles (dédoublonnées), pour l'affichage et la table. */
export function ruleSetSources(rs: RuleSet): { key: string; url: string; effectiveFrom: string; verification: string }[] {
  const out: { key: string; url: string; effectiveFrom: string; verification: string }[] = [];
  for (const [key, p] of Object.entries(rs.params) as [string, Param<unknown>][]) {
    for (const url of p.sources) out.push({ key, url, effectiveFrom: p.effectiveFrom, verification: p.verification });
  }
  return out;
}
