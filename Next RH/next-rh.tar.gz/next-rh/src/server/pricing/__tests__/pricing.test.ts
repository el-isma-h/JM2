import { describe, expect, it } from "vitest";
import { PRICING_ROWS, PRICING_CHECKED_AT, PRICING_SOURCE_URL } from "../data";
import { checkPrice, proposePrice } from "../compute";

/** Valeurs attendues recopiées de replica/pricing.md (référence, prix Next RH), en centimes. */
const EXPECTED: Record<string, [number, number]> = {
  conges: [311, 279],
  temps: [300, 270],
  teletravail: [224, 201],
  dossiers: [321, 288],
  entretiens: [397, 357],
  engagement: [316, 284],
  formations: [321, 288],
  recrutement: [321, 288],
  frais: [581, 522],
  factures: [91, 81],
  remuneration: [178, 160],
  bulletins: [70, 63],
  avantages: [102, 91],
  preparation_paie: [61, 54],
};

describe("grille tarifaire à -10 %", () => {
  it("contient exactement les modules chiffrés de pricing.md avec les bons prix", () => {
    const priced = PRICING_ROWS.filter((r) => r.referencePriceCents !== null && r.referencePriceCents > 0);
    expect(priced.map((r) => r.code).sort()).toEqual(Object.keys(EXPECTED).sort());
    for (const r of priced) {
      const [ref, price] = EXPECTED[r.code];
      expect(r.referencePriceCents).toBe(ref);
      expect(r.priceCents).toBe(price);
    }
  });

  it("recalcule chaque prix à -10 % et n'arrondit jamais au-dessus", () => {
    for (const r of PRICING_ROWS) {
      if (r.referencePriceCents === null || r.unit === "inclus") continue;
      const exact = (r.referencePriceCents * 9000) / 10000;
      const recomputed = proposePrice(r.referencePriceCents, 1000)!;
      expect(recomputed).toBe(r.priceCents);
      expect(recomputed).toBeLessThanOrEqual(exact);
      expect(exact - recomputed).toBeLessThan(1);
      expect(checkPrice(r).level).toBe("ok");
    }
  });

  it("met la production de paie et la DSN sur devis, sans prix", () => {
    for (const code of ["production_paie", "dsn"]) {
      const r = PRICING_ROWS.find((x) => x.code === code)!;
      expect(r.unit).toBe("sur_devis");
      expect(r.priceCents).toBeNull();
      expect(r.isService).toBe(false);
    }
  });

  it("sépare les services d'accompagnement (sur devis) des fonctions incluses", () => {
    const services = PRICING_ROWS.filter((r) => r.isService);
    expect(services.map((s) => s.code).sort()).toEqual(["service_ccn", "service_formation", "service_reprise"]);
    for (const s of services) {
      expect(s.unit).toBe("sur_devis");
      expect(s.priceCents).toBeNull();
    }
    const included = PRICING_ROWS.filter((r) => r.unit === "inclus");
    expect(included).toHaveLength(6);
    for (const r of included) expect(r.priceCents).toBe(0);
  });

  it("porte la source et la date de consultation sur chaque ligne", () => {
    for (const r of PRICING_ROWS) {
      expect(r.referenceUrl).toBe(PRICING_SOURCE_URL);
      expect(r.referenceCheckedAt).toBe(PRICING_CHECKED_AT);
    }
    expect(new Set(PRICING_ROWS.map((r) => r.code)).size).toBe(PRICING_ROWS.length);
  });

  it("signale un prix au-dessus de référence × 0,90", () => {
    expect(checkPrice({ priceCents: 280, referencePriceCents: 311, discountRate: 1000, unit: "par_salarie_mois" }).level).toBe("danger");
    expect(checkPrice({ priceCents: 279, referencePriceCents: 311, discountRate: 1000, unit: "par_salarie_mois" }).level).toBe("ok");
    expect(checkPrice({ priceCents: 250, referencePriceCents: 311, discountRate: 1000, unit: "par_salarie_mois" }).level).toBe("info");
  });

  it("refuse les entrées invalides", () => {
    expect(() => proposePrice(3.5, 1000)).toThrow();
    expect(() => proposePrice(100, 12000)).toThrow();
    expect(proposePrice(null)).toBeNull();
  });
});
