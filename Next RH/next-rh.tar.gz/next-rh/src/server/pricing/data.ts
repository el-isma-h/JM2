/**
 * Grille tarifaire sourcée (replica/pricing.md). Module pur : utilisé par seedPricing() et par les tests.
 * Source unique : https://www.lucca.fr/tarifs/ consultée le 2026-10-20 (prix indicatifs HT, entreprises de 100 salariés et plus).
 */
import { calculationNote, proposePrice } from "./compute";

export const PRICING_SOURCE_URL = "https://www.lucca.fr/tarifs/";
export const PRICING_CHECKED_AT = "2026-10-20";

type Unit = "par_salarie_mois" | "par_declarant_mois" | "par_document" | "par_facture" | "forfait_mois" | "sur_devis" | "inclus";

export type PricingSeedRow = {
  code: string;
  name: string;
  description: string;
  isService: boolean;
  unit: Unit;
  priceCents: number | null;
  referencePriceCents: number | null;
  referenceLabel: string | null;
  referenceUrl: string;
  referenceCheckedAt: string;
  discountRate: number;
  calculationNote: string | null;
  isActive: boolean;
  sortOrder: number;
};

/** Modules à prix public : [code, nom Next RH, comparable référence, prix référence en centimes, unité, description]. */
const PRICED: [string, string, string, number, Unit, string][] = [
  ["conges", "Congés et absences", "Absences", 311, "par_salarie_mois", "Demandes, validation, soldes, planning d'équipe et report en paie."],
  ["temps", "Temps de travail", "Feuilles de temps", 300, "par_salarie_mois", "Feuilles de temps mensuelles, heures supplémentaires et complémentaires."],
  ["teletravail", "Télétravail", "Office", 224, "par_salarie_mois", "Politique de télétravail, demandes par jour et indemnités."],
  ["dossiers", "Dossiers salariés", "Socle RH", 321, "par_salarie_mois", "Fiche salarié, contrats et avenants, historique, documents."],
  ["entretiens", "Entretiens", "Performance", 397, "par_salarie_mois", "Entretiens annuels et professionnels, objectifs, comptes rendus."],
  ["engagement", "Engagement", "Engagement", 316, "par_salarie_mois", "Questionnaires internes et suivi du climat social."],
  ["formations", "Formations", "Formation", 321, "par_salarie_mois", "Demandes, plan de formation, habilitations et dates d'expiration."],
  ["recrutement", "Recrutement", "Recrutement", 321, "par_salarie_mois", "Offres d'emploi, candidatures et passage en dossier salarié."],
  ["frais", "Notes de frais", "Frais professionnels", 581, "par_declarant_mois", "Notes de frais avec justificatifs, validation et remboursement en paie."],
  ["factures", "Factures fournisseurs", "Factures (600-799 factures)", 91, "par_facture", "Réception et validation des factures fournisseurs."],
  ["remuneration", "Variables de rémunération", "Rémunération", 178, "par_salarie_mois", "Primes, commissions, titres-restaurant et historique des rémunérations."],
  ["bulletins", "Distribution des bulletins", "Bulletins de paie", 70, "par_document", "Mise à disposition des bulletins dans l'espace de chaque salarié."],
  ["avantages", "Avantages", "Avantages", 102, "par_salarie_mois", "Avantages salariés et avantages en nature."],
  ["preparation_paie", "Préparation de paie", "Assistant Paie (connecteurs)", 61, "par_salarie_mois", "Collecte, contrôle et validation des éléments variables du mois."],
];

function priced(i: number, [code, name, refLabel, ref, unit, description]: (typeof PRICED)[number]): PricingSeedRow {
  return {
    code,
    name,
    description,
    isService: false,
    unit,
    priceCents: proposePrice(ref, 1000),
    referencePriceCents: ref,
    referenceLabel: refLabel,
    referenceUrl: PRICING_SOURCE_URL,
    referenceCheckedAt: PRICING_CHECKED_AT,
    discountRate: 1000,
    calculationNote: calculationNote(ref, 1000),
    isActive: true,
    sortOrder: (i + 1) * 10,
  };
}

const quote = (code: string, name: string, description: string, refLabel: string, note: string, sortOrder: number, isService = false): PricingSeedRow => ({
  code,
  name,
  description,
  isService,
  unit: "sur_devis",
  priceCents: null,
  referencePriceCents: null,
  referenceLabel: refLabel,
  referenceUrl: PRICING_SOURCE_URL,
  referenceCheckedAt: PRICING_CHECKED_AT,
  discountRate: 1000,
  calculationNote: note,
  isActive: true,
  sortOrder,
});

const included = (code: string, name: string, description: string, sortOrder: number): PricingSeedRow => ({
  code,
  name,
  description,
  isService: false,
  unit: "inclus",
  priceCents: 0,
  referencePriceCents: 0,
  referenceLabel: `${name} (inclus sans surcoût chez la référence)`,
  referenceUrl: PRICING_SOURCE_URL,
  referenceCheckedAt: PRICING_CHECKED_AT,
  discountRate: 1000,
  calculationNote: "Inclus sans surcoût chez la référence, donc inclus sans surcoût chez Next RH.",
  isActive: true,
  sortOrder,
});

export const PRICING_ROWS: PricingSeedRow[] = [
  ...PRICED.map((p, i) => priced(i, p)),
  quote(
    "production_paie",
    "Production de paie (moteur)",
    "Calcul des bulletins par le moteur de paie déterministe et versionné.",
    "Aucun équivalent public (la référence délègue à Silae, Cegid…)",
    "Comparaison à faire sur devis réel : aucun prix public comparable.",
    150,
  ),
  quote("dsn", "Déclarations (DSN)", "Préparation et contrôle des déclarations sociales nominatives.", "Aucun équivalent public", "Comparaison à faire sur devis réel : aucun prix public comparable.", 160),
  included("moyens_paiement", "Moyens de paiement", "Gestion des moyens de paiement des frais professionnels.", 200),
  included("sso", "Authentification unique (SSO)", "Connexion par le fournisseur d'identité de l'entreprise.", 210),
  included("agenda", "Synchronisation agenda", "Absences et entretiens dans l'agenda des collaborateurs.", 220),
  included("documents_partages", "Documents partagés", "Documents d'entreprise mis à disposition des salariés.", 230),
  included("tableaux_bord", "Tableaux de bord", "Indicateurs RH et paie par entreprise.", 240),
  included("export_paie", "Export paie", "Export des éléments de paie et des écritures comptables.", 250),
  quote(
    "service_reprise",
    "Reprise de données assistée",
    "Service d'accompagnement : reprise des salariés et des cumuls avec un conseiller.",
    "Consultant de déploiement inclus chez la référence",
    "Service humain séparé des fonctions incluses : remplacé par l'onboarding guidé, accompagnement optionnel sur devis.",
    300,
    true,
  ),
  quote(
    "service_ccn",
    "Paramétrage convention collective",
    "Service d'accompagnement : paramétrage des spécificités de la convention collective.",
    "Consultant de déploiement inclus chez la référence",
    "Service humain séparé des fonctions incluses : accompagnement optionnel sur devis.",
    310,
    true,
  ),
  quote(
    "service_formation",
    "Formation",
    "Service d'accompagnement : formation des gestionnaires à l'outil.",
    "Consultant de déploiement inclus chez la référence",
    "Service humain séparé des fonctions incluses : accompagnement optionnel sur devis.",
    320,
    true,
  ),
];
