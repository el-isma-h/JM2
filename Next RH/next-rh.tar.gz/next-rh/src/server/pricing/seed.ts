import "server-only";
import { sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { PRICING_ROWS } from "./data";

/**
 * Charge la grille sourcée (replica/pricing.md). Idempotent par `code` :
 * par défaut, une ligne déjà présente n'est pas modifiée (les réglages faits depuis l'admin sont conservés) ;
 * `overwrite: true` réaligne toutes les lignes sur la grille sourcée.
 */
export async function seedPricing(opts: { overwrite?: boolean } = {}): Promise<{ inserted: number; updated: number; total: number }> {
  let inserted = 0;
  let updated = 0;
  for (const row of PRICING_ROWS) {
    const q = db.insert(schema.pricingPlans).values(row);
    const res = opts.overwrite
      ? await q
          .onConflictDoUpdate({ target: schema.pricingPlans.code, set: { ...row, updatedAt: new Date() } })
          .returning({ inserted: sql<boolean>`(xmax = 0)` })
      : await q.onConflictDoNothing({ target: schema.pricingPlans.code }).returning({ inserted: sql<boolean>`true` });
    if (res[0]?.inserted) inserted++;
    else if (res[0]) updated++;
  }
  return { inserted, updated, total: PRICING_ROWS.length };
}
