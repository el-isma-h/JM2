import * as React from "react";
import { cn } from "@/lib/utils";

export type Tone = "neutral" | "ok" | "warn" | "danger" | "info" | "accent";

/** Pastilles NEXT Capital : bordure 1 px, mono capitales, angles droits. */
const tones: Record<Tone, string> = {
  neutral: "border-line-strong text-ink-2",
  ok: "border-ok/50 text-ok-ink",
  warn: "border-warn/60 text-warn-ink",
  danger: "border-danger/50 text-danger-ink",
  info: "border-info-ink/40 text-info-ink",
  accent: "border-accent bg-accent text-accent-ink",
};

export function Badge({ tone = "neutral", className, children, ...props }: React.HTMLAttributes<HTMLSpanElement> & { tone?: Tone }) {
  return (
    <span
      className={cn("inline-flex items-center gap-1 border px-2 py-0.5 font-mono text-[10px] font-medium uppercase leading-4 tracking-[0.14em] whitespace-nowrap", tones[tone], className)}
      {...props}
    >
      {children}
    </span>
  );
}

/** Statuts métier → ton + libellé, pour ne jamais afficher un code brut. */
export const statusMeta: Record<string, { label: string; tone: Tone }> = {
  draft: { label: "Brouillon", tone: "neutral" },
  pending: { label: "En attente", tone: "warn" },
  submitted: { label: "Soumis", tone: "info" },
  approved: { label: "Approuvé", tone: "ok" },
  validated: { label: "Validé", tone: "ok" },
  rejected: { label: "Refusé", tone: "danger" },
  cancelled: { label: "Annulé", tone: "neutral" },
  active: { label: "Actif", tone: "ok" },
  suspended: { label: "Suspendu", tone: "warn" },
  left: { label: "Sorti", tone: "neutral" },
  open: { label: "Ouverte", tone: "neutral" },
  collecting: { label: "Collecte", tone: "info" },
  checking: { label: "Vérification", tone: "info" },
  computed: { label: "Calculée", tone: "info" },
  controlled: { label: "Contrôlée", tone: "info" },
  finalized: { label: "Finalisée", tone: "ok" },
  exported: { label: "Exportée", tone: "ok" },
  distributed: { label: "Distribuée", tone: "ok" },
  closed: { label: "Clôturée", tone: "neutral" },
  blocked: { label: "Bloqué", tone: "danger" },
  prepared: { label: "Préparé", tone: "neutral" },
  send_requested: { label: "Envoi demandé", tone: "warn" },
  sent: { label: "Envoi effectué", tone: "info" },
  accepted: { label: "Acceptation confirmée", tone: "ok" },
  blocking: { label: "Bloquant", tone: "danger" },
  warning: { label: "À vérifier", tone: "warn" },
  info: { label: "Information", tone: "info" },
  resolved: { label: "Résolu", tone: "ok" },
  acknowledged: { label: "Pris en compte", tone: "neutral" },
  ignored: { label: "Ignoré", tone: "neutral" },
  questions: { label: "Questions", tone: "neutral" },
  drafted: { label: "Brouillon généré", tone: "info" },
  in_review: { label: "En relecture", tone: "warn" },
  signed: { label: "Signé", tone: "ok" },
  archived: { label: "Archivé", tone: "neutral" },
  not_configured: { label: "Non configuré", tone: "neutral" },
  requested: { label: "Demandé", tone: "warn" },
  declined: { label: "Refusé", tone: "danger" },
  expired: { label: "Expiré", tone: "neutral" },
  uploaded: { label: "Chargé", tone: "neutral" },
  mapped: { label: "Colonnes associées", tone: "info" },
  applied: { label: "Appliqué", tone: "ok" },
  failed: { label: "Échec", tone: "danger" },
  queued: { label: "En file", tone: "neutral" },
  running: { label: "En cours", tone: "info" },
  done: { label: "Terminé", tone: "ok" },
  skipped_not_configured: { label: "Non envoyé (non configuré)", tone: "warn" },
  upcoming: { label: "À venir", tone: "info" },
  in_progress: { label: "En cours", tone: "info" },
  planned: { label: "Planifié", tone: "neutral" },
};

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  const m = statusMeta[status] ?? { label: status, tone: "neutral" as Tone };
  return (
    <Badge tone={m.tone} className={className}>
      {m.label}
    </Badge>
  );
}
