"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Field, Select } from "@/components/ui/field";
import { startDraftAction } from "@/server/actions/drafting";
import { ActionResult, Hidden } from "./action-form";

export function StartDraftForm({ companyId, templateId, employees, needsEmployee, defaultEmployeeId }: { companyId: string; templateId: string; employees: { id: string; label: string }[]; needsEmployee: boolean; defaultEmployeeId?: string }) {
  const [state, action, pending] = useActionState(startDraftAction, {});
  return (
    <form action={action} className="space-y-4">
      <Hidden fields={{ companyId, templateId }} />
      {needsEmployee ? (
        <Field label="Salarié concerné" htmlFor="employeeId" required help="Seules les informations que vous êtes habilité à consulter seront reprises.">
          <Select id="employeeId" name="employeeId" required defaultValue={defaultEmployeeId ?? ""}>
            <option value="" disabled>
              Choisir un salarié
            </option>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>
                {e.label}
              </option>
            ))}
          </Select>
        </Field>
      ) : null}
      <ActionResult state={state} />
      <Button type="submit" loading={pending} disabled={needsEmployee && !employees.length}>
        Commencer : répondre aux questions
      </Button>
    </form>
  );
}
