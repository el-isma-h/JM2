"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/field";
import { updateVisibilityAction } from "@/server/actions/documents";
import { ActionResult, Hidden } from "./action-form";

export function VisibilityForm({ companyId, documentId, current, hasEmployee, canRestricted }: { companyId: string; documentId: string; current: string; hasEmployee: boolean; canRestricted: boolean }) {
  const [state, action, pending] = useActionState(updateVisibilityAction, {});
  return (
    <form action={action} className="space-y-2">
      <Hidden fields={{ companyId, documentId }} />
      <div className="flex items-center gap-2">
        <Select name="visibility" defaultValue={current} aria-label="Visibilité" className="max-w-56">
          <option value="company">Entreprise</option>
          {hasEmployee ? <option value="employee">Salarié</option> : null}
          {canRestricted || current === "restricted" ? <option value="restricted">Restreint</option> : null}
        </Select>
        <Button type="submit" variant="secondary" size="sm" loading={pending}>
          Modifier
        </Button>
      </div>
      <ActionResult state={state} />
    </form>
  );
}
