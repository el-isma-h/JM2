"use client";

import * as React from "react";
import { useActionState } from "react";
import { DownloadSimple } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { downloadLinkAction } from "@/server/actions/documents";

/** Téléchargement uniquement par lien temporaire (15 min), demandé au moment du clic. */
export function DownloadButton({ companyId, documentId, label = "Télécharger", variant = "ghost" }: { companyId: string; documentId: string; label?: string; variant?: "ghost" | "secondary" }) {
  const [state, action, pending] = useActionState(downloadLinkAction, {});
  React.useEffect(() => {
    if (state.ok && state.data?.url) window.location.assign(state.data.url);
  }, [state]);
  return (
    <form action={action} className="inline-flex flex-col items-end gap-1">
      <input type="hidden" name="companyId" value={companyId} />
      <input type="hidden" name="documentId" value={documentId} />
      <Button type="submit" variant={variant} size="sm" loading={pending} aria-label={`${label} (lien valable 15 minutes)`}>
        {pending ? null : <DownloadSimple size={15} />}
        {label}
      </Button>
      {state.error ? <span className="text-[12px] text-danger-ink">{state.error}</span> : null}
    </form>
  );
}
