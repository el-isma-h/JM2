import * as React from "react";
import { cn } from "@/lib/utils";
import { parseMarkdown, type Inline } from "@/server/documents/markdown";

function Inlines({ items }: { items: Inline[] }) {
  return (
    <>
      {items.map((i, k) =>
        i.marker ? (
          <mark key={k} className="rounded-none bg-warn-soft px-1 py-px font-medium text-warn-ink">
            {i.text}
          </mark>
        ) : i.bold ? (
          <strong key={k} className="font-semibold">
            {i.text}
          </strong>
        ) : (
          <React.Fragment key={k}>{i.text}</React.Fragment>
        ),
      )}
    </>
  );
}

/** Aperçu du brouillon : rendu sûr (aucun HTML interprété), marqueurs surlignés. */
export function MarkdownPreview({ source, className }: { source: string; className?: string }) {
  const blocks = parseMarkdown(source);
  return (
    <div className={cn("max-w-[72ch] text-[13.5px] leading-relaxed text-ink", className)}>
      {blocks.map((b, i) => {
        if (b.type === "heading") {
          const H = (`h${Math.min(3, b.level + 1)}` as "h2" | "h3");
          return (
            <H key={i} className={cn("font-semibold text-ink", b.level === 1 ? "mb-3 text-[17px]" : "mb-2 mt-5 text-[14.5px]")}>
              <Inlines items={b.inlines} />
            </H>
          );
        }
        if (b.type === "list") {
          return (
            <ul key={i} className="mb-3 list-disc space-y-1 pl-5">
              {b.items.map((it, j) => (
                <li key={j}>
                  <Inlines items={it} />
                </li>
              ))}
            </ul>
          );
        }
        if (b.type === "rule") return <hr key={i} className="my-4 border-line" />;
        return (
          <p key={i} className="mb-3 whitespace-pre-line">
            <Inlines items={b.inlines} />
          </p>
        );
      })}
    </div>
  );
}
