"use client";

import * as React from "react";
import { useActionState } from "react";
import { Button, type ButtonProps } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Notice } from "@/components/ui/surface";
import type { ActionState } from "@/server/actions/auth";

type Action = (prev: ActionState, fd: FormData) => Promise<ActionState>;

/** Résultat d'action affiché sous le formulaire. */
export function ActionResult({ state, className }: { state: ActionState; className?: string }) {
  if (state.error) return <Notice tone="danger" className={className}>{state.error}</Notice>;
  if (state.ok && state.message) return <Notice tone="ok" className={className}>{state.message}</Notice>;
  return null;
}

export function Hidden({ fields }: { fields: Record<string, string | number | undefined | null> }) {
  return (
    <>
      {Object.entries(fields).map(([k, v]) => (v === undefined || v === null ? null : <input key={k} type="hidden" name={k} value={String(v)} />))}
    </>
  );
}

/** Bouton déclenchant une server action, avec confirmation optionnelle dans une boîte de dialogue. */
export function ActionButton({
  action,
  fields,
  label,
  variant = "secondary",
  size = "sm",
  confirm,
  disabled,
  children,
}: {
  action: Action;
  fields: Record<string, string | number | undefined | null>;
  label: string;
  variant?: ButtonProps["variant"];
  size?: ButtonProps["size"];
  confirm?: { title: string; description: string; confirmLabel: string };
  disabled?: boolean;
  children?: React.ReactNode;
}) {
  const [open, setOpen] = React.useState(false);
  const [state, formAction, pending] = useActionState(async (prev: ActionState, fd: FormData) => {
    const res = await action(prev, fd);
    setOpen(false);
    return res;
  }, {});
  const form = (
    <form action={formAction} className={confirm ? "mt-2 space-y-4" : "inline"}>
      <Hidden fields={fields} />
      {children}
      {confirm ? (
        <div className="flex justify-end gap-2">
          <DialogClose asChild>
            <Button type="button" variant="ghost" size="sm">
              Annuler
            </Button>
          </DialogClose>
          <Button type="submit" variant={variant === "danger" ? "danger" : "primary"} size="sm" loading={pending}>
            {confirm.confirmLabel}
          </Button>
        </div>
      ) : (
        <Button type="submit" variant={variant} size={size} loading={pending} disabled={disabled}>
          {label}
        </Button>
      )}
    </form>
  );
  return (
    <div className="space-y-2">
      {confirm ? (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button type="button" variant={variant} size={size} disabled={disabled}>
              {label}
            </Button>
          </DialogTrigger>
          <DialogContent title={confirm.title} description={confirm.description}>
            {form}
          </DialogContent>
        </Dialog>
      ) : (
        form
      )}
      <ActionResult state={state} />
    </div>
  );
}
