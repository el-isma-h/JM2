"use client";

import * as React from "react";
import { useActionState } from "react";
import { Eye, PencilSimple } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/field";
import { cn } from "@/lib/utils";
import { saveDraftAction } from "@/server/actions/drafting";
import { listMarkers } from "@/server/documents/render";
import { ActionResult, Hidden } from "./action-form";
import { MarkdownPreview } from "./markdown-preview";

/** Étape 5 : brouillon modifiable (Markdown simple) avec aperçu. Chaque enregistrement crée une version.
 * Le parent passe une `key` liée à la version pour réinitialiser l'éditeur après enregistrement. */
export function DraftEditor({ companyId, draftId, body, locked }: { companyId: string; draftId: string; body: string; locked: boolean }) {
  const [state, action, pending] = useActionState(saveDraftAction, {});
  const [text, setText] = React.useState(body);
  const [view, setView] = React.useState<"edit" | "preview">(locked ? "preview" : "edit");
  const markers = listMarkers(text);
  const dirty = text !== body;

  return (
    <form action={action} className="flex flex-col">
      <Hidden fields={{ companyId, draftId }} />
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-5 py-2.5">
        <div role="tablist" aria-label="Mode d'affichage" className="flex gap-1">
          {(
            [
              ["edit", "Modifier", PencilSimple],
              ["preview", "Aperçu", Eye],
            ] as const
          ).map(([k, label, Icon]) => (
            <button
              key={k}
              type="button"
              role="tab"
              aria-selected={view === k}
              disabled={k === "edit" && locked}
              onClick={() => setView(k)}
              className={cn(
                "inline-flex h-8 items-center gap-1.5 rounded-[var(--radius-sm)] px-3 text-[13px] font-medium transition-colors disabled:opacity-50",
                view === k ? "bg-bg-muted text-ink" : "text-ink-2 hover:bg-bg-sunken hover:text-ink",
              )}
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
        </div>
        <span className={cn("text-[12.5px]", markers.length ? "text-warn-ink" : "text-ok-ink")}>
          {markers.length ? `${markers.length} élément(s) à compléter` : "Aucun élément à compléter"}
        </span>
      </div>
      <div className={cn(view === "edit" ? "block" : "hidden", "p-5")}>
        <label htmlFor="draft-body" className="sr-only">
          Contenu du brouillon
        </label>
        <Textarea
          id="draft-body"
          name="body"
          value={text}
          onChange={(e) => setText(e.target.value)}
          readOnly={locked}
          spellCheck
          className="num min-h-[520px] text-[13px] leading-[1.65]"
        />
        <p className="mt-2 text-[12px] text-ink-3">
          Syntaxe : « # » pour un titre, « - » pour une liste, **texte** pour le gras. Remplacez chaque « [À COMPLÉTER : …] » par l&apos;information vérifiée.
        </p>
      </div>
      {view === "preview" ? (
        <div className="p-6">
          <MarkdownPreview source={text} />
        </div>
      ) : null}
      {!locked ? (
        <div className="flex flex-wrap items-center justify-end gap-2 border-t border-line px-5 py-3">
          <label htmlFor="draft-note" className="sr-only">
            Note de version
          </label>
          <Input id="draft-note" name="note" placeholder="Note de version (facultatif)" className="h-8 max-w-64 text-[13px]" maxLength={120} />
          <Button type="submit" size="sm" loading={pending} disabled={!dirty}>
            Enregistrer la version
          </Button>
        </div>
      ) : (
        <p className="border-t border-line px-5 py-3 text-[12.5px] text-ink-2">Document signé ou archivé : il n&apos;est plus modifiable.</p>
      )}
      <ActionResult state={state} className="mx-5 mb-4" />
    </form>
  );
}
