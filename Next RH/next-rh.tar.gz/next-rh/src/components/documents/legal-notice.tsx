import { Scales } from "@phosphor-icons/react/ssr";
import { LEGAL_WARNING } from "@/server/documents/drafting";

/** Avertissement affiché sur tout modèle à enjeu juridique, avec la liste des points à faire valider. */
export function LegalNotice({ points, verifiedNote }: { points: string[]; verifiedNote: string | null }) {
  return (
    <section aria-label="Validation juridique" className="rounded-[var(--radius-sm)] bg-warn-soft px-4 py-3 text-[13.5px] text-warn-ink">
      <p className="flex items-center gap-2 font-semibold">
        <Scales size={16} />
        {LEGAL_WARNING}
      </p>
      {points.length ? (
        <>
          <p className="mt-2">Points à faire vérifier par une personne compétente :</p>
          <ul className="mt-1 list-disc space-y-1 pl-5">
            {points.map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
        </>
      ) : null}
      {verifiedNote ? <p className="mt-2 text-[12.5px] opacity-90">{verifiedNote}</p> : null}
    </section>
  );
}
