"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { answerQuestionsAction } from "@/server/actions/drafting";
import type { TemplateQuestion } from "@/server/documents/templates-data";
import { ActionResult, Hidden } from "./action-form";

/** Étape 2 : questions définies par le modèle. Une réponse laissée vide reste un marqueur visible. */
export function QuestionsForm({
  companyId,
  draftId,
  questions,
  answers,
  regenerate,
  disabled,
}: {
  companyId: string;
  draftId: string;
  questions: TemplateQuestion[];
  answers: Record<string, string>;
  regenerate: boolean;
  disabled?: boolean;
}) {
  const [state, action, pending] = useActionState(answerQuestionsAction, {});
  return (
    <form action={action} className="space-y-4">
      <Hidden fields={{ companyId, draftId }} />
      {questions.length ? (
        <div className="grid gap-4 md:grid-cols-2">
          {questions.map((q) => {
            const id = `q_${q.key}`;
            const common = { id, name: id, defaultValue: answers[q.key] ?? "", disabled };
            return (
              <Field key={q.key} label={q.label} htmlFor={id} required={q.required} help={q.help} className={q.type === "textarea" ? "md:col-span-2" : undefined}>
                {q.type === "textarea" ? (
                  <Textarea {...common} rows={4} />
                ) : q.type === "select" ? (
                  <Select {...common}>
                    <option value="">Choisir</option>
                    {q.options?.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </Select>
                ) : (
                  <Input {...common} type={q.type === "date" ? "date" : q.type === "number" ? "number" : "text"} />
                )}
              </Field>
            );
          })}
        </div>
      ) : (
        <p className="text-[13px] text-ink-2">Ce modèle ne pose pas de question : les données de l&apos;entreprise et du salarié suffisent.</p>
      )}
      <p className="text-[12.5px] text-ink-3">
        Les champs marqués d&apos;un astérisque sont attendus dans le document. Laissés vides, ils apparaissent comme « À COMPLÉTER » : rien n&apos;est inventé.
      </p>
      <ActionResult state={state} />
      <div className="flex justify-end">
        <Button type="submit" loading={pending} disabled={disabled}>
          {regenerate ? "Regénérer le brouillon" : "Générer le brouillon"}
        </Button>
      </div>
      {regenerate ? <p className="text-right text-[12px] text-ink-3">La version actuelle est conservée dans l&apos;historique.</p> : null}
    </form>
  );
}
