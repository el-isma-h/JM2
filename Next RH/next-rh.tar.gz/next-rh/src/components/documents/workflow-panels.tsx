"use client";

import * as React from "react";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Select, Textarea } from "@/components/ui/field";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Notice } from "@/components/ui/surface";
import { decideReviewAction, exportDraftAction, improveDraftAction, requestSignatureAction, submitReviewAction } from "@/server/actions/drafting";
import { ActionButton, ActionResult, Hidden } from "./action-form";
import type { ActionState } from "@/server/actions/auth";

type Ids = { companyId: string; draftId: string };

/** Étape 6a : envoi en relecture à un membre. */
export function SubmitReviewForm({ ids, candidates, disabled }: { ids: Ids; candidates: { id: string; name: string; role: string }[]; disabled?: boolean }) {
  const [state, action, pending] = useActionState(submitReviewAction, {});
  if (!candidates.length) {
    return <Notice tone="warn">Aucun autre membre ne peut relire les documents de l&apos;entreprise. Invitez un membre RH, paie ou administrateur dans les paramètres.</Notice>;
  }
  return (
    <form action={action} className="space-y-3">
      <Hidden fields={ids} />
      <Field label="Relecteur" htmlFor="reviewerId" required>
        <Select id="reviewerId" name="reviewerId" defaultValue="" required disabled={disabled}>
          <option value="" disabled>
            Choisir un membre
          </option>
          {candidates.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Message" htmlFor="message" help="Facultatif : précisez ce qu'il faut vérifier.">
        <Textarea id="message" name="message" rows={2} maxLength={1000} disabled={disabled} />
      </Field>
      <ActionResult state={state} />
      <Button type="submit" size="sm" loading={pending} disabled={disabled}>
        Envoyer en relecture
      </Button>
    </form>
  );
}

/** Étape 6b : décision du relecteur désigné, avec commentaire. */
export function DecideReviewForm({ ids, canApprove }: { ids: Ids; canApprove: boolean }) {
  const [state, action, pending] = useActionState(decideReviewAction, {});
  const [decision, setDecision] = React.useState<"approved" | "rejected">(canApprove ? "approved" : "rejected");
  return (
    <form action={action} className="space-y-3">
      <Hidden fields={{ ...ids, decision }} />
      <div role="radiogroup" aria-label="Décision" className="flex gap-2">
        <Button type="button" size="sm" variant={decision === "approved" ? "primary" : "secondary"} onClick={() => setDecision("approved")} disabled={!canApprove} aria-pressed={decision === "approved"}>
          Valider
        </Button>
        <Button type="button" size="sm" variant={decision === "rejected" ? "danger" : "secondary"} onClick={() => setDecision("rejected")} aria-pressed={decision === "rejected"}>
          Refuser
        </Button>
      </div>
      {!canApprove ? <p className="text-[12.5px] text-warn-ink">Validation impossible tant que des éléments restent à compléter.</p> : null}
      <Field label="Commentaire" htmlFor="comment" required={decision === "rejected"} help={decision === "rejected" ? "Obligatoire : il est transmis au rédacteur." : "Facultatif."}>
        <Textarea id="comment" name="comment" rows={3} maxLength={2000} required={decision === "rejected"} />
      </Field>
      <ActionResult state={state} />
      <Button type="submit" size="sm" loading={pending}>
        Enregistrer la décision
      </Button>
    </form>
  );
}

/** Étape 7 : export PDF et DOCX. */
export function ExportForm({ ids, isLegal, defaultVisibility, hasEmployee, canRestricted, disabled }: { ids: Ids; isLegal: boolean; defaultVisibility: string; hasEmployee: boolean; canRestricted: boolean; disabled?: boolean }) {
  const [state, action, pending] = useActionState(exportDraftAction, {});
  return (
    <form action={action} className="space-y-3">
      <Hidden fields={ids} />
      <Field label="Visibilité des fichiers" htmlFor="visibility">
        <Select id="visibility" name="visibility" defaultValue={defaultVisibility} disabled={disabled}>
          <option value="company">Entreprise</option>
          {hasEmployee ? <option value="employee">Salarié (visible dans son espace)</option> : null}
          {canRestricted ? <option value="restricted">Restreint</option> : null}
        </Select>
      </Field>
      {isLegal ? (
        <Checkbox name="legalAck" required disabled={disabled} label="Je confirme que ce document sera validé par un juriste ou un avocat avant signature." />
      ) : null}
      <ActionResult state={state} />
      <Button type="submit" size="sm" loading={pending} disabled={disabled}>
        Exporter en PDF et DOCX
      </Button>
    </form>
  );
}

/** Signature électronique : confirmation explicite, message exact si non configurée. */
export function SignatureButton({ ids, configured, isLegal, isDemo, disabled }: { ids: Ids; configured: boolean; isLegal: boolean; isDemo: boolean; disabled?: boolean }) {
  const [open, setOpen] = React.useState(false);
  const [state, action, pending] = useActionState(async (prev: ActionState, fd: FormData) => {
    const res = await requestSignatureAction(prev, fd);
    setOpen(false);
    return res;
  }, {});
  return (
    <div className="space-y-2">
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="secondary" size="sm" disabled={disabled}>
            Envoyer en signature
          </Button>
        </DialogTrigger>
        <DialogContent
          title="Envoyer en signature"
          description={
            isDemo
              ? "Démonstration : la demande sera enregistrée mais rien ne sera envoyé."
              : configured
                ? "Le PDF exporté sera transmis au prestataire de signature, avec l'employeur et le salarié comme signataires."
                : "La signature électronique n'est pas configurée : la demande sera enregistrée avec le statut « Non configuré » et rien ne sera envoyé."
          }
        >
          <form action={action} className="space-y-4">
            <Hidden fields={ids} />
            {isLegal ? <Notice tone="warn">À faire valider par un juriste ou un avocat avant signature.</Notice> : null}
            <div className="flex justify-end gap-2">
              <DialogClose asChild>
                <Button type="button" variant="ghost" size="sm">
                  Annuler
                </Button>
              </DialogClose>
              <Button type="submit" size="sm" loading={pending}>
                Confirmer l&apos;envoi
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      <ActionResult state={state} />
    </div>
  );
}

/** Reformulation IA (documents non juridiques uniquement). */
export function ImproveButton({ ids, aiConfigured, allowed, notConfiguredMessage, disabled }: { ids: Ids; aiConfigured: boolean; allowed: boolean; notConfiguredMessage: string; disabled?: boolean }) {
  if (!allowed) return <p className="text-[12.5px] text-ink-2">Document juridique : la reformulation automatique est désactivée pour ne pas altérer les mentions.</p>;
  if (!aiConfigured) return <Notice tone="info">{notConfiguredMessage}</Notice>;
  return (
    <ActionButton
      action={improveDraftAction}
      fields={ids}
      label="Améliorer la rédaction"
      disabled={disabled}
      confirm={{
        title: "Améliorer la rédaction",
        description: "Le texte est reformulé sans ajout d'information. Les marqueurs à compléter sont conservés. Le résultat est enregistré comme nouvelle version, restaurable.",
        confirmLabel: "Reformuler",
      }}
    />
  );
}
