"use client";

import * as React from "react";
import { useActionState } from "react";
import { UploadSimple } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Field, Input, Select } from "@/components/ui/field";
import { uploadDocumentsAction } from "@/server/actions/documents";
import { ACCEPT_ATTR, ALLOWED_LABEL } from "@/server/documents/upload-rules";
import { ActionResult, Hidden } from "./action-form";
import type { ActionState } from "@/server/actions/auth";

type Opt = { value: string; label: string };

export function UploadDialog({
  companyId,
  categories,
  employees,
  canRestricted,
  previous,
  triggerLabel = "Déposer des documents",
}: {
  companyId: string;
  categories: Opt[];
  employees: Opt[];
  canRestricted: boolean;
  previous?: { id: string; title: string; category: string; visibility: string; employeeId: string | null };
  triggerLabel?: string;
}) {
  const [open, setOpen] = React.useState(false);
  const [state, action, pending] = useActionState(async (prev: ActionState, fd: FormData) => {
    const res = await uploadDocumentsAction(prev, fd);
    if (res.ok) setOpen(false);
    return res;
  }, {});
  const [visibility, setVisibility] = React.useState(previous?.visibility ?? "company");
  const [names, setNames] = React.useState<string[]>([]);

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant={previous ? "secondary" : "primary"} size={previous ? "sm" : "md"}>
            <UploadSimple size={16} />
            {triggerLabel}
          </Button>
        </DialogTrigger>
        <DialogContent
          title={previous ? `Nouvelle version : ${previous.title}` : "Déposer des documents"}
          description={`Formats acceptés : ${ALLOWED_LABEL}. 20 Mo maximum par fichier. Le contenu de chaque fichier est vérifié.`}
        >
          <form action={action} className="space-y-4">
            <Hidden fields={{ companyId, previousVersionId: previous?.id }} />
            <Field label={previous ? "Fichier" : "Fichiers"} htmlFor="files" required help={previous ? "La version actuelle reste consultable dans l'historique." : "Jusqu'à 10 fichiers, classés dans la même catégorie."}>
              <Input
                id="files"
                name="files"
                type="file"
                accept={ACCEPT_ATTR}
                multiple={!previous}
                required
                className="h-auto py-2 file:mr-3 file:rounded-[var(--radius-sm)] file:border-0 file:bg-bg-muted file:px-3 file:py-1 file:text-[13px] file:text-ink"
                onChange={(e) => setNames(Array.from(e.currentTarget.files ?? []).map((f) => f.name))}
              />
            </Field>
            {names.length > 1 ? <p className="text-[12.5px] text-ink-2">{names.length} fichiers sélectionnés.</p> : null}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Catégorie" htmlFor="category" required>
                <Select id="category" name="category" defaultValue={previous?.category ?? "autre"}>
                  {categories.map((c) => (
                    <option key={c.value} value={c.value}>
                      {c.label}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field
                label="Visibilité"
                htmlFor="visibility"
                required
                help={
                  visibility === "restricted"
                    ? "Réservé aux habilités salaires ou validation de paie."
                    : visibility === "employee"
                      ? "Le salarié le verra dans son espace."
                      : "Visible par les gestionnaires habilités aux documents."
                }
              >
                <Select id="visibility" name="visibility" value={visibility} onChange={(e) => setVisibility(e.target.value)}>
                  <option value="company">Entreprise</option>
                  <option value="employee">Salarié</option>
                  {canRestricted ? <option value="restricted">Restreint</option> : null}
                </Select>
              </Field>
            </div>
            {!previous ? (
              <>
                <Field label="Salarié concerné" htmlFor="employeeId" help="Facultatif, sauf pour une visibilité « Salarié ».">
                  <Select id="employeeId" name="employeeId" defaultValue="" required={visibility === "employee"}>
                    <option value="">Aucun (document d&apos;entreprise)</option>
                    {employees.map((e) => (
                      <option key={e.value} value={e.value}>
                        {e.label}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Titre" htmlFor="title" help="Laissez vide pour reprendre le nom du fichier.">
                  <Input id="title" name="title" maxLength={200} />
                </Field>
              </>
            ) : null}
            <ActionResult state={state} />
            <div className="flex justify-end gap-2">
              <DialogClose asChild>
                <Button type="button" variant="ghost">
                  Annuler
                </Button>
              </DialogClose>
              <Button type="submit" loading={pending}>
                Enregistrer
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      {state.ok && state.message ? <ActionResult state={state} className="mt-2" /> : null}
    </>
  );
}
