"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import { Button } from "@/components/ui/button";
import { FiletMarque, Logo } from "@/components/ui/logo";

type Plan = { code: string; name: string; description: string; isService: boolean; price: string; unit: string; reference: string | null };

const EASE = [0.165, 0.84, 0.44, 1] as const;

const steps = [
  { title: "Créer l'entreprise", text: "SIREN, convention collective, établissements, organismes. Un assistant pose les questions, vous confirmez ce qui compte pour la paie." },
  { title: "Intégrer les salariés", text: "Dossiers structurés, contrats et avenants, reprise des cumuls en cours d'année avec contrôle des doublons." },
  { title: "Collecter et produire", text: "Variables du mois, absences, heures. Calcul par un moteur déterministe versionné, anomalies expliquées, validation avant finalisation." },
  { title: "Distribuer et archiver", text: "Bulletins dans l'espace de chaque salarié, exports comptables, déclarations préparées avec leur statut réel." },
];

export function Marketing({ isLoggedIn, plans }: { isLoggedIn: boolean; plans: Plan[] }) {
  const reduce = useReducedMotion();
  const enter = (i: number) => ({
    initial: reduce ? false : { opacity: 0, y: 18 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: "-60px" },
    transition: { duration: 0.8, delay: i * 0.08, ease: EASE },
  });
  const software = plans.filter((p) => !p.isService);
  const services = plans.filter((p) => p.isService);
  const cible = isLoggedIn ? "/app" : "/inscription";

  return (
    <div className="min-h-[100dvh] bg-bg text-ink">
      <header className="sticky top-0 z-40 border-b border-line bg-bg/92 backdrop-blur-sm">
        <div className="mx-auto flex h-16 w-full max-w-[1400px] items-center justify-between px-5 sm:px-10">
          <Link href="/" aria-label="Next RH">
            <Logo />
          </Link>
          <nav className="flex items-center gap-6" aria-label="Navigation">
            <Link href="#parcours" className="hidden font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors duration-500 hover:text-ink sm:block">
              Parcours
            </Link>
            <Link href="#tarifs" className="hidden font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors duration-500 hover:text-ink sm:block">
              Tarifs
            </Link>
            <Link href={isLoggedIn ? "/app" : "/connexion"} className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors duration-500 hover:text-ink">
              <span className="opacity-50">[</span> {isLoggedIn ? "Mon espace" : "Connexion"} <span className="opacity-50">]</span>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero : titre géant Archivo, à la NEXT Capital */}
      <section className="mx-auto w-full max-w-[1400px] px-5 pb-20 pt-16 sm:px-10 lg:pt-24">
        <motion.p {...enter(0)} className="etiquette">
          Paie · ressources humaines · documents
        </motion.p>
        <motion.h1 {...enter(1)} className="titre-geant mt-8 max-w-[14ch] text-[13vw] sm:text-[72px] lg:text-[96px]">
          Une seule plateforme.
        </motion.h1>
        <div className="mt-10 grid gap-8 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)] lg:items-end">
          <motion.p {...enter(2)} className="max-w-[48ch] font-serif text-[24px] italic leading-snug text-ink-2 sm:text-[28px]">
            La paie, les ressources humaines et vos documents réunis. Pour les entreprises françaises et les cabinets qui en gèrent plusieurs.
          </motion.p>
          <motion.div {...enter(3)} className="flex flex-wrap gap-3 lg:justify-end">
            <Button asChild size="lg">
              <Link href={cible}>{isLoggedIn ? "Ouvrir mon espace" : "Créer mon compte"}</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href="/demo">Explorer la démonstration</Link>
            </Button>
          </motion.div>
        </div>
        <motion.div {...enter(4)} className="mt-14">
          <FiletMarque />
        </motion.div>
      </section>

      {/* Parcours : bande encre */}
      <section id="parcours" className="bg-encre text-os">
        <div className="mx-auto grid w-full max-w-[1400px] gap-12 px-5 py-24 sm:px-10 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
          <motion.div {...enter(0)}>
            <p className="etiquette !text-os/50">Parcours</p>
            <h2 className="mt-6 text-[34px] sm:text-[44px]">
              Un parcours complet,
              <br />
              pas une vitrine.
            </h2>
            <p className="mt-6 max-w-[46ch] text-[15px] text-os/70">
              Chaque étape écrit dans la suivante. L&apos;entreprise est créée, les salariés sont intégrés, les variables sont collectées, la paie est calculée puis validée, les documents sont rédigés et archivés.
            </p>
          </motion.div>
          <ol>
            {steps.map((s, i) => (
              <motion.li key={s.title} {...enter(i + 1)} className="grid grid-cols-[3rem_1fr] gap-5 border-t border-os/15 py-7 last:border-b">
                <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-accent-strong">0{i + 1}</span>
                <div>
                  <p className="font-display text-[20px] font-light uppercase tracking-[0.06em] text-os">{s.title}</p>
                  <p className="mt-2 max-w-[62ch] text-[14.5px] text-os/65">{s.text}</p>
                </div>
              </motion.li>
            ))}
          </ol>
        </div>
      </section>

      {/* Principes */}
      <section className="mx-auto w-full max-w-[1400px] px-5 py-24 sm:px-10">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
          <motion.div {...enter(0)} className="border-t border-line-strong pt-8">
            <p className="etiquette">Exactitude</p>
            <h2 className="mt-5 text-[26px] sm:text-[32px]">Les montants légaux ne sont jamais calculés librement.</h2>
            <p className="mt-5 text-[15px] text-ink-2">
              Le moteur de paie est déterministe, versionné et reproductible : mêmes entrées, mêmes paramètres, même résultat, avec la date d&apos;effet de chaque règle. Les cas non couverts bloquent la finalisation et le disent.
            </p>
          </motion.div>
          <motion.div {...enter(1)} className="border-t border-line-strong pt-8">
            <p className="etiquette">Assistant</p>
            <h2 className="mt-5 text-[26px] sm:text-[32px]">L&apos;assistant aide, les habilitations décident.</h2>
            <p className="mt-5 text-[15px] text-ink-2">
              « Prépare la paie de ce mois-ci », « Quels éléments manquent avant validation ? », « Prépare une attestation pour ce salarié ». L&apos;assistant collecte, explique, rédige et contrôle, sans jamais révéler une rémunération à quelqu&apos;un qui n&apos;y a pas droit.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Tarifs */}
      <section id="tarifs" className="border-t border-line bg-bg-sunken">
        <div className="mx-auto w-full max-w-[1400px] px-5 py-24 sm:px-10">
          <motion.div {...enter(0)} className="max-w-[60ch]">
            <p className="etiquette">Tarifs</p>
            <h2 className="mt-5 text-[30px] sm:text-[40px]">Dix pour cent sous le marché de référence.</h2>
            <p className="mt-5 text-[15px] text-ink-2">
              Prix HT, par salarié et par mois sauf mention contraire, sans engagement, décompte mensuel. Les fonctions incluses sont séparées des services d&apos;accompagnement humain.
            </p>
          </motion.div>
          <motion.div {...enter(1)} className="mt-12 overflow-x-auto">
            <table className="data-table min-w-[640px] text-[14px]">
              <thead>
                <tr>
                  <th>Module</th>
                  <th>Ce qu&apos;il couvre</th>
                  <th className="num">Prix Next RH</th>
                  <th>Unité</th>
                </tr>
              </thead>
              <tbody>
                {software.map((p) => (
                  <tr key={p.code}>
                    <td className="font-medium text-ink">{p.name}</td>
                    <td className="max-w-[40ch] text-ink-2">{p.description}</td>
                    <td className="num font-medium text-ink">{p.price}</td>
                    <td className="text-ink-2">{p.unit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </motion.div>
          {services.length ? (
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {services.map((p) => (
                <div key={p.code} className="border-t border-line-strong pt-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Accompagnement humain</p>
                  <p className="mt-2 font-display text-[18px] font-light uppercase tracking-[0.05em] text-ink">{p.name}</p>
                  <p className="mt-1 text-[13px] text-ink-2">{p.price}</p>
                </div>
              ))}
            </div>
          ) : null}
          <p className="mt-8 text-[12.5px] text-ink-3">
            Les modules sans équivalent public chez la référence (production de paie, déclarations) sont proposés sur devis, avec une comparaison établie à partir d&apos;un devis réel.
          </p>
        </div>
      </section>

      {/* Pied de page encre avec monogramme géant */}
      <footer className="bg-encre text-os">
        <div className="mx-auto grid w-full max-w-[1400px] gap-12 px-5 py-20 sm:px-10 lg:grid-cols-[1fr_2fr]">
          <div className="flex flex-col justify-between gap-10">
            <svg viewBox="0 0 32 32" className="h-32 w-32 sm:h-44 sm:w-44" aria-hidden="true">
              <path d="M6 28V4l20 24V4" fill="none" stroke="#F3F0E8" strokeWidth="2.2" strokeLinecap="square" />
              <rect x="23" y="4" width="3" height="3" fill="#C9475A" />
            </svg>
            <div>
              <FiletMarque />
              <p className="mt-6 max-w-sm font-serif text-xl italic text-os/70">La paie, les ressources humaines et vos documents réunis dans une seule plateforme.</p>
            </div>
          </div>
          <div className="grid gap-10 sm:grid-cols-3">
            {[
              ["Produit", [["/#parcours", "Parcours"], ["/#tarifs", "Tarifs"], ["/demo", "Démonstration"]]],
              ["Compte", [["/inscription", "Créer mon compte"], ["/connexion", "Connexion"]]],
              ["Confiance", [["/demo", "Données fictives en démo"], ["/#parcours", "Moteur de paie vérifié"]]],
            ].map(([titre, liens]) => (
              <div key={titre as string}>
                <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-os/40">{titre as string}</p>
                <ul className="mt-5 space-y-2.5">
                  {(liens as [string, string][]).map(([h, l]) => (
                    <li key={h + l}>
                      <Link href={h} className="font-mono text-[11px] uppercase tracking-[0.16em] text-os/70 transition-colors duration-500 hover:text-accent-strong">
                        {l}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="border-t border-os/10">
          <div className="mx-auto flex w-full max-w-[1400px] flex-wrap justify-between gap-4 px-5 py-6 font-mono text-[10px] uppercase tracking-[0.18em] text-os/45 sm:px-10">
            <span>© {new Date().getFullYear()} Next RH</span>
            <span>Hébergement en France recommandé</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
