/** Libellés métier en français clair (partagés serveur / client). */

export const contractTypeLabels: Record<string, string> = {
  CDI: "CDI",
  CDD: "CDD",
  APPRENTISSAGE: "Apprentissage",
  PROFESSIONNALISATION: "Professionnalisation",
  STAGE: "Stage",
  INTERIM: "Intérim",
  MANDAT: "Mandat social",
};

export const categoryLabels: Record<string, string> = {
  non_cadre: "Non-cadre",
  cadre: "Cadre",
  cadre_dirigeant: "Cadre dirigeant",
  apprenti: "Apprenti",
  stagiaire: "Stagiaire",
};

export const workTimeModeLabels: Record<string, string> = {
  heures: "En heures",
  forfait_jours: "Forfait jours",
  forfait_heures: "Forfait heures",
};

export const salaryBasisLabels: Record<string, string> = {
  monthly: "Mensuel",
  hourly: "Horaire",
  annual: "Annuel",
};

export const statusLabels: Record<string, string> = {
  draft: "Brouillon",
  active: "Actif",
  suspended: "Contrat suspendu",
  left: "Sorti",
};

export const genderLabels: Record<string, string> = { F: "Femme", M: "Homme", X: "Non précisé" };

export const eventKindLabels: Record<string, string> = {
  entree: "Entrée",
  reprise: "Reprise du dossier",
  remuneration: "Rémunération",
  contrat: "Contrat",
  avenant: "Avenant",
  temps_travail: "Temps de travail",
  classification: "Classification",
  poste: "Poste et établissement",
  suspension: "Suspension du contrat",
  reprise_activite: "Reprise d'activité",
  sortie: "Sortie",
  identite: "Identité",
  banque: "Coordonnées bancaires",
};

export const exitReasons: { value: string; label: string; docs: string[] }[] = [
  { value: "demission", label: "Démission", docs: ["Certificat de travail", "Attestation France Travail", "Solde de tout compte", "Lettre d'accusé de réception de la démission"] },
  { value: "rupture_conventionnelle", label: "Rupture conventionnelle", docs: ["Convention de rupture homologuée", "Certificat de travail", "Attestation France Travail", "Solde de tout compte"] },
  { value: "licenciement_personnel", label: "Licenciement pour motif personnel", docs: ["Lettre de licenciement", "Certificat de travail", "Attestation France Travail", "Solde de tout compte"] },
  { value: "licenciement_economique", label: "Licenciement pour motif économique", docs: ["Lettre de licenciement", "Certificat de travail", "Attestation France Travail", "Solde de tout compte", "Information sur le contrat de sécurisation professionnelle"] },
  { value: "fin_cdd", label: "Fin de CDD", docs: ["Certificat de travail", "Attestation France Travail", "Solde de tout compte (avec indemnité de fin de contrat si due)"] },
  { value: "fin_periode_essai", label: "Rupture de la période d'essai", docs: ["Courrier de rupture de période d'essai", "Certificat de travail", "Attestation France Travail", "Solde de tout compte"] },
  { value: "retraite", label: "Départ à la retraite", docs: ["Certificat de travail", "Solde de tout compte", "Calcul de l'indemnité de départ"] },
  { value: "fin_apprentissage", label: "Fin d'apprentissage", docs: ["Certificat de travail", "Attestation France Travail", "Solde de tout compte"] },
  { value: "autre", label: "Autre motif", docs: ["Certificat de travail", "Solde de tout compte"] },
];

export const exitReasonLabel = (v: string | null | undefined) => exitReasons.find((r) => r.value === v)?.label ?? v ?? "-";

export const roleLabels: Record<string, string> = {
  owner: "Propriétaire",
  admin: "Administrateur",
  hr: "Ressources humaines",
  payroll: "Gestionnaire de paie",
  manager: "Manager",
  accountant: "Expert-comptable",
  employee: "Salarié",
  viewer: "Lecture seule",
};

export const roleDescriptions: Record<string, string> = {
  owner: "Tous les droits, y compris la gestion des membres.",
  admin: "Tous les droits, y compris la gestion des membres.",
  hr: "Dossiers salariés, salaires, documents et validation des demandes. Ne valide pas la paie.",
  payroll: "Prépare, valide et clôture la paie. Voit les coordonnées bancaires.",
  manager: "Voit son équipe et valide ses demandes. Ne voit pas les salaires.",
  accountant: "Prépare, valide et clôture la paie pour le compte du client.",
  employee: "Accès à son seul espace salarié.",
  viewer: "Consultation sans modification, sans les salaires.",
};

export const organismKindLabels: Record<string, string> = {
  urssaf: "URSSAF",
  retraite: "Retraite complémentaire",
  mutuelle: "Mutuelle (frais de santé)",
  prevoyance: "Prévoyance",
  medecine_travail: "Médecine du travail",
  formation: "Formation (OPCO)",
  autre: "Autre",
};

export const contactRoleLabels: Record<string, string> = {
  dirigeant: "Dirigeant",
  rh: "Ressources humaines",
  paie: "Paie",
  comptable: "Comptabilité",
  informatique: "Informatique",
  autre: "Autre",
};

export const legalFormLabels: Record<string, string> = {
  SAS: "SAS",
  SASU: "SASU",
  SARL: "SARL",
  EURL: "EURL",
  SA: "SA",
  SCI: "SCI",
  SNC: "SNC",
  EI: "Entreprise individuelle",
  ASSOCIATION: "Association",
  AUTRE: "Autre",
};

export const auditActionLabels: Record<string, string> = {
  "employee.create": "Création du dossier",
  "employee.update_identity": "Identité ou coordonnées modifiées",
  "employee.update_job": "Poste ou établissement modifié",
  "employee.exit": "Sortie enregistrée",
  "employee.suspension": "Contrat suspendu",
  "employee.reprise_activite": "Reprise d'activité",
  "employee.export": "Export CSV",
  "contract.amend": "Avenant au contrat",
  "contract.create": "Nouveau contrat",
  "compensation.create": "Nouvelle rémunération",
  "bank.update": "Coordonnées bancaires modifiées",
  "bank.view": "Consultation des coordonnées bancaires",
  "document.upload": "Document ajouté",
  "invitation.create": "Invitation à l'espace salarié",
};
