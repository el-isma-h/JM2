"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { UploadSimple } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { EmptyState, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { ActionForm } from "@/components/onboarding/action-form";
import { uploadEmployeeDocumentAction } from "@/server/actions/employees";
import { fmtDate } from "@/lib/dates";
import { DownloadButton } from "./download-button";

export type EmployeeDocRow = { id: string; title: string; category: string; visibility: string; createdAt: string; sizeBytes: number; version: number };

const categories: Record<string, string> = {
  bulletin: "Bulletin de paie",
  contrat: "Contrat",
  avenant: "Avenant",
  attestation: "Attestation",
  courrier: "Courrier",
  justificatif: "Justificatif",
  identite: "Pièce d'identité",
  fiche_poste: "Fiche de poste",
  convocation: "Convocation",
  compte_rendu: "Compte rendu",
  autre: "Autre",
};
const uploadable = ["contrat", "avenant", "attestation", "courrier", "justificatif", "identite", "fiche_poste", "autre"];

export function EmployeeDocuments({ companyId, employeeId, docs, canWrite }: { companyId: string; employeeId: string; docs: EmployeeDocRow[]; canWrite: boolean }) {
  const router = useRouter();
  return (
    <Panel>
      <PanelHeader title="Documents du salarié" description="Contrats, avenants, justificatifs, bulletins. Téléchargement par lien temporaire de 15 minutes." />
      {canWrite ? (
        <ActionForm action={uploadEmployeeDocumentAction} hidden={{ companyId, employeeId }} resetOnSuccess onSuccess={() => router.refresh()} className="border-b border-line px-5 py-4">
          {(_s, pending) => (
            <div className="grid items-end gap-4 md:grid-cols-[170px_1fr_170px_1fr_auto]">
              <Field label="Type" htmlFor="ed-cat">
                <Select id="ed-cat" name="category" defaultValue="justificatif">
                  {uploadable.map((k) => (
                    <option key={k} value={k}>
                      {categories[k]}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Titre" htmlFor="ed-title" hint="facultatif">
                <Input id="ed-title" name="title" />
              </Field>
              <Field label="Visible par" htmlFor="ed-vis">
                <Select id="ed-vis" name="visibility" defaultValue="restricted">
                  <option value="restricted">Gestionnaires</option>
                  <option value="employee">Gestionnaires et salarié</option>
                </Select>
              </Field>
              <Field label="Fichier" htmlFor="ed-file" hint="8 Mo max">
                <Input id="ed-file" name="file" type="file" required accept="application/pdf,image/png,image/jpeg,.docx" className="py-1.5 file:mr-3 file:rounded-[var(--radius-sm)] file:border-0 file:bg-bg-muted file:px-2 file:py-1 file:text-[12.5px]" />
              </Field>
              <Button type="submit" variant="secondary" loading={pending}>
                {pending ? null : <UploadSimple size={16} />} Ajouter
              </Button>
            </div>
          )}
        </ActionForm>
      ) : null}
      {docs.length === 0 ? (
        <EmptyState title="Aucun document" description="Ajoutez le contrat signé, une copie de la pièce d'identité ou tout justificatif utile." />
      ) : (
        <Table>
          <thead>
            <tr>
              <Th>Document</Th>
              <Th>Type</Th>
              <Th>Visibilité</Th>
              <Th>Ajouté le</Th>
              <Th num>Taille</Th>
              <Th className="w-36"><span className="sr-only">Action</span></Th>
            </tr>
          </thead>
          <tbody>
            {docs.map((d) => (
              <tr key={d.id}>
                <Td className="font-medium">
                  {d.title}
                  {d.version > 1 ? <span className="ml-1 text-[12px] text-ink-3">version {d.version}</span> : null}
                </Td>
                <Td className="text-ink-2">{categories[d.category] ?? d.category}</Td>
                <Td>{d.visibility === "employee" ? <Badge tone="info">Salarié</Badge> : <Badge>Gestionnaires</Badge>}</Td>
                <Td className="num">{fmtDate(d.createdAt)}</Td>
                <Td num>{Math.max(1, Math.round(d.sizeBytes / 1024)).toLocaleString("fr-FR")} Ko</Td>
                <Td className="text-right">
                  <DownloadButton companyId={companyId} documentId={d.id} />
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Panel>
  );
}
