"use client";

import * as React from "react";
import Link from "next/link";
import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";
import { FormDialog } from "@/components/onboarding/editors";
import { FormMessage } from "@/components/onboarding/action-form";
import type { ActionState } from "@/server/actions/auth";
import { addCompensationAction, amendContractAction, changeSituationAction, exitEmployeeAction, newContractAction } from "@/server/actions/employees";
import { categoryLabels, exitReasons, salaryBasisLabels, workTimeModeLabels } from "./labels";
import { ContractFields } from "./forms";

type ContractInfo = {
  id: string;
  type: string;
  jobTitle: string | null;
  classification: string | null;
  coefficient: string | null;
  category: string;
  workTimeMode: string;
  weeklyHours: string;
  annualDays: number | null;
  endDate: string | null;
  trialRenewedUntil: string | null;
};

const effectiveHelp = "La date à partir de laquelle la modification s'applique. La paie du mois concerné en tiendra compte.";

/** Avenant : modification datée d'une ou plusieurs clauses. `scope` limite les champs proposés. */
export function AmendDialog({ companyId, employeeId, contract, scope, label }: { companyId: string; employeeId: string; contract: ContractInfo; scope: "general" | "classification" | "time"; label: string }) {
  const [mode, setMode] = React.useState(contract.workTimeMode);
  return (
    <FormDialog
      trigger={<Button size="sm" variant="secondary">{label}</Button>}
      title={label}
      description="La modification est enregistrée comme un avenant daté : l'ancienne valeur reste dans l'historique."
      action={amendContractAction}
      hidden={{ companyId, employeeId, contractId: contract.id }}
      submitLabel="Enregistrer la modification"
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Date d'effet" htmlFor="am-date" required help={effectiveHelp}>
          <Input id="am-date" name="effectiveDate" type="date" required className="num" />
        </Field>
        <Field label="Objet" htmlFor="am-subject" required>
          <Input id="am-subject" name="subject" required placeholder={scope === "time" ? "Passage à 28 heures" : scope === "classification" ? "Promotion niveau 3" : "Renouvellement du CDD"} />
        </Field>
      </div>
      {scope === "general" ? (
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Poste" htmlFor="am-job">
            <Input id="am-job" name="jobTitle" defaultValue={contract.jobTitle ?? ""} />
          </Field>
          <Field label="Date de fin du contrat" htmlFor="am-end" help={contract.type === "CDI" ? "Laisser vide pour un CDI." : "Pour un renouvellement de CDD."}>
            <Input id="am-end" name="endDate" type="date" defaultValue={contract.endDate ?? ""} className="num" />
          </Field>
          <Field label="Renouvellement de la période d'essai jusqu'au" htmlFor="am-trial" hint="facultatif">
            <Input id="am-trial" name="trialRenewedUntil" type="date" defaultValue={contract.trialRenewedUntil ?? ""} className="num" />
          </Field>
        </div>
      ) : null}
      {scope === "classification" ? (
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Catégorie" htmlFor="am-cat">
            <Select id="am-cat" name="category" defaultValue={contract.category}>
              {Object.entries(categoryLabels).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Classification" htmlFor="am-class">
            <Input id="am-class" name="classification" defaultValue={contract.classification ?? ""} />
          </Field>
          <Field label="Coefficient" htmlFor="am-coef">
            <Input id="am-coef" name="coefficient" defaultValue={contract.coefficient ?? ""} className="num" />
          </Field>
        </div>
      ) : null}
      {scope === "time" ? (
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Organisation" htmlFor="am-mode">
            <Select id="am-mode" name="workTimeMode" value={mode} onChange={(e) => setMode(e.target.value)}>
              {Object.entries(workTimeModeLabels).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
          </Field>
          {mode === "forfait_jours" ? (
            <Field label="Jours par an" htmlFor="am-days" help="218 jours au maximum.">
              <Input id="am-days" name="annualDays" type="number" min={1} max={218} defaultValue={contract.annualDays ?? 218} className="num" />
            </Field>
          ) : (
            <Field label="Heures par semaine" htmlFor="am-hours" help="En dessous de 35 heures, le contrat passe à temps partiel.">
              <Input id="am-hours" name="weeklyHours" defaultValue={Number(contract.weeklyHours).toString().replace(".", ",")} inputMode="decimal" className="num" />
            </Field>
          )}
        </div>
      ) : null}
      {scope !== "general" ? <Notice tone="info">Pensez à mettre à jour la rémunération si elle change avec cette modification (onglet Rémunération).</Notice> : null}
    </FormDialog>
  );
}

export function NewContractDialog({ companyId, employeeId }: { companyId: string; employeeId: string }) {
  return (
    <FormDialog
      trigger={<Button size="sm" variant="secondary">Nouveau contrat</Button>}
      title="Nouveau contrat"
      description="Par exemple un CDI après un CDD. Le contrat en cours sera clos la veille du début du nouveau."
      action={newContractAction}
      hidden={{ companyId, employeeId }}
      submitLabel="Enregistrer le contrat"
    >
      <ContractFields withStart bare />
    </FormDialog>
  );
}

export function CompensationDialog({ companyId, employeeId, currentLabel }: { companyId: string; employeeId: string; currentLabel: string | null }) {
  return (
    <FormDialog
      trigger={<Button size="sm">Modifier la rémunération</Button>}
      title="Nouvelle rémunération"
      description={`Une nouvelle ligne datée est ajoutée ; l'ancienne n'est jamais écrasée.${currentLabel ? ` Actuellement : ${currentLabel}.` : ""}`}
      action={addCompensationAction}
      hidden={{ companyId, employeeId }}
      submitLabel="Enregistrer"
    >
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Date d'effet" htmlFor="cp-date" required help="Souvent le 1er du mois.">
          <Input id="cp-date" name="effectiveDate" type="date" required className="num" />
        </Field>
        <Field label="Montant brut, en €" htmlFor="cp-amount" required>
          <Input id="cp-amount" name="grossAmount" inputMode="decimal" required className="num" placeholder="2312,15" />
        </Field>
        <Field label="Base" htmlFor="cp-basis">
          <Select id="cp-basis" name="basis" defaultValue="monthly">
            {Object.entries(salaryBasisLabels).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <Field label="Motif" htmlFor="cp-reason" required help="Augmentation annuelle, promotion, revalorisation des minima conventionnels…">
        <Input id="cp-reason" name="reason" required />
      </Field>
    </FormDialog>
  );
}

/** Sortie : date, motif, puis liste des documents de fin de contrat à préparer. */
export function ExitDialog({ companyId, employeeId, name }: { companyId: string; employeeId: string; name: string }) {
  const [open, setOpen] = React.useState(false);
  const [reason, setReason] = React.useState(exitReasons[0].value);
  const [state, action, pending] = useActionState(exitEmployeeAction, {} as ActionState);
  const router = useRouter();
  React.useEffect(() => {
    if (state.ok) router.refresh();
  }, [state, router]);
  const r = exitReasons.find((x) => x.value === (state.ok ? state.data?.reason : reason)) ?? exitReasons[0];
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="secondary">
          Enregistrer une sortie
        </Button>
      </DialogTrigger>
      <DialogContent title={`Sortie de ${name}`} description="Le statut passe à « Sorti » à la date indiquée. Les éléments de fin de contrat seront calculés sur la dernière paie." className="max-w-xl">
        {state.ok ? (
          <div className="space-y-4">
            <FormMessage state={state} className="mt-0" />
            <div>
              <p className="text-[13.5px] font-medium text-ink">Documents de fin de contrat à préparer</p>
              <ul className="mt-2 list-disc space-y-1 pl-5 text-[13.5px] text-ink-2">
                {r.docs.map((d) => (
                  <li key={d}>{d}</li>
                ))}
              </ul>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                Fermer
              </Button>
              <Button asChild>
                <Link href={`/app/${companyId}/atelier?salarie=${employeeId}&motif=${r.value}`}>Préparer les documents</Link>
              </Button>
            </div>
          </div>
        ) : (
          <form action={action} className="space-y-4">
            <input type="hidden" name="companyId" value={companyId} />
            <input type="hidden" name="employeeId" value={employeeId} />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Dernier jour du contrat" htmlFor="ex-date" required help="Fin du préavis, effectué ou non.">
                <Input id="ex-date" name="leaveDate" type="date" required className="num" />
              </Field>
              <Field label="Motif" htmlFor="ex-reason" required>
                <Select id="ex-reason" name="reason" value={reason} onChange={(e) => setReason(e.target.value)}>
                  {exitReasons.map((x) => (
                    <option key={x.value} value={x.value}>
                      {x.label}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            <Field label="Précisions" htmlFor="ex-notes" hint="facultatif" help="Préavis non effectué, dispense, date de notification…">
              <Textarea id="ex-notes" name="notes" className="min-h-16" />
            </Field>
            <Notice tone="info">À préparer ensuite : {r.docs.join(", ")}.</Notice>
            <FormMessage state={state} />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                Annuler
              </Button>
              <Button type="submit" variant="danger" loading={pending}>
                Confirmer la sortie
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function SituationDialog({ companyId, employeeId, status }: { companyId: string; employeeId: string; status: string }) {
  const suspending = status === "active";
  return (
    <FormDialog
      trigger={<Button size="sm" variant="ghost">{suspending ? "Suspendre le contrat" : "Reprise d'activité"}</Button>}
      title={suspending ? "Suspension du contrat" : "Reprise d'activité"}
      description={suspending ? "Congé parental, congé sabbatique, création d'entreprise… Le salarié reste dans l'effectif mais n'est plus payé pendant la suspension. Les arrêts maladie se saisissent dans Congés et absences." : "Le salarié redevient actif à la date indiquée."}
      action={changeSituationAction}
      hidden={{ companyId, employeeId, kind: suspending ? "suspension" : "reprise_activite" }}
      submitLabel="Enregistrer"
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Date d'effet" htmlFor="si-date" required>
          <Input id="si-date" name="effectiveDate" type="date" required className="num" />
        </Field>
        <Field label="Motif" htmlFor="si-reason" required>
          <Input id="si-reason" name="reason" required placeholder={suspending ? "Congé parental d'éducation" : "Fin du congé parental"} />
        </Field>
      </div>
    </FormDialog>
  );
}
