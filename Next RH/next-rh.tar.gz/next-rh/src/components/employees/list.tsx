"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { CaretDown, CaretUp, DownloadSimple, EnvelopeSimple, MagnifyingGlass, UserPlus } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Checkbox, Input, Select } from "@/components/ui/field";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { EmptyState, Notice, Panel } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { CopyLink } from "@/components/onboarding/action-form";
import { inviteEmployeesAction } from "@/server/actions/employees";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { categoryLabels, contractTypeLabels, salaryBasisLabels } from "./labels";

export type EmployeeListRow = {
  id: string;
  employeeNumber: string | null;
  firstName: string;
  lastName: string;
  email: string | null;
  jobTitle: string | null;
  department: string | null;
  status: string;
  hireDate: string | null;
  leaveDate: string | null;
  userId: string | null;
  establishmentName: string | null;
  contractType: string | null;
  category: string | null;
  grossCents: number | null;
  basis: string | null;
  hasNir: boolean;
  hasBank: boolean;
  hasContract: boolean;
  hasCompensation: boolean;
};

export function EmployeeFilters({ establishments }: { establishments: { id: string; name: string }[] }) {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const [q, setQ] = React.useState(sp.get("q") ?? "");
  const set = React.useCallback(
    (k: string, v: string) => {
      const next = new URLSearchParams(sp.toString());
      if (v) next.set(k, v);
      else next.delete(k);
      router.replace(`${pathname}?${next.toString()}`, { scroll: false });
    },
    [router, pathname, sp],
  );
  React.useEffect(() => {
    if ((sp.get("q") ?? "") === q) return;
    const t = setTimeout(() => set("q", q.trim()), 300);
    return () => clearTimeout(t);
  }, [q, sp, set]);

  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="relative min-w-[220px] flex-1">
        <MagnifyingGlass size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-3" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nom, matricule, poste, e-mail" className="pl-9" aria-label="Rechercher un salarié" />
      </div>
      <Select aria-label="Statut" value={sp.get("statut") ?? ""} onChange={(e) => set("statut", e.target.value)} className="w-auto">
        <option value="">Présents (hors sortis)</option>
        <option value="active">Actifs</option>
        <option value="draft">Entrée à venir</option>
        <option value="suspended">Contrat suspendu</option>
        <option value="left">Sortis</option>
        <option value="all">Tous</option>
      </Select>
      {establishments.length > 1 ? (
        <Select aria-label="Établissement" value={sp.get("etablissement") ?? ""} onChange={(e) => set("etablissement", e.target.value)} className="w-auto">
          <option value="">Tous les établissements</option>
          {establishments.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </Select>
      ) : null}
      <Select aria-label="Contrat" value={sp.get("contrat") ?? ""} onChange={(e) => set("contrat", e.target.value)} className="w-auto">
        <option value="">Tous les contrats</option>
        {Object.entries(contractTypeLabels).map(([k, v]) => (
          <option key={k} value={k}>
            {v}
          </option>
        ))}
      </Select>
      <Select aria-label="Catégorie" value={sp.get("categorie") ?? ""} onChange={(e) => set("categorie", e.target.value)} className="w-auto">
        <option value="">Toutes catégories</option>
        {Object.entries(categoryLabels).map(([k, v]) => (
          <option key={k} value={k}>
            {v}
          </option>
        ))}
      </Select>
      {sp.get("anomalie") ? (
        <Button type="button" variant="ghost" size="sm" onClick={() => set("anomalie", "")}>
          Retirer le filtre « à compléter »
        </Button>
      ) : null}
    </div>
  );
}

function SortHeader({ k, children, num }: { k: string; children: React.ReactNode; num?: boolean }) {
  const sp = useSearchParams();
  const pathname = usePathname();
  const current = sp.get("tri") ?? "nom";
  const next = new URLSearchParams(sp.toString());
  next.set("tri", k);
  return (
    <Th num={num}>
      <Link href={`${pathname}?${next.toString()}`} scroll={false} className="inline-flex items-center gap-1 hover:text-ink" aria-sort={current === k ? "ascending" : undefined}>
        {children}
        {current === k ? (k === "entree" || k === "salaire" ? <CaretDown size={12} /> : <CaretUp size={12} />) : null}
      </Link>
    </Th>
  );
}

export function EmployeeTable({ companyId, rows, canSeeSalary, canWrite, hasAny }: { companyId: string; rows: EmployeeListRow[]; canSeeSalary: boolean; canWrite: boolean; hasAny: boolean }) {
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [pending, setPending] = React.useState(false);
  const [result, setResult] = React.useState<{ message?: string; error?: string; links?: { name: string; link: string }[] } | null>(null);
  const exportRef = React.useRef<HTMLFormElement>(null);
  const router = useRouter();
  const allSelected = rows.length > 0 && rows.every((r) => selected.has(r.id));
  const toggle = (id: string, on: boolean) =>
    setSelected((s) => {
      const n = new Set(s);
      if (on) n.add(id);
      else n.delete(id);
      return n;
    });

  if (!hasAny) {
    return (
      <Panel>
        <EmptyState
          icon={<UserPlus size={28} />}
          title="Aucun salarié pour l'instant"
          description="Créez les dossiers un par un, ou importez-les en une fois depuis votre ancien logiciel (fichier CSV)."
          action={
            canWrite ? (
              <div className="flex gap-2">
                <Button asChild>
                  <Link href={`/app/${companyId}/salaries/nouveau`}>Ajouter un salarié</Link>
                </Button>
                <Button asChild variant="secondary">
                  <Link href={`/app/${companyId}/onboarding?etape=reprise`}>Importer un fichier</Link>
                </Button>
              </div>
            ) : null
          }
        />
      </Panel>
    );
  }

  return (
    <Panel>
      {selected.size > 0 ? (
        <div className="flex flex-wrap items-center gap-2 border-b border-line bg-accent-soft px-4 py-2.5 text-[13px]">
          <span className="font-medium text-accent-strong">
            <span className="num">{selected.size}</span> sélectionné(s)
          </span>
          <Button size="sm" variant="secondary" onClick={() => exportRef.current?.requestSubmit()}>
            <DownloadSimple size={15} /> Exporter en CSV
          </Button>
          {canWrite ? (
            <Button
              size="sm"
              variant="secondary"
              loading={pending}
              onClick={async () => {
                setPending(true);
                const r = await inviteEmployeesAction(companyId, [...selected]);
                setPending(false);
                setResult({ message: r.message, error: r.error, links: r.links });
                router.refresh();
              }}
            >
              {pending ? null : <EnvelopeSimple size={15} />} Inviter dans l&apos;espace salarié
            </Button>
          ) : null}
          <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>
            Désélectionner
          </Button>
        </div>
      ) : null}
      <form ref={exportRef} method="post" action={`/app/${companyId}/salaries/export`} className="hidden">
        {[...selected].map((id) => (
          <input key={id} type="hidden" name="ids" value={id} />
        ))}
      </form>
      {rows.length === 0 ? (
        <EmptyState title="Aucun salarié ne correspond aux filtres" description="Modifiez la recherche ou affichez tous les statuts." />
      ) : (
        <Table>
          <thead>
            <tr>
              <Th className="w-10">
                <Checkbox aria-label="Tout sélectionner" checked={allSelected} onChange={(e) => setSelected(e.target.checked ? new Set(rows.map((r) => r.id)) : new Set())} />
              </Th>
              <SortHeader k="nom">Salarié</SortHeader>
              <SortHeader k="matricule">Matricule</SortHeader>
              <SortHeader k="poste">Poste</SortHeader>
              <Th>Établissement</Th>
              <Th>Contrat</Th>
              <SortHeader k="entree">Entrée</SortHeader>
              {canSeeSalary ? <SortHeader k="salaire" num>Salaire de base</SortHeader> : null}
              <Th>Statut</Th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const missing = r.status === "active" ? [!r.hasContract && "contrat", !r.hasCompensation && "salaire", !r.hasNir && "n° sécu", !r.hasBank && "IBAN"].filter(Boolean) : [];
              return (
                <tr key={r.id} data-selected={selected.has(r.id) || undefined}>
                  <Td>
                    <Checkbox aria-label={`Sélectionner ${r.firstName} ${r.lastName}`} checked={selected.has(r.id)} onChange={(e) => toggle(r.id, e.target.checked)} />
                  </Td>
                  <Td>
                    <Link href={`/app/${companyId}/salaries/${r.id}`} className="font-medium text-ink hover:text-accent-strong hover:underline">
                      {r.lastName.toUpperCase()} {r.firstName}
                    </Link>
                    {missing.length ? <span className="block text-[12px] text-warn-ink">À compléter : {missing.join(", ")}</span> : r.email ? <span className="block text-[12px] text-ink-3">{r.email}</span> : null}
                  </Td>
                  <Td className="num text-ink-2">{r.employeeNumber ?? "-"}</Td>
                  <Td>
                    {r.jobTitle ?? "-"}
                    {r.department ? <span className="block text-[12px] text-ink-3">{r.department}</span> : null}
                  </Td>
                  <Td className="text-ink-2">{r.establishmentName ?? "-"}</Td>
                  <Td>
                    {r.contractType ? contractTypeLabels[r.contractType] : "-"}
                    {r.category ? <span className="block text-[12px] text-ink-3">{categoryLabels[r.category]}</span> : null}
                  </Td>
                  <Td className="num whitespace-nowrap">{fmtDate(r.hireDate)}</Td>
                  {canSeeSalary ? (
                    <Td num className="whitespace-nowrap">
                      {formatCents(r.grossCents)}
                      {r.basis && r.basis !== "monthly" ? <span className="block text-[12px] text-ink-3">{salaryBasisLabels[r.basis]}</span> : null}
                    </Td>
                  ) : null}
                  <Td>
                    <StatusBadge status={r.status} />
                    {r.leaveDate && r.status !== "left" ? <span className="block text-[12px] text-ink-3">Sortie le {fmtDate(r.leaveDate)}</span> : null}
                    {r.userId ? <Badge tone="info" className="mt-1">Espace activé</Badge> : null}
                  </Td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      )}
      <Dialog open={Boolean(result)} onOpenChange={(o) => !o && setResult(null)}>
        <DialogContent title="Invitations à l'espace salarié" className="max-h-[90dvh] overflow-y-auto">
          {result?.error ? <Notice tone="danger">{result.error}</Notice> : <Notice tone="ok">{result?.message}</Notice>}
          {result?.links?.length ? (
            <div className="mt-4 space-y-3">
              {result.links.map((l) => (
                <div key={l.link}>
                  <p className="text-[13px] font-medium text-ink">{l.name}</p>
                  <CopyLink link={l.link} />
                </div>
              ))}
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </Panel>
  );
}
