"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Panel, PanelHeader } from "@/components/ui/surface";
import { ActionForm } from "@/components/onboarding/action-form";
import { createEmployeeAction, updateIdentityAction, updateJobAction } from "@/server/actions/employees";
import { categoryLabels, contractTypeLabels, genderLabels, salaryBasisLabels, workTimeModeLabels } from "./labels";

export type Option = { value: string; label: string };

export type IdentityValues = {
  civility: string | null;
  firstName: string;
  lastName: string;
  birthName: string | null;
  gender: string | null;
  birthDate: string | null;
  birthPlace: string | null;
  birthCountry: string | null;
  nationality: string | null;
  email: string | null;
  personalEmail: string | null;
  phone: string | null;
  addressLine1: string | null;
  addressLine2: string | null;
  postalCode: string | null;
  city: string | null;
};

const grid = "grid gap-x-5 gap-y-4 p-5 sm:grid-cols-2 lg:grid-cols-3";

export function IdentityFields({ v, maskedNir, isCreate }: { v?: Partial<IdentityValues>; maskedNir?: string | null; isCreate?: boolean }) {
  return (
    <>
      <Panel>
        <PanelHeader title="Identité" description="Telle qu'elle figure sur la pièce d'identité : elle est transmise dans la déclaration sociale." />
        <div className={grid}>
          <Field label="Civilité" htmlFor="civility">
            <Select id="civility" name="civility" defaultValue={v?.civility ?? ""}>
              <option value="">Non précisée</option>
              <option value="Mme">Madame</option>
              <option value="M.">Monsieur</option>
            </Select>
          </Field>
          <Field label="Prénom" htmlFor="firstName" required>
            <Input id="firstName" name="firstName" defaultValue={v?.firstName ?? ""} required autoComplete="off" />
          </Field>
          <Field label="Nom d'usage" htmlFor="lastName" required>
            <Input id="lastName" name="lastName" defaultValue={v?.lastName ?? ""} required autoComplete="off" />
          </Field>
          <Field label="Nom de naissance" htmlFor="birthName" hint="si différent">
            <Input id="birthName" name="birthName" defaultValue={v?.birthName ?? ""} />
          </Field>
          <Field label="Sexe" htmlFor="gender" help="Doit correspondre au premier chiffre du N° de sécurité sociale (1 ou 2).">
            <Select id="gender" name="gender" defaultValue={v?.gender ?? ""}>
              <option value="">Non précisé</option>
              {Object.entries(genderLabels).map(([k, l]) => (
                <option key={k} value={k}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Date de naissance" htmlFor="birthDate">
            <Input id="birthDate" name="birthDate" type="date" defaultValue={v?.birthDate ?? ""} className="num" />
          </Field>
          <Field label="Lieu de naissance" htmlFor="birthPlace">
            <Input id="birthPlace" name="birthPlace" defaultValue={v?.birthPlace ?? ""} />
          </Field>
          <Field label="Pays de naissance" htmlFor="birthCountry">
            <Input id="birthCountry" name="birthCountry" defaultValue={v?.birthCountry ?? (isCreate ? "France" : "")} />
          </Field>
          <Field label="Nationalité" htmlFor="nationality">
            <Input id="nationality" name="nationality" defaultValue={v?.nationality ?? (isCreate ? "Française" : "")} />
          </Field>
          <Field
            label={maskedNir ? "Remplacer le N° de sécurité sociale" : "N° de sécurité sociale"}
            htmlFor="nir"
            className="sm:col-span-2 lg:col-span-1"
            help={maskedNir ? `Numéro enregistré : ${maskedNir}. Laissez vide pour le conserver.` : "15 caractères, clé comprise (carte Vitale ou attestation de droits). Chiffré, puis affiché masqué."}
          >
            <Input id="nir" name="nir" defaultValue="" inputMode="numeric" className="num" autoComplete="off" placeholder="2 91 03 44 123 456 49" />
          </Field>
        </div>
      </Panel>
      <Panel>
        <PanelHeader title="Coordonnées" />
        <div className={grid}>
          <Field label="E-mail professionnel" htmlFor="email" help="Sert à l'invitation dans l'espace salarié.">
            <Input id="email" name="email" type="email" defaultValue={v?.email ?? ""} />
          </Field>
          <Field label="E-mail personnel" htmlFor="personalEmail" hint="facultatif">
            <Input id="personalEmail" name="personalEmail" type="email" defaultValue={v?.personalEmail ?? ""} />
          </Field>
          <Field label="Téléphone" htmlFor="phone">
            <Input id="phone" name="phone" defaultValue={v?.phone ?? ""} className="num" />
          </Field>
          <Field label="Adresse" htmlFor="addressLine1" className="sm:col-span-2">
            <Input id="addressLine1" name="addressLine1" defaultValue={v?.addressLine1 ?? ""} />
          </Field>
          <Field label="Complément" htmlFor="addressLine2" hint="facultatif">
            <Input id="addressLine2" name="addressLine2" defaultValue={v?.addressLine2 ?? ""} />
          </Field>
          <Field label="Code postal" htmlFor="postalCode">
            <Input id="postalCode" name="postalCode" defaultValue={v?.postalCode ?? ""} inputMode="numeric" className="num" />
          </Field>
          <Field label="Ville" htmlFor="city">
            <Input id="city" name="city" defaultValue={v?.city ?? ""} />
          </Field>
        </div>
      </Panel>
    </>
  );
}

export function IdentityForm({ companyId, employeeId, values, maskedNir, readOnly }: { companyId: string; employeeId: string; values: IdentityValues; maskedNir: string | null; readOnly: boolean }) {
  return (
    <ActionForm action={updateIdentityAction} hidden={{ companyId, employeeId }}>
      {(_s, pending) => (
        <fieldset disabled={readOnly} className="space-y-6">
          <IdentityFields v={values} maskedNir={maskedNir} />
          {readOnly ? null : (
            <div className="flex justify-end">
              <Button type="submit" loading={pending}>
                Enregistrer les modifications
              </Button>
            </div>
          )}
        </fieldset>
      )}
    </ActionForm>
  );
}

export function JobForm({
  companyId,
  employeeId,
  values,
  establishments,
  managers,
  readOnly,
}: {
  companyId: string;
  employeeId: string;
  values: { jobTitle: string | null; department: string | null; establishmentId: string | null; managerId: string | null; employeeNumber: string | null };
  establishments: Option[];
  managers: Option[];
  readOnly: boolean;
}) {
  return (
    <ActionForm action={updateJobAction} hidden={{ companyId, employeeId }}>
      {(_s, pending) => (
        <Panel>
          <PanelHeader title="Poste et établissement" description="Un changement d'établissement est daté et repris dans la déclaration sociale du mois concerné." />
          <fieldset disabled={readOnly} className={grid}>
            <Field label="Matricule" htmlFor="employeeNumber" help="Identifiant interne unique.">
              <Input id="employeeNumber" name="employeeNumber" defaultValue={values.employeeNumber ?? ""} className="num" />
            </Field>
            <Field label="Poste" htmlFor="jobTitle">
              <Input id="jobTitle" name="jobTitle" defaultValue={values.jobTitle ?? ""} />
            </Field>
            <Field label="Service" htmlFor="department">
              <Input id="department" name="department" defaultValue={values.department ?? ""} />
            </Field>
            <Field label="Établissement" htmlFor="establishmentId">
              <Select id="establishmentId" name="establishmentId" defaultValue={values.establishmentId ?? ""}>
                <option value="">Non rattaché</option>
                {establishments.map((e) => (
                  <option key={e.value} value={e.value}>
                    {e.label}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Responsable" htmlFor="managerId" hint="facultatif">
              <Select id="managerId" name="managerId" defaultValue={values.managerId ?? ""}>
                <option value="">Aucun</option>
                {managers.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Date d'effet du changement" htmlFor="effectiveDate" help="Par défaut, aujourd'hui.">
              <Input id="effectiveDate" name="effectiveDate" type="date" className="num" />
            </Field>
            {readOnly ? null : (
              <div className="flex items-end justify-end sm:col-span-2 lg:col-span-3">
                <Button type="submit" loading={pending}>
                  Enregistrer
                </Button>
              </div>
            )}
          </fieldset>
        </Panel>
      )}
    </ActionForm>
  );
}

/** Champs d'un contrat (création d'un salarié, nouveau contrat). */
export function ContractFields({ withStart, bare }: { withStart?: boolean; bare?: boolean }) {
  const [type, setType] = React.useState("CDI");
  const [mode, setMode] = React.useState("heures");
  return (
    <div className={bare ? "grid gap-4 sm:grid-cols-2" : grid}>
      {withStart ? (
        <Field label="Date de début" htmlFor="startDate" required>
          <Input id="startDate" name="startDate" type="date" required className="num" />
        </Field>
      ) : null}
      <Field label="Type de contrat" htmlFor="contractType" required>
        <Select id="contractType" name="contractType" value={type} onChange={(e) => setType(e.target.value)}>
          {Object.entries(contractTypeLabels).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Catégorie" htmlFor="category" help="Cadre ou non-cadre : change la retraite complémentaire et la prévoyance.">
        <Select id="category" name="category" defaultValue="non_cadre">
          {Object.entries(categoryLabels).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Poste" htmlFor="c-jobTitle">
        <Input id="c-jobTitle" name="jobTitle" />
      </Field>
      {type !== "CDI" ? (
        <Field label="Date de fin" htmlFor="endDate" required={type === "CDD"} help={type === "CDD" ? "Obligatoire pour un CDD à terme précis." : undefined}>
          <Input id="endDate" name="endDate" type="date" className="num" required={type === "CDD"} />
        </Field>
      ) : null}
      {type === "CDD" ? (
        <Field label="Motif du CDD" htmlFor="cddReason" help="Remplacement, accroissement temporaire d'activité, saisonnier…">
          <Input id="cddReason" name="cddReason" />
        </Field>
      ) : null}
      <Field label="Fin de la période d'essai" htmlFor="trialEndDate" hint="facultatif" help="Les échéances de fin d'essai sont suivies par le module RH.">
        <Input id="trialEndDate" name="trialEndDate" type="date" className="num" />
      </Field>
      <Field label="Classification" htmlFor="classification" help="Niveau, position ou échelon selon la convention collective.">
        <Input id="classification" name="classification" />
      </Field>
      <Field label="Coefficient" htmlFor="coefficient" hint="facultatif">
        <Input id="coefficient" name="coefficient" className="num" />
      </Field>
      <Field label="Temps de travail" htmlFor="workTimeMode">
        <Select id="workTimeMode" name="workTimeMode" value={mode} onChange={(e) => setMode(e.target.value)}>
          {Object.entries(workTimeModeLabels).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      </Field>
      {mode === "forfait_jours" ? (
        <Field label="Jours par an" htmlFor="annualDays" required help="218 jours au maximum.">
          <Input id="annualDays" name="annualDays" type="number" min={1} max={218} defaultValue={218} className="num" />
        </Field>
      ) : (
        <Field label="Heures par semaine" htmlFor="weeklyHours" help="35 pour un temps plein. En dessous, le contrat est à temps partiel.">
          <Input id="weeklyHours" name="weeklyHours" defaultValue="35" inputMode="decimal" className="num" />
        </Field>
      )}
    </div>
  );
}

export function CreateEmployeeForm({ companyId, establishments, canSeeSalary }: { companyId: string; establishments: Option[]; canSeeSalary: boolean }) {
  return (
    <ActionForm action={createEmployeeAction} hidden={{ companyId }}>
      {(_s, pending) => (
        <div className="space-y-6">
          <IdentityFields isCreate />
          <Panel>
            <PanelHeader title="Entrée et poste" />
            <div className={grid}>
              <Field label="Date d'entrée" htmlFor="hireDate" required help="Premier jour de travail. Elle sert aussi de date d'effet de la rémunération initiale.">
                <Input id="hireDate" name="hireDate" type="date" required className="num" />
              </Field>
              <Field label="Matricule" htmlFor="employeeNumber" hint="recommandé">
                <Input id="employeeNumber" name="employeeNumber" className="num" />
              </Field>
              <Field label="Service" htmlFor="department">
                <Input id="department" name="department" />
              </Field>
              <Field label="Établissement" htmlFor="establishmentId">
                <Select id="establishmentId" name="establishmentId" defaultValue={establishments[0]?.value ?? ""}>
                  <option value="">Non rattaché</option>
                  {establishments.map((e) => (
                    <option key={e.value} value={e.value}>
                      {e.label}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
          </Panel>
          <Panel>
            <PanelHeader title="Contrat" />
            <ContractFields />
          </Panel>
          <Panel>
            <PanelHeader title="Rémunération initiale" description="Le salaire de base brut prévu au contrat. Chaque changement ultérieur sera daté dans l'historique." />
            <div className={grid}>
              <Field label="Salaire de base brut, en €" htmlFor="grossAmount" required help={canSeeSalary ? "Par exemple 2187,40." : "Vous saisissez le salaire, mais il restera masqué pour vous ensuite."}>
                <Input id="grossAmount" name="grossAmount" inputMode="decimal" required className="num" />
              </Field>
              <Field label="Base" htmlFor="basis">
                <Select id="basis" name="basis" defaultValue="monthly">
                  {Object.entries(salaryBasisLabels).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
          </Panel>
          <div className="flex justify-end gap-2">
            <Button asChild variant="ghost">
              <Link href={`/app/${companyId}/salaries`}>Annuler</Link>
            </Button>
            <Button type="submit" loading={pending}>
              Créer le dossier
            </Button>
          </div>
        </div>
      )}
    </ActionForm>
  );
}

