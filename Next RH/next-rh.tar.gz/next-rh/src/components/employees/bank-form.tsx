"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Panel, PanelHeader } from "@/components/ui/surface";
import { ActionForm } from "@/components/onboarding/action-form";
import { saveBankAccountAction } from "@/server/actions/employees";

export function BankForm({ companyId, employeeId, holderName }: { companyId: string; employeeId: string; holderName: string }) {
  const router = useRouter();
  return (
    <Panel>
      <PanelHeader title="Nouvelles coordonnées bancaires" description="Le nouveau compte remplace l'ancien pour les virements à partir de la date indiquée. L'ancien reste dans l'historique." />
      <ActionForm action={saveBankAccountAction} hidden={{ companyId, employeeId }} resetOnSuccess onSuccess={() => router.refresh()} className="p-5">
        {(_s, pending) => (
          <div className="grid gap-x-5 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="IBAN" htmlFor="iban" required className="sm:col-span-2" help="Sur le relevé d'identité bancaire (RIB) fourni par le salarié.">
              <Input id="iban" name="iban" required autoComplete="off" className="num" placeholder="FR76 3000 6000 0112 3456 7890 189" />
            </Field>
            <Field label="BIC" htmlFor="bic" hint="facultatif en zone SEPA">
              <Input id="bic" name="bic" autoComplete="off" className="num" />
            </Field>
            <Field label="Titulaire du compte" htmlFor="holderName">
              <Input id="holderName" name="holderName" defaultValue={holderName} />
            </Field>
            <Field label="Banque" htmlFor="bankName" hint="facultatif">
              <Input id="bankName" name="bankName" />
            </Field>
            <Field label="Utilisé à partir du" htmlFor="validFrom">
              <Input id="validFrom" name="validFrom" type="date" className="num" />
            </Field>
            <div className="flex justify-end sm:col-span-2 lg:col-span-3">
              <Button type="submit" loading={pending}>
                Enregistrer l&apos;IBAN
              </Button>
            </div>
          </div>
        )}
      </ActionForm>
    </Panel>
  );
}
