"use client";

import * as React from "react";
import { DownloadSimple } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { getDocumentLinkAction } from "@/server/actions/employees";

/** Demande un lien temporaire (15 min) puis lance le téléchargement. */
export function DownloadButton({ companyId, documentId, label = "Télécharger" }: { companyId: string; documentId: string; label?: string }) {
  const [pending, setPending] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  return (
    <span className="inline-flex items-center gap-2">
      <Button
        type="button"
        size="sm"
        variant="ghost"
        loading={pending}
        onClick={async () => {
          setPending(true);
          setError(null);
          const r = await getDocumentLinkAction(companyId, documentId);
          setPending(false);
          if (r.url) window.location.assign(r.url);
          else setError(r.error ?? "Lien indisponible.");
        }}
      >
        {pending ? null : <DownloadSimple size={15} />}
        {label}
      </Button>
      {error ? <span className="text-[12px] text-danger-ink">{error}</span> : null}
    </span>
  );
}
