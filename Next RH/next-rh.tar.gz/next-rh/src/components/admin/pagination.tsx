import Link from "next/link";
import { Button } from "@/components/ui/button";

/** Pagination par liens (préserve les filtres de la page). */
export function Pagination({ basePath, params, page, pageSize, total }: { basePath: string; params: Record<string, string | undefined>; page: number; pageSize: number; total: number }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const href = (p: number) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) q.set(k, v);
    if (p > 1) q.set("page", String(p));
    const s = q.toString();
    return s ? `${basePath}?${s}` : basePath;
  };
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line px-5 py-3 text-[13px] text-ink-2">
      <span className="num">
        {from}-{to} sur {total}
      </span>
      <div className="flex items-center gap-2">
        {page > 1 ? (
          <Button asChild variant="secondary" size="sm">
            <Link href={href(page - 1)}>Page précédente</Link>
          </Button>
        ) : null}
        <span className="num">
          Page {page} / {pages}
        </span>
        {page < pages ? (
          <Button asChild variant="secondary" size="sm">
            <Link href={href(page + 1)}>Page suivante</Link>
          </Button>
        ) : null}
      </div>
    </div>
  );
}

export function readPage(raw: string | string[] | undefined): number {
  const n = Number(Array.isArray(raw) ? raw[0] : raw);
  return Number.isInteger(n) && n > 0 ? n : 1;
}

export function readParam(raw: string | string[] | undefined): string | undefined {
  const v = Array.isArray(raw) ? raw[0] : raw;
  return v?.trim() ? v.trim() : undefined;
}
