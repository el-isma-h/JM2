"use client";

import * as React from "react";
import { Button, type ButtonProps } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { ActionForm, ResultNotice, type ServerAction } from "./action-form";
import type { ActionState } from "@/server/actions/auth";

/**
 * Bouton qui ouvre un formulaire dans un dialogue. Le dialogue se ferme après succès sauf si le résultat
 * contient un lien à copier (affiché alors sous le bouton).
 */
export function FormDialog({
  action,
  trigger,
  triggerVariant = "primary",
  triggerSize = "md",
  title,
  description,
  submitLabel,
  children,
  wide,
}: {
  action: ServerAction;
  trigger: string;
  triggerVariant?: ButtonProps["variant"];
  triggerSize?: ButtonProps["size"];
  title: string;
  description?: string;
  submitLabel: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  const [open, setOpen] = React.useState(false);
  const [last, setLast] = React.useState<ActionState>({});
  const [key, setKey] = React.useState(0);
  const onDone = React.useCallback((s: ActionState) => {
    if (s.ok) {
      setLast(s);
      setOpen(false);
      setKey((k) => k + 1);
    }
  }, []);
  return (
    <div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant={triggerVariant} size={triggerSize} onClick={() => setLast({})}>
            {trigger}
          </Button>
        </DialogTrigger>
        <DialogContent title={title} description={description} className={wide ? "max-w-2xl" : undefined}>
          <ActionForm key={key} action={action} submitLabel={submitLabel} onDone={onDone} footerClassName="mt-5 justify-end">
            <div className="max-h-[65dvh] space-y-4 overflow-y-auto pr-1">{children}</div>
          </ActionForm>
        </DialogContent>
      </Dialog>
      <ResultNotice state={last} className="mt-3 max-w-xl" />
    </div>
  );
}
