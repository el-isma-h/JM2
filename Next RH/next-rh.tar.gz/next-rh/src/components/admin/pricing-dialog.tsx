"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";
import { checkPrice, proposePrice, pricingUnitLabels } from "@/server/pricing/compute";
import { ActionForm, ResultNotice, type ServerAction } from "./action-form";
import type { ActionState } from "@/server/actions/auth";

export type PlanFormValue = {
  id?: string;
  code: string;
  name: string;
  description: string;
  isService: boolean;
  unit: string;
  priceCents: number | null;
  referencePriceCents: number | null;
  referenceLabel: string;
  referenceUrl: string;
  referenceCheckedAt: string;
  discountRate: number;
  calculationNote: string;
  isActive: boolean;
  sortOrder: number;
};

const toEuros = (c: number | null) => (c === null ? "" : (c / 100).toFixed(2).replace(".", ","));
function parseCents(s: string): number | null {
  const m = /^(\d+)(?:[.,](\d{1,2}))?$/.exec(s.replace(/[\s€]/g, ""));
  return m ? Number(m[1]) * 100 + Number((m[2] ?? "").padEnd(2, "0")) : null;
}

/** Édition d'une ligne tarifaire : le prix Next RH est proposé à partir de la référence et de la remise, puis modifiable. */
export function PricingDialog({ action, plan, trigger, triggerVariant = "secondary" }: { action: ServerAction; plan?: PlanFormValue; trigger: string; triggerVariant?: "primary" | "secondary" | "ghost" }) {
  const [open, setOpen] = React.useState(false);
  const [done, setDone] = React.useState<ActionState>({});
  const [unit, setUnit] = React.useState(plan?.unit ?? "par_salarie_mois");
  const [reference, setReference] = React.useState(toEuros(plan?.referencePriceCents ?? null));
  const [discount, setDiscount] = React.useState(((plan?.discountRate ?? 1000) / 100).toString().replace(".", ","));
  const [price, setPrice] = React.useState(toEuros(plan?.priceCents ?? null));

  const refCents = parseCents(reference);
  const discountBp = Math.round(Number(discount.replace(",", ".")) * 100);
  const validDiscount = Number.isInteger(discountBp) && discountBp >= 0 && discountBp <= 10000;
  const proposed = refCents !== null && validDiscount ? proposePrice(refCents, discountBp) : null;
  const priceCents = unit === "sur_devis" ? null : unit === "inclus" ? 0 : (parseCents(price) ?? proposed);
  const check = checkPrice({ priceCents, referencePriceCents: refCents, discountRate: validDiscount ? discountBp : 1000, unit });
  const exact = refCents !== null && validDiscount ? (refCents * (10000 - discountBp)) / 10000 / 100 : null;

  const onDone = React.useCallback((s: ActionState) => {
    if (s.ok) {
      setDone(s);
      setOpen(false);
    }
  }, []);

  return (
    <div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant={triggerVariant} size="sm" onClick={() => setDone({})}>
            {trigger}
          </Button>
        </DialogTrigger>
        <DialogContent title={plan ? `Modifier : ${plan.name}` : "Nouvelle ligne tarifaire"} description="Montants HT. Le prix Next RH est calculé au centime inférieur, jamais arrondi au-dessus." className="max-w-2xl">
          <ActionForm action={action} submitLabel="Enregistrer le tarif" onDone={onDone} footerClassName="mt-5 justify-end">
            <div className="max-h-[65dvh] space-y-4 overflow-y-auto pr-1">
              {plan?.id ? <input type="hidden" name="id" value={plan.id} /> : null}
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Nom affiché" required htmlFor="p-name">
                  <Input id="p-name" name="name" defaultValue={plan?.name} required />
                </Field>
                <Field label="Code" required htmlFor="p-code" help="Identifiant stable (minuscules, chiffres, _).">
                  <Input id="p-code" name="code" defaultValue={plan?.code} required pattern="[a-z0-9_]+" readOnly={Boolean(plan?.id)} />
                </Field>
              </div>
              <Field label="Description" htmlFor="p-desc">
                <Textarea id="p-desc" name="description" defaultValue={plan?.description} className="min-h-16" />
              </Field>
              <div className="grid gap-4 sm:grid-cols-3">
                <Field label="Unité" htmlFor="p-unit">
                  <Select id="p-unit" name="unit" value={unit} onChange={(e) => setUnit(e.target.value)}>
                    {Object.entries(pricingUnitLabels).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Prix de référence (€ HT)" htmlFor="p-ref" help="Vide si aucun prix public.">
                  <Input id="p-ref" name="reference" value={reference} onChange={(e) => setReference(e.target.value)} inputMode="decimal" className="num" />
                </Field>
                <Field label="Remise (%)" htmlFor="p-disc" help="10 % par défaut.">
                  <Input id="p-disc" name="discountPercent" value={discount} onChange={(e) => setDiscount(e.target.value)} inputMode="decimal" className="num" />
                </Field>
              </div>
              <div className="rounded-[var(--radius-sm)] bg-bg-sunken px-4 py-3 text-[13px]">
                {unit === "sur_devis" ? (
                  <p className="text-ink-2">Sur devis : aucun prix n&apos;est affiché.</p>
                ) : unit === "inclus" ? (
                  <p className="text-ink-2">Inclus sans surcoût : prix 0.</p>
                ) : exact !== null && proposed !== null ? (
                  <p className="text-ink-2">
                    Proposition : <span className="num text-ink">{toEuros(refCents)} €</span> × <span className="num text-ink">{((10000 - discountBp) / 10000).toLocaleString("fr-FR")}</span> ={" "}
                    <span className="num text-ink">{exact.toLocaleString("fr-FR", { maximumFractionDigits: 4 })} €</span>, tronqué : <span className="num font-medium text-ink">{toEuros(proposed)} €</span>
                  </p>
                ) : (
                  <p className="text-ink-2">Saisissez un prix de référence pour obtenir la proposition.</p>
                )}
              </div>
              {unit !== "sur_devis" && unit !== "inclus" ? (
                <Field label="Prix Next RH (€ HT)" htmlFor="p-price" help="Laissez vide pour appliquer la proposition.">
                  <div className="flex gap-2">
                    <Input id="p-price" name="price" value={price} onChange={(e) => setPrice(e.target.value)} placeholder={proposed !== null ? toEuros(proposed) : ""} inputMode="decimal" className="num" />
                    <Button type="button" variant="secondary" onClick={() => setPrice(proposed !== null ? toEuros(proposed) : "")} disabled={proposed === null}>
                      Utiliser la proposition
                    </Button>
                  </div>
                </Field>
              ) : null}
              {check.level !== "ok" ? <Notice tone={check.level === "danger" ? "danger" : "info"}>{check.message}</Notice> : null}
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Comparable de référence" htmlFor="p-rlabel">
                  <Input id="p-rlabel" name="referenceLabel" defaultValue={plan?.referenceLabel} />
                </Field>
                <Field label="Date de consultation" htmlFor="p-rdate">
                  <Input id="p-rdate" name="referenceCheckedAt" type="date" defaultValue={plan?.referenceCheckedAt} />
                </Field>
              </div>
              <Field label="Source (URL)" htmlFor="p-rurl">
                <Input id="p-rurl" name="referenceUrl" type="url" defaultValue={plan?.referenceUrl} />
              </Field>
              <Field label="Note de calcul" htmlFor="p-note" help="Vide : générée automatiquement à partir de la référence et de la remise.">
                <Textarea id="p-note" name="calculationNote" defaultValue={plan?.calculationNote} className="min-h-16" />
              </Field>
              <div className="grid gap-4 sm:grid-cols-[1fr_140px]">
                <div className="flex flex-col gap-2 pt-6">
                  <Checkbox name="isService" defaultChecked={plan?.isService} label="Service d'accompagnement humain (et non fonction du logiciel)" />
                  <Checkbox name="isActive" defaultChecked={plan?.isActive ?? true} label="Publié sur la page tarifs" />
                </div>
                <Field label="Ordre" htmlFor="p-order">
                  <Input id="p-order" name="sortOrder" type="number" min={0} defaultValue={plan?.sortOrder ?? 0} className="num" />
                </Field>
              </div>
            </div>
          </ActionForm>
        </DialogContent>
      </Dialog>
      <ResultNotice state={done} className="mt-2" />
    </div>
  );
}
