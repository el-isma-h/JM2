"use client";

import * as React from "react";
import { useActionState } from "react";
import { Check, Copy } from "@phosphor-icons/react";
import { Button, type ButtonProps } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent } from "@/components/ui/dialog";
import { Checkbox, Field, Input } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";
import { cn } from "@/lib/utils";
import type { ActionState } from "@/server/actions/auth";

export type ServerAction = (prev: ActionState, formData: FormData) => Promise<ActionState>;

export type ConfirmSpec = {
  title: string;
  description?: string;
  /** Texte à saisir à l'identique pour activer la confirmation (confirmation forte). */
  phrase?: string;
  phraseLabel?: string;
  confirmLabel?: string;
  danger?: boolean;
  /** Case à cocher obligatoire dans le dialogue (envoyée avec le formulaire). */
  checkbox?: { name: string; label: string };
  /** Champ texte facultatif dans le dialogue (envoyé avec le formulaire). */
  input?: { name: string; label: string; help?: string; placeholder?: string };
};

/** Bouton copier-dans-le-presse-papiers avec retour visuel. */
export function CopyButton({ value, label = "Copier" }: { value: string; label?: string }) {
  const [done, setDone] = React.useState(false);
  return (
    <Button
      type="button"
      variant="secondary"
      size="sm"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setDone(true);
          setTimeout(() => setDone(false), 1600);
        } catch {
          setDone(false);
        }
      }}
    >
      {done ? <Check size={14} /> : <Copy size={14} />}
      {done ? "Copié" : label}
    </Button>
  );
}

/** Lien à transmettre manuellement (e-mail non configuré). */
export function LinkToCopy({ value }: { value: string }) {
  return (
    <div className="mt-2 flex items-center gap-2">
      <Input readOnly value={value} className="num h-8 text-[12.5px]" onFocus={(e) => e.currentTarget.select()} aria-label="Lien à copier" />
      <CopyButton value={value} />
    </div>
  );
}

export function ResultNotice({ state, className }: { state: ActionState; className?: string }) {
  if (state.error) return <Notice tone="danger" className={className}>{state.error}</Notice>;
  if (!state.ok || !state.message) return null;
  const links = [state.data?.link, ...(state.data?.links?.split("\n") ?? [])].filter(Boolean) as string[];
  return (
    <Notice tone={links.length ? "warn" : "ok"} className={className}>
      {state.message}
      {links.map((l) => {
        const url = l.includes(" : http") ? l.slice(l.indexOf(" : ") + 3) : l;
        const label = l.includes(" : http") ? l.slice(0, l.indexOf(" : ")) : null;
        return (
          <div key={l} className="mt-2">
            {label ? <p className="text-[12.5px] font-medium">{label}</p> : null}
            <LinkToCopy value={url} />
          </div>
        );
      })}
    </Notice>
  );
}

/**
 * Formulaire branché sur une server action (useActionState), avec confirmation explicite optionnelle.
 * Les enfants sont les champs du formulaire.
 */
export function ActionForm({
  action,
  children,
  submitLabel,
  submitVariant = "primary",
  submitSize = "md",
  confirm,
  className,
  footerClassName,
  hideResult = false,
  onDone,
}: {
  action: ServerAction;
  children?: React.ReactNode;
  submitLabel: string;
  submitVariant?: ButtonProps["variant"];
  submitSize?: ButtonProps["size"];
  confirm?: ConfirmSpec;
  className?: string;
  footerClassName?: string;
  hideResult?: boolean;
  onDone?: (state: ActionState) => void;
}) {
  const [checked, setChecked] = React.useState(false);
  const formId = React.useId();
  const formRef = React.useRef<HTMLFormElement>(null);
  const [open, setOpen] = React.useState(false);
  const [typed, setTyped] = React.useState("");
  // L'action est enveloppée : les mises à jour d'état suivent le résultat, sans effet en cascade.
  const run = React.useCallback(
    async (prev: ActionState, fd: FormData) => {
      const next = await action(prev, fd);
      if (next.ok) {
        setOpen(false);
        setTyped("");
        setChecked(false);
      }
      onDone?.(next);
      return next;
    },
    [action, onDone],
  );
  const [state, formAction, pending] = useActionState(run, {});
  const phraseOk = (!confirm?.phrase || typed.trim() === confirm.phrase) && (!confirm?.checkbox || checked);

  return (
    <div className={className}>
      <form id={formId} ref={formRef} action={formAction} className="contents">
        {children}
        <div className={cn("flex flex-wrap items-center gap-2", footerClassName)}>
          {confirm ? (
            <Button type="button" variant={submitVariant} size={submitSize} onClick={() => setOpen(true)} loading={pending && !open}>
              {submitLabel}
            </Button>
          ) : (
            <Button type="submit" variant={submitVariant} size={submitSize} loading={pending}>
              {submitLabel}
            </Button>
          )}
        </div>
      </form>
      {!hideResult ? <ResultNotice state={state} className="mt-3" /> : null}
      {confirm ? (
        <Dialog
          open={open}
          onOpenChange={(o) => {
            setOpen(o);
            if (!o) {
              setTyped("");
              setChecked(false);
            }
          }}
        >
          <DialogContent title={confirm.title} description={confirm.description}>
            <div className="space-y-4">
              {confirm.phrase ? (
                <Field label={confirm.phraseLabel ?? `Pour confirmer, saisissez « ${confirm.phrase} »`} htmlFor={`${formId}-confirm`}>
                  <Input id={`${formId}-confirm`} name="confirm" form={formId} value={typed} onChange={(e) => setTyped(e.target.value)} autoComplete="off" spellCheck={false} />
                </Field>
              ) : null}
              {confirm.input ? (
                <Field label={confirm.input.label} help={confirm.input.help} htmlFor={`${formId}-extra`}>
                  <Input id={`${formId}-extra`} name={confirm.input.name} form={formId} placeholder={confirm.input.placeholder} autoComplete="off" />
                </Field>
              ) : null}
              {confirm.checkbox ? (
                <Checkbox name={confirm.checkbox.name} form={formId} label={confirm.checkbox.label} checked={checked} onChange={(e) => setChecked(e.target.checked)} />
              ) : null}
              {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
              <div className="flex justify-end gap-2">
                <DialogClose asChild>
                  <Button type="button" variant="secondary">
                    Annuler
                  </Button>
                </DialogClose>
                <Button type="submit" form={formId} variant={confirm.danger ? "danger" : "primary"} disabled={!phraseOk} loading={pending}>
                  {confirm.confirmLabel ?? submitLabel}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      ) : null}
    </div>
  );
}

/** Action en un bouton (champs cachés) avec confirmation optionnelle. */
export function ActionButton({
  action,
  fields,
  label,
  variant = "secondary",
  size = "sm",
  confirm,
  className,
}: {
  action: ServerAction;
  fields: Record<string, string>;
  label: string;
  variant?: ButtonProps["variant"];
  size?: ButtonProps["size"];
  confirm?: ConfirmSpec;
  className?: string;
}) {
  return (
    <ActionForm action={action} submitLabel={label} submitVariant={variant} submitSize={size} confirm={confirm} className={className}>
      {Object.entries(fields).map(([k, v]) => (
        <input key={k} type="hidden" name={k} value={v} />
      ))}
    </ActionForm>
  );
}
