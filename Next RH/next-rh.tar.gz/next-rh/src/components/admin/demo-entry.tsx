"use client";

import { useActionState } from "react";
import { ArrowRight } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/surface";
import { enterDemoAction } from "@/server/actions/demo";

/** Bouton d'entrée en démonstration : crée un espace neuf puis redirige (gestionnaire ou salarié). */
export function DemoEntry({ as, label, primary }: { as: "manager" | "employee"; label: string; primary?: boolean }) {
  const [state, action, pending] = useActionState(enterDemoAction, {});
  return (
    <form action={action}>
      <input type="hidden" name="as" value={as} />
      <Button type="submit" size="lg" variant={primary ? "primary" : "secondary"} loading={pending} className="w-full justify-between sm:w-auto">
        {pending ? "Préparation de l'espace…" : label}
        {!pending ? <ArrowRight size={16} /> : null}
      </Button>
      {state.error ? (
        <Notice tone="danger" className="mt-3">
          {state.error}
        </Notice>
      ) : null}
    </form>
  );
}
