/** Nombre de paramètres feuilles (valeurs scalaires) d'un objet JSON (jeu de règles de paie). */
export function countLeaves(v: unknown): number {
  if (v === null || typeof v !== "object") return 1;
  const values = Array.isArray(v) ? v : Object.values(v);
  return values.reduce<number>((a, x) => a + countLeaves(x), 0);
}

export function fmtBytes(n: number): string {
  if (n < 1024) return `${n} o`;
  if (n < 1024 * 1024) return `${(n / 1024).toLocaleString("fr-FR", { maximumFractionDigits: 1 })} Ko`;
  return `${(n / 1024 / 1024).toLocaleString("fr-FR", { maximumFractionDigits: 1 })} Mo`;
}
