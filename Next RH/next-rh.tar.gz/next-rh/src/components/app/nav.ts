import type { Permission } from "@/server/authz";

export type NavItem = { label: string; href: string; icon: string; perm?: Permission; group?: string };

/** Navigation d'une entreprise ; `href` est relatif à /app/[companyId]. */
export const companyNav: NavItem[] = [
  { label: "Tableau de bord", href: "", icon: "SquaresFour" },
  { label: "Onboarding", href: "/onboarding", icon: "ListChecks", perm: "company.manage" },
  { label: "Salariés", href: "/salaries", icon: "Users", perm: "employees.read" },
  { label: "Paie", href: "/paie", icon: "Receipt", perm: "payroll.prepare", group: "Paie" },
  { label: "Déclarations et exports", href: "/declarations", icon: "PaperPlaneTilt", perm: "payroll.prepare", group: "Paie" },
  { label: "Congés et absences", href: "/conges", icon: "CalendarBlank", perm: "employees.read", group: "RH" },
  { label: "Temps de travail", href: "/temps", icon: "Clock", perm: "employees.read", group: "RH" },
  { label: "Télétravail", href: "/teletravail", icon: "HouseLine", perm: "employees.read", group: "RH" },
  { label: "Notes de frais", href: "/frais", icon: "Wallet", perm: "employees.read", group: "RH" },
  { label: "Arrivées et départs", href: "/cycle-de-vie", icon: "ArrowsLeftRight", perm: "employees.write", group: "RH" },
  { label: "Entretiens", href: "/entretiens", icon: "ChatsCircle", perm: "employees.read", group: "RH" },
  { label: "Formations", href: "/formations", icon: "GraduationCap", perm: "employees.read", group: "RH" },
  { label: "Demandes", href: "/demandes", icon: "Tray", perm: "requests.approve", group: "RH" },
  { label: "Documents", href: "/documents", icon: "Files", perm: "documents.read", group: "Documents" },
  { label: "Atelier de rédaction", href: "/atelier", icon: "PencilLine", perm: "documents.write", group: "Documents" },
  { label: "Annuaire", href: "/annuaire", icon: "AddressBook", perm: "employees.read", group: "Organisation" },
  { label: "Échéances", href: "/echeances", icon: "Bell", perm: "employees.read", group: "Organisation" },
  { label: "Rapports", href: "/rapports", icon: "ChartBar", perm: "reports.read", group: "Organisation" },
  { label: "Paramètres", href: "/parametres", icon: "GearSix", perm: "company.manage", group: "Organisation" },
];

export const employeeNav: NavItem[] = [
  { label: "Mon espace", href: "", icon: "SquaresFour" },
  { label: "Mes documents", href: "/documents", icon: "Files" },
  { label: "Mes congés", href: "/conges", icon: "CalendarBlank" },
  { label: "Mes notes de frais", href: "/frais", icon: "Wallet" },
  { label: "Mes demandes", href: "/demandes", icon: "Tray" },
  { label: "Mes informations", href: "/informations", icon: "IdentificationCard" },
];

export const adminNav: NavItem[] = [
  { label: "Vue d'ensemble", href: "", icon: "SquaresFour" },
  { label: "Organisations", href: "/organisations", icon: "Buildings" },
  { label: "Utilisateurs", href: "/utilisateurs", icon: "Users" },
  { label: "Tarifs", href: "/tarifs", icon: "Tag" },
  { label: "Règles de paie", href: "/regles-paie", icon: "Scales" },
  { label: "Modèles de documents", href: "/modeles", icon: "FileText" },
  { label: "Boîte d'envoi", href: "/boite-envoi", icon: "EnvelopeSimple" },
  { label: "Tâches", href: "/taches", icon: "Queue" },
  { label: "Journal d'audit", href: "/audit", icon: "ShieldCheck" },
  { label: "Sauvegardes", href: "/sauvegardes", icon: "Database" },
  { label: "Registre des traitements", href: "/registre", icon: "Notebook" },
  { label: "Intégrations", href: "/integrations", icon: "Plugs" },
];
