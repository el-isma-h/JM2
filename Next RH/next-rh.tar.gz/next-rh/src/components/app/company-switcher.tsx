"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CaretUpDown } from "@phosphor-icons/react";
import { Select } from "@/components/ui/field";

export function CompanySwitcher({ companies, currentId, isDemo }: { companies: { id: string; name: string }[]; currentId: string; isDemo?: boolean }) {
  const router = useRouter();
  if (companies.length <= 1) {
    const c = companies[0];
    return (
      <div className="px-2">
        <p className="truncate text-[13px] font-medium text-ink">{c?.name ?? "Entreprise"}</p>
        {isDemo ? <p className="text-[11.5px] text-warn-ink">Démonstration (données fictives)</p> : null}
      </div>
    );
  }
  return (
    <div className="relative">
      <Select value={currentId} onChange={(e) => router.push(`/app/${e.target.value}`)} aria-label="Changer d'entreprise" className="h-9 pr-8 text-[13px] font-medium">
        {companies.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name}
          </option>
        ))}
      </Select>
      <CaretUpDown size={14} className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-ink-3" />
      <Link href="/app/entreprises" className="mt-1.5 block px-1 text-[12px] text-ink-3 hover:text-ink">
        Tous les dossiers
      </Link>
    </div>
  );
}
