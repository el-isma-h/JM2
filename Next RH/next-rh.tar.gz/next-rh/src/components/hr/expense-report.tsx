import { Paperclip, Trash } from "@phosphor-icons/react/ssr";
import { ActionButton, ActionForm, type ServerAction } from "@/components/hr/action-form";
import { EmptyState, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { Field, Input, Select } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { categoryLabel, EXPENSE_CATEGORIES } from "@/server/hr/expenses";

type Line = { id: string; date: string; category: string; label: string; amountCents: number; vatCents: number; receiptDocumentId: string | null };

/** Détail d'une note de frais : lignes, justificatifs, ajout de dépense (partagé RH / espace salarié). */
export function ExpenseLines({
  lines,
  totalCents,
  editable,
  hidden,
  addAction,
  removeAction,
  linkAction,
  linkHidden,
}: {
  lines: Line[];
  totalCents: number;
  editable: boolean;
  hidden: Record<string, string>;
  addAction: ServerAction;
  removeAction: ServerAction;
  linkAction: ServerAction;
  linkHidden: Record<string, string>;
}) {
  const vat = lines.reduce((s, l) => s + l.vatCents, 0);
  return (
    <div className="space-y-6">
      <Panel>
        <PanelHeader title="Dépenses" description={`${lines.length} dépense(s), total ${formatCents(totalCents)} TTC dont ${formatCents(vat)} de TVA.`} />
        {lines.length ? (
          <Table>
            <thead>
              <tr>
                <Th>Date</Th>
                <Th>Catégorie</Th>
                <Th>Description</Th>
                <Th>Justificatif</Th>
                <Th num>TVA</Th>
                <Th num>Montant TTC</Th>
                {editable ? <Th className="text-right">Retirer</Th> : null}
              </tr>
            </thead>
            <tbody>
              {lines.map((l) => (
                <tr key={l.id}>
                  <Td className="whitespace-nowrap">{fmtDate(l.date)}</Td>
                  <Td>{categoryLabel(l.category)}</Td>
                  <Td>{l.label}</Td>
                  <Td>
                    {l.receiptDocumentId ? (
                      <ActionButton action={linkAction} hidden={{ ...linkHidden, documentId: l.receiptDocumentId }} label="Ouvrir" variant="link" icon={<Paperclip size={14} />} />
                    ) : l.category === "kilometrique" ? (
                      <span className="text-ink-3">Non requis</span>
                    ) : (
                      <Badge tone="warn">Manquant</Badge>
                    )}
                  </Td>
                  <Td num>{formatCents(l.vatCents)}</Td>
                  <Td num className="font-medium">
                    {formatCents(l.amountCents)}
                  </Td>
                  {editable ? (
                    <Td className="text-right">
                      <ActionButton action={removeAction} hidden={{ ...hidden, lineId: l.id }} label="" ariaLabel={`Retirer ${l.label}`} variant="ghost" icon={<Trash size={15} />} />
                    </Td>
                  ) : null}
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <Td colSpan={5} className="text-right font-medium">
                  Total à rembourser
                </Td>
                <Td num className="text-[15px] font-semibold">
                  {formatCents(totalCents)}
                </Td>
                {editable ? <Td /> : null}
              </tr>
            </tfoot>
          </Table>
        ) : (
          <EmptyState title="Aucune dépense" description="Ajoutez chaque dépense avec son justificatif (ticket, facture)." />
        )}
      </Panel>

      {editable ? (
        <Panel>
          <PanelHeader title="Ajouter une dépense" />
          <div className="p-5">
            <ActionForm action={addAction} hidden={hidden} submitLabel="Ajouter la dépense">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <Field label="Date" required htmlFor="xl-date">
                  <Input id="xl-date" name="date" type="date" required />
                </Field>
                <Field label="Catégorie" required htmlFor="xl-cat">
                  <Select id="xl-cat" name="category" required defaultValue="transport">
                    {EXPENSE_CATEGORIES.map((c) => (
                      <option key={c.value} value={c.value}>
                        {c.label}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Montant TTC (euros)" required htmlFor="xl-amount">
                  <Input id="xl-amount" name="amount" inputMode="decimal" required placeholder="0,00" />
                </Field>
                <Field label="Dont TVA (euros)" htmlFor="xl-vat" help="Facultatif, figure sur le ticket.">
                  <Input id="xl-vat" name="vat" inputMode="decimal" placeholder="0,00" />
                </Field>
                <Field label="Description" required htmlFor="xl-label" className="sm:col-span-2">
                  <Input id="xl-label" name="label" required placeholder="Train Paris Lyon aller-retour, rendez-vous client" />
                </Field>
                <Field label="Justificatif" htmlFor="xl-receipt" className="sm:col-span-2" help="PDF ou photo, 10 Mo maximum.">
                  <Input id="xl-receipt" name="receipt" type="file" accept="application/pdf,image/jpeg,image/png,image/webp,image/heic" className="py-1.5" />
                </Field>
              </div>
            </ActionForm>
          </div>
        </Panel>
      ) : null}
    </div>
  );
}
