"use client";

import * as React from "react";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Button, type ButtonProps } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Notice } from "@/components/ui/surface";
import { cn } from "@/lib/utils";
import type { ActionState } from "@/server/actions/auth";

export type ServerAction = (prev: ActionState, fd: FormData) => Promise<ActionState>;

function Hidden({ values }: { values?: Record<string, string> }) {
  if (!values) return null;
  return (
    <>
      {Object.entries(values).map(([k, v]) => (
        <input key={k} type="hidden" name={k} value={v} />
      ))}
    </>
  );
}

/** Bouton d'envoi qui affiche l'état de chargement du formulaire parent. */
export function SubmitButton({ children, ...props }: ButtonProps) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" loading={pending} {...props}>
      {children}
    </Button>
  );
}

/** Suites communes d'une action réussie : navigation (data.href) ou téléchargement (data.url). */
function useAfterSuccess(state: ActionState, onSuccess?: () => void) {
  const router = useRouter();
  const last = React.useRef<ActionState | null>(null);
  React.useEffect(() => {
    if (state === last.current) return;
    last.current = state;
    if (!state.ok) return;
    if (state.data?.url) window.location.assign(state.data.url);
    else if (state.data?.href) router.push(state.data.href);
    onSuccess?.();
  }, [state, router, onSuccess]);
}

/**
 * Formulaire branché sur une server action `(prev, formData) => ActionState`.
 * Affiche l'erreur ou le message de succès ; réinitialise les champs après succès (désactivable).
 */
export function ActionForm({
  action,
  hidden,
  children,
  submitLabel = "Enregistrer",
  submitVariant = "primary",
  extraActions,
  className,
  resetOnSuccess = true,
  onSuccess,
}: {
  action: ServerAction;
  hidden?: Record<string, string>;
  children?: React.ReactNode;
  submitLabel?: string | null;
  submitVariant?: ButtonProps["variant"];
  extraActions?: React.ReactNode;
  className?: string;
  resetOnSuccess?: boolean;
  onSuccess?: () => void;
}) {
  const [state, formAction] = useActionState(action, {});
  const ref = React.useRef<HTMLFormElement>(null);
  const after = React.useCallback(() => {
    if (resetOnSuccess) ref.current?.reset();
    onSuccess?.();
  }, [resetOnSuccess, onSuccess]);
  useAfterSuccess(state, after);
  return (
    <form ref={ref} action={formAction} className={cn("space-y-4", className)}>
      <Hidden values={hidden} />
      {children}
      {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
      {state.ok && state.message ? <Notice tone="ok">{state.message}</Notice> : null}
      {submitLabel !== null || extraActions ? (
        <div className="flex flex-wrap items-center gap-2">
          {submitLabel !== null ? <SubmitButton variant={submitVariant}>{submitLabel}</SubmitButton> : null}
          {extraActions}
        </div>
      ) : null}
    </form>
  );
}

/**
 * Action en un clic (valider, refuser, cocher, télécharger). Option `confirm` : boîte de confirmation explicite.
 * Le message d'erreur s'affiche à côté du bouton.
 */
export function ActionButton({
  action,
  hidden,
  label,
  variant = "secondary",
  size = "sm",
  confirm,
  className,
  icon,
  ariaLabel,
  showSuccess = false,
}: {
  action: ServerAction;
  hidden: Record<string, string>;
  label: React.ReactNode;
  variant?: ButtonProps["variant"];
  size?: ButtonProps["size"];
  confirm?: { title: string; description?: string; confirmLabel: string; withNote?: string };
  className?: string;
  icon?: React.ReactNode;
  ariaLabel?: string;
  showSuccess?: boolean;
}) {
  const [state, formAction] = useActionState(action, {});
  const [open, setOpen] = React.useState(false);
  const close = React.useCallback(() => setOpen(false), []);
  useAfterSuccess(state, close);
  const feedback = state.error ? (
    <span role="alert" className="text-[12.5px] text-danger-ink">
      {state.error}
    </span>
  ) : showSuccess && state.ok && state.message ? (
    <span role="status" className="text-[12.5px] text-ok-ink">
      {state.message}
    </span>
  ) : null;

  if (!confirm) {
    return (
      <form action={formAction} className={cn("inline-flex flex-wrap items-center gap-2", className)}>
        <Hidden values={hidden} />
        <SubmitButton variant={variant} size={size} aria-label={ariaLabel}>
          {icon}
          {label}
        </SubmitButton>
        {feedback}
      </form>
    );
  }
  return (
    <span className={cn("inline-flex flex-wrap items-center gap-2", className)}>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant={variant} size={size} aria-label={ariaLabel}>
            {icon}
            {label}
          </Button>
        </DialogTrigger>
        <DialogContent title={confirm.title} description={confirm.description}>
          <form action={formAction} className="space-y-4">
            <Hidden values={hidden} />
            {confirm.withNote ? (
              <label className="block text-[13px] font-medium text-ink">
                {confirm.withNote}
                <textarea name="note" className="mt-1.5 min-h-20 w-full rounded-[var(--radius-sm)] border border-line-strong bg-bg-elev px-3 py-2 text-sm font-normal focus:border-accent focus:outline-none focus:ring-2 focus:ring-focus/35" />
              </label>
            ) : null}
            {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
            <div className="flex justify-end gap-2">
              <DialogClose asChild>
                <Button type="button" variant="ghost">
                  Annuler
                </Button>
              </DialogClose>
              <SubmitButton variant={variant === "danger" ? "danger" : "primary"}>{confirm.confirmLabel}</SubmitButton>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      {feedback}
    </span>
  );
}

/** Formulaire dans une boîte de dialogue (création rapide depuis un en-tête de page). */
export function DialogForm({
  trigger,
  title,
  description,
  action,
  hidden,
  submitLabel,
  children,
  triggerVariant = "primary",
  triggerSize = "md",
  wide,
  closeOnSuccess = true,
}: {
  closeOnSuccess?: boolean;
  trigger: React.ReactNode;
  title: string;
  description?: string;
  action: ServerAction;
  hidden?: Record<string, string>;
  submitLabel: string;
  children: React.ReactNode;
  triggerVariant?: ButtonProps["variant"];
  triggerSize?: ButtonProps["size"];
  wide?: boolean;
}) {
  const [open, setOpen] = React.useState(false);
  const close = React.useCallback(() => setOpen(false), []);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={triggerVariant} size={triggerSize}>
          {trigger}
        </Button>
      </DialogTrigger>
      <DialogContent title={title} description={description} className={cn("max-h-[90dvh] overflow-y-auto", wide && "max-w-2xl")}>
        <ActionForm action={action} hidden={hidden} submitLabel={submitLabel} onSuccess={closeOnSuccess ? close : undefined}>
          {children}
        </ActionForm>
      </DialogContent>
    </Dialog>
  );
}
