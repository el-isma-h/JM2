import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Graphiques légers en HTML/SVG, sans bibliothèque : lisibles au lecteur d'écran (valeurs en texte),
 * une seule teinte d'accent, valeurs en chiffres tabulaires.
 */

export function BarList({
  items,
  format = (n) => n.toLocaleString("fr-FR"),
  className,
  caption,
}: {
  items: { label: string; value: number; hint?: string }[];
  format?: (n: number) => string;
  className?: string;
  caption: string;
}) {
  const max = Math.max(1, ...items.map((i) => i.value));
  if (!items.length) return <p className="text-[13px] text-ink-3">Aucune donnée.</p>;
  return (
    <table className={cn("w-full text-[13px]", className)}>
      <caption className="sr-only">{caption}</caption>
      <tbody>
        {items.map((it) => (
          <tr key={it.label} className="align-middle">
            <th scope="row" className="w-[38%] max-w-0 truncate py-1.5 pr-3 text-left font-normal text-ink-2" title={it.label}>
              {it.label}
            </th>
            <td className="py-1.5" aria-hidden>
              <div className="h-2.5 rounded-none bg-accent" style={{ width: `${Math.max(2, (it.value / max) * 100)}%`, opacity: 0.85 }} />
            </td>
            <td className="num w-[22%] py-1.5 pl-3 text-right text-ink">
              {format(it.value)}
              {it.hint ? <span className="ml-1 text-[11.5px] text-ink-3">{it.hint}</span> : null}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/** Histogramme mensuel en SVG avec tableau de valeurs masqué pour l'accessibilité. */
export function ColumnChart({
  data,
  format = (n) => n.toLocaleString("fr-FR"),
  title,
  height = 160,
}: {
  data: { label: string; value: number }[];
  format?: (n: number) => string;
  title: string;
  height?: number;
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  const w = 100 / Math.max(1, data.length);
  return (
    <figure className="w-full">
      <svg viewBox={`0 0 100 ${height / 2}`} preserveAspectRatio="none" className="h-[160px] w-full" role="img" aria-label={title}>
        <title>{title}</title>
        <line x1="0" x2="100" y1={height / 2 - 0.25} y2={height / 2 - 0.25} stroke="var(--line-strong)" strokeWidth="0.5" vectorEffect="non-scaling-stroke" />
        {data.map((d, i) => {
          const h = (d.value / max) * (height / 2 - 4);
          return (
            <rect key={d.label} x={i * w + w * 0.18} y={height / 2 - h - 0.5} width={w * 0.64} height={Math.max(h, d.value > 0 ? 0.6 : 0)} rx="0.6" fill="var(--accent)" opacity={i === data.length - 1 ? 1 : 0.72}>
              <title>{`${d.label} : ${format(d.value)}`}</title>
            </rect>
          );
        })}
      </svg>
      <div className="mt-1.5 grid text-center text-[11px] text-ink-3" style={{ gridTemplateColumns: `repeat(${data.length}, minmax(0, 1fr))` }} aria-hidden>
        {data.map((d) => (
          <span key={d.label} className="truncate capitalize">
            {d.label}
          </span>
        ))}
      </div>
      <table className="sr-only">
        <caption>{title}</caption>
        <tbody>
          {data.map((d) => (
            <tr key={d.label}>
              <th scope="row">{d.label}</th>
              <td>{format(d.value)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </figure>
  );
}

/** Répartition en une barre segmentée (ex. F / H), avec légende textuelle. */
export function SplitBar({ parts, caption }: { parts: { label: string; value: number; tone: "accent" | "muted" | "ink" }[]; caption: string }) {
  const total = parts.reduce((s, p) => s + p.value, 0);
  const fill = { accent: "bg-accent", muted: "bg-line-strong", ink: "bg-ink-2" };
  return (
    <div>
      <div className="flex h-2.5 w-full gap-0.5 overflow-hidden rounded-none" aria-hidden>
        {parts.map((p) => (p.value > 0 ? <div key={p.label} className={fill[p.tone]} style={{ width: `${(p.value / Math.max(1, total)) * 100}%` }} /> : null))}
      </div>
      <p className="sr-only">{caption}</p>
      <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12.5px] text-ink-2">
        {parts.map((p) => (
          <li key={p.label} className="flex items-center gap-1.5">
            <span aria-hidden className={cn("h-2 w-2 rounded-none", fill[p.tone])} />
            {p.label}
            <span className="num text-ink">{p.value}</span>
            <span className="num text-ink-3">({total ? Math.round((p.value / total) * 1000) / 10 : 0} %)</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
