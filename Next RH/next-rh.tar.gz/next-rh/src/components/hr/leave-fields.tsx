import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";

/** Champs communs d'une demande d'absence (RH ou salarié). */
export function LeaveFields({
  types,
  employees,
  balances,
  rh,
}: {
  types: { id: string; label: string; requiresProof: boolean; code: string }[];
  employees?: { id: string; name: string }[];
  balances?: Record<string, number>;
  rh?: boolean;
}) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {employees ? (
        <Field label="Salarié" required htmlFor="lv-employee" className="sm:col-span-2">
          <Select id="lv-employee" name="employeeId" required defaultValue="">
            <option value="" disabled>
              Choisir un salarié
            </option>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </Select>
        </Field>
      ) : null}
      <Field label="Type d'absence" required htmlFor="lv-type" className="sm:col-span-2" help="Un justificatif est demandé pour les arrêts maladie, événements familiaux et congés de naissance.">
        <Select id="lv-type" name="leaveTypeId" required defaultValue="">
          <option value="" disabled>
            Choisir un type
          </option>
          {types.map((t) => (
            <option key={t.id} value={t.id}>
              {t.label}
              {t.requiresProof ? " (justificatif requis)" : ""}
              {balances && balances[t.id] !== undefined ? ` : ${balances[t.id].toLocaleString("fr-FR")} j disponibles` : ""}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Premier jour" required htmlFor="lv-start">
        <Input id="lv-start" name="startDate" type="date" required />
      </Field>
      <Field label="Dernier jour" required htmlFor="lv-end">
        <Input id="lv-end" name="endDate" type="date" required />
      </Field>
      <Checkbox name="startHalfDay" label="Commence l'après-midi" />
      <Checkbox name="endHalfDay" label="Se termine à midi" />
      <Field label="Commentaire" htmlFor="lv-reason" className="sm:col-span-2">
        <Textarea id="lv-reason" name="reason" className="min-h-16" placeholder="Facultatif" />
      </Field>
      <Field label="Justificatif" htmlFor="lv-proof" className="sm:col-span-2" help="PDF ou photo, 10 Mo maximum. Peut être ajouté plus tard.">
        <Input id="lv-proof" name="proof" type="file" accept="application/pdf,image/jpeg,image/png,image/webp,image/heic" className="py-1.5" />
      </Field>
      {rh ? (
        <div className="space-y-2 sm:col-span-2">
          <Checkbox name="approveNow" defaultChecked label="Valider immédiatement (saisie par le service RH)" />
          <Checkbox name="allowNegative" label="Autoriser un solde négatif (pose par anticipation)" />
        </div>
      ) : null}
      <p className="text-[12.5px] text-ink-3 sm:col-span-2">
        La durée est calculée automatiquement en jours ouvrés, hors week-ends et jours fériés.
      </p>
    </div>
  );
}
