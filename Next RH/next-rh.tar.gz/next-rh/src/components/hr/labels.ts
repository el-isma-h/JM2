import type { Tone } from "@/components/ui/badge";

export const interviewKindTitle: Record<string, string> = {
  annuel: "Entretien annuel",
  professionnel: "Entretien professionnel",
  fin_periode_essai: "Fin de période d'essai",
  retour_absence: "Retour d'absence",
  recadrage: "Entretien de recadrage",
  autre: "Autre entretien",
};

const interviewStatuses: Record<string, { label: string; tone: Tone }> = {
  planned: { label: "Planifié", tone: "info" },
  done: { label: "Réalisé", tone: "ok" },
  cancelled: { label: "Annulé", tone: "neutral" },
};
export const interviewStatus = (s: string) => interviewStatuses[s] ?? { label: s, tone: "neutral" as Tone };

export const contractTypeLabels: Record<string, string> = {
  CDI: "CDI",
  CDD: "CDD",
  APPRENTISSAGE: "Apprentissage",
  PROFESSIONNALISATION: "Professionnalisation",
  STAGE: "Stage",
  INTERIM: "Intérim",
  MANDAT: "Mandat social",
};

export const categoryLabels: Record<string, string> = {
  non_cadre: "Non-cadre",
  cadre: "Cadre",
  cadre_dirigeant: "Cadre dirigeant",
  apprenti: "Apprenti",
  stagiaire: "Stagiaire",
};
