import * as React from "react";
import Link from "next/link";
import { CaretLeft, CaretRight } from "@phosphor-icons/react/dist/ssr";
import { cn, initials } from "@/lib/utils";
import { monthLabel } from "@/lib/dates";
import { Badge, type Tone } from "@/components/ui/badge";

/** Pastille d'initiales (pas de faux avatar). */
export function Initials({ first, last, size = "md", className }: { first: string; last: string; size?: "sm" | "md" | "lg"; className?: string }) {
  const s = { sm: "h-7 w-7 text-[11px]", md: "h-9 w-9 text-[12.5px]", lg: "h-12 w-12 text-[15px]" }[size];
  return (
    <span aria-hidden className={cn("inline-flex shrink-0 items-center justify-center rounded-none bg-accent-soft font-semibold text-accent-strong", s, className)}>
      {initials(first, last)}
    </span>
  );
}

export function Person({ first, last, sub, href }: { first: string; last: string; sub?: React.ReactNode; href?: string }) {
  const name = `${first} ${last}`;
  return (
    <span className="flex min-w-0 items-center gap-2.5">
      <Initials first={first} last={last} size="sm" />
      <span className="min-w-0">
        {href ? (
          <Link href={href} className="block truncate font-medium text-ink hover:underline">
            {name}
          </Link>
        ) : (
          <span className="block truncate font-medium text-ink">{name}</span>
        )}
        {sub ? <span className="block truncate text-[12px] text-ink-3">{sub}</span> : null}
      </span>
    </span>
  );
}

const pad = (n: number) => String(n).padStart(2, "0");

/** Navigation mois précédent / suivant via `?mois=AAAA-MM` (conserve les autres paramètres). */
export function MonthNav({ base, year, month, params = {} }: { base: string; year: number; month: number; params?: Record<string, string | undefined> }) {
  const prev = month === 1 ? { y: year - 1, m: 12 } : { y: year, m: month - 1 };
  const next = month === 12 ? { y: year + 1, m: 1 } : { y: year, m: month + 1 };
  const href = (y: number, m: number) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) q.set(k, v);
    q.set("mois", `${y}-${pad(m)}`);
    return `${base}?${q.toString()}`;
  };
  return (
    <div className="inline-flex items-center gap-1 rounded-[var(--radius-sm)] border border-line-strong bg-bg-elev p-0.5">
      <Link href={href(prev.y, prev.m)} className="rounded-none p-1.5 text-ink-2 hover:bg-bg-sunken hover:text-ink" aria-label="Mois précédent">
        <CaretLeft size={14} />
      </Link>
      <span className="min-w-[128px] px-1 text-center text-[13px] font-medium capitalize text-ink" aria-live="polite">
        {monthLabel(year, month)}
      </span>
      <Link href={href(next.y, next.m)} className="rounded-none p-1.5 text-ink-2 hover:bg-bg-sunken hover:text-ink" aria-label="Mois suivant">
        <CaretRight size={14} />
      </Link>
    </div>
  );
}

/** Onglets en liens (vue choisie dans l'URL : partageable, accessible). */
export function LinkTabs({ items, current, label }: { items: { key: string; label: string; href: string; count?: number }[]; current: string; label: string }) {
  return (
    <nav aria-label={label} className="mb-5 flex flex-wrap gap-1 border-b border-line">
      {items.map((it) => {
        const active = it.key === current;
        return (
          <Link
            key={it.key}
            href={it.href}
            aria-current={active ? "page" : undefined}
            className={cn(
              "-mb-px inline-flex items-center gap-1.5 border-b-2 px-3 py-2 text-[13.5px] transition-colors",
              active ? "border-accent font-medium text-ink" : "border-transparent text-ink-2 hover:text-ink",
            )}
          >
            {it.label}
            {it.count !== undefined && it.count > 0 ? <span className="num rounded-none bg-bg-muted px-1.5 text-[11.5px] text-ink-2">{it.count}</span> : null}
          </Link>
        );
      })}
    </nav>
  );
}

export function ToneBadge({ tone, children }: { tone: Tone; children: React.ReactNode }) {
  return <Badge tone={tone}>{children}</Badge>;
}

/** Délai lisible avant une échéance. */
export function DueIn({ days }: { days: number }) {
  if (days < 0) return <Badge tone="danger">En retard de {-days} j</Badge>;
  if (days === 0) return <Badge tone="warn">Aujourd&apos;hui</Badge>;
  if (days <= 7) return <Badge tone="warn">Dans {days} j</Badge>;
  if (days <= 30) return <Badge tone="info">Dans {days} j</Badge>;
  return <Badge tone="neutral">Dans {days} j</Badge>;
}

export function SectionTitle({ children, actions }: { children: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
      <h2 className="text-[15px] font-semibold text-ink">{children}</h2>
      {actions}
    </div>
  );
}
