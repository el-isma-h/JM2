"use client";

import * as React from "react";
import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { Select } from "@/components/ui/field";
import type { ServerAction } from "./action-form";

/** Choix de la fiche salarié active quand l'utilisateur a plusieurs employeurs dans Next RH. */
export function SelfSwitcher({ action, records, currentId }: { action: ServerAction; records: { id: string; label: string }[]; currentId: string }) {
  const [state, formAction] = useActionState(action, {});
  const router = useRouter();
  const ref = React.useRef<HTMLFormElement>(null);
  React.useEffect(() => {
    if (state.ok) router.refresh();
  }, [state, router]);
  if (records.length <= 1) {
    return <p className="truncate px-2 text-[13px] font-medium text-ink">{records[0]?.label}</p>;
  }
  return (
    <form ref={ref} action={formAction}>
      <label htmlFor="self-switch" className="sr-only">
        Employeur
      </label>
      <Select id="self-switch" name="employeeId" defaultValue={currentId} onChange={() => ref.current?.requestSubmit()} className="h-9 text-[13px] font-medium">
        {records.map((r) => (
          <option key={r.id} value={r.id}>
            {r.label}
          </option>
        ))}
      </Select>
      {state.error ? <p className="mt-1 text-[12px] text-danger-ink">{state.error}</p> : null}
    </form>
  );
}
