"use client";

import * as React from "react";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent } from "@/components/ui/dialog";
import { Select } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";
import type { ActionState } from "@/server/actions/auth";
import { FIRM_ROLES } from "./roles";

/** Cellule de la matrice d'affectation : changement de rôle avec confirmation explicite. */
export function RoleCell({
  action,
  companyId,
  companyName,
  userId,
  userName,
  current,
  disabled,
}: {
  action: (prev: ActionState, fd: FormData) => Promise<ActionState>;
  companyId: string;
  companyName: string;
  userId: string;
  userName: string;
  current: string;
  disabled?: boolean;
}) {
  const [pendingRole, setPendingRole] = React.useState<string | null>(null);
  const run = React.useCallback(
    async (prev: ActionState, fd: FormData) => {
      const next = await action(prev, fd);
      if (next.ok) setPendingRole(null);
      return next;
    },
    [action],
  );
  const [state, formAction, pending] = useActionState(run, {});
  const formRef = React.useRef<HTMLFormElement>(null);
  const label = (v: string) => FIRM_ROLES.find((r) => r.value === v)?.label ?? (v === "owner" ? "Propriétaire" : v);

  if (current === "owner" || disabled) {
    return <span className="text-[13px] text-ink-2">{current === "none" ? "-" : label(current)}</span>;
  }
  return (
    <form ref={formRef} action={formAction}>
      <input type="hidden" name="companyId" value={companyId} />
      <input type="hidden" name="userId" value={userId} />
      <input type="hidden" name="role" value={pendingRole ?? current} />
      <Select aria-label={`Rôle de ${userName} sur ${companyName}`} value={current} onChange={(e) => setPendingRole(e.target.value)} className="h-8 min-w-[140px] text-[13px]" disabled={pending}>
        {FIRM_ROLES.map((r) => (
          <option key={r.value} value={r.value}>
            {r.label}
          </option>
        ))}
      </Select>
      {state.error && !pendingRole ? <p className="mt-1 text-[11.5px] text-danger-ink">{state.error}</p> : null}
      <Dialog open={pendingRole !== null} onOpenChange={(o) => (o ? null : setPendingRole(null))}>
        <DialogContent
          title={pendingRole === "none" ? "Retirer l'accès" : "Changer le rôle"}
          description={pendingRole === "none" ? `${userName} n'aura plus accès à ${companyName}.` : `${userName} aura le rôle « ${label(pendingRole ?? "")} » sur ${companyName}. ${FIRM_ROLES.find((r) => r.value === pendingRole)?.help ?? ""}`}
        >
          {state.error ? <Notice tone="danger" className="mb-4">{state.error}</Notice> : null}
          <div className="flex justify-end gap-2">
            <DialogClose asChild>
              <Button type="button" variant="secondary">
                Annuler
              </Button>
            </DialogClose>
            <Button type="button" variant={pendingRole === "none" ? "danger" : "primary"} loading={pending} onClick={() => formRef.current?.requestSubmit()}>
              {pendingRole === "none" ? "Retirer l'accès" : "Confirmer"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </form>
  );
}
