/** Rôles attribuables à un gestionnaire sur un dossier (hors propriétaire et salarié). */
export const FIRM_ROLES: { value: string; label: string; help: string }[] = [
  { value: "none", label: "Aucun accès", help: "" },
  { value: "admin", label: "Administrateur", help: "Tout le dossier, y compris les accès." },
  { value: "payroll", label: "Paie", help: "Prépare, valide et clôture la paie, déclarations." },
  { value: "accountant", label: "Comptable", help: "Comme Paie, pour l'expert-comptable." },
  { value: "hr", label: "RH", help: "Salariés, documents et demandes, sans validation de paie." },
  { value: "manager", label: "Manager", help: "Valide les demandes de son équipe." },
  { value: "viewer", label: "Lecture seule", help: "Consulte sans modifier." },
];
