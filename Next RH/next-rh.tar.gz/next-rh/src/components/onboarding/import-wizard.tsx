"use client";

import * as React from "react";
import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Checkbox, Select } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Notice, Panel, PanelHeader, Stat } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { FadeIn } from "@/components/ui/motion";
import { applyImportAction, validateImportAction } from "@/server/actions/imports";
import type { ActionState } from "@/server/actions/auth";
import type { Duplicate, RowIssue } from "@/server/onboarding/import-spec";
import { FormMessage } from "./action-form";

type FieldInfo = { key: string; label: string; required: boolean; help?: string; auto: boolean };

export function ImportWizard({
  companyId,
  importId,
  status,
  headers,
  sample,
  totalRows,
  fields,
  mapping,
  issues,
  duplicates,
  validated,
  appliedCount,
  kind,
}: {
  companyId: string;
  importId: string;
  status: string;
  headers: string[];
  sample: Record<string, string>[];
  totalRows: number;
  fields: FieldInfo[];
  mapping: Record<string, string | null>;
  issues: RowIssue[];
  duplicates: Duplicate[];
  validated: boolean;
  appliedCount: number;
  kind: string;
}) {
  const router = useRouter();
  const [vState, validate, validating] = useActionState(validateImportAction, {} as ActionState);
  const [aState, apply, applying] = useActionState(applyImportAction, {} as ActionState);
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [skip, setSkip] = React.useState(false);
  React.useEffect(() => {
    if (vState.ok || aState.ok) router.refresh();
  }, [vState, aState, router]);

  const applied = status === "applied";
  const errors = issues.filter((i) => i.level === "error");
  const warnings = issues.filter((i) => i.level === "warning");
  const errorLines = new Set(errors.filter((e) => e.line > 1).map((e) => e.line));
  const dupLines = new Set(duplicates.map((d) => d.line));
  const blocked = new Set([...errorLines, ...dupLines]).size;
  const headerError = errors.some((e) => e.line === 1);
  const ready = totalRows - blocked;

  return (
    <div className="space-y-6">
      <Panel>
        <PanelHeader title="Aperçu du fichier" description={`${totalRows} ligne(s) de données. Voici les premières, telles que lues.`} />
        <Table className="max-h-72">
          <thead>
            <tr>
              <Th className="w-14">Ligne</Th>
              {headers.map((h) => (
                <Th key={h} className="whitespace-nowrap">{h}</Th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sample.map((r, i) => (
              <tr key={i}>
                <Td className="num text-ink-3">{i + 2}</Td>
                {headers.map((h) => (
                  <Td key={h} className="max-w-[180px] truncate whitespace-nowrap">{r[h] || <span className="text-ink-3">vide</span>}</Td>
                ))}
              </tr>
            ))}
          </tbody>
        </Table>
      </Panel>

      <form action={validate}>
        <input type="hidden" name="companyId" value={companyId} />
        <input type="hidden" name="importId" value={importId} />
        <Panel>
          <PanelHeader
            title="Correspondance des colonnes"
            description="Next RH a reconnu les colonnes d'après leur titre. Vérifiez chaque ligne et corrigez si besoin."
            actions={
              applied ? null : (
                <Button type="submit" loading={validating}>
                  Vérifier les données
                </Button>
              )
            }
          />
          <Table>
            <thead>
              <tr>
                <Th>Information attendue</Th>
                <Th>Colonne du fichier</Th>
                <Th>Exemple lu</Th>
              </tr>
            </thead>
            <tbody>
              {fields.map((f) => (
                <tr key={f.key}>
                  <Td>
                    <span className="font-medium">{f.label}</span>
                    {f.required ? <span className="ml-0.5 text-danger">*</span> : null}
                    {f.help ? <span className="block text-[12px] text-ink-3">{f.help}</span> : null}
                  </Td>
                  <Td className="w-[280px]">
                    <div className="flex items-center gap-2">
                      <Select name={`map.${f.key}`} defaultValue={mapping[f.key] ?? ""} disabled={applied} aria-label={`Colonne pour ${f.label}`}>
                        <option value="">Non importé</option>
                        {headers.map((h) => (
                          <option key={h} value={h}>
                            {h}
                          </option>
                        ))}
                      </Select>
                      {f.auto && mapping[f.key] ? <Badge tone="info">auto</Badge> : null}
                    </div>
                  </Td>
                  <Td className="max-w-[220px] truncate text-ink-2">{mapping[f.key] ? sample[0]?.[mapping[f.key]!] || "vide" : "-"}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Panel>
        <FormMessage state={vState} />
      </form>

      {validated || applied ? (
        <FadeIn>
          <Panel>
            <PanelHeader title="Rapport de contrôle" description="Format des numéros (sécurité sociale, IBAN), dates, montants, cohérence et doublons dans le fichier comme dans Next RH." />
            <div className="grid grid-cols-2 gap-5 border-b border-line px-5 py-4 sm:grid-cols-4">
              <Stat label="Lignes prêtes" value={applied ? appliedCount : Math.max(0, headerError ? 0 : ready)} />
              <Stat label="Lignes en erreur" value={errorLines.size} />
              <Stat label="Doublons" value={dupLines.size} />
              <Stat label="Alertes" value={warnings.length} hint="n'empêchent pas l'import" />
            </div>
            {errors.length === 0 && duplicates.length === 0 && warnings.length === 0 ? (
              <p className="px-5 py-4 text-[13.5px] text-ok-ink">Aucune anomalie détectée.</p>
            ) : (
              <Table className="max-h-[420px]">
                <thead>
                  <tr>
                    <Th className="w-16">Ligne</Th>
                    <Th className="w-28">Gravité</Th>
                    <Th>Détail</Th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ...errors.map((e) => ({ line: e.line, tone: "danger" as const, label: "Erreur", text: e.message })),
                    ...duplicates.map((d) => ({ line: d.line, tone: "danger" as const, label: "Doublon", text: d.reason })),
                    ...warnings.map((w) => ({ line: w.line, tone: "warn" as const, label: "Alerte", text: w.message })),
                  ]
                    .sort((a, b) => a.line - b.line)
                    .slice(0, 300)
                    .map((r, i) => (
                      <tr key={i}>
                        <Td className="num">{r.line === 0 ? "-" : r.line === 1 ? "En-têtes" : r.line}</Td>
                        <Td>
                          <Badge tone={r.tone}>{r.label}</Badge>
                        </Td>
                        <Td>{r.text}</Td>
                      </tr>
                    ))}
                </tbody>
              </Table>
            )}
            {applied ? (
              <Notice tone="ok" className="m-5">
                Import appliqué : {appliedCount} ligne(s) enregistrée(s).
              </Notice>
            ) : (
              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line px-5 py-4">
                <Checkbox checked={skip} onChange={(e) => setSkip(e.target.checked)} disabled={blocked === 0} label="Ignorer les lignes en erreur ou en doublon et importer le reste" />
                <Button type="button" onClick={() => setConfirmOpen(true)} loading={applying} disabled={headerError || ready <= 0 || (blocked > 0 && !skip)}>
                  Importer {Math.max(0, ready)} ligne(s)
                </Button>
              </div>
            )}
          </Panel>
        </FadeIn>
      ) : null}
      <FormMessage state={aState} />

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent title="Confirmer l'import" description={`${Math.max(0, ready)} ligne(s) seront enregistrées en une seule opération : en cas d'erreur, rien n'est enregistré.`}>
          <form
            action={(fd) => {
              setConfirmOpen(false);
              apply(fd);
            }}
          >
            <input type="hidden" name="companyId" value={companyId} />
            <input type="hidden" name="importId" value={importId} />
            {skip ? <input type="hidden" name="skipInvalid" value="on" /> : null}
            <p className="text-[13.5px] text-ink-2">
              {kind === "employees" ? "Les salariés seront créés avec leur contrat, leur rémunération actuelle et, le cas échéant, leurs coordonnées bancaires (chiffrées)." : "Les données seront rattachées aux salariés existants par leur matricule."}
              {blocked > 0 ? ` ${blocked} ligne(s) seront ignorées.` : ""}
            </p>
            <div className="mt-6 flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={() => setConfirmOpen(false)}>
                Annuler
              </Button>
              <Button type="submit">Importer</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
