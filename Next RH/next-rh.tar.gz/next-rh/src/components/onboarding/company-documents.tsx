"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { UploadSimple } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { EmptyState, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { uploadCompanyDocumentAction } from "@/server/actions/onboarding";
import { DownloadButton } from "@/components/employees/download-button";
import { fmtDate } from "@/lib/dates";
import { ActionForm } from "./action-form";

export type CompanyDocRow = { id: string; title: string; category: string; createdAt: string; sizeBytes: number };

const catLabels: Record<string, string> = { kbis: "Kbis", entreprise: "Document d'entreprise", justificatif: "Justificatif" };

export function CompanyDocuments({ companyId, docs }: { companyId: string; docs: CompanyDocRow[] }) {
  const router = useRouter();
  const hasKbis = docs.some((d) => d.category === "kbis");
  return (
    <Panel>
      <PanelHeader
        title="Documents utiles"
        description="Un Kbis de moins de 3 mois, et si vous les avez : la dernière notification du taux AT/MP, les contrats de mutuelle et de prévoyance. Ils restent privés (visibles des gestionnaires uniquement)."
        actions={hasKbis ? <Badge tone="ok">Kbis déposé</Badge> : <Badge tone="warn">Kbis manquant</Badge>}
      />
      <ActionForm action={uploadCompanyDocumentAction} hidden={{ companyId }} resetOnSuccess onSuccess={() => router.refresh()} className="border-b border-line px-5 py-4">
        {(_s, pending) => (
          <div className="grid items-end gap-4 sm:grid-cols-[180px_1fr_1fr_auto]">
            <Field label="Type" htmlFor="doc-cat">
              <Select id="doc-cat" name="category" defaultValue={hasKbis ? "entreprise" : "kbis"}>
                <option value="kbis">Extrait Kbis</option>
                <option value="entreprise">Document d&apos;entreprise</option>
                <option value="justificatif">Justificatif</option>
              </Select>
            </Field>
            <Field label="Titre" htmlFor="doc-title" hint="facultatif">
              <Input id="doc-title" name="title" placeholder="Notification taux AT 2026" />
            </Field>
            <Field label="Fichier" htmlFor="doc-file" hint="PDF, PNG, JPEG, 8 Mo max">
              <Input id="doc-file" name="file" type="file" accept="application/pdf,image/png,image/jpeg" required className="py-1.5 file:mr-3 file:rounded-[var(--radius-sm)] file:border-0 file:bg-bg-muted file:px-2 file:py-1 file:text-[12.5px]" />
            </Field>
            <Button type="submit" variant="secondary" loading={pending}>
              {pending ? null : <UploadSimple size={16} />} Déposer
            </Button>
          </div>
        )}
      </ActionForm>
      {docs.length === 0 ? (
        <EmptyState title="Aucun document" description="Le Kbis se télécharge gratuitement pour le dirigeant sur monidenum.fr ou infogreffe.fr." />
      ) : (
        <Table>
          <thead>
            <tr>
              <Th>Document</Th>
              <Th>Type</Th>
              <Th>Déposé le</Th>
              <Th num>Taille</Th>
              <Th className="w-36"><span className="sr-only">Action</span></Th>
            </tr>
          </thead>
          <tbody>
            {docs.map((d) => (
              <tr key={d.id}>
                <Td className="font-medium">{d.title}</Td>
                <Td className="text-ink-2">{catLabels[d.category] ?? d.category}</Td>
                <Td>{fmtDate(d.createdAt)}</Td>
                <Td num>{(d.sizeBytes / 1024).toLocaleString("fr-FR", { maximumFractionDigits: 0 })} Ko</Td>
                <Td className="text-right">
                  <DownloadButton companyId={companyId} documentId={d.id} />
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Panel>
  );
}
