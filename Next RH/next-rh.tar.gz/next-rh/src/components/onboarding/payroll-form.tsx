"use client";

import * as React from "react";
import { Checkbox, Field, Input } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { Panel, PanelHeader } from "@/components/ui/surface";
import { cn } from "@/lib/utils";
import { autosavePayrollSettingsAction, type SettingsPatch } from "@/server/actions/onboarding";
import { headcountBracketLabels, workTimeLabels, type HeadcountBracket, type PayrollSettings } from "@/server/onboarding/payroll-settings";
import { roleLabels } from "@/components/employees/labels";
import { SaveIndicator, useAutosave } from "./action-form";

type Member = { userId: string; firstName: string; lastName: string; email: string; role: string };
type Establishment = { id: string; name: string; siret: string | null };

const centsToInput = (c: number | undefined) => (c === undefined ? "" : (c / 100).toFixed(2).replace(".", ","));
const rateToInput = (r: string | undefined) => (r === undefined ? "" : r.replace(".", ","));

function Confirm({ id, checked, onChange, disabled, error }: { id: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean; error?: string }) {
  return (
    <div className="mt-2">
      <Checkbox id={id} checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} label={<span className="text-[13px]">Je confirme cette information</span>} />
      {error ? <p className="mt-1 text-[12.5px] text-danger-ink">{error}</p> : null}
    </div>
  );
}

function Choice({ name, value, current, onSelect, children }: { name: string; value: string; current: string | undefined; onSelect: (v: string) => void; children: React.ReactNode }) {
  const active = current === value;
  return (
    <label className={cn("flex cursor-pointer items-start gap-2.5 rounded-[var(--radius-sm)] border px-3 py-2.5 text-[13.5px] transition-colors", active ? "border-accent bg-accent-soft" : "border-line-strong hover:bg-bg-sunken")}>
      <input type="radio" name={name} value={value} checked={active} onChange={() => onSelect(value)} className="mt-0.5 accent-[var(--accent)]" />
      <span>{children}</span>
    </label>
  );
}

/** Organisation de la paie : écrit companies.payroll_settings, champ par champ, avec confirmations explicites. */
export function PayrollSettingsForm({
  companyId,
  settings,
  members,
  establishments,
  headcount,
}: {
  companyId: string;
  settings: Partial<PayrollSettings> & { confirmed: Record<string, boolean>; preparers: string[]; validators: string[] };
  members: Member[];
  establishments: Establishment[];
  headcount: number | null;
}) {
  const save = React.useCallback((p: SettingsPatch) => autosavePayrollSettingsAction(companyId, p), [companyId]);
  const { status, errors, savedAt, globalError, queue } = useAutosave<SettingsPatch>(save, 700);
  const [confirmed, setConfirmed] = React.useState<Record<string, boolean>>(settings.confirmed);
  const [bracket, setBracket] = React.useState<string | undefined>(settings.headcountBracket);
  const [workTime, setWorkTime] = React.useState<string | undefined>(settings.workTime);
  const [mut, setMut] = React.useState({
    enabled: settings.mutuelle === undefined ? undefined : settings.mutuelle !== null,
    name: settings.mutuelle?.name ?? "",
    employer: centsToInput(settings.mutuelle?.employerCents),
    employee: centsToInput(settings.mutuelle?.employeeCents),
  });
  const [prev, setPrev] = React.useState({
    enabled: settings.prevoyance === undefined ? undefined : settings.prevoyance !== null,
    name: settings.prevoyance?.name ?? "",
    cadreEmployerRate: rateToInput(settings.prevoyance?.cadreEmployerRate),
    cadreEmployeeRate: rateToInput(settings.prevoyance?.cadreEmployeeRate),
    nonCadreEmployerRate: rateToInput(settings.prevoyance?.nonCadreEmployerRate),
    nonCadreEmployeeRate: rateToInput(settings.prevoyance?.nonCadreEmployeeRate),
  });
  const [preparers, setPreparers] = React.useState<string[]>(settings.preparers);
  const [validators, setValidators] = React.useState<string[]>(settings.validators);
  const [estIds, setEstIds] = React.useState<string[]>(settings.establishmentIds ?? establishments.map((e) => e.id));

  const unconfirm = (k: string) => setConfirmed((c) => ({ ...c, [k]: false }));
  const confirm = (k: string) => (v: boolean) => {
    setConfirmed((c) => ({ ...c, [k]: v }));
    queue({ confirmed: { [k]: v } } as SettingsPatch, true);
  };
  const suggested = headcount !== null ? (headcount < 11 ? "lt11" : headcount < 50 ? "11to49" : headcount < 250 ? "50to249" : "gte250") : null;
  const toggle = (list: string[], id: string, on: boolean) => (on ? [...new Set([...list, id])] : list.filter((x) => x !== id));

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <SaveIndicator status={status} savedAt={savedAt} error={globalError} />
      </div>

      <Panel>
        <PanelHeader title="Calendrier de paie" description="La période de paie est le mois civil : du 1er au dernier jour du mois." />
        <div className="grid gap-x-5 gap-y-5 p-5 sm:grid-cols-2">
          <Field label="Premier mois calculé dans Next RH" htmlFor="firstPeriod" error={errors.firstPeriod} help="Si ce n'est pas janvier, il faudra importer les cumuls de l'année (reprise en cours d'année).">
            <Input id="firstPeriod" type="month" defaultValue={settings.firstPeriod ?? ""} onChange={(e) => queue({ firstPeriod: e.target.value })} className="num" />
          </Field>
          <div>
            <Field label="Jour habituel de paiement des salaires" htmlFor="paymentDay" error={errors.paymentDay} help="Par exemple 28 pour un virement le 28 du mois. Si ce jour tombe un week-end, le virement est avancé.">
              <Input
                id="paymentDay"
                type="number"
                min={1}
                max={31}
                defaultValue={settings.paymentDay ?? ""}
                className="num w-28"
                onChange={(e) => {
                  unconfirm("paymentDay");
                  queue({ paymentDay: e.target.value });
                }}
              />
            </Field>
            <Confirm id="c-paymentDay" checked={Boolean(confirmed.paymentDay)} onChange={confirm("paymentDay")} error={errors["confirm.paymentDay"]} />
          </div>
          <Field label="Logiciel ou prestataire précédent" htmlFor="previousProvider" hint="facultatif" help="Utile pour interpréter les fichiers de reprise (Silae, Sage, cabinet comptable…).">
            <Input id="previousProvider" defaultValue={settings.previousProvider ?? ""} onChange={(e) => queue({ previousProvider: e.target.value })} />
          </Field>
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Effectif" description="L'effectif moyen de l'année précédente détermine plusieurs cotisations : FNAL, versement mobilité, contribution formation, participation." />
        <div className="p-5">
          <div className="grid gap-2 sm:grid-cols-2">
            {(Object.keys(headcountBracketLabels) as HeadcountBracket[]).map((k) => (
              <Choice
                key={k}
                name="headcountBracket"
                value={k}
                current={bracket}
                onSelect={(v) => {
                  setBracket(v);
                  unconfirm("headcountBracket");
                  queue({ headcountBracket: v }, true);
                }}
              >
                {headcountBracketLabels[k]}
                {suggested === k ? <span className="ml-2 text-[12px] text-ink-3">(d&apos;après l&apos;effectif saisi)</span> : null}
              </Choice>
            ))}
          </div>
          <p className="mt-2 text-[12.5px] text-ink-3">En cas de doute, prenez l&apos;effectif moyen annuel calculé par votre ancien logiciel ou indiqué par l&apos;URSSAF sur votre compte en ligne.</p>
          <Confirm id="c-bracket" checked={Boolean(confirmed.headcountBracket)} onChange={confirm("headcountBracket")} disabled={!bracket} error={errors["confirm.headcountBracket"]} />
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Taux spécifiques à l'entreprise" description="Deux taux qui varient d'une entreprise à l'autre et ne peuvent pas être devinés." />
        <div className="grid gap-x-5 gap-y-5 p-5 sm:grid-cols-2">
          <div>
            <Field
              label="Taux accident du travail (AT/MP), en %"
              htmlFor="atRate"
              required
              error={errors.atRate}
              help="Notifié chaque année par la CARSAT. Consultable sur net-entreprises.fr, service « Compte AT/MP ». Il figure aussi sur vos anciens bulletins (ligne Accidents du travail)."
            >
              <Input
                id="atRate"
                inputMode="decimal"
                defaultValue={rateToInput(settings.atRate)}
                placeholder="1,30"
                className="num w-32"
                aria-invalid={Boolean(errors.atRate)}
                onChange={(e) => {
                  unconfirm("atRate");
                  queue({ atRate: e.target.value });
                }}
              />
            </Field>
            <Confirm id="c-at" checked={Boolean(confirmed.atRate)} onChange={confirm("atRate")} error={errors["confirm.atRate"]} />
          </div>
          <div>
            <Field
              label="Versement mobilité, en %"
              htmlFor="mobilityRate"
              error={errors.mobilityRate}
              help="Dû à partir de 11 salariés, selon la commune de l'établissement. Le taux est donné par le simulateur de l'URSSAF. Indiquez 0 si l'entreprise n'est pas assujettie."
            >
              <Input
                id="mobilityRate"
                inputMode="decimal"
                defaultValue={rateToInput(settings.mobilityRate)}
                placeholder={bracket === "lt11" ? "0" : "2,95"}
                className="num w-32"
                aria-invalid={Boolean(errors.mobilityRate)}
                onChange={(e) => {
                  unconfirm("mobilityRate");
                  queue({ mobilityRate: e.target.value });
                }}
              />
            </Field>
            <Confirm id="c-mob" checked={Boolean(confirmed.mobilityRate)} onChange={confirm("mobilityRate")} error={errors["confirm.mobilityRate"]} />
          </div>
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Mutuelle (complémentaire santé)" description="Obligatoire dans le privé ; l'employeur finance au moins la moitié de la cotisation." />
        <div className="p-5">
          <div className="grid gap-2 sm:grid-cols-2">
            <Choice
              name="mut"
              value="yes"
              current={mut.enabled === undefined ? undefined : mut.enabled ? "yes" : "no"}
              onSelect={() => {
                const next = { ...mut, enabled: true };
                setMut(next);
                unconfirm("mutuelle");
                queue({ mutuelle: { ...next, enabled: true } }, true);
              }}
            >
              L&apos;entreprise a un contrat de mutuelle
            </Choice>
            <Choice
              name="mut"
              value="no"
              current={mut.enabled === undefined ? undefined : mut.enabled ? "yes" : "no"}
              onSelect={() => {
                setMut({ ...mut, enabled: false });
                unconfirm("mutuelle");
                queue({ mutuelle: { enabled: false } }, true);
              }}
            >
              Pas encore de contrat
            </Choice>
          </div>
          {mut.enabled ? (
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              {(
                [
                  ["name", "Organisme", "Harmonie Mutuelle", "Le nom de l'assureur figurant sur le contrat."],
                  ["employer", "Part employeur, € par mois", "38,60", "Montant mensuel par salarié, pour la formule de base."],
                  ["employee", "Part salarié, € par mois", "25,74", "Retenue mensuelle sur le bulletin."],
                ] as const
              ).map(([k, label, ph, help]) => (
                <Field key={k} label={label} htmlFor={`mut-${k}`} help={help} error={k === "employer" ? errors.mutuelleEmployer : k === "employee" ? errors.mutuelleEmployee : undefined}>
                  <Input
                    id={`mut-${k}`}
                    defaultValue={mut[k]}
                    placeholder={ph}
                    inputMode={k === "name" ? undefined : "decimal"}
                    className={k === "name" ? "" : "num"}
                    onChange={(e) => {
                      const next = { ...mut, [k]: e.target.value };
                      setMut(next);
                      unconfirm("mutuelle");
                      queue({ mutuelle: { ...next, enabled: true } });
                    }}
                  />
                </Field>
              ))}
            </div>
          ) : null}
          <Confirm id="c-mut" checked={Boolean(confirmed.mutuelle)} onChange={confirm("mutuelle")} disabled={mut.enabled === undefined} error={errors["confirm.mutuelle"]} />
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Prévoyance" description="Couvre l'incapacité, l'invalidité et le décès. Obligatoire pour les cadres (au moins 1,50 % de la tranche A à la charge de l'employeur) et souvent imposée par la convention collective." />
        <div className="p-5">
          <div className="grid gap-2 sm:grid-cols-2">
            <Choice
              name="prev"
              value="yes"
              current={prev.enabled === undefined ? undefined : prev.enabled ? "yes" : "no"}
              onSelect={() => {
                const next = { ...prev, enabled: true };
                setPrev(next);
                unconfirm("prevoyance");
                queue({ prevoyance: { ...next, enabled: true } }, true);
              }}
            >
              L&apos;entreprise a un contrat de prévoyance
            </Choice>
            <Choice
              name="prev"
              value="no"
              current={prev.enabled === undefined ? undefined : prev.enabled ? "yes" : "no"}
              onSelect={() => {
                setPrev({ ...prev, enabled: false });
                unconfirm("prevoyance");
                queue({ prevoyance: { enabled: false } }, true);
              }}
            >
              Pas de contrat de prévoyance
            </Choice>
          </div>
          {prev.enabled ? (
            <div className="mt-4 space-y-4">
              <Field label="Organisme" htmlFor="prev-name">
                <Input
                  id="prev-name"
                  defaultValue={prev.name}
                  onChange={(e) => {
                    const next = { ...prev, name: e.target.value };
                    setPrev(next);
                    unconfirm("prevoyance");
                    queue({ prevoyance: { ...next, enabled: true } });
                  }}
                />
              </Field>
              <div className="grid gap-4 sm:grid-cols-4">
                {(
                  [
                    ["cadreEmployerRate", "Cadres : part employeur %", "1,50"],
                    ["cadreEmployeeRate", "Cadres : part salarié %", "0,30"],
                    ["nonCadreEmployerRate", "Non-cadres : part employeur %", "0,40"],
                    ["nonCadreEmployeeRate", "Non-cadres : part salarié %", "0,20"],
                  ] as const
                ).map(([k, label, ph]) => (
                  <Field key={k} label={label} htmlFor={`prev-${k}`} error={errors[`prevoyance.${k}`]}>
                    <Input
                      id={`prev-${k}`}
                      defaultValue={prev[k]}
                      placeholder={ph}
                      inputMode="decimal"
                      className="num"
                      onChange={(e) => {
                        const next = { ...prev, [k]: e.target.value };
                        setPrev(next);
                        unconfirm("prevoyance");
                        queue({ prevoyance: { ...next, enabled: true } });
                      }}
                    />
                  </Field>
                ))}
              </div>
              <p className="text-[12.5px] text-ink-3">Taux en pourcentage du salaire brut (tranche A), tels qu&apos;indiqués au contrat.</p>
            </div>
          ) : null}
          <Confirm id="c-prev" checked={Boolean(confirmed.prevoyance)} onChange={confirm("prevoyance")} disabled={prev.enabled === undefined} error={errors["confirm.prevoyance"]} />
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Organisation du temps de travail" description="La règle la plus fréquente dans l'entreprise. Chaque contrat précise ensuite sa propre durée." />
        <div className="p-5">
          <div className="grid gap-2">
            {Object.entries(workTimeLabels).map(([k, v]) => (
              <Choice
                key={k}
                name="workTime"
                value={k}
                current={workTime}
                onSelect={(val) => {
                  setWorkTime(val);
                  unconfirm("workTime");
                  queue({ workTime: val }, true);
                }}
              >
                {v}
              </Choice>
            ))}
          </div>
          <Confirm id="c-wt" checked={Boolean(confirmed.workTime)} onChange={confirm("workTime")} disabled={!workTime} error={errors["confirm.workTime"]} />
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Établissements concernés" description="Les établissements dont Next RH produit la paie." />
        <div className="space-y-2 p-5">
          {establishments.length === 0 ? <p className="text-[13.5px] text-ink-2">Aucun établissement : ajoutez-les à l&apos;étape Établissements.</p> : null}
          {establishments.map((e) => (
            <Checkbox
              key={e.id}
              className="flex"
              checked={estIds.includes(e.id)}
              onChange={(ev) => {
                const next = toggle(estIds, e.id, ev.target.checked);
                setEstIds(next);
                queue({ establishmentIds: next }, true);
              }}
              label={
                <>
                  {e.name} <span className="num text-ink-3">{e.siret ?? "SIRET manquant"}</span>
                </>
              }
            />
          ))}
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Qui prépare et qui valide la paie" description="Parmi les personnes ayant accès à l'entreprise. Le valideur relit et approuve les bulletins avant leur diffusion ; il peut être la même personne que le préparateur dans une petite structure." />
        <div className="grid gap-6 p-5 sm:grid-cols-2">
          {(
            [
              ["preparers", "Préparent la paie", preparers, setPreparers],
              ["validators", "Valident la paie", validators, setValidators],
            ] as const
          ).map(([key, title, list, setList]) => (
            <fieldset key={key}>
              <legend className="mb-2 text-[13px] font-medium text-ink">
                {title} {key === "validators" ? <span className="text-danger">*</span> : null}
              </legend>
              <div className="space-y-2">
                {members.map((m) => (
                  <Checkbox
                    key={m.userId}
                    className="flex"
                    checked={list.includes(m.userId)}
                    onChange={(ev) => {
                      const next = toggle(list, m.userId, ev.target.checked);
                      setList(next);
                      queue({ [key]: next } as SettingsPatch, true);
                    }}
                    label={
                      <>
                        {m.firstName} {m.lastName} <Badge>{roleLabels[m.role] ?? m.role}</Badge>
                      </>
                    }
                  />
                ))}
              </div>
            </fieldset>
          ))}
        </div>
        <p className="border-t border-line px-5 py-3 text-[12.5px] text-ink-2">Pour ajouter une personne, invitez-la depuis Paramètres, rubrique Membres et rôles.</p>
      </Panel>
    </div>
  );
}
