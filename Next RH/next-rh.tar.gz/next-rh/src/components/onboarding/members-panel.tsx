"use client";

import * as React from "react";
import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { UserPlus } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { EmptyState, Notice, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import type { ActionState } from "@/server/actions/auth";
import { createInvitationAction, removeMemberAction, resendInvitationAction, revokeInvitationAction, updateMemberRoleAction } from "@/server/actions/settings";
import { roleDescriptions, roleLabels } from "@/components/employees/labels";
import { fmtDate } from "@/lib/dates";
import { ActionForm, FormMessage } from "./action-form";
import { FormDialog } from "./editors";

export type MemberRow = { membershipId: string; userId: string; name: string; email: string; role: string; totp: boolean; lastLoginAt: string | null };
export type InvitationRow = { id: string; email: string; role: string; status: string; expiresAt: string; createdAt: string; invitedBy: string | null };

const ASSIGNABLE = ["owner", "admin", "hr", "payroll", "accountant", "manager", "viewer"];

function RoleSelect({ companyId, m, disabled }: { companyId: string; m: MemberRow; disabled: boolean }) {
  const [state, action, pending] = useActionState(updateMemberRoleAction, {} as ActionState);
  const formRef = React.useRef<HTMLFormElement>(null);
  const router = useRouter();
  React.useEffect(() => {
    if (state.ok) router.refresh();
  }, [state, router]);
  return (
    <form ref={formRef} action={action}>
      <input type="hidden" name="companyId" value={companyId} />
      <input type="hidden" name="membershipId" value={m.membershipId} />
      <Select name="role" defaultValue={m.role} disabled={disabled || pending} onChange={() => formRef.current?.requestSubmit()} aria-label={`Rôle de ${m.name}`} className="h-8 w-auto text-[13px]">
        {ASSIGNABLE.map((r) => (
          <option key={r} value={r}>
            {roleLabels[r]}
          </option>
        ))}
      </Select>
      {state.error ? <p className="mt-1 text-[12px] text-danger-ink">{state.error}</p> : null}
    </form>
  );
}

function InvitationActions({ companyId, inv }: { companyId: string; inv: InvitationRow }) {
  const [rState, resend, resending] = useActionState(resendInvitationAction, {} as ActionState);
  const router = useRouter();
  React.useEffect(() => {
    if (rState.ok) router.refresh();
  }, [rState, router]);
  if (inv.status === "accepted") return null;
  return (
    <div className="flex flex-col items-end gap-1">
      <div className="flex justify-end gap-1">
        <form action={resend}>
          <input type="hidden" name="companyId" value={companyId} />
          <input type="hidden" name="id" value={inv.id} />
          <Button type="submit" size="sm" variant="ghost" loading={resending}>
            Renvoyer
          </Button>
        </form>
        {inv.status === "pending" ? (
          <FormDialog
            trigger={<Button size="sm" variant="ghost">Révoquer</Button>}
            title="Révoquer cette invitation ?"
            description={`Le lien envoyé à ${inv.email} ne fonctionnera plus.`}
            action={revokeInvitationAction}
            hidden={{ companyId, id: inv.id }}
            submitLabel="Révoquer"
            danger
          />
        ) : null}
      </div>
      <FormMessage state={rState} className="mt-1 max-w-md text-left" />
    </div>
  );
}

export function MembersPanel({ companyId, currentUserId, members, invitations, canManage, mailConfigured, isDemo }: { companyId: string; currentUserId: string; members: MemberRow[]; invitations: InvitationRow[]; canManage: boolean; mailConfigured: boolean; isDemo: boolean }) {
  const router = useRouter();
  const [role, setRole] = React.useState("payroll");
  return (
    <div className="space-y-6">
      <Panel>
        <PanelHeader title="Membres et rôles" description="Les personnes ayant accès à cette entreprise. Le rôle fixe ce que chacun peut voir et faire." />
        <Table>
          <thead>
            <tr>
              <Th>Personne</Th>
              <Th>Rôle</Th>
              <Th>Double vérification</Th>
              <Th>Dernière connexion</Th>
              <Th className="w-24"><span className="sr-only">Actions</span></Th>
            </tr>
          </thead>
          <tbody>
            {members.map((m) => (
              <tr key={m.membershipId}>
                <Td>
                  <span className="font-medium">{m.name}</span> {m.userId === currentUserId ? <Badge>Vous</Badge> : null}
                  <span className="block text-[12px] text-ink-3">{m.email}</span>
                </Td>
                <Td>{canManage ? <RoleSelect companyId={companyId} m={m} disabled={false} /> : roleLabels[m.role] ?? m.role}</Td>
                <Td>{m.totp ? <Badge tone="ok">Activée</Badge> : <Badge tone="warn">Non activée</Badge>}</Td>
                <Td className="num">{m.lastLoginAt ? fmtDate(m.lastLoginAt) : "Jamais"}</Td>
                <Td className="text-right">
                  {canManage && m.userId !== currentUserId ? (
                    <FormDialog
                      trigger={<Button size="sm" variant="ghost">Retirer</Button>}
                      title={`Retirer l'accès de ${m.name} ?`}
                      description="La personne ne pourra plus ouvrir ce dossier. Son compte n'est pas supprimé."
                      action={removeMemberAction}
                      hidden={{ companyId, membershipId: m.membershipId }}
                      submitLabel="Retirer l'accès"
                      danger
                    />
                  ) : null}
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Panel>

      {canManage ? (
        <Panel>
          <PanelHeader title="Inviter une personne" description="Collègue, gestionnaire de paie, expert-comptable. Les salariés s'invitent depuis la liste des salariés." />
          {!mailConfigured || isDemo ? (
            <Notice tone="warn" className="mx-5 mt-4">
              {isDemo ? "Mode démonstration : aucun e-mail ne part." : "Le service e-mail n'est pas configuré (RESEND_API_KEY)."} Le lien d&apos;invitation s&apos;affichera après création : copiez-le et transmettez-le vous-même.
            </Notice>
          ) : null}
          <ActionForm action={createInvitationAction} hidden={{ companyId }} resetOnSuccess onSuccess={() => router.refresh()} className="p-5">
            {(_s, pending) => (
              <div className="grid items-end gap-4 sm:grid-cols-[1fr_220px_auto]">
                <Field label="Adresse e-mail" htmlFor="inv-email" required>
                  <Input id="inv-email" name="email" type="email" required />
                </Field>
                <Field label="Rôle" htmlFor="inv-role">
                  <Select id="inv-role" name="role" value={role} onChange={(e) => setRole(e.target.value)}>
                    {ASSIGNABLE.map((r) => (
                      <option key={r} value={r}>
                        {roleLabels[r]}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Button type="submit" loading={pending}>
                  {pending ? null : <UserPlus size={16} />} Inviter
                </Button>
                <p className="text-[12.5px] text-ink-2 sm:col-span-3">{roleDescriptions[role]}</p>
              </div>
            )}
          </ActionForm>
        </Panel>
      ) : null}

      <Panel>
        <PanelHeader title="Invitations" description="Un lien d'invitation est valable 7 jours." />
        {invitations.length === 0 ? (
          <EmptyState title="Aucune invitation" />
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Adresse</Th>
                <Th>Rôle</Th>
                <Th>État</Th>
                <Th>Envoyée le</Th>
                <Th>Expire le</Th>
                <Th className="w-48"><span className="sr-only">Actions</span></Th>
              </tr>
            </thead>
            <tbody>
              {invitations.map((i) => {
                const expired = i.status === "pending" && new Date(i.expiresAt) < new Date();
                return (
                  <tr key={i.id}>
                    <Td>
                      {i.email}
                      {i.invitedBy ? <span className="block text-[12px] text-ink-3">par {i.invitedBy}</span> : null}
                    </Td>
                    <Td>{roleLabels[i.role] ?? i.role}</Td>
                    <Td>{expired ? <StatusBadge status="expired" /> : i.status === "revoked" ? <Badge tone="neutral">Révoquée</Badge> : i.status === "accepted" ? <Badge tone="ok">Acceptée</Badge> : <StatusBadge status="pending" />}</Td>
                    <Td className="num">{fmtDate(i.createdAt)}</Td>
                    <Td className="num">{fmtDate(i.expiresAt)}</Td>
                    <Td className="text-right">{canManage ? <InvitationActions companyId={companyId} inv={i} /> : null}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        )}
      </Panel>
    </div>
  );
}
