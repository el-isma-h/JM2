"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PencilSimple, Plus, Trash } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { EmptyState, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import type { ActionState } from "@/server/actions/auth";
import {
  deleteContactAction,
  deleteEstablishmentAction,
  deleteOrganismAction,
  saveContactAction,
  saveEstablishmentAction,
  saveOrganismAction,
} from "@/server/actions/settings";
import { contactRoleLabels, organismKindLabels } from "@/components/employees/labels";
import { ActionForm } from "./action-form";

type Action = (prev: ActionState, fd: FormData) => Promise<ActionState>;

/** Fenêtre de saisie liée à une server action ; se ferme et rafraîchit après succès. */
export function FormDialog({
  trigger,
  title,
  description,
  action,
  hidden,
  submitLabel,
  danger,
  children,
}: {
  trigger: React.ReactNode;
  title: string;
  description?: string;
  action: Action;
  hidden: Record<string, string>;
  submitLabel: string;
  danger?: boolean;
  children?: React.ReactNode;
}) {
  const [open, setOpen] = React.useState(false);
  const router = useRouter();
  const onSuccess = React.useCallback(() => {
    setOpen(false);
    router.refresh();
  }, [router]);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent title={title} description={description} className="max-h-[90dvh] max-w-xl overflow-y-auto">
        <ActionForm action={action} hidden={hidden} onSuccess={onSuccess}>
          {(_s, pending) => (
            <>
              <div className="space-y-4">{children}</div>
              <div className="mt-6 flex justify-end gap-2">
                <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit" variant={danger ? "danger" : "primary"} loading={pending}>
                  {submitLabel}
                </Button>
              </div>
            </>
          )}
        </ActionForm>
      </DialogContent>
    </Dialog>
  );
}

// ---------- Établissements ----------

export type EstablishmentRow = { id: string; name: string; siret: string | null; isHeadOffice: boolean; addressLine1: string | null; postalCode: string | null; city: string | null; urssafCode: string | null };

function EstablishmentFields({ e, siren }: { e?: EstablishmentRow; siren: string | null }) {
  return (
    <>
      <Field label="Nom de l'établissement" htmlFor="est-name" required help="Un nom interne : « Siège », « Agence de Bordeaux »…">
        <Input id="est-name" name="name" defaultValue={e?.name ?? ""} required />
      </Field>
      <Field
        label="SIRET"
        htmlFor="est-siret"
        help={siren ? `14 chiffres : le SIREN (${siren}) suivi du NIC à 5 chiffres. Il figure sur l'avis de situation INSEE de l'établissement.` : "Renseignez d'abord le SIREN de l'entreprise."}
      >
        <Input id="est-siret" name="siret" defaultValue={e?.siret ?? siren ?? ""} inputMode="numeric" className="num" placeholder={siren ? `${siren}00012` : ""} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-6">
        <Field label="Adresse" htmlFor="est-addr" className="sm:col-span-6">
          <Input id="est-addr" name="addressLine1" defaultValue={e?.addressLine1 ?? ""} />
        </Field>
        <Field label="Code postal" htmlFor="est-cp" className="sm:col-span-2">
          <Input id="est-cp" name="postalCode" defaultValue={e?.postalCode ?? ""} inputMode="numeric" className="num" />
        </Field>
        <Field label="Ville" htmlFor="est-city" className="sm:col-span-4">
          <Input id="est-city" name="city" defaultValue={e?.city ?? ""} />
        </Field>
      </div>
      <Field label="Code URSSAF" htmlFor="est-urssaf" hint="facultatif" help="Le code de l'organisme URSSAF dont dépend l'établissement (sur vos bordereaux).">
        <Input id="est-urssaf" name="urssafCode" defaultValue={e?.urssafCode ?? ""} />
      </Field>
      <Checkbox name="isHeadOffice" defaultChecked={e?.isHeadOffice ?? false} label="C'est le siège social" />
    </>
  );
}

export function EstablishmentsEditor({ companyId, siren, rows, readOnly }: { companyId: string; siren: string | null; rows: EstablishmentRow[]; readOnly?: boolean }) {
  return (
    <Panel>
      <PanelHeader
        title="Établissements"
        description="Un établissement par lieu de travail immatriculé. Les salariés y sont rattachés."
        actions={
          readOnly ? null : (
            <FormDialog
              trigger={
                <Button size="sm">
                  <Plus size={15} /> Ajouter un établissement
                </Button>
              }
              title="Nouvel établissement"
              action={saveEstablishmentAction}
              hidden={{ companyId }}
              submitLabel="Ajouter"
            >
              <EstablishmentFields siren={siren} />
            </FormDialog>
          )
        }
      />
      {rows.length === 0 ? (
        <EmptyState title="Aucun établissement" description="Ajoutez au moins le siège : sans établissement, aucune paie ne peut être déclarée." />
      ) : (
        <Table>
          <thead>
            <tr>
              <Th>Établissement</Th>
              <Th>SIRET</Th>
              <Th>Adresse</Th>
              <Th className="w-24"><span className="sr-only">Actions</span></Th>
            </tr>
          </thead>
          <tbody>
            {rows.map((e) => (
              <tr key={e.id}>
                <Td>
                  <span className="font-medium">{e.name}</span> {e.isHeadOffice ? <Badge tone="info">Siège</Badge> : null}
                </Td>
                <Td className="num">{e.siret ?? <Badge tone="danger">SIRET manquant</Badge>}</Td>
                <Td className="text-ink-2">{[e.addressLine1, [e.postalCode, e.city].filter(Boolean).join(" ")].filter(Boolean).join(", ") || "-"}</Td>
                <Td className="text-right">
                  {readOnly ? null : (
                    <div className="flex justify-end gap-1">
                      <FormDialog
                        trigger={
                          <Button size="icon" variant="ghost" aria-label={`Modifier ${e.name}`}>
                            <PencilSimple size={16} />
                          </Button>
                        }
                        title={`Modifier : ${e.name}`}
                        action={saveEstablishmentAction}
                        hidden={{ companyId, id: e.id }}
                        submitLabel="Enregistrer"
                      >
                        <EstablishmentFields e={e} siren={siren} />
                      </FormDialog>
                      <FormDialog
                        trigger={
                          <Button size="icon" variant="ghost" aria-label={`Supprimer ${e.name}`}>
                            <Trash size={16} />
                          </Button>
                        }
                        title="Supprimer cet établissement ?"
                        description={`« ${e.name} » sera supprimé. Impossible si des salariés y sont encore rattachés.`}
                        action={deleteEstablishmentAction}
                        hidden={{ companyId, id: e.id }}
                        submitLabel="Supprimer"
                        danger
                      />
                    </div>
                  )}
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Panel>
  );
}

// ---------- Organismes ----------

export type OrganismRow = { id: string; kind: string; name: string; reference: string | null; contractNumber: string | null; notes: string | null };

const organismHelp: Record<string, string> = {
  urssaf: "Votre URSSAF de rattachement et le numéro de compte cotisant (sur vos bordereaux ou net-entreprises.fr).",
  retraite: "La caisse de retraite complémentaire Agirc-Arrco (Malakoff Humanis, AG2R, Klesia…) et votre numéro d'adhérent.",
  mutuelle: "L'organisme qui assure la complémentaire santé collective et le numéro de contrat.",
  prevoyance: "L'organisme du contrat de prévoyance (incapacité, invalidité, décès) et le numéro de contrat.",
  medecine_travail: "Le service de prévention et de santé au travail auquel l'entreprise adhère.",
  formation: "L'opérateur de compétences (OPCO) de votre branche.",
  autre: "Tout autre organisme à qui des cotisations sont versées.",
};

function OrganismFields({ o, defaultKind }: { o?: OrganismRow; defaultKind?: string }) {
  const [kind, setKind] = React.useState(o?.kind ?? defaultKind ?? "urssaf");
  return (
    <>
      <Field label="Type d'organisme" htmlFor="org-kind" help={organismHelp[kind]}>
        <Select id="org-kind" name="kind" value={kind} onChange={(e) => setKind(e.target.value)}>
          {Object.entries(organismKindLabels).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Nom" htmlFor="org-name" required>
        <Input id="org-name" name="name" defaultValue={o?.name ?? ""} required placeholder={kind === "urssaf" ? "URSSAF Pays de la Loire" : ""} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Référence ou n° d'adhérent" htmlFor="org-ref" hint="facultatif">
          <Input id="org-ref" name="reference" defaultValue={o?.reference ?? ""} className="num" />
        </Field>
        <Field label="N° de contrat" htmlFor="org-contract" hint="facultatif">
          <Input id="org-contract" name="contractNumber" defaultValue={o?.contractNumber ?? ""} className="num" />
        </Field>
      </div>
      <Field label="Notes" htmlFor="org-notes" hint="facultatif">
        <Textarea id="org-notes" name="notes" defaultValue={o?.notes ?? ""} className="min-h-16" />
      </Field>
    </>
  );
}

export function OrganismsEditor({ companyId, rows, readOnly }: { companyId: string; rows: OrganismRow[]; readOnly?: boolean }) {
  const kinds = new Set(rows.map((r) => r.kind));
  const missing = (["urssaf", "retraite", "mutuelle", "prevoyance", "medecine_travail"] as const).filter((k) => !kinds.has(k));
  return (
    <Panel>
      <PanelHeader
        title="Organismes sociaux"
        description="Les cotisations calculées sur les bulletins sont versées et déclarées à ces organismes."
        actions={
          readOnly ? null : (
            <FormDialog
              trigger={
                <Button size="sm">
                  <Plus size={15} /> Ajouter un organisme
                </Button>
              }
              title="Nouvel organisme"
              action={saveOrganismAction}
              hidden={{ companyId }}
              submitLabel="Ajouter"
            >
              <OrganismFields defaultKind={missing[0]} />
            </FormDialog>
          )
        }
      />
      {missing.length && !readOnly ? (
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-5 py-3 text-[13px] text-ink-2">
          <span>À renseigner :</span>
          {missing.map((k) => (
            <FormDialog key={k} trigger={<Button size="sm" variant="secondary">{organismKindLabels[k]}</Button>} title={`Ajouter : ${organismKindLabels[k]}`} action={saveOrganismAction} hidden={{ companyId }} submitLabel="Ajouter">
              <OrganismFields defaultKind={k} />
            </FormDialog>
          ))}
        </div>
      ) : null}
      {rows.length === 0 ? (
        <EmptyState title="Aucun organisme" description="Commencez par l'URSSAF et la caisse de retraite complémentaire : ce sont les deux principaux destinataires des cotisations." />
      ) : (
        <Table>
          <thead>
            <tr>
              <Th>Type</Th>
              <Th>Organisme</Th>
              <Th>Référence</Th>
              <Th>Contrat</Th>
              <Th className="w-24"><span className="sr-only">Actions</span></Th>
            </tr>
          </thead>
          <tbody>
            {rows.map((o) => (
              <tr key={o.id}>
                <Td className="text-ink-2">{organismKindLabels[o.kind] ?? o.kind}</Td>
                <Td className="font-medium">{o.name}</Td>
                <Td className="num">{o.reference ?? "-"}</Td>
                <Td className="num">{o.contractNumber ?? "-"}</Td>
                <Td className="text-right">
                  {readOnly ? null : (
                    <div className="flex justify-end gap-1">
                      <FormDialog trigger={<Button size="icon" variant="ghost" aria-label={`Modifier ${o.name}`}><PencilSimple size={16} /></Button>} title={`Modifier : ${o.name}`} action={saveOrganismAction} hidden={{ companyId, id: o.id }} submitLabel="Enregistrer">
                        <OrganismFields o={o} />
                      </FormDialog>
                      <FormDialog trigger={<Button size="icon" variant="ghost" aria-label={`Retirer ${o.name}`}><Trash size={16} /></Button>} title="Retirer cet organisme ?" description={`« ${o.name} » ne sera plus proposé dans les déclarations.`} action={deleteOrganismAction} hidden={{ companyId, id: o.id }} submitLabel="Retirer" danger />
                    </div>
                  )}
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Panel>
  );
}

// ---------- Interlocuteurs ----------

export type ContactRow = { id: string; fullName: string; role: string; email: string | null; phone: string | null };

function ContactFields({ c }: { c?: ContactRow }) {
  return (
    <>
      <Field label="Nom complet" htmlFor="ct-name" required>
        <Input id="ct-name" name="fullName" defaultValue={c?.fullName ?? ""} required />
      </Field>
      <Field label="Rôle" htmlFor="ct-role">
        <Select id="ct-role" name="role" defaultValue={c?.role ?? "paie"}>
          {Object.entries(contactRoleLabels).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="E-mail" htmlFor="ct-email">
          <Input id="ct-email" name="email" type="email" defaultValue={c?.email ?? ""} />
        </Field>
        <Field label="Téléphone" htmlFor="ct-phone">
          <Input id="ct-phone" name="phone" defaultValue={c?.phone ?? ""} className="num" />
        </Field>
      </div>
    </>
  );
}

export function ContactsEditor({ companyId, rows, readOnly }: { companyId: string; rows: ContactRow[]; readOnly?: boolean }) {
  return (
    <Panel>
      <PanelHeader
        title="Interlocuteurs"
        description="Les personnes à joindre pour une question de paie, de comptabilité ou d'accès. Ils n'ont pas forcément de compte Next RH."
        actions={
          readOnly ? null : (
            <FormDialog trigger={<Button size="sm"><Plus size={15} /> Ajouter</Button>} title="Nouvel interlocuteur" action={saveContactAction} hidden={{ companyId }} submitLabel="Ajouter">
              <ContactFields />
            </FormDialog>
          )
        }
      />
      {rows.length === 0 ? (
        <EmptyState title="Aucun interlocuteur" description="Indiquez au moins la personne à contacter pour la paie et, si vous en avez un, votre expert-comptable." />
      ) : (
        <Table>
          <thead>
            <tr>
              <Th>Nom</Th>
              <Th>Rôle</Th>
              <Th>E-mail</Th>
              <Th>Téléphone</Th>
              <Th className="w-24"><span className="sr-only">Actions</span></Th>
            </tr>
          </thead>
          <tbody>
            {rows.map((c) => (
              <tr key={c.id}>
                <Td className="font-medium">{c.fullName}</Td>
                <Td className="text-ink-2">{contactRoleLabels[c.role] ?? c.role}</Td>
                <Td>{c.email ?? "-"}</Td>
                <Td className="num">{c.phone ?? "-"}</Td>
                <Td className="text-right">
                  {readOnly ? null : (
                    <div className="flex justify-end gap-1">
                      <FormDialog trigger={<Button size="icon" variant="ghost" aria-label={`Modifier ${c.fullName}`}><PencilSimple size={16} /></Button>} title={`Modifier : ${c.fullName}`} action={saveContactAction} hidden={{ companyId, id: c.id }} submitLabel="Enregistrer">
                        <ContactFields c={c} />
                      </FormDialog>
                      <FormDialog trigger={<Button size="icon" variant="ghost" aria-label={`Retirer ${c.fullName}`}><Trash size={16} /></Button>} title="Retirer cet interlocuteur ?" action={deleteContactAction} hidden={{ companyId, id: c.id }} submitLabel="Retirer" danger />
                    </div>
                  )}
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Panel>
  );
}
