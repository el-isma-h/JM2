/** Étapes de l'onboarding guidé (clé stockée dans companies.onboarding_step). */
export const ONBOARDING_STEPS = [
  { key: "entreprise", label: "Identité de l'entreprise", group: "Entreprise", intro: "Les informations légales qui apparaîtront sur les bulletins et les déclarations." },
  { key: "etablissements", label: "Établissements", group: "Entreprise", intro: "Chaque lieu de travail déclaré à l'INSEE a son propre SIRET. La paie est déclarée établissement par établissement." },
  { key: "convention", label: "Convention collective", group: "Entreprise", intro: "Elle fixe les salaires minima, certaines primes et des cotisations spécifiques. Une erreur ici fausse tous les bulletins." },
  { key: "interlocuteurs", label: "Interlocuteurs et documents", group: "Entreprise", intro: "Les personnes à contacter et les justificatifs utiles pour vérifier le dossier." },
  { key: "paie", label: "Organisation de la paie", group: "Paie", intro: "Les paramètres qui changent le calcul : effectif, taux accident du travail, mutuelle, prévoyance, et qui prépare et valide." },
  { key: "organismes", label: "Organismes sociaux", group: "Paie", intro: "Les organismes auxquels les cotisations sont versées et déclarées." },
  { key: "reprise", label: "Reprise des données", group: "Reprise", intro: "Importez salariés, contrats, salaires, cumuls de l'année et soldes de congés depuis votre ancien logiciel." },
  { key: "verification", label: "Vérification", group: "Lancement", intro: "Tout ce qui reste à faire avant la première paie, avec le lien pour le corriger." },
] as const;

export type OnboardingStepKey = (typeof ONBOARDING_STEPS)[number]["key"];

export function normalizeStep(v: string | null | undefined): OnboardingStepKey {
  return (ONBOARDING_STEPS.find((s) => s.key === v)?.key ?? "entreprise") as OnboardingStepKey;
}

export function stepIndex(v: string): number {
  return Math.max(0, ONBOARDING_STEPS.findIndex((s) => s.key === v));
}
