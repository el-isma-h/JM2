"use client";

import * as React from "react";
import { useActionState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Check, CircleNotch, WarningCircle } from "@phosphor-icons/react";
import { Notice } from "@/components/ui/surface";
import type { ActionState } from "@/server/actions/auth";
import { cn } from "@/lib/utils";

type Action = (prev: ActionState, fd: FormData) => Promise<ActionState>;

/** Formulaire branché sur une server action, avec message de retour. */
export function ActionForm({
  action,
  children,
  className,
  onSuccess,
  hidden,
  resetOnSuccess,
}: {
  action: Action;
  children: React.ReactNode | ((state: ActionState, pending: boolean) => React.ReactNode);
  className?: string;
  onSuccess?: (state: ActionState) => void;
  hidden?: Record<string, string>;
  resetOnSuccess?: boolean;
}) {
  const [state, formAction, pending] = useActionState(action, {} as ActionState);
  const ref = React.useRef<HTMLFormElement>(null);
  const last = React.useRef<ActionState | null>(null);
  React.useEffect(() => {
    if (state !== last.current && state.ok) {
      last.current = state;
      if (resetOnSuccess) ref.current?.reset();
      onSuccess?.(state);
    }
  }, [state, onSuccess, resetOnSuccess]);
  return (
    <form ref={ref} action={formAction} className={className}>
      {hidden ? Object.entries(hidden).map(([k, v]) => <input key={k} type="hidden" name={k} value={v} />) : null}
      {typeof children === "function" ? children(state, pending) : children}
      <FormMessage state={state} />
    </form>
  );
}

export function FormMessage({ state, className }: { state: ActionState; className?: string }) {
  if (state.error) return <Notice tone="danger" className={cn("mt-3", className)}>{state.error}</Notice>;
  if (state.ok && state.message) {
    return (
      <Notice tone="ok" className={cn("mt-3", className)}>
        {state.message}
        {state.data?.link ? <CopyLink link={state.data.link} /> : null}
      </Notice>
    );
  }
  return null;
}

export function CopyLink({ link }: { link: string }) {
  const [copied, setCopied] = React.useState(false);
  return (
    <div className="mt-2 flex flex-wrap items-center gap-2">
      <code className="num min-w-0 flex-1 truncate rounded-[var(--radius-sm)] bg-bg-elev px-2 py-1 text-[12px] text-ink">{link}</code>
      <button
        type="button"
        className="text-[12.5px] font-medium underline underline-offset-2"
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(link);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
          } catch {}
        }}
      >
        {copied ? "Lien copié" : "Copier le lien"}
      </button>
    </div>
  );
}

export type SaveStatus = "idle" | "pending" | "saving" | "saved" | "error";

/**
 * Enregistrement automatique : chaque changement de champ est mis en file, fusionné, puis envoyé
 * après un court délai (debounce). Les erreurs de validation reviennent champ par champ.
 */
export function useAutosave<P extends Record<string, unknown>>(
  save: (patch: P) => Promise<{ ok: boolean; errors: Record<string, string>; savedAt?: string; error?: string }>,
  delay = 700,
) {
  const [status, setStatus] = React.useState<SaveStatus>("idle");
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [savedAt, setSavedAt] = React.useState<string | null>(null);
  const [globalError, setGlobalError] = React.useState<string | null>(null);
  const pending = React.useRef<Partial<P>>({});
  const timer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const saveRef = React.useRef(save);
  React.useEffect(() => {
    saveRef.current = save;
  }, [save]);

  const flush = React.useCallback(async () => {
    const patch = pending.current as P;
    pending.current = {};
    if (!Object.keys(patch).length) return;
    setStatus("saving");
    try {
      const res = await saveRef.current(patch);
      setErrors((prev) => {
        const next = { ...prev };
        for (const k of Object.keys(patch)) {
          for (const ek of Object.keys(next)) if (ek === k || ek.startsWith(`${k}.`) || ek.startsWith(k)) delete next[ek];
        }
        return { ...next, ...res.errors };
      });
      if (res.error) {
        setGlobalError(res.error);
        setStatus("error");
      } else {
        setGlobalError(null);
        setSavedAt(res.savedAt ?? new Date().toISOString());
        setStatus(Object.keys(res.errors).length ? "error" : "saved");
      }
    } catch {
      setGlobalError("Connexion interrompue : la modification n'a pas été enregistrée.");
      setStatus("error");
    }
  }, []);

  const queue = React.useCallback(
    (patch: Partial<P>, immediate = false) => {
      pending.current = { ...pending.current, ...patch };
      setStatus("pending");
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => void flush(), immediate ? 0 : delay);
    },
    [delay, flush],
  );

  React.useEffect(() => {
    const onLeave = () => {
      if (Object.keys(pending.current).length) void flush();
    };
    window.addEventListener("beforeunload", onLeave);
    return () => {
      window.removeEventListener("beforeunload", onLeave);
      if (timer.current) clearTimeout(timer.current);
      if (Object.keys(pending.current).length) void flush();
    };
  }, [flush]);

  return { status, errors, savedAt, globalError, queue };
}

/** Indicateur discret « Enregistré » / « Enregistrement… » / erreur. */
export function SaveIndicator({ status, savedAt, error }: { status: SaveStatus; savedAt: string | null; error?: string | null }) {
  const reduce = useReducedMotion();
  const content =
    status === "saving" || status === "pending" ? (
      <span className="inline-flex items-center gap-1.5 text-ink-3">
        <CircleNotch size={14} className="animate-spin" /> Enregistrement
      </span>
    ) : status === "error" ? (
      <span className="inline-flex items-center gap-1.5 text-danger-ink">
        <WarningCircle size={14} /> {error ?? "Certains champs ne sont pas enregistrés"}
      </span>
    ) : status === "saved" ? (
      <span className="inline-flex items-center gap-1.5 text-ok-ink">
        <Check size={14} weight="bold" /> Enregistré
        {savedAt ? <span className="text-ink-3">à {new Date(savedAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</span> : null}
      </span>
    ) : (
      <span className="text-ink-3">Enregistrement automatique</span>
    );
  return (
    <div className="min-h-5 text-[12.5px]" aria-live="polite">
      <AnimatePresence mode="wait" initial={false}>
        <motion.span key={status} initial={reduce ? false : { opacity: 0, y: 2 }} animate={{ opacity: 1, y: 0 }} exit={reduce ? undefined : { opacity: 0 }} transition={{ duration: 0.16 }} className="inline-block">
          {content}
        </motion.span>
      </AnimatePresence>
    </div>
  );
}
