"use client";

import * as React from "react";
import Link from "next/link";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Check, WarningCircle } from "@phosphor-icons/react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { setOnboardingStepAction } from "@/server/actions/onboarding";
import { ONBOARDING_STEPS, stepIndex, type OnboardingStepKey } from "./steps";

/**
 * Cadre de l'assistant : barre de progression, liste des étapes et transition entre étapes.
 * La position est enregistrée côté serveur pour reprendre plus tard au même endroit.
 */
export function OnboardingShell({
  companyId,
  step,
  stepStatus,
  progress,
  children,
}: {
  companyId: string;
  step: OnboardingStepKey;
  stepStatus: Record<string, "ok" | "todo" | "blocking">;
  progress: number;
  children: React.ReactNode;
}) {
  const reduce = useReducedMotion();
  const idx = stepIndex(step);
  const current = ONBOARDING_STEPS[idx];
  const prev = ONBOARDING_STEPS[idx - 1];
  const next = ONBOARDING_STEPS[idx + 1];

  React.useEffect(() => {
    void setOnboardingStepAction(companyId, step);
  }, [companyId, step]);

  const href = (k: string) => `/app/${companyId}/onboarding?etape=${k}`;

  return (
    <div className="grid gap-8 lg:grid-cols-[232px_minmax(0,1fr)]">
      <aside className="lg:sticky lg:top-20 lg:self-start">
        <div className="mb-4">
          <div className="flex items-baseline justify-between text-[12.5px]">
            <span className="text-ink-2">Mise en route</span>
            <span className="num text-ink">{progress} %</span>
          </div>
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-none bg-bg-muted" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} aria-label="Progression de l'onboarding">
            <motion.div className="h-full rounded-none bg-accent" initial={reduce ? false : { width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }} />
          </div>
        </div>
        <nav aria-label="Étapes de l'onboarding">
          <ol className="space-y-0.5">
            {ONBOARDING_STEPS.map((s, i) => {
              const showGroup = i === 0 || ONBOARDING_STEPS[i - 1].group !== s.group;
              const st = stepStatus[s.key];
              const active = s.key === step;
              return (
                <li key={s.key}>
                  {showGroup ? <p className={cn("px-2 pb-1 text-[11.5px] font-medium text-ink-3", i > 0 && "pt-3")}>{s.group}</p> : null}
                  <Link
                    href={href(s.key)}
                    aria-current={active ? "step" : undefined}
                    className={cn(
                      "flex items-center gap-2.5 rounded-[var(--radius-sm)] px-2 py-1.5 text-[13.5px] transition-colors",
                      active ? "bg-accent-soft font-medium text-accent-strong" : "text-ink-2 hover:bg-bg-sunken hover:text-ink",
                    )}
                  >
                    <span
                      className={cn(
                        "flex h-5 w-5 shrink-0 items-center justify-center rounded-none border text-[11px]",
                        st === "ok" ? "border-accent bg-accent text-accent-ink" : st === "blocking" ? "border-danger text-danger-ink" : active ? "border-accent-strong text-accent-strong" : "border-line-strong text-ink-3",
                      )}
                      aria-hidden
                    >
                      {st === "ok" ? <Check size={11} weight="bold" /> : st === "blocking" ? <WarningCircle size={12} weight="bold" /> : <span className="num">{i + 1}</span>}
                    </span>
                    <span className="min-w-0 truncate">{s.label}</span>
                    <span className="sr-only">{st === "ok" ? "(terminé)" : st === "blocking" ? "(bloquant)" : ""}</span>
                  </Link>
                </li>
              );
            })}
          </ol>
        </nav>
      </aside>

      <div className="min-w-0">
        <AnimatePresence mode="wait" initial={false}>
          <motion.section
            key={step}
            initial={reduce ? false : { opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            exit={reduce ? undefined : { opacity: 0, x: -8 }}
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
            aria-labelledby="onboarding-step-title"
          >
            <header className="mb-5">
              <p className="text-[12.5px] text-ink-3">
                Étape <span className="num">{idx + 1}</span> sur <span className="num">{ONBOARDING_STEPS.length}</span>
              </p>
              <h2 id="onboarding-step-title" className="mt-0.5 text-[19px] font-semibold text-ink">
                {current.label}
              </h2>
              <p className="mt-1 max-w-[68ch] text-[13.5px] text-ink-2">{current.intro}</p>
            </header>
            {children}
            <div className="mt-8 flex items-center justify-between border-t border-line pt-4">
              {prev ? (
                <Link href={href(prev.key)} className="text-[13.5px] text-ink-2 hover:text-ink">
                  Étape précédente : {prev.label}
                </Link>
              ) : (
                <span />
              )}
              {next ? (
                <Button asChild>
                  <Link href={href(next.key)}>Continuer : {next.label}</Link>
                </Button>
              ) : null}
            </div>
          </motion.section>
        </AnimatePresence>
      </div>
    </div>
  );
}
