"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { MagnifyingGlass } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select } from "@/components/ui/field";
import { Notice, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { applySuggestionAction, autosaveCompanyAction, lookupSirenAction } from "@/server/actions/onboarding";
import type { CompanySuggestion } from "@/server/onboarding/lookup-parse";
import { legalFormLabels } from "@/components/employees/labels";
import { SaveIndicator, useAutosave } from "./action-form";

export type CompanyValues = {
  legalName: string;
  tradeName: string | null;
  siren: string | null;
  legalForm: string | null;
  activity: string | null;
  apeCode: string | null;
  addressLine1: string | null;
  addressLine2: string | null;
  postalCode: string | null;
  city: string | null;
  headcount: number | null;
  idcc: string | null;
  collectiveAgreement: string | null;
};

type Patch = Partial<Record<keyof CompanyValues, string>>;

const suggestionLabels: Record<string, string> = {
  legalName: "Raison sociale",
  tradeName: "Nom commercial",
  legalForm: "Forme juridique",
  apeCode: "Code APE",
  addressLine1: "Adresse du siège",
  postalCode: "Code postal",
  city: "Ville",
  idcc: "Convention collective (IDCC)",
  headOfficeSiret: "SIRET du siège",
};

/** Identité de l'entreprise, enregistrée automatiquement. Suggestions du répertoire public sur demande. */
export function CompanyIdentityForm({ companyId, values, readOnly }: { companyId: string; values: CompanyValues; readOnly?: boolean }) {
  const router = useRouter();
  const save = React.useCallback((p: Patch) => autosaveCompanyAction(companyId, p), [companyId]);
  const { status, errors, savedAt, globalError, queue } = useAutosave<Patch>(save);
  const formRef = React.useRef<HTMLDivElement>(null);
  const [lookup, setLookup] = React.useState<{ loading: boolean; error?: string; suggestion?: CompanySuggestion }>({ loading: false });
  const [selected, setSelected] = React.useState<Record<string, boolean>>({});
  const [applying, setApplying] = React.useState(false);
  const sirenRef = React.useRef<HTMLInputElement>(null);

  const on = (k: keyof CompanyValues, immediate = false) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => queue({ [k]: e.target.value } as Patch, immediate);

  const suggestionRows = React.useMemo(() => {
    const s = lookup.suggestion;
    if (!s) return [];
    const rows: { key: string; current: string; suggested: string }[] = [];
    const add = (key: string, current: string | null | undefined, suggested: string | undefined) => {
      if (suggested && suggested !== current) rows.push({ key, current: current ?? "", suggested });
    };
    add("legalName", values.legalName, s.legalName);
    add("tradeName", values.tradeName, s.tradeName);
    add("legalForm", values.legalForm, s.legalForm);
    add("apeCode", values.apeCode, s.apeCode);
    add("addressLine1", values.addressLine1, s.addressLine1);
    add("postalCode", values.postalCode, s.postalCode);
    add("city", values.city, s.city);
    if (s.idccList.length === 1) add("idcc", values.idcc, s.idccList[0]);
    add("headOfficeSiret", null, s.headOfficeSiret);
    return rows;
  }, [lookup.suggestion, values]);

  async function runLookup() {
    const siren = sirenRef.current?.value ?? "";
    setLookup({ loading: true });
    const r = await lookupSirenAction(companyId, siren);
    if (r.suggestion) {
      setLookup({ loading: false, suggestion: r.suggestion });
      const sel: Record<string, boolean> = {};
      const cur = values as unknown as Record<string, string | null>;
      for (const k of Object.keys(suggestionLabels)) sel[k] = !cur[k];
      setSelected(sel);
    } else setLookup({ loading: false, error: r.error });
  }

  async function applySelected() {
    if (!lookup.suggestion) return;
    setApplying(true);
    const fields: Record<string, string> = {};
    for (const row of suggestionRows) if (selected[row.key]) fields[row.key] = row.suggested;
    const res = await applySuggestionAction(companyId, fields);
    setApplying(false);
    // Reporte les valeurs reprises dans les champs affichés (champs non contrôlés).
    for (const [k, v] of Object.entries(fields)) {
      if (res.errors[k]) continue;
      const el = formRef.current?.querySelector<HTMLInputElement | HTMLSelectElement>(`#${k}`);
      if (el) el.value = k === "apeCode" && /^\d{4}[A-Z]$/.test(v) ? `${v.slice(0, 2)}.${v.slice(2)}` : v;
    }
    setLookup({ loading: false });
    router.refresh();
  }

  return (
    <div ref={formRef} className="space-y-6">
      <Panel>
        <PanelHeader title="Informations légales" description="Elles figurent sur chaque bulletin de paie et dans la déclaration sociale nominative." actions={readOnly ? null : <SaveIndicator status={status} savedAt={savedAt} error={globalError} />} />
        <fieldset disabled={readOnly} className="grid gap-x-5 gap-y-4 p-5 sm:grid-cols-2">
          <Field label="SIREN" htmlFor="siren" required error={errors.siren} help="9 chiffres. Il figure sur le Kbis, l'avis de situation INSEE ou en haut de vos anciens bulletins.">
            <div className="flex gap-2">
              <Input id="siren" ref={sirenRef} inputMode="numeric" defaultValue={values.siren ?? ""} onChange={on("siren")} placeholder="552 032 534" className="num" aria-invalid={Boolean(errors.siren)} />
              {readOnly ? null : (
                <Button type="button" variant="secondary" onClick={runLookup} loading={lookup.loading} title="Chercher dans le répertoire public des entreprises">
                  {lookup.loading ? null : <MagnifyingGlass size={16} />}
                  Suggérer
                </Button>
              )}
            </div>
          </Field>
          <Field label="Raison sociale" htmlFor="legalName" required error={errors.legalName} help="Le nom officiel de la société, tel qu'inscrit au registre du commerce.">
            <Input id="legalName" defaultValue={values.legalName} onChange={on("legalName")} aria-invalid={Boolean(errors.legalName)} />
          </Field>
          <Field label="Nom commercial" htmlFor="tradeName" hint="facultatif" help="Le nom sous lequel vos clients vous connaissent, s'il diffère.">
            <Input id="tradeName" defaultValue={values.tradeName ?? ""} onChange={on("tradeName")} />
          </Field>
          <Field label="Forme juridique" htmlFor="legalForm" error={errors.legalForm} help="SAS, SARL… Elle détermine notamment le régime social du dirigeant.">
            <Select id="legalForm" defaultValue={values.legalForm ?? ""} onChange={on("legalForm", true)}>
              <option value="">Choisir</option>
              {Object.entries(legalFormLabels).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Activité" htmlFor="activity" help="En quelques mots : ce que fait l'entreprise.">
            <Input id="activity" defaultValue={values.activity ?? ""} onChange={on("activity")} placeholder="Conseil en systèmes informatiques" />
          </Field>
          <Field label="Code APE (NAF)" htmlFor="apeCode" error={errors.apeCode} help="4 chiffres et une lettre, attribué par l'INSEE. Il aide à vérifier la convention collective.">
            <Input id="apeCode" defaultValue={values.apeCode ?? ""} onChange={on("apeCode")} placeholder="62.02A" className="num" aria-invalid={Boolean(errors.apeCode)} />
          </Field>
          <Field label="Effectif actuel" htmlFor="headcount" error={errors.headcount} help="Nombre de salariés aujourd'hui, approximatif. La tranche exacte se confirme à l'étape Organisation de la paie.">
            <Input id="headcount" inputMode="numeric" defaultValue={values.headcount ?? ""} onChange={on("headcount")} className="num" aria-invalid={Boolean(errors.headcount)} />
          </Field>
        </fieldset>
      </Panel>

      {lookup.error ? <Notice tone="warn">{lookup.error}</Notice> : null}
      {lookup.suggestion ? (
        <Panel>
          <PanelHeader
            title="Suggestions du répertoire public"
            description="Source : API Recherche d'entreprises (data.gouv.fr). Rien n'est enregistré sans votre accord : cochez ce que vous voulez reprendre."
            actions={
              <>
                <Button type="button" variant="ghost" size="sm" onClick={() => setLookup({ loading: false })}>
                  Ignorer
                </Button>
                <Button type="button" size="sm" onClick={applySelected} loading={applying} disabled={!suggestionRows.some((r) => selected[r.key])}>
                  Reprendre la sélection
                </Button>
              </>
            }
          />
          {suggestionRows.length === 0 ? (
            <p className="px-5 py-4 text-[13.5px] text-ink-2">Les informations saisies correspondent déjà au répertoire.</p>
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th className="w-10"><span className="sr-only">Reprendre</span></Th>
                  <Th>Information</Th>
                  <Th>Valeur actuelle</Th>
                  <Th>Suggestion</Th>
                </tr>
              </thead>
              <tbody>
                {suggestionRows.map((r) => (
                  <tr key={r.key}>
                    <Td>
                      <Checkbox aria-label={`Reprendre ${suggestionLabels[r.key]}`} checked={Boolean(selected[r.key])} onChange={(e) => setSelected((s) => ({ ...s, [r.key]: e.target.checked }))} />
                    </Td>
                    <Td className="text-ink-2">{suggestionLabels[r.key]}</Td>
                    <Td className="text-ink-3">{r.current || "Non renseigné"}</Td>
                    <Td className="font-medium">{r.key === "legalForm" ? legalFormLabels[r.suggested] ?? r.suggested : r.suggested}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
          <div className="space-y-1 border-t border-line px-5 py-3 text-[12.5px] text-ink-2">
            {lookup.suggestion.headcountLabel ? <p>Tranche d&apos;effectif connue de l&apos;INSEE : {lookup.suggestion.headcountLabel}. Elle peut être ancienne : vous confirmerez l&apos;effectif réel plus loin.</p> : null}
            {lookup.suggestion.idccList.length > 1 ? <p>Plusieurs conventions collectives sont déclarées ({lookup.suggestion.idccList.join(", ")}) : vous choisirez à l&apos;étape Convention collective.</p> : null}
            <p>Une convention collective reprise ici reste à confirmer explicitement à l&apos;étape suivante.</p>
          </div>
        </Panel>
      ) : null}

      <Panel>
        <PanelHeader title="Adresse du siège" description="L'adresse inscrite au registre du commerce." />
        <fieldset disabled={readOnly} className="grid gap-x-5 gap-y-4 p-5 sm:grid-cols-6">
          <Field label="Adresse" htmlFor="addressLine1" className="sm:col-span-6">
            <Input id="addressLine1" defaultValue={values.addressLine1 ?? ""} onChange={on("addressLine1")} />
          </Field>
          <Field label="Complément" htmlFor="addressLine2" hint="facultatif" className="sm:col-span-6">
            <Input id="addressLine2" defaultValue={values.addressLine2 ?? ""} onChange={on("addressLine2")} />
          </Field>
          <Field label="Code postal" htmlFor="postalCode" error={errors.postalCode} className="sm:col-span-2">
            <Input id="postalCode" inputMode="numeric" defaultValue={values.postalCode ?? ""} onChange={on("postalCode")} className="num" aria-invalid={Boolean(errors.postalCode)} />
          </Field>
          <Field label="Ville" htmlFor="city" className="sm:col-span-4">
            <Input id="city" defaultValue={values.city ?? ""} onChange={on("city")} />
          </Field>
        </fieldset>
      </Panel>
    </div>
  );
}

const COMMON_IDCC = [
  { idcc: "1486", label: "Bureaux d'études techniques, cabinets d'ingénieurs-conseils (Syntec)" },
  { idcc: "1979", label: "Hôtels, cafés, restaurants (HCR)" },
  { idcc: "2216", label: "Commerce de détail et de gros à prédominance alimentaire" },
  { idcc: "1517", label: "Commerces de détail non alimentaires" },
  { idcc: "0016", label: "Transports routiers et activités auxiliaires du transport" },
  { idcc: "3043", label: "Entreprises de propreté et services associés" },
  { idcc: "1090", label: "Services de l'automobile" },
  { idcc: "2098", label: "Prestataires de services dans le domaine du secteur tertiaire" },
  { idcc: "3248", label: "Métallurgie" },
  { idcc: "1501", label: "Restauration rapide" },
];

/** Convention collective : IDCC + intitulé, confirmation explicite obligatoire. */
export function AgreementForm({ companyId, idcc, name, confirmed, apeCode }: { companyId: string; idcc: string | null; name: string | null; confirmed: boolean; apeCode: string | null }) {
  const save = React.useCallback((p: Record<string, string | boolean>) => autosaveCompanyAction(companyId, p), [companyId]);
  const { status, errors, savedAt, globalError, queue } = useAutosave<Record<string, string | boolean>>(save, 600);
  const [isConfirmed, setConfirmed] = React.useState(confirmed);
  const idccRef = React.useRef<HTMLInputElement>(null);
  const nameRef = React.useRef<HTMLInputElement>(null);

  return (
    <div className="space-y-6">
      <Panel>
        <PanelHeader title="Convention collective applicable" description="Indiquée sur les contrats de travail et sur les anciens bulletins (mention « Convention collective » ou « IDCC »)." actions={<SaveIndicator status={status} savedAt={savedAt} error={globalError} />} />
        <div className="grid gap-x-5 gap-y-4 p-5 sm:grid-cols-[160px_1fr]">
          <Field label="IDCC" htmlFor="idcc" required error={errors.idcc} help="Identifiant à 4 chiffres.">
            <Input
              id="idcc"
              ref={idccRef}
              inputMode="numeric"
              defaultValue={idcc ?? ""}
              className="num"
              aria-invalid={Boolean(errors.idcc)}
              onChange={(e) => {
                setConfirmed(false);
                queue({ idcc: e.target.value });
              }}
            />
          </Field>
          <Field label="Intitulé" htmlFor="collectiveAgreement" help="Le nom de la convention, pour la retrouver facilement.">
            <Input
              id="collectiveAgreement"
              ref={nameRef}
              defaultValue={name ?? ""}
              onChange={(e) => {
                setConfirmed(false);
                queue({ collectiveAgreement: e.target.value });
              }}
            />
          </Field>
        </div>
        <div className="border-t border-line px-5 py-4">
          <Checkbox
            checked={isConfirmed}
            onChange={(e) => {
              setConfirmed(e.target.checked);
              queue({ idccConfirmed: e.target.checked }, true);
            }}
            label={
              <>
                <span className="font-medium">Je confirme que cette convention collective s&apos;applique à l&apos;entreprise.</span>
                <span className="mt-0.5 block text-[12.5px] text-ink-2">Elle détermine les salaires minima, les primes conventionnelles et certaines cotisations. En cas de doute, vérifiez avec votre expert-comptable avant de confirmer.</span>
              </>
            }
          />
          {errors.idccConfirmed ? <p className="mt-2 text-[12.5px] text-danger-ink">{errors.idccConfirmed}</p> : null}
        </div>
      </Panel>
      <Panel>
        <PanelHeader title="Conventions les plus courantes" description={apeCode ? `Pour vous aider, au regard du code APE ${apeCode}. Choisir une ligne remplit les champs, sans la confirmer.` : "Choisir une ligne remplit les champs, sans la confirmer."} />
        <Table>
          <thead>
            <tr>
              <Th className="w-20">IDCC</Th>
              <Th>Intitulé</Th>
              <Th className="w-28"><span className="sr-only">Action</span></Th>
            </tr>
          </thead>
          <tbody>
            {COMMON_IDCC.map((c) => (
              <tr key={c.idcc}>
                <Td className="num">{c.idcc}</Td>
                <Td>{c.label}</Td>
                <Td className="text-right">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setConfirmed(false);
                      queue({ idcc: c.idcc, collectiveAgreement: c.label }, true);
                      if (idccRef.current) idccRef.current.value = c.idcc;
                      if (nameRef.current) nameRef.current.value = c.label;
                    }}
                  >
                    Choisir
                  </Button>
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
        <p className="border-t border-line px-5 py-3 text-[12.5px] text-ink-2">
          Votre convention n&apos;est pas dans la liste ? Le moteur de recherche officiel est sur code.travail.gouv.fr, rubrique « Trouver sa convention collective ».
        </p>
      </Panel>
    </div>
  );
}
