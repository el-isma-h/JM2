"use client";

import * as React from "react";
import Link from "next/link";
import { DownloadSimple, UploadSimple } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/field";
import { StatusBadge } from "@/components/ui/badge";
import { EmptyState, Notice, Panel, PanelHeader } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { uploadImportAction } from "@/server/actions/imports";
import { fmtDateTime } from "@/lib/dates";
import { ActionForm } from "./action-form";

export type ImportKindInfo = { kind: string; label: string; description: string; required: boolean };
export type ImportRow = { id: string; kind: string; kindLabel: string; fileName: string; status: string; totalRows: number; appliedCount: number; createdAt: string };

function UploadForm({ companyId, kind }: { companyId: string; kind: string }) {
  return (
    <ActionForm action={uploadImportAction} hidden={{ companyId, kind }} className="mt-3">
      {(_s, pending) => (
        <div className="flex flex-wrap items-center gap-2">
          <Input name="file" type="file" accept=".csv,text/csv,.txt" required aria-label="Fichier CSV" className="max-w-xs py-1.5 file:mr-3 file:rounded-[var(--radius-sm)] file:border-0 file:bg-bg-muted file:px-2 file:py-1 file:text-[12.5px]" />
          <Button type="submit" size="sm" loading={pending}>
            {pending ? null : <UploadSimple size={15} />} Charger et vérifier
          </Button>
        </div>
      )}
    </ActionForm>
  );
}

export function ImportPanel({ companyId, kinds, imports, midYear }: { companyId: string; kinds: ImportKindInfo[]; imports: ImportRow[]; midYear: { year: number; month: number } | null }) {
  return (
    <div className="space-y-6">
      {midYear ? (
        <Notice tone="warn" title={`Reprise en cours d'année ${midYear.year}`}>
          La première paie Next RH porte sur le mois {String(midYear.month).padStart(2, "0")}/{midYear.year}. Les cumuls de janvier à {String(midYear.month - 1).padStart(2, "0")}/{midYear.year} sont obligatoires pour chaque salarié présent : sans eux, les plafonds de la Sécurité sociale, la réduction générale de cotisations et le prélèvement à la source seraient faux.
        </Notice>
      ) : (
        <Notice tone="info">
          Format accepté : CSV (séparateur point-virgule ou virgule, UTF-8 ou Windows). Les fichiers Excel se convertissent avec « Enregistrer sous », puis « CSV UTF-8 ». Importez d&apos;abord les salariés : les autres fichiers s&apos;y rattachent par le matricule.
        </Notice>
      )}

      <Panel>
        <PanelHeader title="Fichiers à importer" description="Téléchargez le modèle, remplissez-le depuis votre ancien logiciel, puis chargez-le. Rien n'est enregistré avant votre validation finale." />
        <div>
          {kinds.map((k, i) => (
            <div key={k.kind} className={i > 0 ? "border-t border-line px-5 py-4" : "px-5 py-4"}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 max-w-[70ch]">
                  <p className="text-[14px] font-medium text-ink">
                    {k.label} {k.required ? <span className="ml-1 text-[12px] font-normal text-warn-ink">obligatoire pour la reprise en cours d&apos;année</span> : null}
                  </p>
                  <p className="mt-0.5 text-[13px] text-ink-2">{k.description}</p>
                </div>
                <Button asChild variant="secondary" size="sm">
                  <a href={`/app/${companyId}/onboarding/modeles/${k.kind}`} download>
                    <DownloadSimple size={15} /> Modèle CSV
                  </a>
                </Button>
              </div>
              <UploadForm companyId={companyId} kind={k.kind} />
            </div>
          ))}
        </div>
      </Panel>

      <Panel>
        <PanelHeader title="Imports réalisés" />
        {imports.length === 0 ? (
          <EmptyState title="Aucun import pour l'instant" description="Vous pouvez aussi créer les salariés un par un depuis la rubrique Salariés." />
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Fichier</Th>
                <Th>Contenu</Th>
                <Th>État</Th>
                <Th num>Lignes</Th>
                <Th num>Importées</Th>
                <Th>Date</Th>
                <Th className="w-28"><span className="sr-only">Action</span></Th>
              </tr>
            </thead>
            <tbody>
              {imports.map((r) => (
                <tr key={r.id}>
                  <Td className="max-w-[220px] truncate font-medium">{r.fileName}</Td>
                  <Td className="text-ink-2">{r.kindLabel}</Td>
                  <Td>
                    <StatusBadge status={r.status} />
                  </Td>
                  <Td num>{r.totalRows}</Td>
                  <Td num>{r.appliedCount}</Td>
                  <Td>{fmtDateTime(r.createdAt)}</Td>
                  <Td className="text-right">
                    <Button asChild variant="ghost" size="sm">
                      <Link href={`/app/${companyId}/onboarding/import/${r.id}`}>{r.status === "applied" ? "Voir" : "Reprendre"}</Link>
                    </Button>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Panel>
    </div>
  );
}
