"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle, Circle, WarningCircle } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Notice, Panel, PanelHeader } from "@/components/ui/surface";
import { Stagger, StaggerItem } from "@/components/ui/motion";
import { completeOnboardingAction } from "@/server/actions/onboarding";
import type { ChecklistItem } from "@/server/onboarding/checklist";
import { ActionForm } from "./action-form";

const icon = {
  ok: <CheckCircle size={18} weight="fill" className="text-accent" aria-hidden />,
  todo: <Circle size={18} className="text-ink-3" aria-hidden />,
  blocking: <WarningCircle size={18} weight="fill" className="text-danger" aria-hidden />,
};
const statusText = { ok: "Fait", todo: "À faire", blocking: "Bloque la première paie" };

export function ChecklistView({
  companyId,
  groups,
  blockingCount,
  progress,
  completedAt,
}: {
  companyId: string;
  groups: { key: string; label: string; items: ChecklistItem[] }[];
  blockingCount: number;
  progress: number;
  completedAt: string | null;
}) {
  const router = useRouter();
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <Badge tone={blockingCount ? "danger" : "ok"}>{blockingCount ? `${blockingCount} élément(s) bloquant(s)` : "Aucun élément bloquant"}</Badge>
        <span className="text-[13px] text-ink-2">
          <span className="num">{progress} %</span> des vérifications sont au vert.
        </span>
      </div>

      {groups.map((g) => (
        <Panel key={g.key}>
          <PanelHeader title={g.label} />
          <Stagger>
            {g.items.map((it, i) => (
              <StaggerItem key={it.key} className={i > 0 ? "border-t border-line" : ""}>
                <div className="flex items-start gap-3 px-5 py-3">
                  <span className="mt-0.5">{icon[it.status]}</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13.5px] font-medium text-ink">
                      {it.label} <span className="sr-only">: {statusText[it.status]}</span>
                    </p>
                    <p className="mt-0.5 text-[13px] text-ink-2">{it.help}</p>
                  </div>
                  {it.status !== "ok" ? (
                    <Button asChild size="sm" variant={it.status === "blocking" ? "secondary" : "ghost"}>
                      <Link href={it.href}>Corriger</Link>
                    </Button>
                  ) : null}
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </Panel>
      ))}

      <Panel>
        <PanelHeader title="Terminer la mise en route" description="La première paie pourra être préparée dès que plus rien n'est bloquant. Les éléments « À faire » peuvent être complétés ensuite." />
        <div className="px-5 py-4">
          {completedAt ? (
            <Notice tone="ok">Onboarding terminé. Les paramètres restent modifiables dans Paramètres et dans chaque dossier salarié.</Notice>
          ) : (
            <ActionForm action={completeOnboardingAction} hidden={{ companyId }} onSuccess={() => router.push(`/app/${companyId}`)}>
              {(_s, pending) => (
                <div className="flex flex-wrap items-center gap-3">
                  <Button type="submit" loading={pending} disabled={blockingCount > 0}>
                    Terminer l&apos;onboarding
                  </Button>
                  {blockingCount > 0 ? <span className="text-[13px] text-ink-2">Corrigez d&apos;abord les {blockingCount} élément(s) marqué(s) en rouge : ils fausseraient ou bloqueraient la première paie.</span> : null}
                </div>
              )}
            </ActionForm>
          )}
        </div>
      </Panel>
    </div>
  );
}
