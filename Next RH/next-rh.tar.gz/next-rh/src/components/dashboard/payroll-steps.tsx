import { Check } from "@phosphor-icons/react/ssr";
import { cn } from "@/lib/utils";

/** Étapes lisibles du cycle de paie, regroupant les statuts techniques de `payroll_periods`. */
const STEPS: { label: string; statuses: string[] }[] = [
  { label: "Collecte des variables", statuses: ["open", "collecting"] },
  { label: "Vérification", statuses: ["checking"] },
  { label: "Calcul et contrôle", statuses: ["computed", "controlled"] },
  { label: "Validation", statuses: ["validated"] },
  { label: "Déclaration et paiement", statuses: ["finalized", "exported"] },
  { label: "Bulletins distribués", statuses: ["distributed"] },
  { label: "Clôture", statuses: ["closed"] },
];

export function PayrollSteps({ status }: { status: string | null }) {
  const current = status ? STEPS.findIndex((s) => s.statuses.includes(status)) : -1;
  return (
    <ol className="grid grid-cols-2 gap-x-3 gap-y-3 sm:grid-cols-4 lg:grid-cols-7" aria-label="Avancement de la paie du mois">
      {STEPS.map((s, i) => {
        const done = i < current || (status === "closed" && i === current);
        const active = i === current && status !== "closed";
        return (
          <li key={s.label} className="min-w-0" aria-current={active ? "step" : undefined}>
            <div className={cn("mb-1.5 h-1 rounded-none", done ? "bg-accent" : active ? "bg-accent/45" : "bg-line")} aria-hidden />
            <p className={cn("flex items-center gap-1 text-[12.5px] leading-tight", done ? "text-ink-2" : active ? "font-medium text-ink" : "text-ink-3")}>
              {done ? <Check size={12} weight="bold" className="shrink-0 text-accent" aria-hidden /> : null}
              {s.label}
              <span className="sr-only">{done ? " : terminé" : active ? " : en cours" : " : à venir"}</span>
            </p>
          </li>
        );
      })}
    </ol>
  );
}
