"use client";

import { CountUp } from "@/components/ui/motion";

/**
 * Chiffre clé animé, utilisable depuis un composant serveur (le formatage est choisi par options,
 * une fonction ne pouvant pas traverser la frontière serveur / client).
 */
export function CountUpNumber({ value, digits = 0, suffix = "", cents = false }: { value: number; digits?: number; suffix?: string; cents?: boolean }) {
  const fmt = (n: number) => {
    if (cents) return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(n / 100);
    return `${new Intl.NumberFormat("fr-FR", { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(n)}${suffix}`;
  };
  return <CountUp value={value} format={fmt} />;
}
