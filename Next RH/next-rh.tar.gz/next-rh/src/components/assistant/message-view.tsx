"use client";

import * as React from "react";
import Link from "next/link";
import { useActionState } from "react";
import { motion, useReducedMotion } from "motion/react";
import { ArrowRight, Check, Circle, Info, Prohibit } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/surface";
import { Table, Td, Th } from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { confirmAssistantAction } from "@/server/actions/assistant";
import type { AssistantMeta } from "@/server/assistant/orchestrator";

export type ChatMessage = { id: string; role: "user" | "assistant" | "tool"; content: string; meta: AssistantMeta | Record<string, never>; createdAt: string | Date };

const stepIcon = {
  done: <Check size={13} weight="bold" className="text-ok-ink" />,
  todo: <Circle size={13} className="text-ink-3" />,
  blocked: <Prohibit size={13} className="text-danger-ink" />,
  info: <Info size={13} className="text-info-ink" />,
};

/** Message de l'assistant ou de l'utilisateur, avec plan, résultats, confirmation et suggestions. */
export function MessageView({
  companyId,
  message,
  onFollowup,
  onConfirmed,
  compact,
}: {
  companyId: string;
  message: ChatMessage;
  onFollowup?: (text: string) => void;
  onConfirmed?: (m: ChatMessage) => void;
  compact?: boolean;
}) {
  const reduce = useReducedMotion();
  const anim = { initial: reduce ? false : { opacity: 0, y: 6 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.24, ease: [0.22, 1, 0.36, 1] as const } };

  if (message.role === "user") {
    return (
      <motion.div {...anim} className="flex justify-end">
        <p className="max-w-[60ch] rounded-[var(--radius-md)] bg-bg-muted px-3.5 py-2 text-[13.5px] text-ink">{message.content}</p>
      </motion.div>
    );
  }
  const meta = (message.meta ?? {}) as AssistantMeta;
  return (
    <motion.div {...anim} className="space-y-3">
      {meta.plan?.length ? (
        <ol aria-label="Plan" className="flex flex-wrap gap-x-4 gap-y-1 text-[12.5px] text-ink-2">
          {meta.plan.map((s, i) => (
            <li key={i} className="flex items-center gap-1.5">
              {stepIcon[s.status]}
              {s.label}
            </li>
          ))}
        </ol>
      ) : null}
      <p className={cn("text-[13.5px] leading-relaxed", meta.error ? "text-danger-ink" : "text-ink")}>{message.content}</p>
      {meta.results?.map((r, i) => (
        <div key={i} className="space-y-2">
          {(meta.results?.length ?? 0) > 1 || r.title ? <p className="text-[13px] font-medium text-ink">{r.title}</p> : null}
          {r.table && !compact ? (
            <div className="rounded-[var(--radius-sm)] border border-line">
              <Table>
                <thead>
                  <tr>
                    {r.table.columns.map((c, j) => (
                      <Th key={c} num={r.table?.numeric?.includes(j)}>
                        {c}
                      </Th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {r.table.rows.map((row, k) => (
                    <tr key={k}>
                      {row.map((cell, j) => (
                        <Td key={j} num={r.table?.numeric?.includes(j)}>
                          {cell}
                        </Td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          ) : r.table && compact ? (
            <p className="text-[12.5px] text-ink-2">{r.table.rows.length} ligne(s) de résultat : ouvrez la conversation pour le détail.</p>
          ) : null}
          {r.links?.length ? (
            <div className="flex flex-wrap gap-3">
              {r.links.map((l) => (
                <Link key={l.href + l.label} href={l.href} className="inline-flex items-center gap-1 text-[13px] font-medium text-accent hover:underline">
                  {l.label}
                  <ArrowRight size={13} />
                </Link>
              ))}
            </div>
          ) : null}
        </div>
      ))}
      {meta.confirm ? <ConfirmBlock companyId={companyId} messageId={message.id} confirm={meta.confirm} onConfirmed={onConfirmed} /> : null}
      {meta.followups?.length && onFollowup ? (
        <div className="flex flex-wrap gap-2">
          {meta.followups.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => onFollowup(f)}
              className="rounded-none border border-line-strong bg-bg-elev px-3 py-1 text-[12.5px] text-ink-2 transition-colors hover:border-accent hover:text-ink"
            >
              {f}
            </button>
          ))}
        </div>
      ) : null}
      {meta.notice ? <p className="text-[12px] text-ink-3">{meta.notice}</p> : null}
    </motion.div>
  );
}

function ConfirmBlock({ companyId, messageId, confirm, onConfirmed }: { companyId: string; messageId: string; confirm: NonNullable<AssistantMeta["confirm"]>; onConfirmed?: (m: ChatMessage) => void }) {
  const [state, action, pending] = useActionState(confirmAssistantAction, {});
  const done = Boolean(confirm.executedAt) || state.ok;
  const sent = React.useRef(false);
  React.useEffect(() => {
    if (state.ok && state.data?.message && !sent.current) {
      sent.current = true;
      onConfirmed?.(JSON.parse(state.data.message) as ChatMessage);
    }
  }, [state, onConfirmed]);
  if (done) return <p className="flex items-center gap-1.5 text-[12.5px] text-ok-ink"><Check size={13} weight="bold" />Action confirmée.</p>;
  return (
    <form action={action} className="flex flex-wrap items-center gap-3 rounded-[var(--radius-sm)] border border-line bg-bg-sunken px-3.5 py-2.5">
      <input type="hidden" name="companyId" value={companyId} />
      <input type="hidden" name="messageId" value={messageId} />
      <p className="text-[13px] text-ink-2">Cette action écrit des données. Rien n&apos;est fait sans votre accord.</p>
      <Button type="submit" size="sm" loading={pending}>
        Confirmer
      </Button>
      <span className="sr-only">{confirm.label}</span>
      {state.error ? <Notice tone="danger" className="w-full">{state.error}</Notice> : null}
    </form>
  );
}
