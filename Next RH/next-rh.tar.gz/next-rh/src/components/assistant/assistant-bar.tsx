"use client";

import * as React from "react";
import Link from "next/link";
import { useActionState } from "react";
import { ArrowRight, Sparkle } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";
import { sendAssistantMessageAction } from "@/server/actions/assistant";
import { SUGGESTIONS } from "@/server/assistant/intents";
import { MessageView, type ChatMessage } from "./message-view";
import type { ActionState } from "@/server/actions/auth";

/**
 * Barre de l'assistant Next RH (en haut du tableau de bord). Les permissions sont appliquées côté serveur
 * par chaque outil ; la barre n'affiche que ce que le serveur renvoie.
 */
export function AssistantBar({ companyId }: { companyId: string }) {
  const [text, setText] = React.useState("");
  const [exchange, setExchange] = React.useState<{ question: string; reply: ChatMessage | null } | null>(null);
  const [conversationId, setConversationId] = React.useState("");

  const [state, action, pending] = useActionState(async (prev: ActionState, fd: FormData) => {
    const res = await sendAssistantMessageAction(prev, fd);
    if (res.ok && res.data?.message) {
      const reply = JSON.parse(res.data.message) as ChatMessage;
      setConversationId(res.data.conversationId);
      setExchange((x) => (x ? { ...x, reply } : x));
      setText("");
    }
    return res;
  }, {});

  const ask = (q: string) => {
    const t = q.trim();
    if (!t || pending) return;
    setExchange({ question: t, reply: null });
    const fd = new FormData();
    fd.set("companyId", companyId);
    fd.set("conversationId", conversationId);
    fd.set("text", t);
    React.startTransition(() => action(fd));
  };

  return (
    <section aria-label="Assistant Next RH" className="rounded-[var(--radius-md)] border border-line bg-bg-elev">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          ask(text);
        }}
        className="flex items-center gap-2 px-4 py-3"
      >
        <Sparkle size={18} className="shrink-0 text-accent" aria-hidden />
        <label htmlFor="assistant-bar-input" className="sr-only">
          Demander à l&apos;assistant
        </label>
        <Input
          id="assistant-bar-input"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Demandez à l'assistant : paie du mois, éléments manquants, documents…"
          autoComplete="off"
          maxLength={2000}
          className="border-transparent bg-transparent px-1 focus:ring-0"
        />
        <Button type="submit" size="sm" loading={pending} disabled={!text.trim()}>
          Demander
        </Button>
      </form>
      <div className="flex flex-wrap gap-2 border-t border-line px-4 py-2.5">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => ask(s)}
            disabled={pending}
            className="rounded-none border border-line px-3 py-1 text-[12.5px] text-ink-2 transition-colors hover:border-accent hover:text-ink disabled:opacity-50"
          >
            {s}
          </button>
        ))}
      </div>
      {exchange || state.error ? (
        <div className="space-y-3 border-t border-line px-4 py-4" aria-live="polite">
          {exchange?.question ? <p className="text-[12.5px] text-ink-3">Vous : {exchange.question}</p> : null}
          {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
          {pending ? <p className="text-[13px] text-ink-2">L&apos;assistant prépare sa réponse…</p> : null}
          {exchange?.reply && !pending ? (
            <>
              <MessageView companyId={companyId} message={exchange.reply} onFollowup={ask} compact onConfirmed={(m) => setExchange((x) => (x ? { ...x, reply: m } : x))} />
              <Link href={`/app/${companyId}/assistant?c=${conversationId}`} className="inline-flex items-center gap-1 text-[12.5px] font-medium text-accent hover:underline">
                Ouvrir la conversation complète
                <ArrowRight size={12} />
              </Link>
            </>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
