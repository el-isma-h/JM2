"use client";

import * as React from "react";
import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/field";
import { Notice } from "@/components/ui/surface";
import { sendAssistantMessageAction } from "@/server/actions/assistant";
import { SUGGESTIONS } from "@/server/assistant/intents";
import { MessageView, type ChatMessage } from "./message-view";
import type { ActionState } from "@/server/actions/auth";

/** Conversation complète avec historique. */
export function AssistantChat({ companyId, conversationId, initial }: { companyId: string; conversationId: string | null; initial: ChatMessage[] }) {
  const router = useRouter();
  const [messages, setMessages] = React.useState<ChatMessage[]>(initial);
  const [text, setText] = React.useState("");
  const [convId, setConvId] = React.useState(conversationId ?? "");
  const formRef = React.useRef<HTMLFormElement>(null);
  const endRef = React.useRef<HTMLDivElement>(null);

  const [state, action, pending] = useActionState(async (prev: ActionState, fd: FormData) => {
    const res = await sendAssistantMessageAction(prev, fd);
    if (res.ok && res.data?.message) {
      const reply = JSON.parse(res.data.message) as ChatMessage;
      setMessages((m) => [...m, reply]);
      if (!fd.get("conversationId")) {
        setConvId(res.data.conversationId);
        router.replace(`/app/${companyId}/assistant?c=${res.data.conversationId}`, { scroll: false });
      }
    }
    return res;
  }, {});

  React.useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, pending]);

  const submit = (q: string) => {
    const t = q.trim();
    if (!t || pending) return;
    setMessages((m) => [...m, { id: `local-${Date.now()}`, role: "user", content: t, meta: {}, createdAt: new Date().toISOString() }]);
    const fd = new FormData();
    fd.set("companyId", companyId);
    fd.set("conversationId", convId);
    fd.set("text", t);
    React.startTransition(() => action(fd));
    setText("");
  };

  return (
    <div className="flex min-h-[60dvh] flex-col">
      <div className="flex-1 space-y-6 px-5 py-5" aria-live="polite">
        {messages.length ? (
          messages.map((m) => <MessageView key={m.id} companyId={companyId} message={m} onFollowup={submit} onConfirmed={(r) => setMessages((x) => [...x, r])} />)
        ) : (
          <div className="space-y-3">
            <p className="text-[13.5px] text-ink-2">Posez une question ou choisissez une suggestion. L&apos;assistant propose un plan, demande votre confirmation avant toute écriture et ne révèle que ce que vos habilitations permettent.</p>
            <div className="flex flex-wrap gap-2">
              {SUGGESTIONS.map((s) => (
                <button key={s} type="button" onClick={() => submit(s)} className="rounded-none border border-line-strong px-3 py-1 text-[12.5px] text-ink-2 transition-colors hover:border-accent hover:text-ink">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
        {pending ? <p className="text-[13px] text-ink-2">L&apos;assistant prépare sa réponse…</p> : null}
        {state.error ? <Notice tone="danger">{state.error}</Notice> : null}
        <div ref={endRef} />
      </div>
      <form
        ref={formRef}
        onSubmit={(e) => {
          e.preventDefault();
          submit(text);
        }}
        className="sticky bottom-0 flex items-end gap-2 border-t border-line bg-bg-elev px-5 py-3"
      >
        <label htmlFor="assistant-input" className="sr-only">
          Votre demande
        </label>
        <Textarea
          id="assistant-input"
          rows={2}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              formRef.current?.requestSubmit();
            }
          }}
          placeholder="Votre demande (Entrée pour envoyer, Maj + Entrée pour aller à la ligne)"
          maxLength={2000}
          className="min-h-0 resize-none"
        />
        <Button type="submit" loading={pending} disabled={!text.trim()}>
          Envoyer
        </Button>
      </form>
    </div>
  );
}
