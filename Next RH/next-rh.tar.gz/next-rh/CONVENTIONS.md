# Next RH : conventions de développement

Lis ce fichier en entier avant d'écrire du code. Il décrit le socle déjà en place et les règles que chaque module respecte.

## Stack
- Next.js 16 (App Router, `src/`), React 19, TypeScript strict. Lis `node_modules/next/dist/docs/01-app/` en cas de doute (API différentes de ta mémoire : `proxy.ts` au lieu de middleware, `params`/`searchParams` sont des Promises, `cacheComponents` désactivé).
- Tailwind v4 (tokens dans `src/app/globals.css` : `bg`, `bg-elev`, `bg-sunken`, `bg-muted`, `ink`, `ink-2`, `ink-3`, `line`, `line-strong`, `accent`, `accent-soft`, `accent-strong`, `warn*`, `danger*`, `ok*`, `info*`). Classe `.num` pour tout nombre/montant (mono tabulaire).
- Drizzle ORM + PostgreSQL. Schéma complet dans `src/db/schema/*.ts` ; client `db` et `schema` depuis `@/db`. **Ne modifie pas le schéma sans nécessité** ; si tu ajoutes une table ou colonne, mets-la dans le bon fichier, puis `npx drizzle-kit generate --name <nom>` et `npx drizzle-kit migrate` (base locale : `postgresql://nextrh:nextrh@localhost:5432/nextrh`, PostgreSQL tourne déjà).
- Montants en **centimes entiers** (`*_cents`), taux en `numeric` string. Dates `date` en ISO `YYYY-MM-DD`, `timestamp` en UTC.
- Animations : `motion/react` (Framer Motion). Helpers dans `src/components/ui/motion.tsx` (`FadeIn`, `Stagger`, `CountUp`). Respecter `prefers-reduced-motion` (déjà géré par les helpers).
- Icônes : `@phosphor-icons/react` uniquement.

## Authentification et autorisations (déjà en place, à utiliser, ne pas réécrire)
- `getCurrentUser()` / `requireUser()` dans `src/server/auth.ts`.
- Dans une **page serveur** d'entreprise : `const ctx = await guardCompany(companyId, "/app/<companyId>/<route>", "permission")` (`src/server/guard.ts`). `ctx` contient `user`, `company`, `tenant`, `role`, `permissions: Set<Permission>`, `employeeId`.
- Dans une **server action** : `const ctx = await requireCompany(companyId, "permission")` dans un `try`, et en cas d'erreur `return { error: authErrorMessage(e) ?? "Erreur" }`.
- Permissions (`src/server/authz.ts`) : `company.manage`, `members.manage`, `employees.read`, `employees.write`, `employees.bank.read` (sensible), `salaries.read`, `payroll.prepare`, `payroll.validate`, `payroll.close` (sensible), `filings.send` (sensible), `documents.read`, `documents.write`, `requests.approve`, `reports.read`, `self.read`. Les permissions sensibles exigent une session renforcée (TOTP récent) : `guardCompany` redirige vers `/securite?next=` automatiquement.
- Admin plateforme : `guardAdmin("/admin/...")`.
- **Isolation stricte** : chaque requête filtre par `companyId` (ou par `employeeId` appartenant à la bonne entreprise). Jamais de requête sans ce filtre. Les salariés (`role === "employee"`) ne passent que par `/moi`.
- **Audit** : toute écriture ou lecture sensible appelle `audit({ action: "domaine.verbe", userId, companyId, entityType, entityId, before, after })` (`src/server/audit.ts`). Exemples : `employee.create`, `payroll.validate`, `bank.view`.

## Server actions et formulaires
- Fichiers dans `src/server/actions/<domaine>.ts` avec `"use server"` en tête. Signature : `(prev: ActionState, formData: FormData) => Promise<ActionState>` avec `ActionState = { error?, ok?, message?, data? }` (exporté depuis `src/server/actions/auth.ts`). Valider avec `zod`.
- Côté client : `useActionState` ; composants UI : `Button`, `Input`, `Select`, `Textarea`, `Field`, `Checkbox`, `Badge`/`StatusBadge`, `Panel`/`PanelHeader`/`PageHeader`/`EmptyState`/`Notice`/`Stat`/`KeyValue`, `Table`/`Th`/`Td`, `Dialog` (`src/components/ui/*`). Réutilise-les ; n'invente pas de nouveaux styles de bouton ou de champ.
- Après mutation : `revalidatePath(...)`.
- Chaque bouton déclenche une action réelle ou affiche précisément la configuration manquante (`integrations` et `integrationLabels` dans `src/lib/env.ts`).

## Documents et fichiers
- `createDocument({...})` dans `src/server/documents/store.ts` : stocke le fichier (disque privé `./storage`) et crée la ligne `documents`. Téléchargement uniquement via `issueDownloadLink(documentId, userId)` (lien temporaire `/telechargement/[token]`). Jamais de fichier dans `/public`.
- PDF : `pdfkit` (déjà installé, `serverExternalPackages`). DOCX : package `docx`.

## E-mails et tâches
- `sendMail({ to, subject, html, text, isDemo })` dans `src/server/mail.ts` + `layoutMail(title, bodyHtml, cta)`. Toujours passer `isDemo: company.isDemo` : en démo rien ne part jamais.
- Tâches de fond : insérer dans `schema.jobs` ; un runner simple sera dans `src/server/jobs/runner.ts` (équipe E).

## Démonstration
- Tenant/entreprise avec `isDemo = true`. Les pages affichent le badge « Démo ». Aucune déclaration, paiement ou e-mail réel ne doit partir : vérifier `company.isDemo` avant tout envoi et le dire à l'utilisateur.

## Design (règles non négociables)
- Identité : celle de NEXT Capital (même maison), avec le **rouge bordeaux** comme signal à la place du vert. Fond os #F3F0E8, encre #0A0B0D, angles droits (radius 0), bordures 1 px, titres Archivo fins en capitales espacées (automatique sur h1/h2/h3), étiquettes JetBrains Mono (`.etiquette`), corps Inter, citations Cormorant Garamond italique (`.font-serif`). Boutons en capitales espacées. Un seul accent. Pas de cards imbriquées, pas de dégradés sur texte, pas d'icônes faites main.
- **Aucun tiret cadratin (—) ni demi-cadratin (–) dans l'interface** : utiliser « : », « , », un point, ou le trait d'union `-`.
- Libellés en français clair, compréhensibles par quelqu'un qui n'est pas spécialiste de la paie. Aide contextuelle (`Field help=`). États vides utiles (`EmptyState` avec action). Confirmation explicite (Dialog) pour les opérations sensibles (validation de paie, suppression, envoi).
- Tableaux : `Table` avec `th`/`td` ; montants à droite en `.num`. Pas de `<ul>` pour des listes longues.
- Données de démo : noms français réalistes (pas de « Jean Dupont »), chiffres organiques (pas 50 % ni 1000,00).

## Qualité
- `npx tsc --noEmit` doit passer sans erreur avant de rendre la main. `npm run lint` idem (corrige ce que tu as écrit).
- Tests unitaires avec `vitest` dans `src/**/__tests__/*.test.ts` ou `tests/`. Commande : `npx vitest run`.
- Ne touche pas aux fichiers hors de ton périmètre, sauf `src/db/schema/*` pour une colonne manquante (signale-le dans ton rapport final).

## Routes
- Entreprise : `/app/[companyId]/...` (layout et navigation déjà en place : `src/components/app/nav.ts`). Pages à créer sous `src/app/app/[companyId]/<route>/page.tsx`.
- Espace salarié : `/moi/...` (layout à créer par l'équipe C avec `AppShell` et `employeeNav`).
- Cabinet : `/app/entreprises/...` (layout en place).
- Admin : `/admin/...` (layout à créer par l'équipe E avec `AppShell` et `adminNav`).
