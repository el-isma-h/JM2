# Tableau tarifaire sourcé — Next RH vs référence

Source unique : https://www.lucca.fr/tarifs/ — consultée le 2026-10-20.
Conditions de la référence (telles qu'affichées) : prix indicatifs pour les entreprises de 100 salariés et plus, HT,
coût unitaire dégressif, décompte mensuel des utilisateurs, facturation à la consommation réelle, sans durée
d'engagement, consultant de déploiement inclus, support jours ouvrés 9h–17h. Aucun frais de mise en service,
minimum de facturation ou pack affiché. Devis sur mesure : contacter le commercial.

Règle : Next RH = référence × 0,90, **tronqué au centime inférieur** (jamais arrondi au-dessus, pour ne jamais
réduire la remise annoncée). Même unité, même périmètre.

| Module Next RH | Comparable référence | Prix référence | × 0,90 | Prix Next RH | Unité |
| --- | --- | ---: | ---: | ---: | --- |
| Congés et absences | Absences | 3,11 € | 2,799 | **2,79 €** | / salarié / mois |
| Temps de travail | Feuilles de temps | 3,00 € | 2,700 | **2,70 €** | / salarié / mois |
| Télétravail | Office | 2,24 € | 2,016 | **2,01 €** | / salarié / mois |
| Dossiers salariés | Socle RH | 3,21 € | 2,889 | **2,88 €** | / salarié / mois |
| Entretiens | Performance | 3,97 € | 3,573 | **3,57 €** | / salarié / mois |
| Engagement | Engagement | 3,16 € | 2,844 | **2,84 €** | / salarié / mois |
| Formations | Formation | 3,21 € | 2,889 | **2,88 €** | / salarié / mois |
| Recrutement | Recrutement | 3,21 € | 2,889 | **2,88 €** | / salarié / mois |
| Notes de frais | Frais professionnels | 5,81 € | 5,229 | **5,22 €** | / déclarant / mois |
| Factures fournisseurs | Factures (600–799 factures) | 0,91 € | 0,819 | **0,81 €** | / facture |
| Variables de rémunération | Rémunération | 1,78 € | 1,602 | **1,60 €** | / salarié / mois |
| Distribution des bulletins | Bulletins de paie | 0,70 € | 0,630 | **0,63 €** | / document distribué |
| Avantages | Avantages | 1,02 € | 0,918 | **0,91 €** | / salarié / mois |
| Préparation de paie | Assistant Paie (connecteurs) | 0,61 € | 0,549 | **0,54 €** | / salarié / mois |
| **Production de paie (moteur)** | aucun équivalent public (la référence délègue à Silae/Cegid…) | — | — | **Sur devis** | comparaison à faire sur devis réel |
| Déclarations (DSN) | aucun équivalent public | — | — | **Sur devis** | idem |

Inclus sans surcoût chez la référence, donc inclus sans surcoût chez Next RH : moyens de paiement, SSO,
synchronisation agenda, documents partagés, tableaux de bord, export paie.

Services d'accompagnement humain (séparés des fonctions incluses) : reprise de données assistée, paramétrage
convention collective, formation — **Sur devis** (la référence inclut un consultant de déploiement ; Next RH
remplace ce service par l'onboarding guidé et facture l'accompagnement optionnel séparément).

Ces montants sont chargés en base (table `PricingPlan`) et administrables depuis le dashboard admin, avec la source et
la date pour chaque ligne.
