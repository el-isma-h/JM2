# Recon map : Lucca (web SaaS, lucca.fr)

Scope : périmètre RH + préparation de paie de la référence, étendu à la **production de paie** (que la référence ne fait pas elle-même).
For : Next RH — entreprises françaises et cabinets gérant plusieurs entreprises.
Date de consultation : 2026-10-20
Méthode : pages publiques uniquement (clean-room). Aucun bundle JS, aucun appel réseau, aucun compte tiers.

## Sources

| # | source | URL | notes |
| --- | --- | --- | --- |
| 1 | page d'accueil | https://www.lucca.fr/ | 15 modules, positionnement « SIRH modulaire » |
| 2 | tarifs | https://www.lucca.fr/tarifs/ | prix publics indicatifs « entreprises de 100+ salariés », HT, dégressifs, sans engagement |
| 3 | suite initiale paie | https://www.lucca.fr/suite/suite-initiale-paie | pack petites entreprises : Absences + Socle RH + Rémunération + Assistant Paie |
| 4 | Socle RH | https://www.lucca.fr/gestion-rh/administration | dossier salarié, cycle de vie, documents, e-signature (Signaturit/Skribble), DPAE |
| 5 | Assistant Paie | https://www.lucca.fr/lucca-paie | collecte → contrôle → validation par étape → export Silae/Yeap (API) ou fichiers Cegid/Sage/ADP… |
| 6 | Absences | https://www.lucca.fr/conges-et-absences/ | CP/RTT/CET, fractionnement, planning, justificatifs, reporting |
| 7 | experts-comptables | https://www.lucca.fr/partenaires/devenir-partenaire/expert-comptable | portail multi-clients, calendrier de paie partagé, tâches |
| 8 | Lucca IA | https://www.lucca.fr/lucca-ia | « Ask Lucca » : réponses salariés, prépa entretiens, contrôles RH ; activable par le client |
| 9 | support | https://support.luccasoftware.com/s/?language=fr | centre d'aide public (non parcouru en détail) |
| 10 | roadmap | https://www.lucca.fr/roadmap | mises à jour produit |
| 11 | marketplace | https://marketplace.luccasoftware.com/fr/ | 300+ intégrations (réseau partenaires : hors périmètre) |

## Constat déterminant

La référence **ne produit pas de bulletins** : elle collecte, contrôle et exporte vers un logiciel de paie tiers (Silae en priorité).
Elle ne mentionne ni DSN, ni virements, ni moteur de calcul. Next RH couvre ce périmètre en plus ; les tarifs de ce
périmètre n'ont donc pas d'équivalent public chez la référence (voir `pricing.md`).

## Core loop

Un gestionnaire RH centralise les salariés et leurs événements du mois, contrôle les variables, valide, et la paie est
produite — chez la référence, par un tiers ; chez Next RH, par le moteur interne.

## Screens

| ID | screen | route / accès | purpose | key components | states seen |
| --- | --- | --- | --- | --- | --- |
| S01 | Accueil marketing | / | positionnement, modules, logos clients | hero, grille modules, CTA démo | — |
| S02 | Tarifs | /tarifs | prix par module, inclus, modalités | tableau tarifs, footnotes | — |
| S03 | Connexion | /login | accès espace | formulaire, SSO | erreur |
| S04 | Demande de démo | contact.luccasoftware.com/… | pas d'inscription self-service : démo commerciale | formulaire | — |
| S05 | Dashboard RH | (déduit) | indicateurs, tâches de paie, alertes échéances | KPI, calendrier de paie, to-do | vide, rempli |
| S06 | Dossier salarié | (déduit) | fiche unique, champs configurables, historique de carrière | onglets, champs, timeline | vide, rempli |
| S07 | Annuaire / trombinoscope / organigramme | (déduit) | | grille, arbre | — |
| S08 | Absences — planning équipe | (déduit) | demandes, validation 1 clic, soldes | calendrier, badges | — |
| S09 | Absences — demande | web + mobile | choix type, répartition proposée selon soldes | formulaire, picker dates | erreur contrôle politique |
| S10 | Rémunération — variables | (déduit) | primes, commissions, TR, historique | tableau éditable | — |
| S11 | Assistant Paie — préparation | (déduit) | collecte, contrôle, validation par étape, envoi | stepper, tableau, tâches | validé / en attente |
| S12 | Bulletins — distribution | « votre espace » | mise à disposition des bulletins | liste documents | — |
| S13 | Documents — génération | (déduit) | sélection salariés → modèle → pré-remplissage → relecture → e-signature | wizard 5 étapes | — |
| S14 | Cycle de vie — onboarding/offboarding | (déduit) | formulaires e-mail, tâches IT/manager, DPAE | checklist, formulaires | — |
| S15 | Frais professionnels | (déduit) | notes de frais, factures, moyens de paiement | liste, justificatif | — |
| S16 | Portail cabinet multi-clients | (déduit) | accès aux SIRH des clients, calendrier partagé, tâches | liste dossiers, calendrier | — |
| S17 | Ask Lucca (IA) | (déduit) | questions salariés / managers / RH | chat | — |
| S18 | Reporting | (déduit) | absentéisme, provisions CP, BDESE, bilan social | exports | — |

## Flows

```
F01 Préparer la paie du mois (RH)
    S05 -> S11 (collecte) -> S10 (variables) -> S08 (absences période) -> S11 (contrôle, validation étape) -> export
    happy path clicks : ~8
    edge : variable manquante, absence à régulariser, salarié entré/sorti en cours de mois

F02 Demander un congé (salarié)
    S09 -> validation manager (e-mail / planning) -> solde mis à jour -> export paie
    clicks : 4
    edge : solde insuffisant, justificatif requis, politique refusée

F03 Intégrer un salarié (RH)
    S14 formulaire -> S06 dossier créé -> S13 contrat généré -> e-signature -> DPAE -> tâches IT/manager
    edge : données manquantes, signature refusée

F04 Générer un document (RH)
    S13 : sélection -> modèle -> pré-remplissage -> relecture -> classement -> e-signature
    edge : champ vide dans le dossier

F05 Cabinet : contrôler les dossiers clients
    S16 -> S11 par dossier -> export Silae
    edge : tâche automatique créée par un changement de période

F06 Démarrer (prospect)
    S01 -> S04 demande de démo -> déploiement par consultant
    (pas de self-service : Next RH ajoute « Créer mon compte » + « Explorer la démonstration »)
```

## Components

| component | variants | states | used on |
| --- | --- | --- | --- |
| Tableau de données | tri, filtres, sélection groupée, export | vide, chargement, erreur | S06 S10 S11 S15 S16 S18 |
| Stepper / wizard | horizontal, avec sauvegarde | étape active, validée, bloquée | S11 S13 S14 |
| Fiche à onglets | | | S06 |
| Calendrier / planning | équipe, paie | | S08 S16 |
| Badge statut | en attente, validé, refusé, anomalie | | partout |
| Carte KPI | | | S05 |
| Timeline historique | | | S06 |
| Formulaire avec aide contextuelle | | validation à la saisie | S09 S14 |
| Chat assistant | | | S17 |

## Inferred data model

```
Tenant (cabinet ou groupe)   id, name, kind (company|firm)                 evidence: S16   confidence: high
Company                      id, tenant_id, legal_name, siren, nic, ape, idcc, address   evidence: S06 S14   confidence: high
Establishment                id, company_id, siret, address                evidence: S06   confidence: medium
User                         id, email, role (admin|hr|manager|employee|accountant)   evidence: rôles cités S04 S05   confidence: high
Employee                     id, company_id, establishment_id, identity, contact, bank (restricted), custom fields   evidence: S06   confidence: high
Contract                     id, employee_id, type, start, end, classification, working_time, salary   evidence: S06 S13   confidence: high
CareerEvent                  id, employee_id, date, kind (promotion|mobility|…)   evidence: S06   confidence: high
LeaveType / LeaveBalance / LeaveRequest   evidence: S08 S09   confidence: high
PayVariable                  id, employee_id, period, kind (prime|commission|TR|…), amount   evidence: S10   confidence: high
PayrollPeriod                id, company_id, month, status (open|collecting|checking|validated|exported|closed)   evidence: S11   confidence: high
PayrollTask                  id, period_id, source (auto|manual), done   evidence: S07 S16   confidence: medium
Document / DocumentTemplate / Signature   evidence: S13   confidence: high
Expense / Invoice            evidence: S15   confidence: medium
LifecycleWorkflow / Task     evidence: S14   confidence: medium
AuditLog                     (déduit des exigences de traçabilité)   confidence: medium
```

## Ce qui ne peut pas être cloné (skip)

- Le réseau de 300+ intégrations marketplace et les partenariats éditeurs (Silae, Signaturit, Skribble) : contrats tiers.
- La base clients et logos.
- Le support humain / consultant dédié au déploiement : service, pas fonctionnalité (Next RH le remplace par l'onboarding guidé).

## Size

Screens 18+, flows 6 principaux, entités ~20. Parties dures : moteur de paie déterministe (nouveau par rapport à la
référence), multi-tenant avec isolation stricte, imports avec reprise de cumuls, génération documents PDF/DOCX,
assistant IA sous permissions. **Taille : XL** — livré en une passe, avec un périmètre de paie explicitement délimité.

Prochaine étape : `/replica-architect`.
