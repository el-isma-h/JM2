# Next RH

La paie, les ressources humaines et vos documents réunis dans une seule plateforme. Pour les entreprises françaises et les cabinets qui en gèrent plusieurs.

Application Next.js 16 + PostgreSQL, multi-entreprise, avec un moteur de paie déterministe et versionné, un onboarding guidé, les modules RH, un atelier de rédaction, un assistant sous permissions, un espace salarié, une vue cabinet et un dashboard d'administration.

## Démarrage en 5 minutes

Prérequis : Node.js 22 ou plus, PostgreSQL 16 (ou Docker).

```bash
cp .env.example .env            # puis renseigner APP_SECRET (openssl rand -hex 32) et DATABASE_URL
npm install
npm run setup                   # migrations, admin plateforme, tarifs, modèles, règles de paie, registre
npm run dev                     # http://localhost:3000
```

Avec Docker : `docker compose up` (app + PostgreSQL + tâches planifiées), puis `docker compose exec app npm run setup`.

Comptes après `npm run setup` :
- Administrateur plateforme : `ADMIN_EMAIL` / `ADMIN_PASSWORD` du `.env` (par défaut `admin@nextrh.local` / `ChangeMoi!2026`, à changer). Dashboard : `/admin`.
- Démonstration : `/demo` crée un espace fictif neuf à chaque visite (gestionnaire ou salarié), supprimé après 24 h.

Sans clé e-mail (`RESEND_API_KEY`), les e-mails ne partent pas : ils sont journalisés dans Admin → Boîte d'envoi, où l'on copie le lien de vérification ou de réinitialisation. C'est le mode de développement.

## Commandes

| Commande | Rôle |
| --- | --- |
| `npm run dev` / `npm run build` / `npm start` | développement, compilation, production |
| `npm run setup` | installation idempotente (migrations + données de base) |
| `npm run db:generate` / `npm run db:migrate` | migrations Drizzle après modification de `src/db/schema` |
| `npm test` | 161 tests unitaires (moteur de paie, exports, validateurs, imports, RH, documents, assistant, tarifs) |
| `npx tsx --conditions=react-server src/scripts/backup-roundtrip.ts` | vérification sauvegarde → restauration |
| `curl -H "x-cron-secret: $CRON_SECRET" localhost:3000/api/cron` | exécute les tâches de fond (appelé toutes les minutes par le service cron Docker) |

## Variables d'environnement

Voir `.env.example`. Obligatoires : `DATABASE_URL`, `APP_SECRET` (chiffre NIR, IBAN et secrets TOTP ; le perdre rend ces données illisibles), `APP_URL`. Optionnelles, chacune avec un mode « non configuré » explicite dans l'interface : `RESEND_API_KEY` (e-mails), `ANTHROPIC_API_KEY` (assistant en langage libre et reformulation), `S3_*` (stockage ; sinon disque privé `STORAGE_DIR`), `ESIGN_*` (signature électronique), `CRON_SECRET`.

## Périmètre métier réellement couvert

### Paie (moteur `src/server/payroll/engine`, règles `src/server/payroll/rules/*.json`)
Les montants ne sont jamais calculés par un modèle de langage. Le moteur est pur, déterministe et reproductible : chaque bulletin conserve ses entrées, la version des règles et une empreinte de calcul. Les règles 2026 (SMIC, PMSS, cotisations, réduction générale, barème neutre du PAS…) sont datées, sourcées (URSSAF, Légifrance, BOSS, BOFiP, Agirc-Arrco) et chargées en base (`payroll_rule_sets`). Trois versions : `fr-2026.01`, `fr-2026.05`, `fr-2026.06`.

Couvert : CDI/CDD, cadres et non-cadres, temps plein et partiel, forfait 218 jours, primes, heures supplémentaires et complémentaires, congé sans solde, congés payés et RTT maintenus, entrée/sortie en cours de mois, avantages en nature, titres-restaurant, frais et acomptes, mutuelle et prévoyance, réduction générale 2026, PAS personnalisé ou neutre. Régime général, métropole.

Bloqué avec explication (bulletin au statut « bloqué », finalisation impossible) : arrêts maladie, AT/MP, maternité, apprentis, stagiaires, intérim, mandataires, forfaits particuliers, horaire > 35 h, Alsace-Moselle, outre-mer, saisies sur salaire, indemnités de rupture, changement de salaire en cours de mois. Les dispositions de convention collective ne sont pas appliquées automatiquement : un point « à vérifier » est créé à chaque période. La liste complète est affichée dans l'application (page de période) et dans `src/server/payroll/scope.ts`.

Cycle mensuel en 10 étapes : ouvrir, collecter, vérifier, calculer, contrôler les anomalies, valider, finaliser (PDF), préparer exports et déclarations, distribuer, clôturer. Écarts avec le mois précédent expliqués. Validation refusée tant qu'une anomalie bloquante est ouverte.

Déclarations et exports : journal de paie, état des charges, récapitulatif par établissement, écritures comptables, virements SEPA (pain.001), DSN mensuelle préparée (structure NEODeS, contrôles de base). Six statuts distincts : préparé, contrôlé, envoi demandé, envoi effectué, acceptation confirmée, rejet. Aucune transmission réelle n'est implémentée : « envoyé » et « accepté » ne se posent qu'en enregistrant un accusé technique.

### RH, documents, assistant
Onboarding guidé en 8 étapes avec sauvegarde automatique et reprise ; import CSV avec correspondance des colonnes, rapport d'erreurs, doublons et contrôle des cumuls en cours d'année ; dossiers salariés avec historique daté et RIB à accès restreint (double authentification) ; congés, temps, télétravail, frais, arrivées et départs, échéances, entretiens, formations, demandes, annuaire et organigramme, rapports sociaux ; bibliothèque documentaire avec liens temporaires ; atelier de rédaction (20 modèles, dont 10 juridiques avec points à faire valider par un juriste), export PDF et DOCX, versions ; assistant sous permissions (mode règles sans IA, Claude avec outils si configuré), qui délègue toute préparation de paie au moteur et demande confirmation avant d'écrire.

### Multi-entreprise et administration
Tenants entreprise, cabinet ou groupe. Isolation stricte par entreprise côté serveur. Vue cabinet : dossiers, échéances, gestionnaires et invitations par entreprise. Dashboard admin : organisations, utilisateurs, tarifs (règle −10 % tronquée au centime, sources affichées), règles de paie, modèles, boîte d'envoi, tâches, audit, sauvegardes et restauration, registre des traitements, intégrations.

## Identité visuelle
Charte reprise du projet NEXT Capital (fonds os et encre, Archivo, Inter, JetBrains Mono, Cormorant Garamond, angles droits, bordures fines), avec le rouge bordeaux comme couleur signal. Tokens dans `src/app/globals.css`, composants dans `src/components/ui`. Mode sombre (encre) disponible depuis la barre latérale.

## Sécurité et données personnelles
Sessions httpOnly, mots de passe bcrypt, TOTP pour les accès sensibles, NIR/IBAN/secrets chiffrés AES-256-GCM, journal d'audit, stockage privé avec liens temporaires, en-têtes de sécurité (`src/proxy.ts`), minimisation des données envoyées à l'IA, aucune réutilisation des données RH pour l'entraînement. Détails : `docs/donnees-personnelles.md`. Sauvegardes : `docs/sauvegarde.md`.

## Tarifs
Tableau sourcé dans `replica/pricing.md` (référence publique consultée le 2026-10-20, règle × 0,90 tronquée au centime). Administrable dans `/admin/tarifs`. Les modules sans équivalent public (production de paie, DSN) et les services d'accompagnement sont « Sur devis ».

## Vérifications effectuées
- `npm test` : 161 tests passés (les montants attendus du moteur sont calculés à la main dans les tests, avec la source de chaque taux).
- `npx tsc --noEmit`, `npm run lint`, `npm run build` : sans erreur.
- Parcours navigateur (Playwright) : 68 contrôles passés, dont inscription → vérification e-mail → onboarding, mot de passe oublié, démo gestionnaire (18 écrans, 3 périodes de paie, 14 bulletins), démo salarié, isolation entre entreprises et entre rôles, dashboard admin complet.
- Sauvegarde puis restauration d'un tenant : 182 lignes sur 42 tables à l'identique, identifiants remappés, empreinte vérifiée.
- Score de parité fonctionnelle avec la référence (`replica/features.csv`) : 97/100, tous les indispensables couverts.

## Intégrations restant à configurer
E-mail (Resend), IA (Anthropic), stockage S3, signature électronique (adaptateur prêt dans `src/server/documents/esign.ts`), transmission DSN (net-entreprises, non implémentée), connecteurs comptables tiers, SSO.

## Limites nécessitant une validation métier
- Paie : plafond de sécurité sociale appliqué mois par mois sans régularisation annuelle ; prévoyance à taux unique sur le brut ; les cas « bloqués » ci-dessus ; codes DSN partiels à confronter au cahier technique ; conventions collectives à contrôler manuellement. Faire valider les premiers bulletins par un expert-comptable avant toute utilisation réelle.
- Documents : les 10 modèles juridiques citent leurs articles (code du travail) mais doivent être relus par un juriste avant signature.
- Les durées de conservation sont celles du référentiel CNIL RH ; la purge automatique à échéance n'est pas implémentée (point d'extension dans les tâches de fond).
- Les suggestions SIREN depuis l'API Recherche d'entreprises dépendent de l'accès réseau du serveur.

## Structure
```
src/app            pages (auth, app/[companyId], moi, app/entreprises, admin, demo)
src/server         logique métier : auth, authz, payroll, hr, onboarding, employees, documents, assistant, pricing, jobs, backup, demo
src/db/schema      51 tables Drizzle (tenancy, auth, employees, payroll, hr, documents, platform)
src/components     ui (design system), app (shell), modules
replica/           recon de la référence, matrice de fonctionnalités, tableau tarifaire sourcé
docs/              données personnelles, sauvegarde
```
