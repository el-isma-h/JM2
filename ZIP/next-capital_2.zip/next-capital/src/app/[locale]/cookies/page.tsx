import { pageLocale } from "@/lib/locale";
import { PageEnTete, Section } from "@/components/Sections";

export default async function Cookies({ params }: { params: Promise<{ locale: string }> }) {
  const { t } = await pageLocale(params);
  return (
    <>
      <PageEnTete titre={t.legal.cookiesTitre} />
      <Section><p className="mx-auto max-w-3xl text-lg leading-relaxed text-encre/85">{t.legal.cookiesTexte}</p></Section>
    </>
  );
}
