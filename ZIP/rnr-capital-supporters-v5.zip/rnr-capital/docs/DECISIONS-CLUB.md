# Accords, contrats, intégrations et décisions encore nécessaires

Rien de ce qui suit n'est acquis. Tant qu'un point n'est pas réglé, la plateforme l'affiche comme hypothèse, « à valider », « envisagé » ou « non inclus ».

## A. Accords et autorisations du club (SAS Rouen Normandie Rugby)

1. Accord de principe sur l'opération et sur la présentation de la plateforme comme officielle.
2. Droit d'usage du nom, du logo et des photographies du club. **Depuis la v4, le logo officiel (tête de lion) et cinq photos du site du club sont intégrés à la démonstration** (voir `public/images/CREDITS.md`) : ils doivent être retirés ou autorisés par écrit avant toute mise en ligne publique.
3. Validation de tout texte sur la situation du club : besoin de trésorerie, objectifs, utilisation des fonds.
4. Validation des objectifs de saison affichés et de la règle de promotion en Pro D2 (à vérifier auprès de la FFR / LNR pour 2026-2027).

## B. Montage financier et juridique

5. Choix du montage : augmentation de capital de la SAS **ou** véhicule d'investissement de supporters (holding). Ce que l'investisseur détient réellement en dépend.
6. Décision d'augmentation de capital : nombre d'actions, prix de souscription (hypothèse : 100 €), valeur nominale, calendrier (hypothèse : 16/11/2026 – 28/02/2027), objectif (hypothèse : 500 000 €), plafond par personne.
7. Capital social et dilution, pour pouvoir afficher un pourcentage de détention.
8. Droits attachés : vote, dividendes, restrictions de cession, modalités de sortie (documents approuvés).
9. Cadre réglementaire de l'offre au public et prestataire habilité (financement participatif / PSFP ou autre selon le montage) ; frais de l'opération.
10. Note d'information sur les risques, bulletin de souscription, conditions de souscription.
11. Budget validé : collecte brute, frais, coût des avantages, coût des lots, net pour le club, fréquence des comptes rendus.

## C. Statuts et avantages

12. Approbation et budget de la grille (cinq statuts). Pour chaque avantage : confirmé / en négociation / envisagé, durée, quantité, capacité, nominatif ou transférable, renouvellement.
13. Périmètre exact de l'abonnement Lions Privilège : tribune, inclusion ou non des phases finales, matchs de coupe, rencontres amicales, matchs délocalisés ; plafond de places.
14. Avantages boutique et partenaires : accords avec la boutique et les entreprises concernées.
15. Cercle business : articulation avec le Business Club existant du club.
16. Avantage Olympique de Marseille : contrat, droit de distribution, volume de places, stade, compétitions, saison, exclusions — **ou** alternative rugby. Aucune affiliation ni logo OM sans autorisation.

## D. Concours gratuit de pronostics

17. Validation juridique du règlement et de la qualification du dispositif (concours gratuit sans obligation d'achat) avant toute activation avec des lots.
18. Définition du score retenu (hypothèse : temps réglementaire, prolongations exclues), critère subsidiaire de départage (hypothèse : inscription la plus ancienne), règles de participation en cours de saison, reports et annulations.
19. Source officielle des résultats et circuit de vérification.
20. Mesures anti-comptes multiples et conditions de remise des lots.

## E. Lots et partenaires

21. Lot principal CUPRA : partenaire contractuel, modèle, version, neuf / occasion, kilométrage, valeur documentée, propriété, immatriculation / livraison / frais, conditions de remise, date, documents. Sinon, retirer le lot. CUPRA n'est pas sponsor du club.
22. Lots secondaires : fournisseur, quantité, valeur, contrat, conditions de remise pour chacun.
23. Partenaires de l'opération : aucun n'est confirmé. Les partenaires du club relevés sur son site ne sont que des prospects potentiels.

## F. Intégrations techniques

24. Prestataire de souscription (API, webhook, séquestre). Stripe n'est présent qu'en mode test pour la démonstration et doit être désactivé pour l'opération réelle.
24 bis. Modèles 3D : **depuis la v5, la CUPRA Formentor affichée est le modèle 3D fourni par le porteur du projet** (`public/models/cupra-formentor.glb`, voir `public/models/CREDITS.md`) ; son droit d'usage (licence du fichier, marque CUPRA) doit être vérifié et validé par le partenaire avant toute mise en ligne publique, et le modèle remplacé par celui du partenaire si celui-ci l'exige. Les lots secondaires restent des objets stylisés sans marque, à remplacer par les modèles des fournisseurs une fois les contrats signés.
25. Base de données de production et journal d'audit en ajout seul.
26. Deuxième facteur administrateur (TOTP / passkeys), rôles distincts.
27. E-mails transactionnels (Resend ou autre).
28. Source de résultats (API) ou procédure de double validation.
29. Hébergement, nom de domaine, HTTPS, sauvegardes.
30. Mentions légales, politique de confidentialité, registre RGPD, DPO.

## G. Points signalés par le constructeur de la plateforme

- Un concours doté de lots réservé aux acheteurs d'actions risquerait une qualification en jeu d'argent : le concours est donc gratuit et indépendant de l'investissement.
- Une action achetée 100 € ne peut pas être présentée comme valant 150 € selon le classement : aucune valorisation n'est affichée sans évaluation documentée, et la plateforme ne relie jamais performance sportive et valeur.
- Une simple revente d'actions existantes ne finance pas la trésorerie du club : la plateforme suppose une augmentation de capital ou un montage validé.
