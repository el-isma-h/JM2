import type { Metadata } from "next";
import { lotPrincipal, statutContractuelLabel } from "@/data/lots";
import { liensOfficiels } from "@/config/campagne";
import { Section, Titre, Encart, Badge, teinteEtat } from "@/components/ui";
import { VoitureLot } from "@/components/VoitureLot";
import { PodiumLotsClient } from "@/components/PodiumLotsClient";
import { Apparition } from "@/components/Apparition";
import { FondPhoto } from "@/components/FondPhoto";
import { lireDb } from "@/lib/store";

export const metadata: Metadata = { title: "Lots et partenaires" };
export const dynamic = "force-dynamic";

const champsVehicule: [string, string][] = [
  ["Partenaire contractuel", "partenaireContractuel"],
  ["Modèle", "modele"],
  ["Version", "version"],
  ["État (neuf / occasion)", "etat"],
  ["Kilométrage", "kilometrage"],
  ["Valeur documentée", "valeurDocumentee"],
  ["Propriété du véhicule", "proprieteVehicule"],
  ["Immatriculation, livraison, frais", "immatriculationLivraisonFrais"],
  ["Conditions de remise", "conditionsRemise"],
  ["Date de disponibilité", "dateDisponibilite"],
  ["Documents contractuels", "documentsContractuels"],
];

export default async function Lots() {
  const db = await lireDb();
  const fiche = db.parametres.lotPrincipal;
  const clubs = db.partenaires.filter((p) => p.categorie === "partenaire_club");
  const operation = db.partenaires.filter((p) => p.categorie === "partenaire_operation");
  const prospects = db.partenaires.filter((p) => p.categorie === "prospect");
  return (
    <>
      <section className="section-sombre overflow-hidden text-blanc">
        <FondPhoto src="/images/vip.jpg" opacite={0.7} />
        <div className="relative z-10 mx-auto grid max-w-7xl gap-8 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_1.2fr] lg:items-center">
          <Apparition>
            <Badge teinte="ambre">Lot principal envisagé</Badge>
            <h1 className="mt-4 text-5xl text-blanc sm:text-6xl xl:text-7xl">{lotPrincipal.accroche}</h1>
            <p className="mt-6 inline-block bg-or px-4 py-2 text-sm font-900 uppercase tracking-wider text-ardoise">{lotPrincipal.mentionObligatoire}</p>
            <p className="mt-4 max-w-xl text-blanc/75">CUPRA n&apos;est pas sponsor du club. Un véhicule simplement prêté pour exposition ne peut pas être présenté comme offert au gagnant. Tant que les lots ne sont pas contractuellement sécurisés, le concours fonctionne en démonstration sans promesse de récompense.</p>
            <p className="mt-3 text-xs text-blanc/50">Faites tourner le modèle : glisser pour pivoter. Modèle 3D CUPRA Formentor fourni par le porteur du projet, affiché à titre d&apos;illustration ; le véhicule, sa version et sa finition restent à définir avec le partenaire une fois le contrat signé.</p>
          </Apparition>
          <div className="carte-verre relative h-[22rem] overflow-hidden sm:h-[30rem]">
            <VoitureLot className="h-full w-full" />
          </div>
        </div>
      </section>

      <Section>
        <Titre sur="Fiche du lot principal">Les champs à renseigner avant toute annonce</Titre>
        <dl className="grid gap-px border border-gris-clair bg-ardoise/10 sm:grid-cols-2 lg:grid-cols-3">
          {champsVehicule.map(([k, cle]) => (
            <div key={cle} className="bg-clair-2 p-4">
              <dt className="text-xs uppercase tracking-wider text-gris">{k}</dt>
              <dd className={`mt-1 ${fiche[cle] ? "" : "text-ambre"}`}>{fiche[cle] || "Non renseigné"}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-3 text-xs text-gris">Fiche administrable (onglet Lots de l&apos;administration). Même renseignée, elle reste « envisagée » tant que le club n&apos;active pas les lots.</p>
      </Section>

      <Section className="border-y border-gris-clair bg-clair-2">
        <Titre sur="Catalogue">Les lots à gagner, en 3D</Titre>
        <PodiumLotsClient lots={db.lots} />
        <div className="mt-8 overflow-x-auto border border-gris-clair">
          <table className="w-full text-sm">
            <thead className="bg-clair-2 text-left text-xs uppercase tracking-wider text-gris">
              <tr><th className="px-3 py-2">Rang</th><th className="px-3 py-2">Lot</th><th className="px-3 py-2">Quantité</th><th className="px-3 py-2">Valeur</th><th className="px-3 py-2">Fournisseur</th><th className="px-3 py-2">Statut contractuel</th><th className="px-3 py-2">Remise</th></tr>
            </thead>
            <tbody>
              {db.lots.map((l) => (
                <tr key={l.id} className="border-t border-clair-2 align-top">
                  <td className="display px-3 py-2.5 text-xl font-900 text-rouge">{l.rang}</td>
                  <td className="px-3 py-2.5"><p className="font-600">{l.titre}</p><p className="text-xs text-gris">{l.description}</p></td>
                  <td className="px-3 py-2.5">{l.quantite || "À définir"}</td>
                  <td className="px-3 py-2.5">{l.valeurEstimee ? `${l.valeurEstimee} €` : <span className="text-ambre">Non documentée</span>}</td>
                  <td className="px-3 py-2.5 text-ardoise-2">{l.fournisseur}</td>
                  <td className="px-3 py-2.5"><Badge teinte={teinteEtat(l.statut)}>{statutContractuelLabel[l.statut]}</Badge></td>
                  <td className="px-3 py-2.5 text-ardoise-2">{l.conditionsRemise}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-gris">Aucun don, lot ou participation n&apos;est attribué à une entreprise sans son accord.</p>
      </Section>

      <Section>
        <Titre sur="Partenaires">Trois listes bien distinctes</Titre>
        <div className="grid gap-8 lg:grid-cols-3">
          <div>
            <h3 className="mb-3 text-2xl">Partenaires actuels du club <Badge teinte="gris">{clubs.length}</Badge></h3>
            <p className="mb-3 text-xs text-gris">Relevés sur la <a href={liensOfficiels.partenaires} className="underline" target="_blank" rel="noopener noreferrer">page officielle</a>. Être partenaire du club n&apos;implique aucune participation à cette opération.</p>
            <ul className="flex flex-wrap gap-2">
              {clubs.map((p) => (
                <li key={p.nom} className="border border-gris-clair px-3 py-1 text-sm">{p.site ? <a href={p.site} target="_blank" rel="noopener noreferrer" className="hover:text-rouge">{p.nom}</a> : p.nom}{p.note && <span className="ml-1 text-xs text-gris">({p.note})</span>}</li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="mb-3 text-2xl">Partenaires confirmés de l&apos;opération <Badge teinte="vert">{operation.length}</Badge></h3>
            {operation.length ? <ul className="space-y-2">{operation.map((p) => <li key={p.nom} className="border border-vert/40 bg-clair-2 p-3 text-sm">{p.nom}{p.note && <span className="ml-1 text-xs text-gris">({p.note})</span>}</li>)}</ul> : <Encart titre="Aucun à ce jour" teinte="ambre"><p>Aucun partenaire n&apos;a confirmé sa participation à l&apos;opération.</p></Encart>}
          </div>
          <div>
            <h3 className="mb-3 text-2xl">Entreprises à démarcher <Badge teinte="ambre">{prospects.length}</Badge></h3>
            <ul className="space-y-2">
              {prospects.map((p) => <li key={p.nom} className="carte p-3 text-sm"><p className="font-600">{p.nom}</p><p className="text-xs text-gris">{p.note}</p></li>)}
            </ul>
          </div>
        </div>
      </Section>
    </>
  );
}
