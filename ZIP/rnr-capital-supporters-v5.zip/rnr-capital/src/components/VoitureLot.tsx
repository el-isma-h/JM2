"use client";

import dynamic from "next/dynamic";
import { use3DAutorisee, Secours3D } from "@/components/3d/Securite3D";

const SceneVoiture = dynamic(() => import("@/components/3d/SceneVoiture"), { ssr: false, loading: () => <div className="h-full w-full animate-pulse bg-noir-2" aria-hidden /> });

/** Vue 3D de la voiture envisagée, avec secours sans WebGL ou mouvement réduit. */
export function VoitureLot({ className = "" }: { className?: string }) {
  const ok = use3DAutorisee();
  if (ok === null) return <div className={`animate-pulse bg-noir-2 ${className}`} aria-hidden />;
  if (!ok) return <Secours3D type="voiture" titre="Véhicule envisagé" texte="CUPRA Formentor envisagée, non contractuelle. Partenariat non signé." className={className} />;
  return <SceneVoiture className={className} />;
}
