"use client";

import { Component, useLayoutEffect, useMemo, useRef, type ReactNode } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { Voiture } from "./Voiture";

/**
 * CUPRA Formentor (2021) : modèle 3D fourni par le porteur du projet (fichier FBX),
 * converti en glTF binaire compressé Draco (`public/models/cupra-formentor.glb`).
 *
 * Conversion : FBX → glTF (fbx2gltf), décimation à ~140 000 triangles (Open3D),
 * matériaux PBR attribués par groupe de pièces (carrosserie, vitres, pneus, jantes,
 * phares, feux, chrome, plastiques), soudure des sommets et compression Draco.
 * Le décodeur Draco est servi localement depuis `public/draco/` : aucune ressource réseau.
 *
 * Repère du fichier : X à droite, Y = longueur (avant vers −Y), Z vers le haut.
 * Le groupe est donc pivoté de −90° autour de X pour que Z devienne la hauteur three.js.
 */

export const CHEMIN_MODELE_CUPRA = "/models/cupra-formentor.glb";
useGLTF.setDecoderPath("/draco/");

type Props = {
  /** Longueur cible du véhicule dans la scène (unités three.js). */
  longueur?: number;
  /** Légère respiration verticale. */
  animee?: boolean;
};

function ModeleCupra({ longueur = 4.9, animee = true }: Props) {
  const { scene } = useGLTF(CHEMIN_MODELE_CUPRA);
  const groupe = useRef<THREE.Group>(null);

  // Clone pour pouvoir afficher la voiture dans plusieurs scènes (accueil + page Lots).
  const objet = useMemo(() => {
    const clone = scene.clone(true);
    clone.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        const m = o as THREE.Mesh;
        m.castShadow = true;
        m.receiveShadow = false;
        const mat = m.material as THREE.MeshStandardMaterial;
        if (mat?.transparent) m.renderOrder = 2; // vitres après la carrosserie
      }
    });
    return clone;
  }, [scene]);

  // Mise à l'échelle et centrage sur la boîte englobante réelle du modèle.
  const { echelle, decalage } = useMemo(() => {
    const boite = new THREE.Box3().setFromObject(objet);
    const taille = new THREE.Vector3();
    boite.getSize(taille);
    const centre = new THREE.Vector3();
    boite.getCenter(centre);
    const echelle = longueur / Math.max(taille.y, 0.001); // Y = longueur dans le repère du fichier
    return { echelle, decalage: new THREE.Vector3(-centre.x, -centre.y, -boite.min.z) };
  }, [objet, longueur]);

  useLayoutEffect(() => {
    objet.position.copy(decalage);
  }, [objet, decalage]);

  useFrame(({ clock }) => {
    if (!animee || !groupe.current) return;
    groupe.current.position.y = Math.sin(clock.elapsedTime * 0.9) * 0.012;
  });

  return (
    <group ref={groupe}>
      <group rotation={[-Math.PI / 2, 0, 0]} scale={echelle}>
        <primitive object={objet} />
      </group>
    </group>
  );
}

/** Si le fichier glTF ne peut pas être chargé, on retombe sur la berline stylisée. */
class GardeModele extends Component<{ secours: ReactNode; children: ReactNode }, { erreur: boolean }> {
  state = { erreur: false };
  static getDerivedStateFromError() {
    return { erreur: true };
  }
  componentDidCatch(err: unknown) {
    console.warn("Modèle CUPRA non chargé, affichage du modèle stylisé.", err);
  }
  render() {
    return this.state.erreur ? this.props.secours : this.props.children;
  }
}

export function VoitureGLB(props: Props) {
  return (
    <GardeModele secours={<Voiture animee />}>
      <ModeleCupra {...props} />
    </GardeModele>
  );
}

useGLTF.preload(CHEMIN_MODELE_CUPRA);
