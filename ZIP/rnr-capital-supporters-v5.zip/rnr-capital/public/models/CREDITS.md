cupra-formentor.glb : CUPRA Formentor 2021, modèle 3D transmis par le porteur du projet (archive `cupra-formentor-2021.zip`, fichier `CUPRA F21.fbx`), converti pour le web le 16/10/2026.

Conversion : FBX → glTF (fbx2gltf), décimation à ~140 000 triangles (Open3D), matériaux PBR attribués par groupe de pièces (carrosserie, vitres, pneus, jantes, phares, feux, chrome, plastiques), compression Draco (gltf-transform). Les textures d'origine (freins, pneus, ombre au sol) ne sont pas reprises.

Usage en démonstration uniquement : la licence du fichier source et le droit d'usage de la marque et du design CUPRA doivent être vérifiés et validés par le partenaire avant toute mise en ligne publique (voir docs/DECISIONS-CLUB.md, points 21 et 24 bis).
