"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import { lireDb, modifierDb, journaliser, idUnique, reinitialiser, type Souscription, type StatutSouscription, type Role } from "@/lib/store";
import { hacher, verifier } from "@/lib/password";
import { ouvrirSession, fermerSession, utilisateurCourant, exigerRole, lireSession } from "@/lib/auth";
import { saisieOuverte, validerScore } from "@/lib/concours";
import { campagne, MODE_DEMO } from "@/config/campagne";
import { simuler } from "@/lib/souscription";
import { envoyerEmail, urlBase } from "@/lib/email";
import { creerSessionCheckout, creerSessionCheckoutEmbarquee, stripeEmbarqueConfigure } from "@/lib/stripe";
import type { EtatAvantage } from "@/data/statuts";
import type { StatutContractuel, CategoriePartenaire } from "@/data/lots";

export type Resultat = { ok: true; message?: string } | { ok: false; erreur: string };

function toutRevalider() {
  for (const p of ["/", "/investir", "/statuts", "/matchs", "/classement", "/lots", "/espace", "/admin"]) revalidatePath(p);
}

/* ------------------------------- COMPTES -------------------------------- */

const schemaInscription = z.object({
  email: z.string().email("Adresse e-mail invalide"),
  pseudo: z.string().min(3, "Pseudo trop court").max(24, "Pseudo trop long").regex(/^[\p{L}\p{N} _.-]+$/u, "Caractères non autorisés"),
  motDePasse: z.string().min(8, "8 caractères minimum"),
  cgu: z.literal("on", { errorMap: () => ({ message: "Vous devez accepter les conditions" }) }),
  donnees: z.literal("on", { errorMap: () => ({ message: "Vous devez accepter le traitement des données" }) }),
});

async function creerJeton(userId: string, type: "verification_email" | "reinitialisation", heures: number) {
  const valeur = randomBytes(24).toString("base64url");
  await modifierDb((db) => {
    db.jetons = db.jetons.filter((j) => !(j.userId === userId && j.type === type));
    db.jetons.push({ id: idUnique("jet"), userId, type, valeur, expireLe: new Date(Date.now() + heures * 3_600_000).toISOString(), utilise: false });
  });
  return valeur;
}

export async function inscription(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const parse = schemaInscription.safeParse(Object.fromEntries(form));
  if (!parse.success) return { ok: false, erreur: parse.error.issues[0].message };
  const { email, pseudo, motDePasse } = parse.data;
  const emailNorm = email.trim().toLowerCase();
  if (form.get("site_web")) return { ok: true }; // honeypot
  const user = await modifierDb((db) => {
    if (db.users.some((u) => u.email === emailNorm)) return null;
    if (db.users.some((u) => u.pseudo.toLowerCase() === pseudo.toLowerCase())) return "pseudo";
    const u = {
      id: idUnique("usr"),
      email: emailNorm,
      pseudo: pseudo.trim(),
      motDePasse: hacher(motDePasse),
      role: "supporter" as const,
      creeLe: new Date().toISOString(),
      consentements: { cgu: true, donnees: true, reconnaissancePublique: false },
      emailVerifie: false,
      suspendu: false,
    };
    db.users.push(u);
    db.participants.push({ id: u.id, pseudo: u.pseudo, inscritLe: u.creeLe });
    return u;
  });
  if (user === null) return { ok: false, erreur: "Un compte existe déjà avec cette adresse" };
  if (user === "pseudo") return { ok: false, erreur: "Ce pseudo est déjà utilisé" };
  const jeton = await creerJeton(user.id, "verification_email", 48);
  await envoyerEmail(user.email, "Confirmez votre adresse — Lions Capital (démonstration)", `Bonjour ${user.pseudo},\n\nConfirmez votre adresse en ouvrant ce lien :\n${await urlBase()}/compte/verifier?jeton=${jeton}\n\nCe lien expire dans 48 h. Aucun achat n'est nécessaire pour participer au concours.`);
  await journaliser({ acteur: user.id, action: "inscription gratuite au concours", details: { pseudo: user.pseudo } });
  await ouvrirSession(user);
  redirect("/matchs?bienvenue=1");
}

export async function connexion(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const email = String(form.get("email") ?? "").trim().toLowerCase();
  const motDePasse = String(form.get("motDePasse") ?? "");
  const code = String(form.get("code") ?? "").trim();
  const retour = String(form.get("retour") ?? "");
  const db = await lireDb();
  const user = db.users.find((u) => u.email === email);
  if (!user || !verifier(motDePasse, user.motDePasse)) {
    await journaliser({ acteur: email || "inconnu", action: "échec de connexion" });
    return { ok: false, erreur: "Identifiants incorrects" };
  }
  if (user.suspendu) return { ok: false, erreur: "Compte suspendu : contactez le support" };
  let renforcee = false;
  if (user.role === "admin") {
    if (!code || !user.codeAdmin || !verifier(code, user.codeAdmin)) return { ok: false, erreur: "Code administrateur requis (deuxième facteur)" };
    renforcee = true;
  }
  await ouvrirSession(user, renforcee);
  await journaliser({ acteur: user.id, action: "connexion", details: { role: user.role, renforcee } });
  const cible = retour.startsWith("/") && !retour.startsWith("//") ? retour : user.role === "admin" ? "/admin" : user.role === "actionnaire" ? "/espace" : "/matchs";
  redirect(cible);
}

export async function deconnexion() {
  const s = await lireSession();
  if (s) await journaliser({ acteur: s.userId, action: "déconnexion" });
  await fermerSession();
  redirect("/");
}

export async function verifierEmail(jeton: string): Promise<Resultat> {
  const res = await modifierDb((db) => {
    const j = db.jetons.find((x) => x.valeur === jeton && x.type === "verification_email" && !x.utilise);
    if (!j) return "invalide";
    if (Date.parse(j.expireLe) < Date.now()) return "expire";
    j.utilise = true;
    const u = db.users.find((x) => x.id === j.userId);
    if (u) u.emailVerifie = true;
    return u?.id ?? "invalide";
  });
  if (res === "invalide") return { ok: false, erreur: "Lien invalide ou déjà utilisé" };
  if (res === "expire") return { ok: false, erreur: "Lien expiré : demandez un nouvel envoi depuis votre espace" };
  await journaliser({ acteur: res, action: "adresse e-mail vérifiée" });
  return { ok: true, message: "Adresse confirmée" };
}

export async function renvoyerVerification(): Promise<void> {
  const user = await utilisateurCourant();
  if (!user || user.emailVerifie) return;
  const jeton = await creerJeton(user.id, "verification_email", 48);
  await envoyerEmail(user.email, "Confirmez votre adresse — Lions Capital (démonstration)", `Lien de confirmation :\n${await urlBase()}/compte/verifier?jeton=${jeton}`);
  await journaliser({ acteur: user.id, action: "renvoi de l'e-mail de confirmation" });
  revalidatePath("/espace");
  revalidatePath("/compte/profil");
}

export async function demanderReinitialisation(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const email = String(form.get("email") ?? "").trim().toLowerCase();
  const db = await lireDb();
  const user = db.users.find((u) => u.email === email);
  // Réponse identique que le compte existe ou non (pas de divulgation).
  if (user) {
    const jeton = await creerJeton(user.id, "reinitialisation", 2);
    await envoyerEmail(user.email, "Réinitialisation du mot de passe — Lions Capital", `Pour choisir un nouveau mot de passe :\n${await urlBase()}/compte/reinitialiser?jeton=${jeton}\n\nLe lien expire dans 2 h. Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.`);
    await journaliser({ acteur: user.id, action: "demande de réinitialisation du mot de passe" });
  }
  return { ok: true, message: "Si un compte existe pour cette adresse, un e-mail vient d'être envoyé" };
}

export async function reinitialiserMotDePasse(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const jeton = String(form.get("jeton") ?? "");
  const mdp = String(form.get("motDePasse") ?? "");
  if (mdp.length < 8) return { ok: false, erreur: "8 caractères minimum" };
  if (mdp !== String(form.get("confirmation") ?? "")) return { ok: false, erreur: "Les deux mots de passe diffèrent" };
  const res = await modifierDb((db) => {
    const j = db.jetons.find((x) => x.valeur === jeton && x.type === "reinitialisation" && !x.utilise);
    if (!j || Date.parse(j.expireLe) < Date.now()) return null;
    j.utilise = true;
    const u = db.users.find((x) => x.id === j.userId);
    if (!u) return null;
    u.motDePasse = hacher(mdp);
    return u.id;
  });
  if (!res) return { ok: false, erreur: "Lien invalide ou expiré" };
  await journaliser({ acteur: res, action: "mot de passe réinitialisé" });
  redirect("/connexion?reinitialise=1");
}

export async function majProfil(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await utilisateurCourant();
  if (!user) return { ok: false, erreur: "Connexion requise" };
  const pseudo = String(form.get("pseudo") ?? "").trim();
  if (pseudo.length < 3 || pseudo.length > 24) return { ok: false, erreur: "Pseudo : 3 à 24 caractères" };
  const prenom = String(form.get("prenom") ?? "").trim().slice(0, 60);
  const nom = String(form.get("nom") ?? "").trim().slice(0, 60);
  const telephone = String(form.get("telephone") ?? "").trim().slice(0, 20);
  const reco = form.get("reconnaissancePublique") === "on";
  const res = await modifierDb((db) => {
    if (db.users.some((u) => u.id !== user.id && u.pseudo.toLowerCase() === pseudo.toLowerCase())) return "pseudo";
    const u = db.users.find((x) => x.id === user.id)!;
    u.pseudo = pseudo; u.prenom = prenom; u.nom = nom; u.telephone = telephone;
    u.consentements.reconnaissancePublique = reco;
    const p = db.participants.find((x) => x.id === user.id);
    if (p) p.pseudo = pseudo;
    return "ok";
  });
  if (res === "pseudo") return { ok: false, erreur: "Ce pseudo est déjà utilisé" };
  await journaliser({ acteur: user.id, action: "mise à jour du profil", details: { reconnaissancePublique: reco } });
  toutRevalider();
  return { ok: true, message: "Profil enregistré" };
}

export async function changerMotDePasse(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await utilisateurCourant();
  if (!user) return { ok: false, erreur: "Connexion requise" };
  const actuel = String(form.get("actuel") ?? "");
  const nouveau = String(form.get("nouveau") ?? "");
  if (!verifier(actuel, user.motDePasse)) return { ok: false, erreur: "Mot de passe actuel incorrect" };
  if (nouveau.length < 8) return { ok: false, erreur: "8 caractères minimum" };
  await modifierDb((db) => { db.users.find((x) => x.id === user.id)!.motDePasse = hacher(nouveau); });
  await journaliser({ acteur: user.id, action: "mot de passe modifié" });
  return { ok: true, message: "Mot de passe modifié" };
}

export async function supprimerCompte(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await utilisateurCourant();
  if (!user) return { ok: false, erreur: "Connexion requise" };
  if (String(form.get("confirmation")) !== "SUPPRIMER") return { ok: false, erreur: "Tapez SUPPRIMER pour confirmer" };
  const db = await lireDb();
  if (db.souscriptions.some((s) => s.userId === user.id && (s.statut === "confirmee" || s.statut === "paiement_recu"))) {
    return { ok: false, erreur: "Des titres ou paiements sont rattachés à ce compte : la suppression passe par le support (obligations légales de conservation)" };
  }
  await modifierDb((d) => {
    d.users = d.users.filter((u) => u.id !== user.id);
    d.participants = d.participants.filter((p) => p.id !== user.id);
    d.pronostics = d.pronostics.filter((p) => p.userId !== user.id);
    d.souscriptions = d.souscriptions.filter((s) => s.userId !== user.id);
    d.reservations = d.reservations.filter((r) => r.userId !== user.id);
    d.jetons = d.jetons.filter((j) => j.userId !== user.id);
  });
  await journaliser({ acteur: user.id, action: "compte supprimé à la demande de l'utilisateur (RGPD)" });
  await fermerSession();
  redirect("/?compte=supprime");
}

/* ------------------------------ CONCOURS -------------------------------- */

const schemaProno = z.object({ matchId: z.string(), scoreDomicile: z.coerce.number(), scoreExterieur: z.coerce.number() });

export async function enregistrerPronostic(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await utilisateurCourant();
  if (!user) return { ok: false, erreur: "Connectez-vous pour pronostiquer (inscription gratuite)" };
  const parse = schemaProno.safeParse(Object.fromEntries(form));
  if (!parse.success) return { ok: false, erreur: "Scores invalides" };
  const { matchId, scoreDomicile, scoreExterieur } = parse.data;
  if (!validerScore(scoreDomicile) || !validerScore(scoreExterieur)) return { ok: false, erreur: "Chaque score doit être un entier entre 0 et 150" };
  const db = await lireDb();
  if (!db.parametres.concoursActif) return { ok: false, erreur: "Le concours est suspendu" };
  const match = db.matchs.find((m) => m.id === matchId);
  if (!match) return { ok: false, erreur: "Match inconnu" };
  if (!saisieOuverte(match, campagne.clotureMinutesAvantCoupDEnvoi, new Date())) return { ok: false, erreur: "Les pronostics de ce match sont clôturés" };
  await modifierDb((d) => {
    if (!d.participants.some((p) => p.id === user.id)) d.participants.push({ id: user.id, pseudo: user.pseudo, inscritLe: new Date().toISOString() });
    const existant = d.pronostics.find((p) => p.userId === user.id && p.matchId === matchId);
    const maintenant = new Date().toISOString();
    if (existant) { existant.scoreDomicile = scoreDomicile; existant.scoreExterieur = scoreExterieur; existant.modifieLe = maintenant; }
    else d.pronostics.push({ id: idUnique("prn"), userId: user.id, matchId, scoreDomicile, scoreExterieur, modifieLe: maintenant });
  });
  await journaliser({ acteur: user.id, action: "pronostic enregistré", cible: matchId, details: { scoreDomicile, scoreExterieur } });
  revalidatePath("/matchs");
  return { ok: true, message: "Pronostic enregistré" };
}

/* ---------------------------- SOUSCRIPTION ------------------------------ */

export async function creerIntentionSouscription(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await utilisateurCourant();
  if (!user) return { ok: false, erreur: "Créez un compte ou connectez-vous d'abord" };
  const actions = Number(form.get("actions"));
  if (!Number.isInteger(actions) || actions < campagne.minimumActions || actions > campagne.maximumActionsParPersonne) return { ok: false, erreur: "Nombre d'actions invalide" };
  if (form.get("risques") !== "on") return { ok: false, erreur: "Vous devez confirmer avoir lu les informations sur les risques" };
  const sim = simuler(actions);
  const sub: Souscription = { id: idUnique("sub"), userId: user.id, actions: sim.actions, montant: sim.montantActions, frais: sim.frais, statut: "intention", creeLe: new Date().toISOString(), demo: true };
  await modifierDb((d) => { d.souscriptions.push(sub); });
  await journaliser({ acteur: user.id, action: "intention de souscription (démonstration, aucun encaissement)", cible: sub.id, details: { actions: sub.actions, montant: sub.montant } });
  toutRevalider();
  const db = await lireDb();
  if (form.get("payer") === "on" && db.parametres.stripeDemoActif) {
    if (!user.emailVerifie) return { ok: false, erreur: "Confirmez votre adresse e-mail avant le paiement de démonstration (voir votre espace)" };
    await modifierDb((d) => { const s = d.souscriptions.find((x) => x.id === sub.id)!; s.statut = "en_attente_prestataire"; });
    await journaliser({ acteur: user.id, action: "ouverture de la page de paiement intégrée (démonstration)", cible: sub.id });
    redirect(`/paiement?souscription=${sub.id}`);
  }
  return { ok: true, message: MODE_DEMO ? "Intention enregistrée en démonstration : aucun encaissement, aucune émission de titres." : "Intention enregistrée" };
}

/**
 * Prépare le paiement d'une souscription en attente, depuis la page /paiement (intégrée au site).
 * - Stripe intégré configuré : crée une session « embedded » et renvoie son client_secret.
 * - Stripe hébergé seul (clé secrète sans clé publiable) : renvoie l'URL Checkout hébergée.
 * - Sans clé : simulation locale sur la même page.
 */
export async function preparerPaiement(souscriptionId: string): Promise<{ mode: "embarque"; clientSecret: string } | { mode: "heberge"; url: string } | { mode: "simulation" } | { mode: "erreur"; erreur: string }> {
  const user = await utilisateurCourant();
  if (!user) return { mode: "erreur", erreur: "Connexion requise" };
  const db = await lireDb();
  if (!db.parametres.stripeDemoActif) return { mode: "erreur", erreur: "Le paiement de démonstration est désactivé par l'administration" };
  if (!user.emailVerifie) return { mode: "erreur", erreur: "Confirmez votre adresse e-mail avant le paiement de démonstration (voir votre espace)" };
  const s = db.souscriptions.find((x) => x.id === souscriptionId && x.userId === user.id);
  if (!s) return { mode: "erreur", erreur: "Souscription inconnue" };
  if (s.statut === "paiement_recu" || s.statut === "confirmee") return { mode: "erreur", erreur: "Cette souscription est déjà payée" };
  if (s.statut === "annulee") return { mode: "erreur", erreur: "Cette souscription est annulée" };
  const montantCentimes = Math.round((s.montant + s.frais) * 100);
  if (stripeEmbarqueConfigure()) {
    const session = await creerSessionCheckoutEmbarquee({ souscriptionId: s.id, actions: s.actions, montantCentimes, email: user.email, urlBase: await urlBase() });
    if (session) {
      await modifierDb((d) => { const x = d.souscriptions.find((y) => y.id === s.id)!; x.stripeSessionId = session.sessionId; x.statut = "en_attente_prestataire"; });
      await journaliser({ acteur: user.id, action: "session Stripe Checkout intégrée (mode test) créée", cible: s.id, details: { sessionId: session.sessionId } });
      return { mode: "embarque", clientSecret: session.clientSecret };
    }
  }
  const session = await creerSessionCheckout({ souscriptionId: s.id, actions: s.actions, montantCentimes, email: user.email, urlBase: await urlBase() });
  await modifierDb((d) => { const x = d.souscriptions.find((y) => y.id === s.id)!; x.stripeSessionId = session.sessionId; x.statut = "en_attente_prestataire"; });
  if (session.simulation) {
    await journaliser({ acteur: user.id, action: "paiement simulé (aucune clé Stripe) affiché dans la page /paiement", cible: s.id });
    return { mode: "simulation" };
  }
  await journaliser({ acteur: user.id, action: "session Stripe Checkout hébergée (mode test) créée", cible: s.id, details: { sessionId: session.sessionId } });
  return { mode: "heberge", url: session.url };
}

/** Marque un paiement de démonstration comme reçu (retour Stripe test vérifié, simulation, ou webhook). */
export async function marquerPaiementRecu(souscriptionId: string, paymentIntent: string | undefined, origine: string) {
  const res = await modifierDb((d) => {
    const s = d.souscriptions.find((x) => x.id === souscriptionId);
    if (!s || s.statut === "confirmee" || s.statut === "annulee") return null;
    s.statut = "paiement_recu";
    if (paymentIntent) s.stripePaymentIntent = paymentIntent;
    return s;
  });
  if (res) await journaliser({ acteur: "paiement", action: `paiement de démonstration reçu (${origine})`, cible: souscriptionId, details: { paymentIntent } });
  // Pas de revalidatePath ici : cette fonction peut être appelée pendant le rendu de /paiement/retour (pages dynamiques).
  return res;
}

export async function confirmerPaiementSimule(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await utilisateurCourant();
  if (!user) return { ok: false, erreur: "Connexion requise" };
  const id = String(form.get("souscription"));
  const db = await lireDb();
  const s = db.souscriptions.find((x) => x.id === id && x.userId === user.id);
  if (!s) return { ok: false, erreur: "Souscription inconnue" };
  if (form.get("resultat") === "echec") {
    await journaliser({ acteur: user.id, action: "paiement simulé refusé", cible: id });
    redirect(`/paiement/retour?statut=annule&souscription=${id}`);
  }
  await marquerPaiementRecu(id, `sim_pi_${id}`, "simulation sans clé Stripe");
  redirect(`/paiement/retour?statut=succes&souscription=${id}`);
}

export async function reserverAvantage(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await utilisateurCourant();
  if (!user) return { ok: false, erreur: "Connexion requise" };
  const statutId = String(form.get("statutId"));
  const avantageId = String(form.get("avantageId"));
  const db = await lireDb();
  const statut = db.statuts.find((s) => s.id === statutId);
  const avantage = statut?.avantages.find((a) => a.id === avantageId);
  if (!statut || !avantage) return { ok: false, erreur: "Avantage inconnu" };
  const actions = db.souscriptions.filter((s) => s.userId === user.id && s.statut === "confirmee").reduce((n, s) => n + s.actions, 0);
  if (actions < statut.seuilActions) return { ok: false, erreur: "Ce statut n'est pas atteint par vos titres confirmés" };
  if (avantage.etat !== "confirme") return { ok: false, erreur: "Cet avantage n'est pas encore confirmé par le club : réservation impossible" };
  if (db.reservations.some((r) => r.userId === user.id && r.avantageId === avantageId && r.etat !== "annulee")) return { ok: false, erreur: "Réservation déjà enregistrée" };
  await modifierDb((d) => { d.reservations.push({ id: idUnique("res"), userId: user.id, avantageId, statutId, creeLe: new Date().toISOString(), etat: "demandee" }); });
  await journaliser({ acteur: user.id, action: "réservation d'avantage", cible: avantageId });
  revalidatePath("/espace");
  return { ok: true, message: "Réservation demandée" };
}

/* ----------------------------- ADMINISTRATION ----------------------------- */

async function admin() {
  const a = await exigerRole(["admin"]);
  if (!a) throw new Error("Accès refusé");
  return a.user;
}

export async function saisirResultat(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const matchId = String(form.get("matchId"));
  const sd = Number(form.get("scoreDomicile"));
  const se = Number(form.get("scoreExterieur"));
  const motif = String(form.get("motif") ?? "").trim();
  if (!validerScore(sd) || !validerScore(se)) return { ok: false, erreur: "Scores invalides" };
  const db = await lireDb();
  const m = db.matchs.find((x) => x.id === matchId);
  if (!m) return { ok: false, erreur: "Match inconnu" };
  if (m.resultatVerifie && !motif) return { ok: false, erreur: "Un motif est obligatoire pour corriger un résultat déjà vérifié" };
  const avant = { statut: m.statut, scoreDomicile: m.scoreDomicile, scoreExterieur: m.scoreExterieur, resultatVerifie: m.resultatVerifie };
  await modifierDb((d) => { const x = d.matchs.find((y) => y.id === matchId)!; x.statut = "termine"; x.scoreDomicile = sd; x.scoreExterieur = se; x.resultatVerifie = true; });
  await journaliser({ acteur: user.id, action: m.resultatVerifie ? "CORRECTION de résultat vérifié" : "saisie de résultat vérifié", cible: matchId, details: { avant, apres: { scoreDomicile: sd, scoreExterieur: se }, motif } });
  toutRevalider();
  return { ok: true, message: "Résultat enregistré et journalisé" };
}

export async function changerStatutMatch(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const matchId = String(form.get("matchId"));
  const statut = String(form.get("statut")) as "a_venir" | "reporte" | "annule" | "forfait";
  const nouvelleDate = String(form.get("coupDEnvoi") ?? "").trim();
  const motif = String(form.get("motif") ?? "").trim();
  if (!["a_venir", "reporte", "annule", "forfait"].includes(statut)) return { ok: false, erreur: "Statut invalide" };
  if (!motif) return { ok: false, erreur: "Un motif est obligatoire" };
  const db = await lireDb();
  const m = db.matchs.find((x) => x.id === matchId);
  if (!m) return { ok: false, erreur: "Match inconnu" };
  const avant = { statut: m.statut, coupDEnvoi: m.coupDEnvoi };
  await modifierDb((d) => {
    const x = d.matchs.find((y) => y.id === matchId)!;
    x.statut = statut;
    if (statut === "reporte" && nouvelleDate && !Number.isNaN(Date.parse(nouvelleDate))) { x.coupDEnvoi = new Date(nouvelleDate).toISOString(); x.statut = "a_venir"; }
    if (statut === "annule" || statut === "forfait") { x.resultatVerifie = false; delete x.scoreDomicile; delete x.scoreExterieur; }
  });
  await journaliser({ acteur: user.id, action: "changement de statut de match", cible: matchId, details: { avant, statut, nouvelleDate, motif } });
  toutRevalider();
  return { ok: true, message: "Statut mis à jour et journalisé" };
}

export async function majParametres(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const objectif = Number(form.get("objectif"));
  const ouverture = String(form.get("ouverture"));
  const cloture = String(form.get("cloture"));
  if (!Number.isFinite(objectif) || objectif <= 0) return { ok: false, erreur: "Objectif invalide" };
  if (Number.isNaN(Date.parse(ouverture)) || Number.isNaN(Date.parse(cloture))) return { ok: false, erreur: "Dates invalides" };
  const flags = { concoursActif: form.get("concoursActif") === "on", lotsActifs: form.get("lotsActifs") === "on", omActif: form.get("omActif") === "on", stripeDemoActif: form.get("stripeDemoActif") === "on" };
  const db = await lireDb();
  const avant = { ...db.parametres, lotPrincipal: undefined };
  await modifierDb((d) => { d.parametres = { ...d.parametres, objectif, ouverture, cloture, ...flags }; });
  await journaliser({ acteur: user.id, action: "mise à jour des paramètres de campagne", details: { avant, apres: { objectif, ouverture, cloture, ...flags } } });
  toutRevalider();
  return { ok: true, message: "Paramètres enregistrés" };
}

export async function changerStatutSouscription(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const id = String(form.get("id"));
  const statut = String(form.get("statut")) as StatutSouscription;
  const reference = String(form.get("reference") ?? "").trim();
  const valides: StatutSouscription[] = ["intention", "en_attente_prestataire", "paiement_recu", "confirmee", "annulee"];
  if (!valides.includes(statut)) return { ok: false, erreur: "Statut invalide" };
  if (statut === "confirmee" && !reference) return { ok: false, erreur: "Une référence du prestataire habilité est obligatoire pour confirmer des titres" };
  const db = await lireDb();
  const s = db.souscriptions.find((x) => x.id === id);
  if (!s) return { ok: false, erreur: "Souscription inconnue" };
  const avant = s.statut;
  await modifierDb((d) => {
    const x = d.souscriptions.find((y) => y.id === id)!;
    x.statut = statut;
    if (reference) x.referencePrestataire = reference;
    if (statut === "confirmee") { const u = d.users.find((y) => y.id === x.userId); if (u && u.role === "supporter") u.role = "actionnaire"; }
  });
  await journaliser({ acteur: user.id, action: "rapprochement de souscription", cible: id, details: { avant, apres: statut, reference } });
  toutRevalider();
  return { ok: true, message: "Souscription mise à jour" };
}

export async function changerEtatReservation(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const id = String(form.get("id"));
  const etat = String(form.get("etat")) as "demandee" | "confirmee" | "utilisee" | "annulee";
  await modifierDb((d) => { const r = d.reservations.find((x) => x.id === id); if (r) r.etat = etat; });
  await journaliser({ acteur: user.id, action: "mise à jour de réservation", cible: id, details: { etat } });
  revalidatePath("/admin");
  return { ok: true };
}

export async function gererCompte(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const id = String(form.get("id"));
  const role = String(form.get("role")) as Role;
  const suspendu = form.get("suspendu") === "on";
  const emailVerifie = form.get("emailVerifie") === "on";
  if (!["supporter", "actionnaire", "admin"].includes(role)) return { ok: false, erreur: "Rôle invalide" };
  if (id === user.id && (suspendu || role !== "admin")) return { ok: false, erreur: "Vous ne pouvez pas vous suspendre ni vous retirer le rôle administrateur" };
  const db = await lireDb();
  const u = db.users.find((x) => x.id === id);
  if (!u) return { ok: false, erreur: "Compte inconnu" };
  const avant = { role: u.role, suspendu: u.suspendu, emailVerifie: u.emailVerifie };
  await modifierDb((d) => { const x = d.users.find((y) => y.id === id)!; x.role = role; x.suspendu = suspendu; x.emailVerifie = emailVerifie; if (role === "admin" && !x.codeAdmin) x.codeAdmin = hacher("246810"); });
  await journaliser({ acteur: user.id, action: "gestion de compte", cible: id, details: { avant, apres: { role, suspendu, emailVerifie } } });
  revalidatePath("/admin");
  return { ok: true, message: "Compte mis à jour" };
}

export async function majAvantage(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const statutId = String(form.get("statutId"));
  const avantageId = String(form.get("avantageId"));
  const etat = String(form.get("etat")) as EtatAvantage;
  if (!["confirme", "negociation", "envisage"].includes(etat)) return { ok: false, erreur: "État invalide" };
  const champs = { titre: String(form.get("titre") ?? "").trim(), quantite: String(form.get("quantite") ?? "").trim(), capacite: String(form.get("capacite") ?? "").trim(), duree: String(form.get("duree") ?? "").trim(), coutEstime: Number(form.get("coutEstime") ?? 0) };
  if (!champs.titre) return { ok: false, erreur: "Titre obligatoire" };
  const res = await modifierDb((d) => {
    const s = d.statuts.find((x) => x.id === statutId);
    const a = s?.avantages.find((x) => x.id === avantageId);
    if (!a) return null;
    const avant = { ...a };
    Object.assign(a, champs, { etat });
    return avant;
  });
  if (!res) return { ok: false, erreur: "Avantage inconnu" };
  await journaliser({ acteur: user.id, action: "modification d'un avantage", cible: avantageId, details: { avant: res, apres: { ...champs, etat } } });
  toutRevalider();
  return { ok: true, message: "Avantage enregistré" };
}

export async function majLot(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const id = String(form.get("id"));
  const statut = String(form.get("statut")) as StatutContractuel;
  if (!["confirme", "en_discussion", "envisage"].includes(statut)) return { ok: false, erreur: "Statut invalide" };
  const champs = { titre: String(form.get("titre") ?? "").trim(), fournisseur: String(form.get("fournisseur") ?? "").trim(), quantite: Number(form.get("quantite") ?? 0), valeurEstimee: form.get("valeurEstimee") ? Number(form.get("valeurEstimee")) : null, conditionsRemise: String(form.get("conditionsRemise") ?? "").trim() };
  const res = await modifierDb((d) => {
    const l = d.lots.find((x) => x.id === id);
    if (!l) return null;
    const avant = { ...l };
    Object.assign(l, champs, { statut });
    return avant;
  });
  if (!res) return { ok: false, erreur: "Lot inconnu" };
  await journaliser({ acteur: user.id, action: "modification d'un lot", cible: id, details: { avant: res, apres: { ...champs, statut } } });
  toutRevalider();
  return { ok: true, message: "Lot enregistré" };
}

export async function majLotPrincipal(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const cles = ["partenaireContractuel", "modele", "version", "etat", "kilometrage", "valeurDocumentee", "proprieteVehicule", "immatriculationLivraisonFrais", "conditionsRemise", "dateDisponibilite", "documentsContractuels"];
  const apres: Record<string, string> = {};
  for (const k of cles) apres[k] = String(form.get(k) ?? "").trim().slice(0, 300);
  const db = await lireDb();
  const avant = db.parametres.lotPrincipal;
  await modifierDb((d) => { d.parametres.lotPrincipal = apres; });
  await journaliser({ acteur: user.id, action: "modification de la fiche du lot principal", details: { avant, apres } });
  toutRevalider();
  return { ok: true, message: "Fiche enregistrée (le lot reste « envisagé » tant que lotsActifs est désactivé)" };
}

export async function majPartenaire(_prev: Resultat | null, form: FormData): Promise<Resultat> {
  const user = await admin();
  const nom = String(form.get("nom") ?? "").trim();
  const categorie = String(form.get("categorie")) as CategoriePartenaire;
  const supprimer = form.get("supprimer") === "on";
  if (!nom) return { ok: false, erreur: "Nom obligatoire" };
  if (!["partenaire_club", "partenaire_operation", "prospect"].includes(categorie)) return { ok: false, erreur: "Catégorie invalide" };
  const note = String(form.get("note") ?? "").trim();
  const site = String(form.get("site") ?? "").trim();
  await modifierDb((d) => {
    const i = d.partenaires.findIndex((p) => p.nom === nom);
    if (supprimer) { if (i >= 0) d.partenaires.splice(i, 1); return; }
    const p = { nom, categorie, note: note || undefined, site: site || undefined };
    if (i >= 0) d.partenaires[i] = p; else d.partenaires.push(p);
  });
  await journaliser({ acteur: user.id, action: supprimer ? "suppression d'un partenaire" : "ajout ou modification d'un partenaire", cible: nom, details: { categorie, site, note } });
  toutRevalider();
  return { ok: true, message: supprimer ? "Partenaire retiré" : "Partenaire enregistré" };
}

export async function reinitialiserDemo() {
  const user = await admin();
  await reinitialiser();
  await journaliser({ acteur: user.id, action: "réinitialisation des données de démonstration" });
  toutRevalider();
  redirect("/connexion?reinit=1");
}
