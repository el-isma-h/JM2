/**
 * Stripe en MODE TEST, pour la démonstration uniquement.
 * Rappel : en production, une souscription d'actions n'est jamais encaissée par la plateforme ; le paiement passe
 * par le prestataire habilité (compte séquestre). Ce module sert à montrer le parcours de bout en bout.
 * Sans STRIPE_SECRET_KEY, une page de simulation (/paiement/simulation) remplace Stripe Checkout.
 *
 * Depuis la v6, le formulaire Stripe est intégré directement dans le site (« Embedded Checkout », page /paiement) :
 * la session est créée en `ui_mode: "embedded"` et rendue côté client dans une iframe Stripe, aux couleurs du site.
 * La clé publiable (NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY, pk_test_…) est nécessaire pour ce mode.
 */
import Stripe from "stripe";

export function stripeConfigure() {
  return Boolean(process.env.STRIPE_SECRET_KEY?.startsWith("sk_test_"));
}

/** Clé publiable de test exposée au navigateur (vide si absente ou si ce n'est pas une clé de test). */
export function clePubliableStripe(): string | null {
  const k = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY;
  return k?.startsWith("pk_test_") ? k : null;
}

/** Le paiement intégré (iframe Stripe dans le site) exige la clé secrète ET la clé publiable de test. */
export function stripeEmbarqueConfigure() {
  return stripeConfigure() && clePubliableStripe() !== null;
}

export function clientStripe(): Stripe | null {
  if (!stripeConfigure()) return null;
  return new Stripe(process.env.STRIPE_SECRET_KEY as string);
}

export interface SessionCheckout {
  url: string;
  sessionId: string;
  simulation: boolean;
}

export async function creerSessionCheckout(args: { souscriptionId: string; actions: number; montantCentimes: number; email: string; urlBase: string }): Promise<SessionCheckout> {
  const stripe = clientStripe();
  const succes = `${args.urlBase}/paiement/retour?statut=succes&souscription=${args.souscriptionId}&session={CHECKOUT_SESSION_ID}`;
  const annulation = `${args.urlBase}/paiement/retour?statut=annule&souscription=${args.souscriptionId}`;
  if (!stripe) {
    const sessionId = `sim_${args.souscriptionId}`;
    return { url: `${args.urlBase}/paiement/simulation?souscription=${args.souscriptionId}&montant=${args.montantCentimes}`, sessionId, simulation: true };
  }
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: args.email,
    line_items: [
      {
        quantity: args.actions,
        price_data: {
          currency: "eur",
          unit_amount: Math.round(args.montantCentimes / args.actions),
          product_data: { name: "Souscription d'action — DÉMONSTRATION (aucun titre émis)", description: "Paiement test Stripe. Aucune valeur réelle." },
        },
      },
    ],
    metadata: { souscriptionId: args.souscriptionId, demo: "true" },
    success_url: succes,
    cancel_url: annulation,
  });
  return { url: session.url as string, sessionId: session.id, simulation: false };
}

export async function verifierSession(sessionId: string): Promise<{ paye: boolean; paymentIntent?: string }> {
  const stripe = clientStripe();
  if (!stripe) return { paye: false };
  const s = await stripe.checkout.sessions.retrieve(sessionId);
  return { paye: s.payment_status === "paid", paymentIntent: typeof s.payment_intent === "string" ? s.payment_intent : s.payment_intent?.id };
}

/**
 * Session Stripe Checkout en mode intégré (iframe dans la page /paiement du site).
 * Retourne le `client_secret` à transmettre au composant client `CheckoutEmbarque`.
 */
export async function creerSessionCheckoutEmbarquee(args: { souscriptionId: string; actions: number; montantCentimes: number; email: string; urlBase: string }): Promise<{ clientSecret: string; sessionId: string } | null> {
  const stripe = clientStripe();
  if (!stripe || !clePubliableStripe()) return null;
  const session = await stripe.checkout.sessions.create({
    ui_mode: "embedded",
    mode: "payment",
    customer_email: args.email,
    line_items: [
      {
        quantity: args.actions,
        price_data: {
          currency: "eur",
          unit_amount: Math.round(args.montantCentimes / args.actions),
          product_data: { name: "Souscription d'action — DÉMONSTRATION (aucun titre émis)", description: "Paiement test Stripe. Aucune valeur réelle." },
        },
      },
    ],
    metadata: { souscriptionId: args.souscriptionId, demo: "true" },
    return_url: `${args.urlBase}/paiement/retour?statut=succes&souscription=${args.souscriptionId}&session={CHECKOUT_SESSION_ID}`,
  });
  if (!session.client_secret) return null;
  return { clientSecret: session.client_secret, sessionId: session.id };
}

export function construireEvenementWebhook(brut: string, signature: string): Stripe.Event | null {
  const stripe = clientStripe();
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!stripe || !secret) return null;
  return stripe.webhooks.constructEvent(brut, signature, secret);
}
