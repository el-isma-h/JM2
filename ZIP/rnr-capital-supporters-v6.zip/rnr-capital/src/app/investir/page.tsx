import type { Metadata } from "next";
import { campagne } from "@/config/campagne";
import { Section, Titre, Encart, Badge } from "@/components/ui";
import { Simulateur } from "@/components/Simulateur";
import { ExplicationPaiement } from "@/components/ExplicationPaiement";
import { utilisateurCourant } from "@/lib/auth";
import { lireDb } from "@/lib/store";

export const metadata: Metadata = { title: "Investir" };
export const dynamic = "force-dynamic";

const etapes = [
  ["Identification", "Vérification d'identité (KYC) par le prestataire habilité."],
  ["Documents", "Remise de la note d'information et des conditions de souscription."],
  ["Risques", "Lecture et acceptation des informations sur les risques."],
  ["Signature", "Signature électronique du bulletin de souscription."],
  ["Paiement", "Règlement sur un compte séquestre, jamais sur cette plateforme."],
  ["Confirmation", "Titres confirmés après clôture et rapprochement, puis statut activé."],
];

export default async function Investir() {
  const [user, db] = await Promise.all([utilisateurCourant(), lireDb()]);
  const droits = campagne.droits;
  return (
    <>
      <Section className="pb-8">
        <Titre as="h1" sur="Investir">À partir de {campagne.prixAction} € l&apos;action</Titre>
        <div className="grid gap-6 lg:grid-cols-3">
          <Encart titre="Qui émet les actions ?" teinte="ambre">
            <p>Émetteur pressenti : {campagne.emetteur.denomination} ({campagne.emetteur.forme}). Le montage n&apos;est pas arrêté : participation directe dans la société du club ou part d&apos;un véhicule d&apos;investissement. <Badge teinte="ambre">à valider</Badge></p>
          </Encart>
          <Encart titre="Un vrai financement du club" teinte="rouge">
            <p>L&apos;opération doit être une augmentation de capital (ou un montage validé) dont les fonds bénéficient au club. Une revente d&apos;actions existantes ne finance pas sa trésorerie et ne serait pas présentée comme telle.</p>
          </Encart>
          <Encart titre="Trois notions distinctes" teinte="gris">
            <p><strong>Prix de souscription</strong> : {campagne.prixAction} €, hypothèse. <strong>Valeur nominale</strong> : inconnue. <strong>Valeur estimée</strong> : aucune évaluation documentée à ce jour.</p>
          </Encart>
        </div>
      </Section>

      <Section className="border-y border-gris-clair bg-clair-2">
        <Titre sur="Simulateur">Combien, pour quel statut</Titre>
        <Simulateur connecte={!!user} statuts={db.statuts} stripeDemo={db.parametres.stripeDemoActif} emailVerifie={!!user?.emailVerifie} />
      </Section>

      <Section>
        <Titre sur="Paiement intégré au site">Comment se passe le paiement</Titre>
        <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-start">
          <ExplicationPaiement />
          <Encart titre="Depuis votre espace" teinte="gris">
            <p>Chaque souscription en attente peut être réglée à tout moment depuis votre espace actionnaire (bouton « Payer (démo) »), et son statut y est suivi : intention, paiement en attente, paiement reçu, titres confirmés.</p>
            <p>Le formulaire de paiement s&apos;affiche dans le site, sans redirection vers une page externe.</p>
          </Encart>
        </div>
      </Section>

      <Section className="border-t border-gris-clair bg-clair-2">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <Titre sur="Parcours de souscription">Préparé pour un prestataire habilité</Titre>
            <ol className="space-y-3">
              {etapes.map(([t, d], i) => (
                <li key={t} className="flex gap-4 carte p-4">
                  <span className="display grid h-10 w-10 shrink-0 place-items-center bg-rouge text-xl font-900">{i + 1}</span>
                  <div><p className="display text-xl font-900">{t}</p><p className="text-sm text-ardoise-2">{d}</p></div>
                </li>
              ))}
            </ol>
            <p className="mt-3 text-xs text-gris">Variables d&apos;environnement prévues : SUBSCRIPTION_PROVIDER_URL, SUBSCRIPTION_PROVIDER_KEY (vides en démonstration).</p>
          </div>
          <div>
            <Titre sur="Droits attachés">Ce que disent les documents approuvés</Titre>
            <dl className="divide-y divide-gris-clair border border-gris-clair">
              {[["Droits de vote", droits.vote], ["Dividendes éventuels", droits.dividendes], ["Restrictions de cession", droits.cession], ["Modalités de sortie", droits.sortie]].map(([k, v]) => (
                <div key={k as string} className="flex items-center justify-between gap-4 px-4 py-3">
                  <dt className="text-ardoise-2">{k}</dt>
                  <dd className="text-right text-sm">{v ?? <span className="text-ambre">À définir dans les documents approuvés</span>}</dd>
                </div>
              ))}
            </dl>
            <Encart titre="Rappel" teinte="rouge">
              <p>Risque de perte partielle ou totale, absence de liquidité garantie, risque de dilution. Les avantages communautaires ne sont pas un rendement.</p>
            </Encart>
          </div>
        </div>
      </Section>
    </>
  );
}
