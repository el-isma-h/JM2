import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Section, Titre, Encart } from "@/components/ui";
import { FormulaireSimulation } from "@/components/FormulaireSimulation";
import { utilisateurCourant } from "@/lib/auth";
import { lireDb } from "@/lib/store";

export const metadata: Metadata = { title: "Paiement de démonstration" };
export const dynamic = "force-dynamic";

export default async function Simulation({ searchParams }: { searchParams: Promise<{ souscription?: string }> }) {
  const { souscription } = await searchParams;
  const user = await utilisateurCourant();
  if (!user) redirect("/connexion?retour=/investir");
  const db = await lireDb();
  const s = db.souscriptions.find((x) => x.id === souscription && x.userId === user.id);
  if (!s) redirect("/investir");
  return (
    <Section>
      <Titre as="h1" sur="Simulation de paiement">Stripe Checkout n&apos;est pas configuré</Titre>
      <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
        <FormulaireSimulation s={s} />
        <Encart titre="En production" teinte="rouge">
          <p>Une souscription d&apos;actions n&apos;est jamais encaissée par la plateforme : le paiement passe par le prestataire habilité, sur un compte séquestre, après identification et signature. Stripe sert ici uniquement à démontrer le parcours.</p>
        </Encart>
      </div>
    </Section>
  );
}
