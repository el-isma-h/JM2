import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Section, Titre, Encart, Badge, Bouton, dateFr } from "@/components/ui";
import { CheckoutEmbarque } from "@/components/CheckoutEmbarque";
import { FormulaireSimulation } from "@/components/FormulaireSimulation";
import { ExplicationPaiement } from "@/components/ExplicationPaiement";
import { preparerPaiement } from "@/lib/actions";
import { utilisateurCourant } from "@/lib/auth";
import { lireDb } from "@/lib/store";
import { clePubliableStripe } from "@/lib/stripe";
import { euros } from "@/lib/souscription";

export const metadata: Metadata = { title: "Paiement" };
export const dynamic = "force-dynamic";

/**
 * Page de paiement intégrée au site : récapitulatif de la souscription à gauche,
 * formulaire Stripe (iframe, mode test) ou simulation locale à droite, explication du parcours en dessous.
 */
export default async function Paiement({ searchParams }: { searchParams: Promise<{ souscription?: string }> }) {
  const { souscription } = await searchParams;
  const user = await utilisateurCourant();
  if (!user) redirect(`/connexion?retour=${encodeURIComponent(`/paiement?souscription=${souscription ?? ""}`)}`);
  const db = await lireDb();
  const s = db.souscriptions.find((x) => x.id === souscription && x.userId === user.id);
  if (!s) redirect("/espace");
  const dejaPaye = s.statut === "paiement_recu" || s.statut === "confirmee";
  const prep = dejaPaye || s.statut === "annulee" ? null : await preparerPaiement(s.id);
  if (prep?.mode === "heberge") redirect(prep.url);
  const clePubliable = clePubliableStripe();

  return (
    <>
      <Section className="pb-8">
        <Titre as="h1" sur="Démonstration — mode test">Paiement de votre souscription</Titre>
        <div className="grid gap-8 lg:grid-cols-[1fr_1.3fr] lg:items-start">
          <div className="space-y-4">
            <div className="carte p-6">
              <p className="display text-xl font-900">Récapitulatif</p>
              <dl className="mt-3 divide-y divide-gris-clair border-y border-gris-clair text-sm">
                <div className="flex justify-between py-2"><dt>Souscription</dt><dd className="font-mono text-xs">{s.id}</dd></div>
                <div className="flex justify-between py-2"><dt>Date</dt><dd>{dateFr(s.creeLe)}</dd></div>
                <div className="flex justify-between py-2"><dt>Actions</dt><dd>{s.actions} × {euros(s.montant / s.actions)}</dd></div>
                <div className="flex justify-between py-2"><dt>Frais (hypothèse)</dt><dd>{euros(s.frais)}</dd></div>
                <div className="flex justify-between py-2 font-900"><dt>Total (démonstration)</dt><dd>{euros(s.montant + s.frais)}</dd></div>
              </dl>
              <p className="mt-3 text-xs text-gris">Libellé Stripe : « Souscription d&apos;action — DÉMONSTRATION (aucun titre émis) ». Aucun débit réel.</p>
            </div>
            <Encart titre="Ce que ce paiement ne fait pas" teinte="ambre">
              <p>Il ne confirme aucun titre. Après paiement, votre souscription passe à « paiement reçu (démo) » ; vos titres ne sont « confirmés » qu&apos;après rapprochement par l&apos;administration avec la référence du prestataire habilité.</p>
            </Encart>
          </div>

          <div>
            {dejaPaye && (
              <div className="carte p-6">
                <Badge teinte="vert">{s.statut === "confirmee" ? "Titres confirmés" : "Paiement reçu (démo)"}</Badge>
                <p className="mt-3 text-ardoise-2">Cette souscription est déjà réglée. Retrouvez son statut dans votre espace.</p>
                <div className="mt-4"><Bouton href="/espace">Mon espace</Bouton></div>
              </div>
            )}
            {s.statut === "annulee" && (
              <div className="carte p-6">
                <Badge teinte="rouge">Annulée</Badge>
                <p className="mt-3 text-ardoise-2">Cette souscription a été annulée. Vous pouvez en créer une nouvelle depuis le simulateur.</p>
                <div className="mt-4"><Bouton href="/investir">Simulateur</Bouton></div>
              </div>
            )}
            {prep?.mode === "erreur" && (
              <div className="carte p-6">
                <Badge teinte="ambre">Paiement indisponible</Badge>
                <p className="mt-3 text-ardoise-2">{prep.erreur}</p>
                <div className="mt-4 flex gap-3"><Bouton href="/espace">Mon espace</Bouton><Bouton variante="contour" href="/investir">Simulateur</Bouton></div>
              </div>
            )}
            {prep?.mode === "embarque" && clePubliable && (
              <>
                <p className="mb-3 text-xs text-gris">Formulaire sécurisé Stripe (mode test), intégré au site. Carte de test : 4242 4242 4242 4242, date future, CVC quelconque.</p>
                <CheckoutEmbarque clePubliable={clePubliable} clientSecret={prep.clientSecret} />
              </>
            )}
            {prep?.mode === "simulation" && <FormulaireSimulation s={s} />}
          </div>
        </div>
      </Section>

      <Section className="border-t border-gris-clair bg-clair-2">
        <Titre sur="Comment ça marche">Le paiement, étape par étape</Titre>
        <div className="max-w-3xl"><ExplicationPaiement /></div>
      </Section>
    </>
  );
}
