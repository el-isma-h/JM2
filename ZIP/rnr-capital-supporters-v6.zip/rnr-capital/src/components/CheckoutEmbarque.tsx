"use client";

import { useMemo } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";

/**
 * Formulaire Stripe Checkout intégré dans le site (iframe Stripe, mode test).
 * Les données de carte ne transitent jamais par nos serveurs : elles sont saisies dans l'iframe Stripe.
 */
export function CheckoutEmbarque({ clePubliable, clientSecret }: { clePubliable: string; clientSecret: string }) {
  const stripePromise = useMemo(() => loadStripe(clePubliable), [clePubliable]);
  return (
    <div className="carte overflow-hidden p-2 sm:p-4" data-test="checkout-embarque">
      <EmbeddedCheckoutProvider stripe={stripePromise} options={{ clientSecret }}>
        <EmbeddedCheckout />
      </EmbeddedCheckoutProvider>
    </div>
  );
}
