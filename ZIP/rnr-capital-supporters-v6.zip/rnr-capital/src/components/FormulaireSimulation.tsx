import { FormulaireAction, champ, etiquette } from "@/components/FormulaireAction";
import { confirmerPaiementSimule } from "@/lib/actions";
import type { Souscription } from "@/lib/store";
import { euros } from "@/lib/souscription";

/** Formulaire de paiement simulé (sans clé Stripe), partagé par /paiement et /paiement/simulation. */
export function FormulaireSimulation({ s }: { s: Souscription }) {
  return (
    <div className="carte p-6" data-test="paiement-simulation">
      <p className="text-sm text-gris">Formulaire de simulation : aucune clé Stripe de test (<code>STRIPE_SECRET_KEY</code> / <code>NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY</code>) n&apos;est renseignée. Rien n&apos;est débité, aucun titre n&apos;est émis.</p>
      <dl className="mt-4 divide-y divide-gris-clair border-y border-gris-clair text-sm">
        <div className="flex justify-between py-2"><dt>Souscription</dt><dd>{s.id}</dd></div>
        <div className="flex justify-between py-2"><dt>Actions</dt><dd>{s.actions}</dd></div>
        <div className="flex justify-between py-2 font-900"><dt>Montant (démonstration)</dt><dd>{euros(s.montant + s.frais)}</dd></div>
      </dl>
      <FormulaireAction action={confirmerPaiementSimule} libelle="Payer (test)">
        <input type="hidden" name="souscription" value={s.id} />
        <label htmlFor="carte" className={`${etiquette} mt-4`}>Numéro de carte de test</label>
        <input id="carte" name="carte" defaultValue="4242 4242 4242 4242" readOnly className={champ} />
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div><label htmlFor="exp" className={etiquette}>Expiration</label><input id="exp" defaultValue="12/34" readOnly className={champ} /></div>
          <div><label htmlFor="cvc" className={etiquette}>CVC</label><input id="cvc" defaultValue="123" readOnly className={champ} /></div>
        </div>
        <label className="mt-3 flex items-center gap-2 text-sm"><input type="radio" name="resultat" value="succes" defaultChecked /> Simuler un paiement réussi</label>
        <label className="mt-1 flex items-center gap-2 text-sm"><input type="radio" name="resultat" value="echec" /> Simuler un paiement refusé</label>
      </FormulaireAction>
    </div>
  );
}
