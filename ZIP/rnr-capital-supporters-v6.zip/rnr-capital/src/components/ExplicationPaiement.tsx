import { Encart } from "@/components/ui";

/**
 * Explication du paiement, réutilisée sur la page Investir, la page /paiement et l'espace actionnaire.
 * Texte volontairement prudent : démonstration, aucun encaissement réel, titres confirmés uniquement après rapprochement.
 */
export const etapesPaiement: [string, string][] = [
  ["Je choisis mon nombre d'actions", "Depuis le simulateur de la page Investir, après avoir lu les informations sur les risques. Une intention de souscription est enregistrée dans mon espace."],
  ["Je paie sans quitter le site", "Le formulaire de paiement s'affiche directement sur la page Paiement du site (Stripe en mode test, ou simulation locale sans clé). Les données de carte sont saisies dans un cadre sécurisé Stripe : elles ne transitent jamais par la plateforme."],
  ["Le paiement est enregistré comme « reçu »", "Stripe confirme le paiement au serveur (vérification de la session et webhook). Ma souscription passe au statut « paiement reçu (démo) » dans mon espace."],
  ["Mes titres sont confirmés par rapprochement", "L'administration rapproche le paiement avec la référence du prestataire habilité. Ce n'est qu'à ce moment que mes titres sont « confirmés » et que mon statut et mes avantages s'activent."],
];

export function ExplicationPaiement({ compact = false }: { compact?: boolean }) {
  return (
    <div>
      <ol className={compact ? "space-y-2" : "space-y-3"}>
        {etapesPaiement.map(([t, d], i) => (
          <li key={t} className={`flex gap-4 carte ${compact ? "p-3" : "p-4"}`}>
            <span className={`display grid shrink-0 place-items-center bg-rouge font-900 text-blanc ${compact ? "h-8 w-8 text-base" : "h-10 w-10 text-xl"}`}>{i + 1}</span>
            <div>
              <p className={`display font-900 ${compact ? "text-base" : "text-xl"}`}>{t}</p>
              <p className={`text-ardoise-2 ${compact ? "text-xs" : "text-sm"}`}>{d}</p>
            </div>
          </li>
        ))}
      </ol>
      <div className="mt-4">
      <Encart titre="En production" teinte="rouge">
        <p>Une souscription d&apos;actions n&apos;est jamais encaissée par la plateforme : le paiement passe par le prestataire habilité, sur un compte séquestre, après identification et signature. Stripe sert ici uniquement à démontrer le parcours, en mode test : aucun débit réel, aucun titre émis.</p>
      </Encart>
      </div>
    </div>
  );
}
