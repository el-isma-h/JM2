# Lions Capital — plateforme de démonstration (projet non officiel)

Plateforme de financement participatif en capital et de communauté de supporters autour du Rouen Normandie Rugby, livrée **en démonstration** : données fictives étiquetées, aucun encaissement, aucune émission de titres, aucun lot ni partenariat présenté comme acquis.

Site officiel de référence : https://rouennormandierugby.fr/. Charte relevée dans le navigateur le 15/10/2026 et reprise fidèlement : rouge `#e21e26`, fond clair `#f8f9fa` / `#f1f5f9`, texte ardoise `#0f172a`, sections sombres noires sur photo avec cartes « verre » arrondies, accent or `#ffd700`, titres **Outfit 900 italique capitales**, corps **Inter**, étiquettes **Barlow Condensed**, pastilles de score rouges, bandeau « prochain match » biseauté, menu burger plein écran, liens rapides Boutique / Billetterie, pied de page clair en colonnes.

**Logo et photos (v4)** : logo officiel RNR (`public/images/logo-rnr.svg`, SVG blanc) dans l'en-tête, le menu, le hero et le pied de page ; photos du club en fond du hero (stade de nuit), de la section résultats (tribunes), des statuts (mascotte), de la page Projet (staff) et de la page Lots (fond doré). Crédits et conditions dans `public/images/CREDITS.md` : usage en démonstration, autorisation écrite du club requise avant mise en ligne.

**CUPRA en 3D (v5)** : le véhicule envisagé est désormais le modèle 3D CUPRA Formentor 2021 transmis par le porteur du projet (FBX converti en glTF, ~140 000 triangles, 1,2 Mo), affiché sur la page Lots et dans la vignette de l'accueil, toujours avec la mention « lot envisagé, partenariat non signé ».

**Accueil** : « Le projet en trois étapes » (je souscris / je deviens membre / je joue gratuitement + ce que vous achetez / gagnez / risquez), collecte, section « Les résultats » identique au site officiel (position, derniers résultats, statistiques) complétée par la **courbe des performances** (différence de points cumulée, victoires en vert, points marqués / concédés par journée), statuts, lots en 3D, actualités.

## Lancer

```bash
npm install
cp .env.example .env.local   # facultatif en démonstration
npm run dev                  # http://localhost:3000
```

Au premier démarrage, la base SQLite `data/lions-capital.sqlite` est créée à partir des données fictives (`src/lib/seed.ts`). Pour repartir de zéro : « Réinitialiser » dans l'administration (ou supprimer le fichier et redémarrer).

**Paiement de démonstration, intégré au site (v6)** : la page `/paiement?souscription=…` affiche le récapitulatif de la souscription et le formulaire de paiement **sans quitter le site**. Avec `STRIPE_SECRET_KEY=sk_test_…` **et** `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_…`, c'est Stripe Embedded Checkout (iframe Stripe, mode test, carte 4242…) ; avec la clé secrète seule, Stripe Checkout hébergé ; sans clé, la simulation locale s'affiche dans la même page. Le webhook est sur `/api/stripe/webhook` (`stripe listen --forward-to localhost:3000/api/stripe/webhook`) et le retour `/paiement/retour` vérifie la session côté serveur. Depuis l'espace actionnaire, chaque souscription en attente a un bouton « Payer (démo) ». Le parcours est expliqué en quatre étapes sur la page Investir, la page Paiement, l'espace actionnaire et la FAQ. Un paiement reçu n'est jamais une confirmation de titres : le rapprochement avec le prestataire habilité reste obligatoire.

**E-mails** : sans `RESEND_API_KEY`, les e-mails (confirmation d'adresse, mot de passe oublié) sont consignés dans l'administration, onglet « emails ».

Comptes de démonstration (à supprimer avant toute mise en production) :

| Rôle | E-mail | Mot de passe | Code admin |
| --- | --- | --- | --- |
| supporter | supporter@demo.rnr | demo1234 | — |
| actionnaire | actionnaire@demo.rnr | demo1234 | — |
| admin | admin@demo.rnr | demo1234 | 246810 |

## Vérifier

```bash
npm run test        # 18 tests unitaires (clôture, départage, égalités, matchs reportés, simulateur, budget)
npm run lint
npm run typecheck
npm run build
```

Deux scénarios de bout en bout ont été joués avec Playwright (Chromium) : v1 (inscription gratuite, pronostic, clôture serveur, connexion admin à deux facteurs, saisie et correction de résultat, rapprochement, espace actionnaire) et v2 (confirmation d'adresse par lien, paiement simulé, profil, rapprochement avec référence, édition d'un avantage, export CSV, réservation d'un avantage confirmé, rendu des scènes 3D).

## Structure

- `src/config/campagne.ts` — **toutes les hypothèses configurables** : émetteur pressenti, prix d'action, paliers, objectif, dates, utilisation des fonds, budget, droits (vides), clôture des pronostics, définition du score.
- `src/data/statuts.ts`, `src/data/lots.ts` — valeurs initiales des statuts, lots et partenaires, copiées en base au premier démarrage puis administrables.
- `src/data/matchs.ts` — calendrier Nationale 2026-2027 relevé sur le site du club, classement relevé, objectifs de saison (hypothèse).
- `src/data/lots.ts` — lot principal (champs contractuels vides), lots secondaires, partenaires du club / de l'opération / à démarcher.
- `src/data/contenus.ts` — actualités (démo), FAQ, documents de l'opération, risques, module Olympique de Marseille.
- `src/lib/concours.ts` — moteur du concours (fonctions pures) ; `src/lib/souscription.ts` — simulateur et budget.
- `src/lib/store.ts` — SQLite (better-sqlite3), une table par collection ; `src/lib/actions.ts` — actions serveur (toutes journalisées) ; `src/lib/auth.ts` — sessions signées, rôle, deuxième facteur admin ; `src/lib/stripe.ts` — Checkout test + webhook + simulation ; `src/lib/email.ts` — Resend ou journal.
- `src/components/3d/` — **CUPRA Formentor en 3D (v5)** : modèle fourni par le porteur du projet (`public/models/cupra-formentor.glb`, glTF compressé Draco, décodeur servi localement depuis `public/draco/`), chargé par `VoitureGLB.tsx` ; la berline stylisée `Voiture.tsx` sert de substitut pendant le chargement et de secours si le fichier ne charge pas. Lots (maillot, ballon, panier, équipement) modélisés par le code (React Three Fiber), podium cliquable, secours sans WebGL ou mouvement réduit. Conditions d'usage du modèle : `public/models/CREDITS.md`.
- Comptes : vérification d'adresse, mot de passe oublié, profil, changement de mot de passe, suppression (RGPD) ; administration : comptes, avantages, lots, fiche du lot principal, partenaires, e-mails, exports CSV, courbe de collecte.
- `src/app/` — pages : accueil, projet, investir, statuts, matchs (pronostics), classement, lots, actualités, FAQ, documents, mentions légales, connexion, espace (actionnaire), admin.
- `docs/MISE-EN-PRODUCTION.md` — configuration et intégrations ; `docs/DECISIONS-CLUB.md` — accords, contrats et décisions encore nécessaires.

## Règles appliquées dans le code

- Promesses, paiements reçus et capital définitivement souscrit sont toujours distingués ; les chiffres de démonstration sont étiquetés.
- Aucun pourcentage de détention tant que le capital social et la dilution ne sont pas connus ; aucune valorisation ni « valeur après victoire ».
- Concours gratuit entièrement séparé de l'investissement ; clôture contrôlée par l'horloge du serveur ; seuls les résultats **vérifiés** comptent ; départage déterministe publié.
- Aucune modification silencieuse : résultats, statuts de match et souscriptions exigent un motif ou une référence et sont journalisés avec l'état précédent. Les pronostics clôturés ne sont modifiables par personne.
- Réservation d'un avantage possible uniquement si le statut est atteint par des titres confirmés **et** si l'avantage est confirmé par le club.
