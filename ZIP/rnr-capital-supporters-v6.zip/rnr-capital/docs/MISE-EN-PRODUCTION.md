# Configuration et mise en production

Rien ici ne doit être activé avant : accord écrit de la SAS Rouen Normandie Rugby, validation juridique de l'opération, contractualisation des partenaires.

## 1. Variables d'environnement (`.env.local`)

| Variable | Rôle | Démonstration |
| --- | --- | --- |
| `SESSION_SECRET` | Signature des cookies de session | valeur par défaut, à remplacer par 64 caractères aléatoires |
| `APP_MODE` | `demo` ou `production` ; en `production`, les messages « démonstration » des actions disparaissent | `demo` |
| `SUBSCRIPTION_PROVIDER_URL` / `_KEY` | Prestataire habilité (souscription, KYC, séquestre, signature) | vide |
| `RESULTS_SOURCE_URL` | Source officielle des résultats | vide (saisie admin vérifiée) |
| `RESEND_API_KEY` / `MAIL_FROM` | E-mails transactionnels | vide (journal dans l'administration) |
| `NEXT_PUBLIC_BASE_URL` | URL publique pour les liens d'e-mail et retours Stripe | déduite de la requête |
| `STRIPE_SECRET_KEY` / `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` / `STRIPE_WEBHOOK_SECRET` | Stripe **mode test uniquement** (démonstration du parcours) ; avec la clé secrète et la clé publiable, le formulaire Stripe est intégré dans la page `/paiement` du site (Embedded Checkout) ; avec la clé secrète seule, Checkout hébergé | vide (simulation locale dans `/paiement`) |

## 2. Base de données

Le stockage est SQLite (better-sqlite3, `data/lions-capital.sqlite`, une table par collection, documents JSON, écritures en transaction). Pour la production : Postgres (Prisma ou Drizzle) avec un schéma relationnel reprenant les mêmes collections — users, participants, pronostics, souscriptions, réservations, matchs, statuts, lots, partenaires, jetons, emails, audit, paramètres.

Le journal d'audit doit devenir une table en ajout seul (append-only), sans droit de suppression applicatif.

## 3. Authentification

- Mots de passe : scrypt (déjà en place). Ajouter la vérification d'e-mail à l'inscription et la réinitialisation de mot de passe.
- Administrateurs : remplacer le code fixe de démonstration par un vrai deuxième facteur (TOTP ou passkeys), limiter les tentatives, journaliser chaque connexion (déjà fait).
- Rôles distincts à prévoir : administrateur général, gestionnaire sportif (résultats), gestionnaire financier (souscriptions), support.
- Supprimer les comptes de démonstration (`src/lib/seed.ts`, `COMPTES_DEMO`) et l'encart de la page connexion.

## 4. Souscription (prestataire habilité) et Stripe

**Stripe est présent uniquement en mode test pour démontrer le parcours.** Une souscription d'actions ne doit pas être encaissée par la plateforme en production : désactiver `stripeDemoActif` dans l'administration et retirer les clés. Si le club souhaite malgré tout utiliser Stripe pour des produits annexes (dons, billetterie d'événements), cela se fait avec une validation juridique distincte.

Le parcours est préparé en six étapes (`/investir`). La plateforme ne doit **jamais** encaisser : l'intention est transmise au prestataire (`creerIntentionSouscription` dans `src/lib/actions.ts`), qui gère identification, documents, information sur les risques, signature, paiement sur compte séquestre et confirmation. Le rapprochement (statut `confirmee` + référence prestataire) alimente ensuite les titres détenus et active le statut communautaire. Prévoir un webhook du prestataire vers une route `/api/souscriptions/webhook` (à créer) qui appelle la même logique que `changerStatutSouscription`, avec signature vérifiée.

## 5. Résultats sportifs

En démonstration, les résultats passés viennent du site du club et sont marqués « vérifiés » pour illustrer le classement. En production : brancher la source officielle (API fédérale ou flux validé), **ou** conserver la saisie manuelle avec double validation. Toute correction exige un motif et est journalisée.

## 6. Concours gratuit

- Faire valider le règlement et la qualification juridique avant toute activation publique avec des lots (`parametres.lotsActifs`).
- Clôture : `campagne.clotureMinutesAvantCoupDEnvoi` (15 min) ; l'horloge du serveur fait foi ; le fuseau affiché est Europe/Paris.
- Anti-comptes multiples en production : vérification d'e-mail, limitation par IP et empreinte d'appareil, revue manuelle des gagnants avant remise.
- Reports : changer le statut en « reporté » avec la nouvelle date ; les pronostics existants restent modifiables jusqu'à la nouvelle clôture. Annulé / forfait : le match ne compte pas.

## 7. E-mails et notifications

Aucun e-mail n'est envoyé en démonstration. À brancher : confirmation d'inscription, rappel de clôture, confirmation d'intention et de titres, réservation d'avantage, notifications administrateur.

## 8. Hébergement et conformité

- Hébergement Node (Vercel, ou conteneur Docker à ajouter) avec HTTPS, `SESSION_SECRET` en secret.
- Mentions légales, politique de confidentialité, registre des traitements, DPO : à compléter (`/mentions-legales`).
- Robots : la démonstration est en `noindex` (`src/app/layout.tsx`). Retirer en production **uniquement** après autorisation du club.
- Médias : aucun logo ni photographie officiels. Pour les photos, déposer les fichiers autorisés dans `public/images` et passer `photo="/images/…"` au composant `VisuelStade`.

## 9. Ce qui n'a pas été vérifié

Appel réel à un prestataire, e-mails, montée en charge, navigateurs Safari / Firefox et appareils réels (tests sous Chromium headless uniquement), audit d'accessibilité complet (contrastes et clavier vérifiés par construction, pas par outil).
