import { describe, it, expect } from "vitest";
import { classer, saisieOuverte, dateCloture, evaluer, matchComptabilise, validerScore, type Pronostic, type Participant } from "@/lib/concours";
import type { Match } from "@/data/matchs";

const m = (id: string, sd?: number, se?: number, extra: Partial<Match> = {}): Match => ({
  id, journee: 1, coupDEnvoi: "2026-10-16T20:00:00+02:00", domicile: "Rouen", exterieur: "Rennes", lieu: "Stade", competition: "Nationale",
  statut: sd === undefined ? "a_venir" : "termine", scoreDomicile: sd, scoreExterieur: se, resultatVerifie: sd !== undefined, ...extra,
});
const p = (id: string, inscritLe: string): Participant => ({ id, pseudo: id, inscritLe });
const pr = (userId: string, matchId: string, sd: number, se: number): Pronostic => ({ id: `${userId}-${matchId}`, userId, matchId, scoreDomicile: sd, scoreExterieur: se, modifieLe: "2026-10-01T00:00:00Z" });

describe("clôture des pronostics", () => {
  it("ferme 15 minutes avant le coup d'envoi (heure de Paris)", () => {
    const match = m("j08");
    expect(dateCloture(match, 15).toISOString()).toBe("2026-10-16T17:45:00.000Z");
    expect(saisieOuverte(match, 15, new Date("2026-10-16T17:44:59Z"))).toBe(true);
    expect(saisieOuverte(match, 15, new Date("2026-10-16T17:45:00Z"))).toBe(false);
  });
  it("ferme pour un match terminé, annulé ou forfait", () => {
    expect(saisieOuverte(m("a", 10, 3), 15, new Date("2020-01-01"))).toBe(false);
    expect(saisieOuverte(m("b", undefined, undefined, { statut: "annule" }), 15, new Date("2020-01-01"))).toBe(false);
    expect(saisieOuverte(m("c", undefined, undefined, { statut: "forfait" }), 15, new Date("2020-01-01"))).toBe(false);
  });
  it("un match reporté sans nouvelle date reste fermé si la date initiale est passée, ouvert sinon", () => {
    const reporte = m("d", undefined, undefined, { statut: "reporte" });
    expect(saisieOuverte(reporte, 15, new Date("2026-10-01T00:00:00Z"))).toBe(true);
    expect(saisieOuverte(reporte, 15, new Date("2026-12-01T00:00:00Z"))).toBe(false);
  });
});

describe("évaluation", () => {
  it("un score exact rapporte 1 point, écart 0", () => {
    expect(evaluer(pr("u", "a", 31, 45), m("a", 31, 45))).toEqual({ exact: true, ecart: 0 });
  });
  it("l'écart est la somme des écarts absolus", () => {
    expect(evaluer(pr("u", "a", 30, 40), m("a", 31, 45))).toEqual({ exact: false, ecart: 6 });
  });
  it("un résultat non vérifié ne compte pas", () => {
    const nonVerifie = m("a", 31, 45, { resultatVerifie: false });
    expect(matchComptabilise(nonVerifie)).toBe(false);
    expect(evaluer(pr("u", "a", 31, 45), nonVerifie).exact).toBe(false);
  });
  it("valide les scores entiers de 0 à 150", () => {
    expect(validerScore(0)).toBe(true);
    expect(validerScore(150)).toBe(true);
    expect(validerScore(-1)).toBe(false);
    expect(validerScore(12.5)).toBe(false);
    expect(validerScore("3")).toBe(false);
  });
});

describe("classement et départage", () => {
  const matchs = [m("a", 20, 10), m("b", 15, 15), m("c")];
  it("classe par points puis écart cumulé puis inscription", () => {
    const participants = [p("x", "2026-10-02T00:00:00Z"), p("y", "2026-10-01T00:00:00Z"), p("z", "2026-10-03T00:00:00Z")];
    const pronos = [
      pr("x", "a", 20, 10), pr("x", "b", 10, 10), // 1 pt, écart 10
      pr("y", "a", 20, 10), pr("y", "b", 14, 15), // 1 pt, écart 1
      pr("z", "a", 20, 10), pr("z", "b", 15, 15), // 2 pts
    ];
    const c = classer(participants, pronos, matchs);
    expect(c.map((l) => l.userId)).toEqual(["z", "y", "x"]);
    expect(c.map((l) => l.rang)).toEqual([1, 2, 3]);
  });
  it("à points et écart égaux, l'inscription la plus ancienne l'emporte", () => {
    const participants = [p("tard", "2026-10-05T00:00:00Z"), p("tot", "2026-10-01T00:00:00Z")];
    const pronos = [pr("tard", "a", 19, 10), pr("tot", "a", 20, 9)];
    const c = classer(participants, pronos, matchs);
    expect(c[0].userId).toBe("tot");
  });
  it("un participant sans pronostic évalué est classé après ceux qui ont joué", () => {
    const participants = [p("vide", "2026-09-01T00:00:00Z"), p("joue", "2026-10-01T00:00:00Z")];
    const c = classer(participants, [pr("joue", "a", 0, 0)], matchs);
    expect(c[0].userId).toBe("joue");
  });
  it("les matchs à venir, reportés ou annulés sont ignorés", () => {
    const participants = [p("u", "2026-10-01T00:00:00Z")];
    const annule = m("k", 3, 3, { statut: "annule" });
    const c = classer(participants, [pr("u", "c", 1, 1), pr("u", "k", 3, 3)], [...matchs, annule]);
    expect(c[0].points).toBe(0);
    expect(c[0].pronosticsEvalues).toBe(0);
  });
});
