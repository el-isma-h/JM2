import { describe, it, expect } from "vitest";
import { simuler, budget, prochainStatut, statutPour } from "@/lib/souscription";

describe("simulateur de souscription", () => {
  it("calcule les paliers du cahier des charges", () => {
    for (const [n, attendu] of [[1, 100], [5, 500], [10, 1000], [25, 2500], [50, 5000], [100, 10000]] as const) {
      expect(simuler(n).montantActions).toBe(attendu);
    }
  });
  it("associe le bon statut à chaque palier", () => {
    expect(statutPour(1)?.id).toBe("supporter");
    expect(statutPour(4)?.id).toBe("supporter");
    expect(statutPour(5)?.id).toBe("cercle");
    expect(statutPour(10)?.id).toBe("privilege");
    expect(statutPour(49)?.id).toBe("privilege");
    expect(statutPour(50)?.id).toBe("business");
    expect(statutPour(100)?.id).toBe("ambassadeur");
    expect(statutPour(0)).toBeNull();
  });
  it("borne le nombre d'actions", () => {
    expect(simuler(0).actions).toBe(1);
    expect(simuler(9999).actions).toBe(500);
    expect(simuler(3.9).actions).toBe(3);
  });
  it("n'affiche jamais un pourcentage de détention sans capital connu", () => {
    expect(simuler(100).pourcentageDetention).toBeNull();
  });
  it("indique le prochain statut", () => {
    expect(prochainStatut(7)).toMatchObject({ actionsManquantes: 3 });
    expect(prochainStatut(100)).toBeNull();
  });
  it("cumule les avantages des statuts inférieurs", () => {
    expect(simuler(10).avantages.map((a) => a.statut.id)).toEqual(["supporter", "cercle", "privilege"]);
  });
});

describe("budget de transparence", () => {
  it("déduit frais, avantages et lots de la collecte brute", () => {
    const b = budget(500_000);
    expect(b.fraisOperation).toBe(25_000);
    expect(b.net).toBe(500_000 - 25_000 - b.coutAvantages - b.coutLots);
  });
});
