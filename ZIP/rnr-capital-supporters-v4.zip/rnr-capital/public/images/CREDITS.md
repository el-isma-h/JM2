Photos et logo : © Rouen Normandie Rugby, relevés sur rouennormandierugby.fr le 16/10/2026 pour la démonstration.
Usage soumis à l'autorisation écrite du club avant toute mise en ligne publique (voir docs/DECISIONS-CLUB.md, point 2).
- logo-rnr.svg : tête de lion du logo officiel (couleur héritée via currentColor)
- stade.jpg : stade Robert-Diochon, vue aérienne de nuit
- club.jpg : entrée des joueurs, tribunes
- equipe.jpg : staff et direction (article « La nouvelle ère du RNR »)
- mascotte.jpg : mascotte et jeunes licenciés
- vip.jpg : fond doré du bloc Business Club
