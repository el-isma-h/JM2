/**
 * HYPOTHÈSES CONFIGURABLES DE L'OPÉRATION
 * ------------------------------------------------------------------
 * Tout ce qui figure ici est une hypothèse de travail fournie par le
 * porteur du projet. Rien n'est validé par la SAS Rouen Normandie Rugby.
 * Chaque valeur est reprise telle quelle par l'interface ; modifier ici
 * suffit à mettre à jour l'ensemble du site.
 */

export type StatutValidation = "hypothese" | "a_valider" | "valide";

export const MODE_DEMO = process.env.APP_MODE !== "production";

export const campagne = {
  /** Nom de la plateforme (projet non officiel tant que le club n'a pas autorisé). */
  nom: "Lions Capital",
  slogan: "Ensemble, écrivons la prochaine saison des Lions.",
  bandeauNonOfficiel: "Projet de plateforme — non officiel",

  /** Émetteur pressenti : à confirmer par le montage juridique retenu. */
  emetteur: {
    denomination: "SAS Rouen Normandie Rugby",
    presidente: "Delphine Bunel",
    forme: "Société par actions simplifiée",
    /** Montage effectivement retenu : "direct" (augmentation de capital de la SAS) ou "vehicule" (holding de supporters). Inconnu à ce stade. */
    montage: "a_definir" as "direct" | "vehicule" | "a_definir",
    capitalSocialConnu: false,
    validation: "a_valider" as StatutValidation,
  },

  /** Prix de souscription envisagé par action, en euros. Hypothèse. */
  prixAction: 100,
  /** Valeur nominale : inconnue tant que le capital social et la parité ne sont pas communiqués. */
  valeurNominale: null as number | null,
  /** Frais de souscription envisagés (part fixe + pourcentage). Hypothèse : à aligner sur le prestataire. */
  frais: { fixe: 0, pourcentage: 0 },
  /** Paliers proposés (nombre d'actions). */
  paliers: [1, 5, 10, 25, 50, 100],
  minimumActions: 1,
  maximumActionsParPersonne: 500,

  /** Objectif de financement : hypothèse, à valider par le club. */
  objectif: { montant: 500_000, validation: "hypothese" as StatutValidation },

  /** Dates envisagées de l'opération : hypothèse. */
  dates: {
    ouverture: "2026-11-16",
    cloture: "2027-02-28",
    validation: "hypothese" as StatutValidation,
  },

  /** Utilisation prévisionnelle des fonds : hypothèse, à valider par la direction. */
  utilisationFonds: [
    { poste: "Renforcement des fonds propres", part: 0.4 },
    { poste: "Trésorerie d'exploitation de la saison", part: 0.3 },
    { poste: "Centre de formation et académie", part: 0.15 },
    { poste: "Développement commercial et communauté", part: 0.1 },
    { poste: "Frais de l'opération", part: 0.05 },
  ],

  /** Budget de transparence (hypothèse). Les montants sont des estimations à faire valider. */
  budget: {
    fraisOperationPct: 0.05,
    coutAvantagesEstime: 48_000,
    coutLotsEstime: 0, // aucun lot contractuellement sécurisé
    frequenceComptesRendus: "trimestrielle",
  },

  /** Rôles et droits : doivent provenir des documents approuvés. Tant que vide, l'interface affiche « à définir dans les documents approuvés ». */
  droits: {
    vote: null as string | null,
    dividendes: null as string | null,
    cession: null as string | null,
    sortie: null as string | null,
  },

  /** Fuseau de référence de la plateforme et du concours. */
  fuseau: "Europe/Paris",
  /** Clôture des pronostics : minutes avant le coup d'envoi. */
  clotureMinutesAvantCoupDEnvoi: 15,
  /** Définition du score retenu au règlement (hypothèse, à valider). */
  definitionScore: "fin du temps réglementaire (80 min), prolongations exclues",
} as const;

export const liensOfficiels = {
  site: "https://rouennormandierugby.fr/",
  billetterie: "https://billetterie.rouen-normandie-rugby.fr",
  boutique: "https://boutique.rouennormandierugby.fr/",
  partenaires: "https://rouennormandierugby.fr/partenaires/entreprises",
  calendrier: "https://rouennormandierugby.fr/equipe-pro/calendrier",
  classement: "https://rouennormandierugby.fr/equipe-pro/classement",
  contact: "https://rouennormandierugby.fr/contact",
};
