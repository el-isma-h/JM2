/** Actualités du projet (démonstration), FAQ, documents et module OM. */

export interface Actualite {
  slug: string;
  date: string;
  titre: string;
  chapo: string;
  corps: string[];
  /** Toujours true en démonstration : contenu fictif à remplacer. */
  demo: boolean;
}

export const actualites: Actualite[] = [
  {
    slug: "lancement-du-projet",
    date: "2026-10-15",
    titre: "Un projet de plateforme pour ouvrir le capital aux supporters",
    chapo: "Première présentation du dispositif : actionnariat populaire, statuts communautaires et concours gratuit.",
    corps: [
      "Cette plateforme est un projet présenté à la direction du Rouen Normandie Rugby. Elle n'est ni validée ni officielle.",
      "Elle réunit trois volets distincts : une souscription d'actions à partir de 100 € (hypothèse), des statuts communautaires avec des avantages rugby, et un concours gratuit de pronostics ouvert à tous.",
    ],
    demo: true,
  },
  {
    slug: "ce-qui-reste-a-decider",
    date: "2026-10-15",
    titre: "Ce que le club doit décider avant toute ouverture",
    chapo: "Montage juridique, objectif, calendrier, grille d'avantages, règlement du concours.",
    corps: [
      "Le montage juridique (augmentation de capital de la SAS ou véhicule de supporters), le prestataire habilité, l'objectif et les dates sont des hypothèses de travail.",
      "La liste complète figure dans la page « Documents et risques » et dans la documentation livrée.",
    ],
    demo: true,
  },
];

export interface Faq { question: string; reponse: string }

export const faq: Faq[] = [
  { question: "Est-ce le site officiel du Rouen Normandie Rugby ?", reponse: "Non. Il s'agit d'un projet de plateforme présenté au club. Il devient officiel uniquement si la SAS Rouen Normandie Rugby l'autorise." },
  { question: "Que détient-on en souscrivant des actions ?", reponse: "Cela dépend du montage retenu par le club : une participation directe dans la SAS Rouen Normandie Rugby, ou une part d'un véhicule d'investissement qui détient lui-même des actions du club. Le montage n'est pas arrêté : aucune souscription n'est possible." },
  { question: "Le prix de 100 € est-il définitif ?", reponse: "Non. C'est un prix de souscription envisagé. Il ne correspond ni à la valeur nominale (inconnue) ni à une valeur estimée de l'action." },
  { question: "Puis-je revendre mes actions ?", reponse: "Il n'existe aucun marché ni prix de cession garanti. Les restrictions de cession et les modalités de sortie seront fixées par les documents approuvés." },
  { question: "Mes actions prennent-elles de la valeur si le club monte en Pro D2 ?", reponse: "Rien ne le garantit. Une performance sportive ne se traduit pas mécaniquement par une hausse de valeur, et un prix de revente n'est jamais assuré. Le risque de perte partielle ou totale existe." },
  { question: "Les avantages sont-ils acquis pour toujours ?", reponse: "Non. L'investissement est ponctuel ; les avantages sont définis pour une saison précise, avec une durée, une quantité et des conditions affichées pour chacun." },
  { question: "Faut-il acheter des actions pour participer au concours de pronostics ?", reponse: "Non. Le concours est gratuit, sans achat, don ni abonnement. Tous les participants ont les mêmes règles, les mêmes lots et les mêmes chances ; les actionnaires n'ont aucun avantage de classement." },
  { question: "Comment sont départagées les égalités au concours ?", reponse: "D'abord par le nombre de scores exacts, puis par le plus faible écart cumulé aux scores réels, puis par un critère subsidiaire objectif fixé au règlement (en démonstration : date d'inscription la plus ancienne)." },
  { question: "La CUPRA est-elle réellement à gagner ?", reponse: "Non à ce stade. Il s'agit d'un lot envisagé : le partenariat n'est pas signé et l'attribution n'est pas garantie. CUPRA n'est pas sponsor du club." },
  { question: "L'accès aux matchs de l'OM est-il inclus ?", reponse: "Non. C'est un projet à négocier, non inclus dans l'offre actuelle, et aucune affiliation avec l'Olympique de Marseille n'existe." },
];

export interface DocumentOp {
  titre: string;
  description: string;
  statut: "disponible" | "a_produire" | "a_valider";
  fichier?: string;
}

export const documentsOperation: DocumentOp[] = [
  { titre: "Note d'information sur les risques", description: "Perte partielle ou totale, absence de liquidité, dilution, absence de dividendes garantis.", statut: "a_produire" },
  { titre: "Statuts de l'émetteur", description: "Statuts de la SAS Rouen Normandie Rugby ou du véhicule d'investissement retenu.", statut: "a_valider" },
  { titre: "Décision d'augmentation de capital", description: "Décision des associés fixant le nombre d'actions, le prix et le calendrier.", statut: "a_produire" },
  { titre: "Conditions de souscription", description: "Droits de vote, dividendes éventuels, restrictions de cession, modalités de sortie.", statut: "a_produire" },
  { titre: "Grille des avantages approuvée et budgétée", description: "Version validée par le club avec capacités et coûts.", statut: "a_valider" },
  { titre: "Règlement du concours gratuit", description: "Règlement à faire valider juridiquement avant toute activation publique avec des lots.", statut: "a_produire" },
  { titre: "Politique de confidentialité et mentions légales", description: "Identité de l'éditeur, hébergeur, traitement des données.", statut: "a_produire" },
];

export const risques = [
  "Perte partielle ou totale du capital investi.",
  "Absence de liquidité : aucun marché, aucun prix de cession garanti.",
  "Dilution en cas d'opérations ultérieures sur le capital.",
  "Aucun dividende garanti ; un club sportif ne distribue pas nécessairement de résultat.",
  "Les avantages communautaires ne constituent pas un rendement et sont limités à la saison définie.",
  "L'opération n'existe pas tant qu'elle n'est pas validée par le club et encadrée par un prestataire habilité.",
];

/** Module Olympique de Marseille : administrable, désactivé par défaut. */
export const avantageOM = {
  actif: false,
  statut: "Projet à négocier — non inclus dans l'offre actuelle",
  seuilActions: 10,
  options: [
    { id: "abonnement", titre: "Abonnement aux matchs à domicile de l'OM", detail: "Uniquement si un accord, un droit de distribution et un budget le permettent réellement.", stade: null, competitions: null, saison: null, exclusions: null, confirme: false },
    { id: "quota", titre: "Quota d'invitations ou expériences ponctuelles", detail: "Alternative si l'abonnement n'est pas retenu.", confirme: false },
  ],
  alternativeRugby: {
    titre: "Alternative rugby",
    detail: "Un déplacement accompagné des supporters sur un match extérieur des Lions, ou une invitation à une rencontre de Top 14 / Pro D2 négociée avec un club partenaire. À valider.",
  },
  mentions: "Aucune affiliation avec l'Olympique de Marseille. Le logo de l'OM n'est pas utilisé. Ne jamais annoncer « tous les matchs de l'OM » sans préciser stade, compétitions, saison et exclusions.",
};
