/**
 * Calendrier Nationale 2026-2027 du Rouen Normandie Rugby.
 * Source : rouennormandierugby.fr/equipe-pro/calendrier (relevé le 15/10/2026).
 * Les coups d'envoi sont en heure de Paris (offset inclus : +02:00 jusqu'au 25/10/2026, +01:00 ensuite).
 * Les scores joués sont ceux publiés par le club. Les matchs à venir n'ont pas de score.
 * En production, cette liste est remplacée par la source officielle configurée dans l'administration.
 */

export type StatutMatch = "a_venir" | "termine" | "reporte" | "annule" | "forfait";

export interface Match {
  id: string;
  journee: number;
  /** ISO 8601 avec offset. */
  coupDEnvoi: string;
  domicile: string;
  exterieur: string;
  lieu: string;
  competition: string;
  statut: StatutMatch;
  scoreDomicile?: number;
  scoreExterieur?: number;
  /** Résultat vérifié par l'administration (true) ou saisi en démonstration à partir du site du club. */
  resultatVerifie?: boolean;
}

export const RNR = "Rouen";
export const STADE = "Stade Robert-Diochon, Le Petit-Quevilly";
const NAT = "Championnat de France Nationale 2026-2027";

export const matchs: Match[] = [
  { id: "j01", journee: 1, coupDEnvoi: "2026-08-21T20:00:00+02:00", domicile: "Suresnes", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "termine", scoreDomicile: 23, scoreExterieur: 13, resultatVerifie: false },
  { id: "j02", journee: 2, coupDEnvoi: "2026-08-28T20:00:00+02:00", domicile: RNR, exterieur: "RC Orléans", lieu: STADE, competition: NAT, statut: "termine", scoreDomicile: 59, scoreExterieur: 29, resultatVerifie: false },
  { id: "j03", journee: 3, coupDEnvoi: "2026-09-04T20:00:00+02:00", domicile: "US Carcassonnaise", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "termine", scoreDomicile: 28, scoreExterieur: 5, resultatVerifie: false },
  { id: "j04", journee: 4, coupDEnvoi: "2026-09-11T20:00:00+02:00", domicile: RNR, exterieur: "Stade Montois", lieu: STADE, competition: NAT, statut: "termine", scoreDomicile: 19, scoreExterieur: 13, resultatVerifie: false },
  { id: "j05", journee: 5, coupDEnvoi: "2026-09-26T18:00:00+02:00", domicile: "CS Vienne Rugby", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "termine", scoreDomicile: 18, scoreExterieur: 36, resultatVerifie: false },
  { id: "j06", journee: 6, coupDEnvoi: "2026-10-02T20:00:00+02:00", domicile: RNR, exterieur: "Albi", lieu: STADE, competition: NAT, statut: "termine", scoreDomicile: 31, scoreExterieur: 45, resultatVerifie: false },
  { id: "j07", journee: 7, coupDEnvoi: "2026-10-09T20:00:00+02:00", domicile: "Bourg-en-Bresse", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "termine", scoreDomicile: 17, scoreExterieur: 36, resultatVerifie: false },
  { id: "j08", journee: 8, coupDEnvoi: "2026-10-16T20:00:00+02:00", domicile: RNR, exterieur: "Rennes", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j09", journee: 9, coupDEnvoi: "2026-10-30T20:00:00+01:00", domicile: RNR, exterieur: "OMR", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j10", journee: 10, coupDEnvoi: "2026-11-06T19:00:00+01:00", domicile: "Massy", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
  { id: "j11", journee: 11, coupDEnvoi: "2026-11-13T20:00:00+01:00", domicile: RNR, exterieur: "Chambéry", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j12", journee: 12, coupDEnvoi: "2026-11-21T16:00:00+01:00", domicile: "Périgueux", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
  { id: "j13", journee: 13, coupDEnvoi: "2026-12-04T20:00:00+01:00", domicile: RNR, exterieur: "Bourgoin", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j14", journee: 14, coupDEnvoi: "2026-12-11T20:00:00+01:00", domicile: RNR, exterieur: "Suresnes", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j15", journee: 15, coupDEnvoi: "2027-01-08T19:30:00+01:00", domicile: "RC Orléans", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
  { id: "j16", journee: 16, coupDEnvoi: "2027-01-15T20:00:00+01:00", domicile: RNR, exterieur: "US Carcassonnaise", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j17", journee: 17, coupDEnvoi: "2027-01-22T19:30:00+01:00", domicile: "Stade Montois", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
  { id: "j18", journee: 18, coupDEnvoi: "2027-01-29T20:00:00+01:00", domicile: RNR, exterieur: "CS Vienne Rugby", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j19", journee: 19, coupDEnvoi: "2027-02-12T19:30:00+01:00", domicile: "Albi", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
  { id: "j20", journee: 20, coupDEnvoi: "2027-02-19T20:00:00+01:00", domicile: RNR, exterieur: "Bourg-en-Bresse", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j21", journee: 21, coupDEnvoi: "2027-02-27T18:00:00+01:00", domicile: "Rennes", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
  { id: "j22", journee: 22, coupDEnvoi: "2027-03-05T20:00:00+01:00", domicile: "OMR", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
  { id: "j23", journee: 23, coupDEnvoi: "2027-03-19T20:00:00+01:00", domicile: RNR, exterieur: "Massy", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j24", journee: 24, coupDEnvoi: "2027-03-26T19:30:00+01:00", domicile: "Chambéry", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
  { id: "j25", journee: 25, coupDEnvoi: "2027-04-09T20:00:00+02:00", domicile: RNR, exterieur: "Périgueux", lieu: STADE, competition: NAT, statut: "a_venir" },
  { id: "j26", journee: 26, coupDEnvoi: "2027-04-17T17:00:00+02:00", domicile: "Bourgoin", exterieur: RNR, lieu: "Extérieur", competition: NAT, statut: "a_venir" },
];

/**
 * Classement Nationale tel qu'affiché sur le site du club le 15/10/2026 (page classement, arrêtée à 5 journées ;
 * l'accueil du club indique « 5e » et 4 victoires / 3 défaites après 7 journées). À remplacer par la source officielle.
 */
export const classementNationale = {
  releveLe: "2026-10-15",
  note: "Relevé sur rouennormandierugby.fr (page classement arrêtée à la 5e journée). Source officielle à brancher en production.",
  lignes: [
    { pos: 1, club: "Massy", j: 5, g: 5, n: 0, p: 0, diff: 52, pts: 23 },
    { pos: 2, club: "US Carcassonnaise", j: 5, g: 4, n: 0, p: 1, diff: 80, pts: 22 },
    { pos: 3, club: "Albi", j: 5, g: 4, n: 0, p: 1, diff: 31, pts: 21 },
    { pos: 4, club: "Chambéry", j: 5, g: 3, n: 1, p: 1, diff: 64, pts: 19 },
    { pos: 4, club: "Stade Montois", j: 5, g: 3, n: 0, p: 2, diff: 87, pts: 19 },
    { pos: 6, club: "Rouen", j: 5, g: 3, n: 0, p: 2, diff: 21, pts: 16 },
    { pos: 7, club: "Suresnes", j: 5, g: 3, n: 0, p: 2, diff: -41, pts: 14 },
    { pos: 8, club: "Bourgoin", j: 5, g: 2, n: 1, p: 2, diff: -4, pts: 13 },
    { pos: 8, club: "RC Orléans", j: 5, g: 2, n: 0, p: 3, diff: -7, pts: 13 },
    { pos: 10, club: "Périgueux", j: 5, g: 2, n: 0, p: 3, diff: -26, pts: 12 },
    { pos: 11, club: "Rennes", j: 5, g: 1, n: 0, p: 4, diff: -24, pts: 9 },
    { pos: 12, club: "CS Vienne Rugby", j: 5, g: 1, n: 0, p: 4, diff: -81, pts: 7 },
    { pos: 13, club: "Bourg-en-Bresse", j: 5, g: 1, n: 0, p: 4, diff: -91, pts: 6 },
    { pos: 14, club: "OMR", j: 5, g: 0, n: 0, p: 5, diff: -61, pts: 4 },
  ],
};

/** Position et points de classement affichés sur l'accueil officiel du club le 15/10/2026 (après la 7e journée). */
export const positionActuelle = { releveLe: "2026-10-15", position: 5, pointsClassement: 21, apresJournee: 7, source: "https://rouennormandierugby.fr/ (bloc « Les résultats »)" };

/** Objectifs de saison : hypothèses du porteur du projet, à valider par le club. */
export const objectifsSaison = {
  validation: "hypothese" as const,
  items: [
    "Terminer dans la première moitié du classement",
    "Se qualifier pour les phases finales de Nationale",
    "Promotion éventuelle en Pro D2 (règle de montée : à vérifier auprès de la FFR / LNR pour la saison 2026-2027)",
  ],
};
