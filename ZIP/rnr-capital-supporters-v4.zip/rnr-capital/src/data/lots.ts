/**
 * Lots du concours gratuit de pronostics et partenaires.
 * AUCUN lot n'est contractuellement sécurisé : le concours fonctionne en démonstration sans promesse de récompense.
 */

export type StatutContractuel = "confirme" | "en_discussion" | "envisage";

export interface Lot {
  id: string;
  rang: string;
  titre: string;
  description: string;
  quantite: number;
  valeurEstimee: number | null;
  fournisseur: string;
  statut: StatutContractuel;
  conditionsRemise: string;
  image?: string;
}

/** Champs du lot principal (véhicule) : tous vides tant que le partenariat n'est pas signé. */
export const lotPrincipal = {
  accroche: "Objectif : une CUPRA à gagner, sous réserve de confirmation du partenariat et du règlement.",
  mentionObligatoire: "Lot envisagé — partenariat CUPRA non signé — attribution non garantie à ce stade.",
  statut: "envisage" as StatutContractuel,
  partenaireContractuel: null as string | null,
  modele: null as string | null,
  version: null as string | null,
  etat: null as "neuf" | "occasion" | null,
  kilometrage: null as number | null,
  valeurDocumentee: null as number | null,
  proprieteVehicule: null as string | null,
  immatriculationLivraisonFrais: null as string | null,
  conditionsRemise: null as string | null,
  dateDisponibilite: null as string | null,
  documentsContractuels: [] as string[],
  /** Un véhicule simplement prêté pour exposition ne peut pas être présenté comme offert. */
  pretExpositionSeulement: false,
};

export const lotsSecondaires: Lot[] = [
  { id: "maillot", rang: "2e", titre: "Maillot domicile 26/27 dédicacé", description: "Maillot officiel signé par l'effectif professionnel.", quantite: 1, valeurEstimee: null, fournisseur: "À confirmer (club)", statut: "envisage", conditionsRemise: "Remise en main propre au stade" },
  { id: "ballon", rang: "3e", titre: "Ballon de match signé", description: "Ballon officiel signé par les joueurs.", quantite: 1, valeurEstimee: null, fournisseur: "À confirmer (club)", statut: "envisage", conditionsRemise: "Remise en main propre au stade" },
  { id: "equipement", rang: "4e au 5e", titre: "Équipement de rugby", description: "Tenue d'entraînement ou accessoires de la boutique officielle.", quantite: 2, valeurEstimee: null, fournisseur: "À confirmer (équipementier / boutique)", statut: "envisage", conditionsRemise: "Retrait en boutique" },
  { id: "panier", rang: "6e au 10e", titre: "Panier gastronomique normand", description: "Sélection de produits normands.", quantite: 5, valeurEstimee: null, fournisseur: "Entreprise partenaire à démarcher", statut: "envisage", conditionsRemise: "Expédition en France métropolitaine" },
  { id: "experience", rang: "Classement du mois", titre: "Expérience rugby", description: "Visite, repas ou invitation à un match, après validation de la disponibilité et des conditions.", quantite: 0, valeurEstimee: null, fournisseur: "À confirmer (club)", statut: "envisage", conditionsRemise: "Selon calendrier du club" },
];

export type CategoriePartenaire = "partenaire_club" | "partenaire_operation" | "prospect";

export interface Partenaire {
  nom: string;
  categorie: CategoriePartenaire;
  site?: string;
  note?: string;
}

/**
 * Partenaires actuels du club relevés sur la page officielle des partenaires (15/10/2026).
 * Leur présence ici signifie uniquement qu'ils sont partenaires du club : aucun n'a accepté de participer à l'opération.
 */
export const partenaires: Partenaire[] = [
  { nom: "PGS", categorie: "partenaire_club", site: "https://www.pgsgroup.com/fr/" },
  { nom: "Groupe Agon", categorie: "partenaire_club", site: "https://www.groupe-agon.com/" },
  { nom: "Crédit Agricole Normandie-Seine", categorie: "partenaire_club", site: "https://www.credit-agricole.fr/ca-normandie-seine" },
  { nom: "HAFA", categorie: "partenaire_club", site: "https://www.hafa.fr/" },
  { nom: "Natixis Partners", categorie: "partenaire_club", site: "https://www.natixispartners.com/" },
  { nom: "Candor", categorie: "partenaire_club", site: "https://groupecandor.com/" },
  { nom: "De Rijke", categorie: "partenaire_club", site: "https://derijke.fr/" },
  { nom: "Demgy", categorie: "partenaire_club", site: "https://www.demgy.com/" },
  { nom: "Groupe Hecquet", categorie: "partenaire_club", site: "https://www.groupehecquet.com/" },
  { nom: "Normandie Manutention", categorie: "partenaire_club", site: "https://normandiemanutention.fr/" },
  { nom: "Odyssée Immobilier", categorie: "partenaire_club", site: "https://www.odyssee-immobilier.fr/" },
  { nom: "Bamboo", categorie: "partenaire_club", site: "https://www.bamboo-emf.com/" },
  { nom: "Bono Distribution", categorie: "partenaire_club", site: "https://bonodistribution.fr/", note: "Partenariat reconduit (actualité du club du 07/10/2026)." },
  { nom: "Campus Saint-Marc", categorie: "partenaire_club", site: "https://campus-saint-marc.com/" },
  { nom: "Groupe Castres", categorie: "partenaire_club", site: "https://www.groupe-castres.com/" },
  { nom: "NPN Distribution", categorie: "partenaire_club" },
  { nom: "Pinson Paysage", categorie: "partenaire_club", site: "https://pinson-paysage.com/" },
  { nom: "Rousseille", categorie: "partenaire_club" },
  { nom: "SOGEA", categorie: "partenaire_club", site: "https://sogea-environnement.fr/" },
  { nom: "The Novick's Stadium", categorie: "partenaire_club", site: "https://bar-the-novicks-stadium.fr/" },
  { nom: "Paris-Normandie", categorie: "partenaire_club", site: "https://www.paris-normandie.fr/" },
  { nom: "Métropole Rouen Normandie", categorie: "partenaire_club", note: "Collectivité" },
  { nom: "Région Normandie", categorie: "partenaire_club", note: "Collectivité" },
  { nom: "Département de la Seine-Maritime", categorie: "partenaire_club", note: "Collectivité" },
  { nom: "Ville de Rouen", categorie: "partenaire_club", note: "Collectivité" },
  // Entreprises que l'on souhaite démarcher pour l'opération (aucun contact établi).
  { nom: "CUPRA (distributeur à identifier)", categorie: "prospect", note: "Lot principal envisagé. Aucun contact établi, CUPRA n'est pas sponsor du club." },
  { nom: "Producteurs normands (cidre, fromages, biscuiterie)", categorie: "prospect", note: "Paniers gastronomiques." },
];

export const statutContractuelLabel: Record<StatutContractuel, string> = {
  confirme: "Confirmé",
  en_discussion: "En discussion",
  envisage: "Envisagé",
};
