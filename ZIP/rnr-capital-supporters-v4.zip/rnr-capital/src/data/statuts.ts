/**
 * Grille de statuts d'actionnaires supporters — EXEMPLE À FAIRE APPROUVER ET BUDGÉTER.
 * Chaque avantage porte un état (confirmé / en négociation / envisagé) et ses conditions.
 */

export type EtatAvantage = "confirme" | "negociation" | "envisage";

export interface Avantage {
  id: string;
  titre: string;
  etat: EtatAvantage;
  duree: string;
  quantite: string;
  reservation: string;
  capacite: string;
  nominatif: boolean;
  renouvellement: string;
  /** Coût unitaire estimé pour le budget (euros). */
  coutEstime?: number;
  note?: string;
}

export interface Statut {
  id: string;
  nom: string;
  seuilActions: number;
  accroche: string;
  couleur: string; // classe de fond
  avantages: Avantage[];
}

const base = {
  duree: "Saison 2026-2027 uniquement",
  renouvellement: "Non reconduit automatiquement ; l'investissement est ponctuel",
};

export const statuts: Statut[] = [
  {
    id: "supporter",
    nom: "Supporter actionnaire",
    seuilActions: 1,
    accroche: "Entrer dans l'histoire du club dès une action.",
    couleur: "from-slate-700 to-slate-900",
    avantages: [
      { id: "carte", titre: "Carte numérique nominative", etat: "envisage", quantite: "1", reservation: "Automatique", capacite: "Illimitée", nominatif: true, coutEstime: 0, ...base },
      { id: "badge", titre: "Badge de membre", etat: "envisage", quantite: "1", reservation: "Automatique", capacite: "Illimitée", nominatif: true, coutEstime: 0, ...base },
      { id: "infos", titre: "Informations régulières sur le projet", etat: "envisage", quantite: "Lettre mensuelle", reservation: "Automatique", capacite: "Illimitée", nominatif: false, coutEstime: 0, ...base },
      { id: "contenus", titre: "Accès aux contenus réservés", etat: "envisage", quantite: "Illimité", reservation: "Automatique", capacite: "Illimitée", nominatif: true, coutEstime: 2, ...base },
      { id: "consultations", titre: "Invitations à des consultations communautaires", etat: "envisage", quantite: "Selon calendrier", reservation: "Par e-mail", capacite: "Illimitée", nominatif: true, coutEstime: 0, note: "Consultations consultatives, distinctes des votes statutaires.", ...base },
      { id: "priorite", titre: "Priorité sur certaines offres", etat: "envisage", quantite: "Selon disponibilités", reservation: "Selon offre", capacite: "Selon stock", nominatif: true, coutEstime: 0, ...base },
    ],
  },
  {
    id: "cercle",
    nom: "Cercle des Lions",
    seuilActions: 5,
    accroche: "Au plus près du groupe, dans les coulisses de la semaine.",
    couleur: "from-red-900 to-slate-950",
    avantages: [
      { id: "evenements", titre: "Invitations à des événements supporters", etat: "envisage", quantite: "2 par saison", reservation: "Inscription en ligne, 15 jours avant", capacite: "150 personnes par événement", nominatif: true, coutEstime: 25, ...base },
      { id: "entrainement", titre: "Entraînement ouvert aux membres", etat: "negociation", quantite: "1 par saison", reservation: "Inscription en ligne", capacite: "80 personnes", nominatif: true, coutEstime: 10, note: "Sous réserve du staff sportif.", ...base },
      { id: "rencontres", titre: "Priorité sur les rencontres avec les joueurs", etat: "envisage", quantite: "Selon programme", reservation: "Inscription en ligne", capacite: "Selon événement", nominatif: true, coutEstime: 0, ...base },
    ],
  },
  {
    id: "privilege",
    nom: "Lions Privilège",
    seuilActions: 10,
    accroche: "Tous les matchs à domicile, et la saison vue de l'intérieur.",
    couleur: "from-red-600 to-red-900",
    avantages: [
      { id: "abonnement", titre: "Abonnement : tous les matchs à domicile en Nationale, saison 2026-2027", etat: "negociation", quantite: "1 place, tribune à définir", reservation: "Place attribuée à la confirmation de la souscription", capacite: "Plafond à fixer par le club", nominatif: true, coutEstime: 180, note: "Phases finales, matchs de coupe, rencontres amicales et matchs délocalisés : NON inclus tant que le club n'a pas tranché.", ...base },
      { id: "afterwork", titre: "Afterworks avec des représentants de l'équipe", etat: "envisage", quantite: "2 par saison", reservation: "Inscription en ligne", capacite: "60 personnes", nominatif: true, coutEstime: 35, note: "Sous réserve du calendrier sportif.", ...base },
      { id: "dedicaces", titre: "Rencontres et séances de dédicaces", etat: "envisage", quantite: "2 par saison", reservation: "Inscription en ligne", capacite: "100 personnes", nominatif: true, coutEstime: 5, ...base },
      { id: "visite", titre: "Visite des installations", etat: "envisage", quantite: "1 par saison", reservation: "Inscription en ligne", capacite: "30 personnes par créneau", nominatif: true, coutEstime: 8, ...base },
      { id: "boutique", titre: "Avantages boutique et partenaires", etat: "negociation", quantite: "Remise à définir", reservation: "Code personnel", capacite: "Illimitée", nominatif: true, coutEstime: 15, ...base },
      { id: "carte-premium", titre: "Badge et carte premium", etat: "envisage", quantite: "1", reservation: "Automatique", capacite: "Illimitée", nominatif: true, coutEstime: 3, ...base },
      { id: "communaute", titre: "Accès à une communauté dédiée", etat: "envisage", quantite: "Illimité", reservation: "Automatique", capacite: "Illimitée", nominatif: true, coutEstime: 2, ...base },
    ],
  },
  {
    id: "business",
    nom: "Lions Business",
    seuilActions: 50,
    accroche: "Le réseau du club, au service de votre entreprise.",
    couleur: "from-slate-900 to-black",
    avantages: [
      { id: "networking", titre: "Événements professionnels et networking", etat: "envisage", quantite: "3 par saison", reservation: "Inscription en ligne", capacite: "120 personnes", nominatif: true, coutEstime: 60, ...base },
      { id: "hospitalite", titre: "Invitations d'hospitalité", etat: "negociation", quantite: "4 invitations par saison", reservation: "Demande 10 jours avant le match", capacite: "Selon loges disponibles", nominatif: false, coutEstime: 120, note: "Transférables à des invités, dans la limite du nombre défini.", ...base },
      { id: "direction", titre: "Rencontres avec la direction", etat: "envisage", quantite: "1 par saison", reservation: "Sur invitation", capacite: "40 personnes", nominatif: true, coutEstime: 30, ...base },
      { id: "cercle-business", titre: "Possibilité d'intégrer un cercle business", etat: "negociation", quantite: "Selon accord du club", reservation: "Dossier", capacite: "Selon accord", nominatif: true, coutEstime: 0, note: "Le Business Club du RNR est un dispositif distinct ; l'intégration dépend de l'accord du club.", ...base },
    ],
  },
  {
    id: "ambassadeur",
    nom: "Lions Ambassadeur",
    seuilActions: 100,
    accroche: "Un engagement de référence, reconnu par le club.",
    couleur: "from-amber-600 to-slate-950",
    avantages: [
      { id: "relationnel", titre: "Programme relationnel personnalisé", etat: "envisage", quantite: "Programme annuel", reservation: "Sur rendez-vous", capacite: "Limitée", nominatif: true, coutEstime: 200, ...base },
      { id: "exclusifs", titre: "Événements exclusifs", etat: "envisage", quantite: "2 par saison", reservation: "Sur invitation", capacite: "30 personnes", nominatif: true, coutEstime: 150, ...base },
      { id: "reconnaissance", titre: "Reconnaissance publique facultative", etat: "envisage", quantite: "Sur consentement écrit", reservation: "Formulaire de consentement", capacite: "Illimitée", nominatif: true, coutEstime: 0, ...base },
      { id: "interlocuteur", titre: "Interlocuteur dédié", etat: "envisage", quantite: "1", reservation: "Sur rendez-vous", capacite: "Selon effectif du club", nominatif: true, coutEstime: 0, note: "Uniquement si le club prévoit effectivement ce service.", ...base },
    ],
  },
];

export const etatLabel: Record<EtatAvantage, string> = {
  confirme: "Confirmé",
  negociation: "En négociation",
  envisage: "Envisagé",
};

/** Retourne le statut atteint pour un nombre d'actions (le plus élevé dont le seuil est franchi). */
export function statutPour(actions: number): Statut | null {
  let trouve: Statut | null = null;
  for (const s of statuts) if (actions >= s.seuilActions) trouve = s;
  return trouve;
}

/** Tous les avantages cumulés jusqu'au statut atteint (les statuts incluent les précédents). */
export function avantagesCumules(actions: number): { statut: Statut; avantages: Avantage[] }[] {
  return statuts.filter((s) => actions >= s.seuilActions).map((s) => ({ statut: s, avantages: s.avantages }));
}
