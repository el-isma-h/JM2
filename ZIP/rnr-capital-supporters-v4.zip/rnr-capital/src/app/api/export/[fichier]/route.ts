import { NextResponse } from "next/server";
import { exigerRole } from "@/lib/auth";
import { lireDb } from "@/lib/store";
import { classer } from "@/lib/concours";

function csv(lignes: (string | number | boolean | undefined | null)[][]) {
  const esc = (v: string | number | boolean | undefined | null) => {
    const s = v === undefined || v === null ? "" : String(v);
    return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return "﻿" + lignes.map((l) => l.map(esc).join(";")).join("\r\n");
}

/** Exports CSV réservés aux administrateurs : souscriptions.csv, classement.csv, participants.csv, audit.csv */
export async function GET(_req: Request, ctx: { params: Promise<{ fichier: string }> }) {
  const acces = await exigerRole(["admin"]);
  if (!acces) return new NextResponse("Accès refusé", { status: 403 });
  const { fichier } = await ctx.params;
  const db = await lireDb();
  const pseudo = (id: string) => db.users.find((u) => u.id === id)?.pseudo ?? id;
  const email = (id: string) => db.users.find((u) => u.id === id)?.email ?? "";
  let contenu: string;
  if (fichier === "souscriptions.csv") {
    contenu = csv([["id", "pseudo", "email", "actions", "montant", "frais", "statut", "reference_prestataire", "stripe_session", "cree_le"], ...db.souscriptions.map((s) => [s.id, pseudo(s.userId), email(s.userId), s.actions, s.montant, s.frais, s.statut, s.referencePrestataire, s.stripeSessionId, s.creeLe])]);
  } else if (fichier === "classement.csv") {
    contenu = csv([["rang", "pseudo", "scores_exacts", "ecart_cumule", "pronostics_evalues", "inscrit_le"], ...classer(db.participants, db.pronostics, db.matchs).map((l) => [l.rang, l.pseudo, l.points, l.ecartCumule, l.pronosticsEvalues, l.inscritLe])]);
  } else if (fichier === "participants.csv") {
    contenu = csv([["id", "pseudo", "email", "role", "email_verifie", "suspendu", "cree_le"], ...db.users.map((u) => [u.id, u.pseudo, u.email, u.role, u.emailVerifie, u.suspendu, u.creeLe])]);
  } else if (fichier === "audit.csv") {
    contenu = csv([["date", "acteur", "action", "cible", "details"], ...db.audit.map((e) => [e.date, pseudo(e.acteur), e.action, e.cible, e.details ? JSON.stringify(e.details) : ""])]);
  } else {
    return new NextResponse("Export inconnu", { status: 404 });
  }
  return new NextResponse(contenu, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="${fichier}"` } });
}
