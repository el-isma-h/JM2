import { NextResponse } from "next/server";
import { construireEvenementWebhook } from "@/lib/stripe";
import { marquerPaiementRecu } from "@/lib/actions";

/** Webhook Stripe (mode test). Configurer STRIPE_WEBHOOK_SECRET ; `stripe listen --forward-to localhost:3000/api/stripe/webhook`. */
export async function POST(req: Request) {
  const brut = await req.text();
  const signature = req.headers.get("stripe-signature") ?? "";
  let evenement;
  try {
    evenement = construireEvenementWebhook(brut, signature);
  } catch {
    return NextResponse.json({ erreur: "signature invalide" }, { status: 400 });
  }
  if (!evenement) return NextResponse.json({ erreur: "Stripe non configuré" }, { status: 503 });
  if (evenement.type === "checkout.session.completed") {
    const session = evenement.data.object;
    const id = session.metadata?.souscriptionId;
    if (id && session.payment_status === "paid") {
      await marquerPaiementRecu(id, typeof session.payment_intent === "string" ? session.payment_intent : undefined, "webhook Stripe");
    }
  }
  return NextResponse.json({ recu: true });
}
