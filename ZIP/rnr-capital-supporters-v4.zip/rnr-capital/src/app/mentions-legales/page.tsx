import type { Metadata } from "next";
import { Section, Titre, Encart } from "@/components/ui";

export const metadata: Metadata = { title: "Mentions légales et confidentialité" };

export default function Mentions() {
  return (
    <Section>
      <Titre as="h1" sur="Juridique">Mentions légales et confidentialité</Titre>
      <div className="max-w-3xl space-y-6 text-ardoise-2">
        <Encart titre="À compléter avant toute mise en ligne" teinte="ambre">
          <p>Éditeur, forme juridique, capital, SIREN/RCS, siège, directeur de la publication, hébergeur, contact du délégué à la protection des données.</p>
        </Encart>
        <h2 className="text-3xl">Données personnelles</h2>
        <p>Données traitées en démonstration : adresse e-mail, pseudo, mot de passe (haché), pronostics, intentions de souscription, réservations, consentements et journal d&apos;audit. Finalités : fonctionnement du concours gratuit, suivi des intentions de souscription, gestion des avantages. Base légale : exécution du service demandé et consentement. Durée : le temps de la démonstration. Droits d&apos;accès, de rectification, d&apos;effacement et d&apos;opposition : via l&apos;espace membre ou le contact du club une fois désigné.</p>
        <h2 className="text-3xl">Cookies</h2>
        <p>Un seul cookie de session, strictement nécessaire (rnr_session), signé, sans traceur publicitaire ni mesure d&apos;audience tierce.</p>
        <h2 className="text-3xl">Propriété intellectuelle</h2>
        <p>Les marques, noms et logos du Rouen Normandie Rugby, de l&apos;Olympique de Marseille, de CUPRA et des entreprises citées appartiennent à leurs titulaires. Cette démonstration n&apos;utilise aucun logo officiel.</p>
      </div>
    </Section>
  );
}
