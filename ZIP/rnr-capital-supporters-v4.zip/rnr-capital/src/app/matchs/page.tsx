import type { Metadata } from "next";
import Link from "next/link";
import { campagne } from "@/config/campagne";
import { Section, Titre, Encart, Badge, dateHeureFr } from "@/components/ui";
import { CarteMatch } from "@/components/CarteMatch";
import { FormulairePronostic } from "@/components/FormulairePronostic";
import { matchsDb } from "@/lib/stats";
import { utilisateurCourant } from "@/lib/auth";
import { lireDb } from "@/lib/store";
import { saisieOuverte, dateCloture, evaluer, matchComptabilise } from "@/lib/concours";

export const metadata: Metadata = { title: "Matchs et pronostics" };
export const dynamic = "force-dynamic";

export default async function Matchs({ searchParams }: { searchParams: Promise<{ bienvenue?: string }> }) {
  const { bienvenue } = await searchParams;
  const [{ tous }, user, db] = await Promise.all([matchsDb(), utilisateurCourant(), lireDb()]);
  const mesPronos = user ? db.pronostics.filter((p) => p.userId === user.id) : [];
  const maintenant = new Date();
  const aVenir = tous.filter((m) => m.statut !== "termine" && m.statut !== "annule" && m.statut !== "forfait");
  const passes = tous.filter((m) => m.statut === "termine" || m.statut === "annule" || m.statut === "forfait").reverse();
  const actif = db.parametres.concoursActif;

  return (
    <>
      <Section className="pb-6">
        <Titre as="h1" sur="Concours gratuit de pronostics">Trouvez le score exact des Lions</Titre>
        {bienvenue && <p className="mb-6 bg-vert/10 px-4 py-2 text-sm text-vert">Bienvenue ! Votre compte est créé. Un e-mail de confirmation d&apos;adresse vous a été envoyé (en démonstration : journal des e-mails de l&apos;administration).</p>}
        <div className="grid gap-6 lg:grid-cols-3">
          <Encart titre="Gratuit, pour tous, séparé de l'investissement" teinte="rouge">
            <p>Inscription gratuite, sans achat d&apos;action, don ni abonnement. Mêmes règles, mêmes lots, mêmes chances pour tous. Aucun avantage de classement pour les actionnaires. Aucun achat de points ni de tentatives, pas de mise, pas de cote, aucun gain financier.</p>
          </Encart>
          <Encart titre="Règles" teinte="gris">
            <p>Un pronostic par match (score final de chaque équipe), modifiable jusqu&apos;à la clôture, {campagne.clotureMinutesAvantCoupDEnvoi} min avant le coup d&apos;envoi, contrôlée côté serveur. Fuseau : {campagne.fuseau}. Score retenu : {campagne.definitionScore}. Un score exact = 1 point.</p>
          </Encart>
          <Encart titre="Classement et départage" teinte="gris">
            <p>Classement saisonnier au nombre de scores exacts. Égalités : plus faible écart cumulé aux scores réels, puis inscription la plus ancienne (critère subsidiaire de démonstration à valider au règlement). Lots aux meilleurs du classement, sans tirage au sort. <Link href="/classement" className="underline">Voir le classement</Link>.</p>
          </Encart>
        </div>
        {!actif && <p className="mt-6 bg-ambre-clair/15 px-4 py-2 text-sm text-ambre">Le concours est suspendu par l&apos;administration.</p>}
        {!db.parametres.lotsActifs && <p className="mt-4 text-sm text-gris">Lots non sécurisés : le concours fonctionne en démonstration, sans promesse de récompense. Le règlement et la qualification juridique doivent être validés avant toute activation publique avec des lots.</p>}
      </Section>

      <Section className="border-y border-gris-clair bg-clair-2">
        <Titre sur="À venir">Pronostiquez</Titre>
        <div className="grid gap-4 md:grid-cols-2">
          {aVenir.map((m) => {
            const mien = mesPronos.find((p) => p.matchId === m.id);
            const ouvert = actif && saisieOuverte(m, campagne.clotureMinutesAvantCoupDEnvoi, maintenant);
            return (
              <div key={m.id} className="carte min-w-0 p-5">
                <CarteMatch match={m} compact />
                <FormulairePronostic match={m} initial={mien ? { d: mien.scoreDomicile, e: mien.scoreExterieur } : undefined} cloture={dateHeureFr(dateCloture(m, campagne.clotureMinutesAvantCoupDEnvoi).toISOString())} ouvert={ouvert} connecte={!!user} />
              </div>
            );
          })}
        </div>
      </Section>

      <Section>
        <Titre sur="Historique">Matchs joués</Titre>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {passes.map((m) => {
            const mien = mesPronos.find((p) => p.matchId === m.id);
            const r = mien ? evaluer(mien, m) : null;
            return (
              <div key={m.id} className="carte p-4">
                <CarteMatch match={m} compact />
                <div className="mt-3 flex items-center justify-between text-sm">
                  <span className="text-gris">
                    {mien ? `Votre pronostic : ${mien.scoreDomicile} - ${mien.scoreExterieur}` : "Pas de pronostic"}
                  </span>
                  {r && matchComptabilise(m) && <Badge teinte={r.exact ? "vert" : "gris"}>{r.exact ? "Score exact · 1 pt" : `Écart ${r.ecart}`}</Badge>}
                  {!matchComptabilise(m) && m.statut === "termine" && <Badge teinte="ambre">Résultat non vérifié</Badge>}
                </div>
              </div>
            );
          })}
        </div>
      </Section>
    </>
  );
}
