import type { Metadata } from "next";
import { campagne } from "@/config/campagne";
import { etatLabel } from "@/data/statuts";
import { avantageOM } from "@/data/contenus";
import { Section, Titre, Encart, Badge, Bouton, teinteEtat } from "@/components/ui";
import { Apparition } from "@/components/Apparition";
import { CarteMembre } from "@/components/CarteMembre";
import { euros } from "@/lib/souscription";
import { lireDb } from "@/lib/store";

export const metadata: Metadata = { title: "Statuts et avantages" };
export const dynamic = "force-dynamic";

export default async function Statuts() {
  const db = await lireDb();
  const statuts = db.statuts;
  const coutTotal = statuts.reduce((n, s) => n + s.avantages.reduce((m, a) => m + (a.coutEstime ?? 0), 0), 0);
  return (
    <>
      <Section className="pb-6">
        <Titre as="h1" sur="Statuts d'actionnaires supporters">Une identité, des avantages, des conditions claires</Titre>
        <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <div className="space-y-4">
            <Encart titre="Grille d'exemple" teinte="ambre">
              <p>À faire approuver et budgéter par le club. Chaque avantage indique son état (confirmé, en négociation, envisagé), sa durée, sa quantité, ses conditions de réservation, sa capacité, son caractère nominatif ou transférable et son renouvellement.</p>
            </Encart>
            <Encart titre="L'investissement est ponctuel" teinte="rouge">
              <p>Les avantages sont définis pour la saison indiquée. Rien ne garantit des abonnements ou prestations annuels à vie. Le statut communautaire ne donne aucun droit sur les choix sportifs ni d&apos;accès libre aux joueurs ou aux vestiaires.</p>
              <p className="text-xs">Coût unitaire estimé des avantages par membre Ambassadeur : {euros(coutTotal)} (cumul des estimations), à intégrer au budget pour préserver l&apos;objectif de financement.</p>
            </Encart>
          </div>
          <CarteMembre pseudo="Camille76" statut="Lions Privilège" numero="0042" demo />
        </div>
      </Section>

      {statuts.map((s, i) => (
        <Section key={s.id} id={s.id} className={i % 2 ? "" : "border-y border-gris-clair bg-clair-2"}>
          <Apparition>
            <div className={`mb-6 rounded-2xl bg-gradient-to-r ${s.couleur} p-6 text-blanc md:flex md:items-end md:justify-between`}>
              <div>
                <p className="label text-xs text-blanc/70">dès {s.seuilActions} action{s.seuilActions > 1 ? "s" : ""} · {euros(s.seuilActions * campagne.prixAction)}</p>
                <h2 className="text-4xl sm:text-5xl">{s.nom}</h2>
                <p className="mt-2 text-blanc/80">{s.accroche}</p>
              </div>
              {i > 0 && <p className="mt-3 text-sm text-blanc/80 md:mt-0">Inclut les avantages des statuts précédents.</p>}
            </div>
            <div className="overflow-x-auto border border-gris-clair">
              <table className="w-full text-sm">
                <thead className="bg-clair-2 text-left text-xs uppercase tracking-wider text-gris">
                  <tr>
                    <th className="px-3 py-2">Avantage</th><th className="px-3 py-2">État</th><th className="px-3 py-2">Durée</th><th className="px-3 py-2">Quantité</th><th className="px-3 py-2">Réservation</th><th className="px-3 py-2">Capacité</th><th className="px-3 py-2">Nominatif</th><th className="px-3 py-2">Renouvellement</th>
                  </tr>
                </thead>
                <tbody>
                  {s.avantages.map((a) => (
                    <tr key={a.id} className="border-t border-clair-2 align-top">
                      <td className="px-3 py-2.5 font-600">{a.titre}{a.note && <p className="mt-1 text-xs font-400 text-gris">{a.note}</p>}</td>
                      <td className="px-3 py-2.5"><Badge teinte={teinteEtat(a.etat)}>{etatLabel[a.etat]}</Badge></td>
                      <td className="px-3 py-2.5 text-ardoise-2">{a.duree}</td>
                      <td className="px-3 py-2.5 text-ardoise-2">{a.quantite}</td>
                      <td className="px-3 py-2.5 text-ardoise-2">{a.reservation}</td>
                      <td className="px-3 py-2.5 text-ardoise-2">{a.capacite}</td>
                      <td className="px-3 py-2.5 text-ardoise-2">{a.nominatif ? "Nominatif" : "Transférable"}</td>
                      <td className="px-3 py-2.5 text-ardoise-2">{a.renouvellement}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Apparition>
        </Section>
      ))}

      <Section id="om" className="border-t border-gris-clair bg-clair-2">
        <Titre sur={`Module administrable · dès ${avantageOM.seuilActions} actions`}>Accès aux matchs de l&apos;Olympique de Marseille</Titre>
        <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
          <div>
            <p className="inline-block bg-ambre-clair/15 px-3 py-1 text-sm font-600 text-ambre">{avantageOM.statut}</p>
            <p className="mt-3 text-sm text-gris">Module {db.parametres.omActif ? "activé" : "désactivé"} dans l&apos;administration. Aucune affiliation avec l&apos;Olympique de Marseille ; son logo n&apos;est pas utilisé.</p>
            <ul className="mt-4 space-y-3">
              {avantageOM.options.map((o) => (
                <li key={o.id} className="carte p-4">
                  <p className="display text-xl font-900">{o.titre} <Badge teinte="gris">non confirmé</Badge></p>
                  <p className="text-sm text-ardoise-2">{o.detail}</p>
                  {"stade" in o && (
                    <dl className="mt-2 grid grid-cols-2 gap-1 text-xs text-gris sm:grid-cols-4">
                      <div><dt>Stade</dt><dd className="text-ambre">à préciser</dd></div>
                      <div><dt>Compétitions</dt><dd className="text-ambre">à préciser</dd></div>
                      <div><dt>Saison</dt><dd className="text-ambre">à préciser</dd></div>
                      <div><dt>Exclusions</dt><dd className="text-ambre">à préciser</dd></div>
                    </dl>
                  )}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div className="border border-rouge/40 bg-blanc p-5">
              <p className="display text-xl font-900">{avantageOM.alternativeRugby.titre}</p>
              <p className="mt-1 text-sm text-ardoise-2">{avantageOM.alternativeRugby.detail}</p>
            </div>
            <Encart titre="Règle d'affichage" teinte="gris"><p>{avantageOM.mentions}</p></Encart>
          </div>
        </div>
        <div className="mt-8"><Bouton href="/investir">Simuler une souscription</Bouton></div>
      </Section>
    </>
  );
}
