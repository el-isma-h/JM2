import type { Metadata } from "next";
import Link from "next/link";
import { Section, Titre, Encart } from "@/components/ui";
import { FormulaireAction, champ, etiquette } from "@/components/FormulaireAction";
import { connexion, inscription } from "@/lib/actions";
import { COMPTES_DEMO } from "@/lib/seed";

export const metadata: Metadata = { title: "Connexion et inscription" };

export default async function Connexion({ searchParams }: { searchParams: Promise<{ reinit?: string; retour?: string; reinitialise?: string }> }) {
  const { reinit, retour = "", reinitialise } = await searchParams;
  return (
    <Section>
      <Titre as="h1" sur="Compte">Se connecter ou s&apos;inscrire gratuitement</Titre>
      {reinit && <p className="mb-6 bg-vert/10 px-4 py-2 text-sm text-vert">Données de démonstration réinitialisées.</p>}
      {reinitialise && <p className="mb-6 bg-vert/10 px-4 py-2 text-sm text-vert">Mot de passe modifié : connectez-vous.</p>}
      <div className="grid gap-8 lg:grid-cols-[1fr_1fr_0.9fr]">
        <div className="carte p-6">
          <h2 className="mb-4 text-3xl">Connexion</h2>
          <FormulaireAction action={connexion} libelle="Se connecter">
            <input type="hidden" name="retour" value={retour} />
            <label htmlFor="c-email" className={etiquette}>E-mail</label>
            <input id="c-email" name="email" type="email" autoComplete="email" required className={champ} />
            <label htmlFor="c-mdp" className={`${etiquette} mt-3`}>Mot de passe</label>
            <input id="c-mdp" name="motDePasse" type="password" autoComplete="current-password" required className={champ} />
            <label htmlFor="c-code" className={`${etiquette} mt-3`}>Code administrateur (administrateurs uniquement)</label>
            <input id="c-code" name="code" type="text" inputMode="numeric" autoComplete="one-time-code" className={champ} />
            <p className="mt-3 text-sm"><Link href="/compte/mot-de-passe-oublie" className="underline hover:text-rouge">Mot de passe oublié ?</Link></p>
          </FormulaireAction>
        </div>
        <div className="carte p-6">
          <h2 className="mb-1 text-3xl">Inscription gratuite</h2>
          <p className="mb-4 text-sm text-gris">Pour le concours de pronostics. Aucun achat, aucun don, aucun abonnement.</p>
          <FormulaireAction action={inscription} libelle="Créer mon compte" variante="clair">
            <label htmlFor="i-email" className={etiquette}>E-mail</label>
            <input id="i-email" name="email" type="email" autoComplete="email" required className={champ} />
            <label htmlFor="i-pseudo" className={`${etiquette} mt-3`}>Pseudo (affiché au classement)</label>
            <input id="i-pseudo" name="pseudo" type="text" minLength={3} maxLength={24} required className={champ} />
            <label htmlFor="i-mdp" className={`${etiquette} mt-3`}>Mot de passe (8 caractères minimum)</label>
            <input id="i-mdp" name="motDePasse" type="password" autoComplete="new-password" minLength={8} required className={champ} />
            <div className="hidden" aria-hidden><label>Site web<input name="site_web" tabIndex={-1} autoComplete="off" /></label></div>
            <label className="mt-3 flex items-start gap-2 text-sm"><input type="checkbox" name="cgu" className="mt-1" required /> J&apos;accepte le règlement du concours (version de démonstration) et les conditions d&apos;utilisation.</label>
            <label className="mt-2 flex items-start gap-2 text-sm"><input type="checkbox" name="donnees" className="mt-1" required /> J&apos;accepte le traitement de mes données décrit dans la politique de confidentialité.</label>
            <p className="mt-2 text-xs text-gris">Un seul compte par personne. Les comptes multiples sont exclus du classement.</p>
          </FormulaireAction>
        </div>
        <Encart titre="Comptes de démonstration" teinte="ambre">
          <ul className="space-y-2 text-xs">
            {COMPTES_DEMO.map((c) => (
              <li key={c.email} className="carte p-2">
                <p className="font-600 capitalize">{c.role}</p>
                <p>{c.email} · {c.motDePasse}{"codeAdmin" in c ? ` · code ${c.codeAdmin}` : ""}</p>
              </li>
            ))}
          </ul>
          <p className="text-xs">À supprimer avant toute mise en production.</p>
        </Encart>
      </div>
    </Section>
  );
}
