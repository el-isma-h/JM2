import type { Metadata } from "next";
import { Section, Titre, Bouton } from "@/components/ui";
import { verifierEmail } from "@/lib/actions";

export const metadata: Metadata = { title: "Vérification de l'adresse" };
export const dynamic = "force-dynamic";

export default async function Verifier({ searchParams }: { searchParams: Promise<{ jeton?: string }> }) {
  const { jeton } = await searchParams;
  const res = jeton ? await verifierEmail(jeton) : { ok: false as const, erreur: "Lien incomplet" };
  return (
    <Section>
      <Titre as="h1" sur="Compte">{res.ok ? "Adresse confirmée" : "Vérification impossible"}</Titre>
      <p className="max-w-xl text-ardoise-2">{res.ok ? "Merci. Vous pouvez maintenant utiliser le paiement de démonstration et toutes les fonctions de votre espace." : res.erreur}</p>
      <div className="mt-6 flex gap-3"><Bouton href="/espace">Mon espace</Bouton><Bouton variante="contour" href="/connexion">Connexion</Bouton></div>
    </Section>
  );
}
