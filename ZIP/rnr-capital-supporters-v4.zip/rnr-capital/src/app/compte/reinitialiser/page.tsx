import type { Metadata } from "next";
import { Section, Titre } from "@/components/ui";
import { FormulaireAction, champ, etiquette } from "@/components/FormulaireAction";
import { reinitialiserMotDePasse } from "@/lib/actions";

export const metadata: Metadata = { title: "Nouveau mot de passe" };

export default async function Reinitialiser({ searchParams }: { searchParams: Promise<{ jeton?: string }> }) {
  const { jeton = "" } = await searchParams;
  return (
    <Section>
      <Titre as="h1" sur="Compte">Choisir un nouveau mot de passe</Titre>
      <div className="max-w-md carte p-6">
        <FormulaireAction action={reinitialiserMotDePasse} libelle="Enregistrer">
          <input type="hidden" name="jeton" value={jeton} />
          <label htmlFor="mdp" className={etiquette}>Nouveau mot de passe (8 caractères minimum)</label>
          <input id="mdp" name="motDePasse" type="password" minLength={8} required autoComplete="new-password" className={champ} />
          <label htmlFor="conf" className={`${etiquette} mt-3`}>Confirmation</label>
          <input id="conf" name="confirmation" type="password" minLength={8} required autoComplete="new-password" className={champ} />
        </FormulaireAction>
      </div>
    </Section>
  );
}
