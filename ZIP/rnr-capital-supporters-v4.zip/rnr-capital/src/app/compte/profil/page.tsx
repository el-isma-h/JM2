import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Section, Titre, Badge, Encart, dateFr } from "@/components/ui";
import { FormulaireAction, champ, etiquette } from "@/components/FormulaireAction";
import { majProfil, changerMotDePasse, supprimerCompte, renvoyerVerification } from "@/lib/actions";
import { utilisateurCourant } from "@/lib/auth";

export const metadata: Metadata = { title: "Profil et sécurité" };
export const dynamic = "force-dynamic";

export default async function Profil() {
  const user = await utilisateurCourant();
  if (!user) redirect("/connexion?retour=/compte/profil");
  return (
    <>
      <Section className="pb-6">
        <Titre as="h1" sur="Compte">Profil, sécurité et données</Titre>
        <p className="text-sm text-ardoise-2">{user.email} · compte créé le {dateFr(user.creeLe)} · rôle : {user.role} · {user.emailVerifie ? <Badge teinte="vert">adresse confirmée</Badge> : <Badge teinte="ambre">adresse non confirmée</Badge>}</p>
        {!user.emailVerifie && (
          <form action={renvoyerVerification} className="mt-3">
            <button className="display border border-ambre-clair px-4 py-2 text-base font-900 uppercase tracking-wider text-ambre hover:bg-ambre hover:text-blanc">Renvoyer l&apos;e-mail de confirmation</button>
          </form>
        )}
      </Section>
      <Section className="border-t border-gris-clair bg-clair-2">
        <div className="grid gap-10 lg:grid-cols-3">
          <div>
            <h2 className="mb-4 text-3xl">Profil</h2>
            <FormulaireAction action={majProfil} libelle="Enregistrer" variante="clair">
              <label htmlFor="pseudo" className={etiquette}>Pseudo (affiché au classement)</label>
              <input id="pseudo" name="pseudo" defaultValue={user.pseudo} minLength={3} maxLength={24} required className={champ} />
              <div className="mt-3 grid grid-cols-2 gap-3">
                <div><label htmlFor="prenom" className={etiquette}>Prénom</label><input id="prenom" name="prenom" defaultValue={user.prenom ?? ""} className={champ} /></div>
                <div><label htmlFor="nom" className={etiquette}>Nom</label><input id="nom" name="nom" defaultValue={user.nom ?? ""} className={champ} /></div>
              </div>
              <label htmlFor="tel" className={`${etiquette} mt-3`}>Téléphone (facultatif)</label>
              <input id="tel" name="telephone" type="tel" defaultValue={user.telephone ?? ""} className={champ} />
              <label className="mt-3 flex items-start gap-2 text-sm"><input type="checkbox" name="reconnaissancePublique" defaultChecked={user.consentements.reconnaissancePublique} className="mt-1" /> J&apos;autorise le club à me citer publiquement comme actionnaire supporter (facultatif, révocable).</label>
            </FormulaireAction>
          </div>
          <div>
            <h2 className="mb-4 text-3xl">Mot de passe</h2>
            <FormulaireAction action={changerMotDePasse} libelle="Modifier" variante="contour">
              <label htmlFor="actuel" className={etiquette}>Mot de passe actuel</label>
              <input id="actuel" name="actuel" type="password" autoComplete="current-password" required className={champ} />
              <label htmlFor="nouveau" className={`${etiquette} mt-3`}>Nouveau mot de passe</label>
              <input id="nouveau" name="nouveau" type="password" autoComplete="new-password" minLength={8} required className={champ} />
            </FormulaireAction>
          </div>
          <div>
            <h2 className="mb-4 text-3xl">Mes données</h2>
            <Encart titre="Droits RGPD" teinte="gris"><p>Accès et rectification : ce formulaire. Portabilité : export de vos pronostics sur demande au support. Effacement : ci-dessous, sauf obligations légales de conservation liées à des titres ou paiements.</p></Encart>
            <FormulaireAction action={supprimerCompte} libelle="Supprimer mon compte" variante="contour" className="mt-4 [&>button]:border-rouge [&>button]:text-rouge">
              <label htmlFor="confirmation" className={etiquette}>Tapez SUPPRIMER pour confirmer</label>
              <input id="confirmation" name="confirmation" className={champ} />
            </FormulaireAction>
          </div>
        </div>
      </Section>
    </>
  );
}
