import type { Metadata } from "next";
import { Section, Titre } from "@/components/ui";
import { FormulaireAction, champ, etiquette } from "@/components/FormulaireAction";
import { demanderReinitialisation } from "@/lib/actions";

export const metadata: Metadata = { title: "Mot de passe oublié" };

export default function MotDePasseOublie() {
  return (
    <Section>
      <Titre as="h1" sur="Compte">Mot de passe oublié</Titre>
      <div className="max-w-md carte p-6">
        <FormulaireAction action={demanderReinitialisation} libelle="Envoyer le lien">
          <label htmlFor="email" className={etiquette}>Adresse e-mail du compte</label>
          <input id="email" name="email" type="email" required className={champ} />
          <p className="mt-2 text-xs text-gris">En démonstration, l&apos;e-mail est consigné dans le journal de l&apos;administration (onglet « E-mails »).</p>
        </FormulaireAction>
      </div>
    </Section>
  );
}
