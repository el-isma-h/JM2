import type { Metadata } from "next";
import { campagne, liensOfficiels } from "@/config/campagne";
import { classementNationale, objectifsSaison, RNR } from "@/data/matchs";
import { risques } from "@/data/contenus";
import { Section, Titre, Encart, Badge, Bouton, Chiffre } from "@/components/ui";
import { CarteMatch } from "@/components/CarteMatch";
import { SectionResultats } from "@/components/SectionResultats";
import { FondPhoto } from "@/components/FondPhoto";
import { Badge as BadgeOr } from "@/components/ui";
import { matchsDb } from "@/lib/stats";
import { budget, euros } from "@/lib/souscription";
import { lireDb } from "@/lib/store";

export const metadata: Metadata = { title: "Le projet du club" };

export default async function Projet() {
  const { joues, tous } = await matchsDb();
  const db = await lireDb();
  const victoires = joues.filter((m) => (m.domicile === RNR ? (m.scoreDomicile ?? 0) > (m.scoreExterieur ?? 0) : (m.scoreExterieur ?? 0) > (m.scoreDomicile ?? 0))).length;
  const marques = joues.reduce((n, m) => n + ((m.domicile === RNR ? m.scoreDomicile : m.scoreExterieur) ?? 0), 0);
  const concedes = joues.reduce((n, m) => n + ((m.domicile === RNR ? m.scoreExterieur : m.scoreDomicile) ?? 0), 0);
  const coutAvantages = db.statuts.reduce((n, s) => n + s.avantages.reduce((m, a) => m + (a.coutEstime ?? 0), 0), 0) * Math.max(1, db.souscriptions.filter((x) => x.statut === "confirmee").length);
  const b = budget(db.parametres.objectif, Math.max(coutAvantages, campagne.budget.coutAvantagesEstime));

  return (
    <>
      <section className="section-sombre px-4 py-20 sm:px-6 md:py-28">
        <FondPhoto src="/images/equipe.jpg" position="center 25%" opacite={0.75} />
        <div className="relative z-10 mx-auto max-w-6xl">
          <BadgeOr teinte="or">Le projet du club</BadgeOr>
          <h1 className="mt-4 max-w-3xl text-5xl sm:text-6xl md:text-7xl">Un club, un territoire, une nouvelle ère</h1>
          <p className="mt-4 max-w-2xl text-blanc/80">« Un projet sportif ambitieux ne peut exister sans un projet économique solide. » Delphine Bunel, présidente, juin 2026.</p>
        </div>
      </section>
      <Section className="pb-8">
        <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
          <div className="space-y-4 text-lg text-ardoise-2">
            <p>Le Rouen Normandie Rugby évolue en Nationale, le troisième échelon du rugby français, au stade Robert-Diochon. Le club est porté par la SAS Rouen Normandie Rugby, présidée par Delphine Bunel, et par un réseau de plus de 260 entreprises partenaires.</p>
            <p>En juin 2026, la présidente annonçait l&apos;ouverture d&apos;un nouveau cycle et un plan stratégique « RNR 2030 », en rappelant qu&apos;un projet sportif ambitieux suppose un projet économique solide, soutenu par les actionnaires, les partenaires et les collectivités.</p>
            <p>Cette plateforme propose d&apos;y associer les supporters : souscrire des actions pour renforcer les fonds propres du club, rejoindre une communauté avec des avantages rugby, et vivre chaque match dans un concours gratuit de pronostics.</p>
          </div>
          <Encart titre="Ce que cette page ne dit pas" teinte="ambre">
            <p>Le besoin de trésorerie du club est une hypothèse de travail du porteur du projet. Aucun montant, aucune difficulté financière et aucune affirmation sur la situation du club ne sont publiés sans validation de la direction.</p>
            <p>Sources publiques utilisées : site officiel du club (actualités, calendrier, classement, partenaires).</p>
          </Encart>
        </div>
      </Section>

      <Section className="border-y border-gris-clair bg-clair-2">
        <Titre sur="Fonds propres et trésorerie">À quoi serviraient les fonds</Titre>
        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <ul className="space-y-3">
              {campagne.utilisationFonds.map((u) => (
                <li key={u.poste} className="flex items-center justify-between border-b border-gris-clair pb-2">
                  <span>{u.poste}</span>
                  <span className="display text-2xl font-900 text-rouge">{Math.round(u.part * 100)} %</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-gris">Répartition prévisionnelle : hypothèse à valider par la direction du club.</p>
          </div>
          <div>
            <p className="display mb-3 text-xl font-900">Budget de transparence <Badge teinte="ambre">hypothèse</Badge></p>
            <dl className="divide-y divide-gris-clair border border-gris-clair text-sm">
              <Ligne k="Collecte brute (objectif)" v={euros(b.collecteBrute)} />
              <Ligne k={`Frais de l'opération (${Math.round(campagne.budget.fraisOperationPct * 100)} %, à aligner sur le prestataire)`} v={`− ${euros(b.fraisOperation)}`} />
              <Ligne k="Coût estimé des avantages" v={`− ${euros(b.coutAvantages)}`} />
              <Ligne k="Coût éventuel des lots (aucun sécurisé)" v={`− ${euros(b.coutLots)}`} />
              <Ligne k="Montant net disponible pour le club" v={euros(b.net)} fort />
              <Ligne k="Comptes rendus aux actionnaires" v={`Fréquence ${campagne.budget.frequenceComptesRendus}`} />
            </dl>
          </div>
        </div>
      </Section>

      <SectionResultats joues={joues} titre="La saison des Lions" />
      <Section id="sportif">
        <Titre sur="Tableau de bord sportif">Classement et objectifs</Titre>
        <div className="grid grid-cols-2 gap-6 md:grid-cols-5">
          <Chiffre valeur={`${joues.length}`} label="Matchs joués" />
          <Chiffre valeur={`${victoires}`} label="Victoires" />
          <Chiffre valeur={`${joues.length - victoires}`} label="Défaites" />
          <Chiffre valeur={`${marques}`} label="Points marqués" />
          <Chiffre valeur={`${concedes}`} label="Points concédés" />
        </div>
        <div className="mt-12 grid gap-10 lg:grid-cols-2 [&>*]:min-w-0">
          <div>
            <h3 className="mb-4 text-2xl">Classement Nationale <Badge teinte="gris">relevé le {classementNationale.releveLe.split("-").reverse().join("/")}</Badge></h3>
            <div className="overflow-x-auto border border-gris-clair">
              <table className="w-full text-sm">
                <thead className="bg-clair-2 text-left text-xs uppercase tracking-wider text-gris">
                  <tr><th className="px-3 py-2">#</th><th className="px-3 py-2">Club</th><th className="px-3 py-2">J</th><th className="px-3 py-2">G</th><th className="px-3 py-2">N</th><th className="px-3 py-2">P</th><th className="px-3 py-2">+/−</th><th className="px-3 py-2">Pts</th></tr>
                </thead>
                <tbody>
                  {classementNationale.lignes.map((l) => (
                    <tr key={l.club} className={l.club === "Rouen" ? "bg-rouge/10 font-900 text-rouge" : "border-t border-clair-2"}>
                      <td className="px-3 py-2">{l.pos}</td><td className="px-3 py-2">{l.club}</td><td className="px-3 py-2">{l.j}</td><td className="px-3 py-2">{l.g}</td><td className="px-3 py-2">{l.n}</td><td className="px-3 py-2">{l.p}</td><td className="px-3 py-2">{l.diff > 0 ? `+${l.diff}` : l.diff}</td><td className="px-3 py-2">{l.pts}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-2 text-xs text-gris">{classementNationale.note} <a href={liensOfficiels.classement} className="underline" target="_blank" rel="noopener noreferrer">Classement officiel</a>.</p>
          </div>
          <div>
            <h3 className="mb-4 text-2xl">Objectifs de saison <Badge teinte="ambre">hypothèse</Badge></h3>
            <ul className="space-y-2 text-ardoise-2">
              {objectifsSaison.items.map((o) => <li key={o} className="border-l-2 border-rouge pl-3">{o}</li>)}
            </ul>
            <Encart titre="Performance sportive et valeur des actions" teinte="rouge">
              <p>Une victoire, une qualification ou une promotion en Pro D2 n&apos;augmentent pas mécaniquement la valeur d&apos;une action, et aucun prix de revente n&apos;est garanti. Cette plateforme n&apos;affiche jamais « achetée 100 €, vaut désormais 150 € ».</p>
            </Encart>
            <h3 className="mb-3 mt-8 text-2xl">Derniers matchs</h3>
            <div className="space-y-3">{joues.slice(-4).reverse().map((m) => <CarteMatch key={m.id} match={m} compact />)}</div>
            <p className="mt-2 text-xs text-gris">{tous.length} journées au calendrier. <a href={liensOfficiels.calendrier} className="underline" target="_blank" rel="noopener noreferrer">Calendrier officiel</a>.</p>
          </div>
        </div>
      </Section>

      <Section className="border-t border-gris-clair bg-clair-2">
        <Titre sur="Avant d'investir">Les risques</Titre>
        <ul className="grid gap-3 md:grid-cols-2">
          {risques.map((r) => <li key={r} className="carte p-4 text-ardoise-2">{r}</li>)}
        </ul>
        <div className="mt-8 flex flex-wrap gap-3">
          <Bouton href="/investir">Simuler une souscription</Bouton>
          <Bouton variante="contour" href="/documents">Documents et risques</Bouton>
        </div>
      </Section>
    </>
  );
}

function Ligne({ k, v, fort }: { k: string; v: string; fort?: boolean }) {
  return (
    <div className={`flex items-center justify-between gap-4 px-4 py-2.5 ${fort ? "bg-blanc font-900" : ""}`}>
      <dt className="text-ardoise-2">{k}</dt>
      <dd className={fort ? "display text-xl text-vert" : ""}>{v}</dd>
    </div>
  );
}
