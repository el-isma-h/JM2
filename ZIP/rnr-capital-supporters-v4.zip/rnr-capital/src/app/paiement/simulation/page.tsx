import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Section, Titre, Encart } from "@/components/ui";
import { FormulaireAction, champ, etiquette } from "@/components/FormulaireAction";
import { confirmerPaiementSimule } from "@/lib/actions";
import { utilisateurCourant } from "@/lib/auth";
import { lireDb } from "@/lib/store";
import { euros } from "@/lib/souscription";

export const metadata: Metadata = { title: "Paiement de démonstration" };
export const dynamic = "force-dynamic";

export default async function Simulation({ searchParams }: { searchParams: Promise<{ souscription?: string }> }) {
  const { souscription } = await searchParams;
  const user = await utilisateurCourant();
  if (!user) redirect("/connexion?retour=/investir");
  const db = await lireDb();
  const s = db.souscriptions.find((x) => x.id === souscription && x.userId === user.id);
  if (!s) redirect("/investir");
  return (
    <Section>
      <Titre as="h1" sur="Simulation de paiement">Stripe Checkout n&apos;est pas configuré</Titre>
      <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
        <div className="carte p-6">
          <p className="text-sm text-gris">Cette page remplace Stripe Checkout tant qu&apos;aucune clé de test (<code>STRIPE_SECRET_KEY</code> commençant par <code>sk_test_</code>) n&apos;est renseignée. Rien n&apos;est débité, aucun titre n&apos;est émis.</p>
          <dl className="mt-4 divide-y divide-gris-clair border-y border-gris-clair text-sm">
            <div className="flex justify-between py-2"><dt>Souscription</dt><dd>{s.id}</dd></div>
            <div className="flex justify-between py-2"><dt>Actions</dt><dd>{s.actions}</dd></div>
            <div className="flex justify-between py-2 font-900"><dt>Montant (démonstration)</dt><dd>{euros(s.montant + s.frais)}</dd></div>
          </dl>
          <FormulaireAction action={confirmerPaiementSimule} libelle="Payer (test)">
            <input type="hidden" name="souscription" value={s.id} />
            <label htmlFor="carte" className={`${etiquette} mt-4`}>Numéro de carte de test</label>
            <input id="carte" name="carte" defaultValue="4242 4242 4242 4242" readOnly className={champ} />
            <div className="mt-3 grid grid-cols-2 gap-3">
              <div><label htmlFor="exp" className={etiquette}>Expiration</label><input id="exp" defaultValue="12/34" readOnly className={champ} /></div>
              <div><label htmlFor="cvc" className={etiquette}>CVC</label><input id="cvc" defaultValue="123" readOnly className={champ} /></div>
            </div>
            <label className="mt-3 flex items-center gap-2 text-sm"><input type="radio" name="resultat" value="succes" defaultChecked /> Simuler un paiement réussi</label>
            <label className="mt-1 flex items-center gap-2 text-sm"><input type="radio" name="resultat" value="echec" /> Simuler un paiement refusé</label>
          </FormulaireAction>
        </div>
        <Encart titre="En production" teinte="rouge">
          <p>Une souscription d&apos;actions n&apos;est jamais encaissée par la plateforme : le paiement passe par le prestataire habilité, sur un compte séquestre, après identification et signature. Stripe sert ici uniquement à démontrer le parcours.</p>
        </Encart>
      </div>
    </Section>
  );
}
