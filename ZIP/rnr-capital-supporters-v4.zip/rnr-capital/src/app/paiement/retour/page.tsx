import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Section, Titre, Bouton, Encart } from "@/components/ui";
import { utilisateurCourant } from "@/lib/auth";
import { lireDb } from "@/lib/store";
import { marquerPaiementRecu } from "@/lib/actions";
import { verifierSession, stripeConfigure } from "@/lib/stripe";
import { euros } from "@/lib/souscription";

export const metadata: Metadata = { title: "Retour de paiement" };
export const dynamic = "force-dynamic";

export default async function Retour({ searchParams }: { searchParams: Promise<{ statut?: string; souscription?: string; session?: string }> }) {
  const { statut, souscription, session } = await searchParams;
  const user = await utilisateurCourant();
  if (!user) redirect("/connexion?retour=/espace");
  let db = await lireDb();
  let s = db.souscriptions.find((x) => x.id === souscription && x.userId === user.id);
  if (!s) redirect("/espace");
  // Retour Stripe réel : vérification côté serveur de la session (le webhook fait la même chose, de façon fiable).
  if (statut === "succes" && session && stripeConfigure() && s.statut !== "paiement_recu" && s.statut !== "confirmee") {
    const v = await verifierSession(session);
    if (v.paye) await marquerPaiementRecu(s.id, v.paymentIntent, "retour Stripe vérifié");
    db = await lireDb();
    s = db.souscriptions.find((x) => x.id === souscription)!;
  }
  const succes = statut === "succes" && (s.statut === "paiement_recu" || s.statut === "confirmee");
  return (
    <Section>
      <Titre as="h1" sur="Démonstration">{succes ? "Paiement de test reçu" : "Paiement non abouti"}</Titre>
      <div className="max-w-xl space-y-4">
        <p className="text-ardoise-2">{succes ? `${s.actions} action(s), ${euros(s.montant + s.frais)} — statut : paiement reçu. Les titres ne seront « confirmés » qu'après rapprochement par l'administration avec une référence du prestataire.` : "Le paiement a été annulé ou refusé. Votre intention reste enregistrée ; vous pouvez réessayer depuis votre espace."}</p>
        <Encart titre="Rappel" teinte="ambre"><p>Aucun débit réel, aucune émission de titres : ceci est une démonstration en mode test.</p></Encart>
        <div className="flex gap-3"><Bouton href="/espace">Mon espace</Bouton><Bouton variante="contour" href="/investir">Simulateur</Bouton></div>
      </div>
    </Section>
  );
}
