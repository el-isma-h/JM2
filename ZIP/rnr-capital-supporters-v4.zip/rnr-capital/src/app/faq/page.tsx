import type { Metadata } from "next";
import { faq } from "@/data/contenus";
import { Section, Titre } from "@/components/ui";

export const metadata: Metadata = { title: "Questions fréquentes" };

export default function Faq() {
  return (
    <Section>
      <Titre as="h1" sur="FAQ">Questions fréquentes</Titre>
      <div className="max-w-3xl divide-y divide-gris-clair border border-gris-clair">
        {faq.map((f) => (
          <details key={f.question} className="group">
            <summary className="display cursor-pointer list-none px-5 py-4 text-2xl font-900 hover:bg-clair-2 [&::-webkit-details-marker]:hidden">
              <span className="mr-3 text-rouge group-open:hidden">+</span><span className="mr-3 hidden text-rouge group-open:inline">−</span>{f.question}
            </summary>
            <p className="px-5 pb-5 text-ardoise-2">{f.reponse}</p>
          </details>
        ))}
      </div>
    </Section>
  );
}
