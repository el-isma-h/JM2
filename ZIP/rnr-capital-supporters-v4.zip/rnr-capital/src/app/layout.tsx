import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { campagne } from "@/config/campagne";

export const metadata: Metadata = {
  title: { default: `${campagne.nom} — ${campagne.bandeauNonOfficiel}`, template: `%s — ${campagne.nom}` },
  description: "Projet de plateforme d'actionnariat supporters et de concours gratuit de pronostics autour du Rouen Normandie Rugby. Démonstration non officielle.",
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="flex min-h-dvh flex-col overflow-x-hidden">
        <a href="#contenu" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:bg-rouge focus:px-4 focus:py-2 focus:text-blanc">
          Aller au contenu
        </a>
        <Header />
        <div className="bg-or px-4 py-1.5 text-center text-[0.68rem] font-900 uppercase tracking-[0.12em] text-ardoise">
          Démonstration : données fictives, aucun encaissement, aucun titre émis. {campagne.bandeauNonOfficiel}.
        </div>
        <main id="contenu" className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
