import type { Metadata } from "next";
import { documentsOperation, risques } from "@/data/contenus";
import { campagne } from "@/config/campagne";
import { Section, Titre, Badge, Encart, teinteEtat } from "@/components/ui";

export const metadata: Metadata = { title: "Documents et risques" };

const decisionsClub = [
  "Autoriser (ou non) la présentation de la plateforme comme officielle et l'usage des logos.",
  "Arrêter le montage : augmentation de capital de la SAS ou véhicule d'investissement de supporters.",
  "Choisir le prestataire habilité pour la souscription (identification, séquestre, signature).",
  "Valider l'objectif de financement, le prix de souscription, le nombre d'actions et le calendrier.",
  "Communiquer le capital social et la dilution pour afficher un pourcentage de détention.",
  "Approuver et budgéter la grille des statuts et avantages ; préciser le périmètre de l'abonnement (phases finales, coupes, amicaux, délocalisés).",
  "Trancher sur l'avantage Olympique de Marseille ou son alternative rugby.",
  "Faire valider juridiquement le règlement du concours gratuit avant toute activation avec des lots.",
  "Contractualiser le lot principal (CUPRA) ou y renoncer ; sécuriser chaque lot secondaire.",
  "Valider la source officielle des résultats et le circuit de vérification.",
  "Valider les objectifs de saison et les mentions sportives publiées.",
  "Fournir les mentions légales, la politique de confidentialité et le DPO.",
];

export default function Documents() {
  return (
    <>
      <Section className="pb-6">
        <Titre as="h1" sur="Transparence">Documents et risques</Titre>
        <Encart titre="Aucun document approuvé à ce jour" teinte="ambre">
          <p>Les droits de vote, dividendes éventuels, restrictions de cession et modalités de sortie proviendront exclusivement des documents approuvés par l&apos;émetteur. Tant qu&apos;ils ne sont pas publiés ici, aucune souscription n&apos;est possible.</p>
        </Encart>
      </Section>
      <Section className="border-y border-gris-clair bg-clair-2">
        <Titre sur="Documents de l'opération">État de chaque pièce</Titre>
        <ul className="divide-y divide-gris-clair border border-gris-clair">
          {documentsOperation.map((d) => (
            <li key={d.titre} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
              <div><p className="display text-xl font-900">{d.titre}</p><p className="text-sm text-gris">{d.description}</p></div>
              <Badge teinte={teinteEtat(d.statut)}>{d.statut === "disponible" ? "Disponible" : d.statut === "a_valider" ? "À valider" : "À produire"}</Badge>
            </li>
          ))}
        </ul>
      </Section>
      <Section>
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <Titre sur="Risques">Ce que tout investisseur doit savoir</Titre>
            <ul className="space-y-3">{risques.map((r) => <li key={r} className="border-l-4 border-rouge pl-4 text-ardoise-2">{r}</li>)}</ul>
          </div>
          <div>
            <Titre sur="Décisions attendues">Ce que le club doit trancher</Titre>
            <ol className="space-y-2">
              {decisionsClub.map((d, i) => <li key={d} className="flex gap-3 text-sm text-ardoise-2"><span className="display shrink-0 text-xl font-900 text-rouge">{String(i + 1).padStart(2, "0")}</span>{d}</li>)}
            </ol>
            <p className="mt-4 text-xs text-gris">Émetteur pressenti : {campagne.emetteur.denomination}. Montage : {campagne.emetteur.montage === "a_definir" ? "à définir" : campagne.emetteur.montage}.</p>
          </div>
        </div>
      </Section>
    </>
  );
}
