import { Section, Titre, Bouton } from "@/components/ui";

export default function NotFound() {
  return (
    <Section>
      <Titre as="h1" sur="Erreur 404">Page introuvable</Titre>
      <Bouton href="/">Retour à l&apos;accueil</Bouton>
    </Section>
  );
}
