import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { exigerRole } from "@/lib/auth";
import { lireDb } from "@/lib/store";
import { classer } from "@/lib/concours";
import { lotPrincipal } from "@/data/lots";
import { documentsOperation } from "@/data/contenus";
import { Section, Titre, Encart, Badge, Chiffre, dateFr, dateHeureFr, teinteEtat } from "@/components/ui";
import { FormulaireAction, champ, etiquette } from "@/components/FormulaireAction";
import { saisirResultat, changerStatutMatch, majParametres, changerStatutSouscription, changerEtatReservation, reinitialiserDemo, gererCompte, majAvantage, majLot, majLotPrincipal, majPartenaire } from "@/lib/actions";
import { euros, budget } from "@/lib/souscription";
import { statsCollecte } from "@/lib/stats";
import { stripeConfigure } from "@/lib/stripe";
import { CourbeCollecte } from "@/components/CourbeCollecte";

export const metadata: Metadata = { title: "Administration" };
export const dynamic = "force-dynamic";

const onglets = ["campagne", "souscriptions", "comptes", "matchs", "concours", "avantages", "lots", "partenaires", "emails", "documents", "audit"] as const;
const petit = "[&>button]:mt-2 [&>button]:px-3 [&>button]:py-1 [&>button]:text-sm";

export default async function Admin({ searchParams }: { searchParams: Promise<{ onglet?: string }> }) {
  const acces = await exigerRole(["admin"]);
  if (!acces) redirect("/connexion?retour=/admin");
  const { onglet = "campagne" } = await searchParams;
  const db = await lireDb();
  const stats = await statsCollecte();
  const b = budget(db.parametres.objectif);
  const classement = classer(db.participants, db.pronostics, db.matchs);
  const matchs = [...db.matchs].sort((a, c) => Date.parse(a.coupDEnvoi) - Date.parse(c.coupDEnvoi));
  const pseudo = (id: string) => db.users.find((u) => u.id === id)?.pseudo ?? id;
  const fiche = db.parametres.lotPrincipal;
  const parJour = new Map<string, number>();
  for (const p of db.pronostics) { const j = p.modifieLe.slice(0, 10); parJour.set(j, (parJour.get(j) ?? 0) + 1); }

  return (
    <>
      <Section className="pb-4">
        <Titre as="h1" sur={`Administration · ${acces.user.pseudo} · authentification renforcée`}>Tableau de bord</Titre>
        <div className="grid grid-cols-2 gap-6 md:grid-cols-5">
          <Chiffre valeur={euros(stats.capitalConfirme)} label="Capital confirmé" />
          <Chiffre valeur={euros(stats.paiementsRecus)} label="Paiements reçus (démo)" />
          <Chiffre valeur={euros(stats.intentions)} label="Intentions" />
          <Chiffre valeur={`${stats.participantsConcours}`} label="Participants au concours" />
          <Chiffre valeur={`${db.users.length}`} label="Comptes" />
        </div>
        <div className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <div className="carte p-4"><p className="display mb-2 text-xl font-900">Collecte cumulée</p><CourbeCollecte souscriptions={db.souscriptions} objectif={db.parametres.objectif} /></div>
          <div className="carte p-4">
            <p className="display mb-2 text-xl font-900">Pronostics par jour</p>
            <ul className="space-y-1 text-xs">
              {[...parJour.entries()].sort().slice(-10).map(([j, n]) => (
                <li key={j} className="flex items-center gap-2"><span className="w-20 text-gris">{j.split("-").reverse().join("/")}</span><span className="h-3 bg-rouge" style={{ width: `${Math.min(100, n * 6)}%` }} aria-hidden /><span>{n}</span></li>
              ))}
            </ul>
            <p className="display mb-2 mt-4 text-xl font-900">Exports CSV</p>
            <div className="flex flex-wrap gap-2 text-sm">
              {["souscriptions", "classement", "participants", "audit"].map((f) => <a key={f} href={`/api/export/${f}.csv`} className="border border-gris-clair px-3 py-1 hover:border-ardoise">{f}.csv</a>)}
            </div>
          </div>
        </div>
        <nav aria-label="Sections d'administration" className="mt-8 flex flex-wrap gap-2">
          {onglets.map((o) => (
            <a key={o} href={`/admin?onglet=${o}`} aria-current={onglet === o ? "page" : undefined} className={`display px-4 py-2 text-base font-900 uppercase tracking-wider ${onglet === o ? "bg-rouge text-blanc" : "border border-gris-clair text-ardoise-2 hover:border-ardoise"}`}>{o}</a>
          ))}
        </nav>
      </Section>

      <Section className="border-t border-gris-clair bg-clair-2">
        {onglet === "campagne" && (
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 className="mb-4 text-3xl">Campagne et objectifs</h2>
              <FormulaireAction action={majParametres} libelle="Enregistrer les paramètres">
                <label htmlFor="objectif" className={etiquette}>Objectif de financement (€) — hypothèse à valider</label>
                <input id="objectif" name="objectif" type="number" min={1} defaultValue={db.parametres.objectif} className={champ} />
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <div><label htmlFor="ouverture" className={etiquette}>Ouverture</label><input id="ouverture" name="ouverture" type="date" defaultValue={db.parametres.ouverture} className={champ} /></div>
                  <div><label htmlFor="cloture" className={etiquette}>Clôture</label><input id="cloture" name="cloture" type="date" defaultValue={db.parametres.cloture} className={champ} /></div>
                </div>
                <div className="mt-4 space-y-2 text-sm">
                  <label className="flex items-center gap-2"><input type="checkbox" name="concoursActif" defaultChecked={db.parametres.concoursActif} /> Concours gratuit actif</label>
                  <label className="flex items-center gap-2"><input type="checkbox" name="lotsActifs" defaultChecked={db.parametres.lotsActifs} /> Lots annoncés publiquement (uniquement après contrats signés et règlement validé)</label>
                  <label className="flex items-center gap-2"><input type="checkbox" name="omActif" defaultChecked={db.parametres.omActif} /> Module Olympique de Marseille activé (uniquement après accord et contrat)</label>
                  <label className="flex items-center gap-2"><input type="checkbox" name="stripeDemoActif" defaultChecked={db.parametres.stripeDemoActif} /> Paiement de démonstration (Stripe test : {stripeConfigure() ? "clé de test configurée" : "aucune clé, simulation locale"})</label>
                </div>
              </FormulaireAction>
            </div>
            <div>
              <h2 className="mb-4 text-3xl">Budget de transparence</h2>
              <dl className="divide-y divide-gris-clair border border-gris-clair text-sm">
                {[["Collecte brute (objectif)", euros(b.collecteBrute)], ["Frais de l'opération", euros(b.fraisOperation)], ["Coût des avantages (estimé)", euros(b.coutAvantages)], ["Coût des lots (aucun sécurisé)", euros(b.coutLots)], ["Net disponible pour le club", euros(b.net)]].map(([k, v]) => (
                  <div key={k} className="flex justify-between px-4 py-2.5"><dt className="text-ardoise-2">{k}</dt><dd className="font-900">{v}</dd></div>
                ))}
              </dl>
              <form action={reinitialiserDemo} className="mt-6">
                <button className="display border border-rouge px-4 py-2 text-base font-900 uppercase tracking-wider text-rouge hover:bg-rouge hover:text-blanc">Réinitialiser les données de démonstration</button>
              </form>
            </div>
          </div>
        )}

        {onglet === "souscriptions" && (
          <div>
            <h2 className="mb-2 text-3xl">Souscriptions et rapprochement</h2>
            <p className="mb-4 text-sm text-gris">Confirmer des titres exige une référence du prestataire habilité. Un paiement Stripe de test n&apos;est jamais une confirmation de titres. Chaque changement est journalisé avec son état précédent.</p>
            <div className="space-y-3">
              {db.souscriptions.map((s) => (
                <div key={s.id} className="carte p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                    <span><strong>{pseudo(s.userId)}</strong> · {s.actions} action(s) · {euros(s.montant)} + {euros(s.frais)} frais · {dateFr(s.creeLe)}{s.stripeSessionId && <span className="ml-2 text-xs text-gris">Stripe {s.stripeSessionId}</span>}{s.stripePaymentIntent && <span className="ml-2 text-xs text-gris">PI {s.stripePaymentIntent}</span>}</span>
                    <Badge teinte={s.statut === "confirmee" ? "vert" : s.statut === "annulee" ? "rouge" : "ambre"}>{s.statut}</Badge>
                  </div>
                  <FormulaireAction action={changerStatutSouscription} libelle="Mettre à jour" variante="contour" className={`mt-3 ${petit}`}>
                    <input type="hidden" name="id" value={s.id} />
                    <div className="grid gap-2 sm:grid-cols-2">
                      <select name="statut" defaultValue={s.statut} className={champ} aria-label="Nouveau statut">
                        {["intention", "en_attente_prestataire", "paiement_recu", "confirmee", "annulee"].map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                      <input name="reference" placeholder="Référence prestataire" defaultValue={s.referencePrestataire ?? ""} className={champ} aria-label="Référence prestataire" />
                    </div>
                  </FormulaireAction>
                </div>
              ))}
              {!db.souscriptions.length && <p className="text-gris">Aucune souscription.</p>}
            </div>
          </div>
        )}

        {onglet === "comptes" && (
          <div>
            <h2 className="mb-2 text-3xl">Comptes</h2>
            <p className="mb-4 text-sm text-gris">Rôle, suspension, confirmation manuelle d&apos;adresse. Un administrateur créé ici reçoit le code de démonstration 246810 (à remplacer en production par un vrai deuxième facteur).</p>
            <div className="grid gap-3 lg:grid-cols-2">
              {db.users.map((u) => (
                <FormulaireAction key={u.id} action={gererCompte} libelle="Enregistrer" variante="contour" className={`carte p-4 ${petit}`}>
                  <input type="hidden" name="id" value={u.id} />
                  <p className="text-sm"><strong>{u.pseudo}</strong> · {u.email} · créé le {dateFr(u.creeLe)} {u.id.startsWith("usr_demo") || u.id.startsWith("usr_fictif") ? <Badge teinte="ambre">démo</Badge> : null}</p>
                  <div className="mt-2 flex flex-wrap items-center gap-4 text-sm">
                    <select name="role" defaultValue={u.role} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Rôle">{["supporter", "actionnaire", "admin"].map((r) => <option key={r} value={r}>{r}</option>)}</select>
                    <label className="flex items-center gap-1"><input type="checkbox" name="emailVerifie" defaultChecked={u.emailVerifie} /> adresse confirmée</label>
                    <label className="flex items-center gap-1"><input type="checkbox" name="suspendu" defaultChecked={u.suspendu} /> suspendu</label>
                  </div>
                </FormulaireAction>
              ))}
            </div>
          </div>
        )}

        {onglet === "matchs" && (
          <div>
            <h2 className="mb-2 text-3xl">Matchs et résultats</h2>
            <p className="mb-4 text-sm text-gris">Source officielle non branchée (RESULTS_SOURCE_URL vide) : saisie vérifiée par l&apos;administration. La correction d&apos;un résultat déjà vérifié exige un motif ; rien n&apos;est modifié silencieusement.</p>
            <div className="grid gap-4 lg:grid-cols-2">
              {matchs.map((m) => (
                <div key={m.id} className="carte p-4">
                  <p className="text-sm"><strong>J{m.journee}</strong> · {m.domicile} – {m.exterieur} · {dateHeureFr(m.coupDEnvoi)} <Badge teinte={m.statut === "termine" ? (m.resultatVerifie ? "vert" : "ambre") : "gris"}>{m.statut}{m.statut === "termine" ? (m.resultatVerifie ? " · vérifié" : " · non vérifié") : ""}</Badge></p>
                  <div className="mt-3 grid gap-4 md:grid-cols-2">
                    <FormulaireAction action={saisirResultat} libelle="Enregistrer le résultat" variante="contour" className={petit}>
                      <input type="hidden" name="matchId" value={m.id} />
                      <div className="flex gap-2">
                        <input name="scoreDomicile" type="number" min={0} max={150} defaultValue={m.scoreDomicile ?? ""} required className={champ} aria-label={`Score ${m.domicile}`} />
                        <input name="scoreExterieur" type="number" min={0} max={150} defaultValue={m.scoreExterieur ?? ""} required className={champ} aria-label={`Score ${m.exterieur}`} />
                      </div>
                      <input name="motif" placeholder="Motif (obligatoire en cas de correction)" className={`${champ} mt-2`} aria-label="Motif" />
                    </FormulaireAction>
                    <FormulaireAction action={changerStatutMatch} libelle="Changer le statut" variante="contour" className={petit}>
                      <input type="hidden" name="matchId" value={m.id} />
                      <select name="statut" defaultValue="reporte" className={champ} aria-label="Statut">
                        <option value="a_venir">à venir</option><option value="reporte">reporté (nouvelle date)</option><option value="annule">annulé</option><option value="forfait">forfait</option>
                      </select>
                      <input name="coupDEnvoi" type="datetime-local" className={`${champ} mt-2`} aria-label="Nouvelle date et heure (Paris)" />
                      <input name="motif" placeholder="Motif (obligatoire)" required className={`${champ} mt-2`} aria-label="Motif" />
                    </FormulaireAction>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {onglet === "concours" && (
          <div>
            <h2 className="mb-2 text-3xl">Pronostics et classement</h2>
            <p className="mb-4 text-sm text-gris">{db.pronostics.length} pronostics · {db.participants.length} participants. Les pronostics clôturés ne sont pas modifiables, même par l&apos;administration ; seule la saisie des résultats (journalisée) fait évoluer le classement.</p>
            <div className="overflow-x-auto border border-gris-clair">
              <table className="w-full text-sm">
                <thead className="bg-clair-2 text-left text-xs uppercase tracking-wider text-gris"><tr><th className="px-3 py-2">Rang</th><th className="px-3 py-2">Participant</th><th className="px-3 py-2">Inscrit le</th><th className="px-3 py-2">Points</th><th className="px-3 py-2">Écart</th><th className="px-3 py-2">Évalués</th></tr></thead>
                <tbody>{classement.map((l) => <tr key={l.userId} className="border-t border-clair-2"><td className="px-3 py-2">{l.rang}</td><td className="px-3 py-2">{l.pseudo}</td><td className="px-3 py-2 text-gris">{dateHeureFr(l.inscritLe)}</td><td className="px-3 py-2 font-900">{l.points}</td><td className="px-3 py-2">{l.ecartCumule}</td><td className="px-3 py-2">{l.pronosticsEvalues}</td></tr>)}</tbody>
              </table>
            </div>
            <Encart titre="Mesures anti-comptes multiples (démonstration)" teinte="gris"><p>Unicité de l&apos;e-mail et du pseudo, confirmation d&apos;adresse, honeypot à l&apos;inscription, journal d&apos;audit. En production : limitation par adresse IP et appareil, revue manuelle avant remise des lots.</p></Encart>
          </div>
        )}

        {onglet === "avantages" && (
          <div>
            <h2 className="mb-2 text-3xl">Statuts, avantages, budgets, capacités</h2>
            <p className="mb-4 text-sm text-gris">Chaque avantage est éditable ; un avantage devient réservable par les actionnaires uniquement à l&apos;état « confirmé ». Toute modification est journalisée.</p>
            {db.statuts.map((s) => (
              <div key={s.id} className="mb-6">
                <p className="display bg-clair-2 px-4 py-2 text-lg font-900 tracking-wider">{s.nom} · dès {s.seuilActions} action(s)</p>
                <div className="grid gap-3 lg:grid-cols-2">
                  {s.avantages.map((a) => (
                    <FormulaireAction key={a.id} action={majAvantage} libelle="Enregistrer" variante="contour" className={`carte p-3 ${petit}`}>
                      <input type="hidden" name="statutId" value={s.id} /><input type="hidden" name="avantageId" value={a.id} />
                      <input name="titre" defaultValue={a.titre} required className={champ} aria-label="Titre" />
                      <div className="mt-2 grid grid-cols-2 gap-2 text-sm sm:grid-cols-5">
                        <select name="etat" defaultValue={a.etat} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="État"><option value="envisage">envisagé</option><option value="negociation">en négociation</option><option value="confirme">confirmé</option></select>
                        <input name="quantite" defaultValue={a.quantite} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Quantité" placeholder="Quantité" />
                        <input name="capacite" defaultValue={a.capacite} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Capacité" placeholder="Capacité" />
                        <input name="duree" defaultValue={a.duree} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Durée" placeholder="Durée" />
                        <input name="coutEstime" type="number" min={0} defaultValue={a.coutEstime ?? 0} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Coût unitaire estimé (€)" />
                      </div>
                      <p className="mt-1 text-xs text-gris">Réservations : {db.reservations.filter((r) => r.avantageId === a.id && r.etat !== "annulee").length}</p>
                    </FormulaireAction>
                  ))}
                </div>
              </div>
            ))}
            <h3 className="mb-3 mt-8 text-2xl">Réservations</h3>
            {db.reservations.length ? db.reservations.map((r) => (
              <FormulaireAction key={r.id} action={changerEtatReservation} libelle="OK" variante="contour" className="flex flex-wrap items-center gap-3 border-b border-gris-clair py-2 text-sm [&>button]:mt-0 [&>button]:px-3 [&>button]:py-1 [&>button]:text-sm [&>p]:hidden">
                <input type="hidden" name="id" value={r.id} />
                <span>{pseudo(r.userId)} · {r.avantageId} · {dateFr(r.creeLe)}</span>
                <select name="etat" defaultValue={r.etat} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="État">{["demandee", "confirmee", "utilisee", "annulee"].map((v) => <option key={v} value={v}>{v}</option>)}</select>
              </FormulaireAction>
            )) : <p className="text-sm text-gris">Aucune réservation.</p>}
          </div>
        )}

        {onglet === "lots" && (
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 className="mb-2 text-3xl">Lot principal</h2>
              <Encart titre="Rappel" teinte="ambre"><p>{lotPrincipal.mentionObligatoire} La fiche ci-dessous est publiée sur la page Lots mais le lot reste « envisagé » tant que les lots ne sont pas activés et que le contrat n&apos;est pas signé.</p></Encart>
              <FormulaireAction action={majLotPrincipal} libelle="Enregistrer la fiche" variante="contour" className="mt-4">
                {[["partenaireContractuel", "Partenaire contractuel"], ["modele", "Modèle"], ["version", "Version"], ["etat", "État (neuf / occasion)"], ["kilometrage", "Kilométrage"], ["valeurDocumentee", "Valeur documentée"], ["proprieteVehicule", "Propriété du véhicule"], ["immatriculationLivraisonFrais", "Immatriculation, livraison, frais"], ["conditionsRemise", "Conditions de remise"], ["dateDisponibilite", "Date de disponibilité"], ["documentsContractuels", "Documents contractuels"]].map(([k, l]) => (
                  <div key={k} className="mt-2"><label htmlFor={`lp-${k}`} className={etiquette}>{l}</label><input id={`lp-${k}`} name={k} defaultValue={fiche[k] ?? ""} className={champ} /></div>
                ))}
              </FormulaireAction>
            </div>
            <div>
              <h2 className="mb-2 text-3xl">Lots secondaires</h2>
              <div className="space-y-3">
                {db.lots.map((l) => (
                  <FormulaireAction key={l.id} action={majLot} libelle="Enregistrer" variante="contour" className={`carte p-3 ${petit}`}>
                    <input type="hidden" name="id" value={l.id} />
                    <p className="display text-base font-900 text-rouge">{l.rang} <Badge teinte={teinteEtat(l.statut)}>{l.statut}</Badge></p>
                    <input name="titre" defaultValue={l.titre} required className={`${champ} mt-1`} aria-label="Titre" />
                    <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                      <select name="statut" defaultValue={l.statut} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Statut contractuel"><option value="envisage">envisagé</option><option value="en_discussion">en discussion</option><option value="confirme">confirmé</option></select>
                      <input name="fournisseur" defaultValue={l.fournisseur} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Fournisseur" placeholder="Fournisseur" />
                      <input name="quantite" type="number" min={0} defaultValue={l.quantite} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Quantité" />
                      <input name="valeurEstimee" type="number" min={0} defaultValue={l.valeurEstimee ?? ""} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Valeur (€)" placeholder="Valeur (€)" />
                      <input name="conditionsRemise" defaultValue={l.conditionsRemise} className="col-span-2 border border-gris-clair bg-blanc px-2 py-1" aria-label="Conditions de remise" />
                    </div>
                  </FormulaireAction>
                ))}
              </div>
            </div>
          </div>
        )}

        {onglet === "partenaires" && (
          <div>
            <h2 className="mb-2 text-3xl">Partenaires et contrats</h2>
            <p className="mb-4 text-sm text-gris">Passer une entreprise en « partenaire de l&apos;opération » suppose un accord écrit. Aucun contrat n&apos;est enregistré à ce jour.</p>
            <FormulaireAction action={majPartenaire} libelle="Ajouter" variante="clair" className={`mb-6 carte p-4 ${petit}`}>
              <p className="display text-lg font-900">Ajouter un partenaire ou un prospect</p>
              <div className="mt-2 grid gap-2 text-sm sm:grid-cols-4">
                <input name="nom" placeholder="Nom" required className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Nom" />
                <select name="categorie" defaultValue="prospect" className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Catégorie"><option value="prospect">à démarcher</option><option value="partenaire_club">partenaire du club</option><option value="partenaire_operation">partenaire de l&apos;opération</option></select>
                <input name="site" placeholder="Site (https://…)" className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Site" />
                <input name="note" placeholder="Note (accord, lot…)" className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Note" />
              </div>
            </FormulaireAction>
            <div className="grid gap-2 lg:grid-cols-2">
              {db.partenaires.map((p) => (
                <FormulaireAction key={p.nom} action={majPartenaire} libelle="OK" variante="contour" className="flex flex-wrap items-center gap-2 carte p-2 text-sm [&>button]:mt-0 [&>button]:px-3 [&>button]:py-1 [&>button]:text-sm [&>p]:hidden">
                  <input type="hidden" name="nom" value={p.nom} />
                  <span className="min-w-40 font-600">{p.nom}</span>
                  <select name="categorie" defaultValue={p.categorie} className="border border-gris-clair bg-blanc px-2 py-1" aria-label="Catégorie"><option value="prospect">à démarcher</option><option value="partenaire_club">partenaire du club</option><option value="partenaire_operation">partenaire de l&apos;opération</option></select>
                  <input name="site" defaultValue={p.site ?? ""} className="w-40 border border-gris-clair bg-blanc px-2 py-1" aria-label="Site" />
                  <input name="note" defaultValue={p.note ?? ""} className="w-40 border border-gris-clair bg-blanc px-2 py-1" aria-label="Note" />
                  <label className="flex items-center gap-1 text-xs text-rouge"><input type="checkbox" name="supprimer" /> retirer</label>
                </FormulaireAction>
              ))}
            </div>
          </div>
        )}

        {onglet === "emails" && (
          <div>
            <h2 className="mb-2 text-3xl">E-mails sortants</h2>
            <p className="mb-4 text-sm text-gris">Sans RESEND_API_KEY, rien ne part : les messages sont consignés ici (liens de confirmation et de réinitialisation compris, pour la démonstration).</p>
            {db.emails.length ? db.emails.map((e) => (
              <details key={e.id} className="border-b border-gris-clair py-2 text-sm">
                <summary className="cursor-pointer">{dateHeureFr(e.date)} · {e.a} · <strong>{e.sujet}</strong> <Badge teinte={e.canal === "resend" ? "vert" : "ambre"}>{e.canal}</Badge></summary>
                <pre className="mt-2 whitespace-pre-wrap bg-blanc p-3 text-xs text-ardoise-2">{e.corps}</pre>
              </details>
            )) : <p className="text-sm text-gris">Aucun e-mail.</p>}
          </div>
        )}

        {onglet === "documents" && (
          <div>
            <h2 className="mb-2 text-3xl">Documents, support et consentements</h2>
            <ul className="divide-y divide-gris-clair border border-gris-clair text-sm">{documentsOperation.map((d) => <li key={d.titre} className="flex justify-between px-4 py-2"><span>{d.titre}</span><Badge teinte={teinteEtat(d.statut)}>{d.statut}</Badge></li>)}</ul>
            <h3 className="mb-3 mt-8 text-2xl">Consentements</h3>
            <div className="overflow-x-auto border border-gris-clair">
              <table className="w-full text-sm"><thead className="bg-clair-2 text-left text-xs uppercase tracking-wider text-gris"><tr><th className="px-3 py-2">Compte</th><th className="px-3 py-2">Rôle</th><th className="px-3 py-2">CGU</th><th className="px-3 py-2">Données</th><th className="px-3 py-2">Reconnaissance publique</th><th className="px-3 py-2">Adresse confirmée</th></tr></thead>
                <tbody>{db.users.map((u) => <tr key={u.id} className="border-t border-clair-2"><td className="px-3 py-2">{u.pseudo}</td><td className="px-3 py-2 text-gris">{u.role}</td><td className="px-3 py-2">{u.consentements.cgu ? "oui" : "non"}</td><td className="px-3 py-2">{u.consentements.donnees ? "oui" : "non"}</td><td className="px-3 py-2">{u.consentements.reconnaissancePublique ? "oui" : "non"}</td><td className="px-3 py-2">{u.emailVerifie ? "oui" : "non"}</td></tr>)}</tbody>
              </table>
            </div>
            <h3 className="mb-3 mt-8 text-2xl">Support</h3>
            <p className="text-sm text-gris">Aucun outil de support branché. En production : boîte partagée ou outil de ticketing du club, avec journalisation des réponses.</p>
          </div>
        )}

        {onglet === "audit" && (
          <div>
            <h2 className="mb-2 text-3xl">Journal d&apos;audit</h2>
            <p className="mb-4 text-sm text-gris">Toutes les actions sensibles, avec état précédent et motif. Non modifiable depuis l&apos;interface. <a href="/api/export/audit.csv" className="underline">Exporter en CSV</a>.</p>
            <div className="max-h-[36rem] overflow-y-auto border border-gris-clair">
              <table className="w-full text-xs">
                <thead className="sticky top-0 bg-clair-2 text-left uppercase tracking-wider text-gris"><tr><th className="px-3 py-2">Date</th><th className="px-3 py-2">Acteur</th><th className="px-3 py-2">Action</th><th className="px-3 py-2">Cible</th><th className="px-3 py-2">Détails</th></tr></thead>
                <tbody>{db.audit.map((e) => <tr key={e.id} className="border-t border-clair-2 align-top"><td className="whitespace-nowrap px-3 py-2 text-gris">{dateHeureFr(e.date)}</td><td className="px-3 py-2">{pseudo(e.acteur)}</td><td className="px-3 py-2">{e.action}</td><td className="px-3 py-2 text-gris">{e.cible ?? ""}</td><td className="px-3 py-2 font-mono text-gris">{e.details ? JSON.stringify(e.details) : ""}</td></tr>)}</tbody>
              </table>
            </div>
          </div>
        )}
      </Section>
    </>
  );
}
