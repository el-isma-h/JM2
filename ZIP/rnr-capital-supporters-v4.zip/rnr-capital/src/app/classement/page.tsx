import type { Metadata } from "next";
import { Section, Titre, Encart, Badge } from "@/components/ui";
import { lireDb } from "@/lib/store";
import { classer } from "@/lib/concours";
import { utilisateurCourant } from "@/lib/auth";
import { lotsSecondaires, lotPrincipal } from "@/data/lots";

export const metadata: Metadata = { title: "Classement du concours" };
export const dynamic = "force-dynamic";

export default async function Classement() {
  const [db, user] = await Promise.all([lireDb(), utilisateurCourant()]);
  const lignes = classer(db.participants, db.pronostics, db.matchs);
  const comptabilises = db.matchs.filter((m) => m.statut === "termine" && m.resultatVerifie).length;
  const maLigne = user ? lignes.find((l) => l.userId === user.id) : null;

  return (
    <>
      <Section className="pb-6">
        <Titre as="h1" sur="Concours gratuit">Classement saisonnier</Titre>
        <div className="grid gap-6 md:grid-cols-3">
          <Encart titre="Comment on classe" teinte="gris">
            <p>1. Nombre de scores exacts. 2. Plus faible écart cumulé aux scores réels. 3. Inscription la plus ancienne. {comptabilises} match{comptabilises > 1 ? "s" : ""} comptabilisé{comptabilises > 1 ? "s" : ""} (résultats vérifiés uniquement).</p>
          </Encart>
          <Encart titre="Lots" teinte="ambre">
            <p>1er : {lotPrincipal.accroche} {lotPrincipal.mentionObligatoire}</p>
            <p>{lotsSecondaires.map((l) => `${l.rang} : ${l.titre}`).join(" · ")} (envisagés).</p>
          </Encart>
          <Encart titre="Égalité des chances" teinte="rouge">
            <p>Les actionnaires n&apos;ont aucun avantage. Les participants fictifs sont étiquetés « démo ».</p>
          </Encart>
        </div>
        {maLigne && (
          <p className="mt-6 inline-block border border-or-sombre/50 bg-or/20 px-4 py-2 text-sm">
            Vous êtes <span className="display text-xl font-900 text-or-sombre">{maLigne.rang}e</span> avec {maLigne.points} score{maLigne.points > 1 ? "s" : ""} exact{maLigne.points > 1 ? "s" : ""} (écart cumulé {maLigne.ecartCumule}).
          </p>
        )}
      </Section>
      <Section className="border-t border-gris-clair bg-clair-2">
        <div className="overflow-x-auto border border-gris-clair">
          <table className="w-full text-sm">
            <thead className="bg-clair-2 text-left text-xs uppercase tracking-wider text-gris">
              <tr><th className="px-3 py-2">Rang</th><th className="px-3 py-2">Participant</th><th className="px-3 py-2">Scores exacts</th><th className="px-3 py-2">Écart cumulé</th><th className="px-3 py-2">Pronostics évalués</th></tr>
            </thead>
            <tbody>
              {lignes.map((l) => (
                <tr key={l.userId} className={`border-t border-clair-2 ${user?.id === l.userId ? "bg-or/10" : ""}`}>
                  <td className="display px-3 py-2.5 text-2xl font-900">{l.rang}</td>
                  <td className="px-3 py-2.5">{l.pseudo} {l.userId.startsWith("usr_fictif") || l.userId.startsWith("usr_demo") ? <Badge teinte="ambre">démo</Badge> : null}</td>
                  <td className="px-3 py-2.5 font-900">{l.points}</td>
                  <td className="px-3 py-2.5">{l.pronosticsEvalues ? l.ecartCumule : "—"}</td>
                  <td className="px-3 py-2.5 text-gris">{l.pronosticsEvalues}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>
    </>
  );
}
