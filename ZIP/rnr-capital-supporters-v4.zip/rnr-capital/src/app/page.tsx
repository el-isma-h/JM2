import Link from "next/link";
import { ArrowRight, Coins, Users, Trophy } from "lucide-react";
import { campagne, liensOfficiels } from "@/config/campagne";
import { lotPrincipal } from "@/data/lots";
import { actualites } from "@/data/contenus";
import { Section, Titre, Bouton, Badge, Encart, dateFr, teinteEtat } from "@/components/ui";
import { Compteur } from "@/components/Compteur";
import { Apparition } from "@/components/Apparition";
import { VisuelStade } from "@/components/VisuelStade";
import { CompteARebours } from "@/components/CompteARebours";
import { CourbeCollecte } from "@/components/CourbeCollecte";
import { VoitureLot } from "@/components/VoitureLot";
import { SectionResultats } from "@/components/SectionResultats";
import { FondPhoto } from "@/components/FondPhoto";
import { Logo } from "@/components/Logo";
import { statsCollecte, matchsDb } from "@/lib/stats";
import { euros } from "@/lib/souscription";
import { lireDb } from "@/lib/store";

export const dynamic = "force-dynamic";

const etapes = [
  { icone: <Coins aria-hidden />, titre: "1. Je souscris", texte: `À partir de ${campagne.prixAction} € l'action (hypothèse). L'argent renforce les fonds propres du club.`, href: "/investir", lien: "Simuler" },
  { icone: <Users aria-hidden />, titre: "2. Je deviens membre", texte: "Carte nominative, badge, et des avantages rugby selon mon statut : matchs, rencontres, coulisses.", href: "/statuts", lien: "Voir les statuts" },
  { icone: <Trophy aria-hidden />, titre: "3. Je joue gratuitement", texte: "Le concours de pronostics est ouvert à tous, avec ou sans action. Même règles, mêmes chances.", href: "/matchs", lien: "Pronostiquer" },
];

export default async function Accueil() {
  const [stats, { prochain, joues }, db] = await Promise.all([statsCollecte(), matchsDb(), lireDb()]);
  const statuts = db.statuts;
  const progression = stats.objectif ? Math.min(100, Math.round((stats.capitalConfirme / stats.objectif) * 100)) : 0;
  const progressionIntentions = stats.objectif ? Math.min(100, Math.round(((stats.capitalConfirme + stats.intentions + stats.paiementsRecus) / stats.objectif) * 100)) : 0;

  return (
    <>
      {/* HERO : plein écran sombre, titre centré Outfit italique, bandeau prochain match biseauté comme le site officiel */}
      <section className="relative overflow-hidden bg-noir text-blanc">
        <VisuelStade />
        <div className="relative mx-auto flex min-h-[72vh] max-w-6xl flex-col items-center justify-center px-4 py-24 text-center sm:px-6">
          <Apparition>
            <Logo taille={112} avecTexte={false} className="mb-4 drop-shadow-[0_8px_24px_rgba(0,0,0,0.6)]" />
            <div><Badge teinte="or">{campagne.bandeauNonOfficiel}</Badge></div>
            <h1 className="mt-5 text-[clamp(3rem,10vw,6.5rem)] [text-shadow:0_8px_30px_rgba(0,0,0,0.5)]">
              Tous Normands,<br />tous actionnaires<span className="text-rouge">.</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-blanc/80">{campagne.slogan} Souscrivez dès {euros(campagne.prixAction)} l&apos;action, rejoignez la communauté des Lions et jouez gratuitement chaque match.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Bouton href="/investir">Investir dans le club</Bouton>
              <Bouton variante="clair" href="/matchs">Jouer gratuitement</Bouton>
            </div>
          </Apparition>
        </div>
        {prochain && (
          <div className="relative border-t border-blanc/10 bg-noir-2/90">
            <div className="mx-auto grid max-w-7xl items-stretch gap-x-4 px-4 sm:px-6 lg:grid-cols-[auto_1fr_auto]">
              <div className="flex flex-wrap items-center gap-3 pt-4 lg:py-4">
                <span className="label bg-rouge px-2 py-0.5 text-[0.6rem]">Prochain match</span>
                <span className="text-xs text-blanc/70">{dateFr(prochain.coupDEnvoi, { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3 py-4">
                <CompteARebours cible={prochain.coupDEnvoi} />
                <p className="display text-center text-3xl sm:text-4xl">{prochain.domicile} <span className="text-rouge">vs</span> {prochain.exterieur}</p>
              </div>
              <div className="-mx-4 flex sm:-mx-6 lg:mx-0">
                <a href={liensOfficiels.billetterie} target="_blank" rel="noopener noreferrer" className="biseau-rouge flex flex-1 items-center justify-center px-6 py-4 text-xs font-900 uppercase tracking-[0.15em] hover:bg-rouge-sombre lg:flex-none lg:px-10 lg:py-0 lg:pl-14 lg:pr-16">Billetterie</a>
                <Link href="/matchs" className="flex flex-1 items-center justify-center bg-blanc px-6 py-4 text-xs font-900 uppercase tracking-[0.15em] text-ardoise hover:bg-clair-2 lg:flex-none lg:py-0">Pronostiquer</Link>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* LE PROJET EN 3 ÉTAPES : version simple */}
      <Section>
        <Titre sur="C'est simple" lien={{ href: "/projet", label: "Le projet en détail" }}>Le projet en trois étapes</Titre>
        <div className="grid gap-5 md:grid-cols-3">
          {etapes.map((e, i) => (
            <Apparition key={e.titre} delai={i * 0.08}>
              <div className="carte flex h-full flex-col p-7">
                <span className="grid h-12 w-12 place-items-center rounded-full bg-rouge text-blanc">{e.icone}</span>
                <h3 className="mt-5 text-2xl">{e.titre}</h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-gris">{e.texte}</p>
                <Link href={e.href} className="lien-section mt-5 inline-flex items-center gap-2 text-rouge hover:text-rouge-sombre">{e.lien} <ArrowRight size={14} aria-hidden /></Link>
              </div>
            </Apparition>
          ))}
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <Encart titre="Ce que vous achetez" teinte="gris"><p>Des actions du club (ou d&apos;un véhicule qui le détient), au prix de souscription envisagé de {euros(campagne.prixAction)}. Pas une promesse de gain.</p></Encart>
          <Encart titre="Ce que vous gagnez" teinte="gris"><p>Une place dans l&apos;histoire du club et des avantages pour une saison. Les avantages ne sont ni annuels à vie, ni un rendement.</p></Encart>
          <Encart titre="Ce que vous risquez" teinte="rouge"><p>Perdre tout ou partie de la mise, ne pas pouvoir revendre, être dilué. Lisez les <Link href="/documents" className="underline">documents et risques</Link>.</p></Encart>
        </div>
      </Section>

      {/* COLLECTE */}
      <Section ton="clair-2">
        <Titre sur="L'opération" lien={{ href: "/projet", label: "Utilisation des fonds" }}>La collecte, en toute transparence</Titre>
        <div className="grid gap-8 lg:grid-cols-[1.3fr_1fr]">
          <div className="carte p-6">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="label text-xs text-gris">Objectif <Badge teinte="ambre">hypothèse</Badge></p>
                <p className="display mt-1 text-5xl sm:text-6xl"><Compteur valeur={stats.objectif} suffixe=" €" /></p>
              </div>
              <div className="text-right">
                <p className="label text-xs text-gris">Capital définitivement souscrit</p>
                <p className="display mt-1 text-4xl text-vert">{euros(stats.capitalConfirme)}</p>
              </div>
            </div>
            <div className="relative mt-5 h-3 w-full overflow-hidden rounded-full bg-clair-2" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progression} aria-label="Progression du capital confirmé">
              <div className="absolute inset-y-0 left-0 bg-ambre-clair/40" style={{ width: `${progressionIntentions}%` }} aria-hidden />
              <div className="absolute inset-y-0 left-0 bg-rouge transition-[width] duration-700" style={{ width: `${progression}%` }} />
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
              <div><dt className="text-gris">Capital confirmé</dt><dd className="font-600 text-vert">{euros(stats.capitalConfirme)}</dd></div>
              <div><dt className="text-gris">Paiements reçus</dt><dd className="font-600">{euros(stats.paiementsRecus)}</dd></div>
              <div><dt className="text-gris">Intentions (démo)</dt><dd className="font-600 text-ambre">{euros(stats.intentions)}</dd></div>
              <div><dt className="text-gris">Souscripteurs confirmés</dt><dd className="font-600">{stats.souscripteursConfirmes}</dd></div>
            </dl>
            <div className="mt-6"><CourbeCollecte souscriptions={db.souscriptions} objectif={stats.objectif} hauteur={190} /></div>
          </div>
          <div className="space-y-4">
            <Encart titre="Chiffres de démonstration" teinte="ambre"><p>Données fictives étiquetées. Aucun fonds collecté. Objectif et dates : hypothèses du porteur du projet, non validées par le club.</p></Encart>
            <div className="carte p-6">
              <p className="label text-xs text-gris">Calendrier envisagé</p>
              <p className="display mt-2 text-3xl">{dateFr(stats.ouverture, { day: "numeric", month: "short" })} <span className="text-rouge">→</span> {dateFr(stats.cloture, { day: "numeric", month: "short", year: "numeric" })}</p>
              <p className="label mt-4 text-xs text-gris">Utilisation prévisionnelle <Badge teinte="ambre">à valider</Badge></p>
              <ul className="mt-2 space-y-1.5 text-sm">
                {campagne.utilisationFonds.map((u) => (
                  <li key={u.poste} className="flex items-center gap-3">
                    <span className="h-2 rounded-full bg-rouge" style={{ width: `${u.part * 140}px` }} aria-hidden />
                    <span className="text-ardoise-2">{u.poste}</span>
                    <span className="ml-auto font-600">{Math.round(u.part * 100)} %</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </Section>

      {/* RÉSULTATS + COURBE DE PERFORMANCES */}
      <SectionResultats joues={joues} />

      {/* STATUTS */}
      <Section ton="sombre">
        <FondPhoto src="/images/mascotte.jpg" position="center 20%" opacite={0.55} />
        <Titre sur="Communauté" lien={{ href: "/statuts", label: "Tous les avantages" }}>Les statuts d&apos;actionnaires supporters</Titre>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {statuts.map((s, i) => (
            <Apparition key={s.id} delai={i * 0.06}>
              <Link href={`/statuts#${s.id}`} className="carte-verre group block h-full overflow-hidden transition-transform duration-200 hover:-translate-y-1">
                <div className="px-5 pb-6 pt-5 text-blanc">
                  <p className="label text-[0.65rem] text-blanc/60">dès {s.seuilActions} action{s.seuilActions > 1 ? "s" : ""}</p>
                  <p className="display mt-1 text-2xl">{s.nom}</p>
                  <p className="display text-xl text-or">{euros(s.seuilActions * campagne.prixAction)}</p>
                </div>
                <div className="border-t border-blanc/10 p-5">
                  <p className="text-sm text-blanc/70">{s.accroche}</p>
                  <span className="lien-section mt-4 inline-flex items-center gap-1 text-rouge-vif">Voir <ArrowRight size={12} aria-hidden /></span>
                </div>
              </Link>
            </Apparition>
          ))}
        </div>
      </Section>

      {/* LOTS + ACTUS */}
      <Section ton="clair-2">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <Titre sur="Concours gratuit" lien={{ href: "/lots", label: "Tous les lots" }}>Les lots</Titre>
            <div className="carte overflow-hidden">
              <div className="relative h-60 bg-noir"><VoitureLot className="h-full w-full" /></div>
              <div className="p-6">
                <p className="display text-2xl">{lotPrincipal.accroche}</p>
                <p className="mt-3 inline-block bg-ambre-clair/15 px-3 py-1 text-xs font-600 text-ambre">{lotPrincipal.mentionObligatoire}</p>
                <ul className="mt-4 divide-y divide-clair-2 text-sm">
                  {db.lots.slice(0, 4).map((l) => (
                    <li key={l.id} className="flex items-center justify-between gap-3 py-2">
                      <span><span className="display mr-2 text-base text-rouge">{l.rang}</span>{l.titre}</span>
                      <Badge teinte={teinteEtat(l.statut)}>{l.statut === "envisage" ? "Envisagé" : l.statut === "confirme" ? "Confirmé" : "En discussion"}</Badge>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
          <div>
            <Titre sur="Suivi" lien={{ href: "/actualites", label: "Toutes les actualités" }}>Actualités du projet</Titre>
            <div className="space-y-4">
              {actualites.map((a) => (
                <Link key={a.slug} href={`/actualites/${a.slug}`} className="carte block p-6 hover:border-rouge/40">
                  <p className="label text-[0.65rem] text-gris">{dateFr(a.date)} {a.demo && <Badge teinte="ambre">démo</Badge>}</p>
                  <p className="display mt-2 text-2xl">{a.titre}</p>
                  <p className="mt-2 text-sm text-gris">{a.chapo}</p>
                  <span className="lien-section mt-4 inline-flex items-center gap-2 text-rouge">Lire la suite <ArrowRight size={12} aria-hidden /></span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
