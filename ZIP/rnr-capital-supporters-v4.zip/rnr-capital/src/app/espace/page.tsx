import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { utilisateurCourant } from "@/lib/auth";
import { lireDb } from "@/lib/store";
import { campagne } from "@/config/campagne";
import { etatLabel } from "@/data/statuts";
import { documentsOperation } from "@/data/contenus";
import { Section, Titre, Encart, Badge, Chiffre, dateFr, teinteEtat } from "@/components/ui";
import { CarteMembre } from "@/components/CarteMembre";
import { FormulaireAction } from "@/components/FormulaireAction";
import { reserverAvantage, renvoyerVerification } from "@/lib/actions";
import { euros, statutPour } from "@/lib/souscription";
import { classer } from "@/lib/concours";

export const metadata: Metadata = { title: "Espace actionnaire" };
export const dynamic = "force-dynamic";

const statutSubLabel = { intention: "Intention (démo)", en_attente_prestataire: "Paiement en attente", paiement_recu: "Paiement reçu (démo)", confirmee: "Titres confirmés", annulee: "Annulée" };

export default async function Espace() {
  const user = await utilisateurCourant();
  if (!user) redirect("/connexion?retour=/espace");
  if (user.role === "admin") redirect("/admin");
  const db = await lireDb();
  const statuts = db.statuts;
  const mesSubs = db.souscriptions.filter((s) => s.userId === user.id);
  const titresConfirmes = mesSubs.filter((s) => s.statut === "confirmee").reduce((n, s) => n + s.actions, 0);
  const capitalInvesti = mesSubs.filter((s) => s.statut === "confirmee" || s.statut === "paiement_recu").reduce((n, s) => n + s.montant, 0);
  const enAttente = mesSubs.filter((s) => s.statut === "intention" || s.statut === "en_attente_prestataire").reduce((n, s) => n + s.actions, 0);
  const statut = statutPour(titresConfirmes, statuts);
  const mesRes = db.reservations.filter((r) => r.userId === user.id);
  const classement = classer(db.participants, db.pronostics, db.matchs);
  const maLigne = classement.find((l) => l.userId === user.id);

  return (
    <>
      <Section className="pb-6">
        <Titre as="h1" sur={`Bonjour ${user.pseudo}`}>Mon espace</Titre>
        {!user.emailVerifie && (
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3 border border-ambre-clair/60 bg-ambre-clair/10 px-4 py-3 text-sm">
            <span>Votre adresse e-mail n&apos;est pas confirmée : le paiement de démonstration est bloqué. Le lien se trouve dans l&apos;e-mail d&apos;inscription (journal des e-mails de l&apos;administration en démonstration).</span>
            <form action={renvoyerVerification}><button className="display border border-ambre-clair px-3 py-1 text-sm font-900 uppercase tracking-wider text-ambre hover:bg-ambre hover:text-blanc">Renvoyer</button></form>
          </div>
        )}
        <div className="grid gap-8 lg:grid-cols-[1fr_1.4fr]">
          <div>
            <CarteMembre pseudo={user.pseudo} statut={statut?.nom ?? "Aucun statut (titres non confirmés)"} numero={user.id.slice(-4).toUpperCase()} demo />
            <p className="mt-3 text-xs text-gris">La carte et le badge ne sont activés qu&apos;après confirmation des titres par le prestataire habilité.</p>
          </div>
          <div className="grid grid-cols-2 gap-6">
            <Chiffre valeur={euros(capitalInvesti)} label="Capital investi" note="Paiements reçus et titres confirmés" />
            <Chiffre valeur={`${titresConfirmes}`} label="Titres effectivement détenus" note={enAttente ? `${enAttente} action(s) en attente` : undefined} />
            <Chiffre valeur={euros(campagne.prixAction)} label="Prix historique de souscription" note="Hypothèse de l'opération" />
            <Chiffre valeur="—" label="Dernière valorisation documentée" note="Aucune évaluation disponible" />
          </div>
        </div>
        <Encart titre="Aucun marché, aucun prix de cession garanti" teinte="rouge">
          <p>Vos titres, vos points de concours et vos avantages communautaires sont trois choses distinctes. Aucun résultat simulé n&apos;est jamais inscrit ici comme un solde disponible.</p>
        </Encart>
      </Section>

      <Section className="border-y border-gris-clair bg-clair-2">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <Titre sur="Souscriptions">Statut de souscription</Titre>
            {mesSubs.length ? (
              <ul className="divide-y divide-gris-clair border border-gris-clair">
                {mesSubs.map((s) => (
                  <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 text-sm">
                    <span>{s.actions} action{s.actions > 1 ? "s" : ""} · {euros(s.montant)} · {dateFr(s.creeLe)}</span>
                    <span className="flex items-center gap-2"><Badge teinte={s.statut === "confirmee" ? "vert" : s.statut === "annulee" ? "rouge" : "ambre"}>{statutSubLabel[s.statut]}</Badge>{s.referencePrestataire && <span className="text-xs text-gris">réf. {s.referencePrestataire}</span>}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gris">Aucune souscription. <Link href="/investir" className="underline">Simuler une souscription</Link>.</p>
            )}
            <h3 className="mb-3 mt-8 text-2xl">Documents contractuels</h3>
            <ul className="divide-y divide-gris-clair border border-gris-clair text-sm">
              {documentsOperation.slice(0, 4).map((d) => (
                <li key={d.titre} className="flex items-center justify-between px-4 py-2.5"><span>{d.titre}</span><Badge teinte={teinteEtat(d.statut)}>{d.statut === "disponible" ? "Disponible" : "Non disponible"}</Badge></li>
              ))}
            </ul>
            <h3 className="mb-3 mt-8 text-2xl">Actualités financières validées</h3>
            <p className="text-sm text-gris">Aucune actualité financière validée par le club n&apos;a encore été publiée.</p>
          </div>
          <div>
            <Titre sur="Avantages">Disponibles et réservations</Titre>
            {statut ? (
              <div className="space-y-4">
                {statuts.filter((s) => s.seuilActions <= titresConfirmes).map((s) => (
                  <div key={s.id} className="border border-gris-clair">
                    <p className="display bg-clair-2 px-4 py-2 text-base font-900 tracking-wider">{s.nom}</p>
                    <ul className="divide-y divide-clair-2">
                      {s.avantages.map((a) => {
                        const res = mesRes.find((r) => r.avantageId === a.id && r.etat !== "annulee");
                        return (
                          <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 text-sm">
                            <span>{a.titre} <Badge teinte={teinteEtat(a.etat)}>{etatLabel[a.etat]}</Badge></span>
                            {res ? <Badge teinte="vert">Réservation {res.etat}</Badge> : a.etat === "confirme" ? (
                              <FormulaireAction action={reserverAvantage} libelle="Réserver" variante="contour" className="[&>button]:mt-0 [&>button]:px-3 [&>button]:py-1 [&>button]:text-sm">
                                <input type="hidden" name="statutId" value={s.id} /><input type="hidden" name="avantageId" value={a.id} />
                              </FormulaireAction>
                            ) : <span className="text-xs text-gris">Réservable une fois confirmé par le club</span>}
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gris">Aucun avantage disponible : les avantages s&apos;activent après confirmation des titres.</p>
            )}
            <h3 className="mb-3 mt-8 text-2xl">Historique des avantages</h3>
            {mesRes.length ? <ul className="text-sm">{mesRes.map((r) => <li key={r.id}>{r.avantageId} · {dateFr(r.creeLe)} · {r.etat}</li>)}</ul> : <p className="text-sm text-gris">Aucun avantage utilisé.</p>}
          </div>
        </div>
      </Section>

      <Section>
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <Titre sur="Séparé de vos titres">Concours gratuit</Titre>
            {maLigne ? <p>Vous êtes <span className="display text-3xl font-900 text-or-sombre">{maLigne.rang}e</span> avec {maLigne.points} score(s) exact(s).</p> : <p className="text-gris">Vous ne participez pas encore.</p>}
            <Link href="/matchs" className="display mt-3 inline-block bg-rouge px-5 py-2.5 text-lg font-900 hover:bg-rouge-sombre">Pronostiquer</Link>
          </div>
          <div>
            <Titre sur="Compte">Profil, sécurité et données</Titre>
            <p className="text-sm text-ardoise-2">{user.email} · compte créé le {dateFr(user.creeLe)} · rôle : {user.role} · {user.emailVerifie ? <Badge teinte="vert">adresse confirmée</Badge> : <Badge teinte="ambre">adresse non confirmée</Badge>}</p>
            <p className="mt-1 text-xs text-gris">Session de 12 h, cookie signé. Authentification renforcée réservée aux administrateurs.</p>
            <Link href="/compte/profil" className="display mt-4 inline-block border-2 border-ardoise px-5 py-2.5 text-lg font-900 hover:bg-ardoise hover:text-blanc">Modifier mon profil, mon mot de passe, mes données</Link>
          </div>
        </div>
      </Section>
    </>
  );
}
