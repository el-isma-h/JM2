import type { Metadata } from "next";
import Link from "next/link";
import { actualites } from "@/data/contenus";
import { Section, Titre, Badge, dateFr } from "@/components/ui";

export const metadata: Metadata = { title: "Actualités du projet" };

export default function Actualites() {
  return (
    <Section>
      <Titre as="h1" sur="Suivi">Actualités du projet</Titre>
      <div className="grid gap-4 md:grid-cols-2">
        {actualites.map((a) => (
          <Link key={a.slug} href={`/actualites/${a.slug}`} className="block carte p-6 hover:border-rouge/60">
            <p className="text-xs uppercase tracking-wider text-gris">{dateFr(a.date)} {a.demo && <Badge teinte="ambre">démo</Badge>}</p>
            <h2 className="mt-2 text-3xl">{a.titre}</h2>
            <p className="mt-2 text-ardoise-2">{a.chapo}</p>
          </Link>
        ))}
      </div>
      <p className="mt-6 text-sm text-gris">Les actualités financières publiées dans l&apos;espace actionnaire sont validées par le club avant diffusion.</p>
    </Section>
  );
}
