import { notFound } from "next/navigation";
import { actualites } from "@/data/contenus";
import { Section, Titre, Badge, Bouton, dateFr } from "@/components/ui";

export function generateStaticParams() {
  return actualites.map((a) => ({ slug: a.slug }));
}

export default async function Actualite({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const a = actualites.find((x) => x.slug === slug);
  if (!a) notFound();
  return (
    <Section>
      <p className="text-xs uppercase tracking-wider text-gris">{dateFr(a.date)} {a.demo && <Badge teinte="ambre">contenu de démonstration</Badge>}</p>
      <Titre as="h1">{a.titre}</Titre>
      <p className="max-w-2xl text-lg text-ardoise-2">{a.chapo}</p>
      <div className="mt-6 max-w-2xl space-y-4 text-ardoise-2">{a.corps.map((p, i) => <p key={i}>{p}</p>)}</div>
      <Bouton variante="contour" href="/actualites" className="mt-8">Toutes les actualités</Bouton>
    </Section>
  );
}
