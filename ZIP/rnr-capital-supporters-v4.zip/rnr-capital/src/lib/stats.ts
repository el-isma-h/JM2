import { lireDb } from "@/lib/store";
import { matchComptabilise } from "@/lib/concours";

/** Chiffres de la collecte, séparés par statut : jamais présentés comme des fonds réellement collectés. */
export async function statsCollecte() {
  const db = await lireDb();
  const parStatut = { intention: 0, en_attente_prestataire: 0, paiement_recu: 0, confirmee: 0, annulee: 0 };
  const souscripteursConfirmes = new Set<string>();
  for (const s of db.souscriptions) {
    parStatut[s.statut] += s.montant;
    if (s.statut === "confirmee") souscripteursConfirmes.add(s.userId);
  }
  return {
    objectif: db.parametres.objectif,
    ouverture: db.parametres.ouverture,
    cloture: db.parametres.cloture,
    intentions: parStatut.intention + parStatut.en_attente_prestataire,
    paiementsRecus: parStatut.paiement_recu,
    capitalConfirme: parStatut.confirmee,
    souscripteursConfirmes: souscripteursConfirmes.size,
    participantsConcours: db.participants.length,
    concoursActif: db.parametres.concoursActif,
    lotsActifs: db.parametres.lotsActifs,
    omActif: db.parametres.omActif,
  };
}

export async function matchsDb() {
  const db = await lireDb();
  const tri = [...db.matchs].sort((a, b) => Date.parse(a.coupDEnvoi) - Date.parse(b.coupDEnvoi));
  const maintenant = Date.now();
  const prochain = tri.find((m) => m.statut === "a_venir" && Date.parse(m.coupDEnvoi) > maintenant - 2 * 3_600_000) ?? null;
  const joues = tri.filter((m) => m.statut === "termine");
  return { tous: tri, prochain, joues, comptabilises: tri.filter(matchComptabilise) };
}
