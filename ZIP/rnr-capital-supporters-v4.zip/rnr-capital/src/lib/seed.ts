/**
 * Données fictives de démonstration. Tous les comptes, souscriptions et pronostics ci-dessous sont inventés
 * et clairement étiquetés. Les scores des matchs passés viennent du site du club ; ils sont marqués « vérifiés »
 * pour illustrer le classement. Les statuts, lots et partenaires sont copiés depuis src/data/ puis deviennent
 * administrables en base.
 */
import { matchs as matchsInitiaux } from "@/data/matchs";
import { statuts as statutsInitiaux } from "@/data/statuts";
import { lotsSecondaires, partenaires as partenairesInitiaux } from "@/data/lots";
import { avantageOM } from "@/data/contenus";
import type { Db, User, Souscription } from "@/lib/store";
import type { Pronostic, Participant } from "@/lib/concours";
import { hacher } from "@/lib/password";
import { campagne } from "@/config/campagne";

export const COMPTES_DEMO = [
  { email: "supporter@demo.rnr", motDePasse: "demo1234", role: "supporter", pseudo: "Léo-le-Lion" },
  { email: "actionnaire@demo.rnr", motDePasse: "demo1234", role: "actionnaire", pseudo: "Camille76" },
  { email: "admin@demo.rnr", motDePasse: "demo1234", role: "admin", pseudo: "Administration", codeAdmin: "246810" },
] as const;

export function seed(): Db {
  const t0 = "2026-10-01T09:00:00.000Z";
  const base = { consentements: { cgu: true, donnees: true, reconnaissancePublique: false }, emailVerifie: true, suspendu: false };
  const users: User[] = COMPTES_DEMO.map((c, i) => ({
    id: `usr_demo${i + 1}`,
    email: c.email,
    pseudo: c.pseudo,
    motDePasse: hacher(c.motDePasse),
    role: c.role,
    creeLe: t0,
    ...base,
    ...("codeAdmin" in c ? { codeAdmin: hacher(c.codeAdmin) } : {}),
  }));

  const fictifs = ["Margaux_RNR", "Tom-Diochon", "Inès.76", "Bastien", "Lina", "Hugo_Lions", "Nora", "Yanis"];
  fictifs.forEach((pseudo, i) => {
    users.push({
      id: `usr_fictif${i + 1}`,
      email: `fictif${i + 1}@demo.rnr`,
      pseudo,
      motDePasse: hacher("demo1234"),
      role: "supporter",
      creeLe: new Date(Date.parse(t0) + i * 3_600_000).toISOString(),
      ...base,
    });
  });

  const participants: Participant[] = users.filter((u) => u.role !== "admin").map((u) => ({ id: u.id, pseudo: u.pseudo, inscritLe: u.creeLe }));

  const termines = matchsInitiaux.filter((m) => m.statut === "termine");
  const pronostics: Pronostic[] = [];
  let k = 0;
  for (const p of participants) {
    for (const m of termines) {
      k += 1;
      const sd = (m.scoreDomicile ?? 0) + ((k * 7) % 5) - 2;
      const se = (m.scoreExterieur ?? 0) + ((k * 3) % 4) - 1;
      const exact = k % 9 === 0;
      pronostics.push({
        id: `prn_${p.id}_${m.id}`,
        userId: p.id,
        matchId: m.id,
        scoreDomicile: exact ? (m.scoreDomicile as number) : Math.max(0, sd),
        scoreExterieur: exact ? (m.scoreExterieur as number) : Math.max(0, se),
        modifieLe: new Date(Date.parse(m.coupDEnvoi) - 3_600_000).toISOString(),
      });
    }
  }

  const matchsDemo = matchsInitiaux.map((m) => (m.statut === "termine" ? { ...m, resultatVerifie: true } : m));

  // Souscriptions fictives étalées dans le temps pour alimenter la courbe de collecte (démo).
  const souscriptions: Souscription[] = [
    { id: "sub_demo1", userId: "usr_demo2", actions: 10, montant: 1000, frais: 0, statut: "intention", creeLe: t0, demo: true },
    { id: "sub_fictif1", userId: "usr_fictif1", actions: 5, montant: 500, frais: 0, statut: "confirmee", referencePrestataire: "DEMO-0001", creeLe: "2026-10-03T10:00:00.000Z", demo: true },
    { id: "sub_fictif2", userId: "usr_fictif2", actions: 25, montant: 2500, frais: 0, statut: "confirmee", referencePrestataire: "DEMO-0002", creeLe: "2026-10-06T15:30:00.000Z", demo: true },
    { id: "sub_fictif3", userId: "usr_fictif3", actions: 1, montant: 100, frais: 0, statut: "paiement_recu", creeLe: "2026-10-09T18:00:00.000Z", demo: true },
    { id: "sub_fictif4", userId: "usr_fictif4", actions: 50, montant: 5000, frais: 0, statut: "confirmee", referencePrestataire: "DEMO-0003", creeLe: "2026-10-12T09:15:00.000Z", demo: true },
    { id: "sub_fictif5", userId: "usr_fictif5", actions: 10, montant: 1000, frais: 0, statut: "en_attente_prestataire", creeLe: "2026-10-14T11:00:00.000Z", demo: true },
  ];
  for (const s of souscriptions) {
    if (s.statut === "confirmee") {
      const u = users.find((x) => x.id === s.userId);
      if (u && u.role === "supporter") u.role = "actionnaire";
    }
  }

  return {
    version: 2,
    modeDemo: true,
    users,
    participants,
    pronostics,
    souscriptions,
    reservations: [],
    matchs: matchsDemo,
    statuts: structuredClone(statutsInitiaux),
    lots: structuredClone(lotsSecondaires),
    partenaires: structuredClone(partenairesInitiaux),
    jetons: [],
    emails: [],
    audit: [{ id: "aud_seed", date: t0, acteur: "système", action: "initialisation des données de démonstration" }],
    parametres: {
      objectif: campagne.objectif.montant,
      ouverture: campagne.dates.ouverture,
      cloture: campagne.dates.cloture,
      concoursActif: true,
      lotsActifs: false,
      omActif: avantageOM.actif,
      stripeDemoActif: true,
      lotPrincipal: {},
    },
  };
}
