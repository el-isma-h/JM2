/**
 * Moteur du concours gratuit de pronostics — fonctions pures, testées unitairement.
 * Un score exact = 1 point. Classement : points, puis plus faible écart cumulé, puis inscription la plus ancienne.
 * Aucun achat, aucune mise, aucun avantage lié à l'actionnariat.
 */
import type { Match } from "@/data/matchs";

export interface Pronostic {
  id: string;
  userId: string;
  matchId: string;
  scoreDomicile: number;
  scoreExterieur: number;
  /** ISO de la dernière modification (serveur). */
  modifieLe: string;
}

export interface Participant {
  id: string;
  pseudo: string;
  /** ISO de l'inscription au concours (critère subsidiaire). */
  inscritLe: string;
}

export interface LigneClassement {
  rang: number;
  userId: string;
  pseudo: string;
  points: number;
  ecartCumule: number;
  pronosticsEvalues: number;
  inscritLe: string;
}

/** Date limite de saisie : coupDEnvoi − N minutes. */
export function dateCloture(match: Pick<Match, "coupDEnvoi">, minutesAvant: number): Date {
  return new Date(new Date(match.coupDEnvoi).getTime() - minutesAvant * 60_000);
}

/** Vrai si la saisie est encore ouverte à l'instant `maintenant` (contrôle serveur). */
export function saisieOuverte(match: Match, minutesAvant: number, maintenant: Date = new Date()): boolean {
  if (match.statut === "termine" || match.statut === "annule" || match.statut === "forfait") return false;
  return maintenant.getTime() < dateCloture(match, minutesAvant).getTime();
}

/** Un match compte au classement uniquement s'il est terminé avec un résultat vérifié. */
export function matchComptabilise(match: Match): boolean {
  return (
    match.statut === "termine" &&
    match.resultatVerifie === true &&
    typeof match.scoreDomicile === "number" &&
    typeof match.scoreExterieur === "number"
  );
}

export function evaluer(prono: Pronostic, match: Match): { exact: boolean; ecart: number } {
  if (!matchComptabilise(match)) return { exact: false, ecart: 0 };
  const sd = match.scoreDomicile as number;
  const se = match.scoreExterieur as number;
  const ecart = Math.abs(prono.scoreDomicile - sd) + Math.abs(prono.scoreExterieur - se);
  return { exact: ecart === 0, ecart };
}

export function classer(participants: Participant[], pronostics: Pronostic[], matchs: Match[]): LigneClassement[] {
  const parMatch = new Map(matchs.map((m) => [m.id, m]));
  const lignes: LigneClassement[] = participants.map((p) => {
    let points = 0;
    let ecartCumule = 0;
    let evalues = 0;
    for (const pr of pronostics) {
      if (pr.userId !== p.id) continue;
      const m = parMatch.get(pr.matchId);
      if (!m || !matchComptabilise(m)) continue;
      const r = evaluer(pr, m);
      evalues += 1;
      ecartCumule += r.ecart;
      if (r.exact) points += 1;
    }
    return { rang: 0, userId: p.id, pseudo: p.pseudo, points, ecartCumule, pronosticsEvalues: evalues, inscritLe: p.inscritLe };
  });

  lignes.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    // Un participant sans aucun pronostic évalué n'est pas avantagé par un écart nul.
    const ea = a.pronosticsEvalues === 0 ? Number.POSITIVE_INFINITY : a.ecartCumule;
    const eb = b.pronosticsEvalues === 0 ? Number.POSITIVE_INFINITY : b.ecartCumule;
    if (ea !== eb) return ea - eb;
    return a.inscritLe.localeCompare(b.inscritLe);
  });

  // Rang dense : égalité parfaite = même rang (ne devrait pas arriver, l'inscription départage).
  let rang = 0;
  let prev: LigneClassement | null = null;
  lignes.forEach((l, i) => {
    const egal = prev && prev.points === l.points && prev.ecartCumule === l.ecartCumule && prev.inscritLe === l.inscritLe;
    rang = egal ? rang : i + 1;
    l.rang = rang;
    prev = l;
  });
  return lignes;
}

export function validerScore(n: unknown): n is number {
  return typeof n === "number" && Number.isInteger(n) && n >= 0 && n <= 150;
}
