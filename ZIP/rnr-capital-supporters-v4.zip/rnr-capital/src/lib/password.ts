import { scryptSync, randomBytes, timingSafeEqual, createHmac } from "node:crypto";

export function hacher(motDePasse: string): string {
  const sel = randomBytes(16).toString("hex");
  const hash = scryptSync(motDePasse, sel, 64).toString("hex");
  return `${sel}:${hash}`;
}

export function verifier(motDePasse: string, stocke: string): boolean {
  const [sel, hash] = stocke.split(":");
  if (!sel || !hash) return false;
  const calc = scryptSync(motDePasse, sel, 64);
  const ref = Buffer.from(hash, "hex");
  return calc.length === ref.length && timingSafeEqual(calc, ref);
}

const SECRET = process.env.SESSION_SECRET ?? "secret-de-demonstration";

export function signer(valeur: string): string {
  const sig = createHmac("sha256", SECRET).update(valeur).digest("base64url");
  return `${valeur}.${sig}`;
}

export function verifierSignature(signe: string): string | null {
  const i = signe.lastIndexOf(".");
  if (i < 0) return null;
  const valeur = signe.slice(0, i);
  const attendu = signer(valeur);
  const a = Buffer.from(signe);
  const b = Buffer.from(attendu);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  return valeur;
}
