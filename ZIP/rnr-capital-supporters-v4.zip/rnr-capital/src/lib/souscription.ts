/** Calculs de souscription — fonctions pures, testées. La grille de statuts peut venir de la base (administrable). */
import { campagne } from "@/config/campagne";
import { statuts as statutsParDefaut, type Statut, type Avantage } from "@/data/statuts";

export interface Simulation {
  actions: number;
  montantActions: number;
  frais: number;
  total: number;
  statut: Statut | null;
  avantages: { statut: Statut; avantages: Avantage[] }[];
  /** Pourcentage de détention : null tant que le capital et la dilution ne sont pas connus. */
  pourcentageDetention: number | null;
  prochainStatut: { statut: Statut; actionsManquantes: number } | null;
}

export function statutPour(actions: number, grille: Statut[] = statutsParDefaut): Statut | null {
  let trouve: Statut | null = null;
  for (const s of grille) if (actions >= s.seuilActions) trouve = s;
  return trouve;
}

export function prochainStatut(actions: number, grille: Statut[] = statutsParDefaut): { statut: Statut; actionsManquantes: number } | null {
  const suivant = grille.find((s) => s.seuilActions > actions);
  return suivant ? { statut: suivant, actionsManquantes: suivant.seuilActions - actions } : null;
}

export function simuler(actionsDemandees: number, grille: Statut[] = statutsParDefaut): Simulation {
  const actions = Math.min(Math.max(Math.floor(actionsDemandees), campagne.minimumActions), campagne.maximumActionsParPersonne);
  const montantActions = actions * campagne.prixAction;
  const frais = Math.round((campagne.frais.fixe + montantActions * campagne.frais.pourcentage) * 100) / 100;
  return {
    actions,
    montantActions,
    frais,
    total: montantActions + frais,
    statut: statutPour(actions, grille),
    avantages: grille.filter((s) => actions >= s.seuilActions).map((s) => ({ statut: s, avantages: s.avantages })),
    // Le capital social et la dilution ne sont pas communiqués : aucun pourcentage n'est affiché.
    pourcentageDetention: null,
    prochainStatut: prochainStatut(actions, grille),
  };
}

/** Budget de transparence calculé sur une collecte brute donnée. */
export function budget(collecteBrute: number, coutAvantages: number = campagne.budget.coutAvantagesEstime, coutLots: number = campagne.budget.coutLotsEstime) {
  const fraisOperation = Math.round(collecteBrute * campagne.budget.fraisOperationPct);
  const net = collecteBrute - fraisOperation - coutAvantages - coutLots;
  return { collecteBrute, fraisOperation, coutAvantages, coutLots, net };
}

export const euros = (n: number) =>
  new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", maximumFractionDigits: n % 1 === 0 ? 0 : 2 }).format(n);
