/**
 * Stockage : SQLite (better-sqlite3), fichier data/lions-capital.sqlite, créé au premier démarrage.
 * Modèle : une table par collection, chaque ligne = un document JSON (id, doc). Les lectures passent par un
 * cache en mémoire ; chaque mutation est appliquée dans une transaction SQLite. Pour la production, un
 * schéma relationnel (Prisma / Drizzle sur Postgres) reprendra ces mêmes collections.
 */
import Database from "better-sqlite3";
import path from "node:path";
import fs from "node:fs";
import type { Match } from "@/data/matchs";
import type { Pronostic, Participant } from "@/lib/concours";
import type { Statut } from "@/data/statuts";
import type { Lot, Partenaire } from "@/data/lots";

export type Role = "supporter" | "actionnaire" | "admin";

export interface User {
  id: string;
  email: string;
  pseudo: string;
  /** Hash scrypt (sel:hash). */
  motDePasse: string;
  role: Role;
  creeLe: string;
  consentements: { cgu: boolean; donnees: boolean; reconnaissancePublique: boolean };
  /** Deuxième facteur de démonstration pour les administrateurs : code stocké haché. */
  codeAdmin?: string;
  emailVerifie: boolean;
  suspendu: boolean;
  prenom?: string;
  nom?: string;
  telephone?: string;
}

export type StatutSouscription = "intention" | "en_attente_prestataire" | "paiement_recu" | "confirmee" | "annulee";

export interface Souscription {
  id: string;
  userId: string;
  actions: number;
  montant: number;
  frais: number;
  statut: StatutSouscription;
  creeLe: string;
  /** Référence chez le prestataire habilité (vide en démonstration). */
  referencePrestataire?: string;
  /** Session Stripe Checkout (mode test) le cas échéant. */
  stripeSessionId?: string;
  stripePaymentIntent?: string;
  demo: true;
}

export interface Reservation {
  id: string;
  userId: string;
  avantageId: string;
  statutId: string;
  creeLe: string;
  etat: "demandee" | "confirmee" | "utilisee" | "annulee";
}

export interface EntreeAudit {
  id: string;
  date: string;
  acteur: string;
  action: string;
  cible?: string;
  details?: Record<string, unknown>;
}

export interface Jeton {
  id: string;
  userId: string;
  type: "verification_email" | "reinitialisation";
  valeur: string;
  expireLe: string;
  utilise: boolean;
}

export interface EmailSortant {
  id: string;
  date: string;
  a: string;
  sujet: string;
  corps: string;
  /** "journal" tant qu'aucun fournisseur n'est configuré. */
  canal: "journal" | "resend";
}

export interface Parametres {
  objectif: number;
  ouverture: string;
  cloture: string;
  concoursActif: boolean;
  lotsActifs: boolean;
  omActif: boolean;
  /** Paiement Stripe en mode test (démonstration) autorisé pour les souscriptions. */
  stripeDemoActif: boolean;
  /** Fiche du lot principal (véhicule), administrable. Champs vides tant que rien n'est signé. */
  lotPrincipal: Record<string, string>;
}

export interface Db {
  version: 2;
  modeDemo: true;
  users: User[];
  participants: Participant[];
  pronostics: Pronostic[];
  souscriptions: Souscription[];
  reservations: Reservation[];
  matchs: Match[];
  statuts: Statut[];
  lots: Lot[];
  partenaires: Partenaire[];
  jetons: Jeton[];
  emails: EmailSortant[];
  audit: EntreeAudit[];
  parametres: Parametres;
}

const COLLECTIONS = ["users", "participants", "pronostics", "souscriptions", "reservations", "matchs", "statuts", "lots", "partenaires", "jetons", "emails", "audit"] as const;
type Collection = (typeof COLLECTIONS)[number];

const FICHIER = path.join(process.cwd(), "data", "lions-capital.sqlite");

declare global {
  // eslint-disable-next-line no-var
  var __lionsDb: { sql: Database.Database; cache: Db | null; verrou: Promise<unknown> } | undefined;
}

function connexion() {
  if (!globalThis.__lionsDb) {
    fs.mkdirSync(path.dirname(FICHIER), { recursive: true });
    const sql = new Database(FICHIER);
    sql.pragma("journal_mode = WAL");
    for (const c of COLLECTIONS) sql.exec(`CREATE TABLE IF NOT EXISTS ${c} (id TEXT PRIMARY KEY, doc TEXT NOT NULL)`);
    sql.exec(`CREATE TABLE IF NOT EXISTS parametres (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL)`);
    globalThis.__lionsDb = { sql, cache: null, verrou: Promise.resolve() };
  }
  return globalThis.__lionsDb;
}

function charger(sql: Database.Database): Db | null {
  const p = sql.prepare("SELECT valeur FROM parametres WHERE cle = 'parametres'").get() as { valeur: string } | undefined;
  if (!p) return null;
  const db = { version: 2, modeDemo: true, parametres: JSON.parse(p.valeur) } as Db;
  for (const c of COLLECTIONS) {
    const lignes = sql.prepare(`SELECT doc FROM ${c}`).all() as { doc: string }[];
    (db as unknown as Record<Collection, unknown[]>)[c] = lignes.map((l) => JSON.parse(l.doc));
  }
  return db;
}

function persister(sql: Database.Database, db: Db) {
  const tx = sql.transaction(() => {
    for (const c of COLLECTIONS) {
      sql.prepare(`DELETE FROM ${c}`).run();
      const ins = sql.prepare(`INSERT INTO ${c} (id, doc) VALUES (?, ?)`);
      for (const d of (db as unknown as Record<Collection, { id: string }[]>)[c]) ins.run(d.id, JSON.stringify(d));
    }
    sql.prepare("INSERT OR REPLACE INTO parametres (cle, valeur) VALUES ('parametres', ?)").run(JSON.stringify(db.parametres));
  });
  tx();
}

async function initiale(): Promise<Db> {
  const { seed } = await import("@/lib/seed");
  return seed();
}

export async function lireDb(): Promise<Db> {
  const c = connexion();
  if (c.cache) return c.cache;
  c.cache = charger(c.sql);
  if (!c.cache) {
    c.cache = await initiale();
    persister(c.sql, c.cache);
  }
  return c.cache;
}

/** Applique une mutation de façon sérialisée puis persiste dans une transaction. */
export async function modifierDb<T>(mutation: (db: Db) => T | Promise<T>): Promise<T> {
  const c = connexion();
  const tache = c.verrou.then(async () => {
    const db = await lireDb();
    const res = await mutation(db);
    persister(c.sql, db);
    return res;
  });
  c.verrou = tache.catch(() => undefined);
  return tache;
}

export async function journaliser(entree: Omit<EntreeAudit, "id" | "date">) {
  return modifierDb((db) => {
    db.audit.unshift({ id: idUnique("aud"), date: new Date().toISOString(), ...entree });
    if (db.audit.length > 5000) db.audit.length = 5000;
  });
}

export function idUnique(prefixe: string) {
  return `${prefixe}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

/** Réinitialise la base de démonstration (admin uniquement). */
export async function reinitialiser() {
  const c = connexion();
  c.cache = await initiale();
  persister(c.sql, c.cache);
}
