/**
 * E-mails transactionnels. Sans RESEND_API_KEY, les messages sont consignés dans la base (onglet « E-mails »
 * de l'administration) : rien ne part réellement. Avec la clé, envoi via l'API Resend.
 */
import { modifierDb, idUnique, type EmailSortant } from "@/lib/store";

export async function envoyerEmail(a: string, sujet: string, corps: string): Promise<EmailSortant> {
  const cle = process.env.RESEND_API_KEY;
  const de = process.env.MAIL_FROM;
  let canal: EmailSortant["canal"] = "journal";
  if (cle && de) {
    try {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${cle}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from: de, to: a, subject: sujet, text: corps }),
      });
      if (r.ok) canal = "resend";
    } catch {
      canal = "journal";
    }
  }
  const email: EmailSortant = { id: idUnique("mail"), date: new Date().toISOString(), a, sujet, corps, canal };
  await modifierDb((db) => {
    db.emails.unshift(email);
    if (db.emails.length > 500) db.emails.length = 500;
  });
  return email;
}

import { headers } from "next/headers";

/** URL publique : NEXT_PUBLIC_BASE_URL si définie, sinon déduite de la requête courante. */
export async function urlBase() {
  if (process.env.NEXT_PUBLIC_BASE_URL) return process.env.NEXT_PUBLIC_BASE_URL;
  try {
    const h = await headers();
    const hote = h.get("x-forwarded-host") ?? h.get("host");
    const proto = h.get("x-forwarded-proto") ?? (hote?.startsWith("localhost") ? "http" : "https");
    if (hote) return `${proto}://${hote}`;
  } catch {}
  return "http://localhost:3000";
}
