import { cookies } from "next/headers";
import { lireDb, type User, type Role } from "@/lib/store";
import { signer, verifierSignature } from "@/lib/password";

const COOKIE = "rnr_session";

export interface Session {
  userId: string;
  role: Role;
  /** Deuxième facteur validé (administrateurs). */
  renforcee: boolean;
  exp: number;
}

export async function ouvrirSession(user: User, renforcee = false) {
  const session: Session = { userId: user.id, role: user.role, renforcee, exp: Date.now() + 12 * 3_600_000 };
  const valeur = signer(Buffer.from(JSON.stringify(session)).toString("base64url"));
  (await cookies()).set(COOKIE, valeur, { httpOnly: true, sameSite: "lax", path: "/", secure: process.env.NODE_ENV === "production", maxAge: 12 * 3600 });
}

export async function fermerSession() {
  (await cookies()).delete(COOKIE);
}

export async function lireSession(): Promise<Session | null> {
  const brut = (await cookies()).get(COOKIE)?.value;
  if (!brut) return null;
  const valeur = verifierSignature(brut);
  if (!valeur) return null;
  try {
    const s = JSON.parse(Buffer.from(valeur, "base64url").toString()) as Session;
    if (s.exp < Date.now()) return null;
    return s;
  } catch {
    return null;
  }
}

export async function utilisateurCourant(): Promise<User | null> {
  const s = await lireSession();
  if (!s) return null;
  const db = await lireDb();
  return db.users.find((u) => u.id === s.userId) ?? null;
}

export async function exigerRole(roles: Role[]): Promise<{ user: User; session: Session } | null> {
  const session = await lireSession();
  if (!session || !roles.includes(session.role)) return null;
  const db = await lireDb();
  const user = db.users.find((u) => u.id === session.userId);
  if (!user) return null;
  if (user.role === "admin" && !session.renforcee) return null;
  return { user, session };
}
