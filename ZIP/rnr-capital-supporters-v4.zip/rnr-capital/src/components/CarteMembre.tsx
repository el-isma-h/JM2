/** Carte de membre numérique (nominative). Version de démonstration sans logo officiel. */
export function CarteMembre({ pseudo, statut, numero, demo, saison = "2026-2027" }: { pseudo: string; statut: string; numero: string; demo?: boolean; saison?: string }) {
  return (
    <div className="relative aspect-[1.6/1] w-full max-w-md overflow-hidden rounded-2xl border border-blanc/15 bg-gradient-to-br from-ardoise via-noir-2 to-rouge-sombre p-6 text-blanc shadow-2xl">
      <div className="absolute left-0 top-0 h-1.5 w-full bg-rouge" aria-hidden />
      <div className="flex items-start justify-between">
        <div>
          <p className="label text-[0.6rem] text-blanc/70">Carte de membre</p>
          <p className="display text-3xl">{statut}</p>
        </div>
        <span className="display grid h-10 w-10 place-items-center bg-rouge text-sm not-italic">RNR</span>
      </div>
      <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
        <div>
          <p className="display text-2xl">{pseudo}</p>
          <p className="text-xs text-blanc/70">Saison {saison} · Nominative · N° {numero}</p>
        </div>
        {demo && <span className="label border border-or/60 px-2 py-0.5 text-[0.6rem] text-or">Spécimen</span>}
      </div>
      <svg className="pointer-events-none absolute -right-10 -top-10 h-56 w-56 opacity-10" viewBox="0 0 100 100" aria-hidden>
        <circle cx="50" cy="50" r="48" fill="none" stroke="white" strokeWidth="1" />
        <circle cx="50" cy="50" r="36" fill="none" stroke="white" strokeWidth="1" />
        <circle cx="50" cy="50" r="24" fill="none" stroke="white" strokeWidth="1" />
      </svg>
    </div>
  );
}
