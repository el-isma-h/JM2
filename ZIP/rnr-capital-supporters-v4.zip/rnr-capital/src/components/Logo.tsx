import Image from "next/image";

/**
 * Logo officiel du Rouen Normandie Rugby (tête de lion), SVG blanc.
 * `sombre` l'affiche en ardoise (pour les fonds clairs). Usage en démonstration uniquement :
 * l'autorisation écrite du club est requise avant toute mise en ligne publique.
 */
export function Logo({ taille = 40, className = "", avecTexte = true, sombre = false }: { taille?: number; className?: string; avecTexte?: boolean; sombre?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      <Image src="/images/logo-rnr.svg" alt="Rouen Normandie Rugby" width={taille} height={taille} priority className="shrink-0" style={sombre ? { filter: "brightness(0) saturate(100%) invert(9%) sepia(20%) saturate(1500%) hue-rotate(195deg)" } : undefined} />
      {avecTexte && <span className="display text-2xl leading-none">RNR</span>}
    </span>
  );
}
