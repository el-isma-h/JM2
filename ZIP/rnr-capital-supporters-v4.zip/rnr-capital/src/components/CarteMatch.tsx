import type { Match } from "@/data/matchs";
import { RNR } from "@/data/matchs";
import { Badge, dateHeureFr } from "@/components/ui";

const statutLabel: Record<Match["statut"], string> = {
  a_venir: "À venir",
  termine: "Terminé",
  reporte: "Reporté",
  annule: "Annulé",
  forfait: "Forfait",
};

export function CarteMatch({ match, compact = false }: { match: Match; compact?: boolean }) {
  const termine = match.statut === "termine";
  const rnrDomicile = match.domicile === RNR;
  const score = termine ? `${match.scoreDomicile} - ${match.scoreExterieur}` : null;
  const victoire = termine && ((rnrDomicile && (match.scoreDomicile ?? 0) > (match.scoreExterieur ?? 0)) || (!rnrDomicile && (match.scoreExterieur ?? 0) > (match.scoreDomicile ?? 0)));
  return (
    <article className={`carte min-w-0 ${compact ? "p-4" : "p-5"}`}>
      <div className="mb-3 flex items-center justify-between gap-2 text-xs font-600 uppercase tracking-wider text-gris">
        <span>J{match.journee} · {dateHeureFr(match.coupDEnvoi)} (Paris)</span>
        <Badge teinte={termine ? (victoire ? "vert" : "rouge") : match.statut === "a_venir" ? "gris" : "ambre"}>
          {termine ? (victoire ? "Victoire" : "Défaite") : statutLabel[match.statut]}
        </Badge>
      </div>
      <div className="grid min-w-0 grid-cols-[1fr_auto_1fr] items-center gap-2 sm:gap-3">
        <p className={`display min-w-0 truncate text-right text-xl sm:text-2xl ${rnrDomicile ? "text-rouge" : "text-ardoise"}`}>{match.domicile}</p>
        <p className={score ? `score-pill text-base ${victoire ? "" : "is-loss"}` : "display px-2 text-xl text-gris"}>{score ?? "VS"}</p>
        <p className={`display min-w-0 truncate text-xl sm:text-2xl ${rnrDomicile ? "text-ardoise" : "text-rouge"}`}>{match.exterieur}</p>
      </div>
      {!compact && <p className="mt-3 text-xs text-gris">{match.lieu} · {match.competition}</p>}
    </article>
  );
}
