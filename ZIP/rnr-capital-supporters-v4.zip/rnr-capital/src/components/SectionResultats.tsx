/**
 * Section « Les résultats » reprise du site officiel : titre + étiquette saison, trois cartes verre
 * (position, derniers résultats, statistiques), puis la courbe des performances.
 */
import type { Match } from "@/data/matchs";
import { RNR, positionActuelle } from "@/data/matchs";
import { liensOfficiels } from "@/config/campagne";
import { Performances, statsSaison } from "@/components/Performances";
import { Apparition } from "@/components/Apparition";
import { FondPhoto } from "@/components/FondPhoto";

const dateCourte = (iso: string) => new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris", day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date(iso));

export function SectionResultats({ joues, saison = "26/27", titre = "Les résultats" }: { joues: Match[]; saison?: string; titre?: string }) {
  const s = statsSaison(joues);
  const derniers = [...joues].reverse().slice(0, 4);
  const position = positionActuelle.position;
  const ptsClassement = positionActuelle.pointsClassement;
  return (
    <section className="section-sombre px-4 py-16 sm:px-6 md:py-24" id="resultats">
      <FondPhoto src="/images/club.jpg" position="center 30%" opacite={0.7} />
      <div className="relative z-10 mx-auto max-w-6xl">
        <div className="mb-10 flex flex-wrap items-center gap-4">
          <h2 className="text-5xl sm:text-6xl">{titre}</h2>
          <span className="display bg-rouge px-4 py-1.5 text-xl not-italic tracking-wider">Saison {saison}</span>
        </div>
        <div className="grid gap-5 md:grid-cols-3 [&>*]:min-w-0">
          <Apparition>
            <div className="carte-verre flex h-full flex-col p-6">
              <h3 className="text-lg tracking-widest text-blanc/90">Position</h3>
              <p className="display my-auto py-6 text-center text-[7rem] leading-none">{position}<sup className="text-3xl text-rouge">e</sup></p>
              <p className="label mb-2 text-center text-[0.6rem] text-blanc/40">Nationale · après J{positionActuelle.apresJournee}</p>
              <a href={liensOfficiels.classement} target="_blank" rel="noopener noreferrer" className="lien-section text-center text-blanc/70 hover:text-blanc">Voir le classement →</a>
            </div>
          </Apparition>
          <Apparition delai={0.08}>
            <div className="carte-verre flex h-full flex-col p-6">
              <h3 className="text-lg tracking-widest text-blanc/90">Derniers résultats</h3>
              <ul className="my-4 flex-1 divide-y divide-blanc/10">
                {derniers.map((m) => {
                  const dom = m.domicile === RNR;
                  const win = dom ? (m.scoreDomicile ?? 0) > (m.scoreExterieur ?? 0) : (m.scoreExterieur ?? 0) > (m.scoreDomicile ?? 0);
                  return (
                    <li key={m.id} className="flex min-w-0 items-center gap-2 py-2.5 text-sm sm:gap-3">
                      <span className="w-16 shrink-0 sm:w-20"><span className="font-900">J{m.journee}</span><br /><span className="text-xs text-blanc/60">{dateCourte(m.coupDEnvoi)}</span></span>
                      <span className={`display min-w-0 flex-1 truncate text-base ${dom ? "text-rouge-vif" : "text-blanc"}`}>{m.domicile}</span>
                      <span className={`score-pill ${win ? "" : "is-loss"}`}>{m.scoreDomicile} - {m.scoreExterieur}</span>
                      <span className={`display min-w-0 flex-1 truncate text-right text-base ${dom ? "text-blanc" : "text-rouge-vif"}`}>{m.exterieur}</span>
                    </li>
                  );
                })}
              </ul>
              <a href={liensOfficiels.calendrier} target="_blank" rel="noopener noreferrer" className="lien-section text-center text-blanc/70 hover:text-blanc">Voir tous les résultats →</a>
            </div>
          </Apparition>
          <Apparition delai={0.16}>
            <div className="carte-verre h-full p-6">
              <h3 className="text-lg tracking-widest text-blanc/90">Statistiques</h3>
              <div className="mt-4 grid grid-cols-2 gap-y-5">
                <Stat label="Victoires" valeur={s.victoires} teinte="text-blanc" icone="🏆" />
                <Stat label="Défaites" valeur={s.defaites} teinte="text-blanc/50" icone="✕" />
                <Stat label="Points marqués" valeur={s.pour} teinte="text-blanc" />
                <Stat label="Points concédés" valeur={s.contre} teinte="text-blanc/50" />
                <Stat label="Différence" valeur={`${s.diff > 0 ? "+" : ""}${s.diff}`} teinte="text-rouge-vif" />
                <Stat label="Points class." valeur={ptsClassement} teinte="text-blanc" />
              </div>
            </div>
          </Apparition>
        </div>
        <Apparition delai={0.2}>
          <div className="carte-verre mt-5 p-6">
            <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
              <div>
                <h3 className="text-lg tracking-widest text-blanc/90">Courbe des performances</h3>
                <p className="mt-1 text-sm text-blanc/60">La ligne monte quand les Lions marquent plus qu&apos;ils n&apos;encaissent. Chaque point est une journée : vert pour une victoire.</p>
              </div>
              <span className="label text-xs text-blanc/50">{joues.length} journées jouées · source : résultats publiés par le club</span>
            </div>
            <Performances joues={joues} sombre />
          </div>
        </Apparition>
        <p className="mt-4 text-xs text-blanc/50">Les performances sportives n&apos;ont aucun effet mécanique sur la valeur d&apos;une action. Aucune valorisation n&apos;est affichée sans évaluation documentée.</p>
      </div>
    </section>
  );
}

function Stat({ label, valeur, teinte, icone }: { label: string; valeur: string | number; teinte: string; icone?: string }) {
  return (
    <div>
      <p className="label text-[0.65rem] text-blanc/60">{icone && <span className="mr-1 text-rouge" aria-hidden>{icone}</span>}{label}</p>
      <p className={`display text-4xl ${teinte}`}>{valeur}</p>
    </div>
  );
}
