import Image from "next/image";

/**
 * Photo de fond pour une section sombre, comme sur le site officiel : image en couverture, voile noir
 * et dégradé pour garder le texte lisible. Les photos sont celles du club (voir public/images/CREDITS.md).
 */
export function FondPhoto({ src, position = "center", opacite = 0.38, className = "" }: { src: string; position?: string; opacite?: number; className?: string }) {
  return (
    <div className={`pointer-events-none absolute inset-0 z-0 overflow-hidden ${className}`} aria-hidden>
      <Image src={src} alt="" fill sizes="100vw" className="object-cover" style={{ objectPosition: position, opacity: opacite }} />
      <div className="absolute inset-0 bg-gradient-to-b from-noir/75 via-noir/35 to-noir/90" />
    </div>
  );
}
