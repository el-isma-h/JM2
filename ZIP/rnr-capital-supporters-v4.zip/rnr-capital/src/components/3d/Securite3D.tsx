"use client";

import { useEffect, useState } from "react";

/**
 * Garde-fous pour l'affichage des scènes 3D.
 * - `use3DAutorisee()` : null tant que non déterminé (SSR / premier rendu),
 *   false si l'utilisateur préfère réduire les animations, si l'économiseur
 *   de données est actif ou si WebGL n'est pas disponible, true sinon.
 * - `Secours3D` : bloc HTML/SVG sobre affiché à la place de la 3D.
 */

type NavigatorAvecConnexion = Navigator & {
  connection?: { saveData?: boolean };
};

function webglDisponible(): boolean {
  try {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("webgl") ?? canvas.getContext("experimental-webgl");
    return ctx !== null;
  } catch {
    return false;
  }
}

export function use3DAutorisee(): boolean | null {
  const [autorisee, setAutorisee] = useState<boolean | null>(null);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const nav = navigator as NavigatorAvecConnexion;

    const evaluer = () => {
      if (mq.matches) return false;
      if (nav.connection?.saveData) return false;
      if (!webglDisponible()) return false;
      return true;
    };

    setAutorisee(evaluer());

    const onChange = () => setAutorisee(evaluer());
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  return autorisee;
}

export type Secours3DProps = {
  titre: string;
  texte: string;
  type?: "voiture" | "lots";
  className?: string;
};

function SilhouetteVoiture() {
  return (
    <svg viewBox="0 0 240 100" className="h-24 w-auto" aria-hidden="true" fill="none">
      <path
        d="M18 64 L34 62 L52 40 Q60 30 76 30 L140 30 Q160 30 174 44 L192 56 L218 60 Q226 62 226 70 L224 76 L16 76 Q12 70 18 64 Z"
        fill="#c41e3a"
        opacity="0.9"
      />
      <path d="M62 44 L76 36 L136 36 L158 48 Z" fill="#0f0f12" opacity="0.8" />
      <circle cx="60" cy="78" r="12" fill="#0f0f12" stroke="#d8b45a" strokeWidth="3" />
      <circle cx="180" cy="78" r="12" fill="#0f0f12" stroke="#d8b45a" strokeWidth="3" />
      <rect x="212" y="58" width="10" height="5" rx="2" fill="#f3efe8" />
    </svg>
  );
}

function SilhouetteBallon() {
  return (
    <svg viewBox="0 0 160 100" className="h-24 w-auto" aria-hidden="true" fill="none">
      <ellipse cx="80" cy="50" rx="68" ry="38" fill="#f3efe8" />
      <path d="M20 50 Q80 10 140 50 Q80 90 20 50 Z" fill="#c41e3a" opacity="0.85" />
      <path d="M62 50 L98 50" stroke="#0f0f12" strokeWidth="3" strokeLinecap="round" />
      {[66, 74, 82, 90, 98].map((x) => (
        <path key={x} d={`M${x} 45 L${x} 55`} stroke="#0f0f12" strokeWidth="2.5" strokeLinecap="round" />
      ))}
      <ellipse cx="80" cy="50" rx="68" ry="38" stroke="#d8b45a" strokeWidth="2" />
    </svg>
  );
}

export function Secours3D({ titre, texte, type = "voiture", className = "" }: Secours3DProps) {
  return (
    <div
      className={`flex flex-col items-center justify-center gap-4 rounded-2xl border border-white/10 bg-[#0f0f12] p-8 text-center ${className}`}
      role="img"
      aria-label={titre}
    >
      {type === "voiture" ? <SilhouetteVoiture /> : <SilhouetteBallon />}
      <div>
        <p className="font-semibold text-[#f3efe8]">{titre}</p>
        <p className="mt-1 max-w-sm text-sm text-[#f3efe8]/70">{texte}</p>
      </div>
    </div>
  );
}

export default Secours3D;
