"use client";

import { Suspense, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, OrbitControls } from "@react-three/drei";
import type * as THREE from "three";
import { Voiture } from "./Voiture";

/**
 * Scène autonome : berline stylisée sur un plateau tournant, éclairage studio.
 * À importer via `next/dynamic` avec `ssr: false`.
 */

export type SceneVoitureProps = {
  className?: string;
  /** Couleur de carrosserie (hex). */
  couleur?: string;
};

function Plateau() {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (ref.current) ref.current.rotation.y += delta * 0.08;
  });
  return (
    <group ref={ref}>
      {/* plateau plat sombre */}
      <mesh position={[0, -0.04, 0]} receiveShadow>
        <cylinderGeometry args={[3.4, 3.5, 0.08, 64]} />
        <meshStandardMaterial color="#17171c" roughness={0.6} metalness={0.3} />
      </mesh>
      {/* liseré or discret */}
      <mesh position={[0, 0.001, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[3.3, 3.38, 64]} />
        <meshStandardMaterial color="#d8b45a" roughness={0.4} metalness={0.7} />
      </mesh>
    </group>
  );
}

function Eclairage() {
  return (
    <>
      {/* Éclairage studio sans HDRI externe : aucune ressource réseau. */}
      <ambientLight intensity={0.55} />
      <hemisphereLight args={["#f3efe8", "#2a1a1a", 0.9]} />
      <directionalLight
        position={[5, 7, 4]}
        intensity={2.6}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />
      <directionalLight position={[-6, 4, -3]} intensity={1.4} color="#f3efe8" />
      <directionalLight position={[0, 3, -7]} intensity={1.2} color="#ffd9c2" />
      <spotLight position={[0, 8, 0]} intensity={0.6} angle={0.6} penumbra={0.8} color="#d8b45a" />
    </>
  );
}

function Chargement() {
  return (
    <mesh position={[0, 0.5, 0]}>
      <boxGeometry args={[1.2, 0.3, 0.6]} />
      <meshStandardMaterial color="#2a2a30" wireframe />
    </mesh>
  );
}

export default function SceneVoiture({ className = "", couleur }: SceneVoitureProps) {
  return (
    <div className={`relative ${className}`}>
      <Canvas
        dpr={[1, 1.5]}
        shadows
        camera={{ position: [5.2, 2.4, 5.6], fov: 38 }}
        gl={{ alpha: true, antialias: true }}
        style={{ background: "transparent" }}
      >
        <Eclairage />
        <Suspense fallback={<Chargement />}>
          <Voiture couleur={couleur} animee />
          <Plateau />
          <ContactShadows position={[0, 0.005, 0]} opacity={0.6} scale={9} blur={2.2} far={3} />
        </Suspense>
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          autoRotate
          autoRotateSpeed={0.6}
          minPolarAngle={Math.PI / 5}
          maxPolarAngle={Math.PI / 2.15}
          target={[0, 0.5, 0]}
        />
      </Canvas>

      <div className="pointer-events-none absolute bottom-3 left-3 rounded bg-black/60 px-3 py-1 text-xs text-ambre">
        Modèle 3D stylisé, non contractuel — lot envisagé, partenariat non signé
      </div>
    </div>
  );
}
