"use client";

import { useMemo } from "react";
import * as THREE from "three";

/**
 * Objets 3D des lots du concours, modélisés uniquement avec des primitives three.js.
 * Aucune texture, aucun logo. Chaque objet tient dans un cube d'environ 1.2 unité,
 * posé sur y = 0.
 */

const IVOIRE = "#f3efe8";
const ROUGE = "#c41e3a";
const NOIR = "#0f0f12";
const OR = "#d8b45a";

export type ObjetProps = {
  position?: [number, number, number];
  rotation?: [number, number, number];
  scale?: number;
};

/* ----------------------------------------------------------------------- */
/* Ballon de rugby                                                            */
/* ----------------------------------------------------------------------- */

export function Ballon({ position = [0, 0, 0], rotation = [0, 0, 0], scale = 1 }: ObjetProps) {
  return (
    <group position={position} rotation={rotation} scale={scale}>
      <group position={[0, 0.38, 0]} rotation={[0, 0, 0.35]}>
        {/* corps : sphère étirée */}
        <mesh scale={[1, 0.62, 0.62]} castShadow>
          <sphereGeometry args={[0.6, 32, 24]} />
          <meshStandardMaterial color={IVOIRE} roughness={0.55} metalness={0.02} />
        </mesh>
        {/* bande rouge centrale */}
        <mesh scale={[1.005, 0.625, 0.625]}>
          <sphereGeometry args={[0.6, 32, 24, 0, Math.PI * 2, Math.PI * 0.42, Math.PI * 0.16]} />
          <meshStandardMaterial color={ROUGE} roughness={0.55} side={THREE.DoubleSide} />
        </mesh>
        {/* 4 coutures claires : tores fins placés à 0°, 90°, 180°, 270° autour de l'axe long */}
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} rotation={[(i * Math.PI) / 2, 0, 0]} scale={[1.58, 1, 1]}>
            <torusGeometry args={[0.368, 0.012, 6, 40, Math.PI]} />
            <meshStandardMaterial color={IVOIRE} roughness={0.4} emissive={IVOIRE} emissiveIntensity={0.15} />
          </mesh>
        ))}
        {/* laçage central : petit bloc + 6 lacets */}
        <mesh position={[0, 0.372, 0]}>
          <boxGeometry args={[0.34, 0.02, 0.07]} />
          <meshStandardMaterial color={IVOIRE} roughness={0.6} />
        </mesh>
        {[-0.12, -0.072, -0.024, 0.024, 0.072, 0.12].map((x) => (
          <mesh key={x} position={[x, 0.382, 0]}>
            <boxGeometry args={[0.014, 0.012, 0.1]} />
            <meshStandardMaterial color={NOIR} roughness={0.7} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

/* ----------------------------------------------------------------------- */
/* Maillot                                                                    */
/* ----------------------------------------------------------------------- */

function formeMaillot(): THREE.Shape {
  // T-shirt vu de face (plan XY), centré, ~1.1 de large sur ~1.0 de haut.
  const s = new THREE.Shape();
  s.moveTo(-0.18, 0.5); // base du col gauche
  s.lineTo(-0.42, 0.44); // épaule gauche
  s.lineTo(-0.58, 0.16); // bout de manche gauche (haut)
  s.lineTo(-0.44, 0.06); // bout de manche gauche (bas)
  s.lineTo(-0.34, 0.18); // aisselle gauche
  s.lineTo(-0.34, -0.5); // bas gauche
  s.lineTo(0.34, -0.5); // bas droit
  s.lineTo(0.34, 0.18); // aisselle droite
  s.lineTo(0.44, 0.06);
  s.lineTo(0.58, 0.16);
  s.lineTo(0.42, 0.44);
  s.lineTo(0.18, 0.5); // base du col droit
  s.quadraticCurveTo(0, 0.38, -0.18, 0.5); // encolure
  s.closePath();
  return s;
}

function formeCol(): THREE.Shape {
  const s = new THREE.Shape();
  s.moveTo(-0.2, 0.52);
  s.lineTo(-0.26, 0.5);
  s.quadraticCurveTo(0, 0.3, 0.26, 0.5);
  s.lineTo(0.2, 0.52);
  s.quadraticCurveTo(0, 0.4, -0.2, 0.52);
  s.closePath();
  return s;
}

export function Maillot({ position = [0, 0, 0], rotation = [0, 0, 0], scale = 1 }: ObjetProps) {
  const geomMaillot = useMemo(() => {
    const g = new THREE.ExtrudeGeometry(formeMaillot(), {
      depth: 0.1,
      bevelEnabled: true,
      bevelThickness: 0.02,
      bevelSize: 0.02,
      bevelSegments: 2,
    });
    g.translate(0, 0, -0.05);
    return g;
  }, []);
  const geomCol = useMemo(() => {
    const g = new THREE.ExtrudeGeometry(formeCol(), { depth: 0.12, bevelEnabled: false });
    g.translate(0, 0, -0.06);
    return g;
  }, []);

  return (
    <group position={position} rotation={rotation} scale={scale}>
      <group position={[0, 0.6, 0]}>
        <mesh geometry={geomMaillot} castShadow>
          <meshStandardMaterial color={ROUGE} roughness={0.75} metalness={0.02} />
        </mesh>
        {/* col noir */}
        <mesh geometry={geomCol} position={[0, 0.005, 0]}>
          <meshStandardMaterial color={NOIR} roughness={0.8} />
        </mesh>
        {/* bande noire horizontale (face et dos) */}
        <mesh position={[0, -0.08, 0.072]}>
          <boxGeometry args={[0.66, 0.1, 0.012]} />
          <meshStandardMaterial color={NOIR} roughness={0.8} />
        </mesh>
        <mesh position={[0, -0.08, -0.072]}>
          <boxGeometry args={[0.66, 0.1, 0.012]} />
          <meshStandardMaterial color={NOIR} roughness={0.8} />
        </mesh>
        {/* liseré or aux manches */}
        {[-0.5, 0.5].map((x) => (
          <mesh key={x} position={[x, 0.11, 0]} rotation={[0, 0, x > 0 ? -0.6 : 0.6]}>
            <boxGeometry args={[0.03, 0.16, 0.15]} />
            <meshStandardMaterial color={OR} roughness={0.4} metalness={0.5} />
          </mesh>
        ))}
        {/* cintre discret */}
        <mesh position={[0, 0.58, 0]}>
          <torusGeometry args={[0.07, 0.012, 6, 20, Math.PI]} />
          <meshStandardMaterial color="#8c8c92" roughness={0.3} metalness={0.8} />
        </mesh>
      </group>
    </group>
  );
}

/* ----------------------------------------------------------------------- */
/* Panier gastronomique                                                       */
/* ----------------------------------------------------------------------- */

export function Panier({ position = [0, 0, 0], rotation = [0, 0, 0], scale = 1 }: ObjetProps) {
  const geomPanier = useMemo(() => {
    const pts: THREE.Vector2[] = [
      new THREE.Vector2(0, 0),
      new THREE.Vector2(0.34, 0),
      new THREE.Vector2(0.4, 0.06),
      new THREE.Vector2(0.44, 0.2),
      new THREE.Vector2(0.48, 0.38),
      new THREE.Vector2(0.5, 0.42),
      new THREE.Vector2(0.46, 0.42),
      new THREE.Vector2(0.42, 0.2),
      new THREE.Vector2(0.36, 0.06),
    ];
    return new THREE.LatheGeometry(pts, 24);
  }, []);

  return (
    <group position={position} rotation={rotation} scale={scale}>
      {/* corps en osier */}
      <mesh geometry={geomPanier} castShadow>
        <meshStandardMaterial color="#8c5a2e" roughness={0.9} metalness={0} side={THREE.DoubleSide} />
      </mesh>
      {/* tressage : anneaux horizontaux plus clairs */}
      {[0.1, 0.22, 0.34].map((y, i) => (
        <mesh key={y} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.41 + i * 0.03, 0.012, 6, 32]} />
          <meshStandardMaterial color="#b07a44" roughness={0.9} />
        </mesh>
      ))}
      {/* anse torique */}
      <mesh position={[0, 0.42, 0]} rotation={[0, 0, 0]}>
        <torusGeometry args={[0.46, 0.028, 8, 32, Math.PI]} />
        <meshStandardMaterial color="#7a4b22" roughness={0.9} />
      </mesh>
      {/* linge ivoire qui dépasse */}
      <mesh position={[0, 0.4, 0]}>
        <cylinderGeometry args={[0.44, 0.4, 0.06, 24]} />
        <meshStandardMaterial color={IVOIRE} roughness={0.95} />
      </mesh>
      {/* bouteille verte */}
      <group position={[-0.14, 0.42, 0.08]} rotation={[0, 0, 0.12]}>
        <mesh>
          <cylinderGeometry args={[0.07, 0.07, 0.44, 16]} />
          <meshStandardMaterial color="#2f5a3a" roughness={0.25} metalness={0.1} />
        </mesh>
        <mesh position={[0, 0.3, 0]}>
          <cylinderGeometry args={[0.028, 0.07, 0.16, 16]} />
          <meshStandardMaterial color="#2f5a3a" roughness={0.25} metalness={0.1} />
        </mesh>
        <mesh position={[0, 0.41, 0]}>
          <cylinderGeometry args={[0.03, 0.028, 0.06, 12]} />
          <meshStandardMaterial color={OR} roughness={0.4} metalness={0.6} />
        </mesh>
        <mesh position={[0.071, 0, 0]} rotation={[0, 0, 0]}>
          <boxGeometry args={[0.004, 0.16, 0.09]} />
          <meshStandardMaterial color={IVOIRE} roughness={0.8} />
        </mesh>
      </group>
      {/* meule de fromage */}
      <group position={[0.18, 0.48, -0.06]} rotation={[0.3, 0.4, 0]}>
        <mesh>
          <cylinderGeometry args={[0.16, 0.16, 0.08, 24, 1, false, 0, Math.PI * 1.7]} />
          <meshStandardMaterial color="#e9c75a" roughness={0.7} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[0, 0.041, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.16, 24, 0, Math.PI * 1.7]} />
          <meshStandardMaterial color="#f1dd8c" roughness={0.7} side={THREE.DoubleSide} />
        </mesh>
      </group>
      {/* pot (confiture) */}
      <group position={[0.1, 0.46, 0.2]}>
        <mesh>
          <cylinderGeometry args={[0.08, 0.075, 0.16, 16]} />
          <meshStandardMaterial color="#7a2434" roughness={0.3} metalness={0.05} />
        </mesh>
        <mesh position={[0, 0.095, 0]}>
          <cylinderGeometry args={[0.085, 0.085, 0.03, 16]} />
          <meshStandardMaterial color={OR} roughness={0.4} metalness={0.6} />
        </mesh>
        <mesh position={[0, 0.118, 0]}>
          <cylinderGeometry args={[0.09, 0.09, 0.012, 16]} />
          <meshStandardMaterial color={ROUGE} roughness={0.8} />
        </mesh>
      </group>
    </group>
  );
}

/* ----------------------------------------------------------------------- */
/* Équipement : cône d'entraînement + paire de chaussures                     */
/* ----------------------------------------------------------------------- */

function Chaussure({ position, rotation = [0, 0, 0] }: { position: [number, number, number]; rotation?: [number, number, number] }) {
  return (
    <group position={position} rotation={rotation}>
      {/* semelle */}
      <mesh position={[0, 0.02, 0]}>
        <boxGeometry args={[0.42, 0.04, 0.16]} />
        <meshStandardMaterial color={IVOIRE} roughness={0.8} />
      </mesh>
      {/* corps */}
      <mesh position={[0.02, 0.1, 0]} castShadow>
        <boxGeometry args={[0.36, 0.12, 0.15]} />
        <meshStandardMaterial color={NOIR} roughness={0.6} />
      </mesh>
      {/* pointe arrondie */}
      <mesh position={[0.2, 0.08, 0]} scale={[1, 0.8, 1]}>
        <sphereGeometry args={[0.075, 14, 10]} />
        <meshStandardMaterial color={NOIR} roughness={0.6} />
      </mesh>
      {/* tige (talon) */}
      <mesh position={[-0.14, 0.18, 0]}>
        <boxGeometry args={[0.12, 0.08, 0.14]} />
        <meshStandardMaterial color={NOIR} roughness={0.6} />
      </mesh>
      {/* bande rouge latérale */}
      <mesh position={[0.02, 0.1, 0.078]}>
        <boxGeometry args={[0.2, 0.03, 0.004]} />
        <meshStandardMaterial color={ROUGE} roughness={0.5} />
      </mesh>
      {/* crampons */}
      {[-0.1, 0.02, 0.14].map((x) =>
        [-0.05, 0.05].map((z) => (
          <mesh key={`${x}-${z}`} position={[x, -0.015, z]}>
            <cylinderGeometry args={[0.012, 0.012, 0.03, 6]} />
            <meshStandardMaterial color="#8c8c92" roughness={0.3} metalness={0.8} />
          </mesh>
        )),
      )}
    </group>
  );
}

export function Equipement({ position = [0, 0, 0], rotation = [0, 0, 0], scale = 1 }: ObjetProps) {
  return (
    <group position={position} rotation={rotation} scale={scale}>
      {/* cône d'entraînement orange */}
      <group position={[-0.22, 0, -0.1]}>
        <mesh position={[0, 0.015, 0]}>
          <boxGeometry args={[0.46, 0.03, 0.46]} />
          <meshStandardMaterial color="#e2641e" roughness={0.6} />
        </mesh>
        <mesh position={[0, 0.34, 0]} castShadow>
          <cylinderGeometry args={[0.05, 0.2, 0.64, 20, 1, true]} />
          <meshStandardMaterial color="#e2641e" roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[0, 0.66, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 0.02, 20]} />
          <meshStandardMaterial color="#e2641e" roughness={0.6} />
        </mesh>
        {/* bande ivoire */}
        <mesh position={[0, 0.4, 0]}>
          <cylinderGeometry args={[0.092, 0.11, 0.08, 20, 1, true]} />
          <meshStandardMaterial color={IVOIRE} roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
      </group>
      {/* paire de chaussures */}
      <Chaussure position={[0.28, 0.03, 0.1]} rotation={[0, 0.5, 0]} />
      <Chaussure position={[0.3, 0.03, 0.34]} rotation={[0, 0.25, 0]} />
    </group>
  );
}

export const OBJETS_LOTS = {
  ballon: Ballon,
  maillot: Maillot,
  panier: Panier,
  equipement: Equipement,
} as const;

export type IdLot = keyof typeof OBJETS_LOTS;
