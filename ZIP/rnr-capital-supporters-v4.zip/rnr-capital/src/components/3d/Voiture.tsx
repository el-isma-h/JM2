"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

/**
 * Berline sportive stylisée, modélisée uniquement avec des primitives three.js.
 * Aucun logo, aucune marque : silhouette générique et non contractuelle.
 * Dimensions : ~4.4 unités de long (axe X), ~1.9 de large (axe Z), ~1.3 de haut (axe Y).
 * L'avant est en +X.
 */

export type VoitureProps = {
  /** Couleur de carrosserie (hex). Défaut : cuivre/bronze métallisé. */
  couleur?: string;
  /** Fait tourner lentement les roues. */
  animee?: boolean;
  position?: [number, number, number];
  rotation?: [number, number, number];
  scale?: number;
};

const COULEUR_PNEU = "#15151a";
const COULEUR_JANTE = "#d9d6d0";
const COULEUR_VERRE = "#1a1f2b";
const COULEUR_SOMBRE = "#101014";
const COULEUR_PHARE = "#f3efe8";
const COULEUR_FEU = "#c41e3a";

function profilCapot(): THREE.Shape {
  // Profil latéral (plan XY) de la carrosserie, extrudé le long de Z.
  // x : avant (+) -> arrière (-) ; y : hauteur.
  const s = new THREE.Shape();
  s.moveTo(2.2, 0.32); // bas du pare-chocs avant
  s.lineTo(2.2, 0.62); // pare-chocs avant
  s.lineTo(2.05, 0.72); // nez
  s.lineTo(1.0, 0.86); // capot plongeant
  s.lineTo(0.45, 1.22); // pare-brise incliné
  s.lineTo(-0.55, 1.26); // toit
  s.lineTo(-1.35, 1.02); // lunette arrière
  s.lineTo(-2.05, 0.9); // coffre
  s.lineTo(-2.2, 0.8); // arrière tronqué
  s.lineTo(-2.2, 0.32); // bas du pare-chocs arrière
  s.lineTo(-1.75, 0.3);
  s.lineTo(1.75, 0.3);
  s.closePath();
  return s;
}

function profilVitrage(): THREE.Shape {
  // Habitacle vitré, légèrement en retrait de la carrosserie.
  const s = new THREE.Shape();
  s.moveTo(0.95, 0.88);
  s.lineTo(0.42, 1.2);
  s.lineTo(-0.55, 1.24);
  s.lineTo(-1.3, 1.0);
  s.lineTo(-1.3, 0.88);
  s.closePath();
  return s;
}

type RoueProps = {
  position: [number, number, number];
  animee: boolean;
};

function Roue({ position, animee }: RoueProps) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (animee && ref.current) {
      ref.current.rotation.z -= delta * 1.2;
    }
  });
  return (
    <group ref={ref} position={position}>
      <group rotation={[Math.PI / 2, 0, 0]}>
      {/* pneu */}
      <mesh castShadow>
        <cylinderGeometry args={[0.36, 0.36, 0.24, 28]} />
        <meshStandardMaterial color={COULEUR_PNEU} roughness={0.9} metalness={0.05} />
      </mesh>
      {/* jante */}
      <mesh>
        <cylinderGeometry args={[0.24, 0.24, 0.26, 18]} />
        <meshStandardMaterial color={COULEUR_JANTE} roughness={0.35} metalness={0.7} />
      </mesh>
      {/* moyeu */}
      <mesh>
        <cylinderGeometry args={[0.07, 0.07, 0.3, 12]} />
        <meshStandardMaterial color={COULEUR_SOMBRE} roughness={0.5} metalness={0.4} />
      </mesh>
      {/* rayons */}
      {[0, 1, 2, 3, 4].map((i) => (
        <mesh key={i} rotation={[0, (i * Math.PI * 2) / 5, 0]} position={[0, 0.005, 0]}>
          <boxGeometry args={[0.04, 0.27, 0.2]} />
          <meshStandardMaterial color={COULEUR_SOMBRE} roughness={0.5} metalness={0.4} />
        </mesh>
      ))}
      </group>
    </group>
  );
}

export function Voiture({
  couleur = "#b5673a",
  animee = false,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  scale = 1,
}: VoitureProps) {
  const geomCarrosserie = useMemo(() => {
    const g = new THREE.ExtrudeGeometry(profilCapot(), {
      depth: 1.7,
      bevelEnabled: true,
      bevelThickness: 0.06,
      bevelSize: 0.06,
      bevelSegments: 2,
    });
    g.translate(0, 0, -0.85);
    return g;
  }, []);

  const geomVitrage = useMemo(() => {
    const g = new THREE.ExtrudeGeometry(profilVitrage(), {
      depth: 1.62,
      bevelEnabled: false,
    });
    g.translate(0, 0.01, -0.81);
    return g;
  }, []);

  const materiauCarrosserie = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: couleur,
        // Sans carte d'environnement, un métal trop fort rend noir : peinture satinée éclairée par les projecteurs.
        metalness: 0.45,
        roughness: 0.35,
      }),
    [couleur],
  );

  const garde = 0.1; // garde au sol légère (les roues touchent le sol à y=0)

  return (
    <group position={position} rotation={rotation} scale={scale}>
      <group position={[0, garde, 0]}>
        {/* carrosserie */}
        <mesh geometry={geomCarrosserie} material={materiauCarrosserie} castShadow receiveShadow />

        {/* vitrage sombre semi-transparent */}
        <mesh geometry={geomVitrage}>
          <meshPhysicalMaterial
            color={COULEUR_VERRE}
            metalness={0.1}
            roughness={0.15}
            transparent
            opacity={0.72}
            clearcoat={1}
          />
        </mesh>

        {/* bas de caisse sombre */}
        <mesh position={[0, 0.3, 0]}>
          <boxGeometry args={[3.6, 0.1, 1.72]} />
          <meshStandardMaterial color={COULEUR_SOMBRE} roughness={0.8} />
        </mesh>

        {/* calandre sombre */}
        <mesh position={[2.22, 0.5, 0]}>
          <boxGeometry args={[0.04, 0.2, 1.0]} />
          <meshStandardMaterial color={COULEUR_SOMBRE} roughness={0.6} metalness={0.3} />
        </mesh>

        {/* phares avant (émissifs) */}
        {[-0.62, 0.62].map((z) => (
          <mesh key={`phare-${z}`} position={[2.14, 0.69, z]} rotation={[0, 0, -0.25]}>
            <boxGeometry args={[0.06, 0.09, 0.36]} />
            <meshStandardMaterial
              color={COULEUR_PHARE}
              emissive={COULEUR_PHARE}
              emissiveIntensity={1.6}
              roughness={0.2}
            />
          </mesh>
        ))}

        {/* bande de feux arrière (émissive rouge) */}
        <mesh position={[-2.23, 0.72, 0]}>
          <boxGeometry args={[0.04, 0.07, 1.5]} />
          <meshStandardMaterial
            color={COULEUR_FEU}
            emissive={COULEUR_FEU}
            emissiveIntensity={1.8}
            roughness={0.3}
          />
        </mesh>

        {/* rétroviseurs */}
        {[-0.98, 0.98].map((z) => (
          <group key={`retro-${z}`} position={[0.62, 0.95, z]}>
            <mesh>
              <boxGeometry args={[0.16, 0.08, 0.12]} />
              <meshStandardMaterial color={couleur} metalness={0.45} roughness={0.35} />
            </mesh>
            <mesh position={[0, -0.02, z > 0 ? -0.08 : 0.08]}>
              <boxGeometry args={[0.05, 0.04, 0.08]} />
              <meshStandardMaterial color={COULEUR_SOMBRE} />
            </mesh>
          </group>
        ))}

        {/* passages de roue (arcs sombres) */}
        {[1.35, -1.35].map((x) =>
          [-0.86, 0.86].map((z) => (
            <mesh key={`arc-${x}-${z}`} position={[x, 0.42, z]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.42, 0.42, 0.06, 24, 1, false, 0, Math.PI]} />
              <meshStandardMaterial color={COULEUR_SOMBRE} roughness={0.9} side={THREE.DoubleSide} />
            </mesh>
          )),
        )}
      </group>

      {/* roues : rayon 0.36, centre à y = 0.36 + garde ajustée pour toucher le sol */}
      {[1.35, -1.35].map((x) =>
        [-0.82, 0.82].map((z) => (
          <Roue key={`roue-${x}-${z}`} position={[x, 0.36, z]} animee={animee} />
        )),
      )}
    </group>
  );
}

export default Voiture;
