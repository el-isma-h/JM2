"use client";

import { Suspense, useRef, useState } from "react";
import { Canvas, useFrame, type ThreeEvent } from "@react-three/fiber";
import { ContactShadows, OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import { OBJETS_LOTS, type IdLot } from "./Lots3D";

/**
 * Podium des lots : 4 socles en arc, l'objet sélectionné monte légèrement
 * et reçoit un spot, les autres sont grisés. Clic = onSelection(id).
 * À importer via `next/dynamic` avec `ssr: false`.
 */

export type LotPodium = {
  id: string;
  titre: string;
  rang: string;
  etat: string;
};

export type PodiumLotsProps = {
  lots: LotPodium[];
  selection: string;
  onSelection: (id: string) => void;
  className?: string;
};

const ROUGE = "#c41e3a";
const OR = "#d8b45a";

function estIdLot(id: string): id is IdLot {
  return id in OBJETS_LOTS;
}

/** Positions en arc (4 socles), caméra regardant vers -Z. */
function positionArc(index: number, total: number): [number, number, number] {
  const rayon = 3.2;
  const ouverture = Math.PI * 0.62;
  const t = total <= 1 ? 0.5 : index / (total - 1);
  const angle = -ouverture / 2 + t * ouverture;
  return [Math.sin(angle) * rayon, 0, -Math.cos(angle) * rayon + rayon * 0.75];
}

/** Spot dirigé vers un point local (0, 0.9, 0) du groupe parent. */
function SpotLot() {
  const cible = useRef<THREE.Object3D>(new THREE.Object3D());
  return (
    <>
      <primitive object={cible.current} position={[0, 0.9, 0]} />
      <spotLight
        position={[0, 4.2, 1.2]}
        target={cible.current}
        angle={0.42}
        penumbra={0.7}
        intensity={14}
        distance={9}
        color="#f3efe8"
        castShadow
      />
    </>
  );
}

type SocleProps = {
  lot: LotPodium;
  position: [number, number, number];
  actif: boolean;
  onSelection: (id: string) => void;
};

function Socle({ lot, position, actif, onSelection }: SocleProps) {
  const groupe = useRef<THREE.Group>(null);
  const objet = useRef<THREE.Group>(null);
  const [survol, setSurvol] = useState(false);

  useFrame((state, delta) => {
    if (objet.current) {
      objet.current.rotation.y += delta * (actif ? 0.6 : 0.25);
    }
    if (groupe.current) {
      const cibleY = actif ? 0.32 : 0;
      groupe.current.position.y = THREE.MathUtils.damp(groupe.current.position.y, cibleY, 4, delta);
    }
    if (objet.current) {
      const flottement = actif ? Math.sin(state.clock.elapsedTime * 1.6) * 0.03 : 0;
      objet.current.position.y = 0.46 + flottement;
    }
  });

  const Objet = estIdLot(lot.id) ? OBJETS_LOTS[lot.id] : null;
  const grisage = actif ? 1 : survol ? 0.8 : 0.55;

  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    onSelection(lot.id);
  };
  const onOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setSurvol(true);
    document.body.style.cursor = "pointer";
  };
  const onOut = () => {
    setSurvol(false);
    document.body.style.cursor = "auto";
  };

  return (
    <group position={position}>
      <group ref={groupe} onClick={onClick} onPointerOver={onOver} onPointerOut={onOut}>
        {/* socle */}
        <mesh position={[0, 0.2, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[0.78, 0.84, 0.4, 40]} />
          <meshStandardMaterial color={actif ? "#1d1d23" : "#15151a"} roughness={0.55} metalness={0.35} />
        </mesh>
        {/* liseré supérieur : rouge si actif, sinon gris */}
        <mesh position={[0, 0.401, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.7, 0.78, 40]} />
          <meshStandardMaterial
            color={actif ? ROUGE : "#3a3a42"}
            emissive={actif ? ROUGE : "#0f0f12"}
            emissiveIntensity={actif ? 0.8 : 0}
            roughness={0.4}
          />
        </mesh>
        {/* zone cliquable invisible englobant l'objet */}
        <mesh position={[0, 1.0, 0]} visible={false}>
          <cylinderGeometry args={[0.8, 0.8, 1.4, 12]} />
          <meshBasicMaterial transparent opacity={0} />
        </mesh>
        {/* objet */}
        <group ref={objet} position={[0, 0.46, 0]}>
          {Objet ? (
            <group>
              <Objet scale={0.95} />
              {/* voile de grisage : on joue sur une sphère sombre quasi transparente */}
              {!actif && (
                <mesh position={[0, 0.45, 0]}>
                  <sphereGeometry args={[0.9, 16, 12]} />
                  <meshBasicMaterial color="#0f0f12" transparent opacity={1 - grisage} depthWrite={false} />
                </mesh>
              )}
            </group>
          ) : (
            <mesh position={[0, 0.3, 0]}>
              <boxGeometry args={[0.5, 0.5, 0.5]} />
              <meshStandardMaterial color={OR} />
            </mesh>
          )}
        </group>
      </group>

      {/* spot sur le lot sélectionné */}
      {actif && <SpotLot />}
    </group>
  );
}

export default function PodiumLots({ lots, selection, onSelection, className = "" }: PodiumLotsProps) {
  return (
    <div className={`relative ${className}`}>
      <Canvas
        dpr={[1, 1.5]}
        shadows
        camera={{ position: [0, 3.4, 7.6], fov: 36 }}
        gl={{ alpha: true, antialias: true }}
        style={{ background: "transparent" }}
      >
        <ambientLight intensity={0.35} />
        <directionalLight position={[4, 6, 5]} intensity={1.1} color="#f3efe8" />
        <directionalLight position={[-5, 3, -2]} intensity={0.5} color={OR} />

        <Suspense fallback={null}>
          {lots.map((lot, i) => (
            <Socle
              key={lot.id}
              lot={lot}
              position={positionArc(i, lots.length)}
              actif={lot.id === selection}
              onSelection={onSelection}
            />
          ))}
          {/* sol */}
          <mesh position={[0, -0.01, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
            <circleGeometry args={[7, 48]} />
            <meshStandardMaterial color="#121216" roughness={0.9} metalness={0.1} />
          </mesh>
          <ContactShadows position={[0, 0.002, 0]} opacity={0.5} scale={14} blur={2.4} far={2} />
        </Suspense>

        <OrbitControls
          enableZoom={false}
          enablePan={false}
          minPolarAngle={Math.PI / 4}
          maxPolarAngle={Math.PI / 2.2}
          minAzimuthAngle={-Math.PI / 5}
          maxAzimuthAngle={Math.PI / 5}
          target={[0, 0.8, 0]}
        />
      </Canvas>
    </div>
  );
}
