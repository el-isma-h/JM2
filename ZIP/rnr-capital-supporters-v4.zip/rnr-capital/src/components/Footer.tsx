import Link from "next/link";
import { campagne, liensOfficiels } from "@/config/campagne";
import { Logo } from "@/components/Logo";

const colonnes = [
  { titre: "Plateforme", liens: [["/projet", "Le projet"], ["/investir", "Investir"], ["/statuts", "Statuts et avantages"], ["/documents", "Documents et risques"], ["/faq", "Questions fréquentes"]] },
  { titre: "Concours gratuit", liens: [["/matchs", "Pronostics"], ["/classement", "Classement"], ["/lots", "Lots et partenaires"], ["/actualites", "Actualités du projet"]] },
  { titre: "Le club", liens: [[liensOfficiels.site, "Site officiel"], [liensOfficiels.billetterie, "Billetterie"], [liensOfficiels.boutique, "Boutique"], [liensOfficiels.partenaires, "Partenaires"]] },
  { titre: "Pratique", liens: [["/connexion", "Connexion / inscription"], ["/compte/profil", "Mon profil"], ["/mentions-legales", "Mentions légales"]] },
];

/** Pied de page clair (#f1f5f9), colonnes de liens, comme le site officiel. */
export function Footer() {
  return (
    <footer className="mt-16 bg-clair-2 text-ardoise">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-5">
        <div className="md:col-span-1">
          <div className="flex items-center gap-3 text-ardoise"><Logo taille={40} avecTexte={false} sombre /><p className="display text-2xl">{campagne.nom}</p></div>
          <p className="mt-2 text-xs text-gris">{campagne.bandeauNonOfficiel}. Projet présenté à la SAS Rouen Normandie Rugby. Aucun encaissement réel, aucune émission de titres sur cette démonstration.</p>
        </div>
        {colonnes.map((c) => (
          <div key={c.titre}>
            <p className="label mb-3 text-xs text-gris">{c.titre}</p>
            <ul className="space-y-2 text-sm">
              {c.liens.map(([href, label]) => (
                <li key={href}>
                  {href.startsWith("http") ? <a href={href} target="_blank" rel="noopener noreferrer" className="hover:text-rouge">{label} ↗</a> : <Link href={href} className="hover:text-rouge">{label}</Link>}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-gris-clair px-4 py-4 text-center text-[0.7rem] font-900 uppercase tracking-[0.12em] text-gris">
        Logo et photos © Rouen Normandie Rugby, utilisés pour cette démonstration · autorisation écrite du club requise avant mise en ligne
      </div>
    </footer>
  );
}
