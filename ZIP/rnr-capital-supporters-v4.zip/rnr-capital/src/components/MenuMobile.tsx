"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { liensOfficiels } from "@/config/campagne";
import { Logo } from "@/components/Logo";

/** Méga-menu plein écran comme sur le site officiel (burger → panneau noir, entrées Outfit italiques). */
export function MenuMobile({ liens, connecte, espace }: { liens: { href: string; label: string }[]; connecte: boolean; espace: string | null }) {
  const [ouvert, setOuvert] = useState(false);
  const premier = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    if (!ouvert) return;
    document.body.style.overflow = "hidden";
    premier.current?.focus();
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOuvert(false);
    window.addEventListener("keydown", esc);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", esc);
    };
  }, [ouvert]);

  return (
    <div>
      <button type="button" onClick={() => setOuvert(true)} aria-expanded={ouvert} aria-controls="megamenu" aria-label="Ouvrir le menu" className="grid h-11 w-11 place-items-center hover:text-rouge-vif">
        <Menu aria-hidden />
      </button>
      <AnimatePresence>
        {ouvert && (
          <motion.div id="megamenu" role="dialog" aria-modal="true" aria-label="Menu" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="fixed inset-0 z-50 flex flex-col overflow-y-auto bg-noir-2 px-6 py-5 text-blanc">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-3"><Logo taille={36} avecTexte={false} /><span className="label text-xs text-blanc/60">Lions Capital · projet non officiel</span></span>
              <button type="button" onClick={() => setOuvert(false)} aria-label="Fermer le menu" className="flex items-center gap-2 text-sm font-900 uppercase tracking-widest hover:text-rouge-vif"><X aria-hidden size={18} /> Fermer</button>
            </div>
            <nav className="mt-10 grid gap-x-12 gap-y-1 md:grid-cols-2">
              {liens.map((l, i) => (
                <motion.div key={l.href} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.03 * i, duration: 0.25 }}>
                  <Link ref={i === 0 ? premier : undefined} href={l.href} onClick={() => setOuvert(false)} className="display block border-b border-blanc/10 py-3 text-4xl text-blanc/40 transition-colors hover:text-blanc md:text-5xl">
                    {l.label}
                  </Link>
                </motion.div>
              ))}
            </nav>
            <div className="mt-10 flex flex-wrap gap-3 text-[0.8rem] font-900 uppercase tracking-[0.12em]">
              {connecte && espace ? (
                <Link href={espace} onClick={() => setOuvert(false)} className="bg-blanc px-5 py-3 text-ardoise">Mon espace</Link>
              ) : (
                <Link href="/connexion" onClick={() => setOuvert(false)} className="bg-rouge px-5 py-3">Se connecter</Link>
              )}
              <a href={liensOfficiels.boutique} target="_blank" rel="noopener noreferrer" className="border border-blanc/30 px-5 py-3 hover:border-blanc">Boutique ↗</a>
              <a href={liensOfficiels.billetterie} target="_blank" rel="noopener noreferrer" className="border border-blanc/30 px-5 py-3 hover:border-blanc">Billetterie ↗</a>
              <a href={liensOfficiels.site} target="_blank" rel="noopener noreferrer" className="border border-blanc/30 px-5 py-3 hover:border-blanc">Site officiel ↗</a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
