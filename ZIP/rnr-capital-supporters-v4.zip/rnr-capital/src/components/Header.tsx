import Link from "next/link";
import { campagne, liensOfficiels } from "@/config/campagne";
import { utilisateurCourant } from "@/lib/auth";
import { deconnexion } from "@/lib/actions";
import { MenuMobile } from "@/components/MenuMobile";
import { Logo } from "@/components/Logo";

export const navigation = [
  { href: "/projet", label: "Le projet" },
  { href: "/investir", label: "Investir" },
  { href: "/statuts", label: "Statuts" },
  { href: "/matchs", label: "Pronostics" },
  { href: "/classement", label: "Classement" },
  { href: "/lots", label: "Lots" },
  { href: "/actualites", label: "Actualités" },
  { href: "/faq", label: "FAQ" },
  { href: "/documents", label: "Documents" },
];

/**
 * En-tête calqué sur le site officiel : barre sombre, menu burger à gauche, marque centrée,
 * liens rapides Boutique / Billetterie à droite (Inter 900 capitales espacées).
 */
export async function Header() {
  const user = await utilisateurCourant();
  const espace = user ? (user.role === "admin" ? "/admin" : "/espace") : null;
  return (
    <header className="sticky top-0 z-40 bg-ardoise text-blanc">
      <div className="mx-auto grid max-w-7xl grid-cols-[auto_1fr_auto] items-center gap-4 px-4 py-3 sm:px-6">
        <MenuMobile liens={navigation} connecte={!!user} espace={espace} />
        <Link href="/" className="display flex items-center justify-center gap-3 text-2xl sm:justify-start">
          <Logo taille={44} avecTexte={false} />
          <span>{campagne.nom}</span>
          <span className="label ml-2 hidden rounded-sm border border-or/50 px-1.5 py-0.5 text-[0.6rem] text-or md:inline">non officiel</span>
        </Link>
        <nav aria-label="Liens rapides" className="flex items-center gap-5 text-[0.8rem] font-900 uppercase tracking-[0.1em]">
          <a href={liensOfficiels.boutique} target="_blank" rel="noopener noreferrer" className="hidden hover:text-rouge-vif md:inline">Boutique</a>
          <a href={liensOfficiels.billetterie} target="_blank" rel="noopener noreferrer" className="hidden border-l border-blanc/20 pl-5 hover:text-rouge-vif md:inline">Billetterie</a>
          {user ? (
            <>
              <Link href={espace!} className="hidden bg-blanc px-4 py-2 text-ardoise hover:bg-clair-2 lg:inline">{user.role === "admin" ? "Admin" : "Mon espace"}</Link>
              <form action={deconnexion} className="hidden lg:block"><button className="text-blanc/70 hover:text-blanc">Quitter</button></form>
            </>
          ) : (
            <Link href="/connexion" className="bg-rouge px-4 py-2 hover:bg-rouge-sombre">Connexion</Link>
          )}
        </nav>
      </div>
    </header>
  );
}
