/**
 * Visuel de fond du hero : par défaut la photo aérienne du stade Robert-Diochon (public/images/stade.jpg, © club,
 * usage en démonstration). Passer `photo={null}` pour revenir au stade stylisé en SVG.
 */
export function VisuelStade({ photo = "/images/stade.jpg", className = "" }: { photo?: string | null; className?: string }) {
  return (
    <div className={`grain absolute inset-0 overflow-hidden ${className}`} aria-hidden style={{ contain: "paint" }}>
      {photo ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={photo} alt="" className="h-full w-full object-cover object-center" style={{ opacity: 0.55 }} />
      ) : (
        <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" className="h-full w-full" style={{ display: "block" }}>
          <defs>
            <radialGradient id="lum" cx="50%" cy="0%" r="90%">
              <stop offset="0%" stopColor="oklch(36% 0.15 24)" stopOpacity="0.9" />
              <stop offset="55%" stopColor="oklch(19% 0.008 260)" stopOpacity="1" />
              <stop offset="100%" stopColor="oklch(12% 0.006 260)" />
            </radialGradient>
            <linearGradient id="faisceau" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="oklch(96% 0.01 80)" stopOpacity="0.16" />
              <stop offset="100%" stopColor="oklch(96% 0.01 80)" stopOpacity="0" />
            </linearGradient>
          </defs>
          <rect width="1600" height="900" fill="url(#lum)" />
          <g fill="url(#faisceau)">
            <polygon points="120,0 340,0 760,900 -120,900" />
            <polygon points="1260,0 1480,0 1720,900 840,900" />
          </g>
          <g stroke="oklch(96% 0.01 80)" strokeOpacity="0.28" strokeWidth="3" fill="none" transform="translate(0,120) skewX(-8)">
            <rect x="100" y="420" width="1500" height="520" />
            <line x1="850" y1="420" x2="850" y2="940" />
            <line x1="500" y1="420" x2="500" y2="940" strokeDasharray="14 18" />
            <line x1="1200" y1="420" x2="1200" y2="940" strokeDasharray="14 18" />
            <line x1="300" y1="420" x2="300" y2="940" strokeDasharray="6 26" />
            <line x1="1400" y1="420" x2="1400" y2="940" strokeDasharray="6 26" />
            <path d="M300 300 v120 M300 380 h60 M360 300 v120" strokeWidth="5" strokeOpacity="0.5" />
            <path d="M1400 300 v120 M1400 380 h60 M1460 300 v120" strokeWidth="5" strokeOpacity="0.5" />
          </g>
          <rect width="1600" height="900" fill="url(#lum)" opacity="0.35" />
        </svg>
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-noir via-noir/50 to-noir/30" />
    </div>
  );
}
