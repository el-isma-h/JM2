/**
 * Courbe cumulée de la collecte (SVG rendu côté serveur, sans bibliothèque).
 * Deux séries : capital confirmé, et confirmé + paiements reçus + intentions. Les montants restent étiquetés démo.
 */
import type { Souscription } from "@/lib/store";
import { euros } from "@/lib/souscription";

export function CourbeCollecte({ souscriptions, objectif, hauteur = 220 }: { souscriptions: Souscription[]; objectif: number; hauteur?: number }) {
  const tri = [...souscriptions].filter((s) => s.statut !== "annulee").sort((a, b) => Date.parse(a.creeLe) - Date.parse(b.creeLe));
  if (!tri.length) return <p className="text-sm text-gris">Aucune souscription enregistrée.</p>;
  const debut = Date.parse(tri[0].creeLe);
  const fin = Math.max(Date.now(), Date.parse(tri[tri.length - 1].creeLe));
  const etendue = Math.max(fin - debut, 86_400_000);
  const L = 640, H = hauteur, m = { h: 16, b: 28, g: 56, d: 12 };
  let cumulConf = 0, cumulTout = 0;
  const conf: [number, number][] = [[0, 0]];
  const tout: [number, number][] = [[0, 0]];
  for (const s of tri) {
    const x = (Date.parse(s.creeLe) - debut) / etendue;
    if (s.statut === "confirmee") cumulConf += s.montant;
    cumulTout += s.montant;
    conf.push([x, cumulConf]);
    tout.push([x, cumulTout]);
  }
  conf.push([1, cumulConf]);
  tout.push([1, cumulTout]);
  const max = Math.max(objectif, cumulTout) * 1.05;
  const px = (x: number) => m.g + x * (L - m.g - m.d);
  const py = (v: number) => H - m.b - (v / max) * (H - m.b - m.h);
  const chemin = (pts: [number, number][]) => pts.map(([x, v], i) => `${i ? "L" : "M"}${px(x).toFixed(1)},${py(v).toFixed(1)}`).join(" ");
  const graduations = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round((max * f) / 1000) * 1000);
  const dateFr = (t: number) => new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short", timeZone: "Europe/Paris" }).format(new Date(t));
  return (
    <figure>
      <svg viewBox={`0 0 ${L} ${H}`} className="w-full" role="img" aria-label={`Collecte cumulée : ${euros(cumulConf)} confirmés, ${euros(cumulTout)} au total, objectif ${euros(objectif)}`}>
        {graduations.map((g) => (
          <g key={g}>
            <line x1={m.g} x2={L - m.d} y1={py(g)} y2={py(g)} stroke="currentColor" strokeOpacity="0.12" />
            <text x={m.g - 6} y={py(g) + 4} textAnchor="end" fontSize="10" fill="currentColor" fillOpacity="0.6">{Math.round(g / 1000)} k€</text>
          </g>
        ))}
        <line x1={m.g} x2={L - m.d} y1={py(objectif)} y2={py(objectif)} stroke="oklch(78% 0.13 85)" strokeDasharray="6 5" />
        <text x={L - m.d} y={py(objectif) - 5} textAnchor="end" fontSize="10" fill="oklch(78% 0.13 85)">objectif (hypothèse)</text>
        <path d={chemin(tout)} fill="none" stroke="oklch(72% 0.16 70)" strokeWidth="2" strokeOpacity="0.8" />
        <path d={chemin(conf)} fill="none" stroke="oklch(60% 0.23 24)" strokeWidth="3" />
        <text x={m.g} y={H - 8} fontSize="10" fill="currentColor" fillOpacity="0.6">{dateFr(debut)}</text>
        <text x={L - m.d} y={H - 8} textAnchor="end" fontSize="10" fill="currentColor" fillOpacity="0.6">{dateFr(fin)}</text>
      </svg>
      <figcaption className="mt-1 flex flex-wrap gap-4 text-xs text-gris">
        <span><span className="mr-1 inline-block h-2 w-4 bg-rouge-vif align-middle" />capital confirmé {euros(cumulConf)}</span>
        <span><span className="mr-1 inline-block h-2 w-4 bg-ambre align-middle" />confirmé + paiements + intentions {euros(cumulTout)}</span>
        <span>données de démonstration</span>
      </figcaption>
    </figure>
  );
}
