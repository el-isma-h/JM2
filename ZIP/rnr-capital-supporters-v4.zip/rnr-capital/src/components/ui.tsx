import Link from "next/link";
import type { ReactNode, ComponentProps } from "react";

/** Section claire (défaut), « claire-2 » (gris très clair) ou « sombre » (noir sur photo, texte blanc). */
export function Section({ children, className = "", id, ton = "clair" }: { children: ReactNode; className?: string; id?: string; ton?: "clair" | "clair-2" | "sombre" }) {
  const fond = ton === "sombre" ? "section-sombre" : ton === "clair-2" ? "bg-clair-2" : "bg-blanc";
  return (
    <section id={id} className={`relative px-4 py-16 sm:px-6 md:py-24 ${fond} ${className}`}>
      <div className="relative z-10 mx-auto w-full max-w-6xl">{children}</div>
    </section>
  );
}

/** Titre de section : sur-titre en Barlow, titre Outfit italique, trait rouge vertical à droite comme sur le site officiel. */
export function Titre({ sur, children, className = "", as: Tag = "h2", lien }: { sur?: string; children: ReactNode; className?: string; as?: "h1" | "h2" | "h3"; lien?: { href: string; label: string } }) {
  return (
    <div className={`mb-8 flex flex-wrap items-end justify-between gap-4 ${className}`}>
      <div className="flex items-end gap-4">
        <div>
          {sur && <p className="label mb-2 text-xs text-rouge">{sur}</p>}
          <Tag className={Tag === "h1" ? "text-5xl sm:text-6xl md:text-7xl" : "text-4xl sm:text-5xl"}>{children}</Tag>
        </div>
        <span className="mb-1 hidden h-10 w-1 bg-rouge sm:block" aria-hidden />
      </div>
      {lien && <Link href={lien.href} className="lien-section inline-flex items-center gap-2 text-gris hover:text-rouge">{lien.label} <span aria-hidden>→</span></Link>}
    </div>
  );
}

type BoutonProps = { variante?: "plein" | "contour" | "clair" | "or" | "sombre"; href?: string; className?: string; children: ReactNode } & Omit<ComponentProps<"button">, "children">;

export function Bouton({ variante = "plein", href, className = "", children, ...rest }: BoutonProps) {
  const base = "inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm font-900 uppercase tracking-[0.15em] transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed";
  const styles = {
    plein: "bg-rouge text-blanc hover:bg-rouge-sombre",
    contour: "border-2 border-current text-ardoise hover:bg-ardoise hover:text-blanc",
    clair: "bg-blanc text-ardoise hover:bg-clair-2",
    or: "btn-or hover:brightness-105",
    sombre: "bg-ardoise text-blanc hover:bg-ardoise-2",
  }[variante];
  if (href) {
    const externe = href.startsWith("http");
    return externe ? (
      <a href={href} target="_blank" rel="noopener noreferrer" className={`${base} ${styles} ${className}`}>{children}</a>
    ) : (
      <Link href={href} className={`${base} ${styles} ${className}`}>{children}</Link>
    );
  }
  return <button className={`${base} ${styles} ${className}`} {...rest}>{children}</button>;
}

export type Teinte = "vert" | "ambre" | "gris" | "rouge" | "or";

export function Badge({ teinte = "gris", children }: { teinte?: Teinte; children: ReactNode }) {
  const t = {
    vert: "bg-vert/10 text-vert border-vert/30",
    ambre: "bg-ambre-clair/15 text-ambre border-ambre/30",
    gris: "bg-gris/10 text-gris border-gris/30",
    rouge: "bg-rouge/10 text-rouge border-rouge/30",
    or: "bg-or/20 text-or-sombre border-or-sombre/40",
  }[teinte];
  return <span className={`label inline-flex items-center rounded-sm border px-2 py-0.5 text-[0.68rem] ${t}`}>{children}</span>;
}

export function teinteEtat(etat: string): Teinte {
  if (etat === "confirme" || etat === "valide" || etat === "disponible") return "vert";
  if (etat === "negociation" || etat === "en_discussion" || etat === "a_valider") return "ambre";
  return "gris";
}

export function Encart({ titre, children, teinte = "rouge" }: { titre: string; children: ReactNode; teinte?: "rouge" | "ambre" | "gris" }) {
  const bord = { rouge: "border-rouge", ambre: "border-ambre-clair", gris: "border-gris-clair" }[teinte];
  return (
    <aside className={`rounded-r-2xl border-l-4 ${bord} bg-clair-2 px-5 py-4 text-sm text-ardoise-2`}>
      <p className="display mb-1 text-base text-ardoise">{titre}</p>
      <div className="space-y-1 leading-relaxed">{children}</div>
    </aside>
  );
}

export function Carte({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`carte p-6 ${className}`}>{children}</div>;
}

/** Grand chiffre : Outfit italique, label Barlow. */
export function Chiffre({ valeur, label, note, teinte = "ardoise" }: { valeur: string; label: string; note?: string; teinte?: "ardoise" | "rouge" | "blanc" | "vert" }) {
  const c = { ardoise: "text-ardoise", rouge: "text-rouge", blanc: "text-blanc", vert: "text-vert-clair" }[teinte];
  return (
    <div>
      <p className={`display text-4xl sm:text-5xl ${c}`}>{valeur}</p>
      <p className="label mt-1 text-xs text-gris">{label}</p>
      {note && <p className="mt-1 text-xs text-gris">{note}</p>}
    </div>
  );
}

export const dateFr = (iso: string, opts: Intl.DateTimeFormatOptions = { day: "numeric", month: "long", year: "numeric" }) =>
  new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris", ...opts }).format(new Date(iso));

export const dateHeureFr = (iso: string) =>
  new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris", weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(iso));
