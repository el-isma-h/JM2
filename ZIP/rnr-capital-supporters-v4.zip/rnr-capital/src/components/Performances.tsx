/**
 * Courbe des performances sportives du club sur la saison (SVG serveur, sans bibliothèque).
 * Trois lectures simples : la différence de points cumulée (ligne), le résultat de chaque journée (points verts /
 * gris), et les points marqués / concédés par match (barres). Source : résultats publiés par le club.
 */
import type { Match } from "@/data/matchs";
import { RNR } from "@/data/matchs";

export function statsSaison(joues: Match[]) {
  const lignes = joues.map((m) => {
    const dom = m.domicile === RNR;
    const pour = (dom ? m.scoreDomicile : m.scoreExterieur) ?? 0;
    const contre = (dom ? m.scoreExterieur : m.scoreDomicile) ?? 0;
    return { journee: m.journee, adversaire: dom ? m.exterieur : m.domicile, domicile: dom, pour, contre, diff: pour - contre, victoire: pour > contre, nul: pour === contre, date: m.coupDEnvoi };
  });
  let cumul = 0;
  const serie = lignes.map((l) => { cumul += l.diff; return { ...l, cumul }; });
  const victoires = serie.filter((l) => l.victoire).length;
  return { serie, victoires, defaites: serie.filter((l) => !l.victoire && !l.nul).length, nuls: serie.filter((l) => l.nul).length, pour: serie.reduce((n, l) => n + l.pour, 0), contre: serie.reduce((n, l) => n + l.contre, 0), diff: cumul };
}

export function Performances({ joues, sombre = true }: { joues: Match[]; sombre?: boolean }) {
  const { serie } = statsSaison(joues);
  if (!serie.length) return <p className="text-sm text-gris">Aucun match joué.</p>;
  const L = 680, H = 260, m = { h: 18, b: 44, g: 44, d: 16 };
  const n = serie.length;
  const px = (i: number) => m.g + ((i + 0.5) / n) * (L - m.g - m.d);
  const maxAbs = Math.max(20, ...serie.map((l) => Math.abs(l.cumul)));
  const py = (v: number) => m.h + ((maxAbs - v) / (2 * maxAbs)) * (H - m.h - m.b);
  const maxPts = Math.max(...serie.map((l) => Math.max(l.pour, l.contre)), 10);
  const hb = (v: number) => (v / maxPts) * 56; // hauteur max des barres de points
  const chemin = serie.map((l, i) => `${i ? "L" : "M"}${px(i).toFixed(1)},${py(l.cumul).toFixed(1)}`).join(" ");
  const aire = `${chemin} L${px(n - 1).toFixed(1)},${py(0).toFixed(1)} L${px(0).toFixed(1)},${py(0).toFixed(1)} Z`;
  const texte = sombre ? "rgba(255,255,255,0.7)" : "#64748b";
  const grille = sombre ? "rgba(255,255,255,0.1)" : "#e2e8f0";
  const largeurBarre = Math.min(14, (L - m.g - m.d) / n / 3);
  return (
    <figure>
      <svg viewBox={`0 0 ${L} ${H}`} className="w-full" role="img" aria-label={`Différence de points cumulée sur ${n} journées : ${serie[n - 1].cumul > 0 ? "+" : ""}${serie[n - 1].cumul}`}>
        <defs>
          <linearGradient id="aire-rouge" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#e21e26" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#e21e26" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[-maxAbs, -maxAbs / 2, 0, maxAbs / 2, maxAbs].map((g) => (
          <g key={g}>
            <line x1={m.g} x2={L - m.d} y1={py(g)} y2={py(g)} stroke={g === 0 ? texte : grille} strokeWidth={g === 0 ? 1.2 : 1} />
            <text x={m.g - 6} y={py(g) + 4} textAnchor="end" fontSize="10" fill={texte}>{g > 0 ? `+${Math.round(g)}` : Math.round(g)}</text>
          </g>
        ))}
        {/* barres points marqués (rouge) / concédés (gris) sous l'axe, pour chaque journée */}
        {serie.map((l, i) => (
          <g key={`b${i}`}>
            <rect x={px(i) - largeurBarre - 1} y={H - m.b - hb(l.pour)} width={largeurBarre} height={hb(l.pour)} fill="#e21e26" opacity="0.85" />
            <rect x={px(i) + 1} y={H - m.b - hb(l.contre)} width={largeurBarre} height={hb(l.contre)} fill={sombre ? "#94a3b8" : "#cbd5e1"} opacity="0.9" />
          </g>
        ))}
        <path d={aire} fill="url(#aire-rouge)" />
        <path d={chemin} fill="none" stroke="#e21e26" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
        {serie.map((l, i) => (
          <g key={`p${i}`}>
            <circle cx={px(i)} cy={py(l.cumul)} r="6" fill={l.victoire ? "#22c55e" : l.nul ? "#f59e0b" : "#334155"} stroke={sombre ? "#000" : "#fff"} strokeWidth="2">
              <title>{`J${l.journee} · ${l.domicile ? "vs" : "@"} ${l.adversaire} · ${l.pour}-${l.contre} · cumul ${l.cumul > 0 ? "+" : ""}${l.cumul}`}</title>
            </circle>
            <text x={px(i)} y={H - m.b + 14} textAnchor="middle" fontSize="10" fontWeight="700" fill={texte}>J{l.journee}</text>
            <text x={px(i)} y={H - m.b + 26} textAnchor="middle" fontSize="9" fill={texte}>{l.adversaire.length > 9 ? l.adversaire.slice(0, 8) + "." : l.adversaire}</text>
            <text x={px(i)} y={H - m.b + 38} textAnchor="middle" fontSize="9" fontWeight="900" fill={l.victoire ? "#22c55e" : texte}>{l.pour}-{l.contre}</text>
          </g>
        ))}
      </svg>
      <figcaption className={`mt-2 flex flex-wrap gap-x-5 gap-y-1 text-xs ${sombre ? "text-blanc/70" : "text-gris"}`}>
        <span><span className="mr-1 inline-block h-2.5 w-5 bg-rouge align-middle" />différence de points cumulée</span>
        <span><span className="mr-1 inline-block h-2.5 w-2.5 rounded-full bg-vert-clair align-middle" />victoire</span>
        <span><span className="mr-1 inline-block h-2.5 w-2.5 rounded-full bg-ardoise-2 align-middle ring-1 ring-blanc/40" />défaite</span>
        <span><span className="mr-1 inline-block h-2.5 w-3 bg-rouge align-middle" />points marqués · <span className="mx-1 inline-block h-2.5 w-3 bg-gris-clair align-middle" />points concédés</span>
      </figcaption>
    </figure>
  );
}
