"use client";

import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import type { ReactNode } from "react";

/**
 * Apparition discrète au défilement (Motion). Respecte « réduire les animations ».
 * Garde-fou : si l'élément n'est pas détecté visible sous 2,5 s (impression, capture pleine page,
 * navigateur sans IntersectionObserver), le contenu est affiché quand même.
 */
export function Apparition({ children, delai = 0, className = "" }: { children: ReactNode; delai?: number; className?: string }) {
  const reduit = useReducedMotion();
  const [force, setForce] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setForce(true), 2500);
    return () => clearTimeout(t);
  }, []);
  if (reduit) return <div className={`min-w-0 ${className}`}>{children}</div>;
  return (
    <motion.div
      className={`min-w-0 ${className}`}
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      animate={force ? { opacity: 1, y: 0 } : undefined}
      viewport={{ once: true, amount: 0.05 }}
      transition={{ duration: 0.5, delay: delai, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}
