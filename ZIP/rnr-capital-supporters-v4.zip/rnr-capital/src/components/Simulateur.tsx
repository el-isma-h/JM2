"use client";

import { useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "motion/react";
import { campagne } from "@/config/campagne";
import { simuler, euros } from "@/lib/souscription";
import { etatLabel, type Statut } from "@/data/statuts";
import { Badge, teinteEtat } from "@/components/ui";
import { FormulaireAction, champ, etiquette } from "@/components/FormulaireAction";
import { creerIntentionSouscription } from "@/lib/actions";

export function Simulateur({ connecte, statuts, stripeDemo, emailVerifie }: { connecte: boolean; statuts: Statut[]; stripeDemo: boolean; emailVerifie: boolean }) {
  const [actions, setActions] = useState(10);
  const sim = simuler(actions, statuts);
  const reduit = useReducedMotion();

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.2fr]">
      <div className="carte p-6">
        <p className="display text-2xl font-900">Nombre d&apos;actions envisagé</p>
        <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Paliers">
          {campagne.paliers.map((p) => (
            <button key={p} type="button" onClick={() => setActions(p)} aria-pressed={actions === p} className={`display px-4 py-2 text-lg font-900 transition-colors ${actions === p ? "bg-rouge text-blanc" : "border border-gris-clair text-ardoise-2 hover:border-ardoise"}`}>
              {p}
            </button>
          ))}
        </div>
        <label htmlFor="nb-actions" className={`${etiquette} mt-6`}>Ou un autre nombre ({campagne.minimumActions} à {campagne.maximumActionsParPersonne})</label>
        <input id="nb-actions" type="number" min={campagne.minimumActions} max={campagne.maximumActionsParPersonne} value={actions} onChange={(e) => setActions(Number(e.target.value) || campagne.minimumActions)} className={champ} />
        <input type="range" aria-label="Nombre d'actions" min={campagne.minimumActions} max={100} value={Math.min(actions, 100)} onChange={(e) => setActions(Number(e.target.value))} className="mt-4 w-full accent-[oklch(52%_0.21_24)]" />

        <dl className="mt-6 divide-y divide-gris-clair border-t border-gris-clair text-sm">
          <L k="Prix de souscription envisagé" v={`${euros(campagne.prixAction)} / action`} badge="hypothèse" />
          <L k="Montant investi" v={euros(sim.montantActions)} fort />
          <L k="Frais éventuels" v={sim.frais ? euros(sim.frais) : "À définir avec le prestataire"} />
          <L k="Total" v={euros(sim.total)} fort />
          <L k="Valeur nominale" v={campagne.valeurNominale ? euros(campagne.valeurNominale) : "Inconnue (capital non communiqué)"} />
          <L k="Pourcentage de détention" v={sim.pourcentageDetention !== null ? `${sim.pourcentageDetention} %` : "Non affiché : capital et dilution inconnus"} />
        </dl>
      </div>

      <div>
        <AnimatePresence mode="wait">
          <motion.div
            key={sim.statut?.id ?? "aucun"}
            initial={reduit ? false : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduit ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className={`rounded-2xl bg-gradient-to-br ${sim.statut?.couleur ?? "from-slate-600 to-slate-800"} p-6 text-blanc`}
          >
            <p className="label text-xs text-blanc/70">Statut associé</p>
            <p className="display text-4xl">{sim.statut?.nom ?? "Aucun"}</p>
            {sim.prochainStatut && (
              <p className="mt-2 text-sm text-blanc/80">Encore {sim.prochainStatut.actionsManquantes} action{sim.prochainStatut.actionsManquantes > 1 ? "s" : ""} pour {sim.prochainStatut.statut.nom}.</p>
            )}
          </motion.div>
        </AnimatePresence>

        <div className="mt-4 max-h-[26rem] overflow-y-auto border border-gris-clair">
          {sim.avantages.map(({ statut, avantages }) => (
            <div key={statut.id}>
              <p className="display sticky top-0 bg-clair-2 px-4 py-2 text-base font-900 tracking-wider">{statut.nom}</p>
              <ul className="divide-y divide-clair-2">
                {avantages.map((a) => (
                  <li key={a.id} className="flex items-start justify-between gap-3 px-4 py-2.5 text-sm">
                    <div>
                      <p>{a.titre}</p>
                      <p className="text-xs text-gris">{a.quantite} · {a.duree}{a.note ? ` · ${a.note}` : ""}</p>
                    </div>
                    <Badge teinte={teinteEtat(a.etat)}>{etatLabel[a.etat]}</Badge>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-6 border border-rouge/40 bg-clair-2 p-5">
          <p className="display text-xl font-900">Manifester une intention (démonstration)</p>
          <p className="mt-1 text-sm text-gris">Aucun encaissement, aucune émission de titres. En production, ce parcours est confié à un prestataire habilité : identification, documents, information sur les risques, signature électronique, paiement, confirmation.</p>
          {connecte ? (
            <FormulaireAction action={creerIntentionSouscription} libelle="Enregistrer mon intention">
              <input type="hidden" name="actions" value={sim.actions} />
              <label className="mt-4 flex items-start gap-2 text-sm">
                <input type="checkbox" name="risques" className="mt-1" required />
                <span>J&apos;ai lu les informations sur les risques : perte partielle ou totale, absence de liquidité, dilution, aucun dividende garanti.</span>
              </label>
              {stripeDemo && (
                <label className="mt-2 flex items-start gap-2 text-sm">
                  <input type="checkbox" name="payer" className="mt-1" defaultChecked={emailVerifie} disabled={!emailVerifie} />
                  <span>Continuer vers le <strong>paiement de démonstration</strong> (Stripe en mode test ou simulation : carte 4242 4242 4242 4242, aucun débit réel).{!emailVerifie && <span className="block text-xs text-ambre">Confirmez d&apos;abord votre adresse e-mail depuis votre espace.</span>}</span>
                </label>
              )}
            </FormulaireAction>
          ) : (
            <a href="/connexion?retour=/investir" className="display mt-4 inline-block bg-ardoise px-5 py-2.5 text-lg font-900 text-blanc hover:bg-ardoise-2">Créer un compte ou se connecter</a>
          )}
        </div>
      </div>
    </div>
  );
}

function L({ k, v, fort, badge }: { k: string; v: string; fort?: boolean; badge?: string }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5">
      <dt className="text-gris">{k} {badge && <Badge teinte="ambre">{badge}</Badge>}</dt>
      <dd className={fort ? "display text-2xl font-900" : "text-right"}>{v}</dd>
    </div>
  );
}
