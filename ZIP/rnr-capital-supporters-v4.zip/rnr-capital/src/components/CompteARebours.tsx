"use client";

import { useEffect, useState } from "react";

function calc(cible: string) {
  const diff = Math.max(0, Date.parse(cible) - Date.now());
  const j = Math.floor(diff / 86_400_000);
  const h = Math.floor((diff % 86_400_000) / 3_600_000);
  const m = Math.floor((diff % 3_600_000) / 60_000);
  return { j, h, m, passe: diff === 0 };
}

export function CompteARebours({ cible }: { cible: string }) {
  const [t, setT] = useState<ReturnType<typeof calc> | null>(null);
  useEffect(() => {
    setT(calc(cible));
    const id = setInterval(() => setT(calc(cible)), 30_000);
    return () => clearInterval(id);
  }, [cible]);
  if (!t) return <div className="h-14" aria-hidden />;
  if (t.passe) return <p className="text-sm text-blanc/60">Coup d&apos;envoi donné.</p>;
  return (
    <div className="flex gap-3" aria-label={`Coup d'envoi dans ${t.j} jours ${t.h} heures ${t.m} minutes`}>
      {[[t.j, "jours"], [t.h, "heures"], [t.m, "min"]].map(([v, l]) => (
        <div key={l as string} className="min-w-[4.5rem] rounded-lg border border-blanc/15 bg-blanc/5 px-3 py-2 text-center">
          <p className="display text-3xl not-italic">{String(v).padStart(2, "0")}</p>
          <p className="label text-[0.6rem] text-blanc/60">{l as string}</p>
        </div>
      ))}
    </div>
  );
}
