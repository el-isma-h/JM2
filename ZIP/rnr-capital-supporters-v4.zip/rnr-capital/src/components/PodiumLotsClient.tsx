"use client";

import { useState } from "react";
import dynamic from "next/dynamic";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { use3DAutorisee, Secours3D } from "@/components/3d/Securite3D";
import type { Lot } from "@/data/lots";
import { statutContractuelLabel } from "@/data/lots";

const PodiumLots = dynamic(() => import("@/components/3d/PodiumLots"), { ssr: false, loading: () => <div className="h-full w-full animate-pulse bg-noir-2" aria-hidden /> });

const IDS_3D = ["maillot", "ballon", "panier", "equipement"] as const;

/** Podium 3D des lots secondaires : clic sur un objet = fiche du lot. */
export function PodiumLotsClient({ lots }: { lots: Lot[] }) {
  const en3D = lots.filter((l) => (IDS_3D as readonly string[]).includes(l.id));
  const [selection, setSelection] = useState(en3D[0]?.id ?? "maillot");
  const ok = use3DAutorisee();
  const reduit = useReducedMotion();
  const lot = en3D.find((l) => l.id === selection) ?? en3D[0];
  const teinte = lot?.statut === "confirme" ? "text-vert" : lot?.statut === "en_discussion" ? "text-ambre" : "text-gris";
  return (
    <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
      <div className="relative h-[22rem] overflow-hidden rounded-2xl border border-gris-clair bg-noir sm:h-[28rem]">
        {ok === null && <div className="h-full w-full animate-pulse bg-noir-2" aria-hidden />}
        {ok === false && <Secours3D type="lots" titre="Lots envisagés" texte="Maillot, ballon, panier normand, équipement. Aucun lot n'est contractuellement sécurisé." className="h-full" />}
        {ok && <PodiumLots lots={en3D.map((l) => ({ id: l.id, titre: l.titre, rang: l.rang, etat: l.statut }))} selection={selection} onSelection={setSelection} className="h-full w-full" />}
        <p className="pointer-events-none absolute bottom-2 left-2 bg-noir/70 px-3 py-1 text-xs text-or">Objets 3D stylisés, non contractuels — lots envisagés</p>
      </div>
      <div>
        <div className="mb-3 flex flex-wrap gap-2" role="tablist" aria-label="Lots">
          {en3D.map((l) => (
            <button key={l.id} role="tab" aria-selected={selection === l.id} onClick={() => setSelection(l.id)} className={`display px-3 py-1.5 text-base font-900 uppercase tracking-wider ${selection === l.id ? "bg-rouge text-blanc" : "border border-gris-clair text-ardoise-2 hover:border-ardoise"}`}>
              {l.rang}
            </button>
          ))}
        </div>
        <AnimatePresence mode="wait">
          {lot && (
            <motion.div key={lot.id} initial={reduit ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={reduit ? undefined : { opacity: 0, y: -8 }} transition={{ duration: 0.2 }} className="carte p-5" role="tabpanel">
              <p className="display text-sm font-900 tracking-widest text-rouge">{lot.rang}</p>
              <p className="display text-3xl font-900">{lot.titre}</p>
              <p className="mt-2 text-sm text-ardoise-2">{lot.description}</p>
              <dl className="mt-4 grid grid-cols-2 gap-2 text-sm">
                <div><dt className="text-xs uppercase tracking-wider text-gris">Quantité</dt><dd>{lot.quantite || "À définir"}</dd></div>
                <div><dt className="text-xs uppercase tracking-wider text-gris">Valeur</dt><dd>{lot.valeurEstimee ? `${lot.valeurEstimee} €` : <span className="text-ambre">non documentée</span>}</dd></div>
                <div><dt className="text-xs uppercase tracking-wider text-gris">Fournisseur</dt><dd>{lot.fournisseur}</dd></div>
                <div><dt className="text-xs uppercase tracking-wider text-gris">Statut contractuel</dt><dd className={`font-900 ${teinte}`}>{statutContractuelLabel[lot.statut]}</dd></div>
                <div className="col-span-2"><dt className="text-xs uppercase tracking-wider text-gris">Remise</dt><dd>{lot.conditionsRemise}</dd></div>
              </dl>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
