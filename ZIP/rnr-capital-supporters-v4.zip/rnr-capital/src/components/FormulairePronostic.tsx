"use client";

import { useActionState, startTransition, type FormEvent } from "react";
import { enregistrerPronostic } from "@/lib/actions";
import type { Match } from "@/data/matchs";

export function FormulairePronostic({ match, initial, cloture, ouvert, connecte }: { match: Match; initial?: { d: number; e: number }; cloture: string; ouvert: boolean; connecte: boolean }) {
  const [etat, dispatch, enCours] = useActionState(enregistrerPronostic, null);
  const champ = "w-20 border border-gris-clair bg-blanc px-2 py-2 text-center display text-2xl text-ardoise focus:border-rouge disabled:opacity-50";
  const soumettre = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    startTransition(() => dispatch(data));
  };
  return (
    <form onSubmit={soumettre} className="mt-4 border-t border-gris-clair pt-4">
      <input type="hidden" name="matchId" value={match.id} />
      <div className="flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 text-sm">
          <span className="sr-only">Score {match.domicile}</span>
          <input name="scoreDomicile" type="number" inputMode="numeric" min={0} max={150} defaultValue={initial?.d ?? ""} required disabled={!ouvert || !connecte} className={champ} aria-label={`Score ${match.domicile}`} />
        </label>
        <span className="display text-xl text-gris">—</span>
        <label className="flex items-center gap-2 text-sm">
          <span className="sr-only">Score {match.exterieur}</span>
          <input name="scoreExterieur" type="number" inputMode="numeric" min={0} max={150} defaultValue={initial?.e ?? ""} required disabled={!ouvert || !connecte} className={champ} aria-label={`Score ${match.exterieur}`} />
        </label>
        {connecte ? (
          <button type="submit" disabled={!ouvert || enCours} className="bg-rouge px-5 py-2.5 text-xs font-900 uppercase tracking-[0.15em] text-blanc hover:bg-rouge-sombre disabled:cursor-not-allowed disabled:opacity-40">
            {enCours ? "Envoi…" : initial ? "Modifier" : "Valider"}
          </button>
        ) : (
          <a href="/connexion?retour=/matchs" className="bg-ardoise px-5 py-2.5 text-xs font-900 uppercase tracking-[0.15em] text-blanc hover:bg-ardoise-2">S&apos;inscrire gratuitement</a>
        )}
      </div>
      <p className="mt-2 text-xs text-gris">
        {ouvert ? `Modifiable jusqu'au ${cloture} (heure de Paris)` : "Pronostics clôturés"}
        {initial && ouvert ? " · votre pronostic est enregistré" : ""}
      </p>
      <p role="status" aria-live="polite" className={`text-sm ${etat ? (etat.ok ? "text-vert" : "text-rouge") : "sr-only"}`}>{etat ? (etat.ok ? etat.message : etat.erreur) : ""}</p>
    </form>
  );
}
