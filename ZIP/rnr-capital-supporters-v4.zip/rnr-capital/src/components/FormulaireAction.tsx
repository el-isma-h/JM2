"use client";

import { useActionState, startTransition, type FormEvent, type ReactNode } from "react";
import type { Resultat } from "@/lib/actions";

type Action = (prev: Resultat | null, form: FormData) => Promise<Resultat>;

/** Enveloppe un formulaire autour d'une action serveur, avec message de résultat accessible. */
export function FormulaireAction({ action, children, className = "", libelle, variante = "plein" }: { action: Action; children: ReactNode; className?: string; libelle: string; variante?: "plein" | "clair" | "contour" }) {
  const [etat, dispatch, enCours] = useActionState(action, null);
  const styles = {
    plein: "bg-rouge text-blanc hover:bg-rouge-sombre",
    clair: "bg-ardoise text-blanc hover:bg-ardoise-2",
    contour: "border-2 border-ardoise text-ardoise hover:bg-ardoise hover:text-blanc",
  }[variante];
  // Soumission manuelle : évite la réinitialisation automatique des champs par React après l'action (utile en cas d'erreur).
  const soumettre = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    startTransition(() => dispatch(data));
  };
  return (
    <form onSubmit={soumettre} className={className}>
      {children}
      <button type="submit" disabled={enCours} className={`mt-4 inline-flex items-center justify-center px-6 py-3 text-xs font-900 uppercase tracking-[0.15em] transition-colors disabled:opacity-50 ${styles}`}>
        {enCours ? "Envoi…" : libelle}
      </button>
      <p role="status" aria-live="polite" className={`mt-3 text-sm ${etat ? (etat.ok ? "text-vert" : "text-rouge") : "sr-only"}`}>
        {etat ? (etat.ok ? etat.message ?? "Enregistré" : etat.erreur) : ""}
      </p>
    </form>
  );
}

export const champ = "w-full border border-gris-clair bg-blanc px-3 py-2.5 text-ardoise placeholder:text-gris focus:border-rouge";
export const etiquette = "mb-1 block text-xs font-600 uppercase tracking-wider text-gris";
