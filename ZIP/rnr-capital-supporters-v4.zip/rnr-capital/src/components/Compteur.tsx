"use client";

import { useEffect, useRef } from "react";
import { animate, useInView, useReducedMotion } from "motion/react";

export function Compteur({ valeur, suffixe = "", prefixe = "", decimales = 0, className = "" }: { valeur: number; suffixe?: string; prefixe?: string; decimales?: number; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const visible = useInView(ref, { once: true, margin: "-40px" });
  const reduit = useReducedMotion();
  const fmt = (n: number) => new Intl.NumberFormat("fr-FR", { maximumFractionDigits: decimales, minimumFractionDigits: decimales }).format(n);

  useEffect(() => {
    if (!ref.current) return;
    if (!visible || reduit) {
      ref.current.textContent = `${prefixe}${fmt(valeur)}${suffixe}`;
      return;
    }
    const controls = animate(0, valeur, {
      duration: 1.4,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => {
        if (ref.current) ref.current.textContent = `${prefixe}${fmt(v)}${suffixe}`;
      },
    });
    return () => controls.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, valeur, reduit]);

  return <span ref={ref} className={className} aria-label={`${prefixe}${fmt(valeur)}${suffixe}`}>{prefixe}{fmt(valeur)}{suffixe}</span>;
}
