import Link from "next/link";
import { ArrowRight, GraduationCap } from "@phosphor-icons/react/dist/ssr";
import type { IaDossier } from "@/server/ia/enrollment";
import { IA_FUNDING_META, iaIntegrationConfigured } from "@/server/ia/enrollment";
import { openIaSpaceAction } from "@/server/actions/ia-inscription";
import { ActionForm } from "@/components/admin/action-form";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Panel, PanelHeader } from "@/components/ui/surface";
import { enrollmentStatusLabels } from "@/server/extranet/context";

/**
 * Bloc « Mes formations » de l'accueil apprenant (tableau de bord unique) : une ligne par formation, ici « Ma formation IA ».
 * Un clic sur « Ouvrir la formation » ouvre directement le parcours e-learning (connexion unique) ; le dossier reste accessible
 * par le lien « Mon dossier » (pièces, financement, contrat).
 */
export function IaLearnerCard({ d, userEmail }: { d: IaDossier; userEmail: string }) {
  const missingPieces = d.pieces.filter((p) => p.piece.isRequired && (p.submission.status === "attendue" || p.submission.status === "refusee"));
  const toSign = d.contract && !d.contract.signed && d.contract.request && ["envoyee", "signee_partiellement"].includes(d.contract.request.status) && d.contract.signers.some((s) => s.email.toLowerCase() === userEmail.toLowerCase() && !s.signedAt);
  const fundingLabel = d.iaFunding ? IA_FUNDING_META[d.iaFunding].label : d.funding?.label ?? "À définir";
  const canOpen = Boolean(d.enrollment.iaAccessOpenedAt) && iaIntegrationConfigured();
  const pending = toSign ? "Contrat à signer" : missingPieces.length ? `${missingPieces.length} pièce${missingPieces.length > 1 ? "s" : ""} à fournir` : null;
  return (
    <Panel>
      <PanelHeader title="Mes formations" description="Cliquez sur une formation pour l'ouvrir. Le dossier (pièces, financement, contrat) reste accessible à côté." />
      <div className="flex flex-col gap-5 p-5 md:flex-row md:items-center md:justify-between">
        <div className="flex min-w-0 gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center border border-accent bg-accent-bright/40 text-accent" aria-hidden="true">
            <GraduationCap size={24} />
          </div>
          <div className="min-w-0">
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent">Formation IA · NF-IA-150</p>
            <h3 className="mt-1 text-[20px]">Ma formation IA</h3>
            <p className="mt-1 text-[13.5px] text-ink-2">
              {d.offer?.label ?? d.enrollment.iaOffer} · {fundingLabel} · dossier {d.enrollment.reference}
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-[12.5px] text-ink-2">
              <StatusBadge status={d.enrollment.status} />
              <span>{enrollmentStatusLabels[d.enrollment.status] ?? d.enrollment.status}</span>
              {pending ? (
                <Link href={toSign ? "/formation-ia/inscription?etape=5" : "/moi/pieces"} className="font-medium text-accent hover:underline">
                  {pending}
                </Link>
              ) : null}
              <Link href="/moi/formation-ia" className="hover:underline">
                Mon dossier
              </Link>
            </div>
          </div>
        </div>
        <div className="shrink-0 md:min-w-[240px]">
          {canOpen ? (
            <ActionForm action={openIaSpaceAction} submitLabel="Ouvrir la formation" submitVariant="primary" submitSize="md" />
          ) : (
            <Button asChild variant="secondary">
              <Link href="/moi/formation-ia">
                {d.enrollment.iaAccessOpenedAt ? "Formation : configuration requise" : "Accès à la formation non ouvert"}
                <ArrowRight size={14} aria-hidden="true" />
              </Link>
            </Button>
          )}
        </div>
      </div>
    </Panel>
  );
}
