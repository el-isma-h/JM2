---
id: L047
module: M11
level: N2
title: "Embeddings et recherche sémantique"
minutes: 55
objectives:
  - "Expliquer avec un schéma à deux dimensions ce qu'est un embedding et pourquoi deux textes proches par le sens ont des vecteurs proches"
  - "Distinguer recherche par mots-clés et recherche sémantique, et choisir laquelle convient à un besoin métier"
  - "Décrire les quatre temps d'un RAG (découper, vectoriser, chercher, générer) et le rôle d'une base vectorielle"
  - "Identifier les principaux fournisseurs de modèles d'embeddings (OpenAI, Google, Mistral, Perplexity, modèles ouverts via Ollama) et leurs critères de choix"
skills: ["C2.2"]
sources:
  - { title: "Lewis et al. (2020) — Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks", url: "https://arxiv.org/pdf/2005.11401", lang: "en" }
  - { title: "n8n Docs — Store and search data with vectors", url: "https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md", lang: "en" }
  - { title: "OpenAI — Guide Embeddings", url: "https://developers.openai.com/api/docs/guides/embeddings", lang: "en" }
  - { title: "Google Gemini API — Embeddings", url: "https://ai.google.dev/gemini-api/docs/embeddings", lang: "en" }
  - { title: "Mistral AI — Mistral Embed", url: "https://docs.mistral.ai/models/mistral-embed-23-12", lang: "en" }
  - { title: "Perplexity — Embeddings quickstart", url: "https://docs.perplexity.ai/docs/embeddings/quickstart.md", lang: "en" }
  - { title: "Ollama — Documentation (catégorie embeddings)", url: "https://docs.ollama.com", lang: "en" }
  - { title: "Comparatif des bases vectorielles 2026 (BigData Boutique)", url: "https://bigdataboutique.com/blog/vector-database-comparison-2026", lang: "en" }
---

# Embeddings et recherche sémantique

> ⏱ 55 min · 🎯 Niveau 2 · 📚 Module 11

## 🎯 Ce que vous saurez faire
- Expliquer à un collègue, sans une ligne de mathématiques, pourquoi une machine peut « sentir » que « congés payés » et « vacances » parlent de la même chose.
- Lire un schéma d'embeddings en deux dimensions et calculer à la main une similarité simple.
- Reconnaître les situations où la recherche par mots-clés suffit, et celles où il faut passer au sémantique.
- Dessiner les quatre temps d'un RAG et nommer la brique responsable de chaque temps.
- Choisir un fournisseur d'embeddings selon trois critères : confidentialité, qualité en français, coût.

> 🧭 **En clair** — Imaginez une bibliothèque où les livres ne sont pas rangés par ordre alphabétique, mais **par sujet** : tous les livres qui parlent de vacances sont dans le même rayon, même si l'un dit « congés » et l'autre « jours de repos ». Un *embedding*, c'est l'étiquette qui indique à quel endroit précis de cette bibliothèque ranger un texte. Pour répondre à une question, on calcule l'emplacement de la question, puis on va chercher les livres posés juste à côté : c'est la **recherche sémantique**, la recherche par le sens. Le RAG ajoute un dernier geste : un bibliothécaire (le modèle de langage) lit ces quelques livres et vous rédige la réponse, en citant ses sources.

## 1. Le problème de départ : le moteur de recherche qui ne comprend rien

Imaginez le service RH d'une PME de 80 personnes. Sa base documentaire contient le règlement intérieur, l'accord d'entreprise sur le télétravail, 40 fiches « questions fréquentes » et la convention collective. Une salariée tape dans l'intranet : « puis-je poser des jours quand mon enfant est malade ? ». Résultat : zéro document. Pourquoi ? Parce que la fiche concernée s'intitule « Absence pour enfant malade : modalités » et parle de « jours d'absence autorisés », pas de « poser des jours ».

C'est la limite de la **recherche par mots-clés** (dite *lexicale*) : elle compare des **chaînes de caractères**, pas des **idées**. Elle est excellente quand on connaît le mot exact (« article L3141-1 », « référence FAC-2026-0412 »), désastreuse quand on formule autrement que l'auteur du document. Or vos collègues, vos clients et vos fournisseurs formulent toujours autrement.

La **recherche sémantique** inverse la logique : au lieu de comparer des mots, elle compare des **sens**. Pour cela, il faut d'abord transformer chaque texte en quelque chose que l'ordinateur peut comparer numériquement. C'est le rôle des *embeddings*.

> 💡 **À retenir** — Mots-clés = « contient-il exactement ce mot ? ». Sémantique = « parle-t-il de la même chose ? ». Les deux approches sont complémentaires, et les meilleurs systèmes (dits *hybrides*) utilisent les deux.

```quiz
{
  "type": "mise_en_situation",
  "q": "Un commercial cherche « la facture FAC-2026-0412 » dans l'intranet. Quel type de recherche est le plus fiable ?",
  "options": [
    "La recherche sémantique seule",
    "Aucune recherche, il faut demander au modèle de langage",
    "La recherche par mots-clés (lexicale)",
    "Une recherche par image"
  ],
  "answer": 2,
  "explanation": "Une référence exacte est le terrain idéal de la recherche par mots-clés. La recherche sémantique brille quand la formulation diffère de celle du document, pas pour retrouver un code précis."
}
```


## 2. Un embedding, c'est une adresse dans un espace de sens

### 2.1 L'exemple à deux dimensions

Oublions un instant les ordinateurs. Prenons une feuille quadrillée avec deux axes :
- l'axe horizontal mesure « à quel point le texte parle de **temps de travail / absence** » (0 = pas du tout, 10 = complètement) ;
- l'axe vertical mesure « à quel point le texte parle d'**argent / rémunération** ».

Plaçons quelques phrases :

```
   Argent / rémunération
   10 │
      │        ● "Prime de fin d'année : versement en décembre"  (2, 9)
    8 │
      │                     ● "Indemnité de congés payés"        (6, 7)
    6 │
      │
    4 │
      │
    2 │  ● "Absence pour enfant malade"  (9, 1)
      │  ● "Poser des jours de vacances" (9, 2)
    0 └──────────────────────────────────────────► Temps de travail / absence
      0     2     4     6     8     10
```

Chaque phrase est devenue un **couple de nombres** : ses coordonnées. « Absence pour enfant malade » est en (9, 1) ; « Poser des jours de vacances » en (9, 2). Elles sont **voisines** sur la feuille, alors qu'elles n'ont **aucun mot en commun**. À l'inverse, « Prime de fin d'année » en (2, 9) est loin des deux. Voilà, en miniature, un embedding : **un texte transformé en coordonnées, telles que les textes de sens proche aient des coordonnées proches**.

### 2.2 Dans la vraie vie : 768, 1 024 ou 1 536 axes

Deux axes ne suffisent évidemment pas à décrire toutes les nuances du langage. Les modèles d'embeddings réels utilisent **plusieurs centaines ou milliers de dimensions** : 768 pour beaucoup de modèles ouverts, 1 024 pour `mistral-embed`, 1 536 pour `text-embedding-3-small` d'OpenAI (nov. 2026, voir les fiches des fournisseurs ci-dessous). Personne ne sait nommer l'axe n° 437 (« parle-t-il de bureaucratie administrative teintée d'urgence ? »), et ce n'est pas grave : ces axes ont été **appris automatiquement** par un réseau de neurones entraîné sur des milliards de phrases, avec une seule consigne : *rapprocher les textes qui apparaissent dans des contextes similaires*.

Le principe reste exactement celui de la feuille quadrillée. On a juste beaucoup plus d'axes, et un ordinateur pour calculer les distances.

> 💡 **Autrement dit** — Un embedding de 1 024 dimensions, c'est comme une adresse postale avec 1 024 lignes au lieu de quatre (pays, ville, rue, numéro). Personne ne lit ces lignes une par une ; ce qui compte, c'est que deux textes au sens proche habitent dans le même quartier.


> 🎮 **Défi** — Sur la feuille ci-dessus, où placeriez-vous « Remboursement des frais de transport » ? (Réponse : fort sur l'axe argent, faible sur l'axe absence, par exemple (3, 8) ; elle sera donc voisine de la prime, pas des congés.)

### 2.3 Mesurer la proximité : la similarité cosinus

Comment décider que (9, 1) et (9, 2) sont « proches » ? Deux mesures existent :
- la **distance euclidienne**, c'est-à-dire la longueur du trait qui relie les deux points, comme sur une carte ;
- la **similarité cosinus**, qui compare la **direction** des deux flèches partant de l'origine, indépendamment de leur longueur. Elle vaut 1 quand les flèches pointent dans la même direction, 0 quand elles sont perpendiculaires (aucun rapport), −1 quand elles sont opposées.

En pratique, les bases vectorielles utilisent le cosinus par défaut : un texte long et un texte court sur le même sujet pointent dans la même direction, même si leurs flèches n'ont pas la même longueur. Dans notre exemple, « Absence pour enfant malade » (9, 1) et « Poser des jours de vacances » (9, 2) ont une similarité cosinus d'environ **0,99** ; avec « Prime de fin d'année » (2, 9), elle tombe à environ **0,32**.

Pour celles et ceux qui veulent voir le calcul, voici dix lignes de Python sans aucune bibliothèque externe (vous pouvez les coller dans n'importe quel interpréteur Python 3.12) :

```python
# Similarité cosinus entre deux textes représentés par leurs coordonnées 2D
import math

def cosinus(a: list[float], b: list[float]) -> float:
    """Renvoie la similarité cosinus entre deux vecteurs de même taille."""
    produit_scalaire = sum(x * y for x, y in zip(a, b))
    norme_a = math.sqrt(sum(x * x for x in a))
    norme_b = math.sqrt(sum(y * y for y in b))
    return produit_scalaire / (norme_a * norme_b)

enfant_malade = [9, 1]
vacances      = [9, 2]
prime         = [2, 9]

print(f"enfant malade ~ vacances : {cosinus(enfant_malade, vacances):.2f}")  # ≈ 0.99
print(f"enfant malade ~ prime    : {cosinus(enfant_malade, prime):.2f}")     # ≈ 0.32
```

Vous n'aurez jamais à écrire ce calcul vous-même : n8n, Dify, Flowise ou NotebookLM le font pour vous. Mais savoir qu'il existe vous évitera de croire à la magie, et vous aidera à comprendre les scores de « pertinence » affichés par ces outils.

```quiz
{
  "q": "Deux textes ont une similarité cosinus de 0,98. Qu'en concluez-vous ?",
  "options": [
    "Ils parlent de sujets opposés",
    "Ils n'ont aucun rapport",
    "Ils contiennent forcément les mêmes mots",
    "Ils sont très proches par le sens"
  ],
  "answer": 3,
  "explanation": "Un cosinus proche de 1 signifie que les deux flèches pointent dans la même direction : les textes parlent de la même chose, même sans mot commun. 0 = aucun rapport, −1 = opposés."
}
```

## 3. De la recherche sémantique au RAG

Trouver le bon document, c'est bien. Obtenir une **réponse rédigée, sourcée, dans la langue de la question**, c'est mieux. C'est l'idée du **RAG** (*Retrieval-Augmented Generation*, « génération augmentée par la récupération »), formalisée en 2020 par Patrick Lewis et ses collègues de Facebook AI Research : on **récupère** d'abord les passages pertinents, puis on les **injecte dans le prompt** d'un modèle de langage qui **génère** la réponse à partir d'eux.

Les quatre temps, et ce qu'ils signifient pour vous :

```
  PRÉPARATION (une fois, puis à chaque mise à jour des documents)
  ┌─────────────┐    ┌──────────────┐    ┌────────────────┐    ┌─────────────────┐
  │ 1. DÉCOUPER │ ─► │ 2. VECTORISER│ ─► │ stocker dans la│    │                 │
  │ en morceaux │    │ (embeddings) │    │ BASE VECTORIELLE│   │                 │
  └─────────────┘    └──────────────┘    └───────┬────────┘    │                 │
                                                 │             │                 │
  À CHAQUE QUESTION                              ▼             │                 │
  question ─► vectoriser ─► 3. CHERCHER les k morceaux ───────►│ 4. GÉNÉRER la   │─► réponse
              la question      les plus proches                │ réponse (LLM)   │   + sources
                                                               └─────────────────┘
```

| Temps | Question à vous poser | Brique logicielle |
|---|---|---|
| 1. Découper (*chunking*) | Quelle taille de morceau garde une idée complète ? (leçon 49) | *Text splitter* |
| 2. Vectoriser | Quel modèle d'embeddings, où tournent les données ? | Modèle d'embeddings (OpenAI, Gemini, Mistral, Ollama…) |
| 3. Chercher | Combien de passages (k) renvoyer ? Avec quels filtres ? | Base vectorielle (pgvector, Qdrant, Chroma, Pinecone…) |
| 4. Générer | Quel modèle rédige, avec quelles consignes de citation ? | LLM (Claude, GPT, Gemini, Mistral, modèle local) |

Le point qui surprend souvent : **le modèle de langage ne « lit » jamais toute votre base**. Il ne voit que les quelques morceaux (typiquement 3 à 8) que la recherche a sélectionnés. Si la recherche rate le bon morceau, la meilleure IA du monde répondra à côté, ou inventera. C'est pourquoi ce module consacre une leçon entière (L049) à la qualité de la recherche.

> ⚠️ **Piège fréquent** — Croire que « plus de contexte = meilleure réponse » et renvoyer 30 passages. Le modèle se noie, le coût explose, et les passages hors sujet dégradent la réponse. Commencez à k = 4 ou 5, mesurez, ajustez.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : dans un RAG, le modèle de langage ne voit que les quelques passages sélectionnés par la recherche, pas toute votre base documentaire.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai : il ne voit que les quelques morceaux (souvent 3 à 8) sélectionnés par la recherche. Si la recherche rate le bon passage, la réponse sera fausse ou inventée."
}
```


## 4. La base vectorielle : un index, pas un coffre-fort

Une **base vectorielle** (*vector database*) stocke trois choses pour chaque morceau : son **vecteur** (les coordonnées), son **texte** d'origine et ses **métadonnées** (titre du document, date, service, URL…). Sa spécialité : retrouver en quelques millisecondes, parmi des millions de vecteurs, les k plus proches d'un vecteur donné.

État du marché (nov. 2026, d'après le comparatif BigData Boutique cité en source) :

| Base | Nature | Licence | Quand la choisir |
|---|---|---|---|
| **pgvector** | Extension de PostgreSQL | PostgreSQL License | Vous avez déjà Postgres (c'est le cas avec n8n auto-hébergé, Supabase…) ; le point de départ recommandé |
| **Chroma** | Base embarquée Python/JS | Apache 2.0 | Prototype, atelier, démonstration sur un portable |
| **Qdrant** | Moteur dédié (Rust) | Apache 2.0 | Production auto-hébergée, filtres riches, recherche hybride |
| **Weaviate** | Moteur dédié (Go) | BSD-3 | Production, recherche hybride native |
| **Milvus** | Moteur distribué | Apache 2.0 | Très grande échelle (centaines de millions de vecteurs) |
| **Pinecone** | Service managé propriétaire | Propriétaire | Vous ne voulez rien administrer et acceptez le cloud uniquement |

La recommandation pédagogique de ce programme : **pgvector pour commencer → Chroma pour expérimenter → Qdrant pour la production**. Dans les outils sans code de la leçon 48, vous n'aurez souvent même pas à choisir : n8n propose un *Simple Vector Store* en mémoire pour prototyper, Dify embarque sa propre base, NotebookLM cache tout.

> 🔗 **Documentation officielle** — [n8n — Store and search data with vectors](https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md) 🇬🇧 décrit, avec les mots de l'outil, le trio *embeddings* → *vector store* → *retriever*.

```mission
{
  "title": "Les trois briques d'un RAG selon la documentation n8n",
  "url": "https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md",
  "steps": ["Ouvrez la page « Store and search data with vectors » de la documentation n8n", "Repérez les composants nécessaires pour stocker puis retrouver des données", "Notez le nom du magasin de vecteurs prévu pour prototyper sans rien installer"],
  "question": "Quelles briques n8n faut-il assembler pour stocker et retrouver des documents par le sens, et quel vector store permet de prototyper en mémoire ?",
  "hint": "Le vector store de prototypage porte un nom qui veut dire « simple ».",
  "answer": "Un modèle d'embeddings, un vector store (base vectorielle) et un retriever (récupérateur) ; pour prototyper, le Simple Vector Store en mémoire (les vector stores Pinecone, Qdrant, PGVector… servent en production) — relevé nov. 2026.",
  "xp": 15
}
```


## 5. Choisir son modèle d'embeddings

Trois critères, dans cet ordre pour une PME française :

1. **Où partent les données ?** Un embedding est calculé à partir de votre texte : si vous utilisez une API cloud, vos documents transitent chez le fournisseur. Pour des données sensibles (RH, santé, secrets d'affaires), un modèle d'embeddings **local** via Ollama (catégorie *embeddings* du catalogue) garde tout sur votre machine. Vous l'avez vu au module 10 ; nous y reviendrons à la leçon 50.
2. **Qualité en français.** Tous les grands modèles sont multilingues, mais l'écart se voit sur les textes juridiques ou techniques. Mistral (éditeur parisien) est un bon réflexe ; testez toujours sur **vos** documents (leçon 49).
3. **Coût.** Les embeddings sont très bon marché comparés à la génération : Perplexity affiche par exemple `pplx-embed-v1-0.6b` à 0,004 $ par million de tokens et Mistral `mistral-embed` à 0,10 $ par million (nov. 2026, pages tarifaires des éditeurs). Un classeur de 500 pages (~250 000 tokens) se vectorise pour quelques centimes.

| Fournisseur | Modèle (nov. 2026) | Dimensions | Remarque |
|---|---|---|---|
| OpenAI | `text-embedding-3-small` / `-large` | 1 536 / 3 072 | Référence historique ; le guide officiel détaille les cas d'usage (recherche, clustering, recommandation). Attention : les embeddings ne figurent plus sur la page de tarifs lue le 1er nov. 2026, vérifiez le prix en vigueur |
| Google | `gemini-embedding-2` (multimodal), `gemini-embedding-001` | variable | Peut vectoriser texte et images |
| Mistral | `mistral-embed`, `codestral-embed` (code) | 1 024 | Européen, bon en français, 0,10 $/M tokens |
| Perplexity | `pplx-embed-v1-0.6b` / `-4b`, variantes `context` | n.p. | Les variantes *context* tiennent compte du document entier |
| Modèles ouverts (Ollama, Hugging Face) | `nomic-embed-text` et autres modèles de la catégorie *embeddings* | 768 et plus | Gratuit, local, confidentialité maximale |
| Anthropic | — | — | **Ne propose pas de modèle d'embeddings** : un RAG « avec Claude » utilise Claude pour la génération et un autre fournisseur pour les vecteurs |

> ⚠️ **Piège fréquent** — Vectoriser vos documents avec un modèle, puis vectoriser les questions avec un autre : les coordonnées ne sont pas dans le même « espace », les résultats deviennent aléatoires. **Un seul modèle d'embeddings par base**, noté dans la documentation du projet ; changer de modèle impose de tout re-vectoriser.

```mission
{
  "title": "Fiche technique de Mistral Embed",
  "url": "https://docs.mistral.ai/models/mistral-embed-23-12",
  "steps": ["Ouvrez la fiche du modèle mistral-embed dans la documentation Mistral", "Repérez le nombre de dimensions des vecteurs produits", "Cherchez le prix par million de tokens (sur la fiche ou la page de tarifs liée)"],
  "question": "Combien de dimensions produit mistral-embed et combien coûte la vectorisation d'un million de tokens ?",
  "hint": "Le nombre de dimensions est une puissance de 2.",
  "answer": "1 024 dimensions ; 0,10 $ par million de tokens (relevé nov. 2026 — vérifiez la page de tarifs Mistral, les prix évoluent).",
  "xp": 10
}
```


## 6. Quand le sémantique ne suffit pas : la recherche hybride

Revenons à la salariée du début. Si elle tape « article 12 de l'accord télétravail », la recherche sémantique peut lui proposer des passages qui *parlent* de télétravail sans être l'article 12 : les nombres et les références exactes sont le point faible des embeddings. C'est pourquoi les systèmes sérieux combinent **recherche lexicale** (algorithme BM25, le descendant moderne des moteurs plein texte) et **recherche vectorielle**, puis fusionnent les deux classements. Qdrant, Weaviate et pgvector (via la recherche plein texte de PostgreSQL) le permettent ; Dify propose l'option « hybride » dans ses réglages de base de connaissances. Le cours « Building with the Claude API » de Claude Academy consacre d'ailleurs une leçon à BM25 et une autre au *reranking* (reclassement des résultats par un second modèle), deux techniques que vous retrouverez au niveau 3.

> 💡 **À retenir** — Sémantique pour le sens, lexical pour l'exactitude (références, noms propres, codes). Hybride quand vous pouvez.

## 🧪 Exercice pratique

**Consigne.** Vous êtes responsable qualité dans un cabinet d'expertise comptable de 25 personnes. Trois types de recherches reviennent chaque jour : (a) « quel est le taux de TVA applicable à la vente de livres numériques ? », (b) « retrouve la lettre de mission du client DURAND SAS », (c) « comment on traite un client qui veut passer de l'IS à l'IR ? ».

1. Pour chaque recherche, indiquez si une recherche par mots-clés suffit, si le sémantique est nécessaire, ou s'il faut de l'hybride. Justifiez en une phrase.
2. Sur une feuille, dessinez deux axes de votre choix pertinents pour un cabinet comptable (par exemple « fiscalité » et « relation client ») et placez six titres de documents réels ou plausibles de votre cabinet. Entourez les paires qui seraient « voisines » pour un embedding.
3. Choisissez un fournisseur d'embeddings pour ce cabinet et défendez votre choix avec les trois critères de la section 5.

**Critères de réussite.**
- Les trois recherches sont classées avec une justification cohérente (la (b) repose sur un nom propre exact : lexical ou hybride ; la (c) est formulée librement : sémantique ; la (a) mêle un concept et un terme exact : hybride).
- Le schéma comporte au moins deux paires de documents sans mot commun mais proches par le sens.
- Le choix du fournisseur mentionne explicitement la confidentialité des données clients (secret professionnel de l'expert-comptable) et débouche soit sur un fournisseur européen, soit sur un modèle local.

<details>
<summary>Pistes de corrigé</summary>

- (a) Hybride : « TVA » et « livres numériques » sont des termes précis, mais la fiche interne peut parler de « taux réduit » et de « publications électroniques ». (b) Lexical : « DURAND SAS » doit être trouvé exactement ; un embedding pourrait rapprocher « DURAND » de « DURAN » ou renvoyer d'autres lettres de mission. (c) Sémantique : la question est une reformulation libre ; le document s'intitule sans doute « Option pour l'impôt sur le revenu : procédure ».
- Fournisseur : `mistral-embed` (hébergement européen possible, bon en français) ou un modèle ouvert via Ollama sur le serveur du cabinet ; OpenAI est acceptable si un accord de traitement des données est signé, mais mérite une analyse RGPD (fiches pratiques IA de la CNIL).
</details>

## ✅ Auto-évaluation express

1. Deux phrases sans aucun mot commun peuvent-elles avoir des embeddings très proches ? Pourquoi ?
2. Dans un RAG, qui « lit » l'ensemble de la base documentaire : le modèle de langage ou la base vectorielle ?
3. Que se passe-t-il si vous vectorisez les documents avec `mistral-embed` et les questions avec `text-embedding-3-small` ?

<details>
<summary>Réponses</summary>

1. Oui : l'embedding encode le **sens** appris à partir des contextes d'usage, pas les mots. « Poser des jours » et « absence autorisée » sont voisins.
2. Aucun des deux ne « lit » tout à chaque question : la base vectorielle **compare des coordonnées** et renvoie les k morceaux les plus proches ; le modèle ne voit que ces morceaux.
3. Les deux modèles produisent des coordonnées dans des espaces différents (et de dimensions différentes, 1 024 contre 1 536) : soit une erreur technique, soit des résultats sans rapport. Un seul modèle par base.
</details>

## 📚 Pour aller plus loin

- [Lewis et al., 2020 — Retrieval-Augmented Generation](https://arxiv.org/pdf/2005.11401) 🇬🇧 — l'article fondateur du RAG ; lisez au moins le résumé et la figure 1.
- [OpenAI — Embeddings guide](https://developers.openai.com/api/docs/guides/embeddings) 🇬🇧 — cas d'usage (recherche, clustering, recommandation) et bonnes pratiques.
- [Google Gemini API — Embeddings](https://ai.google.dev/gemini-api/docs/embeddings) 🇬🇧 — embeddings texte et multimodaux.
- [Mistral — Mistral Embed](https://docs.mistral.ai/models/mistral-embed-23-12) 🇬🇧 — fiche du modèle européen de référence.
- [Perplexity — Embeddings quickstart](https://docs.perplexity.ai/docs/embeddings/quickstart.md) 🇬🇧 — exemple des variantes « context ».
- [Ollama — Documentation](https://docs.ollama.com) 🇬🇧 — pour trouver et lancer un modèle d'embeddings local.
- [Comparatif des bases vectorielles 2026](https://bigdataboutique.com/blog/vector-database-comparison-2026) 🇬🇧 — Qdrant, Weaviate, Pinecone, Milvus : déploiement et licences.

> 🗺️ **Et maintenant ?** — Vous comprenez comment une machine retrouve un texte par le sens ; la leçon L048 vous fait construire votre premier assistant documentaire, sans écrire de code, avec n8n, Dify, Flowise ou NotebookLM.
