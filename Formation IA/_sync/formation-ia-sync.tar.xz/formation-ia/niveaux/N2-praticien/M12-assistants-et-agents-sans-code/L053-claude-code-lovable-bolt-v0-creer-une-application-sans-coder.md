---
id: L053
module: M12
level: N2
title: "Claude Code, Lovable, Bolt, v0 : créer une application sans coder"
minutes: 65
objectives:
  - "Expliquer ce qu'est le « vibe coding », ses promesses et ses limites (revue, tests, sécurité)"
  - "Construire une petite application web (calculateur de devis) avec Claude Code, à partir d'un cahier des charges rédigé en français"
  - "Construire la même application avec un générateur d'applications en ligne (Lovable, Bolt, v0) et comparer les deux approches"
  - "Évaluer les pièges de sécurité, de coût et d'hébergement avant de mettre une application générée en production"
skills: ["C2.2", "C1.5"]
sources:
  - { title: "Claude Code — Overview et installation", url: "https://code.claude.com/docs", lang: "en" }
  - { title: "Claude Code — Quickstart", url: "https://code.claude.com/docs/en/quickstart.md", lang: "en" }
  - { title: "Claude Code — Memory (CLAUDE.md)", url: "https://code.claude.com/docs/en/memory.md", lang: "en" }
  - { title: "Claude Code — Permissions", url: "https://code.claude.com/docs/en/permissions.md", lang: "en" }
  - { title: "Claude Code — Costs", url: "https://code.claude.com/docs/en/costs.md", lang: "en" }
  - { title: "Claude Code — Best practices", url: "https://code.claude.com/docs/en/best-practices.md", lang: "en" }
  - { title: "Claude Academy — Claude Code 101", url: "https://academy.claude.com/courses/claude-code-101", lang: "en" }
  - { title: "Claude Academy — Claude Code in action", url: "https://academy.claude.com/courses/claude-code-in-action", lang: "en" }
  - { title: "OpenAI Codex (GitHub)", url: "https://github.com/openai/codex", lang: "en" }
  - { title: "Gemini CLI (GitHub)", url: "https://github.com/google-gemini/gemini-cli", lang: "en" }
  - { title: "Collins Dictionary — « vibe coding » mot de l'année 2025 (CTV News)", url: "https://www.ctvnews.ca/lifestyle/article/vibe-coding-named-word-of-the-year-by-collins-dictionary/", lang: "en" }
  - { title: "OWASP Top 10 for LLM Applications (synthèse Modulos)", url: "https://docs.modulos.ai/frameworks/owasp-top-10-llm/index", lang: "en" }
---

# Claude Code, Lovable, Bolt, v0 : créer une application sans coder

> ⏱ 65 min · 🎯 Niveau 2 · 📚 Module 12

## 🎯 Ce que vous saurez faire
- Décrire une application en français de manière assez précise pour qu'un agent de code la construise.
- Installer Claude Code, l'utiliser en **mode plan**, puis le laisser écrire, tester et publier un calculateur de devis.
- Obtenir le même résultat avec Lovable, Bolt ou v0, et savoir lequel choisir.
- Repérer les trois familles de pièges (sécurité, coûts, hébergement) avant de donner l'adresse de l'application à un client.

> 🧭 **En clair** — Créer une application sans coder, c'est faire construire une maison par une entreprise très rapide : vous n'avez pas besoin de savoir poser des briques, mais vous devez fournir un **plan précis** (le cahier des charges), vérifier chaque étape (les tests) et refuser ce qui n'est pas aux normes (la sécurité). Claude Code, c'est l'entreprise qui vient travailler **chez vous**, dans vos dossiers, et vous demande la permission avant chaque gros travaux. Lovable, Bolt ou v0, c'est la maison préfabriquée livrée clés en main **sur leur terrain** : très rapide, mais pensez à récupérer les plans (l'export du code) pour pouvoir déménager. Dans les deux cas, vous êtes le chef de chantier : l'IA construit, vous décidez et vous vérifiez.

## 1. « Vibe coding » : la promesse et la ligne rouge

En février 2025, Andrej Karpathy (cofondateur d'OpenAI, ex-directeur IA de Tesla) décrit sa nouvelle façon de programmer : parler à l'IA, accepter ses propositions sans tout lire, « s'abandonner au vibe ». Le terme **vibe coding** fait le tour du monde et le dictionnaire Collins en fait son **mot de l'année 2025** (annonce du 6 novembre 2025), défini comme « utiliser l'IA pour dire à une machine ce que l'on veut au lieu de le coder soi-même ».

La promesse est réelle : un artisan, une responsable RH ou un commerçant peut aujourd'hui obtenir en une heure une application qui lui aurait coûté plusieurs milliers d'euros de prestation. Mais la ligne rouge l'est tout autant. Le référentiel **OWASP Top 10 for LLM Applications 2026** (publié le 4 août 2026) consacre son entrée LLM10 « Improper Output Handling » au **code non sécurisé généré à grande échelle**. Autrement dit : la machine écrit vite, et elle écrit parfois des failles.

> 💡 **À retenir** — Vous n'avez pas besoin de savoir *écrire* le code. Vous avez besoin de savoir **décrire** ce que vous voulez, **tester** ce que vous recevez et **refuser** ce qui touche à des données sensibles sans contrôle. C'est l'objet de cette leçon.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : avec le « vibe coding », il n'est plus nécessaire de tester l'application, puisque l'IA écrit un code correct.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : l'OWASP classe le code non sécurisé généré à grande échelle dans LLM10:2026 (Improper Output Handling). Décrire, tester et refuser ce qui touche aux données sensibles restent votre travail."
}
```


## 2. Deux familles d'outils (nov. 2026)

| Famille | Exemples | Où ça tourne | Pour qui | Modèle économique (sources : dossier de recherche 04, à vérifier sur les pages officielles) |
|---|---|---|---|---|
| **Agents de code en terminal / IDE** | **Claude Code** (Anthropic), **Codex CLI** (OpenAI, Apache 2.0), **Gemini CLI** (Google, Apache 2.0), **Cursor**, Cline, Aider, GitHub Copilot | Sur votre machine, dans vos fichiers | Qui accepte un terminal et veut garder le contrôle (code, git, hébergement au choix) | Claude Code inclus dans Claude Pro (20 $/mois) et Max (100–200 $/mois) ; Codex inclus dans ChatGPT Plus/Pro ; Gemini CLI gratuit pour les particuliers |
| **Générateurs d'applications en ligne** | **Lovable**, **Bolt** (StackBlitz), **v0** (Vercel), Replit | Dans le navigateur, hébergement intégré | Qui veut un résultat visible en 5 minutes sans rien installer | Offre gratuite limitée + abonnements mensuels (tarifs non vérifiés dans notre recherche : consulter lovable.dev, bolt.new, v0.app) |

Les deux familles s'appuient sur les mêmes modèles de fond (Claude Sonnet / Opus 5.5, GPT-6, Gemini 4…). La différence est l'**emballage** : le terminal vous donne le contrôle et la portabilité ; le navigateur vous donne la vitesse et le confort, au prix d'une dépendance à la plateforme.

## 3. Le projet : un calculateur de devis pour « Plomberie Martin »

Avant d'ouvrir le moindre outil, écrivez le **cahier des charges**. C'est l'étape que 90 % des débutants sautent, et c'est celle qui fait la différence entre « l'IA n'a rien compris » et « c'est exactement ça ». Créez un dossier `devis-martin/` et un fichier `SPEC.md` :

```markdown
# Calculateur de devis — Plomberie Martin (Angers)

## Objectif
Page web unique permettant à Thomas Martin, plombier, de chiffrer une intervention
devant le client sur sa tablette, puis d'imprimer ou de télécharger le devis en PDF.

## Fonctionnalités (version 1)
1. Formulaire : nom du client, adresse, date.
2. Lignes de prestation choisies dans une liste déroulante (tarifs ci-dessous),
   avec quantité ; bouton « Ajouter une ligne ».
3. Déplacement : 0 € dans Angers, 0,60 €/km au-delà (champ « km aller »).
4. Calcul automatique : total HT, TVA 10 % (rénovation) ou 20 % (neuf, case à cocher),
   total TTC. Arrondi au centime.
5. Bouton « Imprimer / PDF » (impression navigateur, mise en page propre).
6. Mention légale en pied de page : « Devis valable 30 jours. SIRET 000 000 000 00000 ».

## Tarifs (HT)
- Main-d'œuvre : 55 €/h
- Remplacement robinet mitigeur : 120 € (fourniture incluse)
- Débouchage canalisation : 90 €
- Remplacement chauffe-eau 200 L : 650 €
- Recherche de fuite : 80 €

## Contraintes
- Un seul fichier `index.html` (HTML + CSS + JavaScript), sans framework, sans serveur,
  sans base de données, sans appel réseau. Doit fonctionner hors ligne.
- Textes en français, interface lisible sur tablette (boutons larges).
- Aucune donnée n'est envoyée nulle part : tout reste dans le navigateur.
- Tests : une fonction `calculerTotaux()` isolée, testée avec 3 cas donnés ci-dessous.

## Cas de test
- 2 h de main-d'œuvre + 1 mitigeur, 0 km, TVA 10 % → HT 230,00 ; TVA 23,00 ; TTC 253,00
- 1 chauffe-eau + 3 h, 25 km, TVA 20 % → HT 830,00 ; TVA 166,00 ; TTC 996,00
- Panier vide → tous les totaux à 0,00
```

Pourquoi « un seul fichier, sans serveur » ? Parce que c'est le **périmètre le plus sûr** possible : pas de base de données à protéger, pas de clé API à cacher, pas d'hébergement payant. Vous apprendrez à élargir ce périmètre à la fin de la leçon, en connaissance de cause.

> 💡 **Autrement dit** — Le `SPEC.md`, c'est le plan d'architecte de votre application : ce qu'elle doit faire, ce qu'elle ne doit surtout pas faire, et trois exemples chiffrés pour vérifier le résultat. « Sans serveur » veut dire que tout se passe dans la page, sur la tablette du plombier : rien n'est envoyé sur Internet, donc rien ne peut fuir.

```quiz
{
  "q": "Dans le SPEC.md de Plomberie Martin, à quoi servent les trois « cas de test » chiffrés ?",
  "options": [
    "À décorer et aérer le document",
    "À fixer les tarifs définitifs du plombier",
    "À choisir le modèle de langage à utiliser",
    "À vérifier que les calculs sont justes"
  ],
  "answer": 3,
  "explanation": "Les cas de test sont la recette : si l'application ne retrouve pas 253,00 € TTC pour le premier cas, elle n'est pas terminée, quel que soit son aspect."
}
```


## 4. Tutoriel A — Claude Code

### 4.1 Installation et premier lancement

Claude Code s'installe en une commande (documentation officielle, nov. 2026). Il nécessite un compte Claude Pro, Max, Team ou Enterprise, ou une clé API Console.

```bash
# macOS / Linux / WSL (installation native)
curl -fsSL https://claude.ai/install.sh | bash

# Windows PowerShell
# irm https://claude.ai/install.ps1 | iex

# Alternatives : brew install --cask claude-code  ·  winget install Anthropic.ClaudeCode

# Se placer dans le dossier du projet et lancer l'agent
cd devis-martin
claude
```

Au premier lancement, Claude Code vous demande de vous connecter (navigateur) puis affiche une invite. Vous êtes dans une **conversation** avec un agent qui peut lire et écrire les fichiers du dossier, exécuter des commandes, et qui **demande votre permission** avant chaque action potentiellement risquée (mode par défaut). Trois commandes à connaître d'emblée :

| Commande | Effet |
|---|---|
| `/init` | Crée un fichier `CLAUDE.md` : la mémoire du projet, relue à chaque session |
| `Shift+Tab` (deux fois) | Bascule en **mode plan** : Claude réfléchit et propose, sans modifier de fichier |
| `/help` · `/cost` · `/clear` | Aide · coût de la session · nouvelle conversation |

### 4.2 Les prompts, dans l'ordre

**Prompt 1 — mémoire du projet** (après `/init`, complétez `CLAUDE.md`) :

```markdown
# CLAUDE.md — Plomberie Martin
- Lis SPEC.md avant toute action ; c'est la source de vérité.
- Un seul fichier index.html, aucune dépendance externe, aucun appel réseau.
- Commentaires et textes d'interface en français.
- Ne modifie jamais les tarifs sans me le demander.
- Avant de dire « terminé », exécute les 3 cas de test de SPEC.md et montre-moi les résultats.
```

**Prompt 2 — plan** (passez en mode plan avec `Shift+Tab`, puis tapez) :

```text
Lis SPEC.md et propose-moi un plan de réalisation en 5 à 8 étapes.
Pour chaque étape, indique les fichiers touchés. N'écris encore aucun code.
Signale tout point de la spec qui te paraît ambigu.
```

Lisez le plan. C'est votre moment de contrôle : si Claude propose « ajouter une base de données », rappelez la contrainte. S'il signale une ambiguïté (« la TVA 10 % s'applique-t-elle au déplacement ? »), répondez : vous venez d'économiser un aller-retour. Le workflow **explorer → planifier → coder → valider** est exactement celui enseigné dans le cours *Claude Code 101* (section « Daily workflows »).

**Prompt 3 — réalisation** (revenez en mode normal avec `Shift+Tab`) :

```text
Exécute le plan validé. Crée index.html avec la fonction calculerTotaux() isolée
en haut du script. Puis écris un petit fichier tests.html qui appelle calculerTotaux()
sur les 3 cas de SPEC.md et affiche OK/ÉCHEC. Ouvre-le et montre-moi le résultat.
```

Claude Code vous demandera la permission de créer des fichiers et de lancer des commandes (par exemple ouvrir le fichier dans le navigateur). Acceptez ce que vous comprenez ; refusez ce que vous ne comprenez pas et demandez « explique-moi ce que fait cette commande ».

**Prompt 4 — itérations** (exemples réels de corrections) :

```text
Sur tablette, les boutons sont trop petits : minimum 48 px de haut.
Le total TTC affiche 252.99999 : arrondis au centime avec un formatage « 253,00 € ».
Ajoute un bouton « Nouveau devis » qui vide le formulaire après confirmation.
```

**Prompt 5 — livraison** :

```text
Initialise un dépôt git, fais un commit « Calculateur de devis v1 »,
puis explique-moi en 5 lignes comment publier ce fichier sur GitHub Pages ou Netlify Drop.
```

### 4.3 Ce que vous venez de faire, en réalité

Vous avez joué le rôle de **chef de projet** : cahier des charges, validation du plan, recette (les 3 cas de test), décisions de périmètre. Claude Code a joué le rôle de développeur. Ni l'un ni l'autre n'aurait livré seul un résultat fiable aussi vite. Les cours *Claude Code 101* et *Claude Code in action* (Claude Academy, gratuits) approfondissent cette collaboration : `CLAUDE.md` qui suit le projet, modes de permission, vérification des exécutions non supervisées.

> 🔗 **Documentation officielle** — [Quickstart Claude Code](https://code.claude.com/docs/en/quickstart.md) 🇬🇧 · [Memory et CLAUDE.md](https://code.claude.com/docs/en/memory.md) 🇬🇧 · [Permissions](https://code.claude.com/docs/en/permissions.md) 🇬🇧.

```mission
{
  "title": "Comment installer Claude Code et où l'utiliser ?",
  "url": "https://code.claude.com/docs",
  "steps": ["Ouvrez la page d'accueil de la documentation Claude Code", "Repérez la commande d'installation native pour macOS / Linux et celle pour Windows", "Listez les différentes surfaces (endroits) où Claude Code est disponible"],
  "question": "Quelle commande installe Claude Code sur macOS ou Linux, et citez au moins trois surfaces où l'on peut l'utiliser.",
  "hint": "La commande commence par `curl` ; les surfaces incluent des éditeurs de code et un navigateur.",
  "answer": "`curl -fsSL https://claude.ai/install.sh | bash` (Windows : `irm https://claude.ai/install.ps1 | iex`) ; surfaces : terminal, VS Code, JetBrains, application desktop, web (claude.ai/code), mobile (relevé nov. 2026).",
  "xp": 10
}
```

```mermaid
flowchart LR
  E["Explorer<br/>(lire SPEC.md)"] --> P["Planifier<br/>(mode plan, Shift+Tab)"]
  P --> V{"Plan validé<br/>par vous ?"}
  V -- Non --> P
  V -- Oui --> C["Coder<br/>(permissions demandées)"]
  C --> T["Tester<br/>(3 cas de SPEC.md)"]
  T --> G["Commit git<br/>et publication"]
```


> ⚠️ **Piège fréquent** — Lancer Claude Code avec l'option qui saute toutes les permissions « pour aller plus vite », dans un dossier qui contient d'autres projets ou des fichiers personnels. L'agent a alors le droit de tout modifier et de tout exécuter. Travaillez **toujours** dans un dossier dédié et gardez le mode par défaut tant que vous apprenez.

## 5. Tutoriel B — Lovable, Bolt ou v0

### 5.1 Le prompt initial

Ces outils fonctionnent en ligne : vous décrivez, ils génèrent une application complète (souvent React + Tailwind) avec un aperçu immédiat. Le prompt de départ compte énormément ; réutilisez votre `SPEC.md`. Collez ceci dans Lovable (lovable.dev), Bolt (bolt.new) ou v0 (v0.app) :

```text
Crée une application web monopage « Calculateur de devis — Plomberie Martin ».
[coller ici l'intégralité de SPEC.md]
Contraintes supplémentaires : aucune authentification, aucune base de données,
aucun appel à une API externe. Les données restent dans le navigateur.
Interface en français, adaptée à une tablette. Commence par la version la plus simple
qui respecte tous les cas de test, puis demande-moi ce que je veux améliorer.
```

Le dernier paragraphe est une technique de **cadrage** : vous empêchez l'outil de « sur-construire » (compte utilisateur, tableau de bord, abonnement Stripe…), ce qu'il fait volontiers parce que ses modèles ont vu des milliers d'applications SaaS.

### 5.2 Itérer, puis publier

Chaque outil propose un chat latéral pour les corrections (« les boutons sont trop petits », « le PDF coupe le tableau ») et un bouton **Publier / Deploy** qui met l'application en ligne sur une adresse de la plateforme, parfois avec un nom de domaine personnalisé selon l'abonnement. Tous permettent d'**exporter le code** (téléchargement ou dépôt GitHub) : exigez-le dès le départ, c'est votre assurance contre la dépendance.

| | Lovable | Bolt | v0 |
|---|---|---|---|
| Point fort constaté (nov. 2026, à vérifier sur les pages officielles) | Applications complètes, intégration base de données / authentification via Supabase | Environnement complet dans le navigateur (StackBlitz), grande liberté technique | Composants et interfaces soignés, écosystème Vercel / Next.js |
| Export du code | Synchronisation GitHub | Téléchargement / GitHub | Téléchargement / Vercel |
| Risque principal | Activer Supabase sans comprendre les règles d'accès aux données | Complexité technique vite élevée | Coût Vercel si l'application grandit |

> ⚠️ **Piège fréquent** — Le générateur vous propose « d'ajouter une connexion utilisateur et de sauvegarder les devis ». Vous cliquez oui. Vous venez de créer une base de données contenant **noms et adresses de clients** (données personnelles, RGPD, leçon L028) hébergée chez un tiers, avec des règles d'accès que vous n'avez pas relues. Avant d'accepter, posez-vous : « Qui peut lire cette table ? » Si vous ne savez pas répondre, ne cliquez pas.

```mission
{
  "title": "Le programme du cours gratuit Claude Code 101",
  "url": "https://academy.claude.com/courses/claude-code-101",
  "steps": ["Ouvrez la page du cours Claude Code 101 sur Claude Academy", "Repérez la durée, le nombre de leçons et les prérequis", "Lisez le plan de la section « Daily workflows »"],
  "question": "Combien de temps dure Claude Code 101, quel compte faut-il, et quel workflow quotidien la section « Daily workflows » enseigne-t-elle ?",
  "hint": "Le workflow compte quatre verbes, du premier regard sur le code jusqu'à l'enregistrement dans git.",
  "answer": "Environ 1 h 30 (12 leçons + quiz, badge) ; un éditeur, un terminal et un compte Claude Pro/Max/Enterprise ou une clé API ; workflow « explore → plan → code → commit » (avec gestion du contexte et revue de code) — relevé nov. 2026.",
  "xp": 15
}
```

## 6. Les trois familles de pièges

### 6.1 Sécurité

| Piège | Pourquoi c'est grave | Parade |
|---|---|---|
| Clé API dans le code côté navigateur (ex. : « ajoute un bouton qui envoie le devis par e-mail via l'API X ») | Toute personne qui ouvre la page peut lire la clé et consommer votre compte | Les clés vivent **uniquement** côté serveur, dans des variables d'environnement ; sinon, pas d'appel API du tout |
| Base de données sans règles d'accès | Fuite de données clients (OWASP LLM02:2026 pour la partie IA, RGPD pour la partie légale) | Règles « chaque utilisateur ne lit que ses lignes » relues par quelqu'un qui comprend ; sinon, pas de base |
| Code généré jamais relu (LLM10:2026) | Injections, XSS, validations absentes | Demander à l'agent lui-même une **revue de sécurité** : « Liste les entrées utilisateur et vérifie que chacune est validée et échappée » ; faire relire par un développeur avant toute mise en ligne publique |
| Dépendances inconnues | Paquets abandonnés ou malveillants (LLM04:2026 Supply Chain) | Préférer « sans dépendance » tant que possible ; sinon, demander la liste et la justification de chaque paquet |

```quiz
{
  "type": "mise_en_situation",
  "q": "Un générateur d'applications vous propose d'ajouter un bouton « envoyer le devis par e-mail » en plaçant une clé API dans le code de la page. Que faites-vous ?",
  "options": [
    "Je refuse : la clé serait lisible ; mailto: ou serveur",
    "J'accepte, c'est plus rapide et le site est privé",
    "J'accepte, mais je cache la clé dans un commentaire",
    "Je publie la page sans HTTPS pour éviter le problème"
  ],
  "answer": 0,
  "explanation": "Tout ce qui est dans une page web est visible par quiconque l'ouvre. Une clé API doit rester côté serveur, dans une variable d'environnement ; sans serveur, pas d'appel API."
}
```

### 6.2 Coûts

- **Abonnement de l'outil** : Claude Pro (20 $/mois) suffit pour des projets de cette taille ; les offres Max servent aux usages intensifs. Claude Code affiche le coût avec `/cost` et la documentation « Costs » explique comment le maîtriser (sessions courtes, `/clear`, `/compact`).
- **Tokens** : un calculateur de devis coûte quelques dizaines de centimes de tokens en API ; une session qui traîne depuis trois heures avec 200 fichiers lus coûte plusieurs dollars. Redémarrez souvent.
- **Hébergement** : un fichier statique se publie gratuitement (GitHub Pages, Netlify, Vercel offre gratuite). Dès qu'il y a une base de données, de l'authentification ou un envoi d'e-mail, comptez un abonnement mensuel (plateforme + base + nom de domaine) et un temps de maintenance.
- **Le coût caché** : votre temps de relecture. Budgetez-le ; il est non négociable.

### 6.3 Hébergement et pérennité

| Question à poser avant de publier | Réponse minimale |
|---|---|
| Où est le code source ? | Dans un dépôt git que **vous** contrôlez (export GitHub ou dossier local sauvegardé) |
| Qui possède le nom de domaine ? | Vous, chez un registrar, pas la plateforme |
| Que se passe-t-il si la plateforme ferme ou double ses prix ? | Vous redéployez le code exporté ailleurs en moins d'une journée |
| HTTPS ? | Obligatoire ; fourni par défaut par GitHub Pages, Netlify, Vercel, Lovable |
| Des données personnelles sont-elles stockées ? | Si oui : registre des traitements, hébergeur identifié, durée de conservation (leçon L028) ; si non : dites-le dans une mention en pied de page |

## 7. Quel outil pour quel besoin ?

| Besoin | Choix recommandé |
|---|---|
| Outil interne, un fichier, zéro donnée stockée | Claude Code (ou Codex CLI / Gemini CLI) : résultat portable, gratuit à héberger |
| Prototype à montrer demain à un client | Lovable / Bolt / v0 : aperçu immédiat, lien partageable |
| Application avec comptes et données | Les deux familles le permettent, **mais** avec relecture par un développeur avant mise en ligne, et un hébergement choisi en conscience |
| Vous voulez apprendre à lire le code | Claude Code : demandez-lui d'expliquer chaque fichier ; c'est un professeur patient |

## 🎮 Défi

Demandez à votre agent de code (ou au générateur) : « Ajoute un bouton qui envoie le devis par e-mail au client. » Observez ce qu'il propose. Trouvez les deux problèmes de sécurité et le problème RGPD dans sa proposition avant de lire la section 6. Puis demandez-lui une solution qui n'expose aucune clé (indice : `mailto:` avec le devis en texte, ou un service côté serveur).

## 🧪 Exercice pratique

**Consigne.** Réalisez le calculateur de devis de la section 3 **deux fois** : une fois avec Claude Code (ou Codex CLI / Gemini CLI si vous n'avez pas d'abonnement Claude), une fois avec Lovable, Bolt ou v0 (offre gratuite). Vous pouvez adapter le métier (coiffure à domicile, traiteur, électricien) en conservant la structure : tarifs, déplacement, TVA, 3 cas de test.

**Livrables.**
1. `SPEC.md` complété avec vos tarifs et vos 3 cas de test.
2. L'`index.html` produit par l'agent de code, avec `tests.html` montrant 3 OK, et l'adresse de publication (GitHub Pages ou Netlify).
3. Le lien de l'application publiée par le générateur en ligne et l'export de son code.
4. Un compte rendu d'une page : temps passé par approche, nombre d'itérations, ce que vous avez dû corriger, coût (abonnements, `/cost`), et votre choix final argumenté.

**Critères de réussite.**
- Les 3 cas de test passent dans les deux versions (totaux au centime).
- Aucune clé API, aucune base de données, aucun appel réseau dans la version 1 (vérifiez : demandez à l'agent « liste tous les appels réseau du code »).
- Le code des deux versions est sauvegardé dans un dépôt que vous contrôlez.
- Le compte rendu cite au moins un piège de chaque famille (sécurité, coût, hébergement) rencontré ou évité.

<details>
<summary>Corrigé — pistes</summary>

- Si les totaux diffèrent d'un centime entre les deux versions : l'une arrondit à chaque ligne, l'autre à la fin. Précisez dans `SPEC.md` « arrondir chaque ligne au centime, puis sommer » et faites corriger les deux.
- Si le générateur en ligne a ajouté une authentification malgré la consigne : c'est un bon exemple de « sur-construction » à mentionner dans le compte rendu ; demandez « supprime toute authentification et toute persistance ».
- Pour vérifier l'absence d'appels réseau : ouvrez les outils de développement du navigateur, onglet Réseau, rechargez : il ne doit y avoir que `index.html`.
- Temps typique constaté en formation : 45 à 90 min par approche pour un premier projet, dont la moitié en relecture et tests.
</details>

## ✅ Auto-évaluation express

1. Pourquoi commencer par un `SPEC.md` plutôt que par un prompt direct ?
2. À quoi sert le mode plan de Claude Code, et quand y recourir ?
3. Une clé API peut-elle être placée dans le code d'une page web générée ? Pourquoi ?

<details>
<summary>Réponses</summary>

1. Le cahier des charges fixe le périmètre, les contraintes (sans serveur, sans réseau) et les cas de test ; il sert de source de vérité réutilisable par tous les outils et évite la sur-construction.
2. Le mode plan fait réfléchir et proposer l'agent sans qu'il modifie de fichier ; on l'utilise avant toute réalisation et avant toute modification importante, pour valider l'approche et lever les ambiguïtés.
3. Non : tout ce qui est dans une page web est lisible par quiconque l'ouvre. Une clé doit rester côté serveur, dans une variable d'environnement ; sans serveur, pas d'appel API.
</details>

## 📚 Pour aller plus loin
- [Claude Code 101 — Claude Academy](https://academy.claude.com/courses/claude-code-101) 🇬🇧 — 1 h 30, gratuit, badge : installation, premier prompt, workflow explorer → planifier → coder, CLAUDE.md.
- [Claude Code in action — Claude Academy](https://academy.claude.com/courses/claude-code-in-action) 🇬🇧 — modes de permission, hooks, vérification des exécutions non supervisées.
- [Claude Code — Best practices](https://code.claude.com/docs/en/best-practices.md) 🇬🇧 — les habitudes qui font gagner du temps et de l'argent.
- [Claude Code — Costs](https://code.claude.com/docs/en/costs.md) 🇬🇧 — comprendre et réduire la facture.
- [OpenAI Codex sur GitHub](https://github.com/openai/codex) 🇬🇧 et [Gemini CLI sur GitHub](https://github.com/google-gemini/gemini-cli) 🇬🇧 — les deux alternatives open source (Apache 2.0).
- [OWASP Top 10 for LLM Applications 2026 (synthèse)](https://docs.modulos.ai/frameworks/owasp-top-10-llm/index) 🇬🇧 — en particulier LLM10 Improper Output Handling.

> 🗺️ **Et maintenant ?** — Vous savez faire construire une application ; la dernière leçon du module, L054, montre des agents qui utilisent directement votre ordinateur et votre navigateur à votre place — et les précautions qui vont avec.
