---
id: L059
module: M14
level: N2
title: "Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI)"
minutes: 60
objectives:
  - "Rédiger un prompt d'image structuré (sujet, style, composition, lumière, contraintes négatives) et l'itérer jusqu'à un résultat conforme au brief"
  - "Comparer les générateurs d'images fermés (gpt-image, Nano Banana, Grok Imagine, Midjourney) et ouverts (FLUX, Stable Diffusion) selon la qualité, le coût, la confidentialité et la licence"
  - "Dimensionner une machine pour la génération locale avec ComfyUI (VRAM, modèle, quantization) et estimer ce qui tient ou non"
  - "Appliquer les règles de droit d'auteur et de transparence (art. L111-1 CPI, AI Act art. 50) à une image générée utilisée en entreprise"
skills: ["C2.5", "C2.3"]
sources:
  - { title: "OpenAI — Image generation guide", url: "https://developers.openai.com/api/docs/guides/image-generation", lang: "en" }
  - { title: "Google — Gemini API : génération d'images", url: "https://ai.google.dev/gemini-api/docs/image-generation", lang: "en" }
  - { title: "xAI — Image generation", url: "https://docs.x.ai/developers/tools/image-generation", lang: "en" }
  - { title: "Hugging Face — FLUX.1 schnell (model card)", url: "https://huggingface.co/black-forest-labs/FLUX.1-schnell", lang: "en" }
  - { title: "Hugging Face — Stable Diffusion 3.5 Large (model card)", url: "https://huggingface.co/stabilityai/stable-diffusion-3.5-large", lang: "en" }
  - { title: "ComfyUI — dépôt GitHub", url: "https://github.com/comfyanonymous/ComfyUI", lang: "en" }
  - { title: "Apple ML Research — Exploring LLMs with MLX on M5", url: "https://machinelearning.apple.com/research/exploring-llms-mlx-m5", lang: "en" }
  - { title: "donneespersonnelles.fr — Droit d'auteur et IA générative", url: "https://www.donneespersonnelles.fr/droit-auteur-ia-generative", lang: "fr" }
  - { title: "Hugging Face — Diffusion Course", url: "https://huggingface.co/learn/diffusion-course", lang: "en" }
---

# Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI)

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 14

## 🎯 Ce que vous saurez faire
- Décrire une image à une IA comme un directeur artistique briefe un photographe : sujet, style, composition, lumière, contraintes.
- Choisir entre un service fermé (gpt-image, Nano Banana, Grok Imagine, Midjourney) et un modèle ouvert exécuté chez vous (FLUX, Stable Diffusion) avec des arguments de coût, de confidentialité et de licence.
- Estimer si votre Mac ou votre PC peut faire tourner FLUX ou SD 3.5 dans ComfyUI, et quelle quantization choisir.
- Utiliser une image générée dans un support professionnel sans vous exposer juridiquement : droits, mention d'origine, données personnelles.

> 🧭 **En clair** — Une IA d'image, c'est comme un développeur photo qui ferait apparaître une image à partir d'une feuille couverte de neige télévisée : à chaque passage, il enlève un peu de « grain » en se laissant guider par votre description, jusqu'à obtenir une image nette. Votre travail, c'est de donner une description aussi précise qu'un brief à un photographe : quoi, dans quel style, cadré comment, avec quelle lumière et ce qui doit absolument manquer. Vous pouvez utiliser un service en ligne (simple, quelques centimes l'image) ou un modèle installé sur votre propre ordinateur (confidentiel, mais il faut une carte graphique avec assez de mémoire). Et avant de publier, vous vérifiez la licence, l'absence de personne réelle et la mention « généré par IA » si nécessaire.

## 1. Comment une IA « dessine » : la diffusion en deux minutes

Les générateurs d'images actuels reposent presque tous sur des **modèles de diffusion** (*diffusion models*). L'idée, publiée dès 2015 puis rendue pratique en 2020 avec les DDPM, est contre-intuitive : pendant l'entraînement, on apprend au modèle à **débruiter** une image à laquelle on a ajouté du bruit aléatoire, étape par étape. À la génération, on part d'un pur bruit et on le débruite une vingtaine de fois en « guidant » chaque étape avec votre texte, encodé par un modèle de langage. Le résultat : une image qui n'existait nulle part, mais qui ressemble statistiquement à ce que le modèle a vu pendant l'entraînement.

Analogie du quotidien : un sculpteur qui regarde un bloc de marbre et retire tout ce qui n'est pas la statue. Le bruit, c'est le bloc ; votre prompt, c'est l'idée de la statue ; chaque étape de diffusion, c'est un coup de ciseau.

Trois dates à retenir : **janvier 2021**, OpenAI présente DALL·E ; **juillet 2022**, Midjourney ouvre sa bêta publique sur Discord ; **août 2022**, Stable Diffusion est publié en poids ouverts et déclenche l'explosion de la génération locale. Le mois suivant, l'image *Théâtre D'opéra Spatial*, produite avec Midjourney, remporte un concours d'art numérique au Colorado et ouvre le débat juridique qui nous occupera en section 5.

> 💡 **À retenir** — Un modèle d'image ne « cherche » pas une photo dans une base : il la synthétise. C'est pourquoi il invente des doigts en trop, des textes illisibles et des logos approximatifs : il n'a aucune notion de « vrai », seulement de « plausible ».

## 2. Le prompt d'image : la méthode S-S-C-L-C

Un prompt d'image efficace n'est pas une phrase poétique, c'est un **brief de production**. Mémorisez l'acronyme **S-S-C-L-C** :

| Lettre | Composant | Question à se poser | Exemple (visuel pour une boulangerie de Lyon) |
|---|---|---|---|
| **S** | **Sujet** | Qui ou quoi, en train de faire quoi ? | « une baguette tradition dorée, posée sur un torchon en lin » |
| **S** | **Style** | Photo, illustration, 3D, aquarelle ? Quelle référence ? | « photographie culinaire éditoriale, style magazine » |
| **C** | **Composition** | Cadrage, angle, format, place du sujet | « gros plan à 45°, sujet au tiers gauche, format 4:5 vertical » |
| **L** | **Lumière & ambiance** | Heure, source, température, couleur | « lumière naturelle de matin par une fenêtre, tons chauds, légère buée » |
| **C** | **Contraintes** | Ce qu'il faut exclure, ce qui doit rester | « pas de texte, pas de mains, pas de logo, fond flou » |

Le prompt complet : *« Photographie culinaire éditoriale d'une baguette tradition dorée posée sur un torchon en lin, gros plan à 45°, sujet au tiers gauche, lumière naturelle de matin par une fenêtre, tons chauds, légère buée sur la vitre en arrière-plan flou. Pas de texte, pas de mains, pas de logo. Format 4:5. »*

Quatre règles complémentaires :

1. **Les mots concrets battent les adjectifs** : « lumière de 8 h en octobre » vaut mieux que « belle lumière ».
2. **Les contraintes négatives s'écrivent différemment selon l'outil**. Les modèles récents (gpt-image, Nano Banana, FLUX) comprennent « sans texte » dans la phrase ; Stable Diffusion utilise un champ séparé, le *negative prompt* (« text, watermark, extra fingers, blurry »), et Midjourney le paramètre `--no text`.
3. **Itérez par une seule variable à la fois** : changez la lumière, regardez, puis changez le cadrage. Sinon vous ne saurez jamais ce qui a amélioré (ou dégradé) le résultat.
4. **L'édition remplace souvent la régénération** : gpt-image, Nano Banana et FLUX acceptent une image d'entrée et une consigne (« remplace le fond par un comptoir en marbre ») ; dans ComfyUI, c'est l'*inpainting* (on peint un masque et on ne régénère que cette zone).

> ⚠️ **Piège fréquent** — Demander du texte dans l'image. Même en 2026, le rendu typographique reste le point faible de la plupart des modèles. Générez l'image **sans** texte, puis ajoutez le titre dans Canva, Figma ou PowerPoint : vous gardez le contrôle de la police, de l'orthographe et de l'accessibilité.

🎮 **Défi** — Reprenez un visuel réel de votre entreprise (site web, plaquette) et rédigez son prompt S-S-C-L-C *a posteriori*, comme si vous deviez le faire regénérer. L'exercice révèle vite ce qu'on oublie : le format, la lumière, ce qui doit être absent.

```quiz
{
  "q": "Vous travaillez avec Stable Diffusion dans ComfyUI et voulez éviter tout texte et filigrane dans l'image. Où l'écrivez-vous ?",
  "options": [
    "Dans le champ « negative prompt »",
    "À la fin du prompt principal, en majuscules et entre parenthèses",
    "Avec le paramètre --no text en fin de prompt",
    "Nulle part : Stable Diffusion n'ajoute jamais de texte ni de filigrane"
  ],
  "answer": 0,
  "explanation": "Stable Diffusion utilise un champ distinct, le negative prompt. Le paramètre --no est propre à Midjourney ; gpt-image, Nano Banana et FLUX comprennent « sans texte » directement dans la phrase."
}
```

## 3. Le paysage des outils (nov. 2026)

### 3.1 Services fermés, par API ou par abonnement

| Outil | Éditeur | Accès | Points forts | Tarif indicatif (nov. 2026, source : pages officielles lues dans la recherche) |
|---|---|---|---|---|
| **gpt-image-2.5** (variantes *sunburst* / *flare*) et gpt-image-2 | OpenAI | ChatGPT, API (outil `image_generation` de l'API Responses ou endpoint Images) | Compréhension fine des consignes, édition d'image, cohérence texte-image | Facturation aux tokens image : page tarifs « 8 $ en entrée / 30 $ en sortie » pour gpt-image-2.5, « 4 $ / 15 $ » pour gpt-image-2 — vérifier l'unité exacte sur la page tarifs |
| **Nano Banana 2.1** (`gemini-nano-banana-2.1`), Nano Banana Pro | Google | Gemini, AI Studio, API Gemini | Édition conversationnelle, multi-images en entrée, intégration Workspace | 30 $ / million de tokens image, soit ≈ 0,034 $ par image 1K |
| **Grok Imagine** (`grok-imagine-image-2.0`) | xAI | Grok (abonnement X), API xAI | Rapidité, intégration X, mode vidéo (L060) | 0,04 à 0,08 $ par image ; ancien modèle 0,02 $ |
| **Midjourney v7** | Midjourney | Site web et Discord, abonnement | Esthétique très travaillée, communauté, paramètres (`--ar`, `--no`, `--sref`) | Abonnement mensuel ; grille non vérifiée dans notre recherche — voir le site officiel |

Trois remarques de praticien :

- **Les prix se comparent par image, pas par mois.** Une image Nano Banana à 0,034 $ contre une image Grok à 0,04-0,08 $ : l'ordre de grandeur est le même, quelques centimes. Ce qui coûte cher, c'est l'itération humaine (dix essais pour une image gardée) et le temps de retouche.
- **Les données partent chez l'éditeur.** Pour un visuel marketing, aucun problème. Pour générer une illustration à partir de la photo d'un salarié ou d'un plan d'usine, relisez la leçon L041 : la question « cette donnée peut-elle sortir ? » se pose exactement comme pour un LLM.
- **Les conditions d'utilisation changent.** OpenAI cède à l'utilisateur la propriété des sorties (CGU du 1er janvier 2026, voir le dossier de recherche) ; Midjourney et les autres ont leurs propres clauses, souvent différentes entre offre gratuite et payante. Lisez-les avant un usage commercial.

> 🔗 **Documentation officielle** — [OpenAI — Image generation](https://developers.openai.com/api/docs/guides/image-generation) 🇬🇧 · [Gemini API — Image generation](https://ai.google.dev/gemini-api/docs/image-generation) 🇬🇧 · [xAI — Image generation](https://docs.x.ai/developers/tools/image-generation) 🇬🇧

### 3.2 Modèles ouverts, exécutables chez vous

| Modèle | Éditeur | Licence | Taille | Usage recommandé |
|---|---|---|---|---|
| **FLUX.1 schnell** | Black Forest Labs (Allemagne) | Apache 2.0 (usage commercial libre) | ≈ 12 milliards de paramètres | Génération rapide en 4 étapes, prototypage, usage pro sans redevance |
| **FLUX.1 dev** | Black Forest Labs | Licence non commerciale (vérifier la model card) | ≈ 12 Md | Qualité supérieure, expérimentation, formation |
| **Stable Diffusion 3.5 Large / Large Turbo** | Stability AI | Stability Community License (gratuite sous un seuil de chiffre d'affaires ; au-delà, licence entreprise) | ≈ 8 Md | Typographie correcte, personnalisation (LoRA), inpainting |
| **SDXL / SD 1.5** | Stability AI | CreativeML Open RAIL | 2,6 Md / 0,9 Md | Machines modestes, immense écosystème de LoRA et d'extensions |

L'intérêt du local est le même que pour les LLM : **confidentialité, coût marginal nul, contrôle total** (vous pouvez entraîner un petit adaptateur LoRA sur vos propres produits pour que le modèle « connaisse » votre gamme). Le prix à payer est le matériel et l'apprentissage de l'outil.

> ⚠️ **Piège fréquent** — « Poids ouverts » ne signifie pas « libre de droits ». FLUX.1 *schnell* est Apache 2.0 ; FLUX.1 *dev* ne l'est pas ; SD 3.5 impose une licence communautaire avec conditions. Avant tout usage commercial, lisez la model card sur Hugging Face, comme vous le feriez pour un LLM (L045).

## 4. Générer en local avec ComfyUI

**ComfyUI** est l'interface de référence pour exécuter FLUX, Stable Diffusion et leurs dérivés. Son principe : un **graphe de nœuds** (*nodes*) que vous reliez à la souris, chaque nœud effectuant une opération (charger le modèle, encoder le prompt, échantillonner, décoder, enregistrer). C'est exactement la logique de n8n (module 8) appliquée à l'image. Un workflow s'exporte en JSON et se partage.

```
[Load Checkpoint] ──► [CLIP Text Encode (+)] ──┐
                  │                            ├──► [KSampler] ──► [VAE Decode] ──► [Save Image]
                  └─► [CLIP Text Encode (−)] ──┘        ▲
                                                        │
                                   [Empty Latent Image 1024×1024]
```

Le nœud `KSampler` concentre les réglages : nombre d'**étapes** (*steps*, 4 pour FLUX schnell, 20 à 30 pour SD), **CFG** (force de guidage du prompt), **seed** (graine aléatoire : même seed + même prompt = même image, précieux pour itérer sur une seule variable), **sampler** (algorithme de débruitage).

> 💡 **Autrement dit** — Le **KSampler** est le tableau de bord de la génération. Les **étapes**, c'est le nombre de coups de ciseau du sculpteur ; le **CFG**, c'est à quel point il obéit à votre description (trop bas, il improvise ; trop haut, l'image devient raide et saturée) ; la **seed**, c'est le numéro du bloc de marbre de départ : même numéro + même description = même statue, ce qui permet de ne changer qu'un détail à la fois.

### 4.1 Dimensionner la machine : la VRAM décide

Reprenez la règle du module 10 : **mémoire (Go) ≈ paramètres (milliards) × bits ÷ 8 × 1,1**. Pour un modèle d'image, il faut ajouter l'encodeur de texte (T5 pour FLUX et SD 3.5, plusieurs milliards de paramètres) et le VAE, et prévoir la mémoire de travail des images latentes.

| Modèle | Poids FP16 (calcul) | Poids en 8 bits | Poids en 4 bits | Ordre de grandeur « confortable » (à vérifier sur la doc de ComfyUI pour votre version) |
|---|---|---|---|---|
| SD 1.5 (0,9 Md) | ≈ 2 Go | ≈ 1 Go | — | Toute carte 6 Go, Mac 16 Go |
| SDXL (2,6 Md + encodeurs) | ≈ 6-7 Go | ≈ 3,5 Go | — | 8 Go de VRAM, Mac 16 Go |
| SD 3.5 Large (8 Md + T5) | ≈ 18 Go + T5 | ≈ 9 Go + T5 | ≈ 5 Go + T5 | 16 Go de VRAM ; 12 Go en quantifié |
| FLUX.1 dev / schnell (12 Md + T5) | ≈ 26 Go + T5 | ≈ 13 Go + T5 | ≈ 7 Go + T5 | 24 Go de VRAM en FP8 ; 12-16 Go en 4 bits ; FP16 (≈ 26 Go) au-delà de 24 Go, avec déchargement en RAM ; Mac 32 Go |

Ces chiffres sont des **ordres de grandeur calculés** avec la formule, pas des mesures : ComfyUI sait décharger une partie du modèle en RAM système, ce qui permet de faire tourner FLUX sur 12 Go de VRAM au prix d'une forte lenteur. Fait mesuré par Apple (nov. 2025) : FLUX-dev en 4 bits (12 Md) tourne sur un MacBook Pro M5, 3,8 fois plus vite que sur M4 grâce aux Neural Accelerators ([Apple ML Research](https://machinelearning.apple.com/research/exploring-llms-mlx-m5) 🇬🇧).

Règle pratique, identique aux LLM : **la VRAM décide de ce qui tient, la bande passante et le calcul décident de la vitesse**. Une RTX 3060 12 Go génère une image SDXL en quelques secondes ; une RTX 4090 ou 5090 fait tourner FLUX en FP8 à l'aise ; un Mac M-series avec 32 Go et plus est une bonne machine de bureau pour l'image, plus lente qu'un GPU NVIDIA équivalent mais silencieuse et sans configuration CUDA.

```quiz
{
  "q": "Mise en situation : un graphiste dispose d'une carte graphique de 12 Go de VRAM et veut utiliser FLUX.1 schnell. Quel conseil lui donnez-vous ?",
  "options": [
    "Impossible : FLUX exige au minimum 48 Go de VRAM, quelle que soit la version",
    "Charger la version FP16 : ComfyUI s'adapte automatiquement, sans perte de vitesse",
    "Utiliser une version quantifiée en 4 bits",
    "Abandonner FLUX et passer à SD 1.5, seul modèle compatible avec une carte de 12 Go"
  ],
  "answer": 2,
  "explanation": "En FP16, FLUX pèse ≈ 26 Go : trop pour 12 Go. En 4 bits, les poids tombent vers 7 Go plus l'encodeur T5 ; ComfyUI peut décharger une partie en RAM système, au prix d'une forte lenteur. La VRAM décide de ce qui tient."
}
```

```mission
{
  "title": "FLUX.1 schnell : quelle licence et combien d'étapes ?",
  "url": "https://huggingface.co/black-forest-labs/FLUX.1-schnell",
  "steps": ["Ouvrez la model card de FLUX.1 schnell sur Hugging Face", "Repérez la licence affichée en haut de la page et dans la section License", "Cherchez dans la description le nombre d'étapes de génération nécessaires"],
  "question": "Sous quelle licence FLUX.1 schnell est-il diffusé, et en combien d'étapes peut-il produire une image ?",
  "hint": "C'est la même licence que Mistral Small 4 ; le nombre d'étapes tient sur les doigts d'une main.",
  "answer": "Licence Apache 2.0 (usage commercial autorisé) ; une image de qualité en 1 à 4 étapes (nov. 2026) — vérifiez sur la model card.",
  "xp": 10
}
```

### 4.2 Installer et lancer

```bash
# Installation de ComfyUI (Linux / macOS ; Windows : utiliser l'installateur ou le ZIP portable du dépôt)
git clone https://github.com/comfyanonymous/ComfyUI.git
cd ComfyUI
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # installe PyTorch adapté à votre GPU (CUDA, ROCm ou Metal)

# Les modèles se déposent dans models/ : checkpoints/, unet/ ou diffusion_models/, clip/, vae/
# Exemple : télécharger FLUX.1 schnell depuis Hugging Face (connexion et acceptation de la licence si demandée)
pip install -U "huggingface_hub[cli]"
hf download black-forest-labs/FLUX.1-schnell --local-dir models/diffusion_models/flux1-schnell

python3 main.py                            # interface sur http://127.0.0.1:8188
```

Dans l'interface, chargez un workflow d'exemple (menu *Templates*), remplacez le prompt par votre brief S-S-C-L-C, fixez une seed, lancez (*Queue*). Les images sortent dans `output/`.

> 🔗 **Documentation officielle** — [ComfyUI (GitHub)](https://github.com/comfyanonymous/ComfyUI) 🇬🇧 · [FLUX.1 schnell — model card](https://huggingface.co/black-forest-labs/FLUX.1-schnell) 🇬🇧 · [Stable Diffusion 3.5 Large — model card](https://huggingface.co/stabilityai/stable-diffusion-3.5-large) 🇬🇧

### 4.3 Et par API, pour automatiser

Pour produire 50 variantes d'une bannière depuis n8n ou un script, l'API est la voie naturelle. Exemple avec le SDK OpenAI (clé lue dans l'environnement, jamais écrite dans le code) :

```python
# generer_visuel.py — Python 3.12+ ; pip install openai
# Génère une image à partir d'un brief S-S-C-L-C et l'enregistre en PNG.
import base64
import os
from pathlib import Path

from openai import OpenAI

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])  # clé dans la variable d'environnement

brief = (
    "Photographie culinaire éditoriale d'une baguette tradition dorée posée sur un torchon en lin, "
    "gros plan à 45°, sujet au tiers gauche, lumière naturelle de matin par une fenêtre, tons chauds, "
    "arrière-plan flou. Pas de texte, pas de mains, pas de logo."
)

# Nom de modèle et paramètres à contrôler sur le guide officiel (gpt-image-2 / gpt-image-2.5, nov. 2026)
reponse = client.images.generate(model="gpt-image-2", prompt=brief, size="1024x1536", n=1)

donnees = base64.b64decode(reponse.data[0].b64_json)   # l'API renvoie l'image encodée en base64
Path("baguette.png").write_bytes(donnees)
print("Image enregistrée : baguette.png")
```

Le même principe vaut pour Gemini (`gemini-nano-banana-2.1`) et xAI (`grok-imagine-image-2.0`), dont les SDK sont vus en détail au niveau 3.

## 5. Droits, transparence et données personnelles

C'est la partie que l'on saute toujours, et celle qui coûte le plus cher quand elle se passe mal.

**1. L'image générée est-elle protégée par le droit d'auteur ?** En droit français, l'article **L111-1 du Code de la propriété intellectuelle** protège les œuvres de l'esprit portant l'empreinte de la personnalité de leur auteur. Une image produite par un simple prompt, sans intervention créative humaine documentée, n'a **pas de protection** : n'importe qui peut la réutiliser. Une image retravaillée (composition, retouches, intégration) est protégeable à hauteur des apports humains. Conséquence pratique : **documentez votre travail** (prompts successifs, choix, retouches) si l'image compte pour votre marque. L'anecdote du *Théâtre D'opéra Spatial* illustre la même logique outre-Atlantique : l'office américain du droit d'auteur a refusé l'enregistrement de la partie générée.

**2. Peut-on utiliser l'image d'une personne réelle ?** Générer une image d'un collègue, d'un client ou d'une personnalité sans son consentement expose au droit à l'image et, pour les montages trompeurs, à l'article **226-8 du Code pénal** modifié par la loi SREN du 21 mai 2024 : jusqu'à **2 ans d'emprisonnement et 45 000 € d'amende** en cas de diffusion en ligne. Nous y revenons en L061 pour la voix.

**3. Faut-il signaler que l'image est générée ?** Depuis le **2 août 2026**, l'article **50 du règlement européen sur l'IA (AI Act, règlement UE 2024/1689)** impose le marquage des contenus synthétiques et des *deepfakes* (pour les systèmes déjà sur le marché, l'obligation de marquage technique de l'art. 50(2) est différée au 2 décembre 2026). Les manquements relèvent des sanctions générales : jusqu'à **15 M€ ou 3 % du chiffre d'affaires mondial**. En pratique : conservez les métadonnées de provenance insérées par l'outil et ajoutez une mention « image générée par IA » quand le contexte peut induire en erreur (photo « de l'équipe », « de nos locaux », visuel d'actualité).

**4. Les droits des créateurs dont les œuvres ont servi à l'entraînement.** L'exception de fouille de textes et de données (directive 2019/790, art. **L122-5-3 CPI**) autorise l'entraînement sauf réservation de droits lisible par machine ; les fournisseurs de modèles à usage général doivent depuis le 2 août 2025 publier une politique de droit d'auteur (AI Act art. 53). Plusieurs procès sont en cours en Europe (GEMA c. OpenAI, Munich, 2025 ; CJUE C-250/25). Pour vous, utilisateur : évitez de demander « dans le style de [artiste vivant] » pour un usage commercial, préférez décrire le style (« aquarelle, traits fins, palette pastel »).

```quiz
{
  "type": "vrai_faux",
  "q": "Une image obtenue avec un prompt d'une ligne et publiée sans retouche est protégée par le droit d'auteur français : personne ne peut la réutiliser sans votre accord.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "L'article L111-1 du CPI protège les œuvres portant l'empreinte de la personnalité d'un auteur humain. Sans apport créatif humain documenté (retouches, composition), l'image n'est pas protégée."
}
```

> 💡 **À retenir** — Quatre réflexes avant de publier une image générée : (1) licence du modèle ou CGU du service compatible avec l'usage ; (2) aucune personne réelle identifiable sans consentement écrit ; (3) mention « généré par IA » si le contexte peut tromper ; (4) prompts et retouches archivés pour prouver l'apport humain.

> 🔗 **Documentation officielle** — [donneespersonnelles.fr — Droit d'auteur et IA générative](https://www.donneespersonnelles.fr/droit-auteur-ia-generative) 🇫🇷 · [Village de la Justice — Les apports de la loi SREN](https://www.village-justice.com/articles/les-apports-loi-visant-reguler-espace-numerique,52322.html) 🇫🇷 · [Règlement (UE) 2024/1689 — EUR-Lex](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) 🇫🇷

```mission
{
  "title": "Lisez vous-même l'article 50 de l'AI Act",
  "url": "https://eur-lex.europa.eu/eli/reg/2024/1689/oj",
  "steps": ["Ouvrez le règlement (UE) 2024/1689 sur EUR-Lex, en version française", "Descendez jusqu'au chapitre IV et à l'article 50", "Lisez le titre de l'article et le paragraphe consacré aux hypertrucages (deep fakes)"],
  "question": "Quel est l'intitulé de l'article 50, et que doivent faire les déployeurs d'un système qui génère un hypertrucage ?",
  "hint": "L'intitulé commence par « Obligations de transparence » ; le paragraphe sur les hypertrucages est le quatrième.",
  "answer": "« Obligations de transparence pour les fournisseurs et les déployeurs de certains systèmes d'IA » ; les déployeurs doivent indiquer que le contenu (image, audio, vidéo) a été généré ou manipulé artificiellement (art. 50, § 4).",
  "xp": 20
}
```

## 🧪 Exercice pratique

**Consigne.** Vous êtes chargé de communication d'un cabinet d'expertise comptable de 12 personnes à Nantes. Il vous faut trois visuels pour la page « Nos services » du site : *bilan annuel*, *paie et RH*, *création d'entreprise*. Charte : bleu nuit et blanc cassé, style illustration vectorielle plate, aucune personne réelle, aucun texte dans l'image, format 16:9.

1. Rédigez les trois prompts S-S-C-L-C (sujet, style, composition, lumière, contraintes), avec un élément de cohérence commun aux trois (même palette, même angle, même style de trait).
2. Générez-les avec l'outil de votre choix (ChatGPT, Gemini, Grok, Midjourney ou ComfyUI). Notez la seed si l'outil le permet.
3. Faites **une** itération ciblée sur le visuel le moins réussi, en ne changeant qu'une variable.
4. Rédigez la fiche de provenance : outil, modèle, date, prompts, retouches, licence ou CGU applicable, mention prévue sur le site.

**Critères de réussite.**
- Les trois prompts contiennent les cinq composants S-S-C-L-C et au moins deux contraintes négatives explicites.
- Les trois images partagent visiblement palette et style ; aucune ne contient de texte ni de personne identifiable.
- L'itération est documentée : variable modifiée, avant / après, pourquoi.
- La fiche de provenance nomme la licence ou les CGU et contient la mention de transparence.

<details>
<summary>Pistes de corrigé</summary>

Prompt « paie et RH » possible : *« Illustration vectorielle plate, palette bleu nuit (#1B2A49) et blanc cassé, vue de trois quarts d'un bureau stylisé avec un bulletin de paie schématique (lignes, pas de texte lisible), une calculatrice et une plante, composition centrée avec marge à droite pour un futur titre, éclairage uniforme sans ombre portée, format 16:9. Sans texte, sans personnage, sans logo. »* L'élément de cohérence : « vue de trois quarts », « palette bleu nuit et blanc cassé », « éclairage uniforme ». Fiche de provenance : « Visuel généré avec [outil, modèle] le [date] ; prompts archivés dans /communication/visuels-2026 ; retouches : recadrage et ajout du titre dans Figma ; mention sur le site : “Illustrations générées par IA” en pied de page. »
</details>

## ✅ Auto-évaluation express

1. Que signifie l'acronyme S-S-C-L-C et à quoi sert le dernier C ?
2. Un cabinet veut générer en local, sur une RTX 4060 Ti 16 Go, avec FLUX.1 dev en FP16 : réaliste ?
3. Une image produite par un prompt d'une ligne, sans retouche, est-elle protégée par le droit d'auteur français ?

<details>
<summary>Réponses</summary>

1. Sujet, Style, Composition, Lumière, Contraintes. Le dernier C fixe ce qui doit être absent (texte, mains, logo) et les formats imposés.
2. Non en FP16 : ≈ 26 Go pour les poids, plus l'encodeur T5. Oui avec une version FP8 ou 4 bits (≈ 7 à 13 Go), au prix d'une légère perte de qualité ; ComfyUI peut aussi décharger en RAM, plus lentement.
3. Non (art. L111-1 CPI) : sans intervention créative humaine documentée, pas de protection. Elle le devient à hauteur des apports humains (retouches, composition).
</details>

## 📚 Pour aller plus loin
- [OpenAI — Images and vision guide](https://developers.openai.com/api/docs/guides/images-vision) 🇬🇧 — envoyer des images en entrée (analyse, édition) avec l'API.
- [Hugging Face — Diffusion Course](https://huggingface.co/learn/diffusion-course) 🇬🇧 — cours gratuit pour comprendre et entraîner des modèles de diffusion avec la bibliothèque *diffusers*.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — RGPD et données personnelles dans les systèmes d'IA, dont les images de personnes.
- [Apple ML Research — MLX sur M5](https://machinelearning.apple.com/research/exploring-llms-mlx-m5) 🇬🇧 — mesures FLUX-dev 4 bits sur Mac M5.

> 🗺️ **Et maintenant ?** — Vous savez produire une image fixe ; la leçon L060 lui donne du mouvement avec Sora, Veo, Runway et Kling, où les mêmes réflexes de brief et de droits s'appliquent, en plus exigeants.
