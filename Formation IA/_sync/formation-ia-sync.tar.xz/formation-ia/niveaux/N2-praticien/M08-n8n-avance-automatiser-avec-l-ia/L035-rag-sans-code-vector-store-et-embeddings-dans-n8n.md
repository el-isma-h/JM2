---
id: L035
module: M08
level: N2
title: "RAG sans code : vector store et embeddings dans n8n"
minutes: 55
objectives:
  - "Expliquer le principe du RAG (découpage, embeddings, base vectorielle, recherche, génération) avec les mots de la documentation n8n"
  - "Construire un pipeline d'ingestion (Document Loader → Text Splitter → Embeddings → Vector Store) et un pipeline de question-réponse"
  - "Choisir entre Simple Vector Store, pgvector/Supabase et Qdrant selon le volume, la persistance et l'hébergement"
  - "Évaluer la qualité des réponses d'un RAG sur un jeu de questions et ajuster chunking et nombre de passages"
skills: ["C2.2"]
sources:
  - { title: "n8n Docs — Store and search data with vectors", url: "https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md", lang: "en" }
  - { title: "n8n Docs — Retrieve relevant context (RAG)", url: "https://docs.n8n.io/build/integrate-ai/understand-ai-components/retrieve-relevant-context.md", lang: "en" }
  - { title: "Lewis et al. (2020) — Retrieval-Augmented Generation", url: "https://arxiv.org/pdf/2005.11401", lang: "en" }
  - { title: "Ollama — Documentation (modèles d'embeddings)", url: "https://docs.ollama.com", lang: "en" }
  - { title: "Comparatif bases vectorielles 2026 (BigData Boutique)", url: "https://bigdataboutique.com/blog/vector-database-comparison-2026", lang: "en" }
---

# RAG sans code : vector store et embeddings dans n8n

> ⏱ 55 min · 🎯 Niveau 2 · 📚 Module 8

## 🎯 Ce que vous saurez faire
- Raconter le trajet d'un document, du PDF à la réponse de l'agent, en cinq étapes.
- Monter le workflow d'**ingestion** : charger, découper, vectoriser, stocker.
- Monter le workflow de **consultation** : l'agent interroge la base via un Vector Store Tool et cite ses sources.
- Choisir la base vectorielle et le modèle d'embeddings adaptés à votre contexte (cloud, local, volume).
- Mesurer si votre RAG répond juste, et savoir quoi régler quand il répond faux.

> 🧭 **En clair** — Un modèle d'IA ne connaît ni vos procédures, ni vos tarifs, ni vos fiches produits. Le RAG lui donne un **bibliothécaire** : avant de répondre, il va chercher dans vos documents les deux ou trois passages qui parlent du sujet, les lit, et répond en les citant. Pour que le bibliothécaire retrouve « remboursement » quand le client écrit « récupérer mon argent », on transforme chaque morceau de document en une sorte de **coordonnée GPS du sens** (un *embedding*) : les textes qui veulent dire la même chose ont des coordonnées proches. La base vectorielle est la carte où l'on range ces coordonnées. Vous construirez deux workflows : un pour remplir la bibliothèque, un pour la consulter.

## 1. Le problème que le RAG résout

Votre AI Agent de la leçon 34 connaît le monde jusqu'à sa date de coupure (juin 2026 pour les modèles Claude 5.5). Il ne connaît **pas** votre procédure de retour produit, votre grille tarifaire, la convention collective de votre branche ni les 340 fiches de votre base de support. Deux solutions : tout coller dans le prompt (impossible au-delà de quelques dizaines de pages, coûteux, lent), ou **aller chercher uniquement les passages utiles** au moment de la question et les donner au modèle. C'est le *Retrieval-Augmented Generation*, décrit par Lewis et ses collègues (Facebook AI Research) en 2020 : *retrieval* (récupération) + *generation*.

Analogie : un stagiaire brillant (le modèle) face à une armoire de 340 classeurs. Plutôt que de tout lire avant chaque question, il consulte un **index** qui lui dit « la réponse est probablement pages 12 et 47 du classeur 8 », lit ces deux pages, et répond en les citant. L'index, c'est la base vectorielle. La capacité à trouver « probablement » malgré des mots différents (« remboursement » vs « être remboursé » vs « récupérer mon argent »), ce sont les **embeddings**.

## 2. Les cinq étapes, et les nœuds n8n correspondants

```
INGESTION (une fois, puis à chaque mise à jour)
 ┌──────────┐  ┌─────────────┐  ┌──────────────┐  ┌────────────┐  ┌──────────────┐
 │ Source   │─►│ Document    │─►│ Text Splitter│─►│ Embeddings │─►│ Vector Store │
 │ PDF/Drive│  │ Loader      │  │ (chunks)     │  │ (vecteurs) │  │ (Insert)     │
 └──────────┘  └─────────────┘  └──────────────┘  └────────────┘  └──────────────┘

CONSULTATION (à chaque question)
 question ─► Embeddings ─► Vector Store (recherche des k chunks proches) ─► AI Agent ─► réponse + sources
```

| Étape | Sous-nœud / nœud n8n | Ce qu'il fait |
|---|---|---|
| 1. Charger | **Default Data Loader** (sous-nœud *document loader*) | Transforme un fichier binaire (PDF, DOCX, TXT, CSV) ou un JSON en « document » avec des **métadonnées** (titre, URL, date) |
| 2. Découper | **Recursive Character Text Splitter** (ou Character / Token) | Coupe en morceaux (*chunks*) de taille fixe avec chevauchement (*overlap*) |
| 3. Vectoriser | **Embeddings OpenAI / Ollama / Mistral / Google Gemini / Cohere / Hugging Face** | Convertit chaque chunk en vecteur de nombres (par exemple 1 536 ou 768 dimensions) |
| 4. Stocker | **Vector Store** en mode *Insert Documents* | Enregistre vecteur + texte + métadonnées |
| 5. Chercher et générer | **Vector Store** en mode *Retrieve Documents (As Tool for AI Agent)* ou *Question and Answer Chain* | Trouve les k chunks les plus proches de la question, les passe au modèle |

> 💡 **À retenir** — Les embeddings de l'ingestion et ceux de la consultation doivent provenir du **même modèle**. Changer de modèle d'embeddings = tout ré-ingérer. Notez le nom du modèle dans la Sticky Note du workflow.

> 💡 **Autrement dit** — Un **vecteur**, c'est une liste de nombres, par exemple 768 ou 1 536 nombres, qui décrit le sens d'un morceau de texte. La **dimension**, c'est la longueur de cette liste. Comme deux prises électriques de pays différents, un vecteur de 768 nombres ne rentre pas dans une base prévue pour 1 536 : il faut choisir le modèle d'embeddings une fois pour toutes, avant de créer la base.

```quiz
{
  "q": "Vous ingérez vos fiches avec les embeddings OpenAI, puis vous passez aux embeddings Ollama pour la consultation, par souci de confidentialité. Que se passe-t-il ?",
  "options": ["Rien : tous les modèles d'embeddings produisent des vecteurs compatibles", "n8n convertit automatiquement les anciens vecteurs vers le nouveau modèle", "Seule la vitesse de recherche change, les résultats restent identiques", "La recherche ne marche plus : il faut tout ré-ingérer"],
  "answer": 3,
  "explanation": "Deux modèles d'embeddings ne « parlent » pas le même espace de sens, et leurs dimensions diffèrent souvent. Changer de modèle = ré-ingérer toute la base."
}
```

## 3. Choisir la base vectorielle

n8n propose, parmi ses nœuds racines Vector Store : **Simple Vector Store**, **PGVector** et **Supabase** (PostgreSQL + extension pgvector), **Qdrant**, **Pinecone**, **Weaviate**, **Milvus**, **MongoDB Atlas**, **Redis**. Trois suffisent à couvrir 95 % des besoins d'une PME :

| Base | Nature | Persistance | Pour qui | Points d'attention |
|---|---|---|---|---|
| **Simple Vector Store** | En mémoire de l'instance n8n, identifiée par une *Memory Key* | **Perdue au redémarrage** | Prototyper en dix minutes, démo, tests | Jamais en production ; volume limité |
| **pgvector** (via nœud PGVector ou Supabase) | Extension de PostgreSQL (licence PostgreSQL) | Oui | Vous avez déjà Postgres (c'est le cas si n8n est auto-hébergé, leçon 37) ; jusqu'à quelques centaines de milliers de chunks | Une table par base documentaire ; créer un index pour la vitesse |
| **Qdrant** | Moteur dédié écrit en Rust, Apache 2.0, auto-hébergé (Docker) ou cloud | Oui | Production, millions de vecteurs, filtres par métadonnées, recherche hybride dense + sparse | Un conteneur de plus à administrer ; créer la *collection* avec la bonne **dimension** |

Recommandation de la recherche de ce programme (nov. 2026) : **pgvector pour commencer, Qdrant pour la production auto-hébergée**, Pinecone (service propriétaire, cloud uniquement) si vous ne voulez rien administrer. Lancer Qdrant à côté de n8n tient en quelques lignes de Docker Compose (reprises leçon 37) :

```yaml
# Extrait docker-compose.yml : service Qdrant à ajouter à côté de n8n
  qdrant:
    image: qdrant/qdrant
    restart: unless-stopped
    ports:
      - "6333:6333"          # API REST (à ne pas exposer sur Internet)
    volumes:
      - qdrant_data:/qdrant/storage
```

Dans n8n, la credential Qdrant pointe vers `http://qdrant:6333` (nom du service Docker) ; le nœud Qdrant Vector Store demande un nom de collection et la crée au premier *Insert* si elle n'existe pas (comportement à vérifier selon la version : au besoin, créez-la via l'API avec la dimension de votre modèle d'embeddings).

```quiz
{
  "q": "Mise en situation : vous préparez une démo client pour demain, puis une mise en production auto-hébergée le mois prochain sur un serveur qui fait déjà tourner n8n avec PostgreSQL. Quelles bases choisir ?",
  "options": ["Simple Vector Store en démo, pgvector en production", "Simple Vector Store pour la démo comme pour la production, par simplicité", "Pinecone obligatoirement, car c'est la seule base compatible avec n8n", "Aucune : n8n ne sait pas gérer de base vectorielle sans code"],
  "answer": 0,
  "explanation": "Le Simple Vector Store est parfait pour prototyper mais perd tout au redémarrage. En production, pgvector s'appuie sur le Postgres existant ; Qdrant prend le relais pour des millions de vecteurs."
}
```

## 4. Choisir le modèle d'embeddings

| Sous-nœud | Modèle courant | Dimensions | Quand |
|---|---|---|---|
| **Embeddings OpenAI** | `text-embedding-3-small` | 1 536 | Qualité/prix excellent, multilingue correct, données envoyées à OpenAI |
| **Embeddings Ollama** | `nomic-embed-text` ou autre modèle de la catégorie *embeddings* d'Ollama | 768 (selon modèle) | **Tout en local**, confidentialité totale, gratuit ; qualité un cran en dessous sur le français |
| **Embeddings Mistral** | `mistral-embed` | 1 024 | Fournisseur européen, bon en français |
| **Embeddings Google Gemini / Cohere / Hugging Face** | variés | variés | Selon votre écosystème |

Point souvent ignoré : **Anthropic ne propose pas de modèle d'embeddings** (nov. 2026). Un workflow « 100 % Claude » utilise donc Claude pour la génération et un autre fournisseur (ou Ollama) pour les embeddings. C'est normal et sans conséquence : les deux étapes sont indépendantes.

> ⚠️ **Piège fréquent** — Créer une collection Qdrant en 1 536 dimensions puis brancher Ollama `nomic-embed-text` (768) : erreur « dimension mismatch » à la première insertion. Décidez le modèle d'embeddings **avant** de créer la collection.

```mission
{
  "title": "La dimension des embeddings OpenAI",
  "url": "https://developers.openai.com/api/docs/guides/embeddings",
  "steps": ["Ouvrez le guide Embeddings de la documentation OpenAI", "Repérez le tableau des modèles d'embeddings", "Cherchez le paramètre qui permet de raccourcir les vecteurs"],
  "question": "Quelle est la dimension par défaut d'un vecteur produit par text-embedding-3-small, et quel paramètre permet d'en demander moins ?",
  "hint": "Le nombre figure aussi dans le tableau de la section 4 de cette leçon ; le paramètre porte un nom très explicite.",
  "answer": "1 536 dimensions par défaut ; le paramètre `dimensions` permet d'obtenir un vecteur plus court (guide consulté en nov. 2026 — vérifiez les modèles disponibles) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 5. Le découpage (chunking) : le réglage qui change tout

Le Recursive Character Text Splitter coupe d'abord aux paragraphes, puis aux phrases, puis aux mots, pour atteindre la taille cible. Deux paramètres :

- **Chunk Size** : nombre de caractères par morceau. 800 à 1 500 caractères (soit 200 à 400 tokens) est un bon départ pour des fiches de support ; plus court pour des FAQ (une question = un chunk), plus long pour des contrats.
- **Chunk Overlap** : caractères répétés entre deux chunks consécutifs (10 à 20 % de la taille), pour qu'une phrase coupée en deux reste trouvable.

Les **métadonnées** (ajoutées dans le Default Data Loader : `source`, `titre`, `url`, `date_maj`, `categorie`) voyagent avec chaque chunk et reviennent dans les résultats : c'est ce qui permet à l'agent de **citer sa source** (« d'après la fiche *Retour sous 30 jours*, mise à jour le 12/09/2026 ») et de filtrer (« ne chercher que dans la catégorie facturation »).

> 💡 **Autrement dit** — Découper un document, c'est comme couper un gâteau en parts : trop grosses, on sert à l'agent beaucoup de texte inutile ; trop petites, une part ne contient plus assez d'information pour répondre. Le **chevauchement** (*overlap*), c'est laisser un peu de crème sur le bord de chaque part pour qu'aucune phrase ne soit coupée net.

## 6. Deux workflows, pas un

**Workflow A — Ingestion** (déclenché manuellement, ou par un Google Drive Trigger quand un fichier est ajouté au dossier « Base support ») :

```
Google Drive Trigger ─► Google Drive (Download) ─► Qdrant Vector Store (Insert Documents)
                                                      ├─ Default Data Loader (binary, métadonnées: titre = {{ $json.name }})
                                                      │    └─ Recursive Character Text Splitter (1000 / 150)
                                                      └─ Embeddings Ollama (nomic-embed-text)
```

**Workflow B — Consultation** (Chat Trigger, ou Webhook dans le projet de la leçon 38) :

```
Chat Trigger ─► AI Agent ─► réponse
                 ├─ Anthropic Chat Model (claude-haiku-5-5)
                 ├─ Simple Memory
                 └─ Qdrant Vector Store (Retrieve Documents – As Tool for AI Agent, Limit = 4)
                      └─ Embeddings Ollama (nomic-embed-text)   ← le même modèle qu'en A
```

Dans le mode *As Tool for AI Agent*, vous donnez à l'outil un **nom** (« base_support ») et une **description** (« Recherche dans les fiches de support de Maison Connectée. À utiliser pour toute question sur les produits, la livraison, les retours et le SAV »). Le modèle décide quand l'appeler ; ajoutez dans le System Message : « Répondez uniquement à partir des passages renvoyés par base_support ; citez le titre de la fiche ; si aucun passage ne répond, dites-le ». Pour un usage sans agent (une question, une réponse, pas d'outil), la **Question and Answer Chain** avec un sous-nœud *Vector Store Retriever* est plus simple et moins coûteuse.

> 🔗 **Documentation officielle** — [n8n Docs — Store and search data with vectors](https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md) 🇬🇧 et [Retrieve relevant context](https://docs.n8n.io/build/integrate-ai/understand-ai-components/retrieve-relevant-context.md) 🇬🇧.

```mission
{
  "title": "Les briques du RAG dans la doc n8n",
  "url": "https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md",
  "steps": ["Ouvrez la page Store and search data with vectors", "Repérez les familles de sous-nœuds nécessaires pour remplir un vector store", "Notez les vector stores cités en exemple"],
  "question": "Quels types de sous-nœuds faut-il brancher sur un Vector Store en mode Insert, et citez trois vector stores proposés par n8n.",
  "hint": "Un pour charger, un pour découper, un pour vectoriser.",
  "answer": "Un document loader, un text splitter et un modèle d'embeddings ; par exemple Simple Vector Store, Qdrant, Pinecone (et aussi PGVector, Supabase, Weaviate, Milvus…) — doc lue en nov. 2026.",
  "xp": 10
}
```

## 7. Mesurer : le RAG répond-il juste ?

La compétence C2.2 du référentiel fixe le critère : « l'assistant répond correctement à 8 questions sur 10 à partir des documents fournis ; les sources sont citées ». Méthode : écrivez **10 questions avec leur réponse attendue** (dont 2 dont la réponse n'est **pas** dans les documents : l'assistant doit dire qu'il ne sait pas). Faites-les passer, notez. En dessous de 8/10, réglez dans cet ordre :

1. La bonne fiche est-elle dans les 4 passages renvoyés ? Non → augmentez *Limit* à 6-8, réduisez la taille des chunks, vérifiez l'ingestion (nombre de vecteurs dans la collection).
2. Oui, mais la réponse est fausse → renforcez le System Message (« uniquement à partir des passages ») et passez de Haiku à Sonnet.
3. L'assistant répond aux questions hors documents → ajoutez la règle « si aucun passage ne répond, écrivez : Je n'ai pas cette information ».

Le nœud **Evaluation** de n8n (leçon 38) automatise ce test à partir d'une feuille Google Sheets de cas.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour tester un RAG, il faut inclure des questions dont la réponse n'est PAS dans les documents.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. Le critère C2.2 prévoit 2 questions hors périmètre sur 10 : un bon assistant doit répondre « Je n'ai pas cette information » plutôt qu'inventer."
}
```

## 🎮 Défi : diagnostic express

Un RAG répond « Le délai de retour est de 14 jours » alors que la fiche dit 30 jours… et que l'ancienne version de la fiche (14 jours) a été supprimée de Google Drive le mois dernier. Que s'est-il passé ? Réponse en fin de leçon.

## 🧪 Exercice pratique

**Consigne.** Constituez une mini base de connaissances de 5 à 8 documents (fiches de votre activité, ou des documents fictifs : conditions de retour, garantie, livraison, FAQ produit, horaires du SAV) en PDF ou TXT. Montez le workflow A (ingestion) vers un Simple Vector Store (puis, si vous avez Docker, vers Qdrant ou pgvector), chunk 1 000 / overlap 150, métadonnées `titre` et `date_maj`. Montez le workflow B (consultation) avec un AI Agent Claude Haiku 5.5 et l'outil vectoriel. Rédigez 10 questions dont 2 hors périmètre ; faites passer le test ; consignez le score.

**Critères de réussite.**
- Au moins 8/10, dont les 2 questions hors périmètre correctement refusées.
- Chaque réponse cite le titre de la fiche utilisée.
- Vous avez changé **un** réglage (Limit ou Chunk Size), refait le test et noté l'effet.
- Le même modèle d'embeddings est utilisé dans A et B (vérifié).

**Pistes de corrigé.** Si le score stagne à 6-7/10 avec un Simple Vector Store, vérifiez que l'ingestion a bien été exécutée **après** chaque redémarrage de n8n (la mémoire est volatile) : c'est la cause n° 1 des « ma base est vide ».

## ✅ Auto-évaluation express

1. **Pourquoi deux workflows (ingestion et consultation) ?**
   → L'ingestion est rare et coûteuse (découpage, vectorisation) ; la consultation est fréquente et doit être rapide ; les séparer évite de ré-ingérer à chaque question.
2. **Quelle contrainte lie embeddings et base vectorielle ?**
   → La dimension des vecteurs doit correspondre à celle de la collection, et le même modèle doit servir à l'ingestion et à la recherche.
3. **Que permettent les métadonnées ?**
   → Citer la source, filtrer la recherche et mettre à jour ou supprimer les chunks d'un document précis.

**Réponse du défi.** Supprimer un fichier de Drive ne supprime pas ses vecteurs de la base : l'ancienne version est toujours indexée. Il faut, à la mise à jour d'un document, supprimer ses chunks (filtre sur la métadonnée `source`) avant de réinsérer la nouvelle version, ou ré-ingérer toute la collection.

## 📚 Pour aller plus loin
- [n8n Docs — Store and search data with vectors](https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md) 🇬🇧 — vector stores, embeddings, loaders, splitters.
- [n8n Docs — Retrieve relevant context](https://docs.n8n.io/build/integrate-ai/understand-ai-components/retrieve-relevant-context.md) 🇬🇧 — le RAG côté n8n.
- [Lewis et al. (2020) — Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks](https://arxiv.org/pdf/2005.11401) 🇬🇧 — l'article fondateur.
- [Ollama — Documentation](https://docs.ollama.com) 🇬🇧 — modèles d'embeddings locaux (catégorie *embeddings*).
- [Comparatif des bases vectorielles 2026](https://bigdataboutique.com/blog/vector-database-comparison-2026) 🇬🇧 — Qdrant, Weaviate, Pinecone, pgvector, Milvus (source tierce, oct. 2026).

> 🗺️ **Et maintenant ?** — Votre agent sait chercher dans vos documents ; la leçon L036 le relie à vos outils du quotidien : Gmail, Slack, Google Sheets, CRM et webhooks.

