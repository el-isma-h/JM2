---
id: L044
module: M10
level: N2
title: "LM Studio, Jan, Open WebUI : interfaces graphiques"
minutes: 55
objectives:
  - "Comparer les principales interfaces graphiques pour LLM locaux (LM Studio, Jan, Open WebUI, GPT4All, KoboldCpp) selon le public, la licence et l'architecture"
  - "Installer LM Studio ou Jan, y télécharger un modèle depuis Hugging Face et activer le serveur local compatible OpenAI"
  - "Déployer Open WebUI avec Docker au-dessus d'Ollama pour offrir une interface de type ChatGPT multi-utilisateurs à une équipe"
  - "Choisir l'outil adapté à un profil d'utilisateur (non technique, développeur, équipe, Mac « power user »)"
skills: ["C2.3"]
sources:
  - { title: "LM Studio — Documentation", url: "https://www.lmstudio.ai/docs", lang: "en" }
  - { title: "Jan — Site officiel", url: "https://jan.ai", lang: "en" }
  - { title: "Jan — Dépôt GitHub", url: "https://github.com/janhq/jan", lang: "en" }
  - { title: "Open WebUI — Quick Start", url: "https://docs.openwebui.com/getting-started/quick-start/", lang: "en" }
  - { title: "Thomas-Krenn — Installation of Open WebUI with Ollama", url: "https://www.thomas-krenn.com/en/wiki/Installation_of_Open_WebUI_with_Ollama", lang: "en" }
  - { title: "Thunder Compute — LM Studio local LLM guide", url: "https://www.thundercompute.com/blog/lm-studio-local-llm", lang: "en" }
  - { title: "Hugging Face Hub — Inference from model pages", url: "https://huggingface.co/docs/hub/models-inference", lang: "en" }
---

# LM Studio, Jan, Open WebUI : interfaces graphiques

> ⏱ 55 min · 🎯 Niveau 2 · 📚 Module 10

## 🎯 Ce que vous saurez faire
- Donner à un collègue non technique un « ChatGPT local » en un quart d'heure, sans terminal.
- Comprendre la différence d'architecture entre une **application de bureau** (LM Studio, Jan) et une **interface web auto-hébergée** (Open WebUI) au-dessus d'Ollama.
- Télécharger un modèle directement depuis Hugging Face dans LM Studio, et lire une fiche de modèle (*model card*).
- Mettre en place Open WebUI pour une équipe de 5 à 50 personnes avec comptes, historique et documents.

> 🧭 **En clair** — Ollama au terminal, c'est parler à votre chef cuisinier par l'interphone de service. Les interfaces graphiques, c'est lui installer une jolie salle à manger. LM Studio et Jan sont une **cuisine ouverte dans votre appartement** : un seul convive (vous), tout est sur place, rien à configurer. Open WebUI, c'est la **cantine d'entreprise** : un seul chef (Ollama, sur un serveur) et une salle où chaque collègue a sa place, son historique et ses documents. Le choix dépend donc d'abord d'une question simple : un utilisateur, ou toute une équipe ?

## 1. Deux architectures, pas une

En L043, vous avez piloté Ollama au terminal. La plupart des utilisateurs n'ouvriront jamais un terminal : il leur faut une fenêtre de chat. Deux familles d'outils répondent à ce besoin, et leur différence est importante pour vos choix de déploiement.

```
Famille A — Application de bureau « tout-en-un »        Famille B — Interface web sur serveur
┌───────────────────────────────┐                        ┌──────────────┐    ┌──────────────┐
│ LM Studio / Jan / GPT4All     │                        │ Navigateur   │    │ Navigateur   │
│  ├─ interface de chat         │                        │ (poste 1)    │    │ (poste 2)    │
│  ├─ catalogue de modèles      │                        └──────┬───────┘    └──────┬───────┘
│  ├─ moteur (llama.cpp / MLX)  │                               │  http://serveur:8080 │
│  └─ serveur API local (:1234) │                        ┌──────▼──────────────────▼───────┐
└───────────────────────────────┘                        │ Open WebUI (Docker)             │
   Un poste, un utilisateur,                             │  comptes, historique, RAG, outils│
   zéro installation technique                           └──────────────┬──────────────────┘
                                                                        │ http://127.0.0.1:11434
                                                         ┌──────────────▼──────────────────┐
                                                         │ Ollama (ou API compatible OpenAI)│
                                                         └─────────────────────────────────┘
```

La famille A convient à **un utilisateur sur son poste**. La famille B convient à **une équipe** : un serveur (le Mac Studio du bureau, un PC avec RTX 4090, un DGX Spark) fait tourner les modèles, et chacun y accède depuis son navigateur avec son compte.

```quiz
{
  "type": "mise_en_situation",
  "q": "Un cabinet de 15 personnes veut que chacun accède à un « ChatGPT interne » depuis son navigateur, avec son propre historique, sur un seul serveur. Quelle architecture ?",
  "options": [
    "Famille A : LM Studio installé sur chaque poste",
    "KoboldCpp sur une clé USB",
    "Un abonnement grand public partagé par tous les salariés",
    "Famille B : Open WebUI + Ollama sur un serveur"
  ],
  "answer": 3,
  "explanation": "Plusieurs utilisateurs, comptes séparés et un seul serveur de modèles : c'est exactement l'architecture « interface web sur serveur » (Open WebUI + Ollama)."
}
```


## 2. LM Studio : l'application de bureau de référence

**LM Studio** (macOS Apple Silicon, Windows, Linux) est gratuite mais à **code fermé**. Elle réunit quatre fonctions :

1. **Discover** : une recherche intégrée du Hub **Hugging Face**, qui affiche pour chaque modèle les fichiers GGUF (et MLX sur Mac) disponibles, avec leur taille et un indicateur « tient dans votre mémoire / ne tient pas ». C'est l'application la plus pédagogique pour mettre en pratique la L042 : le voyant passe au rouge dès que vous dépassez votre VRAM ou votre mémoire unifiée.
2. **Chat** : conversation avec le modèle chargé, réglages de température, de contexte, de prompt système, pièces jointes (documents, images pour les modèles vision).
3. **Deux moteurs** : llama.cpp (GGUF) partout, et **MLX** sur Apple Silicon, le framework d'Apple qui exploite les Neural Accelerators des puces M5 (voir L042). Sur un Mac récent, MLX est souvent plus rapide que GGUF pour le même modèle.
4. **Developer / Local Server** : un serveur compatible OpenAI sur **`http://localhost:1234/v1`** (par défaut), à activer d'un clic, plus une CLI `lms` pour scripter. Comme Ollama, cela rend LM Studio branchable sur n8n ou un script Python en changeant la `base_url`.

Installation : téléchargement sur lmstudio.ai, puis ouverture de l'application ; aucune ligne de commande. Pour un premier modèle sur un portable 16 Go : cherchez « gemma 4 12B » ou « gpt-oss-20b » dans Discover, choisissez la variante Q4_K_M, téléchargez, chargez, discutez.

> ⚠️ **Piège fréquent** — Plusieurs **quantizations** d'un même modèle, publiées par différentes organisations (ggml-org, bartowski, unsloth, lmstudio-community…), apparaissent côte à côte. Prenez une organisation reconnue, la variante `Q4_K_M` par défaut, et lisez la fiche : la *model card* indique la licence, la langue, le contexte et parfois des avertissements.

Point de vigilance pour l'entreprise : LM Studio est gratuit pour un usage personnel ; les conditions d'utilisation en entreprise ont évolué en 2025 et doivent être **vérifiées sur lmstudio.ai** avant un déploiement professionnel.

> 🔗 **Documentation officielle** — [LM Studio — Documentation](https://www.lmstudio.ai/docs)

```mission
{
  "title": "Trouvez l'adresse du serveur local de LM Studio",
  "url": "https://www.lmstudio.ai/docs",
  "steps": ["Ouvrez la documentation de LM Studio", "Allez dans la section consacrée au serveur local / à l'API (Developer)", "Repérez l'adresse et le port par défaut, ainsi que le nom de l'outil en ligne de commande"],
  "question": "Sur quelle adresse LM Studio expose-t-il par défaut son API compatible OpenAI, et comment s'appelle sa CLI ?",
  "hint": "Le port est une suite de quatre chiffres très facile à retenir.",
  "answer": "http://localhost:1234/v1 ; la CLI s'appelle `lms` (relevé nov. 2026 — le port est modifiable dans les réglages).",
  "xp": 10
}
```


## 3. Jan : l'équivalent open source

**Jan** (Windows, macOS, Linux) ressemble à LM Studio avec deux différences qui comptent pour une organisation : il est **open source sous licence Apache 2.0** (le code est auditable, l'usage en entreprise est libre) et il fonctionne **100 % hors ligne** par conception. Il embarque un « Hub » de modèles GGUF, un chat avec assistants personnalisables (l'équivalent graphique du Modelfile), et un serveur local compatible OpenAI activable dans les paramètres (le port est configurable, consultez la documentation pour la valeur par défaut de votre version). Jan peut aussi se connecter à des API distantes (OpenAI, Anthropic, Mistral…) : surveillez cette bascule si la confidentialité est la raison de votre déploiement.

Pour un service public, une association ou une entreprise avec une politique « logiciels libres uniquement », Jan est le choix naturel. Pour un Mac Apple Silicon où la vitesse MLX fait la différence, LM Studio garde l'avantage.

> 🔗 **Documentation officielle** — [Jan — Site officiel](https://jan.ai) et [dépôt GitHub](https://github.com/janhq/jan)

```quiz
{
  "q": "Votre association impose « logiciels libres uniquement » et veut un chat local sur les postes. Quel outil retenir ?",
  "options": [
    "LM Studio, parce qu'il est gratuit",
    "Jan, open source (Apache 2.0)",
    "Un modèle « cloud » d'Ollama",
    "Aucun outil local n'est libre"
  ],
  "answer": 1,
  "explanation": "Gratuit ne veut pas dire libre : LM Studio est gratuit mais à code fermé. Jan est open source (Apache 2.0) et fonctionne hors ligne."
}
```


## 4. Open WebUI : le « ChatGPT d'entreprise » auto-hébergé

**Open WebUI** est une interface web auto-hébergée qui reproduit l'expérience ChatGPT : comptes utilisateurs et rôles (administrateur, utilisateur), historique de conversations, choix du modèle par conversation, pièces jointes, **RAG** intégré (vous déposez des PDF, l'outil les découpe, les indexe et les cite — nous l'approfondirons au module 11), recherche web optionnelle, outils et serveurs **MCP**, et même l'exécution de plusieurs modèles côte à côte pour les comparer. Elle se place au-dessus d'Ollama, ou de n'importe quelle API compatible OpenAI (y compris LM Studio, vLLM, ou une API cloud pour une architecture hybride).

Son déploiement standard passe par Docker, en une commande, avec Ollama déjà installé sur la même machine :

```bash
# Open WebUI + Ollama sur la même machine Linux (réseau de l'hôte partagé, port 8080)
docker run -d \
  --network=host \
  -v open-webui:/app/backend/data \
  -e OLLAMA_BASE_URL=http://127.0.0.1:11434 \
  --name open-webui \
  --restart always \
  ghcr.io/open-webui/open-webui:main

# Puis ouvrir http://localhost:8080 : le premier compte créé devient administrateur.
# Sur macOS / Windows (Docker Desktop), --network=host n'existe pas : remplacer par
#   -p 3000:8080 -e OLLAMA_BASE_URL=http://host.docker.internal:11434
# et ouvrir http://localhost:3000.
```

> 💡 **Autrement dit** — Docker, c'est un conteneur de déménagement standardisé : le logiciel y est livré avec tout ce dont il a besoin, et il s'installe de la même façon sur n'importe quelle machine. Le « volume », c'est le carton étiqueté qui garde vos affaires (comptes, historiques) même si vous remplacez le conteneur par une version plus récente. Le « port » (8080, 3000…), c'est le numéro de la porte par laquelle votre navigateur entre.

Le volume `open-webui` conserve les comptes, l'historique et les documents indexés : sauvegardez-le. Pour un serveur d'équipe, ajoutez un nom de domaine interne et HTTPS (via un reverse proxy), et imposez des mots de passe robustes : **une interface locale n'est pas une interface sécurisée par défaut**.

Côté licence, Open WebUI est passé en 2025 à une licence propre (dérivée de BSD-3 avec une clause de protection de la marque) : lisez le fichier LICENSE du dépôt avant une utilisation commerciale importante, notamment si vous comptez retirer le logo pour vos clients.

> 💡 **À retenir** — Open WebUI ne fait tourner aucun modèle : il **parle** à Ollama (ou à une API). Les performances dépendent donc entièrement de la machine Ollama dimensionnée en L042. Pour 5 utilisateurs simultanés, prévoyez de la marge de mémoire : chaque conversation active réserve son propre KV cache.

> 🔗 **Documentation officielle** — [Open WebUI — Quick Start](https://docs.openwebui.com/getting-started/quick-start/)

## 5. Les autres outils à connaître

| Outil | En une phrase | Licence | Pour qui |
|---|---|---|---|
| **GPT4All** (Nomic) | Application de bureau grand public, orientée CPU, avec « LocalDocs » (questions sur vos fichiers) | MIT (application) | Poste sans GPU, usage simple sur ses documents |
| **KoboldCpp** | « One File. Zero Install. » : un seul exécutable basé sur llama.cpp, interface web Kobold Lite, images et voix, API OpenAI (port 5001) | AGPL-3.0 | Machine très limitée, clé USB, expérimentation |
| **text-generation-webui** (« TextGen ») | Interface web multi-moteurs (llama.cpp, Transformers, ExLlama) pour utilisateurs avancés | AGPL-3.0 | Bidouilleurs, comparaison de moteurs |
| **llama.cpp** (`llama-server`) | Le moteur lui-même, avec une mini-interface web et une API OpenAI (port 8080) | MIT | Minimalistes, embarqué, benchmarks (`llama-bench`) |
| **vLLM** | Serveur haute performance pour GPU (batching continu), API OpenAI (port 8000) ; pas d'interface | Apache 2.0 | Serveur multi-utilisateurs, production (module 29) |
| **Unsloth Studio** | Nouveauté 2026 : application de bureau pour exécuter **et** fine-tuner des modèles | Apache 2.0 / AGPL-3.0 (interface) | Ceux qui iront jusqu'au module 28 |

Remarquez la constante : **tous exposent une API compatible OpenAI**, chacun sur son port (Ollama 11434, LM Studio 1234, llama-server 8080, vLLM 8000, KoboldCpp 5001). Quelle que soit l'interface choisie, la L046 s'appliquera.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : installer Open WebUI sur un serveur modeste le rend capable de faire tourner un modèle de 70B, puisque c'est lui qui exécute les modèles.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : Open WebUI ne fait tourner aucun modèle, il parle à Ollama ou à une API. La taille de modèle possible dépend uniquement de la machine qui héberge Ollama (L042)."
}
```

## 6. Quel outil pour quel public ?

| Profil | Recommandation | Pourquoi |
|---|---|---|
| Collaborateur non technique, un poste | **LM Studio** ou **Jan** | Interface graphique, catalogue intégré, zéro terminal |
| Développeur / automatisation | **Ollama** (+ Open WebUI pour le confort) | Scriptable, API, Docker, Modelfile |
| Mac Apple Silicon « power user » | **LM Studio** (moteur MLX) ou `mlx-lm` | Exploite les accélérateurs M5, prefill très rapide |
| Équipe de 5 à 50 personnes | **Open WebUI + Ollama** sur un serveur | Comptes, historique, RAG, modèles partagés |
| Organisation « libre uniquement » | **Jan** (poste) + **Open WebUI** (équipe) | Licences Apache 2.0 / ouverte |
| Production multi-utilisateurs intensive | **vLLM** (+ Open WebUI en façade) | Débit agrégé (289–313 tok/s sur 8 requêtes simultanées sur DGX Spark contre aucun gain avec Ollama, mesure oct. 2026) |
| Machine très limitée | **llama.cpp** ou **KoboldCpp** | Binaire unique, CPU/Vulkan |

🎮 **Défi** — Ouvrez la fiche Hugging Face d'un modèle que vous aimeriez tester (par exemple Qwen/Qwen3.8-27B) et trouvez, sans aide, trois informations : la licence, la taille de contexte, et le lien vers une version GGUF ou MLX. Chronométrez-vous : en dessous de trois minutes, vous savez lire une *model card*.

```mission
{
  "title": "Lisez la fiche Hugging Face de Gemma 4 26B-A4B",
  "url": "https://huggingface.co/google/gemma-4-26B-A4B-it",
  "steps": ["Ouvrez la fiche du modèle google/gemma-4-26B-A4B-it", "Repérez l'étiquette « License » en haut de la page", "Cherchez dans la fiche le nombre de paramètres total et actifs, et la longueur de contexte", "Repérez les modalités acceptées en entrée (texte, image…)"],
  "question": "Quelle licence, combien de paramètres actifs, quelle longueur de contexte ? Quelle taille prévoir en 4 bits ?",
  "hint": "« A4B » dans le nom donne déjà un indice sur les paramètres actifs.",
  "answer": "Licence Apache 2.0 ; MoE de 25,2B paramètres au total dont environ 3,8B actifs ; contexte de 256K tokens ; texte + image (+ vidéo courte). En 4 bits, compter 16 à 18 Go (relevé nov. 2026).",
  "xp": 20
}
```

## 🧪 Exercice pratique

**Consigne.** Choisissez l'un des deux parcours selon votre matériel.

*Parcours A — Poste individuel (LM Studio ou Jan).* Installez l'application ; dans le catalogue, cherchez un modèle adapté à votre mémoire (reprenez votre calcul de L042) ; téléchargez la variante Q4_K_M (ou MLX 4 bits sur Mac) ; chargez-le ; créez un prompt système en français pour votre métier ; activez le serveur local et vérifiez-le avec un `curl` sur `/v1/models` (port 1234 pour LM Studio).

*Parcours B — Serveur d'équipe (Open WebUI).* Sur une machine où Ollama tourne déjà (L043), lancez Open WebUI avec Docker ; créez le compte administrateur puis un second compte « utilisateur » ; déposez un PDF interne (notice, procédure) et posez une question dont la réponse s'y trouve ; comparez deux modèles sur la même question avec la fonction de comparaison.

**Critères de réussite.** Le modèle répond en français depuis l'interface ; le serveur API répond (parcours A) ou le second compte voit l'interface sans les droits d'administration (parcours B) ; vous savez dire où sont stockés les modèles et les données ; vous avez identifié la licence du modèle utilisé.

**Pistes de corrigé.** Parcours A : `curl http://localhost:1234/v1/models` doit lister le modèle chargé ; si la réponse est vide, le serveur n'est pas activé dans l'onglet Developer. Parcours B : si Open WebUI ne voit aucun modèle, c'est presque toujours `OLLAMA_BASE_URL` (utilisez `host.docker.internal` sous Docker Desktop) ; les données vivent dans le volume Docker `open-webui`, les modèles dans `~/.ollama/models`.

## ✅ Auto-évaluation express

1. Quelle est la principale différence entre LM Studio et Jan pour une entreprise ?
2. Open WebUI fait-il tourner les modèles lui-même ?
3. Sur quel port LM Studio expose-t-il par défaut son API compatible OpenAI ?

*Réponses :* 1. Jan est open source (Apache 2.0) et conçu hors ligne ; LM Studio est gratuit mais à code fermé, avec des conditions d'usage en entreprise à vérifier, et un moteur MLX plus rapide sur Mac. 2. Non : il s'appuie sur Ollama ou une API compatible OpenAI ; la vitesse dépend de la machine qui héberge le modèle. 3. 1234 (`http://localhost:1234/v1`).

## 📚 Pour aller plus loin
- [LM Studio — Documentation](https://www.lmstudio.ai/docs) 🇬🇧 — chat, serveur local, CLI `lms`, moteurs llama.cpp et MLX.
- [Thunder Compute — LM Studio local LLM guide](https://www.thundercompute.com/blog/lm-studio-local-llm) 🇬🇧 — pas-à-pas illustré de la découverte de modèles au serveur.
- [Jan — Site officiel](https://jan.ai) 🇬🇧 — l'alternative Apache 2.0 et hors ligne.
- [Open WebUI — Quick Start](https://docs.openwebui.com/getting-started/quick-start/) 🇬🇧 — toutes les variantes d'installation (Docker, pip, GPU, Ollama inclus).
- [Thomas-Krenn — Installation of Open WebUI with Ollama](https://www.thomas-krenn.com/en/wiki/Installation_of_Open_WebUI_with_Ollama) 🇬🇧 — tutoriel serveur complet.
- [Hugging Face Hub — Inference from model pages](https://huggingface.co/docs/hub/models-inference) 🇬🇧 — comment les fiches de modèles renvoient vers les outils locaux (Ollama, LM Studio, llama.cpp).

> 🗺️ **Et maintenant ?** — Vous savez faire tourner un modèle et lui donner une interface ; reste à choisir *le bon* modèle parmi des centaines : c'est l'objet de la leçon L045.
