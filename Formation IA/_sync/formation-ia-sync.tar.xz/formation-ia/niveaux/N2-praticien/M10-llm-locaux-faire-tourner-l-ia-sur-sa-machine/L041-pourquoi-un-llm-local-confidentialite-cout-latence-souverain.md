---
id: L041
module: M10
level: N2
title: "Pourquoi un LLM local : confidentialité, coût, latence, souveraineté"
minutes: 45
objectives:
  - "Expliquer ce qu'est un modèle « à poids ouverts » exécuté en local et en quoi il diffère d'un service cloud (ChatGPT, Claude, Gemini)"
  - "Évaluer, pour un cas d'usage professionnel donné, l'intérêt d'un LLM local selon quatre critères : confidentialité, coût, latence, souveraineté"
  - "Identifier les situations où le local n'est pas la bonne réponse et formuler une grille de décision local / API / SaaS"
skills: ["C2.3", "C2.6"]
sources:
  - { title: "Ollama — Documentation officielle", url: "https://docs.ollama.com", lang: "en" }
  - { title: "Pinggy — Best Local LLM Tools and Models in 2026", url: "https://pinggy.io/blog/top_5_local_llm_tools_and_models/", lang: "en" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "Scaleway — Tarifs GPU", url: "https://www.scaleway.com/en/pricing/gpu", lang: "en" }
  - { title: "Artificial Analysis — Recent open weights model launches", url: "https://www.artificialanalysis.ai/articles/recent-open-weights-model-launches", lang: "en" }
---

# Pourquoi un LLM local : confidentialité, coût, latence, souveraineté

> ⏱ 45 min · 🎯 Niveau 2 · 📚 Module 10

## 🎯 Ce que vous saurez faire
- Expliquer à un collègue, sans jargon, ce que signifie « faire tourner un modèle d'IA sur sa machine » et ce que cela change par rapport à ChatGPT ou Claude.
- Peser les quatre arguments du local (confidentialité, coût, latence, souveraineté) avec des chiffres de novembre 2026, et pas avec des slogans.
- Décider, pour un cas réel de votre entreprise, entre trois options : modèle local, API cloud, application SaaS.

> 🧭 **En clair** — Utiliser ChatGPT ou Claude, c'est commander au restaurant : c'est délicieux, on ne fait rien, mais le cuisinier voit tout ce que vous commandez et vous payez chaque plat. Un LLM local, c'est avoir son propre chef cuisinier à la maison : il faut lui fournir une cuisine (un ordinateur assez puissant) et l'installer une fois, mais ensuite il cuisine autant que vous voulez, portes fermées, sans addition à chaque plat. Votre chef maison est souvent un peu moins doué que le grand chef étoilé du restaurant, mais pour les plats du quotidien (résumer, trier, extraire), il fait très bien l'affaire. Cette leçon vous aide à décider quand le chef à domicile vaut la peine.

## 1. De quoi parle-t-on exactement ?

Quand vous utilisez Claude, ChatGPT ou Gemini, votre texte part sur Internet, est traité par des milliers de GPU dans un centre de données, puis la réponse revient. Le modèle lui-même (ses « poids », c'est-à-dire les milliards de nombres appris pendant l'entraînement, vus au module 2) ne quitte jamais les serveurs de l'éditeur : il est **fermé**.

Un **LLM local** repose sur un modèle **à poids ouverts** (*open weights*) : l'éditeur publie le fichier contenant les poids, et n'importe qui peut le télécharger et l'exécuter sur son propre matériel — un MacBook, un PC avec carte graphique, un serveur dans le placard de la PME, ou une machine louée dans un cloud français. Les grands noms de fin 2026 sont Qwen3.8 (Alibaba), Gemma 4 (Google), gpt-oss (OpenAI), Mistral Small 4 (Mistral, Paris), DeepSeek V4, Kimi K3 et Llama 4 (Meta). Nous les comparerons en détail à la leçon L045.

Analogie du quotidien : un service cloud, c'est un restaurant. Vous commandez, on cuisine pour vous, vous payez à l'assiette, et le chef voit ce que vous mangez. Un LLM local, c'est une cuisine équipée chez vous : il faut acheter le four (le matériel), apprendre une ou deux recettes (installer Ollama ou LM Studio), mais ensuite vous cuisinez autant que vous voulez, à huis clos, sans ticket de caisse.

> 💡 **À retenir** — « Open weights » ne veut pas dire « open source » au sens strict : les poids sont publics, mais les données d'entraînement le sont rarement, et la **licence** peut restreindre l'usage commercial (nous y reviendrons en L045). Vérifiez toujours la licence avant un déploiement en entreprise.

Trois précisions pour éviter les confusions de vocabulaire :

| Terme | Ce que cela désigne | Exemple (nov. 2026) |
|---|---|---|
| Modèle fermé, accès API ou SaaS | Poids non publiés, exécution chez l'éditeur | Claude Fable 5.1, GPT-6, Gemini 4 |
| Modèle à poids ouverts, exécuté **en local** | Poids téléchargés, exécution sur votre machine | Qwen3.8-27B sur un Mac 32 Go via Ollama |
| Modèle à poids ouverts, exécuté **dans un cloud que vous louez** | Même poids, mais sur un GPU loué à l'heure | gpt-oss-120b sur un H100 Scaleway à 2,73 € HT/h |

Les deux dernières lignes relèvent de la même famille : vous contrôlez le modèle. Cette leçon parle des deux.

```quiz
{
  "q": "Qu'est-ce qui caractérise un modèle « à poids ouverts » (open weights) ?",
  "options": [
    "Il est forcément gratuit pour tout usage commercial",
    "Ses données d'entraînement sont toujours publiques",
    "Ses poids sont publiés et exécutables sur votre matériel",
    "Il ne fonctionne que sans connexion Internet"
  ],
  "answer": 2,
  "explanation": "Les poids (les milliards de nombres appris) sont téléchargeables. Mais les données d'entraînement restent rarement publiques et la licence peut limiter l'usage commercial."
}
```


## 2. Argument n° 1 : la confidentialité

C'est la raison la plus citée, et à juste titre. Avec un modèle local, **aucune donnée ne quitte la machine** : ni le prompt, ni les documents joints, ni les réponses. Débranchez le câble réseau, le modèle continue de répondre.

Cas professionnels français où cela change tout :

- **Cabinet comptable** : analyser des liasses fiscales et des bulletins de paie de clients sans les envoyer à un prestataire américain.
- **Cabinet d'avocats ou service juridique** : résumer des pièces couvertes par le secret professionnel.
- **Service RH** : trier des CV ou rédiger des comptes rendus d'entretiens annuels (données personnelles sensibles au sens du RGPD).
- **Bureau d'études, R&D industrielle** : brevets, plans, secrets de fabrication.
- **Établissement de santé** : données de santé, dont le traitement est très encadré.

Au module 7, vous avez appris que le RGPD impose de connaître les destinataires des données et d'encadrer tout transfert hors de l'Union européenne. Un LLM local **supprime le problème du transfert** : il n'y a plus de destinataire externe. Attention toutefois, il ne supprime pas les autres obligations (finalité, minimisation, durée de conservation, information des personnes). La CNIL publie des fiches pratiques sur le développement et l'usage des systèmes d'IA qui restent entièrement applicables.

> ⚠️ **Piège fréquent** — Depuis 2025, Ollama propose aussi des « modèles cloud » exécutés sur les serveurs d'Ollama, à côté des modèles locaux. Même outil, même commande… mais vos données partent sur Internet. Vérifiez toujours si le modèle que vous lancez porte la mention *cloud* dans le catalogue (voir docs.ollama.com). Même vigilance avec les interfaces graphiques qui peuvent basculer sur une clé API OpenAI ou Anthropic.

> 🔗 **Documentation officielle** — [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia)

```mission
{
  "title": "Repérez la différence entre modèle local et modèle cloud chez Ollama",
  "url": "https://docs.ollama.com",
  "steps": ["Ouvrez la documentation d'Ollama", "Cherchez la page ou la section consacrée aux modèles « cloud »", "Notez comment un modèle cloud est signalé et où il est exécuté"],
  "question": "Où s'exécute un modèle Ollama marqué « cloud », et qu'est-ce que cela change pour vos données ?",
  "hint": "Utilisez la recherche de la documentation avec le mot « cloud ».",
  "answer": "Il s'exécute sur les serveurs d'Ollama, pas sur votre machine : vos prompts et documents partent donc sur Internet. Seuls les modèles sans la mention « cloud » restent 100 % locaux (relevé nov. 2026 — vérifiez la page, l'offre évolue) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```


## 3. Argument n° 2 : le coût

Ici, il faut compter plutôt que croire. Trois modèles économiques coexistent :

1. **API cloud** : vous payez au million de tokens (entrée + sortie). Pas d'investissement, coût proportionnel à l'usage.
2. **Local sur matériel acheté** : investissement initial (de 0 € si votre ordinateur suffit, à ~2 000 $ pour une RTX 5090, ~3 500 $ pour un mini-PC AMD Strix Halo 128 Go, ~4 700–6 950 $ pour un NVIDIA DGX Spark selon la période, chiffres nov. 2026), puis coût marginal quasi nul (électricité).
3. **GPU loué à l'heure** : entre les deux. Ordres de grandeur (nov. 2026) : RTX 4090 dès 0,34 $/h sur RunPod ou Vast.ai ; H100 PCIe 2,73 € HT/h chez Scaleway, 2,80 €/h chez OVHcloud ; L40S 1,40 €/h chez Scaleway.

Un exercice de calcul (le dossier de recherche du module le propose en « FinOps ») : une RTX 4090 louée 0,34 $/h représente environ **13 800 heures d'usage** (4 699 ÷ 0,34) pour le prix d'un DGX Spark à 4 699 $. Un H100 Scaleway utilisé 8 h par jour, 20 jours par mois, coûte **437 € HT/mois**. Le local sur matériel acheté devient rentable quand l'usage est intensif et régulier ; la location gagne quand l'usage est ponctuel (un fine-tuning, un gros traitement de documents une fois par trimestre).

Le point que beaucoup oublient : **le coût caché du local, c'est le temps humain**. Installer, mettre à jour, surveiller, choisir les modèles. Pour une TPE sans profil technique, une API bien encadrée reste souvent moins chère au total. Pour une PME avec un informaticien et 20 utilisateurs quotidiens, le local se justifie vite.

> 💡 **À retenir** — Le local n'est pas « gratuit ». Il remplace un coût variable (tokens) par un coût fixe (matériel + temps). Faites le calcul sur 12 mois avec votre volume réel de tokens avant de trancher.

> 💡 **Autrement dit** — L'API cloud, c'est le taxi payé à la course ; le matériel acheté, c'est la voiture achetée (cher au départ, presque rien ensuite) ; le GPU loué, c'est la location à l'heure. Plus vous roulez souvent et longtemps, plus l'achat devient intéressant — à condition d'avoir quelqu'un pour l'entretien.

```mission
{
  "title": "Combien coûte une heure de GPU L40S chez un hébergeur français ?",
  "url": "https://www.scaleway.com/en/pricing/gpu",
  "steps": ["Ouvrez la page des tarifs GPU de Scaleway", "Repérez la ligne des instances L40S", "Lisez le prix horaire hors taxes"],
  "question": "Quel est le prix horaire HT d'une instance GPU L40S chez Scaleway ?",
  "hint": "Le prix est affiché en euros par heure.",
  "answer": "Environ 1,40 € HT/heure (relevé nov. 2026 — les prix des GPU changent souvent, notez la date de votre consultation).",
  "xp": 10
}
```


## 4. Argument n° 3 : la latence et la disponibilité

Un modèle local répond sans aller-retour réseau et sans file d'attente partagée. Sur une RTX 5090, un modèle 8B quantifié génère environ **145 tokens par seconde** ; sur un MacBook Pro M4 Max, environ **83 tok/s** sur un 7B (mesures llama.cpp, détaillées en L042). Pour un humain qui lit, c'est bien plus rapide que nécessaire.

Mais la latence a deux visages :

- Le **temps avant le premier token** (*time to first token*, TTFT), qui dépend du traitement du prompt (*prefill*). Les API cloud sont ici très bonnes car elles disposent de GPU énormes ; un petit Mac peut mettre plusieurs secondes sur un prompt de 10 000 tokens.
- Le **débit de génération** (tok/s), borné localement par la bande passante mémoire de votre machine.

Autre bénéfice : la **disponibilité**. Pas de panne du fournisseur, pas de changement de modèle imposé du jour au lendemain, pas de quota. Un cas fréquent : un atelier d'artisanat ou une agence en zone rurale avec une connexion médiocre, ou une application embarquée (tablette d'inventaire en entrepôt, poste isolé sur un chantier).

Et le revers : **un modèle local est presque toujours moins capable qu'un modèle frontière fermé**. Au 27 octobre 2026, l'indice Artificial Analysis v5 donne 58 à Claude Opus 5.5 et 57 à GPT-6 Astra, contre 32 aux meilleurs modèles à poids publiés (DeepSeek V4.1 Flash, GLM-5.3). Et ces 32 points demandent un serveur multi-GPU ; sur un portable, vous ferez tourner des modèles plus petits encore. Pour un résumé, une classification, une extraction de données structurées ou un assistant interne sur des documents connus, un bon modèle de 8 à 30 milliards de paramètres suffit largement. Pour un raisonnement juridique complexe ou du code difficile, le cloud garde l'avantage.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un modèle local de 8 milliards de paramètres sur un portable rivalise en qualité avec Claude Opus 5.5 sur un raisonnement juridique complexe.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : au 27 oct. 2026, l'écart entre les meilleurs modèles fermés (58) et les meilleurs modèles ouverts (32, sur serveur multi-GPU) reste large. Le local excelle pour résumer, classer ou extraire, pas pour le raisonnement le plus pointu."
}
```

## 5. Argument n° 4 : la souveraineté et la maîtrise

La **souveraineté** dépasse la confidentialité : c'est la capacité à ne dépendre de personne. Un modèle à poids ouverts téléchargé en 2026 fonctionnera encore en 2030, identique, même si son éditeur disparaît ou change ses conditions. Vous pouvez l'auditer, le modifier (fine-tuning, module 28), le déployer où vous voulez, le figer pour des raisons de conformité (un modèle qui ne change pas est plus facile à documenter au titre de l'AI Act).

C'est aussi un argument géopolitique de plus en plus présent dans les appels d'offres publics et les grands comptes français : hébergement en France ou en Europe, absence de législation extraterritoriale sur les données. Deux observations honnêtes, tirées du paysage de novembre 2026 :

- Les meilleurs modèles ouverts sont aujourd'hui **chinois** (Kimi K3, DeepSeek, Qwen, GLM) ; les acteurs occidentaux ouverts sont Google (Gemma 4), OpenAI (gpt-oss), NVIDIA (Nemotron), IBM (Granite) et, en Europe, **Mistral AI** (Ministral 3, Small 4, Large 3, tous sous licence Apache 2.0).
- Exécuter un modèle chinois en local ne pose **aucun** problème de transfert de données : les poids sont des fichiers de nombres, ils ne « téléphonent » à personne. La question de souveraineté porte sur la dépendance à l'éditeur pour les versions futures, pas sur la fuite de données.

> ⚠️ **Piège fréquent** — « Local » n'implique pas « sécurisé ». Un modèle téléchargé depuis un dépôt inconnu peut contenir du code malveillant (anciens formats *pickle*) ; une interface web locale exposée sans mot de passe sur le réseau de l'entreprise est une porte ouverte. Préférez les dépôts officiels (ollama.com/search, organisations vérifiées sur Hugging Face), le format `safetensors` ou GGUF, et un pare-feu.

## 6. La grille de décision : local, API ou SaaS ?

Voici la grille que nous utiliserons tout au long du module. Elle sera complétée au module 15 (gouvernance) par les aspects AI Act et RGPD.

| Critère | SaaS (Claude.ai, ChatGPT…) | API cloud (Anthropic, OpenAI, Mistral…) | LLM local / GPU loué |
|---|---|---|---|
| Qualité maximale | ★★★ | ★★★ | ★★ (★★★ avec un gros MoE sur serveur) |
| Confidentialité des données | ★ à ★★ (selon contrat) | ★★ (contrats pro, options « zéro rétention ») | ★★★ |
| Coût à faible volume | ★★★ (abonnement) | ★★★ (paiement à l'usage) | ★ (matériel, temps) |
| Coût à fort volume | ★ | ★★ | ★★★ |
| Latence / hors ligne | ★★ | ★★ | ★★★ (hors ligne possible) |
| Compétences nécessaires | ★ (aucune) | ★★ (développeur) | ★★ à ★★★ |
| Pérennité / indépendance | ★ | ★★ | ★★★ |
| Multimodal, recherche web, agents « clés en main » | ★★★ | ★★★ | ★★ (Open WebUI, n8n, à assembler) |

Règle pratique en trois questions :

1. **Les données sont-elles interdites de sortie ?** (secret professionnel, santé, données de clients sans base légale de transfert) → local, point final.
2. **Le volume est-il élevé et régulier ?** (des milliers de documents par mois) → local ou GPU loué, calcul à l'appui.
3. **La tâche exige-t-elle le meilleur raisonnement du marché ?** → API cloud frontière, avec un contrat adapté.

```mermaid
flowchart TD
  Q1{"Les données sont-elles<br/>interdites de sortie ?"} -- Oui --> L["LLM local"]
  Q1 -- Non --> Q2{"Volume élevé<br/>et régulier ?"}
  Q2 -- Oui --> G["Local ou GPU loué<br/>(calcul à l'appui)"]
  Q2 -- Non --> Q3{"Meilleur raisonnement<br/>du marché exigé ?"}
  Q3 -- Oui --> A["API cloud frontière<br/>+ contrat adapté"]
  Q3 -- Non --> S["SaaS ou API<br/>selon les compétences"]
```


Beaucoup d'organisations finissent avec une architecture **hybride** : un modèle local pour le tri, l'anonymisation et le volume ; une API frontière pour les 5 % de cas difficiles, après anonymisation. C'est exactement ce que vous saurez assembler avec n8n en L046.

🎮 **Défi** — Avant de passer à la suite, écrivez en une phrase le cas d'usage de votre organisation qui bénéficierait le plus d'un LLM local, et lequel ne devrait surtout pas y passer. Gardez cette feuille : elle servira de fil rouge jusqu'à la L046.

```quiz
{
  "type": "mise_en_situation",
  "q": "Un cabinet d'avocats veut résumer des pièces couvertes par le secret professionnel, environ 200 documents par mois. Que recommandez-vous en priorité ?",
  "options": [
    "Un abonnement grand public à un chatbot cloud",
    "Une API cloud sans contrat particulier",
    "Attendre qu'un modèle fermé devienne gratuit",
    "Un LLM local, car les données ne doivent pas sortir"
  ],
  "answer": 3,
  "explanation": "Première question de la grille : si les données sont interdites de sortie, la réponse est le local. Le volume modéré se traite très bien avec un modèle de 8 à 30 milliards de paramètres."
}
```

## 🧪 Exercice pratique

**Consigne.** Vous êtes consultant pour trois structures. Pour chacune, recommandez une option (local sur matériel, GPU loué, API cloud, SaaS) et justifiez en 3 à 5 lignes avec au moins deux critères de la grille et un chiffre de cette leçon.

1. *Cabinet comptable de 12 personnes* à Lyon : souhaite résumer et pré-saisir 3 000 factures fournisseurs par mois ; aucun informaticien, mais un prestataire externe disponible.
2. *Agence de communication de 4 personnes* : rédige des posts et des propositions commerciales, environ 50 prompts par jour, aucune donnée sensible.
3. *Laboratoire d'analyses médicales* : veut un assistant qui répond aux questions du personnel à partir de ses 400 procédures internes (PDF), connexion Internet instable sur un site.

**Critères de réussite.**
- Chaque recommandation cite au moins deux critères (confidentialité, coût, latence, souveraineté, compétences).
- Au moins une recommandation s'appuie sur un calcul de coût (location à l'heure ou investissement).
- Le cas 2 ne conclut **pas** au local « par principe ».

**Pistes de corrigé.**
1. Données comptables de clients, volume régulier élevé : **local** (mini-PC ou serveur avec GPU 24–32 Go, modèle 27B) installé par le prestataire ; alternative transitoire : GPU loué chez un hébergeur français (L40S 1,40 € HT/h) le temps de valider le flux.
2. Aucune donnée sensible, faible volume, zéro compétence : **SaaS** (abonnement) ; le local coûterait plus en temps qu'il ne rapporterait.
3. Données de santé et procédures internes, site mal connecté : **local** avec un assistant documentaire (RAG, module 11) sur Open WebUI ; un Mac Studio ou un PC avec RTX 4090 suffit pour un modèle 27B et quelques utilisateurs simultanés.

## ✅ Auto-évaluation express

1. Un modèle « à poids ouverts » est-il forcément utilisable commercialement ?
2. Citez deux coûts cachés d'un LLM local qui n'apparaissent pas sur une facture de tokens.
3. Pourquoi le fait qu'un modèle ouvert soit chinois ne pose-t-il pas de problème de transfert de données quand il tourne en local ?

*Réponses :* 1. Non : cela dépend de la licence (Apache 2.0 / MIT = libre ; licences « communautaires » Llama, Kimi K3, Muse = conditions et seuils de revenus). 2. Le temps humain (installation, maintenance, choix des modèles) et le matériel (achat, électricité) ; aussi l'écart de qualité éventuel qui peut exiger des reprises manuelles. 3. Les poids sont un fichier de nombres exécuté sur votre machine ; aucune donnée n'est envoyée à l'éditeur. La question de souveraineté porte sur la dépendance future, pas sur la fuite de données.

## 📚 Pour aller plus loin
- [Ollama — Documentation officielle](https://docs.ollama.com) 🇬🇧 — point d'entrée de l'outil que nous installerons en L043, avec la distinction modèles locaux / modèles cloud.
- [Pinggy — Best Local LLM Tools and Models in 2026](https://pinggy.io/blog/top_5_local_llm_tools_and_models/) 🇬🇧 — panorama des outils et des modèles recommandés par taille de mémoire (mis à jour en octobre 2026).
- [Artificial Analysis — Recent open weights model launches](https://www.artificialanalysis.ai/articles/recent-open-weights-model-launches) 🇬🇧 — pour mesurer l'écart réel entre modèles ouverts et fermés.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — les obligations RGPD qui restent applicables même en local.
- [Scaleway — Tarifs GPU](https://www.scaleway.com/en/pricing/gpu) 🇬🇧 — grille d'un hébergeur français pour vos calculs de location à l'heure.

> 🗺️ **Et maintenant ?** — Vous savez *pourquoi* passer au local ; la leçon L042 vous apprend à vérifier *si votre machine en est capable* (mémoire, carte graphique, vitesse).
