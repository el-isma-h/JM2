---
id: L046
module: M10
level: N2
title: "Brancher un LLM local sur n8n et vos applications (API compatible OpenAI)"
minutes: 60
objectives:
  - "Expliquer pourquoi l'API compatible OpenAI est devenue le « port USB » des LLM et comment elle permet de remplacer un modèle cloud par un modèle local sans réécrire une application"
  - "Construire un workflow n8n qui utilise un modèle Ollama ou LM Studio (nœud Ollama Chat Model, nœud OpenAI avec base URL locale) avec gestion des erreurs"
  - "Déployer ensemble Ollama, n8n et Open WebUI avec Docker Compose en réglant correctement le réseau entre conteneurs"
  - "Écrire un script Python ou TypeScript « hybride » qui bascule entre modèle local et API cloud selon la sensibilité des données"
skills: ["C2.1", "C2.3"]
sources:
  - { title: "n8n — LangChain in n8n (cluster nodes, chat models dont Ollama)", url: "https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md", lang: "en" }
  - { title: "n8n — Install with Docker", url: "https://docs.n8n.io/deploy/host-n8n/install-options/install-with-docker.md", lang: "en" }
  - { title: "n8n — MCP servers and MCP Client Tool", url: "https://docs.n8n.io/build/integrate-ai/mcp-servers.md", lang: "en" }
  - { title: "n8n Academy — N8N103 In Practice: AI, Testing & Best Practices", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about", lang: "en" }
  - { title: "Ollama — Documentation officielle", url: "https://docs.ollama.com", lang: "en" }
  - { title: "Open WebUI — Quick Start", url: "https://docs.openwebui.com/getting-started/quick-start/", lang: "en" }
  - { title: "LM Studio — Documentation", url: "https://www.lmstudio.ai/docs", lang: "en" }
  - { title: "Hugging Face — Inference Providers, premier appel", url: "https://huggingface.co/docs/inference-providers/main/guides/first-api-call", lang: "en" }
---

# Brancher un LLM local sur n8n et vos applications (API compatible OpenAI)

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 10

## 🎯 Ce que vous saurez faire
- Remplacer, dans un workflow n8n existant (modules 8 et 9), le nœud OpenAI par votre modèle local en cinq minutes.
- Faire cohabiter Ollama, n8n et Open WebUI sur une machine avec Docker Compose, sans vous battre avec `localhost`.
- Écrire un script qui envoie les données sensibles au modèle local et le reste à une API cloud : l'architecture hybride promise en L041.
- Diagnostiquer les trois pannes classiques (réseau Docker, modèle non chargé, contexte trop grand).

> 🧭 **En clair** — Vous avez maintenant votre chef cuisinier à domicile ; il faut lui faire parvenir les commandes de vos logiciels. Bonne nouvelle : presque tous les logiciels ont appris à passer commande avec le même bon de commande, celui d'OpenAI. Il suffit donc de changer **l'adresse de livraison** (la *base URL*) pour que la commande arrive chez votre chef maison plutôt qu'au restaurant. n8n devient votre maître d'hôtel : il prend les demandes (un e-mail, un formulaire), les transmet au chef, et range le résultat. Et pour les plats confidentiels, une règle simple : ils ne sortent jamais de la maison, même si le chef est malade.

## 1. L'API compatible OpenAI : le « port USB » des LLM

En 2023, OpenAI a publié le format de son API de chat : une requête HTTP `POST /v1/chat/completions` avec un tableau de `messages` (`system`, `user`, `assistant`), une réponse dans `choices[0].message.content`. Ce format est devenu un **standard de fait**. En novembre 2026, le respectent : Ollama (`localhost:11434/v1`), LM Studio (`localhost:1234/v1`), llama.cpp `llama-server` (`:8080/v1`), vLLM (`:8000/v1`), KoboldCpp (`:5001/v1`), LocalAI, Jan ; côté cloud, Mistral, xAI, Perplexity, le routeur Hugging Face (`router.huggingface.co/v1`) et bien d'autres.

Conséquence pratique : **une application écrite pour OpenAI n'a besoin que de deux changements pour parler à un modèle local** : la `base_url` et le nom du `model`. La clé API devient une chaîne quelconque (Ollama l'ignore). C'est ce qui rend l'architecture hybride triviale : même code, deux configurations.

```
Votre application / n8n / Open WebUI
        │  POST /v1/chat/completions  { model, messages, temperature, stream }
        ▼
┌───────────────────────────────────────────────────────────────┐
│  base_url = http://localhost:11434/v1   → Ollama   (local)     │
│  base_url = http://localhost:1234/v1    → LM Studio (local)    │
│  base_url = https://api.openai.com/v1   → OpenAI   (cloud)     │
│  base_url = https://api.mistral.ai/v1   → Mistral  (cloud, FR) │
└───────────────────────────────────────────────────────────────┘
```

> 💡 **À retenir** — Ne codez jamais `base_url`, `model` ni clé en dur. Lisez-les dans des variables d'environnement (`OPENAI_BASE_URL`, `OPENAI_API_KEY`, `MODELE`). Basculer de local à cloud devient une ligne de configuration, pas une mise à jour de code.

```quiz
{
  "q": "Une application fonctionne avec l'API OpenAI. Que faut-il changer, au minimum, pour qu'elle utilise votre modèle Ollama ?",
  "options": [
    "Tout le code, car les formats sont différents",
    "Uniquement la clé API",
    "Le système d'exploitation du serveur",
    "L'adresse de base (base_url) et le nom du modèle"
  ],
  "answer": 3,
  "explanation": "Ollama parle le même format que l'API OpenAI sur http://localhost:11434/v1. On change l'adresse et le nom du modèle ; la clé peut être une chaîne quelconque."
}
```


Ce que la compatibilité ne couvre pas toujours : certains paramètres propres au local (`num_ctx` d'Ollama n'est pas dans le format OpenAI ; fixez-le dans un Modelfile, L043), les fonctionnalités les plus récentes (certains formats de sortie structurée, les outils avancés) et les modèles multimodaux (vérifiez que votre serveur accepte les images dans `content`).

## 2. Brancher Ollama sur n8n

n8n propose deux chemins. Le dossier de recherche du module confirme que les « cluster nodes » IA de n8n (fondés sur LangChain) incluent nativement un sous-nœud de modèle **Ollama Chat Model**, à côté d'OpenAI et d'Anthropic.

### 2.1 Chemin 1 : le sous-nœud Ollama Chat Model (recommandé)

1. Dans un workflow, ajoutez un nœud racine IA : **Basic LLM Chain** (une question, une réponse), **AI Agent** (outils + mémoire) ou **Summarization Chain**.
2. Sur la prise « Model » du nœud, choisissez **Ollama Chat Model**.
3. Créez un *credential* Ollama avec l'URL de base : `http://localhost:11434` si n8n tourne directement sur la machine, `http://host.docker.internal:11434` si n8n est dans Docker Desktop (macOS, Windows), ou `http://ollama:11434` si les deux sont dans le même Docker Compose (section 3).
4. Sélectionnez le modèle dans la liste (n8n interroge `/api/tags` : vous devez voir vos modèles de `ollama list`).
5. Pour un chatbot, déclenchez avec un **Chat Trigger** ; pour une automatisation, avec un Webhook, un formulaire ou un déclencheur planifié.

Un workflow typique « boîte mail → tri → réponse » (module 8) devient local en remplaçant uniquement le sous-nœud de modèle. La mémoire (Simple Memory, Postgres, Redis) et les outils restent identiques : la mémoire ne se connecte qu'au nœud AI Agent.

### 2.2 Chemin 2 : le nœud OpenAI avec une base URL locale

Si votre workflow utilise déjà le nœud **OpenAI Chat Model** ou le nœud OpenAI classique, ouvrez le *credential* OpenAI et modifiez le champ **Base URL** vers `http://localhost:11434/v1` (ou `:1234/v1` pour LM Studio), avec une clé quelconque. Même méthode pour un **HTTP Request** manuel vers `/v1/chat/completions`. Ce chemin est utile pour LM Studio, llama-server ou vLLM, qui n'ont pas de sous-nœud dédié.

> ⚠️ **Piège fréquent** — Le nom du modèle doit être **exactement** celui d'Ollama (`qwen3.8:27b`, `compta-assistant`) ; un nom OpenAI (`gpt-4o`) laissé par défaut renvoie une erreur « model not found ». Deuxième piège : n8n ouvre souvent plusieurs exécutions en parallèle ; Ollama les mettra en file (ou les traitera en parallèle selon `OLLAMA_NUM_PARALLEL`, à régler avec la mémoire disponible).

### 2.3 Gérer les erreurs (compétence C2.1)

Un modèle local peut être arrêté, surchargé ou trop lent. Dans n8n :
- activez « Retry On Fail » sur le nœud IA (2–3 essais, 5 s d'attente) ;
- ajoutez un **Error Trigger** ou une branche `Continue (using error output)` qui bascule sur un modèle cloud **uniquement si les données l'autorisent**, sinon notifie un humain ;
- fixez un **timeout** cohérent avec la vitesse mesurée en L042 (un 27B sur M4 Pro à 11 tok/s met ~45 s pour 500 tokens) ;
- journalisez `model`, durée et nombre de tokens pour suivre la charge.

> 🔗 **Documentation officielle** — [n8n — LangChain in n8n (cluster nodes)](https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md) et [n8n — MCP servers](https://docs.n8n.io/build/integrate-ai/mcp-servers.md)

```mission
{
  "title": "Repérez les modèles et la mémoire disponibles dans les nœuds IA de n8n",
  "url": "https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md",
  "steps": ["Ouvrez la page « LangChain in n8n » de la documentation", "Repérez la distinction entre nœuds racines (root nodes) et sous-nœuds (sub-nodes)", "Cherchez la liste des sous-nœuds de modèles de chat et la règle de connexion de la mémoire"],
  "question": "Citez trois sous-nœuds de modèles de chat proposés par n8n, et dites à quel nœud racine la mémoire peut se connecter.",
  "hint": "L'un de ces sous-nœuds porte le nom de l'outil installé en L043.",
  "answer": "Par exemple Anthropic, OpenAI et Ollama Chat Model ; la mémoire (Simple, Postgres, Redis) ne se connecte qu'au nœud AI Agent (relevé nov. 2026).",
  "xp": 15
}
```


## 3. Tout-en-un avec Docker Compose : Ollama + n8n + Open WebUI

Sur un serveur Linux d'équipe, ces trois services se déploient ensemble. Le point délicat est le **réseau** : dans Docker, chaque conteneur a son propre `localhost`. Les services se joignent par leur **nom de service**.

```yaml
# fichier : docker-compose.yml — Ollama + n8n + Open WebUI sur un serveur Linux
# Lancer : docker compose up -d   ·   Arrêter : docker compose down (les volumes sont conservés)
services:

  ollama:
    image: ollama/ollama:latest
    container_name: ollama
    volumes:
      - ollama_models:/root/.ollama          # les modèles téléchargés (plusieurs dizaines de Go)
    ports:
      - "11434:11434"                        # accessible aussi depuis l'hôte pour la CLI / tests curl
    restart: unless-stopped
    # Pour une carte NVIDIA : installer le NVIDIA Container Toolkit puis décommenter :
    # deploy:
    #   resources:
    #     reservations:
    #       devices:
    #         - driver: nvidia
    #           count: all
    #           capabilities: [gpu]

  n8n:
    image: docker.n8n.io/n8nio/n8n
    container_name: n8n
    ports:
      - "5678:5678"
    environment:
      - GENERIC_TIMEZONE=Europe/Paris
      - TZ=Europe/Paris
      - N8N_ENCRYPTION_KEY=${N8N_ENCRYPTION_KEY}   # lue depuis un fichier .env, jamais en clair ici
      # Dans n8n, l'URL de base du credential Ollama sera : http://ollama:11434
    volumes:
      - n8n_data:/home/node/.n8n
    depends_on:
      - ollama
    restart: unless-stopped

  open-webui:
    image: ghcr.io/open-webui/open-webui:main
    container_name: open-webui
    ports:
      - "3000:8080"                          # interface sur http://serveur:3000
    environment:
      - OLLAMA_BASE_URL=http://ollama:11434  # nom du service, pas localhost
    volumes:
      - open_webui_data:/app/backend/data
    depends_on:
      - ollama
    restart: unless-stopped

volumes:
  ollama_models:
  n8n_data:
  open_webui_data:
```

> 💡 **Autrement dit** — Docker Compose, c'est le plan de l'immeuble : il dit quels appartements (conteneurs) existent — Ollama, n8n, Open WebUI — et comment ils communiquent. Dans cet immeuble, « localhost » veut dire « mon propre appartement » : pour joindre le voisin, on utilise son nom sur la boîte aux lettres (`ollama`), pas « chez moi ».

```mermaid
flowchart LR
  subgraph Serveur["Serveur (Docker Compose)"]
    N["n8n :5678"] -->|"http://ollama:11434"| O["ollama :11434"]
    W["open-webui :8080<br/>(publié en :3000)"] -->|"http://ollama:11434"| O
  end
  U["Navigateur des collègues"] --> N
  U --> W
```

Après `docker compose up -d`, téléchargez un premier modèle **dans** le conteneur : `docker exec -it ollama ollama pull qwen3.8:27b`. Puis : n8n sur le port 5678 (credential Ollama → `http://ollama:11434`), Open WebUI sur le port 3000, et depuis l'hôte, `curl http://localhost:11434/v1/models` pour vérifier.

Deux rappels issus de la documentation n8n : le volume `n8n_data` monté sur `/home/node/.n8n` contient vos workflows et *credentials* chiffrés par `N8N_ENCRYPTION_KEY` (perdez la clé, perdez les credentials) ; la page « Install with Docker » renvoie désormais vers Docker Compose comme méthode recommandée, et une base PostgreSQL (`DB_TYPE=postgresdb`) est conseillée au-delà d'un usage de test.

> 💡 **À retenir** — Règle réseau Docker : `localhost` = le conteneur lui-même ; `host.docker.internal` = la machine hôte (Docker Desktop) ; `nom-du-service` = un autre conteneur du même Compose. Neuf pannes « n8n ne voit pas Ollama » sur dix viennent de là.

```quiz
{
  "type": "mise_en_situation",
  "q": "n8n et Ollama tournent dans le même Docker Compose (service nommé `ollama`). Le credential Ollama de n8n contient `http://localhost:11434` et la liste des modèles reste vide. Que corrigez-vous ?",
  "options": [
    "Réinstaller Ollama directement sur l'hôte",
    "Remplacer l'URL par http://ollama:11434",
    "Passer le port à 5678, celui de n8n",
    "Ajouter une clé API OpenAI au credential"
  ],
  "answer": 1,
  "explanation": "Dans un conteneur, localhost désigne le conteneur n8n lui-même. Entre services d'un même Compose, on utilise le nom du service : http://ollama:11434."
}
```

```mission
{
  "title": "Vérifiez dans la doc n8n le port, le dossier de données et la méthode recommandée",
  "url": "https://docs.n8n.io/deploy/host-n8n/install-options/install-with-docker.md",
  "steps": ["Ouvrez la page « Install with Docker » de la documentation n8n", "Repérez le port exposé par n8n et le chemin où le volume est monté", "Cherchez la variable qui chiffre les credentials et la méthode d'installation désormais recommandée"],
  "question": "Sur quel port n8n écoute-t-il, dans quel dossier du conteneur sont stockées ses données, quelle variable chiffre les credentials, et quelle méthode la page recommande-t-elle ?",
  "hint": "La méthode recommandée est une variante de Docker qui décrit plusieurs services dans un seul fichier.",
  "answer": "Port 5678 ; données dans /home/node/.n8n (volume n8n_data) ; N8N_ENCRYPTION_KEY ; la page renvoie vers Docker Compose comme méthode recommandée (relevé nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```


## 4. Depuis vos applications : le script hybride

Voici le schéma le plus utile de ce module : **router** chaque requête vers le modèle local ou le cloud selon la sensibilité des données. Le SDK est le même ; seule la configuration change.

```python
# fichier : routeur_hybride.py — Python 3.12+, pip install openai
# Variables d'environnement attendues (aucune clé dans le code) :
#   LOCAL_BASE_URL  (défaut http://localhost:11434/v1)   LOCAL_MODEL  (défaut qwen3.8:27b)
#   CLOUD_BASE_URL  (ex. https://api.mistral.ai/v1)      CLOUD_MODEL  (ex. mistral-small-4)
#   CLOUD_API_KEY   (clé du fournisseur cloud)
import os
import re
from openai import OpenAI, APIConnectionError

local = OpenAI(
    base_url=os.environ.get("LOCAL_BASE_URL", "http://localhost:11434/v1"),
    api_key="ollama",  # ignorée par Ollama / LM Studio, mais exigée par le SDK
)
cloud = OpenAI(
    base_url=os.environ.get("CLOUD_BASE_URL", "https://api.openai.com/v1"),
    api_key=os.environ.get("CLOUD_API_KEY", ""),
) if os.environ.get("CLOUD_API_KEY") else None

MODELE_LOCAL = os.environ.get("LOCAL_MODEL", "qwen3.8:27b")
MODELE_CLOUD = os.environ.get("CLOUD_MODEL", "gpt-6-mini")

# Détecteurs très simples de données sensibles : IBAN, numéro de sécurité sociale, e-mail.
# En production, on utiliserait un vrai outil de détection (module 15), ceci illustre le principe.
MOTIFS_SENSIBLES = [
    re.compile(r"\bFR\d{2}(?:\s?\d{4}){5}\s?\d{3}\b"),          # IBAN français
    re.compile(r"\b[12]\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3}"), # NIR (sécurité sociale)
    re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),                       # e-mail
]

def est_sensible(texte: str) -> bool:
    return any(m.search(texte) for m in MOTIFS_SENSIBLES)

def demander(texte: str, consigne: str) -> tuple[str, str]:
    """Retourne (réponse, moteur utilisé). Le local est obligatoire si le texte est sensible."""
    messages = [{"role": "system", "content": consigne}, {"role": "user", "content": texte}]
    sensible = est_sensible(texte)
    cibles = [("local", local, MODELE_LOCAL)]
    if not sensible and cloud is not None:
        cibles.append(("cloud", cloud, MODELE_CLOUD))  # repli cloud autorisé seulement si non sensible
    derniere_erreur = None
    for nom, client, modele in cibles:
        try:
            r = client.chat.completions.create(model=modele, messages=messages, temperature=0.2)
            return r.choices[0].message.content.strip(), nom
        except APIConnectionError as e:   # serveur local éteint, réseau coupé…
            derniere_erreur = e
            continue
    raise RuntimeError(f"Aucun moteur disponible (données sensibles = {sensible}) : {derniere_erreur}")

if __name__ == "__main__":
    consigne = "Tu es l'assistant d'un cabinet comptable français. Réponds en français, en deux phrases."
    exemples = [
        "Quelle est la date limite de dépôt de la liasse fiscale pour un exercice clos au 31 décembre ?",
        "Le client Dupont (IBAN FR76 3000 6000 0112 3456 7890 189) demande un échéancier : que lui proposer ?",
    ]
    for texte in exemples:
        reponse, moteur = demander(texte, consigne)
        print(f"[{moteur.upper():5}] {reponse}\n")
```

Exécutez ce script une fois avec Ollama lancé, une fois Ollama arrêté : la première question bascule sur le cloud (si configuré), la seconde — qui contient un IBAN — refuse de partir et lève une erreur explicite. C'est exactement le comportement attendu par une politique d'usage (module 15).

> 💡 **Autrement dit** — Le script hybride fonctionne comme un vigile à la porte : avant de laisser sortir une demande vers le cloud, il vérifie qu'elle ne contient ni IBAN, ni numéro de sécurité sociale, ni e-mail. Si elle en contient, elle reste à la maison — et si le modèle local est en panne, le vigile préfère signaler le problème plutôt que de laisser filer les données.

La version TypeScript, pour une application web ou un service Node :

```typescript
// fichier : routeur_hybride.ts — Node 22+, npm install openai ; lancer : npx tsx routeur_hybride.ts
import OpenAI from "openai";

// Même principe : tout vient de l'environnement.
const local = new OpenAI({
  baseURL: process.env.LOCAL_BASE_URL ?? "http://localhost:11434/v1",
  apiKey: "ollama",
});
const cloud = process.env.CLOUD_API_KEY
  ? new OpenAI({ baseURL: process.env.CLOUD_BASE_URL, apiKey: process.env.CLOUD_API_KEY })
  : null;

const estSensible = (t: string): boolean =>
  /\bFR\d{2}(?:\s?\d{4}){5}\s?\d{3}\b/.test(t) || /[\w.+-]+@[\w-]+\.[\w.]+/.test(t);

export async function demander(texte: string, consigne: string): Promise<{ reponse: string; moteur: string }> {
  const messages = [
    { role: "system" as const, content: consigne },
    { role: "user" as const, content: texte },
  ];
  const cibles: Array<[string, OpenAI, string]> = [["local", local, process.env.LOCAL_MODEL ?? "qwen3.8:27b"]];
  if (!estSensible(texte) && cloud) cibles.push(["cloud", cloud, process.env.CLOUD_MODEL ?? "gpt-6-mini"]);

  for (const [moteur, client, model] of cibles) {
    try {
      const r = await client.chat.completions.create({ model, messages, temperature: 0.2 });
      return { reponse: r.choices[0]?.message?.content?.trim() ?? "", moteur };
    } catch (e) {
      if (e instanceof OpenAI.APIConnectionError) continue; // moteur injoignable : on tente le suivant
      throw e;                                                // autre erreur : on remonte
    }
  }
  throw new Error("Aucun moteur disponible pour cette requête.");
}

demander("Résume en une phrase l'intérêt d'un LLM local.", "Réponds en français.")
  .then(({ reponse, moteur }) => console.log(`[${moteur}] ${reponse}`))
  .catch(console.error);
```

## 5. Open WebUI comme façade, et le repli cloud « souverain »

Open WebUI (L044) accepte, en plus d'Ollama, des **connexions OpenAI** multiples : vous pouvez y déclarer LM Studio, un vLLM d'entreprise, l'API Mistral (hébergée en Europe) ou le routeur Hugging Face Inference Providers (`https://router.huggingface.co/v1`, qui donne accès à des dizaines de modèles ouverts hébergés chez Scaleway, Together, Groq… au tarif du fournisseur, sans marge, nov. 2026). Les utilisateurs choisissent alors le modèle dans un menu, et l'administrateur peut restreindre les modèles cloud à certains groupes. Résultat : une seule interface, des modèles locaux par défaut, un modèle cloud ouvert pour les tâches lourdes — en restant, si vous le souhaitez, sur des **poids ouverts hébergés en Europe**.

> 🔗 **Documentation officielle** — [Open WebUI — Quick Start](https://docs.openwebui.com/getting-started/quick-start/) et [Hugging Face — Inference Providers, premier appel](https://huggingface.co/docs/inference-providers/main/guides/first-api-call)

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : dans le script hybride, si Ollama est éteint, une demande contenant un IBAN est automatiquement envoyée au modèle cloud pour ne pas bloquer l'utilisateur.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : le cloud n'est ajouté aux cibles que si le texte n'est pas sensible. La demande contenant un IBAN lève une erreur explicite : la règle de confidentialité prime sur la disponibilité."
}
```

## 6. Dépannage des trois pannes classiques

| Panne | Diagnostic | Solution |
|---|---|---|
| n8n / Open WebUI : « connection refused » ou liste de modèles vide | Mauvaise adresse réseau Docker | `http://ollama:11434` (Compose), `http://host.docker.internal:11434` (Docker Desktop), `http://localhost:11434` (sans Docker) |
| Réponse très lente ou timeout | Modèle non chargé (premier appel), modèle sur CPU, contexte trop grand | `ollama ps` ; `OLLAMA_KEEP_ALIVE` plus long ; modèle plus petit ou `num_ctx` réduit (L042) |
| « model not found » | Nom de modèle d'un autre fournisseur ou tag inexact | Copier le nom depuis `ollama list` |
| Réponse tronquée | Fenêtre de contexte dépassée | Augmenter `num_ctx` dans un Modelfile, découper le document (module 11) |

🎮 **Défi** — Prenez n'importe quel workflow n8n d'un module précédent qui utilise un modèle cloud. Chronométrez le temps nécessaire pour le faire tourner en local. Objectif : moins de cinq minutes, sans toucher à autre chose que le sous-nœud de modèle et son *credential*.

## 🧪 Exercice pratique

**Consigne.** Construisez un workflow n8n « Tri de courrier entrant » entièrement local :

1. Déclencheur : un **Webhook** (ou un formulaire n8n) qui reçoit `{ "expediteur": "...", "objet": "...", "corps": "..." }`.
2. Un nœud **Basic LLM Chain** avec **Ollama Chat Model** (modèle de L043, température 0,2) et une consigne système : « Classe ce message en : facturation, technique, commercial, RH, autre. Réponds en JSON `{ "categorie": "...", "urgence": "faible|moyenne|haute", "resume": "..." }`. »
3. Un nœud **Code** ou **Structured Output Parser** qui valide le JSON ; en cas d'échec, une branche d'erreur qui envoie le message à un humain (nœud Email ou Slack) au lieu de deviner.
4. Un nœud **IF** sur `urgence == "haute"` qui notifie ; sinon, ajoute une ligne dans une **Data Table** ou une feuille de calcul.
5. Testez avec cinq messages de votre activité, dont un contenant une donnée sensible, et vérifiez avec `ollama ps` pendant l'exécution que tout reste local.

**Critères de réussite.** Le workflow s'exécute sans erreur sur les cinq messages ; le JSON est validé avant usage ; un message mal formé déclenche la branche humaine ; aucune clé cloud n'apparaît dans les *credentials* du workflow ; le temps par message est noté et cohérent avec la vitesse mesurée en L042.

**Pistes de corrigé.** Si la sortie n'est pas un JSON propre, renforcez la consigne (« Réponds uniquement par le JSON, sans texte autour ») et baissez la température à 0 ; les modèles de la famille Qwen3.8 et gpt-oss suivent bien cette consigne. Si n8n est dans Docker Desktop et Ollama sur l'hôte, l'URL du credential est `http://host.docker.internal:11434`. Pour aller plus loin, remplacez Basic LLM Chain par un **AI Agent** doté d'un outil « Call n8n Workflow » qui recherche le client dans votre CRM avant de classer.

## ✅ Auto-évaluation express

1. Quels sont les deux seuls paramètres à changer pour qu'une application « OpenAI » utilise Ollama ?
2. Dans un Docker Compose où Ollama est le service `ollama`, quelle URL n8n doit-il utiliser ?
3. Dans le script hybride, pourquoi la requête contenant un IBAN lève-t-elle une erreur quand Ollama est éteint, au lieu de partir vers le cloud ?

*Réponses :* 1. La `base_url` (`http://localhost:11434/v1`) et le nom du `model` (la clé devient quelconque). 2. `http://ollama:11434` (le nom du service ; `localhost` désignerait le conteneur n8n lui-même). 3. Parce que la liste des cibles n'inclut le cloud que si le texte n'est pas sensible : la politique de confidentialité est appliquée dans le code, pas laissée au hasard d'une panne.

## 📚 Pour aller plus loin
- [n8n — LangChain in n8n](https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md) 🇬🇧 — nœuds racines (chaînes, AI Agent) et sous-nœuds (modèles dont Ollama, mémoire, outils).
- [n8n — Install with Docker](https://docs.n8n.io/deploy/host-n8n/install-options/install-with-docker.md) 🇬🇧 — variables d'environnement, volume, chiffrement des credentials, et renvoi vers Docker Compose.
- [n8n Academy — N8N103 In Practice: AI, Testing & Best Practices](https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about) 🇬🇧 — le cours officiel sur les nœuds IA, les tests et le débogage ; nous vous encourageons à le suivre et à obtenir son badge en complément de ce module.
- [Ollama — Documentation](https://docs.ollama.com) 🇬🇧 — API native, compatibilité OpenAI, bibliothèques Python et JavaScript.
- [LM Studio — Documentation](https://www.lmstudio.ai/docs) 🇬🇧 — activer le serveur local sur le port 1234 pour le chemin 2.
- [Hugging Face — Inference Providers, premier appel](https://huggingface.co/docs/inference-providers/main/guides/first-api-call) 🇬🇧 — le repli cloud sur des modèles ouverts via un endpoint compatible OpenAI.

> 🗺️ **Et maintenant ?** — Votre IA locale est branchée sur vos outils ; le module 11 (L047) lui apprend à répondre à partir de *vos* documents, en commençant par les embeddings et la recherche par le sens.
