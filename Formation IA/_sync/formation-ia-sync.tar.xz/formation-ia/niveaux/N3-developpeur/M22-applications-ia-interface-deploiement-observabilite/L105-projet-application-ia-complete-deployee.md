---
id: L105
module: M22
level: N3
title: "Projet : application IA complète déployée"
minutes: 65
objectives:
  - "Rédiger un cahier des charges d'application IA avec des exigences non fonctionnelles mesurables (latence, coût, qualité, RGPD)"
  - "Construire une architecture de production reproductible (Next.js 16, Vercel AI SDK, Postgres/pgvector, worker, Docker) et choisir entre Vercel et un VPS derrière Caddy"
  - "Appliquer une checklist de mise en production couvrant sécurité, coûts, fiabilité, observabilité, qualité et exploitation"
  - "Évaluer un projet déployé avec une grille critériée alignée sur les compétences C3.5 et C3.1"
skills: ["C3.5", "C3.1"]
sources:
  - { title: "Vercel AI SDK — documentation", url: "https://ai-sdk.dev", lang: "en" }
  - { title: "Next.js — documentation (déploiement, output standalone)", url: "https://nextjs.org/docs", lang: "en" }
  - { title: "Vercel — documentation", url: "https://vercel.com/docs", lang: "en" }
  - { title: "Docker — documentation (Dockerfile, Compose)", url: "https://docs.docker.com", lang: "en" }
  - { title: "Caddy — documentation (HTTPS automatique, reverse_proxy)", url: "https://caddyserver.com/docs", lang: "en" }
  - { title: "pgvector", url: "https://github.com/pgvector/pgvector", lang: "en" }
  - { title: "Langfuse", url: "https://langfuse.com", lang: "en" }
  - { title: "promptfoo — documentation", url: "https://www.promptfoo.dev/docs", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — Rate limits", url: "https://platform.claude.com/docs/en/api/rate-limits", lang: "en" }
  - { title: "The Twelve-Factor App", url: "https://12factor.net", lang: "en" }
  - { title: "Full Stack Deep Learning — LLM Bootcamp 2023 (source d'inspiration)", url: "https://fullstackdeeplearning.com/llm-bootcamp/spring-2023/", lang: "en" }
---

# Projet : application IA complète déployée

> ⏱ 65 min · 🎯 Niveau 3 · 📚 Module 22

## 🎯 Ce que vous saurez faire
- Transformer une demande floue (« un assistant pour le cabinet ») en **cahier des charges** chiffré et vérifiable.
- Assembler les briques des leçons L101 à L104 dans une **architecture de production** que vous savez justifier.
- Déployer la même application sur **Vercel** ou sur un **VPS Docker + Caddy**, avec HTTPS, test de fumée et retour arrière.
- Passer une **checklist de mise en production** point par point, puis vous auto-évaluer avec la grille du jury.

> 🧭 **En clair** — Jusqu'ici, vous avez fabriqué les pièces d'une voiture : le moteur (le chat), la boîte de vitesses (la file d'attente), le tableau de bord (les traces), le contrôle technique (la CI). Ce projet consiste à **assembler la voiture, l'immatriculer et la confier à de vrais conducteurs**. On commence par le cahier des charges : ce qu'elle doit faire, à quelle vitesse, pour quel budget de carburant. On choisit ensuite le garage : Vercel (un service clé en main) ou un VPS (votre propre garage, plus libre mais à entretenir). Enfin, on passe une checklist point par point, preuves à l'appui, comme un pilote avant le décollage.

## 1. Le cahier des charges : Compta-Chat v1.0

Depuis L101, vous construisez Compta-Chat pour un cabinet d'expertise comptable rennais de 40 collaborateurs. Jusqu'ici, chaque leçon ajoutait une brique ; aujourd'hui, l'associée gérante vous demande une date de mise en service et un budget. C'est le moment où un prototype devient un **produit** : il faut écrire ce qu'il doit faire, à quel niveau de qualité, pour quel coût, et comment on saura qu'il le fait.

Un bon cahier des charges d'application IA comporte deux colonnes que les projets classiques n'ont pas : la **qualité des réponses** (qui se mesure par une suite d'évaluations, pas par un « ça a l'air bien ») et le **coût variable** (chaque question est facturée en tokens).

### 1.1 Exigences fonctionnelles (priorisation MoSCoW)

| # | Exigence | Priorité | Leçon source |
|---|---|---|---|
| F1 | Chat en streaming, authentifié, historique limité à 30 messages | Must | L101 |
| F2 | Outils `rechercherClient` (Postgres) et `echeanceTva` exécutés côté serveur | Must | L101 |
| F3 | Résumé asynchrone de lots de PDF (file pg-boss, worker séparé, état consultable) | Must | L102 |
| F4 | Quotas par utilisateur et budget global mensuel bloquant | Must | L102 |
| F5 | Cache sémantique pgvector sur les questions récurrentes | Should | L102 |
| F6 | Pouce haut / bas relié à la trace Langfuse | Should | L103 |
| F7 | Nouvelle version de prompt activable par pourcentage d'utilisateurs | Should | L104 |
| F8 | Export d'une conversation en PDF | Could | — |
| F9 | Accès des clients du cabinet (externe) | Won't (v1) | — |

Le « Won't » est aussi important que le « Must » : ouvrir l'outil aux clients du cabinet changerait le modèle de menace (OWASP, M23), la base légale RGPD et le budget. L'écrire noir sur blanc évite la dérive du périmètre.

### 1.2 Exigences non fonctionnelles mesurables

| Domaine | Exigence | Comment on la vérifie |
|---|---|---|
| Latence | *Time to first token* p95 < 2 s ; réponse complète p95 < 9 s | Tableau de bord Langfuse (L103), seuil `latenceP95Max` en CI (L104) |
| Qualité | ≥ 92 % des assertions promptfoo réussies ; cas de sécurité à 100 % | Job `evaluation-prompts` bloquant |
| Coût | ≤ 0,006 $ par réponse en moyenne ; budget mensuel plafonné à 300 $ | `verifier-seuils.mjs` + table `appels_llm` + alerte |
| Disponibilité | Heures ouvrées : 99 % ; dégradation propre si le fournisseur est indisponible | `/api/health`, modèle de repli, message d'erreur explicite |
| Sécurité | Aucune clé dans le dépôt ni dans le bundle ; toutes les routes authentifiées | Analyse du dépôt, revue de `NEXT_PUBLIC_*`, test 401 |
| RGPD | Hébergement UE, rétention des traces 30 jours, masquage des données sensibles | Registre des traitements, paramètres Langfuse |
| Exploitabilité | Déploiement en une commande, retour arrière < 5 min, sauvegarde quotidienne | Exercice de restauration chronométré |

### 1.3 Le budget, calculé avant d'écrire une ligne

Hypothèse : 40 collaborateurs × 25 questions par jour = 1 000 questions/jour, 22 jours ouvrés. Une question type consomme 3 000 tokens d'entrée (dont 2 000 de prompt système et définitions d'outils mis en cache) et 400 tokens de sortie. Tarifs officiels (nov. 2026, page [Pricing](https://platform.claude.com/docs/en/about-claude/pricing)) :

| Modèle | Entrée non cachée (1 000 tok) | Lecture cache (2 000 tok) | Sortie (400 tok) | Par question | Par mois |
|---|---|---|---|---|---|
| Claude Sonnet 5.5 (2 $ / 0,10 $ / 10 $ par MTok) | 0,0020 $ | 0,0002 $ | 0,0040 $ | ≈ 0,0062 $ | ≈ 136 $ |
| Claude Haiku 5.5 (0,10 $ / 0,01 $ / 0,50 $ par MTok, ≤ 100k) | 0,0001 $ | 0,00002 $ | 0,0002 $ | ≈ 0,0003 $ | ≈ 7 $ |

Ces chiffres ignorent les écritures de cache (1,25 × le tarif d'entrée, rares si le préfixe est stable) et les étapes d'outils supplémentaires (chaque étape renvoie l'historique au modèle). Comptez une marge de 50 %. Conclusion pratique : Sonnet 5.5 pour le chat, Haiku 5.5 pour les résumés en lot (avec la Batch API à −50 % quand le délai le permet, L102) ; le budget de 300 $ couvre largement la v1, et le plafond global protège contre l'imprévu.

> 💡 **Autrement dit** — Le calcul tient en une ligne : (tokens d'entrée × prix d'entrée + tokens de sortie × prix de sortie) ÷ 1 000 000, multiplié par le nombre de questions. Le cache fait payer à prix cassé les 2 000 tokens répétés à chaque question, d'où l'écart entre la colonne « entrée non cachée » et la colonne « lecture cache ».

> 💡 **À retenir** — Un cahier des charges d'application IA est complet quand chaque exigence a une **mesure** et un **endroit où elle est vérifiée** (CI, traces, tableau de bord, exercice). Si vous ne savez pas où une exigence est contrôlée, elle ne l'est pas.

```quiz
{
  "q": "Laquelle de ces exigences est formulée correctement pour un cahier des charges d'application IA ?",
  "options": [
    "L'assistant doit être rapide et agréable",
    "Les réponses doivent être de bonne qualité",
    "Le coût mensuel doit rester raisonnable",
    "TTFT p95 < 2 s, vérifié dans Langfuse et en CI"
  ],
  "answer": 3,
  "explanation": "Une exigence complète a une mesure chiffrée et un endroit où elle est contrôlée ; les trois autres ne sont pas vérifiables."
}
```

## 2. L'architecture cible

```
                    ┌────────────────────────── Navigateur (useChat) ──────────────────────────┐
                    └───────────────────────────────────┬──────────────────────────────────────┘
                                                        │ HTTPS (Caddy : Let's Encrypt automatique / Vercel)
                    ┌───────────────────────────────────▼──────────────────────────────────────┐
                    │ Next.js 16 (App Router, runtime Node)                                    │
                    │  /api/chat  → auth → quotas → cache sémantique → streamText (outils)     │
                    │  /api/jobs  → pg-boss (202)        /api/feedback → Langfuse              │
                    │  /api/health → SELECT 1 (jamais d'appel LLM)                              │
                    └──────┬───────────────────────┬───────────────────────────┬───────────────┘
                           │ SQL                    │ HTTPS (clé serveur)        │ OTLP
                ┌──────────▼─────────┐   ┌──────────▼──────────┐     ┌──────────▼─────────┐
                │ Postgres + pgvector │   │ Anthropic (Sonnet,  │     │ Langfuse (traces,   │
                │ clients, appels_llm │   │ Haiku) / repli      │     │ coûts, feedback)    │
                │ cache, file pg-boss │   │ OpenAI              │     └────────────────────┘
                └──────────▲─────────┘   └──────────▲──────────┘
                           │                        │
                ┌──────────┴────────────────────────┴──┐
                │ Worker (processus séparé, pg-boss)   │  résumés de PDF, Batch API
                └──────────────────────────────────────┘
```

Deux choix structurants méritent d'être expliqués au jury.

**Postgres fait trois métiers** : données métier, vecteurs (pgvector) et file d'attente (pg-boss). Pour 40 utilisateurs, c'est un atout : un seul service à sauvegarder, surveiller et sécuriser. Le jour où la file traitera des dizaines de milliers de jobs par heure, vous sortirez la file vers Redis/BullMQ ; pas avant.

**Le worker est un processus distinct**. Il ne doit pas vivre dans une fonction serverless : il tourne en continu, consomme la file et peut être redémarré sans couper le chat.

### 2.1 Vercel ou VPS ?

| Critère | Vercel + Postgres managé | VPS (Docker Compose + Caddy) |
|---|---|---|
| Mise en route | Minutes : `git push`, previews par pull request | Une demi-journée : serveur, pare-feu, DNS, Compose |
| Worker permanent | Non prévu par les fonctions : hébergez-le ailleurs (petit conteneur) | Un service de plus dans Compose |
| Durée max d'une requête | Limitée par `maxDuration` (selon l'offre, à vérifier sur la doc Vercel) | Celle que vous configurez (Caddy, Node) |
| Données et RGPD | Choisir une région UE pour les fonctions et la base | Hébergeur français ou UE, maîtrise complète |
| Coût fixe | Abonnement + base managée | Prix du VPS, sauvegardes à organiser vous-même |
| Retour arrière | *Instant Rollback* dans le tableau de bord | Image Docker taguée par commit (section 3.5) |
| Exploitation | Quasi nulle | Mises à jour système, supervision, sauvegardes : à votre charge |

Règle de décision proposée : **Vercel** si l'équipe n'a pas d'administrateur système et que le worker reste léger ; **VPS** si les données doivent rester chez un hébergeur choisi, si les jobs sont longs, ou si vous voulez tout faire tenir dans un budget fixe. Le projet évalué doit être déployé sur **l'une** des deux cibles ; le dossier doit justifier le choix.

> ⚠️ **Piège fréquent** — Choisir Vercel puis lancer le worker « dans » une route API appelée par un cron externe. La fonction est coupée à `maxDuration`, les jobs restent bloqués à l'état actif, puis sont rejoués : vous payez deux fois. Un worker est un processus long ; donnez-lui un vrai hébergement.

```quiz
{
  "q": "Petite équipe sans administrateur système, worker léger, aucune contrainte d'hébergeur particulier. Quelle cible de déploiement proposez-vous ?",
  "options": [
    "Vercel, avec le worker hébergé à part dans un petit conteneur",
    "Un VPS, seule option compatible avec Next.js",
    "Vercel, avec le worker lancé par un cron dans une route API",
    "Pas de déploiement : l'application reste en local"
  ],
  "answer": 0,
  "explanation": "C'est la règle de décision de la section 2.1. Le worker dans une route API appelée par cron est justement le piège signalé : coupé à maxDuration, il rejoue et facture deux fois."
}
```

## 3. Étapes de réalisation

### 3.1 Jalon 1 — configuration validée au démarrage

En 2011, Adam Wiggins, cofondateur de Heroku, publie *The Twelve-Factor App* ; son facteur III, « stockez la configuration dans l'environnement », est resté la règle d'or. Allons un cran plus loin : l'application **refuse de démarrer** si la configuration est incomplète, plutôt que d'échouer au premier appel d'un utilisateur.

```typescript
// src/lib/env.ts — validation de la configuration au démarrage (Zod)
import { z } from "zod";

const schema = z.object({
  ANTHROPIC_API_KEY: z.string().startsWith("sk-ant-"),
  DATABASE_URL: z.string().url(),
  AUTH_SECRET: z.string().min(32),
  AI_MODEL: z.string().default("claude-sonnet-5-5"),
  LANGFUSE_PUBLIC_KEY: z.string().startsWith("pk-lf-"),
  LANGFUSE_SECRET_KEY: z.string().startsWith("sk-lf-"),
  LANGFUSE_BASE_URL: z.string().url(),
  BUDGET_MENSUEL_USD: z.coerce.number().positive().default(300),
  PROMPT_VERSION: z.string().default("dev"),
});

const resultat = schema.safeParse(process.env);
if (!resultat.success) {
  // On affiche les NOMS des variables fautives, jamais leurs valeurs
  console.error("Configuration invalide :", resultat.error.issues.map((i) => i.path.join(".")).join(", "));
  throw new Error("Démarrage interrompu : configuration incomplète");
}
export const env = resultat.data;
```

Importez ce module en tête de `src/instrumentation.ts` (L103) : la fonction `register()` s'exécute au démarrage du serveur, donc l'erreur apparaît dans les journaux du déploiement et non chez l'utilisateur.

```mission
{
  "title": "Le facteur « Config » des Twelve-Factor Apps",
  "url": "https://12factor.net",
  "steps": [
    "Ouvrez The Twelve-Factor App",
    "Parcourez la liste des douze facteurs",
    "Ouvrez le facteur consacré à la configuration"
  ],
  "question": "Quel est le numéro et l'intitulé du facteur sur la configuration, et quel critère propose-t-il pour savoir si la configuration est bien séparée du code ?",
  "hint": "Le critère imagine que l'on rende le code public.",
  "answer": "Facteur III, « Config » : stocker la configuration dans l'environnement ; critère : le code pourrait être rendu open source à tout moment sans compromettre aucun identifiant (texte stable, consulté en nov. 2026).",
  "xp": 10
}
```

### 3.2 Jalon 2 — sonde de santé et build autonome

```typescript
// src/app/api/health/route.ts — sonde utilisée par Docker, Caddy, la CI et la supervision
import { Pool } from "pg";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";      // jamais mise en cache

const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 2 });

export async function GET() {
  const debut = Date.now();
  try {
    await pool.query("SELECT 1");            // vérifie la base, PAS le fournisseur LLM (gratuit et rapide)
    return Response.json({
      statut: "ok",
      version: process.env.APP_VERSION ?? "local",
      promptVersion: process.env.PROMPT_VERSION ?? "dev",
      baseMs: Date.now() - debut,
    });
  } catch {
    return Response.json({ statut: "degrade", base: "injoignable" }, { status: 503 });
  }
}
```

```typescript
// next.config.ts — produit un serveur autonome (.next/standalone) pour l'image Docker
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
};

export default nextConfig;
```

### 3.3 Jalon 3 — conteneurs

```dockerfile
# Dockerfile — multi-étapes : une image "runner" (Next.js) et une image "worker" (pg-boss)
FROM node:22-alpine AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci

FROM node:22-alpine AS build
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
ENV NEXT_TELEMETRY_DISABLED=1
RUN npm run build

FROM node:22-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production NEXT_TELEMETRY_DISABLED=1 PORT=3000 HOSTNAME=0.0.0.0
COPY --from=build --chown=node:node /app/.next/standalone ./
COPY --from=build --chown=node:node /app/.next/static ./.next/static
COPY --from=build --chown=node:node /app/public ./public
USER node
EXPOSE 3000
CMD ["node", "server.js"]

FROM node:22-alpine AS worker
WORKDIR /app
ENV NODE_ENV=production
COPY --from=deps /app/node_modules ./node_modules
COPY --chown=node:node . .
USER node
CMD ["npx", "tsx", "worker.ts"]
```

```yaml
# docker-compose.yml — Compta-Chat sur VPS (nov. 2026)
services:
  caddy:
    image: caddy:2
    restart: unless-stopped
    ports: ["80:80", "443:443", "443:443/udp"]
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile:ro
      - caddy_data:/data              # certificats : à conserver, sinon limites Let's Encrypt
      - caddy_config:/config
    depends_on: [app]

  app:
    build: { context: ., target: runner }
    image: compta-chat-app:${IMAGE_TAG:-local}
    restart: unless-stopped
    env_file: .env.production         # hors dépôt, droits 600
    environment:
      APP_VERSION: ${IMAGE_TAG:-local}
      DATABASE_URL: postgres://compta:${POSTGRES_PASSWORD}@db:5432/compta
    depends_on:
      db: { condition: service_healthy }
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://127.0.0.1:3000/api/health"]
      interval: 30s
      timeout: 5s
      retries: 3

  worker:
    build: { context: ., target: worker }
    image: compta-chat-worker:${IMAGE_TAG:-local}
    restart: unless-stopped
    env_file: .env.production
    environment:
      DATABASE_URL: postgres://compta:${POSTGRES_PASSWORD}@db:5432/compta
    depends_on:
      db: { condition: service_healthy }

  db:
    image: pgvector/pgvector:pg17     # Postgres 17 avec l'extension vector préinstallée
    restart: unless-stopped
    environment:
      POSTGRES_USER: compta
      POSTGRES_DB: compta
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./db/init.sql:/docker-entrypoint-initdb.d/01-init.sql:ro   # CREATE EXTENSION vector + tables L101-L102
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U compta -d compta"]
      interval: 10s
      timeout: 5s
      retries: 5
    # Aucun "ports:" : la base n'est jamais exposée sur Internet

volumes: { caddy_data: {}, caddy_config: {}, pgdata: {} }
```

Le fichier `db/init.sql` commence par `CREATE EXTENSION IF NOT EXISTS vector;` puis reprend les tables des leçons précédentes (`clients`, `appels_llm`, `cache_semantique`). Il ne s'exécute qu'à la **création** du volume : les évolutions de schéma suivantes passent par des migrations versionnées.

### 3.4 Jalon 4 — Caddy, HTTPS et streaming

```caddyfile
# Caddyfile — HTTPS automatique (certificat Let's Encrypt obtenu et renouvelé par Caddy)
assistant.cabinet-exemple.fr {
	encode zstd gzip

	header {
		Strict-Transport-Security "max-age=31536000; includeSubDomains"
		X-Content-Type-Options "nosniff"
		Referrer-Policy "strict-origin-when-cross-origin"
		-Server
	}

	reverse_proxy app:3000 {
		flush_interval -1                     # envoie chaque fragment immédiatement : indispensable au streaming
		transport http {
			response_header_timeout 90s           # cohérent avec maxDuration et le timeout du fournisseur (L102)
		}
	}
}
```

Pointez l'enregistrement DNS A/AAAA du sous-domaine vers le VPS, ouvrez uniquement les ports 22, 80 et 443 dans le pare-feu, puis `docker compose up -d --build`. Au premier démarrage, Caddy obtient le certificat tout seul.

> 💡 **Autrement dit** — Caddy est le gardien de l'immeuble : il accueille les visiteurs à l'entrée (ports 80 et 443), leur présente un badge HTTPS valide qu'il renouvelle tout seul, puis les conduit à l'appartement `app:3000`. `flush_interval -1` lui demande de transmettre chaque mot dès qu'il arrive, au lieu d'attendre la lettre complète : c'est ce qui préserve le streaming.

```mission
{
  "title": "Ce que fait flush_interval -1 dans Caddy",
  "url": "https://caddyserver.com/docs",
  "steps": [
    "Ouvrez la documentation Caddy",
    "Allez dans la référence de la directive reverse_proxy (Caddyfile directives)",
    "Cherchez l'option flush_interval dans la partie streaming"
  ],
  "question": "Que signifie une valeur négative (-1) pour flush_interval ?",
  "hint": "Cherchez « low-latency » ou « buffering ».",
  "answer": "Une valeur négative active le mode faible latence : la mise en tampon de la réponse est désactivée et chaque écriture est envoyée immédiatement au client (doc consultée en nov. 2026).",
  "xp": 15
}
```

> ⚠️ **Piège fréquent** — Un proxy qui met les réponses en mémoire tampon. Symptôme : en local le texte s'affiche mot à mot, en production tout arrive d'un bloc après huit secondes. Les flux du Vercel AI SDK sont des Server-Sent Events ; vérifiez que **chaque** intermédiaire (Caddy, CDN, pare-feu applicatif) laisse passer les fragments sans les regrouper, et que la compression n'est pas appliquée en bloc sur le flux. Testez avec `curl -N`.

### 3.5 Jalon 5 — déploiement continu, test de fumée, retour arrière

Sur Vercel, le job `deploiement` de L104 suffit. Sur VPS, remplacez-le par ce job :

```yaml
# Extrait de .github/workflows/ci.yml — remplace le job "deploiement" de L104 pour un VPS
  deploiement-vps:
    needs: evaluation-prompts
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production
    steps:
      - name: Préparer la clé SSH (secrets du dépôt, jamais dans le YAML)
        run: |
          mkdir -p ~/.ssh
          echo "${{ secrets.VPS_SSH_KEY }}" > ~/.ssh/id_ed25519
          echo "${{ secrets.VPS_KNOWN_HOSTS }}" > ~/.ssh/known_hosts
          chmod 600 ~/.ssh/id_ed25519
      - name: Construire et redémarrer sur le VPS (images taguées par commit)
        run: |
          ssh deploy@${{ secrets.VPS_HOTE }} "cd /opt/compta-chat \
            && git fetch origin && git checkout --force ${{ github.sha }} \
            && IMAGE_TAG=${{ github.sha }} docker compose up -d --build \
            && docker image prune -f"
      - name: Test de fumée
        run: |
          curl --fail --silent --retry 10 --retry-delay 6 --retry-all-errors \
            https://assistant.cabinet-exemple.fr/api/health | grep '"statut":"ok"'
```

Le test de fumée vérifie aussi la version : comparez le champ `version` renvoyé par `/api/health` au SHA du commit. Pour le **retour arrière**, les images précédentes restent sur le serveur (seules les images sans étiquette sont supprimées) :

```bash
# Retour arrière sur le VPS : relancer les images d'un commit antérieur, sans reconstruire
cd /opt/compta-chat
docker image ls compta-chat-app --format '{{.Tag}}  {{.CreatedSince}}'   # repérer le SHA voulu
IMAGE_TAG=<sha_precedent> docker compose up -d --no-build app worker
curl -s https://assistant.cabinet-exemple.fr/api/health
```

Un retour arrière de **code** ne restaure pas la **base** : une migration destructrice (suppression de colonne) se fait en deux déploiements, d'abord le code qui n'utilise plus la colonne, ensuite la suppression.

### 3.6 Jalon 6 — sauvegardes et exploitation

```bash
#!/usr/bin/env bash
# /opt/compta-chat/sauvegarde.sh — exécuté chaque nuit par cron (ex. 2 h 30)
set -euo pipefail
cd /opt/compta-chat
HORODATAGE=$(date +%Y-%m-%d_%H%M)
mkdir -p sauvegardes
docker compose exec -T db pg_dump -U compta -d compta --format=custom > "sauvegardes/compta_${HORODATAGE}.dump"
find sauvegardes -name '*.dump' -mtime +14 -delete       # conserve 14 jours en local
# Copiez ensuite le fichier hors du serveur (stockage objet UE chiffré) : une sauvegarde sur la même machine n'en est pas une.
```

Une sauvegarde jamais restaurée est une hypothèse. Le jury vous demandera de restaurer le dump dans une base vide (`pg_restore -d compta_test …`) et de chronométrer l'opération.

🎮 **Défi « journée du chaos »** — Application en production, faites successivement : `docker compose stop db` ; révoquez la clé Anthropic dans la Console ; envoyez 50 questions en 10 secondes avec le même utilisateur. Pour chaque incident, notez ce que voit l'utilisateur, ce que montre `/api/health`, ce qui apparaît dans Langfuse, et le temps de retour à la normale. Un message « Service momentanément indisponible, réessayez dans une minute » vaut 10 points ; une page blanche, zéro.

## 4. Checklist de mise en production

Cochez chaque ligne **avec une preuve** (capture, commande, lien de trace). Les lignes marquées ⛔ sont éliminatoires.

| Domaine | Contrôle | Preuve attendue |
|---|---|---|
| Sécurité | ⛔ Aucune clé dans le dépôt, l'historique Git ou une variable `NEXT_PUBLIC_*` | Recherche `sk-ant-` dans l'historique, revue du bundle |
| Sécurité | ⛔ Toutes les routes `/api/*` (sauf `/api/health`) renvoient 401 sans session | Requête `curl` sans cookie |
| Sécurité | Taille des messages, profondeur d'historique, `maxOutputTokens` plafonnés | Test 413 ; extrait de code |
| Sécurité | Clés distinctes par environnement (dev, preview, prod), rotation documentée | Captures Console (noms de clés) |
| Coûts | Quota par utilisateur et budget global bloquants ; alerte à 80 % du budget | Test de dépassement ; table `appels_llm` |
| Coûts | Prompt caching actif sur le préfixe stable | Tokens `cache_read` visibles dans une trace |
| Fiabilité | Timeouts à chaque étage, `retry-after` respecté, modèle de repli testé | Journal d'un 429 simulé |
| Fiabilité | Jobs idempotents (clé d'unicité, écriture atomique) | Double envoi → un seul job |
| Fiabilité | Sauvegarde quotidienne hors serveur et restauration testée | Durée de restauration mesurée |
| Observabilité | ⛔ Traces collectées en production (modèle, tokens, coût, latence, outils, `promptVersion`) | Lien vers une trace Langfuse |
| Observabilité | Feedback utilisateur relié aux traces ; rétention 30 jours ; masquage | Paramètres du projet Langfuse |
| Qualité | ⛔ Suite d'évaluation automatisée bloquante en CI (taux, coût, latence, cas critiques) | Pull request rouge puis verte |
| Qualité | Jeu de test alimenté par les traces réelles (≥ 30 cas) | Fichier `tests/` versionné |
| Déploiement | ⛔ Application accessible en HTTPS avec un compte de démonstration | URL + identifiants pour le jury |
| Déploiement | Retour arrière exécuté une fois et chronométré (< 5 min) | Journal de la commande |
| RGPD | Registre des traitements mis à jour ; région UE ; information des utilisateurs | Fiche de traitement (voir M23) |
| Exploitation | README : installation, variables, déploiement, retour arrière, contacts | Fichier dans le dépôt |

> 🔗 **Documentation officielle** — [Docker Compose](https://docs.docker.com) · [Caddy — reverse_proxy et HTTPS automatique](https://caddyserver.com/docs) · [Vercel — déploiements et Instant Rollback](https://vercel.com/docs) · [Next.js — déploiement autonome](https://nextjs.org/docs)

```quiz
{
  "q": "Dans la checklist de mise en production, que signale le symbole ⛔ ?",
  "options": [
    "Une ligne facultative, valorisée en bonus",
    "Un critère éliminatoire, quel que soit le score",
    "Un contrôle qui ne concerne que le déploiement Vercel",
    "Un point à vérifier après la soutenance"
  ],
  "answer": 1,
  "explanation": "Seuil de validation : 70/100 et aucun critère éliminatoire en échec (clés exposées, routes non authentifiées, absence de traces ou de CI bloquante, pas de HTTPS)."
}
```

## 5. Grille d'évaluation du projet (100 points)

Le projet valide la compétence **C3.5** (« l'application est déployée et accessible ; les traces sont collectées ; une suite d'évaluation automatisée existe ») et contribue à **C3.1** (streaming, erreurs, coûts, limites, clés sécurisées). Seuil de validation : **70/100** et aucun critère éliminatoire de la checklist en échec.

| Critère | Pts | Satisfaisant (≈ 60 % des points) | Excellent (100 %) | Comp. |
|---|---|---|---|---|
| Fonctionnel et streaming | 15 | Chat streamé, deux outils opérationnels | + annulation, erreurs affichées proprement, worker et état des jobs | C3.1 |
| Intégration API, coûts, limites | 15 | Coût par réponse journalisé ; 429 géré | + budget prévisionnel argumenté, cache mesuré, repli testé | C3.1 |
| Sécurité | 15 | Auth, validation, clés hors dépôt | + clés par environnement, en-têtes HTTP, test d'abus documenté | C3.1 / C3.6 |
| Déploiement | 15 | HTTPS accessible, déploiement scripté | + CI qui déploie, test de fumée, retour arrière chronométré | C3.5 |
| Observabilité | 15 | Traces avec tokens, coût, latence | + feedback relié, tableau de bord, rétention et masquage | C3.5 |
| Tests et CI | 15 | Suite promptfoo exécutée en CI | + seuils bloquants, cas critiques à 100 %, tests unitaires sans LLM | C3.5 |
| Dossier et soutenance | 10 | README complet, démo fonctionnelle | + choix d'architecture justifiés (Vercel/VPS, modèles), limites assumées | C3.5 |

**Livrables** : dépôt Git (accès lecture pour le jury), URL de production et compte de démonstration, dossier d'architecture de 3 à 5 pages (cahier des charges, schéma, choix, budget, checklist cochée), soutenance de 15 minutes (10 de démonstration en direct, 5 de questions). Le jury peut demander pendant la démonstration de casser volontairement un élément (couper la base, dégrader un prompt) : c'est la meilleure preuve que votre observabilité et votre CI servent à quelque chose.

> 💡 **À retenir** — Ce projet couvre l'essentiel du domaine « Applications & Integration », le plus lourd (environ un tiers des questions selon des guides tiers) de la certification **Claude Certified Developer – Foundations**, et une part de « Evaluation, Testing & Optimization » de l'Architect – Professional. Ces examens Anthropic sont réservés aux organisations du Claude Partner Network : si votre employeur y est, nous vous encourageons à les passer. Le certificat Next Formation atteste de vos compétences sur notre référentiel ; il ne remplace pas ces certifications.

## 🧪 Exercice pratique

**Consigne.** Livrez Compta-Chat v1.0 en production sur la cible de votre choix (Vercel ou VPS Caddy) :

1. rédigez le cahier des charges (sections 1.1 à 1.3) en l'adaptant à **votre** contexte (autre métier possible : agence immobilière, service RH d'une PME, boulangerie multi-sites) ; recalculez le budget avec vos propres volumes ;
2. ajoutez `src/lib/env.ts`, `/api/health`, `output: "standalone"` ; conteneurisez (VPS) ou configurez les variables par environnement (Vercel) ;
3. déployez via la CI de L104, avec test de fumée ;
4. passez la checklist de la section 4 en fournissant une preuve par ligne ;
5. menez le défi « journée du chaos » et consignez les résultats ;
6. auto-évaluez-vous avec la grille de la section 5 avant la soutenance.

**Critères de réussite.**
- L'URL de production répond en HTTPS ; `/api/health` renvoie `"statut":"ok"` et le SHA du commit déployé.
- Le premier mot d'une réponse s'affiche en moins de 2 secondes en production (et pas seulement en local).
- Une trace Langfuse de production montre modèle, tokens (dont cache), coût, latence, appels d'outils et `promptVersion`.
- Une pull request qui dégrade le prompt est bloquée par la CI ; la suivante, corrigée, se déploie seule.
- Le retour arrière et la restauration de sauvegarde ont été exécutés au moins une fois et chronométrés.

**Pistes de corrigé.** Si le streaming arrive d'un bloc en production : vérifiez `flush_interval -1` dans Caddy, l'absence de mise en tampon par un CDN, et que la route ne renvoie pas un `Response.json` après `await result.text`. Si le conteneur `app` redémarre en boucle : lisez `docker compose logs app`, c'est presque toujours `env.ts` qui signale une variable manquante, ce qui est exactement son rôle. Si le jury trouve une clé dans l'historique Git : la supprimer du dernier commit ne suffit pas, **révoquez-la** dans la Console puis réécrivez l'historique. Pour le budget, un tableur à trois lignes (volumes, tokens par question, tarifs datés) suffit, à condition d'indiquer la source et la date des tarifs.

## ✅ Auto-évaluation express

1. Pourquoi la sonde `/api/health` ne doit-elle pas appeler le modèle de langage ?
2. Votre chat streame parfaitement en local mais affiche la réponse d'un bloc en production derrière Caddy. Citez deux causes possibles.
3. Pourquoi un retour arrière d'image Docker ne suffit-il pas toujours après une migration de base de données ?

**Réponses.** 1. Elle est appelée toutes les 30 secondes par Docker, la supervision et la CI : un appel LLM coûterait des tokens à chaque fois, dépendrait de la disponibilité du fournisseur (une panne Anthropic rendrait le conteneur « malade » et provoquerait des redémarrages inutiles) et serait lent. Elle vérifie ce que vous maîtrisez (processus, base) ; la santé du fournisseur se suit dans les traces. 2. Une mise en tampon par le proxy (absence de `flush_interval -1`), une compression appliquée en bloc, un CDN ou pare-feu intermédiaire qui regroupe les fragments, ou un code serveur qui attend la fin de la génération avant de répondre. 3. Parce que l'image restaure le code, pas les données : si la migration a supprimé ou transformé une colonne, l'ancien code ne la retrouve plus. D'où les migrations en deux temps et la sauvegarde avant chaque migration.

## 📚 Pour aller plus loin
- [Next.js — documentation](https://nextjs.org/docs) 🇬🇧 — déploiement, `output: "standalone"`, Route Handlers, `instrumentation.ts`.
- [Vercel — documentation](https://vercel.com/docs) 🇬🇧 — environnements preview/production, régions, durée des fonctions, Instant Rollback.
- [Docker — documentation](https://docs.docker.com) 🇬🇧 — builds multi-étapes, Compose, healthchecks.
- [Caddy — documentation](https://caddyserver.com/docs) 🇬🇧 — HTTPS automatique, `reverse_proxy`, `flush_interval`.
- [pgvector](https://github.com/pgvector/pgvector) 🇬🇧 — image Docker, index HNSW, opérateurs de distance.
- [Langfuse](https://langfuse.com) 🇬🇧 — traces, coûts, datasets, rétention des données.
- [The Twelve-Factor App](https://12factor.net) 🇬🇧 — les douze principes d'une application déployable, toujours d'actualité.
- [Full Stack Deep Learning — LLM Bootcamp 2023](https://fullstackdeeplearning.com/llm-bootcamp/spring-2023/) 🇬🇧 — source d'inspiration : séances « LLMOps » et « Launch an LLM App in One Hour ».

> 🗺️ **Et maintenant ?** — Votre application est en ligne… donc exposée. Le module M23 s'ouvre en L106 sur la carte des risques de sécurité propres aux applications LLM : l'OWASP Top 10.
