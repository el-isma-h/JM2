---
id: L101
module: M22
level: N3
title: "Next.js et Vercel AI SDK : chat en streaming"
minutes: 60
objectives:
  - "Expliquer pourquoi le streaming est indispensable dans une interface LLM et comment il circule du fournisseur jusqu'au navigateur"
  - "Construire un chat complet avec Next.js 16 (App Router), TypeScript et le Vercel AI SDK : route handler, hook useChat, outils exécutés côté serveur"
  - "Sécuriser la route : authentification, limite de taille des messages, validation des entrées, clé API en variable d'environnement"
  - "Changer de fournisseur (Anthropic, OpenAI, Mistral, xAI) sans réécrire l'interface"
skills: ["C3.5", "C3.1"]
sources:
  - { title: "Vercel AI SDK — documentation", url: "https://ai-sdk.dev", lang: "en" }
  - { title: "Next.js — documentation (App Router, Route Handlers)", url: "https://nextjs.org/docs", lang: "en" }
  - { title: "Claude Platform — Streaming Messages", url: "https://platform.claude.com/docs/en/build-with-claude/streaming", lang: "en" }
  - { title: "OpenAI — Streaming responses", url: "https://developers.openai.com/api/docs/guides/streaming-responses", lang: "en" }
  - { title: "Claude Platform — Client SDKs (TypeScript 1.3.0)", url: "https://platform.claude.com/docs/en/cli-sdks-libraries/overview", lang: "en" }
  - { title: "xAI — Quickstart (option Vercel AI SDK)", url: "https://docs.x.ai/developers/quickstart", lang: "en" }
  - { title: "Claude Platform — Reduce latency", url: "https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency", lang: "en" }
---

# Next.js et Vercel AI SDK : chat en streaming

> ⏱ 60 min · 🎯 Niveau 3 · 📚 Module 22

## 🎯 Ce que vous saurez faire
- Expliquer, schéma à l'appui, le trajet d'un token depuis l'API du fournisseur jusqu'au composant React, et pourquoi une réponse « en bloc » est inacceptable pour un utilisateur.
- Mettre en place un chat complet et déployable : route handler `app/api/chat/route.ts`, hook `useChat`, outils (tools) exécutés sur le serveur, affichage des étapes intermédiaires.
- Protéger la route : authentification, plafond de taille du message et de l'historique, validation Zod, clé API jamais exposée au navigateur.
- Changer de modèle ou de fournisseur en modifiant **une seule ligne**.

> 🧭 **En clair** — Une application de chat IA fonctionne comme un restaurant : le navigateur est la salle, votre serveur Next.js est le serveur en salle, et le fournisseur (Anthropic, OpenAI…) est la cuisine. Le client ne va jamais en cuisine, sinon il verrait la caisse : votre clé API. Le *streaming*, c'est le serveur qui apporte chaque plat dès qu'il sort, au lieu d'attendre que toute la table soit prête : la réponse s'affiche mot à mot. Le Vercel AI SDK est la boîte à outils qui fait ce travail de serveur pour vous, quelle que soit la cuisine choisie. Votre rôle : vérifier qui entre (authentification) et limiter la taille des commandes (plafonds).

## 1. Pourquoi le streaming n'est pas un luxe

Imaginez un serveur dans un restaurant qui attendrait que **tous** les plats de la table soient prêts avant d'apporter le premier. C'est ce que fait une API LLM sans streaming : le modèle génère 600 tokens à 80 tokens/s, soit 7,5 secondes de silence total, puis tout arrive d'un coup. Avec le streaming, le premier mot apparaît en moins d'une seconde et l'utilisateur lit pendant que le modèle écrit. Le temps total est identique ; la **perception** est radicalement différente. La métrique qui compte s'appelle le *time to first token* (TTFT) : c'est elle que vous surveillerez en L103.

Techniquement, les fournisseurs envoient la réponse sous forme d'événements **Server-Sent Events (SSE)**. Chez Anthropic, la séquence est documentée sur la page [Streaming Messages](https://platform.claude.com/docs/en/build-with-claude/streaming) : `message_start` → `content_block_start` → une série de `content_block_delta` (avec des deltas `text_delta`, `input_json_delta` pour les arguments d'outils, `thinking_delta` pour le raisonnement) → `content_block_stop` → `message_delta` (qui porte le `stop_reason` et l'usage) → `message_stop`. OpenAI expose un mécanisme équivalent via `stream: true` sur la Responses API (événements `response.output_text.delta`, voir [Streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses)).

> 💡 **Autrement dit** — SSE (*Server-Sent Events*) est un « tuyau » HTTP qui reste ouvert : le serveur y pousse de petits messages au fil de l'eau. Chaque message dit « voici trois mots de plus », « je commence un appel d'outil » ou « j'ai fini, voici le nombre de tokens ». Vous n'avez pas à manipuler ces messages vous-même : le SDK les assemble.

Dans une application web, le flux traverse **trois** étapes :

```
Fournisseur (SSE)  ──►  Votre serveur Next.js (route handler)  ──►  Navigateur (useChat)
   claude-sonnet-5-5       lit le flux, exécute les outils,          affiche les deltas,
   gpt-6.1-terra …         ajoute l'auth, les limites, les logs      les appels d'outils,
                           renvoie un flux "UI message stream"       les erreurs
```

Le navigateur ne parle **jamais** directement au fournisseur : la clé API resterait sinon visible dans l'onglet Réseau de n'importe quel visiteur. C'est tout l'intérêt du route handler intermédiaire, qui est aussi l'endroit où vous brancherez les files d'attente (L102), les traces (L103) et les feature flags (L104).

> 💡 **À retenir** — Le streaming ne raccourcit pas la génération, il raccourcit l'attente perçue. Le serveur intermédiaire protège la clé et centralise la logique métier.

```quiz
{
  "q": "Un collègue propose d'appeler l'API Anthropic directement depuis le composant React, « pour gagner une étape ». Quel est le problème principal ?",
  "options": [
    "Le streaming ne fonctionnerait plus dans un navigateur",
    "Le temps avant le premier token serait doublé",
    "Next.js bloque toute requête HTTP sortante côté client",
    "La clé API deviendrait lisible par n'importe quel visiteur"
  ],
  "answer": 3,
  "explanation": "Tout ce qui s'exécute dans le navigateur est visible (onglet Réseau, bundle). Le route handler garde la clé côté serveur et y ajoute auth, limites et journaux."
}
```

## 2. Le Vercel AI SDK en cinq concepts

Le [Vercel AI SDK](https://ai-sdk.dev) (paquet `ai`, licence Apache 2.0, nov. 2026) est une bibliothèque TypeScript qui unifie les fournisseurs derrière une API commune. Les cinq briques à connaître :

| Brique | Rôle | Où elle vit |
|---|---|---|
| **Fournisseurs** `@ai-sdk/anthropic`, `@ai-sdk/openai`, `@ai-sdk/mistral`, `@ai-sdk/xai`… | Adaptateur vers chaque API ; lit la clé dans `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, etc. | Serveur |
| `generateText` / `streamText` | Appel unique ou flux de tokens ; accepte `system`, `messages`, `tools`, `stopWhen` | Serveur |
| `tool()` + Zod | Déclare un outil typé : description, schéma d'entrée, fonction `execute` | Serveur |
| `UIMessage` / `toUIMessageStreamResponse()` | Format de message côté interface (texte, appels d'outils, résultats) et conversion du flux en réponse HTTP | Serveur → client |
| `useChat` (`@ai-sdk/react`) | Hook React : état des messages, statut, envoi, arrêt, gestion d'erreur | Navigateur |

Le point qui change tout par rapport à un appel SDK « brut » : la **boucle d'outils** est intégrée. Si le modèle demande un outil, le SDK l'exécute, renvoie le résultat au modèle et continue, jusqu'à la condition `stopWhen` (par exemple `stepCountIs(5)`). Chaque étape est diffusée au client au fur et à mesure.

> ⚠️ **Piège fréquent** — Le SDK évolue vite (la version 5 a changé les noms : `maxSteps` → `stopWhen`, `parameters` → `inputSchema`, `toDataStreamResponse` → `toUIMessageStreamResponse`). Vérifiez toujours la version installée avec `npm ls ai` et la page de migration correspondante sur ai-sdk.dev avant de copier un exemple trouvé en ligne.

```quiz
{
  "q": "Avec le Vercel AI SDK, quand le modèle demande un outil, c'est à vous d'écrire la boucle qui exécute l'outil puis renvoie le résultat au modèle.",
  "type": "vrai_faux",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "La boucle d'outils est intégrée : le SDK exécute l'outil, renvoie le résultat et continue jusqu'à la condition stopWhen (par exemple stepCountIs(5))."
}
```

## 3. Le projet : « Compta-Chat » pour un cabinet comptable

Fil rouge du module : un cabinet d'expertise comptable de Rennes veut un assistant interne qui répond aux collaborateurs sur les dossiers clients, avec deux outils : **rechercher un client** dans Postgres et **calculer une échéance de TVA**. Nous construisons l'interface ici, le backend robuste en L102, l'observabilité en L103, la chaîne de livraison en L104, et nous assemblons le tout en L105.

### 3.1 Initialisation

```bash
# Création du projet Next.js 16 (App Router, TypeScript, Tailwind) — nov. 2026
npx create-next-app@latest compta-chat --typescript --app --tailwind --eslint --src-dir
cd compta-chat
npm install ai @ai-sdk/react @ai-sdk/anthropic @ai-sdk/openai zod
npm install pg                     # client Postgres pour l'outil "rechercher un client"
cp .env.example .env.local 2>/dev/null || true
```

Fichier `.env.local` (jamais commité ; ajoutez-le au `.gitignore`, ce que `create-next-app` fait déjà) :

```bash
ANTHROPIC_API_KEY=sk-ant-...      # clé lue par @ai-sdk/anthropic
OPENAI_API_KEY=sk-...             # facultatif : modèle de repli
DATABASE_URL=postgres://compta:motdepasse@localhost:5432/compta
AI_MODEL=claude-sonnet-5-5        # changez ici pour basculer de modèle
MAX_MESSAGE_CHARS=4000
MAX_HISTORY_MESSAGES=30
```

### 3.2 Le route handler : `src/app/api/chat/route.ts`

```typescript
// src/app/api/chat/route.ts — point d'entrée du chat (serveur uniquement)
import { anthropic } from "@ai-sdk/anthropic";
import { openai } from "@ai-sdk/openai";
import {
  streamText, convertToModelMessages, tool, stepCountIs,
  type UIMessage, type LanguageModel,
} from "ai";
import { z } from "zod";
import { Pool } from "pg";
import { getSession } from "@/lib/auth";          // voir section 4

export const runtime = "nodejs";     // "pg" a besoin de Node (pas de runtime Edge)
export const maxDuration = 60;       // secondes ; Vercel coupe la fonction au-delà

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ---- Choix du modèle en une ligne (AI_MODEL dans .env.local) ----
function choisirModele(): LanguageModel {
  const id = process.env.AI_MODEL ?? "claude-sonnet-5-5";
  return id.startsWith("gpt-") ? openai(id) : anthropic(id);
}

// ---- Outils exécutés côté serveur ----
const rechercherClient = tool({
  description: "Recherche un client du cabinet par nom ou SIREN. Retourne au plus 5 résultats.",
  inputSchema: z.object({
    requete: z.string().min(2).max(80).describe("Nom partiel ou SIREN (9 chiffres)"),
  }),
  execute: async ({ requete }) => {
    const { rows } = await pool.query(
      `SELECT id, raison_sociale, siren, regime_tva
         FROM clients
        WHERE raison_sociale ILIKE $1 OR siren = $2
        LIMIT 5`,
      [`%${requete}%`, requete],
    );
    return { resultats: rows };      // le SDK sérialise et renvoie au modèle
  },
});

const echeanceTva = tool({
  description: "Calcule la prochaine date limite de déclaration de TVA selon le régime.",
  inputSchema: z.object({
    regime: z.enum(["reel_normal_mensuel", "reel_simplifie", "franchise"]),
    dateReference: z.string().describe("Date ISO, ex. 2026-11-01"),
  }),
  execute: async ({ regime, dateReference }) => {
    const d = new Date(dateReference);
    if (regime === "franchise") return { echeance: null, commentaire: "Pas de déclaration de TVA en franchise en base." };
    if (regime === "reel_simplifie") {
      // CA12 : 2e jour ouvré suivant le 1er mai (simplification pédagogique)
      return { echeance: `${d.getFullYear() + (d.getMonth() >= 4 ? 1 : 0)}-05-03`, commentaire: "Déclaration annuelle CA12." };
    }
    // Réel normal mensuel : entre le 15 et le 24 du mois suivant (date retenue : 24, simplifiée)
    const suivant = new Date(d.getFullYear(), d.getMonth() + 1, 24);
    return { echeance: suivant.toISOString().slice(0, 10), commentaire: "CA3 mensuelle, date simplifiée : vérifier sur impots.gouv.fr." };
  },
});

const SYSTEM = `Vous êtes Compta-Chat, assistant interne d'un cabinet d'expertise comptable rennais.
Répondez en français, de façon concise. Utilisez les outils plutôt que d'inventer des données.
Si une information n'est pas dans les résultats d'outil, dites-le explicitement.`;

export async function POST(req: Request) {
  // 1. Authentification (section 4)
  const session = await getSession(req);
  if (!session) return new Response("Non authentifié", { status: 401 });

  // 2. Lecture et validation de la requête
  const body = await req.json().catch(() => null);
  const parsed = z.object({ messages: z.array(z.custom<UIMessage>()) }).safeParse(body);
  if (!parsed.success) return new Response("Requête invalide", { status: 400 });

  // 3. Limites de taille : nombre de messages et longueur du dernier message
  const maxHist = Number(process.env.MAX_HISTORY_MESSAGES ?? 30);
  const maxChars = Number(process.env.MAX_MESSAGE_CHARS ?? 4000);
  const messages = parsed.data.messages.slice(-maxHist);
  const dernier = messages.at(-1);
  const texteDernier = dernier?.parts
    .filter((p) => p.type === "text")
    .map((p) => (p as { text: string }).text)
    .join("") ?? "";
  if (texteDernier.length > maxChars) {
    return new Response(`Message trop long (max ${maxChars} caractères)`, { status: 413 });
  }

  // 4. Appel en streaming avec boucle d'outils
  const result = streamText({
    model: choisirModele(),
    system: SYSTEM,
    messages: await convertToModelMessages(messages),
    tools: { rechercherClient, echeanceTva },
    stopWhen: stepCountIs(5),          // au plus 5 allers-retours modèle ↔ outils
    maxOutputTokens: 1024,
    abortSignal: req.signal,           // l'utilisateur ferme l'onglet → on arrête de payer
    onFinish: ({ usage, finishReason }) => {
      // Point d'accroche pour L102 (coûts) et L103 (traces)
      console.log(JSON.stringify({ user: session.userId, usage, finishReason }));
    },
  });

  // 5. Conversion du flux en réponse HTTP "UI message stream"
  return result.toUIMessageStreamResponse();
}
```

Trois détails méritent attention. `abortSignal: req.signal` propage l'annulation : si l'utilisateur ferme la page, la requête vers le fournisseur est coupée et vous ne payez pas les tokens restants. `maxOutputTokens` borne la facture d'une réponse. Enfin, nous ne passons **pas** de `temperature` : les modèles Claude ≥ 4.7 renvoient une erreur 400 si ce paramètre est présent — et, depuis la version d'API `2026-10-21` (envoyée par défaut par les SDK Anthropic v2), `temperature`, `top_p` et `top_k` renvoient une erreur 400 **sur tous les modèles Claude**, même à leur valeur par défaut (voir la page [Using the Messages API](https://platform.claude.com/docs/en/build-with-claude/working-with-messages)), et le SDK le transmettrait tel quel.

```mission
{
  "title": "Quels paramètres la version d'API 2026-10-21 refuse-t-elle ?",
  "url": "https://platform.claude.com/docs/en/api/migration-2026-10-21",
  "steps": [
    "Ouvrez le guide de migration vers la version d'API 2026-10-21",
    "Cherchez la section consacrée aux paramètres d'échantillonnage (sampling)",
    "Notez quels paramètres provoquent une erreur et à quelle condition"
  ],
  "question": "Quels paramètres renvoient une erreur 400 avec cette version d'API, et l'erreur se produit-elle aussi à la valeur par défaut ?",
  "hint": "Cherchez les mots « temperature » et « 400 » dans la page.",
  "answer": "`temperature`, `top_p` et `top_k` renvoient une erreur 400, même à leur valeur par défaut, sur tous les modèles (page lue le 5 nov. 2026 ; la doc évolue, vérifiez) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

### 3.3 L'interface : `src/app/page.tsx`

```typescript
// src/app/page.tsx — composant client ; le flux arrive via useChat
"use client";

import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { useState } from "react";

export default function Page() {
  const [input, setInput] = useState("");
  const { messages, sendMessage, status, stop, error } = useChat({
    transport: new DefaultChatTransport({ api: "/api/chat" }),
  });
  const enCours = status === "submitted" || status === "streaming";

  return (
    <main className="mx-auto max-w-2xl p-6 space-y-4">
      <h1 className="text-xl font-semibold">Compta-Chat</h1>

      <ul className="space-y-3">
        {messages.map((m) => (
          <li key={m.id} className={m.role === "user" ? "text-right" : ""}>
            <span className="text-xs text-gray-500">{m.role === "user" ? "Vous" : "Assistant"}</span>
            {m.parts.map((part, i) => {
              if (part.type === "text") return <p key={i} className="whitespace-pre-wrap">{part.text}</p>;
              // Appels d'outils : le SDK nomme les parts "tool-<nomOutil>"
              if (part.type.startsWith("tool-")) {
                const p = part as { type: string; state: string; input?: unknown; output?: unknown };
                return (
                  <details key={i} className="rounded border p-2 text-sm">
                    <summary>🔧 {p.type.replace("tool-", "")} — {p.state}</summary>
                    <pre className="overflow-x-auto">{JSON.stringify({ entree: p.input, sortie: p.output }, null, 2)}</pre>
                  </details>
                );
              }
              return null;
            })}
          </li>
        ))}
      </ul>

      {error && <p className="text-red-600 text-sm">Erreur : {error.message}</p>}

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!input.trim() || enCours) return;
          sendMessage({ text: input });
          setInput("");
        }}
        className="flex gap-2"
      >
        <input
          className="flex-1 rounded border p-2"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Quelle est l'échéance TVA de la SARL Dupont ?"
          maxLength={4000}
        />
        {enCours ? (
          <button type="button" onClick={stop} className="rounded bg-gray-200 px-3">Stop</button>
        ) : (
          <button type="submit" className="rounded bg-black px-3 text-white">Envoyer</button>
        )}
      </form>
    </main>
  );
}
```

Lancez `npm run dev`, posez la question « Quelle est l'échéance TVA de la SARL Dupont ? » : vous verrez apparaître l'appel à `rechercherClient` (état `input-streaming` puis `output-available`), puis `echeanceTva`, puis le texte final qui se construit mot à mot. Le `maxLength` côté client est un confort ; la **vraie** limite est celle du serveur (section 3.2), car un client malveillant contourne toujours le HTML.

## 4. Authentification et protection de la route

Une route de chat sans authentification est un distributeur de tokens gratuits : en 2025-2026, des bots ont systématiquement scanné les endpoints `/api/chat` ouverts pour s'en servir comme proxy LLM. Le minimum viable :

```typescript
// src/lib/auth.ts — vérification d'une session (exemple minimal avec cookie signé)
import { cookies } from "next/headers";
import { jwtVerify } from "jose";

const secret = new TextEncoder().encode(process.env.AUTH_SECRET!);   // 32+ caractères aléatoires

export async function getSession(_req: Request): Promise<{ userId: string } | null> {
  const token = (await cookies()).get("session")?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    return { userId: String(payload.sub) };
  } catch {
    return null;
  }
}
```

En production, vous brancherez une bibliothèque complète (Auth.js, Clerk, Better Auth, ou l'annuaire de l'entreprise via OIDC) ; l'important est le **contrat** : le route handler obtient un `userId` fiable, qui servira aux quotas par utilisateur (L102) et aux traces (L103).

Checklist de la route avant tout déploiement :

| Contrôle | Pourquoi | Implémentation |
|---|---|---|
| Auth obligatoire | Éviter l'usage pirate de votre clé | `getSession` → 401 |
| Taille du message | Un message de 2 Mo = des milliers de tokens facturés | 413 au-delà de `MAX_MESSAGE_CHARS` |
| Profondeur d'historique | Le contexte grossit à chaque tour : coût linéaire | `slice(-MAX_HISTORY_MESSAGES)` |
| Validation du corps | Les `UIMessage` forgés peuvent injecter des `parts` d'outil factices | Zod + rejet 400 |
| `maxOutputTokens` | Plafond de coût par réponse | paramètre de `streamText` |
| `maxDuration` | Une fonction serverless qui tourne 5 min coûte cher et bloque | export Next.js |
| Annulation | Ne pas payer une réponse que personne ne lit | `abortSignal: req.signal` |

> ⚠️ **Piège fréquent** — Placer la clé API dans une variable `NEXT_PUBLIC_*`. Tout ce qui commence par `NEXT_PUBLIC_` est embarqué dans le bundle JavaScript du navigateur. Les clés restent dans des variables sans ce préfixe, lues uniquement dans du code serveur (route handlers, Server Components, Server Actions).

```quiz
{
  "q": "Votre formulaire impose maxLength=4000. Un testeur envoie avec curl un message de 2 Mo directement à /api/chat. Que doit-il se passer ?",
  "options": [
    "Le navigateur tronque le texte à 4 000 caractères",
    "Le modèle refuse de lire un texte aussi long",
    "Le serveur rejette la requête (413) avant l'appel",
    "Vercel coupe la fonction au bout de maxDuration"
  ],
  "answer": 2,
  "explanation": "curl ne passe pas par le formulaire : seule la limite côté serveur compte. Elle s'applique avant l'appel au fournisseur, donc rien n'est facturé."
}
```

```mission
{
  "title": "Le préfixe qui expose une variable au navigateur",
  "url": "https://nextjs.org/docs",
  "steps": [
    "Ouvrez la documentation Next.js",
    "Cherchez la page « Environment Variables »",
    "Repérez le paragraphe sur les variables accessibles au navigateur"
  ],
  "question": "Quel préfixe rend une variable d'environnement lisible dans le code du navigateur, et à quel moment sa valeur y est-elle intégrée ?",
  "hint": "Le préfixe est cité dans le « Piège fréquent » de la section 4.",
  "answer": "`NEXT_PUBLIC_` : la valeur est intégrée (inlinée) dans le bundle JavaScript au moment du build (doc consultée en nov. 2026). Ne l'utilisez jamais pour une clé.",
  "xp": 10
}
```

## 5. Changer de fournisseur, et quand le faire

La fonction `choisirModele()` illustre l'intérêt de l'abstraction : `AI_MODEL=gpt-6.1-terra` et l'application parle à OpenAI ; `mistral-small-4` avec `@ai-sdk/mistral` ; `grok-4.7` avec `@ai-sdk/xai` (le [Quickstart xAI](https://docs.x.ai/developers/quickstart) présente d'ailleurs le Vercel AI SDK comme première option d'intégration). Ordres de grandeur de prix (nov. 2026, pages Pricing officielles) : Claude Sonnet 5.5 2 $/10 $ par million de tokens entrée/sortie, Claude Haiku 5.5 0,10 $/0,50 $ (≤ 100k tokens), GPT-6.1 Terra 1 $/5 $, GPT-6 Luna 0,10 $/0,50 $, Mistral Small 4 0,15 $/0,60 $.

Ce que l'abstraction **ne** gomme pas : les comportements d'outils (certains modèles appellent plusieurs outils en parallèle, d'autres non), les paramètres interdits (`temperature` chez Claude), la qualité en français, et surtout la **latence**. La page [Reduce latency](https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency) d'Anthropic rappelle les leviers : modèle plus petit, prompt plus court, moins de tokens de sortie, streaming. Un changement de fournisseur se valide donc avec une suite d'évaluations (L103), jamais « à l'œil ».

> 🔗 **Documentation officielle** — [Vercel AI SDK](https://ai-sdk.dev) · [Next.js Route Handlers](https://nextjs.org/docs) · [Streaming Messages (Anthropic)](https://platform.claude.com/docs/en/build-with-claude/streaming)

🎮 **Défi** — Ajoutez un troisième outil `convertirDevise` qui lit un taux dans une table Postgres, puis demandez « Combien vaut la facture de 1 200 € de la SARL Dupont en dollars ? ». Combien d'étapes (`steps`) le modèle utilise-t-il ? Que se passe-t-il si vous passez `stopWhen: stepCountIs(1)` ?

## 🧪 Exercice pratique

**Consigne.** Reprenez le projet Compta-Chat et livrez une version qui :
1. affiche sous chaque réponse de l'assistant le nombre de tokens d'entrée et de sortie (indice : le `onFinish` de `streamText` reçoit `usage` ; transmettez-le au client avec `toUIMessageStreamResponse({ messageMetadata: ... })` ou via un en-tête personnalisé) ;
2. refuse avec un code 429 toute requête d'un même `userId` au-delà de 20 messages sur 10 minutes (une `Map` en mémoire suffit pour cet exercice ; L102 fera mieux) ;
3. propose un sélecteur de modèle dans l'interface (`claude-sonnet-5-5`, `claude-haiku-5-5`, `gpt-6.1-terra`), envoyé au serveur dans le corps de la requête et validé par Zod contre une liste blanche.

**Critères de réussite.**
- Le flux reste fluide (premier token < 1,5 s en local avec Haiku 5.5).
- Un message de 5 000 caractères est rejeté par le serveur (413), même en contournant le `maxLength` du formulaire.
- Un modèle hors liste blanche (`"gpt-99"`) est rejeté avec un 400, sans appel au fournisseur.
- `git grep NEXT_PUBLIC_` ne retourne aucune clé.

**Pistes de corrigé.** Pour le point 1, `toUIMessageStreamResponse({ messageMetadata: ({ part }) => part.type === "finish" ? { usage: part.totalUsage } : undefined })` attache l'usage au message ; côté client, lisez `m.metadata`. Pour le point 2, stockez `Map<userId, number[]>` des horodatages et filtrez ceux des 10 dernières minutes. Pour le point 3, `z.enum([...])` sur le champ `model` et une table `{ id → LanguageModel }` côté serveur.

## ✅ Auto-évaluation express

1. Pourquoi le navigateur ne doit-il jamais appeler directement l'API du fournisseur ?
2. Quel paramètre de `streamText` limite le nombre d'allers-retours modèle ↔ outils ?
3. Que se passe-t-il si vous définissez `NEXT_PUBLIC_ANTHROPIC_API_KEY` ?

**Réponses.** 1. La clé API serait visible dans le code client et réutilisable par n'importe qui ; le serveur intermédiaire protège la clé et applique auth, limites et journalisation. 2. `stopWhen` (par exemple `stepCountIs(5)`) ; chaque étape correspond à un appel modèle. 3. La clé est embarquée dans le bundle JavaScript public : elle est compromise et doit être révoquée immédiatement.

## 📚 Pour aller plus loin
- [Vercel AI SDK — documentation](https://ai-sdk.dev) 🇬🇧 — référence de `streamText`, `useChat`, outils, fournisseurs et guides de migration entre versions.
- [Next.js — documentation](https://nextjs.org/docs) 🇬🇧 — App Router, Route Handlers, variables d'environnement, `maxDuration`.
- [Claude Platform — Streaming Messages](https://platform.claude.com/docs/en/build-with-claude/streaming) 🇬🇧 — détail des événements SSE si vous devez consommer le flux sans SDK.
- [OpenAI — Streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses) 🇬🇧 — équivalent côté Responses API.
- [Claude Platform — Reduce latency](https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency) 🇬🇧 — leviers pour améliorer le TTFT.

> 🗺️ **Et maintenant ?** — Votre chat répond en direct ; en L102, vous apprendrez à lui confier des tâches longues (file d'attente) et à garder la facture sous contrôle (quotas, cache, batch).
