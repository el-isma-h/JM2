---
id: L079
module: M18
level: N3
title: "Function calling et structured outputs"
minutes: 50
objectives:
  - "Déclarer une fonction (nom, description, schéma JSON strict) et exécuter la boucle appel → function_call → function_call_output"
  - "Obtenir une sortie JSON garantie conforme à un schéma avec text.format = json_schema, Pydantic et Zod"
  - "Comparer la syntaxe Responses API et Chat Completions pour les outils et les formats de sortie"
  - "Appliquer les contraintes du mode strict (additionalProperties: false, tous les champs required) et gérer les refus"
skills: ["C3.2"]
sources:
  - { title: "OpenAI Developers — Function calling", url: "https://developers.openai.com/api/docs/guides/agents-api/tools/functions", lang: "en" }
  - { title: "OpenAI Developers — Structured outputs", url: "https://developers.openai.com/api/docs/guides/structured-outputs", lang: "en" }
  - { title: "OpenAI Developers — Migrate to the Responses API", url: "https://developers.openai.com/api/docs/guides/migrate-to-responses", lang: "en" }
  - { title: "OpenAI Developers — Agents overview", url: "https://developers.openai.com/api/docs/guides/agents", lang: "en" }
  - { title: "OpenAI Developers — Predicted outputs", url: "https://developers.openai.com/api/docs/guides/predicted-outputs", lang: "en" }
---

# Function calling et structured outputs

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 18

## 🎯 Ce que vous saurez faire
- Donner des « mains » au modèle : il décide d'appeler votre fonction `chercher_commande(numero)`, vous l'exécutez, il formule la réponse.
- Garantir qu'une extraction (facture, CV, ticket SAV) ressort en **JSON valide et conforme à votre schéma**, sans `try/except` désespéré autour d'un `json.loads`.
- Utiliser les helpers des SDK (`responses.parse` + Pydantic en Python, `zodTextFormat` en TypeScript) pour ne jamais écrire un schéma JSON à la main.
- Savoir quand utiliser un outil, quand utiliser un format de sortie, et quand combiner les deux.

> 🧭 **En clair** — Jusqu'ici, le modèle ne savait que parler. Le *function calling* lui permet de dire « il faudrait vérifier dans le stock » : c'est votre programme qui fait la vérification, puis le modèle rédige la réponse avec le résultat, comme un conseiller au téléphone qui demande à un collègue d'aller voir en réserve. Les *structured outputs*, eux, imposent la forme de la réponse : au lieu d'un texte libre, le modèle remplit un formulaire dont chaque case est définie à l'avance (un « schéma JSON », la liste des champs et de leur type). Le premier change le déroulement de la conversation, le second seulement la présentation du résultat. Dans les deux cas, la forme est garantie, pas la justesse des valeurs : vos contrôles restent indispensables.

## 1. Deux mécanismes, deux intentions

Vous avez vu en M17 (L070-L071) le *tool use* et les sorties structurées chez Anthropic. Chez OpenAI, les deux existent, avec des noms différents :

| Besoin | Mécanisme OpenAI | Paramètre Responses API |
|---|---|---|
| Le modèle doit **agir** sur le monde (lire une base, envoyer un mail, calculer un devis) | **Function calling** (« functions », une catégorie d'outils) | `tools=[{"type":"function", ...}]` |
| Le modèle doit **répondre** dans une forme précise (JSON pour votre code) | **Structured outputs** | `text={"format":{"type":"json_schema", ...}}` |

Analogie : la *fonction*, c'est le stagiaire qui vous dit « je dois vérifier dans le logiciel de stock, pouvez-vous le faire pour moi ? » ; la *sortie structurée*, c'est le formulaire Cerfa que vous lui imposez pour rendre son rapport. Le premier modifie le **déroulement** de la conversation (un aller-retour avec votre code), le second modifie seulement la **forme** de la réponse finale.

Point commun décisif : les deux reposent sur **JSON Schema** et sur le mode **strict**, qui garantit (par décodage contraint côté serveur) que les arguments ou la réponse respectent exactement le schéma.

```quiz
{
  "q": "Une agence immobilière veut que l'assistant (a) consulte les disponibilités d'un appartement dans son logiciel, puis (b) rende un récapitulatif en JSON pour son CRM. Quels mécanismes utiliser ?",
  "options": [
    "Structured outputs pour (a), function calling pour (b)",
    "Function calling pour (a), structured outputs pour (b)",
    "Function calling pour les deux, les structured outputs étant réservés aux factures",
    "Aucun : un prompt bien rédigé suffit pour les deux"
  ],
  "answer": 1,
  "explanation": "Consulter le logiciel, c'est agir sur le monde : une fonction exécutée par votre code. Rendre un JSON conforme, c'est imposer une forme : une sortie structurée."
}
```

## 2. Function calling : la boucle complète

### 2.1 Déclarer une fonction

Dans la Responses API, une fonction est déclarée **à plat** (le guide de migration insiste : plus de sous-objet `function` comme en Chat Completions) :

```json
{
  "type": "function",
  "name": "chercher_commande",
  "description": "Retourne le statut d'une commande à partir de son numéro (format CMD-xxxxx).",
  "parameters": {
    "type": "object",
    "properties": {
      "numero": { "type": "string", "description": "Numéro de commande, ex. CMD-48213" }
    },
    "required": ["numero"],
    "additionalProperties": false
  },
  "strict": true
}
```

Une bonne `description` vaut mieux qu'un long prompt : c'est **elle** que le modèle lit pour décider d'appeler ou non la fonction. Précisez le *quand* (« à utiliser dès qu'un client cite un numéro de commande ») et le *format* attendu.

Avant le code, voici l'aller-retour qu'il réalise :

```
 Votre code                               OpenAI (modèle)
     │ 1. question + liste des outils           │
     │─────────────────────────────────────────►│
     │ 2. item function_call                    │
     │    (name, arguments en chaîne, call_id)  │
     │◄─────────────────────────────────────────│
     │ 3. VOUS exécutez la fonction             │
     │ 4. item function_call_output             │
     │    (même call_id, résultat en chaîne)    │
     │─────────────────────────────────────────►│
     │ 5. réponse rédigée (output_text)         │
     │◄─────────────────────────────────────────│
```

### 2.2 La boucle en Python

```python
# function_calling.py — boucle complète : appel → function_call → function_call_output → réponse
import json
from openai import OpenAI

client = OpenAI()  # OPENAI_API_KEY lue dans l'environnement

# 1) Votre "vraie" fonction (ici simulée : en production, une requête SQL ou HTTP)
def chercher_commande(numero: str) -> dict:
    base = {"CMD-48213": {"statut": "expédiée", "transporteur": "Colissimo", "eta": "2026-11-04"}}
    return base.get(numero, {"statut": "inconnue"})

OUTILS = [{
    "type": "function",
    "name": "chercher_commande",
    "description": "Retourne le statut d'une commande à partir de son numéro (format CMD-xxxxx). "
                   "À utiliser dès qu'un client mentionne un numéro de commande.",
    "parameters": {
        "type": "object",
        "properties": {"numero": {"type": "string", "description": "Ex. CMD-48213"}},
        "required": ["numero"],
        "additionalProperties": False,
    },
    "strict": True,
}]

INSTRUCTIONS = "Vous êtes l'assistant SAV d'une boutique de vélos française. Répondez en français."
entree = [{"role": "user", "content": "Bonjour, où en est ma commande CMD-48213 ?"}]

# 2) Premier appel : le modèle décide d'appeler (ou non) une fonction
r1 = client.responses.create(model="gpt-6.1-terra", instructions=INSTRUCTIONS,
                             tools=OUTILS, input=entree)

# 3) On exécute chaque function_call demandé et on renvoie les résultats
entree += r1.output                      # on conserve les items produits (dont le function_call)
for item in r1.output:
    if item.type == "function_call" and item.name == "chercher_commande":
        args = json.loads(item.arguments)            # JSON garanti conforme (strict)
        resultat = chercher_commande(**args)
        entree.append({
            "type": "function_call_output",
            "call_id": item.call_id,                 # relie le résultat à l'appel
            "output": json.dumps(resultat, ensure_ascii=False),
        })

# 4) Second appel : le modèle rédige la réponse finale avec le résultat
r2 = client.responses.create(model="gpt-6.1-terra", instructions=INSTRUCTIONS,
                             tools=OUTILS, input=entree)
print(r2.output_text)
```

Trois détails qui coûtent des heures de débogage :
- `item.arguments` est une **chaîne JSON** : il faut la parser.
- `call_id` doit être recopié tel quel dans `function_call_output`, sinon erreur 400.
- Il faut **renvoyer l'item `function_call`** dans l'entrée du second appel (ici via `entree += r1.output`), ou utiliser `previous_response_id=r1.id` et n'envoyer que les `function_call_output`.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : dans la Responses API, `item.arguments` est déjà un objet Python prêt à être passé à votre fonction.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. `arguments` est une chaîne JSON : il faut la décoder avec `json.loads` (ou `JSON.parse` en TypeScript). C'est l'une des différences avec Anthropic, où `input` est déjà un objet."
}
```

### 2.3 La même boucle en TypeScript, avec `previous_response_id`

```typescript
// function_calling.ts — npx tsx function_calling.ts
import OpenAI from "openai";
const client = new OpenAI();

type Statut = { statut: string; transporteur?: string; eta?: string };
function chercherCommande(numero: string): Statut {
  const base: Record<string, Statut> = {
    "CMD-48213": { statut: "expédiée", transporteur: "Colissimo", eta: "2026-11-04" },
  };
  return base[numero] ?? { statut: "inconnue" };
}

const outils: OpenAI.Responses.Tool[] = [{
  type: "function",
  name: "chercher_commande",
  description: "Retourne le statut d'une commande (format CMD-xxxxx). À utiliser dès qu'un numéro est cité.",
  parameters: {
    type: "object",
    properties: { numero: { type: "string", description: "Ex. CMD-48213" } },
    required: ["numero"],
    additionalProperties: false,
  },
  strict: true,
}];

async function main() {
  const instructions = "Vous êtes l'assistant SAV d'une boutique de vélos française. Répondez en français.";
  const r1 = await client.responses.create({
    model: "gpt-6.1-terra", instructions, tools: outils,
    input: "Bonjour, où en est ma commande CMD-48213 ?",
  });

  const sorties: OpenAI.Responses.ResponseInputItem[] = [];
  for (const item of r1.output) {
    if (item.type === "function_call" && item.name === "chercher_commande") {
      const args = JSON.parse(item.arguments) as { numero: string };
      sorties.push({
        type: "function_call_output",
        call_id: item.call_id,
        output: JSON.stringify(chercherCommande(args.numero)),
      });
    }
  }

  // Grâce à previous_response_id, pas besoin de renvoyer l'historique ni le function_call
  const r2 = await client.responses.create({
    model: "gpt-6.1-terra", instructions, tools: outils,
    previous_response_id: r1.id,
    input: sorties,
  });
  console.log(r2.output_text);
}
main();
```

> 💡 **À retenir** — La boucle « tant que la réponse contient des `function_call`, exécuter et renvoyer » est **le** motif de base de tout agent. L'Agents SDK (L081) l'implémente pour vous ; l'écrire une fois à la main vous évitera de le subir comme une boîte noire.

### 2.4 Contrôler l'appel : `tool_choice` et appels parallèles

- `tool_choice="auto"` (défaut) : le modèle choisit. `"required"` : il doit appeler au moins une fonction. `{"type":"function","name":"chercher_commande"}` : force cette fonction. `"none"` : interdit.
- Par défaut, le modèle peut émettre **plusieurs `function_call` dans une même réponse** (appels parallèles) : votre boucle doit traiter **tous** les items, pas seulement le premier. `parallel_tool_calls=False` le désactive si vos fonctions ont des effets de bord ordonnés.
- Les **outils intégrés** (`web_search`, `file_search`, `code_interpreter`, MCP distant) se déclarent dans le même tableau `tools` ; vous n'exécutez rien, OpenAI s'en charge (facturés à l'appel : 10 $ les 1 000 recherches web, 2,50 $ les 1 000 recherches de fichiers, nov. 2026).

> ⚠️ **Piège fréquent** — Une fonction « dangereuse » (virement, suppression, envoi de mail) ne doit **jamais** être exécutée automatiquement sur la seule foi du modèle. Ajoutez une confirmation humaine (*human in the loop*, rubrique 3 des [Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices)). Le module M23 détaille les attaques par injection de prompt qui visent exactement ces fonctions.

## 3. Structured outputs : du JSON garanti

### 3.1 Le principe

Avec `text.format` de type `json_schema` et `strict: true`, la réponse **est** un document JSON conforme au schéma, point. Les contraintes du mode strict (page [Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs)) :
- `additionalProperties: false` sur chaque objet ;
- **tous** les champs listés dans `required` (un champ optionnel se modélise par un type `["string", "null"]`) ;
- sous-ensemble de JSON Schema supporté (pas de `minLength` / `pattern` exotiques, profondeur limitée).

Le modèle peut toujours **refuser** (contenu interdit) : la réponse contient alors un item avec un champ `refusal` au lieu du JSON. Testez ce cas.

> 💡 **Autrement dit** — Le mode strict, c'est un formulaire administratif sans case libre : chaque champ est obligatoire (s'il peut rester vide, on l'écrit « texte ou rien », c'est-à-dire `["string", "null"]`), et l'on ne peut rien ajouter dans la marge (`additionalProperties: false`). En échange, le serveur garantit que le formulaire rendu est complet et bien rempli… dans la forme.

### 3.2 Python avec Pydantic et `responses.parse`

```python
# extraction_facture.py — sortie structurée garantie avec Pydantic
from pydantic import BaseModel, Field
from openai import OpenAI

client = OpenAI()

class Ligne(BaseModel):
    designation: str
    quantite: int
    prix_unitaire_ht: float

class Facture(BaseModel):
    fournisseur: str
    numero: str
    date_iso: str = Field(description="Date au format AAAA-MM-JJ")
    lignes: list[Ligne]
    total_ttc: float
    tva_pct: float | None          # devient ["number", "null"] dans le schéma strict

TEXTE = """FACTURE n° F-2026-0912 — Menuiserie Dupont, 12 rue des Lilas, 44000 Nantes
Date : 28/10/2026
- Porte intérieure chêne x2 : 340,00 € HT
- Pose x1 : 180,00 € HT
TVA 10 % — Total TTC : 946,00 €"""

reponse = client.responses.parse(
    model="gpt-6.1-terra",
    instructions="Extrayez les données de la facture. N'inventez aucune valeur absente.",
    input=TEXTE,
    text_format=Facture,            # le SDK génère le schéma strict et valide la sortie
)

facture = reponse.output_parsed    # instance Facture typée, ou None si refus
if facture is None:
    print("Refus ou sortie vide :", reponse.output_text)
else:
    print(facture.model_dump_json(indent=2, ensure_ascii=False))
    print("Contrôle :", sum(l.quantite * l.prix_unitaire_ht for l in facture.lignes), "€ HT")
```

Le contrôle arithmétique final n'est pas un gadget : le schéma garantit la **forme**, pas la **vérité**. Une facture dont les lignes ne somment pas au total doit partir en revue humaine (compétence C1.4, niveau 1, toujours valable pour les développeurs).

```quiz
{
  "q": "Une extraction de facture en mode strict renvoie un JSON valide dont les lignes totalisent 520 € HT, alors que la facture indique 860 € HT. Que conclure ?",
  "options": [
    "Le schéma garantit la forme, pas les valeurs : la facture part en revue humaine",
    "C'est impossible : le mode strict garantit aussi l'exactitude des montants",
    "Il faut désactiver le mode strict pour laisser le modèle corriger",
    "Il suffit de passer à `gpt-6-astra`, qui ne se trompe jamais"
  ],
  "answer": 0,
  "explanation": "Le décodage contraint assure un JSON conforme au schéma, pas des valeurs justes. D'où le contrôle arithmétique du script et la revue humaine en cas d'écart."
}
```

### 3.3 TypeScript avec Zod et `zodTextFormat`

```typescript
// extraction_facture.ts — npm install zod ; npx tsx extraction_facture.ts
import OpenAI from "openai";
import { zodTextFormat } from "openai/helpers/zod";
import { z } from "zod";

const client = new OpenAI();

const Ligne = z.object({
  designation: z.string(),
  quantite: z.number().int(),
  prix_unitaire_ht: z.number(),
});
const Facture = z.object({
  fournisseur: z.string(),
  numero: z.string(),
  date_iso: z.string().describe("Date au format AAAA-MM-JJ"),
  lignes: z.array(Ligne),
  total_ttc: z.number(),
  tva_pct: z.number().nullable(),
});

async function main() {
  const reponse = await client.responses.parse({
    model: "gpt-6.1-terra",
    instructions: "Extrayez les données de la facture. N'inventez aucune valeur absente.",
    input: "FACTURE n° F-2026-0912 — Menuiserie Dupont … TVA 10 % — Total TTC : 946,00 €",
    text: { format: zodTextFormat(Facture, "facture") },
  });

  const facture = reponse.output_parsed; // typé z.infer<typeof Facture> | null
  if (!facture) { console.log("Refus :", reponse.output_text); return; }
  console.log(JSON.stringify(facture, null, 2));
}
main();
```

### 3.4 Et sans helper ? Le schéma brut

Si vous appelez l'API depuis n8n ou `curl`, écrivez le schéma vous-même :

```json
"text": {
  "format": {
    "type": "json_schema",
    "name": "facture",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "fournisseur": { "type": "string" },
        "numero": { "type": "string" },
        "total_ttc": { "type": "number" }
      },
      "required": ["fournisseur", "numero", "total_ttc"],
      "additionalProperties": false
    }
  }
}
```

En Chat Completions, le même objet se plaçait dans `response_format` ; c'est l'un des renommages du guide de migration.

## 4. Combiner les deux : extraction puis action

Cas réel d'un cabinet comptable nantais : un mail client arrive, il faut (1) extraire la demande sous forme structurée, (2) si c'est une demande de pièce, la chercher dans la GED. Deux stratégies :

| Stratégie | Comment | Quand |
|---|---|---|
| **Fonction unique strict** | Une fonction `traiter_demande` dont les paramètres *sont* votre schéma | Quand l'action suit toujours l'extraction |
| **Deux étapes** | `responses.parse` pour classer, puis un second appel avec `tools` si besoin | Quand une partie des mails ne déclenche aucune action (moins cher : Luna pour le tri, Terra pour l'action) |

🎮 **Défi** — Faites appeler par `gpt-6-luna` une fonction `classer(categorie, urgence)` sur dix mails fictifs (catégories : `facture`, `attestation`, `rdv`, `autre`). Comptez combien de fois la classification est correcte, puis refaites le test sur `gpt-6.1-terra`. Vous venez de faire votre première **évaluation** (L082).

```mission
{
  "title": "Déclarer un champ facultatif en mode strict",
  "url": "https://developers.openai.com/api/docs/guides/structured-outputs",
  "steps": [
    "Ouvrez le guide Structured outputs",
    "Cherchez la section sur les schémas supportés et les contraintes du mode strict",
    "Repérez la règle sur `required` et la façon de rendre un champ optionnel"
  ],
  "question": "En mode strict, tous les champs doivent figurer dans `required`. Comment rendre un champ facultatif malgré tout ?",
  "hint": "Pensez à un type « union » qui accepte aussi une valeur vide.",
  "answer": "En le laissant dans `required` avec un type qui accepte `null` (par exemple `[\"string\", \"null\"]`), tout en gardant `additionalProperties: false` (guide consulté en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Le prix de l'outil intégré file_search",
  "url": "https://developers.openai.com/api/docs/pricing",
  "steps": [
    "Ouvrez la page Pricing",
    "Descendez jusqu'aux outils intégrés (web search, file search, code interpreter)",
    "Relevez le prix par appel et le prix du stockage"
  ],
  "question": "Combien coûtent 1 000 appels de l'outil `file_search`, et combien coûte le stockage des fichiers ?",
  "hint": "Le stockage est facturé au Go et par jour, avec une franchise.",
  "answer": "2,50 $ les 1 000 appels, plus 0,10 $ par Go et par jour de stockage (1 Go gratuit) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Construisez un « assistant planning » pour un salon de coiffure (Python ou TypeScript) :
1. une fonction `creneaux_disponibles(date_iso, duree_min)` qui renvoie une liste de créneaux (simulée) ;
2. une fonction `reserver(date_iso, heure, nom_client)` qui ne s'exécute **qu'après** une confirmation `input("Confirmer ? (o/n)")` ;
3. une sortie structurée finale `{ "resume": str, "rdv_cree": bool, "date_iso": str | null, "heure": str | null }` obtenue par `responses.parse` ;
4. la boucle doit supporter des **appels parallèles** (le client demande deux dates).

**Critères de réussite.** Le schéma est strict et valide ; `reserver` n'est jamais appelée sans confirmation ; les `call_id` sont correctement renvoyés ; le JSON final est validé par Pydantic/Zod ; un refus ou une absence de créneau est géré sans exception non capturée.

**Pistes de corrigé.** Réutilisez la boucle de la section 2.2 dans une fonction `executer_tour(entree)` appelée tant que la réponse contient des `function_call` ; pour la sortie finale, faites un dernier appel `responses.parse` avec `previous_response_id` et `tool_choice="none"`.

## ✅ Auto-évaluation express

1. Quel champ relie un `function_call_output` à l'appel qui l'a déclenché ?
2. En mode strict, comment déclarer un champ facultatif ?
3. Que garantit un schéma strict, et que ne garantit-il pas ?

*Réponses : 1) `call_id`. 2) En le laissant dans `required` mais avec un type nullable (`["string","null"]`, `str | None`, `.nullable()`). 3) La forme (JSON valide conforme au schéma) ; pas l'exactitude des valeurs, d'où les contrôles métier.*

## 📚 Pour aller plus loin
- [Function calling](https://developers.openai.com/api/docs/guides/agents-api/tools/functions) 🇬🇧 — guide officiel, avec les bonnes pratiques de description et `tool_choice`.
- [Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs) 🇬🇧 — contraintes du mode strict, sous-ensemble JSON Schema, gestion des refus.
- [Agents overview](https://developers.openai.com/api/docs/guides/agents) 🇬🇧 — comment les fonctions deviennent des outils d'agent.
- [Predicted outputs](https://developers.openai.com/api/docs/guides/predicted-outputs) 🇬🇧 — accélérer les réponses quand une grande partie de la sortie est connue à l'avance.

> 🗺️ **Et maintenant ?** — Votre assistant agit et répond en JSON ; en L080, il apprend à voir (images), à écouter et parler (audio), et à retrouver un document par le sens (embeddings).
