---
id: L081
module: M18
level: N3
title: "OpenAI Agents SDK"
minutes: 55
objectives:
  - "Expliquer les primitives de l'Agents SDK (Agent, outils, handoffs, guardrails, sessions, tracing) et les situer par rapport à la boucle manuelle de la L079"
  - "Construire en Python et en TypeScript un agent muni d'outils typés et d'un handoff vers un agent spécialisé"
  - "Mettre en place un guardrail d'entrée et une limite de tours pour borner le comportement et le coût"
  - "Distinguer Agents SDK (exécuté dans votre application) et Agents API (harnais géré par OpenAI), et brancher un serveur MCP"
skills: ["C3.1", "C3.2"]
sources:
  - { title: "OpenAI Developers — Agents SDK", url: "https://developers.openai.com/api/docs/guides/agents/sdk", lang: "en" }
  - { title: "OpenAI Developers — Agents SDK quickstart", url: "https://developers.openai.com/api/docs/guides/agents/quickstart", lang: "en" }
  - { title: "OpenAI Developers — Agents overview", url: "https://developers.openai.com/api/docs/guides/agents", lang: "en" }
  - { title: "OpenAI Developers — Guardrails and approvals", url: "https://developers.openai.com/api/docs/guides/agents/guardrails-approvals", lang: "en" }
  - { title: "openai-agents-python (GitHub)", url: "https://github.com/openai/openai-agents-python", lang: "en" }
  - { title: "openai-agents-js (GitHub)", url: "https://github.com/openai/openai-agents-js", lang: "en" }
  - { title: "OpenAI Developers — Realtime + MCP", url: "https://developers.openai.com/api/docs/guides/realtime-mcp", lang: "en" }
---

# OpenAI Agents SDK

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 18

## 🎯 Ce que vous saurez faire
- Remplacer la boucle `function_call` → `function_call_output` écrite à la main en L079 par un `Runner.run(agent, "…")` et comprendre ce que le SDK fait à votre place.
- Décrire un outil par une simple fonction Python décorée (ou une fonction TypeScript + schéma Zod), sans écrire de JSON Schema.
- Faire collaborer plusieurs agents par **handoff** (le standard passe la main au spécialiste) et poser des **guardrails** qui coupent court aux demandes hors périmètre.
- Lire une **trace** d'exécution et borner un agent (tours, approbations) pour qu'il ne vide pas votre compte.

> 🧭 **En clair** — Écrire soi-même la boucle « le modèle demande un outil, je l'exécute, je lui rends le résultat » devient vite fastidieux dès qu'il y a plusieurs outils et plusieurs agents. L'Agents SDK d'OpenAI est un chef d'orchestre prêt à l'emploi : vous décrivez vos collaborateurs (les agents), leurs outils et leurs règles, et il fait tourner la boucle à votre place. Comme dans un cabinet, l'accueil peut passer la main à un spécialiste (le *handoff*), un vigile filtre les demandes hors périmètre (le *guardrail*), et un journal note tout ce qui s'est passé (la *trace*). Votre travail : bien décrire les outils et poser des limites, pour que l'agent ne tourne pas en rond à vos frais.

## 1. Pourquoi un SDK, et lequel

En L079, vous avez écrit la boucle agentique à la main : tant que la réponse contient des appels de fonction, exécuter, renvoyer, recommencer. Multipliez cela par cinq outils, trois agents, du streaming, des validations d'entrée et de sortie, et des traces pour comprendre ce qui s'est passé à 3 h du matin… vous obtenez un framework. L'**OpenAI Agents SDK** est celui d'OpenAI, publié sous licence MIT, en **Python** (`pip install openai-agents`) et **TypeScript** (`npm install @openai/agents`).

La page officielle [Agents SDK](https://developers.openai.com/api/docs/guides/agents/sdk) le résume par ses primitives :

| Primitive | Rôle | Analogie « cabinet comptable » |
|---|---|---|
| **Agent** | un modèle + des instructions + des outils | un collaborateur avec sa fiche de poste |
| **Tools** | fonctions locales, outils intégrés (web search, file search, code interpreter), serveurs MCP, et même un autre agent « en tant qu'outil » | le logiciel métier, les classeurs, le téléphone |
| **Handoffs** | un agent délègue la conversation à un autre | « je vous passe ma collègue spécialiste TVA » |
| **Guardrails** | validations en parallèle sur l'entrée et la sortie | la procédure d'accueil qui filtre les demandes hors périmètre |
| **Sessions / Results & state** | mémoire de conversation entre deux exécutions | le dossier client |
| **Running agents** | `Runner.run` / `run()`, avec streaming | la journée de travail |
| **Tracing** | chaque exécution est tracée (console, dashboard OpenAI, intégrations d'observabilité) | le journal des opérations |
| **Sandboxes conteneurisés, pipeline vocal** | exécuter du code isolé ; agents Realtime (L080) | l'atelier et le standard téléphonique |

Important : le SDK **s'exécute dans votre application** (votre serveur, votre machine). OpenAI propose aussi une **Agents API**, harnais géré côté OpenAI, où la boucle tourne chez eux. Le choix ressemble à celui entre Claude Agent SDK et Managed Agents vu en M17 (L074) : contrôle et portabilité d'un côté, simplicité d'exploitation de l'autre. Le SDK est par ailleurs **agnostique** : il peut piloter d'autres fournisseurs via une interface de modèle compatible, ce qui servira en M19.

```quiz
{
  "q": "Quelle est la différence entre l'Agents SDK et l'Agents API d'OpenAI ?",
  "options": [
    "Aucune : ce sont deux noms du même produit",
    "Le SDK tourne chez vous ; l'Agents API tourne chez OpenAI",
    "Le SDK est payant à l'usage, l'Agents API est gratuite",
    "Le SDK ne fonctionne qu'en TypeScript, l'API qu'en Python"
  ],
  "answer": 1,
  "explanation": "Le SDK est une bibliothèque qui tourne chez vous (contrôle, portabilité, autres fournisseurs) ; l'Agents API fait tourner la boucle sur l'infrastructure d'OpenAI."
}
```

## 2. Premier agent avec outils

### 2.1 Python : un agent « devis » pour un plombier

```python
# agent_devis.py — pip install openai-agents ; OPENAI_API_KEY dans l'environnement
import asyncio
from agents import Agent, Runner, function_tool

# Un outil = une fonction Python typée + docstring : le SDK génère le schéma JSON strict
@function_tool
def tarif_main_oeuvre(type_intervention: str) -> float:
    """Retourne le tarif horaire HT en euros pour un type d'intervention.

    Args:
        type_intervention: 'depannage', 'installation' ou 'entretien'.
    """
    grille = {"depannage": 65.0, "installation": 55.0, "entretien": 50.0}
    return grille.get(type_intervention, 60.0)

@function_tool
def prix_piece(reference: str) -> dict:
    """Retourne le prix HT et le délai d'une pièce à partir de sa référence catalogue."""
    catalogue = {"MIT-120": {"libelle": "Mitigeur lavabo", "prix_ht": 89.0, "delai_jours": 2}}
    return catalogue.get(reference, {"libelle": "inconnue", "prix_ht": None, "delai_jours": None})

agent = Agent(
    name="Assistant devis plomberie",
    model="gpt-6.1-terra",
    instructions=(
        "Vous préparez des devis pour un plombier de Toulouse. Répondez en français. "
        "Utilisez les outils pour tout tarif ; n'inventez jamais un prix. "
        "Présentez un récapitulatif HT, TVA 10 % (rénovation) et TTC."
    ),
    tools=[tarif_main_oeuvre, prix_piece],
)

async def main():
    resultat = await Runner.run(
        agent,
        "Remplacement d'un mitigeur MIT-120, environ 1 h 30 de dépannage.",
        max_turns=6,          # borne le nombre d'allers-retours modèle ↔ outils
    )
    print(resultat.final_output)
    # Pour voir les étapes : for item in resultat.new_items: print(item)

asyncio.run(main())
```

Ce que le SDK a fait : généré deux schémas stricts à partir des signatures et des docstrings, envoyé la requête, détecté les `function_call`, exécuté vos fonctions, renvoyé les `function_call_output`, et recommencé jusqu'à une réponse finale ou `max_turns`. Exactement la L079, sans la plomberie (c'est le cas de le dire).

### 2.2 TypeScript : le même agent avec Zod

```typescript
// agent_devis.ts — npm install @openai/agents zod ; npx tsx agent_devis.ts
import { Agent, run, tool } from "@openai/agents";
import { z } from "zod";

const tarifMainOeuvre = tool({
  name: "tarif_main_oeuvre",
  description: "Retourne le tarif horaire HT en euros pour un type d'intervention.",
  parameters: z.object({
    type_intervention: z.enum(["depannage", "installation", "entretien"]),
  }),
  execute: async ({ type_intervention }) =>
    ({ depannage: 65, installation: 55, entretien: 50 }[type_intervention]),
});

const prixPiece = tool({
  name: "prix_piece",
  description: "Retourne le prix HT et le délai d'une pièce à partir de sa référence catalogue.",
  parameters: z.object({ reference: z.string() }),
  execute: async ({ reference }) =>
    reference === "MIT-120"
      ? { libelle: "Mitigeur lavabo", prix_ht: 89, delai_jours: 2 }
      : { libelle: "inconnue", prix_ht: null, delai_jours: null },
});

const agent = new Agent({
  name: "Assistant devis plomberie",
  model: "gpt-6.1-terra",
  instructions:
    "Vous préparez des devis pour un plombier de Toulouse. Répondez en français. " +
    "Utilisez les outils pour tout tarif ; n'inventez jamais un prix. Récapitulatif HT, TVA 10 %, TTC.",
  tools: [tarifMainOeuvre, prixPiece],
});

async function main() {
  const resultat = await run(agent, "Remplacement d'un mitigeur MIT-120, environ 1 h 30 de dépannage.", {
    maxTurns: 6,
  });
  console.log(resultat.finalOutput);
}
main();
```

> 💡 **À retenir** — La qualité d'un agent dépend d'abord de la **description de ses outils** et de ses **instructions**, pas du framework. Un outil mal décrit sera mal appelé, SDK ou pas. Testez chaque outil seul avant de les combiner.

## 3. Handoffs : passer la main au spécialiste

Un cabinet d'expertise comptable reçoit des demandes mêlées : paie, TVA, création d'entreprise. Plutôt qu'un agent omniscient aux instructions interminables, on construit un **agent d'accueil** qui **délègue** :

```python
# handoffs.py — triage puis délégation
import asyncio
from agents import Agent, Runner

agent_paie = Agent(
    name="Spécialiste paie",
    model="gpt-6.1-sol",
    handoff_description="Questions de bulletins de paie, cotisations, congés, DSN.",
    instructions="Vous répondez aux questions de paie d'une PME française, en français, en citant la source légale à vérifier.",
)
agent_tva = Agent(
    name="Spécialiste TVA",
    model="gpt-6.1-sol",
    handoff_description="Questions de TVA : taux, déclarations CA3/CA12, autoliquidation.",
    instructions="Vous répondez aux questions de TVA d'une PME française, en français, prudemment.",
)
accueil = Agent(
    name="Accueil cabinet",
    model="gpt-6-luna",                       # le triage est simple : modèle peu coûteux
    instructions=(
        "Vous êtes l'accueil d'un cabinet comptable. Identifiez le sujet et transférez "
        "au spécialiste adapté. Si le sujet n'est ni paie ni TVA, répondez que le cabinet rappellera."
    ),
    handoffs=[agent_paie, agent_tva],
)

async def main():
    r = await Runner.run(accueil, "Quel taux de TVA pour des travaux de rénovation dans un logement de plus de 2 ans ?")
    print("Agent final :", r.last_agent.name)   # attendu : Spécialiste TVA
    print(r.final_output)

asyncio.run(main())
```

Sous le capot, un handoff est… un **outil** (`transfer_to_specialiste_tva`) que l'agent d'accueil peut appeler ; le SDK bascule alors la conversation vers le spécialiste, qui reçoit l'historique. Vous pouvez ajouter un `input_filter` pour ne transmettre qu'une partie du contexte (confidentialité, coût) et un `on_handoff` pour journaliser. L'alternative, **« agent en tant qu'outil »** (`agent.as_tool(...)`), garde le contrôle à l'agent principal, qui appelle le spécialiste comme une fonction et reformule : à préférer quand c'est l'accueil qui doit répondre au client.

```
 Client ──► Accueil (gpt-6-luna)
               │ appelle l'outil transfer_to_specialiste_tva
               ▼
   ┌──────────────────┐          ┌──────────────────┐
   │ Spécialiste TVA  │    ou    │ Spécialiste paie │
   │  (gpt-6.1-sol)   │          │  (gpt-6.1-sol)   │
   └────────┬─────────┘          └──────────────────┘
            ▼
   réponse finale au client (r.last_agent = « Spécialiste TVA »)

 Handoff          : le spécialiste reprend la conversation.
 Agent-outil      : l'accueil garde la main, appelle le spécialiste
                    comme une fonction, puis reformule.
```

```quiz
{
  "q": "Votre assistant d'accueil doit toujours répondre lui-même au client, en reformulant l'avis d'un spécialiste juridique. Quel mécanisme choisir ?",
  "options": [
    "Le spécialiste exposé comme outil (`as_tool`)",
    "Un handoff vers le spécialiste juridique",
    "Un guardrail de sortie sur l'accueil",
    "Une valeur plus élevée de `max_turns`"
  ],
  "answer": 0,
  "explanation": "Avec un handoff, c'est le spécialiste qui finit la conversation. Avec « agent en tant qu'outil », l'accueil garde le contrôle et rédige la réponse finale."
}
```

🎮 **Défi** — Ajoutez un troisième spécialiste « création d'entreprise » et faites poser trois questions ambiguës à l'accueil. Combien de fois le bon spécialiste est-il choisi ? Passez l'accueil de Luna à Terra : la différence justifie-t-elle le coût ×10 ?

## 4. Guardrails, approbations et bornes

### 4.1 Guardrail d'entrée

Un guardrail est une fonction (souvent un petit agent sur `gpt-6-luna`) qui s'exécute **en parallèle** de l'agent principal et déclenche un **tripwire** quand l'entrée est hors périmètre. Si le tripwire saute, l'exécution principale est annulée : vous ne payez pas une longue réponse d'Astra à une question qui n'aurait pas dû partir.

> 💡 **Autrement dit** — Le guardrail, c'est le vigile à l'entrée du magasin : il examine la demande pendant que le vendeur commence à servir, et s'il donne l'alerte (le *tripwire*, ou « fil-piège »), tout s'arrête avant que la note ne grimpe.

```python
# guardrail.py — bloquer les demandes de conseil fiscal personnalisé
import asyncio
from pydantic import BaseModel
from agents import Agent, Runner, GuardrailFunctionOutput, InputGuardrailTripwireTriggered, input_guardrail

class Verdict(BaseModel):
    hors_perimetre: bool
    raison: str

juge = Agent(
    name="Filtre périmètre",
    model="gpt-6-luna",
    instructions="Dites si la demande réclame un conseil fiscal PERSONNALISÉ (optimisation, montage) "
                 "plutôt qu'une information générale. Répondez au format demandé.",
    output_type=Verdict,                      # sortie structurée garantie (L079)
)

@input_guardrail
async def filtre_perimetre(ctx, agent, entree):
    r = await Runner.run(juge, entree, context=ctx.context)
    verdict = r.final_output_as(Verdict)
    return GuardrailFunctionOutput(output_info=verdict, tripwire_triggered=verdict.hors_perimetre)

assistant = Agent(
    name="Assistant information comptable",
    model="gpt-6.1-terra",
    instructions="Informations générales de comptabilité pour PME, en français.",
    input_guardrails=[filtre_perimetre],
)

async def main():
    for q in ["C'est quoi un amortissement ?", "Comment je fais pour ne pas payer d'impôt sur ma plus-value ?"]:
        try:
            r = await Runner.run(assistant, q)
            print("OK  :", r.final_output[:80], "…")
        except InputGuardrailTripwireTriggered as e:
            print("STOP:", q, "→", e.guardrail_result.output.output_info.raison)

asyncio.run(main())
```

Les **guardrails de sortie** (`@output_guardrail`) fonctionnent symétriquement : vérifier qu'une réponse ne contient pas de données personnelles, de promesse d'engagement, ou qu'elle respecte le format. La page [Guardrails and approvals](https://developers.openai.com/api/docs/guides/agents/guardrails-approvals) décrit aussi les **approbations** : un outil marqué comme nécessitant une validation interrompt l'exécution, vous présentez la demande à un humain, puis vous reprenez. C'est la bonne réponse au piège de la L079 (fonctions dangereuses).

### 4.2 Les bornes à toujours poser

| Borne | Comment | Pourquoi |
|---|---|---|
| Nombre de tours | `max_turns` / `maxTurns` | un agent qui boucle sur un outil en erreur peut faire 100 appels |
| Tokens de sortie | `model_settings` (`max_tokens`) | limite le coût d'une réponse |
| Outils sensibles | approbation (needs approval) | aucune action irréversible sans humain |
| Temps | timeout côté application | un run bloqué ne doit pas bloquer votre serveur |
| Budget global | compteur sur `usage` des résultats + alerte | rubrique « contraindre l'entrée et limiter les tokens de sortie » des Safety best practices |

> ⚠️ **Piège fréquent** — Oublier `max_turns` **et** donner un outil qui renvoie une erreur ambiguë (« erreur inconnue »). Le modèle réessaie de bonne foi, encore et encore. Renvoyez des erreurs **explicites et actionnables** (« référence inconnue, demandez-la au client ») : l'agent saura s'arrêter.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : sans `max_turns`, un agent dont l'outil renvoie « erreur inconnue » peut enchaîner des dizaines d'appels facturés.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai. Le modèle réessaie de bonne foi tant que rien ne l'arrête. `max_turns` borne la boucle, et une erreur explicite (« référence inconnue, demandez-la au client ») l'aide à s'arrêter de lui-même."
}
```

## 5. Sessions, streaming, MCP et traces

- **Sessions** : par défaut, chaque `Runner.run` est sans mémoire. Le SDK fournit des sessions (mémoire SQLite locale ou API Conversations d'OpenAI) pour enchaîner les tours sans gérer l'historique ; vous pouvez aussi passer `r.to_input_list()` d'un run au suivant.
- **Streaming** : `Runner.run_streamed(agent, ...)` (Python) ou `run(agent, input, { stream: true })` (TypeScript) émet des événements au fil de l'eau, utiles pour une interface de chat (M22).
- **MCP** : un serveur MCP (vu en M17 L075) se branche comme source d'outils : `mcp_servers=[...]` avec un transport stdio ou HTTP streamable ; le guide [Realtime + MCP](https://developers.openai.com/api/docs/guides/realtime-mcp) montre la même idée pour les agents vocaux. Un serveur MCP écrit pour Claude fonctionne donc ici sans modification : c'est tout l'intérêt d'un protocole ouvert.
- **Traces** : chaque exécution est tracée par défaut (vue dans le dashboard OpenAI ; exports vers des outils d'observabilité comme Langfuse ou LangSmith, M22). Une trace montre l'arbre agent → outils → handoffs avec les tokens de chaque étape : c'est votre premier réflexe quand un agent « fait n'importe quoi ». Si vos données sont sensibles, désactivez l'envoi des traces (`OPENAI_AGENTS_DISABLE_TRACING=1`) ou exportez-les vers votre propre backend.

Ce que vous construisez ici est la même architecture que celle du module M21 (agents en code, multi-fournisseurs) : outils, boucle, mémoire, bornes. Le SDK OpenAI est une implémentation ; LangGraph, Pydantic AI, Claude Agent SDK ou Google ADK en sont d'autres, et le module M21 vous aidera à choisir.

```mission
{
  "title": "Les primitives de l'Agents SDK",
  "url": "https://developers.openai.com/api/docs/guides/agents/sdk",
  "steps": [
    "Ouvrez la page Agents SDK de la documentation OpenAI",
    "Repérez la liste des primitives (concepts de base)",
    "Identifiez celle qui délègue et celle qui valide"
  ],
  "question": "Quelle primitive permet de déléguer la conversation à un autre agent, et laquelle valide les entrées et les sorties ?",
  "hint": "Le tableau de la section 1 les traduit ; vérifiez les noms anglais sur la page.",
  "answer": "Handoffs pour déléguer, Guardrails pour valider ; la page cite aussi Agents, Results & state, Running agents, les sandboxes, le pipeline vocal et le tracing (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Que se passe-t-il quand un outil demande une approbation ?",
  "url": "https://developers.openai.com/api/docs/guides/agents/guardrails-approvals",
  "steps": [
    "Ouvrez la page Guardrails and approvals",
    "Cherchez la partie consacrée aux approbations (human in the loop)",
    "Lisez ce qui arrive à l'exécution quand un outil sensible est appelé"
  ],
  "question": "Quand un outil marqué comme nécessitant une approbation est appelé, que fait le SDK, et que doit faire votre application ?",
  "hint": "Le mot-clé est « interruption ».",
  "answer": "L'exécution est interrompue ; votre application présente la demande à un humain, puis reprend le run après sa décision (page consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Construisez un système d'agents pour une **agence immobilière** (Python ou TypeScript) :
1. un agent d'accueil (`gpt-6-luna`) avec deux handoffs : « Estimation » (outil `prix_m2(code_postal)` simulé) et « Visites » (outils `creneaux(date_iso)` et `reserver_visite(...)`) ;
2. `reserver_visite` requiert une **approbation** humaine (ou, à défaut, une confirmation `input()` dans l'outil) ;
3. un guardrail d'entrée qui bloque toute demande contenant des données bancaires (IBAN, numéro de carte) ;
4. `max_turns=8` partout, et un affichage, en fin de run, des tokens consommés par agent.

**Critères de réussite.** Le bon spécialiste est choisi sur 4 demandes de test sur 5 ; le guardrail bloque un IBAN fictif ; aucune visite n'est réservée sans confirmation ; le run affiche l'agent final et le coût estimé (tarifs L078).

**Pistes de corrigé.** Partez de `handoffs.py` et `guardrail.py` ; pour les tokens, parcourez `resultat.raw_responses` et additionnez `usage.input_tokens` / `usage.output_tokens` ; pour l'IBAN, une expression régulière suffit au guardrail, inutile d'appeler un modèle.

## ✅ Auto-évaluation express

1. Qu'est-ce qu'un handoff, techniquement, pour le modèle ?
2. Pourquoi un guardrail d'entrée fait-il économiser de l'argent ?
3. Quelle différence entre Agents SDK et Agents API ?

*Réponses : 1) Un outil `transfer_to_<agent>` ; quand il est appelé, le SDK bascule la conversation vers l'agent cible. 2) Il s'exécute en parallèle et annule le run principal dès qu'il se déclenche, avant que le modèle coûteux n'ait produit une longue réponse. 3) Le SDK s'exécute dans votre application (contrôle, portabilité, multi-fournisseurs) ; l'Agents API est un harnais géré côté OpenAI.*

## 📚 Pour aller plus loin
- [Agents SDK](https://developers.openai.com/api/docs/guides/agents/sdk) 🇬🇧 — la page de référence des primitives.
- [Agents SDK quickstart](https://developers.openai.com/api/docs/guides/agents/quickstart) 🇬🇧 — un premier agent avec handoffs et guardrails en dix minutes.
- [openai-agents-python](https://github.com/openai/openai-agents-python) 🇬🇧 et [openai-agents-js](https://github.com/openai/openai-agents-js) 🇬🇧 — dépôts officiels, exemples et documentation détaillée.
- [Guardrails and approvals](https://developers.openai.com/api/docs/guides/agents/guardrails-approvals) 🇬🇧 — patrons de validation et d'interruption pour approbation humaine.
- [OpenAI Academy — Build with AI](https://academy.openai.com/pages/courses) 🇬🇧 — le parcours développeurs (Codex + API) et le cours à badge « Agents and Workflows » ; nous vous encourageons à le suivre en complément.

> 🗺️ **Et maintenant ?** — Votre agent fonctionne ; reste à prouver qu'il marche et à le rendre moins cher : c'est l'objet de la L082 (Evals, Batch et fine-tuning).
