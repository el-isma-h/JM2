---
id: L083
module: M18
level: N3
title: "Projet : le même assistant, porté sur OpenAI"
minutes: 65
objectives:
  - "Porter l'assistant devis pour artisan du module M17 (Claude) vers la Responses API d'OpenAI en conservant le comportement et les tests"
  - "Établir la correspondance Anthropic ↔ OpenAI pour les messages, le system prompt, les outils, les sorties structurées, le cache et le streaming"
  - "Choisir un modèle équivalent chez chaque fournisseur et comparer le coût d'un mois d'exploitation avec et sans cache"
  - "Isoler le fournisseur derrière une interface pour rendre l'application réversible"
skills: ["C3.1", "C3.2"]
sources:
  - { title: "OpenAI Developers — Migrate to the Responses API", url: "https://developers.openai.com/api/docs/guides/migrate-to-responses", lang: "en" }
  - { title: "OpenAI Developers — Function calling", url: "https://developers.openai.com/api/docs/guides/agents-api/tools/functions", lang: "en" }
  - { title: "OpenAI Developers — Structured outputs", url: "https://developers.openai.com/api/docs/guides/structured-outputs", lang: "en" }
  - { title: "OpenAI Developers — Streaming responses", url: "https://developers.openai.com/api/docs/guides/streaming-responses", lang: "en" }
  - { title: "OpenAI Developers — Pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "Claude Platform — Using the Messages API", url: "https://platform.claude.com/docs/en/build-with-claude/working-with-messages", lang: "en" }
  - { title: "Claude Platform — Tool use overview", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview", lang: "en" }
  - { title: "Claude Platform — Structured outputs", url: "https://platform.claude.com/docs/en/build-with-claude/structured-outputs", lang: "en" }
  - { title: "Claude Platform — Prompt caching", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-caching", lang: "en" }
  - { title: "Claude Platform — Streaming", url: "https://platform.claude.com/docs/en/build-with-claude/streaming", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — OpenAI SDK compatibility", url: "https://platform.claude.com/docs/en/cli-sdks-libraries/libraries/openai-sdk", lang: "en" }
---

# Projet : le même assistant, porté sur OpenAI

> ⏱ 65 min · 🎯 Niveau 3 · 📚 Module 18

## 🎯 Ce que vous saurez faire
- Reprendre l'assistant devis de l'artisan construit en M17 avec Claude et le faire tourner sur GPT-6 **sans changer son comportement** ni ses tests.
- Lire d'un coup d'œil la table de correspondance des deux API et savoir où se cachent les vraies différences (il y en a moins qu'on ne le dit, mais elles mordent).
- Chiffrer, pour un client, le coût mensuel de chaque option, cache compris, et expliquer pourquoi le prix catalogue ne suffit pas à décider.
- Structurer le code pour que le fournisseur soit un **détail d'implémentation** : la compétence clé du module M19.

> 🧭 **En clair** — Porter une application d'un fournisseur d'IA à un autre, c'est comme changer de fournisseur d'électricité sans refaire l'installation de la maison : si les prises sont standard, on ne touche qu'au compteur. Ici, la « maison », c'est votre logique métier (catalogue, TVA, devis) et vos 20 tests ; le « compteur », c'est un petit fichier adaptateur qui traduit vers Claude ou vers OpenAI. Les deux API se ressemblent beaucoup, mais quelques détails changent de nom ou de place, et ce sont eux qui provoquent les erreurs. Le portage est réussi quand les mêmes tests passent, et vous saurez dire au client combien chaque option lui coûte par mois.

## 1. Le projet de départ : l'assistant devis de l'artisan

> 📌 **Note de cohérence** — Le projet de la leçon L077 s'appelle **Devis-Express** (Karim, électricien à Toulouse). Cette leçon utilise une variante plus courte du même assistant, la **Menuiserie Dupont** (Nantes), pour que vous puissiez la suivre même sans avoir terminé L077. Si vous avez construit Devis-Express, appliquez exactement la même méthode de portage à votre propre code : le tableau de correspondance Anthropic ↔ OpenAI, l'adaptateur et le calcul des coûts ci-dessous valent à l'identique.

Rappel du cahier des charges du projet M17 (L077). *Si vous ne l'avez pas encore réalisé, voici sa description ; vous pouvez le construire directement dans cette leçon.*

**Client :** Menuiserie Dupont, Nantes, 4 salariés. **Problème :** la gérante passe deux heures par jour à transformer des demandes clients (mails, SMS, messages vocaux transcrits) en devis chiffrés. **Solution :** un assistant conversationnel qui :

1. comprend la demande en langage naturel (« une porte intérieure en chêne avec pose, pour fin novembre ») ;
2. interroge le **catalogue** et la **grille de main-d'œuvre** par des outils (`chercher_article`, `tarif_pose`) ;
3. pose une question quand une information manque (dimensions, délai) ;
4. produit un **devis structuré** en JSON (lignes, totaux HT/TVA/TTC, hypothèses) prêt pour le logiciel de facturation ;
5. **streame** ses réponses dans l'interface de la gérante ;
6. utilise un **system prompt long** (règles de TVA rénovation à 10 %, conditions générales, ton) mis en **cache** pour contenir les coûts.

Les tests du projet M17 (un jeu de 20 demandes avec les devis attendus, évalués par correspondance de champs) sont conservés tels quels : **c'est eux qui diront si le portage est réussi**. Une migration sans tests n'est pas une migration, c'est un pari.

## 2. Table de correspondance Anthropic ↔ OpenAI (nov. 2026)

| Concept | Anthropic — Messages API (`anthropic`) | OpenAI — Responses API (`openai`) | Ce qui change vraiment |
|---|---|---|---|
| Point d'entrée | `client.messages.create(...)` | `client.responses.create(...)` | nom |
| Clé | `ANTHROPIC_API_KEY` | `OPENAI_API_KEY` | nom |
| System prompt | paramètre `system` (chaîne ou liste de blocs) | paramètre `instructions` (ou item de rôle `developer`) | équivalent |
| Historique | `messages=[{role, content}]`, **vous** renvoyez tout | `input=[...]` (tout renvoyer) **ou** `previous_response_id` (stocké chez OpenAI, `store=True` par défaut) | OpenAI peut porter l'état ; incidence RGPD |
| Limite de sortie | `max_tokens` **obligatoire** | `max_output_tokens` optionnel | oubli possible côté OpenAI |
| Contenu de réponse | `content[]` : blocs `text`, `tool_use`, `thinking` ; `stop_reason` | `output[]` : items `message`, `function_call`, `reasoning` ; `status` ; raccourci `output_text` | structure parallèle |
| Déclarer un outil | `tools=[{name, description, input_schema}]` | `tools=[{type:"function", name, description, parameters, strict}]` | `input_schema` → `parameters` ; `strict` |
| Appel d'outil | bloc `tool_use` {id, name, input (objet)} + `stop_reason: "tool_use"` | item `function_call` {call_id, name, arguments (**chaîne JSON**)} | parser `arguments` |
| Résultat d'outil | message `user` avec bloc `tool_result` {tool_use_id, content} | item `function_call_output` {call_id, output} | nom des champs |
| Forcer un outil | `tool_choice` (`auto`/`any`/`tool`) ; forçage → erreur 400 sur Opus 5.5 et Sonnet 5.5 ; accepté sur Haiku 5.5, mais la réponse commence alors par l'appel d'outil, sans bloc de réflexion | `tool_choice` (`auto`/`required`/`none`/fonction) | vocabulaire |
| Sortie structurée | `output_config.format` = `json_schema` ; `client.messages.parse()` | `text.format` = `json_schema` (`strict: true`) ; `client.responses.parse()` | Pydantic/Zod des deux côtés |
| Streaming | événements `message_start` → `content_block_delta` (`text_delta`) → `message_stop` | événements `response.output_text.delta` → `response.completed` | noms d'événements |
| Cache de prompt | explicite : `cache_control` (jusqu'à 4 breakpoints) ou automatique à la racine ; min 512 tokens ; TTL 5 min / 1 h | automatique sur le préfixe identique ; `cached_tokens` dans `usage` ; rétention étendue 30 min / 12 h facturée | OpenAI : rien à écrire |
| Fichiers / PDF | Files API, bloc `document` | Files API, `input_file` ; `file_search` intégré | équivalent |
| Lot asynchrone −50 % | Message Batches API | Batch API (JSONL) | équivalent |
| Raisonnement | `thinking` adaptatif, `effort` | modèles raisonnants, items `reasoning`, paramètre `reasoning.effort` | paramètres différents |
| Outils hébergés | web search, web fetch, code execution, MCP connector | web search, file search, code interpreter, image generation, MCP distant | catalogues proches |

Deux remarques. D'abord, Anthropic publie une couche de **compatibilité avec le SDK OpenAI** ([OpenAI SDK compatibility](https://platform.claude.com/docs/en/cli-sdks-libraries/libraries/openai-sdk)) : pour un prototype en Chat Completions, changer l'URL de base et la clé peut suffire à tester Claude. C'est pratique pour un essai, **pas** pour une architecture : vous perdez les fonctionnalités propres à chaque plateforme. Ensuite, ce tableau est la raison d'être de l'exercice : les deux API se ressemblent *parce qu'elles résolvent le même problème* ; un code bien structuré doit pouvoir passer de l'une à l'autre en changeant **un seul fichier**.

```quiz
{
  "q": "Chez OpenAI, sous quelle forme renvoie-t-on le résultat d'un appel de fonction ?",
  "options": [
    "Un message de rôle `user` contenant un bloc `tool_result`",
    "Un item `function_call_output` avec le même `call_id`",
    "Un message de rôle `assistant` qui recopie le résultat",
    "Un paramètre `tool_result_id` ajouté dans `instructions`"
  ],
  "answer": 1,
  "explanation": "Le bloc `tool_result` dans un message `user`, c'est la forme Anthropic. Chez OpenAI, l'envelopper dans un rôle provoque une erreur 400 peu explicite."
}
```

## 3. Architecture du portage : l'adaptateur

```
                 ┌────────────────────────────────┐
  Interface ───► │  assistant_devis.py            │  logique métier : catalogue, TVA, devis
  (CLI / web)    │  - outils (fonctions Python)   │  tests (20 demandes) — INCHANGÉS
                 │  - schéma Devis (Pydantic)     │
                 │  - boucle agentique            │
                 └───────────────┬────────────────┘
                                 │  interface FournisseurLLM
                 ┌───────────────┴────────────────┐
                 │ fournisseur_anthropic.py (M17)  │ fournisseur_openai.py (cette leçon)
                 └────────────────────────────────┘
```

La boucle agentique, les outils et le schéma restent dans un module neutre. Chaque fournisseur ne fait que **traduire** : outils au format maison, items de réponse en événements neutres (`texte`, `appel_outil`, `fin`). Vous écrirez cette abstraction proprement en M19 ; ici, nous la gardons minimale pour rester lisibles.

## 4. Le portage en Python

### 4.1 Le cœur métier, inchangé

```python
# devis_core.py — logique métier partagée (identique à la version M17)
from pydantic import BaseModel

CATALOGUE = {
    "PORTE-CHENE-204x73": {"libelle": "Porte intérieure chêne 204x73", "prix_ht": 340.0, "delai_jours": 10},
    "PORTE-CHENE-204x83": {"libelle": "Porte intérieure chêne 204x83", "prix_ht": 365.0, "delai_jours": 10},
    "POIGNEE-INOX":       {"libelle": "Poignée inox", "prix_ht": 42.0, "delai_jours": 2},
}
TARIF_POSE_HT = {"porte": 180.0, "fenetre": 260.0, "placard": 320.0}

def chercher_article(mots_cles: str) -> list[dict]:
    """Recherche simple dans le catalogue (en production : base de données)."""
    m = mots_cles.lower()
    return [{"ref": r, **a} for r, a in CATALOGUE.items() if all(w in (r + a["libelle"]).lower() for w in m.split())]

def tarif_pose(type_ouvrage: str) -> dict:
    return {"type": type_ouvrage, "prix_ht": TARIF_POSE_HT.get(type_ouvrage, 200.0)}

class LigneDevis(BaseModel):
    designation: str
    quantite: int
    prix_unitaire_ht: float

class Devis(BaseModel):
    client: str
    lignes: list[LigneDevis]
    total_ht: float
    tva_pct: float
    total_ttc: float
    hypotheses: list[str]
    questions_en_suspens: list[str]

SYSTEM_PROMPT = """Vous êtes l'assistant devis de la Menuiserie Dupont (Nantes). Répondez en français.
Règles : utilisez TOUJOURS les outils pour les prix ; n'inventez aucun tarif. TVA : 10 % pour la rénovation
d'un logement de plus de 2 ans, 20 % sinon ; demandez l'âge du logement si inconnu.
Si une dimension manque, posez la question plutôt que de supposer.
Conditions générales : acompte 30 % à la commande, solde à la réception ; garantie décennale sur la pose.
[... en production, ce bloc fait 2 000 à 4 000 tokens : CGV, grille complète, exemples de devis ...]
"""

# Les outils décrits une fois, dans un format NEUTRE (JSON Schema pur)
OUTILS_NEUTRES = [
    {"name": "chercher_article", "description": "Cherche des articles du catalogue par mots-clés (ex. 'porte chêne 73').",
     "schema": {"type": "object", "properties": {"mots_cles": {"type": "string"}},
                "required": ["mots_cles"], "additionalProperties": False},
     "fn": lambda a: chercher_article(**a)},
    {"name": "tarif_pose", "description": "Tarif HT de la pose pour un type d'ouvrage : porte, fenetre, placard.",
     "schema": {"type": "object", "properties": {"type_ouvrage": {"type": "string"}},
                "required": ["type_ouvrage"], "additionalProperties": False},
     "fn": lambda a: tarif_pose(**a)},
]
```

### 4.2 L'adaptateur OpenAI

```python
# fournisseur_openai.py — traduction vers la Responses API (streaming + outils + sortie structurée)
import json, os
from openai import OpenAI
from devis_core import OUTILS_NEUTRES, SYSTEM_PROMPT, Devis

if not os.environ.get("OPENAI_API_KEY"):
    raise SystemExit("Définissez OPENAI_API_KEY.")
client = OpenAI()
MODELE = os.environ.get("OPENAI_MODEL", "gpt-6.1-sol")   # équivalent de Claude Sonnet 5.5 (2 $/10 $)

# Traduction du format neutre → format OpenAI (aplati, strict)
TOOLS_OPENAI = [{"type": "function", "name": o["name"], "description": o["description"],
                 "parameters": o["schema"], "strict": True} for o in OUTILS_NEUTRES]
FN = {o["name"]: o["fn"] for o in OUTILS_NEUTRES}

def tour_streaming(historique: list, max_iterations: int = 6) -> list:
    """Exécute un tour de conversation : streame le texte, exécute les outils, renvoie l'historique."""
    for _ in range(max_iterations):
        stream = client.responses.create(
            model=MODELE,
            instructions=SYSTEM_PROMPT,     # préfixe stable → mis en cache automatiquement par OpenAI
            input=historique,
            tools=TOOLS_OPENAI,
            max_output_tokens=1500,
            stream=True,
        )
        reponse_finale = None
        for ev in stream:
            if ev.type == "response.output_text.delta":
                print(ev.delta, end="", flush=True)
            elif ev.type == "response.completed":
                reponse_finale = ev.response
        print()
        historique += reponse_finale.output          # on conserve messages + function_call
        appels = [it for it in reponse_finale.output if it.type == "function_call"]
        if not appels:
            u = reponse_finale.usage
            caches = getattr(u.input_tokens_details, "cached_tokens", 0)
            print(f"[usage] {u.input_tokens} in (dont {caches} en cache) / {u.output_tokens} out")
            return historique
        for ap in appels:                              # appels parallèles : on les traite tous
            resultat = FN[ap.name](json.loads(ap.arguments))
            historique.append({"type": "function_call_output", "call_id": ap.call_id,
                               "output": json.dumps(resultat, ensure_ascii=False)})
    raise RuntimeError("Trop d'itérations d'outils")

def generer_devis(historique: list) -> Devis | None:
    """Clôture : demande le devis structuré à partir de la conversation."""
    r = client.responses.parse(
        model=MODELE, instructions=SYSTEM_PROMPT,
        input=historique + [{"role": "user", "content": "Produis maintenant le devis au format demandé."}],
        tools=TOOLS_OPENAI, tool_choice="none",        # plus d'appel d'outil : on veut le JSON
        text_format=Devis,
    )
    return r.output_parsed

if __name__ == "__main__":
    historique = [{"role": "user", "content":
                   "Bonjour, je voudrais une porte intérieure en chêne 204x73 avec poignée inox et la pose. "
                   "La maison a 15 ans. Client : Mme Leroy."}]
    historique = tour_streaming(historique)
    devis = generer_devis(historique)
    if devis:
        print(devis.model_dump_json(indent=2, ensure_ascii=False))
        # Contrôle métier, comme en M17 : la forme est garantie, pas l'arithmétique
        ht = sum(l.quantite * l.prix_unitaire_ht for l in devis.lignes)
        assert abs(ht - devis.total_ht) < 0.01, "total_ht incohérent → revue humaine"
```

### 4.3 Ce qui a changé par rapport à la version Claude

Comparez avec votre `fournisseur_anthropic.py` de M17 : la boucle est la même, seules cinq lignes diffèrent.

| Dans la version Claude (M17) | Dans la version OpenAI |
|---|---|
| `system=[{"type":"text","text":SYSTEM_PROMPT,"cache_control":{"type":"ephemeral"}}]` | `instructions=SYSTEM_PROMPT` (cache automatique) |
| `tools=[{"name", "description", "input_schema"}]` | `tools=[{"type":"function", "name", "description", "parameters", "strict"}]` |
| `if bloc.type == "tool_use": args = bloc.input` (déjà un objet) | `if it.type == "function_call": args = json.loads(it.arguments)` |
| `{"role":"user","content":[{"type":"tool_result","tool_use_id":bloc.id,"content":...}]}` | `{"type":"function_call_output","call_id":it.call_id,"output":...}` |
| `stop_reason == "tool_use"` pour continuer | présence d'items `function_call` pour continuer |
| `client.messages.parse(..., output_format=Devis)` via `output_config` | `client.responses.parse(..., text_format=Devis)` |
| `max_tokens=1500` (obligatoire) | `max_output_tokens=1500` (optionnel, mais mettez-le) |

> ⚠️ **Piège fréquent** — Chez Anthropic, le résultat d'outil est un message de rôle `user` ; chez OpenAI, c'est un item de premier niveau **sans rôle**. Si vous enveloppez le `function_call_output` dans `{"role": "user", ...}`, vous obtenez une erreur 400 peu explicite. Deuxième piège : chez OpenAI, si vous utilisez `previous_response_id`, ne renvoyez **pas** les items déjà stockés, seulement les nouveaux `function_call_output`.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : sur Claude Haiku 5.5, un `tool_choice` forcé (`any` ou `tool`) renvoie une erreur 400, comme sur Opus 5.5 et Sonnet 5.5.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. Opus 5.5 et Sonnet 5.5 refusent le forçage (400), mais Haiku 5.5 l'accepte : la réponse commence alors directement par l'appel d'outil, sans bloc de réflexion (guides de migration Anthropic, vérifiés le 5/11/2026)."
}
```

## 5. Le portage en TypeScript

```typescript
// fournisseur_openai.ts — même assistant, version Node (npm install openai zod ; npx tsx fournisseur_openai.ts)
import OpenAI from "openai";
import { zodTextFormat } from "openai/helpers/zod";
import { z } from "zod";

if (!process.env.OPENAI_API_KEY) throw new Error("Définissez OPENAI_API_KEY.");
const client = new OpenAI();
const MODELE = process.env.OPENAI_MODEL ?? "gpt-6.1-sol";

const SYSTEM_PROMPT = `Vous êtes l'assistant devis de la Menuiserie Dupont (Nantes). Répondez en français.
Utilisez TOUJOURS les outils pour les prix. TVA 10 % rénovation (> 2 ans), 20 % sinon. Posez une question si une dimension manque.`;

const catalogue: Record<string, { libelle: string; prix_ht: number }> = {
  "PORTE-CHENE-204x73": { libelle: "Porte intérieure chêne 204x73", prix_ht: 340 },
  "POIGNEE-INOX": { libelle: "Poignée inox", prix_ht: 42 },
};
const fonctions: Record<string, (a: any) => unknown> = {
  chercher_article: ({ mots_cles }: { mots_cles: string }) =>
    Object.entries(catalogue)
      .filter(([ref, a]) => mots_cles.toLowerCase().split(" ").every((w) => (ref + a.libelle).toLowerCase().includes(w)))
      .map(([ref, a]) => ({ ref, ...a })),
  tarif_pose: ({ type_ouvrage }: { type_ouvrage: string }) =>
    ({ type: type_ouvrage, prix_ht: { porte: 180, fenetre: 260, placard: 320 }[type_ouvrage] ?? 200 }),
};

const tools: OpenAI.Responses.Tool[] = [
  { type: "function", name: "chercher_article", description: "Cherche des articles du catalogue par mots-clés.",
    parameters: { type: "object", properties: { mots_cles: { type: "string" } }, required: ["mots_cles"], additionalProperties: false }, strict: true },
  { type: "function", name: "tarif_pose", description: "Tarif HT de la pose : porte, fenetre, placard.",
    parameters: { type: "object", properties: { type_ouvrage: { type: "string" } }, required: ["type_ouvrage"], additionalProperties: false }, strict: true },
];

const Devis = z.object({
  client: z.string(),
  lignes: z.array(z.object({ designation: z.string(), quantite: z.number().int(), prix_unitaire_ht: z.number() })),
  total_ht: z.number(), tva_pct: z.number(), total_ttc: z.number(),
  hypotheses: z.array(z.string()), questions_en_suspens: z.array(z.string()),
});

async function tourStreaming(historique: OpenAI.Responses.ResponseInputItem[]) {
  for (let i = 0; i < 6; i++) {
    const stream = await client.responses.create({ model: MODELE, instructions: SYSTEM_PROMPT, input: historique, tools, max_output_tokens: 1500, stream: true });
    let finale: OpenAI.Responses.Response | undefined;
    for await (const ev of stream) {
      if (ev.type === "response.output_text.delta") process.stdout.write(ev.delta);
      else if (ev.type === "response.completed") finale = ev.response;
    }
    console.log();
    if (!finale) throw new Error("Flux interrompu");
    historique.push(...(finale.output as OpenAI.Responses.ResponseInputItem[]));
    const appels = finale.output.filter((it) => it.type === "function_call");
    if (appels.length === 0) {
      console.log(`[usage] ${finale.usage?.input_tokens} in (dont ${finale.usage?.input_tokens_details?.cached_tokens ?? 0} en cache) / ${finale.usage?.output_tokens} out`);
      return historique;
    }
    for (const ap of appels) {
      if (ap.type !== "function_call") continue;
      const resultat = fonctions[ap.name](JSON.parse(ap.arguments));
      historique.push({ type: "function_call_output", call_id: ap.call_id, output: JSON.stringify(resultat) });
    }
  }
  throw new Error("Trop d'itérations d'outils");
}

async function main() {
  let historique: OpenAI.Responses.ResponseInputItem[] = [
    { role: "user", content: "Une porte chêne 204x73 avec poignée inox et la pose, maison de 15 ans. Client : Mme Leroy." },
  ];
  historique = await tourStreaming(historique);
  const r = await client.responses.parse({
    model: MODELE, instructions: SYSTEM_PROMPT, tools, tool_choice: "none",
    input: [...historique, { role: "user", content: "Produis maintenant le devis au format demandé." }],
    text: { format: zodTextFormat(Devis, "devis") },
  });
  console.log(JSON.stringify(r.output_parsed, null, 2));
}
main();
```

## 6. Choix de modèle et coûts comparés

### 6.1 Quel modèle pour quel modèle ?

Les deux catalogues (nov. 2026) se répondent presque prix pour prix :

| Rôle dans le projet | Claude (M17) | Prix in / out | OpenAI (M18) | Prix in / out |
|---|---|---|---|---|
| Tri, classification, petites extractions | Haiku 5.5 (`claude-haiku-5-5`) | 0,10 / 0,50 | GPT-6 Luna (`gpt-6-luna`) | 0,10 / 0,50 |
| Assistant par défaut, bon rapport qualité/prix | — | — | GPT-6.1 Terra (`gpt-6.1-terra`) | 1,00 / 5,00 |
| Rédaction soignée, devis complexes | Sonnet 5.5 (`claude-sonnet-5-5`) | 2 / 10 | GPT-6.1 Sol (`gpt-6.1-sol`) | 2,00 / 10,00 |
| Raisonnement difficile, agents longs | Opus 5.5 (`claude-opus-5-5`) | 4 / 20 | — | — |
| Haut de gamme | Fable 5.1 (`claude-fable-5-1`) | 10 / 50 | GPT-6 Astra (`gpt-6-astra`) | 10 / 50 |

Prix en $ par million de tokens, tarif Standard, pages Pricing des deux fournisseurs (nov. 2026). Les cases vides montrent que les gammes **ne se superposent pas exactement** : OpenAI a un palier à 1 $/5 $ sans équivalent direct chez Anthropic, Anthropic un palier à 4 $/20 $ sans équivalent direct chez OpenAI. Le bon réflexe n'est pas de choisir « l'équivalent », mais de **faire tourner vos 20 tests** sur deux ou trois candidats et de retenir le moins cher qui passe.

### 6.2 Le cache change le classement

Notre system prompt fait, disons, **3 000 tokens** ; chaque demande ajoute 300 tokens d'entrée et produit 600 tokens de sortie, avec en moyenne deux allers-retours d'outils (donc 3 appels par devis). Hypothèse : 150 devis par jour, 22 jours par mois, soit 3 300 devis et 9 900 appels.

| Configuration | Entrée pleine | Entrée cache | Sortie | Coût mensuel estimé |
|---|---|---|---|---|
| Sonnet 5.5, **sans** cache | 9 900 × 3 300 tok × 2 $ | — | 3 300 × 600 × 10 $ | ≈ 65 $ + 20 $ = **85 $** |
| Sonnet 5.5, cache (lecture 0,10 $, écriture 2,50 $ 5 min) | 9 900 × 300 × 2 $ | 9 900 × 3 000 × 0,10 $ | idem | ≈ 6 $ + 3 $ + 20 $ ≈ **29 $** (+ écritures marginales) |
| GPT-6.1 Sol, **sans** cache | 9 900 × 3 300 × 2 $ | — | 3 300 × 600 × 10 $ | ≈ **85 $** |
| GPT-6.1 Sol, cache automatique (0,10 $) | 9 900 × 300 × 2 $ | 9 900 × 3 000 × 0,10 $ | idem | ≈ **29 $** |
| GPT-6.1 Terra, cache (0,05 $) | 9 900 × 300 × 1 $ | 9 900 × 3 000 × 0,05 $ | 3 300 × 600 × 5 $ | ≈ 3 $ + 1,5 $ + 10 $ ≈ **14,5 $** |
| Haiku 5.5 / Luna, cache | 9 900 × 300 × 0,10 $ | 9 900 × 3 000 × 0,01 $ | 3 300 × 600 × 0,50 $ | ≈ 0,3 $ + 0,3 $ + 1 $ ≈ **1,6 $** |

Calculs arrondis, tarifs nov. 2026. Trois enseignements : (1) à prix catalogue identique, Sonnet 5.5 et GPT-6.1 Sol coûtent la même chose ; (2) le **cache divise la facture par trois** dans un assistant à long system prompt, et il est **automatique** chez OpenAI tandis qu'Anthropic demande un `cache_control` (ou le cache automatique à la racine) et facture l'écriture 1,25× ; (3) la vraie question économique n'est pas Anthropic *contre* OpenAI, mais **« le modèle à 1 $ ou à 0,10 $ passe-t-il mes tests ? »**. Pour une menuiserie, 85 $ ou 14 $ par mois sont tous deux dérisoires face à deux heures de travail quotidien de la gérante ; le critère décisif sera la **qualité mesurée**, puis la politique de données (stockage `store`, résidence, sous-traitant RGPD, module M15).

> 💡 **Autrement dit** — Le long règlement (le system prompt) est relu à chaque appel. Sans cache, vous le payez plein tarif à chaque fois ; avec le cache, vous payez une « photocopie » dix à vingt fois moins chère. Sur cet assistant, c'est ce détail qui divise la facture par trois, bien plus que le choix entre Anthropic et OpenAI.

```quiz
{
  "q": "D'après le tableau de la section 6.2, quelle configuration revient le moins cher pour 3 300 devis par mois, à condition de passer les tests ?",
  "options": [
    "Sonnet 5.5 avec cache",
    "GPT-6.1 Sol, sans aucun cache",
    "GPT-6.1 Terra avec cache activé",
    "Haiku 5.5 ou Luna avec cache"
  ],
  "answer": 3,
  "explanation": "Environ 1,6 $ par mois contre 14,5 $ (Terra) et 29 $ (Sonnet ou Sol avec cache). Mais seul le jeu de 20 tests dit si un modèle à 0,10 $ fait le travail."
}
```

🎮 **Défi** — Refaites le tableau avec un system prompt de 10 000 tokens (CGV complètes + 15 exemples de devis). À partir de quelle taille le cache devient-il indispensable ? Et que se passe-t-il si vos demandes arrivent espacées de plus de 5 minutes (TTL Anthropic) ?

## 7. Rendre l'application réversible

Trois règles tirées de ce portage, que vous généraliserez en M19 :
1. **Le format neutre d'abord.** Outils en JSON Schema pur, schémas de sortie en Pydantic/Zod, prompts dans des fichiers : les adaptateurs ne font que traduire.
2. **Des tests indépendants du fournisseur.** Vos 20 demandes et devis attendus sont la définition du « ça marche ». Ils tournent sur Claude, sur GPT-6, demain sur Mistral.
3. **Les différences sémantiques se documentent.** Stockage des conversations, cache, comportement face aux refus, limites de débit : notez-les dans un `FOURNISSEURS.md` du projet. Une migration réussie est une migration dont on peut revenir.

```mission
{
  "title": "Jusqu'à quand la série GPT-4 reste-t-elle disponible ?",
  "url": "https://developers.openai.com/api/docs/deprecations",
  "steps": [
    "Ouvrez la page Deprecations de la documentation OpenAI",
    "Cherchez les modèles GPT-4o, GPT-4o mini, GPT-4.1 et GPT-4.1 mini",
    "Relevez la date d'arrêt"
  ],
  "question": "À quelle date la série GPT-4 (4o, 4o mini, 4.1, 4.1 mini) s'arrête-t-elle ?",
  "hint": "Une seule date couvre les quatre modèles.",
  "answer": "Le 14 janvier 2027 (page Deprecations, nov. 2026) : un code porté aujourd'hui doit viser la famille GPT-6 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Le cache de prompts OpenAI dans le changelog",
  "url": "https://developers.openai.com/api/docs/changelog",
  "steps": [
    "Ouvrez le changelog de l'API OpenAI",
    "Remontez jusqu'aux entrées d'octobre 2026",
    "Repérez l'annonce concernant le cache de prompts"
  ],
  "question": "Quelle durée de rétention du cache de prompts OpenAI a été annoncée le 20 octobre 2026 ?",
  "hint": "Le tableau de la section 2 parle de rétention étendue « 30 min / 12 h ».",
  "answer": "12 heures (entrée du 20/10/2026) ; la page Pricing facture l'écriture en cache selon la durée, 30 min ou 12 h (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne (projet évalué).** Livrez le portage complet de l'assistant devis sur OpenAI, en Python **ou** TypeScript :
1. `devis_core` inchangé (ou construit si vous n'avez pas fait M17) ; `fournisseur_openai` avec streaming, outils, appels parallèles, sortie structurée `Devis` ;
2. le jeu de 20 tests passe sur `gpt-6.1-sol` ; relancez-le sur `gpt-6.1-terra` et `gpt-6-luna` et consignez les scores ;
3. un script `couts.py` qui lit les `usage` de chaque run et calcule le coût réel par devis, cache inclus ;
4. une note d'une page pour la gérante : modèle recommandé, coût mensuel, point RGPD (`store`), plan de retour vers Claude en cas de besoin ;
5. bonus : la même application pilotée par l'Agents SDK (L081) avec un guardrail « pas de données bancaires ».

**Critères de réussite.** Aucune clé en code ; les tests passent à ≥ 18/20 sur au moins une configuration ; la boucle gère les appels parallèles et borne les itérations ; le JSON du devis est validé et contrôlé arithmétiquement ; le coût calculé à partir de `usage` est cohérent avec le tableau de la section 6 ; la note est compréhensible par une non-développeuse.

**Pistes de corrigé.** La section 4 est un corrigé presque complet ; il manque le harnais de tests (une boucle sur un JSONL de 20 cas comparant les champs `lignes` et `total_ttc` avec tolérance) et le script de coûts (reprenez `cout_usd` de la L078 en ajoutant `cached_tokens`). Si le modèle oublie de poser la question de l'âge du logement, renforcez les `instructions` plutôt que le code.

## ✅ Auto-évaluation express

1. Chez OpenAI, où va le résultat d'un appel de fonction, et sous quelle forme ?
2. Pourquoi le cache de prompt pèse-t-il plus que le choix du fournisseur dans le coût de cet assistant ?
3. Quelle est la condition pour qu'un portage soit considéré comme réussi ?

*Réponses : 1) Un item de premier niveau `{"type":"function_call_output","call_id":…,"output":"<chaîne>"}` dans `input`, sans rôle. 2) Parce que le system prompt (3 000 tokens) représente 90 % de l'entrée de chaque appel et que l'entrée en cache coûte 10 à 20 fois moins ; à prix catalogue égal, le cache divise la facture par trois. 3) Que le jeu de tests du projet d'origine passe, avec un comportement et un coût documentés.*

## 📚 Pour aller plus loin
- [Migrate to the Responses API](https://developers.openai.com/api/docs/guides/migrate-to-responses) 🇬🇧 — utile aussi pour passer de Chat Completions aux Responses.
- [Claude Platform — OpenAI SDK compatibility](https://platform.claude.com/docs/en/cli-sdks-libraries/libraries/openai-sdk) 🇬🇧 — la passerelle pour tester Claude depuis un code OpenAI.
- [Claude Platform — Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 et [OpenAI Pricing](https://developers.openai.com/api/docs/pricing) 🇬🇧 — les deux sources des calculs de coût de la section 6.
- [OpenAI Academy — Build with AI](https://academy.openai.com/pages/courses) 🇬🇧 — parcours développeurs gratuit ; les badges « AI Foundations », « Applied AI Foundations » et « Agents and Workflows » sont un bon complément à ce module (ce ne sont pas des certifications OpenAI, mais ils valorisent votre profil).

> 🗺️ **Et maintenant ?** — Vous savez passer de Claude à OpenAI ; le module M19 (L084) ajoute Grok, Perplexity, Mistral et Gemini, puis généralise l'adaptateur en véritable architecture multi-fournisseur.
