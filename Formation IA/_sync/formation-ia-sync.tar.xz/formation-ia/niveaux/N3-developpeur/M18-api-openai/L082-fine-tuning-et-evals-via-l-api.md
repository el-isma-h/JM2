---
id: L082
module: M18
level: N3
title: "Fine-tuning et Evals via l'API"
minutes: 55
objectives:
  - "Construire une suite d'évaluation (jeu de test, critères, run) avec l'API Evals et interpréter ses résultats pour choisir un modèle ou valider un prompt"
  - "Diviser par deux le coût d'un traitement en lot avec la Batch API (fichier JSONL, suivi du job, récupération des résultats)"
  - "Expliquer les trois méthodes de fine-tuning (SFT, DPO, RFT), le format des données, et l'état de la plateforme OpenAI (arrêt progressif, nov. 2026)"
  - "Appliquer les Safety best practices d'OpenAI (Moderation API, safety identifiers, limitation de sortie) dans un pipeline"
skills: ["C3.1", "C3.2"]
sources:
  - { title: "OpenAI Developers — Evals getting started", url: "https://developers.openai.com/api/docs/guides/evaluation-getting-started", lang: "en" }
  - { title: "OpenAI Developers — Evals", url: "https://developers.openai.com/api/docs/guides/evals", lang: "en" }
  - { title: "OpenAI Developers — Batch", url: "https://developers.openai.com/api/docs/guides/batch", lang: "en" }
  - { title: "OpenAI Developers — Model optimization", url: "https://developers.openai.com/api/docs/guides/model-optimization", lang: "en" }
  - { title: "OpenAI Developers — Supervised fine-tuning", url: "https://developers.openai.com/api/docs/guides/supervised-fine-tuning", lang: "en" }
  - { title: "OpenAI Developers — Direct preference optimization", url: "https://developers.openai.com/api/docs/guides/direct-preference-optimization", lang: "en" }
  - { title: "OpenAI Developers — Reinforcement fine-tuning", url: "https://developers.openai.com/api/docs/guides/reinforcement-fine-tuning", lang: "en" }
  - { title: "OpenAI Developers — Pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "OpenAI Developers — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "OpenAI Developers — Background mode", url: "https://developers.openai.com/api/docs/guides/background", lang: "en" }
---

# Fine-tuning et Evals via l'API

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 18

## 🎯 Ce que vous saurez faire
- Répondre avec des chiffres, et non au doigt mouillé, à la question « Luna suffit-il, ou faut-il Terra ? » grâce à une **évaluation** reproductible.
- Traiter 10 000 documents pour moitié prix avec la **Batch API**, sans surveiller un terminal pendant six heures.
- Expliquer à un client ce qu'est le fine-tuning, quand il vaut (rarement) le coup, et pourquoi, chez OpenAI, la porte est en train de se fermer pour les nouveaux comptes (nov. 2026).
- Intégrer les réflexes de sécurité recommandés par OpenAI dans un pipeline de production.

> 🧭 **En clair** — Avant de changer de modèle ou de « personnaliser » une IA, il faut pouvoir mesurer si elle fait bien son travail : c'est l'évaluation, un examen blanc avec corrigé que l'on fait passer à chaque modèle candidat. La Batch API, c'est la lettre verte : vous déposez un gros paquet de demandes, il est traité dans les 24 heures, et vous payez moitié prix. Le fine-tuning consiste à ré-entraîner un modèle sur vos exemples pour lui apprendre un style ou un format ; chez OpenAI, cette porte se referme et sera fermée à tous le 6 janvier 2027. La règle d'or : évaluer d'abord, améliorer le prompt ensuite, ré-entraîner en tout dernier recours.

## 1. L'ordre des leviers : d'abord évaluer, ensuite optimiser

La page [Model optimization](https://developers.openai.com/api/docs/guides/model-optimization) décrit une boucle en trois temps : **écrire des évals** → **optimiser le prompt** (instructions, exemples, outils, RAG) → **seulement ensuite**, fine-tuner. Beaucoup d'équipes font l'inverse : elles fine-tunent parce que « ça fait sérieux », sans jeu de test, et ne peuvent jamais prouver le gain. Dans cette leçon, nous respectons l'ordre.

```
   ┌──────────────┐    ┌────────────────────┐    ┌───────────────┐
   │ 1. Évaluer   │───►│ 2. Prompt / RAG /  │───►│ 3. Fine-tuner │
   │  (jeu de test│    │  outils / modèle   │    │  (si 1 et 2   │
   │  + critères) │◄───│  moins cher ?      │◄───│  ne suffisent │
   └──────────────┘    └────────────────────┘    │  pas)         │
          ▲                                      └───────────────┘
          └──────────── on ré-évalue à chaque changement ─────────┘
```

Vous avez déjà rencontré l'évaluation côté Anthropic (M17 L076 : critères SMART, LLM-as-judge). Les concepts sont identiques ; l'outillage change.

```quiz
{
  "q": "Dans quel ordre la page Model optimization recommande-t-elle d'agir ?",
  "options": [
    "Fine-tuner, puis évaluer, puis optimiser le prompt",
    "Optimiser le prompt, puis fine-tuner, puis évaluer",
    "Évaluer, optimiser le prompt, puis seulement fine-tuner",
    "Évaluer uniquement une fois l'application en production"
  ],
  "answer": 2,
  "explanation": "Sans évaluation préalable, impossible de prouver qu'un changement améliore quoi que ce soit. Le fine-tuning arrive en dernier, si le prompt et le choix du modèle ne suffisent pas."
}
```

## 2. Evals : mesurer avant de croire

### 2.1 Les trois ingrédients

1. **Un jeu de données** : des entrées réelles (anonymisées !) avec, si possible, la réponse attendue. 30 à 50 exemples suffisent pour commencer ; 200 pour décider.
2. **Des critères de notation** (*testing criteria*) : correspondance exacte, inclusion de chaîne, **validation JSON**, ou **juge LLM** avec une grille (*label model* / *score model*).
3. **Un run** : on exécute un modèle + un prompt sur le jeu, on obtient un score, et on recommence avec une autre configuration.

> 💡 **Autrement dit** — Une éval, c'est un examen : des copies (le jeu de données), un barème (les critères) et une session d'examen (le run). On fait passer le même examen à Luna et à Terra, puis on compare les notes… et le coût de la session.

### 2.2 Créer une éval et lancer deux runs (Python)

Cas : la classification de mails du cabinet comptable (L079). On veut comparer `gpt-6-luna` et `gpt-6.1-terra`.

```python
# evals_classification.py — comparer deux modèles sur un jeu de test avec l'API Evals
import json, os, time
from openai import OpenAI

client = OpenAI()

# 1) Jeu de test : entrée + étiquette attendue (en production : 50 à 200 lignes anonymisées)
JEU = [
    {"item": {"mail": "Bonjour, pouvez-vous m'envoyer la facture d'octobre ?", "attendu": "facture"}},
    {"item": {"mail": "Il me faut une attestation de régularité pour un appel d'offres.", "attendu": "attestation"}},
    {"item": {"mail": "Peut-on se voir mardi pour le bilan ?", "attendu": "rdv"}},
    {"item": {"mail": "Quel est le taux de TVA sur les travaux ?", "attendu": "autre"}},
]

# 2) Définition de l'éval : schéma des items + critère (le modèle doit sortir exactement l'étiquette)
ev = client.evals.create(
    name="Classification mails cabinet",
    data_source_config={
        "type": "custom",
        "item_schema": {
            "type": "object",
            "properties": {"mail": {"type": "string"}, "attendu": {"type": "string"}},
            "required": ["mail", "attendu"],
        },
        "include_sample_schema": True,          # permet de comparer la sortie du modèle à l'item
    },
    testing_criteria=[{
        "type": "string_check",
        "name": "étiquette exacte",
        "input": "{{ sample.output_text }}",
        "operation": "eq",
        "reference": "{{ item.attendu }}",
    }],
)

PROMPT = ("Classe ce mail dans UNE catégorie parmi : facture, attestation, rdv, autre. "
          "Réponds uniquement par la catégorie, en minuscules.\n\nMail : {{ item.mail }}")

# 3) Un run par modèle à comparer
runs = {}
for modele in ["gpt-6-luna", "gpt-6.1-terra"]:
    run = client.evals.runs.create(
        eval_id=ev.id,
        name=f"run-{modele}",
        data_source={
            "type": "responses",
            "model": modele,
            "source": {"type": "file_content", "content": JEU},
            "input_messages": {"type": "template",
                               "template": [{"role": "user", "content": PROMPT}]},
        },
    )
    runs[modele] = run.id

# 4) Attendre et lire les résultats
for modele, run_id in runs.items():
    while True:
        r = client.evals.runs.retrieve(eval_id=ev.id, run_id=run_id)
        if r.status in ("completed", "failed", "canceled"):
            break
        time.sleep(5)
    print(modele, "→", r.status, "|", r.result_counts)   # passed / failed / errored
```

Les résultats (`result_counts`) donnent le nombre de cas réussis par modèle ; le dashboard OpenAI affiche le détail ligne à ligne. Si Luna fait 48/50 et Terra 49/50, vous venez de gagner un **facteur 10 sur la facture** pour un point de précision. Si Luna fait 38/50, la question est tranchée aussi.

### 2.3 TypeScript : un juge LLM pour une tâche ouverte

Quand la bonne réponse n'est pas une étiquette (un mail de relance, un résumé), on fait noter par un modèle selon une grille :

```typescript
// evals_juge.ts — critère "score_model" : un modèle note les réponses (npx tsx evals_juge.ts)
import OpenAI from "openai";
const client = new OpenAI();

async function main() {
  const ev = await client.evals.create({
    name: "Qualité des mails de relance",
    data_source_config: {
      type: "custom",
      item_schema: {
        type: "object",
        properties: { contexte: { type: "string" } },
        required: ["contexte"],
      },
      include_sample_schema: true,
    },
    testing_criteria: [{
      type: "score_model",
      name: "grille relance",
      model: "gpt-6.1-sol",                       // le juge : plus fort que le candidat
      input: [
        { role: "developer", content:
          "Notez de 0 à 1 le mail de relance proposé : courtoisie, mention du montant et de l'échéance, " +
          "absence de menace juridique inappropriée, longueur < 120 mots. 1 = parfait. Répondez par un nombre." },
        { role: "user", content: "Contexte : {{ item.contexte }}\n\nMail proposé :\n{{ sample.output_text }}" },
      ],
      range: [0, 1],
      pass_threshold: 0.8,
    }],
  });
  console.log("Éval créée :", ev.id);
  // Ensuite : client.evals.runs.create({...}) comme en Python, avec un run par prompt ou par modèle.
}
main();
```

> 💡 **À retenir** — Le juge doit être **au moins aussi fort** que le candidat, et sa grille doit être **binaire ou ordinale** plutôt que « note sur 10 » vague. Gardez un échantillon noté **par un humain** pour vérifier que le juge est d'accord avec vous (M17 L076 appelle cela calibrer le juge).

Côté outillage ouvert, le dossier de recherche de la formation recense **promptfoo** (tests de régression de prompts en YAML, rachat annoncé par OpenAI le 9 mars 2026), **DeepEval** et **Ragas** : vous les utiliserez en M20 et M22 pour des évaluations indépendantes du fournisseur.

## 3. Batch API : moitié prix pour les traitements asynchrones

### 3.1 Quand l'utiliser

Tout ce qui **n'attend pas une réponse immédiate** : classer les 20 000 avis clients de l'année, extraire 5 000 factures, générer les descriptions d'un catalogue, calculer des embeddings de masse. Le tarif est **0,5×** le tarif Standard (nov. 2026), avec une fenêtre d'exécution de 24 h. L'analogie : l'affranchissement « lettre verte » plutôt que le coursier.

### 3.2 Le pipeline en Python

```python
# batch_factures.py — extraire 5 000 factures à moitié prix
import json, time
from openai import OpenAI

client = OpenAI()

# 1) Construire le fichier JSONL : une ligne = une requête Responses complète
factures = [{"id": f"F-{i:05d}", "texte": f"FACTURE n° {i} … Total TTC : {100 + i} €"} for i in range(1, 6)]
with open("requetes.jsonl", "w", encoding="utf-8") as f:
    for fac in factures:
        ligne = {
            "custom_id": fac["id"],                 # votre identifiant, pour recoller les résultats
            "method": "POST",
            "url": "/v1/responses",
            "body": {
                "model": "gpt-6-luna",
                "instructions": "Extrayez fournisseur, numero, total_ttc. JSON strict.",
                "input": fac["texte"],
                "text": {"format": {"type": "json_schema", "name": "facture", "strict": True,
                         "schema": {"type": "object",
                                    "properties": {"fournisseur": {"type": "string"},
                                                   "numero": {"type": "string"},
                                                   "total_ttc": {"type": "number"}},
                                    "required": ["fournisseur", "numero", "total_ttc"],
                                    "additionalProperties": False}}},
            },
        }
        f.write(json.dumps(ligne, ensure_ascii=False) + "\n")

# 2) Téléverser le fichier puis créer le batch
fichier = client.files.create(file=open("requetes.jsonl", "rb"), purpose="batch")
batch = client.batches.create(input_file_id=fichier.id, endpoint="/v1/responses",
                              completion_window="24h")
print("Batch créé :", batch.id, batch.status)

# 3) Attendre (en production : un cron ou un webhook, pas une boucle bloquante)
while batch.status not in ("completed", "failed", "expired", "cancelled"):
    time.sleep(30)
    batch = client.batches.retrieve(batch.id)
    print("…", batch.status, batch.request_counts)

# 4) Lire les résultats, recoller par custom_id
if batch.output_file_id:
    contenu = client.files.content(batch.output_file_id).text
    for ligne in contenu.splitlines():
        res = json.loads(ligne)
        corps = res["response"]["body"]
        texte = next(c["text"] for item in corps["output"] if item["type"] == "message"
                     for c in item["content"] if c["type"] == "output_text")
        print(res["custom_id"], "→", texte)
if batch.error_file_id:
    print("Erreurs :", client.files.content(batch.error_file_id).text[:500])
```

Notez la lecture « à la main » de `output[]` : dans un résultat de batch, pas de raccourci `output_text` (piège de la L078). Entre le Batch (asynchrone, −50 %) et le temps réel, il existe aussi le mode **Background** ([guide](https://developers.openai.com/api/docs/guides/background)) : une requête Responses unique mais longue, que vous interrogez plus tard, et le niveau de service **Flex** (0,5× lui aussi, avec une latence variable), utile pour des traitements unitaires non urgents.

```quiz
{
  "q": "Une agence doit générer les descriptions de 8 000 produits pour un site qui ouvre dans dix jours. Quel mode d'appel choisir ?",
  "options": [
    "Le niveau Fast (×2), pour aller plus vite",
    "La Batch API, asynchrone et à moitié prix",
    "Des appels temps réel en boucle, un par produit",
    "Le fine-tuning d'un modèle GPT-6"
  ],
  "answer": 1,
  "explanation": "Rien n'est urgent à la minute : le lot asynchrone divise la facture par deux. Le fine-tuning, lui, n'est pas proposé sur GPT-6."
}
```

🎮 **Défi** — Reprenez le script de notes de frais de la L080 et convertissez les appels de vision en lignes JSONL (`input_image` en base64 dans le `body`). Estimez l'économie sur 2 000 justificatifs par mois.

## 4. Fine-tuning : ce que c'est, et pourquoi la porte se ferme

### 4.1 Trois méthodes

| Méthode | Données | Ce qu'on apprend au modèle | Guide |
|---|---|---|---|
| **SFT** (supervised fine-tuning) | paires entrée → sortie idéale (JSONL de conversations) | un style, un format, un jargon, des réponses courtes sans long prompt | [Supervised fine-tuning](https://developers.openai.com/api/docs/guides/supervised-fine-tuning) |
| **DPO** (direct preference optimization) | pour une entrée, une réponse **préférée** et une **rejetée** | des préférences fines (ton, prudence) difficiles à décrire | [DPO](https://developers.openai.com/api/docs/guides/direct-preference-optimization) |
| **RFT** (reinforcement fine-tuning) | des entrées + un **grader** (fonction ou modèle de notation) | à raisonner vers un objectif vérifiable (règles métier, code) | [Reinforcement fine-tuning](https://developers.openai.com/api/docs/guides/reinforcement-fine-tuning) |

Format SFT (une ligne par exemple) :

```json
{"messages": [{"role": "system", "content": "Vous rédigez des objets de mails pour un cabinet comptable."},
              {"role": "user", "content": "Relance facture F-2026-0912, 30 jours de retard, client fidèle."},
              {"role": "assistant", "content": "Petit rappel : facture F-2026-0912 en attente"}]}
```

### 4.2 L'état de la plateforme (nov. 2026) : à signaler à vos clients

La page [Pricing](https://developers.openai.com/api/docs/pricing) indique, au 1er novembre 2026, qu'**OpenAI arrête progressivement sa plateforme de fine-tuning et que les nouveaux utilisateurs n'y ont plus accès**. Calendrier (page Deprecations, annonce du 7 mai 2026) : depuis le 7/05/2026, plus de nouveaux clients ; depuis le 2/07/2026, organisations sans inférence sur un modèle fine-tuné depuis 60 jours exclues ; **le 6/01/2027, plus aucun nouveau job** ; l'inférence sur les modèles déjà fine-tunés continue jusqu'à la dépréciation du modèle de base. Deux modèles restent tarifés, au million de tokens (vérifié le 5 nov. 2026) : `gpt-4.1-2025-04-14` (entraînement 25 $ ; 3 $ / 0,75 $ / 12 $ en inférence) et `gpt-4.1-mini-2025-04-14` (5 $ ; 0,80 $ / 0,20 $ / 3,20 $). Aucun modèle GPT-6 n'est proposé au fine-tuning. Conséquences pratiques :

- **Ne promettez pas** de fine-tuning OpenAI à un nouveau client ; vérifiez d'abord dans son dashboard si la fonctionnalité est accessible.
- Pour les comptes qui y ont encore accès, le code reste celui de `client.fine_tuning.jobs.create(training_file=..., model=...)`, avec un fichier téléversé en `purpose="fine-tune"` ; les guides SFT/DPO/RFT restent en ligne.
- Le besoin, lui, n'a pas disparu : il se traite par **prompt + exemples + sorties structurées** (souvent suffisant), par **RAG** (M20), ou par le fine-tuning de **modèles à poids ouverts** (LoRA/QLoRA, M28) que vous hébergez ou faites héberger, ce qui règle au passage la question de la souveraineté des données.

> 📅 **Calendrier précis (page [Deprecations](https://developers.openai.com/api/docs/deprecations), nov. 2026)** — Depuis le **7 mai 2026**, les organisations qui n'avaient jamais lancé de job de fine-tuning ne peuvent plus en créer ; depuis le **2 juillet 2026**, celles qui n'ont fait aucune inférence sur un modèle fine-tuné dans les 60 derniers jours non plus ; le **6 janvier 2027**, plus aucun client ne pourra créer de job. L'inférence sur les modèles déjà fine-tunés reste possible jusqu'à la dépréciation de leur modèle de base.

> ⚠️ **Piège fréquent** — Croire que le fine-tuning « apprend des connaissances » au modèle. Il apprend surtout un **comportement** (style, format, décisions). Pour injecter des connaissances à jour (vos tarifs, vos procédures), c'est le RAG ou le contexte qu'il faut, pas le fine-tuning.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour qu'un assistant connaisse les nouveaux tarifs 2027 d'un client, le fine-tuning est la meilleure solution.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. Le fine-tuning apprend surtout un comportement (style, format). Des informations qui changent se donnent dans le contexte ou par RAG (M20), mis à jour sans ré-entraînement."
}
```

## 5. Safety best practices : la check-list d'OpenAI

La page [Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) liste onze rubriques (nov. 2026). Les plus utiles dans un pipeline :

| Rubrique | Mise en œuvre concrète |
|---|---|
| **Moderation API** (gratuite) | `client.moderations.create(input=texte)` sur les entrées utilisateurs **et** les sorties ; refuser ou escalader si `flagged` |
| Tests adversariaux | ajoutez à votre éval 10 entrées « méchantes » (injection, hors sujet, données perso) et vérifiez le comportement |
| Human in the loop | approbation pour toute action irréversible (L081) |
| Contraindre l'entrée, limiter la sortie | taille maximale du texte utilisateur, `max_output_tokens` |
| **Safety identifiers** | envoyez un identifiant utilisateur haché (`safety_identifier`) pour qu'OpenAI puisse isoler un abus sans bloquer toute votre application |
| Signalement et limites | un bouton « signaler », et une phrase claire sur ce que l'assistant ne fait pas |
| KYC, révocation de clés | clés par environnement, rotation, révocation immédiate en cas de fuite |

```python
# moderation.py — filtrer une entrée avant de la transmettre au modèle
from openai import OpenAI
client = OpenAI()

def est_acceptable(texte: str) -> bool:
    m = client.moderations.create(input=texte)   # modèle de modération par défaut ; gratuit (nov. 2026)
    r = m.results[0]
    if r.flagged:
        categories = [k for k, v in r.categories.model_dump().items() if v]
        print("Entrée refusée :", categories)
    return not r.flagged

print(est_acceptable("Bonjour, où en est ma commande ?"))
```

```mission
{
  "title": "La date de fermeture du fine-tuning OpenAI",
  "url": "https://developers.openai.com/api/docs/deprecations",
  "steps": [
    "Ouvrez la page Deprecations",
    "Cherchez l'entrée consacrée au fine-tuning (annonce du 7 mai 2026)",
    "Relevez les trois dates du calendrier"
  ],
  "question": "À partir de quelle date plus aucun client OpenAI ne pourra-t-il créer de job de fine-tuning ? Les modèles déjà fine-tunés restent-ils utilisables ?",
  "hint": "Il y a trois étapes : mai 2026, juillet 2026, puis une dernière en 2027.",
  "answer": "Le 6 janvier 2027 ; l'inférence sur les modèles déjà fine-tunés continue jusqu'à la dépréciation du modèle de base (page lue en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "L'identifiant qui isole un utilisateur abusif",
  "url": "https://developers.openai.com/api/docs/guides/safety-best-practices",
  "steps": [
    "Ouvrez la page Safety best practices",
    "Comptez les rubriques de la page",
    "Repérez celle qui parle d'identifier les utilisateurs finaux"
  ],
  "question": "Quel paramètre envoyer pour qu'OpenAI puisse isoler un utilisateur abusif sans bloquer toute votre application, et combien de rubriques compte la page ?",
  "hint": "Le paramètre contient le mot « safety ».",
  "answer": "`safety_identifier` (un identifiant utilisateur haché) ; la page compte onze rubriques (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Vous reprenez l'assistant SAV vélos de la L078. Construisez son **banc d'évaluation** :
1. un fichier `jeu_test.jsonl` de 20 questions clients avec, pour chacune, un critère (étiquette attendue pour les 10 questions de classification ; grille de juge pour les 10 réponses rédigées) ;
2. une éval avec **deux** `testing_criteria` (string_check et score_model) ;
3. trois runs : `gpt-6-luna`, `gpt-6.1-terra`, et `gpt-6.1-terra` avec un prompt amélioré ;
4. un tableau comparatif coût (tarifs L078, à partir des `usage` des réponses) × score, et une recommandation en trois lignes ;
5. bonus : relancez les 20 questions en Batch et comparez le coût.

**Critères de réussite.** L'éval se crée sans erreur ; les trois runs se terminent ; le tableau donne score et coût par configuration ; la recommandation est argumentée par les chiffres ; les cinq entrées adversariales que vous avez ajoutées sont correctement refusées (modération ou instructions).

**Pistes de corrigé.** Les trois configurations ne changent que `model` et `input_messages.template` ; pour le coût, additionnez `usage` sur les réponses stockées (dashboard) ou relancez les mêmes prompts avec `client.responses.create` en comptant. La « bonne » réponse dépend de votre jeu : c'est précisément le but.

## ✅ Auto-évaluation express

1. Dans quel ordre la doc OpenAI recommande-t-elle évals, optimisation de prompt et fine-tuning ?
2. Quel est le tarif Batch par rapport au Standard, et quelle est sa contrainte ?
3. Un nouveau client vous demande un fine-tuning de GPT-6 chez OpenAI : que répondez-vous ?

*Réponses : 1) Évals d'abord, puis prompt/outils/RAG/choix de modèle, fine-tuning en dernier recours. 2) 0,5× ; exécution asynchrone sous 24 h, résultats à récupérer dans un fichier. 3) Qu'au 1er nov. 2026 la plateforme de fine-tuning OpenAI est en arrêt progressif et fermée aux nouveaux comptes, qu'aucun GPT-6 n'est proposé, et que le besoin se traite par prompt, RAG ou fine-tuning d'un modèle ouvert.*

## 📚 Pour aller plus loin
- [Evals getting started](https://developers.openai.com/api/docs/guides/evaluation-getting-started) 🇬🇧 — tutoriel pas à pas, avec le dashboard.
- [Evals](https://developers.openai.com/api/docs/guides/evals) 🇬🇧 — types de critères, juges, bonnes pratiques.
- [Batch](https://developers.openai.com/api/docs/guides/batch) 🇬🇧 — format JSONL, limites, statuts.
- [Model optimization](https://developers.openai.com/api/docs/guides/model-optimization) 🇬🇧 — la boucle évals → prompt → fine-tuning.
- [Building Systems with the ChatGPT API](https://deeplearning.ai/short-courses/building-systems-with-chatgpt/) 🇬🇧 — les deux leçons « Evaluation I-II » du short course DeepLearning.AI.

> 🗺️ **Et maintenant ?** — Vous avez tous les outils ; la L083 les met en œuvre dans un vrai portage : l'assistant devis de M17 passe de Claude à OpenAI, tests à l'appui.
