---
id: L078
module: M18
level: N3
title: "Responses API et Chat Completions"
minutes: 50
objectives:
  - "Envoyer une première requête à la Responses API en Python et en TypeScript avec une clé lue depuis l'environnement"
  - "Expliquer la différence de structure entre Chat Completions (messages → choices) et Responses (items → output)"
  - "Choisir un modèle de la famille GPT-6 (Astra, 6.1 Sol, 6.1 Terra, Luna) selon le coût, la latence et la difficulté de la tâche"
  - "Implémenter le streaming, la conversation multi-tours (previous_response_id) et le calcul du coût d'un appel"
skills: ["C3.1"]
sources:
  - { title: "OpenAI Developers — Quickstart", url: "https://developers.openai.com/api/docs/quickstart", lang: "en" }
  - { title: "OpenAI Developers — Migrate to the Responses API", url: "https://developers.openai.com/api/docs/guides/migrate-to-responses", lang: "en" }
  - { title: "OpenAI Developers — Models", url: "https://developers.openai.com/api/docs/models", lang: "en" }
  - { title: "OpenAI Developers — Pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "OpenAI Developers — Streaming responses", url: "https://developers.openai.com/api/docs/guides/streaming-responses", lang: "en" }
  - { title: "OpenAI Developers — Conversation state", url: "https://developers.openai.com/api/docs/guides/conversation-state", lang: "en" }
  - { title: "OpenAI Developers — Rate limits", url: "https://developers.openai.com/api/docs/guides/rate-limits", lang: "en" }
  - { title: "OpenAI Developers — Model selection", url: "https://developers.openai.com/api/docs/guides/model-selection", lang: "en" }
---

# Responses API et Chat Completions

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 18

## 🎯 Ce que vous saurez faire
- Installer le SDK officiel `openai` (Python et TypeScript), stocker votre clé dans `OPENAI_API_KEY` et obtenir une première réponse d'un modèle GPT-6.
- Lire une réponse Responses API comme un développeur : tableau `output` d'items typés, raccourci `output_text`, bloc `usage`.
- Reconnaître du code Chat Completions (l'ancien format `messages` → `choices`) et le traduire vers Responses.
- Tenir une conversation multi-tours sans renvoyer tout l'historique, activer le streaming et estimer le coût d'un appel en dollars.

> 🧭 **En clair** — L'API d'OpenAI, c'est un guichet auquel votre programme envoie une question écrite et dont il reçoit une réponse, accompagnée d'un ticket de caisse : le nombre de *tokens* (des morceaux de mots, l'unité de facturation). Il existe deux guichets : l'ancien, Chat Completions, où il faut rapporter tout le dossier à chaque visite, et le nouveau, la Responses API, qui vous remet un numéro de dossier pour revenir sans tout recopier. Vous choisissez aussi le « cuisinier », c'est-à-dire le modèle : Luna pour les tâches simples et bon marché, Terra pour le quotidien, Sol et Astra pour les plats difficiles. Tout l'art consiste à prendre le moins cher qui fait bien le travail, et à savoir lire le ticket pour en calculer le prix.

## 1. Deux portes d'entrée, une seule à retenir

Vous venez du module M17 : vous connaissez la Messages API d'Anthropic, sans état, où vous renvoyez tout l'historique à chaque tour. Chez OpenAI, l'histoire est un peu plus mouvementée. Il existe **deux** API de génération de texte :

| | **Chat Completions** (2023) | **Responses API** (2025, recommandée) |
|---|---|---|
| Point d'entrée | `POST /v1/chat/completions` | `POST /v1/responses` |
| Entrée | tableau `messages` (`system` / `user` / `assistant`) | `input` : une chaîne ou une liste d'**items** typés |
| Sortie | `choices[0].message.content` | tableau `output` d'items (message, reasoning, function_call…) + raccourci `output_text` |
| Format JSON | `response_format` | `text.format` |
| Plusieurs réponses | paramètre `n` | supprimé |
| État | aucun (vous renvoyez tout) | `previous_response_id` ou API Conversations ; stockage par défaut (`store: false` pour désactiver) |
| Outils intégrés | aucun | `web_search`, `file_search`, `code_interpreter`, `image_generation`, computer use, MCP distant |
| Statut | maintenue, « legacy » pour les nouveautés | **par défaut** dans toute la doc et le quickstart |

La page officielle [Migrate to the Responses API](https://developers.openai.com/api/docs/guides/migrate-to-responses) donne trois raisons chiffrées de migrer (nov. 2026) : environ **3 % de gain sur SWE-bench à prompt identique**, une **boucle agentique intégrée** (le modèle peut enchaîner plusieurs outils dans une seule requête) et **40 à 80 % de meilleure utilisation du cache**. Elle ajoute que le raisonnement peut être **chiffré** pour les organisations en « zero data retention ». L'ancienne **Assistants API**, elle, est reléguée dans la rubrique « Legacy APIs » avec un guide de migration.

> 💡 **À retenir** — Dans ce module, tout le code utilise la **Responses API**. Vous apprendrez à *lire* Chat Completions (des milliers de tutoriels et de dépôts l'utilisent encore), mais vous écrirez du Responses.

Analogie du quotidien : Chat Completions, c'est le guichet où vous apportez chaque fois le dossier complet dans une chemise cartonnée. Responses, c'est le guichet qui vous donne un **numéro de dossier** (`previous_response_id`) : la fois suivante, vous donnez le numéro et seulement la nouvelle pièce.

```quiz
{
  "q": "Dans la Responses API, à quoi sert `previous_response_id` ?",
  "options": [
    "À choisir le modèle de la réponse suivante",
    "À reprendre une conversation stockée sans tout renvoyer",
    "À annuler la réponse précédente pour qu'elle ne soit pas facturée",
    "À chiffrer la réponse précédente pour le RGPD"
  ],
  "answer": 1,
  "explanation": "C'est le « numéro de dossier » : OpenAI recharge le contexte du tour précédent, à condition que la réponse ait été stockée (`store` vaut `true` par défaut)."
}
```

## 2. Première requête : Python et TypeScript côte à côte

### 2.1 Installation et clé API

Le [Quickstart officiel](https://developers.openai.com/api/docs/quickstart) tient en quatre étapes : créer une clé dans le dashboard, l'exporter dans `OPENAI_API_KEY`, installer le SDK (`pip install openai` ou `npm install openai` ; il existe aussi des SDK .NET, Java, Go et Ruby), puis appeler `client.responses.create(...)`.

```bash
# Python 3.12+
python -m venv .venv && source .venv/bin/activate
pip install openai python-dotenv

# TypeScript / Node 20+
npm init -y && npm install openai typescript tsx

# La clé ne va JAMAIS dans le code
export OPENAI_API_KEY="sk-proj-..."   # créée sur le dashboard developers.openai.com
```

Comme pour Anthropic, placez la clé dans un `.env` ignoré par git. Une clé qui a fuité se révoque **immédiatement** depuis le dashboard : la page [Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) en fait l'une de ses onze rubriques.

### 2.2 Le « Bonjour, GPT » en Python

```python
# premier_appel.py — première requête à la Responses API
import os
from openai import OpenAI

if not os.environ.get("OPENAI_API_KEY"):
    raise SystemExit("Définissez OPENAI_API_KEY avant de lancer ce script.")

client = OpenAI()  # lit OPENAI_API_KEY automatiquement

reponse = client.responses.create(
    model="gpt-6.1-terra",            # bon rapport qualité/prix pour une PME (nov. 2026)
    instructions=(                     # l'équivalent du "system prompt"
        "Vous êtes l'assistant d'un cabinet comptable français. "
        "Répondez en français, en trois phrases maximum, sans conseil fiscal personnalisé."
    ),
    input="Quelle est la différence entre un bilan et un compte de résultat ?",
    max_output_tokens=300,            # plafond de tokens de SORTIE (optionnel mais prudent)
)

print(reponse.output_text)             # raccourci : concatène tous les blocs texte

print("\n--- métadonnées ---")
print("id :", reponse.id)              # à conserver pour previous_response_id
print("status :", reponse.status)      # "completed" attendu ; "incomplete" si tronqué
print("tokens entrée :", reponse.usage.input_tokens)
print("tokens sortie :", reponse.usage.output_tokens)
```

### 2.3 Le même appel en TypeScript

```typescript
// premier_appel.ts — à lancer avec : npx tsx premier_appel.ts
import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("Définissez OPENAI_API_KEY avant de lancer ce script.");
}

const client = new OpenAI(); // lit OPENAI_API_KEY

async function main() {
  const reponse = await client.responses.create({
    model: "gpt-6.1-terra",
    instructions:
      "Vous êtes l'assistant d'un cabinet comptable français. " +
      "Répondez en français, en trois phrases maximum, sans conseil fiscal personnalisé.",
    input: "Quelle est la différence entre un bilan et un compte de résultat ?",
    max_output_tokens: 300,
  });

  console.log(reponse.output_text);
  console.log("---");
  console.log("id :", reponse.id, "| status :", reponse.status);
  console.log("tokens :", reponse.usage?.input_tokens, "in /", reponse.usage?.output_tokens, "out");
}

main().catch((e) => { console.error(e); process.exit(1); });
```

### 2.4 Anatomie de la réponse

```
Response
├── id            "resp_..."        ← le "numéro de dossier"
├── status        "completed" | "incomplete" | "failed"
├── output[]      ← liste d'ITEMS typés
│   ├── { type: "reasoning", ... }       (modèles raisonnants, souvent résumé ou vide)
│   ├── { type: "message", role: "assistant",
│   │     content: [ { type: "output_text", text: "..." } ] }
│   └── { type: "function_call", name, arguments, call_id }   (L079)
├── output_text   ← raccourci du SDK : tous les output_text concaténés
└── usage         { input_tokens, output_tokens, total_tokens,
                    input_tokens_details: { cached_tokens } }
```

> ⚠️ **Piège fréquent** — `output_text` est un **raccourci du SDK**, pas un champ de l'API brute. Si vous appelez l'API en `curl` ou depuis n8n (module M09), vous devez parcourir `output[]` et extraire `content[].text` des items `message`. Autre piège : `output[0]` n'est **pas** forcément le message (ce peut être un item `reasoning`). Filtrez par `type`.

> 💡 **Autrement dit** — La réponse est une boîte à compartiments étiquetés : un compartiment « réflexion », un compartiment « message », parfois un compartiment « appel de fonction ». Le SDK vous tend gentiment le texte déjà déballé (`output_text`) ; sans le SDK, c'est à vous d'ouvrir le bon compartiment en lisant son étiquette (`type`).

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : `output[0]` contient toujours le texte rédigé par l'assistant.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. Avec un modèle raisonnant, le premier item est souvent un item `reasoning`. Il faut parcourir `output[]` et garder les items de `type` `message`."
}
```

## 3. Lire et traduire du Chat Completions

Vous tomberez sur ce genre de code dans la moitié des tutoriels du web :

```python
# ANCIEN FORMAT (Chat Completions) — à savoir lire, pas à écrire
completion = client.chat.completions.create(
    model="gpt-6.1-terra",
    messages=[
        {"role": "system", "content": "Vous êtes un assistant comptable."},
        {"role": "user", "content": "Bilan vs compte de résultat ?"},
    ],
)
print(completion.choices[0].message.content)
```

Table de traduction (nov. 2026, d'après le guide de migration) :

| Chat Completions | Responses API |
|---|---|
| `messages=[{"role":"system",...}]` | `instructions="..."` (ou un item `{"role":"developer"}` dans `input`) |
| `messages=[{"role":"user","content":"..."}]` | `input="..."` ou `input=[{"role":"user","content":"..."}]` |
| `choices[0].message.content` | `output_text` |
| `max_tokens` | `max_output_tokens` |
| `response_format={"type":"json_schema",...}` | `text={"format":{"type":"json_schema",...}}` |
| `tools=[{"type":"function","function":{...}}]` | `tools=[{"type":"function","name":...,...}]` (aplati, L079) |
| `n=3` | n'existe plus : faites 3 appels |
| renvoyer tout l'historique | `previous_response_id` |

🎮 **Défi** — Prenez un script Chat Completions de votre choix (ou celui ci-dessus) et convertissez-le en Responses en moins de cinq minutes, sans regarder la table. Vérifiez ensuite.

## 4. Choisir un modèle GPT-6 et estimer le coût

### 4.1 La famille (page [Models](https://developers.openai.com/api/docs/models), 1er nov. 2026)

| Modèle | ID API | Contexte | Sortie max | Cutoff | Input / Cached / Output ($ par M tokens) |
|---|---|---|---|---|---|
| GPT-6 Astra (phare) | `gpt-6-astra` | 1,05 M | 128 k | 30 avr. 2026 | 10,00 / 1,00 / 50,00 |
| GPT-6.1 Sol | `gpt-6.1-sol` | 1,05 M | 128 k | 30 avr. 2026 | 2,00 / 0,10 / 10,00 |
| GPT-6.1 Terra | `gpt-6.1-terra` | 1,05 M | 128 k | 1er juin 2026 | 1,00 / 0,05 / 5,00 |
| GPT-6 Luna | `gpt-6-luna` | 1,05 M | 128 k | 18 mai 2026 | 0,10 / 0,01 / 0,50 |

Tarifs Standard de la page [Pricing](https://developers.openai.com/api/docs/pricing) (nov. 2026). Des **niveaux de service** modulent le prix : **Batch** et **Flex** = 0,5× (L082), **Fast** = 2×, **Ultrafast** = 6× (Astra et 6.1 Sol seulement). Au-delà d'un seuil de contexte, un tarif « contexte long » s'applique (Astra : 20 / 2 / 75 ; 6.1 Sol : 4 / 0,20 / 15 ; Luna : 0,20 / 0,02 / 0,75). Le catalogue liste aussi des modèles spécialisés (`gpt-5.3-codex` pour le code, `gpt-5.6-cyber`, `chat-latest`) que nous n'utiliserons pas ici.

> 💡 **Autrement dit** — Le prix affiché est le tarif « normal ». Si vous acceptez d'attendre (Batch, Flex), vous payez moitié prix ; si vous voulez passer devant tout le monde (Fast, Ultrafast), vous payez deux à six fois plus. Et quand vous envoyez un très gros texte, au-delà d'un certain seuil, le tarif augmente, comme pour un colis hors gabarit.

Règle pratique pour une PME française : **Luna** pour le tri, la classification et les volumes (100 fois moins cher qu'Astra) ; **6.1 Terra** comme modèle par défaut ; **6.1 Sol** quand la qualité rédactionnelle ou le raisonnement comptent ; **Astra** réservé aux tâches difficiles et validé par une évaluation (L082). La page [Model selection](https://developers.openai.com/api/docs/guides/model-selection) recommande la même démarche : partir du modèle le plus capable pour valider la faisabilité, puis **descendre** en gamme tant que vos évaluations restent vertes.

### 4.2 Calculer le coût d'un appel

```python
# cout.py — estimer le coût d'une réponse à partir de usage (tarifs Standard, nov. 2026)
TARIFS_USD_PAR_M = {  # input, cached input, output — $ par million de tokens
    "gpt-6-astra":   (10.00, 1.00, 50.00),
    "gpt-6.1-sol":   (2.00, 0.10, 10.00),
    "gpt-6.1-terra": (1.00, 0.05, 5.00),
    "gpt-6-luna":    (0.10, 0.01, 0.50),
}

def cout_usd(model: str, usage) -> float:
    """usage = reponse.usage ; les tokens en cache sont facturés au tarif cached."""
    p_in, p_cache, p_out = TARIFS_USD_PAR_M[model]
    caches = getattr(getattr(usage, "input_tokens_details", None), "cached_tokens", 0) or 0
    entree_pleine = usage.input_tokens - caches
    return (entree_pleine * p_in + caches * p_cache + usage.output_tokens * p_out) / 1_000_000

# Exemple : 1 200 tokens d'entrée (dont 800 en cache), 350 de sortie, sur gpt-6.1-terra
class _Details: cached_tokens = 800
class _Usage: input_tokens = 1200; output_tokens = 350; input_tokens_details = _Details()
print(f"{cout_usd('gpt-6.1-terra', _Usage()):.6f} $")   # ≈ 0.002190 $
```

À 2 000 appels par jour, cet assistant coûterait environ **4,4 $ par jour** sur 6.1 Terra… et **44 $** sur Astra. D'où l'importance de la ligne *cached input* : l'entrée mise en cache coûte **20 fois moins** que l'entrée pleine sur Terra. Nous reviendrons sur le cache dans la leçon projet (L083).

```quiz
{
  "q": "Un cabinet envoie à `gpt-6.1-terra` 10 000 tokens d'entrée (aucun en cache) et reçoit 2 000 tokens de sortie. Combien coûte l'appel au tarif Standard (nov. 2026) ?",
  "options": [
    "0,002 $",
    "0,012 $",
    "0,02 $",
    "0,2 $"
  ],
  "answer": 2,
  "explanation": "10 000 × 1 $/M = 0,01 $ en entrée, 2 000 × 5 $/M = 0,01 $ en sortie : 0,02 $ au total. La sortie coûte cinq fois plus cher par token que l'entrée."
}
```

## 5. Conversation multi-tours et streaming

### 5.1 Enchaîner les tours avec `previous_response_id`

```python
# multi_tours.py — conversation sans renvoyer l'historique
from openai import OpenAI
client = OpenAI()

r1 = client.responses.create(
    model="gpt-6-luna",
    instructions="Vous êtes l'assistant d'une boulangerie de Lille. Répondez en français, court.",
    input="Nous ouvrons à 7 h. Note-le.",
)
print("Tour 1 :", r1.output_text)

r2 = client.responses.create(
    model="gpt-6-luna",
    previous_response_id=r1.id,          # OpenAI recharge le contexte du tour 1
    input="À quelle heure ouvrons-nous ?",
)
print("Tour 2 :", r2.output_text)        # doit répondre "7 h"
```

Ce mécanisme suppose que la réponse est **stockée** côté OpenAI (`store` est à `true` par défaut). Si votre politique de données l'interdit (données clients, RGPD, module M15), passez `store=False` et gérez l'historique vous-même en renvoyant une liste d'items dans `input`, exactement comme avec Anthropic. La page [Conversation state](https://developers.openai.com/api/docs/guides/conversation-state) décrit aussi l'API **Conversations**, un objet persistant que vous pouvez référencer par identifiant.

### 5.2 Streaming en TypeScript

```typescript
// streaming.ts — afficher la réponse au fil de l'eau (npx tsx streaming.ts)
import OpenAI from "openai";
const client = new OpenAI();

async function main() {
  const stream = await client.responses.create({
    model: "gpt-6.1-terra",
    instructions: "Répondez en français.",
    input: "Rédige un message de relance courtois pour une facture impayée de 30 jours.",
    stream: true,
  });

  for await (const event of stream) {
    // Les deltas de texte arrivent dans des événements typés
    if (event.type === "response.output_text.delta") {
      process.stdout.write(event.delta);
    } else if (event.type === "response.completed") {
      const u = event.response.usage;
      console.log(`\n\n[terminé] ${u?.input_tokens} in / ${u?.output_tokens} out`);
    }
  }
}
main();
```

Côté Python, `client.responses.create(..., stream=True)` renvoie un itérateur d'événements identiques (`response.output_text.delta`, `response.completed`). La page [Streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses) liste tous les types d'événements (texte, appels d'outils, raisonnement). Le streaming ne change pas le prix, seulement la **latence perçue** : un utilisateur qui voit les premiers mots après 300 ms attend volontiers 8 secondes de plus.

> 🔗 **Documentation officielle** — [Rate limits](https://developers.openai.com/api/docs/guides/rate-limits) : les limites (requêtes et tokens par minute) dépendent de votre palier d'usage. Gérez l'erreur HTTP 429 par un **retry exponentiel** ; le SDK en fait deux par défaut (`max_retries`), ajustable à la création du client.

```mission
{
  "title": "Trouvez le multiplicateur du niveau de service Ultrafast",
  "url": "https://developers.openai.com/api/docs/pricing",
  "steps": [
    "Ouvrez la page Pricing de la documentation OpenAI",
    "Repérez la partie consacrée aux niveaux de service (Batch, Flex, Fast, Ultrafast)",
    "Notez le multiplicateur d'Ultrafast et les modèles concernés"
  ],
  "question": "Par combien le prix Standard est-il multiplié en Ultrafast, et quels modèles y ont droit ?",
  "hint": "Comparez avec Fast (×2) et Batch / Flex (×0,5).",
  "answer": "×6, uniquement pour GPT-6 Astra et GPT-6.1 Sol (page consultée au 1er nov. 2026 — vérifiez, les tarifs évoluent) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Le paramètre qui disparaît en passant à Responses",
  "url": "https://developers.openai.com/api/docs/guides/migrate-to-responses",
  "steps": [
    "Ouvrez le guide « Migrate to the Responses API »",
    "Cherchez la comparaison des paramètres entre Chat Completions et Responses",
    "Repérez le paramètre qui demandait plusieurs réponses et le nouveau nom de response_format"
  ],
  "question": "Quel paramètre de Chat Completions, qui demandait plusieurs réponses à la fois, n'existe plus dans Responses, et comment s'appelle désormais `response_format` ?",
  "hint": "La table de traduction de la section 3 vous met sur la piste ; vérifiez-la dans le guide.",
  "answer": "`n` est supprimé (faites plusieurs appels) ; `response_format` devient `text.format` (guide consulté en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Écrivez un petit outil en ligne de commande (Python *ou* TypeScript) `assistant_sav.py` pour le SAV d'une boutique en ligne de vélos. Il doit :
1. lire la clé dans `OPENAI_API_KEY` et refuser de démarrer sans elle ;
2. fixer des `instructions` (ton, langue, périmètre : ne jamais promettre un remboursement) ;
3. boucler sur `input()` de l'utilisateur en chaînant les tours avec `previous_response_id` ;
4. streamer chaque réponse ;
5. afficher, à la fin de chaque tour, le coût cumulé en dollars (tarifs de la section 4).

**Critères de réussite.** Le script tourne sans clé en dur ; la mémoire de conversation fonctionne (« Mon vélo est un modèle X » puis « quel est mon modèle ? ») ; le coût affiché est cohérent avec `usage` ; une erreur réseau ou 429 ne fait pas planter le programme (bloc `try/except` ou `try/catch` + message clair).

**Pistes de corrigé.** Combinez `multi_tours.py` et `streaming.ts` ; stockez `reponse.id` dans une variable `dernier_id` initialisée à `None` ; pour le coût, lisez `event.response.usage` dans l'événement `response.completed`. Comparez ensuite le coût total sur `gpt-6-luna` et `gpt-6.1-terra` pour la même conversation de dix tours.

## ✅ Auto-évaluation express

1. Dans la Responses API, quel champ remplace `messages[{"role":"system"}]` ?
2. Que contient `output[0]` : forcément le message de l'assistant ?
3. Un appel sur `gpt-6-luna` avec 10 000 tokens d'entrée et 1 000 de sortie coûte combien (tarif Standard, nov. 2026) ?

*Réponses : 1) le paramètre `instructions` (ou un item de rôle `developer`). 2) Non : ce peut être un item `reasoning` ; filtrez par `type === "message"`. 3) 10 000 × 0,10 $ / M + 1 000 × 0,50 $ / M = 0,001 $ + 0,0005 $ = 0,0015 $.*

## 📚 Pour aller plus loin
- [OpenAI Developers — Quickstart](https://developers.openai.com/api/docs/quickstart) 🇬🇧 — les quatre étapes officielles, avec extension aux fichiers et aux outils.
- [Migrate to the Responses API](https://developers.openai.com/api/docs/guides/migrate-to-responses) 🇬🇧 — le guide de migration complet, à lire une fois en entier.
- [Text generation](https://developers.openai.com/api/docs/guides/text) 🇬🇧 — paramètres de génération et bonnes pratiques de prompt.
- [OpenAI Cookbook](https://developers.openai.com/cookbook/topic/text) 🇬🇧 — notebooks d'exemples maintenus par OpenAI.
- [Building Systems with the ChatGPT API](https://deeplearning.ai/short-courses/building-systems-with-chatgpt/) 🇬🇧 — short course DeepLearning.AI (Isa Fulford, Andrew Ng), 1 h 55 : chaînage de prompts, modération, évaluation.

> 🗺️ **Et maintenant ?** — Votre modèle sait parler ; dans la leçon suivante (L079), vous lui donnez des « mains » (function calling) et un formulaire à remplir (structured outputs).
