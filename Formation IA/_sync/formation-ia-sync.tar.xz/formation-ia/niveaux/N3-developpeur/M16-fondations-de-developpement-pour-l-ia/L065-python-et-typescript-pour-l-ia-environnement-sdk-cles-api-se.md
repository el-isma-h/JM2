---
id: L065
module: M16
level: N3
title: "Python et TypeScript pour l'IA : environnement, SDK, clés API, secrets"
minutes: 65
objectives:
  - "Construire un environnement de développement reproductible pour l'IA en Python 3.12 (uv ou venv) et en Node 22 / TypeScript"
  - "Installer et configurer les SDK officiels anthropic, openai et @anthropic-ai/sdk, et expliquer ce qu'un SDK apporte par rapport à un appel HTTP brut"
  - "Appliquer les règles de gestion des clés API (variables d'environnement, fichier .env ignoré par Git, gestionnaire de secrets, rotation, jamais côté navigateur)"
  - "Réaliser et lire un premier appel à un modèle de langage en Python et en TypeScript, en identifiant les champs de la réponse (contenu, stop_reason, usage)"
skills: ["C3.1"]
sources:
  - { title: "Claude Platform — Get started (Quickstart)", url: "https://platform.claude.com/docs/en/get-started", lang: "en" }
  - { title: "Claude Platform — Client SDKs overview", url: "https://platform.claude.com/docs/en/cli-sdks-libraries/overview", lang: "en" }
  - { title: "Claude Platform — Get an API key", url: "https://platform.claude.com/docs/en/get-api-key", lang: "en" }
  - { title: "Claude Platform — API migration 2026-10-21", url: "https://platform.claude.com/docs/en/api/migration-2026-10-21", lang: "en" }
  - { title: "OpenAI — Quickstart (developers.openai.com)", url: "https://developers.openai.com/api/docs/quickstart", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "xAI — Quickstart", url: "https://docs.x.ai/developers/quickstart", lang: "en" }
  - { title: "uv — Documentation officielle (Astral)", url: "https://docs.astral.sh/uv/", lang: "en" }
  - { title: "Python — module venv", url: "https://docs.python.org/3/library/venv.html", lang: "en" }
  - { title: "OWASP Top 10 for LLM Applications (GenAI Security Project)", url: "https://genai.owasp.org/", lang: "en" }
---

# Python et TypeScript pour l'IA : environnement, SDK, clés API, secrets

> ⏱ 65 min · 🎯 Niveau 3 · 📚 Module 16

## 🎯 Ce que vous saurez faire
- Monter en moins de dix minutes un projet Python 3.12 (avec `uv` ou `venv`) et un projet Node 22 / TypeScript propres, versionnés et reproductibles sur la machine d'un collègue.
- Installer les trois SDK que vous utiliserez tout au long du niveau 3 (`anthropic`, `openai`, `@anthropic-ai/sdk`) et comprendre ce qu'ils font à votre place : authentification, versionnage d'API, nouvelles tentatives, typage.
- Gérer une clé API comme un professionnel : où la créer, où la stocker, comment la faire tourner, et surtout où elle ne doit **jamais** se trouver.
- Écrire, exécuter et lire votre premier appel à Claude en Python puis en TypeScript, et votre premier appel à GPT-6 avec le SDK OpenAI.

> 🧭 **En clair** — Avant de cuisiner, on range sa cuisine : chaque projet de code a son propre placard d'ingrédients (l'**environnement virtuel**), avec une liste de courses précise et figée (le fichier de verrouillage) pour qu'un collègue puisse refaire exactement la même recette. Le **SDK**, c'est l'appareil électroménager fourni par le fabricant (Anthropic, OpenAI) : il sait parler au modèle à votre place. Et la **clé API**, c'est la carte bancaire de votre compte : chaque appel est débité dessus. On ne la laisse donc jamais traîner dans le code, ni dans Git, ni dans une page web ; on la range dans un coffre (une variable d'environnement, puis un gestionnaire de secrets), et le programme va l'y chercher tout seul.

## 1. Pourquoi commencer par l'outillage

Le niveau 2 vous a appris à faire travailler des modèles sans code : n8n, assistants personnalisés, modèles locaux. Le niveau 3 change d'échelle : vous allez écrire des programmes qui appellent des modèles de langage des milliers de fois par jour, en production, avec de l'argent réel qui sort à chaque requête. Avant la première ligne « intelligente », il faut une fondation saine. Un développeur qui lance `pip install` dans le Python système de son Mac, colle sa clé dans le code et pousse le tout sur GitHub a, en moyenne, quelques heures devant lui avant que des robots ne trouvent la clé et ne la consomment pour miner des réponses à leur compte. Ce n'est pas une hypothèse d'école : la recherche automatisée de clés exposées sur les dépôts publics est une industrie.

Deux langages structurent ce niveau. **Python 3.12+** domine l'écosystème IA : SDK, notebooks, bibliothèques de RAG, d'évaluation, de fine-tuning. **TypeScript sur Node 22** domine les applications web et les agents intégrés à des produits (le cours Anthropic « Claude Platform 101 » est d'ailleurs écrit avec le SDK TypeScript). Un développeur IA complet sait lire et écrire les deux ; ce module vous donne les mêmes exemples dans les deux langages.

> 💡 **À retenir** — Les quatre fondamentaux de ce module : un **environnement isolé** par projet, des **dépendances épinglées**, une **clé lue depuis l'environnement** et un **appel minimal qui fonctionne**. Tout le reste du niveau 3 se construit dessus.

## 2. Environnement Python 3.12 : uv ou venv

### 2.1 Le problème que l'on résout

Python installe par défaut les paquets dans un répertoire global. Deux projets qui exigent deux versions différentes de `httpx` ou de `pydantic` se marchent dessus, et une mise à jour pour l'un casse l'autre. La réponse classique est l'**environnement virtuel** (*virtual environment*) : un dossier `.venv/` qui contient sa propre copie de l'interpréteur et ses propres paquets. L'analogie du quotidien : plutôt qu'une seule boîte à outils dans laquelle tout le monde pioche, chaque chantier a sa propre caisse, inventoriée.

### 2.2 Option recommandée en 2026 : uv

`uv`, édité par Astral (les auteurs du linter Ruff), est un gestionnaire de projet Python écrit en Rust. Il remplace à lui seul `pip`, `venv`, `pip-tools` et `pyenv`, et il est très rapide (résolution de dépendances en secondes). Il sait aussi **installer Python 3.12 lui-même** si votre machine ne l'a pas.

```bash
# Installation de uv (macOS / Linux) — voir https://docs.astral.sh/uv/ pour Windows
curl -LsSf https://astral.sh/uv/install.sh | sh

# Création d'un projet avec Python 3.12 épinglé
mkdir mon-projet-ia && cd mon-projet-ia
uv init --python 3.12          # crée pyproject.toml, .python-version, .gitignore
uv add anthropic openai python-dotenv httpx   # ajoute et installe les dépendances

# Exécuter un script dans l'environnement du projet, sans l'activer
uv run python premier_appel.py
```

Ce que `uv` a produit :

| Fichier | Rôle | À versionner dans Git ? |
|---|---|---|
| `pyproject.toml` | Déclare le projet et ses dépendances (`anthropic>=2.3.0`…) | Oui |
| `uv.lock` | Fige les versions exactes de **toutes** les dépendances transitives | Oui (reproductibilité) |
| `.python-version` | Indique la version de Python (`3.12`) | Oui |
| `.venv/` | L'environnement virtuel lui-même | **Non** (déjà dans `.gitignore`) |

Sur la machine d'un collègue, `git clone` puis `uv sync` reconstruit exactement le même environnement. C'est la définition de la reproductibilité.

```quiz
{
  "q": "Parmi ces éléments d'un projet uv, lequel ne doit PAS être versionné dans Git ?",
  "options": [
    "pyproject.toml (la déclaration du projet)",
    "uv.lock (le verrou des versions)",
    ".venv/",
    "le fichier .python-version"
  ],
  "answer": 2,
  "explanation": ".venv/ est l'environnement lui-même : lourd et propre à chaque machine, il se reconstruit avec uv sync. Les trois autres fichiers décrivent le projet et figent les versions : ils sont indispensables à la reproductibilité."
}
```

### 2.3 Option standard : venv + pip

Si votre entreprise impose les outils de la bibliothèque standard, `venv` fait le travail, un peu plus lentement et avec plus de commandes :

```bash
python3.12 -m venv .venv
source .venv/bin/activate            # Windows PowerShell : .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install "anthropic>=2.3,<3" "openai>=3,<4" python-dotenv
python -m pip freeze > requirements.txt   # fige les versions pour les collègues
```

> ⚠️ **Piège fréquent** — Oublier d'activer l'environnement, puis s'étonner que `import anthropic` échoue : vous utilisez alors le Python global. Vérifiez avec `which python` (ou `Get-Command python` sous Windows) que le chemin pointe vers `.venv`. Avec `uv run`, ce piège disparaît.

## 3. Environnement Node 22 / TypeScript

Node 22 est une version LTS (*Long Term Support*) encore maintenue en novembre 2026 et largement déployée en production (vérifiez le calendrier sur nodejs.org : une version LTS plus récente peut être active, et tout ce qui suit s'y applique). Elle intègre `fetch`, les modules ES et un chargeur TypeScript natif pour les scripts simples. Pour un projet sérieux, on ajoute tout de même `typescript` et `tsx` (exécution directe de fichiers `.ts`).

```bash
mkdir mon-projet-ia-ts && cd mon-projet-ia-ts
npm init -y
npm install @anthropic-ai/sdk openai dotenv
npm install --save-dev typescript tsx @types/node
npx tsc --init --target es2022 --module nodenext --moduleResolution nodenext --strict --outDir dist
```

Ajoutez dans `package.json` le champ `"type": "module"` (modules ES) et un script de lancement :

```json
{
  "type": "module",
  "scripts": {
    "start": "tsx src/premier-appel.ts",
    "build": "tsc"
  }
}
```

L'équivalent du `uv.lock` est `package-lock.json` : il est généré automatiquement et doit être versionné. `node_modules/` ne l'est jamais. Côté versions de Node, l'outil `nvm` (ou `fnm`) joue le rôle de `uv python` : un fichier `.nvmrc` contenant `22` suffit pour que toute l'équipe utilise la même version.

| Besoin | Python | TypeScript / Node |
|---|---|---|
| Isoler les dépendances | `.venv/` (uv ou venv) | `node_modules/` (par projet, automatique) |
| Déclarer les dépendances | `pyproject.toml` | `package.json` |
| Figer les versions exactes | `uv.lock` / `requirements.txt` | `package-lock.json` |
| Épingler la version du langage | `.python-version` | `.nvmrc` + champ `engines` |
| Lancer un script | `uv run python x.py` | `npx tsx x.ts` |

## 4. Les SDK : ce qu'ils font pour vous

Une API de modèle de langage est une API HTTP : vous pourriez l'appeler avec `curl` ou `fetch` (nous le ferons à la leçon L066 pour comprendre la mécanique). Un **SDK** (*Software Development Kit*) est la bibliothèque officielle qui enveloppe ces appels HTTP. Elle vous apporte :

1. **L'authentification** : la clé est lue dans `ANTHROPIC_API_KEY` ou `OPENAI_API_KEY` sans que vous ayez à construire d'en-tête.
2. **Le versionnage d'API** : le SDK Anthropic envoie automatiquement l'en-tête `anthropic-version: 2026-10-21` (la version courante, nov. 2026) ; vous ne découvrirez pas un changement de format par surprise.
3. **Les nouvelles tentatives** (*retries*) : en cas d'erreur 429 (limite de débit), 5xx ou de coupure réseau, le SDK réessaie deux fois par défaut avec un délai croissant (détails en L066).
4. **Le typage** : en Python, les réponses sont des objets Pydantic ; en TypeScript, des types stricts. Votre éditeur vous indique les champs disponibles.
5. **Les utilitaires** : streaming assemblé, comptage de tokens, lots (*batches*), sorties structurées (`parse`).

> 💡 **Autrement dit** — Appeler l'API « à la main », c'est envoyer une lettre recommandée en remplissant soi-même le formulaire de La Poste : adresse exacte, cases à cocher, tampon, et recommencer si le guichet est fermé. Le SDK, c'est un secrétariat qui fait tout cela pour vous : il glisse votre carte d'accès (la clé) dans l'enveloppe, indique la bonne version du formulaire, réessaie poliment si le guichet est saturé (erreur 429) et vous rend une réponse bien rangée dans des cases nommées.

État des SDK officiels au 1er novembre 2026 (page « Client SDKs overview ») : Python `anthropic` 2.3.0, TypeScript `@anthropic-ai/sdk` 1.3.0, plus Go, Java, C#, Ruby, PHP et la CLI `ant`. Les SDK « v2 » sont sortis le 21 octobre 2026 avec la version d'API `2026-10-21` et sont désormais sous licence **Apache 2.0** ; ils s'authentifient avec `Authorization: Bearer` au lieu de `X-Api-Key` (en HTTP brut, `x-api-key` reste l'en-tête documenté), ce qui compte si un proxy lit `X-Api-Key`. Côté OpenAI, `pip install openai` / `npm install openai` installe le SDK dont l'interface principale est l'API **Responses** (`client.responses.create`). Côté xAI, le quickstart officiel recommande d'utiliser… le SDK OpenAI avec `base_url="https://api.x.ai/v1"` : un seul SDK, deux fournisseurs.

> 🔗 **Documentation officielle** — [Client SDKs overview](https://platform.claude.com/docs/en/cli-sdks-libraries/overview) · [OpenAI Quickstart](https://developers.openai.com/api/docs/quickstart) · [xAI Quickstart](https://docs.x.ai/developers/quickstart)

## 5. Clés API : obtenir, stocker, protéger, faire tourner

### 5.1 Obtenir une clé

- **Anthropic** : créez un compte sur la Console (`platform.claude.com`), ajoutez un moyen de paiement, puis générez une clé dans *Settings → API keys* (`https://platform.claude.com/settings/keys`). Nommez-la d'après son usage (`dev-nika-portable`, `prod-facturation`), jamais « clé 1 ».
- **OpenAI** : dashboard développeur, section *API keys*, même logique.
- **xAI** : console `console.x.ai`, clé dans la variable `XAI_API_KEY`.

Une clé n'est affichée **qu'une seule fois** à sa création. Si vous la perdez, vous en créez une autre et révoquez l'ancienne : c'est normal et sain.

### 5.2 Les cinq règles

| Règle | Pourquoi | Comment |
|---|---|---|
| 1. Jamais dans le code ni dans Git | Les dépôts (même privés) fuient, les captures d'écran aussi | Variable d'environnement ; `.env` dans `.gitignore` |
| 2. Jamais côté navigateur ou application mobile | Tout ce qui est livré au client est lisible (onglet Réseau, décompilation) | Le navigateur appelle **votre** serveur, qui seul détient la clé |
| 3. Une clé par environnement et par projet | Révoquer sans tout casser ; mesurer les coûts par usage | `dev` / `staging` / `prod`, workspaces séparés dans la Console |
| 4. Rotation régulière et immédiate en cas de doute | Limite la fenêtre d'exploitation | Créer la nouvelle, déployer, révoquer l'ancienne |
| 5. Plafonds de dépense et alertes | Une clé volée ou une boucle infinie vide un compte en une nuit | Limites par workspace dans la Console (détails en L067) |

La règle 2 est celle que les débutants violent le plus souvent, en particulier dans les applications React ou Vue « sans backend ». La seule architecture correcte est : navigateur → votre API (Next.js route, FastAPI, Express) → fournisseur. Votre serveur peut en plus authentifier l'utilisateur, limiter le nombre de requêtes et journaliser les coûts.

Le bon circuit, vu comme un échange de messages :

```mermaid
sequenceDiagram
    participant N as Navigateur
    participant S as Votre serveur
    participant F as Fournisseur (Anthropic, OpenAI, xAI)
    N->>S: Question de l'utilisateur (sans clé)
    S->>S: Vérifie l'utilisateur et son quota
    S->>F: Appel API avec la clé (lue dans l'environnement)
    F-->>S: Réponse du modèle et usage
    S-->>N: Réponse affichée
```

> ⚠️ **Piège fréquent** — Un fichier `.env` **commité par erreur** reste dans l'historique Git même après suppression. Il faut considérer la clé comme compromise, la révoquer immédiatement, puis purger l'historique. La prévention coûte une ligne : ajoutez `.env` au `.gitignore` **avant** le premier commit. Le `.gitignore` généré par `uv init` exclut `.venv/` mais **pas** `.env` ; sous Node, `npm init` ne crée aucun `.gitignore`. Dans les deux cas, la ligne `.env` est à écrire vous-même.

```quiz
{
  "type": "vrai_faux",
  "q": "Dans une application React, placer la clé dans une variable préfixée VITE_ ou NEXT_PUBLIC_ suffit à la cacher aux utilisateurs.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Ces préfixes signifient précisément « inclure dans le bundle JavaScript livré au navigateur » : n'importe qui peut lire la clé dans les outils de développement. La clé reste sur votre serveur, qui relaie les appels."
}
```

### 5.3 Du fichier .env au gestionnaire de secrets

En développement local, le fichier `.env` est le standard :

```bash
# .env — jamais versionné, un par développeur
ANTHROPIC_API_KEY=sk-ant-api03-...votre-cle...
OPENAI_API_KEY=sk-proj-...votre-cle...
XAI_API_KEY=xai-...votre-cle...
```

Les bibliothèques `python-dotenv` (Python) et `dotenv` (Node) chargent ce fichier dans les variables d'environnement au démarrage. Fournissez à l'équipe un `.env.example` versionné, avec les noms de variables et des valeurs vides.

En production, on ne dépose pas de fichier `.env` sur le serveur : on utilise le **gestionnaire de secrets** de la plateforme, qui chiffre la valeur, journalise les accès et facilite la rotation. Exemples : variables chiffrées d'un hébergeur (Vercel, Railway, Clever Cloud, Scaleway), *GitHub Actions secrets* pour la CI, AWS Secrets Manager, Google Secret Manager, HashiCorp Vault pour les grandes organisations. Dans tous les cas, votre code ne change pas : il lit toujours `os.environ["ANTHROPIC_API_KEY"]`. C'est tout l'intérêt de la convention.

Le SDK Anthropic v2 va plus loin : il peut lire des **profils** de configuration sur disque et des identités fédérées (*workload identity*), ce qui permet, sur un serveur cloud, de ne stocker aucune clé statique du tout. Retenez simplement l'ordre de résolution : argument explicite > variable `ANTHROPIC_API_KEY` > profil. Gardez la clé statique pour vos débuts, et sachez que l'option « sans clé » existe pour la production.

> 🔗 **Documentation officielle** — [Get an API key](https://platform.claude.com/docs/en/get-api-key) · [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) (rubrique sur la protection des clés) · [OWASP GenAI Security Project](https://genai.owasp.org/) (LLM02:2026 *Sensitive Information Disclosure*, LLM06:2026 *Unbounded Consumption*)

## 6. Premier appel en Python

Le scénario fil rouge de ce module : **Chauffage Martin**, une PME de plomberie-chauffage de Lille, veut un assistant qui reformule les demandes de devis reçues par e-mail en fiches structurées. Premier pas : obtenir une réponse du modèle.

```python
# premier_appel.py — Python 3.12+, anthropic>=2.3
# Lancer : uv run python premier_appel.py
import os

from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()  # charge .env dans os.environ (sans écraser une variable déjà définie)

if not os.environ.get("ANTHROPIC_API_KEY"):
    raise SystemExit("ANTHROPIC_API_KEY manquante : créez un fichier .env ou exportez la variable.")

# Le client lit ANTHROPIC_API_KEY tout seul ; ne passez jamais la clé en dur ici.
client = Anthropic()

message = client.messages.create(
    model="claude-sonnet-5-5",   # bon rapport qualité/prix (2 $ / 10 $ par MTok, nov. 2026)
    max_tokens=300,              # obligatoire : plafond de tokens générés
    system="Vous êtes l'assistant de Chauffage Martin, PME de plomberie à Lille. "
           "Répondez en français, de façon concise.",
    messages=[
        {
            "role": "user",
            "content": "Bonjour, ma chaudière gaz de 2009 fait un bruit de claquement "
                       "au démarrage, pouvez-vous passer cette semaine ? Rue Nationale, Lille.",
        }
    ],
)

# La réponse est une liste de blocs de contenu ; ici un seul bloc texte.
for bloc in message.content:
    if bloc.type == "text":
        print(bloc.text)

print("\n--- métadonnées ---")
print("modèle        :", message.model)
print("stop_reason   :", message.stop_reason)       # end_turn, max_tokens, tool_use…
print("tokens entrée :", message.usage.input_tokens)
print("tokens sortie :", message.usage.output_tokens)
```

Lisez la réponse comme un professionnel, pas seulement le texte :

- `message.content` est une **liste de blocs** (`text`, mais aussi `tool_use`, `thinking`…). Ne supposez jamais `content[0]` sans vérifier son type.
- `stop_reason` vous dit **pourquoi** le modèle s'est arrêté : `end_turn` (fin naturelle), `max_tokens` (vous l'avez coupé : augmentez `max_tokens` ou gérez la continuation), `tool_use` (il veut appeler un outil, module 17), `refusal`, `pause_turn`, `stop_sequence`, `model_context_window_exceeded`.
- `usage` donne les tokens consommés : c'est votre facture (leçon L067).

Trois particularités de l'API 2026 à connaître dès maintenant : `max_tokens` est **obligatoire** ; les modèles Claude 5.x utilisent par défaut le *thinking* adaptatif, piloté par `output_config={"effort": "low"|"medium"|"high"|"xhigh"|"max"}` plutôt que par `temperature` ; et justement, **`temperature` n'est plus accepté** (erreur 400 sur les modèles ≥ 4.7 (et sur tous les modèles avec la version d'API 2026-10-21, celle des SDK v2)). Si vous migrez du code écrit en 2025, c'est la première chose à retirer.

```quiz
{
  "q": "Mise en situation : votre script affiche une fiche de devis coupée au milieu d'une phrase, avec stop_reason = \"max_tokens\". Que s'est-il passé ?",
  "options": [
    "Le modèle a refusé de répondre à la demande",
    "La clé API a expiré pendant la génération de la réponse",
    "Le modèle veut appeler un outil avant de terminer",
    "Le plafond max_tokens a été atteint"
  ],
  "answer": 3,
  "explanation": "max_tokens est le plafond de tokens générés. Quand il est atteint, la réponse est coupée et stop_reason vaut max_tokens : augmentez le plafond ou demandez une réponse plus courte, et traitez ce cas dans le code. Un refus donnerait refusal, un appel d'outil tool_use."
}
```

## 7. Premier appel en TypeScript

Même scénario, même structure, avec le SDK `@anthropic-ai/sdk` :

```typescript
// src/premier-appel.ts — Node 22, @anthropic-ai/sdk >= 1.3
// Lancer : npx tsx src/premier-appel.ts
import "dotenv/config"; // charge .env dans process.env
import Anthropic from "@anthropic-ai/sdk";

if (!process.env.ANTHROPIC_API_KEY) {
  throw new Error("ANTHROPIC_API_KEY manquante : créez un fichier .env ou exportez la variable.");
}

// Le client lit process.env.ANTHROPIC_API_KEY ; aucune clé dans le code.
const client = new Anthropic();

async function main(): Promise<void> {
  const message = await client.messages.create({
    model: "claude-sonnet-5-5",
    max_tokens: 300,
    system:
      "Vous êtes l'assistant de Chauffage Martin, PME de plomberie à Lille. " +
      "Répondez en français, de façon concise.",
    messages: [
      {
        role: "user",
        content:
          "Bonjour, ma chaudière gaz de 2009 fait un bruit de claquement au démarrage, " +
          "pouvez-vous passer cette semaine ? Rue Nationale, Lille.",
      },
    ],
  });

  // Le typage TypeScript impose de vérifier le type de chaque bloc.
  for (const bloc of message.content) {
    if (bloc.type === "text") console.log(bloc.text);
  }

  console.log("\n--- métadonnées ---");
  console.log("stop_reason   :", message.stop_reason);
  console.log("tokens entrée :", message.usage.input_tokens);
  console.log("tokens sortie :", message.usage.output_tokens);
}

main().catch((err: unknown) => {
  console.error("Échec de l'appel :", err);
  process.exit(1);
});
```

Observez à quel point les deux versions se ressemblent : mêmes noms de paramètres, même forme de réponse. C'est voulu : les SDK officiels sont générés à partir de la même spécification d'API. Apprendre l'un, c'est apprendre l'autre à 90 %.

## 8. Et le SDK OpenAI ? Un code, deux fournisseurs

Le SDK OpenAI suit une autre convention (API **Responses**), mais la discipline des clés est identique. Le même script sert à GPT-6 et, en changeant deux lignes, à Grok 4.7 de xAI :

```python
# premier_appel_openai.py — openai>=3
import os

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

# --- OpenAI : GPT-6.1 Sol (2 $ / 10 $ par MTok, nov. 2026) ---
client_openai = OpenAI()  # lit OPENAI_API_KEY
reponse = client_openai.responses.create(
    model="gpt-6.1-sol",
    instructions="Vous êtes l'assistant de Chauffage Martin. Répondez en français, en 3 phrases.",
    input="Ma chaudière gaz de 2009 claque au démarrage. Pouvez-vous passer cette semaine ?",
)
print("GPT-6.1 Sol :", reponse.output_text)
print("usage       :", reponse.usage.input_tokens, "in /", reponse.usage.output_tokens, "out")

# --- xAI : même SDK, autre base_url et autre clé (grok-4.7 : 2 $ / 6 $ par MTok) ---
if os.environ.get("XAI_API_KEY"):
    client_xai = OpenAI(api_key=os.environ["XAI_API_KEY"], base_url="https://api.x.ai/v1")
    reponse_grok = client_xai.responses.create(
        model="grok-4.7",
        instructions="Vous êtes l'assistant de Chauffage Martin. Répondez en français, en 3 phrases.",
        input="Ma chaudière gaz de 2009 claque au démarrage. Pouvez-vous passer cette semaine ?",
    )
    print("Grok 4.7    :", reponse_grok.output_text)
```

Le champ `output_text` est un raccourci pratique vers le texte concaténé ; la structure complète (`reponse.output`, une liste d'items) ressemble aux blocs de contenu d'Anthropic. Nous approfondirons l'API Responses au module 18 et la stratégie multi-fournisseur au module 19.

> 💡 **À retenir** — Trois SDK, une seule convention de sécurité : **la clé vit dans l'environnement**, le client la trouve seul, le code ne la voit jamais. Si vous ne retenez qu'une chose de cette leçon, que ce soit celle-là.

### 🔎 Chasse à l'API

Trois missions pour apprendre à trouver vous-même l'information dans les documentations officielles : c'est la compétence la plus utile d'un développeur IA, car ces pages changent plus vite que n'importe quel cours.

```mission
{
  "title": "Quel en-tête porte la clé API chez Anthropic ?",
  "url": "https://platform.claude.com/docs/en/api/overview",
  "steps": ["Ouvrez la page API overview de la documentation Claude Platform", "Repérez la section consacrée à l'authentification et aux en-têtes requis (headers)", "Notez le nom de l'en-tête qui transporte la clé, celui qui indique la version d'API, et le type de contenu attendu"],
  "question": "Quels sont les trois en-têtes HTTP à envoyer avec chaque requête à l'API Claude ?",
  "hint": "Le premier est l'en-tête standard d'authentification (il accepte un repli plus ancien commençant par « x- ») ; le deuxième commence par le nom de l'entreprise ; le troisième annonce du JSON.",
  "answer": "Authorization: Bearer <clé> (x-api-key reste accepté comme repli hérité), anthropic-version (par exemple 2026-10-21) et content-type: application/json (vérifié le 5 nov. 2026). Les SDK v2 (21 oct. 2026) envoient la clé dans Authorization: Bearer, comme chez OpenAI et xAI.",
  "xp": 15
}
```

```mission
{
  "title": "Brancher le SDK OpenAI sur Grok : l'adresse et la variable",
  "url": "https://docs.x.ai/developers/quickstart",
  "steps": ["Ouvrez le Quickstart de la documentation xAI", "Repérez l'option « SDK OpenAI » (Python ou JavaScript)", "Relevez l'adresse de base (base_url) passée au client et le nom de la variable d'environnement de la clé"],
  "question": "Quelle base_url et quelle variable d'environnement le quickstart xAI utilise-t-il, et quel modèle apparaît dans le premier exemple ?",
  "hint": "L'adresse finit par /v1 ; la variable reprend le nom de l'entreprise suivi de _API_KEY.",
  "answer": "base_url = https://api.x.ai/v1 ; variable XAI_API_KEY ; modèle grok-4.7 appelé via client.responses.create (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Le tout premier appel du quickstart OpenAI",
  "url": "https://developers.openai.com/api/docs/quickstart",
  "steps": ["Ouvrez le Quickstart de la documentation OpenAI", "Repérez le nom de la variable d'environnement attendue par le SDK", "Lisez le premier exemple de code : méthode appelée, modèle utilisé, champ qui contient le texte de la réponse"],
  "question": "Quelle méthode, quel modèle et quel champ de réponse le premier exemple du quickstart utilise-t-il ?",
  "hint": "La méthode appartient à l'API Responses ; le modèle est le phare de la gamme GPT-6.",
  "answer": "client.responses.create avec model=\"gpt-6-astra\", puis response.output_text ; la clé est lue dans OPENAI_API_KEY (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🎮 Défi

Sans relire la leçon : citez, pour chacun des trois fichiers `uv.lock`, `.env` et `.env.example`, s'il doit être versionné dans Git et pourquoi. Puis expliquez en une phrase à un stagiaire pourquoi une application React ne doit pas contenir `ANTHROPIC_API_KEY`, même dans une variable « cachée » préfixée `VITE_`. (Réponse : tout ce qui est préfixé `VITE_` ou `NEXT_PUBLIC_` est **inclus dans le bundle JavaScript livré au navigateur**.)

## 🧪 Exercice pratique

**Consigne.** Créez de zéro le projet « assistant-devis » dans les deux langages.

1. Python : initialisez le projet avec `uv init --python 3.12`, ajoutez `anthropic`, `openai`, `python-dotenv`. Créez `.env.example` (noms de variables, valeurs vides) et `.env` (vos vraies clés). Vérifiez que `.env` est bien ignoré : `git status` ne doit pas le lister.
2. Écrivez `appel.py` qui envoie au modèle `claude-haiku-5-5` (le moins cher : 0,10 $ / 0,50 $ par MTok en nov. 2026) ce message : « Résume en une phrase la demande suivante et indique son degré d'urgence (faible / moyen / élevé) : *[collez un e-mail de demande d'intervention inventé]* ». Affichez le texte, le `stop_reason` et l'usage.
3. TypeScript : reproduisez le même appel dans `src/appel.ts` avec `@anthropic-ai/sdk`.
4. Bonus : faites le même appel avec `gpt-6-luna` via le SDK OpenAI et comparez le nombre de tokens d'entrée annoncé par chaque fournisseur pour le même texte.

**Critères de réussite.**
- `git status` ne montre ni `.env`, ni `.venv/`, ni `node_modules/` ; `uv.lock` et `package-lock.json` sont versionnés.
- Les deux scripts s'exécutent sans clé en dur (`grep -r "sk-ant" .` ne renvoie rien hors `.env`).
- Les deux scripts affichent un `stop_reason` égal à `end_turn` ; si vous obtenez `max_tokens`, vous avez compris pourquoi et corrigé.
- Vous savez expliquer la différence de comptage de tokens entre fournisseurs (indice : les *tokenizers* diffèrent ; leçon L067).

**Pistes de corrigé.** La structure attendue est celle des sections 6 et 7 : `load_dotenv()` / `import "dotenv/config"`, client sans argument, `max_tokens` de 150 à 300, lecture de `message.content` en vérifiant `bloc.type == "text"`. Pour le degré d'urgence, demandez explicitement un format (« Réponds sur deux lignes : Résumé : … / Urgence : … ») ; vous verrez au module 17 comment obtenir du JSON garanti avec les sorties structurées.

## ✅ Auto-évaluation express

1. Quelle commande `uv` reconstruit l'environnement exact d'un projet cloné depuis Git ?
2. Un collègue propose de stocker la clé API dans `localStorage` du navigateur « pour éviter d'avoir un serveur ». Que répondez-vous ?
3. Votre appel renvoie `stop_reason == "max_tokens"`. Qu'est-ce que cela signifie et que faites-vous ?

**Réponses.** 1) `uv sync`, qui lit `pyproject.toml` et `uv.lock`. 2) Non : tout ce qui est dans le navigateur est lisible par l'utilisateur et par n'importe quel script injecté ; la clé doit rester sur un serveur que vous contrôlez, qui relaie les appels. 3) Le modèle a été coupé parce qu'il a atteint le plafond `max_tokens` ; la réponse est tronquée. Augmentez `max_tokens` (jusqu'à 128K sur les modèles 5.5) ou demandez une réponse plus courte, et traitez ce cas dans votre code plutôt que de l'ignorer.

## 📚 Pour aller plus loin

- [Claude Platform — Get started](https://platform.claude.com/docs/en/get-started) 🇬🇧 — le quickstart officiel : installation, clé, premier appel dans huit langages.
- [Claude Platform — API migration 2026-10-21](https://platform.claude.com/docs/en/api/migration-2026-10-21) 🇬🇧 — ce qui a changé avec les SDK v2 (indispensable si vous reprenez du code de 2025).
- [uv — documentation Astral](https://docs.astral.sh/uv/) 🇬🇧 — gestion de projets, de versions de Python et de scripts à dépendances inline.
- [Python — module venv](https://docs.python.org/3/library/venv.html) 🇬🇧 — la référence de la bibliothèque standard.
- [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — clés, identifiants utilisateurs, modération, limites.
- [Claude Academy — Claude Platform 101](https://academy.claude.com/courses/claude-platform-101) 🇬🇧 — cours gratuit (1 h 30, SDK TypeScript) dont ce module couvre la première section ; le badge de fin est vérifiable publiquement.

> 🗺️ **Et maintenant ?** — Votre premier appel fonctionne grâce au SDK ; la leçon L066 ouvre le capot pour voir ce qui circule vraiment sur le réseau : requête HTTP, JSON, codes d'erreur et streaming.
