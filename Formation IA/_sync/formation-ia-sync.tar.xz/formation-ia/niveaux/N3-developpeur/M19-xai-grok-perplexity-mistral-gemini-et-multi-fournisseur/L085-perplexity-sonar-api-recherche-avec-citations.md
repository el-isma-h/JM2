---
id: L085
module: M19
level: N3
title: "Perplexity Sonar API : recherche avec citations"
minutes: 50
objectives:
  - "Expliquer la fin du support des Sonar Chat Completions (27 septembre 2026) et migrer vers l'Agent API avec les bons niveaux d'effort"
  - "Interroger la Search API (résultats bruts, filtres de domaine et de date) et l'Agent API (réponse synthétisée avec citations) en Python et TypeScript"
  - "Exploiter et afficher les citations pour produire des réponses vérifiables par un utilisateur"
  - "Chiffrer le coût d'une requête de recherche citée (Search API, outils de l'Agent API, tokens du modèle routé)"
skills: ["C3.1", "C3.3"]
sources:
  - { title: "Perplexity — Migrate from Sonar", url: "https://docs.perplexity.ai/docs/agent-api/migrate-from-sonar/overview.md", lang: "en" }
  - { title: "Perplexity — Agent API quickstart", url: "https://docs.perplexity.ai/docs/agent-api/quickstart.md", lang: "en" }
  - { title: "Perplexity — Agent API models & pricing", url: "https://docs.perplexity.ai/docs/agent-api/models.md", lang: "en" }
  - { title: "Perplexity — Agent API web_search tool", url: "https://docs.perplexity.ai/docs/agent-api/tools/web-search.md", lang: "en" }
  - { title: "Perplexity — Agent API OpenAI compatibility", url: "https://docs.perplexity.ai/docs/agent-api/openai-compatibility.md", lang: "en" }
  - { title: "Perplexity — Search API quickstart", url: "https://docs.perplexity.ai/docs/search/quickstart.md", lang: "en" }
  - { title: "Perplexity — Search API domain filter", url: "https://docs.perplexity.ai/docs/search/filters/domain-filter.md", lang: "en" }
  - { title: "Perplexity — Pricing", url: "https://docs.perplexity.ai/getting-started/pricing", lang: "en" }
  - { title: "Perplexity — Cookbook streaming citations", url: "https://docs.perplexity.ai/docs/cookbook/articles/streaming-citations/README.md", lang: "en" }
---

# Perplexity Sonar API : recherche avec citations

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 19

## 🎯 Ce que vous saurez faire
- Comprendre pourquoi le code « Sonar » de 2025 ne fonctionne plus tel quel et le migrer en dix minutes vers l'**Agent API**.
- Choisir entre la **Search API** (vous récupérez des résultats et vous rédigez) et l'**Agent API** (Perplexity cherche, lit et rédige avec citations).
- Filtrer par domaine, par date et par langue pour qu'un assistant juridique ne cite que `legifrance.gouv.fr` ou `service-public.fr`.
- Afficher les citations dans votre interface comme le fait l'application Perplexity, et calculer ce que coûte chaque réponse.

> 🧭 **En clair** — Perplexity est d'abord un moteur de recherche qui répond en citant ses sources, comme un documentaliste qui vous rend une synthèse avec les références en bas de page. Son API offre deux comptoirs : la Search API vous donne la liste brute des documents trouvés (à vous de rédiger), l'Agent API cherche, lit et rédige elle-même une réponse sourcée, avec le modèle de votre choix. L'ancien guichet « Sonar Chat Completions » a fermé le 27 septembre 2026 : le code des tutoriels de 2025 doit être migré. Le réglage d'*effort* indique combien de temps le documentaliste passe à chercher, et donc combien vous payez.

## 1. Un changement de paradigme : de Sonar à l'Agent API

Perplexity a bâti sa réputation sur une idée simple : **un moteur de réponse qui cite ses sources**. Côté API, cela a d'abord pris la forme de modèles « Sonar » (`sonar`, `sonar-pro`, `sonar-reasoning-pro`, `sonar-deep-research`) accessibles par un endpoint Chat Completions compatible OpenAI. Si vous avez suivi un tutoriel en 2025, c'est ce code que vous avez écrit.

**Depuis le 27 septembre 2026, ces Sonar Chat Completions ne sont plus supportés** ([page Migrate from Sonar](https://docs.perplexity.ai/docs/agent-api/migrate-from-sonar/overview.md)). Tout passe désormais par quatre produits :

| Produit | Ce qu'il fait | Quand l'utiliser |
|---|---|---|
| **Search API** | Renvoie des résultats web bruts (titre, URL, extrait, date) | Vous voulez contrôler la rédaction, alimenter votre propre RAG, ou simplement lister des sources |
| **Agent API** | Un modèle (OpenAI, Google, xAI, Anthropic, modèles Perplexity…) utilise des outils de recherche et répond **avec citations** | Vous voulez une réponse finale sourcée, comme dans l'application Perplexity |
| **Embeddings** | Vecteurs `pplx-embed-v1-*` | RAG maison (module M20) |
| **Decisions** | Petits modèles `pplx-decider-*` de classification / routage | Trier, étiqueter, décider à très bas coût |

La migration est balisée : la synchrone et le streaming sont reformulés vers l'Agent API, l'asynchrone Sonar n'existe plus (il est remplacé par le *background mode*), et chaque ancien modèle correspond à un **niveau d'effort** :

| Ancien modèle Sonar | Équivalent Agent API (`effort`) |
|---|---|
| `sonar` | `fast` |
| `sonar-pro` | `fast` |
| `sonar-reasoning-pro` | `low` |
| `sonar-deep-research` | `high` (ou `xhigh` pour la meilleure qualité) |

> 💡 **À retenir** — `perplexity/sonar` **existe toujours**, mais comme modèle *dans* l'Agent API (0,25 $/M tokens en entrée, 2,50 $/M en sortie, nov. 2026). Ce qui a disparu, c'est l'ancien endpoint Chat Completions, pas le modèle. Le titre de cette leçon garde le mot « Sonar » parce que c'est encore ainsi que vos clients nomment l'API Perplexity.

```
            SEARCH API                                 AGENT API
 question ─► moteur Perplexity            question ─► modèle routé (openai/…, google/…,
                  │                                    xai/…, perplexity/sonar…)
                  ▼                                    + outils web_search, fetch_url…
   liste de résultats (titre, URL,                          │
   extrait, date)                                           ▼
                  │                                réponse rédigée + citations
                  ▼                                (annotations, élément search_results)
   VOUS rédigez (Claude, Mistral, Gemini…)
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : depuis le 27 septembre 2026, le modèle `perplexity/sonar` n'existe plus.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. C'est l'ancien endpoint Sonar Chat Completions qui n'est plus supporté. `perplexity/sonar` reste disponible comme modèle de l'Agent API (0,25 $ / 2,50 $ par million de tokens, nov. 2026)."
}
```

## 2. Installation et clé

La clé est créée dans la console Perplexity (voir [Projets & facturation](https://docs.perplexity.ai/docs/getting-started/projects.md)) et lue depuis `PERPLEXITY_API_KEY`. Perplexity fournit un SDK officiel ([SDK overview](https://docs.perplexity.ai/docs/sdk/overview.md)) et une [compatibilité OpenAI](https://docs.perplexity.ai/docs/agent-api/openai-compatibility.md) pour l'Agent API. Dans cette leçon, nous utilisons le SDK OpenAI pour l'Agent API (vous l'avez déjà, et c'est le même format Responses qu'en L084) et des requêtes HTTP simples pour la Search API.

```bash
export PERPLEXITY_API_KEY="pplx-..."
pip install "openai>=2" httpx         # Python 3.12+
npm install openai                    # TypeScript
```

> ⚠️ **Piège fréquent** — La `base_url` de compatibilité OpenAI et les chemins exacts de la Search API sont fixés par la doc du moment ; les exemples ci-dessous utilisent `https://api.perplexity.ai/v1` pour l'Agent API (quickstart officiel, nov. 2026 : SDK OpenAI → `client.responses.create` ; point de terminaison canonique `POST /v1/agent`, alias `POST /v1/responses`) et `https://api.perplexity.ai/search` pour la Search API. Il existe aussi un SDK natif (`pip install perplexityai` / `npm install @perplexity-ai/perplexity_ai`), dont les exemples placent `effort` à la racine de la requête (la forme `reasoning={"effort": …}` utilisée ici reste à tester). Les citations se lisent dans `output[].content[].annotations[]` (`type: "citation"`, `url`) et dans l'élément `output` de type `search_results`. Avant de déployer, confirmez-les sur les pages [OpenAI compatibility](https://docs.perplexity.ai/docs/agent-api/openai-compatibility.md) et [Search quickstart](https://docs.perplexity.ai/docs/search/quickstart.md) : une API qui vient de changer de paradigme peut encore ajuster ses URL.

## 3. Search API : des résultats bruts que vous maîtrisez

La Search API est le « moteur » nu. Vous envoyez une requête, vous recevez une liste de résultats. C'est l'outil idéal quand vous construisez votre propre pipeline : vous récupérez les pages, vous les passez à Claude, Mistral ou Gemini, et vous gardez la main sur la rédaction.

```python
"""Search API Perplexity : liste de sources filtrées par domaine et par date (Python)."""
import os
import httpx

API_KEY = os.environ["PERPLEXITY_API_KEY"]

def rechercher(question: str, domaines: list[str] | None = None, rapide: bool = False) -> list[dict]:
    """Renvoie une liste de {title, url, snippet, date} ; `rapide` active Fast Search (1 $/1 000)."""
    payload: dict = {"query": question, "max_results": 8}
    if domaines:
        payload["search_domain_filter"] = domaines          # ex. ["legifrance.gouv.fr", "service-public.fr"]
    if rapide:
        payload["search_type"] = "fast"
    with httpx.Client(timeout=30) as client:
        r = client.post(
            "https://api.perplexity.ai/search",
            headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
            json=payload,
        )
        r.raise_for_status()
    return r.json().get("results", [])

if __name__ == "__main__":
    for res in rechercher(
        "délai de préavis démission CDI cadre",
        domaines=["service-public.fr", "legifrance.gouv.fr"],
    ):
        print(f"- {res.get('title')} — {res.get('url')} ({res.get('date', 'date inconnue')})")
```

Trois leviers à connaître (pages [Fast Search](https://docs.perplexity.ai/docs/search/fast-search.md) et [filtres](https://docs.perplexity.ai/docs/search/filters/domain-filter.md)) :

- **Filtre de domaine** : liste blanche (ou noire avec le préfixe `-`) de sites. Pour un assistant RH, restreindre à `service-public.fr`, `urssaf.fr` et `legifrance.gouv.fr` élimine 90 % des hallucinations de source.
- **Filtres de date et de langue** : indispensables pour une veille (« depuis 7 jours ») ou un public francophone.
- **Fast Search** (`search_type: "fast"`) : cinq fois moins cher (1 $/1 000 au lieu de 5 $/1 000), suffisant pour l'autocomplétion ou la vérification rapide d'un fait. Un appel peut porter jusqu'à **5 requêtes comptées pour une**.

```quiz
{
  "q": "Un cabinet RH veut obtenir une liste de sources officielles (service-public.fr, urssaf.fr) qu'il fera ensuite résumer par son propre modèle. Quel produit Perplexity utiliser ?",
  "options": [
    "La Search API, avec un filtre de domaine",
    "L'Agent API en effort `high`, qui rédige la synthèse",
    "L'API Embeddings, pour vectoriser les sites officiels",
    "L'API Decisions, pour trancher entre les sources"
  ],
  "answer": 0,
  "explanation": "La Search API renvoie des résultats bruts (titre, URL, extrait, date) et laisse la rédaction à votre pipeline ; le filtre de domaine garantit le périmètre."
}
```

## 4. Agent API : la réponse synthétisée avec citations

L'Agent API fait ce que fait l'application Perplexity : un modèle de votre choix appelle les outils `web_search`, `fetch_url`, `image_search`, `people_search`, `finance_search` ou un bac à sable (`sandbox`), puis rédige une réponse **avec citations**. Le format est celui des Responses OpenAI, et vous nommez le modèle avec un préfixe fournisseur.

```python
"""Agent API Perplexity via le SDK OpenAI : réponse citée pour un cabinet comptable."""
import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["PERPLEXITY_API_KEY"],
    base_url="https://api.perplexity.ai/v1",   # quickstart officiel (nov. 2026)
)

response = client.responses.create(
    model="openai/gpt-6.1-sol",            # modèle routé : 2 $/M in, 10 $/M out (nov. 2026)
    instructions=(
        "Vous êtes l'assistant d'un cabinet d'expertise comptable français. "
        "Répondez en français avec des citations numérotées [1], [2]… et ne citez que des sources officielles."
    ),
    input="Quel est le taux de TVA applicable aux travaux de rénovation énergétique en 2026 ?",
    tools=[{"type": "web_search", "search_domain_filter": ["impots.gouv.fr", "service-public.fr", "economie.gouv.fr"]}],
    reasoning={"effort": "low"},            # ex-sonar-reasoning-pro
)

print(response.output_text)

# Les citations sont rattachées aux annotations du message final
for item in response.output:
    if item.type == "message":
        for part in item.content:
            for ann in getattr(part, "annotations", []) or []:
                print("Source :", getattr(ann, "url", ann))
```

> 💡 **Autrement dit** — La réponse de l'Agent API ressemble à un article de presse : le texte contient des appels de note, et les références sont rangées à part. Concrètement, chaque citation est une *annotation* de type `citation` (avec son `url`) attachée au message, et un élément `output` de type `search_results` liste tout ce qui a été trouvé (`title`, `url`, `snippet`, `date`…). Dans le texte natif, les appels de note prennent la forme `[web:1]` : si vous ne demandez pas explicitement une numérotation `[1]`, adaptez l'expression régulière de la section 5 (par exemple `\[web:(\d+)\]`). Il n'y a pas de champ `citations` à la racine de la réponse.

```quiz
{
  "q": "Où lire les citations dans une réponse de l'Agent API ?",
  "options": [
    "Dans un champ `citations` à la racine de la réponse",
    "Dans les en-têtes HTTP renvoyés avec la réponse",
    "Dans les annotations du message et l'élément `search_results`",
    "Nulle part : il faut deviner les sources à partir du texte"
  ],
  "answer": 2,
  "explanation": "D'après le quickstart officiel (nov. 2026), les citations sont des annotations du message, complétées par un élément `search_results` ; aucun champ `citations` n'existe à la racine."
}
```

Le même appel en TypeScript, en streaming, avec les citations affichées au fil de l'eau (inspiré du [cookbook « streaming citations »](https://docs.perplexity.ai/docs/cookbook/articles/streaming-citations/README.md)) :

```typescript
// perplexity-stream.ts — npx tsx perplexity-stream.ts
import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.PERPLEXITY_API_KEY,
  baseURL: "https://api.perplexity.ai/v1", // quickstart officiel (nov. 2026)
});

async function main() {
  const stream = await client.responses.create({
    model: "google/gemini-3.8-flash", // 0,75 $/M in, 3,75 $/M out (nov. 2026)
    instructions: "Réponds en français, avec des citations [n] et une liste de sources à la fin.",
    input: "Quelles sont les dernières annonces sur la facturation électronique obligatoire en France ?",
    tools: [{ type: "web_search" }],
    reasoning: { effort: "fast" }, // ex-sonar / sonar-pro
    stream: true,
  });

  const sources: string[] = [];
  for await (const event of stream) {
    if (event.type === "response.output_text.delta") process.stdout.write(event.delta);
    // Les annotations (citations) arrivent dans des événements dédiés : on les collecte
    if (event.type === "response.output_text.annotation.added") {
      const url = (event as any).annotation?.url;
      if (url && !sources.includes(url)) sources.push(url);
    }
  }
  console.log("\n\nSources :");
  sources.forEach((s, i) => console.log(`[${i + 1}] ${s}`));
}

main().catch((e) => { console.error(e.message); process.exit(1); });
```

> 💡 **À retenir** — L'Agent API est **multi-fournisseur par construction** : `openai/gpt-6.1-sol`, `google/gemini-4-argon`, `xai/grok-4.7`, `anthropic/...` (qui exige `max_output_tokens`), `perplexity/sonar`, `perplexity/kimi-k3`, `perplexity/deepseek-v4-pro-0813`… Vous changez de cerveau en changeant une chaîne, et vous gardez les outils de recherche Perplexity. C'est un avant-goût de l'architecture multi-fournisseur de L088.

## 5. Afficher les citations : l'enjeu produit

Une réponse citée n'a de valeur que si l'utilisateur **peut cliquer**. Trois règles issues de l'expérience des assistants de recherche :

1. **Numérotez** les citations dans le texte (`[1]`, `[2]`) et listez les URL en bas, comme dans l'application Perplexity. Les utilisateurs français vérifient davantage quand le numéro est visible dans la phrase.
2. **Montrez le domaine** à côté du titre (« service-public.fr ») : la crédibilité perçue dépend de la source, pas du modèle.
3. **Conservez les citations en base** avec la réponse : en cas de litige (un conseil fiscal erroné), vous pouvez prouver ce que le modèle avait lu.

Dans un rendu Markdown, une fonction de post-traitement remplace `[n]` par un lien : `re.sub(r"\[(\d+)\]", lambda m: f"[[{m.group(1)}]]({sources[int(m.group(1))-1]})", texte)`.

## 6. Tarifs (nov. 2026) et calcul du coût d'une réponse

Source : [page Pricing](https://docs.perplexity.ai/getting-started/pricing) et [Agent API models](https://docs.perplexity.ai/docs/agent-api/models.md).

| Poste | Tarif |
|---|---|
| Search API | 5 $ / 1 000 requêtes réussies ; Fast Search 1 $ / 1 000 |
| Agent API — outil `web_search` | 2,50 $ / 1 000 (mode fast : 1 $ / 1 000) |
| Agent API — `image_search` | 2,50 $ / 1 000 |
| Agent API — `fetch_url` | 0,0005 $ par appel |
| Agent API — `people_search`, `finance_search` | 5 $ / 1 000 |
| Agent API — `sandbox` | 0,03 $ par session de 20 min |
| Tiers `flex` / `priority` (modèles OpenAI) | 0,5× / 2× sur les tokens |

| Modèle routé par l'Agent API (extrait) | Input / Output ($/M tokens) |
|---|---|
| `openai/gpt-6-astra` | 10 / 50 |
| `openai/gpt-6.1-sol` | 2 / 10 |
| `openai/gpt-6-luna` | 0,10 / 0,50 |
| `google/gemini-4-argon` (promo jusqu'au 30/11/2026) | 2 / 10 |
| `google/gemini-3.8-flash` | 0,75 / 3,75 |
| `xai/grok-4.7` | 2 / 6 |
| `perplexity/sonar` | 0,25 / 2,50 |
| `perplexity/glm-5.3` | 1,40 / 4,40 |
| `perplexity/deepseek-v4-pro-0813` | 1,32 / 3,96 |
| `perplexity/kimi-k3` | 3 / 15 |
| `perplexity/nemotron-3.5-super-120b-a12b` | 0,20 / 0,50 |

Embeddings : `pplx-embed-v1-0.6b` 0,004 $/M tokens, `pplx-embed-v1-4b` 0,03 $, versions « context » 0,008 $ et 0,05 $. Decisions : `pplx-decider-v1.2` 0,02 $/M en entrée (sortie gratuite), `pplx-decider-flash-v1.2` 0,01 $.

**Exemple chiffré.** Question TVA ci-dessus, `openai/gpt-6.1-sol`, deux recherches web, 6 k tokens lus (pages intégrées au contexte), 400 tokens produits : 2 × 0,0025 + 6 000 × 2 / 10⁶ + 400 × 10 / 10⁶ = 0,005 + 0,012 + 0,004 = **0,021 $**. Avec `perplexity/sonar` à la place : 0,005 + 0,0015 + 0,001 = **0,0075 $**. Pour un chatbot grand public à 50 000 questions par mois, la différence est de 675 $ mensuels : le choix du modèle routé est une décision financière.

🎮 **Défi** — Même question, mais vous passez `reasoning.effort` à `high` et vous retirez le filtre de domaine. Comptez les appels d'outils déclenchés et recalculez. Vous venez de mesurer, concrètement, ce que « deep research » coûte.

> 🔗 **Documentation officielle** — [Agent API effort](https://docs.perplexity.ai/docs/agent-api/effort.md), [Output control (sorties structurées)](https://docs.perplexity.ai/docs/agent-api/output-control.md), [Batch](https://docs.perplexity.ai/docs/agent-api/batch.md), [Rate limits & usage tiers](https://docs.perplexity.ai/docs/admin/rate-limits-usage-tiers.md).

## 7. Perplexity dans votre boîte à outils

| Besoin | Perplexity | Alternative vue dans la formation |
|---|---|---|
| Réponse sourcée prête à afficher | Agent API | Claude + web search (L072/L073), Grok `web_search` (L084), Gemini grounding (L087) |
| Liste de sources pour votre propre pipeline | Search API | Aucune équivalente aussi simple chez les autres fournisseurs |
| Restriction stricte aux sites officiels | Filtre de domaine | Possible chez certains, moins direct |
| Intégration sans code | Nœud n8n ([intégration n8n](https://docs.perplexity.ai/docs/getting-started/integrations/n8n.md)) et [serveur MCP](https://docs.perplexity.ai/docs/getting-started/integrations/mcp-server.md) | — |

Perplexity n'est pas un fournisseur de modèle comme les autres : c'est un **fournisseur de recherche** qui héberge des modèles. On l'appelle quand la question est « que dit le web, avec preuves ? », pas pour générer un courrier ou analyser un PDF interne.

```mission
{
  "title": "La base URL officielle de l'Agent API",
  "url": "https://docs.perplexity.ai/docs/getting-started/quickstart.md",
  "steps": [
    "Ouvrez le quickstart de la documentation Perplexity",
    "Cherchez l'exemple qui utilise le SDK OpenAI",
    "Relevez la base URL et le point de terminaison"
  ],
  "question": "Quelle base URL faut-il donner au SDK OpenAI pour l'Agent API, et quel est le point de terminaison canonique ?",
  "hint": "Attention au suffixe de version, souvent oublié dans les tutoriels.",
  "answer": "`https://api.perplexity.ai/v1` ; point de terminaison canonique `POST /v1/agent`, avec `POST /v1/responses` accepté comme alias (quickstart lu le 5/11/2026).",
  "xp": 20
}
```

```mission
{
  "title": "Migrer un ancien appel Sonar",
  "url": "https://docs.perplexity.ai/docs/agent-api/migrate-from-sonar/overview.md",
  "steps": [
    "Ouvrez la page Migrate from Sonar",
    "Repérez le tableau de correspondance entre anciens modèles et niveaux d'effort",
    "Lisez ce qui est dit du mode asynchrone"
  ],
  "question": "Quel niveau d'effort remplace `sonar-reasoning-pro`, et que devient le mode asynchrone de Sonar ?",
  "hint": "Le mode asynchrone a un nouveau nom dans l'Agent API.",
  "answer": "`low` ; l'asynchrone Sonar n'existe plus et il est remplacé par le background mode (fin du support des Sonar Chat Completions le 27/09/2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Créez `assistant_juridique.py` (ou `.ts`) pour un cabinet d'avocats en droit du travail : l'utilisateur pose une question, le programme (1) interroge la Search API avec un filtre `["legifrance.gouv.fr", "service-public.fr", "travail-emploi.gouv.fr"]`, (2) passe les 5 meilleurs résultats à l'Agent API (modèle `perplexity/sonar`, effort `fast`) en lui demandant une réponse en français citant **uniquement** ces sources, (3) affiche la réponse en Markdown avec les `[n]` transformés en liens, (4) journalise dans un fichier JSONL la question, la réponse, les sources et le coût estimé.

**Critères de réussite.**
1. Aucune source hors des trois domaines n'apparaît dans la réponse.
2. Chaque `[n]` du texte renvoie à une URL réellement renvoyée par la Search API.
3. Le coût est calculé avec les tarifs de la section 6 (Search 0,005 $ + tokens sonar).
4. Le programme résiste à une Search API vide (aucun résultat) en répondant « Je n'ai pas trouvé de source officielle ».

**Pistes de corrigé.** Pour l'étape 2, insérez les résultats dans `input` sous forme de liste numérotée (« [1] Titre — URL — extrait ») et dites dans `instructions` : « N'utilisez que les sources numérotées ci-dessous ; si elles ne suffisent pas, dites-le ». Vous pouvez alors **ne pas** passer d'outil `web_search` : vous économisez 2,50 $/1 000 et vous garantissez le périmètre. C'est la version « RAG web » que nous généraliserons en M20.

## ✅ Auto-évaluation express

1. Que s'est-il passé le 27 septembre 2026 pour les développeurs Perplexity ?
2. Quelle différence de prix entre une requête Search API standard et une requête Fast Search ?
3. Vous migrez un appel `sonar-deep-research` : quel `effort` choisissez-vous ?

**Réponses.** 1) Fin du support des Sonar Chat Completions ; migration vers l'Agent API (synchrone et streaming), background mode pour l'asynchrone. 2) 5 $/1 000 contre 1 $/1 000, soit un rapport 5. 3) `high` (ou `xhigh` si la qualité prime sur le coût).

## 📚 Pour aller plus loin
- [Perplexity — Agent API prompt guide](https://docs.perplexity.ai/docs/agent-api/prompt-guide.md) 🇬🇧 — comment rédiger des instructions qui produisent de bonnes citations.
- [Perplexity — Conversation state](https://docs.perplexity.ai/docs/agent-api/conversation-state.md) 🇬🇧 — enchaîner les tours sans renvoyer tout l'historique.
- [Perplexity — Embeddings quickstart](https://docs.perplexity.ai/docs/embeddings/quickstart.md) 🇬🇧 — préparer le RAG du module M20.
- [Perplexity — Decisions quickstart](https://docs.perplexity.ai/docs/decisions/quickstart.md) 🇬🇧 — classer et router à 0,01 $/M tokens.

> 🗺️ **Et maintenant ?** — Après la recherche citée, place à la souveraineté : la L086 présente Mistral, le fournisseur français, ses modèles ouverts et Codestral.
