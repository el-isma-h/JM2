---
id: L084
module: M19
level: N3
title: "xAI Grok API : compatibilité SDK, live search, vision"
minutes: 50
objectives:
  - "Appeler Grok 4.7 depuis Python et TypeScript avec le SDK OpenAI (base_url api.x.ai) ou le SDK xai-sdk, clé lue depuis l'environnement"
  - "Activer les outils serveur web_search et x_search pour obtenir des réponses ancrées dans l'actualité et les posts X"
  - "Produire des sorties structurées (JSON Schema) et analyser une image avec Grok"
  - "Estimer le coût d'un appel Grok (tokens, outils serveur, batch) à partir de la grille tarifaire officielle"
skills: ["C3.1", "C3.2"]
sources:
  - { title: "xAI — Quickstart", url: "https://docs.x.ai/developers/quickstart", lang: "en" }
  - { title: "xAI — Models", url: "https://docs.x.ai/developers/models", lang: "en" }
  - { title: "xAI — Pricing", url: "https://docs.x.ai/developers/pricing", lang: "en" }
  - { title: "xAI — Web search", url: "https://docs.x.ai/developers/tools/web-search", lang: "en" }
  - { title: "xAI — X search", url: "https://docs.x.ai/developers/tools/x-search", lang: "en" }
  - { title: "xAI — Structured outputs", url: "https://docs.x.ai/developers/model-capabilities/text/structured-outputs", lang: "en" }
  - { title: "xAI — Image understanding", url: "https://docs.x.ai/developers/model-capabilities/images/understanding", lang: "en" }
  - { title: "xAI — Batch API", url: "https://docs.x.ai/developers/advanced-api-usage/batch-api", lang: "en" }
  - { title: "xAI — Comparison / migration vers Responses", url: "https://docs.x.ai/developers/model-capabilities/text/comparison", lang: "en" }
---

# xAI Grok API : compatibilité SDK, live search, vision

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 19

## 🎯 Ce que vous saurez faire
- Obtenir une clé sur la console xAI, la stocker dans `XAI_API_KEY` et faire répondre `grok-4.7` en Python et en TypeScript **sans installer de nouveau SDK** (le SDK OpenAI suffit), ou avec `xai-sdk` si vous voulez les fonctions natives.
- Brancher les **outils serveur** `web_search` et `x_search` pour qu'une réponse cite ce qui s'est passé ce matin sur le web ou sur X, et comprendre ce que cela coûte.
- Demander du JSON conforme à un schéma, envoyer une photo de facture à analyser, et savoir quand passer par la **Batch API** pour économiser 20 %.
- Comparer Grok à Claude et GPT-6 sur ce qui le différencie vraiment : la fenêtre de 500 k tokens, l'accès natif à X, le tarif.

> 🧭 **En clair** — Grok est le modèle de l'entreprise xAI, et sa particularité tient en une lettre : X (ex-Twitter). C'est le seul à pouvoir fouiller officiellement les posts et profils X pour vous dire « ce qui se dit en ce moment », en plus du web. Bonne nouvelle pour le développeur : inutile d'apprendre une nouvelle façon de coder ; on garde le SDK OpenAI et l'on change l'adresse du guichet (la `base_url`) et la clé, comme un même chargeur branché sur une autre prise. Attention au compteur : au-delà de 200 000 tokens, le tarif double, et la recherche X se paie au nombre de posts lus.

## 1. Pourquoi un développeur français s'intéresse à Grok

Grok est le modèle de **xAI**, l'entreprise fondée par Elon Musk en 2023. Son histoire est inséparable de X (ex-Twitter) : c'est le seul modèle du marché qui dispose d'un **outil serveur officiel de recherche dans les posts et profils X**. Pour une PME qui fait de la veille (un fabricant de vélos électriques qui surveille ce que disent les cyclistes d'un nouveau modèle concurrent, un cabinet de communication qui suit une crise en direct), c'est un cas d'usage que ni Claude ni Gemini n'offrent de la même manière.

Trois faits à connaître avant d'écrire une ligne de code (nov. 2026, [page Models](https://docs.x.ai/developers/models)) :

1. Le modèle phare est **`grok-4.7`** (date de coupure des connaissances : mai 2026), avec une fenêtre de contexte de **500 k tokens** et un `reasoning_effort` configurable.
2. L'API est **compatible avec le SDK OpenAI** : vous pointez `base_url` vers `https://api.x.ai/v1` et le reste du code ne change pas. Les deux formats sont acceptés : **Responses** (recommandé) et **Chat Completions** (marqué « legacy » dans la doc).
3. La documentation a été réorganisée sous `docs.x.ai/developers/...` ; les anciens liens `docs.x.ai/docs/...` que vous trouverez sur les blogs de 2025 ne sont plus fiables.

> 💡 **À retenir** — « Live Search » est l'ancien nom marketing ; dans la doc actuelle, c'est l'outil agentique **`web_search`**, complété par **`x_search`**, `code_execution`, `collections_search` (RAG hébergé) et `remote_mcp`. Quand un recruteur ou un client parle de « live search Grok », il parle de ces outils serveur.

## 2. Premier appel : quatre chemins, un seul réflexe

La page [Quickstart](https://docs.x.ai/developers/quickstart) propose quatre options : Vercel AI SDK (`ai` + `@ai-sdk/xai`), SDK OpenAI JavaScript, SDK OpenAI Python, et `xai-sdk` (Python). Dans tous les cas, la clé est créée sur [console.x.ai](https://console.x.ai/team/default/api-keys) et lue depuis `XAI_API_KEY`.

```bash
# Clé API : jamais dans le code, jamais dans Git
export XAI_API_KEY="xai-..."          # Linux / macOS
# PowerShell : $env:XAI_API_KEY = "xai-..."

pip install "openai>=2" xai-sdk       # Python 3.12+
npm install openai                    # TypeScript / Node 20+
```

### 2.1 Python avec le SDK OpenAI (Responses API)

```python
"""Premier appel à Grok 4.7 via le SDK OpenAI (format Responses)."""
import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["XAI_API_KEY"],        # lève KeyError si la clé manque : volontaire
    base_url="https://api.x.ai/v1",
)

response = client.responses.create(
    model="grok-4.7",
    instructions="Vous êtes l'assistant d'une boulangerie-pâtisserie de Lille. Répondez en français, en 3 phrases maximum.",
    input="Propose-moi un slogan pour notre nouvelle galette des rois à la pistache.",
)

print(response.output_text)
print("Tokens :", response.usage.input_tokens, "in /", response.usage.output_tokens, "out")
```

Le format Responses renvoie un tableau `output` d'objets typés (message, raisonnement, appel d'outil) et l'aide `output_text` qui concatène le texte. Sur `grok-4.7`, la réponse contient toujours un bloc `reasoning.encrypted_content` : c'est le raisonnement chiffré, inutilisable en clair mais réinjectable au tour suivant pour conserver la chaîne de pensée.

### 2.2 TypeScript avec le SDK OpenAI, en streaming

```typescript
// grok-stream.ts — exécuter avec : npx tsx grok-stream.ts
import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.XAI_API_KEY, // undefined => erreur explicite à l'appel
  baseURL: "https://api.x.ai/v1",
});

async function main() {
  const stream = await client.responses.create({
    model: "grok-4.7",
    input: "Explique en 5 lignes ce qu'est une SCI à un artisan plombier.",
    stream: true,
  });

  // Chaque événement de streaming porte un type ; on n'affiche que les deltas de texte
  for await (const event of stream) {
    if (event.type === "response.output_text.delta") process.stdout.write(event.delta);
  }
  process.stdout.write("\n");
}

main().catch((err) => { console.error("Erreur xAI :", err.message); process.exit(1); });
```

### 2.3 Python avec `xai-sdk` (SDK natif)

Le SDK natif expose une API « conversation » légèrement différente, mais vous y gagnez l'accès direct aux outils serveur typés.

```python
"""Même appel avec le SDK natif xai-sdk (lit XAI_API_KEY automatiquement)."""
from xai_sdk import Client
from xai_sdk.chat import system, user

client = Client()                                   # clé via XAI_API_KEY
chat = client.chat.create(model="grok-4.7")
chat.append(system("Vous êtes un expert-comptable français, précis et concis."))
chat.append(user("Quelle est la différence entre un amortissement linéaire et dégressif ?"))

response = chat.sample()                            # un seul échantillon
print(response.content)
```

> ⚠️ **Piège fréquent** — Vous lisez sur un forum que Grok « est compatible avec le SDK Anthropic ». La doc actuelle (nov. 2026) **ne mentionne plus** cette compatibilité : ne bâtissez pas une architecture dessus. Le chemin supporté est le SDK OpenAI (Responses ou Chat Completions legacy), `xai-sdk` ou le Vercel AI SDK. La [page de comparaison](https://docs.x.ai/developers/model-capabilities/text/comparison) explique comment migrer de Chat Completions vers Responses.

```quiz
{
  "q": "Que faut-il changer dans un script écrit pour OpenAI pour qu'il interroge Grok ?",
  "options": [
    "Tout réécrire avec le SDK Anthropic",
    "Seulement le nom du modèle",
    "La `base_url`, la clé API et le nom du modèle",
    "Installer obligatoirement `xai-sdk` et abandonner le SDK OpenAI"
  ],
  "answer": 2,
  "explanation": "L'API xAI est compatible avec le SDK OpenAI (Responses et Chat Completions « legacy »). Le SDK natif `xai-sdk` est une option, pas une obligation."
}
```

## 3. Modèles et tarifs (nov. 2026)

Source : pages [Models](https://docs.x.ai/developers/models) et [Pricing](https://docs.x.ai/developers/pricing), en USD par million de tokens.

| Modèle | Contexte | Input | Input en cache | Output | Input / Output au-delà de 200 k | Usage conseillé |
|---|---|---|---|---|---|---|
| `grok-4.7` (phare) | 500 k | 2,00 | 0,50 | 6,00 | 4,00 / 12,00 | Agents, raisonnement, veille X |
| `grok-4.6` (12 août 2026) | 500 k | 2,00 | 0,50 | 6,00 | 4,00 / 12,00 | Même usage, génération précédente |
| `grok-4.5` | 500 k | 2,00 | 0,30 | 6,00 | 4,00 / 12,00 | Compatibilité descendante |
| `grok-build-0.1` (alias `grok-code-fast-1`) | 256 k | 1,00 | 0,20 | 2,00 | 2,00 / 4,00 | Code, agents de développement |
| `grok-4.3` | 1 M | 1,25 | 0,20 | 2,50 | 2,50 / 5,00 | Documents très longs à petit prix |
| `grok-4.20` | 1 M | 1,25 | 0,20 | 2,50 | 2,50 / 5,00 | idem |

Et ce qui s'ajoute aux tokens :

| Poste | Tarif (nov. 2026) |
|---|---|
| Outil `web_search` | 5 $ / 1 000 appels |
| Outil `x_search` | 5 $ / 1 000 posts lus (posts parents et cités compris), 10 $ / 1 000 profils |
| `code_execution` | 5 $ / 1 000 |
| `collections_search` (RAG hébergé) | 2,50 $ / 1 000 |
| Batch API | −20 % sur grok-4.7 / 4.6 / 4.5 / 4.3 / 4.20, hors rate limits |
| Priority | ×2 ; endpoint régional US ×1,1 |
| Images `grok-imagine-image-2.0` | 0,04 à 0,08 $ par image |

**Lecture rapide** : à 2 $/6 $, `grok-4.7` se place exactement au niveau de Claude Sonnet 5.5 (2 $/10 $ en sortie, voir `_recherche/01`) et de `gpt-6.1-sol` (2 $/10 $). Sa sortie est donc 40 % moins chère que ces deux concurrents, mais la **marche tarifaire au-delà de 200 k tokens** double le prix : un contexte de 500 k n'est pas « gratuit ».

> 💡 **Autrement dit** — Grok vend la sortie moins cher que ses concurrents, mais son tarif fonctionne avec un palier : tant que la requête reste sous 200 000 tokens, prix normal ; au-dessus, toute la requête passe au double. Mieux vaut découper un gros dossier que remplir la fenêtre de 500 000 tokens.

> 💡 **À retenir** — Un appel qui lit 50 k tokens de contexte, produit 1 k tokens et déclenche deux recherches web coûte : 50 000 × 2 / 1 000 000 + 1 000 × 6 / 1 000 000 + 2 × 5 / 1 000 = 0,10 + 0,006 + 0,01 ≈ **0,116 $**. Les outils serveur pèsent vite plus lourd que les tokens sur les petites requêtes.

## 4. Live search : `web_search` et `x_search`

C'est le cas d'usage différenciant. Vous ne décrivez pas l'outil (comme en function calling) : vous **déclarez** un outil serveur, et le modèle décide lui-même quand chercher, combien de fois, puis synthétise.

```python
"""Veille : que disent le web et X d'un sujet, ce matin ? (outils serveur xAI)."""
import os
from openai import OpenAI

client = OpenAI(api_key=os.environ["XAI_API_KEY"], base_url="https://api.x.ai/v1")

response = client.responses.create(
    model="grok-4.7",
    instructions=(
        "Vous êtes l'analyste veille d'un fabricant de vélos électriques à Saint-Étienne. "
        "Répondez en français, citez vos sources (URL ou identifiant de post) et datez chaque information."
    ),
    input="Quelles sont les réactions des cyclistes aux nouvelles aides à l'achat de vélos électriques annoncées cette semaine ?",
    tools=[
        {"type": "web_search"},   # recherche web agentique (ex-« Live Search »)
        {"type": "x_search"},     # recherche dans les posts et profils X
    ],
)

print(response.output_text)

# Trace des appels d'outils : combien de recherches ont été facturées ?
for item in response.output:
    if item.type not in ("message", "reasoning"):
        print("Outil déclenché :", item.type)
```

Quelques règles pratiques tirées de la [doc web_search](https://docs.x.ai/developers/tools/web-search) et de la [doc x_search](https://docs.x.ai/developers/tools/x-search) :

- Demandez explicitement **sources et dates** dans `instructions` : le modèle cite alors les URL et les posts qu'il a lus.
- Contrôlez le budget : chaque appel `web_search` est facturé (5 $/1 000), `x_search` l'est **par post renvoyé** (5 $/1 000 posts, posts parents et cités compris) et par profil (10 $/1 000), et un prompt vague peut déclencher plusieurs recherches. Le [suivi des coûts](https://docs.x.ai/developers/cost-tracking) dans la console vous montre la ventilation tokens / outils.
- Pour une veille récurrente, combinez avec la Batch API (section 6) : les outils serveur y restent disponibles.

🎮 **Défi** — Reprenez le script ci-dessus et remplacez la question par « Quelle est la météo prévue demain à Lille ? ». Observez : le modèle déclenche-t-il `x_search` ? Pourquoi est-ce un gaspillage, et comment l'éviter (indice : retirez l'outil de la liste ou précisez dans `instructions` de ne pas consulter X pour les questions factuelles) ?

```quiz
{
  "q": "Une requête de veille sur `grok-4.7` déclenche 3 appels `x_search` qui renvoient 40 posts au total. Combien coûte la partie `x_search` (nov. 2026) ?",
  "options": [
    "0,015 $ (3 appels × 0,005 $)",
    "0,20 $ (40 posts × 0,005 $)",
    "0,40 $ (40 posts × 0,01 $)",
    "Rien : les outils serveur sont inclus dans les tokens"
  ],
  "answer": 1,
  "explanation": "`x_search` est facturé à l'élément renvoyé : 5 $ / 1 000 posts (posts parents et cités compris), 10 $ / 1 000 profils. Le nombre d'appels ne compte pas."
}
```

## 5. Sorties structurées et vision

### 5.1 JSON conforme à un schéma

Comme chez OpenAI, le format Responses accepte `text.format` de type `json_schema`. Le SDK Python propose `responses.parse()` avec un modèle Pydantic, ce qui évite d'écrire le schéma à la main ([doc structured outputs](https://docs.x.ai/developers/model-capabilities/text/structured-outputs)).

```python
"""Extraction structurée d'un avis client en JSON validé (Pydantic + Grok)."""
import os
from pydantic import BaseModel
from openai import OpenAI

class AvisClient(BaseModel):
    note_sur_5: int
    sentiment: str            # "positif" | "neutre" | "negatif"
    produits_cites: list[str]
    demande_action: bool

client = OpenAI(api_key=os.environ["XAI_API_KEY"], base_url="https://api.x.ai/v1")

avis = ("Livraison rapide, le VTT électrique Alpin 2 est top mais la sacoche était rayée. "
        "J'aimerais un geste commercial.")

result = client.responses.parse(
    model="grok-4.7",
    instructions="Extrayez les informations de l'avis client. Ne rien inventer.",
    input=avis,
    text_format=AvisClient,
)
avis_structure: AvisClient = result.output_parsed
print(avis_structure.model_dump())
# {'note_sur_5': 4, 'sentiment': 'positif', 'produits_cites': ['VTT électrique Alpin 2', 'sacoche'], 'demande_action': True}
```

### 5.2 Comprendre une image

Grok accepte des images **JPG ou PNG jusqu'à 20 MiB**, par URL ou en base64 ([doc image understanding](https://docs.x.ai/developers/model-capabilities/images/understanding)). Le format est celui des Responses OpenAI : un `input_image` à côté d'un `input_text`.

```typescript
// facture-vision.ts — lit une facture scannée et en extrait les montants
import OpenAI from "openai";
import { readFileSync } from "node:fs";

const client = new OpenAI({ apiKey: process.env.XAI_API_KEY, baseURL: "https://api.x.ai/v1" });

async function lireFacture(chemin: string) {
  const base64 = readFileSync(chemin).toString("base64");
  const response = await client.responses.create({
    model: "grok-4.7",
    input: [
      {
        role: "user",
        content: [
          { type: "input_text", text: "Donne le fournisseur, la date, le total HT, la TVA et le total TTC de cette facture, en JSON." },
          { type: "input_image", image_url: `data:image/jpeg;base64,${base64}`, detail: "high" },
        ],
      },
    ],
  });
  return response.output_text;
}

lireFacture("./facture-fournisseur.jpg").then(console.log).catch(console.error);
```

> ⚠️ **Piège fréquent** — `logprobs` n'est **plus supporté** depuis `grok-4.20` : si vous portez du code OpenAI qui lit `logprobs` pour mesurer la confiance, l'appel échoue. Remplacez par une sortie structurée avec un champ `confiance` ou par un second appel « juge ».

## 6. Batch API : −20 % quand vous pouvez attendre

Pour classer 10 000 avis clients ou résumer un mois de tickets, vous n'avez pas besoin d'une réponse en 2 secondes. La [Batch API](https://docs.x.ai/developers/advanced-api-usage/batch-api) traite un fichier de requêtes de manière asynchrone, **hors des rate limits** standard, avec une remise de 20 % sur les modèles grok-4.x. Le principe est identique à celui des lots Anthropic (L073) et OpenAI : vous soumettez un lot, vous interrogez son statut, vous récupérez un fichier de résultats. Consultez la page officielle pour le format exact du fichier (format JSONL par requête, à vérifier sur la page au moment de l'implémentation).

## 7. Grok face à Claude et GPT-6 : quand le choisir ?

| Critère | Grok 4.7 | Claude Sonnet 5.5 | GPT-6.1 Sol |
|---|---|---|---|
| Prix in/out ($/M tokens, nov. 2026) | 2 / 6 | 2 / 10 | 2 / 10 |
| Contexte | 500 k (tarif doublé > 200 k) | 1 M | 1,05 M |
| Recherche X native | **Oui** (`x_search`) | Non | Non |
| Recherche web serveur | 5 $/1 000 | 10 $/1 000 | 10 $/1 000 |
| Compatibilité SDK | OpenAI, xai-sdk, Vercel AI SDK | Anthropic (+ compat OpenAI) | OpenAI |
| Résidence des données | Endpoint régional US documenté (×1,1) ; options européennes à vérifier sur la page officielle | Options de résidence (`inference_geo`, voir L068) | Options de résidence |

**Choisissez Grok** pour la veille sociale, les tableaux de bord d'actualité, les agents qui ont besoin de « ce qui se dit maintenant », ou simplement comme fournisseur de repli bon marché en sortie. **Évitez-le** comme fournisseur unique pour des données réglementées européennes sans analyse préalable (nous verrons en L086 l'argument de souveraineté de Mistral, et en L088 comment combiner plusieurs fournisseurs).

> 🔗 **Documentation officielle** — [Tools overview](https://docs.x.ai/developers/tools/overview), [Rate limits](https://docs.x.ai/developers/rate-limits), [Debugging](https://docs.x.ai/developers/debugging).

```mission
{
  "title": "Comment x_search est-il facturé ?",
  "url": "https://docs.x.ai/developers/pricing",
  "steps": [
    "Ouvrez la page Pricing de la documentation xAI",
    "Descendez jusqu'aux outils serveur (server-side tools)",
    "Comparez la facturation de x_search et celle de web_search"
  ],
  "question": "`x_search` est-il facturé à l'appel ou à l'élément renvoyé ? Donnez ses tarifs et ceux des autres outils serveur.",
  "hint": "Cherchez la phrase « billed per item fetched ».",
  "answer": "À l'élément : 5 $ / 1 000 posts (posts parents et cités compris) et 10 $ / 1 000 profils. `web_search`, `code_execution` et `attachment_search` : 5 $ / 1 000 appels ; `collections_search` : 2,50 $ / 1 000 (page lue le 5/11/2026) (vérifié le 5 nov. 2026).",
  "xp": 20
}
```

```mission
{
  "title": "Les images acceptées par Grok",
  "url": "https://docs.x.ai/developers/model-capabilities/images/understanding",
  "steps": [
    "Ouvrez la page Image understanding",
    "Cherchez les formats supportés et les limites de taille",
    "Notez aussi les deux façons de transmettre l'image"
  ],
  "question": "Quels formats d'image et quelle taille maximale Grok accepte-t-il, et comment peut-on lui envoyer l'image ?",
  "hint": "La section 5.2 de la leçon cite ces limites : vérifiez-les.",
  "answer": "JPG et PNG, jusqu'à 20 MiB par image, par URL ou en base64 (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Construisez `veille_x.py` (ou `.ts`) pour un cabinet de conseil RH : l'utilisateur saisit un mot-clé (ex. « télétravail obligatoire »), le programme interroge `grok-4.7` avec `web_search` et `x_search`, puis renvoie un JSON structuré `{ "resume": str, "sources": [ { "url_ou_post": str, "date": str } ], "tonalite_globale": "positive"|"neutre"|"negative" }` validé par Pydantic ou Zod. Affichez ensuite une **estimation du coût** de l'appel à partir de `usage` et du nombre d'outils déclenchés.

**Critères de réussite.**
1. La clé provient de `XAI_API_KEY` ; le programme échoue proprement si elle manque.
2. Le JSON est validé (aucune clé manquante, tonalité dans l'énumération).
3. Au moins une source datée apparaît pour une requête d'actualité.
4. Le coût affiché respecte la grille : 2 $/M in, 6 $/M out, 5 $/1 000 appels `web_search`, 5 $/1 000 posts renvoyés par `x_search`.

**Pistes de corrigé.** Combinez les sections 4 et 5.1 : passez `tools=[...]` **et** `text_format=...` dans le même `responses.parse`. Comptez les outils avec `sum(1 for item in response.output if item.type not in ("message", "reasoning"))`. Pour le coût : `cout = usage.input_tokens * 2e-6 + usage.output_tokens * 6e-6 + nb_outils * 0.005`. Attention : cette formule ne vaut que pour `web_search` ; `x_search` se facture au nombre de posts renvoyés (ajoutez `nb_posts * 0.005`), pas au nombre d'appels.

## ✅ Auto-évaluation express

1. Quelle `base_url` et quelle variable d'environnement faut-il pour utiliser Grok avec le SDK OpenAI ?
2. Un appel lit 300 k tokens d'entrée : quel tarif s'applique sur `grok-4.7` ?
3. Qu'est-ce qui distingue un outil serveur comme `x_search` d'une fonction déclarée en function calling ?

**Réponses.** 1) `https://api.x.ai/v1` et `XAI_API_KEY`. 2) Le tarif « au-delà de 200 k » : 4 $/M en entrée (12 $/M en sortie) sur toute la requête, d'où l'intérêt de découper. 3) L'outil serveur est exécuté **côté xAI** (le modèle cherche lui-même, vous ne codez rien, vous payez 5 $/1 000 posts renvoyés pour `x_search`, 5 $/1 000 appels pour `web_search`) ; une fonction en function calling est exécutée **par votre code** après que le modèle en a demandé l'appel.

## 📚 Pour aller plus loin
- [xAI — Cookbook](https://docs.x.ai/cookbook) 🇬🇧 — exemples complets (agents, outils, multi-agent).
- [xAI — Function calling](https://docs.x.ai/developers/tools/function-calling) 🇬🇧 — pour mélanger vos propres outils avec `web_search`.
- [xAI — Reasoning](https://docs.x.ai/developers/model-capabilities/text/reasoning) 🇬🇧 — régler `reasoning_effort` selon le coût et la latence.
- [xAI — Collections search](https://docs.x.ai/developers/tools/collections-search) 🇬🇧 — RAG hébergé par xAI, utile avant le module M20.

> 🗺️ **Et maintenant ?** — Grok cherche dans X ; Perplexity, en L085, s'est spécialisé dans la recherche web avec des citations vérifiables.
