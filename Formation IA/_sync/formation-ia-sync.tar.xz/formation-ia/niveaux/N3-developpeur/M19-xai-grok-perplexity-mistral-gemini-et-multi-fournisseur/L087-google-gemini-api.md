---
id: L087
module: M19
level: N3
title: "Google Gemini API"
minutes: 50
objectives:
  - "Appeler Gemini 4 Argon et Gemini 3.8 Flash avec le SDK google-genai (Python) et @google/genai (TypeScript), clé lue depuis GEMINI_API_KEY, avec streaming"
  - "Exploiter le multimodal natif (PDF, images, audio, vidéo via la Files API) et le contexte d'un million de tokens avec le context caching"
  - "Ancrer une réponse avec Google Search (grounding) et produire des sorties structurées validées par un schéma"
  - "Anticiper les hausses de tarifs annoncées (1er déc. 2026 et 1er janv. 2027) dans le calcul du coût d'une application"
skills: ["C3.1", "C3.2"]
sources:
  - { title: "Gemini API — Models", url: "https://ai.google.dev/gemini-api/docs/models", lang: "en" }
  - { title: "Gemini API — Gemini 3.8 Flash", url: "https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash", lang: "en" }
  - { title: "Gemini API — Pricing", url: "https://ai.google.dev/gemini-api/docs/pricing", lang: "en" }
  - { title: "Gemini API — Get started", url: "https://ai.google.dev/gemini-api/docs/get-started", lang: "en" }
  - { title: "Gemini API — Text generation", url: "https://ai.google.dev/gemini-api/docs/text-generation", lang: "en" }
  - { title: "Gemini API — Files API", url: "https://ai.google.dev/gemini-api/docs/files", lang: "en" }
  - { title: "Gemini API — Context caching", url: "https://ai.google.dev/gemini-api/docs/caching", lang: "en" }
  - { title: "Gemini API — Grounding with Google Search", url: "https://ai.google.dev/gemini-api/docs/google-search", lang: "en" }
  - { title: "Gemini API — Structured output", url: "https://ai.google.dev/gemini-api/docs/structured-output", lang: "en" }
  - { title: "Gemini CLI — quotas et tarifs", url: "https://geminicli.com/docs/resources/quota-and-pricing", lang: "en" }
---

# Google Gemini API

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 19

## 🎯 Ce que vous saurez faire
- Installer `google-genai` (Python) ou `@google/genai` (TypeScript), lire la clé depuis `GEMINI_API_KEY` et obtenir une réponse de `gemini-3.8-flash` en streaming.
- Envoyer un PDF de 300 pages, une heure d'audio ou une vidéo via la **Files API**, et ne payer qu'une fois le contexte grâce au **context caching**.
- Activer le **grounding Google Search** pour une réponse ancrée dans le web, et obtenir un JSON validé par schéma.
- Expliquer la grille tarifaire, ses hausses programmées, et quand Gemini CLI vaut mieux que l'API.

> 🧭 **En clair** — Gemini, le modèle de Google, a été conçu pour tout avaler : texte, images, PDF, audio et vidéo entrent par la même porte, et sa fenêtre peut contenir un million de tokens, soit plusieurs gros livres. C'est l'outil idéal pour faire analyser un dossier de 800 pages ou l'enregistrement d'une réunion en un seul appel. Mais remplir une si grande valise coûte cher à chaque voyage : le *context caching* permet de laisser la valise à la consigne et de ne payer ensuite que les nouvelles questions. Attention enfin au compteur : la « réflexion » du modèle est facturée comme du texte produit, et les prix doublent au 1er décembre 2026 (Argon) et au 1er janvier 2027 (Flash).

## 1. Pourquoi Gemini est le « multimodal long contexte » de la bande

Gemini est la famille de modèles de Google DeepMind, née en décembre 2023 et conçue dès l'origine comme **nativement multimodale** : texte, image, audio, vidéo et PDF entrent dans la même fenêtre de contexte, sans module de conversion séparé. Deux chiffres résument sa place dans ce module (nov. 2026, [page Models](https://ai.google.dev/gemini-api/docs/models)) :

- **`gemini-4-argon`**, le modèle phare : raisonnement, contexte unifié de **1 million de tokens**.
- **`gemini-3.8-flash`**, le cheval de trait : **1 048 576 tokens** en entrée, **65 536** en sortie ; texte, image, vidéo, audio, PDF ; function calling, sorties structurées, Google Search, Google Maps, exécution de code, *computer use*, file search, URL context, caching, modes de réflexion `low` / `medium` / `high`, et un **free tier**.

Pour un développeur, le cas d'usage différenciant est clair : **analyser des documents volumineux et des médias** (un dossier d'appel d'offres de 800 pages, l'enregistrement d'un conseil municipal de deux heures, les photos d'un chantier) dans **un seul appel**, à un prix Flash.

> 💡 **À retenir** — Le « million de tokens » est aussi un piège budgétaire : à 0,75 $/M, remplir le contexte coûte 0,75 $ **par appel**. Le context caching (section 4) et la Batch API (0,5×) existent précisément pour cela.

## 2. Premier appel : Python et TypeScript

La clé se crée dans Google AI Studio (lien depuis la page [Get started](https://ai.google.dev/gemini-api/docs/get-started)) et se lit depuis `GEMINI_API_KEY`, que les SDK détectent automatiquement.

```bash
export GEMINI_API_KEY="AIza..."
pip install google-genai            # SDK Python unifié (remplace google-generativeai)
npm install @google/genai           # SDK TypeScript unifié
```

### 2.1 Python, en streaming

```python
"""Gemini 3.8 Flash en streaming : réponse d'un office de tourisme breton."""
import os
from google import genai
from google.genai import types

client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])   # ou genai.Client() : lit la variable

stream = client.models.generate_content_stream(
    model="gemini-3.8-flash",
    contents="Propose un programme de 2 jours à Saint-Malo pour une famille avec deux enfants, hors saison.",
    config=types.GenerateContentConfig(
        system_instruction="Vous êtes l'office de tourisme de Saint-Malo. Français, ton accueillant, listes courtes.",
        thinking_config=types.ThinkingConfig(thinking_level="low"),  # réflexion minimale : moins cher, plus rapide
        max_output_tokens=800,
    ),
)
for chunk in stream:
    if chunk.text:
        print(chunk.text, end="", flush=True)
print()
```

### 2.2 TypeScript, hors streaming, avec `usageMetadata`

```typescript
// gemini-hello.ts — npx tsx gemini-hello.ts
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function main() {
  const response = await ai.models.generateContent({
    model: "gemini-3.8-flash",
    contents: "Rédige en 3 phrases une annonce de recrutement pour un apprenti boulanger à Rennes.",
    config: { systemInstruction: "Français, ton professionnel, sans emoji." },
  });
  console.log(response.text);

  // Comptage pour le calcul du coût : 0,75 $/M in, 3,75 $/M out, tokens de réflexion inclus au tarif de sortie (nov. 2026)
  const u = response.usageMetadata!;
  const cout = (u.promptTokenCount! * 0.75 + u.candidatesTokenCount! * 3.75 + (u.thoughtsTokenCount ?? 0) * 3.75) / 1_000_000;
  console.log(`Tokens : ${u.promptTokenCount} in / ${u.candidatesTokenCount} out — coût ≈ ${cout.toFixed(6)} $`);
}

main().catch((e) => { console.error(e.message); process.exit(1); });
```

> ⚠️ **Piège fréquent** — Les tutoriels de 2024-2025 utilisent `import google.generativeai as genai` et `genai.GenerativeModel(...)`. C'est l'**ancien** SDK. Le SDK actuel est `google-genai` (`from google import genai`, `client.models.generate_content`). Les deux coexistent sur PyPI, et mélanger les deux produit des erreurs incompréhensibles.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : les tokens de réflexion de Gemini (`thoughtsTokenCount`) ne sont pas facturés.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. La page Pricing indique « Output price (including thinking tokens) » : la réflexion est facturée au tarif de sortie. C'est pourquoi le calcul de `gemini-hello.ts` additionne `thoughtsTokenCount` aux tokens de sortie, et pourquoi `thinking_level=\"low\"` fait baisser la facture."
}
```

## 3. Multimodal : PDF, images, audio, vidéo

Pour les petits fichiers, vous passez les octets en ligne. Au-delà de quelques mégaoctets, ou pour réutiliser un fichier dans plusieurs appels, vous l'envoyez d'abord à la [Files API](https://ai.google.dev/gemini-api/docs/files), qui renvoie une référence.

```python
"""Analyse d'un dossier d'appel d'offres en PDF et d'un enregistrement audio de réunion, dans un seul appel."""
import os
from google import genai

client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])

# 1) Téléversement (la Files API conserve les fichiers temporairement ; vérifiez la durée sur la page officielle)
dossier = client.files.upload(file="appel-offres-mairie.pdf")
reunion = client.files.upload(file="reunion-comite-2026-10-28.mp3")

# 2) Un seul prompt, plusieurs médias
response = client.models.generate_content(
    model="gemini-3.8-flash",
    contents=[
        dossier,
        reunion,
        "Vous êtes le chargé d'affaires d'une PME de BTP. "
        "1) Résumez les exigences du dossier en 10 points. "
        "2) Listez les décisions prises en réunion qui concernent ce dossier, avec l'horodatage approximatif. "
        "3) Signalez toute contradiction entre le dossier et la réunion.",
    ],
)
print(response.text)
print("Tokens consommés :", response.usage_metadata.prompt_token_count)
```

Quelques repères pratiques tirés de la [fiche Gemini 3.8 Flash](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash) : une page de PDF, une image, une seconde de vidéo ou d'audio se traduisent chacune en un nombre fixe de tokens (consultez la fiche pour les valeurs courantes) ; c'est ce qui permet d'estimer le coût **avant** l'appel. Une vidéo d'une heure peut consommer plusieurs centaines de milliers de tokens : utilisez les modes basse résolution ou découpez.

## 4. Contexte long et context caching

Quand le même gros document sert à dix questions, vous ne voulez pas payer dix fois son envoi. Le [context caching](https://ai.google.dev/gemini-api/docs/caching) stocke le contexte côté Google ; les appels suivants ne paient que les nouveaux tokens (plus un coût de stockage horaire, voir la page Pricing).

```
 Sans cache :  [Q1 + PDF 400 p.]  [Q2 + PDF 400 p.]  [Q3 + PDF 400 p.]   → le PDF est payé 3 fois

 Avec cache :  ┌────────────────────────────────────────────┐
               │ PDF 400 p. stocké chez Google (TTL 1 h,     │
               │ coût de stockage horaire)                   │
               └───────▲───────────▲───────────▲─────────────┘
                       Q1          Q2          Q3    → chaque question paie ses tokens
                                                       + la lecture du cache (tarif réduit)
```

```python
"""Context caching : un manuel technique de 400 pages chargé une fois, interrogé plusieurs fois."""
import os
from google import genai
from google.genai import types

client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
manuel = client.files.upload(file="manuel-chaudiere-industrielle.pdf")

cache = client.caches.create(
    model="gemini-3.8-flash",
    config=types.CreateCachedContentConfig(
        contents=[manuel],
        system_instruction="Vous êtes le support technique de niveau 2. Répondez en citant la section du manuel.",
        ttl="3600s",                     # durée de vie du cache : 1 h
    ),
)

questions = [
    "Quelle est la procédure de purge avant redémarrage ?",
    "Quel est le couple de serrage des brides du circuit primaire ?",
    "Quels codes d'erreur imposent un arrêt immédiat ?",
]
for q in questions:
    r = client.models.generate_content(
        model="gemini-3.8-flash",
        contents=q,
        config=types.GenerateContentConfig(cached_content=cache.name),
    )
    print(f"\nQ : {q}\nR : {r.text[:300]}…")
    print("Tokens lus depuis le cache :", r.usage_metadata.cached_content_token_count)

client.caches.delete(name=cache.name)   # libérer le stockage dès que possible
```

🎮 **Défi** — Comparez `prompt_token_count` et `cached_content_token_count` sur la deuxième question. Puis calculez combien vous auriez payé sans cache en renvoyant le PDF trois fois. La différence est votre argument pour convaincre votre responsable d'implémenter le cache.

```quiz
{
  "q": "Dans quel cas le context caching est-il le plus rentable ?",
  "options": [
    "Un seul appel sur un texte de deux pages",
    "Le même gros document interrogé de nombreuses fois",
    "Des documents tous différents à chaque appel",
    "Une conversation sans aucun document joint"
  ],
  "answer": 1,
  "explanation": "Le cache évite de repayer un gros contexte identique. Il a un coût de stockage horaire : il ne se rentabilise que si le même contenu sert plusieurs fois avant expiration."
}
```

## 5. Grounding Google Search et sorties structurées

### 5.1 Réponses ancrées dans le web

Le [grounding Google Search](https://ai.google.dev/gemini-api/docs/google-search) est l'équivalent chez Google du `web_search` de Grok ou de l'Agent API Perplexity : vous déclarez l'outil, le modèle décide de chercher, et la réponse revient avec des **métadonnées de grounding** (sources, extraits). Tarif (nov. 2026) : **5 000 requêtes gratuites par mois**, puis 14 $/1 000.

```python
"""Grounding : prix de l'électricité pour les professionnels, avec sources Google Search."""
import os
from google import genai
from google.genai import types

client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
response = client.models.generate_content(
    model="gemini-3.8-flash",
    contents="Quelles sont les dernières évolutions du tarif réglementé de l'électricité pour les TPE en France ?",
    config=types.GenerateContentConfig(tools=[types.Tool(google_search=types.GoogleSearch())]),
)
print(response.text)

meta = response.candidates[0].grounding_metadata
if meta and meta.grounding_chunks:
    print("\nSources :")
    for chunk in meta.grounding_chunks:
        if chunk.web:
            print("-", chunk.web.title, "—", chunk.web.uri)
```

### 5.2 JSON conforme à un schéma

La [sortie structurée](https://ai.google.dev/gemini-api/docs/structured-output) accepte directement une classe Pydantic (Python) ou un schéma JSON (TypeScript).

```typescript
// gemini-structured.ts — extraction d'un ticket de support en JSON typé
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function main() {
  const response = await ai.models.generateContent({
    model: "gemini-3.8-flash",
    contents: "Bonjour, ma box fibre clignote rouge depuis ce matin à Toulouse, j'ai déjà redémarré deux fois. Client n° 48213.",
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          numero_client: { type: Type.STRING },
          ville: { type: Type.STRING },
          categorie: { type: Type.STRING, enum: ["panne", "facturation", "commercial", "autre"] },
          urgence: { type: Type.INTEGER, description: "1 (faible) à 5 (critique)" },
          actions_deja_tentees: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["numero_client", "categorie", "urgence"],
      },
    },
  });
  console.log(JSON.parse(response.text!));
}

main().catch((e) => { console.error(e.message); process.exit(1); });
```

> 🔗 **Documentation officielle** — [Function calling](https://ai.google.dev/gemini-api/docs/function-calling), [Batch API](https://ai.google.dev/gemini-api/docs/batch-api), [Live API](https://ai.google.dev/gemini-api/docs/live-api) (audio bidirectionnel temps réel), [Embeddings](https://ai.google.dev/gemini-api/docs/embeddings).

## 6. Tarifs (nov. 2026) et hausses annoncées

Source : [page Pricing](https://ai.google.dev/gemini-api/docs/pricing), USD par million de tokens, tier Standard. La flèche « → » indique la **hausse annoncée** : au 1er décembre 2026 pour Argon, au 1er janvier 2027 pour les autres.

| Modèle | Input | Output | Free tier | Remarques |
|---|---|---|---|---|
| `gemini-4-argon` | 2,00 → 4,00 | 10,00 → 20,00 | Non | Phare, raisonnement |
| `gemini-3.8-flash` | 0,75 → 1,50 | 3,75 → 7,50 | Oui | Cheval de trait multimodal |
| `gemini-3.6-flash` | 0,75 → 1,50 | 3,75 → 7,50 | Oui | Génération précédente |
| `gemini-3.5-flash-lite` | 0,30 | 2,50 | — | Volume, classification |
| `gemini-3.1-flash-lite` | 0,25 | 1,50 | — | Le moins cher |
| `gemini-3.1-pro-preview` | 2,00 (≤ 200 k) | 12,00 | — | Preview |

Modificateurs : **Batch et Flex ≈ 0,5×**, **Priority ≈ 1,8×**. Live 3.8 : audio 3 $/M en entrée, 12 $/M en sortie. TTS 3.8 Flash : 0,50 $ in / 9 $ out. Images Nano Banana 2.1 : 30 $/M tokens d'image, soit ≈ 0,034 $ par image 1K. Grounding Search / Maps : 5 000 requêtes gratuites par mois puis 14 $/1 000.

**Ce que cela implique pour vos devis** : une application chiffrée aujourd'hui sur `gemini-3.8-flash` verra son coût par token **doubler** au 1er janvier 2027. Écrivez-le dans votre proposition commerciale, et prévoyez dans le code la possibilité de basculer sur `gemini-3.5-flash-lite` ou sur un autre fournisseur (L088).

```quiz
{
  "q": "Une application consomme chaque mois 200 M tokens d'entrée et 20 M tokens de sortie sur `gemini-3.8-flash`. Combien coûtera-t-elle par mois à partir du 1er janvier 2027 (hors cache et hors réflexion) ?",
  "options": [
    "225 $",
    "300 $",
    "450 $",
    "900 $"
  ],
  "answer": 2,
  "explanation": "Nouveaux tarifs : 200 × 1,50 $ = 300 $ en entrée, plus 20 × 7,50 $ = 150 $ en sortie, soit 450 $. Aujourd'hui (0,75 / 3,75 $), la même consommation coûte 225 $ : la facture double."
}
```

## 7. Gemini CLI : l'agent de code gratuit

[Gemini CLI](https://github.com/google-gemini/gemini-cli) est l'agent de code en ligne de commande de Google, sous licence Apache 2.0, concurrent de Claude Code et Codex CLI. Sa particularité est l'**accès individuel gratuit** avec un compte Google, dans la limite de quotas quotidiens décrits sur la [page quotas et tarifs](https://geminicli.com/docs/resources/quota-and-pricing) ; au-delà, vous branchez une clé API facturée au tarif ci-dessus. Il lit les serveurs MCP (M21) et convient très bien pour explorer un dépôt ou générer des tests. Retenez la règle du module : un agent de code gratuit est idéal pour apprendre et prototyper ; pour un projet client, lisez les conditions d'utilisation des données avant de lui ouvrir le code source.

```mission
{
  "title": "La réflexion de Gemini est-elle facturée ?",
  "url": "https://ai.google.dev/gemini-api/docs/pricing",
  "steps": [
    "Ouvrez la page Pricing de la Gemini API",
    "Choisissez la ligne de gemini-3.8-flash",
    "Lisez l'intitulé exact de la ligne Output price"
  ],
  "question": "Les tokens de réflexion (thinking) sont-ils facturés, et à quel tarif ?",
  "hint": "L'intitulé de la ligne de prix de sortie contient une parenthèse.",
  "answer": "Oui, au tarif de sortie : « Output price (including thinking tokens) ». Ajoutez `thoughtsTokenCount` à vos calculs (page consultée le 5/11/2026 ; hausse prévue le 1/01/2027 pour Flash) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Les limites de Gemini 3.8 Flash",
  "url": "https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash",
  "steps": [
    "Ouvrez la fiche du modèle Gemini 3.8 Flash",
    "Cherchez le tableau des limites de tokens",
    "Relevez les limites d'entrée et de sortie"
  ],
  "question": "Combien de tokens Gemini 3.8 Flash accepte-t-il en entrée, et combien peut-il en produire en sortie ?",
  "hint": "L'entrée dépasse légèrement le million.",
  "answer": "1 048 576 tokens en entrée et 65 536 en sortie (fiche consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Un cabinet de géomètres reçoit des procès-verbaux de bornage sous forme de PDF scannés (20 à 60 pages) accompagnés de photos de terrain. Écrivez `pv_bornage.py` qui : (1) téléverse le PDF et 3 photos via la Files API ; (2) crée un cache de contexte d'une heure contenant ces fichiers et un `system_instruction` métier ; (3) pose quatre questions successives (parties présentes, parcelles concernées, bornes posées avec coordonnées si présentes, réserves formulées) avec une **sortie structurée** Pydantic pour chacune ; (4) imprime les tokens facturés, les tokens lus en cache et le coût avec les tarifs actuels **et** ceux du 1er janvier 2027.

**Critères de réussite.**
1. Un seul téléversement des fichiers ; les quatre questions utilisent `cached_content`.
2. Chaque réponse est une instance Pydantic valide (aucun `json.loads` sur du texte libre).
3. Les deux estimations de coût (nov. 2026 et janv. 2027) sont affichées côte à côte.
4. Le cache est supprimé en fin de script, même en cas d'exception (`try/finally`).

**Pistes de corrigé.** Combinez les sections 3, 4 et 5.2 : `config=types.GenerateContentConfig(cached_content=cache.name, response_mime_type="application/json", response_schema=VotreModele)`, puis `VotreModele.model_validate_json(r.text)`. Pour le coût 2027, multipliez simplement les tarifs Flash par deux ; n'oubliez pas que les tokens **lus en cache** sont facturés à un tarif réduit indiqué sur la page Pricing (à reporter dans votre formule).

## ✅ Auto-évaluation express

1. Quel paquet Python installer pour le SDK Gemini actuel, et quelle classe est le point d'entrée ?
2. Que coûtera `gemini-3.8-flash` en entrée à partir du 1er janvier 2027 ?
3. À quoi sert le context caching et dans quel cas est-il rentable ?

**Réponses.** 1) `google-genai`, point d'entrée `genai.Client` (`client.models.generate_content`). 2) 1,50 $/M tokens (3,75 → 7,50 $ en sortie). 3) À stocker un contexte volumineux côté Google pour ne pas le renvoyer (et le repayer) à chaque appel ; rentable dès que le même document est interrogé plusieurs fois pendant la durée de vie du cache, en tenant compte du coût de stockage horaire.

## 📚 Pour aller plus loin
- [Gemini API — Image generation (Nano Banana)](https://ai.google.dev/gemini-api/docs/image-generation) 🇬🇧 — générer et retoucher des images dans le même SDK.
- [Gemini API — Live API](https://ai.google.dev/gemini-api/docs/live-api) 🇬🇧 — assistants vocaux temps réel.
- [Gemma 4 — DeepMind](https://deepmind.google/models/gemma/gemma-4/) 🇬🇧 — la famille de modèles ouverts de Google, auto-hébergeable (M29).
- [Gemini API — Batch API](https://ai.google.dev/gemini-api/docs/batch-api) 🇬🇧 — diviser la facture par deux sur les traitements différés.

> 🗺️ **Et maintenant ?** — Vous connaissez maintenant cinq fournisseurs ; la L088 les fait travailler ensemble derrière une seule interface, avec routage, repli et mesure des coûts.
