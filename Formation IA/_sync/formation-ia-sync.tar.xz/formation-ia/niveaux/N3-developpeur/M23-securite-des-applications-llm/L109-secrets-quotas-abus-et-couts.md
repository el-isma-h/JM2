---
id: L109
module: M23
level: N3
title: "Secrets, quotas, abus et coûts"
minutes: 50
objectives:
  - "Appliquer les règles de gestion des clés API (variables d'environnement, une clé par environnement, détection de fuite, révocation puis rotation)"
  - "Construire une couche de quotas applicatifs (débit par utilisateur, plafond de tokens, budget journalier, coupe-circuit) devant un appel LLM"
  - "Identifier les abus propres aux applications LLM (déni de portefeuille, détournement en proxy gratuit, extraction de modèle) et les contre-mesures associées"
  - "Évaluer le coût d'une requête et d'un mois d'exploitation, puis choisir les leviers FinOps adaptés (modèle, cache, batch, max_tokens)"
skills: ["C3.6"]
sources:
  - { title: "Claude Platform — Obtenir une clé API", url: "https://platform.claude.com/docs/en/get-api-key", lang: "en" }
  - { title: "Claude Platform — Rate limits", url: "https://platform.claude.com/docs/en/api/rate-limits", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — Workspaces", url: "https://platform.claude.com/docs/en/manage-claude/workspaces", lang: "en" }
  - { title: "Claude Platform — Usage & Cost Analytics API", url: "https://platform.claude.com/docs/en/manage-claude/usage-cost-analytics-api", lang: "en" }
  - { title: "Claude Platform — Prompt caching", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-caching", lang: "en" }
  - { title: "Claude Platform — Batch processing", url: "https://platform.claude.com/docs/en/build-with-claude/batch-processing", lang: "en" }
  - { title: "Claude Platform — Task budgets", url: "https://platform.claude.com/docs/en/build-with-claude/task-budgets", lang: "en" }
  - { title: "Claude Agent SDK — Cost tracking", url: "https://code.claude.com/docs/en/agent-sdk/cost-tracking", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "OpenAI — Rate limits", url: "https://developers.openai.com/api/docs/guides/rate-limits", lang: "en" }
  - { title: "Modulos — OWASP Top 10 for LLM Applications (synthèse 2026)", url: "https://docs.modulos.ai/frameworks/owasp-top-10-llm/index", lang: "en" }
---

# Secrets, quotas, abus et coûts

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 23

## 🎯 Ce que vous saurez faire
- Ranger, détecter et faire tourner les **clés API** d'une application LLM sans jamais les exposer au navigateur ni au dépôt Git.
- Placer devant chaque appel au modèle une **couche de quotas** : débit par utilisateur, taille d'entrée, `max_tokens`, budget journalier en dollars, coupe-circuit global.
- Reconnaître les **abus** qui visent votre facture plutôt que vos données, et y répondre.
- Chiffrer le coût d'une requête, d'un mois, d'une attaque, et actionner les bons **leviers FinOps**.

> 🧭 **En clair** — Votre clé API est une carte bancaire d'entreprise : on la range au coffre (jamais dans le code ni dans le navigateur), on en donne une différente à chaque service, et on la fait opposer immédiatement si elle est perdue. Devant votre application, on poste un **videur de boîte de nuit** — c'est le *rate limiting* : il compte les entrées de chaque client, refuse ceux qui reviennent trop souvent et ferme la porte quand la salle est pleine (le budget du jour est atteint). Car en IA, chaque question coûte de l'argent : un attaquant n'a pas besoin de voler vos données, il lui suffit de vous faire dépenser. On termine par la FinOps : chiffrer avant de lancer, et choisir le modèle le moins cher qui fait le travail.

## 1. Pourquoi ce risque est monté à la 6ᵉ place

Dans la liste OWASP 2026, *Unbounded Consumption* passe de la 10ᵉ à la **6ᵉ place (LLM06)** : une application LLM transforme chaque requête en **dépense variable**, payée au token. Un attaquant n'a plus besoin de voler vos données pour vous nuire : il lui suffit de **vous faire consommer** (*denial of wallet*, déni de portefeuille).

Analogie : votre clé API est une **carte carburant d'entreprise**. La perdre, c'est laisser n'importe qui faire le plein ; ne pas la plafonner, c'est accepter qu'un script vide le budget de l'année en un week-end. Garder la carte et la plafonner sont deux protections indépendantes, toutes deux obligatoires.

| Menace | Vecteur | Ce que l'attaquant gagne | OWASP 2026 |
|---|---|---|---|
| Clé volée | Dépôt Git public, bundle JavaScript, journal, capture d'écran | Un accès gratuit à « votre » modèle, sur votre facture | LLM02 (fuite) puis LLM06 |
| Déni de portefeuille | Boucle de requêtes longues, contexte de 1M tokens, agent qui boucle | Votre facture explose, ou votre quota est épuisé et le service tombe | LLM06 |
| Proxy gratuit | Votre chatbot public utilisé comme ChatGPT gratuit (« oublie la plomberie, écris mon mémoire ») | Un LLM payé par vous | LLM06 (+ LLM01) |
| Extraction de modèle / distillation | Des milliers de requêtes systématiques pour copier le comportement d'un modèle affiné | Votre avantage concurrentiel | LLM06 |

```quiz
{
  "q": "Un visiteur utilise votre chatbot de plomberie pour faire rédiger son mémoire de master. De quel abus s'agit-il ?",
  "options": [
    "Extraction de modèle par requêtes systématiques",
    "Détournement en proxy gratuit (LLM06)",
    "Clé API volée dans un dépôt public",
    "Empoisonnement des données du RAG"
  ],
  "answer": 1,
  "explanation": "Votre chatbot sert de LLM gratuit, payé par vous. Contre-mesure : classifieur « hors sujet » avant le modèle principal, refus court, quotas en tokens et en dollars."
}
```

## 2. Secrets : ranger, détecter, révoquer

### 2.1 Les cinq règles

1. **Jamais de clé dans le code ni dans le dépôt** : la clé est lue dans une variable d'environnement (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`) chargée depuis un fichier `.env` **ignoré par Git** en développement, et depuis un gestionnaire de secrets en production (secrets de votre hébergeur, coffre-fort de votre cloud). Les SDK officiels lisent ces variables automatiquement.
2. **Jamais de clé dans le navigateur ni dans une application mobile** : tout ce qui est livré au client est lisible. Les variables préfixées `NEXT_PUBLIC_` (Next.js) ou `VITE_` (Vite) sont **copiées dans le bundle** : y mettre une clé revient à la publier. Le navigateur appelle **votre** serveur, qui seul appelle le fournisseur.
3. **Une clé par environnement et par projet** : développement, recette et production n'ont pas la même clé ; chez Anthropic, les **Workspaces** de la Console permettent de cloisonner clés, limites et suivi des dépenses par projet. Une fuite de la clé de dev ne doit jamais toucher la prod.
4. **Moindre privilège** : la clé d'API « inférence » de l'application n'est pas la clé **Admin API** (qui gère membres, workspaces et clés). Celle-ci ne quitte jamais le poste de l'administrateur.
5. **Révoquer d'abord, comprendre ensuite** : les *Safety best practices* d'OpenAI le rappellent dans une rubrique dédiée — une clé compromise se **révoque immédiatement** dans la console, puis on en émet une nouvelle (rotation), puis on enquête. Supprimer le commit fautif ne sert à rien si la clé reste valide : des robots scrutent les dépôts publics en continu et une clé poussée est souvent exploitée en quelques minutes.

> ⚠️ **Piège fréquent** — Faire un `git rm .env` puis pousser. Le fichier reste dans l'**historique** : n'importe qui peut le retrouver avec `git log -p`. La seule réponse correcte à une clé poussée est la révocation ; la réécriture de l'historique vient après, pour l'hygiène.

### 2.2 Outillage minimal (bash)

```bash
#!/usr/bin/env bash
# hygiene_secrets.sh — à lancer une fois à la création du projet
set -euo pipefail

# 1. Le .env ne doit jamais être suivi par Git
grep -qxF ".env" .gitignore 2>/dev/null || echo ".env" >> .gitignore
grep -qxF ".env.*" .gitignore || echo ".env.*" >> .gitignore
printf 'ANTHROPIC_API_KEY=\n' > .env.example     # modèle sans valeur, lui versionné
git add .gitignore .env.example

# 2. Vérifier qu'aucune clé n'est déjà dans l'historique (motifs indicatifs)
if git log -p --all | grep -nE "sk-ant-[A-Za-z0-9_-]{20,}|sk-(proj-)?[A-Za-z0-9_-]{20,}" ; then
  echo "⚠️  Clé potentielle trouvée dans l'historique : RÉVOQUEZ-LA dans la console avant toute autre action."
  exit 1
fi

# 3. Scanner avant chaque commit avec gitleaks (https://github.com/gitleaks/gitleaks)
#    installation : brew install gitleaks  (ou binaire GitHub)
cat > .git/hooks/pre-commit <<'EOF'
#!/usr/bin/env bash
gitleaks protect --staged --redact || { echo "Commit bloqué : secret détecté."; exit 1; }
EOF
chmod +x .git/hooks/pre-commit
echo "✅ Hygiène des secrets en place."
```

Activez aussi le *secret scanning* de votre forge (GitHub, GitLab) : il prévient souvent l'éditeur de la clé, qui peut la désactiver.

### 2.3 Les agents ont aussi des secrets

Un agent qui appelle un ERP, une messagerie ou une base a besoin d'identifiants. Ne les mettez **jamais dans le prompt** (LLM08 : tout ce qui est dans le contexte peut fuiter) : l'outil, côté code, détient l'identifiant et le modèle ne voit que le résultat. Les plateformes d'agents managés proposent des coffres dédiés (chez Anthropic, les *Vaults* des Managed Agents) pour que les identifiants restent hors du contexte du modèle.

> 💡 **À retenir** — Une clé se **garde** (env, gestionnaire de secrets, jamais côté client), se **cloisonne** (une par environnement, workspaces), se **surveille** (scanner, alertes) et se **révoque** sans hésiter.

> 🔗 **Documentation officielle** — [Obtenir une clé API (Claude)](https://platform.claude.com/docs/en/get-api-key) 🇬🇧 · [Workspaces](https://platform.claude.com/docs/en/manage-claude/workspaces) 🇬🇧 · [Managed Agents — Vaults](https://platform.claude.com/docs/en/managed-agents/vaults) 🇬🇧 · [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧.

```quiz
{
  "q": "Après avoir poussé une clé par erreur, un `git rm .env` suivi d'un nouveau push suffit à régler le problème.",
  "type": "vrai_faux",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Le fichier reste dans l'historique Git et des robots scrutent les dépôts en continu. La seule réponse correcte : révoquer la clé d'abord, puis en émettre une nouvelle, puis nettoyer l'historique."
}
```

## 3. Quotas : deux étages de limites

Le fournisseur vous impose déjà des **rate limits** : chez Anthropic, des paliers (Evaluation, Start, Build, Scale avec des plafonds de dépenses mensuels de 500 $, 1 000 $ et 200 000 $, Custom ; nov. 2026) appliqués selon un algorithme de **seau à jetons** (*token bucket*), avec des en-têtes `anthropic-ratelimit-*` dans chaque réponse et une erreur **429** quand le seau est vide. Mais ces limites protègent **le fournisseur**, pas vous : elles sont calibrées sur votre organisation entière, donc bien trop larges pour un utilisateur isolé. Il faut un **second étage, applicatif**, devant chaque appel.

> 💡 **Autrement dit** — Les limites du fournisseur sont le videur de **tout le quartier** : il laisse passer votre organisation entière tant qu'elle reste sous son plafond. Votre application a besoin de son propre videur, à **sa** porte, qui connaît chaque client par son nom (l'identifiant authentifié) et applique ses propres règles : 10 requêtes par minute, 0,50 $ par jour, et fermeture générale à 30 $.

```
 Navigateur ──► [1 Auth] ──► [2 Débit/utilisateur] ──► [3 Taille d'entrée] ──► [4 Budget $] ──► API LLM
                  │               │ 429                    │ 413                  │ 402/503
                  └─ anonyme ?    └─ 10 req/min            └─ 4 000 tokens        └─ 0,50 $/jour/utilisateur
                     refus           par utilisateur          max                     + 30 $/jour global
                                                                                      (coupe-circuit)
```

Le code ci-dessous implémente ces quatre étages pour DevisBot (stockage en mémoire pour l'exercice ; en production, remplacez les dictionnaires par Redis pour partager les compteurs entre instances).

```python
# garde_budget.py — quotas et budget devant un appel LLM (Python 3.12+)
# pip install anthropic fastapi uvicorn ; export ANTHROPIC_API_KEY=... (jamais dans le code)
import os, time, logging
from collections import defaultdict
from datetime import date
from anthropic import Anthropic
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

if not os.environ.get("ANTHROPIC_API_KEY"):
    raise SystemExit("ANTHROPIC_API_KEY absente : refus de démarrer.")  # échec explicite

client = Anthropic()
app = FastAPI()
log = logging.getLogger("finops")
logging.basicConfig(level=logging.INFO)

MODELE = "claude-haiku-5-5"
# Tarifs $/MTok (Claude Platform Pricing, nov. 2026) — à mettre à jour à chaque changement de grille
TARIFS = {
    "claude-haiku-5-5": {"in": 0.10, "out": 0.50, "cache_read": 0.01, "cache_write": 0.125},
    "claude-sonnet-5-5": {"in": 2.00, "out": 10.00, "cache_read": 0.10, "cache_write": 2.50},
    "claude-opus-5-5": {"in": 4.00, "out": 20.00, "cache_read": 0.20, "cache_write": 5.00},
}
REQ_PAR_MINUTE = 10
MAX_TOKENS_ENTREE = 4_000
MAX_TOKENS_SORTIE = 600
BUDGET_UTILISATEUR_JOUR = 0.50   # $
BUDGET_GLOBAL_JOUR = 30.00       # $ — coupe-circuit
SEUIL_ALERTE = 0.80

horodatages: dict[str, list[float]] = defaultdict(list)
depenses: dict[tuple[str, date], float] = defaultdict(float)

def cout_usd(modele: str, usage) -> float:
    t = TARIFS[modele]
    return (usage.input_tokens * t["in"] + usage.output_tokens * t["out"]
            + (usage.cache_read_input_tokens or 0) * t["cache_read"]
            + (usage.cache_creation_input_tokens or 0) * t["cache_write"]) / 1_000_000

def verifier_debit(uid: str) -> None:
    maintenant = time.monotonic()
    fenetre = [t for t in horodatages[uid] if maintenant - t < 60]
    if len(fenetre) >= REQ_PAR_MINUTE:
        raise HTTPException(429, "Trop de requêtes : réessayez dans une minute.",
                            headers={"Retry-After": "60"})
    fenetre.append(maintenant)
    horodatages[uid] = fenetre

def verifier_budget(uid: str) -> None:
    jour = date.today()
    total = depenses[("*", jour)]
    if total >= BUDGET_GLOBAL_JOUR:
        raise HTTPException(503, "Service momentanément indisponible.")  # coupe-circuit
    if depenses[(uid, jour)] >= BUDGET_UTILISATEUR_JOUR:
        raise HTTPException(402, "Quota quotidien atteint.")

class Question(BaseModel):
    texte: str = Field(max_length=8_000)  # premier filtre, gratuit, en caractères

@app.post("/chat")
def chat(q: Question, x_user_id: str = Header(...)) -> dict:
    # x_user_id doit provenir de votre authentification (session, JWT), jamais d'un champ libre
    verifier_debit(x_user_id)
    verifier_budget(x_user_id)
    messages = [{"role": "user", "content": q.texte}]
    n = client.messages.count_tokens(model=MODELE, messages=messages).input_tokens
    if n > MAX_TOKENS_ENTREE:
        raise HTTPException(413, f"Message trop long ({n} tokens).")
    rep = client.messages.create(
        model=MODELE, max_tokens=MAX_TOKENS_SORTIE,
        system="Tu es DevisBot, assistant de Plomberie Martin. Réponds uniquement sur la plomberie.",
        messages=messages,
        metadata={"user_id": x_user_id},  # identifiant opaque : aide le fournisseur à repérer l'abus
    )
    cout = cout_usd(MODELE, rep.usage)
    jour = date.today()
    depenses[(x_user_id, jour)] += cout
    depenses[("*", jour)] += cout
    if depenses[("*", jour)] >= SEUIL_ALERTE * BUDGET_GLOBAL_JOUR:
        log.warning("ALERTE budget global à %.0f %%", 100 * depenses[("*", jour)] / BUDGET_GLOBAL_JOUR)
    log.info("uid=%s in=%d out=%d cout=%.5f$", x_user_id, rep.usage.input_tokens,
             rep.usage.output_tokens, cout)
    return {"reponse": "".join(b.text for b in rep.content if b.type == "text"),
            "cout_usd": round(cout, 5)}
```

Trois détails qui font la différence :

- **`max_tokens` est votre plafond de sortie le moins cher** : sans lui, une réponse peut monter à 128K tokens de sortie sur les modèles 5.5. Les *Safety best practices* d'OpenAI le recommandent explicitement (« contraindre l'entrée et limiter les tokens de sortie »).
- **Les agents se plafonnent en itérations et en dollars** : une boucle d'outils doit avoir un nombre maximal de tours (10, 20…) codé en dur. Le Claude Agent SDK expose `max_budget_usd` et un suivi des coûts par session ; l'API propose des *task budgets* pour borner l'effort d'une tâche.
- **L'identifiant utilisateur transmis au fournisseur doit être opaque** (un hachage, pas un e-mail) : `metadata.user_id` chez Anthropic, `safety_identifier` chez OpenAI. Il permet au fournisseur de cibler l'abusif sans couper votre organisation entière, sans lui transmettre de donnée personnelle (L108).

```mission
{
  "title": "L'identifiant de sécurité recommandé par OpenAI",
  "url": "https://developers.openai.com/api/docs/guides/safety-best-practices",
  "steps": [
    "Ouvrez « Safety best practices » d'OpenAI",
    "Repérez la rubrique sur les identifiants de sécurité (safety identifiers)",
    "Notez le nom du paramètre et la forme recommandée pour sa valeur"
  ],
  "question": "Quel paramètre permet de transmettre à OpenAI un identifiant d'utilisateur final, et sous quelle forme faut-il l'envoyer ?",
  "hint": "La leçon le cite à côté de `metadata.user_id` chez Anthropic.",
  "answer": "`safety_identifier`, avec une valeur opaque (par exemple un hachage du nom d'utilisateur ou de l'e-mail) pour ne transmettre aucune donnée personnelle (page consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

> ⚠️ **Piège fréquent** — Compter les requêtes et pas les tokens. Dix requêtes de 200 tokens et dix requêtes de 900 000 tokens n'ont rien à voir : la seconde série coûte environ 4 500 fois plus. Limitez **les deux**, et surtout **les dollars**.

> 🔗 **Documentation officielle** — [Rate limits (Claude)](https://platform.claude.com/docs/en/api/rate-limits) 🇬🇧 · [Rate limits (OpenAI)](https://developers.openai.com/api/docs/guides/rate-limits) 🇬🇧 · [Task budgets](https://platform.claude.com/docs/en/build-with-claude/task-budgets) 🇬🇧 · [Agent SDK — Cost tracking](https://code.claude.com/docs/en/agent-sdk/cost-tracking) 🇬🇧.

```quiz
{
  "q": "Le budget global du jour (30 $) est atteint à 15 h. Que renvoie garde_budget.py à l'utilisateur suivant, même s'il n'a rien consommé ?",
  "options": [
    "429 « Trop de requêtes : réessayez dans une minute »",
    "402 « Quota quotidien atteint »",
    "503 « Service momentanément indisponible »",
    "413 « Message trop long »"
  ],
  "answer": 2,
  "explanation": "verifier_budget teste d'abord le total global : au-delà de BUDGET_GLOBAL_JOUR, le coupe-circuit renvoie 503 à tout le monde. Le 402 ne concerne que le quota individuel."
}
```

## 4. Abus : quand l'utilisateur légitime n'en est pas un

Les quotas bornent le dégât ; il reste à **réduire la surface**. Les recommandations éditeurs (OpenAI *Safety best practices* : connaissance client, signalement utilisateur, identifiants de sécurité, tests adverses) se traduisent ainsi :

| Abus | Signal à surveiller | Contre-mesure |
|---|---|---|
| Comptes jetables qui contournent le quota par utilisateur | Pic d'inscriptions, même IP ou même empreinte | Vérification e-mail/téléphone, CAPTCHA sur l'inscription, quota par IP **et** par compte |
| Chatbot détourné en LLM gratuit | Sujets hors périmètre, réponses longues | Classifieur « hors sujet » (Haiku, L107) avant le modèle principal ; refus court et poli |
| Extraction de modèle | Requêtes très régulières, couvrant systématiquement l'espace des entrées | Détection d'anomalies sur les journaux, contrats B2B avec KYC, limites plus basses pour les comptes récents |
| Agent qui boucle (faute de conception ou injection) | Nombre d'appels d'outils par session anormal | Plafond d'itérations, budget par tâche, alerte puis arrêt |

🎮 **Défi** — Un client B2B de DevisBot vous demande « un accès illimité, on paiera ». Que mettez-vous dans le contrat **et** dans le code ? *(Contrat : usage autorisé, plafond mensuel, conditions d'usage du fournisseur répercutées. Code : une clé ou un workspace dédié à ce client, son propre budget et ses alertes ; « illimité » n'existe jamais côté code, seulement « très élevé et surveillé ».)*

## 5. FinOps : chiffrer avant de déployer

### 5.1 Le calcul d'une requête

Reprenons DevisBot (prix nov. 2026) : prompt système de 3 000 tokens, question de 200 tokens, réponse de 400 tokens.

| Modèle | Entrée (3 200 tokens) | Sortie (400 tokens) | Total / requête | 30 000 requêtes / mois |
|---|---|---|---|---|
| Haiku 5.5 (0,10 / 0,50 $) | 0,00032 $ | 0,00020 $ | **0,00052 $** | ≈ 16 $ |
| Sonnet 5.5 (2 / 10 $) | 0,0064 $ | 0,0040 $ | 0,0104 $ | ≈ 312 $ |
| Opus 5.5 (4 / 20 $) | 0,0128 $ | 0,0080 $ | 0,0208 $ | ≈ 624 $ |

Et l'attaque ? Sans plafond, un script qui envoie un contexte de 1M tokens à Opus 5.5 et obtient 128K tokens de sortie paie environ 4 $ + 2,56 $ ≈ **6,56 $ par requête**. Mille requêtes sur un week-end : plus de 6 500 $. Avec la couche de la section 3 (4 000 tokens d'entrée, 600 de sortie, 0,50 $ par jour et par utilisateur, 30 $ par jour au total), la même attaque coûte **au pire 30 $**.

### 5.2 Les leviers, du plus rentable au plus technique

| Levier | Gain typique (nov. 2026) | Quand l'utiliser |
|---|---|---|
| **Choisir le bon modèle** (routage Haiku → Sonnet → Opus) | ×20 (Sonnet) à ×40 (Opus) par rapport à Haiku | Toujours : la majorité des requêtes d'un chatbot métier n'exige pas le modèle phare |
| **Prompt caching** | Lecture du cache à 0,1× le prix d'entrée (0,05× sur Opus/Sonnet 5.5), écriture à 1,25× ; TTL 5 min ou 1 h | Prompt système long et stable, documents relus à chaque tour |
| **Batch API** | −50 %, résultats en général en moins d'une heure (24 h max) | Traitements non interactifs : classement nocturne d'e-mails, génération de fiches |
| **`max_tokens` et consignes de concision** | Proportionnel à la sortie (le token de sortie coûte 5× l'entrée) | Toujours |
| **Compaction / édition du contexte** | Évite que l'historique grossisse à chaque tour | Conversations longues, agents |
| **Modèle local** (M21) | Coût marginal quasi nul, investissement matériel | Gros volumes stables, données sensibles |

> 💡 **Autrement dit** — Le premier levier n'est pas technique : c'est de ne pas prendre un taxi de luxe pour aller chercher le pain. Router les questions simples vers Haiku coûte 20 à 40 fois moins que tout envoyer à Sonnet ou Opus ; le cache et le batch viennent ensuite raboter ce qui reste.

### 5.3 Mesurer en continu

Trois sources de vérité : vos **journaux** (le `cout_usd` par utilisateur et par fonctionnalité), l'**observabilité** (Langfuse, Helicone, LangSmith : coût par trace, M22) et la **facture** (chez Anthropic, l'*Usage & Cost Analytics API*, bêta depuis fin oct. 2026, pour rapprocher les deux). Un écart notable signale un appel non instrumenté — souvent un script oublié avec une vieille clé.

```mission
{
  "title": "Le statut de l'Usage & Cost Analytics API",
  "url": "https://platform.claude.com/docs/en/manage-claude/usage-cost-analytics-api",
  "steps": [
    "Ouvrez la page Usage & Cost Analytics API",
    "Repérez le statut affiché (bêta, disponibilité générale…)",
    "Cherchez ce que devient l'ancienne API Usage and Cost"
  ],
  "question": "Quel est le statut de l'Usage & Cost Analytics API et que devient l'ancienne API Usage and Cost ?",
  "hint": "Les notes de version du 29 octobre 2026 en parlent.",
  "answer": "En bêta (avec un en-tête anthropic-beta dédié) ; l'ancienne API Usage and Cost est désormais présentée comme héritée (legacy) (vérifié le 5 nov. 2026) ; bêta lancée le 29 oct. 2026 selon les notes de version.",
  "xp": 15
}
```

> 💡 **À retenir** — Chiffrez trois scénarios avant toute mise en ligne : **nominal** (usage prévu), **pic** (×10) et **attaque** (sans vos quotas, puis avec). Si le scénario « attaque avec quotas » n'est pas supportable, vos quotas sont trop larges.

> 🔗 **Documentation officielle** — [Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 · [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 · [Batch processing](https://platform.claude.com/docs/en/build-with-claude/batch-processing) 🇬🇧 · [Usage & Cost Analytics API](https://platform.claude.com/docs/en/manage-claude/usage-cost-analytics-api) 🇬🇧.

## 🧪 Exercice pratique

**Consigne.** (1) Lancez `hygiene_secrets.sh` sur le dépôt de DevisBot et provoquez volontairement un blocage en tentant de commiter un faux secret (`sk-ant-` suivi de 30 caractères inventés). (2) Intégrez `garde_budget.py` devant `devisbot_securise.py` (L107-L108) et ajoutez un plafond de **8 itérations** à la boucle d'outils. (3) Écrivez un script local qui envoie 50 requêtes à **votre propre** `http://localhost:8000/chat` avec le même `x-user-id`, puis 50 avec des identifiants différents. (4) Remplissez le tableau des trois scénarios (nominal, pic, attaque) pour 500 clients actifs par mois.

**Critères de réussite.**
- Le commit contenant le faux secret est refusé par le hook.
- Le 11ᵉ appel de la même minute reçoit un **429** avec `Retry-After` ; le budget global déclenche l'alerte à 80 % puis le **503** à 100 % (abaissez temporairement `BUDGET_GLOBAL_JOUR` à 0,01 $ pour le tester).
- Une session d'agent qui dépasse 8 appels d'outils s'arrête avec un message explicite et une ligne de journal.
- Le tableau FinOps indique un coût mensuel par modèle et le coût maximal d'une attaque avec et sans quotas.

**Pistes de corrigé.** `httpx` en boucle suffit pour le test de charge. Le second lot (identifiants différents) passe le débit par utilisateur mais bute sur le budget global : le coupe-circuit est indispensable. 500 clients × 60 requêtes sur Haiku 5.5 : ≈ 16 $/mois ; pic ×10 ≈ 160 $ ; attaque avec quotas ≤ 30 $/jour, soit 900 $/mois au pire — trop ? Baissez le plafond global.

## ✅ Auto-évaluation express

1. Votre clé apparaît dans un commit poussé il y a dix minutes sur un dépôt public. Quelle est la toute première action ?
2. Pourquoi les rate limits du fournisseur ne suffisent-ils pas à protéger votre budget ?
3. Quel est le levier FinOps le plus rentable pour un chatbot métier, avant même le cache ?

*Réponses : 1) Révoquer la clé dans la console du fournisseur (puis en émettre une nouvelle, puis nettoyer l'historique et enquêter). 2) Ils sont calibrés pour toute votre organisation et protègent le fournisseur ; un seul utilisateur peut consommer tout le palier. Il faut des quotas applicatifs par utilisateur, en tokens et en dollars, plus un coupe-circuit global. 3) Le choix du modèle (routage vers Haiku pour les requêtes simples), qui divise le coût par 20 à 40.*

## 📚 Pour aller plus loin
- [Claude Platform — Rate limits](https://platform.claude.com/docs/en/api/rate-limits) 🇬🇧 — paliers, seau à jetons, en-têtes de réponse.
- [Claude Platform — Usage & Cost Analytics API](https://platform.claude.com/docs/en/manage-claude/usage-cost-analytics-api) 🇬🇧 — rapprocher automatiquement consommation et facture.
- [Claude Platform — Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 — règles de cache, TTL et multiplicateurs de prix.
- [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — limitation des tokens, identifiants de sécurité, révocation des clés compromises.
- [gitleaks](https://github.com/gitleaks/gitleaks) 🇬🇧 — scanner de secrets pour dépôts Git et hooks de pré-commit.
- [Modulos — OWASP Top 10 for LLM Applications](https://docs.modulos.ai/frameworks/owasp-top-10-llm/index) 🇬🇧 — synthèse 2026, dont LLM06 *Unbounded Consumption*.

> 🗺️ **Et maintenant ?** — Vous connaissez toutes les défenses ; en L110, vous changez de casquette et devenez auditeur d'une application vulnérable, rapport à l'appui.
