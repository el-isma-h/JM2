---
id: L090
module: M20
level: N3
title: "Pipeline d'ingestion : parsing, chunking, métadonnées"
minutes: 55
objectives:
  - "Extraire le texte de PDF, DOCX et HTML en conservant la structure (titres, pages) et détecter les PDF scannés à envoyer à l'OCR"
  - "Appliquer et comparer un découpage à taille fixe, récursif et sémantique, et choisir la taille de morceau adaptée au modèle d'embedding"
  - "Enrichir chaque morceau de métadonnées exploitables (source, page, section, service, version) et le rattacher à un identifiant stable"
  - "Construire une ingestion incrémentale et dédupliquée (empreinte de fichier, mise à jour, suppression)"
skills: ["C3.3"]
sources:
  - { title: "pypdf — documentation", url: "https://pypdf.readthedocs.io/", lang: "en" }
  - { title: "python-docx — documentation", url: "https://python-docx.readthedocs.io/", lang: "en" }
  - { title: "Beautiful Soup — documentation", url: "https://www.crummy.com/software/BeautifulSoup/bs4/doc/", lang: "en" }
  - { title: "Mistral — OCR 4.1", url: "https://docs.mistral.ai/models/ocr-4-1", lang: "en" }
  - { title: "Claude Platform — PDF support", url: "https://platform.claude.com/docs/en/build-with-claude/pdf-support", lang: "en" }
  - { title: "Claude Platform — Files API", url: "https://platform.claude.com/docs/en/build-with-claude/files", lang: "en" }
  - { title: "Claude Cookbook — Retrieval augmented generation guide", url: "https://platform.claude.com/cookbook/capabilities-retrieval-augmented-generation-guide", lang: "en" }
  - { title: "LangChain — changelog (versions 1.x)", url: "https://docs.langchain.com/oss/python/releases/changelog.md", lang: "en" }
  - { title: "Claude Academy — Building with the Claude API (text chunking strategies)", url: "https://academy.claude.com/courses/building-with-the-claude-api", lang: "en" }
---

# Pipeline d'ingestion : parsing, chunking, métadonnées

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 20

## 🎯 Ce que vous saurez faire
- Transformer le dossier `procedures/` de Bréval Matériaux (PDF, DOCX, FAQ HTML) en morceaux de texte propres, numérotés, avec page et section.
- Expliquer pourquoi un morceau de 300 tokens avec chevauchement bat souvent un morceau de 2 000 tokens, et le prouver avec un test.
- Relancer l'ingestion chaque nuit sans re-vectoriser ce qui n'a pas changé, et sans jamais créer de doublon.

> 🧭 **En clair** — Pour réussir un examen à livre ouvert, il faut un **classeur bien rangé** : des fiches lisibles, ni trop longues ni trop courtes, chacune avec une étiquette (quel document, quelle page, quel service). L'ingestion, c'est ce travail de documentaliste : lire les PDF et les pages web (*parsing*), couper le texte en fiches cohérentes (*chunking*), coller l'étiquette (*métadonnées*) et ne jamais photocopier deux fois la même fiche (*déduplication*). Un classeur mal rangé donne de mauvaises réponses, même avec le meilleur modèle du monde.

## 1. L'ingestion, c'est 60 % de la qualité du RAG

Un RAG se juge à ses réponses, mais il se gagne à l'ingestion. Si le PDF « Procédure notes de frais v3 » est découpé en plein milieu du tableau des plafonds, aucun modèle, aussi brillant soit-il, ne répondra correctement à « quel est le plafond pour un repas ? ». Le pipeline complet :

```
fichiers ──▶ détection du type ──▶ parsing (texte + structure) ──▶ nettoyage
        ──▶ chunking ──▶ métadonnées ──▶ embeddings (L089) ──▶ base vectorielle
                  ▲                                                   │
                  └──────── ingestion incrémentale (empreintes) ◀─────┘
```

Le code de cette leçon construit un paquet `ingestion/` réutilisé tel quel en L094. Installez : `pip install pypdf python-docx beautifulsoup4 lxml tiktoken`.

## 2. Parsing : extraire du texte *et* de la structure

### 2.1 PDF natifs avec pypdf

[pypdf](https://pypdf.readthedocs.io/) lit les PDF dont le texte est encodé (exportés depuis Word, LibreOffice, un ERP). Chaque page devient une chaîne ; nous gardons le **numéro de page**, indispensable pour citer « p. 4 » dans la réponse.

```python
# ingestion/parsers.py — lecteurs PDF / DOCX / HTML renvoyant des blocs (texte + métadonnées)
from dataclasses import dataclass, field
from pathlib import Path
import re

@dataclass
class Bloc:
    texte: str
    meta: dict = field(default_factory=dict)   # page, section, source…

def lire_pdf(chemin: Path) -> list[Bloc]:
    from pypdf import PdfReader
    reader = PdfReader(str(chemin))
    blocs = []
    for num, page in enumerate(reader.pages, start=1):
        texte = page.extract_text() or ""
        texte = re.sub(r"[ \t]+\n", "\n", texte)              # espaces en fin de ligne
        texte = re.sub(r"\n{3,}", "\n\n", texte).strip()      # lignes vides en rafale
        if texte:
            blocs.append(Bloc(texte, {"page": num}))
    return blocs

def pdf_est_scanne(chemin: Path, seuil_caracteres: int = 50) -> bool:
    """Un PDF scanné contient des images et (presque) aucun texte extractible."""
    from pypdf import PdfReader
    reader = PdfReader(str(chemin))
    pages_test = reader.pages[: min(3, len(reader.pages))]
    return all(len((p.extract_text() or "").strip()) < seuil_caracteres for p in pages_test)

def lire_docx(chemin: Path) -> list[Bloc]:
    """Garde la hiérarchie des titres Word (styles 'Heading 1', 'Titre 1'…) comme section courante."""
    import docx
    doc = docx.Document(str(chemin))
    blocs, section, courant = [], "Introduction", []
    for p in doc.paragraphs:
        style = (p.style.name or "").lower()
        if style.startswith(("heading", "titre")) and p.text.strip():
            if courant:
                blocs.append(Bloc("\n".join(courant), {"section": section}))
            section, courant = p.text.strip(), []
        elif p.text.strip():
            courant.append(p.text.strip())
    if courant:
        blocs.append(Bloc("\n".join(courant), {"section": section}))
    # Les tableaux Word deviennent des lignes "cellule | cellule"
    for t in doc.tables:
        lignes = [" | ".join(c.text.strip() for c in row.cells) for row in t.rows]
        blocs.append(Bloc("\n".join(lignes), {"section": section, "type": "tableau"}))
    return blocs

def lire_html(chemin: Path) -> list[Bloc]:
    """FAQ HTML : chaque question (h2/h3) + sa réponse forme un bloc autonome."""
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(chemin.read_text(encoding="utf-8"), "lxml")
    for balise in soup(["script", "style", "nav", "footer", "header"]):
        balise.decompose()
    blocs, question, reponse = [], None, []
    for el in soup.find_all(["h2", "h3", "p", "li"]):
        if el.name in ("h2", "h3"):
            if question:
                blocs.append(Bloc(f"Question : {question}\nRéponse : {' '.join(reponse)}", {"section": question, "type": "faq"}))
            question, reponse = el.get_text(" ", strip=True), []
        elif question:
            reponse.append(el.get_text(" ", strip=True))
    if question:
        blocs.append(Bloc(f"Question : {question}\nRéponse : {' '.join(reponse)}", {"section": question, "type": "faq"}))
    return blocs

LECTEURS = {".pdf": lire_pdf, ".docx": lire_docx, ".html": lire_html, ".htm": lire_html}

def lire(chemin: Path) -> list[Bloc]:
    lecteur = LECTEURS.get(chemin.suffix.lower())
    if lecteur is None:
        raise ValueError(f"Format non géré : {chemin.suffix}")
    if chemin.suffix.lower() == ".pdf" and pdf_est_scanne(chemin):
        raise RuntimeError(f"{chemin.name} semble scanné : passez-le par l'OCR (section 2.2)")
    blocs = lecteur(chemin)
    for b in blocs:
        b.meta["source"] = chemin.name
    return blocs
```

Remarquez le traitement de la FAQ : **une question + sa réponse = un bloc**. C'est le découpage le plus naturel qui soit, et il bat n'importe quel algorithme générique. Règle d'or : quand le document a une structure, respectez-la.

### 2.2 PDF scannés : l'OCR

Les anciennes procédures de Bréval sont parfois des scans signés. `pdf_est_scanne()` les détecte ; envoyez-les à un service d'OCR. Deux options sourcées : **Mistral OCR 4.1** ([fiche](https://docs.mistral.ai/models/ocr-4-1)), tarifé 4 $ pour 1 000 pages (nov. 2026), qui renvoie du Markdown avec les tableaux ; ou le **support PDF natif de Claude** ([PDF support](https://platform.claude.com/docs/en/build-with-claude/pdf-support)) qui lit texte *et* images des pages (jusqu'à 600 pages et 128 Mo par requête, nov. 2026) — utile pour demander une transcription structurée page par page. Dans les deux cas, stockez le résultat en Markdown à côté du PDF d'origine et ingérez le Markdown : l'OCR ne se refait pas à chaque exécution.

> 💡 **À retenir** — Pour un petit corpus que vous interrogez souvent, il existe une alternative au RAG : charger les documents via la [Files API](https://platform.claude.com/docs/en/build-with-claude/files) (GA, 500 Mo par fichier, expiration 1 h à 90 jours — nov. 2026) et les référencer dans chaque requête avec le prompt caching. En dessous de quelques centaines de pages, c'est parfois plus simple et plus fidèle qu'un RAG. Au-delà, ou avec des filtres par service, le RAG s'impose.

```quiz
{
  "q": "Comment la fonction `pdf_est_scanne()` de cette leçon repère-t-elle un PDF scanné ?",
  "options": [
    "Elle lit la date de création inscrite dans le fichier",
    "Elle envoie les trois premières pages à un service d'OCR",
    "Elle compte les caractères extraits des premières pages",
    "Elle vérifie que l'extension du fichier est bien .pdf"
  ],
  "answer": 2,
  "explanation": "Un scan est une photo de page : pypdf n'y trouve (presque) aucun texte. Si chacune des trois premières pages donne moins de 50 caractères, le fichier part à l'OCR au lieu d'être ingéré vide."
}
```

```mission
{
  "title": "Chasse à l'info : les limites du PDF natif de Claude",
  "url": "https://platform.claude.com/docs/en/build-with-claude/pdf-support",
  "steps": [
    "Ouvrez la page « PDF support » de la documentation Claude",
    "Repérez le tableau ou le paragraphe des limites (« PDF support requirements »)",
    "Notez le nombre maximal de pages et la taille maximale de requête"
  ],
  "question": "Combien de pages et quelle taille de requête au maximum pouvez-vous envoyer pour faire lire un PDF scanné à Claude ?",
  "hint": "La leçon donne un ordre de grandeur au § 2.2 ; vérifiez qu'il est toujours d'actualité.",
  "answer": "Jusqu'à 600 pages et 128 Mo par requête (nov. 2026 ; la taille maximale des requêtes Messages est passée de 32 à 128 Mo le 28 oct. 2026). Les limites évoluent : relisez la page avant de dimensionner (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Chunking : découper sans casser le sens

### 3.1 Pourquoi découper ?

Trois raisons. Le modèle d'embedding a une **longueur maximale** (souvent 512 à 8 192 tokens) et, surtout, un vecteur qui résume 3 000 mots devient une moyenne floue : la question « plafond repas » ne ressemble plus au vecteur d'un chapitre entier. Ensuite, le **prompt final** a un budget : cinq morceaux de 300 tokens, c'est 1 500 tokens de contexte ; cinq chapitres, c'est 15 000. Enfin, la **citation** : on cite un paragraphe, pas un document.

### 3.2 Trois stratégies

| Stratégie | Principe | Avantages | Inconvénients |
|---|---|---|---|
| **Taille fixe** | tous les N tokens, chevauchement de 10-20 % | simple, prévisible | coupe au milieu des phrases et tableaux |
| **Récursive** | essaie de couper aux `\n\n`, puis `\n`, puis `. `, puis espace, jusqu'à tenir dans N tokens | respecte paragraphes et phrases ; standard de fait (LangChain `RecursiveCharacterTextSplitter`) | ignore le sens |
| **Sémantique** | calcule l'embedding de chaque phrase et coupe là où la similarité entre phrases voisines chute | morceaux thématiquement homogènes | coûte des embeddings à l'ingestion ; tailles irrégulières |

> 💡 **Autrement dit** — Taille fixe = couper une baguette tous les 10 cm, même au milieu d'un mot. Récursif = couper d'abord entre les paragraphes, puis entre les phrases, et seulement si c'est encore trop long. Sémantique = couper là où le sujet change. Le récursif est le bon point de départ dans la grande majorité des cas.

Les leçons « Text chunking strategies » du cours [Building with the Claude API](https://academy.claude.com/courses/building-with-the-claude-api) partent du même constat : commencer récursif, mesurer, raffiner.

```python
# ingestion/chunking.py — découpage récursif en tokens, avec chevauchement, sans dépendance framework
import re
import tiktoken
from .parsers import Bloc

enc = tiktoken.get_encoding("cl100k_base")   # compteur de tokens approximatif, suffisant pour dimensionner

def n_tokens(s: str) -> int:
    return len(enc.encode(s))

SEPARATEURS = ["\n\n", "\n", ". ", " "]

def decouper_recursif(texte: str, max_tokens: int = 300, chevauchement: int = 40, _niveau: int = 0) -> list[str]:
    if n_tokens(texte) <= max_tokens:
        return [texte.strip()] if texte.strip() else []
    if _niveau >= len(SEPARATEURS):            # dernier recours : coupe brute en tokens
        ids = enc.encode(texte)
        pas = max_tokens - chevauchement
        return [enc.decode(ids[i:i + max_tokens]) for i in range(0, len(ids), pas)]
    sep = SEPARATEURS[_niveau]
    fragments = texte.split(sep)
    morceaux, courant = [], ""
    for frag in fragments:
        candidat = (courant + sep + frag) if courant else frag
        if n_tokens(candidat) <= max_tokens:
            courant = candidat
        else:
            if courant:
                morceaux.append(courant)
            # le fragment seul est trop long -> descendre d'un niveau de séparateur
            courant = frag if n_tokens(frag) <= max_tokens else ""
            if not courant:
                morceaux.extend(decouper_recursif(frag, max_tokens, chevauchement, _niveau + 1))
    if courant:
        morceaux.append(courant)
    # chevauchement : on préfixe chaque morceau par la fin du précédent
    resultat = []
    for i, m in enumerate(morceaux):
        if i > 0 and chevauchement > 0:
            queue = enc.decode(enc.encode(morceaux[i - 1])[-chevauchement:])
            m = queue + sep + m
        resultat.append(m.strip())
    return resultat

def decouper_blocs(blocs: list[Bloc], max_tokens: int = 300, chevauchement: int = 40) -> list[Bloc]:
    """Découpe chaque bloc en conservant ses métadonnées et en numérotant les morceaux."""
    sortie, position = [], 0
    for b in blocs:
        if b.meta.get("type") in ("faq", "tableau") and n_tokens(b.texte) <= 2 * max_tokens:
            parts = [b.texte]                  # une FAQ ou un petit tableau ne se coupe pas
        else:
            parts = decouper_recursif(b.texte, max_tokens, chevauchement)
        for p in parts:
            sortie.append(Bloc(p, {**b.meta, "position": position, "tokens": n_tokens(p)}))
            position += 1
    return sortie
```

Le **découpage sémantique** se code en vingt lignes avec `embed()` de L089 : vectorisez chaque phrase, calculez le cosinus entre phrases consécutives, coupez quand il passe sous un percentile (par ex. le 20ᵉ percentile des similarités du document). Réservez-le aux documents longs sans structure (comptes rendus, courriers) ; sur des procédures titrées, le récursif + respect des titres suffit.

### 3.3 Quelle taille ?

Il n'y a pas de bonne réponse universelle, mais une méthode. Partez de **256 à 512 tokens** avec 10-15 % de chevauchement. Puis, avec le jeu de test de L093, mesurez le rappel du contexte pour 200, 400 et 800 tokens : la courbe parle d'elle-même. Deux repères : les FAQ et procédures courtes aiment les petits morceaux (200-300) ; les contrats et rapports, les plus grands (500-800) avec un titre de section répété en tête de chaque morceau.

> ⚠️ **Piège fréquent** — Compter en **caractères** plutôt qu'en tokens. « 1 000 caractères » en français ≈ 280 tokens ; en code ou en tableau, le rapport change du tout au tout. Mesurez en tokens, c'est l'unité du modèle et de la facture.

> 🎮 **Défi** — Prenez la procédure « notes de frais » (ou n'importe quel PDF de 5 pages). Découpez-la en 150, 300 et 1 000 tokens. Pour chaque taille, cherchez « plafond repas » et regardez le premier morceau renvoyé : lequel contient réellement le chiffre ?

```quiz
{
  "q": "La FAQ RH de Bréval compte 100 questions courtes. Quel découpage choisir ?",
  "options": [
    "Des morceaux fixes de 2 000 tokens pour tout garder ensemble",
    "Un découpage sémantique phrase par phrase",
    "Le document entier en un seul vecteur",
    "Une entrée = une question et sa réponse"
  ],
  "answer": 3,
  "explanation": "Quand le document a une structure, on la respecte : une entrée de FAQ est une unité de sens autonome. Un morceau à cheval sur deux questions mélangerait deux sujets dans un même vecteur."
}
```

```mission
{
  "title": "Chasse à l'info : le prix de l'OCR Mistral",
  "url": "https://docs.mistral.ai/models/ocr-4-1",
  "steps": [
    "Ouvrez la fiche du modèle Mistral OCR 4.1",
    "Repérez la section des tarifs (pricing)",
    "Notez le prix pour 1 000 pages et le format de sortie"
  ],
  "question": "Combien coûte l'OCR de 1 000 pages avec Mistral OCR 4.1, et sous quel format le texte est-il renvoyé ?",
  "hint": "Le format de sortie est celui que nous conseillons de stocker à côté du PDF.",
  "answer": "4 $ pour 1 000 pages, résultat en Markdown avec les tableaux (tarif relevé en nov. 2026, susceptible d'évoluer).",
  "xp": 10
}
```

## 4. Métadonnées : ce qui transforme un tas de vecteurs en base documentaire

Chaque morceau porte, au minimum : `source` (nom de fichier), `page` ou `section`, `position`, `service` (déduit du dossier ou d'un fichier de configuration), `version` ou `date_document`, `checksum` du fichier. Elles servent à **filtrer** (« seulement RH »), à **citer** (« notes-de-frais-v3.pdf, p. 2 »), à **désindexer** (toutes les lignes d'un document retiré) et à **déboguer** (« pourquoi ce morceau est remonté ? »).

Une technique peu coûteuse et très efficace : **préfixer le texte du morceau par son contexte** avant de le vectoriser, par exemple `"[Procédure notes de frais v3 — section Plafonds] " + texte`. Le vecteur sait désormais de quoi il parle même si le paragraphe ne répète pas le sujet. L092 ira plus loin avec le *contextual retrieval* (un résumé de contexte généré par un LLM pour chaque morceau).

## 5. Ingestion incrémentale et déduplication

Le piège classique : un script qui ré-ingère tout chaque nuit. Résultat après une semaine : sept copies de chaque morceau, et des réponses qui citent sept fois la même page. La solution tient en une **empreinte** (SHA-256 du fichier) et une table de suivi.

```python
# ingestion/pipeline.py — ingestion incrémentale vers pgvector (schéma de L089)
import hashlib, json, os
from pathlib import Path
import psycopg
from pgvector.psycopg import register_vector
from embeddings import embed
from .parsers import lire
from .chunking import decouper_blocs

DSN = os.environ["PG_DSN"]
SERVICES = {"rh": "RH", "logistique": "Logistique", "compta": "Compta"}   # dossier -> service

def empreinte(chemin: Path) -> str:
    h = hashlib.sha256()
    with chemin.open("rb") as f:
        for morceau in iter(lambda: f.read(1 << 20), b""):
            h.update(morceau)
    return h.hexdigest()

def ingerer_dossier(racine: Path, taille: int = 300, chevauchement: int = 40) -> dict:
    stats = {"nouveaux": 0, "inchanges": 0, "mis_a_jour": 0, "supprimes": 0, "erreurs": []}
    with psycopg.connect(DSN) as conn:
        register_vector(conn)
        connus = {src: (doc_id, chk) for doc_id, src, chk in conn.execute("SELECT id, source, checksum FROM documents")}
        vus = set()
        for chemin in sorted(p for p in racine.rglob("*") if p.suffix.lower() in (".pdf", ".docx", ".html", ".htm")):
            source = str(chemin.relative_to(racine))
            vus.add(source)
            chk = empreinte(chemin)
            if source in connus and connus[source][1] == chk:
                stats["inchanges"] += 1
                continue                                   # rien n'a changé : on ne re-vectorise pas
            try:
                blocs = decouper_blocs(lire(chemin), taille, chevauchement)
            except Exception as e:                         # PDF scanné, fichier corrompu…
                stats["erreurs"].append(f"{source}: {e}")
                continue
            service = SERVICES.get(chemin.parent.name.lower(), "Général")
            with conn.transaction():                       # tout ou rien par document
                if source in connus:                       # version modifiée : on remplace
                    conn.execute("DELETE FROM documents WHERE id = %s", (connus[source][0],))  # CASCADE sur chunks
                    stats["mis_a_jour"] += 1
                else:
                    stats["nouveaux"] += 1
                doc_id = conn.execute(
                    "INSERT INTO documents (source, checksum, service) VALUES (%s, %s, %s) RETURNING id",
                    (source, chk, service)).fetchone()[0]
                textes = [f"[{chemin.stem} — {b.meta.get('section', 'p.' + str(b.meta.get('page', '?')))}] {b.texte}" for b in blocs]
                vecteurs = embed(textes)                   # un seul appel pour tout le document
                conn.cursor().executemany(
                    "INSERT INTO chunks (document_id, page, position, contenu, embedding, metadata) VALUES (%s, %s, %s, %s, %s, %s)",
                    [(doc_id, b.meta.get("page"), b.meta["position"], t, v, json.dumps(b.meta, ensure_ascii=False))
                     for b, t, v in zip(blocs, textes, vecteurs)])
        # fichiers disparus du dossier : on les retire de l'index
        for source, (doc_id, _) in connus.items():
            if source not in vus:
                conn.execute("DELETE FROM documents WHERE id = %s", (doc_id,))
                stats["supprimes"] += 1
    return stats

if __name__ == "__main__":
    print(json.dumps(ingerer_dossier(Path(os.environ.get("DOCS_DIR", "./procedures"))), ensure_ascii=False, indent=2))
```

Ce script est **idempotent** : lancé deux fois de suite, la seconde exécution ne touche à rien. Une version modifiée d'une procédure remplace l'ancienne dans la même transaction ; un fichier supprimé disparaît de l'index. Pour Qdrant ou Chroma, le même principe s'applique avec l'identifiant stable vu en L089 (`uuid5(source#page#position)`) et une suppression par filtre `source = …`.

Deux raffinements pour la production : une **déduplication au niveau des morceaux** (deux procédures qui partagent le même paragraphe d'avertissement — empreinte du texte normalisé, on ne garde qu'une entrée par texte et on liste les sources), et une **file de traitement** (chaque fichier = une tâche, rejouable) dès que l'ingestion dépasse quelques minutes.

> 🔗 **Documentation officielle** — [pypdf](https://pypdf.readthedocs.io/) 🇬🇧 · [python-docx](https://python-docx.readthedocs.io/) 🇬🇧 · [Beautiful Soup](https://www.crummy.com/software/BeautifulSoup/bs4/doc/) 🇬🇧 · [Claude Cookbook — RAG guide](https://platform.claude.com/cookbook/capabilities-retrieval-augmented-generation-guide) 🇬🇧

```quiz
{
  "type": "vrai_faux",
  "q": "Un fichier dont l'empreinte SHA-256 est identique à celle enregistrée en base n'a pas besoin d'être redécoupé ni re-vectorisé.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai. L'empreinte change dès qu'un seul octet du fichier change : si elle est identique, le contenu l'est aussi. C'est ce qui rend l'ingestion nocturne idempotente et bon marché."
}
```

## 🧪 Exercice pratique

**Consigne.** Constituez un corpus de test pour Bréval Matériaux : trois PDF (générez-les depuis LibreOffice ou Word : une procédure notes de frais avec un tableau de plafonds, une consigne sécurité, une procédure de retour fournisseur), un DOCX avec des titres, et une FAQ HTML de dix questions. Faites tourner `ingerer_dossier()` et répondez :

1. Combien de morceaux par document, et quelle distribution de tailles en tokens (min / médiane / max) ?
2. Le tableau des plafonds est-il intact dans un seul morceau ? Sinon, quelle règle ajouter ?
3. Modifiez une phrase dans la FAQ, relancez : seule la FAQ doit être ré-indexée (`mis_a_jour: 1, inchanges: 4`).
4. Supprimez un PDF, relancez : `supprimes: 1`, et plus aucun morceau de ce document en base.

**Critères de réussite.** Aucun doublon après trois exécutions (`SELECT source, count(*) FROM chunks JOIN documents … GROUP BY source` stable) ; chaque morceau a `source`, `page` ou `section`, `position` ; le tableau est entier ; un PDF scanné (imprimez une page puis photographiez-la en PDF) est refusé avec un message clair et non ingéré silencieusement.

**Pistes de corrigé.** Pour le tableau, repérez dans `lire_pdf` les lignes contenant plusieurs nombres séparés par des espaces et marquez le bloc `type: "tableau"` ; `decouper_blocs` le garde alors entier jusqu'à deux fois la taille cible. Pour la distribution des tailles, `statistics.median([b.meta["tokens"] for b in blocs])`.

## ✅ Auto-évaluation express

1. Pourquoi une FAQ se découpe-t-elle « question + réponse » plutôt qu'en morceaux de 300 tokens ?
2. Quel est le rôle du chevauchement, et quel est son coût ?
3. Comment votre pipeline sait-il qu'un fichier a changé sans le re-vectoriser systématiquement ?

**Réponses.** 1. La structure du document est le meilleur découpage : une entrée de FAQ est une unité de sens autonome, et un morceau à cheval sur deux questions mélangerait deux sujets dans un même vecteur. 2. Il évite qu'une phrase importante soit coupée à la frontière de deux morceaux ; il coûte 10-15 % de tokens en plus à l'indexation et au stockage, et peut faire remonter deux morceaux quasi identiques (à dédupliquer au moment de construire le prompt). 3. Par l'empreinte SHA-256 du fichier comparée à celle stockée dans `documents.checksum` ; seul un fichier dont l'empreinte diffère est relu, redécoupé et re-vectorisé dans une transaction.

## 📚 Pour aller plus loin
- [Claude Cookbook — RAG guide](https://platform.claude.com/cookbook/capabilities-retrieval-augmented-generation-guide) 🇬🇧 — pipeline complet avec évaluation, par Anthropic.
- [Mistral OCR 4.1](https://docs.mistral.ai/models/ocr-4-1) 🇬🇧 — OCR en Markdown pour les documents scannés.
- [Claude Platform — PDF support](https://platform.claude.com/docs/en/build-with-claude/pdf-support) 🇬🇧 — limites et usages du PDF natif.
- [LangChain — changelog](https://docs.langchain.com/oss/python/releases/changelog.md) 🇬🇧 — pour suivre l'évolution des *text splitters* et loaders (L091).

> 🗺️ **Et maintenant ?** — la leçon L091 refait ce pipeline en quelques dizaines de lignes avec LangChain et LlamaIndex, pour que vous sachiez quand un framework vous fait gagner du temps… et quand il vous en fait perdre.
