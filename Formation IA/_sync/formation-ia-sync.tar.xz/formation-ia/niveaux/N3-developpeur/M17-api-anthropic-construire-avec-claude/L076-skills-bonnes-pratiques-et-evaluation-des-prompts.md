---
id: L076
module: M17
level: N3
title: "Skills, bonnes pratiques et évaluation des prompts"
minutes: 45
objectives:
  - "Créer un Agent Skill (SKILL.md) et l'utiliser dans Claude Code, l'Agent SDK et l'API, en distinguant skill, outil, serveur MCP et subagent"
  - "Construire une suite d'évaluation de prompts : jeu de tests, notation par code et par modèle (LLM-as-judge), métriques, seuil de non-régression"
  - "Appliquer les bonnes pratiques officielles de fiabilité (réduire les hallucinations, augmenter la cohérence, réduire la latence)"
skills: ["C3.2", "C3.4"]
sources:
  - { title: "Claude Platform — Agent Skills overview", url: "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview", lang: "en" }
  - { title: "Claude Platform — Skills guide", url: "https://platform.claude.com/docs/en/build-with-claude/skills-guide", lang: "en" }
  - { title: "Claude Code — Skills", url: "https://code.claude.com/docs/en/skills.md", lang: "en" }
  - { title: "Claude Platform — Define success criteria and build evals", url: "https://platform.claude.com/docs/en/test-and-evaluate/develop-tests", lang: "en" }
  - { title: "Claude Platform — Increase output consistency", url: "https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/increase-consistency", lang: "en" }
  - { title: "Claude Platform — Reduce latency", url: "https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency", lang: "en" }
  - { title: "Claude Cookbook — Building evals", url: "https://platform.claude.com/cookbook/misc-building-evals", lang: "en" }
  - { title: "Anthropic — dépôt skills (GitHub)", url: "https://github.com/anthropics/skills", lang: "en" }
  - { title: "DeepLearning.AI — Agent Skills with Anthropic", url: "https://www.deeplearning.ai/courses/agent-skills-with-anthropic", lang: "en" }
---

# Skills, bonnes pratiques et évaluation des prompts

> ⏱ 45 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Empaqueter un savoir-faire métier (« comment ce cabinet rédige une lettre de relance ») dans un **skill** portable, lu par Claude Code, l'Agent SDK et l'API.
- Répondre sans hésiter à la question d'examen « skill, outil, MCP ou subagent ? ».
- Remplacer « ça a l'air de marcher » par un **score** : jeu de tests, notation automatique, seuil de non-régression, exécuté avant chaque changement de prompt ou de modèle.
- Mobiliser les pages officielles de fiabilité quand un prompt hallucine, varie ou répond trop lentement.

> 🧭 **En clair** — Deux idées dans cette leçon. 1) Un **skill**, c'est une **fiche recette plastifiée** rangée dans le classeur de la cuisine : sur la tranche, seul le titre et une ligne de description sont visibles (« Lettre de relance — à utiliser pour tout impayé ») ; Claude n'ouvre la fiche complète que lorsqu'une commande la réclame. Vous pouvez donc ranger cent fiches sans encombrer le plan de travail. 2) **Évaluer un prompt**, c'est organiser une **dégustation à l'aveugle** avant d'ajouter un plat à la carte : un jeu de cas tests, une grille de notation (par un programme ou par un « juge » IA), une note minimale à atteindre. Si une nouvelle version du prompt fait baisser la note, elle ne part pas en production.

## 1. Agent Skills : des procédures que Claude charge à la demande

### 1.1 Le principe

Un **skill** est un dossier contenant un fichier `SKILL.md` (en-tête YAML `name` + `description`, puis des instructions en Markdown) et, en option, des scripts, modèles et références. L'idée clé, expliquée sur la page [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview), est la **divulgation progressive** : seuls le nom et la description restent en permanence dans le contexte ; le corps du skill n'est chargé **que lorsque la tâche le requiert**. Vous pouvez donc donner à Claude cent procédures sans saturer la fenêtre de contexte.

> 💡 **Autrement dit** — « Divulgation progressive » veut dire : **montrer d'abord l'étiquette, ouvrir le contenu seulement si besoin**. Un *frontmatter YAML* est simplement l'en-tête du fichier, entre deux lignes `---`, où l'on écrit des réglages sous la forme `clé: valeur`.

```
CONTEXTE DE CLAUDE (toujours chargé)          DISQUE (chargé à la demande)
┌───────────────────────────────────┐        ┌──────────────────────────────────┐
│ lettre-relance-impayes : « Rédige │ ─────► │ SKILL.md complet (étapes, règles)│
│  une lettre de relance… »         │ si la  │ modeles/niveau-1.md … niveau-3.md│
│ devis-menuiserie : « Chiffre… »   │ demande│ scripts/, références…            │
│ … 98 autres descriptions          │ colle  └──────────────────────────────────┘
└───────────────────────────────────┘
```

Anthropic fournit des skills pré-construits (création de **pptx, xlsx, docx, pdf**) et publie le dépôt [anthropics/skills](https://github.com/anthropics/skills) ; le format est devenu un standard ouvert (agentskills.io) lu aussi par Codex CLI, Cursor et d'autres agents (recherche §04).

### 1.2 Écrire un skill métier

```markdown
---
name: lettre-relance-impayes
description: Rédige une lettre de relance pour facture impayée selon la procédure du cabinet Dupont (3 niveaux : amiable, ferme, mise en demeure). À utiliser dès qu'on demande une relance, un rappel de paiement ou une mise en demeure.
---

# Lettre de relance — procédure du cabinet

## Quand l'utiliser
Toute demande de relance client pour facture échue. Demander le niveau si non précisé.

## Étapes
1. Vérifier dans la demande : nom du client, n° et date de facture, montant TTC, date d'échéance, niveau (1, 2 ou 3).
2. Calculer le retard en jours (date du jour − échéance).
3. Choisir le modèle correspondant dans `modeles/niveau-{n}.md` et le remplir.
4. Niveau 3 uniquement : rappeler l'article L441-10 du Code de commerce (pénalités de retard et indemnité forfaitaire
   de 40 € pour frais de recouvrement) ; ne jamais inventer un taux de pénalité : utiliser celui des CGV fournies,
   sinon écrire « [taux selon CGV] ».
5. Ton : niveau 1 cordial, niveau 2 ferme et factuel, niveau 3 formel (« Par la présente… »).

## Vérifications avant de rendre
- Aucune donnée manquante remplacée par une invention : utiliser des crochets [À COMPLÉTER].
- Montant en toutes lettres pour le niveau 3.
- Longueur ≤ 1 page.
```

Arborescence : `.claude/skills/lettre-relance-impayes/SKILL.md` + `modeles/niveau-1.md`, `niveau-2.md`, `niveau-3.md`. Dans Claude Code (page [Skills](https://code.claude.com/docs/en/skills.md)), un skill est appelé automatiquement par le modèle quand la description correspond, ou manuellement par `/lettre-relance-impayes`. Le frontmatter admet des options : `allowed-tools` (restreindre les outils), `context: fork` (exécuter dans un sous-contexte), `disable-model-invocation` (manuel uniquement), `paths` (activation selon les fichiers). Les skills se placent dans `.claude/skills/` (projet) ou `~/.claude/skills/` (personnel), et se partagent via des **plugins**.

Le même skill s'utilise avec l'**Agent SDK** (option `skills` / répertoire de skills, page `agent-sdk/skills`) et avec la **Messages API** via les fonctionnalités de skills de la plateforme (page [Skills guide](https://platform.claude.com/docs/en/build-with-claude/skills-guide)) : un skill est ainsi **portable** entre les trois surfaces, point insisté dans le cours partenaire « Claude Code, MCP & Integration ».

### 1.3 Skill, outil, MCP ou subagent ?

| Besoin | Solution | Pourquoi |
|---|---|---|
| Enseigner **une procédure** (comment faire, dans quel ordre, avec quels modèles) | **Skill** | instructions + fichiers, chargés à la demande |
| Donner **une capacité** (lire une base, envoyer un e-mail) | **Outil** (L070) | action exécutée par du code |
| Partager cette capacité entre plusieurs hôtes / équipes | **Serveur MCP** (L075) | protocole standard, découverte dynamique |
| Isoler une sous-tâche longue dans son **propre contexte** avec des outils restreints | **Subagent** (L074) | évite de polluer le contexte principal |

Le cours « Agent Skills with Anthropic » (DeepLearning.AI, 2 h 19) et « Introduction to agent skills » (Claude Academy, 1 h) consacrent chacun une leçon à cette distinction : c'est aussi une question type des certifications Architect et Developer.

> ⚠️ **Piège fréquent** — Une description de skill trop vague (« Aide pour la compta »). Comme pour les outils, c'est la **description** qui déclenche le chargement : indiquez les mots-clés des demandes qui doivent l'activer et ceux qui ne le doivent pas.


```quiz
{
  "q": "Le cabinet veut que Claude applique sa procédure maison de relance (3 niveaux, modèles de lettres, vérifications), dans Claude Code comme dans l'Agent SDK. Que créez-vous ?",
  "options": ["Un outil client relance() en Python", "Un serveur MCP dédié à la relance", "Un subagent relecteur en lecture seule", "Un skill avec SKILL.md et ses modèles"],
  "answer": 3,
  "explanation": "Enseigner une procédure (quoi faire, dans quel ordre, avec quels modèles) relève du skill, portable entre Claude Code, l'Agent SDK et l'API. Un outil donne une capacité d'action, MCP la partage entre hôtes, un subagent isole une sous-tâche."
}
```

```mission
{
  "title": "Chasse au frontmatter : les réglages d'un skill dans Claude Code",
  "url": "https://code.claude.com/docs/en/skills.md",
  "steps": ["Ouvrez la page Skills de la documentation Claude Code", "Repérez où placer un skill de projet et un skill personnel", "Parcourez le tableau des champs du frontmatter et trouvez celui qui restreint les outils et celui qui interdit l'appel automatique par le modèle"],
  "question": "Dans quels dossiers placer un skill (projet et personnel), et quels champs du frontmatter restreignent les outils et réservent le skill à un appel manuel ?",
  "hint": "Les deux champs s'écrivent en kebab-case (avec des tirets).",
  "answer": ".claude/skills/ (projet) et ~/.claude/skills/ (personnel) ; allowed-tools restreint les outils ; disable-model-invocation réserve le skill à l'appel manuel /nom-du-skill (documentation consultée en nov. 2026).",
  "xp": 15
}
```

## 2. Évaluer les prompts : de l'opinion à la mesure

### 2.1 La méthode officielle

La page [Define success criteria and build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) propose une démarche en quatre temps : (1) des critères **SMART** (spécifiques, mesurables, atteignables, pertinents, temporels : « 95 % des devis extraits ont un total exact », « latence p95 < 3 s »), (2) un **jeu de tests** représentatif, cas limites compris, (3) des **notateurs** automatiques, (4) un seuil et une exécution systématique. Trois familles de notation :

| Notateur | Exemple | Quand |
|---|---|---|
| **Code** (exact match, regex, JSON valide, tests unitaires) | le total extrait == total attendu | sortie déterministe |
| **Similarité** (cosinus sur embeddings SBERT, ROUGE-L) | résumé proche d'un résumé de référence | texte libre avec référence |
| **LLM-as-judge** (Likert 1-5, binaire, ordinal) | un modèle note la politesse et l'absence de conseil fiscal | qualité subjective ; **noter avec un modèle différent ou plus fort**, avec une grille explicite |

Le cours « Building with the Claude API » (module 3) ajoute une étape souvent oubliée : **générer le jeu de tests avec Claude** (variations, cas difficiles), puis le faire relire par un humain.


```quiz
{
  "q": "Vous voulez vérifier automatiquement que les réponses de votre assistant restent polies et ne donnent aucun conseil fiscal personnalisé. Quel notateur choisir ?",
  "options": ["Un exact match sur la réponse attendue", "Une similarité ROUGE-L avec une réponse de référence", "Un juge LLM (autre modèle) avec une grille explicite", "Une expression régulière qui cherche le mot « bonjour »"],
  "answer": 2,
  "explanation": "La politesse et l'absence de conseil engageant sont des qualités subjectives : c'est le domaine du LLM-as-judge, avec une grille claire, de préférence binaire ou ordinale, et un juge lui-même validé sur un échantillon noté par des humains."
}
```

```mission
{
  "title": "Chasse aux métriques : les notateurs de la méthode officielle",
  "url": "https://platform.claude.com/docs/en/test-and-evaluate/develop-tests",
  "steps": ["Ouvrez la page « Define success criteria and build evals »", "Repérez la section sur les méthodes de notation (grading)", "Relevez les métriques de similarité citées, puis les types d'échelles proposés pour la notation par un LLM"],
  "question": "Quelles métriques de similarité la page cite-t-elle, et quels types d'échelles propose-t-elle pour la notation par LLM ?",
  "hint": "L'une des métriques s'appuie sur des embeddings de phrases, l'autre est un classique du résumé automatique.",
  "answer": "Similarité cosinus (embeddings SBERT) et ROUGE-L ; pour le LLM-as-judge : échelles de Likert, binaires et ordinales (page consultée en nov. 2026).",
  "xp": 15
}
```

### 2.2 Une suite d'évaluation minimale

```python
# evals.py — évaluation d'un prompt d'extraction de devis : notation code + juge LLM, seuil de non-régression
import json, statistics, sys
from anthropic import Anthropic

client = Anthropic()
PROMPT_VERSION = "extracteur-devis-v3"
SYSTEM = open(f"prompts/{PROMPT_VERSION}.txt", encoding="utf-8").read()
SCHEMA = json.load(open("schemas/devis.json"))
TESTS = json.load(open("tests/devis_tests.json", encoding="utf-8"))   # [{"entree": "...", "attendu": {"total_ht": 854.0, ...}}, ...]

def executer(entree: str) -> dict:
    r = client.messages.create(model="claude-haiku-5-5", max_tokens=600, system=SYSTEM,
                               messages=[{"role": "user", "content": entree}],
                               output_config={"format": {"type": "json_schema", "schema": SCHEMA}})
    return json.loads(r.content[0].text)

def note_code(sortie: dict, attendu: dict) -> float:
    """1.0 si total_ht et nombre de lignes exacts, 0.5 si seul le total est bon, 0 sinon."""
    total_ok = abs(sortie.get("total_ht", -1) - attendu["total_ht"]) < 0.01
    lignes_ok = len(sortie.get("lignes", [])) == attendu["nb_lignes"]
    return 1.0 if total_ok and lignes_ok else 0.5 if total_ok else 0.0

def note_juge(entree: str, sortie: dict) -> int:
    """Juge LLM (modèle différent) : fidélité au document, échelle 1-5, grille explicite."""
    grille = ("Notez de 1 à 5 la FIDÉLITÉ de l'extraction JSON au devis source. 5 = aucune valeur inventée, "
              "toutes les lignes présentes ; 3 = une omission mineure ; 1 = valeurs inventées. "
              "Répondez uniquement par le chiffre.")
    r = client.messages.create(model="claude-sonnet-5-5", max_tokens=5, system=grille,
                               messages=[{"role": "user", "content": f"<devis>{entree}</devis>\n<json>{json.dumps(sortie, ensure_ascii=False)}</json>"}])
    return int(r.content[0].text.strip()[0])

scores_code, scores_juge = [], []
for t in TESTS:
    s = executer(t["entree"])
    scores_code.append(note_code(s, t["attendu"]))
    scores_juge.append(note_juge(t["entree"], s))

exactitude = statistics.mean(scores_code)
fidelite = statistics.mean(scores_juge)
print(f"{PROMPT_VERSION} · {len(TESTS)} cas · exactitude {exactitude:.2%} · fidélité juge {fidelite:.2f}/5")
json.dump({"version": PROMPT_VERSION, "exactitude": exactitude, "fidelite": fidelite},
          open(f"resultats/{PROMPT_VERSION}.json", "w"), indent=2)

SEUIL = 0.95
if exactitude < SEUIL:
    print(f"ÉCHEC : exactitude < {SEUIL:.0%}", file=sys.stderr); sys.exit(1)   # bloque la CI
```

```typescript
// evals.ts — même suite en TypeScript, cas exécutés en parallèle (limite de concurrence simple)
import Anthropic from "@anthropic-ai/sdk";
import { readFileSync, writeFileSync } from "node:fs";

const client = new Anthropic();
const VERSION = "extracteur-devis-v3";
const SYSTEM = readFileSync(`prompts/${VERSION}.txt`, "utf8");
const SCHEMA = JSON.parse(readFileSync("schemas/devis.json", "utf8"));
const TESTS: { entree: string; attendu: { total_ht: number; nb_lignes: number } }[] = JSON.parse(readFileSync("tests/devis_tests.json", "utf8"));

async function executer(entree: string) {
  const r = await client.messages.create({ model: "claude-haiku-5-5", max_tokens: 600, system: SYSTEM,
    messages: [{ role: "user", content: entree }], output_config: { format: { type: "json_schema", schema: SCHEMA } } });
  return JSON.parse(r.content[0].type === "text" ? r.content[0].text : "{}");
}
function noteCode(s: any, a: { total_ht: number; nb_lignes: number }) {
  const totalOk = Math.abs((s.total_ht ?? -1) - a.total_ht) < 0.01;
  const lignesOk = (s.lignes ?? []).length === a.nb_lignes;
  return totalOk && lignesOk ? 1 : totalOk ? 0.5 : 0;
}

async function main() {
  const scores: number[] = [];
  const LOT = 5; // 5 cas en parallèle pour respecter les limites de débit
  for (let i = 0; i < TESTS.length; i += LOT) {
    const tranche = TESTS.slice(i, i + LOT);
    const res = await Promise.all(tranche.map(async (t) => noteCode(await executer(t.entree), t.attendu)));
    scores.push(...res);
  }
  const exactitude = scores.reduce((a, b) => a + b, 0) / scores.length;
  console.log(`${VERSION} · ${TESTS.length} cas · exactitude ${(exactitude * 100).toFixed(1)} %`);
  writeFileSync(`resultats/${VERSION}.json`, JSON.stringify({ version: VERSION, exactitude }, null, 2));
  if (exactitude < 0.95) { console.error("ÉCHEC : sous le seuil"); process.exit(1); }
}
main();
```

Quatre habitudes de production : **versionner** prompts et résultats côte à côte ; exécuter l'évaluation **en CI** à chaque modification de prompt ou de modèle (la page partenaire « Upgrade a client's build » en fait l'étape 1 de toute migration : « Build an eval from the client's questions · Set the bar a new setup has to clear ») ; passer par la **Batch API** (L073) quand le jeu dépasse quelques centaines de cas ; conserver un **jeu caché** que vous ne regardez jamais pendant l'optimisation, pour détecter le sur-ajustement du prompt.

> 💡 **Autrement dit** — Le **jeu caché**, c'est comme les sujets d'examen que l'élève n'a jamais vus : si votre prompt ne réussit que les cas sur lesquels vous l'avez peaufiné, il a « appris par cœur » (*sur-ajustement*) au lieu de comprendre. Un *seuil de non-régression*, c'est la note plancher en dessous de laquelle la nouvelle version est refusée automatiquement.

> 💡 **À retenir** — Un juge LLM est un prompt comme un autre : il doit lui aussi être évalué (sur un échantillon noté par des humains) avant qu'on lui fasse confiance. Et préférez des notations **binaires ou ordinales** à des Likert flous quand c'est possible.

## 3. Bonnes pratiques de fiabilité (pages « Strengthen guardrails »)

| Problème | Pages officielles | Leviers principaux |
|---|---|---|
| **Hallucinations** | reduce-hallucinations | autoriser « je ne sais pas » ; exiger des citations (L072) ; demander d'abord les extraits puis la réponse ; vérifier par un second appel ; sortie structurée avec champ « incertitudes » |
| **Incohérence** entre deux exécutions | [increase-consistency](https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/increase-consistency) | format imposé (schéma JSON), exemples, décomposition en étapes, `effort` adapté ; rappel : `temperature` n'existe plus sur les modèles ≥ 4.7 (et sur tous les modèles avec la version d'API 2026-10-21, celle des SDK v2) |
| **Jailbreaks / injection** | mitigate-jailbreaks | séparation données/instructions, règles d'escalade, filtrage d'entrée (modèle Haiku 5.5 en garde), outils en moindre privilège (M23) |
| **Fuite de prompt** | reduce-prompt-leak | aucun secret dans le prompt ; filtrage de sortie |
| **Latence** | [reduce-latency](https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency) | modèle plus petit, `effort: "low"`, streaming, caching du préfixe, `max_tokens` réaliste, Fast mode (Opus 5.5) |

Ces pages sont concises ; leur contenu exact évolue avec les modèles, consultez-les plutôt que de mémoriser des recettes.


```quiz
{
  "type": "vrai_faux",
  "q": "Pour rendre les réponses de Claude Sonnet 5.5 plus cohérentes d'une exécution à l'autre, la première chose à faire est de fixer temperature à 0.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : temperature n'est plus accepté sur les modèles ≥ 4.7, ni sur aucun modèle avec la version d'API 2026-10-21 des SDK v2 (erreur 400). Les leviers sont un format imposé (schéma JSON), des exemples, la décomposition en étapes et un effort adapté."
}
```

🎮 **Défi** — Votre extracteur passe de 96 % à 91 % d'exactitude après la migration de Haiku 4.5 vers Haiku 5.5. Trois hypothèses à tester, dans l'ordre ? *(1. Le nouveau tokenizer consomme ~30 % de tokens en plus : `max_tokens` trop bas → JSON tronqué ; 2. une consigne martelée devient contre-productive sur 5.5 → la reformuler ; 3. régler `effort: "high"` avant de changer de modèle, comme le recommande le cours de migration.)*

## 🧪 Exercice pratique

**Consigne.**
1. Créez le skill `lettre-relance-impayes` (SKILL.md + 3 modèles) et testez-le dans Claude Code sur trois demandes (niveau précisé, niveau absent, données manquantes).
2. Construisez une suite d'évaluation pour le skill : 12 cas (4 par niveau) avec sorties attendues ; notation code (présence des mentions obligatoires, longueur, absence d'invention : regex sur « [À COMPLÉTER] ») et juge LLM (ton adapté au niveau, 1-5).
3. Faites tourner la suite sur deux versions du skill (avec et sans la section « Vérifications ») et comparez.
4. Fixez un seuil et faites échouer le script quand il n'est pas atteint.

**Critères de réussite.** Le skill se déclenche sans être nommé quand on demande « une relance pour la facture 2026-089 » ; aucune lettre n'invente un taux de pénalité ; la version avec « Vérifications » obtient un meilleur score ; le script renvoie un code de sortie ≠ 0 sous le seuil.

<details>
<summary>Pistes</summary>

- Pour exécuter le skill depuis un script, passez par l'Agent SDK (L074) avec l'option de skills, ou par la Messages API en incluant le contenu du skill dans le system prompt pour le test.
- Juge LLM : utilisez Sonnet 5.5 pour juger Haiku 5.5 ; demandez un JSON `{"ton": 1-5, "justification": "..."}` via sortie structurée.
- Gardez 3 cas « cachés » hors du fichier de tests principal pour vérifier que l'amélioration généralise.
</details>

## ✅ Auto-évaluation express

1. Qu'est-ce que la « divulgation progressive » d'un skill, et pourquoi est-elle importante ?
2. Donnez un exemple de notateur par code, par similarité et par juge LLM.
3. Pourquoi faut-il un jeu de tests caché ?

**Réponses.** 1. Seuls le nom et la description sont en contexte ; le corps est chargé à la demande, ce qui permet des dizaines de skills sans saturer la fenêtre. 2. Exact match sur un total ; cosinus d'embeddings ou ROUGE-L sur un résumé ; notation Likert de la politesse par Sonnet 5.5 avec grille explicite. 3. Pour détecter un prompt sur-ajusté aux cas visibles, qui ne généralise pas.

## 📚 Pour aller plus loin
- [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 — format SKILL.md, skills pré-construits, divulgation progressive.
- [Claude Code — Skills](https://code.claude.com/docs/en/skills.md) 🇬🇧 — options du frontmatter, invocation, partage par plugins.
- [Define success criteria and build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) 🇬🇧 — la méthode officielle et les types de notateurs.
- [Cookbook — Building evals](https://platform.claude.com/cookbook/misc-building-evals) 🇬🇧 et [Generate test cases](https://platform.claude.com/cookbook/misc-generate-test-cases) 🇬🇧 — recettes complètes.
- [Introduction to agent skills (Claude Academy)](https://academy.claude.com/courses/introduction-to-agent-skills) 🇬🇧 — cours gratuit d'une heure avec badge.
- [Agent Skills with Anthropic (DeepLearning.AI)](https://www.deeplearning.ai/courses/agent-skills-with-anthropic) 🇬🇧 — skills dans l'API, Claude Code et l'Agent SDK.

> 🗺️ **Et maintenant ?** — Vous avez tous les ingrédients du module ; la leçon L077 les assemble dans un projet complet : un assistant métier en production, outillé, mis en cache, évalué et chiffré.
