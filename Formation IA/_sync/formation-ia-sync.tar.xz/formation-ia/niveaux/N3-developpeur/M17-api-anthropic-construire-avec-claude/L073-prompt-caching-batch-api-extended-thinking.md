---
id: L073
module: M17
level: N3
title: "Prompt caching, Batch API, extended thinking"
minutes: 50
objectives:
  - "Mettre en cache les parties stables d'un prompt (system, outils, documents) avec cache_control et mesurer le gain dans usage"
  - "Traiter des milliers de requêtes à moitié prix avec la Message Batches API (création, suivi, récupération des résultats)"
  - "Configurer le thinking adaptatif et le paramètre effort, lire les blocs de raisonnement et estimer leur coût"
  - "Combiner ces trois leviers pour diviser par 3 à 10 le coût d'une application en production"
skills: ["C3.1"]
sources:
  - { title: "Claude Platform — Prompt caching", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-caching", lang: "en" }
  - { title: "Claude Platform — Cache diagnostics", url: "https://platform.claude.com/docs/en/build-with-claude/cache-diagnostics", lang: "en" }
  - { title: "Claude Platform — Batch processing", url: "https://platform.claude.com/docs/en/build-with-claude/batch-processing", lang: "en" }
  - { title: "Claude Platform — Thinking", url: "https://platform.claude.com/docs/en/build-with-claude/thinking", lang: "en" }
  - { title: "Claude Platform — Effort", url: "https://platform.claude.com/docs/en/build-with-claude/effort", lang: "en" }
  - { title: "Claude Platform — Context editing / compaction", url: "https://platform.claude.com/docs/en/build-with-claude/context-editing", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — Optimizing for cost and intelligence", url: "https://platform.claude.com/docs/en/about-claude/models/optimizing-for-cost-and-intelligence", lang: "en" }
---

# Prompt caching, Batch API, extended thinking

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Reconnaître dans votre application ce qui est **stable** (system prompt, outils, documents de référence) et le mettre en cache pour payer 10 à 40 fois moins cher en lecture.
- Lancer un lot de 10 000 requêtes pendant la nuit à **−50 %** avec la Batch API, et récupérer les résultats proprement.
- Comprendre le **thinking adaptatif** des modèles Claude 5.5 / Fable 5.1, régler `effort`, et savoir pourquoi « extended thinking » à l'ancienne renvoie une erreur 400.
- Lire `usage` comme un contrôleur de gestion : `cache_creation_input_tokens`, `cache_read_input_tokens`, tokens de raisonnement.

> 🧭 **En clair** — Trois astuces de restaurateur pour payer moins cher. 1) Le **prompt caching**, c'est **réchauffer un plat déjà préparé** au lieu de tout recuisiner : la partie de votre requête qui ne change jamais (consignes, outils, gros document de référence) est préparée une fois, gardée au chaud quelques minutes, puis resservie pour une fraction du prix. 2) La **Batch API**, c'est le **tarif heures creuses** : vous déposez des milliers de commandes le soir, la cuisine les traite quand elle a le temps, et vous payez moitié prix. 3) Le **thinking**, c'est le **brouillon** que Claude griffonne avant de répondre ; le réglage **effort** dit combien de temps vous le laissez réfléchir : peu pour une question simple, beaucoup pour un problème épineux, sachant que le brouillon se paie lui aussi.

## 1. Prompt caching : ne payez pas deux fois le même texte

### 1.1 Le principe

Reprenons l'assistant comptable de L069 : un system prompt de 2 000 tokens, 6 outils (1 500 tokens), un mémento fiscal de 40 000 tokens. Chaque question client renvoie ces 43 500 tokens, pour une question de 50 tokens. Sans cache, 1 000 questions = 43,5 M tokens d'entrée = **87 $** avec Sonnet 5.5. Avec le cache, les 43 500 tokens sont **écrits une fois** (×1,25) puis **lus** 999 fois à 0,10 $/MTok (nov. 2026) : ≈ 0,11 $ + 4,35 $ ≈ **4,5 $**. Vingt fois moins.

La page [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) fixe les règles (nov. 2026) :

| Règle | Valeur |
|---|---|
| Taille minimale d'un préfixe cachable | **512 tokens** sur les modèles 5.5 (plus sur certains anciens modèles) |
| Durée de vie (TTL) | **5 min** par défaut, rafraîchie gratuitement à chaque lecture ; option **1 h** (`"ttl": "1h"`) |
| Prix d'écriture | ×1,25 du prix d'entrée (5 min) ; ×2 (1 h) |
| Prix de lecture | ×0,1 du prix d'entrée en général ; **×0,05 pour Opus 5.5 et Sonnet 5.5**, **×0,025 pour Fable 5.1** |
| Points de rupture (`cache_control`) | jusqu'à **4** par requête, placés sur des blocs `system`, `tools`, ou des messages |
| Ordre du préfixe | `tools` → `system` → `messages` ; tout ce qui précède un breakpoint est caché |
| Caching automatique | un `cache_control` à la **racine** de la requête laisse l'API placer les points de rupture pour vous |

Lecture de `usage` : `cache_creation_input_tokens` (tokens écrits dans le cache), `cache_read_input_tokens` (tokens lus), `input_tokens` (tokens non cachés). Le total facturé est la somme pondérée des trois.

```
ORDRE DU PRÉFIXE (lu de gauche à droite)        ce qui est AVANT le 📌 est mis au chaud

 tools ──────────► system ─────────────► messages ───────────────► question du jour
 [6 outils] 📌    [rôle + mémento] 📌    [historique] 📌            (jamais en cache)
     ▲                   ▲                     ▲
     └── breakpoint 1    └── breakpoint 2      └── breakpoint 3 (max 4 par requête)

Changer UN caractère à gauche d'un 📌  ⇒  tout ce qui suit doit être recuisiné (réécriture ×1,25 ou ×2)
```

> 💡 **Autrement dit** — Un *breakpoint* (`cache_control`), c'est une **étiquette « à garder au chaud »** posée sur un bloc : tout ce qui est avant l'étiquette est conservé. Le *TTL* (*time to live*) est la durée pendant laquelle le plat reste chaud : 5 minutes, prolongées à chaque fois qu'on le ressert, ou 1 heure si vous payez un peu plus cher à la préparation.

### 1.2 Mise en œuvre

```python
# caching.py — system prompt + mémento en cache, puis boucle de questions
import time
from pathlib import Path
from anthropic import Anthropic

client = Anthropic()
MEMENTO = Path("memento_fiscal_2026.txt").read_text(encoding="utf-8")   # ~40 000 tokens

SYSTEM = [
    {"type": "text", "text": "Vous êtes Compta-Assist, assistant d'un cabinet d'expertise comptable nantais. "
                             "Répondez en français, en citant la section du mémento utilisée."},
    {"type": "text", "text": f"<memento>\n{MEMENTO}\n</memento>",
     "cache_control": {"type": "ephemeral", "ttl": "1h"}},   # ← point de rupture : tout ce qui précède est caché
]

def poser(question: str):
    r = client.messages.create(
        model="claude-sonnet-5-5", max_tokens=500,
        system=SYSTEM,
        messages=[{"role": "user", "content": question}],
    )
    u = r.usage
    cout = (u.input_tokens * 2 + u.cache_creation_input_tokens * 2 * 2   # écriture 1 h = ×2
            + u.cache_read_input_tokens * 0.10 + u.output_tokens * 10) / 1e6
    print(f"non caché {u.input_tokens} · écrit {u.cache_creation_input_tokens} · lu {u.cache_read_input_tokens} "
          f"· sortie {u.output_tokens} · ≈ {cout:.4f} $")
    return r.content[0].text

t0 = time.time(); poser("Quel est le seuil de franchise en base de TVA pour un artisan ?"); print("1er appel", round(time.time()-t0, 1), "s")
t0 = time.time(); poser("Et pour une activité de conseil ?");                                print("2e appel", round(time.time()-t0, 1), "s")
```

Au premier appel, `cache_creation_input_tokens ≈ 40 000` ; au second, `cache_read_input_tokens ≈ 40 000` et la latence baisse nettement (le préfixe n'est plus retraité).

```typescript
// caching.ts — définitions d'outils + system en cache (ordre : tools → system → messages)
import Anthropic from "@anthropic-ai/sdk";
import { readFileSync } from "node:fs";

const client = new Anthropic();
const memento = readFileSync("memento_fiscal_2026.txt", "utf8");

const tools: Anthropic.Tool[] = [
  { name: "calcul_tva", description: "Calcule le montant de TVA pour un montant HT et un taux (5.5, 10, 20). À utiliser pour tout calcul de TVA.",
    input_schema: { type: "object", properties: { ht: { type: "number" }, taux: { type: "number" } }, required: ["ht", "taux"] },
    cache_control: { type: "ephemeral" } }, // ← breakpoint n°1 : les outils
];

async function poser(question: string) {
  const r = await client.messages.create({
    model: "claude-sonnet-5-5", max_tokens: 500, tools,
    system: [
      { type: "text", text: "Vous êtes Compta-Assist. Répondez en français." },
      { type: "text", text: `<memento>\n${memento}\n</memento>`, cache_control: { type: "ephemeral" } }, // ← breakpoint n°2
    ],
    messages: [{ role: "user", content: question }],
  });
  const u = r.usage;
  console.log(`non caché ${u.input_tokens} · écrit ${u.cache_creation_input_tokens} · lu ${u.cache_read_input_tokens}`);
}
(async () => { await poser("Seuil de franchise TVA artisan ?"); await poser("Et pour le conseil ?"); })();
```

### 1.3 Pièges et diagnostic

> ⚠️ **Piège fréquent** — **Modifier un seul caractère** du préfixe invalide le cache : un horodatage « Nous sommes le 1er nov. 2026 à 14:32 » dans le system prompt, ou l'ordre des outils qui change d'une requête à l'autre, et vous payez l'écriture à chaque appel. Placez tout ce qui varie **après** le dernier breakpoint.

Autres règles : les images et les documents sont cachables ; le cache est **isolé par organisation** ; un préfixe en dessous de 512 tokens n'est pas caché (sans erreur, simplement `cache_creation_input_tokens: 0`). La page [Cache diagnostics](https://platform.claude.com/docs/en/build-with-claude/cache-diagnostics) explique comment interpréter les compteurs et diagnostiquer un taux de lecture trop faible. Pour les conversations multi-tours, placez un breakpoint sur le **dernier message** : l'historique entier devient le préfixe caché du tour suivant (la page « Tool use with prompt caching » détaille le cas des agents).


```quiz
{
  "q": "Votre taux de lecture du cache est nul : chaque appel affiche cache_creation_input_tokens ≈ 40 000. Votre system prompt commence par « Nous sommes le 5 nov. 2026 à 14:32:07 ». Quelle est la cause la plus probable ?",
  "options": ["Le mémento dépasse la taille maximale qu'un bloc peut mettre en cache", "Sonnet 5.5 ne supporte pas le prompt caching sur le paramètre system", "Il faut ajouter un cinquième breakpoint pour couvrir tout le mémento", "L'horodatage change à chaque appel : le préfixe n'est jamais identique"],
  "answer": 3,
  "explanation": "Le cache exige un préfixe strictement identique. Un horodatage à la seconde le rend différent à chaque requête : vous payez l'écriture à chaque fois. Placez tout ce qui varie après le dernier breakpoint."
}
```

```mission
{
  "title": "Chasse à la syntaxe : comment garder un plat au chaud une heure ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/prompt-caching",
  "steps": ["Ouvrez la page « Prompt caching »", "Cherchez (Ctrl+F) « 1-hour » ou « ttl »", "Relevez la syntaxe exacte du bloc cache_control pour une durée d'une heure, puis le nombre maximal de breakpoints par requête"],
  "question": "Quelle syntaxe de cache_control donne un cache d'une heure, combien de breakpoints une requête peut-elle contenir, et quel multiplicateur s'applique à l'écriture 1 h ?",
  "hint": "Le type reste « ephemeral » ; c'est un champ supplémentaire qui change la durée.",
  "answer": "cache_control: {\"type\": \"ephemeral\", \"ttl\": \"1h\"} ; 4 breakpoints maximum ; écriture 1 h facturée ×2 le prix d'entrée (contre ×1,25 pour 5 min) — documentation consultée en nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 2. Batch API : la nuit, tout est à moitié prix

### 2.1 Quand l'utiliser

Si le résultat n'est pas attendu dans la seconde (classification de 50 000 factures, enrichissement d'un catalogue, évaluation d'un prompt sur 2 000 cas, L076), la [Message Batches API](https://platform.claude.com/docs/en/build-with-claude/batch-processing) traite vos requêtes de manière asynchrone avec une **remise de 50 %** sur l'entrée et la sortie (Sonnet 5.5 : 1 $ / 5 $ par MTok en nov. 2026). Caractéristiques : jusqu'à **100 000 requêtes** ou **256 Mo** par lot ; la plupart des lots terminent en **moins d'une heure** (garantie : 24 h, après quoi les requêtes restantes expirent) ; résultats disponibles **29 jours** ; le cache s'applique aussi en batch (remises cumulées).

### 2.2 Créer, suivre, récupérer

```python
# batch.py — classification de 1 000 avis clients en lot, avec sortie structurée
import json, time
from anthropic import Anthropic

client = Anthropic()
avis = json.load(open("avis_clients.json", encoding="utf-8"))   # [{"id": "a1", "texte": "..."}, ...]

SCHEMA = {"type": "object", "properties": {
    "sentiment": {"type": "string", "enum": ["positif", "neutre", "negatif"]},
    "theme": {"type": "string", "enum": ["livraison", "qualite", "prix", "service", "autre"]}},
    "required": ["sentiment", "theme"], "additionalProperties": False}

requetes = [{
    "custom_id": a["id"],                         # votre identifiant, pour recoller les résultats
    "params": {
        "model": "claude-haiku-5-5", "max_tokens": 100,
        "system": "Classez l'avis client d'une boutique en ligne française.",
        "messages": [{"role": "user", "content": a["texte"]}],
        "output_config": {"format": {"type": "json_schema", "schema": SCHEMA}},
    },
} for a in avis]

lot = client.messages.batches.create(requests=requetes)
print("lot créé :", lot.id, lot.processing_status)

# Suivi (polling toutes les 30 s ; en production, préférez une tâche planifiée ou un webhook)
while lot.processing_status == "in_progress":
    time.sleep(30)
    lot = client.messages.batches.retrieve(lot.id)
    c = lot.request_counts
    print(f"  en cours {c.processing} · réussies {c.succeeded} · erreurs {c.errored} · expirées {c.expired}")

# Récupération des résultats (flux JSONL)
resultats = {}
for res in client.messages.batches.results(lot.id):
    if res.result.type == "succeeded":
        resultats[res.custom_id] = json.loads(res.result.message.content[0].text)
    else:
        print("échec", res.custom_id, res.result.type)
json.dump(resultats, open("classification.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(len(resultats), "avis classés")
```

```typescript
// batch.ts — même lot en TypeScript
import Anthropic from "@anthropic-ai/sdk";
import { readFileSync, writeFileSync } from "node:fs";

const client = new Anthropic();
const avis: { id: string; texte: string }[] = JSON.parse(readFileSync("avis_clients.json", "utf8"));

async function main() {
  const lot = await client.messages.batches.create({
    requests: avis.map((a) => ({
      custom_id: a.id,
      params: {
        model: "claude-haiku-5-5", max_tokens: 100,
        system: "Classez l'avis client d'une boutique en ligne française. Répondez par un mot : positif, neutre ou negatif.",
        messages: [{ role: "user", content: a.texte }],
      },
    })),
  });
  console.log("lot :", lot.id);

  let etat = lot;
  while (etat.processing_status === "in_progress") {
    await new Promise((r) => setTimeout(r, 30_000));
    etat = await client.messages.batches.retrieve(lot.id);
    console.log("réussies :", etat.request_counts.succeeded);
  }
  const sortie: Record<string, string> = {};
  for await (const res of await client.messages.batches.results(lot.id)) {
    if (res.result.type === "succeeded") {
      const b = res.result.message.content[0];
      sortie[res.custom_id] = b.type === "text" ? b.text.trim() : "";
    }
  }
  writeFileSync("classification.json", JSON.stringify(sortie, null, 2));
}
main();
```

Coût du lot : 1 000 avis × ~120 tokens d'entrée + 20 de sortie avec Haiku 5.5 en batch (0,05 $ / 0,25 $) ≈ **0,011 $**. Les résultats ne sont **pas ordonnés** : recollez-les toujours via `custom_id`. Un lot peut être annulé (`batches.cancel`) ; les requêtes déjà traitées restent facturées.

> 💡 **À retenir** — Batch + cache + Haiku 5.5 + sortie structurée : c'est la combinaison « industrielle » pour tout traitement de masse. Le header `output-300k-2026-03-24` permet même des sorties de 300K tokens en batch (page Pricing).


```quiz
{
  "q": "Les résultats de votre lot de 1 000 avis arrivent dans le désordre. Comment savoir à quel avis correspond chaque résultat ?",
  "options": ["Par l'ordre d'arrivée, qui suit toujours l'ordre d'envoi des requêtes", "Par l'identifiant du lot (lot.id) renvoyé à la création", "Par le champ custom_id que vous avez fourni pour chaque requête", "Par le nom du modèle renvoyé dans chaque résultat du lot"],
  "answer": 2,
  "explanation": "Les résultats d'un lot ne sont pas ordonnés. Le custom_id, choisi par vous à la création, est la seule clé fiable pour recoller chaque résultat à sa donnée d'origine."
}
```

```mission
{
  "title": "Les limites d'un lot : combien de requêtes, combien de jours ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/batch-processing",
  "steps": ["Ouvrez la page « Batch processing »", "Repérez la section des limites (batch limitations)", "Relevez le nombre maximal de requêtes et la taille maximale d'un lot, puis la durée de disponibilité des résultats"],
  "question": "Combien de requêtes et quelle taille au maximum par lot, et pendant combien de jours les résultats restent-ils téléchargeables ?",
  "hint": "Le nombre de requêtes est un chiffre rond à six chiffres ; la durée est un peu moins d'un mois.",
  "answer": "100 000 requêtes ou 256 Mo par lot ; résultats disponibles 29 jours ; expiration des requêtes non traitées après 24 h (documentation consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Thinking adaptatif et effort

### 3.1 Ce qui a changé

Jusqu'aux modèles 4.x, on activait l'*extended thinking* avec un `budget_tokens` fixe. Les modèles **Claude 5** (Opus 5.5, Sonnet 5.5, Haiku 5.5, Fable 5.1) utilisent un **thinking adaptatif** : le modèle décide lui-même combien raisonner selon la difficulté. La page [Thinking](https://platform.claude.com/docs/en/build-with-claude/thinking) précise (nov. 2026) que le mode `extended` avec budget est **refusé (erreur 400) sur Claude 5**, que le mode recommandé est `{"type": "adaptive"}`, et que l'on peut demander un résumé lisible du raisonnement avec `display: "summarized"`. Sur Fable 5.1 et Opus 5.5, le thinking est **toujours actif** ; sur Sonnet 5.5 et Haiku 5.5, il est adaptatif.

Le paramètre **`effort`** (page [Effort](https://platform.claude.com/docs/en/build-with-claude/effort)) règle l'intensité globale : `low`, `medium`, `high` (valeurs et défauts par modèle : Fable 5.1 et Sonnet 5.5 → `high`, Opus 5.5 et Haiku 5.5 → `medium`, selon les pages modèles). Un effort plus bas = réponses plus rapides, moins de tokens de raisonnement, parfois moins de précision. Une variante bêta permet un effort **par message**.

> 💡 **Autrement dit** — Avant, vous fixiez vous-même la taille du brouillon (« réfléchis sur 8 000 tokens maximum », c'était le `budget_tokens`). Avec les modèles Claude 5, c'est Claude qui **juge seul** combien de brouillon il lui faut (thinking « adaptatif ») ; vous, vous réglez seulement l'intensité générale avec `effort` (`low`, `medium`, `high`). Envoyer l'ancien réglage à budget fixe provoque une erreur 400.

### 3.2 Mise en œuvre et coût

```python
# thinking.py — thinking adaptatif avec résumé affiché, et comparaison d'effort
from anthropic import Anthropic
client = Anthropic()

PROBLEME = ("Un artisan facture 3 chantiers : 4 200 € HT (TVA 10 %), 1 150 € HT (TVA 20 %) et 980 € HT (TVA 5,5 %). "
            "Il a payé 2 300 € TTC de fournitures (TVA 20 %). Quelle TVA doit-il reverser ce trimestre ? Détaillez.")

for effort in ("low", "high"):
    r = client.messages.create(
        model="claude-opus-5-5",
        max_tokens=4000,
        thinking={"type": "adaptive", "display": "summarized"},   # résumé du raisonnement renvoyé
        output_config={"effort": effort},
        messages=[{"role": "user", "content": PROBLEME}],
    )
    for b in r.content:
        if b.type == "thinking":
            print(f"[{effort}] raisonnement (résumé) :", b.thinking[:300].replace("\n", " "), "…")
        elif b.type == "text":
            print(f"[{effort}] réponse :", b.text[:400], "…")
    print(f"[{effort}] usage :", r.usage, "\n")
```

```typescript
// thinking.ts — streaming avec blocs de raisonnement
import Anthropic from "@anthropic-ai/sdk";
const client = new Anthropic();

async function main() {
  const stream = client.messages.stream({
    model: "claude-sonnet-5-5", max_tokens: 3000,
    thinking: { type: "adaptive", display: "summarized" },
    output_config: { effort: "medium" },
    messages: [{ role: "user", content: "Planifiez l'ordre optimal de 5 interventions de plomberie à Rennes en minimisant les trajets : A (centre), B (Cesson), C (centre), D (Bruz), E (Cesson)." }],
  });
  stream.on("thinking", (delta) => process.stdout.write(`\x1b[2m${delta}\x1b[0m`)); // raisonnement en gris
  stream.on("text", (delta) => process.stdout.write(delta));
  const m = await stream.finalMessage();
  console.log("\nusage :", m.usage);
}
main();
```

**Coût.** Les tokens de raisonnement sont facturés comme des **tokens de sortie** (10 $/MTok sur Sonnet 5.5) : un problème qui déclenche 3 000 tokens de thinking coûte 0,03 $ de plus. D'où l'intérêt d'`effort: "low"` sur les tâches simples (classification, reformulation) et de garder `high` pour l'analyse, le code et les agents. Dans une conversation avec outils, les blocs `thinking` renvoyés par l'API doivent être **renvoyés tels quels** dans l'historique (avec leur `signature`), voir la page [Preserved thinking](https://platform.claude.com/docs/en/build-with-claude/preserved-thinking).


```quiz
{
  "type": "vrai_faux",
  "q": "Les tokens de raisonnement (blocs thinking) sont facturés au tarif des tokens de sortie.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai : le brouillon est du texte produit par le modèle, donc facturé comme de la sortie (10 $/MTok sur Sonnet 5.5). D'où l'intérêt d'effort: \"low\" sur les tâches simples."
}
```

### 3.3 Gérer le contexte sur les longues sessions

Trois autres leviers, documentés dans la section Context editing (page [Context editing](https://platform.claude.com/docs/en/build-with-claude/context-editing)), complètent cette leçon : la **compaction** (résumé automatique de l'historique quand il dépasse un seuil, en mode on-demand, background ou threshold ; option « keep recent turns »), l'**effacement des anciens résultats d'outils**, et les **task budgets** (plafond de tokens pour une tâche agentique). Vous les retrouverez dans les agents (M21). Enfin, le **Fast mode** d'Opus 5.5 (8 $ / 40 $) offre une latence réduite pour les cas interactifs qui l'exigent.

> 💡 **Autrement dit** — Sur une très longue conversation, le dossier finit par déborder du bureau. La **compaction**, c'est demander à un assistant de **résumer les vieux échanges** pour ne garder que l'essentiel (et les derniers tours intacts) ; l'effacement des anciens résultats d'outils, c'est **jeter les tickets de courses** déjà exploités ; le *task budget*, c'est **l'enveloppe maximale** allouée à une mission.

🎮 **Défi** — Votre application pose 5 000 questions/jour à un mémento de 30 000 tokens avec Sonnet 5.5. Calculez le coût d'entrée mensuel (30 jours) sans cache, puis avec cache à 1 h renouvelé une fois par heure ouvrée (10 h/jour). *(Sans cache : 5 000 × 30 000 × 30 × 2 / 10⁶ = 9 000 $. Avec cache : écritures 300 × 30 000 × 4 / 10⁶ ≈ 36 $ + lectures 150 000 × 30 000 × 0,10 / 10⁶ = 450 $ ≈ 486 $.)*

## 🧪 Exercice pratique

**Consigne.** Vous reprenez le lecteur de factures de L072 pour un cabinet qui traite **2 000 factures par nuit**.
1. Construisez un lot Batch avec Haiku 5.5, sortie structurée, system prompt commun marqué `cache_control` (≥ 512 tokens : ajoutez un guide de lecture des factures françaises).
2. Suivez le lot et écrivez les résultats dans un CSV ; comptez réussites / échecs / expirations.
3. Calculez le coût réel à partir des `usage` de chaque résultat (entrée, sortie, cache) et comparez avec un traitement synchrone sans cache.
4. Pour les 5 factures où `incertitudes` est non vide, relancez en synchrone avec Opus 5.5, `thinking adaptive` et `effort: "high"`, et comparez les extractions.

**Critères de réussite.** Le lot termine sans erreur de format ; les résultats sont recollés par `custom_id` ; le rapport de coût distingue les quatre lignes de `usage` ; le gain batch + cache est ≥ 50 % par rapport au synchrone.

<details>
<summary>Pistes</summary>

- Dans un lot, le cache est partagé entre les requêtes qui ont le même préfixe : vérifiez que `cache_read_input_tokens` est non nul dès la deuxième facture.
- Tarifs Haiku 5.5 batch (nov. 2026) : 0,05 $ / 0,25 $ ; lecture cache 0,01 $ (hors batch) — la remise batch s'applique en plus.
- Pour la relance Opus 5.5, affichez le résumé du thinking : il montre souvent **pourquoi** une ligne était ambiguë.
</details>

## ✅ Auto-évaluation express

1. Quelle taille minimale doit avoir un préfixe pour être mis en cache sur Sonnet 5.5, et combien coûte une lecture ?
2. Quels sont la remise et le délai maximal de la Batch API ?
3. Pourquoi `thinking: {"type": "extended", "budget_tokens": 8000}` échoue-t-il sur Claude Opus 5.5 ?

**Réponses.** 1. 512 tokens ; lecture à 0,05× le prix d'entrée (0,10 $/MTok) sur Sonnet 5.5. 2. −50 % ; 24 h (la plupart des lots finissent en moins d'une heure). 3. Les modèles Claude 5 n'acceptent que le thinking adaptatif (`type: "adaptive"`) ; l'extended thinking à budget fixe renvoie une erreur 400.

## 📚 Pour aller plus loin
- [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 — règles complètes, tarifs par modèle, caching automatique.
- [Batch processing](https://platform.claude.com/docs/en/build-with-claude/batch-processing) 🇬🇧 — limites, statuts, récupération des résultats, annulation.
- [Thinking](https://platform.claude.com/docs/en/build-with-claude/thinking) 🇬🇧 — adaptatif vs extended, `display`, signatures.
- [Optimizing for cost and intelligence](https://platform.claude.com/docs/en/about-claude/models/optimizing-for-cost-and-intelligence) 🇬🇧 — la méthode officielle pour choisir modèle et effort.
- [Cookbook — Prompt caching](https://platform.claude.com/cookbook/misc-prompt-caching) 🇬🇧 et [Batch processing](https://platform.claude.com/cookbook/misc-batch-processing) 🇬🇧 — recettes mesurées.

> 🗺️ **Et maintenant ?** — Vous maîtrisez les coûts de l'API brute ; la leçon L074 vous fait passer à l'étage au-dessus avec Claude Code et le Claude Agent SDK, qui orchestrent pour vous outils, boucle et permissions.
