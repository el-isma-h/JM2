---
id: L075
module: M17
level: N3
title: "MCP : construire un serveur et un client"
minutes: 50
objectives:
  - "Expliquer l'architecture MCP (hôte, client, serveur), ses primitives (tools, resources, prompts, sampling, elicitation) et ses transports (stdio, Streamable HTTP)"
  - "Construire un serveur MCP complet en Python (FastMCP) et en TypeScript (SDK officiel) exposant outils, ressources et prompts"
  - "Écrire un client MCP, tester avec l'Inspector, connecter le serveur à Claude Code et à la Messages API via le MCP connector"
  - "Appliquer les règles de sécurité : permissions minimales, authentification, serveurs tiers non audités"
skills: ["C3.4", "C3.2"]
sources:
  - { title: "Claude Platform — MCP connector", url: "https://platform.claude.com/docs/en/agents-and-tools/mcp-connector", lang: "en" }
  - { title: "Claude Code — MCP", url: "https://code.claude.com/docs/en/mcp.md", lang: "en" }
  - { title: "Claude Code — MCP quickstart", url: "https://code.claude.com/docs/en/mcp-quickstart.md", lang: "en" }
  - { title: "Claude Agent SDK — MCP", url: "https://code.claude.com/docs/en/agent-sdk/mcp", lang: "en" }
  - { title: "Model Context Protocol — Introduction", url: "https://modelcontextprotocol.io/introduction", lang: "en" }
  - { title: "Model Context Protocol — Spécification 2025-11-25 (authorization)", url: "https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization", lang: "en" }
  - { title: "MCP — SDK TypeScript officiel (GitHub)", url: "https://github.com/modelcontextprotocol/typescript-sdk", lang: "en" }
  - { title: "MCP — dépôts officiels (SDK, serveurs de référence, registry)", url: "https://github.com/orgs/modelcontextprotocol/repositories", lang: "en" }
  - { title: "Claude Academy — Introduction to Model Context Protocol", url: "https://academy.claude.com/courses/introduction-to-model-context-protocol", lang: "en" }
  - { title: "Claude Academy — MCP: Advanced topics", url: "https://academy.claude.com/courses/model-context-protocol-advanced-topics", lang: "en" }
---

# MCP : construire un serveur et un client

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Décrire MCP comme « l'USB-C des outils d'IA » : un protocole ouvert qui permet à n'importe quel hôte (Claude Code, Claude Desktop, l'API, Cursor, Open WebUI…) de brancher n'importe quel serveur d'outils.
- Écrire un serveur MCP **complet** (outils, ressources, prompts) pour un cas métier, en Python avec FastMCP et en TypeScript avec le SDK officiel.
- Le tester (Inspector), l'appeler depuis votre propre client, l'ajouter à Claude Code, et l'exposer à la Messages API via le MCP connector.
- Reconnaître les risques (serveur tiers malveillant, injection par ressource, secrets) et les parades.

> 🧭 **En clair** — MCP (*Model Context Protocol*), c'est **la prise USB-C des assistants IA**. Avant, chaque appareil avait son chargeur : un outil « vérifier le stock » devait être recâblé pour Claude Code, pour Claude Desktop, pour Cursor… Avec MCP, vous fabriquez **un seul appareil** (le *serveur MCP* : vos outils, vos données, vos modèles de prompts) et **n'importe quel ordinateur compatible** (l'*hôte* : Claude Code, Claude Desktop, votre application) peut le brancher grâce à un **câble standard** (le *client MCP*). Le serveur annonce ce qu'il sait faire, l'hôte le découvre tout seul, et Claude peut s'en servir. Dans cette leçon, vous fabriquez l'appareil, le câble, et vous le branchez à trois endroits différents.

## 1. Pourquoi MCP ?

En L070, vous avez écrit des outils pour **votre** application. Mais le même outil « vérifier le stock » serait utile dans Claude Code, dans Claude Desktop, dans un agent n8n, dans Cursor… Avant MCP, il fallait l'intégrer N fois. Le **Model Context Protocol**, publié par Anthropic en novembre 2024 et aujourd'hui gouverné au sein de la Linux Foundation (Agentic AI Foundation), standardise cette intégration : un serveur MCP décrit ses capacités, un client MCP les découvre et les appelle, via JSON-RPC.

```
┌────────────── HÔTE (application) ───────────────┐
│  Claude Code · Claude Desktop · API via connector │
│  Cursor · Open WebUI · votre app Agent SDK        │
│   ┌────────┐   ┌────────┐   ┌────────┐           │
│   │client 1│   │client 2│   │client 3│  (1 client par serveur)
└───┴───┬────┴───┴───┬────┴───┴───┬────┴───────────┘
        │ stdio      │ HTTP       │ HTTP
   ┌────▼────┐  ┌────▼────┐  ┌────▼────┐
   │ serveur │  │ serveur │  │ serveur │
   │ fichiers│  │  ERP    │  │ GitHub  │
   └─────────┘  └─────────┘  └─────────┘
```

**Primitives** (recherche §04 et cours Academy) :

| Côté serveur | Rôle | Analogie |
|---|---|---|
| **Tools** | actions appelées par le modèle (`creer_devis`) | les fonctions de L070 |
| **Resources** | données en lecture, adressées par URI (`tarifs://catalogue`) | un fichier ou une page que l'hôte peut charger dans le contexte |
| **Prompts** | modèles de prompts paramétrés, choisis par l'utilisateur (`/devis-rapide`) | les commandes slash |

| Côté client | Rôle |
|---|---|
| **Sampling** | le serveur demande à l'hôte de faire un appel LLM (sans posséder de clé) |
| **Elicitation** | le serveur demande une information à l'utilisateur (« quel client ? ») |
| **Roots** | l'hôte indique les répertoires autorisés |

**Transports** : `stdio` (le serveur est un processus local lancé par l'hôte : idéal en développement et pour les outils locaux) et **Streamable HTTP** (serveur distant, multi-clients, authentification OAuth) ; l'ancien transport SSE est **déprécié** (page [MCP de Claude Code](https://code.claude.com/docs/en/mcp.md)). Versions de la spécification : `2025-11-25` (stable, citée par la doc Anthropic) et la révision `2026-07-28` plus récente (dépôt GitHub) ; l'en-tête `MCP-Protocol-Version` négocie la version.

> 💡 **Autrement dit** — Le *transport*, c'est **le type de câble**. `stdio`, c'est un câble court branché directement sur votre ordinateur : l'hôte lance le serveur comme un petit programme local et lui parle en direct. *Streamable HTTP*, c'est une connexion par Internet : le serveur vit ailleurs (chez vous en production, dans le cloud) et plusieurs personnes peuvent s'y connecter, avec un badge d'accès (OAuth). *JSON-RPC* est simplement la langue, très codifiée, dans laquelle client et serveur s'échangent leurs messages.
>
> 📌 **Précision (nov. 2026)** — La révision `2026-07-28` est la **version stable actuelle** de MCP : publiée le 28 juillet 2026 (elle remplace sa release candidate `2026-07-28-RC` du 29 mai 2026), `2025-11-25` devient la version stable précédente. Changements clés : protocole **sans état** (plus d'`initialize` ni d'ID de session ; version et capacités transmises à chaque requête), Roots, Sampling, Logging et le transport HTTP+SSE **dépréciés**. Du code qui suppose une session MCP doit évoluer. Source : [release officielle](https://github.com/modelcontextprotocol/specification/releases/tag/2026-07-28).


```quiz
{
  "q": "Votre serveur MCP doit mettre à disposition le catalogue des tarifs, en lecture seule, pour que l'hôte puisse le charger dans le contexte. Quelle primitive utiliser ?",
  "options": ["Un tool (action appelée par le modèle)", "Un prompt (modèle choisi par l'utilisateur)", "Une resource adressée par une URI", "Le sampling (appel LLM demandé à l'hôte)"],
  "answer": 2,
  "explanation": "Les resources sont des données en lecture, identifiées par une URI, que l'hôte peut charger. Les tools sont des actions, les prompts des modèles choisis par l'utilisateur, et le sampling (déprécié par la révision 2026-07-28) permet au serveur de demander un appel LLM à l'hôte."
}
```

## 2. Serveur MCP complet en Python (FastMCP)

Cas métier : **l'atelier d'un menuisier** qui veut que Claude consulte ses tarifs, chiffre un devis et enregistre une demande.

```bash
python -m venv .venv && source .venv/bin/activate
pip install "mcp[cli]"      # SDK Python officiel, inclut FastMCP et l'Inspector
```

```python
# serveur_menuiserie.py — serveur MCP : 3 outils, 1 ressource, 1 prompt
import json
from datetime import date
from pathlib import Path
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("menuiserie-dubois")

TARIFS = {  # €/unité HT — en production : base de données
    "porte_interieure": {"libelle": "Porte intérieure chêne posée", "unite": "u", "prix_ht": 420.0},
    "fenetre_pvc":      {"libelle": "Fenêtre PVC double vitrage posée", "unite": "u", "prix_ht": 650.0},
    "parquet_chene":    {"libelle": "Parquet chêne massif posé", "unite": "m2", "prix_ht": 95.0},
    "main_oeuvre":      {"libelle": "Main d'œuvre", "unite": "h", "prix_ht": 52.0},
}
DEMANDES = Path("demandes.jsonl")

# ---- Resource : données en lecture, chargées dans le contexte par l'hôte ----
@mcp.resource("tarifs://catalogue")
def catalogue() -> str:
    """Catalogue des prestations et tarifs HT de la menuiserie Dubois (nov. 2026)."""
    return json.dumps(TARIFS, ensure_ascii=False, indent=2)

# ---- Tools : actions ; la docstring devient la description lue par le modèle ----
@mcp.tool()
def rechercher_prestation(mot_cle: str) -> list[dict]:
    """Recherche une prestation du catalogue par mot-clé (ex. 'fenêtre', 'parquet').
    Renvoie les codes, libellés et prix HT correspondants. Utiliser AVANT de chiffrer."""
    m = mot_cle.lower()
    return [{"code": c, **t} for c, t in TARIFS.items() if m in t["libelle"].lower() or m in c]

@mcp.tool()
def chiffrer_devis(lignes: list[dict], taux_tva: float = 10.0) -> dict:
    """Calcule un devis à partir de lignes [{code, quantite}] et d'un taux de TVA (10 % rénovation
    logement > 2 ans, 20 % sinon, 5.5 % rénovation énergétique). Renvoie le détail, total HT, TVA, TTC.
    Lève une erreur si un code est inconnu : ne jamais inventer un code."""
    if taux_tva not in (5.5, 10.0, 20.0):
        raise ValueError("taux_tva doit être 5.5, 10 ou 20")
    detail, total_ht = [], 0.0
    for l in lignes:
        t = TARIFS.get(l["code"])
        if not t:
            raise ValueError(f"code inconnu : {l['code']}")
        montant = round(t["prix_ht"] * float(l["quantite"]), 2)
        total_ht += montant
        detail.append({"code": l["code"], "libelle": t["libelle"], "quantite": l["quantite"],
                       "prix_unitaire_ht": t["prix_ht"], "montant_ht": montant})
    tva = round(total_ht * taux_tva / 100, 2)
    return {"detail": detail, "total_ht": round(total_ht, 2), "taux_tva": taux_tva, "tva": tva,
            "total_ttc": round(total_ht + tva, 2)}

@mcp.tool()
def enregistrer_demande(client: str, description: str, total_ttc: float) -> str:
    """Enregistre une demande de devis validée par le client (nom, description, total TTC).
    À n'appeler qu'après confirmation explicite de l'utilisateur."""
    DEMANDES.open("a", encoding="utf-8").write(json.dumps(
        {"date": date.today().isoformat(), "client": client, "description": description,
         "total_ttc": total_ttc}, ensure_ascii=False) + "\n")
    return f"Demande enregistrée pour {client} ({total_ttc:.2f} € TTC)."

# ---- Prompt : modèle réutilisable proposé à l'utilisateur ----
@mcp.prompt()
def devis_rapide(besoin: str) -> str:
    """Prépare un devis à partir d'une description libre du besoin."""
    return (f"Le client décrit son besoin ainsi : « {besoin} ».\n"
            "1. Recherchez les prestations correspondantes avec rechercher_prestation.\n"
            "2. Proposez des quantités plausibles et chiffrez avec chiffrer_devis (TVA 10 % par défaut).\n"
            "3. Présentez le devis en tableau, puis demandez confirmation avant d'enregistrer.")

if __name__ == "__main__":
    mcp.run(transport="stdio")          # ou : mcp.run(transport="streamable-http") pour un serveur distant
```

Tester immédiatement avec l'**Inspector** (interface web qui liste outils, ressources et prompts et permet de les appeler) :

```bash
mcp dev serveur_menuiserie.py
```

## 3. Le même serveur en TypeScript (SDK officiel)

```bash
npm init -y && npm install @modelcontextprotocol/sdk zod && npm install -D typescript tsx @types/node
```

```typescript
// serveur_menuiserie.ts — serveur MCP TypeScript (stdio) avec outil, ressource et prompt
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const TARIFS: Record<string, { libelle: string; unite: string; prix_ht: number }> = {
  porte_interieure: { libelle: "Porte intérieure chêne posée", unite: "u", prix_ht: 420 },
  fenetre_pvc: { libelle: "Fenêtre PVC double vitrage posée", unite: "u", prix_ht: 650 },
  parquet_chene: { libelle: "Parquet chêne massif posé", unite: "m2", prix_ht: 95 },
};

const server = new McpServer({ name: "menuiserie-dubois", version: "1.0.0" });

server.registerResource("catalogue", "tarifs://catalogue",
  { title: "Catalogue tarifs", description: "Prestations et tarifs HT (nov. 2026)", mimeType: "application/json" },
  async (uri) => ({ contents: [{ uri: uri.href, text: JSON.stringify(TARIFS, null, 2) }] }));

server.registerTool("chiffrer_devis",
  {
    title: "Chiffrer un devis",
    description: "Calcule un devis à partir de lignes {code, quantite} et d'un taux de TVA (5.5, 10 ou 20). Erreur si code inconnu : ne jamais inventer un code.",
    inputSchema: {
      lignes: z.array(z.object({ code: z.string(), quantite: z.number().positive() })),
      taux_tva: z.union([z.literal(5.5), z.literal(10), z.literal(20)]).default(10),
    },
  },
  async ({ lignes, taux_tva }) => {
    let total_ht = 0;
    const detail = lignes.map((l) => {
      const t = TARIFS[l.code];
      if (!t) throw new Error(`code inconnu : ${l.code}`);
      const montant = +(t.prix_ht * l.quantite).toFixed(2);
      total_ht += montant;
      return { ...l, libelle: t.libelle, montant_ht: montant };
    });
    const tva = +(total_ht * taux_tva / 100).toFixed(2);
    const devis = { detail, total_ht: +total_ht.toFixed(2), taux_tva, tva, total_ttc: +(total_ht + tva).toFixed(2) };
    return { content: [{ type: "text", text: JSON.stringify(devis, null, 2) }] };
  });

server.registerPrompt("devis_rapide",
  { title: "Devis rapide", description: "Prépare un devis à partir d'un besoin libre", argsSchema: { besoin: z.string() } },
  ({ besoin }) => ({ messages: [{ role: "user", content: { type: "text",
    text: `Le client décrit : « ${besoin} ». Lisez tarifs://catalogue, proposez des quantités, chiffrez avec chiffrer_devis, puis présentez un tableau.` } }] }));

const transport = new StdioServerTransport();
await server.connect(transport);
```

Pour un serveur **distant**, remplacez le transport stdio par le transport Streamable HTTP du SDK (classe `StreamableHTTPServerTransport`, monté sur une route `/mcp` d'Express ou de Hono) et ajoutez une authentification (section 7).

> 💡 **À retenir** — Un outil MCP est **le même objet** qu'un outil de L070 (nom, description, schéma), transporté par un protocole standard. Tout ce que vous savez sur la qualité des descriptions s'applique : c'est elle que le modèle lit pour décider.


```quiz
{
  "type": "vrai_faux",
  "q": "Un outil exposé par un serveur MCP est, sur le fond, le même objet qu'un outil de la Messages API (L070) : un nom, une description et un schéma d'entrée.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai : MCP ne change pas la nature de l'outil, seulement la façon de le transporter et de le découvrir. Le code hote_minimal.py le prouve en convertissant directement la liste MCP en définitions tools."
}
```

## 4. Écrire un client MCP

Un client sert à **tester**, à **intégrer MCP dans une application qui n'est pas un hôte connu**, ou à bâtir votre propre hôte. Le cours Academy « Introduction to MCP » fait exactement cet exercice.

```python
# client_menuiserie.py — client MCP stdio : liste les outils, lit la ressource, appelle un outil
import asyncio, json
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    params = StdioServerParameters(command="python", args=["serveur_menuiserie.py"])
    async with stdio_client(params) as (lecture, ecriture):
        async with ClientSession(lecture, ecriture) as session:
            await session.initialize()                       # négociation de version et de capacités

            outils = await session.list_tools()
            print("Outils :", [t.name for t in outils.tools])

            ressource = await session.read_resource("tarifs://catalogue")
            print("Catalogue :", ressource.contents[0].text[:120], "…")

            resultat = await session.call_tool("chiffrer_devis", {
                "lignes": [{"code": "fenetre_pvc", "quantite": 3}, {"code": "main_oeuvre", "quantite": 6}],
                "taux_tva": 10,
            })
            print("Devis :", resultat.content[0].text)

            prompt = await session.get_prompt("devis_rapide", {"besoin": "remplacer 3 fenêtres au 1er étage"})
            print("Prompt :", prompt.messages[0].content.text[:100], "…")

asyncio.run(main())
```

### 4.1 Brancher le client sur la Messages API (votre propre hôte)

Pour que Claude utilise ces outils depuis **votre** application, convertissez la liste MCP en définitions d'outils (L070) et exécutez les appels via `session.call_tool` :

```python
# hote_minimal.py — Claude (Messages API) + outils découverts dynamiquement sur le serveur MCP
import asyncio
from anthropic import AsyncAnthropic
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    client = AsyncAnthropic()
    params = StdioServerParameters(command="python", args=["serveur_menuiserie.py"])
    async with stdio_client(params) as (r, w), ClientSession(r, w) as session:
        await session.initialize()
        mcp_tools = (await session.list_tools()).tools
        tools = [{"name": t.name, "description": t.description or "", "input_schema": t.inputSchema} for t in mcp_tools]

        messages = [{"role": "user", "content": "Devis pour 2 portes intérieures et 4 h de pose, TVA 10 %."}]
        for _ in range(6):
            rep = await client.messages.create(model="claude-sonnet-5-5", max_tokens=1000, tools=tools, messages=messages)
            messages.append({"role": "assistant", "content": rep.content})
            if rep.stop_reason != "tool_use":
                print("".join(b.text for b in rep.content if b.type == "text")); break
            resultats = []
            for b in rep.content:
                if b.type == "tool_use":
                    res = await session.call_tool(b.name, b.input)
                    resultats.append({"type": "tool_result", "tool_use_id": b.id,
                                      "content": res.content[0].text, "is_error": bool(res.isError)})
            messages.append({"role": "user", "content": resultats})

asyncio.run(main())
```

## 5. Connecter le serveur à Claude Code

```bash
# Serveur local (stdio) — portée "local" (vous, ce projet) par défaut
claude mcp add --transport stdio menuiserie -- python /chemin/serveur_menuiserie.py

# Serveur distant Streamable HTTP, partagé avec l'équipe via .mcp.json (portée "project")
claude mcp add --transport http erp https://mcp.erp.exemple.fr/mcp --scope project

claude mcp list          # vérifier ; dans une session : /mcp pour l'état et l'authentification OAuth
```

Trois **portées** (page [MCP](https://code.claude.com/docs/en/mcp.md)) : `local` (vous, ce projet), `project` (fichier `.mcp.json` versionné, pour l'équipe), `user` (vous, tous les projets). Une fois connecté, Claude Code voit `rechercher_prestation`, `chiffrer_devis`… comme des outils `mcp__menuiserie__…` (soumis aux permissions), peut charger `tarifs://catalogue` avec `@menuiserie:tarifs://catalogue` et exposer le prompt comme commande `/menuiserie:devis_rapide`. Le même fichier de configuration est accepté par l'Agent SDK (option `mcp_servers`, page [Agent SDK — MCP](https://code.claude.com/docs/en/agent-sdk/mcp)) et par Claude Desktop.

```json
{
  "mcpServers": {
    "menuiserie": { "command": "python", "args": ["./serveur_menuiserie.py"] },
    "erp": { "type": "http", "url": "https://mcp.erp.exemple.fr/mcp" }
  }
}
```


```mission
{
  "title": "Chasse à la commande : brancher un serveur MCP dans Claude Code",
  "url": "https://code.claude.com/docs/en/mcp.md",
  "steps": ["Ouvrez la page MCP de la documentation Claude Code", "Repérez la commande d'ajout d'un serveur et ses options de transport", "Cherchez la section sur les portées (scopes) et le nom du fichier partagé avec l'équipe"],
  "question": "Quelle commande ajoute un serveur MCP, quelles sont les trois valeurs de --transport, quelles sont les trois portées et quel fichier stocke la portée project ?",
  "hint": "La commande commence par « claude mcp » ; l'un des trois transports est signalé comme déprécié.",
  "answer": "claude mcp add --transport http|sse|stdio … ; portées local, project et user ; la portée project est enregistrée dans .mcp.json ; SSE est déprécié (documentation consultée en nov. 2026).",
  "xp": 15
}
```

## 6. Le MCP connector : des serveurs MCP directement dans la Messages API

Vous pouvez aussi laisser **Anthropic** jouer le rôle de client MCP : la page [MCP connector](https://platform.claude.com/docs/en/agents-and-tools/mcp-connector) décrit le paramètre `mcp_servers` (serveurs distants Streamable HTTP ou SSE, avec jeton d'autorisation) et l'outil `mcp_toolset` qui expose leurs outils à Claude ; l'en-tête bêta est `mcp-client-2025-11-20` (nov. 2026). Les appels d'outils sont alors exécutés **côté Anthropic**, sans boucle à écrire — mais le serveur doit être **joignable depuis Internet** (pour un serveur local, les [MCP tunnels](https://platform.claude.com/docs/en/agents-and-tools/mcp-tunnels/overview) offrent une solution).

> 💡 **Autrement dit** — Deux façons de brancher l'appareil. Dans **Claude Code**, le câble part **de votre ordinateur**. Avec le **MCP connector**, c'est **Anthropic qui tend le câble** depuis ses propres serveurs jusqu'au vôtre : plus de boucle à écrire, mais votre serveur doit avoir une adresse publique sur Internet, et un badge d'accès (`authorization_token`).

```python
# connector.py — la Messages API appelle elle-même votre serveur MCP distant
import os
from anthropic import Anthropic
client = Anthropic()

r = client.beta.messages.create(
    model="claude-sonnet-5-5",
    max_tokens=1000,
    betas=["mcp-client-2025-11-20"],
    mcp_servers=[{
        "type": "url",
        "url": "https://mcp.menuiserie-dubois.fr/mcp",
        "name": "menuiserie",
        "authorization_token": os.environ["MENUISERIE_MCP_TOKEN"],   # jeton OAuth / API, jamais en dur
    }],
    tools=[{"type": "mcp_toolset", "mcp_server_name": "menuiserie"}],
    messages=[{"role": "user", "content": "Chiffre 20 m² de parquet chêne, TVA 10 %."}],
)
for b in r.content:
    if b.type == "text": print(b.text)
    elif b.type == "mcp_tool_use": print("  ↳ outil MCP :", b.name, b.input)
```

```typescript
// connector.ts — même chose en TypeScript
import Anthropic from "@anthropic-ai/sdk";
const client = new Anthropic();

async function main() {
  const r = await client.beta.messages.create({
    model: "claude-sonnet-5-5", max_tokens: 1000,
    betas: ["mcp-client-2025-11-20"],
    mcp_servers: [{ type: "url", url: "https://mcp.menuiserie-dubois.fr/mcp", name: "menuiserie",
                    authorization_token: process.env.MENUISERIE_MCP_TOKEN }],
    tools: [{ type: "mcp_toolset", mcp_server_name: "menuiserie" }],
    messages: [{ role: "user", content: "Chiffre 20 m² de parquet chêne, TVA 10 %." }],
  } as any);
  for (const b of r.content) if (b.type === "text") console.log(b.text);
}
main();
```

Le nom exact des champs (`mcp_toolset`, `mcp_tool_use`, restriction d'outils par `allowed_tools` dans le toolset) est celui de la page officielle en nov. 2026 ; vérifiez-le pour votre version du SDK.


```quiz
{
  "q": "Votre serveur MCP tourne en stdio sur votre portable. Peut-on le passer tel quel au MCP connector de la Messages API (paramètre mcp_servers) ?",
  "options": ["Oui, il suffit d'indiquer le chemin du script dans mcp_servers", "Non : il doit être joignable depuis Internet (ou via un MCP tunnel)", "Oui, à condition d'ajouter l'en-tête bêta mcp-client-2025-11-20", "Non, le MCP connector ne fonctionne qu'avec Claude Desktop"],
  "answer": 1,
  "explanation": "Avec le connector, c'est l'API d'Anthropic qui joue le rôle de client : elle ne peut pas lancer un programme sur votre machine. Le serveur doit être exposé en Streamable HTTP (l'ancien transport SSE est déprécié), éventuellement via les MCP tunnels."
}
```

## 7. Sécurité MCP

- **Un serveur MCP tiers est du code qui s'exécute avec vos droits** (stdio) ou qui reçoit vos données (HTTP). L'OWASP Top 10 for LLM Applications 2026 cite les serveurs MCP non audités comme risque de chaîne d'approvisionnement (LLM04:2026). N'installez que des serveurs dont vous avez lu le code ou qui viennent d'un éditeur identifié (dépôts officiels, registry MCP).
- **Injection par ressource** : une ressource ou un résultat d'outil peut contenir des instructions (« ignore tes règles… »). Traitez-les comme des données (L069) et limitez les outils d'écriture.
- **Authentification** : la spécification `2025-11-25` définit l'autorisation **OAuth 2.1** pour les serveurs HTTP ; ne mettez jamais un jeton en clair dans `.mcp.json` versionné (variables d'environnement, `${VAR}`).
- **Moindre privilège** : un outil = une action ; séparez lecture et écriture ; demandez confirmation (elicitation ou permissions de l'hôte) avant toute écriture, comme `enregistrer_demande`.


```mission
{
  "title": "Chasse à la spec : quel standard d'autorisation pour un serveur MCP distant ?",
  "url": "https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization",
  "steps": ["Ouvrez la section « Authorization » de la spécification MCP 2025-11-25", "Lisez l'introduction et repérez le standard d'autorisation sur lequel elle s'appuie", "Vérifiez à quels transports cette section s'applique (local ou HTTP)"],
  "question": "Sur quelle version d'OAuth la spécification MCP 2025-11-25 fonde-t-elle l'autorisation, et pour quel type de transport ?",
  "hint": "C'est la version la plus récente d'OAuth ; elle ne concerne pas les serveurs lancés en stdio.",
  "answer": "OAuth 2.1, pour les transports HTTP (les serveurs stdio récupèrent plutôt leurs identifiants depuis l'environnement) — spécification 2025-11-25 ; la version stable actuelle est 2026-07-28 (28 juillet 2026) : vérifiez si cette section a changé (vérifié le 5 nov. 2026).",
  "xp": 20
}
```

🎮 **Défi** — Votre serveur expose 80 outils issus d'un ERP. Problème : chaque requête renvoie 80 schémas (≈ 15 000 tokens). Solutions ? *(Regrouper en quelques outils paramétrés ; n'exposer qu'un sous-ensemble par toolset ; côté API, utiliser l'outil `tool_search` qui charge les définitions à la demande, L070.)*

## 🧪 Exercice pratique

**Consigne.** Construisez un serveur MCP **« cabinet de recrutement »** :
1. Ressource `candidats://liste` (JSON de 5 candidats fictifs) et `candidats://{id}` (fiche détaillée, ressource paramétrée).
2. Outils : `rechercher_candidats(competence, ville)`, `planifier_entretien(id, date, heure)` (écriture, journalisée dans un fichier), `generer_synthese(id)`.
3. Prompt `prequalification(poste)` qui guide Claude pour comparer les candidats et proposer un classement.
4. Version Python (FastMCP) **et** TypeScript ; test avec l'Inspector ; client Python qui appelle les trois outils.
5. Ajout à Claude Code (`claude mcp add`), puis une session où vous demandez « prépare la préqualification pour un poste de développeur Rust à Lyon ».
6. Bonus : exposez la version TypeScript en Streamable HTTP avec un jeton `Authorization: Bearer` lu depuis l'environnement, et appelez-la via le MCP connector.

**Critères de réussite.** L'Inspector liste 3 outils, 2 ressources, 1 prompt ; `planifier_entretien` refuse une date passée ; Claude Code appelle les outils sans erreur de schéma ; aucun secret dans le code ni dans `.mcp.json`.

<details>
<summary>Pistes</summary>

- Ressource paramétrée FastMCP : `@mcp.resource("candidats://{id}")` avec un paramètre `id: str`.
- Pour tester l'écriture, faites planifier deux entretiens et vérifiez le fichier JSONL.
- Dans Claude Code, `/mcp` montre l'état de la connexion ; les outils apparaissent comme `mcp__recrutement__rechercher_candidats`.
</details>

## ✅ Auto-évaluation express

1. Quelles sont les trois primitives côté serveur et les deux principales côté client ?
2. Quel transport choisir pour un serveur partagé par 50 utilisateurs, et lequel est déprécié ?
3. Quelle différence entre « serveur MCP dans Claude Code » et « MCP connector » ?

**Réponses.** 1. Tools, resources, prompts ; sampling et elicitation (plus roots). 2. Streamable HTTP ; SSE est déprécié. 3. Dans Claude Code, le client MCP tourne sur votre machine (stdio ou HTTP) ; avec le connector, c'est l'API d'Anthropic qui se connecte à votre serveur distant et exécute les outils dans la requête.

## 📚 Pour aller plus loin
- [MCP connector](https://platform.claude.com/docs/en/agents-and-tools/mcp-connector) 🇬🇧 — `mcp_servers`, `mcp_toolset`, authentification, limites.
- [Claude Code — MCP](https://code.claude.com/docs/en/mcp.md) 🇬🇧 — transports, portées, OAuth, ressources `@`, prompts `/`.
- [Model Context Protocol — Introduction](https://modelcontextprotocol.io/introduction) 🇬🇧 — site officiel de la spécification (à consulter en ligne ; version stable actuelle 2026-07-28, version stable précédente 2025-11-25).
- [Introduction to MCP (Claude Academy)](https://academy.claude.com/courses/introduction-to-model-context-protocol) 🇬🇧 et [MCP: Advanced topics](https://academy.claude.com/courses/model-context-protocol-advanced-topics) 🇬🇧 — sampling, notifications, roots, transports en profondeur ; badges gratuits.
- [MCP: Build Rich-Context AI Apps with Anthropic (DeepLearning.AI)](https://deeplearning.ai/short-courses/mcp-build-rich-context-ai-apps-with-anthropic) 🇬🇧 — cours court gratuit, serveur + client + Claude Desktop.
- [Hugging Face — MCP Course](https://huggingface.co/learn/mcp-course/unit0/introduction) 🇬🇧 — cours ouvert, avec un projet de serveur sur le Hub.

> 🗺️ **Et maintenant ?** — Vous savez brancher des outils partout ; la leçon L076 vous apprend à empaqueter un savoir-faire complet dans un skill, puis à prouver par une évaluation chiffrée que vos prompts fonctionnent vraiment.
