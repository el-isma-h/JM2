---
id: L117
module: M25
level: N4
title: "Arbres, forêts aléatoires, gradient boosting"
minutes: 60
objectives:
  - "Expliquer comment un arbre de décision choisit ses coupures (impureté de Gini, entropie, gain d'information)"
  - "Expliquer pourquoi le bagging et les forêts aléatoires réduisent la variance, et le boosting le biais"
  - "Appliquer un gradient boosting (scikit-learn HistGradientBoosting, XGBoost ou LightGBM) et régler ses hyperparamètres clés"
  - "Évaluer l'importance des variables par impureté et par permutation, et en identifier les biais"
skills: ["C4.2"]
sources:
  - { title: "MIT 6.036 — Lecture 12 : arbres de décision et forêts aléatoires (Fall 2020)", url: "https://tamarabroderick.com/ml.html", lang: "en" }
  - { title: "DeepLearning.AI — Machine Learning Specialization (cours 2, semaine 4 : arbres et ensembles)", url: "https://deeplearning.ai/courses/machine-learning-specialization", lang: "en" }
  - { title: "scikit-learn — Decision Trees", url: "https://scikit-learn.org/stable/modules/tree.html", lang: "en" }
  - { title: "scikit-learn — Ensembles: gradient boosting, random forests, bagging", url: "https://scikit-learn.org/stable/modules/ensemble.html", lang: "en" }
  - { title: "scikit-learn — Permutation feature importance", url: "https://scikit-learn.org/stable/modules/permutation_importance.html", lang: "en" }
  - { title: "XGBoost — documentation", url: "https://xgboost.readthedocs.io/en/stable/", lang: "en" }
  - { title: "LightGBM — documentation", url: "https://lightgbm.readthedocs.io/en/stable/", lang: "en" }
---

# Arbres, forêts aléatoires, gradient boosting

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 25

## 🎯 Ce que vous saurez faire
- Calculer à la main une impureté de Gini et trouver la meilleure coupure d'une variable.
- Expliquer en une phrase chacun : arbre, bagging, forêt aléatoire, boosting, gradient boosting.
- Entraîner et comparer, avec validation croisée, un arbre, une forêt et un gradient boosting sur données tabulaires.
- Produire une importance des variables fiable et expliquer pourquoi l'importance « par défaut » peut tromper.

> 🧭 **En clair** — Un **arbre de décision** fonctionne comme le jeu « Qui est-ce ? » : il pose une suite de questions oui/non (« le client a-t-il plus de 18 mois d'ancienneté ? ») jusqu'à deviner la réponse. Un seul arbre est fragile et change d'avis pour un rien. Alors on en fait pousser des centaines : une **forêt aléatoire** fait voter des arbres un peu différents, comme on demande l'avis de toute une salle plutôt que d'une seule personne. Le **gradient boosting**, lui, construit les arbres l'un après l'autre, chacun corrigeant les erreurs du précédent, comme un élève qui révise surtout les exercices qu'il a ratés. Sur les tableaux Excel de l'entreprise, ce sont souvent les meilleurs modèles.

## 1. Pourquoi ce chapitre compte autant que le deep learning

Les réseaux de neurones dominent l'image, le son et le texte. Sur les **données tabulaires** (un tableau Excel de clients, de factures, de capteurs), la situation est différente : les méthodes d'ensembles à base d'arbres restent, en 2026, la référence à battre. Elles ont gagné une part considérable des compétitions Kaggle sur données structurées depuis la diffusion de XGBoost (Tianqi Chen et Carlos Guestrin, publication KDD 2016, rendu célèbre dès 2014 par le défi Higgs Boson de Kaggle). Pour un cabinet comptable qui prédit les retards de paiement ou une enseigne qui prévoit ses stocks, c'est souvent **le bon premier modèle sérieux**, juste après la régression logistique de L115.

L'histoire tient en quelques dates : les arbres CART (Breiman, Friedman, Olshen et Stone, 1984), le bagging (Breiman, 1996), les forêts aléatoires (Breiman, 2001), le gradient boosting (Jerome Friedman, 2001), puis les implémentations industrielles XGBoost (2016), LightGBM (Microsoft, 2017) et CatBoost (Yandex, 2017). Le cours MIT 6.036 (leçon 12, Fall 2020) et la Machine Learning Specialization (cours 2, semaine 4) traitent les arbres comme une famille à part entière, et nous ferons de même.

## 2. L'arbre de décision : vingt questions bien choisies

Un arbre de décision pose une suite de questions binaires (« ancienneté client < 18 mois ? », « montant > 2 400 € ? ») jusqu'à une **feuille** qui donne une prédiction : la classe majoritaire (classification) ou la moyenne (régression). C'est le jeu des « vingt questions », avec une règle : chaque question doit **séparer au mieux** les exemples.

### 2.1 Mesurer le désordre

> 🧠 **L'intuition d'abord** — Pour choisir la meilleure question, l'arbre mesure le **désordre** d'un groupe : un groupe où tout le monde a la même réponse est « rangé » (impureté nulle) ; un groupe moitié-moitié est le plus « en vrac ». La bonne question est celle qui produit deux sous-groupes les mieux rangés possible. **Analogie :** trier un tiroir à chaussettes mélangées. La meilleure première question n'est pas « chaussette gauche ou droite ? » (inutile) mais « noire ou blanche ? », qui sépare le tiroir en deux tas presque homogènes.

Pour un nœud contenant des proportions $p_1, \dots, p_K$ de chaque classe, deux mesures d'**impureté** sont courantes :

$$\text{Gini} = 1 - \sum_{k=1}^{K} p_k^2 \qquad\qquad \text{Entropie} = -\sum_{k=1}^{K} p_k \log_2 p_k$$

> 💡 **Autrement dit** — Le Gini répond à : « si je tire deux exemples au hasard dans ce nœud, quelle est la probabilité qu'ils soient de classes différentes ? ». 0 = jamais (nœud pur) ; 0,5 = une chance sur deux (mélange 50/50 entre deux classes).

Un nœud pur (une seule classe) a une impureté nulle ; un nœud 50/50 a un Gini de 0,5 et une entropie de 1 bit (vous reconnaissez l'entropie de Shannon, cousine de la BCE de L115 et de M24 L113). Une coupure qui produit deux enfants $G$ et $D$ est notée par la **baisse d'impureté pondérée** :

$$\Delta = I(\text{parent}) - \frac{n_G}{n}I(G) - \frac{n_D}{n}I(D)$$

> 💡 **Autrement dit** — $\Delta$ = « désordre avant la question » − « désordre moyen après la question » (chaque enfant pesé par sa taille). L'arbre choisit la question qui fait baisser le désordre le plus fort.

```quiz
{
  "q": "Un nœud contient 10 clients : 5 ont résilié, 5 sont restés. Une coupure produit deux enfants de 5 clients : (5 résiliés, 0 restés) et (0 résiliés, 5 restés). Que vaut le gain de Gini ?",
  "options": ["0", "0,25", "0,5", "1"],
  "answer": 2,
  "explanation": "Gini parent = 1 − (0,5² + 0,5²) = 0,5. Les deux enfants sont purs (Gini 0). Gain = 0,5 − (0,5×0 + 0,5×0) = 0,5 : la coupure parfaite supprime tout le désordre."
}
```

Avec l'entropie, $\Delta$ s'appelle le **gain d'information**. L'algorithme CART est **glouton** : à chaque nœud, il teste toutes les variables et tous les seuils, garde le meilleur $\Delta$, et recommence dans chaque enfant. Il ne revient jamais en arrière.

```python
"""Trouver la meilleure coupure d'une variable par l'impureté de Gini, from scratch."""
import numpy as np
from sklearn.tree import DecisionTreeClassifier, export_text


def gini(y):
    _, counts = np.unique(y, return_counts=True)
    p = counts / counts.sum()
    return 1.0 - np.sum(p ** 2)


def best_split(x, y):
    """Teste chaque seuil entre deux valeurs consécutives et renvoie le meilleur."""
    order = np.argsort(x)
    x, y = x[order], y[order]
    best = (None, 0.0)
    parent = gini(y)
    for i in range(1, len(x)):
        if x[i] == x[i - 1]:
            continue
        left, right = y[:i], y[i:]
        child = (len(left) * gini(left) + len(right) * gini(right)) / len(y)
        if parent - child > best[1]:
            best = ((x[i] + x[i - 1]) / 2, parent - child)
    return best


# Mini-jeu : ancienneté client (mois) -> a résilié (1) ou non (0)
anciennete = np.array([2, 3, 5, 7, 9, 12, 15, 20, 26, 30, 36, 48])
resilie = np.array([1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0])

seuil, gain = best_split(anciennete.astype(float), resilie)
print(f"Gini parent = {gini(resilie):.3f} ; meilleur seuil = {seuil} mois ; gain = {gain:.3f}")

tree = DecisionTreeClassifier(max_depth=1, criterion="gini").fit(anciennete.reshape(-1, 1), resilie)
print(export_text(tree, feature_names=["anciennete"]))   # scikit-learn doit trouver le même seuil
```

### 2.2 Forces et faiblesses

Un arbre est **lisible** (on peut l'imprimer pour un directeur commercial), insensible à l'échelle des variables (pas besoin de standardiser), capable de capter des interactions et des non-linéarités. Mais un arbre profond est l'exemple parfait de la **variance** de L116 : changez dix lignes et l'arbre entier change. Vous l'avez vu dans le défi de L116 : la validation décroche dès quelques niveaux de profondeur. On le bride avec `max_depth`, `min_samples_leaf` ou l'élagage `ccp_alpha`, mais la vraie solution est de **combiner** beaucoup d'arbres.

> 💡 **À retenir** — Les ensembles attaquent les deux termes de L116 par deux voies opposées. **Bagging / forêts** : beaucoup d'arbres profonds (faible biais, forte variance) entraînés en parallèle, puis moyennés → la variance baisse. **Boosting** : beaucoup d'arbres peu profonds (fort biais, faible variance) entraînés en série, chacun corrigeant le précédent → le biais baisse.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : une forêt aléatoire combine des arbres peu profonds entraînés l'un après l'autre, chacun corrigeant les erreurs du précédent.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : c'est la description du boosting. Une forêt entraîne des arbres profonds en parallèle, sur des échantillons et des variables tirés au hasard, puis fait la moyenne de leurs votes pour réduire la variance."
}
```

## 3. Forêts aléatoires : la sagesse des foules

> 🧠 **L'intuition d'abord** — Faire la moyenne de nombreux avis **indépendants** réduit les erreurs individuelles ; mais si tous les avis se copient, la moyenne ne vaut pas mieux qu'un seul. **Analogie :** estimer le poids d'un bœuf à une foire. La moyenne de 800 visiteurs qui devinent chacun dans leur coin est étonnamment juste ; si tous écoutent le même voisin bavard avant de répondre, la moyenne hérite de son erreur.

Le **bagging** (*bootstrap aggregating*) entraîne $B$ arbres, chacun sur un échantillon **bootstrap** (tirage avec remise de $n$ lignes parmi $n$), puis moyenne leurs prédictions. Si les arbres avaient chacun une variance $\sigma^2$ et une corrélation deux à deux $\rho$, la variance de la moyenne vaudrait :

$$\operatorname{Var}\Big(\frac1B\sum_{b=1}^{B}\hat f_b\Big) = \rho\,\sigma^2 + \frac{1-\rho}{B}\,\sigma^2$$

> 💡 **Autrement dit** — La variance de la moyenne a deux morceaux : la part **commune** à tous les arbres ($\rho\sigma^2$), qui ne disparaît jamais, et la part **individuelle**, divisée par le nombre d'arbres. Ajouter des arbres efface la seconde ; seule la décorrélation (des arbres plus différents) réduit la première.

Augmenter $B$ fait disparaître le second terme, mais pas le premier : des arbres trop semblables ne s'entraident pas. L'idée de Breiman (2001) est de **décorréler** les arbres en ne proposant, à chaque nœud, qu'un sous-ensemble aléatoire de variables (`max_features`, typiquement $\sqrt{p}$ en classification). C'est la **forêt aléatoire**.

Bonus pratique : chaque arbre n'a vu qu'environ 63 % des lignes ($1 - 1/e$). Les 37 % restantes, dites **hors sac** (*out-of-bag*, OOB), fournissent une estimation de la performance gratuite (`oob_score=True`), proche d'une validation croisée.

Une forêt se règle peu : `n_estimators` (plus c'est mieux, jusqu'à saturation ; elle ne sur-apprend pas en ajoutant des arbres), `max_features` et `min_samples_leaf`. C'est ce qui en fait un excellent modèle de référence (*baseline*).

## 4. Gradient boosting : apprendre de ses erreurs

### 4.1 L'idée de Friedman

> 🧠 **L'intuition d'abord** — On part d'une prédiction grossière (la moyenne), puis on ajoute un petit arbre chargé de corriger **ce qui reste faux**, puis un autre pour corriger le reste, et ainsi de suite, chaque correction étant volontairement modeste. **Analogie :** un peintre qui retouche son tableau. Premier jet approximatif, puis chaque passe corrige les défauts encore visibles, par petites touches, pour ne pas abîmer ce qui est déjà réussi.

Le boosting construit le modèle par étapes : $F_0$ est une constante (la moyenne), puis on ajoute à chaque étape un petit arbre $h_t$ multiplié par un **taux d'apprentissage** $\eta$ :

$$F_t(x) = F_{t-1}(x) + \eta\, h_t(x)$$

> 💡 **Autrement dit** — $F_t = F_{t-1} + \eta\,h_t$ : « nouveau modèle = ancien modèle + un petit pourcentage d'une correction ». $\eta$ (0,03 à 0,1) joue le même rôle que le pas de la descente de gradient : petites touches, mais nombreuses.

Quel arbre ajouter ? Celui qui pointe dans la direction de **plus forte descente** de la perte, comme en M24 L114, mais dans l'espace des fonctions. On calcule pour chaque exemple le **pseudo-résidu** $r_i = -\partial L(y_i, F)/\partial F\,\big|_{F_{t-1}(x_i)}$ et on ajuste $h_t$ sur ces $r_i$. Pour la perte quadratique $L = \tfrac12(y-F)^2$, le pseudo-résidu est simplement le **résidu** $y_i - F_{t-1}(x_i)$ : chaque arbre apprend ce que les précédents ont raté. Pour la BCE, c'est $y_i - \hat p_i$, la même forme que le gradient de la régression logistique de L115. Tout se tient.

### 4.2 Les implémentations modernes

| | `GradientBoosting` (sklearn) | `HistGradientBoosting` (sklearn) | XGBoost | LightGBM |
|---|---|---|---|---|
| Année | historique | 2019 (v0.21) | 2014-2016 | 2017 |
| Idée clé | Friedman « classique » | variables discrétisées en histogrammes (inspiré de LightGBM) | dérivées secondes + régularisation L1/L2 des feuilles | histogrammes, croissance par feuille, échantillonnage GOSS |
| Valeurs manquantes | à imputer | gérées nativement | gérées nativement | gérées nativement |
| Vitesse sur 1 M lignes | lente | rapide | rapide (GPU possible) | très rapide |
| Installation | incluse | incluse | `pip install xgboost` | `pip install lightgbm` |

Les hyperparamètres qui comptent, par ordre d'importance : `learning_rate` ($\eta$, 0,03 à 0,1) et le **nombre d'arbres**, réglés ensemble avec un **arrêt précoce** (*early stopping*) sur un jeu de validation ; puis la taille des arbres (`max_depth` 3 à 8, ou `max_leaf_nodes` / `num_leaves`) ; puis la régularisation (`min_samples_leaf`, `l2_regularization`, sous-échantillonnage des lignes et des colonnes). Contrairement à la forêt, **le boosting sur-apprend si on ajoute trop d'arbres** : l'arrêt précoce n'est pas une option.

> 💡 **Autrement dit** — Le peintre qui retouche sans fin finit par peindre les poussières sur la toile : au bout d'un moment, chaque arbre ajouté corrige le **bruit** des données d'entraînement. L'arrêt précoce pose le pinceau dès que le score de validation ne progresse plus.

> ⚠️ **Piège fréquent** — Comparer un gradient boosting réglé pendant deux heures à une régression logistique laissée par défaut, puis conclure que « le boosting gagne de 4 points ». Une comparaison honnête donne à chaque modèle le même budget de réglage et le même protocole de validation croisée.

Le script suivant compare les quatre approches avec une validation croisée stratifiée. XGBoost et LightGBM sont utilisés s'ils sont installés, sinon le script les ignore proprement.

```python
"""Arbre, forêt, gradient boosting : comparaison honnête par validation croisée."""
import time
from sklearn.datasets import load_breast_cancer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.tree import DecisionTreeClassifier

X, y = load_breast_cancer(return_X_y=True)
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

models = {
    "Arbre (profondeur 4)": DecisionTreeClassifier(max_depth=4, random_state=0),
    "Forêt aléatoire": RandomForestClassifier(n_estimators=300, oob_score=True, n_jobs=-1, random_state=0),
    "HistGradientBoosting": HistGradientBoostingClassifier(learning_rate=0.05, max_iter=500,
                                                           early_stopping=True, random_state=0),
}
try:
    from xgboost import XGBClassifier
    models["XGBoost"] = XGBClassifier(n_estimators=400, learning_rate=0.05, max_depth=4,
                                      subsample=0.8, colsample_bytree=0.8, random_state=0)
except ImportError:
    print("(XGBoost non installé : pip install xgboost)")
try:
    from lightgbm import LGBMClassifier
    models["LightGBM"] = LGBMClassifier(n_estimators=400, learning_rate=0.05, num_leaves=15,
                                        random_state=0, verbose=-1)
except ImportError:
    print("(LightGBM non installé : pip install lightgbm)")

for name, model in models.items():
    t = time.perf_counter()
    res = cross_validate(model, X, y, cv=cv, scoring=["roc_auc", "f1"])
    print(f"{name:<22} AUC={res['test_roc_auc'].mean():.4f} ± {res['test_roc_auc'].std():.4f}  "
          f"F1={res['test_f1'].mean():.3f}  ({time.perf_counter() - t:.1f} s)")

rf = models["Forêt aléatoire"].fit(X, y)
print(f"Score hors sac (OOB) de la forêt : {rf.oob_score_:.3f}")
```

Sur ce petit jeu (569 lignes), les écarts entre forêt et boosting sont souvent inférieurs à l'écart-type entre plis : ils ne sont pas significatifs. C'est un résultat fréquent et instructif. Le boosting creuse l'écart sur les grands jeux de données hétérogènes.

> 🔗 **Documentation officielle** — [scikit-learn — Ensembles: gradient boosting, random forests, bagging](https://scikit-learn.org/stable/modules/ensemble.html) 🇬🇧 · [XGBoost — documentation](https://xgboost.readthedocs.io/en/stable/) 🇬🇧 · [LightGBM — documentation](https://lightgbm.readthedocs.io/en/stable/) 🇬🇧

```mission
{
  "title": "Quand HistGradientBoosting active-t-il l'arrêt précoce tout seul ?",
  "url": "https://scikit-learn.org/stable/modules/ensemble.html",
  "steps": ["Ouvrez la page « Ensembles » du guide utilisateur scikit-learn", "Allez à la partie « Histogram-Based Gradient Boosting » et sa sous-section « Usage »", "Repérez le paragraphe sur l'early stopping et la valeur par défaut du paramètre early_stopping"],
  "question": "Quelle est la valeur par défaut de early_stopping dans HistGradientBoostingClassifier, et à partir de quelle taille de jeu d'entraînement l'arrêt précoce s'active-t-il automatiquement ?",
  "hint": "La valeur par défaut n'est ni True ni False.",
  "answer": "early_stopping='auto' : l'arrêt précoce est activé automatiquement si l'échantillon d'entraînement dépasse 10 000 lignes (validation interne prise sur une fraction des données, validation_fraction). Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 5. Importance des variables : ce que le modèle regarde vraiment

Le directeur financier vous demandera toujours : « qu'est-ce qui fait qu'un client paie en retard ? ». Deux outils, deux philosophies :

- **Importance par impureté** (*Mean Decrease in Impurity*, MDI), l'attribut `feature_importances_` : somme des baisses d'impureté apportées par chaque variable dans tous les arbres. Gratuite, mais **biaisée** : elle favorise les variables à nombreuses valeurs distinctes (un identifiant, un montant au centime) et elle est calculée sur le jeu d'entraînement, donc elle récompense aussi ce que le modèle a sur-appris.
- **Importance par permutation** : on mélange aléatoirement une colonne du jeu de **test** et on mesure la baisse du score. Si mélanger « délai de paiement moyen » fait chuter l'AUC de 0,08, le modèle en dépend. Plus coûteuse, mais fiable et indépendante du modèle.

L'expérience ci-dessous simule les devis d'une entreprise de rénovation : trois variables vraiment utiles (client déjà connu, relance téléphonique faite, montant du devis), une variable « région » sans effet, et une colonne de **bruit pur** continue. Un bon indicateur doit attribuer au bruit une importance nulle.

```python
"""Importance MDI vs permutation : l'expérience de la colonne de bruit."""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.model_selection import train_test_split

rng = np.random.default_rng(0)
n = 2_000
X = pd.DataFrame({
    "client_existant": rng.integers(0, 2, n),             # binaire, effet fort
    "relance_faite": rng.integers(0, 2, n),               # binaire, effet moyen
    "region": rng.integers(0, 5, n),                      # 5 valeurs, AUCUN effet
    "montant_k": rng.lognormal(1.5, 0.6, n).round(1),     # continu, effet négatif
})
logit = -0.5 + 1.2 * X.client_existant + 0.8 * X.relance_faite - 0.15 * X.montant_k
y = (rng.uniform(size=n) < 1 / (1 + np.exp(-logit))).astype(int)   # devis signé ?
X["BRUIT_aleatoire"] = rng.normal(size=n)                 # continu, aucune information

X_tr, X_te, y_tr, y_te = train_test_split(X, y, stratify=y, random_state=0)
rf = RandomForestClassifier(n_estimators=300, random_state=0, n_jobs=-1).fit(X_tr, y_tr)

mdi = pd.Series(rf.feature_importances_, index=X.columns)
perm = permutation_importance(rf, X_te, y_te, scoring="roc_auc", n_repeats=20, random_state=0)
perm = pd.Series(perm.importances_mean, index=X.columns)

table = pd.DataFrame({"MDI (entraînement)": mdi, "permutation (test)": perm})
print(table.sort_values("permutation (test)", ascending=False).round(4))
```

Le verdict est spectaculaire : la MDI place le **bruit en première position**, devant le montant, alors que la permutation lui donne une importance quasi nulle et remet « client existant » en tête. Pourquoi ? Une forêt aux arbres profonds découpe la colonne continue de bruit en des centaines de seuils pour isoler les exemples d'entraînement : chaque découpe fait baisser l'impureté… sur des données que l'arbre apprend par cœur. Les variables binaires, elles, ne peuvent être coupées qu'une fois par branche. La permutation, mesurée sur le test, ne se laisse pas abuser : mélanger le bruit ne dégrade rien.

> 💡 **Autrement dit** — L'importance par permutation, c'est **« débrancher » une variable** pour voir si la machine marche encore : on mélange la colonne (elle ne contient plus que du bruit) et on mesure la casse. Si rien ne casse, le modèle ne s'en servait pas vraiment, quoi qu'en dise la MDI.

```quiz
{
  "q": "Un directeur financier vous montre un graphique feature_importances_ d'une forêt : la variable la plus importante pour prédire les retards de paiement est « numéro de facture ». Quelle est la réaction la plus pertinente ?",
  "options": ["Conclure que la numérotation des factures cause les retards", "Supprimer toutes les autres variables pour simplifier le modèle final", "Passer au gradient boosting, qui ne fait jamais cette erreur", "Suspecter un biais ou une fuite ; vérifier par permutation"],
  "answer": 3,
  "explanation": "La MDI favorise les variables à forte cardinalité et récompense le sur-apprentissage. Si le numéro suit la date, il peut aussi trahir une fuite d'information. L'importance par permutation sur le test tranche."
}
```

Deux limites de la permutation à connaître : avec des variables **corrélées** (montant HT et montant TTC d'un même devis), mélanger l'une ne coûte rien puisque l'autre la remplace, et les deux paraissent inutiles ; regroupez-les ou permutez-les ensemble. Et l'importance mesure ce que **le modèle** utilise, pas une **causalité** : « les clients qui appellent le support résilient plus » ne signifie pas que le support fait fuir les clients. Pour des explications individuelles (« pourquoi ce client-là ? »), on utilise les valeurs de Shapley (bibliothèque open source SHAP), une méthode issue de la théorie des jeux que nous ne détaillons pas ici.

> 🎮 **Défi** — Dans le script précédent, ajoutez `min_samples_leaf=20` à la forêt. Que devient le rang du bruit selon la MDI ? Expliquez en une phrase le lien avec le sur-apprentissage de L116.

## 🧪 Exercice pratique

**Consigne.** Une fédération d'artisans du bâtiment veut prédire si un devis sera signé. Générez un jeu synthétique avec `sklearn.datasets.make_classification(n_samples=5000, n_features=15, n_informative=6, n_redundant=3, weights=[0.7], random_state=1)`, puis :
1. Établissez une baseline (régression logistique standardisée) et une forêt aléatoire.
2. Entraînez un `HistGradientBoostingClassifier` avec arrêt précoce ; affichez le nombre d'itérations effectivement retenues (`n_iter_`).
3. Faites varier `learning_rate` dans {0,3 ; 0,1 ; 0,03} et commentez le compromis vitesse / performance.
4. Produisez l'importance par permutation sur le test et repérez les variables redondantes.

**Critères de réussite.**
- Tous les modèles sont comparés sur les **mêmes** plis (`StratifiedKFold` partagé), avec moyenne et écart-type.
- Le jeu de test (20 %) n'est utilisé qu'à l'étape 4.
- Vous expliquez pourquoi un `learning_rate` plus faible demande plus d'itérations.
- Vous signalez au moins une paire de variables dont l'importance est « partagée ».

**Pistes de corrigé.** Avec $\eta$ plus petit, chaque arbre corrige moins, il en faut donc plus ; la performance finale est souvent légèrement meilleure, au prix du temps de calcul (c'est l'effet de *shrinkage* décrit par Friedman). Pour détecter la redondance, calculez `X.corr().abs()` et repérez les paires au-dessus de 0,9 ; leur importance par permutation individuelle est faible alors que leur permutation conjointe fait chuter le score.

## ✅ Auto-évaluation express
1. Calculez le Gini d'un nœud contenant 6 clients fidèles et 2 résiliés.
2. Pourquoi ajouter des arbres à une forêt ne provoque-t-il pas de sur-apprentissage, alors que c'est le cas pour le boosting ?
3. Votre `feature_importances_` place « numéro de facture » en tête. Que faites-vous ?

**Réponses.** 1. $1 - (0{,}75^2 + 0{,}25^2) = 1 - 0{,}625 = 0{,}375$. 2. Dans une forêt, les arbres sont indépendants et moyennés : en ajouter réduit la variance sans augmenter la complexité effective. Dans le boosting, chaque arbre ajouté corrige plus finement les résidus d'entraînement, y compris le bruit. 3. C'est le biais de la MDI pour les variables à forte cardinalité (ou une fuite d'information si la numérotation suit la date) : retirez la variable, vérifiez par permutation sur le test.

## 📚 Pour aller plus loin
- [MIT 6.036 — vidéos Fall 2020 de Tamara Broderick](https://tamarabroderick.com/ml.html) 🇬🇧 — leçon 12 « Decision trees and random forests ».
- [scikit-learn — Decision Trees](https://scikit-learn.org/stable/modules/tree.html) 🇬🇧 — critères d'impureté, élagage, complexité.
- [scikit-learn — Permutation feature importance](https://scikit-learn.org/stable/modules/permutation_importance.html) 🇬🇧 — méthode, limites, variables corrélées.

```mission
{
  "title": "Ce que la doc scikit-learn reproche à feature_importances_",
  "url": "https://scikit-learn.org/stable/modules/permutation_importance.html",
  "steps": ["Ouvrez la page « Permutation feature importance »", "Lisez la section qui compare avec l'importance basée sur l'impureté (« Relation to impurity-based importance in trees »)", "Puis lisez l'avertissement sur les variables fortement corrélées"],
  "question": "Quels sont les deux défauts de l'importance par impureté cités par la documentation, et que se passe-t-il avec la permutation quand deux variables sont fortement corrélées ?",
  "hint": "Un défaut concerne le jeu de données sur lequel elle est calculée, l'autre le nombre de valeurs distinctes des variables.",
  "answer": "L'importance par impureté est calculée sur le jeu d'entraînement (elle peut valoriser des variables utiles seulement au sur-apprentissage) et elle favorise les variables à forte cardinalité (nombreuses valeurs distinctes). Avec des variables corrélées, permuter l'une a peu d'effet car le modèle retrouve l'information dans l'autre : les deux peuvent paraître peu importantes. Doc stable, nov. 2026.",
  "xp": 15
}
```

- [XGBoost — documentation](https://xgboost.readthedocs.io/en/stable/) 🇬🇧 — tutoriel « Introduction to Boosted Trees » et guide des paramètres.
- [LightGBM — documentation](https://lightgbm.readthedocs.io/en/stable/) 🇬🇧 — réglage de `num_leaves`, `min_data_in_leaf` et GOSS.
- [DeepLearning.AI — Machine Learning Specialization](https://deeplearning.ai/courses/machine-learning-specialization) 🇬🇧 — cours 2, semaine 4 : arbres, forêts aléatoires, XGBoost.

> 🗺️ **Et maintenant ?** — Jusqu'ici, chaque exemple avait sa « bonne réponse » ; la leçon L118 explore l'apprentissage **non supervisé**, où l'on cherche des groupes (k-means) et des directions principales (PCA) dans des données sans étiquette.
