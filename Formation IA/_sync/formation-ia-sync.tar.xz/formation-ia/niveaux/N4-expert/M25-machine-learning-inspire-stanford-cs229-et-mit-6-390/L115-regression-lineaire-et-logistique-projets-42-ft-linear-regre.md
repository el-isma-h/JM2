---
id: L115
module: M25
level: N4
title: "Régression linéaire et logistique (projets 42 ft_linear_regression, DSLR)"
minutes: 65
objectives:
  - "Implémenter from scratch une régression linéaire entraînée par descente de gradient, dans l'esprit du projet 42 ft_linear_regression"
  - "Dériver la fonction de coût et le gradient de la régression logistique à partir du maximum de vraisemblance (lien M24)"
  - "Construire un classifieur multiclasse one-vs-all comme dans le projet 42 DSLR et le comparer à scikit-learn"
  - "Choisir et interpréter les métriques adaptées : MAE, RMSE, R², matrice de confusion, précision, rappel, F1"
skills: ["C4.2", "C4.1"]
sources:
  - { title: "Stanford CS229 — Machine Learning (notes de cours : régression linéaire, logistique, GLM)", url: "https://cs229.stanford.edu/", lang: "en" }
  - { title: "MIT 6.390 IntroML — Fall 2026", url: "https://introml.mit.edu/fall26/info", lang: "en" }
  - { title: "42 AI — bootcamp_machine-learning (modules 06 à 09)", url: "https://github.com/42-AI/bootcamp_machine-learning", lang: "en" }
  - { title: "Dépôt étudiant — 42 ft_linear_regression (madvid)", url: "https://github.com/madvid/42_ft_linear_regression", lang: "en" }
  - { title: "Dépôt étudiant — 42 DSLR (madvid)", url: "https://github.com/madvid/42_DSLR", lang: "en" }
  - { title: "scikit-learn — Linear Models", url: "https://scikit-learn.org/stable/modules/linear_model.html", lang: "en" }
  - { title: "scikit-learn — Metrics and scoring", url: "https://scikit-learn.org/stable/modules/model_evaluation.html", lang: "en" }
---

# Régression linéaire et logistique (projets 42 ft_linear_regression, DSLR)

> ⏱ 65 min · 🎯 Niveau 4 · 📚 Module 25

## 🎯 Ce que vous saurez faire
- Écrire en NumPy pur un `train` et un `predict` de régression linéaire, normalisation comprise, et vérifier votre résultat contre la solution exacte.
- Retrouver la formule de l'entropie croisée binaire (*binary cross-entropy*, BCE) à partir de la vraisemblance d'une loi de Bernoulli vue en M24 (L113).
- Entraîner un classifieur multiclasse « un contre tous » (*one-vs-all*, OvA) et lire sa matrice de confusion.
- Dire, pour un cas métier, quelle métrique vous allez optimiser et pourquoi l'exactitude (*accuracy*) peut mentir.

> 🧭 **En clair** — Un garagiste qui estime le prix d'une voiture d'occasion « à l'œil » applique sans le savoir une **régression linéaire** : plus il y a de kilomètres, moins c'est cher, à peu près en ligne droite. Le machine learning trace cette droite automatiquement, en la déplaçant petit à petit jusqu'à ce qu'elle colle au mieux aux ventes passées. La **régression logistique** fait la même chose pour répondre par oui ou non (« ce client va-t-il partir ? ») : elle donne une probabilité entre 0 et 100 %. Enfin, mesurer la qualité d'un modèle est un choix métier : un détecteur qui ne rate aucune fraude mais déclenche mille fausses alertes n'est pas forcément « meilleur ».

## 1. Deux siècles de droites : d'où vient la régression

En 1805, Adrien-Marie Legendre publie la **méthode des moindres carrés** pour calculer l'orbite des comètes ; Carl Friedrich Gauss affirme en 1809 l'utiliser depuis 1795, et la querelle de priorité dure encore dans les manuels. Le mot « régression » vient, lui, de Francis Galton (1886) : les enfants de parents très grands sont en moyenne plus petits qu'eux, la taille « régresse vers la moyenne ». Le vocabulaire est resté, même si le sens a glissé : aujourd'hui, une **régression** désigne toute prédiction d'une valeur numérique continue (un prix, un délai, une consommation), et une **classification** la prédiction d'une catégorie.

Stanford CS229 ouvre ses notes de cours exactement par ces deux modèles, puis montre qu'ils sont deux cas d'une même famille, les modèles linéaires généralisés (*Generalized Linear Models*, GLM). MIT 6.390 suit le même chemin (classification linéaire en semaine 4). Andrew Ng, dans la Machine Learning Specialization (cours 1), y consacre ses trois premières semaines. Ce consensus n'est pas un hasard : **tout ce que vous ferez ensuite en deep learning (M26) est une régression logistique empilée**. Un neurone, c'est $\sigma(w^\top x + b)$.

À 42, la branche « Algo, AI, data » traduit cette progression en deux projets : **ft_linear_regression** (prédire le prix d'une voiture d'occasion à partir de son kilométrage) puis **DSLR** (*Datascience X Logistic Regression* : recréer le Choixpeau magique de Poudlard). Les sujets officiels sont réservés à l'intranet 42 ; nous nous inspirons ici de leurs objectifs publics, connus par les dépôts d'étudiants, sans les reproduire.

> 💡 **À retenir** — Un modèle supervisé, c'est trois choix : une **hypothèse** $h_\theta(x)$ (la forme du modèle), un **coût** $J(\theta)$ (ce qu'on paie quand on se trompe) et un **optimiseur** (comment on fait baisser $J$). Changez l'un des trois et vous changez d'algorithme.

## 2. Régression linéaire : de la formule au code

### 2.1 Hypothèse et coût

> 🧠 **L'intuition d'abord** — On cherche la **droite** qui passe au plus près d'un nuage de points (kilométrage, prix), puis on mesure la qualité de la droite par la moyenne des erreurs **au carré** : une grosse erreur coûte beaucoup plus cher que deux petites. **Analogie :** tendre un élastique au milieu de clous plantés sur une planche. Chaque clou tire l'élastique vers lui, d'autant plus fort qu'il est loin ; l'élastique se stabilise à la position qui équilibre toutes les tensions.

Pour une seule variable (le kilométrage $x$), l'hypothèse est une droite :

$$\hat{y} = h_\theta(x) = \theta_0 + \theta_1 x$$

Avec $m$ exemples, on mesure l'erreur par l'**erreur quadratique moyenne** (*Mean Squared Error*, MSE), divisée par 2 pour simplifier la dérivée :

$$J(\theta_0, \theta_1) = \frac{1}{2m}\sum_{i=1}^{m}\left(h_\theta(x^{(i)}) - y^{(i)}\right)^2$$

> 💡 **Autrement dit** — $\theta_0$ est le prix d'une voiture à 0 km (l'ordonnée à l'origine), $\theta_1$ la perte de valeur par kilomètre (la pente). $J$ est la « facture d'erreur » de la droite : pour chaque voiture, l'écart entre prix prédit et prix réel, au carré, puis la moyenne. Entraîner, c'est trouver les deux nombres qui rendent cette facture la plus basse possible.

Pourquoi le carré ? Parce que, si l'on suppose un bruit gaussien $y = \theta^\top x + \varepsilon$ avec $\varepsilon \sim \mathcal{N}(0, \sigma^2)$, **minimiser la MSE revient exactement à maximiser la vraisemblance** (démonstration de CS229, à refaire avec vos outils de M24 L113 : prenez le logarithme de la densité gaussienne, les constantes disparaissent, il reste la somme des carrés).

### 2.2 Le gradient et la mise à jour simultanée

En dérivant $J$ (M24 L112), on obtient :

$$\frac{\partial J}{\partial \theta_0} = \frac{1}{m}\sum_{i}\left(\hat{y}^{(i)} - y^{(i)}\right) \qquad \frac{\partial J}{\partial \theta_1} = \frac{1}{m}\sum_{i}\left(\hat{y}^{(i)} - y^{(i)}\right)x^{(i)}$$

> 💡 **Autrement dit** — Les deux gradients répondent à « de combien la facture d'erreur bouge si je monte un peu la droite ($\theta_0$) ou si je l'incline un peu ($\theta_1$) ? ». Le second est multiplié par $x$ : les voitures à fort kilométrage pèsent davantage dans la correction de la pente.

La descente de gradient (M24 L114) répète $\theta_j \leftarrow \theta_j - \alpha\,\partial J / \partial \theta_j$ avec un taux d'apprentissage $\alpha$. Le sujet ft_linear_regression insiste sur un détail qui piège chaque promotion : la mise à jour doit être **simultanée**. On calcule les deux gradients avec les anciens $\theta$, *puis* on met à jour les deux. Mettre à jour $\theta_0$ puis réutiliser le nouveau $\theta_0$ pour $\theta_1$ donne un autre algorithme, qui converge mal.

```quiz
{
  "q": "Dans votre ft_linear_regression, vous écrivez : t0 = t0 − α·grad0(t0, t1), puis t1 = t1 − α·grad1(t0, t1). Quel est le problème ?",
  "options": ["Aucun, l'ordre des lignes n'a pas d'importance", "Il faut toujours mettre à jour t1 avant t0 pour que ça converge", "grad1 utilise déjà le nouveau t0 (pas simultané)", "Le taux α doit être différent pour t0 et pour t1, sinon ça diverge"],
  "answer": 2,
  "explanation": "Les deux gradients doivent être calculés avec les anciennes valeurs, puis appliqués ensemble (variables temporaires tmp0, tmp1). Sinon grad1 utilise un t0 déjà modifié : ce n'est plus la descente de gradient demandée par le sujet."
}
```

### 2.3 La normalisation, ou pourquoi votre gradient explose

> 🧠 **L'intuition d'abord** — Si une variable se compte en centaines de milliers et l'autre en unités, la descente de gradient « voit » l'une énorme et l'autre minuscule, et aucun pas ne convient aux deux. On les remet donc à la même échelle avant d'apprendre, puis on reconvertit le résultat. **Analogie :** comparer des prix en centimes et des distances en années-lumière ; on convertit tout en unités comparables avant de raisonner, puis on retraduit la conclusion dans les unités du client.

Les kilométrages valent de 20 000 à 250 000 ; les prix de 3 000 à 9 000. Le gradient selon $\theta_1$ est multiplié par $x$, donc environ 100 000 fois plus grand que celui selon $\theta_0$. Avec $\alpha = 0{,}1$, tout diverge en trois itérations ; avec $\alpha = 10^{-11}$, $\theta_0$ ne bouge plus. La solution est de **standardiser** : $x' = (x - \mu)/\sigma$. Après l'entraînement, il faut « dé-normaliser » les paramètres pour que `predict` fonctionne sur des kilomètres bruts :

$$\theta_1 = \frac{\theta'_1}{\sigma}, \qquad \theta_0 = \theta'_0 - \theta'_1\frac{\mu}{\sigma}$$

> 💡 **Autrement dit** — Standardiser = « combien d'écarts-types au-dessus ou en dessous de la moyenne ». Après l'entraînement, les deux formules de dé-normalisation traduisent la droite apprise « en écarts-types » en une droite « en kilomètres », pour que `predict` accepte un kilométrage brut.

Voici une implémentation complète, avec un jeu de données synthétique de même forme que le `data.csv` du projet (colonnes `km`, `price`). Remplacez la génération par `pd.read_csv("data.csv")` si vous avez le fichier.

```python
"""Régression linéaire univariée from scratch (esprit 42 ft_linear_regression)."""
import json
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
km = rng.uniform(20_000, 250_000, size=24).round()
price = (9_000 - 0.022 * km + rng.normal(0, 400, size=24)).round()
df = pd.DataFrame({"km": km, "price": price})  # ou : pd.read_csv("data.csv")


def estimate_price(mileage, theta0, theta1):
    """Hypothèse du modèle : une droite."""
    return theta0 + theta1 * mileage


def train(x, y, alpha=0.1, n_iter=2_000):
    """Descente de gradient sur données standardisées, puis dé-normalisation."""
    mu, sigma = x.mean(), x.std()
    xs = (x - mu) / sigma
    t0, t1 = 0.0, 0.0                      # le sujet part de thetas nuls
    m = len(x)
    history = []
    for _ in range(n_iter):
        err = estimate_price(xs, t0, t1) - y
        tmp0 = alpha * err.sum() / m          # gradients calculés AVANT la mise à jour
        tmp1 = alpha * (err * xs).sum() / m
        t0, t1 = t0 - tmp0, t1 - tmp1         # mise à jour simultanée
        history.append((err ** 2).mean() / 2)
    theta1 = t1 / sigma
    theta0 = t0 - t1 * mu / sigma
    return theta0, theta1, history


theta0, theta1, hist = train(df.km.to_numpy(), df.price.to_numpy())
with open("thetas.json", "w") as f:            # le programme predict relira ce fichier
    json.dump({"theta0": theta0, "theta1": theta1}, f)

# Vérification : solution exacte des moindres carrés (équations normales)
X = np.c_[np.ones(len(df)), df.km]
exact = np.linalg.lstsq(X, df.price, rcond=None)[0]
print(f"Descente de gradient : theta0={theta0:.2f}, theta1={theta1:.6f}")
print(f"Moindres carrés      : theta0={exact[0]:.2f}, theta1={exact[1]:.6f}")
print(f"Coût initial {hist[0]:.0f} -> final {hist[-1]:.0f}")
print("Prix estimé pour 120 000 km :", round(estimate_price(120_000, theta0, theta1)), "€")
```

La dernière vérification est votre filet de sécurité : la **solution analytique** $\theta = (X^\top X)^{-1}X^\top y$ (les « équations normales » de CS229) doit coïncider avec votre descente de gradient à quelques centimes près. Si ce n'est pas le cas, le bug est chez vous.

> ⚠️ **Piège fréquent** — Utiliser `numpy.polyfit` ou `sklearn.LinearRegression` pour le `train` d'un projet « from scratch ». Les correcteurs 42 le repèrent immédiatement. Servez-vous-en uniquement pour **vérifier** votre résultat, comme ci-dessus.

## 3. Régression logistique : la probabilité d'appartenir à une classe

### 3.1 La sigmoïde et la vraisemblance de Bernoulli

> 🧠 **L'intuition d'abord** — Une droite peut prédire n'importe quel nombre, y compris 150 % ou −20 %, ce qui n'a aucun sens pour une probabilité. La **sigmoïde** prend la sortie de la droite et la « tord » en S pour qu'elle reste entre 0 et 1. **Analogie :** un variateur de lumière. Vous pouvez tourner le bouton aussi loin que vous voulez, la lampe ne dépassera jamais 100 % ni ne descendra sous 0 % ; près du milieu, elle réagit vite, aux extrémités, presque plus.

Pour une classe binaire $y \in \{0, 1\}$ (« élève de Gryffondor ou non », « client qui résilie ou non »), on veut une probabilité. On écrase donc la droite dans $]0, 1[$ avec la **sigmoïde** :

$$\hat{p} = h_\theta(x) = \sigma(\theta^\top x) = \frac{1}{1 + e^{-\theta^\top x}}$$

> 💡 **Autrement dit** — Score très positif → probabilité proche de 1 ; score très négatif → proche de 0 ; score nul → exactement 0,5 (le modèle hésite complètement).

On modélise $y$ comme une loi de Bernoulli de paramètre $\hat p$ (M24 L113) : $P(y \mid x) = \hat{p}^{\,y}(1-\hat{p})^{1-y}$. La log-vraisemblance négative moyenne donne la **BCE**, le coût du projet DSLR :

$$J(\theta) = -\frac{1}{m}\sum_{i=1}^{m}\left[y^{(i)}\log \hat{p}^{(i)} + (1-y^{(i)})\log(1-\hat{p}^{(i)})\right]$$

> 🧠 **L'intuition d'abord** — La BCE punit la **confiance mal placée**. Si la vraie réponse est « oui » et que le modèle disait 90 % oui, l'amende est faible ; s'il disait 1 % oui, l'amende est énorme (le logarithme explose près de 0). **Analogie :** un pari sportif. Miser un peu sur le mauvais cheval coûte peu ; miser toute sa fortune sur le mauvais cheval est ruineux.

> 💡 **Autrement dit** — Dans la somme, un seul des deux termes est actif à chaque fois : $\log \hat p$ quand la vraie classe est 1, $\log(1-\hat p)$ quand elle est 0. On paie « moins le log de la probabilité accordée à la bonne réponse ».

Miracle de calcul (à refaire à la main, c'est un classique d'examen) : grâce à $\sigma'(z) = \sigma(z)(1-\sigma(z))$, le gradient a **exactement la même forme** que pour la régression linéaire :

$$\nabla_\theta J = \frac{1}{m}X^\top(\hat{p} - y)$$

C'est la propriété des GLM que CS229 met en avant : même mise à jour, seule la fonction de lien change.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour la régression logistique avec la BCE, le gradient s'écrit (1/m)·Xᵀ(p̂ − y), exactement la même forme que pour la régression linéaire, à ceci près que p̂ passe par une sigmoïde.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. Grâce à σ'(z) = σ(z)(1 − σ(z)), les termes se simplifient : « erreur × entrée », comme en régression linéaire. Seule la fonction de lien change (propriété des GLM)."
}
```

### 3.2 Du binaire au multiclasse : one-vs-all

DSLR demande de prédire l'une des **quatre maisons** de Poudlard à partir des notes des élèves dans une douzaine de matières (jeu d'entraînement d'environ 1 600 lignes). La stratégie imposée est le **un contre tous** : on entraîne quatre classifieurs binaires (« Gryffondor contre le reste », « Serpentard contre le reste »…), puis on prédit la maison dont le classifieur renvoie la probabilité la plus haute.

```
           ┌─ θ_Gryffondor ─→ p = 0,81 ─┐
élève x ───┼─ θ_Serdaigle  ─→ p = 0,07 ─┼─→ argmax → Gryffondor
           ├─ θ_Poufsouffle ─→ p = 0,12 ─┤
           └─ θ_Serpentard ─→ p = 0,02 ─┘
```

Pour rester exécutable sans le fichier du projet, nous utilisons le jeu *Wine* de scikit-learn : 178 vins, **3 cépages**, **13 mesures chimiques**. Même structure, autre univers.

```python
"""Régression logistique one-vs-all from scratch (esprit 42 DSLR), comparée à scikit-learn."""
import numpy as np
from sklearn.datasets import load_wine
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split

X, y = load_wine(return_X_y=True)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, stratify=y, random_state=0)

# Standardisation avec les statistiques du SEUL jeu d'entraînement
mu, sd = X_tr.mean(axis=0), X_tr.std(axis=0)
X_tr_s, X_te_s = (X_tr - mu) / sd, (X_te - mu) / sd


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


def add_bias(X):
    return np.c_[np.ones(len(X)), X]


def fit_binary(X, y01, alpha=0.5, n_iter=3_000):
    """Descente de gradient batch sur la BCE."""
    Xb = add_bias(X)
    theta = np.zeros(Xb.shape[1])
    for _ in range(n_iter):
        p = sigmoid(Xb @ theta)
        theta -= alpha * Xb.T @ (p - y01) / len(y01)
    return theta


def fit_ova(X, y):
    classes = np.unique(y)
    return classes, np.array([fit_binary(X, (y == c).astype(float)) for c in classes])


def predict_ova(X, classes, thetas):
    proba = sigmoid(add_bias(X) @ thetas.T)       # une colonne par classifieur
    return classes[proba.argmax(axis=1)]


classes, thetas = fit_ova(X_tr_s, y_tr)
y_pred = predict_ova(X_te_s, classes, thetas)

ref = LogisticRegression(max_iter=1_000).fit(X_tr_s, y_tr)
print("Exactitude from scratch :", round(accuracy_score(y_te, y_pred), 3))
print("Exactitude scikit-learn :", round(accuracy_score(y_te, ref.predict(X_te_s)), 3))
print(confusion_matrix(y_te, y_pred))
print(classification_report(y_te, y_pred, digits=3))
```

Le sujet DSLR exige aussi un `describe` réimplémenté (moyenne, écart-type, quartiles… sans `pandas.describe`), un histogramme pour trouver la matière dont la distribution est homogène entre maisons, un nuage de points pour repérer deux matières redondantes et une *pair plot* pour choisir les variables. C'est de l'**analyse exploratoire** (EDA) : vous la systématiserez en L120. En bonus, il propose de remplacer la descente batch par une descente **stochastique** (SGD) ou **mini-batch**, que vous avez codées en M24 L114.

> 🔗 **Documentation officielle** — [scikit-learn — Linear Models (régression logistique, Ridge, Lasso)](https://scikit-learn.org/stable/modules/linear_model.html) 🇬🇧

```mission
{
  "title": "La régression logistique de scikit-learn est-elle régularisée par défaut ?",
  "url": "https://scikit-learn.org/stable/modules/linear_model.html",
  "steps": ["Ouvrez la page « Linear Models » du guide utilisateur scikit-learn", "Allez à la section « Logistic regression »", "Repérez la phrase sur la régularisation et le rôle du paramètre C"],
  "question": "La classe LogisticRegression applique-t-elle une régularisation par défaut, et que représente le paramètre C ?",
  "hint": "C est l'inverse de quelque chose : plus C est petit, plus…",
  "answer": "Oui : une régularisation L2 est appliquée par défaut. C est l'inverse de la force de régularisation (petit C = régularisation forte). C'est pourquoi le résultat diffère légèrement d'une implémentation « from scratch » non régularisée. Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Les métriques : mesurer, c'est déjà choisir

### 4.1 Régression

| Métrique | Formule | Unité | Quand l'utiliser |
|---|---|---|---|
| MAE | $\frac1m\sum\lvert y-\hat y\rvert$ | celle de $y$ (€) | erreur « typique », robuste aux valeurs extrêmes |
| RMSE | $\sqrt{\frac1m\sum (y-\hat y)^2}$ | celle de $y$ (€) | pénalise fortement les grosses erreurs |
| R² | $1 - \frac{\sum (y-\hat y)^2}{\sum (y-\bar y)^2}$ | sans unité | part de variance expliquée ; 0 = pas mieux que la moyenne |
| MAPE | $\frac1m\sum \lvert (y-\hat y)/y\rvert$ | % | parlant pour un commercial, instable si $y \approx 0$ |

Un garagiste de Montreuil comprendra « en moyenne, je me trompe de 350 € » (MAE) ; il ne comprendra pas « R² = 0,87 ». Choisissez la métrique **qu'on peut expliquer au client**, et gardez les autres pour vous.

### 4.2 Classification

> 🧠 **L'intuition d'abord** — **Précision** et **rappel** répondent à deux peurs différentes. Précision : « quand je crie au loup, y a-t-il vraiment un loup ? ». Rappel : « parmi tous les loups qui sont venus, combien en ai-je vus ? ». **Analogie :** un filet de pêche. Un filet à mailles fines attrape presque tous les poissons visés (bon rappel) mais aussi des algues et des cailloux (mauvaise précision) ; un filet à grosses mailles ne remonte que de beaux poissons (bonne précision) mais en laisse filer beaucoup (mauvais rappel).

La **matrice de confusion** croise vérité et prédiction. Pour une classe positive (« client qui va résilier ») :

|  | prédit positif | prédit négatif |
|---|---|---|
| **vraiment positif** | VP (vrai positif) | FN (faux négatif) |
| **vraiment négatif** | FP (faux positif) | VN (vrai négatif) |

- **Précision** (*precision*) $= \frac{VP}{VP+FP}$ : quand j'alerte, ai-je raison ?
- **Rappel** (*recall*) $= \frac{VP}{VP+FN}$ : parmi les vrais cas, combien en ai-je trouvé ?
- **F1** $= 2\frac{P \cdot R}{P+R}$ : moyenne harmonique, punit le déséquilibre entre les deux.
- **ROC AUC** : probabilité qu'un positif tiré au hasard reçoive un score supérieur à un négatif tiré au hasard ; indépendante du seuil.

> 💡 **Autrement dit** — Le F1 ne peut être élevé que si précision **et** rappel le sont : avec une précision de 1,0 et un rappel de 0,1, la moyenne simple donnerait 0,55, le F1 seulement 0,18. Il empêche de « tricher » en sacrifiant l'un des deux.

Attention : le mot anglais *precision* se traduit par « précision », mais beaucoup de sujets (y compris certaines versions de DSLR) disent « précision » pour l'**exactitude** (*accuracy*). Lisez toujours la formule.

> ⚠️ **Piège fréquent** — Dans une PME où 3 % des clients résilient chaque année, un modèle qui répond toujours « ne résilie pas » obtient 97 % d'exactitude… et ne sert à rien. Sur données déséquilibrées, regardez le rappel, la précision, le F1 ou l'AUC, jamais l'exactitude seule.

```quiz
{
  "q": "Un cabinet d'expertise comptable veut repérer les dossiers clients à risque de redressement fiscal, pour les revoir avant tout contrôle. Rater un dossier à risque coûte très cher ; revoir un dossier sain coûte une heure de travail. Quelle métrique privilégiez-vous ?",
  "options": ["Le rappel", "L'exactitude (accuracy)", "La précision", "Le R²"],
  "answer": 0,
  "explanation": "Le coût d'un faux négatif (dossier à risque raté) est bien supérieur à celui d'un faux positif : on veut trouver le plus possible de vrais cas, donc maximiser le rappel, quitte à abaisser le seuil. Le R² est une métrique de régression."
}
```

### 4.3 Le seuil est une décision métier

Une régression logistique renvoie une probabilité ; le seuil 0,5 n'est qu'une convention. Un cabinet comptable qui veut détecter les factures suspectes avant un contrôle fiscal préférera un seuil bas (rappel élevé, quitte à vérifier des faux positifs). Une banque qui bloque des cartes préférera un seuil haut (précision élevée, pour ne pas fâcher ses clients). Tracez la courbe précision-rappel et choisissez le seuil **avec** le métier, en chiffrant le coût d'un FP et d'un FN.

> 🎮 **Défi** — Dans le code Wine ci-dessus, combien d'itérations faut-il au minimum pour atteindre la même exactitude que scikit-learn ? Tracez le coût BCE par itération pour chacun des trois classifieurs et identifiez le cépage « le plus facile » à séparer.

## 🧪 Exercice pratique

**Consigne.** Transformez le premier script en deux programmes, comme l'exige ft_linear_regression : `train.py` (lit les données, entraîne, écrit `thetas.json`) et `predict.py` (demande un kilométrage à l'utilisateur, lit `thetas.json`, affiche le prix ; si le fichier n'existe pas, $\theta_0 = \theta_1 = 0$). Ajoutez en bonus : (1) un graphique matplotlib des points et de la droite, (2) un calcul de MAE, RMSE et R² **implémentés à la main**, comparés à `sklearn.metrics`.

**Critères de réussite.**
- `predict.py` fonctionne avant tout entraînement (renvoie 0) et gère une saisie invalide (texte, nombre négatif) sans planter.
- Les thetas obtenus diffèrent de moins de 0,1 % de ceux de `np.linalg.lstsq`.
- Vos trois métriques maison sont égales à celles de scikit-learn à $10^{-9}$ près.
- La courbe du coût décroît de façon monotone (sinon, $\alpha$ est trop grand).

**Pistes de corrigé.** R² se calcule par `1 - ((y - yhat)**2).sum() / ((y - y.mean())**2).sum()`. Pour la saisie, encadrez `float(input(...))` dans un `try/except ValueError`. Pour le graphique : `plt.scatter(km, price)` puis `plt.plot(xs, theta0 + theta1 * xs, color="red")` sur `xs = np.linspace(km.min(), km.max(), 100)`, et `plt.savefig("regression.png")`.

## ✅ Auto-évaluation express
1. Pourquoi faut-il standardiser le kilométrage avant la descente de gradient ?
2. Quelle hypothèse probabiliste justifie la BCE comme fonction de coût ?
3. Un modèle de détection de fraude a 99 % d'exactitude sur des données à 1 % de fraude. Que pouvez-vous en conclure ?

**Réponses.** 1. Sans mise à l'échelle, les gradients des paramètres ont des ordres de grandeur très différents : aucun taux d'apprentissage unique ne convient (divergence ou immobilité). 2. La cible est modélisée par une loi de Bernoulli de paramètre $\sigma(\theta^\top x)$ ; la BCE est sa log-vraisemblance négative moyenne. 3. Rien : un modèle qui ne détecte jamais la fraude obtient aussi 99 %. Il faut le rappel, la précision et la matrice de confusion.

## 📚 Pour aller plus loin
- [Stanford CS229 — Machine Learning](https://cs229.stanford.edu/) 🇬🇧 — notes de cours publiques : moindres carrés, régression logistique, GLM (chapitres 1 à 3).
- [MIT 6.390 IntroML (Fall 2026)](https://introml.mit.edu/fall26/info) 🇬🇧 — successeur de 6.036, classification linéaire et méthodes de gradient (CC BY-NC-SA 4.0).
- [42 AI — bootcamp_machine-learning](https://github.com/42-AI/bootcamp_machine-learning) 🇬🇧 — modules 06 à 09 : régression univariée, multivariée, logistique, régularisation ; idéal pour s'entraîner avant ft_linear_regression et DSLR.
- [DeepLearning.AI — Machine Learning Specialization](https://deeplearning.ai/courses/machine-learning-specialization) 🇬🇧 — cours 1 d'Andrew Ng (régression et classification), audit gratuit.
- [Google — Machine Learning Crash Course](https://developers.google.com/machine-learning/crash-course) 🇬🇧 — modules « Linear Regression », « Logistic Regression » et « Classification » avec visualisations interactives.
- [scikit-learn — Metrics and scoring](https://scikit-learn.org/stable/modules/model_evaluation.html) 🇬🇧 — définition exacte de chaque métrique et de chaque `scoring`.

```mission
{
  "title": "Le bon nom de « scoring » pour un F1 multiclasse",
  "url": "https://scikit-learn.org/stable/modules/model_evaluation.html",
  "steps": ["Ouvrez la page « Metrics and scoring » de scikit-learn", "Repérez le tableau des valeurs prédéfinies du paramètre scoring", "Cherchez la ligne Classification consacrée au F1 et ses variantes"],
  "question": "Quelle chaîne passer à scoring= dans cross_val_score pour obtenir un F1 moyenné de façon égale sur les 3 cépages du jeu Wine, et quelle chaîne pour l'aire sous la courbe ROC ?",
  "hint": "Le suffixe indique le mode de moyenne : _micro, _macro, _weighted…",
  "answer": "'f1_macro' (moyenne non pondérée des F1 par classe) et 'roc_auc' (en multiclasse : 'roc_auc_ovr' ou 'roc_auc_ovo'). Doc scikit-learn stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

> 🗺️ **Et maintenant ?** — Votre modèle colle aux données d'entraînement ; la leçon L116 vous apprend à vérifier qu'il fonctionnera aussi sur des données **qu'il n'a jamais vues**, grâce au compromis biais-variance, à la régularisation et à la validation croisée.
