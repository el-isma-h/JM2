---
id: L145
module: M29
level: N4
title: "Edge et NPU : l'IA embarquée"
minutes: 60
objectives:
  - "Expliquer ce qu'est un NPU, ce que mesurent les TOPS et pourquoi la bande passante mémoire reste la limite des LLM embarqués"
  - "Comparer les plateformes edge (Apple Neural Engine, Qualcomm Hexagon, NPU Intel et AMD, PC Copilot+) et leurs piles logicielles (Core ML, MLX, ONNX Runtime, ExecuTorch, LiteRT)"
  - "Construire et exécuter un modèle de 4 milliards de paramètres ou moins quantifié en 4 bits avec ONNX Runtime GenAI ou MLX"
  - "Évaluer un cas d'usage embarqué (latence, confidentialité, hors-ligne, autonomie) et concevoir un routage hybride edge / cloud"
skills: ["C4.5"]
sources:
  - { title: "ONNX Runtime — documentation (execution providers, GenAI)", url: "https://onnxruntime.ai/docs/", lang: "en" }
  - { title: "ExecuTorch — dépôt officiel (PyTorch)", url: "https://github.com/pytorch/executorch", lang: "en" }
  - { title: "Apple — Core ML documentation", url: "https://developer.apple.com/documentation/coreml", lang: "en" }
  - { title: "Apple Machine Learning Research — Exploring LLMs with MLX and the Neural Accelerators in the M5 GPU", url: "https://machinelearning.apple.com/research/exploring-llms-mlx-m5", lang: "en" }
  - { title: "Google AI Edge — LiteRT-LM, Gemma 4", url: "https://ai.google.dev/edge/litert-lm/models/gemma-4", lang: "en" }
  - { title: "MLX LM — dépôt officiel", url: "https://github.com/ml-explore/mlx-lm", lang: "en" }
  - { title: "OpenVINO — documentation", url: "https://docs.openvino.ai/", lang: "en" }
  - { title: "DataNorth — Google releases Gemma 4 open models", url: "https://datanorth.ai/news/google-releases-gemma-4-open-models", lang: "en" }
  - { title: "Microsoft — Phi-4-mini-instruct (model card)", url: "https://huggingface.co/microsoft/Phi-4-mini-instruct", lang: "en" }
---

# Edge et NPU : l'IA embarquée

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 29

## 🎯 Ce que vous saurez faire
- Lire une fiche technique « 45 TOPS » sans vous laisser impressionner, et estimer la vitesse réelle d'un LLM sur un téléphone ou un PC portable.
- Choisir la bonne pile logicielle pour un appareil donné : Core ML et MLX (Apple), ONNX Runtime (Windows, Qualcomm, Intel, AMD), ExecuTorch (mobile), LiteRT (Android).
- Exporter et faire tourner un modèle de 4B ou moins en 4 bits, hors ligne, avec une mesure de débit.
- Décider quand l'embarqué est la bonne réponse, et concevoir un routage hybride appareil / serveur.

> 🧭 **En clair** — L'IA embarquée, c'est faire tourner un petit modèle **directement dans votre téléphone, votre PC portable ou une caméra d'atelier**, sans passer par Internet. C'est comme avoir un **dictionnaire de poche** plutôt que d'appeler la bibliothèque : il en sait moins, mais il répond tout de suite, même au fond d'un parking souterrain, et rien de ce que vous lui confiez ne sort de votre poche. Les appareils récents ont une puce dédiée, le **NPU**, qui fait ces calculs en économisant la batterie. Mais attention aux chiffres de la publicité : ce qui limite la vitesse d'écriture d'un modèle, c'est surtout la vitesse de la mémoire, pas la puissance affichée en « TOPS ».

## 1. Pourquoi l'edge ?

Les trois leçons précédentes ont centralisé l'inférence dans un serveur. L'**edge** (en périphérie) fait l'inverse : le modèle tourne **sur l'appareil** de l'utilisateur ou de l'atelier. Quatre raisons, qui se mesurent :

| Raison | Exemple français | Gain |
|---|---|---|
| **Confidentialité** | dictée de comptes rendus dans un cabinet de kinésithérapie | aucune donnée de santé ne quitte la tablette |
| **Hors-ligne** | technicien d'ascenseurs en sous-sol, viticulteur dans ses parcelles | fonctionne sans réseau |
| **Latence** | correction orthographique en direct, contrôle qualité visuel sur une chaîne | pas d'aller-retour réseau |
| **Coût marginal nul** | 2 000 terminaux de caisse d'une enseigne de bricolage | pas de facture au token |

L'analogie la plus juste est celle de la **trousse de secours** face à l'hôpital : on ne fait pas de chirurgie avec, mais elle est là, tout de suite, sans rendez-vous, et elle règle 80 % des petits problèmes. Un modèle embarqué de 3B ne remplace pas Claude Opus 5.5 ; il résume, classe, extrait, reformule et transcrit très bien.

## 2. NPU, TOPS et la vraie limite

Un **NPU** (*neural processing unit*) est un accélérateur spécialisé dans les multiplications matricielles en faible précision (INT8, INT4, FP16), conçu pour un **rendement énergétique** maximal : à tâche égale, il consomme bien moins qu'un GPU, ce qui compte sur batterie. Les constructeurs l'annoncent en **TOPS** (*trillions of operations per second*, en INT8 le plus souvent).

| Plateforme | NPU | Ordre de grandeur annoncé | Pile logicielle principale |
|---|---|---|---|
| Apple (iPhone, iPad, Mac) | Neural Engine ; Neural Accelerators dans le GPU du M5 | 38 TOPS annoncés pour le Neural Engine du M4 | Core ML, MLX, Foundation Models |
| Qualcomm Snapdragon (X Elite pour PC, 8 Elite pour mobile) | Hexagon | 45 TOPS pour le X Elite | QNN / Qualcomm AI Engine, ONNX Runtime (QNN EP), LiteRT |
| Intel Core Ultra (Lunar Lake et suivants) | NPU Intel | 48 TOPS pour Lunar Lake | OpenVINO, ONNX Runtime (OpenVINO EP) |
| AMD Ryzen AI (300, Max+ « Strix Halo ») | XDNA 2 | 50 TOPS pour Ryzen AI 300 | Ryzen AI Software, ONNX Runtime (Vitis AI EP) |
| PC **Copilot+** (Microsoft) | exigence : NPU ≥ 40 TOPS | — | Windows ML, ONNX Runtime |

Les valeurs de TOPS sont celles annoncées par les constructeurs à la sortie des puces (2024-2025) ; les générations 2026 sont plus rapides : vérifiez la fiche du modèle exact avant tout engagement.

Voici le point d'ingénierie essentiel, que vous connaissez depuis L141 : **la génération d'un LLM est limitée par la bande passante mémoire, pas par les TOPS**. Un modèle de 3B en 4 bits pèse environ 1,8 Go. À chaque token, il faut relire ces 1,8 Go. Avec une mémoire LPDDR5X d'environ 60 à 120 Go/s (téléphones et portables haut de gamme, ordre de grandeur), le plafond théorique est donc de 33 à 66 tokens/s, et l'on obtient en pratique la moitié ou les deux tiers. Les TOPS servent surtout au **prefill** (lecture du prompt) et aux modèles de vision ou de parole, qui sont limités par le calcul. C'est exactement ce qu'Apple a montré avec le M5 : ses Neural Accelerators accélèrent fortement le TTFT (jusqu'à 4 fois par rapport au M4 selon Apple, nov. 2025) alors que la génération progresse comme la bande passante (+19 à +27 %).

> 💡 **À retenir** — Pour un LLM embarqué : **la RAM décide de ce qui tient, la bande passante décide de la vitesse d'écriture, les TOPS décident de la vitesse de lecture du prompt**. Un NPU de 50 TOPS n'accélère pas un decode limité par 70 Go/s de mémoire.

> 💡 **Autrement dit** — Les TOPS, c'est la vitesse de la main qui écrit ; la bande passante, c'est la vitesse à laquelle on tourne les pages du livre à recopier. Pour écrire une réponse, le modèle doit « tourner toutes les pages » à chaque mot : une main très rapide ne sert à rien si les pages tournent lentement.

```quiz
{
  "q": "Deux portables : A (NPU 50 TOPS, mémoire 70 Go/s) et B (NPU 40 TOPS, mémoire 120 Go/s). Lequel écrira la réponse d'un LLM de 3B en 4 bits le plus vite ?",
  "options": ["A, grâce à ses 50 TOPS", "Les deux à égalité", "B, grâce à sa bande passante", "Impossible à dire sans le prix"],
  "answer": 2,
  "explanation": "La génération relit tous les poids à chaque token : elle est limitée par la bande passante mémoire. B (120 Go/s) écrit plus vite ; A pourrait en revanche lire un long prompt plus vite (prefill, limité par le calcul)."
}
```

```mission
{
  "title": "Brancher le routeur hybride sur Ollama, sur le portable du technicien",
  "url": "https://docs.ollama.com",
  "steps": ["Ouvrez la documentation d'Ollama", "Cherchez la page de référence de l'API (API reference) ou la page sur la compatibilité OpenAI", "Notez l'adresse et le port par défaut du serveur local"],
  "question": "Sur quel port Ollama écoute-t-il par défaut, et quelle valeur de `LOCAL_URL` donner à `routeur_hybride.py` (section 6) pour l'utiliser via le client OpenAI ?",
  "hint": "Un port à cinq chiffres qui commence par 114 ; le chemin compatible OpenAI se termine comme celui de vLLM.",
  "answer": "Port 11434 ; `LOCAL_URL=http://localhost:11434/v1` (API compatible OpenAI d'Ollama, doc consultée nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

> 🎮 **Défi** — Un portable a 120 Go/s de bande passante. Combien de tokens/s au maximum pour Phi-4-mini (3,8B) en 4 bits (≈ 2,2 Go avec l'overhead) ? *Réponse : 120 ÷ 2,2 ≈ 55 tokens/s théoriques, environ 30 à 40 en pratique.*

## 3. Les modèles qui tiennent dans la poche (≤ 4B, nov. 2026)

| Modèle | Taille | Licence | Atouts pour l'edge |
|---|---|---|---|
| **Gemma 4 E2B / E4B** (Google, avril 2026) | 2,3B / 4,5B effectifs | Apache 2.0 | texte + image + audio, conçus pour l'embarqué avec LiteRT-LM |
| **Phi-4-mini-instruct** (Microsoft) | 3,8B | MIT | contexte 128K, tourne sur CPU |
| **Ministral 3 — 3B** (Mistral, déc. 2025) | 3B | Apache 2.0 | français natif |
| **SmolLM3-3B** (Hugging Face, juil. 2025) | 3B | Apache 2.0 | entièrement ouvert (données et recettes), français inclus |
| **Granite 4.2 3B** (IBM, août 2026) | ~3-4B | Apache 2.0 | orienté entreprise, raisonnement |

Sources : dossier de recherche (DataNorth, model cards Hugging Face, Serenities AI, KDnuggets, nov. 2026). Côté système, Apple intègre à ses OS un modèle d'environ 3B accessible aux développeurs via le framework *Foundation Models*, et Google embarque Gemini Nano sur Android : pratique, mais vous ne choisissez ni le modèle ni sa version.

## 4. Les piles logicielles

```
           ┌──────────── votre application ─────────────┐
           │                                            │
  Apple ── Core ML / MLX / Foundation Models    Android ── LiteRT(-LM) / ExecuTorch / llama.cpp
           │                                            │
  Windows ─ Windows ML ─ ONNX Runtime ─┬─ QNN EP      → NPU Qualcomm Hexagon
                                       ├─ OpenVINO EP → NPU / GPU Intel
                                       ├─ Vitis AI EP → NPU AMD XDNA
                                       ├─ DirectML / WebGPU → GPU
                                       └─ CPU (par défaut)
```

- **ONNX Runtime** (Microsoft, MIT) : moteur multiplateforme ; un même modèle ONNX s'exécute sur différents matériels via des *execution providers* (EP). Son extension **ONNX Runtime GenAI** ajoute la boucle de génération, le KV cache et l'échantillonnage pour les LLM.
- **ExecuTorch** (PyTorch, BSD) : solution PyTorch pour mobile et embarqué ; on exporte avec `torch.export`, puis on délègue des sous-graphes à des *backends* (XNNPACK pour CPU, Core ML, Qualcomm, Vulkan, MediaTek…). Le runtime est minuscule, adapté aux microcontrôleurs comme aux téléphones.
- **Core ML et MLX** (Apple) : Core ML pour intégrer un modèle dans une application iOS/macOS en tirant parti du Neural Engine ; MLX et `mlx-lm` pour la recherche et les LLM sur Mac (L042).
- **LiteRT** (ex-TensorFlow Lite, Google) et **LiteRT-LM** pour les LLM, dont Gemma 4 E2B/E4B.
- **llama.cpp** : compile aussi pour Android et iOS ; le choix le plus simple pour un prototype, mais il exploite surtout CPU et GPU, rarement le NPU.

> ⚠️ **Piège fréquent** — Croire qu'« ONNX » garantit l'usage du NPU. Si un opérateur n'est pas supporté par l'EP du NPU, ONNX Runtime le renvoie silencieusement sur le CPU, et les allers-retours peuvent rendre l'ensemble plus lent que le CPU seul. Activez les journaux de partitionnement et mesurez.

> 💡 **Autrement dit** — Un *execution provider*, c'est un **adaptateur de prise** : le même modèle ONNX se branche sur la puce Qualcomm, Intel, AMD ou sur le simple processeur, grâce à l'adaptateur correspondant. Si une partie du modèle ne rentre pas dans la prise du NPU, ONNX Runtime la fait tourner en douce sur le processeur classique : ça marche, mais parfois plus lentement.

```mission
{
  "title": "Quel execution provider pour quel NPU ?",
  "url": "https://onnxruntime.ai/docs/",
  "steps": ["Ouvrez la documentation d'ONNX Runtime", "Allez dans la rubrique Execution Providers", "Repérez les EP dédiés aux NPU Qualcomm et à Apple"],
  "question": "Comment s'appellent les execution providers qui ciblent le NPU Hexagon de Qualcomm et le matériel Apple (Neural Engine) ?",
  "hint": "L'un porte le sigle du SDK de Qualcomm, l'autre le nom du framework d'Apple.",
  "answer": "QNN Execution Provider (Qualcomm AI Engine Direct) et CoreML Execution Provider (doc consultée nov. 2026 ; la liste des EP s'allonge régulièrement).",
  "xp": 10
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : convertir un modèle au format ONNX suffit à garantir qu'il s'exécutera sur le NPU d'un PC Copilot+.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : il faut l'EP du NPU, et tout opérateur non supporté retombe silencieusement sur le CPU. Activez les journaux de partitionnement et mesurez le débit réel."
}
```

## 5. Pratique : un modèle de 3,8B en 4 bits, hors ligne

### 5.1 Avec ONNX Runtime GenAI (Windows, Linux, macOS)

```bash
python -m venv .venv && source .venv/bin/activate
pip install onnxruntime-genai transformers huggingface_hub
# Construire un modèle ONNX INT4 pour le CPU à partir des poids Hugging Face
# (-e cuda, -e dml ou -e webgpu selon votre matériel ; les variantes NPU passent par des
#  paquets spécifiques au constructeur : consultez la documentation ONNX Runtime GenAI)
python -m onnxruntime_genai.models.builder -m microsoft/Phi-4-mini-instruct \
  -o ./phi4-mini-int4-cpu -p int4 -e cpu
```

```python
# generer_onnx.py — génération en streaming et mesure du débit avec ONNX Runtime GenAI
import time
import onnxruntime_genai as og

modele = og.Model("./phi4-mini-int4-cpu")
tokenizer = og.Tokenizer(modele)
flux = tokenizer.create_stream()

messages = '[{"role": "user", "content": "Rédigez en 5 lignes un compte rendu d\'intervention : remplacement d\'un câble de traction, ascenseur B, essais conformes."}]'
prompt = tokenizer.apply_chat_template(messages=messages, add_generation_prompt=True)

params = og.GeneratorParams(modele)
params.set_search_options(max_length=1024)
generateur = og.Generator(modele, params)
generateur.append_tokens(tokenizer.encode(prompt))

t0, n, premier = time.perf_counter(), 0, None
while not generateur.is_done():
    generateur.generate_next_token()
    premier = premier or time.perf_counter()
    print(flux.decode(generateur.get_next_tokens()[0]), end="", flush=True)
    n += 1
fin = time.perf_counter()
print(f"\n\nTTFT ≈ {(premier - t0)*1000:.0f} ms · {n / (fin - premier):.1f} tokens/s")
```

L'API d'ONNX Runtime GenAI évolue rapidement (noms de méthodes, gestion des gabarits de chat) : si une méthode manque dans votre version, reportez-vous aux exemples officiels du projet.

### 5.2 Avec MLX sur Mac Apple Silicon

```bash
pip install mlx-lm
# Conversion et quantization 4 bits (exemple : SmolLM3-3B, licence Apache 2.0)
mlx_lm.convert --hf-path HuggingFaceTB/SmolLM3-3B -q --q-bits 4 --mlx-path ./smollm3-3b-4bit
mlx_lm.generate --model ./smollm3-3b-4bit --max-tokens 200 \
  --prompt "Classez ce courriel client en : réclamation, devis, rendez-vous, autre. Texte : « Bonjour, ma chaudière fuit encore depuis votre passage. »"
# mlx_lm.generate affiche les tokens/s de prompt et de génération ainsi que le pic mémoire
```

### 5.3 Avec ExecuTorch : le principe de l'export

Pour un LLM complet, ExecuTorch fournit des recettes dédiées (scripts d'export Llama, Qwen, Phi dans son dépôt). Le principe, lui, tient en quelques lignes, ici sur un petit classifieur de défauts pour une caméra d'atelier :

```python
# export_executorch.py — exporter un petit modèle PyTorch vers un fichier .pte délégué à XNNPACK
import torch
from executorch.exir import to_edge_transform_and_lower
from executorch.backends.xnnpack.partition.xnnpack_partitioner import XnnpackPartitioner

class DetecteurDefauts(torch.nn.Module):
    """CNN minuscule : 3 classes (conforme, rayure, bosse) sur images 96×96."""
    def __init__(self):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Conv2d(3, 16, 3, stride=2), torch.nn.ReLU(),
            torch.nn.Conv2d(16, 32, 3, stride=2), torch.nn.ReLU(),
            torch.nn.AdaptiveAvgPool2d(1), torch.nn.Flatten(), torch.nn.Linear(32, 3))
    def forward(self, x):
        return self.net(x)

modele = DetecteurDefauts().eval()
exemple = (torch.randn(1, 3, 96, 96),)
programme = torch.export.export(modele, exemple)
edge = to_edge_transform_and_lower(programme, partitioner=[XnnpackPartitioner()])
with open("detecteur_defauts.pte", "wb") as f:
    f.write(edge.to_executorch().buffer)
print("Exporté : detecteur_defauts.pte (à embarquer dans l'application Android/iOS)")
```

## 6. Routage hybride : le meilleur des deux mondes

Dans la plupart des projets réels, l'embarqué n'est pas seul : il traite ce qu'il sait traiter, et **escalade** le reste vers un serveur (le vôtre, L143) ou une API, en respectant une règle de confidentialité.

```python
# routeur_hybride.py — local d'abord, serveur si nécessaire, jamais de donnée sensible hors appareil
import os, re
from openai import OpenAI

local = OpenAI(base_url=os.environ.get("LOCAL_URL", "http://localhost:8080/v1"), api_key="local")
distant = OpenAI(base_url=os.environ.get("REMOTE_URL", "https://llm.mon-cabinet.fr/v1"),
                 api_key=os.environ["REMOTE_API_KEY"])
SENSIBLE = re.compile(r"\b(\d{13,15}|[12]\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3})\b")  # n° SS, IBAN…
TACHES_LOCALES = {"classer", "resumer", "extraire", "reformuler"}

def repondre(tache: str, texte: str) -> tuple[str, str]:
    if tache in TACHES_LOCALES or SENSIBLE.search(texte):
        cible, client = "local", local
    else:
        cible, client = "distant", distant
    r = client.chat.completions.create(
        model=client.models.list().data[0].id, max_tokens=400,
        messages=[{"role": "user", "content": f"Tâche : {tache}.\n{texte}"}])
    return cible, r.choices[0].message.content

if __name__ == "__main__":
    print(repondre("resumer", "Le client signale une fuite après intervention du 28 octobre…"))
```

Le motif de détection ci-dessus est volontairement simpliste : en production, utilisez un vrai détecteur de données personnelles et faites valider la règle de routage par votre DPO.

```
           requête
              │
   donnée sensible ? ── oui ──► modèle LOCAL (rien ne sort de l'appareil)
              │ non
   tâche bornée (classer, résumer…) ? ── oui ──► modèle LOCAL
              │ non
              ▼
   serveur maison (L143) ou API ──► réponse
```

```quiz
{
  "q": "Mise en situation : avec `routeur_hybride.py`, un technicien demande « rédiger » un rapport qui contient un numéro de sécurité sociale. Où part la requête ?",
  "options": ["Vers le serveur distant, car « rédiger » n'est pas une tâche locale", "Nulle part : la requête est rejetée", "Vers les deux, pour comparer", "Vers le modèle local, car le texte contient une donnée sensible"],
  "answer": 3,
  "explanation": "La condition est un « ou » : tâche locale OU donnée sensible détectée. Le numéro de sécurité sociale suffit à garder la requête sur l'appareil, quelle que soit la tâche."
}
```

## 7. Limites à annoncer honnêtement

- **Connaissances et raisonnement** : un modèle de 3B hallucine davantage et raisonne moins bien ; cantonnez-le aux tâches bornées, idéalement avec un format de sortie contraint.
- **Contexte** : même si la fiche annonce 128K, le KV cache (L142) dévore la RAM d'un téléphone ; visez quelques milliers de tokens.
- **Énergie et chaleur** : une génération soutenue vide la batterie et fait chuter la fréquence du processeur après quelques minutes (*throttling*) ; mesurez sur 10 minutes, pas sur 10 secondes.
- **Fragmentation** : chaque constructeur de NPU a son SDK, ses opérateurs supportés, ses formats ; prévoyez un repli CPU.
- **Mise à jour** : un modèle de 2 Go à redistribuer sur 2 000 appareils est un vrai sujet de MLOps (L144) : versionnez, déployez par vagues, gardez la version précédente.
- **Taille de l'application** : les magasins d'applications et les utilisateurs n'aiment pas les téléchargements de plusieurs Go ; téléchargez le modèle au premier lancement, en Wi-Fi.

> 🔗 **Documentation officielle** — [ONNX Runtime](https://onnxruntime.ai/docs/) 🇬🇧 · [ExecuTorch](https://github.com/pytorch/executorch) 🇬🇧 · [Core ML](https://developer.apple.com/documentation/coreml) 🇬🇧 · [LiteRT-LM et Gemma 4](https://ai.google.dev/edge/litert-lm/models/gemma-4) 🇬🇧

## 🧪 Exercice pratique

**Consigne.** Une entreprise de maintenance d'ascenseurs (300 techniciens, souvent sans réseau en gaine ou en sous-sol) veut que ses techniciens dictent puis obtiennent un compte rendu structuré (JSON : site, équipement, opération, pièces, conformité) sur leur PC portable durci.
1. Choisissez deux modèles de 4B ou moins et faites-les tourner en 4 bits (ONNX Runtime GenAI ou MLX ou llama.cpp).
2. Sur 20 comptes rendus dictés (vous pouvez les rédiger), mesurez : TTFT, tokens/s, pic mémoire, taux de JSON valide, exactitude des champs.
3. Faites un test d'endurance de 10 minutes et notez la baisse éventuelle de débit.
4. Proposez une architecture hybride : ce qui reste sur le portable, ce qui remonte au serveur une fois le réseau retrouvé, et comment les modèles sont mis à jour.

**Critères de réussite.** Mesures complètes pour les deux modèles ; taux de JSON valide supérieur à 95 % (contrainte de format ou validation + nouvelle tentative) ; endurance documentée ; l'architecture précise la règle de confidentialité, la synchronisation différée et la stratégie de mise à jour par vagues.

<details><summary>Pistes de corrigé</summary>

Sur un portable récent, un 3-4B en 4 bits produit typiquement quelques dizaines de tokens/s, ce qui suffit pour un compte rendu de 150 tokens en quelques secondes. Le JSON valide s'obtient par une sortie contrainte (grammaire GBNF dans llama.cpp, ou validation Pydantic + nouvelle tentative). Architecture : transcription et structuration sur l'appareil ; file d'attente locale chiffrée ; synchronisation vers le serveur central dès le retour du réseau, où un modèle plus gros peut relire et enrichir ; mise à jour des modèles par vagues de 10 %, avec la version précédente conservée pour le retour arrière.
</details>

## ✅ Auto-évaluation express
1. Pourquoi un NPU de 50 TOPS n'accélère-t-il pas beaucoup la génération d'un LLM ?
2. Quel est le rôle d'un *execution provider* dans ONNX Runtime ?
3. Citez deux limites concrètes d'un LLM de 3B embarqué.

*Réponses : 1. Parce que la génération est limitée par la lecture des poids en mémoire (bande passante), pas par le calcul ; les TOPS aident surtout le prefill et les modèles de vision. 2. Il exécute les sous-graphes du modèle sur un matériel donné (NPU Qualcomm, Intel, AMD, GPU, CPU), avec repli sur le CPU pour les opérateurs non supportés. 3. Par exemple : davantage d'hallucinations, contexte utile limité par la RAM, échauffement et baisse de débit, fragmentation des SDK.*

## 📚 Pour aller plus loin
- [ONNX Runtime — documentation](https://onnxruntime.ai/docs/) 🇬🇧 — execution providers, ONNX Runtime GenAI.
- [ExecuTorch — dépôt officiel](https://github.com/pytorch/executorch) 🇬🇧 — recettes d'export LLM et backends.
- [Apple — Core ML](https://developer.apple.com/documentation/coreml) 🇬🇧 et [MLX LM](https://github.com/ml-explore/mlx-lm) 🇬🇧 — intégration Apple et LLM sur Mac.
- [Apple ML Research — LLM et MLX sur M5](https://machinelearning.apple.com/research/exploring-llms-mlx-m5) 🇬🇧 — TTFT et débit mesurés.
- [Google AI Edge — LiteRT-LM et Gemma 4](https://ai.google.dev/edge/litert-lm/models/gemma-4) 🇬🇧 — déployer Gemma 4 E2B/E4B sur mobile.
- [OpenVINO — documentation](https://docs.openvino.ai/) 🇬🇧 — NPU et GPU Intel.

> 🗺️ **Et maintenant ?** — Vous savez déployer un modèle partout, du datacenter à la poche ; le module M30 s'ouvre avec L146 sur la question suivante : comment s'assurer que ce modèle fait bien ce que l'on veut, grâce à l'alignement et à l'interprétabilité.
