---
id: L141
module: M29
level: N4
title: "Quantization, GGUF et serveurs d'inférence : vLLM, llama.cpp, TGI"
minutes: 65
objectives:
  - "Expliquer la quantization affine (échelle, point zéro, granularité par canal et par groupe) et calculer l'erreur introduite en INT8 et INT4"
  - "Comparer GPTQ, AWQ, les k-quants GGUF, FP8 et FP4 (MXFP4, NVFP4) et choisir un format selon le matériel cible"
  - "Mesurer l'impact qualité d'une quantization (perplexité, divergence KL, évaluation de tâche) au lieu de le supposer"
  - "Lancer un modèle avec vLLM, llama-server et TGI, puis mesurer son débit avec llama-bench et vllm bench"
skills: ["C4.5"]
sources:
  - { title: "vLLM — Quickstart", url: "https://docs.vllm.ai/en/latest/getting_started/quickstart/", lang: "en" }
  - { title: "llama.cpp — dépôt officiel (ggml-org)", url: "https://github.com/ggml-org/llama.cpp", lang: "en" }
  - { title: "Hugging Face — Text Generation Inference (documentation)", url: "https://huggingface.co/docs/text-generation-inference/index", lang: "en" }
  - { title: "Frantar et al. (2022) — GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers", url: "https://arxiv.org/abs/2210.17323", lang: "en" }
  - { title: "Lin et al. (2023) — AWQ: Activation-aware Weight Quantization", url: "https://arxiv.org/abs/2306.00978", lang: "en" }
  - { title: "Dettmers et al. (2022) — LLM.int8(): 8-bit Matrix Multiplication for Transformers at Scale", url: "https://arxiv.org/abs/2208.07339", lang: "en" }
  - { title: "Morph — gpt-oss (MXFP4, tailles mémoire)", url: "https://www.morphllm.com/gpt-oss", lang: "en" }
  - { title: "Stanford CS336 — Language Modeling from Scratch (séance Inférence)", url: "https://cs336.stanford.edu/", lang: "en" }
---

# Quantization, GGUF et serveurs d'inférence : vLLM, llama.cpp, TGI

> ⏱ 65 min · 🎯 Niveau 4 · 📚 Module 29

## 🎯 Ce que vous saurez faire
- Écrire la formule de la quantization affine, choisir une granularité (par tenseur, par canal, par groupe de 128) et prédire l'erreur qui en résulte.
- Expliquer en deux phrases ce que font GPTQ, AWQ, les k-quants GGUF, FP8 et FP4, et sur quel matériel chacun est rentable.
- Produire vous-même un GGUF `Q4_K_M` à partir d'un modèle Hugging Face et **mesurer** sa perte de qualité (perplexité, KL).
- Servir le même modèle avec vLLM, `llama-server` et TGI, et comparer leurs débits avec un protocole reproductible.

> 🧭 **En clair** — Quantifier un modèle, c'est comme **compresser une photo en JPEG** : on garde l'image, mais on enregistre chaque pixel avec moins de précision, et le fichier devient trois ou quatre fois plus léger. Pour un modèle d'IA, les « pixels » sont ses milliards de réglages internes (les poids) : on les range sur 4 ou 8 bits au lieu de 16. Le modèle tient alors sur une carte graphique plus modeste et répond plus vite, parce qu'il a moins de données à lire à chaque mot. Comme pour un JPEG trop compressé, il existe un seuil où l'image « bave » : tout l'art consiste à **mesurer** la perte au lieu de la deviner. Enfin, un **serveur d'inférence** (vLLM, llama.cpp, TGI), c'est le « projecteur » qui affiche cette photo à beaucoup de spectateurs en même temps.

En L042 (niveau 2), vous avez appris la règle de dimensionnement `Go ≈ B × bits ÷ 8 × 1,1` et la consigne « téléchargez en 4 bits par défaut ». Ici, on ouvre le capot : **pourquoi** le 4 bits marche, **quand** il casse, et **comment** le prouver par la mesure. C'est la différence entre un utilisateur averti et un ingénieur qui signe un engagement de qualité de service.

## 1. Ce que l'on quantifie vraiment

Un modèle de langage en production manipule trois familles de nombres, qui peuvent être quantifiées indépendamment :

| Objet | Taille typique | Quantifier sert à… | Notation courante |
|---|---|---|---|
| **Poids** (W) | 2 octets × paramètres en BF16 | réduire la mémoire et le volume lu à chaque token | W4, W8 |
| **Activations** (A) | dépend du lot et de la séquence | accélérer le calcul matriciel (unités INT8/FP8) | A8, A16 |
| **KV cache** | grandit avec le contexte (L142) | servir plus d'utilisateurs ou de longs contextes | KV8, `fp8` |

D'où les étiquettes que vous croiserez dans les docs de vLLM ou TensorRT-LLM : **W4A16** (poids 4 bits déquantifiés à la volée, calcul en 16 bits : le cas de GPTQ, AWQ et GGUF), **W8A8** (poids et activations en 8 bits : SmoothQuant, FP8), **W4A4** (FP4 natif sur Blackwell).

Pourquoi le W4A16 accélère-t-il alors que le calcul reste en 16 bits ? Parce qu'en génération (*decode*), un token ne fait qu'une multiplication matrice-vecteur par couche : le GPU passe son temps à **lire** les poids, pas à calculer. Lire 4 fois moins d'octets, c'est jusqu'à 4 fois plus de tokens par seconde. En revanche, au *prefill* (lecture du prompt, calcul massif), le W4A16 n'aide presque pas, voire ralentit à cause de la déquantification : c'est le W8A8 ou le FP8 qui y gagne. Retenez ce couple **decode ↔ bande passante, prefill ↔ calcul**, il guide toute la leçon suivante.

> 💡 **Autrement dit** — Le *decode* (écrire la réponse mot après mot), c'est un cuisinier qui doit relire **tout** son livre de recettes avant chaque coup de cuillère : ce qui le ralentit, c'est la lecture, pas le geste. Un livre quatre fois plus mince (poids en 4 bits) se relit quatre fois plus vite. Le *prefill* (lire votre question en entier), c'est au contraire une grosse séance d'épluchage où l'on travaille à pleine vitesse : là, c'est le nombre de mains (la puissance de calcul) qui compte.

```quiz
{
  "q": "Votre modèle en W4A16 génère ses réponses nettement plus vite qu'en BF16, mais le temps avant le premier token (lecture d'un long prompt) n'a presque pas bougé. Pourquoi ?",
  "options": ["Le prefill dépend du calcul, resté en 16 bits", "Le W4A16 ne quantifie que le KV cache", "Le prefill est désactivé en 4 bits", "Le decode lit davantage de poids en 4 bits"],
  "answer": 0,
  "explanation": "En W4A16, seuls les poids sont stockés en 4 bits : on lit moins d'octets, ce qui accélère le decode (limité par la bande passante). Le prefill est limité par le calcul matriciel, toujours fait en 16 bits : il n'en profite presque pas."
}
```

## 2. Les mathématiques : échelle, point zéro, granularité

La quantization affine associe à chaque réel $x$ un entier $q$ sur $b$ bits :

$$q = \mathrm{clip}\!\left(\mathrm{round}\!\left(\frac{x}{s}\right) + z,\ q_{min},\ q_{max}\right), \qquad \hat{x} = s\,(q - z)$$

- $s$ (*scale*) : pas de la grille ; en symétrique, $s = \max|x| / (2^{b-1}-1)$.
- $z$ (*zero-point*) : décalage, nul en symétrique.
- L'erreur d'arrondi est bornée par $s/2$ : **plus la plage est large, plus la grille est grossière**.

Le problème des LLM, mis en évidence par Dettmers et al. avec LLM.int8() en 2022, ce sont les **valeurs aberrantes** (*outliers*) : quelques dimensions d'activation prennent des valeurs 20 à 100 fois plus grandes que les autres à partir d'environ 6,7 milliards de paramètres. Une seule valeur extrême étire $s$ et écrase la précision de tout le reste. La parade est la **granularité** : au lieu d'une échelle par tenseur, on en calcule une par ligne (par canal), ou par **groupe** de 32, 64 ou 128 poids consécutifs. Chaque groupe paie quelques bits de métadonnées (une échelle en FP16 pour 128 poids ajoute 0,125 bit par poids), mais isole les outliers.

> 💡 **Autrement dit** — Imaginez une règle graduée de 0 à 100 cm avec seulement 16 traits (4 bits) : chaque trait vaut environ 6 cm, et toute mesure est arrondie au trait le plus proche. Si une seule valeur géante oblige à prolonger la règle jusqu'à 10 mètres, chaque trait vaut alors 60 cm et toutes les petites valeurs tombent sur « zéro ». La **granularité par groupe**, c'est donner à chaque petit paquet de 128 poids **sa propre règle**, ajustée à sa taille : la valeur géante n'abîme plus que son paquet.

```
Une échelle pour tout le tenseur        Une échelle par groupe de 128
|0         outlier ▲           |         |g1 ----|g2 ----|g3 ▲ --|g4 ----|
 grille très grossière                    grille fine ; seul g3 est « étiré »
```

Vérifiez-le vous-même : ce script mesure l'erreur relative de quatre stratégies sur une matrice de 4 096 × 4 096 contenant quelques outliers.

```python
# quantif_demo.py — erreur de quantization selon la granularité (Python 3.12, numpy)
import numpy as np

rng = np.random.default_rng(42)
W = rng.normal(0.0, 0.02, size=(4096, 4096)).astype(np.float32)
# On injecte 64 valeurs aberrantes, comme dans un vrai LLM
idx = rng.integers(0, 4096, size=(64, 2))
W[idx[:, 0], idx[:, 1]] = rng.choice([-0.6, 0.6], size=64)

def quant_sym(x: np.ndarray, bits: int, axis=None) -> np.ndarray:
    """Quantization symétrique puis déquantification (round-to-nearest)."""
    qmax = 2 ** (bits - 1) - 1
    scale = np.abs(x).max(axis=axis, keepdims=True) / qmax
    scale = np.where(scale == 0, 1e-12, scale)
    q = np.clip(np.round(x / scale), -qmax - 1, qmax)
    return q * scale

def quant_group(x: np.ndarray, bits: int, g: int = 128) -> np.ndarray:
    """Une échelle par groupe de g poids consécutifs sur chaque ligne."""
    xs = x.reshape(x.shape[0], -1, g)
    return quant_sym(xs, bits, axis=-1).reshape(x.shape)

def rel_err(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b) / np.linalg.norm(a))

for bits in (8, 4):
    print(f"--- INT{bits} ---")
    print(f"par tenseur      : {rel_err(W, quant_sym(W, bits)):.4f}")
    print(f"par ligne        : {rel_err(W, quant_sym(W, bits, axis=1)):.4f}")
    print(f"par groupe de 128: {rel_err(W, quant_group(W, bits, 128)):.4f}")
    print(f"par groupe de 32 : {rel_err(W, quant_group(W, bits, 32)):.4f}")
```

Vous constaterez qu'en INT8 toutes les stratégies restent acceptables, alors qu'en INT4 l'échelle par tenseur est catastrophique (la quasi-totalité des poids tombe sur zéro) et que le groupe de 128 divise l'erreur par un facteur important. C'est exactement pourquoi **tous** les formats 4 bits sérieux sont « par groupe ».

> 💡 **À retenir** — En 4 bits, la question n'est pas « combien de bits ? » mais « combien de bits **effectifs**, métadonnées comprises, et à quelle granularité ? ». Un « 4 bits » par groupe de 32 coûte en réalité environ 4,5 bits par poids.

> 🎮 **Défi** — Une échelle FP16 par groupe de 64 poids et un point zéro sur 4 bits : combien de bits par poids au total pour un format « 4 bits » ? *Réponse : 4 + 16/64 + 4/64 = 4,31 bits.*

## 3. Les grandes familles de méthodes

### 3.1 RTN : l'arrondi naïf
*Round-to-nearest* : on applique la formule ci-dessus, point. Rapide, sans données, très correct en 8 bits, médiocre en 4 bits sur les petits modèles. C'est la base de comparaison de tous les articles.

### 3.2 GPTQ (Frantar et al., 2022)
GPTQ quantifie les poids **colonne par colonne** et, après chaque colonne, **corrige les colonnes restantes** pour compenser l'erreur commise, en s'appuyant sur une approximation de second ordre (la hessienne $H = 2XX^\top$ calculée sur les activations $X$ d'un petit jeu de calibration, souvent 128 séquences). Résultat annoncé par les auteurs : des modèles jusqu'à 175 milliards de paramètres compressés en 3-4 bits avec une perte de perplexité faible, en quelques heures sur un seul GPU. Point de vigilance : la qualité dépend du **jeu de calibration** ; calibrer sur de l'anglais un modèle destiné à des courriers juridiques français est une erreur classique.

### 3.3 AWQ (Lin et al., 2023)
AWQ part d'une observation simple : environ **1 % des poids** sont « saillants », ceux qui multiplient les canaux d'activation de grande amplitude. Plutôt que de les garder en 16 bits (format mixte peu pratique), AWQ **multiplie ces canaux par un facteur d'échelle** avant quantization et divise l'activation d'autant : mathématiquement équivalent, mais l'erreur relative sur les poids importants diminue. Pas de rétropropagation, calibration légère, excellente généralisation, et des noyaux GPU très rapides : AWQ est devenu le choix par défaut du W4A16 sur vLLM. De nombreux éditeurs publient directement des variantes `-AWQ` de leurs modèles sur Hugging Face.

### 3.4 GGUF et les k-quants (llama.cpp)
GGUF est le **format de fichier** de llama.cpp (successeur de GGML, 2023) : un seul fichier contenant poids, tokenizer, gabarit de chat et métadonnées. Les **k-quants** organisent les poids en **super-blocs de 256** subdivisés en sous-blocs, avec des échelles elles-mêmes quantifiées. Le suffixe décrit le mélange :

| Suffixe | Bits effectifs (ordre de grandeur) | Lecture |
|---|---|---|
| `Q8_0` | ~8,5 | quasi indiscernable de BF16 |
| `Q6_K` | ~6,6 | excellent, plus gros |
| `Q5_K_M` | ~5,7 | très bon compromis |
| **`Q4_K_M`** | ~4,8 | le défaut du marché |
| `Q3_K_M`, `IQ3_XXS` | ~3,1-3,9 | pour faire tenir un modèle trop grand |
| `IQ2_XXS` | ~2,1 | expérimental |

Le `_M` (*medium*) signifie que certains tenseurs sensibles (par exemple une partie des projections `attn_v` et `ffn_down`) sont gardés en précision supérieure. Les formats `IQ` (*i-quants*) utilisent des grilles non uniformes et une **matrice d'importance** (*imatrix*) calculée sur un texte de calibration : c'est l'équivalent GGUF de l'idée d'AWQ.

### 3.5 FP8 et FP4 : la quantization « matérielle »
Plutôt que des entiers, on utilise des **flottants courts** que les Tensor Cores calculent nativement :
- **FP8** : formats E4M3 (4 bits d'exposant, 3 de mantisse, pour poids et activations) et E5M2 (plus de plage, pour les gradients). Supporté nativement depuis les architectures Ada (L40S, RTX 4090) et Hopper (H100). Le W8A8 FP8 accélère **aussi le prefill** et la perte est généralement minime : c'est le format de production le plus sûr sur H100.
- **FP4** : **MXFP4** (standard OCP *Microscaling* : blocs de 32 valeurs E2M1 partageant une échelle puissance de deux) et **NVFP4** (NVIDIA : blocs de 16 valeurs avec une échelle FP8, plus fine). Accélérés nativement par Blackwell (B200, RTX 5090, DGX Spark). OpenAI distribue gpt-oss **directement en MXFP4** : gpt-oss-120b tient ainsi dans environ 66 Go et gpt-oss-20b dans environ 12 Go (Morph, nov. 2026).

### 3.6 Le tableau de décision

| Matériel cible | Format recommandé | Pourquoi |
|---|---|---|
| Mac Apple Silicon | MLX 4 bits ou GGUF Q4_K_M | Metal, mémoire unifiée |
| PC / serveur CPU, GPU grand public, Vulkan, ROCm | GGUF (llama.cpp, Ollama) | portabilité maximale |
| GPU NVIDIA Ampere (A100, RTX 3090) | AWQ ou GPTQ (W4A16) | pas de FP8 natif |
| Ada / Hopper (L40S, H100) | **FP8** (W8A8), AWQ si la mémoire manque | FP8 natif, prefill accéléré |
| Blackwell (B200, RTX 5090, DGX Spark) | NVFP4 / MXFP4, FP8 | FP4 natif |

> ⚠️ **Piège fréquent** — Comparer « Q4 » et « 4 bits AWQ » comme s'il s'agissait de la même chose. Les bits effectifs, la calibration et les tenseurs protégés diffèrent. Seule une mesure sur **votre** tâche tranche.

```quiz
{
  "q": "Mise en situation : un client loue un serveur H100 et veut un service multi-utilisateurs où les longs prompts de RAG (lecture de documents) doivent aussi être rapides. Quel format proposez-vous en premier ?",
  "options": ["GGUF Q3_K_M sous llama.cpp", "AWQ 4 bits (W4A16)", "FP8 (W8A8)", "MXFP4 natif"],
  "answer": 2,
  "explanation": "Sur Hopper, le FP8 est calculé nativement : il accélère aussi le prefill (lecture des longs prompts) avec une perte généralement minime. L'AWQ n'accélère que le decode ; le FP4 natif demande un GPU Blackwell ; le Q3 sacrifie trop de qualité."
}
```

## 4. Mesurer l'impact qualité (au lieu de le supposer)

Trois instruments, du plus rapide au plus fiable :

1. **Perplexité** sur un texte de référence (WikiText, ou mieux : un échantillon de *vos* documents). Simple, mais une perplexité qui bouge de 1 % peut masquer une dégradation forte sur une tâche précise (calcul, code, langues peu représentées).
2. **Divergence KL** entre les distributions de tokens du modèle quantifié et du modèle de référence, token par token. Plus sensible que la perplexité ; llama.cpp la calcule directement.
3. **Évaluation de tâche** : votre jeu d'évaluation maison (M28, L138) ou `lm-evaluation-harness` d'EleutherAI. C'est le seul juge qui compte pour un client.

Voici la chaîne complète avec llama.cpp, du modèle Hugging Face au rapport de qualité :

```
Hugging Face ──► convert_hf_to_gguf ──► GGUF BF16 (référence)
                                            │
             calibration_fr.txt ──► llama-imatrix ──► imatrix.dat
                                            │
                                     llama-quantize ──► Q8_0 · Q4_K_M · Q3_K_M
                                            │
             eval_fr.txt ──► llama-perplexity (perplexité + KL vs BF16) ──► rapport
```

```bash
#!/usr/bin/env bash
# quantif_pipeline.sh — conversion, quantization et mesure (llama.cpp compilé dans ./llama.cpp)
set -euo pipefail
MODEL=Qwen/Qwen3-8B
OUT=./gguf && mkdir -p "$OUT"

# 1. Télécharger le modèle et le convertir en GGUF BF16 (référence)
huggingface-cli download "$MODEL" --local-dir ./hf-model
python llama.cpp/convert_hf_to_gguf.py ./hf-model --outtype bf16 --outfile "$OUT/qwen3-8b-bf16.gguf"

# 2. Matrice d'importance sur un texte de calibration EN FRANÇAIS (vos documents)
./llama.cpp/build/bin/llama-imatrix -m "$OUT/qwen3-8b-bf16.gguf" -f calibration_fr.txt -o "$OUT/imatrix.dat" -ngl 99

# 3. Quantifier en trois niveaux
for Q in Q8_0 Q4_K_M Q3_K_M; do
  ./llama.cpp/build/bin/llama-quantize --imatrix "$OUT/imatrix.dat" \
    "$OUT/qwen3-8b-bf16.gguf" "$OUT/qwen3-8b-$Q.gguf" "$Q"
done

# 4. Logits de référence (BF16), puis perplexité + KL de chaque variante
./llama.cpp/build/bin/llama-perplexity -m "$OUT/qwen3-8b-bf16.gguf" -f eval_fr.txt \
  --kl-divergence-base "$OUT/base.kld" -ngl 99
for Q in Q8_0 Q4_K_M Q3_K_M; do
  echo "=== $Q ==="
  ./llama.cpp/build/bin/llama-perplexity -m "$OUT/qwen3-8b-$Q.gguf" \
    --kl-divergence-base "$OUT/base.kld" --kl-divergence -ngl 99 | tail -n 20
done
```

Les ordres de grandeur couramment observés sur des modèles de 7-8B sont : `Q8_0` pratiquement sans perte, `Q4_K_M` une hausse de perplexité de l'ordre de quelques pour cent, `Q3_K_M` une dégradation nette, et une sensibilité **plus forte pour les petits modèles** que pour les gros (un 70B en Q4 souffre moins qu'un 3B en Q4). Ce sont des tendances, pas des garanties : notez vos propres chiffres dans l'exercice.

> 🔗 **Documentation officielle** — [llama.cpp — dépôt et outils `llama-quantize`, `llama-perplexity`, `llama-bench`](https://github.com/ggml-org/llama.cpp) 🇬🇧

## 5. Trois serveurs, trois philosophies

| | **vLLM** | **llama.cpp `llama-server`** | **TGI** (Hugging Face) |
|---|---|---|---|
| Cible | GPU de datacenter, multi-utilisateurs | partout : CPU, Mac, GPU, edge | GPU, écosystème Hugging Face |
| Formats | BF16, FP8, AWQ, GPTQ, NVFP4/MXFP4, GGUF (expérimental) | GGUF uniquement | BF16, AWQ, GPTQ, FP8, bitsandbytes… |
| Points forts | PagedAttention, batching continu, prefix caching, parallélisme tensoriel | binaire unique, `-np` slots parallèles, faible empreinte | conteneur clé en main, intégration Hub et Inference Endpoints |
| API | OpenAI (`/v1`), port 8000 | OpenAI (`/v1`), port 8080 | OpenAI (`/v1/chat/completions`) + API native |
| Licence | Apache 2.0 | MIT | Apache 2.0 |

TGI est en **mode maintenance** (annonce officielle sur la doc TGI, qui recommande vLLM, SGLang, llama.cpp ou MLX pour les nouveaux déploiements) : vérifiez l'état du projet sur sa page officielle avant de l'adopter. Il reste très présent dans les déploiements existants, d'où son étude ici.

> 💡 **Autrement dit** — « Mode maintenance » veut dire que le logiciel n'est pas abandonné du jour au lendemain, mais qu'il ne reçoit plus de nouvelles fonctions : on le répare, on ne l'agrandit plus. Pour un nouveau projet, partez sur un serveur activement développé ; pour un TGI déjà en place, planifiez une migration sans panique.

```mission
{
  "title": "Par quoi remplacer TGI ?",
  "url": "https://huggingface.co/docs/text-generation-inference/index",
  "steps": ["Ouvrez la page d'accueil de la documentation Text Generation Inference", "Repérez l'encadré d'avertissement en haut de la page", "Notez les moteurs d'inférence recommandés à la place"],
  "question": "Dans quel état la documentation officielle déclare-t-elle TGI, et quels moteurs recommande-t-elle ?",
  "hint": "L'encadré cite quatre projets, dont deux étudiés dans cette leçon.",
  "answer": "TGI est « now in maintenance mode » ; la doc recommande vLLM, SGLang, llama.cpp et MLX (relevé du 5 nov. 2026, aucune date d'annonce affichée) — vérifiez, la page peut évoluer (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**vLLM** (installation selon le quickstart officiel, Python 3.11 à 3.14) :

```bash
uv venv --python 3.12 && source .venv/bin/activate
uv pip install vllm --torch-backend=auto
# Modèle AWQ 4 bits, contexte limité à 32K, 90 % de la VRAM pour poids + KV cache
vllm serve Qwen/Qwen3-8B-AWQ \
  --max-model-len 32768 \
  --gpu-memory-utilization 0.90 \
  --enable-prefix-caching \
  --port 8000
# Sur H100 / L40S, variante FP8 calculée à la volée :
# vllm serve Qwen/Qwen3-8B --quantization fp8 --max-model-len 32768
```

```mission
{
  "title": "Les prérequis de vLLM dans le quickstart officiel",
  "url": "https://docs.vllm.ai/en/latest/getting_started/quickstart/",
  "steps": ["Ouvrez le Quickstart de vLLM", "Lisez la section Prerequisites ou Installation", "Puis la section sur le serveur compatible OpenAI (OpenAI-Compatible Server)"],
  "question": "Quelles versions de Python le quickstart accepte-t-il, et sur quel port `vllm serve` écoute-t-il par défaut ?",
  "hint": "Le port est le même que celui utilisé par `client_commun.py` ci-dessous.",
  "answer": "Python 3.11 à 3.14 selon le quickstart consulté pour cette leçon (nov. 2026) et port 8000 par défaut (http://localhost:8000/v1) — la plage de versions Python évolue à chaque version de vLLM : vérifiez (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**llama-server** :

```bash
# -ngl 99 : toutes les couches sur le GPU ; -c : contexte TOTAL partagé entre les slots
# -np 4 : 4 requêtes en parallèle (donc 8192 tokens par slot) ; -fa on : flash attention
./llama.cpp/build/bin/llama-server -m ./gguf/qwen3-8b-Q4_K_M.gguf \
  -ngl 99 -c 32768 -np 4 -fa on --host 0.0.0.0 --port 8080
```

**TGI** (conteneur officiel ; épinglez une version précise en production plutôt que `latest`) :

```bash
docker run --gpus all --shm-size 1g -p 8080:80 \
  -v "$PWD/tgi-data:/data" \
  -e HF_TOKEN="$HF_TOKEN" \
  ghcr.io/huggingface/text-generation-inference:latest \
  --model-id Qwen/Qwen3-8B-AWQ --quantize awq --max-total-tokens 32768
```

Les trois parlent le dialecte OpenAI : un même client Python les interroge en changeant seulement `base_url`.

```python
# client_commun.py — un seul client pour vLLM, llama-server et TGI
import os
from openai import OpenAI

BASE_URL = os.environ.get("LLM_BASE_URL", "http://localhost:8000/v1")
client = OpenAI(base_url=BASE_URL, api_key=os.environ.get("LLM_API_KEY", "local"))

modele = client.models.list().data[0].id  # le serveur annonce le modèle chargé
reponse = client.chat.completions.create(
    model=modele,
    messages=[{"role": "user", "content": "Résumez en trois points la règle de la TVA sur marge."}],
    max_tokens=300,
)
print(modele, "→", reponse.choices[0].message.content)
print("tokens :", reponse.usage)
```

## 6. Mesurer le débit : protocole reproductible

Deux régimes à ne jamais confondre :
- **Mono-utilisateur** (latence) : combien de tokens/s voit **une** personne ? Outil : `llama-bench`.
- **Multi-utilisateurs** (débit agrégé) : combien de tokens/s le serveur produit-il **au total** sous charge ? Outil : `vllm bench serve` (fonctionne contre tout serveur compatible OpenAI).

```bash
# Mono-utilisateur : prefill de 512 tokens (pp512) et génération de 128 tokens (tg128), 5 répétitions
./llama.cpp/build/bin/llama-bench -m ./gguf/qwen3-8b-Q4_K_M.gguf,./gguf/qwen3-8b-Q8_0.gguf \
  -p 512 -n 128 -ngl 99 -r 5 -o md

# Multi-utilisateurs : 200 requêtes aléatoires (1 024 tokens en entrée, 256 en sortie),
# concurrence plafonnée à 32, contre le serveur vLLM lancé plus haut
vllm bench serve --backend openai-chat --base-url http://localhost:8000 \
  --endpoint /v1/chat/completions --model Qwen/Qwen3-8B-AWQ \
  --dataset-name random --random-input-len 1024 --random-output-len 256 \
  --num-prompts 200 --max-concurrency 32
```

`vllm bench serve` affiche le débit de sortie (*output token throughput*), le TTFT et le temps par token de sortie en moyenne, médiane et p99 : vous les décortiquerez en L142. Règles d'hygiène : préchauffez le serveur (une première série jetée), fixez les longueurs d'entrée et de sortie, notez la version du serveur, du pilote et du modèle (révision Hugging Face), et répétez trois fois.

Ordre de grandeur pour situer vos mesures : sur DGX Spark, vLLM atteint 289 à 313 tokens/s agrégés avec 8 requêtes simultanées, là où Ollama n'apporte aucun gain en concurrence (Spheron, oct. 2026, relevé dans notre dossier de recherche). C'est la démonstration la plus parlante de l'intérêt d'un vrai serveur de production.

> ⚠️ **Piège fréquent** — Annoncer à un client « 145 tokens/s » mesurés en mono-utilisateur sur une RTX 5090, puis découvrir en production que 20 collaborateurs simultanés voient chacun 15 tokens/s avec llama-server et `-np 1`. Mesurez toujours le régime que vous vendez.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un `llama-bench` à 145 tokens/s suffit pour promettre ce débit à chacun des 20 collaborateurs d'un cabinet.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : `llama-bench` mesure le régime mono-utilisateur. Sous charge, le débit se partage ; seul un test multi-utilisateurs (`vllm bench serve`) à la concurrence réelle dit ce que chacun verra."
}
```

## 🧪 Exercice pratique

**Consigne.** Un cabinet d'expertise comptable lyonnais veut un assistant interne sur une RTX 4090 (24 Go). À partir de Qwen3-8B :
1. Produisez trois GGUF (`Q8_0`, `Q4_K_M`, `Q3_K_M`) avec une imatrix calculée sur 50 pages de documentation fiscale française publique.
2. Mesurez pour chacun : taille du fichier, perplexité et KL moyenne sur un autre extrait de 20 pages, `tg128` et `pp512` avec `llama-bench`.
3. Lancez la variante retenue dans `llama-server -np 4` puis le même modèle en AWQ dans vLLM, et mesurez le débit agrégé à concurrence 4 et 16 avec `vllm bench serve`.
4. Rédigez une recommandation de 10 lignes.

**Critères de réussite.** Tableau complet (3 formats × 5 mesures) ; versions et révisions notées ; la recommandation distingue qualité, vitesse mono-utilisateur et débit agrégé ; elle justifie le format retenu par un chiffre mesuré, pas par une règle générale.

<details><summary>Pistes de corrigé</summary>

Attendus typiques : `Q8_0` ≈ 8,7 Go, `Q4_K_M` ≈ 5 Go, `Q3_K_M` ≈ 4 Go ; la KL de `Q8_0` est très faible, celle de `Q4_K_M` reste modérée, celle de `Q3_K_M` augmente nettement. `tg128` progresse quand la taille diminue (moins d'octets lus). À concurrence 16, vLLM creuse l'écart grâce au batching continu, alors que llama-server sature ses 4 slots. Recommandation probable : `Q4_K_M` (ou AWQ sous vLLM si plus de 5 utilisateurs simultanés), `Q8_0` si la qualité sur les calculs de TVA se dégrade dans l'évaluation de tâche.
</details>

## ✅ Auto-évaluation express
1. Pourquoi le W4A16 accélère-t-il la génération mais pas le prefill ?
2. Quelle différence de principe entre GPTQ et AWQ ?
3. Pourquoi la divergence KL est-elle un meilleur détecteur de dégradation que la perplexité ?

*Réponses : 1. Le decode est limité par la lecture des poids (bande passante) : 4 fois moins d'octets, c'est plus de tokens/s ; le prefill est limité par le calcul, toujours fait en 16 bits. 2. GPTQ compense l'erreur de chaque colonne sur les suivantes grâce à une approximation de second ordre ; AWQ protège les poids saillants par une mise à l'échelle des canaux guidée par les activations. 3. Elle compare la distribution complète token par token avec la référence, alors qu'une perplexité moyenne peut rester stable tout en masquant des erreurs ciblées.*

## 📚 Pour aller plus loin
- [vLLM — Quickstart](https://docs.vllm.ai/en/latest/getting_started/quickstart/) 🇬🇧 — installation, `vllm serve`, API OpenAI.
- [llama.cpp — dépôt officiel](https://github.com/ggml-org/llama.cpp) 🇬🇧 — README des outils `quantize`, `imatrix`, `perplexity`, `server`, `bench`.
- [Text Generation Inference — documentation](https://huggingface.co/docs/text-generation-inference/index) 🇬🇧 — options de lancement et quantization.
- [Frantar et al. — GPTQ](https://arxiv.org/abs/2210.17323) 🇬🇧 et [Lin et al. — AWQ](https://arxiv.org/abs/2306.00978) 🇬🇧 — les deux articles de référence du W4A16.
- [Dettmers et al. — LLM.int8()](https://arxiv.org/abs/2208.07339) 🇬🇧 — l'origine du problème des outliers.
- [Stanford CS336](https://cs336.stanford.edu/) 🇬🇧 — séance « Inférence », source d'inspiration de cette leçon (supports à consulter, non reproduits).

> 🗺️ **Et maintenant ?** — Votre modèle est compressé et servi ; la leçon L142 ouvre le capot du serveur pour comprendre ce qui limite vraiment le nombre d'utilisateurs simultanés : le KV cache, le batching et le speculative decoding.
