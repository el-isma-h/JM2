---
module: M29
title: "Fiche mémo — Inférence, déploiement et MLOps"
---
# Fiche mémo — M29 · Inférence, déploiement et MLOps

> En une phrase : servir un LLM, c'est quantifier en mesurant, dimensionner mémoire et débit au SLO, chiffrer face aux API, puis versionner et surveiller le service comme du code.

## Les 7 idées à retenir
1. Le decode est limité par la **lecture** des poids : le W4A16 (GPTQ, AWQ, GGUF) accélère la génération, la granularité par groupe sauve le 4 bits (`L141`).
2. vLLM pour le multi-utilisateurs, `llama-server` partout ; TGI est en mode maintenance (`L141`).
3. Les poids décident si le modèle **tient**, le KV cache **combien d'utilisateurs** il sert (`L142`).
4. PagedAttention + batching continu + prefix caching ; le speculative decoding aide la latence à **faible** charge (`L142`).
5. Dimensionner : charge → mémoire → débit **mesuré** au SLO → nombre de GPU (`L143`).
6. Une release = modèle + données + prompt + service, chacun avec une empreinte immuable ; le rollback est une commande (`L144`).
7. Sur l'edge, la RAM décide de ce qui tient, la bande passante de la vitesse d'écriture, les TOPS de la lecture du prompt (`L145`).

## Le schéma à connaître
```mermaid
flowchart LR
  P["Prompt"] --> PF["Prefill : calcul, TTFT"]
  PF --> KV["KV cache : blocs paginés"]
  KV --> DC["Decode : bande passante, TPOT"]
  DC -. "un token à la fois" .-> KV
  DC --> M["Monitoring : système, qualité, dérive, coûts"]
```

## Les formules essentielles
| Formule | Intuition en mots simples |
|---|---|
| $q = \mathrm{clip}(\mathrm{round}(x/s) + z)$, $\hat x = s(q - z)$ | Chaque poids est arrondi au trait le plus proche d'une règle ; une valeur géante l'étire pour tous. |
| KV/token $= 2 \times n_{\text{couches}} \times n_{\text{têtes KV}} \times d_{\text{tête}} \times$ octets | Les notes de réunion gardées pour chaque token, à chaque couche (clés et valeurs). |
| $E = (1 - \alpha^{\gamma+1})/(1 - \alpha)$ | Tokens gagnés par passe quand le « stagiaire » propose $\gamma$ tokens acceptés avec probabilité $\alpha$. |
| $L = \lambda \times W$ (Little) | 2 clients par minute qui restent 3 minutes : 6 clients dans la boutique. |
| $N_{\text{GPU}} = \lceil \lambda T_{out} / (D u) \rceil$ | Le besoin de sortie divisé par le débit mesuré, sans viser 100 % d'utilisation. |
| $\text{PSI} = \sum (p_i - q_i)\ln(p_i/q_i)$ | Compare deux camemberts de trafic ; > 0,25 : dérive significative. |

## Vocabulaire express
| Terme | En clair |
|---|---|
| TTFT / TPOT | Délai du premier token / temps entre deux tokens. |
| `Q4_K_M` | k-quant GGUF ~4,8 bits effectifs, le défaut du marché. |
| Canary / shadow | 5 % puis 25 % du trafic / copie du trafic sans réponse montrée. |

## Les pièges classiques
- Comparer « Q4 » et « AWQ 4 bits » sans mesure sur votre tâche.
- Vendre un débit mono-utilisateur pour un service multi-utilisateurs.
- Mettre le contenu variable au **début** du prompt : il casse le prefix caching.
- Autoscaler sur l'utilisation GPU au lieu de la file d'attente et de la latence.
- Ne surveiller que la latence : un index RAG périmé passe inaperçu.
- Croire qu'ONNX garantit le NPU : repli silencieux sur le CPU.

## Les commandes / chiffres / dates utiles
```bash
vllm serve Qwen/Qwen3-8B-AWQ --max-model-len 32768 --gpu-memory-utilization 0.90 \
  --enable-prefix-caching --kv-cache-dtype fp8
llama-server -m qwen3-8b-Q4_K_M.gguf -ngl 99 -c 32768 -np 4 -fa on --port 8080
vllm bench serve --backend openai-chat --base-url http://localhost:8000 --endpoint /v1/chat/completions \
  --model Qwen/Qwen3-8B-AWQ --dataset-name random --num-prompts 200 --max-concurrency 32
```
- KV en BF16 : Llama 3.1 8B 128 Kio/token (4,3 Go à 32K) ; 70B 320 Kio/token.
- « 4 bits » + échelle FP16 par groupe de 64 + zéro 4 bits = 4,31 bits effectifs.
- Nov. 2026, 315 M tokens d'entrée + 44 M de sortie/mois : Claude Haiku 5.5 ≈ 54 $ ; Sonnet 5.5 ≈ 1 071 $ ; L40S Scaleway 24/7 ≈ 1 022 € (1,40 €/h).
- Lecture du cache de prompt Anthropic : 0,05× sur Sonnet 5.5 depuis le 7/10/2026.
- DGX Spark ≈ 6 950 $ (oct. 2026) ; vLLM y sert 289 à 313 tokens/s agrégés à 8 requêtes.

## Pour aller plus loin
- [vLLM — Quickstart](https://docs.vllm.ai/en/latest/getting_started/quickstart/)
- [llama.cpp — dépôt officiel](https://github.com/ggml-org/llama.cpp)
- [Kwon et al. — PagedAttention / vLLM (2023)](https://arxiv.org/abs/2309.06180)

## Auto-test (3 questions — réponses en bas de fiche)
1. KV cache de Llama 3.1 70B (80 couches, 8 têtes KV, dim. 128, BF16) pour une requête de 16 000 tokens ?
2. 1,2 requête/s × 350 tokens, débit mesuré 900 tokens/s, $u = 0{,}7$ : combien de GPU ?
3. Passer d'un NPU de 40 à 80 TOPS double-t-il les tokens/s d'un LLM de 3B en 4 bits ?

---
**Réponses.** 1. ≈ 5,2 Go. 2. $\lceil 420/630 \rceil = 1$ (+1 si la disponibilité l'exige). 3. Non : le decode est limité par la bande passante mémoire.
