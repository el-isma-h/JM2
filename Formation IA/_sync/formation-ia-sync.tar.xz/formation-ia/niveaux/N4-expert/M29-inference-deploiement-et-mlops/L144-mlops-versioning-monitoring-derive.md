---
id: L144
module: M29
level: N4
title: "MLOps : versioning, monitoring, dérive"
minutes: 60
objectives:
  - "Identifier les quatre artefacts à versionner d'un système LLM (modèle, données, prompts, configuration de service) et les outils adaptés (Hugging Face Hub, DVC, MLflow)"
  - "Construire un manifeste de release reproductible et une procédure de rollback en moins de cinq minutes"
  - "Mettre en place un monitoring à quatre niveaux : système, qualité, dérive, coûts"
  - "Appliquer une intégration continue qui bloque une mise en production quand l'évaluation régresse"
skills: ["C4.5"]
sources:
  - { title: "MLflow — documentation (GenAI, Model Registry, Prompt Registry)", url: "https://mlflow.org", lang: "en" }
  - { title: "DVC — documentation", url: "https://dvc.org/doc", lang: "en" }
  - { title: "Hugging Face Hub — documentation de la bibliothèque huggingface_hub", url: "https://huggingface.co/docs/huggingface_hub/index", lang: "en" }
  - { title: "Full Stack Deep Learning — Course 2022 (Deployment, Continual Learning)", url: "https://fullstackdeeplearning.com/course/", lang: "en" }
  - { title: "Full Stack Deep Learning — LLM Bootcamp Spring 2023 (LLMOps)", url: "https://fullstackdeeplearning.com/llm-bootcamp/spring-2023/", lang: "en" }
  - { title: "Infrabase — LLM observability tools compared (oct. 2026)", url: "https://infrabase.ai/blog/llm-observability-tools-compared", lang: "en" }
  - { title: "promptfoo — dépôt officiel", url: "https://github.com/promptfoo/promptfoo", lang: "en" }
  - { title: "Prometheus — Alerting rules", url: "https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/", lang: "en" }
---

# MLOps : versioning, monitoring, dérive

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 29

## 🎯 Ce que vous saurez faire
- Répondre en dix secondes à la question « quel modèle, quel prompt et quelles données ont produit cette réponse du 14 octobre ? ».
- Revenir à la version précédente d'un service LLM en moins de cinq minutes, sans redéployer à la main.
- Brancher des alertes sur la latence, la qualité, la dérive des entrées et le coût par requête.
- Écrire une intégration continue qui refuse une mise en production dont l'évaluation régresse.

> 🧭 **En clair** — Le MLOps, c'est le **carnet d'entretien et le tableau de bord** de votre IA. Le carnet note précisément quelle version du modèle, du prompt (les consignes données au modèle) et des documents était en service tel jour, pour pouvoir expliquer n'importe quelle réponse passée. Le tableau de bord surveille la vitesse, mais aussi la qualité des réponses et le changement des questions posées (la **dérive**), comme un voyant qui s'allume avant la panne. Et si une nouvelle version déçoit, on doit pouvoir **revenir à l'ancienne d'un geste**, comme on annule une modification dans un traitement de texte.

## 1. Pourquoi le MLOps des LLM est différent

Le MLOps classique, tel que l'enseigne Full Stack Deep Learning dans ses séances « Deployment » et « Continual Learning », versionne un modèle que **vous** avez entraîné sur **vos** données, et surveille une métrique supervisée. Avec les LLM (on parle souvent de *LLMOps*, titre d'une séance du LLM Bootcamp FSDL 2023), trois choses changent :

1. **Le prompt est du code.** Une virgule déplacée dans le prompt système change le comportement autant qu'un nouveau modèle.
2. **Il n'y a souvent pas de vérité terrain.** Une réponse rédigée ne se compare pas à une étiquette : on évalue par échantillonnage, juge-LLM, retours utilisateurs.
3. **Le modèle bouge sans vous.** Une API peut retirer un modèle (Claude Sonnet 4.5 quitte l'API le 30 novembre 2026, d'après le dossier de recherche), un dépôt Hugging Face peut être mis à jour sous le même nom, un serveur d'inférence peut changer de noyau de calcul entre deux versions.

Analogie : un restaurant ne se contente pas de garder « la recette du bœuf bourguignon ». Il note le fournisseur et le lot de viande, la version de la recette, le four utilisé et le chef de service. Le jour où un client tombe malade, il remonte toute la chaîne. Le MLOps, c'est cette **traçabilité**, plus la capacité à **retirer le plat de la carte** en cinq minutes.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : si vous ne changez ni le code ni le prompt, et que vous appelez toujours le même nom de modèle, le comportement de votre service LLM ne peut pas changer.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : un dépôt Hugging Face peut être mis à jour sous le même nom, une API peut retirer ou faire évoluer un modèle, un serveur d'inférence peut changer de noyau de calcul. D'où l'épinglage par empreinte immuable."
}
```

## 2. Les quatre artefacts à versionner

| Artefact | Ce qui change | Outil recommandé | Identifiant immuable |
|---|---|---|---|
| **Modèle** | poids, quantization, adaptateur LoRA | Hugging Face Hub (révisions git), MLflow Model Registry | SHA du commit HF, empreinte du fichier GGUF |
| **Données** | corpus RAG, jeux d'évaluation, données de fine-tuning | DVC (données dans un stockage objet, pointeurs dans git) | hash `md5` DVC + commit git |
| **Prompts** | prompt système, gabarits, définitions d'outils | git + MLflow Prompt Registry | numéro de version + alias |
| **Service** | image du serveur, options (`--max-model-len`…), pilote | git + registre de conteneurs | *digest* `sha256` de l'image |

### 2.1 Le modèle : épingler une révision

```python
# epingler_modele.py — télécharger une révision précise et en garder la trace
import hashlib, json, os, pathlib
from huggingface_hub import HfApi, snapshot_download

REPO = "Qwen/Qwen3-8B-AWQ"
api = HfApi(token=os.environ.get("HF_TOKEN"))
sha = api.model_info(REPO).sha                      # commit courant du dépôt
chemin = snapshot_download(REPO, revision=sha, token=os.environ.get("HF_TOKEN"))

empreintes = {}
for f in sorted(pathlib.Path(chemin).glob("*.safetensors")):
    h = hashlib.sha256()
    with open(f, "rb") as fh:
        for bloc in iter(lambda: fh.read(1 << 24), b""):
            h.update(bloc)
    empreintes[f.name] = h.hexdigest()

json.dump({"repo": REPO, "revision": sha, "sha256": empreintes},
          open("model.lock.json", "w"), indent=2)
print(f"{REPO} épinglé sur {sha[:12]} — {len(empreintes)} fichiers")
```

Passez ensuite `--revision <sha>` à `vllm serve` : le jour où l'éditeur pousse une nouvelle version, votre production ne bouge pas tant que vous ne l'avez pas décidé. Préférez toujours les fichiers `safetensors` aux *pickles* PyTorch, qui peuvent exécuter du code au chargement (risque de chaîne d'approvisionnement, OWASP LLM04:2026).

### 2.2 Les données : DVC

```bash
pip install "dvc[s3]"
git init && dvc init
dvc remote add -d stockage s3://cabinet-ia-donnees/dvc   # ou un bucket Scaleway / OVHcloud compatible S3
dvc add data/corpus_fiscal data/eval/questions_or.jsonl  # crée des fichiers .dvc (pointeurs)
git add data/*.dvc data/eval/*.dvc .gitignore && git commit -m "corpus fiscal v2026-10 + jeu d'éval or"
dvc push                                                 # envoie les données dans le bucket
# Plus tard, revenir exactement aux données d'une release :
git checkout v1.3.0 && dvc checkout
```

> 💡 **Autrement dit** — git n'aime pas les gros fichiers. DVC range donc vos données volumineuses dans un entrepôt à part (un *bucket* de stockage) et ne laisse dans git qu'une **étiquette** (le fichier `.dvc`) qui dit « à cette version du code correspondent exactement ces données ». Revenir en arrière, c'est relire l'étiquette et ressortir les bons cartons de l'entrepôt.

```mission
{
  "title": "Ce que contient vraiment un fichier .dvc",
  "url": "https://dvc.org/doc",
  "steps": ["Ouvrez la documentation de DVC", "Allez dans le guide de démarrage (Get Started) consacré au versionnement des données", "Lisez ce que produit la commande `dvc add` et ce qu'il faut committer dans git"],
  "question": "Que crée `dvc add data/corpus_fiscal`, et quels fichiers doit-on ensuite ajouter à git ?",
  "hint": "Un petit fichier texte qui porte une empreinte, plus une ligne dans un fichier d'exclusion.",
  "answer": "Un fichier `data/corpus_fiscal.dvc` (pointeur contenant l'empreinte md5 et la taille) et une entrée dans `.gitignore` ; on committe ces deux fichiers dans git, les données elles-mêmes partent dans le stockage distant avec `dvc push` (doc consultée nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

### 2.3 Les prompts et le modèle : MLflow

MLflow (Apache 2.0) offre un **registre de modèles** avec des **alias** (`champion`, `challenger`) et, depuis MLflow 3, un **registre de prompts**. Les alias sont la clé du rollback : l'application ne référence jamais « la version 7 » mais « l'alias champion ».

```python
# registre_prompts.py — versionner un prompt et le promouvoir par alias (MLflow 3.x)
import os
import mlflow

mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI", "http://localhost:5000"))

prompt = mlflow.genai.register_prompt(
    name="assistant-fiscal-systeme",
    template=("Vous êtes l'assistant du cabinet. Répondez en français, citez l'article "
              "du CGI applicable et signalez toute incertitude. Question : {{question}}"),
    commit_message="Ajout de l'obligation de citer le CGI",
    tags={"auteur": "equipe-ia", "ticket": "IA-142"},
)
print("version enregistrée :", prompt.version)

# Promotion : l'application charge toujours l'alias, jamais un numéro en dur
mlflow.genai.set_prompt_alias("assistant-fiscal-systeme", alias="champion", version=prompt.version)
p = mlflow.genai.load_prompt("prompts:/assistant-fiscal-systeme@champion")
print(p.format(question="Quel taux de TVA pour une prestation de formation ?"))
```

Les noms exacts des fonctions évoluent d'une version de MLflow à l'autre : vérifiez-les dans la documentation de votre version.

> 💡 **Autrement dit** — Un **alias**, c'est l'étiquette « plat du jour » posée sur l'une des recettes du classeur. Le serveur demande toujours « le plat du jour », jamais « la recette n° 7 » : pour changer de plat, ou revenir à celui d'hier, il suffit de déplacer l'étiquette, sans toucher au code de l'application.

```mission
{
  "title": "La syntaxe officielle pour charger un modèle par alias dans MLflow",
  "url": "https://mlflow.org",
  "steps": ["Depuis mlflow.org, ouvrez la documentation", "Cherchez la page du Model Registry (registre de modèles)", "Repérez la section sur les alias de version et l'URI qui permet de charger un modèle par son alias"],
  "question": "Quelle forme prend l'URI qui charge la version portant l'alias `champion` du modèle `assistant-fiscal` ?",
  "hint": "Le même caractère sépare le nom et l'alias que dans `prompts:/assistant-fiscal-systeme@champion`.",
  "answer": "`models:/assistant-fiscal@champion` (alias de version du Model Registry, introduits avec MLflow 2.3 en avril 2023 et toujours en vigueur) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

### 2.4 Le manifeste de release

Tout se rejoint dans un fichier unique, versionné dans git et étiqueté (`git tag v1.3.0`) :

```yaml
# release.yaml — ce qui est en production, et rien d'autre
release: v1.3.0
date: 2026-11-01
modele: { repo: Qwen/Qwen3-8B-AWQ, revision: 3f2a9c1e7b4d, quantization: awq-int4 }
serveur:
  image: vllm/vllm-openai@sha256:<digest-de-l-image-testee>
  options: ["--max-model-len", "16384", "--enable-prefix-caching", "--kv-cache-dtype", "fp8"]
prompt: { nom: assistant-fiscal-systeme, version: 7 }
donnees: { corpus_rag: "git:v1.3.0 + dvc", index_vectoriel: "qdrant snapshot 2026-10-30" }
evaluation: { jeu: data/eval/questions_or.jsonl, score: 0.87, seuil: 0.85 }
```

> 💡 **À retenir** — Une release LLM = **modèle + données + prompt + service**, chacun identifié par une empreinte immuable. Si l'un des quatre manque dans le manifeste, vous ne pourrez ni reproduire un incident ni revenir en arrière proprement.

## 3. Le monitoring à quatre étages

```
┌──────────────────────────────────────────────────────────────────┐
│ 4. COÛTS     € / 1 000 requêtes, tokens par utilisateur, budget   │
│ 3. DÉRIVE    distribution des entrées, thèmes, langue, longueur   │
│ 2. QUALITÉ   juge-LLM échantillonné, retours 👍/👎, refus, citations│
│ 1. SYSTÈME   TTFT/TPOT p95, erreurs, file d'attente, KV cache      │
└──────────────────────────────────────────────────────────────────┘
```

### 3.1 Système
Les métriques Prometheus de vLLM (L142) suffisent pour l'étage 1. Exemples de règles d'alerte :

```yaml
# alertes-llm.yaml — règles Prometheus (adaptez les noms à votre version de vLLM)
groups:
  - name: llm-service
    rules:
      - alert: TTFTp95Eleve
        expr: histogram_quantile(0.95, sum by (le) (rate(vllm:time_to_first_token_seconds_bucket[5m]))) > 2
        for: 10m
        labels: { severity: warning }
        annotations: { summary: "TTFT p95 > 2 s depuis 10 min : capacité insuffisante ?" }
      - alert: FileAttenteLongue
        expr: sum(vllm:num_requests_waiting) > 20
        for: 5m
        labels: { severity: critical }
        annotations: { summary: "Plus de 20 requêtes en attente : l'autoscaling suit-il ?" }
```

### 3.2 Qualité
Sans vérité terrain, combinez trois signaux :
- **Échantillonnage + juge-LLM** : évaluez chaque jour 1 à 5 % des conversations (anonymisées) avec une grille (exactitude, citation des sources, ton) et un modèle juge plus puissant. Calibrez le juge sur une centaine d'exemples annotés par un humain (M28, L138).
- **Retours explicites** (pouce levé ou baissé, signalement) et **implicites** (reformulation immédiate de la question, copier-coller de la réponse, abandon).
- **Indicateurs automatiques** : taux de refus, taux de réponses sans citation, longueur anormale, langue de la réponse différente de celle de la question.

Les plateformes d'observabilité (Langfuse, LangSmith, Arize Phoenix, MLflow Tracing…) relient chaque trace à sa version de prompt et de modèle ; le comparatif d'Infrabase (oct. 2026) vous aidera à choisir. Pensez RGPD : les traces contiennent des données personnelles, d'où durée de conservation, pseudonymisation et hébergement maîtrisé.

### 3.3 Dérive
Deux dérives à distinguer :
- **Dérive des données** (*data drift*) : les entrées changent. Le cabinet lance une offre « paie », et les questions sociales passent de 10 % à 45 % du trafic alors que le corpus RAG est fiscal.
- **Dérive de concept** : la bonne réponse change pour une même question. Exemple typique : une loi de finances modifie un taux au 1er janvier, le corpus et le modèle « savent » encore l'ancien.

Sans étiquettes, on surveille des **distributions** : longueur des questions, langue, thème (classé par un petit modèle) ou, plus fin, la projection des questions dans un espace d'embeddings. L'indice de stabilité de population (PSI) est un détecteur simple et robuste :

$$\text{PSI} = \sum_{i} (p_i - q_i)\,\ln\frac{p_i}{q_i}$$

où $q_i$ et $p_i$ sont les proportions de la classe $i$ dans la période de référence et dans la période observée. Usage courant : PSI < 0,1 stable, 0,1-0,25 à surveiller, > 0,25 dérive significative.

> 💡 **Autrement dit** — Le PSI compare deux « camemberts » : la répartition des questions le mois dernier et celle de ce mois-ci. Si les parts sont presque identiques, le PSI reste proche de zéro ; si une part gonfle brusquement (les questions de paie passent de 10 % à 45 %), il grimpe. C'est un thermomètre : il dit **que** quelque chose a changé, pas **quoi** ; c'est à vous d'aller voir.

```python
# derive.py — PSI sur la distance des questions au centre du trafic de référence (numpy)
import numpy as np

def psi(ref: np.ndarray, obs: np.ndarray, n_bins: int = 10) -> float:
    bords = np.quantile(ref, np.linspace(0, 1, n_bins + 1))
    bords[0], bords[-1] = -np.inf, np.inf
    q = np.histogram(ref, bords)[0] / len(ref)
    p = np.histogram(obs, bords)[0] / len(obs)
    q, p = np.clip(q, 1e-6, None), np.clip(p, 1e-6, None)
    return float(np.sum((p - q) * np.log(p / q)))

def distance_au_centre(emb: np.ndarray, centre: np.ndarray) -> np.ndarray:
    emb = emb / np.linalg.norm(emb, axis=1, keepdims=True)
    return 1.0 - emb @ (centre / np.linalg.norm(centre))   # distance cosinus

# Démonstration avec des embeddings simulés (remplacez par vos vrais embeddings de questions)
rng = np.random.default_rng(0)
ref = rng.normal(0, 1, (5000, 384)) + 0.5               # octobre : questions fiscales
obs_stable = rng.normal(0, 1, (2000, 384)) + 0.5        # novembre, même thématique
obs_derive = np.vstack([obs_stable[:1100], rng.normal(0, 1, (900, 384)) - 0.5])  # arrivée de la paie
centre = ref.mean(axis=0)
d_ref = distance_au_centre(ref, centre)
for nom, obs in (("stable", obs_stable), ("dérive", obs_derive)):
    v = psi(d_ref, distance_au_centre(obs, centre))
    print(f"{nom:7s} PSI = {v:.3f} → {'ALERTE' if v > 0.25 else 'à surveiller' if v > 0.1 else 'ok'}")
```

### 3.4 Coûts
Calculez et affichez le **coût par requête** et par utilisateur, pas seulement la facture globale : coût GPU horaire divisé par les requêtes servies (auto-hébergé) ou tokens × prix (API). Alertez sur un budget journalier et sur les anomalies (un agent qui boucle peut consommer en une nuit le budget d'un mois : OWASP LLM06:2026 *Unbounded Consumption*).

> ⚠️ **Piège fréquent** — Ne surveiller que l'étage 1. Un service peut afficher une latence parfaite et des réponses fausses depuis trois semaines, parce que l'index RAG n'a plus été mis à jour. Les étages 2 et 3 détectent ce que l'étage 1 ne voit pas.

```quiz
{
  "q": "Mise en situation : au 1er janvier, une loi de finances modifie un taux. Les questions des collaborateurs restent les mêmes, mais l'assistant donne l'ancien taux. De quoi s'agit-il ?",
  "options": ["D'une dérive des données (les entrées changent)", "D'un problème de latence (étage 1)", "D'une consommation non bornée (OWASP LLM06)", "D'une dérive de concept (la bonne réponse change)"],
  "answer": 3,
  "explanation": "Les entrées n'ont pas bougé : c'est la bonne réponse qui a changé. Un PSI sur les questions ne la détectera pas ; il faut mettre à jour le corpus et le jeu d'évaluation à chaque changement réglementaire."
}
```

## 4. Déployer sans trembler : canary, shadow, rollback

| Stratégie | Principe | Quand |
|---|---|---|
| **Shadow** | la nouvelle version reçoit une copie du trafic, ses réponses ne sont pas montrées | nouveau modèle, risque élevé |
| **Canary** | 5 %, puis 25 %, puis 100 % du trafic, avec comparaison des métriques | cas général |
| **Blue/green** | deux environnements complets, bascule instantanée | changement d'infrastructure |
| **Rollback** | retour à la release précédente | dès qu'une alerte qualité ou système se confirme |

Le rollback doit être une **commande**, pas une procédure : repasser l'alias `champion` du prompt sur la version précédente, ou ré-appliquer le manifeste `v1.2.0`. Testez-le à blanc une fois par trimestre, comme un exercice d'évacuation.

```quiz
{
  "q": "Vous remplacez Qwen3-8B par un modèle d'une autre famille, au comportement mal connu. Quelle stratégie de déploiement adopter d'abord ?",
  "options": ["Blue/green avec bascule immédiate de 100 % du trafic", "Shadow : copie du trafic, réponses non montrées", "Rollback préventif", "Aucune : l'évaluation en CI suffit"],
  "answer": 1,
  "explanation": "Pour un risque élevé, le mode shadow compare la nouvelle version sur du trafic réel sans exposer ses réponses aux utilisateurs. On passe ensuite en canary (5 %, 25 %, 100 %)."
}
```

> 🎮 **Défi** — Sans regarder la section 2, citez de mémoire les quatre artefacts d'une release LLM et l'identifiant immuable de chacun. *Réponse : modèle (SHA du commit HF ou empreinte du GGUF), données (hash DVC + commit git), prompt (version + alias), service (digest `sha256` de l'image).*

```bash
# rollback.sh — revenir à la release précédente (prompt + service)
set -euo pipefail
PRECEDENTE=${1:?usage: rollback.sh v1.2.0}
git checkout "$PRECEDENTE" -- release.yaml k8s/
python -c "import mlflow,yaml; r=yaml.safe_load(open('release.yaml')); \
mlflow.genai.set_prompt_alias(r['prompt']['nom'], alias='champion', version=r['prompt']['version'])"
kubectl apply -f k8s/ && kubectl rollout status deploy/vllm-qwen3 --timeout=15m
echo "Rollback vers $PRECEDENTE terminé"
```

## 5. L'intégration continue : l'évaluation comme garde-fou

Chaque modification d'un des quatre artefacts déclenche la même chaîne : construction, démarrage du service en environnement de test, **suite d'évaluation**, comparaison au seuil du manifeste, puis seulement déploiement canary. promptfoo (MIT) décrit les tests en YAML et renvoie un code d'erreur si des assertions échouent, ce qui suffit à bloquer un pipeline.

```yaml
# promptfooconfig.yaml — tests de non-régression de l'assistant fiscal
providers:
  - id: openai:chat:qwen3-8b
    config: { apiBaseUrl: "http://localhost:8000/v1", apiKey: "{{ env.VLLM_API_KEY }}" }
prompts: [file://prompts/systeme.txt]
tests:
  - vars: { question: "Quel est le taux normal de TVA en France métropolitaine ?" }
    assert: [{ type: contains, value: "20" }]
  - vars: { question: "Peut-on déduire la TVA sur un véhicule de tourisme ?" }
    assert:
      - { type: icontains, value: "CGI" }
      - { type: llm-rubric, value: "La réponse explique le principe de non-déduction et ses exceptions" }
```

```yaml
# .github/workflows/eval.yml — bloque la fusion si l'évaluation régresse
name: eval-llm
on: [pull_request]
jobs:
  eval:
    runs-on: [self-hosted, gpu]          # runner disposant d'un GPU
    steps:
      - uses: actions/checkout@v4
      - name: Démarrer le service de test
        run: docker compose -f docker-compose.test.yml up -d --wait
      - name: Évaluer
        env: { VLLM_API_KEY: "${{ secrets.VLLM_API_KEY }}" }
        run: npx promptfoo@latest eval -c promptfooconfig.yaml -o resultats.json
      - uses: actions/upload-artifact@v4
        with: { name: resultats-eval, path: resultats.json }
```

> 🔗 **Documentation officielle** — [MLflow](https://mlflow.org) 🇬🇧 · [DVC](https://dvc.org/doc) 🇬🇧 · [huggingface_hub](https://huggingface.co/docs/huggingface_hub/index) 🇬🇧

## 🧪 Exercice pratique

**Consigne.** Reprenez le service vLLM de L143 et industrialisez-le :
1. Créez un dépôt git avec `model.lock.json`, un corpus versionné par DVC, un prompt enregistré dans MLflow avec l'alias `champion`, et `release.yaml` étiqueté `v1.0.0`.
2. Écrivez 15 tests promptfoo et une règle d'alerte Prometheus sur le TTFT p95.
3. Modifiez volontairement le prompt pour dégrader une réponse, ouvrez une *pull request* et vérifiez que l'intégration continue échoue.
4. Déployez une `v1.1.0`, puis exécutez `rollback.sh v1.0.0` en chronométrant.
5. Calculez le PSI entre deux semaines de questions réelles ou simulées.

**Critères de réussite.** Les quatre artefacts sont identifiés par une empreinte dans le manifeste ; la CI bloque la régression ; le rollback dure moins de cinq minutes hors rechargement du modèle ; le PSI est interprété (stable / à surveiller / dérive).

<details><summary>Pistes de corrigé</summary>

Si le rollback ne touche que le prompt, il est quasi instantané (changement d'alias, relu par l'application au prochain appel ou après expiration de son cache). S'il change le modèle, la durée est dominée par le chargement : d'où l'intérêt de garder l'ancienne version chaude pendant toute la durée du canary. Un PSI au-dessus de 0,25 doit déclencher une analyse des thèmes émergents et, le plus souvent, un enrichissement du corpus RAG plutôt qu'un changement de modèle.
</details>

## ✅ Auto-évaluation express
1. Pourquoi l'application doit-elle charger « l'alias champion » plutôt qu'un numéro de version ?
2. Donnez un exemple de dérive de concept dans un cabinet comptable.
3. Que vaut un PSI de 0,32 et que faites-vous ?

*Réponses : 1. Pour que la promotion et le rollback se fassent en déplaçant l'alias, sans redéployer le code. 2. Un taux légal modifié par la loi de finances au 1er janvier : la même question appelle une nouvelle réponse. 3. Une dérive significative (> 0,25) : analyser les nouvelles thématiques, mettre à jour le corpus et le jeu d'évaluation, puis réévaluer.*

## 📚 Pour aller plus loin
- [MLflow — documentation](https://mlflow.org) 🇬🇧 — GenAI, tracing, registres de modèles et de prompts.
- [DVC — documentation](https://dvc.org/doc) 🇬🇧 — versionner données et pipelines avec git.
- [Hugging Face Hub — huggingface_hub](https://huggingface.co/docs/huggingface_hub/index) 🇬🇧 — révisions, téléchargement épinglé.
- [Full Stack Deep Learning — Course 2022](https://fullstackdeeplearning.com/course/) 🇬🇧 et [LLM Bootcamp 2023](https://fullstackdeeplearning.com/llm-bootcamp/spring-2023/) 🇬🇧 — séances « Continual Learning » et « LLMOps », sources d'inspiration.
- [Infrabase — LLM observability tools compared](https://infrabase.ai/blog/llm-observability-tools-compared) 🇬🇧 — Langfuse, LangSmith, Phoenix, Helicone, MLflow comparés (oct. 2026).
- [Prometheus — Alerting rules](https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/) 🇬🇧 — syntaxe des règles d'alerte.

> 🗺️ **Et maintenant ?** — Vous savez faire vivre un service sur des serveurs ; la leçon L145 emmène le modèle hors du datacenter, sur les téléphones, PC et cartes embarquées équipés de NPU.
