---
id: L143
module: M29
level: N4
title: "Servir en production : GPU cloud, on-premise, DGX Spark, coûts"
minutes: 60
objectives:
  - "Dimensionner un service d'inférence à partir d'un profil de charge (loi de Little, mémoire KV, débit mesuré, taux d'utilisation cible)"
  - "Comparer le coût mensuel d'un auto-hébergement (cloud GPU, on-premise, DGX Spark) avec celui des API Claude, OpenAI et Mistral aux tarifs de novembre 2026"
  - "Construire un déploiement conteneurisé de vLLM (Docker, Kubernetes) avec sondes de santé et autoscaling sur la file d'attente"
  - "Évaluer quand l'auto-hébergement se justifie et quand une API est préférable"
skills: ["C4.5"]
sources:
  - { title: "Scaleway — Tarifs GPU", url: "https://www.scaleway.com/en/pricing/gpu", lang: "en" }
  - { title: "OVHcloud — Prix Public Cloud", url: "https://ovhcloud.com/en/public-cloud/prices", lang: "en" }
  - { title: "Spheron — GPU cloud pricing comparison RunPod vs Vast.ai (2026)", url: "https://www.spheron.network/blog/gpu-cloud-pricing-comparison-runpod-vs-vastai-2026/", lang: "en" }
  - { title: "CloudZero — Cloud GPU pricing comparison (2026)", url: "https://www.cloudzero.com/blog/cloud-gpu-pricing-comparison/", lang: "en" }
  - { title: "IntuitionLabs — NVIDIA DGX Spark review", url: "https://intuitionlabs.ai/articles/nvidia-dgx-spark-review", lang: "en" }
  - { title: "Anthropic — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "OpenAI — API pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "Mistral AI — Pricing", url: "https://docs.mistral.ai/inference/pricing", lang: "en" }
  - { title: "Kubernetes — Schedule GPUs", url: "https://kubernetes.io/docs/tasks/manage-gpus/scheduling-gpus/", lang: "en" }
  - { title: "KEDA — documentation", url: "https://keda.sh/docs/", lang: "en" }
  - { title: "Full Stack Deep Learning — Lecture 5 Deployment", url: "https://fullstackdeeplearning.com/course/", lang: "en" }
---

# Servir en production : GPU cloud, on-premise, DGX Spark, coûts

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 29

## 🎯 Ce que vous saurez faire
- Transformer une phrase de client (« 150 collaborateurs, un assistant documentaire ») en nombre de GPU, avec une formule et des hypothèses explicites.
- Chiffrer, au centime près et en datant les prix, le coût mensuel de cinq options d'hébergement et de six API.
- Écrire un `docker-compose.yml` puis un déploiement Kubernetes de vLLM avec sondes et autoscaling.
- Défendre devant une direction financière le choix « API », « cloud GPU » ou « machine sur site », sans dogme.

> 🧭 **En clair** — Mettre une IA en production, c'est comme choisir entre **prendre le taxi, louer une voiture ou en acheter une**. Le taxi (une API comme Claude ou Mistral) ne coûte rien tant qu'on ne roule pas, et se paie à la course. La location (un GPU dans le cloud) se paie à l'heure, même quand la voiture est garée. L'achat (une machine dans vos locaux ou un DGX Spark) coûte cher au départ, demande de l'entretien, mais vous garde maître du véhicule et de ce qu'on y transporte. Pour choisir, on commence toujours par compter les trajets : combien de personnes, combien de questions, à quelle heure de pointe. Et l'on découvre souvent que, pour une PME, le taxi est le moins cher, et que l'on achète surtout pour la **confidentialité**.

En L042, vous avez appris à arbitrer « acheter ou louer » pour un poste individuel. Ici, on dimensionne un **service** : des utilisateurs simultanés, une promesse de latence, une disponibilité, un budget. Full Stack Deep Learning le résume dans sa séance « Deployment » : un modèle n'a de valeur qu'une fois servi de façon fiable, et la plupart des échecs viennent de l'infrastructure, pas du modèle.

## 1. La méthode de dimensionnement en quatre étapes

### Étape 1 — Le profil de charge
Recueillez cinq nombres auprès du client (ou dans ses journaux) :
- $\lambda$ : requêtes par seconde **à l'heure de pointe** (pas en moyenne) ;
- $T_{in}$ et $T_{out}$ : tokens moyens en entrée et en sortie (et la part de préfixe commun) ;
- la promesse de service (SLO) : par exemple TTFT p95 < 2 s, TPOT p95 < 60 ms ;
- les horaires (24/7 ou heures ouvrées) et la disponibilité exigée.

La **loi de Little** donne le nombre de requêtes simultanées : $L = \lambda \times W$, où $W$ est la durée moyenne d'une requête ($W \approx \text{TTFT} + T_{out} \times \text{TPOT}$).

> 💡 **Autrement dit** — La loi de Little, c'est le calcul du boulanger : s'il entre 2 clients par minute et que chacun reste 3 minutes dans la boutique, il y a en moyenne 6 clients à l'intérieur. Ici, les « clients » sont les requêtes, et la « boutique » est la mémoire du GPU, qui doit pouvoir les accueillir tous en même temps.

### Étape 2 — La mémoire
$$\text{VRAM}_{\text{nécessaire}} = \text{poids} + L \times (T_{in} + T_{out}) \times \text{KV/token} \times m + \text{réserve}$$
avec $m \approx 1{,}5$ (marge pour les pics) et une réserve de 2 à 3 Go (activations, graphes CUDA). Le KV/token se calcule comme en L142.

### Étape 3 — Le débit, **mesuré**
Lancez `vllm bench serve` (L141) sur le GPU candidat, avec vos longueurs réelles, à une concurrence proche de $L$. Retenez le débit de sortie agrégé $D$ (tokens/s) **pour lequel le SLO est encore respecté**. Ne prenez jamais un chiffre de blog pour ce paramètre : il dépend du modèle, de la quantization, de la version du serveur et de vos longueurs.

### Étape 4 — Le nombre de GPU
$$N_{\text{GPU}} = \left\lceil \frac{\lambda \times T_{out}}{D \times u} \right\rceil \quad (+1 \text{ si la disponibilité l'exige})$$
où $u$ est le taux d'utilisation cible (0,6 à 0,7 : on ne dimensionne jamais à 100 %, sinon le moindre pic fait exploser les files d'attente). Vérifiez aussi le prefill : $\lambda \times T_{in}$ (moins la part servie par le prefix caching) doit rester très inférieur à la capacité de prefill mesurée.

> 💡 **À retenir** — Un dimensionnement sérieux tient sur une page : profil de charge, calcul mémoire, débit **mesuré** au SLO, taux d'utilisation cible, redondance. Chaque hypothèse est écrite, datée, et peut être contestée.

```
 Profil de charge ──► Mémoire (poids + KV) ──► Débit MESURÉ au SLO ──► Nombre de GPU (+1)
   λ, T_in, T_out        « ça tient ? »           vllm bench serve        ⌈λ·T_out / (D·u)⌉
```

```quiz
{
  "q": "Un service reçoit 2 requêtes par seconde en pointe ; chaque requête dure en moyenne 15 s. Combien de requêtes simultanées le GPU doit-il pouvoir tenir en mémoire ?",
  "options": ["7,5", "17", "30", "2"],
  "answer": 2,
  "explanation": "Loi de Little : L = λ × W = 2 × 15 = 30 requêtes simultanées. C'est ce nombre qui fixe la taille du KV cache à prévoir."
}
```

## 2. Exemple chiffré : un cabinet d'expertise comptable

Le cabinet (fictif) Martin & Associés, 150 collaborateurs à Nantes, veut un assistant de recherche documentaire (RAG sur sa base fiscale et sociale). Le secret professionnel pousse la direction à envisager l'auto-hébergement. Hypothèses recueillies :

| Paramètre | Valeur |
|---|---|
| Usage | 40 requêtes / collaborateur / jour ouvré, 21 jours / mois → **126 000 requêtes / mois** |
| Pointe | $\lambda$ = 1,2 requête / s (9 h-11 h) |
| Entrée | $T_{in}$ = 2 500 tokens, dont 1 500 de préfixe commun (consignes + outils) |
| Sortie | $T_{out}$ = 350 tokens |
| SLO | TTFT p95 < 2 s ; TPOT p95 < 60 ms |
| Modèle | Qwen3-8B en AWQ 4 bits (poids ≈ 5,5 Go ; KV 144 Kio/token en BF16) |

**Étape 1.** $W \approx 1 + 350 \times 0{,}05 = 18{,}5$ s, donc $L = 1{,}2 \times 18{,}5 \approx 22$ requêtes simultanées.

**Étape 2.** KV par requête : $2\,850 \times 144$ Kio ≈ 0,42 Go ; pour 22 requêtes avec la marge de 1,5 : ≈ 13,9 Go. Total ≈ 5,5 + 13,9 + 3 ≈ **22,4 Go**. Une L4 24 Go est trop juste ; une **L40S 48 Go** est confortable (et laisse de la place au prefix caching).

**Étape 3.** Hypothèse pédagogique, **à remplacer par votre mesure** : sur L40S, `vllm bench serve` à concurrence 24 donne $D$ = 900 tokens/s de sortie agrégés avec un TPOT p95 de 45 ms.

**Étape 4.** Besoin de sortie : $1{,}2 \times 350 = 420$ tokens/s. $N = \lceil 420 / (900 \times 0{,}7) \rceil = \lceil 0{,}67 \rceil = 1$ GPU. Prefill : $1{,}2 \times 1\,000$ tokens nouveaux ≈ 1 200 tokens/s, largement absorbable. Avec une exigence de continuité de service, on ajoute un second GPU, ou une **bascule vers une API** en secours.

```python
# dimensionnement.py — la méthode en 4 étapes, hypothèses en tête de fichier
import math

lam, t_in, t_out = 1.2, 2500, 350          # pointe (req/s), tokens entrée / sortie
ttft, tpot = 1.0, 0.05                      # secondes (SLO visé)
poids_go, kv_kio, marge, reserve = 5.5, 144, 1.5, 3.0
vram_go, debit_mesure, u = 48.0, 900, 0.7   # L40S, débit agrégé MESURÉ au SLO, utilisation cible

W = ttft + t_out * tpot
L = lam * W
kv_req_go = (t_in + t_out) * kv_kio * 1024 / 1e9
vram = poids_go + L * kv_req_go * marge + reserve
n_gpu = math.ceil(lam * t_out / (debit_mesure * u))
print(f"W = {W:.1f} s · L = {L:.1f} requêtes simultanées")
print(f"VRAM nécessaire ≈ {vram:.1f} Go (disponible : {vram_go * 0.9:.1f} Go)")
print(f"GPU nécessaires : {n_gpu} (+1 pour la redondance)")
```

## 3. Combien ça coûte ? Comparatif mensuel (nov. 2026)

Volume mensuel : 126 000 × 2 500 = **315 M tokens en entrée** et 126 000 × 350 = **44,1 M tokens en sortie**.

### 3.1 Les API (prix catalogue USD par million de tokens, sans cache ni batch)

| API (nov. 2026) | Entrée / sortie ($/MTok) | Coût mensuel |
|---|---|---|
| Claude Haiku 5.5 (requêtes ≤ 100k tokens) | 0,10 / 0,50 | 31,50 + 22,05 = **53,55 $** |
| OpenAI gpt-6-luna | 0,10 / 0,50 | **53,55 $** |
| Mistral Small 4 | 0,15 / 0,60 | 47,25 + 26,46 = **73,71 $** |
| Claude Sonnet 5.5 | 2 / 10 | 630 + 441 = **1 071 $** |
| OpenAI gpt-6.1-sol | 2 / 10 | **1 071 $** |
| Claude Opus 5.5 | 4 / 20 | 1 260 + 882 = **2 142 $** |

Sources : pages tarifaires officielles d'Anthropic, OpenAI et Mistral, relevées dans notre dossier de recherche (nov. 2026). Le **prompt caching** réduit encore ces montants : avec Claude Sonnet 5.5, les 1 500 tokens de préfixe lus en cache à 0,10 $/MTok au lieu de 2 $ font passer la facture à environ 712 $ (hors coût d'écriture du cache) ; l'API **Batch** divise le prix par deux pour les traitements différés.

### 3.2 L'auto-hébergement (prix horaires HT, relevés nov. 2026)

| Option | Prix unitaire | 24/7 (730 h) | Heures ouvrées (11 h × 21 j = 231 h) |
|---|---|---|---|
| Scaleway L40S 48 Go (France) | 1,40 €/h | **1 022 €** | 323 € |
| 2 × Scaleway L40S (redondance) | 2,80 €/h | 2 044 € | 647 € |
| Scaleway H100 PCIe | 2,73 €/h | 1 993 € | 631 € |
| OVHcloud H100 (France) | 2,80 €/h | 2 044 € | 647 € |
| RunPod RTX 4090 Community | 0,34 $/h | 248 $ | 79 $ |
| Hyperscaler, H100 (médiane CloudZero) | 7,89 $/h | 5 760 $ | 1 823 $ |
| **DGX Spark** sur site | ≈ 6 950 $ (oct. 2026) | ≈ 193 $ d'amortissement sur 36 mois + électricité | idem |

Pour le DGX Spark, ajoutez l'électricité (240 W au maximum, soit au plus 175 kWh par mois en 24/7 ; multipliez par votre tarif) et surtout le **temps humain** : mises à jour, supervision, sauvegardes. Attention aussi à la capacité : le Spark a une bande passante mémoire de 273 Go/s et vLLM y atteint environ 300 tokens/s agrégés à 8 requêtes simultanées (Spheron, oct. 2026), ce qui reste **en dessous** des 420 tokens/s demandés en pointe. Un Spark conviendrait pour 50 à 80 collaborateurs, pas pour 150 avec ce SLO.

### 3.3 Lecture honnête du résultat

À ce volume, une API de petit modèle coûte **vingt fois moins** qu'un GPU loué en continu. Le seuil de rentabilité face à Claude Haiku 5.5 se situerait autour de 2,4 millions de requêtes par mois pour une seule L40S (1 022 € ÷ 0,000425 $ par requête, en négligeant le change), sans compter le temps d'ingénierie. Face à un modèle de classe Sonnet ou gpt-6.1-sol, le point mort est proche dès ce volume, mais la qualité n'est pas comparable à celle d'un modèle de 8B : il faudrait comparer avec un modèle ouvert plus grand, donc plus de GPU.

L'auto-hébergement se justifie donc rarement par le seul coût pour une PME. Il se justifie par :
- la **confidentialité** et la souveraineté (secret professionnel, données de santé, clauses contractuelles, hébergement en France) ;
- un **modèle adapté** (fine-tuning du module M28) que les API ne servent pas ;
- un **volume très élevé et régulier** (traitements nocturnes massifs, millions de requêtes) ;
- le **hors-ligne** ou la latence locale (atelier, site industriel) ;
- l'indépendance vis-à-vis des changements de prix (Google a par exemple annoncé une hausse de ses tarifs Gemini au 1er décembre 2026).

> ⚠️ **Piège fréquent** — Comparer le prix d'un GPU à l'heure au prix d'une API au token sans ramener les deux au même volume mensuel, ou oublier le coût humain : une demi-journée d'ingénieur par mois pour maintenir le service pèse souvent plus lourd que la location du GPU.

> 🎮 **Défi** — Le cabinet passe ses traitements de lettres de mission (50 M tokens d'entrée, 10 M de sortie par mois, non urgents) sur l'API Batch de Claude Sonnet 5.5 (1 $ / 5 $). Combien paie-t-il ? *Réponse : 50 + 50 = 100 $ par mois.*

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour une PME de 150 personnes, louer une L40S en continu est presque toujours moins cher qu'une API de petit modèle.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : dans l'exemple du cabinet, l'API Haiku 5.5 coûte environ 54 $ par mois contre environ 1 022 € pour la L40S en 24/7. L'auto-hébergement se justifie surtout par la confidentialité, un modèle adapté, un très gros volume ou le hors-ligne."
}
```

```mission
{
  "title": "Vérifier la remise de l'API Batch sur la grille officielle",
  "url": "https://platform.claude.com/docs/en/about-claude/pricing",
  "steps": ["Ouvrez la page Pricing de la documentation Claude", "Repérez la section consacrée au traitement par lots (Batch processing)", "Relevez la réduction appliquée et le prix de sortie de Claude Haiku 5.5"],
  "question": "Quelle réduction l'API Batch accorde-t-elle, et combien coûte 1 M de tokens de sortie de Claude Haiku 5.5 au tarif normal ?",
  "hint": "La remise Batch est la même pour tous les modèles.",
  "answer": "−50 % sur l'entrée et la sortie avec l'API Batch ; Haiku 5.5 : 0,50 $ par million de tokens de sortie pour les requêtes ≤ 100k tokens, 2,50 $ au-delà (nov. 2026) — vérifiez : les prix évoluent (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Cloud, on-premise ou DGX Spark : la grille de décision

| Critère | API | Cloud GPU (Scaleway, OVHcloud, RunPod…) | On-premise (serveur GPU) | DGX Spark / Strix Halo |
|---|---|---|---|---|
| Mise en route | minutes | heures | semaines (achat, installation) | jours |
| Coût fixe | aucun | à l'heure, arrêtable | investissement élevé | 3 400 à 7 000 $ environ |
| Élasticité | totale | bonne (autoscaling) | nulle | nulle |
| Confidentialité | contrats, zone de données | hébergeur choisi (France possible) | maximale | maximale |
| Modèles | ceux du fournisseur | tous les modèles ouverts | tous | jusqu'à ~200B en FP4 ; décode lent |
| Exploitation | nulle | moyenne | lourde | légère (un poste) |
| Profil idéal | démarrer, volume faible à moyen | production souveraine, pics | gros volume stable, contraintes fortes | prototypage, petite équipe, gros MoE |

La combinaison la plus fréquente en 2026 est **hybride** : un modèle ouvert hébergé en France pour les données sensibles, une API pour les tâches génériques ou en secours, derrière une **passerelle** unique (un routeur compatible OpenAI) qui choisit la cible selon la sensibilité de la requête.

## 5. Conteneuriser : Docker

```yaml
# docker-compose.yml — vLLM derrière une clé d'API, cache Hugging Face persistant
services:
  vllm:
    image: vllm/vllm-openai:latest      # en production, épinglez une version précise
    ipc: host                            # mémoire partagée pour PyTorch
    ports: ["8000:8000"]
    volumes:
      - hf-cache:/root/.cache/huggingface
    environment:
      - HF_TOKEN=${HF_TOKEN}
    command: >
      --model Qwen/Qwen3-8B-AWQ
      --served-model-name qwen3-8b
      --max-model-len 16384
      --gpu-memory-utilization 0.90
      --enable-prefix-caching
      --api-key ${VLLM_API_KEY}
    deploy:
      resources:
        reservations:
          devices: [{ driver: nvidia, count: 1, capabilities: [gpu] }]
    healthcheck:
      test: ["CMD", "curl", "-fs", "http://localhost:8000/health"]
      interval: 30s
      start_period: 600s                 # le chargement du modèle prend plusieurs minutes
volumes:
  hf-cache:
```

```bash
export HF_TOKEN=hf_xxx VLLM_API_KEY=$(openssl rand -hex 24)
docker compose up -d && docker compose logs -f vllm   # attendre « Application startup complete »
curl -s localhost:8000/v1/models -H "Authorization: Bearer $VLLM_API_KEY"
```

## 6. Orchestrer : Kubernetes et autoscaling

> 💡 **Autrement dit** — Kubernetes est un chef d'orchestre de conteneurs : vous lui décrivez « je veux tel serveur, avec un GPU, et jamais moins d'un exemplaire en marche », et il s'occupe de le placer sur une machine, de le relancer s'il tombe et d'en ajouter quand la file d'attente s'allonge (l'*autoscaling*, ici confié à KEDA).

Sur Kubernetes, le GPU est une ressource comme une autre (`nvidia.com/gpu`), exposée par le *device plugin* NVIDIA (ou le GPU Operator). Deux particularités des LLM changent tout : le **démarrage est lent** (téléchargement de plusieurs Go, chargement, compilation des graphes : de une à dix minutes), et le **CPU n'est pas un bon signal de charge**. On met donc les poids sur un volume persistant, on utilise une `startupProbe` généreuse, et on déclenche l'autoscaling sur la **file d'attente** du serveur.

```yaml
# vllm-k8s.yaml — Deployment + Service + autoscaling KEDA sur la file d'attente vLLM
apiVersion: apps/v1
kind: Deployment
metadata: { name: vllm-qwen3, labels: { app: vllm-qwen3 } }
spec:
  replicas: 1
  selector: { matchLabels: { app: vllm-qwen3 } }
  template:
    metadata: { labels: { app: vllm-qwen3 } }
    spec:
      containers:
        - name: vllm
          image: vllm/vllm-openai:latest   # épinglez une version
          args: ["--model", "Qwen/Qwen3-8B-AWQ", "--served-model-name", "qwen3-8b",
                 "--max-model-len", "16384", "--enable-prefix-caching"]
          env:
            - name: HF_TOKEN
              valueFrom: { secretKeyRef: { name: hf-token, key: token } }
          ports: [{ containerPort: 8000, name: http }]
          resources:
            limits: { nvidia.com/gpu: 1, memory: 32Gi }
          startupProbe:
            httpGet: { path: /health, port: 8000 }
            periodSeconds: 10
            failureThreshold: 90           # jusqu'à 15 min pour charger le modèle
          readinessProbe:
            httpGet: { path: /health, port: 8000 }
            periodSeconds: 10
          volumeMounts:
            - { name: hf-cache, mountPath: /root/.cache/huggingface }
            - { name: shm, mountPath: /dev/shm }
      volumes:
        - name: hf-cache
          persistentVolumeClaim: { claimName: hf-cache }
        - name: shm
          emptyDir: { medium: Memory, sizeLimit: 8Gi }
---
apiVersion: v1
kind: Service
metadata: { name: vllm-qwen3 }
spec:
  selector: { app: vllm-qwen3 }
  ports: [{ port: 80, targetPort: 8000 }]
---
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata: { name: vllm-qwen3 }
spec:
  scaleTargetRef: { name: vllm-qwen3 }
  minReplicaCount: 1          # 0 possible hors heures ouvrées, au prix d'un démarrage à froid
  maxReplicaCount: 4
  cooldownPeriod: 900         # ne pas détruire un pod coûteux à charger au moindre creux
  triggers:
    - type: prometheus
      metadata:
        serverAddress: http://prometheus.monitoring.svc:9090
        query: sum(vllm:num_requests_waiting{model_name="qwen3-8b"})
        threshold: "5"        # un pod de plus par tranche de 5 requêtes en attente
```

Vérifiez le nom exact des métriques de votre version de vLLM (`curl /metrics`, voir L142) avant de brancher la requête Prometheus. Autres signaux pertinents : l'occupation du KV cache et le TTFT p95.

> ⚠️ **Piège fréquent** — Autoscaler sur l'utilisation GPU. Un GPU qui sert un LLM affiche souvent un taux d'utilisation élevé dès la première requête : l'autoscaler ajoute des pods inutiles, ou au contraire ne réagit pas quand la file s'allonge. Utilisez la file d'attente et la latence.

```quiz
{
  "q": "Mise en situation : votre autoscaler ajoute un pod vLLM toutes les dix minutes alors que la file d'attente est vide. Quelle est la cause la plus probable ?",
  "options": ["Il suit l'usage GPU, élevé dès 1 requête", "Le `cooldownPeriod` est trop long", "La `startupProbe` est trop généreuse", "Le prefix caching est activé"],
  "answer": 0,
  "explanation": "Un GPU qui sert un LLM paraît occupé dès la première requête : ce n'est pas un bon signal de charge. Déclenchez l'autoscaling sur `num_requests_waiting` ou sur le TTFT p95."
}
```

```mission
{
  "title": "Déclarer un GPU dans un pod Kubernetes",
  "url": "https://kubernetes.io/docs/tasks/manage-gpus/scheduling-gpus/",
  "steps": ["Ouvrez la page « Schedule GPUs » de la documentation Kubernetes", "Repérez l'exemple de pod qui demande un GPU", "Lisez la remarque sur l'endroit où le GPU doit être déclaré (requests ou limits)"],
  "question": "Dans quelle section des ressources d'un conteneur faut-il déclarer `nvidia.com/gpu`, et peut-on partager un GPU entier entre deux conteneurs par ce mécanisme ?",
  "hint": "Comparez avec la ligne `resources:` du manifeste `vllm-k8s.yaml` ci-dessus.",
  "answer": "Dans `limits` (si `requests` est donné, il doit être égal à `limits` ; `requests` seul est refusé). La page ne traite plus du partage : un GPU s'y demande en nombre entier, et partager un GPU (time-slicing, MIG) relève du plugin du fabricant (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

Pour aller plus loin, des projets spécialisés ajoutent un routage conscient du cache de préfixes et la désagrégation prefill/decode (par exemple la *production stack* de vLLM ou KServe) : utiles au-delà de quelques GPU, superflus pour une PME.

## 🧪 Exercice pratique

**Consigne.** Une mutuelle régionale veut un assistant pour 400 conseillers : pointe à 3 requêtes/s, entrée 4 000 tokens (dont 3 000 de préfixe commun), sortie 250 tokens, 22 jours ouvrés, 30 requêtes par conseiller et par jour, données de santé, SLO TTFT p95 < 3 s et TPOT p95 < 70 ms.
1. Appliquez la méthode en 4 étapes avec Qwen3-8B-AWQ, puis avec un modèle de 27B en 4 bits (poids ≈ 16 Go, KV à calculer depuis son `config.json`). Pour $D$, mesurez sur un GPU loué ou utilisez l'hypothèse 900 tokens/s (8B) et 350 tokens/s (27B) sur L40S.
2. Calculez le coût mensuel de trois options d'hébergement et de trois API.
3. Recommandez une architecture en 10 lignes en tenant compte des données de santé.

**Critères de réussite.** Hypothèses écrites et datées ; calculs de $L$, VRAM et $N_{\text{GPU}}$ justes ; tableau de coûts sur le même volume mensuel ; la recommandation traite la question de l'hébergement des données de santé (hébergeur certifié HDS à vérifier) et la redondance.

<details><summary>Pistes de corrigé</summary>

Volume : 400 × 30 × 22 = 264 000 requêtes, soit 1 056 M tokens en entrée et 66 M en sortie. Besoin en sortie : 3 × 250 = 750 tokens/s. Avec le 8B : $\lceil 750 / 630 \rceil$ = 2 L40S (+1 de redondance). Avec le 27B : $\lceil 750 / 245 \rceil$ = 4 L40S. API Claude Haiku 5.5 : 105,6 + 33 = 138,60 $ ; Sonnet 5.5 : 2 112 + 660 = 2 772 $ (beaucoup moins avec le cache). Les données de santé imposent un hébergeur certifié HDS ou des garanties contractuelles fortes, ce qui oriente vers un cloud français certifié avec 3 GPU, et une API uniquement pour des tâches sans donnée personnelle.
</details>

## ✅ Auto-évaluation express
1. Que donne la loi de Little pour $\lambda$ = 2 requêtes/s et $W$ = 12 s ?
2. Pourquoi viser un taux d'utilisation de 0,6 à 0,7 et non 1 ?
3. Pourquoi l'utilisation CPU ou GPU est-elle un mauvais signal d'autoscaling pour un serveur LLM ?

*Réponses : 1. $L$ = 24 requêtes simultanées. 2. Parce que la latence explose quand un système en file d'attente approche la saturation ; la marge absorbe les pics. 3. Le GPU paraît occupé dès la première requête et le CPU ne reflète pas la charge ; la file d'attente et la latence mesurent directement ce que vivent les utilisateurs.*

## 📚 Pour aller plus loin
- [Scaleway — Tarifs GPU](https://www.scaleway.com/en/pricing/gpu) 🇬🇧 et [OVHcloud — Prix Public Cloud](https://ovhcloud.com/en/public-cloud/prices) 🇬🇧 — prix à relever le jour de votre devis.
- [Anthropic — Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧, [OpenAI — Pricing](https://developers.openai.com/api/docs/pricing) 🇬🇧, [Mistral — Pricing](https://docs.mistral.ai/inference/pricing) 🇬🇧 — grilles officielles des API.
- [Kubernetes — Schedule GPUs](https://kubernetes.io/docs/tasks/manage-gpus/scheduling-gpus/) 🇬🇧 — device plugin et ressources `nvidia.com/gpu`.
- [KEDA — documentation](https://keda.sh/docs/) 🇬🇧 — autoscaling sur métriques Prometheus.
- [IntuitionLabs — DGX Spark review](https://intuitionlabs.ai/articles/nvidia-dgx-spark-review) 🇬🇧 — capacités et vitesses mesurées.
- [Full Stack Deep Learning — cours 2022](https://fullstackdeeplearning.com/course/) 🇬🇧 — séance « Deployment », source d'inspiration.

> 🗺️ **Et maintenant ?** — Votre service tourne ; la leçon L144 vous apprend à le garder en bonne santé dans la durée : versionner modèles et prompts, surveiller la qualité et détecter la dérive avant vos utilisateurs.
