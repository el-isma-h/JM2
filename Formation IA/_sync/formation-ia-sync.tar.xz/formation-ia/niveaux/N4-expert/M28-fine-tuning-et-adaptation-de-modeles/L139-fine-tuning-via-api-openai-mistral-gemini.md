---
id: L139
module: M28
level: N4
title: "Fine-tuning via API : OpenAI, Mistral, Gemini"
minutes: 60
objectives:
  - "Décrire l'état des offres de fine-tuning hébergé d'OpenAI, de Mistral et de Google en novembre 2026"
  - "Distinguer fine-tuning supervisé, DPO et reinforcement fine-tuning tels que proposés par les API"
  - "Préparer, lancer et suivre un job de fine-tuning via SDK Python en lisant les clés depuis l'environnement"
  - "Comparer le coût total et le risque fournisseur d'un fine-tuning API et d'un fine-tuning local LoRA"
skills: ["C4.4"]
sources:
  - { title: "OpenAI — Model optimization", url: "https://developers.openai.com/api/docs/guides/model-optimization", lang: "en" }
  - { title: "OpenAI — Supervised fine-tuning", url: "https://developers.openai.com/api/docs/guides/supervised-fine-tuning", lang: "en" }
  - { title: "OpenAI — Direct preference optimization", url: "https://developers.openai.com/api/docs/guides/direct-preference-optimization", lang: "en" }
  - { title: "OpenAI — Reinforcement fine-tuning", url: "https://developers.openai.com/api/docs/guides/reinforcement-fine-tuning", lang: "en" }
  - { title: "Mistral — AI Studio (documentation)", url: "https://docs.mistral.ai/studio", lang: "en" }
  - { title: "Mistral — Tarifs", url: "https://docs.mistral.ai/inference/pricing", lang: "en" }
  - { title: "Google — Gemini API, modèles", url: "https://ai.google.dev/gemini-api/docs/models", lang: "en" }
---

# Fine-tuning via API : OpenAI, Mistral, Gemini

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 28

## 🎯 Ce que vous saurez faire
- Dire, pour chacun des trois grands fournisseurs, ce qui est réellement disponible en novembre 2026 et ce qui doit être vérifié.
- Expliquer la différence entre SFT, DPO et *reinforcement fine-tuning* (RFT) côté API.
- Écrire le script complet d'un job hébergé : préparation du fichier, téléversement, lancement, suivi, appel du modèle obtenu.
- Arbitrer entre fine-tuning API et fine-tuning local avec un calcul de coût total et une analyse du risque fournisseur.

> 🧭 **En clair** — Le fine-tuning « via API », c'est comme confier son costume à un tailleur qui garde le patron : vous envoyez vos exemples, le fournisseur ajuste le modèle chez lui puis vous le loue. Pratique… tant que la boutique reste ouverte. Or en 2026, plusieurs boutiques ferment ou réduisent leur offre : OpenAI n'acceptera plus aucun nouveau job de fine-tuning à partir du 6 janvier 2027. Cette leçon vous apprend à vérifier ce qui est réellement disponible, à écrire un job quand c'est encore possible, et surtout à garder chez vous ce qui a de la valeur : vos données et vos évaluations, qui permettent de refaire le costume ailleurs.

## 1. Le paysage en novembre 2026 : un marché qui se contracte

Le fine-tuning hébergé (« vous envoyez un fichier, le fournisseur entraîne et sert le modèle ») a connu son âge d'or entre 2023 et 2025 : GPT-3.5 puis GPT-4o et GPT-4.1 fine-tunables, offre de Mistral sur La Plateforme, réglage des modèles Gemini. Fin 2026, le tableau a changé.

| Fournisseur | État constaté (nov. 2026) | Ce que vous devez vérifier |
|---|---|---|
| **OpenAI** | La plateforme de fine-tuning **est en cours d'arrêt** : les nouveaux comptes n'y ont plus accès. Calendrier (page Deprecations, annonce du 7 mai 2026) : depuis le 7/05/2026, plus de nouveaux clients ; depuis le 2/07/2026, organisations sans inférence sur un modèle fine-tuné depuis 60 jours exclues ; **le 6/01/2027, plus aucun nouveau job** ; l'inférence sur les modèles déjà fine-tunés continue jusqu'à la dépréciation du modèle de base. Sur la page tarifs (vérifié le 5 nov. 2026), seuls `gpt-4.1-2025-04-14` et `gpt-4.1-mini-2025-04-14` restent tarifés, **au million de tokens** : entraînement 25 $ et 5 $, inférence 3 $ / 0,75 $ / 12 $ et 0,80 $ / 0,20 $ / 3,20 $ (entrée / entrée en cache / sortie). Les guides SFT, DPO et RFT restent en ligne. | Si votre organisation a encore accès, quelles méthodes et quels modèles sont ouverts sur *votre* compte ; la date de fin de service des modèles déjà entraînés |
| **Mistral AI** | Modèles principaux : Mistral Large 4, Mistral Small 4 (Apache 2.0), Ministral 3 14B/8B/3B (Apache 2.0). La page tarifs consultée **ne liste pas** de ligne fine-tuning ; les pages de documentation fine-tuning n'ont pas pu être vérifiées. | L'existence et le prix du fine-tuning dans AI Studio (ex-La Plateforme) |
| **Google** | La page Modèles de l'API Gemini (`ai.google.dev`) présente `gemini-4-argon`, `gemini-3.8-flash` et leurs variantes ; **aucune** fonction de réglage n'y est décrite. Historiquement, le réglage supervisé des modèles Gemini relève de **Vertex AI** (Google Cloud). | Les modèles Gemini réglables sur Vertex AI et leur tarification |

Ce reflux a une explication simple : les modèles de pointe sont devenus si bons en suivi d'instructions, avec des contextes d'un million de tokens et le cache de prompt, que la majorité des clients n'ont plus besoin de fine-tuning ; et l'entretien de milliers de modèles personnalisés coûte cher aux fournisseurs. En parallèle, des modèles ouverts Apache 2.0 de qualité (Gemma 4, Qwen3.8-27B, Mistral Small 4, gpt-oss) rendent le fine-tuning **local** très compétitif.

> ⚠️ **Piège fréquent** — Bâtir un produit sur un modèle fine-tuné hébergé sans clause de sortie. Si le fournisseur retire la plateforme ou le modèle de base, votre adaptateur disparaît avec lui : vous ne récupérez jamais les poids. Conservez toujours vos données d'entraînement et vos évaluations, qui sont, elles, portables.

```quiz
{
  "q": "D'après la page Deprecations d'OpenAI, à partir de quelle date plus aucun client ne pourra créer de nouveau job de fine-tuning ?",
  "options": [
    "7 mai 2026",
    "2 juillet 2026",
    "6 janvier 2027",
    "31 décembre 2027"
  ],
  "answer": 2,
  "explanation": "Le 7/05/2026 ferme l'accès aux nouveaux clients, le 2/07/2026 aux organisations inactives depuis 60 jours, et le 6/01/2027 à tout le monde. L'inférence sur les modèles déjà entraînés continue jusqu'à la dépréciation du modèle de base."
}
```

## 2. Les trois méthodes proposées par les API

Les guides OpenAI (toujours en ligne en nov. 2026) décrivent trois méthodes ; elles correspondent à ce que vous avez vu en L133 et L137.

| Méthode | Données | Ce qu'elle optimise | Quand l'utiliser |
|---|---|---|---|
| **SFT** (*supervised fine-tuning*) | Conversations `messages` avec la réponse idéale | Imiter les réponses fournies | Format, ton, classification |
| **DPO** | Paires `preferred` / `non_preferred` | Préférer une réponse à une autre | Affiner le style après un SFT |
| **RFT** (*reinforcement fine-tuning*) | Consignes + un **grader** (fonction ou modèle de notation) | Maximiser un score de récompense | Tâches à réponse vérifiable (extraction exacte, raisonnement expert) ; facturé à l'heure |

Le RFT est l'héritier pratique des méthodes de renforcement à récompense vérifiable (RLVR) vues en L133 : au lieu de fournir les bonnes réponses, vous fournissez **un correcteur**. Les tokens consommés par le modèle correcteur sont facturés au tarif de ce modèle (page Pricing, vérifié le 5 nov. 2026).

> 💡 **Autrement dit** — SFT : « voici la bonne copie, imite-la ». DPO : « entre ces deux copies, préfère celle-ci ». RFT : « voici le barème, débrouille-toi pour obtenir la meilleure note ».

```quiz
{
  "q": "Vous voulez qu'un modèle extraie le montant TTC de factures, et vous pouvez vérifier chaque réponse automatiquement. Quelle méthode API correspond le mieux ?",
  "options": [
    "DPO sur des paires de réponses",
    "RFT avec un grader qui vérifie le montant",
    "SFT sans aucune donnée",
    "Aucune : il suffit d'allonger le contexte"
  ],
  "answer": 1,
  "explanation": "Une réponse vérifiable par programme est le terrain idéal du RFT : vous fournissez le correcteur plutôt que les réponses idéales."
}
```

## 3. OpenAI : le script d'un job (comptes ayant encore accès)

Le format SFT attendu est un JSONL de conversations. Le script ci-dessous vérifie le fichier, le téléverse, lance le job, suit sa progression et appelle le modèle obtenu. Il lit la clé dans `OPENAI_API_KEY` et le modèle de base dans `FT_BASE_MODEL` : renseignez un modèle **listé comme fine-tunable sur votre compte** dans la documentation.

```python
"""openai_ft.py — Job de fine-tuning hébergé OpenAI (SFT). pip install openai
Variables : OPENAI_API_KEY (obligatoire), FT_BASE_MODEL (modèle fine-tunable sur votre compte), TRAIN_FILE.
"""
import json
import os
import sys
import time

from openai import OpenAI

client = OpenAI()  # lit OPENAI_API_KEY dans l'environnement
BASE = os.environ.get("FT_BASE_MODEL")
TRAIN = os.environ.get("TRAIN_FILE", "openai_train.jsonl")
if not BASE:
    sys.exit("Définissez FT_BASE_MODEL avec un modèle fine-tunable listé sur votre compte.")

# 1) Contrôle local du format : chaque ligne = {"messages": [...]} terminée par une réponse assistant
with open(TRAIN, encoding="utf-8") as f:
    for i, ligne in enumerate(f, 1):
        msgs = json.loads(ligne)["messages"]
        assert msgs[-1]["role"] == "assistant", f"ligne {i} : le dernier message doit venir de l'assistant"

# 2) Téléversement puis création du job
fichier = client.files.create(file=open(TRAIN, "rb"), purpose="fine-tune")
job = client.fine_tuning.jobs.create(
    model=BASE,
    training_file=fichier.id,
    suffix="sav-delorme",
    method={"type": "supervised", "supervised": {"hyperparameters": {"n_epochs": 2}}},
)
print("Job créé :", job.id)

# 3) Suivi
while True:
    job = client.fine_tuning.jobs.retrieve(job.id)
    print(time.strftime("%H:%M:%S"), job.status)
    if job.status in {"succeeded", "failed", "cancelled"}:
        break
    time.sleep(60)

for ev in client.fine_tuning.jobs.list_events(fine_tuning_job_id=job.id, limit=10).data:
    print("  ·", ev.message)

# 4) Appel du modèle obtenu (Responses API)
if job.status == "succeeded":
    rep = client.responses.create(model=job.fine_tuned_model, input="Mon colis n'est jamais arrivé.")
    print(rep.output_text)
```

Pour le DPO, le guide décrit des lignes contenant `input`, `preferred_output` et `non_preferred_output`, et une méthode `{"type": "dpo", "dpo": {"hyperparameters": {"beta": 0.1}}}`. Pour le RFT, il faut définir un *grader*. Reportez-vous aux guides officiels liés ci-dessous : les noms de champs et les modèles éligibles évoluent.

> 🔗 **Documentation officielle** — [Model optimization](https://developers.openai.com/api/docs/guides/model-optimization) · [Supervised fine-tuning](https://developers.openai.com/api/docs/guides/supervised-fine-tuning) · [DPO](https://developers.openai.com/api/docs/guides/direct-preference-optimization) · [Reinforcement fine-tuning](https://developers.openai.com/api/docs/guides/reinforcement-fine-tuning)

```mission
{
  "title": "Le calendrier d'arrêt, à la source",
  "url": "https://developers.openai.com/api/docs/deprecations",
  "steps": [
    "Ouvrez la page Deprecations de la documentation OpenAI",
    "Cherchez l'annonce consacrée au fine-tuning (7 mai 2026)",
    "Lisez ce qu'il advient des modèles déjà fine-tunés"
  ],
  "question": "Que deviennent les modèles déjà fine-tunés après le 6 janvier 2027, et quelle condition excluait déjà certaines organisations depuis le 2 juillet 2026 ?",
  "hint": "Deux réponses : une sur l'inférence, une sur une durée de 60 jours.",
  "answer": "L'inférence sur les modèles déjà fine-tunés reste possible jusqu'à la dépréciation de leur modèle de base ; depuis le 2/07/2026, les organisations sans inférence sur un modèle fine-tuné au cours des 60 derniers jours ne peuvent plus créer de job (page consultée le 5 nov. 2026 ; calendrier susceptible d'évoluer) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Mistral : la voie souveraine, plutôt en local

Mistral a longtemps proposé un fine-tuning hébergé sur La Plateforme (aujourd'hui **AI Studio**), avec le SDK `mistralai`. La page tarifs de novembre 2026 ne mentionnant pas de ligne fine-tuning, traitez l'exemple suivant comme un **modèle de code à valider** contre la documentation AI Studio en vigueur avant usage.

```python
"""mistral_ft.py — Job de fine-tuning hébergé Mistral (À VÉRIFIER : disponibilité et noms de modèles dans AI Studio).
pip install mistralai ; variable : MISTRAL_API_KEY ; FT_BASE_MODEL = modèle éligible indiqué par la doc.
"""
import os
import sys
import time

from mistralai import Mistral

client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
BASE = os.environ.get("FT_BASE_MODEL") or sys.exit("Définissez FT_BASE_MODEL (modèle fine-tunable listé par AI Studio).")

with open("train.jsonl", "rb") as f:  # même format "messages" que ci-dessus
    fichier = client.files.upload(file={"file_name": "train.jsonl", "content": f})

job = client.fine_tuning.jobs.create(
    model=BASE,
    training_files=[{"file_id": fichier.id, "weight": 1}],
    hyperparameters={"training_steps": 100, "learning_rate": 1e-4},
    suffix="sav-delorme",
    auto_start=True,
)
while job.status not in {"SUCCESS", "FAILED", "CANCELLED"}:
    time.sleep(60)
    job = client.fine_tuning.jobs.get(job_id=job.id)
    print(job.status)

if job.status == "SUCCESS":
    rep = client.chat.complete(model=job.fine_tuned_model,
                               messages=[{"role": "user", "content": "Mon colis n'est jamais arrivé."}])
    print(rep.choices[0].message.content)
```

En pratique, l'argument souverain de Mistral joue **encore plus fort en local** : Mistral Small 4 (119B dont 6B actifs) et Ministral 3 (3B, 8B, 14B) sont sous licence Apache 2.0. Un QLoRA de Ministral 3 8B avec le script de L136, servi sur un GPU Scaleway ou OVHcloud en France, garde données et poids sous votre contrôle. Côté inférence API, les tarifs Mistral restent parmi les plus bas (nov. 2026, par million de tokens entrée/sortie) : Mistral Small 4 à 0,15 $/0,60 $, Ministral 3 8B à 0,15 $.

## 5. Google : Gemini sur Vertex AI, Gemma partout ailleurs

L'API Gemini grand public (`ai.google.dev`) se concentre en novembre 2026 sur l'inférence : `gemini-4-argon` (2 $/10 $ par million de tokens, hausse annoncée à 4 $/20 $ au 1er décembre 2026) et `gemini-3.8-flash` (0,75 $/3,75 $). Pour **régler** un modèle Gemini, la voie historique est **Vertex AI** sur Google Cloud (réglage supervisé à partir d'un fichier JSONL déposé dans Cloud Storage). Le SDK unifié `google-genai` expose une interface de réglage en mode Vertex ; à titre indicatif, et **à valider** contre la documentation Vertex AI (modèles réglables, régions, prix) :

```python
"""gemini_tuning.py — Réglage supervisé via Vertex AI avec le SDK google-genai (À VÉRIFIER : modèles éligibles).
pip install google-genai ; authentification : gcloud auth application-default login
Variables : GOOGLE_CLOUD_PROJECT, GOOGLE_CLOUD_LOCATION (ex. europe-west1), TUNING_BASE_MODEL, TRAIN_GCS_URI (gs://...)
"""
import os
import time

from google import genai
from google.genai import types

client = genai.Client(vertexai=True,
                      project=os.environ["GOOGLE_CLOUD_PROJECT"],
                      location=os.environ.get("GOOGLE_CLOUD_LOCATION", "europe-west1"))

job = client.tunings.tune(
    base_model=os.environ["TUNING_BASE_MODEL"],
    training_dataset=types.TuningDataset(gcs_uri=os.environ["TRAIN_GCS_URI"]),
    config=types.CreateTuningJobConfig(epoch_count=2, tuned_model_display_name="sav-delorme"),
)
while not job.has_ended:
    time.sleep(60)
    job = client.tunings.get(name=job.name)
    print(job.state)

if job.has_succeeded:
    rep = client.models.generate_content(model=job.tuned_model.endpoint, contents="Mon colis n'est jamais arrivé.")
    print(rep.text)
```

L'alternative la plus simple dans l'écosystème Google reste **Gemma 4** (Apache 2.0, tailles E2B/E4B pour l'embarqué jusqu'à 26B-A4B et 31B) : fine-tuning LoRA local avec TRL ou Unsloth, comme dans le projet L140.

```quiz
{
  "type": "vrai_faux",
  "q": "Quand OpenAI ferme la création de jobs de fine-tuning, les modèles déjà fine-tunés cessent immédiatement de répondre.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : seule la création de nouveaux jobs s'arrête. L'inférence continue jusqu'à la dépréciation du modèle de base, date à surveiller pour préparer votre stratégie de sortie."
}
```

## 6. API ou local : le calcul de décision

Prenons 2 000 exemples de 600 tokens, 3 époques (3,6 M de tokens d'entraînement) et 500 000 requêtes par an de 800 tokens (500 en entrée, 300 en sortie).

| Poste | Fine-tuning API (`gpt-4.1-mini`, SFT) | QLoRA local 8B sur GPU loué | Prompt seul sur API (Mistral Small 4) |
|---|---|---|---|
| Entraînement | 3,6 M tokens × 5 $ ≈ 18 $ | ~1 h de RTX 4090 à 0,34 $/h ≈ 0,34 $ | 0 $ |
| Inférence annuelle | 250 M tokens entrée × 0,80 $ + 150 M sortie × 3,20 $ ≈ **680 $** | GPU dédié L4 Scaleway 0,75 €/h × 8 760 h ≈ **6 570 €** (ou serveur interne déjà amorti) | 250 M × 0,15 $ + 150 M × 0,60 $ ≈ **128 $** |
| Propriété des poids | Non | **Oui** | Non |
| Risque fournisseur | Élevé (plateforme en cours d'arrêt) | Faible | Moyen |

Trois enseignements. D'abord, un **prompt bien fait sur un petit modèle API bon marché** bat souvent tout le monde sur le coût : c'est pourquoi l'arbre de L135 commence par lui. Ensuite, le local n'est rentable que si le GPU est mutualisé ou si la confidentialité l'impose ; un GPU allumé 24 h/24 pour 1 400 requêtes par jour est surdimensionné, une machine interne ou un service à la demande change le calcul. Enfin, le fine-tuning API n'a de sens que pour une tâche où il apporte un gain mesuré que le prompt ne donne pas, et avec une stratégie de sortie.

> 💡 **À retenir** — Ce que vous possédez vraiment dans un projet de fine-tuning, ce sont vos **données** et vos **évaluations**. Avec elles, vous pouvez ré-entraîner n'importe quel modèle en quelques heures ; sans elles, chaque changement de fournisseur repart de zéro.

> 🎮 **Défi** — Reprenez le tableau avec 5 millions de requêtes par an. Quelle option devient la plus intéressante si les données sont confidentielles ? *Piste : le local, avec un GPU désormais bien utilisé ; l'API Mistral reste la moins chère si les données peuvent sortir (vérifiez alors l'inférence régionale UE de Mistral).*

```mission
{
  "title": "Ce que coûte encore le fine-tuning OpenAI",
  "url": "https://developers.openai.com/api/docs/pricing",
  "steps": [
    "Ouvrez la page Pricing de la documentation OpenAI",
    "Descendez jusqu'à la section Fine-tuning",
    "Relevez les modèles encore tarifés, le prix de l'entraînement et ceux de l'inférence"
  ],
  "question": "Quels modèles restent tarifés pour le fine-tuning, combien coûte l'entraînement, et quels sont les prix d'inférence des modèles obtenus ?",
  "hint": "Le prix d'entraînement est au million de tokens, pas à l'heure.",
  "answer": "`gpt-4.1-2025-04-14` : entraînement 25 $ par million de tokens, inférence 3 $ (entrée), 0,75 $ (entrée en cache) et 12 $ (sortie) ; `gpt-4.1-mini-2025-04-14` : 5 $, puis 0,80 $ / 0,20 $ / 3,20 $ par million de tokens (tarif Standard (vérifié le 5 nov. 2026) ; la page peut changer à l'approche du 6 janvier 2027).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Rédigez une note de décision d'une page pour le comité de direction d'un cabinet d'expertise comptable (35 collaborateurs) qui souhaite un assistant de rédaction de lettres de mission :
1. Vérifiez sur les pages officielles (liens de cette leçon) l'état du jour des offres OpenAI, Mistral et Google et datez vos constats.
2. Comparez trois options : prompt seul sur API, fine-tuning hébergé, QLoRA local d'un modèle Apache 2.0.
3. Chiffrez entraînement + inférence sur un an pour 20 000 lettres.
4. Recommandez une option et décrivez la stratégie de sortie.

**Critères de réussite.** Chaque affirmation sur une offre est datée et sourcée ; le calcul de coût est explicite ; la recommandation tient compte du secret professionnel ; la stratégie de sortie mentionne la conservation des données et des évaluations.

<details><summary>Pistes de corrigé</summary>

20 000 lettres × ~1 500 tokens = 30 M de tokens par an : quelques dizaines de dollars en prompt seul sur un modèle API économique ; le fine-tuning n'est justifié que si le gabarit maison n'est pas tenu par le prompt. Le secret professionnel oriente vers un hébergement UE avec engagement de non-réutilisation des données, ou vers un QLoRA local de Ministral 3 8B ou Gemma 4 servi en interne. Stratégie de sortie : jeu d'entraînement versionné, évaluation figée, scripts de L136 prêts à relancer sur un autre modèle de base.
</details>

## ✅ Auto-évaluation express
1. Quel est l'état de la plateforme de fine-tuning d'OpenAI pour un nouveau compte en novembre 2026 ?
2. Que fournit-on à un *reinforcement fine-tuning* à la place des réponses idéales ?
3. Pourquoi les données d'entraînement et les évaluations sont-elles l'actif principal d'un projet de fine-tuning ?

*Réponses : 1. Elle est en cours d'arrêt et n'est plus accessible aux nouveaux comptes. 2. Un grader (fonction ou modèle) qui note les réponses. 3. Parce qu'elles sont portables : elles permettent de ré-entraîner n'importe quel modèle de base, contrairement aux poids hébergés chez un fournisseur.*

## 📚 Pour aller plus loin
- [OpenAI — Model optimization](https://developers.openai.com/api/docs/guides/model-optimization) 🇬🇧 — évaluer, optimiser le prompt, puis entraîner.
- [OpenAI — Reinforcement fine-tuning](https://developers.openai.com/api/docs/guides/reinforcement-fine-tuning) 🇬🇧 — graders et tâches à récompense vérifiable.
- [Mistral — AI Studio](https://docs.mistral.ai/studio) 🇬🇧 — documentation de la plateforme (vérifier la section fine-tuning).
- [Mistral — Tarifs](https://docs.mistral.ai/inference/pricing) 🇬🇧 — grille d'inférence à jour.
- [Gemini API — Modèles](https://ai.google.dev/gemini-api/docs/models) 🇬🇧 et [Tarifs](https://ai.google.dev/gemini-api/docs/pricing) 🇬🇧 — catalogue et hausses annoncées.

> 🗺️ **Et maintenant ?** — Place à la pratique de bout en bout : dans le projet L140, vous spécialisez vous-même un modèle ouvert, de la donnée jusqu'au service par Ollama.
