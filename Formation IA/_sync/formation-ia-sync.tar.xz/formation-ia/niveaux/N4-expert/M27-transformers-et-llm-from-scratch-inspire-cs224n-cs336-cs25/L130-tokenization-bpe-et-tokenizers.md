---
id: L130
module: M27
level: N4
title: "Tokenization : BPE et tokenizers"
minutes: 60
objectives:
  - "Expliquer pourquoi les LLM travaillent sur des sous-mots et comparer tokenisation par caractères, mots et sous-mots"
  - "Implémenter un tokenizer BPE au niveau des octets (entraînement, encodage, décodage) en Python pur"
  - "Utiliser tiktoken et la bibliothèque Hugging Face tokenizers pour encoder, entraîner et inspecter un vocabulaire"
  - "Évaluer l'impact de la tokenisation sur le coût, le contexte et la qualité pour des textes en français"
skills: ["C4.3"]
sources:
  - { title: "Sennrich, Haddow, Birch (2016) — Neural Machine Translation of Rare Words with Subword Units", url: "https://arxiv.org/abs/1508.07909", lang: "en" }
  - { title: "Kudo & Richardson (2018) — SentencePiece", url: "https://arxiv.org/abs/1808.06226", lang: "en" }
  - { title: "Andrej Karpathy — Let's build the GPT Tokenizer", url: "https://youtu.be/zduSFxRajkE", lang: "en" }
  - { title: "OpenAI — tiktoken (dépôt officiel)", url: "https://github.com/openai/tiktoken", lang: "en" }
  - { title: "Hugging Face — Tokenizers documentation", url: "https://huggingface.co/docs/tokenizers/index", lang: "en" }
  - { title: "Stanford CS336 Spring 2026 — séance 1 Overview, tokenization ; devoir A1", url: "https://cs336.stanford.edu/", lang: "en" }
---

# Tokenization : BPE et tokenizers

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 27

## 🎯 Ce que vous saurez faire
- Expliquer ce qu'est un **token**, pourquoi les modèles n'utilisent ni des caractères ni des mots entiers, et ce que coûte ce choix.
- Écrire de zéro un tokenizer **BPE** (*Byte Pair Encoding*) au niveau des octets, capable de traiter n'importe quel texte UTF-8, accents et emojis compris.
- Manipuler les deux outils industriels de référence : **tiktoken** (OpenAI) et **Hugging Face tokenizers** (Rust).
- Mesurer la « taxe » que paie le français par rapport à l'anglais, et en tirer des conséquences concrètes sur le coût d'une API et la taille de contexte utile.

> 🧭 **En clair** — Un modèle ne lit ni des lettres ni des mots entiers : il lit des « briques » numérotées, les tokens. Pour fabriquer ces briques, le BPE parcourt des montagnes de textes et colle ensemble les lettres qui apparaissent le plus souvent côte à côte : « e » + « s » devient la brique « es », puis « es » + espace, puis « les »… C'est comme fabriquer des briques Lego toutes prêtes à partir des lettres les plus souvent collées ensemble. Les mots fréquents deviennent une seule brique, les mots rares se construisent avec plusieurs petites briques, et rien n'est jamais impossible à écrire puisqu'on garde les briques de base (les 256 octets). Revers de la médaille : ces briques ont surtout été fabriquées avec de l'anglais, donc un texte français demande plus de briques… et coûte plus cher à l'API.

Andrej Karpathy ouvre sa vidéo « Let's build the GPT Tokenizer » par une liste de bizarreries des LLM — difficulté à épeler un mot, à inverser une chaîne, à compter des lettres, arithmétique fragile, performances moindres dans les langues non anglaises — et conclut qu'une bonne partie d'entre elles vient… de la tokenisation. Le cours Stanford CS336 en fait d'ailleurs la toute première séance et la première partie du devoir A1 : implémenter un tokenizer BPE. Nous suivons la même démarche, avec un code original et des exemples en français.

## 1. Caractères, mots ou sous-mots ?

Un réseau de neurones ne lit pas du texte : il lit des **entiers**, chacun indexant une ligne de la matrice d'embeddings (L129). La tokenisation est la fonction qui transforme une chaîne en liste d'entiers, et la détokenisation l'opération inverse. Trois stratégies sont possibles.

| Stratégie | Vocabulaire | Longueur des séquences | Mots inconnus | Verdict |
|---|---|---|---|---|
| Caractères (ou octets) | minuscule (~100 à 256) | très longues | aucun | contexte gaspillé, attention quadratique coûteuse (L128) |
| Mots entiers | énorme (des centaines de milliers) | courtes | fréquents (« facturation », néologismes, fautes de frappe, noms propres) | inutilisable en pratique |
| **Sous-mots** (BPE, Unigram, WordPiece) | 30 000 à ~260 000 | intermédiaires | aucun si l'on part des octets | le compromis adopté par tous les LLM |

L'idée des sous-mots : les mots fréquents (« les », « entreprise ») deviennent un seul token, les mots rares sont découpés en morceaux réutilisables (« anti » + « constitution » + « nellement »). Le modèle conserve la capacité d'écrire **n'importe quoi**, tout en gardant des séquences raisonnablement courtes.

> 💡 **À retenir** — La taille du vocabulaire est un arbitrage : plus elle est grande, plus les séquences sont courtes (contexte utile et vitesse accrus), mais plus les matrices d'embedding et de sortie ($V \times d$) sont lourdes et plus chaque token rare est vu rarement à l'entraînement.

## 2. Byte Pair Encoding : une idée de compression recyclée

Le BPE est à l'origine un algorithme de **compression de données** décrit par Philip Gage en 1994 : on remplace répétitivement la paire d'octets la plus fréquente par un nouveau symbole. En 2016, Rico Sennrich, Barry Haddow et Alexandra Birch l'adaptent à la traduction automatique neuronale pour traiter les mots rares (arXiv 1508.07909). En 2019, GPT-2 introduit la variante **au niveau des octets** (*byte-level BPE*) : on part non plus des caractères mais des **256 valeurs d'octet** possibles. Conséquence : tout texte UTF-8, dans n'importe quelle langue, est représentable sans jamais produire de symbole « inconnu ».

L'algorithme d'entraînement tient en quatre lignes :

1. Encoder le corpus d'entraînement en octets UTF-8 : c'est une liste d'entiers entre 0 et 255.
2. Compter toutes les paires d'entiers adjacents.
3. Fusionner la paire la plus fréquente en un nouvel identifiant (256, puis 257, etc.) et l'enregistrer dans la table des fusions.
4. Recommencer jusqu'à atteindre la taille de vocabulaire visée.

```mermaid
flowchart LR
    A[Texte → octets 0 à 255] --> B[Compter les paires voisines]
    B --> C[Fusionner la paire la plus fréquente<br/>en un nouveau token 256, 257…]
    C --> D{Taille de vocabulaire<br/>atteinte ?}
    D -- Non --> B
    D -- Oui --> E[Table des fusions<br/>= le tokenizer entraîné]
```

> 💡 **Autrement dit** — Prenez le mot « lalala ». En octets : l, a, l, a, l, a. La paire la plus fréquente est « la » (trois fois) : elle devient la brique n° 256, et le mot s'écrit 256, 256, 256. Nouvelle paire la plus fréquente : (256, 256), qui devient la brique n° 257 (« lala »), et le mot s'écrit 257, 256. Six briques sont devenues deux : c'est cela, compresser.

L'**encodage** d'un nouveau texte rejoue les fusions **dans l'ordre où elles ont été apprises** ; le **décodage** concatène simplement les octets de chaque token. Le tokenizer est donc un objet **entraîné**, sur un corpus distinct de celui du modèle, et figé ensuite : changer de tokenizer impose de réentraîner le modèle.

```quiz
{
  "q": "Pendant l'encodage d'un nouveau texte, dans quel ordre le BPE applique-t-il les fusions ?",
  "options": [
    "Par ordre alphabétique des tokens",
    "De la fusion la plus longue à la plus courte",
    "Dans l'ordre où elles ont été apprises",
    "Au hasard, puis on garde le découpage le plus court"
  ],
  "answer": 2,
  "explanation": "Chaque fusion a été apprise sur un texte où les fusions précédentes étaient déjà appliquées : il faut les rejouer dans le même ordre pour retrouver les mêmes briques."
}
```

## 3. Implémentation minimale en Python pur

```python
# bpe_minimal.py — L130 : un tokenizer BPE au niveau des octets, en Python pur
from collections import Counter

def compter_paires(ids):
    return Counter(zip(ids, ids[1:]))

def fusionner(ids, paire, nouvel_id):
    """Remplace chaque occurrence de `paire` par `nouvel_id`."""
    sortie, i = [], 0
    while i < len(ids):
        if i < len(ids) - 1 and (ids[i], ids[i + 1]) == paire:
            sortie.append(nouvel_id)
            i += 2
        else:
            sortie.append(ids[i])
            i += 1
    return sortie

class BPE:
    def __init__(self):
        self.fusions = {}                                    # (a, b) -> nouvel id, dans l'ordre d'apprentissage
        self.vocab = {i: bytes([i]) for i in range(256)}     # 256 octets de base : aucun caractère inconnu

    def entrainer(self, texte: str, taille_vocab: int, verbose=False):
        ids = list(texte.encode("utf-8"))
        for nouvel_id in range(256, taille_vocab):
            paires = compter_paires(ids)
            if not paires:
                break
            paire, n = paires.most_common(1)[0]              # la paire la plus fréquente
            ids = fusionner(ids, paire, nouvel_id)
            self.fusions[paire] = nouvel_id
            self.vocab[nouvel_id] = self.vocab[paire[0]] + self.vocab[paire[1]]
            if verbose and nouvel_id < 266:
                print(f"fusion {nouvel_id}: {self.vocab[nouvel_id]!r} ({n} occurrences)")

    def encoder(self, texte: str):
        ids = list(texte.encode("utf-8"))
        while len(ids) >= 2:
            paires = compter_paires(ids)
            # on applique d'abord la fusion apprise le plus tôt (rang le plus faible)
            paire = min(paires, key=lambda p: self.fusions.get(p, float("inf")))
            if paire not in self.fusions:
                break
            ids = fusionner(ids, paire, self.fusions[paire])
        return ids

    def decoder(self, ids):
        return b"".join(self.vocab[i] for i in ids).decode("utf-8", errors="replace")

if __name__ == "__main__":
    corpus = (
        "Le cabinet comptable envoie les factures aux entreprises. "
        "Les entreprises règlent les factures à réception. "
        "La facturation électronique devient obligatoire pour les entreprises françaises. "
    ) * 20
    tok = BPE()
    tok.entrainer(corpus, taille_vocab=320, verbose=True)
    phrase = "Les factures électroniques des entreprises"
    ids = tok.encoder(phrase)
    print(f"\n{len(phrase.encode('utf-8'))} octets -> {len(ids)} tokens")
    print([tok.vocab[i].decode("utf-8", errors="replace") for i in ids])
    assert tok.decoder(ids) == phrase, "aller-retour cassé"
    print("Aller-retour encoder/décoder : OK")
    print("« é » en UTF-8 :", list("é".encode("utf-8")), "-> 2 octets avant toute fusion")
```

Sortie commentée. Les premières fusions apprises sont `'es'`, `'es '`, `'en'`, `'e '`, `'ent'`, puis (après `'ct'`, `'ur'`, `'ep'`, `'is'`) `'les '` : le BPE a « découvert » tout seul le pluriel et la terminaison verbale les plus fréquents du français. La phrase de test passe de 43 octets à 19 tokens, dont `'factur'` et `'entrepris'`. Observez aussi deux tokens affichés `'�'` : ce sont les **deux octets** de « é » (195 et 169), que notre petit vocabulaire n'a pas encore fusionnés. Un token n'est donc **pas** forcément un caractère valide ; il peut être une moitié de caractère. Le décodage global reste exact, car on concatène les octets avant de décoder l'UTF-8.

> ⚠️ **Piège fréquent** — Décoder les tokens **un par un** en streaming (par exemple pour afficher la réponse d'un modèle au fil de l'eau) et obtenir des `�` au milieu des mots accentués. La solution consiste à accumuler les octets et à ne décoder que des séquences UTF-8 complètes ; les SDK sérieux le font pour vous.

## 4. Ce que les vrais tokenizers ajoutent

Notre version capture l'essentiel, mais un tokenizer de production ajoute trois couches.

**La pré-tokenisation.** Avant le BPE, le texte est découpé par une expression régulière (lettres, chiffres, ponctuation, espaces) et les fusions ne franchissent jamais ces frontières. Sans cela, on verrait apparaître des tokens absurdes comme `"facture."` ou `"s de"`. Le GPT-2 rattache l'espace au mot suivant (`" factures"`), d'où le symbole `Ġ` que vous verrez dans les vocabulaires Hugging Face : c'est l'octet de l'espace, rendu visible. Les chiffres sont souvent découpés un par un ou par groupes de trois, ce qui influe directement sur la capacité arithmétique du modèle.

**Les tokens spéciaux.** Des identifiants réservés marquent la fin d'un document (`<|endoftext|>`), le début d'un tour de parole ou le rôle (`system`, `user`, `assistant`). Les **gabarits de conversation** (*chat templates*) d'un modèle instruit reposent sur eux ; un mauvais gabarit dégrade fortement un modèle fine-tuné, un point qui reviendra au module 28.

**La vitesse.** Notre encodeur est quadratique et écrit en Python. tiktoken (Rust, exposé en Python) et Hugging Face tokenizers (Rust) traitent des gigaoctets de texte en quelques minutes, ce qui est indispensable pour préparer des milliers de milliards de tokens de pré-entraînement (L132).

| Outil | Éditeur | Algorithme | Usage typique | Entraîner son propre vocabulaire ? |
|---|---|---|---|---|
| `tiktoken` | OpenAI | BPE au niveau des octets | encodages `cl100k_base`, `o200k_base` ; compter les tokens avant un appel d'API | non (encodage seulement) |
| `tokenizers` | Hugging Face | BPE, WordPiece, Unigram | tokenizers des modèles du Hub ; entraînement rapide | oui |
| SentencePiece | Google | BPE ou Unigram, traite l'espace comme un symbole (`▁`) | historiquement Llama 1-2, T5, de nombreux modèles multilingues | oui |
| minbpe | Karpathy (pédagogique) | BPE au niveau des octets | apprendre, lire le code en une heure | oui |

> 🔗 **Documentation officielle** — [tiktoken](https://github.com/openai/tiktoken) 🇬🇧 · [Hugging Face Tokenizers](https://huggingface.co/docs/tokenizers/index) 🇬🇧 · chapitre 6 du [Hugging Face LLM Course](https://huggingface.co/learn/llm-course/chapter1/1) 🇬🇧 (« Tokenizers », licence Apache 2.0) qui compare BPE, WordPiece et Unigram.

```quiz
{
  "q": "Vous devez (1) compter les tokens d'un prompt avant un appel à l'API OpenAI et (2) entraîner un vocabulaire maison sur vos contrats. Quels outils choisir ?",
  "options": [
    "tiktoken pour les deux",
    "Hugging Face tokenizers pour compter, tiktoken pour entraîner",
    "SentencePiece pour compter, minbpe en production",
    "tiktoken pour compter, Hugging Face tokenizers pour entraîner"
  ],
  "answer": 3,
  "explanation": "tiktoken fournit les encodages d'OpenAI mais n'entraîne pas de vocabulaire ; Hugging Face tokenizers (Rust) entraîne rapidement BPE, WordPiece ou Unigram."
}
```

## 5. Le français face aux tokenizers

Les tokenizers sont entraînés sur des corpus où l'anglais domine largement. Les fusions les plus précieuses sont donc anglaises, et un même contenu exprimé en français se découpe en **davantage** de tokens. Le dossier de recherche de cette formation retient l'ordre de grandeur suivant (nov. 2026) : environ 0,75 mot anglais par token, et un français qui coûte **environ 1,3 à 1,5 fois plus de tokens** que l'anglais pour un texte équivalent. Ce ratio varie selon le tokenizer : les vocabulaires plus grands et plus multilingues (comme `o200k_base` par rapport à `cl100k_base`, ou les tokenizers des modèles Mistral, Qwen et Gemma conçus pour le multilingue) réduisent l'écart. Mesurez-le vous-même avec le script de la section 6 plutôt que de croire un chiffre générique.

Les conséquences sont très concrètes pour une PME française :

- **Coût.** Les API facturent au token. Un chatbot de SAV en français coûte mécaniquement plus cher que son équivalent anglais, à prix unitaire égal.
- **Contexte.** Une fenêtre de 128 000 tokens contient moins de pages de contrat en français qu'en anglais. Comptez toujours en tokens, jamais en pages.
- **Qualité.** Un mot découpé en cinq morceaux est plus difficile à manipuler (orthographe, accords, rimes) qu'un mot représenté par un seul token. Les accents aggravent le phénomène : « é », « è », « à », « ç » occupent deux octets en UTF-8, et une variante sans accent (« reglement ») ou avec une apostrophe typographique (’ au lieu de ') se tokenise différemment.

> 🎮 **Défi** — Sans exécuter de code, classez par nombre de tokens croissant (avec `o200k_base`) : « facture », « refacturation », « anticonstitutionnellement », « 2026 ». Puis vérifiez avec tiktoken. *(Pistes en fin de leçon.)*

Une anecdote célèbre illustre la fragilité de cette couche : début 2023, des chercheurs ont découvert des **« glitch tokens »** comme `SolidGoldMagikarp`, des chaînes présentes dans le vocabulaire de GPT-2/GPT-3 (issues de pseudonymes très fréquents dans les données qui ont servi à entraîner le tokenizer) mais quasiment absentes des données d'entraînement du modèle. Leurs embeddings n'avaient presque jamais été mis à jour, et le modèle réagissait de façon erratique quand on les lui présentait. Morale : tokenizer et modèle doivent être pensés ensemble.

```quiz
{
  "type": "vrai_faux",
  "q": "À prix unitaire égal, un chatbot de SAV qui répond en français consomme généralement plus de tokens que son équivalent anglais.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai : les tokenizers sont entraînés sur des corpus majoritairement anglais, donc le français se découpe en davantage de tokens, et les accents occupent deux octets en UTF-8."
}
```

## 6. Mesurer en pratique : tiktoken et un BPE Hugging Face

```python
# comparer_tokenizers.py — français vs anglais, tiktoken et un BPE Hugging Face entraîné localement
# pip install tiktoken tokenizers
import tiktoken
from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders

fr = "L'entreprise a réceptionné les marchandises et réglé la facture électronique."
en = "The company received the goods and paid the electronic invoice."

for nom in ("cl100k_base", "o200k_base"):          # encodages publiés par OpenAI dans tiktoken
    enc = tiktoken.get_encoding(nom)                # téléchargés au premier appel puis mis en cache
    nf, ne = len(enc.encode(fr)), len(enc.encode(en))
    print(f"{nom:12s} FR={nf:3d} tokens  EN={ne:3d} tokens  ratio FR/EN={nf / ne:.2f}")
    print("   découpage FR :", [enc.decode([t]) for t in enc.encode(fr)])

# Entraîner un BPE « byte-level » sur un petit corpus français, avec la bibliothèque Rust de Hugging Face
corpus = [fr, "La facturation électronique s'impose aux entreprises françaises.",
          "Les réceptions de marchandises sont contrôlées avant le règlement."] * 200
tk = Tokenizer(models.BPE())
tk.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
tk.decoder = decoders.ByteLevel()
tk.train_from_iterator(corpus, trainers.BpeTrainer(vocab_size=400, special_tokens=["<|fin|>"],
                                                   initial_alphabet=pre_tokenizers.ByteLevel.alphabet()))
sortie = tk.encode(fr)
print(f"\nBPE HF maison : {len(sortie.ids)} tokens ->", sortie.tokens)
print("Décodage :", tk.decode(sortie.ids))
```

Sur notre machine, la partie Hugging Face (qui ne nécessite aucun réseau) découpe la phrase française en **13 tokens** seulement — `'entreprise'`, `'Ġmarchandises'`, `'ĠrÃ©ceptionnÃ©'`… — parce que le vocabulaire a été entraîné sur un corpus très proche. Les `Ã©` sont l'affichage « octet par octet » de « é » propre au byte-level BPE ; le décodage restitue parfaitement le texte. La partie tiktoken télécharge les fichiers d'encodage au premier lancement : exécutez-la sur un poste connecté et notez vos ratios FR/EN pour l'exercice.

> 💡 **À retenir** — Un tokenizer entraîné sur **votre domaine** compresse beaucoup mieux **votre domaine**. C'est l'une des raisons pour lesquelles des acteurs francophones entraînent leurs propres vocabulaires, et pour lesquelles il faut toujours mesurer les tokens sur des documents réels.

```mission
{
  "title": "Le premier exemple de tiktoken",
  "url": "https://github.com/openai/tiktoken",
  "steps": [
    "Ouvrez le dépôt GitHub openai/tiktoken",
    "Lisez le premier bloc de code du README",
    "Repérez aussi la fonction qui choisit l'encodage à partir d'un nom de modèle"
  ],
  "question": "Quel encodage le README charge-t-il dans son premier exemple, et quelle fonction donne l'encodage adapté à un modèle donné ?",
  "hint": "Cherchez get_encoding et encoding_for_model.",
  "answer": "`tiktoken.get_encoding(\"o200k_base\")`, et `tiktoken.encoding_for_model(\"gpt-4o\")` pour partir d'un nom de modèle (README consulté en nov. 2026 ; l'exemple peut évoluer avec les nouveaux modèles) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Les trois tokenizers de minbpe",
  "url": "https://github.com/karpathy/minbpe",
  "steps": [
    "Ouvrez le dépôt karpathy/minbpe",
    "Lisez la partie du README qui présente les fichiers du dossier minbpe/",
    "Notez le nom et le rôle de chaque classe de tokenizer"
  ],
  "question": "Quelles sont les trois classes de tokenizers proposées par minbpe, et laquelle reproduit le tokenizer de GPT-4 ?",
  "hint": "L'une travaille directement sur le texte, une autre découpe d'abord avec une expression régulière.",
  "answer": "BasicTokenizer (BPE directement sur le texte), RegexTokenizer (pré-découpage par expression régulière, comme GPT-2 et GPT-4) et GPT4Tokenizer, qui reproduit l'encodage cl100k_base de GPT-4 et se vérifie contre tiktoken (README consulté en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** 
1. Récupérez un texte français libre de droits d'au moins 200 000 caractères (par exemple un roman de Jules Verne ou de Victor Hugo au format « Plain Text UTF-8 » sur [Project Gutenberg](https://www.gutenberg.org/)) et enregistrez-le sous `corpus.txt`.
2. Entraînez **votre** `BPE` de la section 3 avec `taille_vocab=512` sur les 50 000 premiers caractères (l'implémentation naïve est lente : c'est normal). Entraînez aussi un BPE Hugging Face avec `vocab_size=512` sur le texte complet.
3. Calculez pour chaque tokenizer le **taux de compression** (octets UTF-8 / nombre de tokens) sur un paragraphe français **absent** du corpus d'entraînement, puis sur sa traduction anglaise.
4. Comparez avec `o200k_base` et rédigez trois phrases de conclusion.

**Critères de réussite.** (a) L'aller-retour `decoder(encoder(x)) == x` est vérifié par une assertion pour vos deux tokenizers ; (b) les quatre taux de compression sont présentés dans un tableau ; (c) la conclusion explique pourquoi votre tokenizer est meilleur en français et moins bon en anglais que `o200k_base`.

<details><summary>Pistes de corrigé</summary>

- Taux de compression : `len(texte.encode("utf-8")) / len(ids)`. Un tokenizer d'octets « nu » vaut 1,0 ; attendez-vous à environ 2 à 3 pour vos BPE à 512 entrées sur du français, davantage pour `o200k_base` dont le vocabulaire est bien plus grand.
- Sur l'anglais, votre BPE entraîné sur Hugo retombe vers les octets bruts : il n'a appris aucune fusion anglaise utile. `o200k_base`, entraîné sur un corpus massif et majoritairement anglais, compresse très bien l'anglais.
- Conclusion attendue : la compression dépend de l'adéquation entre le corpus d'entraînement du tokenizer et le texte encodé ; c'est le mécanisme qui explique la « taxe » payée par le français.
</details>

## ✅ Auto-évaluation express
1. Pourquoi un BPE au niveau des octets ne produit-il jamais de token « inconnu » ?
2. Dans quel ordre l'encodage applique-t-il les fusions, et pourquoi ?
3. Citez deux conséquences pratiques, pour un projet français, du fait qu'un texte français produit plus de tokens qu'un texte anglais équivalent.

## 📚 Pour aller plus loin
- [Andrej Karpathy — Let's build the GPT Tokenizer](https://youtu.be/zduSFxRajkE) 🇬🇧 — 2 h 13 de construction en direct, avec la regex de pré-tokenisation de GPT-4.
- [Karpathy — minbpe](https://github.com/karpathy/minbpe) 🇬🇧 — code minimal et lisible du BPE, à comparer avec le vôtre.
- [Sennrich et al. (2016) — Subword Units](https://arxiv.org/abs/1508.07909) 🇬🇧 — l'article qui a importé le BPE en traitement automatique des langues.
- [Kudo & Richardson (2018) — SentencePiece](https://arxiv.org/abs/1808.06226) 🇬🇧 — tokenisation indépendante de la langue, sans pré-découpage par espaces.
- [Hugging Face — Tokenizers](https://huggingface.co/docs/tokenizers/index) 🇬🇧 — guide « quicktour » pour entraîner un tokenizer complet.

**Réponses de l'auto-évaluation.** 1. Parce que le vocabulaire contient les 256 octets possibles : tout texte UTF-8 se décompose au pire en octets isolés. 2. Dans l'ordre d'apprentissage (rang croissant), car chaque fusion a été apprise sur un texte où toutes les fusions précédentes étaient déjà appliquées ; l'ordre garantit le même découpage qu'à l'entraînement. 3. Un coût d'API plus élevé à volume égal, et moins de contenu dans une fenêtre de contexte donnée (ainsi qu'une génération plus lente, puisque plus de tokens sont produits). **Défi** : en général « 2026 » et « facture » sont très courts (1 à 2 tokens), « refacturation » en demande davantage, et « anticonstitutionnellement » est le plus découpé ; les valeurs exactes dépendent de l'encodage, d'où l'intérêt de vérifier.

> 🗺️ **Et maintenant ?** — Vous avez toutes les pièces : attention, bloc transformer, tokens. En L131, vous les assemblez dans un vrai petit GPT qui apprend à écrire sur votre ordinateur.
