---
id: L122
module: M26
level: N4
title: "Rétropropagation à la main (micrograd, Karpathy)"
minutes: 65
objectives:
  - "Calculer à la main, nœud par nœud, la passe avant et la passe arrière d'un graphe de calcul"
  - "Expliquer les quatre motifs locaux de la rétropropagation (addition, multiplication, max, embranchement)"
  - "Construire un moteur d'autograd scalaire complet et un MLP au-dessus, puis l'entraîner sur un problème non linéaire"
  - "Généraliser l'autograd aux tableaux (produit matriciel, diffusion, entropie croisée) et vérifier ses gradients contre PyTorch"
skills: ["C4.3", "C4.1"]
sources:
  - { title: "Andrej Karpathy — Neural Networks: Zero to Hero (vidéo 1 : micrograd)", url: "https://karpathy.ai/zero-to-hero.html", lang: "en" }
  - { title: "karpathy/micrograd (GitHub)", url: "https://github.com/karpathy/micrograd", lang: "en" }
  - { title: "MIT 6.S191 Introduction to Deep Learning (2026)", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "Stanford CS231n Spring 2026 — Lecture 4 : Neural networks and backpropagation", url: "https://cs231n.stanford.edu/schedule.html", lang: "en" }
  - { title: "PyTorch — A Gentle Introduction to torch.autograd", url: "https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html", lang: "en" }
  - { title: "3Blue1Brown — Neural Networks, chapitres 3 et 4", url: "https://www.3blue1brown.com/topics/neural-networks", lang: "en" }
---

# Rétropropagation à la main (micrograd, Karpathy)

> ⏱ 65 min · 🎯 Niveau 4 · 📚 Module 26

## 🎯 Ce que vous saurez faire
- Dérouler sur papier la rétropropagation (*backpropagation*) d'un graphe de calcul et vérifier chaque gradient.
- Reconnaître d'un coup d'œil le rôle de chaque nœud : distributeur, échangeur, aiguilleur, collecteur.
- Écrire un moteur d'autograd scalaire complet (une soixantaine de lignes), un MLP au-dessus, et l'entraîner.
- Passer du scalaire au tenseur : produit matriciel, diffusion (*broadcasting*), entropie croisée, et comparer vos gradients à ceux de PyTorch.

> 🧭 **En clair** — Quand un réseau se trompe, il faut savoir **qui est responsable** de l'erreur, et dans quelle mesure, parmi des milliers de petits calculs. La rétropropagation remonte le calcul à l'envers, de la réponse finale vers les entrées, et distribue la « responsabilité » à chaque étape, comme on remonte une chaîne de livraison pour trouver où un colis a été abîmé. Chaque maillon n'a besoin que de deux informations : ce qu'il a reçu de l'aval et sa propre règle locale. Dans cette leçon, vous écrivez vous-même ce mécanisme, d'abord nombre par nombre, puis sur des tableaux entiers, et vous vérifiez qu'il donne exactement les mêmes résultats que PyTorch.

En M24 L112, vous avez découvert la règle de la chaîne, la formule du gradient d'une couche linéaire et une première classe `Valeur` de 40 lignes. Cette leçon reprend exactement les mêmes notations (`Valeur`, `_retour`, `+=`) et va trois crans plus loin : un moteur complet, un réseau entraîné avec, puis une version vectorisée qui ressemble déjà à PyTorch. Elle s'inspire de la première vidéo de la série *Neural Networks: Zero to Hero* d'Andrej Karpathy (« building micrograd », 2 h 25) ; le code ci-dessous est une réécriture originale pour la formation.

## 1. Pourquoi refaire à la main ce que PyTorch fait très bien ?

Karpathy le répète dans ses cours : la rétropropagation est une **abstraction qui fuit**. Tant que tout va bien, `loss.backward()` suffit. Le jour où la perte devient `nan`, où un neurone ne s'active plus jamais, où le gradient de la première couche vaut $10^{-9}$, seule la compréhension du mécanisme permet de diagnostiquer. Les cours de référence (MIT 6.S191 séance 1, Stanford CS231n séance 4, CMU 11-785 séances 3 à 5, fast.ai partie 2 leçons 13-14) font tous ce détour, pour la même raison.

Analogie : un expert-comptable qui n'a jamais tenu une comptabilité à la main sait utiliser son logiciel, mais il ne trouve pas l'erreur quand le bilan ne s'équilibre pas.

## 2. Un graphe de calcul, à la main

Prenons $L = (a \cdot b + c) \cdot f$ avec $a = 1{,}5$, $b = -2$, $c = 5$, $f = -3$. On nomme les résultats intermédiaires : $e = a b$, $d = e + c$, $L = d f$.

```
 a=1.5 ──┐
         (×)── e=-3 ──┐
 b=-2  ──┘            (+)── d=2 ──┐
 c=5   ───────────────┘           (×)── L=-6
 f=-3  ───────────────────────────┘
```

**Passe avant** (de gauche à droite) : $e = -3$, $d = 2$, $L = -6$.

> 🧠 **L'intuition d'abord** — $\bar v$ (« v barre ») répond à : « si je modifie un tout petit peu $v$, de combien bouge le résultat final $L$ ? ». On le calcule en partant de la fin, où la réponse est évidente ($\bar L = 1$ : bouger $L$ bouge $L$ d'autant), puis en reculant maillon par maillon. **Analogie :** un jeu du téléphone à l'envers. Le dernier joueur sait exactement ce qu'il a entendu ; il dit au précédent « ta phrase a eu tel effet sur la mienne », et ainsi de suite jusqu'au premier.

**Passe arrière** (de droite à gauche). On note $\bar v = \partial L / \partial v$ le gradient « qui arrive » au nœud $v$ :

| Nœud | Dérivée locale | Gradient reçu | Calcul | $\bar v$ |
|---|---|---|---|---|
| $L$ | — | — | par définition | $1$ |
| $d$ | $\partial L/\partial d = f$ | $\bar L = 1$ | $-3 \times 1$ | $-3$ |
| $f$ | $\partial L/\partial f = d$ | $\bar L = 1$ | $2 \times 1$ | $2$ |
| $e$ | $\partial d/\partial e = 1$ | $\bar d = -3$ | $1 \times (-3)$ | $-3$ |
| $c$ | $\partial d/\partial c = 1$ | $\bar d = -3$ | $1 \times (-3)$ | $-3$ |
| $a$ | $\partial e/\partial a = b$ | $\bar e = -3$ | $-2 \times (-3)$ | $6$ |
| $b$ | $\partial e/\partial b = a$ | $\bar e = -3$ | $1{,}5 \times (-3)$ | $-4{,}5$ |

Vérification express par différence finie : avec $a = 1{,}501$, $L = (-3{,}002 + 5)(-3) = -5{,}994$, soit une variation de $+0{,}006$ pour $+0{,}001$ : pente $6$. ✔

Chaque ligne applique **la même règle** : *gradient du nœud = dérivée locale × gradient reçu de l'aval*. Aucune ligne n'a besoin de connaître le reste du graphe. C'est ce qui rend l'algorithme modulaire, et c'est ce que code la méthode `_retour`.

```quiz
{
  "q": "Dans le graphe L = (a·b + c)·f, on remplace f = −3 par f = −6 (les autres valeurs inchangées : a = 1,5, b = −2, c = 5). Que vaut maintenant le gradient de c ?",
  "options": ["−6", "−3", "2", "1"],
  "answer": 0,
  "explanation": "c passe par une addition (dérivée locale 1) puis par la multiplication par f : c̄ = 1 × d̄ = f = −6. Le nœud multiplicatif « échange » : le gradient de d est la valeur de l'autre entrée, f."
}
```

## 3. Les quatre motifs à reconnaître

En pratiquant, on finit par lire un graphe comme un circuit. Cette lecture « circuit » est popularisée par les notes du cours CS231n.

> 🧠 **L'intuition d'abord** — Il n'y a que quatre comportements à connaître, comme quatre types de pièces dans un circuit de plomberie : le **distributeur** (addition) envoie le même débit dans chaque tuyau, l'**échangeur** (multiplication) pondère chaque branche par la valeur de l'autre, l'**aiguilleur** (max, ReLU) envoie tout dans une seule branche, le **collecteur** (embranchement) additionne ce qui revient de plusieurs tuyaux.

| Nœud | Comportement en arrière | Image mentale | Conséquence pratique |
|---|---|---|---|
| Addition $x + y$ | copie le gradient reçu vers **chaque** entrée | **distributeur** | les connexions résiduelles (ResNet, L124) transmettent le gradient intact |
| Multiplication $x \cdot y$ | envoie à $x$ le gradient × $y$, et à $y$ le gradient × $x$ | **échangeur** | si une entrée est énorme, l'autre reçoit un gradient énorme : d'où la normalisation des entrées |
| $\max(x, y)$, ReLU | tout le gradient part vers l'entrée gagnante, zéro vers l'autre | **aiguilleur** | un ReLU toujours négatif ne reçoit plus rien : neurone mort |
| Embranchement (une valeur utilisée deux fois) | les gradients des deux chemins **s'additionnent** | **collecteur** | c'est le `+=` ; un `=` provoque un bug silencieux |

> 💡 **À retenir** — Rétropropager, c'est appliquer localement « dérivée locale × gradient aval » et **additionner** quand une valeur sert plusieurs fois. L'ordre de visite est l'**ordre topologique inverse** du graphe : un nœud n'est traité qu'une fois que tous ceux qui l'utilisent ont déposé leur contribution.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : dans un nœud ReLU dont l'entrée vaut −2 lors de la passe avant, le gradient transmis vers l'amont est nul, quel que soit le gradient reçu de l'aval.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. ReLU est un aiguilleur : pour une entrée négative, sa dérivée locale vaut 0, donc rien ne passe. Si cela arrive pour tous les exemples, le neurone ne reçoit plus jamais de gradient (neurone « mort »)."
}
```

## 4. Un moteur d'autograd scalaire complet

La classe ci-dessous complète celle de M24 L112. Deux idées nouvelles : (1) les opérations **dérivées** (soustraction, division, négation) sont construites à partir des opérations élémentaires, sans écrire de nouvelle dérivée ; (2) le tri topologique est **itératif**, pour ne pas dépasser la limite de récursion de Python sur un gros graphe.

```python
"""moteur.py — autograd scalaire minimal (inspiré de micrograd, réécrit pour la formation)."""
import math
import random

class Valeur:
    def __init__(self, data, parents=(), op=""):
        self.data, self.grad = float(data), 0.0
        self._parents, self._op = parents, op
        self._retour = lambda: None

    # ----- opérations élémentaires : valeur + dérivée locale -----
    def __add__(self, autre):
        autre = autre if isinstance(autre, Valeur) else Valeur(autre)
        out = Valeur(self.data + autre.data, (self, autre), "+")
        def _retour():
            self.grad += out.grad
            autre.grad += out.grad
        out._retour = _retour
        return out

    def __mul__(self, autre):
        autre = autre if isinstance(autre, Valeur) else Valeur(autre)
        out = Valeur(self.data * autre.data, (self, autre), "*")
        def _retour():
            self.grad += autre.data * out.grad
            autre.grad += self.data * out.grad
        out._retour = _retour
        return out

    def __pow__(self, k):                        # k : nombre (pas une Valeur)
        out = Valeur(self.data ** k, (self,), f"**{k}")
        def _retour():
            self.grad += k * self.data ** (k - 1) * out.grad
        out._retour = _retour
        return out

    def exp(self):
        e = math.exp(self.data)
        out = Valeur(e, (self,), "exp")
        def _retour():
            self.grad += e * out.grad            # (e^x)' = e^x
        out._retour = _retour
        return out

    def log(self):
        out = Valeur(math.log(self.data), (self,), "log")
        def _retour():
            self.grad += out.grad / self.data    # (ln x)' = 1/x
        out._retour = _retour
        return out

    def tanh(self):
        t = math.tanh(self.data)
        out = Valeur(t, (self,), "tanh")
        def _retour():
            self.grad += (1 - t * t) * out.grad
        out._retour = _retour
        return out

    def relu(self):
        out = Valeur(max(0.0, self.data), (self,), "relu")
        def _retour():
            self.grad += (out.data > 0) * out.grad
        out._retour = _retour
        return out

    # ----- opérations dérivées : aucune dérivée à écrire -----
    def __neg__(self):            return self * -1
    def __sub__(self, autre):     return self + (-autre)
    def __truediv__(self, autre): return self * autre ** -1
    def __radd__(self, autre):    return self + autre       # 2 + v
    def __rsub__(self, autre):    return Valeur(autre) - self
    def __rmul__(self, autre):    return self * autre       # 2 * v
    def __rtruediv__(self, autre): return Valeur(autre) / self
    def __repr__(self):           return f"Valeur(data={self.data:.4f}, grad={self.grad:.4f})"

    def backward(self):
        """Tri topologique itératif (pas de limite de récursion), puis parcours inverse."""
        ordre, vus, pile = [], set(), [(self, False)]
        while pile:
            v, traite = pile.pop()
            if traite:
                ordre.append(v)
            elif v not in vus:
                vus.add(v)
                pile.append((v, True))
                pile.extend((p, False) for p in v._parents)
        self.grad = 1.0
        for v in reversed(ordre):
            v._retour()

# ----- couches au-dessus du moteur -----
class Neurone:
    def __init__(self, n_entrees, activation=True):
        self.w = [Valeur(random.uniform(-1, 1)) for _ in range(n_entrees)]
        self.b = Valeur(0.0)
        self.activation = activation
    def __call__(self, x):
        z = sum((wi * xi for wi, xi in zip(self.w, x)), self.b)
        return z.tanh() if self.activation else z
    def parametres(self):
        return self.w + [self.b]

class Couche:
    def __init__(self, n_entrees, n_sorties, **kw):
        self.neurones = [Neurone(n_entrees, **kw) for _ in range(n_sorties)]
    def __call__(self, x):
        sorties = [n(x) for n in self.neurones]
        return sorties[0] if len(sorties) == 1 else sorties
    def parametres(self):
        return [p for n in self.neurones for p in n.parametres()]

class MLP:
    def __init__(self, n_entrees, tailles):
        dims = [n_entrees] + tailles
        self.couches = [Couche(dims[i], dims[i + 1], activation=i < len(tailles) - 1)
                        for i in range(len(tailles))]
    def __call__(self, x):
        for c in self.couches:
            x = c(x)
        return x
    def parametres(self):
        return [p for c in self.couches for p in c.parametres()]
```

Vérifiez le graphe de la section 2 dans un second fichier :

```python
from moteur import Valeur

a, b, c, f = Valeur(1.5), Valeur(-2.0), Valeur(5.0), Valeur(-3.0)
L = (a * b + c) * f
L.backward()
print(a.grad, b.grad, c.grad, f.grad)   # 6.0 -4.5 -3.0 2.0
```

Notez le détail du tri itératif : la pile contient des couples `(nœud, traité ?)`. Un nœud est ajouté à `ordre` seulement **après** tous ses parents, ce qui produit un ordre topologique ; on le parcourt ensuite à l'envers.

> 💡 **Autrement dit** — Le tri topologique est une **liste d'attente** : un nœud ne doit transmettre sa responsabilité vers l'amont qu'après avoir reçu celle de **tous** ceux qui l'utilisent. Comme un chef de projet qui attend tous les rapports de son équipe avant de faire le sien à la direction.

## 5. Entraîner un réseau avec votre moteur

Les classes `Neurone`, `Couche` et `MLP` reproduisent l'API que vous retrouverez dans `torch.nn` : un objet appelable et une méthode qui liste les paramètres. On entraîne un réseau $2 \to 16 \to 16 \to 1$ sur deux demi-lunes entrelacées, un problème qu'aucune frontière linéaire ne résout.

```python
"""entrainer.py — MLP scalaire sur deux demi-lunes."""
import random
from sklearn.datasets import make_moons
from moteur import Valeur, MLP

random.seed(0)
X, y = make_moons(n_samples=100, noise=0.1, random_state=0)
y = y * 2 - 1                                     # étiquettes -1 / +1
modele = MLP(2, [16, 16, 1])
print("paramètres :", len(modele.parametres()))   # 2*16+16 + 16*16+16 + 16+1 = 337

for etape in range(60):
    scores = [modele(list(map(Valeur, x))) for x in X]
    # perte « hinge » (marge) + petite pénalité L2, comme un SVM
    pertes = [(1 + -yi * si).relu() for yi, si in zip(y, scores)]
    perte = sum(pertes) * (1.0 / len(pertes))
    perte = perte + 1e-4 * sum(p * p for p in modele.parametres())
    exactitude = sum((si.data > 0) == (yi > 0) for yi, si in zip(y, scores)) / len(y)

    for p in modele.parametres():                 # 1. remettre les gradients à zéro
        p.grad = 0.0
    perte.backward()                              # 2. rétropropager
    eta = 1.0 - 0.9 * etape / 60                  # 3. pas décroissant
    for p in modele.parametres():
        p.data -= eta * p.grad
    if etape % 10 == 0 or etape == 59:
        print(f"étape {etape:02d}  perte={perte.data:.4f}  exactitude={exactitude:.0%}")
```

Résultat obtenu : 65 % d'exactitude au départ, 93 % à l'étape 10, **100 % à partir de l'étape 20**, perte finale ≈ 0,020. Mais il a fallu **environ 45 secondes** sur un processeur de portable pour 100 points et 337 paramètres. Chaque multiplication crée un objet Python ; une passe complète en fabrique plusieurs dizaines de milliers. C'est la meilleure démonstration de l'intérêt des tenseurs.

> 💡 **Autrement dit** — La boucle d'entraînement tient en trois gestes répétés : **remettre les compteurs à zéro** (gradients), **remonter l'erreur** (`backward`), **corriger chaque poids** d'un petit pas dans le sens qui réduit l'erreur. La lenteur vient de ce que chaque multiplication est un objet Python à part : on traite les nombres un par un, comme un caissier qui scannerait chaque grain de riz.

> ⚠️ **Piège fréquent** — Oublier la remise à zéro des gradients. Comme `_retour` fait `+=`, les gradients de l'étape précédente s'ajoutent à ceux de l'étape courante et l'entraînement diverge. PyTorch a le même comportement (accumulation volontaire, utile pour simuler de grands lots), d'où le rituel `optimizer.zero_grad()` en L123.

## 6. Du scalaire au tenseur

Un réseau réel manipule des matrices. Le principe ne change pas, seules les dérivées locales deviennent matricielles ; vous les connaissez depuis M24 L112 : pour $Y = XW$, $\bar X = \bar Y\,W^\top$ et $\bar W = X^\top \bar Y$.

> 🧠 **L'intuition d'abord** — Avec des tableaux, les règles ne changent pas, elles s'appliquent à des blocs entiers d'un coup. Seule subtilité : quand un même biais est **recopié** sur toutes les lignes d'un lot, il est utilisé $B$ fois ; en arrière, il faut donc **additionner** les $B$ contributions. **Analogie :** une même affiche placardée dans 32 stations de métro. Pour mesurer son effet total, on additionne les réactions des 32 stations.

Une difficulté nouvelle apparaît : la **diffusion**. Quand on ajoute un biais $b$ de forme $(1, n)$ à une matrice $(B, n)$, NumPy « étire » $b$ sur les $B$ lignes. En arrière, chaque copie a reçu un gradient : il faut **les additionner** pour revenir à la forme $(1, n)$. C'est le motif « collecteur » de la section 3, appliqué à un axe entier.

```python
"""tenseur.py — autograd tensoriel minimal en NumPy, même principe que Valeur."""
import numpy as np
from sklearn.datasets import make_moons

def _reduire(grad, forme):
    """Annule la diffusion (broadcasting) : somme sur les axes qui ont été étirés."""
    while grad.ndim > len(forme):
        grad = grad.sum(axis=0)
    for axe, taille in enumerate(forme):
        if taille == 1:
            grad = grad.sum(axis=axe, keepdims=True)
    return grad

class Tenseur:
    def __init__(self, data, parents=()):
        self.data = np.asarray(data, dtype=np.float64)
        self.grad = np.zeros_like(self.data)
        self._parents, self._retour = parents, lambda: None

    def __add__(self, autre):
        out = Tenseur(self.data + autre.data, (self, autre))
        def _retour():
            self.grad += _reduire(out.grad, self.data.shape)
            autre.grad += _reduire(out.grad, autre.data.shape)
        out._retour = _retour
        return out

    def __matmul__(self, autre):                  # Y = X @ W
        out = Tenseur(self.data @ autre.data, (self, autre))
        def _retour():
            self.grad += out.grad @ autre.data.T  # dL/dX = dL/dY · Wᵀ
            autre.grad += self.data.T @ out.grad  # dL/dW = Xᵀ · dL/dY
        out._retour = _retour
        return out

    def relu(self):
        out = Tenseur(np.maximum(0, self.data), (self,))
        def _retour():
            self.grad += (self.data > 0) * out.grad
        out._retour = _retour
        return out

    def entropie_croisee(self, y):                # self : logits (B, K) ; y : entiers (B,)
        z = self.data - self.data.max(1, keepdims=True)
        P = np.exp(z) / np.exp(z).sum(1, keepdims=True)
        B = len(y)
        out = Tenseur(-np.log(P[np.arange(B), y] + 1e-12).mean(), (self,))
        def _retour():
            G = P.copy(); G[np.arange(B), y] -= 1  # P - Y
            self.grad += G / B * out.grad
        out._retour = _retour
        return out

    def backward(self):
        ordre, vus = [], set()
        def topo(v):
            if id(v) not in vus:
                vus.add(id(v))
                for p in v._parents:
                    topo(p)
                ordre.append(v)
        topo(self)
        self.grad = np.ones_like(self.data)
        for v in reversed(ordre):
            v._retour()

if __name__ == "__main__":
    # --- entraînement : 2 -> 32 -> 32 -> 2 sur 1 000 points ---
    rng = np.random.default_rng(0)
    X, y = make_moons(n_samples=1000, noise=0.15, random_state=0)
    def couche(n_in, n_out):
        return Tenseur(rng.normal(0, np.sqrt(2 / n_in), (n_in, n_out))), Tenseur(np.zeros((1, n_out)))
    W1, b1 = couche(2, 32); W2, b2 = couche(32, 32); W3, b3 = couche(32, 2)
    params = [W1, b1, W2, b2, W3, b3]
    for etape in range(301):
        logits = ((Tenseur(X) @ W1 + b1).relu() @ W2 + b2).relu() @ W3 + b3
        perte = logits.entropie_croisee(y)
        for p in params:
            p.grad[:] = 0
        perte.backward()
        for p in params:
            p.data -= 0.5 * p.grad
        if etape % 100 == 0:
            acc = (logits.data.argmax(1) == y).mean()
            print(f"étape {etape:3d}  perte={perte.data:.4f}  exactitude={acc:.1%}")
```

Résultat obtenu : dix fois plus de points, un réseau plus large (1 218 paramètres), 300 étapes… en **moins de 2 secondes**. Exactitude 96,1 % à l'étape 100, **99,1 %** à l'étape 300. Le gain vient de ce que chaque opération porte sur un tableau entier, exécuté en code compilé. PyTorch pousse la même idée jusqu'au GPU.

```quiz
{
  "q": "Votre autograd tensoriel donne des gradients corrects pour W1 et W2, mais faux pour le biais b1 (forme (1, 32)) quand le lot contient 64 exemples. Quelle est la cause la plus probable ?",
  "options": ["Le taux d'apprentissage est trop grand pour les biais", "Le gradient du biais n'est pas sommé sur l'axe du lot", "ReLU n'est pas dérivable en 0, ce qui fausse les biais", "Il manque une transposée dans le produit matriciel"],
  "answer": 1,
  "explanation": "Le biais a été recopié sur les 64 lignes : son gradient doit être la somme des 64 contributions (fonction _reduire). Une transposée oubliée fausserait aussi W1 et W2."
}
```

| | `Valeur` (scalaire) | `Tenseur` (NumPy) | PyTorch |
|---|---|---|---|
| Unité de calcul | un nombre | un tableau | un tableau sur CPU, GPU ou MPS |
| Dérivées locales | écrites à la main | écrites à la main | plus de 2 000 opérateurs fournis |
| Graphe | objets Python | objets Python | graphe C++ dynamique |
| Vitesse (ordre de grandeur) | 1 | ×100 à ×1 000 | ×1 000 à ×100 000 sur GPU |
| Usage | comprendre | comprendre la diffusion | produire |

## 7. Vérifier contre PyTorch

Le meilleur test d'un autograd maison est la comparaison avec une référence. Ce script calcule une perte avec `Tenseur` et avec PyTorch sur les mêmes données et compare les gradients (installation : `pip install torch numpy scikit-learn`, voir L123).

```python
"""verifier.py — mêmes poids, mêmes données : nos gradients doivent égaler ceux de PyTorch."""
import numpy as np
import torch
from tenseur import Tenseur

rng = np.random.default_rng(1)
X = rng.normal(size=(8, 3)); y = rng.integers(0, 4, size=8)
W1, b1 = rng.normal(size=(3, 5)), rng.normal(size=(1, 5))
W2, b2 = rng.normal(size=(5, 4)), rng.normal(size=(1, 4))

# --- notre moteur ---
t = [Tenseur(a) for a in (W1, b1, W2, b2)]
perte = ((Tenseur(X) @ t[0] + t[1]).relu() @ t[2] + t[3]).entropie_croisee(y)
perte.backward()

# --- PyTorch (double précision pour comparer finement) ---
p = [torch.tensor(a, requires_grad=True) for a in (W1, b1, W2, b2)]
logits = torch.relu(torch.tensor(X) @ p[0] + p[1]) @ p[2] + p[3]
perte_t = torch.nn.functional.cross_entropy(logits, torch.tensor(y))
perte_t.backward()

print(f"perte : nous {perte.data:.10f} | PyTorch {perte_t.item():.10f}")
for nom, a, b in zip(["W1", "b1", "W2", "b2"], t, p):
    ecart = np.abs(a.grad - b.grad.numpy()).max()
    print(f"{nom} : écart max = {ecart:.2e}")
    assert ecart < 1e-8
```

Le bloc `if __name__ == "__main__":` du fichier `tenseur.py` permet de l'importer sans relancer l'entraînement. Attendu : des pertes identiques à $10^{-10}$ près et des écarts de gradient de l'ordre de $10^{-16}$ (la précision machine). Un écart sur `b1` seulement trahit presque toujours un oubli dans `_reduire`.

> 💡 **Autrement dit** — On fait calculer le même problème par deux « comptables » indépendants (votre moteur et PyTorch) et on compare leurs bilans ligne à ligne. Un écart de $10^{-16}$ n'est que l'arrondi de l'ordinateur ; un écart de $10^{-3}$ est une vraie erreur à chercher.

> 🔗 **Documentation officielle** — [PyTorch : A Gentle Introduction to torch.autograd](https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html) décrit le graphe dynamique que PyTorch construit exactement comme vos classes ; [micrograd sur GitHub](https://github.com/karpathy/micrograd) est la référence de Karpathy, à comparer après avoir écrit votre version.

```mission
{
  "title": "Ce que fait exactement micrograd, selon son auteur",
  "url": "https://github.com/karpathy/micrograd",
  "steps": ["Ouvrez le dépôt karpathy/micrograd sur GitHub", "Lisez le paragraphe de présentation en haut du README", "Faites défiler jusqu'à la démonstration d'entraînement (« Training a neural net »)"],
  "question": "Sur quel type de structure micrograd effectue-t-il la rétropropagation, combien de lignes de code comptent environ le moteur et la mini-bibliothèque de réseaux, et quelle perte utilise la démonstration ?",
  "hint": "Trois lettres pour la structure (un graphe orienté sans cycle) ; la perte est celle d'un SVM, comme dans la section 5.",
  "answer": "Sur un graphe orienté acyclique (DAG) construit dynamiquement ; environ 100 lignes pour le moteur et 50 pour la bibliothèque de réseaux ; la démo entraîne un MLP sur les deux demi-lunes (moons) avec une perte SVM « max-margin » (hinge). README consulté en nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 8. Les bugs de rétropropagation les plus fréquents

| Symptôme | Cause probable | Correctif |
|---|---|---|
| Gradient deux fois trop petit pour `x * x` | `=` au lieu de `+=` dans `_retour` | toujours accumuler |
| Perte qui explose après quelques étapes | gradients non remis à zéro | `p.grad = 0` avant chaque `backward` |
| Mauvais gradient du biais seulement | diffusion non annulée | sommer sur l'axe du lot |
| Gradients corrects une fois, faux ensuite | tableau modifié sur place après la passe avant | copier, ou ne pas modifier les données mémorisées |
| `nan` dans la perte | $\log 0$ ou $e^{1000}$ | soustraire le max, ajouter $\varepsilon$ |
| Couche entièrement à gradient nul | ReLU tous négatifs (neurones morts) | réduire le pas, Leaky ReLU, meilleure initialisation (L126) |

> 💡 **À retenir** — Un autograd maison se valide **toujours** par un test : différences finies (M24 L112) ou comparaison à PyTorch en `float64`. Écart relatif $< 10^{-6}$ : correct. Au-delà de $10^{-4}$ : bug.

## 🧪 Exercice pratique

**Consigne.**
1. Ajoutez à `Valeur` une méthode `sigmoid()` **sans écrire de dérivée**, uniquement à partir de `exp`, `+` et `/`. Vérifiez $\sigma'(0) = 0{,}25$.
2. Remplacez la perte « hinge » de la section 5 par l'entropie croisée binaire $-\left[t\log\sigma(s) + (1-t)\log(1-\sigma(s))\right]$ avec $t \in \{0, 1\}$, et réentraînez.
3. Ajoutez à `Tenseur` une méthode `tanh()` et une méthode `somme()`, puis étendez `verifier.py` pour un réseau qui utilise `tanh`.

**Critères de réussite.** `sigmoid` donne la bonne dérivée à $10^{-12}$ près ; le réseau atteint au moins 95 % d'exactitude sur les demi-lunes ; `verifier.py` passe ses assertions avec la nouvelle activation.

<details><summary>Pistes de correction</summary>

1. `def sigmoid(self): return 1 / (1 + (-self).exp())`. Grâce à `__rtruediv__` et `__radd__`, le graphe se construit tout seul ; `s = Valeur(0.0).sigmoid(); s.backward()` doit laisser `0.25` dans le `grad` de la valeur de départ.
2. `t = (yi + 1) / 2` ; `p = si.sigmoid()` ; `perte_i = -(t * p.log() + (1 - t) * (1 - p).log())`. Si vous obtenez une erreur de domaine sur `log`, c'est que $p$ vaut exactement 0 ou 1 : ajoutez `+ 1e-12`.
3. `tanh` : `t = np.tanh(self.data)` et `self.grad += (1 - t**2) * out.grad`. `somme` : `out = Tenseur(self.data.sum(), (self,))` et `self.grad += np.ones_like(self.data) * out.grad`.
</details>

## 🎮 Défi

Prédisez **avant d'exécuter** les gradients de $a$ et $b$ pour `L = (a * b).relu() + a` avec $a = 2$, $b = -1$. Réponse : $ab = -2 < 0$, le ReLU aiguille un gradient nul ; il ne reste que le chemin direct, donc $\bar a = 1$ et $\bar b = 0$.

## ✅ Auto-évaluation express

1. Dans quel ordre la passe arrière visite-t-elle les nœuds, et pourquoi ?
2. Que fait un nœud d'addition au gradient qu'il reçoit ? Et un nœud de multiplication ?
3. Pourquoi faut-il sommer le gradient sur l'axe du lot pour un biais diffusé ?

**Réponses.** 1. En ordre topologique inverse : un nœud ne doit propager son gradient qu'après avoir reçu toutes les contributions des nœuds qui l'utilisent. 2. L'addition le copie à l'identique vers chaque entrée ; la multiplication l'envoie à chaque entrée multiplié par la valeur de l'*autre* entrée. 3. Le même biais a été utilisé pour chaque exemple du lot : c'est un embranchement multiple, donc les contributions s'additionnent.

## 📚 Pour aller plus loin
- [Andrej Karpathy — Neural Networks: Zero to Hero](https://karpathy.ai/zero-to-hero.html) 🇬🇧 — vidéo 1 « building micrograd » (2 h 25), puis vidéo 5 « Becoming a Backprop Ninja » pour la rétropropagation tensorielle à la main.
- [micrograd sur GitHub](https://github.com/karpathy/micrograd) 🇬🇧 — le moteur de référence et son petit module de réseaux.
- [Stanford CS231n — programme Spring 2026](https://cs231n.stanford.edu/schedule.html) 🇬🇧 — séance 4, « Neural networks and backpropagation ».
- [3Blue1Brown — Neural Networks](https://www.3blue1brown.com/topics/neural-networks) 🇬🇧 — chapitres 3 et 4 : l'intuition puis le calcul.
- [fast.ai — Practical Deep Learning for Coders](https://course.fast.ai/) 🇬🇧 — partie 2, leçons 13 et 14 (backpropagation et MLP construits de zéro).

```mission
{
  "title": "Planifiez votre visionnage de « Zero to Hero »",
  "url": "https://karpathy.ai/zero-to-hero.html",
  "steps": ["Ouvrez la page « Neural Networks: Zero to Hero » d'Andrej Karpathy", "Repérez la première vidéo et sa durée", "Repérez la vidéo de la série consacrée à la rétropropagation tensorielle faite à la main"],
  "question": "Quelle est la durée de la vidéo 1 (micrograd), et quel est le titre de la vidéo qui fait refaire à la main la rétropropagation sur des tenseurs ?",
  "hint": "Ce titre parle de devenir un « ninja ».",
  "answer": "Environ 2 h 25 pour « The spelled-out intro to neural networks and backpropagation: building micrograd » ; la vidéo 5 s'intitule « Building makemore Part 4: Becoming a Backprop Ninja » (environ 1 h 55). Page consultée en nov. 2026.",
  "xp": 10
}
```

- [PyTorch — A Gentle Introduction to torch.autograd](https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html) 🇬🇧 — la version industrielle de ce que vous venez d'écrire.

> 🗺️ **Et maintenant ?** — Vous savez ce qui se passe sous le capot ; la leçon L123 vous fait passer à PyTorch, qui fait la même chose sur des tenseurs, sur GPU, avec plus de 2 000 opérations déjà dérivées pour vous.
