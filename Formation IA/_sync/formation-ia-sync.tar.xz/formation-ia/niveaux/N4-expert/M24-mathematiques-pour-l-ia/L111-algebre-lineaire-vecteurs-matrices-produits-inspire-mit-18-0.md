---
id: L111
module: M24
level: N4
title: "Algèbre linéaire : vecteurs, matrices, produits (inspiré MIT 18.06)"
minutes: 80
objectives:
  - "Manipuler vecteurs, matrices, produit matriciel et transposée en notation mathématique et en NumPy"
  - "Calculer une norme, un produit scalaire et une similarité cosinus et les relier aux embeddings"
  - "Expliquer ce que font une couche linéaire et le score d'attention en termes de produits matriciels"
  - "Interpréter intuitivement valeurs propres, vecteurs propres et décomposition en valeurs singulières (SVD)"
skills: ["C4.1"]
sources:
  - { title: "MIT OCW 18.06 Linear Algebra (Gilbert Strang) — vidéos", url: "https://www.ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/video_galleries/video-lectures", lang: "en" }
  - { title: "MIT 6.390 IntroML — Fall 2026 (prérequis d'algèbre linéaire)", url: "https://introml.mit.edu/fall26/info", lang: "en" }
  - { title: "3Blue1Brown — Neural Networks (dont « Attention in transformers »)", url: "https://www.3blue1brown.com/topics/neural-networks", lang: "en" }
  - { title: "NumPy — documentation officielle", url: "https://numpy.org/doc/stable/", lang: "en" }
  - { title: "Deep Learning (Goodfellow, Bengio, Courville) — chap. 2 Linear Algebra", url: "https://www.deeplearningbook.org/", lang: "en" }
---

# Algèbre linéaire : vecteurs, matrices, produits (inspiré MIT 18.06)

> ⏱ 80 min · 🎯 Niveau 4 · 📚 Module 24

## 🎯 Ce que vous saurez faire
- Lire une formule de deep learning comme $y = Wx + b$ ou $\text{softmax}(QK^\top/\sqrt{d_k})V$ sans sauter une ligne.
- Calculer à la main (et vérifier en NumPy) un produit matriciel, une transposée, une norme et une similarité cosinus.
- Expliquer pourquoi un embedding est un vecteur, pourquoi une couche linéaire est une matrice et pourquoi l'attention est « un produit de matrices suivi d'une moyenne pondérée ».
- Donner l'intuition des valeurs propres et de la SVD, et citer deux endroits où elles servent en IA (PCA, LoRA).

> 🧭 **En clair** — Pour un ordinateur, tout est une liste de nombres : une photo, un mot, un client. Cette liste s'appelle un **vecteur**, et on peut l'imaginer comme une flèche dans l'espace ; deux flèches qui pointent dans la même direction représentent deux choses qui se ressemblent. Une **matrice** est une machine qui transforme ces flèches (les étire, les tourne), un peu comme un filtre photo qui transforme toutes les images de la même façon. Un réseau de neurones n'est qu'une longue chaîne de ces machines. Si vous comprenez « flèche », « machine à transformer » et « appliquer la machine », vous pouvez lire l'essentiel des formules d'IA.

## 1. Pourquoi l'IA moderne est de l'algèbre linéaire

Ouvrez n'importe quel fichier de poids d'un modèle de langage ouvert : vous n'y trouverez ni règles, ni phrases, seulement des **tableaux de nombres**. Un modèle de 7 milliards de paramètres, c'est 7 milliards de coefficients rangés dans quelques centaines de matrices. L'inférence consiste à multiplier ces matrices entre elles et par les vecteurs qui représentent vos tokens. Les GPU ne sont rien d'autre que des machines à multiplier des matrices très vite.

Gilbert Strang ouvre son cours MIT 18.06 (35 vidéos, CC BY-NC-SA) par « la géométrie des équations linéaires » : une matrice, ce n'est pas un tableau inerte, c'est une **transformation** qui déplace, étire et tourne les vecteurs. C'est cette lecture géométrique que nous allons adopter, parce qu'elle est celle qui éclaire les réseaux de neurones. Nous nous concentrons sur le sous-ensemble du cours qui sert tous les jours en IA : vidéos 1-3 (produits), 5 (transposée), 14-16 (orthogonalité, projections), 21-22 (valeurs propres) et 29 (SVD).

> 💡 **À retenir** — Trois objets suffisent pour lire 95 % des formules d'IA : le **vecteur** (une donnée, un embedding), la **matrice** (une transformation, une couche) et le **produit** (appliquer la transformation). Tout le reste est du vocabulaire autour de ces trois idées.

## 2. Vecteurs : la donnée comme point dans l'espace

Un vecteur $x \in \mathbb{R}^n$ est une liste ordonnée de $n$ nombres réels : $x = (x_1, x_2, \dots, x_n)$. En IA, on le lit de deux manières complémentaires :

- **comme une donnée** : les 784 pixels d'une image MNIST forment un vecteur de $\mathbb{R}^{784}$ ; le token « facture » dans un LLM est représenté par un vecteur de $\mathbb{R}^{4096}$ (sa dimension d'embedding) ;
- **comme une flèche** : un point dans un espace à $n$ dimensions, avec une direction et une longueur.

La seconde lecture est la plus féconde. Deux tokens « proches de sens » auront des flèches qui pointent dans des directions voisines ; c'est toute l'idée des *embeddings* (plongements) que vous avez utilisés dans le pipeline RAG du module 20.

### 2.1 Opérations de base

Addition et multiplication par un scalaire se font coordonnée par coordonnée : $(x + y)_i = x_i + y_i$ et $(\lambda x)_i = \lambda x_i$. Cela paraît trivial, mais c'est ce qui autorise l'arithmétique sur les sens, popularisée par word2vec (Mikolov et al., 2013) : $\text{roi} - \text{homme} + \text{femme} \approx \text{reine}$.

### 2.2 Produit scalaire et norme

> 🧠 **L'intuition d'abord** — Le produit scalaire répond à une question simple : « ces deux listes de nombres vont-elles dans le même sens ? ». On multiplie les nombres deux à deux puis on additionne : si les grands nombres de l'un tombent en face des grands nombres de l'autre, le total est grand. **Analogie :** deux amis notent 10 films de 1 à 5 ; multipliez leurs notes film par film et additionnez. Si leurs goûts concordent (5 en face de 5, 1 en face de 1), le score est élevé ; s'ils ne sont jamais d'accord, il est faible. C'est exactement ce que fait un site de recommandation.

Le **produit scalaire** (*dot product*) de deux vecteurs de même dimension est la somme des produits coordonnée à coordonnée :

$$x \cdot y = x^\top y = \sum_{i=1}^{n} x_i\, y_i$$

La **norme euclidienne** (norme $L_2$) est la longueur de la flèche : $\|x\|_2 = \sqrt{x \cdot x} = \sqrt{\sum_i x_i^2}$. La norme $L_1$, $\|x\|_1 = \sum_i |x_i|$, sert aussi (régularisation Lasso, module 25). Le produit scalaire possède une interprétation géométrique capitale :

$$x \cdot y = \|x\|\,\|y\|\cos\theta$$

où $\theta$ est l'angle entre les deux flèches. Un produit scalaire positif signifie « même direction », nul signifie « orthogonal » (perpendiculaire, aucune information commune), négatif « directions opposées ».

> 💡 **Autrement dit** — La norme, c'est la **longueur** de la flèche (le théorème de Pythagore généralisé à $n$ dimensions). Le produit scalaire mélange deux informations : la longueur des deux flèches et l'angle qui les sépare. Même sens → positif, angle droit → zéro, sens opposés → négatif.

### 2.3 Similarité cosinus : le cœur du RAG

> 🧠 **L'intuition d'abord** — Un texte long « pèse » plus qu'un texte court : sa flèche est plus longue, et son produit scalaire avec n'importe quoi gonfle mécaniquement. Pour comparer uniquement le **sujet**, on ramène toutes les flèches à la même longueur (1) et on ne regarde plus que leur direction. **Analogie :** deux boussoles, l'une de poche, l'autre géante ; peu importe leur taille, on veut seulement savoir si elles indiquent le même cap.

Diviser le produit scalaire par les normes isole l'angle :

$$\text{cos}(x, y) = \frac{x \cdot y}{\|x\|_2\,\|y\|_2} \in [-1, 1]$$

C'est la **similarité cosinus**, la mesure par défaut des bases vectorielles. Elle ignore la longueur des vecteurs pour ne garder que leur orientation : un paragraphe long et un titre court qui parlent du même sujet auront des embeddings de normes très différentes mais de direction proche. Quand une API d'embeddings renvoie des vecteurs **normalisés** ($\|x\| = 1$), la similarité cosinus se réduit au simple produit scalaire — d'où la rapidité des recherches vectorielles.

> 💡 **Autrement dit** — Le cosinus vaut **1** si les deux flèches pointent exactement dans la même direction (même sujet), **0** si elles sont perpendiculaires (sujets sans rapport), **−1** si elles sont opposées. Une base vectorielle de RAG ne fait que chercher les documents dont le cosinus avec votre question est le plus proche de 1.

```python
# Similarité cosinus entre trois « embeddings » jouets (dimension 4)
import numpy as np

facture = np.array([0.9, 0.1, 0.8, 0.0])
devis   = np.array([0.8, 0.2, 0.7, 0.1])
chaton  = np.array([0.0, 0.9, 0.1, 0.8])

def cosinus(a: np.ndarray, b: np.ndarray) -> float:
    """Similarité cosinus = produit scalaire / produit des normes."""
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b)))

print(f"facture / devis  : {cosinus(facture, devis):.3f}")   # ≈ 0.99 : très proches
print(f"facture / chaton : {cosinus(facture, chaton):.3f}")  # ≈ 0.11 : presque orthogonaux
print(f"norme L2 de facture : {np.linalg.norm(facture):.3f}, norme L1 : {np.linalg.norm(facture, 1):.3f}")
```

> ⚠️ **Piège fréquent** — Comparer des embeddings issus de **deux modèles différents** (par exemple un ancien index et un nouveau modèle d'embeddings) n'a aucun sens : les espaces ne sont pas alignés, les axes n'ont pas la même signification. La similarité cosinus ne vaut qu'au sein d'un même espace. Réindexez tout quand vous changez de modèle.

```quiz
{
  "q": "Un paragraphe de 2 000 mots et un titre de 6 mots parlent exactement du même sujet. Leurs embeddings ont des normes très différentes. Que vaut à peu près leur similarité cosinus ?",
  "options": ["Proche de 0, car les longueurs sont trop différentes", "Proche de −1, car le texte long écrase le court", "Proche de 1, car seule la direction compte", "Impossible à dire sans connaître les normes"],
  "answer": 2,
  "explanation": "Le cosinus divise par les normes : la longueur disparaît, seule l'orientation reste. Même sujet = même direction = cosinus proche de 1."
}
```

## 3. Matrices : la transformation

Une matrice $A \in \mathbb{R}^{m \times n}$ est un tableau de $m$ lignes et $n$ colonnes. Appliquée à un vecteur $x \in \mathbb{R}^n$, elle produit un vecteur $Ax \in \mathbb{R}^m$ : elle **transforme** un espace de dimension $n$ en un espace de dimension $m$. Strang insiste sur deux lectures du produit $Ax$ :

1. **Par lignes** : la $i$-ème coordonnée de $Ax$ est le produit scalaire de la ligne $i$ de $A$ avec $x$. Chaque ligne est un « détecteur » qui mesure à quel point $x$ ressemble à un motif.
2. **Par colonnes** : $Ax$ est une **combinaison linéaire des colonnes** de $A$, pondérée par les coordonnées de $x$. L'ensemble des $Ax$ possibles est l'*espace colonne* (vidéo 6).

Les deux lectures sont utiles en IA. La lecture par lignes explique un neurone : chaque ligne de la matrice de poids est un motif que le neurone cherche dans l'entrée. La lecture par colonnes explique pourquoi un réseau ne peut produire que ce que son espace colonne autorise : le **rang** de la matrice (nombre de colonnes indépendantes) borne l'expressivité.

### 3.1 Produit matriciel

> 🧠 **L'intuition d'abord** — Multiplier deux matrices, c'est faire **tous les produits scalaires possibles** entre les lignes de la première et les colonnes de la seconde, et ranger les résultats dans un tableau. **Analogie :** une grille de bataille navale : la case (ligne 3, colonne 5) contient le « score de ressemblance » entre la ligne 3 de $A$ et la colonne 5 de $B$. C'est aussi pourquoi les dimensions doivent coïncider : on ne peut comparer terme à terme que deux listes de même longueur.

Pour $A \in \mathbb{R}^{m \times n}$ et $B \in \mathbb{R}^{n \times p}$, le produit $C = AB \in \mathbb{R}^{m \times p}$ est défini par :

$$C_{ij} = \sum_{k=1}^{n} A_{ik}\, B_{kj}$$

> 💡 **Autrement dit** — Règle mnémotechnique des formes : $(m \times \mathbf{n}) \cdot (\mathbf{n} \times p) \to (m \times p)$. Les deux nombres « du milieu » doivent être égaux et disparaissent ; ceux « de l'extérieur » donnent la taille du résultat.

Autrement dit, $C_{ij}$ est le produit scalaire de la ligne $i$ de $A$ avec la colonne $j$ de $B$. Deux règles non négociables :

- **Compatibilité** : le nombre de colonnes de $A$ doit égaler le nombre de lignes de $B$. C'est la source numéro un des erreurs `shapes (32,128) and (256,64) not aligned` en PyTorch.
- **Non-commutativité** : en général $AB \neq BA$ ; parfois $BA$ n'est même pas défini.

Le produit matriciel est **associatif** ($(AB)C = A(BC)$), ce qui permet de composer des couches : un réseau sans activation non linéaire, $W_3 W_2 W_1 x$, se replierait en une seule matrice $W x$. C'est précisément pourquoi on intercale des fonctions non linéaires (ReLU, GELU) entre les couches : sans elles, la profondeur ne servirait à rien.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : empiler trois couches linéaires sans fonction d'activation entre elles rend le réseau plus expressif qu'une seule couche linéaire.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Par associativité, W3·W2·W1 se replie en une seule matrice W : trois couches linéaires valent une seule couche. C'est la non-linéarité (ReLU, GELU) qui donne son intérêt à la profondeur."
}
```

Calculons à la main un petit produit, pour fixer le mécanisme :

$$A = \begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix},\quad B = \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix},\quad AB = \begin{pmatrix} 1\cdot 0 + 2\cdot 1 & 1\cdot 1 + 2\cdot 0 \\ 3\cdot 0 + 4\cdot 1 & 3\cdot 1 + 4\cdot 0 \end{pmatrix} = \begin{pmatrix} 2 & 1 \\ 4 & 3 \end{pmatrix}$$

$B$ est une matrice de permutation (vidéo 5) : multiplier par $B$ à droite échange les colonnes de $A$. Vérifiez que $BA$ échange au contraire les lignes : $BA = \begin{pmatrix} 3 & 4 \\ 1 & 2 \end{pmatrix} \neq AB$.

### 3.2 Transposée, identité, inverse

La **transposée** $A^\top$ échange lignes et colonnes : $(A^\top)_{ij} = A_{ji}$. Propriété à connaître par cœur : $(AB)^\top = B^\top A^\top$ (l'ordre s'inverse). Une matrice est **symétrique** si $A = A^\top$ ; les matrices de covariance et les matrices $A^\top A$ sont toujours symétriques, et nous verrons que cela leur donne des valeurs propres réelles.

La matrice **identité** $I$ (des 1 sur la diagonale, des 0 ailleurs) ne change rien : $Ix = x$. L'**inverse** $A^{-1}$, quand elle existe, défait la transformation : $A^{-1}A = I$. Une matrice carrée est inversible si et seulement si son déterminant est non nul, c'est-à-dire si elle n'écrase aucune direction. En deep learning, on inverse rarement une matrice explicitement (trop coûteux, $O(n^3)$, et numériquement instable) ; on préfère résoudre des systèmes ou descendre un gradient (leçon L114).

```python
import numpy as np

A = np.array([[1., 2.], [3., 4.]])
B = np.array([[0., 1.], [1., 0.]])

print("AB =\n", A @ B)          # [[2,1],[4,3]] : colonnes échangées
print("BA =\n", B @ A)          # [[3,4],[1,2]] : lignes échangées
print("(AB)^T == B^T A^T :", np.allclose((A @ B).T, B.T @ A.T))
print("A^-1 A =\n", np.linalg.inv(A) @ A)   # identité (aux arrondis près)
print("det(A) =", np.linalg.det(A))         # -2.0 : inversible

# Erreur classique : dimensions incompatibles
try:
    np.ones((32, 128)) @ np.ones((256, 64))
except ValueError as e:
    print("Erreur attendue :", e)
```

> 🔗 **Documentation officielle** — [NumPy : `numpy.linalg`](https://numpy.org/doc/stable/reference/routines.linalg.html) 🇬🇧 — normes, inverse, déterminant, valeurs propres, SVD. Préférez l'opérateur `@` (ou `np.matmul`) à `*`, qui multiplie **terme à terme** (produit de Hadamard), une confusion fréquente.

```mission
{
  "title": "Que renvoie exactement numpy.linalg.svd ?",
  "url": "https://numpy.org/doc/stable/reference/routines.linalg.html",
  "steps": ["Ouvrez la page « Linear algebra (numpy.linalg) » de la documentation NumPy", "Dans la rubrique des décompositions (« Decompositions »), cliquez sur linalg.svd", "Lisez la section « Returns »"],
  "question": "Combien d'objets renvoie np.linalg.svd(A) par défaut, et sous quelle forme sont rangées les valeurs singulières ?",
  "hint": "Regardez le nom et la description du deuxième objet renvoyé : est-ce une matrice ou un simple vecteur ?",
  "answer": "Trois objets (U, S, Vh) ; les valeurs singulières S sont un vecteur 1D trié par ordre décroissant (pas une matrice diagonale : il faut np.diag(S) pour reconstruire A). État de la doc NumPy stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Trois usages en IA : embeddings, couche linéaire, attention

### 4.1 La table d'embeddings est une matrice

Un vocabulaire de $V$ tokens et une dimension $d$ donnent une matrice $E \in \mathbb{R}^{V \times d}$. Chercher l'embedding du token numéro $t$ revient à multiplier $E^\top$ par le vecteur *one-hot* $e_t$ (un 1 en position $t$, des 0 ailleurs) : $E^\top e_t$ sélectionne la ligne $t$. En pratique, on indexe directement la ligne (`E[t]`), mais la formulation matricielle montre que l'embedding est bien une couche linéaire comme les autres, apprise par descente de gradient.

### 4.2 La couche linéaire : $y = Wx + b$

> 🧠 **L'intuition d'abord** — $y = Wx + b$, c'est une **recette pondérée** : chaque sortie est un mélange des entrées, chacune multipliée par un dosage (les poids $W$), plus une pincée fixe (le biais $b$). **Analogie :** un barman qui prépare 4 cocktails à partir de 16 bouteilles : chaque ligne de $W$ est la fiche recette d'un cocktail (combien de chaque bouteille), $b$ est le glaçon ajouté quoi qu'il arrive.

La brique universelle. Une couche `nn.Linear(n, m)` de PyTorch contient une matrice de poids $W \in \mathbb{R}^{m \times n}$ et un vecteur de biais $b \in \mathbb{R}^m$. Pour un **lot** (*batch*) de $B$ exemples rangés en lignes dans $X \in \mathbb{R}^{B \times n}$, on écrit $Y = XW^\top + b$ (le biais est « diffusé », *broadcast*, sur chaque ligne). Le coût est de $B \times n \times m$ multiplications-additions : c'est ce nombre, multiplié par le nombre de couches, qui donne les FLOPs d'un modèle.

> 💡 **Autrement dit** — Une couche linéaire = un tableau de dosages + un petit décalage. « Apprendre », pour cette couche, signifie seulement ajuster les dosages jusqu'à ce que les cocktails aient le goût voulu.

```python
import numpy as np
rng = np.random.default_rng(42)

B, n, m = 8, 16, 4            # 8 exemples, 16 entrées, 4 sorties
X = rng.normal(size=(B, n))
W = rng.normal(size=(m, n)) * 0.1   # même convention que torch.nn.Linear : (sorties, entrées)
b = np.zeros(m)

Y = X @ W.T + b               # (8,16) @ (16,4) -> (8,4)
print(Y.shape)                # (8, 4)
print("FLOPs ≈", 2 * B * n * m)   # 2 opérations (mult + add) par coefficient
```

### 4.3 L'attention : trois matrices et une moyenne pondérée

Le mécanisme d'attention des Transformers (Vaswani et al., « Attention Is All You Need », 2017 ; vidéo « Attention in transformers » de 3Blue1Brown) se lit entièrement avec ce que nous venons de voir. Pour une séquence de $T$ tokens d'embeddings $X \in \mathbb{R}^{T \times d}$, on calcule trois projections linéaires :

$$Q = XW_Q,\qquad K = XW_K,\qquad V = XW_V$$

> 🧠 **L'intuition d'abord** — Chaque mot d'une phrase pose une question (sa **requête** $Q$), chaque mot porte une étiquette (sa **clé** $K$) et un contenu (sa **valeur** $V$). On compare la question de chaque mot aux étiquettes de tous les autres, on transforme ces scores en pourcentages, puis chaque mot repart avec un mélange des contenus des mots les plus pertinents. **Analogie :** dans une bibliothèque, vous tapez votre question (requête), le catalogue compare avec les fiches des livres (clés), et vous repartez avec des extraits des livres les mieux classés (valeurs), en lisant davantage les plus pertinents.

puis la sortie :

$$\text{Attention}(Q, K, V) = \text{softmax}\!\left(\frac{QK^\top}{\sqrt{d_k}}\right) V$$

Décortiquons. $QK^\top \in \mathbb{R}^{T \times T}$ : la case $(i, j)$ est le **produit scalaire** entre la requête (*query*) du token $i$ et la clé (*key*) du token $j$ — une mesure de similarité, exactement comme en §2.3, non normalisée. La division par $\sqrt{d_k}$ évite que ces produits scalaires explosent avec la dimension (la variance d'une somme de $d_k$ termes croît comme $d_k$). Le softmax (leçon L113) transforme chaque ligne en une distribution de probabilités qui somme à 1. Enfin, multiplier par $V$ calcule, pour chaque token, une **moyenne pondérée des valeurs** des autres tokens : le token « il » récupère ainsi l'information du nom qu'il remplace.

> 💡 **Autrement dit** — Trois étapes : (1) **comparer** toutes les paires de mots ($QK^\top$, un tableau $T \times T$) ; (2) **convertir** chaque ligne en pourcentages (softmax) après avoir « calmé » les scores ($\div\sqrt{d_k}$) ; (3) **mélanger** les contenus selon ces pourcentages ($\times V$). Le tableau $T \times T$ explique pourquoi doubler la longueur du texte quadruple le travail.

```
   X (T×d)  ──W_Q──▶ Q (T×d_k) ─┐
   X (T×d)  ──W_K──▶ K (T×d_k) ─┼─▶ Q Kᵀ (T×T) ─/√d_k─▶ softmax ─┐
   X (T×d)  ──W_V──▶ V (T×d_v) ─┘                               └─▶ · V ─▶ sortie (T×d_v)
```

```python
import numpy as np
rng = np.random.default_rng(0)

T, d, dk = 5, 8, 4                     # 5 tokens, embeddings de dim 8, têtes de dim 4
X  = rng.normal(size=(T, d))
WQ, WK, WV = (rng.normal(size=(d, dk)) * 0.5 for _ in range(3))

Q, K, V = X @ WQ, X @ WK, X @ WV       # projections linéaires
scores = Q @ K.T / np.sqrt(dk)         # (5,5) : similarité requête/clé

def softmax(z, axis=-1):
    z = z - z.max(axis=axis, keepdims=True)   # stabilité numérique
    e = np.exp(z)
    return e / e.sum(axis=axis, keepdims=True)

poids = softmax(scores)                # chaque ligne somme à 1
sortie = poids @ V                     # moyenne pondérée des valeurs
print(poids.round(2))
print("somme par ligne :", poids.sum(axis=1).round(6))
print("sortie :", sortie.shape)        # (5, 4)
```

> 💡 **À retenir** — L'attention n'est pas magique : $QK^\top$ est une matrice de similarités, le softmax la transforme en poids, le produit par $V$ fait une moyenne pondérée. Tout le coût quadratique en $T$ (et donc les limites de la fenêtre de contexte) vient de la matrice $T \times T$.


## 5. Valeurs propres, vecteurs propres : les directions privilégiées

> 🧠 **L'intuition d'abord** — Quand une matrice transforme l'espace, presque toutes les flèches changent de direction. Quelques-unes, privilégiées, gardent leur direction et sont seulement allongées ou raccourcies : ce sont les **vecteurs propres**, et le facteur d'allongement est la **valeur propre**. **Analogie :** pétrissez une pâte à pizza en l'étirant dans un seul sens ; un grain de farine posé sur l'axe d'étirement reste sur cet axe (il s'éloigne juste du centre), alors qu'un grain posé en biais change de direction.

Pour une matrice carrée $A$, un vecteur non nul $v$ est un **vecteur propre** (*eigenvector*) de valeur propre (*eigenvalue*) $\lambda$ si :

$$Av = \lambda v$$

Géométriquement, $A$ ne fait que **dilater** $v$ (facteur $\lambda$) sans le faire tourner. Les vecteurs propres sont les « axes naturels » de la transformation (vidéos 21-22 de Strang). Pour une matrice symétrique, les valeurs propres sont réelles et les vecteurs propres orthogonaux : on peut écrire $A = Q\Lambda Q^\top$ avec $Q$ orthogonale ($Q^\top Q = I$) et $\Lambda$ diagonale.

> 💡 **Autrement dit** — $Av = \lambda v$ se lit : « appliquer la machine $A$ à $v$ revient à simplement multiplier $v$ par un nombre ». $\lambda = 3$ : la flèche est triplée ; $\lambda = 1$ : elle ne bouge pas ; $\lambda = -1$ : elle est retournée.

Deux usages en IA :

- **PCA** (analyse en composantes principales, module 25) : les vecteurs propres de la matrice de covariance des données sont les directions de plus grande variance ; garder les $k$ premiers réduit la dimension en perdant le moins d'information possible.
- **Stabilité et conditionnement** : les valeurs propres de la hessienne (leçon L112) indiquent la courbure de la fonction de perte dans chaque direction ; leur rapport (le *conditionnement*) explique pourquoi certaines directions sont lentes à optimiser et pourquoi le momentum (L114) aide.

Prenons $A = \begin{pmatrix} 2 & 1 \\ 1 & 2 \end{pmatrix}$. Le polynôme caractéristique $\det(A - \lambda I) = (2-\lambda)^2 - 1 = 0$ donne $\lambda_1 = 3$ et $\lambda_2 = 1$. Pour $\lambda_1 = 3$ : $(A - 3I)v = 0$ impose $v_1 = v_2$, donc $v = (1, 1)/\sqrt{2}$. Pour $\lambda_2 = 1$ : $v = (1, -1)/\sqrt{2}$. Les deux sont orthogonaux, comme promis pour une matrice symétrique.

## 6. La SVD : la décomposition qui marche pour toute matrice

> 🧠 **L'intuition d'abord** — La SVD affirme que **n'importe quelle** transformation linéaire, aussi compliquée soit-elle, se décompose en trois gestes simples : tourner, étirer le long des axes, tourner encore. Et les étirements sont classés du plus fort au plus faible : on peut garder les plus forts et jeter le reste en perdant peu. **Analogie :** résumer un roman. Les premières valeurs singulières sont l'intrigue principale, les dernières sont les détails de décor ; un bon résumé (approximation de rang faible) garde les premières.

Les valeurs propres n'existent que pour les matrices carrées. La **décomposition en valeurs singulières** (*Singular Value Decomposition*, vidéo 29) fonctionne pour toute matrice $A \in \mathbb{R}^{m \times n}$ :

$$A = U \Sigma V^\top$$

avec $U \in \mathbb{R}^{m \times m}$ et $V \in \mathbb{R}^{n \times n}$ orthogonales, et $\Sigma$ « diagonale » contenant les **valeurs singulières** $\sigma_1 \ge \sigma_2 \ge \dots \ge 0$. Lecture géométrique : toute transformation linéaire est une **rotation** ($V^\top$), puis un **étirement** le long des axes ($\Sigma$), puis une autre **rotation** ($U$). Les $\sigma_i$ sont les racines carrées des valeurs propres de $A^\top A$.

L'intérêt pratique est l'**approximation de rang faible** : en ne gardant que les $r$ premières valeurs singulières, $A_r = U_r \Sigma_r V_r^\top$ est la meilleure approximation de rang $r$ de $A$ (théorème d'Eckart-Young). Avec $r \ll \min(m, n)$, on stocke $r(m + n)$ nombres au lieu de $mn$. C'est l'intuition exacte derrière **LoRA** (module 28) : plutôt que de fine-tuner toute une matrice $W$ de taille $4096 \times 4096$ (16,8 millions de paramètres), on apprend une correction $\Delta W = BA$ avec $B \in \mathbb{R}^{4096 \times r}$, $A \in \mathbb{R}^{r \times 4096}$ et $r = 8$ ou 16, soit moins de 1 % des paramètres. La compression d'image de la vidéo 31 de Strang repose sur la même idée.

> 💡 **Autrement dit** — Une matrice de 4096 × 4096, c'est 16,8 millions de nombres. Si l'essentiel de son « action » tient dans 8 directions, deux fines matrices (4096 × 8 et 8 × 4096, soit 65 536 nombres) suffisent à la décrire presque aussi bien. C'est le pari de LoRA : la correction à apprendre lors d'un fine-tuning est « simple » et tient dans peu de directions.

```quiz
{
  "q": "Une entreprise veut adapter un LLM à son jargon avec LoRA, rang r = 8, sur une matrice 4096 × 4096. Pourquoi est-ce si économique ?",
  "options": ["Parce qu'on n'apprend que deux fines matrices au lieu d'une grande", "Parce que LoRA supprime les couches du modèle jugées inutiles pour le jargon", "Parce que LoRA calcule la SVD complète du modèle à chaque étape", "Parce que le rang 8 divise par 8 la fenêtre de contexte à traiter"],
  "answer": 0,
  "explanation": "ΔW = B·A avec B (4096×8) et A (8×4096) : 2 × 4096 × 8 = 65 536 paramètres, moins de 1 % de la matrice pleine. C'est l'approximation de rang faible de la SVD appliquée à la correction."
}
```

```python
import numpy as np
rng = np.random.default_rng(1)

# Une matrice 64×64 de rang réel 4, bruitée
A_vrai = rng.normal(size=(64, 4)) @ rng.normal(size=(4, 64))
A = A_vrai + 0.05 * rng.normal(size=(64, 64))

U, s, Vt = np.linalg.svd(A)
print("5 premières valeurs singulières :", s[:5].round(2))   # 4 grandes, puis chute brutale

r = 4
A_r = U[:, :r] @ np.diag(s[:r]) @ Vt[:r, :]
print("erreur relative rang 4 :", np.linalg.norm(A - A_r) / np.linalg.norm(A))
print("paramètres : plein =", 64 * 64, "; rang 4 =", r * (64 + 64))
```

> ⚠️ **Piège fréquent** — Les valeurs singulières ne sont **pas** les valeurs propres (sauf pour une matrice symétrique positive). Une matrice peut n'avoir aucune valeur propre réelle (une rotation du plan) et avoir pourtant des valeurs singulières parfaitement définies (toutes égales à 1 pour une rotation).

## 7. Tableau de correspondance : maths ↔ IA

| Notion | Formule | Où elle sert en IA |
|---|---|---|
| Vecteur $x \in \mathbb{R}^d$ | $(x_1, \dots, x_d)$ | embedding d'un token, d'une image, d'un document |
| Produit scalaire | $x^\top y = \sum x_i y_i$ | score d'attention $q \cdot k$, neurone $w \cdot x$ |
| Norme $L_2$ | $\sqrt{\sum x_i^2}$ | normalisation des embeddings, *weight decay*, *gradient clipping* |
| Similarité cosinus | $x^\top y / (\|x\|\,\|y\|)$ | recherche vectorielle (RAG), déduplication |
| Produit matriciel | $C_{ij} = \sum_k A_{ik}B_{kj}$ | couche linéaire, projections Q/K/V, FLOPs |
| Transposée | $(AB)^\top = B^\top A^\top$ | $QK^\top$, rétropropagation (L112) |
| Rang | nb de colonnes indépendantes | expressivité d'une couche, LoRA |
| Valeurs propres | $Av = \lambda v$ | PCA, courbure de la perte, conditionnement |
| SVD | $A = U\Sigma V^\top$ | compression, LoRA, initialisation orthogonale |

## 🧪 Exercice pratique

**Consigne.** Implémentez en NumPy, sans boucle Python, une fonction `top_k_documents(query, docs, k)` qui reçoit un embedding de requête $q \in \mathbb{R}^d$ et une matrice de documents $D \in \mathbb{R}^{N \times d}$, et renvoie les indices des $k$ documents les plus similaires au sens du cosinus. Puis implémentez `attention_multi_tetes(X, WQ, WK, WV, h)` qui découpe les projections en $h$ têtes, calcule l'attention de chaque tête et concatène les sorties.

**Critères de réussite.**
1. `top_k_documents` donne le même résultat qu'une version avec boucle `for`, pour $N = 10\,000$ et $d = 384$, en moins de 50 ms.
2. La somme de chaque ligne des poids d'attention vaut 1 à $10^{-6}$ près, pour chaque tête.
3. Vous savez expliquer, en une phrase chacune, pourquoi on divise par $\sqrt{d_k}$ et pourquoi $QK^\top$ est de taille $T \times T$.

<details>
<summary>Corrigé</summary>

```python
import numpy as np

def top_k_documents(query: np.ndarray, docs: np.ndarray, k: int) -> np.ndarray:
    """Indices des k documents les plus proches (similarité cosinus), sans boucle."""
    q = query / np.linalg.norm(query)
    D = docs / np.linalg.norm(docs, axis=1, keepdims=True)   # normalise chaque ligne
    scores = D @ q                                            # (N,) : cosinus = produit scalaire de vecteurs unitaires
    return np.argsort(-scores)[:k]                            # tri décroissant

def softmax(z, axis=-1):
    z = z - z.max(axis=axis, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=axis, keepdims=True)

def attention_multi_tetes(X, WQ, WK, WV, h):
    """X : (T,d) ; WQ/WK/WV : (d, d_model) ; h têtes de dimension d_model/h."""
    T, _ = X.shape
    d_model = WQ.shape[1]
    dk = d_model // h
    Q, K, V = X @ WQ, X @ WK, X @ WV                           # (T, d_model)
    # Découpage en têtes : (T, h, dk) -> (h, T, dk)
    Qh, Kh, Vh = (M.reshape(T, h, dk).transpose(1, 0, 2) for M in (Q, K, V))
    scores = Qh @ Kh.transpose(0, 2, 1) / np.sqrt(dk)          # (h, T, T)
    poids = softmax(scores)                                    # chaque ligne somme à 1
    sortie = poids @ Vh                                        # (h, T, dk)
    return sortie.transpose(1, 0, 2).reshape(T, d_model), poids

# Tests
rng = np.random.default_rng(0)
docs, q = rng.normal(size=(10_000, 384)), rng.normal(size=384)
ref = sorted(range(10_000), key=lambda i: -(docs[i] @ q) / (np.linalg.norm(docs[i]) * np.linalg.norm(q)))[:5]
assert list(top_k_documents(q, docs, 5)) == ref

X = rng.normal(size=(6, 32))
W = [rng.normal(size=(32, 32)) * 0.1 for _ in range(3)]
out, poids = attention_multi_tetes(X, *W, h=4)
assert out.shape == (6, 32) and np.allclose(poids.sum(-1), 1.0, atol=1e-6)
print("OK")
```

Pourquoi $\sqrt{d_k}$ : un produit scalaire de deux vecteurs de $d_k$ coordonnées indépendantes de variance 1 a une variance $d_k$ ; sans division, le softmax saturerait (un poids à 1, les autres à 0) et ses gradients s'annuleraient. Pourquoi $T \times T$ : chaque token (ligne) compare sa requête à la clé de chaque token (colonne).
</details>

## 🎮 Défi

Sans NumPy, calculez de tête : $\begin{pmatrix} 1 & 0 \\ 0 & -1 \end{pmatrix}$ a-t-elle des valeurs propres réelles ? Lesquelles ? Et la rotation de 90° $\begin{pmatrix} 0 & -1 \\ 1 & 0 \end{pmatrix}$ ? (Réponse : la première est une réflexion, valeurs propres $1$ et $-1$ ; la seconde n'a aucune valeur propre réelle, puisqu'aucun vecteur ne garde sa direction après rotation, mais ses valeurs singulières valent toutes deux 1.)

## ✅ Auto-évaluation express

1. Quelle est la taille de $AB$ si $A \in \mathbb{R}^{3 \times 5}$ et $B \in \mathbb{R}^{5 \times 2}$ ? Et $BA$ ?
2. Deux embeddings ont une similarité cosinus de 0 : que peut-on dire de leurs directions ?
3. Dans $\text{softmax}(QK^\top/\sqrt{d_k})V$, laquelle des trois matrices $Q$, $K$, $V$ est utilisée pour fabriquer la sortie finale par moyenne pondérée ?

**Réponses.** 1. $AB \in \mathbb{R}^{3 \times 2}$ ; $BA$ n'est pas défini ($2 \neq 3$). 2. Elles sont orthogonales : aucune composante commune (dans cet espace d'embeddings). 3. $V$ (les valeurs) ; $Q$ et $K$ ne servent qu'à calculer les poids.

## 📚 Pour aller plus loin
- [MIT OCW 18.06 Linear Algebra — Gilbert Strang, 35 vidéos](https://www.ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/video_galleries/video-lectures) 🇬🇧 — regardez en priorité les vidéos 1-3, 5, 14-16, 21-22 et 29 ; licence CC BY-NC-SA.
- [3Blue1Brown — Neural Networks, chapitre 6 « Attention in transformers, visually explained »](https://www.3blue1brown.com/topics/neural-networks) 🇬🇧 — l'attention vue comme des produits scalaires animés.
- [Deep Learning (Goodfellow, Bengio, Courville), chapitre 2 « Linear Algebra »](https://www.deeplearningbook.org/) 🇬🇧 — le résumé de référence, lisible en ligne gratuitement.
- [NumPy — guide de l'algèbre linéaire](https://numpy.org/doc/stable/reference/routines.linalg.html) 🇬🇧 — toutes les fonctions utilisées dans cette leçon.
- [MIT 6.390 IntroML Fall 2026 — page d'information](https://introml.mit.edu/fall26/info) 🇬🇧 — les prérequis d'algèbre linéaire (rang, produit, inverse, gradients matriciels) attendus pour un cours de ML universitaire.

```mission
{
  "title": "Retrouvez la leçon de Strang consacrée à la SVD",
  "url": "https://www.ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/video_galleries/video-lectures",
  "steps": ["Ouvrez la galerie de vidéos du cours MIT 18.06 (Spring 2010)", "Faites défiler la liste des 35 leçons", "Repérez le numéro et le titre de la leçon sur la décomposition en valeurs singulières, ainsi que le titre de la toute première leçon"],
  "question": "Quel est le numéro de la leçon de Strang sur la SVD, et quel est le titre de la leçon 1 ?",
  "hint": "Cette leçon-ci cite la vidéo 29 et parle de « la géométrie des équations linéaires ».",
  "answer": "Leçon 29 « Singular Value Decomposition » ; leçon 1 « The Geometry of Linear Equations » (galerie OCW consultée en nov. 2026).",
  "xp": 10
}
```

> 🗺️ **Et maintenant ?** — Vous savez ce que fait une matrice ; la leçon L112 vous montre comment mesurer, grâce aux dérivées et au gradient, **dans quel sens modifier** ses nombres pour qu'un modèle se trompe moins.
