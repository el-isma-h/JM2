---
id: L018
module: M04
level: N1
title: "Prompts métiers : rédiger, résumer, analyser, traduire, tabuler"
minutes: 45
objectives:
  - "Construire des prompts fiables pour les cinq familles de tâches professionnelles les plus courantes"
  - "Adapter le même gabarit de prompt à des contextes métier variés (RH, commerce, comptabilité, artisanat)"
  - "Évaluer un résultat généré au regard des critères fixés dans le prompt"
skills: ["C1.3"]
sources:
  - { title: "DeepLearning.AI — ChatGPT Prompt Engineering for Developers (Summarizing, Inferring, Transforming, Expanding)", url: "https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/", lang: "en" }
  - { title: "Anthropic — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "Anthropic — Multilingual support", url: "https://platform.claude.com/docs/en/build-with-claude/multilingual-support", lang: "en" }
  - { title: "Anthropic Cookbook — Summarization guide", url: "https://platform.claude.com/cookbook/capabilities-summarization-guide", lang: "en" }
---

# Prompts métiers : rédiger, résumer, analyser, traduire, tabuler

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 4

## 🎯 Ce que vous saurez faire
- Disposer de cinq gabarits de prompts éprouvés, un par famille de tâche, prêts à adapter à votre poste.
- Repérer, pour chaque famille, le piège spécifique (le résumé qui invente, la traduction trop littérale, le tableau qui change de colonnes).
- Juger un résultat non pas « à l'œil », mais contre les critères que vous avez écrits dans le prompt.

> 🧭 **En clair** — Au bureau, presque tout ce qu'on demande à une IA tient en cinq verbes : **rédiger**, **résumer**, **analyser**, **traduire** et **mettre en tableau**. Pour chacun, cette leçon vous donne une « recette de cuisine » toute prête (un *gabarit*) avec des cases à remplir, comme un formulaire. Chaque recette contient aussi son garde-fou contre l'erreur typique : le résumé qui invente un détail, la traduction trop littérale, le tableau qui devine les valeurs manquantes. Vous n'aurez plus qu'à remplacer les cases `{{ }}` par vos propres documents.

## 1. Cinq verbes qui couvrent 80 % des usages

Le cours de référence de DeepLearning.AI « ChatGPT Prompt Engineering for Developers » organise les usages des modèles en quatre familles : **résumer** (*summarizing*), **déduire** (*inferring* : sentiment, thèmes, catégories), **transformer** (*transforming* : traduction, changement de ton, conversion de format) et **développer** (*expanding* : rédiger à partir de notes). Nous y ajoutons **tabuler**, tant la mise en tableau est centrale dans la vie d'une entreprise.

| Famille | Exemples au bureau | Le risque n° 1 |
|---|---|---|
| Rédiger | e-mail, annonce, fiche produit, compte rendu | le texte générique « qui pourrait être signé par n'importe qui » |
| Résumer | rapport, réunion, fil d'e-mails, veille | l'invention d'un détail absent du document |
| Analyser | avis clients, candidatures, offres fournisseurs | le jugement non justifié, le biais |
| Traduire | contrats, sites web, échanges export | la traduction littérale, la terminologie incohérente |
| Tabuler | factures, contacts, comparatifs | les colonnes qui changent, les valeurs devinées |

Pour chaque famille, vous trouverez ci-dessous un **avant / après** et un **gabarit** réutilisable. Les gabarits utilisent des variables entre doubles accolades `{{ }}` : vous les remplacez à chaque usage. C'est exactement le principe des « templates et variables » recommandé par les guides des éditeurs, et le point de départ de votre bibliothèque personnelle (leçon 19).

## 2. Rédiger

**Avant** : « *Écris une fiche produit pour une chaise de bureau.* » — Résultat : « Découvrez notre chaise ergonomique au design élégant… » Zéro information, zéro différence avec le concurrent.

**Après** :

```
<role>Vous êtes rédacteur e-commerce pour une boutique française de mobilier
reconditionné.</role>
<contexte>
Produit : fauteuil de bureau Steelcase Leap V2 reconditionné (grade A),
garantie 2 ans, livré monté, 389 € TTC. Cible : télétravailleurs qui ont mal au dos
et hésitent entre neuf bas de gamme et reconditionné haut de gamme.
</contexte>
<tache>Rédigez la fiche produit.</tache>
<format>
Titre (70 caractères max) ; accroche (2 phrases) ; 4 puces « bénéfices » ;
paragraphe « reconditionné, concrètement » (60 mots) ; 1 phrase d'appel à l'action.
Vouvoiement, ton franc et rassurant, sans superlatif creux.
</format>
<contraintes>
Ne citez aucune caractéristique technique absente du contexte ; n'inventez
pas d'avis client ; mentionnez la garantie et le délai de livraison seulement
s'ils figurent ci-dessus.
</contraintes>
```

> 💡 **Autrement dit** — Les doubles accolades `{{ }}` sont des **cases à remplir**, comme les pointillés d'un formulaire administratif : `{{texte}}` veut dire « collez votre texte ici ». Le reste du gabarit ne change pas d'une fois sur l'autre.

**Gabarit « Rédiger »** : rôle + cible + bénéfice principal + structure imposée + ton + interdiction d'inventer. Astuce supplémentaire issue de la leçon 16 : collez un ou deux textes maison dans `<exemples_de_ton>` et le modèle adoptera votre voix.

> ⚠️ **Piège fréquent** — Oublier la cible. Un même produit se décrit différemment pour un acheteur public, un particulier ou un revendeur. Sans cible, le modèle choisit le lecteur « moyen », qui n'existe pas.

```quiz
{
  "type": "mise_en_situation",
  "q": "Vous faites rédiger la fiche d'un fauteuil reconditionné. Laquelle de ces consignes évite le plus le texte « qui pourrait être signé par n'importe qui » ?",
  "options": [
    "« Fais un texte élégant, chaleureux, vraiment vendeur et mémorable. »",
    "« Utilise beaucoup de superlatifs et d'adjectifs forts. »",
    "« Écris au moins 500 mots, en trois paragraphes. »",
    "« Cible : télétravailleurs au dos fragile, tentés par du neuf. »"
  ],
  "answer": 3,
  "explanation": "Sans cible, le modèle écrit pour un lecteur « moyen » qui n'existe pas. Préciser qui lit et ce qui le fait hésiter oriente tout le texte vers des arguments utiles. Ici, la cible hésite entre ce fauteuil reconditionné et un modèle neuf."
}
```

## 3. Résumer

Le résumé est la tâche où la **fidélité** compte le plus. Le guide de résumé du cookbook Anthropic insiste sur trois réglages : préciser **pour qui** (le niveau de détail dépend du lecteur), **quoi garder** (décisions ? chiffres ? risques ?) et **sous quelle forme** (puces, paragraphe, tableau).

**Avant** : « *Résume cette réunion.* » (transcription de 50 minutes)

**Après** :

```
<role>Vous êtes assistant de direction dans une PME du bâtiment.</role>
<tache>Résumez la transcription ci-dessous pour la directrice, absente.</tache>
<format>
1. « Décisions prises » : puces, une décision par puce, avec qui l'a validée.
2. « Actions » : tableau Action | Responsable | Échéance.
3. « Points en suspens » : puces.
4. « Chiffres cités » : liste exacte (montant, contexte).
200 mots maximum hors tableau.
</format>
<contraintes>
Utilisez uniquement le contenu de la transcription. Si un responsable ou une
échéance n'est pas mentionné, écrivez « non précisé ». Ne reformulez pas les
chiffres (pas d'arrondi). Signalez entre crochets les passages inaudibles.
</contraintes>
<transcription>
{{texte}}
</transcription>
```

**Gabarit « Résumer »** : lecteur + ce qu'il faut garder + structure + « uniquement le contenu fourni » + « non précisé » si absent. Cette dernière consigne est votre meilleure assurance contre l'invention.

> 💡 **À retenir** — Un résumé se commande comme un plat : pour qui, quelle taille, quels ingrédients. Et on demande toujours au modèle de dire « non précisé » plutôt que de combler les trous.

## 4. Analyser

Analyser, c'est **déduire** : un sentiment, une catégorie, une conformité, une priorité. La règle d'or : exigez une **justification observable** (citation, critère) pour chaque jugement, sinon vous ne pouvez pas contrôler.

**Avant** : « *Que pensent nos clients ?* » (100 avis collés) — Réponse : « Globalement positifs avec quelques points d'amélioration. » Vous n'avez rien appris.

**Après** :

```
<role>Vous êtes analyste qualité pour une chaîne de salons de coiffure.</role>
<tache>
Analysez les avis ci-dessous.
1. Classez chaque avis : POSITIF / NEUTRE / NÉGATIF.
2. Identifiez les 5 thèmes les plus fréquents (ex. attente, prix, accueil).
3. Pour chaque thème : nombre d'avis concernés, sentiment dominant, et UNE
   citation textuelle représentative (copiée telle quelle, entre guillemets).
4. Proposez 3 actions concrètes classées par impact estimé, en précisant sur
   quels avis vous vous fondez.
</tache>
<format>Tableau pour l'étape 3 ; puces pour le reste ; aucun préambule.</format>
<contraintes>
Ne créez pas de thème présent dans moins de 3 avis. N'attribuez pas d'intention
aux clients au-delà de ce qu'ils écrivent. Si un avis est ambigu, classez-le
NEUTRE et dites pourquoi.
</contraintes>
<avis>
{{avis}}
</avis>
```

**Gabarit « Analyser »** : critères de classement explicites + seuils (« moins de 3 avis ») + citation obligatoire + traitement des cas ambigus. La même structure sert pour présélectionner des CV (attention : voir le module 7 sur les biais et les obligations de l'AI Act pour le recrutement), comparer des devis ou prioriser des tickets.

```quiz
{
  "q": "Dans un prompt de résumé, quelle consigne est votre meilleure assurance contre l'invention d'un détail ?",
  "options": [
    "« Fais un résumé très court, en trois lignes maximum. »",
    "« Contenu fourni uniquement ; sinon, écrivez “non précisé”. »",
    "« Sois créatif dans la reformulation. »",
    "« Arrondis les chiffres pour plus de lisibilité. »"
  ],
  "answer": 1,
  "explanation": "Le modèle a tendance à combler les trous. En lui demandant explicitement d'écrire « non précisé », vous rendez visibles les informations absentes au lieu de les voir inventées."
}
```

## 5. Traduire

Les modèles de 2026 traduisent remarquablement bien… quand on leur dit **quelle** traduction on veut. La page « Multilingual support » d'Anthropic indique que ses modèles couvrent un large éventail de langues avec de bonnes performances ; le vrai sujet n'est plus la langue, c'est le **registre** et la **terminologie**.

**Avant** : « *Traduis ce mail en anglais.* » — Résultat : un anglais correct mais « *Dear Sir or Madam* » pour un client que vous tutoyez depuis trois ans, et « *quotation* » là où votre entreprise dit toujours « *quote* ».

**Après** :

```
<tache>Traduisez l'e-mail ci-dessous du français vers l'anglais.</tache>
<contexte>
Destinataire : acheteur d'une PME irlandaise, relation cordiale et informelle
depuis 3 ans. Secteur : menuiserie aluminium.
</contexte>
<glossaire>
devis → quote ; menuiserie aluminium → aluminium joinery ; pose → installation ;
acompte → deposit
</glossaire>
<format>
Anglais britannique. Registre informel-professionnel (prénom, « Hi Sean »).
Conservez la mise en page (paragraphes, liste). Ne traduisez pas les noms de
produits ni les références. Après la traduction, listez en 3 puces maximum
les choix de traduction discutables.
</format>
<email>
{{texte}}
</email>
```

**Gabarit « Traduire »** : langue cible + variante (britannique/américain, Québec/France…) + registre + glossaire + éléments à ne pas traduire + liste des doutes. Le glossaire est la clé de la cohérence sur la durée : conservez-le dans votre bibliothèque et enrichissez-le.

> ⚠️ **Piège fréquent** — Faire traduire un contrat ou une notice de sécurité sans relecture humaine qualifiée. Le modèle produit une **version de travail**, pas un document opposable. Pour l'export, une relecture par un locuteur natif reste la norme.

## 6. Tabuler

Mettre en tableau, c'est **extraire** des données puis les **normaliser**. Le piège est double : les colonnes qui varient d'une exécution à l'autre, et les valeurs « devinées » pour remplir les trous.

**Avant** : « *Fais un tableau de ces factures.* » (10 factures scannées en PDF)

**Après** :

```
<tache>Extrayez les informations des factures ci-dessous dans un tableau.</tache>
<format>
Tableau Markdown avec exactement ces colonnes, dans cet ordre :
Fournisseur | N° facture | Date (JJ/MM/AAAA) | HT (€) | TVA (€) | TTC (€) | Échéance
Une ligne par facture, dans l'ordre d'apparition. Montants avec deux décimales,
virgule décimale, sans symbole €. Après le tableau : une ligne « TOTAL TTC ».
</format>
<contraintes>
Si une valeur est illisible ou absente : « — », jamais une estimation.
Si le TTC indiqué ne correspond pas à HT + TVA, ajoutez une colonne finale
« Alerte » avec « ÉCART ». Aucun texte avant le tableau.
</contraintes>
<factures>
{{documents}}
</factures>
```

**Gabarit « Tabuler »** : colonnes nommées et ordonnées + format de chaque colonne + règle pour les valeurs manquantes + contrôle de cohérence + « aucun texte avant ». Au niveau 3, cette consigne deviendra un schéma de sortie structurée ; au niveau 2, elle alimentera un tableur automatiquement.

> 🔗 **Documentation officielle** — Les sections « Control the format of responses » et « Controlling output formatting » du guide [Anthropic — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 décrivent les leviers de mise en forme ; le [guide de résumé du cookbook Anthropic](https://platform.claude.com/cookbook/capabilities-summarization-guide) 🇬🇧 détaille les réglages du résumé.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : si une facture scannée est illisible sur le montant de TVA, il est préférable que l'IA estime une valeur plausible pour que le tableau soit complet.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Une valeur devinée est pire qu'une case vide, car elle passe inaperçue. La consigne doit imposer « — » pour toute valeur illisible ou absente, et signaler les écarts entre HT + TVA et TTC."
}
```

## 7. Le tableau récapitulatif des cinq gabarits

| Famille | Composants indispensables | Consigne anti-erreur |
|---|---|---|
| Rédiger | rôle, cible, bénéfice, structure, ton | « n'inventez aucune caractéristique absente du contexte » |
| Résumer | lecteur, quoi garder, structure, longueur | « uniquement le contenu fourni ; “non précisé” si absent » |
| Analyser | critères, seuils, format, cas ambigus | « une citation textuelle par jugement » |
| Traduire | langue + variante, registre, glossaire, exclusions | « listez vos doutes de traduction » |
| Tabuler | colonnes ordonnées, formats, valeurs manquantes | « — » jamais une estimation ; contrôle de cohérence » |

## 8. 🎮 Défi : le prompt caméléon

Prenez le gabarit « Résumer » et adaptez-le en trois minutes à : a) un fil de 25 e-mails sur un litige fournisseur, pour un avocat ; b) un article scientifique sur la nutrition, pour la newsletter d'une salle de sport ; c) le compte rendu d'un conseil municipal, pour un commerçant qui veut savoir si sa rue sera en travaux. Qu'est-ce qui change ? Qu'est-ce qui reste ?

*(Réponse : la structure et les contraintes de fidélité restent ; le lecteur, ce qu'il faut garder et le vocabulaire changent.)*

```mission
{
  "title": "Les quatre familles d'usages du cours DeepLearning.AI",
  "url": "https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/",
  "steps": ["Ouvrez la page du cours « ChatGPT Prompt Engineering for Developers »", "Faites défiler jusqu'à la liste des leçons (« Course outline » ou « What you'll learn »)", "Repérez les quatre leçons qui portent un verbe en « -ing »"],
  "question": "Quels sont les quatre verbes en anglais qui servent de titres aux leçons d'usage du cours, et à quelle famille de cette leçon correspond chacun ?",
  "hint": "La section 1 de cette leçon en donne une traduction ; la cinquième famille, « tabuler », est un ajout de Next Formation.",
  "answer": "Summarizing (résumer), Inferring (déduire / analyser), Transforming (transformer / traduire), Expanding (développer / rédiger) — état au 1er nov. 2026.",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Choisissez **deux** familles parmi les cinq, celles qui correspondent le mieux à votre poste. Pour chacune, adaptez le gabarit à un cas réel (documents anonymisés), exécutez-le, puis **notez le résultat** sur une grille à quatre critères : fidélité (rien d'inventé), format respecté, utilité immédiate (prêt à l'emploi ?), ton. Corrigez le prompt une fois et ré-exécutez.

**Critères de réussite.**
- Les deux prompts contiennent les composants indispensables de leur famille (tableau section 7).
- La grille est remplie pour les deux exécutions (avant et après correction).
- Au moins un critère s'améliore après correction, et vous savez expliquer grâce à quelle modification.
- Aucune donnée personnelle réelle n'a été envoyée (anonymisation faite avant).

**Pistes de corrigé.** Les corrections les plus fréquentes sont : ajouter la cible (rédiger), ajouter « non précisé » (résumer), exiger une citation (analyser), ajouter un glossaire (traduire), fixer l'ordre des colonnes (tabuler). Si votre premier essai était déjà bon, durcissez le cas : un document plus long, des données plus sales.

## ✅ Auto-évaluation express

1. **Quelle consigne protège un résumé contre l'invention ?**
   → « Utilisez uniquement le contenu fourni ; écrivez “non précisé” si l'information manque. »
2. **Pourquoi exiger une citation dans un prompt d'analyse ?**
   → Pour pouvoir vérifier chaque jugement du modèle dans le texte source.
3. **Quel élément garantit la cohérence terminologique d'une traduction sur la durée ?**
   → Un glossaire conservé et enrichi dans votre bibliothèque de prompts.

## 📚 Pour aller plus loin
- [DeepLearning.AI — ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) 🇬🇧 — les leçons « Summarizing », « Inferring », « Transforming », « Expanding » ont inspiré cette typologie.
- [Anthropic — Multilingual support](https://platform.claude.com/docs/en/build-with-claude/multilingual-support) 🇬🇧 — performances multilingues des modèles Claude et conseils.
- [Anthropic Cookbook — Summarization guide](https://platform.claude.com/cookbook/capabilities-summarization-guide) 🇬🇧 — techniques de résumé (pour les curieux, avec du code).
- [Google — AI Essentials (Coursera)](https://www.coursera.org/google-specializations/ai-essentials-google) 🇬🇧 — le cours « Discover the Art of Prompting » couvre les mêmes familles d'usages.

> 🗺️ **Et maintenant ?** — Vous avez cinq gabarits métiers ; la leçon L019 vous apprend à les tester, à les améliorer méthodiquement et à les ranger dans une bibliothèque de prompts personnelle.
