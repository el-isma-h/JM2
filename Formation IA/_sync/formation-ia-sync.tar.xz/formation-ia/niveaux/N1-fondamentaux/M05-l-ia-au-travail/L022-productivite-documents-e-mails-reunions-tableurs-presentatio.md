---
id: L022
module: M05
level: N1
title: "Productivité : documents, e-mails, réunions, tableurs, présentations"
minutes: 45
objectives:
  - "Appliquer une procédure pas à pas pour produire un document, un e-mail, un compte rendu de réunion, une analyse de tableur et une présentation avec un assistant IA"
  - "Choisir entre un assistant intégré (Microsoft 365 Copilot, Gemini dans Workspace) et un assistant généraliste (Claude, ChatGPT) selon l'endroit où vivent les documents"
  - "Construire une chaîne de travail complète : notes brutes → compte rendu → e-mail → diapositives, avec relecture à chaque étape"
  - "Identifier les trois réflexes de sécurité à garder avant de coller un document dans un assistant"
skills: ["C1.2", "C1.3", "C1.4"]
sources:
  - { title: "Claude Academy — Introduction to Claude Cowork", url: "https://academy.claude.com/courses/introduction-to-claude-cowork", lang: "en" }
  - { title: "Claude Academy — Claude 101 (projects, artifacts, skills, connecting your tools)", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "Claude Platform — Agent Skills overview (skills docx, xlsx, pptx, pdf)", url: "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview", lang: "en" }
  - { title: "Claude Platform — PDF support", url: "https://platform.claude.com/docs/en/build-with-claude/pdf-support", lang: "en" }
  - { title: "Claude Platform — Prompting best practices (document creation, format control)", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "OpenAI Academy — catalogue des cours", url: "https://academy.openai.com/pages/courses", lang: "en" }
  - { title: "Google AI Professional Certificate (Gemini dans Workspace)", url: "https://www.coursera.org/professional-certificates/google-ai", lang: "en" }
  - { title: "Microsoft Learn — guide d'étude AI-900 (remplacé par AI-901)", url: "https://learn.microsoft.com/certifications/resources/study-guides/AI-900", lang: "en" }
---

# Productivité : documents, e-mails, réunions, tableurs, présentations

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 5

## 🎯 Ce que vous saurez faire
- Suivre cinq procédures pas à pas (document, e-mail, réunion, tableur, présentation) dans l'outil que votre entreprise met à votre disposition.
- Décider en trente secondes si vous travaillez dans l'assistant intégré à votre suite bureautique ou dans un assistant généraliste.
- Enchaîner les étapes d'une « chaîne de production » bureautique sans perdre le fil ni la qualité.
- Appliquer trois réflexes de sécurité avant chaque collage de document.

> 🧭 **En clair** — Il existe deux sortes d'assistants : ceux qui « habitent » déjà dans vos logiciels (Copilot dans Word ou Outlook, Gemini dans Gmail), et ceux qu'on va voir dans une fenêtre à part (Claude, ChatGPT). C'est comme choisir entre le commis déjà installé dans votre cuisine, qui connaît vos placards, et un chef à domicile très doué à qui il faut apporter les ingrédients. Cette leçon vous donne cinq recettes pas à pas : un document, un mail, une réunion, un tableur, une présentation. Le fil rouge : l'IA produit le premier jet, vous relisez à chaque étape avant de passer à la suivante.

## 1. Deux familles d'outils, une seule question : où vivent vos documents ?

En novembre 2026, vous avez presque toujours le choix entre deux approches.

| | Assistants intégrés | Assistants généralistes |
|---|---|---|
| Exemples | **Microsoft 365 Copilot** (Word, Excel, PowerPoint, Outlook, Teams), **Gemini** dans Google Workspace (Docs, Sheets, Gmail, Meet) | **Claude** (claude.ai, application de bureau Cowork, extension Chrome, intégration Microsoft 365), **ChatGPT**, Le Chat, Grok |
| Force | L'assistant *voit déjà* vos fichiers, votre agenda, vos mails, en respectant vos droits d'accès | Meilleure maîtrise du prompt, projets et instructions persistantes, formats de sortie riches, choix du modèle |
| Limite | Prompt souvent plus contraint ; licence par utilisateur ; fonctionnalités qui dépendent de l'administrateur | Il faut *apporter* les documents (copier-coller, fichier joint ou connecteur) |
| Quand l'utiliser | Tâche à l'intérieur d'un fichier ou d'une boîte mail existants | Tâche qui combine plusieurs sources, demande un raisonnement long ou un format inhabituel |

Règle simple : **si le document est déjà ouvert devant vous dans Word, Excel, Gmail ou Teams, commencez par l'assistant intégré. Si vous partez de notes éparses ou de plusieurs fichiers, prenez un assistant généraliste.**

> ⚠️ **Piège fréquent** — Microsoft 365 Copilot (licence entreprise, données dans votre *tenant*) et Copilot grand public (copilot.microsoft.com) ne sont pas le même produit ; de même, Claude ou ChatGPT en version gratuite n'offrent pas les garanties des offres Team/Enterprise. Avant de coller un document interne, regardez *dans quelle version* vous êtes (leçon L012). Les détails de licence et les libellés exacts des menus Microsoft cités ci-dessous n'ont pas pu être vérifiés par notre recherche au 1er novembre 2026 : **vérifiez-les sur la documentation officielle de votre éditeur**.

Trois réflexes de sécurité, valables partout :
1. **Anonymiser** ce qui n'a pas besoin d'un nom (clients, salariés, patients).
2. **Vérifier la version** de l'outil (gratuit / payant / entreprise) et les réglages d'historique.
3. **Ne jamais coller** de secret industriel, de mot de passe ou de donnée de santé dans un outil non validé par l'entreprise (module M07).

> 💡 **Autrement dit** — Un *tenant*, c'est l'« espace privé » de votre entreprise chez Microsoft : vos fichiers et mails y restent rangés à part, avec vos règles. La version grand public de Copilot n'a pas ce cloisonnement. Même nom, maisons différentes : regardez toujours à quelle porte vous frappez avant de déposer un document.

```quiz
{
  "q": "Vous avez trois fichiers Word, deux PDF et des notes manuscrites à fusionner en une note de synthèse inhabituelle. Quel outil la règle simple de la section 1 recommande-t-elle ?",
  "options": ["L'assistant intégré de Word, puisque le résultat final sera un fichier .docx", "Aucun : l'IA ne sait pas lire les PDF ni les notes, il faut tout ressaisir", "Un assistant généraliste, car la tâche mêle plusieurs sources", "Copilot grand public, car il est gratuit et ouvre tous les formats"],
  "answer": 2,
  "explanation": "Quand on part de plusieurs sources éparses ou d'un format inhabituel, l'assistant généraliste est plus adapté. L'assistant intégré brille quand le document est déjà ouvert dans la suite bureautique."
}
```

## 2. Procédure n° 1 — Rédiger un document

### 2.1 Avec Microsoft 365 Copilot dans Word
1. Ouvrez un document vide ou un brouillon. Cliquez sur l'icône **Copilot** dans le ruban (ou sur l'icône qui apparaît en marge d'une ligne vide).
2. Dans « Rédiger avec Copilot », décrivez le document : objectif, lecteur, longueur, ton. Ajoutez un fichier de référence si l'option vous est proposée (le fichier doit être dans OneDrive/SharePoint).
3. Générez, puis utilisez **« Conserver »** ou **« Régénérer »**. Un bouton permet d'ajuster (plus court, plus formel).
4. Sélectionnez un paragraphe et demandez une réécriture ciblée plutôt que de régénérer tout le document.
5. Relisez intégralement : Copilot rédige, vous signez.

### 2.2 Avec Claude
1. Sur claude.ai, créez un **Projet** (« Rédaction interne ») et déposez-y vos documents de référence : charte, modèles, glossaire. Dans les instructions du projet, écrivez une fois pour toutes : « Vouvoiement, français de France, 300 mots max par défaut, cite le document source pour chaque fait ».
2. Dans une conversation du projet, collez vos notes ou joignez le fichier (PDF jusqu'à 600 pages et 128 Mo par requête côté plateforme, nov. 2026).
3. Demandez le document avec la structure attendue ; Claude l'ouvre dans un **artefact** (panneau latéral éditable) que vous pouvez faire corriger paragraphe par paragraphe.
4. Pour obtenir directement un fichier **.docx**, demandez-le : les *skills* pré-construits docx, xlsx, pptx et pdf, documentés par Anthropic, produisent le fichier bureautique.
5. Avec l'application de bureau **Claude Cowork** (offres Pro/Max), vous pouvez au contraire pointer un *dossier* de votre ordinateur : Claude lit les fichiers, rédige et enregistre le résultat à côté — le cours gratuit « Introduction to Claude Cowork » détaille l'installation et les bonnes pratiques de sécurité.

### 2.3 Avec ChatGPT
1. Créez un **projet** (dossier de conversations avec fichiers et instructions) ou, plus simplement, joignez vos fichiers à la conversation avec le trombone.
2. Rédigez le prompt (rôle, contexte, tâche, format, contraintes).
3. Ouvrez le résultat dans **Canvas** pour éditer, raccourcir, changer le niveau de langue ou demander une relecture ciblée.
4. Exportez ou copiez dans Word.

> 🔗 **Documentation officielle** — Anthropic décrit la gestion des documents longs et la création de fichiers dans ses [Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 (sections « Document creation » et « Control the format of responses ») et les skills bureautiques dans [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧.

```mission
{
  "title": "Quels fichiers les skills bureautiques de Claude savent-ils produire ?",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview",
  "steps": ["Ouvrez la page Agent Skills overview", "Cherchez la partie sur les skills pré-construits (pre-built Agent Skills)", "Notez la liste des formats de fichiers couverts"],
  "question": "Quels quatre types de fichiers bureautiques les skills pré-construits d'Anthropic permettent-ils de créer ?",
  "hint": "Pensez aux extensions des logiciels Word, Excel, PowerPoint… et au format d'impression universel.",
  "answer": "PowerPoint (.pptx), Excel (.xlsx), Word (.docx) et PDF (nov. 2026 — la liste peut s'allonger) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 3. Procédure n° 2 — Traiter ses e-mails

Les e-mails sont le cas d'usage le plus rentable pour un débutant : fréquent, textuel, facile à vérifier.

**Outlook avec Copilot** : ouvrez un mail → **Résumer** (fil long) ; **Rédiger avec Copilot** → décrivez la réponse → choisissez le ton et la longueur → relisez → envoyez. Copilot peut aussi proposer un « coaching » sur un brouillon (clarté, ton).

**Gmail avec Gemini** : ouvrez le panneau latéral Gemini → « Résume ce fil » ; dans un nouveau message, « Aidez-moi à écrire » → décrivez → « Raffiner » (plus formel, plus court, développer).

**Claude ou ChatGPT** : collez le fil (sans les signatures et données inutiles), puis :

```text
Rôle : tu es mon assistant(e) de rédaction.
Contexte : fil de mails ci-dessous ; je suis le gérant d'une menuiserie ; le client se plaint d'un retard.
Tâche : rédige ma réponse.
Format : 100 mots max, vouvoiement, 1) excuse factuelle, 2) nouvelle date (le 14 novembre), 3) geste commercial (10 %).
Contraintes : ne promets rien d'autre ; pas de formule creuse (« n'hésitez pas ») ; termine par une question fermée.
```

🎮 **Défi « boîte de réception à zéro »** — Prenez vos cinq mails les plus anciens sans réponse. Pour chacun, faites rédiger une réponse par l'assistant avec le prompt ci-dessus adapté, relisez, envoyez. Chronométrez : la plupart des stagiaires passent de 8-10 minutes à 2-3 minutes par mail, **relecture comprise**.

> ⚠️ **Piège fréquent** — Un mail généré se reconnaît : adjectifs en rafale, « j'espère que ce message vous trouve en bonne santé », paragraphes de même taille. Retirez une phrase sur trois et ajoutez un détail que seul vous connaissez : c'est ce qui rend le message crédible.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour qu'un mail rédigé par l'IA paraisse authentique, la leçon conseille d'ajouter un détail que vous seul connaissez et de retirer des phrases.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. Retirer une phrase sur trois et ajouter un détail personnel efface les tics typiques d'un texte généré (adjectifs en rafale, formules creuses)."
}
```

## 4. Procédure n° 3 — Les réunions

### 4.1 Avec Teams et Copilot
1. Avant : demandez à Copilot dans Teams « Prépare-moi cette réunion à partir des mails et fichiers partagés ».
2. Pendant : activez la **transcription** (avec l'accord des participants — c'est une obligation d'information, pas une option de politesse).
3. Après : « Récapitulatif » génère les points clés, les décisions et les actions attribuées ; vous pouvez interroger la réunion (« Qu'a dit Marie sur le budget ? »).
4. Relisez, corrigez les attributions, puis diffusez.

### 4.2 Avec un assistant généraliste
Exportez la transcription (Teams, Google Meet, ou un outil de transcription validé par votre entreprise), collez-la et utilisez le prompt « compte rendu » de la leçon L021 (décisions / actions / points en suspens). Ajoutez : « Signale les passages où la transcription semble incomplète ou ambiguë ».

> 💡 **À retenir** — Un compte rendu IA est excellent pour *ne rien oublier* et médiocre pour *hiérarchiser* : il met au même niveau une décision stratégique et le choix de la salle. Votre valeur ajoutée est la hiérarchie et les nuances politiques, pas la retranscription.

## 5. Procédure n° 4 — Les tableurs

C'est le domaine où les gains sont les plus spectaculaires et les erreurs les plus silencieuses.

### 5.1 Avec Excel et Copilot
1. Convertissez votre plage en **tableau** (Ctrl + L) : Copilot travaille bien mieux sur des tableaux nommés avec des en-têtes propres.
2. Ouvrez Copilot : « Ajoute une colonne qui calcule la marge en % », « Mets en évidence les clients dont le retard dépasse 30 jours », « Quelle est la tendance des ventes par trimestre ? ».
3. Copilot propose une **formule** ou un graphique : lisez la formule avant d'accepter, et vérifiez-la sur deux ou trois lignes à la main.
4. Pour les analyses, demandez d'abord « Décris ce tableau » : si la description est fausse (colonne mal comprise), tout le reste le sera.

### 5.2 Avec Claude ou ChatGPT
1. Exportez la feuille en **CSV** (ou joignez le fichier .xlsx). Supprimez les colonnes nominatives inutiles.
2. Demandez une **lecture d'abord** : « Décris les colonnes, le nombre de lignes, les valeurs manquantes et les anomalies ».
3. Puis l'analyse : « Calcule le total par catégorie et les 5 plus gros écarts ; montre ton calcul ». ChatGPT (analyse de données) et Claude peuvent exécuter du code pour calculer plutôt que « deviner » le résultat : préférez toujours un résultat calculé à un résultat « estimé ».
4. Demandez la **formule Excel équivalente** pour la reporter dans votre fichier : vous gardez la maîtrise et la traçabilité.

```text
Contexte : fichier CSV joint, export des ventes 2026 (colonnes : date, commercial, produit, quantité, prix_unitaire, remise).
Tâche : 1) décris les colonnes et signale les anomalies (doublons, dates futures, remises > 50 %) ;
2) calcule le CA net par commercial et par trimestre ; 3) donne la formule Excel (SOMME.SI.ENS) qui
reproduit le CA net d'un commercial donné.
Contraintes : exécute les calculs, ne les estime pas ; si une colonne est ambiguë, pose-moi la question
avant de calculer.
```

> ⚠️ **Piège fréquent** — Demander « quel est le total ? » à un LLM sans outil de calcul. Un modèle de langage *prédit* des chiffres ; il ne les additionne pas, sauf s'il exécute du code. Exigez le calcul exécuté ou la formule, et contrôlez un sous-total à la main.

> 💡 **Autrement dit** — Un modèle de langage est un champion de l'écriture, pas une calculatrice : il « devine » le chiffre qui a l'air juste. S'il exécute du code (un petit programme de calcul), il compte vraiment. Demandez donc toujours « calcule en exécutant », ou la formule Excel, et vérifiez une ligne à la main.

```quiz
{
  "q": "Mise en situation : Claude vous annonce « le CA net total est de 412 380 € » à partir de votre CSV. Quel est le bon réflexe ?",
  "options": ["Copier le chiffre dans la présentation : l'IA a lu le fichier entier, donc c'est fiable", "Exiger le calcul exécuté ou la formule, et vérifier un sous-total", "Lui demander de répéter la réponse trois fois et garder la moyenne des trois chiffres", "Reformuler la question en anglais pour obtenir un résultat plus précis"],
  "answer": 1,
  "explanation": "Un LLM sans outil de calcul prédit des chiffres plausibles. Le calcul exécuté (ou la formule reportée dans Excel) et un contrôle manuel d'un sous-total garantissent la traçabilité."
}
```

## 6. Procédure n° 5 — Les présentations

1. **Le plan d'abord.** Demandez à l'assistant un plan en 8-10 diapositives avec, pour chacune, un titre « message » (une phrase qui affirme quelque chose) et deux ou trois puces. Validez le plan avant de générer quoi que ce soit : c'est là que vous gagnez du temps.
2. **La génération.** Avec PowerPoint et Copilot : « Créer une présentation à partir de » un document Word ou d'un prompt, puis « Ajouter une diapositive sur… », « Réorganiser ». Avec Claude : demandez le fichier .pptx (skill pptx) ou un artefact ; avec ChatGPT, demandez le contenu structuré puis importez-le dans votre modèle d'entreprise.
3. **Le modèle.** Appliquez toujours la charte graphique de l'entreprise (thème PowerPoint ou Google Slides) ; l'IA génère le contenu, pas l'identité visuelle.
4. **Les notes de l'orateur.** Demandez « Rédige les notes de l'orateur pour chaque diapositive, 60 mots, ton oral » : c'est l'étape que tout le monde oublie et qui fait les bonnes présentations.
5. **La relecture chiffres.** Chaque nombre d'une diapositive doit avoir une source que vous pouvez citer en séance.

## 7. La chaîne complète : des notes au PowerPoint en trente minutes

```
notes brutes (réunion, mails)
   │  prompt « compte rendu » (L021)
   ▼
compte rendu validé ──► prompt « mail de synthèse » ──► e-mail relu et envoyé
   │
   │  prompt « plan en 8 diapositives »
   ▼
plan validé ──► génération (Copilot / Claude / ChatGPT) ──► charte graphique ──► notes de l'orateur ──► relecture chiffres
```

Le secret n'est pas l'outil : c'est de **valider à chaque flèche**. Un compte rendu faux produit un mail faux, puis une présentation fausse, avec un effet boule de neige. La leçon L023 vous donne la méthode de vérification.

```mission
{
  "title": "Les limites des PDF envoyés à Claude",
  "url": "https://platform.claude.com/docs/en/build-with-claude/pdf-support",
  "steps": ["Ouvrez la page PDF support de la documentation Claude", "Cherchez la section sur les limites (PDF support requirements / limits)", "Repérez la taille maximale de requête et le nombre de pages maximal"],
  "question": "Quelle taille maximale de requête et quel nombre maximal de pages la documentation indique-t-elle pour un PDF ?",
  "hint": "Le nombre de pages dépend aussi de la taille de la fenêtre de contexte du modèle.",
  "answer": "128 Mo par requête et 600 pages maximum (100 pages pour les modèles dont le contexte est inférieur à 1 M de tokens) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** À partir de la transcription (fictive) ci-dessous, produisez en moins de 30 minutes, avec l'outil de votre choix : 1) un compte rendu (décisions / actions / points en suspens), 2) un e-mail de synthèse de 100 mots à l'équipe, 3) un plan de présentation de 6 diapositives pour le comité de direction, avec notes de l'orateur.

> « Réunion du 3 novembre, présents : Karim (direction), Léa (commerce), Tom (production). Léa : le client Bertin veut 500 pièces de plus avant le 15 décembre. Tom : impossible sans une équipe de nuit, coût estimé 18 000 €. Karim : on accepte si le client prend 60 % du surcoût, Léa négocie d'ici vendredi. Tom demande aussi le remplacement de la fraiseuse n° 2 — à chiffrer. Prochaine réunion le 10. »

**Critères de réussite.**
- Le compte rendu n'attribue aucune action absente de la transcription (le remplacement de la fraiseuse est « à chiffrer », pas « validé »).
- L'e-mail tient en 100 mots, avec une seule demande claire.
- Chaque diapositive a un titre « message » et non un titre « sujet » (« Le surcoût est couvert à 60 % par le client » et non « Surcoût »).
- Le chiffre 18 000 € apparaît partout à l'identique et les 60 % sont présentés comme *à négocier*, pas acquis.

**Pistes de corrigé.** Décisions : accord de principe conditionné à 60 % du surcoût pris par le client. Actions : Léa négocie (vendredi 7 nov.) ; Tom chiffre la fraiseuse (échéance à définir). En suspens : équipe de nuit (dépend de la négociation). Plan de présentation : 1) contexte de la demande, 2) contrainte de production, 3) surcoût et hypothèse de partage, 4) décision proposée, 5) risques (délai, qualité), 6) prochaines étapes.

## ✅ Auto-évaluation express

1. Dans quel cas préférez-vous l'assistant intégré (Copilot, Gemini) à un assistant généraliste ?
2. Pourquoi faut-il convertir une plage Excel en tableau avant de solliciter Copilot ?
3. Quelle est la première étape pour une présentation, avant toute génération ?

**Réponses.** 1) Quand le document, le mail ou la réunion est déjà dans la suite bureautique : l'assistant voit le contexte et respecte vos droits d'accès. 2) Les en-têtes nommés permettent à l'assistant d'identifier correctement les colonnes ; sans cela, formules et analyses reposent sur une lecture incertaine. 3) Faire valider un plan de 8-10 diapositives avec des titres « message » ; la génération vient après.

## 📚 Pour aller plus loin
- [Introduction to Claude Cowork](https://academy.claude.com/courses/introduction-to-claude-cowork) 🇬🇧 — 2,5 h, gratuit : fichiers et dossiers, Claude dans Chrome, Claude pour Microsoft 365, bonnes pratiques de sécurité.
- [Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 — projets, artefacts, skills et connexion de vos outils.
- [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 — les skills docx/xlsx/pptx/pdf qui produisent vos fichiers.
- [OpenAI Academy — cours](https://academy.openai.com/pages/courses) 🇬🇧 — parcours « Apply AI at Work » (notes → plans d'action, tableurs, résumés avec citations).
- [Google AI Professional Certificate](https://www.coursera.org/professional-certificates/google-ai) 🇬🇧 — modules « AI for Writing and Communicating » et « AI for Data Analysis » avec Gemini dans Workspace.

> 🗺️ **Et maintenant ?** — Vous produisez plus vite ; la leçon L023 vous apprend à vérifier, sourcer et corriger ces productions pour ne jamais diffuser une erreur.

