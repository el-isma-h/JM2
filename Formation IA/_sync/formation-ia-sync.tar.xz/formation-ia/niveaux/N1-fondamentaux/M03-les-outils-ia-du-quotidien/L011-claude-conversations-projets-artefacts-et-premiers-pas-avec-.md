---
id: L011
module: M03
level: N1
title: "Claude : conversations, projets, artefacts et premiers pas avec Claude Code"
minutes: 45
objectives:
  - "Démarrer avec Claude (claude.ai, applications bureau et mobile) et distinguer les modèles Fable, Opus, Sonnet et Haiku"
  - "Organiser son travail avec les projets, les artefacts, les connecteurs et Claude Cowork"
  - "Décrire ce qu'est Claude Code, l'installer et lancer une première demande dans le terminal"
  - "Repérer les cours gratuits de Claude Academy et comprendre le statut des certifications Anthropic"
skills: ["C1.2"]
sources:
  - { title: "Claude Academy — Claude 101", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "Claude Academy — Introduction to Claude Cowork", url: "https://academy.claude.com/courses/introduction-to-claude-cowork", lang: "en" }
  - { title: "Claude Academy — Claude Code 101", url: "https://academy.claude.com/courses/claude-code-101", lang: "en" }
  - { title: "Claude Code — documentation officielle", url: "https://code.claude.com/docs", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Fable 5.1 — fiche modèle", url: "https://platform.claude.com/docs/en/models/fable-5-1/overview", lang: "en" }
  - { title: "Claude Academy — FAQ (badges et certifications)", url: "https://academy.claude.com/help/faq", lang: "en" }
---

# Claude : conversations, projets, artefacts et premiers pas avec Claude Code

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 3

## 🎯 Ce que vous saurez faire
- Ouvrir Claude, choisir le bon modèle et mener une conversation productive avec des fichiers.
- Créer un **projet** avec des instructions et des documents, produire un **artefact** (document, tableau, page web, schéma).
- Expliquer ce qu'apportent Claude Cowork et les connecteurs pour travailler dans vos propres dossiers et outils.
- Installer **Claude Code** et lui confier une première tâche, même sans être développeur.
- Trouver les cours gratuits de Claude Academy et savoir ce que valent leurs badges.

> 🧭 **En clair** — Claude est l'assistant de l'entreprise Anthropic, cousin de ChatGPT. Sa grande force : il peut « lire » des dossiers très épais d'un seul coup et produire des livrables prêts à l'emploi. Pour bien l'utiliser, retenez une image de bureau : la **conversation**, c'est une discussion au café ; le **projet**, c'est un classeur rangé avec vos consignes et vos documents de référence, que Claude relit à chaque nouvelle discussion ; l'**artefact**, c'est le document fini qu'il vous tend (tableau, page, présentation). Et pour aller plus loin, **Cowork** et **Claude Code** permettent de lui confier de vraies tâches sur vos fichiers, toujours avec votre feu vert.

## 1. Qui est Claude ?

Claude est l'assistant d'**Anthropic**, entreprise fondée en 2021 à San Francisco par d'anciens chercheurs d'OpenAI, avec une mission affichée de sûreté de l'IA. Le prénom évoque, selon l'explication la plus souvent rapportée, Claude Shannon, père de la théorie de l'information (1948). Anthropic publie les **instructions système** de ses applications (le texte de cadrage que reçoit le modèle avant votre premier message) : une transparence rare, que vous pouvez consulter sur la plateforme développeur.

Au 1er novembre 2026, la gamme compte quatre modèles principaux, tous dotés d'une fenêtre de contexte de **1 million de tokens** (environ 555 000 mots) et de connaissances arrêtées à juin 2026 :

| Modèle (nov. 2026) | Sortie | Pour quoi faire | Tarif API entrée / sortie ($ par million de tokens) |
|---|---|---|---|
| **Claude Fable 5.1** | 1er sept. 2026 | Les tâches les plus difficiles, raisonnement long | 10 / 50 |
| **Claude Opus 5.5** | 22 sept. 2026 | Travail exigeant au quotidien, agents | 4 / 20 |
| **Claude Sonnet 5.5** | 28 sept. 2026 | Le meilleur rapport qualité/prix pour la plupart des usages | 2 / 10 |
| **Claude Haiku 5.5** | 7 oct. 2026 | Rapidité et volume (tri, classification, réponses courtes) | 0,10 / 0,50 |

Source : pages modèles et Pricing de platform.claude.com (nov. 2026). Dans l'application, un sélecteur permet de choisir le modèle ; selon votre offre, certains sont réservés aux abonnements payants.

> 💡 **À retenir** — Le prix API varie de **1 à 100** entre Haiku et Fable. Dans l'application, cela se traduit par des quotas différents : réservez les gros modèles aux tâches où la qualité compte vraiment.

```quiz
{
  "type": "mise_en_situation",
  "q": "Vous devez trier 5 000 e-mails clients en quatre catégories via l'API. Quel modèle Claude est le plus adapté ?",
  "options": [
    "Claude Fable 5.1, le plus puissant",
    "Claude Opus 5.5, pour les agents",
    "Claude Haiku 5.5, rapide et économique",
    "Peu importe, ils coûtent tous le même prix"
  ],
  "answer": 2,
  "explanation": "Le tri est une tâche simple et répétitive : Haiku 5.5 la fait vite et pour environ 100 fois moins cher que Fable 5.1. On réserve les gros modèles aux tâches où la qualité de raisonnement compte vraiment."
}
```

## 2. Prise en main : votre première conversation

1. Ouvrez [claude.ai](https://claude.ai/) ou installez l'application de bureau (Windows/macOS) ou mobile. Créez un compte avec une adresse e-mail ou un compte Google.
2. Tapez votre demande. Comme ChatGPT, Claude répond en continu et conserve le fil de la conversation. Essayez :

```
Voici le compte rendu de notre réunion d'équipe (collé ci-dessous).
Rédigez un e-mail de suivi de 120 mots maximum, listant les 3 décisions
prises et la personne responsable de chacune. Vouvoiement, ton direct.
```

3. **Joignez des fichiers** (trombone) : PDF, images, feuilles de calcul, textes. Claude lit un PDF de plusieurs centaines de pages d'un coup grâce à son contexte d'un million de tokens : vous pouvez lui donner un contrat de 80 pages et demander « quelles clauses engagent le client au-delà de 12 mois ? ».
4. **Recherche web** : activez-la pour les questions d'actualité ; Claude cite alors ses sources. **Recherche approfondie** (« Research ») : pour une enquête longue avec rapport, décrite dans le cours Claude 101 comme l'outil des « deep dives ».
5. Utilisez les **styles** de réponse (concis, formel, explicatif) et les réglages d'effort de réflexion quand ils sont proposés : un effort élevé produit une réponse plus réfléchie, mais plus lente.

> ⚠️ **Piège fréquent** — Coller un document de 80 pages puis poser dix questions successives dans la même conversation fonctionne, mais chaque question relit tout le document : c'est lent et consomme vos quotas. Pour un travail répété sur les mêmes fichiers, créez un **projet** (section 3).

## 3. Organiser son travail : projets, artefacts, skills, connecteurs

Le cours gratuit **Claude 101** (2,5 h, 13 leçons) d'Anthropic consacre une section entière à « organiser votre travail et vos connaissances ». Voici les quatre briques.

### Projets
Un projet est un espace qui regroupe des **instructions permanentes** (« Vous êtes l'assistant du service RH de la société X ; répondez toujours en français, citez la convention collective Syntec ») et des **documents de référence** (règlement intérieur, grille de salaires, modèles de courriers). Chaque nouvelle conversation ouverte dans le projet hérite de tout cela. Cas typique dans une PME : un projet « Réponses candidats » avec les fiches de poste et la charte de ton ; un projet « Devis » avec la grille tarifaire.

### Artefacts
Quand vous demandez un livrable (document, tableau, page web, schéma, petite application interactive), Claude l'affiche dans un volet séparé appelé **artefact**, que vous pouvez modifier, versionner, télécharger ou publier. Exemple : « Crée un tableau de suivi des congés de l'équipe avec un code couleur » produit une page interactive utilisable immédiatement. Un artefact peut aussi être une présentation ou un fichier Word/Excel grâce aux **skills** intégrés.

### Skills
Un skill est un « mode d'emploi » réutilisable que Claude charge quand la tâche s'y prête : mise en forme de présentations, création de tableurs, rédaction selon votre charte. Anthropic en fournit (pptx, xlsx, docx, pdf) et vous pouvez créer les vôtres ; le module 12 vous apprendra à en écrire.

### Connecteurs
Les connecteurs relient Claude à vos outils (messagerie, agenda, documents, CRM…) via le protocole MCP (module 6). Avec l'accord de l'administrateur, Claude peut lire votre agenda pour préparer la journée ou chercher dans vos documents d'entreprise (« enterprise search »).

> 🔗 **Documentation officielle** — [Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 : cours gratuit de 2,5 h avec badge, sections « Introduction to projects », « Creating with artifacts », « Connecting your tools ».

> 💡 **Autrement dit** — Les quatre briques se rangent comme dans un atelier : le **projet** est l'établi où sont posés vos consignes et vos documents ; l'**artefact** est l'objet fabriqué que vous emportez ; le **skill** est la fiche technique accrochée au mur, que Claude consulte quand il en a besoin ; le **connecteur** est la rallonge qui le relie à vos autres outils (agenda, messagerie, documents).

```quiz
{
  "q": "Vous voulez que Claude applique toujours la même charte de ton et s'appuie sur votre grille tarifaire, dans toutes vos futures conversations sur les devis. Que créez-vous ?",
  "options": [
    "Un artefact partagé avec l'équipe",
    "Une nouvelle conversation à chaque fois, en recollant tout",
    "Un compte Claude par client",
    "Un projet : instructions permanentes + grille en référence"
  ],
  "answer": 3,
  "explanation": "Un projet regroupe des instructions permanentes et des documents de référence : chaque conversation ouverte dedans en hérite. L'artefact, lui, est le livrable produit (tableau, page, document)."
}
```

## 4. Claude Cowork et Claude Tag : l'assistant qui travaille dans vos dossiers

**Claude Cowork** est l'application de bureau orientée tâches : vous lui donnez accès à un dossier de votre ordinateur, et il peut lire, trier, renommer, convertir ou produire des fichiers, naviguer dans Chrome et travailler avec Microsoft 365. Le cours gratuit « Introduction to Claude Cowork » (2,5 h, 14 leçons) détaille : la première tâche confiée, les **instructions globales et projets** (« standing context »), les skills « pour lui apprendre votre façon de faire », les plugins d'équipe, et une section « travailler en sécurité » (quoi autoriser, comment valider un skill avant de l'installer).

Exemple concret pour un cabinet d'architectes : « Dans le dossier *Factures 2026*, renomme chaque PDF au format AAAA-MM-Fournisseur-Montant et produis un tableau récapitulatif ». Cowork lit chaque facture, propose les renommages, attend votre validation, puis exécute.

**Claude Tag** est la version Slack : on mentionne Claude dans un canal, en message privé ou dans un fil, et il répond avec la mémoire du canal. Le cours dédié (2,5 h) explique où lui parler (canal public, privé, DM), comment planifier des routines et comment lui déléguer des travaux continus.

> 💡 **À retenir** — Conversation (claude.ai) = je discute. Cowork = je délègue une tâche sur mes fichiers. Tag = je travaille avec l'équipe dans Slack. Claude Code = je fais produire du code et des automatisations (section 5).

## 5. Premiers pas avec Claude Code

**Claude Code** est un agent qui travaille dans un terminal (ou dans VS Code, JetBrains, l'application de bureau, le web via claude.ai/code et le mobile). Vous lui décrivez un objectif ; il explore les fichiers, propose un plan, écrit ou modifie du code, lance des commandes et vous demande la permission avant toute action sensible. Ce n'est pas réservé aux développeurs : un responsable marketing peut lui demander « convertis ces 40 fichiers CSV en un seul classeur Excel avec un onglet par mois » et obtenir le script et le résultat.

### Installation (nov. 2026, documentation officielle)

```bash
# macOS / Linux : installation native en une ligne
curl -fsSL https://claude.ai/install.sh | bash

# macOS avec Homebrew
brew install --cask claude-code
```

```powershell
# Windows (PowerShell)
irm https://claude.ai/install.ps1 | iex
# ou : winget install Anthropic.ClaudeCode
```

Prérequis indiqués par le cours Claude Code 101 : un éditeur, un terminal et un compte Claude Pro, Max ou Enterprise (ou une clé API). Au premier lancement, la commande `claude` ouvre une session de connexion dans votre navigateur.

### Première demande

```bash
cd mon-dossier-de-travail
claude
```

Puis, dans la session :

```
Explore ce dossier et explique-moi en 5 lignes ce qu'il contient.
Ne modifie rien.
```

Le cours officiel recommande la boucle **explorer → planifier → coder → valider** (« explore → plan → code → commit ») : demandez d'abord une lecture, puis un plan, et seulement ensuite une action. Un fichier `CLAUDE.md` placé dans le dossier sert de mémoire permanente (« ce projet est en Python 3.12, les commentaires sont en français »).

> ⚠️ **Piège fréquent** — Accepter toutes les permissions « pour aller plus vite ». Claude Code demande l'autorisation avant d'écrire ou d'exécuter : lisez ce qu'il propose. Au niveau 1, gardez le mode par défaut et travaillez dans un dossier de test, jamais directement dans vos fichiers de production.

> 🔗 **Documentation officielle** — [Claude Code — Overview et installation](https://code.claude.com/docs) 🇬🇧 et le cours gratuit [Claude Code 101](https://academy.claude.com/courses/claude-code-101) 🇬🇧 (1,5 h, 12 leçons : installation, premier prompt, workflow, CLAUDE.md, skills, MCP, hooks).

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour votre première utilisation de Claude Code, il est conseillé d'accepter toutes les permissions afin d'aller plus vite.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Claude Code demande l'autorisation avant d'écrire ou d'exécuter quoi que ce soit : lisez ce qu'il propose, gardez le mode par défaut et travaillez dans un dossier de test, jamais dans vos fichiers de production."
}
```

## 6. Offres, cours gratuits, certifications : ce qu'il faut savoir

- **Offres.** Claude existe en version gratuite et en abonnements individuels (Pro, Max) et professionnels (Team, Enterprise). Les prix en euros et les quotas changent régulièrement : **consultez la page tarifs officielle** (menu « Mettre à niveau » dans l'application ou le site claude.com) avant de budgéter. Cowork est présenté par Anthropic comme destiné aux utilisateurs Pro/Max (nov. 2026).
- **Claude Academy** ([academy.claude.com](https://academy.claude.com/), ex-Anthropic Academy, renommée le 20 août 2026) : **27 cours gratuits** en anglais, 124 tutoriels, 157 cas d'usage. Les badges sont délivrés à la réussite du dernier quiz, vérifiables publiquement, sans expiration. Pour ce niveau, nous recommandons **Claude 101**, **Introduction to Claude Cowork** et **AI Fluency: Framework and foundations** (4 h, le cadre « 4D » : délégation, description, discernement, diligence).
- **Certifications officielles Anthropic** (Associate, Developer, Architect ; 99 à 175 $, examen Pearson VUE de 120 min, score 720/1000, validité 12 mois) : elles sont **réservées aux employés d'organisations membres du Claude Partner Network**. Un particulier ne peut pas s'y inscrire. Notre formation s'aligne sur leurs domaines (notamment « Product & Model Selection » et « Prompting & Task Execution » du parcours Associate) sans prétendre les délivrer.

## 7. Forces et limites de Claude

**Forces** : très long contexte (1 M de tokens) idéal pour les dossiers volumineux ; qualité de rédaction en français ; artefacts et skills pour produire des livrables finis ; Cowork et Claude Code pour agir sur vos fichiers ; publication des instructions système ; politique de données claire sur les offres professionnelles.

**Limites** : interface un peu moins riche en « gadgets » que ChatGPT (génération d'images absente de l'application, nov. 2026 — Claude décrit ou code un visuel mais ne le peint pas) ; cours et documentation en anglais ; quotas de la version gratuite vite atteints sur les gros modèles ; comme tout LLM, des erreurs factuelles possibles — vérifiez.

## 🎮 Défi
Dans un projet Claude « Ma boutique », déposez trois fiches produits et une instruction « réponds toujours en français, vouvoie, 80 mots maximum ». Ouvrez trois conversations différentes et vérifiez que l'instruction est respectée dans chacune. Puis demandez un artefact : « Crée une page HTML de comparaison de mes trois produits ». Vous venez d'utiliser projets + artefacts.

```mission
{
  "title": "Le programme du cours gratuit Claude 101",
  "url": "https://academy.claude.com/courses/claude-101",
  "steps": ["Ouvrez la page du cours Claude 101 sur Claude Academy", "Notez la durée et le nombre de leçons", "Repérez la leçon consacrée aux artefacts"],
  "question": "Combien de temps dure Claude 101, combien de leçons compte-t-il, et comment s'intitule la section sur les artefacts ?",
  "hint": "Le titre de la section commence par « Creating with… ».",
  "answer": "Environ 2,5 h et 13 leçons ; la section s'intitule « Creating with artifacts » (état au 1er nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Les badges de Claude Academy expirent-ils ?",
  "url": "https://academy.claude.com/help/faq",
  "steps": ["Ouvrez la FAQ de Claude Academy", "Cherchez la question sur les badges (« badges », « certificates »)", "Lisez aussi la différence avec les certifications payantes"],
  "question": "À quel moment un badge Claude Academy est-il délivré, a-t-il une date d'expiration, et en quoi diffère-t-il d'une certification Anthropic ?",
  "hint": "La section 6 de cette leçon résume la réponse ; la mission consiste à la confirmer à la source.",
  "answer": "Le badge est délivré gratuitement à la réussite du dernier quiz d'un cours et n'expire pas ; les certifications (99 à 175 $, valables 12 mois) sont payantes et réservées au Claude Partner Network (nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Vous gérez une petite agence immobilière (4 personnes). Construisez votre environnement de travail dans Claude :
1. Créez un projet « Annonces » avec une instruction permanente (ton, mentions légales obligatoires, longueur) et un document de référence (votre charte ou un exemple d'annonce réussie).
2. Dans ce projet, faites rédiger deux annonces à partir de notes brutes (surface, étage, DPE, prix, quartier).
3. Demandez un artefact : un tableau comparatif des deux biens avec une colonne « points de vigilance ».
4. *Facultatif* : installez Claude Code et demandez-lui de lister le contenu d'un dossier de test et de proposer un classement, sans rien modifier.

**Critères de réussite.**
- L'instruction du projet est appliquée dans toutes les conversations (vérifiez le ton et la longueur).
- Les annonces ne contiennent aucune information inventée par rapport à vos notes (surface, prix, DPE identiques).
- L'artefact est téléchargeable ou publiable et lisible sans retouche.
- Si vous avez installé Claude Code : il a demandé l'autorisation avant toute action, et aucun fichier n'a été modifié.

**Pistes de corrigé.** Une bonne instruction permanente ressemble à : « Vous rédigez des annonces immobilières pour une agence de Nantes. Toujours en français, vouvoiement, 120 mots maximum, mentionner obligatoirement le DPE et les honoraires. Si une information manque, écrivez [À COMPLÉTER] au lieu d'inventer. » Cette dernière phrase est le meilleur rempart contre les hallucinations.

## ✅ Auto-évaluation express

1. Quel modèle Claude choisir pour trier 5 000 e-mails en catégories, et pourquoi ?
2. Quelle différence entre un projet et une conversation ?
3. Un particulier peut-il passer la certification « Claude Certified Associate » ?

**Réponses.** 1) Claude Haiku 5.5 : tâche simple et répétitive, modèle le plus rapide et le moins cher (0,10 $/0,50 $ par million de tokens en API, nov. 2026). 2) Une conversation est un fil unique ; un projet est un espace durable avec instructions permanentes et documents de référence partagés par toutes ses conversations. 3) Non (nov. 2026) : les certifications Anthropic sont réservées aux employés d'organisations du Claude Partner Network ; les badges de Claude Academy, eux, sont gratuits et ouverts à tous.

## 📚 Pour aller plus loin
- [Claude Academy — catalogue](https://academy.claude.com/courses) 🇬🇧 — les 27 cours gratuits, dont Claude 101, Cowork et AI Fluency.
- [Introduction to Claude Cowork](https://academy.claude.com/courses/introduction-to-claude-cowork) 🇬🇧 — 2,5 h pour déléguer des tâches sur vos fichiers en toute sécurité.
- [Claude Code — documentation](https://code.claude.com/docs) 🇬🇧 — installation, quickstart, CLAUDE.md, permissions.
- [Fiche Claude Fable 5.1](https://platform.claude.com/docs/en/models/fable-5-1/overview) 🇬🇧 — caractéristiques du modèle phare (contexte, sortie, effort).
- [FAQ Claude Academy](https://academy.claude.com/help/faq) 🇬🇧 — badges gratuits vs certifications partenaires.

> 🗺️ **Et maintenant ?** — Après ChatGPT et Claude, la leçon L012 passe en revue Gemini, Copilot, Grok et Le Chat, pour savoir lequel s'intègre le mieux à vos outils de travail.
