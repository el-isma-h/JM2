---
id: L010
module: M03
level: N1
title: "ChatGPT : prise en main complète"
minutes: 40
objectives:
  - "Créer un compte ChatGPT, lancer une première conversation et utiliser les fonctions de base (fichiers, voix, recherche web, images)"
  - "Identifier la famille de modèles GPT-6 et comprendre ce que change le choix du modèle"
  - "Appliquer les réglages de confidentialité et les bons réflexes avant de saisir une donnée professionnelle"
  - "Situer ChatGPT par rapport aux offres gratuites et payantes et aux cours gratuits d'OpenAI Academy"
skills: ["C1.2"]
sources:
  - { title: "OpenAI — Models (catalogue des modèles)", url: "https://developers.openai.com/api/docs/models", lang: "en" }
  - { title: "OpenAI — Pricing (tarifs API)", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "OpenAI — Quickstart", url: "https://developers.openai.com/api/docs/quickstart", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "OpenAI Academy — catalogue des cours", url: "https://academy.openai.com/pages/courses", lang: "en" }
  - { title: "ChatGPT (application web)", url: "https://chatgpt.com/", lang: "fr" }
---

# ChatGPT : prise en main complète

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 3

## 🎯 Ce que vous saurez faire
- Ouvrir un compte ChatGPT, démarrer une conversation et tirer parti des principales fonctions de l'interface (nov. 2026).
- Reconnaître les modèles de la famille **GPT-6** et choisir entre rapidité et profondeur de raisonnement.
- Régler la confidentialité de votre compte et décider ce que vous pouvez (ou non) confier à l'outil.
- Expliquer à un collègue ce que ChatGPT fait bien, ce qu'il fait mal, et combien cela coûte.

> 🧭 **En clair** — ChatGPT, c'est un peu le « couteau suisse » de l'IA : une seule application pour discuter, rédiger, résumer un document, chercher sur Internet, créer une image ou parler à voix haute. Comme une voiture, il a un **tableau de bord** (l'application ChatGPT) et un **moteur** (les modèles GPT-6), que l'éditeur OpenAI change régulièrement. Pour bien démarrer, trois réflexes suffisent : être précis dans sa demande, activer la recherche web pour toute question d'actualité, et régler la confidentialité avant d'y confier quoi que ce soit de sensible.

## 1. ChatGPT en une minute : d'où vient-il, où en est-il ?

Le 30 novembre 2022, OpenAI met en ligne une « démo de recherche » baptisée ChatGPT. Cinq jours plus tard, un million de personnes l'ont essayée : jamais un produit numérique n'avait été adopté aussi vite. Près de quatre ans plus tard, ChatGPT est devenu une suite complète : conversation, analyse de fichiers, recherche sur le web, génération d'images, mode vocal, outils pour développeurs et même un catalogue de cours gratuits (OpenAI Academy).

Derrière l'interface se trouvent les modèles d'OpenAI. Au 1er novembre 2026, la page officielle des modèles présente la famille **GPT-6** : `gpt-6-astra` (le modèle phare, connaissances arrêtées au 30 avril 2026), `gpt-6.1-sol`, `gpt-6.1-terra` et `gpt-6-luna` (le plus léger). Tous acceptent un contexte d'environ **1,05 million de tokens** (nov. 2026), c'est-à-dire plusieurs romans d'un coup ; nous avons vu au module 2 que le « contexte » est la mémoire de travail du modèle. L'application grand public, elle, expose un modèle appelé `chat-latest` : c'est la version que vous utilisez quand vous ne choisissez rien.

> 💡 **À retenir** — « ChatGPT » est l'application ; « GPT-6 » est le moteur. Comme pour une voiture, on peut changer le moteur sans changer le tableau de bord : les menus restent, les capacités évoluent.

```quiz
{
  "q": "Quelle phrase décrit le mieux la relation entre « ChatGPT » et « GPT-6 » ?",
  "options": [
    "Ce sont deux concurrents qui appartiennent à des entreprises différentes",
    "GPT-6 est la version payante de ChatGPT",
    "ChatGPT est un ancien nom de GPT-6",
    "ChatGPT est l'application ; GPT-6, les modèles qui la font tourner"
  ],
  "answer": 3,
  "explanation": "Comme le tableau de bord et le moteur d'une voiture : OpenAI peut changer le moteur (les modèles GPT-6) sans changer l'application ChatGPT, dont les menus restent familiers."
}
```

## 2. Prise en main pas à pas

### Étape 1 — Créer un compte
1. Rendez-vous sur [chatgpt.com](https://chatgpt.com/) (ou installez l'application mobile / de bureau).
2. Créez un compte avec une adresse e-mail, un compte Google, Microsoft ou Apple. **Conseil professionnel** : utilisez votre adresse de travail si votre entreprise a souscrit une offre équipe, votre adresse personnelle sinon, mais jamais un compte partagé entre collègues (l'historique est personnel).
3. Vérifiez votre âge et acceptez les conditions d'utilisation. Lisez au moins la section « données » : vous y apprendrez que, par défaut sur un compte individuel, vos conversations peuvent servir à améliorer les modèles, sauf si vous désactivez l'option (voir section 5).

### Étape 2 — Votre première conversation
Tapez une demande dans la zone de saisie, par exemple :

```
Je suis responsable d'une boulangerie de 6 salariés à Angers.
Rédige une note interne de 10 lignes pour annoncer le nouveau
planning d'été, sur un ton chaleureux mais clair.
```

Observez trois choses : la réponse arrive **mot par mot** (le modèle génère token après token), elle est **structurée** sans qu'on l'ait demandé, et elle contient parfois des détails inventés (« ouverture à 6 h 30 » alors que vous n'avez rien dit). Ce dernier point est normal : le modèle comble les blancs. À vous de préciser ou de corriger.

### Étape 3 — Poursuivre, corriger, régénérer
- Répondez dans la même conversation pour affiner : « Plus court », « Ajoute une phrase sur les congés », « Tutoie les salariés ». Le modèle se souvient de tout le fil.
- Le bouton **Régénérer** produit une autre version ; le crayon **Modifier** permet de réécrire votre message précédent (la conversation repart de là).
- Pour un sujet nouveau, ouvrez une **nouvelle conversation** : vous éviterez que le contexte précédent « contamine » la réponse.

### Étape 4 — Ajouter des fichiers, des images, la voix
Le trombone (ou l'icône « + ») permet de joindre un PDF, un tableur, une image ou une capture d'écran. Vous pouvez demander : « Résume ce contrat en 5 points et liste les dates à ne pas manquer ». Le mode vocal (icône micro ou casque) transforme ChatGPT en interlocuteur oral : pratique pour préparer un entretien ou répéter une présentation en voiture.

### Étape 5 — Chercher sur le web et créer des images
Quand votre question porte sur l'actualité, activez la **recherche web** (icône globe ou simplement « cherche sur le web… »). Le modèle cite alors ses sources ; sans cette option, il répond uniquement avec ses connaissances arrêtées à sa date de coupure. Pour une illustration, demandez-la en langage naturel (« Crée une image carrée d'un panier de légumes, style aquarelle, fond blanc ») : la génération repose sur les modèles d'images `gpt-image` d'OpenAI (nov. 2026 : `gpt-image-2.5`).

> ⚠️ **Piège fréquent** — Sans recherche web, ChatGPT ne « connaît » pas le présent. Demander « quel est le taux du Livret A aujourd'hui ? » sans activer la recherche produit une réponse assurée… et potentiellement périmée.

```quiz
{
  "type": "mise_en_situation",
  "q": "Vous demandez à ChatGPT, sans activer la recherche web : « Quel est le taux du Livret A aujourd'hui ? ». Que risque-t-il de se passer ?",
  "options": [
    "Il refusera toujours de répondre",
    "Il répondra avec assurance, mais peut-être avec un taux périmé",
    "Il ira automatiquement consulter le site de la Banque de France",
    "Il vous demandera votre numéro de compte"
  ],
  "answer": 1,
  "explanation": "Sans recherche web, le modèle ne connaît que ce qu'il a appris jusqu'à sa date de coupure (30 avril 2026 pour GPT-6 Astra). Pour toute info qui change, activez la recherche et vérifiez la source."
}
```

## 3. Les fonctions qui font gagner du temps au bureau

| Fonction (nov. 2026) | À quoi ça sert | Exemple métier |
|---|---|---|
| Instructions personnalisées | Dire une fois pour toutes qui vous êtes et comment vous voulez les réponses | « Je suis comptable, réponds en français, en vouvoyant, avec des tableaux » |
| Projets / dossiers | Regrouper conversations et fichiers autour d'un sujet | Un projet « Appel d'offres mairie » avec le cahier des charges joint |
| Mémoire | Retenir des faits d'une conversation à l'autre (désactivable) | Se souvenir que vous travaillez en Excel, pas en Google Sheets |
| GPT personnalisés | Assistants pré-configurés, les vôtres ou ceux du catalogue | Un « Rédacteur de fiches produits » pour votre e-commerce |
| Canvas / édition côte à côte | Travailler un texte ou un code dans un volet éditable | Réécrire une page de site section par section |
| Recherche approfondie (deep research) | Lancer une enquête web de plusieurs minutes avec rapport sourcé | Benchmark des logiciels de caisse pour un commerce |
| Génération d'images | Illustrations, maquettes, logos de travail | Visuel pour un post LinkedIn |
| Mode vocal | Dialogue oral, traduction en direct | Préparer un pitch, s'entraîner à l'anglais |

Les noms exacts des menus changent souvent : si une fonction n'apparaît pas, cherchez-la dans le centre d'aide officiel ([help.openai.com](https://help.openai.com/)) avant de conclure qu'elle n'existe pas.

> 🔗 **Documentation officielle** — [Catalogue des modèles OpenAI](https://developers.openai.com/api/docs/models) 🇬🇧 : la liste à jour des modèles, de leur contexte et de leur date de connaissances.

## 4. Gratuit ou payant ? Comprendre l'offre

ChatGPT propose un accès **gratuit** (usage limité, accès aux modèles les plus récents avec des quotas) et plusieurs abonnements individuels et professionnels (Plus, Pro, Business/Team, Enterprise, Éducation). Les prix en euros et les quotas évoluent plusieurs fois par an : **consultez la page tarifs officielle depuis chatgpt.com** (menu « Mettre à niveau ») avant de communiquer un chiffre à votre direction. Ce que nous pouvons dater avec certitude au 1er novembre 2026 :

- **Les tarifs API** (pour les développeurs, facturation au million de tokens) : `gpt-6-astra` 10 $ en entrée / 50 $ en sortie ; `gpt-6.1-sol` 2 $ / 10 $ ; `gpt-6.1-terra` 1 $ / 5 $ ; `gpt-6-luna` 0,10 $ / 0,50 $ (nov. 2026, source : page Pricing OpenAI). Un e-mail de 300 mots coûte donc quelques dixièmes de centime avec le modèle le plus cher : la différence de prix entre les modèles est de 1 à 100.
- **ChatGPT for Teachers** est gratuit pour les enseignants vérifiés jusqu'en juin 2027 (nov. 2026).
- **OpenAI Academy** ([academy.openai.com](https://academy.openai.com/)) propose quatre parcours gratuits (« Apply AI at Work », « Build with AI », « Lead AI Adoption », « Teach and Learn with AI ») et, depuis juin 2026, des cours à badge comme **AI Foundations** (environ 70 minutes, évaluation de 20 questions, 80 % requis, tentatives illimitées). OpenAI précise que ces badges ne sont **pas** des « OpenAI Certifications » (programme formel, encore sur invitation). Nous vous encourageons à passer AI Foundations à la fin de ce niveau : c'est gratuit et valorisable sur LinkedIn.

> 💡 **À retenir** — Pour un usage individuel modéré, la version gratuite suffit à apprendre. Un abonnement se justifie quand vous butez sur les quotas, avez besoin des fonctions avancées (recherche approfondie, projets, plus d'images) ou devez garantir que vos données ne servent pas à l'entraînement (offres professionnelles).

## 5. Confidentialité et sécurité : les réflexes avant de taper

> 💡 **Autrement dit** — Un chatbot grand public, c'est un peu comme une conversation dans un lieu public : utile et agréable, mais on n'y parle pas de ses codes bancaires. Les cinq réflexes ci-dessous reviennent à fermer la porte (désactiver l'entraînement), baisser la voix (anonymiser) et relire avant de signer (vérifier).

1. **Désactivez l'amélioration du modèle** si vous êtes sur un compte individuel et traitez des informations sensibles : Paramètres → Contrôles des données → option « Améliorer le modèle pour tous » (libellé susceptible de changer). Les offres Business/Enterprise excluent l'entraînement par défaut.
2. **Ne saisissez jamais** de données personnelles de tiers (nom + situation médicale, numéro de sécurité sociale, RIB), de secrets industriels ou de mots de passe. La règle du module 7 s'applique dès aujourd'hui : *si vous ne l'écririez pas sur une carte postale, ne le tapez pas dans un chatbot grand public*.
3. **Anonymisez** : remplacez « M. Dupont, 12 rue des Lilas » par « le client A » avant de demander une analyse. Le résultat est aussi bon.
4. **Vérifiez** chaque chiffre, chaque citation, chaque article de loi. OpenAI elle-même, dans son guide de bonnes pratiques de sécurité, recommande un « humain dans la boucle » et de « communiquer les limites » du système aux utilisateurs.
5. **Conversations temporaires** : pour un test ponctuel, utilisez le mode temporaire (non conservé dans l'historique, non utilisé pour la mémoire).

> 🔗 **Documentation officielle** — [Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 : les 11 recommandations d'OpenAI (modération, tests adverses, humain dans la boucle, signalement…).

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour faire analyser le dossier médical d'un salarié, il suffit de supprimer la conversation ensuite.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Des données de santé de tiers ne doivent jamais être saisies dans un chatbot grand public. La bonne pratique est de ne pas les confier du tout, ou d'anonymiser complètement les informations, et de passer par une offre professionnelle encadrée par votre entreprise."
}
```

## 6. Forces, limites, et quand choisir un autre outil

**ChatGPT excelle** pour la rédaction et la reformulation, le brainstorming, la synthèse de documents, la traduction, l'aide au tableur, la préparation d'entretiens, et comme « collègue » polyvalent disponible 24 h/24. Son écosystème (GPT personnalisés, images, voix, recherche) est le plus large du marché grand public.

**Ses limites** : réponses parfois trop longues ou trop affirmatives, inventions de sources quand la recherche web n'est pas activée, variations d'un jour à l'autre, et dépendance à une entreprise américaine pour l'hébergement des données (point à examiner avec votre délégué à la protection des données). Pour une recherche sourcée, Perplexity (leçon L013) est souvent plus direct ; pour travailler longuement sur des dossiers et des fichiers, Claude (L011) a ses atouts ; pour rester dans l'écosystème Google Workspace ou Microsoft 365, Gemini et Copilot (L012) s'intègrent nativement.

```
Je veux…                          → Outil à essayer d'abord
─────────────────────────────────────────────────────────
rédiger / reformuler / traduire   → ChatGPT, Claude, Le Chat
trouver une info récente sourcée  → Perplexity, ChatGPT (recherche web), Gemini
analyser un long dossier (PDF)    → Claude, ChatGPT (projet), Gemini
créer une image rapidement        → ChatGPT, Gemini, Grok Imagine
rester dans mes outils bureau     → Copilot (Microsoft 365), Gemini (Workspace)
```

## 🎮 Défi
Demandez à ChatGPT : « Quelle est la date de ta coupure de connaissances ? » puis « Que s'est-il passé en France la semaine dernière ? » **sans** recherche web, puis **avec**. Comparez les deux réponses : vous venez de voir la différence entre mémoire d'entraînement et accès au présent.

```mission
{
  "title": "Les conditions du badge OpenAI « AI Foundations »",
  "url": "https://academy.openai.com/pages/courses",
  "steps": ["Ouvrez le catalogue des cours d'OpenAI Academy", "Repérez le cours « AI Foundations »", "Lisez sa durée et les conditions d'obtention du badge"],
  "question": "Combien de temps dure le cours AI Foundations, combien de questions compte l'évaluation et quel score faut-il obtenir ?",
  "hint": "La section 4 de cette leçon donne un ordre de grandeur : vérifiez-le à la source.",
  "answer": "Environ 70 minutes ; évaluation de 20 questions ; 80 % de bonnes réponses requis, tentatives illimitées (nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Où désactiver l'entraînement sur vos conversations ?",
  "url": "https://help.openai.com/",
  "steps": ["Ouvrez le centre d'aide officiel de ChatGPT", "Tapez dans la barre de recherche « data controls » ou « improve the model »", "Ouvrez l'article qui explique comment empêcher que vos conversations servent à entraîner les modèles"],
  "question": "Dans quel menu de ChatGPT se trouve l'option qui empêche l'utilisation de vos conversations pour améliorer les modèles, et comment s'appelle-t-elle ?",
  "hint": "Le chemin commence par « Paramètres » ; la section 5 de cette leçon vous met sur la piste.",
  "answer": "Paramètres → Contrôles des données → option « Améliorer le modèle pour tous » à désactiver (libellés de nov. 2026, susceptibles de changer).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Vous êtes assistant(e) de direction dans un cabinet d'expertise comptable de 15 personnes. Un client vous a envoyé par e-mail une liste de 8 questions sur la facturation électronique obligatoire. Dans ChatGPT :
1. Créez des instructions personnalisées (votre rôle, le ton, la langue).
2. Demandez une réponse structurée aux 8 questions **avec recherche web activée**, en exigeant les sources.
3. Faites reformuler la réponse en un e-mail de 150 mots maximum.
4. Identifiez au moins un point à vérifier avant envoi.

**Critères de réussite.**
- Les instructions personnalisées sont renseignées et visibles dans le résultat (ton, vouvoiement, format).
- La réponse cite des sources consultables (URL d'un site officiel : impots.gouv.fr, legifrance…).
- L'e-mail final tient en 150 mots et ne contient aucune donnée nominative du client.
- Vous avez listé un élément douteux (date, seuil, montant) et expliqué comment le vérifier.

**Pistes de corrigé.** Un prompt efficace précise le rôle (« Tu es un assistant de cabinet comptable »), le public (« dirigeant de TPE, non spécialiste »), le format (« 8 réponses numérotées de 3 lignes, puis une liste de sources ») et la contrainte (« si tu n'es pas sûr, écris “à confirmer” »). Le point à vérifier typique : le calendrier d'entrée en vigueur par taille d'entreprise, que vous contrôlerez sur le site officiel de l'administration fiscale.

## ✅ Auto-évaluation express

1. Quelle différence entre « ChatGPT » et « GPT-6 » ?
2. Que se passe-t-il si vous posez une question d'actualité sans activer la recherche web ?
3. Citez deux réglages ou réflexes de confidentialité à appliquer sur un compte individuel.

**Réponses.** 1) ChatGPT est l'application (interface, fichiers, voix, projets) ; GPT-6 est la famille de modèles qui la fait fonctionner (Astra, Sol, Terra, Luna en nov. 2026). 2) Le modèle répond avec ses connaissances arrêtées à sa date de coupure (30 avril 2026 pour Astra) et peut présenter une information périmée avec assurance. 3) Désactiver l'amélioration du modèle dans les contrôles des données ; anonymiser les données de tiers ; utiliser une conversation temporaire pour les tests ; ne jamais saisir de secrets ou de mots de passe.

## 📚 Pour aller plus loin
- [OpenAI Academy — catalogue des cours](https://academy.openai.com/pages/courses) 🇬🇧 — les parcours gratuits et le cours à badge « AI Foundations » (70 min) que nous vous conseillons de passer.
- [OpenAI — Pricing](https://developers.openai.com/api/docs/pricing) 🇬🇧 — comprendre la facturation au token, utile pour dialoguer avec votre service informatique.
- [OpenAI — Quickstart API](https://developers.openai.com/api/docs/quickstart) 🇬🇧 — pour les curieux : le premier appel au modèle en quelques lignes (vu en détail au niveau 3).
- [Centre d'aide ChatGPT](https://help.openai.com/) 🇬🇧/🇫🇷 — réglages de confidentialité, offres, nouveautés de l'interface.

> 🗺️ **Et maintenant ?** — Vous maîtrisez les bases de ChatGPT ; la leçon L011 vous fait découvrir Claude, ses projets et ses artefacts, pour comparer deux façons de travailler avec un assistant.
