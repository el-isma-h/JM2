---
id: L029
module: M07
level: N1
title: "AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA"
minutes: 45
objectives:
  - "Expliquer la logique par niveaux de risque du règlement (UE) 2024/1689 et classer un cas d'usage d'entreprise dans la bonne catégorie"
  - "Situer les grandes échéances du calendrier d'application (2025-2028) et leur impact pour une PME"
  - "Appliquer l'obligation de maîtrise de l'IA (article 4) en complétant la charte d'usage IA et un registre des systèmes"
skills: ["C1.6"]
sources:
  - { title: "donneespersonnelles.fr — Omnibus numérique IA : calendrier AI Act mis à jour", url: "https://donneespersonnelles.fr/omnibus-numerique-ia", lang: "fr" }
  - { title: "CMS Law — European Commission clarifies AI literacy requirements under the AI Act", url: "https://cms.law/en/int/legal-updates/european-commission-clarifies-literacy-requirements-under-the-ai-act", lang: "en" }
  - { title: "RTR (Autriche) — AI literacy (art. 4 AI Act)", url: "https://www.rtr.at/rtr/service/ki-servicestelle/ai-act/ai_literacy.en.html", lang: "en" }
  - { title: "Sénat — Réponse ministérielle sur les deepfakes et l'AI Act (5 février 2026)", url: "https://www.senat.fr/questions/base/2025/qSEQ251006478.html", lang: "fr" }
  - { title: "EUR-Lex — Règlement (UE) 2024/1689 (AI Act)", url: "https://eur-lex.europa.eu/eli/reg/2024/1689/oj", lang: "fr" }
---

# AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 7

## 🎯 Ce que vous saurez faire
- Expliquer à votre dirigeant, en trois phrases, ce qu'est l'AI Act et pourquoi il concerne déjà une entreprise de 15 salariés.
- Classer un usage (chatbot client, tri de CV, assistant de rédaction, caméra en atelier) dans la bonne « case » de risque.
- Retenir les quatre dates qui comptent et savoir lesquelles ont bougé en 2026.
- Compléter la page 2 de votre charte d'usage IA et démarrer un registre des systèmes d'IA.

> 🧭 **En clair** — L'AI Act est le « code de la route » européen de l'intelligence artificielle. Comme sur la route, les règles dépendent du danger : un vélo n'a pas les mêmes obligations qu'un camion de matières dangereuses. Un assistant de rédaction est un vélo (presque aucune règle) ; un chatbot sur votre site doit dire qu'il est un robot ; un logiciel qui trie des CV est un camion (règles lourdes) ; certains usages, comme lire les émotions des salariés, sont tout simplement interdits. Et une règle vaut pour tout le monde, quel que soit le véhicule : former les personnes qui utilisent l'IA. C'est l'article 4, et cette formation y répond.

## 1. L'AI Act en une image : une pyramide, pas une interdiction

Le **règlement (UE) 2024/1689**, dit *AI Act* (règlement sur l'intelligence artificielle), est entré en vigueur le **1er août 2024**. C'est un règlement européen : il s'applique directement en France, sans loi de transposition. Son idée centrale est simple : **plus un usage de l'IA peut nuire aux personnes, plus les obligations sont lourdes**. On le représente en pyramide.

```
                 ┌───────────────────┐
                 │   INACCEPTABLE    │  ← interdit (art. 5)
                 │  notation sociale,│
                 │ manipulation…     │
               ┌─┴───────────────────┴─┐
               │      HAUT RISQUE      │  ← obligations lourdes (annexes I et III)
               │  RH, crédit, éducation,│
               │  santé, biométrie…    │
             ┌─┴───────────────────────┴─┐
             │     RISQUE LIMITÉ          │  ← transparence (art. 50)
             │  chatbots, deepfakes,      │
             │  contenus synthétiques     │
           ┌─┴───────────────────────────┴─┐
           │       RISQUE MINIMAL           │  ← aucune obligation spécifique
           │  filtre anti-spam, correcteur, │
           │  assistant de rédaction…       │
           └────────────────────────────────┘
   + une couche à part : les MODÈLES À USAGE GÉNÉRAL (GPAI, art. 51-56)
     → obligations pour les fournisseurs (Anthropic, OpenAI, Mistral…), pas pour vous
```

### 1.1 Les quatre étages, avec des exemples d'entreprise

| Niveau | Ce que c'est | Exemples concrets | Ce que vous devez faire |
|---|---|---|---|
| **Inacceptable** (art. 5) | Pratiques interdites car contraires aux droits fondamentaux | Notation sociale généralisée, manipulation subliminale, exploitation de la vulnérabilité, reconnaissance des émotions au travail (sauf exceptions), moissonnage non ciblé de visages | **Ne jamais le faire.** Applicable depuis le 2 février 2025 |
| **Haut risque** (annexes I et III) | Systèmes qui influencent des décisions importantes sur des personnes | Tri automatique de CV, notation des candidats, évaluation des salariés, octroi de crédit, admission à une formation, dispositifs médicaux, composants de sécurité de machines | Pour le *déployeur* : utiliser conformément à la notice, surveillance humaine, information des personnes, conservation des journaux, AIPD si données personnelles |
| **Risque limité** (art. 50) | Systèmes qui interagissent avec des humains ou génèrent des contenus | Chatbot sur votre site, avatar vocal, images ou vidéos générées, deepfakes | **Transparence** : dire que c'est une IA, marquer les contenus synthétiques, signaler les deepfakes |
| **Risque minimal** | Tout le reste | Assistant de rédaction, résumé de réunion, traduction, filtre anti-spam, suggestions de produits | Aucune obligation spécifique… **sauf l'article 4** (maîtrise de l'IA), qui s'applique à tous |

> ⚠️ **Piège fréquent** — « *Nous utilisons seulement ChatGPT pour rédiger, donc l'AI Act ne nous concerne pas.* » Faux à deux titres : (1) l'article 4 s'applique à **tout employeur** qui déploie de l'IA, même à risque minimal ; (2) le même outil change de catégorie selon l'usage. Rédiger une offre d'emploi avec un assistant = risque minimal ; faire **trier les candidatures** par le même assistant = haut risque (annexe III, emploi).

```quiz
{
  "q": "Une PME utilise le même assistant IA pour deux tâches : rédiger ses offres d'emploi, et classer automatiquement les candidatures reçues. Comment l'AI Act classe-t-il ces deux usages ?",
  "options": ["Les deux en risque minimal, puisqu'il s'agit du même outil d'IA générative", "Les deux en haut risque, puisque les deux tâches concernent le recrutement", "Les deux sont interdits par l'article 5, qui vise toute IA appliquée aux RH", "Rédaction : risque minimal ; tri des candidatures : haut risque"],
  "answer": 3,
  "explanation": "La catégorie dépend de l'usage, pas de l'outil. Rédiger est un usage à risque minimal ; trier ou noter des candidats influence une décision importante sur une personne : haut risque, domaine de l'emploi."
}
```

### 1.2 Fournisseur ou déployeur : de quel côté êtes-vous ?

L'AI Act distingue le **fournisseur** (*provider* : celui qui développe et met sur le marché le système) et le **déployeur** (*deployer* : celui qui l'utilise sous sa responsabilité dans un cadre professionnel). Une PME qui utilise Claude, ChatGPT, Gemini, Le Chat ou Copilot est **déployeur**. Elle devient fournisseur si elle met sur le marché un système sous son propre nom (par exemple un assistant qu'elle vend à ses clients) ou si elle modifie substantiellement un système à haut risque. Retenez : la plupart des obligations lourdes pèsent sur les fournisseurs ; les déployeurs ont des obligations ciblées (bon usage, surveillance, transparence, formation).

> 💡 **Autrement dit** — Le **fournisseur**, c'est le fabricant de la voiture (Anthropic, OpenAI, Mistral…) ; le **déployeur**, c'est l'entreprise qui la conduit pour son travail. Le fabricant porte l'essentiel des obligations techniques ; le conducteur doit l'utiliser correctement, surveiller la route, prévenir les passagers et… savoir conduire (former ses équipes).

## 2. Le calendrier : quatre dates à connaître (et ce qui a bougé en 2026)

Le calendrier initial a été modifié en 2026 par le règlement dit « omnibus numérique IA ». Voici l'état à la date de cette formation.

| Date | Ce qui s'applique | Pour une PME, concrètement |
|---|---|---|
| **2 février 2025** | Pratiques interdites (art. 5) + **obligation de maîtrise de l'IA (art. 4)** | Vous deviez déjà former vos équipes. C'est le point de départ de cette formation |
| **2 août 2025** | Obligations des fournisseurs de modèles à usage général (GPAI, art. 53 : politique droit d'auteur, résumé public des données d'entraînement) ; gouvernance et désignation des autorités nationales | Rien à faire directement ; vous pouvez demander à vos fournisseurs leur documentation |
| **2 août 2026** | **Transparence (art. 50)** : signaler les chatbots, marquer les contenus synthétiques, signaler les deepfakes ; **sanctions (chapitre XII)** ; surveillance de marché ; **début du contrôle national, y compris de l'art. 4** | Si vous avez un chatbot ou publiez des contenus générés : c'est **maintenant**. L'art. 50(2) (marquage) bénéficie d'un délai au 2 décembre 2026 pour les systèmes déjà sur le marché |
| **2 décembre 2026** | **Nouvelles interdictions** ajoutées par l'omnibus : systèmes générant des images intimes non consenties (applications « nudifier ») et du matériel pédopornographique | Vérifiez qu'aucun outil d'image utilisé ou proposé ne permet ces usages |
| ~~2 août 2026~~ → **2 décembre 2027** | Systèmes à **haut risque de l'annexe III** (RH, éducation, crédit, santé, biométrie, justice…) | **Reporté** par le règlement (UE) 2026/1744 (JOUE du 24 juillet 2026, en vigueur le 27 juillet 2026). Si vous envisagez un outil de tri de CV, profitez du délai pour le cadrer |
| ~~2 août 2027~~ → **2 août 2028** | Haut risque de l'annexe I (IA intégrée dans des produits réglementés : machines, dispositifs médicaux…) | Reporté ; concerne surtout les industriels |
| 2 août 2030 | Systèmes à haut risque des autorités publiques déjà en service | Inchangé |

Point important pour les créateurs de contenu : le volet **droit d'auteur** de l'article 53 (obligations des fournisseurs de modèles) **n'a pas été décalé** par l'omnibus.

> 🔗 **Documentation officielle** — [EUR-Lex — Règlement (UE) 2024/1689](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) · [donneespersonnelles.fr — Omnibus numérique IA, calendrier mis à jour (sept. 2026)](https://donneespersonnelles.fr/omnibus-numerique-ia)

> 💡 **À retenir** — Trois dates suffisent pour une PME : **février 2025** (formation et interdits), **août 2026** (transparence et sanctions), **décembre 2027** (haut risque RH et consorts). Tout le reste est du détail pour spécialistes.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : l'obligation de former les équipes à l'IA (article 4) ne s'appliquera qu'en décembre 2027, avec le report du haut risque.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. L'article 4 s'applique depuis le 2 février 2025, avec un contrôle national à partir du 2 août 2026. Seules les obligations du haut risque de l'annexe III ont été reportées au 2 décembre 2027."
}
```

## 3. Les sanctions : des chiffres qui font lever la tête

Le chapitre XII prévoit des amendes administratives graduées, applicables depuis le 2 août 2026 (nov. 2026) :

| Manquement | Plafond |
|---|---|
| Pratiques interdites (art. 5) | **35 M€ ou 7 %** du chiffre d'affaires annuel mondial (le plus élevé) |
| Autres obligations, dont la transparence de l'art. 50 (deepfakes, chatbots) | **15 M€ ou 3 %** — confirmé pour les deepfakes par la réponse ministérielle publiée au Sénat le 5 février 2026 |
| Informations inexactes fournies aux autorités | **7,5 M€ ou 1 %** |

Pour les PME et start-up, le règlement prévoit que c'est le **montant le plus bas** des deux (pourcentage ou somme fixe) qui s'applique — à vérifier dans l'article 99 sur EUR-Lex avant de le citer dans un document.

Et l'article 4 ? Il n'a **pas d'amende dédiée**. Mais trois mécanismes le rendent très concret :
1. la **surveillance de marché** peut constater l'absence de formation depuis août 2026 ;
2. en cas de dommage causé par un salarié mal formé, l'article 4 sert de **standard de diligence** devant un juge (responsabilité civile) ;
3. vos clients et donneurs d'ordre commencent à l'exiger dans leurs **appels d'offres**.

```mission
{
  "title": "Les amendes des PME dans le texte officiel",
  "url": "https://eur-lex.europa.eu/eli/reg/2024/1689/oj",
  "steps": ["Ouvrez le règlement (UE) 2024/1689 sur EUR-Lex, en français", "Allez au chapitre XII « Sanctions », article 99", "Lisez le paragraphe consacré aux PME et aux jeunes pousses"],
  "question": "Pour une PME ou une start-up, l'amende est-elle plafonnée au montant fixe ou au pourcentage du chiffre d'affaires, et lequel des deux s'applique ?",
  "hint": "Pour les grandes entreprises, c'est le plus élevé des deux ; pour les PME, c'est l'inverse.",
  "answer": "Le plus faible des deux (article 99, paragraphe 6, dans la version initiale du règlement) — vérifiez la version consolidée après l'omnibus de 2026.",
  "xp": 20
}
```

## 4. L'article 4 : l'obligation qui vous concerne tous

L'article 4 impose aux fournisseurs **et aux déployeurs** de prendre des mesures pour garantir « dans toute la mesure du possible » un niveau suffisant de **maîtrise de l'IA** (*AI literacy*) à leur personnel et aux personnes qui utilisent les systèmes pour leur compte, en tenant compte de leurs connaissances, de leur expérience et du contexte d'utilisation. Depuis l'omnibus (règlement (UE) 2026/1744, en vigueur le 27 juillet 2026), l'article 4 est reformulé : fournisseurs et déployeurs prennent des mesures qui *favorisent* la maîtrise de l'IA, sans niveau individuel imposé. L'obligation de former demeure (formulation exacte à vérifier sur la version consolidée d'EUR-Lex).


> 📌 **Mise à jour (nov. 2026)** — Depuis l'omnibus (règlement (UE) 2026/1744, publié au JOUE le 24 juillet 2026 et en vigueur le 27 juillet 2026), l'article 4 est reformulé : fournisseurs et déployeurs prennent des mesures qui **favorisent** la maîtrise de l'IA, sans « niveau suffisant » individuel imposé. L'obligation d'agir (former, sensibiliser) demeure ; vérifiez la formulation exacte sur la version consolidée d'EUR-Lex.

La définition de la maîtrise de l'IA (art. 3, point 56) couvre : les **compétences, connaissances et compréhension** permettant un déploiement éclairé, la conscience des **opportunités et des risques**, et des **dommages possibles**. Les clarifications de la Commission européenne (FAQ de mai 2025, résumées par CMS et par le régulateur autrichien RTR) précisent :

- **Pas d'examen ni de certification obligatoires** : l'entreprise choisit les moyens.
- Les mesures doivent être **proportionnées** : plus poussées pour un outil à haut risque, plus légères pour un assistant de rédaction ; adaptées au niveau de chaque personne (un développeur et une assistante commerciale n'ont pas le même besoin).
- Un simple **manuel** ou un **message automatique** à la connexion est « probablement insuffisant ».
- Contenu attendu : **fonctionnement** général, **risques** (hallucinations, biais, fuites de données), **mesures de prévention**, enjeux **juridiques et éthiques**.
- **Documentation recommandée** : inventaire des systèmes utilisés, politique interne, plan de formation, trace par salarié (type de formation, prestataire, contenu, date, recyclage prévu).

```mermaid
flowchart LR
    A[Inventaire des<br>systèmes IA utilisés] --> B[Évaluer le risque<br>de chaque usage]
    B --> C[Politique / charte<br>d'usage]
    C --> D[Plan de formation<br>par profil]
    D --> E[Trace par salarié<br>date, contenu, recyclage]
    E --> F[Revue annuelle]
    F --> A
```

> 💡 **À retenir** — Cette formation Next Formation constitue, pour vous et votre employeur, un **élément de preuve** de conformité à l'article 4 : conservez votre attestation de suivi et vos résultats de quiz dans le dossier « formation IA » de l'entreprise. Elle ne remplace pas une analyse spécifique si vous déployez un système à haut risque.

> 🔗 **Documentation officielle** — [CMS Law — Commission clarifies AI literacy requirements](https://cms.law/en/int/legal-updates/european-commission-clarifies-literacy-requirements-under-the-ai-act) 🇬🇧 · [RTR — AI literacy, art. 4](https://www.rtr.at/rtr/service/ki-servicestelle/ai-act/ai_literacy.en.html) 🇬🇧

```quiz
{
  "q": "Mise en situation : votre dirigeant propose de « régler l'article 4 » en affichant un message automatique « Utilisez l'IA avec prudence » à la connexion. Qu'en pensez-vous ?",
  "options": ["Probablement insuffisant : formation adaptée, tracée de préférence", "Suffisant : l'article 4 n'impose aucun moyen précis, un message suffit donc", "Inutile : seule une certification officielle de chaque salarié est reconnue", "Interdit : l'article 4 impose une formation de 150 heures à chaque salarié"],
  "answer": 0,
  "explanation": "Les clarifications de la Commission jugent un manuel ou un message automatique « probablement insuffisant ». Aucune certification n'est imposée, mais il faut des mesures de formation adaptées ; une trace par salarié est recommandée, c'est votre meilleure preuve."
}
```

```mission
{
  "title": "Lire l'article 4 à la source",
  "url": "https://eur-lex.europa.eu/eli/reg/2024/1689/oj",
  "steps": ["Ouvrez le règlement sur EUR-Lex en français", "Cherchez « Article 4 » (maîtrise de l'IA)", "Puis l'article 3, point 56, pour la définition"],
  "question": "À quelles deux catégories d'acteurs l'article 4 impose-t-il de garantir la maîtrise de l'IA, et pour quelles personnes ?",
  "hint": "Les deux mêmes rôles qu'à la section 1.2.",
  "answer": "Aux fournisseurs et aux déployeurs de systèmes d'IA, pour leur personnel et les autres personnes s'occupant du fonctionnement et de l'utilisation de ces systèmes pour leur compte (texte applicable depuis le 2 février 2025). Depuis l'omnibus (règlement (UE) 2026/1744, en vigueur le 27 juillet 2026), l'article 4 parle de mesures qui favorisent cette maîtrise, sans niveau individuel imposé : vérifiez la version consolidée.",
  "xp": 15
}
```

## 5. Charte d'usage IA — page 2 (le volet AI Act)

Complétez le modèle commencé en L028 avec ces rubriques.

```
8. INVENTAIRE DES SYSTÈMES D'IA (registre tenu par [responsable], revu chaque [trimestre/année])
   | Outil | Usage | Service | Catégorie AI Act | Données personnelles ? | Contrat / date |
   | ex. Claude (Team) | rédaction, résumés | tous | minimal | pseudonymisées | oui, __/__/____ |
   | ex. chatbot site web | réponses clients | commercial | limité (art. 50) | e-mails clients | oui, __/__/____ |
   | ex. outil de tri de CV | présélection | RH | HAUT RISQUE (annexe III) | oui | AIPD à faire avant déploiement |

9. USAGES INTERDITS DANS L'ENTREPRISE
   - Toute pratique relevant de l'article 5 (notation sociale, reconnaissance des émotions au travail…)
   - Toute décision automatisée sans validation humaine sur un salarié, un candidat ou un client

10. TRANSPARENCE (art. 50, applicable depuis le 2 août 2026)
   - Nos chatbots indiquent clairement qu'ils sont une IA.
   - Les images, vidéos et sons générés et diffusés à l'extérieur portent une mention ou un marquage.
   - Aucun deepfake d'une personne réelle n'est produit sans son consentement écrit (voir L030).

11. MAÎTRISE DE L'IA (art. 4)
   - Sensibilisation obligatoire à l'arrivée + recyclage annuel ; formation renforcée pour les
     utilisateurs d'un système à haut risque.
   - Registre des formations : nom, date, contenu, prestataire, prochaine échéance.

12. RÉFÉRENT IA : [nom], joignable à [contact], chargé de la veille réglementaire et des incidents.
```

## 🧪 Exercice pratique

**Consigne.** Une entreprise de transport de 60 salariés (dont 35 chauffeurs) vous présente cinq projets. Pour chacun, indiquez la **catégorie AI Act**, la **date** à partir de laquelle des obligations s'appliquent et **une action concrète** à prévoir.

1. Un assistant IA pour rédiger les réponses aux e-mails clients (relu par un humain avant envoi).
2. Un chatbot sur le site web qui répond aux questions sur les tarifs et délais.
3. Un logiciel qui analyse les candidatures reçues et classe les candidats chauffeurs par « score d'adéquation ».
4. Une caméra dans la cabine qui détecte la somnolence du chauffeur et déclenche une alerte sonore.
5. Un outil qui analyse les expressions du visage des chauffeurs pour mesurer leur « motivation » en réunion.

**Critères de réussite.** Les cinq catégories sont correctes ; les dates citées correspondent au calendrier de la section 2 ; chaque action est proportionnée (pas d'AIPD pour un assistant de rédaction, mais une AIPD et une surveillance humaine pour le tri de CV).

<details>
<summary>Corrigé</summary>

1. **Risque minimal.** Obligation : art. 4 (formation) depuis le 2 février 2025. Action : inscrire l'outil au registre, former les utilisateurs, règle de relecture humaine.
2. **Risque limité** (art. 50). Depuis le 2 août 2026. Action : afficher « Vous échangez avec un assistant automatisé » dès le premier message et prévoir un relais humain.
3. **Haut risque** (annexe III, emploi : recrutement et sélection). Obligations pour le déployeur à partir du **2 décembre 2027** (report de l'omnibus, règlement (UE) 2026/1744) — mais le RGPD s'applique **dès aujourd'hui**. Action : AIPD avant déploiement, information des candidats, décision finale humaine, conservation des journaux, choix d'un fournisseur capable de fournir la documentation de conformité.
4. **Haut risque probable** (composant de sécurité d'un véhicule, annexe I ; reporté au 2 août 2028 selon la source citée) — ou dispositif soumis à la réglementation produit. Action : s'appuyer sur le fournisseur du dispositif (c'est lui qui porte la conformité) et informer les chauffeurs ; vérifier la qualification exacte avec un conseil.
5. **Inacceptable** : reconnaissance des émotions sur le lieu de travail, interdite par l'art. 5 depuis le 2 février 2025 (hors exceptions médicales ou de sécurité). Action : **abandonner le projet**.
</details>

🎮 **Défi** — Dans votre entreprise ou votre dernière expérience, listez trois outils qui utilisent de l'IA (y compris ceux que vous n'identifiez pas comme tels : correcteur, tri d'e-mails, GPS…). Classez-les dans la pyramide. Surprise garantie : la plupart sont au niveau minimal, et c'est rassurant.

## ✅ Auto-évaluation express

1. Depuis quelle date l'obligation de maîtrise de l'IA (article 4) s'applique-t-elle ?
2. Un outil de tri automatique des candidatures relève de quelle catégorie ?
3. L'article 4 exige-t-il que les salariés passent une certification ?

<details>
<summary>Réponses</summary>

1. Depuis le **2 février 2025**, avec un contrôle national effectif à partir du 2 août 2026.
2. **Haut risque** (annexe III, domaine de l'emploi) ; obligations des déployeurs applicables à partir du 2 décembre 2027 selon le calendrier révisé (règlement (UE) 2026/1744), RGPD applicable immédiatement.
3. **Non.** Il exige des mesures proportionnées et documentées (formation adaptée au contexte, trace par salarié) ; un manuel seul est jugé probablement insuffisant.
</details>

## 📚 Pour aller plus loin
- [EUR-Lex — Règlement (UE) 2024/1689](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) — le texte consolidé en français ; lisez au moins les articles 3 (définitions), 4, 5 et 50.
- [donneespersonnelles.fr — Omnibus numérique IA](https://donneespersonnelles.fr/omnibus-numerique-ia) — calendrier mis à jour après le règlement 2026/1744 (vérifier la version consolidée sur EUR-Lex).
- [RTR — AI literacy (art. 4)](https://www.rtr.at/rtr/service/ki-servicestelle/ai-act/ai_literacy.en.html) 🇬🇧 — la lecture la plus pédagogique de l'article 4 par un régulateur.
- [Sénat — Réponse ministérielle du 5 février 2026](https://www.senat.fr/questions/base/2025/qSEQ251006478.html) — articulation entre l'art. 50 de l'AI Act et le droit pénal français des deepfakes.
- [Anthropic Partner Academy — Governance, Risk & Responsible Use](https://anthropic-partners.skilljar.com/governance-risk-responsible-use) 🇬🇧 — module du parcours Claude Certified Associate consacré à la gouvernance ; incitation à passer cette certification si votre organisation est partenaire.

> 🗺️ **Et maintenant ?** — Au-delà des règles, l'IA soulève des questions de création, d'image et d'équité ; la leçon L030 traite du droit d'auteur, des deepfakes et des biais.

