---
id: L004
module: M01
level: N1
title: "Mythes, réalités et chiffres clés de l'IA en 2026"
minutes: 40
objectives:
  - "Démonter huit idées reçues sur l'IA en s'appuyant sur le fonctionnement vu en L001-L003"
  - "Citer et sourcer dix chiffres clés de l'IA en 2026 (monde, Europe, France) utiles dans un échange professionnel"
  - "Expliquer l'obligation de « maîtrise de l'IA » de l'article 4 de l'AI Act et ce qu'elle implique pour un salarié et son employeur"
skills: ["C1.1", "C1.6"]
sources:
  - { title: "Stanford HAI — AI Index Report 2026", url: "https://hai.stanford.edu/ai-index/2026-ai-index-report", lang: "en" }
  - { title: "Stanford HAI — 12 takeaways from the 2026 AI Index", url: "https://hai.stanford.edu/news/inside-the-ai-index-12-takeaways-from-the-2026-report", lang: "en" }
  - { title: "Règlement (UE) 2024/1689 — AI Act (EUR-Lex)", url: "https://eur-lex.europa.eu/eli/reg/2024/1689/oj", lang: "fr" }
  - { title: "CMS Law — La Commission clarifie l'obligation d'AI literacy (art. 4)", url: "https://cms.law/en/int/legal-updates/european-commission-clarifies-literacy-requirements-under-the-ai-act", lang: "en" }
  - { title: "donneespersonnelles.fr — Omnibus numérique IA : calendrier de l'AI Act", url: "https://donneespersonnelles.fr/omnibus-numerique-ia", lang: "fr" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "Maddyness — Plan « Osez l'IA » (1er juillet 2025)", url: "https://www.maddyness.com/2025/07/01/osez-lia-le-plan-de-clara-chappaz-pour-accelerer-ladoption-de-lia-dans-les-entreprises-francaises/", lang: "fr" }
  - { title: "Le Monde Informatique — Plan « Impulsion IA 2027 »", url: "https://www.lemondeinformatique.fr/actualites/lireamp-le-gouvernement-lance-un-plan-pour-former-a-l-ia-100805.html", lang: "fr" }
  - { title: "Blog du Modérateur — Étude PwC sur les compétences IA dans les offres d'emploi", url: "https://www.blogdumoderateur.com/etude-competences-ia-offres-emploi/", lang: "fr" }
  - { title: "OPIIEC — IA dans la branche numérique, ingénierie, conseil (à retenir)", url: "https://www.syntec-ingenierie.fr/app/uploads/2025/06/20250428_OPIIEC_IA_A_RETENIR.pdf", lang: "fr" }
---

# Mythes, réalités et chiffres clés de l'IA en 2026

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 1

## 🎯 Ce que vous saurez faire
- Répondre calmement, avec des arguments techniques, aux huit phrases que vous entendrez le plus souvent sur l'IA en réunion ou en famille.
- Mobiliser dix chiffres sourcés et datés pour situer l'IA en 2026 — et savoir d'où ils viennent pour les actualiser l'an prochain.
- Décrire l'obligation de « maîtrise de l'IA » (*AI literacy*) de l'article 4 du règlement européen sur l'IA, à laquelle cette formation répond.

> 🧭 **En clair** — Sur l'IA, on entend tout et son contraire, comme sur la météo au comptoir du café : « elle va nous remplacer », « elle ne sert à rien », « elle ne se trompe jamais ». Cette leçon vous donne un réflexe simple : avant de croire une affirmation, demandez **de quel outil on parle, ce qu'il a appris, et qui a vérifié le résultat**. Vous repartirez aussi avec une dizaine de chiffres datés pour parler avec justesse, et vous comprendrez pourquoi une loi européenne demande désormais aux employeurs de former leurs équipes à l'IA — c'est précisément ce que vous êtes en train de faire.

## 1. Huit mythes passés au crible

Chaque mythe est confronté à ce que vous savez maintenant du fonctionnement des modèles (L001-L003). Entraînez-vous à formuler la réponse en une phrase : c'est l'exercice de fin de leçon.

### Mythe 1 — « L'IA, c'est un robot qui pense comme nous »

**Réalité.** Les systèmes de 2026 sont des programmes **étroits** : chacun excelle sur une famille de tâches (L003). Un LLM manipule des probabilités de tokens ; il n'a ni corps, ni intentions, ni conscience. Le débat scientifique sur une éventuelle « intelligence artificielle générale » existe, mais aucun système déployé aujourd'hui n'en relève. L'effet ELIZA (L001) — attribuer une compréhension humaine à un programme qui reformule — a 60 ans et n'a jamais été aussi puissant.

### Mythe 2 — « L'IA ne se trompe jamais / l'IA est objective »

**Réalité.** Un modèle reproduit les régularités de ses données, erreurs et stéréotypes compris (L002). L'AI Index 2026 de Stanford a recensé **362 incidents liés à l'IA** signalés en 2025, un record (nov. 2026). Les LLM hallucinent ; les modèles de vision ont des biais de carnation ; les modèles de scoring peuvent discriminer indirectement. Une sortie d'IA est une **proposition à vérifier**, pas une vérité — toute la compétence C1.4 du module 5 porte là-dessus.

### Mythe 3 — « L'IA va remplacer tout le monde »

**Réalité.** Les données disponibles montrent plutôt une **transformation des postes** qu'une disparition. D'après l'étude PwC relayée en juin 2025, les offres d'emploi françaises demandant des compétences IA ont augmenté de **273 % entre 2019 et 2024**, et les emplois « augmentés » par l'IA progressent plus vite (+252 %) que les emplois « automatisés » (+223 %). Le communiqué Randstad du 23 juillet 2026 (2,1 millions d'offres analysées) indique que les salariés qui utilisent l'IA seraient promus jusqu'à 3,5 fois plus vite et mieux rémunérés d'environ 25 %. Certaines tâches disparaissent bel et bien (saisie, premier tri, traduction brute) : la bonne question n'est pas « vais-je être remplacé ? » mais « quelles tâches de mon poste changent, et comment m'y former ? ».

### Mythe 4 — « L'IA, c'est nouveau »

**Réalité.** La discipline a 70 ans (Dartmouth, 1956), le perceptron en a presque autant, la rétropropagation date de 1986 et le Transformer de 2017 (L001). Ce qui est nouveau depuis novembre 2022, c'est l'**accès grand public** à des modèles génératifs puissants : l'AI Index 2026 note que l'IA générative a atteint **53 % d'adoption en trois ans**, plus vite qu'Internet ou l'ordinateur personnel (nov. 2026).

### Mythe 5 — « L'assistant apprend de ma conversation en direct »

**Réalité.** À l'inférence, les paramètres sont figés (L002). Ce qui donne l'impression de mémoire, c'est la **fenêtre de contexte** (le modèle relit toute la conversation à chaque réponse) et, chez certains éditeurs, des fonctions de mémoire qui stockent des notes **à côté** du modèle. En revanche, vos conversations peuvent servir à un **futur** entraînement si vous ne désactivez pas cette option : d'où la règle de ne jamais y saisir de données confidentielles (module 3 et module 7).

> 💡 **Autrement dit** — L'assistant ressemble à un serveur de restaurant qui relit votre commande à chaque fois qu'il revient à la table (la fenêtre de contexte) : il semble se souvenir, mais il ne change pas de métier pour autant. Certaines applications ajoutent un petit carnet de notes à côté (la « mémoire »). Le vrai risque n'est pas qu'il apprenne en direct, c'est que vos échanges servent plus tard à entraîner une nouvelle version : réglez la confidentialité et ne tapez jamais d'informations confidentielles.

### Mythe 6 — « Il faut être ingénieur pour comprendre »

**Réalité.** Vous venez de comprendre, en trois leçons et sans équation, le cycle données → entraînement → inférence. Les MOOC *Elements of AI* (Helsinki, traduit en français avec Sorbonne Université) et *AI For Everyone* (Andrew Ng) sont bâtis sur ce constat. Les mathématiques ne deviennent nécessaires qu'au niveau 4, pour **construire** des modèles.

### Mythe 7 — « L'IA est gratuite »

**Réalité.** L'inférence se paie au token (L002) ; les abonnements grand public coûtent quelques dizaines d'euros par mois ; et l'investissement privé mondial se chiffre en centaines de milliards : **285,88 milliards de dollars aux États-Unis en 2025, 20,92 en Europe, 12,41 en Chine** selon l'AI Index 2026 (nov. 2026). Coût énergétique et environnemental inclus : chaque requête consomme de l'électricité dans un centre de données. Les modèles ouverts exécutés en local (niveau 2) déplacent le coût vers votre matériel sans le supprimer.

### Mythe 8 — « Le RGPD interdit l'IA en entreprise »

**Réalité.** La CNIL écrit elle-même que « l'idée reçue selon laquelle le RGPD empêcherait l'innovation en IA est fausse » et publie **15 fiches pratiques** (numérotées de 1 à 13) pour développer et utiliser des systèmes d'IA conformes. Ce qui est encadré, c'est l'usage de **données personnelles** : finalité précise, base légale, minimisation, information des personnes. Vous produirez une charte d'usage simplifiée au module 7.

> 💡 **À retenir** — Devant toute affirmation sur l'IA, posez trois questions : *de quelle famille de système parle-t-on ? sur quelles données a-t-il été entraîné ? qui a mesuré le résultat, et comment ?* Ces trois questions désamorcent la quasi-totalité des mythes.

> ⚠️ **Piège fréquent** — Le mythe inverse : « ce n'est qu'un perroquet statistique, ça ne sert à rien ». Les agents IA ont atteint, en 2025, 66,3 % de réussite sur des tâches informatiques du benchmark OSWorld contre 72,35 % pour des humains (AI Index 2026). Sous-estimer l'outil est aussi coûteux que le surestimer.

```quiz
{
  "type": "mise_en_situation",
  "q": "Un collègue affirme : « L'IA est objective, elle ne fait que calculer, on peut lui faire confiance les yeux fermés. » Quelle réponse est la plus juste ?",
  "options": [
    "Il a tort : il reproduit les biais de ses données, on vérifie",
    "Il a raison : une machine qui calcule n'a pas d'opinion propre",
    "Il a raison, sauf le week-end quand les serveurs sont surchargés",
    "Il a tort : l'IA ment volontairement pour plaire"
  ],
  "answer": 0,
  "explanation": "Un modèle apprend à partir de données humaines, avec leurs défauts. L'AI Index 2026 a recensé 362 incidents liés à l'IA en 2025. Il ne « ment » pas exprès, mais il peut se tromper avec assurance : on vérifie toujours."
}
```

## 2. Dix chiffres clés à connaître (nov. 2026)

Les chiffres vieillissent vite : chacun est daté et sourcé pour que vous puissiez le vérifier et l'actualiser. Le rapport *AI Index* de l'Institute for Human-Centered AI de Stanford, publié chaque printemps, est la référence mondiale ; les chiffres français proviennent des plans gouvernementaux et d'études de branche.

| # | Chiffre | Ce qu'il dit | Source et date |
|---|---|---|---|
| 1 | **53 %** | Taux d'adoption de l'IA générative atteint en trois ans — plus rapide qu'Internet ou le PC | AI Index 2026 (avril 2026) |
| 2 | **285,88 Md$ / 20,92 Md$ / 12,41 Md$** | Investissement privé dans l'IA en 2025 : États-Unis / Europe / Chine | AI Index 2026 |
| 3 | **362** | Incidents liés à l'IA signalés en 2025 (record) | AI Index 2026 |
| 4 | **66,3 % vs 72,35 %** | Réussite des agents IA sur OSWorld (tâches sur ordinateur) en 2025, contre les humains ; les agents étaient à ~5 % en 2024 | AI Index 2026 |
| 5 | **1 503 vs 1 464** | Score Arena du meilleur modèle américain contre le meilleur modèle chinois : l'écart se resserre | AI Index 2026 |
| 6 | **91 % → 31 %** | Confiance dans la capacité de l'État à réguler l'IA, de Singapour aux États-Unis | AI Index 2026 (chapitre opinion publique) |
| 7 | **8 % des TPE, 13 % des PME** | Part des très petites et petites entreprises françaises utilisant une IA « clé en main » ; objectif 2030 du plan « Osez l'IA » : 50 % des TPE, 80 % des PME-ETI, 100 % des grands groupes | Plan Osez l'IA, 1er juillet 2025 (Maddyness) |
| 8 | **15 millions puis 30 millions** | Professionnels à former à l'IA d'ici 2030 (Osez l'IA) ; personnes à sensibiliser, former ou accompagner d'ici 2027 (plan « Impulsion IA 2027 », 22 septembre 2026, 80 M€, 12 mesures dont une certification nationale avec l'ANSSI et l'Afpa) | Maddyness ; Le Monde Informatique (23 sept. 2026) |
| 9 | **+273 %** | Croissance des offres d'emploi françaises exigeant des compétences IA entre 2019 et 2024 ; la France devance l'Allemagne et le Royaume-Uni en volume | PwC via Blog du Modérateur (12 juin 2025) |
| 10 | **287 500 salariés à former, 26 % déjà formés** | Dans la seule branche numérique-ingénierie-conseil ; 64 % des entreprises de la branche utilisent l'IA ; ~45 000 emplois IA à créer sous trois ans | OPIIEC (avril 2025) |

Bonus : lors du Sommet pour l'action sur l'IA de Paris (10-11 février 2025), **109 milliards d'euros** d'investissements privés ont été annoncés pour la France et 58 pays ont signé la déclaration finale (Maddyness, 12 février 2025).

🎮 **Défi** — Choisissez trois chiffres du tableau et imaginez la phrase que vous diriez à votre direction pour justifier une formation IA de l'équipe. Exemple : « 8 % des TPE seulement utilisent l'IA : se former maintenant, c'est prendre deux ans d'avance sur nos concurrents. »

> 🔗 **Documentation officielle** — [Stanford HAI — AI Index Report 2026](https://hai.stanford.edu/ai-index/2026-ai-index-report) 🇬🇧 (neuf chapitres : recherche, performance technique, IA responsable, économie, science, médecine, éducation, politiques publiques, opinion) et sa synthèse [12 takeaways from the 2026 report](https://hai.stanford.edu/news/inside-the-ai-index-12-takeaways-from-the-2026-report) 🇬🇧.

```quiz
{
  "q": "Pourquoi chaque chiffre du tableau est-il accompagné d'une source et d'une date ?",
  "options": [
    "Pour faire plus sérieux face à un public de dirigeants",
    "Parce qu'ils vieillissent vite et doivent rester vérifiables",
    "Parce que la loi l'impose pour toute formation professionnelle",
    "Parce que les chiffres sans date sont toujours faux"
  ],
  "answer": 1,
  "explanation": "Dans un domaine qui bouge chaque mois, un chiffre sans date ni source devient vite trompeur. Le rapport AI Index de Stanford, publié chaque printemps, permet de les mettre à jour."
}
```

## 3. L'article 4 de l'AI Act : pourquoi vous êtes ici

Le **règlement (UE) 2024/1689** — l'*AI Act* — est entré en vigueur le 1er août 2024. Son **article 4**, applicable depuis le **2 février 2025**, impose aux **fournisseurs et aux déployeurs** de systèmes d'IA de prendre des mesures pour garantir « dans toute la mesure du possible » un niveau suffisant de **maîtrise de l'IA** (*AI literacy*) de leur personnel et des personnes qui utilisent ces systèmes pour leur compte.


> 📌 **Mise à jour (nov. 2026)** — Depuis l'omnibus (règlement (UE) 2026/1744, publié au JOUE le 24 juillet 2026 et en vigueur le 27 juillet 2026), l'article 4 est reformulé : fournisseurs et déployeurs prennent des mesures qui **favorisent** la maîtrise de l'IA, sans « niveau suffisant » individuel imposé. L'obligation d'agir (former, sensibiliser) demeure ; vérifiez la formulation exacte sur la version consolidée d'EUR-Lex.

Ce que cela signifie concrètement, d'après les clarifications publiées par la Commission européenne en mai 2025 et relayées par les cabinets juridiques :

| Question | Réponse |
|---|---|
| Qui est concerné ? | **Tout employeur** dont les salariés utilisent un système d'IA — y compris un simple assistant génératif comme ChatGPT, Claude ou Copilot. Un déployeur, c'est l'entreprise qui utilise ; un fournisseur, celle qui développe. |
| Un diplôme ou un examen est-il obligatoire ? | Non. Le texte n'impose ni certification ni format ; les mesures doivent être **proportionnées** au contexte, au niveau technique des personnes et aux risques des systèmes utilisés. |
| Que doit couvrir la formation ? | Selon la définition de l'article 3, point 56 : les compétences et connaissances permettant un déploiement éclairé, la conscience des **opportunités**, des **risques** et des **dommages** possibles — soit exactement : fonctionnement (ce module), usages (modules 3-6), limites et cadre juridique (modules 5 et 7). |
| Un simple mémo suffit-il ? | Des manuels ou messages automatiques sont jugés « probablement insuffisants » ; une formation adaptée au poste, tracée (contenu, date, prestataire), est la pratique recommandée. |
| Quelles sanctions ? | L'article 4 n'a pas d'amende propre, mais le régime général de sanctions (chapitre XII) s'applique depuis le **2 août 2025** (article 113) et le contrôle de cette obligation par les autorités nationales démarre le **2 août 2026** ; l'obligation sert de standard de diligence en cas de dommage. Les sanctions générales vont jusqu'à 35 M€ ou 7 % du chiffre d'affaires mondial pour les pratiques interdites, 15 M€ ou 3 % pour les autres manquements. |

Calendrier à retenir (état au 1er novembre 2026) : pratiques interdites et maîtrise de l'IA depuis le 2 février 2025 ; obligations des modèles à usage général (GPAI) depuis le 2 août 2025 ; transparence des chatbots et marquage des contenus générés (article 50) depuis le 2 août 2026 ; les obligations pour les systèmes à **haut risque** (recrutement, crédit, éducation, santé…) ont été reportées au **2 décembre 2027** par le règlement « omnibus numérique IA » de juillet 2026 — à confirmer sur EUR-Lex pour toute décision engageante.

Le **certificat Next Formation IA — Niveau 1** atteste que vous avez suivi une formation structurée couvrant ces attendus et constitue une pièce de la documentation de conformité de votre employeur (plan de formation, trace par salarié). Il ne remplace pas une certification tierce ; nous vous encourageons d'ailleurs à passer en complément des parcours gratuits comme *Elements of AI*, *AI Fluency* de Claude Academy ou Google AI Essentials, qui enrichissent votre dossier.

> ⚠️ **Piège fréquent** — Croire que l'AI Act ne concerne que les « entreprises de la tech ». Un cabinet comptable qui utilise un assistant génératif pour ses courriers est un **déployeur** au sens du règlement, et donc tenu par l'article 4.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un cabinet de 5 personnes qui utilise ChatGPT pour rédiger ses courriers est concerné par l'obligation de « maîtrise de l'IA » de l'article 4 de l'AI Act.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. En utilisant un système d'IA dans son activité, le cabinet est un « déployeur » au sens du règlement. Il doit prendre des mesures proportionnées qui favorisent la maîtrise de l'outil par son personnel — sans obligation de diplôme ni d'examen. Depuis l'omnibus (règlement (UE) 2026/1744, en vigueur le 27 juillet 2026), l'article 4 n'impose plus de « niveau suffisant » à chaque individu, mais l'obligation d'agir demeure."
}
```

> 🔗 **Documentation officielle** — [Règlement (UE) 2024/1689 sur EUR-Lex](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) 🇫🇷 (texte officiel, article 4 « Maîtrise de l'IA » et article 3 point 56) ; [CMS Law — European Commission clarifies literacy requirements under the AI Act](https://cms.law/en/int/legal-updates/european-commission-clarifies-literacy-requirements-under-the-ai-act) 🇬🇧 ; [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷.

```mission
{
  "title": "Lisez vous-même l'article 4 de l'AI Act",
  "url": "https://eur-lex.europa.eu/eli/reg/2024/1689/oj",
  "steps": ["Ouvrez le règlement (UE) 2024/1689 sur EUR-Lex et choisissez la langue FR", "Utilisez la recherche de votre navigateur (Ctrl+F ou Cmd+F) et tapez « Article 4 »", "Lisez le titre de l'article et repérez les deux catégories d'acteurs visées"],
  "question": "Quel est le titre de l'article 4, et quels acteurs vise-t-il dans sa version initiale de 2024 ?",
  "hint": "Les deux acteurs sont définis dans la section 3 de cette leçon : celui qui développe et celui qui utilise.",
  "answer": "« Maîtrise de l'IA » ; l'obligation vise les fournisseurs et les déployeurs de systèmes d'IA (texte du 13 juin 2024, article applicable depuis le 2 février 2025). Attention : l'omnibus (règlement (UE) 2026/1744, en vigueur le 27 juillet 2026) a reformulé l'article 4 — mesures qui favorisent la maîtrise de l'IA, sans niveau individuel imposé ; consultez la version consolidée.",
  "xp": 15
}
```

```mission
{
  "title": "Combien de fiches pratiques IA la CNIL propose-t-elle ?",
  "url": "https://cnil.fr/fr/les-fiches-pratiques-ia",
  "steps": ["Ouvrez la page « Les fiches pratiques IA » du site de la CNIL", "Parcourez la liste des fiches", "Comptez-les et notez le titre d'une fiche qui vous concerne"],
  "question": "Combien de fiches pratiques la CNIL a-t-elle publiées pour aider à concevoir des systèmes d'IA conformes au RGPD ?",
  "hint": "Le nombre est cité dans le « Mythe 8 » de cette leçon : la mission consiste à le vérifier à la source.",
  "answer": "15 fiches pratiques (numérotées de 1 à 13, dont une fiche 4 en deux parties et une fiche 8 bis), plus une fiche synthèse, une introduction et une liste de vérification (vérifié le 5 nov. 2026) ; la CNIL peut en ajouter.",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Lors d'un comité de direction d'une PME de 60 salariés (négoce de matériel électrique), quatre phrases sont prononcées :

- (A) « On ne va pas former les commerciaux à l'IA, c'est un truc d'informaticiens. »
- (B) « De toute façon ChatGPT apprend tout ce qu'on lui dit, donc on interdit tout. »
- (C) « L'IA ne se trompe pas, on peut envoyer les devis générés sans relire. »
- (D) « L'AI Act, c'est pour Google et Microsoft, pas pour nous. »

Rédigez, pour chaque phrase, une **réponse de trois à cinq lignes** qui (1) nomme le mythe, (2) rétablit le fait avec une notion vue dans le module (famille d'IA, entraînement/inférence, hallucination, article 4…), (3) cite **un chiffre ou un texte sourcé** de cette leçon, et (4) propose une action concrète.

**Critères de réussite.**
- Les quatre réponses sont argumentées techniquement et non par simple opinion.
- Au moins trois chiffres ou références différents du tableau ou de la section 3 sont cités avec leur date.
- Chaque réponse se termine par une action (former, paramétrer la confidentialité, instaurer une relecture, rédiger une charte).
- Le ton reste professionnel : on corrige une idée, pas une personne.

<details>
<summary>Pistes de corrigé</summary>

- **(A)** Mythe 6. L'article 4 vise *tout* le personnel utilisant l'IA ; la maîtrise de l'IA ne demande aucune compétence technique (ce module en est la preuve). Chiffre : 15 millions de professionnels à former d'ici 2030 (Osez l'IA). Action : inscrire les commerciaux au niveau 1, tracer la formation.
- **(B)** Mythe 5. À l'inférence, le modèle n'apprend pas ; le risque réel est la réutilisation des conversations pour un entraînement futur et la fuite de données personnelles. Référence : fiches pratiques de la CNIL. Action : compte professionnel avec option d'entraînement désactivée, charte listant les données interdites de saisie (module 7).
- **(C)** Mythe 2. Un LLM génère le token le plus plausible ; 362 incidents recensés en 2025 (AI Index 2026). Action : relecture systématique des prix et références, prompt alimenté avec le catalogue à jour.
- **(D)** Mythe de périmètre. Toute entreprise qui utilise un système d'IA est un déployeur ; article 4 applicable depuis le 2 février 2025, enforcement depuis le 2 août 2026. Action : inventaire des outils IA utilisés, plan de formation, charte d'usage.

</details>

## ✅ Auto-évaluation express

1. Depuis quelle date l'obligation de maîtrise de l'IA (article 4) est-elle applicable ?
2. Quel organisme publie chaque année le rapport *AI Index* ?
3. Un assistant génératif modifie-t-il ses paramètres pendant que vous l'utilisez ?

<details>
<summary>Réponses</summary>

1. Depuis le 2 février 2025 (règlement (UE) 2024/1689, article 4), avec surveillance de marché et sanctions applicables à partir du 2 août 2026.
2. L'Institute for Human-Centered AI (HAI) de l'université Stanford.
3. Non : l'inférence ne modifie pas les paramètres ; seules des fonctions de mémoire externes ou un futur entraînement peuvent réutiliser vos échanges.

</details>

## 📚 Pour aller plus loin
- [Règlement (UE) 2024/1689 — AI Act, texte intégral](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) 🇫🇷 — lisez au moins l'article 3 (définitions), l'article 4 et l'article 50.
- [donneespersonnelles.fr — Omnibus numérique IA](https://donneespersonnelles.fr/omnibus-numerique-ia) 🇫🇷 — calendrier d'application mis à jour après le report des obligations « haut risque ».
- [RTR (Autriche) — AI literacy, article 4](https://www.rtr.at/rtr/service/ki-servicestelle/ai-act/ai_literacy.en.html) 🇬🇧 — guide pratique d'une autorité nationale sur la mise en œuvre de l'article 4.
- [Plan « Osez l'IA » (Maddyness)](https://www.maddyness.com/2025/07/01/osez-lia-le-plan-de-clara-chappaz-pour-accelerer-ladoption-de-lia-dans-les-entreprises-francaises/) 🇫🇷 et [Plan « Impulsion IA 2027 » (Le Monde Informatique)](https://www.lemondeinformatique.fr/actualites/lireamp-le-gouvernement-lance-un-plan-pour-former-a-l-ia-100805.html) 🇫🇷 — les deux plans publics français de formation à l'IA.
- [Blog du Modérateur — Étude PwC sur les compétences IA](https://www.blogdumoderateur.com/etude-competences-ia-offres-emploi/) 🇫🇷 et [OPIIEC — IA dans la branche numérique](https://www.syntec-ingenierie.fr/app/uploads/2025/06/20250428_OPIIEC_IA_A_RETENIR.pdf) 🇫🇷 — les chiffres emploi utilisés dans cette leçon.

> 🗺️ **Et maintenant ?** — Le module 1 est bouclé ; le module 2 ouvre la « boîte noire » des grands modèles de langage, en commençant en L005 par ce que sont réellement les tokens, les paramètres et les poids.
