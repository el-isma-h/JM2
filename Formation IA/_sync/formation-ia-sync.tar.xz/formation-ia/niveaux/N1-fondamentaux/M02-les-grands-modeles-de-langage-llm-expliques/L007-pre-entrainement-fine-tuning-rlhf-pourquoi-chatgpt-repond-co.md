---
id: L007
module: M02
level: N1
title: "Pré-entraînement, fine-tuning, RLHF : pourquoi ChatGPT répond comme ça"
minutes: 40
objectives:
  - "Décrire les trois étapes de fabrication d'un assistant IA (pré-entraînement, fine-tuning supervisé, alignement par préférences humaines) et ce que chacune apporte"
  - "Expliquer pourquoi un modèle de base « complète » alors qu'un assistant « répond », et d'où viennent le ton, les refus et les formules de politesse"
  - "Identifier dans une réponse les traces du prompt système et de l'alignement, et en tirer des règles d'usage"
skills: ["C1.1"]
sources:
  - { title: "Ouyang et al., « Training language models to follow instructions with human feedback » (InstructGPT, 2022)", url: "https://arxiv.org/abs/2203.02155", lang: "en" }
  - { title: "Andrej Karpathy — [1hr Talk] Intro to Large Language Models", url: "https://www.youtube.com/watch?v=zjkBMFhNj_g", lang: "en" }
  - { title: "Hugging Face — a smol course (post-training : SFT, DPO, RL)", url: "https://huggingface.co/learn/smol-course", lang: "en" }
  - { title: "Hugging Face — TRL, intégration PEFT (SFTTrainer, DPOTrainer, GRPO)", url: "https://huggingface.co/docs/trl/main/en/peft_integration", lang: "en" }
  - { title: "Anthropic — System prompts des applications Claude (release notes)", url: "https://platform.claude.com/docs/en/release-notes/system-prompts/overview", lang: "en" }
  - { title: "Claude Academy — AI capabilities and limitations (How AI gets its character)", url: "https://academy.claude.com/courses/ai-capabilities-and-limitations", lang: "en" }
  - { title: "OpenAI — Supervised fine-tuning", url: "https://developers.openai.com/api/docs/guides/supervised-fine-tuning", lang: "en" }
---

# Pré-entraînement, fine-tuning, RLHF : pourquoi ChatGPT répond comme ça

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 2

## 🎯 Ce que vous saurez faire
- Raconter la « chaîne de fabrication » d'un assistant IA en trois étapes, avec les ordres de grandeur (données, durée, coût, nombre d'humains impliqués).
- Expliquer pourquoi un modèle brut, à qui l'on demande « Quelle est la capitale de l'Australie ? », peut répondre par… une autre question.
- Reconnaître ce qui, dans une réponse, vient de l'alignement (politesse, refus, structure en listes) plutôt que du « savoir » du modèle.
- Utiliser les bons mots : *pré-entraînement*, *fine-tuning*, *RLHF*, *DPO*, *prompt système*, *modèle de raisonnement*.

> 🧭 **En clair** — Fabriquer un assistant comme ChatGPT ressemble à la formation d'un futur serveur de grand restaurant. D'abord, il **lit énormément** pour se cultiver, sans parler à personne : c'est le *pré-entraînement*. Ensuite, il **observe des serveurs modèles** et apprend à répondre poliment à une commande : c'est le *fine-tuning*. Enfin, le maître d'hôtel lui dit après chaque service « ça, c'était mieux que ça » : c'est l'*alignement* (RLHF), qui lui donne ses bonnes manières et sa prudence. Et chaque matin, on lui glisse une fiche du jour — date, consignes, plats disponibles — c'est le *prompt système*. Comprendre ces quatre couches, c'est comprendre pourquoi l'assistant répond « comme ça ».

## 1. Le point de départ : un modèle de base ne « répond » pas

Reprenons le fichier de poids de la leçon L005. Juste après l'entraînement initial, ce fichier contient un **modèle de base** (*base model*, ou *pretrained model*). Sa seule compétence : continuer un texte.

Demandez-lui « Quelle est la capitale de l'Australie ? » et vous obtiendrez, selon les cas :

- « Quelle est la capitale du Canada ? Quelle est la capitale du Brésil ? » (il continue une liste de questions de quiz, très fréquente sur Internet) ;
- « Réponse : Sydney. » (faux, mais statistiquement fréquent dans les textes) ;
- ou, avec de la chance, « Canberra ».

Le modèle de base est un **moteur de complétion** ; pour en faire un **assistant** qui répond, qui dit « bonjour », qui refuse d'aider à fabriquer une arme et qui structure ses réponses en listes à puces, il faut deux étapes supplémentaires. C'est ce que l'on appelle le **post-entraînement** (*post-training*).

```
Étape 1 ─ PRÉ-ENTRAÎNEMENT      « Internet entier »      → modèle de base (sait continuer)
Étape 2 ─ FINE-TUNING SUPERVISÉ  dialogues exemplaires    → assistant (sait répondre)
Étape 3 ─ ALIGNEMENT (RLHF/DPO)  préférences humaines     → assistant utile, poli, prudent
          + prompt système        consignes au démarrage   → la « personnalité » du jour
```

```quiz
{
  "type": "mise_en_situation",
  "q": "Vous demandez « Quelle est la capitale de l'Australie ? » à un modèle tout juste pré-entraîné, et il répond « Quelle est la capitale du Canada ? ». Pourquoi ?",
  "options": [
    "Il est en panne ou mal installé sur le serveur",
    "Il ne connaît pas encore l'Australie ni sa capitale",
    "Il ne sait que prolonger un texte, comme une liste de quiz",
    "Il refuse de répondre aux questions de géographie"
  ],
  "answer": 2,
  "explanation": "Un modèle de base est un « moteur de complétion » : il prolonge le texte de façon plausible. Le format « question → réponse » ne s'apprend qu'à l'étape suivante, le fine-tuning supervisé."
}
```

## 2. Étape 1 — Le pré-entraînement : lire Internet pour apprendre à continuer

### 2.1 Les données
On rassemble des milliers de milliards de tokens : pages web filtrées (Common Crawl), livres, articles scientifiques, code source, forums, Wikipédia dans toutes les langues. Le nettoyage est une science à part entière : déduplication, suppression du spam et des contenus illicites, équilibrage entre les langues et les domaines. Un cours comme Stanford CS336 consacre deux séances entières aux données.

### 2.2 L'apprentissage
Le modèle lit un fragment, prédit le token suivant, compare avec le vrai token, et ajuste très légèrement ses milliards de paramètres pour réduire l'erreur. Puis recommence. Des milliers de milliards de fois. Cela demande des milliers de cartes graphiques pendant des semaines ou des mois, et une facture d'électricité et de matériel qui se compte en dizaines ou centaines de millions d'euros pour les modèles de pointe — ce qui explique que seule une poignée d'acteurs mondiaux les fabriquent.

Analogie : un stagiaire qui aurait lu toute la bibliothèque nationale, tous les forums, tous les dépôts de code, **sans jamais parler à personne**. Il connaît une quantité phénoménale de choses, mais il ne sait pas qu'on attend de lui une réponse.

> 💡 **À retenir** — Tout ce que le modèle « sait » vient de cette étape, et sa connaissance s'arrête à la date de fin de collecte (*knowledge cutoff*) : juin 2026 pour les Claude 5.5, 30 avril 2026 pour GPT-6 Astra, mai 2026 pour Grok 4.7 (nov. 2026). Les deux étapes suivantes ajoutent très peu de connaissances : elles ajoutent un **comportement**.

## 3. Étape 2 — Le fine-tuning supervisé : apprendre le format « question → réponse »

On prend le modèle de base et on continue son entraînement, mais sur un jeu de données très différent : quelques dizaines ou centaines de milliers de **dialogues exemplaires**, rédigés par des humains (puis, de plus en plus, par d'autres modèles sous supervision humaine) :

```
Utilisateur : Rédige un objet d'e-mail pour relancer un devis.
Assistant   : Voici trois propositions :
              1. « Suite à notre devis n° 2026-118 »
              2. …
```

Le modèle apprend ainsi le **format** : un tour de parole « utilisateur », un tour « assistant », une réponse directe et structurée. C'est le *supervised fine-tuning* (SFT, fine-tuning supervisé). Dans le cours ouvert de Hugging Face *a smol course*, c'est l'unité 1, « Instruction Tuning ».

C'est aussi à cette étape qu'on introduit les **gabarits de conversation** (*chat templates*) : des balises invisibles qui marquent qui parle. Quand vous écrivez dans l'interface, votre texte est enveloppé dans ce gabarit avant d'être envoyé au modèle.

Le fine-tuning est aussi l'outil dont dispose une entreprise pour **spécialiser** un modèle ouvert (ton de la marque, vocabulaire d'un métier, format de sortie) — nous le pratiquerons au Niveau 4. À noter (nov. 2026) : OpenAI a annoncé l'arrêt progressif de sa plateforme de fine-tuning pour les nouveaux comptes ; la pratique se concentre désormais sur les modèles à poids ouverts.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : le fine-tuning supervisé et l'alignement apportent au modèle l'essentiel de ses connaissances sur le monde.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Presque tout le « savoir » vient du pré-entraînement, qui s'arrête à la date de connaissance. Les étapes suivantes ajoutent surtout un comportement : le format des réponses, le ton, la prudence."
}
```

## 4. Étape 3 — L'alignement : apprendre ce que les humains préfèrent

### 4.1 Le problème que le SFT ne règle pas
Après le SFT, l'assistant répond, mais il répond parfois trop long, parfois avec aplomb sur des choses fausses, parfois de façon dangereuse. Il faudrait lui enseigner non pas *une* bonne réponse, mais *ce qu'est une bonne réponse* en général. Or il est très difficile d'écrire cela sous forme de règles.

### 4.2 RLHF : apprendre par comparaison
L'idée, popularisée par l'article InstructGPT (OpenAI, mars 2022) puis par ChatGPT, est l'**apprentissage par renforcement à partir de retours humains** (*Reinforcement Learning from Human Feedback*, RLHF) :

1. On génère **plusieurs réponses** à une même question.
2. Des annotateurs humains les **classent** de la meilleure à la pire (il est bien plus facile de comparer que de rédiger).
3. On entraîne un petit « modèle de récompense » à imiter ces préférences.
4. Le modèle principal est ajusté pour produire des réponses que le modèle de récompense note bien.

Analogie : un apprenti pâtissier à qui l'on ne donne pas de recette, mais à qui le chef dit, à chaque fournée, « celle-ci est meilleure que celle-là ». Au bout de quelques milliers de fournées, l'apprenti a intériorisé le goût du chef.

Variantes courantes en 2026 (dossier de recherche 04) : **DPO** (*Direct Preference Optimization*, 2023) obtient un résultat similaire sans modèle de récompense, en apprenant directement sur les paires « préférée / rejetée » ; **GRPO** et les méthodes de type *RLVR* (récompense vérifiable) servent à entraîner les **modèles de raisonnement**, en récompensant les réponses justes à des problèmes de mathématiques ou de code — c'est ainsi que les modèles ont appris à « réfléchir » longuement avant de répondre. Ces méthodes sont toutes implémentées dans la bibliothèque ouverte TRL de Hugging Face.

> 💡 **Autrement dit** — Toutes ces abréviations (RLHF, DPO, GRPO…) désignent des façons d'**apprendre par les retours** plutôt que par une recette. Certaines utilisent un « juge » intermédiaire qui imite les préférences humaines, d'autres s'en passent. Pour les modèles qui « réfléchissent » avant de répondre, on récompense simplement les bonnes réponses à des problèmes dont on peut vérifier le résultat (un calcul juste, un programme qui fonctionne).

### 4.3 Constitutional AI : l'approche d'Anthropic
Anthropic complète les retours humains par un jeu de **principes écrits** (une « constitution ») : le modèle critique et révise lui-même ses réponses à la lumière de ces principes, et l'on entraîne sur le résultat. Le cours *AI capabilities and limitations* de Claude Academy appelle ce chapitre *How AI gets its character* — « comment l'IA acquiert son caractère ».

> ⚠️ **Piège fréquent** — « Le modèle a été programmé pour refuser. » Non : personne n'a écrit `if question_dangereuse: refuser`. Les refus, le ton, l'humilité (« je ne suis pas certain ») sont des **comportements appris par préférence**, donc statistiques, donc imparfaits dans les deux sens : des refus excessifs sur des questions légitimes, et des failles qu'exploitent les « jailbreaks » (module M07).

```quiz
{
  "q": "Dans la méthode RLHF, quel travail les humains effectuent-ils principalement ?",
  "options": [
    "Ils écrivent eux-mêmes chaque bonne réponse",
    "Ils programment des règles « si… alors refuser »",
    "Ils corrigent les fautes d'orthographe et de grammaire du modèle",
    "Ils classent des réponses, de la meilleure à la pire"
  ],
  "answer": 3,
  "explanation": "Comparer est beaucoup plus facile que rédiger. Les annotateurs classent des réponses ; un « modèle de récompense » apprend leurs préférences, puis guide l'ajustement de l'assistant."
}
```

## 5. La dernière couche : le prompt système

Même après l'alignement, l'assistant que vous utilisez reçoit, au début de chaque conversation, un texte invisible pour vous : le **prompt système** (*system prompt*). Il fixe la date du jour, le nom du modèle, le ton attendu, les outils disponibles, et des consignes comme « réponds dans la langue de l'utilisateur ». Anthropic **publie** les prompts système de ses applications grand public, version par version — une transparence rare et utile pour comprendre pourquoi Claude se présente comme il le fait.

> 🔗 **Documentation officielle** — [System prompts des applications Claude](https://platform.claude.com/docs/en/release-notes/system-prompts/overview) 🇬🇧 : lisez celui de Claude Fable 5.1 ; vous y reconnaîtrez des comportements que vous attribuiez au « modèle ».

Dans l'API et dans les outils « projets » ou « GPT personnalisés », **c'est vous** qui écrivez ce prompt système : c'est le levier numéro un du module M04 (prompt engineering).

## 6. Synthèse : d'où vient chaque comportement ?

| Vous observez… | Cela vient surtout de… |
|---|---|
| Il connaît le Code du travail de 2024 | Pré-entraînement (données jusqu'au cutoff) |
| Il répond en listes à puces bien formatées | Fine-tuning supervisé (format des dialogues exemplaires) |
| Il refuse d'écrire un e-mail d'hameçonnage | Alignement (RLHF / DPO / constitution) |
| Il ajoute « n'hésitez pas si vous avez d'autres questions » | Alignement (les annotateurs ont préféré ces fins) |
| Il « réfléchit » 20 secondes avant une réponse de maths | Entraînement par renforcement sur récompense vérifiable (modèle de raisonnement) |
| Il sait qu'on est le 1er novembre 2026 | Prompt système (il ne le saurait pas sinon) |
| Il dit « je ne sais pas » sur un événement de septembre 2026 | Cutoff + alignement (humilité apprise) |

🎮 **Défi** — Demandez à votre assistant : « Quelle est la date du jour ? » puis « Comment le sais-tu ? ». Une bonne réponse mentionne le prompt système ou le contexte fourni, pas « ma mémoire ».

```mission
{
  "title": "Retrouvez l'article InstructGPT",
  "url": "https://arxiv.org/abs/2203.02155",
  "steps": ["Ouvrez la page arXiv de l'article « Training language models to follow instructions with human feedback »", "Lisez le nom du premier auteur et l'organisation (indiquée dans le résumé)", "Repérez la date de première soumission"],
  "question": "Qui est le premier auteur de l'article et en quel mois de 2022 a-t-il été soumis ?",
  "hint": "Le mois est cité dans la section 4.2 de cette leçon ; le nom du premier auteur figure juste sous le titre.",
  "answer": "Long Ouyang (OpenAI), première soumission en mars 2022 (4 mars).",
  "xp": 10
}
```

```mission
{
  "title": "Que contient le « smol course » de Hugging Face ?",
  "url": "https://huggingface.co/learn/smol-course",
  "steps": ["Ouvrez la page du cours « a smol course » sur Hugging Face Learn", "Parcourez la liste des unités", "Repérez celles qui correspondent aux étapes de cette leçon"],
  "question": "Citez au moins trois thèmes couverts par ce cours gratuit, et dites lequel correspond au « fine-tuning supervisé » de la section 3.",
  "hint": "Cherchez les sigles SFT et DPO, déjà rencontrés dans cette leçon.",
  "answer": "Le cours couvre notamment le fine-tuning supervisé (SFT, « Instruction Tuning » en unité 1), l'évaluation, l'alignement par préférences (DPO), les modèles vision-langage, l'apprentissage par renforcement et les données synthétiques (état au 1er nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Vous êtes chargé(e) de recrutement dans une ETI industrielle. Posez à deux assistants différents (par exemple Claude et ChatGPT, ou Le Chat de Mistral) exactement la même demande :

« Rédige une réponse négative à un candidat non retenu après entretien, en 80 mots. »

Puis analysez les deux réponses avec la grille suivante :

| Critère | Réponse A | Réponse B |
|---|---|---|
| Respect du format (≈ 80 mots, e-mail) | | |
| Formules de politesse / d'empathie présentes | | |
| Ajout non demandé (conseils, « n'hésitez pas… ») | | |
| Mention d'une loi ou d'un fait vérifiable | | |
| Ce qui relève du **SFT** (format) / de l'**alignement** (ton) / du **pré-entraînement** (faits) | | |

Terminez par trois lignes : quel comportement souhaiteriez-vous modifier, et par quel moyen à votre portée (prompt système d'un projet, consigne dans la demande) ?

**Critères de réussite.** La grille est remplie pour les deux réponses ; chaque ligne est attribuée à la bonne étape de fabrication ; la modification proposée passe par le prompt (et non par un ré-entraînement, hors de portée d'un utilisateur).

<details>
<summary>Pistes de corrigé</summary>

- Le respect du nombre de mots et la structure « objet / corps / signature » viennent du SFT.
- L'empathie (« nous avons été sensibles à votre parcours ») et les ajouts non demandés sont typiques de l'alignement : les annotateurs ont préféré, en moyenne, des réponses chaleureuses et complètes — quitte à dépasser la consigne.
- Une mention juridique (par exemple sur la conservation des candidatures) vient du pré-entraînement et doit être vérifiée (L008).
- Modification réaliste : un prompt système de projet « Tu rédiges des e-mails RH sobres, sans conseils non sollicités, 80 mots maximum ». Cela ne change pas le modèle ; cela change ce qu'il reçoit.
</details>

## ✅ Auto-évaluation express

1. Pourquoi un modèle de base peut-il répondre à une question par une autre question ?
2. Dans le RLHF, que fournissent exactement les annotateurs humains : des réponses rédigées, ou des classements ?
3. Vrai ou faux : la date du jour fait partie des connaissances apprises pendant le pré-entraînement.

<details>
<summary>Réponses</summary>

1. Parce qu'il n'a appris qu'à continuer un texte de façon plausible ; sur Internet, une question est souvent suivie d'autres questions (listes, quiz). Le format « question → réponse » s'apprend au fine-tuning supervisé.
2. Des **classements** (ou des paires « préférée / rejetée ») entre plusieurs réponses générées par le modèle. Les réponses rédigées de A à Z relèvent du fine-tuning supervisé.
3. **Faux.** Le modèle ne sait rien au-delà de sa date de connaissance et n'a pas d'horloge ; la date est fournie par le prompt système (ou par vous).
</details>

## 📚 Pour aller plus loin
- [InstructGPT — Training language models to follow instructions with human feedback (arXiv, 2022)](https://arxiv.org/abs/2203.02155) 🇬🇧 — l'article qui a décrit le RLHF tel qu'utilisé pour ChatGPT ; la figure 2 résume les trois étapes de cette leçon.
- [Hugging Face — a smol course](https://huggingface.co/learn/smol-course) 🇬🇧 — cours gratuit sur le post-entraînement (SFT, évaluation, DPO, RL) avec certificats ; nous le mettrons en pratique au Niveau 4.
- [Hugging Face — TRL et PEFT](https://huggingface.co/docs/trl/main/en/peft_integration) 🇬🇧 — la bibliothèque où vivent SFTTrainer, DPOTrainer et GRPO.
- [Anthropic — System prompts publiés](https://platform.claude.com/docs/en/release-notes/system-prompts/overview) 🇬🇧 — pour lire « la personnalité » de Claude noir sur blanc.
- [OpenAI — Supervised fine-tuning](https://developers.openai.com/api/docs/guides/supervised-fine-tuning) 🇬🇧 — la description officielle du SFT côté OpenAI (plateforme en cours d'arrêt pour les nouveaux comptes, nov. 2026).
- [Andrej Karpathy — Intro to Large Language Models](https://www.youtube.com/watch?v=zjkBMFhNj_g) 🇬🇧 — la seconde partie de la conférence porte précisément sur le passage du modèle de base à l'assistant.

> 🗺️ **Et maintenant ?** — Vous savez comment un assistant est fabriqué ; la leçon L008 explore ses limites au quotidien : la fenêtre de contexte, la température et les fameuses « hallucinations ».
