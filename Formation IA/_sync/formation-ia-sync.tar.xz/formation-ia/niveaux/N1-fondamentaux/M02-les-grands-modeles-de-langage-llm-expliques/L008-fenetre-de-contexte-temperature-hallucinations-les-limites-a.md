---
id: L008
module: M02
level: N1
title: "Fenêtre de contexte, température, hallucinations : les limites à connaître"
minutes: 40
objectives:
  - "Expliquer la fenêtre de contexte comme mémoire de travail du modèle et en déduire des règles pratiques (longueur des conversations, pièces jointes, coût)"
  - "Expliquer l'effet de la température sur la variabilité des réponses et savoir quand la régler"
  - "Identifier une hallucination sur un exemple, en expliquer la cause et appliquer quatre parades"
skills: ["C1.1"]
sources:
  - { title: "Anthropic — Context windows", url: "https://platform.claude.com/docs/en/build-with-claude/context-windows", lang: "en" }
  - { title: "Anthropic — Using the Messages API (paramètres non supportés : temperature)", url: "https://platform.claude.com/docs/en/build-with-claude/working-with-messages", lang: "en" }
  - { title: "Anthropic — Prompt caching", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-caching", lang: "en" }
  - { title: "Anthropic — Citations", url: "https://platform.claude.com/docs/en/build-with-claude/citations", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "Claude Academy — AI capabilities and limitations (Knowledge, Working Memory, Steerability)", url: "https://academy.claude.com/courses/ai-capabilities-and-limitations", lang: "en" }
  - { title: "Google — Gemini API, modèles", url: "https://ai.google.dev/gemini-api/docs/models", lang: "en" }
---

# Fenêtre de contexte, température, hallucinations : les limites à connaître

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 2

## 🎯 Ce que vous saurez faire
- Dire ce qu'un modèle « a sous les yeux » à un instant donné, et pourquoi une conversation de trois heures finit par coûter cher et perdre le fil.
- Régler (ou ne pas régler) la température selon que vous voulez un contrat ou un slogan.
- Reconnaître une hallucination au premier coup d'œil et appliquer les quatre parades de base — avant même le module M05 consacré à la vérification.
- Expliquer à votre équipe les trois limites d'un LLM en une minute : *il ne voit que son contexte, il tire au sort, il invente avec assurance*.

> 🧭 **En clair** — Un assistant IA a trois limites à garder en tête, comme un très bon collaborateur un peu particulier. 1) Il ne travaille qu'avec les papiers posés **sur son bureau** : votre conversation et vos documents (c'est la *fenêtre de contexte*) ; ce qui n'y est pas, il l'ignore. 2) Il a un petit **bouton d'audace**, la *température* : réglé bas, il reste sage et prévisible ; réglé haut, il devient inventif mais moins fiable. 3) Quand il ne sait pas, il lui arrive de **broder avec aplomb** — on parle d'*hallucination*. La bonne nouvelle : quelques réflexes simples (lui donner la source, exiger des citations, l'autoriser à dire « je ne sais pas », vérifier ce qui compte) réduisent fortement ces risques.

## 1. La fenêtre de contexte : la mémoire de travail du modèle

### 1.1 Tout ce que le modèle « voit »

Un LLM n'a **aucune mémoire** entre deux appels. À chaque réponse, il ne connaît que ce qui se trouve dans sa **fenêtre de contexte** (*context window*) : le prompt système, l'intégralité de la conversation depuis le début, les documents joints, et la réponse en cours de génération. Tout cela partage une enveloppe maximale de tokens.

Analogie : un bureau. Le modèle ne peut travailler qu'avec les documents posés dessus. Le bureau est devenu immense en 2026, mais il a des bords, et tout ce qui tombe par terre n'existe plus.

| Modèle (nov. 2026) | Fenêtre de contexte | Sortie max | Source |
|---|---|---|---|
| Claude Fable 5.1 / Opus 5.5 / Sonnet 5.5 / Haiku 5.5 | 1 000 000 tokens | 128 000 | Anthropic, pages modèles |
| GPT-6 Astra / GPT-6.1 Sol / Terra / Luna | 1 050 000 tokens | 128 000 | OpenAI, page Models |
| Gemini 4 Argon / Gemini 3.8 Flash | ~1 000 000 tokens | 65 536 (3.8 Flash) | Google, page Models |
| Grok 4.7 | 500 000 tokens | — | xAI, page Models |
| Modèles ouverts locaux (Qwen3.8-27B, Gemma 4, gpt-oss) | 128 000 à 262 000 tokens | — | fiches Hugging Face |

Un million de tokens, c'est environ 555 000 mots anglais (tokenizer Claude 2026) — l'équivalent de cinq ou six romans, ou d'un dossier de 1 500 pages. C'est pourquoi Claude accepte des PDF jusqu'à 600 pages par requête (nov. 2026).

### 1.2 Ce que « 1 million » ne garantit pas

> ⚠️ **Piège fréquent** — « Le modèle a tout lu, donc il a tout pris en compte. » Une grande fenêtre permet de *placer* l'information ; elle ne garantit pas qu'elle sera *bien utilisée*. Les éditeurs eux-mêmes documentent des techniques pour les longs contextes (placer les documents en tête, demander d'abord des citations exactes avant de répondre). Plus le contexte est long et bruyant, plus le risque de passer à côté d'un détail augmente. Un contrat de 40 pages ? Joignez-le. Trois ans d'e-mails « au cas où » ? Non.

### 1.3 Trois conséquences pratiques

1. **Une conversation longue coûte de plus en plus cher.** À chaque nouveau message, *toute* la conversation est renvoyée au modèle. Au vingtième échange d'une conversation avec un PDF de 100 pages, ce sont les 100 pages qui sont relues à chaque tour. Les API disposent d'un mécanisme de **cache de prompt** (*prompt caching*) qui facture la relecture à 10 % du prix de base, voire 5 % sur Opus et Sonnet 5.5 (Anthropic, nov. 2026), et certains tarifs doublent au-delà d'un seuil : Haiku 5.5 passe de 0,10 $ à 0,50 $ par million de tokens d'entrée au-delà de 100 000 tokens ; Grok 4.7 double au-delà de 200 000.
2. **Le fil se perd.** Quand la fenêtre est pleine, les interfaces résument ou tronquent le début (Anthropic appelle cela la *compaction*). Vos consignes initiales peuvent disparaître : répétez-les, ou ouvrez une nouvelle conversation avec un résumé.
3. **« Il se souvient de moi » est presque toujours faux.** Sauf fonction de mémoire explicite (projets, mémoire persistante), une nouvelle conversation part de zéro.

> 🔗 **Documentation officielle** — [Context windows](https://platform.claude.com/docs/en/build-with-claude/context-windows) 🇬🇧 explique le partage entrée/sortie, et [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 détaille les économies possibles.

**Règle d'or pour les professionnels** : une conversation = une tâche. Résumez, puis repartez propre.

```quiz
{
  "type": "mise_en_situation",
  "q": "Depuis trois heures, vous travaillez dans la même conversation avec un PDF de 100 pages. L'assistant semble avoir oublié la consigne de ton donnée au début. Que faites-vous ?",
  "options": [
    "Vous faites résumer, puis repartez dans une conversation neuve",
    "Vous continuez : il finira bien par se souvenir de la consigne",
    "Vous changez d'ordinateur ou de navigateur",
    "Vous augmentez la température"
  ],
  "answer": 0,
  "explanation": "Quand la fenêtre de contexte se remplit, le début peut être résumé ou tronqué, et chaque message coûte de plus en plus cher. Règle d'or : une conversation = une tâche ; résumez, puis repartez propre."
}
```

## 2. La température : le bouton d'audace

### 2.1 Ce qu'elle règle

En L006, nous avons vu que le modèle produit une liste de probabilités, puis **tire au sort** le token suivant. La **température** règle l'audace de ce tirage :

| Température | Comportement | Usage typique |
|---|---|---|
| 0 (ou proche) | Choisit presque toujours le token le plus probable ; réponses stables, prévisibles, parfois répétitives | Extraction de données, classification, réponses factuelles, code |
| ~0,7 – 1 (valeur par défaut courante) | Équilibre variété / cohérence | Rédaction, résumé, conversation |
| > 1 (jusqu'à 2 chez certains éditeurs) | Tirages improbables acceptés ; créativité… et incohérences | Brainstorming de noms, poésie, variantes |

Un paramètre voisin, **top-p** (*nucleus sampling*), limite le tirage aux tokens dont les probabilités cumulées atteignent *p* (par exemple 0,9) : on coupe la « queue » des options absurdes. On règle en général l'un ou l'autre, pas les deux.

Analogie : un sommelier. Température 0, il vous sert toujours la valeur sûre. Température 1,5, il vous propose un vin orange géorgien : parfois une révélation, parfois une erreur.

### 2.2 Où la régler, et le cas particulier de 2026

- Dans les interfaces grand public (claude.ai, ChatGPT, Gemini), **vous n'y avez pas accès** : l'éditeur a choisi une valeur raisonnable. Vous influencez la variété par la consigne (« propose 10 variantes très différentes »).
- Dans les API (OpenAI, Google, Mistral, xAI) et les outils locaux (Ollama via un `Modelfile`, LM Studio), c'est un simple paramètre.
- Chez Anthropic, les modèles **à partir de Claude 4.7 n'acceptent plus le paramètre `temperature`** (la requête est rejetée avec une erreur 400) : le modèle gère lui-même son échantillonnage, et l'on pilote plutôt le niveau d'**effort** de raisonnement. Depuis la version d'API 2026-10-21 (envoyée par défaut par les SDK v2), `temperature`, `top_p` et `top_k` renvoient une erreur 400 **sur tous les modèles**, même à leur valeur par défaut. C'est un bon rappel que ces réglages évoluent ; vérifiez toujours la documentation du modèle que vous utilisez.

> ⚠️ **Piège fréquent** — « Température 0 = réponse toujours identique et toujours vraie. » Ni l'un ni l'autre. Les calculs sur carte graphique introduisent de minuscules variations, et surtout **la température ne touche pas à la justesse** : à 0, le modèle sert sa réponse *la plus probable*, qui peut être fausse avec la même assurance.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : régler la température à 0 garantit que la réponse de l'IA sera exacte.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. La température joue sur la variété des réponses, pas sur leur justesse. À 0, le modèle sert sa réponse la plus probable… qui peut être fausse avec la même assurance."
}
```

## 3. Les hallucinations : inventer avec assurance

### 3.1 De quoi parle-t-on ?

Une **hallucination** est une information fausse ou inventée, présentée avec la même fluidité que les informations exactes. Exemples réels rencontrés dans les entreprises françaises :

- une **référence juridique inventée** (« article L. 1234-9-2 du Code du travail » — il n'existe pas) ;
- un **chiffre plausible mais faux** (« le taux de TVA sur la restauration est de 7 % » — c'était vrai jusqu'en 2013, il est de 10 % depuis) ;
- une **URL fabriquée** qui ressemble à une vraie page mais renvoie une erreur 404 ;
- une **citation attribuée** à une personne qui ne l'a jamais prononcée ;
- un **résumé qui ajoute** une clause absente du contrat fourni.

Le mot « hallucination » est trompeur : le modèle ne « voit » rien. Il fait exactement ce pour quoi il a été construit — produire la suite la plus plausible — dans une zone où il n'a pas de connaissance fiable. Une référence juridique *a la forme* « article L. + numéros » ; le modèle produit cette forme.

> 💡 **Autrement dit** — C'est comme un élève qui, face à une question qu'il ne connaît pas, écrit une réponse qui « a l'air » d'une bonne réponse : bon vocabulaire, bon format, ton assuré. La forme est parfaite, le fond est inventé. Le modèle ne ment pas exprès : il complète, simplement, là où il n'a pas d'information fiable.

### 3.2 Pourquoi c'est inévitable (et pourquoi ça diminue)

Trois causes principales :

1. **Pas de base de faits** : le savoir est une compression statistique (L005), pas une base de données consultable. Les faits rares ou récents sont flous.
2. **La génération mot à mot** (L006) : une fois lancé sur une mauvaise piste, le modèle complète de façon cohérente avec son erreur.
3. **L'alignement récompense l'aide** (L007) : les annotateurs ont souvent préféré une réponse complète à un « je ne sais pas ». Les modèles 2026 sont nettement mieux calibrés qu'en 2023 — ils disent plus volontiers « je ne suis pas certain » — mais le biais de complaisance (*sycophancy*) persiste : glissez une fausse prémisse dans la question et vous augmentez le risque.

À cela s'ajoutent la **date de connaissance** (tout événement postérieur est inconnu ou inventé) et les **biais** hérités des données (surreprésentation de certains points de vue, stéréotypes), que le module M07 traitera.

### 3.3 Les quatre parades de base

| Parade | Comment | Pourquoi ça marche |
|---|---|---|
| **1. Fournir la source** | Joignez le contrat, le barème, la page officielle, et demandez de répondre *à partir du document* | Le modèle complète à partir de son contexte plutôt que de sa mémoire floue |
| **2. Exiger des citations** | « Cite le passage exact qui justifie chaque affirmation » ; l'API Claude propose une fonction *Citations* qui renvoie les extraits sources | Une affirmation sans passage à citer devient visible |
| **3. Autoriser l'ignorance** | « Si l'information n'est pas dans le document, dis-le explicitement » | Contre-balance le biais « toujours aider » |
| **4. Vérifier ce qui engage** | Tout chiffre, article de loi, nom, URL, date qui sera utilisé pour décider est contrôlé à la source par un humain | Rien ne remplace cela ; c'est l'objet du module M05 |

Les outils de **recherche web** et les assistants « sourcés » (Perplexity, Claude ou ChatGPT avec recherche activée) appliquent la parade 1 automatiquement : ils placent des pages fraîches dans le contexte avant de répondre. Ils ne suppriment pas la parade 4.

> 🔗 **Documentation officielle** — OpenAI recommande explicitement de « communiquer les limites » du modèle aux utilisateurs finaux dans ses [Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 ; Anthropic documente la fonction [Citations](https://platform.claude.com/docs/en/build-with-claude/citations) 🇬🇧.

🎮 **Défi** — Demandez à un assistant (sans recherche web) : « Donne-moi le numéro SIREN de la boulangerie Dupont à Vesoul. » Observez : refuse-t-il, invente-t-il un numéro à 9 chiffres, ou vous renvoie-t-il vers l'annuaire officiel ? Un numéro inventé est une hallucination de manuel.

```quiz
{
  "q": "Laquelle de ces consignes réduit le PLUS le risque d'hallucination quand vous interrogez un assistant sur un contrat ?",
  "options": [
    "« Réponds le plus vite possible, en une seule phrase courte et claire. »",
    "« Réponds d'après le contrat joint, cite le passage, et dis-le si l'info manque. »",
    "« Sois créatif et original, et reformule le contrat avec tes propres mots. »",
    "« Fais une réponse très longue et détaillée, avec tous les cas possibles. »"
  ],
  "answer": 1,
  "explanation": "Cette consigne combine trois parades : fournir la source, exiger des citations et autoriser l'ignorance. Il restera à vérifier vous-même ce qui engage l'entreprise."
}
```

```mission
{
  "title": "Jusqu'à combien de pages Claude peut-il lire dans un PDF ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/pdf-support",
  "steps": ["Ouvrez la page « PDF support » de la documentation Claude", "Cherchez le paragraphe ou le tableau des limites (« limits », « requirements »)", "Relevez le nombre maximal de pages et la taille maximale de la requête"],
  "question": "Combien de pages et quel poids maximal un PDF envoyé à Claude peut-il atteindre par requête ?",
  "hint": "La section 1.1 de cette leçon cite le nombre de pages ; la taille s'exprime en Mo.",
  "answer": "600 pages maximum (100 pour les modèles dont le contexte est inférieur à 1 M de tokens) et 128 Mo par requête (nov. 2026) — ces limites évoluent, vérifiez-les avant un gros traitement (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "La fenêtre de contexte de Gemini 3.8 Flash",
  "url": "https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash",
  "steps": ["Ouvrez la fiche du modèle Gemini 3.8 Flash dans la documentation Google", "Repérez les lignes « Input token limit » et « Output token limit »", "Comparez avec le tableau de la section 1.1"],
  "question": "Combien de tokens Gemini 3.8 Flash accepte-t-il en entrée, et combien peut-il en produire en sortie ?",
  "hint": "Les nombres exacts ne sont pas « ronds » : ce sont des puissances de 2.",
  "answer": "1 048 576 tokens en entrée et 65 536 tokens en sortie (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Vous êtes assistant(e) de direction dans une PME du bâtiment. Vous avez demandé à un LLM (sans document joint) : « Quelles sont les mentions obligatoires sur un devis de travaux pour un particulier ? » Voici un extrait de sa réponse :

> « Le devis doit mentionner : la date, le nom et l'adresse de l'entreprise, le numéro SIREN, le décompte détaillé des prestations, le prix HT et TTC, la durée de validité de l'offre (obligatoirement 3 mois minimum selon l'article R. 111-4 du Code de la consommation), la mention « devis gratuit » ou son coût, et l'assurance décennale. »

1. Soulignez les deux éléments qui vous paraissent **suspects** et expliquez, pour chacun, quel mécanisme (section 3.2) a pu produire l'erreur.
2. Réécrivez votre demande en appliquant les parades 1, 2 et 3 (vous pouvez supposer que vous disposez de la fiche officielle sur le site service-public.fr).
3. Précisez quel(s) élément(s) vous vérifierez à la source quoi qu'il arrive, et pourquoi.

**Critères de réussite.** Les éléments suspects sont identifiés avec une justification plausible ; la demande reformulée contient le document source, une exigence de citation et une autorisation d'ignorance ; la liste des vérifications inclut la référence réglementaire et toute durée chiffrée.

<details>
<summary>Pistes de corrigé</summary>

1. Les deux éléments à vérifier sont **la durée de validité « obligatoirement 3 mois minimum »** (il n'existe pas de minimum légal général : la durée de validité doit être indiquée, mais l'entreprise la fixe) et **la référence « article R. 111-4 du Code de la consommation »** (une référence d'allure plausible, mécanisme n° 1 « forme sans fond » ; à contrôler sur Légifrance avant tout usage). Le reste de la liste est globalement cohérent avec les obligations connues, mais reste à confirmer sur la fiche officielle.
2. Exemple : « Voici la fiche officielle sur les devis (texte joint). À partir de ce document uniquement, liste les mentions obligatoires d'un devis de travaux pour un particulier. Pour chaque mention, cite le passage exact. Si une information n'y figure pas, écris “non précisé dans le document”. »
3. Toute référence réglementaire et toute durée/valeur chiffrée, car elles engagent la responsabilité de l'entreprise ; vérification sur service-public.fr ou Légifrance.
</details>

## ✅ Auto-évaluation express

1. Pourquoi le vingtième message d'une conversation coûte-t-il plus cher que le premier ?
2. Que change la température : la justesse des réponses ou leur variabilité ?
3. Citez trois parades contre les hallucinations applicables dès aujourd'hui, sans outil supplémentaire.

<details>
<summary>Réponses</summary>

1. Parce que le modèle n'a pas de mémoire : toute la conversation (et les documents joints) est renvoyée dans la fenêtre de contexte à chaque tour, et facturée en tokens d'entrée (sauf cache).
2. La **variabilité** uniquement. À température 0, la réponse la plus probable peut être fausse avec la même assurance.
3. Fournir le document source dans la demande ; exiger des citations exactes ; autoriser explicitement « je ne sais pas » ; et, dans tous les cas, vérifier à la source ce qui engage (chiffres, lois, noms, URL).
</details>

## 📚 Pour aller plus loin
- [Claude Academy — AI capabilities and limitations](https://academy.claude.com/courses/ai-capabilities-and-limitations) 🇬🇧 — cours gratuit (3,5 h) dont les chapitres *Knowledge*, *Working Memory* et *Steerability* correspondent exactement aux trois parties de cette leçon ; badge à la clé.
- [Anthropic — Using the Messages API](https://platform.claude.com/docs/en/build-with-claude/working-with-messages) 🇬🇧 — où l'on découvre que `temperature` n'est plus accepté par les modèles Claude récents.
- [Google — Gemini API : modèles et fenêtres de contexte](https://ai.google.dev/gemini-api/docs/models) 🇬🇧 — pour comparer les tailles de contexte et de sortie.
- [Anthropic — Prompting best practices, section « Long context prompting »](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 — comment placer et exploiter des documents longs (module M04).

> 🗺️ **Et maintenant ?** — Vous connaissez le fonctionnement et les limites des LLM ; la leçon L009 dresse le panorama des modèles de 2026 — Claude, GPT, Gemini, Grok, Mistral, Llama… — pour savoir lequel choisir selon l'usage.
