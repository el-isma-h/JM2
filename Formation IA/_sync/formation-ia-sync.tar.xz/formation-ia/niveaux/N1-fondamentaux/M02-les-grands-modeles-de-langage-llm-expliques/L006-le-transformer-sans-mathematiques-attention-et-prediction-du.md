---
id: L006
module: M02
level: N1
title: "Le transformer sans mathématiques : attention et prédiction du mot suivant"
minutes: 45
objectives:
  - "Décrire les quatre étapes du parcours d'un texte dans un transformer (tokens, vecteurs, attention, prédiction)"
  - "Expliquer le mécanisme d'attention avec un exemple de phrase ambiguë, sans aucune formule"
  - "Expliquer pourquoi un LLM génère un token à la fois et ce que cela implique pour l'utilisateur"
skills: ["C1.1"]
sources:
  - { title: "Vaswani et al., « Attention Is All You Need » (2017)", url: "https://arxiv.org/abs/1706.03762", lang: "en" }
  - { title: "3Blue1Brown — Neural networks (chapitres 5 à 7 : GPT, attention, MLP)", url: "https://www.3blue1brown.com/topics/neural-networks", lang: "en" }
  - { title: "Hugging Face — LLM Course, chapitre 1", url: "https://huggingface.co/learn/llm-course/chapter1/1", lang: "en" }
  - { title: "Stanford CS224N — NLP with Deep Learning (lecture 8 : Transformers)", url: "https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1244/", lang: "en" }
  - { title: "Claude Academy — AI capabilities and limitations (Next Token Prediction)", url: "https://academy.claude.com/courses/ai-capabilities-and-limitations", lang: "en" }
  - { title: "Anthropic — Streaming Messages", url: "https://platform.claude.com/docs/en/build-with-claude/streaming", lang: "en" }
---

# Le transformer sans mathématiques : attention et prédiction du mot suivant

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 2

## 🎯 Ce que vous saurez faire
- Raconter, étape par étape, ce qui se passe entre le moment où vous appuyez sur « Entrée » et l'apparition du premier mot de la réponse.
- Expliquer le mot **attention** avec une phrase de la vie courante, et comprendre pourquoi il a tout changé en 2017.
- Comprendre pourquoi la réponse « s'écrit » sous vos yeux mot après mot, et pourquoi un modèle peut « se tromper puis s'entêter ».
- Repérer les abus de langage (« il comprend », « il sait ») et les remplacer par une description exacte.

> 🧭 **En clair** — Le *transformer* est la « recette de fabrication » de tous les assistants actuels (c'est le T de ChatGPT). Son idée géniale s'appelle l'**attention** : au lieu de lire une phrase mot à mot en oubliant le début, le modèle regarde tous les mots à la fois et repère ceux qui comptent, comme vous le faites pour savoir à qui renvoie « il » dans une phrase. Ensuite, il ne sort pas une réponse toute faite : il calcule les chances de chaque mot possible, en choisit un, l'ajoute au texte… et recommence. C'est pour cela que la réponse s'écrit sous vos yeux, et qu'une erreur écrite au début peut entraîner la suite.

## 1. Un peu d'histoire : 2017, l'année où tout a basculé

Jusqu'au milieu des années 2010, les programmes de traitement du langage lisaient un texte **mot après mot, dans l'ordre**, comme on lit un télégramme — ce sont les réseaux récurrents (RNN, LSTM). Problème : arrivés au bout d'une longue phrase, ils avaient « oublié » le début. Traduire « La facture que le fournisseur basé à Marseille nous a envoyée la semaine dernière est erronée » était un exploit, parce que « est erronée » se rapporte à « facture », vingt mots plus tôt.

En juin 2017, huit chercheurs de Google publient un article au titre provocateur : *Attention Is All You Need* (« L'attention est tout ce dont vous avez besoin »). Ils y décrivent une architecture nouvelle, le **transformer**, qui abandonne la lecture séquentielle : tous les mots sont traités **en même temps**, et chaque mot peut « regarder » tous les autres pour décider lesquels comptent. Deux conséquences majeures :

- la longue distance ne pose plus problème (« est erronée » peut regarder directement « facture ») ;
- le calcul se parallélise parfaitement sur les cartes graphiques, ce qui permet d'entraîner des modèles mille fois plus gros.

Le **T** de GPT (*Generative Pre-trained Transformer*) vient de là. GPT-1 (2018), GPT-2 (2019), GPT-3 (2020, 175 milliards de paramètres), puis ChatGPT (30 novembre 2022), Claude, Gemini, Mistral, Llama, Qwen, DeepSeek : tous les LLM actuels sont des transformers, avec des variantes.

> 🔗 **Documentation officielle** — L'article fondateur est librement accessible : [Attention Is All You Need (arXiv, 2017)](https://arxiv.org/abs/1706.03762) 🇬🇧. Vous n'avez pas besoin de le lire pour cette leçon ; sachez simplement qu'il existe et qu'il tient en 15 pages.

```quiz
{
  "q": "Quel était le principal défaut des anciens programmes de langage (avant 2017), que le transformer a corrigé ?",
  "options": [
    "Ils ne fonctionnaient qu'en anglais, jamais en français",
    "Ils étaient incapables de compter les mots d'une phrase",
    "Ils demandaient une connexion Internet permanente",
    "Ils lisaient mot à mot et « oubliaient » le début des phrases"
  ],
  "answer": 3,
  "explanation": "Les réseaux récurrents lisaient dans l'ordre, comme un télégramme, et perdaient le fil sur les longues phrases. Avec l'attention, chaque mot peut « regarder » directement n'importe quel autre, même vingt mots plus tôt."
}
```

## 2. Le voyage d'une phrase dans le modèle, en quatre étapes

Prenons la demande d'une gérante de boulangerie : « Propose un nom pour ma nouvelle brioche au ». Voici ce qui se passe.

```
Votre texte
   │
   ▼
① Tokenisation      « Propose » « un » « nom » … « brioche » « au »
   │
   ▼
② Vectorisation     chaque token devient une liste de nombres (un « vecteur »)
   │                 qui encode son sens et sa position dans la phrase
   ▼
③ Attention ×N      chaque token « regarde » les autres et enrichit son vecteur
   │                 (répété dans des dizaines de couches empilées)
   ▼
④ Prédiction        une liste de probabilités pour le token suivant :
                     « beurre » 31 % · « chocolat » 18 % · « sucre » 12 % · « miel » 9 % …
```

### 2.1 Étape ① — Tokenisation
Vue en leçon L005 : le texte est découpé en tokens.

### 2.2 Étape ② — Les mots deviennent des nombres (*embeddings*)
Un ordinateur ne calcule pas avec des lettres. Chaque token est converti en une longue liste de nombres (plusieurs milliers), appelée **vecteur** ou *embedding*. L'astuce : pendant l'entraînement, le modèle apprend à placer ces vecteurs de façon que **les mots de sens proche soient voisins**. « Brioche », « croissant » et « viennoiserie » se retrouvent dans la même région ; « Marseille » et « Lyon » dans une autre.

Analogie : un immense magasin où les produits ne sont pas rangés par ordre alphabétique mais par affinité. Le modèle n'a pas de dictionnaire : il a une carte.

> 💡 **À retenir** — Ces vecteurs sont aussi la base des *embeddings* utilisés pour la recherche sémantique et le RAG (Niveau 2) : on compare la position de votre question à celle de vos documents.

### 2.3 Étape ③ — L'attention : chaque mot regarde les autres

C'est le cœur du transformer, et il se comprend sans équation.

Lisez : « Le directeur a appelé le comptable parce qu'**il** avait oublié la déclaration de TVA. » Qui est « il » ? Votre cerveau a hésité une fraction de seconde, puis a « regardé » les mots autour pour trancher. L'**attention** fait exactement cela : pour chaque token, le modèle calcule un score d'importance vis-à-vis de chaque autre token de la phrase, puis mélange les vecteurs en proportion. Le vecteur de « il » s'enrichit ainsi d'un peu de « directeur », d'un peu de « comptable » et beaucoup de « oublié la déclaration » — et c'est ce vecteur enrichi qui servira à la suite.

Ce mécanisme tourne en parallèle sur plusieurs « têtes » (*attention heads*), chacune spécialisée au fil de l'entraînement : une tête suit la grammaire (sujet–verbe), une autre les références (pronoms), une autre le style, etc. Puis le résultat passe dans une couche de « réflexion » (un petit réseau de neurones classique, le *MLP*), et l'ensemble est **empilé** des dizaines de fois : chaque couche affine un peu plus la représentation.

> 💡 **Autrement dit** — Imaginez une réunion où, avant de parler, chaque participant jette un coup d'œil à tous les autres pour savoir qui est concerné par son propos. Plusieurs « paires d'yeux » (les têtes) regardent en même temps, chacune avec une préoccupation différente : la grammaire, qui fait quoi, le ton… Et la réunion se répète des dizaines de fois, à chaque étage du modèle, pour affiner la compréhension du contexte.

Deux usages professionnels que vous rencontrerez :
- **Le résumé** : l'attention permet de relier « ce montant » (page 12) à « l'acompte de 15 000 € » (page 2).
- **Le code** : une variable déclarée ligne 3 et utilisée ligne 240 sont reliées en une opération.

> ⚠️ **Piège fréquent** — « Le modèle comprend ma phrase. » Non : il a construit, pour chaque token, un vecteur qui tient compte du contexte. Cela *ressemble* à de la compréhension et produit souvent le même résultat, mais ce n'en est pas une. Gardez la formulation exacte : « le modèle a modélisé les relations entre les mots ».

### 2.4 Étape ④ — Une liste de probabilités, pas une réponse

À la sortie de la dernière couche, le modèle ne produit pas un mot : il produit **une probabilité pour chacun des tokens de son vocabulaire** (des dizaines de milliers de valeurs). Puis un token est **tiré au sort** selon ces probabilités — pas forcément le plus probable. C'est ce tirage qui fait que deux demandes identiques donnent deux réponses différentes, et c'est le réglage de la **température** (leçon L008) qui contrôle l'audace du tirage.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : à la fin de ses calculs, le modèle choisit toujours le mot le plus probable, ce qui explique qu'il donne exactement la même réponse à chaque fois.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Le modèle produit une liste de probabilités, puis un mot est tiré au sort selon ces chances — pas forcément le plus probable. C'est pourquoi deux demandes identiques peuvent donner deux réponses différentes (réglage de la température, leçon L008)."
}
```

## 3. La boucle : un token à la fois

Le modèle vient de choisir « beurre ». Et maintenant ? Il **recommence tout** : il prend votre demande + « beurre », refait les quatre étapes, et prédit le token suivant (« salé » ?). Puis encore. Jusqu'à produire un token spécial de fin. Ce fonctionnement est dit **autorégressif** : chaque mot produit devient une entrée pour le suivant.

```
[Propose un nom pour ma brioche au]            → « beurre »
[Propose un nom pour ma brioche au beurre]     → « salé »
[… brioche au beurre salé]                     → « :»
[… brioche au beurre salé :]                   → « La »
[… brioche au beurre salé : La]                → « Bretonne »
```

Trois conséquences très concrètes :

1. **La réponse s'affiche progressivement.** Ce n'est pas un effet de style : les interfaces (et l'API, via le *streaming*) vous montrent les tokens au fur et à mesure qu'ils sont générés.
2. **Le modèle ne revient jamais en arrière.** Un mot émis est acquis. S'il commence par « La TVA sur les livres est de 20 % », il aura tendance à continuer de façon cohérente avec cette erreur (le taux réel est 5,5 %), car le texte déjà écrit fait partie de son contexte. D'où l'intérêt des modèles « à raisonnement » (ou mode *thinking*), qui rédigent d'abord un brouillon interne avant la réponse finale — nous y reviendrons en L007 et L009.
3. **La sortie coûte plus cher que l'entrée.** Chaque token généré exige un passage complet dans le réseau : c'est pour cela que les tarifs « sortie » sont 4 à 5 fois plus élevés que les tarifs « entrée » (L005).

> 🔗 **Documentation officielle** — Dans l'API Claude, le [streaming](https://platform.claude.com/docs/en/build-with-claude/streaming) 🇬🇧 renvoie les morceaux de réponse (`text_delta`) au fur et à mesure : c'est la boucle autorégressive rendue visible.

```quiz
{
  "type": "mise_en_situation",
  "q": "Vous écrivez : « Puisque la TVA sur les livres est de 20 %, calcule la TVA d'un livre à 30 € HT. » Pourquoi l'assistant risque-t-il de suivre votre erreur ?",
  "options": [
    "Parce qu'il n'a jamais entendu parler de la TVA",
    "Parce qu'il prolonge votre texte, prémisse fausse comprise",
    "Parce qu'il est programmé pour toujours donner raison à l'utilisateur",
    "Parce que les calculs de pourcentage lui sont interdits"
  ],
  "answer": 1,
  "explanation": "Le modèle prolonge le texte déjà présent dans son contexte, prémisse fausse comprise (le taux réel est de 5,5 %). Règle d'usage : ne glissez jamais une donnée non vérifiée dans votre question comme si elle était acquise."
}
```

## 4. Pourquoi « prédire le mot suivant » suffit à tant de choses

On entend parfois : « ce n'est qu'un perroquet statistique, ça ne fait que prédire le mot suivant ». La seconde partie est exacte, la première est trompeuse. Pour prédire correctement le mot suivant dans *tous* les textes d'Internet — manuels de droit, discussions de forums, code Python, recettes, débats philosophiques — le modèle est obligé d'apprendre des régularités de plus en plus abstraites : la grammaire, puis les faits (« la capitale de l'Australie est… »), puis des formes de raisonnement (« si A alors B, or A, donc… »). Prédire le mot suivant dans un problème de mathématiques, c'est devoir faire le calcul.

Le cours gratuit *AI capabilities and limitations* de Claude Academy (3,5 h, en anglais) consacre un chapitre entier à cette idée de *Next Token Prediction* et à ses conséquences : nous vous encourageons à le suivre après ce module.

🎮 **Défi** — Jouez au transformer. Complétez : « Le client a signé le devis, mais il n'a toujours pas… ». Notez vos trois mots les plus probables et un pourcentage pour chacun. Comparez avec un voisin : vos « distributions » diffèrent — c'est normal, vos « entraînements » diffèrent.

```mission
{
  "title": "Qui a écrit « Attention Is All You Need » ?",
  "url": "https://arxiv.org/abs/1706.03762",
  "steps": ["Ouvrez la page de l'article sur arXiv (pas besoin de télécharger le PDF)", "Lisez la liste des auteurs sous le titre", "Repérez la date de la première soumission (« Submitted on… »)"],
  "question": "Combien d'auteurs signent l'article, et en quel mois de 2017 a-t-il été soumis pour la première fois ?",
  "hint": "La section 1 de cette leçon donne déjà le nombre : la mission consiste à le vérifier à la source. Le premier auteur s'appelle Ashish Vaswani.",
  "answer": "8 auteurs (Vaswani, Shazeer, Parmar, Uszkoreit, Jones, Gomez, Kaiser, Polosukhin) ; première soumission en juin 2017 (12 juin) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Le programme du cours « AI capabilities and limitations »",
  "url": "https://academy.claude.com/courses/ai-capabilities-and-limitations",
  "steps": ["Ouvrez la page du cours sur Claude Academy", "Notez sa durée annoncée", "Parcourez la liste des chapitres et repérez celui sur la prédiction du token suivant"],
  "question": "Combien de temps dure ce cours gratuit, et quelles grandes notions aborde-t-il en plus de la « Next Token Prediction » ?",
  "hint": "Cherchez des mots comme knowledge (connaissances) ou working memory (mémoire de travail).",
  "answer": "Environ 3,5 h ; il couvre la prédiction du token suivant, les connaissances (knowledge), la mémoire de travail (working memory) et la « pilotabilité » du modèle (steerability) — état au 1er nov. 2026.",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Ouvrez l'assistant de votre choix (Claude, ChatGPT, Gemini, Le Chat…) et menez les trois expériences suivantes. Notez vos observations dans un tableau à trois colonnes (expérience / résultat / ce que ça révèle du transformer).

1. **L'attention à l'œuvre.** Soumettez : « Le livreur a remis le colis à la gardienne parce qu'elle était absente. Qui était absent ? » puis la même phrase avec « parce qu'il était en avance ». Le modèle doit changer de réponse.
2. **La boucle autorégressive.** Demandez : « Écris une phrase de 15 mots sur la comptabilité, puis compte les mots. » Observez si le décompte est juste. Recommencez en demandant d'abord le décompte planifié (« écris d'abord les 15 mots numérotés, puis la phrase »).
3. **L'entêtement.** Posez une question dont la réponse commence par une affirmation fausse que vous suggérez : « Puisque le taux de TVA sur les livres est de 20 %, calcule la TVA sur un livre à 30 € HT. » Le modèle corrige-t-il votre prémisse ou la suit-il ?

**Critères de réussite.** Les trois expériences sont réalisées ; chaque observation est reliée à un mécanisme vu en cours (attention, génération séquentielle, contexte déjà écrit) ; vous avez formulé une règle d'usage personnelle à partir de l'expérience 3.

<details>
<summary>Pistes de corrigé</summary>

1. Les bons modèles attribuent « absente » à la gardienne… puis hésitent, car la phrase est réellement ambiguë ; ils explicitent souvent l'ambiguïté. Le changement de réponse avec « il » montre l'attention qui relie le pronom au bon antécédent.
2. Le décompte est souvent faux quand il est fait « après coup », car le modèle n'a pas « vu » sa phrase comme un tout : il l'a produite token par token. Numéroter d'abord force une planification dans le texte lui-même.
3. Les modèles 2026 corrigent généralement la prémisse (« le taux est de 5,5 % »), mais pas toujours, surtout si la question est formulée avec assurance. Règle d'usage : ne jamais glisser une donnée non vérifiée dans la question comme si elle était acquise.
</details>

## ✅ Auto-évaluation express

1. Quel problème des réseaux récurrents le mécanisme d'attention a-t-il résolu ?
2. Vrai ou faux : à la fin du calcul, le transformer produit directement le mot suivant.
3. Pourquoi une réponse générée mot à mot peut-elle « s'entêter » dans une erreur ?

<details>
<summary>Réponses</summary>

1. L'oubli des mots lointains dans une longue phrase et l'impossibilité de paralléliser le calcul. L'attention relie directement n'importe quel mot à n'importe quel autre, quelle que soit la distance.
2. **Faux.** Il produit une distribution de probabilités sur tout le vocabulaire ; un token est ensuite tiré au sort selon ces probabilités (influencées par la température).
3. Parce que chaque token produit est réinjecté en entrée pour prédire le suivant : le texte déjà écrit, même faux, fait partie du contexte et oriente la suite. Le modèle ne revient pas en arrière.
</details>

## 📚 Pour aller plus loin
- [3Blue1Brown — Neural networks, chapitres 5 à 7 (« But what is a GPT? », « Attention in transformers, visually explained »)](https://www.3blue1brown.com/topics/neural-networks) 🇬🇧 — les meilleures animations existantes sur le sujet ; source d'inspiration principale de cette leçon.
- [Attention Is All You Need (arXiv, 2017)](https://arxiv.org/abs/1706.03762) 🇬🇧 — l'article original, pour les curieux.
- [Hugging Face — LLM Course, chapitre 1](https://huggingface.co/learn/llm-course/chapter1/1) 🇬🇧 — « How do Transformers work? », avec quiz.
- [Claude Academy — AI capabilities and limitations](https://academy.claude.com/courses/ai-capabilities-and-limitations) 🇬🇧 — cours gratuit avec badge ; chapitre « Next Token Prediction ».
- [Stanford CS224N (Winter 2024), lecture 8 « Transformers »](https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1244/) 🇬🇧 — pour ceux qui voudront, plus tard, voir les mathématiques (Niveau 4).

> 🗺️ **Et maintenant ?** — Vous savez comment un transformer produit sa réponse ; la leçon L007 raconte comment on le dresse — pré-entraînement, fine-tuning, RLHF — pour qu'il réponde comme un assistant poli et utile.
