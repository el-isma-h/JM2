---
id: L166
module: M34
level: N5
title: "Penser en flux : événements, temps d'événement et de traitement, fenêtres, retard, garanties de livraison"
minutes: 45
objectives:
  - "Distinguer traitement par lots et traitement de flux, et identifier les cas où la fraîcheur justifie le streaming"
  - "Différencier temps d'événement, temps d'ingestion et temps de traitement"
  - "Choisir une fenêtre (fixe, glissante, de session) et expliquer le rôle du filigrane (watermark) face aux données en retard"
  - "Expliquer les garanties at-most-once, at-least-once et exactly-once et le rôle de l'idempotence des sorties"
skills: ["C5.3"]
sources:
  - { title: "Martin Kleppmann — Designing Data-Intensive Applications, 2e éd. (annonce, mars 2026)", url: "https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html", lang: "en" }
  - { title: "Apache Flink — documentation (stable)", url: "https://nightlies.apache.org/flink/flink-docs-stable/", lang: "en" }
  - { title: "Apache Spark — Structured Streaming", url: "https://spark.apache.org/docs/latest/streaming/index.html", lang: "en" }
  - { title: "DataTalksClub — Data Engineering Zoomcamp (module 7 Streaming)", url: "https://github.com/datatalksclub/data-engineering-zoomcamp", lang: "en" }
  - { title: "MIT 6.5830 Database Systems — syllabus (streaming databases)", url: "https://dsg.csail.mit.edu/6.5830/syllabus.php", lang: "en" }
---

# Penser en flux : événements, temps d'événement et de traitement, fenêtres, retard, garanties de livraison

> ⏱ 45 min · 🎯 Niveau 5 · 📚 Module 34

## 🎯 Ce que vous saurez faire
- Dire, pour un besoin métier, si le traitement par lots de M33 suffit ou si un flux temps réel se justifie.
- Expliquer pourquoi « l'heure de la commande » et « l'heure où le serveur la reçoit » ne sont pas la même chose, et pourquoi cela fausse les chiffres.
- Calculer un chiffre d'affaires par tranches de 5 minutes en tolérant les retardataires, grâce au **filigrane** (*watermark*).
- Choisir entre « au plus une fois », « au moins une fois » et « exactement une fois », et savoir ce que coûte chacune.

> 🧭 **En clair** — Jusqu'ici, nos données arrivaient comme le courrier : une tournée par jour, on trie tout le paquet le lendemain matin. Le streaming, c'est le tapis roulant des bagages à l'aéroport : les valises arrivent une par une, sans fin, et il faut les traiter au fil de l'eau. Problème : certaines valises arrivent en retard, parfois après la fermeture du vol. On doit donc décider combien de temps on attend avant de dire « le vol de 10 h est complet », sachant qu'attendre plus longtemps donne des comptes plus justes, mais plus tardifs.

## 1. Du lot au flux

| | **Lot** (*batch*, M33) | **Flux** (*stream*, M34) |
|---|---|---|
| Données | un ensemble **borné** (« les commandes d'hier ») | une suite **non bornée** d'événements |
| Déclenchement | à heure fixe ou sur asset | en continu, à chaque événement ou micro-lot |
| Fraîcheur typique | heures | secondes à minutes |
| Complexité | faible | élevée : ordre, retard, état, reprise |
| Outils | dlt, dbt, Airflow, Dagster | Kafka, Debezium, Flink, Spark Structured Streaming, Kafka Streams |

Un **événement** est un fait immuable, daté, qui s'est produit : « la commande CMD-2026-0040812 de Bréval a été validée à 10 h 03 ». On ne modifie pas un événement ; un changement est un **nouvel** événement (« la commande CMD-2026-0040812 a été annulée à 10 h 20 »). C'est exactement ce que produit le CDC de Debezium vu en L162.

Quand le streaming vaut-il son coût ? Quand la **valeur de la donnée chute vite** : détection de fraude au paiement, stock affiché sur un site marchand, alerte « ticket SAV urgent », index RAG qui doit refléter une suppression dans la minute. Pour un tableau de bord de chiffre d'affaires consulté le lundi matin, le lot de M33 suffit largement.

> 💡 **À retenir** — Le streaming n'est pas « du batch en plus rapide » : c'est un autre modèle, où l'on raisonne sur des données qui n'ont **jamais de fin**. Choisissez-le pour un besoin de fraîcheur argumenté, pas pour la mode.

```quiz
{
  "q": "Pour lequel de ces besoins un traitement de flux est-il le plus justifié ?",
  "options": [
    "Le rapport mensuel de chiffre d'affaires envoyé à l'expert-comptable",
    "Le blocage d'une carte en moins de 2 secondes après un paiement suspect",
    "L'inventaire annuel du stock",
    "La liste des clients inactifs depuis un an"
  ],
  "answer": 1,
  "explanation": "La valeur d'une alerte de fraude disparaît en quelques secondes : seul un traitement en flux répond. Les trois autres besoins tolèrent des heures, voire des jours, de délai."
}
```

## 2. Trois horloges

Chaque événement porte (au moins) trois instants :

| Horloge | Définition | Exemple (commande saisie au comptoir de l'agence de Saint-Nazaire) |
|---|---|---|
| **Temps d'événement** (*event time*) | quand le fait s'est réellement produit | 10 h 03 min 00 s, au terminal de caisse |
| **Temps d'ingestion** (*ingestion time*) | quand l'événement entre dans le système de flux (Kafka) | 10 h 06 min 40 s (le terminal était hors ligne) |
| **Temps de traitement** (*processing time*) | quand l'application de traitement le lit | 10 h 06 min 41 s |

L'écart entre temps d'événement et temps de traitement s'appelle le **décalage** (*skew* ou *lag*). Il vient des réseaux mobiles, des terminaux hors ligne, des files d'attente, des relances. Conséquence directe : les événements arrivent **dans le désordre**.

Si vous comptez « le CA de 10 h 00 à 10 h 05 » en **temps de traitement**, la commande de Saint-Nazaire tombe dans la tranche 10 h 05-10 h 10 : le chiffre est faux, et il change selon la charge du serveur. Pour des résultats exacts et rejouables (principe de L161), on calcule en **temps d'événement**.

> 💡 **Autrement dit** — Le temps d'événement, c'est le cachet de la poste ; le temps de traitement, c'est le jour où vous ouvrez la lettre. Pour savoir qui a envoyé son dossier avant la date limite, on regarde le cachet.

> ⚠️ **Piège fréquent** — Horodater l'événement au moment de sa réception (`now()` dans le consommateur) au lieu de transporter l'heure d'origine dans le message. Le temps d'événement doit être écrit **par le producteur**, dans le message, en UTC.

## 3. Fenêtres, filigrane et retardataires

Un flux n'a pas de fin : pour calculer une somme, on le découpe en **fenêtres**.

```
Fenêtres fixes (tumbling, 5 min) :     |10:00────10:05|10:05────10:10|10:10────10:15|
Fenêtres glissantes (sliding/hopping,  |10:00──────────10:10|
taille 10 min, pas de 5 min) :                |10:05──────────10:15|
Fenêtres de session (inactivité 30 min) : ●●● ●●      (pause > 30 min)      ●●●●
                                          └ session 1 ┘                      └ session 2 ┘
```

- **Fixes** (*tumbling*) : tranches contiguës sans recouvrement. Le CA par tranche de 5 minutes.
- **Glissantes** (*sliding* ou *hopping*) : tranches qui se recouvrent. « Nombre de tickets SAV sur les 10 dernières minutes, rafraîchi toutes les 5 minutes ».
- **De session** : regroupent l'activité séparée par des pauses. Une visite d'un client sur le site.

Reste une question : **quand** déclarer une fenêtre terminée, puisque des retardataires peuvent encore arriver ? Le **filigrane** (*watermark*) est la réponse. C'est une estimation qui avance avec le flux : « je considère que tous les événements antérieurs à T sont arrivés ». Une stratégie courante : *filigrane = plus grand temps d'événement vu − retard toléré*. Quand le filigrane dépasse la fin d'une fenêtre, on émet son résultat définitif et on libère la mémoire. Un événement qui arrive ensuite pour cette fenêtre est un **retardataire** : on l'ignore, on l'envoie dans une sortie dédiée, ou on corrige le résultat, selon le moteur et votre choix.

Le script suivant, en Python pur (aucune installation), simule tout cela.

```python
# l166_fenetres.py — fenêtres fixes de 5 min en temps d'événement, filigrane et retardataires
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta

@dataclass
class Evenement:
    commande_id: int
    agence_id: str              # NAN, STN, ANC (agences de Bréval, L151)
    montant_ht: float
    temps_evenement: datetime   # écrit par le terminal de caisse (UTC)
    temps_arrivee: datetime     # quand le message atteint le traitement

T0 = datetime(2026, 11, 5, 10, 0)
def h(minutes: int, secondes: int = 0) -> datetime:
    return T0 + timedelta(minutes=minutes, seconds=secondes)

FLUX = [
    Evenement(1, "NAN",   1120.0, h(0, 30), h(0, 31)),
    Evenement(2, "NAN",     80.0, h(1, 10), h(1, 12)),
    Evenement(3, "STN",     45.5, h(3, 0),  h(6, 40)),   # terminal hors ligne : en retard mais toléré
    Evenement(4, "NAN",     60.0, h(5, 20), h(5, 21)),
    Evenement(5, "NAN",     30.0, h(7, 0),  h(7, 2)),
    Evenement(6, "STN",     99.0, h(4, 10), h(12, 30)),  # beaucoup trop tard : fenêtre déjà fermée
    Evenement(7, "NAN",     15.0, h(11, 0), h(11, 1)),
]
TAILLE = timedelta(minutes=5)
RETARD_TOLERE = timedelta(minutes=2)

def debut_fenetre(t: datetime) -> datetime:
    return t.replace(minute=t.minute - t.minute % 5, second=0, microsecond=0)

def en_temps_evenement(flux: list[Evenement]) -> None:
    ouvertes: dict[tuple[datetime, str], float] = defaultdict(float)
    filigrane = datetime.min
    for e in sorted(flux, key=lambda x: x.temps_arrivee):          # ordre réel d'arrivée
        debut = debut_fenetre(e.temps_evenement)
        if debut + TAILLE <= filigrane:
            print(f"  ⚠ retardataire écarté : commande {e.commande_id} ({e.temps_evenement:%H:%M:%S})")
            continue
        ouvertes[(debut, e.agence_id)] += e.montant_ht
        filigrane = max(filigrane, e.temps_evenement - RETARD_TOLERE)
        for cle in sorted(k for k in ouvertes if k[0] + TAILLE <= filigrane):
            d, agence = cle
            print(f"[{e.temps_arrivee:%H:%M:%S}] {d:%H:%M}-{d + TAILLE:%H:%M} {agence:<4} "
                  f"{ouvertes.pop(cle):7.2f} € (définitif, filigrane {filigrane:%H:%M:%S})")
    for (d, agence), ca in sorted(ouvertes.items()):
        print(f"[fin]      {d:%H:%M}-{d + TAILLE:%H:%M} {agence:<4} {ca:8.2f} € (provisoire)")

def en_temps_de_traitement(flux: list[Evenement]) -> None:
    ca: dict[tuple[datetime, str], float] = defaultdict(float)
    for e in flux:
        ca[(debut_fenetre(e.temps_arrivee), e.agence_id)] += e.montant_ht
    for (d, agence), total in sorted(ca.items()):
        print(f"           {d:%H:%M}-{d + TAILLE:%H:%M} {agence:<4} {total:8.2f} €")

print("== Temps d'événement + filigrane (retard toléré : 2 min) ==")
en_temps_evenement(FLUX)
print("\n== Temps de traitement (naïf) ==")
en_temps_de_traitement(FLUX)
```

Résultat attendu : en temps d'événement, la fenêtre 10 h 00-10 h 05 donne 1 200,00 € HT pour Nantes (NAN) et 45,50 € pour Saint-Nazaire (STN) (la commande 3, arrivée avec 3 min 40 s de retard, est bien comptée car le filigrane n'avait pas dépassé 10 h 05), et la commande 6 est écartée comme retardataire. En temps de traitement, Saint-Nazaire apparaît à 10 h 05-10 h 10 et à 10 h 10-10 h 15 : les chiffres sont faux.

> 💡 **À retenir** — Le retard toléré est un **compromis** : plus il est long, plus les résultats sont complets, mais plus ils sont émis tard et plus le moteur garde d'état en mémoire. Mesurez la distribution réelle des retards (par exemple le 99ᵉ centile) avant de le fixer.

```quiz
{
  "q": "Dans la simulation, vous passez RETARD_TOLERE à 10 minutes. Que se passe-t-il pour la commande 6 (temps d'événement 10:04:10, arrivée 10:12:30) ?",
  "options": [
    "Elle est toujours écartée, car elle arrive après 10:05",
    "Elle est comptée dans la fenêtre 10:10-10:15, celle de son heure d'arrivée",
    "Elle est comptée dans la fenêtre 10:00-10:05, émise plus tard",
    "Le programme s'arrête sur une erreur d'horodatage hors fenêtre"
  ],
  "answer": 2,
  "explanation": "Avec 10 minutes de tolérance, le filigrane n'a pas dépassé 10:05 quand elle arrive : elle rejoint sa fenêtre en temps d'événement. Contrepartie : la fenêtre reste ouverte plus longtemps et son résultat définitif arrive plus tard."
}
```

## 4. Garanties de livraison

Entre un producteur, un système de flux et un consommateur, les pannes sont normales. Que devient un message quand le consommateur plante au milieu de son traitement ? Tout dépend du moment où il **valide sa position** (le *commit* de son offset, détaillé en L167).

| Garantie | Mécanisme côté consommateur | Risque | Usage |
|---|---|---|---|
| **Au plus une fois** (*at-most-once*) | valider **avant** de traiter | perte de messages | métriques indicatives, journaux non critiques |
| **Au moins une fois** (*at-least-once*) | traiter **puis** valider | doublons après une reprise | le cas par défaut, combiné à une sortie idempotente |
| **Exactement une fois** (*exactly-once*) | transactions (lecture, traitement et écriture validés ensemble) ou sortie idempotente | coût et complexité | argent, stocks, compteurs exacts |

En pratique, « exactement une fois » signifie « l'**effet** est appliqué exactement une fois », pas que le message n'est jamais relu. Deux voies y mènent : les **transactions** du moteur (Kafka, Flink ; L168) et le couple **au moins une fois + écriture idempotente** (upsert sur une clé, comme le `MERGE` de L161). La seconde, plus simple, est celle de notre atelier L169.

> ⚠️ **Piège fréquent** — Croire qu'un système « exactly-once » protège aussi les effets externes : un e-mail envoyé ou un appel d'API de paiement exécuté pendant le traitement sera **refait** lors d'une reprise. Ces effets doivent porter une clé d'idempotence côté service appelé.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un consommateur qui écrit chaque commande dans une table par un upsert sur commande_id, et qui valide sa position après l'écriture, obtient un résultat équivalent à « exactement une fois » pour cette table.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai. La livraison est « au moins une fois » (un message peut être relu après une panne), mais l'upsert sur la clé rend la relecture sans effet : la table finale est la même que si chaque message avait été traité une seule fois."
}
```

```mission
{
  "title": "La deuxième édition de « Designing Data-Intensive Applications »",
  "url": "https://martin.kleppmann.com/2026/03/24/designing-data-intensive-applications-2e.html",
  "steps": ["Ouvrez le billet de Martin Kleppmann annonçant la 2e édition", "Repérez la date de parution", "Cherchez le nom du coauteur"],
  "question": "Quand la 2e édition de DDIA est-elle parue, et avec quel coauteur ?",
  "hint": "Le coauteur est connu dans le monde Kafka et data engineering.",
  "answer": "Mars 2026 (billet du 24 mars 2026), coécrite avec Chris Riccomini. Ce livre est la référence pour approfondir flux, ordre et garanties (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🎮 Défi : trois horloges au supermarché

Un artisan fait scanner ses articles au comptoir de l'agence d'Ancenis à 17 h 58, la commande est validée à 18 h 01, et le message arrive au siège de Nantes à 18 h 09 à cause d'une coupure réseau. L'agence ferme à 18 h. Pour le rapport « CA réalisé avant la fermeture », quelle horloge utiliser, et quel retard toléré faut-il au minimum ? Pourquoi ?

## 🧪 Exercice pratique

**Consigne** : à partir de `l166_fenetres.py` :
1. ajoutez un compteur de retardataires et affichez, à la fin, le pourcentage d'événements écartés ;
2. transformez les fenêtres fixes en fenêtres **glissantes** de 10 minutes avec un pas de 5 minutes (un événement appartient alors à deux fenêtres) ;
3. générez 1 000 événements aléatoires avec un retard tiré d'une loi exponentielle de moyenne 30 s (`random.expovariate(1/30)`), puis tracez le pourcentage de retardataires pour un retard toléré de 0, 30, 60, 120 et 300 s.

**Critères de réussite** : le total des fenêtres définitives plus les retardataires égale le total du flux (rien ne se perd silencieusement) ; le tableau des pourcentages montre une décroissance avec le retard toléré ; une phrase justifie le retard toléré que vous choisiriez.

**Corrigé (pistes)** : pour les fenêtres glissantes, calculez les débuts possibles `debut_fenetre(t)` et `debut_fenetre(t) - 5 min`, et gardez ceux dont la fenêtre de 10 min contient `t`. Avec une loi exponentielle de moyenne 30 s, environ 37 % des événements dépassent 30 s, 14 % dépassent 60 s, 2 % dépassent 120 s : un retard toléré de 2 à 3 minutes est un bon point de départ si un résultat à quelques minutes suffit. Pour le défi : le temps d'événement (la validation, à 18 h 01, est d'ailleurs **après** la fermeture : à vous de définir avec le métier quel événement compte, le scan de 17 h 58 ou la validation), et au moins 11 minutes de retard toléré (18 h 09 − 17 h 58) pour que le message soit pris en compte.

## ✅ Auto-évaluation express
1. Pourquoi calcule-t-on les agrégats en temps d'événement plutôt qu'en temps de traitement ?
2. Que signifie « le filigrane est à 10 h 07 » ?
3. Quelle combinaison simple donne un effet « exactement une fois » ?

**Réponses** : 1. Parce que le résultat ne dépend alors ni du retard réseau ni de la charge du serveur, et qu'il est identique en cas de rejeu. 2. Le moteur considère que tous les événements antérieurs à 10 h 07 (temps d'événement) sont arrivés ; les fenêtres qui se terminent avant peuvent être émises. 3. Livraison « au moins une fois » + écriture idempotente (upsert sur une clé).

## 📚 Pour aller plus loin
- [Apache Flink — documentation](https://nightlies.apache.org/flink/flink-docs-stable/) 🇬🇧 — concepts de temps, fenêtres et watermarks.
- [Spark Structured Streaming](https://spark.apache.org/docs/latest/streaming/index.html) 🇬🇧 — fenêtres en temps d'événement et gestion des données en retard.
- [MIT 6.5830 — syllabus](https://dsg.csail.mit.edu/6.5830/syllabus.php) 🇬🇧 — séance sur les bases de données de flux (source d'inspiration).
- [Data Engineering Zoomcamp](https://github.com/datatalksclub/data-engineering-zoomcamp) 🇬🇧 — module 7 consacré au streaming.

> 🗺️ **Et maintenant ?** — Vous savez penser en flux ; la leçon L167 installe le tapis roulant lui-même, Apache Kafka 4 en mode KRaft, et vous apprend à y produire et consommer les événements de commande.
