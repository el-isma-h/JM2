---
id: L169
module: M34
level: N5
title: "Atelier : CDC Postgres → Debezium → Kafka → table Iceberg/Delta interrogée par DuckDB"
minutes: 50
objectives:
  - "Déployer une chaîne CDC locale : Postgres en réplication logique, Kafka 4 KRaft, Debezium sur Kafka Connect"
  - "Décoder les événements Debezium (création, mise à jour, suppression, lecture initiale) et les appliquer à une table Delta Lake par MERGE idempotent"
  - "Interroger la table de lakehouse avec DuckDB et mesurer la latence de bout en bout"
  - "Superviser le slot de réplication et démontrer l'absence de perte et de doublon après une panne du consommateur"
skills: ["C5.3", "C5.2"]
sources:
  - { title: "Debezium — documentation", url: "https://debezium.io/documentation/", lang: "en" }
  - { title: "Debezium — exemples officiels (wiki)", url: "https://github.com/debezium/debezium-examples/wiki", lang: "en" }
  - { title: "Apache Kafka — documentation (Kafka Connect)", url: "https://kafka.apache.org/documentation/#connect", lang: "en" }
  - { title: "Delta Lake — site officiel", url: "https://delta.io/", lang: "en" }
  - { title: "Apache Iceberg — site officiel", url: "https://iceberg.apache.org/", lang: "en" }
  - { title: "RisingWave — Apache Iceberg vs Delta Lake vs Apache Hudi (2026)", url: "https://risingwave.com/blog/apache-iceberg-vs-delta-lake-vs-hudi-2026/", lang: "en" }
  - { title: "DuckDB 2.0 — documentation", url: "https://duckdb.org/docs/2.0/guides/python/polars.html", lang: "en" }
---

# Atelier : CDC Postgres → Debezium → Kafka → table Iceberg/Delta interrogée par DuckDB

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 34

## 🎯 Ce que vous saurez faire
- Monter en local la chaîne complète **Postgres → Debezium → Kafka → table Delta Lake**, puis l'interroger en SQL avec **DuckDB**.
- Lire un événement Debezium et savoir ce que signifient `op`, `before`, `after`, `source.lsn` et `ts_ms`.
- Appliquer créations, mises à jour **et suppressions** à une table de lakehouse, de façon idempotente.
- Mesurer la **latence** entre la validation d'une transaction dans Postgres et sa visibilité dans DuckDB, et prouver qu'une panne ne crée ni perte ni doublon (critères de la compétence C5.3).

> 🧭 **En clair** — On installe un « mouchard » bienveillant sur l'ERP de Bréval Matériaux : chaque fois qu'une commande est créée, modifiée ou supprimée, Debezium lit la ligne correspondante dans le journal de bord de Postgres et la poste dans Kafka. Au bout du tapis, un petit programme range ces changements dans une table du lac de données, en remplaçant l'ancienne version de chaque commande par la nouvelle, et en retirant celles qui ont été supprimées. Résultat : quelques secondes après un clic dans le logiciel de gestion, l'analyste voit le changement dans sa requête DuckDB, sans jamais interroger la base de production.

## 1. L'architecture de l'atelier

```
┌───────────┐  WAL (pgoutput)  ┌──────────────────────┐   topics breval.erp.*   ┌──────────────┐
│ Postgres  │ ───────────────▶ │ Kafka Connect        │ ──────────────────────▶ │ Kafka 4      │
│ (ERP)     │  slot debezium   │ + connecteur Debezium│   JSON {op,before,after}│ (KRaft)      │
└───────────┘                  └──────────────────────┘                         └──────┬───────┘
                                                                                        │ consommateur Python
                                                                                        ▼ (MERGE idempotent, commit après écriture)
                                                         ┌──────────────┐  delta_scan  ┌──────────────────┐
                                                         │ DuckDB       │ ◀─────────── │ Delta Lake       │
                                                         │ (analyste)   │              │ data/lake/cmd    │
                                                         └──────────────┘              └──────────────────┘
```

Pourquoi **Delta Lake** plutôt qu'**Iceberg** pour ce TP ? Les deux sont des formats de table ouverts vus en M32 (L157) ; la bibliothèque `deltalake` (delta-rs) permet un `MERGE` en Python **sans cluster ni catalogue**, ce qui garde l'atelier léger. La variante Iceberg est donnée en section 6. Pour le choix en production, Iceberg offre le support multi-moteurs le plus large, Delta est le plus intégré à Spark et Databricks (d'après le comparatif RisingWave de 2026).

## 2. Démarrer la chaîne

Tout se passe dans le dossier `breval/` : le Postgres de L151 (déjà lancé avec `wal_level=logical`, données chargées en L152), le Kafka de L167 (`docker-compose.kafka.yml`) et un troisième fichier pour Kafka Connect et Debezium. Les trois fichiers forment un seul projet Compose, donc un seul réseau : Connect joint Postgres sous le nom `postgres` et Kafka sous le nom `kafka`.

```yaml
# breval/docker-compose.cdc.yml — Kafka Connect + connecteur Debezium
services:
  connect:
    image: quay.io/debezium/connect:${DEBEZIUM_TAG:-3.2}       # version compatible Kafka 4 : à vérifier sur debezium.io
    container_name: breval-connect
    depends_on: [kafka, postgres]
    ports: ["8083:8083"]
    environment:
      BOOTSTRAP_SERVERS: kafka:9092
      GROUP_ID: connect-breval
      CONFIG_STORAGE_TOPIC: connect_configs
      OFFSET_STORAGE_TOPIC: connect_offsets
      STATUS_STORAGE_TOPIC: connect_statuses
```

```json
{
  "name": "breval-erp",
  "config": {
    "connector.class": "io.debezium.connector.postgresql.PostgresConnector",
    "plugin.name": "pgoutput",
    "database.hostname": "postgres",
    "database.port": "5432",
    "database.user": "breval",
    "database.password": "breval_local",
    "database.dbname": "breval",
    "topic.prefix": "breval",
    "table.include.list": "erp.commandes,erp.clients",
    "slot.name": "debezium_breval",
    "publication.autocreate.mode": "filtered",
    "decimal.handling.mode": "string",
    "key.converter": "org.apache.kafka.connect.json.JsonConverter",
    "key.converter.schemas.enable": "false",
    "value.converter": "org.apache.kafka.connect.json.JsonConverter",
    "value.converter.schemas.enable": "false"
  }
}
```

Enregistrez ce JSON dans `breval/cdc/connecteur-breval.json`, puis :

```bash
cd breval
docker compose -f docker-compose.yml -f docker-compose.kafka.yml -f docker-compose.cdc.yml up -d
sleep 20   # le temps que Connect démarre
curl -s -X POST -H "Content-Type: application/json" --data @cdc/connecteur-breval.json http://localhost:8083/connectors
curl -s http://localhost:8083/connectors/breval-erp/status      # "state":"RUNNING" attendu
docker exec breval-kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list
docker exec breval-kafka /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 \
  --topic breval.erp.commandes --from-beginning --max-messages 1
```

Au démarrage, Debezium réalise un **instantané initial** (*snapshot*) : les 120 000 commandes existantes sont publiées avec `"op": "r"` (*read*). Ensuite, il suit le WAL en continu. `decimal.handling.mode=string` transmet les `NUMERIC` sous forme de texte (`"3619.56"`) au lieu d'un encodage binaire peu lisible.

> ⚠️ **Piège fréquent** — Le mot de passe en clair dans la configuration du connecteur : acceptable pour un TP local, jamais en production. Kafka Connect propose des *config providers* (fichier, variables d'environnement, coffre-fort de secrets) pour injecter les secrets ; utilisez aussi un utilisateur Postgres dédié avec les seuls droits de réplication et de lecture.

## 3. Anatomie d'un événement Debezium

```json
{
  "before": null,
  "after": {"commande_id": 42, "numero": "CMD-2024-0000042", "client_id": 2606, "agence_id": "NAN",
            "canal": "telephone", "statut": "annulee", "date_commande": 1704199281000000,
            "date_livraison_prevue": 19725, "montant_ht": "3619.56", "mis_a_jour_le": 1793873643118000},
  "source": {"connector": "postgresql", "db": "breval", "schema": "erp", "table": "commandes",
             "lsn": 26843216, "ts_ms": 1793870043118, "...": "..."},
  "op": "u",
  "ts_ms": 1793870043301
}
```

| Champ | Signification |
|---|---|
| `op` | `c` création, `u` mise à jour, `d` suppression, `r` lecture lors de l'instantané initial |
| `before` / `after` | état de la ligne avant / après ; `after` est nul pour une suppression |
| `source.lsn` | position dans le WAL (*log sequence number*) : **ordre** total des changements de la base |
| `source.ts_ms` | heure de validation de la transaction dans Postgres, en millisecondes UTC (notre **temps d'événement**) |
| `ts_ms` | heure de traitement par Debezium |

Trois subtilités. Avec la configuration par défaut de Postgres (`REPLICA IDENTITY DEFAULT`), `before` est **nul** pour une mise à jour et ne contient que la **clé primaire** pour une suppression ; réglez `ALTER TABLE erp.commandes REPLICA IDENTITY FULL` si vous avez besoin de toute l'ancienne ligne. Les colonnes `timestamp` de l'ERP (`date_commande`, `mis_a_jour_le`, heure de Paris sans fuseau, L151) arrivent en **microsecondes depuis 1970**, et les `date` en **nombre de jours** : le consommateur les reconvertit. Enfin, chaque suppression est suivie d'un message **tombstone** (même clé, valeur nulle), utile au compactage des topics Kafka : votre consommateur doit l'ignorer.

```quiz
{
  "q": "Vous recevez un événement Debezium avec \"op\": \"d\", \"after\": null et \"before\": {\"commande_id\": 43}. Comment l'appliquer à la table du lakehouse ?",
  "options": [
    "L'ignorer : un événement dont « after » est nul est invalide",
    "Supprimer la ligne 43, avec la clé lue dans « before »",
    "Insérer une ligne vide pour la commande 43, en gardant la clé",
    "Attendre le message tombstone pour décider"
  ],
  "answer": 1,
  "explanation": "op = d signale une suppression ; la clé se trouve dans before (seule la clé primaire y figure avec la configuration par défaut). Le tombstone qui suit sert au compactage de Kafka et doit simplement être ignoré par le consommateur."
}
```

## 4. Le consommateur : du topic à la table Delta

```bash
source .venv/bin/activate
pip install confluent-kafka deltalake pyarrow duckdb      # deltalake ≥ 1.0 recommandé (à vérifier)
```

```python
# breval/cdc/cdc_vers_delta.py — Kafka (Debezium) → table Delta « data/lake/commandes », MERGE idempotent
import json
import os
import statistics
import time
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

import pyarrow as pa
from confluent_kafka import Consumer, KafkaException
from deltalake import DeltaTable

CHEMIN = os.environ.get("LAKE_COMMANDES", "data/lake/commandes")
TOPIC = "breval.erp.commandes"
EPOCH, EPOCH_DATE = datetime(1970, 1, 1), date(1970, 1, 1)

CIBLE = pa.schema([
    ("commande_id", pa.int64()), ("numero", pa.string()), ("client_id", pa.int64()),
    ("agence_id", pa.string()), ("canal", pa.string()), ("statut", pa.string()),
    ("date_commande", pa.timestamp("us")),             # heure de Paris sans fuseau, comme l'ERP
    ("date_livraison_prevue", pa.date32()),
    ("montant_ht", pa.decimal128(12, 2)),
    ("mis_a_jour_le", pa.timestamp("us")),
    ("_lsn", pa.int64()), ("_source_ts", pa.timestamp("ms", tz="UTC")),
])
LOT = CIBLE.append(pa.field("_op", pa.string()))
COLONNES = [f.name for f in CIBLE]

def micro(v):        # Debezium MicroTimestamp → datetime naïf
    return EPOCH + timedelta(microseconds=v) if v is not None else None

def jours(v):        # Debezium Date → date
    return EPOCH_DATE + timedelta(days=v) if v is not None else None

def convertir(evt: dict) -> dict:
    ligne = evt["after"] if evt["op"] != "d" else evt["before"]
    return {
        "commande_id": ligne["commande_id"],
        "numero": ligne.get("numero"),
        "client_id": ligne.get("client_id"),
        "agence_id": ligne.get("agence_id"),
        "canal": ligne.get("canal"),
        "statut": ligne.get("statut"),
        "date_commande": micro(ligne.get("date_commande")),
        "date_livraison_prevue": jours(ligne.get("date_livraison_prevue")),
        "montant_ht": Decimal(ligne["montant_ht"]) if ligne.get("montant_ht") else None,
        "mis_a_jour_le": micro(ligne.get("mis_a_jour_le")),
        "_lsn": evt["source"]["lsn"],
        "_source_ts": datetime.fromtimestamp(evt["source"]["ts_ms"] / 1000, tz=timezone.utc),
        "_op": evt["op"],
    }

def appliquer(evenements: list[dict]) -> None:
    # 1) Dans un même lot, ne garder que le dernier changement de chaque commande (ordre du WAL)
    derniers: dict[int, dict] = {}
    for e in sorted(evenements, key=lambda x: x["_lsn"]):
        derniers[e["commande_id"]] = e
    lot = pa.Table.from_pylist(list(derniers.values()), schema=LOT)
    # 2) MERGE : supprime, met à jour (seulement si plus récent), insère
    maj = {c: f"s.{c}" for c in COLONNES}
    (DeltaTable(CHEMIN)
        .merge(source=lot, predicate="t.commande_id = s.commande_id", source_alias="s", target_alias="t")
        .when_matched_delete(predicate="s._op = 'd'")
        .when_matched_update(updates=maj, predicate="s._op <> 'd' AND s._lsn > t._lsn")
        .when_not_matched_insert(updates=maj, predicate="s._op <> 'd'")
        .execute())

def main() -> None:
    if not DeltaTable.is_deltatable(CHEMIN):
        DeltaTable.create(CHEMIN, schema=CIBLE)
    consommateur = Consumer({
        "bootstrap.servers": os.environ.get("KAFKA_BOOTSTRAP", "localhost:29092"),
        "group.id": "lakehouse-commandes",
        "enable.auto.commit": False,          # commit APRÈS l'écriture Delta → au moins une fois
        "auto.offset.reset": "earliest",
    })
    consommateur.subscribe([TOPIC])
    try:
        while True:
            messages = consommateur.consume(num_messages=5000, timeout=2.0)
            evenements = []
            for m in messages:
                if m.error():
                    raise KafkaException(m.error())
                if m.value() is None:          # tombstone qui suit une suppression : ignoré
                    continue
                evenements.append(convertir(json.loads(m.value())))
            if not evenements:
                continue
            appliquer(evenements)
            consommateur.commit(asynchronous=False)
            maintenant = time.time()
            latences = [maintenant - e["_source_ts"].timestamp() for e in evenements if e["_op"] != "r"]
            if latences:
                p95 = statistics.quantiles(latences, n=20)[-1] if len(latences) >= 20 else max(latences)
                print(f"{len(evenements)} changements appliqués · latence médiane "
                      f"{statistics.median(latences):.2f} s · p95 {p95:.2f} s")
            else:
                print(f"{len(evenements)} lignes de l'instantané initial appliquées")
    except KeyboardInterrupt:
        pass
    finally:
        consommateur.close()

if __name__ == "__main__":
    main()
```

Trois mécanismes rendent ce consommateur sûr :

1. **Commit après écriture** : un plantage entre le `MERGE` et le commit fait relire le lot ; c'est du « au moins une fois ».
2. **MERGE sur la clé** `commande_id` : relire un lot ne crée pas de doublon.
3. **Garde sur `_lsn`** : une mise à jour plus ancienne relue après une reprise ne peut pas écraser une version plus récente. Ensemble, ils donnent l'effet « exactement une fois » de L166.

> 💡 **Autrement dit** — Le LSN est le numéro de page du journal de bord de Postgres. En gardant dans la table le numéro de page de la dernière modification appliquée, on refuse poliment toute modification « plus vieille » que ce qu'on a déjà.

> ⚠️ **Piège fréquent** — Un `MERGE` toutes les deux secondes produit des milliers de petits fichiers Parquet et de versions Delta : les requêtes ralentissent. Planifiez un compactage (`DeltaTable(CHEMIN).optimize.compact()`) et un nettoyage des fichiers obsolètes (`vacuum`, en respectant la durée de rétention du *time travel*), par exemple toutes les heures depuis l'orchestrateur de L164.

## 5. Interroger avec DuckDB et éprouver la chaîne

```bash
python cdc/cdc_vers_delta.py          # terminal 1 : applique l'instantané initial (120 000 commandes), puis suit le flux
```

```python
# breval/cdc/requete.py — terminal 2 : l'analyste interroge le lakehouse
import duckdb

con = duckdb.connect()
con.execute("INSTALL delta; LOAD delta;")
print(con.sql("""
    SELECT agence_id, statut, count(*) AS nb, sum(montant_ht) AS ca_ht
    FROM delta_scan('data/lake/commandes')
    GROUP BY ALL ORDER BY agence_id, nb DESC
"""))
print(con.sql("""SELECT commande_id, statut, mis_a_jour_le FROM delta_scan('data/lake/commandes')
                 WHERE commande_id IN (42, 43, 120001)"""))
```

```bash
# terminal 3 : on modifie l'ERP (la commande 43 est supprimée avec ses lignes, contrainte de clé étrangère oblige)
docker exec -i breval-postgres psql -U breval -d breval <<'SQL'
UPDATE erp.commandes SET statut = 'annulee' WHERE commande_id = 42;
BEGIN;
DELETE FROM erp.lignes_commande WHERE commande_id = 43;
DELETE FROM erp.commandes WHERE commande_id = 43;
COMMIT;
INSERT INTO erp.commandes (commande_id, numero, client_id, agence_id, canal, statut, date_commande,
                           date_livraison_prevue, montant_ht, mis_a_jour_le)
VALUES (120001, 'CMD-2026-9000001', 17, 'NAN', 'comptoir', 'validee',
        now() AT TIME ZONE 'Europe/Paris', current_date + 3, 1249.90, now() AT TIME ZONE 'Europe/Paris');
SQL
python cdc/requete.py      # quelques secondes plus tard : 42 annulée, 43 disparue, 120001 présente
```

Supervisez enfin le **slot de réplication**, le point de vigilance n° 1 du CDC sur Postgres :

```bash
docker exec -it breval-postgres psql -U breval -d breval -c "
  SELECT slot_name, active,
         pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn)) AS wal_retenu
  FROM pg_replication_slots;"
```

Arrêtez le conteneur `breval-connect` (`docker stop breval-connect`) et générez de l'activité : `wal_retenu` augmente. Redémarrez-le : Debezium reprend à sa position, `wal_retenu` redescend. En production, une alerte sur ce volume protège la base d'une saturation du disque.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : si le consommateur Python est arrêté pendant une heure, les changements de cette heure sont perdus pour la table Delta.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Les événements restent dans Kafka pendant la durée de rétention et le groupe lakehouse-commandes reprend à son dernier offset validé. C'est l'intérêt d'un journal persistant entre la source et la cible."
}
```

```mission
{
  "title": "Les codes d'opération des événements Debezium",
  "url": "https://debezium.io/documentation/",
  "steps": ["Ouvrez la documentation de Debezium", "Allez dans la référence du connecteur PostgreSQL", "Cherchez la description du champ op dans la structure des événements de changement (change event values)"],
  "question": "Quelles sont les valeurs possibles du champ op et que signifie chacune ?",
  "hint": "Il y en a au moins quatre, dont une propre à l'instantané initial ; d'autres concernent les TRUNCATE et les messages logiques.",
  "answer": "c = create, u = update, d = delete, r = read (instantané), t = truncate et m = message (messages de décodage logique) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 6. Variante Iceberg

Avec **PyIceberg** et un catalogue SQL local (fichier SQLite), le même consommateur peut écrire dans une table Iceberg. Les opérations d'upsert et de suppression dépendent de la version de PyIceberg : vérifiez la documentation avant de vous lancer.

```python
# cdc/variante_iceberg.py — pip install "pyiceberg[sql-sqlite,pyarrow]" (API upsert : PyIceberg récent, à vérifier)
from pathlib import Path

import pyarrow as pa
from pyiceberg.catalog.sql import SqlCatalog
from pyiceberg.expressions import In

entrepot = Path("data/lake/iceberg").resolve()
entrepot.mkdir(parents=True, exist_ok=True)
catalogue = SqlCatalog("breval", uri=f"sqlite:///{entrepot}/catalogue.db", warehouse=f"file://{entrepot}")
catalogue.create_namespace_if_not_exists("bronze")

def appliquer_iceberg(lot: pa.Table, ids_supprimes: list[int]) -> None:
    table = catalogue.create_table_if_not_exists("bronze.commandes", schema=lot.schema)
    if lot.num_rows:
        table.upsert(lot, join_cols=["commande_id"])         # mises à jour + insertions
    if ids_supprimes:
        table.delete(delete_filter=In("commande_id", ids_supprimes))  # suppressions propagées
```

DuckDB lit ensuite la table avec l'extension `iceberg` (`iceberg_scan(...)` sur le dossier ou le fichier de métadonnées de la table ; voir la documentation DuckDB). En production, on préfère un **catalogue REST** (Apache Polaris, Unity Catalog, vus en L157) et, souvent, un connecteur *sink* Kafka Connect ou un job Flink plutôt qu'un script maison.

> 🔗 **Documentation officielle** — [Delta Lake](https://delta.io/) 🇬🇧 · [Apache Iceberg](https://iceberg.apache.org/) 🇬🇧 · [Debezium](https://debezium.io/documentation/) 🇬🇧.

## 🎮 Défi : le crash au pire moment

Ajoutez `os._exit(1)` dans `main()` juste **après** `appliquer(evenements)` et **avant** `commit`, déclenché une seule fois (par exemple si un fichier `crash.flag` existe, que vous supprimez ensuite). Relancez. Combien d'événements sont relus ? La table contient-elle des doublons ? Une version plus ancienne a-t-elle pu écraser une plus récente ? Justifiez chaque réponse par une ligne du code.

## 🧪 Exercice pratique

**Consigne** : démontrez les trois critères de C5.3 sur la chaîne CDC.
1. **Latence mesurée** : écrivez un script qui met à jour 200 commandes à raison de 5 par seconde ; relevez la latence médiane et le p95 affichés par le consommateur.
2. **Sans perte** : comparez `SELECT count(*), sum(montant_ht) FROM erp.commandes` dans Postgres et la même requête sur `delta_scan('data/lake/commandes')` après stabilisation.
3. **Sans doublon après panne** : réalisez le défi ci-dessus puis vérifiez `count(*) = count(DISTINCT commande_id)` sur la table Delta.
4. **Suppressions** : supprimez 20 commandes dans l'ERP (lignes comprises, dans une transaction) et vérifiez qu'elles ont disparu de la table Delta en moins de 10 secondes.
5. Étendez le consommateur au topic `breval.erp.clients` (une table Delta par topic, clé `client_id`).

**Critères de réussite** : latence p95 rapportée (de l'ordre de quelques secondes en local) ; les deux agrégats Postgres et Delta sont identiques ; aucune clé dupliquée après la panne simulée ; les 20 suppressions sont propagées ; un court rapport (10 lignes) explique les choix (clé de MERGE, garde LSN, commit après écriture).

**Corrigé (pistes)** : la latence se décompose en temps de décodage du WAL par Debezium, de publication dans Kafka, d'attente du `consume(timeout=2.0)` et de durée du `MERGE` ; réduire le `timeout` diminue la latence au prix de lots plus petits. Pour le défi : tout le dernier lot est relu (le commit n'a pas eu lieu) ; pas de doublon grâce au `MERGE` sur `commande_id` ; pas d'écrasement grâce à `s._lsn > t._lsn`. Pour les clients : adaptez le schéma `CIBLE` (colonnes de `erp.clients`, `date_creation` en jours, `consentement_marketing` booléen) et gardez en tête que cette table contient des données personnelles : son accès doit être restreint comme celui du bronze (L161, M35). Remarquez enfin que les 5 commandes supprimées lors de l'expérience 3 de L162 sont **absentes** de la table Delta (l'instantané lit l'état actuel de l'ERP), alors qu'elles restent dans le bronze de dlt : le CDC corrige exactement ce que le curseur ne savait pas faire.

## ✅ Auto-évaluation express
1. Que se passe-t-il côté Postgres si le connecteur Debezium reste arrêté plusieurs jours ?
2. Pourquoi dédoublonner les événements d'un même lot avant le `MERGE` ?
3. À quoi sert la condition `s._lsn > t._lsn` ?

**Réponses** : 1. Le slot de réplication retient le WAL non lu : le disque de la base grossit, jusqu'à saturation si personne ne surveille. 2. Parce qu'un `MERGE` refuse (ou rend ambigu) le cas où plusieurs lignes sources correspondent à la même ligne cible ; on garde le dernier changement selon le LSN. 3. À empêcher qu'un événement plus ancien, relu après une reprise, écrase une version plus récente.

## 📚 Pour aller plus loin
- [Debezium — documentation](https://debezium.io/documentation/) 🇬🇧 — connecteur PostgreSQL, instantanés, signaux, Debezium Server.
- [Debezium — exemples officiels](https://github.com/debezium/debezium-examples/wiki) 🇬🇧 — architectures CDC prêtes à tester.
- [Apache Kafka — Kafka Connect](https://kafka.apache.org/documentation/#connect) 🇬🇧 — workers, convertisseurs, config providers.
- [RisingWave — Iceberg vs Delta vs Hudi (2026)](https://risingwave.com/blog/apache-iceberg-vs-delta-lake-vs-hudi-2026/) 🇬🇧 — comparatif tiers pour choisir le format de table.

> 🗺️ **Et maintenant ?** — Vos données circulent en lot comme en flux ; le module M35 vérifie qu'elles sont **dignes de confiance** : tests de qualité, contrats de données, catalogue, lignage et observabilité, en commençant par L170.
