---
id: L168
module: M34
level: N5
title: "Traiter les flux : Apache Flink, Spark Structured Streaming, Kafka Streams — état, watermarks, exactly-once"
minutes: 50
objectives:
  - "Comparer Apache Flink, Spark Structured Streaming et Kafka Streams selon la latence, le modèle d'exécution, l'état et l'exploitation"
  - "Implémenter une agrégation fenêtrée en temps d'événement avec watermark en PySpark et en Flink SQL"
  - "Expliquer la gestion de l'état (state store, RocksDB, checkpoints) et sa reprise après panne"
  - "Expliquer comment chaque moteur obtient un effet exactly-once et appliquer une sortie idempotente par micro-lot"
skills: ["C5.3"]
sources:
  - { title: "Apache Flink — documentation (stable)", url: "https://nightlies.apache.org/flink/flink-docs-stable/", lang: "en" }
  - { title: "Apache Spark — Structured Streaming", url: "https://spark.apache.org/docs/latest/streaming/index.html", lang: "en" }
  - { title: "PySpark — Getting Started", url: "https://spark.apache.org/docs/latest/api/python/getting_started/", lang: "en" }
  - { title: "Apache Kafka — documentation", url: "https://kafka.apache.org/documentation/#connect", lang: "en" }
  - { title: "DataTalksClub — Data Engineering Zoomcamp (module 7 : Kafka Streams, KSQL)", url: "https://github.com/datatalksclub/data-engineering-zoomcamp", lang: "en" }
---

# Traiter les flux : Apache Flink, Spark Structured Streaming, Kafka Streams — état, watermarks, exactly-once

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 34

## 🎯 Ce que vous saurez faire
- Choisir entre **Flink**, **Spark Structured Streaming** et **Kafka Streams** pour un besoin donné, et savoir quand un simple consommateur Python suffit.
- Écrire le même calcul (CA HT par agence de Bréval et par tranche de 5 minutes, en temps d'événement, avec 10 minutes de retard toléré) en **PySpark** et en **Flink SQL**.
- Expliquer où vit l'**état** d'un traitement de flux et comment il survit à une panne grâce aux **checkpoints**.
- Dire comment chaque moteur obtient un effet « exactement une fois », et écrire une sortie idempotente par micro-lot.

> 🧭 **En clair** — En L167, vous avez installé le tapis roulant (Kafka). Il faut maintenant des machines qui travaillent **sur** le tapis : compter, regrouper, joindre, alerter, sans jamais arrêter la chaîne. Ces machines ont une mémoire (l'**état** : « l'agence de Nantes en est à 12 400 € depuis 10 h 00 ») et prennent régulièrement une photo de cette mémoire (le **checkpoint**). En cas de panne, on recharge la dernière photo et on rembobine le tapis jusqu'au moment de la photo : rien n'est perdu, rien n'est compté deux fois.

## 1. Trois moteurs, trois philosophies

| | **Apache Flink** | **Spark Structured Streaming** | **Kafka Streams** |
|---|---|---|---|
| Nature | moteur de flux distribué dédié | extension streaming de Spark (même API DataFrame que le batch) | **bibliothèque Java** embarquée dans votre application |
| Modèle d'exécution | événement par événement (*true streaming*) | micro-lots (mode continu expérimental) | événement par événement |
| Latence typique | millisecondes | de la centaine de millisecondes à quelques secondes | millisecondes |
| Sources / sorties | très nombreuses (Kafka, fichiers, bases, Iceberg…) | très nombreuses (écosystème Spark) | **Kafka → Kafka** uniquement |
| État | très riche (RocksDB, TTL, temporisateurs) | *state store* (RocksDB possible) | *state stores* RocksDB, sauvegardés dans des topics |
| Langages | Java, SQL, Python (PyFlink) | Python, Scala, Java, SQL | Java / Kotlin (ksqlDB pour le SQL) |
| Exploitation | un cluster à gérer | un cluster Spark (ou Databricks) | aucune infrastructure en plus de Kafka |
| Idéal pour | temps réel exigeant, logique à état complexe, CEP | équipes déjà sur Spark, unification batch + flux | microservices qui réagissent aux événements Kafka |

Le **CEP** (*complex event processing*) désigne la détection de motifs dans un flux (« trois paiements refusés en 2 minutes sur la même carte »).

Et le consommateur Python de L167 ? Il suffit pour des transformations **sans état** ou à état simple, à faible débit. Dès que vous avez besoin de fenêtres en temps d'événement, de jointures entre flux ou d'une reprise exacte après panne, un moteur vous épargne de réinventer (mal) les checkpoints.

> 💡 **À retenir** — Kafka Streams = une bibliothèque, pas de cluster, Kafka seulement. Spark = un seul outil pour le batch et le flux. Flink = le spécialiste du flux à faible latence et à état riche.

```quiz
{
  "q": "Une équipe Java veut ajouter à son microservice de commandes une alerte « plus de 5 annulations en 10 minutes pour un même client », en lisant et écrivant uniquement dans Kafka, sans nouvelle infrastructure. Quel outil est le plus adapté ?",
  "options": [
    "Un cluster Apache Flink dédié",
    "Un DAG Airflow lancé toutes les 10 minutes sur le topic",
    "Spark Structured Streaming sur Databricks",
    "Kafka Streams, en bibliothèque dans le microservice"
  ],
  "answer": 3,
  "explanation": "Kafka Streams est une bibliothèque Java : pas de cluster supplémentaire, entrée et sortie Kafka, état local avec fenêtres. Flink et Spark conviendraient techniquement mais ajoutent une infrastructure ; Airflow n'est pas un moteur de flux."
}
```

## 2. Spark Structured Streaming : le même DataFrame, en continu

L'idée de Structured Streaming : un flux est une **table qui ne cesse de grandir**. Vous écrivez une requête DataFrame comme en batch ; Spark l'exécute de façon incrémentale, micro-lot après micro-lot. La documentation « latest » correspond à **PySpark 4.3.0** (nov. 2026).

```bash
pip install pyspark            # nécessite Java 17 ou plus récent installé sur la machine
export KAFKA_BOOTSTRAP=localhost:29092
```

```python
# breval/streaming/l168_spark_ca.py — CA HT par agence et par fenêtre de 5 min, en temps d'événement
import os

import pyspark
from pyspark.sql import SparkSession, functions as F, types as T

# Le connecteur Kafka doit correspondre à la version de Spark installée (Scala 2.13 pour Spark 4)
PAQUET_KAFKA = f"org.apache.spark:spark-sql-kafka-0-10_2.13:{pyspark.__version__}"

spark = (SparkSession.builder.appName("ca_temps_reel")
         .config("spark.jars.packages", PAQUET_KAFKA)
         .config("spark.sql.shuffle.partitions", "3")
         .getOrCreate())

SCHEMA = T.StructType([
    T.StructField("commande_id", T.LongType()),
    T.StructField("client_id", T.LongType()),
    T.StructField("agence_id", T.StringType()),
    T.StructField("canal", T.StringType()),
    T.StructField("montant_ht", T.DoubleType()),
    T.StructField("statut", T.StringType()),
    T.StructField("horodatage_utc", T.StringType()),     # temps d'événement écrit par le producteur (L167)
])

brut = (spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", os.environ.get("KAFKA_BOOTSTRAP", "localhost:29092"))
        .option("subscribe", "commandes-evenements")
        .option("startingOffsets", "earliest")
        .load())

evenements = (brut
    .select(F.from_json(F.col("value").cast("string"), SCHEMA).alias("e"))
    .select("e.*")
    .withColumn("temps_evenement", F.to_timestamp("horodatage_utc")))

ca = (evenements
    .withWatermark("temps_evenement", "10 minutes")                    # retard toléré
    .groupBy(F.window("temps_evenement", "5 minutes"), "agence_id")        # fenêtres fixes en temps d'événement
    .agg(F.round(F.sum("montant_ht"), 2).alias("ca_ht"), F.count("*").alias("nb_commandes")))

def ecrire_lot(df, batch_id: int) -> None:
    """Sortie idempotente : un micro-lot rejoué après panne réécrit le même dossier."""
    (df.select(F.col("window.start").alias("debut"), F.col("window.end").alias("fin"),
               "agence_id", "ca_ht", "nb_commandes")
       .write.mode("overwrite").parquet(f"sortie/ca_fenetres/batch_id={batch_id}"))

requete = (ca.writeStream
    .outputMode("append")                       # n'émet une fenêtre qu'une fois close par le watermark
    .foreachBatch(ecrire_lot)
    .option("checkpointLocation", "checkpoints/ca_temps_reel")   # offsets + état : la clé de la reprise
    .trigger(processingTime="10 seconds")
    .start())
requete.awaitTermination()
```

Lancez le producteur de L167, puis ce script. Les premières fenêtres n'apparaissent dans `sortie/` qu'après une dizaine de minutes : en mode `append`, Spark attend que le watermark dépasse la fin de chaque fenêtre, exactement comme la simulation de L166. Passez en `outputMode("update")` (avec une sortie console) pour voir des résultats provisoires mis à jour à chaque micro-lot.

```bash
python -c "import duckdb; print(duckdb.sql(\"SELECT debut, agence_id, sum(ca_ht) ca FROM 'sortie/ca_fenetres/*/*.parquet' GROUP BY ALL ORDER BY debut, agence_id\"))"
```

> ⚠️ **Piège fréquent** — Changer le code d'agrégation puis relancer avec le **même** `checkpointLocation`. L'état sauvegardé ne correspond plus à la nouvelle requête : Spark refuse de démarrer, ou pire, produit des résultats incohérents. Une modification de la logique à état impose un nouveau checkpoint (et donc un retraitement depuis un offset choisi).

## 3. Flink SQL : le flux comme une table, watermark compris

Dans Flink, le watermark se déclare **dans la définition de la table**, puis les fenêtres s'écrivent avec des fonctions de table (`TUMBLE`, `HOP`, `CUMULATE`, `SESSION`).

```sql
-- l168_flink_ca.sql — à exécuter dans le client SQL de Flink (sql-client.sh)
-- Prérequis : le JAR du connecteur SQL Kafka correspondant à VOTRE version de Flink
-- (voir la page « Connectors » de la documentation ; versions à vérifier en nov. 2026).
CREATE TABLE commandes_evenements (
  commande_id  BIGINT,
  client_id       BIGINT,
  agence_id       STRING,
  canal           STRING,
  montant_ht      DOUBLE,
  statut          STRING,
  horodatage_utc  TIMESTAMP(3),
  WATERMARK FOR horodatage_utc AS horodatage_utc - INTERVAL '10' MINUTE      -- retard toléré
) WITH (
  'connector' = 'kafka',
  'topic' = 'commandes-evenements',
  'properties.bootstrap.servers' = 'kafka:9092',
  'properties.group.id' = 'flink-ca',
  'scan.startup.mode' = 'earliest-offset',
  'format' = 'json',
  'json.timestamp-format.standard' = 'ISO-8601'
);

SELECT window_start, window_end, agence_id,
       ROUND(SUM(montant_ht), 2) AS ca_ht,
       COUNT(*)                   AS nb_commandes
FROM TABLE(
  TUMBLE(TABLE commandes_evenements, DESCRIPTOR(horodatage_utc), INTERVAL '5' MINUTES)
)
GROUP BY window_start, window_end, agence_id;
```

Flink émet chaque fenêtre quand le watermark dépasse `window_end`. Pour fiabiliser la reprise, activez les checkpoints (par exemple `SET 'execution.checkpointing.interval' = '30s';`) : à chaque intervalle, Flink injecte des **barrières** dans le flux et sauvegarde de façon cohérente les offsets Kafka et l'état de chaque opérateur.

> 💡 **Autrement dit** — La barrière de checkpoint, c'est un petit drapeau glissé sur le tapis roulant. Quand chaque machine voit passer le drapeau, elle photographie sa mémoire. Toutes les photos correspondent alors au même instant du flux.

```quiz
{
  "q": "Dans la table Flink ci-dessus, le watermark courant vaut 10:08. Arrive une commande dont horodatage_utc vaut 10:02. Que se passe-t-il ?",
  "options": [
    "Elle est comptée dans la fenêtre 10:00-10:05, qui attend encore les retardataires",
    "Elle est comptée dans la fenêtre 10:05-10:10",
    "Elle est retardataire : la fenêtre 10:00-10:05 est déjà close, l'événement est écarté",
    "Elle arrête le job avec une erreur"
  ],
  "answer": 2,
  "explanation": "Une fenêtre est émise et fermée dès que le watermark dépasse sa fin. À 10:08, la fenêtre 10:00-10:05 est close : l'événement de 10:02 est un retardataire. Règle à retenir : un événement n'est accepté que si la fin de sa fenêtre est postérieure au watermark courant."
}
```

## 4. Kafka Streams : le traitement dans l'application

Kafka Streams s'utilise depuis Java. Le même calcul, avec une fenêtre de 5 minutes et 10 minutes de grâce (*grace period*, l'équivalent du retard toléré), tient en quelques lignes :

```java
// CaParAgence.java — dépendance Maven org.apache.kafka:kafka-streams (même version que vos brokers)
import java.time.Duration;
import java.util.Properties;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.*;

public class CaParAgence {
  public static void main(String[] args) {
    Properties p = new Properties();
    p.put(StreamsConfig.APPLICATION_ID_CONFIG, "ca-par-agence");          // = group.id + préfixe des topics d'état
    p.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:29092");
    p.put(StreamsConfig.PROCESSING_GUARANTEE_CONFIG, StreamsConfig.EXACTLY_ONCE_V2);  // transactions Kafka
    p.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
    p.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());

    StreamsBuilder b = new StreamsBuilder();
    b.<String, String>stream("commandes-evenements-par-agence")  // valeur = montant HT, clé = agence_id (topic préparé en amont)
     .mapValues(Double::parseDouble)
     .groupByKey(Grouped.with(Serdes.String(), Serdes.Double()))
     .windowedBy(TimeWindows.ofSizeAndGrace(Duration.ofMinutes(5), Duration.ofMinutes(10)))
     .reduce(Double::sum)
     .toStream()
     .map((fenetre, ca) -> KeyValue.pair(fenetre.key() + "@" + fenetre.window().startTime(), String.valueOf(ca)))
     .to("ca-par-agence-5min");

    KafkaStreams app = new KafkaStreams(b.build(), p);
    Runtime.getRuntime().addShutdownHook(new Thread(app::close));
    app.start();
  }
}
```

Par défaut, Kafka Streams utilise l'horodatage du message Kafka comme temps d'événement ; pour lire `horodatage_utc` dans la valeur, on fournit un `TimestampExtractor`. L'état (les sommes en cours) vit dans un *state store* RocksDB local, sauvegardé dans un topic interne *changelog* : si l'instance meurt, une autre reconstruit l'état en relisant ce topic.

## 5. État, checkpoints et « exactly-once » : la synthèse

| | Flink | Spark Structured Streaming | Kafka Streams |
|---|---|---|---|
| Où vit l'état ? | *state backend* (mémoire ou RocksDB) | *state store* par partition (RocksDB disponible) | *state store* RocksDB local + topic changelog |
| Comment il survit | checkpoints périodiques (barrières) vers un stockage durable ; *savepoints* manuels pour les mises à jour | dossier de checkpoint (offsets + état) | relecture du topic changelog |
| Effet exactly-once | checkpoints + sorties transactionnelles en **deux phases** (ex. sortie Kafka transactionnelle) ou sorties idempotentes | source rejouable + checkpoint + sortie **idempotente** (ex. `foreachBatch` indexé par `batch_id`, MERGE) | `processing.guarantee = exactly_once_v2` (transactions Kafka), **de Kafka à Kafka** |
| Limite à connaître | la sortie doit supporter les transactions ou l'idempotence | une sortie non idempotente redevient « au moins une fois » | toute écriture hors Kafka (base, API) sort de la garantie |

> ⚠️ **Piège fréquent** — Laisser l'état grossir sans limite : une jointure entre deux flux sans watermark, ou un comptage par client « depuis toujours », finit par saturer la mémoire ou le disque. Bornez l'état : watermark, fenêtres, ou durée de vie (*TTL*) de l'état.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : avec processing.guarantee=exactly_once_v2, une application Kafka Streams qui envoie aussi un e-mail à chaque grosse commande garantit qu'aucun e-mail ne sera envoyé deux fois.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. La garantie couvre les lectures, l'état et les écritures dans Kafka, réunis dans une transaction. Un e-mail est un effet externe : après une reprise, le traitement est rejoué et l'e-mail peut repartir. Il faut une clé d'idempotence côté service d'envoi."
}
```

```mission
{
  "title": "Les modes de sortie de Structured Streaming",
  "url": "https://spark.apache.org/docs/latest/streaming/index.html",
  "steps": ["Ouvrez la documentation Structured Streaming de Spark", "Cherchez la section sur les modes de sortie (output modes)", "Notez les modes et ce que chacun écrit"],
  "question": "Quels sont les trois modes de sortie de Structured Streaming, et lequel n'émet une fenêtre agrégée qu'une fois close par le watermark ?",
  "hint": "Le mode qui ne réécrit jamais une ligne déjà émise.",
  "answer": "append, complete et update ; c'est append qui attend la clôture de la fenêtre par le watermark (doc « latest », PySpark 4.3.0, nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Les stratégies de watermark dans Flink",
  "url": "https://nightlies.apache.org/flink/flink-docs-stable/",
  "steps": ["Ouvrez la documentation stable de Flink", "Cherchez la page « Generating Watermarks » (section temps d'événement)", "Repérez la stratégie fournie pour des événements arrivant dans le désordre"],
  "question": "Quelle stratégie de watermark prédéfinie Flink propose-t-il pour des événements dont le désordre est borné, et quel paramètre prend-elle ?",
  "hint": "Son nom contient « bounded » et « out of orderness ».",
  "answer": "WatermarkStrategy.forBoundedOutOfOrderness(Duration) : le paramètre est le retard maximal toléré (équivalent de l'INTERVAL de la clause WATERMARK en SQL) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🎮 Défi : le moteur idéal

Pour chacun de ces besoins, choisissez Flink, Spark Structured Streaming, Kafka Streams ou « un consommateur Python suffit » en une phrase : (a) recopier les tickets SAV de Kafka vers un dossier Parquet toutes les minutes ; (b) détecter en moins d'une seconde un motif de fraude sur 50 000 paiements par seconde ; (c) calculer en continu le stock disponible par article dans un microservice Java ; (d) une équipe qui a déjà 200 jobs Spark batch veut des agrégats à la minute.

## 🧪 Exercice pratique

**Consigne** : avec le producteur de L167 et le script PySpark :
1. lancez le job, laissez tourner 15 minutes, puis arrêtez-le brutalement (`Ctrl+C` deux fois ou `kill -9`) ;
2. relancez-le avec le **même** checkpoint ; vérifiez par une requête DuckDB qu'aucune fenêtre n'est comptée deux fois (une seule ligne par `debut`, `agence_id` une fois les lots dédoublonnés) ;
3. mesurez le décalage entre la fin d'une fenêtre et son apparition dans `sortie/` ; expliquez-le à partir du watermark et du déclencheur de 10 secondes ;
4. réduisez le watermark à 1 minute, avec un **nouveau** checkpoint ; comparez le nombre de retardataires écartés (indice : comparez le nombre total de commandes en sortie avec celui produit).

**Critères de réussite** : la reprise ne perd ni ne double aucune fenêtre ; le décalage mesuré est expliqué (≈ retard toléré + intervalle de déclenchement) ; le compromis fraîcheur / exhaustivité est chiffré pour 10 min et 1 min.

**Corrigé (pistes)** : un micro-lot rejoué après la panne porte le même `batch_id` : `mode("overwrite")` sur `batch_id=<n>` le réécrit à l'identique, d'où l'idempotence. Le décalage avoisine 10 minutes (watermark) plus le délai jusqu'au micro-lot suivant. Avec 1 minute de watermark, les résultats arrivent environ 9 minutes plus tôt, mais les commandes simulées avec plus d'une minute de retard (environ 5 % avec la loi exponentielle de moyenne 20 s du producteur) disparaissent du total. Pour le défi : (a) consommateur Python ou Spark ; (b) Flink ; (c) Kafka Streams ; (d) Spark Structured Streaming.

## ✅ Auto-évaluation express
1. Quelle est la différence de modèle d'exécution entre Spark Structured Streaming et Flink ?
2. Que contient un dossier de checkpoint Spark ?
3. Pourquoi la garantie exactly-once de Kafka Streams s'arrête-t-elle aux frontières de Kafka ?

**Réponses** : 1. Spark traite par micro-lots ; Flink traite événement par événement. 2. Les offsets lus par source et l'état des opérateurs (plus les métadonnées des lots validés). 3. Parce qu'elle repose sur les transactions Kafka, qui ne couvrent que les écritures dans des topics Kafka.

## 📚 Pour aller plus loin
- [Apache Flink — documentation](https://nightlies.apache.org/flink/flink-docs-stable/) 🇬🇧 — temps d'événement, watermarks, checkpoints, Table API et SQL.
- [Spark Structured Streaming](https://spark.apache.org/docs/latest/streaming/index.html) 🇬🇧 — guide de programmation, watermarks, `foreachBatch`.
- [PySpark — Getting Started](https://spark.apache.org/docs/latest/api/python/getting_started/) 🇬🇧 — installation et Spark Connect.
- [Data Engineering Zoomcamp](https://github.com/datatalksclub/data-engineering-zoomcamp) 🇬🇧 — module 7 avec Kafka Streams et KSQL.

> 🗺️ **Et maintenant ?** — Place à l'atelier L169 : vous allez brancher l'ERP Postgres de Bréval sur Kafka par CDC Debezium et matérialiser le flux en table de lakehouse interrogeable par DuckDB, en mesurant la latence de bout en bout.
