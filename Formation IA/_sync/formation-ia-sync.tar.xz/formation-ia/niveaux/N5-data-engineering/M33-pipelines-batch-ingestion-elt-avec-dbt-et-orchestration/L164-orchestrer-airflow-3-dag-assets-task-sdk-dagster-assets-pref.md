---
id: L164
module: M33
level: N5
title: "Orchestrer : Airflow 3 (DAG, assets, Task SDK), Dagster (assets), Prefect — reprise, backfill, alertes"
minutes: 55
objectives:
  - "Expliquer le rôle d'un orchestrateur : dépendances, planification, reprise, rattrapage (backfill), alertes"
  - "Écrire un DAG Airflow 3 avec le Task SDK, des relances et un déclenchement par asset"
  - "Modéliser le même pipeline en assets Dagster intégrant chaque modèle dbt"
  - "Comparer Airflow, Dagster et Prefect pour un contexte donné et tenir compte de la consolidation du marché en 2026"
skills: ["C5.2", "C5.6"]
sources:
  - { title: "Apache Airflow — Announcements", url: "https://airflow.apache.org/announcements/", lang: "en" }
  - { title: "Apache Airflow 3.3.2 — notes de version", url: "https://airflow.apache.org/docs/apache-airflow/3.3.2/release_notes.html", lang: "en" }
  - { title: "Apache Airflow 3.0.0 — notes de version", url: "https://airflow.apache.org/docs/apache-airflow/3.0.0/release_notes.html", lang: "en" }
  - { title: "Dagster — documentation", url: "https://docs.dagster.io/", lang: "en" }
  - { title: "Dagster — Prefect is acquiring Dagster (13 juillet 2026)", url: "https://dagster.io/blog/prefect-is-acquiring-dagster", lang: "en" }
  - { title: "Prefect — documentation", url: "https://docs.prefect.io/", lang: "en" }
  - { title: "Data Lakehouse Hub — Orchestration in 2026: Airflow 3 vs Dagster vs Prefect", url: "https://datalakehousehub.com/blog/orchestration-in-2026/", lang: "en" }
---

# Orchestrer : Airflow 3 (DAG, assets, Task SDK), Dagster (assets), Prefect — reprise, backfill, alertes

> ⏱ 55 min · 🎯 Niveau 5 · 📚 Module 33

## 🎯 Ce que vous saurez faire
- Expliquer ce qu'un orchestrateur apporte de plus qu'une ligne `cron` : dépendances, relances, rattrapage du passé, alertes, historique.
- Écrire le pipeline de Bréval Matériaux (ingestion dlt puis `dbt build`) en **DAG Airflow 3** avec le Task SDK et un déclenchement par **asset**.
- Écrire le même pipeline en **assets Dagster**, où chaque modèle dbt devient un nœud du graphe.
- Choisir un orchestrateur en connaissant l'état du marché en novembre 2026 (Airflow 3.3.2, rachat de Dagster Labs par Prefect).

> 🧭 **En clair** — Un orchestrateur est le chef d'orchestre de la cuisine. Il ne cuisine pas lui-même : il dit au commis de commencer les légumes à 2 h du matin, attend qu'ils soient prêts pour lancer la sauce, relance le four s'il s'est éteint, et prévient le chef par SMS si un plat est raté. Si l'on découvre lundi que la recette de la semaine dernière était fausse, il sait refaire les sept services passés, un par un, dans l'ordre. Une simple minuterie (`cron`) sait seulement sonner à l'heure ; elle ne sait ni attendre, ni relancer, ni prévenir.

## 1. Ce qu'on attend d'un orchestrateur

| Besoin | Sans orchestrateur (`cron` + scripts) | Avec orchestrateur |
|---|---|---|
| **Dépendances** | « on lance dbt à 2 h 30 en espérant que l'ingestion de 2 h soit finie » | dbt démarre quand l'ingestion **a réussi** |
| **Reprise** (*retry*) | rien, ou une boucle maison | relances automatiques avec délai croissant |
| **Rattrapage** (*backfill*) | relancer à la main, jour par jour | « rejoue du 1er au 31 octobre » en une commande |
| **Alertes** | on découvre le problème au comité de direction | message sur la messagerie de l'équipe à l'échec |
| **Historique et journaux** | fichiers de log dispersés | interface : qui a tourné, combien de temps, avec quelle erreur |

Deux philosophies coexistent :

- **Orienté tâches** : on décrit des *étapes* à exécuter dans un ordre (un DAG, graphe orienté acyclique). C'est le modèle historique d'**Airflow**.
- **Orienté assets** : on décrit les *objets de données* à produire (une table, un fichier, un index) et leurs dépendances ; l'outil en déduit quoi exécuter. C'est le modèle natif de **Dagster**, qu'Airflow a largement rattrapé avec les *assets* d'Airflow 3.

> 💡 **Autrement dit** — Orienté tâches : « fais ceci, puis cela ». Orienté assets : « je veux que cette table existe et soit à jour ; débrouille-toi ». Le second colle mieux à dbt, où chaque modèle est déjà un objet de données.

> 💡 **À retenir** — L'orchestrateur ne rend pas un pipeline idempotent : il le **relance**. Si vos tâches ne sont pas idempotentes (L161), chaque relance automatique crée des doublons. Idempotence d'abord, orchestration ensuite.

```quiz
{
  "q": "Votre ingestion échoue à 2 h 05 à cause d'une coupure réseau ; l'orchestrateur la relance avec succès à 2 h 10. Quelle propriété de la tâche garantit que le résultat est correct ?",
  "options": [
    "Sa rapidité d'exécution, qui limite la fenêtre de panne",
    "Le fait qu'elle soit écrite en Python avec le Task SDK d'Airflow 3.3",
    "Son idempotence : rejouée, elle aboutit toujours au même état",
    "Le nombre de relances configuré dans l'orchestrateur, ici trois"
  ],
  "answer": 2,
  "explanation": "Une relance n'est sûre que si la tâche est idempotente. Sinon, les lignes écrites par la tentative partielle s'ajoutent à celles de la tentative réussie."
}
```

## 2. Airflow 3 : DAG, Task SDK et assets

**Apache Airflow** reste l'orchestrateur le plus répandu et celui que citent les certifications cloud. La version **3.3.2** est parue le **17 septembre 2026** (nov. 2026). La génération 3 a apporté trois changements à connaître :

- **Le Task SDK** (`airflow.sdk`) : l'API stable pour écrire DAG et tâches. Les tâches communiquent avec le serveur d'API via la *Task Execution API* au lieu d'accéder directement à la base de métadonnées : meilleure isolation, et tâches exécutables à distance.
- **Les assets** (anciennement *datasets* dans Airflow 2) : une tâche déclare l'asset qu'elle met à jour (`outlets`) ; un autre DAG peut être planifié **sur cet asset** plutôt qu'à heure fixe. Les versions 3.2 et 3.3 ajoutent le partitionnement d'assets (d'après un comparatif tiers ; détails à vérifier dans les notes de version).
- **Une nouvelle interface** et un *backfill* piloté par le planificateur.

```bash
# Installation locale (Python 3.12) avec le fichier de contraintes officiel
AIRFLOW_VERSION=3.3.2
PYTHON_VERSION=3.12
pip install "apache-airflow==${AIRFLOW_VERSION}" \
  --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-${AIRFLOW_VERSION}/constraints-${PYTHON_VERSION}.txt"
export AIRFLOW_HOME="$PWD/airflow_home"
airflow standalone      # base, planificateur et interface sur http://localhost:8080 (identifiants affichés)
```

```python
# airflow_home/dags/breval_pipeline.py — Airflow 3.x, Task SDK
import os
import subprocess
from datetime import datetime, timedelta

import requests
from airflow.sdk import Asset, dag, task

PROJET = os.environ.get("BREVAL_PROJET", "/opt/breval")   # dossier breval/ des leçons L151-L163
BRONZE = Asset("breval_bronze")
GOLD = Asset("breval_gold")

def alerter(context) -> None:
    """Callback d'échec : poste un message sur un webhook (Mattermost, Slack, Teams…)."""
    ti = context["ti"]
    message = f"❌ {ti.dag_id}.{ti.task_id} a échoué (essai {ti.try_number}) : {context.get('exception')}"
    url = os.environ.get("ALERTE_WEBHOOK_URL")
    if url:
        requests.post(url, json={"text": message}, timeout=10)
    else:
        print(message)

PAR_DEFAUT = {
    "retries": 3,
    "retry_delay": timedelta(minutes=5),
    "retry_exponential_backoff": True,   # 5 min, puis environ 10, 20…
    "on_failure_callback": alerter,      # appelé quand toutes les relances ont échoué
}

@dag(schedule="0 2 * * *", start_date=datetime(2026, 11, 1), catchup=False,
     default_args=PAR_DEFAUT, tags=["breval", "bronze"])
def breval_ingestion():
    @task(outlets=[BRONZE])
    def ingerer(ds=None):
        print(f"Ingestion pour la date logique {ds}")
        subprocess.run(["python", "ingestion/ingest.py"], check=True, cwd=PROJET)
    ingerer()

@dag(schedule=[BRONZE], start_date=datetime(2026, 11, 1), catchup=False,
     default_args=PAR_DEFAUT, tags=["breval", "dbt"])
def breval_transformation():
    @task(outlets=[GOLD])
    def dbt_build():
        projet_dbt = f"{PROJET}/dbt_breval"
        subprocess.run(["dbt", "build", "--profiles-dir", "."], check=True, cwd=projet_dbt)
    dbt_build()

breval_ingestion()
breval_transformation()
```

Le second DAG n'a **pas d'horaire** : il démarre chaque fois que l'asset `breval_bronze` est mis à jour avec succès. Si l'ingestion échoue après ses trois relances, `breval_transformation` ne tourne pas, et l'alerte part.

**Backfill** : pour rejouer octobre après correction d'une règle, Airflow 3 propose le rattrapage depuis l'interface ou en ligne de commande :

```bash
airflow backfill create --dag-id breval_ingestion --from-date 2026-10-01 --to-date 2026-10-31
```

Chaque exécution reçoit sa **date logique** (`ds`) : c'est elle, et non l'horloge, que vos tâches doivent utiliser pour savoir quelle période traiter (règle de rejouabilité de L161). Notez qu'un DAG déclenché par un asset n'a pas toujours de date logique : prévoyez ce cas.

> ⚠️ **Piège fréquent** — Mettre du code lourd au niveau supérieur du fichier DAG (requête SQL, appel d'API, import de gros modèles). Le planificateur relit ces fichiers en permanence : le code de haut niveau s'exécute à chaque lecture. Tout travail réel doit se trouver **dans** les tâches.

> 🔗 **Documentation officielle** — [Airflow — notes de version 3.0.0](https://airflow.apache.org/docs/apache-airflow/3.0.0/release_notes.html) 🇬🇧 pour la liste des changements de la génération 3 (Task SDK, assets, backfill), et [notes de version 3.3.2](https://airflow.apache.org/docs/apache-airflow/3.3.2/release_notes.html) 🇬🇧.

```mission
{
  "title": "La dernière version d'Airflow",
  "url": "https://airflow.apache.org/announcements/",
  "steps": ["Ouvrez la page Announcements du site Apache Airflow", "Repérez l'annonce de version la plus récente", "Notez le numéro de version et la date"],
  "question": "Quelle est la dernière version d'Apache Airflow annoncée et à quelle date est-elle parue ?",
  "hint": "Les annonces sont classées de la plus récente à la plus ancienne.",
  "answer": "Airflow 3.3.2, publiée le 17 septembre 2026 (au 5 nov. 2026 — vérifiez, une version plus récente a pu paraître depuis) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 3. Dagster : penser en assets

**Dagster** décrit le pipeline comme un graphe d'**assets logiciels** : chaque fonction décorée produit un objet de données nommé. L'intégration `dagster-dbt` lit le `manifest.json` de dbt et transforme **chaque modèle dbt en asset**, avec ses tests en *asset checks*. Le lignage affiché va donc de la table Postgres jusqu'au mart gold, sans rien déclarer deux fois.

```bash
pip install dagster dagster-webserver dagster-dbt requests
```

```python
# breval/orchestration/defs.py — Dagster : ingestion dlt + modèles dbt en assets
import os
import subprocess
import sys
from pathlib import Path

import dagster as dg
import requests
from dagster_dbt import DbtCliResource, DbtProject, dbt_assets

RACINE = Path(__file__).resolve().parent.parent
projet_dbt = DbtProject(project_dir=RACINE / "dbt_breval")
projet_dbt.prepare_if_dev()          # en développement : génère le manifest.json automatiquement

# Clés [<source dbt>, <table>] : par défaut, dagster-dbt nomme ainsi les sources dbt (erp, sav de L163),
# ce qui relie les assets d'ingestion aux modèles dbt dans un seul graphe.
SOURCES_BRONZE = [["erp", "clients"], ["erp", "commandes"], ["erp", "lignes_commande"], ["sav", "tickets_sav"]]

@dg.multi_asset(
    specs=[dg.AssetSpec(cle, group_name="bronze") for cle in SOURCES_BRONZE],
    retry_policy=dg.RetryPolicy(max_retries=3, delay=60),
)
def bronze_breval(context: dg.AssetExecutionContext):
    subprocess.run([sys.executable, str(RACINE / "ingestion" / "ingest.py")], check=True, cwd=RACINE)
    for cle in SOURCES_BRONZE:
        yield dg.MaterializeResult(asset_key=cle)

@dbt_assets(manifest=projet_dbt.manifest_path)
def modeles_dbt(context: dg.AssetExecutionContext, dbt: DbtCliResource):
    yield from dbt.cli(["build"], context=context).stream()

breval_quotidien = dg.define_asset_job("breval_quotidien", selection=dg.AssetSelection.all())

@dg.run_failure_sensor(monitored_jobs=[breval_quotidien])
def alerte_echec(context: dg.RunFailureSensorContext):
    message = f"❌ {context.dagster_run.job_name} a échoué : {context.failure_event.message}"
    url = os.environ.get("ALERTE_WEBHOOK_URL")
    if url:
        requests.post(url, json={"text": message}, timeout=10)
    else:
        context.log.error(message)

defs = dg.Definitions(
    assets=[bronze_breval, modeles_dbt],
    jobs=[breval_quotidien],
    schedules=[dg.ScheduleDefinition(job=breval_quotidien, cron_schedule="0 2 * * *",
                                     execution_timezone="Europe/Paris")],
    sensors=[alerte_echec],
    resources={"dbt": DbtCliResource(project_dir=projet_dbt)},
)
```

```bash
cd breval && dagster dev -f orchestration/defs.py     # interface sur http://localhost:3000
```

Dans l'interface, la vue *Asset lineage* affiche `erp/commandes → stg_erp__commandes → fct_commandes → ca_journalier_par_agence`. Vous pouvez matérialiser **un seul** asset et ses descendants, ce qui évite de tout relancer après un correctif. Pour le rattrapage, Dagster s'appuie sur les **partitions** (par exemple `dg.DailyPartitionsDefinition(start_date="2026-10-01")`) : on sélectionne une plage de partitions dans l'interface et Dagster lance un *backfill*.

```quiz
{
  "q": "Dans le graphe Dagster ci-dessus, vous corrigez uniquement le modèle ca_journalier_par_agence. Quelle est l'action la plus économe ?",
  "options": [
    "Matérialiser seulement cet asset et ses éventuels descendants",
    "Relancer tout le job breval_quotidien, ingestion comprise",
    "Supprimer la base DuckDB et tout reconstruire",
    "Attendre l'exécution planifiée de 2 h"
  ],
  "answer": 0,
  "explanation": "L'orientation assets permet de reconstruire précisément l'objet modifié et ce qui en dépend, sans réingérer les sources ni recalculer les modèles en amont."
}
```

## 4. Prefect : du Python, simplement

**Prefect 3** mise sur la simplicité : des fonctions Python décorées `@flow` et `@task`, des relances déclarées dans le décorateur, et un déploiement en une ligne.

```python
# breval/orchestration/flow_prefect.py — pip install prefect
import subprocess
import sys
from pathlib import Path

from prefect import flow, task

RACINE = Path(__file__).resolve().parent.parent

@task(retries=3, retry_delay_seconds=60)
def ingerer():
    subprocess.run([sys.executable, "ingestion/ingest.py"], check=True, cwd=RACINE)

@task(retries=1)
def transformer():
    subprocess.run(["dbt", "build", "--profiles-dir", "."], check=True, cwd=RACINE / "dbt_breval")

@flow(log_prints=True)
def breval_quotidien():
    ingerer()
    transformer()

if __name__ == "__main__":
    breval_quotidien.serve(name="breval-quotidien", cron="0 2 * * *")
```

## 5. Choisir en 2026

| Critère | Airflow 3 | Dagster | Prefect 3 |
|---|---|---|---|
| Modèle | DAG de tâches + assets | assets natifs (lignage, partitions, checks) | flows et tasks Python, événements |
| Intégration dbt | via opérateurs ou paquets tiers | la plus étroite : 1 modèle = 1 asset | via appel CLI ou intégration |
| Exploitation | la plus lourde (planificateur, API, base, workers) | intermédiaire | la plus légère à auto-héberger |
| Écosystème | le plus large ; services managés chez les clouds | en croissance | en croissance |
| Pour qui ? | grande organisation, multi-équipes, exigences d'examen cloud | équipe data centrée dbt et lignage | petite équipe Python, *fan-out* dynamique |

Ces appréciations résument un comparatif tiers ([Data Lakehouse Hub, 2026](https://datalakehousehub.com/blog/orchestration-in-2026/)) ; testez sur votre propre cas. **Actualité du marché** : le 13 juillet 2026, **Prefect a annoncé le rachat de Dagster Labs** ; la marque Dagster est conservée et le projet open source reste activement développé selon l'annonce. Autres options : **Kestra** (déclaratif en YAML, utilisé par le module 2 du Zoomcamp) et les orchestrateurs des plateformes (Lakeflow Jobs chez Databricks, au programme de la certification Databricks Data Engineer Associate).

> ⚠️ **Piège fréquent** — Choisir l'orchestrateur avant d'avoir un pipeline idempotent et testé. Commencez par un `make pipeline` qui fonctionne et se rejoue ; l'orchestrateur viendra encadrer quelque chose de sain.

```mission
{
  "title": "Le rachat de Dagster Labs",
  "url": "https://dagster.io/blog/prefect-is-acquiring-dagster",
  "steps": ["Ouvrez le billet de blog de Dagster consacré au rachat", "Repérez la date et l'acquéreur", "Cherchez ce qui est dit de la marque et du projet open source"],
  "question": "Qui rachète Dagster Labs, à quelle date, et que devient la marque Dagster ?",
  "hint": "Le titre du billet donne déjà l'acquéreur.",
  "answer": "Prefect, annonce du 13 juillet 2026 ; la marque Dagster est conservée et le projet open source reste activement développé (environ 40 personnes rejoignent Prefect) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🎮 Défi : la panne de 3 h 12

Il est 3 h 12, l'ingestion a échoué trois fois (le mot de passe Postgres a été changé). Retracez, pour votre DAG Airflow : qui est prévenu, quand, ce qui **ne** tourne pas, et les deux commandes à lancer le matin après avoir corrigé le secret pour que le tableau de bord soit à jour.

## 🧪 Exercice pratique

**Consigne** : orchestrez le pipeline de L162-L163 avec **l'un** des deux outils (Airflow 3 ou Dagster) :
1. ingestion puis `dbt build`, dans cet ordre, avec 3 relances sur l'ingestion ;
2. planification quotidienne à 2 h (heure de Paris) ;
3. alerte en cas d'échec (webhook ou, à défaut, message dans les journaux) ;
4. provoquez un échec (arrêtez le conteneur Postgres), constatez les relances et l'alerte, puis relancez après réparation ;
5. rejouez trois jours passés (backfill Airflow ou partitions Dagster).

**Critères de réussite** : la transformation ne démarre jamais après une ingestion en échec ; l'alerte est visible ; le rejeu des trois jours ne crée pas de doublon (même `count(*)` dans `fct_commandes`) ; captures d'écran de la vue graphe jointes au rendu.

**Corrigé (pistes)** : `docker stop breval-postgres` provoque une erreur de connexion dans `ingest.py`, donc `subprocess.run(..., check=True)` lève une exception, ce qui déclenche les relances puis le callback ou le capteur d'échec. Pour le défi : l'équipe est prévenue après la dernière relance (environ 35 min plus tard avec le délai exponentiel) ; `breval_transformation` ne tourne pas ; le matin, on met à jour le secret puis on relance l'exécution en échec (*clear* dans l'interface Airflow), ce qui met à jour l'asset et déclenche la transformation.

## ✅ Auto-évaluation express
1. Quelle est la différence entre une planification horaire et une planification sur asset ?
2. Pourquoi une tâche doit-elle utiliser la date logique fournie par l'orchestrateur ?
3. Dans Dagster, comment un modèle dbt apparaît-il dans le graphe ?

**Réponses** : 1. L'horaire déclenche à heure fixe ; l'asset déclenche quand une donnée amont a été mise à jour avec succès. 2. Pour que le rattrapage (backfill) traite la bonne période, quel que soit le jour de l'exécution. 3. Comme un asset (avec ses tests en asset checks), relié aux assets bronze par les sources dbt.

## 📚 Pour aller plus loin
- [Apache Airflow — Announcements](https://airflow.apache.org/announcements/) 🇬🇧 — versions et annonces officielles.
- [Dagster — documentation](https://docs.dagster.io/) 🇬🇧 — assets, intégration dbt, partitions, capteurs.
- [Prefect — documentation](https://docs.prefect.io/) 🇬🇧 — flows, déploiements, automatisations.
- [Data Engineering Zoomcamp](https://github.com/datatalksclub/data-engineering-zoomcamp) 🇬🇧 — le module 2 traite l'orchestration (avec Kestra).

> 🗺️ **Et maintenant ?** — Toutes les pièces sont là ; l'atelier L165 les assemble en un dépôt complet, avec une intégration continue qui ne reconstruit que les modèles dbt modifiés.
