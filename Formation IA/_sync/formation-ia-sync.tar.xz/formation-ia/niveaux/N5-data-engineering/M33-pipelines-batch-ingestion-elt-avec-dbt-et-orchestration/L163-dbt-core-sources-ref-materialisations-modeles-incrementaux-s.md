---
id: L163
module: M33
level: N5
title: "dbt Core : sources, ref, matérialisations, modèles incrémentaux, snapshots, tests, documentation et lignage"
minutes: 60
objectives:
  - "Structurer un projet dbt Core en couches staging / marts avec sources et ref()"
  - "Choisir la matérialisation adaptée (view, table, incremental, ephemeral) et écrire un modèle incrémental idempotent"
  - "Historiser une dimension avec un snapshot (SCD type 2)"
  - "Écrire des tests génériques, un test singulier, un unit test et un contrat de modèle"
  - "Générer la documentation et lire le graphe de lignage"
skills: ["C5.2", "C5.4"]
sources:
  - { title: "dbt — documentation officielle", url: "https://docs.getdbt.com/", lang: "en" }
  - { title: "dbt — Data tests", url: "https://docs.getdbt.com/docs/build/data-tests", lang: "en" }
  - { title: "dbt — Source freshness", url: "https://docs.getdbt.com/docs/deploy/source-freshness", lang: "en" }
  - { title: "dbt — Analytics Engineering Certification Exam", url: "https://www.getdbt.com/certifications/analytics-engineer-certification-exam", lang: "en" }
  - { title: "dbt Labs — New Learn courses (dbt Learn Fundamentals gratuit)", url: "https://www.getdbt.com/blog/new-learn-courses", lang: "en" }
  - { title: "dbt Learn — catalogue", url: "https://learn.getdbt.com/catalog", lang: "en" }
---

# dbt Core : sources, ref, matérialisations, modèles incrémentaux, snapshots, tests, documentation et lignage

> ⏱ 60 min · 🎯 Niveau 5 · 📚 Module 33

## 🎯 Ce que vous saurez faire
- Créer un projet **dbt Core** branché sur DuckDB, qui transforme le bronze de Bréval Matériaux en silver et gold avec du SQL versionné dans Git.
- Relier les modèles entre eux par `source()` et `ref()` pour que dbt calcule seul l'ordre d'exécution.
- Choisir entre `view`, `table`, `incremental` et `ephemeral`, et écrire un modèle incrémental qui reste idempotent.
- Historiser les déménagements d'un client avec un **snapshot** (SCD type 2), comme la `dim_client` conçue à la main en L154.
- Protéger le pipeline par des tests (`unique`, `not_null`, `accepted_values`, `relationships`), un **unit test** et un **contrat**, puis publier la documentation et le graphe de lignage.

> 🧭 **En clair** — dbt est le classeur de recettes de la cuisine de L161. Chaque recette (un **modèle**) est une simple requête `SELECT` qui dit « je prends tel ingrédient et je fabrique tel plat ». Quand une recette en utilise une autre (« prenez la pâte brisée de la page 12 »), dbt le note et sait dans quel ordre cuisiner. Il goûte aussi chaque plat avant de le servir (les **tests**), et il imprime le livre de recettes avec un plan qui montre d'où vient chaque ingrédient (la **documentation** et le **lignage**). Vous écrivez du SQL ; dbt s'occupe du reste.

## 1. Ce que fait dbt, et ce qu'il ne fait pas

**dbt** (*data build tool*) est le « T » de l'ELT. Il ne déplace aucune donnée entre systèmes : il se connecte à un entrepôt (ici DuckDB, mais aussi Postgres, Snowflake, BigQuery, Databricks…) et y exécute vos `SELECT` en les enveloppant dans des `CREATE VIEW` ou `CREATE TABLE`. Ses apports :

- **Le graphe de dépendances** (DAG) calculé à partir de `ref()` et `source()` ;
- **Les matérialisations** : vous décrivez le résultat, dbt génère le DDL ;
- **Les tests** de données, unitaires et les contrats ;
- **Jinja** (gabarits) et **macros** pour factoriser le SQL ;
- **La documentation** et le **lignage** générés automatiquement ;
- **L'état** (*state*) : comparer deux versions du projet pour ne reconstruire que ce qui a changé (atelier L165).

**dbt Core** est open source et gratuit ; c'est lui que nous utilisons. La certification *dbt Analytics Engineering* est alignée sur **dbt 1.11** (nov. 2026), et dbt Labs propose le cours **dbt Learn Fundamentals** gratuit (environ 5 h), excellent complément à cette leçon.

```bash
# Dans breval/, avec l'environnement virtuel activé
pip install dbt-core dbt-duckdb            # visez dbt 1.11 ; compatibilité dbt-duckdb / DuckDB 2.0 : à vérifier
dbt init dbt_breval --skip-profile-setup   # crée le squelette du projet
cd dbt_breval
```

## 2. Le projet de Bréval

```
breval/dbt_breval/
├── dbt_project.yml
├── profiles.yml                  ← connexion (ici dans le projet, pour le TP)
├── macros/generate_schema_name.sql
├── models/
│   ├── staging/                  ← silver : 1 modèle par table source, renommage, typage, minimisation
│   │   ├── _sources.yml
│   │   ├── stg_erp__clients.sql  stg_erp__commandes.sql  stg_erp__lignes_commande.sql  stg_sav__tickets.sql
│   │   └── _staging.yml          ← tests
│   └── marts/                    ← gold : faits, dimensions, agrégats
│       ├── dim_client.sql  fct_commandes.sql  ca_journalier_par_agence.sql
│       └── _marts.yml            ← tests, contrat, unit test
├── snapshots/snap_clients.yml
└── tests/assert_dates_commande_plausibles.sql   ← test singulier
```

La convention `stg_<source>__<table>` (double tiret bas) indique d'un coup d'œil d'où vient chaque modèle de staging.

```yaml
# dbt_project.yml
name: breval
version: "1.0.0"
profile: breval
model-paths: ["models"]
snapshot-paths: ["snapshots"]
test-paths: ["tests"]
macro-paths: ["macros"]

models:
  breval:
    staging:
      +materialized: view
      +schema: silver
    marts:
      +materialized: table
      +schema: gold
```

```yaml
# profiles.yml — dbt cherche d'abord ce fichier dans le dossier courant
breval:
  target: dev
  outputs:
    dev:
      type: duckdb
      path: "{{ env_var('BREVAL_DUCKDB_PATH', '../data/breval.duckdb') }}"
      schema: main
      threads: 4
      settings:
        TimeZone: UTC   # dlt peut stocker les horodatages sans fuseau de l'ERP en TIMESTAMP WITH TIME ZONE (lus comme UTC) :
                        # une session en UTC rend les conversions neutres (comportement à vérifier selon votre version de dlt)
```

Par défaut, dbt nomme un schéma personnalisé `<schéma_cible>_<schéma>` (ici `main_silver`). Cette macro le remplace par le nom exact, pratique pour retrouver `silver` et `gold` :

```sql
-- macros/generate_schema_name.sql
{% macro generate_schema_name(custom_schema_name, node) -%}
  {%- if custom_schema_name is none -%}{{ target.schema }}{%- else -%}{{ custom_schema_name | trim }}{%- endif -%}
{%- endmacro %}
```

Vérifiez la connexion avec `dbt debug` (le fichier `../data/breval.duckdb` est l'entrepôt des ateliers de M31, rempli par dlt en L162).

## 3. Sources et `ref()` : le graphe se dessine tout seul

Une **source** déclare une table que dbt ne construit pas (notre bronze). On peut y attacher un contrôle de **fraîcheur** : la commande `dbt source freshness` alerte si les données n'ont pas été rafraîchies. Les deux systèmes sources de Bréval deviennent deux sources dbt, toutes deux chargées par dlt dans le schéma `bronze`.

```yaml
# models/staging/_sources.yml
version: 2
sources:
  - name: erp
    schema: bronze
    tables:
      - name: clients
      - name: lignes_commande
      - name: commandes
        loaded_at_field: mis_a_jour_le   # en dbt ≥ 1.10, ces clés peuvent aussi se placer sous config: (à vérifier)
        freshness:
          warn_after: {count: 24, period: hour}
          error_after: {count: 48, period: hour}
  - name: sav
    schema: bronze
    tables:
      - name: tickets_sav
```

```sql
-- models/staging/stg_erp__commandes.sql — silver : renommer, typer, normaliser. Une ligne = une commande.
select
    cast(commande_id as bigint)          as commande_id,
    numero,
    cast(client_id as bigint)            as client_id,
    agence_id,
    canal,
    lower(trim(statut))                  as statut,
    cast(date_commande as timestamp)     as date_commande,     -- heure de Paris sans fuseau (héritage ERP, L151)
    date_livraison_prevue,
    cast(montant_ht as decimal(12, 2))   as montant_ht,
    cast(mis_a_jour_le as timestamp)     as mis_a_jour_le
from {{ source('erp', 'commandes') }}
```

```sql
-- models/staging/stg_erp__clients.sql
-- Minimisation RGPD : nom, prénom, e-mail et téléphone restent en bronze (accès restreint) ;
-- les usages qui en ont besoin passeront par la pseudonymisation de M36.
select
    cast(client_id as bigint)            as client_id,
    code_client, type_client, segment, raison_sociale,
    code_postal, trim(ville)             as ville, agence_id,
    date_creation, consentement_marketing,
    cast(mis_a_jour_le as timestamp)     as mis_a_jour_le
from {{ source('erp', 'clients') }}
```

```sql
-- models/staging/stg_erp__lignes_commande.sql
select
    cast(ligne_id as bigint)                  as ligne_id,
    cast(commande_id as bigint)               as commande_id,
    num_ligne,
    cast(produit_id as bigint)                as produit_id,
    cast(quantite as decimal(10, 1))          as quantite,
    cast(prix_unitaire_ht as decimal(10, 2))  as prix_unitaire_ht,   -- parfois nul (défaut connu, L151)
    cast(remise_pct as decimal(4, 1))         as remise_pct
from {{ source('erp', 'lignes_commande') }}
```

```sql
-- models/staging/stg_sav__tickets.sql — colonnes de premier niveau ; messages et tags sont dans des tables enfants dlt
select
    ticket_id,
    cast(client_id as bigint)    as client_id,
    cast(commande_id as bigint)  as commande_id,
    ouvert_le, ferme_le, canal, categorie, priorite,
    lower(statut)                as statut,
    satisfaction                 -- valeurs textuelles éventuelles : colonne variante créée par dlt (dérive de type, M35)
from {{ source('sav', 'tickets_sav') }}
```

Dès qu'un modèle écrit `{{ ref('stg_erp__commandes') }}`, dbt sait que `stg_erp__commandes` doit être construit **avant**. Vous ne déclarez jamais l'ordre : il est déduit. C'est aussi ce qui permet à dbt de remplacer le nom selon l'environnement (dev, CI, prod).

> 💡 **À retenir** — Jamais de nom de table en dur dans un modèle : `source()` pour ce qui vient de l'extérieur, `ref()` pour ce que dbt construit. Un nom en dur casse le lignage, la CI et le passage dev → prod.

```quiz
{
  "q": "Un collègue écrit dans fct_commandes.sql : « from silver.stg_erp__commandes ». Le modèle fonctionne en local. Quel est le principal problème ?",
  "options": [
    "dbt ignore la dépendance : ordre, lignage et environnement ne sont plus garantis",
    "Aucun : dbt détecte le nom de table et en déduit la même dépendance qu'avec ref()",
    "La requête sera plus lente, car dbt ne peut plus la mettre en cache entre deux runs",
    "DuckDB refuse les noms qualifiés par un schéma dans une clause from"
  ],
  "answer": 0,
  "explanation": "ref('stg_erp__commandes') déclare la dépendance dans le graphe : dbt construit le parent d'abord, l'affiche dans le lignage et résout le bon schéma selon la cible (dev, CI, prod). Un nom en dur contourne tout cela."
}
```

## 4. Matérialisations : view, table, incremental, ephemeral

| Matérialisation | Ce que dbt crée | Coût à chaque exécution | Quand l'utiliser |
|---|---|---|---|
| `view` | une vue SQL | quasi nul (calcul à la lecture) | staging, modèles légers |
| `table` | une table recalculée entièrement | proportionnel au volume total | marts de taille raisonnable, agrégats |
| `incremental` | une table complétée à chaque exécution | proportionnel aux **nouvelles** lignes | gros volumes (faits, événements, logs) |
| `ephemeral` | rien : le SQL est injecté en CTE dans les modèles enfants | — | logique intermédiaire réutilisée, non exposée |

Les **snapshots** (section 5) sont une cinquième famille, dédiée à l'historisation.

### 4.1 Le modèle incrémental

Un modèle incrémental contient deux comportements : à la **première** exécution (ou avec `--full-refresh`), il construit toute la table ; ensuite, la macro `is_incremental()` devient vraie et l'on filtre les seules lignes nouvelles ou modifiées. `{{ this }}` désigne la table déjà construite.

```sql
-- models/marts/fct_commandes.sql — fait au grain « une commande », incrémental et idempotent
{{
  config(
    materialized = 'incremental',
    unique_key = 'commande_id',
    incremental_strategy = 'delete+insert'
  )
}}

select
    c.commande_id,
    c.numero,
    c.client_id,
    c.agence_id,
    c.canal,
    c.statut,
    c.date_commande,
    c.montant_ht,
    c.mis_a_jour_le,
    cl.type_client,
    cl.segment
from {{ ref('stg_erp__commandes') }} as c
left join {{ ref('stg_erp__clients') }} as cl using (client_id)

{% if is_incremental() %}
  -- seules les commandes créées ou modifiées depuis la dernière exécution
  where c.mis_a_jour_le > (select coalesce(max(mis_a_jour_le), cast('1900-01-01' as timestamp)) from {{ this }})
{% endif %}
```

Le `unique_key` est ce qui rend le modèle **idempotent** : une commande déjà présente et modifiée est supprimée puis réinsérée (`delete+insert`), jamais dupliquée. Les stratégies disponibles dépendent de l'adaptateur (`append`, `delete+insert`, `merge`, `insert_overwrite`, `microbatch`…) ; vérifiez la liste dans la documentation de dbt-duckdb.

> ⚠️ **Piège fréquent** — Un modèle incrémental **sans** `unique_key` est en mode `append` : chaque rejeu recopie les lignes de la fenêtre. Et si vous changez la logique du modèle (nouvelle colonne, nouvelle règle), les lignes anciennes ne sont pas recalculées : lancez `dbt build --full-refresh --select fct_commandes`.

```sql
-- models/marts/ca_journalier_par_agence.sql — gold : prêt pour le tableau de bord de la direction
select
    cast(date_commande as date)  as jour,
    agence_id,
    sum(montant_ht)              as ca_ht,
    count(*)                     as nb_commandes
from {{ ref('fct_commandes') }}
where statut in ('validee', 'livree', 'facturee')     -- ni brouillons, ni annulations
group by all
```

```sql
-- models/marts/dim_client.sql — version courante ; l'historique est dans le snapshot (section 5)
select
    client_id,
    cast(code_client as varchar)  as code_client,
    cast(type_client as varchar)  as type_client,
    cast(segment as varchar)      as segment,
    cast(ville as varchar)        as ville,
    cast(agence_id as varchar)    as agence_id,
    cast(date_creation as date)   as date_creation
from {{ ref('stg_erp__clients') }}
```

```quiz
{
  "q": "Votre table d'événements de navigation grossit de 20 millions de lignes par jour et n'est jamais mise à jour. Quelle matérialisation choisir ?",
  "options": [
    "view, car elle ne coûte rien à construire ni à stocker",
    "table, recalculée entièrement chaque nuit à partir de la source",
    "ephemeral, pour ne rien stocker",
    "incremental, filtré par is_incremental() sur la date"
  ],
  "answer": 3,
  "explanation": "Une vue recalculerait des milliards de lignes à chaque lecture, une table complète chaque nuit coûterait de plus en plus cher. L'incrémental ne traite que les nouvelles lignes ; ephemeral n'est pas lisible par un tableau de bord. Le filtre porte sur la date d'événement."
}
```

## 5. Snapshots : l'historique des changements (SCD type 2)

Le client 17 déménage de Nantes à Saint-Herblain. Dans `dim_client`, la ville est simplement remplacée : impossible de savoir où il habitait quand il a passé sa commande de mars. Le **snapshot** conserve chaque version avec ses dates de validité : c'est la dimension à évolution lente de type 2 que vous avez écrite à la main en L154 (`valide_du` / `valide_au`), cette fois gérée par dbt.

```yaml
# snapshots/snap_clients.yml — syntaxe YAML des snapshots (dbt ≥ 1.9)
snapshots:
  - name: snap_clients
    relation: ref('stg_erp__clients')      # déjà minimisé : aucune donnée personnelle directe historisée
    config:
      schema: snapshots
      unique_key: client_id
      strategy: timestamp
      updated_at: mis_a_jour_le            # fiable grâce au déclencheur ajouté en L162
```

À chaque `dbt snapshot` (ou `dbt build`), dbt compare l'état courant aux versions enregistrées. Une ligne modifiée voit sa version précédente fermée (`dbt_valid_to` renseigné) et une nouvelle version ouverte (`dbt_valid_from`, `dbt_valid_to` nul). Sans colonne de mise à jour fiable, on utiliserait `strategy: check` avec `check_cols: [ville, segment, agence_id]`, plus coûteux car il compare les valeurs.

```bash
dbt snapshot
docker exec -it breval-postgres psql -U breval -d breval -c \
  "UPDATE erp.clients SET ville='Saint-Herblain', code_postal='44800' WHERE client_id=17;"
(cd .. && python ingestion/ingest.py) && dbt snapshot
python -c "import duckdb; print(duckdb.connect('../data/breval.duckdb').sql('SELECT client_id, ville, dbt_valid_from, dbt_valid_to FROM snapshots.snap_clients WHERE client_id=17'))"
```

> 💡 **Autrement dit** — Un snapshot, c'est l'album photo d'une table : on ne remplace jamais une photo, on en ajoute une nouvelle avec la date. Le snapshot doit tourner **régulièrement** : un changement qui apparaît et disparaît entre deux exécutions n'est jamais photographié.

## 6. Tests, unit tests et contrats

dbt propose trois niveaux de garde-fous, du plus simple au plus strict.

**Les tests de données génériques** se déclarent en YAML. Quatre sont intégrés : `unique`, `not_null`, `accepted_values`, `relationships`. Depuis dbt 1.10, leurs paramètres se placent sous `arguments`.

```yaml
# models/staging/_staging.yml
version: 2
models:
  - name: stg_erp__commandes
    columns:
      - name: commande_id
        data_tests: [unique, not_null]
      - name: statut
        data_tests:
          - accepted_values:
              arguments:
                values: ['brouillon', 'validee', 'livree', 'facturee', 'annulee']
      - name: agence_id
        data_tests:
          - accepted_values:
              arguments:
                values: ['NAN', 'STN', 'ANC']
      - name: client_id
        data_tests:
          - not_null
          - relationships:
              arguments:
                to: ref('stg_erp__clients')
                field: client_id
  - name: stg_erp__clients
    columns:
      - name: client_id
        data_tests: [unique, not_null]
```

**Un test singulier** est une requête qui renvoie les lignes **fautives** : le test échoue si elle renvoie au moins une ligne. Celui-ci attrape les années saisies « 206x » injectées volontairement dans le jeu (L151) ; on le règle en **avertissement** tant que la règle de correction n'est pas décidée avec le métier (M35).

```sql
-- tests/assert_dates_commande_plausibles.sql
{{ config(severity = 'warn') }}
select commande_id, numero, date_commande
from {{ ref('fct_commandes') }}
where date_commande < cast('2024-01-01' as timestamp)
   or date_commande > cast('2026-12-31' as timestamp)
```

**Les unit tests** (depuis dbt 1.8) vérifient la **logique** d'un modèle sur des données inventées, sans dépendre du contenu réel de l'entrepôt. **Les contrats** garantissent la **forme** d'un modèle (colonnes et types) : si une modification casse le contrat, la construction échoue avant d'atteindre les consommateurs.

```yaml
# models/marts/_marts.yml
version: 2
models:
  - name: dim_client
    description: "Un client par ligne, version courante, sans données personnelles directes."
    config:
      contract: {enforced: true}
    columns:
      - name: client_id
        data_type: bigint
        constraints: [{type: not_null}]
        data_tests: [unique]
      - name: code_client
        data_type: varchar
      - name: type_client
        data_type: varchar
      - name: segment
        data_type: varchar
      - name: ville
        data_type: varchar
      - name: agence_id
        data_type: varchar
      - name: date_creation
        data_type: date

  - name: ca_journalier_par_agence
    description: "CA HT par jour et par agence ; seules les commandes validées, livrées ou facturées comptent."

unit_tests:
  - name: ca_exclut_brouillons_et_annulations
    model: ca_journalier_par_agence
    given:
      - input: ref('fct_commandes')
        rows:
          - {commande_id: 1, agence_id: NAN, montant_ht: 100.00, statut: validee,   date_commande: "2026-11-03 10:00:00"}
          - {commande_id: 2, agence_id: NAN, montant_ht: 50.00,  statut: annulee,   date_commande: "2026-11-03 11:00:00"}
          - {commande_id: 3, agence_id: NAN, montant_ht: 30.00,  statut: brouillon, date_commande: "2026-11-03 12:00:00"}
          - {commande_id: 4, agence_id: STN, montant_ht: 80.00,  statut: facturee,  date_commande: "2026-11-03 09:00:00"}
    expect:
      rows:
        - {jour: 2026-11-03, agence_id: NAN, ca_ht: 100.00, nb_commandes: 1}
        - {jour: 2026-11-03, agence_id: STN, ca_ht: 80.00,  nb_commandes: 1}
```

```bash
dbt build                     # dans l'ordre du graphe : snapshots, modèles, tests, unit tests
dbt source freshness          # contrôle de fraîcheur du bronze
```

`dbt build` s'arrête en aval d'un test en échec : un `unique` qui échoue sur `stg_erp__commandes` empêche la construction de `fct_commandes`. C'est le comportement voulu, une donnée fausse ne se propage pas. Le test des dates, réglé en `warn`, signale la douzaine de dates aberrantes sans bloquer.

> 🔗 **Documentation officielle** — [dbt — Data tests](https://docs.getdbt.com/docs/build/data-tests) 🇬🇧 et [Source freshness](https://docs.getdbt.com/docs/deploy/source-freshness) 🇬🇧.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un unit test dbt échoue si la table réelle fct_commandes de Bréval contient des doublons.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. Un unit test remplace les entrées par les lignes déclarées dans given : il vérifie la logique SQL du modèle, pas le contenu réel. Les doublons réels sont détectés par un test de données (unique)."
}
```

## 7. Documentation et lignage

```bash
dbt docs generate     # produit target/catalog.json et target/manifest.json
dbt docs serve        # site local : descriptions, colonnes, tests et graphe de lignage
dbt ls --select +ca_journalier_par_agence   # tous les ancêtres d'un modèle
dbt ls --select stg_erp__clients+           # tous ses descendants (impact d'un changement)
```

Le **graphe de lignage** (*lineage graph*) montre, de gauche à droite, `erp.clients` → `stg_erp__clients` → `dim_client` / `snap_clients` / `fct_commandes` → `ca_journalier_par_agence`. Avant de modifier `stg_erp__clients`, un coup d'œil à `stg_erp__clients+` vous dit quels tableaux de bord vous risquez de casser. Le fichier `manifest.json` est aussi la matière première de la CI « slim » (L165) et de l'orchestration par Dagster (L164) : un modèle dbt y devient un *asset*.

```mission
{
  "title": "Le format de l'examen dbt Analytics Engineering",
  "url": "https://www.getdbt.com/certifications/analytics-engineer-certification-exam",
  "steps": ["Ouvrez la page officielle de la certification", "Repérez le format de l'examen", "Notez la version de dbt couverte et le seuil de réussite"],
  "question": "Combien de questions, quelle durée, quel seuil de réussite et quelle version de dbt ?",
  "hint": "Ces informations sont regroupées dans le bloc de présentation de l'examen.",
  "answer": "65 questions, 2 heures, 65 % de réussite, aligné sur dbt 1.11 (200 $, nov. 2026 — vérifiez, les conditions évoluent). Ce module prépare l'examen ; il ne s'y substitue pas (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Les cours gratuits de dbt Learn",
  "url": "https://www.getdbt.com/blog/new-learn-courses",
  "steps": ["Ouvrez l'annonce des nouveaux cours dbt Learn", "Repérez le cours d'introduction et sa durée", "Listez les cours avancés"],
  "question": "Quel est le cours gratuit d'introduction, combien de temps dure-t-il, et quels cours avancés sont cités ?",
  "hint": "Un cours porte sur Jinja, un autre sur les matérialisations.",
  "answer": "dbt Learn Fundamentals (environ 5 h, gratuit) ; puis Macros and Packages with Jinja, Advanced Materializations, Analyses and Seeds, Refactoring SQL for Modularity (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🎮 Défi : casser exprès

Faites échouer volontairement chaque garde-fou, un par un : passez dans l'ERP une commande au statut `rembourse`, puis une autre à `montant_ht = -10`, puis renommez la colonne `ville` en `commune` dans `stg_erp__clients`. Relancez l'ingestion et `dbt build` après chaque changement. Quel test, quel contrat ou quel unit test attrape chaque erreur ? Lequel ne l'attrape pas, et pourquoi ?

## 🧪 Exercice pratique

**Consigne** : complétez le projet `dbt_breval` avec :
1. le fait `fait_ventes` conçu en L154, au **grain de la ligne de commande** : incrémental sur `ligne_id` (clé unique `ligne_id`), avec `ca_ht = quantite * prix_unitaire_ht * (1 - remise_pct / 100)` et la dimension dégénérée `numero` ;
2. un mart `taux_tickets_par_agence` (nombre de tickets SAV ouverts / nombre de commandes, par agence et par mois) à partir de `stg_sav__tickets` ;
3. au moins **cinq** tests, dont un `relationships` entre `fait_ventes` et `fct_commandes`, un `accepted_values` sur la catégorie des tickets et un test singulier « la somme des lignes diffère de `montant_ht` de l'en-tête de plus de 1 € » ;
4. un unit test sur `taux_tickets_par_agence` ;
5. la documentation de chaque colonne de vos nouveaux modèles et la preuve d'idempotence : `dbt build` deux fois de suite, même `count(*)` pour `fait_ventes`.

**Critères de réussite** : `dbt build` termine sans erreur bloquante ; au moins 5 tests de données et 1 unit test passent (critère C5.2) ; le graphe de lignage affiche vos modèles ; le nombre de lignes ne change pas entre deux exécutions.

**Corrigé (pistes)** : le test singulier agrège `fait_ventes` par `commande_id`, joint `fct_commandes` et renvoie les lignes `where abs(somme_lignes - montant_ht) > 1` ; il **échoue** sur le jeu Bréval, qui contient volontairement des en-têtes saisis TTC au lieu de HT et des prix manquants (L151) : passez-le en `severity: warn` et documentez la décision, la correction relevant de la couche silver (L155, M35). Les prix nuls donnent un `ca_ht` nul : traitez-les explicitement (`coalesce` interdit sans règle métier !). Pour le taux, joignez deux agrégats par agence et par mois plutôt que tickets et commandes ligne à ligne, sinon vous multipliez les lignes.

## ✅ Auto-évaluation express
1. Que fait `is_incremental()` et quand renvoie-t-elle faux ?
2. Quelle différence entre un test de données, un unit test et un contrat ?
3. Quelle commande liste tous les modèles impactés par une modification de `stg_erp__clients` ?

**Réponses** : 1. Elle indique que la table existe déjà et que le modèle tourne en mode incrémental ; elle est fausse à la première exécution et avec `--full-refresh`. 2. Le test de données vérifie le contenu réel, l'unit test la logique sur des données inventées, le contrat la forme (colonnes et types) du résultat. 3. `dbt ls --select stg_erp__clients+`.

## 📚 Pour aller plus loin
- [dbt — documentation officielle](https://docs.getdbt.com/) 🇬🇧 — matérialisations, snapshots, unit tests, contrats.
- [dbt Learn — catalogue](https://learn.getdbt.com/catalog) 🇬🇧 — dbt Learn Fundamentals, gratuit.
- [dbt — Analytics Engineering Certification Exam](https://www.getdbt.com/certifications/analytics-engineer-certification-exam) 🇬🇧 — la certification à préparer après ce module (pratique de six mois recommandée par dbt Labs).
- Le module 4 « Analytics engineering » du [Data Engineering Zoomcamp](https://github.com/datatalksclub/data-engineering-zoomcamp) 🇬🇧 utilise aussi dbt et DuckDB.

> 🗺️ **Et maintenant ?** — Vous avez une ingestion (L162) et des transformations testées ; la leçon L164 les fait tourner toutes seules, dans le bon ordre, avec relances, rattrapage du passé et alertes, grâce à un orchestrateur.
