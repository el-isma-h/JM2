---
id: L165
module: M33
level: N5
title: "Atelier : pipeline dlt → DuckDB → dbt orchestré, avec CI « slim » sur les modèles modifiés"
minutes: 50
objectives:
  - "Assembler un dépôt de pipeline batch complet : ingestion dlt, transformations dbt testées, orchestration Dagster"
  - "Démontrer par un test automatisé qu'un rejeu complet du pipeline ne crée aucun doublon"
  - "Mettre en place une intégration continue qui ne construit et ne teste que les modèles dbt modifiés et leurs dépendances (sélecteur state:modified)"
  - "Évaluer son pipeline au regard des critères de la compétence C5.2"
skills: ["C5.2", "C5.6"]
sources:
  - { title: "dbt — documentation officielle", url: "https://docs.getdbt.com/", lang: "en" }
  - { title: "dbt — Source freshness", url: "https://docs.getdbt.com/docs/deploy/source-freshness", lang: "en" }
  - { title: "dlt (dltHub) — documentation", url: "https://dlthub.com/docs", lang: "en" }
  - { title: "Dagster — documentation", url: "https://docs.dagster.io/", lang: "en" }
  - { title: "dbt — guide d'étude de la certification (v1.11)", url: "https://www.getdbt.com/dbt-assets/certifications/dbt-certificate-study-guide-version-1-11", lang: "en" }
  - { title: "DataTalksClub — Data Engineering Zoomcamp", url: "https://github.com/datatalksclub/data-engineering-zoomcamp", lang: "en" }
---

# Atelier : pipeline dlt → DuckDB → dbt orchestré, avec CI « slim » sur les modèles modifiés

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 33

## 🎯 Ce que vous saurez faire
- Livrer un **dépôt Git** qui fait tourner, d'une seule commande, l'ingestion Postgres → DuckDB, les transformations dbt testées et l'orchestration Dagster.
- **Prouver** l'idempotence par un test automatisé, et non par une affirmation.
- Brancher une **CI « slim »** : à chaque demande de fusion (*pull request*), seuls les modèles dbt modifiés et ce qui en dépend sont reconstruits et testés.
- Vous auto-évaluer avec la grille de la compétence C5.2.

> 🧭 **En clair** — Dans les leçons précédentes, vous avez fabriqué chaque pièce d'une chaîne de montage : le tapis qui apporte les matières (dlt), les machines qui les transforment (dbt) et le contremaître qui lance tout dans l'ordre (Dagster). Aujourd'hui, on visse tout ensemble et on ajoute le contrôle qualité à l'entrée de l'usine : chaque fois qu'un ouvrier propose de modifier une machine, on teste **cette machine et celles qui en dépendent**, pas l'usine entière. C'est rapide, donc on le fait systématiquement.

## 1. Le dépôt final

Vous réutilisez le dossier `breval/` du niveau : M31 (Docker Compose, DDL `erp.*`, générateur `generer_breval.py`, `vers_bronze.py`), L162 (déclencheur, `ingest.py`), L163 (projet `dbt_breval`) et L164 (`orchestration/defs.py`). Il reste à ajouter le liant : dépendances, Makefile, test d'idempotence et CI.

```
breval/
├── docker-compose.yml                ← L151 (conteneur breval-postgres, wal_level=logical)
├── sql/01_ddl_erp.sql                ← L151 (schéma ERP de référence du niveau)
├── sql/02_trigger_mis_a_jour.sql     ← L162
├── generer_breval.py  vers_bronze.py ← L152 (jeu reproductible, graine 42)
├── requirements.txt
├── Makefile
├── ingestion/ingest.py               ← L162 (dlt, incrémental + merge)
├── dbt_breval/                       ← L163 (staging, marts, snapshot, tests, contrat, unit test)
├── orchestration/defs.py             ← L164 (Dagster)
├── tests_pipeline/test_idempotence.py
└── .github/workflows/dbt-ci-slim.yml ← à placer à la racine du dépôt Git
```

Ajoutez `data/` et `.venv/` à votre `.gitignore` : les données se **régénèrent** à l'identique avec le générateur de L152, elles n'ont rien à faire dans Git.

```text
# breval/requirements.txt — figez les versions exactes (pip freeze) une fois le pipeline validé
duckdb
polars
pyarrow
dlt[duckdb,sql_database]
psycopg2-binary
dbt-core
dbt-duckdb
dagster
dagster-webserver
dagster-dbt
requests
pytest
```

```makefile
# breval/Makefile — une commande par étape (les recettes commencent par une tabulation)
export BREVAL_PG_URL ?= postgresql://breval:breval_local@localhost:5432/breval
export BREVAL_DUCKDB_PATH ?= $(CURDIR)/data/breval.duckdb
DBT = cd dbt_breval && dbt

.PHONY: up trigger ingest transform pipeline freshness docs orchestrate test-idempotence

up:
	docker compose up -d
trigger:
	docker exec -i breval-postgres psql -U breval -d breval < sql/02_trigger_mis_a_jour.sql
ingest:
	python ingestion/ingest.py
transform:
	$(DBT) build --profiles-dir .
pipeline: ingest transform
freshness:
	$(DBT) source freshness --profiles-dir .
docs:
	$(DBT) docs generate --profiles-dir . && $(DBT) docs serve --profiles-dir .
orchestrate:
	dagster dev -f orchestration/defs.py
test-idempotence:
	pytest -q tests_pipeline/test_idempotence.py
```

```bash
cd breval
make up && make pipeline       # premier passage complet (ERP chargé en L152, déclencheur posé en L162)
make freshness                 # le bronze est-il frais ?
```

## 2. Prouver l'idempotence

L'idempotence est le premier critère de la compétence C5.2 : « un rejeu ne crée pas de doublon (idempotence démontrée) ». Démontrée signifie : un test que n'importe qui peut relancer.

```python
# breval/tests_pipeline/test_idempotence.py — pytest -q tests_pipeline/test_idempotence.py
import os
import subprocess
import sys
from pathlib import Path

import duckdb

RACINE = Path(__file__).resolve().parent.parent
DUCKDB_PATH = os.environ.get("BREVAL_DUCKDB_PATH", str(RACINE / "data" / "breval.duckdb"))
TABLES = ["bronze.commandes", "bronze.lignes_commande", "bronze.tickets_sav",
          "gold.fct_commandes", "gold.ca_journalier_par_agence"]

def executer_pipeline() -> None:
    env = {**os.environ, "BREVAL_DUCKDB_PATH": DUCKDB_PATH}
    subprocess.run([sys.executable, "ingestion/ingest.py"], check=True, cwd=RACINE, env=env)
    subprocess.run(["dbt", "build", "--profiles-dir", "."], check=True, cwd=RACINE / "dbt_breval", env=env)

def empreinte() -> dict[str, tuple]:
    """Nombre de lignes + somme de contrôle du contenu métier, par table."""
    con = duckdb.connect(DUCKDB_PATH, read_only=True)
    resultat = {}
    for t in TABLES:
        n = con.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
        colonnes = [c[0] for c in con.execute(f"DESCRIBE {t}").fetchall() if not c[0].startswith("_dlt")]
        somme = con.execute(
            f"SELECT sum(hash(concat_ws('|', {', '.join(colonnes)}))) FROM {t}"   # hors colonnes techniques dlt
        ).fetchone()[0]
        resultat[t] = (n, somme)
    con.close()
    return resultat

def test_rejeu_sans_doublon():
    executer_pipeline()
    avant = empreinte()
    executer_pipeline()          # rejeu complet, sans changement à la source
    apres = empreinte()
    assert apres == avant, f"Le rejeu a modifié les données : {avant} → {apres}"

def test_cles_uniques():
    con = duckdb.connect(DUCKDB_PATH, read_only=True)
    n, distincts = con.execute("SELECT count(*), count(DISTINCT commande_id) FROM gold.fct_commandes").fetchone()
    con.close()
    assert n == distincts
```

> ⚠️ **Piège fréquent** — Lancer ce test pendant que l'interface Dagster ou un notebook garde le fichier DuckDB ouvert en écriture : DuckDB n'autorise qu'**un seul processus écrivain** à la fois. Fermez les autres connexions, ou utilisez des fichiers distincts (`BREVAL_DUCKDB_PATH`) pour le test.

```quiz
{
  "q": "Votre test compare seulement count(*) avant et après le rejeu. Quelle erreur pourrait-il laisser passer ?",
  "options": [
    "Un doublon de clé primaire ajouté par le rejeu",
    "Une erreur de syntaxe SQL dans le modèle rejoué par l'orchestrateur",
    "Aucune : si le nombre de lignes est identique, le contenu l'est aussi",
    "Un doublon qui compense une suppression, ou un montant modifié"
  ],
  "answer": 3,
  "explanation": "Le nombre de lignes peut rester identique alors que le contenu a changé. Une somme de contrôle (hash des colonnes métier) détecte aussi les modifications de valeurs."
}
```

## 3. La CI « slim » : ne tester que ce qui a changé

Sur un vrai projet, `dbt build` complet peut prendre une heure. Lancer tout le projet à chaque *pull request* décourage les contributions. La CI « slim » s'appuie sur l'**état** de dbt : on compare le `manifest.json` de la branche proposée à celui de la branche principale, et le sélecteur `state:modified` ne retient que les nœuds dont le code ou la configuration ont changé.

| Sélecteur | Ce qu'il construit |
|---|---|
| `state:modified` | seulement les modèles modifiés |
| `state:modified+` | les modèles modifiés **et leurs descendants** (ce qu'une modification peut casser) |
| `+state:modified+` | en plus, leurs **ancêtres** (nécessaire si l'entrepôt de CI est vide) |

Avec un entrepôt **partagé** (Snowflake, BigQuery, Databricks, MotherDuck), la forme canonique est `dbt build --select state:modified+ --defer --state <artefacts_prod>` : `--defer` fait pointer les `ref()` des modèles non modifiés vers les tables de production, qu'on n'a donc pas à reconstruire. Dans notre atelier, la base DuckDB de CI est **éphémère** et vide : on construit donc `+state:modified+` sur un jeu de données de test, ce qui reste bien plus léger que le projet entier dès que celui-ci grandit.

```yaml
# .github/workflows/dbt-ci-slim.yml — à la racine du dépôt Git (le projet est dans breval/)
name: dbt-ci-slim
on:
  pull_request:
    paths: ["breval/dbt_breval/**", "breval/ingestion/**", "breval/sql/**"]

jobs:
  dbt-slim:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:17
        env: { POSTGRES_USER: breval, POSTGRES_PASSWORD: ci, POSTGRES_DB: breval }
        ports: ["5432:5432"]
        options: >-
          --health-cmd "pg_isready -U breval" --health-interval 5s
          --health-timeout 5s --health-retries 10
    env:
      BREVAL_PG_URL: postgresql://breval:ci@localhost:5432/breval
      BREVAL_DUCKDB_PATH: ${{ github.workspace }}/ci.duckdb
      PGPASSWORD: ci
    defaults:
      run: { working-directory: breval }
    steps:
      - uses: actions/checkout@v4                      # branche proposée
      - uses: actions/checkout@v4                      # branche principale, pour l'état de référence
        with: { ref: main, path: reference }
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install -r requirements.txt

      - name: Jeu de test Bréval réduit (5 %), reproductible
        run: |
          python generer_breval.py --echelle 0.05 --sortie data/raw
          python vers_bronze.py
      - name: ERP de test (DDL de L151 + données + déclencheur)
        run: |
          psql -h localhost -U breval -d breval -f sql/01_ddl_erp.sql
          mkdir -p data/pg
          for t in agences fournisseurs produits clients commandes lignes_commande; do
            python -c "import duckdb; duckdb.sql(\"COPY (SELECT DISTINCT * FROM 'data/bronze/$t.parquet' ORDER BY 1) TO 'data/pg/$t.csv' (HEADER)\")"
            psql -h localhost -U breval -d breval -c "\copy erp.$t FROM 'data/pg/$t.csv' CSV HEADER"
          done
          psql -h localhost -U breval -d breval -f sql/02_trigger_mis_a_jour.sql
      - name: Ingestion dlt
        run: python ingestion/ingest.py

      - name: État de référence (manifest.json de main)
        working-directory: reference/breval/dbt_breval
        run: |
          dbt parse --profiles-dir .
          mkdir -p "$GITHUB_WORKSPACE/etat-main"
          cp target/manifest.json "$GITHUB_WORKSPACE/etat-main/"

      - name: Lister les modèles modifiés
        working-directory: breval/dbt_breval
        run: dbt ls --select state:modified --state "$GITHUB_WORKSPACE/etat-main" --profiles-dir .

      - name: Construire et tester uniquement le périmètre impacté
        working-directory: breval/dbt_breval
        run: dbt build --select "+state:modified+" --state "$GITHUB_WORKSPACE/etat-main" --profiles-dir . --fail-fast
```

Le jeu de CI est généré par le même script que votre jeu local, avec la même graine : les tests voient les mêmes types de défauts volontaires (dates « 206x », en-têtes TTC…) que vous, à 5 % du volume, ce qui garde la CI rapide.

Pour la première *pull request*, la branche `main` ne contient pas encore de projet dbt : l'étape « État de référence » échoue. Fusionnez d'abord un projet minimal, ou ajoutez une condition qui lance un `dbt build` complet quand le manifest de référence est absent.

> 💡 **Autrement dit** — Le `manifest.json` est la photo de tout le projet dbt. La CI compare deux photos (main et votre branche) et ne reconstruit que ce qui diffère, plus ce qui en dépend.

> 🔗 **Documentation officielle** — [dbt — documentation](https://docs.getdbt.com/) 🇬🇧 : cherchez « state selection » et « defer ». Le thème « exploiter le *state* dbt » fait partie des sept thèmes de la certification dbt Analytics Engineering ([guide d'étude v1.11](https://www.getdbt.com/dbt-assets/certifications/dbt-certificate-study-guide-version-1-11)).

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : avec le sélecteur state:modified+, si vous modifiez stg_erp__clients, le mart ca_journalier_par_agence sera lui aussi reconstruit et testé.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai. Le « + » final ajoute les descendants : stg_erp__clients → fct_commandes (jointure pour type_client et segment) → ca_journalier_par_agence. C'est précisément le périmètre qu'une modification peut casser."
}
```

```mission
{
  "title": "Les seuils de fraîcheur d'une source dbt",
  "url": "https://docs.getdbt.com/docs/deploy/source-freshness",
  "steps": ["Ouvrez la page Source freshness de la documentation dbt", "Repérez la configuration d'exemple", "Notez les deux niveaux de seuil et la commande à lancer"],
  "question": "Quels sont les deux seuils de fraîcheur configurables pour une source, et quelle commande les vérifie ?",
  "hint": "L'un produit un avertissement, l'autre une erreur.",
  "answer": "warn_after et error_after (avec count et period), vérifiés par la commande dbt source freshness, qui s'appuie sur loaded_at_field (doc consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 4. Orchestration finale et grille d'auto-évaluation

Lancez `make orchestrate`, matérialisez tous les assets depuis l'interface Dagster, puis vérifiez la vue de lignage : `erp/clients`, `erp/commandes`, `erp/lignes_commande`, `sav/tickets_sav` à gauche, les modèles dbt au centre, `ca_journalier_par_agence` à droite. Provoquez un échec (`docker stop breval-postgres`) et vérifiez que le capteur d'échec émet l'alerte.

| Critère C5.2 (référentiel N5) | Preuve attendue | ✔ |
|---|---|---|
| Le pipeline s'exécute de bout en bout sur le jeu de test | `make up && make pipeline` sans erreur | |
| Un rejeu ne crée pas de doublon | `make test-idempotence` vert | |
| Au moins 5 tests dbt passent | sortie de `dbt build` (tests `unique`, `not_null`, `accepted_values`, `relationships`, test singulier, unit test) | |
| Les dépendances sont orchestrées avec alerte en cas d'échec | capture du graphe Dagster + message d'alerte | |
| (bonus) CI slim opérationnelle | une *pull request* qui ne reconstruit que le périmètre modifié | |

## 🎮 Défi : la PR piégée

Proposez dans une branche une modification de `stg_erp__commandes` qui renomme `montant_ht` en `montant`. Avant de pousser, prédisez : quels modèles la CI va-t-elle reconstruire, et quel garde-fou va échouer en premier ? Poussez, comparez avec votre prédiction.

## 🧪 Exercice pratique

**Consigne** : livrez le dépôt `breval` complet dans un dépôt Git personnel, avec :
1. un `README.md` de 15 lignes maximum (démarrage en 3 commandes, schéma du pipeline, commande de test) ;
2. le test d'idempotence vert ;
3. la CI slim qui passe sur une *pull request* modifiant **un seul** modèle mart, avec la sortie de `dbt ls --select state:modified` montrant ce seul modèle ;
4. un court paragraphe : combien de modèles la CI aurait-elle construits sans le sélecteur d'état, et combien avec ?

**Critères de réussite** : la grille de la section 4 est entièrement cochée ; la CI échoue bien quand on y introduit volontairement une erreur (statut inconnu, contrat cassé) ; aucun secret en clair dans le dépôt (mots de passe via variables d'environnement ou secrets du dépôt).

**Corrigé (pistes)** : sur notre petit projet (4 modèles de staging, 3 marts, 1 snapshot, sans compter vos ajouts de L163), la différence est modeste : une modification de `ca_journalier_par_agence` reconstruit ce mart et ses ancêtres (`+state:modified+`), soit 4 modèles (`stg_erp__commandes`, `stg_erp__clients`, `fct_commandes`, le mart) au lieu des 8 nœuds du projet, avec leurs seuls tests. Sur un projet de 300 modèles, le gain atteint souvent plus de 90 %. Pour le défi : `stg_erp__commandes`, `fct_commandes`, `ca_journalier_par_agence` (et le test singulier des dates) sont sélectionnés ; c'est la construction de `fct_commandes` qui échoue en premier (colonne `montant_ht` introuvable), avant même les tests.

## ✅ Auto-évaluation express
1. Quelle commande produit le `manifest.json` de référence sans rien construire ?
2. Pourquoi `--defer` ne sert-il à rien avec une base DuckDB de CI éphémère ?
3. Qu'apporte une somme de contrôle par rapport à un simple comptage dans un test d'idempotence ?

**Réponses** : 1. `dbt parse` (ou `dbt compile`). 2. Parce qu'il redirige les `ref()` vers des tables de production qui n'existent pas dans la base éphémère ; il faut un entrepôt partagé. 3. Elle détecte aussi les valeurs modifiées à nombre de lignes constant.

## 📚 Pour aller plus loin
- [dbt — documentation](https://docs.getdbt.com/) 🇬🇧 — sélection par état, `--defer`, *best practices* de CI.
- [dlt — documentation](https://dlthub.com/docs) 🇬🇧 — déploiement d'un pipeline dlt dans un orchestrateur.
- [Dagster — documentation](https://docs.dagster.io/) 🇬🇧 — intégration dbt et déploiement.
- [Data Engineering Zoomcamp](https://github.com/datatalksclub/data-engineering-zoomcamp) 🇬🇧 — projet final du cours, à comparer avec le vôtre.

> 🗺️ **Et maintenant ?** — Votre pipeline tourne une fois par nuit ; le module M34 passe à la vitesse supérieure avec le **streaming** : traiter chaque commande quelques secondes après sa création, en commençant par la façon de penser en flux (L166).
