---
id: L159
module: M32
level: N5
title: "Apache Spark et PySpark 4 : DataFrames, partitions, shuffle, jointures broadcast, AQE, Spark Connect"
minutes: 60
objectives:
  - "Expliquer l'architecture de Spark (driver, exécuteurs, tâches, étapes) et l'évaluation paresseuse des DataFrames"
  - "Distinguer transformations étroites et larges, et repérer les shuffles (Exchange) dans un plan physique"
  - "Appliquer et mesurer les optimisations clés : jointure broadcast, nombre de partitions de shuffle, exécution adaptative (AQE), gestion du déséquilibre (skew), cache"
  - "Écrire une table partitionnée en Parquet (ou Delta/Iceberg) en maîtrisant le nombre de fichiers"
  - "Utiliser Spark Connect pour piloter un serveur Spark depuis un client Python léger"
skills: ["C5.3"]
sources:
  - { title: "PySpark — Getting Started (doc latest, 4.3.0)", url: "https://spark.apache.org/docs/latest/api/python/getting_started/", lang: "en" }
  - { title: "Apache Spark — documentation", url: "https://spark.apache.org/docs/latest/", lang: "en" }
  - { title: "Apache Spark — SQL performance tuning (AQE, broadcast)", url: "https://spark.apache.org/docs/latest/sql-performance-tuning.html", lang: "en" }
  - { title: "Databricks — Learn, experiment and build with Free Edition", url: "https://www.databricks.com/blog/learn-experiment-and-build-databricks-free-edition", lang: "en" }
  - { title: "Databricks Certified Data Engineer Associate", url: "https://www.databricks.com/learn/certification/data-engineer-associate", lang: "en" }
  - { title: "Stanford CS246 — Info Handout 2025 (Colabs Spark)", url: "https://snap.stanford.edu/class/cs246-2025/WWW/handouts/CS246_Info_Handout.pdf", lang: "en" }
  - { title: "Berkeley CS186 — Introduction to Database Systems (MapReduce et Spark)", url: "https://cs186berkeley.net/sp25/", lang: "en" }
---

# Apache Spark et PySpark 4 : DataFrames, partitions, shuffle, broadcast, AQE, Spark Connect

> ⏱ 60 min · 🎯 Niveau 5 · 📚 Module 32

## 🎯 Ce que vous saurez faire
- Lancer Spark sur votre portable et y traiter les 3,4 millions de lignes de commande de Bréval à l'échelle 10.
- Lire un plan physique Spark et y trouver, en dix secondes, les shuffles qui coûtent cher.
- Rendre une jointure plusieurs fois plus rapide en diffusant (*broadcast*) la petite table, et le **mesurer**.
- Comprendre ce que fait l'exécution adaptative (AQE) à votre place, et quand l'aider.
- Piloter un serveur Spark à distance avec Spark Connect, comme le font les plateformes cloud.

> 🧭 **En clair** — Spark est un chef de chantier (le *driver*) qui dirige une équipe d'ouvriers (les *exécuteurs*). Quand vous lui donnez des instructions, il ne fait rien tout de suite : il note tout, réfléchit au meilleur plan, puis lance le travail seulement quand vous demandez un résultat. Chaque ouvrier traite sa part du tas (une *partition*). Le moment coûteux, c'est quand les ouvriers doivent s'échanger des matériaux d'un bout à l'autre du chantier (le *shuffle*). Tout l'art de Spark consiste à organiser le travail pour limiter ces échanges, par exemple en donnant à chaque ouvrier sa propre copie d'un petit plan plutôt que de faire circuler les gros matériaux.

## 1. Spark en quelques repères

Spark naît en **2009** à l'AMPLab de l'université de Berkeley (Matei Zaharia) pour dépasser MapReduce : garder les données **en mémoire** entre les étapes au lieu de tout réécrire sur disque. Il devient projet Apache de premier niveau en **2014** ; ses créateurs fondent Databricks en 2013. Les jalons utiles pour vous : l'API **DataFrame** et l'optimiseur Catalyst (Spark 2), l'**exécution adaptative** (AQE, introduite en Spark 3.0 et activée par défaut depuis la 3.2), **Spark Connect** (introduit en 3.4), puis la génération **Spark 4** (2025), qui active notamment le mode SQL ANSI par défaut et exige Java 17 ou plus. La documentation PySpark « latest » est en version **4.3.0** (nov. 2026) ; consultez ses notes de version pour le détail des nouveautés.

### 1.1 Architecture

```
          votre code PySpark
                 │
          ┌──────▼──────┐   plan logique ─▶ optimiseur Catalyst ─▶ plan physique
          │   DRIVER    │   découpe le job en ÉTAPES (stages) séparées par les shuffles
          └──┬───┬───┬──┘   et chaque étape en TÂCHES (une par partition)
             │   │   │
     ┌───────▼┐ ┌▼───────┐ ┌▼───────┐
     │EXÉCUTEUR│ │EXÉCUTEUR│ │EXÉCUTEUR│   chaque exécuteur traite des tâches en parallèle
     │ cœurs   │ │ cœurs   │ │ cœurs   │   et échange des données lors des shuffles
     └─────────┘ └─────────┘ └─────────┘
```

En mode local (`local[*]`), driver et exécuteurs vivent dans le même processus Java de votre machine, avec un *thread* par cœur : idéal pour apprendre, inutile pour des données qui tiennent dans DuckDB (L160).

### 1.2 Installer et préparer les données

```bash
java -version                     # Spark 4 : Java 17 ou 21 requis
pip install "pyspark[sql]"       # pour écrire en Delta/Iceberg depuis Spark, suivez la configuration de leur doc
# Données : copie du dossier breval/ générée à l'échelle 10 (chaîne complète de L155)
cp -r breval breval-x10 && cd breval-x10
python generer_breval.py --echelle 10 && python vers_bronze.py && python vers_silver.py
```

À l'échelle 10, silver contient environ 1,2 million de commandes et 3,3 millions de lignes. Ce n'est pas du « big data » (DuckDB le traite en une seconde), mais c'est assez pour **voir** les mécanismes de Spark et mesurer leurs effets.

> 💡 **À retenir** — On apprend Spark sur de petites données pour comprendre ses mécanismes ; on ne l'adopte en production que quand les données ou le partage du calcul l'exigent. L160 vous donne les critères.

## 2. DataFrames et évaluation paresseuse

```python
# breval-x10/spark_ventes.py
import time
from pyspark.sql import SparkSession, functions as F

spark = (SparkSession.builder
         .appName("breval-ventes")
         .master("local[*]")
         .config("spark.sql.shuffle.partitions", "200")       # valeur par défaut, conservée pour l'expérience
         .config("spark.driver.memory", "4g")
         .getOrCreate())
spark.sparkContext.setLogLevel("WARN")

lignes = spark.read.parquet("data/silver/lignes_commande.parquet")
commandes = spark.read.parquet("data/silver/commandes.parquet")
produits = spark.read.parquet("data/silver/produits.parquet")
lignes.printSchema()

ca = (lignes
      .join(commandes.where(F.col("statut").isin("livree", "facturee")), "commande_id")
      .join(produits.select("produit_id", "famille"), "produit_id")
      .withColumn("ca_ht", F.col("quantite") * F.col("prix_unitaire_ht") * (1 - F.col("remise_pct") / 100))
      .groupBy("agence_id", "famille")
      .agg(F.round(F.sum("ca_ht"), 2).alias("ca_ht"), F.countDistinct("commande_id").alias("nb_commandes")))
# Rien n'a encore été calculé : `ca` n'est qu'un plan.
ca.explain(mode="formatted")

t0 = time.perf_counter()
resultat = ca.orderBy("agence_id", "famille").collect()     # ACTION : le calcul démarre ici
print(f"{len(resultat)} groupes en {time.perf_counter() - t0:.1f} s")
```

Les méthodes `where`, `join`, `withColumn`, `groupBy` sont des **transformations** : elles construisent un plan. `collect`, `count`, `show`, `write` sont des **actions** : elles déclenchent l'exécution. Ouvrez l'interface web de Spark sur `http://localhost:4040` pendant l'exécution : onglets *Jobs*, *Stages* (une étape par portion de plan sans shuffle) et *SQL / DataFrame* (le plan annoté avec le nombre de lignes et le temps de chaque opérateur).

| Transformation **étroite** (*narrow*) | Transformation **large** (*wide*) |
|---|---|
| chaque partition de sortie dépend d'une seule partition d'entrée | une partition de sortie dépend de **plusieurs** partitions d'entrée |
| `select`, `where`, `withColumn`, `union` | `groupBy`, `join` (sauf broadcast), `orderBy`, `distinct`, `repartition` |
| pas d'échange réseau | **shuffle** (`Exchange` dans le plan) : écriture, réseau, tri |

```quiz
{
  "q": "Parmi ces opérations PySpark, laquelle déclenche réellement un calcul ?",
  "options": ["df.where(F.col(\"statut\") == \"livree\")", "df.groupBy(\"agence_id\").agg(F.sum(\"ca_ht\"))", "df.write.parquet(\"sortie/\")", "df.withColumn(\"annee\", F.year(\"date_commande\"))"],
  "answer": 2,
  "explanation": "where, groupBy/agg et withColumn sont des transformations paresseuses qui enrichissent le plan. L'écriture est une action : Spark optimise alors le plan complet et lance les tâches."
}
```

## 3. Lire le plan : où sont les shuffles ?

Dans la sortie de `explain(mode="formatted")`, repérez :

- `Scan parquet` avec `ReadSchema` (colonnes lues : projection poussée) et `PushedFilters` (filtres poussés vers Parquet, par exemple `In(statut, [facturee, livree])`) ;
- `Exchange hashpartitioning(commande_id, 200)` : un **shuffle** qui redistribue les lignes par clé de jointure en 200 partitions ;
- `BroadcastExchange` + `BroadcastHashJoin` : la petite table est **copiée** sur chaque exécuteur, sans shuffle de la grande ;
- `SortMergeJoin` : jointure par tri des deux côtés après shuffle, la stratégie des grandes tables ;
- `HashAggregate` en deux temps (partiel puis final, séparés par un `Exchange`) : Spark pré-agrège **avant** le shuffle, exactement comme un *combiner* MapReduce ;
- `AdaptiveSparkPlan isFinalPlan=false` : le plan sera revu en cours d'exécution par AQE.

Comme `produits` est minuscule (1 200 lignes), Spark choisit déjà un broadcast : en dessous du seuil `spark.sql.autoBroadcastJoinThreshold` (10 Mo par défaut), la diffusion est automatique.

> 💡 **Autrement dit** — Chaque `Exchange` du plan est un moment où toutes les données concernées traversent le « chantier ». Moins il y en a, et moins ils transportent de lignes, plus le job est rapide.

## 4. Mesurer les optimisations

```python
# breval-x10/spark_experiences.py — à lancer après spark_ventes.py (mêmes imports et DataFrames)
def chrono(nom: str, df) -> float:
    t0 = time.perf_counter(); df.write.format("noop").mode("overwrite").save()   # exécute sans rien écrire
    duree = time.perf_counter() - t0
    print(f"{nom:45s} {duree:6.2f} s"); return duree

requete = lambda: (lignes.join(commandes, "commande_id").join(produits, "produit_id")
                   .groupBy("agence_id", "famille").agg(F.sum("quantite").alias("q")))

# A. Référence : AQE activée, broadcast automatique
chrono("A. AQE + broadcast auto", requete())

# B. Sans broadcast ni AQE : SortMergeJoin partout et 200 partitions de shuffle
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")
spark.conf.set("spark.sql.adaptive.enabled", "false")
chrono("B. sans broadcast, sans AQE, 200 partitions", requete())

# C. Toujours sans AQE, mais nombre de partitions adapté à la machine (≈ 2 à 4 × nb de cœurs)
spark.conf.set("spark.sql.shuffle.partitions", str(4 * spark.sparkContext.defaultParallelism))
chrono("C. sans AQE, partitions ajustées", requete())

# D. Broadcast explicite de la petite table (indice donné à l'optimiseur)
chrono("D. broadcast explicite de produits",
       lignes.join(commandes, "commande_id").join(F.broadcast(produits), "produit_id")
             .groupBy("agence_id", "famille").agg(F.sum("quantite").alias("q")))

# Retour aux réglages par défaut
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", str(10 * 1024 * 1024))
spark.conf.set("spark.sql.shuffle.partitions", "200")
```

Notez vos quatre temps. Vous devriez observer que B est le plus lent (deux jointures par tri + 200 petites tâches par shuffle pour quelques centaines de Mo), que C rattrape une partie du retard en réduisant le nombre de tâches, et que A et D sont les plus rapides. Ce sont **vos** mesures qui comptent : écrivez-les dans votre dossier, elles constituent le « gain mesuré » exigé par la compétence C5.3.

### 4.1 Ce que fait l'AQE pour vous

L'**exécution adaptative** (*Adaptive Query Execution*) réoptimise le plan **entre deux étapes**, à partir des statistiques réelles des données déjà calculées :

| Fonction AQE | Problème résolu | Paramètre |
|---|---|---|
| Fusion des partitions de shuffle | 200 partitions minuscules après un filtre sélectif | `spark.sql.adaptive.coalescePartitions.enabled` |
| Conversion en broadcast | une table devenue petite après filtrage | (automatique quand AQE est active) |
| Gestion du déséquilibre (*skew*) | une clé énorme qui retient une seule tâche pendant des minutes | `spark.sql.adaptive.skewJoin.enabled` |

Le **déséquilibre** se produit typiquement avec un client « COMPTOIR ANONYME » qui regrouperait 30 % des ventes : la tâche qui traite cette clé dure dix fois plus que les autres. Dans l'onglet *Stages*, cela se voit à une tâche dont la durée maximale écrase la médiane. L'AQE découpe alors la partition fautive ; à défaut, on « sale » la clé (*salting* : ajout d'un suffixe aléatoire puis double agrégation).

> ⚠️ **Piège fréquent** — Forcer `F.broadcast()` sur une table « petite » qui ne l'est plus. Si la table diffusée fait plusieurs Go, le driver et chaque exécuteur doivent la tenir en mémoire : erreur `OutOfMemory` ou délai d'attente du broadcast. Le broadcast est fait pour les dimensions (produits, agences, calendrier), pas pour les faits.

```quiz
{
  "q": "Dans l'onglet Stages, 199 tâches durent 2 secondes et une seule dure 3 minutes, toujours sur la même jointure par client_id. Quel est le diagnostic le plus probable ?",
  "options": ["Un déséquilibre (skew) : un client_id concentre trop de lignes", "Le cache mémoire des exécuteurs est saturé", "La table produits est trop grande pour être diffusée en broadcast", "Le fichier Parquet est corrompu"],
  "answer": 0,
  "explanation": "Une tâche beaucoup plus longue que les autres sur une même étape de jointure signale une partition surchargée par une clé dominante. L'AQE (skewJoin) ou le salting répartissent cette clé sur plusieurs tâches."
}
```

## 5. Partitions en mémoire, partitions sur disque

Deux notions portent le même nom, ne les confondez pas :

- les **partitions en mémoire** : morceaux de DataFrame traités par une tâche (`df.repartition(n)` les redistribue avec un shuffle ; `df.coalesce(n)` en fusionne sans shuffle) ;
- les **partitions sur disque** : dossiers `annee=2025/` créés par `partitionBy` à l'écriture (L156).

```python
# Une table de faits partitionnée par année, avec un nombre maîtrisé de fichiers par dossier
faits = (lignes.join(commandes.select("commande_id", "date_commande", "agence_id", "statut"), "commande_id")
               .withColumn("annee", F.year("date_commande")))
(faits.repartition("annee")                          # une partition mémoire par année -> un fichier par dossier
      .write.mode("overwrite").partitionBy("annee")
      .parquet("lakehouse/spark/fait_lignes"))
print(spark.read.parquet("lakehouse/spark/fait_lignes").where("annee = 2025").count())

# Le cache : utile seulement si le même DataFrame est réutilisé par plusieurs actions
commandes_utiles = commandes.where(F.col("statut").isin("livree", "facturee")).cache()
commandes_utiles.count()                             # matérialise le cache
```

Sans `repartition("annee")`, chaque tâche écrirait un fichier dans **chaque** dossier d'année qu'elle rencontre : avec 200 tâches et 3 années, jusqu'à 600 petits fichiers. Pour des tables Delta ou Iceberg, la même écriture se fait avec `.format("delta")` ou via le catalogue Iceberg configuré (L157), et la compaction (`OPTIMIZE`) corrige les petits fichiers a posteriori.

```mission
{
  "title": "Les quickstarts de la documentation PySpark",
  "url": "https://spark.apache.org/docs/latest/api/python/getting_started/",
  "steps": ["Ouvrez la page « Getting Started » de la documentation PySpark", "Notez le numéro de version affiché", "Listez les guides de démarrage rapide proposés"],
  "question": "Quelle version de PySpark la documentation « latest » affiche-t-elle, et quels quickstarts sont proposés ?",
  "hint": "L'un d'eux concerne le client léger présenté en section 6.",
  "answer": "PySpark 4.3.0 (nov. 2026) ; Installation, Quickstart DataFrame, Quickstart Spark Connect, Quickstart Pandas API on Spark, Testing PySpark — la version « latest » évolue à chaque publication (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 6. Spark Connect : un client léger pour un serveur distant

Historiquement, le programme PySpark **était** le driver : il devait tourner à côté du cluster, avec la bonne version de Java et de Spark. **Spark Connect** sépare les deux : le client Python envoie des plans (au format protobuf, via gRPC) à un **serveur Spark Connect**, qui les exécute et renvoie les résultats en Arrow. Avantages : client léger (un notebook, une application, un IDE), mises à jour du serveur indépendantes des clients, isolation des sessions. C'est le mécanisme utilisé par de nombreuses plateformes managées.

```bash
# Côté serveur (distribution Spark 4 téléchargée depuis spark.apache.org) — port par défaut 15002
$SPARK_HOME/sbin/start-connect-server.sh
# Côté client : PySpark avec le support Connect (voir le « Quickstart Spark Connect » pour le paquet exact)
pip install "pyspark[connect]"
```

```python
from pyspark.sql import SparkSession
spark = SparkSession.builder.remote("sc://localhost:15002").getOrCreate()
df = spark.read.parquet("/chemin/vu/par/le/serveur/data/silver/commandes.parquet")
df.groupBy("agence_id").count().show()      # l'API DataFrame est la même
```

> ⚠️ **Piège fréquent** — En Spark Connect, il n'y a **pas** d'accès aux RDD ni au `SparkContext` côté client (`df.rdd`, `spark.sparkContext` échouent), et les chemins de fichiers sont ceux **du serveur**. Écrivez votre code avec l'API DataFrame/SQL uniquement : il fonctionnera dans les deux modes.

Pour passer à un vrai cluster sans frais, **Databricks Free Edition** donne un accès gratuit, sans limite de durée, à un environnement Spark managé (notebooks, SQL, jobs) : chargez-y les Parquet silver de Bréval et relancez les expériences de la section 4.

## 🧪 Exercice pratique

**Consigne** — (1) Exécutez `spark_ventes.py` et `spark_experiences.py` à l'échelle 10 ; consignez les quatre temps et une capture du plan B et du plan A annotés (où sont les `Exchange` ?). (2) Simulez un déséquilibre : réaffectez 30 % des commandes à un même `client_id`, joignez avec la table `clients` silver, et comparez la durée de l'étape avec `spark.sql.adaptive.skewJoin.enabled` à `true` puis `false`. (3) Écrivez `fait_lignes` partitionné par année et comptez les fichiers par dossier, avec et sans `repartition("annee")`. (4) Relancez la requête de la section 2 via Spark Connect.

**Critères de réussite** — Le tableau des temps est complété et commenté ; chaque `Exchange` des plans est expliqué ; l'effet de l'AQE sur le skew est mesuré (durée maximale de tâche) ; le nombre de fichiers passe de plusieurs dizaines à un par dossier.

**Pistes de corrigé** — Pour (2) : `commandes.withColumn("client_id", F.when(F.rand(42) < 0.3, F.lit(1)).otherwise(F.col("client_id")))`. Désactivez le broadcast (`autoBroadcastJoinThreshold = -1`), sinon il n'y a pas de shuffle à déséquilibrer. À cette petite échelle, abaissez aussi les seuils de détection, prévus pour de gros volumes : `spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes` et `spark.sql.adaptive.advisoryPartitionSizeInBytes` à quelques Mo (valeurs par défaut et noms exacts : page *SQL performance tuning*). Dans l'onglet *Stages*, comparez la colonne *Max* de la durée des tâches : avec l'AQE, la partition déséquilibrée est découpée en plusieurs tâches.

## ✅ Auto-évaluation express
1. Quelle différence entre une transformation et une action ?
2. Pourquoi une jointure broadcast évite-t-elle un shuffle de la grande table ?
3. Que change Spark Connect pour le code client ?

**Réponses** — 1. Une transformation ajoute une étape au plan sans rien calculer ; une action (collect, count, write) déclenche l'optimisation et l'exécution. 2. La petite table est copiée sur chaque exécuteur : chaque partition de la grande table trouve localement ses correspondances, sans redistribuer la grande table par clé. 3. Le client n'est plus le driver : il envoie des plans à un serveur distant ; seule l'API DataFrame/SQL est disponible (pas de RDD ni de SparkContext), et les chemins sont résolus côté serveur.

## 📚 Pour aller plus loin
- [PySpark — Getting Started](https://spark.apache.org/docs/latest/api/python/getting_started/) 🇬🇧 — installation, quickstarts DataFrame et Spark Connect, notebooks « live ».
- [Spark — SQL performance tuning](https://spark.apache.org/docs/latest/sql-performance-tuning.html) 🇬🇧 — AQE, indices de jointure, partitions de shuffle.
- [Databricks Free Edition](https://www.databricks.com/blog/learn-experiment-and-build-databricks-free-edition) 🇬🇧 — un Spark managé gratuit pour pratiquer.
- [Databricks Certified Data Engineer Associate](https://www.databricks.com/learn/certification/data-engineer-associate) 🇬🇧 — certification qui s'appuie largement sur Spark et Delta (guide d'août 2026).
- [Stanford CS246](https://snap.stanford.edu/class/cs246-2025/WWW/handouts/CS246_Info_Handout.pdf) 🇬🇧 et [Berkeley CS186](https://cs186berkeley.net/sp25/) 🇬🇧 — cours universitaires avec Spark (sources d'inspiration).

> 🗺️ **Et maintenant ?** — Spark est puissant, mais il a un coût (JVM, cluster, réglages) ; L160 vous montre jusqu'où vont Polars, DuckDB, Dask et Ray sur une seule machine, et vous donne une grille pour décider quand Spark vaut vraiment la peine.
