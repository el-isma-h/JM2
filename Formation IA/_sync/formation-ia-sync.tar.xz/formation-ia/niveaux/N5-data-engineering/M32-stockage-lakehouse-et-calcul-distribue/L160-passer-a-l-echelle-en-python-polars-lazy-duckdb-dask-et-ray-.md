---
id: L160
module: M32
level: N5
title: "Passer à l'échelle en Python : Polars lazy, DuckDB, Dask et Ray — quand ne pas utiliser Spark"
minutes: 50
objectives:
  - "Appliquer l'API lazy de Polars (scan, optimisation, moteur streaming) et lire son plan optimisé"
  - "Configurer DuckDB pour des données plus grandes que la mémoire (limite mémoire, débordement sur disque, parallélisme)"
  - "Expliquer le positionnement de Dask et de Ray (dont Ray Data pour l'inférence par lots) par rapport à Spark"
  - "Mesurer les performances de six moteurs sur une même requête et évaluer le choix d'un moteur selon une grille (volume, latence, coût, partage, compétences)"
skills: ["C5.3", "C5.1"]
sources:
  - { title: "DuckDB 2.0 — Integration with Polars", url: "https://duckdb.org/docs/2.0/guides/python/polars.html", lang: "en" }
  - { title: "Polars — documentation", url: "https://docs.pola.rs/", lang: "en" }
  - { title: "DuckDB — documentation", url: "https://duckdb.org/docs/", lang: "en" }
  - { title: "Dask — documentation", url: "https://docs.dask.org/", lang: "en" }
  - { title: "Ray — Working with LLMs (Ray Data)", url: "https://docs.ray.io/en/latest/data/working-with-llms.html", lang: "en" }
  - { title: "Ray — Offline batch inference", url: "https://docs.ray.io/en/latest/data/batch_inference.html", lang: "en" }
  - { title: "PySpark — Getting Started", url: "https://spark.apache.org/docs/latest/api/python/getting_started/", lang: "en" }
---

# Passer à l'échelle en Python : Polars lazy, DuckDB, Dask et Ray

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 32

## 🎯 Ce que vous saurez faire
- Traiter 17 millions de lignes de commande de Bréval sur un portable de 8 Go, sans cluster.
- Faire lire à Polars uniquement les colonnes et les lignes utiles, et le prouver par son plan.
- Faire déborder DuckDB sur disque au lieu de planter quand la mémoire manque.
- Savoir à quoi servent Dask et Ray, et pourquoi Ray revient dans les pipelines d'IA.
- Défendre, chiffres à l'appui, la phrase : « ici, nous n'avons pas besoin de Spark ».

> 🧭 **En clair** — Pour déménager un studio, on ne loue pas un semi-remorque avec trois déménageurs : une camionnette et un ami suffisent, et on part plus vite. Spark est le semi-remorque : formidable pour un château, encombrant pour un studio. Polars et DuckDB sont des camionnettes très bien conçues, qui utilisent tous les cœurs de votre ordinateur et savent ne charger que ce qui sert. Dask et Ray sont des sociétés de déménagement « à la demande » qui ajoutent des camionnettes quand le volume grossit, en restant en Python. Le bon choix dépend du volume… mais aussi du nombre de personnes qui doivent partager le camion.

## 1. Préparer un jeu plus gros

```bash
# Copie dédiée, à l'échelle 50 : ≈ 4 min de génération, ≈ 1,6 Go de fichiers bruts, ≈ 17 M de lignes de commande.
# Le générateur garde les 6 M d'en-têtes de commande en mémoire : prévoyez ≈ 5 Go de RAM libre (sinon --echelle 25).
cp -r breval breval-x50 && cd breval-x50
python generer_breval.py --echelle 50 && python vers_bronze.py && python vers_silver.py
```

Si la machine peine sur `vers_silver.py` (fonctions de fenêtre sur 17 M de lignes), c'est déjà une information : appliquez la section 3 (limite mémoire et débordement de DuckDB) avant de relancer.

## 2. Polars : l'API lazy

Polars (DataFrames écrits en Rust, modèle mémoire Arrow) a deux modes. En mode **eager** (`pl.read_parquet`), chaque instruction s'exécute immédiatement, comme pandas. En mode **lazy** (`pl.scan_parquet`), Polars construit un plan, l'**optimise** (projection et filtres poussés vers la lecture, simplification des expressions, ordre des jointures), puis l'exécute à `collect()`.

```python
# breval-x50/polars_lazy.py
import time
import polars as pl

lignes = pl.scan_parquet("data/silver/lignes_commande.parquet")
commandes = pl.scan_parquet("data/silver/commandes.parquet")
produits = pl.scan_parquet("data/silver/produits.parquet")

requete = (lignes
           .join(commandes.filter(pl.col("statut").is_in(["livree", "facturee"])), on="commande_id")
           .join(produits.select("produit_id", "famille"), on="produit_id")
           .filter(pl.col("date_commande").dt.year() == 2026)
           .group_by("agence_id", "famille")
           .agg((pl.col("quantite") * pl.col("prix_unitaire_ht") * (1 - pl.col("remise_pct") / 100))
                .sum().alias("ca_ht"))
           .sort("agence_id", "famille"))

print(requete.explain())                 # plan OPTIMISÉ : regardez les colonnes lues et la sélection poussée

for moteur in ["in-memory", "streaming"]:
    t0 = time.perf_counter()
    resultat = requete.collect(engine=moteur)
    print(f"Polars lazy ({moteur}) : {time.perf_counter() - t0:.2f} s, {resultat.height} groupes")
```

Dans le plan, vous devez voir pour chaque `Parquet SCAN` un nombre de colonnes lues inférieur au total (« PROJECT 4/9 COLUMNS » ou équivalent) et le filtre sur `statut` placé **dans** la lecture des commandes. Le moteur **streaming** traite les données par morceaux : il permet des calculs sur des volumes supérieurs à la mémoire, au prix parfois d'un peu de vitesse. Les noms des options d'exécution ont évolué au fil des versions : vérifiez `collect` dans la documentation de votre version de Polars.

> 💡 **À retenir** — Écrivez du Polars **lazy par défaut** (`scan_*` … `collect()`), et `sink_parquet()` pour écrire un résultat trop gros pour la mémoire sans jamais le matérialiser entièrement.

> ⚠️ **Piège fréquent** — Convertir en pandas (`.to_pandas()`) ou appeler `.collect()` au milieu de la chaîne « pour voir ». Chaque `collect` intermédiaire matérialise tout et casse l'optimisation globale. Pour inspecter, utilisez `.head(5).collect()` ou `.explain()`.

```quiz
{
  "q": "Pourquoi `pl.scan_parquet(...).filter(...).select(...).collect()` est-il souvent bien plus économe en mémoire que `pl.read_parquet(...).filter(...).select(...)` ?",
  "options": ["Parce que scan_parquet garde les données compressées en mémoire jusqu'au collect", "Parce que read_parquet n'utilise qu'un seul cœur, contrairement à scan_parquet", "Parce que collect écrit le résultat sur disque au lieu de le garder en mémoire", "Parce que filtre et colonnes sont poussés dans la lecture : seul l'utile est chargé"],
  "answer": 3,
  "explanation": "En mode eager, read_parquet charge tout le fichier avant de filtrer. En mode lazy, Polars voit la requête entière et ne lit que les colonnes et row groups nécessaires (projection et predicate pushdown)."
}
```

## 3. DuckDB : plus grand que la mémoire

DuckDB exécute en flux et peut **déborder sur disque** (*spill*) les opérateurs gourmands (jointures, agrégations, tris) quand la mémoire allouée est atteinte.

```python
# breval-x50/duckdb_echelle.py
import time
import duckdb

con = duckdb.connect()
con.execute("SET memory_limit = '2GB'")                 # simulez une petite machine
con.execute("SET temp_directory = 'tmp_duckdb'")         # où déborder
con.execute("SET preserve_insertion_order = false")      # moins de mémoire quand l'ordre n'importe pas
print(con.sql("SELECT current_setting('threads') AS threads, current_setting('memory_limit') AS memoire"))

t0 = time.perf_counter()
print(con.sql("""
    SELECT c.agence_id, p.famille, round(sum(l.quantite * l.prix_unitaire_ht * (1 - l.remise_pct / 100)), 2) AS ca_ht
    FROM 'data/silver/lignes_commande.parquet' l
    JOIN 'data/silver/commandes.parquet' c USING (commande_id)
    JOIN 'data/silver/produits.parquet'  p USING (produit_id)
    WHERE c.statut IN ('livree', 'facturee') AND year(c.date_commande) = 2026
    GROUP BY ALL ORDER BY ALL""").fetchall()[:3])
print(f"DuckDB : {time.perf_counter() - t0:.2f} s")

# Interopérabilité : DuckDB interroge un LazyFrame Polars par son nom et renvoie du Polars
import polars as pl
commandes_pl = pl.scan_parquet("data/silver/commandes.parquet")
print(con.sql("SELECT canal, count(*) AS n FROM commandes_pl GROUP BY ALL").pl())
```

Une jointure qui déborde est plus lente mais **termine** ; c'est souvent la différence entre « ça marche sur mon portable » et « il faut un cluster ».

## 4. Dask et Ray : distribuer du Python

| Outil | Idée | Point fort | À surveiller |
|---|---|---|---|
| **Dask** | parallélise les API pandas et NumPy en découpant les données en morceaux, sur une machine ou un cluster | migration douce de code pandas existant ; tableau de bord de suivi | performances inférieures à Polars/DuckDB sur une seule machine pour le SQL analytique |
| **Ray** | moteur de calcul distribué Python généraliste (tâches, acteurs) ; **Ray Data** pour les pipelines de données | traitements mêlant CPU et **GPU** : préparation de corpus, **inférence par lots**, embeddings | pas un moteur SQL ; exploitation d'un cluster |

```python
# breval-x50/dask_ventes.py — pip install "dask[dataframe,distributed]"
import time
import dask.dataframe as dd
from dask.distributed import Client

if __name__ == "__main__":
    client = Client()                                # cluster local ; tableau de bord affiché par print(client)
    print(client)
    t0 = time.perf_counter()
    lignes = dd.read_parquet("data/silver/lignes_commande.parquet",
                             columns=["commande_id", "produit_id", "quantite", "prix_unitaire_ht", "remise_pct"])
    commandes = dd.read_parquet("data/silver/commandes.parquet", columns=["commande_id", "agence_id", "statut"])
    jointe = lignes.merge(commandes[commandes.statut.isin(["livree", "facturee"])], on="commande_id")
    jointe["ca_ht"] = (jointe.quantite.astype("float64") * jointe.prix_unitaire_ht.astype("float64")
                       * (1 - jointe.remise_pct.astype("float64") / 100))
    print(jointe.groupby("agence_id").ca_ht.sum().compute())
    print(f"Dask : {time.perf_counter() - t0:.2f} s")
```

```python
# breval-x50/ray_lot.py — pip install "ray[data]" ; un traitement par lots Python sur les tickets SAV
import ray

ray.init()
tickets = ray.data.read_parquet("data/silver/tickets_sav.parquet", columns=["ticket_id", "categorie", "messages"])

def longueur_premier_message(lot):                  # lot = DataFrame pandas (batch_format="pandas")
    lot["longueur"] = lot["messages"].map(lambda m: len(m[0]["texte"]) if len(m) else 0)
    return lot[["ticket_id", "categorie", "longueur"]]

resume = tickets.map_batches(longueur_premier_message, batch_format="pandas")
print(resume.groupby("categorie").mean("longueur").take_all())
```

Ce petit exemple n'a d'intérêt qu'à titre de prise en main : sur ce volume, DuckDB serait plus rapide. Ray prend tout son sens quand chaque lot passe par un **modèle** : le module `ray.data.llm` (doc Ray 2.60.0, nov. 2026) construit des « processeurs » d'inférence par lots sur des moteurs comme vLLM ou SGLang, avec plusieurs répliques GPU, pour générer des embeddings ou classer des millions de documents. Vous l'utiliserez en M36 pour vectoriser le corpus de Bréval.

```mission
{
  "title": "L'inférence LLM par lots avec Ray Data",
  "url": "https://docs.ray.io/en/latest/data/working-with-llms.html",
  "steps": ["Ouvrez la page « Working with LLMs » de la documentation Ray Data", "Repérez les moteurs d'inférence pris en charge", "Repérez la fonction qui construit un processeur et le paramètre qui règle le nombre de répliques"],
  "question": "Quels moteurs d'inférence Ray Data LLM prend-il en charge, et quelle fonction construit le processeur ?",
  "hint": "La fonction commence par « build ».",
  "answer": "vLLM et SGLang ; build_processor, avec un paramètre de concurrence pour plusieurs répliques (doc Ray 2.60.0 consultée en nov. 2026, API susceptible d'évoluer) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 5. Le banc d'essai : six moteurs, une requête

Assemblez les scripts précédents (et ceux de L159 pour Spark) dans un même tableau, aux échelles 10 et 50. Ajoutez pandas comme référence (`pd.read_parquet` puis `merge` et `groupby`).

| Moteur | Échelle 10 (s) | Échelle 50 (s) | Mémoire max observée | Lignes de code |
|---|---|---|---|---|
| pandas | … | … (peut échouer) | … | … |
| Polars lazy (in-memory) | … | … | … | … |
| Polars lazy (streaming) | … | … | … | … |
| DuckDB (limite 2 Go) | … | … | … | … |
| Dask (cluster local) | … | … | … | … |
| Spark local | … | … | … | … |

Mesurez la mémoire avec le moniteur système (ou `/usr/bin/time -v` sous Linux, ligne *Maximum resident set size*). Sur un portable, il est habituel de constater que **DuckDB et Polars sont les plus rapides**, que pandas consomme le plus de mémoire, et que Spark local paie un coût de démarrage de la JVM qui pèse lourd sur de petits volumes. Vos propres chiffres font foi.

```quiz
{
  "q": "Bréval (échelle 50, ≈ 17 M de lignes) veut un traitement nocturne de 5 minutes maximum, maintenu par une seule personne qui connaît SQL et Python. Quelle recommandation est la mieux justifiée ?",
  "options": ["Un cluster Spark de trois nœuds, pour être prêt à grandir", "Dask sur Kubernetes, pour garder du code de type pandas distribué", "DuckDB ou Polars sur un serveur, avec un seuil de réévaluation", "Ray, parce qu'il sait répartir le travail sur les GPU"],
  "answer": 2,
  "explanation": "Le volume tient largement sur une machine, l'équipe est réduite et le SLA est modeste : un moteur mono-nœud minimise le coût et la complexité d'exploitation. Fixer un seuil (volume, durée, nombre d'utilisateurs) au-delà duquel réévaluer évite le choix « au cas où »."
}
```

## 6. Quand (ne pas) utiliser Spark

La règle de la recherche préparatoire de ce niveau tient en une phrase : **DuckDB ou Polars jusqu'à quelques centaines de Go sur une machine ; Spark, Ray ou un entrepôt cloud au-delà, ou quand le calcul doit être partagé.**

| Situation | Choix raisonnable |
|---|---|
| < quelques centaines de Go, une équipe réduite, traitements par lots | **DuckDB / Polars** (+ Parquet ou Iceberg) |
| SQL interactif pour de nombreux utilisateurs simultanés | entrepôt cloud (L158) ou MotherDuck |
| plusieurs To, ou traitements longs à paralléliser sur plusieurs machines | **Spark** (managé de préférence) |
| code pandas existant à faire grossir sans tout réécrire | Dask |
| préparation de corpus et inférence / embeddings par lots sur GPU | **Ray Data** (M36) |
| écosystème Databricks déjà en place | Spark (mais DuckDB reste utile pour le développement local) |
| flux temps réel | Kafka + Flink ou Spark Structured Streaming (M34) |

> 💡 **Autrement dit** — Ne choisissez pas un moteur pour le volume que vous **aurez peut-être un jour**, mais pour celui que vous avez, avec un seuil écrit à partir duquel vous changerez. Les formats ouverts (Parquet, Iceberg, Delta) rendent ce changement possible sans tout migrer.

## 🧪 Exercice pratique

**Consigne** — (1) Remplissez le tableau de la section 5 aux échelles 10 et 50, sur votre machine. (2) Ajoutez à votre requête Polars un `sink_parquet("data/gold/ca_2026.parquet")` et vérifiez la mémoire consommée. (3) Avec DuckDB, abaissez `memory_limit` jusqu'à provoquer un débordement sur disque (regardez le dossier `tmp_duckdb`), puis jusqu'à l'échec : notez les deux seuils. (4) Rédigez une note d'architecture de 15 lignes « Moteur de calcul de Bréval » : choix actuel, trois critères chiffrés tirés de vos mesures, seuils de révision et moteur cible au-delà.

**Critères de réussite** — Six moteurs mesurés à deux échelles (pandas peut échouer : notez-le) ; mémoire maximale relevée ; les deux seuils DuckDB sont identifiés ; la note respecte la compétence C5.1 (au moins trois critères chiffrés) et C5.3 (moteur justifié).

**Pistes de corrigé** — Une note solide dit par exemple : « DuckDB + Parquet. Mesures : 17 M de lignes traitées en quelques secondes avec 2 Go de mémoire ; coût d'infrastructure nul. Réévaluation si : volume silver > 200 Go, durée du traitement nocturne > 30 min, ou plus de 20 utilisateurs SQL simultanés. Cible : entrepôt cloud ou Spark managé sur tables Iceberg, sans migration des fichiers. »

## ✅ Auto-évaluation express
1. Que fait `collect(engine="streaming")` de plus que `collect()` ?
2. Quels réglages DuckDB permettent de traiter plus que la mémoire disponible ?
3. Dans quel cas Ray est-il préférable à DuckDB ?

**Réponses** — 1. Il exécute le plan par morceaux, ce qui permet de traiter des données plus volumineuses que la mémoire (avec parfois un léger coût en vitesse). 2. `memory_limit` (plafond), `temp_directory` (débordement sur disque) et `preserve_insertion_order = false` (moins de mémoire). 3. Quand le traitement est du Python arbitraire ou passe par des modèles (embeddings, inférence par lots, GPU) à répartir sur plusieurs machines, plutôt que du SQL analytique.

## 📚 Pour aller plus loin
- [Polars — documentation](https://docs.pola.rs/) 🇬🇧 — API lazy, moteur streaming, `sink_parquet`.
- [DuckDB 2.0 — Integration with Polars](https://duckdb.org/docs/2.0/guides/python/polars.html) 🇬🇧 — interroger un LazyFrame, `.pl(lazy=True)`.
- [Dask — documentation](https://docs.dask.org/) 🇬🇧 — DataFrames distribués, tableau de bord.
- [Ray — Working with LLMs](https://docs.ray.io/en/latest/data/working-with-llms.html) 🇬🇧 et [Offline batch inference](https://docs.ray.io/en/latest/data/batch_inference.html) 🇬🇧 — l'inférence par lots, utilisée en M36.
- [PySpark — Getting Started](https://spark.apache.org/docs/latest/api/python/getting_started/) 🇬🇧 — pour compléter le banc d'essai avec Spark.

> 🗺️ **Et maintenant ?** — Vous savez stocker et calculer à l'échelle ; le module M33 automatise tout cela : ingestion incrémentale, transformations dbt testées et orchestration, pour que la chaîne de Bréval tourne seule chaque nuit.
