---
id: L156
module: M32
level: N5
title: "De Hadoop au lakehouse : HDFS et MapReduce (historique), stockage objet S3/GCS/MinIO, coûts et cycle de vie"
minutes: 40
objectives:
  - "Retracer les grandes étapes du big data, de GFS et MapReduce à la séparation stockage/calcul du lakehouse"
  - "Expliquer le modèle map → shuffle → reduce et le reconnaître dans les moteurs actuels"
  - "Décrire le stockage objet (buckets, préfixes, classes de stockage, cycle de vie, versioning, coûts de requêtes et de sortie)"
  - "Déployer MinIO en local, y publier les couches de Bréval avec un partitionnement de type Hive et les interroger avec DuckDB"
  - "Estimer le coût mensuel d'un stockage objet à partir des tarifs officiels"
skills: ["C5.1", "C5.3"]
sources:
  - { title: "Stanford CS246 — Mining Massive Data Sets, Info Handout 2025", url: "https://snap.stanford.edu/class/cs246-2025/WWW/handouts/CS246_Info_Handout.pdf", lang: "en" }
  - { title: "Mining of Massive Datasets (Leskovec, Rajaraman, Ullman) — ch. 2 Map-Reduce", url: "http://www.mmds.org", lang: "en" }
  - { title: "APEC — Fiche métier Data Engineer", url: "https://www.apec.fr/tous-nos-metiers/informatique/data-engineer.html", lang: "fr" }
  - { title: "Amazon S3 — documentation", url: "https://docs.aws.amazon.com/s3/", lang: "en" }
  - { title: "Google Cloud Storage — documentation", url: "https://cloud.google.com/storage/docs", lang: "en" }
  - { title: "MinIO — documentation", url: "https://min.io/", lang: "en" }
  - { title: "DuckDB — documentation", url: "https://duckdb.org/docs/", lang: "en" }
---

# De Hadoop au lakehouse : HDFS, MapReduce, stockage objet, coûts et cycle de vie

> ⏱ 40 min · 🎯 Niveau 5 · 📚 Module 32

## 🎯 Ce que vous saurez faire
- Raconter en deux minutes pourquoi le monde est passé de Hadoop au stockage objet + moteurs séparés.
- Reconnaître les trois temps « map, shuffle, reduce » dans n'importe quel traitement distribué.
- Monter un stockage compatible S3 sur votre poste et y ranger le lac de données de Bréval.
- Chiffrer ce que coûterait ce lac chez un fournisseur cloud, avant de signer quoi que ce soit.

> 🧭 **En clair** — Au début des années 2000, pour traiter plus de données qu'un seul ordinateur ne pouvait en contenir, Google a eu l'idée de couper les fichiers en morceaux, de les répartir sur des centaines de machines bon marché et d'envoyer le calcul là où se trouvaient les morceaux. Hadoop a rendu cette idée accessible à tous. Puis on a compris qu'il était plus souple de séparer l'entrepôt (le stockage) des ouvriers (le calcul) : on stocke tout dans un immense entrepôt en libre-service, le stockage objet, et on loue des ouvriers seulement quand il y a du travail. C'est le principe du lakehouse.

## 1. Petite histoire du big data (2003-2026)

| Année | Événement | Ce qu'il a changé |
|---|---|---|
| 2003 | Google publie l'article sur **GFS** (*Google File System*) | fichiers découpés en blocs répliqués sur des machines ordinaires |
| 2004 | Jeffrey Dean et Sanjay Ghemawat publient **MapReduce** | un modèle de calcul parallèle simple, tolérant aux pannes |
| 2006 | Doug Cutting et Mike Cafarella créent **Hadoop** (soutenu par Yahoo) ; le nom vient de l'éléphant en peluche du fils de Doug Cutting | version open source de GFS (→ HDFS) et MapReduce |
| 2006 | Amazon lance **S3** (*Simple Storage Service*) | le stockage objet à la demande, facturé à l'usage |
| 2008-2010 | **Hive** (né chez Facebook) | du SQL au-dessus de MapReduce |
| 2009-2014 | **Spark** naît à l'AMPLab de Berkeley, devient projet Apache de premier niveau | calcul en mémoire, bien plus rapide que MapReduce sur disque (L159) |
| 2020 | S3 garantit la cohérence forte en lecture après écriture | le stockage objet devient une base fiable pour les tables analytiques |
| 2020-2026 | formats de table ouverts (Delta, Iceberg, Hudi) et **lakehouse** | transactions, historique et SQL directement sur des fichiers Parquet (L157) |

**HDFS** découpe chaque fichier en blocs (128 Mo par défaut depuis Hadoop 2), répliqués trois fois sur des *DataNodes* ; un *NameNode* garde la carte des blocs. **YARN** répartit les ressources de calcul. Le principe fondateur : **déplacer le calcul vers les données**, car le réseau était le goulot d'étranglement. La fiche APEC du data engineer cite encore « stockage sous Hadoop » et Hive : vous en croiserez dans les grandes entreprises, mais un projet neuf démarre presque toujours sur du stockage objet.

### 1.1 Le modèle MapReduce, en Python

Le livre gratuit *Mining of Massive Datasets* (chapitre 2) et le cours Stanford CS246 en font le point de départ du calcul distribué. Trois temps : **map** (chaque machine transforme ses enregistrements en paires clé → valeur), **shuffle** (on regroupe toutes les paires de même clé sur la même machine : c'est l'étape coûteuse, qui traverse le réseau), **reduce** (on agrège chaque groupe).

```python
# breval/mapreduce_sav.py — compter les mots des messages clients SAV « à la MapReduce »
from collections import defaultdict
from multiprocessing import Pool
import json, re

MOTS_VIDES = {"de", "la", "le", "les", "des", "du", "un", "une", "et", "pour", "sur", "pas", "je", "ma", "mon", "vous"}

def map_lot(lignes: list[str]) -> list[tuple[str, int]]:           # MAP : (mot, 1) pour chaque mot
    paires = []
    for ligne in lignes:
        ticket = json.loads(ligne)
        texte = ticket["messages"][0]["texte"].lower()
        paires += [(m, 1) for m in re.findall(r"[a-zàâçéèêëîïôûùüÿœ]{3,}", texte) if m not in MOTS_VIDES]
    return paires

def reduce_groupe(item: tuple[str, list[int]]) -> tuple[str, int]:  # REDUCE : somme par mot
    mot, uns = item
    return mot, sum(uns)

if __name__ == "__main__":
    lignes = open("data/raw/sav/tickets_sav.jsonl", encoding="utf-8").read().splitlines()
    lots = [lignes[i:i + 1000] for i in range(0, len(lignes), 1000)]  # « blocs » répartis sur les cœurs
    with Pool() as pool:
        resultats_map = pool.map(map_lot, lots)
        groupes = defaultdict(list)                                    # SHUFFLE : regrouper par clé
        for paires in resultats_map:
            for mot, un in paires:
                groupes[mot].append(un)
        comptes = pool.map(reduce_groupe, groupes.items())
    for mot, n in sorted(comptes, key=lambda x: -x[1])[:10]:
        print(f"{mot:15s} {n}")
```

Vous verrez sortir « cmd » (les numéros CMD-… des commandes citées), « commande », « chantier », « unités »… La même requête en SQL tient en une ligne (`GROUP BY mot`), et tout moteur moderne (Spark, DuckDB, BigQuery) exécute **exactement** ce schéma en interne : dans un plan d'exécution, le *shuffle* s'appelle `Exchange` chez Spark. Retenez donc le coût du shuffle : c'est lui que vous chercherez à réduire en L159.

> 💡 **Autrement dit** — Map = « chacun trie son tas de courrier par destinataire » ; shuffle = « on fait passer les enveloppes au bon guichet » ; reduce = « chaque guichet compte ses enveloppes ». Le passage des enveloppes d'un guichet à l'autre est ce qui prend du temps.

```quiz
{
  "q": "Dans un traitement MapReduce, quelle étape transfère des données entre machines par le réseau et coûte généralement le plus cher ?",
  "options": ["Le map", "Le reduce", "Le shuffle", "La lecture du premier bloc"],
  "answer": 2,
  "explanation": "Le shuffle regroupe toutes les valeurs d'une même clé sur la même machine : il implique des écritures, des transferts réseau et des tris. Réduire ou éviter les shuffles (jointures broadcast, pré-agrégation) est l'optimisation n° 1 en calcul distribué."
}
```

## 2. Le stockage objet, socle du lakehouse

Un stockage objet (Amazon S3, Google Cloud Storage, Azure ADLS Gen2, ou les solutions compatibles S3 auto-hébergeables : MinIO, Garage, Ceph) ne connaît ni dossiers ni fichiers modifiables : il stocke des **objets** (des octets + des métadonnées) identifiés par une **clé** dans un **bucket**. Les « dossiers » ne sont que des **préfixes** de clé : `silver/commandes/annee=2025/mois=03/part-0.parquet`.

| Notion | Ce qu'il faut savoir |
|---|---|
| Objet immuable | on réécrit un objet entier, on ne le modifie pas « au milieu » : d'où l'intérêt des formats de table (L157) |
| Classes de stockage | standard (accès fréquent), accès peu fréquent, archive (récupération lente) : plus c'est froid, moins le Go coûte, plus la lecture coûte |
| Cycle de vie (*lifecycle*) | règles automatiques : expirer les fichiers temporaires après N jours, basculer les vieilles partitions en classe froide |
| Versioning | conserve les versions précédentes d'un objet (protection contre l'effacement accidentel ou un rançongiciel) |
| Coûts | stockage (Go-mois) **+ requêtes** (par millier de PUT/GET) **+ sortie réseau** (*egress*, données téléchargées hors du cloud) |
| Sécurité | politiques d'accès (IAM), chiffrement au repos et en transit, blocage de l'accès public |

> ⚠️ **Piège fréquent** — Les **petits fichiers**. Un million de fichiers de 10 Ko coûtent un million de requêtes GET à chaque lecture complète et ralentissent tous les moteurs. Visez des fichiers Parquet de quelques centaines de Mo (et la compaction des formats de table, L157).

> ⚠️ **Piège fréquent** — Oublier la souveraineté. Pour des données personnelles ou sensibles, l'hébergeur et sa nationalité comptent (RGPD, transferts hors UE). Des stockages compatibles S3 sont proposés par des hébergeurs établis en France (OVHcloud, Scaleway, Outscale…) : vérifiez leur localisation, leurs certifications et leurs tarifs sur leurs pages officielles.

## 3. Atelier : MinIO en local et lac partitionné

Ajoutez MinIO au `docker-compose.yml` de L151 :

```yaml
# à ajouter sous « services: » dans breval/docker-compose.yml
  minio:
    image: minio/minio:latest          # voir l'avertissement ci-dessous
    container_name: breval-minio
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: breval
      MINIO_ROOT_PASSWORD: ${MINIO_ROOT_PASSWORD:-breval_local_123}   # 8 caractères minimum
    ports: ["9000:9000", "9001:9001"]   # 9000 : API S3 ; 9001 : console web
    volumes:
      - minio:/data
# et ajoutez « minio: » sous « volumes: »
```

> ⚠️ **Piège fréquent** — La distribution de l'édition communautaire de MinIO a évolué en 2025 (fonctionnalités de la console, mode de publication des images et binaires). Vérifiez sur la documentation officielle quelle image utiliser à la date de votre installation, et figez un tag précis plutôt que `latest` une fois votre choix fait. Si besoin, Garage ou Ceph offrent aussi une API compatible S3 ; le code DuckDB ci-dessous ne change pas.

```bash
docker compose up -d minio
pip install boto3
```

Publiez la couche silver de Bréval dans un bucket, avec un **partitionnement de type Hive** (`annee=…/mois=…`) pour les commandes, directement depuis DuckDB :

```python
# breval/publier_lac.py — data/silver -> s3://breval-lake (MinIO local)
import os
import boto3
import duckdb

ACCES, SECRET = "breval", os.environ.get("MINIO_ROOT_PASSWORD", "breval_local_123")
s3 = boto3.client("s3", endpoint_url="http://localhost:9000",
                  aws_access_key_id=ACCES, aws_secret_access_key=SECRET, region_name="us-east-1")
if "breval-lake" not in [b["Name"] for b in s3.list_buckets().get("Buckets", [])]:
    s3.create_bucket(Bucket="breval-lake")
s3.put_bucket_versioning(Bucket="breval-lake", VersioningConfiguration={"Status": "Enabled"})

con = duckdb.connect()
con.execute("INSTALL httpfs; LOAD httpfs;")
con.execute(f"""CREATE SECRET minio (TYPE s3, KEY_ID '{ACCES}', SECRET '{SECRET}', REGION 'us-east-1',
                ENDPOINT 'localhost:9000', URL_STYLE 'path', USE_SSL false)""")

# Commandes : un dossier par année et par mois (partitionnement Hive)
con.execute("""
    COPY (SELECT *, year(date_commande) AS annee, month(date_commande) AS mois
          FROM 'data/silver/commandes.parquet')
    TO 's3://breval-lake/silver/commandes' (FORMAT parquet, COMPRESSION zstd, PARTITION_BY (annee, mois), OVERWRITE_OR_IGNORE true)""")
for t in ["clients", "produits", "agences", "lignes_commande", "tickets_sav", "documents"]:
    con.execute(f"COPY (FROM 'data/silver/{t}.parquet') TO 's3://breval-lake/silver/{t}.parquet' (FORMAT parquet)")

# Lecture : le filtre sur annee/mois élimine des dossiers entiers avant toute lecture (partition pruning)
print(con.sql("""
    SELECT agence_id, sum(montant_ht) AS ca_ht
    FROM read_parquet('s3://breval-lake/silver/commandes/*/*/*.parquet', hive_partitioning = true)
    WHERE annee = 2026 AND mois BETWEEN 1 AND 3
    GROUP BY ALL ORDER BY agence_id"""))
objets = s3.list_objects_v2(Bucket="breval-lake", Prefix="silver/commandes/")
print(objets["KeyCount"], "objets sous silver/commandes/")
```

Enfin, une règle de cycle de vie qui expire les fichiers temporaires au bout de 7 jours (format de l'API S3, accepté par MinIO) :

```python
s3.put_bucket_lifecycle_configuration(Bucket="breval-lake", LifecycleConfiguration={"Rules": [{
    "ID": "purge-temporaires", "Status": "Enabled",
    "Filter": {"Prefix": "tmp/"},
    "Expiration": {"Days": 7}}]})
print(s3.get_bucket_lifecycle_configuration(Bucket="breval-lake")["Rules"])
```

> 💡 **À retenir** — Partitionner, c'est choisir **une ou deux colonnes souvent filtrées et peu nombreuses en valeurs** (date, pays). Partitionner par `client_id` (5 000 valeurs) créerait des milliers de minuscules fichiers : le remède serait pire que le mal.

```quiz
{
  "q": "Bréval partitionne ses commandes par annee/mois. Quelle requête profite le plus du partition pruning ?",
  "options": ["SELECT count(*) WHERE client_id = 4388", "SELECT client_id, montant_ht ORDER BY montant_ht DESC LIMIT 10", "SELECT DISTINCT canal", "SELECT sum(montant_ht) WHERE annee = 2025 AND mois = 6"],
  "answer": 3,
  "explanation": "Le filtre porte sur les colonnes de partition : le moteur ne liste et ne lit que le dossier annee=2025/mois=6. Les autres requêtes doivent parcourir toutes les partitions (seules les statistiques Parquet peuvent encore aider)."
}
```

## 4. Chiffrer avant de choisir

Les tarifs changent souvent et varient selon la région : **ne les recopiez jamais d'un article**, lisez la page de tarifs officielle du jour. La méthode, elle, ne change pas :

```python
# breval/cout_stockage.py — estimation mensuelle ; remplacez les prix par ceux de la page officielle du jour
def cout_mensuel(go_stockes: float, prix_go_mois: float,
                 milliers_put: float, prix_millier_put: float,
                 milliers_get: float, prix_millier_get: float,
                 go_sortie: float, prix_go_sortie: float) -> dict:
    lignes = {"stockage": go_stockes * prix_go_mois,
              "requetes_ecriture": milliers_put * prix_millier_put,
              "requetes_lecture": milliers_get * prix_millier_get,
              "sortie_reseau": go_sortie * prix_go_sortie}
    lignes["total"] = sum(lignes.values())
    return {k: round(v, 2) for k, v in lignes.items()}

# Hypothèses Bréval (échelle 1) : ~0,1 Go en silver Parquet, ~1 000 écritures et ~50 000 lectures par mois,
# ~2 Go téléchargés hors du cloud. PRIX FICTIFS à remplacer : ne les citez pas comme réels.
print(cout_mensuel(go_stockes=0.1, prix_go_mois=0.0,
                   milliers_put=1, prix_millier_put=0.0,
                   milliers_get=50, prix_millier_get=0.0,
                   go_sortie=2, prix_go_sortie=0.0))
```

Pour Bréval, la conclusion sera presque toujours la même : le stockage coûte quelques centimes ; ce sont les **requêtes**, la **sortie réseau** et surtout le **calcul** (L158) qui font la facture.

```mission
{
  "title": "Les chapitres du livre Mining of Massive Datasets",
  "url": "https://snap.stanford.edu/class/cs246-2025/WWW/handouts/CS246_Info_Handout.pdf",
  "steps": ["Ouvrez la fiche d'information du cours Stanford CS246 (hiver 2025)", "Repérez le manuel de référence et l'adresse où il est disponible gratuitement", "Repérez les thèmes du cours liés à MapReduce et Spark"],
  "question": "Quel manuel le cours CS246 utilise-t-il, à quelle adresse le télécharger, et quel outil la plupart des devoirs exigent-ils ?",
  "hint": "Le manuel porte le même nom que le cours.",
  "answer": "Mining of Massive Datasets (Leskovec, Rajaraman, Ullman), PDF disponibles sur mmds.org ; la plupart des devoirs exigent Spark, les Colabs hebdomadaires étant des notebooks Google Colab (le handout ne leur associe pas d'outil précis) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne** — (1) Déployez MinIO, publiez la couche silver de Bréval avec `publier_lac.py` et ouvrez la console web (`http://localhost:9001`) pour constater l'arborescence `annee=…/mois=…`. (2) Activez le versioning, écrasez `silver/produits.parquet` avec une version modifiée, puis récupérez l'ancienne version (`s3.list_object_versions`). (3) Remplissez `cout_stockage.py` avec les tarifs officiels d'un fournisseur de votre choix (région Paris ou Europe) pour l'échelle 1 et pour une échelle 100, et commentez.

**Critères de réussite** — La requête partitionnée renvoie le CA du premier trimestre 2026 par agence ; deux versions de `produits.parquet` sont listées ; l'estimation de coût cite la page de tarifs et sa date de consultation et distingue les quatre postes.

**Pistes de corrigé** — À l'échelle 100 (≈ 12 millions de commandes), le volume Parquet reste de l'ordre de quelques Go : le stockage reste marginal, la sortie réseau peut devenir le premier poste si un outil de BI hors cloud télécharge les données chaque jour. Solution : interroger dans le cloud et ne rapatrier que des agrégats.

## ✅ Auto-évaluation express
1. Quel principe fondait l'architecture Hadoop, et lequel l'a remplacé ?
2. Pourquoi un « dossier » S3 n'est-il qu'un préfixe ?
3. Citez les quatre postes de coût d'un stockage objet.

**Réponses** — 1. Déplacer le calcul vers les données (stockage et calcul sur les mêmes machines) ; remplacé par la séparation stockage/calcul (stockage objet + moteurs indépendants et élastiques). 2. Parce que le stockage objet est un espace plat de clés : `silver/commandes/annee=2025/…` est une clé complète, les « dossiers » sont reconstitués par l'affichage. 3. Stockage (Go-mois), requêtes d'écriture, requêtes de lecture, sortie réseau.

## 📚 Pour aller plus loin
- [Mining of Massive Datasets](http://www.mmds.org) 🇬🇧 — livre gratuit, chapitre 2 « Map-Reduce and the New Software Stack ».
- [Stanford CS246 — Info Handout 2025](https://snap.stanford.edu/class/cs246-2025/WWW/handouts/CS246_Info_Handout.pdf) 🇬🇧 — programme du cours (source d'inspiration).
- [Amazon S3 — documentation](https://docs.aws.amazon.com/s3/) 🇬🇧 — classes de stockage, cycle de vie, versioning.
- [Google Cloud Storage — documentation](https://cloud.google.com/storage/docs) 🇬🇧 — l'équivalent chez Google.
- [MinIO — documentation](https://min.io/) 🇬🇧 — déploiement et administration.

> 🗺️ **Et maintenant ?** — Vos fichiers Parquet sont dans un stockage objet, mais on ne peut ni les modifier proprement ni revenir en arrière ; L157 ajoute la couche qui change tout : les formats de table ouverts Delta Lake et Iceberg.
