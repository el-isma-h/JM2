---
id: L154
module: M31
level: N5
title: "Modéliser pour l'analytique : 3NF, étoile et SCD type 2, Data Vault 2.0, architecture médaillon"
minutes: 55
objectives:
  - "Expliquer pourquoi un modèle normalisé (3NF), excellent pour une application, est inadapté à l'analyse"
  - "Concevoir un schéma en étoile en quatre étapes (processus, grain, dimensions, faits) pour les ventes de Bréval Matériaux"
  - "Construire et mettre à jour une dimension historisée SCD type 2 de façon idempotente avec DuckDB"
  - "Identifier les composants d'un Data Vault 2.0 (hubs, links, satellites) et ses cas d'usage"
  - "Placer chaque modèle dans une architecture médaillon bronze / silver / gold"
skills: ["C5.1"]
sources:
  - { title: "MIT 6.5830/6.5831 Database Systems — syllabus (modèles, normalisation)", url: "https://dsg.csail.mit.edu/6.5830/syllabus.php", lang: "en" }
  - { title: "Berkeley CS186 — Introduction to Database Systems", url: "https://cs186berkeley.net/sp25/", lang: "en" }
  - { title: "DuckDB — documentation", url: "https://duckdb.org/docs/", lang: "en" }
  - { title: "O'Reilly — Fundamentals of Data Engineering (ch. modélisation et transformation)", url: "https://oreilly.com/library/view/fundamentals-of-data/9781098108298", lang: "en" }
  - { title: "Databricks — Learn, experiment and build with Free Edition", url: "https://www.databricks.com/blog/learn-experiment-and-build-databricks-free-edition", lang: "en" }
---

# Modéliser pour l'analytique : 3NF, étoile et SCD type 2, Data Vault 2.0, médaillon

> ⏱ 55 min · 🎯 Niveau 5 · 📚 Module 31

## 🎯 Ce que vous saurez faire
- Justifier en deux phrases pourquoi on ne branche pas un tableau de bord directement sur les tables de l'ERP.
- Dessiner le schéma en étoile des ventes de Bréval, en fixant d'abord son **grain**.
- Répondre correctement à « dans quelle ville habitait ce client quand il a passé cette commande ? » grâce à une dimension SCD type 2.
- Reconnaître un Data Vault et savoir quand il vaut l'effort.
- Ranger chaque table dans la bonne couche bronze, silver ou gold.

> 🧭 **En clair** — Une base d'application est rangée comme un atelier : chaque outil a une seule place, sans doublon, pour qu'on ne se trompe jamais en le remettant (c'est la normalisation). Une base d'analyse est rangée comme un rayon de supermarché : on met côte à côte ce que les clients cherchent ensemble, quitte à répéter certaines étiquettes. Le schéma en étoile est ce rayon : au centre, les « faits » (ce qui s'est passé, avec des chiffres), autour, les « dimensions » (qui, quoi, où, quand). Et comme le monde change (un client déménage), on garde l'ancienne étiquette datée plutôt que de l'effacer : c'est la SCD de type 2.

## 1. Le point de départ : un ERP en troisième forme normale

Le schéma de L151 est **normalisé** (troisième forme normale, 3NF) : chaque information est stockée une seule fois, à un seul endroit. La ville d'un client est dans `clients`, pas recopiée dans chaque commande. C'est idéal pour une application qui écrit beaucoup : une mise à jour ne touche qu'une ligne et ne peut pas créer d'incohérence. C'est l'approche « entrepôt d'entreprise intégré » défendue par Bill Inmon.

Pour l'analyse, trois défauts apparaissent :

1. **Beaucoup de jointures** : « CA par famille de produit, par agence et par trimestre » demande quatre tables.
2. **Pas d'historique** : quand un client déménage, l'ERP écrase sa ville ; le CA « par ville » de 2024 est recalculé avec les adresses de 2026.
3. **Des définitions dispersées** : chaque analyste recalcule « CA HT net de remise » à sa manière.

> 💡 **À retenir** — On ne modélise pas pour stocker, on modélise pour **répondre**. Le modèle analytique part des questions métier, pas de la structure de l'application.

## 2. Le schéma en étoile (Kimball) en quatre étapes

Ralph Kimball a popularisé la **modélisation dimensionnelle** (*The Data Warehouse Toolkit*, avec Margy Ross). Sa méthode tient en quatre décisions, dans cet ordre :

| Étape | Décision pour les ventes de Bréval |
|---|---|
| 1. Processus métier | la vente (les lignes de commande facturées ou livrées) |
| 2. **Grain** | **une ligne = une ligne de commande** (le niveau le plus fin disponible) |
| 3. Dimensions | date, client, produit, agence, canal |
| 4. Faits (mesures) | quantité, CA HT net de remise, marge brute |

```mermaid
erDiagram
    FAIT_VENTES }o--|| DIM_DATE : "date_sk"
    FAIT_VENTES }o--|| DIM_CLIENT : "client_sk (version valide à la date)"
    FAIT_VENTES }o--|| DIM_PRODUIT : "produit_sk"
    FAIT_VENTES }o--|| DIM_AGENCE : "agence_id"
    FAIT_VENTES {
        bigint ligne_id
        int date_sk
        bigint client_sk
        int produit_sk
        text agence_id
        text canal
        text numero_commande
        decimal quantite
        decimal ca_ht
        decimal marge_ht
    }
```

Quelques notions à nommer correctement :

- **Clé de substitution** (*surrogate key*, suffixe `_sk`) : un entier propre à l'entrepôt, distinct de la clé de l'ERP (`client_id`). Indispensable dès qu'un même client a plusieurs versions.
- **Dimension dégénérée** : le `numero_commande` est un attribut sans table propre ; on le garde dans le fait.
- **Mesures additives** (CA, quantité : on peut les sommer sur toutes les dimensions) et **non additives** (prix unitaire, taux de remise : on ne les somme jamais, on les recalcule).
- **Dimension date** : une table générée une fois (jour, semaine ISO, mois, trimestre, jour férié, saison du BTP) qui évite de recalculer ces attributs dans chaque requête.

> ⚠️ **Piège fréquent** — Mélanger deux grains dans un même fait, par exemple mettre `montant_ht` de l'en-tête de commande dans le fait au grain de la ligne : chaque somme multiplie le montant par le nombre de lignes. Un fait = un grain, écrit en toutes lettres dans sa documentation.

```quiz
{
  "q": "Le grain du fait ventes est « une ligne de commande ». Le directeur demande le panier moyen par agence. Quelle formule est juste ?",
  "options": ["avg(ca_ht) sur la table de faits, groupé par agence_sk", "sum(ca_ht) / count(DISTINCT numero_commande), par agence", "sum(ca_ht) / count(*), par agence", "sum(ca_ht) / count(DISTINCT client_sk), groupé par agence"],
  "answer": 1,
  "explanation": "Une commande compte plusieurs lignes : la moyenne des lignes (ou count(*)) donne le montant moyen d'une ligne, pas d'une commande. Il faut diviser le CA par le nombre de commandes distinctes, d'où l'intérêt de garder la dimension dégénérée numero_commande."
}
```

## 3. Les dimensions qui changent : SCD types 0 à 3

Une **SCD** (*Slowly Changing Dimension*, dimension à évolution lente) est une dimension dont les attributs changent de temps en temps. Kimball propose plusieurs stratégies, à choisir **attribut par attribut** :

| Type | Comportement | Exemple Bréval |
|---|---|---|
| 0 | jamais modifié | `date_creation` du client |
| 1 | on écrase (pas d'historique) | correction d'une faute dans le libellé produit |
| **2** | on **ferme** l'ancienne version et on **ajoute** une nouvelle ligne datée | ville, segment, agence de rattachement du client |
| 3 | une colonne « valeur précédente » | `segment_precedent` (une seule étape d'historique) |

### 3.1 Construire `dim_client` en SCD 2 avec DuckDB

Attributs **suivis** (type 2) : `type_client`, `segment`, `ville`, `code_postal`, `agence_id`. Les données personnelles directes (`nom`, `prenom`, `email`, `telephone`) **ne vont pas** dans la dimension analytique : minimisation RGPD, l'analyse n'en a pas besoin.

```sql
-- breval/sql/scd2_dim_client.sql — à exécuter dans data/breval.duckdb (vues bz_* de L153)
CREATE SEQUENCE IF NOT EXISTS seq_client_sk START 1;

-- Chargement initial : une version par client, valable depuis sa création
CREATE OR REPLACE TABLE dim_client AS
SELECT nextval('seq_client_sk')  AS client_sk,
       client_id, code_client, type_client, segment, ville, code_postal, agence_id,
       md5(concat_ws('|', type_client, segment, coalesce(ville, '∅'),
                     coalesce(code_postal, '∅'), agence_id)) AS hash_suivi,
       CAST(date_creation AS TIMESTAMP) AS valide_du,
       TIMESTAMP '9999-12-31'            AS valide_au,           -- « date infinie » : version en cours
       true                              AS est_courant
FROM bz_clients;

-- Mise à jour du 1er novembre 2026
CREATE OR REPLACE TEMP TABLE maj AS
SELECT *, md5(concat_ws('|', type_client, segment, coalesce(ville, '∅'),
                        coalesce(code_postal, '∅'), agence_id)) AS hash_suivi
FROM 'data/bronze/clients_maj_2026_11_01.parquet';

-- Étape 1 : fermer les versions courantes dont un attribut suivi a changé
UPDATE dim_client AS d
SET valide_au = m.mis_a_jour_le, est_courant = false
FROM maj AS m
WHERE d.client_id = m.client_id AND d.est_courant AND d.hash_suivi <> m.hash_suivi;

-- Étape 2 : ouvrir une version pour les clients modifiés (plus de version courante) et les nouveaux
INSERT INTO dim_client (client_sk, client_id, code_client, type_client, segment, ville, code_postal,
                        agence_id, hash_suivi, valide_du, valide_au, est_courant)
SELECT nextval('seq_client_sk'), m.client_id, m.code_client, m.type_client, m.segment, m.ville,
       m.code_postal, m.agence_id, m.hash_suivi, m.mis_a_jour_le, TIMESTAMP '9999-12-31', true
FROM maj AS m
WHERE NOT EXISTS (SELECT 1 FROM dim_client d WHERE d.client_id = m.client_id AND d.est_courant);

SELECT count(*) AS versions, count(*) FILTER (WHERE est_courant) AS courantes FROM dim_client;
```

Résultat attendu avec le jeu de référence : sur les 200 clients modifiés, **80** ont changé un attribut suivi (les autres ont seulement changé de téléphone ou de consentement, attributs non historisés ici) ; avec les 50 nouveaux, la dimension compte **5 205 versions dont 5 125 courantes**. Relancez les deux étapes : rien ne bouge, l'opération est **idempotente**.

> 💡 **Autrement dit** — L'empreinte `hash_suivi` résume les attributs suivis en une seule valeur : si elle change, au moins un attribut a changé, et il faut une nouvelle version. On compare une colonne au lieu de cinq, et les `NULL` sont remplacés par `'∅'` pour qu'un passage de « vide » à « Nantes » soit bien détecté.

### 3.2 Relier les faits à la bonne version

```sql
CREATE OR REPLACE TABLE fait_ventes AS
SELECT l.ligne_id,
       CAST(strftime(c.date_commande, '%Y%m%d') AS INTEGER) AS date_sk,
       d.client_sk, l.produit_id AS produit_sk, c.agence_id, c.canal, c.numero AS numero_commande,
       l.quantite,
       CAST(round(l.quantite * l.prix_unitaire_ht * (1 - l.remise_pct / 100), 2) AS DECIMAL(12,2))                AS ca_ht,
       CAST(round(l.quantite * (l.prix_unitaire_ht * (1 - l.remise_pct / 100) - p.prix_achat_ht), 2) AS DECIMAL(12,2)) AS marge_ht
FROM bz_lignes_commande l
JOIN (FROM bz_commandes QUALIFY row_number() OVER (PARTITION BY commande_id ORDER BY mis_a_jour_le DESC) = 1) c
     USING (commande_id)
JOIN bz_produits p USING (produit_id)
JOIN dim_client d ON d.client_id = c.client_id
                 AND c.date_commande >= d.valide_du AND c.date_commande < d.valide_au   -- jointure « à la date »
WHERE c.statut IN ('livree', 'facturee');
```

La condition d'intervalle sur `valide_du` / `valide_au` rattache chaque commande à la version du client **en vigueur ce jour-là**. Comme toutes les commandes du jeu sont antérieures au 1er novembre 2026, elles pointent toutes vers la première version ; les commandes de novembre, que vous ajouterez en M33, pointeront vers les nouvelles. Ce fait est volontairement **brut** : en L155, vous le reconstruirez à partir de données nettoyées (silver).

```quiz
{
  "q": "Un artisan nantais déménage à Saint-Nazaire le 1er novembre 2026. Avec dim_client en SCD 2, à quelle ville est rattaché son CA d'octobre 2026 ?",
  "options": ["Saint-Nazaire, car c'est la ville de la version courante", "Aucune, la ligne est supprimée", "Les deux, le CA est compté deux fois", "Nantes, la version du client valide à la date de commande"],
  "answer": 3,
  "explanation": "La jointure par intervalle de validité relie chaque fait à la version du client en vigueur à la date de la commande. Avec un simple MERGE (SCD 1), le CA d'octobre aurait été réattribué à Saint-Nazaire."
}
```

## 4. Data Vault 2.0 : historiser tout, de toutes les sources

Le **Data Vault 2.0** (Dan Linstedt ; ouvrage de référence *Building a Scalable Data Warehouse with Data Vault 2.0*, avec Michael Olschimke) sépare trois choses que l'étoile mélange :

| Composant | Contient | Exemple Bréval |
|---|---|---|
| **Hub** | la clé métier, une fois pour toutes | `hub_client(client_hk, code_client, date_chargement, source)` |
| **Link** | une relation entre clés métier | `lnk_commande_client(lien_hk, commande_hk, client_hk, …)` |
| **Satellite** | les attributs descriptifs, historisés, **par source** | `sat_client_erp` (segment, ville…), `sat_client_sav` (canal préféré, vu dans l'outil SAV) |

```sql
-- Esquisse Data Vault 2.0 (DuckDB) : clés de hachage calculées depuis la clé métier normalisée
CREATE TABLE hub_client AS
SELECT DISTINCT md5(upper(trim(code_client))) AS client_hk, code_client,
       TIMESTAMP '2026-11-01 02:00:00' AS date_chargement, 'erp' AS source
FROM bz_clients;

CREATE TABLE sat_client_erp AS
SELECT md5(upper(trim(code_client))) AS client_hk,
       TIMESTAMP '2026-11-01 02:00:00' AS date_chargement,
       md5(concat_ws('|', segment, coalesce(ville, '∅'), agence_id)) AS hash_diff,   -- détecte les changements
       segment, ville, agence_id, 'erp' AS source
FROM bz_clients;
```

Tout y est **en insertion seule** : on n'écrase jamais, on ajoute une ligne de satellite quand `hash_diff` change. Avantages : traçabilité complète (exigée en banque et assurance, utile pour l'AI Act quand des données servent à un système à haut risque), ajout d'une nouvelle source sans casser l'existant, chargements parallèles. Inconvénient : beaucoup de tables et de jointures ; on **ne requête pas** un Data Vault directement, on construit des étoiles par-dessus.

> ⚠️ **Piège fréquent** — Mettre en place un Data Vault pour une PME à trois sources stables. Pour Bréval, une couche silver propre + une étoile en gold suffit largement ; le Data Vault se justifie quand les sources sont nombreuses, changeantes, et l'auditabilité obligatoire.

## 5. Tables larges et architecture médaillon

La **table large** (*One Big Table*, OBT) dénormalise tout dans une seule table : chaque ligne de vente porte la famille du produit, le segment du client, la ville… Les moteurs colonnaires la compriment très bien, les outils de BI et les modèles de machine learning l'adorent. C'est une **couche de consommation**, construite à partir de l'étoile, pas un modèle de référence.

L'**architecture médaillon** organise le lakehouse en trois couches de raffinement, dont la vôtre :

```mermaid
flowchart LR
    S[Sources : ERP, SAV, documents] --> B
    B["BRONZE<br/>données brutes typées<br/>commandes, clients, tickets_sav…"] --> SI
    SI["SILVER<br/>nettoyé, dédoublonné, conforme<br/>3NF propre ou Data Vault"] --> G
    G["GOLD<br/>prêt à consommer<br/>fait_ventes, dim_client SCD2, OBT, features ML, chunks RAG"]
```

| Couche | Règle d'or | Bréval |
|---|---|---|
| Bronze | fidèle à la source, rejouable, jamais corrigée | `data/bronze/*.parquet` (L152) |
| Silver | une vérité par entité : types, formats, doublons, références valides | `data/silver/` (L155) |
| Gold | modèle orienté usage : étoile, agrégats, features, index | `data/gold/` (L155, puis M33 avec dbt) |

| Approche | Force | Faiblesse | Pour Bréval |
|---|---|---|---|
| 3NF | intégrité, pas de redondance | jointures, pas d'historique | ERP source, silver |
| Étoile + SCD 2 | simple à requêter, historisé | à concevoir par processus | **gold principal** |
| Data Vault 2.0 | auditabilité, multi-sources | complexité | non retenu (justifié) |
| OBT | vitesse et simplicité de lecture | redondance, rigidité | marts BI et features ML |

```mission
{
  "title": "Où l'on enseigne la normalisation",
  "url": "https://dsg.csail.mit.edu/6.5830/syllabus.php",
  "steps": ["Ouvrez le syllabus du cours MIT 6.5830/6.5831 Database Systems", "Parcourez les premières séances", "Repérez les thèmes consacrés aux modèles de données et à la conception de schéma"],
  "question": "Quels thèmes de modélisation (modèles, normalisation, contraintes…) le MIT place-t-il en début de cours, et dans quel langage sont écrits les labs ?",
  "hint": "Les labs ne sont pas en Python.",
  "answer": "Le modèle relationnel et SQL dès les deux premières séances, puis la conception de schéma (normalisation, contraintes d'intégrité) à la troisième ; labs en Go (syllabus et calendrier du printemps 2026, vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne** — (1) Concevez l'étoile du processus « SAV » de Bréval : grain, dimensions, mesures (au moins trois), dimensions partagées avec les ventes. (2) Exécutez `scd2_dim_client.sql` deux fois et prouvez l'idempotence. (3) Écrivez une requête qui affiche, pour un client ayant déménagé, ses deux versions et le CA rattaché à chacune. (4) En cinq lignes, expliquez au dirigeant de Bréval pourquoi vous ne retenez pas de Data Vault.

**Critères de réussite** — Le grain SAV est énoncé en une phrase ; `dim_client` est partagée par les deux étoiles (dimension **conforme**) ; les compteurs sont 5 205 / 5 125 après chaque exécution ; l'argumentaire cite au moins deux critères (nombre de sources, exigence d'audit, coût de maintenance).

**Pistes de corrigé** — Grain SAV : « un ticket ». Dimensions : date d'ouverture, client (SCD 2, partagée), agence, catégorie, canal ; mesures : délai de première réponse, durée de résolution, nombre de messages, satisfaction (non additive : on en fait des moyennes). Une variante « un message » est possible pour analyser les échanges : c'est un **autre** fait.

## ✅ Auto-évaluation express
1. Quelles sont les quatre étapes de Kimball, dans l'ordre ?
2. Quelle différence entre SCD 1 et SCD 2 ?
3. Que contient un satellite de Data Vault ?

**Réponses** — 1. Choisir le processus métier, déclarer le grain, identifier les dimensions, identifier les faits. 2. SCD 1 écrase l'ancienne valeur (pas d'historique) ; SCD 2 ferme l'ancienne version et en ouvre une nouvelle, datée. 3. Les attributs descriptifs d'un hub ou d'un link, historisés par date de chargement et par source, avec une empreinte de changement (`hash_diff`).

## 📚 Pour aller plus loin
- [MIT 6.5830/6.5831 — syllabus](https://dsg.csail.mit.edu/6.5830/syllabus.php) 🇬🇧 — modèles, normalisation, contraintes (source d'inspiration).
- [Berkeley CS186](https://cs186berkeley.net/sp25/) 🇬🇧 — modélisation relationnelle et requêtes.
- [Fundamentals of Data Engineering](https://oreilly.com/library/view/fundamentals-of-data/9781098108298) 🇬🇧 — chapitre sur la modélisation et la transformation (Kimball, Inmon, Data Vault, tables larges).
- Références bibliographiques sans lien : Kimball & Ross, *The Data Warehouse Toolkit* ; Linstedt & Olschimke, *Building a Scalable Data Warehouse with Data Vault 2.0*.
- [Databricks Free Edition](https://www.databricks.com/blog/learn-experiment-and-build-databricks-free-edition) 🇬🇧 — pour pratiquer l'architecture médaillon dans un lakehouse cloud gratuit.

> 🗺️ **Et maintenant ?** — Le modèle est conçu ; en L155, vous mettez les mains dans le cambouis : profiler, nettoyer et remplir les couches silver et gold de Bréval avec DuckDB et Polars.
