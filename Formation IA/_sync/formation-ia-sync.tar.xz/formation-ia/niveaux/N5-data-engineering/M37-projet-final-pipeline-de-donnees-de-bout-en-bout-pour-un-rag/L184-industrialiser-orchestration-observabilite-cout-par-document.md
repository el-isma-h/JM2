---
id: L184
module: M37
level: N5
title: "Industrialiser : orchestration, observabilité, coût par document, documentation et soutenance"
minutes: 45
objectives:
  - "Orchestrer le micro-batch complet avec Dagster (assets, dbt, contrôles bloquants, reprise, planification, alertes) à côté des services de flux"
  - "Mettre en place des moniteurs couvrant les cinq piliers de l'observabilité, détecter un incident simulé et rédiger son post-mortem"
  - "Estimer le coût par exécution et par document à partir de mesures, et comparer exécution locale et API cloud"
  - "Livrer un runbook et présenter le projet en 15 minutes avec des preuves rejouables alignées sur la grille"
skills: ["C5.6", "C5.2", "C5.4"]
sources:
  - { title: "Dagster — documentation", url: "https://docs.dagster.io/", lang: "en" }
  - { title: "Dagster — Prefect is acquiring Dagster", url: "https://dagster.io/blog/prefect-is-acquiring-dagster", lang: "en" }
  - { title: "Apache Airflow — Announcements", url: "https://airflow.apache.org/announcements/", lang: "en" }
  - { title: "Elementary — documentation", url: "https://docs.elementary-data.com/", lang: "en" }
  - { title: "OpenLineage — Object model", url: "https://openlineage.io/docs/spec/object-model", lang: "en" }
  - { title: "DataDriven — Data observability", url: "https://datadriven.io/data-observability", lang: "en" }
  - { title: "dbt — Source freshness", url: "https://docs.getdbt.com/docs/deploy/source-freshness", lang: "en" }
  - { title: "Google Cloud — Professional Data Engineer", url: "https://cloud.google.com/certification/data-engineer", lang: "en" }
---

# Industrialiser : orchestration, observabilité, coût par document, documentation et soutenance

> ⏱ 45 min · 🎯 Niveau 5 · 📚 Module 37

## 🎯 Ce que vous saurez faire
- Faire tourner Bréval Assist sans vous : un micro-batch toutes les 15 minutes, qui s'arrête de lui-même devant une donnée non conforme et vous prévient.
- Savoir, d'un coup d'œil, si la chaîne est fraîche, complète, stable, propre et traçable, et le prouver par des mesures historisées.
- Dire combien coûte le traitement d'un document, chiffres mesurés à l'appui, en local et avec une API cloud.
- Remettre un runbook qu'un collègue d'astreinte peut suivre, et soutenir le projet en 15 minutes devant un jury.

> 🧭 **En clair** — Le bâtiment est construit ; il faut maintenant l'exploiter. Un gardien fait sa ronde tous les quarts d'heure et ferme la porte si quelque chose cloche (l'orchestrateur). Des capteurs surveillent la température, les fuites et les compteurs (les moniteurs). Le syndic connaît la facture d'électricité par appartement (le coût par document). Un carnet d'entretien dit quoi faire quand l'alarme sonne (le runbook). Et le jour de la réception des travaux, on fait visiter le bâtiment en montrant les preuves, pas en racontant (la soutenance). Cette dernière leçon transforme votre pipeline en service.

## 1. Orchestrer : un graphe d'assets, deux familles de processus

Deux familles de processus cohabitent, et c'est voulu :

| Famille | Processus | Qui le fait tourner | En production |
|---|---|---|---|
| **Flux permanents** | `cdc_vers_bronze.py`, `indexeur_suppressions.py`, Kafka Connect | lancés une fois, tournent en continu | conteneurs avec redémarrage automatique (`restart: unless-stopped`), supervision du retard |
| **Micro-batch** | bronze CDC → dbt amont → silver → dbt aval → embeddings → index → évaluation → moniteurs | Dagster, toutes les 15 min en heures ouvrées | même code, planifié, avec reprise et alertes |

Le fichier de définitions reprend la logique de L164 (un modèle dbt = un asset) et y branche les étapes Python du projet :

```python
# orchestration/defs_rag.py — Bréval Assist : micro-batch toutes les 15 min, du bronze jusqu'aux moniteurs
# dagster dev -f orchestration/defs_rag.py   (remplace defs.py de L164 pour le projet final ; arrêtez l'autre)
import os
import subprocess
import sys
from pathlib import Path

import dagster as dg
import requests
from dagster_dbt import DbtCliResource, DbtProject, dbt_assets

RACINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RACINE))                                    # paquets rag/, qualite/, observabilite/
from observabilite.moniteurs_rag import mesurer                    # noqa: E402
from qualite.gx_chunks import charger, valider_chunks              # noqa: E402
from rag import embeddings, evaluation, index, lignage             # noqa: E402
from rag.bronze_cdc import charger_cdc                             # noqa: E402
from rag.config import COLLECTION, connexion_duckdb                # noqa: E402
from rag.preparer import preparer                                  # noqa: E402

projet_dbt = DbtProject(project_dir=RACINE / "dbt_breval")
projet_dbt.prepare_if_dev()
SOURCES_DLT = [["erp", "clients"], ["erp", "commandes"], ["erp", "lignes_commande"],
               ["sav", "tickets_sav"], ["sav", "tickets_sav__messages"]]
REPRISE = dg.RetryPolicy(max_retries=2, delay=30)


def connexion(context):
    os.environ["RAG_RUN_ID"] = context.run_id                      # relie obs.etapes au run Dagster (coûts)
    return connexion_duckdb()


def alerter(message: str) -> None:
    url = os.environ.get("ALERTE_WEBHOOK_URL")                     # Slack, Teams, Mattermost… (L164)
    if url:
        requests.post(url, json={"text": message}, timeout=10)


@dg.multi_asset(specs=[dg.AssetSpec(c, group_name="bronze") for c in SOURCES_DLT], retry_policy=REPRISE)
def bronze_dlt(context: dg.AssetExecutionContext):
    subprocess.run([sys.executable, str(RACINE / "ingestion" / "ingest.py")], check=True, cwd=RACINE)
    for c in SOURCES_DLT:
        yield dg.MaterializeResult(asset_key=c)


@dg.asset(key=["cdc", "cdc_evenements"], group_name="bronze", retry_policy=REPRISE)
def bronze_cdc(context: dg.AssetExecutionContext) -> dg.MaterializeResult:
    con = connexion(context)
    try:
        n = charger_cdc(con)
    finally:
        con.close()
    return dg.MaterializeResult(metadata={"nouveaux_evenements": n})


@dbt_assets(manifest=projet_dbt.manifest_path, select="path:models/staging path:models/rag/amont", name="dbt_amont")
def dbt_amont(context: dg.AssetExecutionContext, dbt: DbtCliResource):
    yield from dbt.cli(["build"], context=context).stream()


@dg.multi_asset(specs=[
    dg.AssetSpec(["rag", "rag_documents"], deps=["rag_documents_courants", "rag_tickets_a_indexer"], group_name="silver"),
    dg.AssetSpec(["rag", "rag_chunks"], deps=["rag_documents_courants", "rag_tickets_a_indexer"], group_name="silver"),
])
def silver_rag(context: dg.AssetExecutionContext):
    run = lignage.nouveau_run()
    lignage.emettre("preparer_silver", [("s3", "documents"), ("duckdb", "silver.rag_tickets_a_indexer")],
                    [("duckdb", "silver.rag_chunks")], "START", run)
    con = connexion(context)
    try:
        stats = preparer(con)
        ok, echecs = valider_chunks(charger(con))                  # contrôle BLOQUANT avant toute indexation
    finally:
        con.close()
    if not ok:
        raise dg.Failure(description="GX a bloqué silver.rag_chunks : " + " ; ".join(echecs))
    lignage.emettre("preparer_silver", [("s3", "documents"), ("duckdb", "silver.rag_tickets_a_indexer")],
                    [("duckdb", "silver.rag_chunks")], "COMPLETE", run)
    yield dg.MaterializeResult(asset_key=["rag", "rag_documents"],
                               metadata={k: stats[k] for k in ("documents", "tickets", "doublons", "pii_calculees")})
    yield dg.MaterializeResult(asset_key=["rag", "rag_chunks"],
                               metadata={"chunks": stats["chunks"], "indexables": stats["indexables"]})


@dbt_assets(manifest=projet_dbt.manifest_path, select="source:rag+", name="dbt_aval")
def dbt_aval(context: dg.AssetExecutionContext, dbt: DbtCliResource):
    yield from dbt.cli(["build"], context=context).stream()        # un test dbt en échec arrête la suite


@dg.asset(deps=[["rag", "rag_chunks"], "rag_qualite_corpus"], group_name="index", retry_policy=REPRISE)
def embeddings_rag(context: dg.AssetExecutionContext) -> dg.MaterializeResult:
    con = connexion(context)
    try:
        n = embeddings.calculer(con)
    finally:
        con.close()
    return dg.MaterializeResult(metadata={"chunks_vectorises": n})


@dg.asset(deps=["embeddings_rag"], group_name="index", retry_policy=REPRISE)
def index_qdrant(context: dg.AssetExecutionContext) -> dg.MaterializeResult:
    run, q = lignage.nouveau_run(), index.client()
    cible = index.collection_servie(q) or COLLECTION
    lignage.emettre("indexer_qdrant", [("duckdb", "silver.rag_chunks")], [("qdrant", cible)], "START", run)
    con = connexion(context)
    try:
        bilan = index.synchroniser(con, q, cible)
    finally:
        con.close()
    lignage.emettre("indexer_qdrant", [("duckdb", "silver.rag_chunks")], [("qdrant", cible)], "COMPLETE", run)
    return dg.MaterializeResult(metadata={**bilan, "collection": cible})


@dg.asset(deps=["index_qdrant"], group_name="index")
def evaluation_recuperation(context: dg.AssetExecutionContext) -> dg.MaterializeResult:
    synthese, _ = evaluation.evaluer()
    con = connexion(context)
    try:
        evaluation.enregistrer(con, synthese)
    finally:
        con.close()
    if synthese["fuites"]:
        raise dg.Failure(description=f"{synthese['fuites']} fuite(s) de droits : incident de sécurité")
    return dg.MaterializeResult(metadata={"recall@5": synthese["recall"], "mrr": synthese["mrr"]})


@dg.asset(deps=["evaluation_recuperation", "rag_suivi_documents"], group_name="observabilite")
def moniteurs(context: dg.AssetExecutionContext) -> dg.MaterializeResult:
    con = connexion(context)
    try:
        alertes = mesurer(con)
    finally:
        con.close()
    for a in alertes:
        context.log.warning(a)
    if alertes:
        alerter("⚠️ Bréval Assist\n" + "\n".join(alertes))
    return dg.MaterializeResult(metadata={"alertes": len(alertes)})


rag_quart_heure = dg.define_asset_job("rag_quart_heure", selection=dg.AssetSelection.all(),
                                      executor_def=dg.in_process_executor)   # un seul écrivain DuckDB à la fois


@dg.run_failure_sensor(monitored_jobs=[rag_quart_heure])
def alerte_echec(context: dg.RunFailureSensorContext):
    alerter(f"❌ {context.dagster_run.job_name} a échoué : {context.failure_event.message}")


defs = dg.Definitions(
    assets=[bronze_dlt, bronze_cdc, dbt_amont, silver_rag, dbt_aval, embeddings_rag, index_qdrant,
            evaluation_recuperation, moniteurs],
    jobs=[rag_quart_heure],
    schedules=[dg.ScheduleDefinition(job=rag_quart_heure, cron_schedule="*/15 7-19 * * 1-6",
                                     execution_timezone="Europe/Paris")],
    sensors=[alerte_echec],
    resources={"dbt": DbtCliResource(project_dir=projet_dbt)},
)
```

Les assets `silver_rag` et `index_qdrant` émettent aussi des événements OpenLineage, comme le script de L172, avec le petit module `rag/lignage.py` ci-dessous. Il ne fait rien tant que `MARQUEZ_URL` n'est pas défini : le graphe de Dagster suffit pour le TP, et Marquez sert à exporter le lignage vers un catalogue d'entreprise.

```python
# rag/lignage.py — événements OpenLineage START/COMPLETE vers Marquez (méthode de L172), si MARQUEZ_URL est défini
import datetime as dt
import os
import uuid

import requests

PRODUCER = "urn:breval:breval-assist:1.0"
SCHEMA_URL = "https://openlineage.io/spec/2-0-2/OpenLineage.json#/$defs/RunEvent"   # à vérifier sur openlineage.io
NAMESPACES = {"duckdb": "duckdb://breval", "s3": "s3://breval-docs", "qdrant": "qdrant://localhost:6333"}


def nouveau_run() -> str:
    return str(uuid.uuid4())


def emettre(job: str, entrees: list[tuple[str, str]], sorties: list[tuple[str, str]], etat: str, run_id: str) -> None:
    url = os.environ.get("MARQUEZ_URL")              # ex. http://localhost:5000/api/v1/lineage (L172)
    if not url:
        return
    jeu = lambda ns, nom: {"namespace": NAMESPACES[ns], "name": nom}
    requests.post(url, timeout=10, json={
        "eventType": etat, "eventTime": dt.datetime.now(dt.timezone.utc).isoformat(),
        "run": {"runId": run_id}, "job": {"namespace": "breval-rag", "name": job},   # namespace de job de L172
        "inputs": [jeu(*e) for e in entrees], "outputs": [jeu(*s) for s in sorties],
        "producer": PRODUCER, "schemaURL": SCHEMA_URL}).raise_for_status()
```

Quatre décisions à expliquer au jury :

- **Deux groupes dbt** (`dbt_amont`, `dbt_aval`) parce que Python s'intercale entre eux : les modèles amont alimentent `preparer()`, les modèles aval et leurs tests lisent ce qu'il a écrit.
- **Trois verrous** : la suite GX dans `silver_rag` (rien ne part vers l'index si elle échoue), les tests dbt de `dbt_aval` (un test rouge arrête `embeddings_rag`, qui en dépend), et l'évaluation qui lève une erreur à la moindre **fuite de droits**. L'index garde alors son dernier état valide.
- **`in_process_executor`** : les étapes s'exécutent l'une après l'autre dans un seul processus, car DuckDB n'accepte qu'un écrivain (L165).
- **`RetryPolicy`** sur les étapes qui dépendent du réseau (MinIO, Qdrant, Postgres) : une coupure de quelques secondes ne doit pas réveiller l'astreinte.

```text
# Makefile (ajouts au fichier de L165) — projet final Bréval Assist ; les recettes commencent par une tabulation
export PYTHONPATH := $(CURDIR)

.PHONY: plateforme connecteur cdc indexeur rag dagster-rag tests-rag moniteurs couts

plateforme:
	docker compose up -d
	docker exec -i breval-postgres psql -U breval -d breval < sql/03_ged_rgpd.sql
	python ingestion/ged_simulateur.py init
connecteur:
	curl -s -X POST -H "Content-Type: application/json" --data @cdc/connecteur-breval.json http://localhost:8083/connectors
cdc:
	python cdc/cdc_vers_bronze.py
indexeur:
	python cdc/indexeur_suppressions.py
rag:                       # le micro-batch à la main, étape par étape (une ligne = un shell)
	python -m rag.bronze_cdc
	python ingestion/ingest.py
	$(DBT) build --profiles-dir . --select path:models/staging path:models/rag/amont
	python -m rag.preparer
	$(DBT) build --profiles-dir . --select "source:rag+"
	python -m rag.embeddings
	python -m rag.index
	python -m rag.evaluation
dagster-rag:
	dagster dev -f orchestration/defs_rag.py
tests-rag:
	pytest -q -s tests_pipeline/test_rag.py
moniteurs:
	python -m observabilite.moniteurs_rag
couts:
	python couts/cout_par_document.py
```

```bash
make dagster-rag            # interface sur http://localhost:3000 ; arrêtez d'abord le defs.py de L164
```

**Point de contrôle** — Dans la vue des assets, le graphe va de `erp/commandes`, `sav/tickets_sav` et `cdc/cdc_evenements` jusqu'à `index_qdrant` et `moniteurs` : c'est le **lignage source → index** demandé par C5.4, consultable sans rien déclarer de plus. Matérialisez tout une première fois, puis activez la planification `rag_quart_heure`. Une exécution sans changement doit afficher `chunks_vectorises: 0` et `inseres: 0`.

```quiz
{
  "q": "La suite GX échoue dans silver_rag à 10 h 15. Que voient les utilisateurs de Bréval Assist à 10 h 16 ?",
  "options": ["Une erreur : l'index est vidé par sécurité jusqu'au prochain passage", "Les réponses de l'index dans son état du dernier passage réussi", "Les nouveaux chunks, indexés avant que GX ait fini de les vérifier", "Rien : Dagster arrête l'assistant jusqu'à la correction des données"],
  "answer": 1,
  "explanation": "L'échec arrête le run avant embeddings_rag et index_qdrant : l'index n'est pas touché et continue de servir son dernier état valide. Les suppressions urgentes, elles, continuent d'être appliquées par l'indexeur de flux, qui ne dépend pas du batch."
}
```

## 2. Observer : les cinq piliers appliqués à Bréval Assist

| Pilier (L173) | Ce qu'on mesure ici | Seuil | Pourquoi |
|---|---|---|---|
| Fraîcheur | slot Debezium actif, WAL retenu, retard de l'indexeur, p95 des suppressions, âge de silver | actif ; ≤ 100 Mo ; ≤ 50 messages ; ≤ 300 s ; ≤ 60 min | les SLO du contrat (L180) |
| Volume | écart entre points Qdrant et chunks attendus, z-score du nombre de chunks | ≤ 1 % ; \|z\| ≤ 3 | index désynchronisé, effondrement ou explosion du corpus |
| Schéma | empreinte des colonnes de `silver.rag_chunks`, clés inattendues dans les événements du registre | inchangée ; aucune | dérive silencieuse côté GED ou pipeline |
| Qualité | PII résiduelles, recall@5, fuites de droits | 0 ; ≥ 0,80 ; 0 | ce que l'utilisateur subit directement |
| Lignage | chunks indexables sans source vivante (orphelins) | 0 | un chunk qui ne remonte à rien ne peut ni être cité ni être effacé |

```python
# observabilite/moniteurs_rag.py — les 5 piliers de L173 appliqués à Bréval Assist ; historisés dans obs.metriques_rag
import hashlib
import json
import statistics

import psycopg2
from confluent_kafka import Consumer, TopicPartition

from rag.config import AUDIT_SUPPRESSIONS, KAFKA, PG_URL, SLO_SUPPRESSION_S, connexion_duckdb
from rag.index import client, collection_servie

TEL = r"(\+33\s?|0)[1-9]([ .]?\d{2}){4}"
CLES_GED = {"doc_id", "cle_objet", "titre", "type_document", "service", "version", "date_maj",
            "confidentialite", "sha256", "modifie_le"}


def slot_replication() -> tuple[bool, float]:
    with psycopg2.connect(PG_URL) as pg, pg.cursor() as cur:
        cur.execute("""SELECT active, pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn)
                       FROM pg_replication_slots WHERE slot_name = 'debezium_breval'""")
        ligne = cur.fetchone()
    return (False, 0.0) if ligne is None else (bool(ligne[0]), float(ligne[1] or 0) / 1e6)


def retard_kafka(groupe: str, topics: list[str]) -> int:
    """Messages publiés mais pas encore traités par le groupe (le « lag »)."""
    c = Consumer({"bootstrap.servers": KAFKA, "group.id": groupe, "enable.auto.commit": False})
    try:
        retard = 0
        for t in topics:
            partitions = [TopicPartition(t, p) for p in c.list_topics(t, timeout=10).topics[t].partitions]
            for tp in c.committed(partitions, timeout=10):
                bas, haut = c.get_watermark_offsets(tp, timeout=10)
                retard += haut - (tp.offset if tp.offset >= 0 else bas)
        return retard
    finally:
        c.close()


def mesurer(con) -> list[str]:
    con.execute("CREATE SCHEMA IF NOT EXISTS obs")
    con.execute("""CREATE TABLE IF NOT EXISTS obs.metriques_rag (mesure_le TIMESTAMPTZ DEFAULT now(),
                   pilier VARCHAR, indicateur VARCHAR, valeur DOUBLE, seuil DOUBLE, ok BOOLEAN, detail VARCHAR)""")
    q, m = client(), []

    def noter(pilier, indicateur, valeur, seuil, ok, detail=None):
        m.append((pilier, indicateur, float(valeur), float(seuil), bool(ok), detail))

    # 1) FRAÎCHEUR : la chaîne CDC avance-t-elle, et les suppressions tiennent-elles leur SLO ?
    actif, retard_mo = slot_replication()
    noter("fraicheur", "slot_debezium_actif", actif, 1, actif)
    noter("fraicheur", "wal_retenu_mo", retard_mo, 100, retard_mo <= 100)
    lag = retard_kafka("rag-indexeur", ["breval.ged.documents", "breval.rgpd.demandes_effacement"])
    noter("fraicheur", "retard_indexeur_messages", lag, 50, lag <= 50)
    latences = ([json.loads(l)["latence_s"] for l in AUDIT_SUPPRESSIONS.open(encoding="utf-8")][-200:]
                if AUDIT_SUPPRESSIONS.exists() else [])
    p95 = statistics.quantiles(latences, n=20)[-1] if len(latences) >= 20 else max(latences, default=0)
    noter("fraicheur", "suppression_p95_s", p95, SLO_SUPPRESSION_S, p95 <= SLO_SUPPRESSION_S)
    age = con.execute("SELECT date_diff('minute', max(prepare_le), now()) FROM silver.rag_chunks").fetchone()[0]
    noter("fraicheur", "age_silver_min", age, 60, age <= 60)

    # 2) VOLUME : l'index contient-il ce que silver annonce ? Le corpus a-t-il brusquement changé de taille ?
    attendus = con.execute("SELECT count(*) FROM silver.rag_chunks WHERE indexable").fetchone()[0]
    presents = q.count(collection_servie(q), exact=True).count
    ecart = abs(attendus - presents) / max(1, attendus)
    noter("volume", "ecart_index_silver", ecart, 0.01, ecart <= 0.01, f"{presents} points / {attendus} attendus")
    moy, ecart_type, n_hist = con.execute("""
        SELECT avg(valeur), stddev_samp(valeur), count(*) FROM obs.metriques_rag
        WHERE indicateur = 'chunks_indexables' AND mesure_le > now() - INTERVAL 7 DAY""").fetchone()
    z = (attendus - moy) / ecart_type if n_hist and n_hist >= 10 and ecart_type else 0.0
    noter("volume", "chunks_indexables", attendus, 0, True)
    noter("volume", "zscore_chunks", z, 3, abs(z) <= 3)

    # 3) SCHÉMA : la table de chunks et le registre CDC ont-ils changé de forme ?
    colonnes = con.execute("""SELECT column_name, data_type FROM information_schema.columns
                              WHERE table_schema = 'silver' AND table_name = 'rag_chunks'
                              ORDER BY ordinal_position""").fetchall()
    empreinte = hashlib.sha256(repr(colonnes).encode()).hexdigest()[:16]
    precedente = con.execute("""SELECT detail FROM obs.metriques_rag WHERE indicateur = 'schema_rag_chunks'
                                ORDER BY mesure_le DESC LIMIT 1""").fetchone()
    noter("schema", "schema_rag_chunks", 0, 0, precedente is None or precedente[0] == empreinte, empreinte)
    cles = {k for (liste,) in con.execute("""SELECT DISTINCT json_keys(apres) FROM bronze.cdc_evenements
                                             WHERE _topic = 'breval.ged.documents' AND apres IS NOT NULL""").fetchall()
            for k in liste}
    noter("schema", "cles_inattendues_ged", len(cles - CLES_GED), 0, not (cles - CLES_GED),
          ",".join(sorted(cles - CLES_GED)) or None)

    # 4) QUALITÉ : PII résiduelles, qualité de récupération, fuites de droits
    pii = con.execute(f"SELECT count(*) FROM silver.rag_chunks WHERE regexp_matches(texte_indexe, '{TEL}')").fetchone()[0]
    noter("qualite", "pii_residuelles", pii, 0, pii == 0)
    con.execute("""CREATE TABLE IF NOT EXISTS obs.evaluations (run_id VARCHAR, evalue_le TIMESTAMPTZ,
                   collection VARCHAR, chunking_v VARCHAR, modele_v VARCHAR, k INTEGER, n INTEGER,
                   recall DOUBLE, mrr DOUBLE, fuites INTEGER)""")          # même définition que rag/evaluation.py
    recall, fuites = con.execute("""SELECT recall, fuites FROM obs.evaluations
                                    ORDER BY evalue_le DESC LIMIT 1""").fetchone() or (0, 0)
    noter("qualite", "recall_at_5", recall, 0.8, recall >= 0.8)
    noter("qualite", "fuites_droits", fuites, 0, fuites == 0)

    # 5) LIGNAGE : tout chunk indexable remonte-t-il à une source vivante ?
    orphelins = con.execute("""
        SELECT count(*) FROM silver.rag_chunks c WHERE c.indexable AND c.doc_id NOT IN (
            SELECT doc_id FROM silver.rag_documents_courants UNION ALL SELECT ticket_id FROM silver.rag_tickets_a_indexer)
    """).fetchone()[0]
    noter("lignage", "chunks_orphelins", orphelins, 0, orphelins == 0)

    con.executemany("INSERT INTO obs.metriques_rag (pilier, indicateur, valeur, seuil, ok, detail) "
                    "VALUES (?, ?, ?, ?, ?, ?)", m)
    return [f"[{p.upper()}] {i} = {v:g} (seuil {s:g}){' · ' + d if d else ''}" for p, i, v, s, ok, d in m if not ok]


if __name__ == "__main__":
    con = connexion_duckdb()
    print("\n".join(mesurer(con)) or "Aucune anomalie sur les 5 piliers")
    con.close()
```

Un flux calme pose un problème de fraîcheur : si personne ne modifie la GED pendant un week-end, aucun événement n'arrive, et l'on ne distingue plus « rien ne se passe » de « la chaîne est cassée ». Activez le **heartbeat** de Debezium, qui publie un message périodique et fait aussi avancer le slot quand les tables suivies sont inactives (propriété `heartbeat.interval.ms`, à vérifier dans la doc du connecteur) :

```bash
curl -s -X PUT -H "Content-Type: application/json" http://localhost:8083/connectors/breval-postgres/config \
  --data "$(python -c "import json; c = json.load(open('cdc/connecteur-breval.json'))['config']; c['heartbeat.interval.ms'] = '60000'; print(json.dumps(c))")"
```

Le **tableau de bord** peut rester simple : trois requêtes DuckDB suffisent pour la soutenance (ou le rapport Elementary de L173, si vous l'avez branché sur le projet dbt).

```sql
-- État des 5 piliers à la dernière mesure
SELECT pilier, indicateur, valeur, seuil, ok, detail FROM obs.metriques_rag
WHERE mesure_le = (SELECT max(mesure_le) FROM obs.metriques_rag) ORDER BY ok, pilier;
-- Tendance de la qualité de récupération
SELECT date_trunc('day', evalue_le) AS jour, avg(recall) AS recall_5, avg(mrr) AS mrr, max(fuites) AS fuites
FROM obs.evaluations GROUP BY ALL ORDER BY jour;
-- Où en est chaque document (table gold de L182)
SELECT statut, source_type, count(*) FROM gold.rag_suivi_documents GROUP BY ALL ORDER BY 3 DESC;
```

> ⚠️ **Piège fréquent** — Des moniteurs qui sonnent tout le temps. Un z-score sur le volume déclenchera chaque lundi matin si l'activité SAV est saisonnière (L173), et l'équipe finira par couper les alertes. Ajustez les seuils après deux semaines d'historique, et distinguez **avertissement** (canal d'équipe) et **incident** (astreinte).

## 3. Un incident simulé, puis son post-mortem

C5.6 exige qu'« un incident simulé soit détecté, diagnostiqué et documenté ». Scénario : Kafka Connect s'arrête pendant la nuit.

```bash
docker compose stop connect                          # 1) la panne
python ingestion/ged_simulateur.py supprimer PRC-030 # 2) un document est retiré pendant la panne
sleep 360 && make moniteurs                          # 3) détection : slot inactif, WAL retenu en hausse
python -m rag.recherche sandrine "assistant IA interne"   # PRC-030 est toujours cité : SLO violé
docker compose start connect                         # 4) remédiation : Debezium reprend au dernier LSN confirmé
tail -1 data/rag/audit/suppressions.jsonl            # 5) la suppression est appliquée, latence = durée de la panne
python ingestion/ged_simulateur.py restaurer PRC-030
```

Rien n'est perdu : le slot de réplication a **retenu** le WAL pendant la panne, et Debezium reprend exactement où il s'était arrêté. C'est précisément pourquoi un slot abandonné est dangereux (le disque se remplit) et pourquoi on le surveille. Rédigez ensuite le post-mortem, **sans recherche de coupable** :

```markdown
# Post-mortem — suppression de PRC-030 propagée en 7 min (SLO 5 min) — <date>
## Résumé            — une phrase : quoi, combien de temps, quel impact
## Chronologie       — heure de la panne, de la suppression, de la détection, de la remédiation, du retour à la normale
## Détection         — quel moniteur a sonné (slot_debezium_actif), au bout de combien de temps ; aurait-on pu détecter plus tôt ?
## Impact            — document cité à tort pendant N minutes ; utilisateurs concernés (journaux de l'assistant)
## Cause             — arrêt du conteneur connect ; pourquoi n'a-t-il pas redémarré seul ?
## Actions           — restart: unless-stopped ; alerte slot inactif > 2 min en astreinte ; test de panne mensuel
```

## 4. Combien coûte un document ?

Les durées de chaque étape sont déjà mesurées dans `obs.etapes` (L182). Le script les combine avec des hypothèses **explicites**, que vous remplacerez par vos propres valeurs sourcées :

```python
# couts/cout_par_document.py — coût par document, local et cloud, à partir des durées MESURÉES dans obs.etapes
import os

from rag.config import DIMENSION, connexion_duckdb

H = {   # Hypothèses : remplacez-les par VOS valeurs et citez leur source dans le dossier (C5.6)
    "puissance_w": float(os.environ.get("COUT_PUISSANCE_W", "65")),        # poste sous charge : à mesurer (wattmètre)
    "prix_kwh_eur": float(os.environ.get("COUT_PRIX_KWH_EUR", "0.25")),    # votre contrat d'électricité
    "amortissement_eur_h": float(os.environ.get("COUT_AMORT_EUR_H", "0.05")),  # prix machine / heures d'usage prévues
    "embed_api_usd_par_m": 0.10,                                           # Mistral Embed (L089, nov. 2026)
    "eur_par_usd": float(os.environ.get("COUT_EUR_PAR_USD", "0.9")),       # taux du jour : à mettre à jour
    "runs_par_mois": 4 * 13 * 26,                                          # toutes les 15 min, 7 h-19 h, lun.-sam.
}

con = connexion_duckdb(read_only=True)
runs = con.execute("""
    SELECT run_id, sum(duree_s) AS duree, max(nb_elements) FILTER (WHERE etape = 'extraction_pii') AS sources,
           sum(tokens) FILTER (WHERE etape = 'embeddings') AS tokens_embed, min(debut) AS debut
    FROM obs.etapes GROUP BY run_id ORDER BY duree DESC""").fetchall()
complet, courant = runs[0], runs[-1]                 # le plus long (initial) et le plus court (incrémental type)


def cout_local(secondes: float) -> float:
    heures = secondes / 3600
    return heures * (H["puissance_w"] / 1000 * H["prix_kwh_eur"] + H["amortissement_eur_h"])


print(f"{'':28s}{'durée (s)':>11s}{'coût local (€)':>16s}{'€ / 1 000 sources':>19s}")
for nom, (_, duree, sources, _, _) in [("exécution complète", complet), ("exécution incrémentale", courant)]:
    c = cout_local(duree)
    print(f"{nom:28s}{duree:11.0f}{c:16.4f}{1000 * c / max(1, sources or 1):19.4f}")

for etape, duree, n in con.execute("""SELECT etape, sum(duree_s), sum(nb_elements) FROM obs.etapes
                                      WHERE run_id = ? GROUP BY etape ORDER BY 2 DESC""", [complet[0]]).fetchall():
    print(f"  {etape:24s}{duree:9.1f} s  {n:>9,d} éléments  ({100 * duree / complet[1]:.0f} % du temps)")

api = (complet[3] or 0) / 1e6 * H["embed_api_usd_par_m"] * H["eur_par_usd"]
points = con.execute("SELECT count(*) FROM silver.rag_chunks WHERE indexable").fetchone()[0]
print(f"\nEmbeddings par API au lieu du local : ≈ {api:.2f} € pour une indexation complète ({complet[3] or 0:,} tokens)")
print(f"Vecteurs en mémoire (float32) : {points * DIMENSION * 4 / 1e6:.0f} Mo pour {points:,} points")
print(f"Fonctionnement mensuel local : ≈ {H['runs_par_mois'] * cout_local(courant[1]):.2f} € "
      f"({H['runs_par_mois']} exécutions incrémentales), hors temps humain d'exploitation")
```

```bash
make couts
```

Lisez le résultat en trois temps. **Où passe le temps ?** La répartition par étape dit quoi optimiser : sur ce corpus, attendez-vous à ce que la pseudonymisation de la première exécution et les embeddings sur CPU dominent, et à ce que l'exécution incrémentale ne dure que quelques secondes. **Local ou API ?** Le calcul montre que l'API d'embeddings coûterait quelques centimes pour tout le corpus : le vrai coût n'est pas l'API, c'est la ré-indexation complète à chaque changement de modèle ou de clé de pseudonymisation, et surtout le temps humain d'exploitation. **Et à l'échelle ?** Multipliez par vos hypothèses de croissance (L180) : × 10 en volume ne change ni l'architecture ni l'ordre de grandeur du coût, ce qui est un argument pour rester sur DuckDB et une seule collection.

| Poste | Local (poste ou serveur) | Cloud managé | Ce qui fait varier |
|---|---|---|---|
| Calcul (Presidio, chunking, embeddings) | électricité + amortissement, mesurés | instances ou services facturés au temps | nombre de sources modifiées, modèle d'embedding |
| Embeddings par API | — | ≈ 0,10 $ / M tokens (Mistral Embed, nov. 2026) | ré-indexations complètes |
| Stockage (MinIO, Parquet, DuckDB) | disque | tarif objet par Go-mois + requêtes + sortie (L156) | rétention, versions d'objets |
| Base vectorielle | RAM : ≈ 38 Mo de vecteurs | offre managée au Go de RAM ou au point | dimension, quantification (L178) |
| Exploitation | astreinte, mises à jour, tests de panne | réduite, pas nulle | qualité du runbook |

> 💡 **Autrement dit** — Pour une PME, la facture d'un RAG bien conçu tient plus de l'heure d'ingénieur que de la ligne de cloud. Un pipeline incrémental, testé et documenté coûte peu à faire tourner ; un pipeline qu'il faut relancer à la main et déboguer chaque semaine coûte cher, même gratuit en licences.

```quiz
{
  "q": "Le comité de direction de Bréval demande s'il faut passer les embeddings sur une API payante « pour réduire les coûts ». Quelle réponse est la mieux fondée ?",
  "options": ["Oui : le calcul local coûte toujours plus cher qu'une API à l'usage", "Non : une API facturée au token revient toujours plus cher que le local", "Coût d'API négligeable : on tranche sur la confidentialité et la dépendance", "Il faut d'abord passer à Spark pour réduire le coût de chaque indexation"],
  "answer": 2,
  "explanation": "Avec environ 0,8 million de tokens et 0,10 $ par million, le coût d'API est négligeable. Les vrais critères sont ailleurs : données pseudonymisées mais internes envoyées à un tiers (et sa localisation), dépendance à un fournisseur, coût des ré-indexations, temps d'exploitation."
}
```

## 5. Documenter : ce que l'astreinte lira à 3 h du matin

Le dépôt livré contient quatre documents : le **dossier d'architecture** (L180, mis à jour avec vos mesures), le **contrat** `contrats/rag_chunks.odcs.yaml`, la documentation dbt (`dbt docs generate`, avec son graphe de lignage) et le **runbook**. Squelette de ce dernier :

```markdown
# Runbook — Bréval Assist (v1, <date>) · responsable : <nom> · canal : #breval-assist
## 0. Carte du système      — schéma de L180, ports, services, où sont les journaux (docker compose logs <service>)
## 1. Démarrer / arrêter    — make plateforme, make connecteur, make cdc, make indexeur, make dagster-rag ; ordre d'arrêt inverse
## 2. Alertes → actions
| Alerte                          | Diagnostic                                         | Action |
| slot_debezium_actif = 0         | curl :8083/connectors/breval-postgres/status        | redémarrer connect ; si le slot est orphelin, le supprimer (pg_drop_replication_slot) APRÈS accord |
| wal_retenu_mo > 100             | slot actif ? connecteur en erreur ?                 | idem ; vérifier l'espace disque Postgres |
| retard_indexeur_messages > 50   | indexeur arrêté ? Qdrant joignable ?                | relancer make indexeur ; les suppressions sont rejouées (idempotentes) |
| ecart_index_silver > 1 %        | run Dagster en échec ? index restauré ?             | relancer rag_quart_heure ; à défaut, reconstruire (§3) |
| pii_residuelles > 0             | gold.rag_suivi_documents, rapport GX                | NE PAS forcer : corriger le reconnaisseur, relancer, documenter |
| fuites_droits > 0               | evaluation : questions et payloads fautifs          | INCIDENT SÉCURITÉ : basculer l'alias sur la dernière collection saine, prévenir le DPO |
| recall_at_5 < 0,80              | questions ratées par type                           | analyser avant de changer un paramètre ; jamais en production directement |
## 3. Procédures
- Reconstruire Qdrant : nouvelle collection depuis le cache d'embeddings (python -m rag.index), évaluer, basculer l'alias
- Demande d'effacement : ged_simulateur.py effacer-client (ou l'outil RGPD) ; vérifier 0 point ; purger les versions
  d'objets MinIO et les exports bruts concernés ; consigner la preuve (date, périmètre)
- Rotation de PII_HMAC_KEY : planifiée, hors heures ouvrées ; ré-embedding complet dans une nouvelle collection + bascule
- Changement de modèle d'embedding : L183 §6.4
- Document supprimé par erreur : restaurer la version d'objet MinIO + ligne de registre (ged_simulateur.py restaurer)
## 4. Contacts et escalade    — propriétaire des données, DPO, hébergeur
```

```mission
{
  "title": "Le risque fournisseur de votre orchestrateur",
  "url": "https://dagster.io/blog/prefect-is-acquiring-dagster",
  "steps": ["Ouvrez l'annonce publiée sur le blog de Dagster", "Repérez la date et l'acquéreur", "Cherchez ce qui est annoncé pour la marque et pour le projet open source"],
  "question": "Qui rachète Dagster, quand l'annonce a-t-elle été faite et que devient le projet open source selon elle ?",
  "hint": "L'acquéreur est un autre orchestrateur Python présenté en L164.",
  "answer": "Prefect, annonce du 13 juillet 2026 ; la marque Dagster est conservée et le projet open source est présenté comme activement développé (à suivre dans la section « Risques » de votre dossier) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 6. La soutenance : 15 minutes de preuves

| Minute | Contenu | Preuve montrée |
|---|---|---|
| 0-2 | Le besoin de Bréval et les trois échecs du prototype (fraîcheur, droits, PII) | une question qui citait une procédure périmée |
| 2-4 | Architecture et choix justifiés | schéma de L180, table de décision chiffrée |
| 4-9 | **Démonstration en direct** | supprimer un document → disparition en secondes (`tail` de l'audit) ; Alice vs Sandrine sur NOTE-002 ; graphe Dagster ; un run incrémental à 0 |
| 9-11 | Qualité et gouvernance | contrat ODCS, blocage GX démontré, rappel PII ≥ 90 %, taux de doublons |
| 11-13 | Évaluation et exploitation | recall@5 / MRR des deux chunkings, 0 fuite ; incident simulé et post-mortem ; coût par document |
| 13-15 | Limites et suite | recherche hybride pour les numéros de commande, heartbeat, passage en production |

Préparez une **grille de preuves** qui reprend la pondération du cahier des charges ; le jury doit pouvoir rejouer chaque ligne :

| Critère (poids) | Preuve rejouable |
|---|---|
| Bout en bout (25 %) | `make plateforme connecteur`, puis une matérialisation complète dans Dagster |
| Idempotence et CDC (20 %) | `pytest tests_pipeline/test_idempotence.py` puis `pytest tests_pipeline/test_rag.py -k "idempotente or suppression"` |
| Qualité, gouvernance, PII (20 %) | `datacontract test`, `python qualite/gx_chunks.py`, rapport `evaluer_pii.py`, `gold.rag_qualite_corpus` |
| Évaluation RAG (15 %) | `python -m rag.evaluation` sur les deux collections, `test_cloisonnement` |
| Observabilité et coûts (10 %) | `make moniteurs`, post-mortem, `make couts` |
| Documentation et soutenance (10 %) | dossier, runbook, contrat, `dbt docs` |

Questions fréquentes du jury, à préparer : « Que se passe-t-il si Kafka perd ses données ? » (le bronze est dédoublonné, l'état se recalcule ; l'instantané Debezium repeuple) ; « Pourquoi ne pas tout faire en flux ? » (coût de complexité, SLO de modification d'une heure suffisant) ; « Comment savez-vous qu'il n'y a pas de fuite ? » (filtre pendant la recherche, test sur cinq profils, métrique à chaque run, verrou dans Dagster) ; « Que changeriez-vous à 100 fois le volume ? » (embeddings Ray, quantification, partitionnement du bronze, état d'index tenu dans une table plutôt qu'un `scroll` complet).

> 💡 **À retenir** — Ce projet couvre une part importante des domaines des certifications du marché : préparation des données pour l'IA (section 4.2 du Google Professional Data Engineer), ingestion, stockage, sécurité et opérations (AWS DEA-C01), ingestion et gouvernance (Databricks Data Engineer Associate), modèles et tests dbt. Il en est une **préparation** solide et une expérience à valoriser, pas un équivalent : chaque examen exige en plus la maîtrise des services de son éditeur.

| Erreur fréquente | Conséquence | Parade |
|---|---|---|
| Exécuteur parallèle avec DuckDB | runs en échec aléatoire (verrou) | `in_process_executor` ou base serveur (Postgres) pour les tables partagées |
| Consommateurs CDC lancés « à la main » en production | arrêt silencieux au premier redémarrage du serveur | conteneurs avec politique de redémarrage, moniteur de retard |
| Pas de heartbeat Debezium | WAL qui grossit sur une base active mais des tables suivies calmes ; fraîcheur illisible | `heartbeat.interval.ms` |
| Coûts « estimés » sans mesure | chiffres invérifiables en soutenance | durées issues d'`obs.etapes`, hypothèses écrites et sourcées |
| Runbook qui décrit le code au lieu des gestes | inutilisable pendant un incident | tableau alerte → diagnostic → action |

## 🧪 Exercice pratique

**Consigne** — Livrez le projet : (1) `defs_rag.py` planifié, avec une exécution complète puis trois exécutions incrémentales réussies ; (2) `make moniteurs` vert sur les cinq piliers, puis l'incident simulé de la section 3 détecté par au moins un moniteur ; (3) le post-mortem de cet incident ; (4) la sortie de `make couts` commentée en dix lignes dans le dossier ; (5) le runbook complété ; (6) une répétition chronométrée de la soutenance (15 min) avec la grille de preuves.

**Critères de réussite** — Le graphe Dagster va des sources à `moniteurs` ; une exécution sans changement ne vectorise ni n'insère rien ; un échec GX provoqué bloque l'indexation et déclenche l'alerte ; au moins un indicateur par pilier est historisé dans `obs.metriques_rag` ; le post-mortem contient chronologie, détection, impact, cause et au moins deux actions ; le coût par document s'appuie sur des durées mesurées et des hypothèses écrites ; la soutenance tient en 15 minutes et chaque critère de la grille a sa preuve rejouable.

**Pistes de corrigé** — Pour provoquer l'échec GX sans tricher, injectez un téléphone dans un document source (`ged_simulateur.py ajouter` d'un fichier Markdown contenant « appelez le 0639981234 ») : si votre reconnaisseur rate cette écriture, GX la rattrape et bloque, ce qui est exactement le rôle d'un second filet ; corrigez ensuite le reconnaisseur. Si le z-score sonne dès la deuxième mesure, c'est normal : il n'a de sens qu'à partir de dix mesures d'historique (condition dans le code).

## ✅ Auto-évaluation express
1. Pourquoi les consommateurs CDC ne sont-ils pas des assets Dagster ?
2. Citez un indicateur par pilier d'observabilité pour Bréval Assist.
3. Quel est, d'après vos mesures, le principal poste de coût d'un RAG de PME, et pourquoi ?

**Réponses** — 1. Ce sont des processus permanents, à faible latence ; un orchestrateur de lots les lancerait par intervalles et casserait le SLO de suppression. Ils sont supervisés par leurs propres moniteurs (retard, slot). 2. Fraîcheur : p95 des suppressions ; volume : écart index / silver ; schéma : empreinte des colonnes de `rag_chunks` ; qualité : fuites de droits ou PII résiduelles ; lignage : chunks orphelins. 3. Rarement l'API d'embeddings (quelques centimes) : le calcul des ré-indexations complètes et surtout le temps humain d'exploitation, que l'incrémental, les tests et le runbook réduisent.

## 📚 Pour aller plus loin
- [Dagster — documentation](https://docs.dagster.io/) 🇬🇧 — assets, dagster-dbt, exécuteurs, capteurs, planifications.
- [Apache Airflow — Announcements](https://airflow.apache.org/announcements/) 🇬🇧 — si votre entreprise standardise sur Airflow 3, le même graphe s'écrit avec des assets et le Task SDK (L164).
- [Elementary](https://docs.elementary-data.com/) 🇬🇧 — tests d'anomalies et rapport d'observabilité sur le projet dbt.
- [OpenLineage — Object model](https://openlineage.io/docs/spec/object-model) 🇬🇧 — pour exporter le lignage vers un catalogue d'entreprise.
- [dbt — Source freshness](https://docs.getdbt.com/docs/deploy/source-freshness) 🇬🇧 — fraîcheur déclarative des sources bronze.
- [Google Cloud — Professional Data Engineer](https://cloud.google.com/certification/data-engineer) 🇬🇧 — une certification à préparer ensuite, avec les services de l'éditeur.

> 🗺️ **Et maintenant ?** — Le projet est livré et soutenu ; il ne reste que l'examen de certification du niveau 5, qui reprend, en mises en situation, tout ce que ce chantier vous a fait pratiquer, de la modélisation de M31 à l'exploitation de cette leçon.
