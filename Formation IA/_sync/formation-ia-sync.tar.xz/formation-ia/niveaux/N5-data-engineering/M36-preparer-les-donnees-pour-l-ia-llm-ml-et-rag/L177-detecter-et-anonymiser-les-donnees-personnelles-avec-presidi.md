---
id: L177
module: M36
level: N5
title: "Détecter et anonymiser les données personnelles avec Presidio (reconnaisseurs français : NIR, IBAN, téléphone)"
minutes: 40
objectives:
  - "Expliquer l'architecture de Presidio (analyseur, reconnaisseurs, moteur NLP, anonymiseur) et ses limites"
  - "Configurer Presidio pour le français avec un modèle spaCy et ajouter des reconnaisseurs NIR, IBAN, téléphone et e-mail"
  - "Appliquer des opérateurs de masquage, de remplacement, de pseudonymisation cohérente et de chiffrement réversible"
  - "Évaluer le rappel de la détection sur un jeu annoté et l'intégrer au pipeline entre bronze et silver"
skills: ["C5.5", "C5.4"]
sources:
  - { title: "Microsoft Presidio — Data Protection and De-identification SDK", url: "https://microsoft.github.io/presidio", lang: "en" }
  - { title: "spaCy — modèles français", url: "https://spacy.io/models/fr", lang: "en" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "CNIL — Développement des systèmes d'IA : recommandations RGPD", url: "https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd", lang: "fr" }
  - { title: "UPPMAX LLM workshop — Data pipelines", url: "https://uppmax.github.io/LLM-workshop/day2/data_pipelines", lang: "en" }
---

# Détecter et anonymiser les données personnelles avec Presidio (reconnaisseurs français : NIR, IBAN, téléphone)

> ⏱ 40 min · 🎯 Niveau 5 · 📚 Module 36

## 🎯 Ce que vous saurez faire
- Faire reconnaître à Presidio un numéro de sécurité sociale (NIR), un IBAN et un téléphone **français**, avec vérification des clés de contrôle.
- Transformer « Mme Claire Martin, 06 12 34 56 78, IBAN FR76… » en « <PERSONNE_3f9a>, <TELEPHONE>, <IBAN> » de façon cohérente dans tout le corpus.
- Prouver, chiffres à l'appui, que votre détection atteint le seuil du référentiel (≥ 90 % des PII du jeu de test détectées).

> 🧭 **En clair** — Avant d'envoyer des courriers clients à la reprographie, une secrétaire passe au feutre noir les numéros de sécurité sociale et les coordonnées bancaires. Presidio est ce feutre, automatisé : il **lit** le texte, **repère** ce qui ressemble à une donnée personnelle (nom, téléphone, IBAN…) et la **remplace** par une étiquette. Pour le français, il faut lui apprendre nos formats : le numéro de sécurité sociale à 15 chiffres, l'IBAN qui commence par FR76, le 06 des portables. Et comme aucun feutre automatique n'est parfait, on **mesure** ce qu'il rate.

## 1. Pourquoi, et où dans le pipeline

Les tickets SAV de Bréval Matériaux (la PME fil rouge du niveau) contiennent des téléphones glissés dans le texte libre (environ 15 % des tickets du jeu de L152), et les procédures internes nomment leurs responsables avec leur téléphone (L151). Un vrai outil SAV contient en plus des IBAN pour les remboursements, parfois un NIR (un client qui joint une attestation de mutuelle), des noms et adresses : les exemples de cette leçon les ajoutent. Le RGPD impose la **minimisation** (L174) ; la CNIL recommande, dans ses fiches pratiques IA, de pseudonymiser ou d'écarter les données personnelles inutiles à la finalité dès la constitution du jeu de données. Le pipeline type, rappelé par la recherche du niveau : ingestion brute (bronze) → **anonymisation PII en ETL** avant silver → transformations → *serving* (marts, features, index vectoriel).

```
apres_minhash.jsonl  ──▶ ANALYZER (spaCy fr + reconnaisseurs FR) ──▶ entités détectées (type, début, fin, score)
                                                                            │
                           ANONYMIZER (opérateurs par type) ◀───────────────┘
                                   │
                                   ▼
                     silver_tickets.jsonl (texte pseudonymisé) ──▶ chunking, embeddings (L178)
```

## 2. L'architecture de Presidio

**Presidio** est un SDK open source de Microsoft, en deux briques principales :

| Brique | Rôle |
|---|---|
| **Analyzer** (`presidio-analyzer`) | détecte les entités : combine un **moteur NLP** (spaCy, Stanza ou transformers) pour les noms et lieux, et des **reconnaisseurs** à motifs (expressions régulières + listes de mots de contexte + fonction de validation) |
| **Anonymizer** (`presidio-anonymizer`) | applique un **opérateur** par type d'entité : `replace`, `mask`, `redact`, `hash`, `encrypt` (réversible avec la clé), ou une fonction personnalisée |

Chaque détection reçoit un **score** de confiance entre 0 et 1. Un mot de contexte proche (« IBAN », « sécu », « tél ») augmente le score ; une fonction de validation (clé de contrôle) peut le porter au maximum ou annuler la détection.

> ⚠️ **Piège fréquent** — Croire que Presidio « parle français » après `pip install`. La plupart des reconnaisseurs fournis sont déclarés pour l'anglais, et le NER (reconnaissance d'entités nommées) dépend du modèle de langue chargé. Sans configuration, un texte français est analysé avec un modèle anglais : les noms sont mal détectés et les formats français ignorés.

```quiz
{
  "q": "Dans Presidio, quelle brique décide qu'un numéro détecté comme IBAN sera remplacé par <IBAN> plutôt que masqué par des étoiles ?",
  "options": ["Le moteur NLP spaCy", "Le reconnaisseur IBAN", "L'anonymiseur, via l'opérateur choisi pour ce type d'entité", "La fonction de validation de la clé de contrôle (modulo 97) de l'IBAN"],
  "answer": 2,
  "explanation": "L'analyseur ne fait que détecter (type, position, score). C'est l'anonymiseur qui applique, entité par entité, l'opérateur choisi : replace, mask, hash, encrypt ou personnalisé."
}
```

## 3. Configurer Presidio pour le français

```bash
pip install presidio-analyzer presidio-anonymizer
python -m spacy download fr_core_news_lg     # modèle français (noms, lieux, organisations)
```

### 3.1 Le reconnaisseur NIR, avec clé de contrôle

Le NIR compte 13 chiffres + une **clé** de 2 chiffres : sexe (1), année (2), mois (2), département (2, avec 2A/2B pour la Corse), commune (3), rang (3). La clé vaut **97 − (nombre à 13 chiffres modulo 97)**, en remplaçant 2A par 19 et 2B par 18. Vérifier la clé élimine presque tous les faux positifs (un numéro de commande de 15 chiffres a environ une chance sur 97 d'avoir une clé valide).

```python
# reconnaisseurs_fr.py — reconnaisseurs Presidio pour les formats français
import re
from presidio_analyzer import Pattern, PatternRecognizer

class NirRecognizer(PatternRecognizer):
    """Numéro de sécurité sociale français (NIR), 15 caractères, espaces tolérés."""
    MOTIF = r"\b[1-478]\s?\d{2}\s?(?:0[1-9]|1[0-2]|[2-9]\d)\s?(?:\d{2}|2[AaBb])\s?\d{3}\s?\d{3}\s?\d{2}\b"

    def __init__(self):
        super().__init__(
            supported_entity="FR_NIR",
            supported_language="fr",
            patterns=[Pattern("nir", self.MOTIF, 0.5)],
            context=["sécurité sociale", "sécu", "nir", "numéro ss", "insee", "assuré"],
        )

    def validate_result(self, pattern_text: str) -> bool:
        brut = re.sub(r"\s", "", pattern_text).upper()
        corps, cle = brut[:13], int(brut[13:])
        corps = corps.replace("2A", "19").replace("2B", "18")
        return 97 - (int(corps) % 97) == cle
```

### 3.2 Assembler l'analyseur : spaCy français + IBAN, téléphone, e-mail, NIR

Presidio fournit des reconnaisseurs IBAN (avec validation modulo 97), téléphone (fondé sur la bibliothèque `phonenumbers`) et e-mail ; il suffit de les **instancier pour le français** et la région FR.

```python
# analyseur_fr.py
from presidio_analyzer import AnalyzerEngine
from presidio_analyzer.nlp_engine import NlpEngineProvider
from presidio_analyzer.predefined_recognizers import EmailRecognizer, IbanRecognizer, PhoneRecognizer
from reconnaisseurs_fr import NirRecognizer

CONFIG_NLP = {
    "nlp_engine_name": "spacy",
    "models": [{"lang_code": "fr", "model_name": "fr_core_news_lg"}],
    "ner_model_configuration": {
        "model_to_presidio_entity_mapping": {"PER": "PERSON", "LOC": "LOCATION", "ORG": "ORGANIZATION"},
        "labels_to_ignore": ["MISC"],
    },
}

def creer_analyseur() -> AnalyzerEngine:
    moteur_nlp = NlpEngineProvider(nlp_configuration=CONFIG_NLP).create_engine()
    analyseur = AnalyzerEngine(nlp_engine=moteur_nlp, supported_languages=["fr"])
    analyseur.registry.add_recognizer(NirRecognizer())
    analyseur.registry.add_recognizer(IbanRecognizer(supported_language="fr",
                                                     context=["iban", "rib", "virement", "remboursement"]))
    analyseur.registry.add_recognizer(PhoneRecognizer(supported_language="fr", supported_regions=("FR",),
                                                      context=["tél", "téléphone", "portable", "joindre"]))
    analyseur.registry.add_recognizer(EmailRecognizer(supported_language="fr"))
    return analyseur

if __name__ == "__main__":
    a = creer_analyseur()
    texte = ("Bonjour, je suis Claire Martin (Lyon). Mon numéro de sécu : 2 85 05 69 123 456 88. "
             "Remboursez sur FR76 3000 6000 0112 3456 7890 189, ou appelez le 06 12 34 56 78 / claire.martin@exemple.fr")
    for r in sorted(a.analyze(text=texte, language="fr"), key=lambda r: r.start):
        print(f"{r.entity_type:13} {r.score:.2f}  {texte[r.start:r.end]!r}")
```

Le NIR d'exemple est construit pour avoir une clé valide ; changez un chiffre et il disparaît des résultats : c'est la validation qui agit. Les signatures exactes des classes peuvent varier selon les versions : vérifiez la page « Supporting new languages » et la liste des reconnaisseurs dans la [documentation Presidio](https://microsoft.github.io/presidio).

> 💡 **Autrement dit** — L'expression régulière dit « ça a la **forme** d'un numéro de sécu », les mots de contexte disent « on en **parle** juste à côté », et la clé de contrôle dit « c'est **mathématiquement** un vrai numéro ». Les trois ensemble donnent une détection fiable.

```mission
{
  "title": "Ajouter une langue à Presidio",
  "url": "https://microsoft.github.io/presidio",
  "steps": ["Ouvrez la documentation officielle de Presidio", "Dans la partie Analyzer, ouvrez la page consacrée au support multilingue (« Supporting new languages » ou équivalent)", "Repérez comment déclarer un modèle spaCy pour une langue et la liste des langues supportées par l'analyseur"],
  "question": "Quels deux réglages faut-il faire pour analyser du texte français, et quel paramètre passe-t-on à analyze() ?",
  "hint": "Il y a une configuration du moteur NLP et un paramètre du constructeur AnalyzerEngine.",
  "answer": "Déclarer un modèle français dans la configuration du moteur NLP (ex. spaCy fr_core_news_lg) et passer supported_languages=[\"fr\"] à AnalyzerEngine ; puis appeler analyze(..., language=\"fr\"). Les reconnaisseurs à motifs doivent eux aussi être déclarés pour \"fr\" (documentation consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Anonymiser : choisir l'opérateur selon l'usage

| Opérateur | Résultat | Réversible ? | Usage dans le pipeline |
|---|---|---|---|
| `replace` | `<IBAN>` | non | corpus RAG et fine-tuning : le modèle n'a pas besoin du vrai IBAN |
| `mask` | `06 •• •• •• 78` | non | affichage partiel pour un agent du SAV |
| `hash` | empreinte | non (mais attaque par dictionnaire possible sur les formats courts) | jointures statistiques ; préférez un HMAC à clé |
| **pseudonyme cohérent** (opérateur personnalisé, HMAC) | `<PERSONNE_3f9a>` identique partout pour la même personne | non sans la clé | garder le fil d'une conversation sans l'identité |
| `encrypt` | texte chiffré (AES) | **oui**, avec la clé (`DeanonymizeEngine`) | réidentification autorisée et tracée (litige, demande d'accès) |

```python
# anonymiser.py — pseudonymisation cohérente + remplacement + chiffrement réversible
import hashlib
import hmac
import json
import os
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig
from analyseur_fr import creer_analyseur

CLE_PSEUDO = os.environ["PII_HMAC_KEY"].encode()        # secret (≥ 32 caractères), jamais dans Git
CLE_AES = os.environ["PII_AES_KEY"]                      # 16, 24 ou 32 caractères pour AES

def pseudonyme(prefixe: str):
    return lambda valeur: f"<{prefixe}_{hmac.new(CLE_PSEUDO, valeur.lower().encode(), hashlib.sha256).hexdigest()[:6]}>"

OPERATEURS = {
    "PERSON":        OperatorConfig("custom", {"lambda": pseudonyme("PERSONNE")}),
    "EMAIL_ADDRESS": OperatorConfig("custom", {"lambda": pseudonyme("EMAIL")}),
    "PHONE_NUMBER":  OperatorConfig("replace", {"new_value": "<TELEPHONE>"}),
    "IBAN_CODE":     OperatorConfig("encrypt", {"key": CLE_AES}),   # réversible pour la comptabilité
    "FR_NIR":        OperatorConfig("replace", {"new_value": "<NIR>"}),
    "LOCATION":      OperatorConfig("keep"),                         # la ville est utile au SAV (choix documenté)
    "DEFAULT":       OperatorConfig("replace", {"new_value": "<PII>"}),
}

analyseur, anonymiseur = creer_analyseur(), AnonymizerEngine()

def anonymiser(texte: str) -> tuple[str, list[str]]:
    resultats = analyseur.analyze(text=texte, language="fr", score_threshold=0.4)
    sortie = anonymiseur.anonymize(text=texte, analyzer_results=resultats, operators=OPERATEURS)
    return sortie.text, sorted({r.entity_type for r in resultats})

# Entrée : le corpus dédoublonné de L176 (tickets ET documents : les procédures citent aussi des noms et téléphones, L151)
with open("corpus/apres_minhash.jsonl", encoding="utf-8") as fe, \
     open("corpus/silver_tickets.jsonl", "w", encoding="utf-8") as fs:
    for ligne in fe:
        doc = json.loads(ligne)
        doc["texte"], doc["pii_detectees"] = anonymiser(doc["texte"])
        doc["pii_traitement"] = "presidio+fr v1"              # tracé dans le manifeste et le lignage
        fs.write(json.dumps(doc, ensure_ascii=False) + "\n")
```

> ⚠️ **Piège fréquent** — Utiliser un `hash` SHA-256 simple sur des téléphones : il n'existe que quelques centaines de millions de numéros français, qu'un attaquant peut tous hacher en quelques minutes pour retrouver l'original. Une pseudonymisation sûre utilise une **clé secrète** (HMAC) conservée hors du pipeline — et reste une donnée personnelle au sens du RGPD (L174).

## 5. Mesurer : rappel ≥ 90 %, sinon pas de mise en production

Une détection de PII se juge surtout à son **rappel** (part des vraies PII trouvées) : une PII manquée finit dans l'index RAG. La **précision** (part des détections qui sont de vraies PII) compte aussi : trop de faux positifs détruisent l'information utile (« Garage du Centre » remplacé par `<PII>`).

```python
# evaluer_pii.py — rappel et précision par type sur un jeu annoté à la main
# Format d'une ligne de evals/pii_annote.jsonl :
# {"texte": "...", "entites": [{"type": "PHONE_NUMBER", "debut": 41, "fin": 55}, ...]}
import json
from collections import Counter
from analyseur_fr import creer_analyseur

a = creer_analyseur()
vp, fn, fp = Counter(), Counter(), Counter()

def chevauche(x, y):
    return x["debut"] < y["fin"] and y["debut"] < x["fin"]

for ligne in open("evals/pii_annote.jsonl", encoding="utf-8"):
    ex = json.loads(ligne)
    predits = [{"type": r.entity_type, "debut": r.start, "fin": r.end}
               for r in a.analyze(text=ex["texte"], language="fr", score_threshold=0.4)]
    for verite in ex["entites"]:
        if any(p["type"] == verite["type"] and chevauche(p, verite) for p in predits):
            vp[verite["type"]] += 1
        else:
            fn[verite["type"]] += 1
            print("MANQUÉ", verite["type"], repr(ex["texte"][verite["debut"]:verite["fin"]]))
    for p in predits:
        if not any(p["type"] == v["type"] and chevauche(p, v) for v in ex["entites"]):
            fp[p["type"]] += 1

for t in sorted(set(vp) | set(fn) | set(fp)):
    rappel = vp[t] / max(1, vp[t] + fn[t])
    precision = vp[t] / max(1, vp[t] + fp[t])
    print(f"{t:14} rappel {rappel:.0%}  précision {precision:.0%}  {'OK' if rappel >= 0.9 else 'À AMÉLIORER'}")
```

Les leviers quand le rappel est insuffisant : baisser `score_threshold`, enrichir les mots de contexte, ajouter des motifs (téléphone écrit « 06.12.34.56.78 », « +33 6 »…), passer à un modèle NER plus grand ou à un modèle transformers, ou ajouter un second passage par un LLM **local** pour les cas ambigus. Pour la précision : listes d'autorisation (raisons sociales de vos clients professionnels, noms de produits), ou désactivation d'un type d'entité inutile.

```quiz
{
  "type": "vrai_faux",
  "q": "Pour un corpus destiné à un index RAG, il vaut mieux privilégier le rappel de la détection de PII, quitte à masquer quelques mots inoffensifs.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai : une PII manquée se retrouve copiée dans les chunks, les embeddings et potentiellement les réponses. Un faux positif coûte un peu d'information ; on le corrige ensuite avec des listes d'autorisation."
}
```

## 6. 🎮 Défi : le feutre noir

Sans exécuter de code, dites ce que Presidio configuré ci-dessus devrait détecter dans : « Commande 102938475610234 livrée chez M. Petit, 12 rue des Lilas, 59000 Lille. Tél +33 6 98 76 54 32. » *Réponse attendue : M. Petit (PERSON), Lille et peut-être « rue des Lilas » (LOCATION, si le modèle les reconnaît), le téléphone au format international (PHONE_NUMBER). Le numéro de commande à 15 chiffres ne doit pas être pris pour un NIR (il a la forme d'un NIR — sexe « 1 », année « 02 », mois « 93 » accepté par le motif — mais sa clé « 34 » est fausse, la bonne serait « 55 » : la validation l'écarte). L'adresse complète (numéro et rue) n'est pas couverte par défaut : il faut un reconnaisseur dédié — bon sujet d'exercice.*

## 🧪 Exercice pratique

**Consigne** : constituez `evals/pii_annote.jsonl` avec **40 phrases** réalistes de tickets SAV (inventées, aucune donnée réelle) contenant au total au moins 60 PII : noms, téléphones dans 4 formats, IBAN FR avec et sans espaces, NIR valides et invalides, e-mails, adresses. Lancez `evaluer_pii.py`, puis améliorez la configuration jusqu'à **≥ 90 % de rappel** sur chaque type requis. Ajoutez un reconnaisseur `FR_ADRESSE` (motif « numéro + type de voie + nom ») et intégrez `anonymiser.py` comme étape entre bronze et silver de votre pipeline.

**Critères de réussite** : tableau rappel/précision par type avant et après amélioration ; aucun NIR à clé invalide détecté ; pseudonymes cohérents (la même personne citée dans deux tickets reçoit le même `<PERSONNE_xxxxxx>`) ; clés lues depuis l'environnement.

**Pistes de corrigé** : motif d'adresse `\b\d{1,4}(?:\s?(?:bis|ter))?\s(?:rue|avenue|av\.|boulevard|bd|chemin|allée|impasse|place|route)\s[\w' -]{2,40}` avec contexte « adresse », « domicile », « livrée » ; pour les téléphones, `PhoneRecognizer` gère les formats nationaux et internationaux, mais ajoutez un motif de secours pour « 06.12.34.56.78 » si votre version le manque. Générez des NIR valides en calculant la clé avec la formule du §3.1.

## ✅ Auto-évaluation express
1. Quels sont les trois mécanismes qui fiabilisent la détection d'un NIR ?
2. Quel opérateur choisir pour pouvoir réidentifier un IBAN en cas de litige ?
3. Pourquoi le rappel est-il l'indicateur principal ?

**Réponses** : 1. Le motif (expression régulière), les mots de contexte et la validation de la clé (97 − n mod 97, Corse 2A/2B → 19/18). 2. `encrypt` (AES), déchiffrable avec la clé via le moteur de désanonymisation, dans un processus tracé. 3. Parce qu'une donnée personnelle non détectée se propage dans toutes les couches dérivées (chunks, embeddings, réponses), alors qu'un faux positif ne fait perdre qu'un peu d'information.

## 📚 Pour aller plus loin
- [Microsoft Presidio](https://microsoft.github.io/presidio) 🇬🇧 — analyseur, anonymiseur, ajout de reconnaisseurs, support multilingue, rédaction d'images.
- [spaCy — modèles français](https://spacy.io/models/fr) 🇬🇧 — tailles et performances des modèles `fr_core_news_*`.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — minimisation et sécurité des jeux de données.
- [CNIL — Recommandations RGPD pour les systèmes d'IA](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd) 🇫🇷
- [UPPMAX — Data pipelines](https://uppmax.github.io/LLM-workshop/day2/data_pipelines) 🇬🇧 — place du retrait des PII dans les chaînes de pré- et post-entraînement.

> 🗺️ **Et maintenant ?** — Le corpus est propre, unique et pseudonymisé : la leçon L178 le découpe, le vectorise par lots et l'installe dans une base vectorielle dimensionnée pour la production.
