---
id: L179
module: M36
level: N5
title: "Features, versions et données synthétiques : Feast (point-in-time), DVC, lakeFS, SDV et génération par LLM"
minutes: 45
objectives:
  - "Expliquer la fuite de données temporelle et construire un jeu d'entraînement par jointure point-in-time (DuckDB ASOF JOIN, puis Feast)"
  - "Définir entités et feature views Feast, matérialiser vers l'online store et servir des features en ligne"
  - "Versionner jeux de données et pipelines avec DVC, et isoler des expériences sur le lac de données avec les branches lakeFS"
  - "Générer des données tabulaires synthétiques avec SDV et un jeu d'évaluation RAG par LLM, puis en évaluer la qualité et la confidentialité"
skills: ["C5.5"]
sources:
  - { title: "Feast — documentation (index llms.txt)", url: "https://docs.feast.dev/llms.txt", lang: "en" }
  - { title: "Feast — Feature repository", url: "https://docs.feast.dev/getting-started/concepts/feature-repo", lang: "en" }
  - { title: "DVC", url: "https://dvc.org/home/", lang: "en" }
  - { title: "lakeFS — documentation", url: "https://docs.lakefs.io", lang: "en" }
  - { title: "SDV — documentation", url: "https://docs.sdv.dev/sdv", lang: "en" }
  - { title: "Self-Instruct (arXiv 2212.10560)", url: "https://arxiv.org/abs/2212.10560", lang: "en" }
  - { title: "NVIDIA NeMo Curator — synthetic data", url: "https://docs.nvidia.com/nemo/curator/latest/curate-text/synthetic.md", lang: "en" }
---

# Features, versions et données synthétiques : Feast (point-in-time), DVC, lakeFS, SDV et génération par LLM

> ⏱ 45 min · 🎯 Niveau 5 · 📚 Module 36

## 🎯 Ce que vous saurez faire
- Préparer, pour un modèle de prédiction d'attrition (*churn*) des clients de Bréval Matériaux (la PME fil rouge du niveau), des features calculées **telles qu'elles étaient connues** à chaque date, sans tricher avec le futur.
- Retrouver dans six mois **exactement** le corpus, les chunks et les features qui ont servi à un modèle ou à un index.
- Fabriquer des données réalistes mais fictives : une base de démonstration multi-tables et un jeu de questions d'évaluation pour le RAG.

> 🧭 **En clair** — Trois outils, trois soucis du quotidien. **Feast** est le garde-manger étiqueté d'une cuisine : chaque ingrédient (une *feature*, comme « nombre de commandes sur 90 jours ») y est rangé avec sa date, pour qu'on ne cuisine jamais la recette d'hier avec les courses de demain. **DVC** et **lakeFS** sont les albums photo datés de vos données : on peut revenir à la version du 5 novembre, ou essayer une variante sur une copie sans abîmer l'original. **SDV** et les LLM fabriquent des **doublures** : des données qui ressemblent aux vraies, pour tester ou évaluer, sans exposer de vrais clients.

## 1. La fuite temporelle et la jointure *point-in-time*

Vous voulez prédire, chaque 1er du mois, quels clients risquent de ne plus commander. Pour l'entraînement, chaque **étiquette** (le client a-t-il commandé dans les 60 jours suivant le 1er mars ?) doit être associée aux features **connues au 1er mars**, pas à celles d'aujourd'hui. Utiliser le « nombre de tickets SAV ouverts » d'aujourd'hui pour expliquer une attrition de mars, c'est donner au modèle des informations du futur : il brillera à l'entraînement et échouera en production. C'est la **fuite de données** (*data leakage*) temporelle.

La solution : une jointure **point-in-time** (« à date ») : pour chaque couple (client, date d'étiquette), on prend la **dernière** valeur de feature dont l'horodatage est **antérieur ou égal** à la date de l'étiquette.

```
features de client 1 :   01/01 [nb_cmd=5]      01/02 [nb_cmd=7]      01/03 [nb_cmd=2]      01/04 [nb_cmd=0]
étiquette :                                                    ▲ 15/03 → on prend la valeur du 01/03 (2), jamais celle du 01/04
```

DuckDB fait cela nativement avec `ASOF JOIN`, ce qui permet de comprendre le principe avant tout outil :

```python
# point_in_time.py — features quotidiennes par client puis jointure à date (pip install duckdb)
import duckdb

con = duckdb.connect("data/breval.duckdb")      # tables simplifiées de L170
con.execute("""
-- 1) Une ligne de features par client et par jour (fenêtre glissante de 90 jours)
CREATE OR REPLACE TABLE stats_clients AS
WITH jours AS (
  SELECT c.id AS client_id, d::TIMESTAMP AS event_timestamp
  FROM clients c, range(TIMESTAMP '2026-09-01', TIMESTAMP '2026-11-01', INTERVAL 1 DAY) t(d)
)
SELECT j.client_id, j.event_timestamp,
       count(DISTINCT co.id)                               AS nb_commandes_90j,
       coalesce(avg(co.montant_ttc), 0)::FLOAT             AS panier_moyen_90j,
       (SELECT count(*) FROM tickets_sav t
         WHERE t.client_id = j.client_id AND t.statut = 'ouvert'
           AND t.cree_le <= j.event_timestamp)             AS nb_tickets_ouverts,
       now()                                               AS cree_le
FROM jours j
LEFT JOIN commandes co
  ON co.client_id = j.client_id
 AND co.cree_le <= j.event_timestamp                       -- uniquement le passé
 AND co.cree_le >  j.event_timestamp - INTERVAL 90 DAY
GROUP BY ALL;

-- 2) Les étiquettes à prédire (ici fictives)
CREATE OR REPLACE TABLE etiquettes AS
SELECT * FROM (VALUES (1, TIMESTAMP '2026-10-15', false), (2, TIMESTAMP '2026-10-20', true),
                      (3, TIMESTAMP '2026-10-31', false)) t(client_id, date_etiquette, a_churne);
""")
print(con.sql("""
SELECT e.client_id, e.date_etiquette, s.event_timestamp AS feature_du,
       s.nb_commandes_90j, s.panier_moyen_90j, s.nb_tickets_ouverts, e.a_churne
FROM etiquettes e
ASOF JOIN stats_clients s
  ON e.client_id = s.client_id AND e.date_etiquette >= s.event_timestamp
ORDER BY e.client_id
"""))
con.execute("COPY stats_clients TO 'stats_clients.parquet' (FORMAT parquet)")   # source Feast (§2)
```

> 💡 **Autrement dit** — La jointure à date répond à la question : « Si j'avais pris la photo de ce client **ce jour-là**, qu'aurais-je vu ? » Tout ce qui est arrivé après la photo est interdit.

```quiz
{
  "q": "Pour entraîner le modèle d'attrition au 1er mars, vous joignez chaque client à son « nombre de tickets SAV ouverts » calculé aujourd'hui. Quel est le problème ?",
  "options": ["Aucun : le nombre de tickets est une bonne feature, quelle que soit sa date", "Une fuite temporelle : la feature reflète des faits postérieurs au 1er mars", "Un problème de déduplication MinHash", "Une violation du contrat ODCS sur le schéma de la table des tickets SAV"],
  "answer": 1,
  "explanation": "La feature doit refléter ce qui était connu au 1er mars. Utiliser la valeur actuelle injecte le futur dans l'entraînement : les scores sont flatteurs mais le modèle échoue en production."
}
```

## 2. Feast : le *feature store* open source

Quand plusieurs modèles réutilisent les mêmes features, et qu'il faut les servir **en ligne** en quelques millisecondes (scorer un client à l'ouverture de sa fiche dans le CRM), on passe à un ***feature store***. **Feast** (open source) organise :

| Notion | Rôle |
|---|---|
| **Entité** | la clé métier (ici `client`, clé de jointure `client_id`) |
| **Source** | où lire les valeurs historiques (Parquet, entrepôt…) avec leur horodatage |
| **Feature view** | un groupe de features d'une entité, avec une durée de validité (*ttl*) |
| **Offline store** | l'historique, pour construire des jeux d'entraînement par jointure point-in-time |
| **Online store** | la dernière valeur par entité, pour l'inférence temps réel (SQLite en local, Redis, Postgres… en production) |
| **Matérialisation** | la copie périodique offline → online |

```bash
pip install feast
feast init breval_features && cd breval_features/feature_repo   # crée un dépôt d'exemple et son feature_store.yaml
cp ../../stats_clients.parquet data/                       # la source produite au §1
```

```python
# breval_features/feature_repo/clients.py — remplace l'exemple généré (supprimez example_repo.py)
from datetime import timedelta
from feast import Entity, FeatureView, Field, FileSource
from feast.types import Float32, Int64

client = Entity(name="client", join_keys=["client_id"], description="Client de la PME")

source_stats = FileSource(
    name="stats_clients_source",
    path="data/stats_clients.parquet",
    timestamp_field="event_timestamp",
    created_timestamp_column="cree_le",
)

stats_clients = FeatureView(
    name="stats_clients",
    entities=[client],
    ttl=timedelta(days=90),                  # au-delà, la valeur est considérée comme absente
    schema=[
        Field(name="nb_commandes_90j", dtype=Int64),
        Field(name="panier_moyen_90j", dtype=Float32),
        Field(name="nb_tickets_ouverts", dtype=Int64),
    ],
    source=source_stats,
    online=True,
    tags={"proprietaire": "equipe-data", "contient_pii": "non"},
)
```

```python
# entrainement_et_service.py — à lancer dans feature_repo/ après `feast apply`
from datetime import datetime
import pandas as pd
from feast import FeatureStore

store = FeatureStore(repo_path=".")
FEATURES = ["stats_clients:nb_commandes_90j", "stats_clients:panier_moyen_90j", "stats_clients:nb_tickets_ouverts"]

# 1) Jeu d'entraînement : jointure point-in-time faite par Feast
etiquettes = pd.DataFrame({
    "client_id": [1, 2, 3],
    "event_timestamp": pd.to_datetime(["2026-10-15", "2026-10-20", "2026-10-31"]),
    "a_churne": [False, True, False],
})
train = store.get_historical_features(entity_df=etiquettes, features=FEATURES).to_df()
print(train)

# 2) Matérialisation vers l'online store, puis lecture « temps réel »
store.materialize_incremental(end_date=datetime(2026, 11, 1))
print(store.get_online_features(features=FEATURES, entity_rows=[{"client_id": 1}]).to_dict())
```

Feast documente aussi des tutoriels **RAG** et des *online stores* vectoriels (la référence « Vector Database », en **alpha**, liste Pgvector, Elasticsearch, Milvus, Faiss, SQLite, Qdrant, ScyllaDB et Pinecone ; vérifié le 5 nov. 2026). La version courante de Feast n'a pas été confirmée lors de la rédaction : consultez la page *releases* avant de figer vos dépendances.

> ⚠️ **Piège fréquent** — Calculer les features différemment à l'entraînement (SQL dans un notebook) et en production (code Python dans l'API) : c'est le ***training-serving skew***. Le modèle reçoit en production des valeurs qui n'ont pas la même définition. Un feature store, ou au minimum **une seule** définition versionnée (le modèle dbt ou le SQL du §1), l'évite.

```mission
{
  "title": "Les online stores vectoriels de Feast",
  "url": "https://docs.feast.dev/llms.txt",
  "steps": ["Ouvrez l'index de la documentation Feast (llms.txt)", "Cherchez les pages consacrées au RAG et aux bases vectorielles", "Notez les online stores qui prennent en charge la recherche vectorielle et le statut de la fonctionnalité"],
  "question": "Quels online stores Feast cite-t-il pour la recherche vectorielle, et quel est le statut de la référence « Vector Database » ?",
  "hint": "Suivez le lien « [Alpha] Vector Database » de l'index : huit noms, dont trois bases déjà vues en L178.",
  "answer": "La page « [Alpha] Vector Database » liste Pgvector, Elasticsearch, Milvus, Faiss, SQLite, Qdrant, ScyllaDB et Pinecone ; la fonctionnalité est en alpha (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Versionner les données : DVC et lakeFS

Git versionne le code, pas des Parquet de plusieurs gigaoctets. Deux approches complémentaires, toutes deux utilisables avec le **MinIO** du Docker Compose :

| | **DVC** | **lakeFS** |
|---|---|---|
| Principe | des petits fichiers pointeurs (`.dvc`) dans Git ; les données dans un stockage distant | « Git pour le lac de données » : branches, commits, merges **directement sur le stockage objet** |
| Unité | fichiers et dossiers d'un projet | tout un dépôt de données (des milliers de tables) |
| Bonus | pipelines reproductibles (`dvc.yaml`, `dvc repro`) | expériences isolées, retour arrière atomique, accès S3 compatible |
| Idéal pour | projet ML/RAG d'une équipe | plateforme de données partagée |

### 3.1 DVC : un corpus et un pipeline reproductibles

```bash
pip install "dvc[s3]"
git init && dvc init
dvc remote add -d minio s3://dvc-store
dvc remote modify minio endpointurl http://localhost:9000
dvc remote modify --local minio access_key_id "$MINIO_ROOT_USER"        # --local : hors de Git
dvc remote modify --local minio secret_access_key "$MINIO_ROOT_PASSWORD"
```

```yaml
# dvc.yaml — le pipeline M36 de bout en bout ; `dvc repro` ne relance que les étapes dont les entrées ont changé
stages:
  corpus:
    cmd: python construire_corpus.py
    deps: [construire_corpus.py, filtres.py, data/raw/documents, data/raw/sav]
    outs: [corpus/silver_filtre.jsonl, corpus/silver]
  dedup:
    cmd: python minhash_lsh.py
    deps: [minhash_lsh.py, corpus/silver_filtre.jsonl]
    outs: [corpus/apres_minhash.jsonl]
  pii:
    cmd: python anonymiser.py
    deps: [anonymiser.py, analyseur_fr.py, corpus/apres_minhash.jsonl]
    outs: [corpus/silver_tickets.jsonl]
  chunks:
    cmd: python chunker.py
    deps: [chunker.py, corpus/silver_tickets.jsonl]
    outs: [corpus/chunks.parquet]
```

```bash
dvc repro && git add dvc.yaml dvc.lock .gitignore && git commit -m "corpus v2026-11-05" && dvc push
git tag corpus-2026-11-05                      # dans six mois : git checkout corpus-2026-11-05 && dvc pull
```

### 3.2 lakeFS : une branche pour expérimenter un nouveau seuil de déduplication

```bash
# lakeFS en mode démonstration (stockage local intégré), interface sur http://localhost:8000
docker run --name lakefs --rm -p 8000:8000 treeverse/lakefs:latest run --quickstart
# (créez des identifiants dans l'interface puis configurez lakectl : lakectl config)
lakectl branch create lakefs://quickstart/exp-dedup-055 --source lakefs://quickstart/main
lakectl fs upload lakefs://quickstart/exp-dedup-055/corpus/apres_minhash.jsonl --source corpus/apres_minhash.jsonl
lakectl commit lakefs://quickstart/exp-dedup-055 -m "MinHash b=20 r=5 (seuil ~0,55)"
lakectl diff lakefs://quickstart/main lakefs://quickstart/exp-dedup-055
lakectl merge lakefs://quickstart/exp-dedup-055 lakefs://quickstart/main   # seulement si l'évaluation est meilleure
```

DuckDB, Spark ou Polars lisent ensuite `s3://quickstart/main/corpus/...` via la passerelle S3 de lakeFS : chaque branche est un préfixe, chaque commit une version immuable. Les formats de table (Iceberg, Delta, M32) offrent aussi un *time travel* par table ; lakeFS ajoute la cohérence **entre** tables.

> 💡 **À retenir** — Une version de jeu de données n'a de valeur que liée à **la version du code** qui l'a produite et **aux modèles** qui l'ont consommée. C'est exactement la traçabilité qu'attend l'article 10 de l'AI Act pour les systèmes à haut risque (L174), et le critère C5.5 « chaque jeu produit est versionné et reproductible ».

```quiz
{
  "type": "vrai_faux",
  "q": "Avec DVC, les fichiers de données volumineux sont stockés dans le dépôt Git, ce qui alourdit chaque clone.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : Git ne contient que de petits fichiers pointeurs (.dvc et dvc.lock) avec les empreintes ; les données sont poussées vers un stockage distant (ici MinIO) et récupérées à la demande avec dvc pull."
}
```

## 4. Données synthétiques : SDV et génération par LLM

### 4.1 SDV pour des tables relationnelles

Le **Synthetic Data Vault (SDV)** apprend un modèle génératif sur des tables réelles puis génère des données synthétiques ; il gère trois cas : **table unique**, **séquentiel** et **multi-tables relationnelles** (en respectant les clés étrangères), et fournit des métriques de qualité statistique et des visualisations réel/synthétique. Une édition Enterprise existe sous licence ; vérifiez la licence de l'édition communautaire avant un usage commercial.

```python
# synth_sdv.py — pip install sdv duckdb ; API SDV 1.x (vérifiez les noms sur docs.sdv.dev)
import duckdb
from sdv.metadata import Metadata
from sdv.multi_table import HMASynthesizer
from sdv.evaluation.multi_table import evaluate_quality

con = duckdb.connect("data/breval.duckdb")      # tables simplifiées de L170
# Échantillon de 300 clients (Bréval en compte 5 000) et de leurs commandes, sans les doublons d'export
reel = {"clients": con.sql("SELECT * FROM clients WHERE id <= 300").df(),
        "commandes": con.sql("SELECT DISTINCT * FROM commandes WHERE client_id <= 300").df()}

metadata = Metadata.detect_from_dataframes(reel)
metadata.set_primary_key(table_name="clients", column_name="id")
# Si la relation n'a pas été détectée automatiquement (noms différents), déclarez-la :
if not metadata.relationships:
    metadata.add_relationship(parent_table_name="clients", child_table_name="commandes",
                              parent_primary_key="id", child_foreign_key="client_id")
metadata.validate()

synth = HMASynthesizer(metadata)
synth.fit(reel)                                   # quelques centaines de clients : assez pour une démo
faux = synth.sample(scale=2)                      # deux fois plus de clients que l'échantillon réel
print(faux["clients"].head(), faux["commandes"].head(), sep="\n")
print("Score de qualité :", evaluate_quality(reel, faux, metadata).get_score())
```

**Évaluer la confidentialité** : une donnée synthétique peut **recopier** un vrai enregistrement (mémorisation). Un indicateur simple est la **distance au plus proche enregistrement réel** (*DCR*) : si de nombreuses lignes synthétiques sont à distance quasi nulle d'une ligne réelle, le générateur recopie.

```python
# dcr.py — distance de chaque ligne synthétique à la ligne réelle la plus proche (pip install scikit-learn)
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

def dcr(reel_df, faux_df, colonnes):
    sc = StandardScaler().fit(reel_df[colonnes])
    nn = NearestNeighbors(n_neighbors=1).fit(sc.transform(reel_df[colonnes]))
    distances, _ = nn.kneighbors(sc.transform(faux_df[colonnes]))
    return distances.ravel()

# Exemple : d = dcr(reel["commandes"], faux["commandes"], ["montant_ttc"]); print((d < 1e-6).mean())
```

> ⚠️ **Piège fréquent** — Croire qu'une donnée synthétique est automatiquement « anonyme ». Si le générateur a mémorisé des cas rares (le seul client de Redon avec un panier à 12 000 €), il peut les reproduire. Mesurez la DCR, retirez ou généralisez les valeurs rares avant l'apprentissage, et **étiquetez** le jeu comme synthétique dans le catalogue (L172), avec la version des données réelles d'origine.

### 4.2 Générer un jeu d'évaluation RAG avec un LLM

La génération d'**exemples d'entraînement** par LLM (graines humaines, Self-Instruct, filtrage, relecture) a été traitée en L137 (M28) ; nous ne la reprenons pas. Côté data engineering, l'usage le plus rentable est le **jeu d'évaluation** du RAG : pour chaque chunk échantillonné, un LLM **local** (aucune donnée ne sort) rédige une question dont la réponse se trouve dans ce chunk ; on obtient des paires (question, chunk attendu) pour mesurer recall@k et MRR (L093, L178). Le projet final (M37) exige 30 questions dont 10 synthétiques **relues**.

```python
# questions_eval.py — pip install openai polars ; modèle ouvert servi par Ollama (API compatible OpenAI)
import json
import os
import polars as pl
from openai import OpenAI

client = OpenAI(base_url=os.environ.get("LLM_BASE_URL", "http://localhost:11434/v1"),
                api_key=os.environ.get("LLM_API_KEY", "ollama"))
MODELE = os.environ.get("LLM_MODEL", "qwen3.8:27b")          # même modèle local qu'en L137

chunks = pl.read_parquet("corpus/chunks.parquet").sample(n=20, seed=42)
with open("evals/rag_questions_synth.jsonl", "w", encoding="utf-8") as f:
    for c in chunks.iter_rows(named=True):
        consigne = ("Voici un extrait d'un document interne d'une PME. Rédigez UNE question qu'un salarié "
                    "ou un client poserait et dont la réponse se trouve dans l'extrait, sans recopier ses phrases. "
                    'Répondez uniquement en JSON : {"question": "...", "reponse_attendue": "..."}\n\n' + c["texte"])
        rep = client.chat.completions.create(model=MODELE, messages=[{"role": "user", "content": consigne}],
                                             temperature=0.7)
        brut = rep.choices[0].message.content.strip().removeprefix("```json").removesuffix("```")
        try:
            qa = json.loads(brut)
        except json.JSONDecodeError:
            continue                                          # on jette les sorties mal formées
        f.write(json.dumps({**qa, "chunk_id_attendu": c["chunk_id"], "doc_id": c["doc_id"],
                            "origine": f"synthetique:{MODELE}", "relu": False}, ensure_ascii=False) + "\n")
```

Ensuite : relecture humaine (passer `relu` à `true`, corriger ou supprimer), **décontamination** (L176 : une question qui recopie le chunk mot pour mot rend l'évaluation trop facile), puis **versionnement** du jeu avec DVC. À plus grande échelle, NeMo Curator propose des modules de génération synthétique.

```quiz
{
  "q": "Quelle est la bonne pratique pour un jeu de questions d'évaluation RAG généré par un LLM ?",
  "options": ["L'utiliser tel quel : un LLM ne se trompe pas sur ses propres questions", "Le relire, le décontaminer, l'étiqueter comme synthétique et le versionner", "Le régénérer à chaque évaluation pour avoir plus de variété", "Le mélanger aux documents du corpus pour enrichir l'index"],
  "answer": 1,
  "explanation": "Un jeu d'évaluation doit être stable, fiable et traçable : relecture humaine, contrôle des recopies, étiquette « synthétique » et version figée. Le régénérer à chaque fois rendrait les mesures incomparables."
}
```

## 5. 🎮 Défi : l'enquête du modèle trop bon

Un stagiaire annonce un modèle d'attrition avec 99 % d'AUC. Trouvez **trois** causes possibles liées aux données, vues dans ce module. *Pistes : fuite temporelle (features calculées après la date d'étiquette, §1) ; doublons entre entraînement et test (L176) ; une feature qui encode directement la cible (« date de résiliation » renseignée) ; jeu de test synthétique trop proche du jeu d'entraînement (§4).*

## 🧪 Exercice pratique

**Consigne** : (1) produisez `stats_clients.parquet` (§1) sur une base enrichie de 300 clients synthétiques générés avec SDV ; (2) définissez le dépôt Feast, lancez `feast apply`, construisez le jeu d'entraînement par `get_historical_features` et vérifiez sur 3 lignes, à la main, qu'aucune feature n'est postérieure à la date d'étiquette ; (3) versionnez tout le pipeline M36 avec DVC (`dvc.yaml` à 4 étapes minimum) et poussez sur MinIO ; (4) générez 20 questions d'évaluation RAG, relisez-en 10 et versionnez le jeu.

**Critères de réussite** : la vérification point-in-time est documentée (tableau date d'étiquette / date de feature) ; `dvc repro` relancé sans changement n'exécute aucune étape ; `git checkout <tag> && dvc pull` restaure le corpus à l'identique (empreintes égales) ; le jeu de questions porte les champs `origine` et `relu`, et la DCR des clients synthétiques est rapportée.

**Pistes de corrigé** : si `get_historical_features` renvoie des valeurs nulles, vérifiez que `event_timestamp` des étiquettes est postérieur au premier jour de features et dans le *ttl* de 90 jours ; pour DVC, `dvc status` doit afficher « Data and pipelines are up to date » après un `repro` ; pour la DCR, une part de distances nulles supérieure à quelques pour cent signale une recopie — réduisez le nombre d'époques ou retirez les valeurs rares.

## ✅ Auto-évaluation express
1. Qu'est-ce qu'une jointure point-in-time et quel problème évite-t-elle ?
2. Quelle différence d'usage entre DVC et lakeFS ?
3. Pourquoi mesurer la distance au plus proche enregistrement réel sur des données synthétiques ?

**Réponses** : 1. Associer à chaque étiquette la dernière valeur de feature connue à sa date ; elle évite la fuite de données temporelle. 2. DVC versionne les fichiers et pipelines d'un projet à côté de Git ; lakeFS versionne tout un lac de données sur le stockage objet avec branches, commits et merges. 3. Pour détecter une mémorisation : des lignes synthétiques identiques ou quasi identiques à des lignes réelles exposent de vraies personnes.

## 📚 Pour aller plus loin
- [Feast — documentation](https://docs.feast.dev/llms.txt) 🇬🇧 — entités, feature views, point-in-time, online stores, tutoriels RAG.
- [Feast — Feature repository](https://docs.feast.dev/getting-started/concepts/feature-repo) 🇬🇧 — organisation d'un dépôt de features.
- [DVC](https://dvc.org/home/) 🇬🇧 — versionnement de données et pipelines reproductibles.
- [lakeFS — documentation](https://docs.lakefs.io) 🇬🇧 — branches et commits sur stockage objet.
- [SDV — documentation](https://docs.sdv.dev/sdv) 🇬🇧 — synthétiseurs table unique, séquentiel, multi-tables ; évaluation.
- [Self-Instruct (arXiv 2212.10560)](https://arxiv.org/abs/2212.10560) 🇬🇧 — la méthode fondatrice de génération d'instructions par LLM.
- [NeMo Curator — synthetic data](https://docs.nvidia.com/nemo/curator/latest/curate-text/synthetic.md) 🇬🇧 — génération synthétique à l'échelle.

> 🗺️ **Et maintenant ?** — Toutes les briques sont en place : le module M37 les assemble en un pipeline de données de bout en bout pour un RAG d'entreprise, à commencer par le cadrage du projet en L180.
