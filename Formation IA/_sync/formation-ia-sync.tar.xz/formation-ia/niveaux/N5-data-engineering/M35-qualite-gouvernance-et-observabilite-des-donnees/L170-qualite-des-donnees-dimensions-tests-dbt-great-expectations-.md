---
id: L170
module: M35
level: N5
title: "Qualité des données : dimensions, tests dbt, Great Expectations (GX Core) et Soda Core (SodaCL)"
minutes: 50
objectives:
  - "Identifier les six dimensions de la qualité des données et les traduire en règles mesurables sur une table métier"
  - "Écrire des tests dbt génériques, singuliers et unitaires, ainsi qu'un contrôle de fraîcheur de source"
  - "Construire une suite de validations avec GX Core et un fichier de contrôles SodaCL sur la même table"
  - "Choisir entre dbt tests, GX Core et Soda Core selon l'équipe, le moment du contrôle et l'outillage existant"
skills: ["C5.4", "C5.6"]
sources:
  - { title: "dbt — Data tests", url: "https://docs.getdbt.com/docs/build/data-tests", lang: "en" }
  - { title: "dbt — Source freshness", url: "https://docs.getdbt.com/docs/deploy/source-freshness", lang: "en" }
  - { title: "Great Expectations (GX Core)", url: "https://greatexpectations.io/", lang: "en" }
  - { title: "Soda", url: "https://soda.io/", lang: "en" }
  - { title: "DataExpert.io — Soda vs Great Expectations (14 fév. 2026)", url: "https://www.dataexpert.io/blog/soda-vs-great-expectations-data-quality-tools", lang: "en" }
  - { title: "DataDriven — Data Observability: 5 Pillars and Tools (2026)", url: "https://datadriven.io/data-observability", lang: "en" }
---

# Qualité des données : dimensions, tests dbt, Great Expectations (GX Core) et Soda Core (SodaCL)

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 35

## 🎯 Ce que vous saurez faire
- Transformer une phrase floue (« les commandes doivent être propres ») en une dizaine de règles chiffrées, rangées par dimension de qualité.
- Écrire ces règles trois fois : en tests dbt, en *Expectations* GX Core et en contrôles SodaCL, sur la base de Bréval Matériaux (la PME fil rouge du niveau).
- Décider où placer chaque contrôle dans le pipeline (à l'entrée, entre bronze et silver, avant la publication) et qui le maintient.

> 🧭 **En clair** — Une cuisine de restaurant ne sert pas un plat sans vérifier que les ingrédients sont frais, en quantité suffisante et conformes à la recette. Les données, c'est pareil : avant d'alimenter un tableau de bord, un modèle de machine learning ou un assistant RAG, on vérifie qu'elles sont complètes, exactes, à jour et sans doublon. Les tests de qualité sont les « contrôles à réception » de votre usine à données : ils bloquent la palette abîmée avant qu'elle n'arrive sur la chaîne. Cette leçon vous montre trois outils gratuits pour écrire ces contrôles, et comment choisir entre eux.

## 1. Rappel du fil rouge et des six dimensions

Tout le niveau 5 travaille sur les données de **Bréval Matériaux**, la PME fil rouge présentée en L151 (ERP Postgres `erp.*`, tickets SAV en JSONL, documents internes en Markdown avec leur fichier de métadonnées `documents.csv`). Pour que chaque exemple de ce module tienne en quelques lignes et s'exécute en une seconde, nous travaillons sur une **vue simplifiée** de ces données : trois tables aux noms de colonnes courts, construites par le script `creer_tables_qualite.py` ci-dessous à partir de la couche bronze de L152, dans le schéma `main` de l'entrepôt du niveau `data/breval.duckdb` (le fichier de M31, que dlt et dbt ont complété en M33 avec les schémas `bronze`, `silver` et `gold`) :

| Table simplifiée | Colonnes | Correspondance dans le jeu complet de L151 |
|---|---|---|
| `clients` | `id`, `nom`, `ville`, `cree_le` | `erp.clients` : `client_id`, `raison_sociale` ou `prenom` + `nom` (sans `email` ni `telephone`), `ville`, `date_creation` |
| `commandes` | `id`, `client_id`, `montant_ttc`, `statut`, `cree_le`, `maj_le` | `erp.commandes` : `commande_id`, `client_id`, `montant_ht` × 1,20 (TVA 20 %), `statut`, `date_commande`, `mis_a_jour_le` |
| `tickets_sav` | `id`, `client_id`, `sujet`, `texte`, `statut`, `cree_le` | `tickets_sav.jsonl` : `ticket_id`, `client_id`, `categorie`, `messages[1].texte` (premier message), `statut`, `ouvert_le` (heure de Paris) |

Les règles que vous écrirez se transposent telles quelles au jeu complet en changeant les noms de colonnes ; l'exercice de fin de leçon vous le fait faire. Les documents internes (procédures, CGV, fiches techniques) seront traités en M36.

La qualité ne se « sent » pas, elle se **mesure** selon des dimensions. Six d'entre elles font consensus :

| Dimension | Question posée | Règle concrète sur `commandes` |
|---|---|---|
| **Complétude** | La valeur est-elle présente ? | `client_id` jamais nul |
| **Unicité** | Chaque entité apparaît-elle une seule fois ? | `id` unique |
| **Validité** | La valeur respecte-t-elle le format ou le domaine ? | `statut` ∈ {brouillon, validee, livree, facturee, annulee} |
| **Exactitude** | La valeur reflète-t-elle la réalité ? | `montant_ttc` = somme des lignes (contrôle croisé avec la comptabilité) |
| **Cohérence** | Les données concordent-elles entre elles ? | `maj_le ≥ cree_le` ; chaque `client_id` existe dans `clients` |
| **Fraîcheur** | La donnée est-elle assez récente ? | dernière `maj_le` il y a moins de 24 h |

> 💡 **À retenir** — L'exactitude est la seule dimension qu'on ne peut presque jamais vérifier avec la table seule : il faut une **référence externe** (relevé bancaire, comptabilité, saisie manuelle d'un échantillon). Les cinq autres se testent en SQL.

> 💡 **Autrement dit** — Complétude = « rien ne manque », unicité = « pas de doublon », validité = « la forme est bonne », exactitude = « c'est vrai », cohérence = « ça colle avec le reste », fraîcheur = « c'est à jour ».

Pour que les exemples soient exécutables, créez ces tables, volontairement imparfaites : elles gardent les défauts injectés par le générateur de L152 (240 commandes exportées deux fois, 11 dates « 206x », 46 en-têtes à montant négatif issus des quantités négatives) et ajoutent trois défauts de démonstration.

```python
# creer_tables_qualite.py — tables simplifiées du module M35, dérivées du jeu Bréval (L151-L152)
# À lancer depuis breval/ après vers_bronze.py (L152) ; pip install duckdb pandas
import duckdb

con = duckdb.connect("data/breval.duckdb")      # entrepôt du niveau (M31, puis dlt et dbt en M33)
con.execute("SET TimeZone = 'Europe/Paris'")
con.execute("""
-- 1) Projection des tables de L151 (couche bronze de L152), avec des noms de colonnes courts.
--    Rien n'est corrigé : les défauts injectés par le générateur restent (doublons d'export, dates « 206x »…).
CREATE OR REPLACE TABLE clients AS
SELECT client_id                                      AS id,
       coalesce(raison_sociale, prenom || ' ' || nom) AS nom,
       ville,
       CAST(date_creation AS TIMESTAMP)               AS cree_le
FROM 'data/bronze/clients.parquet';

CREATE OR REPLACE TABLE commandes AS
SELECT commande_id                                          AS id,
       client_id,
       CAST(round(montant_ht * 1.20, 2) AS DECIMAL(12,2))   AS montant_ttc,   -- TVA 20 % (taux_tva des produits)
       statut,                                              -- brouillon, validee, livree, facturee, annulee
       date_commande                                        AS cree_le,
       mis_a_jour_le                                        AS maj_le
FROM 'data/bronze/commandes.parquet';

CREATE OR REPLACE TABLE tickets_sav AS
SELECT ticket_id                                            AS id,
       client_id,
       categorie                                            AS sujet,
       messages[1].texte                                    AS texte,         -- premier message du client
       statut,                                              -- ouvert, en_cours, resolu, clos
       CAST(timezone('Europe/Paris', ouvert_le) AS TIMESTAMP) AS cree_le      -- heure de Paris, comme l'ERP
FROM 'data/bronze/tickets_sav.parquet';

-- 2) Trois défauts de démonstration que le générateur ne produit pas (identifiants ≥ 900000, faciles à retrouver)
INSERT INTO clients VALUES (900001, 'Fleurs & Co', NULL, TIMESTAMP '2025-06-02 16:45');             -- ville manquante
INSERT INTO commandes VALUES
  (900001, 999999,  18.00, 'validee', TIMESTAMP '2026-10-03 09:00', TIMESTAMP '2026-10-03 18:00'),  -- client inexistant
  (900002,     17, 276.00, 'Livrée',  TIMESTAMP '2026-10-04 15:00', TIMESTAMP '2026-10-04 16:00');  -- statut invalide
INSERT INTO tickets_sav VALUES ('SAV-9000001', 17, 'facturation',
  'Merci de rembourser sur FR76 3000 6000 0112 3456 7890 189', 'ouvert', TIMESTAMP '2026-10-06 10:00'); -- IBAN (L177)
""")
print(con.sql("SELECT count(*) AS nb_commandes, count(DISTINCT id) AS ids_distincts FROM commandes").fetchall())
```

```quiz
{
  "q": "Une commande affiche un montant de 129,90 € alors que la facture réelle est de 139,90 €. Le format, le type et la plage sont corrects. Quelle dimension est en défaut ?",
  "options": ["La validité", "La complétude", "L'exactitude", "L'unicité"],
  "answer": 2,
  "explanation": "La valeur est bien formée et présente, mais elle ne correspond pas à la réalité : c'est un défaut d'exactitude, qui nécessite une source de référence (la facture) pour être détecté."
}
```

## 2. Les tests dbt : la qualité au plus près des transformations

Si votre pipeline ELT utilise dbt (M33), les tests dbt sont le premier filet. Ils sont gratuits, versionnés avec le code, et s'exécutent avec `dbt build` (qui enchaîne modèles et tests dans l'ordre du graphe). Un test dbt est une requête SQL qui **renvoie les lignes fautives** : zéro ligne, le test passe.

### 2.1 Tests génériques et fraîcheur de source

```yaml
# models/staging/_sources.yml — dbt 1.11 (adaptateur dbt-duckdb)
version: 2
sources:
  - name: qualite                   # tables simplifiées de creer_tables_qualite.py
    schema: main
    tables:
      - name: commandes
        loaded_at_field: maj_le
        freshness:                    # contrôle de fraîcheur : dbt source freshness
          warn_after: {count: 24, period: hour}
          error_after: {count: 48, period: hour}
        columns:
          - name: id
            data_tests: [unique, not_null]
          - name: client_id
            data_tests:
              - not_null
              - relationships:
                  arguments:          # depuis dbt 1.10, les paramètres vont sous "arguments"
                    to: source('qualite', 'clients')
                    field: id
          - name: statut
            data_tests:
              - accepted_values:
                  arguments:
                    values: ['brouillon', 'validee', 'livree', 'facturee', 'annulee']
                  config:
                    severity: error
      - name: clients
        columns:
          - name: ville
            data_tests:
              - not_null:
                  config:
                    severity: warn    # une ville manquante n'arrête pas le pipeline
```

> ⚠️ **Piège fréquent** — La syntaxe a évolué : `tests:` est devenu `data_tests:` (dbt 1.8) et les paramètres des tests génériques se placent sous `arguments:` (dbt 1.10). Les anciennes formes déclenchent des avertissements de dépréciation. Vérifiez la page [Data tests](https://docs.getdbt.com/docs/build/data-tests) pour votre version exacte.

### 2.2 Test singulier et test unitaire

Un **test singulier** est un fichier SQL libre dans `tests/` : idéal pour la cohérence entre colonnes.

```sql
-- tests/commandes_dates_coherentes.sql : renvoie les commandes modifiées "avant" leur création
select id, cree_le, maj_le
from {{ source('qualite', 'commandes') }}
where maj_le < cree_le
```

Un **test unitaire** (dbt 1.8+) vérifie la *logique* d'un modèle sur des données d'entrée fictives, sans toucher à la vraie base — l'équivalent d'un test pytest pour du SQL :

```yaml
# models/marts/_unit_tests.yml
unit_tests:
  - name: ca_client_exclut_les_annulations
    model: mart_ca_client
    given:
      - input: ref('stg_commandes')
        rows:
          - {client_id: 1, montant_ttc: 100, statut: livree}
          - {client_id: 1, montant_ttc: 50,  statut: annulee}
    expect:
      rows:
        - {client_id: 1, ca_ttc: 100}
```

Lancez `dbt source freshness` puis `dbt build`. Sur nos tables piégées, attendez-vous à voir échouer `unique` (les 240 commandes exportées deux fois), `relationships` (client 999999 de la commande 900001), `accepted_values` (« Livrée », commande 900002) et le test singulier (les 11 commandes datées « 206x », dont `maj_le` est antérieure à `cree_le`), plus un avertissement sur la ville (client 900001).

> 🔗 **Documentation officielle** — [dbt — Data tests](https://docs.getdbt.com/docs/build/data-tests) 🇬🇧 · [dbt — Source freshness](https://docs.getdbt.com/docs/deploy/source-freshness) 🇬🇧

```mission
{
  "title": "Les quatre tests génériques livrés avec dbt",
  "url": "https://docs.getdbt.com/docs/build/data-tests",
  "steps": ["Ouvrez la page « Data tests » de la documentation dbt", "Repérez la partie consacrée aux tests génériques (generic data tests)", "Listez les tests fournis « out of the box »"],
  "question": "Quels sont les quatre tests génériques fournis nativement par dbt ?",
  "hint": "Deux portent sur une colonne seule, un sur une liste de valeurs, un sur une autre table.",
  "answer": "unique, not_null, accepted_values et relationships (état de la documentation en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 3. GX Core : des « attentes » écrites en Python

**Great Expectations**, dont la partie open source s'appelle **GX Core** (licence Apache 2.0), formule chaque règle comme une *Expectation* (« j'attends que les valeurs de `montant_ttc` soient entre 0 et 50 000 »). Plus de 50 Expectations sont intégrées ; elles produisent des résultats détaillés (pourcentage de lignes fautives, exemples) et des **Data Docs** HTML lisibles par le métier. Son terrain de jeu naturel : les pipelines Python (Polars, pandas, Spark) **avant** l'entrée dans l'entrepôt, par exemple sur un fichier reçu d'un partenaire.

```python
# gx_commandes.py — pip install "great_expectations>=1.0" duckdb pandas
# API GX Core 1.x ; vérifiez les noms exacts sur greatexpectations.io si votre version diffère
import duckdb
import great_expectations as gx

df = duckdb.connect("data/breval.duckdb").sql("SELECT * FROM commandes").df()

context = gx.get_context()                                   # contexte éphémère en mémoire
source = context.data_sources.add_pandas("breval_pandas")
asset = source.add_dataframe_asset(name="commandes")
batch_def = asset.add_batch_definition_whole_dataframe("lot_complet")

suite = context.suites.add(gx.ExpectationSuite(name="commandes_qualite"))
suite.add_expectation(gx.expectations.ExpectColumnValuesToBeUnique(column="id"))
suite.add_expectation(gx.expectations.ExpectColumnValuesToNotBeNull(column="client_id"))
suite.add_expectation(gx.expectations.ExpectColumnValuesToBeBetween(
    column="montant_ttc", min_value=0, max_value=50_000))
suite.add_expectation(gx.expectations.ExpectColumnValuesToBeInSet(
    column="statut", value_set=["brouillon", "validee", "livree", "facturee", "annulee"]))
suite.add_expectation(gx.expectations.ExpectTableRowCountToBeBetween(min_value=1, max_value=1_000_000))

validation = context.validation_definitions.add(
    gx.ValidationDefinition(name="valider_commandes", data=batch_def, suite=suite))
resultat = validation.run(batch_parameters={"dataframe": df})

print("Succès global :", resultat.success)
for r in resultat.results:
    cfg = r.expectation_config
    print(f"{'OK ' if r.success else 'KO '} {cfg.type:45} {cfg.kwargs.get('column', '')}")
```

Pour bloquer réellement le pipeline, terminez le script par `raise SystemExit(1)` si `resultat.success` est faux : l'orchestrateur (Airflow, Dagster) marquera la tâche en échec et déclenchera l'alerte.

```quiz
{
  "q": "Vous recevez chaque nuit un fichier CSV d'un transporteur, que vous lisez avec Polars avant de le charger. Où un contrôle GX Core est-il le plus utile ?",
  "options": ["Après la publication du tableau de bord, pour comparer les chiffres", "Sur le DataFrame, avant le chargement en couche bronze ou silver", "Uniquement dans les tests unitaires dbt", "Dans le navigateur de l'utilisateur final"],
  "answer": 1,
  "explanation": "GX Core brille dans le code Python, au plus tôt : bloquer un fichier défectueux avant qu'il n'entre dans l'entrepôt évite de propager l'erreur à toutes les tables dérivées."
}
```

## 4. Soda Core : des contrôles déclaratifs en YAML (SodaCL)

**Soda Core** est l'outil open source de Soda ; on y écrit des contrôles dans un langage YAML appelé **SodaCL**, puis une commande `soda scan` les traduit en requêtes SQL exécutées **dans** la base (*pushdown* : les données ne sortent pas). Soda Cloud, la version commerciale, ajoute tableaux de bord, alertes et collaboration. Atout majeur : un analyste ou un *data steward* qui ne code pas en Python peut lire et modifier les règles.

```yaml
# soda/configuration.yml — pip install soda-core-duckdb
data_source breval:
  type: duckdb
  path: data/breval.duckdb        # tables simplifiées dans le schéma main
```

```yaml
# soda/checks_commandes.yml — SodaCL
checks for commandes:
  - row_count > 0
  - duplicate_count(id) = 0
  - missing_count(client_id) = 0
  - min(montant_ttc) >= 0
  - invalid_count(statut) = 0:
      valid values: [brouillon, validee, livree, facturee, annulee]
  - freshness(maj_le) < 1d
  - schema:
      fail:
        when required column missing: [id, client_id, montant_ttc, statut]
  - failed rows:
      name: maj_le postérieure à cree_le
      fail condition: maj_le < cree_le
```

```bash
soda scan -d breval -c soda/configuration.yml soda/checks_commandes.yml
# Code de sortie non nul si un contrôle échoue : exploitable en CI ou par l'orchestrateur
```

> ⚠️ **Piège fréquent** — Le contrôle `freshness(maj_le) < 1d` échouera sur notre base de démonstration, dont les dates datent d'octobre 2026 : c'est normal, et c'est même l'intérêt. Par ailleurs, Soda fait évoluer son offre (contrats de données, nouvelles versions majeures) : vérifiez sur [soda.io](https://soda.io/) que la syntaxe SodaCL ci-dessus correspond à la version que vous installez.

## 5. Choisir : trois outils, trois moments

Le comparatif publié par DataExpert.io (tiers, février 2026) résume bien l'opposition : GX est une boîte à outils Python très expressive, Soda une approche déclarative orientée équipes mixtes. Dans la pratique, beaucoup d'équipes combinent.

| Critère | dbt tests | GX Core | Soda Core |
|---|---|---|---|
| Langage des règles | YAML + SQL | Python | YAML (SodaCL) |
| Moment idéal | pendant/après chaque transformation dbt | à l'ingestion, sur DataFrames ou fichiers | sur n'importe quelle table, planifié |
| Lisible par le métier | moyen | via Data Docs HTML | bon |
| Exécution | dans l'entrepôt | en mémoire ou SQL | dans l'entrepôt (*pushdown*) |
| Coût | inclus dans dbt Core | Apache 2.0 (offre cloud payante) | OSS (Soda Cloud payant) |

Placement recommandé dans l'architecture médaillon :

```
 sources ──▶ [GX : fichier reçu conforme ?] ──▶ BRONZE ──▶ [dbt tests sur staging] ──▶ SILVER
         ──▶ [dbt tests + unit tests sur marts] ──▶ GOLD ──▶ [Soda planifié : fraîcheur, volume] ──▶ consommateurs (BI, ML, RAG)
```

> 💡 **À retenir** — Un test qui échoue doit avoir un **propriétaire** et une **sévérité** (`warn` ou `error`). Un test sans propriétaire finit ignoré, puis désactivé. Gardez peu de tests bloquants, mais des tests qui bloquent vraiment.

```quiz
{
  "type": "vrai_faux",
  "q": "Avec Soda Core, les données de la table doivent être téléchargées sur le poste qui lance le scan pour être contrôlées.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : Soda traduit les contrôles SodaCL en requêtes SQL exécutées dans la source (pushdown). Seuls les résultats agrégés et, si demandé, quelques lignes fautives remontent."
}
```

## 6. 🎮 Défi : le contrôleur qualité de la PME

Le service comptable signale : « Le chiffre d'affaires d'octobre a doublé d'un coup dans le tableau de bord. » Sans regarder le code, listez **trois** règles de qualité qui auraient détecté le problème, en précisant la dimension et l'outil. *(Pistes : unicité de `id` après une ingestion rejouée deux fois ; volume quotidien hors de la plage habituelle ; `montant_ttc` dont la médiane change brutalement.)* Le volume et la distribution relèvent de l'**observabilité** (L173) : la frontière entre tests et observabilité est poreuse.

## 🧪 Exercice pratique

**Consigne** : sur `data/breval.duckdb`, écrivez pour la table simplifiée `tickets_sav` au moins **6 règles** couvrant 5 dimensions différentes, implémentées dans **deux** outils au choix (dbt + Soda, ou GX + Soda). Ajoutez volontairement un ticket défectueux (statut « en cours » non prévu, `client_id` nul) et montrez que les contrôles le bloquent. **Bonus** : transposez trois de vos règles au fichier complet `data/bronze/tickets_sav.parquet` produit en L152 (colonnes `ticket_id`, `client_id`, `statut`, `ouvert_le`) et comptez les défauts injectés volontairement dans le jeu Bréval.

**Critères de réussite** :
- les 6 règles sont listées dans un tableau « règle / dimension / outil / sévérité / propriétaire » ;
- la commande lancée retourne un code d'échec sur la donnée défectueuse et un succès une fois la donnée corrigée ;
- au moins une règle est de sévérité `warn` et justifiée.

**Pistes de corrigé** : unicité de `id` ; complétude de `client_id` et `texte` ; validité de `statut` ∈ {ouvert, en_cours, resolu, clos} ; cohérence `client_id` → `clients.id` ; fraîcheur `cree_le` < 2 jours (warn, le SAV ne reçoit pas de tickets le week-end) ; validité de longueur : `length(texte) BETWEEN 5 AND 20000`. En Soda : `invalid_count(statut) = 0` avec `valid values`, `missing_count(texte) = 0`, `failed rows` pour la longueur.

## ✅ Auto-évaluation express
1. Quelle dimension nécessite presque toujours une source de référence externe ?
2. Que renvoie la requête d'un test dbt quand il passe ?
3. Citez un avantage de SodaCL par rapport à GX Core et un avantage inverse.

**Réponses** : 1. L'exactitude. 2. Zéro ligne (le test renvoie les lignes fautives). 3. SodaCL : déclaratif, lisible par des non-développeurs et exécuté dans la base ; GX Core : très expressif en Python, adapté aux DataFrames et aux fichiers avant chargement, Data Docs détaillées.

## 📚 Pour aller plus loin
- [dbt — Data tests](https://docs.getdbt.com/docs/build/data-tests) 🇬🇧 — tests génériques, singuliers, sévérités et configuration.
- [dbt — Source freshness](https://docs.getdbt.com/docs/deploy/source-freshness) 🇬🇧 — paramètres `warn_after` / `error_after`.
- [Great Expectations](https://greatexpectations.io/) 🇬🇧 — documentation GX Core, galerie des Expectations.
- [Soda](https://soda.io/) 🇬🇧 — documentation SodaCL et Soda Core.
- [DataExpert.io — Soda vs Great Expectations](https://www.dataexpert.io/blog/soda-vs-great-expectations-data-quality-tools) 🇬🇧 — comparatif tiers (février 2026).
- [dbt Analytics Engineering Certification](https://www.getdbt.com/certifications/analytics-engineer-certification-exam) 🇬🇧 — le thème « implémenter les tests » fait partie de l'examen (dbt 1.11) ; ce module en est une préparation, pas un équivalent.

> 🗺️ **Et maintenant ?** — Vos règles vivent pour l'instant dans votre dépôt ; la leçon L171 les promeut au rang d'**engagement** entre producteur et consommateur grâce au contrat de données ODCS.
