---
id: L171
module: M35
level: N5
title: "Contrats de données avec l'Open Data Contract Standard v3.1 et gestion de l'évolution de schéma"
minutes: 40
objectives:
  - "Expliquer à quoi sert un contrat de données et qui le signe (producteur, consommateurs)"
  - "Rédiger un contrat ODCS v3.1.0 décrivant schéma, règles de qualité, SLA, équipe et serveurs pour une table métier"
  - "Valider un contrat et le tester contre la base avec le Data Contract CLI"
  - "Classer une évolution de schéma en compatible ou cassante et appliquer la démarche expand/contract"
skills: ["C5.4"]
sources:
  - { title: "Bitol — Open Data Contract Standard (dépôt officiel)", url: "https://github.com/bitol-io/open-data-contract-standard", lang: "en" }
  - { title: "Data Contract CLI — Open Data Contract Standard", url: "https://docs.datacontract.com/docs/open-data-contract-standard.md", lang: "en" }
  - { title: "DataHub — source d'ingestion ODCS", url: "https://docs.datahub.com/docs/generated/ingestion/sources/odcs", lang: "en" }
  - { title: "dbt — Data tests", url: "https://docs.getdbt.com/docs/build/data-tests", lang: "en" }
---

# Contrats de données avec l'Open Data Contract Standard v3.1 et gestion de l'évolution de schéma

> ⏱ 40 min · 🎯 Niveau 5 · 📚 Module 35

## 🎯 Ce que vous saurez faire
- Écrire le contrat de données de la table `commandes` de Bréval Matériaux (la PME fil rouge du niveau) au format ODCS v3.1.0.
- Le vérifier automatiquement (syntaxe, puis conformité de la vraie table) dans la CI.
- Faire évoluer le schéma sans casser le tableau de bord du contrôle de gestion ni l'index RAG du SAV.

> 🧭 **En clair** — Quand une boulangerie commande sa farine, le bon de commande précise le type, la quantité, la date de livraison et ce qui se passe en cas de retard. Un contrat de données, c'est ce bon de commande entre l'équipe qui **produit** une table et celles qui la **consomment** : quelles colonnes, quel format, quelles règles de qualité, livrée à quelle heure, et qui appeler en cas de problème. Écrit dans un fichier standard (ODCS), il est lisible par les humains *et* vérifiable par les machines. Fini le « j'ai renommé une colonne, je ne pensais pas que quelqu'un s'en servait ».

## 1. Pourquoi des contrats ? Le problème des dépendances invisibles

Dans la PME, l'équipe « ventes » maintient l'application de prise de commandes. Un lundi, elle renomme `montant_ttc` en `total_ttc`. Résultat : le modèle dbt `mart_ca_client` échoue, le tableau de bord du directeur financier est vide, et l'assistant RAG qui répond aux clients (« où en est ma commande ? ») renvoie des montants nuls. Personne n'a commis de faute *technique* : il manquait un **accord explicite**.

Un contrat de données formalise cet accord. Il est :

- **déclaratif** : un fichier YAML versionné dans Git, à côté du code ;
- **exécutable** : des outils en déduisent des tests (qualité, schéma) et bloquent un déploiement non conforme ;
- **social** : il nomme un propriétaire, des canaux de support et des engagements de service (SLA).

L'**Open Data Contract Standard (ODCS)** est le format ouvert de référence. Il est maintenu par le projet **Bitol**, hébergé par la **LF AI & Data Foundation**, sous licence **Apache 2.0** ; la version courante est la **v3.1.0** (nov. 2026). Ses sections : fondamentaux, **schéma**, références, **qualité**, support et canaux, tarification, équipe, rôles, **SLA**, infrastructures et serveurs, propriétés personnalisées.

> 💡 **À retenir** — Un contrat ne remplace pas les tests : il en est la **source**. Les tests dbt, GX ou Soda de L170 peuvent être générés à partir du contrat ou rester écrits à la main, mais ils doivent dire la même chose que lui.

```quiz
{
  "q": "Quelle organisation maintient l'Open Data Contract Standard ?",
  "options": ["dbt Labs, dans dbt Core", "Le projet Bitol, hébergé par la LF AI & Data Foundation", "La CNIL, dans ses fiches pratiques sur le développement de l'IA", "Databricks, dans Unity Catalog"],
  "answer": 1,
  "explanation": "ODCS est porté par Bitol, projet de la LF AI & Data Foundation, sous licence Apache 2.0. Il est indépendant des éditeurs, ce qui permet à plusieurs outils (Data Contract CLI, DataHub…) de le lire."
}
```

## 2. Un contrat ODCS v3.1.0 complet pour `commandes`

```yaml
# contrats/commandes.odcs.yaml — Open Data Contract Standard v3.1.0
# Vérifiez les noms de champs exacts dans le schéma JSON officiel du dépôt bitol-io
apiVersion: v3.1.0
kind: DataContract
id: 5f1c2a9e-breval-commandes
name: commandes
version: 1.0.0
status: active
domain: ventes
dataProduct: ventes_commandes
description:
  purpose: "Commandes clients de Bréval Matériaux, une ligne par commande, pour la BI, le ML (churn) et l'assistant SAV."
  usage: "Lecture seule. Jointure sur clients.id via client_id."
  limitations: "Montants en euros TTC. Les commandes annulées restent présentes avec statut = annulee."

schema:
  - name: commandes
    physicalName: main.commandes
    physicalType: table
    logicalType: object
    description: "Table simplifiée des commandes (L170), dérivée de erp.commandes."
    properties:
      - name: id
        logicalType: integer
        physicalType: BIGINT
        primaryKey: true
        required: true
        unique: true
      - name: client_id
        logicalType: integer
        physicalType: BIGINT
        required: true
        description: "Référence clients.id"
      - name: montant_ttc
        logicalType: number
        physicalType: DECIMAL(12,2)
        required: true
        quality:
          - type: sql
            description: "Aucun montant négatif"
            query: "SELECT count(*) FROM main.commandes WHERE montant_ttc < 0"
            mustBe: 0
      - name: statut
        logicalType: string
        physicalType: VARCHAR
        required: true
        logicalTypeOptions:
          enum: [brouillon, validee, livree, facturee, annulee]   # à adapter si votre outil attend une règle qualité dédiée
      - name: cree_le
        logicalType: date
        physicalType: TIMESTAMP
        required: true
      - name: maj_le
        logicalType: date
        physicalType: TIMESTAMP
        required: true
    quality:
      - type: sql
        description: "Pas de commande modifiée avant sa création"
        query: "SELECT count(*) FROM main.commandes WHERE maj_le < cree_le"
        mustBe: 0
      - type: sql
        description: "Pas de doublon d'identifiant"
        query: "SELECT count(*) - count(DISTINCT id) FROM main.commandes"
        mustBe: 0

slaProperties:
  - property: latency          # délai max entre l'événement source et sa disponibilité
    value: 4
    unit: h
  - property: frequency
    value: 1
    unit: d
  - property: retention        # aligné sur la politique de conservation RGPD (L174)
    value: 10
    unit: y

team:
  - username: c.durand
    role: owner
  - username: equipe-data
    role: data_engineer

support:
  - channel: "#data-ventes"
    tool: slack

servers:
  - server: local
    type: duckdb
    path: data/breval.duckdb      # tables simplifiées de L170, schéma main
```

> ⚠️ **Piège fréquent** — Les contrats copiés d'un blog datent souvent de la v2 (structure `dataset:` et `columns:`) ou de la v3.0. La v3.x utilise `schema:` → `properties:` et `apiVersion: v3.1.0`. Validez toujours contre le schéma JSON de la version annoncée dans `apiVersion` : c'est la seule référence.

> 💡 **Autrement dit** — Le bloc `schema` dit **à quoi ressemble** la table, le bloc `quality` dit **ce qui doit toujours être vrai**, `slaProperties` dit **quand et combien de temps** elle est disponible, `team` et `support` disent **qui appeler**.

```mission
{
  "title": "Les sections officielles d'un contrat ODCS",
  "url": "https://github.com/bitol-io/open-data-contract-standard",
  "steps": ["Ouvrez le dépôt officiel bitol-io/open-data-contract-standard", "Lisez le README et repérez la version courante du standard", "Repérez la liste des sections (fundamentals, schema…) qui composent un contrat"],
  "question": "Quelle est la version courante du standard et citez au moins cinq de ses sections ?",
  "hint": "Cherchez « v3.1.0 » et la liste qui commence par « Fundamentals ».",
  "answer": "v3.1.0 (nov. 2026) ; sections : fondamentaux, schéma, références, qualité, support et canaux, tarification, équipe, rôles, SLA, infrastructures et serveurs, propriétés personnalisées (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Vérifier le contrat en CI avec le Data Contract CLI

Le **Data Contract CLI** (open source) lit les contrats ODCS, les valide, les teste contre la base décrite dans `servers`, et exporte vers d'autres formats (modèles dbt, schémas SQL, Avro…).

```bash
# pip install "datacontract-cli[duckdb]"
datacontract lint contrats/commandes.odcs.yaml          # 1) le fichier respecte-t-il le standard ?
datacontract test contrats/commandes.odcs.yaml          # 2) la table réelle respecte-t-elle le contrat ?
datacontract export --format dbt contrats/commandes.odcs.yaml > models/silver/_commandes.yml  # 3) génération
```

Sur la base piégée de L170, `test` échoue sur trois règles (montant négatif, `maj_le < cree_le`, doublon d'`id`) : exactement ce que nous voulons. Les sous-commandes et options exactes évoluent ; consultez la page [Data Contract CLI — ODCS](https://docs.datacontract.com/docs/open-data-contract-standard.md).

Une étape de CI minimaliste (GitHub Actions, GitLab CI ou tout autre exécuteur) :

```yaml
# .github/workflows/contrats.yml
name: contrats-de-donnees
on: [pull_request]
jobs:
  verifier:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install "datacontract-cli[duckdb]" duckdb
      - run: python generer_breval.py --echelle 0.05 && python vers_bronze.py && python creer_tables_qualite.py   # jeu de recette (L152, L170)
      - run: datacontract lint contrats/*.odcs.yaml
```

Enfin, le contrat devient **découvrable** : DataHub sait ingérer des contrats ODCS comme source de métadonnées ([DataHub — source ODCS](https://docs.datahub.com/docs/generated/ingestion/sources/odcs)), ce que nous exploiterons en L172.

## 4. Faire évoluer un schéma sans tout casser

Un schéma vit. La question n'est pas « faut-il changer ? » mais « ce changement est-il **compatible** pour les consommateurs actuels ? ».

| Changement | Compatible ? | Pourquoi |
|---|---|---|
| Ajouter une colonne facultative (`canal_vente`) | ✅ oui | les requêtes existantes l'ignorent |
| Élargir un type (`DECIMAL(10,2)` → `DECIMAL(12,2)`) | ✅ en général | aucune valeur existante n'est perdue |
| Ajouter une valeur à une énumération (`retournee`) | ⚠️ à annoncer | un `CASE` ou un test `accepted_values` aval peut échouer |
| Rendre obligatoire une colonne facultative | ❌ cassant pour les producteurs | les anciennes écritures sont refusées |
| Renommer ou supprimer une colonne | ❌ cassant | toutes les requêtes qui la citent échouent |
| Restreindre un type (`VARCHAR` → `INTEGER`) | ❌ cassant | valeurs existantes invalides |

On retrouve ici les modes de compatibilité du Schema Registry vus en M34 (BACKWARD, FORWARD, FULL) : même logique, appliquée aux tables.

**Règle de versionnement** : appliquez le *semantic versioning* au champ `version` du contrat — correctif (1.0.**1**) pour une description, mineure (1.**1**.0) pour un ajout compatible, majeure (**2**.0.0) pour un changement cassant, publiée avec un préavis et une période de double diffusion.

**La démarche expand/contract** pour renommer `montant_ttc` en `total_ttc` sans coupure :

```
1. EXPAND   : ajouter total_ttc, alimenter les DEUX colonnes (contrat 1.1.0, total_ttc facultative)
2. MIGRER   : prévenir les consommateurs (canal du contrat), ils basculent sur total_ttc
3. VÉRIFIER : le lignage (L172) montre qu'aucun modèle ne lit plus montant_ttc
4. CONTRACT : supprimer montant_ttc (contrat 2.0.0), après la date de préavis annoncée
```

Côté dbt, activez en plus les **contrats de modèle** (`config: contract: {enforced: true}`, vus en M33) sur les modèles publiés : dbt refuse alors de construire un modèle dont les colonnes ou types ne correspondent pas à ceux déclarés.

```quiz
{
  "q": "L'équipe ventes veut ajouter la valeur « retournee » au champ statut. Quelle est la bonne démarche ?",
  "options": ["La déployer directement : ajouter une valeur n'est jamais cassant", "Version mineure, consommateurs prévenus, accepted_values adapté avant", "Créer une nouvelle table commandes_v2 et supprimer l'ancienne le jour même", "Supprimer le test accepted_values pour éviter les échecs"],
  "answer": 1,
  "explanation": "Ajouter une valeur d'énumération est compatible sur le plan du schéma mais peut faire échouer des tests ou des CASE en aval : on l'annonce via une version mineure et on adapte les contrôles avant de produire la nouvelle valeur."
}
```

## 5. 🎮 Défi : compatible ou cassant ?

Classez en 2 minutes : (a) `ville` de `clients` passe de facultative à obligatoire ; (b) ajout de `tickets_sav.priorite` facultative ; (c) `cree_le` passe de `TIMESTAMP` à `DATE` ; (d) suppression de la colonne `clients.nom` « parce que le RAG n'en a pas besoin ».
*Réponses : (a) cassant pour les producteurs qui écrivent sans ville ; (b) compatible ; (c) cassant (perte de l'heure, requêtes de fraîcheur faussées) ; (d) cassant — et vérifiez le lignage : la facturation l'utilise sans doute.*

## 🧪 Exercice pratique

**Consigne** : rédigez le contrat ODCS v3.1.0 de la table `tickets_sav`, destinée à alimenter l'index RAG du SAV (M36). Il doit contenir : description (purpose, usage, limitations), schéma complet, au moins **3 règles de qualité** de type `sql`, **2 propriétés de SLA**, un propriétaire, un canal de support et le serveur DuckDB local. Ajoutez une propriété personnalisée signalant que `texte` contient des données personnelles.

**Critères de réussite** :
- `datacontract lint` passe sans erreur ;
- `datacontract test` échoue si vous insérez un ticket avec `client_id` nul, et passe après correction ;
- une note de 5 lignes décrit comment vous renommeriez `texte` en `contenu` sans coupure.

**Pistes de corrigé** : règles « `texte` non vide », « `statut` ∈ {ouvert, en_cours, resolu, clos} », « `client_id` existe dans `clients` » ; SLA `latency` 1 h (le SAV attend des réponses fraîches) et `retention` 3 ans après clôture ; propriété personnalisée du type `customProperties: [{property: contientDonneesPersonnelles, value: true}]` à relier à la classification de L172 et au traitement Presidio de L177. Renommage : démarche expand/contract en 4 étapes, version 1.1.0 puis 2.0.0.

## ✅ Auto-évaluation express
1. Citez trois sections d'un contrat ODCS.
2. Que vérifie `datacontract test` que `datacontract lint` ne vérifie pas ?
3. Pourquoi le renommage d'une colonne demande-t-il deux versions du contrat ?

**Réponses** : 1. Par exemple schéma, qualité, SLA (aussi équipe, rôles, support, serveurs, tarification…). 2. `lint` contrôle le fichier ; `test` se connecte au serveur et vérifie que la **vraie table** respecte schéma et règles. 3. Parce qu'il faut d'abord ajouter la nouvelle colonne en parallèle (version mineure compatible), laisser les consommateurs migrer, puis supprimer l'ancienne (version majeure cassante).

## 📚 Pour aller plus loin
- [Bitol — Open Data Contract Standard](https://github.com/bitol-io/open-data-contract-standard) 🇬🇧 — spécification, schéma JSON, exemples.
- [Data Contract CLI — ODCS](https://docs.datacontract.com/docs/open-data-contract-standard.md) 🇬🇧 — validation, tests et exports.
- [DataHub — source d'ingestion ODCS](https://docs.datahub.com/docs/generated/ingestion/sources/odcs) 🇬🇧 — publier ses contrats dans le catalogue.
- [dbt — Data tests](https://docs.getdbt.com/docs/build/data-tests) 🇬🇧 — pour aligner tests dbt et règles du contrat.

> 🗺️ **Et maintenant ?** — Un contrat n'a de valeur que s'il est trouvé : la leçon L172 range vos tables, contrats et dépendances dans un **catalogue** avec un **lignage** de bout en bout.
