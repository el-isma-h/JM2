---
id: L172
module: M35
level: N5
title: "Gouvernance, catalogues et lignage : Unity Catalog, OpenMetadata, DataHub, OpenLineage"
minutes: 50
objectives:
  - "Expliquer les rôles de la gouvernance des données (propriétaire, steward, dépositaire) et les objets qu'elle gère (glossaire, classification, politiques)"
  - "Distinguer catalogue technique (Unity Catalog OSS, Apache Polaris) et plateforme de métadonnées (OpenMetadata, DataHub)"
  - "Décrire le modèle objet OpenLineage (run, job, dataset, facettes) et émettre des événements de lignage vers Marquez"
  - "Évaluer quel outil retenir pour une PME selon la pile technique, l'effort d'exploitation et les besoins de conformité"
skills: ["C5.4"]
sources:
  - { title: "Data Lakehouse Hub — Metadata Platforms in 2026", url: "https://datalakehousehub.com/blog/metadata-platforms-in-2026/", lang: "en" }
  - { title: "OpenLineage — Object model", url: "https://openlineage.io/docs/spec/object-model", lang: "en" }
  - { title: "Unity Catalog (open source)", url: "https://www.unitycatalog.io/", lang: "en" }
  - { title: "OpenMetadata", url: "https://open-metadata.org/", lang: "en" }
  - { title: "DataHub — source d'ingestion ODCS", url: "https://docs.datahub.com/docs/generated/ingestion/sources/odcs", lang: "en" }
  - { title: "Apache Polaris", url: "https://polaris.apache.org/", lang: "en" }
---

# Gouvernance, catalogues et lignage : Unity Catalog, OpenMetadata, DataHub, OpenLineage

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 35

## 🎯 Ce que vous saurez faire
- Organiser la gouvernance de Bréval Matériaux (la PME fil rouge du niveau) : qui décide, qui documente, qui exploite chaque jeu de données.
- Choisir et démarrer en local un catalogue adapté (technique ou « plateforme de métadonnées »).
- Tracer automatiquement le chemin d'une donnée, de la table `tickets_sav` jusqu'à l'index vectoriel du RAG, grâce à OpenLineage.

> 🧭 **En clair** — Imaginez une grande médiathèque sans fichier ni étiquettes : les livres existent, mais personne ne les retrouve, personne ne sait lesquels sont en consultation restreinte, et l'on ignore d'où vient une photocopie trouvée sur une table. Un **catalogue de données** est le fichier de la médiathèque : il recense chaque table, son responsable, sa description et son niveau de confidentialité. Le **lignage** est l'arbre généalogique de chaque donnée : « ce chiffre du tableau de bord vient de cette table, calculée à partir de ces deux sources ». La **gouvernance**, enfin, ce sont les règles de la médiathèque et les bibliothécaires qui les font respecter.

## 1. Gouvernance : des rôles avant des outils

La gouvernance des données est l'ensemble des règles, rôles et processus qui garantissent que les données sont **connues, fiables, protégées et utilisées à bon escient**. Elle répond à des questions très concrètes : *qui peut lire la table `clients` ? que signifie « client actif » ? combien de temps garde-t-on un ticket SAV ?*

| Rôle | Responsabilité | Dans Bréval Matériaux |
|---|---|---|
| **Propriétaire** (*data owner*) | décide des usages, des accès, valide le contrat | directrice commerciale pour `commandes` |
| **Steward** (*data steward*) | définitions métier, glossaire, qualité au quotidien | assistante ADV qui connaît les statuts de commande |
| **Dépositaire** (*custodian*, souvent l'équipe data) | stockage, sauvegarde, sécurité technique, pipelines | vous |
| **Consommateur** | utilise la donnée dans le respect du contrat | contrôle de gestion, data scientist, assistant RAG |
| **DPO** | conformité RGPD, registre des traitements | délégué à la protection des données (interne ou mutualisé) |

Les objets que manipule la gouvernance :

- un **glossaire métier** (« Commande livrée : statut `livree` et date de livraison renseignée ») ;
- une **classification** des colonnes (`Public`, `Interne`, `Confidentiel`, `DonneePersonnelle`, `DonneeSensible`) ;
- des **politiques** d'accès et de conservation (L174) ;
- des **contrats** (L171) et des **indicateurs de qualité** (L170, L173).

> ⚠️ **Piège fréquent** — Installer un catalogue sans avoir nommé de propriétaires. Après trois mois, 400 tables sont « documentées » automatiquement par l'ingestion de métadonnées techniques, mais aucune description métier n'existe et personne ne répond aux questions. Commencez par **les 10 tables qui comptent** et leurs propriétaires.

```quiz
{
  "q": "Qui doit valider qu'un nouveau service (le marketing) peut lire la table commandes ?",
  "options": ["Le data engineer qui maintient le pipeline", "Le propriétaire de la donnée (data owner)", "N'importe quel consommateur existant", "L'outil de catalogue, automatiquement"],
  "answer": 1,
  "explanation": "Le propriétaire décide des usages et des accès. Le data engineer (dépositaire) met en œuvre techniquement la décision, et le catalogue en garde la trace."
}
```

## 2. Le paysage des catalogues en 2026

On confond souvent deux familles d'outils, qui se complètent :

```
        ┌──────────────────────── PLATEFORME DE MÉTADONNÉES ────────────────────────┐
        │  OpenMetadata / DataHub : recherche, glossaire, propriétaires, tags PII,    │
        │  lignage de bout en bout, qualité, contrats, discussions                    │
        └───────────────▲─────────────────▲──────────────────▲──────────────────────┘
                        │ ingestion        │ ingestion         │ événements OpenLineage
        ┌───────────────┴──────┐  ┌────────┴────────┐  ┌───────┴────────────────┐
        │ CATALOGUE TECHNIQUE  │  │ dbt (manifest)   │  │ Airflow, Dagster, Spark │
        │ Unity Catalog OSS,   │  │ Postgres, DuckDB │  │ scripts Python          │
        │ Apache Polaris       │  └─────────────────┘  └────────────────────────┘
        │ (où sont les tables, │
        │  qui y accède)       │
        └──────────────────────┘
```

| Outil | Nature | Statut (nov. 2026, d'après la synthèse Data Lakehouse Hub) | Pour qui |
|---|---|---|---|
| **Unity Catalog OSS** | catalogue technique + gouvernance | open source depuis 2024, hébergé par la LF AI & Data ; tables Delta et Iceberg, point d'accès Iceberg REST ; la version hébergée par Databricks ajoute lignage, tags et gouvernance avancée | équipes Spark/Delta, lakehouse |
| **Apache Polaris** | catalogue technique Iceberg | projet de premier niveau Apache depuis février 2026 (selon l'article) ; Iceberg uniquement, RBAC, fédération | lakehouse Iceberg multi-moteurs |
| **OpenMetadata** | plateforme de métadonnées | Apache 2.0, porté par l'éditeur Collate | PME/ETI qui veulent « tout-en-un » (découverte, glossaire, qualité, lignage) |
| **DataHub** | plateforme de métadonnées + catalogue | Apache 2.0, né chez LinkedIn (2020) ; v1.0 avec catalogue Iceberg REST en bêta | organisations à nombreuses sources, très extensible |

> 💡 **À retenir** — Le **catalogue technique** répond à « où est la table et qui a le droit d'y lire ? » ; il est interrogé par les moteurs (Spark, DuckDB, Trino) à chaque requête. La **plateforme de métadonnées** répond à « qu'est-ce que cette donnée, qui en est responsable, d'où vient-elle ? » ; elle est consultée par les humains et les outils de gouvernance.

> 💡 **Autrement dit** — Le catalogue technique, c'est le plan de l'entrepôt utilisé par les caristes ; la plateforme de métadonnées, c'est l'annuaire et le guide du visiteur.

### 2.1 Démarrer en local

```bash
# Unity Catalog OSS (serveur Java + CLI) — vérifiez les prérequis Java sur unitycatalog.io
git clone https://github.com/unitycatalog/unitycatalog.git && cd unitycatalog
bin/start-uc-server                       # serveur sur le port 8080
bin/uc catalog list                       # dans un autre terminal
bin/uc table list --catalog unity --schema default

# DataHub en local (Docker requis, plusieurs Go de RAM)
pip install acryl-datahub
datahub docker quickstart                 # interface sur http://localhost:9002
```

Une fois DataHub lancé, ingérez le projet dbt (fichiers `manifest.json` et `catalog.json` produits par `dbt docs generate`) et vos contrats ODCS :

```yaml
# ingestion_dbt.yml — datahub ingest -c ingestion_dbt.yml
source:
  type: dbt
  config:
    manifest_path: target/manifest.json
    catalog_path: target/catalog.json
    target_platform: duckdb
sink:
  type: datahub-rest
  config:
    server: http://localhost:8080
```

OpenMetadata se déploie de façon comparable (Docker Compose fourni par le projet) et propose des connecteurs dbt, Postgres, Airflow, etc. Pour une PME, comptez **un serveur de 8 à 16 Go de RAM** pour l'une ou l'autre plateforme (ordre de grandeur, à vérifier dans la documentation de déploiement de la version retenue).

```mission
{
  "title": "Les contrats ODCS dans DataHub",
  "url": "https://docs.datahub.com/docs/generated/ingestion/sources/odcs",
  "steps": ["Ouvrez la page de la source d'ingestion ODCS de DataHub", "Repérez le bloc d'exemple de recette (recipe)", "Notez le type de source à indiquer et ce que DataHub crée à partir du contrat"],
  "question": "Quel type de source déclarez-vous dans la recette, et quels éléments du contrat DataHub récupère-t-il ?",
  "hint": "Le type porte le nom du standard ; regardez la liste des « capabilities ».",
  "answer": "Le type « odcs » ; DataHub en tire notamment le schéma, les propriétaires, la description et les règles de qualité ou assertions associées (contenu de la page en nov. 2026, à relire car la liste évolue) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Le lignage avec OpenLineage

Le **lignage** (*lineage*) répond à deux questions vitales :
- **analyse d'impact** (vers l'aval) : « si je modifie `commandes.montant_ttc`, qu'est-ce qui casse ? » ;
- **analyse de cause** (vers l'amont) : « ce chiffre faux, d'où vient-il ? ».

Chaque outil (dbt, Airflow, Spark) connaît une partie du graphe. **OpenLineage** est le standard ouvert qui leur permet de **raconter la même histoire dans la même langue**. Son modèle objet tient en quatre notions :

| Objet | Définition | Exemple |
|---|---|---|
| **Job** | un traitement nommé, stable dans le temps | `rag.indexer_tickets` |
| **Run** | une exécution d'un job, avec un identifiant unique (UUID) | l'exécution de cette nuit, 02:00 |
| **Dataset** | une donnée lue (*input*) ou écrite (*output*) | `duckdb://breval/main.tickets_sav` → `qdrant://local/tickets_chunks` |
| **Facette** (*facet*) | un bloc de métadonnées extensible attaché à l'un des trois | schéma, nombre de lignes, version du code, lignage colonne |

Un job émet des **événements** `START`, puis `COMPLETE` ou `FAIL`, vers un serveur compatible. Le serveur de référence open source est **Marquez**. Des intégrations existent pour Airflow, Spark et dbt (`dbt-ol`, un enveloppeur de la commande dbt) ; pour vos scripts maison (comme l'indexeur RAG de M36), vous émettez les événements vous-même.

```python
# lignage_indexeur.py — émet START/COMPLETE vers Marquez (API OpenLineage /api/v1/lineage)
# Marquez en local : git clone https://github.com/MarquezProject/marquez && cd marquez && ./docker/up.sh
import datetime as dt
import uuid
import requests

MARQUEZ = "http://localhost:5000/api/v1/lineage"
PRODUCER = "urn:breval:pipeline-rag:1.0"   # identifie votre code (URI de votre choix)
# Les URL de schéma ci-dessous dépendent de la version de la spec : vérifiez-les sur openlineage.io
SCHEMA_URL = "https://openlineage.io/spec/2-0-2/OpenLineage.json#/$defs/RunEvent"

def evenement(etat: str, run_id: str, nb_chunks: int | None = None) -> dict:
    sortie = {"namespace": "qdrant://localhost:6333", "name": "tickets_chunks"}
    if nb_chunks is not None:
        sortie["outputFacets"] = {"outputStatistics": {
            "_producer": PRODUCER,
            "_schemaURL": "https://openlineage.io/spec/facets/1-0-2/OutputStatisticsOutputDatasetFacet.json",
            "rowCount": nb_chunks}}
    return {
        "eventType": etat,
        "eventTime": dt.datetime.now(dt.timezone.utc).isoformat(),
        "run": {"runId": run_id},
        "job": {"namespace": "breval-rag", "name": "indexer_tickets_sav"},
        "inputs": [{"namespace": "duckdb://breval", "name": "main.tickets_sav"}],   # table simplifiée de L170
        "outputs": [sortie],
        "producer": PRODUCER,
        "schemaURL": SCHEMA_URL,
    }

run_id = str(uuid.uuid4())
requests.post(MARQUEZ, json=evenement("START", run_id), timeout=10).raise_for_status()
nb = 1234                                  # ... ici, le vrai travail : lecture, chunking, embeddings, upsert
requests.post(MARQUEZ, json=evenement("COMPLETE", run_id, nb), timeout=10).raise_for_status()
print("Lignage envoyé ; ouvrez l'interface Marquez (http://localhost:3000)")
```

> 🔗 **Documentation officielle** — [OpenLineage — Object model](https://openlineage.io/docs/spec/object-model) 🇬🇧

> ⚠️ **Piège fréquent** — Des noms de *datasets* incohérents (`tickets_sav`, `main.tickets_sav`, `breval.main.tickets_sav`) produisent trois nœuds différents et un graphe en morceaux. Fixez une convention de `namespace` et de `name` par système (documentée dans le catalogue) **avant** d'instrumenter.

```quiz
{
  "q": "Dans le modèle OpenLineage, qu'est-ce qui distingue un « job » d'un « run » ?",
  "options": ["Le job est l'exécution identifiée par un UUID, le run la définition stable", "Le job est le traitement nommé et stable ; le run, une de ses exécutions (UUID)", "Ce sont deux synonymes, selon la version de la spécification", "Le run désigne la table de sortie, le job celle d'entrée"],
  "answer": 1,
  "explanation": "Un job (ex. indexer_tickets_sav) existe dans la durée ; chaque exécution produit un run distinct, avec ses propres événements START, COMPLETE ou FAIL et ses facettes."
}
```

## 4. Choisir pour une PME

| Situation | Choix raisonnable |
|---|---|
| Pile DuckDB + dbt + Dagster, < 50 tables, 1-2 personnes data | **documentation dbt** (`dbt docs`) + lignage d'assets de Dagster + contrats ODCS dans Git ; un catalogue complet viendra plus tard |
| Lakehouse Iceberg interrogé par plusieurs moteurs | **Apache Polaris** ou **Unity Catalog OSS** comme catalogue technique |
| Plusieurs sources (ERP, CRM, Postgres, fichiers), exigences RGPD/AI Act, besoin de glossaire et de recherche | **OpenMetadata** ou **DataHub**, alimenté par ingestion + OpenLineage |
| Plateforme Databricks | Unity Catalog hébergé (inclus), lignage natif |

Pour la conformité, c'est le **lignage source → index vectoriel** qui fera la différence : quand un client exerce son droit à l'effacement (L174), vous devez savoir **tous** les endroits où ses données ont été copiées, y compris les chunks de l'assistant RAG.

## 5. 🎮 Défi : remonter le fil

Le tableau de bord affiche un « taux de tickets SAV par client » aberrant. À partir du schéma du §2 et d'un lignage complet, écrivez les **4 questions** que vous poseriez au catalogue, dans l'ordre. *(Proposition : 1. Quel modèle calcule l'indicateur et qui en est propriétaire ? 2. Quelles tables amont lit-il ? 3. Laquelle a changé récemment (schéma, volume) ? 4. Quels autres consommateurs de cette table sont touchés ?)*

## 🧪 Exercice pratique

**Consigne** : lancez Marquez en local et instrumentez **deux** jobs du pipeline fil rouge : (1) un job `extraire_tickets` qui lit `main.tickets_sav` et écrit `bronze/tickets.parquet` ; (2) le job `indexer_tickets_sav` ci-dessus qui lit `bronze/tickets.parquet` et écrit `tickets_chunks`. Rédigez ensuite la fiche catalogue de `tickets_sav` (description, propriétaire, steward, classification de chaque colonne, durée de conservation).

**Critères de réussite** :
- l'interface Marquez montre un graphe continu `tickets_sav → tickets.parquet → tickets_chunks` (mêmes `namespace`/`name` à la jonction) ;
- un run en échec simulé (`FAIL`) apparaît distinctement ;
- la fiche catalogue classe `texte` et `client_id` comme données personnelles et cite la base légale pressentie.

**Pistes de corrigé** : utilisez `namespace = "file://bronze"` et `name = "tickets.parquet"` dans la sortie du job 1 **et** l'entrée du job 2 ; pour l'échec, émettez `FAIL` dans un bloc `except`. Classification : `id` Interne, `client_id` DonneePersonnelle (identifiant indirect), `sujet` Interne, `texte` DonneePersonnelle (texte libre pouvant contenir téléphone, IBAN…), `statut` Interne. Base légale typique : exécution du contrat (gestion du SAV) ; conservation : durée de la relation commerciale + délai de prescription, à valider avec le DPO.

## ✅ Auto-évaluation express
1. Différence entre catalogue technique et plateforme de métadonnées ?
2. Les quatre objets du modèle OpenLineage ?
3. Pourquoi le lignage est-il utile pour le droit à l'effacement ?

**Réponses** : 1. Le premier sert les moteurs (localisation des tables, droits d'accès) ; la seconde sert les humains (découverte, glossaire, propriétaires, lignage, qualité). 2. Job, run, dataset, facette. 3. Il liste toutes les copies et dérivés d'une donnée (tables, fichiers, index vectoriels), donc tous les endroits où l'effacement doit être propagé.

## 📚 Pour aller plus loin
- [Data Lakehouse Hub — Metadata Platforms in 2026](https://datalakehousehub.com/blog/metadata-platforms-in-2026/) 🇬🇧 — panorama tiers des catalogues (mi-2026).
- [OpenLineage — Object model](https://openlineage.io/docs/spec/object-model) 🇬🇧 — runs, jobs, datasets, facettes.
- [Unity Catalog](https://www.unitycatalog.io/) 🇬🇧 — catalogue open source multi-formats.
- [OpenMetadata](https://open-metadata.org/) 🇬🇧 — plateforme de métadonnées open source.
- [Apache Polaris](https://polaris.apache.org/) 🇬🇧 — catalogue Iceberg REST.
- [DataHub — source ODCS](https://docs.datahub.com/docs/generated/ingestion/sources/odcs) 🇬🇧 — relier contrats et catalogue.

> 🗺️ **Et maintenant ?** — Vous savez *ce qui existe* et *d'où ça vient* ; la leçon L173 vous apprend à savoir, en continu, si tout **va bien** : l'observabilité des données et la gestion d'incident.
