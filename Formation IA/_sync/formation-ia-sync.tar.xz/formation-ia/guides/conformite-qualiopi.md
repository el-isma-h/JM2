# Conformité Qualiopi — Formation IA Next Formation (NF-IA-150)

> Version 1.0 — 5 novembre 2026. Synthèse documentaire, pas un avis juridique. À relire avec le **Guide de lecture du RNQ V10** avant l'audit.

## 1. Cadre de référence

- **Texte** : référentiel national qualité actualisé par le **décret n° 2026-728 du 1er août 2026** (JORF du 4 août 2026), applicable au **1er novembre 2026**, sans disposition transitoire : tout audit réalisé à partir de cette date se fait sur le nouveau référentiel. **Arrêté du 28 octobre 2026** (JO du 1er novembre 2026) pour les seuils : indicateur 19 = **8 intervenants** par formation (référent pédagogique au-delà) ; indicateur 20 = 50 % d'heures assurées par des permanents (CFA). « V10 » désigne le **guide de lecture** (novembre 2026), pas le décret (`_recherche/07`, P9).
- **Structure** : 7 critères inchangés, **33 indicateurs** ; le nouvel indicateur 33 est **réservé aux CFA**. Un organisme de formation qui n'est pas CFA reste audité sur **32 indicateurs**, dont certains seulement s'il fait de l'alternance ou de la certification.
- **Indicateurs modifiés** selon `_recherche/07` (source la plus récente) : 1, 2, 3, 12 (violences, harcèlement, discriminations), 14-15 (CFA), 19 (effectivité du suivi à distance), 20, 27 (sous-traitance, portage salarial), 32 (analyse des risques qualité). `_recherche/05` donnait une liste un peu différente (1, 3, 7, 12, 14, 15, 19, 20, 27, 30, 32, et 23 et 25 modifiés). **Les deux listes sont à confronter au guide de lecture V10** ; le tableau ci-dessous signale les deux sources quand elles divergent.
- **FOAD** : art. D6313-3-1 du code du travail (assistance technique et pédagogique, information sur les activités et leur durée moyenne, évaluations qui jalonnent ou concluent) ; TA Toulouse, 2 novembre 2023, n° 2107403 : connexions + résultats d'évaluation + traces d'accompagnement individuel.
- **CPF** (rappel, `_recherche/05` § 2 et `_recherche/07` P7-P8) : Qualiopi « actions de formation » obligatoire ; certification RS ou RNCP active et habilitation de l'organisme ; plafond de prise en charge RS de 1 500 € (décret 2026-127 du 24 février 2026) ; reste à charge de 150 € depuis le 2 avril 2026 (décret 2026-234).

Légende de la dernière colonne : **[À COMPLÉTER PAR L'ORGANISME]** = pièce ou décision que seul Next Formation peut produire ; **[À VÉRIFIER]** = point à confirmer dans le guide de lecture V10.

## 2. Tableau indicateur → preuve → reste à faire

### Critère 1 — Information du public

| Ind. | Exigence (résumé) | Évolution 2026 | Preuve fournie par cette formation | Reste à faire par l'organisme |
|---|---|---|---|---|
| 1 | Information accessible, détaillée et vérifiable : prérequis, objectifs, durée, modalités et délais d'accès, tarifs, contacts, méthodes, modalités d'évaluation, accessibilité | Modifié (taux de satisfaction et de résultats avec **méthode de calcul**) | `programme/programme.json` (source de vérité) et `programme/programme.md` (fiche lisible générée) ; `export/programme-catalogue.json` (fiche catalogue) ; chaque `niveaux/Nx-…/niveau.md` (public, prérequis, compétences, durées, évaluation, matériel) ; `README.md` ; mention « badges = reconnaissance complémentaire » (`guides/guide-apprenant.md` § 2.8) | **[À COMPLÉTER PAR L'ORGANISME]** tarifs TTC, délais d'accès, contacts, page publique, référent handicap ; taux de satisfaction et de réussite **avec méthode de calcul** une fois la première promotion terminée |
| 2 | Indicateurs de résultats adaptés à la nature des prestations | Modifié (selon `_recherche/07`) **[À VÉRIFIER]** | Données sources dans l'app : exports **Résultats des quiz**, **Tentatives d'examen**, **Certificats** (`/ia/admin/exports`) ; tableau de bord admin (taux de réussite quiz et examens) | **[À COMPLÉTER PAR L'ORGANISME]** choisir et publier les indicateurs (taux de réussite par niveau, taux d'abandon, satisfaction), méthode de calcul, fréquence |
| 3 | Certification : taux d'obtention, possibilités de valider des blocs, équivalences, passerelles, suites de parcours, débouchés | Modifié | `referentiel/referentiel-competences.md` (4 blocs + bloc 5) ; `referentiel/correspondance-certifications.md` (certifications tierces, suites de parcours) ; `referentiel/dossier-rs-france-competences.md` (trame RS) ; enchaînement N1 → N4 et N5 décrit dans les `niveau.md` ; export **Certificats** et page publique de vérification `/ia/verifier/[numero]` | **[À COMPLÉTER PAR L'ORGANISME]** enregistrement RS ou habilitation par un certificateur existant ; taux d'obtention publié par niveau ; débouchés (fiches métiers) |

### Critère 2 — Objectifs et adaptation des prestations

| Ind. | Exigence | Évolution 2026 | Preuve fournie | Reste à faire |
|---|---|---|---|---|
| 4 | Analyse du besoin du bénéficiaire | — | Publics et prérequis par niveau (`niveau.md`) ; formulation des besoins dans le dossier RS (note d'opportunité, `dossier-rs-france-competences.md`) | **[À COMPLÉTER PAR L'ORGANISME]** questionnaire ou entretien d'analyse du besoin à l'inscription (individuel et entreprise), conservé dans le dossier apprenant |
| 5 | Objectifs opérationnels et évaluables | — | Objectifs par leçon (en-tête YAML `objectives`) et par module (`module.json`), formulés par verbes d'action ; compétences C1.1 à C5.6 avec critères d'évaluation (`referentiel-competences.md`) | Rien de spécifique ; vérifier que la fiche publique reprend ces objectifs |
| 6 | Contenus et modalités adaptés aux objectifs | — | 150 leçons (+ 34 en N5) au format de `FORMAT.md` ; exercice pratique à chaque leçon ; correspondance compétences ↔ modules (`referentiel-competences.md`) ; labs `labs/` | Rien de spécifique |
| 7 | Adéquation des contenus aux exigences de la certification visée | Modifié selon `_recherche/05` (capacité à mener la certification à terme, y compris comme organisme habilité) ; absent de la liste de `_recherche/07` **[À VÉRIFIER]** | `referentiel-evaluation.md` (épreuves par compétence) ; `examens/N1-examen.json` à `N4-examen.json` avec la répartition des questions par compétence ; `correspondance-certifications.md` | **[À COMPLÉTER PAR L'ORGANISME]** décision RS ou convention d'habilitation ; calendrier des sessions ; jury constitué. Examen N5 (`examens/N5-examen.json`) **non encore rédigé** |
| 8 | Positionnement et évaluation des acquis à l'entrée | — | Test de positionnement **annoncé** dans les `niveau.md` (20 questions en N1, test d'entrée en N3, N4, N5) ; déblocage manuel d'un niveau après positionnement (`/ia/admin/apprenants/[id]`, action journalisée) | **[À COMPLÉTER PAR L'ORGANISME]** **le test de positionnement n'existe pas encore** dans les fichiers ni dans l'app : le rédiger (par niveau), définir la règle d'orientation, conserver le résultat |

### Critère 3 — Adaptation aux publics, accompagnement, suivi et évaluation

| Ind. | Exigence | Évolution 2026 | Preuve fournie | Reste à faire |
|---|---|---|---|---|
| 9 | Information des publics sur les conditions de déroulement | — | `guides/guide-apprenant.md` (fonctionnement, durées, plannings, assistance, évaluation, charte IA) ; durée estimée affichée sur chaque leçon (`minutes`) ; règles d'examen affichées sur `/ia/examen/[niveau]` | **[À COMPLÉTER PAR L'ORGANISME]** les mentions du guide (contacts, horaires des classes virtuelles, délais, RGPD) ; règlement intérieur et règlement de certification remis à l'inscription. Harmoniser les durées : la somme des leçons et quiz de `programme.json` (≈ 146 h + 7 h 30 de quiz + 4 h d'examens) ne correspond pas exactement aux 150 h annoncées (141 h + 9 h selon `referentiel-evaluation.md` § 4) |
| 10 | Adaptation de la prestation, accompagnement et suivi | — | Trois plannings types (guide apprenant § 3) ; déblocages manuels, réinitialisation de tentatives (espace admin) ; tuteur IA par leçon ; classes virtuelles par niveau (guide formateur § 2) | **[À COMPLÉTER PAR L'ORGANISME]** procédure d'adaptation individuelle (avenant de planning, aménagement) |
| 11 | Évaluation de l'atteinte des objectifs | — | Quiz par module (30 + 7), examens de niveau (4, N5 à venir), épreuves pratiques et grilles (`referentiel-evaluation.md`) ; résultats horodatés en base ; exports **Résultats des quiz** et **Tentatives d'examen** ; résultat par compétence après l'examen | **[À COMPLÉTER PAR L'ORGANISME]** archivage des grilles d'épreuves pratiques corrigées (l'app **ne gère pas le dépôt ni la correction des projets**) |
| 12 | Engagement des bénéficiaires et prévention des ruptures de parcours | Modifié : **prévention des violences, du harcèlement et des discriminations** | Liste « À relancer » (7 jours sans activité) sur `/ia/admin` ; protocole de relance J+7 / J+14 / J+21 / J+30 (guide formateur § 3.2) ; gamification sans classement (XP, série, badges), révisions espacées | **[À COMPLÉTER PAR L'ORGANISME]** journal de tutorat traçant les relances (l'app **n'envoie pas de relance automatique et n'a pas de messagerie**) ; **procédure de signalement VSS / harcèlement / discriminations** et référent désigné (mention prévue dans le guide apprenant § 6) ; mise à jour du règlement intérieur |
| 13 | Formations en alternance : coordination entre organisme, entreprise et bénéficiaire | Modifié (CFA, selon `_recherche/05`) | Non applicable à ce parcours 100 % à distance hors alternance | À traiter seulement si la formation est vendue en alternance |
| 14 | CFA : exercice de la citoyenneté | Modifié (CFA) | Non applicable (organisme non CFA) | — |
| 15 | CFA : information des apprentis sur leurs droits et devoirs | Modifié (CFA) | Non applicable (organisme non CFA) | — |
| 16 | Formations certifiantes : conditions de présentation à la certification conformes aux exigences du certificateur | Selon `_recherche/05`, complété par la possibilité pour l'auditeur d'**observer une séquence ou d'utiliser un compte observateur** **[À VÉRIFIER : rattachement de cette exigence à l'ind. 16]** | Règlement de certification pré-rempli (`dossier-rs-france-competences.md` § 6) ; conditions d'éligibilité et déroulement (guide formateur § 6) ; examens chronométrés serveur, 3 tentatives, 7 jours d'intervalle, ordre mélangé | **[À COMPLÉTER PAR L'ORGANISME]** responsable de la certification ; convocations ; procédure de surveillance à distance (l'app **n'intègre pas la surveillance webcam** ni la vérification d'identité : outil externe à choisir) ; **compte observateur** pour l'auditeur (l'app n'a pas de rôle « observateur » : créer un compte apprenant ou formateur dédié, journalisé) |

### Critère 4 — Moyens pédagogiques, techniques et d'encadrement

| Ind. | Exigence | Évolution 2026 | Preuve fournie | Reste à faire |
|---|---|---|---|---|
| 17 | Moyens humains et techniques adaptés, environnement approprié | — | Application e-learning (`app/README.md`, `app/SPEC.md`) : parcours séquencé, lecteur de leçons, quiz, examens, tuteur IA, révisions, lexique (589 termes), ressources (bibliothèque de liens officiels), certificats PDF vérifiables, sonde `/ia/api/health` ; labs avec tests et mode simulé sans clé ; matériel requis par niveau (`niveau.md`) | **[À COMPLÉTER PAR L'ORGANISME]** liste nominative des formateurs, support technique (contact, horaires), hébergement et sauvegardes (exploitation du serveur), clé IA de la plateforme |
| 18 | Coordination des acteurs internes et externes | — | Rôles définis (référent FOAD, formateur-évaluateur, jury, responsable de certification) dans `guides/guide-formateur.md` | **[À COMPLÉTER PAR L'ORGANISME]** organigramme, réunions de coordination, comptes rendus |
| 19 | Ressources pédagogiques accessibles et contrôle de l'effectivité du suivi à distance | Modifié : **effectivité du distanciel** ; **référent pédagogique au-delà de 8 intervenants** (arrêté du 28/10/2026) | Temps par leçon mesuré (onglet visible, ping 30 s, plafonné), journal d'activité (`activity_log`), dates d'ouverture et de fin, quiz et examens horodatés ; exports **Preuves de réalisation FOAD** et **Relevé d'activité journalier** ; journal des actions admin ; sources et licences citées dans chaque leçon | **[À COMPLÉTER PAR L'ORGANISME]** **traces d'accompagnement individuel** (journal de tutorat, comptes rendus de classes virtuelles, émargement des classes virtuelles) — non produites par l'app ; validation humaine du temps comptabilisé (la fonction `elearning_progress.validatedBy` existe dans **Next Formation**, pas dans cette app) ; désignation du **référent pédagogique** si plus de 8 intervenants |
| 20 | Personnels dédiés (référent handicap, mobilité, conseil de perfectionnement) — CFA | Modifié : seuil de 50 % d'heures par des permanents (CFA) | Non applicable en tant que CFA ; le référent handicap est traité à l'ind. 26 | — |

### Critère 5 — Qualification et développement des compétences des personnels

| Ind. | Exigence | Évolution 2026 | Preuve fournie | Reste à faire |
|---|---|---|---|---|
| 21 | Compétences des intervenants | — | Profil attendu des formateurs-évaluateurs (3 ans d'expérience IA / automatisation, veille documentée) dans `dossier-rs-france-competences.md` ; exigences des jurés (guide formateur § 6) | **[À COMPLÉTER PAR L'ORGANISME]** CV, diplômes, attestations d'expérience, fiches de poste |
| 22 | Développement des compétences des salariés | — | Formation annuelle des jurés (2 h) prévue ; veille trimestrielle (guide formateur § 8) | **[À COMPLÉTER PAR L'ORGANISME]** plan de développement des compétences, attestations de formation des formateurs |

### Critère 6 — Inscription dans l'environnement professionnel

| Ind. | Exigence | Évolution 2026 | Preuve fournie | Reste à faire |
|---|---|---|---|---|
| 23 | Veille légale et réglementaire | Modifié selon `_recherche/05` ; absent de la liste de `_recherche/07` **[À VÉRIFIER]** | `_recherche/05-reglementation-certification-marche.md` (RS, CPF, FOAD, Qualiopi, AI Act, RGPD, droit d'auteur) ; `_recherche/07-mise-a-jour-nov-2026.md` (vérification datée, statuts) ; leçons M07 et M15 à jour de l'omnibus IA ; procédure de veille (guide formateur § 8) | **[À COMPLÉTER PAR L'ORGANISME]** note de veille trimestrielle datée et diffusée à l'équipe ; preuve d'exploitation (corrections appliquées) |
| 24 | Veille sur les emplois, métiers et compétences | — | Données de marché et tendances (`_recherche/05` § 6) ; publics et métiers visés par niveau (`niveau.md`, ex. fiche APEC et code ROME M1811 pour N5) | **[À COMPLÉTER PAR L'ORGANISME]** veille périodique (OPIIEC, France Travail, offres d'emploi), trace d'exploitation |
| 25 | Veille sur les innovations pédagogiques et technologiques | Modifié selon `_recherche/05` **[À VÉRIFIER]** | Dossiers `_recherche/01` à `07` (fournisseurs, cours académiques, outils) ; nouveautés relevées au 5/11/2026 ; `_corrections-appliquees-nov-2026.md` et `_corrections-en-attente.md` (mise à jour des contenus) ; enrichissements pédagogiques v1.1 (« En clair », quiz éclair, missions, fiches mémo, lexique, révisions espacées — `FORMAT.md`) | **[À COMPLÉTER PAR L'ORGANISME]** calendrier de veille, responsable, exploitation documentée |
| 26 | Mobilisation des expertises, outils et réseaux nécessaires pour accueillir les personnes en situation de handicap | — | Accessibilité décrite (guide apprenant § 7 ; `referentiel-evaluation.md` § 5) : supports textuels compatibles lecteurs d'écran, mode sombre, réduction des animations respectée, temps majoré d'un tiers prévu | **[À COMPLÉTER PAR L'ORGANISME]** **référent handicap** nommé, partenariats (Agefiph, Cap emploi), procédure d'aménagement. **L'app ne gère pas encore le temps majoré** à l'examen (60 min fixes) : procédure manuelle à formaliser ou évolution à demander |
| 27 | Sous-traitance et portage salarial : respect du référentiel par les sous-traitants | Modifié : **contrat écrit obligatoire** (sous-traitance, portage salarial) | Exigence rappelée pour les formateurs et jurés externes (guide formateur § 6) | **[À COMPLÉTER PAR L'ORGANISME]** contrats écrits avec chaque formateur ou juré externe, preuves de leur qualification |
| 28 | Formation en situation de travail : mobilisation des partenaires socio-économiques | — | Non applicable (100 % à distance, hors alternance) | À traiter seulement en cas d'alternance |
| 29 | Insertion professionnelle ou poursuite d'études (CFA) | — | Non applicable en tant que CFA ; enquête à 6 mois prévue pour la certification (`dossier-rs-france-competences.md` § 6) | **[À COMPLÉTER PAR L'ORGANISME]** enquête d'insertion à 6 mois (utile au dossier RS) |

### Critère 7 — Recueil et prise en compte des appréciations et réclamations

| Ind. | Exigence | Évolution 2026 | Preuve fournie | Reste à faire |
|---|---|---|---|---|
| 30 | Recueil des appréciations des parties prenantes | Complété selon `_recherche/05` **[À VÉRIFIER]** | Enquêtes à chaud et à froid prévues (`dossier-rs-france-competences.md` § 10.1) | **[À COMPLÉTER PAR L'ORGANISME]** **questionnaires de satisfaction** (apprenants, entreprises, financeurs, formateurs) : **non intégrés à l'app** ; outil, calendrier, résultats |
| 31 | Traitement des difficultés et réclamations | — | Procédure de réclamation et de recours de certification (30 jours / 30 jours, commission de 3 personnes) dans `dossier-rs-france-competences.md` § 6 ; rappel dans le guide apprenant § 6 | **[À COMPLÉTER PAR L'ORGANISME]** adresse de réclamation, **registre des réclamations**, réponses tracées |
| 32 | Mesures d'amélioration à partir des appréciations et réclamations | Modifié : **analyse des risques pesant sur la qualité** | Risques identifiés dans `dossier-rs-france-competences.md` § 10.1 (abandon FOAD, fraude, obsolescence des contenus, panne LMS, dépendance aux API tierces) ; procédure de mise à jour et traçabilité des corrections (guide formateur § 8, fichiers `_corrections-*.md`) ; procédure de fraude (guide formateur § 7) | **[À COMPLÉTER PAR L'ORGANISME]** **cartographie des risques qualité** formalisée (probabilité, impact, mesures, responsable, revue annuelle) ; plan d'amélioration daté |
| 33 | Évaluation des enseignements par les apprentis | **Nouveau, réservé aux CFA** | Non applicable | — |

## 3. FOAD : correspondance des trois obligations

| Obligation (art. D6313-3-1) | Preuve fournie | Reste à faire |
|---|---|---|
| Assistance technique et pédagogique appropriée | Formateur-référent (guide formateur § 1), réponse sous 24 h ouvrées, classes virtuelles hebdomadaires par niveau, tuteur IA par leçon, liste « À relancer » | **[À COMPLÉTER PAR L'ORGANISME]** canal de messagerie tracé, contacts, journal de tutorat exportable |
| Information sur les activités à distance et leur durée moyenne | Durée par leçon (`programme.json`) affichée dans l'app ; guide apprenant (activités, plannings types, méthode) | Harmoniser la somme des durées avec les 150 h annoncées (voir ind. 9) |
| Évaluations qui jalonnent ou concluent | Quiz de module (jalons, déblocage), examens de niveau (conclusion), épreuves pratiques, certificat PDF vérifiable ; exports horodatés | Archivage des épreuves pratiques corrigées (hors app) |
| Preuve de réalisation (jurisprudence) | Exports **Preuves de réalisation FOAD**, **Relevé d'activité journalier**, **Résultats des quiz**, **Tentatives d'examen** | **[À COMPLÉTER PAR L'ORGANISME]** certificat de réalisation (modèle DGEFP) distinct de l'attestation de fin de formation et du parchemin ; service fait EDOF ; durée de conservation des preuves |

## 4. Écarts entre les documents et l'application (à arbitrer)

Le dossier RS (`dossier-rs-france-competences.md` § 10.1) cite des preuves que l'application `app/` ne produit pas aujourd'hui. Elles doivent être fournies par un autre outil ou ajoutées à l'application :

| Preuve citée | État dans l'app (5/11/2026) |
|---|---|
| Messagerie de tutorat, journal de tutorat exportable | Absente |
| Relances automatiques d'inactivité | Liste « À relancer » seulement, sans envoi |
| Dépôt horodaté des épreuves pratiques | Absent |
| Émargement électronique | Absent |
| Validation humaine du temps (`elearning_progress.validatedBy`) | Fonction de la plateforme Next Formation, pas de cette app |
| Compte observateur auditeur | Pas de rôle dédié (rôles : apprenant, formateur, administrateur) |
| Examen surveillé (webcam, identité) | Absent : timer serveur, ordre mélangé, correction serveur uniquement |
| Temps majoré d'un tiers | Absent (60 min fixes) |
| Test de positionnement | Absent des fichiers et de l'app |
| Questionnaires de satisfaction | Absents |

## 5. Pièces à produire par l'organisme avant l'audit (récapitulatif)

1. NDA, attestation Qualiopi « actions de formation » (ou dossier d'audit initial) **[À COMPLÉTER PAR L'ORGANISME]**.
2. Fiche publique complète (tarifs, délais d'accès, contacts, accessibilité, indicateurs de résultats avec méthode de calcul).
3. Questionnaire d'analyse du besoin et test de positionnement par niveau.
4. Règlement intérieur (avec procédure VSS / harcèlement / discriminations) et règlement de certification finalisé.
5. Référents nommés : pédagogique, handicap, VSS, responsable de la certification ; CV et contrats des intervenants et jurés externes.
6. Outil de tutorat tracé et journal exportable ; émargement des classes virtuelles.
7. Outil de surveillance d'examen et procédure d'aménagement (temps majoré).
8. Questionnaires de satisfaction et registre des réclamations.
9. Cartographie des risques qualité et plan d'amélioration.
10. Notes de veille trimestrielles (réglementaire, métiers, innovations) et trace de leur exploitation.
11. Modèles de certificat de réalisation et d'attestation de fin de formation ; procédure d'archivage des exports.
12. Décision d'enregistrement RS ou convention d'habilitation (CPF).

Sources : `_recherche/05-reglementation-certification-marche.md` § 2-3 et § 9 ; `_recherche/07-mise-a-jour-nov-2026.md` P7-P9 ; `referentiel/dossier-rs-france-competences.md` § 6 et § 10 ; `referentiel/referentiel-evaluation.md` ; `app/SPEC.md` et code de l'application (`app/src/`). Textes à relire à la source primaire avant l'audit : décret n° 2026-728, arrêté du 28 octobre 2026, guide de lecture V10 (travail-emploi.gouv.fr).
