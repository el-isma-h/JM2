# Guide du formateur — Formation IA Next Formation (NF-IA-150)

> Version 1.0 — 5 novembre 2026. Destiné aux formateurs-référents, formateurs-évaluateurs et membres de jury. Documents de référence : `referentiel/referentiel-evaluation.md` (épreuves, grilles, jury), `referentiel/referentiel-competences.md`, `referentiel/dossier-rs-france-competences.md` (§ 6 règlement de certification, § 10 Qualiopi et FOAD), `app/SPEC.md` (fonctions de la plateforme), `guides/guide-apprenant.md` (ce que les apprenants ont lu). Les mentions **[À COMPLÉTER PAR L'ORGANISME]** désignent des informations que seul Next Formation peut fixer.

---

## 1. Le rôle du formateur-référent FOAD

### 1.1 Le cadre réglementaire

Une formation à distance doit comprendre trois éléments (art. D6313-3-1 du code du travail) :

1. une **assistance technique et pédagogique appropriée** ;
2. une **information sur les activités à distance et leur durée moyenne** (assurée par le guide de l'apprenant et la durée affichée sur chaque leçon) ;
3. des **évaluations qui jalonnent ou concluent** la formation (quiz, examens, épreuves pratiques).

La charge de la preuve repose sur l'organisme. Le tribunal administratif de Toulouse (2 novembre 2023, n° 2107403) a jugé que les relevés de connexion ne prouvent ni l'accompagnement ni les heures : il faut cumuler **relevés de connexion + résultats d'évaluation + traces d'accompagnement individuel**. Le référentiel qualité actualisé (décret n° 2026-728 du 1er août 2026, applicable au 1er novembre 2026) renforce l'indicateur 19 sur le **contrôle de l'effectivité du suivi à distance**. **Votre travail d'accompagnement est donc aussi une pièce du dossier de preuve : tracez-le.**

### 1.2 Vos missions

| Mission | Concrètement | Trace à conserver |
|---|---|---|
| Accueil | Envoyer l'invitation, vérifier l'activation, présenter le guide de l'apprenant, faire passer le test de positionnement, valider les prérequis (N3, N4, N5) | Invitation (journal admin), résultat du positionnement, compte rendu d'entretien d'accueil |
| Assistance pédagogique | Répondre aux questions **sous 24 h ouvrées** ; débloquer un apprenant sur un exercice ou un projet | Messages (canal **[À COMPLÉTER PAR L'ORGANISME]**), journal de tutorat |
| Animation | Une classe virtuelle de 60 min par semaine et par niveau (§ 2) | Feuille de présence ou émargement électronique, support, enregistrement si prévu |
| Suivi et prévention des abandons | Consulter le tableau « À relancer » au moins deux fois par semaine ; relancer selon le protocole (§ 3.2) | Relances datées, réponses, actions décidées |
| Évaluation | Corriger les épreuves pratiques avec la grille (§ 4), rédiger un retour écrit, proposer une reprise | Grille remplie, retour écrit, date de correction |
| Préparation à la certification | Vérifier l'éligibilité (toutes épreuves validées), inscrire à la session de jury, transmettre le dossier | Dossier candidat, convocation |
| Remontées | Signaler erreurs de contenu, difficultés récurrentes, réclamations, incidents | Ticket ou registre (§ 8) |

> ⚠️ **Piège fréquent** — Être à la fois le formateur-référent d'un candidat et le membre du jury qui le certifie. Le règlement de certification l'interdit : le formateur-évaluateur du jury **n'est pas intervenu dans la préparation du candidat**.

### 1.3 Engagements de délai

| Engagement | Délai |
|---|---|
| Réponse à une question pédagogique | 24 h ouvrées |
| Correction d'une épreuve pratique | **[À COMPLÉTER PAR L'ORGANISME]** (5 jours ouvrés recommandés) |
| Première relance d'un apprenant inactif | 7 jours sans activité |
| PV de jury | 15 jours après la session |
| Réponse à une réclamation | 30 jours |

---

## 2. Animation : les classes virtuelles hebdomadaires

### 2.1 Principes

- **Facultatives pour l'apprenant**, mais tracées : elles comptent comme assistance pédagogique, pas comme heures de formation supplémentaires (les 150 h sont des heures d'activités à distance).
- Une séance **par niveau** : les publics et les prérequis sont trop différents pour mélanger N1 et N4.
- **Partir des données** : avant chaque séance, regardez dans l'espace admin les quiz les plus ratés et les questions fréquentes. Une séance qui traite les vrais blocages vaut mieux qu'un cours de plus.
- **Jamais les réponses des quiz ni des examens.** Vous travaillez la notion, avec vos propres exemples.
- Démonstration en direct quand c'est possible (ouvrir la doc officielle, lancer n8n, exécuter le code) : c'est ce que les apprenants ne trouvent pas dans le texte.

### 2.2 Déroulé type de 60 minutes par niveau

**Niveau 1 — Fondamentaux (public non technique)**

| Temps | Séquence | Contenu |
|---|---|---|
| 0-5 | Accueil | Tour de table rapide : où en est chacun, une réussite de la semaine |
| 5-15 | Retour sur les révisions | 3 notions les plus ratées de la semaine (tableau admin), réexpliquées avec une analogie « En clair » |
| 15-35 | Démonstration guidée | Un même besoin métier traité en direct dans 2 assistants (Claude, ChatGPT, Gemini, Le Chat…) ; on améliore le prompt ensemble |
| 35-50 | Atelier | Chaque participant applique à son métier ; partage de 2 ou 3 prompts ; correction collective (rôle, contexte, tâche, format, contraintes) |
| 50-58 | Conformité | Un cas RGPD / AI Act / droit d'auteur : « Puis-je coller ce document ? » |
| 58-60 | Clôture | Objectif de la semaine, rappel de l'échéance de l'examen N1 |

**Niveau 2 — Praticien (automatisation sans code)**

| Temps | Séquence | Contenu |
|---|---|---|
| 0-5 | Accueil | Point d'avancement des projets (L038, L048, L058, L063) |
| 5-15 | Clinique des erreurs | 2 workflows d'apprenants (avec accord) qui échouent : lecture des exécutions n8n, du nœud en erreur, des données d'entrée |
| 15-40 | Démonstration | Construction en direct d'une brique du module (gestion d'erreurs, AI Agent, ingestion RAG, nœud Code) |
| 40-52 | Questions sur les projets | Lecture commentée des critères de réussite ; « qu'est-ce qu'une preuve recevable ? » (captures, exports JSON, feuille de test) |
| 52-58 | Coûts et choix | Un calcul de coût mensuel ou un arbitrage SaaS / API / local |
| 58-60 | Clôture | Prochaines remises |

**Niveau 3 — Développeur**

| Temps | Séquence | Contenu |
|---|---|---|
| 0-5 | Accueil | Tests rouges / verts de chacun sur le lab en cours |
| 5-20 | Revue de code | Un extrait de dépôt (anonymisé, avec accord) : gestion des erreurs, boucle d'outils, coûts, secrets |
| 20-40 | Live coding | Une fonction clé du module (streaming, `tool_use`, recherche hybride, serveur MCP, trace Langfuse) écrite et testée en direct |
| 40-52 | Documentation officielle | Une page de doc lue ensemble (changelog, migration, pricing) : ce qui a changé ce mois-ci |
| 52-58 | Sécurité | Un risque OWASP LLM 2026 appliqué au projet de la semaine |
| 58-60 | Clôture | Rappel des règles de dépôt (pas de clé, README, coût par appel, tests) |

**Niveau 4 — Expert**

| Temps | Séquence | Contenu |
|---|---|---|
| 0-5 | Accueil | Avancement des entraînements, problèmes de GPU ou de budget |
| 5-25 | Retour sur une notion difficile | Dérivation au tableau (rétropropagation, attention, LoRA) ou lecture d'une courbe d'apprentissage d'un apprenant |
| 25-40 | Protocole expérimental | Critique d'un protocole : séparation des données, fuite, graines, métrique figée avant l'entraînement |
| 40-52 | Lecture d'article | Passe 1 d'un article récent (méthode L150) ; « peut-on citer ce résultat à un client ? » |
| 52-58 | Préparation de la soutenance | Une question type du jury travaillée à voix haute |
| 58-60 | Clôture | Jalons du rapport final |

**Niveau 5 — Data engineering (si ouvert)** : même structure que N3, avec une revue de pipeline (idempotence, rejeu, tests dbt) à la place de la revue de code et une démonstration sur l'environnement Docker Compose « Bréval Matériaux ».

### 2.3 Trois exemples de séances

**Exemple 1 — N1, semaine 2 (M04 « Prompt engineering »), « Du prompt flou au prompt exploitable »**

| Temps | Déroulé |
|---|---|
| 0-5 | Accueil ; sondage : « Quel prompt vous a déçu cette semaine ? » |
| 5-15 | Les 3 questions éclair de M04 les plus ratées. Rappel des cinq composants (rôle, contexte, tâche, format, contraintes) avec une analogie : briefer un stagiaire le premier jour. |
| 15-35 | Démonstration : « Résume ce compte rendu de réunion » → réponse vague. Itérations en direct : ajouter le public, la longueur, un tableau des décisions, l'interdiction d'inventer, un exemple (few-shot). Comparer Claude et ChatGPT sur la version finale. |
| 35-50 | Atelier : chaque participant réécrit un prompt de son métier ; deux volontaires le partagent ; la classe identifie le composant manquant. |
| 50-58 | Cas : « Je colle la liste des salariés avec leurs salaires pour faire un tableau. » Pourquoi c'est interdit (L028), comment le faire autrement (données fictives, pseudonymisation). |
| 58-60 | Rappel : atelier 10 prompts (L020) à rendre avec le journal des itérations. |

**Exemple 2 — N3, semaine 9 (M23 « Sécurité des applications LLM »), « Prouver plutôt qu'affirmer »**

| Temps | Déroulé |
|---|---|
| 0-5 | Accueil ; rappel du cadre : la **seule** cible autorisée est PaieAssist sur `localhost` (L110). |
| 5-20 | Revue d'un extrait de code vulnérable (clé dans un fichier servi au navigateur, `innerHTML` sur la sortie du modèle) : trouver le risque OWASP, proposer la contre-mesure. |
| 20-40 | Démonstration : une injection indirecte cachée dans un document ingéré, rejouée **cinq fois** ; calcul du taux de succès ; ajout d'une défense (délimitation des données, filtre) puis nouvelle mesure. Message clé : un refus isolé ne prouve rien. |
| 40-52 | Lecture de la liste OWASP Top 10 for LLM Applications 2026 et des risques agentiques ASI01-ASI10 ; correspondance avec les constats de l'atelier. |
| 52-58 | Comment rédiger une synthèse exécutive d'une page pour un dirigeant, sans jargon. |
| 58-60 | Rappel : 10 constats cotés et 3 fiches détaillées attendus. |

**Exemple 3 — N4, semaine 11 (M28 « Fine-tuning »), « Les trois feux verts »**

| Temps | Déroulé |
|---|---|
| 0-5 | Accueil ; qui a déjà écrit ses 40 cas d'évaluation ? |
| 5-25 | Pourquoi écrire l'évaluation **avant** d'entraîner ; règle de succès de L140 : fine-tuné ≥ base + 15 points, non-régression ≤ 2 points, aucune invention grave sur les cas pièges. Exercice : trois jeux de résultats fictifs, la classe décide « livré » ou « refusé ». |
| 25-40 | Revue d'un jeu de données d'apprenant (avec accord) : fuite entre entraînement et évaluation, pseudonymisation, provenance, licences. |
| 40-52 | Sujet B (droit du travail) : pourquoi le modèle invente des numéros d'articles plausibles et pourquoi la conclusion doit recommander un RAG. |
| 52-58 | Question de jury : « Que faites-vous si le gain n'est que de 8 points ? » Réponse attendue : conclure honnêtement, un projet qui démontre que le prompt suffit est aussi réussi. |
| 58-60 | Jalons : entraînement, servi par Ollama, rapport. |

---

## 3. Suivi des apprenants dans l'espace admin

L'espace admin (`/ia/admin`) est accessible aux rôles **formateur** et **administrateur**. Le formateur a accès à tout, sauf aux réglages de la plateforme et à la gestion des rôles ; il ne peut inviter que des apprenants. **Chaque action d'administration est journalisée** (qui, quand, sur quel apprenant).

### 3.1 Ce que vous voyez

| Écran | Contenu | Usage |
|---|---|---|
| **Tableau de bord** (`/ia/admin`) | Nombre d'apprenants, actifs sur 7 et 30 jours, temps total, leçons terminées, quiz et examens (tentatives / réussites), certificats, activité des 30 derniers jours, répartition par niveau, liste **« À relancer »** | Revue bihebdomadaire ; préparation des classes virtuelles |
| **Apprenants** (`/ia/admin/apprenants`) | Liste avec progression, temps passé, dernière activité | Repérer les écarts de rythme |
| **Fiche apprenant** (`/ia/admin/apprenants/[id]`) | Détail par leçon (temps, dates), quiz, tentatives d'examen, déblocages, certificats | Entretien individuel, décision de déblocage |
| **Invitations** (`/ia/admin/invitations`) | Création et renouvellement des invitations (e-mail envoyé si la messagerie est configurée, sinon lien à copier) | Accueil |
| **Exports** (`/ia/admin/exports`) | 5 exports CSV (§ 3.4) | Preuves FOAD, financeurs, audit |

### 3.2 Relances : protocole

La liste « À relancer » contient les apprenants **non désactivés**, qui n'ont **pas terminé** leur parcours et **sans activité depuis 7 jours** (ou jamais connectés 7 jours après leur création), du plus ancien au plus récent.

| Moment | Action | Canal |
|---|---|---|
| J+7 sans activité | Message personnalisé : où il en est, ce qui l'attend, proposition d'aide | **[À COMPLÉTER PAR L'ORGANISME]** |
| J+14 | Proposition d'un entretien de 15 min (visio ou téléphone) ; ajustement du planning | Appel |
| J+21 | Entretien formalisé : cause (charge de travail, difficulté, matériel, santé, situation personnelle), plan d'action daté | Compte rendu |
| J+30 | Information du responsable pédagogique et, si prévu par la convention, du financeur ou de l'employeur | Écrit |

> ⚠️ **Piège fréquent** — Relancer sans tracer. La plateforme **n'envoie pas de relance automatique et n'a pas de messagerie intégrée** : la liste vous dit qui relancer, pas que la relance a été faite. Consignez chaque relance (date, canal, réponse) dans le journal de tutorat **[À COMPLÉTER PAR L'ORGANISME : outil du journal]** : c'est une preuve de l'indicateur 12 (prévention des ruptures) et de l'assistance FOAD.

### 3.3 Déblocages et autres actions

| Action | Quand l'utiliser | Ne pas faire |
|---|---|---|
| **Débloquer un module** | Prérequis attesté (test de positionnement, expérience), incident technique sur un quiz, aménagement pédagogique validé | Débloquer pour « faire avancer » un apprenant qui échoue au quiz : traitez plutôt la difficulté |
| **Débloquer un niveau** | Entrée directe en N3, N4 ou N5 après positionnement | Débloquer un niveau sans trace de la décision (notez le motif) |
| **Retirer un déblocage** | Erreur de manipulation | |
| **Réinitialiser les tentatives d'examen** | Incident technique avéré (coupure, panne), aménagement handicap, décision du responsable de la certification. Les tentatives annulées ne comptent plus dans les 3 | Offrir une 4e chance sans décision formalisée |
| **Révoquer / réémettre un certificat** | Fraude établie, erreur d'identité, correction de nom | Révoquer sans décision écrite du responsable de la certification |
| **Désactiver / réactiver un compte** | Fin de contrat, abandon confirmé, suspension | |

> ⚠️ **Piège fréquent** — L'examen est chronométré à 60 minutes par le serveur. **La plateforme ne gère pas encore le temps majoré** (80 min pour un aménagement handicap). En attendant, l'aménagement se gère par décision du responsable de la certification (session spécifique ou réinitialisation après incident) **[À COMPLÉTER PAR L'ORGANISME : procédure]**.

### 3.4 Exports de preuves

Tous les exports sont des CSV (UTF-8, séparateur « ; », lisibles dans Excel), filtrables par période (`du … au …`) et par apprenant.

| Export | Contenu | Utilisation |
|---|---|---|
| **Preuves de réalisation FOAD** | Une ligne par apprenant et par leçon : première ouverture, fin, temps passé (total et sur la période), score du quiz du module | Certificat de réalisation, service fait EDOF, financeurs, audit Qualiopi (ind. 19) |
| **Relevé d'activité journalier** | Une ligne par apprenant et par jour : temps, leçons terminées, quiz, examens, questions au tuteur, connexions | Assiduité, BPF (heures-stagiaires FOAD) |
| **Résultats des quiz** | Toutes les tentatives : date, score, pourcentage, réussite | Évaluations qui jalonnent (FOAD), ind. 11 |
| **Tentatives d'examen** | Toutes les tentatives, y compris annulées : horaires, durée, score, réussite | Évaluations qui concluent, jury |
| **Certificats** | Certificats émis et révoqués, avec lien de vérification | Suivi des certifiés, ind. 3 |

Bonnes pratiques : exportez **à chaque fin de niveau** et **à la sortie** de chaque apprenant, archivez les fichiers datés **[À COMPLÉTER PAR L'ORGANISME : emplacement, durée de conservation ; 6 ans cités par une source secondaire, à vérifier]**. Le temps de connexion est une preuve parmi d'autres : joignez-y toujours les résultats d'évaluation et les traces de tutorat.

---

## 4. Correction des épreuves pratiques

### 4.1 La grille commune (`referentiel/referentiel-evaluation.md` § 3)

| Critère | Insuffisant (0) | Partiel (1) | Atteint (2) | Expert (3) |
|---|---|---|---|---|
| Fonctionnement | Ne s'exécute pas | S'exécute avec erreurs | S'exécute sur les cas de test | S'exécute et gère les cas limites |
| Qualité / structure | Désorganisé | Lisible mais fragile | Structuré, documenté | Réutilisable, testé |
| Pertinence métier | Hors sujet | Répond partiellement au besoin | Répond au besoin | Dépasse le besoin (valeur ajoutée) |
| Conformité & sécurité | Données sensibles exposées | Risques non traités | Règles respectées | Risques anticipés et documentés |
| Explication orale/écrite | Absente | Confuse | Claire | Argumentée avec alternatives |

**Validation d'une compétence : ≥ 8/15 et aucun critère à 0.** Pas de compensation entre compétences.

### 4.2 Les grilles sur 100 des leçons

Plusieurs projets ont, en plus, une grille sur 100 points dans la leçon (L077, L094, L100, L105, L120, L127, L150 ; grille pondérée de M37). **La note sur 100 sert de retour au candidat ; la validation de la compétence se fait toujours sur la grille commune.** Conversion recommandée (reprise de L150 § 4.3) :

| Grille commune | Rubriques des grilles sur 100 qui l'alimentent |
|---|---|
| Fonctionnement | Fonctionnement, prototype, tests passés |
| Qualité / structure | Architecture, documentation, reproductibilité |
| Pertinence métier | Analyse du besoin, cahier des charges, coûts au regard du besoin |
| Conformité & sécurité | Sécurité, conformité, analyse de menaces, red teaming, gouvernance |
| Explication | Rapport, note au client, soutenance |

Une rubrique « éliminatoire » d'une grille sur 100 (par exemple une clé API dans le dépôt, un critère de L150 à 15 points sous 6) entraîne un 0 sur le critère commun correspondant.

### 4.3 Procédure de correction

1. **Vérifier la recevabilité** : livrables complets (liste dans la leçon), section « Usage de l'IA » présente, aucune clé dans le dépôt (y compris l'historique Git), README exécutable.
2. **Exécuter** : cloner, suivre le README, lancer les tests. Un projet que vous ne pouvez pas exécuter en suivant le README ne peut pas dépasser « Partiel » en fonctionnement.
3. **Noter** chaque critère avec **une preuve** (fichier, ligne, capture, sortie de test).
4. **Rédiger un retour écrit** : ce qui est atteint, ce qui manque, une piste concrète pour chaque critère sous 2.
5. **Décider** : validé, ou reprise (une reprise avec retour écrit), ou suspicion de fraude (§ 7).
6. **Archiver** la grille, le retour et la date.

---

## 5. Corrigés et pièges fréquents par projet

Les corrigés détaillés sont dans les leçons (sections « Pistes de corrigé ») et dans les labs (`solution/`). Ce tableau rassemble ce qu'il faut vérifier en priorité. **Ne transmettez pas ces éléments aux apprenants avant leur dépôt.**

### N2 — L038 · Assistant de support client automatisé (n8n) → C2.1, C2.2

- **Attendus** : exports JSON des workflows, base de connaissances ingérée (≥ 6 fiches), feuille de 10 cas de test et résultats, fiche d'exploitation, calcul de coût ; démonstration de 3 demandes (facturation, technique, réclamation).
- **Seuils** : 2 réponses proposées dans Slack et envoyées après validation, 1 escalade sans réponse IA ; ≥ 8/10 cas conformes ; **aucune réclamation non escaladée** ; une panne simulée (credential Anthropic invalide) déclenche l'alerte et l'escalade « IA indisponible » sans perte de ticket ; coût mensuel chiffré et sourcé.
- **Pièges fréquents** : base non ingérée avant les tests (l'agent répond « je n'ai pas cette information » à tout : vérifier le nombre de vecteurs dans Qdrant) ; Structured Output Parser qui échoue (activer la réparation automatique, ajouter un exemple JSON) ; reprise Slack qui ne fonctionne pas (`WEBHOOK_URL` non joignable en HTTPS) ; clé en clair, nœuds non nommés, pas de Sticky Note.

### N2 — L048 · RAG sans code (n8n, Dify / Flowise, NotebookLM) → C2.2

- **Attendus** : au moins 2 des 3 tutoriels sur le même jeu de 5 à 20 documents ; 5 questions dont 1 hors sujet ; tableau comparatif (réponse, justesse, source, temps de mise en place).
- **Seuils** : ≥ 3/4 bonnes réponses et refus de la question hors sujet pour chaque outil ; bonne source citée ; même modèle d'embeddings à l'ingestion et à la consultation, noté. Le référentiel N2 demande 8/10 pour l'assistant RAG certifiant (L048 / L052).
- **Pièges fréquents** : Simple Vector Store de n8n utilisé comme s'il était persistant (il disparaît au redémarrage) ; changement de modèle d'embeddings sans ré-indexation ; question hors sujet acceptée (prompt système trop permissif) ; réponse répartie sur deux pages ratée (augmenter overlap ou k).

### N2 — L058 · Reporting hebdomadaire automatisé → C2.4

- **Valeurs de référence** : date `2026-06-29` → semaine du 22 au 28 juin **1 078,20 €**, semaine précédente **2 443,00 €**, **−55,9 %**, cumul **33 500,00 €** ; date `2026-05-04` → avoir C-1016, **−349,00 €**, semaine précédente 1 110,00 €, **−131,4 %** ; date `2026-08-03` → « Rapport non généré : … » sans aucun chiffre.
- **Seuils** : chiffres recopiés exactement ; aucun chiffre calculé par le modèle (tout dans le JSON `kpi`) ; contrôle automatique et Error Trigger prouvés par capture ; note avec coût et 2 contrôles humains.
- **Pièges fréquents** : prompt qui demande une comparaison sans fournir la semaine précédente (le modèle invente une comparaison plausible) ; « environ −350 € » ou « CA nul » non attrapé par le contrôle ; fuseau horaire du Schedule Trigger.

### N3 — L077 · Assistant métier avec Claude (lab `lab-claude-devis`) → C3.1, C3.2, C3.4

- **Contraintes non négociables** : ≥ 3 outils dont 1 en écriture avec confirmation humaine, 1 fichier via la Files API, 1 sortie structurée finale, caching du system prompt et des documents ; suite d'évaluation ≥ 20 cas (code + juge) exécutée en Batch ; journal des coûts ; README.
- **Grille de la leçon (≥ 70/100)** : architecture 20, fonctionnement 25, fiabilité 20 (**0 prix inventé**, TVA correcte ≥ 90 %, injection neutralisée), coûts 15 (coût moyen ≤ 0,05 $, `cache_read_input_tokens` > 0 dès la 2e demande, p95 < 15 s), sécurité 10, documentation 10.
- **Pièges fréquents** : prix demandés au modèle au lieu du catalogue (le code calcule, le modèle structure) ; enregistrement sans accord de l'artisan ; JSON tronqué (`max_tokens`) ; cache absent du journal ; paramètres d'échantillonnage (`temperature`…) envoyés à un modèle récent ou avec la version d'API `2026-10-21` : erreur 400 ; `tool_choice` forcé refusé par Opus 5.5 et Sonnet 5.5 (voir `_recherche/07` P2, P2-bis).
- **Corrigé** : `labs/lab-claude-devis/solution/` (Python et TypeScript, tests verts). Vérifiez que le candidat n'a pas simplement copié le corrigé (§ 7).

### N3 — L083 · Le même assistant porté sur OpenAI (lab `lab-openai-portage`) → C3.1, C3.2

- **Attendus** : `fournisseur_openai` (streaming, outils, appels parallèles, sortie structurée), 20 tests sur au moins une configuration, `couts.py` à partir des `usage` (cache compris), note d'une page pour la gérante (modèle, coût, point RGPD `store`, plan de retour vers Claude).
- **Seuils** : ≥ 18/20 ; itérations bornées ; JSON validé et contrôlé arithmétiquement ; note compréhensible par une non-développeuse.
- **Pièges fréquents** : `function_call_output` enveloppé dans `{"role": "user"}` (erreur 400 peu explicite) ; renvoi des items déjà stockés avec `previous_response_id` ; `devis_core` modifié (le portage doit laisser le métier intact) ; oubli de `store` dans la note RGPD.

### N3 — L094 · RAG documentaire d'entreprise → C3.3

- **Attendus** : `ingestion/` (contextual retrieval activable), `schema.sql`, recherche hybride, reranking, `rag_app.py`, `api.py`, Docker ; `tests.jsonl` ≥ 40 cas relus ; `eval/` et `RAPPORT.md` (architecture, résultats recherche + Ragas, 3 expériences, coûts, risques) ; démonstration de 5 questions par `curl`, dont 1 hors périmètre et 1 à référence exacte.
- **Seuils** : citations exactes (vérifiées à la main dans les PDF) ou refus ; seconde ingestion sans effet ; `usage.cache_read` non nul dès le second appel ; coût mensuel calculé à partir de la page Pricing.
- **Pièges fréquents** : vouloir citations **et** sorties structurées JSON (incompatibles sur l'API en nov. 2026) ; seuil de refus fixé au hasard (il se fixe à partir des scores de reranking des cas hors périmètre) ; ingestion non idempotente.
- **Ressources** : `labs/lab-rag-code/` (procédures internes et `tests.jsonl`).

### N3 — L100 · Agent de recherche et de rédaction + serveur MCP → C3.4

- **Attendus** : `agent_veille.py` adapté, 3 notes avec leurs `journal.json`, coûts réels comparés à l'estimation, README (architecture, limites, validation humaine).
- **Seuils** : ≥ 2 notes sur 3 au statut `brouillon` dès la 1re ou 2e version ; **aucune URL de la bibliographie absente des résultats bruts** (vérifiable par script sur `journal.json` et `dossier.json`) ; `--budget 0.05` → statut `interrompu` sans exception ; le lien injecté `https://exemple-malveillant.test` n'apparaît ni dans la note ni dans les sources.
- **Pièges fréquents** : bibliographie écrite par le modèle (source des URL hallucinées ; elle doit être générée par le code) ; croire que le relecteur LLM vérifie les faits (il vérifie la cohérence avec le dossier) ; coûts dépassés par des requêtes de recherche trop vagues ; serveur MCP absent ou non testé (exigé par C3.4).

### N3 — L105 · Application IA complète déployée → C3.5

- **Seuils** : URL de production en HTTPS ; `/api/health` renvoie `"statut":"ok"` et le SHA du commit ; premier mot affiché en moins de 2 s **en production** ; trace Langfuse avec modèle, tokens (cache compris), coût, latence, outils, `promptVersion` ; une PR qui dégrade le prompt est bloquée par la CI ; retour arrière et restauration de sauvegarde exécutés et chronométrés.
- **Pièges fréquents** : worker lancé dans une route API appelée par cron sur Vercel (coupé à `maxDuration`, rejoué, facturé deux fois) ; streaming qui arrive d'un bloc en production (tampon de proxy ou de CDN, compression, `flush_interval -1` absent dans Caddy, route qui renvoie `Response.json` après `await result.text`) ; conteneur qui redémarre en boucle (variable manquante signalée par `env.ts`) ; **clé dans l'historique Git** : elle doit être **révoquée**, pas seulement supprimée.

### N3 — L110 · Audit de sécurité de PaieAssist (atelier) → C3.6

- **Seuils** : ≥ 10 des 12 vulnérabilités du corrigé reliées au bon risque OWASP ; preuve reproductible et recommandation testable pour chaque constat critique ; synthèse exécutive d'une page avec verdict ; tests limités à `localhost`, aucune donnée réelle.
- **Corrigé** (L110) : V01 clé API dans `config.js` (LLM02, LLM06) · V02 mot de passe de base dans le prompt système (LLM08) · V03 collection Chroma unique sans filtre client (LLM09, LLM02) · V04 `requete_sql` avec droits complets (LLM10, LLM03) · V05 `envoyer_bulletin` sans confirmation ni contrôle du destinataire (LLM03) · V06 document client injecté brut (LLM01, LLM05) · V07 mémoire partagée entre utilisateurs (LLM05, LLM02) · V08 journaux avec NIR et salaires en clair (LLM02, RGPD art. 32) · V09 100 itérations, 32 000 tokens, aucun quota (LLM06) · V10 `innerHTML` sur la sortie (LLM10) · V11 dépendances et serveur MCP non épinglés, pickle douteux (LLM04) · V12 « réponds avec assurance », sans source ni mention IA (LLM07, AI Act art. 50). **Bonus** : champ `client` fourni par le navigateur et non par l'authentification.
- **Pièges fréquents** : conclure « non vulnérable » après un seul refus (rejouer 5 fois et noter le taux) ; tester un service tiers ; synthèse jargonneuse.

### N4 — L120 · Projet ML sur données réelles → C4.2

- **Seuils** : grille du § 6 de la leçon ≥ 70 points ; code exécutable de bout en bout par une seule commande ; score de test avec **intervalle de confiance**, comparé au critère de succès fixé au cadrage.
- **Pistes par jeu** : California Housing (baseline Ridge, `HistGradientBoostingRegressor` meilleur ; cible plafonnée à signaler ; `GroupKFold` par zones) ; Titanic (fuites cabine/billet ; extraction du titre légitime) ; DVF (filtrage des ventes atypiques justifié ; **découpage temporel obligatoire**).
- **Pièges fréquents** : critère de succès défini après coup ; prétraitement ajusté sur tout le jeu (fuite) ; jeu de test consulté pendant la sélection ; projet présenté comme outil de diagnostic médical (hors cadre : dispositif médical, haut risque AI Act).

### N4 — L127 · Classifieur d'images PyTorch → C4.3

- **Seuils** : exactitude de test ≥ 80 % (ou écart chiffré et expliqué) ; aucune classe sous 65 % de rappel (ou plan d'action) ; **deux graines** rapportées avec leur écart ; rapport de 2 à 4 pages qui commence par la recommandation ; `cadrage.md` daté **avant** l'entraînement ; planche `erreurs.png`.
- **Pièges fréquents** : métrique choisie après les résultats ; `sched.step()` appelé par époque au lieu de par lot ; `modele.train()` non rappelé ; augmentation appliquée à la validation ; meilleure graine sélectionnée au lieu de la moyenne ; normalisation non ImageNet en transfert.

### N4 — L140 · Spécialiser un modèle ouvert (LoRA / QLoRA) → C4.4

- **Règle de succès** : fine-tuné ≥ base + 15 points **et** non-régression ≤ 2 points sur les tâches générales **et** zéro invention grave sur les cas pièges. Un projet qui démontre, preuves à l'appui, que le prompt seul suffisait est aussi réussi.
- **Seuils** : jeu de données valide, pseudonymisé, sans fuite, provenance documentée ; entraînement reproductible (graine, versions, hyperparamètres) ; modèle servi par Ollama ; juge A/B en double ordre et 20 paires relues à l'aveugle ; 40 cas d'évaluation (30 nominaux, 10 pièges) rédigés **avant** l'entraînement.
- **Résultats typiques (sujet A, ~800 exemples)** : gain de 15 à 30 points, non-régression ±2. **Pièges fréquents** : cas pièges sous-représentés ; montants inventés quand la politique commerciale n'est pas dans le prompt ; sujet B : numéros d'articles plausibles mais faux (critère « article exact » vérifié contre Légifrance ; la conclusion doit recommander un RAG) ; prompt différent entre base et fine-tuné (le gain n'est plus attribuable).

### N4 — L150 · Rapport final de sûreté et de gouvernance → C4.6

- **Dossier** : 25 à 40 pages, 7 parties (synthèse, conception, sécurité avec red teaming exécuté, alignement, gouvernance AI Act / NIST / ISO 42001 / AIPD, déploiement et surveillance, annexes avec ≥ 8 références dont 4 articles de recherche). Cas A (recrutement, haut risque annexe III), B (agent de factures avec paiement), C (RAG cabinet comptable), ou cas personnel validé.
- **Grille sur 100, seuil 60/100 et aucun critère à 15 points sous 6** (menaces, red teaming, architecture, gouvernance). Exemple : 72/100 avec 5/15 en red teaming → **non validé**.
- **Soutenance** : 20 min + 15 min de questions ; démonstration de 5 min avec **une attaque rejouée et la défense qui la bloque**. Questions types : changement de version du modèle fournisseur ; mesure supprimée en premier si le budget est divisé par deux ; « montrez la ligne du journal qui prouve qu'un humain a validé ».
- **Pièges fréquents** : qualification AI Act inexacte (cas A = haut risque ; obligations annexe III reportées au 2 décembre 2027 par le règlement 2026/1744) ; prépublication arXiv citée comme résultat établi ; red teaming décrit mais non exécuté ; affirmations sans preuve (« nous n'avons pas testé X, voici pourquoi » vaut mieux).

### N5 — M37 · Projet final : pipeline de données pour un RAG d'entreprise → C5.1 à C5.6

> État au 5 novembre 2026 : seules **L180** (cadrage) et **L181** (ingestion) sont rédigées ; L182 à L184 sont en cours. Ce qui suit couvre L180-L181 et la grille du référentiel ; à compléter quand les leçons seront livrées.

- **L180 — livrable 1** : `docs/architecture.md` (8 sections, 2 pages max.), `rag/droits.py`, `contrats/rag_chunks.odcs.yaml` qui passe `datacontract lint` avec ≥ 4 règles de qualité ; chaque SLO avec SLI, seuil chiffré et lieu de mesure ; ≥ 3 choix justifiés par 3 critères chiffrés. **Corrigé des accès** : PRC-001 visible par Léa (RH) et Sandrine (direction) seulement ; NOTE-002 par Sandrine seulement ; FT-BRV-ISO-00075 par tous ; un ticket de Saint-Nazaire par Karim et Sandrine, pas par Alice (bonne équipe, mauvaise agence) ni par Erwan. Lint en échec sur `items` : comparer au schéma JSON ODCS v3.1.0 du dépôt bitol-io.
- **L181 — ingestion** : 5 services actifs ; 126 objets et 126 lignes de registre ; second chargement à 0 ; événements `u`, `d`, `c` visibles avec latence < 10 s ; aucun `email` ni `telephone` dans les événements clients ; même nombre d'événements après `kill -9`. Requête de preuve dans la leçon (« Pistes de corrigé »).
- **Grille pondérée du projet final** : bout en bout 25 %, idempotence et CDC 20 %, qualité/gouvernance/PII 20 %, évaluation RAG 15 %, observabilité et coûts 10 %, documentation et soutenance 10 % ; PII détectées à ≥ 90 % ; document supprimé à la source absent de l'index dans le délai du SLA ; cloisonnement des droits vérifié.
- **Pièges fréquents** : dimensionner en fichiers au lieu de chunks et de tokens ; écrire « temps réel » sans chiffre ni percentile ; contrat rédigé après le pipeline ; anciennes versions de procédures et CGV identiques non dédoublonnées ; `delete_object` dans un bucket versionné pris pour un effacement RGPD ; mot de passe en clair dans `connecteur-breval.json` et utilisateur propriétaire de tout.

---

## 6. Organisation du jury

Référence : `referentiel/referentiel-evaluation.md` § 1 et `referentiel/dossier-rs-france-competences.md` § 6.

| Élément | Règle |
|---|---|
| Composition | **2 membres minimum**, dont **au moins un professionnel extérieur** à l'équipe pédagogique, et un formateur-évaluateur **non intervenu** dans la préparation du candidat. N4 : un expert ML/IA externe. N5 : un data engineer en activité externe. |
| Habilitation des jurés | Formation annuelle de 2 h aux référentiels et à la grille ; charte d'impartialité signée ; registre des jurés ; contrat écrit pour les jurés externes (ind. 27). **[À COMPLÉTER PAR L'ORGANISME : noms, contrats]** |
| Éligibilité du candidat | Examen de niveau réussi ; épreuves pratiques déposées et corrigées ; identité vérifiée |
| Convocation | 15 jours avant ; règlement de certification joint ; aménagements handicap confirmés |
| Soutenance | Visioconférence enregistrée **[À COMPLÉTER PAR L'ORGANISME : outil, conservation]** ; vérification d'identité par pièce officielle en début de séance ; N1-N3 : 20 min ; N4 : 30 min ; N5 : 15 min (démonstration + questions) |
| Délibération | Hors présence du candidat ; une décision par compétence (validée / non validée) ; **pas de validation partielle du certificat** ; compétence non validée repassable sous 6 mois |
| PV | Sous 15 jours ; signé par le président du jury et le responsable de la certification ; délivrance du parchemin et du certificat PDF |
| Recours | Réclamation écrite sous 30 jours ; réponse sous 30 jours ; commission de 3 personnes dont un externe |

**Déroulé type d'une session de jury (demi-journée, 6 candidats N3)** : 15 min de préparation du jury (relecture des grilles des correcteurs) ; 6 × (20 min de soutenance + 10 min de délibération) ; 15 min de synthèse et de rédaction du PV.

Questions utiles en soutenance, pour vérifier la paternité du travail : « Pourquoi ce choix plutôt que l'alternative X ? », « Modifiez ce paramètre en direct : que va-t-il se passer ? », « Montrez où le coût est calculé », « Qu'avez-vous demandé à l'IA, et qu'avez-vous corrigé ? ».

---

## 7. Fraude et usage de l'IA dans les épreuves

### 7.1 La règle (charte du guide de l'apprenant, § 9)

| Épreuve | IA |
|---|---|
| Quiz de module | Tolérée (formatif), non recommandée |
| Examen de niveau, épreuve écrite de maths N4 | **Interdite** |
| Projets, ateliers, rapports | **Autorisée avec déclaration** dans une section « Usage de l'IA » ; le candidat doit pouvoir expliquer chaque partie |
| Soutenance | **Interdite** pendant les questions (le prototype peut tourner) |

Le principe à appliquer : **l'IA est un outil, la compétence est celle du candidat**. Une déclaration honnête ne pénalise pas ; un usage non déclaré découvert est traité comme une fraude.

### 7.2 Mesures de prévention

- **Examen** : identité vérifiée en visio, webcam, questions et options mélangées, timer serveur, soumission automatique, bonnes réponses jamais envoyées au navigateur ; le tuteur IA a pour consigne de ne jamais donner les réponses des quiz et examens.
- **Projets** : livrables personnalisables (autre métier, autre jeu de données), journal d'expériences demandé, oral individuel ; comparaison avec les corrigés des labs et entre dépôts d'une même session (détection de similarité **[À COMPLÉTER PAR L'ORGANISME : outil]**) ; lecture de l'historique Git (un dépôt livré en un seul commit la veille mérite une question).
- **Soutenance** : questions de modification en direct ; demande de rejouer un test.

### 7.3 Indices qui doivent alerter (sans constituer une preuve)

- Code identique au corrigé `solution/` d'un lab, ou entre deux candidats.
- Sources ou URL inexistantes dans un rapport (signe d'une rédaction par IA non vérifiée).
- Écart net entre la qualité écrite et la capacité à expliquer à l'oral.
- Absence de section « Usage de l'IA » dans un projet manifestement assisté.
- Pendant l'examen : regard hors champ répété, absence de la caméra, durée anormalement courte avec un score très élevé.

### 7.4 Procédure

1. **Consigner** les faits (captures, extraits, horodatage), sans conclure.
2. **Entendre** le candidat (entretien ou écrit), qui peut s'expliquer.
3. **Transmettre** au responsable de la certification, qui décide : reprise de l'épreuve, annulation de l'épreuve, ou, en cas de fraude grave, annulation de la session ; révocation d'un certificat déjà délivré si la fraude est établie (action « Révoquer » de l'espace admin, journalisée).
4. **Notifier** la décision par écrit avec la voie de recours.
5. **Enregistrer** l'incident dans le registre des réclamations et incidents (analyse des risques, ind. 32).

---

## 8. Mise à jour annuelle du contenu

Les contenus d'IA vieillissent vite : modèles renommés, API modifiées, prix, réglementation. Une mise à jour **au moins annuelle** est prévue, et une veille **trimestrielle** alimente les indicateurs 23 à 25 de Qualiopi.

### 8.1 Les sources de la veille

| Dossier / fichier | Contenu | Usage |
|---|---|---|
| `_recherche/01-anthropic.md` à `06-data-engineering-big-data.md` | Recherche documentaire initiale par domaine (Anthropic ; OpenAI, xAI, Perplexity, n8n ; cours académiques ; LLM locaux ; réglementation et marché ; data engineering) | Point de départ de chaque révision |
| `_recherche/07-mise-a-jour-nov-2026.md` | Vérification des doutes (statuts ✅ ❌ ◐ ❓), nouveautés, liens à ajouter, corrections à appliquer | Modèle de la note de veille à produire chaque trimestre |
| `_corrections-appliquees-nov-2026.md` | Corrections déjà faites | Ne pas les refaire |
| `_corrections-en-attente.md` | Corrections prêtes (texte exact à remplacer) dans les leçons qui étaient verrouillées | À appliquer en premier |
| `_relecture-*.md` | Relectures indépendantes, doutes non tranchés | Liste des points à revérifier |
| `ressources/bibliotheque-liens.md` | Liens officiels classés | À tester (§ 8.3) |

### 8.2 Calendrier

| Moment | Action |
|---|---|
| Chaque trimestre | Note de veille datée sur le modèle de `_recherche/07` : changelogs des fournisseurs (Anthropic, OpenAI, xAI, Google, Mistral, Perplexity, n8n), dépréciations annoncées, OWASP, MCP, AI Act, CNIL, CPF, Qualiopi. |
| Chaque année (avant la rentrée de septembre, par exemple) | Révision complète (§ 8.3), nouvelle version du programme (`programme.json` → `version`, `versionDate`), information des apprenants en cours |
| À chaque dépréciation annoncée | Correctif ciblé avant la date d'arrêt (exemples relevés en nov. 2026 : fine-tuning OpenAI fermé à tous les nouveaux jobs le 6 janvier 2027 ; série GPT-4 arrêtée le 14 janvier 2027 ; mode rapide d'Opus 4.8 supprimé le 30 novembre 2026) |

### 8.3 Procédure de vérification des points « à vérifier »

Au 5 novembre 2026, la mention **« à vérifier »** apparaît **129 fois dans 76 leçons**. Procédure :

1. **Inventorier** : `grep -rn "à vérifier" niveaux/` ; ajouter les ⚠️ et `[NON VÉRIFIÉ]` des dossiers `_recherche/` et les doutes ouverts des relectures.
2. **Prioriser** : d'abord ce qui fausse un quiz ou un examen (une réponse officielle fausse), puis les chiffres (prix, limites, dates), puis les noms d'API et de paramètres, enfin le contexte.
3. **Vérifier à la source primaire** : documentation officielle, notes de version, Légifrance, EUR-Lex, JORF, travail-emploi.gouv.fr. Une source secondaire est acceptable si la primaire est inaccessible, **à condition de la nommer** (comme le fait `_recherche/07`).
4. **Consigner** dans une nouvelle note `_recherche/0x-mise-a-jour-<mois-année>.md` : point, statut (✅ confirmé, ❌ infirmé, ◐ à nuancer, ❓ introuvable), réponse exacte, URL et date de lecture.
5. **Préparer les corrections** au format de `_corrections-en-attente.md` (fichier, texte exact actuel, remplacement, source), puis les appliquer ; corriger aussi les `quiz.json` et `examens/*.json` concernés (question, `answer`, `explanation`, `source`).
6. **Retirer la mention** « à vérifier » seulement si le statut est ✅ ou ❌ corrigé ; laisser la mention avec une date si le statut reste ❓.
7. **Contrôler** : `node scripts/validate.mjs` (structure, en-têtes, quiz, durées), puis `node scripts/validate.mjs --links` (liens), puis `node scripts/build.mjs` (régénère `programme.md` et `export/`). Exécuter les tests de l'application (`npm test` dans `app/`) si des quiz ou examens ont changé.
8. **Tracer** : consigner la version, la date, les fichiers modifiés et les corrections dans `_corrections-appliquees-<mois-année>.md` ; c'est la preuve de la veille et de l'amélioration continue (ind. 23-25, 32).

> ⚠️ **Piège fréquent** — Corriger une leçon sans corriger le quiz ou l'examen qui l'évalue (ou l'inverse). Le cas s'est produit en novembre 2026 (M17-Q04, explication fausse sur les messages `user` consécutifs). Cherchez toujours l'identifiant de la leçon (`lessonId`) dans les `quiz.json` et `examens/*.json` avant de clore une correction.

### 8.4 Remontées des formateurs

Toute erreur signalée par un apprenant ou repérée en classe virtuelle est consignée (leçon, extrait, source officielle, date) et traitée à la révision suivante ou immédiatement si elle fausse une évaluation. **[À COMPLÉTER PAR L'ORGANISME : outil de suivi, responsable des contenus]**
