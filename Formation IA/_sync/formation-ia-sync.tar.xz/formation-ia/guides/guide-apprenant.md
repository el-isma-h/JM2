# Guide de l'apprenant — Formation IA Next Formation (NF-IA-150)

> Version 1.0 — 5 novembre 2026. Ce guide répond à l'obligation d'information des formations à distance (art. D6313-3-1 du code du travail : activités à effectuer, durée moyenne, assistance, évaluations) et à l'indicateur 9 du référentiel national qualité (Qualiopi). Les mentions **[À COMPLÉTER PAR L'ORGANISME]** désignent des informations que seul Next Formation peut fournir (contacts, horaires, noms).

---

## 1. Bienvenue

Bienvenue dans la formation **« Formation IA complète — Next Formation »**. Elle vous emmène de zéro à expert en **150 heures à distance**, en quatre niveaux. Chaque niveau donne lieu à un certificat Next Formation :

| Niveau | Intitulé | Durée | Certificat | Prérequis |
|---|---|---|---|---|
| N1 | Fondamentaux de l'IA | 25 h | « Utilisateur IA certifié » | Savoir utiliser un ordinateur et un navigateur. Aucune programmation. |
| N2 | Praticien IA et automatisation | 35 h | « Praticien IA & automatisation » | N1 ou équivalent. Aucune programmation. |
| N3 | Développeur IA | 45 h | « Développeur IA » | Bases de Python ou de JavaScript/TypeScript, HTTP/JSON, Git. N2 recommandé. |
| N4 | Expert IA : du machine learning aux modèles de frontière | 45 h | « Expert IA » | N3 ou expérience équivalente ; Python solide. Les mathématiques sont reprises en M24. |
| N5 (option) | Data engineering & Big Data pour l'IA | 30 h | « Data engineer IA » | N3 validé ; SQL et Docker de base. **Hors parcours de 150 h.** |

Vous pouvez suivre un seul niveau ou tout le parcours. Le niveau 5 est une spécialisation : il s'ajoute aux 150 heures et s'ouvre dès que le niveau 3 est validé. Vous pouvez le suivre avant, après ou à la place du niveau 4.

Pour chaque niveau, la fiche `niveaux/Nx-…/niveau.md` (également affichée dans la plateforme) présente la promesse du niveau, les six compétences visées, le matériel, les comptes à créer et les certifications externes que vous pourrez passer ensuite. **Lisez-la avant de commencer le niveau.**

> 💡 **À retenir** — Les certificats Next Formation ne remplacent pas les certifications des éditeurs (Anthropic, n8n, Microsoft, AWS, Google…). La formation couvre leurs référentiels publics et vous encourage à les passer en plus, à vos frais et selon leurs propres règles.

---

## 2. Comment fonctionne la formation

### 2.1 La plateforme

La formation se suit sur l'application **Next Formation IA** (`https://formation.nikaholding.world/ia`). Votre compte est créé **sur invitation** : vous recevez un lien d'activation, vous choisissez votre mot de passe, puis vous arrivez sur votre tableau de bord. Ce tableau de bord affiche vos XP, votre série de jours, votre objectif du jour, le niveau en cours, un bouton « Reprendre » et vos derniers badges.

Navigation principale : **Parcours** (le chemin des leçons), **Révisions**, **Lexique**, **Ressources** (la bibliothèque de liens officiels), **Badges**, **Certificats**, **Profil** (mot de passe, thème clair ou sombre, objectif quotidien, clé API personnelle).

### 2.2 Niveaux, modules, leçons

- **30 modules** dans le parcours de 150 h (M01 à M30), plus 7 modules dans le niveau 5 (M31 à M37).
- **150 leçons** (L001 à L150), plus 34 leçons dans le niveau 5 (L151 à L184). Chaque leçon affiche sa **durée estimée** (de 40 à 60 min environ), ses objectifs et les compétences qu'elle travaille.
- **Parcours imposé** : les leçons d'un module se suivent dans l'ordre. Le **module suivant se débloque quand vous réussissez le quiz du module** (70 % minimum). L'**examen de niveau** se débloque quand tous les quiz du niveau sont réussis. Le **niveau suivant** se débloque quand l'examen est réussi.
- Sur le chemin, chaque leçon a un état : verrouillée, disponible, en cours, terminée, parfaite.

Une leçon suit toujours le même plan :

| Partie | Ce que vous y trouvez |
|---|---|
| 🎯 Ce que vous saurez faire | Les objectifs de la leçon, formulés par des verbes d'action. |
| 🧭 **En clair** | 3 à 6 phrases sans jargon, avec une analogie de la vie quotidienne. Si vous ne lisez que ce bloc, vous avez compris l'idée centrale. Commencez toujours par lui. |
| Sections numérotées | Le cours : explications, exemples concrets, code (à partir de N3), schémas, formules. Encadrés : 💡 **À retenir**, ⚠️ **Piège fréquent**, 🔗 **Documentation officielle**. |
| **Quiz éclair** | 2 à 3 questions placées à la fin des sections importantes, avec correction et explication immédiates. Ils vous rapportent des XP et alimentent vos révisions. Ils ne bloquent rien. |
| **Mission documentation** (« chasse à l'info ») | 1 ou 2 par leçon quand une documentation officielle s'y prête : vous ouvrez la page officielle indiquée (Anthropic, OpenAI, n8n, CNIL, Légifrance…), vous suivez les étapes et vous trouvez une information précise (un prix, un paramètre d'API, une limite, un article de loi). Un indice est disponible. La réponse est datée quand elle peut changer. |
| 🧪 Exercice pratique | Une consigne précise et des critères de réussite, parfois une piste de corrigé repliable. Dans les leçons de projet, l'exercice **est** l'épreuve pratique évaluée (voir § 5). |
| ✅ Auto-évaluation express | 3 questions rapides, réponses en fin de leçon. |
| 📚 Pour aller plus loin | Des liens vers les documentations officielles et les cours de référence (MIT, Stanford, Hugging Face…). |

Quand vous avez fini, cliquez sur **« J'ai terminé »** : la leçon passe à l'état « terminée » et ses questions entrent dans vos révisions.

### 2.3 Fiches mémo

Chaque module a sa **fiche mémo** : une page, à relire en 5 minutes, imprimable. Elle contient la phrase qui résume le module, les 7 idées à retenir (avec un renvoi vers la leçon), le schéma à connaître, un vocabulaire express, les pièges classiques, les chiffres ou commandes utiles et un auto-test de 3 questions. Relisez-la **juste avant le quiz du module** et **la veille de l'examen de niveau**.

### 2.4 Lexique

La page **Lexique** rassemble **589 termes** des cinq niveaux. Chaque terme a une définition simple, une analogie, un exemple dans une organisation française, des liens vers les termes voisins et la liste des leçons où il est traité. Vous pouvez filtrer par niveau et par catégorie. Gardez-le ouvert dans un onglet pendant les niveaux 3 et 4.

### 2.5 Révisions

La page **Révisions** vous propose des sessions de **10 questions** tirées des quiz de module et des quiz éclair **des leçons que vous avez terminées**. Elle fonctionne comme des boîtes de Leitner :

- une **bonne réponse** fait monter la question d'une boîte et espace la prochaine révision : 1 jour, puis 2, 4, 8 et 16 jours ;
- une **erreur** la remet dans la première boîte : elle revient dans 10 minutes ;
- les questions ratées passent d'abord, puis les questions échues les moins maîtrisées, puis celles des leçons les plus anciennes.

Chaque bonne réponse rapporte 2 XP. Le compteur « Dues » indique ce qui est à revoir aujourd'hui, et « Maîtrisées » ce qui est en dernière boîte.

### 2.6 Le tuteur IA

Dans chaque leçon, le panneau **« Demander au tuteur »** répond à vos questions **à partir du contenu de la leçon ouverte**. Il peut réexpliquer autrement (analogie, étapes, schéma en texte), donner un exemple dans votre métier ou vous poser un mini-quiz de 3 questions. Il répond en français, en général en moins de 250 mots.

Ce qu'il faut savoir :

- **Il ne donne jamais les réponses des quiz de module ni des examens.** Si vous collez une question officielle, il vous explique la notion pour que vous trouviez vous-même.
- Il peut se tromper. Il a pour consigne de dire quand il n'est pas sûr. **Vérifiez dans la leçon ou dans la documentation officielle** avant de retenir une information.
- Il faut une clé API (Anthropic, OpenAI ou xAI). Soit la plateforme en fournit une, soit vous utilisez la vôtre (« Apporter ma clé », stockée chiffrée). La page **Configurer une clé API** explique pas à pas comment en créer une, combien cela coûte et comment la protéger.
- Pour éviter les abus : 12 questions au maximum par tranche de 5 minutes, 150 par jour. Une question fait au plus 4 000 caractères.
- Ne lui confiez **aucune donnée personnelle ni confidentielle** (voir la charte, § 9).

### 2.7 Les labs

Certains projets sont accompagnés d'un **lab** : un dépôt de départ avec des données, des étapes guidées (« TODO »), des tests automatiques et un corrigé.

| Lab | Leçon | Ce que vous construisez |
|---|---|---|
| `labs/lab-claude-devis/` | L077 (N3, M17) | « Devis-Express », l'assistant de devis d'un électricien avec Claude : 7 TODO guidés en Python ou TypeScript, 25 tests, mode simulé sans clé API. |
| `labs/lab-openai-portage/` | L083 (N3, M18) | Le même type d'assistant porté sur l'API OpenAI, sans changer son comportement : 7 TODO, 20 cas de test. |
| `labs/lab-rag-code/` | M20 (N3) | Un corpus de procédures internes et un jeu de tests (questions, sources attendues, cas hors périmètre) pour évaluer votre RAG. |

> ⚠️ **Piège fréquent** — Ouvrir le dossier `solution/` avant d'avoir essayé. Les tests sont **rouges au départ, c'est normal**. Faites passer les tests un par un ; le corrigé sert à comparer après coup.

Les leçons du niveau 5 utilisent en plus un environnement de TP gratuit et local (Docker Compose) sur le jeu de données fil rouge « Bréval Matériaux ».

### 2.8 Motivation : XP, badges, série

Leçon terminée : +20 XP. Quiz réussi : +50 XP (+50 de plus sans faute). Examen réussi : +300 XP. S'y ajoutent les XP des quiz éclair, des missions et des révisions. La **série** compte les jours consécutifs où vous atteignez votre objectif quotidien (réglable dans votre profil). **Il n'y a aucun classement entre apprenants.** Les badges sont une reconnaissance complémentaire : ils n'ont pas valeur de certification.

---

## 3. Plannings types

### 3.1 Trois rythmes

| Rythme | Durée | Charge | Pour qui |
|---|---|---|---|
| **Intensif** | 4 semaines | ≈ 37 h 30 par semaine (temps plein) | Demandeurs d'emploi, reconversion, période de formation financée à temps plein |
| **Standard** | 12 semaines | ≈ 12 h 30 par semaine (2 h 30 par jour ouvré, ou 3 soirs + le samedi) | Salariés en formation sur temps de travail partiel, indépendants |
| **Temps partiel** | 6 mois (26 semaines) | ≈ 6 h par semaine (1 h par jour en semaine + 1 h le week-end) | Salariés en formation hors temps de travail |

Les heures par semaine ci-dessous reprennent les **durées officielles des niveaux** (25, 35, 45 et 45 h, quiz et examens compris), réparties entre les modules au prorata des durées de `programme/programme.json`. Une semaine « 12 h 30 » est une moyenne : certaines leçons de projet prennent plus de temps que prévu, d'autres moins.

Points d'attention communs aux trois rythmes :

- Les **épreuves pratiques** (projets) sont déposées puis corrigées par un formateur ; la **soutenance** devant le jury se tient à une date de session fixée par l'organisme. Le calendrier ci-dessous indique quand vous réalisez le projet, pas la date de soutenance.
- En cas d'échec à l'examen, il faut attendre **7 jours** avant la tentative suivante. Prévoyez donc une marge d'une semaine par niveau si vous visez une date précise.
- Si vous suivez le **niveau 5**, ajoutez 30 h : environ 1 semaine en intensif, 2 à 3 semaines en standard, 5 semaines en temps partiel.

### 3.2 Intensif — 4 semaines (≈ 37 h 30 par semaine)

| Semaine | Contenu | Heures | Cumul | Jalons |
|---|---|---|---|---|
| S1 | N1 complet (M01 à M07 + examen N1), M08, M09, début de M10 | 37,5 | 37,5 | Examen N1 en fin de mercredi ; projet n8n support client (L038) jeudi-vendredi |
| S2 | Fin de M10, M11 à M15, examen N2, M16, M17, début de M18 | 37,5 | 75 | Projets L048 (RAG sans code), L058 (reporting), L063 (politique IA) ; examen N2 ; lab L077 |
| S3 | Fin de M18, M19 à M23, examen N3, M24, début de M25 | 37,5 | 112,5 | Projets L083, L094, L100, L105, L110 ; examen N3 ; épreuve écrite de maths (M24) |
| S4 | Fin de M25, M26 à M30, examen N4 | 37,5 | 150 | Projets L120, L127, L140, déploiement M29, rapport final L150 ; examen N4 |

> ⚠️ **Piège fréquent** — Le rythme intensif laisse peu de place aux six projets de code du niveau 3. Réservez la soirée ou le samedi de la semaine 3 pour les terminer, et n'hésitez pas à demander au formateur de décaler une remise : c'est prévu.

### 3.3 Standard — 12 semaines (≈ 12 h 30 par semaine)

| Semaine | Modules | Heures | Cumul | Jalons et épreuves |
|---|---|---|---|---|
| S1 | M01, M02, M03, début de M04 | 12,5 | 12,5 | Créer les comptes gratuits (Claude, ChatGPT, Gemini, Perplexity, Le Chat) avant M03 |
| S2 | Fin de M04, M05, M06, M07, **examen N1** | 12,5 | 25 | Atelier 10 prompts (L020), étude de cas RGPD / AI Act (L028-L029), examen N1 |
| S3 | M08, M09, début de M10 | 12,5 | 37,5 | **Projet** workflow n8n support client (L038) ; installer Ollama et Docker Desktop |
| S4 | Fin de M10, M11, M12, début de M13 | 12,5 | 50 | Installation documentée d'un LLM local (L043) ; **projet** assistant RAG (L048 / L052) |
| S5 | Fin de M13, M14, M15, **examen N2**, début de M16 | 12,5 | 62,5 | **Projets** reporting hebdomadaire (L058), politique IA (L063), production multimédia (M14) ; examen N2 |
| S6 | Fin de M16, M17, début de M18 | 12,5 | 75 | Créer les clés API et plafonner les dépenses (L067) ; **projet** assistant Claude (L077, lab) |
| S7 | Fin de M18, M19, début de M20 | 12,5 | 87,5 | **Projet** portage OpenAI (L083, lab) |
| S8 | Fin de M20, M21, M22, début de M23 | 12,5 | 100 | **Projets** RAG d'entreprise (L094), agent + serveur MCP (L100), application déployée (L105). Semaine chargée : commencez L105 dès que M22 est lu. |
| S9 | Fin de M23, **examen N3**, M24, début de M25 | 12,5 | 112,5 | **Atelier** audit de sécurité (L110) ; examen N3 ; épreuve écrite de maths (M24, 90 min) |
| S10 | Fin de M25, M26, début de M27 | 12,5 | 125 | **Projets** ML (L120) et DL (L127) ; ouvrir un compte Colab ou Kaggle |
| S11 | Fin de M27, début de M28 | 12,5 | 137,5 | Préparer le jeu de données et les 40 cas d'évaluation du fine-tuning (L140) **avant** d'entraîner |
| S12 | Fin de M28, M29, M30, **examen N4** | 12,5 | 150 | **Projets** fine-tuning (L140), déploiement servi (M29), rapport final sûreté et gouvernance (L150) ; examen N4 |

### 3.4 Temps partiel — 6 mois (26 semaines, ≈ 6 h par semaine)

| Semaine | Modules | Heures | Cumul | Jalons |
|---|---|---|---|---|
| S1 | M01, début de M02 | 5,8 | 5,8 | |
| S2 | Fin de M02, M03, début de M04 | 5,8 | 11,5 | Comptes gratuits créés |
| S3 | Fin de M04, début de M05 | 5,8 | 17,3 | Atelier 10 prompts (L020) |
| S4 | Fin de M05, M06, début de M07 | 5,8 | 23,1 | |
| S5 | Fin de M07, **examen N1**, début de M08 | 5,8 | 28,8 | Examen N1 |
| S6 | Fin de M08, M09, début de M10 | 5,8 | 34,6 | **Projet** L038 |
| S7 | Fin de M10 | 5,8 | 40,4 | Installation LLM local (L043) |
| S8 | M11, début de M12 | 5,8 | 46,2 | **Projet** RAG sans code (L048) |
| S9 | Fin de M12, début de M13 | 5,8 | 51,9 | |
| S10 | Fin de M13, M14, début de M15 | 5,8 | 57,7 | **Projets** L058 et M14 |
| S11 | Fin de M15, **examen N2**, M16 | 5,8 | 63,5 | Politique IA (L063) ; examen N2 |
| S12 | Début de M17 | 5,8 | 69,2 | Clés API plafonnées |
| S13 | Fin de M17, début de M18 | 5,8 | 75 | **Projet** L077 |
| S14 | Fin de M18, début de M19 | 5,8 | 80,8 | **Projet** L083 |
| S15 | Fin de M19, début de M20 | 5,8 | 86,5 | |
| S16 | Fin de M20, début de M21 | 5,8 | 92,3 | **Projet** L094 |
| S17 | Fin de M21, début de M22 | 5,8 | 98,1 | **Projet** L100 |
| S18 | Fin de M22, début de M23 | 5,8 | 103,8 | **Projet** L105 |
| S19 | Fin de M23, **examen N3**, début de M24 | 5,8 | 109,6 | Atelier L110 ; examen N3 |
| S20 | Fin de M24, début de M25 | 5,8 | 115,4 | Épreuve écrite de maths |
| S21 | Fin de M25, début de M26 | 5,8 | 121,2 | **Projet** L120 |
| S22 | Fin de M26, début de M27 | 5,8 | 126,9 | **Projet** L127 |
| S23 | Fin de M27, début de M28 | 5,8 | 132,7 | Jeu d'évaluation du fine-tuning |
| S24 | Fin de M28 | 5,8 | 138,5 | **Projet** L140 |
| S25 | M29, début de M30 | 5,8 | 144,2 | Déploiement servi (M29) |
| S26 | Fin de M30, **examen N4** | 5,8 | 150 | Rapport final (L150) ; examen N4 |

> 💡 **À retenir** — À temps partiel, le plus grand risque est l'abandon entre deux niveaux. Fixez-vous un créneau fixe dans votre agenda, gardez une série de révisions même les semaines chargées (10 questions = 5 minutes) et prévenez votre formateur-référent si vous prenez du retard : il peut adapter le calendrier.

---

## 4. Méthode d'apprentissage

La formation applique trois principes. Ils sont simples, mais ils font la différence entre « j'ai lu » et « je sais faire ».

### 4.1 Répéter dans le temps plutôt que relire

On oublie très vite ce qu'on a lu une seule fois. Ce qui fixe un souvenir, c'est d'**essayer de s'en rappeler** à intervalles croissants.

- Faites une session de **Révisions** chaque jour où vous vous connectez, avant la nouvelle leçon (5 à 10 minutes).
- Répondez aux quiz éclair **sans remonter dans le texte** ; si vous vous trompez, relisez la section, puis continuez.
- Relisez la fiche mémo avant le quiz du module, refaites son auto-test, et relisez toutes les fiches du niveau la veille de l'examen.
- Les quiz de module sont illimités : si vous réussissez à 70 % « de justesse », refaites-le deux jours plus tard.

### 4.2 Pratiquer à chaque leçon

On n'apprend pas l'IA en la regardant. Chaque leçon a un exercice : **faites-le vraiment**, même brièvement, avec vos propres données (anonymisées) ou celles fournies. Pour les projets :

1. lisez les **critères de réussite avant de commencer** ;
2. livrez une version minimale qui marche, puis améliorez ;
3. gardez un **journal** (ce que vous avez essayé, ce qui a échoué, pourquoi) : il vous servira en soutenance ;
4. auto-évaluez-vous avec la grille de la leçon avant de déposer.

### 4.3 Revenir à la documentation officielle

Les outils d'IA changent chaque mois. Votre compétence la plus durable sera de **savoir trouver l'information juste à la source**.

- Les missions documentation vous entraînent à lire les pages officielles (Anthropic, OpenAI, xAI, Perplexity, Mistral, Google, Hugging Face, n8n, CNIL, Légifrance…). La page **Ressources** les rassemble.
- Quand un chiffre est daté « (nov. 2026) », vérifiez-le avant de l'utiliser dans un contexte professionnel.
- Les points que l'équipe n'a pas pu confirmer sont marqués **« à vérifier »** dans les leçons : c'est volontaire, et c'est une bonne occasion de faire vous-même la vérification.
- Ne prenez jamais une réponse d'IA (y compris celle du tuteur) pour une source.

### 4.4 Une séance type de 2 h 30 (rythme standard)

| Temps | Activité |
|---|---|
| 10 min | Révisions (10 questions) |
| 5 min | Bloc « En clair » de la leçon du jour, puis objectifs |
| 60 min | Lecture active : sections, quiz éclair, mission documentation |
| 45 min | Exercice pratique |
| 10 min | Auto-évaluation express, « J'ai terminé », une question au tuteur si un point reste flou |
| 20 min | Leçon suivante (début) ou fiche mémo + quiz si le module est fini |

---

## 5. Évaluation et certificat

### 5.1 Les trois types d'épreuves

| Épreuve | Format | Règle |
|---|---|---|
| **Quiz de fin de module** | 10 questions (QCM, vrai/faux, « trouvez l'erreur », mises en situation), environ 15 min | Seuil **70 %**. Tentatives **illimitées**, avec une explication et une source par question. Réussir le quiz débloque le module suivant. |
| **Examen de niveau** | 40 questions, majoritairement des mises en situation, **60 min** chronométrées par le serveur | Seuil **70 %**. **3 tentatives maximum** par niveau, **7 jours d'attente** entre deux tentatives. Questions et réponses mélangées. Surveillance à distance (identité vérifiée, webcam). Soumission automatique à la fin du temps. Résultat détaillé par compétence après soumission. |
| **Épreuves pratiques** | Projets, ateliers, études de cas, épreuve écrite (N4) | Évaluées par un formateur-évaluateur sur une grille de 5 critères notés de 0 à 3. **Compétence validée si la note est d'au moins 8/15 et qu'aucun critère n'est à 0.** Certains projets ont en plus une grille sur 100 points (voir la leçon). |

Pendant l'examen, vous pouvez naviguer entre les questions et marquer celles « à revoir ». Les bonnes réponses ne sont jamais envoyées à votre navigateur avant la soumission.

### 5.2 Les épreuves pratiques par niveau

| Niveau | Épreuves pratiques | Compétences |
|---|---|---|
| N1 | Atelier de 10 prompts (L020, journal évalué sur grille) ; étude de cas RGPD / AI Act avec charte d'usage simplifiée (L028-L029) ; étude de cas de vérification d'une production IA | C1.1 à C1.6 |
| N2 | Workflow n8n support client (L038) ; assistant RAG à 8 bonnes réponses sur 10 avec sources (L048 / L052) ; installation documentée d'un LLM local (L043) ; reporting automatisé (L058) ; politique IA et grille SaaS / API / local (L063) ; production multimédia (M14) | C2.1 à C2.6 |
| N3 | Six dépôts Git : assistant Claude (L077), portage OpenAI (L083), RAG (L094), agent + serveur MCP (L100), application déployée (L105), audit de sécurité (L110) | C3.1 à C3.6 |
| N4 | Épreuve écrite de maths (M24, 90 min) ; projets ML (L120), DL (L127), fine-tuning (L140), déploiement servi (M29) ; rapport final de sûreté et de gouvernance (L150) | C4.1 à C4.6 |
| N5 | Cinq ateliers (L155, L159-L160, L165, L169, dossier M35) et un projet final avec soutenance de 15 min (M37) | C5.1 à C5.6 |

Règles de dépôt des projets de code : **aucune clé API dans le code** (variables d'environnement), un README qui explique comment l'exécuter, le coût estimé par appel, des tests.

### 5.3 Le certificat

- Le certificat Next Formation d'un niveau est délivré quand **toutes les compétences du niveau sont validées** : examen réussi **et** épreuves pratiques validées. **Pas de compensation** : une excellente note sur un projet ne rattrape pas une compétence non atteinte.
- Une compétence non validée peut être **repassée dans un délai de 6 mois**. Une épreuve pratique peut être reprise une fois, avec un retour écrit du correcteur.
- Pour la certification enregistrée (option RS, en vue de l'éligibilité au CPF), une **soutenance devant un jury de 2 personnes**, dont au moins un professionnel extérieur à l'équipe pédagogique, est ajoutée : 20 min pour N1 à N3, 30 min pour N4, 15 min pour N5.
- Le certificat est un **PDF** téléchargeable dans la page **Certificats**. Il porte un numéro unique (`NF-IA-N{niveau}-{année}-{6 caractères}`) et un **QR code** : n'importe quel employeur peut vérifier son authenticité sur la page publique `/ia/verifier/{numéro}`.
- Vous recevez aussi un **certificat de réalisation** (heures et résultats) et une **attestation de fin de formation**, distincts du certificat de niveau. **[À COMPLÉTER PAR L'ORGANISME : modalités et délai d'envoi]**

---

## 6. Assistance

La formation est à distance, mais vous n'êtes pas seul. Trois formes d'assistance sont prévues.

| Assistance | Comment | Délai |
|---|---|---|
| **Pédagogique** : une notion, un exercice, un projet, un blocage | Votre **formateur-référent** : **[À COMPLÉTER PAR L'ORGANISME : canal (messagerie, e-mail), nom, adresse]** | Réponse **sous 24 h ouvrées** |
| **Classes virtuelles** | Une séance de 60 min par semaine et par niveau, facultative : questions-réponses, démonstrations, préparation des projets. **[À COMPLÉTER PAR L'ORGANISME : jour, heure, lien]** | Hebdomadaire |
| **Technique** : connexion, invitation expirée, certificat, déblocage, clé API | **[À COMPLÉTER PAR L'ORGANISME : contact support technique]** | **[À COMPLÉTER PAR L'ORGANISME]** (24 h ouvrées recommandées) |
| **Tuteur IA** | Panneau dans chaque leçon | Immédiat (ne remplace pas le formateur) |

Votre formateur suit votre progression. Si vous n'êtes pas connecté depuis 7 jours, il vous contactera pour faire le point : ce n'est pas une sanction, c'est l'accompagnement prévu par la réglementation des formations à distance. Les échanges avec votre formateur sont conservés comme preuve de l'accompagnement.

**Réclamations** : vous pouvez adresser une réclamation écrite à **[À COMPLÉTER PAR L'ORGANISME : adresse]**. Pour une décision de certification, le recours se fait par écrit sous 30 jours auprès du responsable de la certification, qui répond sous 30 jours.

**Signalement** : tout comportement de violence, de harcèlement ou de discrimination (y compris dans les classes virtuelles ou les échanges en ligne) peut être signalé à **[À COMPLÉTER PAR L'ORGANISME : référent, procédure]**.

---

## 7. Accessibilité et handicap

- Les leçons sont des **textes structurés** (titres, listes, tableaux), compatibles avec les lecteurs d'écran ; les liens externes s'ouvrent dans un nouvel onglet ; la plateforme propose un **mode sombre** et respecte le réglage « réduire les animations » de votre système.
- Les vidéos externes citées ne sont pas produites par Next Formation : quand une transcription existe, elle est recommandée.
- **Temps majoré d'un tiers** aux examens (80 min au lieu de 60) sur demande, et aménagement des soutenances (durée, pauses, format).
- Contactez le **référent handicap** **avant le début de la formation** ou au plus tard deux semaines avant un examen : **[À COMPLÉTER PAR L'ORGANISME : nom, contact]**. Vos informations restent confidentielles ; seul l'aménagement est communiqué aux personnes qui l'organisent.
- Si un élément de la plateforme vous gêne (contraste, navigation au clavier, formule mathématique illisible), signalez-le : il sera corrigé ou une alternative vous sera proposée.

---

## 8. Questions fréquentes

**1. Ai-je besoin de savoir coder ?**
Non pour les niveaux 1 et 2. Oui à partir du niveau 3 (bases de Python ou de JavaScript/TypeScript). Le module 16 propose une remise à niveau.

**2. Puis-je commencer directement au niveau 3 ?**
Oui si vous avez les prérequis. Un test de positionnement le vérifie ; le formateur peut alors débloquer le niveau pour vous.

**3. Que se passe-t-il si j'échoue au quiz d'un module ?**
Rien de grave : les quiz sont illimités. Lisez les explications, relisez la fiche mémo, faites une session de révisions, puis recommencez.

**4. Et si j'échoue à l'examen de niveau ?**
Vous avez 3 tentatives, avec 7 jours d'attente entre chacune. Le résultat par compétence vous montre quoi retravailler. Après 3 échecs, contactez votre formateur : il étudie avec vous la suite (accompagnement, nouvelle session).

**5. Combien de temps ai-je pour finir ?**
Cela dépend de votre convention ou de votre contrat de formation : **[À COMPLÉTER PAR L'ORGANISME]**. Les trois plannings types (4 semaines, 12 semaines, 6 mois) sont des repères.

**6. Mon temps de formation est-il compté ?**
Oui. La plateforme mesure le temps passé sur chaque leçon (onglet visible, plafonné), les dates d'ouverture et de fin, les résultats des quiz et des examens. Ces relevés, validés par l'organisme, servent de preuve de réalisation (par exemple pour un financement CPF ou OPCO).

**7. Laisser une leçon ouverte compte-t-il comme du temps ?**
Non. Le temps n'est compté que si l'onglet est visible, et il est plafonné. Et surtout, le temps seul ne suffit pas : ce sont vos résultats et vos dépôts qui prouvent la formation.

**8. Dois-je payer des abonnements ou des API ?**
Aucun abonnement n'est requis aux niveaux 1 et 2 (comptes gratuits). Au niveau 3, comptez environ 20 à 40 € de crédits d'API pour tout le niveau. Au niveau 4, environ 10 à 30 € de GPU dans le cloud. Le niveau 5 tourne gratuitement en local. Chaque leçon concernée explique comment plafonner vos dépenses.

**9. Quel ordinateur me faut-il ?**
N1 : n'importe quel ordinateur ou tablette récent. N2 et N3 : 16 Go de RAM recommandés (8 Go minimum), 30 Go d'espace disque. N4 : pas de GPU obligatoire (Colab ou Kaggle suffisent). Webcam et micro pour les examens et les soutenances. Le détail est dans chaque `niveau.md`.

**10. Le tuteur IA peut-il faire mes exercices à ma place ?**
Il peut vous expliquer, vous donner un exemple ou vous interroger. Il ne donne jamais les réponses des quiz ni des examens. Pour les projets, voyez la charte (§ 9) : ce que vous rendez doit être votre travail, et vous devez pouvoir l'expliquer.

**11. Le tuteur ne répond pas. Pourquoi ?**
Soit aucune clé API n'est configurée (le panneau l'indique), soit vous avez atteint la limite (12 questions par 5 minutes, 150 par jour). Patientez ou configurez votre propre clé dans « Configurer une clé API ».

**12. Ma clé API est-elle en sécurité ?**
Elle est stockée **chiffrée** (AES-256-GCM) et n'est jamais affichée en clair. Fixez quand même un plafond de dépense chez le fournisseur, et révoquez-la à la fin de la formation.

**13. Les certificats Next Formation sont-ils reconnus ?**
Ce sont des certificats d'organisme, vérifiables en ligne. Leur enregistrement au Répertoire spécifique de France Compétences, condition de l'éligibilité au CPF, est **en préparation** : **[À COMPLÉTER PAR L'ORGANISME : état de l'enregistrement ou de l'habilitation]**. Ils ne valent pas équivalence des certifications des éditeurs.

**14. Puis-je financer la formation avec mon CPF ?**
Seulement quand la certification visée est enregistrée au Répertoire spécifique (ou que Next Formation est habilité par un certificateur enregistré). Depuis le 2 avril 2026, un reste à charge de 150 € s'applique (sauf exonérations, par exemple demandeurs d'emploi ou abondement employeur). **[À COMPLÉTER PAR L'ORGANISME : financements ouverts, tarifs]**

**15. Puis-je passer les certifications officielles d'Anthropic, de n8n, de Microsoft, etc. ?**
Oui, et c'est encouragé. Chaque `niveau.md` liste celles qui correspondent. Attention : les certifications Claude Certified sont réservées aux salariés des organisations membres du Claude Partner Network.

**16. Le niveau 5 est-il obligatoire ?**
Non. C'est une spécialisation de 30 h, hors parcours de 150 h, accessible après le niveau 3. Son examen est en cours de finalisation.

**17. J'ai perdu ma progression / un module reste verrouillé alors que j'ai réussi le quiz.**
Rechargez la page, puis contactez le support : le formateur voit votre historique complet et peut débloquer un module ou un niveau manuellement.

**18. Puis-je utiliser mes propres documents dans les exercices ?**
Oui, c'est même recommandé, **à condition qu'ils ne contiennent ni données personnelles ni informations confidentielles** (ou qu'ils soient anonymisés). Sinon, utilisez les jeux de données fournis.

**19. Une information d'une leçon me semble fausse ou dépassée.**
C'est possible : l'IA évolue vite. Signalez-la à votre formateur avec la source officielle. Les contenus sont relus et mis à jour au moins une fois par an.

**20. Que deviennent mes données ?**
Votre compte, votre progression et vos résultats sont conservés pour justifier la réalisation de la formation et délivrer les certificats. **[À COMPLÉTER PAR L'ORGANISME : durée de conservation, responsable de traitement, contact pour exercer vos droits RGPD]**

---

## 9. Charte d'usage de l'IA pendant la formation

Cette formation vous apprend à **utiliser l'IA**. Il serait absurde de vous l'interdire. Mais une certification atteste que **vous** savez faire : les règles ci-dessous distinguent l'apprentissage, où l'IA est une alliée, et l'évaluation certificative, où elle est encadrée.

### 9.1 Ce qui est autorisé et ce qui ne l'est pas

| Activité | Usage de l'IA | Conditions |
|---|---|---|
| Lecture des leçons, révisions, fiches mémo | ✅ Autorisé | Tuteur IA ou tout assistant pour reformuler, illustrer, s'entraîner. Vérifiez ce qu'il dit. |
| Quiz éclair, missions documentation | ✅ Autorisé mais déconseillé pour répondre | Ils servent à vous entraîner : répondre avec une IA ne fait que fausser vos révisions. Une mission se résout **dans la documentation officielle**, pas dans un chatbot. |
| Exercices pratiques non évalués | ✅ Autorisé | C'est souvent l'objet même de l'exercice (prompts, n8n, API…). |
| **Quiz de fin de module** | ⚠️ Toléré, non recommandé | Ils sont formatifs, mais ils conditionnent le déblocage et sont enregistrés. Répondez seul : c'est votre meilleure préparation à l'examen. |
| **Examen de niveau** | ❌ **Interdit** | Aucun assistant IA, aucun moteur de recherche, aucune aide extérieure, aucun second écran. Surveillance à distance. |
| **Épreuve écrite de maths (N4)** | ❌ **Interdit** | Comme l'examen. Calculatrice simple autorisée **[À COMPLÉTER PAR L'ORGANISME si différent]**. |
| **Projets et épreuves pratiques** | ✅ Autorisé **avec déclaration** | Assistants de code (Claude Code, Copilot…), aide à la rédaction, génération de données de test : oui, si vous le **déclarez** (§ 9.2) et si vous **comprenez et pouvez expliquer chaque partie** de ce que vous rendez. Quand l'IA est l'objet de l'épreuve (appel d'API, agent, RAG), elle fait évidemment partie du livrable. |
| Rapports écrits (politique IA, audit, rapport final N4, dossier N5) | ✅ Autorisé **avec déclaration** | Reformulation et relecture : oui. Faire rédiger l'analyse, les choix ou les conclusions par une IA : non. Les sources citées doivent être réelles et vérifiées par vous. |
| **Soutenance devant le jury** | ❌ **Interdit** pendant les questions | Vous pouvez faire tourner votre prototype en démonstration. Vous ne pouvez pas vous faire souffler les réponses par une IA ou une personne. |

### 9.2 La déclaration d'usage de l'IA dans un projet

Ajoutez à chaque projet une section **« Usage de l'IA »** dans le README ou le rapport :

- les outils utilisés (nom, modèle si connu) ;
- pour quoi (génération de code, débogage, reformulation, données synthétiques, tests…) ;
- les parties concernées (fichiers, sections) ;
- ce que vous avez vérifié ou modifié vous-même.

Une déclaration honnête **ne fait pas perdre de points**. Un usage non déclaré, découvert en correction ou en soutenance, est traité comme une fraude.

### 9.3 Règles permanentes, en formation comme au travail

1. **Aucune donnée personnelle ni confidentielle** dans un outil d'IA (le tuteur compris) : pas de nom de client, de numéro de sécurité sociale, de salaire, de document interne non anonymisé. C'est l'objet même de la leçon L028.
2. **Aucune clé API dans un dépôt ni dans un message.** Une clé exposée doit être **révoquée**, pas seulement supprimée.
3. **Les tests d'attaque** (injection de prompt, red teaming) ne visent **que** les applications fournies par la formation, sur votre machine. Jamais un service tiers, même « pour voir ».
4. **Citez vos sources.** Une réponse d'IA n'est pas une source ; une page officielle, un article ou un texte de loi en est une.
5. **Respectez les droits** : licences des modèles et des jeux de données, droit d'auteur, mention des contenus générés (M07, M14).

### 9.4 En cas de manquement

Le formateur ou le jury qui constate un manquement (aide extérieure à l'examen, usage non déclaré, travail d'un tiers, sources inventées) le signale au responsable de la certification. La sanction peut aller de la **reprise de l'épreuve** à son **annulation**. Vous êtes entendu avant toute décision et vous disposez d'une voie de recours (§ 6).
