"use client";

import * as React from "react";
import { motion, useReducedMotion } from "motion/react";
import { HardDrives, Lightning } from "@phosphor-icons/react";
import {
  CONTEXT_STEPS,
  COMFORT_TPS,
  LLM_PRESETS,
  PARAM_STEPS,
  PRECISIONS,
  allVerdicts,
  estimateLlm,
  formatGb,
  formatParams,
  type MachineVerdict,
  type Precision,
  type Verdict,
} from "@/domain/labo/llm-memory";
import { Badge, type Tone } from "@/components/ui/badge";
import { Notice } from "@/components/ui/surface";
import { Challenge, Range, Readout, Segmented, ToggleRow, useLaboUse } from "./controls";
import { cn } from "@/lib/utils";

const VERDICT: Record<Verdict, { label: string; tone: Tone }> = {
  confort: { label: "Confortable", tone: "ok" },
  serre: { label: "Serré", tone: "warn" },
  lent: { label: "Lent", tone: "warn" },
  impossible: { label: "Ne tient pas", tone: "danger" },
};

const ctxLabel = (t: number) => `${Math.round(t / 1024)}K`;
const fmtTps = (v: number) => (v >= 100 ? Math.round(v).toString() : v.toLocaleString("fr-FR", { maximumFractionDigits: v < 10 ? 1 : 0 }));

export function LlmCalculator() {
  const reduce = useReducedMotion();
  const markUsed = useLaboUse("memoire-llm");
  const [paramIdx, setParamIdx] = React.useState<number>(PARAM_STEPS.indexOf(8));
  const [moe, setMoe] = React.useState(false);
  const [activeB, setActiveB] = React.useState(5);
  const [precision, setPrecision] = React.useState<Precision>("Q4");
  const [ctxIdx, setCtxIdx] = React.useState<number>(CONTEXT_STEPS.indexOf(8192));
  const [customTotal, setCustomTotal] = React.useState<number | null>(null);

  const totalB = customTotal ?? PARAM_STEPS[paramIdx];
  const active = moe ? Math.min(activeB, totalB) : totalB;
  const ctx = CONTEXT_STEPS[ctxIdx];
  const est = estimateLlm({ totalB, activeB: active, precision, contextTokens: ctx });
  const verdicts = allVerdicts(est);
  const weightsShare = est.totalGb > 0 ? (est.weightsGb / est.totalGb) * 100 : 100;
  const touch = <T,>(fn: (v: T) => void) => (v: T) => {
    markUsed();
    fn(v);
  };

  const applyPreset = (id: string) => {
    const p = LLM_PRESETS.find((x) => x.id === id);
    if (!p) return;
    markUsed();
    const idx = PARAM_STEPS.indexOf(p.totalB as (typeof PARAM_STEPS)[number]);
    if (idx >= 0) {
      setParamIdx(idx);
      setCustomTotal(null);
    } else setCustomTotal(p.totalB);
    setMoe(p.activeB < p.totalB);
    setActiveB(p.activeB);
    setPrecision(p.precision);
  };

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-8">
      <div className="grid grid-cols-[minmax(0,1fr)] gap-6 lg:items-start lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        {/* Réglages */}
        <div className="grid content-start gap-5 border border-line bg-bg-elev p-5">
          <div className="grid gap-1.5">
            <span className="font-mono text-[10px] font-medium uppercase tracking-[0.2em] text-ink-3">Exemples de la leçon L042</span>
            <div className="flex flex-wrap gap-1.5">
              {LLM_PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => applyPreset(p.id)}
                  className="border border-line-strong px-2.5 py-1 text-[12px] text-ink-2 transition-colors duration-300 hover:border-ink hover:text-ink"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
          <Range
            id="llm-params"
            label={moe ? "Paramètres totaux" : "Paramètres"}
            value={customTotal !== null ? Math.max(0, PARAM_STEPS.findIndex((s) => s >= customTotal)) : paramIdx}
            min={0}
            max={PARAM_STEPS.length - 1}
            onChange={touch((v: number) => {
              setCustomTotal(null);
              setParamIdx(v);
            })}
            display={formatParams(totalB)}
            valueText={`${formatParams(totalB)} paramètres`}
          />
          <ToggleRow
            id="llm-moe"
            label="Modèle MoE (Mixture of Experts)"
            hint="Le total décide de la mémoire ; les paramètres actifs décident de la vitesse."
            checked={moe}
            onChange={touch(setMoe)}
          />
          {moe ? (
            <Range
              id="llm-active"
              label="Paramètres actifs par token"
              value={Math.min(activeB, totalB)}
              min={0.5}
              max={Math.max(1, Math.min(totalB, 64))}
              step={0.1}
              onChange={touch(setActiveB)}
              display={formatParams(active)}
              valueText={`${formatParams(active)} actifs`}
            />
          ) : null}
          <Segmented
            label="Précision des poids"
            value={precision}
            columns={3}
            options={PRECISIONS.map((p) => ({ value: p.id, label: p.id, title: `${p.label} — ${p.quality}` }))}
            onChange={touch(setPrecision)}
          />
          <p className="-mt-3 text-[12px] text-ink-3">
            {PRECISIONS.find((p) => p.id === precision)!.label} · {PRECISIONS.find((p) => p.id === precision)!.quality}
          </p>
          <Range
            id="llm-ctx"
            label="Contexte utilisé"
            value={ctxIdx}
            min={0}
            max={CONTEXT_STEPS.length - 1}
            onChange={touch(setCtxIdx)}
            display={`${ctxLabel(ctx)} tokens`}
            valueText={`${ctx} tokens de contexte`}
          />
        </div>

        {/* Lecture */}
        <div className="grid content-start gap-6">
          <div className="border border-line bg-bg-elev p-5">
            <Readout value={formatGb(est.totalGb).replace(/ (Go|To)$/, "")} unit={formatGb(est.totalGb).endsWith("To") ? "To de mémoire" : "Go de mémoire"} caption="Poids + KV cache, avant la marge du système." />
            <div className="mt-5" aria-hidden>
              <div className="flex h-3 w-full overflow-hidden border border-line">
                <motion.div className="h-full bg-accent" initial={false} animate={{ width: `${weightsShare}%` }} transition={reduce ? { duration: 0 } : { duration: 0.45, ease: [0.22, 1, 0.36, 1] }} />
                <div className="labo-hachures h-full flex-1" />
              </div>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-x-6 gap-y-3 text-[13px] sm:grid-cols-4">
              <div>
                <dt className="flex items-center gap-1.5 text-ink-3">
                  <span className="inline-block h-2 w-2 bg-accent" aria-hidden /> Poids
                </dt>
                <dd className="num mt-0.5 text-ink">{formatGb(est.weightsGb)}</dd>
              </div>
              <div>
                <dt className="flex items-center gap-1.5 text-ink-3">
                  <span className="labo-hachures inline-block h-2 w-2 border border-line-strong" aria-hidden /> KV cache
                </dt>
                <dd className="num mt-0.5 text-ink">{formatGb(est.kvGb)}</dd>
              </div>
              <div>
                <dt className="flex items-center gap-1.5 text-ink-3">
                  <HardDrives size={12} aria-hidden /> Disque
                </dt>
                <dd className="num mt-0.5 text-ink">≈ {formatGb(est.diskGb)}</dd>
              </div>
              <div>
                <dt className="flex items-center gap-1.5 text-ink-3">
                  <Lightning size={12} aria-hidden /> Lu par token
                </dt>
                <dd className="num mt-0.5 text-ink">{formatGb(est.readPerTokenGb)}</dd>
              </div>
            </dl>
            <p className="mt-4 border-t border-line pt-3 font-mono text-[11.5px] text-ink-2">
              {formatParams(totalB)} × {est.bits} bits ÷ 8 × 1,1 = {formatGb(est.weightsGb)} · + KV {ctxLabel(ctx)} = {formatGb(est.totalGb)}
            </p>
          </div>
          <MachineTable verdicts={verdicts} />
        </div>
      </div>

      <Notice tone="warn" title="Estimations">
        Règles de la leçon L042 : mémoire utilisable ≈ 90 % de la VRAM d&apos;un GPU, ≈ 75 % de la mémoire unifiée d&apos;un Mac ; vitesse ≈ bande passante ÷ Go lus par token, × un rendement calibré sur les mesures citées. Le KV cache est interpolé à partir des mesures Llama 3 (131 Mo / 1 000 tokens à 8B, 328 Mo à 70B). Vérifiez sur votre machine avec <code className="font-mono">ollama ps</code> ou <code className="font-mono">llama-bench</code>.
      </Notice>

      <Challenge
        prompt="Votre collègue a un MacBook Air M4 16 Go. Quel est le plus gros modèle dense qu'il peut faire tourner confortablement en Q4, avec 8K de contexte ?"
        options={["Un 8B", "Un 14B", "Un 27B", "Un 70B"]}
        answer={0}
        onAnswer={markUsed}
        explanation={
          <p>
            8 × 4 ÷ 8 × 1,1 = 4,4 Go, + ~1 Go de KV cache : il tient dans les ~12 Go utilisables, à environ 24 tok/s. Un 14B passe, mais à moins de {COMFORT_TPS} tok/s et avec un contexte court.
          </p>
        }
      />
    </div>
  );
}

function MachineTable({ verdicts }: { verdicts: MachineVerdict[] }) {
  const reduce = useReducedMotion();
  return (
    <div className="border border-line bg-bg-elev">
      <div className="flex items-baseline justify-between gap-3 border-b border-line px-5 py-3">
        <h2 className="text-[13px] text-ink">Verdict par machine</h2>
        <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">tok/s estimés</span>
      </div>
      <ul className="divide-y divide-line">
        {verdicts.map((v) => {
          const pct = Math.min(100, v.load * 100);
          return (
            <li key={v.machine.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-4 gap-y-1.5 px-5 py-2.5 sm:grid-cols-[minmax(0,11rem)_minmax(0,1fr)_5.5rem_7.5rem]">
              <div className="min-w-0">
                <p className="truncate text-[13.5px] text-ink">{v.machine.label}</p>
                <p className="truncate text-[11.5px] text-ink-3">{v.machine.detail}</p>
              </div>
              <div className="order-3 col-span-2 sm:order-none sm:col-span-1" aria-hidden>
                <div className="relative h-1.5 w-full bg-bg-muted">
                  <motion.div
                    className={cn("absolute inset-y-0 left-0", v.fits ? (v.load > 0.9 ? "bg-warn" : "bg-ink") : "bg-danger")}
                    initial={false}
                    animate={{ width: `${pct}%` }}
                    transition={reduce ? { duration: 0 } : { duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                  />
                </div>
                <p className="num mt-1 text-[10.5px] text-ink-3">{v.fits ? `${Math.round(v.load * 100)} % de ${formatGb(v.usableGb)} utilisables` : `${formatGb(v.usableGb)} utilisables : déborde`}</p>
              </div>
              <p className="num hidden text-right text-[15px] text-ink sm:block">{v.tokensPerSecond !== null ? fmtTps(v.tokensPerSecond) : "—"}</p>
              <div className="flex items-center justify-end gap-2">
                <span className="num text-[13px] text-ink sm:hidden">{v.tokensPerSecond !== null ? `${fmtTps(v.tokensPerSecond)} tok/s` : ""}</span>
                <Badge tone={VERDICT[v.verdict].tone}>{VERDICT[v.verdict].label}</Badge>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
