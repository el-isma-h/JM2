"use client";

/**
 * Quiz éclair d'une leçon (bloc ```quiz) : une question, vérification côté serveur, explication, +5 XP une seule fois.
 * Le client ne reçoit ni la bonne réponse ni l'explication avant d'avoir répondu.
 */
import * as React from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ArrowCounterClockwise, Check, Lightning, X } from "@phosphor-icons/react";
import type { PublicFlashQuiz } from "@/lib/lesson-blocks";
import { answerFlashQuizAction } from "@/server/actions/enrichments";
import { announceRewards, toast } from "@/components/feedback/toaster";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ChoiceList } from "./choice-list";

type Feedback = { correct: boolean; answer: number; chosen: number; explanation: string; xp: number };

export function FlashQuizCard({ lessonId, index, quiz, done, xp }: { lessonId: string; index: number; quiz: PublicFlashQuiz; done: boolean; xp: number }) {
  const reduce = useReducedMotion();
  const id = React.useId();
  const [value, setValue] = React.useState<number | null>(null);
  const [fb, setFb] = React.useState<Feedback | null>(null);
  const [won, setWon] = React.useState(done);
  const [pending, start] = React.useTransition();
  const feedbackRef = React.useRef<HTMLDivElement>(null);

  const check = () => {
    if (value === null) return;
    const chosen = value;
    start(async () => {
      const r = await answerFlashQuizAction(lessonId, index, chosen);
      if (!r.ok) {
        toast({ kind: "error", title: r.error });
        return;
      }
      setFb({ correct: r.correct, answer: r.answer, chosen, explanation: r.explanation, xp: r.rewards.xp });
      if (r.correct) setWon(true);
      if (r.rewards.xp > 0 || r.rewards.badges.length) announceRewards(r.rewards);
      requestAnimationFrame(() => feedbackRef.current?.focus());
    });
  };

  const retry = () => {
    setFb(null);
    setValue(null);
  };

  return (
    <section className="nf-block border border-line-strong bg-bg-elev" aria-labelledby={`${id}-q`}>
      <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-2.5 sm:px-5">
        <span className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-accent">
          <Lightning size={13} weight="fill" aria-hidden />
          Quiz éclair
        </span>
        {won ? (
          <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-ok-ink">
            <Check size={12} weight="bold" aria-hidden /> Réussi
          </span>
        ) : (
          <span className="num font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">+{xp} XP</span>
        )}
      </header>

      <div className="px-4 pb-5 pt-4 sm:px-5">
        <p id={`${id}-q`} className="max-w-[60ch] text-[15.5px] font-medium leading-snug text-ink">
          {quiz.q}
        </p>
        <div className="mt-4">
          <ChoiceList name={`${id}-choice`} labelledBy={`${id}-q`} options={quiz.options} value={value} onChange={setValue} verdict={fb ? { answer: fb.answer, chosen: fb.chosen } : null} disabled={pending} />
        </div>

        <AnimatePresence mode="wait" initial={false}>
          {fb ? (
            <motion.div
              key="fb"
              ref={feedbackRef}
              tabIndex={-1}
              role="status"
              initial={reduce ? { opacity: 0 } : { opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className={cn("mt-4 border-l-2 bg-bg px-4 py-3 outline-none", fb.correct ? "border-ok" : "border-danger")}
            >
              <p className={cn("inline-flex items-center gap-2 font-display text-[14px] font-light uppercase tracking-[0.08em]", fb.correct ? "text-ok-ink" : "text-danger-ink")}>
                {fb.correct ? <Check size={14} weight="bold" aria-hidden /> : <X size={14} weight="bold" aria-hidden />}
                {fb.correct ? "Exact" : "Pas tout à fait"}
                {fb.xp > 0 ? (
                  <span className="num ml-1 inline-flex items-center gap-1 font-mono text-[11px] normal-case tracking-normal text-accent">
                    <Lightning size={11} weight="fill" aria-hidden />+{fb.xp} XP
                  </span>
                ) : null}
              </p>
              {fb.explanation ? <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-2">{fb.explanation}</p> : null}
              {!fb.correct ? <p className="mt-1.5 text-[12px] text-ink-3">Cette question reviendra dans vos révisions.</p> : null}
            </motion.div>
          ) : null}
        </AnimatePresence>

        <div className="mt-4 flex flex-wrap items-center justify-end gap-2">
          {fb && !fb.correct ? (
            <Button variant="secondary" size="sm" onClick={retry}>
              <ArrowCounterClockwise size={13} aria-hidden /> Réessayer
            </Button>
          ) : null}
          {!fb ? (
            <Button size="sm" onClick={check} disabled={value === null} loading={pending}>
              Vérifier
            </Button>
          ) : null}
        </div>
      </div>
    </section>
  );
}
