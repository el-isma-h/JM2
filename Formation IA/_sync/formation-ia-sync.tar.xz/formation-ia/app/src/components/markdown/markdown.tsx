/**
 * Rendu Markdown des leçons et ressources (SPEC § Rendu des leçons) — composant SERVEUR.
 *
 * Chaîne : remark-gfm + remark-math → rehype-raw (HTML des fichiers, ex. <details>) → rehype-sanitize (liste blanche)
 * → rehype-katex (formules) → rehype-highlight (code) → rehype-slug (ancres identiques à lesson.headings).
 * Les blocs ```mermaid sont rendus côté client (MermaidDiagram). Encadrés 💡 / ⚠️ / 🔗 → blockquote[data-callout].
 * Liens externes : target=_blank rel="noopener noreferrer".
 * v1.2 : les prix en dollars (« 0,10 $ … 10 $ ») sont échappés avant l'analyse pour ne plus être lus comme une formule.
 * v1.1 : encadré « 🧭 En clair » (citation mise en avant) ; blocs ```quiz (quiz éclair) et ```mission (mission
 * documentation) rendus interactifs quand `lesson` est fourni ; JSON invalide → bloc brut affiché tel quel.
 *
 *   <Markdown source={lesson.body} />
 *   <Markdown source={body} lesson={{ id: "L001", doneQuiz: [0], doneMissions: [] }} />
 */
import * as React from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeRaw from "rehype-raw";
import rehypeSanitize, { defaultSchema, type Options as SanitizeSchema } from "rehype-sanitize";
import rehypeKatex from "rehype-katex";
import rehypeHighlight from "rehype-highlight";
import rehypeSlug from "rehype-slug";
import { Compass } from "@phosphor-icons/react/ssr";
import { cn } from "@/lib/utils";
import { FLASH_QUIZ_XP, parseMissionBlock, parseQuizBlock, remarkLessonBlocks, toPublicFlashQuiz } from "@/lib/lesson-blocks";
import { escapeCurrencyDollars } from "@/lib/lesson-text";
import { MermaidDiagram } from "./mermaid";
import { FlashQuizCard } from "./flash-quiz";
import { MissionCard } from "./mission-card";

/** Contexte d'une leçon : active les blocs interactifs (quiz éclair, missions) et l'état déjà acquis. */
export type LessonBlocksContext = { id: string; doneQuiz: readonly number[]; doneMissions: readonly number[] };

const schema: SanitizeSchema = {
  ...defaultSchema,
  // Pas de préfixe « user-content- » : les ancres sont posées après le nettoyage par rehype-slug.
  clobberPrefix: "",
  tagNames: [...(defaultSchema.tagNames ?? []), "details", "summary", "kbd", "mark", "figure", "figcaption"],
  attributes: {
    ...defaultSchema.attributes,
    details: ["open"],
    code: [...(defaultSchema.attributes?.code ?? []), ["className", /^language-./, "math-inline", "math-display"], "dataBlock", "dataBlockIndex"],
    span: [...(defaultSchema.attributes?.span ?? []), ["className", "math-inline", "math-display"]],
    div: [...(defaultSchema.attributes?.div ?? []), ["className", "math-display"]],
  },
};

function textOf(node: React.ReactNode): string {
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(textOf).join("");
  if (React.isValidElement<{ children?: React.ReactNode }>(node)) return textOf(node.props.children);
  return "";
}

function calloutKind(children: React.ReactNode): string | undefined {
  const t = textOf(children).trimStart();
  if (t.startsWith("💡")) return "tip";
  if (t.startsWith("⚠️") || t.startsWith("⚠")) return "warn";
  if (t.startsWith("🔗")) return "link";
  if (t.startsWith("⏱")) return "meta";
  if (t.startsWith("🧭")) return "plain";
  return undefined;
}

/**
 * « > 🧭 **En clair** — texte » : retire l'émoji, le libellé en gras et le tiret du premier paragraphe
 * (le libellé est affiché par l'en-tête de l'encadré). Le reste du contenu est intact.
 */
function stripPlainLabel(children: React.ReactNode): React.ReactNode {
  let done = false;
  return React.Children.map(children, (child) => {
    if (done || !React.isValidElement<{ children?: React.ReactNode }>(child) || child.type !== "p") return child;
    done = true;
    const parts = React.Children.toArray(child.props.children);
    let i = 0;
    if (typeof parts[i] === "string" && /^\s*🧭\s*$/u.test(parts[i] as string)) i++;
    else if (typeof parts[i] === "string") parts[i] = (parts[i] as string).replace(/^\s*🧭\s*/u, "");
    const label = parts[i];
    if (React.isValidElement<{ children?: React.ReactNode }>(label) && /^en clair\s*:?$/i.test(textOf(label.props.children).trim())) i++;
    const rest = parts.slice(i);
    if (typeof rest[0] === "string") rest[0] = (rest[0] as string).replace(/^\s*[—–:-]\s*/, "");
    return React.cloneElement(child, {}, ...rest);
  });
}

function codeBlock(children: React.ReactNode): { lang: string; text: string; block?: string; index?: number } | null {
  const child = React.Children.toArray(children)[0];
  if (!React.isValidElement<{ className?: string; children?: React.ReactNode; "data-block"?: string; "data-block-index"?: string }>(child)) return null;
  const lang = /\blanguage-([\w-]+)/.exec(child.props.className ?? "")?.[1] ?? "";
  const idx = child.props["data-block-index"];
  return { lang, text: textOf(child.props.children), block: child.props["data-block"], index: idx !== undefined ? Number(idx) : undefined };
}

function makeComponents(lesson: LessonBlocksContext | undefined): Components {
  return {
    a: ({ href, children, ...props }) => {
      const external = typeof href === "string" && /^https?:\/\//.test(href);
      return (
        <a href={href} {...props} {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}>
          {children}
        </a>
      );
    },
    blockquote: ({ children, ...props }) => {
      const kind = calloutKind(children);
      if (kind === "plain") {
        return (
          <blockquote data-callout="plain" {...props}>
            <p className="en-clair-label" aria-hidden>
              <Compass size={14} weight="regular" /> En clair
            </p>
            <span className="sr-only">En clair : </span>
            {stripPlainLabel(children)}
          </blockquote>
        );
      }
      return (
        <blockquote data-callout={kind} {...props}>
          {children}
        </blockquote>
      );
    },
    pre: ({ children, ...props }) => {
      const code = codeBlock(children);
      if (code?.lang === "mermaid") return <MermaidDiagram code={code.text} />;
      if (lesson && code?.block && code.index !== undefined && Number.isInteger(code.index)) {
        if (code.block === "quiz") {
          const quiz = parseQuizBlock(code.text);
          if (quiz) return <FlashQuizCard lessonId={lesson.id} index={code.index} quiz={toPublicFlashQuiz(quiz)} done={lesson.doneQuiz.includes(code.index)} xp={FLASH_QUIZ_XP} />;
        } else if (code.block === "mission") {
          const mission = parseMissionBlock(code.text);
          if (mission) return <MissionCard lessonId={lesson.id} index={code.index} mission={mission} done={lesson.doneMissions.includes(code.index)} />;
        }
      }
      return <pre {...props}>{children}</pre>;
    },
    table: ({ children, ...props }) => <table {...props}>{children}</table>,
  };
}

const staticComponents = makeComponents(undefined);

export function Markdown({ source, className, lesson }: { source: string; className?: string; lesson?: LessonBlocksContext }) {
  return (
    <div className={cn("prose-nf", className)}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath, remarkLessonBlocks]}
        rehypePlugins={[rehypeRaw, [rehypeSanitize, schema], rehypeKatex, [rehypeHighlight, { detect: false, plainText: ["mermaid", "text", "txt", "quiz", "mission"] }], rehypeSlug]}
        components={lesson ? makeComponents(lesson) : staticComponents}
      >
        {escapeCurrencyDollars(source)}
      </ReactMarkdown>
    </div>
  );
}
