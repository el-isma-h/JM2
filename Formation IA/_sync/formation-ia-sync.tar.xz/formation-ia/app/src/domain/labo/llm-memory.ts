/**
 * Labo — calculateur « LLM local » (leçon L042, module M10).
 *
 * Règles reprises EXACTEMENT de la leçon L042 :
 *   Mémoire des poids (Go) ≈ Paramètres (milliards) × bits ÷ 8 × 1,1
 *   Mémoire totale ≈ poids + KV cache(contexte)
 *   Mémoire utilisable ≈ 90 % de la VRAM d'un GPU, ~75 % de la mémoire unifiée d'un Mac
 *   Vitesse (tok/s) ≈ bande passante (Go/s) ÷ Go lus par token × rendement (0,6 dans l'exercice de L042 ;
 *   ≈ 36 % mesuré sur RTX 5090, « les très grosses bandes passantes sont moins bien exploitées »)
 *
 * KV cache : ordres de grandeur mesurés sur Llama 3 en FP16 cités par la leçon (8B ≈ 131 Mo / 1 000 tokens,
 * 70B ≈ 328 Mo / 1 000 tokens). Entre ces deux points : interpolation linéaire ; en dessous de 8B : proportionnel
 * (borné à 30 Mo) ; au-delà de 70B : même pente, plafonnée à 500 Mo / 1 000 tokens (les gros MoE récents compressent
 * leur KV cache). Ce sont des ESTIMATIONS pédagogiques, pas des mesures.
 */

export type Precision = "FP16" | "Q8" | "Q6" | "Q5" | "Q4" | "Q3";

/** Bits par paramètre (valeurs nominales utilisées par la formule de L042). */
export const PRECISION_BITS: Record<Precision, number> = { FP16: 16, Q8: 8, Q6: 6, Q5: 5, Q4: 4, Q3: 3 };

export const PRECISIONS: { id: Precision; label: string; quality: string }[] = [
  { id: "FP16", label: "FP16 / BF16", quality: "Aucune perte (référence)" },
  { id: "Q8", label: "Q8_0 / FP8", quality: "Perte négligeable" },
  { id: "Q6", label: "Q6_K", quality: "Perte très faible" },
  { id: "Q5", label: "Q5_K_M", quality: "Perte faible" },
  { id: "Q4", label: "Q4_K_M / MXFP4", quality: "Faible, le standard du local en 2026" },
  { id: "Q3", label: "Q3 / IQ3", quality: "Perte sensible" },
];

/** Paliers du curseur « paramètres » (milliards), de 1B à 1T. */
export const PARAM_STEPS = [1, 3, 4, 8, 12, 14, 20, 27, 32, 70, 120, 235, 405, 671, 1000] as const;

export const CONTEXT_STEPS = [2_048, 4_096, 8_192, 16_384, 32_768, 65_536, 131_072] as const;

export const OVERHEAD = 1.1;
export const GPU_USABLE = 0.9;
export const UNIFIED_USABLE = 0.75;
export const DEFAULT_EFFICIENCY = 0.6;
export const MOE_READ_FACTOR = 1.25;

/** Go des poids : B × bits ÷ 8 × 1,1. */
export function weightsGb(paramsB: number, bits: number): number {
  return (paramsB * bits * OVERHEAD) / 8;
}

/** Mo de KV cache par tranche de 1 000 tokens (FP16), pour un modèle de `paramsB` milliards de paramètres. */
export function kvMbPer1k(paramsB: number): number {
  const slope = (328 - 131) / (70 - 8);
  if (paramsB <= 8) return Math.max(30, (131 * paramsB) / 8);
  if (paramsB <= 70) return 131 + (paramsB - 8) * slope;
  return Math.min(500, 328 + (paramsB - 70) * slope);
}

/** Go de KV cache pour `contextTokens` tokens de contexte. */
export function kvCacheGb(paramsB: number, contextTokens: number): number {
  return (kvMbPer1k(paramsB) * (contextTokens / 1000)) / 1000;
}

export type MachineKind = "mac" | "gpu" | "spark" | "cpu";

export type Machine = {
  id: string;
  label: string;
  detail: string;
  kind: MachineKind;
  memoryGb: number;
  bandwidthGBs: number;
  /** Part de la mémoire réellement disponible pour le modèle. */
  usable: number;
  /** Rendement observé (part de la vitesse théorique atteinte). */
  efficiency: number;
};

/**
 * Machines du grand tableau de L042 (bandes passantes de la leçon). `efficiency` est calibré sur la vitesse
 * MESURÉE d'un 8B Q4 citée par la leçon (ex. M4 : 24 tok/s ÷ (120 ÷ 4,4) ≈ 0,88 ; RTX 5090 : 145 ÷ (1 792 ÷ 4,4) ≈ 0,36).
 */
export const MACHINES: Machine[] = [
  { id: "mac8", label: "Mac 8 Go", detail: "M1 à M3 base · 68–100 Go/s", kind: "mac", memoryGb: 8, bandwidthGBs: 100, usable: UNIFIED_USABLE, efficiency: 0.7 },
  { id: "mac16", label: "Mac 16 Go", detail: "M4 · 120 Go/s", kind: "mac", memoryGb: 16, bandwidthGBs: 120, usable: UNIFIED_USABLE, efficiency: 0.88 },
  { id: "mac32", label: "Mac 32 Go", detail: "M4 Pro · 273 Go/s", kind: "mac", memoryGb: 32, bandwidthGBs: 273, usable: UNIFIED_USABLE, efficiency: 0.82 },
  { id: "mac64", label: "Mac 64 Go", detail: "M4 Max · 546 Go/s", kind: "mac", memoryGb: 64, bandwidthGBs: 546, usable: UNIFIED_USABLE, efficiency: 0.67 },
  { id: "mac128", label: "Mac 128 Go", detail: "M4 Max · 546 Go/s", kind: "mac", memoryGb: 128, bandwidthGBs: 546, usable: UNIFIED_USABLE, efficiency: 0.67 },
  { id: "rtx3060", label: "RTX 3060 12 Go", detail: "PC NVIDIA · 360 Go/s", kind: "gpu", memoryGb: 12, bandwidthGBs: 360, usable: GPU_USABLE, efficiency: 0.51 },
  { id: "rtx4070", label: "RTX 4070 12 Go", detail: "PC NVIDIA · 504 Go/s", kind: "gpu", memoryGb: 12, bandwidthGBs: 504, usable: GPU_USABLE, efficiency: 0.5 },
  { id: "rtx4090", label: "RTX 4090 24 Go", detail: "PC NVIDIA · 1 008 Go/s", kind: "gpu", memoryGb: 24, bandwidthGBs: 1008, usable: GPU_USABLE, efficiency: 0.45 },
  { id: "rtx5090", label: "RTX 5090 32 Go", detail: "PC NVIDIA · 1 792 Go/s", kind: "gpu", memoryGb: 32, bandwidthGBs: 1792, usable: GPU_USABLE, efficiency: 0.36 },
  { id: "spark", label: "DGX Spark 128 Go", detail: "NVIDIA GB10 · 273 Go/s", kind: "spark", memoryGb: 128, bandwidthGBs: 273, usable: GPU_USABLE, efficiency: 0.61 },
  { id: "cpu", label: "CPU seul 32 Go", detail: "DDR5 double canal · ~90 Go/s", kind: "cpu", memoryGb: 32, bandwidthGBs: 90, usable: UNIFIED_USABLE, efficiency: 0.5 },
];

export type LlmInput = {
  /** Paramètres totaux (milliards) : ce qu'il faut stocker. */
  totalB: number;
  /** Paramètres actifs par token (MoE) ; = totalB pour un modèle dense. */
  activeB?: number;
  precision: Precision;
  contextTokens: number;
};

export type LlmEstimate = {
  bits: number;
  weightsGb: number;
  kvGb: number;
  totalGb: number;
  /** Fichier à télécharger (≈ poids). */
  diskGb: number;
  /** Go relus à chaque token généré (paramètres actifs). */
  readPerTokenGb: number;
};

export function estimateLlm(input: LlmInput): LlmEstimate {
  const bits = PRECISION_BITS[input.precision];
  const total = Math.max(0, input.totalB);
  const active = Math.min(total, Math.max(0, input.activeB ?? total));
  const w = weightsGb(total, bits);
  const kv = kvCacheGb(total, Math.max(0, input.contextTokens));
  // MoE : attention, routeur et experts partagés s'ajoutent aux experts actifs (L042 compte ≈ 3,5 Go lus par token
  // pour les 5,1B actifs de gpt-oss-120b, soit ≈ 1,25 × les poids actifs).
  const read = active < total ? weightsGb(active, bits) * MOE_READ_FACTOR : w;
  return { bits, weightsGb: w, kvGb: kv, totalGb: w + kv, diskGb: w, readPerTokenGb: read };
}

export type Verdict = "confort" | "serre" | "lent" | "impossible";

export type MachineVerdict = {
  machine: Machine;
  usableGb: number;
  fits: boolean;
  /** Occupation de la mémoire utilisable (0-1+). */
  load: number;
  /** Vitesse estimée (tok/s), null si le modèle ne tient pas. */
  tokensPerSecond: number | null;
  verdict: Verdict;
};

/** Seuil de confort interactif cité par L042 : ≥ 20 tok/s (plus vite que vous ne lisez). */
export const COMFORT_TPS = 20;

export function speedTps(bandwidthGBs: number, readPerTokenGb: number, efficiency = DEFAULT_EFFICIENCY): number {
  if (readPerTokenGb <= 0) return 0;
  return (bandwidthGBs / readPerTokenGb) * efficiency;
}

export function machineVerdict(machine: Machine, est: LlmEstimate): MachineVerdict {
  const usableGb = machine.memoryGb * machine.usable;
  const load = usableGb > 0 ? est.totalGb / usableGb : Infinity;
  const fits = est.totalGb <= usableGb;
  const tps = fits ? speedTps(machine.bandwidthGBs, est.readPerTokenGb, machine.efficiency) : null;
  let verdict: Verdict = "impossible";
  if (fits && tps !== null) verdict = tps < COMFORT_TPS ? "lent" : load > 0.9 ? "serre" : "confort";
  return { machine, usableGb, fits, load, tokensPerSecond: tps, verdict };
}

export function allVerdicts(est: LlmEstimate, machines: readonly Machine[] = MACHINES): MachineVerdict[] {
  return machines.map((m) => machineVerdict(m, est));
}

/** Préréglages tirés des exemples de L042. */
export const LLM_PRESETS: { id: string; label: string; totalB: number; activeB: number; precision: Precision }[] = [
  { id: "8b", label: "Llama / Qwen 8B", totalB: 8, activeB: 8, precision: "Q4" },
  { id: "27b", label: "Qwen3.8-27B", totalB: 27, activeB: 27, precision: "Q4" },
  { id: "70b", label: "Llama 3.3 70B", totalB: 70, activeB: 70, precision: "Q4" },
  { id: "gptoss20", label: "gpt-oss-20b (MoE)", totalB: 21, activeB: 3.6, precision: "Q4" },
  { id: "gptoss120", label: "gpt-oss-120b (MoE)", totalB: 116.8, activeB: 5.1, precision: "Q4" },
];

/** Format « 4,4 Go » / « 1,4 To ». */
export function formatGb(gb: number): string {
  if (gb >= 1000) return `${(gb / 1000).toLocaleString("fr-FR", { maximumFractionDigits: 2 })} To`;
  return `${gb.toLocaleString("fr-FR", { maximumFractionDigits: gb < 10 ? 1 : 0 })} Go`;
}

export function formatParams(b: number): string {
  if (b >= 1000) return `${(b / 1000).toLocaleString("fr-FR", { maximumFractionDigits: 1 })}T`;
  return `${b.toLocaleString("fr-FR", { maximumFractionDigits: 1 })}B`;
}
