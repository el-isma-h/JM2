# Bibliothèque de liens — Formation IA Next Formation (NF-IA-150)

Consolidation de toutes les URL **vérifiées** des cinq dossiers de recherche (`_recherche/01` à `05`), dédoublonnées et classées par fournisseur / thème. État au **1er novembre 2026**.

**Règles de constitution**
- Sont incluses les URL marquées ✅ (page ouverte et lue), 🔗 / « URL citée » (adresse extraite telle quelle de la navigation ou du corps d'une page officielle ouverte) et **[vérifiée]** (dossier 04) dans les dossiers de recherche.
- Les URL marquées ⚠️, 🔎 (résultat de recherche non ouvert) ou **[non re-vérifiée]** sont regroupées dans la section finale « À vérifier » et ne doivent pas être utilisées dans un support avant contrôle.
- Format : `- [Titre](url) 🇬🇧/🇫🇷 — description en une ligne (date si pertinente)`.
- Aucune URL n'a été inventée ; les intitulés reprennent les titres officiels ou le contenu lu. Les prix et chiffres sont ceux relevés le 1er novembre 2026.
- Licences de réutilisation : voir la section « Réutilisation de contenus » ; les contenus MIT OCW, Stanford SEE et `anthropics/courses` sont en CC BY-NC (citation uniquement) ; les dépôts Microsoft sont sous licence MIT.

Sommaire : 1 Anthropic & Claude · 2 OpenAI · 3 xAI · 4 Perplexity · 5 Mistral · 6 Google · 7 Hugging Face · 8 n8n / Make / Zapier · 9 LLM locaux · 10 Matériel · 11 Modèles à poids ouverts · 12 Frameworks & agents, MCP, A2A, agents de code · 13 Évaluation & observabilité · 14 Sécurité · 15 Cours universitaires · 16 MOOC, cours ouverts & livres · 17 Réglementation France / UE · 18 Certifications · 19 Marché & politiques publiques · 20 Médias génératifs · 21 À vérifier.

---

## 1. Anthropic & Claude

### 1.1 Claude Academy (cours gratuits, badges)
- [Claude Academy — accueil](https://academy.claude.com/) 🇬🇧 — catalogue gratuit : 27 cours, 124 tutoriels, 157 cas d'usage ; compte Claude gratuit pour la progression (renommage d'Anthropic Academy le 20 août 2026)
- [Catalogue des cours](https://academy.claude.com/courses) 🇬🇧 — 5 sections, 27 cours
- [Anthropic Academy (ancienne URL)](https://anthropic.com/learn) 🇬🇧 — redirige (302) vers academy.claude.com
- [FAQ Claude Academy](https://academy.claude.com/help/faq) 🇬🇧 — badges gratuits délivrés à la réussite du dernier quiz, sans expiration ; distinction avec les certifications payantes
- [Connecteur MCP de Claude Academy](https://academy.claude.com/help/mcp) 🇬🇧 — serveur MCP en lecture seule (`search_academy`, `get_content`, `list_content`), endpoint https://academy.claude.com/mcp
- [Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 — 2,5 h, 13 leçons : projets, artefacts, skills, connecteurs, cas d'usage par rôle
- [Claude Code 101](https://academy.claude.com/courses/claude-code-101) 🇬🇧 — 1,5 h : installation, explore → plan → code → commit, CLAUDE.md, subagents, skills, MCP, hooks
- [Introduction to Claude Cowork](https://academy.claude.com/courses/introduction-to-claude-cowork) 🇬🇧 — 2,5 h : Cowork desktop, instructions globales, skills, plugins, Chrome, Microsoft 365
- [Introduction to Claude Tag](https://academy.claude.com/courses/introduction-to-claude-tag) 🇬🇧 — 2,5 h : Claude dans Slack, mémoire, routines
- [Claude Platform 101](https://academy.claude.com/courses/claude-platform-101) 🇬🇧 — 1,5 h (SDK TypeScript) : premier appel, agent loop, tool use, thinking, MCP, Managed Agents
- [Claude Code in action](https://academy.claude.com/courses/claude-code-in-action) 🇬🇧 — 1 h : permission modes, hooks, routines, headless, GitHub Actions, plugins
- [Introduction to Model Context Protocol](https://academy.claude.com/courses/introduction-to-model-context-protocol) 🇬🇧 — 1 h (Python) : tools, inspector, client, resources, prompts
- [Model Context Protocol: Advanced topics](https://academy.claude.com/courses/model-context-protocol-advanced-topics) 🇬🇧 — 1,5 h : sampling, notifications, roots, STDIO, StreamableHTTP
- [Introduction to subagents](https://academy.claude.com/courses/introduction-to-subagents) 🇬🇧 — 45 min : `/agents`, conception et usage des sous-agents
- [Introduction to agent skills](https://academy.claude.com/courses/introduction-to-agent-skills) 🇬🇧 — 1 h : SKILL.md, skills multi-fichiers, partage, dépannage
- [The AI-native SDLC playbook](https://academy.claude.com/courses/ai-native-sdlc-playbook) 🇬🇧 — 1 h : intent.md, plan mode, évals en CI, hooks comme portes d'approbation
- [Deploying Claude Enterprise with confidence](https://academy.claude.com/courses/deploying-claude-enterprise-with-confidence) 🇬🇧 — 2,5 h : organisation, groupes, connecteurs, spend caps, adoption
- [AI Fluency: Framework and foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations) 🇬🇧 — 4 h : cadre 4D (Délégation, Description, Discernement, Diligence)
- [AI capabilities and limitations](https://academy.claude.com/courses/ai-capabilities-and-limitations) 🇬🇧 — 3,5 h : next token prediction, knowledge, working memory, steerability
- [Building effective human-agent teams (beta)](https://academy.claude.com/courses/building-effective-human-agent-teams) 🇬🇧 — 45 min pour managers
- [AI Fluency for builders](https://academy.claude.com/courses/ai-fluency-for-builders) 🇬🇧 — déclinaison concepteurs produit
- [AI Fluency for creative work](https://academy.claude.com/courses/ai-fluency-for-creative-work) 🇬🇧 — déclinaison créatifs
- [AI Fluency for educators](https://academy.claude.com/courses/ai-fluency-for-educators) 🇬🇧 — enseignement supérieur
- [AI Fluency for pK-12 educators](https://academy.claude.com/courses/ai-fluency-for-k-12-educators) 🇬🇧 — primaire/secondaire
- [AI Fluency for pK-12 Train the Trainer](https://academy.claude.com/courses/ai-fluency-for-pk-12-train-the-trainer) 🇬🇧 — formateurs d'enseignants
- [Teaching AI Fluency (facilitators)](https://academy.claude.com/courses/teaching-ai-fluency) 🇬🇧 — formateurs
- [AI Fluency for nonprofits](https://academy.claude.com/courses/ai-fluency-for-nonprofits) 🇬🇧 — associations
- [AI Fluency for small businesses](https://academy.claude.com/courses/ai-fluency-for-small-businesses) 🇬🇧 — TPE/PME
- [AI Fluency for students](https://academy.claude.com/courses/ai-fluency-for-students) 🇬🇧 — étudiants
- [Building with the Claude API](https://academy.claude.com/courses/building-with-the-claude-api) 🇬🇧 — 9 h, 67 leçons, 8 quiz : cours pivot (API, évals, prompt engineering, tool use, RAG, features, MCP, agents)
- [Building with the Claude API — miroir Coursera](https://www.coursera.org/learn/building-with-the-claude-api) 🇬🇧 — gratuit sans certificat, 7 modules, 78 vidéos
- [Claude with Amazon Bedrock](https://academy.claude.com/courses/claude-with-amazon-bedrock) 🇬🇧 — 8 h, 65 leçons
- [Claude on Google Cloud (Vertex AI)](https://academy.claude.com/courses/claude-with-google-cloud-s-vertex-ai) 🇬🇧 — 8,5 h, 66 leçons
- [Tutoriel « Creating your first skill »](https://academy.claude.com/tutorials/creating-your-first-skill) 🇬🇧 — exemple de tutoriel Academy (cité par la page MCP)
- [Certificat Skilljar « Claude Code 101 » (exemple)](https://anthropic.skilljar.com/c/jmi2mx2dd6xp) 🇬🇧 — format d'un certificat émis par « Anthropic Education »
- [Ancien cours Skilljar « Claude with the Anthropic API »](https://anthropic.skilljar.com/claude-with-the-anthropic-api) 🇬🇧 — instance historique anthropic.skilljar.com

### 1.2 Anthropic Partner Academy (Claude Partner Network — pages lisibles sans compte)
- [Catalogue complet (55 cours)](https://anthropic-partners.skilljar.com/page/all-courses) 🇬🇧 — instance partenaires
- [Learning paths (Associate, Developer, Architect, FDE, Administrator)](https://anthropic-partners.skilljar.com/page/learning-paths) 🇬🇧
- [Parcours Claude Architect (10 cours)](https://anthropic-partners.skilljar.com/path/claude-architect) 🇬🇧
- [Claude Platform 101 (dans le parcours Architect)](https://anthropic-partners.skilljar.com/path/claude-architect/claude-platform-101) 🇬🇧
- [Cours de préparation aux certifications](https://anthropic-partners.skilljar.com/page/claude-certification-exam-prep-courses) 🇬🇧
- [Prep Claude Certified Associate – Foundations (8 cours)](https://anthropic-partners.skilljar.com/path/claude-certified-associate-foundations) 🇬🇧
- [Prep Claude Certified Developer – Foundations (5 cours, ≈ 13 h)](https://anthropic-partners.skilljar.com/path/claude-certified-developer-foundations) 🇬🇧
- [Prep Claude Certified Architect – Foundations (7 cours)](https://anthropic-partners.skilljar.com/page/claude-certified-architect-foundations-prep-courses) 🇬🇧
- [Prep Claude Certified Architect – Professional (5 cours)](https://anthropic-partners.skilljar.com/path/claude-certified-architect-professional) 🇬🇧
- [Claude Platform & Model Foundations](https://anthropic-partners.skilljar.com/claude-platform-model-foundations) 🇬🇧 — 59 min, parcours Associate
- [Workflow Integration & Solution Design](https://anthropic-partners.skilljar.com/workflow-integration-solution-design) 🇬🇧 — 63 min
- [Governance, Risk & Responsible Use](https://anthropic-partners.skilljar.com/governance-risk-responsible-use) 🇬🇧 — 55 min
- [Prompting & Task Execution](https://anthropic-partners.skilljar.com/prompting-task-execution) 🇬🇧 — 53 min
- [Evaluating & Validating Claude's Output](https://anthropic-partners.skilljar.com/evaluating-validating-claudes-output) 🇬🇧 — 74 min
- [Configuration & Knowledge Management](https://anthropic-partners.skilljar.com/configuration-knowledge-management) 🇬🇧 — 47 min
- [Troubleshooting & Optimization](https://anthropic-partners.skilljar.com/troubleshooting-optimization) 🇬🇧 — 30 min
- [MSO Foundations](https://anthropic-partners.skilljar.com/mso-foundations) 🇬🇧 — 57 min, parcours Developer
- [Production-Grade Prompting, Agents & Tool Use](https://anthropic-partners.skilljar.com/production-grade-prompting-agents-tool-use) 🇬🇧 — 209 min
- [Claude Code, MCP & Integration](https://anthropic-partners.skilljar.com/claude-code-mcp-integration) 🇬🇧 — 142 min
- [Production Engineering, Evals & Security](https://anthropic-partners.skilljar.com/production-engineering-evals-security) 🇬🇧 — 211 min
- [Accelerators & IP Contribution](https://anthropic-partners.skilljar.com/accelerators-ip-contribution) 🇬🇧 — 155 min
- [Claude Platform & Solution Design](https://anthropic-partners.skilljar.com/claude-platform-solution-design) 🇬🇧 — 238 min, Architect Pro
- [Enterprise Integration & Production](https://anthropic-partners.skilljar.com/enterprise-integration-production) 🇬🇧 — 158 min
- [Stakeholder Engagement, Lifecycle & GTM](https://anthropic-partners.skilljar.com/stakeholder-engagement-lifecycle-gtm) 🇬🇧 — 178 min
- [Team Enablement & Operational Productivity](https://anthropic-partners.skilljar.com/developer-productivity-enablement) 🇬🇧 — 45 min
- [Responsible AI, Safety & Risk for Architects](https://anthropic-partners.skilljar.com/responsible-ai-safety-risk-for-architects) 🇬🇧 — 114 min
- [Working with Claude Fable 5.1](https://anthropic-partners.skilljar.com/working-with-claude-fable-51) 🇬🇧 — choix de modèle, migration d'un appel, cross-model check
- [Upgrade a client's build to the Claude 5.5 models](https://anthropic-partners.skilljar.com/bring-the-claude-55-models-to-your-clients) 🇬🇧 — cas « Tallyweir », retrait de Sonnet 4.5 le 30 nov. 2026
- [Opus 4.7 and Cyber](https://anthropic-partners.skilljar.com/opus-47-and-cyber) 🇬🇧
- [Claude Security](https://anthropic-partners.skilljar.com/claude-security) 🇬🇧
- [Installation and Environments (Claude Code admin)](https://anthropic-partners.skilljar.com/installation-and-environments) 🇬🇧
- [Configuration and Customization](https://anthropic-partners.skilljar.com/configuration-and-customization) 🇬🇧
- [Extensibility](https://anthropic-partners.skilljar.com/extensibility-course) 🇬🇧
- [Product Foundations (Partner Enablement)](https://anthropic-partners.skilljar.com/product-foundations) 🇬🇧
- [Driving enterprise adoption of Claude](https://anthropic-partners.skilljar.com/driving-enterprise-adoption-of-claude) 🇬🇧
- [Claude Partner Network Connect — épisode 01](https://anthropic-partners.skilljar.com/claude-partner-network-connect-episode-01) 🇬🇧 — webinaires partenaires
- [Claude Code partner badge](https://anthropic-partners.skilljar.com/path/partner-badge-claude-code) 🇬🇧
- [Claude 101 (instance partenaires)](https://anthropic-partners.skilljar.com/claude-101) 🇬🇧
- [Introduction to Claude Cowork (instance partenaires)](https://anthropic-partners.skilljar.com/introduction-to-claude-cowork) 🇬🇧
- [Introduction to MCP (instance partenaires)](https://anthropic-partners.skilljar.com/introduction-to-model-context-protocol) 🇬🇧
- [MCP: Advanced Topics (instance partenaires)](https://anthropic-partners.skilljar.com/model-context-protocol-advanced-topics) 🇬🇧
- [AI Fluency: Framework & Foundations (instance partenaires)](https://anthropic-partners.skilljar.com/ai-fluency-framework-foundations) 🇬🇧
- [Claude with the Anthropic API (instance partenaires)](https://anthropic-partners.skilljar.com/claude-with-the-anthropic-api) 🇬🇧

### 1.3 Certifications officielles Anthropic (réservées au Claude Partner Network)
- [FAQ Certifications](https://anthropic-partners.skilljar.com/page/faq-certifications) 🇬🇧 — format, 120 min, seuil 720/1000, validité 12 mois, Pearson VUE, Credly, reprises, langues EN/JA
- [Partner certifications](https://anthropic-partners.skilljar.com/page/partner-certifications) 🇬🇧 — présentation des 4 examens
- [Claude Certified Associate – Foundations](https://anthropic-partners.skilljar.com/claude-certified-associate-foundations-certification) 🇬🇧 — 99 $
- [Claude Certified Developer – Foundations](https://anthropic-partners.skilljar.com/claude-certified-developer-foundations-certification) 🇬🇧 — 125 $
- [Claude Certified Architect – Foundations](https://anthropic-partners.skilljar.com/claude-certified-architect-foundations-certification) 🇬🇧 — 125 $ ; évalue Claude Code, Agent SDK, API, MCP
- [Claude Certified Architect – Professional](https://anthropic-partners.skilljar.com/claude-certified-architect-professional-certification) 🇬🇧 — 175 $
- [CloudThat — CCA-F exam guide, skills, format, preparation](https://www.cloudthat.com/resources/blog/claude-certified-architect-foundations-exam-guide-skills-format-and-preparation) 🇬🇧 — source tierce : 60 questions, 5 domaines pondérés (13 août 2026)
- [What each Claude certification actually tests, domain by domain](https://claudearchitectcertification.com/blog/what-each-claude-certification-actually-tests-domain-by-domain) 🇬🇧 — source tierce : pondérations des 4 examens
- [Claude Certified Architect guide 2026](https://pasqualepillitteri.it/en/news/3297/claude-certified-architect-guide-2026-en) 🇬🇧 — source tierce (mars 2026 ; données périmées sur validité/prix)
- [Claude Academy live: free courses](https://pasqualepillitteri.it/en/news/12081/claude-academy-live-free-courses-learn-claude) 🇬🇧 — lancement d'Anthropic Academy (2 mars 2026)
- [ClaudeLog — What are Claude certifications?](https://claudelog.com/faqs/what-are-claude-certifications/) 🇬🇧 — extension à 4 examens (juillet 2026)
- [vanja.io — Claude Academy](https://vanja.io/claude-academy/) 🇬🇧 — lancement de Claude Academy, 22 cours (20 août 2026)
- [Analytics Vidhya — Free Anthropic AI courses with certificates](https://www.analyticsvidhya.com/blog/2026/03/free-anthropic-ai-courses-with-certificates/) 🇬🇧 — fiche des 7 cours gratuits (mars 2026)

### 1.4 Claude Platform — documentation développeur (platform.claude.com)
- [Console Claude Platform](https://platform.claude.com/) 🇬🇧 — clés, playground, usage
- [Clés API](https://platform.claude.com/settings/keys) 🇬🇧
- [Playground (ex-Workbench)](https://platform.claude.com/playground) 🇬🇧
- [Docs — accueil](https://platform.claude.com/docs/en/home) 🇬🇧 — hub Messages vs Managed Agents ; exemples Python, TS, Go, Java, Ruby, PHP, C#, cURL, CLI `ant`
- [Docs — accueil (version brute .md)](https://platform.claude.com/docs/en/home.md) 🇬🇧 — chaque page existe en `.md`
- [Intro to Claude](https://platform.claude.com/docs/en/intro) 🇬🇧
- [Quickstart](https://platform.claude.com/docs/en/get-started) 🇬🇧 — `pip install anthropic`, `ANTHROPIC_API_KEY`
- [Obtenir une clé API](https://platform.claude.com/docs/en/get-api-key) 🇬🇧
- [Features overview](https://platform.claude.com/docs/en/build-with-claude/overview) 🇬🇧 — 57 fonctionnalités plateforme, 18 Messages API, 19 Managed Agents
- [Using the Messages API](https://platform.claude.com/docs/en/build-with-claude/working-with-messages) 🇬🇧 — multi-tours, rôle system en cours de conversation ; prefill non supporté ≥ 4.6 ; temperature/top_p/top_k non supportés ≥ 4.7
- [Messages API reference](https://platform.claude.com/docs/en/api/messages/create) 🇬🇧
- [API overview](https://platform.claude.com/docs/en/api/overview) 🇬🇧
- [API versioning](https://platform.claude.com/docs/en/api/versioning) 🇬🇧 — version `2026-10-21`
- [Migration guide 2026-10-21](https://platform.claude.com/docs/en/api/migration-2026-10-21) 🇬🇧 — SDK v2, licence Apache 2.0 (21 oct. 2026)
- [Stop reasons and fallback](https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons) 🇬🇧
- [Streaming](https://platform.claude.com/docs/en/build-with-claude/streaming) 🇬🇧 — événements message_start → content_block_* → message_delta → message_stop
- [System prompts des apps Claude](https://platform.claude.com/docs/en/release-notes/system-prompts/overview) 🇬🇧
- [System prompt Claude Fable 5.1](https://platform.claude.com/docs/en/release-notes/system-prompts/claude-fable-5-1) 🇬🇧
- [Mid-conversation system messages](https://platform.claude.com/docs/en/build-with-claude/mid-conversation-system-messages) 🇬🇧
- [Tool use overview](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview) 🇬🇧 — 27 sous-pages (how-tool-use-works, define-tools, handle-tool-calls, parallel-tool-use, tool-runner, strict-tool-use, memory-tool, bash-tool, text-editor-tool, computer-use-tool, browser-use-tool, server-tools, web-search-tool, web-fetch-tool, code-execution-tool, advisor-tool, tool-search-tool, programmatic-tool-calling, fine-grained-tool-streaming…)
- [Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧 — `output_config.format = json_schema`, `client.messages.parse()`
- [Vision](https://platform.claude.com/docs/en/build-with-claude/vision) 🇬🇧 — JPEG/PNG/GIF/WebP, base64/url/file
- [PDF support](https://platform.claude.com/docs/en/build-with-claude/pdf-support) 🇬🇧 — 128 Mo/requête, 600 pages max
- [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 — min 512 tokens, TTL 5 min / 1 h, écriture 1,25×, lecture 0,1× (0,05× Opus/Sonnet 5.5)
- [Cache diagnostics](https://platform.claude.com/docs/en/build-with-claude/cache-diagnostics) 🇬🇧
- [Batch processing (Message Batches API)](https://platform.claude.com/docs/en/build-with-claude/batch-processing) 🇬🇧 — −50 %, 100 000 requêtes / 256 Mo par lot
- [Files API](https://platform.claude.com/docs/en/build-with-claude/files) 🇬🇧 — GA, 500 Mo/fichier, 1 To/org
- [Thinking (adaptive)](https://platform.claude.com/docs/en/build-with-claude/thinking) 🇬🇧 — thinking adaptatif recommandé
- [Extended thinking](https://platform.claude.com/docs/en/build-with-claude/extended-thinking) 🇬🇧 — refusé (400) sur Claude 5
- [Preserved thinking](https://platform.claude.com/docs/en/build-with-claude/preserved-thinking) 🇬🇧
- [Effort](https://platform.claude.com/docs/en/build-with-claude/effort) 🇬🇧 — effort par message (beta)
- [Fast mode](https://platform.claude.com/docs/en/build-with-claude/fast-mode) 🇬🇧
- [Citations](https://platform.claude.com/docs/en/build-with-claude/citations) 🇬🇧 — `cited_text` non facturé ; incompatible structured outputs
- [Search results](https://platform.claude.com/docs/en/build-with-claude/search-results) 🇬🇧
- [Context windows](https://platform.claude.com/docs/en/build-with-claude/context-windows) 🇬🇧 — 1M tokens, sortie 128K
- [Context editing / compaction](https://platform.claude.com/docs/en/build-with-claude/context-editing) 🇬🇧 — compaction on-demand, background, threshold, keep-recent-turns
- [Task budgets](https://platform.claude.com/docs/en/build-with-claude/task-budgets) 🇬🇧
- [Token counting](https://platform.claude.com/docs/en/build-with-claude/token-counting) 🇬🇧
- [Multilingual support](https://platform.claude.com/docs/en/build-with-claude/multilingual-support) 🇬🇧
- [Refusals and fallback](https://platform.claude.com/docs/en/build-with-claude/refusals-and-fallback) 🇬🇧
- [Fallback credit](https://platform.claude.com/docs/en/build-with-claude/fallback-credit) 🇬🇧
- [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 — SKILL.md, skills pré-construits pptx/xlsx/docx/pdf
- [Skills guide (custom skills)](https://platform.claude.com/docs/en/build-with-claude/skills-guide) 🇬🇧
- [MCP connector](https://platform.claude.com/docs/en/agents-and-tools/mcp-connector) 🇬🇧 — `mcp_servers`, `mcp_toolset`, Streamable HTTP/SSE
- [MCP tunnels](https://platform.claude.com/docs/en/agents-and-tools/mcp-tunnels/overview) 🇬🇧
- [Client SDKs overview](https://platform.claude.com/docs/en/cli-sdks-libraries/overview) 🇬🇧 — Python 2.3.0, TS 1.3.0, Go, Java, PHP, Ruby, C#, CLI `ant`
- [SDK middleware](https://platform.claude.com/docs/en/cli-sdks-libraries/middleware) 🇬🇧
- [OpenAI SDK compatibility](https://platform.claude.com/docs/en/cli-sdks-libraries/libraries/openai-sdk) 🇬🇧
- [Rate limits](https://platform.claude.com/docs/en/api/rate-limits) 🇬🇧 — paliers Evaluation / Start / Build / Scale / Custom ; headers `anthropic-ratelimit-*`
- [Service tiers (Priority Tier)](https://platform.claude.com/docs/en/api/service-tiers) 🇬🇧
- [Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 — Fable 5.1 10/50 $, Opus 5.5 4/20 $, Sonnet 5.5 2/10 $, Haiku 5.5 0,10/0,50 $ par MTok ; Managed Agents 0,08 $/h
- [Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model) 🇬🇧
- [Model IDs & versions](https://platform.claude.com/docs/en/about-claude/models/model-ids-and-versions) 🇬🇧
- [Model deprecations](https://platform.claude.com/docs/en/about-claude/model-deprecations) 🇬🇧
- [Claude Fable 5.1 — overview](https://platform.claude.com/docs/en/models/fable-5-1/overview) 🇬🇧 — `claude-fable-5-1`, 1er sept. 2026
- [Claude Mythos 5.1 — overview](https://platform.claude.com/docs/en/models/mythos-5-1/overview) 🇬🇧 — accès vérifié (Cyber Verification Program)
- [Claude Opus 5.5 — overview](https://platform.claude.com/docs/en/models/opus-5-5/overview) 🇬🇧 — 22 sept. 2026
- [Claude Sonnet 5.5 — overview](https://platform.claude.com/docs/en/models/sonnet-5-5/overview) 🇬🇧 — 28 sept. 2026
- [Claude Haiku 5.5 — overview](https://platform.claude.com/docs/en/models/haiku-5-5/overview) 🇬🇧 — 7 oct. 2026, contexte 1M
- [Claude Sonnet 5](https://platform.claude.com/docs/en/models/sonnet-5/) 🇬🇧 — 30 juin 2026
- [Define success criteria / build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) 🇬🇧 — exact match, cosine, ROUGE-L, LLM-as-judge
- [Increase output consistency](https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/increase-consistency) 🇬🇧
- [Admin API](https://platform.claude.com/docs/en/manage-claude/admin-api) 🇬🇧 — workspaces, usage & cost analytics, compliance, data residency, OpenTelemetry (pages voisines)
- [Claude Tag API (beta, Enterprise)](https://platform.claude.com/docs/en/manage-claude/claude-tag-api) 🇬🇧 — Claude dans Slack (23 oct. 2026)
- [Release notes (What's new)](https://platform.claude.com/docs/en/release-notes/overview) 🇬🇧 — chronologie 2026
- [Claude in Amazon Bedrock](https://platform.claude.com/docs/en/build-with-claude/claude-in-amazon-bedrock) 🇬🇧
- [Claude models on Google Cloud — overview](https://platform.claude.com/docs/en/build-with-claude/claude-models-on-google-cloud/overview) 🇬🇧
- [Claude models on Google Cloud — Anthropic managed](https://platform.claude.com/docs/en/build-with-claude/claude-models-on-google-cloud/anthropic-managed) 🇬🇧 — 22 oct. 2026
- [Claude in Microsoft Foundry](https://platform.claude.com/docs/en/build-with-claude/claude-in-microsoft-foundry) 🇬🇧
- [Claude Platform on AWS](https://platform.claude.com/docs/en/build-with-claude/claude-platform-on-aws) 🇬🇧
- [Support Claude](https://support.claude.com/) 🇬🇧
- [Statut des services](https://status.claude.com/) 🇬🇧
- [Discord Anthropic](https://www.anthropic.com/discord) 🇬🇧
- [Claude Opus 5.5 migration guide](https://platform.claude.com/docs/en/models/opus-5-5/migration-guide) 🇬🇧 — ce qui casse en passant à Opus 5.5 : échantillonnage, prefill, `tool_choice`, tokenizer, cache minimal à 512 tokens (nov. 2026)
- [Claude Sonnet 5.5 migration guide](https://platform.claude.com/docs/en/models/sonnet-5-5/migration-guide) 🇬🇧 — erreurs 400 (sampling, prefill, forçage d'outil), prix du cache (nov. 2026)
- [Claude Haiku 5.5 migration guide](https://platform.claude.com/docs/en/models/haiku-5-5/migration-guide) 🇬🇧 — migration depuis Haiku 4.5 et 3.5 : +30 % de tokens, images plus coûteuses, `tool_choice` forcé sans réflexion (nov. 2026)
- [Nouveautés de Claude Haiku 5.5](https://platform.claude.com/docs/fr/models/haiku-5-5/whats-new-haiku-5-5) 🇫🇷 — capacités : 1M de contexte, 128k en sortie, réflexion adaptative, effort (nov. 2026, vue dans l'index officiel)
- [Nouveautés de Claude Opus 5.5](https://platform.claude.com/docs/fr/models/opus-5-5/whats-new-opus-5-5) 🇫🇷 — nouveautés du modèle phare (nov. 2026, vue dans l'index officiel)
- [Nouveautés de Claude Sonnet 5.5](https://platform.claude.com/docs/fr/models/sonnet-5-5/whats-new-sonnet-5-5) 🇫🇷 — nouveautés du modèle intermédiaire (nov. 2026, vue dans l'index officiel)
- [Nouveautés de Claude Fable 5.1](https://platform.claude.com/docs/fr/models/fable-5-1/whats-new-fable-5-1) 🇫🇷 — positionnement de Fable 5.1 (nov. 2026, vue dans l'index officiel)
- [Modèles : vue d'ensemble / API Models](https://platform.claude.com/docs/fr/models/overview) 🇫🇷 — lire les capacités d'un modèle via `GET /v1/models` (`line`, `capabilities.thinking`, `server_tools`) (nov. 2026, vue dans l'index officiel)
- [Fils de messages](https://platform.claude.com/docs/fr/build-with-claude/message-threads) 🇫🇷 — conversations conservées côté serveur, coût et latence des longues boucles (nov. 2026, vue dans l'index officiel)
- [Compacter une conversation à la demande](https://platform.claude.com/docs/fr/build-with-claude/compaction-on-demand) 🇫🇷 — gérer un contexte long sans le perdre (nov. 2026, vue dans l'index officiel)
- [Filigrane textuel](https://platform.claude.com/docs/fr/build-with-claude/text-watermark) 🇫🇷 — marquage du texte généré (transparence, art. 50 de l'AI Act) (nov. 2026, vue dans l'index officiel)
- [Outil de récupération web (`web_fetch`)](https://platform.claude.com/docs/fr/agents-and-tools/tool-use/web-fetch-tool) 🇫🇷 — lire une page web depuis Claude, limites, exfiltration (nov. 2026, vue dans l'index officiel)
- [Appel d'outils programmatique](https://platform.claude.com/docs/fr/agents-and-tools/tool-use/programmatic-tool-calling) 🇫🇷 — laisser le code appeler les outils pour économiser des allers-retours (nov. 2026, vue dans l'index officiel)
- [Outil advisor](https://platform.claude.com/docs/fr/agents-and-tools/tool-use/advisor-tool) 🇫🇷 — faire relire un modèle par un modèle plus fort (nov. 2026, vue dans l'index officiel)
- [Navigateur et ordinateur avec les ensembles d'outils du SDK](https://platform.claude.com/docs/fr/agents-and-tools/tool-use/browser-use-sdk) 🇫🇷 — boucle d'outils navigateur et bureau, politiques d'URL, callback d'approbation (nov. 2026, vue dans l'index officiel)
- [Refus en streaming](https://platform.claude.com/docs/fr/test-and-evaluate/strengthen-guardrails/handle-streaming-refusals) 🇫🇷 — gérer un refus en cours de flux (nov. 2026, vue dans l'index officiel)
- [SDK Python](https://platform.claude.com/docs/fr/cli-sdks-libraries/sdks/python) 🇫🇷 — installation et usage du SDK v2 (nov. 2026, vue dans l'index officiel)
- [CLI `ant` — quickstart](https://platform.claude.com/docs/fr/cli-sdks-libraries/cli/quickstart) 🇫🇷 — appeler l'API depuis le terminal (nov. 2026, vue dans l'index officiel)
- [Gérer les ressources en tant que code avec `ant apply`](https://platform.claude.com/docs/fr/cli-sdks-libraries/cli/apply) 🇫🇷 — infrastructure-as-code pour agents et environnements (nov. 2026, vue dans l'index officiel)

### 1.5 Prompt engineering (guide officiel)
- [Prompt engineering — overview](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview) 🇬🇧 — quand faire du prompt engineering, prérequis (critères de succès, tests)
- [Prompting best practices (référence principale)](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 — principes généraux, format, tool use, thinking, systèmes agentiques, migration
- [Prompting Claude Fable 5.1](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-fable-5-1) 🇬🇧
- [Prompting Claude Fable 5](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-fable-5) 🇬🇧
- [Prompting Claude Opus 5.5](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-opus-5-5) 🇬🇧
- [Prompting Claude Opus 5](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-opus-5) 🇬🇧
- [Prompting Claude Opus 4.8](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-opus-4-8) 🇬🇧
- [Prompting Claude Sonnet 5.5](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-sonnet-5-5) 🇬🇧
- [Prompting Claude Sonnet 5](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-sonnet-5) 🇬🇧
- [Prompting Claude Haiku 5.5](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-haiku-5-5) 🇬🇧

### 1.6 Managed Agents (2026)
- [Managed Agents — overview](https://platform.claude.com/docs/en/managed-agents/overview) 🇬🇧 — Agent → Environment → Session → Events ; header beta `managed-agents-2026-04-01` ; 0,08 $/h
- [Managed Agents — overview (version pt-BR lue)](https://platform.claude.com/docs/pt/managed-agents/overview) 🇵🇹
- [Managed Agents — quickstart](https://platform.claude.com/docs/en/managed-agents/quickstart) 🇬🇧
- [Console agent builder (onboarding)](https://platform.claude.com/docs/en/managed-agents/onboarding) 🇬🇧
- [Agent setup](https://platform.claude.com/docs/en/managed-agents/agent-setup) 🇬🇧 — pages voisines : tools, permission-policies, environments, sessions, events-and-streaming, budgets, memory, define-outcomes, multiagent-orchestration, workflow-runs, session-threads, scheduled-deployments, self-hosted-sandboxes, vaults, webhooks, github, dreams, session-observability
- [API reference Sessions (beta)](https://platform.claude.com/docs/en/api/beta/sessions) 🇬🇧
- [Managed Agents — Budgets de session](https://platform.claude.com/docs/fr/managed-agents/budgets) 🇫🇷 — plafonner le coût d'un agent (lien avec LLM06 Unbounded Consumption) (nov. 2026, vue dans l'index officiel)
- [Managed Agents — Magasins de mémoire](https://platform.claude.com/docs/fr/managed-agents/memory) 🇫🇷 — mémoire persistante d'un agent (nov. 2026, vue dans l'index officiel)
- [Managed Agents — Politiques de permission](https://platform.claude.com/docs/fr/managed-agents/permission-policies) 🇫🇷 — faire évaluer chaque appel d'outil par le serveur (`auto`) (nov. 2026, vue dans l'index officiel)
- [Managed Agents — Restreindre les domaines web](https://platform.claude.com/docs/fr/managed-agents/tools-web-restrictions) 🇫🇷 — `allowed_hosts` / `allowed_domains` : défense contre l'exfiltration (nov. 2026, vue dans l'index officiel)
- [Managed Agents — Exécutions de workflow](https://platform.claude.com/docs/fr/managed-agents/workflow-runs) 🇫🇷 — orchestration multi-agents par phases (nov. 2026, vue dans l'index officiel)

### 1.7 Claude Code et Claude Agent SDK (code.claude.com)
- [Claude Code — overview + installation](https://code.claude.com/docs) 🇬🇧 — `curl -fsSL https://claude.ai/install.sh | bash`, `brew install --cask claude-code`, `winget install Anthropic.ClaudeCode` ; Terminal, VS Code, JetBrains, Desktop, Web, mobile
- [Overview (version .md)](https://code.claude.com/docs/en/overview.md) 🇬🇧
- [Index complet llms.txt](https://code.claude.com/docs/llms.txt) 🇬🇧
- [Quickstart](https://code.claude.com/docs/en/quickstart.md) 🇬🇧
- [Advanced setup](https://code.claude.com/docs/en/setup.md) 🇬🇧
- [Memory (CLAUDE.md, AGENTS.md, auto memory)](https://code.claude.com/docs/en/memory.md) 🇬🇧
- [Hooks reference](https://code.claude.com/docs/en/hooks.md) 🇬🇧 — 32 événements (SessionStart, PreToolUse, PostToolUse, Stop, PreCompact…)
- [Hooks guide](https://code.claude.com/docs/en/hooks-guide.md) 🇬🇧
- [MCP dans Claude Code](https://code.claude.com/docs/en/mcp.md) 🇬🇧 — `claude mcp add --transport http|sse|stdio` ; scopes local/project/user
- [MCP quickstart](https://code.claude.com/docs/en/mcp-quickstart.md) 🇬🇧
- [Skills](https://code.claude.com/docs/en/skills.md) 🇬🇧 — `~/.claude/skills/`, `.claude/skills/`, frontmatter, `/nom-du-skill`
- [Subagents](https://code.claude.com/docs/en/sub-agents.md) 🇬🇧
- [Plugins](https://code.claude.com/docs/en/plugins/overview.md) 🇬🇧
- [Settings](https://code.claude.com/docs/en/settings.md) 🇬🇧 — pages voisines settings-reference, settings-example
- [Permissions](https://code.claude.com/docs/en/permissions.md) 🇬🇧 — pages voisines authentication, security, sandboxing
- [GitHub Actions](https://code.claude.com/docs/en/github-actions.md) 🇬🇧 — pages voisines gitlab-ci-cd, code-review, slack, chrome, channels
- [Headless (`claude -p`)](https://code.claude.com/docs/en/headless.md) 🇬🇧 — pages voisines cli-reference, commands, output-styles
- [Routines (tâches planifiées cloud)](https://code.claude.com/docs/en/routines.md) 🇬🇧 — pages voisines desktop-scheduled-tasks, remote-control
- [Dynamic workflows](https://code.claude.com/docs/en/workflows.md) 🇬🇧 — page voisine agent-view
- [Costs](https://code.claude.com/docs/en/costs.md) 🇬🇧 — pages voisines monitoring-usage, model-config, best-practices, common-workflows, troubleshooting
- [Desktop quickstart](https://code.claude.com/docs/en/desktop-quickstart.md) 🇬🇧 — pages voisines web-quickstart, mobile, vs-code, jetbrains
- [Claude Agent SDK — overview](https://code.claude.com/docs/en/agent-sdk/overview) 🇬🇧 — Python + TypeScript ; mêmes outils/boucle/hooks que Claude Code ; Commercial Terms
- [Agent SDK — quickstart](https://code.claude.com/docs/en/agent-sdk/quickstart.md) 🇬🇧 — pages voisines migration-guide, agent-loop, configuration, examples, sessions, streaming, structured-outputs, custom-tools, mcp, tool-search, subagents, skills, plugins, permissions, hooks, cost-tracking, observability, hosting, secure-deployment
- [Agent SDK — référence TypeScript](https://code.claude.com/docs/en/agent-sdk/typescript.md) 🇬🇧
- [Agent SDK — référence Python](https://code.claude.com/docs/en/agent-sdk/python.md) 🇬🇧
- [Claude Code — page produit](https://claude.com/product/claude-code) 🇬🇧 — inclus Pro 20 $/mois, Max 100-200 $/mois (cité par Tembo)

### 1.8 Dépôts, cookbook, skills
- [Cookbook Claude Platform](https://platform.claude.com/cookbook) 🇬🇧 — ~110 recettes : Managed Agents, Agent SDK, patterns d'agents, evals, multimodal, skills, RAG (recettes `patterns-agents-basic-workflows`, `patterns-agents-orchestrator-workers`, `patterns-agents-evaluator-optimizer`, `misc-building-evals`, `misc-prompt-caching`, `capabilities-retrieval-augmented-generation-guide`…)
- [anthropics/courses (archivé 15 sept. 2026)](https://github.com/anthropics/courses) 🇬🇧 — 5 cours notebooks ; **CC BY-NC 4.0 : usage non commercial uniquement**
- [anthropics/courses — LICENSE](https://github.com/anthropics/courses/blob/master/LICENSE) 🇬🇧 — texte de la licence CC BY-NC 4.0
- [anthropics/claude-cookbooks](https://github.com/anthropics/claude-cookbooks) 🇬🇧 — dépôt source du cookbook (cité par la page cookbook ; licence non vérifiée)
- [anthropics/prompt-eng-interactive-tutorial](https://github.com/anthropics/prompt-eng-interactive-tutorial) 🇬🇧 — tutoriel interactif (Anthropic 1P + Bedrock), cité par la doc prompt engineering
- [anthropics/anthropic-quickstarts](https://github.com/anthropics/anthropic-quickstarts) 🇬🇧 — apps starter (cité par docs home)
- [anthropics/skills](https://github.com/anthropics/skills) 🇬🇧 — skills open source (pptx, xlsx, docx, pdf…), cité par la doc Agent Skills
- [skills.sh — anthropics/skills/academy-guide](https://www.skills.sh/anthropics/skills/academy-guide) 🇬🇧 — annuaire de skills (~185k étoiles pour le dépôt)
- [anthropics/anthropic-sdk-go](https://github.com/anthropics/anthropic-sdk-go) 🇬🇧 — SDK Go, Apache 2.0 depuis le 21 oct. 2026
- [anthropics/anthropic-cli](https://github.com/anthropics/anthropic-cli) 🇬🇧 — CLI `ant`
- [anthropics/claude-agent-sdk-python](https://github.com/anthropics/claude-agent-sdk-python) 🇬🇧 — cité par la doc Agent SDK
- [anthropics/claude-agent-sdk-typescript](https://github.com/anthropics/claude-agent-sdk-typescript) 🇬🇧
- [anthropics/claude-agent-sdk-demos](https://github.com/anthropics/claude-agent-sdk-demos) 🇬🇧
- [Wikipédia — Claude Mythos](https://en.wikipedia.org/wiki/Claude_Mythos) 🇬🇧 — Mythos Preview, Project Glasswing, Fable 5 (chronologie 2026)
- [Support Claude — Cyber Verification Program (article 14604842)](https://support.claude.com/en/articles/14604842) 🇬🇧 — Mythos 5.1 ouvert aux organisations vérifiées (6 oct. 2026 ; cité)

---

## 2. OpenAI

### 2.1 Documentation API (developers.openai.com)
- [Accueil doc API](https://developers.openai.com/api/docs) 🇬🇧 — doc migrée depuis platform.openai.com
- [Index llms.txt](https://developers.openai.com/llms.txt) 🇬🇧
- [Quickstart](https://developers.openai.com/api/docs/quickstart) 🇬🇧 — `client.responses.create(model="gpt-6-astra", input=...)`
- [Concepts clés](https://developers.openai.com/api/docs/concepts) 🇬🇧
- [Catalogue de modèles](https://developers.openai.com/api/docs/models) 🇬🇧 — GPT-6 Astra, GPT-6.1 Sol/Terra, GPT-6 Luna (1,05 M contexte), gpt-5.3-codex, gpt-image-2.5, gpt-realtime-2.1
- [Tarifs](https://developers.openai.com/api/docs/pricing) 🇬🇧 — gpt-6-astra 10/50 $, 6.1-sol 2/10 $, 6.1-terra 1/5 $, 6-luna 0,10/0,50 $ ; Batch/Flex 0,5×, Fast 2× ; fine-tuning en arrêt progressif
- [Référence API](https://developers.openai.com/api/reference/overview) 🇬🇧
- [Model selection](https://developers.openai.com/api/docs/guides/model-selection) 🇬🇧
- [Migrate to Responses API](https://developers.openai.com/api/docs/guides/migrate-to-responses) 🇬🇧 — Items typés, `previous_response_id`, outils intégrés, Assistants API en legacy
- [Text generation](https://developers.openai.com/api/docs/guides/text) 🇬🇧
- [Streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses) 🇬🇧
- [Conversation state](https://developers.openai.com/api/docs/guides/conversation-state) 🇬🇧
- [Background mode](https://developers.openai.com/api/docs/guides/background) 🇬🇧
- [Function calling (Agents API › Functions)](https://developers.openai.com/api/docs/guides/agents-api/tools/functions) 🇬🇧
- [Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs) 🇬🇧 — `text.format = json_schema`, `strict: true`, pydantic / zod
- [Embeddings](https://developers.openai.com/api/docs/guides/embeddings) 🇬🇧
- [Images & vision](https://developers.openai.com/api/docs/guides/images-vision) 🇬🇧
- [Image generation](https://developers.openai.com/api/docs/guides/image-generation) 🇬🇧
- [Audio & speech](https://developers.openai.com/api/docs/guides/audio) 🇬🇧
- [Speech-to-text](https://developers.openai.com/api/docs/guides/speech-to-text) 🇬🇧
- [Text-to-speech](https://developers.openai.com/api/docs/guides/text-to-speech) 🇬🇧
- [Realtime](https://developers.openai.com/api/docs/guides/realtime) 🇬🇧
- [Realtime + MCP](https://developers.openai.com/api/docs/guides/realtime-mcp) 🇬🇧
- [Agents — vue d'ensemble](https://developers.openai.com/api/docs/guides/agents) 🇬🇧
- [Agents SDK](https://developers.openai.com/api/docs/guides/agents/sdk) 🇬🇧 — Agents, Handoffs, Guardrails, streaming, sandboxes, voix, traces
- [Agents SDK — quickstart](https://developers.openai.com/api/docs/guides/agents/quickstart) 🇬🇧
- [Guardrails & approvals](https://developers.openai.com/api/docs/guides/agents/guardrails-approvals) 🇬🇧
- [Model optimization / fine-tuning](https://developers.openai.com/api/docs/guides/model-optimization) 🇬🇧
- [Supervised fine-tuning](https://developers.openai.com/api/docs/guides/supervised-fine-tuning) 🇬🇧
- [Direct preference optimization (DPO)](https://developers.openai.com/api/docs/guides/direct-preference-optimization) 🇬🇧
- [Reinforcement fine-tuning](https://developers.openai.com/api/docs/guides/reinforcement-fine-tuning) 🇬🇧
- [Batch](https://developers.openai.com/api/docs/guides/batch) 🇬🇧
- [Evals — getting started](https://developers.openai.com/api/docs/guides/evaluation-getting-started) 🇬🇧
- [Evals](https://developers.openai.com/api/docs/guides/evals) 🇬🇧
- [Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — Moderation API, adversarial testing, HITL, KYC, safety identifiers
- [Rate limits](https://developers.openai.com/api/docs/guides/rate-limits) 🇬🇧
- [Audio avec Chat Completions (legacy)](https://developers.openai.com/api/docs/guides/audio-chat-completions) 🇬🇧
- [Predicted outputs](https://developers.openai.com/api/docs/guides/predicted-outputs) 🇬🇧
- [Cookbook OpenAI (site)](https://developers.openai.com/cookbook/topic/text) 🇬🇧 — redirigé depuis cookbook.openai.com
- [openai/openai-cookbook (GitHub)](https://github.com/openai/openai-cookbook) 🇬🇧
- [openai/openai-agents-python](https://github.com/openai/openai-agents-python) 🇬🇧 — Agents SDK Python
- [openai/openai-agents-js](https://github.com/openai/openai-agents-js) 🇬🇧 — Agents SDK TypeScript
- [Codex — tarifs](https://developers.openai.com/codex/pricing) 🇬🇧 — Go 8 $, Plus 20 $, Pro 100-200 $ (cité)
- [openai/codex (GitHub)](https://github.com/openai/codex) 🇬🇧 — Codex CLI, Apache 2.0 (cité)
- [Morph — OpenAI API pricing](https://morphllm.com/openai-api-pricing) 🇬🇧 — recoupement tarifaire tiers
- [API Changelog](https://developers.openai.com/api/docs/changelog) 🇬🇧 — veille officielle : nouveaux modèles et fonctions (nov. 2026)
- [Deprecations](https://developers.openai.com/api/docs/deprecations) 🇬🇧 — calendrier d'arrêt des modèles et du fine-tuning (nov. 2026)
- [Build a data analyst with the Agents API (10/09/2026)](https://developers.openai.com/cookbook/examples/agents_api/apps/data_analyst/readme) 🇬🇧 — agent d'analyse de données de bout en bout (nov. 2026, vue dans l'index officiel)
- [Build a Slack bot with the Agents API](https://developers.openai.com/cookbook/examples/agents_api/apps/slack_bot/readme) 🇬🇧 — brancher un agent sur Slack (nov. 2026, vue dans l'index officiel)
- [Build an SRE agent for incident response](https://developers.openai.com/cookbook/examples/agents_api/apps/sev_bot/readme) 🇬🇧 — agent de réponse à incident (nov. 2026, vue dans l'index officiel)
- [Optimizing Customer Support Agents for Cost and Quality (14/09/2026)](https://developers.openai.com/cookbook/examples/agent_optimization/optimizing_agents_for_cost_and_quality) 🇬🇧 — arbitrage coût / qualité d'un agent SAV (nov. 2026, vue dans l'index officiel)
- [Harness-aware evaluation of plugins (23/09/2026)](https://developers.openai.com/cookbook/examples/partners/harness_aware_plugin_evals/harness_aware_plugin_evals) 🇬🇧 — évaluer un plugin dans son harnais d'exécution (nov. 2026, vue dans l'index officiel)
- [GPT-Live evaluation guide](https://developers.openai.com/cookbook/examples/audio/voice_agent_evaluation) 🇬🇧 — évaluer un agent vocal (nov. 2026, vue dans l'index officiel)
- [Run OpenAI agents on a Databricks Sandbox (23/10/2026)](https://developers.openai.com/cookbook/examples/agents_api/sandboxes/databricks/readme) 🇬🇧 — bacs à sable d'exécution pour agents (nov. 2026, vue dans l'index officiel)
- [Run Agents API sandboxes on AWS Lambda MicroVMs](https://developers.openai.com/cookbook/examples/agents_api/sandboxes/aws/readme) 🇬🇧 — isolation de l'exécution de code (nov. 2026, vue dans l'index officiel)

### 2.2 OpenAI Academy et certification
- [OpenAI Academy — accueil](https://academy.openai.com/) 🇬🇧 — 4 parcours : Apply AI at Work, Build with AI, Lead AI Adoption, Teach and Learn with AI
- [Catalogue des cours](https://academy.openai.com/pages/courses) 🇬🇧 — AI Foundations, Applied AI Foundations, Agents and Workflows (badges Accredible/Credly)
- [Guide de déploiement des cours (organisations)](https://academy.openai.com/home/clubs/champions-ecqup/resources/openai-academy-courses-champion-deployment-guide-2026-06-11) 🇬🇧 — 11 juin 2026
- [bestaicertifications.com — OpenAI certification](https://bestaicertifications.com/openai-certification/) 🇬🇧 — analyse tierce (17 oct. 2026)
- [findskill.ai — OpenAI certification guide](https://findskill.ai/blog/openai-certification-guide/) 🇬🇧 — analyse tierce (12 juil. 2026)
- [gend.co — OpenAI certifications AI Foundations 2026](https://www.gend.co/blog/openai-certifications-ai-foundations-2026) 🇬🇧 — analyse tierce (9 déc. 2025)
- [TechRepublic — OpenAI ChatGPT training certifications](https://www.techrepublic.com/article/news-openai-chatgpt-training-certifications/) 🇬🇧 — annonce (22 déc. 2025)
- [flashgenius — Ultimate guide to OpenAI certifications 2026](https://flashgenius.net/blog-article/ultimate-guide-to-openai-certifications-2026) 🇬🇧 — tiers
- [MentorCruise — certifications OpenAI](https://mentorcruise.com/certifications/openai/) 🇬🇧 — tiers (cite ~100 $ pour AWS AIF-C01)

---

## 3. xAI (Grok)
- [Introduction](https://docs.x.ai/developers/introduction) 🇬🇧
- [Quickstart](https://docs.x.ai/developers/quickstart) 🇬🇧 — Vercel AI SDK, SDK OpenAI (`base_url=https://api.x.ai/v1`), `xai-sdk` ; `grok-4.7`
- [Modèles](https://docs.x.ai/developers/models) 🇬🇧 — grok-4.7 (500k, cutoff mai 2026), 4.6, 4.5, grok-build-0.1, 4.3, 4.20
- [Tarifs](https://docs.x.ai/developers/pricing) 🇬🇧 — grok-4.7 2/6 $ par MTok ; outils serveur 5 $/1 000 ; Imagine ; Voice API ; Batch −20 %
- [Release notes](https://docs.x.ai/developers/release-notes) 🇬🇧
- [Generate text](https://docs.x.ai/developers/model-capabilities/text/generate-text) 🇬🇧
- [Streaming](https://docs.x.ai/developers/model-capabilities/text/streaming) 🇬🇧
- [Reasoning](https://docs.x.ai/developers/model-capabilities/text/reasoning) 🇬🇧 — `reasoning_effort`
- [Structured outputs](https://docs.x.ai/developers/model-capabilities/text/structured-outputs) 🇬🇧
- [Image understanding (vision)](https://docs.x.ai/developers/model-capabilities/images/understanding) 🇬🇧
- [Multi-agent](https://docs.x.ai/developers/model-capabilities/text/multi-agent) 🇬🇧
- [Best practices](https://docs.x.ai/developers/model-capabilities/text/best-practices) 🇬🇧
- [Comparison / migration vers Responses](https://docs.x.ai/developers/model-capabilities/text/comparison) 🇬🇧
- [Chat Completions (legacy)](https://docs.x.ai/developers/model-capabilities/legacy/chat-completions) 🇬🇧
- [Tools — overview](https://docs.x.ai/developers/tools/overview) 🇬🇧
- [Function calling](https://docs.x.ai/developers/tools/function-calling) 🇬🇧
- [Web search (ex-Live Search)](https://docs.x.ai/developers/tools/web-search) 🇬🇧
- [X search](https://docs.x.ai/developers/tools/x-search) 🇬🇧
- [Code execution](https://docs.x.ai/developers/tools/code-execution) 🇬🇧
- [Image generation](https://docs.x.ai/developers/tools/image-generation) 🇬🇧 — `grok-imagine-image-2.0`
- [Collections search (RAG)](https://docs.x.ai/developers/tools/collections-search) 🇬🇧
- [Remote MCP](https://docs.x.ai/developers/tools/remote-mcp) 🇬🇧
- [Rate limits](https://docs.x.ai/developers/rate-limits) 🇬🇧
- [Debugging](https://docs.x.ai/developers/debugging) 🇬🇧
- [Cost tracking](https://docs.x.ai/developers/cost-tracking) 🇬🇧
- [Batch API](https://docs.x.ai/developers/advanced-api-usage/batch-api) 🇬🇧
- [Cookbook xAI](https://docs.x.ai/cookbook) 🇬🇧
- [Console xAI](https://console.x.ai) 🇬🇧
- [Clés API (console)](https://console.x.ai/team/default/api-keys) 🇬🇧
- [Morph — Grok API pricing](https://www.morphllm.com/grok-api-pricing) 🇬🇧 — recoupement tiers (21 août 2026)
- [ai-toolbox — Grok pricing plans & API 2026](https://ai-toolbox.co/grok-models/grok-pricing-plans-api-2026) 🇬🇧 — « The X Subscription » : Plus 8 $, Premium 30 $, Super 100 $, Ultra 200 $/mois (12 oct. 2026)
- [pricepertoken — abonnements Grok](https://pricepertoken.com/subscriptions/grok) 🇬🇧 — anciennes offres SuperGrok (25 juin 2026)
- [Citations](https://docs.x.ai/developers/tools/citations) 🇬🇧 — récupérer les sources des outils de recherche (nov. 2026, vue dans l'index officiel)
- [Image Prompting Guide](https://docs.x.ai/developers/model-capabilities/images/prompting-guide) 🇬🇧 — rédiger des prompts pour Grok Imagine (nov. 2026, vue dans l'index officiel)
- [Context Compaction](https://docs.x.ai/developers/advanced-api-usage/context-compaction) 🇬🇧 — compacter le contexte des longues sessions (nov. 2026, vue dans l'index officiel)

---

## 4. Perplexity
- [Index llms.txt](https://docs.perplexity.ai/llms.txt) 🇬🇧
- [Overview](https://docs.perplexity.ai/docs/getting-started/overview.md) 🇬🇧
- [Quickstart](https://docs.perplexity.ai/docs/getting-started/quickstart.md) 🇬🇧
- [Tarifs](https://docs.perplexity.ai/getting-started/pricing) 🇬🇧 — Search API 5 $/1 000 (Fast 1 $), Agent API outils, embeddings, Decisions
- [Tarifs (version .md)](https://docs.perplexity.ai/docs/getting-started/pricing.md) 🇬🇧
- [Projets & facturation](https://docs.perplexity.ai/docs/getting-started/projects.md) 🇬🇧
- [Rate limits & usage tiers](https://docs.perplexity.ai/docs/admin/rate-limits-usage-tiers.md) 🇬🇧
- [Migrate from Sonar](https://docs.perplexity.ai/docs/agent-api/migrate-from-sonar/overview.md) 🇬🇧 — fin de support Sonar Chat Completions le 27 sept. 2026 ; équivalences d'effort
- [Agent API — quickstart](https://docs.perplexity.ai/docs/agent-api/quickstart.md) 🇬🇧
- [Agent API — modèles & tarifs](https://docs.perplexity.ai/docs/agent-api/models.md) 🇬🇧 — routage multi-fournisseurs (OpenAI, Google, xAI, Anthropic, GLM, DeepSeek, Kimi, sonar)
- [Agent API — effort](https://docs.perplexity.ai/docs/agent-api/effort.md) 🇬🇧
- [Agent API — tools overview](https://docs.perplexity.ai/docs/agent-api/tools/overview.md) 🇬🇧
- [Agent API — web_search](https://docs.perplexity.ai/docs/agent-api/tools/web-search.md) 🇬🇧
- [Agent API — MCP](https://docs.perplexity.ai/docs/agent-api/tools/mcp.md) 🇬🇧
- [Agent API — custom functions](https://docs.perplexity.ai/docs/agent-api/tools/custom-functions.md) 🇬🇧
- [Agent API — output control (structured)](https://docs.perplexity.ai/docs/agent-api/output-control.md) 🇬🇧
- [Agent API — conversation state](https://docs.perplexity.ai/docs/agent-api/conversation-state.md) 🇬🇧
- [Agent API — batch](https://docs.perplexity.ai/docs/agent-api/batch.md) 🇬🇧
- [Agent API — compatibilité OpenAI](https://docs.perplexity.ai/docs/agent-api/openai-compatibility.md) 🇬🇧
- [Agent API — prompt guide](https://docs.perplexity.ai/docs/agent-api/prompt-guide.md) 🇬🇧
- [Orchestrator (Router) — modèles](https://docs.perplexity.ai/docs/router/models.md) 🇬🇧
- [Search API — overview](https://docs.perplexity.ai/docs/search/overview.md) 🇬🇧
- [Search API — quickstart](https://docs.perplexity.ai/docs/search/quickstart.md) 🇬🇧
- [Search API — Fast Search](https://docs.perplexity.ai/docs/search/fast-search.md) 🇬🇧
- [Search API — filtre de domaine](https://docs.perplexity.ai/docs/search/filters/domain-filter.md) 🇬🇧
- [Embeddings — quickstart](https://docs.perplexity.ai/docs/embeddings/quickstart.md) 🇬🇧 — `pplx-embed-v1-0.6b` / `4b`
- [Decisions — quickstart](https://docs.perplexity.ai/docs/decisions/quickstart.md) 🇬🇧
- [SDK — overview](https://docs.perplexity.ai/docs/sdk/overview.md) 🇬🇧
- [CLI — overview](https://docs.perplexity.ai/docs/cli/overview.md) 🇬🇧
- [MCP server Perplexity](https://docs.perplexity.ai/docs/getting-started/integrations/mcp-server.md) 🇬🇧
- [Intégration n8n](https://docs.perplexity.ai/docs/getting-started/integrations/n8n.md) 🇬🇧
- [Cookbook — index](https://docs.perplexity.ai/docs/cookbook/index.md) 🇬🇧
- [Cookbook — streaming citations](https://docs.perplexity.ai/docs/cookbook/articles/streaming-citations/README.md) 🇬🇧
- [Sandbox (Agent API)](https://docs.perplexity.ai/docs/agent-api/tools/sandbox.md) 🇬🇧 — exécuter du code dans l'Agent API (nov. 2026, vue dans l'index officiel)
- [Search — Best Practices](https://docs.perplexity.ai/docs/search/best-practices.md) 🇬🇧 — bien formuler les requêtes de la Search API (nov. 2026, vue dans l'index officiel)
- [Search Date and Time Filters](https://docs.perplexity.ai/docs/search/filters/date-time-filters.md) 🇬🇧 — filtrer les résultats par date (veille) (nov. 2026, vue dans l'index officiel)
- [Contextualized Embeddings](https://docs.perplexity.ai/docs/embeddings/contextualized-embeddings.md) 🇬🇧 — embeddings contextualisés pour le RAG (nov. 2026, vue dans l'index officiel)
- [SDK — Error Handling](https://docs.perplexity.ai/docs/sdk/error-handling.md) 🇬🇧 — gérer les erreurs et les relances (nov. 2026, vue dans l'index officiel)
- [RAG with Perplexity Embeddings](https://docs.perplexity.ai/docs/cookbook/articles/embeddings-rag/README.md) 🇬🇧 — construire un RAG complet (nov. 2026, vue dans l'index officiel)
- [Structured Output Extraction](https://docs.perplexity.ai/docs/cookbook/articles/structured-output-extraction/README.md) 🇬🇧 — extraire du JSON depuis une recherche (nov. 2026, vue dans l'index officiel)
- [Multi-Provider Orchestration](https://docs.perplexity.ai/docs/cookbook/articles/multi-provider-orchestration/README.md) 🇬🇧 — router entre fournisseurs (lien avec L088) (nov. 2026, vue dans l'index officiel)
- [Function Calling End-to-End](https://docs.perplexity.ai/docs/cookbook/articles/function-calling-e2e/README.md) 🇬🇧 — fonctions personnalisées dans l'Agent API (nov. 2026, vue dans l'index officiel)
- [Deep Research Workflows](https://docs.perplexity.ai/docs/cookbook/articles/async-deep-research/README.md) 🇬🇧 — recherches longues et asynchrones (nov. 2026, vue dans l'index officiel)
- [Agent Research Assistant](https://docs.perplexity.ai/docs/cookbook/examples/agent-research-assistant/README.md) 🇬🇧 — exemple complet d'assistant de recherche (nov. 2026, vue dans l'index officiel)
- [Document Q&A with Embeddings](https://docs.perplexity.ai/docs/cookbook/examples/document-qa/README.md) 🇬🇧 — questions-réponses sur documents (nov. 2026, vue dans l'index officiel)
- [Perplexity with LangChain](https://docs.perplexity.ai/docs/getting-started/integrations/langchain.md) 🇬🇧 — intégration avec LangChain (nov. 2026, vue dans l'index officiel)

---

## 5. Mistral AI
- [Models overview](https://docs.mistral.ai/getting-started/models/) 🇬🇧 — Mistral Large 4, Small 4 (Apache 2.0), Ministral 3, OCR 4.1, Voxtral, Codestral, Shieldstral
- [Catalogue modèles](https://docs.mistral.ai/models) 🇬🇧 — dépréciations (mistral-medium-3-5 → Large 4 au 30/04/2027)
- [Tarifs](https://docs.mistral.ai/inference/pricing) 🇬🇧 — Large 4 0,70/2,10 $, Small 4 0,15/0,60 $, OCR 4.1 4 $/1 000 pages, Voxtral, embeddings
- [Model selection guide](https://docs.mistral.ai/inference/model-selection-guide) 🇬🇧
- [Model lifecycle](https://docs.mistral.ai/inference/model-lifecycle) 🇬🇧
- [Inference (section)](https://docs.mistral.ai/inference) 🇬🇧
- [Prompting](https://docs.mistral.ai/inference/prompting) 🇬🇧
- [Regional inference](https://docs.mistral.ai/inference/regional-inference) 🇬🇧
- [Priority tier](https://docs.mistral.ai/inference/priority-tier) 🇬🇧
- [Référence API](https://docs.mistral.ai/api) 🇬🇧
- [Codestral 25.08](https://docs.mistral.ai/models/codestral-25-08) 🇬🇧
- [OCR 4.1](https://docs.mistral.ai/models/ocr-4-1) 🇬🇧
- [Voxtral Mini Transcribe 3](https://docs.mistral.ai/models/voxtral-mini-transcribe-3-0) 🇬🇧
- [Voxtral TTS 3](https://docs.mistral.ai/models/voxtral-mini-tts-3-0) 🇬🇧
- [Mistral Embed](https://docs.mistral.ai/models/mistral-embed-23-12) 🇬🇧
- [Codestral Embed](https://docs.mistral.ai/models/codestral-embed-25-05) 🇬🇧
- [Vibe (CLI de code)](https://docs.mistral.ai/vibe) 🇬🇧
- [AI Studio (ex-La Plateforme) — doc](https://docs.mistral.ai/studio) 🇬🇧
- [Console AI Studio](https://console.mistral.ai) 🇬🇧
- [Mistral Small 4 — annonce](https://mistral.ai/news/mistral-small-4/) 🇬🇧 — 119B / 6B actifs, Apache 2.0 (16 mars 2026)
- [Devstral 2 + Vibe CLI — annonce](https://mistral.ai/news/devstral-2-vibe-cli/) 🇬🇧
- [Mistral Small 3.1 — annonce](https://mistral.ai/en/news/mistral-small-3-1) 🇬🇧 — cité par HF blog
- [Devstral — annonce](https://mistral.ai/en/news/devstral) 🇬🇧 — cité par HF blog
- [Collection HF Mistral Small 4](https://huggingface.co/collections/mistralai/mistral-small-4) 🇬🇧 — cité
- [Voxtral 4B TTS (HF)](https://huggingface.co/mistralai/Voxtral-4B-TTS-2603) 🇬🇧 — CC BY-NC 4.0 (cité)
- [Serenities AI — Mistral AI models 2026 complete guide](https://serenitiesai.com/articles/mistral-ai-models-2026-complete-guide) 🇬🇧 — Ministral 3, Large 3, Moderation 2603
- [ActuIA — Mistral Large 4 drops from 38 to 25 on new Artificial Analysis index](https://www.actuia.com/en/news/mistral-large-4-drops-from-38-to-25-on-new-artificial-analysis-index/) 🇬🇧 — index AA v5 (oct. 2026)
- [Changelogs](https://docs.mistral.ai/resources/changelogs) 🇬🇧 — veille officielle Mistral (nov. 2026)
- [Cookbooks (111 entrées)](https://docs.mistral.ai/resources/cookbooks) 🇬🇧 — index des notebooks officiels (nov. 2026)
- [SDKs](https://docs.mistral.ai/resources/sdks) 🇬🇧 — clients Python / TypeScript (nov. 2026, vue dans l'index officiel)
- [Function calling](https://docs.mistral.ai/studio-api/conversations/function-calling) 🇬🇧 — appel de fonctions (nov. 2026, vue dans l'index officiel)
- [Structured output](https://docs.mistral.ai/studio-api/conversations/structured-output) 🇬🇧 — sorties JSON fiables (nov. 2026, vue dans l'index officiel)
- [Agents — introduction](https://docs.mistral.ai/studio-api/agents/introduction) 🇬🇧 — agents API de Mistral (nov. 2026, vue dans l'index officiel)
- [Basic OCR (Document AI)](https://docs.mistral.ai/studio-api/document-processing/basic_ocr) 🇬🇧 — OCR de documents (nov. 2026, vue dans l'index officiel)
- [Safety & moderation](https://docs.mistral.ai/studio-api/safety-moderation) 🇬🇧 — garde-fous et modération (nov. 2026, vue dans l'index officiel)
- [Concepts : visite du Mistral Search Toolkit](https://docs.mistral.ai/resources/cookbooks/mistral-rag-00-introduction-concepts) 🇬🇧 — notions de RAG, avec schémas (nov. 2026)
- [OCR / Document AI — PDF Chunking](https://docs.mistral.ai/resources/cookbooks/mistral-ocr-documentchunking-document_chunking_cookbook) 🇬🇧 — découper un PDF pour le RAG (nov. 2026)
- [Human-in-the-Loop Tool Confirmation](https://docs.mistral.ai/resources/cookbooks/mistral-connectors-04-human-in-the-loop-confirmation) 🇬🇧 — validation humaine avant une action (nov. 2026)
- [Running Campaigns with LLM Judges (Observability API)](https://docs.mistral.ai/resources/cookbooks/mistral-observability-llm_judge_campaign_workflow) 🇬🇧 — évaluation par un LLM juge (nov. 2026)

---

## 6. Google (Gemini, Gemma, cours)

### 6.1 Gemini API et outils
- [Modèles Gemini](https://ai.google.dev/gemini-api/docs/models) 🇬🇧 — gemini-4-argon, 3.8-flash, 3.8-live, Nano Banana 2.1, embeddings 2, lyria-3.5
- [Gemini 3.8 Flash](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash) 🇬🇧 — 1 048 576 in / 65 536 out ; multimodal ; outils
- [Tarifs Gemini API](https://ai.google.dev/gemini-api/docs/pricing) 🇬🇧 — argon 2/10 $ (→ 4/20 $ au 1er déc. 2026), 3.8-flash 0,75/3,75 $ ; grounding 5 000 requêtes gratuites/mois
- [Get started](https://ai.google.dev/gemini-api/docs/get-started) 🇬🇧
- [Text generation](https://ai.google.dev/gemini-api/docs/text-generation) 🇬🇧
- [Function calling](https://ai.google.dev/gemini-api/docs/function-calling) 🇬🇧
- [Structured output](https://ai.google.dev/gemini-api/docs/structured-output) 🇬🇧
- [Embeddings](https://ai.google.dev/gemini-api/docs/embeddings) 🇬🇧
- [Image generation](https://ai.google.dev/gemini-api/docs/image-generation) 🇬🇧
- [Live API](https://ai.google.dev/gemini-api/docs/live-api) 🇬🇧
- [Files API](https://ai.google.dev/gemini-api/docs/files) 🇬🇧
- [Grounding with Google Search](https://ai.google.dev/gemini-api/docs/google-search) 🇬🇧
- [Context caching](https://ai.google.dev/gemini-api/docs/caching) 🇬🇧
- [Batch API](https://ai.google.dev/gemini-api/docs/batch-api) 🇬🇧
- [Gemini CLI — quotas & tarifs](https://geminicli.com/docs/resources/quota-and-pricing) 🇬🇧 — redirection depuis /docs/quota-and-pricing
- [Gemini CLI — quotas (ancienne URL)](https://geminicli.com/docs/quota-and-pricing) 🇬🇧
- [google-gemini/gemini-cli (GitHub)](https://github.com/google-gemini/gemini-cli) 🇬🇧 — Apache 2.0 (cité par Firecrawl ; non ouvert)
- [Gemma 4 — DeepMind](https://deepmind.google/models/gemma/gemma-4/) 🇬🇧 — cité
- [Gemma 4 sur LiteRT-LM (edge)](https://ai.google.dev/edge/litert-lm/models/gemma-4) 🇬🇧 — E2B/E4B embarqués
- [DataNorth — Google releases Gemma 4 open models](https://datanorth.ai/news/google-releases-gemma-4-open-models) 🇬🇧 — 2 avr. 2026, Apache 2.0, 26B-A4B, 31B
- [Gemma 4 26B-A4B (HF)](https://huggingface.co/google/gemma-4-26B-A4B-it) 🇬🇧 — cité
- [Google Antigravity](https://antigravity.google) 🇬🇧 — IDE agentique (gratuit particuliers)
- [Thinking](https://ai.google.dev/gemini-api/docs/thinking) 🇬🇧 — budget de réflexion et facturation des tokens de pensée (nov. 2026, vue dans l'index officiel)
- [Long context](https://ai.google.dev/gemini-api/docs/long-context) 🇬🇧 — exploiter un très long contexte (nov. 2026, vue dans l'index officiel)
- [Document processing](https://ai.google.dev/gemini-api/docs/document-processing) 🇬🇧 — analyser des PDF (nov. 2026, vue dans l'index officiel)
- [URL context](https://ai.google.dev/gemini-api/docs/url-context) 🇬🇧 — donner des URL comme contexte (nov. 2026, vue dans l'index officiel)
- [Code execution](https://ai.google.dev/gemini-api/docs/code-execution) 🇬🇧 — exécution de code côté serveur (nov. 2026, vue dans l'index officiel)
- [Computer use (GA le 30/10/2026)](https://ai.google.dev/gemini-api/docs/computer-use) 🇬🇧 — agents qui pilotent un navigateur ou un bureau (nov. 2026, vue dans l'index officiel)
- [Interactions API overview](https://ai.google.dev/gemini-api/docs/interactions-overview) 🇬🇧 — nouvelle API conversationnelle à état (nov. 2026, vue dans l'index officiel)
- [Prompt engineering (prompting strategies)](https://ai.google.dev/gemini-api/docs/prompting-strategies) 🇬🇧 — guide officiel de prompting Gemini (nov. 2026, vue dans l'index officiel)
- [Gemini API CLI (`gemini-api`, bêta)](https://ai.google.dev/gemini-api/docs/cli) 🇬🇧 — client en ligne de commande pour scripts et CI (nov. 2026, vue dans l'index officiel)
- [AI Studio quickstart](https://ai.google.dev/gemini-api/docs/ai-studio-quickstart) 🇬🇧 — prise en main sans code (nov. 2026, vue dans l'index officiel)
- [Gemini API Cookbook (GitHub)](https://github.com/google-gemini/cookbook) 🇬🇧 — notebooks officiels (nov. 2026, vue dans l'index officiel)

### 6.2 Cours Google
- [Machine Learning Crash Course](https://developers.google.com/machine-learning/crash-course?authuser=8) 🇬🇧 — 12 modules (régression → LLM → production, fairness)
- [Introduction to Generative AI Learning Path (parcours 118)](https://www.cloudskillsboost.google/paths/118) 🇬🇧 — redirige vers skills.google
- [Introduction to Generative AI (course 536)](https://www.cloudskillsboost.google/paths/118/course_templates/536) 🇬🇧
- [Introduction to Responsible AI (course 554)](https://www.cloudskillsboost.google/course_templates/554) 🇬🇧
- [Google AI Essentials — Coursera](https://www.coursera.org/google-specializations/ai-essentials-google) 🇬🇧 — 5 cours, 49 $/mois après essai
- [Google AI Essentials — Coursera (FR)](https://www.coursera.org/fr-FR/specializations/ai-essentials-google) 🇫🇷 — version doublée IA en français
- [Google AI Essentials — Grow with Google](https://grow.google/enroll-certificates/ai-essentials-mid/) 🇬🇧
- [Google AI Professional Certificate — Coursera](https://www.coursera.org/professional-certificates/google-ai) 🇬🇧 — 8 cours (mis à jour août 2026)
- [Blog du Modérateur — Google Skills](https://www.blogdumoderateur.com/google-skills-comment-se-former-gratuitement-ia-cours-officiels-google/) 🇫🇷 — AI Boost Bites, Google AI Professional Certificate (49 $/mois ou 349 $/an)
- [The Daily Star — free Google courses](https://www.thedailystar.net/tech-startup/news/free-google-courses-level-your-ai-skills-3626566) 🇬🇧 — liste des cours du parcours 118
- [Coursera — Google vs IBM vs DeepLearning.AI](https://www.coursera.org/articles/google-vs-ibm-specializations-vs-deep-learning-ai-course) 🇬🇧 — comparatif

---

## 7. Hugging Face
- [Hugging Face Learn (catalogue)](https://huggingface.co/learn) 🇬🇧 — 12 cours gratuits
- [LLM Course](https://huggingface.co/learn/llm-course) 🇬🇧 — Apache 2.0 ; 12 chapitres (Transformers → fine-tuning → reasoning models)
- [LLM Course — chapitre 1](https://huggingface.co/learn/llm-course/chapter1/1) 🇬🇧 — quiz et certification exam
- [Agents Course](https://huggingface.co/learn/agents-course) 🇬🇧 — smolagents, LlamaIndex, LangGraph, RAG agentique, projet final
- [Agents Course — unité 0](https://huggingface.co/learn/agents-course/unit0/introduction) 🇬🇧
- [a smol course (post-training)](https://huggingface.co/learn/smol-course) 🇬🇧 — SFT, évaluation, DPO, VLM, RL, données synthétiques
- [MCP Course](https://huggingface.co/learn/mcp-course/unit0/introduction) 🇬🇧 — Python ou TypeScript, certificats
- [MCP Course — certificat unité 1](https://huggingface.co/learn/mcp-course/unit1/certificate) 🇬🇧
- [Context Course](https://huggingface.co/learn/context-course) 🇬🇧 — context engineering pour agents de code
- [Deep RL Course — unité 0](https://huggingface.co/learn/deep-rl-course/unit0/introduction) 🇬🇧
- [Diffusion Course — unité 0](https://huggingface.co/learn/diffusion-course/unit0/1) 🇬🇧
- [Diffusion Course](https://huggingface.co/learn/diffusion-course) 🇬🇧
- [Robotics Course (LeRobot)](https://huggingface.co/learn/robotics-course) 🇬🇧
- [Community Computer Vision Course](https://huggingface.co/learn/computer-vision-course) 🇬🇧
- [Audio Course](https://huggingface.co/learn/audio-course) 🇬🇧
- [ML for Games Course](https://huggingface.co/learn/ml-games-course) 🇬🇧
- [ML for 3D Course](https://huggingface.co/learn/ml-for-3d-course) 🇬🇧
- [Open-Source AI Cookbook](https://huggingface.co/learn/cookbook) 🇬🇧
- [Hub — inférence depuis les pages de modèles](https://huggingface.co/docs/hub/models-inference) 🇬🇧
- [Inference Providers — premier appel](https://huggingface.co/docs/inference-providers/main/guides/first-api-call) 🇬🇧 — `InferenceClient(provider="auto")`, endpoint OpenAI https://router.huggingface.co/v1
- [Inference Providers — tarifs](https://huggingface.co/docs/inference-providers/pricing) 🇬🇧 — PRO 2 $/mois de crédits, prix fournisseur sans marge
- [Inference Providers — intégration Hub](https://huggingface.co/docs/inference-providers/hub-integration) 🇬🇧
- [HF-Inference (ex-Inference API)](https://huggingface.co/docs/inference-providers/providers/hf-inference) 🇬🇧
- [Réglages Inference Providers](https://hf.co/settings/inference-providers) 🇬🇧
- [TRL — intégration PEFT](https://huggingface.co/docs/trl/main/en/peft_integration) 🇬🇧 — SFTTrainer, DPOTrainer, GRPO
- [smolagents — docs](https://huggingface.co/docs/smolagents) 🇬🇧 — cité (non re-vérifié)
- [HF blog — Open-source LLM models to run locally](https://huggingface.co/blog/daya-shankar/open-source-llm-models-to-run-locally) 🇬🇧 — 13 mai 2026
- [HF blog — Open-source LLMs](https://huggingface.co/blog/daya-shankar/open-source-llms) 🇬🇧 — 13 nov. 2025
- [HF blog — Reflection Beam](https://huggingface.co/blog/reflection-beam) 🇬🇧 — cité (SWE-bench Verified 81,6 %)
- [Open LLM Leaderboard v3 (Space)](https://huggingface.co/spaces/open-llm-leaderboard/open_llm_leaderboard_v3) 🇬🇧 — cité
- [KDnuggets — 5 free AI courses from Hugging Face](https://www.kdnuggets.com/5-free-ai-courses-from-hugging-face) 🇬🇧
- [AI Engineer Guide — free AI courses from Hugging Face](https://aiengineerguide.com/til/free-ai-courses-from-huggingface/) 🇬🇧
- [KDnuggets — SmolLM3 avec Transformers](https://www.kdnuggets.com/small-language-models-with-hugging-face-transformers-library-smollm3) 🇬🇧

---

## 8. n8n, Make, Zapier

### 8.1 n8n Academy (learn.n8n.io)
- [n8n Academy — accueil](https://learn.n8n.io/) 🇬🇧 — lancée le 16 juin 2026 ; remplace les cours Level 1/2
- [Catalogue des cours](https://learn.n8n.io/courses) 🇬🇧
- [QS101 n8n Quickstart](https://learn.n8n.io/courses/course-v1:n8n+QS101+2026H2/about) 🇬🇧
- [N8N101 Essentials: Your First Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N101+2026H2/about) 🇬🇧 — 2-4 h ; canvas, nœuds, triggers, expressions
- [N8N102 Integrations: APIs & Connected Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about) 🇬🇧 — 4-6 h ; logique, HTTP, OAuth2, webhooks, Data Tables
- [N8N103 In Practice: AI, Testing & Best Practices](https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about) 🇬🇧 — 3-4 h ; AI Agent node, debugger, bonnes pratiques
- [Ancien cours Level 1 (redirige vers learn.n8n.io)](https://docs.n8n.io/courses/level-one) 🇬🇧
- [Ancien cours Level 2 (redirige vers learn.n8n.io)](https://docs.n8n.io/courses/level-two) 🇬🇧
- [Annonce « The n8n Academy is here »](https://community.n8n.io/t/the-n8n-academy-is-here/299695) 🇬🇧 — 16 juin 2026
- [Retiring the text courses and forum badges](https://community.n8n.io/t/retiring-the-text-courses-and-forum-badges/299962) 🇬🇧
- [Forum n8n Academy](https://community.n8n.io/c/n8n-academy/41) 🇬🇧
- [No official n8n certification yet](https://community.n8n.io/t/no-official-n8n-certification-yet/318573?tl=en) 🇬🇧 — certification repoussée à fin T4 2026 (5 oct. 2026)
- [n8n Education](https://n8n.io/education/) 🇬🇧 — « coming soon »

### 8.2 Documentation n8n
- [Index llms.txt](https://docs.n8n.io/llms.txt) 🇬🇧
- [Learning paths](https://docs.n8n.io/learning-paths) 🇬🇧
- [Build your first workflow](https://docs.n8n.io/build-your-first-workflow.md) 🇬🇧
- [Intégrer l'IA (hub)](https://docs.n8n.io/build/integrate-ai.md) 🇬🇧
- [LangChain dans n8n (cluster nodes)](https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md) 🇬🇧 — root nodes (chains, AI Agent, vector stores) + sub-nodes (modèles, mémoire, outils, embeddings)
- [Cluster nodes](https://docs.n8n.io/integrations/builtin/cluster-nodes.md) 🇬🇧
- [Nœud AI Agent](https://docs.n8n.io/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.agent.md) 🇬🇧 — cité (chargement direct refusé)
- [Ce que font les agents](https://docs.n8n.io/build/integrate-ai/understand-ai-components/what-agents-do.md) 🇬🇧
- [Agents (préversion) — Agent Builder](https://docs.n8n.io/build/build-and-manage-agents.md) 🇬🇧 — canaux Slack/Telegram/Teams, cron, sous-agents
- [Vector stores & embeddings](https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md) 🇬🇧
- [Retrieve relevant context (RAG)](https://docs.n8n.io/build/integrate-ai/understand-ai-components/retrieve-relevant-context.md) 🇬🇧
- [Chat Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.chattrigger.md) 🇬🇧
- [LangChain Code node](https://docs.n8n.io/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.code.md) 🇬🇧
- [MCP — registre & MCP Client Tool](https://docs.n8n.io/build/integrate-ai/mcp-servers.md) 🇬🇧
- [MCP Server Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.mcptrigger.md) 🇬🇧
- [MCP Client](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.mcpclient.md) 🇬🇧
- [Serveur MCP de n8n (instance)](https://docs.n8n.io/build/ways-of-building-workflows/connect-to-n8n-mcp-server.md) 🇬🇧
- [Human in the loop for tools](https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md) 🇬🇧
- [Evaluations — pourquoi tester](https://docs.n8n.io/build/integrate-ai/test-and-improve-ai-workflows/understand-why-to-test.md) 🇬🇧
- [Evaluation node](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluation.md) 🇬🇧
- [Templates](https://docs.n8n.io/build/ways-of-building-workflows/use-templates.md) 🇬🇧
- [Data Tables](https://docs.n8n.io/build/work-with-data/data-tables.md) 🇬🇧
- [Hébergement (hub)](https://docs.n8n.io/deploy/host-n8n.md) 🇬🇧
- [Options d'installation](https://docs.n8n.io/deploy/host-n8n/install-options.md) 🇬🇧
- [Install with Docker](https://docs.n8n.io/deploy/host-n8n/install-options/install-with-docker.md) 🇬🇧 — port 5678, volume `n8n_data`, `N8N_ENCRYPTION_KEY` (Compose recommandé)
- [Install using Docker Compose](https://docs.n8n.io/deploy/host-n8n/install-options/install-using-docker-compose.md) 🇬🇧
- [Install with npm](https://docs.n8n.io/deploy/host-n8n/install-options/install-with-npm.md) 🇬🇧
- [Scaling / queue mode](https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling.md) 🇬🇧
- [42 Perpignan — AI Automation with n8n (programme PDF)](https://42perpignan.fr/wp-content/uploads/2026/05/AI-Automation-with-n8n-Programme.pdf) 🇫🇷 — 21 h, 1 490 € TTC, projet agent IA (mai 2026)
- [n8n — Release notes](https://docs.n8n.io/release-notes) 🇬🇧 — suivre les versions (n8n 3.0 du 27/10/2026) (nov. 2026)

### 8.3 Make
- [Make Academy — accueil](https://academy.make.com/) 🇬🇧 — gratuit, badges Credly, 6 mois d'accès
- [Recherche catalogue](https://academy.make.com/pages/search) 🇬🇧
- [Parcours « Automation to AI Agents: Advanced »](https://academy.make.com/bundles/automation-to-ai-agents-advanced-builder) 🇬🇧 — ~3 h, badge « AI Agent Builder » : MCP, context engineering, agent de production
- [Make Academy course overview (community)](https://community.make.com/t/make-academy-course-overview/29699) 🇬🇧 — titres des cours Foundation → Advanced (6 mars 2024)
- [Annonce « AI Automation Explorer »](https://community.make.com/t/make-academy-news-ai-automation-explorer/105070) 🇬🇧 — 8 mars 2026
- [Make — Operations (aide)](https://help.make.com/operations) 🇬🇧 — règles de décompte des opérations et des crédits (nov. 2026)
- [Make Academy — Credit consumption in Make](https://academy-content.make.com/courses/make-foundation-operations-credits/02-credit-consumption-in-make) 🇬🇧 — opérations et crédits, déclencheurs, routeurs, modules IA (nov. 2026)

### 8.4 Zapier
- [Zapier Academy — AI Builder Path](https://learn.zapier.com/path/ai-builder-path) 🇬🇧 — page JS (contenu non rendu)
- [Cours « Building AI Agents »](https://learn.zapier.com/building-ai-agents) 🇬🇧 — idem
- [Solution Partner Program (ex-Zapier Experts)](https://zapier.com/l/new-experts/info) 🇬🇧 — certification partenaires par niveaux, pas de certification grand public

---

## 9. LLM locaux (outils)
- [Ollama — docs](https://docs.ollama.com) 🇬🇧 — API REST port 11434, compatible OpenAI et Anthropic, bibliothèques Python/JS, modèles cloud
- [Ollama — téléchargement](https://ollama.com/download) 🇬🇧 — macOS, Windows, Linux (`curl -fsSL https://ollama.com/install.sh | sh`)
- [Ollama — catalogue de modèles](https://ollama.com/search) 🇬🇧 — catégories embeddings, vision, safety (Llama Guard)
- [Guide Ollama (kx.cloudingenium)](https://kx.cloudingenium.com/en/ollama-local-llm-run-large-language-models-machine-guide/) 🇬🇧 — commandes `ollama run/pull/list/ps/rm/serve/create`, RAM 7B → 8 Go, 13B → 16 Go, 70B → 64 Go
- [LM Studio — docs](https://www.lmstudio.ai/docs) 🇬🇧 — GUI, moteurs llama.cpp + MLX, serveur local port 1234, CLI `lms`
- [Thunder Compute — LM Studio local LLM](https://www.thundercompute.com/blog/lm-studio-local-llm) 🇬🇧 — guide
- [llama.cpp — discussion performances Apple Silicon #4167](https://github.com/ggml-org/llama.cpp/discussions/4167) 🇬🇧 — tableau tok/s M1 → M5 Ultra (mis à jour 25 août 2026)
- [vLLM — quickstart](https://docs.vllm.ai/en/latest/getting_started/quickstart/) 🇬🇧 — `uv pip install vllm`, `vllm serve`, port 8000 ; CUDA, ROCm, TPU, Ascend
- [text-generation-webui (TextGen)](https://github.com/oobabooga/text-generation-webui) 🇬🇧 — interface Gradio multi-backends, AGPL-3.0
- [Jan](https://jan.ai) 🇬🇧 — application de bureau hors ligne, Apache 2.0
- [janhq/jan (GitHub)](https://github.com/janhq/jan) 🇬🇧
- [GPT4All 3.0 (actualité)](https://alternativeto.net/news/2024/7/nomic-releases-gpt4all-3-0-its-open-source-local-llm-desktop-app-with-new-redesign-and-more) 🇬🇧 — LocalDocs (RAG local)
- [Apple — Exploring LLMs with MLX and the M5](https://machinelearning.apple.com/research/exploring-llms-mlx-m5) 🇬🇧 — tailles mesurées (Qwen3-8B 4 bits = 5,61 Go), TTFT ×4 sur M5 (19 nov. 2025)
- [Open WebUI — quick start](https://docs.openwebui.com/getting-started/quick-start/) 🇬🇧 — `docker run … ghcr.io/open-webui/open-webui:main`, port 8080
- [Thomas-Krenn — installation Open WebUI avec Ollama](https://www.thomas-krenn.com/en/wiki/Installation_of_Open_WebUI_with_Ollama) 🇬🇧
- [LocalAI](https://localai.io) 🇬🇧 — « OpenAI drop-in » auto-hébergé (LLM, images, audio, embeddings), MIT
- [PromptQuorum — LocalAI explained](https://www.promptquorum.com/power-local-llm/localai-explained) 🇬🇧
- [KoboldCpp — wiki](https://github.com/LostRuins/koboldcpp/wiki) 🇬🇧 — exécutable unique, API OpenAI + Kobold, image/voix (SD, Whisper, TTS)
- [exo (exo labs)](https://github.com/exo-explore/exo) 🇬🇧 — cluster d'inférence sur appareils hétérogènes, GPL v3 (peu actif)
- [Unsloth — docs](https://unsloth.ai/docs) 🇬🇧 — Unsloth Studio/Desktop : exécuter et fine-tuner 500+ modèles ; « 2× plus rapide, 70 % de VRAM en moins »
- [unslothai/unsloth (GitHub)](https://github.com/unslothai/unsloth) 🇬🇧 — cité
- [Axolotl — intégration Unsloth](https://docs.axolotl.ai/docs/unsloth.html) 🇬🇧
- [Pinggy — Best Local LLM Tools and Models in 2026](https://pinggy.io/blog/top_5_local_llm_tools_and_models/) 🇬🇧 — synthèse outils + « quel modèle pour quelle mémoire » (5 oct. 2026)
- [Bestllmfor — benchmarks](https://bestllmfor.com/benchmarks/) 🇬🇧 — tests de modèles 8-12B sur du français ; mesures Gigabyte AI TOP ATOM (CC BY 4.0)

---

## 10. Matériel : dimensionnement, GPU, Mac, DGX Spark, cloud GPU
- [Flavio Copes — LLM VRAM requirements](https://flaviocopes.com/llm-vram-requirements/) 🇬🇧 — formule mémoire ≈ paramètres × bits ÷ 8 × 1,1, KV cache, 90 % VRAM / 70-75 % mémoire unifiée
- [InventiveHQ — LLM VRAM calculator](https://inventivehq.com/tools/llm-vram-calculator) 🇬🇧 — calculateur en ligne
- [Presenc — Local LLM tokens per second benchmarks 2026](https://presenc.ai/research/local-llm-tokens-per-second-benchmarks-2026) 🇬🇧 — Mac Studio M5 Max/Ultra
- [Presenc — RTX 5090 local LLM benchmarks 2026](https://presenc.ai/research/rtx-5090-local-llm-benchmarks-2026) 🇬🇧 — 145 tok/s sur 8B Q4 ; gpt-oss-20b 205 tok/s
- [Presenc — AMD Strix Halo local LLM benchmarks 2026](https://presenc.ai/research/amd-strix-halo-local-llm-benchmarks-2026) 🇬🇧 — Ryzen AI Max+ 395 128 Go ; machines Framework, GMKtec, Minisforum, Beelink, HP
- [AMD — Ryzen AI Max+ 395, a leap forward in generative AI performance](https://www.amd.com/en/developer/resources/technical-articles/2025/amd-ryzen-ai-max-395--a-leap-forward-in-generative-ai-performanc.html) 🇬🇧
- [FormulaMod — Which NVIDIA GPU for local AI in 2026](https://www.formulamod.net/blogs/new/which-nvidia-gpu-for-local-ai-in-2026-rtx-3090-vs-4060-ti-vs-4070-ti-super-vs-4090-vs-5090) 🇬🇧 — llama-bench Q4_K_XL 16K (avril 2026)
- [Ajit Singh — LLM inference speed comparison (RTX 3060)](https://singhajit.com/llm-inference-speed-comparison/) 🇬🇧 — avril 2026
- [Corelab — VRAM tier list GPU](https://corelab.tech/llmgpu/) 🇬🇧 — prix indicatifs
- [ComputingForGeeks — best GPU for LLM](https://computingforgeeks.com/best-gpu-for-llm/) 🇬🇧
- [IntuitionLabs — NVIDIA DGX Spark review](https://intuitionlabs.ai/articles/nvidia-dgx-spark-review) 🇬🇧 — GB10, 128 Go, 273 Go/s ; prix 3 999 → 4 699 → ~6 950 $ (15 oct. 2026)
- [ServeTheHome — NVIDIA DGX Spark review (p. 3)](https://www.servethehome.com/nvidia-dgx-spark-review-the-gb10-machine-is-so-freaking-cool/3/) 🇬🇧
- [Spheron — DGX Spark vs RTX 5090 tokens per second 2026](https://www.spheron.network/blog/dgx-spark-vs-rtx-5090-for-local-llms-tokens-per-second-2026/) 🇬🇧 — gpt-oss-120b 60,6 → 40,5 tok/s ; vLLM batching 289-313 tok/s agrégés
- [Kaitchup — DGX Spark: use it for fine-tuning](https://kaitchup.substack.com/p/dgx-spark-use-it-for-fine-tuning) 🇬🇧 — conseil < 8B pour un confort réel
- [Spheron — GPU cloud pricing RunPod vs Vast.ai 2026](https://www.spheron.network/blog/gpu-cloud-pricing-comparison-runpod-vs-vastai-2026/) 🇬🇧 — RTX 4090 0,34 $/h, H100 1,49-2,99 $/h (11 août 2026)
- [CloudZero — cloud GPU pricing comparison](https://www.cloudzero.com/blog/cloud-gpu-pricing-comparison/) 🇬🇧 — médianes H100 4,19 $ (dédiés) vs 7,89 $ (hyperscalers) (4 sept. 2026)
- [Scaleway — tarifs GPU](https://www.scaleway.com/en/pricing/gpu) 🇫🇷 — H100 PCIe 2,73 €/h, L40S 1,40 €/h, L4 0,75 €/h (HT)
- [OVHcloud — grille Public Cloud](https://ovhcloud.com/en/public-cloud/prices) 🇫🇷 — H100 2,80 €/h
- [Spheron — OVHcloud GPU pricing 2026 and sovereign AI](https://www.spheron.network/blog/ovhcloud-gpu-pricing-2026-h100-cost-and-sovereign-ai/) 🇬🇧 — 27 juil. 2026
- [Daily Dose of DS — speculative decoding](https://www.dailydoseofds.com/p/speculative-decoding-in-llms/) 🇬🇧 — gain typique 2-3×
- [BoringBot — KV caching and speculative decoding](https://boringbot.substack.com/p/kv-caching-and-speculative-decoding) 🇬🇧

---

## 11. Modèles à poids ouverts (fiches et classements)
- [Qwen3.8-27B (HF)](https://huggingface.co/Qwen/Qwen3.8-27B) 🇬🇧 — dense, vision, Apache 2.0, 262K → 1M ; « meilleur rapport qualité/Go » (août 2026)
- [Qwen3.8 — blog](https://qwen.ai/blog?id=qwen3.8) 🇬🇧 — cité par la model card
- [Qwen3.8-Flash-Next (HF)](https://huggingface.co/Qwen/Qwen3.8-Flash-Next) 🇬🇧 — 125B / 6B actifs (cité)
- [Qwen3.8-2.4T-A95B « Qwen3.8-Max » (HF)](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B) 🇬🇧 — cité
- [Morph — best open-source LLM](https://www.morphllm.com/best-open-source-llm) 🇬🇧 — tableau comparatif (26 oct. 2026)
- [Morph — gpt-oss](https://www.morphllm.com/gpt-oss) 🇬🇧 — gpt-oss-20b / 120b, Apache 2.0, MXFP4
- [DataNorth — IBM releases Granite 4.2](https://datanorth.ai/news/ibm-releases-granite-4-2) 🇬🇧 — 25 août 2026, Apache 2.0
- [IBM Research — Introducing Granite 4.2](https://research.ibm.com/blog/introducing-granite-4-2) 🇬🇧 — cité
- [Phi-4-mini-instruct (HF)](https://huggingface.co/microsoft/Phi-4-mini-instruct) 🇬🇧 — cité, MIT
- [Phi-4-reasoning (HF)](https://huggingface.co/microsoft/Phi-4-reasoning) 🇬🇧 — cité
- [Wikipédia — Phi (language model)](https://en.wikipedia.org/wiki/Phi_%28language_model%29) 🇬🇧 — Phi-4-reasoning-vision-15B (mars 2026)
- [Wikipédia — Llama (language model)](https://en.wikipedia.org/wiki/Llama_%28language_model%29) 🇬🇧 — Llama 4 Scout/Maverick, licence communautaire non OSI, supplanté par Muse
- [Llama 4 Scout 17B-16E (HF)](https://huggingface.co/meta-llama/Llama-4-Scout-17B-16E) 🇬🇧 — cité
- [The New Stack — Meta Muse Spark Open](https://thenewstack.io/meta-muse-spark-open/) 🇬🇧 — 816B / 42B actifs, « Muse Model License » (15 oct. 2026)
- [Muse Spark Open 816B-A42B (HF)](https://huggingface.co/meta-models/Muse-Spark-Open-816B-A42B) 🇬🇧 — cité
- [DeepSeek-R1 (HF)](https://huggingface.co/deepseek-ai/DeepSeek-R1) 🇬🇧 — cité ; distillats 1,5B-70B, MIT
- [DeepSeek-V4-Pro (HF)](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro) 🇬🇧 — cité
- [DeepSeek-V4.1-Flash (HF)](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash) 🇬🇧 — cité
- [LLM Reference — DeepSeek V4.1 Flash](https://www.llmreference.com/model/deepseek-v4.1-flash) 🇬🇧 — 552B, MIT, Terminal-Bench 2.1 = 90,6 (sept.-oct. 2026)
- [LLM Reference — GLM-5.3-Flash](https://www.llmreference.com/model/glm-5.3-flash/z-ai) 🇬🇧 — 320B / 18B actifs, MIT (26 août 2026)
- [GLM-5.3-Flash (HF)](https://huggingface.co/zai-org/GLM-5.3-Flash) 🇬🇧 — cité
- [Artificial Analysis — GLM-5.2 leading open weights model](https://artificialanalysis.ai/articles/glm-5-2-is-the-new-leading-open-weights-model-on-the-artificial-analysis-intelligence-index) 🇬🇧 — 16 juin 2026
- [Artificial Analysis — recent open weights model launches](https://www.artificialanalysis.ai/articles/recent-open-weights-model-launches) 🇬🇧 — 30 avr. 2026
- [Artificial Analysis — leaderboard models](https://artificialanalysis.ai/leaderboards/models) 🇬🇧 — index v5 (27 oct. 2026 ; cité)
- [NYU Shanghai RITS — Kimi K3 open weights ship](https://rits.shanghai.nyu.edu/ai/kimi-k3-open-weights-ship-2-8t-parameters-1-4-tb-to-run/) 🇬🇧 — 2,8T / 104B actifs, 1,4 To (juil. 2026)
- [PureAI — Moonshot AI releases Kimi K3](https://pureai.com/articles/2026/07/17/china-moonshot-ai-releases-kimi-k3.aspx) 🇬🇧 — 17 juil. 2026
- [Kimi-K3 (HF)](https://huggingface.co/moonshotai/Kimi-K3) 🇬🇧 — cité
- [Kimi-K2.7-Code (HF)](https://huggingface.co/moonshotai/Kimi-K2.7-Code) 🇬🇧 — cité
- [Kimi-K2.6 (HF)](https://huggingface.co/moonshotai/Kimi-K2.6) 🇬🇧 — cité
- [Let's Data Science — Kimi K3.1 Pro](https://letsdatascience.com/news/moonshot-releases-kimi-k31-pro-api-open-weights-due-nov-4-786e160c) 🇬🇧 — poids annoncés pour le 4 nov. 2026
- [NVIDIA Nemotron 3 Ultra 550B-A55B (HF)](https://huggingface.co/nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-BF16) 🇬🇧 — cité, OpenMDW-1.1
- [Swfte — relevé LMArena](https://www.swfte.com/lmarena) 🇬🇧 — Elo au 31 oct. 2026 (Mythos 5 1531 ; Kimi K3 1500 meilleur ouvert)
- [Ainauten — HF Open LLM Leaderboard v3](https://news.ainauten.com/en/story/huggingface-open-llm-leaderboard-v3) 🇬🇧 — refonte annoncée le 12 janv. 2026

---

## 12. Frameworks, agents, protocoles, agents de code
### 12.1 Frameworks d'applications LLM et d'agents
- [LangChain — changelog (Python)](https://docs.langchain.com/oss/python/releases/changelog.md) 🇬🇧 — langchain 1.4.6, langchain-core 1.7.0, LangGraph 1.2.0 (oct. 2026)
- [itsourcecode — LangChain vs LlamaIndex](https://itsourcecode.com/?p=153165) 🇬🇧 — comparatif
- [Atlan — Microsoft Agent Framework](https://atlan.com/know/ai-agent/microsoft/agent-framework/) 🇬🇧 — v1.0 GA le 3 avril 2026, successeur de Semantic Kernel et AutoGen
- [microsoft/agent-framework (GitHub)](https://github.com/microsoft/agent-framework) 🇬🇧 — cité
- [Semantic Kernel — overview](https://learn.microsoft.com/en-us/semantic-kernel/overview/) 🇬🇧 — cité
- [Composio — Claude Agent SDK vs OpenAI Agents SDK vs Google ADK](https://composio.dev/blog/claude-agents-sdk-vs-openai-agents-sdk-vs-google-adk) 🇬🇧 — comparatif (`max_budget_usd`, handoffs, A2A natif)
- [Future AGI — Dify vs Flowise vs Langflow 2026](https://futureagi.com/blog/dify-vs-flowise-vs-langflow-2026/) 🇬🇧
- [KDnuggets — best no-code LLM app builders](https://www.kdnuggets.com/best-no-code-llm-app-builders) 🇬🇧
- [langgenius/dify](https://github.com/langgenius/dify) 🇬🇧 — cité ; ~140k étoiles, Dify OSS License
- [FlowiseAI/Flowise](https://github.com/FlowiseAI/Flowise) 🇬🇧 — cité ; Apache 2.0
- [langflow-ai/langflow](https://github.com/langflow-ai/langflow) 🇬🇧 — cité ; MIT, export en serveur MCP

### 12.2 MCP et A2A
- [MCP — release candidate 2026-07-28-RC (GitHub)](https://github.com/modelcontextprotocol/modelcontextprotocol/releases/tag/2026-07-28-RC) 🇬🇧 — publiée le 29 mai 2026
- [MCP — historique des versions de la spécification](https://releases.sh/modelcontextprotocol/mcp-specification.md) 🇬🇧 — 2024-11-05 → 2025-11-25 → 2026-07-28
- [MCP — spécification (site officiel)](https://modelcontextprotocol.io/specification) 🇬🇧 — cité
- [MCP — introduction](https://modelcontextprotocol.io/introduction) 🇬🇧 — cité par la doc Anthropic
- [MCP — spécification 2025-11-25, authorization](https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization) 🇬🇧 — cité
- [MCP — spécification draft](https://modelcontextprotocol.io/specification/draft) 🇬🇧 — cité
- [MCP — changelog draft](https://modelcontextprotocol.io/specification/draft/changelog) 🇬🇧 — cité
- [MCP — concepts : tools](https://modelcontextprotocol.io/docs/concepts/tools) 🇬🇧 — cité
- [MCP — SDK TypeScript officiel](https://github.com/modelcontextprotocol/typescript-sdk) 🇬🇧 — cité
- [MCP — dépôts de l'organisation](https://github.com/orgs/modelcontextprotocol/repositories) 🇬🇧 — SDK, serveurs de référence, registry
- [dSebastien — MCP Registry](https://www.dsebastien.net/model-context-protocol-registry/) 🇬🇧 — registre (sept. 2025)
- [Blog MCP](https://blog.modelcontextprotocol.io/) 🇬🇧 — résultat de recherche
- [Linux Foundation — A2A protocol surpasses 150 organizations](https://www.linuxfoundation.org/press/a2a-protocol-surpasses-150-organizations-lands-in-major-cloud-platforms-and-sees-enterprise-production-use-in-first-year) 🇬🇧 — v1.0, 9 avril 2026
- [Google Open Source — a year of A2A](https://opensource.googleblog.com/2026/04/a-year-of-open-collaboration-celebrating-the-anniversary-of-a2a.html) 🇬🇧
- [A2A — site](https://a2a-protocol.org/) 🇬🇧 — cité
- [Cloudmagazin — A2A 1.2 in production](https://www.cloudmagazin.com/en/2026/04/25/a2a-protocol-1-2-in-production-what-dach-cloud-architects-need-to-change-in-their-istio-setup-now/) 🇬🇧 — Agent Cards signées (DID), 25 avr. 2026
- [Agent Skills — standard ouvert](https://agentskills.io) 🇬🇧 — cité
- [Parallel — What are Agent Skills](https://parallel.ai/articles/what-are-agent-skills) 🇬🇧 — SKILL.md lu par Claude Code, Codex, Cursor, OpenCode (18 août 2026)
- [MCP — release 2026-07-28 (stable)](https://github.com/modelcontextprotocol/specification/releases/tag/2026-07-28) 🇬🇧 — statut officiel de la spécification (nov. 2026)
- [MCP — changelog 2026-07-28](https://modelcontextprotocol.io/specification/2026-07-28/changelog) 🇬🇧 — liste officielle des changements (sans état, extensions, dépréciations) (nov. 2026, vue dans l'index officiel)

### 12.3 Agents de code et « vibe coding »
- [Firecrawl — best AI coding agents](https://www.firecrawl.dev/blog/best-ai-coding-agents) 🇬🇧 — 3 août 2026
- [Tembo — best AI for coding](https://www.tembo.io/blog/best-ai-for-coding) 🇬🇧 — 21 avr. 2026
- [Cursor](https://www.cursor.com/) 🇬🇧 — Hobby gratuit, Pro 20 $, Ultra 200 $
- [Windsurf](https://windsurf.com/) 🇬🇧 — racheté par Cognition
- [Aider](https://aider.chat/) 🇬🇧 — CLI Git, Apache 2.0
- [Cline](https://cline.bot/) 🇬🇧 — extension VS Code/JetBrains, Apache 2.0
- [GitHub Copilot](https://github.com/features/copilot) 🇬🇧 — Free, Pro 10 $, Business 19 $
- [OpenCode](https://opencode.ai/) 🇬🇧 — TUI/CLI, MIT
- [Devin](https://devin.ai) 🇬🇧 — agent cloud autonome
- [Continue](https://continue.dev) 🇬🇧 — Apache 2.0
- [CTV News — « vibe coding » mot de l'année Collins 2025](https://www.ctvnews.ca/lifestyle/article/vibe-coding-named-word-of-the-year-by-collins-dictionary/) 🇬🇧 — 6 nov. 2025

### 12.4 Bases vectorielles et RAG
- [BigData Boutique — vector database comparison 2026](https://bigdataboutique.com/blog/vector-database-comparison-2026) 🇬🇧 — Qdrant, Weaviate, Pinecone (25 oct. 2026)
- [Alex Cloud Star — vector database comparison 2026](https://alexcloudstar.com/blog/vector-database-comparison-2026/) 🇬🇧 — pgvector
- [GroovyWeb — top 10 AI vector databases 2026](https://www.groovyweb.co/blog/top-10-ai-vector-databases-2026) 🇬🇧 — Milvus
- [arXiv — Retrieval-Augmented Generation (Lewis et al., 2020)](https://arxiv.org/pdf/2005.11401) 🇬🇧 — article fondateur du RAG
- [arXiv — LoRA (Hu et al., 2021)](https://arxiv.org/abs/2106.09685v1) 🇬🇧 — article fondateur de LoRA

---

## 13. Évaluation, benchmarks et observabilité
- [Infrabase — LLM observability tools compared](https://infrabase.ai/blog/llm-observability-tools-compared) 🇬🇧 — LangSmith, Langfuse (racheté par ClickHouse), Braintrust, Phoenix, Helicone, Opik, Weave, MLflow (25 oct. 2026)
- [Braintrust — alternatives à DeepEval](https://www.braintrust.dev) 🇬🇧 — vérifié via article
- [MLflow](https://mlflow.org) 🇬🇧 — `mlflow.genai.evaluate()`, tracing (vérifié via recherche)
- [QA Skills — DeepEval vs Ragas vs promptfoo 2026](https://qaskills.sh/blog/deepeval-vs-ragas-vs-promptfoo-2026) 🇬🇧 — 29 juin 2026
- [QA Skills — promptfoo vs OpenAI Evals](https://qaskills.sh/compare/promptfoo-vs-openai-evals) 🇬🇧
- [promptfoo (GitHub)](https://github.com/promptfoo/promptfoo) 🇬🇧 — cité ; MIT ; tests YAML, red-teaming ; rachat par OpenAI annoncé le 9 mars 2026
- [DeepEval (GitHub)](https://github.com/confident-ai/deepeval) 🇬🇧 — cité ; Apache 2.0 ; métriques G-Eval, Faithfulness
- [Ragas (GitHub)](https://github.com/vibrantlabsai/ragas) 🇬🇧 — cité ; métriques RAG (v0.4.3, janv. 2026)
- [Inspect AI (UK AISI, GitHub)](https://github.com/UKGovernmentBEIS/inspect_ai) 🇬🇧 — cité ; MIT
- [Atlan — LLM benchmarks explained](https://atlan.com/know/llm-benchmarks-explained.md) 🇬🇧 — MMLU, GPQA, SWE-bench, HumanEval, HLE (27 juil. 2026)
- [MMLU (hendrycks/test)](https://github.com/hendrycks/test) 🇬🇧
- [GPQA (idavidrein/gpqa)](https://github.com/idavidrein/gpqa) 🇬🇧
- [HumanEval (openai/human-eval)](https://github.com/openai/human-eval) 🇬🇧
- [τ²-bench (sierra-research/tau2-bench)](https://github.com/sierra-research/tau2-bench) 🇬🇧
- [Humanity's Last Exam](https://agi.safe.ai/) 🇬🇧 — cité
- [AIME — Art of Problem Solving](https://artofproblemsolving.com) 🇬🇧
- [Stanford HAI — AI Index Report 2026](https://hai.stanford.edu/ai-index/2026-ai-index-report) 🇬🇧 — 9 chapitres ; OSWorld 66,3 %, 362 incidents, 285,88 Md$ d'investissement US
- [Stanford HAI — 12 takeaways from the 2026 report](https://hai.stanford.edu/news/inside-the-ai-index-12-takeaways-from-the-2026-report) 🇬🇧 — 13 avril 2026

---

## 14. Sécurité des applications LLM et agents
- [OWASP GenAI Security Project](https://genai.owasp.org/) 🇬🇧 — cité ; Top 10 for LLM Applications 2026 (4 août 2026), Top 10 for Agentic Applications
- [Modulos — OWASP Top 10 for LLM](https://docs.modulos.ai/frameworks/owasp-top-10-llm/index) 🇬🇧 — synthèse de la liste 2026 (LLM01 Prompt Injection → LLM10 Improper Output Handling)
- [Modulos — OWASP Top 10 for Agentic Applications](https://docs.modulos.ai/frameworks/owasp-top-10-agentic/) 🇬🇧 — cité (ASI01-ASI10)
- [Modulos — hub OWASP](https://docs.modulos.ai/frameworks/owasp/) 🇬🇧 — cité
- [Coralogix — OWASP Top 10 for LLM applications (2025)](https://coralogix.com/ai-blog/owasp-top-10-for-llm-applications/) 🇬🇧 — liste 2025 archivée
- [TDS (s-anand) — OWASP LLM Top 10](https://tds.s-anand.net/2026-02/docs/week-7/05-owasp-llm-top-10/) 🇬🇧 — exemple d'injection indirecte (fév. 2026)
- [Serenities AI — Mistral Moderation 2603](https://serenitiesai.com/articles/mistral-ai-models-2026-complete-guide) 🇬🇧 — modèle de modération (mars 2026)
- [OWASP Top 10 for Agentic Applications 2026](https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/) 🇬🇧 — ASI01 à ASI10 (nov. 2026, vue dans l'index officiel)
- [OWASP GenAI LLM Top 10 2026](https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/) 🇬🇧 — LLM01 à LLM10:2026 (nov. 2026, vue dans l'index officiel)

---

## 15. Cours universitaires (MIT, Stanford, Berkeley, CMU, Harvard, 42)

### 15.1 MIT
- [MIT 6.S191 Introduction to Deep Learning (2026)](https://introtodeeplearning.com/) 🇬🇧 — Alexander et Ava Amini ; 9 cours + 3 labs ; licence MIT (conserver le copyright sur les slides)
- [6.S191 — playlist YouTube](https://www.youtube.com/playlist?list=PLtBw6njQRU-rwp5__7C0oIVt26ZgjG9NI) 🇬🇧 — indiquée sur le site
- [6.S191 — vidéo d'introduction](https://www.youtube.com/watch?v=II4giR4vOOo) 🇬🇧
- [MIT 6.036 Introduction to Machine Learning (Fall 2020, OCW live)](https://live.ocw.mit.edu/courses/6-036-introduction-to-machine-learning-fall-2020) 🇬🇧 — CC BY-NC-SA 4.0
- [6.036 — MITx Open Learning Library (exercices autograder)](https://openlearninglibrary.mit.edu/courses/course-v1:MITx+6.036+1T2019/about) 🇬🇧 — 13 semaines × ~12 h ; « All Rights Reserved »
- [Tamara Broderick — vidéos 6.036 Fall 2020](https://tamarabroderick.com/ml.html) 🇬🇧 — liste des 14 vidéos
- [6.036 vidéo 1 — Bases](https://youtu.be/0xaLT4Svzgo) 🇬🇧
- [6.036 vidéo 2 — Perceptrons](https://youtu.be/A3obZhw7Jc4) 🇬🇧
- [6.036 vidéo 3 — Features](https://youtu.be/WZVNvfMdk-E) 🇬🇧
- [6.036 vidéo 4 — Régression logistique](https://youtu.be/abB3fwfPy14) 🇬🇧
- [6.036 vidéo 5 — Régression](https://youtu.be/OpvrwhWEUmY) 🇬🇧
- [6.036 vidéo 6 — Réseaux de neurones](https://youtu.be/N0uGnAfXUes) 🇬🇧
- [6.036 vidéo 7](https://youtu.be/QJY342H8LOo) 🇬🇧
- [6.036 vidéo 8 — Réseaux convolutifs](https://youtu.be/sFEZ180RvTI) 🇬🇧
- [6.036 vidéo 9 — Machines à états et MDP](https://youtu.be/O5hkIfUR_uA) 🇬🇧
- [6.036 vidéo 10 — Apprentissage par renforcement](https://youtu.be/Ir93m9OmOHo) 🇬🇧
- [6.036 vidéo 11 — Réseaux récurrents](https://youtu.be/JZ0WVuk4mt8) 🇬🇧
- [6.036 vidéo 12 — Arbres et forêts aléatoires](https://youtu.be/ZOiBe-nrmc4) 🇬🇧
- [6.036 vidéo 13 — Clustering](https://youtu.be/BaZWcSq3IuI) 🇬🇧
- [6.036 vidéo 14 — Conférence invitée (David Sontag)](https://youtu.be/kZWPuZV9Qkc) 🇬🇧
- [MIT 6.390 IntroML — Fall 2026 (info)](https://introml.mit.edu/fall26/info) 🇬🇧 — CC BY-NC-SA 4.0 ; prérequis Python intermédiaire, algèbre linéaire
- [MIT 6.390 — accueil Fall 2026](https://introml.mit.edu/fall26) 🇬🇧
- [MIT 6.034 Artificial Intelligence (Fall 2010) — syllabus](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/pages/syllabus/) 🇬🇧 — Patrick Winston ; 23 lectures + 7 méga-récitations
- [6.034 — Lecture 1 : Introduction and Scope](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-1-introduction-and-scope) 🇬🇧
- [Class Central — MIT 6.034 (liste des lectures)](https://www.classcentral.com/course/mit-opencourseware-artificial-intelligence-fall-2010-40938) 🇬🇧
- [MIT 18.06 Linear Algebra (Strang) — vidéos](https://www.ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/video_galleries/video-lectures) 🇬🇧 — 35 vidéos
- [MIT 6.7960 Deep Learning (Fall 2024)](https://live.ocw.mit.edu/courses/6-7960-deep-learning-fall-2024/) 🇬🇧 — Isola, Beery, Bernstein
- [MIT 6.S087 Foundation Models and Generative AI (IAP 2024)](https://ocw.mit.edu/courses/6-s087-foundation-models-and-generative-ai-january-iap-2024/) 🇬🇧 — non technique
- [MIT RES.6-013 AI 101 (Fall 2021)](https://ocw.mit.edu/courses/res-6-013-ai-101-fall-2021/) 🇬🇧 — atelier grand public
- [MIT Open Learning — 13 foundational AI courses](https://openlearning.mit.edu/news/13-foundational-ai-courses-resources-mit) 🇬🇧
- [MIT Open Learning — How MIT teaches and learns AI](https://openlearning.mit.edu/news/how-mit-teaches-and-learns-ai) 🇬🇧 — MIT Learn, AskTIM, Day of AI
- [MIT xPRO — Driving Innovation with Generative AI](https://xpro.mit.edu/courses/course-v1:xPRO+GenAI/) 🇬🇧 — cité
- [MIT OCW — Terms (licence)](https://ocw.mit.edu/terms) 🇬🇧 — CC BY-NC-SA 4.0
- [MIT OCW — Privacy and terms of use](https://ocw.mit.edu/pages/privacy-and-terms-of-use/) 🇬🇧 — interdiction des cours payants basés sur OCW

### 15.2 Stanford
- [CS229 Machine Learning (Summer 2026)](https://cs229.stanford.edu/) 🇬🇧 — Amjad, Avati
- [CS229 — Winter 2026](https://cs229.stanford.edu/index.html-win26) 🇬🇧 — Fox, Koyejo
- [CS229 — syllabus Fall 2022 (notes PDF)](https://cs229.stanford.edu/syllabus-fall2022.html) 🇬🇧
- [CS224N NLP with Deep Learning — Winter 2024](https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1244/) 🇬🇧 — 19 lectures (word vectors → transformers → RLHF → déploiement)
- [CS224N — slides lecture 1 Winter 2026](https://web.stanford.edu/class/cs224n/slides_w26/cs224n-2026-lecture01-intro.pdf) 🇬🇧 — Diyi Yang, Yejin Choi
- [CS224N — playlist YouTube 2023](https://www.youtube.com/playlist?list=PLoROMvodv4rMFqRtEuo6SGjY4XbRIVRd4) 🇬🇧
- [CS231n Deep Learning for Computer Vision — Spring 2026](https://cs231n.stanford.edu/schedule.html) 🇬🇧 — 18 lectures
- [Stanford CRFM — courses (CS324)](https://crfm.stanford.edu/courses.html) 🇬🇧 — Liang, Hashimoto, Ré
- [CS324 — site Winter 2022](https://stanford-cs324.github.io/winter2022/) 🇬🇧 — cité (non ouvert)
- [CS25 Transformers United V6 (Spring 2026)](https://web.stanford.edu/class/cs25/index.html) 🇬🇧 — séminaire ouvert à tous
- [CS25 — enregistrements](https://web.stanford.edu/class/cs25/recordings) 🇬🇧
- [CS25 — playlist YouTube](https://www.youtube.com/playlist?list=PLoROMvodv4rNiJRchCzutFw5ItR_Z27CM) 🇬🇧
- [CS336 Language Modeling from Scratch (Spring 2026)](https://cs336.stanford.edu/) 🇬🇧 — Hashimoto, Liang ; 19 séances, 5 devoirs
- [stanford-cs336 (GitHub)](https://github.com/stanford-cs336) 🇬🇧 — devoirs 1-4 sous licence MIT
- [stanford-cs336/lectures](https://github.com/stanford-cs336/lectures) 🇬🇧 — supports lecture_01 à 17
- [CS336 — playlist YouTube (Stanford Online)](https://www.youtube.com/watch?v=JuoVZkPBiKk&list=PLoROMvodv4rMqXOcazWaTUHhq-yembLCV) 🇬🇧 — 18 vidéos
- [CS221 AI: Principles and Techniques (Spring 2018)](https://web.stanford.edu/class/archive/cs/cs221/cs221.1186/index.html) 🇬🇧
- [Hackr — Stanford AI Professional Program](https://hackr.io/blog/stanford-ai-professional-program) 🇬🇧 — 1 750 $ par cours, certificat après 3 cours (source secondaire)
- [Stanford — page d'inscription AI Professional Program](https://learn.stanford.edu/LP-Hackr-AI-2024.html) 🇬🇧 — cité
- [Stanford SEE — Using SEE (licence)](https://see.stanford.edu/UsingSEE) 🇬🇧 — CC BY-NC-SA, pas d'accréditation de programmes tiers

### 15.3 Berkeley, CMU, Harvard
- [UC Berkeley CS188 — portail](https://inst.eecs.berkeley.edu/~cs188/) 🇬🇧
- [CS188 Spring 2026](https://inst.eecs.berkeley.edu/~cs188/sp26/) 🇬🇧 — Klein, Russell ; 28 lectures (search → LLMs → AI Safety)
- [CS188 Fall 2025](https://inst.eecs.berkeley.edu/~cs188/fa25) 🇬🇧 — Pierson, Kao
- [CS188 Spring 2026 — playlist YouTube](https://www.youtube.com/playlist?list=PLp8QV47qJEg5tSxKiwcZt4LVwN_ek2Kxy) 🇬🇧
- [CS188 Fall 2025 — playlist YouTube](https://www.youtube.com/playlist?list=PLp8QV47qJEg614q1L8avhmWQPyIR5QOWq) 🇬🇧
- [CMU 11-785 Introduction to Deep Learning — Spring 2025](https://deeplearning.cs.cmu.edu/S25/index.html) 🇬🇧 — Raj, Singh ; 28 lectures
- [CMU 11-785 — Fall 2025](https://deeplearning.cs.cmu.edu/F25/index.html) 🇬🇧
- [CMU 11-785 — Spring 2026](https://deeplearning.cs.cmu.edu/S26/index.html) 🇬🇧 — cité
- [CMU 11-785 — chaîne YouTube](https://www.youtube.com/channel/UC8hYZGEkI2dDO8scT8C5UQA) 🇬🇧
- [CMU 11-785 — livre IDL (Rita Singh)](http://mlsp.cs.cmu.edu/people/rsingh/IDLbook.html) 🇬🇧
- [csdiy.wiki — CMU 11-785](https://csdiy.wiki/en/%E6%B7%B1%E5%BA%A6%E5%AD%A6%E4%B9%A0/CMU11-785/) 🇬🇧 — fiche
- [CMU 11-667 LLMs: Methods and Applications](https://cmu-llms.org/) 🇬🇧 — cité
- [CMU 11-667 — devoirs](https://cmu-llms.org/assignments/) 🇬🇧 — cité
- [csdiy.wiki — CMU 11-667](https://csdiy.wiki/en/%E6%B7%B1%E5%BA%A6%E7%94%9F%E6%88%90%E6%A8%A1%E5%9E%8B/%E5%A4%A7%E8%AF%AD%E8%A8%80%E6%A8%A1%E5%9E%8B/CMU11-667/) 🇬🇧 — fiche
- [Harvard CS50's Introduction to AI with Python](https://pll.harvard.edu/course/cs50s-introduction-artificial-intelligence-Python) 🇬🇧 — Malan, Yu ; 7 semaines ; certificat 299 $
- [CS50 AI — edX](https://www.edx.org/course/cs50s-introduction-to-artificial-intelligence-with-python) 🇬🇧 — cité
- [CS50 AI — lectures (Extension, Fall 2024)](https://cs50.harvard.edu/extension/ai/2024/fall/lectures) 🇬🇧
- [CS50 AI — projets (Extension, Fall 2022)](https://cs50.harvard.edu/extension/ai/2022/fall/projects) 🇬🇧
- [freeCodeCamp — Harvard CS50 AI course](https://www.freecodecamp.org/news/harvard-cs50s-ai-python-course/) 🇬🇧
- [CS50 AI — vidéo complète 12 h (YouTube)](https://youtu.be/5NgNicANyqM) 🇬🇧 — cité
- [Harvard CS50x 2025 — semaines](https://cs50.harvard.edu/x/2025/weeks) 🇬🇧 — 11 semaines (Scratch → Flask)

### 15.4 École 42 et 42 AI
- [jmcheon/42cursus — branche Algo, AI, data](https://github.com/jmcheon/42cursus) 🇬🇧 — liste des projets (ft_linear_regression, dslr, Leaffliction, Multilayer_Perceptron, Total_perspective_vortex…)
- [Piscine Python for Data Science (dépôt étudiant)](https://github.com/Atroooo/Piscine_DataScience) 🇬🇧 — modules 00-04 + journées datascience
- [ft_linear_regression (dépôt étudiant)](https://github.com/madvid/42_ft_linear_regression) 🇬🇧 — régression linéaire from scratch
- [DSLR — Datascience X Logistic Regression (dépôt étudiant)](https://github.com/madvid/42_DSLR) 🇬🇧 — régression logistique one-vs-all
- [multilayer-perceptron (dépôt étudiant)](https://github.com/agiordan101/multilayer_perceptron_42) 🇬🇧 — MLP from scratch (Wisconsin Breast Cancer)
- [Learn2Slither (dépôt étudiant)](https://github.com/Sleleu/Learn2slither) 🇬🇧 — Q-learning / DQN
- [Leaffliction (dépôt étudiant)](https://github.com/jainavas/leaffliction) 🇬🇧 — CNN maladies de feuilles
- [Total-Perspective-Vortex (dépôt étudiant)](https://github.com/GaetanMo/Total_perspective_vortex) 🇬🇧 — EEG, CSP, scikit-learn
- [42 AI — organisation GitHub](https://github.com/42-ai) 🇬🇧 — association étudiante 42 Paris
- [42 AI — site](http://www.42ai.fr) 🇫🇷
- [42-AI/bootcamp_python](https://github.com/42-AI/bootcamp_python) 🇬🇧 — cité (miroir lu : https://gh.mise.run.place/42-AI/bootcamp_python)
- [42-AI/bootcamp_machine-learning](https://github.com/42-AI/bootcamp_machine-learning) 🇬🇧 — modules 05-09 (régression, logistique, régularisation)

---

## 16. MOOC, cours ouverts, vidéos et livres

### 16.1 DeepLearning.AI
- [Short courses — catalogue](https://www.deeplearning.ai/short-courses/) 🇬🇧 — gratuits, 1-2 h
- [DeepLearning.AI — index llms.txt](https://www.deeplearning.ai/llms.txt) 🇬🇧
- [Building toward Computer Use with Anthropic](https://learn.deeplearning.ai/courses/building-toward-computer-use-with-anthropic/lesson/1/introduction) 🇬🇧 — Colt Steele, 1 h 44
- [MCP: Build Rich-Context AI Apps with Anthropic](https://deeplearning.ai/short-courses/mcp-build-rich-context-ai-apps-with-anthropic) 🇬🇧 — Elie Schoppik, 1 h 58
- [Claude Code: A Highly Agentic Coding Assistant](https://deeplearning.ai/short-courses/claude-code-a-highly-agentic-coding-assistant) 🇬🇧 — 2 h
- [Agent Skills with Anthropic](https://www.deeplearning.ai/courses/agent-skills-with-anthropic) 🇬🇧 — 2 h 19
- [ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) 🇬🇧 — Fulford, Ng, 1 h 40
- [Building Systems with the ChatGPT API](https://deeplearning.ai/short-courses/building-systems-with-chatgpt/) 🇬🇧 — 1 h 55
- [Reasoning with o1](https://www.deeplearning.ai/courses/reasoning-with-o1) 🇬🇧 — cité
- [Collaborative Writing and Coding with OpenAI Canvas](https://www.deeplearning.ai/courses/collaborative-writing-and-coding-with-openai-canvas) 🇬🇧 — cité
- [LangChain for LLM Application Development](https://www.deeplearning.ai/short-courses/langchain-for-llm-application-development/) 🇬🇧 — Chase, Ng, 1 h 53
- [Generative AI with LLMs (AWS)](https://www.deeplearning.ai/courses/generative-ai-with-llms/) 🇬🇧 — 13 h 18
- [Machine Learning Specialization](https://deeplearning.ai/courses/machine-learning-specialization) 🇬🇧 — Andrew Ng, 3 cours, ~95 h, audit gratuit
- [Deep Learning Specialization](https://www.deeplearning.ai/deep-learning-specialization/) 🇬🇧 — 5 cours, ~16 semaines
- [Deep Learning Specialization — fiche](https://www.deeplearning.ai/alpha/courses/deep-learning-specialization) 🇬🇧
- [AI For Everyone](https://www.deeplearning.ai/courses/ai-for-everyone) 🇬🇧 — ~7 h, débutant
- [Analytics Vidhya — free GenAI short courses by DeepLearning.AI](https://www.analyticsvidhya.com/blog/2024/05/free-generative-ai-short-courses-by-deeplearning-ai/) 🇬🇧 — fiches des cours Hugging Face

### 16.2 IBM, Microsoft, Elements of AI, autres
- [IBM AI Engineering Professional Certificate — Coursera](https://www.coursera.org/professional-certificates/ai-engineer) 🇬🇧 — 13 cours, ~168 h, intermédiaire
- [IBM AI Foundations for Everyone — Coursera](https://www.coursera.org/specializations/ai-foundations-for-everyone) 🇬🇧 — 4 cours, cité
- [Microsoft — Generative AI for Beginners (GitHub)](https://github.com/microsoft/generative-ai-for-beginners) 🇬🇧 — v3, 21 leçons, **licence MIT** (réutilisable)
- [Generative AI for Beginners — site](https://microsoft.github.io/generative-ai-for-beginners/) 🇬🇧 — cité
- [SourcePulse — fiche generative-ai-for-beginners](https://www.sourcepulse.org/projects/851024) 🇬🇧 — confirmation de la licence MIT
- [Microsoft — AI for Beginners (GitHub)](https://github.com/microsoft/ai-for-beginners) 🇬🇧 — 12 semaines, 24 leçons, MIT
- [i-programmer — Microsoft ML for Beginners](https://www.i-programmer.info/news/150-training-a-education/14802-microsofts-machine-learning-for-beginners.html) 🇬🇧 — plan des 26 leçons
- [Elements of AI](https://www.elementsofai.com/) 🇬🇧 — cité ; 23 langues dont le français
- [UE Digital Skills & Jobs — fiche Elements of AI](https://digital-skills-jobs.europa.eu/en/learning-space/training-catalogue/elements-ai) 🇬🇧 — gratuit, 6 chapitres, ~4 semaines
- [Sorbonne Université — lancement de la version française d'Elements of AI](https://lettres.sorbonne-universite.fr/en/news/french-version-elements-ai-platform-launched) 🇬🇧 — 30-60 h
- [Full Stack Deep Learning — course 2022](https://fullstackdeeplearning.com/course/) 🇬🇧 — 9 lectures + labs (tooling, testing, deployment, monitoring)
- [FSDL — course 2022 (pages)](https://fullstackdeeplearning.com/course/2022/) 🇬🇧 — cité
- [FSDL — LLM Bootcamp Spring 2023](https://fullstackdeeplearning.com/llm-bootcamp/spring-2023/) 🇬🇧 — prompt engineering, LLMOps, UX, augmented LMs
- [fast.ai — Practical Deep Learning for Coders](https://course.fast.ai/) 🇬🇧 — Jeremy Howard ; Part 1 (9 leçons) + Part 2 (Stable Diffusion)
- [fast.ai — annonce du cours 2022](https://www.fast.ai/posts/2022-07-21-dl-coders-22.html) 🇬🇧
- [fast.ai — playlist YouTube](https://www.youtube.com/playlist?list=PLfYUBJiXbdtSvpQjSnJJ_PmDQB_VyT5iU) 🇬🇧 — cité
- [fastai/course22 (GitHub)](https://github.com/fastai/course22) 🇬🇧 — cité
- [fastai/fastbook (GitHub)](https://github.com/fastai/fastbook/) 🇬🇧 — cité (licence propre « usage personnel »)
- [beri.net — Kaggle Learn](https://www.beri.net/learning/kaggle-learn) 🇬🇧 — fiche des 17 micro-cours
- [Blog du Modérateur — IA : formations gratuites](https://www.blogdumoderateur.com/ia-formations-gratuites/) 🇫🇷 — OpenAI Academy, Anthropic Academy, HF, Elements of AI, Objectif IA, MOOC Dejoux (17 mars 2026)

### 16.3 Vidéos de référence (Karpathy, 3Blue1Brown)
- [Andrej Karpathy — Neural Networks: Zero to Hero](https://karpathy.ai/zero-to-hero.html) 🇬🇧 — 8 vidéos (~14 h)
- [1. building micrograd](https://youtu.be/VMj-3S1tku0) 🇬🇧 — 2 h 25
- [2. building makemore](https://youtu.be/PaCmpygFfXo) 🇬🇧 — 1 h 57
- [3. makemore Part 2: MLP](https://youtu.be/TCH_1BHY58I) 🇬🇧
- [4. makemore Part 3: Activations & Gradients, BatchNorm](https://youtu.be/P6sfmUTpUmc) 🇬🇧
- [5. makemore Part 4: Becoming a Backprop Ninja](https://youtu.be/q8SA3rM6ckI) 🇬🇧
- [6. makemore Part 5: Building a WaveNet](https://youtu.be/t3YJ5hKiMQ0) 🇬🇧
- [7. Let's build GPT: from scratch, in code, spelled out](https://www.youtube.com/watch?v=kCc8FmEb1nY) 🇬🇧 — 1 h 56
- [8. Let's build the GPT Tokenizer](https://youtu.be/zduSFxRajkE) 🇬🇧 — 2 h 13
- [Karpathy — [1hr Talk] Intro to Large Language Models](https://www.youtube.com/watch?v=zjkBMFhNj_g) 🇬🇧 — cité
- [AIIQ — must-watch: Intro to LLMs](https://aiiq.substack.com/p/must-watch-video-introduction-to) 🇬🇧 — fiche
- [YouTubeSummary — Deep Dive into LLMs like ChatGPT](https://youtubesummary.com/summary/7xTGNNLPyMI) 🇬🇧 — plan de la vidéo (3 h 30)
- [Conffab — Deep Dive into LLMs](https://conffab.com/?p=7983) 🇬🇧
- [3Blue1Brown — Neural Networks](https://www.3blue1brown.com/topics/neural-networks) 🇬🇧 — 8 vidéos (dont « But what is a GPT? », « Attention in transformers ») ; © Grant Sanderson
- [TheTVDB — 3Blue1Brown 2024 (épisodes)](https://www.thetvdb.com/series/3blue1brown/seasons/official/2024) 🇬🇧
- [beri.net — 3Blue1Brown Neural Networks](https://www.beri.net/learning/3blue1brown-neural-networks) 🇬🇧
- [Class Central — Stanford CS229 Autumn 2018 (Andrew Ng) sur YouTube](https://www.classcentral.com/course/youtube-stanford-cs229-machine-learning-full-course-taught-by-andrew-ng-autumn-2018-107761) 🇬🇧 — résultat de recherche

---

## 17. Réglementation France / UE

### 17.1 France Compétences, RS, CPF, FOAD, Qualiopi
- [France Compétences — Notice d'aide à la téléprocédure RS (octobre 2026)](https://www.francecompetences.fr/app/uploads/2026/10/Notice_aide_RS_102026.pdf) 🇫🇷 — version la plus récente
- [France Compétences — formulaire RS complément de dossier (octobre 2025)](https://www.francecompetences.fr/app/uploads/2025/09/VF_demande_enregistrement_RS_complement_dossier_oct2025.pdf) 🇫🇷
- [France Compétences — Notice RS (septembre 2024)](https://francecompetences.fr/app/uploads/2024/09/Notice_aide_RS_092024.pdf) 🇫🇷
- [France Compétences — Notice RS (juin 2019)](https://www.francecompetences.fr/IMG/pdf/notice_d_aide_rs_19-06-2019.pdf) 🇫🇷 — règles de rédaction des intitulés
- [France Compétences — Notice d'information certification (juin 2021)](https://francecompetences.fr/app/uploads/2021/06/20210602_FC_NOTICE_CERTIFICATION.pdf) 🇫🇷
- [France Compétences — fiche RS7685](https://www.francecompetences.fr/recherche/rs/7685/) 🇫🇷 — IA générative dans le design ; épreuves écrites + oral jury
- [Relevé de décisions — janvier 2026](https://www.francecompetences.fr/app/uploads/2026/01/Decisions-RNCP-RS_JANV2026.pdf) 🇫🇷
- [Relevé de décisions — 28 avril 2026](https://www.francecompetences.fr/app/uploads/2026/04/CCP20260428_Releve_decisionsRNCP_RS.pdf) 🇫🇷 — titres RNCP « Product builder no code », « Expert en ingénierie de l'IA »
- [Relevé de décisions — 16 juillet 2026](https://www.francecompetences.fr/app/uploads/2026/07/CCP20260716_Releve-de-decisions.pdf) 🇫🇷
- [Centre Inffo — décret 2018-1172 (conditions d'enregistrement)](https://www.centre-inffo.fr/site-reforme/certification/conditions-denregistrement-des-certifications-et-habilitations-dans-les-repertoires-nationaux-publication-du-decret) 🇫🇷
- [Centre Inffo — « Le RS, une démarche exigeante et rigoureuse » (webinaire)](https://www.centre-inffo.fr/site-centre-inffo/le-repertoire-specifique-une-demarche-exigeante-et-rigoureuse-webinaire-centre-inffo) 🇫🇷 — ~80 % des dossiers échouent à l'instruction
- [Centre Inffo — Enregistrer une certification au RS (PDF 2018)](https://www.centre-inffo.fr/content/uploads/2018/10/enregistrer-une-certification-au-re-pertoire-spe-cifique.pdf) 🇫🇷
- [Centre Inffo — IA générative : vers une certification de référence (Certifopac)](https://www.centre-inffo.fr/site-centre-inffo/actualites-centre-inffo/le-quotidien-de-la-formation-actualite-formation-professionnelle-apprentissage/articles-2025/ia-generative-et-competences-vers-une-certification-professionnelle-de-reference) 🇫🇷 — 4 mars 2025
- [Certif Info — RS5005 (Simplon, archivée)](https://www.intercariforef.org/formations/certification-106821.html) 🇫🇷
- [Certif Info — RS6776 (INKREA)](https://www.intercariforef.org/formations/certification-117593.html) 🇫🇷
- [Certif Info — RS6891 (Certifopac)](https://www.intercariforef.org/formations/produire-et-reviser-du-contenu-professionnel-multimedia-en-utilisant-les-outils-dintelligence-artificielle-generative-iag-de-facon-responsable/certification-118058.html) 🇫🇷
- [Certif Info — RS7138 (Valeurs et talents)](https://www.intercariforef.org/formations/details/certification-119005.html) 🇫🇷
- [Certif Info — RS7177 (One learn)](https://www.intercariforef.org/formations/certification-119102) 🇫🇷
- [Certif Info — RS7232 (CCI France)](https://www.intercariforef.org/formations/certification-119566.html) 🇫🇷
- [Certif Info — RS7344 (Webmarketing & co'm)](https://www.intercariforef.org/formations/certification-119843) 🇫🇷
- [MaFormation — Certification IA : laquelle choisir](https://www.maformation.fr/actualites/certification-ia-choisir-197700) 🇫🇷 — RS6776/RS6891 plafonnées à 1 500 € (31 août 2026)
- [Éditions Tissot — reste à charge CPF 150 € au 2 avril 2026](https://www.editions-tissot.fr/actualite/droit-du-travail/cpf-le-reste-a-charge-passe-a-150-euros-a-compter-du-2-avril-2026) 🇫🇷 — décret 2026-234
- [Previssima — reste à charge 103,20 € au 1er janvier 2026](https://www.previssima.fr/actualite/cpf-votre-reste-a-charge-passe-a-10320-en-2026.html) 🇫🇷
- [Filiz — plafonds CPF et reste à charge](https://www.filiz.io/blog/cpf-plafonds-reste-a-charge) 🇫🇷 — décret 2026-127 : RS plafonné à 1 500 €
- [Culture RH — CPF : ce qui change le 2 avril 2026](https://culture-rh.com/cpf-reste-a-charge-2026/) 🇫🇷
- [Filiz — Portail EDOF : inscription et fonctionnement](https://www.filiz.io/blog/portail-edof-inscription-fonctionnement-organismes-formation) 🇫🇷
- [Certiforma — Référencer ses formations sur EDOF](https://certiforma.fr/referencer-formations-mon-compte-formation-edof/) 🇫🇷
- [Code du travail — art. D6313-3-1 (FOAD)](https://code.travail.gouv.fr/code-du-travail/d6313-3-1) 🇫🇷
- [Centre Inffo — formation à distance : respecter le cadre réglementaire (TA Toulouse 2023)](https://www.centre-inffo.fr/site-droit-formation/actualites-droit/formation-dispensee-a-distance-respecter-le-cadre-reglementaire) 🇫🇷
- [Certiforma — critères du Référentiel national qualité](https://certiforma.fr/criteres-referentiel-national-qualite/) 🇫🇷
- [Certiforma — Qualiopi V10](https://certiforma.fr/qualiopi-v10/) 🇫🇷 — décret 2026-728, applicable au 1er nov. 2026
- [CNFCE — Qualiopi : ce qui change au 1er novembre 2026](https://www.cnfce.com/actualites/qualiopi-ce-qui-change-au-1er-novembre-2026) 🇫🇷
- [OPCO Direct — checklist Qualiopi](https://opcodirect.fr/outils/checklist-qualiopi) 🇫🇷

### 17.2 AI Act, RGPD, droit d'auteur, loi SREN
- [donneespersonnelles.fr — Omnibus numérique IA](https://donneespersonnelles.fr/omnibus-numerique-ia) 🇫🇷 — calendrier AI Act mis à jour (12 sept. 2026) ; report haut risque au 2 déc. 2027
- [CMS Law — la Commission clarifie l'obligation d'AI literacy](https://cms.law/en/int/legal-updates/european-commission-clarifies-literacy-requirements-under-the-ai-act) 🇬🇧 — 22 mai 2025
- [RTR (Autriche) — AI literacy, art. 4](https://www.rtr.at/rtr/service/ki-servicestelle/ai-act/ai_literacy.en.html) 🇬🇧
- [Sénat — réponse ministérielle (deepfakes, sanctions AI Act)](https://www.senat.fr/questions/base/2025/qSEQ251006478.html) 🇫🇷 — 5 fév. 2026
- [CNIL — finalisation des recommandations IA](https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia) 🇫🇷 — 22 juil. 2025
- [CNIL — les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — 18 fiches
- [CNIL — synthèse des recommandations RGPD / IA](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd) 🇫🇷
- [donneespersonnelles.fr — Droit d'auteur et IA générative](https://www.donneespersonnelles.fr/droit-auteur-ia-generative) 🇫🇷 — exception TDM, GEMA c. OpenAI, CJUE C-250/25 (sept. 2026)
- [Seban & Associés — LAION c. Kneschke (LG Hambourg, 27 sept. 2024)](https://www.seban-associes.avocat.fr/intelligence-artificielle-et-exception-de-fouille-de-textes-et-de-donnees-une-premiere-decision-rendue-en-europe/?idLAJ=122601) 🇫🇷
- [Village de la Justice — apports de la loi SREN](https://www.village-justice.com/articles/les-apports-loi-visant-reguler-espace-numerique,52322.html) 🇫🇷 — art. 226-8 code pénal (deepfakes)
- [Règlement (UE) 2026/1744 (omnibus IA)](https://eur-lex.europa.eu/eli/reg/2026/1744/oj) 🇬🇧 — texte officiel des reports de l'AI Act (nov. 2026, vue dans l'index officiel)

### 17.3 Réutilisation de contenus (licences)
- [Creative Commons — CC BY-NC-SA 4.0 (deed FR)](https://creativecommons.org/licenses/by-nc-sa/4.0/deed.fr) 🇫🇷
- [ConductAtlas — CGU OpenAI : propriété des outputs](https://conductatlas.com/platform/openai/terms-of-use-row/output-ownership-and-content-license/) 🇬🇧 — version du 1er janv. 2026
- [Google — intégrer des vidéos YouTube (embed)](https://support.google.com/youtube/answer/171780?hl=fr-ch) 🇫🇷 — conditions d'intégration dans un LMS

---

## 18. Certifications tierces (hors Anthropic, OpenAI, n8n, Make déjà listées)
- [Microsoft — study guide AI-900](https://learn.microsoft.com/certifications/resources/study-guides/AI-900) 🇬🇧 — version du 2 mai 2025 ; examen retiré le 30 juin 2026
- [Microsoft — examen AI-901](https://learn.microsoft.com/en-us/credentials/certifications/exams/ai-901/) 🇬🇧 — cité (page refusée) ; remplaçant d'AI-900
- [Open Exam Prep — AI-901 exam guide 2026](https://open-exam-prep.com/blog/microsoft-azure-ai-fundamentals-ai-901-exam-guide-2026) 🇬🇧 — domaines 40-45 % / 55-60 %
- [AWS Certified AI Practitioner](https://aws.amazon.com/certification/certified-ai-practitioner/) 🇬🇧 — page refusée (voir « À vérifier »)
- [Jedha — 10 formations IA éligibles au CPF](https://www.jedha.co/formation-ia/les-10-meilleures-formations-ia-eligibles-au-cpf-en-2025) 🇫🇷 — RS6792, RS7029, RS6560, RS6601 cités
- [France Formation Groupe — certification RS6776](https://francefg.fr/certification-rs6776/) 🇫🇷 — « nos formations IA ne sont pas certifiantes »

---

## 19. Marché français et politiques publiques
- [Licorne Society — formations IA](https://www.licornesociety.com/blog/formations-ia) 🇫🇷 — relevé de prix (13 oct. 2026)
- [Formalive — meilleure formation IA (comparatif)](https://www.formalive.fr/meilleure-formation-intelligence-artificielle/) 🇫🇷 — 21 fév. 2026
- [The Intelligence Academy — comparatif formations IA en ligne 2026](https://www.the-intelligence-academy.com/blog/comparatif-formations-ia-en-ligne-france-2026) 🇫🇷 — source commerciale (biais déclaré)
- [École Cube — Automatisations & Agents IA (avancé)](https://www.ecole.cube.fr/formations/competences/automatisations-agents-ia-avance) 🇫🇷 — 3 990 €, 100 h, n8n, Claude Code, bloc RNCP39108
- [Le Monde Informatique — Wild Code School forme à l'IA agentique](https://www.lemondeinformatique.fr/actualites/lire-la-wild-code-school-forme-des-codeurs-a-l-ia-agentique-99179.html) 🇫🇷 — 7 990 € TTC, 6 mois
- [MaFormation — IA agentique et automatisation avancée (Cadres en Mission)](https://www.maformation.fr/formation/formation-ia-agentique-et-automatisation-avancee-creer-des-agents-ia-capables-de-prendre-des-decisions-et-executer-des-taches-553090) 🇫🇷 — 4 920 €, 198 h
- [Dawan — IA génératives dans le travail de bureau (PDF)](https://www.dawan.fr/formations/intelligence-artificielle/premiers-pas-avec-IA/ia-generatives-dans-le-travail-de-bureau.pdf) 🇫🇷 — 14 h, 1 020-1 275 € HT
- [Maddyness — ce qu'il faut retenir du Sommet pour l'action sur l'IA](https://www.maddyness.com/2025/02/12/ce-quil-faut-retenir-du-sommet-pour-laction-sur-lia/) 🇫🇷 — 109 Md€, 58 pays (12 fév. 2025)
- [Maddyness — Osez l'IA, le plan de Clara Chappaz](https://www.maddyness.com/2025/07/01/osez-lia-le-plan-de-clara-chappaz-pour-accelerer-ladoption-de-lia-dans-les-entreprises-francaises/) 🇫🇷 — 15 M de professionnels à former d'ici 2030 (1er juil. 2025)
- [Le Monde Informatique — le gouvernement lance un plan pour former à l'IA (Impulsion IA 2027)](https://www.lemondeinformatique.fr/actualites/lireamp-le-gouvernement-lance-un-plan-pour-former-a-l-ia-100805.html) 🇫🇷 — 30 M de personnes, Explore IA, certification nationale ANSSI/Afpa (23 sept. 2026)
- [Blog du Modérateur — étude PwC compétences IA dans les offres d'emploi](https://www.blogdumoderateur.com/etude-competences-ia-offres-emploi/) 🇫🇷 — +273 % 2019-2024 (12 juin 2025)
- [France Travail — IA : les métiers qui recrutent](https://www.francetravail.fr/actualites/le-dossier/les-metiers-de-demain/ia-les-metiers-qui-recrutent-le.html) 🇫🇷 — màj 18 sept. 2025
- [Syntec Ingénierie — OPIIEC IA « à retenir » (PDF)](https://www.syntec-ingenierie.fr/app/uploads/2025/06/20250428_OPIIEC_IA_A_RETENIR.pdf) 🇫🇷 — 45 000 emplois IA à créer, 287 500 salariés à former
- [HEC — Diffusion de l'IA en France (Aghion, Bergeaud, Bunel, Delbouve)](https://www.hec.edu/sites/default/files/documents/Diffusion%20de%20l%E2%80%99Intelligence%20Artificielle%20en%20France_Philippe%20Aghion-Antonin%20Bergeaud-Simon%20Bunel-Paul%20Delbouve_Juillet%202025.pdf) 🇫🇷 — juillet 2025
- [Randstad — hybridation des compétences (communiqué)](https://www.grouperandstad.fr/wp-content/uploads/2026/07/communique-de-presse-randstad--hybridation-des-competences-23-07-2026.pdf) 🇫🇷 — 23 juil. 2026

---

## 20. Médias génératifs (image, vidéo, voix)
- [FLUX.1 Schnell (HF)](https://huggingface.co/black-forest-labs/FLUX.1-schnell) 🇬🇧 — cité ; Apache 2.0
- [Stable Diffusion 3.5 Large (HF)](https://huggingface.co/stabilityai/stable-diffusion-3.5-large) 🇬🇧 — cité ; Stability Community License
- [KoboldCpp — wiki (image, voix, musique intégrées)](https://github.com/LostRuins/koboldcpp/wiki) 🇬🇧 — SD/Flux, Whisper, TTS, ACE-Step
- [Apple — FLUX-dev-4bit sur M5 (MLX)](https://machinelearning.apple.com/research/exploring-llms-mlx-m5) 🇬🇧 — génération d'image locale 3,8× plus rapide que M4

---

## 21. À vérifier avant usage (URL ⚠️, 🔎 ou « non re-vérifiée » dans les dossiers)

Adresses officielles connues ou résultats de recherche **non ouverts** pendant la recherche : ne pas les citer dans un support avant contrôle.

### Anthropic
- https://www.anthropic.com/legal/aup — Usage Policy (cité par academy.claude.com)
- https://www.anthropic.com/legal/commercial-terms — Commercial Terms (cité par la doc Agent SDK)
- https://www.anthropic.com/news/claude-partner-network — annonce du Claude Partner Network
- https://www.pearsonvue.com/us/en/anthropic.html — page Pearson VUE Anthropic
- https://www.anthropic.com/claude-fable-and-mythos-5-1 — annonce Fable 5.1 / Mythos 5.1
- https://www.anthropic.com/claude-fable-5-1-mythos-5-1-system-card — system card
- https://www.anthropic.com/news/claude-fable-5-mythos-5 — annonce Fable 5 (9 juin 2026)
- https://www.anthropic.com/news/claude-opus-4-8 — annonce Opus 4.8
- https://www.anthropic.com/news/cyber-verification-program — Cyber Verification Program
- https://www.anthropic.com/glasswing — Project Glasswing
- https://claude.com/blog/anthropics-approach-to-teaching-and-learning-ai — article pédagogie Anthropic
- https://anthropic.skilljar.com/ — ancienne instance Skilljar grand public (non ouvrable directement)
- https://github.com/anthropics/anthropic-cookbook — ancien nom du cookbook
- https://platform.claude.com/docs/en/test-and-evaluate/eval-tool — page probablement renommée/supprimée (❌)
- https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency — chemin déduit de la navigation
- https://docs.claude.com/en/api/agent-sdk/overview — ancienne adresse de la doc Agent SDK

### OpenAI, Google, Microsoft, AWS, autres certifications
- https://openai.com/index/openai-certificate-courses/ — annonce officielle des certificate courses (refusée)
- https://help.openai.com/en/articles/20001270-openai-academy-courses — aide OpenAI Academy courses
- https://help.openai.com/en/articles/20001151-openai-certified-app — aide OpenAI Certified app
- https://openai.github.io/openai-agents-python/ — docs Agents SDK Python
- https://platform.openai.com/docs/guides/image-generation — ancienne adresse de la doc image
- https://www.skills.google/paths/118 — nouveau domaine Google Skills (parcours 118)
- https://www.cloudskillsboost.google/paths/118/course_templates/539 et …/976, …/552, …/541, …/388 — autres cours du parcours 118 (cités de mémoire dans le dossier 03)
- https://www.coursera.org/specializations/introduction-to-generative-ai — version Coursera du parcours Google
- https://developers.google.com/machine-learning/crash-course/prereqs-and-prework — prérequis du Crash Course
- https://google.github.io/adk-docs/ — docs Google ADK
- https://aws.amazon.com/certification/certified-ai-practitioner/ — AWS AIF-C01 (page refusée ; domaines non lus)
- https://trailhead.salesforce.com/en/credentials/aiassociate — Salesforce Certified AI Associate (refusée)
- https://www.comptia.org/certifications/ai-essentials — CompTIA AI Essentials (refusée)
- https://costbench.com/changelog/xai-api-price-increase-2026-08/ — changements de prix xAI (non ouvert)
- https://learn.zapier.com/automate-your-work — cours Zapier (trouvé en recherche)
- https://www.coursera.org/learn/agentic-ai-chatgpt-zapier — cours Vanderbilt ChatGPT & Zapier
- https://github.com/microsoft/ML-For-Beginners — ML for Beginners (licence MIT à relire)
- https://www.kaggle.com/learn — Kaggle Learn (titres et durées officiels)

### Cours universitaires et vidéos
- https://cs50.harvard.edu/ai/license et https://cs50.harvard.edu/x/2025/license/ — licence CS50 (CC BY-NC-SA habituellement)
- https://cs50.harvard.edu/x/weeks/6/ — CS50x 2026
- https://ocw.mit.edu/courses/6-036-introduction-to-machine-learning-fall-2020/ — miroir OCW de 6.036
- https://introml.mit.edu/spring26/info · https://introml.mit.edu/fall23/info — autres éditions de 6.390
- https://introml.mit.edu/_static/fall23/LectureNotes/6390_intro.pdf · https://introml.mit.edu/_static/spring26/lectures/lec01/introml-sp26-lec01.pdf — notes et slides 6.390
- https://introtodeeplearning.com/2025/index.html · https://introtodeeplearning.com/2024/ · https://introtodeeplearning.com/2023/index.html — éditions antérieures de 6.S191
- https://cs231n.stanford.edu/2025/schedule.html — CS231n 2025
- https://web.stanford.edu/class/cs25/past/cs25-v5 · https://web.stanford.edu/class/cs25/past/cs25-v4/index.html — CS25 V5/V4
- https://web.stanford.edu/~shervine/teaching/cs-221 — cheatsheets CS221 (Shervine Amidi)
- https://www.coursera.org/specializations/machine-learning-introduction · https://www.coursera.org/specializations/deep-learning · https://www.coursera.org/learn/ai-for-everyone — versions Coursera des cours DeepLearning.AI
- https://luma.com/42E_PBWS_HappyHour — événement 42 Blockchain (seul résultat trouvé ; site/GitHub de l'association à documenter)
- https://www.elementsofai.fr/ — version française d'Elements of AI (intitulés FR des chapitres)
- Livres libres : https://d2l.ai/ (Dive into Deep Learning) · https://www.deeplearningbook.org/ (Goodfellow) · https://web.stanford.edu/~jurafsky/slp3/ (SLP3) · https://udlbook.github.io/udlbook/ (Understanding Deep Learning) · https://fleuret.org/francois/lbdl.html (Little Book of Deep Learning) — URL canoniques non ouvertes, licences à confirmer
- MOOC francophones : https://www.fun-mooc.fr/fr/cours/intelligence-artificielle-avec-intelligence/ (Inria/Class'Code) · https://www.fun-mooc.fr/fr/cours/machine-learning-in-python-with-scikit-learn/ et https://inria.github.io/scikit-learn-mooc/ (Inria) · https://classcode.fr/iai/ · https://objectif-ia.openclassrooms.com/ (Institut Montaigne) · https://pix.fr/ia · https://www.fun-mooc.fr/ — non ouverts

### LLM locaux, matériel, frameworks, évaluation, sécurité, médias (dossier 04 « non re-vérifiées »)
- https://github.com/ggml-org/llama.cpp · https://github.com/nomic-ai/gpt4all · https://github.com/ml-explore/mlx-lm · https://github.com/chroma-core/chroma · https://github.com/milvus-io/milvus
- https://docs.llamaindex.ai · https://haystack.deepset.ai · https://docs.crewai.com · https://github.com/ag2ai/ag2 · https://docs.agno.com · https://ai.pydantic.dev · https://ai-sdk.dev
- https://lmarena.ai · https://smith.langchain.com · https://langfuse.com · https://phoenix.arize.com · https://www.helicone.ai · https://github.com/comet-ml/opik · https://wandb.ai · https://github.com/openai/evals · https://github.com/EleutherAI/lm-evaluation-harness
- https://www.swebench.com · https://arcprize.org · https://www.tbench.ai · https://livecodebench.github.io
- https://www.nist.gov/itl/ai-risk-management-framework · https://atlas.mitre.org · https://github.com/NVIDIA/NeMo-Guardrails · https://github.com/guardrails-ai/guardrails · https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/ · https://huggingface.co/meta-llama (Llama Guard)
- https://github.com/comfyanonymous/ComfyUI · https://openai.com/sora · https://deepmind.google/models/veo/ · https://runwayml.com · https://klingai.com · https://www.midjourney.com · https://elevenlabs.io · https://github.com/openai/whisper · https://suno.com
- https://huggingface.co/Qwen/Qwen3-235B-A22B — fiche Qwen3-235B (citée)
- arXiv 2305.14314 (QLoRA, Dettmers et al., 2023) — référence non re-vérifiée

### Réglementation (dossier 05 — non exploitables ou non vérifiées)
- economie.gouv.fr (Osez l'IA), info.gouv.fr (Sommet IA), legifrance (décret 2018-1172, décrets 2026-127 et 2026-234, décret 2026-728), EUR-Lex (règlement 2026/1744), travail-emploi.gouv.fr (guide de lecture Qualiopi V10, BPF), 1edtech.org (Open Badges 3.0), europa.eu/europass (Europass Digital Credentials), afnor.org (guide de lecture V9), formation.lefebvre-dalloz.fr, openai.com/policies, youtube.com/t/terms.
