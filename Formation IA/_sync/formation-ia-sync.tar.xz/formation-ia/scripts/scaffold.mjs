// Crée l'arborescence niveaux/ et les module.json manquants à partir de programme.json (idempotent, n'écrase rien).
import fs from "node:fs";
import path from "node:path";
import { ROOT, LEVEL_DIRS, loadProgramme, moduleDir, slugify } from "./lib.mjs";

const p = loadProgramme();
let created = 0;
for (const level of p.levels) {
  const ldir = path.join(ROOT, "niveaux", LEVEL_DIRS[level.id]);
  fs.mkdirSync(ldir, { recursive: true });
  for (const mod of level.modules) {
    const dir = moduleDir(level, mod);
    fs.mkdirSync(dir, { recursive: true });
    const mj = path.join(dir, "module.json");
    if (!fs.existsSync(mj)) {
      fs.writeFileSync(
        mj,
        JSON.stringify(
          {
            id: mod.id,
            level: level.id,
            title: mod.title,
            minutes: mod.minutes,
            description: "",
            objectives: [],
            skills: [],
            alignedWith: [],
            sources: [],
            lessons: mod.lessons.map((l) => ({ id: l.id, title: l.title, minutes: l.minutes, file: `${l.id}-${slugify(l.title)}.md` })),
          },
          null,
          2,
        ) + "\n",
      );
      created++;
    }
  }
}
fs.mkdirSync(path.join(ROOT, "examens"), { recursive: true });
fs.mkdirSync(path.join(ROOT, "export"), { recursive: true });
fs.mkdirSync(path.join(ROOT, "referentiel"), { recursive: true });
fs.mkdirSync(path.join(ROOT, "ressources"), { recursive: true });
console.log(`scaffold ok — ${created} module.json créés`);
