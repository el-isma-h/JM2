// Valide l'ensemble : programme.json, module.json, leçons (frontmatter, longueur, sources), quiz, examens.
// Usage : node scripts/validate.mjs [--links]  (--links : vérifie les URLs par HEAD/GET, lent)
import fs from "node:fs";
import path from "node:path";
import { ROOT, loadProgramme, moduleDir, lessonFile, parseFrontmatter, wordCount } from "./lib.mjs";

const checkLinks = process.argv.includes("--links");
const errors = [], warnings = [];
const err = (s) => errors.push(s), warn = (s) => warnings.push(s);
const p = loadProgramme();
const urls = new Set();
let lessons = 0, lessonsWritten = 0, questions = 0, words = 0;

function validateQuiz(file, expectedCount, label) {
  if (!fs.existsSync(file)) return warn(`${label}: quiz manquant (${path.relative(ROOT, file)})`);
  let q;
  try { q = JSON.parse(fs.readFileSync(file, "utf8")); } catch (e) { return err(`${label}: JSON invalide — ${e.message}`); }
  if (!Array.isArray(q.questions)) return err(`${label}: "questions" manquant`);
  if (q.questions.length < expectedCount) warn(`${label}: ${q.questions.length} questions (< ${expectedCount})`);
  if (q.passScore !== 70) warn(`${label}: passScore ${q.passScore} ≠ 70`);
  const ids = new Set();
  q.questions.forEach((it, i) => {
    const tag = `${label} Q${i + 1}`;
    if (!it.q || typeof it.q !== "string") err(`${tag}: "q" manquant`);
    if (!Array.isArray(it.options) || it.options.length < 2) err(`${tag}: options invalides`);
    else if (typeof it.answer !== "number" || it.answer < 0 || it.answer >= it.options.length) err(`${tag}: "answer" hors limites`);
    if (!it.explanation) warn(`${tag}: pas d'explication`);
    if (it.id) { if (ids.has(it.id)) err(`${tag}: id dupliqué ${it.id}`); ids.add(it.id); }
    if (it.source?.url) urls.add(it.source.url);
    questions++;
  });
  return q;
}

for (const level of p.levels) {
  let levelMinutes = 0;
  for (const mod of level.modules) {
    const dir = moduleDir(level, mod);
    const mj = path.join(dir, "module.json");
    if (!fs.existsSync(mj)) { err(`${mod.id}: module.json manquant`); continue; }
    let m;
    try { m = JSON.parse(fs.readFileSync(mj, "utf8")); } catch (e) { err(`${mod.id}: module.json invalide — ${e.message}`); continue; }
    if (!m.description) warn(`${mod.id}: description vide`);
    if (!m.objectives?.length) warn(`${mod.id}: objectifs vides`);
    for (const s of m.sources || []) if (s.url) urls.add(s.url);
    let modMinutes = 0;
    for (const lesson of mod.lessons) {
      lessons++;
      modMinutes += lesson.minutes;
      const f = lessonFile(level, mod, lesson);
      if (!fs.existsSync(f)) { warn(`${lesson.id}: leçon non rédigée`); continue; }
      lessonsWritten++;
      const md = fs.readFileSync(f, "utf8");
      const { data, body } = parseFrontmatter(md);
      if (!data) { err(`${lesson.id}: en-tête YAML manquant`); continue; }
      if (data.id !== lesson.id) err(`${lesson.id}: id en-tête ≠ ${data.id}`);
      if (data.module !== mod.id) err(`${lesson.id}: module en-tête ≠ ${data.module}`);
      if (data.level !== level.id) err(`${lesson.id}: level en-tête ≠ ${data.level}`);
      if (Number(data.minutes) !== lesson.minutes) warn(`${lesson.id}: minutes ${data.minutes} ≠ programme ${lesson.minutes}`);
      const wc = wordCount(body); words += wc;
      const minWords = lesson.minutes >= 60 ? 1500 : 800;
      if (wc < minWords) warn(`${lesson.id}: ${wc} mots (< ${minWords})`);
      const links = [...body.matchAll(/\]\((https?:\/\/[^)\s]+)\)/g)].map((x) => x[1]);
      links.forEach((u) => urls.add(u));
      if (links.length < 2) warn(`${lesson.id}: ${links.length} lien(s) de documentation (< 2)`);
      for (const section of ["Exercice pratique", "Pour aller plus loin"]) if (!body.includes(section)) warn(`${lesson.id}: section « ${section} » absente`);
      for (const m of body.matchAll(/```(quiz|mission)\n([\s\S]*?)\n```/g)) {
        try {
          const o = JSON.parse(m[2]);
          if (m[1] === "quiz" && (!Array.isArray(o.options) || typeof o.answer !== "number" || o.answer < 0 || o.answer >= o.options.length || !o.q)) err(`${lesson.id}: bloc quiz invalide`);
          if (m[1] === "mission") { if (!o.url || !o.question || !o.answer) err(`${lesson.id}: bloc mission incomplet`); else urls.add(o.url); }
        } catch (e) { err(`${lesson.id}: JSON invalide dans un bloc ${m[1]} — ${e.message}`); }
      }
    }
    validateQuiz(path.join(dir, "quiz.json"), p.quizPerModule, `${mod.id} quiz`);
    levelMinutes += modMinutes + (mod.quizMinutes || 15);
  }
  validateQuiz(path.join(ROOT, "examens", `${level.id}-examen.json`), p.examPerLevel, `${level.id} examen`);
  levelMinutes += level.examMinutes || 60;
  if (levelMinutes !== level.hours * 60) err(`${level.id}: ${levelMinutes} min ≠ ${level.hours} h`);
}

if (checkLinks) {
  console.log(`Vérification de ${urls.size} URLs…`);
  const list = [...urls];
  const bad = [];
  const limit = 12;
  let i = 0;
  await Promise.all(Array.from({ length: limit }, async () => {
    while (i < list.length) {
      const u = list[i++];
      try {
        const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 15000);
        let r = await fetch(u, { method: "HEAD", redirect: "follow", signal: ctrl.signal, headers: { "user-agent": "Mozilla/5.0 (link-check)" } });
        if (r.status >= 400 || r.status === 405) r = await fetch(u, { method: "GET", redirect: "follow", signal: ctrl.signal, headers: { "user-agent": "Mozilla/5.0 (link-check)" } });
        clearTimeout(t);
        if (r.status >= 400) bad.push(`${r.status} ${u}`);
      } catch (e) { bad.push(`ERR ${u} (${e.name})`); }
    }
  }));
  bad.forEach((b) => warn(`lien: ${b}`));
  console.log(`liens KO : ${bad.length}`);
}

console.log(`\nLeçons rédigées : ${lessonsWritten}/${lessons} · mots : ${words.toLocaleString("fr-FR")} · questions : ${questions} · URLs distinctes : ${urls.size}`);
if (warnings.length) { console.log(`\n⚠️  ${warnings.length} avertissement(s)`); warnings.forEach((w) => console.log("  - " + w)); }
if (errors.length) { console.log(`\n❌ ${errors.length} erreur(s)`); errors.forEach((e) => console.log("  - " + e)); process.exit(1); }
console.log("\n✅ Aucune erreur bloquante.");
