// Génère : programme/programme.md, export/elearning-modules.json (format Next Formation), export/programme-catalogue.json, export/formation-ia-complete.md
import fs from "node:fs";
import path from "node:path";
import { ROOT, loadProgramme, moduleDir, lessonFile, parseFrontmatter, fmtHours } from "./lib.mjs";


/** Convertit les blocs ```quiz / ```mission (rendus interactifs par l'app) en Markdown classique pour l'export Next Formation. */
const LETTERS = ["A", "B", "C", "D", "E", "F"];
export function plainBlocks(md) {
  return md.replace(/```(quiz|mission)\n([\s\S]*?)\n```/g, (all, kind, json) => {
    let o;
    try { o = JSON.parse(json); } catch { return all; }
    if (kind === "quiz") {
      const opts = (o.options || []).map((x, i) => `> - **${LETTERS[i]}.** ${x}`).join("\n");
      return `> 🧩 **Quiz éclair** — ${o.q}\n>\n${opts}\n>\n> <details><summary>Voir la réponse</summary>\n>\n> **${LETTERS[o.answer]}.** ${o.options[o.answer]} — ${o.explanation || ""}\n>\n> </details>`;
    }
    const steps = (o.steps || []).map((x, i) => `> ${i + 1}. ${x}`).join("\n");
    return `> 🔎 **Mission documentation${o.xp ? ` (+${o.xp} XP)` : ""}** — ${o.title || ""}\n>\n> 🔗 [${o.url}](${o.url})\n>\n${steps}\n>\n> **Question :** ${o.question}\n>\n> <details><summary>Indice</summary>\n>\n> ${o.hint || "—"}\n>\n> </details>\n>\n> <details><summary>Réponse</summary>\n>\n> ${o.answer}\n>\n> </details>`;
  });
}

const p = loadProgramme();
const out = [];
out.push(`# ${p.title}`, ``, `*${p.subtitle}*`, ``, `Version ${p.version} — ${p.versionDate} · Organisme : ${p.organisme} · Modalité : à distance (FOAD) · Durée totale : **${p.totalHours} h**`, ``);
out.push(`## Vue d'ensemble`, ``, `| Niveau | Intitulé | Durée | Modules | Leçons | Certificat |`, `|---|---|---|---|---|---|`);
for (const lv of p.levels) out.push(`| ${lv.id} | ${lv.title} | ${lv.hours} h | ${lv.modules.length} | ${lv.modules.reduce((a, m) => a + m.lessons.length, 0)} | ${lv.certificate} |`);
out.push(``, `Évaluation : quiz de ${p.quizPerModule} questions à la fin de chaque module, examen de ${p.examPerLevel} questions par niveau, seuil de réussite ${p.passScore} %, projets pratiques aux niveaux 2, 3 et 4.`, ``);

const elearning = [];
const catalogue = { code: p.code, title: p.title, kind: "certifiante", category: "Intelligence artificielle", formacode: "31016", specialty: "Informatique, traitement de l'information", cpfEligible: p.cpfEligible, availableAsContinuing: true, availableAsApprenticeship: false, isPublished: true, tags: ["IA", "intelligence artificielle", "LLM", "automatisation", "n8n", "Anthropic", "OpenAI"], levels: [] };
const full = [`# ${p.title} — contenu intégral`, ``];

for (const lv of p.levels) {
  out.push(`## ${lv.title} (${lv.hours} h)`, ``, `**Public** : ${lv.audience}  `, `**Prérequis** : ${lv.prerequisites}  `, `**Certificat** : ${lv.certificate}  `, `**Aligné sur** : ${lv.alignedWith.join(" · ")}`, ``);
  const lvOut = { id: lv.id, code: lv.code, title: lv.title, hours: lv.hours, audience: lv.audience, prerequisites: lv.prerequisites, certificate: lv.certificate, alignedWith: lv.alignedWith, modules: [] };
  full.push(`# ${lv.title}`, ``);
  let position = 0;
  for (const mod of lv.modules) {
    const dir = moduleDir(lv, mod);
    let mj = {};
    try { mj = JSON.parse(fs.readFileSync(path.join(dir, "module.json"), "utf8")); } catch {}
    out.push(`### ${mod.id} — ${mod.title} (${fmtHours(mod.minutes)})`, ``);
    if (mj.description) out.push(mj.description, ``);
    if (mj.objectives?.length) { out.push(`Objectifs :`); mj.objectives.forEach((o) => out.push(`- ${o}`)); out.push(``); }
    out.push(`| # | Leçon | Durée |`, `|---|---|---|`);
    full.push(`## ${mod.id} — ${mod.title}`, ``);
    const modSkills = mj.skills || [];
    for (const lesson of mod.lessons) {
      out.push(`| ${lesson.id} | ${lesson.title} | ${lesson.minutes} min |`);
      const f = lessonFile(lv, mod, lesson);
      if (fs.existsSync(f)) {
        const { body } = parseFrontmatter(fs.readFileSync(f, "utf8"));
        elearning.push({ level: lv.id, module: mod.id, lessonId: lesson.id, kind: "contenu", title: `${lesson.id} · ${lesson.title}`, description: `${lv.title} — ${mod.title}`, durationMinutes: lesson.minutes, countsAsHours: true, position: position++, content: { format: "markdown", body: plainBlocks(body.trim()) } });
        full.push(plainBlocks(body.trim()), ``, `---`, ``);
      }
    }
    out.push(`| — | Quiz de module (${p.quizPerModule} questions) | ${mod.quizMinutes} min |`, ``);
    const qf = path.join(dir, "quiz.json");
    if (fs.existsSync(qf)) {
      const q = JSON.parse(fs.readFileSync(qf, "utf8"));
      elearning.push({ level: lv.id, module: mod.id, kind: "quiz", title: q.title || `Quiz — ${mod.title}`, description: `${q.questions.length} questions pour valider le module ${mod.id}.`, durationMinutes: mod.quizMinutes, countsAsHours: false, position: position++, content: { questions: q.questions.map((x) => ({ q: x.q, options: x.options, answer: x.answer, explanation: x.explanation, type: x.type, lessonId: x.lessonId, source: x.source })), passScore: q.passScore ?? p.passScore } });
    }
    lvOut.modules.push({ code: mod.id, title: mod.title, description: mj.description || "", hours: Math.round(mod.minutes / 60), minutes: mod.minutes, position: lvOut.modules.length, skills: modSkills, objectives: mj.objectives || [], lessons: mod.lessons.map((l) => ({ id: l.id, title: l.title, minutes: l.minutes })) });
  }
  const ef = path.join(ROOT, "examens", `${lv.id}-examen.json`);
  if (fs.existsSync(ef)) {
    const q = JSON.parse(fs.readFileSync(ef, "utf8"));
    elearning.push({ level: lv.id, module: null, kind: "quiz", title: q.title || `Examen — ${lv.title}`, description: `Examen de certification du niveau ${lv.id} : ${q.questions.length} questions, ${lv.examMinutes} min, seuil ${q.passScore ?? p.passScore} %.`, durationMinutes: lv.examMinutes, countsAsHours: false, position: position++, content: { questions: q.questions.map((x) => ({ q: x.q, options: x.options, answer: x.answer, explanation: x.explanation, type: x.type, lessonId: x.lessonId, source: x.source })), passScore: q.passScore ?? p.passScore, timeLimitMinutes: q.timeLimitMinutes ?? lv.examMinutes } });
  }
  out.push(`### Examen de certification ${lv.id} — ${p.examPerLevel} questions, ${lv.examMinutes} min, seuil ${p.passScore} %`, ``);
  catalogue.levels.push(lvOut);
}

fs.writeFileSync(path.join(ROOT, "programme/programme.md"), out.join("\n") + "\n");
fs.mkdirSync(path.join(ROOT, "export"), { recursive: true });
fs.writeFileSync(path.join(ROOT, "export/elearning-modules.json"), JSON.stringify({ generatedAt: new Date().toISOString(), programme: p.code, version: p.version, format: "Next Formation elearning_modules (kind contenu|quiz)", modules: elearning }, null, 2));
fs.writeFileSync(path.join(ROOT, "export/programme-catalogue.json"), JSON.stringify(catalogue, null, 2));
fs.writeFileSync(path.join(ROOT, "export/formation-ia-complete.md"), full.join("\n"));
console.log(`build ok — ${elearning.filter((e) => e.kind === "contenu").length} leçons, ${elearning.filter((e) => e.kind === "quiz").length} quiz/examens exportés`);
