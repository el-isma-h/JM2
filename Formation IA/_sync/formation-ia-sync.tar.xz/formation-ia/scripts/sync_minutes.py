"""Propage les durées (minutes) de programme/programme.json vers les module.json et l'en-tête YAML des leçons.
Usage : python3 scripts/sync_minutes.py  (à lancer depuis la racine du projet)
"""
import glob
import json
import os
import re

p = json.load(open("programme/programme.json", encoding="utf-8"))
changed = 0
for lv in p["levels"]:
    for m in lv["modules"]:
        mdirs = glob.glob(f"niveaux/*/{m['id']}-*/")
        if not mdirs:
            continue
        d = mdirs[0]
        mj = os.path.join(d, "module.json")
        if os.path.exists(mj):
            j = json.load(open(mj, encoding="utf-8"))
            j["minutes"] = m["minutes"]
            for l in m["lessons"]:
                for jl in j.get("lessons", []):
                    if isinstance(jl, dict) and jl.get("id") == l["id"]:
                        jl["minutes"] = l["minutes"]
            json.dump(j, open(mj, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        for l in m["lessons"]:
            for f in glob.glob(f"{d}{l['id']}-*.md"):
                s = open(f, encoding="utf-8").read()
                s2 = re.sub(r"^minutes:\s*\d+", f"minutes: {l['minutes']}", s, count=1, flags=re.M)
                s2 = re.sub(r"(> ⏱ )\d+( min)", rf"\g<1>{l['minutes']}\2", s2, count=1)
                if s2 != s:
                    open(f, "w", encoding="utf-8").write(s2)
                    changed += 1
print("leçons mises à jour :", changed)
