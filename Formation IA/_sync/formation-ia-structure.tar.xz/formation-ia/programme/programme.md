# Formation IA complète — Next Formation

*De zéro à expert : 4 niveaux, 150 heures, 30 modules, 150 leçons*

Version 1.0.0 — 2026-11-01 · Organisme : Next Formation (Next by HPT GIE) · Modalité : à distance (FOAD) · Durée totale : **150 h**

## Vue d'ensemble

| Niveau | Intitulé | Durée | Modules | Leçons | Certificat |
|---|---|---|---|---|---|
| N1 | Niveau 1 — Fondamentaux de l'IA | 25 h | 7 | 31 | Certificat Next Formation IA — Niveau 1 « Utilisateur IA certifié » |
| N2 | Niveau 2 — Praticien IA et automatisation | 35 h | 8 | 33 | Certificat Next Formation IA — Niveau 2 « Praticien IA & automatisation » |
| N3 | Niveau 3 — Développeur IA | 45 h | 8 | 46 | Certificat Next Formation IA — Niveau 3 « Développeur IA » |
| N4 | Niveau 4 — Expert IA : du machine learning aux modèles de frontière | 45 h | 7 | 40 | Certificat Next Formation IA — Niveau 4 « Expert IA » |

Évaluation : quiz de 10 questions à la fin de chaque module, examen de 40 questions par niveau, seuil de réussite 70 %, projets pratiques aux niveaux 2, 3 et 4.

## Niveau 1 — Fondamentaux de l'IA (25 h)

**Public** : Tout public : salariés, dirigeants, indépendants, demandeurs d'emploi, sans prérequis technique.  
**Prérequis** : Savoir utiliser un ordinateur et un navigateur web. Aucune compétence en programmation.  
**Certificat** : Certificat Next Formation IA — Niveau 1 « Utilisateur IA certifié »  
**Aligné sur** : Anthropic Academy (cours fondamentaux Claude) · n8n Level 1 · Google AI Essentials · Microsoft AI-900 (domaines IA générative) · Elements of AI · AI Act art. 4 — alphabétisation IA

### M01 — Comprendre l'intelligence artificielle (2 h 45)

| # | Leçon | Durée |
|---|---|---|
| L001 | Histoire et définitions : IA, machine learning, deep learning, IA générative | 40 min |
| L002 | Comment une machine apprend : données, entraînement, inférence | 40 min |
| L003 | Les grandes familles d'IA : vision, langage, recommandation, prédiction | 35 min |
| L004 | Mythes, réalités et chiffres clés de l'IA en 2026 | 35 min |
| — | Quiz de module (10 questions) | 15 min |

### M02 — Les grands modèles de langage (LLM) expliqués (3 h 45)

| # | Leçon | Durée |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 40 min |
| L006 | Le transformer sans mathématiques : attention et prédiction du mot suivant | 40 min |
| L007 | Pré-entraînement, fine-tuning, RLHF : pourquoi ChatGPT répond comme ça | 40 min |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 min |
| L009 | Panorama des modèles 2026 : Claude, GPT, Gemini, Grok, Mistral, Llama, DeepSeek, Qwen | 50 min |
| — | Quiz de module (10 questions) | 15 min |

### M03 — Les outils IA du quotidien (3 h 35)

| # | Leçon | Durée |
|---|---|---|
| L010 | ChatGPT : prise en main complète | 40 min |
| L011 | Claude : conversations, projets, artefacts et premiers pas avec Claude Code | 45 min |
| L012 | Gemini, Copilot, Grok, Le Chat : forces et usages | 40 min |
| L013 | Perplexity et la recherche augmentée par l'IA | 35 min |
| L014 | Image, vidéo, voix : premier tour des outils génératifs | 40 min |
| — | Quiz de module (10 questions) | 15 min |

### M04 — Prompt engineering : parler aux modèles (4 h 50)

| # | Leçon | Durée |
|---|---|---|
| L015 | Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes | 45 min |
| L016 | Techniques : exemples (few-shot), raisonnement pas à pas, décomposition | 45 min |
| L017 | Les guides officiels Anthropic et OpenAI : balises, system prompts, clarté | 50 min |
| L018 | Prompts métiers : rédiger, résumer, analyser, traduire, tabuler | 45 min |
| L019 | Itérer et évaluer : bibliothèque de prompts personnelle | 40 min |
| L020 | Atelier guidé : 10 prompts à construire et corriger | 50 min |
| — | Quiz de module (10 questions) | 15 min |

### M05 — L'IA au travail (2 h 25)

| # | Leçon | Durée |
|---|---|---|
| L021 | Cas d'usage par métier : RH, vente, marketing, finance, support, juridique | 45 min |
| L022 | Productivité : documents, e-mails, réunions, tableurs, présentations | 45 min |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 min |
| — | Quiz de module (10 questions) | 15 min |

### M06 — Introduction à l'automatisation et aux agents (2 h 55)

| # | Leçon | Durée |
|---|---|---|
| L024 | API, webhook, JSON : les trois mots à comprendre | 40 min |
| L025 | n8n : découverte et premier workflow (aligné n8n Level 1) | 50 min |
| L026 | Qu'est-ce qu'un agent IA ? | 35 min |
| L027 | MCP (Model Context Protocol) expliqué simplement | 35 min |
| — | Quiz de module (10 questions) | 15 min |

### M07 — Éthique, droit et sécurité de l'IA (3 h 45)

| # | Leçon | Durée |
|---|---|---|
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 min |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 min |
| L030 | Droit d'auteur, deepfakes, biais et discriminations | 40 min |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 85 min |
| — | Quiz de module (10 questions) | 15 min |

### Examen de certification N1 — 40 questions, 60 min, seuil 70 %

## Niveau 2 — Praticien IA et automatisation (35 h)

**Public** : Professionnels voulant automatiser, déployer des assistants et faire tourner des modèles en local, sans être développeurs.  
**Prérequis** : Niveau 1 ou connaissances équivalentes.  
**Certificat** : Certificat Next Formation IA — Niveau 2 « Praticien IA & automatisation »  
**Aligné sur** : n8n Level 2 · Make Academy · Anthropic Academy (Claude pour les équipes, Claude Code) · Microsoft AI-900 · AWS Certified AI Practitioner (domaines fondamentaux)

### M08 — n8n avancé : automatiser avec l'IA (6 h 50)

| # | Leçon | Durée |
|---|---|---|
| L032 | Nœuds, expressions et structure des données (n8n Level 1 approfondi) | 55 min |
| L033 | n8n Level 2 : traitement d'erreurs, sous-workflows, bonnes pratiques | 55 min |
| L034 | Les nœuds IA : AI Agent, modèles, mémoire, outils | 55 min |
| L035 | RAG sans code : vector store et embeddings dans n8n | 55 min |
| L036 | Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks | 55 min |
| L037 | Auto-héberger n8n (Docker) et sécuriser | 50 min |
| L038 | Projet : assistant de support client automatisé | 70 min |
| — | Quiz de module (10 questions) | 15 min |

### M09 — Make, Zapier et choix d'un outil d'automatisation (2 h 15)

| # | Leçon | Durée |
|---|---|---|
| L039 | Make : scénarios avec modules IA | 60 min |
| L040 | Zapier, comparatif et grille de choix | 60 min |
| — | Quiz de module (10 questions) | 15 min |

### M10 — LLM locaux : faire tourner l'IA sur sa machine (6 h 15)

| # | Leçon | Durée |
|---|---|---|
| L041 | Pourquoi un LLM local : confidentialité, coût, latence, souveraineté | 45 min |
| L042 | Matériel : paramètres, RAM / VRAM, stockage, vitesse — Mac, PC NVIDIA, CPU, DGX Spark | 75 min |
| L043 | Ollama : installer, télécharger un modèle, dialoguer, API locale | 60 min |
| L044 | LM Studio, Jan, Open WebUI : interfaces graphiques | 55 min |
| L045 | Choisir le meilleur modèle ouvert : Llama, Qwen, Mistral, Gemma, DeepSeek, gpt-oss | 65 min |
| L046 | Brancher un LLM local sur n8n et vos applications (API compatible OpenAI) | 60 min |
| — | Quiz de module (10 questions) | 15 min |

### M11 — RAG et bases de connaissances (4 h 15)

| # | Leçon | Durée |
|---|---|---|
| L047 | Embeddings et recherche sémantique | 55 min |
| L048 | Construire un RAG sans code : n8n, Dify, Flowise, NotebookLM | 70 min |
| L049 | Découpage (chunking), qualité et évaluation d'un RAG | 60 min |
| L050 | Projets Claude, GPT personnalisés, Gems : la connaissance embarquée | 55 min |
| — | Quiz de module (10 questions) | 15 min |

### M12 — Assistants et agents sans code (4 h 20)

| # | Leçon | Durée |
|---|---|---|
| L051 | Custom GPT, Projets Claude, Copilot Studio | 60 min |
| L052 | Agents multi-outils dans n8n | 65 min |
| L053 | Claude Code, Lovable, Bolt, v0 : créer une application sans coder | 70 min |
| L054 | Computer use et navigateurs IA | 50 min |
| — | Quiz de module (10 questions) | 15 min |

### M13 — Données et analyse avec l'IA (4 h 20)

| # | Leçon | Durée |
|---|---|---|
| L055 | Analyser un fichier CSV / Excel avec ChatGPT et Claude | 60 min |
| L056 | Visualisations et rapports générés | 60 min |
| L057 | SQL en langage naturel | 60 min |
| L058 | Automatiser un reporting hebdomadaire | 65 min |
| — | Quiz de module (10 questions) | 15 min |

### M14 — IA multimédia : image, vidéo, voix (3 h 20)

| # | Leçon | Durée |
|---|---|---|
| L059 | Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI) | 65 min |
| L060 | Vidéo : Sora, Veo, Runway, Kling | 60 min |
| L061 | Voix et audio : ElevenLabs, Whisper, Suno | 60 min |
| — | Quiz de module (10 questions) | 15 min |

### M15 — Gouvernance et déploiement de l'IA en entreprise (2 h 25)

| # | Leçon | Durée |
|---|---|---|
| L062 | SaaS, API ou local : coûts, risques, grille de décision | 60 min |
| L063 | Politique IA interne, conformité AI Act et RGPD | 60 min |
| L064 | Conduite du changement et montée en compétence des équipes | 10 min |
| — | Quiz de module (10 questions) | 15 min |

### Examen de certification N2 — 40 questions, 60 min, seuil 70 %

## Niveau 3 — Développeur IA (45 h)

**Public** : Développeurs, intégrateurs, data analysts, étudiants en informatique.  
**Prérequis** : Bases de programmation (Python ou JavaScript/TypeScript), notions HTTP/JSON. Niveau 2 recommandé.  
**Certificat** : Certificat Next Formation IA — Niveau 3 « Développeur IA »  
**Aligné sur** : Anthropic Academy — API & Claude Code · Anthropic certification développeur (si existante) · OpenAI Academy / OpenAI API · xAI Grok API · Perplexity Sonar API · Hugging Face Agents Course · DeepLearning.AI short courses (MCP, Agents) · OWASP Top 10 LLM

### M16 — Fondations de développement pour l'IA (3 h 30)

| # | Leçon | Durée |
|---|---|---|
| L065 | Python et TypeScript pour l'IA : environnement, SDK, clés API, secrets | 65 min |
| L066 | HTTP, JSON, streaming : anatomie d'un appel à un LLM | 65 min |
| L067 | Tokens, coûts, rate limits, caching : maîtriser la facture | 65 min |
| — | Quiz de module (10 questions) | 15 min |

### M17 — API Anthropic : construire avec Claude (8 h 05)

| # | Leçon | Durée |
|---|---|---|
| L068 | Messages API : requêtes, rôles, paramètres, modèles | 45 min |
| L069 | System prompts et prompt engineering avancé (guide officiel Anthropic) | 45 min |
| L070 | Tool use : donner des outils à Claude | 50 min |
| L071 | Sorties structurées et JSON fiable | 40 min |
| L072 | Vision, PDF, Files API et citations | 40 min |
| L073 | Prompt caching, Batch API, extended thinking | 45 min |
| L074 | Claude Code et Claude Agent SDK en pratique | 50 min |
| L075 | MCP : construire un serveur et un client | 50 min |
| L076 | Skills, bonnes pratiques et évaluation des prompts | 40 min |
| L077 | Projet : assistant métier avec Claude | 65 min |
| — | Quiz de module (10 questions) | 15 min |

### M18 — API OpenAI (5 h 45)

| # | Leçon | Durée |
|---|---|---|
| L078 | Responses API et Chat Completions | 50 min |
| L079 | Function calling et structured outputs | 50 min |
| L080 | Embeddings, images, audio et Realtime | 55 min |
| L081 | OpenAI Agents SDK | 55 min |
| L082 | Fine-tuning et Evals via l'API | 55 min |
| L083 | Projet : le même assistant, porté sur OpenAI | 65 min |
| — | Quiz de module (10 questions) | 15 min |

### M19 — xAI Grok, Perplexity, Mistral, Gemini et multi-fournisseur (4 h 50)

| # | Leçon | Durée |
|---|---|---|
| L084 | xAI Grok API : compatibilité SDK, live search, vision | 50 min |
| L085 | Perplexity Sonar API : recherche avec citations | 50 min |
| L086 | Mistral AI : La Plateforme, Codestral, modèles ouverts | 50 min |
| L087 | Google Gemini API | 50 min |
| L088 | Architecture multi-fournisseur : abstraction, routeurs (OpenRouter, LiteLLM), repli | 75 min |
| — | Quiz de module (10 questions) | 15 min |

### M20 — RAG en code (5 h 45)

| # | Leçon | Durée |
|---|---|---|
| L089 | Embeddings et bases vectorielles : pgvector, Chroma, Qdrant | 55 min |
| L090 | Pipeline d'ingestion : parsing, chunking, métadonnées | 55 min |
| L091 | LangChain et LlamaIndex | 55 min |
| L092 | Recherche hybride, reranking, requêtes multiples | 50 min |
| L093 | Évaluer un RAG : Ragas, jeux de test, métriques | 50 min |
| L094 | Projet : RAG documentaire d'entreprise | 65 min |
| — | Quiz de module (10 questions) | 15 min |

### M21 — Agents en code (5 h 45)

| # | Leçon | Durée |
|---|---|---|
| L095 | La boucle agentique : outils, mémoire, planification | 55 min |
| L096 | LangGraph : agents à états | 55 min |
| L097 | OpenAI Agents SDK, Claude Agent SDK, Pydantic AI | 55 min |
| L098 | Multi-agents : CrewAI, AutoGen / AG2 | 50 min |
| L099 | Agents, MCP et A2A : interopérabilité | 50 min |
| L100 | Projet : agent de recherche et de rédaction autonome | 65 min |
| — | Quiz de module (10 questions) | 15 min |

### M22 — Applications IA : interface, déploiement, observabilité (4 h 50)

| # | Leçon | Durée |
|---|---|---|
| L101 | Next.js et Vercel AI SDK : chat en streaming | 60 min |
| L102 | Backend : files d'attente, limites, coûts, cache | 50 min |
| L103 | Observabilité : Langfuse, LangSmith ; évaluations : promptfoo, DeepEval | 55 min |
| L104 | CI/CD et tests de prompts | 45 min |
| L105 | Projet : application IA complète déployée | 65 min |
| — | Quiz de module (10 questions) | 15 min |

### M23 — Sécurité des applications LLM (5 h 30)

| # | Leçon | Durée |
|---|---|---|
| L106 | OWASP Top 10 pour les applications LLM | 55 min |
| L107 | Prompt injection directe et indirecte : attaques et défenses | 55 min |
| L108 | Guardrails, modération, données personnelles | 55 min |
| L109 | Secrets, quotas, abus et coûts | 50 min |
| L110 | Audit de sécurité d'une application IA (atelier) | 100 min |
| — | Quiz de module (10 questions) | 15 min |

### Examen de certification N3 — 40 questions, 60 min, seuil 70 %

## Niveau 4 — Expert IA : du machine learning aux modèles de frontière (45 h)

**Public** : Développeurs confirmés, ingénieurs, data scientists, étudiants d'écoles d'ingénieurs et de 42.  
**Prérequis** : Niveau 3 ou expérience en développement IA ; bases de mathématiques niveau bac + 1 remises à niveau dans le module 24.  
**Certificat** : Certificat Next Formation IA — Niveau 4 « Expert IA »  
**Aligné sur** : MIT 6.S191 Introduction to Deep Learning · MIT 6.390 Introduction to Machine Learning · Stanford CS229, CS224N, CS324, CS336 · École 42 — projets IA (ft_linear_regression, DSLR, multilayer-perceptron) · Karpathy Zero to Hero · Hugging Face LLM Course · NIST AI RMF, ISO/IEC 42001, OWASP Agentic

### M24 — Mathématiques pour l'IA (5 h 15)

| # | Leçon | Durée |
|---|---|---|
| L111 | Algèbre linéaire : vecteurs, matrices, produits (inspiré MIT 18.06) | 80 min |
| L112 | Dérivées et gradients | 70 min |
| L113 | Probabilités et statistiques utiles | 70 min |
| L114 | Optimisation : descente de gradient | 80 min |
| — | Quiz de module (10 questions) | 15 min |

### M25 — Machine learning (inspiré Stanford CS229 et MIT 6.390) (6 h 15)

| # | Leçon | Durée |
|---|---|---|
| L115 | Régression linéaire et logistique (projets 42 ft_linear_regression, DSLR) | 65 min |
| L116 | Biais-variance, régularisation, validation croisée | 55 min |
| L117 | Arbres, forêts aléatoires, gradient boosting | 55 min |
| L118 | Apprentissage non supervisé : k-means, PCA | 55 min |
| L119 | scikit-learn en pratique | 60 min |
| L120 | Projet ML : prédiction sur données réelles | 70 min |
| — | Quiz de module (10 questions) | 15 min |

### M26 — Deep learning (inspiré MIT 6.S191) (7 h 15)

| # | Leçon | Durée |
|---|---|---|
| L121 | Perceptron et réseaux multicouches (projet 42 multilayer-perceptron) | 60 min |
| L122 | Rétropropagation à la main (micrograd, Karpathy) | 65 min |
| L123 | PyTorch : tenseurs, autograd, boucle d'entraînement | 60 min |
| L124 | Réseaux convolutifs et vision | 60 min |
| L125 | Séquences : RNN, LSTM et leurs limites | 55 min |
| L126 | Entraîner efficacement : optimiseurs, régularisation, GPU | 55 min |
| L127 | Projet DL : classifieur d'images | 65 min |
| — | Quiz de module (10 questions) | 15 min |

### M27 — Transformers et LLM from scratch (inspiré CS224N, CS336, CS25) (7 h 15)

| # | Leçon | Durée |
|---|---|---|
| L128 | Le mécanisme d'attention | 60 min |
| L129 | Architecture transformer complète | 60 min |
| L130 | Tokenization : BPE et tokenizers | 55 min |
| L131 | Un GPT from scratch (nanoGPT) | 70 min |
| L132 | Lois d'échelle, données et pré-entraînement | 55 min |
| L133 | Post-entraînement : SFT, RLHF, DPO, modèles de raisonnement | 60 min |
| L134 | Architectures 2026 : MoE, contexte long, multimodal | 60 min |
| — | Quiz de module (10 questions) | 15 min |

### M28 — Fine-tuning et adaptation de modèles (6 h 15)

| # | Leçon | Durée |
|---|---|---|
| L135 | Quand fine-tuner (et quand ne pas le faire) | 50 min |
| L136 | LoRA / QLoRA avec Hugging Face PEFT, TRL et Unsloth | 70 min |
| L137 | Jeux de données, données synthétiques, distillation | 60 min |
| L138 | Évaluer : benchmarks (MMLU, GPQA, SWE-bench…) et evals maison | 55 min |
| L139 | Fine-tuning via API : OpenAI, Mistral, Gemini | 55 min |
| L140 | Projet : spécialiser un modèle ouvert sur un domaine | 70 min |
| — | Quiz de module (10 questions) | 15 min |

### M29 — Inférence, déploiement et MLOps (5 h 15)

| # | Leçon | Durée |
|---|---|---|
| L141 | Quantization, GGUF et serveurs d'inférence : vLLM, llama.cpp, TGI | 65 min |
| L142 | KV cache, batching, speculative decoding | 55 min |
| L143 | Servir en production : GPU cloud, on-premise, DGX Spark, coûts | 60 min |
| L144 | MLOps : versioning, monitoring, dérive | 60 min |
| L145 | Edge et NPU : l'IA embarquée | 60 min |
| — | Quiz de module (10 questions) | 15 min |

### M30 — Sécurité avancée, alignement et frontière de la recherche (6 h 30)

| # | Leçon | Durée |
|---|---|---|
| L146 | Alignement et interprétabilité (recherche Anthropic, OpenAI, DeepMind) | 60 min |
| L147 | Red teaming, jailbreaks, robustesse | 60 min |
| L148 | Sécurité des systèmes agentiques : OWASP Agentic, MITRE ATLAS | 60 min |
| L149 | Gouvernance avancée : NIST AI RMF, ISO/IEC 42001, AI Act haut risque | 60 min |
| L150 | Veille scientifique, articles fondateurs et projet final | 135 min |
| — | Quiz de module (10 questions) | 15 min |

### Examen de certification N4 — 40 questions, 60 min, seuil 70 %

