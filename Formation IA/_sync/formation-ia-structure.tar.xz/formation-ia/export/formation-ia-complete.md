# Formation IA complète — Next Formation — contenu intégral

# Niveau 1 — Fondamentaux de l'IA

## M01 — Comprendre l'intelligence artificielle

## M02 — Les grands modèles de langage (LLM) expliqués

## M03 — Les outils IA du quotidien

## M04 — Prompt engineering : parler aux modèles

## M05 — L'IA au travail

## M06 — Introduction à l'automatisation et aux agents

## M07 — Éthique, droit et sécurité de l'IA

# Niveau 2 — Praticien IA et automatisation

## M08 — n8n avancé : automatiser avec l'IA

## M09 — Make, Zapier et choix d'un outil d'automatisation

## M10 — LLM locaux : faire tourner l'IA sur sa machine

## M11 — RAG et bases de connaissances

## M12 — Assistants et agents sans code

## M13 — Données et analyse avec l'IA

## M14 — IA multimédia : image, vidéo, voix

## M15 — Gouvernance et déploiement de l'IA en entreprise

# Niveau 3 — Développeur IA

## M16 — Fondations de développement pour l'IA

## M17 — API Anthropic : construire avec Claude

## M18 — API OpenAI

## M19 — xAI Grok, Perplexity, Mistral, Gemini et multi-fournisseur

## M20 — RAG en code

## M21 — Agents en code

## M22 — Applications IA : interface, déploiement, observabilité

## M23 — Sécurité des applications LLM

# Niveau 4 — Expert IA : du machine learning aux modèles de frontière

## M24 — Mathématiques pour l'IA

## M25 — Machine learning (inspiré Stanford CS229 et MIT 6.390)

## M26 — Deep learning (inspiré MIT 6.S191)

## M27 — Transformers et LLM from scratch (inspiré CS224N, CS336, CS25)

## M28 — Fine-tuning et adaptation de modèles

## M29 — Inférence, déploiement et MLOps

## M30 — Sécurité avancée, alignement et frontière de la recherche
