# Parcours métier — Marketing & communication

> 🧭 Pour les chargés de communication, responsables marketing, community managers et créatifs qui produisent des contenus écrits, visuels, vidéo et audio. Aucun prérequis technique.

## 1. Ce que l'IA change pour vous en 2026

Votre métier est l'un de ceux que l'IA générative transforme le plus visiblement. Un article devient un post LinkedIn, une newsletter et un script vidéo en quelques minutes ; 200 avis clients se rangent en cinq thèmes avec leurs verbatims (L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique ») ; un visuel ou une vidéo de quelques secondes se génère à partir d'un brief (L059 « Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI) », L060 « Vidéo : Sora, Veo, Runway, Kling »).

Ce qui ne change pas : la stratégie, la connaissance de vos publics et le goût. Les modèles produisent volontiers du contenu générique, des superlatifs et des chiffres qui ne figurent nulle part. Votre valeur se déplace vers le brief, la sélection, la retouche et la vérification.

Deux règles nouvelles pèsent sur vous. Depuis le 2 août 2026, l'article 50 de l'AI Act impose de **signaler les deepfakes et les contenus synthétiques** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA »). Et une création générée en un clic n'est **pas protégée** par le droit d'auteur : seule la part humaine documentée l'est (L030 « Droit d'auteur, deepfakes, biais et discriminations »).

## 2. Parcours conseillé

Le **niveau 1 complet** (25 h) donne le certificat « Utilisateur IA certifié » ; le parcours ci-dessous en garde l'essentiel et ajoute le module M14 (multimédia) et l'analyse de données du niveau 2.

**Socle N1** — 16 leçons, 11 h 25

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L015 | Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes | 45 |
| L016 | Techniques : exemples (few-shot), raisonnement pas à pas, décomposition | 45 |
| L018 | Prompts métiers : rédiger, résumer, analyser, traduire, tabuler | 45 |
| L019 | Itérer et évaluer : bibliothèque de prompts personnelle | 40 |
| L021 | Cas d'usage par métier : RH, vente, marketing, finance, support, juridique | 45 |
| L022 | Productivité : documents, e-mails, réunions, tableurs, présentations | 45 |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 |
| L030 | Droit d'auteur, deepfakes, biais et discriminations | 40 |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 40 |
| L013 | Perplexity et la recherche augmentée par l'IA | 40 |
| L014 | Image, vidéo, voix : premier tour des outils génératifs | 40 |
| L017 | Les guides officiels Anthropic et OpenAI : balises, system prompts, clarté | 50 |

**Prioritaires N2** — 6 leçons, 5 h 55

| Leçon | Titre | Durée (min) |
|---|---|---|
| L050 | Projets Claude, GPT personnalisés, Gems : la connaissance embarquée | 55 |
| L055 | Analyser un fichier CSV / Excel avec ChatGPT et Claude | 60 |
| L056 | Visualisations et rapports générés | 60 |
| L059 | Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI) | 60 |
| L060 | Vidéo : Sora, Veo, Runway, Kling | 60 |
| L061 | Voix et audio : ElevenLabs, Whisper, Suno | 60 |

**Facultatives** — 7 leçons, 6 h 50. Pour automatiser la diffusion ou créer une mini-application de campagne.

| Leçon | Titre | Durée (min) |
|---|---|---|
| L025 | n8n : découverte et premier workflow (aligné n8n Level 1) | 50 |
| L036 | Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks | 55 |
| L039 | Make : scénarios avec modules IA | 60 |
| L040 | Zapier, comparatif et grille de choix | 60 |
| L051 | Custom GPT, Projets Claude, Copilot Studio | 60 |
| L053 | Claude Code, Lovable, Bolt, v0 : créer une application sans coder | 65 |
| L063 | Politique IA interne, conformité AI Act et RGPD | 60 |

> ⏱ **Durée totale du parcours conseillé : 17 h 20** de leçons et d'exercices (quiz de module non compris), **24 h 10** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

🟢 relecture rapide · 🟠 contrôle des faits · 🔴 validation experte (L021).

### Cas 1 — Un contenu, cinq formats
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🟢
```text
Rôle : responsable communication d'une marque de cosmétiques bio. Contexte : charte de ton et étude de cas ci-dessous. Tâche : post LinkedIn (120 mots, question finale), paragraphe de newsletter, script vidéo 30 s. Contraintes : aucune allégation santé, aucun chiffre absent de l'étude, aucun superlatif.
```

### Cas 2 — Les thèmes de 200 avis clients
Leçon : L055 « Analyser un fichier CSV / Excel avec ChatGPT et Claude » · 🟠
```text
Fichier joint : 200 avis (colonnes date, note, texte), sans nom. Fais calculer en code le nombre d'avis par thème ; propose 5 thèmes avec 2 verbatims exacts chacun et la note moyenne. Montre le code exécuté.
```

### Cas 3 — Dix angles de campagne
Leçon : L016 « Techniques : exemples (few-shot), raisonnement pas à pas, décomposition » · 🟢 — Décomposition : 10 angles en une ligne → vous en choisissez 2 → développement de chacun avec accroche, preuve et appel à l'action.

### Cas 4 — L'assistant « charte de marque »
Leçon : L050 « Projets Claude, GPT personnalisés, Gems : la connaissance embarquée » · 🟠 — Projet Claude, GPT ou Gem nourri de la charte de ton, du glossaire et de trois contenus exemplaires ; il réécrit tout brouillon dans la voix de la marque.

### Cas 5 — Prompt d'image structuré
Leçon : L059 « Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI) » · 🟠
```text
Sujet : flacon de sérum ambré sur un plan de travail en chêne. Style : photographie produit naturelle. Composition : plan rapproché, tiers gauche vide pour le texte. Lumière : matin, douce, latérale. À éviter : texte, logo, mains, reflets artificiels. Format 4:5.
```

### Cas 6 — Une vidéo produit en six étapes
Leçon : L060 « Vidéo : Sora, Veo, Runway, Kling » · 🟠 — Brief → storyboard → images de référence → génération des plans avec un budget d'itérations fixé → montage → mention de transparence et contrôle juridique (personnes, marques).

### Cas 7 — Sous-titres et voix off
Leçon : L061 « Voix et audio : ElevenLabs, Whisper, Suno » · 🟠 — Transcription Whisper en local → fichier SRT relu → voix de synthèse sous licence commerciale ; clonage d'une voix réelle seulement avec un accord écrit.

### Cas 8 — Veille concurrentielle sourcée
Leçon : L013 « Perplexity et la recherche augmentée par l'IA » · 🟠
```text
Liste les lancements de produits de nos 4 concurrents (noms ci-dessous) depuis 6 mois. Pour chaque fait : date, source cliquable, citation exacte. Écarte toute information sans source primaire.
```

### Cas 9 — Le graphique du bilan de campagne
Leçon : L056 « Visualisations et rapports générés » · 🟠 — Données, type de graphique, axes, unités, titre et message clé dans le prompt ; vérification des axes tronqués et des chiffres avant diffusion.

### Cas 10 — Relecture conformité d'une campagne
Leçon : L030 « Droit d'auteur, deepfakes, biais et discriminations » · 🟠
```text
Relis ces 6 messages de campagne. Signale : allégations non prouvées, superlatifs, stéréotypes (genre, âge, origine), personnes réelles représentées, visuels générés sans mention. Tableau : message, problème, reformulation.
```

## 4. Trois projets fil rouge

### Projet 1 — Le kit éditorial de la marque
- **Énoncé** : industrialiser la déclinaison d'un contenu pilier.
- **Livrable** : assistant « charte de marque », 6 gabarits de prompts versionnés, grille d'évaluation.
- **Critères de réussite** : chaque gabarit passe 5 cas de test ; aucun chiffre inventé ; ton validé à l'aveugle par un collègue.
- **Leçons** : L018, L019, L050 · **Lab** : aucun, bibliothèque de prompts de L019.

### Projet 2 — Le baromètre mensuel des avis clients
- **Énoncé** : chaque mois, une note de 1 page sur ce que disent les clients.
- **Livrable** : workflow (export → comptage par code → rédaction → graphique), note type.
- **Critères de réussite** : comptages recalculés à l'identique ; verbatims exacts ; alerte si un thème double d'un mois sur l'autre.
- **Leçons** : L055, L056, L058 · **Lab** : [`lab-reporting`](../labs/lab-reporting/), à adapter (le code compte, le modèle rédige).

### Projet 3 — Une campagne visuelle et vidéo conforme
- **Énoncé** : lancer un produit avec 3 visuels, une vidéo de 15 s et une voix off.
- **Livrable** : fichiers finaux, journal des prompts et retouches, registre des mentions et consentements.
- **Critères de réussite** : mention « généré par IA » sur chaque contenu synthétique ; licences vérifiées ; part humaine documentée.
- **Leçons** : L030, L059, L060, L061 · **Lab** : aucun, exercices de M14.

## 5. Missions documentation

**Mission 1** · L059 — Lire l'article qui encadre vos visuels et vidéos générés.

```mission
{
  "title": "L'obligation de transparence des contenus générés",
  "url": "https://eur-lex.europa.eu/eli/reg/2024/1689/oj",
  "steps": [
    "Ouvrez le règlement (UE) 2024/1689 sur EUR-Lex, en version française",
    "Descendez jusqu'au chapitre IV et à l'article 50",
    "Lisez le titre de l'article et le paragraphe consacré aux hypertrucages (deep fakes)"
  ],
  "question": "Quel est l'intitulé de l'article 50, et que doivent faire les déployeurs d'un système qui génère un hypertrucage ?",
  "hint": "L'intitulé commence par « Obligations de transparence » ; le paragraphe sur les hypertrucages est le quatrième.",
  "answer": "« Obligations de transparence pour les fournisseurs et les déployeurs de certains systèmes d'IA » ; les déployeurs doivent indiquer que le contenu (image, audio, vidéo) a été généré ou manipulé artificiellement (art. 50, § 4).",
  "xp": 20
}
```

**Mission 2** · L030 — Décoder une licence avant de réutiliser un contenu.

```mission
{
  "title": "Peut-on reprendre ce visuel sous licence CC BY-NC-SA ?",
  "url": "https://creativecommons.org/licenses/by-nc-sa/4.0/deed.fr",
  "steps": [
    "Ouvrez le résumé en français de la licence CC BY-NC-SA 4.0",
    "Repérez les trois conditions affichées avec leurs pictogrammes",
    "Lisez la définition de chacune"
  ],
  "question": "Que signifient les trois sigles BY, NC et SA, et que vous impose concrètement « SA » si vous modifiez le contenu ?",
  "hint": "Le troisième sigle concerne la licence de votre propre version.",
  "answer": "BY = Attribution (citer l'auteur) ; NC = Pas d'utilisation commerciale ; SA = Partage dans les mêmes conditions : si vous remaniez le contenu, vous devez diffuser votre version sous la même licence.",
  "xp": 10
}
```

**Mission 3** · L060 — Mesurer le risque d'une vidéo générée sans mention.

```mission
{
  "title": "Deepfake non signalé : le plafond de sanction",
  "url": "https://www.senat.fr/questions/base/2025/qSEQ251006478.html",
  "steps": [
    "Ouvrez la question écrite publiée sur le site du Sénat",
    "Repérez la date de la réponse du ministère",
    "Cherchez dans la réponse le montant maximal des sanctions prévues par l'AI Act pour un manquement aux obligations de transparence"
  ],
  "question": "À quelle date le ministère a-t-il répondu, et quel est le plafond de sanction cité pour un manquement à l'obligation de transparence ?",
  "hint": "La réponse est publiée au début de 2026 ; le plafond combine un montant en millions d'euros et un pourcentage du chiffre d'affaires mondial.",
  "answer": "Réponse publiée le 5 février 2026 ; jusqu'à 15 M€ ou 3 % du chiffre d'affaires annuel mondial.",
  "xp": 15
}
```

**Mission 4** · L061 — Vérifier la licence d'un modèle de voix avant une publicité.

```mission
{
  "title": "Une voix de synthèse pour votre spot radio ?",
  "url": "https://huggingface.co/mistralai/Voxtral-4B-TTS-2603",
  "steps": [
    "Ouvrez la model card de Voxtral 4B TTS sur Hugging Face",
    "Repérez la licence affichée dans l'en-tête de la page",
    "Cherchez ce que signifient les lettres « NC » de cette licence"
  ],
  "question": "Sous quelle licence Voxtral 4B TTS est-il publié, et autorise-t-elle un usage commercial direct ?",
  "hint": "C'est une licence Creative Commons ; « NC » veut dire « Non Commercial ».",
  "answer": "Licence CC BY-NC 4.0 : pas d'usage commercial direct (nov. 2026). Pour une publicité, préférez une API sous contrat (Voxtral TTS 3) ou une voix de bibliothèque sous licence.",
  "xp": 10
}
```

**Mission 5** · L060 — Chiffrer une seconde de vidéo générée.

```mission
{
  "title": "Budgéter une vidéo générée par API",
  "url": "https://docs.x.ai/developers/pricing",
  "steps": [
    "Ouvrez la page Pricing de la documentation xAI",
    "Repérez la section consacrée à Grok Imagine (image et vidéo)",
    "Notez le tarif de la vidéo à la seconde, puis cherchez la remise accordée à l'API Batch"
  ],
  "question": "À partir de quel prix par seconde la vidéo Grok Imagine est-elle facturée, et quelle remise offre la Batch API de xAI ?",
  "hint": "Le prix vidéo se compte en centimes de dollar ; la remise Batch est inférieure à celle d'Anthropic et d'OpenAI.",
  "answer": "À partir de 0,02 $ par seconde de vidéo ; Batch API −20 % (nov. 2026) — vérifiez : les prix évoluent (vérifié le 5 nov. 2026).",
  "xp": 15
}
```


## 6. Quiz éclair

```quiz
{
  "q": "Un concurrent copie un logo que vous avez généré en un clic, sans retouche. Que permet le droit d'auteur ?",
  "options": ["Une action en contrefaçon dès demain matin", "Peu de chose : sortie brute non protégée", "Une plainte pénale pour deepfake commercial", "Une licence payante imposée au concurrent"],
  "answer": 1,
  "explanation": "Sans intervention créative humaine, pas d'œuvre originale (art. L111-1 CPI) ; d'où l'intérêt de documenter brief, sélection et retouches (L030)."
}
```

```quiz
{
  "q": "L'équipe crée un « témoignage client » avec un visage généré qui ne ressemble à personne. Comment le qualifier ?",
  "options": ["Un deepfake licite, faute de victime", "Une pratique commerciale trompeuse", "Un contenu libre de droits à diffuser", "Une simple illustration sans risque"],
  "answer": 1,
  "explanation": "Ce n'est pas le deepfake d'une personne réelle, mais un faux avis : pratique commerciale trompeuse, à proscrire (L030)."
}
```

```quiz
{
  "q": "Pour une vidéo de vœux avec la voix clonée du dirigeant, quels sont les deux réflexes à respecter ?",
  "options": ["Accord oral et diffusion en interne", "Consentement écrit et mention visible", "Dépôt INPI et filigrane invisible", "Contrat agence et logo sur l'écran"],
  "answer": 1,
  "explanation": "Consentement écrit de la personne représentée et mention « contenu généré par IA » : sans les deux, on ne publie pas (L030)."
}
```

```quiz
{
  "q": "Un stagiaire colle dans la plaquette une image trouvée sur Google Images. Que vous autorise le droit par défaut ?",
  "options": ["Tout, si l'usage reste interne", "Tout, avec le nom du site en légende", "Rien : c'est de la contrefaçon", "Tout, si l'image est retouchée"],
  "answer": 2,
  "explanation": "Une image trouvée en ligne n'est pas libre de droits : la reprendre sans licence est une contrefaçon, même en interne (L030)."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : une vidéo sous licence CC BY-NC peut illustrer la page d'accueil du site de l'entreprise si l'auteur est cité.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. « NC » exclut tout usage destiné à un avantage commercial : un site d'entreprise ou une plaquette en font partie (L030)."
}
```

## 7. Points de vigilance juridiques

- **AI Act, transparence** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA ») : depuis le 2 août 2026, signaler un deepfake et marquer les contenus synthétiques (aménagements pour les œuvres manifestement artistiques ou satiriques) ; sanction jusqu'à 15 M€ ou 3 % du chiffre d'affaires. Depuis l'omnibus, les outils générant des images intimes non consenties sont interdits à compter du 2 décembre 2026.
- **Deepfakes, droit pénal** (L030 « Droit d'auteur, deepfakes, biais et discriminations ») : article 226-8 du code pénal (loi SREN) ; jusqu'à 2 ans et 45 000 € en cas de diffusion en ligne.
- **Propriété intellectuelle** (L030 « Droit d'auteur, deepfakes, biais et discriminations », L059 « Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI) ») : sortie brute non protégée ; conditions d'utilisation de chaque outil à lire ; licences « NC » (y compris certains modèles de voix) incompatibles avec la publicité ; courte citation strictement encadrée.
- **RGPD et droit à l'image** (L028 « RGPD et données personnelles dans les prompts (CNIL) », L061 « Voix et audio : ElevenLabs, Whisper, Suno ») : la voix et le visage sont des données personnelles, biométriques quand ils servent à identifier ; exports d'avis sans nom ; pas de fichier clients sur un compte grand public.
- **Biais** (L030 « Droit d'auteur, deepfakes, biais et discriminations ») : check-list anti-stéréotypes avant diffusion.

## 8. Certifications tierces (préparation, jamais équivalence)

Ce parcours **prépare** aux certificats suivants, sans en être l'équivalent ni être reconnu par leurs éditeurs (voir `referentiel/correspondance-certifications.md`) :
- **Google AI Professional Certificate** : cours « AI for Content Creation » et « AI for Writing and Communicating », couverts à 100 % par L014, L018, L021, L022 et M14.
- Claude Academy, série **« AI Fluency, for your world »**, dont « AI Fluency for creative work » (5 h) : couverture partielle, environ 60 %.
- **Google AI Essentials** (Coursera, ~49 $/mois après essai, nov. 2026).
