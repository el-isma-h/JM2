# Parcours métier — Ressources humaines

> 🧭 Pour les responsables et chargés RH, recruteurs, gestionnaires de paie et de formation qui veulent gagner du temps sur l'écrit sans jamais confier à l'IA une décision sur une personne. Aucun prérequis technique.

## 1. Ce que l'IA change pour vous en 2026

Les RH produisent beaucoup de texte : offres, grilles d'entretien, notes d'information, réponses aux salariés, synthèses d'enquêtes. C'est exactement ce que l'IA générative accélère : un premier jet en une minute, une synthèse de 40 verbatims en cinq (L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique »). Le gain est réel sur la rédaction et la mise en forme, beaucoup plus faible sur ce qui demande du jugement.

Votre métier est aussi celui où la frontière est la plus nette. **Trier, noter ou classer des candidats** relève du haut risque de l'AI Act (annexe III, obligations reportées au 2 décembre 2027) ; **lire les émotions** d'un salarié ou d'un candidat est interdit depuis le 2 février 2025 (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA »). Et vous manipulez en permanence des données sensibles : santé, RQTH, appartenance syndicale (L028 « RGPD et données personnelles dans les prompts (CNIL) »).

Enfin, vous serez souvent le pilote du **plan de formation IA** exigé par l'article 4 de l'AI Act (L064 « Conduite du changement et montée en compétence des équipes ») : la direction attendra de vous un plan par population, tracé salarié par salarié.

## 2. Parcours conseillé

Le **niveau 1 complet** (25 h) donne le certificat « Utilisateur IA certifié » ; le parcours ci-dessous en garde l'essentiel et ajoute cinq leçons du niveau 2.

**Socle N1** — 14 leçons, 10 h

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L015 | Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes | 45 |
| L016 | Techniques : exemples (few-shot), raisonnement pas à pas, décomposition | 45 |
| L018 | Prompts métiers : rédiger, résumer, analyser, traduire, tabuler | 45 |
| L019 | Itérer et évaluer : bibliothèque de prompts personnelle | 40 |
| L021 | Cas d'usage par métier : RH, vente, marketing, finance, support, juridique | 45 |
| L022 | Productivité : documents, e-mails, réunions, tableurs, présentations | 45 |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 |
| L030 | Droit d'auteur, deepfakes, biais et discriminations | 40 |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 40 |
| L011 | Claude : conversations, projets, artefacts et premiers pas avec Claude Code | 45 |

**Prioritaires N2** — 5 leçons, 4 h 50

| Leçon | Titre | Durée (min) |
|---|---|---|
| L048 | Construire un RAG sans code : n8n, Dify, Flowise, NotebookLM | 65 |
| L050 | Projets Claude, GPT personnalisés, Gems : la connaissance embarquée | 55 |
| L051 | Custom GPT, Projets Claude, Copilot Studio | 60 |
| L063 | Politique IA interne, conformité AI Act et RGPD | 60 |
| L064 | Conduite du changement et montée en compétence des équipes | 50 |

**Facultatives** — 7 leçons, 6 h 30. Pour automatiser un parcours d'accueil ou analyser une enquête interne.

| Leçon | Titre | Durée (min) |
|---|---|---|
| L013 | Perplexity et la recherche augmentée par l'IA | 40 |
| L025 | n8n : découverte et premier workflow (aligné n8n Level 1) | 50 |
| L036 | Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks | 55 |
| L038 | Projet : assistant de support client automatisé | 65 |
| L055 | Analyser un fichier CSV / Excel avec ChatGPT et Claude | 60 |
| L056 | Visualisations et rapports générés | 60 |
| L061 | Voix et audio : ElevenLabs, Whisper, Suno | 60 |

> ⏱ **Durée totale du parcours conseillé : 14 h 50** de leçons et d'exercices (quiz de module non compris), **21 h 20** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

🟢 relecture rapide · 🟠 contrôle des faits · 🔴 validation experte (L021).

### Cas 1 — Offre d'emploi inclusive
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🟠
```text
Rôle : chargé(e) de recrutement d'une PME industrielle de 80 salariés. Tâche : offre pour un(e) technicien(ne) de maintenance d'après la fiche de poste ci-dessous. Format : accroche, 5 missions, 4 critères de profil, conditions. Contraintes : 250 mots, aucun critère lié à l'âge, au sexe ou à la situation familiale ; signale toute information manquante.
```

### Cas 2 — Grille d'entretien structurée
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🟢 — Mêmes questions pour tous les candidats, rattachées aux compétences de la fiche de poste, avec une échelle de notation décrite pour chaque niveau.

### Cas 3 — Synthèse d'une enquête de climat social
Leçon : L018 « Prompts métiers : rédiger, résumer, analyser, traduire, tabuler » · 🟠
```text
Voici 40 réponses libres anonymisées. Regroupe-les en 5 thèmes maximum ; pour chacun : nombre de réponses, 2 verbatims exacts, une question à poser en CODIR. N'invente aucun verbatim.
```

### Cas 4 — Résumé d'entretien annuel pseudonymisé
Leçon : L028 « RGPD et données personnelles dans les prompts (CNIL) » · 🟠 — Le salarié devient « S1 », les informations médicales sont retirées avant envoi ; la table de correspondance reste chez vous.

### Cas 5 — Test anti-biais d'une annonce
Leçon : L030 « Droit d'auteur, deepfakes, biais et discriminations » · 🟠 — Workflow : générer l'annonce → changer une seule variable (prénom, âge, quartier) → comparer → chasser les *proxies* (« disponibilité totale », « jeune et dynamique »).

### Cas 6 — Note sur un changement de convention collective
Leçon : L023 « Vérifier, sourcer, corriger : la relecture critique des sorties IA » · 🟠
```text
À partir du texte officiel joint (et de lui seul), rédige une note d'information de 300 mots pour les salariés : ce qui change, à partir de quand, pour qui. Cite l'article source de chaque point ; écris « à confirmer » si le texte est ambigu.
```

### Cas 7 — Expliquer un bulletin de paie
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🟠 — Bulletin anonymisé, explication ligne à ligne en langage simple ; le calcul de la paie reste au logiciel et au gestionnaire.

### Cas 8 — Assistant « questions des salariés »
Leçon : L050 « Projets Claude, GPT personnalisés, Gems : la connaissance embarquée » · 🟠 — Projet Claude ou GPT personnalisé nourri des accords et procédures internes, avec la consigne de renvoyer vers un humain dès qu'une question touche une situation individuelle.

### Cas 9 — Plan de formation IA article 4
Leçon : L064 « Conduite du changement et montée en compétence des équipes » · 🟢
```text
Propose un plan de formation IA par population (direction, managers, administratifs, production) pour 120 salariés : objectifs, durée, modalité, preuve conservée, recyclage. Format : tableau.
```

### Cas 10 — Livret d'accueil d'un nouvel arrivant
Leçon : L022 « Productivité : documents, e-mails, réunions, tableurs, présentations » · 🟢 — Notes brutes → livret structuré → e-mail de bienvenue → planning de la première semaine, avec relecture à chaque étape.

## 4. Trois projets fil rouge

### Projet 1 — L'assistant RH des salariés
- **Énoncé** : rendre interrogeables le règlement intérieur, les accords et les procédures.
- **Livrable** : base de connaissances + 10 questions de test notées + consignes de refus.
- **Critères de réussite** : 8 réponses sur 10 correctes et sourcées ; aucune donnée personnelle dans la base ; renvoi vers un humain sur toute situation individuelle.
- **Leçons** : L048, L049, L050 · **Lab** : [`lab-rag-sans-code`](../labs/lab-rag-sans-code/).

### Projet 2 — Le kit de recrutement équitable
- **Énoncé** : outiller un recrutement de bout en bout sans confier la sélection à l'IA.
- **Livrable** : offre, grille d'entretien, check-list anti-biais, mention « décision humaine » dans le processus.
- **Critères de réussite** : test « une variable » passé sans écart ; aucun usage de tri ou de notation automatique ; la grille est identique pour tous.
- **Leçons** : L021, L029, L030 · **Lab** : aucun, exercice de L030.

### Projet 3 — L'accueil automatisé d'un nouvel arrivant
- **Énoncé** : un formulaire d'arrivée déclenche les messages et tâches d'intégration.
- **Livrable** : workflow n8n (déclencheur → rédaction IA → validation humaine → envoi), journal d'exécution.
- **Critères de réussite** : aucun envoi sans validation ; erreurs notifiées ; aucune donnée de santé dans le flux.
- **Leçons** : L025, L036, L038 · **Lab** : [`lab-n8n-support`](../labs/lab-n8n-support/), à adapter (même schéma de validation humaine).

## 5. Missions documentation

**Mission 1** · L063 — Ancrer le plan de formation IA dans le texte.

```mission
{
  "title": "L'article 4 de l'AI Act, base de votre plan de formation",
  "url": "https://eur-lex.europa.eu/eli/reg/2024/1689/oj",
  "steps": [
    "Ouvrez le règlement (UE) 2024/1689 sur EUR-Lex, en français",
    "Allez au chapitre I « Dispositions générales »",
    "Lisez l'article 4 : son titre et les personnes qu'il vise"
  ],
  "question": "Quel est l'intitulé de l'article 4, et à quelles personnes les fournisseurs et déployeurs doivent-ils assurer un niveau suffisant de maîtrise de l'IA ?",
  "hint": "L'intitulé tient en trois mots ; l'article vise le personnel, mais pas seulement.",
  "answer": "« Maîtrise de l'IA » ; il vise leur personnel et les autres personnes s'occupant du fonctionnement et de l'utilisation des systèmes d'IA pour leur compte (applicable depuis le 2 février 2025). Depuis l'omnibus (règlement (UE) 2026/1744, en vigueur le 27 juillet 2026), la formulation « niveau suffisant » est remplacée par des mesures qui favorisent la maîtrise de l'IA, sans niveau individuel imposé : vérifiez la version consolidée.",
  "xp": 20
}
```

**Mission 2** · L028 — Surveiller les futures recommandations sectorielles de la CNIL.

```mission
{
  "title": "La CNIL prépare des recommandations « travail »",
  "url": "https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia",
  "steps": [
    "Ouvrez l'article de la CNIL sur la finalisation de ses recommandations IA",
    "Repérez la date de publication",
    "Cherchez la partie sur les travaux à venir"
  ],
  "question": "Quels secteurs la CNIL annonce-t-elle pour ses futures recommandations, et comment s'appelle son projet d'outil d'audit de confidentialité des modèles mené avec l'ANSSI et le PEReN ?",
  "hint": "Le nom du projet évoque une capitale… et un panier.",
  "answer": "Éducation, santé (avec la HAS) et travail ; projet PANAME (article du 22 juillet 2025 — l'avancement a pu évoluer depuis).",
  "xp": 15
}
```

**Mission 3** · L010 — Couper l'entraînement sur les conversations.

```mission
{
  "title": "Le réglage à vérifier avant tout test RH dans ChatGPT",
  "url": "https://help.openai.com/",
  "steps": [
    "Ouvrez le centre d'aide officiel de ChatGPT",
    "Tapez dans la barre de recherche « data controls » ou « improve the model »",
    "Ouvrez l'article qui explique comment empêcher que vos conversations servent à entraîner les modèles"
  ],
  "question": "Dans quel menu de ChatGPT se trouve l'option qui empêche l'utilisation de vos conversations pour améliorer les modèles, et comment s'appelle-t-elle ?",
  "hint": "Le chemin commence par « Paramètres » ; la section 5 de la leçon L010 vous met sur la piste.",
  "answer": "Paramètres → Contrôles des données → option « Améliorer le modèle pour tous » à désactiver (libellés de nov. 2026, susceptibles de changer).",
  "xp": 15
}
```

**Mission 4** · L021 — Trouver une ressource gratuite pour vos équipes RH.

```mission
{
  "title": "Les usages RH dans le cours Claude 101",
  "url": "https://academy.claude.com/courses/claude-101",
  "steps": [
    "Ouvrez la page du cours Claude 101 sur Claude Academy",
    "Déroulez le plan du cours (liste des leçons)",
    "Repérez la partie « Putting it all together »"
  ],
  "question": "Quel est le titre exact de la leçon consacrée aux usages de Claude selon le métier, et combien de temps dure le cours entier ?",
  "hint": "Le titre commence par « Claude in action ».",
  "answer": "« Claude in action — use-cases by role », dans un cours d'environ 2,5 h (13 leçons + 1 quiz) — plan lu le 1er nov. 2026, il peut évoluer.",
  "xp": 15
}
```

**Mission 5** · L031 — Savoir où orienter l'entreprise en cas de fraude (la mission porte sur la fraude au faux fournisseur, le parcours est le même).

```mission
{
  "title": "Fraude au changement de RIB : à qui s'adresser ?",
  "url": "https://www.cybermalveillance.gouv.fr/",
  "steps": [
    "Ouvrez Cybermalveillance.gouv.fr",
    "Repérez le parcours d'assistance aux victimes (diagnostic en ligne)",
    "Notez à qui s'adresse le service (particuliers, entreprises, collectivités)"
  ],
  "question": "Quel service la plateforme propose-t-elle à une PME victime d'une fraude au faux fournisseur, et à quels publics s'adresse-t-elle ?",
  "hint": "Cherchez le bouton qui propose d'être assisté ou de faire un diagnostic.",
  "answer": "Un diagnostic en ligne qui oriente vers des conseils et, si besoin, vers des prestataires de proximité ou les services compétents (dont le dépôt de plainte) ; elle s'adresse aux particuliers, aux entreprises et aux collectivités. Le parcours peut évoluer : notez la date de consultation.",
  "xp": 10
}
```


## 6. Quiz éclair

```quiz
{
  "q": "Un éditeur vous propose un outil qui note automatiquement les CV reçus. Comment l'AI Act classe-t-il cet usage ?",
  "options": ["Risque minimal, comme un correcteur", "Haut risque, domaine de l'emploi", "Risque limité, simple transparence", "Hors champ, car c'est un logiciel RH"],
  "answer": 1,
  "explanation": "Trier ou noter des candidats relève de l'annexe III (emploi) : haut risque, obligations reportées au 2 décembre 2027 (L029)."
}
```

```quiz
{
  "q": "Un outil d'entretien vidéo promet de mesurer le stress et l'enthousiasme des candidats. Que faites-vous ?",
  "options": ["Je l'adopte, avec l'accord écrit de chaque candidat", "Je le teste d'abord sur les salariés volontaires", "Je refuse : lire les émotions au travail est interdit", "Je l'adopte, l'obligation ne vise que les fournisseurs"],
  "answer": 2,
  "explanation": "La reconnaissance des émotions sur le lieu de travail figure parmi les pratiques interdites (art. 5) depuis le 2 février 2025, hors exceptions médicales ou de sécurité (L029)."
}
```

```quiz
{
  "q": "Vous remplacez le nom d'un salarié par « S1 » et gardez la table de correspondance. Comment qualifier l'opération ?",
  "options": ["Une anonymisation complète et définitive", "Une pseudonymisation : le RGPD s'applique", "Un chiffrement au sens strict du RGPD", "Une minimisation qui supprime le RGPD"],
  "answer": 1,
  "explanation": "Tant qu'une table permet de revenir en arrière, c'est une pseudonymisation : le risque baisse, mais les données restent personnelles (L028)."
}
```

```quiz
{
  "q": "Pourquoi « disponibilité totale exigée » est-il risqué dans une annonce générée ?",
  "options": ["C'est un critère qui peut écarter les parents", "C'est une formule trop longue pour un job board", "C'est une mention réservée aux cadres dirigeants", "C'est une clause interdite par le code du travail"],
  "answer": 0,
  "explanation": "C'est un proxy : un critère d'apparence neutre qui en cache un autre (situation familiale). Test : changez une variable et comparez (L030)."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour utiliser l'IA sur des données salariés, le consentement de chaque salarié est la base légale à privilégier.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. En contexte salarié, le consentement est rarement libre (déséquilibre) ; l'intérêt légitime est la base usuelle, sous trois conditions (L063)."
}
```

## 7. Points de vigilance juridiques

- **AI Act** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA », L063 « Politique IA interne, conformité AI Act et RGPD ») : tri, notation et évaluation des personnes = haut risque (annexe III, au 2 décembre 2027) ; le déployeur assure surveillance humaine, information des personnes et conservation des journaux, et informe salariés et représentants avant tout système à haut risque. Reconnaissance des émotions au travail : interdite. Article 4 : c'est souvent à vous de tracer la formation.
- **RGPD** (L028 « RGPD et données personnelles dans les prompts (CNIL) ») : santé, RQTH, syndicat sont des données sensibles (art. 9) ; jamais sur un compte grand public. AIPD de fait obligatoire pour un système à haut risque. Les décisions entièrement automatisées produisant des effets juridiques sont encadrées.
- **Non-discrimination** (L030 « Droit d'auteur, deepfakes, biais et discriminations ») : interdite que la décision soit humaine ou assistée ; vous devez pouvoir l'expliquer sans dire « c'est l'algorithme ».
- **Dialogue social** : un outil qui modifie les conditions de travail ou permet un contrôle de l'activité suppose l'information-consultation du CSE quand il existe (L063).
- **Confidentialité** : dossiers du personnel et entretiens = niveau « confidentiel » ou « réglementé » de la classification (L063) ; outil sous contrat ou local.

## 8. Certifications tierces (préparation, jamais équivalence)

Aucune certification tierce n'est propre aux RH ; ce parcours **prépare** aux certificats généralistes suivants, sans en être l'équivalent (voir `referentiel/correspondance-certifications.md`) :
- Claude Academy **« AI Fluency: Framework and foundations »** (gratuit, couvert à 100 % par le N1).
- OpenAI Academy, badge **« AI Foundations »** (gratuit, 20 questions, 80 % requis).
- **Google AI Essentials**, dont le cours « Use AI Responsibly » (couvert par M07).
