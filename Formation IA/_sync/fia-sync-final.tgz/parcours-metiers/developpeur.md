# Parcours métier — Développeur·se

> 🧭 Pour les développeurs back-end, front-end et full-stack qui intègrent des LLM dans des produits : API, outils, RAG, agents, mise en production et sécurité. Prérequis : Python ou TypeScript, HTTP et JSON.

## 1. Ce que l'IA change pour vous en 2026

Deux changements se superposent. L'IA **dans** votre travail : Claude Code et les agents de code explorent un dépôt, planifient, modifient et testent (L074 « Claude Code et Claude Agent SDK en pratique »). L'IA **dans** vos produits : un appel de modèle devient une dépendance comme une autre, avec ses coûts au token, ses limites de débit, ses dépréciations et ses failles propres (L067 « Tokens, coûts, rate limits, caching : maîtriser la facture », L106 « OWASP Top 10 pour les applications LLM »).

L'écosystème casse du code : avec la version d'API `2026-10-21` (envoyée par défaut par les SDK v2), `temperature`, `top_p` et `top_k` renvoient une 400 sur tous les modèles Claude ; MCP `2026-07-28` est devenu un protocole sans état ; OpenAI ferme la création de jobs de fine-tuning le 6 janvier 2027 (`_recherche/07`).

Un LLM non déterministe exige **plus** d'ingénierie, pas moins : évaluations en CI, traces et coût par requête (L103, L104), défense contre l'injection de prompt, qui n'a pas de correctif définitif (L107).

## 2. Parcours conseillé

Suivez le **niveau 3 complet** (45 h, certificat Next Formation « Développeur IA »), précédé d'un socle N1 accéléré.

**Socle N1 accéléré** — 7 leçons, 5 h

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L017 | Les guides officiels Anthropic et OpenAI : balises, system prompts, clarté | 50 |
| L027 | MCP (Model Context Protocol) expliqué simplement | 40 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 40 |

**Prioritaires N3 — API, outils, RAG, agents** — 23 leçons, 21 h 10

| Leçon | Titre | Durée (min) |
|---|---|---|
| L065 | Python et TypeScript pour l'IA : environnement, SDK, clés API, secrets | 65 |
| L066 | HTTP, JSON, streaming : anatomie d'un appel à un LLM | 65 |
| L067 | Tokens, coûts, rate limits, caching : maîtriser la facture | 65 |
| L068 | Messages API : requêtes, rôles, paramètres, modèles | 50 |
| L069 | System prompts et prompt engineering avancé (guide officiel Anthropic) | 50 |
| L070 | Tool use : donner des outils à Claude | 50 |
| L071 | Sorties structurées et JSON fiable | 45 |
| L072 | Vision, PDF, Files API et citations | 45 |
| L073 | Prompt caching, Batch API, extended thinking | 50 |
| L074 | Claude Code et Claude Agent SDK en pratique | 50 |
| L075 | MCP : construire un serveur et un client | 50 |
| L076 | Skills, bonnes pratiques et évaluation des prompts | 45 |
| L077 | Projet : assistant métier avec Claude | 65 |
| L088 | Architecture multi-fournisseur : abstraction, routeurs (OpenRouter, LiteLLM), repli | 75 |
| L089 | Embeddings et bases vectorielles : pgvector, Chroma, Qdrant | 55 |
| L090 | Pipeline d'ingestion : parsing, chunking, métadonnées | 55 |
| L092 | Recherche hybride, reranking, requêtes multiples | 50 |
| L093 | Évaluer un RAG : Ragas, jeux de test, métriques | 50 |
| L094 | Projet : RAG documentaire d'entreprise | 65 |
| L095 | La boucle agentique : outils, mémoire, planification | 55 |
| L097 | OpenAI Agents SDK, Claude Agent SDK, Pydantic AI | 55 |
| L099 | Agents, MCP et A2A : interopérabilité | 50 |
| L100 | Projet : agent de recherche et de rédaction autonome | 65 |

**Prioritaires N3 — mise en production et sécurité** — 10 leçons, 9 h 20

| Leçon | Titre | Durée (min) |
|---|---|---|
| L101 | Next.js et Vercel AI SDK : chat en streaming | 60 |
| L102 | Backend : files d'attente, limites, coûts, cache | 50 |
| L103 | Observabilité : Langfuse, LangSmith ; évaluations : promptfoo, DeepEval | 55 |
| L104 | CI/CD et tests de prompts | 45 |
| L105 | Projet : application IA complète déployée | 65 |
| L106 | OWASP Top 10 pour les applications LLM | 55 |
| L107 | Prompt injection directe et indirecte : attaques et défenses | 55 |
| L108 | Guardrails, modération, données personnelles | 55 |
| L109 | Secrets, quotas, abus et coûts | 50 |
| L110 | Audit de sécurité d'une application IA (atelier) | 70 |

**Facultatives** — 6 leçons, 5 h 30. Pour OpenAI, LangChain, LangGraph et le multi-agents.

| Leçon | Titre | Durée (min) |
|---|---|---|
| L078 | Responses API et Chat Completions | 50 |
| L081 | OpenAI Agents SDK | 55 |
| L083 | Projet : le même assistant, porté sur OpenAI | 65 |
| L091 | LangChain et LlamaIndex | 55 |
| L096 | LangGraph : agents à états | 55 |
| L098 | Multi-agents : CrewAI, AutoGen / AG2 | 50 |

> ⏱ **Durée totale du parcours conseillé : 35 h 30** de leçons et d'exercices (quiz de module non compris), **41 h** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

### Cas 1 — Une sortie JSON qui respecte toujours le schéma
Leçon : L071 « Sorties structurées et JSON fiable » — Workflow : schéma JSON → sortie structurée (ou outil en `strict: true`) → validation côté code → test de non-régression.

### Cas 2 — Un outil métier avec confirmation humaine
Leçon : L070 « Tool use : donner des outils à Claude » — Définir l'outil (nom, description, `input_schema`) → le modèle propose l'appel → votre code vérifie les règles métier → l'utilisateur confirme avant toute écriture.

### Cas 3 — Diviser la facture
Leçon : L073 « Prompt caching, Batch API, extended thinking » — Préfixe stable mis en cache (system prompt, documents), traitements non urgents en Batch API, effort de réflexion réglé par tâche.

### Cas 4 — Un serveur MCP pour un outil interne
Leçon : L075 « MCP : construire un serveur et un client » — Exposer deux outils en lecture seule et une ressource ; tester avec l'inspecteur ; ne pas supposer de session (spécification 2026-07-28 sans état).

### Cas 5 — Faire travailler Claude Code sur un dépôt
Leçon : L074 « Claude Code et Claude Agent SDK en pratique »
```text
Lis CLAUDE.md et le dossier src/billing. Propose un plan pour ajouter un export CSV des factures, sans écrire de code. Après validation : implémente, ajoute les tests, lance la suite, résume les fichiers modifiés.
```

### Cas 6 — Un RAG hybride qui cite et filtre
Leçon : L092 « Recherche hybride, reranking, requêtes multiples » — Recherche lexicale + vectorielle, reranking, filtre par droits d'accès **avant** la génération, citations obligatoires dans la réponse.

### Cas 7 — Des tests de prompts en CI
Leçon : L104 « CI/CD et tests de prompts » — Jeu de cas versionné, assertions déterministes (`is-json`, contenu attendu) et notées par un modèle, seuil bloquant dans le pipeline.

### Cas 8 — Plusieurs fournisseurs, un seul code
Leçon : L088 « Architecture multi-fournisseur : abstraction, routeurs (OpenRouter, LiteLLM), repli » — Interface interne, routeur (LiteLLM ou OpenRouter), nouvelles tentatives sur 429, 5xx et timeouts, puis repli sur le fournisseur suivant ; tests identiques pour tous.

### Cas 9 — Résister à l'injection indirecte
Leçon : L107 « Prompt injection directe et indirecte : attaques et défenses » — Contenus externes traités comme données, moindre privilège, confirmation des actions sensibles.

### Cas 10 — Revue de code assistée
Leçon : L074 « Claude Code et Claude Agent SDK en pratique »
```text
Relis ce diff comme un ingénieur senior. Signale par ordre de gravité : failles de sécurité (secrets, injection), erreurs de logique, cas limites non testés. Pour chaque point : fichier, ligne, correction proposée. N'invente pas de problème.
```

## 4. Trois projets fil rouge

### Projet 1 — L'assistant métier outillé et portable
- **Énoncé** : un assistant de devis (outils, confirmation humaine, contrôles métier, coûts), puis son portage sur un second fournisseur.
- **Livrable** : code Python ou TypeScript, tests verts dans les deux versions, note de coût.
- **Critères de réussite** : aucun prix modifié par le modèle ; les tests passent à l'identique après portage ; coût par conversation mesuré.
- **Leçons** : L070, L071, L077, L083 · **Labs** : [`lab-claude-devis`](../labs/lab-claude-devis/), [`lab-openai-portage`](../labs/lab-openai-portage/).

### Projet 2 — Le RAG documentaire d'entreprise
- **Énoncé** : une API de questions-réponses sur une base documentaire, avec droits d'accès.
- **Livrable** : FastAPI + pgvector, recherche hybride, citations, jeu d'évaluation.
- **Critères de réussite** : un utilisateur ne récupère jamais un passage auquel il n'a pas droit ; métriques de récupération mesurées avant et après réglage.
- **Leçons** : L089, L090, L092, L093, L094 · **Lab** : [`lab-rag-code`](../labs/lab-rag-code/).

### Projet 3 — L'application déployée et auditée
- **Énoncé** : un chat en streaming authentifié et borné en coût, déployé puis audité.
- **Livrable** : application Next.js, Docker et Caddy HTTPS, checklist de mise en production, rapport d'audit.
- **Critères de réussite** : quotas par utilisateur actifs ; aucun secret côté client ; chaque vulnérabilité du rapport a une correction ou un risque accepté.
- **Leçons** : L101, L105, L106, L109, L110 · **Lab** : [`lab-app-deployee`](../labs/lab-app-deployee/) puis l'atelier de L110 (environnement isolé, mandat écrit).

## 5. Missions documentation

**Mission 1** · L071 — Fiabiliser les appels d'outils de votre backend.

```mission
{
  "title": "Des arguments d'outil qui respectent toujours le schéma",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use",
  "steps": [
    "Ouvrez la page « Strict tool use »",
    "Repérez l'exemple de définition d'outil en mode strict",
    "Observez à quel niveau se trouve le champ strict, puis lisez ce que la page promet sur les arguments produits"
  ],
  "question": "À quel niveau de la définition d'outil se place le champ strict, et que garantit-il ?",
  "hint": "Comparez avec les trois champs name / description / input_schema vus en L070.",
  "answer": "strict: true se place au premier niveau de la définition, à côté de name, description et input_schema ; il garantit que les arguments de l'appel respectent exactement le schéma (types, champs requis), avec un sous-ensemble de JSON Schema supporté (page consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 2** · L067 — Dimensionner les relances et les files d'attente.

```mission
{
  "title": "Les en-têtes qui annoncent un 429",
  "url": "https://platform.claude.com/docs/en/api/rate-limits",
  "steps": [
    "Ouvrez la page Rate limits de la documentation Claude Platform",
    "Relevez le nom des paliers d'usage (usage tiers) et le plafond de dépenses mensuel du palier Build",
    "Cherchez le préfixe des en-têtes de réponse qui indiquent vos limites restantes, et le code HTTP renvoyé en cas de dépassement"
  ],
  "question": "Quels sont les paliers d'usage d'Anthropic, quel préfixe portent les en-têtes de limite, et quel code d'erreur signale un dépassement ?",
  "hint": "Cinq paliers, du test au sur-mesure ; les en-têtes commencent par le nom de l'entreprise ; le code d'erreur est celui du guichet saturé.",
  "answer": "Evaluation, Start, Build, Scale et Custom (plafonds de dépenses mensuels : 500 $, 1 000 $ et 200 000 $ pour Start, Build et Scale) ; en-têtes anthropic-ratelimit-* (plus retry-after) ; erreur 429 rate_limit_error (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 3** · L072 — Récupérer le passage cité pour l'afficher à l'utilisateur.

```mission
{
  "title": "Afficher la citation exacte dans votre interface",
  "url": "https://platform.claude.com/docs/en/build-with-claude/citations",
  "steps": [
    "Ouvrez la page « Citations »",
    "Repérez un exemple de réponse JSON contenant un tableau citations",
    "Notez le nom du champ qui contient le passage exact, puis cherchez (Ctrl+F) « output tokens » pour la règle de facturation"
  ],
  "question": "Quel champ d'une citation contient le texte exact du document, et compte-t-il dans les tokens de sortie facturés ?",
  "hint": "Le nom du champ est en anglais et en snake_case ; le code citations.py l'affiche.",
  "answer": "Le champ cited_text ; il n'est pas comptabilisé dans les tokens de sortie (documentation consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 4** · L103 — Écrire le premier test de prompt de votre pipeline.

```mission
{
  "title": "Tester en CI qu'une sortie est un JSON valide",
  "url": "https://www.promptfoo.dev/docs",
  "steps": [
    "Ouvrez la documentation promptfoo",
    "Allez dans la référence des assertions (« Assertions & metrics »)",
    "Cherchez les assertions déterministes liées au format"
  ],
  "question": "Quel type d'assertion vérifie qu'une sortie est un JSON valide, et peut-on lui fournir un schéma ?",
  "hint": "La configuration de la section 3.1 de la leçon L103 l'utilise dans le cas « Sortie JSON pour l'export ».",
  "answer": "`is-json` ; on peut lui passer un schéma JSON dans `value` pour vérifier la structure (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 5** · L027 — Trouver le paramètre qui déclare vos serveurs MCP.

```mission
{
  "title": "Brancher un serveur MCP distant depuis l'API",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/mcp-connector",
  "steps": [
    "Ouvrez la page MCP connector de Claude Platform",
    "Repérez l'exemple de requête",
    "Notez le nom du paramètre qui liste les serveurs distants"
  ],
  "question": "Quel paramètre de la requête permet de donner à Claude l'adresse d'un serveur MCP distant ?",
  "hint": "Il porte le nom du protocole, au pluriel.",
  "answer": "`mcp_servers` (associé à un `mcp_toolset` dans les outils ; fonctionnalité en bêta avec un en-tête dédié — doc lue en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```


## 6. Quiz éclair

```quiz
{
  "q": "Après la mise à jour vers le SDK Python 2.0, une requête qui envoie temperature=1.0 renvoie une 400. Pourquoi ?",
  "options": ["La clé d'API a expiré avec la mise à jour", "La version d'API 2026-10-21 refuse ce paramètre", "La valeur 1.0 dépasse la plage autorisée par l'API", "Le modèle choisi a été retiré de l'API publique"],
  "answer": 1,
  "explanation": "Les SDK v2 envoient la version 2026-10-21 : temperature, top_p et top_k y renvoient une 400 sur tous les modèles, même à leur valeur par défaut (_recherche/07)."
}
```

```quiz
{
  "q": "Qu'est-ce qui change pour votre serveur MCP avec la spécification stable 2026-07-28 ?",
  "options": ["Le protocole passe sur gRPC uniquement", "Le protocole devient sans état", "Les outils doivent être écrits en Rust", "Le transport stdio est supprimé"],
  "answer": 1,
  "explanation": "Plus d'initialize ni d'ID de session : version et capacités voyagent avec chaque requête ; Roots, Sampling, Logging et HTTP+SSE sont dépréciés (_recherche/07)."
}
```

```quiz
{
  "q": "Quel risque occupe la première place (LLM01) de l'OWASP Top 10 for LLM Applications 2026 ?",
  "options": ["Excessive Agency", "Prompt Injection", "Data and Model Poisoning", "Misinformation"],
  "answer": 1,
  "explanation": "LLM01 Prompt Injection, puis LLM02 Sensitive Information Disclosure et LLM03 Excessive Agency (L106, _recherche/07)."
}
```

```quiz
{
  "q": "Vous forcez tool_choice de type « tool » sur Claude Opus 5.5. Que se passe-t-il ?",
  "options": ["L'outil est appelé normalement", "Une erreur 400 est renvoyée", "Le paramètre est ignoré en silence", "La réflexion est désactivée seule"],
  "answer": 1,
  "explanation": "Opus 5.5 et Sonnet 5.5 rejettent le forçage en 400 ; Haiku 5.5 l'accepte, mais sans bloc de réflexion (_recherche/07)."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : placer la clé d'API dans le code client de l'application est acceptable si le dépôt Git est privé.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Tout ce qui part au navigateur est lisible par l'utilisateur ; la clé reste côté serveur, dans l'environnement, avec quotas et rotation (L031, L109)."
}
```

## 7. Points de vigilance juridiques

- **AI Act** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA ») : en mettant sur le marché un système sous votre nom, votre entreprise devient **fournisseur** ; un chatbot doit indiquer qu'il est une IA (art. 50, depuis le 2 août 2026) ; un usage de l'annexe III (RH, crédit, éducation…) se repère dès la conception.
- **RGPD** (L028 « RGPD et données personnelles dans les prompts (CNIL) », L063 « Politique IA interne, conformité AI Act et RGPD », L108 « Guardrails, modération, données personnelles ») : protection dès la conception ; minimisation des prompts et des journaux (traces Langfuse, logs) ; contrat de sous-traitance et durée de conservation du fournisseur ; filtrage des données personnelles en entrée et en sortie.
- **Secret professionnel** (L062) : si vos utilisateurs y sont soumis, l'architecture se décide avant le code.
- **Propriété intellectuelle** (L030 « Droit d'auteur, deepfakes, biais et discriminations », L045 « Choisir le meilleur modèle ouvert : Llama, Qwen, Mistral, Gemma, DeepSeek, gpt-oss ») : licences des modèles ouverts (Apache 2.0, MIT, licences communautaires ou non commerciales) à lire avant tout usage commercial ; SDK Anthropic v2 sous Apache 2.0 ; un code généré sans apport humain est peu protégé.
- **Sécurité** (L106 « OWASP Top 10 pour les applications LLM », L109 « Secrets, quotas, abus et coûts ») : OWASP LLM Top 10 2026, secrets hors du code, quotas et plafonds de dépense (consommation non bornée).

## 8. Certifications tierces (préparation, jamais équivalence)

Ce parcours **prépare** aux certificats suivants, sans en être l'équivalent ni être reconnu par leurs éditeurs (voir `referentiel/correspondance-certifications.md`) :
- Claude Academy : **« Building with the Claude API »** (9 h), **« Claude Code 101 »**, **« Introduction to Model Context Protocol »** (badges gratuits).
- **Claude Certified Developer – Foundations** (125 $, 120 min, seuil 720, validité 12 mois) : domaines couverts à 95-100 %, mais examen **réservé aux organisations du Claude Partner Network**.
- Hugging Face **Agents Course** et **MCP Course** (certificats gratuits) ; OpenAI Academy « Build with AI ».
