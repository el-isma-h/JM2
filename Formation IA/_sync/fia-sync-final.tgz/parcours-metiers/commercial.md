# Parcours métier — Commercial

> 🧭 Pour les commerciaux terrain et sédentaires, chargés d'affaires, account managers et directeurs commerciaux qui veulent mieux préparer leurs rendez-vous, écrire plus vite et nourrir leur CRM sans ressaisie. Aucun prérequis technique.

## 1. Ce que l'IA change pour vous en 2026

L'IA ne vend pas à votre place : la relation, l'écoute et la négociation restent humaines. Elle vous rend en revanche du temps sur tout ce qui entoure le rendez-vous. Avant : une fiche prospect construite à partir de sources publiques citées (L013 « Perplexity et la recherche augmentée par l'IA »). Après : un compte rendu structuré, une relance et une proposition rédigées à partir de vos notes (L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique »). Entre les deux : un CRM rempli automatiquement plutôt qu'à la main (L036 « Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks »).

Le piège principal est connu : un modèle qui « arrondit » un prix, invente un délai ou promet une prestation absente de vos notes. Une proposition commerciale engage l'entreprise ; elle reste en vérification 🔴. Le second piège est la confidentialité : un compte rendu de rendez-vous contient le nom, le budget et les enjeux du client, des données « confidentielles » qui n'ont rien à faire sur un compte personnel (L063 « Politique IA interne, conformité AI Act et RGPD »).

Les agents (des assistants qui enchaînent eux-mêmes plusieurs actions) arrivent aussi dans les équipes commerciales (L026 « Qu'est-ce qu'un agent IA ? »). Ils sont utiles pour préparer, chercher et résumer ; ils ne doivent pas envoyer seuls un devis à un client.

## 2. Parcours conseillé

Le **niveau 1 complet** (25 h) donne le certificat « Utilisateur IA certifié » ; le parcours ci-dessous en garde l'essentiel et ajoute quatre leçons d'automatisation et d'assistants du niveau 2.

**Socle N1** — 17 leçons, 12 h 05

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L015 | Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes | 45 |
| L016 | Techniques : exemples (few-shot), raisonnement pas à pas, décomposition | 45 |
| L018 | Prompts métiers : rédiger, résumer, analyser, traduire, tabuler | 45 |
| L019 | Itérer et évaluer : bibliothèque de prompts personnelle | 40 |
| L021 | Cas d'usage par métier : RH, vente, marketing, finance, support, juridique | 45 |
| L022 | Productivité : documents, e-mails, réunions, tableurs, présentations | 45 |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 |
| L030 | Droit d'auteur, deepfakes, biais et discriminations | 40 |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 40 |
| L010 | ChatGPT : prise en main complète | 40 |
| L013 | Perplexity et la recherche augmentée par l'IA | 40 |
| L025 | n8n : découverte et premier workflow (aligné n8n Level 1) | 50 |
| L026 | Qu'est-ce qu'un agent IA ? | 40 |

**Prioritaires N2** — 4 leçons, 3 h 50

| Leçon | Titre | Durée (min) |
|---|---|---|
| L036 | Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks | 55 |
| L050 | Projets Claude, GPT personnalisés, Gems : la connaissance embarquée | 55 |
| L051 | Custom GPT, Projets Claude, Copilot Studio | 60 |
| L052 | Agents multi-outils dans n8n | 60 |

**Facultatives** — 7 leçons, 7 h. Pour automatiser davantage le CRM ou analyser vos ventes.

| Leçon | Titre | Durée (min) |
|---|---|---|
| L038 | Projet : assistant de support client automatisé | 65 |
| L039 | Make : scénarios avec modules IA | 60 |
| L040 | Zapier, comparatif et grille de choix | 60 |
| L053 | Claude Code, Lovable, Bolt, v0 : créer une application sans coder | 65 |
| L054 | Computer use et navigateurs IA | 50 |
| L055 | Analyser un fichier CSV / Excel avec ChatGPT et Claude | 60 |
| L056 | Visualisations et rapports générés | 60 |

> ⏱ **Durée totale du parcours conseillé : 15 h 55** de leçons et d'exercices (quiz de module non compris), **22 h 55** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

🟢 relecture rapide · 🟠 contrôle des faits · 🔴 validation experte (L021).

### Cas 1 — Fiche prospect sourcée
Leçon : L013 « Perplexity et la recherche augmentée par l'IA » · 🟠
```text
Prépare une fiche sur l'entreprise ci-dessous : activité, taille, actualités des 12 derniers mois, interlocuteurs publics, 3 enjeux probables pour notre offre. Chaque fait avec sa source et sa date ; écris « non trouvé » plutôt que de supposer.
```

### Cas 2 — Proposition commerciale d'une page
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🔴
```text
Rôle : directeur commercial d'une société de nettoyage industriel. Contexte : notes de rendez-vous et grille tarifaire ci-dessous. Tâche : proposition d'une page (besoin, solution, planning, tarif, prochaines étapes). Contraintes : reprends EXACTEMENT les prix de la grille ; ne promets rien d'absent de mes notes ; liste les points à confirmer.
```

### Cas 3 — Réponses aux objections
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🟢 — Notes CRM anonymisées de 3 mois → objections classées par fréquence → une réponse type et une question de relance pour chacune.

### Cas 4 — Relance après rendez-vous
Leçon : L022 « Productivité : documents, e-mails, réunions, tableurs, présentations » · 🟢
```text
Rédige un e-mail de relance de 120 mots à partir de ce compte rendu : remerciement, rappel des 2 besoins exprimés, prochaine étape datée. Vouvoiement, aucun engagement nouveau.
```

### Cas 5 — Du compte rendu au CRM
Leçon : L018 « Prompts métiers : rédiger, résumer, analyser, traduire, tabuler » · 🟠
```text
Extrais de ces notes : entreprise, interlocuteur, besoin, budget, échéance, concurrents cités, prochaine action. Format : une ligne par champ. Si une information est absente, écris « absente ».
```

### Cas 6 — Préparer une négociation
Leçon : L016 « Techniques : exemples (few-shot), raisonnement pas à pas, décomposition » · 🟢 — Décomposition : objectifs et limites → 3 scénarios de réaction de l'acheteur → contre-propositions possibles pour chacun.

### Cas 7 — L'assistant « offre et tarifs »
Leçon : L050 « Projets Claude, GPT personnalisés, Gems : la connaissance embarquée » · 🟠 — Projet Claude ou GPT personnalisé nourri du catalogue et des conditions générales, qui répond aux questions de l'équipe en citant le document.

### Cas 8 — Enrichir le CRM après un formulaire web
Leçon : L036 « Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks » · 🟠 — Workflow n8n : webhook du formulaire → résumé et catégorie par l'IA → création du contact dans HubSpot ou Pipedrive → alerte Slack au commercial.

### Cas 9 — Un agent de préparation des rendez-vous
Leçon : L052 « Agents multi-outils dans n8n » · 🟠 — Agent n8n avec outils en lecture seule (CRM, recherche web), limite d'itérations et journal ; il prépare, vous validez.

### Cas 10 — Adapter une offre pour un prospect étranger
Leçon : L018 « Prompts métiers : rédiger, résumer, analyser, traduire, tabuler » · 🟠
```text
Traduis cette proposition en anglais commercial britannique. Garde les montants, unités et références à l'identique ; signale les termes juridiques qui méritent une relecture.
```

## 4. Trois projets fil rouge

### Projet 1 — Le dossier de préparation de compte
- **Énoncé** : préparer un rendez-vous stratégique sur un compte cible.
- **Livrable** : fiche prospect sourcée, plan de découverte (10 questions), carte des interlocuteurs.
- **Critères de réussite** : chaque fait a une source vérifiée ; aucun chiffre non sourcé ; le plan tient sur une page.
- **Leçons** : L013, L018, L023 · **Lab** : aucun ; pour les profils techniques, [`lab-agent-recherche`](../labs/lab-agent-recherche/) montre la même démarche automatisée.

### Projet 2 — Le générateur de propositions commerciales
- **Énoncé** : produire une proposition fiable à partir de notes et d'une grille tarifaire.
- **Livrable** : assistant spécialisé (instructions, grille, modèles) + 5 propositions de test.
- **Critères de réussite** : 5 sur 5 sans prix modifié ; les points à confirmer sont listés ; aucune promesse hors notes.
- **Leçons** : L021, L050, L051 · **Lab** : [`lab-claude-devis`](../labs/lab-claude-devis/) en démonstration (mode sans clé, avec un collègue technique) pour voir des contrôles métier sur les prix.

### Projet 3 — La qualification automatique des leads
- **Énoncé** : chaque demande entrante est résumée, classée et routée vers le bon commercial.
- **Livrable** : workflow n8n (webhook → classification → validation → CRM → Slack), jeu de 20 demandes de test.
- **Critères de réussite** : au moins 18 classements corrects sur 20 ; aucune création de contact sans validation ; erreurs notifiées.
- **Leçons** : L025, L036, L052 · **Lab** : [`lab-n8n-support`](../labs/lab-n8n-support/), même architecture à adapter.

## 5. Missions documentation

**Mission 1** · L013 — Chiffrer des recherches web automatisées sur vos comptes cibles.

```mission
{
  "title": "Le coût d'une veille prospects automatisée",
  "url": "https://docs.perplexity.ai/getting-started/pricing",
  "steps": [
    "Ouvrez la page de tarifs de la documentation Perplexity",
    "Repérez la rubrique « Search API »",
    "Lisez le prix standard et celui du mode rapide (Fast)"
  ],
  "question": "Combien coûtent 1 000 requêtes réussies avec la Search API de Perplexity, en mode standard et en mode rapide ?",
  "hint": "Le prix est exprimé « pour 1 000 requêtes » et non au token.",
  "answer": "5 $ pour 1 000 requêtes en mode standard, 1 $ en mode rapide (Fast) — relevé de nov. 2026, les prix évoluent.",
  "xp": 10
}
```

**Mission 2** · L023 — Repérer le mécanisme de citation qui sécurise vos fiches prospects.

```mission
{
  "title": "Faire citer la source exacte d'un chiffre client",
  "url": "https://platform.claude.com/docs/en/build-with-claude/citations",
  "steps": [
    "Ouvrez la page Citations de la documentation Claude",
    "Repérez le champ qui contient le passage exact cité du document",
    "Cherchez ce qui est dit sur la facturation de ce passage"
  ],
  "question": "Comment s'appelle le champ qui renvoie l'extrait exact du document source, et est-il facturé comme des tokens de sortie ?",
  "hint": "Le nom du champ associe « cited » et « text ».",
  "answer": "Le champ `cited_text` ; il n'est pas compté comme tokens de sortie (doc lue en nov. 2026, conditions susceptibles d'évoluer) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 3** · L052 — Savoir où un agent n8n peut répondre à l'équipe commerciale.

```mission
{
  "title": "Un agent commercial dans Slack ou Teams",
  "url": "https://docs.n8n.io/build/build-and-manage-agents.md",
  "steps": [
    "Ouvrez la page « Build and manage agents » de la documentation n8n",
    "Repérez la liste des canaux dans lesquels un agent peut être publié",
    "Cherchez le nom du nœud qui permet d'appeler un agent depuis un workflow, et la façon dont les exécutions sont comptées"
  ],
  "question": "Dans quels canaux un agent de l'Agent Builder peut-il être déployé, quel nœud l'appelle depuis un workflow, et comment un tour de conversation est-il compté ?",
  "hint": "Le nœud porte un nom très explicite qui commence par « Message ».",
  "answer": "Slack, Telegram, Linear et Microsoft Teams (plus la planification cron) ; nœud « Message an Agent » ; chaque tour de conversation compte comme une exécution — fonctionnalité en préversion, relevé nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 4** · L022 — Vérifier les formats de fichiers que Claude sait produire.

```mission
{
  "title": "Votre proposition en PowerPoint ou en PDF",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview",
  "steps": [
    "Ouvrez la page Agent Skills overview",
    "Cherchez la partie sur les skills pré-construits (pre-built Agent Skills)",
    "Notez la liste des formats de fichiers couverts"
  ],
  "question": "Quels quatre types de fichiers bureautiques les skills pré-construits d'Anthropic permettent-ils de créer ?",
  "hint": "Pensez aux extensions des logiciels Word, Excel, PowerPoint… et au format d'impression universel.",
  "answer": "PowerPoint (.pptx), Excel (.xlsx), Word (.docx) et PDF (nov. 2026 — la liste peut s'allonger) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 5** · L021 — Retrouver le cadre 4D qui structure vos délégations.

```mission
{
  "title": "Les quatre compétences pour déléguer à l'IA",
  "url": "https://academy.claude.com/courses/ai-fluency-framework-foundations",
  "steps": [
    "Ouvrez la page du cours AI Fluency: Framework and foundations",
    "Parcourez le plan du cours",
    "Repérez les chapitres consacrés à chacun des quatre « D »"
  ],
  "question": "Quels sont les quatre « D » du cadre, et dans quel ordre le cours les aborde-t-il ?",
  "hint": "Le premier est justement celui travaillé dans la leçon L021.",
  "answer": "Delegation, Description, Discernment, Diligence (dans cet ordre) — cours d'environ 4 h, plan lu le 1er nov. 2026.",
  "xp": 10
}
```


## 6. Quiz éclair

```quiz
{
  "q": "Vous voulez coller dans ChatGPT, sur votre compte personnel gratuit, un compte rendu avec le nom et le budget du client. Que dit la classification ?",
  "options": ["Autorisé si le texte tient sur moins d'une page", "Non : données confidentielles, outil sous contrat", "Autorisé si vous effacez l'historique ensuite", "Autorisé puisque l'usage reste professionnel"],
  "answer": 1,
  "explanation": "Des données clients sont de niveau 3 (confidentiel) : SaaS entreprise ou API sous contrat, ou local, de préférence après pseudonymisation (L063)."
}
```

```quiz
{
  "q": "Dans la proposition générée, un tarif de 1 240 € est devenu 1 200 €. Quelle consigne aurait évité l'erreur ?",
  "options": ["« Sois précis et professionnel »", "« Reprends EXACTEMENT la grille »", "« Arrondis pour plus de lisibilité »", "« Utilise un ton plus commercial »"],
  "answer": 1,
  "explanation": "La contrainte explicite « reprends exactement les prix de la grille, sans en inventer » et une vérification 🔴 (L021)."
}
```

```quiz
{
  "q": "Le chatbot du site a promis à un client une remise qui n'existe pas. Qui est engagé ?",
  "options": ["Personne, c'est une erreur de machine", "L'éditeur du modèle de langage utilisé", "L'entreprise qui exploite le chatbot", "Le client qui a mal posé sa question"],
  "answer": 2,
  "explanation": "Affaire Air Canada (2024) : une règle inventée par le chatbot a engagé l'entreprise. D'où la consigne « applique strictement la politique fournie » (L021, L023)."
}
```

```quiz
{
  "q": "Un « client » vous écrit pour changer en urgence l'IBAN de paiement d'une commande. Que faites-vous ?",
  "options": ["Je transmets à la comptabilité sans délai", "Je réponds à l'e-mail pour confirmer", "J'appelle le client à un numéro connu", "J'attends une seconde relance écrite"],
  "answer": 2,
  "explanation": "Règle du double canal : on vérifie par un canal indépendant déjà connu, jamais par celui de la demande (L031)."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un agent qui envoie seul les devis aux clients est un bon premier projet d'agent.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Un envoi au client est irréversible et engage l'entreprise : validation humaine obligatoire, outils en lecture seule d'abord (L052)."
}
```

## 7. Points de vigilance juridiques

- **RGPD** (L028 « RGPD et données personnelles dans les prompts (CNIL) », L063 « Politique IA interne, conformité AI Act et RGPD ») : prospects et clients sont des personnes ; finalité précise, minimisation, outil sous contrat (art. 28), traçabilité de ce qui est envoyé à quel outil, car le client peut vous demander ce que vous avez fait de ses données. Une fiche prospect se limite aux informations professionnelles publiques utiles.
- **AI Act** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA ») : un chatbot ou un agent conversationnel au contact des clients doit dire qu'il est une IA (art. 50, depuis le 2 août 2026). L'octroi de crédit à un client relève du haut risque (annexe III).
- **Engagement contractuel** (L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique ») : une proposition ou une réponse générée engage l'entreprise ; prix, délais et garanties toujours vérifiés.
- **Secret des affaires** : grilles de prix d'achat, marges, contrats non signés = confidentiel, jamais sur un compte personnel (L028).
- **Fraude** (L031 « Sécurité au quotidien : clés, phishing IA, shadow AI ») : faux client, faux fournisseur, voix clonée ; double canal avant tout changement de coordonnées bancaires.

## 8. Certifications tierces (préparation, jamais équivalence)

Ce parcours **prépare** aux certificats suivants, sans en être l'équivalent ni être reconnu par leurs éditeurs (voir `referentiel/correspondance-certifications.md`) :
- Claude Academy **« Claude 101 »** (gratuit), dont la leçon « use-cases by role ».
- OpenAI Academy : **« Applied AI Foundations »** et **« Agents and Workflows »** (badges gratuits, couverts à environ 90 %).
- **n8n Academy** N8N101 à N8N103 : certificats de complétion, que n8n présente comme « not a certification » ; la certification officielle, repoussée à fin T4 2026, n'était pas ouverte au 5 nov. 2026.
