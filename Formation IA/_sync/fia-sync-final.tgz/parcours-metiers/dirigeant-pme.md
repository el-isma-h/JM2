# Parcours métier — Dirigeant·e de PME

> 🧭 Pour les dirigeants de TPE et PME, gérants, associés et directeurs généraux qui veulent décider où l'IA rapporte, la déployer sans risque juridique et former leurs équipes. Aucun prérequis technique.

## 1. Ce que l'IA change pour vous en 2026

Selon l'AI Index 2026 de Stanford, l'IA générative a atteint 53 % d'adoption en trois ans ; mais au lancement du plan *Osez l'IA* (juillet 2025), seules 8 % des TPE et 13 % des PME françaises utilisaient une IA « clé en main » (L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique »). Ceux qui structurent leurs usages maintenant prennent une avance réelle, mais modeste.

L'IA vous fait gagner du temps sur le texte et les chiffres : comptes rendus, courriers, synthèses de devis, notes à la banque, procédures. Elle ne décide pas, ne signe rien et se trompe avec aplomb (L008 « Fenêtre de contexte, température, hallucinations : les limites à connaître ») : voyez-la comme un stagiaire très rapide qui ne connaît pas votre entreprise.

Trois changements vous concernent directement en tant que chef d'entreprise :
- **Une obligation de formation** : article 4 de l'AI Act, depuis le 2 février 2025, contrôlé depuis le 2 août 2026 (L029).
- **Un choix d'architecture** : SaaS, API ou local ; c'est souvent la sensibilité des données, pas le prix, qui tranche (L062).
- **Des risques nouveaux** : shadow AI (comptes personnels) et fraude au président par voix clonée (L031).

## 2. Parcours conseillé

Pour le certificat « Utilisateur IA certifié », suivez le **niveau 1 complet** (25 h). Le parcours ci-dessous en retient l'essentiel et y ajoute le module **M15** et trois leçons des modules M10 à M12 du niveau 2.

**Socle N1 — comprendre, demander, vérifier, rester conforme** — 15 leçons, 10 h 40

| Leçon | Titre | Durée (min) |
|---|---|---|
| L004 | Mythes, réalités et chiffres clés de l'IA en 2026 | 40 |
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L009 | Panorama des modèles 2026 : Claude, GPT, Gemini, Grok, Mistral, Llama, DeepSeek, Qwen | 50 |
| L012 | Gemini, Copilot, Grok, Le Chat : forces et usages | 40 |
| L015 | Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes | 45 |
| L018 | Prompts métiers : rédiger, résumer, analyser, traduire, tabuler | 45 |
| L021 | Cas d'usage par métier : RH, vente, marketing, finance, support, juridique | 45 |
| L022 | Productivité : documents, e-mails, réunions, tableurs, présentations | 45 |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 |
| L026 | Qu'est-ce qu'un agent IA ? | 40 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 |
| L030 | Droit d'auteur, deepfakes, biais et discriminations | 40 |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 40 |

**Prioritaires N2 — décider, cadrer, déployer** — 6 leçons, 5 h 30

| Leçon | Titre | Durée (min) |
|---|---|---|
| L041 | Pourquoi un LLM local : confidentialité, coût, latence, souveraineté | 45 |
| L050 | Projets Claude, GPT personnalisés, Gems : la connaissance embarquée | 55 |
| L051 | Custom GPT, Projets Claude, Copilot Studio | 60 |
| L062 | SaaS, API ou local : coûts, risques, grille de décision | 60 |
| L063 | Politique IA interne, conformité AI Act et RGPD | 60 |
| L064 | Conduite du changement et montée en compétence des équipes | 50 |

**Facultatives** — 7 leçons, 6 h. Pour tester vous-même un outil, une automatisation ou une petite application avant d'en confier le déploiement.

| Leçon | Titre | Durée (min) |
|---|---|---|
| L010 | ChatGPT : prise en main complète | 40 |
| L011 | Claude : conversations, projets, artefacts et premiers pas avec Claude Code | 45 |
| L013 | Perplexity et la recherche augmentée par l'IA | 40 |
| L025 | n8n : découverte et premier workflow (aligné n8n Level 1) | 50 |
| L040 | Zapier, comparatif et grille de choix | 60 |
| L053 | Claude Code, Lovable, Bolt, v0 : créer une application sans coder | 65 |
| L058 | Automatiser un reporting hebdomadaire | 60 |

> ⏱ **Durée totale du parcours conseillé : 16 h 10** de leçons et d'exercices (quiz de module non compris), **22 h 10** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

Niveau de vérification : 🟢 relecture rapide · 🟠 contrôle des faits · 🔴 validation experte (L021).

### Cas 1 — Compte rendu du comité de direction
Leçon : L022 « Productivité : documents, e-mails, réunions, tableurs, présentations » · 🟠
```text
À partir de cette transcription, rédige le compte rendu : décisions, actions (tableau action / responsable / échéance), points en suspens. N'attribue une action que si c'est explicite ; sinon écris « responsable à définir ».
```

### Cas 2 — Argumentaire pour la banque
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🔴
```text
Rôle : directeur financier. Contexte : prévisionnel et historique ci-dessous. Tâche : argumentaire de 1 page pour un prêt de 150 k€. Contraintes : n'utilise que les chiffres fournis ; liste à la fin les questions qu'un banquier poserait.
```

### Cas 3 — Comparer trois devis fournisseurs
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🔴 — Grille critère × fournisseur, chiffres repris tels quels avec la page du devis, aucun « gagnant » désigné : c'est vous qui décidez.

### Cas 4 — Choisir l'assistant de l'entreprise
Leçon : L012 « Gemini, Copilot, Grok, Le Chat : forces et usages » · 🟢
```text
Nous sommes 25 personnes, sous Microsoft 365, avec des données clients. Compare Copilot, Claude, ChatGPT et Le Chat sur : intégration, confidentialité, coût par utilisateur, sources. Tableau, puis 3 questions à poser à chaque éditeur.
```

### Cas 5 — Rédiger la charte d'usage IA
Leçon : L028 « RGPD et données personnelles dans les prompts (CNIL) » · 🟠 — Ébauche générée à partir du modèle de la leçon, puis relue par le DPO ou le conseil.

### Cas 6 — Calculer un coût total de possession
Leçon : L062 « SaaS, API ou local : coûts, risques, grille de décision » · 🟠 — Workflow : lister les usages → estimer les tokens par mois → appliquer les tarifs publics datés → ajouter le temps humain sur 3 ans → comparer SaaS, API et local.

### Cas 7 — Tenir le registre des usages IA
Leçon : L063 « Politique IA interne, conformité AI Act et RGPD » · 🟠 — Un tableau d'une ligne par usage : finalité, outil, niveau de données, risque AI Act, contrôle humain, date de revue.

### Cas 8 — Assistant « procédures maison »
Leçon : L050 « Projets Claude, GPT personnalisés, Gems : la connaissance embarquée » · 🟠 — Un Projet Claude ou un GPT personnalisé nourri de vos procédures (jamais de données sensibles), consigne « réponds uniquement d'après les documents ».

### Cas 9 — Préparer le pilote IA
Leçon : L064 « Conduite du changement et montée en compétence des équipes » · 🟢
```text
Propose un pilote IA de 6 semaines pour notre service administratif (8 personnes) : objectif chiffré, indicateurs avant/après, champions, risques, bilan. Signale les hypothèses que je dois valider.
```

### Cas 10 — Identifier un usage d'agent réaliste
Leçon : L026 « Qu'est-ce qu'un agent IA ? » · 🟢 — Objectif, outils autorisés (lecture seule d'abord), validation humaine avant toute action irréversible.

## 4. Trois projets fil rouge

### Projet 1 — La politique IA de votre entreprise
- **Énoncé** : rédiger la politique IA d'une PME de 20 à 50 salariés.
- **Livrable** : charte, classification des données en 4 niveaux, registre de 5 usages, 10 questions au fournisseur.
- **Critères de réussite** : chaque usage a un niveau de données et un contrôle humain ; la charte tient sur deux pages ; le plan de formation art. 4 est tracé par population.
- **Leçons** : L028, L029, L063, L064 · **Lab** : aucun, exercice de L063.

### Projet 2 — Le tableau de bord hebdomadaire de direction
- **Énoncé** : automatiser la note du lundi à partir d'un tableur d'indicateurs.
- **Livrable** : workflow planifié + modèle de note + règle d'alerte.
- **Critères de réussite** : le code calcule, le modèle rédige, le code contrôle ; aucun chiffre inventé sur 4 semaines de test.
- **Leçons** : L025, L058 · **Lab** : [`lab-reporting`](../labs/lab-reporting/) (mode sans clé).

### Projet 3 — L'assistant de connaissances internes
- **Énoncé** : rendre vos procédures interrogeables par l'équipe.
- **Livrable** : base documentaire + 10 questions de test notées + note de décision SaaS / local.
- **Critères de réussite** : au moins 8 réponses sur 10 correctes et sourcées ; choix d'hébergement justifié par la grille de L062.
- **Leçons** : L041, L048, L050, L062 · **Lab** : [`lab-rag-sans-code`](../labs/lab-rag-sans-code/).

## 5. Missions documentation

**Mission 1** · L062 — Anticiper la dépréciation d'un modèle utilisé par vos équipes.

```mission
{
  "title": "Votre fournisseur retire un modèle : à quelle date ?",
  "url": "https://platform.claude.com/docs/en/about-claude/model-deprecations",
  "steps": [
    "Ouvrez la page Model deprecations de la documentation Claude Platform",
    "Repérez le tableau des modèles dépréciés ou retirés",
    "Trouvez la ligne Claude Sonnet 4.5 et lisez la date de retrait, ainsi que le modèle de remplacement recommandé"
  ],
  "question": "À quelle date Claude Sonnet 4.5 est-il retiré de l'API, et vers quel type de modèle Anthropic recommande-t-il de migrer ?",
  "hint": "La date tombe à la fin de l'automne 2026 ; le remplaçant appartient à la génération 5.5.",
  "answer": "Retrait le 30 novembre 2026 ; migration recommandée vers un modèle de la génération 5.5 (par exemple Sonnet 5.5) — vérifiez le tableau à jour (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 2** · L041 — Chiffrer l'option « IA hébergée en France » avant d'acheter une machine.

```mission
{
  "title": "Louer plutôt qu'acheter : le prix d'un GPU en France",
  "url": "https://www.scaleway.com/en/pricing/gpu",
  "steps": [
    "Ouvrez la page des tarifs GPU de Scaleway",
    "Repérez la ligne des instances L40S",
    "Lisez le prix horaire hors taxes"
  ],
  "question": "Quel est le prix horaire HT d'une instance GPU L40S chez Scaleway ?",
  "hint": "Le prix est affiché en euros par heure.",
  "answer": "Environ 1,40 € HT/heure (relevé nov. 2026 — les prix des GPU changent souvent, notez la date de votre consultation).",
  "xp": 10
}
```

**Mission 3** · L063 — Repérer les fiches CNIL utiles à votre politique IA.

```mission
{
  "title": "Les fiches CNIL à remettre à votre référent IA",
  "url": "https://cnil.fr/fr/les-fiches-pratiques-ia",
  "steps": [
    "Ouvrez la page « Les fiches pratiques IA » sur le site de la CNIL",
    "Comptez les fiches proposées",
    "Repérez la fiche consacrée à la base légale de l'intérêt légitime et celle consacrée à l'analyse d'impact (AIPD)"
  ],
  "question": "Combien de fiches pratiques la CNIL propose-t-elle, et lesquelles traitent de l'intérêt légitime et de l'AIPD ?",
  "hint": "Leur nombre est compris entre 15 et 20 ; la leçon L063 cite leur numéro dans la section 4.",
  "answer": "15 fiches pratiques (numérotées de 1 à 13, dont une fiche 4 en deux parties et une fiche 8 bis), finalisées en juillet 2025 ; l'intérêt légitime est traité dans la fiche 8 (et la 8 bis sur le moissonnage), l'AIPD dans la fiche 5 (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 4** · L026 — Comprendre la facturation d'un agent avant de signer un pilote.

```mission
{
  "title": "Ce que coûte un agent qui travaille pour vous",
  "url": "https://platform.claude.com/docs/en/managed-agents/overview",
  "steps": [
    "Ouvrez la page Managed Agents overview",
    "Repérez les concepts de base (agent, environnement, session)",
    "Cherchez l'information de tarification (ou suivez le lien vers la page Pricing)"
  ],
  "question": "Comment sont facturés les Managed Agents, en plus des tokens consommés ?",
  "hint": "Le tarif est exprimé par heure… mais pas de n'importe quelle heure.",
  "answer": "0,08 $ par heure de session active (« running »), en plus des tokens au tarif du modèle (nov. 2026 — tarif susceptible d'évoluer) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 5** · L064 — Trouver une ressource gratuite pour embarquer l'encadrement.

```mission
{
  "title": "Un cours court pour vos managers",
  "url": "https://academy.claude.com/courses/building-effective-human-agent-teams",
  "steps": [
    "Ouvrez la page du cours Building effective human-agent teams sur Claude Academy",
    "Relevez sa durée et le public visé",
    "Repérez les principes clés d'un pilote réussi cités dans la présentation"
  ],
  "question": "Quelle est la durée de ce cours, à qui s'adresse-t-il, et quel est son statut ?",
  "hint": "Il dure moins d'une heure, s'adresse à des encadrants et porte une mention entre parenthèses dans son titre.",
  "answer": "Environ 45 minutes, pour les managers ; cours en version bêta (nov. 2026) — vérifiez : le catalogue évolue.",
  "xp": 10
}
```


## 6. Quiz éclair

```quiz
{
  "q": "Votre entreprise de 30 salariés n'utilise l'IA que pour rédiger des courriers. L'article 4 de l'AI Act vous concerne-t-il ?",
  "options": ["Oui : tout employeur qui déploie de l'IA doit agir", "Non : le risque minimal échappe à toute obligation", "Seulement à partir de 50 salariés dans l'entreprise", "Seulement après le report du haut risque en 2027"],
  "answer": 0,
  "explanation": "L'article 4 (maîtrise de l'IA) s'applique à tous les déployeurs depuis le 2 février 2025, même pour un usage à risque minimal (L029)."
}
```

```quiz
{
  "q": "Un cabinet sous secret professionnel compare l'API d'un grand fournisseur, moins chère, et une station locale. Qu'est-ce qui tranche en priorité ?",
  "options": ["Le prix mensuel affiché par chaque fournisseur", "La vitesse de génération en tokens par seconde", "La règle : les données ne doivent pas sortir", "La notoriété du modèle dans les classements"],
  "answer": 2,
  "explanation": "Dans le scénario C de L062, l'API est la moins chère mais exclue par le premier critère de la grille : la conformité pousse vers le local."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : interdire purement et simplement ChatGPT suffit à régler le shadow AI.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Le shadow AI est un symptôme d'un besoin non couvert : on mesure, on propose un outil validé et on forme (L031)."
}
```

```quiz
{
  "q": "Votre comptable reçoit un appel de votre voix lui demandant un virement urgent. Quelle règle doit-elle appliquer ?",
  "options": ["Exécuter le virement si la voix est bien reconnue", "Rappeler par un autre canal connu avant tout virement", "Demander une confirmation en répondant à l'e-mail", "Attendre une heure, puis exécuter le virement demandé"],
  "answer": 1,
  "explanation": "La règle du double canal (L031) : on vérifie par un canal indépendant et déjà connu, jamais par celui de la demande."
}
```

```quiz
{
  "q": "Quelle est la meilleure façon de lancer l'IA dans un service de 8 personnes ?",
  "options": ["Un déploiement général avec licences pour tous", "Un pilote chiffré, avec champions et bilan publié", "Une interdiction en attendant la réglementation", "Un achat de serveurs GPU avant de définir les usages"],
  "answer": 1,
  "explanation": "L064 : un pilote avec objectif chiffré et bilan honnête vaut mieux qu'un déploiement général qui réussit vaguement."
}
```

## 7. Points de vigilance juridiques

- **AI Act** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA », L063 « Politique IA interne, conformité AI Act et RGPD ») : vous êtes **déployeur** ; vous devenez fournisseur si vous vendez un système sous votre nom. Article 4 : formation tracée par salarié (date, contenu, recyclage) ; depuis l'omnibus (règlement (UE) 2026/1744), il s'agit de mesures qui *favorisent* la maîtrise de l'IA, sans niveau individuel imposé, mais l'obligation d'agir demeure. Transparence (art. 50) depuis le 2 août 2026 : un chatbot sur votre site doit dire qu'il est une IA. Amendes jusqu'à 15 M€ ou 3 % pour la transparence ; pour une PME, le plus bas des deux (article 99, à vérifier).
- **RGPD** (L028 « RGPD et données personnelles dans les prompts (CNIL) ») : l'entreprise est **responsable de traitement** ; exigez un contrat de sous-traitance (art. 28) et des comptes professionnels administrés. Violation de données : notification à la CNIL sous 72 h.
- **Secret professionnel et secret des affaires** : prix d'achat, contrats non signés, données clients sont au minimum « confidentiels » ; données réglementées en local par défaut (classification de L063).
- **Propriété intellectuelle** (L030 « Droit d'auteur, deepfakes, biais et discriminations ») : une sortie brute, sans apport créatif humain, n'est pas protégée ; documentez la part humaine de vos logos, slogans et visuels.
- **Droit du travail** : l'IA qui modifie les conditions de travail suppose l'information-consultation du CSE quand il existe (L063).

## 8. Certifications tierces (préparation, jamais équivalence)

Ce parcours **prépare** aux certificats ci-dessous ; le certificat Next Formation n'en est pas l'équivalent et n'est reconnu par aucun de ces éditeurs (voir `referentiel/correspondance-certifications.md`).
- OpenAI Academy, parcours **« Lead AI Adoption »** (dirigeants), couvert à environ 80 % par M15 et L029 ; badge « AI Foundations » en amont (gratuit).
- Claude Academy : **« AI Fluency: Framework and foundations »** (gratuit) et **« Deploying Claude Enterprise with confidence »** (couvert à environ 70 %, sans atelier d'administration).
- **Google AI Essentials** (Coursera, ~49 $/mois après essai, nov. 2026).
