# Parcours métier — Formateur·rice

> 🧭 Pour les formateurs, ingénieurs pédagogiques, responsables de formation et coordinateurs d'organismes qui conçoivent, animent et évaluent des formations, en présentiel ou à distance. Aucun prérequis technique.

## 1. Ce que l'IA change pour vous en 2026

L'IA générative accélère toute la chaîne de conception : un déroulé pédagogique, des études de cas, une banque de questions, un visuel ou des sous-titres se produisent en quelques minutes (L018 « Prompts métiers : rédiger, résumer, analyser, traduire, tabuler », L059 « Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI) », L061 « Voix et audio : ElevenLabs, Whisper, Suno »). Un assistant nourri de votre support peut aussi répondre aux questions des stagiaires entre deux sessions, en citant le passage du cours (L048 « Construire un RAG sans code : n8n, Dify, Flowise, NotebookLM »).

Ce qui ne change pas : la progression, l'évaluation juste et la relation avec le groupe. Quiz dont la bonne réponse est la plus longue, cas trop lisses, chiffres non sourcés : relire reste votre travail (L023).

Trois sujets prennent de l'importance. Le **droit d'auteur** d'abord : un cours sous licence CC BY-NC ne peut pas nourrir une formation vendue (L030 « Droit d'auteur, deepfakes, biais et discriminations »). L'**article 4 de l'AI Act** ensuite : vos clients doivent former leurs équipes, et vos attestations leur servent d'élément de preuve (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA », L064 « Conduite du changement et montée en compétence des équipes »). Le **cadre de la formation professionnelle**, enfin, a bougé : référentiel Qualiopi actualisé (décret n° 2026-728, 33 indicateurs) applicable depuis le 1er novembre 2026.

## 2. Parcours conseillé

Le **niveau 1 complet** (25 h) donne le certificat « Utilisateur IA certifié » ; le parcours ci-dessous en garde l'essentiel et ajoute six leçons du niveau 2 (assistants, multimédia, conduite du changement).

**Socle N1** — 16 leçons, 11 h 20

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L015 | Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes | 45 |
| L016 | Techniques : exemples (few-shot), raisonnement pas à pas, décomposition | 45 |
| L018 | Prompts métiers : rédiger, résumer, analyser, traduire, tabuler | 45 |
| L019 | Itérer et évaluer : bibliothèque de prompts personnelle | 40 |
| L021 | Cas d'usage par métier : RH, vente, marketing, finance, support, juridique | 45 |
| L022 | Productivité : documents, e-mails, réunions, tableurs, présentations | 45 |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 |
| L030 | Droit d'auteur, deepfakes, biais et discriminations | 40 |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 40 |
| L011 | Claude : conversations, projets, artefacts et premiers pas avec Claude Code | 45 |
| L013 | Perplexity et la recherche augmentée par l'IA | 40 |
| L014 | Image, vidéo, voix : premier tour des outils génératifs | 40 |

**Prioritaires N2** — 6 leçons, 5 h 50

| Leçon | Titre | Durée (min) |
|---|---|---|
| L048 | Construire un RAG sans code : n8n, Dify, Flowise, NotebookLM | 65 |
| L050 | Projets Claude, GPT personnalisés, Gems : la connaissance embarquée | 55 |
| L051 | Custom GPT, Projets Claude, Copilot Studio | 60 |
| L059 | Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI) | 60 |
| L061 | Voix et audio : ElevenLabs, Whisper, Suno | 60 |
| L064 | Conduite du changement et montée en compétence des équipes | 50 |

**Facultatives** — 7 leçons, 6 h 50. Pour produire des vidéos, une application d'entraînement ou un assistant local.

| Leçon | Titre | Durée (min) |
|---|---|---|
| L025 | n8n : découverte et premier workflow (aligné n8n Level 1) | 50 |
| L043 | Ollama : installer, télécharger un modèle, dialoguer, API locale | 60 |
| L044 | LM Studio, Jan, Open WebUI : interfaces graphiques | 55 |
| L053 | Claude Code, Lovable, Bolt, v0 : créer une application sans coder | 65 |
| L055 | Analyser un fichier CSV / Excel avec ChatGPT et Claude | 60 |
| L060 | Vidéo : Sora, Veo, Runway, Kling | 60 |
| L063 | Politique IA interne, conformité AI Act et RGPD | 60 |

> ⏱ **Durée totale du parcours conseillé : 17 h 10** de leçons et d'exercices (quiz de module non compris), **24 h** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

🟢 relecture rapide · 🟠 contrôle des faits · 🔴 validation experte (L021).

### Cas 1 — Le déroulé d'une séquence
Leçon : L018 « Prompts métiers : rédiger, résumer, analyser, traduire, tabuler » · 🟠
```text
Rôle : ingénieur(e) pédagogique. Public : 12 assistants commerciaux débutants. Tâche : déroulé de 3 h sur « rédiger une relance client ». Format : tableau (séquence, objectif observable, méthode, durée, évaluation). Contraintes : alterner apports et pratique toutes les 20 min ; signale les hypothèses sur le public.
```

### Cas 2 — Une banque de questions sans indice de longueur
Leçon : L016 « Techniques : exemples (few-shot), raisonnement pas à pas, décomposition » · 🟠
```text
Voici 2 exemples de questions validées (ci-dessous). Rédige 10 QCM sur le même modèle : 4 options, une seule bonne, distracteurs plausibles, bonne réponse jamais plus longue que les autres, explication d'une phrase.
```

### Cas 3 — Des études de cas métier réalistes
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🟢 — Contexte d'entreprise, problème, documents fournis, consigne, critères de réussite ; un cas par métier représenté dans le groupe.

### Cas 4 — Le tuteur du support de cours
Leçon : L048 « Construire un RAG sans code : n8n, Dify, Flowise, NotebookLM » · 🟠 — Carnet NotebookLM ou Projet Claude nourri du support (dont vous détenez les droits) ; consigne « réponds uniquement d'après le support et cite la page ».

### Cas 5 — Un visuel pédagogique
Leçon : L059 « Image : gpt-image, Midjourney, Flux et Stable Diffusion en local (ComfyUI) » · 🟠 — Sujet, style, composition, contraintes négatives (pas de texte incrusté, pas de logo) ; mention de l'origine IA sur la diapositive.

### Cas 6 — Sous-titrer une capsule vidéo
Leçon : L061 « Voix et audio : ElevenLabs, Whisper, Suno » · 🟠 — Whisper en local → SRT → relecture des termes techniques → intégration.

### Cas 7 — Adapter un contenu à deux publics
Leçon : L018 « Prompts métiers : rédiger, résumer, analyser, traduire, tabuler » · 🟢
```text
Réécris cette fiche en deux versions : (1) débutants, phrases courtes, une analogie du quotidien ; (2) experts, vocabulaire technique, 30 % plus courte. Ne change aucun fait ; liste les passages simplifiés.
```

### Cas 8 — Vérifier les faits d'un support avant diffusion
Leçon : L023 « Vérifier, sourcer, corriger : la relecture critique des sorties IA » · 🟠 — Repérer chiffres, dates et références → remonter à la source primaire → dater la vérification → corriger en gardant une trace.

### Cas 9 — Vérifier la licence d'une ressource
Leçon : L030 « Droit d'auteur, deepfakes, biais et discriminations » · 🔴 — Licence (CC BY, BY-NC, MIT…) → usage prévu (formation gratuite ou vendue) → attribution → décision : intégrer, lier ou écarter.

### Cas 10 — Le plan de formation IA d'un client
Leçon : L064 « Conduite du changement et montée en compétence des équipes » · 🟢
```text
Pour une PME de 60 salariés, propose un plan de formation IA par population (direction, managers, administratifs, production) : objectifs, durée, modalité, preuve conservée par salarié, recyclage. Tableau.
```

## 4. Trois projets fil rouge

### Projet 1 — Un module de 3 heures conçu avec l'IA
- **Énoncé** : concevoir un module complet sur un thème de votre catalogue.
- **Livrable** : déroulé, support, 2 études de cas, 10 QCM, journal des prompts et des vérifications, registre des sources et licences.
- **Critères de réussite** : chaque fait est sourcé et daté ; aucun contenu « NC » dans un module payant ; quiz relu (bonne réponse non devinable).
- **Leçons** : L016, L018, L019, L023, L030 · **Lab** : aucun, atelier de L020.

### Projet 2 — L'assistant tuteur de votre formation
- **Énoncé** : permettre aux stagiaires d'interroger le support entre les sessions.
- **Livrable** : base documentaire, consignes (périmètre, refus, citation), 10 questions de test, note de confidentialité.
- **Critères de réussite** : 8 réponses sur 10 correctes et citées ; renvoi vers le formateur hors périmètre ; aucune donnée d'apprenant dans la base.
- **Leçons** : L048, L050, L051 · **Lab** : [`lab-rag-sans-code`](../labs/lab-rag-sans-code/).

### Projet 3 — Une capsule multimédia accessible
- **Énoncé** : produire une capsule de 3 minutes (visuels, voix off, sous-titres).
- **Livrable** : vidéo, fichier SRT relu, registre des licences et consentements, mention de transparence.
- **Critères de réussite** : sous-titres sans erreur sur les termes clés ; voix et images sous licence compatible ; mention « généré par IA » visible.
- **Leçons** : L014, L059, L061 · **Lab** : aucun, exercices de M14.

## 5. Missions documentation

**Mission 1** · L023 — Vérifier à la source les obligations d'une FOAD.

```mission
{
  "title": "Ce que la loi exige d'une formation à distance",
  "url": "https://www.legifrance.gouv.fr/",
  "steps": [
    "Ouvrez Légifrance et allez dans les codes (Code du travail)",
    "Utilisez la recherche avec la référence « D. 6313-3-1 »",
    "Vérifiez que vous lisez bien la version en vigueur aujourd'hui"
  ],
  "question": "Selon l'article D. 6313-3-1 du Code du travail, quels éléments une formation à distance doit-elle comporter ? Et l'article « L. 6323-4-2 » cité dans l'exercice de la leçon L023 existe-t-il avec ce contenu ?",
  "hint": "L'article D. 6313-3-1 parle d'assistance, d'information sur les activités et d'évaluations.",
  "answer": "Une assistance technique et pédagogique, une information sur les activités pédagogiques et leur durée moyenne estimée, et des évaluations jalonnant ou concluant la formation. Quant à l'article « L. 6323-4-2 » interdisant la formation à distance, il est à considérer comme inventé tant que vous ne l'avez pas trouvé (version en vigueur au nov. 2026 — vérifiez la date de la version consultée).",
  "xp": 20
}
```

**Mission 2** · L030 — Décoder une licence avant d'intégrer un contenu.

```mission
{
  "title": "Ce support CC BY-NC-SA peut-il entrer dans une formation vendue ?",
  "url": "https://creativecommons.org/licenses/by-nc-sa/4.0/deed.fr",
  "steps": [
    "Ouvrez le résumé en français de la licence CC BY-NC-SA 4.0",
    "Repérez les trois conditions affichées avec leurs pictogrammes",
    "Lisez la définition de chacune"
  ],
  "question": "Que signifient les trois sigles BY, NC et SA, et que vous impose concrètement « SA » si vous modifiez le contenu ?",
  "hint": "Le troisième sigle concerne la licence de votre propre version.",
  "answer": "BY = Attribution (citer l'auteur) ; NC = Pas d'utilisation commerciale ; SA = Partage dans les mêmes conditions : si vous remaniez le contenu, vous devez diffuser votre version sous la même licence.",
  "xp": 10
}
```

**Mission 3** · L011 — Expliquer le statut des badges Claude Academy.

```mission
{
  "title": "Badge ou certification : que dire à vos stagiaires ?",
  "url": "https://academy.claude.com/help/faq",
  "steps": [
    "Ouvrez la FAQ de Claude Academy",
    "Cherchez la question sur les badges (« badges », « certificates »)",
    "Lisez aussi la différence avec les certifications payantes"
  ],
  "question": "À quel moment un badge Claude Academy est-il délivré, a-t-il une date d'expiration, et en quoi diffère-t-il d'une certification Anthropic ?",
  "hint": "La section 6 de la leçon L011 résume la réponse ; la mission consiste à la confirmer à la source.",
  "answer": "Le badge est délivré gratuitement à la réussite du dernier quiz d'un cours et n'expire pas ; les certifications (99 à 175 $, valables 12 mois) sont payantes et réservées au Claude Partner Network (nov. 2026).",
  "xp": 15
}
```

**Mission 4** · L001 — Proposer un complément gratuit aux débutants.

```mission
{
  "title": "Un cours gratuit en français à recommander",
  "url": "https://digital-skills-jobs.europa.eu/en/learning-space/training-catalogue/elements-ai",
  "steps": [
    "Ouvrez la fiche Elements of AI du catalogue européen Digital Skills & Jobs",
    "Repérez le résumé du cours (durée, prix, contenu)",
    "Relevez le nombre de chapitres et la durée indicative"
  ],
  "question": "En combien de chapitres le cours est-il découpé, et combien de temps faut-il compter environ ?",
  "hint": "La fiche précise aussi que le cours est gratuit ; la version française est accessible depuis https://www.elementsofai.com/.",
  "answer": "6 chapitres, environ 4 semaines, gratuit (relevé du 1er nov. 2026 — vérifiez, la fiche peut évoluer).",
  "xp": 10
}
```

**Mission 5** · L038 — Répondre juste à un stagiaire qui veut « se certifier n8n ».

```mission
{
  "title": "La certification n8n existe-t-elle déjà ?",
  "url": "https://community.n8n.io/t/no-official-n8n-certification-yet/318573?tl=en",
  "steps": [
    "Ouvrez le fil de la communauté n8n sur la certification",
    "Repérez la réponse de l'équipe n8n",
    "Notez la date de la réponse et l'échéance annoncée"
  ],
  "question": "Quand l'examen de certification officiel chronométré était-il initialement prévu, et à quand a-t-il été repoussé ?",
  "hint": "Cherchez une réponse datée d'octobre 2026.",
  "answer": "Annoncé pour le T3 2026, repoussé à fin T4 2026 (réponse de n8n du 5 octobre 2026) — vérifiez sur n8n.io/education si l'examen est désormais ouvert (vérifié le 5 nov. 2026).",
  "xp": 10
}
```


## 6. Quiz éclair

```quiz
{
  "q": "Vous voulez intégrer des vidéos d'un cours MIT OpenCourseWare (CC BY-NC-SA) dans une formation que vous vendez. Est-ce possible ?",
  "options": ["Oui, si vous citez bien le MIT en source", "Non : l'usage commercial est exclu", "Oui, si la formation est certifiante", "Oui, en traduisant d'abord les vidéos"],
  "answer": 1,
  "explanation": "« NC » exclut l'usage commercial ; MIT précise qu'une entreprise de formation ne peut pas proposer de cours payants basés sur ces contenus (L030)."
}
```

```quiz
{
  "q": "Quelle utilisation d'une vidéo YouTube est en principe admise dans un support de formation ?",
  "options": ["La télécharger puis l'héberger", "L'intégrer via le lecteur officiel", "La remonter en masquant la marque", "La recouper avec votre propre logo"],
  "answer": 1,
  "explanation": "L'intégration (embed) par le lecteur officiel, si le créateur l'autorise ; télécharger et ré-héberger est exclu (L030)."
}
```

```quiz
{
  "q": "Dans le quiz généré par l'IA, la bonne réponse est presque toujours la plus longue. Quel est le problème ?",
  "options": ["Les stagiaires la devinent sans savoir", "Le quiz devient trop difficile à passer", "Le format JSON devient invalide à l'import", "La plateforme refuse les options longues"],
  "answer": 0,
  "explanation": "Une réponse devinable par sa longueur ne mesure plus la compétence : imposez des options de longueur comparable et relisez (L019)."
}
```

```quiz
{
  "q": "Un client vous demande si l'article 4 de l'AI Act impose à ses salariés un examen certifiant. Que répondez-vous ?",
  "options": ["Oui, un examen agréé par l'État français", "Non : mesures proportionnées, tracées", "Oui, mais seulement pour les cadres", "Non : l'article 4 a été supprimé en 2026"],
  "answer": 1,
  "explanation": "Pas d'examen ni de certification obligatoires : l'entreprise choisit des mesures proportionnées et documente la formation de chaque salarié (L029)."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un badge gratuit de Claude Academy est une certification Anthropic.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Le badge est délivré à la réussite du dernier quiz et n'expire pas ; les certifications, payantes, sont réservées au Claude Partner Network (L011)."
}
```

## 7. Points de vigilance juridiques

- **Propriété intellectuelle** (L030 « Droit d'auteur, deepfakes, biais et discriminations ») : CC BY-NC interdit la formation vendue ; courte citation seulement (auteur, source, but pédagogique) ; image trouvée en ligne non libre par défaut ; part humaine documentée pour protéger vos supports générés.
- **AI Act** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA ») : l'éducation figure parmi les domaines à haut risque de l'annexe III (dont l'admission à une formation), obligations reportées au 2 décembre 2027 ; un tuteur IA doit se présenter comme une IA (art. 50) ; article 4 : vos attestations sont un élément de preuve pour vos clients, pas une certification exigée.
- **RGPD** (L028 « RGPD et données personnelles dans les prompts (CNIL) ») : copies, résultats et échanges des stagiaires sont des données personnelles ; pas sur un compte grand public, minimisation et durée de conservation définies.
- **Formation professionnelle** (`_recherche/07`) : référentiel Qualiopi actualisé par le décret n° 2026-728 (33 indicateurs, audit sur ce référentiel depuis le 1er novembre 2026) ; CPF : plafond annuel de 1 500 € pour les certifications RS (décret n° 2026-127) et reste à charge de 150 € depuis le 2 avril 2026 (décret n° 2026-234).
- **Deepfakes** (L030 « Droit d'auteur, deepfakes, biais et discriminations ») : avatar ou voix d'un formateur réel seulement avec son consentement écrit et une mention visible.

## 8. Certifications tierces (préparation, jamais équivalence)

Ce parcours **prépare** aux certificats suivants, sans en être l'équivalent ni être reconnu par leurs éditeurs (voir `referentiel/correspondance-certifications.md`) :
- Claude Academy **« AI Fluency: Framework and foundations »** (gratuit, couvert à 100 %). Les déclinaisons « educators », « train the trainer » et « facilitators » ne sont pas ciblées par NF-IA-150 : à suivre en complément.
- **Elements of AI** (gratuit, en français), à recommander aussi à vos stagiaires débutants.
- OpenAI Academy « Teach and Learn with AI » : hors cible de NF-IA-150 (couverture 0 %), à suivre seul si votre public est scolaire.
