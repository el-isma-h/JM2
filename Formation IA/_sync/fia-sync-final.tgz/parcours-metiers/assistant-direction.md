# Parcours métier — Assistant·e de direction

> 🧭 Pour les assistant·es de direction, office managers et assistant·es de dirigeants qui gèrent réunions, courriers, agendas et boîtes mail, et deviennent souvent les référents IA de fait de leur service. Aucun prérequis technique.

## 1. Ce que l'IA change pour vous en 2026

Votre journée est faite de tâches que l'IA générative accélère vraiment : transformer une transcription en compte rendu, enchaîner compte rendu, e-mail et diapositives en une demi-heure, rédiger un courrier au bon ton, résumer un dossier avant une réunion (L022 « Productivité : documents, e-mails, réunions, tableurs, présentations »). Les assistants intégrés (Microsoft 365 Copilot, Gemini dans Workspace) voient déjà vos fichiers et votre agenda ; les généralistes (Claude, ChatGPT) sont meilleurs pour fusionner plusieurs sources ou produire un format inhabituel.

Ce qui reste votre valeur : la **hiérarchie** et les **nuances**. Un compte rendu généré n'oublie rien, mais il met au même niveau une décision stratégique et le choix de la salle. C'est vous qui savez ce qui compte pour la direction.

Deux vigilances propres à votre poste. Vous êtes une cible privilégiée de la **fraude au président**, désormais avec voix clonée (L031 « Sécurité au quotidien : clés, phishing IA, shadow AI »). Et vous manipulez des informations très confidentielles (agenda, rémunérations, santé d'un collaborateur, projets de cession) qui ne vont jamais dans un compte personnel (L028 « RGPD et données personnelles dans les prompts (CNIL) »).

## 2. Parcours conseillé

Le **niveau 1 complet** (25 h) donne le certificat « Utilisateur IA certifié » ; le parcours ci-dessous en garde l'essentiel, avec l'atelier de prompts, et ajoute quatre leçons du niveau 2.

**Socle N1** — 17 leçons, 12 h 15

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L010 | ChatGPT : prise en main complète | 40 |
| L011 | Claude : conversations, projets, artefacts et premiers pas avec Claude Code | 45 |
| L012 | Gemini, Copilot, Grok, Le Chat : forces et usages | 40 |
| L013 | Perplexity et la recherche augmentée par l'IA | 40 |
| L015 | Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes | 45 |
| L016 | Techniques : exemples (few-shot), raisonnement pas à pas, décomposition | 45 |
| L018 | Prompts métiers : rédiger, résumer, analyser, traduire, tabuler | 45 |
| L019 | Itérer et évaluer : bibliothèque de prompts personnelle | 40 |
| L020 | Atelier guidé : 10 prompts à construire et corriger | 50 |
| L021 | Cas d'usage par métier : RH, vente, marketing, finance, support, juridique | 45 |
| L022 | Productivité : documents, e-mails, réunions, tableurs, présentations | 45 |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 |
| L025 | n8n : découverte et premier workflow (aligné n8n Level 1) | 50 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 40 |

**Prioritaires N2** — 4 leçons, 3 h 50

| Leçon | Titre | Durée (min) |
|---|---|---|
| L036 | Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks | 55 |
| L050 | Projets Claude, GPT personnalisés, Gems : la connaissance embarquée | 55 |
| L051 | Custom GPT, Projets Claude, Copilot Studio | 60 |
| L061 | Voix et audio : ElevenLabs, Whisper, Suno | 60 |

**Facultatives** — 8 leçons, 6 h 40. Pour aller vers les agents, le computer use et l'automatisation de la boîte mail.

| Leçon | Titre | Durée (min) |
|---|---|---|
| L014 | Image, vidéo, voix : premier tour des outils génératifs | 40 |
| L026 | Qu'est-ce qu'un agent IA ? | 40 |
| L027 | MCP (Model Context Protocol) expliqué simplement | 40 |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 |
| L038 | Projet : assistant de support client automatisé | 65 |
| L052 | Agents multi-outils dans n8n | 60 |
| L054 | Computer use et navigateurs IA | 50 |
| L055 | Analyser un fichier CSV / Excel avec ChatGPT et Claude | 60 |

> ⏱ **Durée totale du parcours conseillé : 16 h 05** de leçons et d'exercices (quiz de module non compris), **22 h 45** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

🟢 relecture rapide · 🟠 contrôle des faits · 🔴 validation experte (L021).

### Cas 1 — Le compte rendu de réunion
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🟠
```text
Rôle : assistant(e) de direction d'un cabinet de 15 personnes. Contexte : transcription ci-dessous. Format : décisions, actions (tableau action / responsable / échéance), points en suspens, prochaine réunion. Contraintes : n'attribue une action que si c'est explicite, sinon « responsable à définir » ; 300 mots.
```

### Cas 2 — Des notes au PowerPoint en trente minutes
Leçon : L022 « Productivité : documents, e-mails, réunions, tableurs, présentations » · 🟠 — Notes brutes → compte rendu → e-mail de diffusion → plan de 6 diapositives → fichier ; relecture à chaque étape, jamais seulement à la fin.

### Cas 3 — Trier la boîte mail de la direction
Leçon : L022 « Productivité : documents, e-mails, réunions, tableurs, présentations » · 🟠
```text
Voici 30 e-mails reçus (expéditeur, objet, extrait). Classe-les : à traiter par le directeur, à traiter par moi, pour information, à archiver. Pour la première catégorie, propose un brouillon de réponse de 80 mots. N'envoie rien.
```

### Cas 4 — Préparer un déplacement
Leçon : L013 « Perplexity et la recherche augmentée par l'IA » · 🟠 — Recherche sourcée des options de transport et d'hébergement, avec lien et date pour chaque horaire ou tarif, à confirmer sur le site du transporteur.

### Cas 5 — Un courrier officiel au ton juste
Leçon : L018 « Prompts métiers : rédiger, résumer, analyser, traduire, tabuler » · 🟢
```text
Rédige un courrier de la directrice générale à un partenaire pour reporter une signature de 3 semaines. Ton cordial et ferme, 150 mots, sans justification détaillée ; propose deux dates.
```

### Cas 6 — Le dossier de préparation d'une réunion
Leçon : L022 « Productivité : documents, e-mails, réunions, tableurs, présentations » · 🟠
```text
Synthétise ces 5 documents pour la réunion de jeudi : enjeux en 5 lignes, chiffres clés avec le document source, 3 questions à poser, points de désaccord probables. 1 page.
```

### Cas 7 — L'assistant du bureau
Leçon : L050 « Projets Claude, GPT personnalisés, Gems : la connaissance embarquée » · 🟠 — Projet Claude ou GPT personnalisé nourri des procédures internes (notes de frais, réservations, accueil des visiteurs), qui répond en citant le document.

### Cas 8 — La bibliothèque de prompts du service
Leçon : L019 « Itérer et évaluer : bibliothèque de prompts personnelle » · 🟢 — Un document partagé et versionné : nom du prompt, usage, prompt complet, exemple de bon résultat, date de dernière vérification.

### Cas 9 — Transcrire sans envoyer l'audio
Leçon : L061 « Voix et audio : ElevenLabs, Whisper, Suno » · 🟠 — Whisper en local → fichier texte ou SRT → relecture des noms propres ; participants informés avant l'enregistrement.

### Cas 10 — Choisir le bon assistant pour la tâche
Leçon : L012 « Gemini, Copilot, Grok, Le Chat : forces et usages » · 🟢 — Document déjà ouvert dans Word, Outlook ou Teams : assistant intégré. Plusieurs sources éparses ou format inhabituel : assistant généraliste. Toujours vérifier la version (grand public ou entreprise).

## 4. Trois projets fil rouge

### Projet 1 — La chaîne de réunion complète
- **Énoncé** : outiller toutes les réunions de direction, de la préparation au suivi des actions.
- **Livrable** : 4 prompts testés (préparation, compte rendu, e-mail, diapositives), tableau de suivi des actions, procédure de transcription.
- **Critères de réussite** : aucune action attribuée à tort sur 3 réunions de test ; diffusion en moins de 30 minutes ; participants informés de la transcription.
- **Leçons** : L021, L022, L061 · **Lab** : aucun, exercice de L022.

### Projet 2 — L'assistant du bureau de direction
- **Énoncé** : répondre aux questions récurrentes des équipes sur les procédures internes.
- **Livrable** : assistant spécialisé (instructions, documents, refus), 10 questions de test, règles de partage.
- **Critères de réussite** : 8 réponses sur 10 correctes et citées ; aucune donnée personnelle dans la base ; partage limité au bon groupe.
- **Leçons** : L050, L051 · **Lab** : [`lab-rag-sans-code`](../labs/lab-rag-sans-code/) (guide NotebookLM).

### Projet 3 — Le tri automatisé de la boîte de direction
- **Énoncé** : classer chaque e-mail entrant et préparer un brouillon, sans aucun envoi automatique.
- **Livrable** : workflow n8n (Gmail → classification → brouillon → validation Slack), journal, jeu de 20 e-mails de test.
- **Critères de réussite** : au moins 18 classements corrects sur 20 ; aucun envoi sans validation ; erreurs notifiées.
- **Leçons** : L025, L036, L038 · **Lab** : [`lab-n8n-support`](../labs/lab-n8n-support/), même architecture.

## 5. Missions documentation

**Mission 1** · L022 — Vérifier les formats bureautiques que Claude sait produire.

```mission
{
  "title": "Du compte rendu au document Word, Excel ou PowerPoint",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview",
  "steps": [
    "Ouvrez la page Agent Skills overview",
    "Cherchez la partie sur les skills pré-construits (pre-built Agent Skills)",
    "Notez la liste des formats de fichiers couverts"
  ],
  "question": "Quels quatre types de fichiers bureautiques les skills pré-construits d'Anthropic permettent-ils de créer ?",
  "hint": "Pensez aux extensions des logiciels Word, Excel, PowerPoint… et au format d'impression universel.",
  "answer": "PowerPoint (.pptx), Excel (.xlsx), Word (.docx) et PDF (nov. 2026 — la liste peut s'allonger) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 2** · L022 — Connaître les limites des PDF envoyés à Claude.

```mission
{
  "title": "Le rapport annuel de 300 pages passe-t-il ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/pdf-support",
  "steps": [
    "Ouvrez la page PDF support de la documentation Claude",
    "Cherchez la section sur les limites (PDF support requirements / limits)",
    "Repérez la taille maximale de requête et le nombre de pages maximal"
  ],
  "question": "Quelle taille maximale de requête et quel nombre maximal de pages la documentation indique-t-elle pour un PDF ?",
  "hint": "Le nombre de pages dépend aussi de la taille de la fenêtre de contexte du modèle.",
  "answer": "128 Mo par requête et 600 pages maximum (100 pages pour les modèles dont le contexte est inférieur à 1 M de tokens) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 3** · L011 — Repérer la formation gratuite de prise en main.

```mission
{
  "title": "Un cours gratuit pour bien démarrer avec Claude",
  "url": "https://academy.claude.com/courses/claude-101",
  "steps": [
    "Ouvrez la page du cours Claude 101 sur Claude Academy",
    "Notez la durée et le nombre de leçons",
    "Repérez la leçon consacrée aux artefacts"
  ],
  "question": "Combien de temps dure Claude 101, combien de leçons compte-t-il, et comment s'intitule la section sur les artefacts ?",
  "hint": "Le titre de la section commence par « Creating with… ».",
  "answer": "Environ 2,5 h et 13 leçons ; la section s'intitule « Creating with artifacts » (état au 1er nov. 2026).",
  "xp": 10
}
```

**Mission 4** · L051 — Repérer le cours consacré aux tâches déléguées sur le poste de travail.

```mission
{
  "title": "Organiser vos tâches récurrentes avec Claude Cowork",
  "url": "https://academy.claude.com/courses/introduction-to-claude-cowork",
  "steps": [
    "Ouvrez la page du cours sur Claude Academy",
    "Repérez sa durée et le nombre de leçons",
    "Lisez le plan de la partie « Make Claude Cowork yours »"
  ],
  "question": "Quelle est la durée du cours et quels sont les quatre thèmes de la partie « Make Claude Cowork yours » ?",
  "hint": "On y retrouve deux briques de la leçon L051 : les projets et les skills.",
  "answer": "Environ 2 h 30 (14 leçons + quiz) ; partie 3 : « Get better results faster », « Standing context — Global instructions and projects », « Skills — teach Claude Cowork your way », « Plugins — encode your team's expertise » (relevé nov. 2026).",
  "xp": 10
}
```

**Mission 5** · L061 — Vérifier la mémoire nécessaire pour transcrire sans envoyer l'audio.

```mission
{
  "title": "Transcrire les réunions en local : la machine suffit-elle ?",
  "url": "https://github.com/openai/whisper",
  "steps": [
    "Ouvrez le dépôt GitHub openai/whisper",
    "Dans le README, repérez le tableau des tailles de modèles (Available models and languages)",
    "Lisez la colonne de mémoire vidéo requise (Required VRAM) pour les modèles large et turbo"
  ],
  "question": "Combien de VRAM le README indique-t-il pour les modèles large et turbo, et sous quelle licence le dépôt est-il publié ?",
  "hint": "Environ dix gigaoctets pour l'un, environ six pour l'autre ; la licence est très permissive et tient en trois lettres.",
  "answer": "≈ 10 Go pour large et ≈ 6 Go pour turbo ; licence MIT (nov. 2026) — vérifiez sur la version installée (vérifié le 5 nov. 2026).",
  "xp": 10
}
```


## 6. Quiz éclair

```quiz
{
  "q": "La transcription dit « il faudrait relancer le fournisseur » sans préciser qui s'en charge. Qu'écrit le compte rendu ?",
  "options": ["Le nom de la personne qui a parlé", "« responsable à définir »", "Le nom du directeur, par défaut", "Rien : on supprime l'action"],
  "answer": 1,
  "explanation": "Consigne du prompt de L021 : n'attribuer une action que si c'est explicite dans la transcription."
}
```

```quiz
{
  "q": "Un message vocal du directeur, très convaincant, vous demande d'envoyer sur-le-champ la liste des salaires à un « avocat ». Que faites-vous ?",
  "options": ["J'envoie, c'est bien sa voix au téléphone", "Je réponds au numéro du message vocal", "Je rappelle le directeur à un numéro connu", "J'envoie la liste, mais sans les montants"],
  "answer": 2,
  "explanation": "Voix clonée possible : on applique la règle du double canal, par un canal indépendant déjà connu (L031)."
}
```

```quiz
{
  "q": "Vous voulez activer la transcription d'une réunion Teams. Quelle condition est une obligation, pas une politesse ?",
  "options": ["Prévenir le service informatique avant", "Informer les participants au préalable", "Limiter la réunion à une heure maximum", "Couper les caméras des participants"],
  "answer": 1,
  "explanation": "L'accord ou au minimum l'information des participants est une obligation d'information (L022) ; la voix est une donnée personnelle (L061)."
}
```

```quiz
{
  "q": "Le budget à résumer est déjà ouvert dans Excel, dans l'espace Microsoft 365 de l'entreprise. Quel outil essayer en premier ?",
  "options": ["Copilot grand public, gratuit", "L'assistant intégré à Excel", "Un compte ChatGPT personnel", "Un modèle local à installer"],
  "answer": 1,
  "explanation": "Règle de L022 : si le document est déjà ouvert dans la suite bureautique, commencez par l'assistant intégré (en version entreprise)."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : « la seule comptable de notre agence, en congé maternité » n'est pas une donnée personnelle, puisqu'aucun nom n'apparaît.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. L'identification indirecte compte autant que le nom, et l'information touche à la santé (L028)."
}
```

## 7. Points de vigilance juridiques

- **RGPD** (L028 « RGPD et données personnelles dans les prompts (CNIL) ») : comptes rendus, agendas et e-mails contiennent des données personnelles, parfois sensibles (santé, syndicat) ; pseudonymisez, n'utilisez que les outils validés par l'entreprise, gardez une trace de ce qui a été envoyé à quel outil.
- **Enregistrements** (L022 « Productivité : documents, e-mails, réunions, tableurs, présentations », L061 « Voix et audio : ElevenLabs, Whisper, Suno ») : informer les participants avant toute transcription ; la voix est une donnée personnelle, biométrique quand elle sert à identifier ; pas de clonage de voix sans consentement.
- **Secret des affaires et confidentialité** (L063 « Politique IA interne, conformité AI Act et RGPD ») : projets de cession, rémunérations, contentieux = niveau « confidentiel » ou « réglementé ».
- **AI Act** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA ») : vos usages sont à risque minimal ; l'article 4 vous concerne (formation tracée) ; un contenu synthétique diffusé à l'extérieur (voix, vidéo) doit être signalé.
- **Sécurité** (L031 « Sécurité au quotidien : clés, phishing IA, shadow AI ») : phishing personnalisé par IA, voix clonée ; jamais de clé d'API ou de mot de passe dans un prompt.

## 8. Certifications tierces (préparation, jamais équivalence)

Ce parcours **prépare** aux certificats suivants, sans en être l'équivalent ni être reconnu par leurs éditeurs (voir `referentiel/correspondance-certifications.md`) :
- Claude Academy : **« Claude 101 »**, **« Introduction to Claude Cowork »** et **« Introduction to Claude Tag »** (badges gratuits).
- OpenAI Academy, badge **« AI Foundations »** (gratuit, 20 questions, 80 % requis).
- **Google AI Essentials**, dont « Maximize Productivity With AI Tools » (couvert par L010-L013, L021, L022).
