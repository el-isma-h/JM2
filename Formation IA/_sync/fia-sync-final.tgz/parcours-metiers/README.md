# Parcours métiers — Formation IA (NF-IA-150)

Dix parcours qui relisent la formation **par métier** plutôt que par niveau. Chacun dit ce que l'IA change concrètement pour le métier en 2026, quelles leçons suivre en priorité, et comment s'entraîner sur des cas, des projets, des missions et des quiz propres au métier. Les leçons, quiz, examens et labs existants ne sont pas modifiés : les parcours y renvoient.

## Les dix parcours

| Métier | Niveaux et modules mobilisés (leçons prioritaires) | Parcours prioritaire | Avec facultatives |
|---|---|---|---|
| [Dirigeant·e de PME](dirigeant-pme.md) | N1 · N2 (M10, M11, M12, M15) | 16 h 10 | 22 h 10 |
| [Ressources humaines](rh.md) | N1 · N2 (M11, M12, M15) | 14 h 50 | 21 h 20 |
| [Marketing & communication](marketing-communication.md) | N1 · N2 (M11, M13, M14) | 17 h 20 | 24 h 10 |
| [Commercial](commercial.md) | N1 · N2 (M08, M11, M12) | 15 h 55 | 22 h 55 |
| [Comptable & finance](comptable-finance.md) | N1 · N2 (M09, M10, M11, M13, M15) | 18 h 45 | 25 h 25 |
| [Juriste](juriste.md) | N1 · N2 (M10, M11, M15) | 17 h 25 | 23 h 40 |
| [Assistant·e de direction](assistant-direction.md) | N1 · N2 (M08, M11, M12, M14) | 16 h 05 | 22 h 45 |
| [Formateur·rice](formateur.md) | N1 · N2 (M11, M12, M14, M15) | 17 h 10 | 24 h |
| [Développeur·se](developpeur.md) | N1 · N3 (M16, M17, M19, M20, M21, M22, M23) | 35 h 30 | 41 h |
| [Data analyst / data engineer](data-analyst-engineer.md) | N1 · N2 (M13) · N3 (M17, M20) · N5 (M31, M33, M35, M36) | 20 h 25 | 25 h 35 |

Les durées sont calculées à partir de `programme/programme.json` (leçons et exercices, quiz de module non compris). Le parcours prioritaire est un sous-ensemble : **le certificat Next Formation d'un niveau suppose de suivre ce niveau en entier**.

## Ce que contient chaque fichier

1. **Ce que l'IA change pour vous en 2026** : vulgarisé, chiffré quand une leçon le permet, sans promesse exagérée.
2. **Parcours conseillé** : niveaux, leçons prioritaires et facultatives (identifiants et titres officiels), durée totale.
3. **Dix cas d'usage**, chacun relié à la leçon qui l'enseigne, avec un prompt type ou un workflow type. Niveau de vérification repris de L021 : 🟢 relecture rapide · 🟠 contrôle des faits · 🔴 validation experte.
4. **Trois projets fil rouge** : énoncé, livrable, critères de réussite, leçons et labs mobilisés (voir [`labs/README.md`](../labs/README.md)).
5. **Cinq missions documentation** au format ```` ```mission ```` de `FORMAT.md`. Elles sont **reprises des leçons** : le titre est adapté au métier et les renvois internes (« cette leçon », « la section 6 ») sont rendus explicites (« la leçon L058 ») ; l'URL, le contenu des étapes, de la question et de l'indice, et la réponse sont inchangés. Une réponse qui porte « vérifié le 5 nov. 2026 » a été contrôlée lors des passes de vérification des missions ; les autres restent à revérifier avant publication.
6. **Cinq quiz éclair** au format ```` ```quiz ```` (2 à 4 options, `answer` 0-based) ; la bonne réponse n'est jamais plus longue de plus de 15 % que la plus courte des autres options.
7. **Points de vigilance juridiques** (RGPD, AI Act, secret professionnel, propriété intellectuelle) tirés de M07, M15 et `_recherche/07-mise-a-jour-nov-2026.md`. Ce sont des repères pédagogiques, pas un conseil juridique.
8. **Certifications tierces** tirées de `referentiel/correspondance-certifications.md`, toujours présentées comme une **préparation** : les certificats Next Formation ne sont l'équivalent d'aucune certification tierce et ne sont reconnus par aucun de leurs éditeurs.

## Contrôles effectués (5 novembre 2026)

Un script de contrôle a vérifié, pour chaque fichier : l'existence de chaque identifiant de leçon cité, le JSON strict de chaque bloc ```` ```quiz ```` et ```` ```mission ````, la présence des champs obligatoires, l'origine de chaque URL de mission (`_recherche/*.md`, `ressources/bibliotheque-liens.md` ou une leçon), la règle de longueur des bonnes réponses, le nombre de cas (10), de projets (3), de missions (5) et de quiz (5), et une longueur comprise entre 1 500 et 2 500 mots (mot = jeton contenant au moins une lettre ou un chiffre ; `wc -w` brut, qui compte aussi les « | » des tableaux, les flèches et les pictogrammes, donne environ 2 700 à 2 900).

## À revoir avant publication

- Les prix, dates et conditions (tarifs d'API, certifications, CPF, Qualiopi) sont ceux de novembre 2026 : à revérifier, comme dans les leçons.
- Les missions sans mention « vérifié le 5 nov. 2026 » (sources Légifrance, EUR-Lex, Claude Academy…) n'ont pas été rouvertes pour ces parcours.
