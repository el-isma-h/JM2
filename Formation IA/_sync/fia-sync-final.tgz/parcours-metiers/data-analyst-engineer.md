# Parcours métier — Data analyst / data engineer

> 🧭 Pour les data analysts, analytics engineers et data engineers qui interrogent, modélisent et fiabilisent les données, et de plus en plus les préparent pour des systèmes d'IA (RAG, ML). Prérequis : SQL ; Python et Docker pour la piste engineer.

## 1. Ce que l'IA change pour vous en 2026

Côté **analyst**, l'assistant écrit une requête à partir d'une question en français et du schéma, propose un graphique, rédige un commentaire (L056, L057). Votre valeur se déplace vers la vérification : totaux de contrôle, lecture critique du SQL, chasse au chiffre halluciné (L055).

Côté **engineer**, l'IA crée une demande nouvelle : des données **prêtes pour l'IA**. Un RAG ne vaut que ses documents : extraction propre, données personnelles détectées, déduplication, découpage, métadonnées de droits, ré-indexation incrémentale (L175, L177, L178). Le socle du métier reste ingestion, transformation, qualité et orchestration (L151).

Ce qui ne change pas : un pipeline doit être **idempotent** et testé (L161, L170), et un LLM ne calcule pas, il rédige à partir de chiffres produits par le code (L058).

## 2. Parcours conseillé

Piste **analyst** : socle commun + groupe « analytique et qualité ». Piste **engineer** : ajoutez « données pour l'IA » et les facultatives ; le **N5** (30 h, certificat « Data engineer IA ») est accessible après le N3.

**Socle commun** — 8 leçons, 6 h 45

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L055 | Analyser un fichier CSV / Excel avec ChatGPT et Claude | 60 |
| L056 | Visualisations et rapports générés | 60 |
| L057 | SQL en langage naturel | 60 |
| L058 | Automatiser un reporting hebdomadaire | 60 |

**Prioritaires N5 — analytique et qualité** — 11 leçons, 8 h 40

| Leçon | Titre | Durée (min) |
|---|---|---|
| L071 | Sorties structurées et JSON fiable | 45 |
| L151 | Le cycle de vie du data engineering et le rôle du data engineer IA (Reis & Housley, fiche APEC, ROME M1811) | 40 |
| L152 | Types de données et formats de fichiers : CSV, JSON/JSONL, Parquet, Avro, ORC, Arrow — mesurer taille et vitesse | 55 |
| L153 | SQL analytique moderne avec DuckDB : CTE, fenêtres, QUALIFY, MERGE, JSON et lecture d'un plan d'exécution | 55 |
| L154 | Modéliser pour l'analytique : 3NF, étoile et SCD type 2, Data Vault 2.0, architecture médaillon | 55 |
| L155 | Atelier : profiler, nettoyer et modéliser un jeu de données réel en Parquet avec DuckDB et Polars | 45 |
| L161 | ETL ou ELT : architectures, couches bronze/silver/gold, idempotence et rejouabilité | 35 |
| L163 | dbt Core : sources, ref, matérialisations, modèles incrémentaux, snapshots, tests, documentation et lignage | 60 |
| L170 | Qualité des données : dimensions, tests dbt, Great Expectations (GX Core) et Soda Core (SodaCL) | 50 |
| L171 | Contrats de données avec l'Open Data Contract Standard v3.1 et gestion de l'évolution de schéma | 40 |
| L174 | Sécurité et conformité dans le pipeline : RGPD, contrôle d'accès, chiffrement, AI Act art. 10 | 40 |

**Prioritaires N3 / N5 — données pour l'IA** — 6 leçons, 5 h

| Leçon | Titre | Durée (min) |
|---|---|---|
| L093 | Évaluer un RAG : Ragas, jeux de test, métriques | 50 |
| L164 | Orchestrer : Airflow 3 (DAG, assets, Task SDK), Dagster (assets), Prefect — reprise, backfill, alertes | 55 |
| L172 | Gouvernance, catalogues et lignage : Unity Catalog, OpenMetadata, DataHub, OpenLineage | 50 |
| L175 | Construire un corpus texte : extraction (Docling, Trafilatura), normalisation, langue, filtres qualité (méthode FineWeb) | 50 |
| L177 | Détecter et anonymiser les données personnelles avec Presidio (reconnaisseurs français : NIR, IBAN, téléphone) | 40 |
| L178 | Chunking, embeddings par lots (Ray Data, Spark) et bases vectorielles à l'échelle : index, filtres, multi-tenance, coûts | 55 |

**Facultatives (piste engineer)** — 6 leçons, 5 h 10. Lakehouse, Spark, ingestion incrémentale, Kafka et cadrage du projet final M37 (L180-L184).

| Leçon | Titre | Durée (min) |
|---|---|---|
| L157 | Formats de table ouverts : Delta Lake, Apache Iceberg, Apache Hudi, time travel et catalogues REST (Unity Catalog, Polaris) | 55 |
| L159 | Apache Spark et PySpark 4 : DataFrames, partitions, shuffle, jointures broadcast, AQE, Spark Connect | 60 |
| L162 | Ingestion incrémentale : Airbyte, Fivetran, dlt et capture de changements (CDC) avec Debezium | 50 |
| L165 | Atelier : pipeline dlt → DuckDB → dbt orchestré, avec CI « slim » sur les modèles modifiés | 50 |
| L167 | Apache Kafka 4 en mode KRaft : topics, partitions, consumer groups (KIP-848), Avro et Schema Registry, Kafka Connect | 55 |
| L180 | Cadrer le projet : sources, volumétrie, fraîcheur, droits d'accès, SLA, contrat de données et architecture cible | 40 |

> ⏱ **Durée totale du parcours conseillé : 20 h 25** de leçons et d'exercices (quiz de module non compris), **25 h 35** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

### Cas 1 — Profiler un jeu de données inconnu
Leçon : L155 « Atelier : profiler, nettoyer et modéliser un jeu de données réel en Parquet avec DuckDB et Polars »
```text
Voici le schéma DuckDB de la table ventes (ci-dessous). Écris les requêtes de profilage : nombre de lignes, taux de nulls et de valeurs distinctes par colonne, min/max des dates et montants, doublons sur (commande_id). N'interprète rien avant que je t'aie donné les résultats.
```

### Cas 2 — Du français au SQL, avec contrôle
Leçon : L057 « SQL en langage naturel » — Schéma et dialecte dans le prompt → requête SELECT seule → exécution sur un jeu de test connu → total de contrôle → compte en lecture seule en production.

### Cas 3 — Dédoublonner « au plus récent »
Leçon : L153 « SQL analytique moderne avec DuckDB : CTE, fenêtres, QUALIFY, MERGE, JSON et lecture d'un plan d'exécution »
```text
Dialecte : DuckDB. Table commandes(commande_id, statut, mis_a_jour_le). Écris une requête qui garde la ligne la plus récente par commande_id avec QUALIFY, puis la même sans QUALIFY pour PostgreSQL.
```

### Cas 4 — Tests et documentation d'un modèle dbt
Leçon : L163 « dbt Core : sources, ref, matérialisations, modèles incrémentaux, snapshots, tests, documentation et lignage » — SQL du modèle et table source → `schema.yml` proposé (descriptions, tests génériques) → chaque test relu avant commit.

### Cas 5 — Un contrat de données
Leçon : L171 « Contrats de données avec l'Open Data Contract Standard v3.1 et gestion de l'évolution de schéma » — Ébauche ODCS v3.1 (schéma, qualité, SLA, propriétaires) générée depuis la table, puis confrontée aux données.

### Cas 6 — Le commentaire automatique d'un reporting
Leçon : L058 « Automatiser un reporting hebdomadaire » — Le code calcule les indicateurs → le modèle rédige sans recalculer → le code vérifie que chaque nombre du texte figure dans les résultats.

### Cas 7 — Un graphique honnête
Leçon : L056 « Visualisations et rapports générés »
```text
Données ci-dessous (CA mensuel 2025-2026 par région). Produis une courbe par région, axe Y à zéro, unité k€, titre qui énonce le message principal. Donne le code et vérifie que chaque point correspond au tableau.
```

### Cas 8 — Pseudonymiser un corpus avant indexation
Leçon : L177 « Détecter et anonymiser les données personnelles avec Presidio (reconnaisseurs français : NIR, IBAN, téléphone) » — Presidio en français (NIR, IBAN, téléphone) → opérateurs de remplacement → échantillon relu, faux négatifs mesurés.

### Cas 9 — Préparer des documents pour un RAG
Leçon : L178 « Chunking, embeddings par lots (Ray Data, Spark) et bases vectorielles à l'échelle : index, filtres, multi-tenance, coûts » — Extraction structurée → découpage respectant les titres → métadonnées (source, date, droits) → embeddings par lots ; upserts et suppressions incrémentaux en L183.

### Cas 10 — Structurer du texte libre en colonnes
Leçon : L071 « Sorties structurées et JSON fiable » — Schéma JSON des champs attendus (catégorie, produit, sentiment) → sortie structurée → validation de type → chargement dans la table d'analyse.

## 4. Trois projets fil rouge

### Projet 1 — Le reporting hebdomadaire fiable
- **Énoncé** : chaque lundi, un rapport d'activité calculé, rédigé et contrôlé automatiquement.
- **Livrable** : workflow n8n ou script Python testé, prompt de rédaction, règles d'alerte.
- **Critères de réussite** : tests `pytest` verts ; aucun nombre du texte absent des calculs ; coût par rapport chiffré.
- **Leçons** : L055, L056, L058 · **Lab** : [`lab-reporting`](../labs/lab-reporting/) (variante Python).

### Projet 2 — Le pipeline analytique orchestré
- **Énoncé** : ingérer une source, la modéliser en couches bronze, silver et gold, tester et orchestrer.
- **Livrable** : pipeline dlt → DuckDB → dbt, DAG d'orchestration, CI « slim » sur les modèles modifiés.
- **Critères de réussite** : rejouer le pipeline deux fois donne le même résultat ; tests dbt bloquants ; documentation et lignage générés.
- **Leçons** : L161, L163, L164, L165, L170 · **Lab** : aucun kit dans `labs/`, atelier de L165 (Docker Compose local).

### Projet 3 — Le pipeline de données d'un RAG d'entreprise
- **Énoncé** : documents et base métier → corpus propre, pseudonymisé, indexé et tenu à jour.
- **Livrable** : cadrage (sources, droits, contrat), pipeline bronze → silver → index, évaluation, coût par document.
- **Critères de réussite** : aucune donnée personnelle non voulue dans l'index ; suppressions propagées ; métriques de récupération mesurées.
- **Leçons** : L175, L177, L178, L180-L184 · **Lab** : [`lab-rag-code`](../labs/lab-rag-code/) pour la partie recherche et évaluation.

## 5. Missions documentation

**Mission 1** · L151 — Situer le métier et sa rémunération.

```mission
{
  "title": "Le marché du data engineer en France",
  "url": "https://www.apec.fr/tous-nos-metiers/informatique/data-engineer.html",
  "steps": [
    "Ouvrez la fiche métier Data Engineer de l'APEC",
    "Descendez jusqu'au bloc consacré à la rémunération",
    "Relevez la fourchette qui concentre la majorité des offres et la moyenne"
  ],
  "question": "Entre quels montants se situent 80 % des offres de data engineer, et quel est le salaire moyen indiqué ?",
  "hint": "Les montants sont exprimés en k€ brut annuel, fixe et variable compris.",
  "answer": "Entre 35 et 60 k€ brut annuel, moyenne d'environ 47 k€ (fiche consultée en nov. 2026 ; ces chiffres sont mis à jour régulièrement) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 2** · L152 — Retrouver la méthode d'échange entre vos deux outils.

```mission
{
  "title": "Passer de DuckDB à Polars sans copie inutile",
  "url": "https://duckdb.org/docs/2.0/guides/python/polars.html",
  "steps": [
    "Ouvrez le guide « Integration with Polars » de la documentation DuckDB 2.0",
    "Repérez l'exemple qui transforme un résultat DuckDB en DataFrame Polars",
    "Cherchez l'option qui renvoie un LazyFrame plutôt qu'un DataFrame"
  ],
  "question": "Quelle méthode convertit un résultat DuckDB en objet Polars, et quel paramètre permet d'obtenir un LazyFrame ?",
  "hint": "La méthode tient en deux lettres.",
  "answer": "La méthode .pl() ; avec lazy=True elle renvoie un LazyFrame (doc DuckDB 2.0 consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 3** · L170 — Vérifier les tests livrés avec dbt.

```mission
{
  "title": "Les quatre tests dbt à poser partout",
  "url": "https://docs.getdbt.com/docs/build/data-tests",
  "steps": [
    "Ouvrez la page « Data tests » de la documentation dbt",
    "Repérez la partie consacrée aux tests génériques (generic data tests)",
    "Listez les tests fournis « out of the box »"
  ],
  "question": "Quels sont les quatre tests génériques fournis nativement par dbt ?",
  "hint": "Deux portent sur une colonne seule, un sur une liste de valeurs, un sur une autre table.",
  "answer": "unique, not_null, accepted_values et relationships (état de la documentation en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 4** · L177 — Configurer Presidio pour un corpus français.

```mission
{
  "title": "Détecter les données personnelles en français",
  "url": "https://microsoft.github.io/presidio",
  "steps": [
    "Ouvrez la documentation officielle de Presidio",
    "Dans la partie Analyzer, ouvrez la page consacrée au support multilingue (« Supporting new languages » ou équivalent)",
    "Repérez comment déclarer un modèle spaCy pour une langue et la liste des langues supportées par l'analyseur"
  ],
  "question": "Quels deux réglages faut-il faire pour analyser du texte français, et quel paramètre passe-t-on à analyze() ?",
  "hint": "Il y a une configuration du moteur NLP et un paramètre du constructeur AnalyzerEngine.",
  "answer": "Déclarer un modèle français dans la configuration du moteur NLP (ex. spaCy fr_core_news_lg) et passer supported_languages=[\"fr\"] à AnalyzerEngine ; puis appeler analyze(..., language=\"fr\"). Les reconnaisseurs à motifs doivent eux aussi être déclarés pour \"fr\" (documentation consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 5** · L158 — Lire le programme d'une certification data reconnue.

```mission
{
  "title": "Une certification data qui parle d'IA",
  "url": "https://cloud.google.com/certification/data-engineer",
  "steps": [
    "Ouvrez la page officielle de la certification Professional Data Engineer",
    "Repérez la durée, le nombre de questions et le prix",
    "Ouvrez le guide d'examen lié et repérez la section consacrée aux données pour l'IA et le ML"
  ],
  "question": "Quels sont la durée, le nombre de questions et le prix de l'examen, et quel sous-domaine traite de la préparation des données pour l'IA ?",
  "hint": "Le sous-domaine est numéroté 4.2.",
  "answer": "2 heures, 40 à 50 questions, 200 $ (+ taxes) ; sous-domaine 4.2 « Preparing data for AI and ML » (page consultée en nov. 2026 ; tarifs et contenus susceptibles d'évoluer) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```


## 6. Quiz éclair

```quiz
{
  "q": "Pourquoi une requête analytique lit-elle souvent beaucoup moins de données sur un fichier Parquet que sur le même CSV ?",
  "options": ["Parquet stocke les lignes triées par date", "Parquet range les données par colonne", "Parquet supprime les doublons à l'écriture", "Parquet charge tout le fichier en mémoire vive"],
  "answer": 1,
  "explanation": "Format colonnaire : on ne lit que les colonnes utiles, et des valeurs semblables se compressent bien (L152)."
}
```

```quiz
{
  "q": "À quoi sert une dimension SCD de type 2 ?",
  "options": ["À supprimer les clients inactifs", "À garder l'historique des valeurs", "À chiffrer les colonnes sensibles", "À fusionner deux tables de faits"],
  "answer": 1,
  "explanation": "On garde l'ancienne valeur datée au lieu de l'écraser : on sait où habitait le client au moment de sa commande (L154)."
}
```

```quiz
{
  "q": "Que signifie « idempotent » pour un pipeline de chargement ?",
  "options": ["Il s'exécute toujours en moins d'une heure", "Rejoué deux fois, il donne le même résultat", "Il ne lit jamais deux fois la même source", "Il s'arrête de lui-même à la première erreur"],
  "answer": 1,
  "explanation": "Rejouer un chargement ne doit ni dupliquer ni corrompre les données : c'est la condition de la reprise et du backfill (L153, L161)."
}
```

```quiz
{
  "q": "Dans DuckDB, quelle clause filtre le résultat d'une fonction de fenêtre comme ROW_NUMBER() ?",
  "options": ["La clause WHERE", "La clause QUALIFY", "La clause HAVING", "La clause FILTER"],
  "answer": 1,
  "explanation": "WHERE filtre avant les fenêtres, HAVING après les agrégats, QUALIFY après les fenêtres ; absente de PostgreSQL, elle se remplace par une sous-requête (L153)."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : après pseudonymisation par Presidio avec une table de correspondance conservée, le corpus n'est plus soumis au RGPD.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Tant qu'un retour en arrière est possible, les données restent personnelles ; le risque baisse, les obligations demeurent (L028, L177)."
}
```

## 7. Points de vigilance juridiques

- **RGPD** (L174 « Sécurité et conformité dans le pipeline : RGPD, contrôle d'accès, chiffrement, AI Act art. 10 », L028 « RGPD et données personnelles dans les prompts (CNIL) ») : minimisation par couche (bronze, silver, gold), contrôle d'accès au moindre privilège (lignes et colonnes), chiffrement et secrets, **droit à l'effacement propagé** jusqu'aux index vectoriels ; pseudonymiser n'est pas anonymiser.
- **AI Act, article 10** (L174 « Sécurité et conformité dans le pipeline : RGPD, contrôle d'accès, chiffrement, AI Act art. 10 ») : pour un système à haut risque, jeux d'entraînement, de validation et de test pertinents, suffisamment représentatifs et, autant que possible, exempts d'erreurs ; gouvernance documentée.
- **Propriété intellectuelle** (L030 « Droit d'auteur, deepfakes, biais et discriminations », L175 « Construire un corpus texte : extraction (Docling, Trafilatura), normalisation, langue, filtres qualité (méthode FineWeb) ») : collecter un corpus web suppose de respecter les réserves (opt-out TDM) et les licences des jeux de données ; tracer la provenance dans un manifeste.
- **Données sensibles et secret professionnel** (L063 « Politique IA interne, conformité AI Act et RGPD ») : santé, données bancaires, pièces couvertes = niveau « réglementé » ; pipeline local ou hébergé sous contrat.

## 8. Certifications tierces (préparation, jamais équivalence)

Ce parcours **prépare** aux certificats suivants, sans en être l'équivalent ni être reconnu par leurs éditeurs ; les certifications data portent largement sur des services propriétaires que le N5 présente sans les pratiquer en profondeur (voir `referentiel/correspondance-certifications.md`) :
- **dbt Analytics Engineering Certification Exam** (200 $, 65 questions, seuil 65 %) : la plus proche du N5, couverture d'environ 65 %.
- **Databricks Certified Data Engineer Associate** (≈ 55 %), **Google Cloud Professional Data Engineer** (≈ 50 %), **AWS DEA-C01** (≈ 45 %), **Microsoft DP-700** (≈ 40 %).
- Piste analyst : **Google AI Professional Certificate**, cours « AI for Data Analysis » (couvert à 100 % par M13).
