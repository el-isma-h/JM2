# Parcours métier — Comptable & finance

> 🧭 Pour les comptables, collaborateurs et experts-comptables, contrôleurs de gestion, trésoriers et DAF de PME qui veulent automatiser la collecte, l'analyse et le reporting sans jamais laisser le modèle « deviner » un chiffre. Aucun prérequis technique.

## 1. Ce que l'IA change pour vous en 2026

Un modèle de langage n'est pas une calculatrice : il prédit du texte, et un total « de tête » peut être faux avec aplomb. La bonne nouvelle : les assistants de 2026 savent **exécuter du code** dans un bac à sable pour calculer réellement, et vous pouvez l'exiger (L055 « Analyser un fichier CSV / Excel avec ChatGPT et Claude »).

Concrètement, l'IA vous aide à expliquer des écarts budgétaires, à pré-classer des dépenses pour relecture, à rédiger la note mensuelle à la direction (L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique ») et à automatiser un reporting où **le code calcule, le modèle rédige et le code contrôle** (L058 « Automatiser un reporting hebdomadaire »). Elle extrait aussi date, montant et TVA des pièces reçues, avec revue humaine des gros montants (L040).

Votre contrainte principale est la confidentialité. Données bancaires, paies, dossiers clients d'un cabinet soumis au secret professionnel : c'est le niveau « réglementé » de la classification, pour lequel le modèle local est l'option par défaut (L063 « Politique IA interne, conformité AI Act et RGPD », L041 « Pourquoi un LLM local : confidentialité, coût, latence, souveraineté »). Relisez l'histoire du « comptable trop pressé » qui ouvre L028.

## 2. Parcours conseillé

Le **niveau 1 complet** (25 h) donne le certificat « Utilisateur IA certifié » ; le parcours ci-dessous en garde l'essentiel et ajoute des leçons des modules M09, M10, M11, M13 et M15 du niveau 2.

**Socle N1** — 14 leçons, 10 h 05

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un LLM ? Tokens, paramètres, poids | 45 |
| L008 | Fenêtre de contexte, température, hallucinations : les limites à connaître | 40 |
| L015 | Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes | 45 |
| L016 | Techniques : exemples (few-shot), raisonnement pas à pas, décomposition | 45 |
| L018 | Prompts métiers : rédiger, résumer, analyser, traduire, tabuler | 45 |
| L019 | Itérer et évaluer : bibliothèque de prompts personnelle | 40 |
| L021 | Cas d'usage par métier : RH, vente, marketing, finance, support, juridique | 45 |
| L022 | Productivité : documents, e-mails, réunions, tableurs, présentations | 45 |
| L023 | Vérifier, sourcer, corriger : la relecture critique des sorties IA | 40 |
| L028 | RGPD et données personnelles dans les prompts (CNIL) | 40 |
| L029 | AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA | 45 |
| L030 | Droit d'auteur, deepfakes, biais et discriminations | 40 |
| L031 | Sécurité au quotidien : clés, phishing IA, shadow AI | 40 |
| L025 | n8n : découverte et premier workflow (aligné n8n Level 1) | 50 |

**Prioritaires N2** — 9 leçons, 8 h 40

| Leçon | Titre | Durée (min) |
|---|---|---|
| L040 | Zapier, comparatif et grille de choix | 60 |
| L041 | Pourquoi un LLM local : confidentialité, coût, latence, souveraineté | 45 |
| L050 | Projets Claude, GPT personnalisés, Gems : la connaissance embarquée | 55 |
| L055 | Analyser un fichier CSV / Excel avec ChatGPT et Claude | 60 |
| L056 | Visualisations et rapports générés | 60 |
| L057 | SQL en langage naturel | 60 |
| L058 | Automatiser un reporting hebdomadaire | 60 |
| L062 | SaaS, API ou local : coûts, risques, grille de décision | 60 |
| L063 | Politique IA interne, conformité AI Act et RGPD | 60 |

**Facultatives** — 7 leçons, 6 h 40. Pour installer un modèle local ou construire une base documentaire fiscale.

| Leçon | Titre | Durée (min) |
|---|---|---|
| L032 | Nœuds, expressions et structure des données (n8n Level 1 approfondi) | 55 |
| L036 | Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks | 55 |
| L043 | Ollama : installer, télécharger un modèle, dialoguer, API locale | 60 |
| L044 | LM Studio, Jan, Open WebUI : interfaces graphiques | 55 |
| L046 | Brancher un LLM local sur n8n et vos applications (API compatible OpenAI) | 60 |
| L047 | Embeddings et recherche sémantique | 55 |
| L049 | Découpage (chunking), qualité et évaluation d'un RAG | 60 |

> ⏱ **Durée totale du parcours conseillé : 18 h 45** de leçons et d'exercices (quiz de module non compris), **25 h 25** avec toutes les leçons facultatives.

## 3. Dix cas d'usage

🟢 relecture rapide · 🟠 contrôle des faits · 🔴 validation experte (L021).

### Cas 1 — Expliquer les écarts budget / réalisé
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🟠
```text
Rôle : contrôleur de gestion d'une PME de distribution. Contexte : tableau budget/réalisé d'octobre (CSV ci-dessous). Tâche : les 5 plus gros écarts en valeur absolue, 2 hypothèses chacun. Contraintes : recalcule les écarts et affiche le calcul ; formule les causes comme des questions aux responsables.
```

### Cas 2 — Analyser un export comptable avec du code
Leçon : L055 « Analyser un fichier CSV / Excel avec ChatGPT et Claude » · 🟠
```text
Fichier joint : export du grand livre (colonnes compte, date, libellé, débit, crédit). Écris et exécute le code qui calcule le solde par compte de classe 6 ; affiche le code, puis un tableau. Ne donne aucun chiffre qui ne sorte pas du code.
```

### Cas 3 — Pré-classer des dépenses
Leçon : L021 « Cas d'usage par métier : RH, vente, marketing, finance, support, juridique » · 🔴 — Libellés seuls (sans données personnelles) → nature comptable proposée avec un indice de confiance → validation ligne à ligne par le comptable.

### Cas 4 — La note mensuelle à la direction
Leçon : L058 « Automatiser un reporting hebdomadaire » · 🟠
```text
Voici les indicateurs du mois, déjà calculés (JSON ci-dessous), et la note du mois dernier. Rédige la note de 200 mots : faits marquants, 3 points d'attention. N'invente ni ne recalcule aucun chiffre ; reprends-les tels quels.
```

### Cas 5 — Le graphique de trésorerie
Leçon : L056 « Visualisations et rapports générés » · 🟠 — Courbe sur 12 mois, axe des ordonnées à zéro, unité en k€, titre qui porte le message ; contrôle des valeurs contre le tableau source.

### Cas 6 — Interroger la base de facturation en français
Leçon : L057 « SQL en langage naturel » · 🟠
```text
Dialecte : PostgreSQL. Schéma : factures(id, client_id, date_emission, montant_ht, statut). Question : chiffre d'affaires HT par mois en 2026, factures « payée » uniquement. Donne une requête SELECT seule, puis un total de contrôle à vérifier.
```

### Cas 7 — Extraire les données des factures reçues
Leçon : L040 « Zapier, comparatif et grille de choix » · 🔴 — Workflow n8n auto-hébergé : e-mail → extraction date, montant, TVA → contrôle de cohérence HT + TVA = TTC → revue humaine au-delà de 5 000 € → dépôt dans l'outil de production.

### Cas 8 — Repérer les anomalies d'un fichier de paiements
Leçon : L055 « Analyser un fichier CSV / Excel avec ChatGPT et Claude » · 🟠 — Faire calculer en code les doublons (même montant, même fournisseur, même semaine), les montants ronds inhabituels et les fournisseurs nouveaux ; chaque alerte est vérifiée à la pièce.

### Cas 9 — Chiffrer SaaS, API ou local pour le cabinet
Leçon : L062 « SaaS, API ou local : coûts, risques, grille de décision » · 🟠 — Coût total sur 3 ans (sièges ou tokens, hébergement, mise en place, administration, formation, sortie), puis critère « les données ne sortent pas ».

### Cas 10 — Expliquer un bilan à un dirigeant
Leçon : L018 « Prompts métiers : rédiger, résumer, analyser, traduire, tabuler » · 🟢
```text
Reformule cette synthèse de bilan validée pour un gérant non financier : 250 mots, phrases courtes, chaque terme technique expliqué en une ligne. N'ajoute aucun chiffre ni aucune interprétation.
```

## 4. Trois projets fil rouge

### Projet 1 — Le reporting mensuel automatisé
- **Énoncé** : produire chaque mois la note de gestion à partir d'un tableur.
- **Livrable** : workflow planifié (lecture → calculs en code → rédaction → contrôle → envoi), note type.
- **Critères de réussite** : tous les chiffres de la note proviennent du code ; une alerte se déclenche si un indicateur sort de sa plage ; coût par note chiffré.
- **Leçons** : L056, L058 · **Lab** : [`lab-reporting`](../labs/lab-reporting/) (n8n ou Python, mode sans clé).

### Projet 2 — La collecte des pièces clients
- **Énoncé** : classer les pièces reçues par e-mail et en extraire les champs comptables.
- **Livrable** : workflow avec contrôle HT/TVA/TTC, file de revue humaine, journal des erreurs.
- **Critères de réussite** : 100 % des montants > 5 000 € revus ; aucune pièce perdue sur un lot de test de 50 ; données hébergées en France ou en local.
- **Leçons** : L025, L040, L055 · **Lab** : aucun lab dédié ; reprendre le schéma de validation humaine de [`lab-n8n-support`](../labs/lab-n8n-support/).

### Projet 3 — La base documentaire fiscale et sociale en local
- **Énoncé** : interroger vos notes internes et procédures sans que rien ne quitte le cabinet.
- **Livrable** : RAG sur modèle local, 10 questions de test notées, note de choix d'hébergement.
- **Critères de réussite** : réponses sourcées ; 8 sur 10 correctes ; aucun document client dans la base de test.
- **Leçons** : L041, L043, L047, L048 · **Lab** : [`lab-rag-sans-code`](../labs/lab-rag-sans-code/) avec Ollama (8 Go de RAM).

## 5. Missions documentation

**Mission 1** · L055 — Vérifier la taille maximale d'un export envoyé à Claude.

```mission
{
  "title": "Le grand livre tient-il dans un seul fichier ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/files",
  "steps": [
    "Ouvrez la page Files API de la documentation Claude Platform",
    "Cherchez la section des limites (file storage / limits)",
    "Relevez la taille maximale d'un fichier et le stockage total par organisation"
  ],
  "question": "Quelle est la taille maximale d'un fichier envoyé via la Files API, et quel est le plafond de stockage par organisation ?",
  "hint": "Les deux chiffres s'expriment l'un en mégaoctets, l'autre en téraoctets.",
  "answer": "500 Mo par fichier et 1 To par organisation (nov. 2026) — vérifiez : les limites évoluent (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

**Mission 2** · L055 — Chiffrer l'outil qui exécute vraiment vos calculs.

```mission
{
  "title": "Faire calculer plutôt que deviner : le coût",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool",
  "steps": [
    "Ouvrez la page Code execution tool",
    "Repérez la section consacrée à l'usage et à la tarification (usage and pricing)",
    "Notez le nombre d'heures gratuites et le prix au-delà"
  ],
  "question": "Combien d'heures d'exécution de code sont offertes chaque mois, et combien coûte l'heure supplémentaire ?",
  "hint": "Le quota gratuit dépasse le millier d'heures ; le prix horaire se compte en centimes de dollar.",
  "answer": "1 550 heures gratuites par mois, puis 0,05 $ de l'heure (nov. 2026) — vérifiez : les prix évoluent (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 3** · L049 — Budgéter l'OCR d'un fonds de pièces scannées.

```mission
{
  "title": "Numériser les archives de factures",
  "url": "https://docs.mistral.ai/models/ocr-4-1",
  "steps": [
    "Ouvrez la fiche du modèle OCR 4.1 dans la documentation Mistral",
    "Repérez la description de ce que fait le modèle (types de documents acceptés)",
    "Cherchez le prix, exprimé par lot de pages"
  ],
  "question": "Combien coûte le traitement de 1 000 pages avec Mistral OCR 4.1, et combien vous coûterait un fonds de 12 000 pages d'anciens contrats scannés ?",
  "hint": "Le prix est donné pour 1 000 pages ; multipliez ensuite par 12.",
  "answer": "Environ 4 $ les 1 000 pages, soit environ 48 $ pour 12 000 pages (relevé nov. 2026 — vérifiez la page de tarifs Mistral avant de budgéter).",
  "xp": 15
}
```

**Mission 4** · L058 — Refaire le calcul de coût d'un rapport généré.

```mission
{
  "title": "Le coût réel d'un reporting automatisé",
  "url": "https://platform.claude.com/docs/en/about-claude/pricing",
  "steps": [
    "Ouvrez la page Pricing de Claude Platform",
    "Trouvez la ligne Claude Haiku 5.5 dans le tableau des modèles",
    "Lisez les prix par million de tokens en entrée (input) et en sortie (output), puis refaites le calcul de la section 6 de la leçon L058 avec 900 tokens en entrée et 250 en sortie"
  ],
  "question": "Quels sont les prix de Claude Haiku 5.5, et le coût d'un rapport est-il bien d'environ 0,0002 $ ?",
  "hint": "(900 × prix entrée + 250 × prix sortie) / 1 000 000.",
  "answer": "0,10 $ en entrée et 0,50 $ en sortie par million de tokens ; (900 × 0,10 + 250 × 0,50) / 1 000 000 = 0,000215 $, soit environ 0,0002 $ par rapport (nov. 2026) — vérifiez : les prix évoluent (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

**Mission 5** · L038 — Mesurer l'économie du cache de prompt sur un traitement répétitif.

```mission
{
  "title": "Des consignes répétées qui coûtent moins cher",
  "url": "https://platform.claude.com/docs/en/about-claude/pricing",
  "steps": [
    "Ouvrez la page Pricing de Claude Platform",
    "Repérez la ligne Claude Sonnet 5.5",
    "Comparez le prix d'entrée normal et le prix de lecture du cache (cache read / cache hits)"
  ],
  "question": "Combien coûte, pour Sonnet 5.5, un million de tokens d'entrée relus depuis le cache, comparé au prix d'entrée normal ? Pourquoi est-ce intéressant pour le projet de la leçon L038 ?",
  "hint": "Le System Message est identique pour chaque ticket.",
  "answer": "0,10 $ par million de tokens lus en cache, contre 2 $ en entrée normale (vérifié le 5 nov. 2026). Le System Message répété à chaque ticket peut donc coûter vingt fois moins cher s'il est mis en cache.",
  "xp": 20
}
```


## 6. Quiz éclair

```quiz
{
  "q": "Vous demandez à l'assistant « le total des factures impayées » d'un fichier de 2 000 lignes. Comment fiabiliser le chiffre ?",
  "options": ["Reposer la même question deux fois de suite", "Exiger un calcul exécuté en code et le contrôler", "Lui demander d'être très attentif aux décimales", "Choisir le modèle le plus cher de l'éditeur"],
  "answer": 1,
  "explanation": "Une réponse « de tête » est une prédiction de texte ; un calcul exécuté dans un bac à sable est vérifiable, et on recalcule un total de contrôle (L055)."
}
```

```quiz
{
  "q": "Dans un reporting automatisé bien conçu, quel est le rôle du modèle de langage ?",
  "options": ["Calculer lui-même les indicateurs du mois", "Rédiger à partir de chiffres calculés", "Valider seul les chiffres avant envoi", "Remplacer le service de contrôle de gestion"],
  "answer": 1,
  "explanation": "Le code calcule, le modèle rédige, le code contrôle : le prompt interdit d'inventer ou de recalculer (L058)."
}
```

```quiz
{
  "q": "Un cabinet d'expertise comptable veut faire résumer des dossiers clients. Quelle option est l'option par défaut ?",
  "options": ["Un compte gratuit bien paramétré", "Un modèle local, hébergé en interne", "N'importe quelle API bon marché", "Un compte personnel du collaborateur"],
  "answer": 1,
  "explanation": "Données sous secret professionnel = niveau 4 « réglementé » : local par défaut, sinon analyse juridique et AIPD avant tout service externe (L063)."
}
```

```quiz
{
  "q": "La requête SQL proposée par l'IA contient un DELETE. Quel garde-fou aurait dû l'empêcher ?",
  "options": ["Un compte de base en lecture seule", "Un prompt rédigé plus poliment", "Une police de caractères plus grande", "Un modèle plus récent et plus rapide"],
  "answer": 0,
  "explanation": "On ne fait exécuter le SQL généré qu'avec des droits en lecture seule, après lecture critique et test sur un jeu connu (L057)."
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : si l'IA pré-classe correctement 95 % des dépenses, on peut intégrer ses propositions en comptabilité sans relecture.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Le pré-classement reste en vérification 🔴 : le comptable valide, car une erreur engage l'entreprise (L021)."
}
```

## 7. Points de vigilance juridiques

- **Secret professionnel** (L062 « SaaS, API ou local : coûts, risques, grille de décision », L063 « Politique IA interne, conformité AI Act et RGPD ») : dossiers clients d'un expert-comptable = niveau « réglementé » ; modèle local par défaut, sinon contrat de sous-traitance, résidence UE, non-réutilisation des données, analyse juridique et AIPD.
- **RGPD** (L028 « RGPD et données personnelles dans les prompts (CNIL) ») : paies, coordonnées bancaires et arrêts maladie sont des données personnelles, parfois sensibles ; pseudonymisez (`SAL-001`) et n'envoyez que les colonnes utiles. Le responsable de traitement est le cabinet employeur, pas le collaborateur.
- **AI Act** (L029 « AI Act : catégories de risque, calendrier, obligation d'alphabétisation IA ») : l'octroi de crédit relève du haut risque (annexe III, au 2 décembre 2027) ; article 4 pour tous les usages.
- **Fraude** (L031 « Sécurité au quotidien : clés, phishing IA, shadow AI ») : fraude au président par voix clonée, faux fournisseur ; double canal avant tout virement ou changement d'IBAN.
- **Responsabilité** : un chiffre faux reste le vôtre ; conservez le code de calcul.

## 8. Certifications tierces (préparation, jamais équivalence)

Ce parcours **prépare** aux certificats suivants, sans en être l'équivalent ni être reconnu par leurs éditeurs (voir `referentiel/correspondance-certifications.md`) :
- **Google AI Professional Certificate** : cours « AI for Data Analysis », couvert à 100 % par M13 (L055-L058).
- OpenAI Academy, badge **« AI Foundations »** (tableur et données, usage responsable) puis **« Applied AI Foundations »**.
- **n8n Academy** N8N101 à N8N103 et **Make Academy** : certificats de complétion et badges, utiles pour l'automatisation ; ce ne sont pas des certifications.
