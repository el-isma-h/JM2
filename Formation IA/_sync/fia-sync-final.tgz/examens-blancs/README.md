# Examens blancs d'entraînement aux certifications tierces — NF-IA-150

Version 1.0 — 5 novembre 2026. Faits vérifiés d'après `_recherche/01`, `02`, `06` et `07-mise-a-jour-nov-2026.md` (état au 5 novembre 2026) et `referentiel/correspondance-certifications.md`.

---

## ⚠️ Avertissement (à reproduire dans toute communication)

1. **Ces examens blancs sont des outils d'entraînement non officiels**, rédigés par Next Formation. Ils ne sont ni fournis, ni relus, ni approuvés, ni reconnus par Anthropic, Microsoft, Google, Coursera ou Databricks. **Next Formation n'a aucun lien avec ces éditeurs** et n'est pas centre d'examen.
2. **Les 170 questions sont 100 % originales.** Elles ont été écrites à partir des leçons NF-IA-150 et de la documentation publique des éditeurs. **Elles ne reproduisent aucune question réelle d'examen** et ne prétendent pas en donner un aperçu. Nous ne détenons aucune question officielle et n'en utilisons aucune.
3. **Un bon score ne garantit pas la réussite** à l'examen officiel : formats, nombre de questions, questions à réponses multiples, barème et contenu exact diffèrent. Le seuil indiqué dans chaque fichier est un seuil d'entraînement.
4. Les noms de certifications sont cités pour désigner le référentiel visé, sans aucune affiliation. Prix, conditions et dates ont été relevés au 5 novembre 2026 : **revérifiez-les sur la page officielle avant toute inscription ou communication commerciale** (Qualiopi, indicateur 1 : information exacte du public).

---

## 1. Les cinq examens

| Fichier | Certification visée (nom exact) | Questions | Durée | Seuil d'entraînement | Origine des pondérations |
|---|---|---|---|---|---|
| `claude-developer-foundations.json` | Claude Certified Developer – Foundations | 40 | 90 min | 72 % | Sources tierces concordantes reprenant le guide d'examen v1.0 (juillet 2026) |
| `claude-architect-foundations.json` | Claude Certified Architect – Foundations | 40 | 80 min | 72 % | Idem |
| `microsoft-ai-901.json` | Microsoft Certified: Azure AI Fundamentals (examen AI-901) | 30 | 45 min | 70 % | Source tierce s'appuyant sur Microsoft Learn (page officielle non ouverte) |
| `google-ai-essentials.json` | Google AI Essentials | 30 | 45 min | 80 % | **Non officielle** : prorata des durées des 5 cours Coursera (pas d'examen pondéré) |
| `databricks-data-engineer-associate.json` | Databricks Certified Data Engineer Associate | 30 | 60 min | 70 % | Page officielle, guide d'examen d'août 2026 |

Les questions sont réparties entre domaines au prorata des pondérations (méthode du plus fort reste) ; le détail figure dans le champ `domaines` de chaque fichier. Les durées sont celles des examens officiels ramenées au nombre de questions, quand elles sont connues.

### Format

Même format que `examens/N1-examen.json` (`title`, `passScore`, `timeLimitMinutes`, `questions` avec `id`, `lessonId`, `type`, `q`, `options`, `answer` — index à partir de 0 —, `explanation`, `source`), plus :

- `certification` : nom exact de la certification visée ;
- `domaines` : liste `{nom, poids, questions, source}` (pondération officielle ou tierce, et sa source) ;
- `domaine` sur chaque question ;
- `avertissement` et `notes` : rappel du caractère non officiel et des choix de transposition (seuil, durée).

Toutes les questions sont des mises en situation professionnelles (quelques `qcm` et `trouve_erreur`), avec **une seule bonne réponse** parmi 4 options.

### Contrôles réalisés (script de validation, 5 novembre 2026)

JSON valide et champs obligatoires présents ; 4 options distinctes et `answer` dans les bornes ; **bonne réponse jamais plus longue de plus de 15 % que la plus longue des autres options** ; positions de la bonne réponse équilibrées (10/10/10/10 sur 40, 8/8/7/7 sur 30) ; `lessonId` présents dans `programme/programme.json` ; nombre de questions par domaine conforme ; sources en `https://` ; absence de doublon entre examens blancs et de proximité excessive avec les 770 questions des examens et quiz de la formation et avec les quiz intégrés aux leçons.

### Mode d'emploi conseillé

1. Passez l'examen blanc en temps limité, sans documentation (les examens Anthropic sont « livre fermé »).
2. Relisez chaque explication, y compris pour les questions réussies.
3. Pour chaque domaine sous 70 %, révisez les leçons indiquées ci-dessous, puis la documentation officielle citée dans le champ `source`.
4. Complétez toujours par les ressources de préparation **officielles** de l'éditeur.

---

## 2. Claude Certified Developer – Foundations et Claude Certified Architect – Foundations

### Conditions d'accès réelles (FAQ officielle, relue le 5/11/2026)

- **Réservées aux employés d'organisations membres du Claude Partner Network** : « *Certification is currently available only to organizations in the Claude Partner Network* ». Il faut une adresse e-mail professionnelle sur un domaine reconnu et avoir **18 ans minimum** (pièce d'identité).
- **Un organisme de formation ne peut ni vendre ni faire passer ces certifications.** Un apprenant dont l'employeur n'est pas partenaire ne peut pas s'inscrire. Ce qui est ouvert à tous, ce sont les **badges gratuits de Claude Academy** (délivrés à la réussite du dernier quiz, sans expiration).
- **Prix** (USD, avant remise partenaire) : Developer – Foundations **125 $** ; Architect – Foundations **125 $** (99 $ jusqu'au 30 juin 2026). Remise de 50 % pour les paliers Select, Preferred et Global Premier ; 100 % pour Global Premier jusqu'au 31 décembre 2026.
- **Format** : examen surveillé Pearson VUE (en ligne OnVUE ou en centre), **120 min**, QCM à réponse unique et à réponses multiples sur scénarios, **livre fermé** (ni notes, ni documentation, ni outils d'IA, ni traduction du navigateur), score de 100 à 1 000, **seuil 720**, en **anglais ou en japonais**, badges Credly. Nombre de questions non publié par la FAQ : 53 (Developer) et 60 (Architect, 4 scénarios tirés parmi 6) selon les sources tierces.
- **Validité 12 mois** ; recertification par une évaluation non surveillée gratuite sur la Partner Academy. **4 tentatives par 12 mois glissants** (attente de 14, 30 puis 90 jours), chaque tentative au plein tarif (remise de palier comprise).
- Les **pondérations des domaines** viennent de sources tierces concordantes (CloudThat, claudearchitectcertification.com, pasqualepillitteri.it) qui reprennent les guides d'examen v1.0 de juillet 2026 ; les PDF officiels n'ont pas pu être ouverts. À confirmer sur le guide officiel.

### Liens officiels

- FAQ certifications : https://anthropic-partners.skilljar.com/page/faq-certifications
- Page Partner certifications : https://anthropic-partners.skilljar.com/page/partner-certifications
- Developer – Foundations : https://anthropic-partners.skilljar.com/claude-certified-developer-foundations-certification
- Architect – Foundations : https://anthropic-partners.skilljar.com/claude-certified-architect-foundations-certification
- Badges gratuits ouverts à tous : https://academy.claude.com/courses (notamment « Building with the Claude API », « Claude Platform 101 », « Claude Code 101 », « Claude Code in action », « Introduction to Model Context Protocol », « Model Context Protocol: Advanced topics »)

### Leçons à réviser — Developer – Foundations

| Domaine (poids) | Questions | Leçons NF-IA-150 |
|---|---|---|
| Applications & Integration (33,1 %) | 13 | L065, L066, L067, L068, L071, L072, L101, L102, L105 |
| Model Selection & Optimization (16,8 %) | 7 | L009, L067, L068, L073 |
| Agents & Workflows (14,7 %) | 6 | L074, L095, L097, L098, L099, L100 |
| Prompt & Context Engineering (11,0 %) | 5 | L068, L069, L071, L073 |
| Tools & MCPs (10,6 %) | 4 | L070, L075, L099 |
| Security & Safety (8,1 %) | 3 | L106, L107, L108, L109 |
| Claude Code (3,1 %) | 1 | L074 |
| Evaluation, Testing & Debugging (2,6 %) | 1 | L076, L103, L104 |

### Leçons à réviser — Architect – Foundations

| Domaine (poids) | Questions | Leçons NF-IA-150 |
|---|---|---|
| Agentic Architecture & Orchestration (27 %) | 11 | L074, L095, L096, L097, L098, L099, L100 |
| Claude Code Configuration & Workflows (20 %) | 8 | L074, L075, L076, L104 |
| Prompt Engineering & Structured Output (20 %) | 8 | L016, L017, L020, L069, L071, L076 |
| Tool Design & MCP Integration (18 %) | 7 | L070, L075, L099 |
| Context Management & Reliability (15 %) | 6 | L008, L067, L073, L102 |

Faits sensibles à jour au 5/11/2026 (`_recherche/07`) intégrés aux questions : `temperature`, `top_p` et `top_k` refusés sur tous les modèles avec la version d'API `2026-10-21` ; `tool_choice` forcé refusé sur Opus 5.5 et Sonnet 5.5 mais accepté sur Haiku 5.5 ; messages `user` consécutifs fusionnés et non rejetés ; SDK v2 authentifiés par `Authorization: Bearer` ; MCP `2026-07-28` stable et sans état.

---

## 3. Microsoft Certified: Azure AI Fundamentals — examen AI-901

### Conditions d'accès réelles

- **Ouvert à tous**, sans prérequis formel. Microsoft recommande des notions de syntaxe Python, des concepts d'IA et des ressources Azure.
- **AI-900 a été retiré le 30 juin 2026** et remplacé par **AI-901** (bêta le 15 avril 2026, disponibilité générale en juin 2026), pour le même titre « Microsoft Certified: Azure AI Fundamentals ». Les titulaires d'AI-900 n'ont rien à faire.
- **Prix selon le pays**, affiché à l'inscription ; environ 99 $ selon des sources tierces, montant non publié globalement par Microsoft.
- **Score de réussite 700/1000**. Durée et nombre de questions non publiés dans nos sources. Anglais d'abord, localisations ensuite.
- Deux domaines : **Identifier les concepts et capacités de l'IA (40-45 %)** et **Implémenter des solutions IA avec Microsoft Foundry (55-60 %)** (source tierce ; la page officielle AI-901 n'a pas pu être ouverte : à confirmer).
- **Point faible assumé** : NF-IA-150 n'est pas une formation Azure. Elle couvre le domaine 2 à environ 30 % seulement. Les questions de ce domaine restent au niveau des concepts d'implémentation communs (déploiement, authentification, RAG, filtres de contenu, évaluation, quotas). **Passez impérativement le parcours gratuit Microsoft Learn** (examen d'entraînement officiel et bac à sable) avant l'examen.

### Liens officiels

- Page de l'examen AI-901 : https://learn.microsoft.com/en-us/credentials/certifications/exams/ai-901/
- Study guide AI-900 (examen retiré, utile comme base de contenu) : https://learn.microsoft.com/certifications/resources/study-guides/AI-900

### Leçons à réviser

| Domaine (poids) | Questions | Leçons NF-IA-150 |
|---|---|---|
| Identifier les concepts et capacités de l'IA (40-45 %) | 13 | L001, L002, L003, L005, L006, L028, L029, L030, L061 (M01, M02, M07) |
| Implémenter des solutions IA avec Microsoft Foundry (55-60 %) | 17 | L017, L022, L029, L062, L065, L067, L072, L078, L089, L093, L095, L103, L108, L109, L135 ; Azure cité en L062, L087, L088 + parcours Microsoft Learn |

---

## 4. Google AI Essentials

### Conditions d'accès réelles

- **Spécialisation Coursera de 5 cours**, ouverte à tous, **sans prérequis technique**. Ce n'est pas un examen surveillé : le **certificat Google** (partageable) s'obtient en suivant les cours et en réussissant leurs évaluations sur Coursera.
- **Prix** : environ **49 $ par mois** (États-Unis et Canada) après 7 jours d'essai gratuit ; inclus dans Coursera Plus ; aide financière possible ; **audit gratuit sans certificat**.
- Durée annoncée : de 4 h à « moins de 10 h » selon les pages (incohérence relevée dans nos sources) ; durées par cours affichées : 1 h, 2 h, 2 h, 1 h, 2 h.
- **Il n'existe pas de pondération officielle** : celle du fichier est calculée par Next Formation au prorata des durées des cours, uniquement pour répartir les questions. Le seuil de 80 % est un choix d'entraînement (le seuil des quiz Coursera n'a pas été vérifié).

### Liens officiels

- Coursera : https://www.coursera.org/google-specializations/ai-essentials-google
- Grow with Google : https://grow.google/enroll-certificates/ai-essentials-mid/

### Leçons à réviser

| Cours (pondération non officielle) | Questions | Leçons NF-IA-150 |
|---|---|---|
| Introduction to AI (12,5 %) | 4 | L001, L002, L003, L004 |
| Maximize Productivity With AI Tools (25 %) | 7 | L010, L011, L012, L013, L021, L022 |
| Discover the Art of Prompting (25 %) | 8 | L014, L015, L016, L017, L018, L019, L020 |
| Use AI Responsibly (12,5 %) | 4 | L023, L028, L029, L030, L031 |
| Stay Ahead of the AI Curve (25 %) | 7 | L004, L009, L012, L029, L064 |

Faits à jour intégrés : article 4 de l'AI Act reformulé par le règlement (UE) 2026/1744 (en vigueur le 27 juillet 2026 : mesures qui *favorisent* la maîtrise de l'IA, sans niveau individuel imposé) ; obligations haut risque de l'annexe III reportées au 2 décembre 2027.

---

## 5. Databricks Certified Data Engineer Associate

### Conditions d'accès réelles

- **Ouvert à tous, sans prérequis.** Examen surveillé de **90 min**, **45 questions notées**, en anglais, japonais, portugais (Brésil) ou coréen. Guide d'examen daté d'**août 2026**.
- **Prix : 200 $.** **Validité : 2 ans.** Le seuil de réussite officiel n'a pas été relevé dans nos sources (70 % = seuil d'entraînement).
- Préparation officielle gratuite : cours *self-paced* de **Databricks Academy** et **Databricks Free Edition** (Spark managé, notebooks, SQL, jobs), sans limite de durée.
- Le N5 couvre environ **55 %** du référentiel : les fondamentaux (Spark, Delta, médaillon, MERGE, CDC, orchestration, CI, gouvernance) sont traités, mais **Auto Loader, `COPY INTO`, Lakeflow Jobs, les pipelines déclaratifs et les Databricks Asset Bundles ne sont pas pratiqués** dans nos leçons. Les questions correspondantes s'appuient sur la documentation publique Databricks : **pratiquez-les sur Free Edition** avant l'examen.

### Liens officiels

- Page de la certification : https://www.databricks.com/learn/certification/data-engineer-associate
- Documentation : https://docs.databricks.com/
- Free Edition : https://www.databricks.com/blog/learn-experiment-and-build-databricks-free-edition

### Leçons à réviser

| Domaine (poids officiel) | Questions | Leçons NF-IA-150 |
|---|---|---|
| Databricks Intelligence Platform (6 %) | 2 | L157, L158 |
| Ingestion et chargement (21 %) | 6 | L161, L162, L169 |
| Transformation et modélisation (22 %) | 7 | L154, L159, L161, L163, L168, L170 |
| Lakeflow Jobs (16 %) | 5 | L164 |
| CI/CD (10 %) | 3 | L165 |
| Dépannage, supervision et optimisation (10 %) | 3 | L159, L173 |
| Gouvernance et sécurité (15 %) | 4 | L157, L172, L174 |

---

## 6. Limites connues et mises à jour

- Les pondérations Anthropic et AI-901 proviennent de sources tierces : à revérifier dès que les guides officiels sont accessibles. En cas d'écart, il suffit de mettre à jour le champ `domaines` et de rééquilibrer les questions.
- Les modèles, prix et paramètres cités (Claude 5.5, Fable 5.1, version d'API `2026-10-21`, MCP `2026-07-28`, etc.) sont ceux du 5 novembre 2026. Les examens blancs doivent être relus à chaque mise à jour de `_recherche/` ou des leçons concernées.
- Les examens officiels comportent des questions à réponses multiples ; ces examens blancs n'en contiennent pas (une seule bonne réponse par question).
- Les certifications dbt, Google Cloud Professional Data Engineer, AWS DEA-C01, DP-700, SnowPro Core et CCDAK, également recommandées pour le N5 (correspondance-certifications § 13), n'ont pas encore d'examen blanc.
