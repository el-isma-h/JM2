---
module: M04
title: "Fiche mémo — Prompt engineering : parler aux modèles"
---
# Fiche mémo — M04 · Prompt engineering : parler aux modèles

> En une phrase : un prompt est un brief pour un collaborateur brillant mais tout nouveau (et amnésique) : cinq briques R-C-T-F-C, des exemples, des étapes visibles, et une correction à la fois.

## Les 7 idées à retenir
1. **Ce qui n'est pas écrit n'existe pas** : un prompt vague donne la réponse « moyenne », celle de personne. Test : un collègue sans contexte serait-il perdu ? (`L015`)
2. **R-C-T-F-C** : Rôle, Contexte, Tâche, Format, Contraintes. Une réponse décevante = une brique manquante (`L015`).
3. **Montrer plutôt qu'expliquer** : 2 à 5 exemples pertinents, variés, balisés, dont un cas limite commenté (`L016`).
4. **Raisonnement visible pour vérifier** : les modèles 2026 réfléchissent déjà ; imposer des étapes sert à contrôler le chemin. Pour une tâche simple : « réponse directe » (`L016`).
5. **Découper en chaîne** : analyser → confronter → rédiger → faire critiquer → corriger ; chaque maillon se contrôle (`L016`).
6. **Balises = tiroirs étiquetés** ; **system prompt = fiche de poste** permanente (rôle, règles, format), tâche du jour dans le message utilisateur (`L017`).
7. **Itérer avec méthode** : critères mesurables d'abord, 5 à 10 cas de test, **une** correction par version, puis archivage dans une bibliothèque versionnée (`L019`, `L020`).

## Le schéma à connaître

```mermaid
flowchart LR
  A["1. Critères<br/>mesurables"] --> B["2. Prompt v1"]
  B --> C["3. Tests<br/>5 à 10 cas, dont pièges"]
  C -- "un critère échoue" --> D["4. UNE correction<br/>ciblée sur la brique"]
  D --> C
  C -- "tout réussit" --> E["5. Archiver la fiche<br/>vN, date, score"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Prompt | Le brief donné au modèle avant qu'il réponde |
| Few-shot | Coller 2 à 5 exemples pour fixer un style ou un format |
| Chain of thought | Faire « poser le calcul » pour pouvoir le relire |
| Chaîne de prompts | Un chantier découpé en lots contrôlés un par un |
| Balises XML | `<document>…</document>` : séparer consignes, données et exemples |
| System prompt | Les règles permanentes (chez OpenAI : *developer message* / `instructions`) |
| Sortie structurée | Obliger l'IA à remplir un formulaire précis (JSON Schema) |
| Variable `{{ }}` | La case à remplir d'un gabarit réutilisable |
| Injection de prompt | Un faux ordre caché dans un document à traiter |

## Les pièges classiques
- Croire que le rôle donne la compétence : « meilleur avocat du monde » ne rend rien juridiquement sûr.
- Dire ce qu'on ne veut pas : préférez « réponds en prose fluide » à « pas de listes ».
- Trois exemples identiques : couvrez chaque catégorie et un cas ambigu. Le modèle copie aussi les défauts.
- Juger un prompt sur sa dernière réponse : relancez **tous** les cas après chaque correction.
- System prompt-roman ou contradictoire (« détaillé mais concis », « invente si tu ne sais pas »).
- Croire que les balises suffisent contre l'injection : elles réduisent le risque, la relecture reste obligatoire.
- Envoyer des données personnelles inutiles : anonymisez avant.

## Les commandes / chiffres / dates utiles
- **Les 5 verbes du bureau et leur garde-fou** : Rédiger (« n'inventez aucune caractéristique absente ») · Résumer (« uniquement le contenu fourni ; *non précisé* sinon ») · Analyser (« une citation par jugement ») · Traduire (glossaire + « listez vos doutes ») · Tabuler (« — » jamais une estimation).
- **Format = mesure + exemple + formulation positive + « sans préambule »**.
- Long document : **données en haut, question à la fin**.
- Nom de fiche : `[famille] — [usage] — vN`, avec modèle testé, variables, critères, tests et score.
- Chez Anthropic (nov. 2026) : *prefill* non pris en charge à partir de Claude 4.6, `temperature` refusée depuis Claude 4.7 (et sur tous les modèles avec la version d'API 2026-10-21, celle des SDK v2) ; pour un format strict, utiliser la sortie structurée (`output_config.format`). Chez OpenAI : `text.format` avec `strict: true`.
- 2022 : « *Let's think step by step* » fait bondir les bonnes réponses des modèles de l'époque.

## Pour aller plus loin
- [Anthropic — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices)
- [OpenAI — Text generation and prompting](https://developers.openai.com/api/docs/guides/text)
- [DeepLearning.AI — ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Quelle brique protège le mieux contre un chiffre inventé ?
2. Pourquoi ne modifier qu'une seule chose entre deux versions d'un prompt ?
3. Où placer un long contrat dans le prompt, et où placer la question ?

---
**Réponses** — 1. Les contraintes (« uniquement les données fournies ; sinon *non précisé* »). 2. Pour savoir quelle modification a produit l'amélioration ou la dégradation. 3. Le contrat en haut, balisé ; la question à la fin.
