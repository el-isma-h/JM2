---
id: L016
module: M04
level: N1
title: "Techniques : exemples (few-shot), raisonnement pas à pas, décomposition"
minutes: 45
objectives:
  - "Appliquer la technique des exemples (few-shot) pour imposer un style ou un format"
  - "Déclencher et encadrer un raisonnement pas à pas (chain of thought) quand la tâche l'exige"
  - "Décomposer une tâche complexe en chaîne de prompts simples et vérifiables"
skills: ["C1.3"]
sources:
  - { title: "Anthropic — Prompting best practices (Use examples effectively, Chain complex prompts, Leverage thinking)", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "Anthropic — Thinking (adaptive thinking)", url: "https://platform.claude.com/docs/en/build-with-claude/thinking", lang: "en" }
  - { title: "DeepLearning.AI — ChatGPT Prompt Engineering for Developers", url: "https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/", lang: "en" }
  - { title: "xAI — Best practices (text)", url: "https://docs.x.ai/developers/model-capabilities/text/best-practices", lang: "en" }
---

# Techniques : exemples (few-shot), raisonnement pas à pas, décomposition

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 4

## 🎯 Ce que vous saurez faire
- Montrer au modèle « ce que vous voulez » avec deux ou trois exemples plutôt que de l'expliquer en vingt lignes.
- Savoir quand demander un raisonnement explicite, et quand c'est inutile voire contre-productif avec les modèles de 2026.
- Découper un gros projet (dossier de candidature, étude de marché, procédure) en étapes que vous pouvez contrôler une à une.
- Reconnaître ces trois techniques dans les guides officiels des éditeurs.

> 🧭 **En clair** — Trois astuces de bon formateur valent aussi pour l'IA. **Montrer des exemples** : plutôt que d'expliquer pendant dix minutes le ton de vos courriers, on en montre deux ou trois (c'est le *few-shot*). **Faire poser le calcul** : comme à l'école, on demande d'écrire les étapes pour pouvoir vérifier le raisonnement (le *raisonnement pas à pas*). **Découper le travail** : on ne construit pas une maison en un jour, on avance lot par lot en contrôlant chaque étape (la *décomposition*). Ces trois gestes simples transforment une réponse correcte en réponse vraiment fiable.

## 1. Trois leviers au-delà de la structure

La leçon précédente vous a donné la **structure** d'un prompt (R-C-T-F-C). Cette leçon ajoute trois **techniques** qui font la différence entre une réponse correcte et une réponse excellente :

| Technique | Nom anglais | Elle sert à… | Analogie |
|---|---|---|---|
| Les exemples | *few-shot prompting* | imposer un style, un format, une classification | montrer un modèle de lettre à un nouveau collègue |
| Le raisonnement pas à pas | *chain of thought* (CoT) | fiabiliser les calculs, les analyses, les décisions | demander à un stagiaire de « poser » son calcul |
| La décomposition | *prompt chaining*, *task decomposition* | traiter un projet complexe sans perdre le fil | découper un chantier en lots |

Ces trois techniques apparaissent, sous ces noms, dans le guide « Prompting best practices » d'Anthropic (sections « Use examples effectively », « Leverage thinking », « Chain complex prompts ») et dans le cours de référence de DeepLearning.AI « ChatGPT Prompt Engineering for Developers » (leçons « Guidelines » et « Iterative »).

## 2. Les exemples : montrer plutôt qu'expliquer

### 2.1 Zéro, un, plusieurs

- **Zero-shot** (sans exemple) : vous décrivez la tâche, point. Suffisant pour les tâches courantes.
- **One-shot** : un exemple. Déjà très efficace pour un format.
- **Few-shot** : deux à cinq exemples. La référence pour les classifications, les styles de rédaction et les formats de sortie délicats.

Pourquoi ça marche ? Un modèle de langage est une machine à repérer des régularités. Trois exemples bien choisis définissent une régularité plus précisément que n'importe quelle description. Essayez d'expliquer par écrit « le ton de nos newsletters » : vous n'y arriverez pas. Collez-en trois : le modèle l'aura compris.

### 2.2 Les règles d'or des exemples

Le guide Anthropic liste trois qualités : les exemples doivent être **pertinents** (proches du cas réel), **variés** (couvrir les cas limites, pas trois fois la même chose) et **clairement délimités** (encadrés par des balises `<example>` … `</example>` — des étiquettes qui marquent le début et la fin de l'exemple, comme deux serre-livres — ou un titre « Exemple 1 »). Il ajoute un avertissement précieux : les modèles récents suivent les exemples **de très près**, y compris leurs défauts. Un exemple bâclé donne des réponses bâclées ; un exemple avec une faute de frappe peut la reproduire.

> ⚠️ **Piège fréquent** — Donner trois exemples qui disent tous la même chose. Si vous classez des e-mails clients en « urgent / normal / information », montrez un exemple de chaque catégorie, dont un cas ambigu, et expliquez pourquoi il tombe dans telle catégorie.

### 2.3 Avant / après : le tri des demandes clients

**Avant** (zero-shot) : « *Classe ces messages par urgence.* » — Le modèle invente ses propres catégories, parfois cinq niveaux, parfois des couleurs.

**Après** (few-shot) :

```
Classez chaque message client dans UNE catégorie : URGENT, NORMAL ou INFO.
Répondez uniquement par la catégorie.

<exemples>
Message : « Fuite d'eau dans la cuisine, le sol est inondé, venez vite ! »
Catégorie : URGENT

Message : « Bonjour, pouvez-vous me rappeler la date de ma prochaine visite ? »
Catégorie : NORMAL

Message : « Merci pour votre intervention d'hier, tout fonctionne. »
Catégorie : INFO

Message : « Le chauffage marche mais fait un bruit étrange depuis ce matin. »
Catégorie : NORMAL
(Note : pas de danger immédiat ni de panne totale → NORMAL, pas URGENT.)
</exemples>

Message : « Plus d'eau chaude depuis hier soir avec un bébé à la maison. »
Catégorie :
```

Le quatrième exemple est le plus important : c'est le **cas limite commenté**, celui qui apprend au modèle où passe la frontière.

> 💡 **À retenir** — Un exemple vaut mille explications, à condition d'être représentatif, varié et irréprochable. Dès que vous vous surprenez à écrire « quelque chose dans ce genre », remplacez par un vrai exemple.

```quiz
{
  "type": "mise_en_situation",
  "q": "Vous voulez que l'IA classe des messages clients en URGENT, NORMAL ou INFO. Quel est le meilleur jeu d'exemples à lui fournir ?",
  "options": [
    "Un exemple par catégorie, plus un cas ambigu commenté",
    "Trois exemples de messages URGENT, pour qu'elle comprenne bien l'urgence",
    "Aucun exemple : la description suffit toujours",
    "Vingt exemples copiés au hasard dans la boîte mail"
  ],
  "answer": 0,
  "explanation": "Les bons exemples sont pertinents, variés et clairement délimités. Le cas limite commenté est le plus précieux : il apprend au modèle où se situe la frontière entre deux catégories."
}
```

## 3. Le raisonnement pas à pas

### 3.1 L'anecdote de 2022 : « Let's think step by step »

En 2022, des chercheurs ont montré qu'ajouter la simple phrase « *Let's think step by step* » (« réfléchissons étape par étape ») à la fin d'un problème de mathématiques faisait bondir le taux de bonnes réponses des modèles de l'époque. La raison est mécanique : un modèle qui écrit ses étapes intermédiaires « pose son calcul » au lieu de deviner le résultat d'un coup. C'est la **chaîne de raisonnement** (*chain of thought*).

### 3.2 Ce qui a changé en 2026

Les modèles actuels (Claude Sonnet 5.5 et Opus 5.5 avec le *thinking adaptatif*, GPT-6, Grok 4.7, Gemini 4 — nov. 2026) raisonnent **avant de répondre**, dans une phase interne que vous ne voyez pas toujours. La documentation Anthropic précise que ses modèles de la génération 5 utilisent un raisonnement adaptatif : le modèle décide lui-même combien réfléchir selon la difficulté. Conséquence : la formule magique « réfléchis étape par étape » n'est plus indispensable… mais la technique reste utile sous une forme modernisée :

1. **Demander un raisonnement visible** quand vous devez **vérifier** le chemin, pas seulement le résultat : « *Avant de conclure, liste les hypothèses que tu as faites et les données qui te manquent.* »
2. **Imposer des étapes** quand vous voulez une **méthode précise** : « *1) Extrais les montants, 2) vérifie que la somme correspond au total indiqué, 3) signale tout écart.* »
3. **Freiner** le raisonnement quand il est inutile : le guide Anthropic contient une section « Overthinking and excessive thoroughness » : pour une tâche simple, précisez « *Réponse directe, sans préambule ni analyse* ». Vous gagnez du temps et de la lisibilité.

> 🔗 **Documentation officielle** — [Anthropic — Thinking](https://platform.claude.com/docs/en/build-with-claude/thinking) 🇬🇧 explique le raisonnement adaptatif des modèles Claude 5 ; [xAI — Best practices](https://docs.x.ai/developers/model-capabilities/text/best-practices) 🇬🇧 donne l'équivalent pour Grok.

### 3.3 Avant / après : la vérification d'un devis

**Avant** : « *Ce devis est-il correct ?* » (devis collé). Réponse : « Oui, le devis semble cohérent. » — Inutilisable : on ne sait pas ce qui a été vérifié.

**Après** :

```
Vérifiez ce devis en suivant exactement ces étapes et en montrant chacune :
1. Recalculez le total HT à partir des lignes.
2. Vérifiez que la TVA appliquée est bien 20 % sur chaque ligne (sauf mention).
3. Comparez avec le total TTC indiqué.
4. Concluez : CONFORME ou ÉCART (avec le montant de l'écart).
Si une information manque pour conclure, dites-le au lieu de supposer.

<devis>
…
</devis>
```

Vous obtenez une démarche que vous pouvez **relire et contester**, ce qui est tout l'intérêt.

> 💡 **Autrement dit** — Les modèles de 2026 « réfléchissent » déjà un peu en silence avant de répondre. Demander les étapes ne sert donc plus tant à les rendre intelligents qu'à **vous permettre de vérifier** leur chemin, comme un professeur qui veut voir le brouillon et pas seulement le résultat. Et pour une question toute simple, dites-lui au contraire d'aller droit au but.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : avec les modèles de 2026, il faut ajouter « réfléchis étape par étape » à toutes vos demandes, même les plus simples.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Les modèles actuels raisonnent déjà en interne. On demande des étapes visibles quand on veut vérifier la démarche (un devis, une analyse) ; pour une tâche simple, on demande au contraire une réponse directe, sans préambule."
}
```

## 4. La décomposition : une chaîne de prompts

### 4.1 Pourquoi découper

Demander en une fois « *Rédige mon dossier de réponse à cet appel d'offres* » revient à demander à un architecte de construire la maison en une journée. Le résultat sera superficiel. La section « Chain complex prompts » du guide Anthropic recommande de découper en sous-tâches dont **chacune produit une sortie claire qui alimente la suivante**. Avantages :

- vous **contrôlez** chaque étape avant de passer à la suivante ;
- une erreur en étape 2 ne contamine pas l'étape 5 ;
- chaque prompt est court, donc plus précis ;
- vous pouvez réutiliser les étapes (c'est le début de l'automatisation, module 6).

### 4.2 Le schéma type

```
Étape 1 ─ Analyser      « Liste les 10 exigences du cahier des charges. »
    │
Étape 2 ─ Confronter    « Pour chaque exigence, indique si notre offre y répond
    │                      (oui / partiellement / non) d'après notre fiche. »
Étape 3 ─ Rédiger       « Rédige la section “Compréhension du besoin” à partir
    │                      du tableau validé. »
Étape 4 ─ Critiquer     « Relis la section comme un acheteur public exigeant ;
    │                      liste 5 faiblesses. »
Étape 5 ─ Corriger      « Réécris en corrigeant ces 5 points. »
```

Notez l'étape 4 : faire **critiquer par le modèle sa propre production**, avec un rôle différent (l'acheteur, le client, l'auditeur), est l'une des techniques les plus rentables qui existent. Le cours DeepLearning.AI l'appelle « vérifier les sorties » ; la pratique courante parle de *self-critique* ou de boucle *generator-evaluator* (l'un rédige, l'autre évalue, comme un auteur et son relecteur).

### 4.3 Avant / après : l'étude de marché express

**Avant** : « *Fais une étude de marché pour une boulangerie bio à Rennes.* » — Dix paragraphes généraux, chiffres non sourcés, zéro décision possible.

**Après** (chaîne) :
1. « *Liste les 8 questions auxquelles une étude de marché pour une boulangerie bio à Rennes doit répondre. Ne réponds pas encore.* »
2. « *Pour les questions 1 à 4, indique quelles sources officielles françaises je devrais consulter (INSEE, CCI, mairie…). Ne donne aucun chiffre.* »
3. (vous allez chercher les chiffres, puis) « *Voici les données collectées : … Analyse-les question par question.* »
4. « *Rédige une synthèse d'une page pour un banquier, à partir de l'analyse validée ci-dessus.* »

Vous avez remplacé une hallucination élégante par un travail documenté, où **les chiffres viennent de vous**.

> 💡 **À retenir** — Les trois techniques se combinent : une chaîne de prompts dont chaque maillon contient des exemples et demande une vérification explicite. C'est exactement ainsi que sont construits les assistants et agents professionnels que vous verrez au niveau 2.

```quiz
{
  "q": "Dans une chaîne de prompts pour un appel d'offres, à quoi sert l'étape « Relis la section comme un acheteur public exigeant et liste 5 faiblesses » ?",
  "options": [
    "À allonger le texte pour atteindre le nombre de pages",
    "À faire critiquer le texte par le modèle avant de le corriger",
    "À traduire le texte en anglais pour un acheteur étranger",
    "À vérifier uniquement l'orthographe et la ponctuation"
  ],
  "answer": 1,
  "explanation": "C'est l'auto-critique (self-critique) : on change de rôle pour relire le travail avec les yeux du destinataire, puis on corrige. C'est l'une des techniques les plus rentables."
}
```

## 5. 🎮 Défi : quelle technique ?

Associez chaque besoin à la technique la plus adaptée (exemples / raisonnement / décomposition) :

- a) « Je veux que les réponses à mes avis Google aient toujours notre ton maison. »
- b) « Je dois vérifier que les 30 notes de frais respectent notre politique. »
- c) « Je dois produire un manuel utilisateur de 40 pages. »
- d) « Je veux extraire nom / date / montant de 200 factures dans un format fixe. »

Réponses en fin de leçon.

```mission
{
  "title": "Combien d'exemples conseille Anthropic ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices",
  "steps": ["Ouvrez la page « Prompting best practices »", "Allez à la section « Use examples effectively » (utilisez Ctrl+F ou Cmd+F)", "Repérez le nombre d'exemples recommandé et la balise conseillée pour les encadrer"],
  "question": "Combien d'exemples le guide recommande-t-il d'inclure pour de meilleurs résultats, et dans quelle balise conseille-t-il de les placer ?",
  "hint": "La balise est citée dans la section 2.2 de cette leçon ; le nombre est une petite fourchette.",
  "answer": "3 à 5 exemples pertinents et variés, encadrés par des balises <example> (ou <examples> pour plusieurs) — page consultée en nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Le cours de prompt engineering d'Andrew Ng",
  "url": "https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/",
  "steps": ["Ouvrez la page du cours « ChatGPT Prompt Engineering for Developers » sur DeepLearning.AI", "Repérez les noms des formateurs", "Notez la durée et la liste des leçons"],
  "question": "Qui anime ce cours gratuit, combien de temps dure-t-il, et quelle leçon correspond à l'idée d'améliorer un prompt par essais successifs ?",
  "hint": "Deux formateurs, dont une ingénieure d'OpenAI ; la leçon cherchée porte un nom proche de « itératif ».",
  "answer": "Isa Fulford et Andrew Ng ; environ 1 h 40 ; la leçon « Iterative » (prompt development) — état au 1er nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Prenez une tâche de classification de votre quotidien (tri de courriels, catégorisation de tickets, qualification de prospects, étiquetage de dépenses). Rédigez un prompt few-shot avec **quatre exemples** dont un cas limite commenté, puis testez-le sur cinq messages réels (anonymisés). Ensuite, ajoutez une consigne de raisonnement : « *Avant de donner la catégorie, cite en une phrase l'indice qui t'a décidé.* » Comparez.

**Concrètement :** « classer » veut dire ranger chaque message dans une case. Choisissez trois catégories au maximum (par exemple URGENT / NORMAL / INFO) et partez du modèle de la section 2.3 en remplaçant les exemples par les vôtres. Pour les cinq messages de test, remplacez noms, téléphones et adresses par « client A », « 06 XX » ; si vous n'avez pas de vrais messages, inventez-en cinq réalistes. Faites deux essais dans deux nouvelles conversations : sans puis avec la consigne de justification.

**Critères de réussite.**
- Les quatre exemples couvrent toutes les catégories et au moins un cas ambigu.
- Le format de sortie demandé est respecté sur les cinq messages.
- Le prompt avec justification permet de repérer au moins une classification discutable.
- Vous savez dire si la justification a amélioré ou dégradé la lisibilité, et pourquoi.

**Pistes de corrigé.** Un bon prompt délimite les exemples par des balises, impose « *une seule catégorie, en majuscules* », et traite explicitement le cas « *si le message relève de deux catégories, choisis la plus urgente* ». Pour la version avec justification, un format fixe (« *Indice : … / Catégorie : …* ») évite les paragraphes inutiles.

## ✅ Auto-évaluation express

1. **Combien d'exemples pour un prompt few-shot efficace ?**
   → Généralement deux à cinq, pertinents, variés, bien délimités ; la qualité compte plus que le nombre.
2. **Pourquoi « réfléchis étape par étape » est-il moins indispensable avec les modèles de 2026 ?**
   → Parce qu'ils disposent d'un raisonnement interne (thinking adaptatif chez Claude 5, modèles de raisonnement chez OpenAI et xAI) ; la technique reste utile pour rendre le raisonnement **visible et vérifiable**.
3. **Quel est le principal avantage d'une chaîne de prompts ?**
   → Contrôler chaque étape et empêcher qu'une erreur précoce contamine tout le livrable.

**Réponses du défi.** a) exemples ; b) raisonnement pas à pas (étapes de vérification explicites) ; c) décomposition (plan → chapitres → relecture) ; d) exemples (format fixe) — avec, au niveau 3, les sorties structurées JSON (un format de fiche lisible par les logiciels, vu en L017).

> ✅ **Si vous ne retenez que 3 choses** — 1. Montrez plutôt qu'expliquer : deux à cinq exemples variés, dont un cas limite commenté, valent mieux qu'une longue description. 2. Demandez les étapes du raisonnement quand vous devez vérifier le chemin (un calcul, un contrôle) ; pour une question simple, demandez au contraire une réponse directe. 3. Découpez un gros travail en étapes que vous contrôlez une à une, et faites critiquer le résultat par l'IA dans un autre rôle (client, acheteur, auditeur).

## 📚 Pour aller plus loin
- [Anthropic — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 — sections « Use examples effectively », « Leverage thinking and interleaved thinking », « Chain complex prompts ».
- [DeepLearning.AI — ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) 🇬🇧 — cours gratuit d'1 h 40 (Isa Fulford, Andrew Ng) : principes, itération, résumé, inférence, transformation.
- [Microsoft — Generative AI for Beginners](https://github.com/microsoft/generative-ai-for-beginners) 🇬🇧 — chapitres 04 « Prompt Engineering Fundamentals » et 05 « Advanced Prompts » (licence MIT).

> 🗺️ **Et maintenant ?** — Vous maîtrisez les grandes techniques ; la leçon L017 vous emmène dans les guides officiels d'Anthropic et d'OpenAI pour découvrir les balises, le prompt système et les réglages propres à chaque éditeur.
