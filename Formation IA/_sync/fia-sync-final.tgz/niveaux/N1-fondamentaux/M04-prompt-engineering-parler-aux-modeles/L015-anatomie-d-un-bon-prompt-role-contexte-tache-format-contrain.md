---
id: L015
module: M04
level: N1
title: "Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes"
minutes: 45
objectives:
  - "Identifier les cinq composants d'un prompt structuré (rôle, contexte, tâche, format, contraintes)"
  - "Transformer une demande vague en prompt complet et exploitable"
  - "Expliquer pourquoi le contexte et la clarté améliorent la qualité des réponses"
skills: ["C1.3"]
sources:
  - { title: "Anthropic — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "Anthropic — Prompt engineering overview", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview", lang: "en" }
  - { title: "OpenAI — Text generation and prompting", url: "https://developers.openai.com/api/docs/guides/text", lang: "en" }
  - { title: "Claude Academy — AI Fluency: Framework and foundations", url: "https://academy.claude.com/courses/ai-fluency-framework-foundations", lang: "en" }
---

# Anatomie d'un bon prompt : rôle, contexte, tâche, format, contraintes

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 4

## 🎯 Ce que vous saurez faire
- Reconnaître les cinq briques d'un prompt efficace et les assembler dans le bon ordre.
- Réécrire une demande floue (« fais-moi un mail ») en consigne précise qui produit un résultat utilisable du premier coup.
- Diagnostiquer, dans un prompt qui « ne marche pas », quelle brique manque.
- Expliquer à un collègue pourquoi un modèle de langage a besoin de contexte, exactement comme un nouveau collaborateur.

> 🧭 **En clair** — Parler à une IA, c'est comme passer commande chez un traiteur au téléphone. Si vous dites seulement « un repas pour samedi », vous recevrez quelque chose de très moyen. Si vous précisez **qui vous êtes**, **pour quelle occasion**, **ce que vous voulez exactement**, **pour combien de personnes et sous quelle forme**, et **ce qu'il ne faut surtout pas** (allergies !), vous obtenez exactement ce qu'il vous faut. Un bon prompt suit cette même logique en cinq briques : Rôle, Contexte, Tâche, Format, Contraintes — R-C-T-F-C. Quand une réponse déçoit, c'est presque toujours qu'une brique manque.

## 1. Le prompt, c'est un brief

Un **prompt** (consigne, invite) est tout ce que vous écrivez à un modèle de langage avant qu'il réponde. Rien de magique : c'est un brief, comme celui que vous donneriez à un stagiaire brillant, très cultivé, qui vient d'arriver ce matin dans votre entreprise… et qui ne connaît ni vos clients, ni vos habitudes, ni ce que vous avez en tête.

Le guide officiel d'Anthropic résume l'idée en une phrase que nous vous invitons à encadrer : « *Pensez à Claude comme à un employé brillant mais tout nouveau (et amnésique) qui a besoin d'instructions explicites* ». La règle d'or qui en découle : **montrez votre prompt à un collègue qui n'a aucun contexte. S'il est perdu, le modèle le sera aussi.**

> 💡 **À retenir** — Le modèle ne lit pas dans vos pensées. Tout ce qui n'est pas écrit dans le prompt (ou dans les documents joints) n'existe pas pour lui. Un prompt vague produit une réponse « moyenne », celle qui conviendrait à n'importe qui, donc à personne.

### 1.1 Pourquoi un prompt vague donne une réponse vague

Un grand modèle de langage prédit la suite la plus probable d'un texte (vous l'avez vu au module 2). Si vous écrivez « *Rédige une annonce pour un poste de comptable* », le modèle génère l'annonce la plus **statistiquement banale** : un texte générique, en anglais parfois, sans votre convention collective, sans votre ville, sans votre ton. Ce n'est pas une erreur du modèle : c'est la réponse la plus plausible à une question sous-spécifiée (pas assez précise).

Chaque élément de contexte que vous ajoutez **réduit l'espace des réponses possibles** et rapproche la sortie de ce que vous vouliez vraiment. C'est tout le travail du prompt engineering (ingénierie de prompt) : ne rien laisser au hasard.

```quiz
{
  "q": "Vous écrivez « Rédige une annonce pour un poste de comptable » et obtenez un texte banal et générique. Pourquoi ?",
  "options": [
    "Le modèle est en panne ou de mauvaise qualité",
    "Les annonces d'emploi sont interdites aux IA",
    "Faute de contexte, il produit la réponse la plus « moyenne »",
    "Il fallait écrire la demande en anglais, langue native du modèle"
  ],
  "answer": 2,
  "explanation": "Le modèle prédit la suite la plus probable. Sans contexte (entreprise, ville, convention collective, ton), la réponse la plus probable est la plus banale. Chaque précision réduit l'éventail des réponses possibles."
}
```

## 2. Les cinq briques : R-C-T-F-C

Mémorisez ce moyen mnémotechnique : **R-C-T-F-C** — Rôle, Contexte, Tâche, Format, Contraintes. Un prompt complet les contient toutes, pas forcément dans cet ordre, pas forcément avec des titres. Mais si l'une manque, la réponse s'en ressent.

```
┌──────────────────────────────────────────────────────┐
│  R  Rôle        « Tu es … »  qui parle ? à qui ?       │
│  C  Contexte    situation, public, données, enjeux    │
│  T  Tâche       le verbe d'action + l'objet précis     │
│  F  Format      longueur, structure, langue, ton       │
│  C  Contraintes interdits, obligations, critères      │
└──────────────────────────────────────────────────────┘
```

### 2.1 Rôle — qui parle ?

Attribuer un rôle (« *Vous êtes un juriste spécialisé en droit du travail français* ») oriente le vocabulaire, le niveau de détail et les réflexes du modèle. Le guide Anthropic consacre une section entière à ce sujet (« Give Claude a role ») : le rôle est le plus efficace quand il est **précis** et qu'il décrit l'**expertise attendue**, plus que quand il se contente d'un titre ronflant.

| Rôle faible | Rôle utile |
|---|---|
| « Tu es un expert. » | « Vous êtes responsable RH d'une PME industrielle de 80 salariés, habitué à rédiger des annonces conformes au Code du travail. » |
| « Agis comme un marketeur. » | « Vous êtes chargé de communication d'un cabinet d'expertise comptable qui s'adresse à des artisans et commerçants ; ton rassurant, jamais jargonneux. » |

> ⚠️ **Piège fréquent** — Le rôle ne crée pas de compétence que le modèle n'a pas. Dire « tu es le meilleur avocat du monde » ne rend pas les réponses juridiquement sûres. Le rôle **cadre**, il ne **garantit** rien : la vérification (module 5) reste indispensable.

### 2.2 Contexte — dans quelle situation ?

C'est la brique le plus souvent oubliée, et la plus rentable. Le contexte répond aux questions : pour qui ? pourquoi ? avec quelles données ? quel est l'enjeu ? La section « Add context to improve performance » du guide Anthropic recommande même d'expliquer **la raison** d'une consigne : un modèle qui comprend *pourquoi* vous voulez des phrases courtes (« car le texte sera lu sur mobile par des livreurs pressés ») généralise mieux qu'un modèle à qui l'on impose une règle sèche.

Exemples de contexte utile :
- le public cible (« clients particuliers qui ne connaissent pas le vocabulaire bancaire ») ;
- l'objectif final (« obtenir un rendez-vous téléphonique ») ;
- les données brutes (le texte à résumer, les chiffres, l'historique d'échanges) ;
- ce qui a déjà été essayé et n'a pas convenu.

### 2.3 Tâche — quel verbe, quel objet ?

La tâche commence par un **verbe d'action** précis : *rédiger, résumer, comparer, extraire, classer, traduire, reformuler, proposer trois variantes*… et un objet clairement délimité. « Aide-moi avec ce document » n'est pas une tâche ; « Résume ce compte rendu en cinq points d'action, chacun avec un responsable et une échéance » en est une.

Astuce : si la tâche est longue, **numérotez les étapes**. Les guides Anthropic et OpenAI recommandent tous deux les listes numérotées ou à puces pour les instructions séquentielles — le modèle les suit alors dans l'ordre.

### 2.4 Format — à quoi doit ressembler la réponse ?

Longueur (« 120 mots maximum »), structure (« un tableau à trois colonnes »), langue (« en français, vouvoiement »), ton (« chaleureux mais professionnel »), support (« prêt à coller dans un e-mail »). Le guide Anthropic insiste sur un point contre-intuitif : **dites ce que vous voulez, pas ce que vous ne voulez pas**. « *Réponds en paragraphes fluides* » fonctionne mieux que « *Pas de listes à puces* ».

### 2.5 Contraintes — les lignes rouges

Obligations et interdits : « *Ne mentionne aucun prix* », « *Cite uniquement les informations présentes dans le document fourni ; si une information manque, écris « non précisé »* », « *Respecte la RGPD : aucune donnée personnelle inventée* ». Les contraintes transforment une réponse plausible en réponse **conforme**.

> 🔗 **Documentation officielle** — [Anthropic — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 : les sections « Be clear and direct », « Add context to improve performance » et « Give Claude a role » sont la source directe de cette leçon.

> 💡 **Autrement dit** — Les cinq briques répondent à cinq questions qu'on se pose naturellement avant de confier un travail à quelqu'un : **Qui** est censé parler ? (rôle) **Dans quelle situation** ? (contexte) **Que faut-il faire** exactement ? (tâche) **À quoi doit ressembler** le résultat ? (format) **Qu'est-ce qui est interdit ou obligatoire** ? (contraintes)

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour obtenir un texte sans jargon, il vaut mieux écrire « explique avec des mots du quotidien » que « pas de jargon ».",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. Le guide d'Anthropic recommande de dire ce que l'on veut plutôt que ce que l'on ne veut pas : une consigne positive guide mieux le modèle qu'un interdit."
}
```

## 3. Avant / après : la transformation en direct

### Exemple 1 — L'artisan plombier

**Avant** : « *Écris un message pour relancer un client qui n'a pas payé.* »

Résultat typique : un texte anglo-saxon traduit, froid, qui parle de « facture en souffrance » et menace de poursuites dès la première relance. Inutilisable.

**Après** :

```
Vous êtes la gérante d'une entreprise de plomberie de 4 personnes à Nantes.
Contexte : la facture n° 2026-118 (680 € TTC, remplacement d'un chauffe-eau)
est due depuis 15 jours. C'est un bon client, c'est la première relance.
Tâche : rédigez un SMS de relance, puis un e-mail plus complet.
Format : SMS de 300 caractères maximum ; e-mail de 120 mots maximum,
vouvoiement, ton cordial et sans reproche, qui propose un paiement par virement
ou par lien de paiement.
Contraintes : ne mentionnez ni pénalités ni poursuites ; rappelez le numéro de
facture et le montant ; terminez par une formule de politesse chaleureuse.
```

Les cinq briques sont là. Le résultat est prêt à envoyer, et surtout **il vous ressemble**.

### Exemple 2 — Le cabinet comptable

**Avant** : « *Explique la TVA à un client.* »

**Après** :

```
Rôle : vous êtes collaborateur d'un cabinet d'expertise comptable.
Contexte : votre client est un micro-entrepreneur (vente de bijoux artisanaux
en ligne) qui vient de dépasser le seuil de franchise en base de TVA et panique.
Tâche : expliquez-lui, en termes simples, ce qui change concrètement pour lui
(facturation, déclaration, prix de vente).
Format : e-mail de 200 mots maximum, 3 paragraphes courts, vouvoiement, une
analogie du quotidien pour la TVA collectée / déductible.
Contraintes : ne donnez aucun montant de seuil (ils seront vérifiés par le
cabinet) ; invitez-le à prendre rendez-vous ; ne promettez rien sur le calendrier.
```

Remarquez la contrainte « *ne donnez aucun montant de seuil* » : c'est vous qui décidez ce que le modèle a le droit d'affirmer. C'est une protection contre les hallucinations sur des chiffres qui changent chaque année.

```quiz
{
  "type": "trouve_erreur",
  "q": "Voici un prompt : « Vous êtes gérante d'une plomberie à Nantes. Rédigez une relance pour la facture n° 2026-118 de 680 €, en SMS de 300 caractères maximum. » Quelle brique manque le plus ?",
  "options": [
    "Le rôle (qui parle, en quelle qualité)",
    "La tâche (que faire, sur quelle facture)",
    "Le format (SMS, 300 caractères)",
    "Les contraintes (ton, interdits)"
  ],
  "answer": 3,
  "explanation": "Rôle, tâche et format sont présents, et le contexte est partiel. Il manque surtout les contraintes : sans elles, le modèle peut adopter un ton menaçant ou évoquer des pénalités dès la première relance."
}
```

## 4. Ordre, longueur et mise en page : trois questions pratiques

**Dans quel ordre ?** Pour une demande courte, l'ordre R-C-T-F-C est naturel. Pour une demande qui s'appuie sur un **long document** (contrat, rapport, transcription), le guide Anthropic recommande de placer les données **en haut** du prompt et la question **à la fin** : les tests internes d'Anthropic montrent une amélioration sensible de la qualité des réponses sur les longs contextes avec cette disposition.

**Quelle longueur ?** Un bon prompt est aussi long que nécessaire, pas plus. Dix lignes bien pensées valent mieux qu'une page de bavardage. Mais n'ayez pas peur d'être long quand la tâche est complexe : les modèles actuels (Claude Sonnet 5.5, GPT-6, Gemini 4, Mistral Large 4 — nov. 2026) acceptent des centaines de pages de contexte.

**Comment séparer les parties ?** Utilisez des titres, des lignes vides, ou des balises comme `<document>` … `</document>` (des étiquettes d'ouverture et de fermeture qui encadrent un texte, comme les deux rabats d'une pochette). Vous verrez cela en détail à la leçon 17 ; retenez déjà que **séparer visiblement les données des instructions** évite au modèle de confondre « ce qu'il doit faire » et « ce sur quoi il doit le faire ».

> 💡 **À retenir** — Un prompt qui échoue est presque toujours un prompt auquel il manque une brique. Avant d'accuser le modèle, relisez : rôle ? contexte ? tâche précise ? format ? contraintes ?

```mission
{
  "title": "La « règle d'or » du guide de prompt d'Anthropic",
  "url": "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices",
  "steps": ["Ouvrez la page « Prompting best practices » de la documentation Claude", "Repérez la section « Be clear and direct »", "Lisez la comparaison avec un nouvel employé et la « golden rule » qui suit"],
  "question": "À quel type de personne le guide compare-t-il Claude, et quelle règle d'or propose-t-il pour tester la clarté d'un prompt ?",
  "hint": "La section 1 de cette leçon en donne une traduction ; cherchez dans la page les mots « brilliant » et « golden rule ».",
  "answer": "À un employé brillant mais tout nouveau (sans contexte sur vos habitudes) ; règle d'or : montrer son prompt à un collègue qui n'a pas le contexte — s'il est perdu, Claude le sera aussi (page consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Que faut-il préparer AVANT d'écrire un prompt ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview",
  "steps": ["Ouvrez la page « Prompt engineering overview » de la documentation Claude", "Repérez le paragraphe des prérequis (« Before prompt engineering »)", "Notez les éléments qu'Anthropic recommande d'avoir en main avant de commencer"],
  "question": "Selon Anthropic, de quoi faut-il disposer avant de se lancer dans l'amélioration d'un prompt ?",
  "hint": "Il est question de « success criteria » et de façons de « tester ».",
  "answer": "D'une définition claire des critères de réussite, de moyens de tester le prompt par rapport à ces critères, et d'un premier brouillon de prompt à améliorer (état de la page en nov. 2026).",
  "xp": 10
}
```

## 5. 🎮 Défi : le détecteur de briques manquantes

Pour chacun de ces prompts réels (anonymisés), trouvez la ou les briques absentes :

1. « *Résume ce rapport.* » (rapport de 40 pages joint)
2. « *Tu es un chef cuisinier. Donne-moi une recette.* »
3. « *Rédige une annonce LinkedIn pour notre nouveau service de nettoyage de panneaux solaires, 150 mots, ton dynamique.* »
4. « *Traduis ce contrat en anglais.* »

Réponses en fin de leçon (section Auto-évaluation).

## 🧪 Exercice pratique

**Consigne.** Choisissez une tâche réelle de votre métier que vous aimeriez confier à un assistant IA (rédiger une fiche produit, préparer un ordre du jour, répondre à un avis client, expliquer une procédure…). Rédigez un prompt complet selon la grille R-C-T-F-C, soumettez-le à l'assistant de votre choix (Claude, ChatGPT, Le Chat, Gemini…), puis comparez avec la réponse obtenue à partir d'une version « vague » en une phrase.

**Concrètement :** écrivez votre prompt dans un document en mettant chaque brique sur sa propre ligne, précédée de son nom (« Rôle : … », « Contexte : … »), comme dans les exemples de la section 3 : c'est cela que « surligner les briques » veut dire. Ouvrez ensuite deux nouvelles conversations : l'une avec la version vague en une phrase, l'autre avec la version complète, et copiez les deux réponses côte à côte pour les comparer. Remplacez tout nom réel de client ou de collègue par « client A », « collègue B ».

**Critères de réussite.**
- Les cinq briques sont identifiables dans votre prompt (surlignez-les).
- Le format demandé est respecté par la réponse (longueur, langue, structure).
- Au moins une contrainte protège contre une erreur probable (chiffre inventé, promesse, donnée personnelle).
- Vous êtes capable d'expliquer en deux phrases la différence de qualité entre la version vague et la version structurée.

**Corrigé type (avis client).**

```
Rôle : vous êtes gérant d'un restaurant familial à Lyon.
Contexte : un client a laissé un avis 2/5 en ligne : « Plats bons mais 45 min
d'attente un samedi soir, personne ne nous a prévenus. » C'était un soir où un
serveur était absent.
Tâche : rédigez une réponse publique à cet avis.
Format : 80 mots maximum, vouvoiement, ton sincère, pas de formule toute faite.
Contraintes : reconnaissez le problème sans vous justifier longuement ;
n'offrez pas de remise publique ; invitez le client à revenir ; ne mentionnez
pas l'absence du serveur (vie privée).
```

Une réponse réussie reconnaît l'attente, remercie pour le compliment sur les plats, explique sobrement qu'une mesure a été prise, invite à revenir — et tient en 80 mots.

## ✅ Auto-évaluation express

1. **Quelle brique protège le plus efficacement contre un chiffre inventé par le modèle ?**
   → Les *contraintes* (« utilise uniquement les données fournies ; sinon écris “non précisé” »).
2. **Faut-il plutôt écrire « pas de jargon » ou « explique avec des mots du quotidien » ?**
   → La seconde formulation : les guides recommandent de dire ce que l'on veut plutôt que ce que l'on ne veut pas.
3. **Où placer un long document dans le prompt ?**
   → En haut, avec la question à la fin, selon les recommandations d'Anthropic pour les longs contextes.

**Réponses du défi.** 1 : tout manque sauf la tâche (pour qui ? quelle longueur ? quels points ?). 2 : contexte, format, contraintes (combien de convives, allergies, temps, budget ?). 3 : contexte manquant (qui est la cible ? quel bénéfice ? zone géographique ?) et contraintes (prix ? mentions légales ?). 4 : rôle et contraintes (anglais britannique ou américain ? glossaire imposé ? clauses à ne pas interpréter ?).

> ✅ **Si vous ne retenez que 3 choses** — 1. Un prompt, c'est un brief donné à un collaborateur brillant mais tout nouveau et sans mémoire : tout ce qui n'est pas écrit n'existe pas pour lui. 2. Les cinq briques R-C-T-F-C : Rôle, Contexte, Tâche, Format, Contraintes. Quand une réponse déçoit, cherchez la brique manquante. 3. Dites ce que vous voulez plutôt que ce que vous ne voulez pas ; avec un long document, mettez-le en haut et la question à la fin.

## 📚 Pour aller plus loin
- [Anthropic — Prompt engineering overview](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview) 🇬🇧 — quand faire du prompt engineering, et les prérequis (critères de succès, tests).
- [OpenAI — Text generation and prompting](https://developers.openai.com/api/docs/guides/text) 🇬🇧 — le guide OpenAI pour la génération de texte et la rédaction d'instructions.
- [Claude Academy — AI Fluency: Framework and foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations) 🇬🇧 — cours gratuit avec badge ; la compétence « Description » correspond exactement à cette leçon.
- [Mistral AI — Prompting](https://docs.mistral.ai/inference/prompting) 🇬🇧 — la page de bonnes pratiques de l'éditeur français.

> 🗺️ **Et maintenant ?** — Vous savez construire un prompt complet ; la leçon L016 ajoute les techniques qui font la différence : donner des exemples, faire raisonner pas à pas et découper une tâche complexe.
