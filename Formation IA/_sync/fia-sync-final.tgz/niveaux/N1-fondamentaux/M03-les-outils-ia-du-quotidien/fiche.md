---
module: M03
title: "Fiche mémo — Les outils IA du quotidien"
---
# Fiche mémo — M03 · Les outils IA du quotidien

> En une phrase : chaque assistant a son terrain (ChatGPT polyvalent, Claude dossiers épais, Gemini et Copilot dans vos suites bureautiques, Grok actualité X, Le Chat souveraineté, Perplexity sources) ; on choisit par l'usage, pas par le classement.

## Les 7 idées à retenir
1. **L'application n'est pas le moteur** : ChatGPT est le tableau de bord, GPT-6 le moteur, changé régulièrement (`L010`).
2. **Sans recherche web, pas de présent** : l'assistant répond avec ses connaissances arrêtées à sa date de coupure, avec assurance (`L010`).
3. **Confidentialité avant de taper** : désactiver l'amélioration du modèle, anonymiser (« le client A »), règle de la carte postale (`L010`).
4. **Chez Claude, 4 briques** : projet (l'établi), artefact (l'objet fabriqué), skill (la fiche technique au mur), connecteur (la rallonge vers vos outils) (`L011`).
5. **Choisir en 3 questions** : où sont mes documents ? Mes données peuvent-elles sortir ? Ai-je besoin du temps réel ? (`L012`)
6. **Sourcé ≠ vrai, sourcé = vérifiable** : ce qui protège, c'est d'ouvrir la source (`L013`).
7. **Générer est facile, diffuser engage** : mention d'origine + consentement + conditions d'utilisation (`L014`).

## Le schéma à connaître

```mermaid
flowchart TD
  A["Mon besoin"] --> B{"Où sont mes documents ?"}
  B -- "Google Workspace" --> G["Gemini"]
  B -- "Microsoft 365" --> M["Microsoft 365 Copilot"]
  B -- "Nulle part en particulier" --> C{"Mes données peuvent-elles sortir ?"}
  C -- "Non" --> L["Le Chat / modèle ouvert hébergé<br/>ou offre Entreprise"]
  C -- "Oui, anonymisées" --> T{"Besoin du temps réel ?"}
  T -- "Oui" --> P["Perplexity, Grok, Gemini"]
  T -- "Non" --> Q["ChatGPT, Claude, Le Chat"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Projet | Un classeur avec consignes et documents que l'assistant relit à chaque conversation |
| Artefact | Le livrable fini dans un volet à part (tableau, page, schéma) |
| Claude Cowork / Claude Code | Déléguer une tâche sur vos fichiers / faire produire du code, avec votre feu vert |
| Tenant | « L'appartement » numérique de l'entreprise chez Microsoft, avec ses serrures |
| Moteur de réponse | Le journaliste : il lit les pages, résume et met une note après chaque phrase |
| Poids ouverts | Le fichier du modèle se télécharge : rien ne quitte votre machine |
| Modèle de diffusion | Le sculpteur qui part d'une « neige » de pixels et la façonne selon votre texte |
| STT / TTS | La sténographe (audio → texte) / le lecteur à voix haute (texte → audio) |

## Les pièges classiques
- Poser une question d'actualité sans activer la recherche web.
- Confondre Copilot grand public (dans la rue) et Microsoft 365 Copilot (dans votre tenant).
- Coller un document de 80 pages et poser dix questions dans la même conversation : créez un projet.
- Accepter toutes les permissions de Claude Code « pour aller plus vite » : travaillez dans un dossier de test.
- Faire confiance au numéro de note sans regarder le domaine (forum, page sponsorisée…).
- Demander du texte dans une image : demandez « sans texte » et ajoutez vos mots à la mise en page.

## Les commandes / chiffres / dates utiles
- **Contrôle en 120 secondes, mnémo « RODAC »** : **R**epérer les chiffres et dates · **O**uvrir chaque source · **D**ater la source · évaluer l'**A**utorité · **C**roiser (et signaler « à confirmer »).
- Claude Code : `claude` dans un terminal ; boucle *explorer → planifier → coder → valider* ; mémoire permanente dans `CLAUDE.md`.
- Gammes API (nov. 2026, $/M tokens) : Claude Haiku 5.5 0,10/0,50 → Fable 5.1 10/50 ; GPT-6 Luna 0,10/0,50 → Astra 10/50 ; Gemini 3.8 Flash 0,75/3,75 ; Mistral Small 4 0,15/0,60 ; grok-4.7 2/6. Écart de 1 à 100.
- Contexte : Claude 1 M · GPT-6 ≈ 1,05 M · Gemini 1 M · Grok 4.7 500 k.
- Transcrire une heure de réunion : moins de 30 centimes (gpt-transcribe 0,0045 $/min, Voxtral 0,0035 $/min).
- AI-900 retiré le 30 juin 2026, remplacé par AI-901. Certifications Anthropic : réservées au Claude Partner Network ; badges Claude Academy gratuits pour tous.
- Diffusion : AI Act art. 50 (transparence) depuis le 2 août 2026 ; deepfake sans consentement diffusé sur un réseau social jusqu'à 2 ans et 45 000 € (art. 226-8 du code pénal).

## Pour aller plus loin
- [Claude 101](https://academy.claude.com/courses/claude-101)
- [OpenAI Academy — catalogue des cours](https://academy.openai.com/pages/courses)
- [Gemini API — Models](https://ai.google.dev/gemini-api/docs/models)

## Auto-test (3 questions — réponses en bas de fiche)
1. Quel modèle Claude choisir pour trier 5 000 e-mails en catégories ?
2. Quel assistant privilégier pour analyser la vidéo d'une réunion stockée dans Google Drive ?
3. Une image générée par une machine seule est-elle protégée par le droit d'auteur français ?

---
**Réponses** — 1. Claude Haiku 5.5 : tâche simple et répétitive, le plus rapide et le moins cher. 2. Gemini : multimodal (vidéo, audio) et intégré à Drive. 3. Non : il faut une intervention créative humaine (article L111-1 du CPI) ; documentez votre apport.
