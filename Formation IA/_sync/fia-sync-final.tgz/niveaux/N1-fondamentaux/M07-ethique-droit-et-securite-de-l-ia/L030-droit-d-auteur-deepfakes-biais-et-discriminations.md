---
id: L030
module: M07
level: N1
title: "Droit d'auteur, deepfakes, biais et discriminations"
minutes: 40
objectives:
  - "Expliquer qui est titulaire des droits sur un contenu généré par IA et à quelles conditions il est protégeable"
  - "Identifier les usages de deepfakes interdits par le code pénal français et les obligations de transparence associées"
  - "Détecter un biais discriminatoire dans une production IA et appliquer une procédure de contrôle"
skills: ["C1.6"]
sources:
  - { title: "donneespersonnelles.fr — Droit d'auteur et IA générative (état sept. 2026)", url: "https://www.donneespersonnelles.fr/droit-auteur-ia-generative", lang: "fr" }
  - { title: "Seban & Associés — IA et exception de fouille de textes et de données : LAION c. Kneschke", url: "https://www.seban-associes.avocat.fr/intelligence-artificielle-et-exception-de-fouille-de-textes-et-de-donnees-une-premiere-decision-rendue-en-europe/?idLAJ=122601", lang: "fr" }
  - { title: "Village de la Justice — Les apports de la loi SREN", url: "https://www.village-justice.com/articles/les-apports-loi-visant-reguler-espace-numerique,52322.html", lang: "fr" }
  - { title: "Sénat — Réponse ministérielle sur les deepfakes (5 février 2026)", url: "https://www.senat.fr/questions/base/2025/qSEQ251006478.html", lang: "fr" }
  - { title: "Creative Commons — Licence CC BY-NC-SA 4.0 (résumé en français)", url: "https://creativecommons.org/licenses/by-nc-sa/4.0/deed.fr", lang: "fr" }
---

# Droit d'auteur, deepfakes, biais et discriminations

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 7

## 🎯 Ce que vous saurez faire
- Répondre à la question que tout le monde pose : « *l'image que j'ai générée, elle est à moi ?* »
- Lire une licence (CC BY, CC BY-NC, MIT) et savoir si vous pouvez réutiliser un contenu dans un support commercial.
- Reconnaître un deepfake illégal et connaître la peine encourue en France.
- Repérer un biais dans un texte ou un classement généré, et mettre en place un contrôle avant diffusion.

> 🧭 **En clair** — Trois idées simples. **Un** : ce qu'une IA crée seule, en un clic, n'appartient vraiment à personne — c'est comme une photo prise par un appareil tombé par terre ; c'est votre travail humain (choisir, retoucher, assembler) qui crée une protection. **Deux** : faire dire ou faire faire à une vraie personne quelque chose qu'elle n'a pas fait (un *deepfake*) sans son accord est un délit, et même avec son accord, il faut le signaler. **Trois** : une IA apprend de nos textes et images, avec nos préjugés ; elle peut donc les répéter, voire les amplifier. Avant de diffuser, on vérifie qu'elle ne désavantage personne.

## 1. Droit d'auteur : trois questions, trois réponses

Le droit d'auteur français repose sur une idée simple : une **œuvre de l'esprit** est protégée dès sa création si elle est **originale**, c'est-à-dire si elle porte l'empreinte de la personnalité de son auteur. Une machine n'a pas de personnalité. D'où trois questions distinctes qu'il faut absolument séparer.

### 1.1 Les modèles ont-ils le droit d'apprendre sur des œuvres protégées ?

C'est la question de l'**entraînement**. En Europe, la directive 2019/790 a créé une exception de **fouille de textes et de données** (*text and data mining*, TDM) :
- **article 3** : pour la recherche scientifique, sans possibilité pour les auteurs de s'y opposer ;
- **article 4** : pour tout usage, **y compris commercial**, **sauf si le titulaire des droits a réservé ses droits** par un procédé lisible par machine (*opt-out*).

En France, cette exception est transposée à l'**article L122-5-3 du code de la propriété intellectuelle**. Il n'existe pas de standard unique d'opt-out : les praticiens recommandent de **cumuler** le protocole TDMRep, un fichier `ai.txt`, des règles dans `robots.txt` (de petits fichiers techniques placés sur un site pour donner des consignes aux robots qui le visitent) et une clause dans les mentions légales. L'opt-out ne vaut que pour l'avenir : il n'efface pas ce qui a déjà été appris.

Quelques décisions à connaître (nov. 2026) :
- **LAION c. Kneschke, tribunal de Hambourg, 27 septembre 2024** : la constitution d'un jeu de données non commercial par une association de recherche est couverte par l'exception recherche ; dans ce cas précis, une réserve rédigée en texte dans les conditions d'utilisation du site a été jugée suffisante.
- **GEMA c. OpenAI, tribunal de Munich I, 11 novembre 2025** : la mémorisation puis la restitution de paroles de chansons par un modèle constitue une reproduction ; appel en cours.
- **Like Company c. Google, CJUE, affaire C-250/25** : question préjudicielle plaidée en grande chambre le 10 mars 2026, arrêt non rendu à la date de cette formation — c'est l'affaire à suivre.
- En France, une proposition de loi instaurant une **présomption d'utilisation** des contenus culturels par les fournisseurs d'IA a été adoptée au Sénat le 8 avril 2026 et examinée en commission à l'Assemblée le 2 juin 2026 ; elle n'est **pas en vigueur** (nov. 2026).

> 💡 **Autrement dit** — Inutile de retenir ces affaires : elles montrent que les tribunaux européens sont en train de fixer les règles, et que la réponse définitive n'est pas encore connue. La **CJUE** est la Cour de justice de l'Union européenne, le juge suprême du droit européen ; une **question préjudicielle**, c'est un tribunal national qui lui demande comment interpréter la loi.

Côté AI Act, l'article 53 impose depuis le 2 août 2025 aux fournisseurs de modèles à usage général une **politique de respect du droit d'auteur** et un **résumé public** des données d'entraînement (modèle de la Commission du 24 juillet 2025). Ce volet n'a pas été reporté par l'omnibus de 2026.

> 💡 **Autrement dit** — L'*opt-out*, c'est un panneau « Défense d'entrer » posé sur votre site, lisible par les robots des entreprises d'IA. Sans panneau, la loi européenne les autorise à « lire » vos contenus pour entraîner leurs modèles, même à des fins commerciales. Le panneau ne vaut que pour l'avenir : ce qui a déjà été lu reste appris.

### 1.2 Ce que je génère, est-ce à moi ?

C'est la question de la **sortie** (*output*). Deux règles coexistent :

1. **Les conditions d'utilisation du fournisseur.** OpenAI, par exemple, cède à l'utilisateur la propriété des sorties (version du 1er janvier 2026, d'après l'analyse citée dans nos sources), en interdisant notamment d'entraîner un modèle concurrent ou de présenter une sortie comme humaine dans certains contextes. Lisez les conditions de **votre** outil : elles diffèrent.
2. **Le droit d'auteur lui-même** (art. L111-1 CPI) : sans **intervention créative humaine**, une sortie brute n'est pas une œuvre protégée. Le fournisseur peut vous « céder » la sortie, cela ne crée pas un droit d'auteur opposable aux tiers. En revanche, une sortie **retravaillée** (choix, montage, réécriture, direction artistique documentée) est protégeable **à hauteur des apports humains**.

> 💡 **À retenir** — Pour protéger un contenu produit avec l'IA, **documentez la part humaine** : brief initial, itérations, sélections, retouches. Conservez les versions. Un logo généré en un clic est copiable par votre concurrent sans recours ; un logo généré, puis choisi parmi 40, retravaillé et intégré à une charte graphique, l'est beaucoup moins.

```quiz
{
  "q": "Votre graphiste a généré un logo en un clic, sans aucune retouche. Un concurrent publie un logo quasi identique. Que pouvez-vous faire au titre du droit d'auteur ?",
  "options": ["L'attaquer en contrefaçon : les conditions d'utilisation du fournisseur vous ont cédé la propriété", "Pas grand-chose : une sortie brute sans apport créatif humain n'est pas une œuvre protégée", "Déposer plainte pour deepfake", "Exiger qu'il paie une licence CC BY-NC"],
  "answer": 1,
  "explanation": "Sans intervention créative humaine, pas d'œuvre originale (art. L111-1 CPI). La cession prévue par le fournisseur ne crée pas un droit opposable aux tiers. D'où le conseil : documenter la part humaine."
}
```

### 1.3 Puis-je réutiliser ce que je trouve en ligne (cours, images, vidéos) ?

C'est la question de la **réutilisation**, celle qui piège le plus les PME qui montent une formation interne, un site ou une plaquette.

| Licence / source | Ce que vous pouvez faire | Ce que vous ne pouvez pas faire |
|---|---|---|
| **CC BY** | Tout, y compris commercial, avec attribution (en citant l'auteur) | Omettre l'attribution |
| **CC BY-NC(-SA)** (NC = pas d'usage commercial ; SA = repartager dans les mêmes conditions) (ex. MIT OpenCourseWare, Stanford SEE, dépôt `anthropics/courses`) | Usage **non commercial** : formation interne gratuite, étude personnelle | Intégrer dans une **formation vendue**, un produit payant ; MIT précise qu'« une entreprise de formation ne peut pas proposer des cours payants basés sur ces contenus » |
| **MIT / Apache 2.0** (ex. `microsoft/generative-ai-for-beginners`) | Réutiliser, modifier, vendre, traduire | Supprimer la notice de copyright |
| **Vidéo YouTube** | **Intégrer** (embed) via le lecteur officiel si le créateur l'autorise | Télécharger et ré-héberger, masquer la marque, ajouter sa propre publicité |
| **Courte citation** (art. L122-5 3° a CPI) | Citer quelques lignes, avec auteur et source, à titre critique ou pédagogique | Reprendre un chapitre, une vidéo entière — conditions exactes à vérifier sur Légifrance |
| **Image trouvée sur Google Images** | Rien par défaut | La coller dans votre plaquette (c'est de la contrefaçon, même « pour un usage interne ») |

> ⚠️ **Piège fréquent** — « *C'est gratuit en ligne, donc je peux l'utiliser.* » Gratuit d'accès ne veut pas dire libre de droits. Et « NC » (*non commercial*) couvre tout ce qui est « prioritairement destiné à susciter un avantage commercial ou une compensation financière » : une formation payante, un site d'entreprise, une plaquette commerciale.

> 🔗 **Documentation officielle** — [Creative Commons — CC BY-NC-SA 4.0 (deed en français)](https://creativecommons.org/licenses/by-nc-sa/4.0/deed.fr) · [MIT OpenCourseWare — Terms of use](https://ocw.mit.edu/pages/privacy-and-terms-of-use/) 🇬🇧 · [donneespersonnelles.fr — Droit d'auteur et IA générative](https://www.donneespersonnelles.fr/droit-auteur-ia-generative)

```mission
{
  "title": "Que veut dire « SA » dans une licence Creative Commons ?",
  "url": "https://creativecommons.org/licenses/by-nc-sa/4.0/deed.fr",
  "steps": ["Ouvrez le résumé en français de la licence CC BY-NC-SA 4.0", "Repérez les trois conditions affichées avec leurs pictogrammes", "Lisez la définition de chacune"],
  "question": "Que signifient les trois sigles BY, NC et SA, et que vous impose concrètement « SA » si vous modifiez le contenu ?",
  "hint": "Le troisième sigle concerne la licence de votre propre version.",
  "answer": "BY = Attribution (citer l'auteur) ; NC = Pas d'utilisation commerciale ; SA = Partage dans les mêmes conditions : si vous remaniez le contenu, vous devez diffuser votre version sous la même licence.",
  "xp": 10
}
```

## 2. Deepfakes : ce qui est interdit, ce qui doit être signalé

Un **deepfake** (hypertrucage) est un contenu audio, vidéo ou image qui représente une personne réelle en train de dire ou faire quelque chose qu'elle n'a pas dit ou fait, généré ou modifié par IA. Les outils de 2026 (voir module 3) le rendent accessible en quelques minutes, y compris pour cloner une voix à partir de dix secondes d'enregistrement.

### 2.1 Le droit pénal français : article 226-8 du code pénal

La **loi SREN n° 2024-449 du 21 mai 2024** (article 15) a modifié l'**article 226-8 du code pénal** pour viser explicitement les montages et contenus « générés par un traitement algorithmique » représentant l'image ou les paroles d'une personne **sans son consentement**, lorsqu'il n'apparaît pas à l'évidence qu'il s'agit d'un montage ou que ce n'est pas expressément mentionné. Circonstance aggravante lorsque le contenu est diffusé sur un **réseau social** ou un service en ligne : jusqu'à **2 ans d'emprisonnement et 45 000 € d'amende**. Le texte exact (conditions, peines de base, deepfakes à caractère sexuel) est à vérifier sur Légifrance.

### 2.2 L'AI Act : signaler, même quand c'est légal

Depuis le **2 août 2026**, l'article 50 de l'AI Act impose aux déployeurs de **signaler** qu'un contenu est un deepfake (avec aménagements pour les œuvres manifestement artistiques ou satiriques) et aux fournisseurs de **marquer** les contenus synthétiques. À partir du **2 décembre 2026**, l'omnibus (règlement (UE) 2026/1744) ajoute aux pratiques interdites les systèmes qui génèrent des images intimes non consenties (applications dites « nudifier ») et du matériel pédopornographique. Sanction : jusqu'à 15 M€ ou 3 % du chiffre d'affaires, comme l'a confirmé la réponse ministérielle publiée au Sénat le 5 février 2026.

```mission
{
  "title": "L'article 226-8 du code pénal sur Légifrance",
  "url": "https://www.legifrance.gouv.fr/",
  "steps": ["Ouvrez Légifrance, rubrique Codes, puis Code pénal", "Recherchez l'article 226-8", "Vérifiez que vous lisez la version en vigueur (modifiée par la loi SREN du 21 mai 2024)"],
  "question": "Quelle est la peine de base pour un deepfake publié sans consentement, et quelle peine s'applique quand il est diffusé via un service de communication au public en ligne ?",
  "hint": "La peine aggravée est déjà dans la leçon ; cherchez la peine de base.",
  "answer": "Un an d'emprisonnement et 15 000 € d'amende ; deux ans et 45 000 € en cas de diffusion en ligne (version issue de la loi n° 2024-449 — vérifiez la version en vigueur à la date de consultation).",
  "xp": 20
}
```

### 2.3 Cas pratiques d'entreprise

| Situation | Verdict |
|---|---|
| Une agence de communication clone la voix du dirigeant (avec son accord écrit) pour un message de vœux, mention « voix générée par IA » | Licite : consentement + transparence |
| Un commercial fait dire à un concurrent, dans une vidéo humoristique interne, que ses produits sont nuls | **Illicite** : pas de consentement, montage non évident ; s'ajoutent le dénigrement et la diffamation |
| Un service marketing crée un faux témoignage client avec un visage généré « qui ne ressemble à personne » | Pas de deepfake d'une personne réelle, mais **pratique commerciale trompeuse** (faux avis) — à proscrire |
| Un fraudeur appelle la comptable avec la voix clonée du DG pour un virement urgent | Deepfake criminel (escroquerie) : voir leçon L031 |

> 💡 **À retenir** — Deux réflexes : **consentement écrit** de la personne représentée, **mention visible** « contenu généré par IA ». Sans les deux, ne publiez pas.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : avec l'accord écrit du dirigeant, une agence peut cloner sa voix pour un message de vœux, à condition d'indiquer que la voix est générée par IA.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. Consentement écrit de la personne représentée et mention visible « contenu généré par IA » : ce sont les deux réflexes qui rendent l'usage licite."
}
```

## 3. Biais et discriminations : quand l'IA répète nos erreurs

### 3.1 D'où viennent les biais ?

Un modèle apprend à partir de textes et d'images produits par des humains. Si, dans ces données, les infirmières sont des femmes et les ingénieurs des hommes, le modèle **reproduit** cette association, parfois en l'**amplifiant**. Trois sources principales :
1. **Biais des données** : sous-représentation de certains groupes, stéréotypes historiques.
2. **Biais d'étiquetage** : les annotateurs humains ont leurs propres préjugés.
3. **Biais d'usage** : vous demandez « le profil idéal » et le modèle optimise sur des critères qui corrèlent avec (vont souvent de pair avec) l'origine, l'âge ou le genre.

Exemple historique exact : à la fin des années 2010, un grand distributeur en ligne a abandonné un outil expérimental de tri de CV qui pénalisait les candidatures contenant le mot « *women's* » (clubs féminins), parce qu'il avait appris sur dix ans de recrutements majoritairement masculins. L'outil n'a jamais été utilisé en production — mais l'histoire illustre parfaitement le mécanisme.

### 3.2 Ce que dit le droit

En France, la discrimination fondée sur un critère protégé (origine, sexe, âge, handicap, état de santé, opinions, syndicat, orientation sexuelle, lieu de résidence…) est interdite par le code pénal et le code du travail, **que la décision soit prise par un humain ou assistée par une machine** (articles à vérifier sur Légifrance). L'AI Act classe les usages RH, éducation et crédit en **haut risque** précisément pour cette raison (L029). Et le RGPD encadre les décisions **entièrement automatisées** produisant des effets juridiques sur une personne (L028).

Le principe pratique : **« l'IA propose, l'humain dispose »**, et l'humain doit être capable d'expliquer la décision sans dire « c'est l'algorithme ».

> 💡 **Autrement dit** — Un **proxy**, c'est un critère d'apparence neutre qui en cache un autre. « Disponibilité totale » peut écarter les parents ; « jeune et dynamique » écarte les seniors ; une adresse peut trahir une origine. Le test le plus simple : changez une seule variable (prénom, âge, quartier) et regardez si la réponse de l'IA change.

### 3.3 La check-list anti-biais (à appliquer avant diffusion)

```
☐ 1. Ai-je demandé à l'IA un classement ou une sélection de PERSONNES ?
      → Si oui, niveau de vigilance maximal, décision finale humaine obligatoire.
☐ 2. Le prompt contient-il des critères protégés ou des proxys ?
      (âge, « jeune et dynamique », nom, adresse, photo, « disponibilité totale »…)
☐ 3. Ai-je testé le même prompt en changeant UNE variable (prénom masculin/féminin,
      quartier, âge) ? Le résultat change-t-il ?
☐ 4. Les illustrations générées représentent-elles la diversité réelle de mon public ?
☐ 5. Le texte contient-il des généralisations sur un groupe (« les seniors ont du mal
      avec le numérique ») ?
☐ 6. Puis-je expliquer la décision ou le contenu sans invoquer l'IA ?
☐ 7. Ai-je conservé une trace (prompt, sortie, correction) ?
```

> ⚠️ **Piège fréquent** — Croire qu'un modèle « récent » est « sans biais ». Les fournisseurs réduisent les biais les plus visibles, mais aucun modèle n'est neutre : le cours « AI capabilities and limitations » de Claude Academy consacre une section entière à la façon dont un modèle « acquiert son caractère » à partir de ses données et de son entraînement.

> 🔗 **Documentation officielle** — [Claude Academy — AI capabilities and limitations](https://academy.claude.com/courses/ai-capabilities-and-limitations) 🇬🇧 · [Sénat — Réponse ministérielle du 5 février 2026](https://www.senat.fr/questions/base/2025/qSEQ251006478.html)

```quiz
{
  "q": "Mise en situation : vous demandez à l'IA de classer 10 candidats. Vous relancez le même prompt en remplaçant seulement « Julien » par « Fatoumata » dans un CV, et ce candidat recule de 4 places. Que faites-vous ?",
  "options": ["Rien : l'IA est neutre, c'est une simple variation aléatoire entre deux exécutions", "Vous gardez le second classement, plus récent, et vous l'envoyez au manager", "C'est un biais : la décision redevient humaine et explicable", "Vous retirez le prénom de ce CV et publiez le classement tel quel"],
  "answer": 2,
  "explanation": "Le test « une variable à la fois » vient de révéler un biais lié à un critère protégé. Un classement de personnes exige une décision finale humaine qu'on sait expliquer sans invoquer l'algorithme."
}
```

## 🧪 Exercice pratique

**Consigne.** Un cabinet de recrutement de 6 personnes a demandé à un assistant IA : « *Rédige une annonce pour un poste de responsable de magasin, profil jeune, dynamique, de préférence disponible le week-end, et génère une photo d'illustration du candidat idéal.* » Le modèle a produit une annonce et une image d'un homme blanc d'une trentaine d'années en costume.

1. Relevez les éléments problématiques dans le **prompt** et dans la **sortie** (annonce + image).
2. Réécrivez le prompt.
3. Indiquez qui est titulaire des droits sur l'image finale si le cabinet la publie, et ce qu'il doit ajouter.

**Concrètement :** trois parties dans un document. ① Une liste à puces des problèmes, en précisant pour chacun où il se trouve (prompt, annonce ou image) et pourquoi il pose problème : aidez-vous de la check-list anti-biais de la section 3.3. ② Le nouveau prompt complet, construit avec les briques du module 4 (rôle, contexte, tâche, format, contraintes). ③ Deux phrases : à qui appartient l'image (section 1.2) et quelle mention ajouter (section 2.2). Inutile de générer réellement l'image.

**Critères de réussite.** Au moins trois problèmes identifiés (âge, proxy de situation familiale, image non diverse, absence de mention IA) ; prompt réécrit sans critère protégé ; réponse correcte sur la protection (sortie brute non protégée par le droit d'auteur, conditions du fournisseur à vérifier) et sur la mention de contenu généré.

<details>
<summary>Corrigé</summary>

1. **Prompt** : « jeune » = critère d'âge (discriminatoire) ; « disponible le week-end » peut être une exigence légitime du poste si elle est formulée comme contrainte objective, mais « de préférence » suggère un tri sur la situation personnelle ; « candidat idéal » en image = demande de **représentation d'une personne type**, piège classique. **Sortie** : l'image uniformise (genre, origine, âge) ; l'annonce reprend « jeune et dynamique » ; aucune mention de génération par IA.
2. Réécriture : « Rédige une annonce pour un poste de responsable de magasin en CDI. Missions : [liste]. Compétences requises : gestion d'équipe, tenue de caisse, merchandising. Contrainte : travail le samedi (planning tournant). Ton accueillant, 200 mots, formulation inclusive, aucune référence à l'âge, au genre ou à la situation familiale. » Pour l'illustration : préférer une photo du magasin ou une illustration **sans personnage**, ou générer une image représentant l'équipe diverse, avec mention « illustration générée par IA ».
3. L'image brute n'est **pas une œuvre protégée** (pas d'apport créatif humain, art. L111-1 CPI) ; le cabinet peut l'utiliser selon les conditions de son fournisseur, mais ne pourra pas interdire à un tiers d'en produire une semblable. Il doit ajouter la **mention de contenu généré** (bonne pratique, obligatoire pour les deepfakes et contenus synthétiques selon l'art. 50 de l'AI Act).
</details>

🎮 **Défi** — Demandez à votre assistant IA « *Décris un chef d'entreprise qui réussit* » puis « *Décris une cheffe d'entreprise qui réussit* ». Comparez les adjectifs. Qu'observez-vous ?

## ✅ Auto-évaluation express

1. Une image générée en un clic, sans retouche, est-elle protégée par le droit d'auteur en France ?
2. Quelle peine maximale prévoit l'article 226-8 du code pénal pour un deepfake diffusé sur un réseau social sans consentement ?
3. Puis-je intégrer les notebooks du dépôt `anthropics/courses` (licence CC BY-NC 4.0) dans une formation que je vends ?

<details>
<summary>Réponses</summary>

1. **Non** : sans intervention créative humaine, pas d'œuvre originale (art. L111-1 CPI). Une version retravaillée est protégeable à hauteur des apports humains.
2. Jusqu'à **2 ans d'emprisonnement et 45 000 € d'amende** (circonstance aggravante de diffusion en ligne, loi SREN du 21 mai 2024 ; texte exact à vérifier sur Légifrance).
3. **Non** : la clause NC interdit l'usage commercial. Vous pouvez renvoyer vers le dépôt, vous inspirer de la structure et écrire vos propres exercices.
</details>

> ✅ **Si vous ne retenez que 3 choses** — 1. Un contenu généré en un clic n'est protégé par personne : documentez votre apport humain. Et « gratuit en ligne » ne veut pas dire libre de droits : lisez la licence (NC = pas d'usage commercial). 2. Montrer une vraie personne dans un contenu fabriqué exige son accord écrit et une mention visible « généré par IA » ; sinon c'est un délit (jusqu'à 2 ans de prison et 45 000 € d'amende). 3. L'IA répète nos préjugés : aucun critère d'âge, de genre ou d'origine dans vos prompts, testez en changeant une seule variable, et gardez la décision et son explication côté humain.

## 📚 Pour aller plus loin
- [donneespersonnelles.fr — Droit d'auteur et IA générative](https://www.donneespersonnelles.fr/droit-auteur-ia-generative) — état des lieux (TDM, jurisprudence, PPL « présomption d'utilisation »), mis à jour septembre 2026.
- [Seban & Associés — LAION c. Kneschke](https://www.seban-associes.avocat.fr/intelligence-artificielle-et-exception-de-fouille-de-textes-et-de-donnees-une-premiere-decision-rendue-en-europe/?idLAJ=122601) — première décision européenne sur l'exception TDM, expliquée simplement.
- [Village de la Justice — Les apports de la loi SREN](https://www.village-justice.com/articles/les-apports-loi-visant-reguler-espace-numerique,52322.html) — le volet deepfakes et les autres mesures de la loi du 21 mai 2024.
- [Légifrance](https://www.legifrance.gouv.fr/) — pour vérifier les articles 226-8 du code pénal, L111-1 et L122-5-3 du code de la propriété intellectuelle.
- [Google AI Essentials — cours « Use AI Responsibly »](https://www.coursera.org/google-specializations/ai-essentials-google) 🇬🇧 — module d'une heure sur les biais et l'usage responsable ; certificat Google en complément de cette formation.
- [Microsoft Learn — Guide d'étude AI-900 (principes d'IA responsable)](https://learn.microsoft.com/certifications/resources/study-guides/AI-900) 🇬🇧 — les six principes (équité, fiabilité, confidentialité, inclusivité, transparence, responsabilité) ; examen remplacé par AI-901 depuis juin 2026.

> 🗺️ **Et maintenant ?** — Dernière brique du module : la sécurité au quotidien. La leçon L031 vous apprend à protéger vos clés, à déjouer le phishing dopé à l'IA et à éviter le *shadow AI*.

