---
id: L028
module: M07
level: N1
title: "RGPD et données personnelles dans les prompts (CNIL)"
minutes: 40
objectives:
  - "Identifier une donnée personnelle et une donnée sensible dans un prompt avant de l'envoyer à un assistant IA"
  - "Appliquer les principes du RGPD (finalité, minimisation, base légale, droits) à l'usage quotidien d'un outil d'IA générative"
  - "Produire la première version d'une charte d'usage IA pour une petite structure"
skills: ["C1.6"]
sources:
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "CNIL — Développement des systèmes d'IA : les recommandations de la CNIL pour respecter le RGPD", url: "https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd", lang: "fr" }
  - { title: "CNIL — IA : finalisation des recommandations sur le développement des systèmes d'IA", url: "https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia", lang: "fr" }
  - { title: "Anthropic — API and data retention", url: "https://platform.claude.com/docs/en/manage-claude/api-and-data-retention", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
---

# RGPD et données personnelles dans les prompts (CNIL)

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 7

## 🎯 Ce que vous saurez faire
- Repérer en quelques secondes, dans un prompt, ce qui est une donnée personnelle, une donnée sensible ou un secret d'affaires.
- Appliquer la règle des « 3 questions » avant de coller un document dans ChatGPT, Claude, Gemini, Le Chat ou Copilot.
- Choisir entre anonymiser, pseudonymiser, ou ne pas envoyer du tout.
- Rédiger la première page d'une charte d'usage de l'IA pour votre équipe (la seconde page viendra avec l'AI Act, leçon L029).

> 🧭 **En clair** — Coller un document dans un assistant IA, c'est comme le confier à un coursier : il quitte votre bureau et part chez quelqu'un d'autre. Le RGPD ne vous interdit pas d'appeler le coursier ; il vous demande de vérifier ce que contient l'enveloppe. Avant d'envoyer, retirez ce qui permet de reconnaître une personne (nom, téléphone, description trop précise), n'envoyez jamais de données de santé ou de secrets sur un compte gratuit, et utilisez les outils que votre entreprise a validés. Dans la grande majorité des cas, remplacer « Karim Benali » par « S1 » donne exactement le même résultat, sans aucun risque.

## 1. Pourquoi cette leçon existe : l'histoire du comptable trop pressé

Lundi matin, 8 h 40. Dans un cabinet comptable de Nantes, un collaborateur reçoit vingt bulletins de paie à vérifier. Il a une idée : il copie le fichier Excel complet (noms, numéros de sécurité sociale, salaires, arrêts maladie) dans un assistant IA grand public et demande « *trouve les anomalies* ». L'outil répond en dix secondes. Mission accomplie ?

Non. En dix secondes, il vient de :
1. **transférer des données personnelles** (et des données de santé, donc *sensibles*) vers un prestataire que son cabinet n'a jamais contractualisé (aucun contrat signé avec lui) ;
2. le faire **sans base légale** ni information des salariés concernés ;
3. potentiellement **alimenter l'entraînement** d'un modèle si le compte utilisé est un compte gratuit dont les réglages par défaut autorisent cet usage ;
4. engager la **responsabilité de son employeur**, qui est le *responsable de traitement* au sens du RGPD.

Le pire ? Il n'avait pas besoin de tout ça. Un fichier avec des identifiants anonymes (`SAL-001`, `SAL-002`…) et les seules colonnes utiles aurait donné exactement le même résultat.

> 💡 **À retenir** — Le RGPD ne vous interdit pas d'utiliser l'IA. Il vous demande de **réfléchir avant d'envoyer**. La CNIL elle-même l'écrit : « l'idée reçue selon laquelle le RGPD empêcherait l'innovation en IA est fausse ».

```quiz
{
  "q": "Dans l'histoire du comptable de Nantes, qui est juridiquement le « responsable de traitement » des données des salariés ?",
  "options": ["Le collaborateur qui a collé le fichier", "L'éditeur de l'assistant IA", "Le cabinet comptable, son employeur", "La CNIL"],
  "answer": 2,
  "explanation": "Le responsable de traitement est celui qui décide pourquoi et comment les données sont traitées : en pratique l'employeur. Le collaborateur agit sous son autorité, ce qui engage la responsabilité du cabinet."
}
```

## 2. Le vocabulaire minimum (sans être juriste)

| Terme | Définition simple | Exemple dans un prompt |
|---|---|---|
| **Donnée personnelle** | Toute information qui permet d'identifier une personne, directement ou indirectement | Nom, e-mail, numéro de téléphone, plaque d'immatriculation, adresse IP (le numéro qui identifie une connexion Internet), photo, voix… |
| **Donnée sensible** (catégories particulières) | Données dont le traitement est en principe interdit : santé, origine ethnique, opinions politiques, religion, syndicat, orientation sexuelle, données biométriques et génétiques | Arrêt maladie, mention « RQTH » (reconnaissance de la qualité de travailleur handicapé), « adhérent CGT » dans un compte rendu d'entretien |
| **Responsable de traitement** | Celui qui décide *pourquoi* et *comment* les données sont traitées : en pratique, votre **employeur** | Le cabinet comptable, pas le collaborateur |
| **Sous-traitant** | Celui qui traite les données pour le compte du responsable | L'éditeur de l'assistant IA, si un contrat le prévoit |
| **Finalité** | Le but précis et légitime du traitement | « Contrôler la cohérence des bulletins de paie » |
| **Minimisation** | Ne collecter et n'envoyer que ce qui est strictement nécessaire à la finalité | Pas besoin du numéro de sécurité sociale pour vérifier une somme |
| **Base légale** | La justification juridique du traitement (contrat, obligation légale, intérêt légitime, consentement…) | Pour une entreprise privée, l'**intérêt légitime** est la base la plus courante selon la CNIL, sous trois conditions (intérêt réel, nécessité, équilibre avec les droits des personnes) |
| **AIPD** (analyse d'impact) | Étude préalable des risques pour les personnes, exigée quand le traitement est à risque élevé | Déploiement d'un outil IA de tri de candidatures |

Ces notions proviennent du règlement (UE) 2016/679 (RGPD). Les numéros d'articles précis (définitions, bases légales, droits, AIPD) sont à vérifier sur EUR-Lex si vous devez les citer dans un document officiel ; pour l'usage quotidien, la logique ci-dessus suffit.

> ⚠️ **Piège fréquent** — « *Mon prompt ne contient pas de nom, donc pas de donnée personnelle.* » Faux. « *Le directeur financier de notre PME de 12 salariés à Vierzon, en arrêt depuis mars* » identifie une personne sans la nommer. L'identification **indirecte** compte autant que le nom.

> 💡 **Autrement dit** — Une donnée personnelle, ce n'est pas seulement un nom : c'est tout ce qui permet de reconnaître quelqu'un, même par recoupement. « La seule comptable de notre agence de Vierzon, enceinte depuis l'été » ne cite aucun nom, mais tout le monde sait de qui on parle. Si un collègue pourrait deviner, c'est une donnée personnelle.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : « le seul technicien de nuit de notre site d'Angers, en arrêt depuis septembre » n'est pas une donnée personnelle, puisqu'aucun nom n'est cité.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. L'identification indirecte compte autant que le nom : ce collègue est reconnaissable. Et la mention de l'arrêt touche en plus à la santé, une donnée sensible."
}
```

## 3. Où vont vos prompts ? Trois situations très différentes

Avant de juger un usage, il faut savoir où partent les données. Le schéma ci-dessous résume les trois cas que vous rencontrerez (nov. 2026).

```
Votre prompt
   │
   ├─► (A) Compte grand public gratuit / perso
   │       → serveurs de l'éditeur, souvent hors UE
   │       → réglages par défaut : parfois utilisation pour l'entraînement
   │       → aucun contrat avec votre entreprise
   │
   ├─► (B) Offre professionnelle (Team / Enterprise / API)
   │       → contrat de sous-traitance (clauses RGPD, durée de conservation)
   │       → engagement « pas d'entraînement sur vos données » dans la plupart des offres
   │       → options de résidence des données (ex. UE / US) chez certains fournisseurs
   │
   └─► (C) Modèle local (Ollama, LM Studio…) — voir module 10
           → rien ne sort de votre machine
```

Quelques repères factuels :

- Chez Anthropic, la documentation « API and data retention » décrit les durées de conservation des données envoyées à l'API et les options associées ; une page « Data residency » décrit le choix de la zone d'inférence (le pays ou la région où les calculs sont faits) (nov. 2026). Lisez ces pages avant de signer : c'est exactement le type de garantie que votre responsable de traitement doit pouvoir exiger.
- Chez OpenAI, la page « Safety best practices » rappelle l'existence d'une API de modération gratuite (un service qui repère automatiquement les contenus problématiques), la nécessité d'un humain dans la boucle pour les décisions à fort impact et la révocation immédiate d'une clé compromise.
- Les conditions exactes (entraînement ou non, durée de conservation, localisation) **changent souvent** : notez la date de votre vérification dans votre charte.

> 🔗 **Documentation officielle** — [Anthropic — API and data retention](https://platform.claude.com/docs/en/manage-claude/api-and-data-retention) 🇬🇧 · [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧

## 4. La règle des 3 questions (à afficher au-dessus de l'écran)

Avant d'envoyer un document ou un texte à un assistant IA, posez-vous **dans l'ordre** :

1. **Y a-t-il des personnes identifiables dedans ?** (noms, e-mails, numéros, descriptions précises, photos, voix)
   → Si oui : puis-je les **retirer** ou les **remplacer** sans nuire à la tâche ? Dans 90 % des cas, oui.
2. **Y a-t-il des données sensibles ou des secrets ?** (santé, opinions, syndicat, mais aussi : prix d'achat, code source, contrat non signé, données clients)
   → Si oui : **stop** sur un compte grand public. Uniquement via un outil contractualisé par l'entreprise (B) ou en local (C), et seulement si la charte l'autorise.
3. **Mon entreprise a-t-elle autorisé cet outil pour cet usage ?**
   → Si vous ne savez pas, demandez. L'usage d'un outil non validé a un nom : le *shadow AI* (leçon L031).

### 4.1 Anonymiser, pseudonymiser : la différence qui compte

- **Pseudonymiser** = remplacer les identifiants par des codes (`Client A`, `SAL-017`) **en gardant une table de correspondance chez vous**. Les données restent personnelles au sens du RGPD (on peut revenir en arrière), mais le risque en cas de fuite est très réduit. C'est la bonne pratique pour la plupart des tâches de bureau.
- **Anonymiser** = rendre l'identification **impossible de façon irréversible** (agréger, supprimer, généraliser). Les données ne sont plus personnelles. C'est plus exigeant qu'il n'y paraît : « femme, 52 ans, directrice d'une boulangerie à Saint-Flour » n'est pas anonyme.

Exemple concret, service RH d'une PME de 40 personnes qui veut un résumé des entretiens annuels :

| Avant (interdit sur compte perso) | Après (acceptable) |
|---|---|
| « Résume l'entretien de Karim Benali, 34 ans, chef d'atelier, qui se plaint de son mal de dos et souhaite une augmentation. » | « Résume cet entretien annuel. Le salarié est désigné **S1**. Les informations médicales ont été retirées. Objectif : liste des demandes professionnelles et des actions à prévoir. » |

```quiz
{
  "q": "Mise en situation : vous remplacez les noms des clients par « Client A, Client B… » et gardez la table de correspondance dans un fichier interne. Qu'avez-vous fait ?",
  "options": ["Une anonymisation : les données ne sont plus personnelles au sens du RGPD", "Une pseudonymisation : risque réduit, données toujours personnelles", "Rien d'utile : seul un chiffrement complet du fichier protège réellement", "Une violation du RGPD, car toute table de correspondance est interdite"],
  "answer": 1,
  "explanation": "Tant qu'une table permet de revenir en arrière, c'est une pseudonymisation : très utile pour réduire le risque, mais le RGPD continue de s'appliquer. L'anonymisation, elle, est irréversible."
}
```

### 4.2 Et les droits des personnes ?

Le RGPD donne aux personnes des droits (accès, rectification, effacement, opposition…). Conséquence pratique souvent oubliée : si vous envoyez les données d'un client dans un outil IA, ce client peut vous demander **ce que vous en avez fait et à qui vous les avez transmises**. Si votre réponse est « je ne sais pas, c'était dans ChatGPT », vous avez un problème. Tenez une trace : quel outil, quelle finalité, quelle date.

## 5. Ce que dit la CNIL sur l'IA (nov. 2026)

La CNIL a publié, entre 2024 et juillet 2025, **15 fiches pratiques** (numérotées de 1 à 13, dont une fiche 4 en deux parties et une fiche 8 bis) consacrées au développement des systèmes d'IA (régime juridique, finalité, base légale, AIPD, protection dès la conception, collecte, intérêt légitime, moissonnage web (collecte automatique de pages web), information des personnes, droits, annotation, sécurité…). Elles visent d'abord ceux qui *construisent* des systèmes d'IA, mais plusieurs messages s'appliquent directement à vous, utilisateur :

- **Finalité précise** : « améliorer la productivité » n'est pas une finalité ; « générer des réponses types aux réclamations clients » en est une.
- **Intérêt légitime** = base légale habituelle du secteur privé, sous trois conditions (intérêt réel, nécessité, mise en balance avec les droits des personnes).
- **AIPD fortement recommandée**, et de fait obligatoire pour les systèmes classés à haut risque par l'AI Act (leçon L029).
- **Minimisation et durée de conservation** : ne gardez pas les historiques de conversation contenant des données personnelles « au cas où ».
- La CNIL annonce des recommandations **sectorielles** (éducation, santé avec la HAS, travail) : surveillez la page des fiches pratiques, elle évolue.

> 🔗 **Documentation officielle** — [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) · [CNIL — Recommandations pour respecter le RGPD](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd)

> 💡 **À retenir** — Dans une entreprise, le RGPD est l'affaire du **responsable de traitement** (l'employeur) et, s'il existe, du **DPO** (délégué à la protection des données). Votre rôle de salarié : respecter la charte, pseudonymiser par réflexe, et signaler toute fuite immédiatement (une violation de données doit être notifiée à la CNIL dans un délai court, 72 heures selon le RGPD — vérifiez la procédure interne).

```mission
{
  "title": "Combien de fiches pratiques IA la CNIL a-t-elle publiées ?",
  "url": "https://cnil.fr/fr/les-fiches-pratiques-ia",
  "steps": ["Ouvrez la page « Les fiches pratiques IA » de la CNIL", "Comptez les fiches listées (attention à la fiche « 8 bis »)", "Repérez le document de synthèse proposé en téléchargement"],
  "question": "Combien de fiches pratiques la page présente-t-elle, et quel document récapitulatif est proposé pour vérifier sa conformité ?",
  "hint": "Le récapitulatif prend la forme d'une liste à cocher en PDF.",
  "answer": "15 fiches pratiques (numérotées de 1 à 13, dont une fiche 4 en deux parties et une fiche 8 bis sur le moissonnage web), plus une fiche synthèse, une introduction et une liste de vérification au format PDF (juillet 2025). Page susceptible d'être enrichie par des recommandations sectorielles (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Les prochains chantiers IA de la CNIL",
  "url": "https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia",
  "steps": ["Ouvrez l'article de la CNIL sur la finalisation de ses recommandations IA", "Repérez la date de publication", "Cherchez la partie sur les travaux à venir"],
  "question": "Quels secteurs la CNIL annonce-t-elle pour ses futures recommandations, et comment s'appelle son projet d'outil d'audit de confidentialité des modèles mené avec l'ANSSI et le PEReN ?",
  "hint": "Le nom du projet évoque une capitale… et un panier.",
  "answer": "Éducation, santé (avec la HAS) et travail ; projet PANAME (article du 22 juillet 2025 — l'avancement a pu évoluer depuis).",
  "xp": 15
}
```

## 6. Charte d'usage IA — page 1 (modèle à adapter)

Voici un modèle volontairement court. Une charte de 12 pages que personne ne lit protège moins qu'une page affichée dans la cuisine.

```
CHARTE D'USAGE DE L'IA GÉNÉRATIVE — [Nom de l'entreprise] — version 1.0 du [date]

1. OUTILS AUTORISÉS
   - [Outil 1] (compte entreprise, contrat signé le __/__/____, données non utilisées pour l'entraînement : oui/non vérifié le __/__)
   - [Outil 2] ...
   Tout autre outil est interdit pour les données de l'entreprise, sauf accord écrit de [responsable].

2. DONNÉES INTERDITES DE SAISIE (quel que soit l'outil)
   - Données de santé, opinions, religion, syndicat, orientation sexuelle, données biométriques
   - Numéros de sécurité sociale, IBAN, mots de passe, clés d'accès
   - Secrets d'affaires non publics : prix d'achat, contrats en négociation, code source propriétaire
   - Données de clients ou de salariés nominatives → pseudonymiser d'abord (Client A, SAL-01)

3. RÈGLE DES 3 QUESTIONS avant tout envoi
   Personnes identifiables ? Données sensibles / secrets ? Outil autorisé pour cet usage ?

4. VÉRIFICATION HUMAINE
   Toute production IA destinée à un client, un salarié ou une administration est relue
   et validée par une personne responsable avant envoi. L'IA ne décide jamais seule
   d'un recrutement, d'une sanction, d'un refus de crédit ou d'un licenciement.

5. TRANSPARENCE
   Un contenu généré ou substantiellement modifié par IA et diffusé à l'extérieur est signalé
   comme tel lorsque la loi ou le bon sens l'exige (voir page 2, AI Act).

6. INCIDENTS
   Toute saisie accidentelle de données interdites ou tout doute est signalé sans délai à
   [DPO / responsable], sans sanction pour le signalement de bonne foi.

7. FORMATION
   Chaque collaborateur suit une sensibilisation IA à l'arrivée puis une fois par an (page 2).

Signature du collaborateur : ____________   Date : ____________
```

La page 2 (obligations issues de l'AI Act, transparence, inventaire des systèmes) est construite dans la leçon suivante.

## 🧪 Exercice pratique

**Consigne.** Vous êtes assistant(e) de direction dans une agence immobilière de 8 personnes. Votre responsable vous transmet trois prompts qu'il a l'intention d'envoyer à un assistant IA grand public (compte gratuit). Pour chacun : (1) surlignez les données personnelles et sensibles, (2) décidez *envoyer / pseudonymiser / ne pas envoyer*, (3) réécrivez le prompt si nécessaire.

**Concrètement :** recopiez les trois prompts dans un document ; surlignez en jaune les données personnelles et en rouge les données sensibles ou les secrets d'affaires. Sous chaque prompt, écrivez l'un des trois mots (« envoyer », « pseudonymiser », « ne pas envoyer ») et une phrase qui justifie votre choix, en appliquant dans l'ordre la règle des 3 questions de la section 4. Pour réécrire, gardez l'objectif du message et remplacez ce qui identifie quelqu'un par « M. X », « le prospect », « le bien ».

- **Prompt A** : « Rédige un mail de relance à M. Dupuis, 06 12 34 56 78, pour la visite de l'appartement 3 rue des Lilas, il a dit qu'il hésitait à cause de son divorce. »
- **Prompt B** : « Voici notre grille de commissions 2026 [tableau collé] : propose une version plus lisible pour le site web. »
- **Prompt C** : « Rédige une annonce pour un T2 de 45 m² au 4e étage sans ascenseur, loyer 720 € charges comprises, quartier gare. »

**Critères de réussite.**
- Les données personnelles (nom, téléphone) et la donnée relevant de la vie privée (divorce) sont identifiées dans A.
- Le secret d'affaires (grille de commissions interne) est identifié dans B et l'envoi sur un compte gratuit est refusé ou conditionné.
- C est reconnu comme sans donnée personnelle : envoi possible.
- Le prompt A réécrit conserve l'objectif (relancer) sans les données.

<details>
<summary>Corrigé</summary>

- **A** : nom + téléphone = données personnelles ; « divorce » = information de vie privée inutile à la tâche (et potentiellement discriminante). Décision : **pseudonymiser**. Réécriture : « Rédige un mail de relance courtois à un prospect (M. X) qui a visité un appartement et hésite. Ton chaleureux, 120 mots, proposer un second créneau de visite. » Les coordonnées sont ajoutées **à la main** dans le client mail.
- **B** : aucune donnée personnelle, mais une **grille tarifaire interne** = secret d'affaires. Sur un compte gratuit : **ne pas envoyer**. Alternative : envoyer un tableau avec des valeurs fictives (« 3 %, 4 %, 5 % ») pour obtenir la mise en forme, puis remettre les vrais chiffres. Ou utiliser l'outil contractualisé de l'agence.
- **C** : description d'un bien, aucune personne identifiable : **envoyer**. Vigilance : l'annonce finale ne doit contenir aucun critère discriminatoire (leçon L030).
</details>

🎮 **Défi** — En 2 minutes, listez les cinq données personnelles que vous avez manipulées aujourd'hui au travail. Pour chacune : l'auriez-vous collée dans un assistant IA sans réfléchir il y a un mois ?

## ✅ Auto-évaluation express

1. Une adresse e-mail professionnelle du type `prenom.nom@entreprise.fr` est-elle une donnée personnelle ?
2. Quelle est la différence entre pseudonymiser et anonymiser ?
3. Qui est le responsable de traitement quand un salarié utilise un assistant IA pour son travail ?

<details>
<summary>Réponses</summary>

1. **Oui** : elle identifie directement une personne physique. Elle peut être traitée dans un cadre professionnel, mais elle reste soumise au RGPD.
2. La pseudonymisation remplace les identifiants par des codes **avec** une table de correspondance conservée (réversible, données toujours personnelles) ; l'anonymisation rend l'identification **irréversiblement impossible** (données non personnelles).
3. **L'employeur** (l'entreprise), qui décide des finalités et des moyens ; le salarié agit sous son autorité et doit respecter la charte.
</details>

> ✅ **Si vous ne retenez que 3 choses** — 1. Une donnée personnelle, c'est tout ce qui permet de reconnaître quelqu'un, même sans son nom (une fonction, un lieu, une situation). 2. Avant d'envoyer : personnes identifiables ? données sensibles ou secrets ? outil autorisé ? Et pseudonymisez par réflexe (« S1 », « Client A ») : le résultat est le même. 3. Jamais de données de santé, de secrets ou de mots de passe sur un compte gratuit ; utilisez les outils validés par l'entreprise et signalez sans attendre toute erreur.

## 📚 Pour aller plus loin
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) — les 15 fiches et la liste de vérification PDF (juillet 2025).
- [CNIL — IA : finalisation des recommandations](https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia) — synthèse des messages clés et des travaux à venir (secteurs, projet PANAME).
- [Anthropic — API and data retention](https://platform.claude.com/docs/en/manage-claude/api-and-data-retention) 🇬🇧 — durées de conservation et options, à lire avant de contractualiser.
- [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — modération, humain dans la boucle, révocation de clés.
- [Claude Academy — AI Fluency: Framework and foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations) 🇬🇧 — le « D » de Diligence du cadre 4D correspond à cette leçon.

> 🗺️ **Et maintenant ?** — Le RGPD protège les données ; l'AI Act encadre les systèmes d'IA eux-mêmes. La leçon L029 vous en donne les catégories de risque, le calendrier et l'obligation de formation, et complète la page 2 de votre charte.

