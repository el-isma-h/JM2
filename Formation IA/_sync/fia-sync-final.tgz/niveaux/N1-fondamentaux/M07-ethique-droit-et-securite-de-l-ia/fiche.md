---
module: M07
title: "Fiche mémo — Éthique, droit et sécurité de l'IA"
---
# Fiche mémo — M07 · Éthique, droit et sécurité de l'IA

> En une phrase : vérifiez l'enveloppe avant d'appeler le coursier (RGPD), conduisez selon la taille du véhicule (AI Act), ne faites dire à personne ce qu'il n'a pas dit (deepfakes), et limitez les pouvoirs de l'IA (sécurité).

## Les 7 idées à retenir
1. **Le RGPD n'interdit pas l'IA, il demande de réfléchir avant d'envoyer** : 3 questions — personnes identifiables ? données sensibles ou secrets ? outil autorisé ? (`L028`)
2. **Pseudonymiser par réflexe** : « Karim Benali » → « S1 » donne le même résultat sans risque. L'identification indirecte compte autant que le nom (`L028`).
3. **L'AI Act est une pyramide** : inacceptable (interdit) · haut risque (RH, crédit…) · risque limité (transparence) · minimal. Le même outil change d'étage selon l'usage (`L029`).
4. **L'article 4 vaut pour tous les employeurs** : former ses équipes, de façon proportionnée et tracée ; pas de certification obligatoire (`L029`).
5. **Droit d'auteur** : une sortie brute n'est pas protégée ; seule la part humaine documentée l'est. « Gratuit en ligne » ≠ libre de droits (`L030`).
6. **Deepfake** : consentement écrit + mention visible, sinon on ne publie pas. Et « l'IA propose, l'humain dispose » face aux biais (`L030`).
7. **Sécurité** : une IA obéit à tout ce qu'elle lit ; une clé d'API est une carte bancaire ; l'urgence est le signal d'une fraude ; le shadow AI se traite en offrant un outil officiel (`L031`).

## Le schéma à connaître

```mermaid
flowchart TB
  A["INACCEPTABLE (art. 5)<br/>notation sociale, émotions au travail<br/>→ interdit depuis le 2 févr. 2025"]
  B["HAUT RISQUE (annexes I et III)<br/>tri de CV, crédit, éducation<br/>→ annexe III au 2 déc. 2027"]
  C["RISQUE LIMITÉ (art. 50)<br/>chatbots, deepfakes, contenus générés<br/>→ transparence depuis le 2 août 2026"]
  D["RISQUE MINIMAL<br/>rédaction, anti-spam, traduction<br/>→ seulement l'article 4 (formation)"]
  A --> B --> C --> D
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Donnée sensible | Santé, opinions, religion, syndicat, orientation sexuelle, biométrie |
| Responsable de traitement | L'employeur, pas le salarié |
| Pseudonymiser / anonymiser | Codes + table gardée chez vous (réversible) / identification impossible (irréversible) |
| Fournisseur / déployeur | Le fabricant de la voiture / l'entreprise qui la conduit |
| Opt-out (TDM) | Le panneau « Défense d'entrer » pour les robots d'entraînement, valable pour l'avenir |
| Injection de prompt | Directe (tapée par l'utilisateur) ou indirecte (cachée dans un PDF, une page, un e-mail) |
| Shadow AI | L'IA utilisée sans validation de l'entreprise : un symptôme, pas une faute |

## Les pièges classiques
- « Pas de nom, donc pas de donnée personnelle » : « la seule comptable de Vierzon » identifie quelqu'un.
- « On ne fait que rédiger, l'AI Act ne nous concerne pas » : l'article 4 s'applique ; et trier des CV avec le même outil = haut risque.
- Intégrer un contenu CC BY-NC dans une formation vendue.
- « J'ai reconnu sa voix » : en 2026, une voix ou un visage en visio n'est plus une preuve.
- Croire qu'un modèle récent est sans biais : testez en changeant **une** variable (prénom, âge, quartier).

## Les commandes / chiffres / dates utiles
- **Mnémo dates AI Act « F-A-D-D »** : **F**évrier 2025 (interdits + art. 4) · **A**oût 2026 (transparence, sanctions, contrôle) · **D**écembre 2026 (interdiction des applis « nudifier » et du contenu pédopornographique) · **D**écembre 2027 (haut risque annexe III ; annexe I au 2 août 2028).
- Omnibus : règlement (UE) **2026/1744**, JOUE du 24 juillet 2026, en vigueur le 27 juillet 2026 ; l'article 4 demande désormais de **favoriser** la maîtrise de l'IA, l'obligation de former demeure.
- Amendes AI Act : 35 M€ ou 7 % (interdits) · 15 M€ ou 3 % (autres, dont art. 50) · 7,5 M€ ou 1 % (informations inexactes).
- Deepfake sans consentement diffusé en ligne : jusqu'à **2 ans et 45 000 €** (art. 226-8 du code pénal, loi SREN du 21 mai 2024).
- Violation de données : notification à la CNIL sous **72 h**. La CNIL publie des **fiches pratiques IA** (15 fiches numérotées de 1 à 13, plus une synthèse, une introduction et une liste de vérification).
- OWASP Top 10 LLM 2026 (4 août 2026), les 5 du bureau : **LLM01** injection · **LLM02** fuite d'informations · **LLM03** agentivité excessive · **LLM06** consommation non bornée · **LLM07** désinformation.
- Clés d'API : variable d'environnement, une clé par projet, quota + alerte, rotation, révocation immédiate.
- Fraude : **double canal** (rappel sur un numéro que vous choisissez) + **double validation** au-delà d'un seuil.

## Pour aller plus loin
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia)
- [EUR-Lex — Règlement (UE) 2024/1689](https://eur-lex.europa.eu/eli/reg/2024/1689/oj)
- [OWASP GenAI Security Project](https://genai.owasp.org/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Une caméra qui mesure la « motivation » des salariés par leurs expressions : quelle catégorie AI Act ?
2. Une image générée en un clic, sans retouche, est-elle protégée par le droit d'auteur ?
3. Un e-mail parfait de votre fournisseur annonce un nouvel IBAN : que faites-vous ?

---
**Réponses** — 1. Inacceptable : reconnaissance des émotions au travail, interdite depuis le 2 février 2025. 2. Non (art. L111-1 CPI) : seule une version retravaillée l'est, à hauteur des apports humains. 3. Ne pas répondre ; rappeler le fournisseur sur un numéro connu, bloquer le paiement, faire valider par une seconde personne.
