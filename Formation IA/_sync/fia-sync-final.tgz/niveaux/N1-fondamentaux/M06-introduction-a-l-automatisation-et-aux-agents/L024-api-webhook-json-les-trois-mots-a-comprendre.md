---
id: L024
module: M06
level: N1
title: "API, webhook, JSON : les trois mots à comprendre"
minutes: 40
objectives:
  - "Expliquer avec une analogie du quotidien ce qu'est une API, un webhook et un fichier JSON"
  - "Lire un petit document JSON et y repérer les clés, les valeurs et les listes"
  - "Distinguer une communication « à la demande » (API) d'une communication « sur événement » (webhook) dans un cas professionnel"
skills: ["C1.5"]
sources:
  - { title: "Claude Platform — API overview", url: "https://platform.claude.com/docs/en/api/overview", lang: "en" }
  - { title: "Claude Platform — Quickstart", url: "https://platform.claude.com/docs/en/get-started", lang: "en" }
  - { title: "OpenAI — API Quickstart", url: "https://developers.openai.com/api/docs/quickstart", lang: "en" }
  - { title: "n8n Academy — N8N102 Integrations: APIs & Connected Workflows", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about", lang: "en" }
  - { title: "Make Academy — catalogue (cours « Introduction to HTTP », « Webhooks »)", url: "https://academy.make.com/", lang: "en" }
  - { title: "JSON — présentation officielle (version française)", url: "https://www.json.org/json-fr.html", lang: "fr" }
---

# API, webhook, JSON : les trois mots à comprendre

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 6

## 🎯 Ce que vous saurez faire
- Expliquer à un collègue, sans jargon, ce qu'est une **API**, un **webhook** et un document **JSON**, avec une analogie pour chacun.
- Lire un document JSON de quelques lignes (une facture, une fiche client) et dire ce qu'il contient.
- Reconnaître, dans un processus de votre entreprise, les moments où un logiciel « demande » (API) et ceux où il « prévient » (webhook).

> 🧭 **En clair** — Pour que deux logiciels travaillent ensemble sans vous, il leur faut trois choses, comme dans un restaurant. Un **guichet** où l'un passe commande à l'autre : c'est l'API (le serveur qui prend votre commande). Une **sonnette** pour être prévenu quand quelque chose arrive : c'est le webhook (le bipeur qui vibre quand votre plat est prêt). Et une **langue commune** pour écrire la commande : c'est le JSON (le bon de commande standard que tout le monde sait lire). Avec ces trois mots, vous comprendrez n'importe quel outil d'automatisation et n'importe quel devis de prestataire.

## 1. Pourquoi ces trois mots, et pourquoi maintenant ?

Jusqu'ici, dans cette formation, vous avez dialogué avec l'IA **à la main** : vous tapez un prompt, vous lisez la réponse, vous copiez-collez. C'est efficace pour une tâche, c'est épuisant pour cent tâches par semaine. L'**automatisation** consiste à faire enchaîner ces tâches par des logiciels, sans vous, 24 h/24.

Or, pour que des logiciels se parlent, il faut trois choses : un **guichet** où l'un demande un service à l'autre (l'API), une **sonnette** pour qu'un logiciel en prévienne un autre qu'un événement vient de se produire (le webhook), et une **langue commune** (le JSON). Ces trois notions reviennent dans tous les outils que vous rencontrerez : n8n, Make, Zapier, (des logiciels d'automatisation « sans code », voir L025) les plateformes d'Anthropic, d'OpenAI ou de Mistral. Les comprendre, c'est pouvoir lire une documentation, dialoguer avec un prestataire et construire votre premier workflow (leçon suivante) — un workflow est un enchaînement automatique d'étapes.

> 💡 **À retenir** — Automatiser, c'est remplacer vos copier-coller par des échanges entre logiciels. API = demander, webhook = être prévenu, JSON = la langue de l'échange.

## 2. L'API : le guichet d'un logiciel

### 2.1 L'analogie du restaurant

Dans un restaurant, vous ne rentrez pas en cuisine pour préparer votre plat. Vous passez commande au serveur, à partir d'une **carte** qui liste ce qui est possible. Le serveur transmet, la cuisine prépare, le serveur revient avec l'assiette. Vous ne savez rien de la cuisine, et c'est tant mieux.

Une **API** (*Application Programming Interface*, interface de programmation) fonctionne exactement ainsi : c'est le **serveur** d'un logiciel. La **carte**, c'est la documentation de l'API : elle décrit les demandes possibles (« crée un contact », « envoie ce texte au modèle et renvoie-moi sa réponse », « donne-moi la météo de Lyon »), ce qu'il faut fournir, et ce que l'on reçoit en retour.

Quand vous utilisez Claude ou ChatGPT dans votre navigateur, vous passez par une interface graphique. Quand n8n, une application mobile ou le logiciel de votre comptable utilisent le même modèle, ils passent par l'API, c'est-à-dire par le guichet, sans écran. C'est pourquoi la documentation développeur d'Anthropic s'appelle « Claude Platform » et celle d'OpenAI « API docs » : ce sont les cartes du restaurant.

### 2.2 Comment se passe une commande (requête et réponse)

Une demande à une API est une **requête** envoyée sur Internet, le plus souvent avec le même protocole que votre navigateur, **HTTP** (la « langue » technique qu'utilise votre navigateur pour afficher les pages web). Elle comporte quatre éléments que vous retrouverez partout :

| Élément | Ce que c'est | Exemple (API Claude, nov. 2026) |
|---|---|---|
| L'**adresse** (*endpoint*) | « À quel guichet je m'adresse » | `https://api.anthropic.com/v1/messages` |
| Le **verbe** (*method*) | Ce que je veux faire : lire (`GET`), créer ou envoyer (`POST`), modifier (`PUT`/`PATCH`), supprimer (`DELETE`) | `POST` (j'envoie un message) |
| Les **en-têtes** (*headers*) | La carte d'identité de la demande, dont la **clé API** | `x-api-key: …` (ou `Authorization: Bearer …`, la forme utilisée par les SDK récents), `anthropic-version: 2026-10-21` |
| Le **corps** (*body*) | Le contenu de la demande, écrit en JSON | le modèle choisi et votre prompt |

En retour, l'API renvoie une **réponse** : un **code** à trois chiffres qui dit si tout s'est bien passé (`200` = OK ; `401` = clé invalide ; `429` = trop de demandes ; `500` = panne côté serveur), et un corps, lui aussi en JSON.

Voici une « commande » réelle, passée depuis un terminal avec l'outil `curl` (un petit outil qui envoie des requêtes en tapant une commande). Ne vous inquiétez pas si vous ne codez pas : lisez-la comme un bon de commande.

```bash
# La clé API est lue depuis une variable d'environnement, jamais écrite dans le code.
# Créez-la sur https://platform.claude.com/settings/keys puis : export ANTHROPIC_API_KEY="sk-ant-..."
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2026-10-21" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-haiku-5-5",
    "max_tokens": 200,
    "messages": [
      { "role": "user", "content": "Résume en une phrase : la réunion de lundi est reportée à jeudi 10 h." }
    ]
  }'
```

Ce que vous venez de lire : l'adresse, le verbe `POST` (implicite avec `-d`), trois en-têtes, et un corps JSON qui contient le modèle (`claude-haiku-5-5`, le plus économique des modèles Claude à 0,10 $ par million de tokens en entrée, nov. 2026) et votre message. La réponse reviendra elle aussi en JSON, avec le texte du résumé.

> 💡 **Autrement dit** — Une requête, c'est une lettre : l'**adresse** (à qui j'écris), le **verbe** (je demande, j'envoie, je modifie ou je supprime), l'**enveloppe** avec mon identité (les en-têtes, dont la clé API) et la **lettre** elle-même (le corps, en JSON). La réponse revient avec un code : `200` veut dire « bien reçu », `401` « je ne vous connais pas », `429` « pas si vite », `500` « nous avons un souci de notre côté ».

```quiz
{
  "q": "Votre automatisation reçoit le code 429 en appelant l'API Claude. Que signifie-t-il ?",
  "options": ["La clé API est invalide", "Trop de demandes envoyées en peu de temps", "Tout s'est bien passé", "Le modèle demandé n'existe pas en français"],
  "answer": 1,
  "explanation": "429 = trop de demandes (limite de débit atteinte). 200 = OK, 401 = clé invalide, 500 = panne côté serveur."
}
```

### 2.3 La clé API : votre carte de fidélité nominative

La **clé API** (*API key*) est une longue chaîne de caractères qui identifie **qui** passe la commande et **qui paie**. Avec Claude, OpenAI, Mistral ou xAI, chaque appel est facturé au nombre de tokens (nov. 2026 : de 0,10 $ à 10 $ par million de tokens en entrée selon le modèle). Une clé qui fuit, c'est un inconnu qui commande à vos frais.

> ⚠️ **Piège fréquent** — Copier une clé API dans un e-mail, un document partagé, un prompt ou un fichier déposé sur GitHub (un site où les développeurs partagent leur code, souvent publiquement). Règle d'or : la clé vit dans une **variable d'environnement** ou dans le coffre à identifiants (*credentials*) de votre outil d'automatisation, et nulle part ailleurs. Si vous avez un doute, révoquez-la et créez-en une nouvelle (« révoquer » = la désactiver, comme on fait opposition sur une carte bancaire) : c'est gratuit et immédiat.

> 🔗 **Documentation officielle** — [Claude Platform — Quickstart](https://platform.claude.com/docs/en/get-started) 🇬🇧 et [OpenAI — Quickstart](https://developers.openai.com/api/docs/quickstart) 🇬🇧 : les deux guides commencent exactement par la même étape, « créer une clé puis la mettre dans une variable d'environnement ».

```mission
{
  "title": "Le nom de la variable qui protège votre clé",
  "url": "https://platform.claude.com/docs/en/get-started",
  "steps": ["Ouvrez le Quickstart de Claude Platform", "Repérez l'étape « Set your API key » (définir votre clé)", "Notez le nom exact de la variable d'environnement utilisée dans les exemples"],
  "question": "Quel nom de variable d'environnement le Quickstart d'Anthropic utilise-t-il pour stocker la clé API ?",
  "hint": "Il est en majuscules et commence par le nom de l'entreprise.",
  "answer": "ANTHROPIC_API_KEY (Quickstart lu en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 3. Le webhook : la sonnette

### 3.1 « Ne m'appelez pas, je vous appelle »

Avec une API, c'est **vous** qui demandez. Mais comment savoir **quand** demander ? Imaginez que vous vouliez être averti dès qu'un client règle une facture. Première solution : interroger l'API de votre outil de facturation toutes les minutes (« y a-t-il un nouveau paiement ? Et maintenant ? Et maintenant ? »). C'est le **polling**, l'équivalent de l'enfant qui demande « on est arrivés ? » toutes les trente secondes. Cela fonctionne, mais c'est lent et gaspilleur.

Deuxième solution : vous donnez à votre outil de facturation une **adresse** où il doit **vous prévenir** à chaque paiement. C'est le **webhook** : une sonnette. Dès que l'événement survient, l'outil envoie de lui-même une requête HTTP (en général `POST`, avec un corps JSON décrivant l'événement) vers l'adresse que vous avez fournie. Votre automatisation se réveille, et seulement à ce moment-là.

```
   API (à la demande)                       WEBHOOK (sur événement)
   ──────────────────                       ───────────────────────
   Vous ──« un nouveau paiement ? »──▶ Outil      Outil ──« paiement reçu ! »──▶ Vous
   Vous ◀──« non »─────────────────── Outil             (seulement quand ça arrive)
   Vous ──« et maintenant ? »────────▶ Outil
   Vous ◀──« non »─────────────────── Outil
```

### 3.2 Où trouve-t-on des webhooks ?

Presque partout : une boutique en ligne qui prévient d'une commande, un formulaire de contact qui prévient d'une réponse, un outil de signature électronique qui prévient qu'un contrat est signé, un agenda qui prévient d'un rendez-vous annulé. Dans n8n, le nœud **Webhook Trigger** (étudié dans le cours N8N102 de la n8n Academy) crée justement une adresse unique que vous collez dans l'outil émetteur ; dans Make, le module « Webhooks » joue le même rôle. Les plateformes d'IA elles-mêmes en proposent : la documentation des Managed Agents d'Anthropic comporte une page « Webhooks » pour être prévenu des événements d'un agent, et l'API Claude propose des *organization webhooks* (bêta, oct. 2026).

| | API | Webhook |
|---|---|---|
| Qui prend l'initiative ? | Vous (ou votre workflow) | L'autre logiciel |
| Quand ? | Quand vous le décidez | Quand l'événement se produit |
| Analogie | Passer commande au guichet | La sonnette / la notification |
| Exemple métier | « Donne-moi la liste des factures impayées » | « Une facture vient d'être payée » |
| Dans n8n | Nœud **HTTP Request** | Nœud **Webhook Trigger** |

> 💡 **À retenir** — Une API et un webhook utilisent la même technique (une requête HTTP avec du JSON). La différence est le **sens de l'initiative** : l'API répond à vos questions, le webhook vous prévient.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : quand votre outil de signature électronique prévient n8n qu'un contrat vient d'être signé, c'est un webhook.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. L'initiative vient de l'autre logiciel, au moment où l'événement se produit : c'est la sonnette, donc un webhook. Si n8n allait lui-même demander « y a-t-il un contrat signé ? », ce serait un appel d'API (du polling)."
}
```

## 4. JSON : la langue commune

### 4.1 Une fiche de renseignements que tout le monde sait lire

Pour qu'un logiciel de facturation français, un modèle d'IA américain et un outil d'automatisation allemand se comprennent, il leur faut un format d'échange universel. Ce format, c'est **JSON** (*JavaScript Object Notation*), un texte structuré, lisible par un humain et par n'importe quel langage de programmation. Le site officiel [json.org](https://www.json.org/json-fr.html) 🇫🇷 tient en une page : c'est l'un des standards les plus simples de l'informatique.

Pensez à une **fiche de renseignements** : des rubriques (les **clés**) et ce que l'on écrit en face (les **valeurs**). Voici une facture en JSON :

```json
{
  "numero": "F-2026-0417",
  "client": {
    "nom": "Boulangerie Martin",
    "ville": "Tours",
    "siren": "123456789"
  },
  "lignes": [
    { "designation": "Site vitrine", "quantite": 1, "prix_ht": 1800.00 },
    { "designation": "Maintenance annuelle", "quantite": 12, "prix_ht": 49.00 }
  ],
  "total_ht": 2388.00,
  "payee": false,
  "date_echeance": "2026-11-30"
}
```

### 4.2 Les cinq règles pour le lire

1. Les **accolades** `{ }` délimitent un **objet** : un ensemble de couples `"clé": valeur`, séparés par des virgules. Ici, la facture entière est un objet, et `client` en contient un autre (on dit qu'il est **imbriqué**).
2. Les **crochets** `[ ]` délimitent une **liste** (un *array*) : `lignes` contient deux lignes de facture, chacune étant elle-même un objet.
3. Les **clés** sont toujours entre guillemets doubles. Les **textes** aussi (`"Tours"`).
4. Les **nombres** s'écrivent sans guillemets, avec un **point** décimal (`1800.00`, jamais `1 800,00`). C'est le piège numéro un pour les francophones.
5. Trois valeurs spéciales : `true`, `false` (vrai/faux, sans guillemets) et `null` (absence de valeur).

Pour désigner une information précise, on suit le chemin des clés : « le nom du client » se note `client.nom` ; « le prix de la première ligne » se note `lignes[0].prix_ht` (on compte à partir de zéro). Vous retrouverez cette notation dans les **expressions** de n8n, par exemple `{{ $json.client.nom }}`, étudiées dans la leçon suivante.

> ⚠️ **Piège fréquent** — Un JSON mal formé (une virgule en trop après le dernier élément, un guillemet simple à la place d'un double, une virgule décimale) est **rejeté en bloc** par le logiciel qui le reçoit. Quand une automatisation « ne marche pas », la première chose à vérifier est la validité du JSON ; la plupart des outils (n8n, VS Code, le site json.org) signalent l'erreur et sa ligne.

```quiz
{
  "q": "Lequel de ces extraits JSON est valide ?",
  "options": ["{ 'ville': 'Tours', 'payee': false }", "{ \"total_ht\": 1 800,00, \"payee\": false }", "{ \"payee\": false, \"total_ht\": 1800.00 }", "{ \"nom\": \"Martin\", \"ville\": \"Tours\", }"],
  "answer": 2,
  "explanation": "Guillemets doubles obligatoires (pas de guillemets simples), point décimal sans espace, booléen sans guillemets, et aucune virgule après le dernier élément."
}
```

```mission
{
  "title": "La grammaire officielle de JSON",
  "url": "https://www.json.org/json-fr.html",
  "steps": ["Ouvrez la page officielle de JSON en français", "Repérez le schéma qui décrit ce qu'est une « valeur »", "Listez toutes les formes qu'une valeur peut prendre"],
  "question": "Quels sont les sept types de valeurs autorisés en JSON ?",
  "hint": "Il y en a deux qui contiennent d'autres valeurs, deux « simples », et trois mots réservés.",
  "answer": "Une chaîne de caractères, un nombre, un objet, un tableau (liste), true, false et null.",
  "xp": 10
}
```

### 4.3 Pourquoi les modèles d'IA adorent le JSON

Un modèle de langage produit du texte libre : parfait pour un e-mail, inutilisable pour un logiciel qui attend un montant et une date. D'où les **sorties structurées** (*structured outputs*) : on donne au modèle le « formulaire » JSON attendu et il le remplit, sans phrase autour. Retenez que JSON est la **passerelle entre le monde de l'IA et le monde des logiciels** ; la pratique viendra au niveau 2.

> 🔗 **Documentation officielle** — [Claude Platform — Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧 · [OpenAI — Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs) 🇬🇧.

## 5. Les trois mots dans un même processus

Prenons un cabinet d'expertise comptable qui reçoit les notes de frais de ses clients.

```
1. Le client dépose sa note de frais dans un formulaire en ligne.
   └─▶ Le formulaire PRÉVIENT n8n : WEBHOOK (corps JSON : nom, montant, photo du ticket)
2. n8n DEMANDE à Claude de lire le ticket et d'en extraire date, montant, TVA.
   └─▶ API d'Anthropic ; réponse en JSON structuré
3. n8n DEMANDE au logiciel comptable de créer l'écriture.
   └─▶ API du logiciel comptable ; corps JSON
4. Si le montant dépasse 500 €, n8n envoie un e-mail à l'expert-comptable pour validation.
   └─▶ API de la messagerie (Gmail, Outlook…)
```

Quatre échanges, trois mots, et aucune ligne de code : dans n8n ou Make, vous reliez des blocs qui parlent API, webhook et JSON à votre place. Mais sans ces trois mots, vous ne comprendriez ni les blocs, ni leurs erreurs, ni le devis d'un prestataire.

🎮 **Défi** — Dans la liste suivante, qui est l'API, qui est le webhook ? (a) Votre banque vous envoie une notification « paiement de 42 € chez Carrefour ». (b) Vous ouvrez l'application pour consulter votre solde. (c) Votre site de e-commerce prévient votre transporteur qu'une commande est à expédier. (d) Votre tableau de bord interroge chaque matin les ventes de la veille. *(Réponses : a et c = webhook ; b et d = API.)*

## 🧪 Exercice pratique

**Consigne.** Choisissez un processus réel de votre travail qui implique au moins deux logiciels (exemples : réception d'une candidature, commande fournisseur, demande de congés, prise de rendez-vous). Produisez un document d'une page contenant :

**Concrètement :** un document d'une page, rien à installer. ① Le schéma peut être une simple liste numérotée avec des flèches : « 1. Le candidat remplit le formulaire → WEBHOOK vers l'outil RH ». ② Pour le JSON, partez de l'exemple de facture (section 4.1) ou du corrigé, et remplacez les clés par celles de votre objet. ③ Pour tester votre JSON sans rien installer, collez-le dans une conversation Claude ou ChatGPT avec la consigne « Ce JSON est-il valide ? Signale chaque erreur et sa ligne, sans le corriger » — en n'y mettant que des données fictives.

1. Le schéma du processus en 3 à 5 étapes, en indiquant pour chaque flèche s'il s'agit d'un **webhook** (événement) ou d'un **appel d'API** (demande).
2. Un document **JSON** de 8 à 15 lignes décrivant l'objet qui circule (la candidature, la commande, la demande…) avec au moins : un objet imbriqué, une liste, un nombre, un booléen (`true`/`false`).
3. Une phrase indiquant où serait stockée la clé API, et qui dans l'entreprise devrait y avoir accès.

**Critères de réussite.**
- Les flèches sont correctement qualifiées (l'initiative est du bon côté).
- Le JSON est valide : testez-le en le collant dans un validateur (le nœud *Edit Fields* de n8n, ou un éditeur de code) ; aucune virgule décimale, aucune virgule finale.
- Le chemin vers une valeur imbriquée est écrit en notation pointée (ex. `candidat.email`).

<details>
<summary>Corrigé indicatif (demande de congés)</summary>

Schéma : (1) le salarié remplit le formulaire → **webhook** vers n8n ; (2) n8n **demande** au SIRH le solde de congés (le logiciel de gestion du personnel) (API, `GET`) ; (3) n8n **demande** à Claude de rédiger la réponse (API, `POST`) ; (4) n8n **demande** à la messagerie d'envoyer l'e-mail au manager (API, `POST`).

```json
{
  "id": "CONGE-2026-118",
  "salarie": { "nom": "Dupont", "prenom": "Lina", "email": "l.dupont@exemple.fr" },
  "periode": { "debut": "2026-12-22", "fin": "2026-12-31" },
  "jours_ouvres": 7,
  "type": "CP",
  "solde_suffisant": true,
  "pieces_jointes": []
}
```

Chemin : `salarie.email`, `periode.debut`. Clé API : dans le coffre à identifiants de n8n, accessible au seul administrateur de l'instance.

</details>

## ✅ Auto-évaluation express

1. Quelle est la différence d'initiative entre une API et un webhook ?
2. Dans le JSON de la facture ci-dessus, comment désigner la ville du client ? Et le prix de la deuxième ligne ?
3. Pourquoi faut-il écrire `1800.00` et non `1 800,00` dans un JSON ?

<details>
<summary>Réponses</summary>

1. Avec une API, c'est vous (ou votre workflow) qui demandez ; avec un webhook, c'est l'autre logiciel qui vous prévient quand un événement se produit.
2. `client.ville` ; `lignes[1].prix_ht` (la numérotation commence à 0).
3. JSON impose le point décimal et interdit les espaces dans les nombres ; `1 800,00` serait rejeté comme invalide.

</details>

> ✅ **Si vous ne retenez que 3 choses** — 1. API = je demande (le guichet) ; webhook = on me prévient quand quelque chose arrive (la sonnette) ; JSON = la fiche commune que tous les logiciels savent lire. 2. Un JSON se lit comme une fiche « rubrique : valeur » : accolades pour un objet, crochets pour une liste, guillemets doubles, point décimal (jamais de virgule dans un nombre). 3. Une clé API est comme une carte bancaire : jamais dans un e-mail, un document partagé ou un prompt ; en cas de doute, on la révoque.

## 📚 Pour aller plus loin
- [Claude Platform — API overview](https://platform.claude.com/docs/en/api/overview) 🇬🇧 — la « carte du restaurant » d'Anthropic : adresses, en-têtes, versions, codes d'erreur.
- [OpenAI — API Quickstart](https://developers.openai.com/api/docs/quickstart) 🇬🇧 — même logique, autre fournisseur : clé, variable d'environnement, premier appel.
- [n8n Academy — N8N102 Integrations: APIs & Connected Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about) 🇬🇧 — le cours gratuit qui approfondit GET/POST, clés API, OAuth2 et Webhook Trigger (4-6 h, badge à la clé).
- [Make Academy](https://academy.make.com/) 🇬🇧 — cours gratuits « Introduction to HTTP » et « Webhooks » (niveau Intermediate), badges Credly.
- [JSON — site officiel en français](https://www.json.org/json-fr.html) 🇫🇷 — la grammaire complète de JSON en une page.

> 🗺️ **Et maintenant ?** — Vous connaissez le vocabulaire ; dans la leçon L025, vous ouvrez n8n et construisez votre premier workflow, où ces trois mots deviennent des blocs à relier.

