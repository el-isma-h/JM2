---
module: M06
title: "Fiche mémo — Introduction à l'automatisation et aux agents"
---
# Fiche mémo — M06 · Introduction à l'automatisation et aux agents

> En une phrase : automatiser, c'est faire parler des logiciels entre eux (API, webhook, JSON) ; un workflow suit une recette, un agent choisit ses outils, et MCP est la prise universelle qui les branche.

## Les 7 idées à retenir
1. **Trois mots, un restaurant** : l'API est le serveur (on lui passe commande), le webhook le bipeur (il vous prévient), le JSON le bon de commande (la langue commune) (`L024`).
2. **La clé API = votre carte bancaire** : elle identifie qui commande et qui paie ; elle vit dans un coffre (*credentials*), jamais dans un e-mail ou un prompt (`L024`).
3. **n8n = des dominos** : un déclencheur fait tomber les nœuds suivants ; les données circulent en *items* JSON (`L025`).
4. **Expressions** : `{{ $json.avis }}` insère la valeur reçue du nœud précédent, à condition d'être en mode *Expression* (`L025`).
5. **Chatbot, workflow, agent** : vous décidez à chaque message / une fois pour toutes / le modèle décide au fil de l'eau (`L026`).
6. **La boucle de l'agent** : raisonner → agir (outil) → observer → décider ; avec garde-fous (droits limités, budget, validation humaine avant l'irréversible). Commencez par le plus simple (`L026`).
7. **MCP = l'USB-C de l'IA** : hôte, client, serveur ; un serveur expose outils, ressources et prompts. MCP relie agent ↔ outils, A2A relie agent ↔ agent (`L027`).

## Le schéma à connaître

```mermaid
flowchart LR
  F["Formulaire en ligne"] -- "WEBHOOK : il prévient" --> N["n8n"]
  N -- "API : je demande d'extraire" --> C["Claude"]
  C -- "réponse JSON" --> N
  N -- "API : je crée l'écriture" --> L["Logiciel comptable"]
  N -- "si plus de 500 € : validation humaine" --> E["Expert-comptable"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Endpoint / verbe | L'adresse du guichet / ce qu'on veut faire (`GET` lire, `POST` envoyer, `DELETE` supprimer) |
| Objet `{ }` / liste `[ ]` | Une fiche (clés + valeurs) / une pile de fiches |
| Déclencheur (*trigger*) | Le premier domino : une heure, un webhook, un e-mail, un formulaire |
| Item | Une fiche JSON qui passe de nœud en nœud |
| Outil (*tool*) | Un commis que l'agent fait travailler via un petit bon de commande JSON |
| Human in the loop | Votre feu vert avant d'envoyer, payer ou supprimer |
| Serveur MCP | L'accessoire branché qui dit « voici ce que je sais faire » |
| Skill (`SKILL.md`) | La fiche de procédure : *comment* faire (MCP donne *les moyens* de faire) |

## Les pièges classiques
- JSON invalide : virgule décimale (`1 800,00`), virgule finale, guillemets simples. Le JSON est rejeté en bloc.
- Oublier `GENERIC_TIMEZONE` en auto-hébergement : votre « lundi 8 h » tombe à l'heure UTC.
- Laisser un champ n8n en mode *Fixed* : le modèle reçoit le texte `{{ $json.avis }}` et « ne voit aucun avis ».
- Croire qu'un agent connaît l'entreprise : sans outil vers le CRM, il invente des clients.
- Brancher « tous les serveurs MCP » : un bon agent a trois outils bien choisis, pas trente.
- Ignorer l'injection de prompt : un e-mail lu peut contenir un faux ordre. Jamais d'envoi sortant sans accord.

## Les commandes / chiffres / dates utiles
- **Codes HTTP, mnémo « 200 OK, 401 inconnu, 429 trop vite, 500 panne chez eux »**.
- Chemins JSON : `client.nom`, `lignes[0].prix_ht` (on compte à partir de 0).
- n8n : `docker compose up -d` → `http://localhost:5678` ; Schedule Trigger → Edit Fields → Basic LLM Chain + Anthropic Chat Model → Gmail ; *Execute workflow* = test, *Active* = production. Cron lun-ven 18 h : `0 18 * * 1-5`.
- **n8n 3.0** (27 oct. 2026) apporte des changements incompatibles : vérifiez la version installée. Certification officielle n8n : **pas encore lancée** au 5 nov. 2026 ; la n8n Academy délivre des certificats d'achèvement (N8N101, 102, 103).
- 3 questions avant de brancher un serveur MCP : **qui** l'a écrit ? **quels droits** ? et si une donnée lue contient une **consigne piégée** ?
- MCP : publié en nov. 2024 par Anthropic, géré par la Linux Foundation ; version stable actuelle **2026-07-28** (protocole sans état), précédente 2025-11-25. Transports : *stdio* (local) et *Streamable HTTP* (distant).

## Pour aller plus loin
- [n8n Academy — N8N101 Essentials: Your First Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N101+2026H2/about)
- [Claude Academy — Introduction to Model Context Protocol](https://academy.claude.com/courses/introduction-to-model-context-protocol)
- [JSON — site officiel en français](https://www.json.org/json-fr.html)

## Auto-test (3 questions — réponses en bas de fiche)
1. Votre banque vous notifie un paiement de 42 € : API ou webhook ?
2. Que fait réellement un modèle quand il « appelle un outil » ?
3. Une PME veut un agent qui relance seul les impayés par e-mail : quelle configuration pour démarrer ?

---
**Réponses** — 1. Webhook : c'est l'autre logiciel qui prend l'initiative. 2. Il produit une demande JSON (nom de l'outil + paramètres) ; votre logiciel l'exécute et lui renvoie le résultat. 3. Lecture seule sur facturation et CRM, rédaction par l'agent, envoi uniquement après validation humaine.
