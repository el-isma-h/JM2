---
id: L009
module: M02
level: N1
title: "Panorama des modèles 2026 : Claude, GPT, Gemini, Grok, Mistral, Llama, DeepSeek, Qwen"
minutes: 50
objectives:
  - "Situer les huit grandes familles de modèles de novembre 2026 (éditeur, pays, modèle phare, ouvert ou fermé, ordre de prix)"
  - "Distinguer modèle fermé (API) et modèle à poids ouverts, et lire une licence (Apache 2.0, MIT, licences communautaires)"
  - "Lire un classement (LMArena, Artificial Analysis) avec recul et choisir un modèle à partir d'une grille de cinq critères"
skills: ["C1.1", "C1.2"]
sources:
  - { title: "Anthropic — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Anthropic — Choosing a model", url: "https://platform.claude.com/docs/en/about-claude/models/choosing-a-model", lang: "en" }
  - { title: "OpenAI — Models", url: "https://developers.openai.com/api/docs/models", lang: "en" }
  - { title: "OpenAI — Pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "xAI — Models", url: "https://docs.x.ai/developers/models", lang: "en" }
  - { title: "Google — Gemini API pricing", url: "https://ai.google.dev/gemini-api/docs/pricing", lang: "en" }
  - { title: "Mistral AI — Models overview", url: "https://docs.mistral.ai/getting-started/models/", lang: "en" }
  - { title: "Mistral AI — Pricing", url: "https://docs.mistral.ai/inference/pricing", lang: "en" }
  - { title: "Artificial Analysis — Leaderboards", url: "https://artificialanalysis.ai/leaderboards/models", lang: "en" }
  - { title: "Hugging Face — Open-source LLMs to run locally (mai 2026)", url: "https://huggingface.co/blog/daya-shankar/open-source-llm-models-to-run-locally", lang: "en" }
---

# Panorama des modèles 2026 : Claude, GPT, Gemini, Grok, Mistral, Llama, DeepSeek, Qwen

> ⏱ 50 min · 🎯 Niveau 1 · 📚 Module 2

## 🎯 Ce que vous saurez faire
- Nommer, pour chaque grand éditeur, le modèle phare de novembre 2026, son ordre de prix et son statut (fermé ou ouvert).
- Expliquer la différence entre « j'appelle une API » et « je télécharge les poids », et pourquoi une entreprise française peut préférer l'un ou l'autre.
- Décoder une licence de modèle ouvert et repérer les pièges (seuils de revenus, usages interdits).
- Lire un classement sans vous faire piéger, et choisir un modèle avec une grille en cinq questions.

> 🧭 **En clair** — Choisir un modèle d'IA, c'est un peu comme choisir une voiture. Vous pouvez **la louer** avec chauffeur (les modèles « fermés » comme Claude, GPT ou Gemini, utilisés via une application ou un abonnement) ou **l'acheter et la garder dans votre garage** (les modèles « ouverts », que l'on télécharge et fait tourner sur ses propres machines). Il existe des citadines économiques pour les petits trajets (trier, résumer) et des berlines haut de gamme pour les longs voyages (analyser, raisonner) — avec des prix qui vont de 1 à 100. Les classements sont comme les essais des magazines automobiles : utiles, mais rien ne remplace votre propre essai sur vos trajets à vous.

> ⚠️ Tous les chiffres de cette leçon sont **datés de novembre 2026** et proviennent des pages officielles de tarifs et de modèles (liens en fin de leçon). Ils changent plusieurs fois par an : vérifiez avant tout devis.

## 1. Le marché en deux mots : fermé ou ouvert

Il existe deux façons d'accéder à un modèle :

- **Modèle fermé** (*closed / proprietary*) : l'éditeur héberge le modèle et vous le louez via une interface (claude.ai, ChatGPT…) ou une **API**, facturée au million de tokens. Vous ne voyez jamais les poids. Exemples : Claude, GPT-6, Gemini 4, Grok 4.7.
- **Modèle à poids ouverts** (*open weights*) : l'éditeur publie le fichier de paramètres (L005), généralement sur Hugging Face (le grand site de partage de modèles d'IA, une sorte de bibliothèque publique des modèles). Vous pouvez le télécharger, le faire tourner sur vos machines, le modifier. Exemples : Mistral Small 4, Gemma 4 (Google), gpt-oss (OpenAI), Llama 4 (Meta), DeepSeek V4.1, Qwen3.8 (Alibaba), Kimi K3 (Moonshot).

Trois nuances importantes :
1. « Ouvert » ne veut pas dire « gratuit à faire tourner » : il faut du matériel (Niveau 2).
2. « Ouvert » ne veut pas toujours dire « open source » (code et recettes publiés, réutilisables librement) au sens strict : tout dépend de la **licence** (section 4).
3. Les meilleurs modèles ouverts sont aussi proposés **en API** par des hébergeurs (Mistral, Hugging Face Inference Providers, Perplexity Agent API, etc.) : vous pouvez les louer comme un modèle fermé, souvent moins cher.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un modèle « à poids ouverts » peut être téléchargé librement, mais le faire tourner demande du matériel (ou un hébergeur payant), et sa licence peut imposer des conditions d'usage commercial.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai. « Ouvert » ne veut pas dire « gratuit à faire tourner » ni « sans conditions » : il faut des machines adaptées, et certaines licences « communautaires » fixent des seuils ou des usages interdits."
}
```

## 2. Les éditeurs et leurs modèles phares (nov. 2026)

### 2.1 Anthropic (États-Unis) — Claude
Quatre modèles actifs, tous avec un contexte de 1 million de tokens et une sortie maximale de 128 000 tokens :

| Modèle | Sortie | Prix entrée / sortie ($ par M tokens) | Positionnement |
|---|---|---|---|
| Claude Fable 5.1 | 1er sept. 2026 | 10 / 50 | Haut de gamme, raisonnement toujours actif |
| Claude Opus 5.5 | 22 sept. 2026 | 4 / 20 | Modèle « frontier » polyvalent |
| Claude Sonnet 5.5 | 28 sept. 2026 | 2 / 10 | Le rapport qualité/prix le plus utilisé |
| Claude Haiku 5.5 | 7 oct. 2026 | 0,10 / 0,50 (jusqu'à 100 k tokens) | Rapide et économique : tri, extraction, chat à volume |

> 💡 **Autrement dit** — Comment lire ce tableau : « 10 / 50 » veut dire 10 $ pour un million de tokens envoyés au modèle et 50 $ pour un million de tokens qu'il vous renvoie ; « 100 k » = 100 000 (k pour « kilo », mille) ; « frontier » = à la pointe. Plus le modèle est haut de gamme, plus il est cher. Pour toute la section 2, ne cherchez pas à tout mémoriser : retenez, pour chaque éditeur, un nom de modèle et s'il est fermé ou ouvert.

Un cinquième modèle, Claude Mythos 5.1, a les mêmes caractéristiques que Fable 5.1 mais est réservé aux organisations vérifiées (programme de vérification cyber). Anthropic ne publie **aucun** modèle à poids ouverts.

### 2.2 OpenAI (États-Unis) — GPT-6 et gpt-oss
La famille **GPT-6** (contexte 1,05 M, sortie 128 k) : GPT-6 Astra (10 / 50 $), GPT-6.1 Sol (2 / 10 $), GPT-6.1 Terra (1 / 5 $), GPT-6 Luna (0,10 / 0,50 $). Vous remarquerez que la grille est **calquée sur celle d'Anthropic** : la concurrence a aligné les prix. OpenAI publie aussi, depuis août 2025, deux modèles ouverts sous licence Apache 2.0 (une licence très permissive, expliquée en section 4), **gpt-oss-20b** (tourne en 16 Go de mémoire) et **gpt-oss-120b**.

### 2.3 Google (États-Unis) — Gemini et Gemma
**Gemini 4 Argon** est le modèle phare fermé (2 / 10 $, hausse annoncée à 4 / 20 $ au 1er décembre 2026), **Gemini 3.8 Flash** le modèle économique (0,75 / 3,75 $, avec un niveau gratuit), tous deux multimodaux (texte, image, vidéo, audio, PDF). Côté ouvert, la famille **Gemma 4** (avril 2026, Apache 2.0) va de modèles minuscules pour téléphone (E2B, E4B) à un 31B classé parmi les meilleurs ouverts.

### 2.4 xAI (États-Unis) — Grok
**Grok 4.7** (2 / 6 $, contexte 500 k, doublement du prix au-delà de 200 k tokens) ; intégré au réseau social X, avec un outil de recherche dans les publications X. Pas de poids ouverts pour les modèles récents.

### 2.5 Mistral AI (France) — Large, Small, Ministral
L'acteur européen de référence, basé à Paris. **Mistral Large 4** (0,70 / 2,10 $, multimodal) en API ; **Mistral Small 4** (119B dont 6B actifs, Apache 2.0, 0,15 / 0,60 $ en API) fusionne raisonnement, code et vision ; **Ministral 3** (3B, 8B, 14B, Apache 2.0) pour l'embarqué et le français natif (l'« embarqué » = une IA intégrée dans un appareil : téléphone, voiture, machine). Mistral propose une inférence régionale en Europe (les calculs sont faits dans des centres de données situés en Europe) et des outils de transcription (Voxtral) et d'OCR. Pour une entreprise française soucieuse de souveraineté des données (garder ses données sous juridiction européenne, à l'abri des lois étrangères), c'est souvent le premier nom à examiner.

### 2.6 Meta (États-Unis) — Llama, puis Muse
**Llama** a lancé le mouvement des poids ouverts (Llama 2 en 2023, Llama 3 en 2024, Llama 4 Scout/Maverick en avril 2025 avec un contexte annoncé jusqu'à 10 M de tokens). Depuis avril 2026, Meta a basculé sur la famille **Muse** ; **Muse Spark Open** (816B dont 42B actifs, octobre 2026) est publié sous une licence « Muse Model License » assortie de conditions (section 4). Llama 3.1 8B reste le modèle de référence des tests matériels.

### 2.7 DeepSeek (Chine)
Le choc de janvier 2025 (DeepSeek R1, un modèle de raisonnement ouvert au niveau des meilleurs fermés) a durablement changé le marché. En 2026, **DeepSeek V4.1 Flash** (552B dont 8 à 16B actifs, contexte 1 M, licence **MIT**) et **DeepSeek V4 Pro** (1,6T dont 49B actifs) sont parmi les meilleurs modèles ouverts, à des prix API très bas (V4.1 Flash chez Mistral : 0,30 / 1,20 $).

### 2.8 Alibaba (Chine) — Qwen
**Qwen3.8** (août 2026) : du **Qwen3.8-27B** (Apache 2.0, vision native, « meilleur rapport qualité par gigaoctet » selon les tests de modèles locaux) jusqu'à Qwen3.8-Max (2,4T dont 95B actifs, licence spécifique). Qwen est la famille la plus déclinée en tailles et la plus utilisée pour les déploiements locaux.

### 2.9 Et aussi
**Moonshot AI** (Kimi K3, 2,8T dont 104B actifs, meilleur ouvert sur LMArena fin octobre 2026), **Z.ai** (GLM-5.3), **MiniMax** (M3), **NVIDIA** (Nemotron 3), **IBM** (Granite 4.2, Apache 2.0, orienté entreprise), **Microsoft** (Phi-4, MIT), **Hugging Face** (SmolLM3, « entièrement ouvert » : données et recettes publiées).

> 💡 **À retenir** — Trois pays dominent : États-Unis (Anthropic, OpenAI, Google, xAI, Meta), Chine (DeepSeek, Alibaba, Moonshot, Z.ai, MiniMax) et France (Mistral). Les Américains dominent le fermé ; les Chinois dominent l'ouvert ; Mistral est le seul acteur européen de premier plan.

```quiz
{
  "type": "mise_en_situation",
  "q": "Une PME française veut un modèle performant, si possible hébergé en Europe et proposé par un éditeur européen. Quel nom examine-t-elle en premier ?",
  "options": [
    "Grok (xAI)",
    "DeepSeek",
    "Mistral AI",
    "Kimi (Moonshot)"
  ],
  "answer": 2,
  "explanation": "Mistral AI, basé à Paris, est le seul acteur européen de premier plan ; il propose une inférence régionale en Europe et plusieurs modèles sous licence ouverte Apache 2.0."
}
```

## 3. Tableau comparatif des modèles phares

| Famille | Modèle phare | Fermé / ouvert | Contexte | Prix entrée / sortie ($/M tokens, nov. 2026) | Cutoff |
|---|---|---|---|---|---|
| Claude | Opus 5.5 | Fermé | 1 M | 4 / 20 | juin 2026 |
| Claude | Sonnet 5.5 | Fermé | 1 M | 2 / 10 | juin 2026 |
| GPT | GPT-6 Astra | Fermé | 1,05 M | 10 / 50 | 30 avr. 2026 |
| GPT | GPT-6.1 Sol | Fermé | 1,05 M | 2 / 10 | 30 avr. 2026 |
| Gemini | Gemini 4 Argon | Fermé | 1 M | 2 / 10 (→ 4 / 20 au 1er déc.) | n. p. |
| Grok | Grok 4.7 | Fermé | 500 k | 2 / 6 | mai 2026 |
| Mistral | Large 4 | Fermé (poids annoncés) | n. p. | 0,70 / 2,10 | n. p. |
| Mistral | Small 4 | **Ouvert** (Apache 2.0) | 256 k | 0,15 / 0,60 (API Mistral) | n. p. |
| DeepSeek | V4.1 Flash | **Ouvert** (MIT) | 1 M | 0,30 / 1,20 (API Mistral) | n. p. |
| Qwen | Qwen3.8-27B | **Ouvert** (Apache 2.0) | 262 k | gratuit en local | n. p. |
| Llama / Muse | Muse Spark Open | **Ouvert** (licence Muse) | 1 M | gratuit en local | n. p. |

*n. p. = non publié sur les pages consultées.* Les écarts de prix vont de 1 à 100 entre un petit modèle et un modèle haut de gamme : choisir le bon modèle pour chaque tâche est le premier levier d'économie.

## 4. Lire une licence de modèle ouvert

| Famille de licence | Exemples | Usage commercial | Pièges |
|---|---|---|---|
| **Apache 2.0 / MIT** (reconnues par l'OSI) — l'*Open Source Initiative*, l'organisme qui définit ce qu'est l'open source | Qwen3.8-27B, Gemma 4, gpt-oss, Mistral Small 4, DeepSeek (MIT), Granite, Phi, SmolLM3 | Libre | Aucun (hors usage des marques) |
| **Licences « communautaires »** | Llama 4 Community, Muse Model License, Kimi K3 License, Qwen3.8-Max, GLM-5.3 | Oui, **sous conditions** : seuils de chiffre d'affaires (20 M$ pour Muse et Kimi K3), mention obligatoire (« Built with… »), usages interdits | Non reconnues « open source » par l'OSI ; à faire relire par un juriste avant un produit commercial |
| **Non commerciales** (CC BY-NC…) | Certains modèles de voix ou de recherche | Non | Interdit en production commerciale |

> 💡 **Autrement dit** — Une licence, ce sont les conditions d'utilisation. **Apache 2.0 / MIT** : « faites-en ce que vous voulez ». **Communautaire** : « oui, mais… », un peu comme une salle municipale prêtée gratuitement aux petites associations mais payante au-delà d'une certaine taille. **Non commerciale** : usage personnel ou de recherche uniquement, jamais pour vendre.

> ⚠️ **Piège fréquent** — « C'est sur Hugging Face, donc je peux l'utiliser dans mon produit. » Lisez la licence sur la fiche du modèle. Un modèle sous Llama Community License utilisé par une entreprise qui dépasse le seuil d'utilisateurs prévu nécessite un accord spécifique.

## 5. Les classements : utiles, à condition de savoir les lire

Deux classements font référence :

- **LMArena** (ex-Chatbot Arena) : des utilisateurs comparent deux réponses anonymes et votent ; on en déduit un score Elo (un système de points où l'on gagne davantage en battant un adversaire fort), comme aux échecs. Relevé du 31 octobre 2026 : Claude Mythos 5 (1531), Claude Fable 5 (1525), Claude Opus 5 (1522), GPT-5.6 Sol (1514) ; meilleurs ouverts : Kimi K3 (1500), Qwen3.8-Max (1491). *Limite* : mesure la préférence humaine, donc aussi le style et la longueur, pas seulement l'exactitude.
- **Artificial Analysis Intelligence Index** (v5, 27 oct. 2026) : indice composite (une note globale qui combine plusieurs tests) sur des tests de raisonnement, de code, de sciences et de culture générale, dont 60 % de tests privés (pour éviter que les éditeurs « révisent le sujet »). Claude Opus 5.5 = 58, GPT-6 Astra = 57 ; meilleurs poids publiés : DeepSeek V4.1 Flash et GLM-5.3 = 32. L'écart fermé/ouvert, mesuré sur les poids réellement publiés, est d'environ 26 points sur cette version v5 — un écart très sensible à la méthode : sur la version précédente de l'indice (v4, avril 2026), les meilleurs ouverts (Kimi K2.6 : 54) talonnaient GPT-5.5 (60), et en avril 2025 le meilleur ouvert plafonnait à 22. Tendance de fond : l'ouvert rattrape, par vagues.

Trois règles de lecture :
1. Un score global ne dit rien de *votre* tâche : un modèle moyen en code peut être excellent en rédaction française.
2. Les scores auto-déclarés par les éditeurs (sur leurs propres pages) sont à prendre comme de la publicité.
3. Le meilleur test est le vôtre : 20 exemples réels de votre métier, les mêmes pour chaque modèle (module M03 et, pour les développeurs, Niveau 3).

🎮 **Défi** — Sans regarder le tableau, classez de mémoire du moins cher au plus cher : GPT-6 Astra, Mistral Small 4, Claude Sonnet 5.5, Claude Haiku 5.5. Vérifiez ensuite.

> 💡 **Autrement dit** — Un classement comme LMArena, c'est un concours de dégustation à l'aveugle : les juges votent pour la réponse qu'ils préfèrent, y compris parce qu'elle est mieux présentée ou plus longue. Un indice comme celui d'Artificial Analysis, c'est plutôt un examen écrit commun à tous. Aucun des deux ne vous dit comment le modèle se débrouillera sur **vos** documents et **votre** métier.

```quiz
{
  "q": "Un modèle est premier au classement LMArena. Que devez-vous faire avant de l'adopter pour votre service ?",
  "options": [
    "Le tester sur une vingtaine de cas réels de votre métier",
    "Rien : le premier du classement est forcément le meilleur pour vous",
    "Vérifier qu'il a le nom le plus récent",
    "Choisir le plus cher, gage de qualité"
  ],
  "answer": 0,
  "explanation": "LMArena mesure une préférence humaine moyenne sur des questions générales, style compris. Seul un test sur vos propres cas — dans votre langue, avec vos documents — permet de trancher. Comparez-le au passage à d'autres modèles sur ces mêmes exemples."
}
```

## 6. La grille de choix en cinq questions

| Question | Si la réponse est… | Orientation |
|---|---|---|
| **1. Où vont mes données ?** | Données personnelles, secrets d'affaires, santé | Modèle ouvert en local ou hébergeur européen (Mistral, inférence régionale) ; sinon, API avec contrat et options de résidence des données (module M07) |
| **2. Quelle difficulté ?** | Tri, extraction, résumé simple | Petit modèle (Haiku 5.5, GPT-6 Luna, Gemini 3.8 Flash, Ministral) |
| | Analyse juridique, code complexe, raisonnement long | Modèle haut de gamme (Opus 5.5, GPT-6 Astra, Gemini 4 Argon) |
| **3. Quel volume ?** | Des millions de documents | Le prix par token devient décisif : petit modèle, lots (*batch*) = envoi groupé, traité moins vite mais moins cher à −50 %, cache |
| **4. Quelles modalités ?** | Images, audio, vidéo, PDF scannés | Vérifier la fiche : Gemini et Qwen3.8 sont nativement multimodaux ; Claude lit images et PDF ; Mistral propose OCR et voix |
| **5. Quelles compétences internes ?** | Aucune équipe technique | Interface grand public ou outil no-code (un logiciel qu'on configure sans écrire de programme) (Niveau 2) plutôt que serveur local |

> 🔗 **Documentation officielle** — Anthropic publie un guide [Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model) 🇬🇧 et OpenAI une page équivalente de [sélection de modèle](https://developers.openai.com/api/docs/guides/model-selection) 🇬🇧. Les deux recommandent la même méthode : commencer par le modèle le plus capable pour valider la faisabilité, puis descendre en gamme tant que la qualité tient.

```mission
{
  "title": "Jusqu'à quand va la « culture » de Grok 4.7 ?",
  "url": "https://docs.x.ai/developers/models",
  "steps": ["Ouvrez la page Models de la documentation xAI", "Repérez la ligne ou la fiche du modèle grok-4.7", "Relevez sa fenêtre de contexte et sa date de connaissance (knowledge cutoff)"],
  "question": "Quelle est la fenêtre de contexte de Grok 4.7, et jusqu'à quel mois s'étendent ses connaissances ?",
  "hint": "Le tableau de la section 3 donne déjà la réponse : vérifiez qu'elle est toujours à jour.",
  "answer": "500 000 tokens de contexte ; connaissances jusqu'en mai 2026 (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Une hausse de prix annoncée chez Google",
  "url": "https://ai.google.dev/gemini-api/docs/pricing",
  "steps": ["Ouvrez la page de tarifs de l'API Gemini", "Trouvez la ligne Gemini 4 Argon", "Lisez le prix actuel et la mention de changement de tarif à venir"],
  "question": "Quel est le prix de Gemini 4 Argon par million de tokens (entrée / sortie), et que devient-il à partir du 1er décembre 2026 ?",
  "hint": "Le prix est multiplié par un chiffre rond.",
  "answer": "2 $ / 10 $ par million de tokens, puis 4 $ / 20 $ à partir du 1er décembre 2026 (relevé du 1er nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Pour chacune des trois situations suivantes, proposez **un modèle** (ou une famille) et justifiez votre choix par au moins **deux critères** de la grille de la section 6. Précisez le mode d'accès (interface, API, local) et un ordre de grandeur de coût si l'API est retenue.

**Concrètement :** trois petits paragraphes. Pour chaque situation : ① répondez aux cinq questions de la grille de la section 6 (données, difficulté, volume, modalités, compétences) ; ② choisissez un modèle dans les tableaux de la leçon ; ③ indiquez le mode d'accès : **interface** (le site ou l'application), **API** (un prestataire branche le modèle sur vos logiciels) ou **local** (sur vos propres serveurs) ; ④ pour le coût, comptez environ 1 000 tokens par page, puis tokens ÷ 1 000 000 × prix d'entrée. Il n'y a pas une seule bonne réponse : c'est la justification qui compte.

1. **Cabinet d'expertise comptable (12 personnes, Nantes)** : classer automatiquement 50 000 pièces justificatives par mois (facture, note de frais, relevé…) à partir du texte extrait. Données clients sensibles. Pas de développeur en interne, mais un prestataire disponible.
2. **Agence de communication (6 personnes)** : rédiger des propositions commerciales élaborées, en français, à partir d'un brief et de trois propositions antérieures (environ 60 pages de contexte au total). Une vingtaine de propositions par mois.
3. **Start-up santé (équipe technique de 4 développeurs)** : assistant interne de questions-réponses sur des comptes rendus médicaux anonymisés ; exigence : aucune donnée ne quitte les serveurs de l'entreprise (deux serveurs avec cartes graphiques de 24 Go).

**Critères de réussite.** Chaque choix cite deux critères pertinents (données, difficulté, volume, modalités, compétences) ; le mode d'accès est cohérent avec les compétences internes ; les coûts cités sont datés et tirés des tableaux de cette leçon ; une alternative est mentionnée pour au moins un cas.

<details>
<summary>Pistes de corrigé</summary>

1. Tâche simple à très grand volume, données sensibles : un **petit modèle** (Claude Haiku 5.5, GPT-6 Luna ou Ministral 3 via API européenne de Mistral) en mode *batch*. Ordre de grandeur : 50 000 pièces × ~800 tokens = 40 M tokens/mois → ~4 $ avec Haiku 5.5 (0,10 $/M) hors batch. Le prestataire mettra en place l'API ; le choix d'un hébergement européen ou d'un contrat avec résidence des données répond au critère « données ». Alternative : Ministral 3 8B en local sur un petit serveur si le prestataire le maîtrise.
2. Rédaction élaborée en français, contexte long (60 pages ≈ 60 000 tokens), faible volume : un **modèle haut de gamme** via une interface « projet » (Claude Opus 5.5 / Sonnet 5.5, GPT-6 Astra ou Mistral Large 4). Avec l'API Sonnet 5.5 : ~60 k tokens d'entrée × 20 propositions = 1,2 M tokens → ~2,40 $ d'entrée par mois plus la sortie — le coût est négligeable, la qualité prime. Aucune compétence technique requise.
3. Contrainte absolue de confidentialité et équipe technique disponible : **modèle ouvert en local**. Avec 24 Go par carte, Qwen3.8-27B (Apache 2.0, ~16-19 Go en 4 bits) ou Gemma 4 26B-A4B ; Mistral Small 4 demanderait ~64 Go. Coût API nul ; coût = matériel + temps d'ingénierie. Licence permissive indispensable pour un usage commercial en santé.
</details>

## ✅ Auto-évaluation express

1. Citez un modèle à poids ouverts publié par un éditeur américain, et un par un éditeur français.
2. Qu'est-ce qui distingue une licence Apache 2.0 d'une « licence communautaire » comme celle de Llama ou de Muse ?
3. Pourquoi le score LMArena d'un modèle ne suffit-il pas à le choisir pour votre entreprise ?

<details>
<summary>Réponses</summary>

1. Américain : gpt-oss (OpenAI), Gemma 4 (Google), Llama 4 / Muse Spark Open (Meta), Granite (IBM), Phi (Microsoft). Français : Mistral Small 4, Ministral 3, Mistral Large 3 (Mistral AI).
2. Apache 2.0 autorise tout usage commercial sans condition (hors marques) ; une licence communautaire ajoute des conditions (seuil de chiffre d'affaires ou d'utilisateurs, mention obligatoire, usages interdits) et n'est pas reconnue comme « open source » par l'OSI.
3. Parce qu'il mesure une préférence humaine moyenne sur des questions générales (y compris le style), pas la performance sur votre tâche, dans votre langue, avec vos documents ; seul un test sur vos propres exemples tranche.
</details>

> ✅ **Si vous ne retenez que 3 choses** — 1. Deux façons d'utiliser un modèle : le louer (modèles fermés comme Claude, GPT, Gemini, Grok, via une application ou une API) ou le télécharger pour le faire tourner chez soi (modèles ouverts comme Mistral Small, Gemma, Qwen, DeepSeek). 2. Les prix vont de 1 à 100 : un petit modèle pour les tâches simples et massives, un modèle haut de gamme pour les tâches difficiles. Mistral est l'acteur français de référence. 3. Un classement ne remplace pas votre propre essai sur une vingtaine d'exemples de votre métier ; et pour un modèle ouvert, lisez toujours la licence.

## 📚 Pour aller plus loin
- [Anthropic — Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 et [Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model) 🇬🇧 — tarifs et méthode de sélection officiels.
- [OpenAI — Models](https://developers.openai.com/api/docs/models) 🇬🇧 et [Pricing](https://developers.openai.com/api/docs/pricing) 🇬🇧 — la famille GPT-6 et ses tarifs.
- [Google — Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing) 🇬🇧 — avec les hausses annoncées pour décembre 2026 et janvier 2027.
- [xAI — Models](https://docs.x.ai/developers/models) 🇬🇧 — Grok 4.7 et ses prédécesseurs.
- [Mistral AI — Models overview](https://docs.mistral.ai/getting-started/models/) 🇬🇧 et [Pricing](https://docs.mistral.ai/inference/pricing) 🇬🇧 — l'offre française, avec les modèles ouverts et les modèles tiers hébergés.
- [Artificial Analysis — Leaderboards](https://artificialanalysis.ai/leaderboards/models) 🇬🇧 — l'indice composite cité dans cette leçon.
- [Hugging Face — Open-source LLMs to run locally (mai 2026)](https://huggingface.co/blog/daya-shankar/open-source-llm-models-to-run-locally) 🇬🇧 — panorama des modèles ouverts par taille, pour préparer le Niveau 2.
- [Microsoft — Generative AI for Beginners, leçon 02 « Exploring and comparing different LLMs »](https://github.com/microsoft/generative-ai-for-beginners) 🇬🇧 — cours libre (licence MIT) qui propose une grille de comparaison voisine.

> 🗺️ **Et maintenant ?** — Le module 2 est terminé : vous savez comment fonctionnent les modèles. Le module 3 passe à la pratique, en commençant en L010 par une prise en main complète de ChatGPT.
