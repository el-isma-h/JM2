---
id: L005
module: M02
level: N1
title: "Qu'est-ce qu'un LLM ? Tokens, paramètres, poids"
minutes: 45
objectives:
  - "Définir un grand modèle de langage en une phrase exacte et sans jargon"
  - "Expliquer ce qu'est un token et pourquoi tout (prix, contexte, vitesse) se compte en tokens"
  - "Distinguer paramètres, poids et taille d'un modèle, et lire une fiche de modèle (7B, 27B, 119B-A6B…)"
skills: ["C1.1"]
sources:
  - { title: "Anthropic — Token counting", url: "https://platform.claude.com/docs/en/build-with-claude/token-counting", lang: "en" }
  - { title: "Anthropic — Context windows", url: "https://platform.claude.com/docs/en/build-with-claude/context-windows", lang: "en" }
  - { title: "Andrej Karpathy — [1hr Talk] Intro to Large Language Models", url: "https://www.youtube.com/watch?v=zjkBMFhNj_g", lang: "en" }
  - { title: "Hugging Face — LLM Course, chapitre 1", url: "https://huggingface.co/learn/llm-course/chapter1/1", lang: "en" }
  - { title: "Fiche Hugging Face — Qwen3.8-27B", url: "https://huggingface.co/Qwen/Qwen3.8-27B", lang: "en" }
  - { title: "Mistral AI — Mistral Small 4", url: "https://mistral.ai/news/mistral-small-4/", lang: "en" }
---

# Qu'est-ce qu'un LLM ? Tokens, paramètres, poids

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 2

## 🎯 Ce que vous saurez faire
- Donner une définition exacte d'un grand modèle de langage (LLM) et la distinguer d'un moteur de recherche ou d'une base de données.
- Expliquer ce qu'est un **token**, estimer combien de tokens « pèse » un document, et comprendre pourquoi le français coûte plus cher que l'anglais.
- Lire une fiche de modèle : « 27B », « 119B-A6B », « contexte 1M » ne seront plus des hiéroglyphes.
- Expliquer à un collègue, avec l'analogie du « fichier de 2 téraoctets » (un téraoctet = mille gigaoctets, la capacité d'un gros disque dur), pourquoi un modèle ne « cherche » pas sur Internet quand il vous répond.

> 🧭 **En clair** — Un LLM (le moteur de ChatGPT, Claude ou Gemini), c'est un champion du jeu « finis ma phrase ». À force d'avoir lu des bibliothèques entières, il devine très bien le morceau de texte qui vient ensuite, puis le suivant, et ainsi de suite. Ces morceaux s'appellent des **tokens** : ce sont un peu les « pièces de Lego » du texte, et c'est avec eux qu'on mesure le prix, la mémoire et la vitesse du modèle. Tout ce qu'il a retenu de ses lectures est rangé dans des milliards de petits réglages, les **paramètres** (ou poids). Il ne cherche donc pas dans une base de réponses : il fabrique sa réponse à chaque fois.

## 1. Une définition en une phrase (et ce qu'elle ne dit pas)

Un **grand modèle de langage** (*Large Language Model*, LLM) est un programme informatique qui, après avoir lu une quantité gigantesque de textes, a appris à **prédire le prochain morceau de texte** le plus probable à la suite de ce qu'on lui donne.

C'est tout. Il n'y a ni base de données de réponses, ni règles écrites par des ingénieurs, ni « compréhension » au sens humain. Et pourtant, de cette unique capacité — continuer un texte de manière plausible — découlent la rédaction d'e-mails, la traduction, le résumé, la génération de code, et la conversation.

Prenons l'exemple d'un cabinet comptable à Lyon. Lorsque l'assistante tape dans Claude ou ChatGPT « Rédige un rappel de paiement courtois pour une facture de 1 200 € échue depuis 30 jours », le modèle ne consulte aucun modèle de lettre. Il « continue » cette demande, mot après mot, comme le ferait quelqu'un qui aurait lu des millions de courriers commerciaux et aurait développé une intuition très fine de ce qui vient ensuite.

> 💡 **À retenir** — Un LLM ne *stocke* pas des réponses, il *génère* du texte. C'est ce qui le rend si polyvalent… et c'est aussi la source de ses erreurs (leçon L008).

Le chercheur Andrej Karpathy (ex-OpenAI, ex-Tesla) résume un LLM à **deux fichiers** : un fichier de paramètres (les « poids », parfois plusieurs centaines de gigaoctets) et un petit programme de quelques centaines de lignes qui sait les faire tourner. Tout le « savoir » est dans le premier fichier. C'est l'image la plus juste que vous puissiez garder en tête.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : quand vous demandez à Claude une lettre de relance, il la fabrique morceau par morceau, sans aller chercher un modèle de lettre tout prêt dans une base de données.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai. Un LLM ne stocke pas de réponses toutes faites : il génère la lettre token par token, en prédisant à chaque fois la suite la plus probable. C'est ce qui le rend polyvalent… et parfois inventif à tort."
}
```

## 2. Les tokens : l'unité de mesure de tout

### 2.1 Un modèle ne lit pas des mots

Avant d'entrer dans le modèle, votre texte est découpé en **tokens** par un outil appelé *tokenizer*. Un token est un morceau de texte : parfois un mot entier (« maison »), parfois un fragment (« anti » + « constitution » + « nel » + « lement »), parfois un signe de ponctuation ou un espace.

Pourquoi ne pas utiliser simplement les mots ? Parce qu'un vocabulaire de mots serait infini (noms propres, fautes de frappe, néologismes, 200 langues…). Avec des sous-mots, un vocabulaire de quelques dizaines à quelques centaines de milliers de tokens suffit pour écrire n'importe quoi, dans n'importe quelle langue, y compris du code.

```
Phrase :  « Le cabinet comptable envoie une relance. »
Tokens :  [Le] [ cabinet] [ compt] [able] [ envoie] [ une] [ rel] [ance] [.]
          → 9 tokens pour 7 mots
```

Ce découpage exact varie d'un modèle à l'autre (chaque éditeur a son tokenizer), mais les ordres de grandeur sont stables.

> 💡 **Autrement dit** — Un *tokenizer*, c'est un découpeur automatique, comme le massicot d'un imprimeur : il tranche votre texte en petits morceaux avant de le donner au modèle. Les mots courants restent souvent entiers ; les mots longs ou rares sont coupés en plusieurs bouts. C'est pourquoi on compte en tokens plutôt qu'en mots.

### 2.2 Les ordres de grandeur à connaître par cœur

| Repère | Valeur (nov. 2026) | Source |
|---|---|---|
| 1 token en anglais | ≈ 0,75 mot (soit ~4 caractères) | Dossier recherche 04, §4 |
| Le français | coûte ~1,3 à 1,5 fois plus de tokens que l'anglais | Dossier recherche 04, §4 |
| 1 million de tokens (Claude, tokenizer 2026) | ≈ 555 000 mots anglais | Anthropic, page Pricing |
| Une page A4 dense (500 mots en français) | ≈ 900 à 1 000 tokens | estimation à partir des repères ci-dessus |
| Un roman de 300 pages | ≈ 150 000 à 200 000 tokens | idem |

> ⚠️ **Piège fréquent** — Les accents et les mots composés du français sont « chers ». Une PME qui traite 10 000 e-mails français par mois paiera typiquement 30 à 50 % de plus en tokens qu'une entreprise anglophone pour le même volume de texte. Les comparateurs de prix en « $ par million de tokens » doivent être lus avec cette correction en tête.

### 2.3 Pourquoi tout se compte en tokens

Trois choses essentielles se mesurent en tokens, et vous les retrouverez dans toute la formation :

1. **Le prix des API** (les « prises » qui permettent à un logiciel d'utiliser le modèle à distance ; voir L024) : les éditeurs facturent « par million de tokens » en entrée (ce que vous envoyez) et en sortie (ce que le modèle génère). Exemple (nov. 2026) : Claude Sonnet 5.5 coûte 2 $ par million de tokens en entrée et 10 $ en sortie ; GPT-6.1 Sol affiche exactement les mêmes tarifs. La sortie est presque toujours 4 à 5 fois plus chère que l'entrée, car générer est plus coûteux que lire.
2. **La fenêtre de contexte** : la quantité maximale de tokens (votre demande + les documents joints + la réponse) que le modèle peut traiter d'un coup. En 2026, les modèles phares annoncent 1 million de tokens (Claude 5.5, GPT-6, Gemini 4) ; Grok 4.7 annonce 500 000.
3. **La vitesse** : on parle de « tokens par seconde ». Un modèle local sur un ordinateur portable génère souvent 10 à 50 tokens/s ; les API cloud, bien davantage (« cloud » = sur les serveurs de l'éditeur, via Internet).

> 🔗 **Documentation officielle** — [Anthropic — Token counting](https://platform.claude.com/docs/en/build-with-claude/token-counting) 🇬🇧 : l'API propose un point d'entrée gratuit pour compter les tokens d'une requête avant de l'envoyer. Et [Context windows](https://platform.claude.com/docs/en/build-with-claude/context-windows) 🇬🇧 pour comprendre comment entrée et sortie partagent la même enveloppe.

```quiz
{
  "q": "Pourquoi une PME française paie-t-elle souvent 30 à 50 % de plus en tokens qu'une entreprise anglophone pour le même volume de texte ?",
  "options": [
    "Parce que les éditeurs appliquent une taxe sur les langues étrangères",
    "Parce que les serveurs sont situés aux États-Unis",
    "Parce que le français est découpé en davantage de tokens",
    "Parce que le français contient plus de mots par phrase que l'anglais"
  ],
  "answer": 2,
  "explanation": "Le prix se calcule au token, pas au mot. Les tokenizers, entraînés surtout sur de l'anglais, découpent plus finement le français : le même texte « pèse » donc plus lourd."
}
```

## 3. Paramètres et poids : le « cerveau » en chiffres

### 3.1 Ce qu'est un paramètre

Un LLM est un réseau de neurones artificiels : un gigantesque enchevêtrement de connexions, chacune portant un nombre réglable. Ces nombres sont les **paramètres** ; leurs valeurs, une fois l'apprentissage terminé, sont les **poids** (*weights*). Dans la pratique, les deux mots sont employés comme synonymes.

Analogie : imaginez une immense table de mixage avec des milliards de potentiomètres. Pendant l'entraînement (leçon L007), on tourne tous ces boutons, un tout petit peu à chaque exemple lu, jusqu'à ce que le son — ici, la prédiction du prochain token — soit juste. À la fin, on « fige » la position des boutons : ce sont les poids. Les utiliser ensuite ne les modifie plus — ce qui explique au passage pourquoi un modèle « n'apprend pas » de vos conversations en temps réel.

### 3.2 Lire la taille d'un modèle

Les tailles s'écrivent avec **B** (*billion* = milliard) ou **T** (*trillion* = mille milliards). Quelques repères réels (nov. 2026, dossier de recherche 04) :

| Modèle (ouvert) | Paramètres | Ce que ça implique |
|---|---|---|
| Ministral 3 — 3B (Mistral, Paris) | 3 milliards | Tourne sur un téléphone haut de gamme ou un PC à 8 Go de RAM |
| Qwen3.8-27B (Alibaba) | 27 milliards | Un PC de joueur (RTX 4090) ou un Mac 32 Go suffisent |
| Mistral Small 4 | 119 milliards, dont **6 actifs** | Architecture MoE (voir ci-dessous) ; ~64 Go de mémoire |
| Kimi K3 (Moonshot) | 2 800 milliards (2,8T), dont 104 actifs | Nécessite un cluster de plusieurs dizaines de cartes graphiques |

> 💡 **Autrement dit** — Quelques mots de ce tableau : la **RAM** est la mémoire de travail d'un ordinateur ; une **RTX 4090** est une carte graphique haut de gamme, celle des passionnés de jeux vidéo ; un **cluster** est un groupe d'ordinateurs branchés ensemble pour travailler comme un seul. L'idée à retenir est simple : plus un modèle a de paramètres, plus il faut une grosse machine — du téléphone jusqu'à la salle de serveurs.

La règle du pouce pour la mémoire, enseignée au Niveau 2 : **mémoire (Go) ≈ paramètres (milliards) × bits ÷ 8 × 1,1**. Un modèle 8B stocké sur 16 bits occupe ~17,6 Go ; compressé (« quantifié ») sur 4 bits, ~4,4 Go. C'est ce qui permet aujourd'hui de faire tourner un modèle honnête sur un ordinateur portable.

> 💡 **Autrement dit** — Pas besoin de faire ce calcul au niveau 1. Les **bits** indiquent la précision avec laquelle on note chaque paramètre : c'est comme écrire un prix « 12,3456789 € » ou l'arrondir à « 12,35 € ». **Quantifier**, c'est arrondir ces nombres pour que le modèle prenne quatre fois moins de place — un peu comme une photo compressée qu'on envoie par e-mail : un peu moins fine, mais bien plus légère.

### 3.3 « 119B-A6B » : les modèles à experts (MoE)

Depuis 2024-2025, beaucoup de grands modèles sont des **mélanges d'experts** (*Mixture of Experts*, MoE). Le modèle est découpé en dizaines ou centaines de sous-réseaux spécialisés (« experts ») ; pour chaque token, un aiguilleur n'en active que quelques-uns. Mistral Small 4, par exemple, compte 128 experts dont 4 travaillent à chaque instant : 119 milliards de paramètres au total, mais seulement 6 milliards « actifs ». La notation **119B-A6B** se lit donc : *119 milliards au total, 6 milliards actifs*.

Analogie : un grand cabinet de conseil de 128 consultants. Chaque question n'est traitée que par les 4 plus compétents sur le sujet. Il faut héberger tout le cabinet (la mémoire), mais chaque réponse ne mobilise que 4 personnes (la vitesse et le coût).

> 💡 **À retenir** — Pour un MoE, la mémoire nécessaire dépend du total ; la vitesse et le coût dépendent des paramètres actifs.

```quiz
{
  "type": "mise_en_situation",
  "q": "Sur la fiche d'un modèle, vous lisez « 119B-A6B ». Que comprenez-vous ?",
  "options": [
    "119 milliards de paramètres, 6 milliards actifs par token",
    "Le modèle a été publié le 11 septembre, version 6B",
    "Le modèle accepte 119 000 tokens en entrée et en produit 6 000",
    "Il faut 119 Go de mémoire et 6 cartes graphiques"
  ],
  "answer": 0,
  "explanation": "C'est la notation d'un « mélange d'experts » (MoE) : il faut héberger les 119 milliards de paramètres (la mémoire), mais seuls 6 milliards sont « actifs » à chaque instant (la vitesse et le coût)."
}
```

### 3.4 Et les modèles fermés ?

Pour Claude, GPT-6, Gemini 4 ou Grok 4.7, le nombre de paramètres **n'est pas publié**. Ces éditeurs ne communiquent que sur les capacités (contexte, prix, date de connaissance). Méfiez-vous des chiffres « 1 700 milliards de paramètres pour GPT-4 » qui circulent : ce sont des rumeurs, jamais confirmées officiellement. Quand une fiche ne donne pas la taille, c'est volontaire.

## 4. Ce qui n'est PAS dans les poids

Les poids contiennent une compression statistique des textes d'entraînement. Ils ne contiennent **ni** vos documents, **ni** l'actualité postérieure à la date de connaissance (*knowledge cutoff*, juin 2026 pour les Claude 5.5, 30 avril 2026 pour GPT-6 Astra — nov. 2026), **ni** l'accès à Internet. Lorsqu'un assistant vous cite un article paru hier, c'est qu'un **outil** de recherche web lui a été ajouté par-dessus — ce n'est pas le modèle lui-même (module M06).

🎮 **Défi** — Devinez le nombre de tokens de ce proverbe : « Les cordonniers sont toujours les plus mal chaussés. » Réponse en fin de leçon.

```mission
{
  "title": "Quelle licence pour Mistral Small 4 ?",
  "url": "https://mistral.ai/news/mistral-small-4/",
  "steps": ["Ouvrez l'annonce officielle de Mistral Small 4 sur le site de Mistral AI", "Repérez la date de publication", "Cherchez le nom de la licence sous laquelle les poids sont diffusés"],
  "question": "Sous quelle licence Mistral Small 4 est-il publié, et à quelle date a-t-il été annoncé ?",
  "hint": "Une licence « ouverte » très courante, qui porte le nom d'une fondation de logiciels libres.",
  "answer": "Licence Apache 2.0 ; annonce du 16 mars 2026 (119 milliards de paramètres, dont 6 milliards actifs).",
  "xp": 10
}
```

```mission
{
  "title": "Comparez les prix d'OpenAI et d'Anthropic",
  "url": "https://developers.openai.com/api/docs/pricing",
  "steps": ["Ouvrez la page de tarifs de l'API OpenAI", "Repérez la ligne du modèle GPT-6.1 Sol", "Lisez le prix par million de tokens en entrée (input) et en sortie (output)"],
  "question": "Combien coûte GPT-6.1 Sol par million de tokens en entrée et en sortie ? Est-ce plus cher ou moins cher que Claude Sonnet 5.5 (2 $ / 10 $) ?",
  "hint": "La section 2.3 de cette leçon affirme que les deux modèles sont au même tarif : vérifiez-le vous-même.",
  "answer": "2 $ en entrée et 10 $ en sortie par million de tokens, soit exactement le tarif de Claude Sonnet 5.5 (nov. 2026) — vérifiez : les prix évoluent (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Vous êtes responsable administratif d'une PME de 40 salariés. La direction envisage de faire résumer par un LLM, via une API, les 1 200 comptes rendus de réunion archivés (environ 2 pages A4 chacun, en français).

1. Estimez le nombre total de tokens en **entrée** (utilisez les repères de la section 2.2).
2. Chaque résumé fera environ 150 mots. Estimez les tokens en **sortie**.
3. Calculez le coût avec Claude Haiku 5.5 (0,10 $ / M tokens en entrée, 0,50 $ / M en sortie, nov. 2026) puis avec Claude Sonnet 5.5 (2 $ / 10 $).
4. En trois lignes, expliquez à la direction pourquoi le français fait grimper la facture, et quelle précaution prendre avant de lancer le traitement.

**Concrètement :** procédez en trois temps, avec la calculatrice de votre téléphone. ① Nombre de mots = pages × 500 mots × nombre de comptes rendus. ② Nombre de tokens : en français, comptez environ 2 tokens par mot (c'est le repère « 1 page de 500 mots ≈ 1 000 tokens » du tableau 2.2). ③ Coût = tokens ÷ 1 000 000 × prix. « 0,10 $ / M tokens » se lit « 10 centimes de dollar par million de tokens ». On attend un ordre de grandeur, pas un résultat au centime près.

**Critères de réussite.** Les deux estimations sont dans le bon ordre de grandeur ; les coûts sont calculés séparément pour l'entrée et la sortie ; la précaution proposée est concrète (tester sur 20 comptes rendus et compter les tokens réels, par exemple).

<details>
<summary>Corrigé</summary>

1. 2 pages × 500 mots × 1 200 comptes rendus = 1,2 million de mots. En français, comptez ~1,9 token par mot (0,75 mot/token en anglais, ×1,4) → **≈ 2,3 millions de tokens** en entrée. Toute estimation entre 2 et 3 millions est correcte.
2. 150 mots × 1 200 ≈ 180 000 mots → **≈ 340 000 tokens** en sortie.
3. Haiku 5.5 : 2,3 × 0,10 $ + 0,34 × 0,50 $ ≈ **0,40 $**. Sonnet 5.5 : 2,3 × 2 $ + 0,34 × 10 $ ≈ **8 $**. Même avec le modèle le plus cher de la paire, la facture reste anecdotique : le vrai coût d'un tel projet, c'est le temps de vérification humaine des résumés.
4. Le tokenizer découpe plus finement les mots accentués et les terminaisons françaises ; prévoir une marge de 30 à 50 %. Précaution : lancer un lot pilote de 20 documents, lire la consommation réelle de tokens renvoyée par l'API, puis extrapoler.
</details>

## ✅ Auto-évaluation express

1. Vrai ou faux : un LLM consulte une base de données de réponses pour répondre à vos questions.
2. Un fournisseur facture 1 $ par million de tokens en entrée. Combien coûte, grosso modo, l'envoi d'un rapport français de 50 pages (500 mots par page) ?
3. Que signifie « 26B-A4B » sur la fiche d'un modèle Gemma 4 ?

<details>
<summary>Réponses</summary>

1. **Faux.** Il génère du texte token par token à partir de paramètres figés ; aucune base de réponses n'est consultée (sauf si un outil externe lui est ajouté).
2. 25 000 mots × ~1,9 token ≈ 47 000 tokens → environ **0,05 $**. (L'ordre de grandeur compte, pas la décimale.)
3. 26 milliards de paramètres au total, dont 4 milliards **actifs** à chaque token : c'est un modèle à mélange d'experts (MoE). La mémoire se dimensionne sur 26B, la vitesse sur 4B.

🎮 **Réponse au défi** : selon le tokenizer, entre 10 et 14 tokens pour 8 mots — un bel exemple du « surcoût » du français (« cordonniers », « chaussés » sont découpés en plusieurs morceaux).
</details>

> ✅ **Si vous ne retenez que 3 choses** — 1. Un LLM est un champion du « finis ma phrase » : il fabrique sa réponse morceau par morceau, il ne cherche pas dans une base de réponses. 2. Le token (un morceau de mot) est l'unité de mesure de tout : le prix, la taille de ce que l'IA peut lire d'un coup, la vitesse. Le français consomme plus de tokens que l'anglais. 3. Les paramètres (ou poids) sont des milliards de réglages figés ; « 27B » = 27 milliards. Ils ne contiennent ni vos documents ni l'actualité récente.

## 📚 Pour aller plus loin
- [Andrej Karpathy — Intro to Large Language Models (1 h)](https://www.youtube.com/watch?v=zjkBMFhNj_g) 🇬🇧 — la conférence de référence sur « le LLM = deux fichiers » ; source d'inspiration de cette leçon.
- [Hugging Face — LLM Course, chapitre 1 « Transformer models »](https://huggingface.co/learn/llm-course/chapter1/1) 🇬🇧 — cours gratuit sous licence Apache 2.0, avec quiz de fin de chapitre.
- [Anthropic — Pricing (tarifs par million de tokens)](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 — pour vérifier les chiffres de cette leçon, qui évoluent régulièrement.
- [Fiche Qwen3.8-27B sur Hugging Face](https://huggingface.co/Qwen/Qwen3.8-27B) 🇬🇧 — un exemple de fiche de modèle ouvert à décoder : paramètres, contexte, licence.
- [Mistral AI — annonce de Mistral Small 4](https://mistral.ai/news/mistral-small-4/) 🇬🇧 — l'exemple de MoE « 119B dont 6B actifs » utilisé dans cette leçon.

> 🗺️ **Et maintenant ?** — Vous savez de quoi un LLM est fait ; la leçon L006 montre, sans une seule équation, comment son architecture — le Transformer — choisit le token suivant grâce au mécanisme d'« attention ».
