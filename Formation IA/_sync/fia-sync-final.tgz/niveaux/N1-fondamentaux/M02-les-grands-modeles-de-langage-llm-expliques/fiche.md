---
module: M02
title: "Fiche mémo — Les grands modèles de langage (LLM) expliqués"
---
# Fiche mémo — M02 · Les grands modèles de langage (LLM) expliqués

> En une phrase : un LLM est un champion du jeu « finis ma phrase » : il découpe le texte en tokens, regarde les mots qui comptent (attention), tire au sort le token suivant… et recommence, sans jamais revenir en arrière.

## Les 7 idées à retenir
1. **Un LLM génère, il ne stocke pas de réponses** : tout son « savoir » tient dans un fichier de poids figés (« un LLM = deux fichiers », Karpathy) (`L005`).
2. **Tout se compte en tokens** : prix, fenêtre de contexte, vitesse. Le français coûte 1,3 à 1,5 fois plus de tokens que l'anglais (`L005`).
3. **« 119B-A6B »** = 119 milliards de paramètres au total, 6 milliards actifs (mélange d'experts) : la mémoire dépend du total, la vitesse et le coût des actifs (`L005`).
4. **L'attention** (2017) : chaque token regarde tous les autres pour savoir lesquels comptent ; le modèle sort une liste de probabilités, puis tire un token au sort (`L006`).
5. **Fabrication en 3 couches + 1** : pré-entraînement (le savoir) → fine-tuning supervisé (le format) → alignement RLHF/DPO (le ton, les refus) → prompt système (la fiche du jour) (`L007`).
6. **Trois limites en une minute** : il ne voit que son contexte, il tire au sort, il invente avec assurance (`L008`).
7. **Fermé ou ouvert ?** Louer avec chauffeur (API) ou garder la voiture au garage (poids téléchargés). Lire la licence, puis tester sur 20 exemples de votre métier (`L009`).

## Le schéma à connaître

```mermaid
flowchart LR
  A["Votre texte"] --> B["1. Tokenisation<br/>pièces de Lego"]
  B --> C["2. Vecteurs<br/>sens + position"]
  C --> D["3. Attention x N couches<br/>qui compte pour qui ?"]
  D --> E["4. Probabilités<br/>beurre 31 %, chocolat 18 %…"]
  E --> F["Tirage d'un token"]
  F -- "réinjecté (autorégressif)" --> B
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Token | Un morceau de texte (mot, bout de mot, ponctuation) ; ≈ 0,75 mot anglais |
| Paramètres / poids | Les milliards de boutons de la table de mixage, figés après l'entraînement |
| MoE (mélange d'experts) | Un cabinet de 128 consultants dont 4 traitent chaque question |
| Embedding | La « carte » où les mots de sens proche sont voisins |
| Autorégressif | Chaque mot écrit devient l'entrée du mot suivant |
| Fenêtre de contexte | Le bureau du modèle : ce qui n'est pas posé dessus n'existe pas |
| Température | Le bouton d'audace : bas = sage, haut = inventif |
| Hallucination | Une réponse à la forme parfaite et au fond inventé |

## Les pièges classiques
- « Il cherche dans une base » : non, il génère. Une info d'hier vient d'un **outil** de recherche ajouté.
- « Il a été programmé pour refuser » : les refus sont **appris par préférence**, donc imparfaits dans les deux sens.
- « 1 million de tokens, donc il a tout pris en compte » : placer n'est pas bien utiliser. Une conversation = une tâche.
- « Température 0 = toujours vrai » : la température change la **variabilité**, pas la justesse.
- « C'est sur Hugging Face, donc libre » : une licence communautaire impose des conditions (seuils, mentions).

## Les commandes / chiffres / dates utiles
- **4 parades anti-hallucination, mnémo « SCIV »** : **S**ource fournie · **C**itations exigées · **I**gnorance autorisée · **V**érification de ce qui engage.
- Mémoire d'un modèle ≈ paramètres (milliards) × bits ÷ 8 × 1,1 (8B en 4 bits ≈ 4,4 Go).
- Prix (nov. 2026, $/M tokens entrée/sortie) : Haiku 5.5 0,10/0,50 · Sonnet 5.5 2/10 · Opus 5.5 4/20 · GPT-6 Astra 10/50. La sortie coûte 4 à 5 fois plus que l'entrée.
- Contexte : 1 M (Claude 5.5, Gemini 4), 1,05 M (GPT-6), 500 k (Grok 4.7). Cache de prompt : relecture à 10 % du prix, 5 % sur Opus et Sonnet 5.5.
- Date de connaissance : juin 2026 (Claude 5.5), 30 avril 2026 (GPT-6 Astra), mai 2026 (Grok 4.7).
- API Claude : `temperature`, `top_p` et `top_k` refusés (erreur 400) à partir de Claude 4.7, et **sur tous les modèles** avec la version d'API 2026-10-21 (SDK v2).

## Pour aller plus loin
- [Claude Academy — AI capabilities and limitations](https://academy.claude.com/courses/ai-capabilities-and-limitations)
- [3Blue1Brown — Neural networks](https://www.3blue1brown.com/topics/neural-networks)
- [Anthropic — Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model)

## Auto-test (3 questions — réponses en bas de fiche)
1. Que signifie « 26B-A4B » sur une fiche Gemma 4 ?
2. Pourquoi le vingtième message d'une conversation avec un PDF coûte-t-il plus cher que le premier ?
3. Dans le RLHF, les annotateurs rédigent-ils les réponses ou les classent-ils ?

---
**Réponses** — 1. 26 milliards de paramètres au total, dont 4 milliards actifs (MoE) : mémoire sur 26B, vitesse sur 4B. 2. Le modèle n'a pas de mémoire : toute la conversation et le PDF sont renvoyés à chaque tour. 3. Ils les **classent** (paires préférée / rejetée) ; rédiger relève du fine-tuning supervisé.
