# Niveau 1 — Fondamentaux de l'IA (NF-IA-N1)

**Certificat Next Formation IA — Niveau 1 « Utilisateur IA certifié »** · 25 h à distance (24 h de leçons et exercices + 1 h d'évaluations) · 7 modules · 31 leçons · 7 quiz · 1 examen · Version 1.0 — 1er novembre 2026.

## Promesse

À l'issue du niveau 1, vous utilisez les assistants IA du marché (Claude, ChatGPT, Gemini, Grok, Perplexity, Le Chat, Copilot) de manière **productive, critique et conforme** : vous comprenez ce qu'est réellement un grand modèle de langage et ses limites, vous rédigez des prompts qui donnent des résultats exploitables, vous vérifiez et corrigez ce que l'IA produit, vous savez ce qu'une automatisation ou un agent peut faire pour votre métier, et vous respectez le RGPD, le droit d'auteur et l'obligation de « maîtrise de l'IA » de l'article 4 du règlement européen sur l'IA (applicable à tous les employeurs depuis le 2 février 2025).

## Public

Tout public : salariés, managers, dirigeants, indépendants, demandeurs d'emploi, étudiants. Aucun profil technique requis. Ce niveau répond directement au besoin de formation des équipes imposé par l'AI Act (art. 4) et au plan national « Osez l'IA ».

## Prérequis

- Savoir utiliser un ordinateur, un navigateur web et une messagerie.
- Aucune compétence en programmation ni en mathématiques.
- Test de positionnement d'entrée (20 questions, non éliminatoire).

## Compétences du bloc 1 (référentiel de compétences)

| Code | Compétence |
|---|---|
| C1.1 | Expliquer le fonctionnement général d'un grand modèle de langage (tokens, paramètres, entraînement, fenêtre de contexte) et ses limites (hallucinations, biais, date de connaissance) |
| C1.2 | Sélectionner l'outil IA adapté à une tâche professionnelle donnée parmi l'offre du marché |
| C1.3 | Rédiger un prompt structuré (rôle, contexte, tâche, format, contraintes, exemples) produisant un résultat exploitable |
| C1.4 | Vérifier, sourcer et corriger une production IA avant utilisation |
| C1.5 | Décrire les principes d'une automatisation (API, webhook, workflow) et d'un agent IA et identifier un cas d'usage pertinent dans son métier |
| C1.6 | Appliquer les règles de protection des données (RGPD), de propriété intellectuelle et les obligations de l'AI Act dans l'usage quotidien de l'IA |

## Modules et durées

| Module | Titre | Leçons | Durée | Compétences |
|---|---|---|---|---|
| M01 | Comprendre l'intelligence artificielle | L001-L004 | 2 h 45 | C1.1 |
| M02 | Les grands modèles de langage (LLM) expliqués | L005-L009 | 3 h 45 | C1.1 |
| M03 | Les outils IA du quotidien (ChatGPT, Claude, Gemini, Copilot, Grok, Le Chat, Perplexity, image/vidéo/voix) | L010-L014 | 3 h 35 | C1.2 |
| M04 | Prompt engineering : parler aux modèles | L015-L020 | 4 h 50 | C1.3 |
| M05 | L'IA au travail (cas d'usage par métier, productivité, relecture critique) | L021-L023 | 2 h 25 | C1.4 |
| M06 | Introduction à l'automatisation et aux agents (API, n8n, agents, MCP) | L024-L027 | 2 h 55 | C1.5 |
| M07 | Éthique, droit et sécurité de l'IA (RGPD/CNIL, AI Act, droit d'auteur, deepfakes, sécurité) | L028-L031 | 3 h 45 | C1.6 |
| | **Total leçons et exercices** | 31 leçons | **24 h 00** | |
| | Quiz de modules (7 × 15 min) et examen de niveau (60 min) | | ≈ 1 h (comptés dans les 25 h) | |

Chaque leçon affiche sa durée estimée (obligation FOAD) et comporte un exercice pratique, trois questions d'auto-évaluation et des liens vers la documentation officielle.

## Modalités d'évaluation

- **7 quiz de fin de module** (10 questions, seuil 70 %, tentatives illimitées avec explications) ; le module suivant se déverrouille après réussite du quiz.
- **Examen de niveau** : 40 questions, 60 min, seuil 70 %, surveillé à distance, 3 tentatives maximum (7 jours d'intervalle).
- **Épreuves pratiques** : atelier de 10 prompts (L020, journal des prompts évalué sur grille) ; étude de cas RGPD / AI Act avec charte d'usage simplifiée (L028-L029) ; étude de cas de vérification et correction d'une production IA.
- **Certification (option RS)** : entretien de 20 min devant un jury de 2 personnes (dont un professionnel externe). Toutes les compétences C1.1 à C1.6 doivent être validées (pas de compensation).
- Délivrables : certificat de réalisation (heures et résultats), attestation de fin de formation, certificat Next Formation Niveau 1, badge numérique (reconnaissance complémentaire).

## Certifications tierces visées (à passer en complément, à vos frais, hors Next Formation)

- Badges gratuits **Claude Academy** : « AI Fluency: Framework and foundations », « AI capabilities and limitations », « Claude 101 » (https://academy.claude.com/courses).
- Badge gratuit **OpenAI Academy** « AI Foundations » puis « Applied AI Foundations » et « Agents and Workflows » (https://academy.openai.com/pages/courses).
- **Google AI Essentials** (Coursera, ~49 $/mois après essai, audit gratuit) — https://www.coursera.org/google-specializations/ai-essentials-google.
- **Elements of AI** — « Introduction à l'IA » (gratuit, en français) — https://www.elementsofai.com/.
- Optionnel, orienté Azure : **Microsoft Certified: Azure AI Fundamentals (examen AI-901)**, préparation gratuite sur Microsoft Learn.

Les certificats Next Formation ne sont pas des équivalences de ces certifications (voir `referentiel/correspondance-certifications.md`).

## Matériel et logiciels nécessaires

- Ordinateur (Windows, macOS ou Linux) ou tablette avec navigateur récent, connexion internet, webcam et micro pour l'examen surveillé et l'entretien.
- **Comptes gratuits** à créer avant le module 3 : Claude (claude.ai), ChatGPT (chatgpt.com), Gemini (compte Google), Perplexity, Mistral Le Chat ; compte X pour Grok (offre gratuite limitée). Aucun abonnement payant n'est requis ; les offres payantes sont présentées à titre informatif (prix datés « nov. 2026 »).
- Module 6 : un compte **n8n Cloud en essai gratuit** (ou l'instance de démonstration fournie par Next Formation) pour le premier workflow (L025).
- Module 3 (L014) : outils d'image/vidéo/voix en versions gratuites ou démonstrations guidées par le formateur.
- Aucune installation logicielle, aucun langage de programmation.
