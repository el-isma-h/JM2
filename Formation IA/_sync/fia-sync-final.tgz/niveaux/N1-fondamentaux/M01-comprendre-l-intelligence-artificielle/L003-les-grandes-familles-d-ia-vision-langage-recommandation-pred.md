---
id: L003
module: M01
level: N1
title: "Les grandes familles d'IA : vision, langage, recommandation, prédiction"
minutes: 40
objectives:
  - "Identifier les quatre grandes familles d'applications de l'IA (vision, langage, recommandation, prédiction) et leurs tâches types"
  - "Associer un besoin métier concret à la famille d'IA et au type de modèle adaptés"
  - "Expliquer pourquoi les modèles multimodaux de 2026 brouillent les frontières entre familles"
skills: ["C1.1", "C1.2"]
sources:
  - { title: "Microsoft Learn — Guide d'étude AI-900 (domaines : vision, NLP, IA générative)", url: "https://learn.microsoft.com/certifications/resources/study-guides/AI-900", lang: "en" }
  - { title: "MIT 6.S191 — Introduction to Deep Learning (séances vision et séquences)", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "Harvard CS50's Introduction to Artificial Intelligence with Python", url: "https://pll.harvard.edu/course/cs50s-introduction-artificial-intelligence-Python", lang: "en" }
  - { title: "Microsoft — AI for Beginners (parties Computer Vision et NLP)", url: "https://github.com/microsoft/ai-for-beginners", lang: "en" }
  - { title: "Claude Platform — Choosing a model", url: "https://platform.claude.com/docs/en/about-claude/models/choosing-a-model", lang: "en" }
  - { title: "Ollama — catalogue de modèles ouverts", url: "https://ollama.com/search", lang: "en" }
---

# Les grandes familles d'IA : vision, langage, recommandation, prédiction

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 1

## 🎯 Ce que vous saurez faire
- Nommer les quatre grandes familles d'applications de l'IA et, pour chacune, trois tâches concrètes avec un exemple d'entreprise française.
- Face à un besoin (« je veux lire mes factures automatiquement », « je veux prévoir mes ventes »), dire quelle famille mobiliser et quel type d'outil regarder.
- Comprendre ce qu'est un modèle **multimodal** et pourquoi, en 2026, un même assistant peut voir, lire, écouter et écrire.

> 🧭 **En clair** — Pensez aux IA comme aux métiers d'un hôpital : il y a celle qui **regarde** (le radiologue : la vision), celle qui **lit et écrit** (la secrétaire médicale : le langage), celle qui **connaît vos habitudes** et vous oriente (l'accueil : la recommandation) et celle qui **fait des prévisions à partir de chiffres** (le gestionnaire : la prédiction). Chacune a sa spécialité et ses outils. Depuis peu, les assistants comme ChatGPT ou Claude savent faire un peu de tout à la fois — on dit qu'ils sont *multimodaux* — mais pour un travail répétitif et massif, le spécialiste reste souvent meilleur et moins cher.

## 1. Une carte pour s'orienter

La leçon précédente a montré *comment* une machine apprend. Celle-ci répond à la question *pour faire quoi ?* Les référentiels des certifications grand public — le guide d'étude Microsoft AI-900, Google AI Essentials — découpent le paysage de la même façon : par **type de donnée d'entrée** et par **type de sortie**. Nous retiendrons quatre familles principales, plus deux familles « transversales ».

> 💡 **Autrement dit** — Une IA, c'est un peu comme une machine à café : ce qu'on met dedans (l'**entrée** : des grains, ou ici une photo, un texte, un tableau de chiffres) et ce qui en sort (la **sortie** : un café, ou ici une étiquette, un résumé, une prévision). Les « référentiels » cités sont simplement les programmes officiels de certifications connues ; ils rangent les IA selon ce qu'elles reçoivent et ce qu'elles rendent.

```
            ENTRÉE                       FAMILLE                    SORTIE TYPIQUE
  image, vidéo, scan      ──►   👁  VISION PAR ORDINATEUR   ──►  étiquette, boîte, texte lu
  texte, parole           ──►   💬  LANGAGE (NLP / LLM)     ──►  classe, résumé, traduction, texte
  historique d'usages     ──►   🎯  RECOMMANDATION          ──►  classement personnalisé
  tableaux, séries        ──►   📈  PRÉDICTION (ML tabulaire)──►  nombre, probabilité, alerte
  ─────────────────────────────────────────────────────────────────────────────────
  tout                    ──►   🧩  GÉNÉRATIF MULTIMODAL    ──►  texte, image, son, vidéo, code
  un environnement        ──►   🤖  DÉCISION / ROBOTIQUE    ──►  une action
```

## 2. 👁 Vision par ordinateur (*computer vision*)

La machine « regarde » des pixels (les minuscules points de couleur qui composent une image numérique) et en tire du sens. Les grandes tâches, par difficulté croissante :

| Tâche | Question posée | Exemple professionnel français |
|---|---|---|
| **Classification d'images** | « Qu'est-ce que c'est ? » | Un négociant en vins trie les photos d'étiquettes par appellation |
| **Détection d'objets** | « Où sont les objets, et lesquels ? » | Une usine agroalimentaire compte les pièces sur un convoyeur et repère les défauts |
| **Segmentation** | « Quels pixels appartiennent à quoi ? » | Un cabinet de radiologie délimite une lésion sur une IRM |
| **OCR / lecture de documents** | « Que dit ce texte imprimé ou manuscrit ? » | Un cabinet comptable extrait montant, TVA et date de 2 000 factures fournisseurs par mois |
| **Reconnaissance faciale / biométrie** | « Qui est-ce ? » | Déverrouillage de téléphone ; attention : usage très encadré par le RGPD et l'AI Act (le règlement européen sur l'IA) (module 7) |

Technologie dominante : les **réseaux convolutifs** (CNN), stars de la révolution de 2012 (AlexNet) — le MIT 6.S191 leur consacre sa séance « Deep Computer Vision » — rejoints depuis par les *vision transformers*. Anecdote : le premier succès industriel du deep learning en vision date de 1998, lorsque le réseau LeNet de Yann LeCun lisait les chiffres manuscrits des chèques bancaires aux États-Unis.

> 💡 **Autrement dit** — Inutile de retenir ces noms techniques (CNN, *vision transformers*, LeNet) : ce sont les « moteurs » des IA de vision, un peu comme diesel, essence ou électrique pour une voiture. Ce qui compte pour vous, c'est ce que la voiture sait faire, pas le nom du moteur.

En 2026, l'OCR « classique » est largement remplacé par des modèles multimodaux : vous glissez la photo d'une facture dans Claude, Gemini ou ChatGPT et vous obtenez directement un tableau structuré. Pour un usage massif et confidentiel, des modèles ouverts à capacité visuelle (Qwen3.8, Gemma 4) tournent en local (directement sur vos propres ordinateurs, sans envoyer les données sur Internet) (niveau 2).

> ⚠️ **Piège fréquent** — Croire qu'un modèle de vision « comprend » la scène. Il associe des motifs de pixels à des étiquettes vues à l'entraînement. Un autocollant sur un panneau stop peut suffire à tromper un détecteur, et un modèle entraîné sur des visages majoritairement clairs reconnaît moins bien les peaux foncées — le lab 2 du MIT 6.S191 porte précisément sur ce biais algorithmique (une erreur systématique qui défavorise un groupe de personnes ; voir le lexique).

```quiz
{
  "type": "mise_en_situation",
  "q": "Un cabinet comptable veut récupérer automatiquement le montant, la TVA et la date de 2 000 factures scannées par mois. Quelle famille d'IA mobilise-t-il en premier ?",
  "options": [
    "La recommandation (suggestions personnalisées)",
    "La prédiction sur données tabulaires",
    "La vision par ordinateur (OCR)",
    "La robotique (automates physiques de tri)"
  ],
  "answer": 2,
  "explanation": "L'entrée est une image (le scan de la facture) et la sortie un texte lu : c'est la vision par ordinateur, plus précisément l'OCR, la « lecture » automatique de documents. En 2026, un assistant multimodal peut aussi le faire pour des volumes modestes."
}
```

## 3. 💬 Langage (*natural language processing*, NLP)

La famille qui a changé le travail de bureau. Avant 2018, chaque tâche avait son modèle spécialisé ; depuis les Transformers et les LLM (l'architecture de 2017 vue en L001, et les grands modèles de langage comme ChatGPT), un seul modèle généraliste accomplit la plupart d'entre elles.

| Tâche | Exemple professionnel |
|---|---|
| **Classification de texte / analyse de sentiment** | Une enseigne de magasins trie 10 000 avis clients en positifs, négatifs, à traiter en urgence |
| **Extraction d'entités** | Un service juridique repère noms, dates, montants et clauses dans des contrats |
| **Résumé** | Une DRH résume 40 pages de convention collective en une fiche |
| **Traduction** | Un artisan exporte vers l'Allemagne avec des devis traduits |
| **Question-réponse sur documents** | Un cabinet d'expertise interroge sa base de notes techniques (vous construirez cela au niveau 2, c'est le « RAG ») |
| **Génération** | Rédaction de fiches produit, d'e-mails, de comptes rendus, de code |
| **Parole** (*speech-to-text*, *text-to-speech*) : transformer la voix en texte, et le texte en voix | Transcription automatique de réunions ; serveur vocal d'un cabinet médical |

Les LLM de référence en novembre 2026 : Claude Fable 5.1, Opus 5.5, Sonnet 5.5 et Haiku 5.5 (Anthropic), la famille GPT-6 (OpenAI), Gemini 4 (Google), Grok 4.7 (xAI), Mistral Large 4 et Small 4 (Mistral AI, France) ; côté modèles à poids ouverts (que chacun peut télécharger et utiliser librement ; voir le lexique) : Qwen3.8, Gemma 4, gpt-oss, DeepSeek V4.1, Kimi K3, Llama 4. Le module 2 leur est entièrement consacré ; le module 3 vous apprendra à choisir entre eux.

> 💡 **Autrement dit** — Cette liste de noms ressemble à un catalogue de voitures : Claude, GPT, Gemini, Grok, Mistral sont des « marques » et les numéros sont des « modèles ». Vous n'avez rien à mémoriser ici ; le module 2 vous aidera à vous y retrouver.

> 🔗 **Documentation officielle** — [Claude Platform — Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model) 🇬🇧 présente la logique de choix entre un modèle rapide et économique (Haiku) et un modèle de raisonnement avancé (Opus, Fable) — exactement le type d'arbitrage que vous ferez au module 3.

## 4. 🎯 Recommandation

La famille la plus discrète et la plus rentable. Netflix, Amazon, Spotify, TikTok, mais aussi votre site de vente en ligne de pièces détachées : « les clients qui ont acheté ceci ont aussi acheté… ».

Deux grandes techniques, enseignées notamment dans la spécialisation *Machine Learning* d'Andrew Ng :
- **Filtrage collaboratif** : on ne regarde pas le contenu des produits, seulement les comportements. Si Marie et Paul ont acheté les mêmes six articles et que Marie en achète un septième, on le propose à Paul.
- **Recommandation basée sur le contenu** : on décrit les produits (catégorie, prix, mots-clés, et aujourd'hui *embeddings* — des vecteurs de sens que vous rencontrerez au niveau 2) et on propose ce qui ressemble à ce que l'utilisateur aime.

Exemple PME : une librairie indépendante de Lyon avec 30 000 références utilise un module de recommandation de sa plateforme e-commerce ; aucune donnée personnelle sensible, juste l'historique d'achats anonymisé. Point de vigilance : l'**effet bulle** (on ne propose que du semblable) et, pour les plateformes, les obligations de transparence des systèmes de recommandation prévues par le règlement européen sur les services numériques (DSA).

> 💡 **Autrement dit** — Le **filtrage collaboratif**, c'est le conseil du libraire qui vous dit : « les lecteurs qui ont aimé les mêmes livres que vous ont aussi adoré celui-ci » — sans jamais avoir ouvert le livre. La **recommandation basée sur le contenu**, c'est le libraire qui a lu le livre et vous dit : « c'est un polar nordique, comme ceux que vous aimez ».

```quiz
{
  "q": "Sur un site marchand, Marie et Paul ont acheté les six mêmes articles. Marie en achète un septième, que le site propose ensuite à Paul. Quelle technique est utilisée ?",
  "options": [
    "La recommandation basée sur le contenu",
    "La reconnaissance faciale",
    "La régression",
    "Le filtrage collaboratif"
  ],
  "answer": 3,
  "explanation": "Le site ne regarde pas ce que sont les articles : il compare les comportements d'achat de clients qui se ressemblent. C'est le filtrage collaboratif."
}
```

## 5. 📈 Prédiction sur données tabulaires

La famille historique du machine learning en entreprise, et de loin la plus répandue dans les PME, l'industrie et la banque. Les données sont des **tableaux** (lignes = observations, colonnes = variables) et la sortie, un nombre ou une probabilité.

| Besoin | Type | Exemple |
|---|---|---|
| Prévoir les ventes de la semaine prochaine | Régression / séries temporelles (des chiffres qui évoluent dans le temps, mois après mois) | Une boulangerie-pâtisserie ajuste sa production selon la météo et le calendrier |
| Estimer la probabilité qu'un client parte | Classification (*churn* = départ d'un client vers la concurrence) | Un opérateur télécom cible ses offres de rétention |
| Détecter une transaction frauduleuse | Classification / détection d'anomalie | Une banque bloque un paiement inhabituel en 50 millisecondes |
| Prédire la panne d'une machine | Maintenance prédictive | Un parc d'éoliennes planifie ses interventions |
| Évaluer un risque de crédit | Scoring (une note de risque) | Un organisme de crédit — usage classé **haut risque** par l'AI Act (module 7) |

Ici, ce ne sont pas les réseaux de neurones qui dominent mais des méthodes plus sobres et explicables : régression logistique, **arbres de décision** et forêts aléatoires, *gradient boosting* (XGBoost). Elles sont au programme de tous les cours d'introduction — MIT 6.036/6.390, Stanford CS229, cours 4 « Learning » de CS50 AI — et vous les pratiquerez au niveau 4. Avantage décisif en entreprise : on peut souvent **expliquer** pourquoi le modèle a décidé, ce que le RGPD et l'AI Act exigent dans de nombreux cas.

> 💡 **Autrement dit** — Ces noms (régression logistique, arbres de décision, forêts aléatoires, *gradient boosting*) sont des méthodes de calcul ; vous n'avez pas à les connaître à ce niveau. Retenez juste l'idée de l'**arbre de décision** : une suite de questions oui/non, comme un questionnaire — « Le client a-t-il déjà eu un retard de paiement ? Si oui, son crédit dépasse-t-il 10 000 € ? » Parce qu'on peut suivre chaque question, on peut **expliquer** la décision à la personne concernée, ce que la loi exige souvent.

> 💡 **À retenir** — Quatre familles, quatre entrées : pixels (vision), mots (langage), comportements (recommandation), tableaux (prédiction). Les LLM sont impressionnants, mais pour prévoir des ventes à partir d'un tableau Excel, un modèle de prédiction classique est souvent meilleur, moins cher et plus explicable.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour prévoir les ventes du mois prochain à partir d'un tableau Excel de cinq ans d'historique, un modèle de prédiction classique (régression, arbres de décision) est souvent plus adapté qu'un grand modèle de langage comme ChatGPT.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai. Pour des tableaux de chiffres, un modèle de prédiction classique est souvent plus précis, moins cher et plus facile à expliquer qu'un LLM. Les LLM brillent sur le texte, pas forcément sur les séries de chiffres."
}
```

## 6. Les familles transversales de 2026

### 6.1 Le génératif multimodal : la fusion des familles

Un modèle **multimodal** accepte plusieurs types d'entrées (texte, image, audio, vidéo, PDF) et produit plusieurs types de sorties. Les assistants actuels — Claude, ChatGPT, Gemini, Grok — lisent une photo de tableau blanc, écoutent un mémo vocal et répondent en texte ; des modèles dédiés génèrent images, vidéos et musique. Conséquence pour votre carte mentale : la frontière entre « vision » et « langage » s'efface **à l'usage**, mais pas dans l'architecture : un modèle multimodal reste un grand modèle de langage auquel on a greffé des « yeux » et des « oreilles ».

Trois réflexes :
1. Pour une tâche ponctuelle (lire une facture, décrire une photo), le modèle multimodal généraliste suffit.
2. Pour un flux industriel (100 000 images par jour, temps réel, confidentialité), un modèle de vision spécialisé reste plus pertinent et moins cher.
3. Tout contenu généré (image, voix, vidéo) relève d'obligations de transparence (AI Act art. 50, applicable depuis le 2 août 2026) — vous le verrez en L004 et au module 7.

### 6.2 Décision et robotique

L'apprentissage par renforcement et la planification (famille « recherche » des cours 6.034 et CS50 AI) servent à **agir** : piloter un robot d'entrepôt, optimiser une tournée de livraison, jouer au go. Les **agents IA** de 2026 — des LLM qui enchaînent eux-mêmes des actions (chercher sur le web, remplir un formulaire, lancer un programme) — appartiennent à cette logique de décision : vous les découvrirez au module 6. Pour fixer les idées : l'AI Index 2026 de Stanford relève que la réussite des agents sur le benchmark OSWorld (un test standardisé, sorte d'examen commun passé par toutes les IA) (tâches sur ordinateur) est passée d'environ 5 % en 2024 à 66,3 % en 2025, contre 72,35 % pour des humains (nov. 2026).

🎮 **Défi éclair** — Pour chaque besoin, trouvez la famille en moins de dix secondes : (a) « Repérer les colis abîmés sur la chaîne » ; (b) « Proposer la formation suivante à chaque salarié selon son parcours » ; (c) « Anticiper les retards de paiement » ; (d) « Rédiger les comptes rendus de réunion ». (Réponses : a vision ; b recommandation ; c prédiction tabulaire ; d langage génératif.)

> 🔗 **Documentation officielle** — Le [guide d'étude Microsoft AI-900](https://learn.microsoft.com/certifications/resources/study-guides/AI-900) 🇬🇧 liste les charges de travail IA (vision, NLP, documents, IA générative) et les six principes d'IA responsable de Microsoft ; ce référentiel (examen remplacé par AI-901 depuis juin 2026) reste une excellente grille de lecture. Le catalogue [Ollama — Search](https://ollama.com/search) 🇬🇧 montre concrètement les familles de modèles ouverts : texte, vision, embeddings, outils.

```mission
{
  "title": "Les six principes d'IA responsable de Microsoft",
  "url": "https://learn.microsoft.com/certifications/resources/study-guides/AI-900",
  "steps": ["Ouvrez le guide d'étude AI-900", "Repérez la partie consacrée aux charges de travail IA et aux considérations d'IA responsable", "Relevez la liste des principes"],
  "question": "Quels sont les six principes d'IA responsable cités par Microsoft ?",
  "hint": "Les termes sont en anglais : fairness, reliability and safety…",
  "answer": "Équité (fairness), fiabilité et sécurité (reliability and safety), confidentialité et sécurité des données (privacy and security), inclusion (inclusiveness), transparence (transparency), responsabilité (accountability) — guide du 2 mai 2025.",
  "xp": 15
}
```

```mission
{
  "title": "Feuilletez le rapport AI Index 2026 de Stanford",
  "url": "https://hai.stanford.edu/ai-index/2026-ai-index-report",
  "steps": ["Ouvrez la page du rapport AI Index 2026 de Stanford HAI", "Repérez la liste des chapitres", "Trouvez le chapitre consacré aux performances techniques"],
  "question": "Combien de chapitres compte le rapport, et comment s'appelle celui qui mesure les progrès de chaque famille d'IA ?",
  "hint": "Le titre du chapitre est cité dans la rubrique « Pour aller plus loin » de cette leçon.",
  "answer": "9 chapitres ; le chapitre « Technical Performance » (rapport publié en avril 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Vous êtes consultant pour **Menuiserie Dubois**, PME de 35 salariés en Loire-Atlantique (fabrication de fenêtres sur mesure, vente aux particuliers et aux artisans). La direction a listé six irritants :

1. Les devis sont saisis à la main à partir des croquis cotés envoyés par les artisans (photos de carnets).
2. Le service après-vente reçoit 60 e-mails par jour, dont un tiers de questions récurrentes.
3. Le stock de profilés aluminium est tantôt en rupture, tantôt pléthorique.
4. Le site e-commerce de quincaillerie vend 4 000 références, mais le panier moyen stagne.
5. Les techniciens photographient chaque pose ; personne ne vérifie la conformité avant la facturation.
6. La dirigeante voudrait un rapport hebdomadaire lisible à partir du tableau de bord Excel de production.

Pour chaque irritant, indiquez : **la famille d'IA**, **le type d'entrée et de sortie**, **si un assistant généraliste suffit ou s'il faut un modèle spécialisé**, et **un risque à surveiller**.

**Concrètement :** faites un tableau de 6 lignes (une par irritant) et 5 colonnes : n° · famille d'IA · ce qui entre → ce qui sort · assistant généraliste ou modèle spécialisé · un risque. Une phrase courte par case suffit. Les familles possibles sont celles de la carte du début de leçon : vision, langage, recommandation, prédiction, génératif multimodal, décision.

**Critères de réussite.**
- Les six irritants sont correctement rattachés à une famille (au moins quatre familles différentes apparaissent).
- Pour au moins deux irritants, vous expliquez pourquoi un LLM généraliste multimodal suffit ; pour au moins un, pourquoi un modèle spécialisé ou classique est préférable.
- Chaque ligne comporte un risque concret (hallucination, biais, confidentialité, explicabilité, coût).

<details>
<summary>Pistes de corrigé</summary>

| # | Famille | Entrée → sortie | Généraliste ou spécialisé | Risque |
|---|---|---|---|---|
| 1 | Vision multimodale (lecture de croquis) | Photo → cotes structurées | Généraliste multimodal pour commencer, avec validation humaine | Erreur de cote → fenêtre inutilisable : contrôle obligatoire |
| 2 | Langage | E-mail → classe + brouillon | Généraliste (LLM) | Hallucination de délai ; données clients dans le prompt (RGPD) |
| 3 | Prédiction tabulaire | Historique de ventes, saisonnalité → quantité | Modèle classique (régression / séries temporelles) | Données historiques incomplètes ; sur-apprentissage |
| 4 | Recommandation | Historique d'achats → suggestions | Module e-commerce existant (filtrage collaboratif) | Effet bulle, faible volume de données |
| 5 | Vision (détection) | Photos de pose → conforme / non conforme | Spécialisé si volume ; généraliste multimodal en pilote | Biais d'éclairage, faux positifs ; photos de domiciles (RGPD) |
| 6 | Langage génératif + analyse de données | Tableau → rapport rédigé | Généraliste | Chiffres mal recopiés : vérifier les totaux |

</details>

## ✅ Auto-évaluation express

1. Quelle famille d'IA mobilisez-vous pour estimer, à partir d'un historique de 5 ans, le chiffre d'affaires du mois prochain ?
2. Un modèle multimodal est-il un modèle de vision ou un modèle de langage ?
3. Pourquoi préfère-t-on souvent un arbre de décision à un réseau de neurones pour un scoring de crédit ?

<details>
<summary>Réponses</summary>

1. La prédiction sur données tabulaires (régression / séries temporelles), pas un LLM.
2. C'est d'abord un grand modèle de langage auquel on a ajouté des entrées image et audio ; à l'usage, il couvre les deux familles.
3. Parce que sa décision est explicable, ce que le RGPD et l'AI Act exigent pour un usage à haut risque comme le crédit, et parce qu'il est souvent aussi performant sur des données tabulaires.

</details>

> ✅ **Si vous ne retenez que 3 choses** — 1. Quatre grandes familles, selon ce qu'on donne à l'IA : des images (vision), des mots (langage), des habitudes d'achat ou de clic (recommandation), des tableaux de chiffres (prédiction). 2. Les assistants comme ChatGPT ou Claude sont « multimodaux » : ils savent un peu tout faire, mais pour un travail massif et répétitif, un outil spécialisé reste souvent meilleur et moins cher. 3. Pour prévoir des chiffres (ventes, retards de paiement), une méthode classique et explicable bat souvent un LLM.

## 📚 Pour aller plus loin
- [Harvard CS50 AI — Introduction to Artificial Intelligence with Python](https://pll.harvard.edu/course/cs50s-introduction-artificial-intelligence-Python) 🇬🇧 — sept semaines (recherche, connaissance, incertitude, optimisation, apprentissage, réseaux de neurones, langage) ; audit gratuit.
- [Microsoft — AI for Beginners](https://github.com/microsoft/ai-for-beginners) 🇬🇧 — parties IV « Computer Vision » et V « NLP », avec notebooks (licence MIT).
- [MIT 6.S191 — Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 — séances « Deep Computer Vision », « Deep Sequence Modeling » et « Deep Reinforcement Learning ».
- [Stanford HAI — AI Index Report 2026](https://hai.stanford.edu/ai-index/2026-ai-index-report) 🇬🇧 — chapitre « Technical Performance » : où en est chaque famille.

> 🗺️ **Et maintenant ?** — Vous avez la carte des familles d'IA ; la leçon L004 démêle les mythes et les chiffres clés de 2026 pour en parler avec justesse.
