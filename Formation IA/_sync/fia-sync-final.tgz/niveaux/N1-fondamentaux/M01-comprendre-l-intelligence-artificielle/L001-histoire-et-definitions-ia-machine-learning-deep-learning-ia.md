---
id: L001
module: M01
level: N1
title: "Histoire et définitions : IA, machine learning, deep learning, IA générative"
minutes: 45
objectives:
  - "Distinguer les quatre notions emboîtées : intelligence artificielle, machine learning, deep learning et IA générative"
  - "Situer les dix dates clés de l'histoire de l'IA, de Turing (1950) aux modèles de 2026"
  - "Reconnaître dans un exemple professionnel à quelle famille appartient un système d'IA"
skills: ["C1.1"]
sources:
  - { title: "MIT 6.S191 — Introduction to Deep Learning (2026)", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "MIT OCW 6.034 — Artificial Intelligence (Patrick Winston)", url: "https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/pages/syllabus/", lang: "en" }
  - { title: "MIT OCW 6.S087 — Foundation Models and Generative AI", url: "https://ocw.mit.edu/courses/6-s087-foundation-models-and-generative-ai-january-iap-2024/", lang: "en" }
  - { title: "Elements of AI (version française)", url: "https://www.elementsofai.com/", lang: "fr" }
  - { title: "Microsoft — AI for Beginners", url: "https://github.com/microsoft/ai-for-beginners", lang: "en" }
  - { title: "Claude Academy — AI Fluency: Framework and Foundations", url: "https://academy.claude.com/courses/ai-fluency-framework-foundations", lang: "en" }
---

# Histoire et définitions : IA, machine learning, deep learning, IA générative

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 1

## 🎯 Ce que vous saurez faire
- Expliquer avec vos propres mots la différence entre *intelligence artificielle*, *machine learning*, *deep learning* et *IA générative*, et dessiner le schéma des « poupées russes » qui les relie.
- Raconter l'histoire de l'IA en dix dates exactes, sans confondre les époques ni les héros.
- Classer un outil que vous utilisez au travail (filtre anti-spam, GPS, ChatGPT, Claude…) dans la bonne famille.

> 🧭 **En clair** — « L'IA », c'est un grand rayon de supermarché qui contient plusieurs étagères. Sur la première, des programmes qui suivent des règles écrites à la main, comme le GPS qui calcule un trajet. Sur la deuxième, des programmes qui apprennent à partir d'exemples, comme le filtre anti-spam (c'est le *machine learning*). Sur une étagère encore plus précise, des programmes qui apprennent avec d'immenses « réseaux de neurones » (le *deep learning*). Et tout au bout, ceux qui fabriquent du contenu neuf — textes, images, sons : c'est l'IA générative, celle de ChatGPT ou de Claude. Savoir sur quelle étagère se trouve un outil, c'est déjà savoir ce qu'on peut en attendre.

## 1. Quatre mots, quatre poupées russes

Au café, « l'IA » désigne tout et n'importe quoi : le robot de science-fiction, l'assistant vocal du téléphone, le chatbot qui rédige vos e-mails. Pour travailler sérieusement avec ces outils, il faut d'abord ranger le vocabulaire. Les quatre termes du titre de cette leçon ne sont pas des synonymes : ce sont des **ensembles emboîtés**, comme des poupées russes.

```
┌──────────────────────────────────────────────────────────┐
│ INTELLIGENCE ARTIFICIELLE (IA)                           │
│  « faire faire à une machine ce qui demande de           │
│  l'intelligence à un humain » — règles, recherche, logique│
│  ┌────────────────────────────────────────────────────┐  │
│  │ MACHINE LEARNING (apprentissage automatique)       │  │
│  │  la machine apprend des régularités dans des données│  │
│  │  ┌──────────────────────────────────────────────┐  │  │
│  │  │ DEEP LEARNING (apprentissage profond)        │  │  │
│  │  │  réseaux de neurones à nombreuses couches     │  │  │
│  │  │  ┌────────────────────────────────────────┐  │  │  │
│  │  │  │ IA GÉNÉRATIVE                          │  │  │  │
│  │  │  │  produit du nouveau contenu : texte,   │  │  │  │
│  │  │  │  image, son, code (ChatGPT, Claude…)   │  │  │  │
│  │  │  └────────────────────────────────────────┘  │  │  │
│  │  └──────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

### 1.1 Intelligence artificielle (IA) : le grand parapluie

L'expression *artificial intelligence* est née en 1956, dans la proposition d'un atelier d'été au Dartmouth College (États-Unis), rédigée notamment par John McCarthy, Marvin Minsky, Claude Shannon et Nathaniel Rochester. L'ambition affichée : décrire chaque aspect de l'intelligence si précisément qu'une machine puisse le simuler. Aujourd'hui, le terme désigne **tout programme qui accomplit une tâche réputée demander de l'intelligence** : jouer aux échecs, traduire, reconnaître un visage, planifier un trajet.

Point important : une IA **n'apprend pas forcément**. Le GPS de votre voiture calcule le meilleur itinéraire grâce à un algorithme de recherche (une méthode de calcul qui essaie méthodiquement les chemins possibles pour garder le meilleur ; voir le lexique) (le même principe que celui enseigné dans le cours 6.034 du MIT ou dans CS50 AI de Harvard) ; il ne s'est jamais « entraîné » sur vos trajets. On parle d'**IA symbolique** ou de « bonne vieille IA » : des règles écrites à la main par des experts. Les premiers **systèmes experts** médicaux des années 1970-1980 fonctionnaient ainsi, avec des centaines de règles « SI fièvre ET toux ALORS… ».

### 1.2 Machine learning : la machine apprend des exemples

Avec le *machine learning* (ML, apprentissage automatique), on change de méthode : au lieu d'écrire les règles, **on fournit des exemples et la machine trouve les règles elle-même**. L'informaticien américain Arthur Samuel, qui faisait apprendre le jeu de dames à un ordinateur IBM dès la fin des années 1950, est souvent cité pour cette idée : donner aux ordinateurs la capacité d'apprendre sans être explicitement programmés.

Analogie du quotidien : pour apprendre à un enfant ce qu'est un chat, vous ne lui dictez pas « quatre pattes, moustaches, queue, oreilles pointues » (le chien aurait trois critères sur quatre). Vous lui montrez des chats. Beaucoup de chats. Le ML fait pareil avec des milliers d'exemples étiquetés (c'est-à-dire accompagnés de la bonne réponse : « ceci est un chat », « ceci n'en est pas un »).

Exemple professionnel : le **filtre anti-spam** de votre messagerie est du machine learning classique. Il a vu des millions d'e-mails marqués « spam » ou « légitime » et a appris quels mots, expéditeurs et structures sont suspects. La leçon suivante (L002) détaille comment se passe cet apprentissage.

### 1.3 Deep learning : des réseaux de neurones empilés

Le *deep learning* (apprentissage profond) est **une famille de méthodes du machine learning** fondée sur les **réseaux de neurones artificiels** : des couches de petites unités de calcul inspirées — très librement — des neurones biologiques. « Profond » signifie simplement **beaucoup de couches** (des dizaines, voire des centaines). Chaque couche extrait des caractéristiques de plus en plus abstraites : pour une photo, la première couche repère des contours, la suivante des formes, puis des yeux, puis un visage.

Pourquoi cette famille a-t-elle tout emporté depuis 2012 ? Trois ingrédients réunis au même moment : des **données** massives (Internet), de la **puissance de calcul** (les cartes graphiques, GPU, conçues pour les jeux vidéo) et des **algorithmes** affinés depuis les années 1980 (la rétropropagation du gradient — la méthode qui permet au réseau de corriger ses erreurs petit à petit, voir le lexique, que vous rencontrerez en L002). Le cours MIT 6.S191 consacre sa toute première séance à ce trio.

> 💡 **Autrement dit** — Pensez à un gâteau : il faut des **ingrédients** (les données), un **four** assez puissant (les cartes graphiques, ces puces d'abord conçues pour les jeux vidéo) et une **recette** (les algorithmes). La recette existait depuis les années 1980, mais il manquait les ingrédients en quantité et le four. En 2012, les trois étaient enfin réunis.

### 1.4 IA générative : la machine produit du contenu

L'**IA générative** est le sous-ensemble du deep learning dont les modèles **créent du contenu nouveau** — texte, image, musique, vidéo, code — plutôt que de classer ou de prédire une étiquette. ChatGPT, Claude, Gemini, Grok, Mistral, Midjourney ou Suno en font partie. Un **grand modèle de langage** (*large language model*, LLM) est un modèle génératif spécialisé dans le texte : il a appris, sur une gigantesque quantité de textes, à prédire le mot suivant, et cette capacité en apparence modeste suffit pour rédiger, résumer, traduire ou coder.

> 💡 **À retenir** — IA ⊃ machine learning ⊃ deep learning ⊃ IA générative. Tout LLM est une IA, mais toute IA n'est pas un LLM : votre GPS, votre filtre anti-spam et Claude sont trois « IA » qui n'ont presque rien en commun techniquement.

> ⚠️ **Piège fréquent** — Dire « l'IA » pour parler uniquement de ChatGPT. Dans une réunion, précisez toujours de quelle famille il s'agit : un logiciel de détection de fraude bancaire (ML classique) ne présente pas les mêmes risques ni les mêmes coûts qu'un assistant génératif.

```quiz
{
  "type": "mise_en_situation",
  "q": "Votre banque bloque votre carte après un achat inhabituel. Son logiciel a appris à repérer les fraudes en étudiant des millions d'anciennes transactions. Dans quelle famille le rangez-vous ?",
  "options": [
    "IA symbolique (règles écrites à la main)",
    "IA générative",
    "Machine learning classique",
    "Ce n'est pas de l'IA"
  ],
  "answer": 2,
  "explanation": "Le logiciel a appris des régularités à partir d'exemples chiffrés (transactions normales ou frauduleuses) : c'est du machine learning classique. Il ne crée aucun contenu, donc ce n'est pas de l'IA générative."
}
```

## 2. Soixante-quinze ans d'histoire en dix dates

L'IA a connu des étés enthousiastes et des **hivers** (*AI winters*) où les financements se sont taris parce que les promesses n'étaient pas tenues. Connaître cette chronologie vous protège du double piège de l'emballement et du scepticisme.

| Année | Événement | Pourquoi c'est important |
|---|---|---|
| **1950** | Alan Turing publie *Computing Machinery and Intelligence* et propose le « jeu de l'imitation » (test de Turing) | Première formulation sérieuse de la question « une machine peut-elle penser ? » |
| **1956** | Atelier de Dartmouth : le terme *artificial intelligence* est officialisé | Naissance de la discipline |
| **1957-1958** | Frank Rosenblatt présente le **perceptron**, ancêtre du neurone artificiel (une minuscule unité de calcul qui imite très grossièrement un neurone) | Premier modèle qui apprend ses poids (ses réglages internes) à partir d'exemples |
| **1966** | ELIZA (Joseph Weizenbaum, MIT) simule un psychothérapeute par simples règles de reformulation | Premier « chatbot » ; déjà, des utilisateurs s'y attachent — l'« effet ELIZA » |
| **1974-1980 puis 1987-1993** | Deux hivers de l'IA | Les promesses excessives (traduction automatique, systèmes experts) déçoivent, les budgets chutent |
| **1986** | Rumelhart, Hinton et Williams popularisent la **rétropropagation** pour entraîner des réseaux multicouches | L'algorithme qui fait encore tourner le deep learning en 2026 |
| **1997** | Deep Blue (IBM) bat le champion du monde d'échecs Garry Kasparov | Triomphe de l'IA symbolique et de la force de calcul (pas d'apprentissage) |
| **2012** | AlexNet (Krizhevsky, Sutskever, Hinton) écrase la compétition de reconnaissance d'images ImageNet grâce à un réseau profond sur GPU | Point de départ de la vague deep learning |
| **2016** | AlphaGo (DeepMind) bat Lee Sedol au jeu de go, 4 parties à 1 | Combinaison deep learning + apprentissage par renforcement (apprendre par essais, erreurs et récompenses) sur un jeu jugé hors de portée |
| **2017** | Article *Attention Is All You Need* (Vaswani et al., Google) : l'architecture **Transformer** | Le « T » de GPT ; base de tous les LLM actuels |
| **30 nov. 2022** | Lancement public de ChatGPT (OpenAI) | L'IA générative entre dans le grand public ; adoption la plus rapide de l'histoire du numérique |
| **2024** | Prix Nobel de physique à John Hopfield et Geoffrey Hinton (réseaux de neurones) ; prix Nobel de chimie à Demis Hassabis et John Jumper (AlphaFold) avec David Baker | L'IA reconnue comme science fondamentale |
| **2026** | Génération actuelle : Claude Fable 5.1 / Opus 5.5 / Sonnet 5.5 / Haiku 5.5 (Anthropic), famille GPT-6 (OpenAI), Gemini 4 (Google), Grok 4.7 (xAI), Mistral Large 4 ; modèles ouverts Qwen3.8, Gemma 4, DeepSeek V4.1, Kimi K3 (nov. 2026) | Fenêtres de contexte d'un million de tokens, agents capables d'exécuter des tâches de plusieurs heures |

> 💡 **Autrement dit** — Pas de panique devant la dernière ligne du tableau : « Claude Opus 5.5 », « GPT-6 » ou « Gemini 4 » sont des noms de produits, comme des modèles de voiture ; inutile de les apprendre. Une **fenêtre de contexte** d'un million de tokens veut dire que l'IA peut avoir sous les yeux, en une fois, l'équivalent de plusieurs gros romans ; un **agent** est une IA qui enchaîne seule plusieurs étapes d'un travail. Vous reverrez ces deux notions aux modules 2 et 6.

🎮 **Défi** — Sans regarder le tableau, placez dans l'ordre : AlphaGo, Deep Blue, ChatGPT, Dartmouth, le Transformer. (Réponse : Dartmouth 1956 → Deep Blue 1997 → AlphaGo 2016 → Transformer 2017 → ChatGPT 2022.)

Anecdote exacte : en 1965, Herbert Simon, futur prix Nobel d'économie, prédisait que les machines seraient capables « d'ici vingt ans » de faire tout travail qu'un homme peut faire. Il s'est trompé de plusieurs décennies — et c'est précisément ce genre d'annonce qui a déclenché le premier hiver. Gardez ce réflexe : **une démonstration spectaculaire n'est pas un déploiement industriel**.

> 🔗 **Documentation officielle** — Le cours [MIT 6.S191 — Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 (supports sous licence MIT) retrace ce basculement vers le deep learning dans sa première séance ; le cours historique [MIT OCW 6.034 — Artificial Intelligence](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/pages/syllabus/) 🇬🇧 de Patrick Winston couvre l'IA symbolique (recherche, règles, contraintes).

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : Deep Blue, l'ordinateur d'IBM qui a battu Garry Kasparov en 1997, avait appris à jouer aux échecs en s'entraînant tout seul sur des millions de parties.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Deep Blue est un triomphe de l'IA symbolique et de la force de calcul : il explorait énormément de coups possibles selon des règles écrites par des humains, sans apprentissage. C'est AlphaGo (2016) qui a combiné deep learning et apprentissage par renforcement."
}
```

## 3. Trois approches, trois façons de « réfléchir »

Pour affiner, les chercheurs distinguent trois grandes approches qui coexistent dans les produits de 2026.

| Approche | Comment la machine « sait » | Exemple vécu | Force | Faiblesse |
|---|---|---|---|---|
| **Symbolique** (règles, logique, recherche) | Un humain écrit les règles | GPS, moteur de règles d'un logiciel de paie, Deep Blue | Explicable, prévisible | Ne gère pas l'imprévu, coûteux à maintenir |
| **Statistique / ML classique** | Elle apprend des régularités chiffrées dans des tableaux de données | Scoring crédit, anti-spam, prévision des ventes | Efficace sur des données structurées, peu gourmande | Demande des caractéristiques préparées à la main |
| **Connexionniste / deep learning** | Des millions de paramètres ajustés sur des données brutes (pixels, mots, sons) | Reconnaissance faciale, traduction, Claude, ChatGPT | Traite l'image, le son, le langage naturel | Opaque, gourmande en données et en calcul, peut « halluciner » |

> 💡 **Autrement dit** — Imaginez trois cuisiniers. Le **symbolique** suit la recette écrite à la lettre : fiable, mais perdu si un ingrédient manque. Le **ML classique** a appris à partir de fiches bien remplies, comme des tableaux Excel (on parle de « données structurées ») : très efficace sur ces fiches-là. Le **deep learning** a goûté des millions de plats et se débrouille avec n'importe quoi (photos, voix, textes), mais il est incapable d'expliquer pourquoi, et il lui arrive d'« halluciner », c'est-à-dire d'inventer avec aplomb.

Dans une PME française typique, les trois cohabitent : le logiciel de comptabilité applique des règles fiscales (symbolique), l'outil de relance client classe les factures à risque (ML classique) et l'assistant qui rédige le brouillon de relance est un LLM (deep learning génératif).

> ⚠️ **Piège fréquent** — Croire qu'un LLM « raisonne » comme un logiciel de règles. Un LLM produit la suite de mots la plus probable ; il peut écrire avec aplomb une règle fiscale fausse. Vous apprendrez en L002 et au module 2 pourquoi, et au module 5 comment vérifier.

```quiz
{
  "q": "Pourquoi un assistant comme ChatGPT ou Claude peut-il vous citer avec assurance une règle fiscale qui n'existe pas ?",
  "options": [
    "Parce qu'il produit la suite la plus probable, sans la vérifier",
    "Parce qu'il consulte une base de lois qui contient des erreurs",
    "Parce qu'il cherche à vous tromper volontairement",
    "Parce que sa connexion Internet était coupée"
  ],
  "answer": 0,
  "explanation": "Un LLM ne « consulte » pas de règles comme un logiciel de paie : il enchaîne les mots les plus probables. Une phrase peut donc être parfaitement crédible et pourtant fausse — d'où l'importance de vérifier."
}
```

## 4. Vocabulaire minimal pour la suite du parcours

- **Modèle** : le programme obtenu après apprentissage (un fichier de paramètres plus un peu de code).
- **Paramètres** (*weights*) : les nombres ajustés pendant l'entraînement ; on parle de milliards (B) pour les LLM (B pour *billion*, qui veut dire « milliard » en anglais : un modèle « 70B » a 70 milliards de paramètres).
- **Entraînement** / **inférence** : la phase d'apprentissage, coûteuse et rare ; puis la phase d'utilisation, à chaque question posée (détail en L002).
- **Données d'entraînement** : les exemples montrés au modèle ; leur qualité fait celle du modèle.
- **Token** : l'unité de texte manipulée par un LLM (environ trois quarts d'un mot anglais ; le français en consomme 30 à 50 % de plus). Vous y reviendrez en module 2.
- **Modèle de fondation** (*foundation model*) : grand modèle entraîné une fois sur des données générales, puis adapté à mille usages — le cours MIT 6.S087 lui est entièrement consacré.

> 🔗 **Documentation officielle** — [MIT OCW 6.S087 — Foundation Models and Generative AI](https://ocw.mit.edu/courses/6-s087-foundation-models-and-generative-ai-january-iap-2024/) 🇬🇧, cours non technique sur l'histoire de l'IA et les modèles de fondation ; [Microsoft — AI for Beginners](https://github.com/microsoft/ai-for-beginners) 🇬🇧 (licence MIT), dont la première partie « Intro & History » et la deuxième « Symbolic AI » complètent cette leçon.

```mission
{
  "title": "Combien de chapitres compte le cours gratuit Elements of AI ?",
  "url": "https://digital-skills-jobs.europa.eu/en/learning-space/training-catalogue/elements-ai",
  "steps": ["Ouvrez la fiche Elements of AI du catalogue européen Digital Skills & Jobs", "Repérez le résumé du cours (durée, prix, contenu)", "Relevez le nombre de chapitres et la durée indicative"],
  "question": "En combien de chapitres le cours est-il découpé, et combien de temps faut-il compter environ ?",
  "hint": "La fiche précise aussi que le cours est gratuit ; la version française est accessible depuis https://www.elementsofai.com/.",
  "answer": "6 chapitres, environ 4 semaines, gratuit (relevé du 1er nov. 2026 — vérifiez, la fiche peut évoluer).",
  "xp": 10
}
```

```mission
{
  "title": "Les « 4 D » du cours AI Fluency d'Anthropic",
  "url": "https://academy.claude.com/courses/ai-fluency-framework-foundations",
  "steps": ["Ouvrez la page du cours AI Fluency: Framework and Foundations sur Claude Academy", "Lisez la présentation du cours", "Repérez le nom du cadre proposé et ses quatre composantes"],
  "question": "Quels sont les quatre mots commençant par « D » qui structurent ce cours (en anglais Delegation, Description…) ?",
  "hint": "Le cadre s'appelle « 4D ». Deux des mots sont donnés dans la question.",
  "answer": "Délégation, Description, Discernement, Diligence (cours d'environ 4 h, état au 1er nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Listez cinq outils numériques que vous utilisez dans votre activité (ou votre vie quotidienne) et qui contiennent « de l'IA » : par exemple la suggestion de mots du clavier du téléphone, le GPS, le filtre anti-spam, la recommandation de vidéos, un assistant conversationnel, la détection de fraude de votre banque, un logiciel de reconnaissance de caractères sur une facture.

Pour chacun, remplissez un tableau à quatre colonnes : **Outil · Famille (symbolique / ML classique / deep learning / IA générative) · Indice qui justifie votre choix · Ce que l'outil produit (une décision, un score, un contenu ?)**.

**Concrètement :** un simple tableau sur papier ou dans un document Word suffit (5 lignes, 4 colonnes), comptez 15 minutes. Pour choisir la famille, posez-vous deux questions : l'outil s'améliore-t-il en observant des exemples ou vos habitudes ? (si oui : ML classique ou deep learning) ; fabrique-t-il un contenu nouveau, comme un texte ou une image ? (si oui : IA générative). S'il se contente d'appliquer une règle fixe, c'est du symbolique. En cas de doute, notez votre hésitation dans la colonne « Indice » : c'est accepté.

**Critères de réussite.**
1. Les cinq outils sont classés et au moins trois familles différentes apparaissent.
2. Chaque classement s'appuie sur un indice concret (« il a appris sur mes e-mails », « il génère un texte nouveau », « il applique une règle fixe »).
3. Vous avez repéré au moins un outil qui mélange deux familles (un GPS avec prévision de trafic apprise, par exemple).

<details>
<summary>Corrigé indicatif</summary>

| Outil | Famille | Indice | Produit |
|---|---|---|---|
| GPS (calcul d'itinéraire) | Symbolique (recherche de chemin) ; la prévision de trafic est du ML | Règle fixe : plus court chemin ; le trafic est appris sur l'historique | Une décision (itinéraire) |
| Filtre anti-spam | ML classique | Il s'améliore quand vous signalez un spam | Un score / une classe |
| Clavier prédictif | Deep learning (petit modèle de langage) | Propose le mot suivant selon le contexte | Un contenu court |
| Recommandation de vidéos | ML / deep learning | Apprend de vos clics et de ceux des autres | Un classement |
| Claude / ChatGPT | IA générative (LLM) | Rédige un texte inédit | Un contenu |
| OCR de factures | Deep learning (vision) | Lit des images de caractères variés | Un texte extrait |

</details>

## ✅ Auto-évaluation express

1. Le deep learning est-il un sous-ensemble du machine learning, ou l'inverse ?
2. Quel événement de 2017 est à l'origine de l'architecture de tous les LLM actuels ?
3. Un moteur de règles de paie qui applique le Code du travail est-il de l'IA générative ?

<details>
<summary>Réponses</summary>

1. Le deep learning est un sous-ensemble du machine learning (réseaux de neurones à nombreuses couches).
2. La publication de l'article *Attention Is All You Need* qui introduit le Transformer.
3. Non : c'est de l'IA symbolique (règles écrites par des humains) ; il ne génère pas de contenu nouveau et n'apprend pas.

</details>

> ✅ **Si vous ne retenez que 3 choses** — 1. L'IA est un grand ensemble qui contient le machine learning, qui contient le deep learning, qui contient l'IA générative (les poupées russes). 2. Toutes les IA n'apprennent pas : le GPS suit des règles, l'anti-spam a appris sur des exemples, ChatGPT ou Claude fabriquent du contenu nouveau. 3. Une démonstration spectaculaire n'est pas une garantie : un LLM peut affirmer avec assurance une chose fausse, il faut toujours vérifier.

## 📚 Pour aller plus loin
- [Elements of AI — Introduction à l'IA](https://www.elementsofai.com/) 🇫🇷 — le MOOC gratuit de l'université d'Helsinki, disponible en français (Sorbonne Université) ; chapitre 1 « Qu'est-ce que l'IA ? ».
- [Claude Academy — AI Fluency: Framework and Foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations) 🇬🇧 — cours gratuit d'Anthropic (badge) sur les fondamentaux de la collaboration avec l'IA ; nous vous encourageons à le suivre en parallèle de ce niveau.
- [MIT OCW RES.6-013 — AI 101](https://ocw.mit.edu/courses/res-6-013-ai-101-fall-2021/) 🇬🇧 — atelier vidéo grand public du MIT.
- [DeepLearning.AI — AI For Everyone](https://www.deeplearning.ai/courses/ai-for-everyone) 🇬🇧 — le cours d'Andrew Ng pour non-techniciens (semaine 1 : « Qu'est-ce que l'IA ? »).

> 🗺️ **Et maintenant ?** — Vous savez ranger les IA sur leurs étagères ; la leçon L002 ouvre le capot du *machine learning* pour voir comment une machine « apprend » réellement à partir d'exemples.
