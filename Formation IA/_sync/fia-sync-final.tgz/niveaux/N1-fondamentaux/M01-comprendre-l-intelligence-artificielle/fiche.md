---
module: M01
title: "Fiche mémo — Comprendre l'intelligence artificielle"
---
# Fiche mémo — M01 · Comprendre l'intelligence artificielle

> En une phrase : l'IA est un grand rayon à étagères emboîtées ; un LLM apprend une fois (cher), répond des milliards de fois (pas cher), et produit le plus plausible, pas forcément le vrai.

## Les 7 idées à retenir
1. **Poupées russes** : IA ⊃ machine learning ⊃ deep learning ⊃ IA générative. Le GPS, l'anti-spam et Claude sont trois « IA » très différentes (`L001`).
2. **Une IA n'apprend pas forcément** : l'IA symbolique applique des règles écrites à la main (GPS, logiciel de paie, Deep Blue en 1997) (`L001`).
3. **Le deep learning a gagné en 2012** grâce au trio données + GPU + algorithmes : ingrédients, four, recette (`L001`).
4. **Le cycle** : données → entraînement → modèle (un fichier de nombres) → inférence. Pendant que vous discutez, le modèle **n'apprend pas** (`L002`).
5. **Trois façons d'apprendre** : supervisé (avec la bonne réponse), non supervisé (sans réponse, on cherche des groupes), par renforcement (récompenses) (`L002`).
6. **Quatre familles, quatre entrées** : pixels → vision, mots → langage, comportements → recommandation, tableaux → prédiction. Pour prévoir des ventes depuis un tableau Excel, un modèle classique bat souvent un LLM (`L003`).
7. **Trois questions anti-mythe** : de quelle famille parle-t-on ? Entraînée sur quelles données ? Qui a mesuré le résultat, et comment ? (`L004`)

## Le schéma à connaître

```mermaid
flowchart LR
  A["Données<br/>(exemples)"] --> B["Entraînement<br/>essayer, mesurer, corriger"]
  B --> C["Modèle<br/>fichier de paramètres"]
  C --> D["Inférence<br/>une question, une réponse"]
  D -. "retours, nouvelles données" .-> A
```

Pour un LLM, l'entraînement se fait en 3 temps : **pré-entraînement** (lire la bibliothèque) → **ajustement supervisé** (imiter un tuteur) → **RLHF** (retours « celle-ci est meilleure ») (`L002`).

## Vocabulaire express
| Terme | En clair |
|---|---|
| Paramètres (poids) | Les millions de « boutons » réglés pendant l'entraînement |
| Descente de gradient | Descendre la montagne dans le brouillard, pas à pas, là où ça descend le plus |
| Sur-apprentissage | L'élève qui récite le corrigé de l'an dernier et rate le nouveau sujet |
| Inférence | L'utilisation du modèle : il répond sans réapprendre |
| Date de connaissance | Le jour où le modèle a arrêté de « lire » ; après, il ne sait rien sauf si on le lui donne |
| Multimodal | Un LLM à qui on a greffé des « yeux » et des « oreilles » (texte, image, audio, PDF) |
| Déployeur | L'entreprise qui *utilise* un système d'IA (le fournisseur, lui, le développe) |

## Les pièges classiques
- Dire « l'IA » pour parler seulement de ChatGPT : un détecteur de fraude n'a ni les mêmes risques ni les mêmes coûts.
- Croire que Deep Blue « avait appris » : c'était de la force de calcul et des règles. C'est AlphaGo (2016) qui apprenait.
- Croire qu'un LLM « cherche dans une base » : il **génère**, token après token, même un numéro d'article de loi.
- Croire que l'assistant apprend en direct : c'est la fenêtre de contexte qui donne l'illusion de mémoire.
- « L'AI Act, c'est pour Google » : un cabinet comptable qui utilise un assistant est **déployeur**.

## Les commandes / chiffres / dates utiles
- **Les dates en 5 marches** : *naissance* (Turing 1950, Dartmouth 1956) → *recette* (rétropropagation 1986) → *force brute* (Deep Blue 1997) → *déclic* (AlexNet 2012) → *grand public* (AlphaGo 2016, Transformer 2017, ChatGPT 30 nov. 2022).
- 2024 : Nobel de physique (Hopfield, Hinton) et de chimie (Hassabis, Jumper, avec Baker).
- IA générative : **53 %** d'adoption en 3 ans (AI Index 2026).
- Investissement privé 2025 : États-Unis 285,88 Md$, Europe 20,92 Md$, Chine 12,41 Md$.
- France : 8 % des TPE et 13 % des PME utilisent une IA clé en main (plan Osez l'IA).
- **AI Act** (règlement 2024/1689) : article 4 (maîtrise de l'IA) applicable depuis le **2 février 2025** ; contrôle à partir du 2 août 2026 ; article 50 (transparence) depuis le 2 août 2026 ; haut risque reporté au **2 décembre 2027** par l'omnibus (règlement 2026/1744, en vigueur le 27 juillet 2026). Depuis l'omnibus, l'article 4 demande de **favoriser** la maîtrise de l'IA, sans niveau individuel imposé : l'obligation de former demeure.

## Pour aller plus loin
- [Elements of AI (version française)](https://www.elementsofai.com/)
- [Claude Academy — AI Fluency: Framework and Foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations)
- [Règlement (UE) 2024/1689 — AI Act (EUR-Lex)](https://eur-lex.europa.eu/eli/reg/2024/1689/oj)

## Auto-test (3 questions — réponses en bas de fiche)
1. Un moteur de paie qui applique le Code du travail : IA générative ?
2. Une enseigne veut regrouper 50 000 clients en profils sans groupes définis à l'avance : quel mode d'apprentissage ?
3. Pourquoi un LLM peut-il affirmer une chose fausse avec assurance ?

---
**Réponses** — 1. Non : IA symbolique (règles écrites par des humains, ni apprentissage ni génération). 2. Non supervisé (regroupement, *clustering*). 3. Il a été entraîné à produire le token suivant le plus plausible, pas à vérifier la vérité.
