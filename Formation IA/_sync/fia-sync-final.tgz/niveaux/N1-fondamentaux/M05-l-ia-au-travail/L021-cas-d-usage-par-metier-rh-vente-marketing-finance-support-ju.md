---
id: L021
module: M05
level: N1
title: "Cas d'usage par métier : RH, vente, marketing, finance, support, juridique"
minutes: 45
objectives:
  - "Identifier, dans son propre métier, les tâches qui se prêtent à l'IA générative et celles qui doivent lui échapper"
  - "Décrire au moins trois cas d'usage concrets pour huit métiers courants des entreprises françaises"
  - "Appliquer un prompt type métier et l'adapter à son contexte (rôle, documents, format attendu)"
  - "Évaluer le niveau de vérification requis selon l'enjeu de la tâche"
skills: ["C1.2", "C1.3", "C1.4"]
sources:
  - { title: "Claude Academy — Claude 101 (Claude in action — use-cases by role)", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "Claude Academy — AI Fluency for small businesses", url: "https://academy.claude.com/courses/ai-fluency-for-small-businesses", lang: "en" }
  - { title: "Claude Academy — AI Fluency: Framework and foundations (4D)", url: "https://academy.claude.com/courses/ai-fluency-framework-foundations", lang: "en" }
  - { title: "OpenAI Academy — catalogue des cours (parcours Apply AI at Work)", url: "https://academy.openai.com/pages/courses", lang: "en" }
  - { title: "Google AI Essentials (Coursera)", url: "https://www.coursera.org/google-specializations/ai-essentials-google", lang: "en" }
  - { title: "Stanford HAI — AI Index Report 2026", url: "https://hai.stanford.edu/ai-index/2026-ai-index-report", lang: "en" }
  - { title: "Maddyness — plan Osez l'IA (1er juillet 2025)", url: "https://www.maddyness.com/2025/07/01/osez-lia-le-plan-de-clara-chappaz-pour-accelerer-ladoption-de-lia-dans-les-entreprises-francaises/", lang: "fr" }
  - { title: "Syntec Ingénierie — étude OPIIEC IA (2025)", url: "https://www.syntec-ingenierie.fr/app/uploads/2025/06/20250428_OPIIEC_IA_A_RETENIR.pdf", lang: "fr" }
  - { title: "CNIL — les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
---

# Cas d'usage par métier : RH, vente, marketing, finance, support, juridique

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 5

## 🎯 Ce que vous saurez faire
- Repérer en moins de cinq minutes les tâches de votre poste que l'IA générative accélère vraiment, et celles où elle fait perdre du temps ou prendre des risques.
- Citer trois cas d'usage concrets et un prompt type pour huit métiers : RH, vente, marketing, finance, support client, juridique, achats-logistique, direction de PME.
- Adapter un prompt type à votre contexte en y glissant vos documents, votre vocabulaire et votre format de sortie.
- Associer à chaque cas d'usage un niveau de vérification proportionné à l'enjeu (la méthode complète est dans la leçon L023).

> 🧭 **En clair** — Voyez l'IA générative comme un stagiaire très rapide, très cultivé, mais qui ne connaît ni votre entreprise ni vos clients. Il est excellent pour écrire un premier jet, résumer un long document ou ranger des éléments en vrac ; il est incapable de décider à votre place ou de signer un contrat. Cette leçon vous apprend à regarder votre propre journée de travail et à repérer les tâches que vous pouvez lui confier. Pour chacune, vous saurez aussi combien de temps passer à vérifier : une relecture rapide pour un mail interne, un contrôle d'expert pour un devis ou une clause juridique.

## 1. Pourquoi « par métier » et non « par outil »

Les modules précédents vous ont appris ce qu'est un LLM (M02), quels assistants existent (M03) et comment leur parler (M04). Ce module change de point de vue : on part de **votre journée de travail**, pas de la technologie.

Quelques repères chiffrés (nov. 2026) pour situer le mouvement :
- L'IA générative a atteint **53 % d'adoption en trois ans**, plus vite qu'Internet ou le PC, selon l'AI Index 2026 de Stanford.
- En France, seules **8 % des TPE et 13 % des PME** utilisaient une IA « clé en main » lorsque le plan *Osez l'IA* a été lancé (juillet 2025) ; l'objectif public est de 50 % des TPE et 80 % des PME d'ici 2030.
- Dans la branche numérique-ingénierie-conseil, l'étude OPIIEC 2025 estime à **287 500 salariés** le nombre de personnes à former ou sensibiliser, dont seulement 26 % l'étaient déjà.

Autrement dit : la majorité de vos collègues n'a pas encore de pratique structurée. Ce que vous apprenez ici est une avance, pas un rattrapage.

### 1.1 Les sept familles de tâches où un LLM excelle

Quel que soit le métier, les cas d'usage rentables se rangent presque toujours dans sept familles. Mémorisez-les : elles sont votre « détecteur de cas d'usage ».

| Famille | Ce que vous donnez | Ce que vous obtenez | Exemple |
|---|---|---|---|
| **Rédiger** | Des notes, un brief | Un texte structuré | Mail, offre d'emploi, post LinkedIn |
| **Résumer** | Un document long | L'essentiel, au format voulu | Compte rendu de réunion, synthèse d'un appel d'offres |
| **Extraire** | Un texte brut | Des données structurées | Tableau des clauses d'un contrat, champs d'une facture |
| **Classer** | Des éléments en vrac | Des catégories | Tri de tickets support, de candidatures, de dépenses |
| **Traduire / reformuler** | Un texte | Le même texte dans une autre langue ou un autre registre | Réponse client en anglais, note juridique « en français courant » |
| **Analyser** | Des données ou un texte | Des constats et des hypothèses | Écarts budgétaires, tendances dans des avis clients |
| **Générer des idées** | Une contrainte | Des options variées | Noms de campagne, questions d'entretien, scénarios de négociation |

> 💡 **À retenir** — Si une tâche n'entre dans aucune de ces familles (décider, signer, négocier en face à face, consoler un salarié), l'IA peut *préparer* mais pas *faire*. C'est un bon test en cinq secondes.

```quiz
{
  "q": "Votre directrice vous demande d'« utiliser l'IA pour choisir le prochain fournisseur d'emballages ». Dans quelle famille de tâches l'IA peut-elle réellement vous aider ?",
  "options": ["Extraire et analyser : mettre les devis côte à côte, vous décidez", "Aucune : choisir un fournisseur est une décision, l'IA ne peut strictement rien préparer", "Générer des idées : l'IA désigne elle-même le fournisseur le plus créatif du lot", "Traduire : l'IA traduit les devis en anglais puis signe directement le bon de commande"],
  "answer": 0,
  "explanation": "Décider ne fait pas partie des sept familles : l'IA ne fait pas, elle prépare. Elle peut extraire les chiffres des devis et les mettre côte à côte (analyse), mais le choix vous revient."
}
```

### 1.2 Le cadre 4D pour déléguer sans se tromper

Le cours *AI Fluency* de Claude Academy, co-écrit avec les professeurs Joseph Feller et Rick Dakan, propose quatre compétences que nous adoptons comme fil rouge du module : **Délégation** (choisir ce qu'on confie à l'IA), **Description** (expliquer clairement, cf. M04), **Discernement** (juger la sortie, cf. L023) et **Diligence** (assumer la responsabilité du résultat, cf. M07). Dans cette leçon, nous travaillons la première : *déléguer*.

Trois questions pour décider si une tâche se délègue :
1. **Est-elle répétitive ou chronophage ?** (Si vous la faites une fois par an, le gain est faible.)
2. **Passe-t-elle par du texte, des chiffres ou des images ?** (L'IA ne porte pas de cartons.)
3. **Puis-je vérifier le résultat plus vite que je ne l'aurais produit ?** (Si non, vous perdez du temps *et* vous prenez un risque.)

Trois « oui » : déléguez. Un « non » à la question 3 : ne déléguez pas, ou seulement une ébauche.

> 💡 **Autrement dit** — Avant de confier une tâche, posez-vous trois questions de bon sens : « Je la fais souvent ? », « C'est du texte, des chiffres ou des images ? », « Je peux vérifier le résultat vite ? ». Trois oui : allez-y. Si la vérification prendrait plus de temps que de faire la tâche vous-même, l'IA ne vous fait rien gagner.

```mermaid
flowchart TD
  A[Une tâche de ma journée] --> B{Répétitive ou chronophage ?}
  B -- non --> X[Gain faible : faites-la vous-même]
  B -- oui --> C{Texte, chiffres ou images ?}
  C -- non --> X
  C -- oui --> D{Vérifiable plus vite que produite ?}
  D -- non --> Y[Ne déléguez pas, ou seulement une ébauche]
  D -- oui --> Z[Déléguez à l'IA + vérification 🟢🟠🔴]
```

## 2. Huit métiers, vingt-quatre cas d'usage, huit prompts types

Pour chaque métier : trois cas d'usage, les documents à fournir, le niveau de vérification (🟢 faible : relecture rapide · 🟠 moyen : contrôle des faits · 🔴 fort : validation experte obligatoire) et un prompt type. Les prompts suivent la structure du module M04 : rôle, contexte, tâche, format, contraintes.

> ⚠️ **Piège fréquent** — Avant de copier un prompt, retirez des documents toute donnée personnelle inutile (noms, adresses, numéros de sécurité sociale, salaires nominatifs). La CNIL rappelle que la finalité et la minimisation s'appliquent aussi aux prompts ; le module M07 y revient en détail. En attendant : **anonymisez par défaut**.

### 2.1 Ressources humaines

| Cas d'usage | À fournir | Vérification |
|---|---|---|
| Rédiger une offre d'emploi inclusive et conforme (pas de critère discriminant) | Fiche de poste, grille de salaire, valeurs de l'entreprise | 🟠 |
| Préparer une grille d'entretien structurée (questions identiques pour tous les candidats) | Fiche de poste, compétences clés | 🟢 |
| Synthétiser 40 réponses libres d'une enquête de climat social en thèmes | Export anonymisé des réponses | 🟠 |

Hors périmètre : **trier ou noter des candidatures** avec une IA. Le recrutement figure à l'annexe III de l'AI Act (haut risque) — la liste des usages jugés sensibles, qui imposent des obligations renforcées — ; même si l'application de ces obligations a été reportée au 2 décembre 2027 (nov. 2026), la décision doit rester humaine et explicable.

```text
Rôle : tu es chargé(e) de recrutement dans une PME industrielle de 80 salariés en Normandie.
Contexte : voici la fiche de poste (ci-dessous) et notre fourchette de salaire (32-36 k€ brut annuel).
Tâche : rédige une offre d'emploi pour un(e) technicien(ne) de maintenance.
Format : titre, 3 lignes d'accroche, missions (5 puces), profil (4 puces), conditions, processus de recrutement.
Contraintes : 250 mots maximum, aucun critère lié à l'âge, au sexe ou à la situation familiale,
vouvoiement, mentionne le télétravail impossible sur ce poste. Signale toute information manquante.
```

### 2.2 Vente / commercial

| Cas d'usage | À fournir | Vérification |
|---|---|---|
| Préparer un rendez-vous : fiche prospect à partir de son site et de ses actualités publiques | URL ou texte collé du site, contexte de l'offre | 🟠 (dates et chiffres) |
| Rédiger une proposition commerciale à partir d'un compte rendu de découverte | Notes du rendez-vous, grille tarifaire | 🔴 (prix, engagements) |
| Classer les objections entendues en 3 mois et préparer des réponses | Notes CRM anonymisées | 🟢 |

```text
Rôle : tu es directeur commercial d'une société de nettoyage industriel.
Contexte : notes brutes de mon rendez-vous avec un prospect (ci-dessous) et notre grille tarifaire (ci-dessous).
Tâche : rédige une proposition commerciale en 1 page.
Format : rappel du besoin (3 phrases), solution proposée, planning, tarif (reprends EXACTEMENT les prix
de la grille, sans en inventer), prochaines étapes.
Contraintes : ne promets aucun délai ou prestation absent de mes notes ; liste à la fin les points
à confirmer avec le client.
```

### 2.3 Marketing / communication

| Cas d'usage | À fournir | Vérification |
|---|---|---|
| Décliner un contenu long en 5 formats (post LinkedIn, newsletter, script vidéo 30 s, FAQ, tweet) | Article ou étude de cas source | 🟢 |
| Analyser 200 avis clients et en sortir 5 thèmes avec verbatims (citations exactes des clients) | Export d'avis (sans noms) | 🟠 |
| Produire 10 angles de campagne pour un lancement, puis en développer 2 | Brief, persona, ton de marque (le persona est le portrait-type du client visé) | 🟢 |

```text
Rôle : tu es responsable communication d'une marque de cosmétiques bio française.
Contexte : voici notre charte de ton (ci-dessous) et l'étude de cas client (ci-dessous).
Tâche : décline l'étude de cas en un post LinkedIn, un paragraphe de newsletter et un script vidéo de 30 s.
Format : trois blocs titrés ; le post fait 120 mots maximum avec une question finale.
Contraintes : aucune allégation santé, aucun chiffre qui ne figure pas dans l'étude de cas,
pas de superlatif (« le meilleur », « révolutionnaire »).
```

### 2.4 Finance / comptabilité

| Cas d'usage | À fournir | Vérification |
|---|---|---|
| Expliquer en français courant les écarts entre budget et réalisé d'un tableau | Tableau exporté (CSV) — un format de tableau simple, exportable depuis Excel — | 🟠 |
| Pré-classer des dépenses par nature comptable pour relecture | Libellés de dépenses | 🔴 (le comptable valide) |
| Rédiger la note de synthèse mensuelle pour la direction à partir des indicateurs | KPI du mois (indicateurs clés : chiffre d'affaires, marge…), note du mois précédent | 🟠 |

```text
Rôle : tu es contrôleur de gestion dans une PME de distribution.
Contexte : tableau budget/réalisé par poste pour octobre (ci-dessous, en CSV).
Tâche : identifie les 5 écarts les plus importants en valeur absolue et propose pour chacun 2 hypothèses d'explication.
Format : tableau (poste, budget, réalisé, écart en €, écart en %), puis liste des hypothèses.
Contraintes : recalcule les écarts toi-même et affiche ton calcul ; n'invente aucune cause,
formule-les comme des questions à poser aux responsables de service.
```

### 2.5 Support client

| Cas d'usage | À fournir | Vérification |
|---|---|---|
| Rédiger une réponse empathique et conforme à la politique de l'entreprise | Ticket client, politique SAV | 🟠 |
| Classer les tickets de la semaine par motif et urgence | Export des tickets anonymisés | 🟢 |
| Créer une FAQ à partir des 50 questions les plus fréquentes | Historique de questions, documentation produit | 🟠 |

```text
Rôle : tu es conseiller(ère) service client d'un site de vente de matériel de jardinage.
Contexte : message du client (ci-dessous) et notre politique de retour (ci-dessous).
Tâche : rédige une réponse.
Format : 120 mots maximum, vouvoiement, ton chaleureux mais factuel, une seule action demandée au client.
Contraintes : applique STRICTEMENT la politique de retour fournie ; si le cas n'y est pas prévu,
écris « [À FAIRE VALIDER PAR UN RESPONSABLE] » au lieu d'inventer une règle.
```

Cette dernière contrainte n'est pas un détail : en 2024, un tribunal canadien a condamné Air Canada parce que son chatbot avait inventé une politique de remboursement (détails en L023).

### 2.6 Juridique (service juridique ou cabinet)

| Cas d'usage | À fournir | Vérification |
|---|---|---|
| Extraire les clauses clés d'un contrat (durée, résiliation, pénalités, loi applicable) en tableau | Le contrat (PDF) | 🟠 |
| Comparer deux versions d'un contrat et lister les différences | Les deux versions | 🟠 |
| Reformuler une note juridique en « français courant » pour un client ou un opérationnel | La note validée | 🟢 |

Hors périmètre à ce niveau : **demander une recherche de jurisprudence sans outil de recherche sourcé**. Les références inventées sont l'hallucination la plus documentée au monde (L023).

```text
Rôle : tu es juriste d'entreprise.
Contexte : contrat de prestation de services joint (PDF, 14 pages).
Tâche : extrais les clauses suivantes : durée, conditions de résiliation, pénalités de retard,
responsabilité et plafond, propriété intellectuelle, loi applicable et juridiction.
Format : tableau à 3 colonnes : clause, résumé en 1 phrase, numéro d'article et citation exacte du passage.
Contraintes : si une clause est absente, écris « absente » ; ne complète jamais avec ce qui est « habituel ».
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : dans un prompt de support client, il vaut mieux laisser l'IA « compléter avec la pratique habituelle » quand la politique de retour ne prévoit pas le cas du client.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Une règle inventée par un chatbot engage l'entreprise (affaire Air Canada, 2024). La bonne consigne : appliquer strictement la politique fournie et écrire « [À FAIRE VALIDER PAR UN RESPONSABLE] » si le cas n'est pas prévu."
}
```

### 2.7 Achats / logistique

| Cas d'usage | À fournir | Vérification |
|---|---|---|
| Rédiger un cahier des charges de consultation à partir d'un besoin exprimé oralement | Notes de réunion, contraintes (délais, budget) | 🟠 |
| Comparer 3 devis fournisseurs sur une grille commune | Les devis (PDF) | 🔴 (chiffres recalculés) |
| Rédiger un mail de relance ferme mais courtois pour un retard de livraison | Historique des échanges | 🟢 |

```text
Rôle : tu es acheteur(se) dans une entreprise agroalimentaire.
Contexte : trois devis joints pour la fourniture d'emballages (PDF).
Tâche : construis une grille comparative.
Format : tableau (critère en ligne, fournisseur en colonne) : prix unitaire HT, minimum de commande,
délai, conditions de paiement, garanties, points non précisés.
Contraintes : reprends les chiffres tels quels sans les convertir ; indique la page du devis pour chaque
valeur ; ne désigne pas de « gagnant », liste plutôt les questions à poser à chaque fournisseur.
```

### 2.8 Direction de PME / assistanat de direction

| Cas d'usage | À fournir | Vérification |
|---|---|---|
| Transformer un enregistrement de réunion en compte rendu avec décisions et actions | Transcription | 🟠 |
| Préparer un argumentaire pour la banque à partir du prévisionnel | Prévisionnel, historique | 🔴 |
| Rédiger la charte d'usage de l'IA de l'entreprise (ébauche à faire valider) | Exemples de règles, contexte | 🟠 |

```text
Rôle : tu es assistant(e) de direction d'un cabinet d'architecture de 15 personnes.
Contexte : transcription de notre réunion hebdomadaire (ci-dessous).
Tâche : rédige le compte rendu.
Format : 1) décisions prises (liste), 2) actions (tableau : action, responsable, échéance),
3) points en suspens, 4) prochaine réunion.
Contraintes : n'attribue une action à quelqu'un que si c'est explicite dans la transcription ;
sinon, écris « responsable à définir ». 300 mots maximum.
```

> 🔗 **Documentation officielle** — Le cours gratuit [Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 consacre une leçon entière aux « use-cases by role » ; le cours [AI Fluency for small businesses](https://academy.claude.com/courses/ai-fluency-for-small-businesses) 🇬🇧 reprend la même logique pour les TPE-PME. Côté OpenAI, le parcours « Apply AI at Work » de l'[OpenAI Academy](https://academy.openai.com/pages/courses) 🇬🇧 couvre les mêmes familles de tâches (notes → plans d'action, résumés avec citations, tableurs).

```quiz
{
  "q": "Mise en situation : un acheteur demande à l'IA de comparer trois devis fournisseurs. Quel niveau de vérification la leçon recommande-t-elle, et pourquoi ?",
  "options": ["🟢 faible : il suffit de relire la mise en forme du tableau et les intitulés", "🟠 moyen : on vérifie seulement les dates de livraison annoncées par chaque fournisseur", "Aucun : l'IA ne se trompe jamais sur des chiffres qu'elle recopie d'un document", "🔴 fort : chaque chiffre est recalculé et vérifié dans le devis"],
  "answer": 3,
  "explanation": "Une erreur de prix ou de minimum de commande coûte directement de l'argent. Le tableau de la section 2.7 classe ce cas en 🔴 : chiffres recalculés, page du devis indiquée pour chaque valeur."
}
```

```mission
{
  "title": "Retrouvez la leçon « métiers » du cours Claude 101",
  "url": "https://academy.claude.com/courses/claude-101",
  "steps": ["Ouvrez la page du cours Claude 101 sur Claude Academy", "Déroulez le plan du cours (liste des leçons)", "Repérez la partie « Putting it all together »"],
  "question": "Quel est le titre exact de la leçon consacrée aux usages de Claude selon le métier, et combien de temps dure le cours entier ?",
  "hint": "Le titre commence par « Claude in action ».",
  "answer": "« Claude in action — use-cases by role », dans un cours d'environ 2,5 h (13 leçons + 1 quiz) — plan lu le 1er nov. 2026, il peut évoluer.",
  "xp": 15
}
```

## 3. Trouver *vos* cas d'usage en dix minutes

🎮 **Défi « journal d'une journée »** — Prenez votre agenda d'hier. Listez dix tâches que vous avez réellement faites. Pour chacune, cochez : famille (section 1.1), trois questions de délégation (section 1.2), niveau de vérification. Vous obtiendrez en général deux ou trois tâches « 3 oui / 🟢 ou 🟠 » : ce sont vos premiers cas d'usage. Commencez par ceux-là, pas par les plus spectaculaires.

Deux erreurs classiques des débutants :
- **Viser trop gros** : « automatiser toute la facturation » est un projet d'automatisation (module M06), pas un cas d'usage de première semaine.
- **Viser trop risqué** : commencer par un courrier d'avocat ou un bilan comptable, où toute erreur coûte cher, décourage tout le monde dès la première hallucination.

> 💡 **À retenir** — Un bon premier cas d'usage est fréquent, textuel, vérifiable en moins de temps qu'il n'en faut pour le faire, et à faible enjeu. La vitesse viendra ensuite.

```mission
{
  "title": "Le cadre 4D à la source",
  "url": "https://academy.claude.com/courses/ai-fluency-framework-foundations",
  "steps": ["Ouvrez la page du cours AI Fluency: Framework and foundations", "Parcourez le plan du cours", "Repérez les chapitres consacrés à chacun des quatre « D »"],
  "question": "Quels sont les quatre « D » du cadre, et dans quel ordre le cours les aborde-t-il ?",
  "hint": "Le premier est justement celui travaillé dans cette leçon.",
  "answer": "Delegation, Description, Discernment, Diligence (dans cet ordre) — cours d'environ 4 h, plan lu le 1er nov. 2026.",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Choisissez votre métier (ou celui que vous visez). Construisez une **fiche « IA dans mon métier »** comportant :
1. Trois cas d'usage, chacun avec la famille de tâche, les documents à fournir (anonymisés) et le niveau de vérification 🟢/🟠/🔴.
2. Un prompt type complet pour le cas d'usage le plus fréquent (rôle, contexte, tâche, format, contraintes), testé dans l'assistant de votre choix.
3. Une ligne « ce que je ne confierai pas à l'IA et pourquoi ».

**Concrètement :** une page dans un document : d'abord un tableau de trois lignes (une par cas d'usage) et quatre colonnes (cas d'usage · famille de tâche · documents à fournir · couleur de vérification 🟢/🟠/🔴), puis votre prompt complet, puis la phrase « hors périmètre ». Pour trouver vos cas, faites le défi « journal d'une journée » de la section 3 et inspirez-vous du métier le plus proche du vôtre en section 2. Si vous n'êtes pas en poste, prenez le métier visé ou une activité associative.

**Critères de réussite.**
- Les trois cas d'usage sont différents (pas trois variantes de « rédiger un mail »).
- Le prompt contient une contrainte anti-invention explicite (« si l'information manque, dis-le »).
- Le résultat obtenu est exploitable après moins de cinq minutes de retouche.
- La ligne « hors périmètre » cite un enjeu concret (juridique, données personnelles, décision sur une personne).

**Pistes de corrigé.** Pour un(e) gestionnaire de paie : classer les questions des salariés par thème (🟢), rédiger une note d'information sur un changement de convention collective à partir du texte officiel fourni (🟠), expliquer un bulletin de paie en langage simple à partir du bulletin anonymisé (🟠). Hors périmètre : calculer une paie ou un solde de tout compte (le logiciel de paie et le contrôle humain s'en chargent ; une erreur engage l'employeur).

## ✅ Auto-évaluation express

1. Citez les sept familles de tâches où un LLM apporte le plus de valeur.
2. Un responsable RH veut utiliser ChatGPT pour présélectionner des CV. Que lui répondez-vous ?
3. Quelle contrainte ajoutez-vous systématiquement à un prompt de support client, et pourquoi ?

**Réponses.** 1) Rédiger, résumer, extraire, classer, traduire/reformuler, analyser, générer des idées. 2) Non en l'état : le recrutement relève du haut risque dans l'AI Act (annexe III, obligations reportées au 2 décembre 2027 mais décision humaine indispensable), et les CV contiennent des données personnelles ; l'IA peut en revanche préparer une grille d'entretien identique pour tous. 3) « Applique strictement la politique fournie ; si le cas n'est pas prévu, signale-le au lieu d'inventer » — parce qu'une règle inventée engage l'entreprise (affaire Air Canada, 2024).

> ✅ **Si vous ne retenez que 3 choses** — 1. Sept familles de tâches où l'IA excelle : rédiger, résumer, extraire, classer, traduire ou reformuler, analyser, trouver des idées. Pour le reste (décider, signer, négocier), elle prépare, elle ne fait pas. 2. Avant de déléguer, trois questions : la tâche est-elle fréquente ? passe-t-elle par du texte, des chiffres ou des images ? puis-je vérifier le résultat plus vite que le faire moi-même ? 3. Adaptez la vérification à l'enjeu (🟢 relecture, 🟠 contrôle des faits, 🔴 validation d'un expert), anonymisez par défaut, et gardez toute décision sur une personne entre des mains humaines.

## 📚 Pour aller plus loin
- [Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 — cours gratuit de 2,5 h avec une leçon « Claude in action — use-cases by role ».
- [AI Fluency: Framework and foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations) 🇬🇧 — le cadre 4D (Délégation, Description, Discernement, Diligence), badge gratuit à la clé.
- [Google AI Essentials](https://www.coursera.org/google-specializations/ai-essentials-google) 🇬🇧 — cours 2 « Maximize Productivity With AI Tools », aligné avec ce module.
- [CNIL — les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — pour savoir ce que vous pouvez (ou non) mettre dans un prompt.
- [AI Index Report 2026 (Stanford HAI)](https://hai.stanford.edu/ai-index/2026-ai-index-report) 🇬🇧 — chapitre 4 « Economy » : adoption et effets sur le travail.

> 🗺️ **Et maintenant ?** — Vous savez *quoi* confier à l'IA ; la leçon L022 vous montre *comment* gagner du temps concrètement sur vos mails, réunions, tableurs et présentations.

