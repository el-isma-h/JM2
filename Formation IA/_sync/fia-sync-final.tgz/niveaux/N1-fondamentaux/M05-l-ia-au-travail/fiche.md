---
module: M05
title: "Fiche mémo — L'IA au travail"
---
# Fiche mémo — M05 · L'IA au travail

> En une phrase : l'IA est un stagiaire très rapide qui prépare, vous décidez ; déléguez ce qui est fréquent, textuel et vérifiable, puis vérifiez en proportion de l'enjeu.

## Les 7 idées à retenir
1. **Partir de sa journée, pas de l'outil** : 7 familles de tâches rentables — rédiger, résumer, extraire, classer, traduire/reformuler, analyser, générer des idées (`L021`).
2. **Le test des 3 oui** : fréquent ? du texte, des chiffres ou des images ? vérifiable plus vite que produit ? Sinon, une ébauche au mieux (`L021`).
3. **Préparer, pas décider** : pas de tri de CV par IA (recrutement = haut risque, annexe III de l'AI Act) (`L021`).
4. **Où vivent vos documents ?** Déjà ouverts dans Word, Excel, Gmail, Teams → assistant intégré ; notes éparses ou plusieurs sources → assistant généraliste (`L022`).
5. **Un LLM n'additionne pas** : exigez le calcul exécuté ou la formule Excel, contrôlez une ligne à la main (`L022`).
6. **Valider à chaque flèche** : notes → compte rendu → e-mail → diapositives ; une erreur en amont fait boule de neige (`L022`).
7. **Vérifier en 5 étapes** et proportionner selon « enjeu × réversibilité » (`L023`).

## Le schéma à connaître

```mermaid
flowchart LR
  A["1. Classer<br/>fait, chiffre, référence…"] --> B["2. Repérer<br/>signaux d'alerte"]
  B --> C["3. Remonter<br/>à la source primaire"]
  C --> D["4. Contre-vérifier<br/>2 sources indépendantes"]
  D --> E["5. Corriger et tracer<br/>source + date + qui"]
```

| | Réversible (brouillon) | Irréversible (envoyé, signé) |
|---|---|---|
| Enjeu faible | Relecture rapide | Étapes 1-2 + chiffres |
| Enjeu fort | Étapes 1 à 4 | Les 5 étapes + expert métier |

## Vocabulaire express
| Terme | En clair |
|---|---|
| Cadre 4D | Délégation, Description, Discernement, Diligence (AI Fluency) |
| 🟢 🟠 🔴 | Relecture rapide / contrôle des faits / validation experte obligatoire |
| Tenant | L'espace privé de l'entreprise chez Microsoft, avec ses règles d'accès |
| Source primaire | Le document d'origine (loi, rapport, page de l'éditeur), pas un résumé |
| Registre d'erreurs | Le tableau date / outil / tâche / erreur / correction qui montre où l'outil se trompe |
| Titre « message » | Un titre de diapositive qui affirme (« Le surcoût est couvert à 60 % ») |

## Les pièges classiques
- Viser trop gros (« automatiser toute la facturation ») ou trop risqué (un bilan comptable) dès la première semaine.
- Demander « es-tu sûr ? » à la même IA : c'est un second tirage au sort, pas une vérification.
- Un e-mail « qui sent l'IA » : adjectifs en rafale, paragraphes égaux. Retirez une phrase sur trois, ajoutez un détail que vous seul connaissez.
- Un compte rendu IA met au même niveau la décision stratégique et le choix de la salle : la hiérarchie, c'est vous.
- Confondre Copilot grand public et Microsoft 365 Copilot ; version gratuite et offre Team/Enterprise.
- Transcrire une réunion sans informer les participants.

## Les commandes / chiffres / dates utiles
- **Signaux d'alerte, mnémo « PTAMDF »** : **P**récision suspecte · **T**rop beau pour être vrai · **A**bsence de nuance · **M**élange vrai/faux · **D**ate de connaissance dépassée · **F**ausse prémisse acceptée.
- Où vérifier : Légifrance (version en vigueur), Service-public.fr (date de mise à jour), INSEE (année, périmètre), CNIL, documentation officielle de l'éditeur. Une URL en 404 = référence inventée jusqu'à preuve du contraire.
- Excel : convertir la plage en tableau (**Ctrl + L**) avant de solliciter Copilot ; demander d'abord « Décris ce tableau ».
- CPF : reste à charge **150 €** depuis le 2 avril 2026 (décret 2026-234) ; plafond **annuel** de **1 500 €** pour les certifications RS, hors CléA (décret n° 2026-127 du **24 février 2026**).
- Mention conseillée : « Produit avec l'aide d'une IA, relu et validé par [nom], le [date] ».
- Affaires à raconter : Mata c. Avianca (2023, fausses jurisprudences), Bard et le télescope James-Webb (2023), Moffatt c. Air Canada (2024 : l'entreprise répond de son chatbot), Deloitte Australie (2025).
- Recrutement (haut risque) : obligations reportées au **2 décembre 2027**, décision humaine indispensable.

## Pour aller plus loin
- [Claude 101](https://academy.claude.com/courses/claude-101)
- [AI Fluency: Framework and foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations)
- [Légifrance](https://www.legifrance.gouv.fr/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Un RH veut présélectionner des CV avec ChatGPT : que répondez-vous ?
2. Que retenir de l'affaire Air Canada (2024) ?
3. Quelle est la première étape d'une présentation, avant toute génération ?

---
**Réponses** — 1. Non en l'état : recrutement à haut risque (AI Act, annexe III) et données personnelles ; l'IA peut préparer une grille d'entretien identique pour tous. 2. L'entreprise est responsable de ce que dit son chatbot : la politique inventée a dû être honorée. 3. Faire valider un plan de 8 à 10 diapositives aux titres « message ».
