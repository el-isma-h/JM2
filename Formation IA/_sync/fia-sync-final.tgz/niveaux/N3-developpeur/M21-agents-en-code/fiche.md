---
module: M21
title: "Fiche mémo — Agents en code"
---
# Fiche mémo — M21 · Agents en code

> En une phrase : un agent, c'est un modèle avec des outils, une boucle et des garde-fous. Le modèle choisit l'action suivante, mais c'est le code qui pose les limites, les validations et les preuves.

## Les 7 idées à retenir
1. Dans un workflow, c'est vous qui fixez l'ordre des étapes. Dans un agent, c'est le modèle qui décide. Commencez par le workflow le plus simple qui marche (`L095`).
2. Un agent a quatre briques (outils, mémoire courte, mémoire longue, planification ReAct) et toujours des limites : tours, budget, délai (`L095`).
3. Une erreur d'outil est une observation. On la renvoie au modèle avec `is_error: true`, sans trace Python brute (`L095`).
4. LangGraph : un état typé, des nœuds et des arêtes, un checkpointer avec un `thread_id`, et `interrupt` pour l'humain dans la boucle (`L096`).
5. Les trois SDK suivent la même boucle mais placent les garde-fous ailleurs. OpenAI : guardrails en parallèle. Claude : hook `PreToolUse`. Pydantic AI : typage et `ModelRetry` (`L097`).
6. On ne passe en multi-agents que si les domaines sont vraiment distincts. Entre agents, on échange du JSON validé, pas de la prose (`L098`).
7. MCP relie un agent à des outils et des données, A2A relie des agents entre eux, et les skills portent des procédures. Un serveur tiers se traite comme un sous-traitant (`L099`).

## Le schéma à connaître
```mermaid
flowchart LR
    T["Tâche"] --> P["Perception (contexte, mémoire)"]
    P --> R["Raisonnement (planifier, choisir)"]
    R -->|"outil"| A["Action : appel d'outil"]
    A --> O["Observation (résultat ou is_error)"]
    O --> P
    R -->|"fin"| F["Réponse finale"]
    R -.->|"tours / budget / délai dépassés"| X["Arrêt forcé"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| ReAct | Le modèle alterne réflexion et action |
| Réducteur (`add_messages`) | La règle qui dit comment ranger une mise à jour : ajouter au lieu de remplacer |
| Checkpointer | Sauvegarde l'état après chaque nœud, pour reprendre plus tard |
| Handoff | L'agent passe la main à un spécialiste |
| Orchestrateur-workers | L'un découpe le travail, les autres l'exécutent en parallèle |
| Agent Card | La carte de visite A2A, sur `/.well-known/agent-card.json` |
| Rug pull | Un serveur MCP change ses outils après que vous les avez validés |

## Les pièges classiques
- Pas de `max_tours` et un outil qui renvoie une erreur floue : l'agent tourne pour rien.
- Le coût d'un agent devient quadratique avec les tours si on ne compacte pas ou ne tronque pas l'historique.
- Utiliser le même `thread_id` pour tous les utilisateurs : les conversations se mélangent.
- Mettre une règle métier dans le prompt. Si elle est non négociable, elle va dans le code (hook, validator, outil).
- Le « téléphone arabe » entre agents : l'information se dégrade à chaque passage.
- Laisser le rédacteur écrire lui-même la bibliographie. C'est là que naissent les URL inventées.
- Croire que le relecteur LLM vérifie les faits. Il vérifie la cohérence avec le dossier fourni.

## Les commandes / chiffres / dates utiles
```python
# Boucle maison (Messages API) : on s'arrête sur end_turn, max_tours ou budget
for tour in range(MAX_TOURS):
    r = client.messages.create(model="claude-sonnet-5-5", max_tokens=1024, tools=OUTILS, messages=messages)
    if r.stop_reason != "tool_use": break
    messages += [{"role": "assistant", "content": r.content},
                 {"role": "user", "content": [executer(b) for b in r.content if b.type == "tool_use"]}]
```
```python
graphe = g.compile(checkpointer=SqliteSaver.from_conn_string("db.sqlite"))      # LangGraph
graphe.invoke({...}, {"configurable": {"thread_id": "client-7731"}})            # interrupt() → Command(resume=…)
await Runner.run(agent, "…", max_turns=8)                                        # OpenAI (10 par défaut, MaxTurnsExceeded)
# Claude Agent SDK, hook PreToolUse : {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny"}}
```
- **Memory tool (Anthropic)** : `view`, `create`, `str_replace`, `insert`, `delete`, `rename`, dans `/memories`.
- **LangGraph 1.2** (12/05/2026) : timeouts et gestion d'erreur par nœud. LangSmith s'active avec `LANGSMITH_TRACING=true`.
- **CrewAI** : process `sequential` ou `hierarchical` (le second demande un `manager_llm`). AutoGen est en maintenance depuis le 2/10/2025, Microsoft Agent Framework 1.0 est en GA depuis le 3/04/2026.
- **MCP 2026-07-28** : version stable. Protocole sans état. Roots, Sampling, Logging et HTTP+SSE dépréciés, DCR remplacé par CIMD. **A2A 1.2** (avril 2026) : Agent Cards signées.
- **OWASP Agentic 2026** : de ASI01 (Agent Goal Hijack) à ASI10 (Rogue Agents).
- **Projet de veille (nov. 2026)** : `perplexity/sonar` 0,25 / 2,50 $, `grok-4.7` 2 / 6 $, `x_search` 5 $ / 1 000 posts. Environ 0,26 $ par note, plafond à 0,60 $.

## Pour aller plus loin
- [Build a tool-using agent](https://platform.claude.com/docs/en/agents-and-tools/tool-use/build-a-tool-using-agent)
- [LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview)
- [A2A Protocol](https://a2a-protocol.org/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Que faut-il pour utiliser `interrupt()` dans LangGraph ?
2. Avec le Claude Agent SDK, comment garantir qu'aucun congé de plus de 10 jours n'est enregistré ?
3. Votre agent lit une base Postgres interne et consulte l'agent d'un partenaire. Quel protocole pour chaque lien ?

---
**Réponses.** 1) Un checkpointer avec un `thread_id`, pour persister l'état et reprendre. 2) Un hook `PreToolUse` qui renvoie `permissionDecision: "deny"` au-delà de 10 jours. 3) MCP pour Postgres (agent ↔ données), A2A pour le partenaire (agent ↔ agent).
