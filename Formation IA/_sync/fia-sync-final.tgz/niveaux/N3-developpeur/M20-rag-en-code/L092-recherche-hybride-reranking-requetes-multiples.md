---
id: L092
module: M20
level: N3
title: "Recherche hybride, reranking, requêtes multiples"
minutes: 50
objectives:
  - "Expliquer les forces complémentaires de la recherche lexicale (BM25) et vectorielle, et les fusionner par Reciprocal Rank Fusion"
  - "Implémenter un reranking par cross-encoder sur les candidats et mesurer son effet sur la précision du contexte"
  - "Appliquer la génération de requêtes multiples et HyDE pour améliorer le rappel sur des questions mal formulées"
  - "Mettre en œuvre le contextual retrieval (contexte généré par LLM pour chaque morceau) avec le prompt caching pour en limiter le coût"
skills: ["C3.3"]
sources:
  - { title: "Anthropic — Introducing Contextual Retrieval", url: "https://www.anthropic.com/news/contextual-retrieval", lang: "en" }
  - { title: "Claude Cookbook — Contextual embeddings guide", url: "https://platform.claude.com/cookbook/capabilities-contextual-embeddings-guide", lang: "en" }
  - { title: "Claude Platform — Prompt caching", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-caching", lang: "en" }
  - { title: "Claude Platform — Message Batches", url: "https://platform.claude.com/docs/en/build-with-claude/batch-processing", lang: "en" }
  - { title: "Gao et al. (2022) — Precise Zero-Shot Dense Retrieval without Relevance Labels (HyDE)", url: "https://arxiv.org/abs/2212.10496", lang: "en" }
  - { title: "PostgreSQL — Full Text Search", url: "https://www.postgresql.org/docs/current/textsearch.html", lang: "en" }
  - { title: "Qdrant — documentation (vecteurs sparse, fusion)", url: "https://qdrant.tech/documentation/", lang: "en" }
  - { title: "Sentence Transformers — documentation (Cross-Encoders)", url: "https://www.sbert.net", lang: "en" }
  - { title: "Claude Academy — Building with the Claude API (BM25, multi-index, reranking, contextual retrieval)", url: "https://academy.claude.com/courses/building-with-the-claude-api", lang: "en" }
---

# Recherche hybride, reranking, requêtes multiples

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 20

## 🎯 Ce que vous saurez faire
- Faire remonter la « procédure PR-2024-17 » quand un salarié la demande par son code — ce que la recherche vectorielle seule rate.
- Passer de 5 candidats « à peu près bons » à 5 candidats « vraiment bons » grâce à un reranker, pour le prix de 50 ms.
- Rattraper les questions mal posées (« c'est quoi le truc pour les frais ? ») par reformulation automatique.
- Donner à chaque morceau la mémoire de son document grâce au contextual retrieval, sans faire exploser la facture.

> 🧭 **En clair** — Imaginez deux bibliothécaires. Le premier comprend le sens (« rembourser mon train » = « frais de déplacement ») mais ne retient pas les numéros ; le second retrouve n'importe quelle cote exacte (« PR-2024-17 ») mais ne comprend pas les synonymes. La **recherche hybride** les fait travailler ensemble et fusionne leurs listes. Ensuite, un **relecteur** plus lent mais plus attentif (le *reranker*) relit les vingt meilleures fiches avec la question sous les yeux et garde les cinq vraiment utiles. Enfin, on peut reformuler la question (multi-query, HyDE) et coller sur chaque fiche un petit résumé de son document (*contextual retrieval*).

## 1. Le problème : la recherche vectorielle seule ne suffit pas

Relancez la base de L089 avec la question « Que dit la procédure PR-2024-17 ? ». Résultat typique : des morceaux sur les procédures en général, mais pas celle-là. Le modèle d'embedding voit « PR-2024-17 » comme une suite de signes sans sens ; il n'a aucune raison de la placer près du bon paragraphe. Même chose pour un nom de fournisseur rare, une référence d'article, une ligne de budget.

À l'inverse, la recherche **lexicale** (mots-clés, type moteur de 2005) retrouve « PR-2024-17 » instantanément, mais rate « comment me faire rembourser mon train » si la procédure dit « frais de déplacement ».

| | Vectoriel (dense) | Lexical (BM25) |
|---|---|---|
| Paraphrases, synonymes | ✅ | ❌ |
| Codes, références, noms propres, acronymes | ❌ | ✅ |
| Questions longues et floues | ✅ | ❌ |
| Termes exacts (« article L1234-5 ») | ❌ | ✅ |
| Multilingue | ✅ (selon modèle) | ❌ |

**BM25** (Best Matching 25, Robertson et al., années 1990) note un document selon la fréquence des termes de la requête, pondérée par leur rareté dans le corpus et la longueur du document. C'est le cœur d'Elasticsearch et de la recherche plein texte de PostgreSQL (qui utilise un classement voisin, `ts_rank`, avec un dictionnaire français pour les racines : « remboursement » ≈ « rembourser »).

```quiz
{
  "q": "Un salarié demande « Que dit la procédure PR-2024-17 ? ». Quelle recherche a le plus de chances de trouver le bon passage ?",
  "options": [
    "La recherche lexicale (BM25), sur les termes exacts",
    "La recherche vectorielle seule, avec un k plus grand (k = 50)",
    "Un modèle d'embedding plus grand et plus récent",
    "Aucune : les codes ne peuvent pas être recherchés"
  ],
  "answer": 0,
  "explanation": "Pour un modèle d'embedding, « PR-2024-17 » est une suite de signes sans sens. La recherche lexicale, elle, retrouve le terme exact instantanément : c'est pour cela qu'on combine les deux."
}
```

## 2. Recherche hybride : deux listes, une fusion

### 2.1 La recherche lexicale dans PostgreSQL

Ajoutons au schéma de L089 une colonne plein texte générée et son index :

```sql
-- hybride.sql — colonne tsvector en français, générée automatiquement
ALTER TABLE chunks ADD COLUMN tsv tsvector
  GENERATED ALWAYS AS (to_tsvector('french', contenu)) STORED;
CREATE INDEX chunks_tsv_gin ON chunks USING gin (tsv);
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `ALTER TABLE chunks ADD COLUMN tsv tsvector` ajoute une colonne à la table de L089. `GENERATED ALWAYS AS (to_tsvector('french', contenu)) STORED` la remplit **automatiquement** : PostgreSQL découpe chaque `contenu` en mots, les ramène à leur racine française (« remboursement », « rembourser » → même racine), retire les mots vides (« le », « de ») et stocke le résultat ; à chaque insertion ou modification, la colonne se recalcule seule. L'index `gin` rend la recherche dans cette colonne rapide. Exécution : `docker exec -i pg-breval psql -U postgres < hybride.sql`.

### 2.2 Reciprocal Rank Fusion (RRF)

Comment combiner un score cosinus (0,62) et un score BM25 (14,3) ? On ne le fait pas : on combine des **rangs**. RRF (Cormack, Clarke et Buettcher, 2009) attribue à chaque document `Σ 1 / (k + rang_i)` sur chaque liste où il apparaît, avec `k = 60` par convention. Un document 1er en vectoriel et 3e en lexical bat un document 1er dans une seule liste. Simple, sans réglage, robuste : c'est la méthode par défaut dans Qdrant, Weaviate et la plupart des moteurs.

```python
# recherche_hybride.py — vectoriel + plein texte PostgreSQL, fusion RRF
import os, psycopg
from pgvector.psycopg import register_vector
from embeddings import embed

DSN = os.environ["PG_DSN"]

def _lignes(rows):
    return [{"id": r[0], "contenu": r[1], "page": r[2], "source": r[3]} for r in rows]

def rechercher_vectoriel(conn, question: str, n: int) -> list[dict]:
    q = embed([question], usage="query")[0]
    return _lignes(conn.execute(
        "SELECT c.id, c.contenu, c.page, d.source FROM chunks c JOIN documents d ON d.id = c.document_id "
        "ORDER BY c.embedding <=> %s::vector LIMIT %s", (q, n)).fetchall())

def rechercher_lexical(conn, question: str, n: int) -> list[dict]:
    # websearch_to_tsquery accepte une saisie libre ("frais train", guillemets, -mot)
    return _lignes(conn.execute(
        "SELECT c.id, c.contenu, c.page, d.source FROM chunks c JOIN documents d ON d.id = c.document_id "
        "WHERE c.tsv @@ websearch_to_tsquery('french', %s) "
        "ORDER BY ts_rank_cd(c.tsv, websearch_to_tsquery('french', %s)) DESC LIMIT %s", (question, question, n)).fetchall())

def rrf(listes: list[list[dict]], k: int = 60) -> list[dict]:
    scores, docs = {}, {}
    for liste in listes:
        for rang, doc in enumerate(liste, start=1):
            scores[doc["id"]] = scores.get(doc["id"], 0.0) + 1.0 / (k + rang)
            docs[doc["id"]] = doc
    return [dict(docs[i], rrf=round(s, 4)) for i, s in sorted(scores.items(), key=lambda x: -x[1])]

def rechercher_hybride(question: str, n_candidats: int = 20) -> list[dict]:
    with psycopg.connect(DSN) as conn:
        register_vector(conn)
        return rrf([rechercher_vectoriel(conn, question, n_candidats),
                    rechercher_lexical(conn, question, n_candidats)])

if __name__ == "__main__":
    for r in rechercher_hybride("Que dit la procédure PR-2024-17 ?")[:5]:
        print(r["rrf"], r["source"], "p.", r["page"], "—", r["contenu"][:70])
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `_lignes(rows)` : transforme les lignes renvoyées par la base en dictionnaires lisibles.
> - `rechercher_vectoriel` : la recherche par le sens de L089 ; les `%s` sont des paramètres **positionnels**, remplis dans l'ordre par le tuple `(q, n)`.
> - `rechercher_lexical` : `websearch_to_tsquery('french', %s)` transforme la question en requête plein texte (mêmes racines françaises) ; `c.tsv @@ …` garde les morceaux qui contiennent ces mots, et `ts_rank_cd(...)` les classe du plus au moins pertinent.
> - `rrf(listes, k=60)` : pour chaque liste, `enumerate(liste, start=1)` donne le rang de chaque morceau ; on ajoute `1 / (60 + rang)` à son score (un morceau présent dans les deux listes cumule deux contributions). `sorted(scores.items(), key=lambda x: -x[1])` trie par score décroissant, et `dict(docs[i], rrf=…)` renvoie une copie du morceau avec son score ajouté.
> - `rechercher_hybride` : ouvre une connexion, lance les deux recherches avec 20 candidats chacune, puis fusionne.
>
> 🛠️ **Si ça ne marche pas** —
> - `column c.tsv does not exist` → `hybride.sql` n'a pas été exécuté → voir l'encadré précédent.
> - La recherche lexicale ne trouve pas « PR-2024-17 » → le découpage en mots de PostgreSQL coupe le code aux tirets, et la configuration `french` peut transformer les morceaux → testez `SELECT to_tsvector('french', 'procédure PR-2024-17');` pour voir ce qui est réellement stocké ; pour les codes, une seconde colonne en configuration `'simple'` (sans racines) donne souvent de meilleurs résultats.
> - `ModuleNotFoundError: No module named 'embeddings'` → `embeddings.py` (L089) doit être dans le même dossier.
> - Résultats identiques à la recherche vectorielle seule → la liste lexicale est vide (aucun mot commun) : c'est normal pour une question en langage courant, et c'est précisément ce que la fusion compense.

> 💡 **Autrement dit** — RRF fait voter les deux listes avec des points de classement. Un passage 1er en vectoriel et 3e en lexical obtient 1/61 + 1/63 ≈ 0,0323 ; un passage 1er dans une seule liste n'obtient que 1/61 ≈ 0,0164. Être bien classé par les deux bibliothécaires vaut mieux qu'être premier chez un seul.

Notez le `n_candidats = 20` : on demande *large* à chaque moteur, on fusionne, et le reranking (section 3) fera le tri fin. Avec Qdrant, la même chose se fait côté serveur : une collection avec un vecteur dense et un vecteur *sparse* (BM25 encodé), puis `query_points(prefetch=[Prefetch(dense), Prefetch(sparse)], query=FusionQuery(fusion=Fusion.RRF))` — voir la [documentation Qdrant](https://qdrant.tech/documentation/).

> 💡 **À retenir** — Hybride = **rappel**. On élargit le filet pour ne rien rater. C'est l'étape suivante, le reranking, qui apporte la **précision**. Les deux sont complémentaires, et c'est exactement l'enchaînement enseigné dans le module 6 du cours [Building with the Claude API](https://academy.claude.com/courses/building-with-the-claude-api) (BM25 → multi-index → reranking).

```mission
{
  "title": "Chasse à l'API : les fusions hybrides de Qdrant",
  "url": "https://qdrant.tech/documentation/",
  "steps": [
    "Ouvrez la documentation Qdrant",
    "Cherchez la page « Hybrid Queries » (rubrique Search / Concepts)",
    "Repérez les valeurs possibles du paramètre `fusion`"
  ],
  "question": "Quelles méthodes de fusion Qdrant propose-t-il pour combiner un vecteur dense et un vecteur sparse ?",
  "hint": "L'une d'elles est utilisée dans cette leçon ; l'autre s'appuie sur la distribution des scores.",
  "answer": "RRF (Reciprocal Rank Fusion) et DBSF (Distribution-Based Score Fusion) — documentation consultée en nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Reranking : un second regard, plus cher, plus juste

Un modèle d'embedding encode la question et le document **séparément** (bi-encodeur) : rapide, mais il ne « voit » jamais les deux ensemble. Un **cross-encoder** lit la paire (question, morceau) d'un bloc et renvoie un score de pertinence : bien plus précis, mais impossible à pré-calculer — on ne l'applique donc qu'aux 20-50 candidats de l'étape précédente.

Options en nov. 2026 :

- **Ouvert, en local** : des modèles de reranking multilingues sont disponibles sur le Hub Hugging Face (famille `bge-reranker`, par exemple) et s'utilisent via la classe `CrossEncoder` de [Sentence Transformers](https://www.sbert.net). Sur CPU, 20 paires prennent 100-300 ms ; sur GPU, quelques millisecondes. Vérifiez la fiche du modèle choisi pour la langue et la licence.
- **API** : des fournisseurs comme Cohere ou Voyage AI proposent des endpoints de reranking facturés à la requête ; nous n'avons pas vérifié leurs tarifs ni leurs ID de modèles pour cette session — consultez leurs pages officielles avant de les inscrire dans un devis.
- **Le LLM lui-même** : demander à Claude Haiku 5.5 (0,10 $ / M tokens en entrée, nov. 2026) de noter chaque candidat de 0 à 10. Plus lent et plus cher qu'un cross-encoder, mais zéro dépendance supplémentaire et un raisonnement explicable.

```python
# reranking.py — cross-encoder local sur les candidats de la recherche hybride
import os
from sentence_transformers import CrossEncoder
from recherche_hybride import rechercher_hybride

_reranker = CrossEncoder(os.environ.get("RERANKER_MODEL", "BAAI/bge-reranker-v2-m3"))  # ID à vérifier sur le Hub

def rechercher_rerank(question: str, k: int = 5, n_candidats: int = 25) -> list[dict]:
    candidats = rechercher_hybride(question, n_candidats)[:n_candidats]
    scores = _reranker.predict([(question, c["contenu"]) for c in candidats])
    for c, s in zip(candidats, scores):
        c["rerank"] = float(s)
    return sorted(candidats, key=lambda c: -c["rerank"])[:k]

if __name__ == "__main__":
    for r in rechercher_rerank("Combien de temps ai-je pour envoyer une note de frais ?"):
        print(round(r["rerank"], 3), r["source"], "p.", r["page"], "—", r["contenu"][:70])
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `CrossEncoder(...)` charge le modèle relecteur (téléchargé au premier lancement, comme en L089). `rechercher_hybride(question, n_candidats)` récupère 25 candidats ; `_reranker.predict([(question, c["contenu"]) for c in candidats])` donne au relecteur **chaque couple** (question, morceau) et renvoie un score par couple. `zip(candidats, scores)` associe chaque score à son morceau, puis `sorted(..., key=lambda c: -c["rerank"])[:k]` garde les 5 meilleurs. Si le chargement échoue (`OSError`), l'identifiant du modèle n'existe pas sur le Hub ou l'accès à Hugging Face est bloqué : vérifiez la fiche du modèle et définissez `RERANKER_MODEL`. Si la relecture est lente, c'est attendu sur un processeur sans GPU : réduisez `n_candidats` ou choisissez un modèle plus petit.

> ⚠️ **Piège fréquent** — Reranker 5 candidats. Le reranker ne peut pas faire remonter ce qui n'a pas été récupéré : donnez-lui 20 à 50 candidats, et gardez-en 5 à 8 pour le prompt. Et mesurez (L093) : sur un corpus de FAQ courtes et bien rédigées, le gain du reranking est parfois nul, et vous aurez ajouté 200 ms pour rien.

```quiz
{
  "q": "Vous ne donnez que 5 candidats au reranker, et le bon passage n'en fait pas partie. Que peut faire le reranker ?",
  "options": [
    "Le retrouver grâce à sa meilleure précision",
    "Le reconstituer à partir des autres passages",
    "Augmenter automatiquement `ef_search`",
    "Rien : il ne reclasse que ce qu'on lui donne"
  ],
  "answer": 3,
  "explanation": "Le reranker améliore la précision, pas le rappel : il ne peut pas faire remonter ce qui n'a pas été récupéré. On lui confie donc un filet large (20 à 50 candidats) et on garde 5 à 8 passages pour le prompt."
}
```

## 4. Requêtes multiples et HyDE : améliorer la question elle-même

### 4.1 Multi-query

Les salariés écrivent « c'est quoi le truc pour les frais ? ». Plutôt que de chercher avec cette phrase, on demande au LLM **trois reformulations** (« procédure de remboursement des notes de frais », « délai et justificatifs pour les frais professionnels », « plafonds de remboursement repas et hébergement »), on lance la recherche hybride pour chacune, et on fusionne par RRF. Coût : un appel à un petit modèle (une centaine de tokens) et trois recherches au lieu d'une.

### 4.2 HyDE (Hypothetical Document Embeddings)

Idée de Gao et al., 2022 ([arXiv 2212.10496](https://arxiv.org/abs/2212.10496)) : demander au LLM d'écrire **une réponse hypothétique** (même fausse dans les détails), puis vectoriser *cette réponse* à la place de la question. Un paragraphe qui ressemble à une procédure est plus proche, dans l'espace des embeddings, des vrais paragraphes de procédure qu'une question de douze mots. Très efficace sur les questions courtes ; à éviter quand le LLM risque d'inventer des entités (noms, codes) qui attireront les mauvais documents.

```python
# requetes.py — multi-query et HyDE avec Claude Haiku 5.5, fusion RRF
import os, json
from anthropic import Anthropic
from recherche_hybride import rechercher_hybride, rrf
from embeddings import embed

client = Anthropic()
MODELE_LEGER = os.environ.get("RAG_QUERY_MODEL", "claude-haiku-5-5")

def reformulations(question: str, n: int = 3) -> list[str]:
    r = client.messages.create(
        model=MODELE_LEGER, max_tokens=300,
        system="Vous aidez un moteur de recherche documentaire d'une PME de négoce de matériaux. "
               f"Proposez {n} reformulations variées de la question, en français, vocabulaire administratif. "
               "Répondez uniquement par un tableau JSON de chaînes.",
        messages=[{"role": "user", "content": question}],
    )
    try:
        return json.loads(r.content[0].text)[:n]
    except json.JSONDecodeError:
        return []                      # en cas de sortie mal formée, on retombe sur la question seule

def document_hypothetique(question: str) -> str:
    r = client.messages.create(
        model=MODELE_LEGER, max_tokens=200,
        system="Rédigez, en 3 phrases et sans inventer de chiffres ni de références, le paragraphe de procédure interne "
               "qui répondrait à la question. Style neutre, administratif.",
        messages=[{"role": "user", "content": question}],
    )
    return r.content[0].text

def rechercher_multi(question: str, n_candidats: int = 15, hyde: bool = False) -> list[dict]:
    variantes = [question] + reformulations(question)
    if hyde:
        variantes.append(document_hypothetique(question))
    return rrf([rechercher_hybride(v, n_candidats) for v in variantes])

if __name__ == "__main__":
    for r in rechercher_multi("c'est quoi le truc pour les frais ?", hyde=True)[:5]:
        print(r["rrf"], r["source"], "p.", r["page"], "—", r["contenu"][:70])
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `reformulations` : demande à Haiku trois variantes de la question, sous forme de tableau JSON ; `json.loads(...)` le transforme en liste Python, et `[:n]` en garde au plus trois.
> - `try: … except json.JSONDecodeError: return []` : si le modèle ne renvoie pas un JSON valide, on continue avec la seule question d'origine. Attention, l'échec est **silencieux** : un modèle qui entoure son JSON de balises de code Markdown fait échouer `json.loads` à chaque fois sans que vous le voyiez ; affichez la réponse brute pendant vos tests, ou utilisez une sortie structurée (L071), qui garantit le format.
> - `document_hypothetique` : la technique HyDE ; on fait rédiger un faux paragraphe de procédure, que l'on cherchera à la place de la question.
> - `rechercher_multi` : lance la recherche hybride pour chaque variante (`[… for v in variantes]`), puis fusionne toutes les listes avec la même fonction `rrf`.

> 🎮 **Défi** — Posez à votre base la question « combien pour un resto ? » en vectoriel seul, en hybride, puis en multi-query + HyDE. Notez à chaque étape le rang du morceau qui contient le plafond repas. Vous venez de faire, à la main, l'évaluation que L093 automatisera.

## 5. Contextual retrieval : rendre chaque morceau conscient de son document

Le défaut structurel du découpage : un morceau qui dit « Le plafond est fixé à 25 € » ne sait pas qu'il parle du **repas du midi**, dans la procédure **notes de frais**, **version 2026**. Anthropic a décrit en septembre 2024 une technique simple et mesurée, le **contextual retrieval** ([billet officiel](https://www.anthropic.com/news/contextual-retrieval)) : pour chaque morceau, on demande au modèle une ou deux phrases de contexte situant le morceau dans le document entier, on **préfixe** le morceau par ce contexte, puis on calcule l'embedding *et* l'index BM25 sur le texte enrichi. Le billet rapporte une réduction du taux d'échec de récupération de l'ordre de la moitié en combinant contextual embeddings, contextual BM25 et reranking (chiffres détaillés sur la page officielle).

Le coût semble prohibitif — un appel LLM par morceau avec le document complet en contexte — jusqu'à ce qu'on utilise le **prompt caching** : le document (souvent 5 000 à 50 000 tokens) est mis en cache une fois, et chaque morceau ne paie que la lecture du cache (0,1× le prix d'entrée, voire 0,05× sur Opus/Sonnet 5.5 — [page Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching), nov. 2026) plus ses propres quelques centaines de tokens. Pour aller encore plus bas, passez l'ingestion par la [Message Batches API](https://platform.claude.com/docs/en/build-with-claude/batch-processing) (−50 %).

```python
# contextual.py — génération du contexte de chaque morceau avec prompt caching (document en cache)
import os
from anthropic import Anthropic

client = Anthropic()
MODELE = os.environ.get("RAG_CONTEXT_MODEL", "claude-haiku-5-5")

def contextualiser(document_complet: str, morceaux: list[str]) -> list[str]:
    """Renvoie, pour chaque morceau, le texte enrichi 'contexte + morceau' à indexer."""
    enrichis = []
    for m in morceaux:
        r = client.messages.create(
            model=MODELE, max_tokens=120,
            system=[{
                "type": "text",
                "text": "Vous situez des extraits dans leur document d'origine pour améliorer une recherche documentaire. "
                        "Voici le document complet :\n<document>\n" + document_complet + "\n</document>",
                "cache_control": {"type": "ephemeral"},     # le document est mis en cache (min. 512 tokens)
            }],
            messages=[{"role": "user", "content":
                "Voici l'extrait :\n<extrait>\n" + m + "\n</extrait>\n"
                "Rédigez 1 à 2 phrases, en français, qui situent cet extrait dans le document (sujet, section, version, à quoi il sert). "
                "Répondez uniquement par ces phrases."}],
        )
        contexte = r.content[0].text.strip()
        enrichis.append(f"{contexte}\n\n{m}")
        # r.usage.cache_read_input_tokens > 0 à partir du 2e morceau : vérifiez-le lors de vos tests
    return enrichis
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Pour chaque morceau, un appel à Haiku contient deux parties : un bloc `system` avec **le document complet**, marqué `cache_control` (il est mis en cache au premier appel, puis relu à prix réduit), et un message `user` qui ne contient que l'extrait. Le modèle rédige une ou deux phrases de contexte, que l'on colle **devant** le morceau (`f"{contexte}\n\n{m}"`) ; c'est ce texte enrichi qui sera vectorisé et indexé.
>
> 🛠️ **Si ça ne marche pas** —
> - `cache_read_input_tokens` reste à 0 à partir du 2e morceau → le document fait moins de 512 tokens, ou le texte du bloc `system` change d'un appel à l'autre → vérifiez qu'il est identique au caractère près (L073).
> - Erreurs 429 sur un gros document → un appel par morceau, en rafale → ajoutez une petite pause entre les appels, ou passez l'ingestion par la Batch API.
> - Le contexte généré invente des détails (une version, une date) → le prompt ne l'interdit pas assez → ajoutez « sans rien ajouter qui ne figure pas dans le document » et relisez un échantillon.

Branchez `contextualiser()` dans `ingerer_dossier()` de L090 juste avant `embed(textes)` : les vecteurs et la colonne `tsv` sont calculés sur le texte enrichi. Ordre de grandeur pour Bréval Matériaux : 30 documents, 900 morceaux, document moyen 8 000 tokens ; avec Haiku 5.5 et le cache, l'enrichissement complet coûte quelques dizaines de centimes (nov. 2026) — à recalculer avec vos volumes à partir de la page Pricing. Le [guide « contextual embeddings » du cookbook Claude](https://platform.claude.com/cookbook/capabilities-contextual-embeddings-guide) détaille l'implémentation de référence.

```mission
{
  "title": "Chasse à l'info : les gains mesurés du contextual retrieval",
  "url": "https://www.anthropic.com/news/contextual-retrieval",
  "steps": [
    "Ouvrez le billet « Introducing Contextual Retrieval » d'Anthropic",
    "Repérez les résultats chiffrés (taux d'échec de récupération sur le top 20)",
    "Notez la réduction obtenue par chaque combinaison"
  ],
  "question": "De combien le taux d'échec de récupération baisse-t-il avec les contextual embeddings seuls, puis en ajoutant le contextual BM25, puis le reranking ?",
  "hint": "Les chiffres sont exprimés en pourcentage de réduction et en taux d'échec (de 5,7 % au départ).",
  "answer": "−35 % avec les contextual embeddings (5,7 % → 3,7 %), −49 % avec le contextual BM25 en plus (2,9 %), −67 % avec le reranking en plus (1,9 %) — billet de septembre 2024 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 6. Assembler : l'ordre des étapes

```
question ──▶ (multi-query / HyDE, optionnel) ──▶ recherche hybride (dense + BM25, 20-50 candidats)
        ──▶ fusion RRF ──▶ reranking cross-encoder ──▶ top 5-8 ──▶ prompt (L094)
```

Chaque brique est **optionnelle et mesurable**. La discipline à adopter : n'ajoutez une brique que si le jeu de test de L093 montre un gain. Ordre de priorité habituel pour un corpus de PME : hybride (gain presque systématique, coût nul) → contextual retrieval (gain fort sur les documents longs) → reranking (gain variable, latence) → multi-query / HyDE (seulement si les utilisateurs posent des questions courtes ou floues).

> 🔗 **Documentation officielle** — [Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval) 🇬🇧 · [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 · [PostgreSQL Full Text Search](https://www.postgresql.org/docs/current/textsearch.html) 🇬🇧 · [Qdrant](https://qdrant.tech/documentation/) 🇬🇧

```quiz
{
  "type": "vrai_faux",
  "q": "La leçon recommande d'activer toutes les briques (hybride, contextual retrieval, reranking, multi-query, HyDE) dès le départ pour maximiser la qualité.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. Chaque brique est optionnelle et mesurable : on n'en ajoute une que si le jeu de test (L093) montre un gain. Ordre habituel : hybride, puis contextual retrieval, puis reranking, puis multi-query / HyDE si les questions sont floues."
}
```

## 🧪 Exercice pratique

**Consigne.** Sur la base de Bréval Matériaux, constituez 12 questions dont 4 contiennent un **code ou nom exact** (référence de procédure, nom de fournisseur, numéro d'article) et 4 sont **floues ou familières**. Pour chaque question, vous connaissez le morceau attendu. Implémentez quatre configurations : (A) vectoriel seul, (B) hybride RRF, (C) hybride + reranking, (D) hybride + multi-query + reranking. Calculez pour chacune le **rang moyen** du morceau attendu et le **taux de présence dans le top 5**.

**Critères de réussite.**
1. Un tableau 4 configurations × 2 métriques, plus la latence moyenne par configuration.
2. (B) bat (A) sur les 4 questions à code exact ; vous expliquez pourquoi.
3. Vous identifiez au moins une question où (D) fait *moins bien* que (C) et vous expliquez par quoi (reformulation qui dérive ? document hypothétique qui invente un terme ?).
4. Vous choisissez une configuration par défaut pour la production et la justifiez par les chiffres et la latence.

**Pistes de corrigé.** Rang moyen : `statistics.mean(rangs)` avec rang = 51 si absent des 50 candidats. Sur la plupart des corpus de procédures, (B) et (C) donnent 90-100 % de présence dans le top 5 ; (D) aide surtout sur les 4 questions floues. Si la latence de (C) dépasse 500 ms sur CPU, essayez un reranker plus petit ou limitez à 15 candidats.

## ✅ Auto-évaluation express

1. Pourquoi fusionne-t-on des rangs (RRF) et non des scores ?
2. Un cross-encoder est plus précis qu'un bi-encodeur : pourquoi ne l'utilise-t-on pas pour toute la base ?
3. Qu'est-ce qui rend le contextual retrieval abordable ?

**Réponses.** 1. Les scores cosinus et BM25 ne sont pas sur la même échelle ni la même distribution ; les rangs, si. RRF n'a aucun paramètre à régler et résiste aux listes de qualité inégale. 2. Il doit lire chaque paire (question, document) au moment de la requête : impossible à pré-calculer, donc coût linéaire en nombre de documents ; on le réserve aux 20-50 candidats pré-sélectionnés. 3. Le prompt caching : le document complet est mis en cache une fois, et chaque appel par morceau ne paie que la lecture du cache (0,1× ou moins du prix d'entrée) ; la Batches API divise encore le coût par deux.

> ✅ **Si vous ne retenez que 3 choses** — 1. La recherche hybride (vectorielle pour le sens + plein texte BM25 pour les codes et les noms exacts), fusionnée par rangs avec RRF, élargit le filet : c'est le gain le plus sûr, pour un coût quasi nul. 2. Le reranking (un cross-encoder qui relit chaque couple question / morceau) trie finement 20 à 50 candidats ; multi-query et HyDE améliorent les questions floues. 3. Le contextual retrieval colle un contexte généré sur chaque morceau, rendu abordable par le prompt caching ; mais chaque brique s'ajoute seulement si le jeu de test (L093) prouve un gain.

## 📚 Pour aller plus loin
- [Anthropic — Introducing Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval) 🇬🇧 — méthode, résultats mesurés, prompt de référence.
- [Claude Cookbook — Contextual embeddings guide](https://platform.claude.com/cookbook/capabilities-contextual-embeddings-guide) 🇬🇧 — implémentation complète avec BM25 et reranking.
- [Gao et al. — HyDE](https://arxiv.org/abs/2212.10496) 🇬🇧 — l'article d'origine, court et clair.
- [PostgreSQL — Full Text Search](https://www.postgresql.org/docs/current/textsearch.html) 🇬🇧 — `to_tsvector`, `websearch_to_tsquery`, dictionnaires et classement.
- [Sentence Transformers](https://www.sbert.net) 🇬🇧 — bi-encodeurs et cross-encodeurs en local.

> 🗺️ **Et maintenant ?** — la leçon L093 vous donne l'instrument de mesure qui tranche tous ces choix : un jeu de test, des métriques de recherche gratuites et les métriques de génération de Ragas.
