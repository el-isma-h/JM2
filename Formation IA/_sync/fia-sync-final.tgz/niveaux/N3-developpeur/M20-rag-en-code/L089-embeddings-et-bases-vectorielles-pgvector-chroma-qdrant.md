---
id: L089
module: M20
level: N3
title: "Embeddings et bases vectorielles : pgvector, Chroma, Qdrant"
minutes: 55
objectives:
  - "Expliquer ce qu'est un embedding, une similarité cosinus et un index HNSW, et pourquoi on ne compare jamais deux modèles d'embedding entre eux"
  - "Calculer des embeddings avec OpenAI, Mistral, Gemini ou un modèle ouvert (sentence-transformers) et choisir le modèle selon le coût, la langue et la confidentialité"
  - "Créer un schéma pgvector dans PostgreSQL avec index HNSW, puis la même collection dans Chroma et Qdrant (Docker)"
  - "Comparer pgvector, Chroma, Qdrant, Weaviate, Milvus et Pinecone pour choisir la base adaptée à une PME"
skills: ["C3.3"]
sources:
  - { title: "Lewis et al. (2020) — Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks", url: "https://arxiv.org/pdf/2005.11401", lang: "en" }
  - { title: "OpenAI Developers — Embeddings", url: "https://developers.openai.com/api/docs/guides/embeddings", lang: "en" }
  - { title: "Mistral — Mistral Embed", url: "https://docs.mistral.ai/models/mistral-embed-23-12", lang: "en" }
  - { title: "Gemini API — Embeddings", url: "https://ai.google.dev/gemini-api/docs/embeddings", lang: "en" }
  - { title: "Perplexity — Embeddings quickstart", url: "https://docs.perplexity.ai/docs/embeddings/quickstart.md", lang: "en" }
  - { title: "Hugging Face — Inference Providers, premier appel", url: "https://huggingface.co/docs/inference-providers/main/guides/first-api-call", lang: "en" }
  - { title: "Ollama — documentation (catégorie embeddings)", url: "https://docs.ollama.com", lang: "en" }
  - { title: "pgvector — dépôt officiel", url: "https://github.com/pgvector/pgvector", lang: "en" }
  - { title: "Chroma — dépôt officiel", url: "https://github.com/chroma-core/chroma", lang: "en" }
  - { title: "Qdrant — documentation", url: "https://qdrant.tech/documentation/", lang: "en" }
  - { title: "Claude Academy — Building with the Claude API (module RAG & agentic search)", url: "https://academy.claude.com/courses/building-with-the-claude-api", lang: "en" }
---

# Embeddings et bases vectorielles : pgvector, Chroma, Qdrant

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 20

## 🎯 Ce que vous saurez faire
- Transformer les 120 pages de procédures d'une PME en vecteurs, et retrouver en 20 ms « le passage qui parle des notes de frais » même si la question ne contient pas ces mots.
- Choisir un modèle d'embedding (API ou local) en argumentant coût, langue, dimension et confidentialité.
- Monter en dix minutes une base vectorielle : pgvector dans votre PostgreSQL existant, Chroma pour un notebook, Qdrant dans Docker pour la production.
- Lire une requête `ORDER BY embedding <=> $1` et expliquer ce que fait l'index HNSW derrière.

> 🧭 **En clair** — Un RAG, c'est un **examen à livre ouvert** : au lieu d'exiger du modèle qu'il sache tout par cœur, on lui tend les bonnes pages du classeur juste avant qu'il réponde. Pour trouver ces pages vite, on donne à chaque paragraphe des **coordonnées GPS du sens** : un *embedding*, c'est-à-dire une liste de nombres qui place dans le même quartier les textes qui parlent de la même chose, même s'ils n'emploient pas les mêmes mots. La **base vectorielle** est le cadastre qui range ces adresses et répond en quelques millisecondes à la question « quels sont les voisins les plus proches de ma question ? ». Cette leçon vous apprend à calculer ces coordonnées et à choisir votre cadastre : pgvector, Chroma ou Qdrant.

## 0. Le fil rouge du module : la base documentaire de Bréval Matériaux

Tout le module M20 construit un seul système. **Bréval Matériaux** est une PME fictive de 45 salariés (négoce de matériaux de construction, Loire-Atlantique). Son intranet contient une trentaine de **PDF de procédures** (notes de frais, demandes de congés, consignes de sécurité en entrepôt, procédure de retour fournisseur…) et une **FAQ RH** en HTML d'une centaine de questions. Aujourd'hui, les salariés posent leurs questions à l'assistante de direction. Objectif : un assistant qui répond en citant la procédure exacte, page comprise. Dans cette leçon, nous posons la fondation : les vecteurs et leur stockage.

## 1. Qu'est-ce qu'un embedding, concrètement ?

Un **embedding** (plongement) est une liste de nombres — typiquement 384, 768, 1 024, 1 536 ou 3 072 valeurs — produite par un modèle de langage spécialisé à partir d'un texte. Ce vecteur encode le *sens* : « remboursement des frais de déplacement » et « comment me faire rembourser mon train ? » donnent des vecteurs proches, alors qu'ils ne partagent presque aucun mot. C'est précisément ce que la recherche par mots-clés classique ne sait pas faire.

Analogie : chaque texte reçoit une adresse GPS dans un espace à mille dimensions. Deux textes qui parlent de la même chose habitent le même quartier. Chercher, c'est demander « quels sont les cinq voisins les plus proches de ma question ? ».

On mesure la proximité par la **similarité cosinus** : le cosinus de l'angle entre deux vecteurs, entre −1 et 1 (1 = même direction = même sens). Les bases vectorielles stockent souvent la **distance** cosinus (1 − similarité), d'où le `ORDER BY ... ASC` que vous verrez plus bas. Deux règles absolues :

1. **Un espace par modèle.** Un vecteur OpenAI et un vecteur Mistral ne sont pas comparables : si vous changez de modèle, vous re-vectorisez toute la base.
2. **Même modèle à l'indexation et à la requête.** Évident, et pourtant première cause de « mon RAG trouve n'importe quoi » en support.

Le terme **RAG** (Retrieval-Augmented Generation) vient de l'article de Lewis et al. publié en 2020 chez Facebook AI Research ([arXiv 2005.11401](https://arxiv.org/pdf/2005.11401)) : au lieu de compter uniquement sur ce que le modèle a mémorisé, on *récupère* des passages pertinents puis on les *injecte* dans le prompt. L'idée précède ChatGPT de deux ans.

> 💡 **À retenir** — Un embedding ne « comprend » rien au sens humain : c'est une projection géométrique entraînée pour que des textes paraphrasés se retrouvent proches. Il est excellent sur le sens, médiocre sur les codes exacts (« procédure PR-2024-17 », numéros de série, noms propres rares). C'est pour cela que L092 ajoutera une recherche lexicale.

> 💡 **Autrement dit** — La similarité cosinus regarde si deux flèches pointent **dans la même direction**, pas si elles ont la même longueur : 1 = même direction (même sens), 0 = aucun rapport. La *distance* cosinus est l'envers du décor : plus elle est petite, plus les textes se ressemblent, d'où le tri croissant (`ASC`) des requêtes SQL.

```quiz
{
  "q": "Pour gagner du temps, vous vectorisez les nouveaux documents avec `bge-m3` et gardez les anciens vecteurs calculés avec `mistral-embed`. Que va-t-il se passer ?",
  "options": [
    "Des résultats incohérents : il faut tout re-vectoriser",
    "Tout fonctionne, car tous les vecteurs sont des listes de nombres comparables",
    "Seule la vitesse de recherche diminue, la pertinence reste identique",
    "Il suffit de normaliser les vecteurs pour pouvoir les mélanger"
  ],
  "answer": 0,
  "explanation": "Chaque modèle a son propre « système de coordonnées » : comparer un vecteur Mistral à un vecteur bge-m3, c'est comparer une adresse GPS à un numéro de cadastre. Règle n° 1 : un espace par modèle (et souvent une dimension différente)."
}
```

## 2. Choisir son modèle d'embedding (nov. 2026)

| Fournisseur | Modèle (ID) | Points clés | Tarif (nov. 2026) | Source |
|---|---|---|---|---|
| OpenAI | famille `text-embedding-*` | SDK `client.embeddings.create` ; paramètre `dimensions` pour réduire la taille | non listé sur la page Pricing au 1er nov. 2026 — à vérifier | [Embeddings](https://developers.openai.com/api/docs/guides/embeddings) |
| Mistral | `mistral-embed` ; `codestral-embed` (code) | API compatible Chat-Completions-style, données hébergées en Europe (option regional inference) | 0,10 $ / M tokens ; Codestral Embed 0,15 $ | [Mistral Embed](https://docs.mistral.ai/models/mistral-embed-23-12) |
| Google | `gemini-embedding-001`, `gemini-embedding-2` (multimodal) | paramètre `task_type` (document vs requête) | voir page Pricing (section embeddings non lue dans notre recherche) | [Gemini Embeddings](https://ai.google.dev/gemini-api/docs/embeddings) |
| Perplexity | `pplx-embed-v1-0.6b` / `-4b` ; variantes `-context-` | API Embeddings dédiée | 0,004 $ à 0,05 $ / M tokens | [Quickstart](https://docs.perplexity.ai/docs/embeddings/quickstart.md) |
| Ouvert, via Hugging Face | `BAAI/bge-m3`, `intfloat/multilingual-e5-large`… | multilingues, exécutables en local avec `sentence-transformers` ou via Inference Providers | gratuit en local (CPU suffit pour quelques milliers de pages) | [Inference Providers](https://huggingface.co/docs/inference-providers/main/guides/first-api-call) |
| Ouvert, via Ollama | catégorie « embeddings » du catalogue | `ollama pull <modèle>` puis endpoint local | gratuit | [docs.ollama.com](https://docs.ollama.com) |

Comment trancher pour Bréval Matériaux ? Trois critères :

- **Confidentialité** : les procédures RH contiennent parfois des données personnelles. Un modèle ouvert en local (ou Mistral hébergé en Europe) évite de transférer le corpus hors UE — argument RGPD que votre DPO appréciera.
- **Langue** : les procédures sont en français. Choisissez un modèle *multilingue* explicitement évalué en français ; consultez le classement MTEB sur Hugging Face (onglet multilingue) plutôt que la réputation.
- **Coût réel** : 120 pages ≈ 60 000 mots ≈ 90 000 tokens en français. À 0,10 $ / M tokens, l'indexation complète coûte **moins d'un centime**. Le coût des embeddings est presque toujours négligeable face au coût de génération ; ne sur-optimisez pas ici.

> ⚠️ **Piège fréquent** — Les identifiants de modèles d'embedding changent et les pages de tarifs ne les listent pas toujours. Lisez l'ID dans une variable d'environnement avec une valeur par défaut, et vérifiez la **dimension** renvoyée (`len(vector)`) avant de créer votre table : une colonne `vector(1536)` refusera un vecteur de 1 024 valeurs.

### 2.1 Une fonction `embed()` interchangeable

```python
# embeddings.py — une seule interface, quatre fournisseurs (clés lues dans l'environnement)
import os
from typing import Literal

Fournisseur = Literal["openai", "mistral", "gemini", "local"]
FOURNISSEUR: Fournisseur = os.environ.get("EMB_PROVIDER", "local")  # local = sentence-transformers, sans clé

def embed(textes: list[str], usage: Literal["document", "query"] = "document") -> list[list[float]]:
    """Renvoie un vecteur par texte, dans le même ordre. `usage` sert aux modèles asymétriques."""
    if FOURNISSEUR == "openai":
        from openai import OpenAI
        client = OpenAI()  # OPENAI_API_KEY
        modele = os.environ.get("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")  # ID à vérifier sur la page Models
        r = client.embeddings.create(model=modele, input=textes, dimensions=1024)  # même taille que VECTOR(1024)
        return [d.embedding for d in r.data]

    if FOURNISSEUR == "mistral":
        from mistralai import Mistral
        client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
        r = client.embeddings.create(model=os.environ.get("MISTRAL_EMBEDDING_MODEL", "mistral-embed"), inputs=textes)
        return [d.embedding for d in r.data]

    if FOURNISSEUR == "gemini":
        from google import genai
        client = genai.Client()  # GEMINI_API_KEY
        task = "RETRIEVAL_DOCUMENT" if usage == "document" else "RETRIEVAL_QUERY"
        r = client.models.embed_content(model=os.environ.get("GEMINI_EMBEDDING_MODEL", "gemini-embedding-001"),
                                        contents=textes, config={"task_type": task, "output_dimensionality": 1024})
        return [e.values for e in r.embeddings]

    # Local : pip install sentence-transformers — premier appel = téléchargement du modèle
    from sentence_transformers import SentenceTransformer
    global _modele_local
    try:
        _modele_local
    except NameError:
        _modele_local = SentenceTransformer(os.environ.get("LOCAL_EMBEDDING_MODEL", "BAAI/bge-m3"))
    return _modele_local.encode(textes, normalize_embeddings=True).tolist()

if __name__ == "__main__":
    v = embed(["Procédure de remboursement des notes de frais", "Comment me faire rembourser mon billet de train ?"])
    print("dimension :", len(v[0]))
    import numpy as np
    a, b = np.array(v[0]), np.array(v[1])
    print("cosinus :", float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b))))
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `Literal["openai", "mistral", "gemini", "local"]` : un type qui n'autorise que ces quatre textes ; `os.environ.get("EMB_PROVIDER", "local")` choisit le fournisseur, `local` par défaut (aucune clé nécessaire).
> - Chaque bloc `if FOURNISSEUR == …:` importe le SDK **seulement** s'il est utilisé, appelle l'API d'embeddings et renvoie une liste de vecteurs, dans l'ordre des textes. OpenAI reçoit `dimensions=1024` : les modèles `text-embedding-3-*` savent raccourcir leurs vecteurs, ce qui les aligne sur la colonne `VECTOR(1024)` de la section 4 (sans ce paramètre, `text-embedding-3-small` en produit 1 536). Gemini reçoit en plus `task_type` (un document et une question ne sont pas vectorisés tout à fait de la même façon) et `output_dimensionality=1024`, pour la même raison qu'OpenAI : `gemini-embedding-001` produit sinon 3 072 dimensions.
> - Le bloc local : `global _modele_local` puis `try: _modele_local except NameError:` est une astuce pour ne charger le modèle (lourd) qu'**une fois** ; au premier appel, la variable n'existe pas encore, Python lève `NameError` et on crée le modèle.
> - `encode(textes, normalize_embeddings=True).tolist()` : calcule les vecteurs, les ramène à une longueur de 1 (le cosinus devient alors un simple produit scalaire) et les convertit en listes Python.
> - Dans la démo, `a @ b` est le produit scalaire de NumPy et `np.linalg.norm` la longueur d'un vecteur : c'est la formule du cosinus de L080.
>
> 🛠️ **Si ça ne marche pas** —
> - Le premier lancement en local dure plusieurs minutes et télécharge beaucoup → normal : `BAAI/bge-m3` pèse plusieurs gigaoctets et `sentence-transformers` installe aussi PyTorch → laissez finir une fois ; pour tester vite, essayez un modèle plus petit via `LOCAL_EMBEDDING_MODEL` (en recalibrant ensuite la dimension de vos tables).
> - `EMB_PROVIDER=local python embeddings.py` refusé sous Windows → cette écriture est propre à macOS / Linux → en PowerShell, faites `$env:EMB_PROVIDER="local"` puis `python embeddings.py`.
> - `ModuleNotFoundError: No module named 'sentence_transformers'` → `pip install sentence-transformers` (avec un tiret à l'installation, un tiret bas à l'import).
> - `OSError` au chargement du modèle → pas d'accès à Hugging Face (proxy d'entreprise, hors ligne) → téléchargez le modèle depuis une autre connexion ou passez par un fournisseur API.

Lancez `EMB_PROVIDER=local python embeddings.py` : vous devriez obtenir une similarité élevée (souvent > 0,6 pour ce type de paire) entre la procédure et la question du salarié. Testez ensuite avec « Horaires d'ouverture de l'entrepôt » : la similarité chute. Vous venez de faire de la recherche sémantique.

> 🎮 **Défi** — Écrivez cinq paires de phrases (synonymes, paraphrases, phrases sans rapport, même mots mais sens différent : « le compte est bon » vs « ouvrir un compte client ») et notez les cosinus. Quel cas surprend le plus votre modèle ?

## 3. Pourquoi une base vectorielle ? L'index HNSW

Avec 300 vecteurs, une boucle Python qui calcule 300 cosinus suffit (c'est ce que fait L080 du module M18). Avec 300 000 morceaux de documents et 50 requêtes par seconde, non. Une base vectorielle apporte trois choses : un **index approximatif** pour chercher vite, des **filtres** sur métadonnées (« seulement les documents du service RH, version 2026 »), et la **persistance** avec le reste de vos données.

L'index le plus répandu est **HNSW** (Hierarchical Navigable Small World) : un graphe à plusieurs étages où chaque vecteur est relié à ses voisins proches. La recherche part d'un étage grossier (peu de nœuds, grands sauts) et descend vers des étages fins. Analogie : chercher une rue en partant de la carte de France, puis de la région, puis du plan de ville. Deux paramètres à connaître :

- `m` : nombre de liens par nœud (16 par défaut ; plus = plus précis, plus de mémoire) ;
- `ef_construction` / `ef_search` : largeur de l'exploration à la construction et à la requête (plus = plus précis, plus lent).

L'index est **approximatif** : il peut rater le vrai plus proche voisin dans 1 à 2 % des cas. Pour une base documentaire de PME, c'est invisible ; pour de la détection de fraude, mesurez le rappel (L093).

Schéma — l'index HNSW vu comme des cartes routières empilées :

```text
Étage 2  (carte de France)   A ───────────────────── F        peu de points, grands sauts
                             │                       │
Étage 1  (carte régionale)   A ─────── C ───── E ─── F
                             │         │       │     │
Étage 0  (plan de ville)     A ─ B ─ C ─ D ─ E ─ F ─ G ─ H    tous les vecteurs, petits pas
                                             ▲
          La recherche entre par le haut, saute vers le point le plus proche de la question ★,
          descend d'un étage, recommence… et finit par explorer le quartier de ★ au rez-de-chaussée.
```

```quiz
{
  "type": "vrai_faux",
  "q": "L'index HNSW garantit de toujours renvoyer le vrai plus proche voisin de la question.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. HNSW est un index approximatif : il explore un nombre limité de candidats (`ef_search`) et peut rater le vrai plus proche voisin dans 1 à 2 % des cas. C'est invisible pour une base documentaire de PME, mais à mesurer pour des usages critiques."
}
```

## 4. Trois bases, un même schéma mental

Le modèle mental est identique partout : une **collection** (table) de **points**, chacun avec un `id`, un `vector`, un `payload` de métadonnées (source, page, service, date) et souvent le `text` d'origine. Notre recherche recommande la progression **pgvector → Chroma → Qdrant**.

### 4.1 pgvector : la voie royale pour une PME qui a déjà PostgreSQL

[pgvector](https://github.com/pgvector/pgvector) est une extension PostgreSQL (licence PostgreSQL) : vos vecteurs vivent à côté de vos tables clients, avec transactions, sauvegardes et droits habituels. Disponible sur Supabase, RDS, Scaleway et consorts.

```bash
# PostgreSQL 17 avec pgvector préinstallé
docker run -d --name pg-breval -e POSTGRES_PASSWORD="$PG_PASSWORD" -p 5432:5432 pgvector/pgvector:pg17
```

> 🧭 **Pré-requis express — Docker en cinq notions** — Une **image** est un paquet prêt à l'emploi (ici PostgreSQL avec pgvector déjà installé), un **conteneur** est une image en train de tourner, isolée du reste de votre machine. Dans `docker run -d --name pg-breval -e … -p 5432:5432 pgvector/pgvector:pg17` : `-d` lance le conteneur en arrière-plan, `--name` lui donne un nom, `-e NOM=valeur` lui passe une variable d'environnement (le mot de passe), `-p 5432:5432` relie le port 5432 de votre machine au port 5432 du conteneur, et le dernier mot est l'image à utiliser (téléchargée automatiquement la première fois). Commandes utiles : `docker ps` (conteneurs en marche), `docker logs pg-breval` (ses messages), `docker stop pg-breval` puis `docker start pg-breval`, `docker rm -f pg-breval` (le supprimer). Docker Desktop (Windows, macOS) doit être **démarré** avant toute commande.
>
> 🛠️ **Si ça ne marche pas** —
> - `Cannot connect to the Docker daemon` → Docker Desktop n'est pas lancé → démarrez-le et attendez qu'il soit prêt.
> - `Bind for 0.0.0.0:5432 failed: port is already allocated` → un PostgreSQL tourne déjà sur votre machine (ou un ancien conteneur) → utilisez un autre port, `-p 5433:5432`, et mettez `5433` dans votre chaîne de connexion.
> - Le conteneur s'arrête aussitôt (`docker ps` ne le montre pas) → `docker logs pg-breval` ; le plus souvent, `PG_PASSWORD` est vide, et l'image refuse de démarrer sans mot de passe → `export PG_PASSWORD=…`, puis `docker rm pg-breval` et relancez.
> - `Conflict. The container name "/pg-breval" is already in use` → un conteneur de ce nom existe déjà → `docker start pg-breval`, ou supprimez-le avant de le recréer.

```sql
-- schema.sql — base documentaire de Bréval Matériaux
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE documents (
  id          BIGSERIAL PRIMARY KEY,
  source      TEXT NOT NULL,             -- chemin relatif au dossier procedures/, ex. 'rh/notes-de-frais-v3.pdf' (L090)
  checksum    TEXT NOT NULL UNIQUE,      -- empreinte SHA-256 du fichier (déduplication, L090)
  service     TEXT,                      -- 'RH', 'Logistique', 'Compta'
  indexe_le   TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE chunks (
  id          BIGSERIAL PRIMARY KEY,
  document_id BIGINT REFERENCES documents(id) ON DELETE CASCADE,
  page        INT,
  position    INT,                       -- rang du morceau dans le document
  contenu     TEXT NOT NULL,
  embedding   VECTOR(1024) NOT NULL,     -- dimension = celle de VOTRE modèle (ex. bge-m3 = 1024)
  metadata    JSONB DEFAULT '{}'::jsonb
);

-- Index HNSW sur la distance cosinus ; m et ef_construction = valeurs par défaut explicitées
CREATE INDEX chunks_embedding_hnsw ON chunks
  USING hnsw (embedding vector_cosine_ops) WITH (m = 16, ef_construction = 64);

-- Index classiques pour les filtres
CREATE INDEX chunks_document_idx ON chunks (document_id);
CREATE INDEX chunks_metadata_gin ON chunks USING gin (metadata);
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `CREATE EXTENSION IF NOT EXISTS vector;` : active pgvector dans la base (une seule fois).
> - `BIGSERIAL PRIMARY KEY` : un identifiant numérique attribué automatiquement ; `REFERENCES documents(id) ON DELETE CASCADE` relie chaque morceau à son document et supprime les morceaux quand on supprime le document.
> - `embedding VECTOR(1024)` : une colonne qui contient un vecteur de **exactement** 1 024 nombres ; ce chiffre doit être celui de votre modèle.
> - `metadata JSONB` : un champ libre au format JSON, pour les étiquettes (service, date…).
> - `USING hnsw (embedding vector_cosine_ops)` : construit l'index HNSW pour la distance cosinus ; l'index `gin` accélère les filtres sur `metadata`.
> - Pour exécuter ce fichier dans le conteneur : `docker exec -i pg-breval psql -U postgres < schema.sql`.

La requête de recherche : `<=>` est l'opérateur de **distance cosinus** de pgvector (`<->` = euclidienne, `<#>` = produit scalaire négatif).

```python
# recherche_pgvector.py — top-5 des morceaux les plus proches, filtrés par service
import os, psycopg
from pgvector.psycopg import register_vector
from embeddings import embed

DSN = os.environ.get("PG_DSN", "postgresql://postgres:%s@localhost:5432/postgres" % os.environ["PG_PASSWORD"])

def rechercher(question: str, service: str | None = None, k: int = 5) -> list[dict]:
    q = embed([question], usage="query")[0]
    with psycopg.connect(DSN) as conn:
        register_vector(conn)                        # adapte les listes Python au type vector
        conn.execute("SET hnsw.ef_search = 80")      # largeur d'exploration (défaut 40) : précision vs vitesse
        rows = conn.execute(
            """
            SELECT c.contenu, c.page, d.source, 1 - (c.embedding <=> %(q)s::vector) AS similarite
            FROM chunks c JOIN documents d ON d.id = c.document_id
            WHERE (%(service)s IS NULL OR d.service = %(service)s)
            ORDER BY c.embedding <=> %(q)s::vector
            LIMIT %(k)s
            """,
            {"q": q, "service": service, "k": k},
        ).fetchall()
    return [{"contenu": r[0], "page": r[1], "source": r[2], "score": round(r[3], 3)} for r in rows]

if __name__ == "__main__":
    for r in rechercher("Combien de temps ai-je pour envoyer une note de frais ?", service="RH"):
        print(f"{r['score']}  {r['source']} p.{r['page']}  {r['contenu'][:80]}…")
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `from embeddings import embed` : réutilise la fonction de la section 2.1 ; `embeddings.py` doit être dans le même dossier.
> - `DSN = … % os.environ["PG_PASSWORD"]` : construit l'adresse de connexion (`postgresql://utilisateur:motdepasse@machine:port/base`) en y insérant le mot de passe à la place de `%s`.
> - `register_vector(conn)` : apprend à `psycopg` à envoyer une liste Python comme un vecteur pgvector.
> - `%(q)s`, `%(service)s`, `%(k)s` : des **paramètres nommés** ; `psycopg` y insère les valeurs du dictionnaire de manière sûre (jamais par collage de texte, ce qui protège des injections SQL). `::vector` précise le type.
> - `1 - (c.embedding <=> …)` : convertit la distance en similarité pour l'affichage ; `ORDER BY … <=> …` trie du plus proche au plus lointain.
> - `(%(service)s IS NULL OR d.service = %(service)s)` : le filtre ne s'applique que si un service est fourni.
>
> 🛠️ **Si ça ne marche pas** —
> - `ModuleNotFoundError: No module named 'psycopg'` ou `'pgvector'` → `pip install "psycopg[binary]" pgvector`.
> - `connection refused` → le conteneur ne tourne pas, ou le port n'est pas le bon → `docker ps`, et vérifiez le port de la chaîne de connexion.
> - `relation "chunks" does not exist` → le fichier `schema.sql` n'a pas été exécuté → voir la dernière ligne de l'encadré précédent.
> - `expected 1024 dimensions, not 384` (ou l'inverse) → le modèle d'embedding ne produit pas la dimension de la colonne → alignez `VECTOR(n)` sur `len(embed(["test"])[0])` et recréez la table.
> - Aucun résultat affiché → c'est normal à ce stade : la table est vide ; insérez quelques morceaux (exercice pratique) ou attendez le pipeline d'ingestion de L090.

> ⚠️ **Piège fréquent** — Un filtre `WHERE` très sélectif combiné à un index HNSW peut renvoyer **moins de k résultats** : l'index explore `ef_search` candidats, puis seulement le filtre s'applique. Remède : augmentez `hnsw.ef_search`, ou activez le scan itératif (`hnsw.iterative_scan`) disponible dans les versions récentes de pgvector (à vérifier sur le dépôt officiel), ou partitionnez par service.

```mission
{
  "title": "Chasse à l'API : jusqu'où pgvector indexe-t-il un vecteur ?",
  "url": "https://github.com/pgvector/pgvector",
  "steps": [
    "Ouvrez le dépôt officiel pgvector et faites défiler le README",
    "Repérez la section consacrée aux index HNSW (ou la FAQ sur les dimensions)",
    "Notez la limite de dimensions pour le type `vector` et le type à utiliser au-delà"
  ],
  "question": "Combien de dimensions au maximum une colonne `vector` peut-elle avoir pour être indexée en HNSW, et quel type permet d'aller plus loin ?",
  "hint": "Cherchez les mots « dimensions » et `halfvec` dans le README.",
  "answer": "2 000 dimensions pour `vector` ; `halfvec` (demi-précision) monte à 4 000 dimensions (et `bit` jusqu'à 64 000) — README consulté en nov. 2026, vérifiez pour votre version de pgvector (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

### 4.2 Chroma : la base embarquée du notebook

[Chroma](https://github.com/chroma-core/chroma) (Apache 2.0) s'installe par `pip install chromadb` et tient dans un dossier. Parfait pour prototyper en une heure, ou pour une application mono-poste.

```python
# chroma_demo.py — même logique, zéro serveur
import chromadb
from embeddings import embed

client = chromadb.PersistentClient(path="./breval_chroma")          # persistance sur disque
coll = client.get_or_create_collection(name="procedures", metadata={"hnsw:space": "cosine"})

morceaux = [
    {"id": "notes-frais-v3#p2#0", "texte": "Les notes de frais doivent être transmises dans les 30 jours suivant la dépense, avec justificatif original.", "meta": {"source": "notes-de-frais-v3.pdf", "page": 2, "service": "RH"}},
    {"id": "securite-entrepot#p1#0", "texte": "Le port du gilet haute visibilité et des chaussures de sécurité est obligatoire dans la zone de stockage.", "meta": {"source": "securite-entrepot.pdf", "page": 1, "service": "Logistique"}},
]
coll.upsert(
    ids=[m["id"] for m in morceaux],
    documents=[m["texte"] for m in morceaux],
    embeddings=embed([m["texte"] for m in morceaux]),
    metadatas=[m["meta"] for m in morceaux],
)

res = coll.query(query_embeddings=embed(["délai pour envoyer mes frais"], usage="query"),
                 n_results=3, where={"service": "RH"})
for doc, meta, dist in zip(res["documents"][0], res["metadatas"][0], res["distances"][0]):
    print(round(1 - dist, 3), meta["source"], "p.", meta["page"], "—", doc[:70])
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `chromadb.PersistentClient(path="./breval_chroma")` crée (ou rouvre) une base rangée dans ce dossier. `get_or_create_collection(..., metadata={"hnsw:space": "cosine"})` choisit la distance cosinus. `coll.upsert(ids=…, documents=…, embeddings=…, metadatas=…)` prend **quatre listes alignées** (le premier élément de chacune décrit le même morceau) ; *upsert* veut dire « insérer, ou remplacer si l'identifiant existe déjà ». `coll.query(...)` renvoie des listes de listes, une par question posée : d'où les `[0]` pour lire les résultats de la première (et unique) question. `round(1 - dist, 3)` convertit la distance en similarité.

Chroma peut aussi tourner en serveur (`docker run -p 8000:8000 chromadb/chroma`, puis `chromadb.HttpClient(host="localhost", port=8000)`), mais au-delà de quelques centaines de milliers de vecteurs ou de plusieurs utilisateurs concurrents, passez à Qdrant ou pgvector.

### 4.3 Qdrant : le moteur dédié pour la production auto-hébergée

[Qdrant](https://qdrant.tech/documentation/) (Rust, Apache 2.0) offre un serveur dédié, une API REST/gRPC, des filtres riches, la fusion dense + sparse (utile en L092), la quantification des vecteurs et une offre Cloud ou Hybrid Cloud (BYOC) si vous ne voulez pas l'héberger.

```bash
# Qdrant en local : API REST sur 6333, gRPC sur 6334, données persistées dans ./qdrant_storage
docker run -d --name qdrant -p 6333:6333 -p 6334:6334 -v "$(pwd)/qdrant_storage:/qdrant/storage" qdrant/qdrant
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Mêmes options que pour PostgreSQL, avec deux ports (6333 pour l'API REST, 6334 pour gRPC) et une option de plus : `-v "$(pwd)/qdrant_storage:/qdrant/storage"` relie un dossier de votre machine (`$(pwd)` = dossier courant) au dossier de données du conteneur. Sans ce **volume**, les données disparaîtraient en supprimant le conteneur. Sous PowerShell, remplacez `$(pwd)` par `${PWD}`. Une fois lancé, l'interface d'administration s'ouvre à l'adresse `http://localhost:6333/dashboard`.

```python
# qdrant_demo.py — pip install qdrant-client
import uuid
from qdrant_client import QdrantClient, models
from embeddings import embed

client = QdrantClient(url="http://localhost:6333")
COLL = "procedures"

if not client.collection_exists(COLL):
    client.create_collection(
        collection_name=COLL,
        vectors_config=models.VectorParams(size=1024, distance=models.Distance.COSINE),  # dimension de votre modèle
        hnsw_config=models.HnswConfigDiff(m=16, ef_construct=100),
    )
    client.create_payload_index(COLL, field_name="service", field_schema="keyword")  # filtre rapide

textes = ["Les demandes de congés se font sur l'intranet au moins 15 jours avant le départ.",
          "Tout retour fournisseur nécessite un bon de retour signé par le responsable d'agence."]
payloads = [{"source": "conges-v2.pdf", "page": 1, "service": "RH"},
            {"source": "retours-fournisseurs.pdf", "page": 3, "service": "Logistique"}]
client.upsert(COLL, points=[
    models.PointStruct(id=str(uuid.uuid5(uuid.NAMESPACE_URL, f"{p['source']}#{p['page']}#{i}")),  # id stable
                       vector=v, payload={**p, "contenu": t})
    for i, (t, v, p) in enumerate(zip(textes, embed(textes), payloads))
])

hits = client.query_points(
    COLL, query=embed(["poser des vacances"], usage="query")[0], limit=3,
    query_filter=models.Filter(must=[models.FieldCondition(key="service", match=models.MatchValue(value="RH"))]),
).points
for h in hits:
    print(round(h.score, 3), h.payload["source"], "p.", h.payload["page"], "—", h.payload["contenu"][:70])
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `client.collection_exists(COLL)` puis `create_collection(..., vectors_config=models.VectorParams(size=1024, distance=models.Distance.COSINE))` : crée la collection une seule fois, avec la dimension de votre modèle.
> - `create_payload_index(COLL, field_name="service", field_schema="keyword")` : indexe le champ `service` pour que le filtre soit rapide.
> - `uuid.uuid5(uuid.NAMESPACE_URL, f"{source}#{page}#{i}")` : fabrique un identifiant **toujours identique** pour le même morceau ; réindexer remplace au lieu de dupliquer.
> - `for i, (t, v, p) in enumerate(zip(textes, embed(textes), payloads))` : parcourt ensemble les textes, leurs vecteurs et leurs métadonnées, avec un numéro `i`.
> - `models.PointStruct(id=…, vector=v, payload={**p, "contenu": t})` : un point = identifiant + vecteur + métadonnées (texte compris).
> - `client.query_points(..., query_filter=models.Filter(must=[...]))` : recherche les 3 plus proches **parmi** les points du service RH ; `h.score` est déjà une similarité (plus grand = plus proche).
>
> 🛠️ **Si ça ne marche pas** —
> - `Connection refused` → le conteneur Qdrant ne tourne pas → `docker ps`, puis `docker start qdrant`.
> - Erreur « Vector dimension error » → `size=1024` ne correspond pas à votre modèle → supprimez la collection (`client.delete_collection(COLL)`) et recréez-la avec la bonne taille.
> - Le score n'a pas changé après un changement de modèle → la collection contient encore les anciens vecteurs → supprimez-la et réindexez tout.

Notez l'**identifiant stable** (UUID v5 dérivé de source + page + position) : réindexer le même document écrase le point au lieu de le dupliquer. Vous retrouverez ce principe en L090.

```mission
{
  "title": "Chasse à l'API : les distances proposées par Qdrant",
  "url": "https://qdrant.tech/documentation/",
  "steps": [
    "Ouvrez la documentation Qdrant",
    "Allez dans la partie « Concepts » puis « Collections »",
    "Repérez la liste des métriques de distance acceptées par `VectorParams`"
  ],
  "question": "Quelles métriques de distance pouvez-vous choisir à la création d'une collection Qdrant ?",
  "hint": "Le code de cette leçon en utilise une : `models.Distance.COSINE`.",
  "answer": "Dot (produit scalaire), Cosine, Euclid et Manhattan (documentation consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

### 4.4 TypeScript : pgvector depuis Node

```typescript
// recherche.ts — même requête pgvector en TypeScript (npm i pg pgvector openai)
import { Pool } from "pg";
import pgvector from "pgvector/pg";
import OpenAI from "openai";

const pool = new Pool({ connectionString: process.env.PG_DSN });
const openai = new OpenAI();
const MODELE_EMB = process.env.OPENAI_EMBEDDING_MODEL ?? "text-embedding-3-small"; // ID à vérifier

export async function rechercher(question: string, k = 5) {
  const { data } = await openai.embeddings.create({ model: MODELE_EMB, input: question, dimensions: 1024 }); // = VECTOR(1024)
  const client = await pool.connect();
  try {
    await pgvector.registerTypes(client);
    const { rows } = await client.query(
      `SELECT c.contenu, c.page, d.source, 1 - (c.embedding <=> $1) AS similarite
       FROM chunks c JOIN documents d ON d.id = c.document_id
       ORDER BY c.embedding <=> $1 LIMIT $2`,
      [pgvector.toSql(data[0].embedding), k],
    );
    return rows;
  } finally {
    client.release();
  }
}
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `new Pool({ connectionString })` crée un réservoir de connexions à PostgreSQL ; `pool.connect()` en emprunte une, et `finally { client.release(); }` la rend **toujours**, même en cas d'erreur. `pgvector.registerTypes(client)` apprend au pilote le type `vector`. Dans la requête, `$1` et `$2` sont les paramètres (l'équivalent des `%(q)s` Python), fournis dans la liste qui suit ; `pgvector.toSql(...)` met le vecteur au bon format. Attention à la **dimension** et au **modèle** : `dimensions: 1024` ramène le vecteur OpenAI à la taille de la colonne `VECTOR(1024)` (sinon `text-embedding-3-small` en produit 1 536 et PostgreSQL refuse la comparaison), mais cela ne suffit pas : la question doit être vectorisée par **le même modèle** que les documents. Ce script suppose donc que la table a été remplie avec `EMB_PROVIDER=openai` (et le même `OPENAI_EMBEDDING_MODEL`) ; si vous avez indexé avec bge-m3 en local, interrogez depuis Python ou exposez la fonction `embed` derrière une petite API.

## 5. Tableau de décision

| Base | Type | Licence | Quand la choisir pour une PME | Limites |
|---|---|---|---|---|
| **pgvector** | extension PostgreSQL | PostgreSQL | vous avez déjà Postgres ; < quelques millions de vecteurs ; vous voulez jointures, transactions, sauvegardes unifiées | filtres + HNSW à surveiller ; vecteurs indexés limités en dimension (utilisez `halfvec` au-delà, à vérifier sur le dépôt) |
| **Chroma** | embarquée Python/JS | Apache 2.0 | prototype, notebook, outil interne mono-poste | montée en charge et multi-utilisateurs limitées |
| **Qdrant** | moteur dédié (Rust) | Apache 2.0 | production auto-hébergée, hybride dense + sparse, quantification, Cloud/BYOC | un service de plus à exploiter |
| **Weaviate** | moteur dédié (Go) | BSD-3 | recherche hybride native, modules d'embedding intégrés | idem |
| **Milvus** | distribué (Zilliz) | Apache 2.0 | très grande échelle, Kubernetes | sur-dimensionné pour une PME |
| **Pinecone** | service managé | propriétaire | zéro exploitation ; cloud uniquement | dépendance fournisseur, données hors de chez vous |

Source du tableau : comparatifs 2026 consultés dans notre dossier de recherche (bigdataboutique, alexcloudstar, groovyweb, 25 oct. 2026).

> 💡 **À retenir** — Commencez par pgvector si PostgreSQL est déjà là : une table, un index, une requête SQL que toute l'équipe sait lire. Changez de moteur quand vous *mesurez* un problème (latence p95, mémoire, filtres), pas avant.

> 🔗 **Documentation officielle** — [pgvector](https://github.com/pgvector/pgvector) 🇬🇧 · [Chroma](https://github.com/chroma-core/chroma) 🇬🇧 · [Qdrant](https://qdrant.tech/documentation/) 🇬🇧 · [Gemini Embeddings](https://ai.google.dev/gemini-api/docs/embeddings) 🇬🇧

```quiz
{
  "q": "Une PME de 30 salariés fait tourner son ERP sur PostgreSQL, a 50 000 morceaux de documents à indexer et une équipe qui maîtrise SQL. Que lui conseillez-vous pour commencer ?",
  "options": [
    "Pinecone, pour n'avoir rien à exploiter",
    "Milvus sur Kubernetes, pour anticiper la croissance",
    "pgvector dans la base PostgreSQL existante",
    "Chroma en mode serveur partagé par tous"
  ],
  "answer": 2,
  "explanation": "Avec PostgreSQL déjà en place et un volume modeste, pgvector offre une table, un index et des requêtes SQL que l'équipe sait lire, avec des sauvegardes unifiées. On change de moteur seulement quand on mesure un problème."
}
```

## 🧪 Exercice pratique

**Consigne.** Montez la base de Bréval Matériaux dans pgvector **et** dans Qdrant avec un modèle d'embedding local (`sentence-transformers`). Insérez une vingtaine de phrases que vous rédigez vous-même (procédures RH, sécurité, logistique, compta — 5 par service), puis exécutez les cinq questions suivantes : « délai note de frais », « que porter dans l'entrepôt », « poser des vacances », « renvoyer une palette abîmée », « où est la cafétéria » (piège : aucune phrase n'en parle).

**Critères de réussite.**
1. La dimension de la colonne `VECTOR(n)` et celle de `VectorParams(size=n)` correspondent à `len(embed(["test"])[0])`.
2. Les quatre premières questions ramènent le bon service en première position dans les deux bases.
3. Pour « où est la cafétéria », vous affichez le score du premier résultat et proposez un **seuil** en dessous duquel l'application répondra « je n'ai pas cette information » plutôt qu'un passage hors sujet.
4. Réexécuter l'insertion ne crée pas de doublons (contrainte `UNIQUE` ou identifiant stable).

**Pistes de corrigé.** Pour le seuil, affichez les scores des 20 phrases pour chaque question : vous verrez un « trou » net entre les pertinentes (souvent > 0,55 avec bge-m3) et les autres. Fixez le seuil dans une variable d'environnement : il dépend du modèle et devra être recalibré si vous en changez. Pour la déduplication dans pgvector, `INSERT ... ON CONFLICT (checksum) DO NOTHING` sur la table `documents`.

## ✅ Auto-évaluation express

1. Vous passez de `mistral-embed` à un modèle local `bge-m3`. Que devez-vous faire de votre table `chunks` ?
2. Que signifie `embedding <=> $1` dans pgvector, et pourquoi la requête est-elle en `ORDER BY ... ASC` alors qu'on veut la *plus grande* similarité ?
3. Un filtre `WHERE service = 'Compta'` ne renvoie que 2 résultats au lieu des 5 demandés. Cause probable et remède ?

**Réponses.** 1. Tout re-vectoriser : les espaces d'embedding ne sont pas comparables, et la dimension change (1 024 vs celle de Mistral) — il faut donc aussi recréer la colonne et l'index. 2. `<=>` est la distance cosinus (1 − similarité) ; une petite distance = grande similarité, donc tri croissant. 3. L'index HNSW explore `ef_search` candidats avant d'appliquer le filtre ; si peu d'entre eux sont en Compta, il en reste moins que k. Augmentez `hnsw.ef_search`, utilisez le scan itératif ou partitionnez.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un embedding est un vecteur qui représente le sens d'un texte ; on utilise le même modèle à l'indexation et à la requête, et la dimension de la base doit être celle du modèle (changer de modèle = tout re-vectoriser). 2. Une base vectorielle ajoute un index rapide mais approximatif (HNSW), des filtres sur métadonnées et la persistance ; `<=>` est la distance cosinus de pgvector, d'où le tri croissant. 3. Commencez par pgvector si PostgreSQL est déjà là (Chroma pour un prototype, Qdrant pour une production dédiée), lancez-les avec Docker, et changez de moteur seulement quand vous mesurez un problème.

## 📚 Pour aller plus loin
- [Lewis et al., 2020 — l'article fondateur du RAG](https://arxiv.org/pdf/2005.11401) 🇬🇧 — 12 pages, lisibles, pour savoir d'où vient le mot.
- [OpenAI — Embeddings](https://developers.openai.com/api/docs/guides/embeddings) 🇬🇧 — cas d'usage, réduction de dimension, recommandations.
- [Mistral — Mistral Embed](https://docs.mistral.ai/models/mistral-embed-23-12) 🇬🇧 — fiche du modèle, hébergement européen.
- [Hugging Face — Inference Providers](https://huggingface.co/docs/inference-providers/main/guides/first-api-call) 🇬🇧 — appeler un modèle d'embedding ouvert sans l'installer.
- [Claude Academy — Building with the Claude API](https://academy.claude.com/courses/building-with-the-claude-api) 🇬🇧 — module 6 « RAG & agentic search » : text embeddings, full RAG flow. Cours gratuit, certificat à la clé.

> 🗺️ **Et maintenant ?** — la leçon L090 vous apprend à préparer ce que l'on range dans ce cadastre : extraire le texte des PDF et des pages web, le découper proprement et l'étiqueter.
