---
module: M20
title: "Fiche mémo — RAG en code"
---
# Fiche mémo — M20 · RAG en code

> En une phrase : un RAG, c'est un examen à livre ouvert. On range bien les fiches (ingestion), on retrouve les bonnes (recherche hybride + reranking), on répond en citant, et on mesure tout.

## Les 7 idées à retenir
1. Chaque modèle d'embedding a son propre espace. On utilise le même modèle à l'indexation et à la requête, et on re-vectorise tout si on en change (`L089`).
2. Si PostgreSQL est déjà là, on commence par pgvector. Chroma sert aux notebooks, Qdrant à la production auto-hébergée (`L089`).
3. L'ingestion fait 60 % de la qualité : parsing, structure respectée (une FAQ = une question + sa réponse), 256 à 512 tokens par morceau, métadonnées (`L090`).
4. L'ingestion doit être incrémentale et idempotente : une empreinte SHA-256 par fichier, aucun doublon (`L090`).
5. Un framework (LangChain, LlamaIndex) accélère le premier prototype, mais ne rend pas le RAG meilleur (`L091`).
6. Hybride (dense + BM25, fusion RRF) pour le rappel, reranking pour la précision. Le contextual retrieval reste abordable grâce au cache (`L092`).
7. Le jeu de test versionné est votre actif le plus précieux. On mesure la recherche sans LLM, puis la génération avec Ragas (`L093`, `L094`).

## Le schéma à connaître
```mermaid
flowchart LR
    Q["Question"] --> H["Hybride : dense + BM25 (20-50 candidats)"]
    H --> F["Fusion RRF"]
    F --> R["Reranking cross-encoder"]
    R --> S{"Score ≥ seuil ?"}
    S -->|"non"| N["« Je n'ai pas cette information »"]
    S -->|"oui"| G["Top 5-8 → Claude avec citations"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Similarité cosinus | Deux flèches pointent-elles dans la même direction ? |
| HNSW | Un index approximatif, comme des cartes routières empilées |
| BM25 | La recherche par mots-clés, imbattable sur « PR-2024-17 » |
| RRF | On fusionne des rangs, pas des scores : `Σ 1 / (60 + rang)` |
| Cross-encoder | Un juge qui lit la question et le passage ensemble : précis, mais lent |
| HyDE | On cherche avec une réponse hypothétique au lieu de la question |
| Context recall / Faithfulness | A-t-on récupéré ce qu'il faut ? La réponse colle-t-elle au contexte ? |

## Les pièges classiques
- Compter les morceaux en caractères au lieu de tokens.
- Ré-ingérer tout chaque nuit : sept copies de chaque morceau au bout d'une semaine.
- Combiner un filtre `WHERE` très sélectif avec HNSW : on obtient moins de k résultats.
- Reranker seulement 5 candidats. Le reranker ne fait pas remonter ce qui n'a pas été récupéré.
- Oublier les questions hors périmètre (15 % du jeu de test) : un RAG doit savoir refuser.
- Ne lire que la moyenne : les pires cas sont cachés dedans.
- Demander citations et JSON structuré dans le même appel : les deux sont incompatibles.

## Les commandes / chiffres / dates utiles
```sql
CREATE EXTENSION IF NOT EXISTS vector;
CREATE INDEX ON chunks USING hnsw (embedding vector_cosine_ops);
SET hnsw.ef_search = 80;                            -- défaut 40
SELECT contenu FROM chunks ORDER BY embedding <=> $1 LIMIT 5;   -- <=> = distance cosinus, tri croissant
ALTER TABLE chunks ADD COLUMN tsv tsvector GENERATED ALWAYS AS (to_tsvector('french', contenu)) STORED;
```
```python
# Génération citée : chaque extrait devient un bloc document, un extrait par bloc
[{"type": "document", "source": {"type": "content", "content": [{"type": "text", "text": e["contenu"]}]},
  "title": e["source"], "citations": {"enabled": True}} for e in top]
```
```bash
docker run -d -p 5432:5432 -e POSTGRES_PASSWORD="$PG_PASSWORD" pgvector/pgvector:pg17
docker run -d -p 6333:6333 -p 6334:6334 qdrant/qdrant
deepeval test run test_rag.py
```
- **pgvector** : `<=>` cosinus, `<->` euclidienne, `<#>` produit scalaire. HNSW jusqu'à 2 000 dimensions avec `vector`, 4 000 avec `halfvec`.
- **Qdrant** : distances Dot, Cosine, Euclid et Manhattan. Fusion RRF ou DBSF.
- **LlamaIndex** `SentenceSplitter` : 1 024 tokens et 200 de chevauchement par défaut.
- **Contextual retrieval** (Anthropic, 2024) : −35 % d'échecs de récupération, −49 % avec le contextual BM25, −67 % avec le reranking en plus.
- **Coûts nov. 2026** : `mistral-embed` 0,10 $/MTok. Mistral OCR 4.1 : 4 $ / 1 000 pages. Sonnet 5.5 à 2 / 10 $ (cache 0,10 $). Le projet Bréval coûte environ 3 $ d'API par mois.
- **PDF à Claude** : 600 pages, 128 Mo par requête.
- **Seuils du projet** : hit rate@5 ≥ 0,85, faithfulness ≥ 0,85, p95 < 5 s.

## Pour aller plus loin
- [pgvector](https://github.com/pgvector/pgvector)
- [Anthropic — Introducing Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval)
- [Ragas](https://github.com/vibrantlabsai/ragas)

## Auto-test (3 questions — réponses en bas de fiche)
1. Context recall = 0,55, faithfulness = 0,95. Où est le problème ?
2. Pourquoi fusionne-t-on des rangs (RRF) et non des scores ?
3. Pourquoi ne pas appeler le modèle quand le meilleur score de reranking est sous le seuil ?

---
**Réponses.** 1) Dans la recherche ou l'ingestion : les bons morceaux ne remontent pas. Inutile de toucher au prompt. 2) Les scores cosinus et BM25 n'ont ni la même échelle ni la même distribution. Les rangs, eux, se comparent. 3) Ça ne coûte rien, ça ne prend pas de temps, et sans contexte pertinent, la bonne réponse est un refus.
