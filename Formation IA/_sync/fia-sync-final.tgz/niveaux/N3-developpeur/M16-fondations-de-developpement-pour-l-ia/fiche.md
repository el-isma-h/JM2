---
module: M16
title: "Fiche mémo — Fondations de développement pour l'IA"
---
# Fiche mémo — M16 · Fondations de développement pour l'IA

> En une phrase : un appel à un LLM, c'est une requête HTTP avec du JSON. On la protège (clé côté serveur), on la fiabilise (retries, streaming) et on la chiffre (tokens × tarif).

## Les 7 idées à retenir
1. Un environnement isolé par projet et des versions figées : `uv init --python 3.12`, puis `uv sync` chez le collègue (`L065`).
2. La clé API vit dans l'environnement. Jamais dans le code, jamais dans Git, jamais dans le navigateur (`L065`).
3. Le SDK ajoute la clé, la version d'API, les retries et le typage. Dessous, c'est un simple `POST /v1/messages` (`L066`).
4. L'API est sans état : chaque requête renvoie tout l'historique utile (`L066`).
5. On réessaie seulement les erreurs passagères (408, 409, 429, 5xx, 529), avec backoff exponentiel, jitter et plafond. Jamais une 400, 401 ou 404 (`L066`).
6. Le streaming (SSE) affiche le texte au fil de l'eau. Il protège aussi les longues requêtes (`L066`).
7. Coût = tokens × prix. Pour le baisser : choisir le bon modèle, puis le cache, puis le batch, puis une sortie plus courte (`L067`).

## Le schéma à connaître
```mermaid
sequenceDiagram
    participant N as Navigateur
    participant S as Votre serveur (détient la clé)
    participant F as Fournisseur LLM
    N->>S: Question (sans clé)
    S->>S: Vérifie l'utilisateur, le quota, le budget
    S->>F: POST /v1/messages + clé + JSON
    F-->>S: 200 + content, stop_reason, usage
    S-->>N: Réponse (en streaming)
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| `uv.lock` / `package-lock.json` | Fige les versions exactes. On le versionne |
| `.env` | Les secrets locaux. Jamais versionné (on versionne `.env.example`) |
| `stop_reason` | Pourquoi le modèle s'arrête : `end_turn`, `max_tokens`, `tool_use`, `refusal` |
| SSE | Le flux d'événements texte du streaming |
| Backoff + jitter | Attendre de plus en plus longtemps, avec une part de hasard |
| Token bucket | Le quota se recharge en continu, pas d'un bloc chaque minute |
| Prompt caching | Le préfixe stable est relu à prix cassé |

## Les pièges classiques
- Mettre la clé dans une variable `VITE_` ou `NEXT_PUBLIC_`. Elle part dans le bundle, donc tout le monde peut la lire.
- Un `.env` commité reste dans l'historique Git. Il faut révoquer la clé.
- Lire `content[0].text` sans regarder le type du bloc.
- Envoyer `temperature`. Avec l'API `2026-10-21` (SDK v2), `temperature`, `top_p` et `top_k` donnent une erreur 400 sur tous les modèles, même à leur valeur par défaut.
- Mettre la date en tête du prompt système. Le préfixe change à chaque appel et le cache ne sert plus.
- Lancer 200 appels d'un coup : on reçoit des 429. Il faut un sémaphore.

## Les commandes / chiffres / dates utiles
```bash
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" -H "anthropic-version: 2026-10-21" \
  -H "content-type: application/json" \
  -d '{"model":"claude-haiku-5-5","max_tokens":200,"messages":[{"role":"user","content":"Bonjour"}]}'
```
```python
from anthropic import Anthropic
client = Anthropic(max_retries=4, timeout=60.0)        # lit ANTHROPIC_API_KEY
with client.messages.stream(model="claude-sonnet-5-5", max_tokens=400,
        messages=[{"role": "user", "content": "…"}]) as s:
    for t in s.text_stream: print(t, end="")
client.messages.count_tokens(model="claude-sonnet-5-5", messages=[…])  # gratuit
```
- **SDK v2 (21/10/2026)**, sous licence Apache 2.0 : Python `anthropic` 2.3.0, TS `@anthropic-ai/sdk` 1.3.0. Ils envoient `Authorization: Bearer`. En HTTP brut, l'en-tête reste `x-api-key`. OpenAI et xAI utilisent `Authorization: Bearer`.
- **Retries du SDK** : 2 par défaut. Le SDK respecte `retry-after`.
- **Erreurs** : 400 `invalid_request_error`, 401 `authentication_error`, 402 `billing_error`, 403 `permission_error`, 404 `not_found_error`, 409 `conflict_error`, 413 `request_too_large` (128 Mo), 429 `rate_limit_error`, 500 `api_error`, 504 `timeout_error`, 529 `overloaded_error`.
- **Flux SSE** : `message_start` → `content_block_start` / `content_block_delta` / `content_block_stop` → `message_delta` (porte `stop_reason` et l'usage final) → `message_stop`.
- **Tarifs nov. 2026 ($/MTok, entrée / sortie)** : Haiku 5.5 0,10 / 0,50 · Sonnet 5.5 2 / 10 · Opus 5.5 4 / 20 · Fable 5.1 10 / 50 · GPT-6 Luna 0,10 / 0,50 · GPT-6.1 Sol 2 / 10. La sortie coûte environ 5 fois l'entrée.
- **Cache Anthropic** : écriture à 1,25 × l'entrée (5 min) ou 2 × (1 h). Lecture à 0,05 × sur Sonnet et Opus 5.5. Il faut un préfixe d'au moins 512 tokens.
- **Batch** : −50 %, jusqu'à 100 000 requêtes par lot, résultat en 24 h maximum.
- **Concurrence** ≈ RPM × durée d'un appel (en min) × 0,8.
- **Repère** : ≈ 2,5 tokens par mot français avec le tokenizer Claude.

## Pour aller plus loin
- [API migration 2026-10-21](https://platform.claude.com/docs/en/api/migration-2026-10-21)
- [Streaming Messages](https://platform.claude.com/docs/en/build-with-claude/streaming)
- [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching)

## Auto-test (3 questions — réponses en bas de fiche)
1. Vous recevez un 401, puis un 529, puis un 429 avec `retry-after: 12`. Que faites-vous pour chacun ?
2. 300 e-mails par jour, 22 jours par mois, avec 900 tokens d'entrée et 120 de sortie : combien coûte le mois sur Sonnet 5.5 ?
3. Le cache ne lit rien sur un prompt système de 450 tokens qui commence par l'heure. Pourquoi ?

---
**Réponses.** 1) 401 : on s'arrête et on vérifie la clé. 529 : on réessaie avec backoff et jitter. 429 : on attend au moins 12 s et on réduit la concurrence. 2) (900 × 2 + 120 × 10) / 10⁶ = 0,003 $ par appel, soit ≈ 19,80 $ par mois (≈ 0,99 $ sur Haiku 5.5). 3) Le préfixe fait moins de 512 tokens, et l'heure le change à chaque appel.
