---
id: L067
module: M16
level: N3
title: "Tokens, coûts, rate limits, caching : maîtriser la facture"
minutes: 65
objectives:
  - "Compter et estimer les tokens d'une requête (count_tokens, heuristiques) et expliquer pourquoi le même texte n'a pas le même nombre de tokens chez deux fournisseurs"
  - "Calculer le coût d'un appel et d'un usage mensuel à partir des tarifs publics de novembre 2026 (Anthropic, OpenAI, xAI, Mistral, Google) avec un calculateur Python"
  - "Expliquer le fonctionnement des limites de débit (paliers, token bucket, en-têtes, erreur 429) et dimensionner la concurrence d'une application"
  - "Appliquer le prompt caching et le traitement par lots (batch) pour réduire la facture, et mettre en place un budget avec garde-fous et alertes"
skills: ["C3.1"]
sources:
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — Token counting", url: "https://platform.claude.com/docs/en/build-with-claude/token-counting", lang: "en" }
  - { title: "Claude Platform — Rate limits", url: "https://platform.claude.com/docs/en/api/rate-limits", lang: "en" }
  - { title: "Claude Platform — Service tiers", url: "https://platform.claude.com/docs/en/api/service-tiers", lang: "en" }
  - { title: "Claude Platform — Prompt caching", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-caching", lang: "en" }
  - { title: "Claude Platform — Cache diagnostics", url: "https://platform.claude.com/docs/en/build-with-claude/cache-diagnostics", lang: "en" }
  - { title: "Claude Platform — Batch processing", url: "https://platform.claude.com/docs/en/build-with-claude/batch-processing", lang: "en" }
  - { title: "Claude Platform — Optimizing for cost and intelligence", url: "https://platform.claude.com/docs/en/about-claude/models/optimizing-for-cost-and-intelligence", lang: "en" }
  - { title: "Claude Platform — Usage & Cost Analytics API", url: "https://platform.claude.com/docs/en/manage-claude/usage-cost-analytics-api", lang: "en" }
  - { title: "OpenAI — Pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "OpenAI — Rate limits", url: "https://developers.openai.com/api/docs/guides/rate-limits", lang: "en" }
  - { title: "xAI — Pricing", url: "https://docs.x.ai/developers/pricing", lang: "en" }
  - { title: "Mistral — Pricing", url: "https://docs.mistral.ai/inference/pricing", lang: "en" }
  - { title: "Google — Gemini API pricing", url: "https://ai.google.dev/gemini-api/docs/pricing", lang: "en" }
  - { title: "OWASP Top 10 for LLM Applications 2025 (Coralogix)", url: "https://coralogix.com/ai-blog/owasp-top-10-for-llm-applications/", lang: "en" }
---

# Tokens, coûts, rate limits, caching : maîtriser la facture

> ⏱ 65 min · 🎯 Niveau 3 · 📚 Module 16

## 🎯 Ce que vous saurez faire
- Répondre en chiffres, et non au doigt mouillé, à la question « combien va coûter cette fonctionnalité IA par mois ? ».
- Compter précisément les tokens d'une requête avant de l'envoyer, et estimer de tête un ordre de grandeur.
- Lire les en-têtes de limite de débit, comprendre un 429 et régler la concurrence de votre application en conséquence.
- Diviser la facture par deux, puis encore par deux, avec le prompt caching, le traitement par lots et le choix du bon modèle.
- Installer des garde-fous (budget par appel, plafonds, alertes) pour qu'aucune boucle infinie ni clé volée ne vide le compte.

> 🧭 **En clair** — Une API de modèle de langage se paie comme un **service de livraison de colis facturé au poids**. Le poids, ce sont les **tokens**, des petits morceaux de texte : vous payez ce que vous envoyez (l'entrée) et, plus cher, ce que le modèle vous renvoie (la sortie). Le transporteur limite aussi le nombre de colis que vous pouvez déposer par minute (les **rate limits**) : au-delà, il vous répond « 429, revenez dans un instant ». Pour alléger la facture, vous choisissez le bon calibre de camion (un petit modèle pour les petites tâches), vous évitez de renvoyer chaque fois le même carton déjà enregistré (le **cache**), et vous regroupez les envois non urgents en un seul convoi de nuit à moitié prix (le **batch**). Enfin, vous fixez un plafond de dépense pour qu'aucune erreur ne vide le compte.

## 1. Le token, unité de compte de tout

Un modèle de langage ne lit pas des mots mais des **tokens** : des fragments de texte (un mot courant, une syllabe, un signe de ponctuation, un espace) produits par un découpeur appelé *tokenizer*. Tout se mesure en tokens : la fenêtre de contexte (1 million de tokens pour les modèles Claude 5.5, GPT-6 et Gemini 4 en nov. 2026), la vitesse (tokens par seconde), les limites de débit (tokens par minute) et, surtout, **le prix** (dollars par million de tokens, noté $/MTok).

Trois faits changent votre manière de concevoir une application :

1. **Chaque fournisseur a son propre tokenizer.** Le même e-mail de 200 mots peut valoir 280 tokens chez l'un et 320 chez l'autre. Anthropic a changé de tokenizer à partir de Claude Opus 4.7 : 1 million de tokens ≈ 555 000 mots anglais, et Haiku 5.5 consomme environ 30 % de tokens de plus que Haiku 4.5 pour le même texte. Comparer deux fournisseurs sur le prix au token sans comparer le nombre de tokens est donc une erreur classique.
2. **Le français coûte plus cher que l'anglais**, d'environ 1,3 à 1,5 fois : les tokenizers, entraînés sur des corpus surtout anglophones, découpent nos mots en plus de morceaux (« chaudière » devient facilement trois tokens). Le code, le JSON et les tableaux sont également gourmands.
3. **L'entrée et la sortie n'ont pas le même prix.** La sortie coûte en général cinq fois plus que l'entrée (2 $ contre 10 $ par MTok pour Sonnet 5.5), parce que générer un token exige un passage complet dans le modèle. Une réponse bavarde coûte plus qu'un long contexte.

```quiz
{
  "q": "Pour une même requête sur Claude Sonnet 5.5, qu'est-ce qui pèse le plus lourd sur la facture : 1 000 tokens d'entrée ou 1 000 tokens de sortie ?",
  "options": [
    "La sortie : 5 fois plus chère",
    "Les 1 000 tokens d'entrée, car le modèle doit relire tout le contexte à chaque fois",
    "C'est strictement identique : un token est un token, quelle que soit sa direction",
    "Cela dépend uniquement de la langue du texte, le français étant toujours plus cher"
  ],
  "answer": 0,
  "explanation": "Générer un token demande un passage complet dans le modèle : la sortie coûte en général cinq fois l'entrée. Une réponse bavarde coûte donc plus cher qu'un long contexte, d'où l'intérêt de limiter max_tokens et de demander un format concis."
}
```

### 1.1 Compter exactement : l'endpoint count_tokens

Avant un envoi coûteux (un PDF de 300 pages, un historique de conversation), demandez au fournisseur le compte exact. Chez Anthropic, `count_tokens` est gratuit et accepte les mêmes paramètres que `messages.create` (système, messages, outils).

```python
# compter_tokens.py — compte exact avant envoi (gratuit, pas de génération)
from anthropic import Anthropic

client = Anthropic()

SYSTEME = "Vous êtes l'assistant de Chauffage Martin, PME de plomberie-chauffage à Lille. Répondez en français."
EMAIL = ("Bonjour, ma chaudière gaz de 2009 fait un bruit de claquement au démarrage, "
         "pouvez-vous passer cette semaine ? Rue Nationale, Lille. Cordialement, M. Dubois")

compte = client.messages.count_tokens(
    model="claude-sonnet-5-5",
    system=SYSTEME,
    messages=[{"role": "user", "content": EMAIL}],
)
print("tokens d'entrée :", compte.input_tokens)
print("mots            :", len((SYSTEME + " " + EMAIL).split()))
print("tokens / mot    :", round(compte.input_tokens / len((SYSTEME + " " + EMAIL).split()), 2))
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `client.messages.count_tokens(...)` prend **les mêmes arguments** que `messages.create` (sauf `max_tokens`), mais ne génère rien : il renvoie seulement `input_tokens`, le nombre de tokens que la requête coûterait en entrée. Les parenthèses autour de `EMAIL = ( "…" "…" )` permettent d'écrire une longue chaîne sur deux lignes. `texte.split()` découpe le texte aux espaces et `len(...)` compte les morceaux, donc les mots ; `round(x, 2)` arrondit à deux décimales.

Chez OpenAI, la bibliothèque `tiktoken` compte localement pour les tokenizers publiés ; ailleurs, l'`usage` renvoyé par un premier appel réel reste la référence.

### 1.2 Estimer de tête

Ordre de grandeur sans appel réseau : **≈ 1,8 token par mot anglais, ≈ 2,5 tokens par mot français** avec le tokenizer Claude depuis Opus 4.7 (la règle générale ~0,75 mot par token de L005 vaut pour d'autres tokenizers et donne des chiffres plus bas ; 1 000 mots de français ≈ 2 500 tokens, une page A4 dense ≈ 1 200 à 1 500 tokens). Mesurez ensuite votre propre coefficient avec `count_tokens` ou `usage` : c'est lui, pas la règle générale, qui alimentera vos prévisions.

> 💡 **À retenir** — Le prix affiché est par **million** de tokens. Un appel typique (900 tokens d'entrée, 120 de sortie) sur Sonnet 5.5 coûte 0,003 $. Ce n'est pas l'appel qui coûte cher, c'est la **multiplication** : 300 appels par jour, 22 jours, et le même appel devient 20 $ par mois ; dix fois plus de contexte ou dix fois plus d'utilisateurs, et ce sont 200 $.

## 2. La grille tarifaire de novembre 2026

Les prix ci-dessous sont ceux des pages officielles lues le 1er novembre 2026, en dollars par million de tokens, tarif standard. Ils changent souvent : Google a par exemple annoncé une hausse de Gemini 4 Argon au 1er décembre 2026 (2 → 4 $ en entrée, 10 → 20 $ en sortie). **Mettez la date dans vos tableurs.**

| Modèle (ID API) | Entrée | Sortie | Cache lecture | Cache écriture | Batch | Contexte |
|---|---|---|---|---|---|---|
| Claude Fable 5.1 (`claude-fable-5-1`) | 10 | 50 | 0,25 | 12,50 (5 min) / 20 (1 h) | 5 / 25 | 1M |
| Claude Opus 5.5 (`claude-opus-5-5`) | 4 | 20 | 0,20 | 5 / 8 | 2 / 10 | 1M |
| Claude Sonnet 5.5 (`claude-sonnet-5-5`) | 2 | 10 | 0,10 | 2,50 / 4 | 1 / 5 | 1M |
| Claude Haiku 5.5 (`claude-haiku-5-5`), ≤ 100k tokens | 0,10 | 0,50 | 0,01 | 0,125 / 0,20 | 0,05 / 0,25 | 1M |
| Claude Haiku 5.5, requêtes > 100k tokens | 0,50 | 2,50 | 0,05 | 0,625 / 1 | 0,25 / 1,25 | 1M |
| GPT-6 Astra (`gpt-6-astra`) | 10 | 50 | 1 | 12,50 (30 min) / 25 (12 h) | 0,5× | 1,05M |
| GPT-6.1 Sol (`gpt-6.1-sol`) | 2 | 10 | 0,10 | 2,50 / 5 | 0,5× | 1,05M |
| GPT-6.1 Terra (`gpt-6.1-terra`) | 1 | 5 | 0,05 | 1,25 / 2,50 | 0,5× | 1,05M |
| GPT-6 Luna (`gpt-6-luna`) | 0,10 | 0,50 | 0,01 | 0,125 / 0,25 | 0,5× | 1,05M |
| Grok 4.7 (`grok-4.7`) | 2 (4 au-delà de 200k) | 6 (12) | 0,50 | — | −20 % | 500k |
| Mistral Large 4 | 0,70 | 2,10 | 0,07 | — | tarif Batch (non chiffré sur la page) | — |
| Mistral Small 4 | 0,15 | 0,60 | 0,015 | — | idem | — |
| Gemini 4 Argon (`gemini-4-argon`) | 2 (→ 4 au 1/12) | 10 (→ 20) | — | — | ≈ 0,5× | 1M |
| Gemini 3.8 Flash (`gemini-3.8-flash`) | 0,75 (→ 1,50 au 1/1/2027) | 3,75 (→ 7,50) | — | — | ≈ 0,5× | 1M |

Lecture rapide : il y a **un facteur 100** entre Haiku 5.5 (ou GPT-6 Luna) et Fable 5.1 (ou GPT-6 Astra). Choisir le bon modèle pour chaque tâche est, de très loin, le premier levier de coût. Classer un e-mail en quatre catégories ne demande pas un modèle frontière.

> 🔗 **Documentation officielle** — [Claude Pricing](https://platform.claude.com/docs/en/about-claude/pricing) · [OpenAI Pricing](https://developers.openai.com/api/docs/pricing) · [xAI Pricing](https://docs.x.ai/developers/pricing) · [Mistral Pricing](https://docs.mistral.ai/inference/pricing) · [Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing)

## 3. Le calculateur de coûts

Voici un calculateur complet, exécutable hors ligne, qui encode la grille ci-dessus. Gardez-le dans votre dépôt et mettez à jour la table (et sa date) à chaque changement de prix.

```python
# calcul_cout.py — calculateur de coût d'appels LLM (tarifs publics au 1er nov. 2026)
# Sources : platform.claude.com/docs/en/about-claude/pricing · developers.openai.com/api/docs/pricing
#           docs.x.ai/developers/pricing · docs.mistral.ai/inference/pricing · ai.google.dev/gemini-api/docs/pricing
# Aucune clé API nécessaire : ce script fonctionne hors ligne.
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Tarif:
    """Prix en USD par million de tokens (MTok)."""
    fournisseur: str
    entree: float            # tokens d'entrée non cachés
    sortie: float            # tokens de sortie
    cache_lecture: float     # tokens d'entrée lus depuis le cache
    cache_ecriture: float    # tokens d'entrée écrits dans le cache (Anthropic : TTL 5 min)
    batch: float = 0.5       # multiplicateur du mode batch (0.5 = -50 %)


TARIFS: dict[str, Tarif] = {
    # Anthropic (nov. 2026) — cache write 5 min = 1,25× ; cache read = 0,025× à 0,1× selon le modèle
    "claude-fable-5-1":   Tarif("Anthropic", 10.00, 50.00, 0.25, 12.50, 0.5),
    "claude-opus-5-5":    Tarif("Anthropic",  4.00, 20.00, 0.20,  5.00, 0.5),
    "claude-sonnet-5-5":  Tarif("Anthropic",  2.00, 10.00, 0.10,  2.50, 0.5),
    "claude-haiku-5-5":   Tarif("Anthropic",  0.10,  0.50, 0.01,  0.125, 0.5),  # ≤ 100k tokens d'entrée
    # OpenAI (nov. 2026) — « cached input » ; écriture de cache 30 min = 1,25× ; Batch / Flex = 0,5×
    "gpt-6-astra":        Tarif("OpenAI",    10.00, 50.00, 1.00, 12.50, 0.5),
    "gpt-6.1-sol":        Tarif("OpenAI",     2.00, 10.00, 0.10,  2.50, 0.5),
    "gpt-6.1-terra":      Tarif("OpenAI",     1.00,  5.00, 0.05,  1.25, 0.5),
    "gpt-6-luna":         Tarif("OpenAI",     0.10,  0.50, 0.01,  0.125, 0.5),
    # xAI (nov. 2026) — cached 0,50 ; batch = -20 % ; écriture de cache non tarifée séparément (hypothèse : tarif d'entrée)
    "grok-4.7":           Tarif("xAI",        2.00,  6.00, 0.50,  2.00, 0.8),
    # Mistral (nov. 2026) — cached publié ; multiplicateur Batch non chiffré sur la page lue (hypothèse 0,5 : à vérifier)
    "mistral-large-4":    Tarif("Mistral",    0.70,  2.10, 0.07,  0.70, 0.5),
    "mistral-small-4":    Tarif("Mistral",    0.15,  0.60, 0.015, 0.15, 0.5),
    # Google (nov. 2026, avant la hausse du 1er déc. 2026 pour Argon) — cache : hypothèse 0,1× (à vérifier sur la page caching)
    "gemini-4-argon":     Tarif("Google",     2.00, 10.00, 0.20,  2.00, 0.5),
    "gemini-3.8-flash":   Tarif("Google",     0.75,  3.75, 0.075, 0.75, 0.5),
}


def cout_appel(modele: str, entree: int, sortie: int, cache_lu: int = 0,
               cache_ecrit: int = 0, batch: bool = False) -> float:
    """Coût en USD d'un appel. `entree` = tokens d'entrée NON cachés."""
    t = TARIFS[modele]
    usd = (entree * t.entree + sortie * t.sortie
           + cache_lu * t.cache_lecture + cache_ecrit * t.cache_ecriture) / 1_000_000
    return usd * t.batch if batch else usd


def cout_mensuel(modele: str, appels_par_jour: int, entree: int, sortie: int,
                 jours: int = 22, **kw) -> float:
    return cout_appel(modele, entree, sortie, **kw) * appels_par_jour * jours


def estimer_tokens(texte: str, langue: str = "fr") -> int:
    """Estimation grossière SANS appel réseau : ~1,8 token par mot en anglais
    (1M tokens ≈ 555k mots avec le tokenizer Claude depuis Opus 4.7), le français
    coûtant ~1,3× à 1,5× plus. Pour un chiffre exact : client.messages.count_tokens()."""
    mots = len(texte.split())
    facteur = 1.8 * (1.4 if langue == "fr" else 1.0)
    return round(mots * facteur)


if __name__ == "__main__":
    # Scénario Chauffage Martin : 300 e-mails/jour à classer et résumer.
    # Entrée ≈ 900 tokens (prompt système 600 + e-mail 300), sortie ≈ 120 tokens.
    print(f"{'modèle':<20}{'$/appel':>10}{'$/mois (300/j)':>16}{'batch $/mois':>14}")
    for m in TARIFS:
        a = cout_appel(m, 900, 120)
        mois = cout_mensuel(m, 300, 900, 120)
        mois_batch = cout_mensuel(m, 300, 900, 120, batch=True)
        print(f"{m:<20}{a:>10.5f}{mois:>16.2f}{mois_batch:>14.2f}")

    print("\n--- effet du prompt caching sur claude-sonnet-5-5 (prompt système de 600 tokens) ---")
    sans = cout_mensuel("claude-sonnet-5-5", 300, 900, 120)
    # Avec cache : 600 tokens lus depuis le cache, 300 non cachés ; le TTL de 5 min se rafraîchit à chaque lecture,
    # donc avec un appel toutes les 2 min le cache n'expire presque jamais : ~20 réécritures/jour (pauses, nuit)
    avec = cout_mensuel("claude-sonnet-5-5", 300, 300, 120, cache_lu=600) \
        + cout_appel("claude-sonnet-5-5", 0, 0, cache_ecrit=600) * 20 * 22
    print(f"sans cache : {sans:.2f} $/mois · avec cache : {avec:.2f} $/mois · économie : {100 * (1 - avec / sans):.0f} %")

    texte = "Bonjour, ma chaudière gaz de 2009 fait un bruit de claquement au démarrage, pouvez-vous passer cette semaine ?"
    print(f"\nEstimation hors ligne : {estimer_tokens(texte)} tokens pour {len(texte.split())} mots français")
```

> 🧭 **Pré-requis express — `@dataclass` et les annotations de type** — `@dataclass` est un raccourci de Python pour créer une « fiche » à champs nommés sans écrire de code répétitif : `Tarif("Anthropic", 2.00, 10.00, 0.10, 2.50, 0.5)` crée une fiche dont on lit ensuite `t.entree`, `t.sortie`… `frozen=True` interdit de modifier une fiche après sa création (un tarif ne doit pas changer en cours de calcul). Les annotations `entree: float`, `dict[str, Tarif]` ou `-> float` disent quel type de valeur est attendu ; Python ne les vérifie pas à l'exécution, mais votre éditeur, si. `from __future__ import annotations` permet d'utiliser ces annotations modernes sans souci de version.
>
> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `TARIFS: dict[str, Tarif] = {…}` : un dictionnaire qui associe chaque identifiant de modèle à sa fiche de prix ; `TARIFS["claude-haiku-5-5"]` donne la fiche de Haiku.
> - `cout_appel(...)` : multiplie chaque catégorie de tokens par son prix, additionne, divise par `1_000_000` (les `_` ne servent qu'à la lisibilité : c'est un million), puis applique la remise batch si `batch=True`.
> - `cout_mensuel(..., **kw)` : `**kw` récupère tous les arguments nommés supplémentaires (`batch=True`, `cache_lu=600`) et les transmet tels quels à `cout_appel`.
> - `f"{m:<20}{a:>10.5f}"` : mise en forme des colonnes ; `<20` aligne à gauche sur 20 caractères, `>10.5f` aligne à droite sur 10 caractères avec 5 décimales.
> - Le `\` en fin de ligne (calcul `avec = …`) prolonge simplement l'expression sur la ligne suivante.

Sortie (extrait) pour le scénario Chauffage Martin, 300 e-mails par jour :

```
modèle                 $/appel  $/mois (300/j)  batch $/mois
claude-fable-5-1       0.01500           99.00         49.50
claude-opus-5-5        0.00600           39.60         19.80
claude-sonnet-5-5      0.00300           19.80          9.90
claude-haiku-5-5       0.00015            0.99          0.49
gpt-6.1-sol            0.00300           19.80          9.90
gpt-6-luna             0.00015            0.99          0.49
mistral-small-4        0.00021            1.37          0.68
gemini-3.8-flash       0.00112            7.42          3.71

sans cache : 19.80 $/mois · avec cache : 12.94 $/mois · économie : 35 %
```

Le message pour le patron de Chauffage Martin est limpide : l'assistant coûte **moins d'un euro par mois** avec Haiku 5.5 ou GPT-6 Luna, une vingtaine avec Sonnet 5.5, une centaine avec Fable 5.1. La question n'est pas « l'IA est-elle chère ? » mais « quel niveau de qualité justifie quel modèle ? » (évaluations : module 22).

## 4. Rate limits : le droit de passage

### 4.1 Paliers et compteurs

Les fournisseurs limitent le débit de chaque organisation pour protéger leur infrastructure et éviter qu'un nouveau compte ne dépense des milliers de dollars par erreur. Chez Anthropic, les limites dépendent d'un **palier d'usage** (*usage tier*) qui progresse avec vos dépenses : la page officielle décrit, en novembre 2026, les paliers *Evaluation*, *Start*, *Build*, *Scale* (plafonds de dépenses mensuels de 500 $, 1 000 $ et 200 000 $) et *Custom*. Chaque palier fixe, **par modèle**, trois compteurs : requêtes par minute (RPM), tokens d'entrée par minute (ITPM) et tokens de sortie par minute (OTPM). Les valeurs exactes évoluent ; consultez la page plutôt que de les mémoriser.

Ces compteurs suivent l'algorithme du **seau à jetons** (*token bucket*) : la capacité se recharge en continu, pas d'un bloc toutes les 60 secondes. Vous pouvez donc consommer en rafale puis attendre quelques secondes.

> 💡 **Autrement dit** — Imaginez un guichet qui distribue des tickets d'accès depuis une borne qui se remplit au goutte-à-goutte. La borne contient au maximum, disons, 50 tickets ; chaque requête en consomme un ; la borne se recharge en continu, un ticket toutes les 1,2 seconde. Vous pouvez donc passer à dix d'un coup si la borne est pleine, mais si vous la videz, il faut attendre qu'elle se remplisse un peu. Il y a trois bornes de ce genre : une pour le nombre de requêtes, une pour les tokens envoyés, une pour les tokens reçus.

### 4.2 Lire les en-têtes

Chaque réponse porte votre situation dans des en-têtes `anthropic-ratelimit-*` : limite, restant et instant de réinitialisation pour les requêtes, les tokens d'entrée et les tokens de sortie, plus `retry-after` en cas de 429. Le SDK vous y donne accès via `with_raw_response` :

```python
# lire_ratelimits.py — inspecter les en-têtes de limite de débit
from anthropic import Anthropic

client = Anthropic()

brut = client.messages.with_raw_response.create(
    model="claude-haiku-5-5",
    max_tokens=20,
    messages=[{"role": "user", "content": "Réponds simplement : OK"}],
)
message = brut.parse()           # l'objet Message habituel
print(message.content[0].text if message.content[0].type == "text" else message.content)

print("\n--- en-têtes de limite de débit ---")
for nom, valeur in brut.headers.items():
    if nom.startswith("anthropic-ratelimit-") or nom in ("retry-after", "request-id"):
        print(f"{nom:<50} {valeur}")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `client.messages.with_raw_response.create(...)` fait le même appel que d'habitude, mais vous rend la **réponse HTTP brute** (avec ses en-têtes) au lieu du seul message. `brut.parse()` en extrait le message habituel ; `brut.headers.items()` parcourt les en-têtes sous forme de couples (nom, valeur), et la condition `nom.startswith("anthropic-ratelimit-")` ne garde que ceux qui concernent vos limites.

### 4.3 Dimensionner la concurrence

Une règle simple : **concurrence maximale ≈ RPM × durée moyenne d'un appel (en minutes) × 0,8**. Si votre palier autorise 50 requêtes par minute et qu'un appel dure 6 secondes (0,1 min), vous pouvez maintenir 50 × 0,1 × 0,8 = 4 appels en vol. C'est la valeur à donner au sémaphore de la leçon L066. Vérifiez aussi les tokens : 4 appels de 20 000 tokens d'entrée toutes les 6 secondes font 800 000 tokens par minute, ce qui dépasse largement la plupart des paliers d'entrée.

Quand un 429 survient malgré tout : respecter `retry-after`, ne pas réessayer immédiatement, et surtout **réduire** la concurrence plutôt que d'augmenter le nombre de tentatives. Pour les charges non urgentes, le mode batch (section 6) est hors limites de débit en temps réel. Pour les charges critiques, Anthropic propose un *Priority Tier* (page « Service tiers ») : capacité réservée moyennant un surcoût, avec le paramètre `service_tier` de l'API.

> ⚠️ **Piège fréquent** — Tester en développement avec 3 requêtes par minute, puis mettre en production devant 2 000 utilisateurs sans jamais avoir regardé son palier. Le premier jour de charge réelle se termine en 429 en cascade. Lisez vos en-têtes **avant** le lancement, et prévoyez une file d'attente.

> 🔗 **Documentation officielle** — [Rate limits](https://platform.claude.com/docs/en/api/rate-limits) · [Service tiers](https://platform.claude.com/docs/en/api/service-tiers) · [OpenAI — Rate limits](https://developers.openai.com/api/docs/guides/rate-limits)

```quiz
{
  "q": "Mise en situation : votre palier autorise 50 requêtes par minute et un appel dure en moyenne 6 secondes. Quelle valeur donnez-vous au sémaphore (nombre d'appels simultanés) ?",
  "options": [
    "50, la limite de requêtes par minute",
    "1, pour ne prendre aucun risque",
    "Environ 4 (50 × 0,1 min × 0,8)",
    "Autant que d'e-mails à traiter"
  ],
  "answer": 2,
  "explanation": "Concurrence ≈ RPM × durée d'un appel en minutes × 0,8 = 50 × 0,1 × 0,8 = 4. Vérifiez ensuite les limites de tokens par minute, qui sont souvent atteintes avant celle des requêtes."
}
```

## 5. Prompt caching : ne pas payer deux fois la même chose

### 5.1 L'idée

Dans une application réelle, l'essentiel de chaque requête est **identique d'un appel à l'autre** : le prompt système, les instructions de format, les exemples, la description des outils, le document de référence. L'API est sans état, donc vous renvoyez ces milliers de tokens à chaque fois… et vous les payez à chaque fois. Le **prompt caching** permet au fournisseur de conserver en mémoire le préfixe déjà traité (techniquement, le *KV cache* de l'attention, que vous avez rencontré avec les modèles locaux au module 10) et de ne vous facturer sa relecture qu'à une fraction du prix.

Chiffres Anthropic (nov. 2026) : l'écriture dans le cache coûte **1,25 ×** le prix d'entrée (durée de vie 5 minutes, **rafraîchie gratuitement** à chaque lecture) ou **2 ×** pour une durée d'une heure ; la lecture coûte **0,1 ×** (Haiku 5.5), **0,05 ×** (Opus et Sonnet 5.5) ou **0,025 ×** (Fable 5.1) le prix d'entrée. Le préfixe à mettre en cache doit faire au moins **512 tokens** sur les modèles 5.5. Sur une conversation ou un agent qui renvoie 10 000 tokens de contexte à chaque tour, l'économie dépasse souvent 80 % sur l'entrée.

Le cache fonctionne sur un **préfixe exact** : tout ce qui précède le point de cache doit être identique octet pour octet. Mettez donc le contenu stable (système, outils, documents) **en tête**, et le contenu variable (le message de l'utilisateur) **en queue**. Un horodatage ou un prénom placé au début du prompt système suffit à rendre le cache inopérant.

> 💡 **Autrement dit** — Le cache, c'est le transporteur qui garde en entrepôt le gros carton que vous lui envoyez à chaque fois (vos procédures, vos tarifs) : au lieu de le repeser et de le refacturer plein pot, il vous compte une petite taxe de « sortie d'entrepôt ». Mais il ne reconnaît le carton que s'il est **strictement identique** et posé **en premier** : changez une seule étiquette sur le dessus (une date, un prénom), et il le considère comme un nouveau colis.

### 5.2 En pratique

Deux manières de l'activer. La plus simple, introduite en 2026 : le **cache automatique**, en passant `cache_control` à la racine de la requête ; l'API place alors elle-même le point de cache au meilleur endroit. La manière fine : placer jusqu'à quatre points de cache (`cache_control` sur un bloc précis). Le champ `usage` vous dit ce qui s'est passé.

```python
# caching.py — prompt caching automatique et lecture des compteurs de cache
import time

from anthropic import Anthropic

client = Anthropic()

# Un prompt système long (> 512 tokens) : procédures, grille tarifaire, ton de la PME…
PROCEDURES = """Vous êtes l'assistant de Chauffage Martin, PME de plomberie-chauffage à Lille (12 salariés).
Règles de réponse : français, vouvoiement, 5 lignes maximum, jamais de prix ferme sans devis.
Grille indicative : entretien chaudière gaz 129 € TTC ; dépannage 89 € de déplacement + pièces ;
remplacement chauffe-eau 200 L à partir de 1 100 € posé ; adoucisseur à partir de 1 500 € posé.
Zones : Lille, Villeneuve-d'Ascq, Roubaix, Tourcoing, Marcq-en-Barœul, Lambersart, La Madeleine.
Horaires : lundi-vendredi 8 h-18 h ; astreinte week-end pour les pannes de chauffage uniquement.
Urgences : absence totale de chauffage ou d'eau chaude, fuite importante, odeur de gaz (dans ce cas,
dire d'appeler d'abord Urgence Sécurité Gaz au 0 800 47 33 33 et de ne pas rallumer d'appareil).
""" * 4  # répétition pour dépasser le seuil de 512 tokens dans cette démonstration


def demander(question: str):
    msg = client.messages.create(
        model="claude-sonnet-5-5",
        max_tokens=200,
        cache_control={"type": "ephemeral"},     # cache automatique : l'API choisit le point de cache
        system=PROCEDURES,
        messages=[{"role": "user", "content": question}],
    )
    u = msg.usage
    print(f"entrée non cachée={u.input_tokens:5d} | écrit en cache={u.cache_creation_input_tokens or 0:5d} "
          f"| lu depuis le cache={u.cache_read_input_tokens or 0:5d} | sortie={u.output_tokens}")
    return msg


demander("Intervenez-vous à Wambrechies ?")          # 1er appel : écriture du cache (1,25× sur le préfixe)
time.sleep(1)
demander("Combien coûte un entretien de chaudière ?")  # 2e appel : lecture du cache (0,05× sur Sonnet 5.5)
demander("Je sens une odeur de gaz, que faire ?")      # 3e appel : lecture, et le TTL de 5 min est rafraîchi
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `""" … """ * 4` : un texte sur plusieurs lignes, répété 4 fois pour dépasser artificiellement les 512 tokens du seuil de cache. Dans la vraie vie, votre prompt est long parce qu'il contient vraiment des procédures.
> - `cache_control={"type": "ephemeral"}` : active le cache automatique ; `ephemeral` signifie « temporaire » (5 minutes par défaut, rafraîchies à chaque lecture).
> - `u.cache_creation_input_tokens or 0` : `or 0` remplace une valeur vide (`None`) par 0, pour que l'affichage `:5d` (nombre entier sur 5 caractères) ne plante pas.
> - Les trois appels à `demander(...)` : le premier écrit le cache, les deux suivants le lisent ; c'est ce que les compteurs affichés doivent prouver.

La deuxième et la troisième ligne doivent montrer `lu depuis le cache` égal (à quelques tokens près) à la taille du prompt système, et `entrée non cachée` réduit à la question. Si `lu depuis le cache` reste à 0, vérifiez le seuil de 512 tokens et l'identité stricte du préfixe ; la page « Cache diagnostics » détaille les causes de ratés.

> 🛠️ **Si ça ne marche pas** —
> - `lu depuis le cache` reste à 0 → le préfixe fait moins de 512 tokens, ou il change d'un appel à l'autre (date, prénom, ordre des outils) → mesurez-le avec `count_tokens` et sortez tout élément variable du prompt système.
> - Le premier appel montre déjà une lecture de cache → normal si vous avez relancé le script moins de 5 minutes après : le cache de l'exécution précédente est encore vivant.
> - `TypeError` sur `cache_control` → SDK trop ancien → `uv add "anthropic>=2.3"` (ou `pip install -U anthropic`) puis relancez.
> - Les chiffres de coût ne baissent pas sur la facture → la lecture coûte peu, mais l'**écriture** coûte 1,25× : un cache réécrit à chaque appel (préfixe instable) coûte plus cher que pas de cache du tout.

Chez OpenAI, le cache est **automatique** sur les préfixes répétés (prix « cached input », par exemple 0,10 $ au lieu de 2 $ pour GPT-6.1 Sol) et se pilote avec `prompt_cache_key` ; chez xAI, le prix « cached » est également appliqué automatiquement ; chez Google, le *context caching* explicite se facture avec un coût de stockage horaire. Dans tous les cas, la règle « stable en tête, variable en queue » s'applique.

> 🔗 **Documentation officielle** — [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) · [Cache diagnostics](https://platform.claude.com/docs/en/build-with-claude/cache-diagnostics)

```quiz
{
  "type": "vrai_faux",
  "q": "Placer la date et l'heure du jour au tout début du prompt système, avant les procédures, n'a aucun effet sur le prompt caching.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Le cache repose sur un préfixe identique octet pour octet. Une donnée qui change en tête du prompt invalide tout ce qui suit : mettez le contenu stable en premier et le variable (date, question) à la fin."
}
```

## 6. Batch : moitié prix pour ceux qui savent attendre

Beaucoup de traitements n'ont rien d'interactif : classer les 4 000 e-mails de l'année, générer les fiches produits d'un catalogue, évaluer un jeu de tests. Pour ces charges, la **Message Batches API** d'Anthropic accepte jusqu'à **100 000 requêtes** (256 Mo) par lot, les traite de façon asynchrone (le plus souvent en **moins d'une heure**, au maximum 24 h), et facture **50 % de moins** sur l'entrée comme sur la sortie, cumulable avec le prompt caching. Les résultats restent disponibles 29 jours. OpenAI (Batch et Flex, 0,5 ×), Google (≈ 0,5 ×) et xAI (−20 %) proposent l'équivalent.

```python
# batch_emails.py — classer un lot d'e-mails à -50 % avec la Message Batches API
import json
import time

from anthropic import Anthropic

client = Anthropic()

EMAILS = {
    "mail-0001": "Ma chaudière ne démarre plus depuis ce matin, il fait 12 °C dans la maison.",
    "mail-0002": "Pouvez-vous m'envoyer un devis pour remplacer un chauffe-eau de 200 L ?",
    "mail-0003": "Facture n° 2026-118 : je n'ai pas reçu l'attestation d'entretien.",
    "mail-0004": "Petite fuite au niveau du robinet de la cuisine, pas urgent.",
}

# 1. Créer le lot : une requête Messages complète par e-mail, identifiée par custom_id
lot = client.messages.batches.create(
    requests=[
        {
            "custom_id": identifiant,
            "params": {
                "model": "claude-haiku-5-5",
                "max_tokens": 10,
                "system": "Classe l'e-mail en un seul mot parmi : URGENT, DEVIS, ADMINISTRATIF, PETIT_TRAVAUX.",
                "messages": [{"role": "user", "content": texte}],
            },
        }
        for identifiant, texte in EMAILS.items()
    ]
)
print("lot créé :", lot.id, "| statut :", lot.processing_status)

# 2. Attendre la fin (en production : tâche planifiée ou webhook, pas une boucle bloquante)
while lot.processing_status != "ended":
    time.sleep(30)
    lot = client.messages.batches.retrieve(lot.id)
    print("…", lot.processing_status, lot.request_counts)

# 3. Lire les résultats (ordre non garanti : on se repère avec custom_id)
resultats: dict[str, str] = {}
for entree in client.messages.batches.results(lot.id):
    if entree.result.type == "succeeded":
        bloc = entree.result.message.content[0]
        resultats[entree.custom_id] = bloc.text.strip() if bloc.type == "text" else "?"
    else:
        resultats[entree.custom_id] = f"ERREUR ({entree.result.type})"

print(json.dumps(resultats, indent=2, ensure_ascii=False))
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `requests=[ {…} for identifiant, texte in EMAILS.items() ]` : une **compréhension de liste** ; elle fabrique une requête par e-mail en parcourant le dictionnaire `EMAILS` (`.items()` donne les couples identifiant / texte).
> - `"custom_id": identifiant` : votre étiquette pour retrouver chaque résultat, car les réponses reviennent dans le désordre.
> - `"params": {…}` : exactement les arguments que vous passeriez à `messages.create`.
> - `while lot.processing_status != "ended":` : on redemande le statut toutes les 30 secondes (`time.sleep(30)`) jusqu'à la fin du traitement ; `batches.retrieve(lot.id)` relit le lot.
> - `client.messages.batches.results(lot.id)` : parcourt les résultats un par un ; `entree.result.type` vaut `succeeded` quand la requête a réussi (sinon `errored`, `canceled` ou `expired`).
> - `json.dumps(resultats, indent=2, ensure_ascii=False)` : affiche le dictionnaire au format JSON lisible, en gardant les accents tels quels.

Pour le tri de 4 000 e-mails d'archives avec Haiku 5.5 : environ 3,6 millions de tokens d'entrée et 40 000 de sortie, soit 0,38 $ au tarif standard et **0,19 $ en batch**. À ce prix, l'obstacle n'est plus financier mais organisationnel : qui vérifie les résultats ?

> 🔗 **Documentation officielle** — [Batch processing](https://platform.claude.com/docs/en/build-with-claude/batch-processing)

## 7. Stratégies de réduction des coûts, par ordre d'efficacité

| # | Levier | Gain typique | Effort | Quand |
|---|---|---|---|---|
| 1 | **Choisir le modèle par tâche** (Haiku pour classer/extraire, Sonnet pour rédiger, Opus/Fable pour raisonner) | ×10 à ×100 | Faible | Toujours, avec une évaluation (module 22) pour vérifier la qualité |
| 2 | **Prompt caching** sur le préfixe stable | 50 à 90 % de l'entrée | Faible | Dès que le prompt système dépasse 512 tokens ou qu'une conversation s'allonge |
| 3 | **Batch** pour tout ce qui n'est pas interactif | −50 % | Moyen | Traitements de nuit, évaluations, migrations |
| 4 | **Limiter la sortie** : `max_tokens` juste, format concis, `output_config={"effort": "low"}` sur les tâches simples | 20 à 60 % de la sortie | Faible | Partout ; la sortie coûte 5× l'entrée |
| 5 | **Réduire l'entrée** : résumer l'historique, tronquer les documents à la partie utile, compaction du contexte | Variable | Moyen | Conversations longues, agents |
| 6 | **Router** vers un modèle moins cher quand une heuristique le permet, escalader seulement en cas de doute | 30 à 70 % | Élevé | Volumes importants |
| 7 | **Dédupliquer et mettre en cache applicatif** les réponses aux questions identiques | Variable | Moyen | FAQ, catalogues |

Le mode `effort` mérite un mot : les modèles Claude 5.x réfléchissent avant de répondre (*thinking* adaptatif), et ces tokens de raisonnement sont facturés en sortie (le champ `usage.output_tokens_details.thinking_tokens` les isole). Sur une classification en un mot, `"effort": "low"` supprime l'essentiel de ce coût sans perte de qualité ; réservez `"high"` ou `"max"` aux tâches qui en ont besoin.

> 🔗 **Documentation officielle** — [Optimizing for cost and intelligence](https://platform.claude.com/docs/en/about-claude/models/optimizing-for-cost-and-intelligence)

## 8. Budget, garde-fous et alertes

L'OWASP classe la **consommation non bornée** (*Unbounded Consumption*, LLM10 dans la liste 2025, LLM06 dans la liste 2026) parmi les dix risques majeurs des applications LLM : boucle d'agent infinie, utilisateur malveillant qui envoie des prompts de 500 000 tokens, clé volée. La défense se construit à trois niveaux.

**Niveau 1 : la Console.** Fixez un **plafond de dépense mensuel** et des **alertes par e-mail** (par exemple à 50 % et 80 %) sur l'organisation et, mieux, sur chaque *workspace* : un workspace « dev » plafonné à 20 $ ne mettra jamais en péril le workspace « prod ». L'API *Usage & Cost Analytics* (bêta, oct. 2026) permet de rapatrier ces chiffres dans votre propre tableau de bord.

**Niveau 2 : le code.** Un garde-fou qui compte en temps réel, refuse les requêtes trop grosses avant envoi et coupe quand l'enveloppe est consommée :

```python
# budget_garde.py — garde-fou de budget au niveau applicatif
import threading

from anthropic import Anthropic

from calcul_cout import TARIFS, cout_appel   # le calculateur de la section 3


class BudgetDepasse(RuntimeError):
    pass


class ClientBudgete:
    """Enveloppe le client Anthropic : refuse les entrées trop grosses, suit la dépense, coupe au plafond."""

    def __init__(self, plafond_usd: float, max_tokens_entree: int = 20_000):
        self.client = Anthropic()
        self.plafond = plafond_usd
        self.max_entree = max_tokens_entree
        self.depense = 0.0
        self.verrou = threading.Lock()

    def create(self, **params):
        modele = params["model"]
        if modele not in TARIFS:
            raise ValueError(f"Tarif inconnu pour {modele} : mettez TARIFS à jour avant d'appeler ce modèle.")

        # 1. Refuser avant envoi une entrée anormalement grosse (gratuit : count_tokens)
        comptage = {"model": modele, "messages": params["messages"]}
        if "system" in params:
            comptage["system"] = params["system"]
        estimation = self.client.messages.count_tokens(**comptage).input_tokens
        if estimation > self.max_entree:
            raise BudgetDepasse(f"Entrée de {estimation} tokens > plafond {self.max_entree}")

        # 2. Refuser si le pire cas (entrée + max_tokens de sortie) dépasserait l'enveloppe restante
        pire_cas = cout_appel(modele, estimation, params["max_tokens"])
        with self.verrou:
            if self.depense + pire_cas > self.plafond:
                raise BudgetDepasse(f"Dépense {self.depense:.4f} $ + pire cas {pire_cas:.4f} $ > plafond {self.plafond} $")

        # 3. Appeler, puis comptabiliser la dépense réelle (cache inclus)
        msg = self.client.messages.create(**params)
        u = msg.usage
        reel = cout_appel(modele, u.input_tokens, u.output_tokens,
                          cache_lu=u.cache_read_input_tokens or 0,
                          cache_ecrit=u.cache_creation_input_tokens or 0)
        with self.verrou:
            self.depense += reel
            if self.depense > 0.8 * self.plafond:
                print(f"⚠️ ALERTE : {self.depense:.4f} $ dépensés sur {self.plafond} $ (80 %)")
        return msg


if __name__ == "__main__":
    client = ClientBudgete(plafond_usd=0.05)   # 5 centimes pour la démonstration
    for i in range(3):
        msg = client.create(
            model="claude-haiku-5-5",
            max_tokens=60,
            messages=[{"role": "user", "content": f"Conseil n° {i + 1} pour économiser du gaz, en une phrase."}],
        )
        bloc = msg.content[0]
        print(f"[{client.depense:.5f} $] {bloc.text if bloc.type == 'text' else bloc}")
```

> 🧭 **Pré-requis express — classes et verrou** — Une **classe** est un moule à objets : `ClientBudgete(plafond_usd=0.05)` fabrique un objet qui garde ses propres données (`self.depense`, `self.plafond`) d'un appel à l'autre. `__init__` est la fonction exécutée à la fabrication ; `self` désigne « cet objet-ci ». `class BudgetDepasse(RuntimeError): pass` crée un nouveau type d'erreur, que l'on déclenche avec `raise` et que le code appelant peut attraper avec `except BudgetDepasse`. Enfin, `threading.Lock()` est un **verrou** : si deux parties du programme modifient `self.depense` au même instant, `with self.verrou:` les fait passer l'une après l'autre, pour qu'aucune dépense ne soit perdue.
>
> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `from calcul_cout import TARIFS, cout_appel` : réutilise le calculateur de la section 3 ; le fichier `calcul_cout.py` doit être **dans le même dossier**.
> - `def create(self, **params)` : la méthode reçoit les mêmes arguments que `messages.create`, rangés dans le dictionnaire `params`.
> - Étape 1 : `count_tokens` mesure l'entrée **avant** d'envoyer ; au-delà de `max_entree`, on refuse.
> - Étape 2 : on calcule le **pire cas** (toute la sortie autorisée par `max_tokens` consommée) et on refuse si l'enveloppe serait dépassée.
> - Étape 3 : on appelle vraiment, puis on ajoute le coût **réel** (lu dans `usage`) à `self.depense`, et on prévient à 80 % du plafond.

**Niveau 3 : l'observabilité.** Journalisez pour chaque appel : modèle, tokens (entrée, sortie, cache), coût calculé, durée, `request-id`, utilisateur ou fonctionnalité. Des outils comme Langfuse, Helicone ou LangSmith (module 22) affichent ensuite le coût par utilisateur et par fonctionnalité. Sans cette ventilation, vous saurez que vous avez dépensé 1 200 $ ce mois-ci, mais pas que 900 $ viennent d'une boucle de test oubliée.

> 🛠️ **Si ça ne marche pas** —
> - `ModuleNotFoundError: No module named 'calcul_cout'` → `budget_garde.py` n'est pas dans le même dossier que `calcul_cout.py`, ou vous le lancez depuis un autre dossier → rangez les deux fichiers ensemble et lancez depuis ce dossier.
> - `ValueError: Tarif inconnu…` ou `KeyError` → l'identifiant de modèle ne figure pas dans `TARIFS` (faute de frappe, nouveau modèle) → ajoutez la ligne de tarif datée.
> - Le lot batch reste `in_progress` pendant longtemps → c'est normal : le service garantit 24 h au maximum ; en démonstration, attendez ou réduisez le lot à 2 requêtes.
> - 429 alors que vous comptez bien vos requêtes → `count_tokens` a ses **propres** limites de débit (requêtes par minute, selon votre palier) → espacez les comptages ou comptez une seule fois les parties stables du prompt.

> 💡 **À retenir** — Un budget IA se pilote comme un budget cloud : **plafond** (Console), **compteur** (code), **ventilation** (observabilité), **alertes** (e-mail, Slack) et **revue mensuelle** des coûts par fonctionnalité. Les quatre leviers techniques (modèle, cache, batch, sortie) viennent ensuite.

### 🔎 Chasse à l'API

```mission
{
  "title": "Limites de débit Claude : paliers et en-têtes",
  "url": "https://platform.claude.com/docs/en/api/rate-limits",
  "steps": ["Ouvrez la page Rate limits de la documentation Claude Platform", "Relevez le nom des paliers d'usage (usage tiers) et le plafond de dépenses mensuel du palier Build", "Cherchez le préfixe des en-têtes de réponse qui indiquent vos limites restantes, et le code HTTP renvoyé en cas de dépassement"],
  "question": "Quels sont les paliers d'usage d'Anthropic, quel préfixe portent les en-têtes de limite, et quel code d'erreur signale un dépassement ?",
  "hint": "Cinq paliers, du test au sur-mesure ; les en-têtes commencent par le nom de l'entreprise ; le code d'erreur est celui du guichet saturé.",
  "answer": "Evaluation, Start, Build, Scale et Custom (plafonds de dépenses mensuels : 500 $, 1 000 $ et 200 000 $ pour Start, Build et Scale) ; en-têtes anthropic-ratelimit-* (plus retry-after) ; erreur 429 rate_limit_error (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Quelle fenêtre de contexte pour Grok 4.7 ?",
  "url": "https://docs.x.ai/developers/models",
  "steps": ["Ouvrez la page Models de la documentation xAI", "Repérez la ligne du modèle phare grok-4.7", "Relevez sa fenêtre de contexte et sa date de coupure des connaissances, puis comparez avec le million de tokens des modèles Claude 5.5"],
  "question": "Quelle est la fenêtre de contexte de grok-4.7, et est-elle plus grande ou plus petite que celle de Claude Sonnet 5.5 ?",
  "hint": "C'est la moitié d'un million.",
  "answer": "500 000 tokens (cutoff mai 2026), soit deux fois moins que le million de tokens de Claude Sonnet 5.5 (nov. 2026) — vérifiez : les fiches évoluent (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Le prix du token « en cache » chez OpenAI",
  "url": "https://developers.openai.com/api/docs/pricing",
  "steps": ["Ouvrez la page Pricing de l'API OpenAI", "Trouvez la ligne gpt-6-luna dans le tableau des modèles", "Lisez les colonnes Input, Cached input et Output, puis calculez le rapport entre l'entrée normale et l'entrée en cache"],
  "question": "Combien coûte GPT-6 Luna par million de tokens en entrée, en entrée cachée et en sortie ? De combien le cache divise-t-il le prix de l'entrée ?",
  "hint": "Ses prix sont identiques à ceux de Claude Haiku 5.5.",
  "answer": "0,10 $ en entrée, 0,01 $ en entrée cachée et 0,50 $ en sortie : le cache divise le prix de l'entrée par 10 (nov. 2026) — vérifiez : les prix évoluent (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🎮 Défi

Chauffage Martin veut maintenant un assistant conversationnel pour ses clients, avec un prompt système de 3 000 tokens et des conversations de 6 tours en moyenne (chaque tour renvoie tout l'historique). Sans calculatrice : pourquoi le prompt caching est-il ici un levier **plus** important que pour le classement d'e-mails de la section 3 ? (Réponse : sans cache, les 3 000 tokens du système sont facturés 6 fois par conversation, plus l'historique croissant ; avec cache, ils ne sont écrits qu'une fois puis lus à 0,05 × du prix sur Sonnet 5.5, et l'historique précédent devient lui aussi un préfixe stable mis en cache tour après tour.)

## 🧪 Exercice pratique

**Consigne.** Vous êtes chargé d'estimer et d'encadrer le budget de l'assistant conversationnel du défi ci-dessus, pour 150 conversations par jour, 22 jours par mois.

1. Avec `count_tokens`, mesurez la taille réelle d'un prompt système que vous rédigerez (procédures, tarifs, zones, ton) : visez entre 2 500 et 3 500 tokens. Mesurez aussi un message client typique (≈ 60 mots) et une réponse typique (≈ 90 mots) : notez les tokens entrée/sortie réels à partir de `usage`.
2. Étendez `calcul_cout.py` avec une fonction `cout_conversation(modele, tokens_systeme, tours, tokens_question, tokens_reponse, cache=True|False)` qui modélise la croissance de l'historique et le cache (écriture au tour 1, lecture ensuite ; prefixe = système + historique).
3. Produisez un tableau mensuel pour `claude-haiku-5-5`, `claude-sonnet-5-5`, `gpt-6.1-sol` et `mistral-small-4`, avec et sans cache.
4. Choisissez un modèle, justifiez-le en trois lignes (coût, qualité attendue, risque), fixez un plafond mensuel dans la Console avec une alerte à 80 %, et enveloppez l'assistant dans `ClientBudgete`.

**Critères de réussite.**
- Les tailles de tokens utilisées dans le calcul sont **mesurées** (count_tokens / usage), pas supposées.
- Le tableau montre l'économie du cache en pourcentage pour chaque modèle ; l'économie croît avec le nombre de tours.
- Le choix du modèle est argumenté avec des chiffres datés « nov. 2026 » et sourcés (URL de la page tarifaire).
- Un test volontaire avec un plafond minuscule (0,01 $) déclenche `BudgetDepasse` **avant** l'envoi d'une requête qui le dépasserait.

**Pistes de corrigé.** Au tour *k*, l'entrée vaut `système + Σ(question_i + réponse_i pour i<k) + question_k`. Sans cache, tout est au prix d'entrée. Avec cache : au tour 1, `système` est écrit (1,25 ×) ; au tour *k*, `système + historique jusqu'au tour k-1` est lu (0,05 × sur Sonnet 5.5, 0,1 × sur Haiku 5.5) et seuls les tokens nouveaux (réponse précédente, écrite dans le cache, et `question_k`) sont au tarif plein. Attendez-vous, pour 6 tours et un système de 3 000 tokens, à 70-80 % d'économie sur la part « entrée » avec Sonnet 5.5 ; pour 150 conversations/jour : quelques dollars par mois sur Haiku, quelques dizaines sur Sonnet avec cache.

## ✅ Auto-évaluation express

1. Un prompt système de 400 tokens sur `claude-sonnet-5-5` n'est jamais lu depuis le cache. Pourquoi ?
2. Votre application reçoit un 429 alors que vous n'envoyez que 20 requêtes par minute. Quelle autre limite avez-vous probablement dépassée ?
3. Quelle est la différence de coût entre 1 million de tokens de sortie sur Haiku 5.5 et sur Fable 5.1 (nov. 2026) ?

**Réponses.** 1) Le seuil minimal de mise en cache est de 512 tokens sur les modèles 5.5 ; en dessous, aucun point de cache n'est créé. 2) Une limite de **tokens** par minute (entrée ou sortie), pas de requêtes : 20 requêtes de 30 000 tokens font 600 000 tokens d'entrée par minute. Lisez les en-têtes `anthropic-ratelimit-input-tokens-*`. 3) 0,50 $ contre 50 $ : un facteur 100. D'où la règle « le bon modèle pour la bonne tâche ».

> ✅ **Si vous ne retenez que 3 choses** — 1. Tout se paie en tokens, la sortie coûte environ 5 fois l'entrée, et le français consomme plus de tokens que l'anglais : mesurez avec `count_tokens` ou `usage`, ne devinez pas. 2. Le premier levier d'économie est le choix du modèle (facteur 100 entre Haiku et Fable), puis le cache (préfixe stable en tête, au moins 512 tokens) et le batch (−50 %). 3. Une facture se protège à trois niveaux : plafond et alertes dans la Console, compteur dans le code, journalisation du coût de chaque appel.

## 📚 Pour aller plus loin

- [Claude Platform — Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 — la grille complète, y compris modèles legacy, outils serveur, Managed Agents et Fast mode.
- [Claude Platform — Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 — seuils, TTL, points de cache, interactions avec les outils et le thinking.
- [Claude Platform — Batch processing](https://platform.claude.com/docs/en/build-with-claude/batch-processing) 🇬🇧 — limites, statuts, lecture des résultats, bonnes pratiques.
- [Claude Platform — Rate limits](https://platform.claude.com/docs/en/api/rate-limits) 🇬🇧 — paliers, compteurs par modèle, en-têtes.
- [Claude Platform — Usage & Cost Analytics API](https://platform.claude.com/docs/en/manage-claude/usage-cost-analytics-api) 🇬🇧 — récupérer programmatiquement vos coûts pour votre propre tableau de bord.
- [OpenAI — Pricing](https://developers.openai.com/api/docs/pricing) 🇬🇧 — tarifs GPT-6, niveaux de service Batch / Flex / Fast / Ultrafast.
- [Coralogix — OWASP Top 10 for LLM Applications](https://coralogix.com/ai-blog/owasp-top-10-for-llm-applications/) 🇬🇧 — présentation claire du risque « Unbounded Consumption » et des autres.

> 🗺️ **Et maintenant ?** — Vous savez appeler un modèle, lire chaque octet de l'échange et chiffrer la facture ; le module 17 entre dans le détail de l'API Anthropic avec la leçon L068 : requêtes, rôles, paramètres et choix des modèles de la Messages API.
