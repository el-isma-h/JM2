---
id: L066
module: M16
level: N3
title: "HTTP, JSON, streaming : anatomie d'un appel à un LLM"
minutes: 65
objectives:
  - "Décrire la requête HTTP complète d'un appel à la Messages API (méthode, URL, en-têtes, corps JSON) et la réponse qu'elle produit"
  - "Interpréter les codes d'erreur HTTP d'une API de LLM (400, 401, 403, 404, 413, 429, 500, 529) et appliquer une stratégie de nouvelles tentatives avec backoff exponentiel et jitter"
  - "Expliquer le protocole Server-Sent Events et implémenter le streaming d'une réponse avec curl, Python et TypeScript"
  - "Construire un client asynchrone qui parallélise plusieurs appels en respectant une limite de concurrence"
skills: ["C3.1"]
sources:
  - { title: "Claude Platform — Messages API reference (create)", url: "https://platform.claude.com/docs/en/api/messages/create", lang: "en" }
  - { title: "Claude Platform — API overview", url: "https://platform.claude.com/docs/en/api/overview", lang: "en" }
  - { title: "Claude Platform — API versioning", url: "https://platform.claude.com/docs/en/api/versioning", lang: "en" }
  - { title: "Claude Platform — Streaming Messages", url: "https://platform.claude.com/docs/en/build-with-claude/streaming", lang: "en" }
  - { title: "Claude Platform — Handling stop reasons", url: "https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons", lang: "en" }
  - { title: "Claude Platform — Using the Messages API", url: "https://platform.claude.com/docs/en/build-with-claude/working-with-messages", lang: "en" }
  - { title: "OpenAI — Streaming responses", url: "https://developers.openai.com/api/docs/guides/streaming-responses", lang: "en" }
  - { title: "MDN — Utiliser les événements envoyés par le serveur (SSE)", url: "https://developer.mozilla.org/fr/docs/Web/API/Server-sent_events/Using_server-sent_events", lang: "fr" }
  - { title: "MDN — Codes de statut de réponse HTTP", url: "https://developer.mozilla.org/fr/docs/Web/HTTP/Status", lang: "fr" }
  - { title: "Claude status page", url: "https://status.claude.com/", lang: "en" }
---

# HTTP, JSON, streaming : anatomie d'un appel à un LLM

> ⏱ 65 min · 🎯 Niveau 3 · 📚 Module 16

## 🎯 Ce que vous saurez faire
- Lire et écrire « à la main », avec `curl`, la requête HTTP exacte que le SDK fabrique pour vous, et reconnaître chaque en-tête et chaque champ JSON.
- Diagnostiquer en quelques secondes une erreur d'API à partir de son code HTTP et de son type, et savoir lesquelles méritent une nouvelle tentative.
- Mettre en place un *retry* avec *backoff* exponentiel et *jitter*, en vous appuyant sur ce que le SDK fait déjà.
- Afficher une réponse au fil de l'eau (streaming) dans un terminal, un script Python ou une application Node, et paralléliser des appels en asynchrone sans vous faire bloquer.

> 🧭 **En clair** — Appeler un modèle de langage, c'est aller au **guichet de la poste**. Vous tendez une enveloppe (la **requête HTTP**) avec une adresse précise (l'URL), quelques mentions obligatoires sur le dessus (les **en-têtes** : votre carte d'abonné, c'est-à-dire la clé, et la version du formulaire) et, à l'intérieur, un formulaire rempli case par case (le **JSON**). Le guichetier vous rend une réponse, elle aussi en JSON, avec un code qui dit si tout s'est bien passé : 200 « c'est bon », 401 « carte inconnue », 429 « trop de monde, revenez dans un instant ». Le **streaming**, c'est recevoir la réponse en plusieurs petits colis au fil de l'eau plutôt qu'en un seul gros colis à la fin : vous commencez à lire tout de suite.

## 1. Sous le SDK, une requête HTTP comme une autre

Quand vous appelez `client.messages.create(...)`, le SDK ne fait rien de magique : il envoie une requête **HTTP POST** vers `https://api.anthropic.com/v1/messages`, avec un corps JSON, et lit la réponse JSON. Comprendre cette couche vous rend autonome : vous saurez appeler l'API depuis n'importe quel langage, depuis n8n, depuis un *webhook* (une adresse web qu'un service appelle automatiquement quand un événement se produit, par exemple « nouvel e-mail reçu »), et vous saurez lire un journal d'erreurs sans paniquer.

Analogie : le SDK est un coursier qui connaît l'adresse, le format du bordereau et la procédure en cas d'absence du destinataire. Cette leçon vous apprend à remplir le bordereau vous-même, pour le jour où le coursier n'est pas disponible, ou pour vérifier ce qu'il a réellement livré.

```mermaid
sequenceDiagram
    participant C as Votre programme
    participant A as API (api.anthropic.com)
    C->>A: POST /v1/messages + en-têtes (clé, version) + corps JSON
    A->>A: Vérifie la clé, le quota, le format
    A-->>C: Code 200 + JSON (content, stop_reason, usage)
    Note over C,A: En cas de problème : code 4xx (votre requête) ou 5xx / 529 (leur service)
```

### 1.1 La requête, champ par champ

```bash
# appel_brut.sh — la requête exacte que le SDK construit pour vous
curl https://api.anthropic.com/v1/messages \
  --header "x-api-key: $ANTHROPIC_API_KEY" \
  --header "anthropic-version: 2026-10-21" \
  --header "content-type: application/json" \
  --data '{
    "model": "claude-haiku-5-5",
    "max_tokens": 200,
    "system": "Vous êtes l'\''assistant de Chauffage Martin, PME de plomberie à Lille.",
    "messages": [
      {"role": "user", "content": "Quels sont vos horaires d'\''intervention ?"}
    ]
  }'
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `curl https://…/v1/messages` : `curl` est un petit programme qui envoie une requête HTTP depuis le terminal ; il fait ici le travail du SDK.
> - Le `\` en fin de ligne veut dire « la commande continue à la ligne suivante » : c'est **une seule** commande écrite sur plusieurs lignes. Aucun espace ne doit suivre le `\`.
> - `--header "x-api-key: $ANTHROPIC_API_KEY"` : ajoute un en-tête. Entre guillemets doubles, le shell remplace `$ANTHROPIC_API_KEY` par la valeur de la variable d'environnement (leçon L065) : la clé n'apparaît pas en clair dans le script.
> - `--data '{…}'` : le corps JSON de la requête. Le fait de fournir un corps fait passer `curl` en méthode **POST**.
> - `'\''` : astuce du shell pour écrire une apostrophe (`l'assistant`) à l'intérieur d'un texte déjà entouré d'apostrophes. On ferme, on écrit une apostrophe protégée, on rouvre.

| Élément | Valeur | Rôle |
|---|---|---|
| Méthode + URL | `POST https://api.anthropic.com/v1/messages` | Le point d'entrée (*endpoint*) de la Messages API |
| `x-api-key` | votre clé | Authentification. En HTTP brut, Anthropic utilise un en-tête dédié ; les SDK v2 (21/10/2026, licence Apache 2.0) envoient `Authorization: Bearer`, ce qui compte si un proxy lit `X-Api-Key`. OpenAI et xAI utilisent `Authorization: Bearer <clé>` |
| `anthropic-version` | `2026-10-21` | Version du contrat d'API. Elle garantit que le format de réponse ne changera pas sous vos pieds ; le SDK v2 l'envoie automatiquement |
| `content-type` | `application/json` | Le corps est du JSON |
| `anthropic-beta` (optionnel) | ex. `output-300k-2026-03-24` | Active une fonctionnalité en bêta |
| Corps JSON | `model`, `max_tokens`, `messages`, `system`… | Les paramètres de l'appel |

> 💡 **Autrement dit** — Les en-têtes, ce sont les mentions écrites **sur** l'enveloppe : qui vous êtes (`x-api-key`), quelle version du formulaire vous utilisez (`anthropic-version`), et dans quelle langue est rédigé le contenu (`content-type: application/json`). Le corps JSON, c'est le formulaire **dans** l'enveloppe : des cases nommées entre guillemets (`"model"`, `"max_tokens"`) suivies de leur valeur, des listes entre crochets `[ ]` et des sous-formulaires entre accolades `{ }`. Le JSON est simplement une façon normalisée d'écrire un formulaire que toutes les machines savent relire.

Le corps JSON mérite une lecture attentive. `messages` est une **liste de tours** alternant `user` et `assistant` ; pour une conversation, vous renvoyez tout l'historique à chaque appel (l'API est **sans état**, *stateless*). `content` peut être une simple chaîne ou une liste de blocs (texte, image, document PDF, résultat d'outil). `system` est le prompt système, placé hors de la liste pour signifier qu'il vient de vous, pas de l'utilisateur.

> 🛠️ **Si ça ne marche pas** —
> - Réponse `401 authentication_error` alors que la clé est bonne → la variable est vide dans **ce** terminal → `echo $ANTHROPIC_API_KEY` ; si rien ne s'affiche, faites `export ANTHROPIC_API_KEY=…` (ou `source .env` si votre fichier ne contient que des lignes `NOM=valeur`).
> - `curl: (3) URL rejected` ou `Could not resolve host` sur des lignes qui commencent par `--header` → un espace s'est glissé après un `\`, ou vous avez collé la commande dans l'invite Windows → retirez l'espace, ou utilisez Git Bash / WSL.
> - Sous PowerShell, `curl` n'est pas le vrai curl et les apostrophes ne sont pas comprises → tapez `curl.exe` et mettez le JSON dans un fichier : `--data @requete.json`.
> - `400 invalid_request_error` qui parle de JSON → une virgule manque ou est en trop (la dernière ligne d'une liste ou d'un objet ne prend **pas** de virgule) → collez votre JSON dans un validateur ou dans `python -m json.tool`.

### 1.2 La réponse

```json
{
  "id": "msg_01XFDUDYJgAACzvnptvVoYEL",
  "type": "message",
  "role": "assistant",
  "model": "claude-haiku-5-5",
  "content": [
    {"type": "text", "text": "Nos techniciens interviennent du lundi au vendredi, de 8 h à 18 h…"}
  ],
  "stop_reason": "end_turn",
  "stop_sequence": null,
  "usage": {
    "input_tokens": 48,
    "output_tokens": 61,
    "cache_creation_input_tokens": 0,
    "cache_read_input_tokens": 0
  }
}
```

Les en-têtes de réponse contiennent aussi des informations précieuses : `request-id` (à conserver dans vos journaux pour toute demande au support) et la famille `anthropic-ratelimit-*` qui indique où vous en êtes de vos quotas (leçon L067).

> 💡 **À retenir** — L'API est **sans état** : chaque requête doit contenir tout le contexte nécessaire. C'est vous (ou votre base de données) qui conservez l'historique. Cela explique pourquoi les conversations longues coûtent de plus en plus cher, et pourquoi le *prompt caching* existe (L067).

> 🔗 **Documentation officielle** — [Messages API reference](https://platform.claude.com/docs/en/api/messages/create) · [API versioning](https://platform.claude.com/docs/en/api/versioning) · [Using the Messages API](https://platform.claude.com/docs/en/build-with-claude/working-with-messages)

```quiz
{
  "type": "vrai_faux",
  "q": "L'API Messages est sans état : pour poser une question de suivi, votre programme doit renvoyer tout l'historique utile de la conversation.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Par défaut, l'API ne garde aucun souvenir entre deux appels (stateless) : chaque requête doit contenir tout l'historique utile. Seule la bêta « message threads » (2 nov. 2026, en-tête dédié) conserve un fil côté serveur, qui expire 5 minutes après la dernière requête. C'est votre programme qui le conserve et le renvoie, ce qui explique pourquoi les longues conversations coûtent de plus en plus cher."
}
```

### 1.3 Et chez les autres fournisseurs ?

Le principe est identique, les détails changent :

| | Anthropic | OpenAI (Responses) | xAI | Mistral |
|---|---|---|---|---|
| Endpoint | `POST /v1/messages` | `POST /v1/responses` | `POST /v1/responses` (compatible OpenAI) | `POST /v1/chat/completions` |
| Authentification | `x-api-key` (HTTP brut ; `Authorization: Bearer` via les SDK v2) | `Authorization: Bearer` | `Authorization: Bearer` | `Authorization: Bearer` |
| Prompt système | champ `system` | champ `instructions` | champ `instructions` | message de rôle `system` |
| Entrée | `messages` (liste) | `input` (chaîne ou liste) | `input` | `messages` |
| Texte de sortie | `content[].text` | `output_text` (raccourci) | `output_text` | `choices[0].message.content` |

Nous écrirons des clients multi-fournisseurs au module 19 ; retenez pour l'instant que **tout est du JSON sur HTTP**, et que les différences tiennent en un tableau.

## 2. Quand ça casse : les codes d'erreur

Une API bien conçue vous dit précisément pourquoi elle refuse. Le corps d'une erreur Anthropic ressemble à ceci :

```json
{"type": "error", "error": {"type": "rate_limit_error", "message": "This request would exceed your organization's rate limit…"}}
```

Le tableau suivant est votre fiche de diagnostic. La colonne « Réessayer ? » est la plus importante : réessayer une erreur 400 est inutile (la requête restera invalide), réessayer une erreur 529 est exactement ce qu'il faut faire.

| Code HTTP | Type d'erreur Anthropic | Cause typique | Réessayer ? | Exception du SDK Python |
|---|---|---|---|---|
| 400 | `invalid_request_error` | JSON mal formé, `max_tokens` manquant, paramètre non supporté (`temperature` sur un modèle ≥ 4.7 (et sur tous les modèles avec la version d'API 2026-10-21, celle des SDK v2)) | Non : corrigez la requête | `BadRequestError` |
| 401 | `authentication_error` | Clé absente, invalide ou révoquée | Non : vérifiez `ANTHROPIC_API_KEY` | `AuthenticationError` |
| 402 | `billing_error` | Problème de facturation ou de paiement du compte | Non : réglez la facturation dans la Console | à vérifier dans le README du SDK |
| 403 | `permission_error` | Clé valide mais sans droit (workspace, modèle réservé, région) | Non | `PermissionDeniedError` |
| 404 | `not_found_error` | Modèle ou ressource inexistants (faute de frappe dans l'ID) | Non | `NotFoundError` |
| 409 | `conflict_error` | Conflit avec l'état de la ressource visée | Selon le cas (le SDK le réessaie, voir ci-dessous) | à vérifier dans le README du SDK |
| 413 | `request_too_large` | Requête au-delà de la taille maximale (128 Mo depuis oct. 2026) | Non : réduisez | `RequestTooLargeError` (à vérifier dans le README du SDK) |
| 429 | `rate_limit_error` | Limite de débit atteinte (requêtes ou tokens par minute) | **Oui**, après le délai `retry-after` | `RateLimitError` |
| 500 | `api_error` | Erreur interne côté Anthropic | Oui, avec backoff | `InternalServerError` |
| 504 | `timeout_error` | Délai de traitement dépassé côté Anthropic | Oui, avec backoff | à vérifier dans le README du SDK |
| 529 | `overloaded_error` | API surchargée temporairement | **Oui**, avec backoff | `OverloadedError` (à vérifier dans le README du SDK) |

Seule la classe `anthropic.NotFoundError` est citée par la page officielle *Errors* ; les autres noms de classes de ce tableau sont à vérifier dans le README du SDK.

Deux cas particuliers méritent un mot. Le **408** (délai d'attente côté serveur) et le **409** (conflit) sont également réessayés automatiquement par le SDK. Et une **coupure réseau** (pas de code HTTP du tout) remonte comme `APIConnectionError` ou `APITimeoutError` : elle aussi mérite une nouvelle tentative.

> 💡 **Autrement dit** — Reprenons le guichet. Les codes **4xx**, c'est le guichetier qui vous rend l'enveloppe parce que **vous** avez fait une erreur : formulaire mal rempli (400), carte d'abonné invalide (401), service auquel vous n'avez pas droit (403), adresse inconnue (404), colis trop gros (413). Revenir avec la même enveloppe ne servira à rien. Le **429**, c'est « vous êtes déjà passé dix fois cette minute, attendez votre tour » : on revient après le délai indiqué. Les **5xx** et le **529**, c'est la poste qui est en panne ou débordée : vous n'y êtes pour rien, vous patientez un peu et réessayez.

> ⚠️ **Piège fréquent** — Confondre une erreur **de requête** (4xx : c'est vous) et une erreur **de service** (5xx, 529 : c'est eux). Réessayer en boucle un 401 ne fera que remplir vos journaux ; ignorer un 529 fera planter votre application alors qu'une attente de deux secondes aurait suffi. Avant de coder quoi que ce soit, jetez un œil à [status.claude.com](https://status.claude.com/).

```quiz
{
  "q": "Parmi ces erreurs, laquelle faut-il réessayer automatiquement (après un délai) ?",
  "options": [
    "401 authentication_error",
    "529 overloaded_error",
    "400 invalid_request_error",
    "404 not_found_error"
  ],
  "answer": 1,
  "explanation": "Le 529 signale une surcharge temporaire du service : une nouvelle tentative avec backoff et jitter est exactement ce qu'il faut. Les 400, 401 et 404 sont des erreurs de votre requête : elles échoueront à l'identique tant que vous ne corrigez rien."
}
```

## 3. Retries et backoff : laisser le SDK travailler, puis l'ajuster

### 3.1 Ce que le SDK fait déjà

Le SDK Anthropic (Python 2.3, TypeScript 1.3) réessaie **deux fois** par défaut (`max_retries=2`) les erreurs 408, 409, 429, 5xx et les erreurs de connexion. Il respecte l'en-tête `retry-after` envoyé par le serveur quand il existe ; sinon, il applique un **backoff exponentiel** (délai qui double à chaque tentative, de 0,5 s jusqu'à 8 s) avec un **jitter** (une part aléatoire). Le jitter évite l'effet « troupeau » : si mille clients réessaient tous exactement 2 s après une panne, ils recréent la panne.

> 💡 **Autrement dit** — Le *backoff exponentiel*, c'est la politesse au guichet saturé : vous revenez après 1 minute, puis 2, puis 4, puis 8, au lieu de frapper à la vitre toutes les secondes. Le *jitter*, c'est ajouter quelques secondes au hasard pour que tous les clients refoulés ne reviennent pas pile au même moment, ce qui recréerait la cohue.

```python
# retries_config.py — ajuster la politique du SDK plutôt que la réécrire
from anthropic import Anthropic

client = Anthropic(
    max_retries=4,     # au lieu de 2 : utile pour un traitement par lots nocturne
    timeout=60.0,      # secondes, au lieu de 10 min par défaut : utile pour une API web
)

# Possible aussi appel par appel :
message = client.with_options(max_retries=0).messages.create(
    model="claude-haiku-5-5",
    max_tokens=50,
    messages=[{"role": "user", "content": "Ping"}],
)
print(message.content[0].text if message.content[0].type == "text" else message.content)
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `Anthropic(max_retries=4, timeout=60.0)` : réglages valables pour **tous** les appels de ce client : 4 nouvelles tentatives au lieu de 2, et abandon au bout de 60 secondes sans réponse.
> - `client.with_options(max_retries=0)` : une copie du client avec d'autres réglages, **pour cet appel seulement** (ici : aucune nouvelle tentative).
> - `A if condition else B` : écriture compacte de Python qui veut dire « A si la condition est vraie, sinon B ». On n'affiche `.text` que si le premier bloc est bien du texte.

### 3.2 Quand écrire sa propre boucle

Il reste des cas où vous voulez contrôler la stratégie : attendre plus longtemps qu'un SDK ne l'accepte, basculer vers un autre modèle (`claude-sonnet-5-5` → `claude-haiku-5-5`) après N échecs, ou journaliser chaque tentative. Voici une implémentation complète, avec jitter et plafond, qui s'appuie sur les exceptions typées du SDK :

```python
# retry_maison.py — boucle de nouvelles tentatives avec backoff exponentiel + jitter
import logging
import random
import time

from anthropic import (
    Anthropic,
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("retry")

client = Anthropic(max_retries=0)  # on désactive les retries du SDK : c'est nous qui gérons
CODES_REESSAYABLES = {408, 409, 429, 500, 502, 503, 504, 529}


def appeler_avec_retry(params: dict, tentatives_max: int = 5, delai_base: float = 1.0, plafond: float = 30.0):
    """Appelle messages.create en réessayant les erreurs transitoires.

    delai = min(plafond, delai_base * 2**k) + jitter uniforme [0, 1 s)
    """
    for tentative in range(1, tentatives_max + 1):
        try:
            return client.messages.create(**params)
        except APIStatusError as err:
            if err.status_code not in CODES_REESSAYABLES or tentative == tentatives_max:
                raise  # erreur définitive (4xx) ou dernière tentative : on remonte
            # Le serveur peut imposer son délai (en secondes) via retry-after
            retry_after = err.response.headers.get("retry-after")
            delai = float(retry_after) if retry_after else min(plafond, delai_base * 2 ** (tentative - 1))
            delai += random.uniform(0, 1.0)
            log.warning("HTTP %s (%s) — tentative %d/%d, attente %.1f s (request-id=%s)",
                        err.status_code, type(err).__name__, tentative, tentatives_max,
                        delai, err.response.headers.get("request-id"))
            time.sleep(delai)
        except (APIConnectionError, APITimeoutError) as err:
            if tentative == tentatives_max:
                raise
            delai = min(plafond, delai_base * 2 ** (tentative - 1)) + random.uniform(0, 1.0)
            log.warning("Réseau : %s — tentative %d/%d, attente %.1f s", err, tentative, tentatives_max, delai)
            time.sleep(delai)


if __name__ == "__main__":
    msg = appeler_avec_retry({
        "model": "claude-haiku-5-5",
        "max_tokens": 100,
        "messages": [{"role": "user", "content": "Donne un conseil d'entretien pour une chaudière gaz, en une phrase."}],
    })
    print(msg.content[0].text if msg.content[0].type == "text" else msg.content)
    print("request-id :", msg._request_id)  # identifiant à citer au support en cas de problème
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `from anthropic import (…, APIStatusError, …)` : on importe les **types d'erreurs** du SDK pour pouvoir les attraper séparément. `APIStatusError` = « le serveur a répondu avec un code d'erreur » ; `APIConnectionError` / `APITimeoutError` = « pas de réponse du tout ».
> - `client.messages.create(**params)` : `**` « déplie » le dictionnaire `params` en arguments nommés ; c'est équivalent à écrire `model=…, max_tokens=…, messages=…`.
> - `try: … except APIStatusError as err:` : « essaie ; si cette erreur survient, exécute le bloc `except` au lieu de planter ». `err.status_code` contient le code HTTP (429, 529…).
> - `raise` tout seul : relance l'erreur qu'on vient d'attraper, pour la laisser remonter (erreur définitive ou dernière tentative).
> - `delai_base * 2 ** (tentative - 1)` : `**` est la puissance ; pour les tentatives 1, 2, 3, 4 cela donne 1, 2, 4, 8 secondes, et `min(plafond, …)` empêche de dépasser 30 s.
> - `random.uniform(0, 1.0)` : le jitter, un petit délai au hasard entre 0 et 1 seconde ; `time.sleep(delai)` met le programme en pause.
> - `if __name__ == "__main__":` : ce bloc ne s'exécute que si vous lancez ce fichier directement (`python retry_maison.py`), pas si un autre fichier l'importe pour réutiliser `appeler_avec_retry`.

Lisez bien la séquence des délais pour `delai_base=1` : 1 s, 2 s, 4 s, 8 s, puis plafond à 30 s, chaque fois plus un jitter. Cinq tentatives couvrent environ une minute d'indisponibilité, ce qui absorbe la quasi-totalité des incidents transitoires.

> 💡 **À retenir** — Règle d'or du retry : **jamais sans plafond, jamais sans jitter, jamais sur une 4xx** (sauf 408, 409, 429). Et toujours un journal : un retry silencieux cache un problème de quota que vous découvrirez sur la facture.

## 4. Le streaming : pourquoi et comment

### 4.1 Le problème de la latence perçue

Un modèle génère sa réponse **token par token**. Sans streaming, vous attendez le dernier token avant de voir le premier : pour 800 tokens, cela peut représenter dix secondes d'écran vide. Avec le streaming, le serveur envoie chaque fragment dès qu'il existe, et l'utilisateur lit pendant que le modèle écrit. C'est ce qui donne l'impression de « dactylographie » dans ChatGPT ou Claude. Le temps total ne change pas, mais le **temps jusqu'au premier token** (*time to first token*, TTFT) tombe à quelques centaines de millisecondes.

Le streaming est aussi une question de robustesse : Anthropic recommande de l'utiliser pour toute requête longue, car une connexion HTTP qui reste muette pendant plusieurs minutes finit par être coupée par un proxy ou un équilibreur de charge.

### 4.2 Le protocole : Server-Sent Events

Le streaming repose sur **SSE** (*Server-Sent Events*), un format texte très simple normalisé par le W3C/WHATWG : la réponse HTTP reste ouverte (`content-type: text/event-stream`) et le serveur y écrit des événements séparés par une ligne vide, chacun avec un champ `event:` et un champ `data:` contenant du JSON. Pas de WebSocket, pas de bibliothèque exotique : `curl` suffit pour le voir.

> 💡 **Autrement dit** — Sans streaming, vous attendez qu'un livreur vous apporte tout le carton d'un coup, au bout de dix secondes. Avec SSE, le livreur laisse la porte ouverte et vous tend les objets un par un dès qu'ils sortent de l'atelier : d'abord un bordereau d'annonce (`message_start`), puis les morceaux de texte (`content_block_delta`), puis un récapitulatif avec le motif d'arrêt et le poids total facturé (`message_delta`), et enfin « livraison terminée » (`message_stop`). Chaque objet est une petite ligne `event:` suivie d'une ligne `data:` en JSON.

```bash
# stream_brut.sh — observer les événements SSE en direct
curl https://api.anthropic.com/v1/messages \
  --header "x-api-key: $ANTHROPIC_API_KEY" \
  --header "anthropic-version: 2026-10-21" \
  --header "content-type: application/json" \
  --no-buffer \
  --data '{
    "model": "claude-haiku-5-5",
    "max_tokens": 100,
    "stream": true,
    "messages": [{"role": "user", "content": "Compte de 1 à 5 en toutes lettres."}]
  }'
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Deux différences seulement avec l'appel brut de la section 1.1 : `"stream": true` dans le JSON demande au serveur d'envoyer la réponse en morceaux, et `--no-buffer` demande à `curl` d'afficher chaque morceau dès qu'il arrive, au lieu d'attendre la fin.

Vous verrez défiler quelque chose comme :

```
event: message_start
data: {"type":"message_start","message":{"id":"msg_01…","role":"assistant","content":[],"usage":{"input_tokens":21,"output_tokens":1}}}

event: content_block_start
data: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}

event: content_block_delta
data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Un"}}

event: content_block_delta
data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":", deux"}}

event: content_block_stop
data: {"type":"content_block_stop","index":0}

event: message_delta
data: {"type":"message_delta","delta":{"stop_reason":"end_turn","stop_sequence":null},"usage":{"output_tokens":14}}

event: message_stop
data: {"type":"message_stop"}
```

La séquence est toujours la même : `message_start` → (`content_block_start` → `content_block_delta`* → `content_block_stop`) répété pour chaque bloc → `message_delta` (avec le `stop_reason` et l'usage de sortie) → `message_stop`. Des événements `ping` peuvent s'intercaler pour maintenir la connexion, et un événement `error` peut survenir en cours de route (par exemple `overloaded_error`) : votre code doit le gérer. Les deltas ont plusieurs types : `text_delta` (texte), `input_json_delta` (arguments d'un outil, module 17), `thinking_delta` et `signature_delta` (raisonnement).

```
            ┌──────────────────────── message_start ────────────────────────┐
            │   ┌─ content_block_start ─┐                                   │
 serveur ──▶│   │  content_block_delta  │ × n   … (un cycle par bloc) …     │──▶ client
            │   └─ content_block_stop ──┘                                   │
            │                  message_delta (stop_reason, usage.output)    │
            └──────────────────────── message_stop ─────────────────────────┘
```

> 🔗 **Documentation officielle** — [Streaming Messages](https://platform.claude.com/docs/en/build-with-claude/streaming) · [MDN — Server-Sent Events](https://developer.mozilla.org/fr/docs/Web/API/Server-sent_events/Using_server-sent_events) · [OpenAI — Streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses)

```quiz
{
  "q": "Mise en situation : vous relayez un flux Anthropic vers un navigateur et voulez afficher le texte au fur et à mesure. Quels événements devez-vous lire pour obtenir les morceaux de texte ?",
  "options": [
    "message_start, qui annonce le message et l'usage d'entrée",
    "message_stop, qui clôt le flux une fois la réponse terminée",
    "content_block_delta (text_delta)",
    "ping, envoyé régulièrement pendant toute la génération"
  ],
  "answer": 2,
  "explanation": "Le texte arrive dans les content_block_delta de type text_delta. message_start annonce le message et l'usage d'entrée, message_stop clôt le flux, ping sert seulement à garder la connexion ouverte."
}
```

### 4.3 Streaming en Python

Le SDK propose deux niveaux. Le niveau haut, `client.messages.stream(...)`, assemble les événements et expose `text_stream` ; il reconstitue aussi le message final complet (`get_final_message()`), avec l'usage.

```python
# stream_python.py — streaming avec le SDK (niveau haut)
from anthropic import Anthropic

client = Anthropic()

with client.messages.stream(
    model="claude-sonnet-5-5",
    max_tokens=400,
    system="Vous êtes l'assistant de Chauffage Martin. Répondez en français.",
    messages=[{"role": "user", "content": "Explique à un client ce qu'est un entretien annuel de chaudière, en 5 lignes."}],
) as stream:
    for fragment in stream.text_stream:
        print(fragment, end="", flush=True)   # affichage au fil de l'eau
    print()
    final = stream.get_final_message()        # le message complet, assemblé par le SDK

print("stop_reason :", final.stop_reason)
print("tokens      :", final.usage.input_tokens, "in /", final.usage.output_tokens, "out")
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `with client.messages.stream(...) as stream:` : `with` ouvre la connexion de streaming et garantit qu'elle sera **refermée proprement** à la fin du bloc, même en cas d'erreur (comme une porte qui se referme toute seule derrière vous).
> - `for fragment in stream.text_stream:` : la boucle reçoit les morceaux de texte un par un, au fur et à mesure qu'ils arrivent du serveur.
> - `print(fragment, end="", flush=True)` : `end=""` évite le retour à la ligne après chaque morceau ; `flush=True` force l'affichage immédiat (sinon Python attendrait d'avoir un paquet de texte).
> - `stream.get_final_message()` : une fois le flux terminé, le SDK vous rend le message complet, du même type que celui de `create`, avec `stop_reason` et `usage`.

Le niveau bas, `stream=True` sur `create`, vous livre les événements bruts : indispensable quand vous relayez le flux vers un navigateur ou quand vous suivez les appels d'outils.

```python
# stream_evenements.py — streaming niveau bas : événements bruts
from anthropic import Anthropic

client = Anthropic()
texte = []

with client.messages.create(
    model="claude-haiku-5-5",
    max_tokens=200,
    stream=True,
    messages=[{"role": "user", "content": "Liste 3 signes qu'une chaudière doit être remplacée."}],
) as evenements:
    for ev in evenements:
        if ev.type == "message_start":
            print("[début] tokens d'entrée :", ev.message.usage.input_tokens)
        elif ev.type == "content_block_delta" and ev.delta.type == "text_delta":
            texte.append(ev.delta.text)
            print(ev.delta.text, end="", flush=True)
        elif ev.type == "message_delta":
            print(f"\n[fin] stop_reason={ev.delta.stop_reason}, tokens de sortie={ev.usage.output_tokens}")

print("Longueur du texte assemblé :", len("".join(texte)), "caractères")
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `stream=True` sur `create` : au lieu d'un message, vous recevez la suite d'**événements bruts** de la section 4.2.
> - `for ev in evenements:` puis `if ev.type == …` : on trie les événements selon leur type ; chaque branche correspond à une ligne `event:` du flux SSE.
> - `ev.delta.type == "text_delta"` : on ne garde que les morceaux de texte (pas les arguments d'outils ni le raisonnement).
> - `texte.append(...)` puis `"".join(texte)` : on range les morceaux dans une liste, puis on les recolle en un seul texte à la fin. C'est ce que `get_final_message()` faisait pour vous au niveau haut.

### 4.4 Streaming en TypeScript

```typescript
// src/stream.ts — streaming avec @anthropic-ai/sdk
import "dotenv/config";
import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic();

async function main(): Promise<void> {
  const stream = client.messages.stream({
    model: "claude-sonnet-5-5",
    max_tokens: 400,
    system: "Vous êtes l'assistant de Chauffage Martin. Répondez en français.",
    messages: [
      { role: "user", content: "Explique à un client ce qu'est un entretien annuel de chaudière, en 5 lignes." },
    ],
  });

  // Événement de haut niveau : chaque fragment de texte
  stream.on("text", (fragment) => process.stdout.write(fragment));

  // Le message complet, une fois le flux terminé
  const final = await stream.finalMessage();
  console.log("\nstop_reason :", final.stop_reason);
  console.log("tokens      :", final.usage.input_tokens, "in /", final.usage.output_tokens, "out");
}

main().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `client.messages.stream({...})` : démarre le flux (pas de `await` ici : on récupère tout de suite un objet « flux » qui va recevoir les morceaux).
> - `stream.on("text", (fragment) => process.stdout.write(fragment))` : « à chaque fois qu'un morceau de texte arrive, exécute cette petite fonction ». `(fragment) => …` est une fonction fléchée (une fonction sans nom) ; `process.stdout.write` affiche sans retour à la ligne.
> - `await stream.finalMessage()` : attend la fin du flux et renvoie le message complet avec son usage.

Pour relayer le flux vers un navigateur depuis une route Next.js ou Express, vous itérez sur `stream` (`for await (const event of stream)`) (une boucle qui attend l'arrivée de chaque événement avant de tourner une fois de plus) et vous réécrivez chaque `text_delta` dans votre propre réponse SSE. Le navigateur lit alors votre flux avec l'objet standard `EventSource` ou `fetch` + `ReadableStream`. La clé API, elle, ne quitte jamais le serveur (leçon L065).

### 4.5 Le même streaming avec le SDK OpenAI

```python
# stream_openai.py — Responses API en streaming
from openai import OpenAI

client = OpenAI()
with client.responses.stream(
    model="gpt-6.1-terra",   # 1 $ / 5 $ par MTok (nov. 2026)
    input="Explique en 3 lignes ce qu'est un entretien annuel de chaudière.",
) as stream:
    for event in stream:
        if event.type == "response.output_text.delta":
            print(event.delta, end="", flush=True)
    print()
    final = stream.get_final_response()
    print("tokens :", final.usage.input_tokens, "in /", final.usage.output_tokens, "out")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Même structure qu'avec Anthropic : `with client.responses.stream(...)` ouvre le flux ; dans la boucle, on ne garde que les événements de type `response.output_text.delta`, dont `event.delta` contient le morceau de texte ; `stream.get_final_response()` rend la réponse complète et son usage une fois le flux terminé.

Les noms d'événements diffèrent (`response.output_text.delta` chez OpenAI, `content_block_delta` chez Anthropic), la logique est la même : un flux SSE, des deltas de texte, un événement final avec l'usage.

## 5. L'asynchrone : plusieurs appels à la fois, sans se faire bloquer

Un appel à un LLM dure de 0,5 à 30 secondes. Si Chauffage Martin reçoit 200 e-mails à classer, les traiter un par un prend une demi-heure ; en parallèle, quelques minutes. Python (`asyncio`) et Node (natif) savent attendre plusieurs réponses réseau simultanément sans multiplier les threads. Le SDK fournit `AsyncAnthropic`, dont l'interface est identique à `Anthropic` avec `await`.

> 🧭 **Pré-requis express — `asyncio` en Python** — Sans asynchrone, un programme qui appelle une API attend, les bras croisés, chaque réponse avant d'envoyer la question suivante. Avec `asyncio`, il envoie plusieurs questions et s'occupe de chaque réponse dès qu'elle arrive, comme un serveur de restaurant qui prend plusieurs commandes sans rester planté devant la cuisine.
> - `async def f():` définit une **coroutine** : une fonction qui peut se mettre en pause.
> - `await quelque_chose` : « mets-moi en pause ici jusqu'au résultat ; pendant ce temps, avance sur les autres tâches ».
> - `asyncio.gather(t1, t2, …)` lance plusieurs coroutines en même temps et rend la liste de leurs résultats, **dans l'ordre** où on les a données.
> - `asyncio.Semaphore(5)` est un videur : au plus 5 tâches à la fois dans la salle ; les autres attendent qu'une place se libère.
> - `asyncio.run(main())` démarre le tout ; on ne l'écrit **qu'une fois**, à la fin du script.
> - Appeler une coroutine sans `await` ne l'exécute pas : Python affiche alors l'avertissement `coroutine ... was never awaited`.

La subtilité : si vous lancez 200 appels d'un coup, vous récolterez des 429 (leçon L067). On limite donc la **concurrence** avec un sémaphore.

```python
# parallele.py — classer 20 e-mails en parallèle, 5 appels simultanés au maximum
import asyncio
import time

from anthropic import AsyncAnthropic

client = AsyncAnthropic()
semaphore = asyncio.Semaphore(5)   # au plus 5 requêtes en vol

EMAILS = [
    "Ma chaudière ne démarre plus depuis ce matin, il fait 12 °C dans la maison.",
    "Pouvez-vous m'envoyer un devis pour remplacer un chauffe-eau de 200 L ?",
    "Facture n° 2026-118 : je n'ai pas reçu l'attestation d'entretien.",
    "Petite fuite au niveau du robinet de la cuisine, pas urgent.",
] * 5   # 20 e-mails


async def classer(index: int, email: str) -> tuple[int, str]:
    async with semaphore:
        msg = await client.messages.create(
            model="claude-haiku-5-5",
            max_tokens=10,
            system="Classe l'e-mail en un seul mot parmi : URGENT, DEVIS, ADMINISTRATIF, PETIT_TRAVAUX.",
            messages=[{"role": "user", "content": email}],
        )
        bloc = msg.content[0]
        return index, bloc.text.strip() if bloc.type == "text" else "?"


async def main() -> None:
    debut = time.perf_counter()
    resultats = await asyncio.gather(*(classer(i, e) for i, e in enumerate(EMAILS)), return_exceptions=True)
    for r in resultats:
        if isinstance(r, Exception):
            print("ERREUR :", r)
        else:
            print(f"e-mail {r[0]:2d} → {r[1]}")
    print(f"{len(EMAILS)} e-mails en {time.perf_counter() - debut:.1f} s")


asyncio.run(main())
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `client = AsyncAnthropic()` : la version asynchrone du client ; ses méthodes s'utilisent avec `await`.
> - `[...] * 5` : répète la liste de 4 e-mails cinq fois, pour en obtenir 20.
> - `async with semaphore:` : prend une des 5 places ; la place est rendue automatiquement à la fin du bloc.
> - `msg = await client.messages.create(...)` : envoie la requête et attend la réponse **sans bloquer** les autres tâches.
> - `-> tuple[int, str]` : annotation qui dit « cette fonction renvoie un couple (numéro, catégorie) » ; on garde le numéro pour retrouver quel e-mail a reçu quelle catégorie.
> - `asyncio.gather(*(classer(i, e) for i, e in enumerate(EMAILS)), return_exceptions=True)` : `enumerate` numérote les e-mails (0, 1, 2…), on crée une tâche `classer` par e-mail, `*` les passe toutes à `gather`, qui les lance ensemble. `return_exceptions=True` range une erreur dans la liste de résultats au lieu de tout arrêter.
> - `isinstance(r, Exception)` : vérifie si le résultat est une erreur, pour l'afficher à part.

Trois détails à retenir : `return_exceptions=True` empêche qu'une seule erreur n'annule les dix-neuf autres résultats ; le sémaphore se règle en fonction de votre palier de débit (L067) ; et `AsyncAnthropic` conserve les mêmes *retries* automatiques que le client synchrone. En TypeScript, `Promise.all` joue le rôle de `gather`, et une petite bibliothèque comme `p-limit` celui du sémaphore.

> ⚠️ **Piège fréquent** — Mélanger client synchrone et code `async` : appeler `Anthropic().messages.create()` (bloquant) à l'intérieur d'une coroutine bloque toute la boucle d'événements, et vos « 20 appels parallèles » redeviennent séquentiels. Dans du code `async`, utilisez `AsyncAnthropic` et `await`, systématiquement.

> 🛠️ **Si ça ne marche pas** —
> - `RuntimeError: asyncio.run() cannot be called from a running event loop` → vous êtes dans un notebook Jupyter, qui a déjà sa propre boucle → remplacez la dernière ligne par `await main()`.
> - `RuntimeWarning: coroutine '…' was never awaited` → un `await` manque devant un appel à une fonction `async` → ajoutez-le.
> - Beaucoup de `RateLimitError` (429) dans les résultats → la concurrence dépasse votre palier de débit → baissez le sémaphore (3 au lieu de 5) ou passez par la Batch API (L073).
> - Le streaming s'affiche d'un seul bloc à la fin → `flush=True` manque dans `print`, ou un proxy d'entreprise met la réponse en mémoire tampon → ajoutez `flush=True` ; testez avec `curl --no-buffer` pour savoir de quel côté vient le problème.
> - `AttributeError: 'Message' object has no attribute 'text'` → vous avez écrit `msg.text` au lieu de `msg.content[0].text` → la réponse est toujours une liste de blocs.

### 🔎 Chasse à l'API

```mission
{
  "title": "Comment active-t-on le streaming chez OpenAI ?",
  "url": "https://developers.openai.com/api/docs/guides/streaming-responses",
  "steps": ["Ouvrez le guide Streaming responses d'OpenAI", "Repérez le paramètre à ajouter à client.responses.create pour recevoir un flux", "Cherchez le nom de l'événement qui transporte un morceau de texte, puis celui qui signale la fin de la réponse"],
  "question": "Quel paramètre active le streaming dans l'API Responses, quel événement porte les morceaux de texte et lequel annonce la fin ?",
  "hint": "Le paramètre est un simple booléen ; les événements commencent tous par « response. ».",
  "answer": "stream=True (stream: true en JSON) ; les morceaux de texte arrivent dans response.output_text.delta et la fin est signalée par response.completed (nov. 2026) — vérifiez sur le guide (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Que signifie officiellement le code 429 ?",
  "url": "https://developer.mozilla.org/fr/docs/Web/HTTP/Status",
  "steps": ["Ouvrez la page MDN des codes de statut HTTP", "Descendez jusqu'aux réponses d'erreur du client (400 à 499)", "Lisez la fiche du code 429 et repérez l'en-tête qui indique combien de temps attendre"],
  "question": "Quel est l'intitulé standard du code 429, et quel en-tête de réponse peut indiquer le délai avant de réessayer ?",
  "hint": "L'intitulé anglais signifie « trop de requêtes » ; l'en-tête se traduit par « réessayer après ».",
  "answer": "429 Too Many Requests ; l'en-tête Retry-After indique le délai d'attente (en secondes ou sous forme de date). Le SDK Anthropic le respecte automatiquement (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Les événements du streaming Claude, dans la doc",
  "url": "https://platform.claude.com/docs/en/build-with-claude/streaming",
  "steps": ["Ouvrez la page Streaming Messages de la documentation Claude Platform", "Repérez la section qui décrit le déroulement des événements (event flow)", "Notez le nom de l'événement qui peut apparaître à tout moment pour maintenir la connexion, et les types de deltas possibles"],
  "question": "Quel événement sert à maintenir la connexion ouverte, et quels sont les quatre types de deltas listés ?",
  "hint": "L'événement de maintien porte le nom d'un bruit de sonar ; les deltas concernent le texte, le JSON d'un outil, le raisonnement et sa signature.",
  "answer": "L'événement ping ; deltas text_delta, input_json_delta, thinking_delta et signature_delta (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🎮 Défi

Dans la sortie SSE de la section 4.2, le `message_start` annonce `"output_tokens": 1` et le `message_delta` final annonce `"output_tokens": 14`. Pourquoi deux valeurs ? (Réponse : `message_start` est émis avant la génération et contient l'usage **d'entrée** définitif plus un compteur de sortie provisoire ; le `message_delta` final donne le total de sortie, celui qui sera facturé. Comptez toujours à la fin.)

## 🧪 Exercice pratique

**Consigne.** Écrivez `assistant_stream.py` (ou `.ts`), un mini-chat en ligne de commande pour Chauffage Martin :

1. Il lit une question au clavier, l'ajoute à une liste `historique` (rôle `user`), et appelle `claude-haiku-5-5` **en streaming** ; la réponse s'affiche au fil de l'eau, puis est ajoutée à `historique` (rôle `assistant`). La boucle continue jusqu'à ce que l'utilisateur tape `quit`.
2. Enveloppez l'appel dans la fonction de retry de la section 3.2 (adaptée au streaming : réessayez uniquement si l'erreur survient **avant** le premier token reçu).
3. Simulez une erreur : lancez le script avec une clé volontairement fausse (`ANTHROPIC_API_KEY=sk-ant-faux`) et vérifiez que votre programme affiche un message clair (« clé invalide, 401 ») **sans** réessayer.
4. Simulez une erreur de modèle : utilisez `model="claude-haiku-5-5-typo"` et vérifiez que le 404 est traité sans retry.

**Critères de réussite.**
- Le texte s'affiche progressivement (vous voyez les mots apparaître), pas d'un bloc.
- Après chaque réponse, le programme affiche les tokens d'entrée et de sortie lus dans le message final.
- Un 401 et un 404 produisent un message d'erreur lisible et un code de sortie non nul, sans aucune attente.
- L'historique est bien renvoyé en entier à chaque tour (vérifiez que le modèle se souvient de votre prénom donné au tour 1).

**Pistes de corrigé.** Utilisez `with client.messages.stream(...) as stream:` et `stream.text_stream` ; après la boucle, `stream.get_final_message()` vous donne le texte complet à stocker dans l'historique et l'usage. Pour le retry « avant premier token », mettez un drapeau `premier_token_recu = False` que vous passez à `True` dans la boucle ; dans le `except`, ne réessayez que si le drapeau est encore `False`. Les exceptions 401 et 404 sont `AuthenticationError` et `NotFoundError` : attrapez-les explicitement avant le cas général.

## ✅ Auto-évaluation express

1. Quels en-têtes HTTP sont indispensables pour un appel brut à `POST /v1/messages` ?
2. Votre application reçoit un 429 puis un 529 dans la même minute. Laquelle de ces deux erreurs est « de votre faute » et que faites-vous dans chaque cas ?
3. Dans un flux SSE Anthropic, quel événement porte le `stop_reason` final ?

**Réponses.** 1) `x-api-key`, `anthropic-version` (ex. `2026-10-21`) et `content-type: application/json`. 2) Le 429 signifie que **vous** dépassez votre quota : ralentissez (sémaphore, file d'attente) et respectez `retry-after` ; le 529 signifie que l'API est surchargée : réessayez avec backoff et jitter, sans rien changer à votre requête. 3) `message_delta`, qui contient aussi le compte définitif de tokens de sortie ; `message_stop` ne fait que clore le flux.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un appel à un LLM n'est qu'une requête HTTP POST avec des en-têtes (clé, version) et un corps JSON ; l'API est sans état, vous renvoyez tout l'historique à chaque fois. 2. Le code d'erreur dit qui doit agir : 4xx = corrigez votre requête (sauf 408, 409, 429), 429 / 5xx / 529 = attendez et réessayez avec backoff et jitter. 3. Le streaming (SSE) affiche la réponse au fil de l'eau, et l'asynchrone avec un sémaphore lance plusieurs appels en parallèle sans déclencher de 429.

## 📚 Pour aller plus loin

- [Claude Platform — Streaming Messages](https://platform.claude.com/docs/en/build-with-claude/streaming) 🇬🇧 — tous les types d'événements et de deltas, y compris pour les outils et le raisonnement.
- [Claude Platform — Handling stop reasons](https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons) 🇬🇧 — quoi faire pour chaque valeur de `stop_reason`, y compris `pause_turn` et `refusal`.
- [Claude Platform — API overview](https://platform.claude.com/docs/en/api/overview) 🇬🇧 — authentification, versions, tailles de requêtes, en-têtes de réponse.
- [MDN — Codes de statut HTTP](https://developer.mozilla.org/fr/docs/Web/HTTP/Status) 🇫🇷 — la référence générale des codes 1xx à 5xx.
- [OpenAI — Streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses) 🇬🇧 — les événements de l'API Responses.

> 🗺️ **Et maintenant ?** — Vous savez ce qui circule dans chaque appel ; la leçon L067 vous apprend à compter ce que ça coûte : tokens, prix, limites de débit et cache, pour maîtriser la facture.
