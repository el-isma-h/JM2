---
module: M18
title: "Fiche mémo — API OpenAI"
---
# Fiche mémo — M18 · API OpenAI

> En une phrase : chez OpenAI, tout passe par la Responses API (`client.responses.create`). Les mêmes réflexes qu'avec Claude s'appliquent, avec d'autres noms de champs.

## Les 7 idées à retenir
1. On utilise la Responses API. Chat Completions est l'ancien format : on sait le lire, on ne l'écrit plus (`L078`).
2. `instructions` remplace le message `system`. La réponse est une liste `output[]` d'items typés, et `output_text` n'est qu'un raccourci du SDK (`L078`).
3. `previous_response_id` évite de renvoyer l'historique, mais la réponse est alors stockée chez OpenAI (`store` vaut `true` par défaut). Pensez au RGPD (`L078`).
4. Function calling : les `arguments` arrivent en chaîne JSON. On renvoie un item `function_call_output` avec le même `call_id` (`L079`).
5. Le mode strict (`text.format`, `strict: true`) garantit la forme du JSON, pas sa vérité (`L079`).
6. L'Agents SDK remplace la boucle écrite à la main : agents, outils, handoffs, guardrails, traces. Bornez toujours `max_turns` (`L081`).
7. D'abord on évalue, ensuite on optimise. Le fine-tuning se ferme : plus aucun nouveau job à partir du 6 janvier 2027 (`L082`).

## Le schéma à connaître
```mermaid
flowchart LR
    Q["input + tools"] --> M["Modèle GPT-6"]
    M -->|"function_call (name, arguments, call_id)"| F["Votre fonction"]
    F -->|"function_call_output (même call_id)"| M
    M -->|"output_text"| R["Réponse"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| `output[]` | La liste des items : `reasoning`, `message`, `function_call`… |
| `call_id` | Le fil qui relie un appel de fonction à son résultat |
| Handoff | Un outil `transfer_to_<agent>` qui passe la conversation au spécialiste |
| Guardrail | Le vigile qui vérifie l'entrée ou la sortie, en parallèle de l'agent |
| Embedding | Un vecteur qui représente le sens d'un texte |
| Clé éphémère | Le secret court-terme qu'on donne au navigateur pour Realtime |
| `safety_identifier` | Un id utilisateur haché pour isoler un abus |

## Les pièges classiques
- Croire que `output[0]` est le message. Ce peut être un item `reasoning` : filtrez par `type`.
- Oublier de parser `arguments` ou de recopier le `call_id` : erreur 400.
- Chercher `output_text` dans un résultat de batch. Il faut lire `output[]` à la main.
- Comparer des embeddings issus de deux modèles différents. Si on change de modèle, on re-vectorise tout.
- Mettre `OPENAI_API_KEY` dans le navigateur, même pour Realtime.
- Promettre un fine-tuning OpenAI à un nouveau client.
- Donner à l'agent un outil irréversible (virement, envoi) sans approbation humaine.

## Les commandes / chiffres / dates utiles
```python
from openai import OpenAI
client = OpenAI()                                   # lit OPENAI_API_KEY
r = client.responses.create(model="gpt-6.1-terra", instructions="Français, court.",
        input="…", max_output_tokens=500,
        tools=[{"type": "function", "name": "chercher_commande", "description": "…",
                "strict": True, "parameters": {"type": "object",
                "properties": {"numero": {"type": "string"}},
                "required": ["numero"], "additionalProperties": False}}])
for it in r.output:
    if it.type == "function_call":
        args = json.loads(it.arguments)             # chaîne JSON
        entree += r.output + [{"type": "function_call_output", "call_id": it.call_id,
                               "output": json.dumps(chercher_commande(**args))}]
f = client.responses.parse(model="gpt-6-luna", input="…", text_format=Facture).output_parsed
```
```python
from agents import Agent, Runner, function_tool       # pip install openai-agents
agent = Agent(name="Devis", model="gpt-6.1-sol", instructions="…", tools=[tarif])
res = await Runner.run(agent, "Devis pour…", max_turns=8)
```
| Chat Completions | Responses |
|---|---|
| `messages` (`system`) | `instructions` + `input` |
| `choices[0].message.content` | `output_text` |
| `max_tokens` | `max_output_tokens` |
| `response_format` | `text.format` |
| `n=3` | n'existe plus |

- **Tarifs nov. 2026 ($/MTok, entrée / cache / sortie)** : Luna 0,10 / 0,01 / 0,50 · Terra 1 / 0,05 / 5 · Sol 2 / 0,10 / 10 · Astra 10 / 1 / 50. Contexte 1,05M.
- **Batch** et **Flex** : 0,5 × le prix. **Ultrafast** : × 6 (Astra et Sol seulement).
- **Cache** : automatique sur un préfixe identique. Rétention 30 min ou 12 h (annoncée le 20/10/2026).
- **Audio** : `gpt-transcribe` coûte 0,0045 $/min. `gpt-realtime-2.1` coûte 32 / 64 $ par MTok audio, la version mini 10 / 20.
- **Outil `file_search`** : 2,50 $ les 1 000 appels.
- **Moderation API** : gratuite (`client.moderations.create`).
- **Arrêts annoncés** : `tts-1`, `tts-1-hd` et `gpt-4o-mini-tts` le 6/01/2027 · série GPT-4 le 14/01/2027 · `whisper-1` et `gpt-4o-transcribe` le 26/02/2027.
- **Fine-tuning** : fermé aux nouveaux comptes depuis le 7/05/2026, aux comptes inactifs depuis le 2/07/2026, puis à tous le 6/01/2027. L'inférence continue sur les modèles déjà fine-tunés.

## Pour aller plus loin
- [Migrate to the Responses API](https://developers.openai.com/api/docs/guides/migrate-to-responses)
- [Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [Agents SDK](https://developers.openai.com/api/docs/guides/agents/sdk)

## Auto-test (3 questions — réponses en bas de fiche)
1. Comment rendre un champ facultatif dans un schéma strict ?
2. Vous portez un assistant de Sonnet 5.5 vers GPT-6.1 Sol, au même prix catalogue. Qu'est-ce qui pèse le plus sur la facture ?
3. Un handoff, techniquement, c'est quoi ?

---
**Réponses.** 1) On le laisse dans `required`, avec un type nullable (`["string", "null"]`). 2) Le cache du prompt système : il divise la facture par environ trois. 3) Un outil `transfer_to_<agent>`. Quand le modèle l'appelle, le SDK bascule la conversation vers l'agent cible.
