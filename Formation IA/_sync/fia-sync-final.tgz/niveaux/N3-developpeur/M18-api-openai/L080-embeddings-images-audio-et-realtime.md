---
id: L080
module: M18
level: N3
title: "Embeddings, images, audio et Realtime"
minutes: 55
objectives:
  - "Calculer des embeddings et une similarité cosinus pour une recherche sémantique sur des documents d'entreprise"
  - "Envoyer une image en entrée (vision) et générer une image avec les modèles gpt-image"
  - "Transcrire un fichier audio, synthétiser de la parole et expliquer l'architecture d'une session Realtime (WebSocket / WebRTC)"
  - "Estimer le coût de chaque modalité à partir de la page Pricing et choisir la modalité adaptée à un cas métier"
skills: ["C3.1"]
sources:
  - { title: "OpenAI Developers — Embeddings", url: "https://developers.openai.com/api/docs/guides/embeddings", lang: "en" }
  - { title: "OpenAI Developers — Images and vision", url: "https://developers.openai.com/api/docs/guides/images-vision", lang: "en" }
  - { title: "OpenAI Developers — Image generation", url: "https://developers.openai.com/api/docs/guides/image-generation", lang: "en" }
  - { title: "OpenAI Developers — Audio and speech", url: "https://developers.openai.com/api/docs/guides/audio", lang: "en" }
  - { title: "OpenAI Developers — Speech to text", url: "https://developers.openai.com/api/docs/guides/speech-to-text", lang: "en" }
  - { title: "OpenAI Developers — Text to speech", url: "https://developers.openai.com/api/docs/guides/text-to-speech", lang: "en" }
  - { title: "OpenAI Developers — Realtime", url: "https://developers.openai.com/api/docs/guides/realtime", lang: "en" }
  - { title: "OpenAI Developers — Realtime + MCP", url: "https://developers.openai.com/api/docs/guides/realtime-mcp", lang: "en" }
  - { title: "OpenAI Developers — Models", url: "https://developers.openai.com/api/docs/models", lang: "en" }
  - { title: "OpenAI Developers — Pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
---

# Embeddings, images, audio et Realtime

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 18

## 🎯 Ce que vous saurez faire
- Transformer un texte en vecteur (embedding), comparer deux vecteurs et retrouver « le document qui parle de ça » dans une base de 500 fiches produits.
- Faire lire une photo de devis manuscrit ou un ticket de caisse au modèle, et générer une image publicitaire à partir d'un brief.
- Transcrire un message vocal client, répondre en voix de synthèse, et savoir quand passer à l'API Realtime (voix-à-voix en continu).
- Mettre un prix sur chaque modalité avant de la proposer à un client.

> 🧭 **En clair** — Jusqu'ici, tout passait par du texte. Cette leçon ouvre les autres sens du modèle : la vue (lire la photo d'un ticket), l'ouïe et la parole (transcrire un message vocal, répondre avec une voix de synthèse), et une sorte de flair pour le sens des textes, les *embeddings*. Un embedding transforme une phrase en une liste de nombres, comme des coordonnées GPS : deux phrases qui veulent dire la même chose ont des coordonnées proches, même sans aucun mot commun. L'API Realtime, enfin, permet une vraie conversation téléphonique où l'on peut couper la parole au modèle. Chaque sens a son prix : on le calcule avant de le proposer à un client.

## 1. Carte des modalités (nov. 2026)

La Responses API (L078) accepte déjà du texte et des images en entrée. Autour d'elle gravitent des points d'entrée spécialisés. Voici la carte, avec les modèles listés sur la page [Models](https://developers.openai.com/api/docs/models) au 1er novembre 2026 :

| Modalité | Point d'entrée SDK | Modèles (nov. 2026) | Tarif indicatif (page Pricing, nov. 2026) |
|---|---|---|---|
| Texte → vecteur | `client.embeddings.create` | famille `text-embedding-*` (ID exact à vérifier sur la page Models : la page Pricing ne listait pas les embeddings au 1er nov. 2026) | non listé |
| Image en entrée (vision) | `client.responses.create` avec un item `input_image` | tous les GPT-6 | tokens d'image facturés comme de l'entrée texte |
| Génération d'image | outil `image_generation` dans Responses, ou `client.images.generate` | `gpt-image-2.5-sunburst`, `gpt-image-2.5-flare`, `gpt-image-2` | gpt-image-2.5 : 8 $ (entrée image) / 30 $ (sortie image) ; gpt-image-2 : 4 $ / 15 $, par million de tokens d'image |
| Parole → texte | `client.audio.transcriptions.create` | `gpt-transcribe`, `gpt-live-transcribe`, `gpt-realtime-whisper` (les `gpt-4o-*-transcribe` sont dépréciés) | gpt-transcribe 0,0045 $/min ; gpt-live-transcribe 0,017 $/min |
| Texte → parole | `client.audio.speech.create` | `gpt-4o-mini-tts` déprécié ; ID courant à vérifier sur la page Models | non listé |
| Voix ↔ voix en continu | API Realtime (WebRTC / WebSocket) | `gpt-realtime-2.1`, `gpt-realtime-2.1-mini`, `gpt-realtime-2`, `gpt-realtime-translate`, `gpt-live-1` | gpt-realtime-2.1 audio : 32 $ in / 64 $ out par M tokens ; mini : 10 $ / 20 $ ; gpt-live-1 : 0,05 $/min ; gpt-realtime-translate : 0,034 $/min |

> ⚠️ **Piège fréquent** — Les identifiants de modèles audio et d'embeddings changent souvent. Dans tout ce qui suit, les ID sont lus dans des variables d'environnement avec une valeur par défaut : si l'API renvoie « model not found », vérifiez la page Models plutôt que de chercher un bug dans votre code.

## 2. Embeddings : la recherche sémantique en 40 lignes

### 2.1 L'idée

Un **embedding** est un vecteur de nombres (typiquement 1 536 ou 3 072 dimensions) qui représente le *sens* d'un texte. Deux textes proches en sens donnent des vecteurs proches ; on mesure cette proximité par la **similarité cosinus** (1 = identiques, 0 = sans rapport). C'est la brique de base du RAG que vous construirez en M20 ; ici, nous faisons la version minimale : des vecteurs en mémoire, sans base vectorielle.

> 💡 **Autrement dit** — Imaginez une grande carte où chaque phrase est une punaise. « Annuler un devis signé à domicile » et « délai de rétractation de 14 jours » sont plantées côte à côte, tandis que « horaires de l'atelier » est loin. La similarité cosinus vérifie si deux punaises pointent dans la même direction : proche de 1, même sujet ; proche de 0, rien à voir.

> 🧭 **Pré-requis express — vecteur et similarité cosinus** — Un **vecteur** est simplement une liste de nombres, par exemple `[0.12, -0.53, 0.08, …]`. Chaque nombre est une « dimension » : un embedding de 1 536 dimensions est une liste de 1 536 nombres. On peut voir cette liste comme une flèche qui part du centre d'un espace et pointe dans une direction. La **similarité cosinus** compare deux flèches : on multiplie les nombres deux à deux et on additionne (le *produit scalaire*), puis on divise par la longueur de chaque flèche (la *norme*, racine carrée de la somme des carrés). Le résultat vaut près de 1 si les flèches pointent dans la même direction (même sens), près de 0 si elles n'ont rien à voir. Vous n'avez pas à retenir la formule : la fonction `cosinus` ci-dessous la contient, en trois lignes.

### 2.2 Python

```python
# recherche_semantique.py — embeddings + similarité cosinus, sans base vectorielle
import math, os
from openai import OpenAI

client = OpenAI()
MODELE_EMB = os.environ.get("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")  # ID à vérifier sur la page Models

FICHES = [
    "Garantie décennale : couvre les dommages compromettant la solidité de l'ouvrage pendant 10 ans.",
    "Délai de rétractation : 14 jours pour un contrat conclu hors établissement.",
    "Acompte : 30 % à la commande, solde à la réception des travaux.",
    "Horaires de l'atelier : du lundi au vendredi, 8 h - 17 h.",
]

def embed(textes: list[str]) -> list[list[float]]:
    r = client.embeddings.create(model=MODELE_EMB, input=textes)
    return [d.embedding for d in r.data]          # même ordre que l'entrée

def cosinus(a: list[float], b: list[float]) -> float:
    num = sum(x * y for x, y in zip(a, b))
    return num / (math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b)))

vecteurs = embed(FICHES)                          # 1 seul appel pour toutes les fiches

question = "Je peux annuler mon devis signé à domicile ?"
v_q = embed([question])[0]
scores = sorted(((cosinus(v_q, v), f) for v, f in zip(vecteurs, FICHES)), reverse=True)
for s, f in scores[:2]:
    print(f"{s:.3f}  {f}")
# Attendu : la fiche "Délai de rétractation" en tête, bien qu'aucun mot ne soit commun.
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `os.environ.get("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")` : lit l'identifiant du modèle dans l'environnement, avec une valeur par défaut si la variable n'existe pas.
> - `client.embeddings.create(model=…, input=textes)` : envoie **toute la liste** en un appel ; `[d.embedding for d in r.data]` récupère un vecteur par texte, dans le même ordre.
> - `sum(x * y for x, y in zip(a, b))` : `zip` associe les nombres des deux vecteurs deux à deux ; on multiplie et on additionne (le produit scalaire). La ligne suivante divise par la longueur des deux vecteurs.
> - `embed([question])[0]` : on vectorise la question (dans une liste d'un seul élément), puis on prend le premier et unique vecteur.
> - `sorted(((cosinus(v_q, v), f) for v, f in zip(vecteurs, FICHES)), reverse=True)` : calcule un couple (score, fiche) pour chaque fiche, puis trie du plus grand au plus petit score ; `scores[:2]` garde les deux meilleures.

### 2.3 TypeScript

```typescript
// recherche_semantique.ts — npx tsx recherche_semantique.ts
import OpenAI from "openai";
const client = new OpenAI();
const MODELE_EMB = process.env.OPENAI_EMBEDDING_MODEL ?? "text-embedding-3-small";

const fiches = [
  "Garantie décennale : couvre les dommages compromettant la solidité de l'ouvrage pendant 10 ans.",
  "Délai de rétractation : 14 jours pour un contrat conclu hors établissement.",
  "Acompte : 30 % à la commande, solde à la réception des travaux.",
];

async function embed(textes: string[]): Promise<number[][]> {
  const r = await client.embeddings.create({ model: MODELE_EMB, input: textes });
  return r.data.map((d) => d.embedding);
}
const cos = (a: number[], b: number[]) => {
  const dot = a.reduce((s, x, i) => s + x * b[i], 0);
  const n = (v: number[]) => Math.sqrt(v.reduce((s, x) => s + x * x, 0));
  return dot / (n(a) * n(b));
};

async function main() {
  const vecteurs = await embed(fiches);
  const [vq] = await embed(["Je peux annuler mon devis signé à domicile ?"]);
  const classement = fiches.map((f, i) => ({ f, s: cos(vq, vecteurs[i]) })).sort((x, y) => y.s - x.s);
  console.table(classement);
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `r.data.map((d) => d.embedding)` récupère les vecteurs. Dans `cos`, `a.reduce((s, x, i) => s + x * b[i], 0)` parcourt le vecteur `a` en additionnant les produits avec `b` (le produit scalaire), et la petite fonction `n` calcule la longueur d'un vecteur. `const [vq] = await embed([...])` range directement le premier vecteur renvoyé dans `vq` (déstructuration). `.sort((x, y) => y.s - x.s)` trie par score décroissant, et `console.table` affiche le résultat sous forme de tableau.

> 💡 **À retenir** — Envoyez vos textes **par lots** (une liste dans `input`) : un appel pour 100 fiches, pas 100 appels. Stockez les vecteurs une fois pour toutes (fichier, SQLite, pgvector…) : seule la **question** est vectorisée à chaque recherche. Et n'oubliez pas que changer de modèle d'embedding impose de **tout re-vectoriser** : les espaces ne sont pas comparables entre modèles.

> 🛠️ **Si ça ne marche pas** —
> - Erreur 404 « model not found » → l'identifiant par défaut n'existe pas (ou plus) sur votre compte → lisez l'ID courant sur la page *Models* et définissez `export OPENAI_EMBEDDING_MODEL=…`.
> - Erreur 400 sur `input` → un texte vide (`""`) ou trop long dans la liste → filtrez les textes vides et découpez les très longs documents (L090).
> - Les scores sont tous très proches (0,80 à 0,85) → c'est normal : avec les embeddings récents, les écarts sont faibles en valeur absolue → regardez le **classement**, pas la valeur.
> - `ZeroDivisionError` dans `cosinus` → un vecteur ne contient que des zéros, signe d'une entrée vide → vérifiez les textes envoyés.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : après être passé à un nouveau modèle d'embedding, on peut garder les anciens vecteurs et ne vectoriser que les nouvelles fiches.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. Chaque modèle dessine sa propre « carte » : comparer un vecteur de l'ancien modèle à un vecteur du nouveau n'a aucun sens. Il faut tout re-vectoriser."
}
```

## 3. Images : lire et générer

### 3.1 Vision : faire lire un ticket de caisse

```python
# vision.py — envoyer une image locale en base64 à la Responses API
import base64, pathlib
from openai import OpenAI

client = OpenAI()
image = pathlib.Path("ticket.jpg")                 # photo d'un ticket de caisse
b64 = base64.b64encode(image.read_bytes()).decode()

r = client.responses.create(
    model="gpt-6.1-terra",
    instructions="Vous lisez des justificatifs de notes de frais. Répondez en français.",
    input=[{
        "role": "user",
        "content": [
            {"type": "input_text", "text": "Donne le commerçant, la date, le total TTC et la TVA."},
            {"type": "input_image", "image_url": f"data:image/jpeg;base64,{b64}", "detail": "high"},
        ],
    }],
)
print(r.output_text)
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `base64.b64encode(image.read_bytes()).decode()` traduit la photo en texte (pré-requis base64 en L072). L'image est ensuite glissée dans une **data URL** : `f"data:image/jpeg;base64,{b64}"` commence par le type MIME, puis contient l'image elle-même, si bien que l'adresse « transporte » le fichier au lieu de pointer vers un site. Le message `user` contient deux items : `input_text` (la consigne) et `input_image` (la photo) ; `"detail": "high"` demande une lecture fine, plus précise et plus chère. Pour un PNG, remplacez `image/jpeg` par `image/png`.

Une URL publique fonctionne aussi (`"image_url": "https://..."`). Le paramètre `detail` (`low` / `high` / `auto`) règle la finesse d'analyse, donc le nombre de tokens d'image facturés. Pour une extraction fiable, combinez avec une **sortie structurée** (L079) : `responses.parse(..., text_format=NoteDeFrais)`.

### 3.2 Génération : un visuel pour la vitrine

```typescript
// generer_image.ts — l'outil image_generation dans la Responses API (npx tsx generer_image.ts)
import OpenAI from "openai";
import { writeFileSync } from "node:fs";
const client = new OpenAI();

async function main() {
  const r = await client.responses.create({
    model: "gpt-6.1-terra",
    input: "Affiche sobre pour une boulangerie artisanale de Lille : pain au levain, " +
           "ambiance chaleureuse, aucun texte dans l'image.",
    tools: [{ type: "image_generation", model: process.env.OPENAI_IMAGE_MODEL ?? "gpt-image-2" }],
  });

  // Le résultat est un item image_generation_call contenant l'image en base64
  const item = r.output.find((o) => o.type === "image_generation_call");
  if (item && "result" in item && item.result) {
    writeFileSync("affiche.png", Buffer.from(item.result, "base64"));
    console.log("Image écrite : affiche.png");
  }
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `tools: [{ type: "image_generation", model: … }]` donne au modèle de texte un outil de dessin, exécuté par OpenAI. `r.output.find((o) => o.type === "image_generation_call")` cherche dans la réponse l'item qui contient l'image ; `"result" in item` vérifie que le champ existe avant de le lire. `Buffer.from(item.result, "base64")` retraduit le texte base64 en octets d'image, et `writeFileSync("affiche.png", …)` les enregistre.
>
> 🛠️ **Si ça ne marche pas** — Aucun fichier n'est écrit → l'outil n'a pas été appelé (le modèle a répondu en texte) : affichez `r.output_text` et formulez la demande comme une demande d'image (« Génère une image… »). Erreur 403 ou message sur la vérification → certains modèles d'image peuvent exiger une vérification de l'organisation dans le dashboard → faites-la, ou utilisez un autre modèle d'image. Erreur 404 sur le modèle → définissez `OPENAI_IMAGE_MODEL` avec un ID listé sur la page *Models*.

La variante « directe » `client.images.generate({ model, prompt })` existe toujours ; l'intérêt de passer par Responses est que le modèle peut **reformuler votre brief**, enchaîner plusieurs images et combiner avec d'autres outils. Rappel juridique du module M14 : un visuel généré doit respecter les conditions d'utilisation et, dans beaucoup de contextes (AI Act, art. 50), être signalé comme généré.

## 4. Audio : transcription et synthèse

### 4.1 Transcrire un message vocal (Python)

```python
# transcrire.py — speech-to-text sur un fichier audio
import os
from openai import OpenAI

client = OpenAI()
MODELE_STT = os.environ.get("OPENAI_STT_MODEL", "gpt-transcribe")   # 0,0045 $/min (nov. 2026)

with open("message_client.m4a", "rb") as f:
    t = client.audio.transcriptions.create(
        model=MODELE_STT,
        file=f,
        language="fr",                                  # accélère et fiabilise
        prompt="Vocabulaire : devis, acompte, chantier, placo, décennale.",  # aide sur le jargon
    )
print(t.text)
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `open("message_client.m4a", "rb")` ouvre le fichier audio en lecture binaire ; le `with` le referme automatiquement. `language="fr"` indique la langue parlée, et `prompt=…` donne au modèle une liste de mots du métier pour qu'il les écrive correctement. `t.text` contient la transcription. Si l'API refuse le fichier, vérifiez son format (`mp3`, `m4a`, `wav`… sont courants) et sa taille, limitée par fichier (voir le guide *Audio*) : découpez les longs enregistrements.

À 0,0045 $ la minute, transcrire **1 000 heures** de messages vocaux coûte environ 270 $ (nov. 2026). Pour du **direct** (standard téléphonique), le modèle `gpt-live-transcribe` (0,017 $/min) accepte un flux.

### 4.2 Répondre en voix (TypeScript)

```typescript
// parler.ts — text-to-speech vers un fichier MP3 (npx tsx parler.ts)
import OpenAI from "openai";
import { writeFileSync } from "node:fs";
const client = new OpenAI();

async function main() {
  const mp3 = await client.audio.speech.create({
    model: process.env.OPENAI_TTS_MODEL ?? "gpt-4o-mini-tts", // déprécié : vérifiez l'ID courant sur la page Models
    voice: "alloy",
    input: "Bonjour, votre devis est prêt. Vous pouvez le consulter dans votre espace client.",
    instructions: "Ton chaleureux, débit posé, accent français neutre.",
  });
  writeFileSync("reponse.mp3", Buffer.from(await mp3.arrayBuffer()));
  console.log("Fichier écrit : reponse.mp3");
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `client.audio.speech.create({ model, voice, input, instructions })` demande la lecture à voix haute du texte `input`, avec une voix (`alloy`) et des consignes de ton. La réponse est un fichier audio : `await mp3.arrayBuffer()` en récupère les octets, `Buffer.from(...)` les met au format attendu par Node, et `writeFileSync` crée `reponse.mp3`. Comme le modèle par défaut est déprécié (encadré ci-dessous), définissez `OPENAI_TTS_MODEL` avant de lancer.

Le pipeline **STT → Responses → TTS** suffit pour un répondeur intelligent où une latence de 2 à 4 secondes est acceptable. Il ne suffit plus pour une **conversation** naturelle : c'est le rôle de Realtime.

> 📅 **Calendrier à noter** — D'après la page [Deprecations](https://developers.openai.com/api/docs/deprecations) (nov. 2026), `tts-1`, `tts-1-hd` et `gpt-4o-mini-tts` s'arrêtent le **6 janvier 2027**, `whisper-1` et `gpt-4o-transcribe` le **26 février 2027**. La valeur par défaut de `parler.ts` ne fonctionnera donc plus après cette date : c'est précisément pour cela que l'ID est lu dans `OPENAI_TTS_MODEL`.

```quiz
{
  "q": "Un plombier veut faire transcrire les messages vocaux laissés la nuit sur son répondeur et recevoir un résumé chaque matin. Quelle architecture choisir ?",
  "options": [
    "Une transcription (`gpt-transcribe`) puis un résumé via Responses",
    "L'API Realtime en WebRTC, indispensable dès qu'il y a de la voix",
    "Des embeddings calculés directement sur l'audio brut",
    "L'outil `image_generation` appliqué au spectrogramme"
  ],
  "answer": 0,
  "explanation": "Rien n'est urgent ni interactif : une transcription à 0,0045 $/min puis un résumé suffisent. Realtime se justifie pour une conversation en direct avec interruptions."
}
```

## 5. Realtime : la voix en continu

### 5.1 Architecture

```
Navigateur / app mobile                 OpenAI Realtime
┌───────────────────────┐   WebRTC     ┌──────────────────────┐
│ micro ──► flux audio ─┼─────────────►│ gpt-realtime-2.1     │
│ haut-parleur ◄────────┼──────────────┤ (écoute, raisonne,   │
│ événements JSON ◄────►│  data channel│  parle, appelle des  │
└───────────────────────┘              │  fonctions, MCP)     │
          ▲                            └──────────────────────┘
          │ clé éphémère (jamais la vraie clé dans le navigateur !)
┌─────────┴─────────┐
│ Votre serveur     │  POST /v1/realtime/client_secrets  (WebSocket serveur-à-serveur possible)
└───────────────────┘
```

Deux transports : **WebRTC** depuis un navigateur ou un mobile (gère le micro, la gigue réseau), **WebSocket** depuis un serveur (standard téléphonique, intégration SIP). Dans les deux cas, le modèle reçoit l'audio brut et **répond en audio**, sans passer par du texte intermédiaire, ce qui permet d'être interrompu et de percevoir le ton. Les fonctions de la L079 fonctionnent à l'identique dans une session Realtime, et le guide [Realtime + MCP](https://developers.openai.com/api/docs/guides/realtime-mcp) montre comment brancher un serveur MCP distant.

### 5.2 La règle d'or de sécurité

Un navigateur ne doit **jamais** contenir `OPENAI_API_KEY`. Votre serveur demande une **clé éphémère** (client secret, courte durée) et la transmet au front, qui ouvre la session WebRTC avec elle. Voici le minimum côté serveur :

```python
# realtime_secret.py — votre serveur fabrique une clé éphémère pour le navigateur
import os
import httpx

MODELE_RT = os.environ.get("OPENAI_REALTIME_MODEL", "gpt-realtime-2.1-mini")  # 10 $ in / 20 $ out par M tokens audio

def cle_ephemere() -> dict:
    r = httpx.post(
        "https://api.openai.com/v1/realtime/client_secrets",   # chemin exact à vérifier dans le guide Realtime officiel
        headers={"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
        json={"session": {"type": "realtime", "model": MODELE_RT,
                          "instructions": "Vous êtes l'accueil téléphonique d'un garage à Rennes. Français, concis."}},
        timeout=30,
    )
    r.raise_for_status()
    return r.json()          # contient la valeur du secret et sa date d'expiration

if __name__ == "__main__":
    print(cle_ephemere())
```

> 🧭 **Pré-requis express — WebRTC, WebSocket et requête HTTP « à la main »** — Une requête HTTP classique est un aller-retour : une question, une réponse, puis la connexion se ferme. Une **WebSocket** garde la connexion ouverte dans les deux sens, pour échanger des messages en continu ; **WebRTC** fait de même entre un navigateur et un serveur, avec en plus le transport du son et de la vidéo en temps réel. C'est pourquoi la voix en continu passe par ces deux techniques. Le petit script ci-dessous, lui, est une requête HTTP ordinaire, faite sans SDK avec la bibliothèque `httpx` (`pip install httpx`).
>
> 🔍 **Ce que fait ce code, ligne par ligne** — `httpx.post(url, headers=…, json=…, timeout=30)` envoie une requête POST : l'en-tête `Authorization: Bearer …` porte **votre vraie clé** (lue sur le serveur), le corps `json=` décrit la session voulue (modèle, consignes). `r.raise_for_status()` transforme une réponse d'erreur (401, 404…) en exception Python, au lieu de continuer avec une réponse vide. `r.json()` renvoie la clé éphémère et sa date d'expiration : c'est **elle seule** que vous transmettrez au navigateur. Si vous obtenez une erreur 404, vérifiez le chemin exact dans le guide Realtime, comme l'indique le commentaire.

Le front (page [Realtime](https://developers.openai.com/api/docs/guides/realtime)) crée ensuite un `RTCPeerConnection`, attache le micro, et échange des événements JSON sur le data channel (`session.update`, `response.create`, `conversation.item.*`). Le Agents SDK (L081) fournit un `RealtimeAgent` qui masque cette tuyauterie.

```quiz
{
  "q": "Dans une application vocale Realtime qui tourne dans le navigateur, où doit se trouver `OPENAI_API_KEY` ?",
  "options": [
    "Dans le code JavaScript du front, une fois minifié",
    "Dans le `localStorage` du navigateur",
    "Sur le serveur, qui fournit une clé éphémère",
    "Dans un paramètre de l'URL de la page"
  ],
  "answer": 2,
  "explanation": "Tout ce qui est dans le navigateur est lisible par l'utilisateur. Le serveur garde la vraie clé et fabrique un secret de courte durée pour ouvrir la session WebRTC."
}
```

### 5.3 Combien ça coûte ?

Sur `gpt-realtime-2.1`, l'audio est facturé 32 $ par million de tokens en entrée et 64 $ en sortie (nov. 2026) ; la version **mini** divise par trois. Ordre de grandeur à retenir : une minute de conversation consomme quelques centaines à un millier de tokens audio selon le sens. Un standard qui traite 5 000 minutes par mois sera **nettement** plus coûteux en Realtime qu'en STT + TTS ; c'est le confort de l'interruption et de la latence qui se paie. Le modèle `gpt-live-1`, facturé à la minute (0,05 $), simplifie le calcul pour les cas simples.

🎮 **Défi** — Pour un cabinet de kinés qui reçoit 40 appels par jour de 2 minutes, estimez le coût mensuel (22 jours) avec `gpt-live-1`, puis avec un pipeline `gpt-transcribe` + 6.1 Terra + TTS. Lequel proposeriez-vous, et pourquoi ?

```mission
{
  "title": "Jusqu'à quand le modèle TTS du script fonctionnera-t-il ?",
  "url": "https://developers.openai.com/api/docs/deprecations",
  "steps": [
    "Ouvrez la page Deprecations de la documentation OpenAI",
    "Cherchez les modèles audio (tts, transcribe, whisper)",
    "Relevez les dates d'arrêt"
  ],
  "question": "À quelle date `gpt-4o-mini-tts` s'arrête-t-il, et quand `whisper-1` le suit-il ?",
  "hint": "Les modèles de synthèse et de transcription n'ont pas la même date.",
  "answer": "`gpt-4o-mini-tts` (avec `tts-1` et `tts-1-hd`) le 6 janvier 2027 ; `whisper-1` et `gpt-4o-transcribe` le 26 février 2027 (page Deprecations, nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Le prix de l'audio Realtime « mini »",
  "url": "https://developers.openai.com/api/docs/pricing",
  "steps": [
    "Ouvrez la page Pricing",
    "Repérez la section Realtime / audio",
    "Comparez gpt-realtime-2.1 et gpt-realtime-2.1-mini"
  ],
  "question": "Combien coûte un million de tokens audio en entrée et en sortie sur `gpt-realtime-2.1-mini` ?",
  "hint": "La version complète coûte 32 $ / 64 $.",
  "answer": "10 $ en entrée et 20 $ en sortie par million de tokens audio (nov. 2026), soit environ trois fois moins que gpt-realtime-2.1 (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Construisez `notes_de_frais.py` (ou `.ts`) pour une PME :
1. le script parcourt un dossier `justificatifs/` d'images JPEG/PNG ;
2. pour chaque image, il appelle la Responses API avec `input_image` **et** une sortie structurée `{ commercant, date_iso, total_ttc, tva, categorie }` (`categorie` ∈ `repas`, `transport`, `hebergement`, `autre`) ;
3. il calcule l'embedding de la chaîne `"{commercant} {categorie}"` et signale les doublons probables (cosinus > 0,95 entre deux justificatifs) ;
4. il produit un `notes_de_frais.csv` et affiche le coût total estimé.

**Critères de réussite.** Aucune clé en dur ; les ID de modèles sont lus dans l'environnement ; le JSON est validé (Pydantic/Zod) ; un justificatif illisible produit une ligne `erreur` sans arrêter le lot ; les doublons sont détectés sur un jeu de test contenant deux fois le même ticket.

**Pistes de corrigé.** Réutilisez `vision.py` + `responses.parse` ; pour le lot d'embeddings, un seul appel avec la liste complète ; pour le CSV, le module `csv` de la bibliothèque standard. Bonus : passez les appels de vision en Batch (L082) pour diviser le coût par deux.

## ✅ Auto-évaluation express

1. Pourquoi faut-il tout re-vectoriser quand on change de modèle d'embedding ?
2. Où doit se trouver la clé API dans une application vocale Realtime côté navigateur ?
3. Citez un cas où STT + TTS suffit et un cas où Realtime s'impose.

*Réponses : 1) Les vecteurs de deux modèles vivent dans des espaces différents ; une similarité cosinus entre eux n'a aucun sens. 2) Uniquement sur le serveur ; le navigateur reçoit une clé éphémère. 3) STT + TTS : répondeur, dictée, messages vocaux asynchrones ; Realtime : conversation téléphonique interactive avec interruptions.*

> ✅ **Si vous ne retenez que 3 choses** — 1. Un embedding est un vecteur qui représente le sens d'un texte ; la similarité cosinus compare deux vecteurs ; on vectorise par lots, on stocke les vecteurs et on re-vectorise tout si l'on change de modèle. 2. Images (lecture et génération) et audio (transcription, synthèse) passent par des appels dédiés, chacun avec son tarif ; les ID de modèles changent souvent : lisez-les dans des variables d'environnement. 3. La voix en continu (Realtime) se paie cher ; dans un navigateur, on n'utilise qu'une clé éphémère fabriquée par votre serveur, jamais la vraie clé.

## 📚 Pour aller plus loin
- [Embeddings](https://developers.openai.com/api/docs/guides/embeddings) 🇬🇧 — dimensions, cas d'usage, réduction de dimension.
- [Images and vision](https://developers.openai.com/api/docs/guides/images-vision) 🇬🇧 — formats, paramètre `detail`, limites de taille.
- [Audio and speech](https://developers.openai.com/api/docs/guides/audio) 🇬🇧 — panorama des modèles audio et du choix entre pipeline et Realtime.
- [Realtime](https://developers.openai.com/api/docs/guides/realtime) 🇬🇧 — WebRTC, WebSocket, clés éphémères, événements.
- [Pricing](https://developers.openai.com/api/docs/pricing) 🇬🇧 — tous les tarifs images, audio et Realtime cités dans cette leçon.

> 🗺️ **Et maintenant ?** — Vous savez faire voir, entendre et parler le modèle ; en L081, l'Agents SDK assemble ces briques en agents qui enchaînent les outils tout seuls, avec des garde-fous.
