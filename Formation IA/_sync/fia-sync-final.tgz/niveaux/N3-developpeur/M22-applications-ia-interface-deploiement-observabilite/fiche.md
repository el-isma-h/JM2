---
module: M22
title: "Fiche mémo — Applications IA : interface, déploiement, observabilité"
---
# Fiche mémo — M22 · Applications IA : interface, déploiement, observabilité

> En une phrase : un prototype devient une application de production quand il streame derrière un serveur authentifié, met les tâches longues en file, plafonne les coûts, trace chaque appel et bloque les régressions en CI.

## Les 7 idées à retenir
1. Le streaming réduit l'attente perçue (TTFT), pas le temps total. Le navigateur ne parle jamais directement au fournisseur (`L101`).
2. Vercel AI SDK : `streamText` côté serveur et `useChat` côté navigateur. Les outils se déclarent avec `tool()` et Zod. On change de modèle en une ligne (`L101`).
3. Au-delà de 10 secondes ou d'un appel LLM par requête, on passe par une file d'attente : la route répond 202, un worker séparé fait le travail (`L102`).
4. L'idempotence est à votre charge. Deux appels identiques sont deux appels facturés (`L102`).
5. Quatre leviers de coût : prompt caching, cache sémantique, batch (−50 %), et le bon modèle routé au bon endroit (`L102`).
6. Une trace contient des spans. Les métriques de coût, latence et qualité ont chacune un seuil et un destinataire. Le pouce haut/bas des utilisateurs est la mesure la moins chère (`L103`).
7. Un prompt, c'est du code : un fichier versionné, une suite promptfoo bloquante en CI, un feature flag par hash d'utilisateur, un retour arrière en moins de 5 min (`L104`, `L105`).

## Le schéma à connaître
```mermaid
flowchart LR
    N["Navigateur (useChat)"] -->|"HTTPS"| C["Caddy / Vercel"]
    C --> A["/api/chat : auth → quotas → cache → streamText"]
    A --> L["Fournisseur LLM (clé serveur)"]
    A --> P[("Postgres : données + pgvector + pg-boss")]
    P --> W["Worker séparé (jobs longs)"]
    A -->|"OTLP"| O["Langfuse (traces, scores)"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| TTFT | *Time to first token* : le délai avant le premier mot |
| `stopWhen: stepCountIs(n)` | Limite les allers-retours entre modèle et outils |
| Idempotence | Le faire deux fois donne le même résultat qu'une seule |
| Cache sémantique | On renvoie la réponse d'une question très proche (cosinus ≥ seuil) |
| Trace / span / generation | La requête entière / une étape / un appel LLM |
| Feature flag | Une nouvelle version activée pour un pourcentage d'utilisateurs |
| Canary | Un premier déploiement sur 5 % des utilisateurs |

## Les pièges classiques
- Mettre la clé dans `NEXT_PUBLIC_*` : elle est copiée dans le bundle au build.
- Compter les requêtes au lieu des tokens dans les quotas.
- Utiliser le cache sémantique sur des questions liées à un dossier client : on risque de servir la réponse de quelqu'un d'autre.
- Activer les traces sans durée de rétention ni masquage des données personnelles.
- Noter sur une échelle de 1 à 10 avec un juge LLM. Le binaire ou 3 niveaux, c'est plus stable.
- Faire `Math.random()` à chaque requête pour un flag. Il faut un hash stable de l'id utilisateur.
- Un proxy qui garde la réponse en tampon : le streaming arrive d'un bloc.
- Lancer le worker « dans » une route serverless appelée par un cron.

## Les commandes / chiffres / dates utiles
```typescript
const result = streamText({
  model: anthropic(process.env.AI_MODEL ?? "claude-sonnet-5-5"),
  system: SYSTEM, messages: await convertToModelMessages(messages),
  tools: { echeanceTva }, stopWhen: stepCountIs(5), maxOutputTokens: 800,
  abortSignal: req.signal,                                   // pas de temperature : 400 avec l'API 2026-10-21
  experimental_telemetry: { isEnabled: true, functionId: "chat-principal" },
});
return result.toUIMessageStreamResponse();
```
```bash
npx promptfoo eval --output resultats.json    # code ≠ 0 si un test échoue
node scripts/verifier-seuils.mjs resultats.json
deepeval test run tests/
```
```caddyfile
reverse_proxy app:3000 { flush_interval -1 }   # pas de tampon : le streaming passe
```
- **Route** : 401 si pas de session · 413 si le message dépasse `MAX_MESSAGE_CHARS` · 400 si le corps n'est pas valide (Zod) · 429 ou 402 si le quota est dépassé · `retry-after` après un 429.
- **Files d'attente** : pg-boss (Postgres, `singletonKey`, `expireInSeconds`) ou BullMQ (Redis, `jobId`).
- **Seuils de Compta-Chat** : ≥ 92 % d'assertions réussies, cas de sécurité à 100 %, ≤ 0,006 $ par réponse, TTFT p95 < 2 s, budget de 300 $ par mois.
- **Coût d'une question sur Sonnet 5.5** (1 000 tokens d'entrée + 2 000 lus en cache + 400 de sortie) : ≈ 0,0062 $. Le routage 70 % Haiku / 30 % Sonnet fait passer de 792 $ à 165 $ par mois.
- **promptfoo** : assertions déterministes `icontains`, `is-json`, `javascript`. Juge : `llm-rubric`.
- **Langfuse** : Hobby gratuit à 50 000 unités par mois, Core à 29 $ par mois. Racheté par ClickHouse en janvier 2026.
- **GitHub Actions** : `${{ secrets.NOM }}`, `concurrency` avec `cancel-in-progress: true`.

## Pour aller plus loin
- [Vercel AI SDK](https://ai-sdk.dev)
- [Langfuse](https://langfuse.com)
- [promptfoo — documentation](https://www.promptfoo.dev/docs)

## Auto-test (3 questions — réponses en bas de fiche)
1. Il faut résumer 300 liasses chaque matin, environ 8 s par document. Quelle architecture choisir ?
2. En local, le texte arrive mot à mot. Derrière Caddy, il arrive d'un bloc. Que vérifiez-vous en premier ?
3. Pourquoi les cas « injection » et « hors périmètre » sont-ils exigés à 100 % ?

---
**Réponses.** 1) Une file pg-boss : la route répond 202, un worker séparé traite les documents, de préférence via la Batch API. 2) Que le proxy ne garde pas la réponse en tampon (`flush_interval -1`). 3) Ce sont des planchers absolus : ces défauts sont inacceptables, quelle que soit leur fréquence.
