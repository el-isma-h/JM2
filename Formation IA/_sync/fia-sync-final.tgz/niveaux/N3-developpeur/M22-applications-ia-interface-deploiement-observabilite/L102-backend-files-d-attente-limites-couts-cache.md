---
id: L102
module: M22
level: N3
title: "Backend : files d'attente, limites, coûts, cache"
minutes: 50
objectives:
  - "Choisir entre traitement synchrone et file d'attente (pg-boss ou BullMQ/Redis) selon la durée et la criticité d'une tâche LLM"
  - "Rendre les traitements idempotents et appliquer des limites par utilisateur et un budget global, en s'appuyant sur les limites de débit du fournisseur"
  - "Réduire la facture avec le prompt caching, un cache sémantique pgvector, le batch et le choix de modèle"
  - "Estimer et suivre le coût réel d'une application IA à partir des champs usage"
skills: ["C3.5", "C3.1"]
sources:
  - { title: "Claude Platform — Rate limits", url: "https://platform.claude.com/docs/en/api/rate-limits", lang: "en" }
  - { title: "Claude Platform — Prompt caching", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-caching", lang: "en" }
  - { title: "Claude Platform — Batch processing", url: "https://platform.claude.com/docs/en/build-with-claude/batch-processing", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — Service tiers (Priority Tier)", url: "https://platform.claude.com/docs/en/api/service-tiers", lang: "en" }
  - { title: "OpenAI — Rate limits", url: "https://developers.openai.com/api/docs/guides/rate-limits", lang: "en" }
  - { title: "OpenAI — Batch", url: "https://developers.openai.com/api/docs/guides/batch", lang: "en" }
  - { title: "OpenAI — Pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "pg-boss (file d'attente sur Postgres)", url: "https://github.com/timgit/pg-boss", lang: "en" }
  - { title: "BullMQ — documentation", url: "https://docs.bullmq.io", lang: "en" }
  - { title: "pgvector", url: "https://github.com/pgvector/pgvector", lang: "en" }
---

# Backend : files d'attente, limites, coûts, cache

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 22

## 🎯 Ce que vous saurez faire
- Décider, pour chaque fonctionnalité, si elle répond **en direct** (chat) ou passe par une **file d'attente** (résumé de 300 PDF, génération nocturne), et implémenter la file avec pg-boss ou BullMQ.
- Garantir qu'une tâche rejouée ne facture pas deux fois (idempotence) et qu'un utilisateur ou un bot ne peut pas vider votre budget (limites par utilisateur, budget global, timeouts).
- Appliquer les quatre leviers de coût : prompt caching, cache sémantique, batch à −50 %, bon modèle au bon endroit.
- Lire `usage` et tenir une comptabilité au centime près.

> 🧭 **En clair** — Le chat de L101 est un comptoir où l'on sert à la minute. Mais certaines commandes sont énormes (résumer 300 documents) : on ne les prépare pas au comptoir, on les note dans un carnet — la **file d'attente** — et une équipe en cuisine (le *worker*) les traite une à une, même si le comptoir ferme. Il faut aussi un **videur de boîte de nuit** à l'entrée : il compte qui entre et refuse poliment ceux qui ont déjà trop consommé (limites et quotas). Enfin, pour payer moins, on réutilise ce qui est déjà prêt (le cache), on groupe les commandes non urgentes (le batch, à moitié prix) et on ne sort pas le chef étoilé pour beurrer des tartines (le bon modèle au bon endroit).

## 1. Synchrone ou file d'attente ? La règle des 10 secondes

Le chat de L101 fonctionne en direct parce que l'utilisateur **attend** la réponse et qu'elle arrive en quelques secondes. Mais le cabinet comptable de notre fil rouge veut aussi « résumer les 300 liasses fiscales reçues ce matin ». À 8 secondes par document, cela fait 40 minutes : impossible dans un route handler (Vercel coupe à `maxDuration`, un VPS garderait une connexion HTTP ouverte 40 minutes, et le moindre redéploiement perdrait tout).

La règle pratique : **au-delà de 10 secondes ou de 1 appel LLM par requête utilisateur, passez par une file d'attente** (job queue). Le route handler enregistre la tâche et répond immédiatement « tâche n° 42 acceptée » (HTTP 202) ; un *worker* séparé traite la file ; l'interface interroge l'état ou reçoit une notification.

```
Navigateur ──POST /api/jobs──► Route handler ──INSERT──► File (table Postgres ou Redis)
                 ◄── 202 { jobId }                              │
                                                                ▼
Navigateur ──GET /api/jobs/42──► état : queued / active / done   Worker (processus Node)
                                                                → appelle le LLM, écrit le résultat
```

Deux outils dominent en TypeScript (nov. 2026) :

| | **pg-boss** | **BullMQ** |
|---|---|---|
| Stockage | Postgres (que vous avez déjà pour pgvector) | Redis |
| Installation | `npm i pg-boss`, aucun service en plus | `npm i bullmq` + Redis (Docker ou Upstash) |
| Garanties | Transactions SQL, reprise après crash, `retryLimit`, `expireInSeconds`, planification cron | Très haut débit, priorités, *rate limiter* intégré, *flows* (jobs parents/enfants) |
| Quand le choisir | Petites et moyennes charges, simplicité opérationnelle, un seul service à sauvegarder | Dizaines de milliers de jobs/heure, besoin de limiter le débit finement |

Pour Compta-Chat, pg-boss suffit et évite un composant supplémentaire. Installez d'abord les paquets de la leçon (dans le projet `compta-chat` de L101), puis ajoutez à `db/init.sql` les tables métier dont se servent le worker et les quotas :

```bash
npm install pg-boss @ai-sdk/mistral   # file d'attente + fournisseur d'embeddings du cache sémantique (section 4.2)
```

```sql
-- db/init.sql (suite) — tables métier de L102 ; pg-boss crée seul les siennes au premier boss.start()
CREATE TABLE IF NOT EXISTS documents (
  id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),   -- la route /api/jobs exige un UUID
  nom   text NOT NULL,
  texte text NOT NULL
);
CREATE TABLE IF NOT EXISTS resumes (
  document_id uuid PRIMARY KEY REFERENCES documents(id) ON DELETE CASCADE,  -- 1 résumé par document (verrou n° 3)
  user_id     text NOT NULL,
  texte       text NOT NULL,
  tokens_in   integer,
  tokens_out  integer,
  creele      timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS appels_llm (
  id           bigserial PRIMARY KEY,
  user_id      text NOT NULL,
  model        text NOT NULL,
  tokens_in    integer NOT NULL DEFAULT 0,
  tokens_out   integer NOT NULL DEFAULT 0,
  tokens_cache integer NOT NULL DEFAULT 0,
  cout_usd     numeric(12, 6) NOT NULL DEFAULT 0,
  creele       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS appels_llm_user_creele ON appels_llm (user_id, creele);
```

```bash
psql "postgres://compta:motdepasse@localhost:5432/compta" -f db/init.sql   # relançable : IF NOT EXISTS partout
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `documents` contient les textes à résumer ; son identifiant est un **UUID** (`gen_random_uuid()`, intégré à PostgreSQL depuis la version 13), car la route `/api/jobs` refuse tout autre format. Dans `resumes`, `document_id` est la clé primaire : un document ne peut avoir qu'un résumé, c'est le verrou d'unicité côté base décrit en section 2. `appels_llm` reçoit une ligne par appel au modèle (tokens, coût en dollars, date `creele`) ; l'index sur `(user_id, creele)` accélère le calcul des quotas de la section 3.2. Pour un essai, insérez un document (`INSERT INTO documents (nom, texte) VALUES ('liasse-test', '…') RETURNING id;`) et réutilisez l'UUID renvoyé.

Exemple complet :

```typescript
// src/lib/queue.ts — file d'attente pg-boss partagée entre l'app et le worker
import PgBoss from "pg-boss";

export const boss = new PgBoss({ connectionString: process.env.DATABASE_URL! });
export const QUEUE_RESUME = "resume-document";

export async function demarrerQueue() {
  await boss.start();
  await boss.createQueue(QUEUE_RESUME);     // idempotent : ne recrée pas si elle existe
  return boss;
}
```

```typescript
// src/app/api/jobs/route.ts — enregistre une tâche de résumé et répond 202
import { z } from "zod";
import { demarrerQueue, QUEUE_RESUME } from "@/lib/queue";
import { getSession } from "@/lib/auth";

export async function POST(req: Request) {
  const session = await getSession(req);
  if (!session) return new Response("Non authentifié", { status: 401 });

  const body = z.object({ documentId: z.string().uuid() }).safeParse(await req.json());
  if (!body.success) return new Response("Requête invalide", { status: 400 });

  const boss = await demarrerQueue();
  const jobId = await boss.send(
    QUEUE_RESUME,
    { documentId: body.data.documentId, userId: session.userId },
    {
      singletonKey: `resume:${body.data.documentId}`, // idempotence : un seul job par document
      retryLimit: 3, retryDelay: 30, retryBackoff: true,
      expireInSeconds: 120,                           // timeout d'exécution du job
    },
  );
  return Response.json({ jobId }, { status: 202 });
}
```

```typescript
// worker.ts — processus séparé : `npx tsx --env-file=.env.local worker.ts` (ou un service Docker dédié)
import { generateText } from "ai";
import { anthropic } from "@ai-sdk/anthropic";
import { Pool } from "pg";
import { demarrerQueue, QUEUE_RESUME } from "./src/lib/queue";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function main() {
  const boss = await demarrerQueue();
  await boss.work(QUEUE_RESUME, { batchSize: 1 }, async ([job]) => {
    const { documentId, userId } = job.data as { documentId: string; userId: string };

    // Idempotence côté résultat : si déjà résumé, on ne rappelle pas le LLM
    const deja = await pool.query("SELECT 1 FROM resumes WHERE document_id = $1", [documentId]);
    if (deja.rowCount) return;

    const { rows } = await pool.query("SELECT texte FROM documents WHERE id = $1", [documentId]);
    const { text, usage } = await generateText({
      model: anthropic("claude-haiku-5-5"),      // tâche simple → modèle économique
      system: "Résumez ce document comptable en 5 points, en français.",
      prompt: rows[0].texte.slice(0, 200_000),   // garde-fou de taille
      maxOutputTokens: 400,
      abortSignal: AbortSignal.timeout(90_000),  // timeout de l'appel LLM (90 s)
    });

    await pool.query(
      "INSERT INTO resumes (document_id, user_id, texte, tokens_in, tokens_out) VALUES ($1,$2,$3,$4,$5)",
      [documentId, userId, text, usage.inputTokens, usage.outputTokens],
    );
  });
  console.log("Worker prêt.");
}
main().catch((e) => { console.error(e); process.exit(1); });
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `queue.ts` : `new PgBoss({ connectionString })` crée la file **dans votre base PostgreSQL** (pg-boss y crée ses propres tables) ; `boss.start()` la démarre et `createQueue(QUEUE_RESUME)` déclare la file nommée `resume-document`.
> - `route.ts` : après l'authentification et la validation (`z.string().uuid()` exige un identifiant au format UUID), `boss.send(file, données, options)` **enregistre** la tâche sans l'exécuter et renvoie son identifiant ; la réponse HTTP **202** signifie « accepté, traitement en cours ». Options : `singletonKey` (un seul job par document), `retryLimit` / `retryDelay` / `retryBackoff` (trois nouvelles tentatives, délai croissant), `expireInSeconds` (durée maximale d'un job).
> - `worker.ts` : un programme **séparé**, qui tourne en continu ; contrairement à `npm run dev`, `tsx` ne lit pas `.env.local` de lui-même, d'où l'option `--env-file=.env.local` de la commande ; `boss.work(file, { batchSize: 1 }, async ([job]) => {...})` reçoit les jobs un par un (`[job]` extrait le premier élément du tableau reçu).
> - Dans le worker : on vérifie d'abord si le résumé existe (`SELECT 1 …`, idempotence), on lit le document, on appelle Haiku avec une taille d'entrée bornée (`slice(0, 200_000)`) et un délai maximal (`AbortSignal.timeout(90_000)`), puis on enregistre résumé et tokens.
>
> 🛠️ **Si ça ne marche pas** —
> - Le worker plante avec une erreur de connexion, ou `DATABASE_URL` vaut `undefined` → vous l'avez lancé sans `--env-file=.env.local` (seul Next.js lit ce fichier tout seul), ou depuis un autre dossier que la racine du projet → relancez `npx tsx --env-file=.env.local worker.ts` depuis `compta-chat/`.
> - `relation "resumes" does not exist` (ou `documents`, `appels_llm`) → ces tables métier ne sont pas créées par pg-boss → exécutez `db/init.sql` (début de la section) sur la base de `DATABASE_URL`.
> - `TypeError: PgBoss is not a constructor` ou erreur sur `createQueue` / `work` → la forme d'import ou la signature diffère selon la version majeure de pg-boss → `npm ls pg-boss`, puis reprenez les exemples du README de cette version.
> - La route renvoie 202 mais rien ne se passe → aucun worker ne tourne → lancez-le dans un second terminal et laissez-le ouvert.
> - Un second envoi du même document crée quand même un job → le comportement de `singletonKey` dépend de l'état du premier job (en attente, actif, terminé) et de la politique de la file → c'est pourquoi le worker vérifie aussi `resumes` avant d'appeler le modèle.

> 💡 **À retenir** — Une file d'attente apporte trois choses que le route handler ne peut pas offrir : la **persistance** (la tâche survit à un redéploiement), les **reprises** automatiques et le **lissage** de charge face aux limites du fournisseur.

```quiz
{
  "q": "Le cabinet veut produire chaque nuit 300 résumés de liasses fiscales. Quelle architecture choisissez-vous ?",
  "options": [
    "Un route handler avec maxDuration poussé à 3 600 secondes",
    "Un cron qui appelle /api/chat 300 fois de suite",
    "Une file d'attente et un worker, voire la Batch API",
    "300 onglets de navigateur ouverts sur useChat"
  ],
  "answer": 2,
  "explanation": "Au-delà de 10 secondes, on passe par une file : la tâche survit aux redéploiements, se rejoue en cas d'échec, et la Batch API divise le prix par deux quand la réponse peut attendre. Le worker tourne à part, hors des route handlers."
}
```

## 2. Idempotence : ne payez jamais deux fois

Un job peut être rejoué : le worker a planté après l'appel LLM mais avant l'écriture en base, le réseau a coupé, l'utilisateur a double-cliqué. Sans précaution, chaque rejeu refacture l'appel. Trois verrous complémentaires, visibles dans le code ci-dessus :

1. **Clé d'unicité à l'enfilement** (`singletonKey` pg-boss, `jobId` BullMQ) : deux demandes pour le même document donnent un seul job.
2. **Vérification avant l'appel** : si le résultat existe déjà, on sort.
3. **Écriture atomique** : résultat et marqueur « traité » dans la même transaction (ou une contrainte `UNIQUE (document_id)` qui rejette le doublon).

Côté fournisseur, l'**idempotence n'est pas garantie** : deux appels identiques sont deux appels facturés. C'est votre couche qui doit l'assurer.

> 💡 **Autrement dit** — « Idempotent » signifie : faire la même chose deux fois donne le même résultat qu'une seule fois. Comme le bouton d'un ascenseur : appuyer cinq fois n'appelle pas cinq cabines. Votre code doit se comporter ainsi, car le fournisseur, lui, facture chaque appel.

```quiz
{
  "q": "Si un job est rejoué après un crash, le fournisseur LLM reconnaît le doublon et ne facture pas le second appel.",
  "type": "vrai_faux",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Deux appels identiques sont deux appels facturés. Clé d'unicité, vérification avant l'appel et écriture atomique sont à votre charge."
}
```

## 3. Limites : les leurs et les vôtres

### 3.1 Les limites du fournisseur

Anthropic documente sur [Rate limits](https://platform.claude.com/docs/en/api/rate-limits) un système de paliers (Evaluation, Start, Build, Scale avec des plafonds de dépenses mensuels de 500 $, 1 000 $ et 200 000 $, Custom) avec des limites en requêtes/minute et tokens/minute, un algorithme de *token bucket* (le crédit se reconstitue en continu, pas d'un coup) et des en-têtes `anthropic-ratelimit-*` qui indiquent la capacité restante et la date de réinitialisation. Dépasser donne un **429**, avec un en-tête `retry-after`. OpenAI fonctionne sur le même principe (page [Rate limits](https://developers.openai.com/api/docs/guides/rate-limits)). Pour les charges critiques, Anthropic propose un [Priority Tier](https://platform.claude.com/docs/en/api/service-tiers) à capacité réservée.

> 💡 **Autrement dit** — Le *token bucket* (seau à jetons) : imaginez un seau qui se remplit goutte à goutte, en continu ; chaque requête y puise. Seau vide : réponse 429 « revenez plus tard », et l'en-tête `retry-after` dit combien de secondes attendre. Le *rate limiting*, c'est le videur de boîte de nuit : il ne juge pas vos intentions, il compte.

```mission
{
  "title": "Lire les en-têtes de limites d'Anthropic",
  "url": "https://platform.claude.com/docs/en/api/rate-limits",
  "steps": [
    "Ouvrez la page Rate limits de la documentation Claude",
    "Descendez jusqu'à la section sur les en-têtes de réponse (response headers)",
    "Repérez aussi l'en-tête renvoyé avec une erreur 429"
  ],
  "question": "Quel préfixe portent les en-têtes qui indiquent la capacité restante, et quel en-tête dit combien de temps attendre après un 429 ?",
  "hint": "Le préfixe commence par le nom de l'éditeur.",
  "answer": "Les en-têtes `anthropic-ratelimit-*` (requêtes et tokens restants, date de réinitialisation) ; après un 429, l'en-tête `retry-after` donne le délai en secondes (page consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

Votre worker doit donc : lire les en-têtes, respecter `retry-after`, et limiter la **concurrence** (pg-boss `batchSize` et nombre de workers ; BullMQ `limiter: { max: 50, duration: 60_000 }`). Un backoff exponentiel avec jitter (30 s, 60 s, 120 s ± aléa) évite que tous les workers repartent en même temps.

### 3.2 Vos propres limites : par utilisateur et globales

Le fournisseur vous protège de vous-même ; rien ne vous protège d'un utilisateur. Deux compteurs minimum, stockés en Postgres (ou Redis) pour survivre aux redémarrages et être partagés entre instances :

```typescript
// src/lib/quotas.ts — quota journalier de tokens par utilisateur + budget global mensuel
import { Pool } from "pg";
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const QUOTA_TOKENS_JOUR = 200_000;         // par utilisateur
const BUDGET_MENSUEL_USD = 300;            // pour toute l'application

export async function verifierQuotas(userId: string) {
  const { rows } = await pool.query(
    `SELECT
       COALESCE(SUM(cout_usd) FILTER (WHERE date_trunc('month', creele) = date_trunc('month', now())), 0) AS mois_usd,
       COALESCE(SUM(tokens_in + tokens_out) FILTER (WHERE user_id = $1 AND creele > now() - interval '1 day'), 0) AS user_tokens
     FROM appels_llm`, [userId]);
  if (Number(rows[0].mois_usd) >= BUDGET_MENSUEL_USD) throw new Error("BUDGET_EPUISE");
  if (Number(rows[0].user_tokens) >= QUOTA_TOKENS_JOUR) throw new Error("QUOTA_UTILISATEUR");
}

// Prix nov. 2026 (page Pricing Anthropic), $/MTok : [entrée, sortie, lecture cache]
const PRIX: Record<string, [number, number, number]> = {
  "claude-sonnet-5-5": [2, 10, 0.10],
  "claude-haiku-5-5":  [0.10, 0.50, 0.01],
  "claude-opus-5-5":   [4, 20, 0.20],
};

export function coutUsd(model: string, tokensIn: number, tokensOut: number, cacheRead = 0) {
  const [pIn, pOut, pCache] = PRIX[model] ?? [10, 50, 0.25];   // défaut prudent (tarif Fable 5.1)
  return ((tokensIn - cacheRead) * pIn + cacheRead * pCache + tokensOut * pOut) / 1e6;
}

export async function journaliser(userId: string, model: string, usage: { inputTokens?: number; outputTokens?: number; cachedInputTokens?: number }) {
  const tin = usage.inputTokens ?? 0, tout = usage.outputTokens ?? 0, cache = usage.cachedInputTokens ?? 0;
  await pool.query(
    "INSERT INTO appels_llm (user_id, model, tokens_in, tokens_out, tokens_cache, cout_usd) VALUES ($1,$2,$3,$4,$5,$6)",
    [userId, model, tin, tout, cache, coutUsd(model, tin, tout, cache)]);
}
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `verifierQuotas` fait **une seule** requête SQL qui calcule deux totaux : `SUM(cout_usd) FILTER (WHERE …)` additionne seulement les lignes du mois en cours (`date_trunc('month', …)` ramène une date au premier jour de son mois), et la seconde somme ne compte que les tokens de cet utilisateur sur les dernières 24 heures ; `COALESCE(…, 0)` remplace « aucune ligne » par 0. Si l'un des plafonds est atteint, la fonction **lève une erreur** (`BUDGET_EPUISE` ou `QUOTA_UTILISATEUR`) : le route handler doit l'attraper (`try … catch`) pour répondre 402 ou 429. `coutUsd` applique les prix (avec un tarif par défaut **élevé** pour un modèle inconnu, par prudence), et `journaliser` écrit une ligne par appel dans `appels_llm`, table à créer avec les colonnes `user_id`, `model`, `tokens_in`, `tokens_out`, `tokens_cache`, `cout_usd` et `creele` (date de création, valeur par défaut `now()`).

Dans le route handler de L101, appelez `verifierQuotas(session.userId)` avant `streamText` (renvoyez 429 ou 402 selon l'erreur) et `journaliser(...)` dans `onFinish`. La table `appels_llm` est aussi la matière première du tableau de bord de L103.

> ⚠️ **Piège fréquent** — Compter les **requêtes** au lieu des **tokens**. Un utilisateur qui colle un PDF de 150 pages dans chaque message consomme 1 000 fois plus qu'un autre à nombre de requêtes égal. Le quota pertinent est en tokens (ou en euros), et il se vérifie **avant** l'appel.

### 3.3 Timeouts à chaque étage

| Étage | Mécanisme | Valeur typique |
|---|---|---|
| Appel LLM | `abortSignal: AbortSignal.timeout(ms)` | 60-90 s (plus pour les tâches de raisonnement) |
| Job | `expireInSeconds` (pg-boss) / `timeout` (BullMQ) | 2-5 min |
| Route handler | `export const maxDuration` | 60 s (Vercel) ; côté Caddy `reverse_proxy` avec `transport http { response_header_timeout 90s }` |
| Requête client | `AbortController` côté React, bouton Stop | géré par `useChat().stop()` |

## 4. Les quatre leviers de coût

### 4.1 Prompt caching (−90 % sur le préfixe stable)

Compta-Chat envoie à chaque message le même system prompt, les mêmes définitions d'outils et, en L105, un mémento de 30 000 tokens. La page [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) (nov. 2026) : préfixe minimal de 512 tokens sur les modèles 5.5, TTL 5 min rafraîchi gratuitement à chaque lecture (ou 1 h en option), écriture facturée ×1,25, lecture à 0,10 $/MTok pour Sonnet 5.5 (soit 20 fois moins que l'entrée normale). Avec le Vercel AI SDK, le point de rupture se pose via `providerOptions` :

```typescript
// Mise en cache du mémento (bloc system) avec le fournisseur Anthropic du Vercel AI SDK
const result = streamText({
  model: anthropic("claude-sonnet-5-5"),
  messages: [
    {
      role: "system",
      content: `${SYSTEM}\n<memento>${MEMENTO}</memento>`,          // ≥ 512 tokens
      providerOptions: { anthropic: { cacheControl: { type: "ephemeral" } } },
    },
    ...(await convertToModelMessages(messages)),
  ],
  tools: { rechercherClient, echeanceTva },
});
// result.providerMetadata.anthropic.cacheReadInputTokens indique ce qui a été lu depuis le cache
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Le prompt système et le mémento sont placés dans un message de rôle `system`, en **tête** de la liste, suivi de l'historique converti (`...` déverse les messages). `providerOptions: { anthropic: { cacheControl: { type: "ephemeral" } } }` est la façon, propre au Vercel AI SDK, de poser l'étiquette `cache_control` de L073 sur ce bloc. Vérifiez l'effet dans `result.providerMetadata.anthropic.cacheReadInputTokens` à partir du deuxième appel ; une valeur nulle signifie que le bloc fait moins de 512 tokens ou qu'il change d'un appel à l'autre.

OpenAI applique un cache automatique sur les préfixes (prix « cached input », par exemple 0,05 $ contre 1 $ pour GPT-6.1 Terra, nov. 2026, page [Pricing](https://developers.openai.com/api/docs/pricing)) : la seule règle est de placer la partie stable **au début** du prompt.

```quiz
{
  "q": "Pour profiter du prompt caching, où placer la partie stable du prompt (system prompt, outils, mémento) ?",
  "options": [
    "Au début, avant tout ce qui change d'une requête à l'autre",
    "À la fin, juste après la question de l'utilisateur",
    "N'importe où : le cache repère seul les passages identiques",
    "Dans un fichier joint envoyé à part"
  ],
  "answer": 0,
  "explanation": "Le cache porte sur un préfixe : tout ce qui précède le point de rupture doit être identique d'un appel à l'autre. OpenAI applique la même règle à son cache automatique."
}
```

```mission
{
  "title": "Taille minimale et durée de vie du cache",
  "url": "https://platform.claude.com/docs/en/build-with-claude/prompt-caching",
  "steps": [
    "Ouvrez la page Prompt caching",
    "Cherchez le tableau de la longueur minimale cacheable par modèle",
    "Repérez la durée de vie (TTL) par défaut et l'option longue"
  ],
  "question": "Quelle est la longueur minimale d'un préfixe cacheable sur les modèles 5.5, et quelle est la durée de vie par défaut du cache ?",
  "hint": "Cherchez « minimum cacheable » et « 5-minute ».",
  "answer": "512 tokens sur les modèles 5.5 ; TTL de 5 minutes par défaut, rafraîchi à chaque lecture, ou 1 heure en option (nov. 2026, vérifiez : ces valeurs changent selon les modèles) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

### 4.2 Cache sémantique (−100 % sur les questions déjà posées)

Cinquante collaborateurs posent chaque matin des variantes de « quelle est la date limite de la CA3 ? ». Un cache sémantique stocke les paires (embedding de la question, réponse) dans pgvector et renvoie la réponse existante si une question **proche** a déjà été traitée :

```sql
-- Table de cache sémantique (pgvector ; dimension selon le modèle d'embedding choisi)
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE cache_semantique (
  id bigserial PRIMARY KEY,
  question text NOT NULL,
  reponse text NOT NULL,
  embedding vector(1024) NOT NULL,
  creele timestamptz DEFAULT now()
);
CREATE INDEX ON cache_semantique USING hnsw (embedding vector_cosine_ops);
```

```typescript
// src/lib/cache-semantique.ts — lecture / écriture ; seuil de similarité à régler sur vos données
import { embed } from "ai";
import { mistral } from "@ai-sdk/mistral";          // ou openai.textEmbeddingModel(...)
import { Pool } from "pg";
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const SEUIL = 0.92;                                 // cosinus ; au-dessous, on rappelle le LLM

async function vecteur(texte: string) {
  const { embedding } = await embed({ model: mistral.textEmbeddingModel("mistral-embed"), value: texte });
  return `[${embedding.join(",")}]`;
}

export async function lireCache(question: string) {
  const v = await vecteur(question);
  const { rows } = await pool.query(
    `SELECT reponse, 1 - (embedding <=> $1::vector) AS similarite
       FROM cache_semantique
      WHERE creele > now() - interval '7 days'
      ORDER BY embedding <=> $1::vector LIMIT 1`, [v]);
  return rows[0] && rows[0].similarite >= SEUIL ? (rows[0].reponse as string) : null;
}

export async function ecrireCache(question: string, reponse: string) {
  await pool.query("INSERT INTO cache_semantique (question, reponse, embedding) VALUES ($1,$2,$3::vector)",
    [question, reponse, await vecteur(question)]);
}
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `vecteur(texte)` calcule l'embedding de la question avec la fonction `embed` du Vercel AI SDK, puis l'écrit au format texte attendu par pgvector (`[0.12,-0.5,…]`). `lireCache` cherche la question **la plus proche** parmi celles des 7 derniers jours (`ORDER BY embedding <=> $1::vector LIMIT 1`) et ne renvoie sa réponse que si la similarité dépasse le seuil de 0,92 ; sinon `null`, et l'application appelle le modèle. `ecrireCache` enregistre la nouvelle paire question / réponse.
>
> 🛠️ **Si ça ne marche pas** — `Cannot find module '@ai-sdk/mistral'` → l'installation du début de la leçon a été sautée → `npm install @ai-sdk/mistral`. Erreur d'authentification Mistral → ajoutez `MISTRAL_API_KEY=…` dans `.env.local` et relancez le serveur. La table `cache_semantique` n'existe pas → exécutez le bloc SQL ci-dessus comme `db/init.sql` (avec `psql -f`). `expected 1024 dimensions` → la colonne `vector(1024)` doit avoir la dimension du modèle d'embedding choisi (L089). Le cache ne sert jamais → le seuil est trop haut pour votre modèle : affichez la similarité de quelques reformulations d'une même question, puis réglez `SEUIL` ; à l'inverse, un seuil trop bas sert de mauvaises réponses, d'où les deux garde-fous ci-dessous.

Deux garde-fous : n'utilisez le cache sémantique que pour les questions **sans contexte personnel** (une réponse sur le dossier de la SARL Dupont ne doit pas être servie à une question sur la SAS Martin, même si les phrases se ressemblent) ; et ne mettez jamais en cache une réponse issue d'un appel d'outil dont le résultat change (soldes, dates du jour).

### 4.3 Batch (−50 %) pour tout ce qui n'est pas interactif

Les 300 résumés nocturnes n'ont pas besoin d'une réponse en 8 secondes. La [Message Batches API](https://platform.claude.com/docs/en/build-with-claude/batch-processing) d'Anthropic traite jusqu'à 100 000 requêtes par lot, généralement en moins d'une heure (24 h max), pour **la moitié du prix** ; OpenAI offre la même remise via [Batch](https://developers.openai.com/api/docs/guides/batch). Le worker devient alors un **assembleur de lot** : il regroupe les jobs de la nuit, soumet un seul batch, puis redistribue les résultats. La leçon L073 détaille l'API ; ici, retenez le critère de décision : *latence tolérée > 1 h → batch*.

### 4.4 Le bon modèle au bon endroit

Pour un cabinet de 50 personnes, 2 000 conversations par jour de 3 tours en moyenne, 1 500 tokens d'entrée et 300 de sortie par tour (nov. 2026, prix Pricing Anthropic) :

| Scénario | Calcul | Coût mensuel (22 jours) |
|---|---|---|
| Tout en Sonnet 5.5, sans cache | 6 000 tours × (1 500 × 2 + 300 × 10) / 1e6 = 36 $/jour | **792 $** |
| Sonnet 5.5 + prompt caching (1 200 tokens stables lus à 0,10 $) | 6 000 × (300 × 2 + 1 200 × 0,10 + 300 × 10) / 1e6 = 22,3 $/jour | **491 $** |
| Routage : 70 % Haiku 5.5, 30 % Sonnet 5.5, avec cache | 0,7 × 6 000 × (300 × 0,10 + 1 200 × 0,01 + 300 × 0,5) / 1e6 + 0,3 × 22,3 = 0,8 + 6,7 $/jour | **165 $** |

Le routage (un classifieur Haiku qui envoie les questions complexes vers Sonnet) divise la facture par presque cinq sans toucher à l'interface. C'est précisément ce que les évaluations de L103 permettent de vérifier : la qualité ne doit pas baisser sur votre jeu de test.

> 🔗 **Documentation officielle** — [Rate limits](https://platform.claude.com/docs/en/api/rate-limits) · [Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) · [Batch processing](https://platform.claude.com/docs/en/build-with-claude/batch-processing) · [pg-boss](https://github.com/timgit/pg-boss) · [BullMQ](https://docs.bullmq.io)

🎮 **Défi** — Votre budget mensuel est fixé à 300 $. Avec le scénario « routage » ci-dessus, combien de conversations supplémentaires par jour pouvez-vous absorber avant de le dépasser ? Et si le cabinet ajoute un mémento de 30 000 tokens dans le system prompt, quel scénario reste sous les 300 $ ?

## 🧪 Exercice pratique

**Consigne.** Ajoutez à Compta-Chat une fonctionnalité « Résumer mes documents » :
1. une route `POST /api/jobs` qui enfile un job par document sélectionné (idempotent par `documentId`) ;
2. un worker pg-boss qui résume avec `claude-haiku-5-5`, journalise l'usage dans `appels_llm` et respecte un timeout de 90 s ;
3. une route `GET /api/jobs/:id` qui renvoie l'état (`created`, `active`, `completed`, `failed`) via `boss.getJobById` ;
4. une vérification de quota par utilisateur (200 000 tokens/jour) et de budget global (300 $/mois) **avant** l'enfilement.

**Critères de réussite.**
- Soumettre deux fois le même document ne crée qu'un seul job et un seul appel LLM (vérifiez dans `appels_llm`).
- Tuer le worker pendant un traitement (`Ctrl+C`) puis le relancer reprend le job sans perte.
- Un utilisateur ayant dépassé son quota reçoit un 429 et aucun job n'est créé.
- `SELECT SUM(cout_usd) FROM appels_llm` correspond, à 5 % près, au tableau de bord Usage de la console du fournisseur après une journée de test.

**Pistes de corrigé.** Pour l'état, pg-boss expose `boss.getJobById(queue, id)` qui renvoie `state`. Pour tester la reprise, mettez `retryLimit: 3` et faites planter volontairement le worker avec `throw new Error("test")` sur le premier essai. Pour la cohérence des coûts, comparez avec la page Usage de la console Anthropic ou l'Usage & Cost Analytics API (beta, oct. 2026).

## ✅ Auto-évaluation express

1. Citez deux raisons pour lesquelles un traitement de 300 documents ne doit pas s'exécuter dans un route handler.
2. Quel champ de `usage` faut-il lire pour vérifier que le prompt caching fonctionne ?
3. Pourquoi un cache sémantique est-il dangereux pour des questions portant sur un dossier client précis ?

**Réponses.** 1. Durée au-delà de `maxDuration` / du timeout HTTP ; perte de la tâche en cas de redéploiement ou de crash ; impossibilité de reprendre et de lisser la charge. 2. Les tokens lus depuis le cache (`cache_read_input_tokens` dans l'API Anthropic, exposés par le SDK via `providerMetadata.anthropic.cacheReadInputTokens` ou `usage.cachedInputTokens`) : ils doivent être non nuls à partir du deuxième appel. 3. Deux questions formulées de façon proche mais portant sur des clients différents peuvent dépasser le seuil de similarité : on servirait la réponse d'un client à un autre (fuite de données et réponse fausse).

> ✅ **Si vous ne retenez que 3 choses** — 1. Au-delà de 10 secondes ou d'un appel par requête, passez par une file d'attente (pg-boss sur PostgreSQL, ou BullMQ sur Redis) : la route répond 202, un worker séparé traite, avec reprises et délais maximaux. 2. Rendez tout rejouable sans double facturation (clé d'unicité, vérification avant l'appel, contrainte `UNIQUE`) et posez vos propres limites, comptées en tokens ou en euros et vérifiées **avant** l'appel : quota par utilisateur, budget global, timeouts à chaque étage. 3. Les quatre leviers de coût : prompt caching du préfixe stable, cache sémantique pour les questions génériques, batch à −50 % pour le non-urgent, et le bon modèle au bon endroit (routage Haiku / Sonnet).

## 📚 Pour aller plus loin
- [Claude Platform — Rate limits](https://platform.claude.com/docs/en/api/rate-limits) 🇬🇧 — paliers, token bucket, en-têtes `anthropic-ratelimit-*`.
- [Claude Platform — Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 — règles, prix, points de rupture, diagnostics.
- [OpenAI — Batch](https://developers.openai.com/api/docs/guides/batch) 🇬🇧 — traitement asynchrone à −50 % côté OpenAI.
- [pg-boss](https://github.com/timgit/pg-boss) 🇬🇧 et [BullMQ](https://docs.bullmq.io) 🇬🇧 — les deux files d'attente de référence en Node.js.
- [pgvector](https://github.com/pgvector/pgvector) 🇬🇧 — opérateurs de distance et index HNSW utilisés par le cache sémantique.

> 🗺️ **Et maintenant ?** — En L103, vous allez enfin voir ce qui se passe à l'intérieur de chaque appel : traces, latence, coût et qualité, grâce à l'observabilité et aux évaluations.
