---
id: L101
module: M22
level: N3
title: "Next.js et Vercel AI SDK : chat en streaming"
minutes: 60
objectives:
  - "Expliquer pourquoi le streaming est indispensable dans une interface LLM et comment il circule du fournisseur jusqu'au navigateur"
  - "Construire un chat complet avec Next.js 16 (App Router), TypeScript et le Vercel AI SDK : route handler, hook useChat, outils exécutés côté serveur"
  - "Sécuriser la route : authentification, limite de taille des messages, validation des entrées, clé API en variable d'environnement"
  - "Changer de fournisseur (Anthropic, OpenAI, Mistral, xAI) sans réécrire l'interface"
skills: ["C3.5", "C3.1"]
sources:
  - { title: "Vercel AI SDK — documentation", url: "https://ai-sdk.dev", lang: "en" }
  - { title: "Next.js — documentation (App Router, Route Handlers)", url: "https://nextjs.org/docs", lang: "en" }
  - { title: "Claude Platform — Streaming Messages", url: "https://platform.claude.com/docs/en/build-with-claude/streaming", lang: "en" }
  - { title: "OpenAI — Streaming responses", url: "https://developers.openai.com/api/docs/guides/streaming-responses", lang: "en" }
  - { title: "Claude Platform — Client SDKs (TypeScript 1.3.0)", url: "https://platform.claude.com/docs/en/cli-sdks-libraries/overview", lang: "en" }
  - { title: "xAI — Quickstart (option Vercel AI SDK)", url: "https://docs.x.ai/developers/quickstart", lang: "en" }
  - { title: "Claude Platform — Reduce latency", url: "https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency", lang: "en" }
---

# Next.js et Vercel AI SDK : chat en streaming

> ⏱ 60 min · 🎯 Niveau 3 · 📚 Module 22

## 🎯 Ce que vous saurez faire
- Expliquer, schéma à l'appui, le trajet d'un token depuis l'API du fournisseur jusqu'au composant React, et pourquoi une réponse « en bloc » est inacceptable pour un utilisateur.
- Mettre en place un chat complet et déployable : route handler `app/api/chat/route.ts`, hook `useChat`, outils (tools) exécutés sur le serveur, affichage des étapes intermédiaires.
- Protéger la route : authentification, plafond de taille du message et de l'historique, validation Zod, clé API jamais exposée au navigateur.
- Changer de modèle ou de fournisseur en modifiant **une seule ligne**.

> 🧭 **En clair** — Une application de chat IA fonctionne comme un restaurant : le navigateur est la salle, votre serveur Next.js est le serveur en salle, et le fournisseur (Anthropic, OpenAI…) est la cuisine. Le client ne va jamais en cuisine, sinon il verrait la caisse : votre clé API. Le *streaming*, c'est le serveur qui apporte chaque plat dès qu'il sort, au lieu d'attendre que toute la table soit prête : la réponse s'affiche mot à mot. Le Vercel AI SDK est la boîte à outils qui fait ce travail de serveur pour vous, quelle que soit la cuisine choisie. Votre rôle : vérifier qui entre (authentification) et limiter la taille des commandes (plafonds).

## 1. Pourquoi le streaming n'est pas un luxe

Imaginez un serveur dans un restaurant qui attendrait que **tous** les plats de la table soient prêts avant d'apporter le premier. C'est ce que fait une API LLM sans streaming : le modèle génère 600 tokens à 80 tokens/s, soit 7,5 secondes de silence total, puis tout arrive d'un coup. Avec le streaming, le premier mot apparaît en moins d'une seconde et l'utilisateur lit pendant que le modèle écrit. Le temps total est identique ; la **perception** est radicalement différente. La métrique qui compte s'appelle le *time to first token* (TTFT) : c'est elle que vous surveillerez en L103.

Techniquement, les fournisseurs envoient la réponse sous forme d'événements **Server-Sent Events (SSE)**. Chez Anthropic, la séquence est documentée sur la page [Streaming Messages](https://platform.claude.com/docs/en/build-with-claude/streaming) : `message_start` → `content_block_start` → une série de `content_block_delta` (avec des deltas `text_delta`, `input_json_delta` pour les arguments d'outils, `thinking_delta` pour le raisonnement) → `content_block_stop` → `message_delta` (qui porte le `stop_reason` et l'usage) → `message_stop`. OpenAI expose un mécanisme équivalent via `stream: true` sur la Responses API (événements `response.output_text.delta`, voir [Streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses)).

> 💡 **Autrement dit** — SSE (*Server-Sent Events*) est un « tuyau » HTTP qui reste ouvert : le serveur y pousse de petits messages au fil de l'eau. Chaque message dit « voici trois mots de plus », « je commence un appel d'outil » ou « j'ai fini, voici le nombre de tokens ». Vous n'avez pas à manipuler ces messages vous-même : le SDK les assemble.

Dans une application web, le flux traverse **trois** étapes :

```
Fournisseur (SSE)  ──►  Votre serveur Next.js (route handler)  ──►  Navigateur (useChat)
   claude-sonnet-5-5       lit le flux, exécute les outils,          affiche les deltas,
   gpt-6.1-terra …         ajoute l'auth, les limites, les logs      les appels d'outils,
                           renvoie un flux "UI message stream"       les erreurs
```

Le navigateur ne parle **jamais** directement au fournisseur : la clé API resterait sinon visible dans l'onglet Réseau de n'importe quel visiteur. C'est tout l'intérêt du route handler intermédiaire, qui est aussi l'endroit où vous brancherez les files d'attente (L102), les traces (L103) et les feature flags (L104).

> 💡 **À retenir** — Le streaming ne raccourcit pas la génération, il raccourcit l'attente perçue. Le serveur intermédiaire protège la clé et centralise la logique métier.

```quiz
{
  "q": "Un collègue propose d'appeler l'API Anthropic directement depuis le composant React, « pour gagner une étape ». Quel est le problème principal ?",
  "options": [
    "Le streaming ne fonctionnerait plus dans un navigateur",
    "Le temps avant le premier token serait doublé",
    "Next.js bloque toute requête HTTP sortante côté client",
    "La clé API deviendrait lisible par n'importe quel visiteur"
  ],
  "answer": 3,
  "explanation": "Tout ce qui s'exécute dans le navigateur est visible (onglet Réseau, bundle). Le route handler garde la clé côté serveur et y ajoute auth, limites et journaux."
}
```

## 2. Le Vercel AI SDK en cinq concepts

Le [Vercel AI SDK](https://ai-sdk.dev) (paquet `ai`, licence Apache 2.0, nov. 2026) est une bibliothèque TypeScript qui unifie les fournisseurs derrière une API commune. Les cinq briques à connaître :

| Brique | Rôle | Où elle vit |
|---|---|---|
| **Fournisseurs** `@ai-sdk/anthropic`, `@ai-sdk/openai`, `@ai-sdk/mistral`, `@ai-sdk/xai`… | Adaptateur vers chaque API ; lit la clé dans `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, etc. | Serveur |
| `generateText` / `streamText` | Appel unique ou flux de tokens ; accepte `system`, `messages`, `tools`, `stopWhen` | Serveur |
| `tool()` + Zod | Déclare un outil typé : description, schéma d'entrée, fonction `execute` | Serveur |
| `UIMessage` / `toUIMessageStreamResponse()` | Format de message côté interface (texte, appels d'outils, résultats) et conversion du flux en réponse HTTP | Serveur → client |
| `useChat` (`@ai-sdk/react`) | Hook React : état des messages, statut, envoi, arrêt, gestion d'erreur | Navigateur |

Le point qui change tout par rapport à un appel SDK « brut » : la **boucle d'outils** est intégrée. Si le modèle demande un outil, le SDK l'exécute, renvoie le résultat au modèle et continue, jusqu'à la condition `stopWhen` (par exemple `stepCountIs(5)`). Chaque étape est diffusée au client au fur et à mesure.

> ⚠️ **Piège fréquent** — Le SDK évolue vite (la version 5 a changé les noms : `maxSteps` → `stopWhen`, `parameters` → `inputSchema`, `toDataStreamResponse` → `toUIMessageStreamResponse`). Vérifiez toujours la version installée avec `npm ls ai` et la page de migration correspondante sur ai-sdk.dev avant de copier un exemple trouvé en ligne.

```quiz
{
  "q": "Avec le Vercel AI SDK, quand le modèle demande un outil, c'est à vous d'écrire la boucle qui exécute l'outil puis renvoie le résultat au modèle.",
  "type": "vrai_faux",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "La boucle d'outils est intégrée : le SDK exécute l'outil, renvoie le résultat et continue jusqu'à la condition stopWhen (par exemple stepCountIs(5))."
}
```

## 3. Le projet : « Compta-Chat » pour un cabinet comptable

Fil rouge du module : un cabinet d'expertise comptable de Rennes veut un assistant interne qui répond aux collaborateurs sur les dossiers clients, avec deux outils : **rechercher un client** dans Postgres et **calculer une échéance de TVA**. Nous construisons l'interface ici, le backend robuste en L102, l'observabilité en L103, la chaîne de livraison en L104, et nous assemblons le tout en L105.

### 3.1 Initialisation

```bash
# Création du projet Next.js 16 (App Router, TypeScript, Tailwind) — nov. 2026
npx create-next-app@latest compta-chat --typescript --app --tailwind --eslint --src-dir
cd compta-chat
npm install ai @ai-sdk/react @ai-sdk/anthropic @ai-sdk/openai zod
npm install pg jose                # client Postgres (outil "rechercher un client") + jetons de session (section 4)
npm install -D @types/pg           # types TypeScript de pg (sinon `next build` refuse l'import)
cp .env.example .env.local 2>/dev/null || true
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `npx create-next-app@latest compta-chat …` crée le squelette du projet ; les options demandent TypeScript, le routeur « App Router » (`--app`), Tailwind pour le style, ESLint pour la qualité du code et un dossier `src/`. Les `npm install` ajoutent le Vercel AI SDK (`ai`, `@ai-sdk/react`), deux fournisseurs, Zod, le client PostgreSQL `pg`, la bibliothèque de jetons `jose` (section 4) et, en dépendance de développement (`-D`), les types TypeScript de `pg`. La dernière ligne copie un éventuel `.env.example` vers `.env.local` : `2>/dev/null || true` évite une erreur si ce fichier n'existe pas (L074).

Fichier `.env.local` (jamais commité ; ajoutez-le au `.gitignore`, ce que `create-next-app` fait déjà) :

```bash
ANTHROPIC_API_KEY=sk-ant-...      # clé lue par @ai-sdk/anthropic
OPENAI_API_KEY=sk-...             # facultatif : modèle de repli
DATABASE_URL=postgres://compta:motdepasse@localhost:5432/compta
AI_MODEL=claude-sonnet-5-5        # changez ici pour basculer de modèle
MAX_MESSAGE_CHARS=4000
MAX_HISTORY_MESSAGES=30
AUTH_SECRET=remplacez-moi-par-32-caracteres-aleatoires   # signe les cookies de session (section 4) : openssl rand -base64 32
```

> 🧭 **Pré-requis express — Next.js « App Router » en cinq règles** —
> - Ce sont les **dossiers** qui créent les adresses : `src/app/page.tsx` est la page d'accueil `/`, `src/app/api/chat/route.ts` répond à l'adresse `/api/chat`.
> - Un fichier `route.ts` qui exporte une fonction `POST` est un **route handler** : il s'exécute **sur le serveur** quand le navigateur envoie une requête POST à cette adresse.
> - Par défaut, un composant s'exécute sur le serveur ; la ligne `"use client";` en tête de fichier le fait tourner **dans le navigateur** (nécessaire pour les hooks React comme `useState` ou `useChat`).
> - `.env.local` est lu **au démarrage** de `npm run dev` : après toute modification, arrêtez (`Ctrl+C`) et relancez le serveur.
> - L'alias `@/` (comme dans `@/lib/auth`) désigne le dossier `src/` ; il est configuré par `create-next-app`.

Créez ensuite la table interrogée par l'outil « rechercher un client », dans un fichier `db/init.sql` que L102 complétera et que L105 réutilisera :

```sql
-- db/init.sql — table de l'outil rechercherClient (données fictives) ; L102 complétera ce fichier, L105 le réutilisera
CREATE TABLE IF NOT EXISTS clients (
  id             bigserial PRIMARY KEY,
  raison_sociale text NOT NULL,
  siren          text UNIQUE,              -- 9 chiffres
  regime_tva     text NOT NULL CHECK (regime_tva IN ('reel_normal_mensuel', 'reel_simplifie', 'franchise'))
);
INSERT INTO clients (raison_sociale, siren, regime_tva) VALUES
  ('SARL Dupont',            '000000001', 'reel_normal_mensuel'),
  ('SAS Martin Menuiserie',  '000000002', 'reel_simplifie'),
  ('EI Leroy Conseil',       '000000003', 'franchise')
ON CONFLICT (siren) DO NOTHING;
```

```bash
psql "postgres://compta:motdepasse@localhost:5432/compta" -f db/init.sql   # même adresse que DATABASE_URL
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `CREATE TABLE IF NOT EXISTS clients (…)` crée la table seulement si elle n'existe pas encore (relancer le script ne casse rien) ; `CHECK (regime_tva IN (…))` n'accepte que les trois régimes connus de l'outil `echeanceTva`. L'`INSERT` ajoute trois clients **fictifs** (SIREN `000000001`… manifestement inventés) ; `ON CONFLICT (siren) DO NOTHING` évite les doublons si vous relancez le fichier. `psql … -f db/init.sql` exécute le fichier sur la base de `DATABASE_URL` ; si PostgreSQL tourne dans Docker sans `psql` installé sur votre machine, lancez `docker exec -i <nom-du-conteneur> psql -U compta -d compta < db/init.sql`.

### 3.2 Le route handler : `src/app/api/chat/route.ts`

```typescript
// src/app/api/chat/route.ts — point d'entrée du chat (serveur uniquement)
import { anthropic } from "@ai-sdk/anthropic";
import { openai } from "@ai-sdk/openai";
import {
  streamText, convertToModelMessages, tool, stepCountIs,
  type UIMessage, type LanguageModel,
} from "ai";
import { z } from "zod";
import { Pool } from "pg";
import { getSession } from "@/lib/auth";          // voir section 4

export const runtime = "nodejs";     // "pg" a besoin de Node (pas de runtime Edge)
export const maxDuration = 60;       // secondes ; Vercel coupe la fonction au-delà

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ---- Choix du modèle en une ligne (AI_MODEL dans .env.local) ----
function choisirModele(): LanguageModel {
  const id = process.env.AI_MODEL ?? "claude-sonnet-5-5";
  return id.startsWith("gpt-") ? openai(id) : anthropic(id);
}

// ---- Outils exécutés côté serveur ----
const rechercherClient = tool({
  description: "Recherche un client du cabinet par nom ou SIREN. Retourne au plus 5 résultats.",
  inputSchema: z.object({
    requete: z.string().min(2).max(80).describe("Nom partiel ou SIREN (9 chiffres)"),
  }),
  execute: async ({ requete }) => {
    const { rows } = await pool.query(
      `SELECT id, raison_sociale, siren, regime_tva
         FROM clients
        WHERE raison_sociale ILIKE $1 OR siren = $2
        LIMIT 5`,
      [`%${requete}%`, requete],
    );
    return { resultats: rows };      // le SDK sérialise et renvoie au modèle
  },
});

const echeanceTva = tool({
  description: "Calcule la prochaine date limite de déclaration de TVA selon le régime.",
  inputSchema: z.object({
    regime: z.enum(["reel_normal_mensuel", "reel_simplifie", "franchise"]),
    dateReference: z.string().describe("Date ISO, ex. 2026-11-01"),
  }),
  execute: async ({ regime, dateReference }) => {
    const d = new Date(dateReference);
    if (regime === "franchise") return { echeance: null, commentaire: "Pas de déclaration de TVA en franchise en base." };
    if (regime === "reel_simplifie") {
      // CA12 : 2e jour ouvré suivant le 1er mai (simplification pédagogique)
      return { echeance: `${d.getFullYear() + (d.getMonth() >= 4 ? 1 : 0)}-05-03`, commentaire: "Déclaration annuelle CA12." };
    }
    // Réel normal mensuel : entre le 15 et le 24 du mois suivant (date retenue : 24, simplifiée)
    const suivant = new Date(d.getFullYear(), d.getMonth() + 1, 24);
    return { echeance: suivant.toISOString().slice(0, 10), commentaire: "CA3 mensuelle, date simplifiée : vérifier sur impots.gouv.fr." };
  },
});

const SYSTEM = `Vous êtes Compta-Chat, assistant interne d'un cabinet d'expertise comptable rennais.
Répondez en français, de façon concise. Utilisez les outils plutôt que d'inventer des données.
Si une information n'est pas dans les résultats d'outil, dites-le explicitement.`;

export async function POST(req: Request) {
  // 1. Authentification (section 4)
  const session = await getSession(req);
  if (!session) return new Response("Non authentifié", { status: 401 });

  // 2. Lecture et validation de la requête
  const body = await req.json().catch(() => null);
  const parsed = z.object({ messages: z.array(z.custom<UIMessage>()) }).safeParse(body);
  if (!parsed.success) return new Response("Requête invalide", { status: 400 });

  // 3. Limites de taille : nombre de messages et longueur du dernier message
  const maxHist = Number(process.env.MAX_HISTORY_MESSAGES ?? 30);
  const maxChars = Number(process.env.MAX_MESSAGE_CHARS ?? 4000);
  const messages = parsed.data.messages.slice(-maxHist);
  const dernier = messages.at(-1);
  const texteDernier = dernier?.parts
    .filter((p) => p.type === "text")
    .map((p) => (p as { text: string }).text)
    .join("") ?? "";
  if (texteDernier.length > maxChars) {
    return new Response(`Message trop long (max ${maxChars} caractères)`, { status: 413 });
  }

  // 4. Appel en streaming avec boucle d'outils
  const result = streamText({
    model: choisirModele(),
    system: SYSTEM,
    messages: await convertToModelMessages(messages),
    tools: { rechercherClient, echeanceTva },
    stopWhen: stepCountIs(5),          // au plus 5 allers-retours modèle ↔ outils
    maxOutputTokens: 1024,
    abortSignal: req.signal,           // l'utilisateur ferme l'onglet → on arrête de payer
    onFinish: ({ usage, finishReason }) => {
      // Point d'accroche pour L102 (coûts) et L103 (traces)
      console.log(JSON.stringify({ user: session.userId, usage, finishReason }));
    },
  });

  // 5. Conversion du flux en réponse HTTP "UI message stream"
  return result.toUIMessageStreamResponse();
}
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `export const runtime = "nodejs"` et `export const maxDuration = 60` : réglages lus par Next.js (et Vercel) pour cette route : environnement Node complet, durée maximale de 60 secondes.
> - `new Pool({ connectionString: process.env.DATABASE_URL })` : le réservoir de connexions PostgreSQL de L089, créé une fois au chargement du fichier.
> - `choisirModele()` : lit `AI_MODEL` et renvoie un modèle OpenAI si l'identifiant commence par `gpt-`, sinon un modèle Anthropic.
> - `tool({ description, inputSchema: z.object(...), execute })` : chaque outil déclare son schéma en Zod et sa fonction ; dans `rechercherClient`, `$1` et `$2` sont des paramètres SQL (jamais de collage de texte, donc pas d'injection SQL).
> - `POST(req)` : 1) vérifie la session (401 sinon) ; 2) lit le JSON et le valide avec `safeParse` (400 si invalide) ; 3) garde les 30 derniers messages (`slice(-maxHist)`) et refuse un dernier message trop long (413) ; 4) lance `streamText` avec les outils, `stopWhen: stepCountIs(5)`, un plafond de sortie et le signal d'annulation ; 5) renvoie le flux au navigateur.
> - `onFinish` : appelé à la fin, avec l'usage ; c'est ici que L102 et L103 brancheront coûts et traces.

Trois détails méritent attention. `abortSignal: req.signal` propage l'annulation : si l'utilisateur ferme la page, la requête vers le fournisseur est coupée et vous ne payez pas les tokens restants. `maxOutputTokens` borne la facture d'une réponse. Enfin, nous ne passons **pas** de `temperature` : les modèles Claude ≥ 4.7 renvoient une erreur 400 si ce paramètre est présent — et, depuis la version d'API `2026-10-21` (envoyée par défaut par les SDK Anthropic v2), `temperature`, `top_p` et `top_k` renvoient une erreur 400 **sur tous les modèles Claude**, même à leur valeur par défaut (voir la page [Using the Messages API](https://platform.claude.com/docs/en/build-with-claude/working-with-messages)), et le SDK le transmettrait tel quel.

> 🛠️ **Si ça ne marche pas** —
> - `Module not found: Can't resolve 'jose'` → la bibliothèque de la section 4 n'est pas installée → `npm install jose`.
> - Toutes les requêtes renvoient **401 Non authentifié** → normal tant qu'aucun cookie `session` n'existe : il n'y a pas encore de vraie page de connexion → en local, ouvrez une fois `http://localhost:3000/api/dev-login` (route de test de la section 4), qui pose le cookie puis vous renvoie sur le chat.
> - L'outil `rechercherClient` renvoie une erreur `relation "clients" does not exist` → `db/init.sql` n'a pas été exécuté sur **cette** base → relancez la commande `psql` de la section 3.1 avec exactement l'adresse de `DATABASE_URL`.
> - Les changements de `.env.local` semblent ignorés → le serveur de développement ne relit ce fichier qu'au démarrage → relancez `npm run dev`.
> - Erreurs de types sur `convertToModelMessages`, `toUIMessageStreamResponse` ou `stopWhen` → votre version du SDK n'est pas la 5 → `npm ls ai`, puis alignez-vous sur la page de migration (encadré « Piège fréquent » de la section 2).

```mission
{
  "title": "Quels paramètres la version d'API 2026-10-21 refuse-t-elle ?",
  "url": "https://platform.claude.com/docs/en/api/migration-2026-10-21",
  "steps": [
    "Ouvrez le guide de migration vers la version d'API 2026-10-21",
    "Cherchez la section consacrée aux paramètres d'échantillonnage (sampling)",
    "Notez quels paramètres provoquent une erreur et à quelle condition"
  ],
  "question": "Quels paramètres renvoient une erreur 400 avec cette version d'API, et l'erreur se produit-elle aussi à la valeur par défaut ?",
  "hint": "Cherchez les mots « temperature » et « 400 » dans la page.",
  "answer": "`temperature`, `top_p` et `top_k` renvoient une erreur 400, même à leur valeur par défaut, sur tous les modèles (page lue le 5 nov. 2026 ; la doc évolue, vérifiez) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

### 3.3 L'interface : `src/app/page.tsx`

```typescript
// src/app/page.tsx — composant client ; le flux arrive via useChat
"use client";

import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { useState } from "react";

export default function Page() {
  const [input, setInput] = useState("");
  const { messages, sendMessage, status, stop, error } = useChat({
    transport: new DefaultChatTransport({ api: "/api/chat" }),
  });
  const enCours = status === "submitted" || status === "streaming";

  return (
    <main className="mx-auto max-w-2xl p-6 space-y-4">
      <h1 className="text-xl font-semibold">Compta-Chat</h1>

      <ul className="space-y-3">
        {messages.map((m) => (
          <li key={m.id} className={m.role === "user" ? "text-right" : ""}>
            <span className="text-xs text-gray-500">{m.role === "user" ? "Vous" : "Assistant"}</span>
            {m.parts.map((part, i) => {
              if (part.type === "text") return <p key={i} className="whitespace-pre-wrap">{part.text}</p>;
              // Appels d'outils : le SDK nomme les parts "tool-<nomOutil>"
              if (part.type.startsWith("tool-")) {
                const p = part as { type: string; state: string; input?: unknown; output?: unknown };
                return (
                  <details key={i} className="rounded border p-2 text-sm">
                    <summary>🔧 {p.type.replace("tool-", "")} — {p.state}</summary>
                    <pre className="overflow-x-auto">{JSON.stringify({ entree: p.input, sortie: p.output }, null, 2)}</pre>
                  </details>
                );
              }
              return null;
            })}
          </li>
        ))}
      </ul>

      {error && <p className="text-red-600 text-sm">Erreur : {error.message}</p>}

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!input.trim() || enCours) return;
          sendMessage({ text: input });
          setInput("");
        }}
        className="flex gap-2"
      >
        <input
          className="flex-1 rounded border p-2"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Quelle est l'échéance TVA de la SARL Dupont ?"
          maxLength={4000}
        />
        {enCours ? (
          <button type="button" onClick={stop} className="rounded bg-gray-200 px-3">Stop</button>
        ) : (
          <button type="submit" className="rounded bg-black px-3 text-white">Envoyer</button>
        )}
      </form>
    </main>
  );
}
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `"use client";` : ce composant tourne dans le navigateur (pré-requis ci-dessus).
> - `const [input, setInput] = useState("")` : une variable d'état React pour le texte saisi ; `setInput` la modifie et provoque un nouvel affichage.
> - `useChat({ transport: new DefaultChatTransport({ api: "/api/chat" }) })` : le hook du SDK gère toute la conversation ; il renvoie la liste `messages`, la fonction `sendMessage`, le `status` (`submitted`, `streaming`, `ready`…), `stop` pour interrompre et `error`.
> - `messages.map(...)` puis `m.parts.map(...)` : chaque message est composé de **parties** ; on affiche le texte, et les appels d'outils (`tool-<nom>`) dans un bloc dépliable `<details>` avec leurs entrées et sorties.
> - Le formulaire : `e.preventDefault()` empêche le rechargement de la page, `sendMessage({ text: input })` envoie la question au route handler, `setInput("")` vide le champ ; pendant la génération, le bouton « Stop » remplace « Envoyer ».

Lancez `npm run dev`, posez la question « Quelle est l'échéance TVA de la SARL Dupont ? » : vous verrez apparaître l'appel à `rechercherClient` (état `input-streaming` puis `output-available`), puis `echeanceTva`, puis le texte final qui se construit mot à mot. Le `maxLength` côté client est un confort ; la **vraie** limite est celle du serveur (section 3.2), car un client malveillant contourne toujours le HTML.

## 4. Authentification et protection de la route

Une route de chat sans authentification est un distributeur de tokens gratuits : en 2025-2026, des bots ont systématiquement scanné les endpoints `/api/chat` ouverts pour s'en servir comme proxy LLM. Le minimum viable :

```typescript
// src/lib/auth.ts — vérification d'une session (exemple minimal avec cookie signé)
import { cookies } from "next/headers";
import { jwtVerify } from "jose";

const secret = new TextEncoder().encode(process.env.AUTH_SECRET!);   // 32+ caractères aléatoires

export async function getSession(_req: Request): Promise<{ userId: string } | null> {
  const token = (await cookies()).get("session")?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    return { userId: String(payload.sub) };
  } catch {
    return null;
  }
}
```

> 🧭 **Pré-requis express — cookie de session et JWT** — Un **cookie** est une petite donnée que le navigateur renvoie automatiquement au serveur à chaque requête vers le même site. Un **JWT** (*JSON Web Token*) est un texte en trois parties séparées par des points : un en-tête, un contenu (par exemple `sub`, l'identifiant de l'utilisateur) et une **signature** calculée avec un secret que seul le serveur connaît. `jwtVerify(token, secret)` vérifie cette signature : si quelqu'un modifie le contenu du jeton, la vérification échoue. C'est pourquoi `AUTH_SECRET` (au moins 32 caractères aléatoires, à ajouter dans `.env.local`) ne doit jamais quitter le serveur.
>
> 🔍 **Ce que fait ce code, ligne par ligne** — `new TextEncoder().encode(process.env.AUTH_SECRET!)` transforme le secret en octets (le `!` affirme qu'il existe : s'il manque, aucun jeton ne sera jamais valide). `(await cookies()).get("session")?.value` lit le cookie `session` de la requête ; pas de cookie, pas de session. `jwtVerify(...)` vérifie la signature et renvoie le contenu (`payload`), dont on garde `sub` comme `userId`. Toute erreur (jeton expiré, falsifié) aboutit à `null`, donc à un 401.

Il manque encore une façon d'**obtenir** ce cookie. En attendant une vraie page de connexion, cette route de test, active seulement en développement, en fabrique un :

```typescript
// src/app/api/dev-login/route.ts — connexion de TEST, active seulement avec `npm run dev`
import { SignJWT } from "jose";
import { NextResponse } from "next/server";

const secret = new TextEncoder().encode(process.env.AUTH_SECRET!);   // le même secret que auth.ts

export async function GET(req: Request) {
  if (process.env.NODE_ENV !== "development") return new Response("Introuvable", { status: 404 });
  const jeton = await new SignJWT({ sub: "collaborateur-test" })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("8h")
    .sign(secret);
  const reponse = NextResponse.redirect(new URL("/", req.url));          // retour à la page du chat
  reponse.cookies.set("session", jeton, { httpOnly: true, sameSite: "lax", path: "/" });
  return reponse;
}
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `process.env.NODE_ENV` vaut `"development"` sous `npm run dev` et `"production"` après `npm run build` : en production, la route répond 404 et ne délivre aucun jeton. `new SignJWT({ sub: … })…sign(secret)` fabrique un jeton signé avec `AUTH_SECRET`, valable 8 heures, que `getSession` acceptera. `NextResponse.redirect(…)` renvoie le navigateur vers `/` et `reponse.cookies.set("session", …)` pose le cookie au passage ; `httpOnly: true` le rend illisible par le JavaScript de la page. Ouvrez une fois `http://localhost:3000/api/dev-login` : vous arrivez sur le chat, connecté comme `collaborateur-test`.
>
> 🛠️ **Si ça ne marche pas** — Pour tester en local sans la route `dev-login`, créez un jeton avec la même bibliothèque, dans un petit script Node lancé avec `npx tsx` : `new SignJWT({ sub: "test" }).setProtectedHeader({ alg: "HS256" }).setExpirationTime("2h").sign(secret)` (import `SignJWT` depuis `jose`, `secret` fabriqué comme ci-dessus). Copiez le résultat dans un cookie nommé `session` via les outils de développement du navigateur (onglet *Application* → *Cookies*). Toujours 401 ensuite → `AUTH_SECRET` n'est pas le même dans le script et dans `.env.local`, ou le serveur n'a pas été relancé. `/api/dev-login` répond 404 → vous n'êtes pas sous `npm run dev` (c'est voulu en production).

En production, vous brancherez une bibliothèque complète (Auth.js, Clerk, Better Auth, ou l'annuaire de l'entreprise via OIDC) ; l'important est le **contrat** : le route handler obtient un `userId` fiable, qui servira aux quotas par utilisateur (L102) et aux traces (L103).

Checklist de la route avant tout déploiement :

| Contrôle | Pourquoi | Implémentation |
|---|---|---|
| Auth obligatoire | Éviter l'usage pirate de votre clé | `getSession` → 401 |
| Taille du message | Un message de 2 Mo = des milliers de tokens facturés | 413 au-delà de `MAX_MESSAGE_CHARS` |
| Profondeur d'historique | Le contexte grossit à chaque tour : coût linéaire | `slice(-MAX_HISTORY_MESSAGES)` |
| Validation du corps | Les `UIMessage` forgés peuvent injecter des `parts` d'outil factices | Zod + rejet 400 |
| `maxOutputTokens` | Plafond de coût par réponse | paramètre de `streamText` |
| `maxDuration` | Une fonction serverless qui tourne 5 min coûte cher et bloque | export Next.js |
| Annulation | Ne pas payer une réponse que personne ne lit | `abortSignal: req.signal` |

> ⚠️ **Piège fréquent** — Placer la clé API dans une variable `NEXT_PUBLIC_*`. Tout ce qui commence par `NEXT_PUBLIC_` est embarqué dans le bundle JavaScript du navigateur. Les clés restent dans des variables sans ce préfixe, lues uniquement dans du code serveur (route handlers, Server Components, Server Actions).

```quiz
{
  "q": "Votre formulaire impose maxLength=4000. Un testeur envoie avec curl un message de 2 Mo directement à /api/chat. Que doit-il se passer ?",
  "options": [
    "Le navigateur tronque le texte à 4 000 caractères",
    "Le modèle refuse de lire un texte aussi long",
    "Le serveur rejette la requête (413) avant l'appel",
    "Vercel coupe la fonction au bout de maxDuration"
  ],
  "answer": 2,
  "explanation": "curl ne passe pas par le formulaire : seule la limite côté serveur compte. Elle s'applique avant l'appel au fournisseur, donc rien n'est facturé."
}
```

```mission
{
  "title": "Le préfixe qui expose une variable au navigateur",
  "url": "https://nextjs.org/docs",
  "steps": [
    "Ouvrez la documentation Next.js",
    "Cherchez la page « Environment Variables »",
    "Repérez le paragraphe sur les variables accessibles au navigateur"
  ],
  "question": "Quel préfixe rend une variable d'environnement lisible dans le code du navigateur, et à quel moment sa valeur y est-elle intégrée ?",
  "hint": "Le préfixe est cité dans le « Piège fréquent » de la section 4.",
  "answer": "`NEXT_PUBLIC_` : la valeur est intégrée (inlinée) dans le bundle JavaScript au moment du build (doc consultée en nov. 2026). Ne l'utilisez jamais pour une clé.",
  "xp": 10
}
```

## 5. Changer de fournisseur, et quand le faire

La fonction `choisirModele()` illustre l'intérêt de l'abstraction : `AI_MODEL=gpt-6.1-terra` et l'application parle à OpenAI ; `mistral-small-4` avec `@ai-sdk/mistral` ; `grok-4.7` avec `@ai-sdk/xai` (le [Quickstart xAI](https://docs.x.ai/developers/quickstart) présente d'ailleurs le Vercel AI SDK comme première option d'intégration). Ordres de grandeur de prix (nov. 2026, pages Pricing officielles) : Claude Sonnet 5.5 2 $/10 $ par million de tokens entrée/sortie, Claude Haiku 5.5 0,10 $/0,50 $ (≤ 100k tokens), GPT-6.1 Terra 1 $/5 $, GPT-6 Luna 0,10 $/0,50 $, Mistral Small 4 0,15 $/0,60 $.

Ce que l'abstraction **ne** gomme pas : les comportements d'outils (certains modèles appellent plusieurs outils en parallèle, d'autres non), les paramètres interdits (`temperature` chez Claude), la qualité en français, et surtout la **latence**. La page [Reduce latency](https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency) d'Anthropic rappelle les leviers : modèle plus petit, prompt plus court, moins de tokens de sortie, streaming. Un changement de fournisseur se valide donc avec une suite d'évaluations (L103), jamais « à l'œil ».

> 🔗 **Documentation officielle** — [Vercel AI SDK](https://ai-sdk.dev) · [Next.js Route Handlers](https://nextjs.org/docs) · [Streaming Messages (Anthropic)](https://platform.claude.com/docs/en/build-with-claude/streaming)

🎮 **Défi** — Ajoutez un troisième outil `convertirDevise` qui lit un taux dans une table Postgres, puis demandez « Combien vaut la facture de 1 200 € de la SARL Dupont en dollars ? ». Combien d'étapes (`steps`) le modèle utilise-t-il ? Que se passe-t-il si vous passez `stopWhen: stepCountIs(1)` ?

## 🧪 Exercice pratique

**Consigne.** Reprenez le projet Compta-Chat et livrez une version qui :
1. affiche sous chaque réponse de l'assistant le nombre de tokens d'entrée et de sortie (indice : le `onFinish` de `streamText` reçoit `usage` ; transmettez-le au client avec `toUIMessageStreamResponse({ messageMetadata: ... })` ou via un en-tête personnalisé) ;
2. refuse avec un code 429 toute requête d'un même `userId` au-delà de 20 messages sur 10 minutes (une `Map` en mémoire suffit pour cet exercice ; L102 fera mieux) ;
3. propose un sélecteur de modèle dans l'interface (`claude-sonnet-5-5`, `claude-haiku-5-5`, `gpt-6.1-terra`), envoyé au serveur dans le corps de la requête et validé par Zod contre une liste blanche.

**Critères de réussite.**
- Le flux reste fluide (premier token < 1,5 s en local avec Haiku 5.5).
- Un message de 5 000 caractères est rejeté par le serveur (413), même en contournant le `maxLength` du formulaire.
- Un modèle hors liste blanche (`"gpt-99"`) est rejeté avec un 400, sans appel au fournisseur.
- `git grep NEXT_PUBLIC_` ne retourne aucune clé.

**Pistes de corrigé.** Pour le point 1, `toUIMessageStreamResponse({ messageMetadata: ({ part }) => part.type === "finish" ? { usage: part.totalUsage } : undefined })` attache l'usage au message ; côté client, lisez `m.metadata`. Pour le point 2, stockez `Map<userId, number[]>` des horodatages et filtrez ceux des 10 dernières minutes. Pour le point 3, `z.enum([...])` sur le champ `model` et une table `{ id → LanguageModel }` côté serveur.

## ✅ Auto-évaluation express

1. Pourquoi le navigateur ne doit-il jamais appeler directement l'API du fournisseur ?
2. Quel paramètre de `streamText` limite le nombre d'allers-retours modèle ↔ outils ?
3. Que se passe-t-il si vous définissez `NEXT_PUBLIC_ANTHROPIC_API_KEY` ?

**Réponses.** 1. La clé API serait visible dans le code client et réutilisable par n'importe qui ; le serveur intermédiaire protège la clé et applique auth, limites et journalisation. 2. `stopWhen` (par exemple `stepCountIs(5)`) ; chaque étape correspond à un appel modèle. 3. La clé est embarquée dans le bundle JavaScript public : elle est compromise et doit être révoquée immédiatement.

> ✅ **Si vous ne retenez que 3 choses** — 1. Le trajet d'un token passe toujours par votre serveur : fournisseur (SSE) → route handler Next.js (auth, limites, outils, journaux) → navigateur (`useChat`) ; la clé API ne quitte jamais le serveur et ne porte jamais le préfixe `NEXT_PUBLIC_`. 2. Le Vercel AI SDK fait la boucle d'outils (`streamText` + `tool()` + `stopWhen`) et le streaming pour vous, et le modèle se change en une ligne. 3. Protégez la route avant de la déployer : authentification, validation Zod, taille du message et de l'historique, `maxOutputTokens`, `maxDuration` et annulation (`abortSignal`).

## 📚 Pour aller plus loin
- [Vercel AI SDK — documentation](https://ai-sdk.dev) 🇬🇧 — référence de `streamText`, `useChat`, outils, fournisseurs et guides de migration entre versions.
- [Next.js — documentation](https://nextjs.org/docs) 🇬🇧 — App Router, Route Handlers, variables d'environnement, `maxDuration`.
- [Claude Platform — Streaming Messages](https://platform.claude.com/docs/en/build-with-claude/streaming) 🇬🇧 — détail des événements SSE si vous devez consommer le flux sans SDK.
- [OpenAI — Streaming responses](https://developers.openai.com/api/docs/guides/streaming-responses) 🇬🇧 — équivalent côté Responses API.
- [Claude Platform — Reduce latency](https://platform.claude.com/docs/en/test-and-evaluate/reduce-latency) 🇬🇧 — leviers pour améliorer le TTFT.

> 🗺️ **Et maintenant ?** — Votre chat répond en direct ; en L102, vous apprendrez à lui confier des tâches longues (file d'attente) et à garder la facture sous contrôle (quotas, cache, batch).
