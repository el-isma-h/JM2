---
module: M23
title: "Fiche mémo — Sécurité des applications LLM"
---
# Fiche mémo — M23 · Sécurité des applications LLM

> En une phrase : un LLM ne fait pas de différence entre une donnée et une instruction. Il n'existe donc pas de correctif unique. On réduit ce que l'application peut faire, on contrôle chaque frontière (entrée, outils, sortie), on plafonne les coûts, puis on audite avec des preuves.

## Les 7 idées à retenir
1. L'OWASP Top 10 LLM 2026 sert de grille de lecture. Excessive Agency monte au 3ᵉ rang, Unbounded Consumption au 6ᵉ (`L106`).
2. Dès que le modèle agit (outils, mémoire, autres agents), on ajoute la liste Agentic ASI01–ASI10. Le NIST AI RMF sert à gouverner, MITRE ATLAS à simuler l'attaquant (`L106`).
3. L'injection indirecte est la plus dangereuse : celui qui l'écrit n'est pas celui qui en est victime. Un refus du modèle ne prouve rien (`L107`).
4. La défense se fait en cinq couches : capacités réduites dans le code, données séparées des instructions, filtre « garde », validation de la sortie, journal et surveillance (`L107`).
5. Un garde-fou est toujours un composant à part : Llama Guard en local, API de modération, regex, Presidio, sorties structurées (`L108`).
6. On pseudonymise avant d'envoyer au fournisseur. La table de correspondance ne quitte jamais votre infrastructure (`L108`).
7. Une clé se garde, se cloisonne, se révoque d'abord. On empile quatre étages de quotas devant le LLM. Un audit commence par un mandat écrit et se prouve par des tests rejoués (`L109`, `L110`).

## Le schéma à connaître
```mermaid
flowchart LR
    U["Utilisateur / documents"] --> E["ENTRÉE : auth, quotas, PII, modération, filtre d'injection"]
    E --> M["Modèle"]
    M --> O["OUTILS : allow-list, plafonds, validation humaine"]
    O --> M
    M --> S["SORTIE : schéma, échappement, canari, PII"]
    S --> R["Réponse"]
    E & O & S --> J["Journal + alertes"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Injection directe / indirecte | Le piège est écrit par l'utilisateur, ou caché dans un contenu que l'appli lit |
| Jailbreak | Pousser le modèle hors de ses règles d'alignement (≠ injection) |
| Canari | Une chaîne unique dans le prompt système : si elle sort, il y a fuite |
| Pseudonymisation | Remplacer les données personnelles par des jetons qu'on peut retrouver |
| Déni de portefeuille | Une attaque qui vise votre facture plutôt que vos données |
| Probabilité × impact | Une note de 1 à 16. De 12 à 16, c'est critique et bloquant |

## Les pièges classiques
- « Le modèle a refusé, donc je suis protégé. » Rejouez chaque test au moins 5 fois.
- Mettre une règle métier (« remise ≤ 10 % ») dans le prompt. Elle va dans le code.
- Laisser des secrets (grille de remises, mot de passe) dans le prompt système (LLM08).
- Compter sur l'API de modération contre l'injection. Elle classe des contenus, pas des manipulations.
- Insérer la sortie du modèle avec `innerHTML`, ou exécuter son SQL avec tous les droits (LLM10 + LLM03).
- Utiliser une base vectorielle unique sans filtre par client (LLM09).
- Tester le chatbot d'un concurrent « pour voir ». C'est une intrusion (art. 323-1 du Code pénal).

## Les commandes / chiffres / dates utiles
```python
# Couche 1 : la règle vit dans le code
if nom == "appliquer_remise" and args["pourcentage"] > PLAFOND_REMISE_AUTO:   # 10
    raise ValidationHumaineRequise(nom, args)
# Couche 2 : le contenu externe est une donnée
contenu = contenu.replace("</donnees_externes>", "&lt;/donnees_externes&gt;")
```
```bash
ollama run llama-guard3 "…"                    # → safe / unsafe + catégorie (ex. S9)
npx promptfoo@latest eval -c audit.yaml        # attaques rejouées à chaque commit
```
- **OWASP LLM 2026** (4/08/2026) : LLM01 Prompt Injection · LLM02 Sensitive Information Disclosure · LLM03 Excessive Agency · LLM04 Supply Chain · LLM05 Data and Model Poisoning · LLM06 Unbounded Consumption · LLM07 Misinformation · LLM08 Hidden Context Exposure · LLM09 Vector and Embedding Weaknesses · LLM10 Improper Output Handling.
- **OWASP Agentic 2026** (9/12/2025) : ASI01 Agent Goal Hijack · ASI02 Tool Misuse and Exploitation · ASI03 Identity and Privilege Abuse · ASI04 Agentic Supply Chain Vulnerabilities · ASI05 Unexpected Code Execution (RCE) · ASI06 Memory & Context Poisoning · ASI07 Insecure Inter-Agent Communication · ASI08 Cascading Failures · ASI09 Human-Agent Trust Exploitation · ASI10 Rogue Agents.
- **NIST AI RMF** : Govern, Map, Measure, Manage. Profil IA générative : NIST AI 600-1.
- **Quotas DevisBot** : 10 requêtes par minute → 429 · 4 000 tokens en entrée → 413 · 0,50 $ par jour et par utilisateur, 30 $ par jour au global → 402/503.
- **Coût d'une requête** (3 200 tokens d'entrée, 400 de sortie) : Haiku 5.5 0,00052 $, Opus 5.5 0,0208 $ (40 fois plus).
- **Identifiant opaque** : `metadata.user_id` (Anthropic), `safety_identifier` (OpenAI).
- **Réglementation** : AI Act art. 50 (dire « vous échangez avec une IA »), applicable depuis le 2/08/2026. La CNIL publie des fiches pratiques IA (15 fiches numérotées de 1 à 13 ; fiche 12 : sécurité).

## Pour aller plus loin
- [OWASP GenAI Security Project](https://genai.owasp.org/)
- [Mitigate jailbreaks and prompt injections](https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/mitigate-jailbreaks)
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia)

## Auto-test (3 questions — réponses en bas de fiche)
1. Votre clé a été poussée sur un dépôt public il y a dix minutes. Que faites-vous en premier ?
2. L'outil `requete_sql` exécute le SQL du modèle avec tous les droits. À quels risques OWASP ce constat se rattache-t-il ?
3. Un cabinet médical résume des e-mails de patients via une API. Quel pipeline choisir ?

---
**Réponses.** 1) Révoquer la clé dans la console, en émettre une nouvelle, puis nettoyer l'historique. 2) LLM10 Improper Output Handling et LLM03 Excessive Agency. 3) Pseudonymiser en local, envoyer le texte pseudonymisé, ré-identifier en local. La table reste chez vous.
