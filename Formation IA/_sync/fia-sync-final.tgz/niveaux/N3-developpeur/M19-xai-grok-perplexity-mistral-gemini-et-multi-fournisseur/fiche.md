---
module: M19
title: "Fiche mémo — xAI Grok, Perplexity, Mistral, Gemini et multi-fournisseur"
---
# Fiche mémo — M19 · xAI Grok, Perplexity, Mistral, Gemini et multi-fournisseur

> En une phrase : chaque fournisseur a son point fort (X, recherche citée, souveraineté, multimodal). Une couche d'abstraction mince permet de router, de basculer et de comparer en dollars.

## Les 7 idées à retenir
1. Grok se parle avec le SDK OpenAI (`base_url="https://api.x.ai/v1"`). Son atout : `x_search`, la recherche native dans X (`L084`).
2. Perplexity a abandonné les Sonar Chat Completions le 27/09/2026. La Search API donne des sources brutes, l'Agent API une réponse citée (`L085`).
3. Mistral, c'est l'option européenne. Small 4 et Ministral 3 sont sous Apache 2.0 et peuvent être auto-hébergés. Codestral fait du FIM (`L086`).
4. Gemini avale PDF, audio et vidéo sur 1M tokens. On réutilise un gros document avec le context caching (`L087`).
5. Le fournisseur est une dépendance remplaçable : interface → adaptateurs → routeur → repli → cache → traces (`L088`).
6. Un retry rappelle le même fournisseur sur une erreur passagère. Un fallback passe au fournisseur suivant (`L088`).
7. On compare les fournisseurs en dollars et sur un jeu de tests commun (promptfoo), jamais en tokens (`L088`).

## Le schéma à connaître
```mermaid
flowchart LR
    R["Requête"] --> C["Classifieur de difficulté"]
    C --> P["Palier : simple / complexe / recherche / documents"]
    P --> L["Candidats triés (coût, latence, contraintes)"]
    L --> A["Fournisseur 1"]
    A -->|"échec après retries"| B["Fournisseur 2 (fallback)"]
    A --> T["Trace : coût, latence, palier"]
    B --> T
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Outil serveur | Le fournisseur l'exécute lui-même (`web_search`, `x_search`, grounding) |
| Search API / Agent API | Des sources brutes, ou une réponse rédigée avec citations |
| FIM | *Fill-in-the-middle* : compléter le code entre `prompt` et `suffix` |
| Context caching | Un gros contexte stocké chez Google, relu à tarif réduit |
| Passerelle | Un serveur intermédiaire : une clé, une facture (OpenRouter) |
| Disjoncteur | On ignore un fournisseur pendant un temps après plusieurs échecs |

## Les pièges classiques
- Facturer `x_search` à l'appel. Il est facturé par post renvoyé (5 $ / 1 000), posts parents et cités compris, et 10 $ / 1 000 profils.
- Donner à Perplexity `base_url="https://api.perplexity.ai"` sans `/v1`. Il ne faut pas non plus chercher un champ `citations` à la racine : les sources sont dans `output[].content[].annotations[]`.
- Dire « Mistral = open source ». Large 4 est en Public Preview avec des poids ouverts annoncés, mais pas sous Apache 2.0.
- Oublier que les tokens de réflexion Gemini sont facturés en sortie (`thoughtsTokenCount`).
- Utiliser l'ancien SDK Gemini `google.generativeai`. Il faut `google-genai`.
- Envoyer `logprobs` à Grok ≥ 4.20, ou `temperature` à Claude avec l'API `2026-10-21` : les deux sont refusés.
- Passer des données réglementées par une passerelle SaaS : c'est un tiers de plus qui voit les prompts.

## Les commandes / chiffres / dates utiles
```python
xai = OpenAI(api_key=os.environ["XAI_API_KEY"], base_url="https://api.x.ai/v1")
ppx = OpenAI(api_key=os.environ["PERPLEXITY_API_KEY"], base_url="https://api.perplexity.ai/v1")
r = ppx.responses.create(model="openai/gpt-6.1-sol", input="…")   # POST /v1/agent (alias /v1/responses)

from mistralai import Mistral
Mistral(api_key=os.environ["MISTRAL_API_KEY"]).chat.complete(model="mistral-small-latest", messages=[…])

from google import genai
genai.Client().models.generate_content(model="gemini-3.8-flash", contents="…")

from litellm import Router   # modèles nommés "fournisseur/modèle", fallbacks=[{"complexe": ["simple"]}]
```
- **Grok 4.7** : 2 / 6 $ par MTok (4 / 12 au-delà de 200k), cache à 0,50. Contexte 500k. `web_search` 5 $ / 1 000. Batch −20 %.
- **Perplexity** : Search API 5 $ / 1 000 (Fast Search 1 $). Équivalents d'effort : `sonar` → `fast`, `sonar-reasoning-pro` → `low`, `sonar-deep-research` → `high`. Dans le quickstart, `effort` est un paramètre racine.
- **Mistral** : Large 4 0,70 / 2,10 · Small 4 0,15 / 0,60 · Codestral 0,30 / 0,90. OCR 4.1 : 4 $ / 1 000 pages.
- **Gemini** : `gemini-3.8-flash` à 0,75 / 3,75, puis **1,50 / 7,50 au 1/01/2027**. `gemini-4-argon` à 2 / 10, puis **4 / 20 au 1/12/2026**. Batch ≈ 0,5×.
- **Rôle système** : `system` (Anthropic), `instructions` (OpenAI et xAI), message `system` (Mistral), `system_instruction` (Gemini).
- **Bases URL** : OpenRouter `https://openrouter.ai/api/v1`. Hugging Face `router.huggingface.co/v1`.
- **Comparer** : `npx promptfoo eval`, puis `npx promptfoo view`.

## Pour aller plus loin
- [xAI — Quickstart](https://docs.x.ai/developers/quickstart)
- [Gemini API — Pricing](https://ai.google.dev/gemini-api/docs/pricing)
- [LiteLLM — Documentation](https://docs.litellm.ai/docs/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Un appel `grok-4.7` lit 20 000 tokens, en produit 800, et `x_search` renvoie 60 posts. Combien coûte-t-il ?
2. Une mutuelle traite 2 milliards de tokens par mois et ses données ne doivent jamais sortir du SI. Quelle option Mistral choisir ?
3. Retry ou fallback : lequel pour une erreur 529, et lequel quand le fournisseur reste en panne ?

---
**Réponses.** 1) 0,04 + 0,0048 + 60 × 0,005 ≈ 0,345 $. 2) Auto-héberger Small 4 ou Ministral 3 (Apache 2.0), après un prototype sur l'API. 3) Un retry avec backoff sur le même fournisseur pour la 529. Un fallback vers le fournisseur suivant si la panne persiste.
