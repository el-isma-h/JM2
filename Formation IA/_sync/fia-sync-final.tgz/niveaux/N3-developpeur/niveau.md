# Niveau 3 — Développeur IA (NF-IA-N3)

**Certificat Next Formation IA — Niveau 3 « Développeur IA »** · 45 h à distance (44 h de leçons et exercices + 1 h d'évaluations) · 8 modules · 46 leçons · 8 quiz · 1 examen · 6 projets de code · Version 1.0 — 1er novembre 2026.

## Promesse

À l'issue du niveau 3, vous **développez, sécurisez et déployez des applications et des agents** fondés sur les API de modèles de langage : Anthropic (Claude), OpenAI, xAI (Grok), Perplexity, Mistral et Google Gemini. Vous maîtrisez le streaming, les coûts, le cache et les limites de débit ; l'appel d'outils et les sorties structurées ; le RAG en code avec évaluation ; les agents (boucle outils-mémoire-planification, LangGraph, Agent SDK, multi-agents) exposés via le protocole MCP ; l'interface, l'observabilité et les tests de prompts en CI/CD ; et la défense contre les risques de l'OWASP Top 10 pour les applications LLM (édition 2026). Le niveau est aligné sur les référentiels publics des certifications Claude Certified Developer – Foundations et Architect – Foundations.

## Public

Développeurs (web, mobile, back-end), intégrateurs, data analysts, administrateurs systèmes, étudiants en informatique (écoles d'ingénieurs, 42, BUT/BTS, bootcamps), freelances techniques, product builders qui veulent dépasser le no-code.

## Prérequis

- **Bases de programmation** en Python **ou** JavaScript/TypeScript : variables, fonctions, boucles, gestion des erreurs, installation de paquets (pip / npm).
- Notions HTTP (requêtes, codes de statut), JSON et ligne de commande ; usage de base de Git.
- Niveau 2 recommandé (ou équivalent : notions de prompt, RAG, automatisation).
- Test de positionnement d'entrée ; une remise à niveau est proposée dans le module 16.

## Compétences du bloc 3 (référentiel de compétences)

| Code | Compétence |
|---|---|
| C3.1 | Intégrer une API de modèle de langage (Anthropic, OpenAI, xAI, Perplexity, Mistral, Gemini) dans une application avec gestion du streaming, des erreurs, des coûts et des limites |
| C3.2 | Mettre en œuvre l'appel d'outils (tool use / function calling) et les sorties structurées pour fiabiliser les réponses |
| C3.3 | Concevoir un pipeline RAG (ingestion, découpage, embeddings, base vectorielle, reranking) et en évaluer la qualité |
| C3.4 | Développer un agent IA (boucle outils-mémoire-planification) et l'exposer via MCP ou un SDK d'agents |
| C3.5 | Déployer une application IA avec interface, observabilité et tests de prompts |
| C3.6 | Sécuriser une application LLM contre les risques de l'OWASP Top 10 (injection de prompt, fuite de données, abus) |

## Modules et durées

| Module | Titre | Leçons | Durée | Compétences |
|---|---|---|---|---|
| M16 | Fondations de développement pour l'IA (Python/TypeScript, SDK, clés et secrets ; HTTP/JSON/streaming ; tokens, coûts, rate limits, caching) | L065-L067 | 3 h 30 | C3.1 |
| M17 | API Anthropic : construire avec Claude (Messages API, system prompts, tool use, sorties structurées, vision/PDF/Files/citations, caching/Batch/thinking, Claude Code et Agent SDK, MCP, Skills, évaluation, projet) | L068-L077 | 8 h 05 | C3.1, C3.2, C3.4 |
| M18 | API OpenAI (Responses API, function calling, embeddings/images/audio/Realtime, Agents SDK, fine-tuning et Evals, projet de portage) | L078-L083 | 5 h 45 | C3.1, C3.2 |
| M19 | xAI Grok, Perplexity, Mistral, Gemini et multi-fournisseur (abstraction, routeurs, repli) | L084-L088 | 4 h 50 | C3.1 |
| M20 | RAG en code (pgvector/Chroma/Qdrant, ingestion, LangChain/LlamaIndex, recherche hybride et reranking, Ragas, projet) | L089-L094 | 5 h 45 | C3.3 |
| M21 | Agents en code (boucle agentique, LangGraph, OpenAI Agents SDK / Claude Agent SDK / Pydantic AI, CrewAI / AG2, MCP et A2A, projet) | L095-L100 | 5 h 45 | C3.4 |
| M22 | Applications IA : interface (Next.js, Vercel AI SDK), backend, observabilité (Langfuse, LangSmith, promptfoo, DeepEval), CI/CD, projet déployé | L101-L105 | 4 h 50 | C3.5 |
| M23 | Sécurité des applications LLM (OWASP Top 10 LLM 2026, prompt injection, guardrails, secrets et coûts, atelier d'audit) | L106-L110 | 5 h 30 | C3.6 |
| | **Total leçons et exercices** | 46 leçons | **44 h 00** | |
| | Quiz de modules (8 × 15 min) et examen de niveau (60 min) | | ≈ 1 h (comptés dans les 45 h) | |

## Modalités d'évaluation

- **8 quiz de fin de module** (10 questions, seuil 70 %) et **examen de niveau** (40 questions, 60 min, seuil 70 %, surveillé à distance, 3 tentatives).
- **Six projets de code livrés dans un dépôt Git** (grille à 5 critères notés 0-3 ; compétence validée si ≥ 8/15 sans critère à 0) :
  1. Assistant métier avec Claude (L077) → C3.1, C3.2
  2. Le même assistant porté sur OpenAI (L083) → C3.1, C3.2
  3. RAG documentaire d'entreprise avec métriques Ragas (L094) → C3.3
  4. Agent de recherche et de rédaction autonome + serveur MCP (L100) → C3.4
  5. Application IA complète déployée avec traces et suite d'évaluation en CI (L105) → C3.5
  6. Audit de sécurité d'une application IA fournie, contre-mesures implémentées (L110) → C3.6
- Règles de dépôt : aucune clé API dans le code (variables d'environnement), README d'exécution, coût estimé par appel, tests.
- **Certification (option RS)** : soutenance de 20 min devant jury (revue de code et démonstration). Toutes les compétences C3.1 à C3.6 doivent être validées.

## Certifications tierces visées (en complément, hors Next Formation)

- Badges gratuits **Claude Academy** : « Building with the Claude API » (9 h, 8 quiz), « Claude Platform 101 », « Claude Code 101 », « Claude Code in action », « Introduction to Model Context Protocol », « MCP: Advanced topics », « The AI-native SDLC playbook » — https://academy.claude.com/courses.
- **Claude Certified Developer – Foundations** (125 $) ou **Claude Certified Architect – Foundations** (125 $) — **uniquement si votre employeur est membre du Claude Partner Network** (Pearson VUE, 120 min, seuil 720/1000, validité 12 mois) — https://anthropic-partners.skilljar.com/page/partner-certifications.
- **Hugging Face Agents Course** (certificat de réussite) et **MCP Course** (certificat de complétion), gratuits — https://huggingface.co/learn.
- **OpenAI Academy** — parcours « Build with AI » (gratuit) — https://academy.openai.com/.
- Short courses gratuits **DeepLearning.AI** : « MCP: Build Rich-Context AI Apps with Anthropic », « Agent Skills with Anthropic », « Claude Code: A Highly Agentic Coding Assistant », « Building Systems with the ChatGPT API », « LangChain for LLM Application Development ».

## Matériel et logiciels nécessaires

- Ordinateur Windows 10/11 (WSL2 recommandé), macOS 13+ ou Linux, 16 Go de RAM recommandés, webcam et micro pour l'examen et la soutenance. Aucun GPU requis : les modèles sont appelés via les API ; un modèle local (Ollama) sert de solution de repli sans frais.
- **Langages et outils à installer (gratuits)** : Python 3.11+ (avec `uv` ou `pip`/`venv`), **Node.js 20+** (npm), Git, VS Code (ou JetBrains), Docker Desktop (bases vectorielles, Open WebUI), PostgreSQL + pgvector (via Docker), **Claude Code** (`curl -fsSL https://claude.ai/install.sh | bash` ou `winget install Anthropic.ClaudeCode`), MCP Inspector, Ollama.
- **Comptes et clés API** : console Anthropic (https://platform.claude.com/, clé API, palier Evaluation puis Start), OpenAI (developers.openai.com), xAI (console.x.ai), Perplexity (Agent API), Mistral AI Studio (console.mistral.ai), Google AI Studio (Gemini, free tier), Hugging Face, GitHub, Vercel (déploiement, plan gratuit), Langfuse (plan Hobby gratuit) ou LangSmith. Budget d'API indicatif pour les projets : **20 à 40 € pour l'ensemble du niveau** (modèles économiques Haiku 5.5 / GPT-6 Luna / Gemini 3.8 Flash / Mistral Small 4 et cache de prompts enseignés dès le module 16) ; plafonner les clés et activer les alertes de dépense (L067, L109).
- SDK utilisés : `anthropic` (Python 2.x / TypeScript 1.x), `openai`, `xai-sdk`, `mistralai`, `google-genai`, `langchain`/`langgraph`, `llama-index`, `chromadb`, `qdrant-client`, `ragas`, `promptfoo`, `deepeval`, `ai` (Vercel AI SDK), `claude-agent-sdk`, `openai-agents`, `pydantic-ai`, `mcp`.
