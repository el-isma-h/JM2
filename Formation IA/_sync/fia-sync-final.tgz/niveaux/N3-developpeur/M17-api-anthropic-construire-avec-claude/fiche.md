---
module: M17
title: "Fiche mémo — API Anthropic : construire avec Claude"
---
# Fiche mémo — M17 · API Anthropic : construire avec Claude

> En une phrase : la Messages API est la base. On y branche un system prompt, des outils, du JSON garanti, des documents, du cache, puis Claude Code, l'Agent SDK et MCP.

## Les 7 idées à retenir
1. L'API est sans état. Vous renvoyez l'historique à chaque tour et vous lisez toujours `stop_reason` (`L068`).
2. Le system prompt, c'est la fiche de poste : rôle, contexte, règles avec leur raison, format, exemples, escalade. Il se versionne comme du code (`L069`).
3. Tool use : Claude demande l'outil, votre code l'exécute. Tous les `tool_result` d'un tour partent dans un seul message `user` (`L070`).
4. `output_config.format` garantit la forme du JSON, pas son contenu. Il faut des contrôles métier (`L071`).
5. Vision, PDF, Files API (`file_id`), citations : `cited_text` n'est pas facturé en sortie. Les citations ne se combinent pas avec les sorties structurées (`L072`).
6. Le cache coupe le coût du préfixe stable. Le batch coûte −50 %. Le thinking adaptatif se règle avec `effort` (`L073`).
7. Claude Code et l'Agent SDK partagent le même moteur. MCP branche des outils partout. Un skill apprend une procédure, et il s'évalue avec un score (`L074`–`L076`).

## Le schéma à connaître
```mermaid
sequenceDiagram
    participant A as Votre code
    participant C as Claude (Messages API)
    A->>C: messages + tools
    C-->>A: stop_reason = tool_use (bloc tool_use, id)
    A->>A: exécute la fonction
    A->>C: 1 message user avec tous les tool_result (tool_use_id)
    C-->>A: stop_reason = end_turn (texte final)
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| `tool_use` / `tool_result` | La demande d'outil et sa réponse, reliées par l'id |
| `strict: true` | Les arguments de l'outil respectent exactement le schéma |
| Breakpoint `cache_control` | L'étiquette « à garder au chaud » (4 au maximum) |
| `effort` | L'intensité de réflexion : `low` … `max` |
| Hook | Un script vigile de Claude Code (`PreToolUse`…) |
| Skill | Un dossier avec un `SKILL.md`, chargé à la demande |
| MCP connector | L'API joue elle-même le client MCP (`mcp_servers`) |

## Les pièges classiques
- Envoyer `temperature`, `top_p` ou `top_k`. Avec l'API `2026-10-21` (SDK v2), c'est une erreur 400 sur tous les modèles.
- Forcer `tool_choice` (`any` ou `tool`) : erreur 400 sur Opus 5.5 et Sonnet 5.5. Haiku 5.5 l'accepte, mais sans bloc de réflexion.
- Préremplir le message `assistant` : ce n'est plus supporté. Utilisez `output_config.format`.
- Deux messages `user` consécutifs ne provoquent pas d'erreur : l'API les fusionne. Les `tool_result` doivent quand même tenir dans un seul message.
- Mettre un horodatage avant le breakpoint : le cache est réécrit à chaque appel.
- Utiliser `budget_tokens` sur les modèles 5 : il faut `thinking: {"type": "adaptive"}`.
- Installer un serveur MCP tiers sans l'auditer : c'est du code qui tourne avec vos droits.

## Les commandes / chiffres / dates utiles
```python
r = client.messages.create(model="claude-sonnet-5-5", max_tokens=800,
    system=[{"type": "text", "text": PROC, "cache_control": {"type": "ephemeral", "ttl": "1h"}}],
    tools=[{"name": "verifier_stock", "description": "…", "strict": True,
            "input_schema": {"type": "object", "properties": {"reference": {"type": "string"}},
                             "required": ["reference"]}}],
    thinking={"type": "adaptive"}, output_config={"effort": "medium"},
    messages=historique)
devis = client.messages.parse(…, output_format=Devis).parsed_output  # Pydantic ; Zod : zodOutputFormat
```
```bash
claude -p "Relis ce diff" --output-format json --allowedTools "Read,Grep" --max-turns 8
claude mcp add --transport http erp https://mcp.erp.exemple.fr/mcp --scope project   # → .mcp.json
mcp dev serveur.py                                                                   # Inspector
```
- **Modèles nov. 2026 ($/MTok)** : Haiku 5.5 0,10 / 0,50 · Sonnet 5.5 2 / 10 (le choix par défaut) · Opus 5.5 4 / 20 · Fable 5.1 10 / 50. Contexte 1M, sortie 128K.
- **Cache** : préfixe d'au moins 512 tokens, TTL de 5 min ou 1 h. Écriture ×1,25 ou ×2, lecture ×0,05 sur Sonnet et Opus 5.5. Ordre : `tools` → `system` → `messages`.
- **Batch** : 100 000 requêtes ou 256 Mo par lot, 24 h maximum, résultats gardés 29 jours.
- **PDF** : 600 pages au maximum, requête de 128 Mo au maximum.
- **Outils serveur** : `web_search` 10 $ / 1 000 recherches, `web_fetch` gratuit.
- **Hooks** : un code de sortie 2 refuse l'action, et le message de stderr est transmis à Claude.
- **MCP** : la révision `2026-07-28` est la version stable actuelle. Le protocole est désormais sans état (plus d'`initialize` ni d'ID de session). HTTP+SSE, Roots, Sampling et Logging sont dépréciés. Pour un serveur partagé, on utilise Streamable HTTP avec OAuth 2.1.
- **Certification Developer – Foundations** : 120 min, seuil 720 sur 1 000, valable 12 mois.

## Pour aller plus loin
- [Tool use overview](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)
- [Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs)
- [MCP connector](https://platform.claude.com/docs/en/agents-and-tools/mcp-connector)

## Auto-test (3 questions — réponses en bas de fiche)
1. Claude renvoie deux blocs `tool_use`. Que renvoyez-vous ?
2. Vous devez classer 50 000 factures par mois, sans urgence. Quelle combinaison choisissez-vous ?
3. Skill, outil, MCP ou subagent : lequel pour enseigner une procédure de relance d'impayés ?

---
**Réponses.** 1) Un seul message `user` avec deux `tool_result`, chacun portant le bon `tool_use_id`. 2) Haiku 5.5, une sortie structurée avec `enum`, et la Batch API (−50 %). 3) Un skill : c'est une procédure, chargée à la demande.
