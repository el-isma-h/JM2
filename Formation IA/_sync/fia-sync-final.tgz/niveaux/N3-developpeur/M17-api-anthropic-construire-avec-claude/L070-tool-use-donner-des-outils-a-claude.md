---
id: L070
module: M17
level: N3
title: "Tool use : donner des outils à Claude"
minutes: 50
objectives:
  - "Expliquer le cycle complet d'un appel d'outil (tool_use → exécution côté client → tool_result) et le rôle de stop_reason"
  - "Définir des outils avec un schéma JSON précis et une description de qualité, puis implémenter la boucle agentique en Python et TypeScript"
  - "Gérer les appels parallèles, les erreurs d'outil, le mode strict et distinguer outils client, outils serveur (web search, code execution) et outils intégrés (bash, text editor, computer use)"
  - "Estimer le coût d'une boucle d'outils et appliquer les bonnes pratiques de la documentation officielle"
skills: ["C3.2", "C3.4"]
sources:
  - { title: "Claude Platform — Tool use overview", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview", lang: "en" }
  - { title: "Claude Platform — How tool use works", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/how-tool-use-works", lang: "en" }
  - { title: "Claude Platform — Define tools", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/define-tools", lang: "en" }
  - { title: "Claude Platform — Handle tool calls", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/handle-tool-calls", lang: "en" }
  - { title: "Claude Platform — Parallel tool use", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/parallel-tool-use", lang: "en" }
  - { title: "Claude Platform — Strict tool use", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use", lang: "en" }
  - { title: "Claude Platform — Tool runner (SDK)", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-runner", lang: "en" }
  - { title: "Claude Platform — Server tools", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools", lang: "en" }
  - { title: "Claude Platform — Web search tool", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool", lang: "en" }
  - { title: "Claude Platform — Troubleshooting tool use", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/troubleshooting-tool-use", lang: "en" }
---

# Tool use : donner des outils à Claude

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Déclarer des outils (nom, description, `input_schema`) et comprendre que **Claude ne les exécute jamais lui-même** : il demande, vous exécutez, vous rendez compte.
- Écrire la boucle agentique complète (jusqu'à `stop_reason == "end_turn"`) en Python et en TypeScript, avec gestion des erreurs et des appels parallèles.
- Choisir entre outils client (votre code), outils serveur (exécutés par Anthropic : web search, web fetch, code execution) et outils intégrés (bash, text editor, computer use, memory).
- Diagnostiquer les problèmes classiques : outil jamais appelé, arguments mal formés, boucle infinie, coût qui explose.

> 🧭 **En clair** — Le *tool use*, c'est **le chef qui envoie le commis chercher un ingrédient**. Le chef (Claude) sait cuisiner, mais il ne quitte jamais sa cuisine : quand il lui manque une information (le stock, l'agenda, un prix), il crie « Commis ! Va voir s'il reste du beurre en chambre froide ! ». Le commis, c'est **votre code** : il y va, revient et annonce « Il en reste deux kilos ». Le chef reprend alors sa recette avec cette information, ou renvoie le commis ailleurs. Vous décidez où le commis a le droit d'aller : s'il n'a que la clé de la chambre froide, il ne pourra jamais vider la caisse. Toute la leçon consiste à bien décrire les courses possibles (les outils) et à organiser ces allers-retours (la boucle).

## 1. Comment fonctionne le tool use

Un plombier reçoit un appel : « Avez-vous un joint de 40 mm en stock et pouvez-vous passer jeudi ? » Il ne devine pas : il **consulte son logiciel de stock** et **son agenda**, puis répond. Le tool use (ou *function calling*) donne ce réflexe à Claude. Le cycle, décrit sur la page [How tool use works](https://platform.claude.com/docs/en/agents-and-tools/tool-use/how-tool-use-works), est le suivant :

```
1. Vous envoyez : messages + liste `tools` (nom, description, input_schema)
2. Claude répond avec stop_reason = "tool_use" et un bloc
   { type: "tool_use", id: "toolu_01…", name: "verifier_stock", input: { reference: "J40" } }
3. VOTRE code exécute la fonction (base de données, API, calcul…)
4. Vous renvoyez un message user contenant
   { type: "tool_result", tool_use_id: "toolu_01…", content: "12 unités en stock" }
5. Claude répond en texte (stop_reason = "end_turn") … ou redemande un outil (retour à 2)
```

Le point crucial : **l'API ne fait rien à votre place**. Elle produit une *intention structurée* ; c'est vous qui décidez d'exécuter ou non, avec quelles permissions. C'est aussi ce qui rend le tool use sûr : un outil qui ne fait que lire ne pourra jamais supprimer.


```quiz
{
  "q": "Claude renvoie un bloc tool_use demandant verifier_stock(reference=\"J40\"). Qui interroge réellement la base de stock ?",
  "options": ["Les serveurs d'Anthropic, automatiquement, dès le bloc tool_use", "Votre propre code, qui décide d'exécuter ou non la fonction", "Claude, qui se connecte directement à votre base de données", "Le SDK, sans que vous ayez à écrire la moindre fonction"],
  "answer": 1,
  "explanation": "Pour un outil client, l'API ne produit qu'une intention structurée (nom + arguments). C'est votre code qui exécute la fonction, avec vos permissions, puis renvoie un bloc tool_result."
}
```

## 2. Définir de bons outils

La page [Define tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/define-tools) insiste sur un point contre-intuitif : **la description est plus importante que le schéma**. Claude décide d'appeler un outil en lisant sa description ; 3-4 phrases qui disent *ce que fait l'outil, quand l'utiliser, quand ne pas l'utiliser, ce qu'il renvoie* valent mieux qu'un schéma parfait avec une description d'un mot.

```python
# outils.py — définitions d'outils pour un artisan plombier (réutilisées dans la boucle ci-dessous)
OUTILS = [
    {
        "name": "verifier_stock",
        "description": (
            "Vérifie la quantité disponible d'une pièce dans le stock de l'atelier à partir de sa référence "
            "interne (ex. 'J40' pour un joint de 40 mm). À utiliser dès qu'un client demande une disponibilité "
            "ou un délai. Ne pas utiliser pour les prix : utiliser 'tarif_piece'. Renvoie la quantité et "
            "l'emplacement, ou 'référence inconnue'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reference": {"type": "string", "description": "Référence interne de la pièce, en majuscules"}
            },
            "required": ["reference"],
        },
    },
    {
        "name": "creneaux_disponibles",
        "description": (
            "Liste les créneaux d'intervention libres de l'artisan pour une date donnée (format AAAA-MM-JJ). "
            "À utiliser pour proposer un rendez-vous. Renvoie une liste de plages horaires, vide si journée pleine."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"date": {"type": "string", "description": "Date ISO 8601, ex. 2026-11-06"}},
            "required": ["date"],
        },
    },
]
```

> 🧭 **Pré-requis express — JSON Schema** — `input_schema` est écrit en **JSON Schema**, un format standard pour décrire « à quoi doit ressembler » un objet JSON. Il se lit comme un formulaire vierge :
> - `"type": "object"` : l'outil reçoit un objet (des paires nom / valeur, comme un dictionnaire Python).
> - `"properties": {…}` : la liste des champs possibles ; chacun a un `type` (`string` = texte, `integer` = nombre entier, `number` = nombre, `boolean` = vrai/faux, `array` = liste) et une `description` lue par Claude.
> - `"required": ["reference"]` : les champs obligatoires ; les autres sont facultatifs.
> - `"enum": ["urgent", "normal"]` : seules ces valeurs sont permises.
> - Claude **remplit** ce formulaire quand il veut appeler l'outil ; votre code reçoit le résultat dans `bloc.input`, sous forme de dictionnaire (`{"reference": "J40"}`).
>
> 🔍 **Ce que fait ce code, ligne par ligne** — `OUTILS` est une simple liste Python de deux dictionnaires ; rien n'est exécuté ici, on **décrit** seulement les outils. Les parenthèses autour de `"description": ( "…" "…" )` servent à écrire une longue phrase sur plusieurs lignes. Le fichier doit s'appeler `outils.py` et être rangé à côté de `boucle_outils.py`, qui l'importe.

Trois règles de la doc à retenir : un **nom** en `snake_case` sans espace ; des **propriétés documentées** une par une ; des **enum** quand les valeurs sont fermées (`"enum": ["urgent", "normal"]`). Le mode **strict** (`"strict": true` dans la définition, page [Strict tool use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use)) garantit que les arguments respectent exactement le schéma JSON (types, champs requis), au prix d'un sous-ensemble de JSON Schema supporté : activez-le pour les outils qui écrivent dans une base.

> 💡 **Autrement dit** — Le **schéma JSON** (`input_schema`), c'est le **bon de commande** que le commis doit remplir : quels champs, de quel type, lesquels sont obligatoires. Un `enum`, c'est une case à cocher parmi une liste fermée. Le mode **strict**, c'est un bon de commande que le système **refuse d'émettre** s'il est mal rempli : indispensable quand l'outil écrit dans une base.

```mission
{
  "title": "Chasse au schéma : retrouvez la structure officielle d'une définition d'outil",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/tool-use/define-tools",
  "steps": ["Ouvrez la page « Define tools »", "Repérez le premier exemple de définition d'outil (souvent un outil météo)", "Relevez les trois champs de premier niveau de la définition, puis lisez le passage sur la longueur conseillée de la description"],
  "question": "Quels sont les trois champs de premier niveau d'une définition d'outil client, et combien de phrases la doc recommande-t-elle au minimum pour la description ?",
  "hint": "L'un des champs contient un JSON Schema ; comparez avec OUTILS dans le code ci-dessus.",
  "answer": "name, description et input_schema (un objet JSON Schema avec type, properties, required) ; la doc recommande une description détaillée d'au moins 3 à 4 phrases (page consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. La boucle agentique complète

### 3.1 Python

```python
# boucle_outils.py — agent « secrétariat du plombier » avec deux outils, boucle jusqu'à end_turn
import json
from anthropic import Anthropic
from outils import OUTILS

client = Anthropic()

# --- implémentations réelles (ici simulées) --------------------------------
STOCK = {"J40": (12, "étagère B3"), "J32": (0, "étagère B2"), "RB15": (4, "bac C1")}
AGENDA = {"2026-11-06": ["09:00-11:00", "14:00-16:00"], "2026-11-07": []}

def verifier_stock(reference: str) -> str:
    q = STOCK.get(reference.upper())
    return "référence inconnue" if q is None else f"{q[0]} unité(s), {q[1]}"

def creneaux_disponibles(date: str) -> str:
    return json.dumps(AGENDA.get(date, []))

FONCTIONS = {"verifier_stock": verifier_stock, "creneaux_disponibles": creneaux_disponibles}

def executer(nom: str, args: dict) -> tuple[str, bool]:
    """Exécute l'outil ; renvoie (contenu, is_error)."""
    try:
        return FONCTIONS[nom](**args), False
    except Exception as e:           # on renvoie l'erreur à Claude plutôt que de planter
        return f"Erreur outil : {e}", True

# --- boucle ----------------------------------------------------------------
def agent(question: str, max_tours: int = 6) -> str:
    messages = [{"role": "user", "content": question}]
    total_in = total_out = 0
    for _ in range(max_tours):
        r = client.messages.create(
            model="claude-sonnet-5-5",
            max_tokens=1000,
            system="Vous êtes la secrétaire de Martin Plomberie (Rennes). Utilisez les outils avant d'affirmer "
                   "une disponibilité. Répondez en français, chaleureusement.",
            tools=OUTILS,
            messages=messages,
        )
        total_in += r.usage.input_tokens; total_out += r.usage.output_tokens
        messages.append({"role": "assistant", "content": r.content})   # on garde les blocs tels quels

        if r.stop_reason != "tool_use":
            texte = "".join(b.text for b in r.content if b.type == "text")
            print(f"[coût ≈ {(total_in*2 + total_out*10)/1e6:.4f} $]")
            return texte

        # Un ou plusieurs blocs tool_use (appels parallèles) : on renvoie TOUS les résultats dans UN message user
        resultats = []
        for bloc in r.content:
            if bloc.type == "tool_use":
                contenu, erreur = executer(bloc.name, bloc.input)
                print(f"  ↳ {bloc.name}({bloc.input}) → {contenu}")
                resultats.append({"type": "tool_result", "tool_use_id": bloc.id,
                                  "content": contenu, "is_error": erreur})
        messages.append({"role": "user", "content": resultats})
    return "Désolé, je n'ai pas pu conclure (trop d'étapes)."

if __name__ == "__main__":
    print(agent("Bonjour, il me faut un joint de 40 mm et un rendez-vous le 6 novembre matin. Possible ?"))
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `from outils import OUTILS` : récupère les descriptions d'outils du fichier précédent (même dossier).
> - `STOCK.get(reference.upper())` : cherche la référence en majuscules ; `.get` renvoie `None` (rien) si elle n'existe pas, au lieu de planter. `q[0]` et `q[1]` sont la quantité et l'emplacement du couple `(12, "étagère B3")`.
> - `FONCTIONS = {"verifier_stock": verifier_stock, …}` : un dictionnaire qui associe le **nom** demandé par Claude à la **vraie fonction** Python ; `FONCTIONS[nom](**args)` appelle la bonne fonction avec les arguments fournis par Claude.
> - `try: … except Exception as e:` dans `executer` : si l'outil plante, on renvoie le message d'erreur à Claude (avec `True` pour `is_error`) au lieu d'arrêter le programme.
> - `for _ in range(max_tours):` : au plus 6 allers-retours ; `_` signale qu'on n'utilise pas le numéro du tour.
> - `messages.append({"role": "assistant", "content": r.content})` : on recopie la réponse de Claude **telle quelle**, blocs `tool_use` compris : l'API en a besoin pour relier chaque résultat à sa demande.
> - `if r.stop_reason != "tool_use":` : Claude n'a plus besoin d'outil, on renvoie son texte final. Sinon, on exécute chaque bloc `tool_use` et on renvoie **tous** les `tool_result` (reliés par `tool_use_id`) dans **un seul** message `user`.

### 3.2 TypeScript

```typescript
// boucle_outils.ts — même agent en TypeScript
import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic();

const STOCK: Record<string, [number, string]> = { J40: [12, "étagère B3"], J32: [0, "étagère B2"] };
const AGENDA: Record<string, string[]> = { "2026-11-06": ["09:00-11:00", "14:00-16:00"] };

const outils: Anthropic.Tool[] = [
  {
    name: "verifier_stock",
    description: "Vérifie la quantité disponible d'une pièce à partir de sa référence interne (ex. 'J40'). À utiliser pour toute question de disponibilité. Renvoie quantité et emplacement, ou 'référence inconnue'.",
    input_schema: { type: "object", properties: { reference: { type: "string", description: "Référence interne, majuscules" } }, required: ["reference"] },
  },
  {
    name: "creneaux_disponibles",
    description: "Liste les créneaux libres pour une date AAAA-MM-JJ. Renvoie une liste vide si la journée est pleine.",
    input_schema: { type: "object", properties: { date: { type: "string", description: "Date ISO 8601" } }, required: ["date"] },
  },
];

function executer(nom: string, args: any): { contenu: string; erreur: boolean } {
  try {
    if (nom === "verifier_stock") {
      const q = STOCK[String(args.reference).toUpperCase()];
      return { contenu: q ? `${q[0]} unité(s), ${q[1]}` : "référence inconnue", erreur: false };
    }
    if (nom === "creneaux_disponibles") return { contenu: JSON.stringify(AGENDA[args.date] ?? []), erreur: false };
    return { contenu: `outil inconnu : ${nom}`, erreur: true };
  } catch (e) { return { contenu: `Erreur outil : ${e}`, erreur: true }; }
}

async function agent(question: string, maxTours = 6): Promise<string> {
  const messages: Anthropic.MessageParam[] = [{ role: "user", content: question }];
  for (let i = 0; i < maxTours; i++) {
    const r = await client.messages.create({
      model: "claude-sonnet-5-5", max_tokens: 1000,
      system: "Vous êtes la secrétaire de Martin Plomberie (Rennes). Utilisez les outils avant d'affirmer une disponibilité.",
      tools: outils, messages,
    });
    messages.push({ role: "assistant", content: r.content });
    if (r.stop_reason !== "tool_use") {
      return r.content.filter((b) => b.type === "text").map((b) => (b as Anthropic.TextBlock).text).join("");
    }
    const resultats: Anthropic.ToolResultBlockParam[] = [];
    for (const bloc of r.content) {
      if (bloc.type === "tool_use") {
        const { contenu, erreur } = executer(bloc.name, bloc.input);
        console.log(`  ↳ ${bloc.name}(${JSON.stringify(bloc.input)}) → ${contenu}`);
        resultats.push({ type: "tool_result", tool_use_id: bloc.id, content: contenu, is_error: erreur });
      }
    }
    messages.push({ role: "user", content: resultats });
  }
  return "Désolé, trop d'étapes.";
}

agent("Il me faut un joint de 40 mm et un rendez-vous le 6 novembre matin. Possible ?").then(console.log);
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `Record<string, [number, string]>` : type TypeScript « dictionnaire dont les clés sont du texte et les valeurs un couple (nombre, texte) ».
> - `const outils: Anthropic.Tool[]` : la même description d'outils qu'en Python, typée par le SDK : une faute de nom de champ est soulignée par l'éditeur.
> - `args: any` : on accepte n'importe quelle forme d'arguments (Claude les fournit) ; `String(args.reference).toUpperCase()` force en texte majuscule.
> - `AGENDA[args.date] ?? []` : `??` signifie « si la valeur n'existe pas, prends `[]` » (liste vide).
> - `(b as Anthropic.TextBlock).text` : `as` rassure TypeScript sur le type exact du bloc, déjà filtré juste avant.
> - `const { contenu, erreur } = executer(…)` : *déstructuration* ; on range directement les deux champs de l'objet renvoyé dans deux variables.
> - `agent(…).then(console.log)` : lance l'agent, puis affiche son résultat quand la promesse est tenue (équivalent de `await` hors d'une fonction `async`).

Points de la page [Handle tool calls](https://platform.claude.com/docs/en/agents-and-tools/tool-use/handle-tool-calls) illustrés ici :
- on conserve le bloc `assistant` **tel quel** (texte + `tool_use`) dans l'historique ;
- **tous** les `tool_result` d'un même tour vont dans **un seul** message `user`, dans l'ordre des `tool_use_id` ;
- `is_error: true` signale un échec à Claude, qui pourra réessayer ou expliquer ;
- un **plafond de tours** évite la boucle infinie et borne le coût.

> 🛠️ **Si ça ne marche pas** —
> - `ModuleNotFoundError: No module named 'outils'` → `outils.py` n'est pas dans le même dossier que `boucle_outils.py` → rangez-les ensemble et lancez depuis ce dossier.
> - Erreur 400 `tool_use ids were found without tool_result blocks` → un `tool_result` manque, ou les résultats ont été répartis sur plusieurs messages → un seul message `user`, un `tool_result` par `tool_use_id`, et rien d'autre avant eux dans ce message.
> - Erreur 400 qui cite `tool_choice` → vous forcez l'appel (`any` ou `tool`) : Opus 5.5 et Sonnet 5.5 le refusent ; Haiku 5.5 l'accepte, mais sa réponse commence alors directement par l'appel d'outil, sans bloc de réflexion → laissez `tool_choice` en `auto`.
> - La réponse finale est « Désolé, je n'ai pas pu conclure » → plafond de 6 tours atteint, souvent parce qu'un outil renvoie toujours une erreur → lisez les lignes `↳` affichées : elles montrent chaque appel et son résultat.
> - Claude invente une disponibilité sans appeler l'outil → description trop vague ou system prompt muet → voir le tableau de dépannage de la section 6.

> ⚠️ **Piège fréquent** — Le mode « forcé » (`tool_choice: {"type": "any"}` ou `{"type": "tool", "name": …}`) qui obligeait Claude à appeler un outil renvoie une **erreur 400 sur Opus 5.5 et Sonnet 5.5** ; Haiku 5.5 l'accepte, mais sa réponse commence alors directement par l'appel d'outil, sans bloc de réflexion (guides de migration des modèles 5.5, nov. 2026). Pour un code qui fonctionne sur les trois modèles, laissez `tool_choice` en `auto` (défaut) et obtenez le comportement voulu par la description de l'outil et le system prompt ; pour imposer un JSON, utilisez les sorties structurées (L071). `{"type": "none"}` reste utile pour désactiver temporairement les outils.


```quiz
{
  "q": "Claude a demandé deux outils dans la même réponse (stock et agenda). Comment renvoyez-vous les résultats ?",
  "options": ["Un seul tool_result qui regroupe les deux résultats en texte", "Un seul message assistant qui contient les deux résultats d'outils", "Seulement le premier résultat : Claude redemandera le second", "Un message user avec deux tool_result et leurs tool_use_id"],
  "answer": 3,
  "explanation": "Tous les tool_result d'un même tour vont dans un seul message user, chacun relié par son tool_use_id. En oublier un provoque l'erreur 400 « tool_use ids were found without tool_result »."
}
```

## 4. Appels parallèles et coût

Claude 5.5 peut émettre **plusieurs blocs `tool_use` dans une même réponse** quand les appels sont indépendants (vérifier le stock *et* l'agenda). La page [Parallel tool use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/parallel-tool-use) conseille d'y encourager Claude dans le system prompt (« Quand plusieurs outils sont indépendants, appelez-les en parallèle ») : cela divise le nombre de tours, donc la latence et le coût. Dans nos boucles, `asyncio.gather` (Python) ou `Promise.all` (TypeScript) exécutent les outils simultanément.

**Coût d'une boucle.** Chaque tour renvoie tout l'historique, définitions d'outils comprises (quelques centaines de tokens par outil). Une conversation de 4 tours avec 6 outils et 3 000 tokens de contexte coûte environ 4 × 3 500 = 14 000 tokens d'entrée, soit **0,028 $** avec Sonnet 5.5 et **0,0014 $** avec Haiku 5.5. La page [Tool use with prompt caching](https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-use-with-prompt-caching) montre comment mettre les définitions d'outils en cache (L073) : sur une boucle longue, le coût d'entrée chute de 90 %.

> 💡 **Autrement dit** — À chaque aller-retour du commis, le chef relit **toute la fiche recette depuis le début**, y compris la liste des courses possibles (les définitions d'outils). Moins de tours = moins de relectures = facture plus basse. D'où deux leviers : demander à Claude de lancer les appels indépendants **en même temps** (parallèle) et mettre en cache ce qui ne change pas (L073).

## 5. Les familles d'outils (nov. 2026)

| Famille | Qui exécute ? | Exemples | Page |
|---|---|---|---|
| **Outils client** (custom) | votre code | `verifier_stock`, requête SQL, appel ERP | define-tools |
| **Outils serveur** | Anthropic, dans la même requête | `web_search` (10 $ / 1 000 recherches), `web_fetch` (gratuit), `code_execution` (1 550 h gratuites/mois puis 0,05 $/h) | [Server tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/server-tools) |
| **Outils intégrés Anthropic** (définis par Anthropic, exécutés par vous) | votre code / sandbox | `bash`, `text_editor`, `computer` (computer use), `browser` (browser use), `memory` | bash-tool, text-editor-tool, computer-use-tool, browser-use-tool, memory-tool |
| **Méta-outils** | mixte | `tool_search` (charger des définitions à la demande parmi des centaines), `advisor` | tool-search-tool, advisor-tool |

```python
# web_search.py — outil serveur : Claude cherche sur le web, Anthropic exécute (10 $ / 1 000 recherches, nov. 2026)
from anthropic import Anthropic
client = Anthropic()
r = client.messages.create(
    model="claude-sonnet-5-5", max_tokens=800,
    tools=[{"type": "web_search_20250305", "name": "web_search", "max_uses": 3}],
    messages=[{"role": "user", "content": "Quel est le taux horaire moyen d'un plombier à Rennes en 2026 ? Cite tes sources."}],
)
for b in r.content:
    if b.type == "text": print(b.text)
print("recherches facturées :", r.usage.server_tool_use.web_search_requests if r.usage.server_tool_use else 0)
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Ici, pas de boucle : un outil **serveur** est exécuté par Anthropic pendant la requête elle-même, et la réponse arrive déjà rédigée, sources comprises. `"type": "web_search_20250305"` désigne la version de l'outil (la date fait partie du nom), `"max_uses": 3` plafonne le nombre de recherches (donc la facture). `r.usage.server_tool_use.web_search_requests` donne le nombre de recherches facturées ; le `if … else 0` évite une erreur quand aucune recherche n'a eu lieu. Si l'appel est refusé alors que le code est juste, l'outil de recherche web n'est peut-être pas activé pour votre organisation : vérifiez les réglages de la Console avec un administrateur.

Le type exact de l'outil serveur (ici `web_search_20250305`) est versionné : vérifiez le nom courant sur la page [Web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool) avant de copier.

Deux fonctionnalités avancées à connaître pour la certification : le **programmatic tool calling** (Claude écrit du code qui appelle vos outils dans un sandbox, réduisant les allers-retours ; page `programmatic-tool-calling`) et le **fine-grained tool streaming** (recevoir les arguments d'un outil en flux avant la fin de la génération, utile pour afficher une requête SQL pendant qu'elle s'écrit ; page `fine-grained-tool-streaming`).

> 💡 **Autrement dit** — Avec le *programmatic tool calling*, au lieu d'envoyer le commis dix fois au magasin, le chef lui **écrit une liste de courses complète** (un petit programme) qu'il exécute d'une traite dans un espace isolé (*sandbox*) : moins d'allers-retours. Le *fine-grained tool streaming*, c'est entendre la commande du chef **pendant qu'il la dicte**, mot par mot, au lieu d'attendre qu'il ait fini.

```quiz
{
  "type": "vrai_faux",
  "q": "Avec l'outil serveur web_search, c'est votre application qui doit exécuter la recherche web puis renvoyer un tool_result.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : les outils serveur (web_search, web_fetch, code_execution) sont exécutés par Anthropic dans la même requête. Vous recevez directement la réponse, et la facture compte les recherches effectuées."
}
```

```mission
{
  "title": "Combien coûtent 1 000 recherches web faites par Claude ?",
  "url": "https://platform.claude.com/docs/en/about-claude/pricing",
  "steps": ["Ouvrez la page Pricing", "Descendez jusqu'aux tarifs des outils (tool use pricing / server tools)", "Relevez le prix de web search, puis celui de web fetch"],
  "question": "Quel est le prix de l'outil web search pour 1 000 recherches, et combien coûte web fetch ?",
  "hint": "L'un des deux outils est gratuit : seuls les tokens du contenu récupéré sont facturés.",
  "answer": "Web search : 10 $ pour 1 000 recherches ; web fetch : gratuit (hors tokens) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

### 5.1 Le « tool runner » du SDK

Les SDK v2 proposent un **tool runner** (page [Tool runner](https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-runner)) qui exécute la boucle de la section 3 pour vous : vous déclarez des fonctions typées (Pydantic en Python, Zod en TypeScript : deux bibliothèques qui décrivent la forme attendue d'une donnée, champ par champ, et la vérifient ; le SDK en déduit le JSON Schema à votre place), le SDK génère le schéma, appelle vos fonctions et renvoie les résultats jusqu'à `end_turn`. C'est le chemin le plus court pour un prototype ; la boucle manuelle reste indispensable pour comprendre ce qui se passe et pour contrôler finement permissions et coûts. Consultez la page officielle pour la signature exacte dans votre version du SDK.

## 6. Dépannage

La page [Troubleshooting tool use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/troubleshooting-tool-use) recense les symptômes classiques :

| Symptôme | Cause probable | Remède |
|---|---|---|
| Claude répond sans appeler l'outil | description vague ; system prompt qui ne dit pas quand l'utiliser | réécrire la description (quand / quand pas) ; ajouter « Vérifiez toujours le stock avant de répondre » |
| Arguments manquants ou mal typés | schéma sans `description` ni `required` | documenter chaque propriété ; activer `strict: true` |
| Erreur 400 « tool_use ids were found without tool_result » | un `tool_result` oublié ou envoyé dans le mauvais message | renvoyer **tous** les résultats, dans un seul message `user` |
| Boucle qui ne s'arrête pas | outil qui renvoie toujours une erreur ; pas de plafond | plafond de tours ; `is_error` + message explicite |
| Coût élevé | définitions d'outils renvoyées à chaque tour | caching des outils (L073) ; `tool_search` si > 20 outils |

> 💡 **À retenir** — Le tool use est le fondement de **tout** l'agentique chez Anthropic : Claude Code, l'Agent SDK, les Managed Agents et MCP (L075) ne sont que des manières d'industrialiser la boucle que vous venez d'écrire à la main.


🎮 **Défi** — Rédigez la description de l'outil `tarif_piece` (mentionné dans `verifier_stock`) en 4 phrases maximum : ce qu'il fait, quand l'utiliser, quand **ne pas** l'utiliser, ce qu'il renvoie. Faites-la relire par un collègue qui ne connaît pas le projet : s'il devine sans hésiter quand l'outil doit être appelé, Claude le devinera aussi.

## 🧪 Exercice pratique

**Consigne.** Étendez l'agent du plombier avec un troisième outil `creer_rendez_vous(date, creneau, client, motif)` qui **écrit** dans l'agenda (dictionnaire en mémoire ou fichier JSON). Exigences :
1. `strict: true` sur cet outil ; `motif` est un `enum` (`fuite`, `installation`, `entretien`, `autre`).
2. Avant toute écriture, votre code demande une confirmation humaine dans le terminal (`input("Confirmer ? o/n")`) : si refus, renvoyez un `tool_result` avec `is_error: true` et le message « refusé par l'opérateur ».
3. Gérez les appels parallèles (stock + agenda) avec `asyncio` ou `Promise.all`.
4. Affichez le coût cumulé de la conversation.

**Critères de réussite.** Le rendez-vous n'est créé qu'après confirmation ; un refus produit une réponse polie de Claude ; aucun crash sur une référence inconnue ; le script fonctionne en Python et en TypeScript.

<details>
<summary>Pistes</summary>

- Pour les appels parallèles en Python, passez par `AsyncAnthropic` et `await asyncio.gather(*[executer(b) for b in blocs])`.
- La confirmation humaine est un « point de contrôle HITL » (human-in-the-loop) que vous retrouverez dans les permissions de Claude Code et de l'Agent SDK (L074).
</details>

## ✅ Auto-évaluation express

1. Qui exécute un outil « client » : Anthropic ou votre code ?
2. Que doit contenir le message `user` qui suit une réponse avec deux blocs `tool_use` ?
3. Que se passe-t-il si vous forcez `tool_choice: {"type": "any"}` sur Claude Sonnet 5.5 ?

**Réponses.** 1. Votre code ; Claude ne produit qu'une demande structurée. 2. Deux blocs `tool_result` (un par `tool_use_id`), dans un seul message. 3. Une erreur 400 : Opus 5.5 et Sonnet 5.5 refusent le mode forcé (`any` ou `tool`) ; seul Haiku 5.5 l'accepte, sans bloc de réflexion. Utilisez plutôt les descriptions d'outils ou les sorties structurées.

> ✅ **Si vous ne retenez que 3 choses** — 1. Claude n'exécute jamais un outil client : il remplit une demande (`tool_use`) d'après la description et le schéma, votre code l'exécute et renvoie un `tool_result`. 2. La boucle tourne jusqu'à ce que `stop_reason` ne soit plus `tool_use`, avec un plafond de tours ; tous les résultats d'un tour partent dans un seul message `user`. 3. La description de l'outil (quand l'utiliser, quand ne pas l'utiliser, ce qu'il renvoie) compte plus que le schéma ; `strict: true` pour les outils qui écrivent.

## 📚 Pour aller plus loin
- [Tool use overview](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview) 🇬🇧 — l'index des 27 sous-pages (outils intégrés, serveur, streaming, caching…).
- [Build a tool-using agent](https://platform.claude.com/docs/en/agents-and-tools/tool-use/build-a-tool-using-agent) 🇬🇧 — tutoriel officiel pas à pas.
- [Tool combinations](https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-combinations) 🇬🇧 — quels outils peuvent coexister dans une requête.
- [Memory tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool) 🇬🇧 — mémoire persistante entre sessions pour vos agents.
- [Cookbook — Tool use : extracting structured JSON](https://platform.claude.com/cookbook/tool-use-extracting-structured-json) 🇬🇧 — recette officielle, pont vers la leçon suivante.

> 🗺️ **Et maintenant ?** — Le commis rapporte des ingrédients ; la leçon L071 vous apprend à exiger de Claude une réponse au format parfaitement prévisible (JSON validé par un schéma), prête à être enregistrée dans votre base.
