---
id: L071
module: M17
level: N3
title: "Sorties structurées et JSON fiable"
minutes: 45
objectives:
  - "Obtenir un JSON conforme à un schéma avec output_config.format (json_schema) et les helpers parse() / Pydantic / Zod"
  - "Comparer les trois approches (prompt seul, outil « extracteur », sorties structurées natives) et choisir selon le cas"
  - "Valider et post-traiter la sortie, gérer les refus et les troncatures, et connaître les incompatibilités (citations, préremplissage)"
skills: ["C3.2"]
sources:
  - { title: "Claude Platform — Structured outputs", url: "https://platform.claude.com/docs/en/build-with-claude/structured-outputs", lang: "en" }
  - { title: "Claude Platform — Strict tool use", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use", lang: "en" }
  - { title: "Claude Platform — Handling stop reasons", url: "https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons", lang: "en" }
  - { title: "Claude Cookbook — Extracting structured JSON with tool use", url: "https://platform.claude.com/cookbook/tool-use-extracting-structured-json", lang: "en" }
  - { title: "Claude Platform — Prompting best practices (Control the format)", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
---

# Sorties structurées et JSON fiable

> ⏱ 45 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Faire produire à Claude un JSON **garanti conforme** à un schéma, sans regex ni `try/except json.loads`.
- Utiliser `output_config.format` à la main, puis les helpers `client.messages.parse()` (Pydantic) et `zodOutputFormat` (Zod) des SDK v2.
- Savoir quand une sortie structurée est le bon outil, quand un outil « extracteur » est préférable, et quand un simple prompt suffit.
- Anticiper les cas limites : refus, `max_tokens`, schémas trop complexes, incompatibilité avec les citations.

> 🧭 **En clair** — Demander « réponds en JSON » à Claude, c'est comme demander à quelqu'un d'écrire une lettre « bien rangée » : la plupart du temps ça marche, mais un jour il ajoute un mot d'introduction et votre logiciel ne sait plus la lire. Les **sorties structurées**, c'est lui tendre **un formulaire Cerfa avec des cases** : nom ici, date là, montant dans cette case, et rien en dehors des cases. Le *JSON* est simplement un format texte de données rangées (des étiquettes et des valeurs), et le *schéma* est le plan du formulaire. Attention : le formulaire garantit que **chaque case est remplie au bon format**, pas que ce qui est écrit dedans est **vrai**. Vous gardez donc toujours une relecture métier (le total est-il juste ?).

## 1. Pourquoi le JSON « à la main » finit toujours par casser

Vous avez tous écrit ce code : « Réponds uniquement en JSON », puis `json.loads(reponse)`. Et un jour, Claude ajoute « Voici le JSON demandé : », ou un commentaire, ou une virgule finale, et votre pipeline de 50 000 factures s'arrête à la facture 3 412 à 2 h du matin. Le problème n'est pas la qualité du modèle, c'est **l'absence de contrat**.

Trois approches existent en nov. 2026 :

| Approche | Garantie | Quand l'utiliser |
|---|---|---|
| **Prompt + description du format** | aucune (le modèle « fait de son mieux ») | prototypes, sorties lues par un humain |
| **Outil « extracteur »** avec `strict: true` (L070) | arguments de l'outil conformes au schéma | quand l'extraction est **une étape** d'un agent avec d'autres outils |
| **Sorties structurées natives** (`output_config.format`) | **réponse finale** conforme au schéma JSON | extraction, classification, formulaires, tout pipeline qui parse |

La page officielle [Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) décrit la troisième : vous fournissez un schéma JSON dans `output_config.format` (type `json_schema`) ; l'API contraint la génération pour que le texte renvoyé **soit** un document JSON valide conforme au schéma.

> 💡 **Autrement dit** — « Contraindre la génération », c'est comme un clavier dont certaines touches se bloquent : à chaque mot, Claude ne peut écrire **que** ce que le schéma autorise à cet endroit (une accolade, un nom de champ attendu, un nombre…). Le résultat ne peut donc pas sortir du formulaire.

## 2. Sorties structurées natives : la forme brute

```python
# structured_raw.py — extraction d'un devis d'artisan vers un JSON conforme à un schéma
import json
from anthropic import Anthropic

client = Anthropic()

SCHEMA = {
    "type": "object",
    "properties": {
        "client": {"type": "string", "description": "Nom du client tel qu'écrit sur le devis"},
        "date": {"type": "string", "description": "Date du devis au format AAAA-MM-JJ"},
        "lignes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "designation": {"type": "string"},
                    "quantite": {"type": "number"},
                    "prix_unitaire_ht": {"type": "number"},
                },
                "required": ["designation", "quantite", "prix_unitaire_ht"],
                "additionalProperties": False,
            },
        },
        "tva_pct": {"type": "number", "enum": [5.5, 10, 20]},
        "total_ht": {"type": "number"},
        "incertitudes": {"type": "array", "items": {"type": "string"},
                         "description": "Champs illisibles ou ambigus ; vide si tout est clair"},
    },
    "required": ["client", "date", "lignes", "tva_pct", "total_ht", "incertitudes"],
    "additionalProperties": False,
}

DEVIS = """DEVIS n° 2026-117 — 3 novembre 2026
Client : SCI Les Tilleuls
Remplacement chauffe-eau 200 L : 1 x 689,00 € HT
Main d'œuvre : 3 h x 55,00 € HT
Évacuation ancien appareil : 1 x 40,00 € HT
TVA 10 % (logement > 2 ans)"""

r = client.messages.create(
    model="claude-sonnet-5-5",
    max_tokens=800,
    system="Vous extrayez des données de devis d'artisans français. N'inventez aucune valeur : "
           "signalez les doutes dans 'incertitudes'.",
    messages=[{"role": "user", "content": DEVIS}],
    output_config={"format": {"type": "json_schema", "schema": SCHEMA}},
)

assert r.stop_reason == "end_turn", f"réponse incomplète : {r.stop_reason}"
donnees = json.loads(r.content[0].text)    # garanti parsable et conforme
print(json.dumps(donnees, ensure_ascii=False, indent=2))

# Contrôle métier (le schéma garantit la FORME, pas la VÉRITÉ) :
calcule = sum(l["quantite"] * l["prix_unitaire_ht"] for l in donnees["lignes"])
if abs(calcule - donnees["total_ht"]) > 0.01:
    print(f"⚠️ total incohérent : {calcule:.2f} vs {donnees['total_ht']:.2f}")
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `SCHEMA = {…}` : le plan du formulaire, en JSON Schema (pré-requis express en L070). `"type": "array"` + `"items": {…}` décrit une **liste** dont chaque élément suit le sous-schéma donné (ici, une ligne de devis).
> - `"additionalProperties": False` : interdit tout champ non prévu. En Python on écrit `False` (majuscule) ; dans le JSON envoyé, le SDK le transforme en `false`.
> - `"enum": [5.5, 10, 20]` : la TVA ne peut prendre que ces trois valeurs.
> - `output_config={"format": {"type": "json_schema", "schema": SCHEMA}}` : la ligne qui active la sortie structurée ; sans elle, c'est un appel ordinaire.
> - `assert r.stop_reason == "end_turn", …` : arrête le programme avec ce message si la réponse est incomplète (un JSON coupé par `max_tokens` serait illisible).
> - `json.loads(r.content[0].text)` : transforme le texte JSON en dictionnaire Python ; `json.dumps(..., ensure_ascii=False, indent=2)` fait l'inverse, pour un affichage lisible avec les accents.
> - `sum(l["quantite"] * l["prix_unitaire_ht"] for l in donnees["lignes"])` : recalcule le total ligne par ligne ; `abs(…) > 0.01` tolère un centime d'écart dû aux arrondis.

```typescript
// structured_raw.ts — même extraction en TypeScript
import Anthropic from "@anthropic-ai/sdk";
const client = new Anthropic();

const schema = {
  type: "object",
  properties: {
    client: { type: "string" },
    date: { type: "string", description: "AAAA-MM-JJ" },
    lignes: { type: "array", items: { type: "object",
      properties: { designation: { type: "string" }, quantite: { type: "number" }, prix_unitaire_ht: { type: "number" } },
      required: ["designation", "quantite", "prix_unitaire_ht"], additionalProperties: false } },
    tva_pct: { type: "number", enum: [5.5, 10, 20] },
    total_ht: { type: "number" },
    incertitudes: { type: "array", items: { type: "string" } },
  },
  required: ["client", "date", "lignes", "tva_pct", "total_ht", "incertitudes"],
  additionalProperties: false,
} as const;

async function main() {
  const r = await client.messages.create({
    model: "claude-sonnet-5-5", max_tokens: 800,
    system: "Vous extrayez des données de devis d'artisans français. N'inventez aucune valeur.",
    messages: [{ role: "user", content: "DEVIS n° 2026-117 — 3 novembre 2026\nClient : SCI Les Tilleuls\nRemplacement chauffe-eau 200 L : 1 x 689,00 € HT\nMain d'œuvre : 3 h x 55,00 € HT\nTVA 10 %" }],
    output_config: { format: { type: "json_schema", schema } },
  });
  if (r.stop_reason !== "end_turn") throw new Error(`réponse incomplète : ${r.stop_reason}`);
  const bloc = r.content[0];
  const donnees = JSON.parse(bloc.type === "text" ? bloc.text : "{}");
  console.log(donnees);
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Le schéma est le même, écrit en objet JavaScript (`false` en minuscule cette fois). `as const` demande à TypeScript de garder les valeurs **exactes** (`"object"` et non « n'importe quel texte »), ce que le SDK exige pour accepter le schéma. `throw new Error(…)` arrête le programme si la réponse est incomplète ; `JSON.parse(…)` transforme le texte JSON en objet JavaScript, et `bloc.type === "text" ? bloc.text : "{}"` évite de lire `.text` sur un bloc qui n'en a pas.

> 💡 **À retenir** — Une sortie structurée garantit la **forme** (le JSON est valide et respecte le schéma), jamais le **fond** (les valeurs peuvent être fausses). Gardez toujours un contrôle métier (totaux, dates plausibles, références existantes) et un champ « incertitudes » pour que le modèle puisse avouer un doute au lieu d'inventer.


```quiz
{
  "type": "vrai_faux",
  "q": "Si la réponse respecte le schéma JSON (stop_reason = end_turn), alors le total_ht extrait du devis est forcément juste.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : le schéma garantit la forme (JSON valide, bons types, champs requis), jamais le fond. Un contrôle métier (recalcul du total, dates plausibles) reste indispensable."
}
```

```mission
{
  "title": "Chasse au paramètre : où se déclare le schéma d'une sortie structurée ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/structured-outputs",
  "steps": ["Ouvrez la page « Structured outputs »", "Repérez le premier exemple de requête en Python ou en cURL", "Notez le nom du paramètre racine, de son sous-champ et la valeur de type utilisée, puis le nom de la méthode helper du SDK Python"],
  "question": "Quel paramètre (et quel sous-champ) reçoit le schéma, quelle valeur de type faut-il indiquer, et quelle méthode du SDK Python le génère pour vous ?",
  "hint": "Le paramètre commence par « output_ » ; la méthode helper a un nom très court.",
  "answer": "output_config.format avec type json_schema ; helper client.messages.parse() (documentation consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Les helpers des SDK v2 : Pydantic et Zod

Écrire un schéma JSON à la main est fastidieux et source d'erreurs. Les SDK v2 fournissent `client.messages.parse()` (Python, avec un modèle Pydantic) et `zodOutputFormat` (TypeScript, avec un schéma Zod) : le schéma est généré, la réponse est validée et désérialisée en objet typé.

> 🧭 **Pré-requis express — Pydantic et Zod** — Ce sont deux bibliothèques de **validation de données** : on décrit une fois la forme d'un objet, et la bibliothèque vérifie qu'une donnée reçue la respecte.
> - **Pydantic** (Python) : on écrit une classe qui hérite de `BaseModel` et on liste ses champs avec leur type (`client: str`, `lignes: list[Ligne]`). `Field(description=…)` ajoute une explication, `default_factory=list` donne une liste vide par défaut.
> - **Zod** (TypeScript) : on construit le schéma avec des fonctions (`z.object({…})`, `z.string()`, `z.array(…)`, `.describe(…)`).
> - Dans les deux cas, la bibliothèque sait **produire le JSON Schema** correspondant : vous n'écrivez plus le gros dictionnaire de la section 2.
> - Et elle **contrôle** la réponse : si un champ manque ou n'a pas le bon type, vous obtenez une erreur claire au lieu d'une donnée bancale.
> - Installation : Pydantic arrive déjà avec le SDK `anthropic` ; Zod s'installe avec `npm install zod`.

```python
# structured_pydantic.py — extraction typée avec client.messages.parse() et Pydantic
from pydantic import BaseModel, Field
from anthropic import Anthropic

client = Anthropic()

class Ligne(BaseModel):
    designation: str
    quantite: float
    prix_unitaire_ht: float

class Devis(BaseModel):
    client: str
    date: str = Field(description="AAAA-MM-JJ")
    lignes: list[Ligne]
    tva_pct: float
    total_ht: float
    incertitudes: list[str] = Field(default_factory=list)

r = client.messages.parse(
    model="claude-sonnet-5-5",
    max_tokens=800,
    system="Vous extrayez des données de devis d'artisans français. N'inventez aucune valeur.",
    messages=[{"role": "user", "content": "DEVIS du 3 nov. 2026, client Boulangerie Martin : "
                                           "pétrin 1 x 2 400 € HT, livraison 1 x 120 € HT, TVA 20 %"}],
    output_format=Devis,          # le SDK génère le json_schema et valide la réponse
)
devis: Devis = r.parsed_output    # objet Pydantic typé (nom de l'attribut : voir la doc de votre version du SDK)
print(devis.client, devis.total_ht, [l.designation for l in devis.lignes])
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `class Ligne(BaseModel):` puis `class Devis(BaseModel):` : deux « moules » ; un devis contient une liste de lignes (`lignes: list[Ligne]`).
> - `client.messages.parse(..., output_format=Devis)` : comme `create`, mais le SDK fabrique le JSON Schema à partir de la classe `Devis`, l'envoie, puis **vérifie** la réponse.
> - `r.parsed_output` : la réponse déjà transformée en objet `Devis` ; on lit directement `devis.client` ou `devis.total_ht`, sans `json.loads`.
> - `[l.designation for l in devis.lignes]` : une compréhension de liste qui récupère la désignation de chaque ligne.

```typescript
// structured_zod.ts — extraction typée avec Zod (SDK TypeScript v2)
import Anthropic from "@anthropic-ai/sdk";
import { zodOutputFormat } from "@anthropic-ai/sdk/helpers/zod";
import { z } from "zod";

const client = new Anthropic();

const Devis = z.object({
  client: z.string(),
  date: z.string().describe("AAAA-MM-JJ"),
  lignes: z.array(z.object({ designation: z.string(), quantite: z.number(), prix_unitaire_ht: z.number() })),
  tva_pct: z.number(),
  total_ht: z.number(),
  incertitudes: z.array(z.string()),
});

async function main() {
  const r = await client.messages.parse({
    model: "claude-sonnet-5-5", max_tokens: 800,
    system: "Vous extrayez des données de devis d'artisans français. N'inventez aucune valeur.",
    messages: [{ role: "user", content: "DEVIS du 3 nov. 2026, client Boulangerie Martin : pétrin 1 x 2 400 € HT, livraison 1 x 120 € HT, TVA 20 %" }],
    output_format: zodOutputFormat(Devis),
  });
  const devis = r.parsed_output; // typé z.infer<typeof Devis>
  console.log(devis?.client, devis?.total_ht);
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `z.object({…})` décrit le devis champ par champ ; `zodOutputFormat(Devis)` le convertit au format attendu par l'API ; `client.messages.parse(…)` envoie la requête et valide la réponse. `r.parsed_output` est l'objet validé ; le `?.` de `devis?.client` signifie « lis `client` seulement si `devis` existe » (il vaut `null` en cas de refus, par exemple).

Les noms exacts des helpers (`parse`, `parsed_output`, chemin d'import de `zodOutputFormat`) sont ceux documentés sur la page Structured outputs en nov. 2026 ; en cas de divergence avec votre version du SDK, la forme brute de la section 2 fonctionne toujours.

> 🛠️ **Si ça ne marche pas** —
> - `Cannot find module 'zod'` → Zod n'est pas installé → `npm install zod` dans le dossier du projet.
> - `AttributeError: … has no attribute 'parse'` ou `parsed_output` introuvable → SDK trop ancien, ou nom d'attribut différent dans votre version → mettez à jour (`uv add "anthropic>=2.3"`), sinon revenez à la forme brute de la section 2, qui marche toujours.
> - `json.decoder.JSONDecodeError` → la réponse a été coupée (`stop_reason == "max_tokens"`) ou refusée (`refusal`) → testez `stop_reason` **avant** de parser et augmentez `max_tokens`.
> - Erreur 400 qui cite le schéma → mot-clé non supporté (`minimum`, motif `pattern` complexe, récursivité) → simplifiez le schéma et faites ces vérifications dans votre code (section 4).
> - `pydantic.ValidationError` → la donnée ne respecte pas le moule (souvent un champ obligatoire que le document ne contient pas) → rendez-le facultatif (`str | None = None`).

## 4. Règles, limites et incompatibilités

La page officielle précise plusieurs contraintes (nov. 2026) :

- **Sous-ensemble de JSON Schema** : objets, tableaux, chaînes, nombres, booléens, `enum`, `required`, `additionalProperties: false` sont supportés ; certaines contraintes (expressions régulières complexes, `minimum`/`maximum`, récursivité profonde) peuvent être ignorées ou refusées. Vérifiez la liste sur la page avant de concevoir un schéma exotique ; au besoin, validez les contraintes numériques dans votre code.
- **Incompatible avec les citations** (L072) et avec l'ancien préremplissage : une requête avec `citations` et `output_config.format` est refusée. Pour « extraire avec sources », faites deux appels, ou demandez des champs `citation_texte` dans le schéma.
- **Premier appel plus lent** : la contrainte de grammaire est compilée puis mise en cache côté Anthropic ; les appels suivants avec le même schéma sont rapides.
- **`stop_reason`** : si `max_tokens` est atteint, le JSON est tronqué (et donc invalide). Dimensionnez `max_tokens` selon la taille attendue ; en cas de `refusal`, il n'y a pas de JSON du tout. Testez toujours `stop_reason == "end_turn"`.
- **Streaming** : compatible ; vous recevez des `text_delta` qui forment progressivement le JSON (utile pour afficher un formulaire qui se remplit).
- **Classification** : un schéma `{"type": "object", "properties": {"categorie": {"enum": [...]}, "confiance": {"type": "number"}}}` avec Haiku 5.5 est la façon la moins chère (0,10 $/MTok en entrée) et la plus fiable de router des tickets, e-mails ou factures.

> 💡 **Autrement dit** — Le schéma accepte les « cases » courantes (texte, nombre, liste, choix dans une liste, oui/non) mais pas toutes les règles imaginables (« nombre entre 0 et 100 », « format très précis d'un numéro »). Ces règles fines, vérifiez-les vous-même dans votre code après réception. Et si `max_tokens` coupe la réponse, le formulaire est **déchiré en deux** : inutilisable.

> ⚠️ **Piège fréquent** — Mettre dans le schéma des champs que le document ne contient pas (« SIRET du client » sur un devis manuscrit). Comme le champ est `required`, le modèle **doit** le remplir… et invente. Rendez optionnels les champs incertains (`"type": ["string", "null"]`) ou ajoutez le champ « incertitudes ».


```quiz
{
  "q": "Votre requête combine output_config.format et des documents avec citations activées. Que se passe-t-il ?",
  "options": ["Les citations sont ajoutées dans un champ spécial du JSON produit", "Le schéma est ignoré et vous recevez du texte libre avec citations", "Les citations sont silencieusement désactivées, le JSON est renvoyé", "La requête est refusée : les deux fonctionnalités sont incompatibles"],
  "answer": 3,
  "explanation": "La documentation (nov. 2026) indique que sorties structurées et citations sont incompatibles : la requête est refusée. Solution : deux appels, ou des champs citation_texte dans votre schéma."
}
```

## 5. Choisir : sortie structurée ou outil extracteur ?

| Critère | Sortie structurée | Outil `strict` |
|---|---|---|
| La structure est la réponse finale | ✅ | ❌ (il faut un tour de plus) |
| L'extraction est une étape parmi d'autres outils | ❌ | ✅ |
| Besoin de citations sur les sources | ❌ (incompatible) | ✅ (ajoutez un champ) |
| Forçage de l'appel sur Claude 5.5 | n/a | ❌ sur Opus et Sonnet 5.5 (`tool_choice` forcé → erreur 400) ; accepté sur Haiku 5.5, sans réflexion |
| Simplicité du code | ✅ (`parse()`) | moyenne (boucle) |

La recette officielle [Extracting structured JSON with tool use](https://platform.claude.com/cookbook/tool-use-extracting-structured-json) montre l'approche « outil » ; depuis les sorties structurées natives, elle reste pertinente surtout à l'intérieur d'un agent.


```quiz
{
  "q": "Votre agent comptable utilise déjà trois outils (lire_facture, chercher_fournisseur, enregistrer_ecriture) et doit extraire des données à l'étape 2. Quelle approche choisir ?",
  "options": ["Un outil extracteur avec strict: true dans la boucle d'outils", "Une sortie structurée native à chaque tour de la boucle", "Un simple prompt « réponds en JSON » suivi de json.loads", "tool_choice forcé sur l'outil extracteur"],
  "answer": 0,
  "explanation": "Quand l'extraction est une étape parmi d'autres outils, l'outil strict s'intègre naturellement à la boucle. tool_choice forcé empêche la boucle de choisir ses autres outils (et renvoie une erreur 400 sur Opus 5.5 et Sonnet 5.5), et le JSON « au prompt » n'offre aucune garantie."
}
```

```mission
{
  "title": "Où placer strict: true dans une définition d'outil ?",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use",
  "steps": ["Ouvrez la page « Strict tool use »", "Repérez l'exemple de définition d'outil en mode strict", "Observez à quel niveau se trouve le champ strict, puis lisez ce que la page promet sur les arguments produits"],
  "question": "À quel niveau de la définition d'outil se place le champ strict, et que garantit-il ?",
  "hint": "Comparez avec les trois champs name / description / input_schema vus en L070.",
  "answer": "strict: true se place au premier niveau de la définition, à côté de name, description et input_schema ; il garantit que les arguments de l'appel respectent exactement le schéma (types, champs requis), avec un sous-ensemble de JSON Schema supporté (page consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

🎮 **Défi** — Faites classer 20 objets d'e-mails de PME (« Relance facture 2026-089 », « Candidature spontanée », « Panne serveur ») en `{"categorie": "compta" | "rh" | "it" | "commercial" | "autre", "urgence": 1-5}` avec Haiku 5.5. Calculez le coût : 20 e-mails × ~60 tokens = 1 200 tokens d'entrée ≈ **0,00012 $**. Oui, douze cent-millièmes de dollar.

## 🧪 Exercice pratique

**Consigne.** Construisez un **extracteur de CV** pour un cabinet de recrutement :
1. Schéma (Pydantic **et** Zod) : `nom`, `email` (nullable), `annees_experience` (nombre), `competences` (liste), `langues` (liste d'objets `{langue, niveau ∈ {A1…C2, natif}}`), `incertitudes`.
2. Testez sur 3 CV texte (dont un incomplet sans e-mail et un avec une expérience ambiguë).
3. Ajoutez un contrôle métier : si `annees_experience > 50` ou si une compétence apparaît en double, marquez le CV « à vérifier ».
4. Mesurez le coût total avec `usage` et comparez Haiku 5.5 / Sonnet 5.5 sur la qualité de l'extraction.

**Critères de réussite.** Aucun `json.loads` ne lève d'exception sur les 3 CV ; le CV sans e-mail renvoie `null` et non une adresse inventée ; l'ambiguïté apparaît dans `incertitudes` ; `stop_reason` est contrôlé.

<details>
<summary>Pistes</summary>

- Pour un champ nullable en Pydantic : `email: str | None = None` ; en Zod : `z.string().nullable()`.
- Pour le niveau de langue : `Literal["A1","A2","B1","B2","C1","C2","natif"]` / `z.enum([...])`.
- Le CV ambigu doit faire apparaître une phrase du type « expérience 2019-2026 chevauche deux postes » dans `incertitudes`.
</details>

## ✅ Auto-évaluation express

1. Que garantit `output_config.format` : la forme ou le fond du JSON ?
2. Pourquoi ne peut-on pas combiner sorties structurées et citations ?
3. Quelle approche choisir pour extraire des données **au milieu** d'une boucle d'agent avec d'autres outils ?

**Réponses.** 1. La forme uniquement (JSON valide et conforme au schéma) ; les valeurs doivent être contrôlées. 2. Les deux fonctionnalités sont documentées comme incompatibles (nov. 2026) ; il faut deux appels ou des champs de citation dans le schéma. 3. Un outil extracteur avec `strict: true`.

> ✅ **Si vous ne retenez que 3 choses** — 1. Pour un JSON qu'un programme doit lire, utilisez `output_config.format` (ou `messages.parse()` avec Pydantic / Zod) : la réponse est garantie conforme au schéma, sans bricolage de `json.loads`. 2. Le schéma garantit la forme, pas la vérité : gardez un contrôle métier et un champ « incertitudes », et rendez facultatifs les champs que le document peut ne pas contenir. 3. Vérifiez toujours `stop_reason == "end_turn"` avant de lire le JSON, et souvenez-vous que sorties structurées et citations ne se combinent pas dans une même requête.

## 📚 Pour aller plus loin
- [Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧 — schéma supporté, helpers `parse()`, limites et incompatibilités.
- [Strict tool use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use) 🇬🇧 — garantie de schéma sur les arguments d'outils.
- [Cookbook — Classification guide](https://platform.claude.com/cookbook/capabilities-classification-guide) 🇬🇧 — classer à grande échelle avec évaluation.
- [Handling stop reasons](https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons) 🇬🇧 — `refusal`, `max_tokens` et leurs conséquences sur un JSON.

> 🗺️ **Et maintenant ?** — Vous savez obtenir des données propres à partir de texte ; la leçon L072 ouvre Claude aux images, aux PDF et aux fichiers, avec des citations qui prouvent d'où vient chaque information.
