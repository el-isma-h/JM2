---
id: L068
module: M17
level: N3
title: "Messages API : requêtes, rôles, paramètres, modèles"
minutes: 50
objectives:
  - "Envoyer une première requête à la Messages API en Python et en TypeScript avec une clé lue depuis l'environnement"
  - "Expliquer la structure d'une requête (model, max_tokens, system, messages, rôles) et d'une réponse (content, stop_reason, usage)"
  - "Choisir un modèle Claude (Haiku 5.5, Sonnet 5.5, Opus 5.5, Fable 5.1) selon le coût, la latence et la difficulté de la tâche"
  - "Implémenter le streaming, la conversation multi-tours et le calcul du coût d'un appel"
skills: ["C3.1"]
sources:
  - { title: "Claude Platform — Get started (quickstart)", url: "https://platform.claude.com/docs/en/get-started", lang: "en" }
  - { title: "Claude Platform — Using the Messages API", url: "https://platform.claude.com/docs/en/build-with-claude/working-with-messages", lang: "en" }
  - { title: "Claude Platform — Messages API reference", url: "https://platform.claude.com/docs/en/api/messages/create", lang: "en" }
  - { title: "Claude Platform — Streaming", url: "https://platform.claude.com/docs/en/build-with-claude/streaming", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — Choosing a model", url: "https://platform.claude.com/docs/en/about-claude/models/choosing-a-model", lang: "en" }
  - { title: "Claude Platform — Rate limits", url: "https://platform.claude.com/docs/en/api/rate-limits", lang: "en" }
  - { title: "Claude Platform — Migration guide API 2026-10-21", url: "https://platform.claude.com/docs/en/api/migration-2026-10-21", lang: "en" }
  - { title: "Claude Academy — Building with the Claude API", url: "https://academy.claude.com/courses/building-with-the-claude-api", lang: "en" }
---

# Messages API : requêtes, rôles, paramètres, modèles

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Installer le SDK officiel (`anthropic` en Python, `@anthropic-ai/sdk` en TypeScript), stocker votre clé dans une variable d'environnement et obtenir une première réponse de Claude.
- Lire une réponse comme un développeur : blocs `content`, `stop_reason`, `usage`, et transformer `usage` en euros… pardon, en dollars.
- Tenir une conversation multi-tours, activer le streaming et choisir le bon modèle pour chaque tâche.
- Éviter les trois erreurs qui font échouer 80 % des premiers appels (clé dans le code, `max_tokens` oublié, paramètre `temperature` envoyé à un modèle qui le refuse).

> 🧭 **En clair** — Parler à Claude par l'API, c'est comme **échanger des lettres avec un expert qui n'a aucune mémoire**. Chaque lettre que vous envoyez doit contenir tout le nécessaire : qui il est censé être (le *system prompt*), tout l'échange précédent, et votre nouvelle question. Il vous renvoie une lettre-réponse, avec en bas de page deux mentions utiles : pourquoi il s'est arrêté d'écrire (`stop_reason`) et combien de mots il a lus et écrits (`usage`), ce qui sert à calculer la facture. Vous choisissez aussi quel expert consulter (Haiku, Sonnet, Opus, Fable) : du plus rapide et économique au plus pointu et plus cher. Toute la leçon consiste à savoir écrire cette lettre, la lire et payer le bon prix.

## 1. La Messages API, porte d'entrée de tout le module

Imaginez un cabinet comptable qui embauche un collaborateur brillant mais amnésique : à chaque fois que vous entrez dans son bureau, il ne se souvient de rien. Vous devez donc lui redonner **tout le dossier** (le contexte), lui rappeler **son rôle** (le system prompt) et lui poser **votre question**. Il répond, puis oublie tout. C'est exactement le fonctionnement de la **Messages API** d'Anthropic : une requête HTTP `POST` vers `https://api.anthropic.com/v1/messages`, **sans état** (stateless). Toute la mémoire, c'est vous qui la gérez.

> 💡 **Autrement dit** — « Sans état » (*stateless*) signifie que le serveur d'Anthropic ne garde **aucun souvenir** entre deux appels : une requête = une lettre complète, lue puis oubliée. Une « requête HTTP `POST` » est simplement l'envoi de cette lettre à une adresse web précise (`/v1/messages`), comme un formulaire qu'on soumet sur un site.

Cette API est la brique commune à tout ce que vous verrez dans ce module : tool use (L070), sorties structurées (L071), fichiers (L072), caching et batch (L073). Même le Claude Agent SDK (L074) et les Managed Agents reposent dessus. Bien la comprendre, c'est gagner du temps sur les neuf leçons suivantes.

### 1.1 Les versions qui comptent (nov. 2026)

| Élément | Valeur (nov. 2026) | Où vérifier |
|---|---|---|
| Version de l'API | `2026-10-21` (envoyée automatiquement par les SDK v2 dans l'en-tête `anthropic-version`) | [Migration guide 2026-10-21](https://platform.claude.com/docs/en/api/migration-2026-10-21) |
| SDK Python | `anthropic` 2.3.0, licence Apache 2.0 | [Client SDKs overview](https://platform.claude.com/docs/en/cli-sdks-libraries/overview) |
| SDK TypeScript | `@anthropic-ai/sdk` 1.3.0 | idem |
| Autres SDK | Go 2.4.0, Java 3.3.0, C# 13.3.0, Ruby 2.3.0, PHP 1.3.0, CLI `ant` 2.4.0 | idem |
| Console (clés, playground) | `https://platform.claude.com/settings/keys` et `/playground` | [Get started](https://platform.claude.com/docs/en/get-started) |

> 💡 **À retenir** — Depuis la version `2026-10-21`, les SDK sont passés en **v2** et sous licence **Apache 2.0**. Si vous trouvez sur un blog du code `client.messages.create(...)` écrit en 2024, la forme de la requête est toujours valable ; ce sont certains paramètres (`temperature`, préremplissage) qui ont disparu sur les modèles récents (section 3).

## 2. Première requête : Python et TypeScript côte à côte

### 2.1 Installation et clé API

```bash
# Python 3.12+
python -m venv .venv && source .venv/bin/activate
pip install "anthropic>=2.3" python-dotenv

# TypeScript / Node 20+
npm init -y && npm install @anthropic-ai/sdk dotenv typescript tsx

# La clé ne va JAMAIS dans le code : variable d'environnement
export ANTHROPIC_API_KEY="sk-ant-..."   # créée sur platform.claude.com/settings/keys
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `python -m venv .venv && source .venv/bin/activate` : crée l'environnement isolé du projet **puis** (`&&`) l'active pour ce terminal (sous Windows PowerShell : `.venv\Scripts\Activate.ps1`).
> - `pip install "anthropic>=2.3" python-dotenv` : installe le SDK, version 2.3 au minimum (les guillemets protègent le `>`), et `python-dotenv`, qui lit le fichier `.env`.
> - `npm init -y && npm install …` : crée `package.json` puis installe le SDK TypeScript, `dotenv` (lecture du fichier `.env`), le compilateur et le lanceur `tsx`.
> - `export ANTHROPIC_API_KEY="sk-ant-..."` : crée la variable d'environnement **dans ce terminal seulement** ; un nouveau terminal ne la connaîtra pas (voir le pré-requis « variables d'environnement » de L065).

Le SDK lit automatiquement `ANTHROPIC_API_KEY`. Dans un projet, placez-la dans un fichier `.env` **ajouté au `.gitignore`** (une ligne `ANTHROPIC_API_KEY=sk-ant-...`), et chargez-la avec `python-dotenv` ou `dotenv` : c'est ce que font les deux premières lignes de chaque script Python de cette leçon (`load_dotenv()`) et la première ligne de chaque script TypeScript (`import "dotenv/config";`). Si vous avez fait `export`, ces lignes ne changent rien : par défaut, une variable déjà définie n'est pas écrasée.

### 2.2 Le « Bonjour, Claude » en Python

```python
# premier_appel.py — première requête à la Messages API
import os
from anthropic import Anthropic
from dotenv import load_dotenv
load_dotenv()                      # lit le fichier .env (dossier du script ou parents), s'il existe

# Le client lit ANTHROPIC_API_KEY ; on vérifie quand même qu'elle existe.
if not os.environ.get("ANTHROPIC_API_KEY"):
    raise SystemExit("Définissez ANTHROPIC_API_KEY avant de lancer ce script.")

client = Anthropic()

reponse = client.messages.create(
    model="claude-sonnet-5-5",        # modèle polyvalent, bon rapport qualité/prix
    max_tokens=400,                   # plafond de tokens de SORTIE (obligatoire)
    system="Vous êtes l'assistant d'un cabinet comptable français. Répondez en français, "
           "de façon concise, sans donner de conseil fiscal personnalisé.",
    messages=[
        {"role": "user", "content": "Explique en trois phrases la différence entre bilan et compte de résultat."}
    ],
)

# La réponse est une liste de blocs ; le premier est un bloc texte.
for bloc in reponse.content:
    if bloc.type == "text":
        print(bloc.text)

print("\n--- métadonnées ---")
print("stop_reason :", reponse.stop_reason)          # "end_turn" attendu
print("tokens entrée :", reponse.usage.input_tokens)
print("tokens sortie :", reponse.usage.output_tokens)
```

> 🔍 **Ce que fait ce code, ligne par ligne** — C'est le même squelette qu'en L065 : `load_dotenv()` copie dans les variables d'environnement le contenu du fichier `.env` s'il existe (sinon, il faut avoir fait `export ANTHROPIC_API_KEY=…` dans le terminal), puis le `if` arrête proprement le script si la clé manque. `client.messages.create(...)` envoie la requête ; la boucle `for bloc in reponse.content` n'affiche que les blocs de type `text` ; `reponse.usage` donne les tokens facturés.

### 2.3 Le même appel en TypeScript

```typescript
// premier_appel.ts — à lancer avec : npx tsx premier_appel.ts
import "dotenv/config";           // charge le fichier .env du dossier courant dans process.env
import Anthropic from "@anthropic-ai/sdk";

if (!process.env.ANTHROPIC_API_KEY) {
  throw new Error("Définissez ANTHROPIC_API_KEY avant de lancer ce script.");
}

const client = new Anthropic(); // lit ANTHROPIC_API_KEY

async function main() {
  const reponse = await client.messages.create({
    model: "claude-sonnet-5-5",
    max_tokens: 400,
    system:
      "Vous êtes l'assistant d'un cabinet comptable français. Répondez en français, " +
      "de façon concise, sans donner de conseil fiscal personnalisé.",
    messages: [
      { role: "user", content: "Explique en trois phrases la différence entre bilan et compte de résultat." },
    ],
  });

  for (const bloc of reponse.content) {
    if (bloc.type === "text") console.log(bloc.text);
  }
  console.log("\nstop_reason :", reponse.stop_reason);
  console.log("usage :", reponse.usage);
}

main().catch((e) => { console.error(e); process.exit(1); });
```

> 🛠️ **Si ça ne marche pas** —
> - « Définissez ANTHROPIC_API_KEY… » alors que votre `.env` est rempli → le fichier n'est pas trouvé : en TypeScript, `dotenv` cherche `.env` dans le dossier **courant** (celui d'où vous lancez la commande) ; en Python, `load_dotenv()` le cherche à partir du dossier du script → lancez le script depuis le dossier qui contient `.env`, vérifiez le nom exact (`.env`, pas `.env.txt`, piège fréquent sous Windows) et la ligne `ANTHROPIC_API_KEY=sk-ant-...` (sans espace autour du `=`).
> - `ModuleNotFoundError: No module named 'dotenv'` ou `Cannot find module 'dotenv/config'` → le paquet n'est pas installé → `pip install python-dotenv` (le nom d'installation diffère du nom d'import) ou `npm install dotenv`.
> - `SyntaxError: Cannot use import statement outside a module` en lançant avec `node` → Node ne lit pas le TypeScript de cette façon → lancez avec `npx tsx`, comme indiqué en commentaire.
> - `await is only valid in async functions` → vous avez sorti l'appel de la fonction `main()` → laissez `await` à l'intérieur d'une fonction `async` (pré-requis `async` / `await` en L065).
> - Erreur 404 sur le modèle → identifiant mal recopié ou modèle retiré (Sonnet 4.5 l'est le 30 nov. 2026) → reprenez un ID du tableau de la section 6.

### 2.4 Anatomie de la requête et de la réponse

```
REQUÊTE                                  RÉPONSE
┌──────────────────────────────┐         ┌──────────────────────────────────┐
│ model      "claude-sonnet-5-5"│         │ id          "msg_01…"            │
│ max_tokens 400                │  ───►   │ model       "claude-sonnet-5-5"  │
│ system     "Vous êtes…"       │         │ role        "assistant"          │
│ messages   [ {user: "…"} ]    │         │ content     [ {type:"text", …} ] │
│ (tools, thinking, output_config│         │ stop_reason "end_turn"           │
│  metadata, stream…)           │         │ usage       {input_tokens, …}    │
└──────────────────────────────┘         └──────────────────────────────────┘
```

Quatre paramètres suffisent pour 90 % des appels :

| Paramètre | Rôle | Pièges |
|---|---|---|
| `model` | identifiant du modèle (`claude-haiku-5-5`, `claude-sonnet-5-5`, `claude-opus-5-5`, `claude-fable-5-1`) | un alias retiré de l'API renvoie une erreur 404 : surveillez la page [Model deprecations](https://platform.claude.com/docs/en/about-claude/model-deprecations) (Sonnet 4.5 est retiré le 30 nov. 2026) |
| `max_tokens` | plafond de **sortie** ; obligatoire | trop bas → `stop_reason: "max_tokens"`, réponse tronquée ; trop haut ne coûte rien tant que le modèle n'utilise pas les tokens, mais influence la file d'attente |
| `system` | consigne de cadrage (rôle, ton, règles) | c'est un paramètre de niveau requête, pas un message dans `messages` (détails en L069) |
| `messages` | liste alternée `user` / `assistant` | la liste doit **commencer par `user`** et alterner les rôles ; deux messages consécutifs du même rôle sont fusionnés par l'API en un seul tour — une source fréquente de questions dupliquées dans l'historique |

La réponse contient `stop_reason`, que vous devez **toujours** lire : `end_turn` (fin normale), `max_tokens` (tronqué), `tool_use` (le modèle veut appeler un outil, L070), `stop_sequence`, `refusal` (contenu refusé pour des raisons de sécurité). La page [Handling stop reasons](https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons) détaille le comportement à adopter pour chacun.

> ⚠️ **Piège fréquent** — Oublier de tester `stop_reason == "max_tokens"`. Un résumé coupé au milieu d'une phrase renvoyé tel quel à un client fait très mauvais effet. Relancez l'appel avec un `max_tokens` plus élevé ou demandez une « continuation ».


```quiz
{
  "q": "Votre script de résumé de devis renvoie un texte coupé au milieu d'une phrase. Dans la réponse, quel champ regardez-vous en premier ?",
  "options": ["usage.input_tokens", "stop_reason", "model", "id"],
  "answer": 1,
  "explanation": "stop_reason dit pourquoi Claude s'est arrêté. S'il vaut \"max_tokens\", la réponse a été tronquée par votre plafond : relancez avec un max_tokens plus élevé ou demandez une continuation."
}
```

```mission
{
  "title": "Quel en-tête HTTP porte la version de l'API ?",
  "url": "https://platform.claude.com/docs/en/api/migration-2026-10-21",
  "steps": ["Ouvrez le guide de migration vers la version 2026-10-21", "Cherchez (Ctrl+F ou Cmd+F) le mot « anthropic-version »", "Notez la valeur de version que les SDK v2 envoient automatiquement"],
  "question": "Quel en-tête HTTP indique la version de l'API, et quelle valeur les SDK v2 y placent-ils ?",
  "hint": "Le nom de l'en-tête commence par « anthropic- » ; le tableau de la section 1.1 vous met sur la piste.",
  "answer": "L'en-tête anthropic-version, avec la valeur 2026-10-21 pour les SDK v2 (documentation consultée en nov. 2026 ; une nouvelle version d'API peut sortir) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Paramètres : ce qui existe encore, ce qui a disparu

Les modèles actuels (Claude 5.5 et Fable 5.1) ont simplifié l'API. La page [Using the Messages API](https://platform.claude.com/docs/en/build-with-claude/working-with-messages) précise (nov. 2026) :

- **`temperature`, `top_p`, `top_k` ne sont plus supportés** sur les modèles ≥ 4.7 (et sur tous les modèles avec la version d'API 2026-10-21, celle des SDK v2) : les envoyer provoque une erreur **400**. Le contrôle de la créativité passe désormais par le prompt et par `effort` (L073).
- **Le préremplissage** (prefill : commencer vous-même le message `assistant`) n'est plus supporté sur les modèles ≥ 4.6. Pour forcer un format, utilisez les sorties structurées (L071).
- **`stop_sequences`** reste disponible : liste de chaînes qui arrêtent la génération.
- **`metadata.user_id`** : un identifiant opaque de votre utilisateur final, utile pour l'abus et le suivi.
- **`stream: true`** : réponse en flux (section 5).
- **`thinking`**, **`output_config`** (effort, format), **`tools`**, **`mcp_servers`** : leçons suivantes.

```python
# Vérification pratique : un appel avec temperature échoue sur Sonnet 5.5
import anthropic
from dotenv import load_dotenv
load_dotenv()                      # lit le fichier .env (dossier du script ou parents), s'il existe
client = anthropic.Anthropic()
try:
    client.messages.create(model="claude-sonnet-5-5", max_tokens=50, temperature=0.2,
                           messages=[{"role": "user", "content": "Bonjour"}])
except anthropic.BadRequestError as e:
    print("400 attendu :", e.message)
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `try:` tente l'appel avec `temperature=0.2` ; comme le SDK v2 envoie la version d'API `2026-10-21`, le serveur répond 400 et le SDK lève l'exception `anthropic.BadRequestError`. Le bloc `except … as e:` l'attrape au lieu de laisser le programme planter, et `e.message` contient l'explication renvoyée par le serveur. C'est la bonne façon de **vérifier** un comportement d'API plutôt que de croire un vieux blog.


```quiz
{
  "type": "vrai_faux",
  "q": "Sur claude-sonnet-5-5, on peut encore rendre les réponses plus « créatives » en envoyant temperature: 0.9.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : temperature, top_p et top_k ne sont plus supportés sur les modèles ≥ 4.7, et sur tous les modèles avec la version d'API 2026-10-21 des SDK v2 : ils provoquent une erreur 400. La créativité se pilote par le prompt et par le paramètre effort (L073)."
}
```

## 4. Conversation multi-tours : vous êtes la mémoire

Puisque l'API est sans état, un chatbot consiste à **renvoyer l'historique complet** à chaque tour. Voici un mini-chat de terminal, en Python puis en TypeScript, avec comptage du coût.

```python
# chat.py — conversation multi-tours avec suivi du coût (tarifs nov. 2026, Sonnet 5.5 : 2 $ / 10 $ par MTok)
from anthropic import Anthropic
from dotenv import load_dotenv
load_dotenv()                      # lit le fichier .env (dossier du script ou parents), s'il existe

client = Anthropic()
PRIX_ENTREE, PRIX_SORTIE = 2.00, 10.00   # $/million de tokens
historique: list[dict] = []
cout_total = 0.0

print("Chat avec Claude (tapez 'quit' pour sortir)")
while True:
    question = input("\nVous > ").strip()
    if question.lower() in {"quit", "exit"}:
        break
    historique.append({"role": "user", "content": question})

    reponse = client.messages.create(
        model="claude-sonnet-5-5",
        max_tokens=800,
        system="Vous êtes un assistant RH pour une PME française de 40 salariés. Soyez précis et prudent.",
        messages=historique,   # TOUT l'historique, à chaque tour
    )
    texte = "".join(b.text for b in reponse.content if b.type == "text")
    historique.append({"role": "assistant", "content": texte})

    u = reponse.usage
    cout = (u.input_tokens * PRIX_ENTREE + u.output_tokens * PRIX_SORTIE) / 1_000_000
    cout_total += cout
    print(f"\nClaude > {texte}")
    print(f"[{u.input_tokens} in / {u.output_tokens} out · {cout:.5f} $ · cumul {cout_total:.4f} $]")
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `historique: list[dict] = []` : la mémoire de la conversation, une liste vide au départ, que **votre** programme remplit.
> - `while True:` … `break` : une boucle sans fin, dont on sort quand l'utilisateur tape `quit` ou `exit`. `input("…")` attend que l'utilisateur tape une ligne ; `.strip()` retire les espaces autour.
> - `historique.append({"role": "user", "content": question})` : ajoute la question **avant** l'appel ; `messages=historique` envoie toute la liste.
> - `"".join(b.text for b in reponse.content if b.type == "text")` : prend le texte de chaque bloc de type `text` et les colle bout à bout, en une seule chaîne.
> - `historique.append({"role": "assistant", …})` : range la réponse dans la mémoire, pour que le tour suivant la contienne.
> - `cout = (… * PRIX_ENTREE + … * PRIX_SORTIE) / 1_000_000` : le calcul de facture de L067, appel par appel ; `cout_total += cout` fait le cumul.

```typescript
// chat.ts — même logique en TypeScript, avec readline
import "dotenv/config";           // charge le fichier .env du dossier courant dans process.env
import Anthropic from "@anthropic-ai/sdk";
import * as readline from "node:readline/promises";

const client = new Anthropic();
const PRIX_ENTREE = 2.0, PRIX_SORTIE = 10.0; // $/MTok, Sonnet 5.5 (nov. 2026)
const historique: Anthropic.MessageParam[] = [];
let coutTotal = 0;

async function main() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  while (true) {
    const question = (await rl.question("\nVous > ")).trim();
    if (["quit", "exit"].includes(question.toLowerCase())) break;
    historique.push({ role: "user", content: question });

    const reponse = await client.messages.create({
      model: "claude-sonnet-5-5",
      max_tokens: 800,
      system: "Vous êtes un assistant RH pour une PME française de 40 salariés. Soyez précis et prudent.",
      messages: historique,
    });
    const texte = reponse.content.filter((b) => b.type === "text").map((b) => b.text).join("");
    historique.push({ role: "assistant", content: texte });

    const cout = (reponse.usage.input_tokens * PRIX_ENTREE + reponse.usage.output_tokens * PRIX_SORTIE) / 1e6;
    coutTotal += cout;
    console.log(`\nClaude > ${texte}\n[coût ${cout.toFixed(5)} $ · cumul ${coutTotal.toFixed(4)} $]`);
  }
  rl.close();
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `import * as readline from "node:readline/promises"` : le module de Node qui lit le clavier ; la version `promises` permet d'écrire `await rl.question(…)`.
> - `const historique: Anthropic.MessageParam[] = []` : une liste vide dont le type est « messages au format attendu par le SDK » ; l'éditeur vous signalera un message mal formé.
> - `reponse.content.filter((b) => b.type === "text").map((b) => b.text).join("")` : garde les blocs texte (`filter`), en extrait le texte (`map`), puis colle le tout (`join`). C'est l'équivalent du `"".join(...)` Python.
> - `` `\nClaude > ${texte}` `` : une chaîne entre accents graves (*template literal*) ; `${…}` y insère la valeur d'une variable.
> - `rl.close()` : libère le clavier ; sans cette ligne, le programme ne se termine pas après `quit`.

Remarquez que **les tokens d'entrée croissent à chaque tour** : au dixième échange, vous renvoyez neuf questions et neuf réponses. C'est la raison d'être du prompt caching (L073) et de la gestion de contexte (compaction). Les modèles 5.5 acceptent **1 million de tokens** de contexte (≈ 555 000 mots avec le tokenizer actuel, selon la page Pricing), mais chaque token renvoyé est facturé.

> 🛠️ **Si ça ne marche pas** —
> - Le modèle « répète » ou répond deux fois à la même question → un appel a échoué **après** l'ajout de la question à `historique`, puis vous avez reposé la question : deux messages `user` consécutifs sont fusionnés en un seul tour → en cas d'erreur, retirez le dernier message avec `historique.pop()`.
> - Erreur 400 après avoir appuyé sur Entrée sans rien taper → un message vide peut être refusé → ignorez les questions vides (`if not question: continue`).
> - Le coût affiché grimpe très vite → c'est normal : l'historique entier est renvoyé à chaque tour → voir le prompt caching (L073) ou résumez les anciens tours.
> - `Ctrl+C` affiche un long message d'erreur (`KeyboardInterrupt`) → ce n'est pas un bug, c'est l'arrêt forcé ; tapez `quit` pour sortir proprement.

> 💡 **À retenir** — Sur les modèles récents (par exemple Opus 5.5, Sonnet 5.5, Haiku 5.5 ; pas Sonnet 5), un message de rôle **`system` peut aussi apparaître en cours de conversation** dans `messages` (page [Mid-conversation system messages](https://platform.claude.com/docs/en/build-with-claude/mid-conversation-system-messages)) : pratique pour injecter une nouvelle règle au tour 12 sans réécrire le system prompt initial.


```quiz
{
  "q": "Au 10e tour d'un chat, pourquoi la facture d'un appel est-elle plus élevée qu'au 1er tour, à question de même longueur ?",
  "options": ["Parce que Claude réfléchit plus longtemps quand la conversation avance", "Parce que l'API facture un supplément fixe par tour", "Parce que vous renvoyez tout l'historique en tokens d'entrée", "Parce que max_tokens double automatiquement à chaque tour"],
  "answer": 2,
  "explanation": "L'API est sans état : à chaque tour, vous renvoyez toutes les questions et réponses précédentes, qui sont refacturées comme tokens d'entrée. Le prompt caching (L073) sert justement à réduire ce coût."
}
```

## 5. Streaming : afficher au fil de l'eau

Une réponse de 800 tokens met quelques secondes à arriver. Pour une interface, on préfère afficher les mots au fur et à mesure. Le protocole envoie des événements SSE dans l'ordre : `message_start` → `content_block_start` → `content_block_delta` (plusieurs) → `content_block_stop` → `message_delta` (avec `stop_reason` et `usage` final) → `message_stop`. Les deltas sont de type `text_delta`, `input_json_delta` (arguments d'outils), `thinking_delta` ou `signature_delta` (page [Streaming](https://platform.claude.com/docs/en/build-with-claude/streaming)).

> 💡 **Autrement dit** — Sans streaming, vous attendez que le plat soit entièrement cuisiné avant qu'on vous le serve. Avec le streaming, le serveur vous apporte **les bouchées au fur et à mesure** : l'interface affiche les mots dès qu'ils sont écrits. Les « événements SSE » (*Server-Sent Events*) sont ces petites livraisons successives : « je commence », « voici un morceau de texte », « j'ai fini, voici la facture ».

```mermaid
sequenceDiagram
  participant App as Votre application
  participant API as API Claude
  App->>API: POST /v1/messages (stream: true)
  API-->>App: message_start
  API-->>App: content_block_start
  API-->>App: content_block_delta (text_delta) × N
  API-->>App: content_block_stop
  API-->>App: message_delta (stop_reason, usage)
  API-->>App: message_stop
```

Les SDK masquent cette plomberie :

```python
# stream.py — streaming texte avec le SDK Python
from anthropic import Anthropic
from dotenv import load_dotenv
load_dotenv()                      # lit le fichier .env (dossier du script ou parents), s'il existe
client = Anthropic()

with client.messages.stream(
    model="claude-haiku-5-5",     # rapide et peu coûteux pour une démo
    max_tokens=500,
    messages=[{"role": "user", "content": "Rédige une annonce de 80 mots pour un poste de boulanger à Lyon."}],
) as stream:
    for texte in stream.text_stream:   # seulement les deltas de texte
        print(texte, end="", flush=True)

message_final = stream.get_final_message()   # objet Message complet, avec usage
print("\n\nusage :", message_final.usage)
```

```typescript
// stream.ts — streaming avec le SDK TypeScript
import "dotenv/config";           // charge le fichier .env du dossier courant dans process.env
import Anthropic from "@anthropic-ai/sdk";
const client = new Anthropic();

async function main() {
  const stream = client.messages.stream({
    model: "claude-haiku-5-5",
    max_tokens: 500,
    messages: [{ role: "user", content: "Rédige une annonce de 80 mots pour un poste de boulanger à Lyon." }],
  });
  stream.on("text", (delta) => process.stdout.write(delta));
  const final = await stream.finalMessage();
  console.log("\n\nusage :", final.usage);
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Mêmes mécanismes qu'en L066 : en Python, `with client.messages.stream(...) as stream:` ouvre le flux et le referme proprement, `stream.text_stream` donne les morceaux de texte et `print(…, end="", flush=True)` les affiche aussitôt ; `stream.get_final_message()` rend le message complet avec `usage`. En TypeScript, `stream.on("text", …)` exécute la petite fonction à chaque morceau et `await stream.finalMessage()` attend la fin du flux.

## 6. Choisir son modèle : la famille Claude en nov. 2026

| Modèle | ID | Entrée / sortie ($/MTok) | Effort par défaut | Pour quoi ? |
|---|---|---|---|---|
| Claude Haiku 5.5 | `claude-haiku-5-5` | 0,10 / 0,50 (≤ 100k tokens de contexte ; 0,50 / 2,50 au-delà) | medium | classification, extraction, routage, chat à fort volume |
| Claude Sonnet 5.5 | `claude-sonnet-5-5` | 2 / 10 | high | assistants métier, code, agents courants : **le choix par défaut** |
| Claude Opus 5.5 | `claude-opus-5-5` | 4 / 20 | medium | raisonnement long, agents complexes, revue critique |
| Claude Fable 5.1 | `claude-fable-5-1` | 10 / 50 | high (thinking toujours actif) | frontière : recherche, tâches très difficiles |

Tous : contexte **1M tokens**, sortie max **128K**, thinking adaptatif, connaissances jusqu'à **juin 2026** (page [Pricing](https://platform.claude.com/docs/en/about-claude/pricing), nov. 2026). Claude Mythos 5.1 (mêmes tarifs que Fable 5.1) est réservé aux organisations vérifiées du Cyber Verification Program.

Règle pratique enseignée dans le cours partenaire « Upgrade a client's build to the Claude 5.5 models » : **commencez par le modèle le moins cher qui réussit votre évaluation** (L076), puis montez en gamme seulement sur les cas qu'il rate. Un cabinet comptable qui classe 50 000 factures par mois paiera avec Haiku 5.5 environ **5 $ d'entrée** pour 50 M de tokens, contre 100 $ avec Sonnet 5.5.

### 6.1 Limites de débit et gestion des erreurs

Les comptes sont répartis en paliers d'usage (Evaluation, Start, Build, Scale avec des plafonds de dépenses mensuels de 500 $, 1 000 $ et 200 000 $, Custom) avec un algorithme de *token bucket* ; les en-têtes `anthropic-ratelimit-*` de chaque réponse vous indiquent le quota restant (page [Rate limits](https://platform.claude.com/docs/en/api/rate-limits)). Le SDK réessaie automatiquement (2 tentatives par défaut, modifiable avec `max_retries`) les erreurs 429 et 5xx avec un délai exponentiel.

```python
# erreurs.py — gestion propre des erreurs du SDK Python
import anthropic
from dotenv import load_dotenv
load_dotenv()                      # lit le fichier .env (dossier du script ou parents), s'il existe
client = anthropic.Anthropic(max_retries=4, timeout=60.0)
try:
    r = client.messages.create(model="claude-sonnet-5-5", max_tokens=200,
                               messages=[{"role": "user", "content": "Ping"}])
except anthropic.AuthenticationError:
    print("Clé invalide ou absente (401).")
except anthropic.RateLimitError as e:
    print("Quota atteint (429) ; réessayer après :", e.response.headers.get("retry-after"))
except anthropic.APIStatusError as e:
    print("Erreur API", e.status_code, e.message)
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `anthropic.Anthropic(max_retries=4, timeout=60.0)` règle les nouvelles tentatives et le délai maximal pour tout le client. Les blocs `except` sont lus **de haut en bas** et seul le premier qui correspond s'exécute : on place donc les erreurs précises (`AuthenticationError` pour 401, `RateLimitError` pour 429) **avant** l'erreur générale `APIStatusError`, qui attrape tous les autres codes. Inversez l'ordre et les cas précis ne seront jamais atteints. Notez qu'un `RateLimitError` n'arrive ici qu'après l'échec des 4 nouvelles tentatives automatiques.

> 🔗 **Documentation officielle** — [Messages API reference](https://platform.claude.com/docs/en/api/messages/create) · [Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model) · [Token counting](https://platform.claude.com/docs/en/build-with-claude/token-counting) (endpoint `count_tokens` pour estimer avant d'envoyer).


```mission
{
  "title": "Quel est le plafond de dépenses mensuel du palier Build ?",
  "url": "https://platform.claude.com/docs/en/api/rate-limits",
  "steps": ["Ouvrez la page Rate limits", "Repérez le tableau des paliers d'usage (usage tiers)", "Lisez le plafond de dépenses mensuel du palier Build, puis repérez le préfixe des en-têtes de quota"],
  "question": "Quel plafond de dépenses mensuel correspond au palier Build, et par quel préfixe commencent les en-têtes qui donnent le quota restant ?",
  "hint": "Les paliers sont Evaluation, Start, Build, Scale et Custom ; les en-têtes commencent comme le nom de l'entreprise.",
  "answer": "1 000 $ par mois pour Build (Start : 500 $, Scale : 200 000 $) : ce sont des plafonds de dépenses mensuels, les conditions d'achat de crédits figurent sur la page Billing de la Console ; en-têtes anthropic-ratelimit-* (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

🎮 **Défi** — Sans lancer le code, estimez le coût d'un appel Sonnet 5.5 avec 12 000 tokens d'entrée et 900 de sortie. Réponse : 12 000 × 2 / 10⁶ + 900 × 10 / 10⁶ = 0,024 + 0,009 = **0,033 $**.

## 🧪 Exercice pratique

**Consigne.** Écrivez un script `resume_devis.py` (ou `.ts`) qui :
1. lit un texte de devis d'artisan (fourni dans un fichier `devis.txt`, 300-500 mots) ;
2. demande à `claude-haiku-5-5` un résumé en 3 puces, en streaming, avec un system prompt qui impose le français et interdit d'inventer des montants ;
3. affiche à la fin le `stop_reason`, les tokens et le coût calculé avec les tarifs de nov. 2026 ;
4. relance automatiquement avec `max_tokens` doublé si `stop_reason == "max_tokens"`.

**Critères de réussite.**
- La clé n'apparaît nulle part dans le code ni dans le dépôt (`.env` ignoré par Git).
- Le script gère `AuthenticationError` et `RateLimitError` sans planter.
- Le coût affiché est cohérent avec `usage` (vérifiez à la main sur un appel).
- Bonus : ajoutez un argument `--model` pour comparer Haiku 5.5 et Sonnet 5.5 sur le même devis et notez la différence de coût et de qualité.

<details>
<summary>Corrigé (pistes)</summary>

- Lisez le fichier avec `pathlib.Path("devis.txt").read_text(encoding="utf-8")`.
- Utilisez `client.messages.stream(...)` ; récupérez `stream.get_final_message()` pour `stop_reason` et `usage`.
- Bouclez `while` tant que `stop_reason == "max_tokens"` avec `max_tokens *= 2` (plafonnez à 4 000 pour éviter l'emballement).
- Coût Haiku 5.5 : `(in × 0.10 + out × 0.50) / 1e6`.
</details>

## ✅ Auto-évaluation express

1. Pourquoi faut-il renvoyer tout l'historique à chaque tour ?
2. Que se passe-t-il si vous envoyez `temperature: 0.7` à `claude-sonnet-5-5` ?
3. Quel `stop_reason` indique une réponse tronquée, et que faire ?

**Réponses.** 1. L'API est sans état : le serveur ne conserve aucune conversation ; la mémoire est à la charge du client. 2. Erreur HTTP 400 : `temperature`, `top_p` et `top_k` ne sont plus supportés sur les modèles ≥ 4.7 (et sur tous les modèles avec la version d'API 2026-10-21, celle des SDK v2). 3. `max_tokens` ; relancer avec un plafond plus élevé ou demander une continuation.

> ✅ **Si vous ne retenez que 3 choses** — 1. Une requête Messages tient en quatre paramètres (`model`, `max_tokens`, `system`, `messages`) et une réponse se lit par `content`, `stop_reason` et `usage`. 2. L'API est sans état : c'est votre programme qui garde l'historique et le renvoie en entier à chaque tour, d'où un coût d'entrée qui grimpe. 3. `temperature`, `top_p`, `top_k` et le préremplissage ne sont plus acceptés sur les modèles récents (et `temperature`, `top_p`, `top_k` sur aucun modèle avec la version d'API `2026-10-21`) : ils provoquent une erreur 400.

## 📚 Pour aller plus loin
- [Get started — Claude Platform](https://platform.claude.com/docs/en/get-started) 🇬🇧 — le quickstart officiel, avec exemples en 8 langages et la CLI `ant`.
- [Using the Messages API](https://platform.claude.com/docs/en/build-with-claude/working-with-messages) 🇬🇧 — multi-tours, rôle `system` en cours de conversation, paramètres retirés.
- [Streaming](https://platform.claude.com/docs/en/build-with-claude/streaming) 🇬🇧 — la liste exhaustive des événements SSE.
- [Building with the Claude API — Claude Academy](https://academy.claude.com/courses/building-with-the-claude-api) 🇬🇧 — cours gratuit de 9 h (badge à la clé) dont ce module couvre le programme ; nous vous encourageons à le suivre en parallèle.
- [Rate limits](https://platform.claude.com/docs/en/api/rate-limits) 🇬🇧 — paliers, token bucket, en-têtes de quota.

> 🗺️ **Et maintenant ?** — Vous savez envoyer une lettre à Claude ; la leçon L069 vous apprend à rédiger sa « fiche de poste », le system prompt, avec les techniques du guide officiel d'Anthropic.
