---
id: L072
module: M17
level: N3
title: "Vision, PDF, Files API et citations"
minutes: 45
objectives:
  - "Envoyer des images (base64, URL, file_id) et des PDF à Claude et en extraire des informations fiables"
  - "Utiliser la Files API pour téléverser une fois et référencer plusieurs fois (limites, expiration, coût)"
  - "Activer les citations sur des documents pour obtenir des réponses sourcées passage par passage"
  - "Dimensionner les requêtes multimodales (taille, pages, tokens) et en estimer le coût"
skills: ["C3.1", "C3.2"]
sources:
  - { title: "Claude Platform — Vision", url: "https://platform.claude.com/docs/en/build-with-claude/vision", lang: "en" }
  - { title: "Claude Platform — PDF support", url: "https://platform.claude.com/docs/en/build-with-claude/pdf-support", lang: "en" }
  - { title: "Claude Platform — Files API", url: "https://platform.claude.com/docs/en/build-with-claude/files", lang: "en" }
  - { title: "Claude Platform — Citations", url: "https://platform.claude.com/docs/en/build-with-claude/citations", lang: "en" }
  - { title: "Claude Platform — Search results", url: "https://platform.claude.com/docs/en/build-with-claude/search-results", lang: "en" }
  - { title: "Claude Platform — Token counting", url: "https://platform.claude.com/docs/en/build-with-claude/token-counting", lang: "en" }
  - { title: "Claude Cookbook — Using citations", url: "https://platform.claude.com/cookbook/misc-using-citations", lang: "en" }
---

# Vision, PDF, Files API et citations

> ⏱ 45 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Faire lire à Claude une photo de ticket de caisse, une capture d'écran ou un plan, en Python et en TypeScript.
- Traiter des PDF natifs ou scannés (texte **et** mise en page), jusqu'à 600 pages, en respectant les limites de l'API.
- Téléverser un fichier une fois avec la Files API et le réutiliser dans des dizaines de requêtes.
- Produire des réponses **citées** (quel passage de quel document justifie quelle phrase), sans payer les citations en tokens de sortie.

> 🧭 **En clair** — Jusqu'ici, vous n'envoyiez que du texte à Claude. Désormais, vous pouvez **glisser des photos et des classeurs dans l'enveloppe** : un ticket de caisse photographié, un contrat PDF de 30 pages, un plan. La **Files API**, c'est le **vestiaire d'un théâtre** : vous déposez votre manteau (le fichier) une seule fois, on vous donne un ticket (le `file_id`), et vous n'avez plus qu'à montrer le ticket à chaque requête au lieu de trimballer le manteau. Les **citations**, ce sont les **notes de bas de page** d'un bon rapport : pour chaque affirmation, Claude indique le passage exact du document qui la justifie, ce qui permet de vérifier en un clic.

## 1. Vision : Claude regarde vos images

Un expert-comptable reçoit chaque mois des centaines de photos de notes de frais prises au téléphone. Avec la Messages API, une image est simplement **un bloc de contenu** dans un message `user`, à côté du texte. La page [Vision](https://platform.claude.com/docs/en/build-with-claude/vision) précise les formats acceptés : **JPEG, PNG, GIF, WebP**, fournis en **base64**, par **URL** publique, ou par **`file_id`** (section 3).

```python
# vision.py — lecture d'une note de frais photographiée (base64) puis d'une image par URL
import base64, mimetypes
from pathlib import Path
from anthropic import Anthropic

client = Anthropic()

def bloc_image_local(chemin: str) -> dict:
    p = Path(chemin)
    media_type = mimetypes.guess_type(p.name)[0] or "image/jpeg"
    data = base64.standard_b64encode(p.read_bytes()).decode("ascii")
    return {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": data}}

r = client.messages.create(
    model="claude-sonnet-5-5",
    max_tokens=600,
    system="Vous lisez des justificatifs de frais pour un cabinet comptable. Si un élément est illisible, écrivez 'illisible'.",
    messages=[{
        "role": "user",
        "content": [
            bloc_image_local("ticket_restaurant.jpg"),
            {"type": "text", "text": "Donnez : commerçant, date, montant TTC, taux de TVA, nombre de couverts. Format : une ligne par champ."},
        ],
    }],
)
print(r.content[0].text)
print("tokens image + texte :", r.usage.input_tokens)

# Variante : image accessible par URL (pas de téléchargement côté client)
r2 = client.messages.create(
    model="claude-haiku-5-5", max_tokens=300,
    messages=[{"role": "user", "content": [
        {"type": "image", "source": {"type": "url", "url": "https://exemple.fr/photos/vitrine.jpg"}},
        {"type": "text", "text": "Décrivez cette vitrine en deux phrases pour une fiche Google Business."},
    ]}],
)
print(r2.content[0].text)
```

> 🧭 **Pré-requis express — base64 et type MIME** — Une requête JSON ne transporte que du texte ; une photo, elle, est faite d'octets « binaires ». Le **base64** traduit ces octets en une longue suite de lettres et de chiffres (environ un tiers plus longue que le fichier), que l'on peut glisser dans le JSON. Le **type MIME** (`image/jpeg`, `image/png`, `application/pdf`) est l'étiquette qui dit au serveur quel genre de fichier il reçoit ; elle doit correspondre au vrai format du fichier, pas seulement à son extension.
>
> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `mimetypes.guess_type(p.name)[0] or "image/jpeg"` : devine le type MIME d'après l'extension (`.png` → `image/png`) ; à défaut, suppose du JPEG.
> - `p.read_bytes()` lit le fichier en octets ; `base64.standard_b64encode(...)` les traduit en base64 ; `.decode("ascii")` transforme le résultat en texte Python ordinaire.
> - `{"type": "image", "source": {"type": "base64", …}}` : le bloc image, placé dans la liste `content` **avant** le bloc texte de la question.
> - `"content": [ bloc_image, {"type": "text", …} ]` : un message `user` peut contenir plusieurs blocs ; ici une image puis une consigne.
> - Variante `r2` : `"source": {"type": "url", "url": …}` ; c'est le serveur d'Anthropic qui va chercher l'image, elle doit donc être **publique** (pas derrière un mot de passe ni sur votre réseau interne).

```typescript
// vision.ts — même lecture en TypeScript
import Anthropic from "@anthropic-ai/sdk";
import { readFileSync } from "node:fs";

const client = new Anthropic();

async function main() {
  const data = readFileSync("ticket_restaurant.jpg").toString("base64");
  const r = await client.messages.create({
    model: "claude-sonnet-5-5", max_tokens: 600,
    system: "Vous lisez des justificatifs de frais pour un cabinet comptable. Si un élément est illisible, écrivez 'illisible'.",
    messages: [{
      role: "user",
      content: [
        { type: "image", source: { type: "base64", media_type: "image/jpeg", data } },
        { type: "text", text: "Donnez : commerçant, date, montant TTC, taux de TVA, nombre de couverts." },
      ],
    }],
  });
  console.log(r.content[0].type === "text" ? r.content[0].text : r.content);
  console.log("tokens :", r.usage.input_tokens);
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `readFileSync("ticket_restaurant.jpg").toString("base64")` lit le fichier et le convertit directement en base64. Le type `media_type: "image/jpeg"` est écrit en dur : si vous envoyez un PNG, changez-le en `"image/png"`, sinon l'API renvoie une erreur 400. `data` seul, dans `{ type: "base64", media_type: …, data }`, est un raccourci JavaScript pour `data: data`.

**Coût d'une image.** Une image est convertie en tokens proportionnellement à sa surface ; la doc donne la formule et conseille de **redimensionner avant envoi** (les grandes images sont réduites côté serveur, vous payez donc inutilement le transfert). Ordre de grandeur : une photo de 1 000 × 1 000 px représente environ 1 300-1 600 tokens, soit ~0,003 $ avec Sonnet 5.5 (nov. 2026). Le guide de prompting a une section « Improved vision capabilities » : placez l'image **avant** la question, et demandez des réponses « illisible » plutôt que des suppositions.

> 💡 **Autrement dit** — Pour Claude, une image se « paie » comme du texte, au prorata de sa surface : une photo géante de 12 mégapixels coûte plus cher qu'une photo réduite, sans être mieux lue (le serveur la réduit de toute façon). Redimensionnez donc vos images avant l'envoi, comme on compresse une pièce jointe avant un e-mail. Le format *base64* est juste une façon d'écrire une image sous forme de texte pour pouvoir la glisser dans une requête.

> ⚠️ **Piège fréquent** — Envoyer 40 photos dans une seule requête « pour aller plus vite ». Chaque image consomme des tokens et de la mémoire de contexte ; et une erreur sur l'une fait échouer tout le lot. Préférez une requête par justificatif (ou la Batch API, L073) et une sortie structurée (L071).

> 🛠️ **Si ça ne marche pas** —
> - `FileNotFoundError` / `ENOENT` → la photo n'est pas dans le dossier depuis lequel vous lancez le script → déplacez-la ou donnez un chemin complet.
> - Erreur 400 sur le `media_type` → l'étiquette ne correspond pas au contenu (un PNG renommé en `.jpg`) → ouvrez le fichier dans un éditeur d'images et réexportez-le dans le bon format.
> - Photo d'iPhone en `.heic` refusée → format non accepté → convertissez-la en JPEG avant l'envoi.
> - Erreur 400 sur une image par URL → l'adresse n'est pas publique, redirige vers une page de connexion, ou n'existe pas (`exemple.fr` est un nom fictif) → testez l'URL dans une fenêtre de navigation privée.
> - Erreur 400 ou 413 sur la taille → image trop lourde → redimensionnez-la (2 000 px de côté suffisent largement) ; les limites exactes sont sur la page Vision.


```quiz
{
  "q": "Parmi ces façons de fournir une image à la Messages API, laquelle N'EXISTE PAS ?",
  "options": ["Un bloc image dont la source est de type base64 (données encodées)", "Un bloc image dont la source est de type url (adresse publique)", "Le chemin local du fichier sur votre disque, ex. C:\\photos\\ticket.jpg", "Un bloc image dont la source est de type file, avec un file_id"],
  "answer": 2,
  "explanation": "Les trois sources possibles sont base64, url publique et file_id (Files API). Les serveurs d'Anthropic n'ont évidemment pas accès à votre disque : c'est à votre code de lire le fichier et de l'encoder."
}
```

## 2. PDF : texte et mise en page

La page [PDF support](https://platform.claude.com/docs/en/build-with-claude/pdf-support) décrit le traitement : chaque page est **à la fois** extraite en texte et rendue en image, ce qui permet à Claude de lire les tableaux, les tampons, les signatures et les documents scannés. Limites (nov. 2026) : **128 Mo par requête**, **600 pages maximum** (100 pages si le modèle n'est pas en contexte 1M), formats PDF standards non chiffrés.

```python
# pdf.py — analyse d'un contrat PDF envoyé en base64
import base64
from pathlib import Path
from anthropic import Anthropic

client = Anthropic()
pdf_b64 = base64.standard_b64encode(Path("contrat_maintenance.pdf").read_bytes()).decode("ascii")

r = client.messages.create(
    model="claude-sonnet-5-5",
    max_tokens=1200,
    messages=[{
        "role": "user",
        "content": [
            {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": pdf_b64},
             "title": "Contrat de maintenance ascenseur — Résidence Les Tilleuls"},
            {"type": "text", "text": "Listez les obligations du prestataire, la durée, les conditions de résiliation "
                                     "et les pénalités. Indiquez la page de chaque élément."},
        ],
    }],
)
print(r.content[0].text)
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Même principe que pour une image, mais avec un bloc `"type": "document"` et le type MIME `application/pdf`. Le champ `"title"` donne un nom lisible au document : Claude peut s'y référer, et il apparaîtra dans les citations (section 4). La consigne « Indiquez la page de chaque élément » fonctionne parce que chaque page est aussi vue comme une image numérotée. Un PDF protégé par mot de passe est refusé : enregistrez-en une copie sans protection.

Un PDF de 30 pages de texte dense représente environ 30 × (1 500 tokens de texte + ~1 500 tokens d'image) ≈ **90 000 tokens** : 0,18 $ par analyse avec Sonnet 5.5, 0,009 $ avec Haiku 5.5. Si vous interrogez le même contrat 20 fois, c'est le cas d'école du prompt caching (L073) et de la Files API.


```mission
{
  "title": "Combien de pages un PDF peut-il faire ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/pdf-support",
  "steps": ["Ouvrez la page « PDF support »", "Repérez le tableau ou la liste des limites (PDF requirements / limits)", "Relevez la taille maximale de requête et le nombre maximal de pages, et la condition qui fait varier ce nombre"],
  "question": "Quelle est la taille maximale d'une requête contenant un PDF, et combien de pages au plus peut-on envoyer ?",
  "hint": "Le nombre de pages dépend de la fenêtre de contexte du modèle.",
  "answer": "128 Mo par requête ; 600 pages maximum (100 pages si le modèle n'est pas en contexte 1M) — documentation consultée en nov. 2026, limites susceptibles d'évoluer (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 3. Files API : téléverser une fois, utiliser partout

Plutôt que d'encoder un PDF de 20 Mo en base64 à chaque requête, la [Files API](https://platform.claude.com/docs/en/build-with-claude/files) (disponible en **GA**, sans en-tête bêta depuis 2026) permet de le téléverser une fois et d'obtenir un `file_id` réutilisable. Limites (nov. 2026) : **500 Mo par fichier**, **1 To par organisation**, durée de conservation configurable de **1 heure à 90 jours**.

```mermaid
flowchart LR
  A["PDF sur votre disque"] -->|"files.upload (une fois)"| B["Files API<br/>stockage 1 h à 90 j"]
  B -->|"renvoie"| C["file_id"]
  C --> D["Requête 1 : document + question"]
  C --> E["Requête 2 : document + question"]
  C --> F["Requête N…"]
  B -->|"files.delete"| G["Supprimé"]
```

```python
# files_api.py — téléversement puis réutilisation d'un PDF par file_id
from anthropic import Anthropic
client = Anthropic()

# 1. Téléverser (une seule fois)
with open("catalogue_tarifs_2026.pdf", "rb") as f:
    fichier = client.files.upload(file=("catalogue_tarifs_2026.pdf", f, "application/pdf"))
print("file_id :", fichier.id, "· taille :", fichier.size_bytes)

# 2. Réutiliser dans autant de requêtes que nécessaire
questions = ["Quel est le tarif horaire de la main d'œuvre ?", "Y a-t-il une majoration le week-end ?"]
for q in questions:
    r = client.messages.create(
        model="claude-haiku-5-5", max_tokens=300,
        messages=[{"role": "user", "content": [
            {"type": "document", "source": {"type": "file", "file_id": fichier.id}},
            {"type": "text", "text": q},
        ]}],
    )
    print("Q :", q, "\nR :", r.content[0].text, "\n")

# 3. Lister / supprimer
for f in client.files.list():
    print(f.id, f.filename)
client.files.delete(fichier.id)
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `with open("catalogue_tarifs_2026.pdf", "rb") as f:` : ouvre le fichier en lecture binaire (`"rb"` = *read binary*) et le referme automatiquement à la fin du bloc.
> - `client.files.upload(file=("nom.pdf", f, "application/pdf"))` : envoie le fichier une seule fois ; le trio donne le nom, le contenu et le type MIME. La réponse contient `fichier.id`, le « ticket de vestiaire ».
> - `{"type": "document", "source": {"type": "file", "file_id": fichier.id}}` : à chaque question, on ne renvoie plus le PDF, seulement son identifiant. Attention : le document est tout de même **relu et facturé** à chaque requête (voir l'encadré suivant).
> - `client.files.list()` puis `client.files.delete(...)` : listent puis suppriment vos fichiers stockés ; pensez-y, ils occupent votre quota.

```typescript
// files_api.ts — Files API en TypeScript
import Anthropic, { toFile } from "@anthropic-ai/sdk";
import { readFileSync } from "node:fs";

const client = new Anthropic();

async function main() {
  const fichier = await client.files.upload({
    file: await toFile(readFileSync("catalogue_tarifs_2026.pdf"), "catalogue_tarifs_2026.pdf", { type: "application/pdf" }),
  });
  console.log("file_id :", fichier.id);

  const r = await client.messages.create({
    model: "claude-haiku-5-5", max_tokens: 300,
    messages: [{ role: "user", content: [
      { type: "document", source: { type: "file", file_id: fichier.id } },
      { type: "text", text: "Quel est le tarif horaire de la main d'œuvre ?" },
    ] }],
  });
  console.log(r.content[0].type === "text" ? r.content[0].text : r.content);
  await client.files.delete(fichier.id);
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `toFile(contenu, nom, { type })` est une fonction du SDK qui emballe les octets lus par `readFileSync` dans le format attendu par `files.upload` ; elle renvoie une promesse, d'où le `await`. La suite est identique à la version Python : on réutilise `fichier.id` dans le bloc `document`, puis on supprime le fichier.
>
> 🛠️ **Si ça ne marche pas** —
> - Erreur 404 `not_found_error` sur un `file_id` → le fichier a été supprimé, a expiré (durée de conservation choisie au téléversement) ou appartient à un autre workspace → téléversez-le de nouveau.
> - Erreur 400 sur un PDF → fichier chiffré ou abîmé → ouvrez-le dans un lecteur PDF et réenregistrez-le (« Imprimer en PDF »).
> - Facture plus élevée que prévu → le `file_id` évite de renvoyer les octets, pas de payer la lecture → mesurez avec `count_tokens` (section 5) et combinez avec le cache (L073).

Les mêmes `file_id` servent pour les images (`{"type": "image", "source": {"type": "file", "file_id": …}}`), pour l'outil **code execution** (analyser un CSV, produire un graphique) et pour récupérer les fichiers **produits** par Claude (sortie de code execution, skills pptx/xlsx, L076). Les noms exacts des méthodes (`files.upload`, `files.list`, `files.delete`) sont ceux de la page officielle en nov. 2026.

> 💡 **À retenir** — Files API ≠ RAG. Un fichier téléversé est **relu intégralement** à chaque requête qui le référence (et facturé en tokens) ; il n'est pas découpé ni indexé. Pour des milliers de documents, vous aurez besoin d'un pipeline de retrieval (module M20) et des blocs `search_result` (section 4.2).


```quiz
{
  "type": "vrai_faux",
  "q": "Un PDF référencé par son file_id est relu en entier, et facturé en tokens d'entrée, à chaque requête qui l'utilise.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai : la Files API évite de renvoyer le fichier, pas de le relire. Elle ne découpe ni n'indexe rien ; pour réduire la facture des relectures, combinez-la avec le prompt caching (L073), et pour des milliers de documents passez à un RAG (M20)."
}
```

## 4. Citations : des réponses qui montrent leurs sources

### 4.1 Activer les citations sur un document

La page [Citations](https://platform.claude.com/docs/en/build-with-claude/citations) décrit la fonctionnalité : en ajoutant `"citations": {"enabled": true}` à un bloc `document`, la réponse est découpée en blocs texte accompagnés de **citations** (`cited_text`, index du document, localisation : plage de caractères, de pages pour un PDF, ou de blocs pour du contenu pré-découpé). Point économique important : **le texte cité (`cited_text`) n'est pas facturé en tokens de sortie**.

> 💡 **Autrement dit** — Activer les citations, c'est demander à Claude de **surligner** dans vos documents chaque phrase sur laquelle il s'appuie. La réponse arrive en petits morceaux, chacun accompagné de son « surlignage » (`cited_text`) et de son adresse (numéro de page pour un PDF, position des caractères pour un texte). Et bonne nouvelle : ces passages surlignés ne vous sont pas facturés comme du texte écrit par Claude.

```python
# citations.py — réponse sourcée sur deux documents texte
from anthropic import Anthropic
client = Anthropic()

docs = {
    "Convention collective — extrait": "Article 12 : la durée du préavis en cas de démission est d'un mois pour les employés et de trois mois pour les cadres. Article 14 : les heures supplémentaires sont majorées de 25 % pour les huit premières heures.",
    "Règlement intérieur": "Chapitre 3 : les horaires d'ouverture sont de 8 h à 18 h. Le télétravail est autorisé deux jours par semaine après accord du responsable.",
}
contenu = [
    {"type": "document",
     "source": {"type": "text", "media_type": "text/plain", "data": texte},
     "title": titre,
     "citations": {"enabled": True}}
    for titre, texte in docs.items()
]
contenu.append({"type": "text", "text": "Quel est le préavis de démission d'un cadre, et combien de jours de télétravail sont possibles ?"})

r = client.messages.create(model="claude-sonnet-5-5", max_tokens=600,
                           messages=[{"role": "user", "content": contenu}])

for bloc in r.content:
    if bloc.type != "text":
        continue
    print(bloc.text)
    for c in (bloc.citations or []):
        print(f"   ↳ [{c.document_title}] « {c.cited_text.strip()} »")
```

> 🔍 **Ce que fait ce code, ligne par ligne** —
> - `contenu = [ {…} for titre, texte in docs.items() ]` : fabrique un bloc `document` par entrée du dictionnaire `docs` ; chaque bloc contient le texte brut (`"type": "text"`, `text/plain`), un titre et `"citations": {"enabled": True}`.
> - `contenu.append({"type": "text", …})` : ajoute la question **après** les documents.
> - `for bloc in r.content: if bloc.type != "text": continue` : `continue` saute au bloc suivant ; on ne traite que les blocs de texte.
> - `for c in (bloc.citations or []):` : un bloc peut n'avoir aucune citation (`None`) ; `or []` le remplace par une liste vide pour que la boucle ne plante pas. `c.document_title` et `c.cited_text` donnent la source et le passage exact.

```typescript
// citations.ts — même principe en TypeScript
import Anthropic from "@anthropic-ai/sdk";
const client = new Anthropic();

async function main() {
  const r = await client.messages.create({
    model: "claude-sonnet-5-5", max_tokens: 600,
    messages: [{ role: "user", content: [
      { type: "document", source: { type: "text", media_type: "text/plain", data: "Article 12 : la durée du préavis en cas de démission est d'un mois pour les employés et de trois mois pour les cadres." },
        title: "Convention collective — extrait", citations: { enabled: true } },
      { type: "text", text: "Quel est le préavis de démission d'un cadre ?" },
    ] }],
  });
  for (const bloc of r.content) {
    if (bloc.type !== "text") continue;
    console.log(bloc.text);
    for (const c of bloc.citations ?? []) console.log(`   ↳ [${(c as any).document_title}] « ${(c as any).cited_text} »`);
  }
}
main();
```

> 🔍 **Ce que fait ce code, ligne par ligne** — Même logique qu'en Python : `bloc.citations ?? []` remplace une absence de citations par une liste vide, et `(c as any)` contourne le typage, car une citation peut avoir plusieurs formes (plage de caractères, de pages, de blocs) selon le type de document.
>
> 🛠️ **Si ça ne marche pas** —
> - Erreur 400 en combinant `citations` et `output_config.format` → les deux sont incompatibles (section 4.3) → faites deux appels.
> - Aucune citation dans la réponse → la question ne trouve pas d'appui dans les documents, ou `citations.enabled` manque sur un bloc → vérifiez chaque bloc `document`.
> - Erreur 400 au tour suivant d'une conversation → vous avez recopié des blocs de citations dans un message `user` : depuis la version d'API `2026-10-21`, c'est refusé (et un bloc `document` placé dans un message `assistant` aussi) → ne renvoyez dans l'historique que le texte de la réponse, ou les blocs tels quels dans le message `assistant`.


```mission
{
  "title": "Chasse au champ : comment s'appelle le passage cité, et est-il facturé ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/citations",
  "steps": ["Ouvrez la page « Citations »", "Repérez un exemple de réponse JSON contenant un tableau citations", "Notez le nom du champ qui contient le passage exact, puis cherchez (Ctrl+F) « output tokens » pour la règle de facturation"],
  "question": "Quel champ d'une citation contient le texte exact du document, et compte-t-il dans les tokens de sortie facturés ?",
  "hint": "Le nom du champ est en anglais et en snake_case ; le code citations.py l'affiche.",
  "answer": "Le champ cited_text ; il n'est pas comptabilisé dans les tokens de sortie (documentation consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

### 4.2 Citations sur des résultats de recherche (RAG)

Pour un pipeline RAG, vous ne fournissez pas des documents entiers mais des **extraits** issus de votre moteur de recherche. Le bloc `search_result` (page [Search results](https://platform.claude.com/docs/en/build-with-claude/search-results)) porte une `source` (URL ou identifiant), un `title` et un `content` ; avec `citations.enabled`, Claude cite ces extraits exactement comme des documents, ce qui donne à vos utilisateurs des réponses vérifiables (« d'après la fiche produit n° 221 »). Vous retrouverez ce bloc dans le module RAG (M20).

### 4.3 Limites

- Les citations sont **incompatibles avec les sorties structurées** (L071) : choisissez, ou enchaînez deux appels.
- Les PDF cités renvoient des **numéros de page** ; les documents texte, des plages de caractères ; vous pouvez pré-découper un document en blocs (`content` sous forme de liste) pour contrôler la granularité des citations.
- Une citation prouve que **le passage existe**, pas que le raisonnement est juste : gardez une relecture humaine sur les sujets juridiques ou financiers.


```quiz
{
  "q": "Votre moteur de recherche interne renvoie 5 extraits de fiches produit. Quel type de bloc utiliser pour que Claude les cite dans sa réponse ?",
  "options": ["Des blocs search_result avec citations activées", "Un bloc image par extrait, capturé depuis le moteur", "Une sortie structurée via output_config.format", "Un message system inséré en cours de conversation"],
  "answer": 0,
  "explanation": "Le bloc search_result est conçu pour les extraits RAG : Claude les cite comme des documents. La sortie structurée, elle, est incompatible avec les citations."
}
```

## 5. Dimensionner et estimer avant d'envoyer

L'endpoint `count_tokens` (page [Token counting](https://platform.claude.com/docs/en/build-with-claude/token-counting)) accepte exactement les mêmes paramètres qu'une requête `messages.create` (images, PDF, outils compris) et renvoie le nombre de tokens d'entrée **sans facturer de génération**. Intégrez-le dans vos pipelines pour refuser ou découper les documents trop gros et afficher un coût prévisionnel.

```python
# count.py — estimer le coût d'un PDF avant de l'analyser
from anthropic import Anthropic
client = Anthropic()
n = client.messages.count_tokens(
    model="claude-sonnet-5-5",
    messages=[{"role": "user", "content": [
        {"type": "document", "source": {"type": "file", "file_id": "file_0123"}},
        {"type": "text", "text": "Résumez ce document."}]}],
)
print(f"{n.input_tokens} tokens ≈ {n.input_tokens * 2 / 1e6:.4f} $ d'entrée (Sonnet 5.5, nov. 2026)")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `count_tokens` reçoit la même liste `messages` qu'un vrai appel et renvoie seulement `n.input_tokens` ; on multiplie par le prix d'entrée de Sonnet 5.5 (2 $ par million). Attention, `"file_0123"` est un identifiant **fictif** : remplacez-le par un vrai `fichier.id` obtenu à la section 3, sinon vous obtiendrez une erreur 404.

🎮 **Défi** — Un syndic de copropriété veut interroger 120 procès-verbaux d'assemblée générale (PDF, 8 pages chacun) sur « qui a voté contre les travaux de toiture ? ». Calculez : 120 × 8 × ~3 000 tokens ≈ 2,9 M tokens. Une requête unique dépasse 1M. Que proposez-vous ? *(Réponse : Files API + Batch API en 120 requêtes Haiku 5.5 avec sortie structurée ≈ 0,15 $ en batch ; ou un index de recherche + `search_result` cités pour les questions suivantes.)*

## 🧪 Exercice pratique

**Consigne.** Construisez un **lecteur de factures fournisseurs** pour une PME :
1. Téléversez 3 factures (2 PDF, 1 photo JPEG) via la Files API ; conservez les `file_id` dans un fichier JSON.
2. Pour chaque fichier, extrayez `fournisseur`, `numero`, `date`, `total_ttc`, `tva` avec une sortie structurée (L071), modèle Haiku 5.5.
3. Pour le PDF le plus long, posez une question en mode **citations** (sans sortie structurée) et affichez les pages citées.
4. Avant chaque appel, estimez les tokens avec `count_tokens` et refusez tout document > 200 000 tokens.
5. Supprimez les fichiers à la fin.

**Critères de réussite.** Les trois extractions réussissent ; la photo illisible produit `null` et non une valeur inventée ; les citations pointent vers des pages existantes ; le coût total affiché est < 0,05 $.

<details>
<summary>Pistes</summary>

- Stockez `{"nom": "...", "file_id": "...", "expire": "..."}` ; la durée de conservation se choisit au téléversement (1 h à 90 j).
- Pour la photo, demandez explicitement « si le montant est illisible, renvoyez null ».
- Pour les citations sur PDF, lisez `c.start_page_number` / `c.end_page_number` (noms indicatifs ; vérifiez le type de localisation dans la réponse).
</details>

## ✅ Auto-évaluation express

1. Quels formats d'image la Messages API accepte-t-elle, et de quelles trois façons peut-on fournir une image ?
2. Pourquoi les citations sont-elles économiquement intéressantes ?
3. Quelle est la différence entre un fichier de la Files API et un document indexé dans un RAG ?

**Réponses.** 1. JPEG, PNG, GIF, WebP ; en base64, par URL ou par `file_id`. 2. Le `cited_text` n'est pas facturé en tokens de sortie, et les réponses sont vérifiables. 3. Le fichier est relu intégralement et facturé à chaque requête ; un RAG découpe, indexe et ne renvoie que les extraits pertinents.

> ✅ **Si vous ne retenez que 3 choses** — 1. Images et PDF sont de simples blocs de contenu (`image`, `document`) placés avant la question, en base64, par URL publique ou par `file_id` ; chaque page de PDF est lue comme texte et comme image, et tout se paie en tokens. 2. La Files API évite de renvoyer les octets à chaque fois, mais le document est relu et facturé à chaque requête : ce n'est pas un RAG. 3. Les citations (`citations.enabled`) rendent chaque affirmation vérifiable et le passage cité n'est pas facturé en sortie, mais elles ne se combinent pas avec les sorties structurées.

## 📚 Pour aller plus loin
- [Vision](https://platform.claude.com/docs/en/build-with-claude/vision) 🇬🇧 — formats, calcul des tokens, bonnes pratiques.
- [PDF support](https://platform.claude.com/docs/en/build-with-claude/pdf-support) 🇬🇧 — limites de taille et de pages, traitement texte + image.
- [Files API](https://platform.claude.com/docs/en/build-with-claude/files) 🇬🇧 — téléversement, expiration, usage avec code execution.
- [Citations](https://platform.claude.com/docs/en/build-with-claude/citations) 🇬🇧 — types de localisation, documents pré-découpés, incompatibilités.
- [Cookbook — Using citations](https://platform.claude.com/cookbook/misc-using-citations) 🇬🇧 — recette complète avec PDF.

> 🗺️ **Et maintenant ?** — Vous savez envoyer des dossiers volumineux ; la leçon L073 vous montre comment ne pas payer plein tarif à chaque relecture (prompt caching), traiter des milliers de requêtes à moitié prix (Batch API) et doser la réflexion de Claude (thinking, effort).
