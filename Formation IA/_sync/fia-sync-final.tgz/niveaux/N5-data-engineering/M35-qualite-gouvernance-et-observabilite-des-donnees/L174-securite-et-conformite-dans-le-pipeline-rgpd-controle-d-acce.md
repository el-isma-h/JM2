---
id: L174
module: M35
level: N5
title: "Sécurité et conformité dans le pipeline : RGPD, contrôle d'accès, chiffrement, AI Act art. 10"
minutes: 40
objectives:
  - "Appliquer les principes RGPD (minimisation, limitation de conservation, droits des personnes) aux couches bronze, silver, gold et à l'index vectoriel"
  - "Mettre en œuvre un contrôle d'accès au moindre privilège : rôles, sécurité au niveau des lignes et vues de masquage dans PostgreSQL"
  - "Choisir les mécanismes de chiffrement adaptés (au repos, en transit, par colonne, effacement cryptographique)"
  - "Relier les exigences de l'article 10 de l'AI Act aux artefacts produits par le pipeline (contrats, lignage, rapports de qualité et de biais)"
skills: ["C5.4"]
sources:
  - { title: "EUR-Lex — Règlement (UE) 2024/1689 (AI Act)", url: "https://eur-lex.europa.eu/eli/reg/2024/1689/oj", lang: "fr" }
  - { title: "CNIL — Développement des systèmes d'IA : les recommandations pour respecter le RGPD", url: "https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd", lang: "fr" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "CNIL — Finalisation des recommandations IA (22 juil. 2025)", url: "https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia", lang: "fr" }
  - { title: "Microsoft Presidio", url: "https://microsoft.github.io/presidio", lang: "en" }
---

# Sécurité et conformité dans le pipeline : RGPD, contrôle d'accès, chiffrement, AI Act art. 10

> ⏱ 40 min · 🎯 Niveau 5 · 📚 Module 35

## 🎯 Ce que vous saurez faire
- Cartographier où vivent les données personnelles de Bréval Matériaux (la PME fil rouge du niveau), de la source à l'index RAG, et décider où les réduire.
- Écrire en SQL un contrôle d'accès « chaque agence ne voit que ses clients » et une vue qui masque les colonnes sensibles.
- Propager un droit à l'effacement dans **toutes** les copies, y compris les snapshots et les vecteurs.
- Préparer la documentation de données exigée par l'article 10 de l'AI Act pour un système à haut risque.

> 🧭 **En clair** — Un pipeline de données, c'est un circuit de transport de fonds : on transporte quelque chose de précieux (les informations sur des personnes), et chaque étape doit être sécurisée. On transporte **le moins possible** (minimisation), dans des **fourgons blindés** (chiffrement), seules les personnes habilitées ouvrent les **coffres** (contrôle d'accès), on garde un **registre** de chaque mouvement (lignage, journaux), et l'on sait **détruire** ce qui doit l'être, partout (effacement). Le RGPD et l'AI Act ne sont pas des formulaires à remplir à la fin : ce sont des règles de conception du circuit.

## 1. Le RGPD, couche par couche

Les principes du RGPD ont été présentés en N1 (M07) et leur traduction en politique d'entreprise en N2 (M15) ; ici, vous les **implémentez**. La CNIL a finalisé en juillet 2025 ses recommandations et fiches pratiques sur le développement des systèmes d'IA : elles s'appliquent directement à la constitution d'un corpus RAG ou d'un jeu d'entraînement.

| Principe | Traduction dans le pipeline fil rouge |
|---|---|
| **Licéité, finalité** | chaque jeu de données est rattaché à une finalité et une base légale dans le contrat (L171) et le registre du DPO |
| **Minimisation** | la couche silver ne garde que les colonnes utiles ; le texte des tickets est **pseudonymisé** (Presidio, L177) avant chunking |
| **Exactitude** | tests et contrats (L170-L171) |
| **Limitation de conservation** | purge planifiée par table selon la durée du contrat (`retention`) ; expiration des snapshots |
| **Intégrité et confidentialité** | chiffrement, contrôle d'accès, journaux |
| **Droits des personnes** | effacement et rectification propagés jusqu'à l'index vectoriel |
| **Responsabilité** (*accountability*) | lignage, rapports de qualité, analyse d'impact (AIPD) quand elle est requise |

*AIPD = analyse d'impact relative à la protection des données, obligatoire pour les traitements à risque élevé ; le **NIR**, cité plus bas, est le numéro de sécurité sociale.*

L'architecture médaillon s'y prête bien : la **pseudonymisation se fait en ETL** entre bronze et silver, de sorte que seules quelques personnes (et aucun index vectoriel) accèdent aux données directement identifiantes.

```
 SOURCE (Postgres, PDF) ─▶ BRONZE brut, accès restreint, conservation courte (ex. 30 j)
                          │  ETL : Presidio (pseudonymisation), suppression des colonnes inutiles
                          ▼
                         SILVER pseudonymisé ─▶ GOLD agrégé ─▶ BI
                          │
                          └─▶ chunks + embeddings (jamais de NIR ni d'IBAN en clair) ─▶ index RAG
```

> ⚠️ **Piège fréquent** — Confondre **pseudonymisation** et **anonymisation**. Remplacer « Claire Martin » par `PERSONNE_7f3a` avec une table de correspondance (ou une clé) est une pseudonymisation : la donnée **reste personnelle** au sens du RGPD. L'anonymisation suppose qu'aucune réidentification ne soit raisonnablement possible, ce qui est très difficile sur du texte libre. Dans le doute, traitez la donnée comme personnelle.

```quiz
{
  "q": "Dans le pipeline fil rouge, où est-il le plus judicieux de pseudonymiser le texte des tickets SAV ?",
  "options": ["Dans le tableau de bord, à l'affichage", "Entre bronze et silver, avant le chunking et la vectorisation", "Directement dans la base de production de l'application SAV", "Après l'indexation vectorielle, en filtrant les réponses du LLM"],
  "answer": 1,
  "explanation": "Pseudonymiser en ETL avant silver garantit que les couches dérivées (marts, chunks, embeddings) ne contiennent jamais d'identifiants directs. Filtrer à l'affichage ou après l'indexation laisse les données personnelles copiées partout en amont."
}
```

## 2. Contrôle d'accès : moindre privilège, lignes et colonnes

Trois niveaux de granularité :

1. **Objet** (base, schéma, table) : rôles et `GRANT` ;
2. **Ligne** : sécurité au niveau des lignes (*Row-Level Security*, RLS) — « l'agence de Nantes ne voit que ses clients » ;
3. **Colonne** : vues de masquage, ou masquage dynamique dans les entrepôts qui le proposent.

Le modèle **RBAC** (rôles) suffit souvent ; l'**ABAC** (attributs : agence, service, niveau de classification) devient utile quand les combinaisons se multiplient. (RBAC = *Role-Based*, ABAC = *Attribute-Based Access Control*.) Exemple complet dans le PostgreSQL du Docker Compose du niveau :

```sql
-- acces.sql — à exécuter en superutilisateur sur la base breval du conteneur breval-postgres (Postgres 17, L151) :
--   docker exec -i breval-postgres psql -U breval -d breval < acces.sql
CREATE SCHEMA IF NOT EXISTS silver;
CREATE TABLE IF NOT EXISTS silver.clients (
  id BIGINT PRIMARY KEY, nom TEXT, ville TEXT, cree_le TIMESTAMPTZ,
  agence_id CHAR(3) NOT NULL, email TEXT, telephone TEXT);   -- NAN, STN, ANC (L151)
INSERT INTO silver.clients                                    -- alimentée depuis l'ERP chargé en L152
SELECT client_id, nom, ville, date_creation, agence_id, email, telephone FROM erp.clients
ON CONFLICT (id) DO NOTHING;

-- 1) Rôles fonctionnels (sans droit de connexion) et utilisateurs
CREATE ROLE lecteur_nan NOLOGIN;  CREATE ROLE lecteur_stn NOLOGIN;  CREATE ROLE analyste NOLOGIN;
CREATE ROLE alice LOGIN PASSWORD 'change-moi' IN ROLE lecteur_nan;
CREATE ROLE bruno LOGIN PASSWORD 'change-moi' IN ROLE analyste;

-- 2) Sécurité au niveau des lignes : chaque lecteur d'agence ne voit que les clients de son agence
ALTER TABLE silver.clients ENABLE ROW LEVEL SECURITY;
CREATE POLICY clients_nan ON silver.clients FOR SELECT TO lecteur_nan USING (agence_id = 'NAN');
CREATE POLICY clients_stn ON silver.clients FOR SELECT TO lecteur_stn USING (agence_id = 'STN');
GRANT USAGE ON SCHEMA silver TO lecteur_nan, lecteur_stn, analyste;
GRANT SELECT ON silver.clients TO lecteur_nan, lecteur_stn;

-- 3) Vue de masquage pour les analystes : pas de contact direct, ville conservée
CREATE OR REPLACE VIEW silver.clients_analyse AS
SELECT id, ville, cree_le, agence_id,
       left(nom, 1) || '***'                         AS nom_masque,
       regexp_replace(telephone, '\d(?=\d{2})', '•', 'g') AS telephone_masque
FROM silver.clients;
GRANT SELECT ON silver.clients_analyse TO analyste;   -- aucun droit sur la table elle-même
```

> 🧭 **Pré-requis express** — Enregistrez ce bloc sous `breval/acces.sql` et lancez la commande indiquée en commentaire depuis `breval/` (sous PowerShell : `Get-Content acces.sql | docker exec -i breval-postgres psql -U breval -d breval`). Un **superutilisateur** a tous les droits sur la base : c'est le cas de l'utilisateur `breval` créé par l'image Docker, qui n'est donc **pas** soumis à la RLS.

> 🔍 **Ce que vous devez voir** — une suite de réponses `CREATE SCHEMA`, `CREATE TABLE`, `INSERT 0 5075`, `CREATE ROLE` (×5), `ALTER TABLE`, `CREATE POLICY` (×2), `GRANT` (×3), `CREATE VIEW`, `GRANT`. Pour vérifier la RLS, ouvrez `docker exec -it breval-postgres psql -U breval -d breval`, puis tapez `SET ROLE alice;` et `SELECT agence_id, count(*) FROM silver.clients GROUP BY 1;` : une **seule** ligne `NAN | …` s'affiche. `RESET ROLE; SET ROLE bruno; SELECT * FROM silver.clients_analyse LIMIT 3;` montre des noms du type `M***` et des téléphones masqués, alors que `SELECT * FROM silver.clients;` (toujours en `bruno`) répond `ERROR: permission denied for table clients`.

> 🛠️ **Si ça ne marche pas** — « ERROR: role "lecteur_nan" already exists » (et les erreurs suivantes) au second lancement → les rôles ont été créés la première fois : c'est sans conséquence, ou repartez de zéro avec `DROP OWNED BY alice, bruno, lecteur_nan, lecteur_stn, analyste; DROP ROLE alice, bruno, lecteur_nan, lecteur_stn, analyste;`. Vous voyez les trois agences en étant connecté en `breval` → normal : superutilisateur, il contourne la RLS (voir le piège ci-dessous) ; testez avec `SET ROLE alice`. « relation "erp.clients" does not exist » → l'ERP n'a pas été chargé (L152).

> 💡 **Autrement dit** — Le `GRANT` ouvre la porte de la pièce, la politique RLS décide quels tiroirs on peut ouvrir dans la pièce, et la vue de masquage floute certaines lignes des fiches avant de les montrer.

Le même principe s'applique à l'index vectoriel : chaque chunk porte un attribut `service` ou `agence_id` (le `tenant_id` de L178, issu par exemple de la colonne `service` de `documents.csv`) et **chaque requête** de l'assistant RAG filtre dessus (multi-tenance, L178). Un filtre oublié dans l'application équivaut à une RLS désactivée. (La **multi-tenance** consiste à servir plusieurs « locataires », ici agences ou services, depuis un même index, chacun ne voyant que ses données.)

> ⚠️ **Piège fréquent** — Dans PostgreSQL, les superutilisateurs et les rôles dotés de l'attribut `BYPASSRLS` **contournent** toujours la RLS ; le propriétaire de la table aussi, sauf `ALTER TABLE … FORCE ROW LEVEL SECURITY`. Ne faites jamais tourner l'application ou le pipeline avec le rôle propriétaire.

## 3. Chiffrement et secrets

| Où | Mécanisme | Dans l'environnement de TP |
|---|---|---|
| **En transit** | TLS partout (le chiffrement des connexions réseau, le « s » de HTTPS) (Postgres `sslmode=require`, HTTPS vers MinIO/Qdrant, Kafka SSL) | certificats auto-signés en local, gérés par l'hébergeur en production |
| **Au repos** | chiffrement des disques et du stockage objet (SSE avec clés gérées par un KMS) — *Server-Side Encryption* ; un KMS, *Key Management Service*, est un service qui garde et fait tourner les clés de chiffrement | chiffrement côté serveur de MinIO avec un KMS, ou chiffrement de volume |
| **Par colonne** | chiffrement applicatif des champs très sensibles (NIR, IBAN) avec `pgcrypto` ou une bibliothèque (`pgcrypto` est l'extension de chiffrement de Postgres) | clé dans une variable d'environnement en TP, dans un coffre (Vault, KMS) en production |
| **Effacement cryptographique** (*crypto-shredding*) | une clé par personne ; détruire la clé rend toutes ses copies chiffrées illisibles, y compris dans les sauvegardes | utile quand on ne peut pas réécrire les sauvegardes |

Règle d'hygiène : **aucun secret dans le code ni dans Git** (clés API d'embedding, mots de passe de base) ; variables d'environnement en TP, gestionnaire de secrets en production, rotation régulière.

## 4. Propager un droit à l'effacement

Une demande d'effacement du client n° 2 doit atteindre **toutes** les copies identifiées par le lignage (L172) :

```python
# effacement.py — propagation d'une demande d'effacement (squelette exécutable sur l'environnement de TP)
import os
import duckdb

CLIENT_ID = 2
con = duckdb.connect("data/breval.duckdb")      # tables simplifiées de L170

# 1) Tables relationnelles (silver/gold) : suppression ou anonymisation selon les obligations légales
#    (les factures doivent souvent être conservées : on anonymise alors au lieu de supprimer)
con.execute("DELETE FROM tickets_sav WHERE client_id = ?", [CLIENT_ID])
con.execute("UPDATE clients SET nom = 'ANONYMISÉ', ville = NULL WHERE id = ?", [CLIENT_ID])

# 2) Index vectoriel : suppression des chunks par filtre de métadonnées
#    L'index (alias « chunks » de la collection Qdrant) n'est construit qu'en L178 :
#    si vous n'avez pas encore fait L178, cette étape est sautée avec un message, sans erreur.
try:
    from qdrant_client import QdrantClient, models
    qdrant = QdrantClient(url=os.environ.get("QDRANT_URL", "http://localhost:6333"))
    alias = {a.alias_name for a in qdrant.get_aliases().aliases}
    if "chunks" in alias or qdrant.collection_exists("chunks"):
        qdrant.delete(
            collection_name="chunks",
            points_selector=models.FilterSelector(filter=models.Filter(must=[
                models.FieldCondition(key="client_id", match=models.MatchValue(value=CLIENT_ID))])),
        )
    else:
        print("Index vectoriel absent (L178 pas encore faite) : étape 2 sautée.")
except Exception as e:          # qdrant-client non installé ou Qdrant non démarré
    print(f"Index vectoriel injoignable ({type(e).__name__}) : étape 2 à refaire après L178.")

# 3) Formats de table ouverts : la suppression logique ne suffit pas, il faut purger l'historique
#    Iceberg : CALL system.expire_snapshots(...) puis remove_orphan_files ; Delta : VACUUM (après la rétention)
# 4) Journaliser la demande (date, périmètre, preuve d'exécution) pour l'accountability
print(f"Effacement du client {CLIENT_ID} propagé ; pensez aux snapshots et sauvegardes.")
```

> 🧭 **Pré-requis express** — Ce squelette vise un index vectoriel **qui n'existe pas encore** : la collection Qdrant, accessible par l'alias `chunks`, est construite en M36 (L178). Si vous n'avez pas encore fait L178, lancez le script tel quel : l'étape 2 est sautée avec un message (« Index vectoriel absent… » ou « … injoignable »), les étapes DuckDB s'exécutent ; relancez-le après L178 (avec `pip install qdrant-client` et un Qdrant démarré, par exemple `docker run -d -p 6333:6333 --name breval-qdrant qdrant/qdrant`) pour effacer aussi les vecteurs. Le script modifie les tables simplifiées de L170 : relancez `creer_tables_qualite.py` pour les remettre en état.

> 🔍 **Ce que vous devez voir** — la ligne `Effacement du client 2 propagé ; pensez aux snapshots et sauvegardes.`, précédée avant L178 d'un message indiquant que l'étape 2 est sautée. Vérifiez ensuite dans DuckDB : `SELECT * FROM clients WHERE id = 2` montre `ANONYMISÉ` et une ville vide, `SELECT count(*) FROM tickets_sav WHERE client_id = 2` renvoie 0.

> 🛠️ **Si ça ne marche pas** — « Index vectoriel absent » → normal avant L178 : voir le pré-requis ci-dessus. « Index vectoriel injoignable (ResponseHandlingException) » ou « Connection refused » → Qdrant n'est pas démarré sur le port 6333. « … injoignable (ModuleNotFoundError) » → `pip install qdrant-client`.

> ⚠️ **Piège fréquent** — Le *time travel* (M32) est un ami pour le débogage et un ennemi pour l'effacement : tant que les anciens snapshots Iceberg ou fichiers Delta existent, la donnée « supprimée » est toujours lisible. Alignez la rétention des snapshots sur vos délais de réponse aux demandes (un mois en principe, prolongeable dans certains cas selon le RGPD).

## 5. AI Act, article 10 : la gouvernance des données d'entraînement

Le règlement (UE) 2024/1689 (AI Act, présenté en N1 et N2) impose, dans son **article 10**, des pratiques de gouvernance des données pour les **systèmes d'IA à haut risque** (par exemple le tri de candidatures ou l'évaluation de salariés, annexe III). Les jeux d'entraînement, de validation et de test doivent faire l'objet de pratiques portant notamment sur :

- les **choix de conception** et l'**origine** des données (et, pour les données personnelles, la finalité initiale de leur collecte) ;
- les **opérations de préparation** : annotation, étiquetage, nettoyage, mise à jour, enrichissement, agrégation ;
- les **hypothèses** formulées sur ce que les données mesurent et représentent ;
- l'évaluation de la **disponibilité, de la quantité et de l'adéquation** des jeux ;
- l'examen des **biais** possibles et les mesures pour les détecter, les prévenir et les atténuer ;
- l'identification des **lacunes** de données et la façon d'y remédier.

Les jeux doivent être **pertinents, suffisamment représentatifs** et, dans toute la mesure du possible, **exempts d'erreurs et complets** au regard de la finalité. L'article 10(5) autorise, à titre exceptionnel et avec des garanties strictes, le traitement de catégories particulières de données (les données dites « sensibles » du RGPD : santé, origine, opinions, religion, orientation sexuelle…) **pour détecter et corriger des biais**.

Calendrier (nov. 2026) : les obligations des systèmes à haut risque de l'annexe III, initialement prévues au 2 août 2026, ont été **reportées au 2 décembre 2027** par le règlement « omnibus » (UE) 2026/1744 (publié au JOUE le 24 juillet 2026, en vigueur le 27 juillet 2026) (JOUE = Journal officiel de l'Union européenne ; EUR-Lex est le site officiel où l'on consulte les textes européens à jour) ; relisez la version consolidée sur EUR-Lex avant toute communication contractuelle.

Ce qui est remarquable : **presque tout ce que demande l'article 10 est déjà produit par un pipeline bien gouverné**.

| Exigence de l'article 10 | Artefact du pipeline N5 |
|---|---|
| Origine et finalité de collecte | contrat ODCS (`description`, `purpose`), catalogue (L171-L172) |
| Opérations de préparation | code versionné (dbt, scripts M36), lignage OpenLineage |
| Qualité, erreurs, complétude | rapports dbt/GX/Soda (L170), moniteurs (L173) |
| Représentativité, lacunes | profils statistiques par segment (région, âge, sexe quand légitime) |
| Biais | rapport d'analyse de biais versionné avec le jeu (DVC/lakeFS, L179) |
| Traçabilité | version du jeu + version du code + version du modèle |

```mission
{
  "title": "Les jeux de données visés par l'article 10 de l'AI Act",
  "url": "https://eur-lex.europa.eu/eli/reg/2024/1689/oj",
  "steps": ["Ouvrez le règlement (UE) 2024/1689 sur EUR-Lex (version française)", "Allez à l'article 10 « Données et gouvernance des données »", "Lisez le paragraphe 1 puis le paragraphe 3"],
  "question": "Quels trois types de jeux de données l'article 10 mentionne-t-il, et quelles qualités le paragraphe 3 exige-t-il de ces jeux ?",
  "hint": "Le paragraphe 1 parle d'entraînement, de validation et de…",
  "answer": "Les jeux d'entraînement, de validation et de test ; ils doivent être pertinents, suffisamment représentatifs et, dans toute la mesure du possible, exempts d'erreurs et complets au regard de la destination du système (texte consolidé consulté en nov. 2026 ; vérifiez les modifications éventuelles de l'omnibus 2026/1744).",
  "xp": 20
}
```

```quiz
{
  "q": "Next RH développe un module qui classe automatiquement les candidatures. Quel artefact de pipeline répond le plus directement à l'exigence d'examen des biais de l'article 10 ?",
  "options": ["Le chiffrement TLS de bout en bout entre Postgres et l'entrepôt de données", "Un rapport de représentation et de résultats par groupe, versionné avec le jeu", "La politique RLS qui limite l'accès aux candidatures par service", "Le z-score du volume quotidien de candidatures, historisé sur 28 jours"],
  "answer": 1,
  "explanation": "L'article 10 demande d'examiner les biais et de prendre des mesures pour les détecter et les atténuer. Un rapport par groupe, versionné avec le jeu de données, documente cet examen ; les autres éléments relèvent de la sécurité ou de l'observabilité."
}
```

## 🧪 Exercice pratique

**Consigne** : pour Bréval Matériaux, produisez (1) une **cartographie** des données personnelles (tableau : table/fichier, colonne, catégorie, couche, base légale pressentie, durée de conservation, mesure de protection) couvrant `clients`, `commandes`, `tickets_sav`, les PDF internes et l'index RAG ; (2) le script `acces.sql` adapté avec une politique RLS sur `tickets_sav` par agence ; (3) une procédure d'effacement en 6 étapes qui cite chaque copie.

**Critères de réussite** : au moins 8 lignes dans la cartographie dont l'index vectoriel et les snapshots ; un utilisateur `lecteur_nan` ne voit aucun ticket de l'agence de Saint-Nazaire (requête de vérification fournie) ; la procédure mentionne les sauvegardes et le journal de preuve.

**Pistes de corrigé** : catégories « identification » (nom), « coordonnées » (téléphone dans `texte`), « économique et financière » (IBAN éventuels dans `messages[].texte`, montants) ; responsables nommés avec leur téléphone dans les procédures ; base légale contrat pour la gestion des commandes et du SAV ; conservation des pièces comptables selon les obligations légales (10 ans en France pour les documents comptables — à faire confirmer par l'expert-comptable) ; bronze 30 jours ; chunks pseudonymisés. Vérification RLS : `SET ROLE alice; SELECT DISTINCT agence_id FROM silver.tickets_sav;` doit renvoyer uniquement `NAN` (ajoutez `agence_id` aux tickets via la commande ou le client, comme dans le champ `agent.agence` du jeu L151).

## ✅ Auto-évaluation express
1. Une donnée pseudonymisée est-elle encore une donnée personnelle ?
2. Pourquoi le *time travel* complique-t-il l'effacement ?
3. Citez trois exigences de l'article 10 de l'AI Act.

**Réponses** : 1. Oui, tant qu'une réidentification reste possible (clé, table de correspondance, recoupements). 2. Les anciens snapshots conservent la donnée supprimée tant qu'ils ne sont pas expirés et purgés. 3. Par exemple : documenter l'origine des données, décrire les opérations de préparation, examiner les biais, identifier les lacunes, garantir des jeux pertinents et représentatifs.

## 📚 Pour aller plus loin
- [EUR-Lex — Règlement (UE) 2024/1689](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) 🇫🇷 — texte officiel, article 10.
- [CNIL — Recommandations pour respecter le RGPD lors du développement des systèmes d'IA](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd) 🇫🇷 — synthèse.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — base légale, minimisation, annotation, sécurité.
- [CNIL — Finalisation des recommandations (juillet 2025)](https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia) 🇫🇷
- [Microsoft Presidio](https://microsoft.github.io/presidio) 🇬🇧 — l'outil de détection et de pseudonymisation mis en œuvre en L177.

> ✅ **Si vous ne retenez que 3 choses** — 1. Le RGPD se traduit en règles de conception du pipeline : minimiser dès la couche silver, pseudonymiser en ETL avant tout index vectoriel (une donnée pseudonymisée reste personnelle), limiter la conservation, journaliser. 2. Le contrôle d'accès s'exerce à trois niveaux : objet (`GRANT`), ligne (RLS : chaque agence ne voit que ses clients) et colonne (vues de masquage) ; les superutilisateurs et propriétaires contournent la RLS, et l'index RAG doit filtrer chaque requête de la même façon. 3. Un effacement doit atteindre **toutes** les copies trouvées par le lignage (tables, index vectoriel, snapshots Iceberg/Delta, sauvegardes) ; l'article 10 de l'AI Act demande une documentation des données d'entraînement qu'un pipeline bien gouverné produit déjà presque entièrement.

> 🗺️ **Et maintenant ?** — Le module M36 passe de la gouvernance à la préparation concrète des données pour l'IA, en commençant par la construction d'un corpus texte propre à partir des PDF et des tickets de la PME (L175).
