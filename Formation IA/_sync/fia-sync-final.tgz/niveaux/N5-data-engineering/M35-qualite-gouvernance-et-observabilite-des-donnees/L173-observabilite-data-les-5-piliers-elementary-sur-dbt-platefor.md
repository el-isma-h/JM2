---
id: L173
module: M35
level: N5
title: "Observabilité data : les 5 piliers, Elementary sur dbt, plateformes commerciales, gestion d'incident"
minutes: 40
objectives:
  - "Expliquer les cinq piliers de l'observabilité des données et l'indicateur de data downtime"
  - "Construire des moniteurs de fraîcheur, de volume et de schéma en SQL sur DuckDB, puis avec le package Elementary pour dbt"
  - "Comparer l'approche open source et les plateformes commerciales (Monte Carlo, Sifflet, Bigeye…)"
  - "Conduire un incident de données de la détection au post-mortem avec un runbook"
skills: ["C5.6"]
sources:
  - { title: "DataDriven — Data Observability: 5 Pillars and Tools (2026)", url: "https://datadriven.io/data-observability", lang: "en" }
  - { title: "Elementary — documentation", url: "https://docs.elementary-data.com/", lang: "en" }
  - { title: "Monte Carlo", url: "https://www.montecarlodata.com/", lang: "en" }
  - { title: "dbt — Source freshness", url: "https://docs.getdbt.com/docs/deploy/source-freshness", lang: "en" }
  - { title: "OpenLineage — Object model", url: "https://openlineage.io/docs/spec/object-model", lang: "en" }
---

# Observabilité data : les 5 piliers, Elementary sur dbt, plateformes commerciales, gestion d'incident

> ⏱ 40 min · 🎯 Niveau 5 · 📚 Module 35

## 🎯 Ce que vous saurez faire
- Couvrir les cinq piliers (fraîcheur, volume, schéma, qualité, lignage) sur les tables de Bréval Matériaux (la PME fil rouge du niveau).
- Détecter une anomalie de volume sans écrire de seuil fixe, avec un score statistique simple.
- Mener un incident : alerte, tri, diagnostic, correction, post-mortem.

> 🧭 **En clair** — Les tests de L170, c'est le contrôle technique de la voiture : on vérifie des points connus à l'avance. L'**observabilité**, c'est le tableau de bord allumé pendant que vous roulez : jauge d'essence (fraîcheur), compteur (volume), voyant moteur (schéma qui change), température (qualité qui dérive) et GPS (lignage, pour savoir d'où vient le problème). Elle détecte aussi ce que personne n'avait prévu de tester : « hier, 3 000 commandes ; aujourd'hui, 40 ». L'objectif : apprendre la panne **avant** le directeur financier.

## 1. Les cinq piliers et le *data downtime*

Formalisés par Barr Moses (Monte Carlo) dans un essai de décembre 2020, les cinq piliers sont devenus le vocabulaire commun du métier :

| Pilier | Question | Signal typique sur la PME |
|---|---|---|
| **Fraîcheur** | La donnée est-elle arrivée à l'heure ? | `max(maj_le)` de `commandes` a plus de 4 h (SLA du contrat L171) |
| **Volume** | La quantité est-elle normale ? | 40 commandes un mardi au lieu de ~3 000 |
| **Schéma** | La structure a-t-elle changé ? | colonne `montant_ttc` disparue, type modifié |
| **Qualité** (ex-« distribution ») | Les valeurs sont-elles plausibles ? | part de `client_id` nuls passée de 0 % à 12 % ; montant moyen divisé par 100 (centimes au lieu d'euros) |
| **Lignage** | Qui est touché, d'où vient le problème ? | graphe OpenLineage de L172 |

L'indicateur de pilotage est le ***data downtime*** : le temps pendant lequel une donnée est absente, fausse ou incomplète. On le décompose ainsi :

```
data downtime ≈ nombre d'incidents × (temps de détection + temps de résolution)
```

> 💡 **À retenir** — Les tests réduisent le **nombre** d'incidents qui atteignent la production ; l'observabilité réduit surtout le **temps de détection**, souvent le plus long (des jours quand c'est un utilisateur qui s'en aperçoit).

```quiz
{
  "q": "Les montants de commandes arrivent soudain en centimes (12990 au lieu de 129,90). Les types et les colonnes n'ont pas changé. Quel pilier détecte ce problème ?",
  "options": ["La fraîcheur", "Le schéma", "La qualité", "Le volume"],
  "answer": 2,
  "explanation": "Le schéma est intact et le nombre de lignes normal : seule la distribution des valeurs (moyenne, médiane, percentiles) change brutalement. C'est le pilier qualité, anciennement appelé distribution."
}
```

## 2. Des moniteurs « maison » en SQL : comprendre avant d'outiller

Avant tout outil, écrivez le principe vous-même. Ce script mesure chaque jour fraîcheur, volume et empreinte de schéma, les historise, et lève une alerte quand le volume s'écarte de plus de 3 écarts-types de sa moyenne sur 28 jours (un *z-score*). (L'**écart-type** mesure de combien les valeurs s'écartent habituellement de leur moyenne : petit si le volume est très régulier, grand s'il varie beaucoup.)

```python
# moniteurs.py — observabilité minimale sur les tables simplifiées de L170 (à planifier chaque heure ou chaque jour)
import datetime as dt
import hashlib
import duckdb

con = duckdb.connect("data/breval.duckdb")
con.execute("""
CREATE TABLE IF NOT EXISTS obs_metriques (
  mesure_le TIMESTAMP, table_nom VARCHAR, nb_lignes BIGINT,
  derniere_maj TIMESTAMP, schema_hash VARCHAR, taux_client_nul DOUBLE)
""")

TABLES = {"commandes": "maj_le", "tickets_sav": "cree_le"}
alertes = []

for table, col_ts in TABLES.items():
    nb, derniere, taux_nul = con.execute(f"""
        SELECT count(*), max({col_ts}), avg(CASE WHEN client_id IS NULL THEN 1 ELSE 0 END)
        FROM {table}""").fetchone()
    colonnes = con.execute(
        "SELECT column_name, data_type FROM information_schema.columns "
        "WHERE table_schema = 'main' AND table_name = ? ORDER BY ordinal_position",   # bronze.commandes (dlt) existe aussi
        [table]).fetchall()
    schema_hash = hashlib.sha256(repr(colonnes).encode()).hexdigest()[:16]

    # Historique AVANT d'insérer la mesure du jour
    hist = con.execute("""
        SELECT avg(nb_lignes), stddev_samp(nb_lignes), arg_max(schema_hash, mesure_le), count(*)
        FROM obs_metriques
        WHERE table_nom = ? AND mesure_le > now() - INTERVAL 28 DAY""", [table]).fetchone()
    moyenne, ecart, dernier_hash, n_hist = hist

    # 1) Fraîcheur : comparée au SLA (4 h pour commandes)
    if derniere is None or dt.datetime.now() - derniere > dt.timedelta(hours=4):
        alertes.append(f"[FRAÎCHEUR] {table} : dernière donnée {derniere}")
    # 2) Volume : z-score si l'historique est suffisant
    if n_hist and n_hist >= 7 and ecart:
        z = (nb - moyenne) / ecart
        if abs(z) > 3:
            alertes.append(f"[VOLUME] {table} : {nb} lignes (moyenne {moyenne:.0f}, z = {z:.1f})")
    # 3) Schéma : empreinte différente de la précédente
    if dernier_hash and dernier_hash != schema_hash:
        alertes.append(f"[SCHÉMA] {table} : structure modifiée ({dernier_hash} → {schema_hash})")
    # 4) Qualité : complétude d'une colonne critique
    if taux_nul and taux_nul > 0.01:
        alertes.append(f"[QUALITÉ] {table} : {taux_nul:.1%} de client_id nuls")

    con.execute("INSERT INTO obs_metriques VALUES (now(), ?, ?, ?, ?, ?)",
                [table, nb, derniere, schema_hash, taux_nul])

print("\n".join(alertes) or "Aucune anomalie")
# En production : envoyer `alertes` vers le canal du contrat (Slack, Teams, e-mail) et ouvrir un incident.
```

*Lecture du code : `information_schema.columns` est une vue standard SQL qui liste les colonnes de chaque table ; l'**empreinte de schéma** (`schema_hash`) résume la liste des colonnes et de leurs types en 16 caractères : si elle change, la structure a changé.*

> 🔍 **Ce que vous devez voir** — au **premier** lancement (depuis `breval/`, après `creer_tables_qualite.py` de L170), une ou deux lignes `[FRAÎCHEUR] commandes : dernière donnée 2026-…` et `[FRAÎCHEUR] tickets_sav : …` (les données de démonstration s'arrêtent fin octobre 2026, bien au-delà du SLA de 4 h), et **aucune** alerte de volume ni de schéma : il faut au moins 7 mesures d'historique pour le z-score, et une mesure précédente pour comparer les empreintes. Chaque lancement ajoute deux lignes dans `obs_metriques` (vérifiez avec `SELECT * FROM obs_metriques`).

> 🛠️ **Si ça ne marche pas** — « Catalog Error: Table with name commandes does not exist » → lancez d'abord `creer_tables_qualite.py` (L170). « Could not set lock on file » → fermez les autres programmes qui ont ouvert `breval.duckdb`.

> 💡 **Autrement dit** — Le *z-score* mesure « à combien de pas habituels » on se trouve de la normale. Si les commandes varient d'habitude de ±200 autour de 3 000, 40 commandes se trouvent à près de 15 pas : c'est anormal, sans qu'on ait eu besoin de fixer un seuil à la main.

> ⚠️ **Piège fréquent** — La **saisonnalité**. Le volume du dimanche ou du mois d'août n'est pas celui d'un mardi de novembre : comparez au même jour de la semaine, ou utilisez un outil qui modélise la saisonnalité. Sinon, chaque lundi déclenche une fausse alerte, et l'équipe finit par couper les alertes.

## 3. Elementary : l'observabilité open source dans dbt

**Elementary** est un package dbt open source (un **package** dbt est un ensemble de macros et de modèles prêts à l'emploi, déclaré dans `packages.yml` et téléchargé par `dbt deps`) (avec une offre cloud) qui ajoute des **tests d'anomalies** et un **rapport** d'observabilité. Il stocke les résultats des exécutions et des tests dans un schéma dédié de votre entrepôt, puis le CLI `edr` produit un rapport HTML et envoie des alertes.

```yaml
# packages.yml — prenez la version indiquée sur la page d'installation d'Elementary
packages:
  - package: elementary-data/elementary
    version: [">=0.16.0", "<1.0.0"]   # à ajuster selon la version courante et votre dbt

# dbt_project.yml (extrait)
models:
  elementary:
    +schema: "elementary"
```

```yaml
# models/staging/_elementary.yml — moniteurs Elementary sur le modèle silver stg_commandes (créé en L170)
version: 2
models:
  - name: stg_commandes
    config:
      elementary:
        timestamp_column: maj_le
    data_tests:
      - elementary.volume_anomalies        # volume par période vs historique
      - elementary.freshness_anomalies     # retard inhabituel
      - elementary.schema_changes          # colonne ajoutée, supprimée, type modifié
    columns:
      - name: montant_ttc
        data_tests:
          - elementary.column_anomalies:
              arguments:
                column_anomalies: [null_count, average, min]
```

> 🧭 **Pré-requis express** — Ce YAML vise le modèle de démonstration `stg_commandes` créé en L170 (section 2.2) sur les tables simplifiées, qui a bien les colonnes `maj_le` et `montant_ttc` : créez-le d'abord si ce n'est pas fait, sinon dbt signale un test « sur un nœud introuvable » et l'ignore. Pour surveiller plutôt le modèle Bréval complet de L163, adaptez-le : `name: stg_erp__commandes`, `timestamp_column: mis_a_jour_le` et colonne `montant_ht` au lieu de `montant_ttc`.

```bash
pip install "elementary-data"          # CLI edr ; ajoutez l'extra de votre adaptateur (ex. [postgres])
dbt deps && dbt run --select elementary # crée les tables de suivi
dbt build                               # exécute modèles + tests (dont anomalies)
edr report                              # rapport HTML local
edr monitor --slack-webhook "$SLACK_WEBHOOK_URL"   # alertes
```

> 🔍 **Ce que vous devez voir** — `dbt deps` affiche `Installing elementary-data/elementary` puis `Installed from version 0.x.y` ; `dbt run --select elementary` crée une vingtaine de tables dans le schéma `elementary` ; `dbt build` exécute vos tests, les tests d'anomalies affichant `PASS` tant qu'il n'y a pas assez d'historique ; `edr report` génère un fichier `edr_target/elementary_report.html` et l'ouvre dans le navigateur (tableaux de tests, graphiques de volume, lignage).

> 🛠️ **Si ça ne marche pas** — « Adapter duckdb is not supported » ou erreurs de macros Elementary → adaptateur non pris en charge par votre version : suivez le piège ci-dessous. `edr monitor` ne fait rien sans webhook : la variable `SLACK_WEBHOOK_URL` doit contenir l'adresse fournie par Slack (*Incoming Webhooks*) ; pour un essai, contentez-vous de `edr report`.

> ⚠️ **Piège fréquent** — Vérifiez dans la [documentation Elementary](https://docs.elementary-data.com/) que votre adaptateur dbt est pris en charge (la liste évolue). Si DuckDB n'y figure pas pour votre version, faites tourner la partie observabilité sur le Postgres du Docker Compose du niveau, ou conservez les moniteurs SQL du §2.

```mission
{
  "title": "Les tests d'anomalies proposés par Elementary",
  "url": "https://docs.elementary-data.com/",
  "steps": ["Ouvrez la documentation Elementary", "Allez dans la partie consacrée aux tests (anomaly detection tests)", "Listez les types de tests d'anomalies disponibles et les paramètres de sensibilité"],
  "question": "Citez au moins quatre tests d'anomalies Elementary et le nom du paramètre qui règle la sensibilité de détection.",
  "hint": "Les noms commencent par « elementary. » ; la sensibilité s'exprime en écarts-types.",
  "answer": "Par exemple volume_anomalies, freshness_anomalies, column_anomalies, all_columns_anomalies, dimension_anomalies, event_freshness_anomalies, plus schema_changes ; la sensibilité se règle avec anomaly_sensitivity (nombre d'écarts-types, 3 par défaut) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Plateformes commerciales : ce que l'on achète

| Offre | Exemples (nov. 2026) | Ce qu'elles ajoutent |
|---|---|---|
| Plateformes dédiées | **Monte Carlo**, Bigeye, Anomalo, **Sifflet** (éditeur français), Acceldata | détection automatique sans configuration table par table, modèles de saisonnalité, lignage colonne, triage d'incidents, intégrations BI |
| Rachats et consolidation | **Datadog** a racheté Metaplane (2025) | observabilité data intégrée à l'observabilité applicative |
| Fonctions natives des entrepôts | fonctions de métriques Snowflake, *data quality monitoring* Databricks | aucun outil de plus, mais limité à la plateforme |

Critères de décision : nombre de tables critiques (au-delà de quelques centaines, la configuration manuelle devient intenable), multiplicité des sources, exigences d'audit, et coût (licences souvent indexées sur le volume de tables ou de requêtes, sur devis). Pour une PME avec une cinquantaine de tables et un pipeline dbt, **Elementary + moniteurs SQL** suffit largement.

```quiz
{
  "type": "vrai_faux",
  "q": "Pour une PME qui a 40 modèles dbt et un seul data engineer, une plateforme commerciale d'observabilité est indispensable dès le premier jour.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : à cette échelle, les tests dbt, quelques moniteurs SQL et Elementary couvrent les cinq piliers. Une plateforme commerciale devient rentable avec des centaines de tables, de nombreuses sources ou des exigences d'audit fortes."
}
```

## 5. Gestion d'incident : de l'alerte au post-mortem

Un incident de données se gère comme un incident applicatif, avec un **runbook** (procédure écrite) :

```
ALERTE ──▶ TRIER ──▶ COMMUNIQUER ──▶ DIAGNOSTIQUER ──▶ CORRIGER ──▶ RATTRAPER ──▶ POST-MORTEM
 (moniteur) (sévérité) (canal du     (lignage amont,  (code, source, (backfill,    (sans recherche
                        contrat)      diff de schéma)  contrat)       ré-indexation) de coupable)
```

| Sévérité | Définition | Délai de prise en charge |
|---|---|---|
| **SEV1** | donnée fausse exposée à des clients ou à une décision réglementaire (ex. assistant SAV qui donne de faux montants) | immédiat, coupure du flux si besoin |
| **SEV2** | tableau de bord ou modèle ML interne faux ou absent | dans la journée |
| **SEV3** | anomalie sans impact avéré, dérive lente | planifiée |

**Gabarit de post-mortem** (une page, sans désigner de coupable) : (*post-mortem* : l'analyse écrite d'un incident une fois résolu ; « sans coupable », car le but est de corriger le système, pas de sanctionner une personne)

```markdown
## Incident 2026-11-03 — commandes en centimes
- Impact : CA affiché ×100 dans le tableau de bord direction de 06:00 à 10:40 ; assistant SAV non touché (lit montant formaté).
- Détection : elementary.column_anomalies (average) à 06:12 ; prise en charge 08:30 (SEV2).
- Cause racine : nouvelle version de l'API e-commerce, montant en centimes ; pas de contrat côté fournisseur.
- Correction : division par 100 dans stg_commandes + règle qualité « montant moyen entre 20 et 500 € ».
- Rattrapage : `dbt build --select stg_commandes+` sur la période ; contrôle par la comptabilité.
- Actions : contrat ODCS avec le prestataire (unité explicite), test de distribution bloquant (owner : C. Durand, échéance 15/11).
- Data downtime : 4 h 40 (détection 12 min, résolution 4 h 28).
```

> 💡 **À retenir** — Chaque post-mortem doit produire au moins **une règle nouvelle** (test, contrat, moniteur) : c'est ainsi que les mêmes incidents ne reviennent pas.

## 🧪 Exercice pratique

**Consigne** : (1) lancez `moniteurs.py` sept fois en simulant sept jours (insérez des lignes dans `obs_metriques` avec des dates passées, autour du volume réel de la table `commandes` simplifiée, ≈ 120 240 lignes ± 150) ; (2) supprimez 90 % des commandes et relancez : l'alerte de volume doit apparaître ; (3) ajoutez une colonne `canal_vente` à `commandes` et relancez : l'alerte de schéma doit apparaître ; (4) rédigez le post-mortem de l'incident (2) avec le gabarit.

**Critères de réussite** : les deux alertes s'affichent avec le bon pilier ; le post-mortem chiffre le *data downtime*, nomme une cause racine plausible et au moins deux actions avec propriétaire et échéance.

**Pistes de corrigé** : pour simuler l'historique, `INSERT INTO obs_metriques SELECT now() - INTERVAL (i) DAY, 'commandes', 120240 + (random()*300 - 150)::INT, now(), '<hash du jour>', 0 FROM range(1, 8) t(i)` (remplacez le hash par celui calculé par le script, sinon l'alerte de schéma se déclenche aussi) ; pour la suppression massive, `DELETE FROM commandes WHERE random() < 0.9` sur une **copie** de la base. Cause racine plausible : ingestion incrémentale relancée avec un mauvais filtre de date ; actions : test de volume bloquant, contrôle de la fenêtre d'extraction.

## ✅ Auto-évaluation express
1. Citez les cinq piliers.
2. Quelle composante du *data downtime* l'observabilité réduit-elle surtout ?
3. Que doit toujours produire un post-mortem ?

**Réponses** : 1. Fraîcheur, volume, schéma, qualité (distribution), lignage. 2. Le temps de détection. 3. Au moins une action préventive concrète (nouveau test, contrat, moniteur), avec propriétaire et échéance.

## 📚 Pour aller plus loin
- [DataDriven — Data Observability: 5 Pillars and Tools](https://datadriven.io/data-observability) 🇬🇧 — synthèse 2026 des piliers et du marché.
- [Elementary — documentation](https://docs.elementary-data.com/) 🇬🇧 — installation, tests d'anomalies, alertes.
- [Monte Carlo](https://www.montecarlodata.com/) 🇬🇧 — exemple de plateforme commerciale.
- [dbt — Source freshness](https://docs.getdbt.com/docs/deploy/source-freshness) 🇬🇧 — fraîcheur des sources nativement dans dbt.

> ✅ **Si vous ne retenez que 3 choses** — 1. L'observabilité surveille en continu cinq piliers (fraîcheur, volume, schéma, qualité des valeurs, lignage) et réduit surtout le **temps de détection** des incidents, donc le *data downtime*. 2. Un moniteur simple compare chaque mesure à son historique (z-score : « à combien d'écarts-types de la normale ? ») au lieu d'un seuil fixe, en tenant compte de la saisonnalité ; Elementary apporte la même chose dans dbt, les plateformes commerciales l'automatisent à grande échelle. 3. Un incident suit un runbook (alerte, tri par sévérité, communication, diagnostic par le lignage, correction, rattrapage) et se termine par un post-mortem sans coupable qui produit au moins une règle nouvelle.

> 🗺️ **Et maintenant ?** — Vos données sont fiables et surveillées ; reste à les **protéger** : la leçon L174 traite du RGPD, du contrôle d'accès, du chiffrement et de l'article 10 de l'AI Act, directement dans le pipeline.
