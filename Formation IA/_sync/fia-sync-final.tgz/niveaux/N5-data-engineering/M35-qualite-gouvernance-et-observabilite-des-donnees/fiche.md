---
module: M35
title: "Fiche mémo — Qualité, gouvernance et observabilité des données"
---
# Fiche mémo — M35 · Qualité, gouvernance et observabilité des données

> En une phrase : une donnée digne de confiance est testée (dbt, GX, Soda), promise par contrat (ODCS), retrouvable avec son arbre généalogique (catalogue + OpenLineage), surveillée en continu (5 piliers) et protégée jusqu'à l'index vectoriel (RGPD, AI Act).

## Les 7 idées à retenir
1. Six dimensions : complétude, unicité, validité, exactitude, cohérence, fraîcheur. Seule l'exactitude demande une référence externe (`L170`).
2. Trois outils, trois moments : GX Core en Python sur le fichier reçu, les tests dbt sur staging et marts, Soda planifié (SodaCL exécuté dans la base). Chaque test a un propriétaire et une sévérité `warn` ou `error` (`L170`).
3. Le contrat ODCS v3.1.0 est le bon de commande entre producteur et consommateurs : schéma, qualité, SLA, équipe, support, serveurs. `lint` vérifie le fichier, `test` vérifie la vraie table (`L171`).
4. Pour renommer une colonne : expand → migrer → vérifier le lignage → contract. Version mineure pour un ajout compatible, majeure pour un changement cassant, avec préavis (`L171`).
5. Des rôles avant des outils : owner, steward, dépositaire, consommateur, DPO. Le catalogue technique (Unity, Polaris) sert les moteurs, la plateforme de métadonnées (OpenMetadata, DataHub) sert les humains (`L172`).
6. Cinq piliers : fraîcheur, volume, schéma, qualité (ex-distribution), lignage. Data downtime ≈ incidents × (détection + résolution). Chaque post-mortem produit au moins une règle nouvelle (`L173`).
7. Pseudonymiser en ETL entre bronze et silver. Une donnée pseudonymisée reste personnelle. L'effacement se propage partout : tables, snapshots (`VACUUM`, `expire_snapshots`), vecteurs (`L174`).

## Le schéma à connaître
```mermaid
flowchart LR
    S["sources"] -->|"GX : fichier conforme ?"| B["BRONZE<br/>accès restreint, 30 j"]
    B -->|"Presidio (ETL) + tests dbt staging"| SI["SILVER pseudonymisé"]
    SI -->|"dbt tests + unit tests marts"| G["GOLD"]
    G -->|"Soda / Elementary : fraîcheur, volume"| C["BI, ML, RAG"]
    SI --> V["chunks + embeddings<br/>sans NIR ni IBAN"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Test dbt | Une requête qui renvoie les lignes fautives : 0 ligne = le test passe |
| Expectation (GX) | « J'attends que `montant_ttc` soit entre 0 et 50 000 » |
| SodaCL | Contrôles en YAML exécutés dans la base (pushdown) |
| SLA (ODCS) | `latency`, `frequency`, `retention` |
| Job / run / dataset / facette | Le traitement / une exécution (UUID) / une donnée lue ou écrite / des métadonnées attachées |
| z-score | « À combien de pas habituels » on se trouve de la normale. Alerte au-delà de 3 |
| RLS | Sécurité au niveau des lignes : chaque agence ne voit que ses clients |
| Crypto-shredding | Détruire la clé d'une personne rend illisibles toutes ses copies chiffrées |

## Les pièges classiques
- Garder la vieille syntaxe dbt : `tests:` est devenu `data_tests:` (1.8), et les paramètres vont sous `arguments:` (1.10).
- Copier un contrat de blog en v2 (`dataset:`, `columns:`) : la v3.x utilise `schema:` → `properties:`.
- Installer un catalogue sans propriétaires nommés : 400 tables « documentées » que personne ne comprend.
- Donner des noms de datasets OpenLineage incohérents : le graphe se retrouve en morceaux.
- Ignorer la saisonnalité : une fausse alerte de volume chaque lundi, et l'équipe finit par couper les alertes.
- Confondre pseudonymisation et anonymisation.
- Faire tourner l'application avec le rôle propriétaire ou `BYPASSRLS` : la RLS est contournée.
- Oublier le time travel lors d'un effacement : la donnée reste lisible tant que les snapshots ne sont pas purgés.
- Mettre des secrets dans Git.

## Les commandes / chiffres / dates utiles
```bash
dbt source freshness && dbt build                       # warn_after 24 h, error_after 48 h
soda scan -d breval -c soda/configuration.yml soda/checks_commandes.yml
datacontract lint contrats/commandes.odcs.yaml ; datacontract test contrats/commandes.odcs.yaml
datacontract export --format dbt contrats/commandes.odcs.yaml
datahub docker quickstart                               # UI sur localhost:9002 ; datahub ingest -c ingestion_dbt.yml
bin/start-uc-server ; bin/uc catalog list               # Unity Catalog OSS, port 8080
dbt deps && dbt run --select elementary && edr report ; edr monitor --slack-webhook "$SLACK_WEBHOOK_URL"
```
```yaml
- duplicate_count(id) = 0                     # SodaCL
- invalid_count(statut) = 0:
    valid values: [brouillon, validee, livree, facturee, annulee]
- freshness(maj_le) < 1d
# dbt + Elementary, sur le modèle silver :
data_tests: [elementary.volume_anomalies, elementary.freshness_anomalies, elementary.schema_changes]
```
```sql
ALTER TABLE silver.clients ENABLE ROW LEVEL SECURITY;
CREATE POLICY clients_nan ON silver.clients FOR SELECT TO lecteur_nan USING (agence_id = 'NAN');
GRANT SELECT ON silver.clients_analyse TO analyste;     -- vue de masquage, aucun droit sur la table
```
- **Fichiers Bréval** : `creer_tables_qualite.py` crée les tables simplifiées `clients`, `commandes`, `tickets_sav` (schéma `main` de `data/breval.duckdb`, `montant_ttc` = HT × 1,20). Défauts : 240 doublons, 11 dates « 206x », démos id ≥ 900000. Également `contrats/commandes.odcs.yaml`, `moniteurs.py` (table `obs_metriques`), `acces.sql`, `effacement.py`, `lignage_indexeur.py` (Marquez sur le port 5000, UI sur le port 3000).
- **Contrat commandes** : SLA `latency` 4 h, `frequency` 1 j, `retention` 10 ans.
- **Incidents** : SEV1 immédiat, SEV2 dans la journée, SEV3 planifié. **Marché** : Datadog a racheté Metaplane (2025), Sifflet est un éditeur français.
- **Versions et dates 2026** : ODCS v3.1.0 (Bitol, LF AI & Data, Apache 2.0). dbt 1.11. Apache Polaris projet de premier niveau depuis février 2026. Les recommandations IA de la CNIL ont été finalisées en juillet 2025. AI Act art. 10 : les obligations haut risque de l'annexe III sont reportées au 2 décembre 2027 (omnibus (UE) 2026/1744).

## Pour aller plus loin
- [Bitol — Open Data Contract Standard](https://github.com/bitol-io/open-data-contract-standard)
- [OpenLineage — Object model](https://openlineage.io/docs/spec/object-model)
- [EUR-Lex — Règlement (UE) 2024/1689 (AI Act)](https://eur-lex.europa.eu/eli/reg/2024/1689/oj)

## Auto-test (3 questions — réponses en bas de fiche)
1. Des statuts « Livrée » apparaissent dans `commandes`. Quelle dimension est en défaut, et quel test dbt la contrôle ?
2. Les montants arrivent en centimes, sans changement de colonnes ni de volume. Quel pilier le détecte ?
3. Que vérifie `datacontract test` que `datacontract lint` ne vérifie pas ?

---
**Réponses.** 1) La validité, avec `accepted_values`. 2) Le pilier qualité (la distribution des valeurs), par exemple avec `elementary.column_anomalies` sur `average`. 3) `test` se connecte au serveur et vérifie que la vraie table respecte le schéma et les règles. `lint` ne contrôle que le fichier.
