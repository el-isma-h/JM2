---
module: M36
title: "Fiche mémo — Préparer les données pour l'IA : LLM, ML et RAG"
---
# Fiche mémo — M36 · Préparer les données pour l'IA : LLM, ML et RAG

> En une phrase : on trie les légumes avant de cuisiner. On extrait, normalise et filtre, puis on déduplique, on retire les données personnelles, on découpe et vectorise par lots avec des identifiants stables, et on versionne tout, sans jamais laisser le futur fuiter dans l'entraînement.

## Les 7 idées à retenir
1. Une même chaîne sert trois usages : extraire (Docling pour les PDF, Trafilatura pour le web), normaliser (ftfy + NFC), détecter la langue (GlotLID), filtrer (Gopher, C4, FineWeb) avec des seuils par catégorie et un journal des rejets (`L175`).
2. Doublons exacts : un SHA-256 du texte normalisé. Quasi-doublons : MinHash (P[min égaux] = Jaccard) + LSH en bandes, seuil t ≈ (1/b)^(1/r). Reformulations : cosinus des embeddings > 0,95 (`L176`).
3. Pour un RAG, la déduplication sémantique suit une règle de survie métier : on garde la version en vigueur. On décontamine les évaluations par 13-grammes (`L176`).
4. Presidio = un analyzer qui détecte et un anonymizer qui applique un opérateur par type. En français, on configure spaCy `fr_core_news_lg` et des reconnaisseurs FR, et on vise un rappel ≥ 90 % par type (`L177`).
5. Le `chunk_id` est un hash déterministe (`doc_id | chunking_v | position | texte`) : l'upsert est idempotent. On ne calcule que ce qui manque, par anti-jointure sur `(chunk_id, modele_v)` (`L178`).
6. On ne mélange jamais deux modèles d'embedding dans un index : nouvelle collection, évaluation, puis bascule atomique de l'alias. Les filtres `tenant_id` s'appliquent pendant la recherche, pas après (`L178`).
7. Jointure point-in-time (`ASOF JOIN`, Feast) contre la fuite temporelle. DVC ou lakeFS pour versionner. Les données synthétiques ne sont pas anonymes d'office : on mesure la DCR (`L179`).

## Le schéma à connaître
```mermaid
flowchart LR
    R["PDF, HTML, md/, tickets"] -->|"Docling, Trafilatura"| X["bronze_*.jsonl"]
    X -->|"ftfy+NFC, GlotLID, filtres"| F["silver_filtre.jsonl<br/>+ rejets.jsonl"]
    F -->|"SHA-256, MinHash/LSH"| M["apres_minhash.jsonl"]
    M -->|"Presidio FR"| P["silver_tickets.jsonl"]
    P -->|"chunker"| C["chunks.parquet"]
    C -->|"Ray Data / Spark"| E["embeddings/"]
    E -->|"upsert + alias"| Q["Qdrant / pgvector"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Shingle | Un morceau de 5 mots consécutifs : les étiquettes du sac |
| MinHash | 128 tombolas : le pourcentage de gagnants communs estime la ressemblance |
| LSH | Le centre de tri postal : seuls les documents d'un même casier sont comparés |
| Décontamination | Retirer de l'entraînement ce qui figure dans les évaluations |
| `encrypt` (Presidio) | Le seul opérateur réversible (avec la clé, via `DeanonymizeEngine`) |
| Training-serving skew | Une feature calculée différemment à l'entraînement et en production |
| Online / offline store | La dernière valeur pour l'inférence / l'historique pour l'entraînement |
| DCR | Distance au plus proche enregistrement réel : près de 0 = recopie |

## Les pièges classiques
- Collecter sans vérifier les licences.
- Régler les seuils à l'aveugle au lieu de relire 50 rejets et 50 documents gardés par catégorie.
- Croire que SHA-256 voit les quasi-doublons : un seul caractère change toute l'empreinte.
- Croire que Presidio parle français après un simple `pip install`.
- Hacher des téléphones en SHA-256 simple (attaque par dictionnaire) : il faut un HMAC à clé.
- Mélanger deux modèles d'embedding dans un index : la recherche renvoie du bruit, sans erreur.
- Post-filtrer par service : un petit locataire obtient 0 résultat.
- Utiliser une feature « d'aujourd'hui » pour une étiquette de mars : c'est une fuite de données.
- Considérer des données SDV comme anonymes sans mesurer la DCR.

## Les commandes / chiffres / dates utiles
```sql
-- DuckDB : doublons exacts, puis chunks à vectoriser, puis features à date
SELECT * FROM read_ndjson_auto('corpus/silver_filtre.jsonl')
QUALIFY row_number() OVER (PARTITION BY sha256(lower(regexp_replace(texte, '\s+', ' ', 'g'))) ORDER BY source DESC) = 1;
SELECT c.* FROM 'corpus/chunks.parquet' c
ANTI JOIN (SELECT chunk_id FROM 'corpus/embeddings/*.parquet' WHERE modele_v = 'bge-m3@2026-11') e USING (chunk_id);
SELECT * FROM etiquettes e ASOF JOIN stats_clients s ON e.client_id = s.client_id AND e.date_etiquette >= s.event_timestamp;
-- pgvector
CREATE INDEX ON chunks USING hnsw (embedding halfvec_cosine_ops) WITH (m = 16, ef_construction = 64);
SET hnsw.iterative_scan = relaxed_order;
```
```bash
python -m spacy download fr_core_news_lg
feast init breval_features ; feast apply
dvc init ; dvc repro ; dvc push ; git tag corpus-2026-11-05     # restauration : git checkout <tag> && dvc pull
lakectl branch create lakefs://quickstart/exp-dedup-055 --source lakefs://quickstart/main
```
```python
ds.map_batches(Embedder, batch_size=128, concurrency=2, num_gpus=GPU)        # Ray Data
store.get_historical_features(entity_df=etiquettes, features=FEATURES)        # Feast point-in-time
OperatorConfig("encrypt", {"key": CLE_AES})                                   # IBAN réversible
```
- **Formules** : P(candidats) = 1 − (1 − s^r)^b. Avec b = 14 et r = 8 (112 hachages, comme FineWeb), le seuil est d'environ 0,72 ; avec b = 20 et r = 5, il est d'environ 0,55. Clé NIR = 97 − (n mod 97), avec 2A → 19 et 2B → 18.
- **Mémoire** = N × d × octets (float32 = 4, int8 = 1, binaire = 1/8). Bréval : environ 10 000 chunks, soit 41 Mo. 100 000 chunks : 0,4 Go (pgvector suffit). 10 M de chunks : 41 Go.
- **Coût** : avec Mistral Embed à 0,10 $/MTok, 100 000 chunks coûtent environ 3 $ et 10 M de chunks environ 300 $.
- **Seuils** : GlotLID ≥ 0,65 (`fra_Latn`), shards de 50 à 500 Mo, Presidio `score_threshold=0.4`, rappel PII ≥ 90 %.
- **Fichiers Bréval** : `data/raw/documents/` (126 docs : md/, `documents.csv`, pdf/), `corpus/` (bronze_*, silver_filtre, apres_minhash, silver_tickets, chunks.parquet, embeddings/, silver/MANIFEST.json), `evals/`, collection `chunks_bge_m3_v1` derrière l'alias `chunks`.
- **Versions 2026** : Ray 2.60 (`ray.data.llm` : vLLM, SGLang, `build_processor`). La référence vectorielle de Feast est en alpha. `bge-m3@2026-11`. LLM local `qwen3.8:27b` via Ollama.

## Pour aller plus loin
- [UPPMAX LLM workshop — Data pipelines](https://uppmax.github.io/LLM-workshop/day2/data_pipelines)
- [Mining of Massive Datasets](http://www.mmds.org)
- [Microsoft Presidio](https://microsoft.github.io/presidio)

## Auto-test (3 questions — réponses en bas de fiche)
1. Avec 14 bandes de 8 hachages, deux documents ont un Jaccard de 0,5. Seront-ils candidats ?
2. La comptabilité doit pouvoir retrouver l'IBAN, mais jamais en clair dans le RAG. Quel opérateur Presidio choisir ?
3. Vous changez de modèle d'embedding. Comment passer en production ?

---
**Réponses.** 1) Rarement : P = 1 − (1 − 0,5^8)^14 ≈ 0,05, sous le seuil d'environ 0,72. 2) `encrypt` (AES), avec une clé conservée hors du pipeline et un déchiffrement tracé. 3) Construire une nouvelle collection, l'évaluer, puis basculer l'alias de façon atomique, en gardant l'ancienne pour un retour arrière.
