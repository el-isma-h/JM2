---
id: L176
module: M36
level: N5
title: "Dédupliquer à l'échelle : hachage exact, MinHash/LSH (MMDS ch. 3), déduplication sémantique, décontamination"
minutes: 50
objectives:
  - "Expliquer pourquoi les doublons nuisent au RAG, au fine-tuning et au pré-entraînement, et mesurer un taux de doublons"
  - "Appliquer une déduplication exacte par empreinte de texte normalisé"
  - "Expliquer MinHash et LSH par une analogie puis par leurs propriétés mathématiques (Jaccard, bandes, courbe en S), et les implémenter"
  - "Mettre en œuvre une déduplication sémantique par embeddings et une décontamination par n-grammes vis-à-vis des jeux d'évaluation"
skills: ["C5.5", "C5.3"]
sources:
  - { title: "Leskovec, Rajaraman, Ullman — Mining of Massive Datasets (ch. 3, Finding Similar Items)", url: "http://www.mmds.org", lang: "en" }
  - { title: "Stanford CS246 — Info Handout 2025", url: "https://snap.stanford.edu/class/cs246-2025/WWW/handouts/CS246_Info_Handout.pdf", lang: "en" }
  - { title: "UPPMAX LLM workshop — Data pipelines", url: "https://uppmax.github.io/LLM-workshop/day2/data_pipelines", lang: "en" }
  - { title: "huggingface/datatrove", url: "https://github.com/huggingface/datatrove", lang: "en" }
  - { title: "NVIDIA NeMo Curator — Welcome", url: "https://docs.nvidia.com/nemo/curator/latest/home/welcome.md", lang: "en" }
  - { title: "RefinedWeb (arXiv 2306.01116)", url: "https://arxiv.org/abs/2306.01116", lang: "en" }
---

# Dédupliquer à l'échelle : hachage exact, MinHash/LSH (MMDS ch. 3), déduplication sémantique, décontamination

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 36

## 🎯 Ce que vous saurez faire
- Mesurer le taux de doublons du corpus de Bréval Matériaux (la PME fil rouge du niveau) (procédures recopiées, CGV en plusieurs versions, tickets envoyés deux fois).
- Supprimer les doublons exacts en une ligne de SQL, puis les **quasi-doublons** avec MinHash/LSH, sans comparer chaque paire.
- Repérer les reformulations (déduplication sémantique) et retirer de vos données d'entraînement les questions de vos jeux d'évaluation (décontamination).

> 🧭 **En clair** — Dans une bibliothèque, dix exemplaires du même livre prennent de la place et faussent les statistiques (« le livre le plus lu ? »). Les doublons dans un corpus font pareil : un RAG renvoie cinq fois le même paragraphe au lieu de cinq informations différentes, un modèle fine-tuné « récite » ce qu'il a vu trop souvent, et une évaluation est faussée si les questions du test figurent déjà dans l'entraînement. Repérer les copies **exactes** est facile (même empreinte). Repérer les copies **presque** identiques (une date changée, un logo en plus) parmi des millions de documents demande une astuce : MinHash et LSH, que nous allons expliquer avec une tombola avant les maths.

## 1. Pourquoi dédupliquer, et comment mesurer

| Usage | Effet des doublons |
|---|---|
| **RAG** | les k résultats sont redondants ; une ancienne version des CGV peut être citée à la place de la nouvelle |
| **Fine-tuning** | sur-apprentissage des exemples répétés (le modèle apprend ces exemples par cœur au lieu de généraliser) ; fuite entre entraînement et évaluation (L137) |
| **Pré-entraînement** | mémorisation, gaspillage de calcul ; FineWeb et RefinedWeb montrent qu'une déduplication soignée améliore les modèles à budget égal |

Le référentiel du niveau (C5.5) exige que le **taux de doublons après traitement soit mesuré**. Définissez-le avant de coder :

```
taux de doublons = 1 − (nombre de documents uniques / nombre de documents)
```

Calculé **trois fois** : avant traitement, après déduplication exacte, après déduplication approchée. Ces trois chiffres vont dans le manifeste du corpus (L175).

## 2. Doublons exacts : l'empreinte du texte normalisé

On calcule une empreinte (SHA-256) du texte **normalisé** (L175 : Unicode NFC, espaces, casse) ; deux documents de même empreinte sont identiques.

```sql
-- dedup_exact.sql — DuckDB : garder le document le plus récent pour chaque empreinte
CREATE OR REPLACE TABLE corpus_unique AS
SELECT * EXCLUDE (empreinte)
FROM (
  SELECT *, sha256(lower(regexp_replace(texte, '\s+', ' ', 'g'))) AS empreinte
  FROM read_ndjson_auto('corpus/silver_filtre.jsonl')
)
QUALIFY row_number() OVER (PARTITION BY empreinte ORDER BY source DESC) = 1;

SELECT (SELECT count(*) FROM read_ndjson_auto('corpus/silver_filtre.jsonl')) AS avant,
       count(*) AS apres FROM corpus_unique;
```

> 🧭 **Pré-requis express** — Exécutez ce SQL depuis `breval/` avec le client `duckdb` (`duckdb data/breval.duckdb < dedup_exact.sql`) ou en Python (`duckdb.connect('data/breval.duckdb').sql(open('dedup_exact.sql').read()).show()`). Il lit `corpus/silver_filtre.jsonl`, produit par les filtres de L175.

> 🔍 **Ce que vous devez voir** — un tableau `avant | apres` ; l'écart correspond aux copies exactes. S'il est anormalement grand (près de la moitié des lignes), c'est presque toujours que `silver_filtre.jsonl` a été rempli deux fois en L175 (mode ajout) : supprimez-le, relancez les filtres, puis ce script.

Cela coûte une passe sur les données et passe à l'échelle sans difficulté (Spark ou DuckDB : un simple `GROUP BY`). Mais il suffit d'une date de mise à jour différente en pied de page pour que deux procédures identiques aient des empreintes différentes. D'où la suite.

```quiz
{
  "q": "Deux versions d'une procédure ne diffèrent que par la date « mise à jour le 03/11/2026 » en bas de page. Que détecte la déduplication exacte par SHA-256 ?",
  "options": ["Un doublon, car 99 % du texte des deux versions est identique", "Rien : un seul caractère différent change complètement l'empreinte", "Un doublon si l'on utilise SHA-512 au lieu de SHA-256", "Une erreur de normalisation Unicode"],
  "answer": 1,
  "explanation": "Une fonction de hachage cryptographique change totalement dès qu'un octet change. Elle ne mesure pas la ressemblance : il faut une technique de quasi-doublons comme MinHash."
}
```

## 3. MinHash : la tombola qui estime la ressemblance

### 3.1 D'abord, l'analogie

Imaginez que chaque document soit un **sac de petites étiquettes** : chaque étiquette porte un morceau de 5 mots consécutifs du texte (« le délai de rétractation est », « délai de rétractation est de »…). Deux documents se ressemblent s'ils ont beaucoup d'étiquettes en commun.

Maintenant, organisons une **tombola** : on mélange au hasard **toutes** les étiquettes possibles du monde et on les numérote dans cet ordre. Chaque document annonce **la plus petite** de ses étiquettes (celle qui sort en premier dans le tirage). Question : quelle est la probabilité que deux documents annoncent **la même** ? Réponse : exactement la part d'étiquettes qu'ils partagent. Si les deux sacs ont 80 % d'étiquettes en commun, ils annonceront la même gagnante 8 fois sur 10.

On refait la tombola **128 fois** avec 128 mélanges différents. Chaque document obtient une **signature** de 128 numéros. Pour savoir si deux documents se ressemblent, il suffit de compter dans combien de tombolas ils ont annoncé la même étiquette : 100 sur 128 ≈ 78 % de ressemblance. Et 128 numéros, c'est minuscule comparé au texte entier.

> 💡 **Autrement dit** — MinHash remplace « comparer deux textes entiers » par « comparer deux listes de 128 nombres », et le pourcentage de nombres identiques est une bonne estimation de la ressemblance.

### 3.2 Ensuite, les maths (MMDS, chapitre 3)

Le chapitre 3 de *Mining of Massive Datasets* (Leskovec, Rajaraman, Ullman ; base du cours Stanford CS246) formalise cette idée — nous en reprenons les notions, pas le texte :

- **Shingles** : un document D est représenté par l'ensemble S(D) de ses *k*-grammes (*shingle*, « bardeau » : les morceaux se chevauchent comme les tuiles d'un toit ; un *k*-gramme est une suite de *k* mots consécutifs) (ici, 5 mots consécutifs, comme FineWeb).
- **Similarité de Jaccard** : J(A, B) = |A ∩ B| / |A ∪ B|, entre 0 (rien en commun) et 1 (identiques).
- **Propriété fondamentale** : pour une permutation aléatoire π des shingles, P[min π(A) = min π(B)] = J(A, B).
- En pratique, on remplace les permutations par des **fonctions de hachage** h_i(x) = (a_i·x + b_i) mod p ; la signature est le vecteur des minimums. La fraction de positions égales entre deux signatures est un estimateur sans biais de J (« sans biais » : en moyenne, l'estimation tombe juste ; l'écart-type indique de combien elle peut se tromper), d'écart-type ≈ √(J(1−J)/n) pour n fonctions (≈ 0,04 pour n = 128 et J = 0,5).

## 4. LSH : ne comparer que les candidats

Avec 1 million de documents, comparer toutes les signatures deux à deux fait environ 5 × 10¹¹ paires : trop. Le ***Locality-Sensitive Hashing*** (LSH) évite cela.

**Analogie** : un centre de tri postal. On découpe chaque signature de 128 nombres en **b bandes** de **r** nombres (par exemple 16 bandes de 8). Pour chaque bande, on range le document dans un **casier** étiqueté par le contenu de la bande. Deux documents qui tombent dans le **même casier pour au moins une bande** deviennent **candidats** ; on ne compare vraiment que ceux-là.

```
signature (128) = [ bande 1 : 8 nombres | bande 2 : 8 nombres | … | bande 16 : 8 nombres ]
                        │                       │
                   casier h(bande 1)       casier h(bande 2)   ← documents dans le même casier = candidats
```

**Les maths** : si deux documents ont une similarité s, la probabilité qu'une bande soit identique vaut s^r ; la probabilité d'être candidats vaut

```
P(candidats) = 1 − (1 − s^r)^b
```

C'est une **courbe en S** : presque nulle sous un seuil, presque 1 au-dessus. Le seuil approximatif est t ≈ (1/b)^(1/r). Avec la configuration décrite pour FineWeb (14 buckets ; 8 hachages par bucket, soit 112 fonctions, d'après le code datatrove — à vérifier pour votre version), t ≈ (1/14)^(1/8) ≈ **0,72**.

| Similarité s | 0,5 | 0,6 | 0,7 | 0,8 | 0,9 |
|---|---|---|---|---|---|
| P(candidats), b = 14, r = 8 | 0,05 | 0,21 | 0,56 | 0,92 | ≈ 1,00 |

> 💡 **À retenir** — Plus de bandes (b ↑) : on attrape plus de quasi-doublons, mais plus de faux candidats à vérifier. Plus de lignes par bande (r ↑) : seuil plus strict. On choisit b et r pour placer le seuil là où le métier le veut, puis on **vérifie** chaque paire candidate avec l'estimation de Jaccard.

```quiz
{
  "q": "Avec 14 bandes de 8 hachages, deux documents ont une similarité de Jaccard de 0,5. Que se passe-t-il le plus souvent ?",
  "options": ["Ils sont presque toujours candidats, puis fusionnés en un seul", "Ils ne sont candidats qu'environ 5 fois sur 100 et restent séparés", "LSH renvoie une erreur car 0,5 est sous le seuil", "Ils sont candidats exactement une fois sur deux"],
  "answer": 1,
  "explanation": "P = 1 − (1 − 0,5^8)^14 ≈ 0,05. Le seuil de cette configuration est d'environ 0,72 : un document à moitié semblable est rarement proposé comme candidat."
}
```

### 4.1 Implémentation complète (numpy, sans dépendance exotique)

```python
# minhash_lsh.py — déduplication approchée d'un corpus JSONL (pip install numpy)
import hashlib
import json
import re
from collections import defaultdict
import numpy as np

K, N_PERM, BANDES = 5, 112, 14          # 5-grammes de mots, 14 bandes x 8 lignes
LIGNES = N_PERM // BANDES
P = (1 << 61) - 1                       # grand nombre premier (Mersenne)
rng = np.random.default_rng(42)         # graine fixe : signatures reproductibles
A = rng.integers(1, P, N_PERM, dtype=np.uint64)
B = rng.integers(0, P, N_PERM, dtype=np.uint64)

def shingles(texte: str) -> set[int]:
    mots = re.findall(r"\w+", texte.lower())
    grams = {" ".join(mots[i:i + K]) for i in range(max(1, len(mots) - K + 1))}
    return {int.from_bytes(hashlib.blake2b(g.encode(), digest_size=8).digest(), "little") % P for g in grams}

def signature(sh: set[int]) -> np.ndarray:
    x = np.fromiter(sh, dtype=np.uint64)
    # (a*x + b) mod p, calculé en objets Python pour éviter les débordements 64 bits
    h = (A.astype(object)[:, None] * x.astype(object)[None, :] + B.astype(object)[:, None]) % P
    return np.array(h.min(axis=1), dtype=np.uint64)

docs = [json.loads(l) for l in open("corpus/silver_filtre.jsonl", encoding="utf-8")]
sigs = [signature(shingles(d["texte"])) for d in docs]

# LSH : un dictionnaire de casiers par bande
casiers = defaultdict(list)
for i, s in enumerate(sigs):
    for b in range(BANDES):
        casiers[(b, s[b * LIGNES:(b + 1) * LIGNES].tobytes())].append(i)

# Vérification des paires candidates + regroupement (union-find)
parent = list(range(len(docs)))
def racine(i):
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i

SEUIL = 0.8
for membres in casiers.values():
    for i in membres[1:]:
        j = membres[0]
        if np.mean(sigs[i] == sigs[j]) >= SEUIL:      # Jaccard estimé
            parent[racine(i)] = racine(j)

groupes = defaultdict(list)
for i in range(len(docs)):
    groupes[racine(i)].append(i)
gardes = [docs[max(g, key=lambda k: len(docs[k]["texte"]))] for g in groupes.values()]  # garde le plus long
print(f"{len(docs)} documents → {len(gardes)} après MinHash "
      f"(taux de quasi-doublons : {1 - len(gardes) / len(docs):.1%})")
with open("corpus/apres_minhash.jsonl", "w", encoding="utf-8") as f:   # entrée de L177 (et de dedup_semantique.py)
    f.writelines(json.dumps(d, ensure_ascii=False) + "\n" for d in gardes)

# Courbe en S pour choisir b et r
for s in (0.5, 0.6, 0.7, 0.8, 0.9):
    print(s, round(1 - (1 - s ** LIGNES) ** BANDES, 3))
```

> 🧭 **Pré-requis express** — Le script lit `corpus/silver_filtre.jsonl` (L175) et écrit `corpus/apres_minhash.jsonl`. Le regroupement des documents semblables utilise un **union-find** (fonction `racine`) : chaque document pointe vers un « chef de groupe », et fusionner deux groupes revient à changer un pointeur. `P` est un grand nombre premier dit « de Mersenne » (2⁶¹ − 1), pratique pour les calculs de hachage.

> 🔍 **Ce que vous devez voir** — après quelques dizaines de secondes à quelques minutes (calcul en Python pur), une ligne du type `9169 documents → 9102 après MinHash (taux de quasi-doublons : 0.7%)` (vos nombres dépendent de vos PDF et de vos filtres), puis la courbe en S : `0.5 0.053`, `0.6 0.211`, `0.7 0.565`, `0.8 0.924`, `0.9 1.0` (identique au tableau de la section 4).

> 🛠️ **Si ça ne marche pas** — « MemoryError » ou lenteur extrême → testez d'abord sur les 2 000 premières lignes (`docs = docs[:2000]` juste après la lecture du fichier). « OverflowError » → vous avez retiré les `astype(object)` : ils évitent les débordements des entiers 64 bits.

Ce code est volontairement lisible ; il traite confortablement quelques dizaines de milliers de documents. Au-delà, utilisez une implémentation optimisée : le bloc de déduplication MinHash de **datatrove** (en 4 étapes : signatures, buckets, clustering, filtrage — exactement les étapes ci-dessus, distribuées), celui de **NeMo Curator** sur GPU, ou une bibliothèque Python dédiée comme `datasketch` (`MinHash`, `MinHashLSH`). Avec Spark, `pyspark.ml.feature.MinHashLSH` existe aussi (vérifiez son comportement : il travaille sur des vecteurs creux et une *distance* de Jaccard). (Un **vecteur creux** ne stocke que ses valeurs non nulles ; la *distance* de Jaccard vaut 1 − la similarité.)

```mission
{
  "title": "MinHash et LSH dans le livre Mining of Massive Datasets",
  "url": "http://www.mmds.org",
  "steps": ["Ouvrez le site du livre Mining of Massive Datasets", "Téléchargez ou ouvrez le chapitre 3 « Finding Similar Items »", "Repérez la section sur le LSH pour les signatures MinHash (bandes et lignes)"],
  "question": "Quelle formule approximative le chapitre donne-t-il pour le seuil de similarité à partir duquel la probabilité d'être candidat devient forte, en fonction de b et r ?",
  "hint": "Elle fait intervenir une racine r-ième de 1/b.",
  "answer": "t ≈ (1/b)^(1/r) : le point où la courbe en S est la plus raide (chapitre 3, section sur le « banding technique » ; le PDF est diffusé gratuitement par les auteurs avec l'accord de l'éditeur).",
  "xp": 20
}
```

## 5. Déduplication sémantique : les reformulations

MinHash attrape les copies **textuelles**. Il ne voit pas que « Comment retourner un article défectueux ? » et « Procédure de renvoi d'un produit en panne » disent la même chose. La **déduplication sémantique** compare des **embeddings** (vus en L089) : deux textes dont la similarité cosinus dépasse un seuil élevé (0,95 par exemple) sont considérés comme redondants.

```python
# dedup_semantique.py — pip install sentence-transformers numpy
import json
import numpy as np
from sentence_transformers import SentenceTransformer

modele = SentenceTransformer("BAAI/bge-m3")      # même modèle local qu'en L089 ; CPU suffisant ici
docs = [json.loads(l) for l in open("corpus/apres_minhash.jsonl", encoding="utf-8")]
emb = modele.encode([d["texte"][:2000] for d in docs], normalize_embeddings=True, batch_size=32)

sim = emb @ emb.T                                 # cosinus (vecteurs normalisés)
np.fill_diagonal(sim, 0)
a_retirer = set()
for i in range(len(docs)):
    if i in a_retirer:
        continue
    for j in np.where(sim[i] > 0.95)[0]:
        if j > i:
            a_retirer.add(int(j))
print(f"{len(a_retirer)} documents sémantiquement redondants sur {len(docs)}")
```

> 🧭 **Pré-requis express** — Le modèle `BAAI/bge-m3` est téléchargé au premier lancement (plus de 2 Go) et l'encodage de plusieurs milliers de documents sur un processeur ordinaire peut prendre **30 minutes ou plus** : pour un premier essai, limitez-vous aux documents internes (`docs = [d for d in docs if d.get("categorie") != "tickets"]`). `emb @ emb.T` calcule d'un coup toutes les **similarités cosinus** (L089) entre paires de documents.

> 🔍 **Ce que vous devez voir** — une barre de progression `Batches: 100%|…|` puis une ligne `12 documents sémantiquement redondants sur 126` (ordre de grandeur pour les seuls documents internes : surtout les versions successives des CGV et les anciennes versions de procédures).

> 🛠️ **Si ça ne marche pas** — « Killed » ou plantage mémoire → trop de documents à la fois : la matrice `sim` contient n × n nombres ; filtrez ou découpez le corpus.

La matrice complète est en O(n²) (le temps de calcul est multiplié par 4 quand le nombre de documents double) : au-delà de quelques dizaines de milliers de documents, on **regroupe d'abord** (k-means sur les embeddings, ou un index vectoriel) (*k-means* : un algorithme qui range les vecteurs en *k* groupes de voisins) et l'on ne compare qu'à l'intérieur de chaque groupe — c'est la stratégie des outils de curation à l'échelle comme NeMo Curator.

> ⚠️ **Piège fréquent** — Appliquer la déduplication sémantique à un corpus RAG d'entreprise **sans regarder les métadonnées**. Chez Bréval, les CGV 2024, 2025 et 2026 sont sémantiquement presque identiques, et le serveur de fichiers contient d'anciennes versions de procédures (`PRC-007` en v2 et son ancienne version `PRC-007-v1`, par exemple, défaut volontaire du jeu de L152) : il faut garder **la version en vigueur** (la plus récente `version`/`date_maj` de `documents.csv`) et archiver les autres, pas en garder une au hasard. Pour un RAG, la règle de survie se décide avec le métier : la plus récente, la version « validée », celle du bon service.

## 6. Décontamination : protéger vos évaluations

Une **contamination** se produit quand des éléments de vos **jeux d'évaluation** se retrouvent dans les données d'**entraînement** (ou, pour un RAG, quand le jeu de questions de test a été rédigé en recopiant mot pour mot les documents). Les scores mesurent alors la mémoire, pas la compétence. La méthode la plus répandue : rechercher des **n-grammes longs** (13 mots, par exemple) communs entre le corpus et les jeux d'évaluation.

```python
# decontaminer.py — retire du corpus d'entraînement les documents qui contiennent un 13-gramme des jeux d'évaluation
import json
import re

N = 13
def ngrams(texte: str) -> set[str]:
    m = re.findall(r"\w+", texte.lower())
    return {" ".join(m[i:i + N]) for i in range(len(m) - N + 1)}

evals = set()
for chemin in ("evals/rag_questions.jsonl", "evals/sav_eval.jsonl"):   # jeux de L093 et L137
    for l in open(chemin, encoding="utf-8"):
        e = json.loads(l)
        evals |= ngrams(e.get("question", "") + " " + e.get("reponse_attendue", ""))

gardes, contamines = [], 0
for l in open("corpus/train_candidats.jsonl", encoding="utf-8"):
    d = json.loads(l)
    if ngrams(d["texte"]) & evals:
        contamines += 1
    else:
        gardes.append(d)
print(f"{contamines} documents contaminés retirés")
```

> 🧭 **Pré-requis express** — Ce script suppose deux jeux d'évaluation créés dans d'autres niveaux (L093, L137) et un fichier `corpus/train_candidats.jsonl` que le niveau 5 ne produit pas : lancé tel quel, il échoue sur `FileNotFoundError`. Pour l'essayer, créez un petit `evals/rag_questions.jsonl` à la main (deux ou trois lignes `{"question": "…", "reponse_attendue": "…"}` en recopiant une phrase d'une procédure), remplacez `evals/sav_eval.jsonl` par ce seul fichier dans la boucle, et utilisez `corpus/apres_minhash.jsonl` comme `train_candidats.jsonl`.

> 🔍 **Ce que vous devez voir** — `1 documents contaminés retirés` (ou plus) : la procédure d'où vous avez recopié la phrase est détectée, puisqu'elle partage au moins un 13-gramme avec la question.

Deux politiques : retirer du **corpus** les documents contaminés (fine-tuning, pré-entraînement) ou retirer/réécrire les **questions** contaminées (quand le document doit rester, comme dans un RAG). Dans tous les cas, **gelez et versionnez** vos jeux d'évaluation (L179).

```quiz
{
  "q": "Vous fine-tunez un modèle sur les tickets SAV et l'évaluez sur 200 tickets mis de côté. 30 d'entre eux ont été envoyés deux fois par les clients et figurent aussi dans le jeu d'entraînement. Comment appelle-t-on ce problème ?",
  "options": ["Un biais de sélection dans l'échantillon d'évaluation retenu", "Une contamination (fuite) entre entraînement et évaluation", "Un problème de fraîcheur des tickets d'entraînement", "Un défaut de chunking des tickets trop longs"],
  "answer": 1,
  "explanation": "Les mêmes exemples (ou quasi-copies) se trouvent des deux côtés : le score d'évaluation est gonflé artificiellement. Dédupliquez avant la séparation et décontaminez par n-grammes ou MinHash entre les deux jeux."
}
```

## 🧪 Exercice pratique

**Consigne** : sur votre corpus de L175, ajoutez volontairement 20 quasi-doublons (copiez des documents en changeant une date, en ajoutant un pied de page, en supprimant un paragraphe) et 5 reformulations. Mesurez le taux de doublons (1) brut, (2) après déduplication exacte, (3) après MinHash/LSH, (4) après déduplication sémantique. Tracez la courbe en S pour deux configurations (b = 14, r = 8 et b = 20, r = 5) et justifiez votre choix.

**Critères de réussite** :
- les quatre taux sont consignés dans le manifeste du corpus ;
- au moins 18 des 20 quasi-doublons sont détectés par MinHash ; aucun document légitime n'est fusionné à tort (vérifiez 10 groupes à la main) ;
- la règle de survie (quel document garder) est écrite et justifiée par le métier.

**Pistes de corrigé** : un pied de page ajouté modifie peu de 5-grammes, la similarité reste > 0,9 ; supprimer un paragraphe sur trois fait tomber J vers 0,6-0,7 : avec b = 14, r = 8 (seuil ≈ 0,72), une partie sera manquée, alors que b = 20, r = 5 (seuil ≈ (1/20)^(1/5) ≈ 0,55) les attrape mais génère plus de candidats à vérifier. Règle de survie : document le plus récent, sinon le plus long, sinon celui qui a le moins de rejets qualité.

## ✅ Auto-évaluation express
1. Que vaut, en probabilité, l'égalité des minimums de deux ensembles sous une permutation aléatoire ?
2. Quel est le rôle des bandes dans LSH ?
3. Pourquoi la déduplication sémantique est-elle délicate dans un RAG documentaire ?

**Réponses** : 1. La similarité de Jaccard des deux ensembles. 2. Ne mettre en concurrence que les documents qui partagent au moins une bande identique (candidats), afin d'éviter de comparer toutes les paires, avec un seuil réglable par b et r. 3. Des versions successives d'un même document sont sémantiquement proches mais n'ont pas la même validité : il faut une règle de survie métier (version en vigueur), pas une suppression aveugle.

## 📚 Pour aller plus loin
- [Mining of Massive Datasets](http://www.mmds.org) 🇬🇧 — chapitre 3 « Finding Similar Items » : shingling, MinHash, LSH (PDF gratuit des auteurs, ne pas redistribuer).
- [Stanford CS246 — Info Handout 2025](https://snap.stanford.edu/class/cs246-2025/WWW/handouts/CS246_Info_Handout.pdf) 🇬🇧 — le cours qui s'appuie sur ce livre (source d'inspiration).
- [UPPMAX — Data pipelines](https://uppmax.github.io/LLM-workshop/day2/data_pipelines) 🇬🇧 — MinHash dans la recette FineWeb.
- [huggingface/datatrove](https://github.com/huggingface/datatrove) 🇬🇧 — déduplication MinHash distribuée.
- [NVIDIA NeMo Curator](https://docs.nvidia.com/nemo/curator/latest/home/welcome.md) 🇬🇧 — déduplication exacte, approchée et sémantique sur GPU.
- [RefinedWeb (arXiv 2306.01116)](https://arxiv.org/abs/2306.01116) 🇬🇧 — l'impact de la déduplication sur la qualité des modèles.

> ✅ **Si vous ne retenez que 3 choses** — 1. On mesure le taux de doublons trois fois (brut, après déduplication exacte, après déduplication approchée) : l'exacte compare une empreinte SHA-256 du texte normalisé, l'approchée estime la ressemblance de Jaccard avec MinHash (128 « tombolas » → une signature de 128 nombres). 2. LSH découpe les signatures en b bandes de r nombres et ne compare que les documents qui partagent une bande : la courbe en S `1 − (1 − s^r)^b` place le seuil (≈ 0,72 pour b = 14, r = 8). 3. La déduplication sémantique (embeddings, cosinus > 0,95) attrape les reformulations mais doit respecter une règle de survie métier (garder la version en vigueur) ; la décontamination retire les n-grammes longs communs avec vos jeux d'évaluation.

> 🗺️ **Et maintenant ?** — Votre corpus est unique et propre ; il reste à en retirer les numéros de téléphone, IBAN et numéros de sécurité sociale : c'est l'objet de la leçon L177 avec Presidio.
