---
id: L175
module: M36
level: N5
title: "Construire un corpus texte : extraction (Docling, Trafilatura), normalisation, langue, filtres qualité (méthode FineWeb)"
minutes: 50
objectives:
  - "Décrire la chaîne de préparation d'un corpus texte, de l'acquisition au stockage en shards, et situer chaque étape dans un pipeline de données"
  - "Extraire le texte structuré de PDF avec Docling et de pages HTML avec Trafilatura"
  - "Normaliser l'Unicode, identifier la langue avec GlotLID et appliquer des filtres qualité heuristiques inspirés de Gopher, C4 et FineWeb"
  - "Produire un corpus versionné en JSONL et Parquet avec un manifeste et des statistiques de rejet"
skills: ["C5.5"]
sources:
  - { title: "UPPMAX LLM workshop — Data pipelines", url: "https://uppmax.github.io/LLM-workshop/day2/data_pipelines", lang: "en" }
  - { title: "Docling — RAG with OpenSearch (exemple officiel)", url: "https://docling-project.github.io/docling/examples/rag_opensearch", lang: "en" }
  - { title: "Trafilatura — documentation", url: "https://trafilatura.readthedocs.io/", lang: "en" }
  - { title: "huggingface/datatrove", url: "https://github.com/huggingface/datatrove", lang: "en" }
  - { title: "Penedo et al. (2024) — The FineWeb Datasets", url: "https://arxiv.org/abs/2406.17557", lang: "en" }
  - { title: "FineWeb-2 (dépôt)", url: "https://github.com/huggingface/fineweb-2", lang: "en" }
  - { title: "NVIDIA NeMo Curator — Welcome", url: "https://docs.nvidia.com/nemo/curator/latest/home/welcome.md", lang: "en" }
---

# Construire un corpus texte : extraction (Docling, Trafilatura), normalisation, langue, filtres qualité (méthode FineWeb)

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 36

## 🎯 Ce que vous saurez faire
- Transformer les 126 documents internes de Bréval Matériaux (procédures, fiches techniques, CGV, notes — jeu de L151-L152), leurs originaux PDF, quelques pages HTML de l'intranet et les messages des tickets SAV en **un corpus propre et traçable**.
- Expliquer, chiffres de rejet à l'appui, ce que chaque filtre a retiré et pourquoi.
- Réutiliser la même méthode que les grands corpus ouverts (FineWeb, datatrove), à l'échelle d'une PME puis d'un cluster.

> 🧭 **En clair** — Préparer un corpus, c'est comme préparer les légumes avant de cuisiner pour une cantine : on les sort des cagettes (extraction), on les lave et on les épluche (normalisation), on trie ceux qui ne sont pas de la bonne variété (langue), on jette les abîmés (filtres qualité), puis on les range en bacs étiquetés et datés (stockage versionné). Un bon chef ne cuisine jamais avec des légumes non triés : un LLM entraîné, ou un RAG alimenté, avec des textes sales donne des réponses sales. Cette leçon vous donne la chaîne de tri complète, celle qu'utilisent les grands laboratoires, adaptée à une PME.

## 1. Une chaîne en dix étapes, trois usages

Le workshop « LLM data pipelines » de l'UPPMAX (université d'Uppsala) décrit une chaîne de pré-entraînement en dix étapes : acquisition et licences ; extraction et normalisation ; déduplication exacte et approchée ; filtres qualité et décontamination ; tokenisation ; mélange ; stockage et *sharding* ; (la **décontamination** retire du corpus d'entraînement les textes des jeux de test, pour ne pas fausser l'évaluation ; la **tokenisation** découpe le texte en jetons pour le modèle ; le *sharding* le découpe en fichiers, L152) entraînement et observabilité ; évaluation continue ; gouvernance. Les modules N4 ont traité ce pipeline **côté modèle** (lois d'échelle et données de pré-entraînement en L132, jeux de fine-tuning en L137) ; ici, nous le construisons **côté données**, comme un pipeline industriel.

Le même tronc commun sert trois usages, avec des réglages différents :

| Usage | Volume typique | Ce qui compte le plus |
|---|---|---|
| **RAG d'entreprise** (M20, M37) | quelques milliers de documents | structure (titres, tableaux, pages), métadonnées de droits, fraîcheur |
| **Fine-tuning** (M28) | 1 000 à 100 000 exemples | qualité exemplaire, PII retirées, séparation entraînement/évaluation |
| **Pré-entraînement** (N4 M27) | milliards de tokens | filtres heuristiques et classifieurs à grande échelle, déduplication massive |

```
 PDF ─┐                       ┌──────────────── rejets.jsonl (raison, étape) ───────────────┐
 HTML ┼─▶ 1 EXTRAIRE ─▶ 2 NORMALISER ─▶ 3 LANGUE ─▶ 4 FILTRES QUALITÉ ─▶ [L176 dédup] ─▶ [L177 PII]
 SQL ─┘   Docling,      Unicode NFC,    GlotLID      Gopher / C4 /                           │
          Trafilatura   ftfy, espaces                FineWeb adaptés                          ▼
                                                                      5 STOCKER : JSONL + Parquet + manifeste
```

La recette FineWeb (Hugging Face, outil **datatrove**) suit exactement ce schéma pour le web (FineWeb est un grand corpus ouvert de pages web filtrées, construit à partir de **Common Crawl**, une archive publique de milliards de pages) : filtrage d'URL → extraction Trafilatura → filtre de langue → filtres Gopher et C4 → filtres propres à FineWeb → déduplication MinHash → formatage des PII → JSONL.

```quiz
{
  "q": "Pour le RAG documentaire de la PME, quelle information est la plus importante à conserver dès l'extraction ?",
  "options": ["Le nombre total de tokens du corpus, pour le budget", "La structure (titres, tableaux, pages) et la source des passages", "La police et la taille de caractères utilisées dans chaque page des PDF", "L'ordre alphabétique des documents"],
  "answer": 1,
  "explanation": "Un RAG cite ses sources et découpe selon la structure : perdre les titres, les tableaux ou les numéros de page à l'extraction dégrade à la fois le chunking et les citations."
}
```

## 2. Extraire : Docling pour les documents, Trafilatura pour le web

### 2.1 Docling : du PDF au Markdown structuré

Le générateur de L152 livre les documents de Bréval **déjà en Markdown** (`data/raw/documents/md/<doc_id>.md`) avec leurs métadonnées dans `documents.csv` (`doc_id`, `titre`, `type_document`, `service`, `version`, `date_maj`, `confidentialite`, `sha256`) : c'est la forme que doit avoir la sortie d'une bonne extraction. Dans la vraie vie, le serveur de fichiers contient surtout des **PDF** : anciennes procédures signées, fiches fournisseurs, CGV mises en page. Pour vous entraîner, déposez dans `data/raw/documents/pdf/` quelques PDF réels ou exportez quelques fichiers Markdown en PDF (traitement de texte, LibreOffice).

En M20 (L090), vous avez extrait des PDF avec `pypdf`, page par page. C'est suffisant pour des procédures simples ; c'est insuffisant pour des CGV en deux colonnes ou des fiches techniques pleines de tableaux. **Docling**, projet open source issu d'IBM Research, analyse la mise en page (ordre de lecture, titres, tableaux, figures, OCR si nécessaire) — l'**OCR** (reconnaissance optique de caractères) lit le texte d'un document scanné, qui n'est qu'une image et produit un document structuré exportable en Markdown ou JSON.

```python
# extraire_docs.py — pip install docling
# Les modèles de mise en page sont téléchargés au premier lancement (prévoir quelques minutes)
import hashlib
import json
from pathlib import Path
from docling.document_converter import DocumentConverter

import csv

RACINE = Path("data/raw/documents")       # jeu Bréval (L152) : documents.csv + md/ ; vos PDF dans pdf/
SORTIE = Path("corpus/bronze_docs.jsonl")
SORTIE.parent.mkdir(parents=True, exist_ok=True)

with (RACINE / "documents.csv").open(encoding="utf-8") as fcsv:
    META = {m["doc_id"]: m for m in csv.DictReader(fcsv, delimiter=";")}   # séparateur « à la française »

def ecrire(f, doc_id, source, texte, extracteur, sha):
    m = META.get(doc_id, {})
    f.write(json.dumps({
        "doc_id": doc_id, "source": source, "texte": texte, "extracteur": extracteur,
        "sha256_fichier": sha,
        "categorie": m.get("type_document", "pdf_externe"),   # procedure, fiche_technique, cgv, note_interne
        "service": m.get("service", "commun"),                # servira au cloisonnement (L178)
        "version": m.get("version"), "date_maj": m.get("date_maj"),
        "confidentialite": m.get("confidentialite", "interne"),
    }, ensure_ascii=False) + "\n")

convertisseur = DocumentConverter()
with SORTIE.open("w", encoding="utf-8") as f:
    for md in sorted((RACINE / "md").glob("*.md")):            # 1) Markdown déjà structuré
        contenu = md.read_text(encoding="utf-8")
        ecrire(f, md.stem, str(md), contenu, "markdown", hashlib.sha256(contenu.encode()).hexdigest())
    for pdf in sorted((RACINE / "pdf").glob("*.pdf")):          # 2) PDF : Docling
        markdown = convertisseur.convert(pdf).document.export_to_markdown()   # titres "#", tableaux
        ecrire(f, pdf.stem, str(pdf), markdown, "docling", hashlib.sha256(pdf.read_bytes()).hexdigest())
        print(f"{pdf.name}: {len(markdown):,} caractères")
```

> 🧭 **Pré-requis express** — `pip install docling` installe aussi PyTorch et, au premier lancement, télécharge les modèles d'analyse de mise en page : comptez **plusieurs Go** et dix minutes la première fois. Créez le dossier `data/raw/documents/pdf/` (même vide) et lancez le script depuis `breval/`. Si vous n'avez aucun PDF, le script fonctionne quand même : il ne traite que les 126 Markdown.

> 🔍 **Ce que vous devez voir** — une ligne par PDF traité, par exemple `cgv-2025.pdf: 18,532 caractères`, et un fichier `corpus/bronze_docs.jsonl` de **126 lignes** + une par PDF (vérifiez avec `wc -l corpus/bronze_docs.jsonl`, ou en ouvrant le fichier dans votre éditeur : une ligne JSON par document).

> 🛠️ **Si ça ne marche pas** — « ModuleNotFoundError: No module named 'docling' » → l'installation a échoué (souvent l'espace disque) : relisez la fin de la sortie de `pip`. « KeyError: 'doc_id' » → `documents.csv` n'a pas été lu avec le séparateur `;` (copie incomplète du script). Le premier PDF prend plusieurs minutes → téléchargement des modèles, une seule fois.

> 💡 **À retenir** — Gardez **deux empreintes** : un `doc_id` stable (dérivé du chemin ou d'un identifiant métier) et le `sha256` du fichier. Le premier dit « c'est le même document », le second « il a changé ». C'est la base de l'ingestion incrémentale (M37).

### 2.2 Trafilatura : le texte principal d'une page web

Pour les pages HTML (intranet, FAQ publique, base de connaissances), le défi est d'éliminer le *boilerplate* : menus, pieds de page, bandeaux cookies. **Trafilatura** est l'extracteur retenu par FineWeb pour Common Crawl.

```python
# extraire_html.py — pip install trafilatura
import json
from pathlib import Path
import trafilatura

with open("corpus/bronze_web.jsonl", "w", encoding="utf-8") as f:
    for page in sorted(Path("intranet_html").glob("*.html")):
        html = page.read_text(encoding="utf-8", errors="replace")
        texte = trafilatura.extract(html, include_tables=True, include_comments=False,
                                    favor_precision=True)      # préférez la précision au rappel
        if texte:
            f.write(json.dumps({"doc_id": page.stem, "source": str(page),
                                "texte": texte, "extracteur": "trafilatura"},
                               ensure_ascii=False) + "\n")
# Pour une URL publique : trafilatura.fetch_url(url) puis extract(...) — respectez robots.txt et les licences.
```

> 🧭 **Pré-requis express** — Le dossier `intranet_html/` n'est pas fourni : créez-le dans `breval/` et enregistrez-y quelques pages web (dans le navigateur, **Fichier → Enregistrer sous… → « Page web, HTML uniquement »**), par exemple des pages publiques de documentation produit. `favor_precision=True` demande à Trafilatura de préférer laisser passer un peu de texte utile (moins de **rappel**) plutôt que d'inclure du bruit (plus de **précision**).

> 🔍 **Ce que vous devez voir** — aucun affichage ; un fichier `corpus/bronze_web.jsonl` avec une ligne par page dont le texte principal a été trouvé. Ouvrez-le : les menus et pieds de page ont disparu.

Les tickets SAV, eux, sont déjà du texte : un ticket Bréval contient une liste `messages` (auteur, horodatage, texte). On concatène les messages d'un ticket en un document, avec `client_id` et `commande_id` en métadonnées (indispensables pour l'effacement, L174) :

```python
# extraire_tickets.py — tickets_sav.jsonl (L152) -> un document par ticket
import json
with open("data/raw/sav/tickets_sav.jsonl", encoding="utf-8") as fe, \
     open("corpus/bronze_tickets.jsonl", "w", encoding="utf-8") as fs:
    for ligne in fe:
        t = json.loads(ligne)
        texte = "\n".join(f"[{m['auteur']}] {m['texte']}" for m in t.get("messages", []))
        fs.write(json.dumps({"doc_id": t["ticket_id"], "source": "outil_sav", "categorie": "tickets",
                             "texte": texte, "client_id": t["client_id"], "commande_id": t.get("commande_id"),
                             "service": "sav", "extracteur": "jsonl"}, ensure_ascii=False) + "\n")
```

> 🔍 **Ce que vous devez voir** — aucun affichage ; `corpus/bronze_tickets.jsonl` contient **9 048** lignes, chacune avec un `texte` du type `[client] Bonjour, … \n[agent] …`.

> ⚠️ **Piège fréquent** — Collecter « tout le web » ou des documents de partenaires sans vérifier les **licences** et les conditions d'utilisation. L'étape 1 de l'UPPMAX s'appelle « acquisition **et licences** » pour une raison : notez la licence ou la base contractuelle de chaque source dans le manifeste.

## 3. Normaliser et identifier la langue

Les textes extraits contiennent des pièges invisibles : caractères mal décodés (« Ã© » au lieu de « é », le *mojibake*), espaces insécables, ligatures (« ﬁ »), formes Unicode différentes d'un même caractère. Deux textes identiques à l'œil peuvent avoir des octets différents — ce qui ruine la déduplication de L176.

```python
# normaliser.py — pip install ftfy
import re
import unicodedata
import ftfy

def normaliser(texte: str) -> str:
    texte = ftfy.fix_text(texte)                    # répare le mojibake (Ã© -> é), guillemets, etc.
    texte = unicodedata.normalize("NFC", texte)     # une seule forme pour "é" (composée)
    texte = texte.replace(" ", " ").replace(" ", " ")   # espaces insécables -> espace
    texte = re.sub(r"[ \t]+", " ", texte)
    texte = re.sub(r"\n{3,}", "\n\n", texte)
    return texte.strip()

print(normaliser("Les CGV s’appliquent Ã  toute commande : dÃ©lai 30 jours."))
```

> 🔍 **Ce que vous devez voir** — `Les CGV s'appliquent à toute commande : délai 30 jours.` : les « Ã  » et « Ã© » sont réparés, et ftfy remplace aussi par défaut l'apostrophe typographique par une apostrophe droite.

> 💡 **Autrement dit** — NFC, c'est décider une fois pour toutes que « é » s'écrit avec un seul caractère, et pas avec « e » suivi d'un accent ajouté. NFKC va plus loin (ligatures, exposants) mais peut altérer des symboles techniques : réservez-le aux usages où le sens ne change pas.

Pour la **langue**, le workshop UPPMAX cite GlotLID et FastText. (**FastText** est une bibliothèque de Meta pour classer des textes très vite, sans GPU.) **GlotLID** est un modèle FastText d'identification couvrant plus d'un millier de langues, publié sur le Hugging Face Hub :

```python
# langue.py — pip install fasttext huggingface_hub  (sur certaines plateformes : fasttext-wheel)
import fasttext
from huggingface_hub import hf_hub_download

modele = fasttext.load_model(hf_hub_download(repo_id="cis-lmu/glotlid", filename="model.bin"))

def langue(texte: str) -> tuple[str, float]:
    etiquettes, probas = modele.predict(texte.replace("\n", " ")[:2000], k=1)
    return etiquettes[0].removeprefix("__label__"), float(probas[0])   # ex. ("fra_Latn", 0.98)

print(langue("Le délai de rétractation est de quatorze jours à compter de la livraison."))
```

> 🔍 **Ce que vous devez voir** — après le téléchargement du modèle (quelques centaines de Mo, une seule fois, mis en cache par Hugging Face), une ligne `('fra_Latn', 0.99…)`.

> 🛠️ **Si ça ne marche pas** — « error: command 'gcc' failed » ou « Failed building wheel for fasttext » → installez la variante précompilée : `pip install fasttext-wheel`. « ValueError: Unable to avoid copy while creating an array » avec NumPy 2 → `pip install "numpy<2"` dans la venv, ou une version récente de `fasttext-wheel`.

Gardez les documents `fra_Latn` (et `eng_Latn` si des fiches fournisseurs sont en anglais) au-dessus d'un seuil de confiance (0,65 est un point de départ courant) et **journalisez** les autres au lieu de les jeter silencieusement.

## 4. Filtres qualité : la méthode Gopher, C4, FineWeb… adaptée

Les grands corpus combinent des **heuristiques** simples et peu coûteuses, puis, parfois, des **classifieurs** de qualité. (Une **heuristique** est une règle simple « qui marche le plus souvent », comme « une vraie phrase finit par un point » ; un **classifieur** est un petit modèle entraîné à noter la qualité d'un texte.) Les familles de règles, telles que décrites dans les articles et dans datatrove :

| Famille | Exemples de règles (ordre de grandeur publié) | Ce qu'elles chassent |
|---|---|---|
| **Gopher** (DeepMind) | 50 à 100 000 mots ; longueur moyenne des mots entre 3 et 10 caractères ; peu de lignes en puces ou terminées par « … » ; au moins quelques mots outils (« le », « de », « et »…) | pages vides, listes de mots-clés, code ou tableaux bruts |
| **C4** (Google) | garder les lignes terminées par une ponctuation ; retirer les lignes contenant « javascript », « lorem ipsum » ; écarter les pages trop courtes | menus, avertissements techniques, gabarits |
| **FineWeb** | rejeter si trop peu de lignes finissent par une ponctuation, si trop de caractères sont dans des lignes dupliquées, ou si la majorité des lignes sont très courtes (seuils de l'article : 0,12 / 0,1 / 0,67 pour des lignes de moins de 30 caractères — à vérifier dans l'article et le code datatrove) | listes, pages répétitives, navigation résiduelle |

Pour un corpus d'entreprise, on **adapte** : une fiche technique Bréval (« Référence : BRV-GRO-00001 », « Unité : sac »…) est légitimement faite de lignes courtes ; un ticket SAV de 12 mots peut être précieux. Voici des filtres paramétrés par catégorie, avec journal des rejets :

```python
# filtres.py — filtres qualité heuristiques adaptés au corpus d'une PME
import json
import re
from collections import Counter
from pathlib import Path

MOTS_OUTILS_FR = {"le", "la", "les", "de", "des", "du", "et", "un", "une", "en", "à", "pour", "est", "que"}
REGLES = {   # seuils par catégorie : ajustez-les en relisant les rejets
    "procedure":       {"min_mots": 40, "max_lignes_courtes": 0.70, "min_ponct": 0.10},
    "cgv":             {"min_mots": 30, "max_lignes_courtes": 0.60, "min_ponct": 0.20},   # CGV Bréval courtes ; de vraies CGV : ~200
    "fiche_technique": {"min_mots": 25, "max_lignes_courtes": 0.95, "min_ponct": 0.00},
    "note_interne":    {"min_mots": 15, "max_lignes_courtes": 0.80, "min_ponct": 0.00},
    "tickets":         {"min_mots": 8,  "max_lignes_courtes": 1.00, "min_ponct": 0.00},
    "web":             {"min_mots": 50, "max_lignes_courtes": 0.67, "min_ponct": 0.12},
}

def raisons_de_rejet(texte: str, categorie: str) -> list[str]:
    r = REGLES.get(categorie, REGLES["web"])
    mots = re.findall(r"\w+", texte.lower())
    lignes = [l for l in texte.splitlines() if l.strip()]
    raisons = []
    if len(mots) < r["min_mots"]:
        raisons.append("trop_court")
    if mots and not 3 <= sum(map(len, mots)) / len(mots) <= 10:
        raisons.append("longueur_mots_anormale")             # Gopher
    if len(MOTS_OUTILS_FR & set(mots)) < 2 and categorie not in ("fiche_technique", "tickets"):
        raisons.append("pas_de_phrases")                     # Gopher (mots outils)
    if lignes:
        courtes = sum(len(l) < 30 for l in lignes) / len(lignes)
        ponct = sum(l.rstrip().endswith((".", "!", "?", ":", "»")) for l in lignes) / len(lignes)
        doublons = Counter(lignes)
        part_dupliquee = sum(len(l) * (n - 1) for l, n in doublons.items()) / max(1, len(texte))
        if courtes > r["max_lignes_courtes"]:
            raisons.append("lignes_trop_courtes")            # FineWeb
        if ponct < r["min_ponct"]:
            raisons.append("peu_de_ponctuation")             # FineWeb / C4
        if part_dupliquee > 0.10:
            raisons.append("lignes_dupliquees")              # FineWeb (ex. en-têtes répétés)
    if re.search(r"lorem ipsum|javascript", texte, re.I):
        raisons.append("gabarit")                            # C4
    return raisons

def filtrer(entree: str, sortie: str, rejets: str, categorie: str) -> Counter:
    stats = Counter()
    # Mode ajout ("a") : documents et tickets s'accumulent dans les mêmes fichiers ; ceux-ci sont vidés une fois,
    # au début de chaque exécution (bloc __main__ ci-dessous), pour qu'un relancement ne crée pas de doublons.
    with open(entree, encoding="utf-8") as fe, open(sortie, "a", encoding="utf-8") as fs, \
         open(rejets, "a", encoding="utf-8") as fr:
        for ligne in fe:
            doc = json.loads(ligne)
            raisons = raisons_de_rejet(doc["texte"], doc.get("categorie", categorie))
            stats["total"] += 1
            if raisons:
                stats.update(raisons)
                fr.write(json.dumps({"doc_id": doc["doc_id"], "raisons": raisons}, ensure_ascii=False) + "\n")
            else:
                stats["gardes"] += 1
                fs.write(json.dumps(doc, ensure_ascii=False) + "\n")
    return stats

if __name__ == "__main__":
    for f in ("corpus/silver_filtre.jsonl", "corpus/rejets.jsonl"):
        Path(f).unlink(missing_ok=True)          # vider avant : relancer le script donne le même résultat
    print(filtrer("corpus/bronze_docs.jsonl", "corpus/silver_filtre.jsonl", "corpus/rejets.jsonl", "procedure"))
    print(filtrer("corpus/bronze_tickets.jsonl", "corpus/silver_filtre.jsonl", "corpus/rejets.jsonl", "tickets"))
```

> 🧭 **Pré-requis express** — Lancez `python filtres.py` depuis `breval/` : le bloc final `if __name__ == "__main__":` vide `corpus/silver_filtre.jsonl` et `corpus/rejets.jsonl` (`Path(f).unlink(missing_ok=True)`), puis appelle `filtrer()` sur les documents (`bronze_docs.jsonl`), puis sur les tickets (`bronze_tickets.jsonl`). Importé depuis un autre script (`from filtres import filtrer`), le fichier ne lance rien. La catégorie passée en argument ne sert que si le document n'a pas la sienne.

> 🔍 **Ce que vous devez voir** — deux compteurs du type `Counter({'total': 126, 'gardes': 121, 'trop_court': 3, …})` puis `Counter({'total': 9048, 'gardes': 90xx, …})` : les raisons de rejet et leur nombre. Ouvrez `corpus/rejets.jsonl` pour relire les documents écartés.

> 🛠️ **Si ça ne marche pas** — Les nombres doublent à chaque lancement → les fichiers de sortie sont ouverts en mode **ajout** (`"a"`) et n'ont pas été vidés : vérifiez que les deux lignes `unlink` du bloc final sont présentes, ou, si vous appelez `filtrer()` depuis un autre script, supprimez `corpus/silver_filtre.jsonl` et `corpus/rejets.jsonl` avant de relancer. Sinon, les doublons fausseront la déduplication de L176.

> ⚠️ **Piège fréquent** — Régler les seuils « à l'aveugle ». Relisez **50 rejets et 50 documents gardés** par catégorie avant de valider : un filtre qui supprime 40 % des CGV parce qu'elles contiennent beaucoup de numéros d'articles est un filtre mal réglé, pas des CGV de mauvaise qualité.

```quiz
{
  "type": "vrai_faux",
  "q": "Les seuils de filtrage publiés par FineWeb pour le web anglais peuvent être appliqués tels quels aux fiches techniques d'une PME française.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : ces seuils visent à écarter des pages web de navigation ou de listes. Une fiche technique est légitimement faite de lignes courtes et de tableaux ; il faut des seuils par catégorie, réglés en relisant des échantillons."
}
```

## 5. Stocker : JSONL pour relire, Parquet pour l'échelle, manifeste toujours

Le workshop UPPMAX recommande **JSONL** pour prototyper et relire, puis **Parquet/Arrow** en shards de **50 à 500 Mo** à l'échelle, et de **toujours enregistrer versions et manifestes**.

```python
# stocker.py — JSONL -> Parquet + manifeste (pip install polars)
import datetime as dt
import hashlib
import json
from pathlib import Path
import polars as pl

df = pl.read_ndjson("corpus/silver_filtre.jsonl")
Path("corpus/silver").mkdir(parents=True, exist_ok=True)
df.write_parquet("corpus/silver/part-0000.parquet", compression="zstd")   # un shard ; découpez au-delà de ~500 Mo

manifeste = {
    "version": "2026-11-05.1",
    "cree_le": dt.datetime.now(dt.timezone.utc).isoformat(),
    "nb_documents": df.height,
    "par_categorie": dict(df.group_by("categorie").len().iter_rows()) if "categorie" in df.columns else {},
    "etapes": ["docling|trafilatura", "ftfy+NFC", "glotlid>=0.65 fra/eng", "filtres v1 (seuils par catégorie)"],
    "code_git": "à renseigner : git rev-parse HEAD",
    "sha256_shards": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in Path("corpus/silver").glob("*.parquet")},
}
Path("corpus/silver/MANIFEST.json").write_text(json.dumps(manifeste, ensure_ascii=False, indent=2))
```

> 🔍 **Ce que vous devez voir** — aucun affichage ; `corpus/silver/` contient `part-0000.parquet` et `MANIFEST.json`, dont `nb_documents` est égal au nombre de documents gardés par les filtres et `par_categorie` donne le détail (`procedure`, `fiche_technique`, `cgv`, `note_interne`, `tickets`…).

> 🛠️ **Si ça ne marche pas** — « FileNotFoundError: corpus/silver_filtre.jsonl » → les filtres n'ont pas été exécutés (voir le pré-requis de la section 4).

À grande échelle, ne réécrivez pas tout : **datatrove** (Hugging Face) fournit lecteurs, filtres (dont `GopherQualityFilter`, `C4QualityFilter`, `FineWebQualityFilter`, `LanguageFilter`), dédupliqueurs et écrivains, exécutables en local ou sur un cluster Slurm (Slurm est le gestionnaire de tâches des supercalculateurs et des clusters universitaires) ; **NeMo Curator** (NVIDIA) couvre le texte, l'image, la vidéo et l'audio, avec accélération GPU. Les noms et paramètres exacts sont à prendre dans leur documentation, ils évoluent souvent.

```mission
{
  "title": "Les étapes de la recette FineWeb",
  "url": "https://uppmax.github.io/LLM-workshop/day2/data_pipelines",
  "steps": ["Ouvrez la page « Data pipelines » du LLM workshop de l'UPPMAX", "Repérez la partie consacrée à FineWeb et datatrove", "Notez l'ordre des étapes et les paramètres de la déduplication MinHash"],
  "question": "Dans quel ordre la recette FineWeb enchaîne-t-elle ses étapes, et combien de buckets utilise sa déduplication MinHash ?",
  "hint": "La chaîne commence par un filtrage d'URL et se termine par un écrivain JSONL.",
  "answer": "Filtrage d'URL → extraction Trafilatura → filtre de langue → filtres Gopher et C4 → filtre FineWeb → MinHash en 4 étapes (5-grammes, 14 buckets) → formatage PII → JSONL (page consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 6. 🎮 Défi : le juge de ligne

Classez « garder » ou « rejeter » pour le RAG, et donnez la règle : (a) une page « Accueil | Produits | Contact | Mentions légales » ; (b) un ticket « Colis reçu abîmé, je veux un avoir. » ; (c) une fiche technique de 45 mots dont 30 lignes de caractéristiques ; (d) un PDF de 3 pages identique à un autre au mot près. *Réponses : (a) rejeter (lignes courtes, pas de phrases) ; (b) garder (catégorie tickets, seuil 8 mots) ; (c) garder (seuil des fiches techniques) ; (d) pas un problème de qualité mais de **déduplication** — c'est la leçon suivante.*

## 🧪 Exercice pratique

**Consigne** : assemblez `extraire_docs.py`, `extraire_html.py`, l'export des tickets, `normaliser.py`, `langue.py`, `filtres.py` et `stocker.py` en un seul script `construire_corpus.py` (ou en assets Dagster si vous avez suivi M33). Appliquez-le aux 126 documents Markdown de Bréval, à au moins 10 PDF (créez-en si besoin en exportant des procédures et des CGV depuis un traitement de texte), à 5 pages HTML et aux 9 048 tickets SAV.

**Critères de réussite** :
- un tableau de statistiques par catégorie : documents en entrée, rejetés (par raison), gardés ;
- un `MANIFEST.json` qui permet de refaire exactement le même corpus (versions, seuils, empreintes) ;
- une relecture documentée de 10 rejets : combien étaient de « faux rejets » ? Ajustez un seuil en conséquence.

**Pistes de corrigé** : taux de rejet attendu faible sur des PDF internes (< 10 %) et plus élevé sur le HTML (pages de navigation) ; si des CGV sont rejetées pour « peu_de_ponctuation », c'est souvent que Docling a converti des listes d'articles en lignes séparées : baissez `min_ponct` des CGV ou recollez les lignes d'un même paragraphe. Pensez à ajouter au manifeste la version de Docling et de GlotLID (`pip freeze`).

## ✅ Auto-évaluation express
1. Pourquoi normaliser l'Unicode avant de dédupliquer ?
2. Quand préférer Docling à `pypdf` ?
3. Que doit contenir au minimum un manifeste de corpus ?

**Réponses** : 1. Deux textes identiques à l'œil peuvent avoir des octets différents (formes NFC/NFD, espaces insécables, mojibake) et échapper à la détection de doublons. 2. Pour des documents à mise en page complexe (colonnes, tableaux, figures, scans) dont il faut garder la structure. 3. La version, la date, le nombre de documents, les étapes et leurs paramètres, la version du code et les empreintes des fichiers produits.

## 📚 Pour aller plus loin
- [UPPMAX — LLM workshop, Data pipelines](https://uppmax.github.io/LLM-workshop/day2/data_pipelines) 🇬🇧 — les dix étapes et la recette FineWeb.
- [Docling — exemple RAG avec OpenSearch](https://docling-project.github.io/docling/examples/rag_opensearch) 🇬🇧 — conversion et indexation de bout en bout.
- [Trafilatura — documentation](https://trafilatura.readthedocs.io/) 🇬🇧 — options d'extraction.
- [huggingface/datatrove](https://github.com/huggingface/datatrove) 🇬🇧 — la bibliothèque de traitement utilisée pour FineWeb.
- [The FineWeb Datasets (arXiv 2406.17557)](https://arxiv.org/abs/2406.17557) 🇬🇧 — l'article qui détaille et évalue chaque filtre.
- [FineWeb-2](https://github.com/huggingface/fineweb-2) 🇬🇧 — l'extension multilingue (dont le français).
- [NVIDIA NeMo Curator](https://docs.nvidia.com/nemo/curator/latest/home/welcome.md) 🇬🇧 — curation à l'échelle, multimodale.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un corpus se construit en chaîne traçable : extraire (Docling pour les PDF structurés, Trafilatura pour le web), normaliser (ftfy + Unicode NFC), identifier la langue (GlotLID), filtrer, stocker (JSONL pour relire, Parquet pour l'échelle) avec un manifeste. 2. Les filtres qualité (Gopher, C4, FineWeb) sont des heuristiques à **adapter par catégorie** de document et à régler en relisant rejets et documents gardés ; tout rejet est journalisé avec sa raison. 3. Chaque document garde deux empreintes, un `doc_id` stable et le `sha256` du fichier, plus ses métadonnées (service, version, confidentialité, `client_id`) : ce sont elles qui permettront la mise à jour incrémentale, le cloisonnement et l'effacement.

> 🗺️ **Et maintenant ?** — Votre corpus est propre, mais il contient sans doute dix copies de la même procédure : la leçon L176 vous apprend à repérer doublons exacts et quasi-doublons, même sur des millions de documents.
