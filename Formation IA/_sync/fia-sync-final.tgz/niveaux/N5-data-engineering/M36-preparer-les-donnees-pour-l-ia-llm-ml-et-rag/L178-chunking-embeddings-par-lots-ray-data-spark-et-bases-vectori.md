---
id: L178
module: M36
level: N5
title: "Chunking, embeddings par lots (Ray Data, Spark) et bases vectorielles à l'échelle : index, filtres, multi-tenance, coûts"
minutes: 55
objectives:
  - "Industrialiser le chunking : configuration versionnée, identifiants de chunks stables, métadonnées de droits et de traçabilité"
  - "Calculer des embeddings par lots de façon incrémentale et parallèle avec Ray Data ou Spark"
  - "Dimensionner une base vectorielle : choix d'index (HNSW, IVF), quantification, mémoire et coût"
  - "Mettre en œuvre filtrage par métadonnées, multi-tenance, upserts idempotents, suppressions et ré-indexation sans coupure"
skills: ["C5.5", "C5.3"]
sources:
  - { title: "Ray — Working with LLMs (Ray Data LLM)", url: "https://docs.ray.io/en/latest/data/working-with-llms.html", lang: "en" }
  - { title: "Ray — Offline batch inference", url: "https://docs.ray.io/en/latest/data/batch_inference.html", lang: "en" }
  - { title: "Qdrant — documentation", url: "https://qdrant.tech/documentation/", lang: "en" }
  - { title: "pgvector — dépôt officiel", url: "https://github.com/pgvector/pgvector", lang: "en" }
  - { title: "Milvus — documentation", url: "https://milvus.io/docs", lang: "en" }
  - { title: "PySpark — Getting Started", url: "https://spark.apache.org/docs/latest/api/python/getting_started/", lang: "en" }
  - { title: "Feast — documentation (llms.txt)", url: "https://docs.feast.dev/llms.txt", lang: "en" }
---

# Chunking, embeddings par lots (Ray Data, Spark) et bases vectorielles à l'échelle : index, filtres, multi-tenance, coûts

> ⏱ 55 min · 🎯 Niveau 5 · 📚 Module 36

## 🎯 Ce que vous saurez faire
- Passer du RAG « qui marche sur mon poste » (N3, M20) au RAG qui tient **100 000 puis 10 millions** de chunks, se met à jour chaque nuit et coûte un montant prévisible.
- Écrire un job d'embeddings par lots qui ne recalcule **que** ce qui a changé, en parallèle sur CPU ou GPU.
- Configurer Qdrant ou pgvector pour filtrer par service ou par client sans fuite, et changer de modèle d'embedding sans interrompre l'assistant.

> 🧭 **En clair** — En N3, vous avez construit une bibliothèque de quartier : quelques centaines de livres, rangés à la main. Ici, on construit la **Bibliothèque nationale** : des millions d'ouvrages, des arrivages chaque nuit, des salles réservées à certains lecteurs, et un budget à tenir. Il faut des **cotes** stables (identifiants de chunks), une **chaîne de catalogage** qui traite les nouveautés par cartons entiers (embeddings par lots), des **rayonnages** adaptés au volume (index et compression des vecteurs), des **badges d'accès** (filtres et multi-tenance) et la possibilité de **réorganiser** les rayons sans fermer la bibliothèque (ré-indexation par alias).

## 1. Ce qui change à l'échelle

La leçon L090 a présenté les stratégies de découpage (taille fixe avec recouvrement, récursif, par structure, sémantique) et L089 les embeddings, la similarité cosinus et l'index HNSW ; L093 l'évaluation (recall@k, MRR). Nous ne les répétons pas. À l'échelle, quatre questions nouvelles apparaissent :

| Question | Petite échelle (M20) | Échelle de production (ici) |
|---|---|---|
| Quand re-vectoriser ? | tout, à chaque fois | seulement les chunks nouveaux ou modifiés, ou tout si le **modèle** change |
| Comment calculer ? | une boucle Python | lots parallèles (Ray Data, Spark), GPU, reprise sur erreur |
| Où stocker ? | n'importe quelle base vectorielle | base dimensionnée : index, quantification, disque/RAM, sauvegardes |
| Qui voit quoi ? | tout le monde | filtres obligatoires, multi-tenance, suppressions propagées (CDC) |

```
silver (texte pseudonymisé, L177)
   │ 1. CHUNKER (config versionnée)  → chunks.parquet  [chunk_id, doc_id, texte, meta, chunking_v]
   │ 2. DIFF (anti-jointure sur chunk_id + modele_v) → seulement les nouveaux
   │ 3. EMBEDDER par lots (Ray Data / Spark) → embeddings.parquet
   │ 4. UPSERT idempotent + suppressions (tombstones CDC) → Qdrant / pgvector
   ▼
 index servi derrière un ALIAS (bascule sans coupure lors d'un changement de modèle)
```

## 2. Chunking industriel : la cote de chaque morceau

Trois règles transforment un découpage en actif de production :

1. **La configuration est versionnée** : `chunking_v = "struct-md-v2 (max 350 tokens, recouvrement 50)"`. Changer un paramètre crée une nouvelle version, comme changer le modèle.
2. **L'identifiant est stable et déterministe** : `chunk_id = sha256(doc_id | chunking_v | position | texte)`. Rejouer le pipeline produit les mêmes identifiants : l'upsert est **idempotent** (zéro doublon, compétence C5.2 vue en M33).
3. **Les métadonnées servent trois usages** : citer (source, page, section, date), **filtrer** (service, `tenant_id`, niveau de confidentialité, langue) et **effacer** (`client_id`, `doc_id` — L174).

```python
# chunker.py — découpage par structure Markdown (sortie Docling, L175) + identifiants stables
# pip install polars tiktoken
import hashlib
import re
import polars as pl
import tiktoken

CHUNKING_V = "struct-md-v2-max350-rec50"
enc = tiktoken.get_encoding("cl100k_base")      # approximation du nombre de tokens, suffisante pour dimensionner

def decouper(markdown: str, max_tokens: int = 350, recouvrement: int = 50) -> list[tuple[str, str]]:
    """Coupe d'abord aux titres, puis par fenêtres de tokens dans les sections trop longues."""
    morceaux, section = [], "Préambule"
    for bloc in re.split(r"\n(?=#{1,3} )", markdown):
        if bloc.startswith("#"):
            section = bloc.splitlines()[0].lstrip("# ").strip()
        toks = enc.encode(bloc)
        pas = max_tokens - recouvrement
        for debut in range(0, max(1, len(toks)), pas):
            morceaux.append((section, enc.decode(toks[debut:debut + max_tokens])))
            if debut + max_tokens >= len(toks):
                break
    return morceaux

docs = pl.read_ndjson("corpus/silver_tickets.jsonl", infer_schema_length=None)   # sortie pseudonymisée de L177
lignes = []
for d in docs.iter_rows(named=True):
    for pos, (section, texte) in enumerate(decouper(d["texte"])):
        cle = f"{d['doc_id']}|{CHUNKING_V}|{pos}|{texte}"
        lignes.append({
            "chunk_id": hashlib.sha256(cle.encode()).hexdigest()[:32],
            "doc_id": d["doc_id"], "position": pos, "section": section, "texte": texte,
            "source": d["source"], "categorie": d.get("categorie"),
            "tenant_id": d.get("service", "commun"),          # cloisonnement par service
            "client_id": d.get("client_id"),                  # pour l'effacement (tickets)
            "chunking_v": CHUNKING_V,
        })
pl.DataFrame(lignes, infer_schema_length=None).write_parquet("corpus/chunks.parquet")   # client_id nul pour les documents
print(len(lignes), "chunks")
```

> 🧭 **Pré-requis express** — `tiktoken` est le découpeur en tokens d'OpenAI ; `cl100k_base` est l'un de ses vocabulaires. On ne l'utilise ici que pour **compter** des tokens (et donc dimensionner les morceaux), pas pour appeler une API. Le script lit `corpus/silver_tickets.jsonl`, produit par `anonymiser.py` (L177).

> 🔍 **Ce que vous devez voir** — une seule ligne, par exemple `10342 chunks` (de l'ordre de 10 000 : un ou deux chunks par ticket, quelques-uns par document), et un fichier `corpus/chunks.parquet`. Relancez : **le même nombre** et les mêmes `chunk_id` (vérifiez avec `duckdb -c "SELECT count(DISTINCT chunk_id) FROM 'corpus/chunks.parquet'"`), preuve que les identifiants sont déterministes.

> 🛠️ **Si ça ne marche pas** — « FileNotFoundError: corpus/silver_tickets.jsonl » → faites d'abord L177. « ComputeError » de Polars sur `client_id` → mélange d'entiers et de nuls mal deviné : l'option `infer_schema_length=None` (lire tout le fichier) doit rester présente.

> 💡 **À retenir** — Le référentiel (C5.5) demande que **la stratégie de chunking soit justifiée par une évaluation de récupération**. Gardez deux ou trois configurations candidates, mesurez recall@5 et MRR sur votre jeu de questions (méthode de L093), et notez le résultat dans le manifeste : c'est votre justification.

```quiz
{
  "q": "Pourquoi inclure la version de la configuration de chunking dans le calcul du chunk_id ?",
  "options": ["Pour rendre les identifiants plus longs, donc plus résistants aux collisions", "Pour qu'un nouveau découpage ait ses propres identifiants, sans mélange", "Parce que Qdrant l'exige pour tout identifiant de point", "Pour accélérer la recherche HNSW en regroupant les chunks par version"],
  "answer": 1,
  "explanation": "Si l'on change la taille des morceaux sans changer les identifiants, d'anciens et de nouveaux chunks coexistent sous des clés incohérentes. Versionner la configuration dans l'identifiant rend chaque découpage explicite et traçable."
}
```

## 3. Embeddings par lots : Ray Data ou Spark

### 3.1 Ne calculer que ce qui manque

Avant tout calcul, une **anti-jointure** entre les chunks et les embeddings déjà calculés **pour le même modèle** : (une **anti-jointure** garde les lignes de gauche qui n'ont **aucune** correspondance à droite)

```sql
-- a_calculer.sql (DuckDB) : chunks sans embedding pour le modèle courant
COPY (
  SELECT c.* FROM 'corpus/chunks.parquet' c
  ANTI JOIN (SELECT chunk_id FROM 'corpus/embeddings/*.parquet' WHERE modele_v = 'bge-m3@2026-11')
       e USING (chunk_id)
) TO 'corpus/a_calculer.parquet' (FORMAT parquet);
```

Au tout premier passage, le dossier `corpus/embeddings/` n'existe pas encore et DuckDB refuse un motif qui ne trouve aucun fichier. Le petit lanceur ci-dessous crée le dossier, puis exécute la même anti-jointure, contre une liste vide tant qu'aucun embedding n'a été calculé :

```python
# a_calculer.py — lance l'anti-jointure de a_calculer.sql, y compris à la première exécution
from pathlib import Path
import duckdb

EMB = Path("corpus/embeddings")
EMB.mkdir(parents=True, exist_ok=True)          # première exécution : le dossier n'existe pas encore
deja = ("SELECT chunk_id FROM 'corpus/embeddings/*.parquet' WHERE modele_v = 'bge-m3@2026-11'"
        if any(EMB.glob("*.parquet"))
        else "SELECT CAST(NULL AS VARCHAR) AS chunk_id WHERE false")   # aucun embedding : tout est à calculer
duckdb.sql(f"""
COPY (
  SELECT c.* FROM 'corpus/chunks.parquet' c
  ANTI JOIN ({deja}) e USING (chunk_id)
) TO 'corpus/a_calculer.parquet' (FORMAT parquet)
""")
```

> 🛠️ **Si ça ne marche pas** — « IO Error: No files found that match the pattern "corpus/embeddings/*.parquet" » au **premier** lancement de `a_calculer.sql` → normal, aucun embedding n'existe encore : utilisez `python a_calculer.py`, qui gère ce cas. Si vous tenez à la version SQL, amorcez une seule fois avec `duckdb -c "COPY (FROM 'corpus/chunks.parquet') TO 'corpus/a_calculer.parquet' (FORMAT parquet)"` (tous les chunks sont à calculer), puis utilisez ce script à partir de la deuxième exécution.

> 🔍 **Ce que vous devez voir** — aucun affichage ; `SELECT count(*) FROM 'corpus/a_calculer.parquet'` donne le nombre de chunks à vectoriser : tous la première fois, **0** à la seconde si rien n'a changé.

### 3.2 Ray Data : des lots parallèles, CPU ou GPU

**Ray Data** (bibliothèque du framework de calcul distribué Ray) lit des Parquet, applique une fonction par **lots** sur un **pool d'acteurs** (des processus qui gardent le modèle chargé en mémoire) et réécrit des Parquet. Le même code tourne sur un portable et sur un cluster de GPU. Pour l'inférence de **LLM** par lots (classification, extraction, génération), Ray fournit en plus `ray.data.llm` (moteurs vLLM et SGLang, `build_processor`, plusieurs répliques GPU) ; la documentation Ray 2.60 en décrit l'usage, y compris pour les embeddings.

```python
# embed_ray.py — pip install "ray[data]" sentence-transformers pyarrow
import os
import numpy as np
import ray

MODELE = os.environ.get("EMBEDDING_MODEL", "BAAI/bge-m3")
MODELE_V = "bge-m3@2026-11"
GPU = float(os.environ.get("NUM_GPUS_PAR_ACTEUR", "0"))   # 1 si vous avez un GPU

class Embedder:
    def __init__(self):
        from sentence_transformers import SentenceTransformer
        self.modele = SentenceTransformer(MODELE, device="cuda" if GPU else "cpu")

    def __call__(self, lot: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
        lot["vecteur"] = self.modele.encode(list(lot["texte"]), batch_size=32,
                                            normalize_embeddings=True).astype(np.float32)
        lot["modele_v"] = np.full(len(lot["texte"]), MODELE_V)
        return lot

ray.init()
ds = ray.data.read_parquet("corpus/a_calculer.parquet")
ds = ds.map_batches(Embedder, batch_size=128, concurrency=2, num_gpus=GPU)   # 2 acteurs en parallèle
ds.write_parquet("corpus/embeddings/")     # un fichier par bloc ; reprise possible bloc par bloc
```

> 🧭 **Pré-requis express** — Sur un ordinateur sans GPU, vectoriser ~10 000 chunks avec `bge-m3` peut prendre **une heure ou plus** : pour un premier essai, réduisez le volume (`ds = ds.limit(500)` juste après `read_parquet`), ou choisissez un modèle plus léger (`export EMBEDDING_MODEL=BAAI/bge-small-en-v1.5` pour un test technique, en changeant aussi `MODELE_V` et la taille 1024 → 384 de la collection Qdrant). Avec un GPU NVIDIA : `export NUM_GPUS_PAR_ACTEUR=1`.

> 🔍 **Ce que vous devez voir** — des journaux Ray puis une barre de progression `Running Dataset … MapBatches(Embedder) … 100%` ; le dossier `corpus/embeddings/` se remplit de fichiers `….parquet` contenant les colonnes d'origine plus `vecteur` (1 024 nombres) et `modele_v`.

> 🛠️ **Si ça ne marche pas** — « OutOfMemoryError » ou ordinateur figé → baissez `concurrency=2` à `1` (chaque acteur charge sa propre copie du modèle, ~2 Go). Ray ne démarre pas sous Windows natif → WSL (voir L160).

### 3.3 Spark : quand les données vivent déjà dans le lakehouse

Si vos chunks sont dans une table Delta ou Iceberg traitée par Spark (M32), une **UDF pandas** fait le même travail (*User-Defined Function* : une fonction Python que Spark applique à des paquets de lignes, reçus sous forme de séries pandas), le modèle étant chargé une fois par processus exécuteur :

```python
# embed_spark.py — pip install pyspark sentence-transformers pandas pyarrow
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import pandas_udf

spark = SparkSession.builder.appName("embeddings").getOrCreate()
_modele = None

@pandas_udf("array<float>")
def embed(textes: pd.Series) -> pd.Series:
    global _modele
    if _modele is None:
        from sentence_transformers import SentenceTransformer
        _modele = SentenceTransformer("BAAI/bge-m3")
    vecteurs = _modele.encode(textes.tolist(), batch_size=32, normalize_embeddings=True)
    return pd.Series([v.tolist() for v in vecteurs])

chunks = spark.read.parquet("corpus/a_calculer.parquet").repartition(8)   # 8 tâches parallèles
chunks.withColumn("vecteur", embed("texte")).write.mode("append").parquet("corpus/embeddings_spark/")
```

> ⚠️ **Piège fréquent** — Mélanger dans un même index des vecteurs de **deux modèles** (ou de deux versions d'un même modèle). Les espaces vectoriels sont incompatibles : la recherche renvoie du bruit sans aucune erreur. Le champ `modele_v` doit être obligatoire, et un changement de modèle déclenche une **ré-indexation complète** dans une nouvelle collection (§5).

> 💡 **Autrement dit** — Ray Data et Spark font la même chose ici : découper la pile de textes en cartons, confier chaque carton à un ouvrier qui a déjà son outil en main (le modèle chargé), et ranger les résultats. Ray est plus naturel pour du Python et des GPU ; Spark quand tout le reste du pipeline est déjà dans Spark.

```mission
{
  "title": "Les moteurs d'inférence de Ray Data LLM",
  "url": "https://docs.ray.io/en/latest/data/working-with-llms.html",
  "steps": ["Ouvrez la page « Working with LLMs » de la documentation Ray Data", "Repérez la fonction qui construit un processeur d'inférence par lots", "Notez les moteurs d'inférence pris en charge et le paramètre qui règle le nombre de répliques"],
  "question": "Quelle fonction construit le processeur, quels moteurs sont cités et quel paramètre permet de lancer plusieurs répliques sur plusieurs GPU ?",
  "hint": "La fonction commence par « build_ » ; les moteurs sont deux projets open source de serving de LLM.",
  "answer": "build_processor ; moteurs vLLM et SGLang ; le paramètre concurrency règle le nombre de répliques (documentation Ray 2.60, consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Bases vectorielles à l'échelle : index, compression, mémoire

### 4.1 Index : HNSW ou IVF

| Index | Principe | Forces | Faiblesses | Où |
|---|---|---|---|---|
| **HNSW** | graphe de voisins à plusieurs niveaux (L089) | excellent rappel, faible latence, insertions continues | mémoire élevée, construction coûteuse | Qdrant, pgvector, Milvus, OpenSearch, Weaviate |
| **IVF** (*inverted file*) | k-means en *n* listes ; on ne fouille que les listes les plus proches | construction rapide, mémoire modérée, se combine à la compression PQ | rappel sensible au paramètre de sondage, ré-entraînement si la distribution change | pgvector (IVFFlat), Milvus (IVF_FLAT, IVF_PQ…), Faiss |
| Recherche exacte | comparer à tout | rappel parfait | O(n) | petits volumes, tests |

*La **PQ** (*product quantization*) compresse un vecteur en le découpant en morceaux remplacés chacun par le numéro du « prototype » le plus proche ; la **quantification scalaire** (int8) arrondit chaque nombre sur 1 octet au lieu de 4.*

### 4.2 Combien de mémoire ? Le calcul à savoir faire

```
mémoire des vecteurs ≈ N × d × octets par dimension
float32 = 4 octets · float16/halfvec = 2 · int8 (quantification scalaire) = 1 · binaire = 1/8
+ graphe HNSW ≈ N × m × 2 × 4 octets à la couche 0 (m = 16 → ~128 octets par vecteur)
```

| Scénario | N | d | float32 | int8 | binaire |
|---|---|---|---|---|---|
| Bréval, fil rouge (126 documents + 9 048 tickets, ≈ 10 000 chunks) | 10 000 | 1 024 | **41 Mo** | 10 Mo | 1,3 Mo |
| PME plus documentée (5 000 documents × 20 chunks) | 100 000 | 1 024 | **0,4 Go** | 0,1 Go | 13 Mo |
| ETI, base documentaire + 5 ans de tickets | 10 000 000 | 1 024 | **41 Go** | 10 Go | 1,3 Go |

Conclusion pour la PME : **pgvector dans le Postgres existant** suffit largement (M20 le recommandait déjà). Au-delà de quelques millions de vecteurs, la **quantification** (int8, binaire, PQ) avec **re-scoring** des meilleurs candidats sur les vecteurs complets (*re-scoring* : on recalcule précisément le score des 50 à 100 meilleurs candidats trouvés avec les vecteurs compressés), et le stockage des vecteurs complets **sur disque**, deviennent les leviers principaux.

> 💡 **À retenir** — La quantification réduit la mémoire d'un facteur 4 (int8) à 32 (binaire) au prix d'une légère perte de rappel, que l'on récupère en grande partie en ré-ordonnant les 50-100 premiers résultats avec les vecteurs pleins. Mesurez toujours le rappel **avant/après** sur votre jeu d'évaluation.

### 4.3 Coût de calcul des embeddings

À titre d'ordre de grandeur, avec le tarif de Mistral Embed relevé en L089 (0,10 $ par million de tokens, nov. 2026) : 10 millions de chunks × 300 tokens = 3 milliards de tokens ≈ **300 $** pour une indexation complète ; 100 000 chunks ≈ **3 $**. En local sur GPU, le coût est l'électricité et l'amortissement de la machine : mesurez votre débit (chunks par seconde) avec `embed_ray.py` sur 10 000 chunks avant d'extrapoler. Le vrai coût récurrent n'est pas l'indexation initiale mais la **ré-indexation** à chaque changement de modèle : d'où l'intérêt de ne pas en changer à la légère.

```quiz
{
  "q": "Un index de 10 millions de vecteurs de dimension 1 024 en float32 occupe environ combien de mémoire pour les seuls vecteurs ?",
  "options": ["Environ 4 Go", "Environ 41 Go", "Environ 410 Go", "Environ 400 Mo"],
  "answer": 1,
  "explanation": "10 000 000 × 1 024 × 4 octets ≈ 40,96 milliards d'octets, soit environ 41 Go, sans compter le graphe HNSW. En int8, on descend à environ 10 Go."
}
```

## 5. Filtres, multi-tenance, mises à jour : l'exploitation

### 5.1 Qdrant : collection configurée pour la production

```python
# qdrant_prod.py — pip install qdrant-client pyarrow ; Qdrant du Docker Compose sur 6333
import os
import uuid
import pyarrow.dataset as pads
from qdrant_client import QdrantClient, models

q = QdrantClient(url=os.environ.get("QDRANT_URL", "http://localhost:6333"))
COLLECTION, ALIAS = "chunks_bge_m3_v1", "chunks"

if not q.collection_exists(COLLECTION):
    q.create_collection(
        COLLECTION,
        vectors_config=models.VectorParams(size=1024, distance=models.Distance.COSINE, on_disk=True),
        quantization_config=models.ScalarQuantization(
            scalar=models.ScalarQuantizationConfig(type=models.ScalarType.INT8, always_ram=True)),
        hnsw_config=models.HnswConfigDiff(m=16, payload_m=16),
    )
    # Index de payload : le filtre par service doit être rapide ; is_tenant optimise le stockage par locataire
    q.create_payload_index(COLLECTION, "tenant_id",
                           field_schema=models.KeywordIndexParams(type="keyword", is_tenant=True))
    for champ in ("doc_id", "client_id", "categorie"):
        q.create_payload_index(COLLECTION, champ, field_schema=models.PayloadSchemaType.KEYWORD)

# Upsert idempotent par lots : l'id Qdrant est dérivé du chunk_id (même chunk -> même point)
for lot in pads.dataset("corpus/embeddings/").to_batches(batch_size=512):
    t = lot.to_pydict()
    q.upsert(COLLECTION, points=[
        models.PointStruct(
            id=str(uuid.UUID(hex=t["chunk_id"][i])),
            vector=t["vecteur"][i],
            payload={k: t[k][i] for k in ("doc_id", "tenant_id", "client_id", "section", "source", "texte", "modele_v")},
        ) for i in range(lot.num_rows)])

# L'application interroge toujours l'ALIAS, jamais la collection
q.update_collection_aliases(change_aliases_operations=[
    models.CreateAliasOperation(create_alias=models.CreateAlias(collection_name=COLLECTION, alias_name=ALIAS))])

def rechercher(vecteur, service: str, k: int = 5):
    """Filtre obligatoire : un service ne voit jamais les chunks d'un autre."""
    return q.query_points(ALIAS, query=vecteur, limit=k,
                          query_filter=models.Filter(must=[models.FieldCondition(
                              key="tenant_id", match=models.MatchValue(value=service))])).points
```

> 🧭 **Pré-requis express** — Le niveau ne déclare pas de Qdrant dans ses fichiers Compose : démarrez-en un (si ce n'est pas déjà fait en L174) avec `docker run -d --name breval-qdrant -p 6333:6333 -v qdrant_data:/qdrant/storage qdrant/qdrant`. Le **payload** est la fiche de métadonnées attachée à chaque vecteur ; un **alias** est un second nom qui pointe vers une collection et que l'on peut rediriger instantanément.

> 🔍 **Ce que vous devez voir** — aucun affichage. Ouvrez `http://localhost:6333/dashboard` : la collection `chunks_bge_m3_v1` apparaît avec un nombre de points égal au nombre de lignes de `corpus/embeddings/`, et l'onglet *Aliases* (ou `curl http://localhost:6333/aliases`) montre `chunks → chunks_bge_m3_v1`. Relancer le script ne change pas le nombre de points : l'upsert est idempotent.

> 🛠️ **Si ça ne marche pas** — « Connection refused » sur 6333 → Qdrant n'est pas démarré. « Wrong input: Vector dimension error: expected dim: 1024, got 384 » → vous avez changé de modèle d'embedding sans adapter `size=1024`. « ValueError: badly formed hexadecimal UUID string » → les `chunk_id` ne font pas 32 caractères hexadécimaux (le `[:32]` de `chunker.py` a été modifié).

Trois opérations d'exploitation à connaître :

- **Suppressions** : quand un document est supprimé ou modifié à la source, la CDC (Debezium → Kafka, M34) émet un événement ; l'indexeur supprime les points par filtre `doc_id` (comme pour l'effacement RGPD en L174) puis insère les nouveaux chunks. Un document modifié = suppression de ses anciens chunks + upsert des nouveaux.
- **Changement de modèle** : construire `chunks_<nouveau_modele>_v1` en parallèle, l'évaluer, puis **basculer l'alias** en une opération atomique ; l'ancienne collection est gardée quelques jours pour un retour arrière. C'est le déploiement *blue/green* appliqué aux index. (deux environnements, « bleu » en service et « vert » en préparation : on bascule de l'un à l'autre d'un coup, et on peut revenir en arrière aussi vite)
- **Sauvegarde** : snapshots de collection planifiés, et surtout la capacité à **reconstruire** l'index depuis les Parquet d'embeddings versionnés (L179) — la vraie sauvegarde, c'est la reproductibilité.

### 5.2 pgvector : les équivalents en SQL

```sql
-- pgvector (vérifiez dans le README les fonctionnalités disponibles pour votre version)
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE chunks (
  chunk_id TEXT PRIMARY KEY, doc_id TEXT NOT NULL, tenant_id TEXT NOT NULL,
  client_id TEXT, texte TEXT, modele_v TEXT NOT NULL,
  embedding halfvec(1024)                       -- demi-précision : mémoire divisée par 2
);
CREATE INDEX ON chunks USING hnsw (embedding halfvec_cosine_ops) WITH (m = 16, ef_construction = 64);
CREATE INDEX ON chunks (tenant_id);

-- Upsert idempotent
INSERT INTO chunks VALUES ($1, $2, $3, $4, $5, $6, $7)
ON CONFLICT (chunk_id) DO UPDATE SET embedding = EXCLUDED.embedding, modele_v = EXCLUDED.modele_v;

-- Recherche filtrée : avec un filtre sélectif, l'index peut renvoyer trop peu de résultats ;
-- les versions récentes proposent des parcours itératifs (hnsw.iterative_scan) pour compenser.
SET hnsw.iterative_scan = relaxed_order;
SELECT chunk_id, texte FROM chunks
WHERE tenant_id = 'sav'
ORDER BY embedding <=> $1::halfvec LIMIT 5;
```

> 🧭 **Pré-requis express** — Ce bloc est **à lire** ou à adapter : les `$1`, `$2`… sont des **paramètres** remplis par votre programme (par exemple avec `psycopg`), ils ne s'exécutent pas tels quels dans `psql`. De plus, l'image `postgres:17` de L151 ne contient pas pgvector : `CREATE EXTENSION vector` y échoue avec « extension "vector" is not available ». Pour essayer, utilisez l'image `pgvector/pgvector:pg17` dans un conteneur séparé. `halfvec` stocke chaque dimension sur 2 octets au lieu de 4 ; `m` et `ef_construction` règlent la densité et le soin de construction du graphe HNSW (plus grand = meilleur rappel, plus de mémoire et de temps) ; `<=>` est l'opérateur de distance cosinus de pgvector.

> ⚠️ **Piège fréquent** — Le **post-filtrage** naïf : chercher les 5 plus proches voisins, *puis* filtrer par service. Si le service « juridique » ne représente que 1 % des chunks, vous obtenez souvent 0 résultat. Utilisez le filtrage intégré à la recherche (index de payload Qdrant, parcours itératif pgvector, partitions Milvus) ou, pour quelques gros locataires, une collection ou une partition **par locataire**.

```quiz
{
  "type": "vrai_faux",
  "q": "Pour changer de modèle d'embedding sans coupure, on peut ré-encoder les vecteurs en place dans la collection servie, lot par lot, pendant que l'assistant répond.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : pendant la migration, la collection contiendrait des vecteurs de deux modèles incompatibles et les résultats seraient faux. On construit une nouvelle collection, on l'évalue, puis on bascule l'alias de façon atomique."
}
```

## 6. 🎮 Défi : le devis

Une ETI cliente veut indexer 2 millions de pages (≈ 6 chunks par page, 1 024 dimensions), avec 30 services cloisonnés et un changement de modèle prévu par an. Estimez en 5 minutes : nombre de chunks, mémoire float32 et int8, coût d'une indexation complète à 0,10 $/M tokens (300 tokens par chunk), et l'architecture de multi-tenance. *Corrigé : 12 M chunks ; ≈ 49 Go float32, ≈ 12 Go int8 (+ graphe ~1,5 Go) ; 3,6 milliards de tokens ≈ 360 $ par indexation complète ; une collection unique avec `tenant_id` indexé (30 services, aucun très dominant), filtres obligatoires côté API, ré-indexation annuelle par alias.*

## 🧪 Exercice pratique

**Consigne** : sur le corpus de la PME (L175-L177), (1) produisez deux configurations de chunking (`struct-md-v2-max350` et `fixe-max600-rec100`) ; (2) calculez les embeddings par lots avec Ray Data **de façon incrémentale** (relancez : zéro calcul la seconde fois) ; (3) chargez chaque version dans une collection Qdrant derrière l'alias `chunks` ; (4) mesurez recall@5 et MRR sur 20 questions (méthode de L093) et basculez l'alias vers la meilleure ; (5) supprimez un document à la source et montrez que ses chunks disparaissent.

**Critères de réussite** : la seconde exécution annonce 0 chunk à calculer ; le tableau de métriques justifie le choix de chunking ; la bascule d'alias n'interrompt pas un script de requêtes qui tourne en boucle ; une requête filtrée sur le service « sav » ne renvoie aucun chunk d'un autre service ; aucune trace du document supprimé après traitement.

**Pistes de corrigé** : l'anti-jointure doit porter sur `(chunk_id, modele_v)` ; pour la bascule, utilisez `update_collection_aliases` avec une opération de suppression de l'ancien alias et de création du nouveau dans le **même** appel ; pour la suppression, `q.delete(..., points_selector=models.FilterSelector(filter=...doc_id...))`. Sur de petits documents structurés (procédures, FAQ), le découpage par structure l'emporte généralement ; sur des CGV longues, la fenêtre fixe avec recouvrement peut être compétitive : c'est la mesure qui tranche.

## ✅ Auto-évaluation express
1. Que doit contenir un `chunk_id` pour garantir l'idempotence et la traçabilité ?
2. Quand faut-il ré-indexer tout le corpus ?
3. Pourquoi le post-filtrage est-il dangereux pour les petits locataires ?

**Réponses** : 1. Un hachage déterministe du document, de la version de chunking, de la position et du texte. 2. Lors d'un changement de modèle d'embedding (ou de configuration de chunking), dans une nouvelle collection basculée par alias. 3. Les k plus proches voisins globaux appartiennent rarement au petit locataire : après filtrage, il ne reste presque rien ; il faut filtrer pendant la recherche ou isoler le locataire.

## 📚 Pour aller plus loin
- [Ray — Working with LLMs](https://docs.ray.io/en/latest/data/working-with-llms.html) 🇬🇧 — inférence LLM et embeddings par lots.
- [Ray — Offline batch inference](https://docs.ray.io/en/latest/data/batch_inference.html) 🇬🇧 — `map_batches`, acteurs, GPU.
- [Qdrant — documentation](https://qdrant.tech/documentation/) 🇬🇧 — quantification, multi-tenance, alias, snapshots.
- [pgvector](https://github.com/pgvector/pgvector) 🇬🇧 — HNSW, IVFFlat, halfvec, parcours itératifs.
- [Milvus — documentation](https://milvus.io/docs) 🇬🇧 — index IVF/PQ, partitions, très grands volumes.
- [PySpark — Getting Started](https://spark.apache.org/docs/latest/api/python/getting_started/) 🇬🇧 — UDF pandas et traitement distribué.
- [Feast — documentation](https://docs.feast.dev/llms.txt) 🇬🇧 — Feast propose aussi des *online stores* vectoriels pour le RAG (fonction en alpha), transition vers la leçon suivante.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un chunk de production a une configuration versionnée (`chunking_v`), un identifiant déterministe (`chunk_id` = hachage du document, de la version, de la position et du texte) et des métadonnées pour citer, filtrer (`tenant_id`) et effacer (`client_id`, `doc_id`). 2. On ne vectorise que ce qui manque (anti-jointure sur `chunk_id` + `modele_v`), par lots parallèles (Ray Data ou UDF pandas Spark) ; on ne mélange jamais deux modèles dans un index, et un changement de modèle se fait dans une nouvelle collection basculée par alias. 3. La mémoire se calcule (N × d × octets) : pgvector suffit pour une PME, la quantification (int8, binaire) devient le levier au-delà de quelques millions de vecteurs ; le filtre par locataire se fait **pendant** la recherche, jamais après.

> 🗺️ **Et maintenant ?** — Vos données sont prêtes pour le RAG ; la leçon L179 traite l'autre versant de l'IA : les features pour le machine learning, le versionnement de tous ces jeux de données et la génération de données synthétiques.
