---
id: L162
module: M33
level: N5
title: "Ingestion incrémentale : Airbyte, Fivetran, dlt et capture de changements (CDC) avec Debezium"
minutes: 50
objectives:
  - "Comparer chargement complet, incrémental par curseur et capture de changements (CDC) selon la fraîcheur, la charge sur la source et la détection des suppressions"
  - "Choisir entre Airbyte, Fivetran, dlt et Debezium pour un besoin d'ingestion donné"
  - "Construire une ingestion incrémentale Postgres → DuckDB avec dlt (curseur mis_a_jour_le, fusion sur clé primaire) et charger le fichier JSONL des tickets SAV"
  - "Expliquer le principe du CDC par lecture du journal de transactions (WAL) avec Debezium"
skills: ["C5.2"]
sources:
  - { title: "dlt (dltHub) — documentation", url: "https://dlthub.com/docs", lang: "en" }
  - { title: "dltHub — source Airbyte", url: "https://dlthub.com/context/source/airbyte", lang: "en" }
  - { title: "Airbyte — documentation", url: "https://docs.airbyte.com/", lang: "en" }
  - { title: "Fivetran — documentation", url: "https://fivetran.com/docs", lang: "en" }
  - { title: "Debezium — documentation", url: "https://debezium.io/documentation/", lang: "en" }
  - { title: "Debezium — exemples officiels (wiki)", url: "https://github.com/debezium/debezium-examples/wiki", lang: "en" }
  - { title: "DataTalksClub — Data Engineering Zoomcamp (workshop dlt)", url: "https://github.com/datatalksclub/data-engineering-zoomcamp", lang: "en" }
---

# Ingestion incrémentale : Airbyte, Fivetran, dlt et capture de changements (CDC) avec Debezium

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 33

## 🎯 Ce que vous saurez faire
- Choisir entre trois façons de copier une base : tout recopier, copier « ce qui a changé depuis hier » (curseur), ou écouter chaque modification en direct (CDC).
- Positionner Airbyte, Fivetran, dlt et Debezium sur une carte « code / sans code », « auto-hébergé / SaaS », « lot / flux ».
- Ingérer de façon incrémentale l'ERP Postgres de **Bréval Matériaux** (monté en L151-L152) et le fichier de tickets SAV dans DuckDB avec **dlt**, en relançant sans doublon.
- Expliquer pourquoi un curseur `mis_a_jour_le` ne voit **jamais** les suppressions, et comment le CDC règle ce problème.

> 🧭 **En clair** — Pour tenir à jour la copie d'un carnet d'adresses, vous pouvez le photocopier en entier chaque soir (chargement complet), recopier seulement les pages marquées « modifié aujourd'hui » (incrémental par curseur), ou demander à la secrétaire de vous dicter chaque rature au moment où elle la fait (capture de changements, ou CDC). La photocopie est simple mais lente ; les pages marquées sont rapides mais ne vous disent pas quelles fiches ont été arrachées ; la dictée voit tout, y compris les suppressions, mais demande plus d'organisation.

## 1. Trois stratégies d'ingestion

| Stratégie | Principe | Fraîcheur | Charge sur la source | Voit les suppressions ? | Quand l'utiliser |
|---|---|---|---|---|---|
| **Complet** (*full refresh*) | `SELECT *` à chaque fois, on remplace la copie | celle du lot | forte (tout est relu) | oui, implicitement | petites tables de référence (< quelques centaines de milliers de lignes) |
| **Incrémental par curseur** | `WHERE mis_a_jour_le > dernier_curseur` | celle du lot (heure, jour) | faible | **non** | tables volumineuses avec colonne de mise à jour fiable |
| **CDC par journal** (*log-based change data capture*) | lecture du journal de transactions (WAL Postgres, binlog MySQL) | quasi temps réel (secondes) | très faible (pas de requête sur les tables) | **oui** (événement `delete`) | tables critiques, suppressions à propager (RAG !), besoin de fraîcheur |

Le **curseur** est une valeur mémorisée entre deux exécutions : « la plus grande date `mis_a_jour_le` déjà vue ». L'outil d'ingestion la stocke dans son **état** (*state*) et ne demande ensuite que les lignes plus récentes.

> 💡 **Autrement dit** — Le curseur, c'est le marque-page : « j'en étais là ». Le CDC, c'est l'abonnement aux notifications : « prévenez-moi de chaque changement ».

> ⚠️ **Piège fréquent** — Un curseur sur `mis_a_jour_le` suppose que **toute** modification met à jour cette colonne. Si un script de maintenance fait un `UPDATE` sans la toucher (ou s'il n'y a pas de déclencheur), la modification est invisible pour toujours. Le schéma ERP de Bréval (L151) **n'a pas** de déclencheur : vous allez l'ajouter en section 3.

```quiz
{
  "q": "Chez Bréval, l'agence d'Ancenis supprime de l'ERP des commandes saisies par erreur. Votre ingestion incrémentale par curseur sur mis_a_jour_le tourne chaque nuit. Que se passe-t-il dans votre copie ?",
  "options": [
    "Les commandes supprimées disparaissent aussi de la copie la nuit suivante",
    "L'ingestion échoue avec une erreur de clé",
    "Elles restent indéfiniment dans la copie : rien ne signale la suppression",
    "La copie est entièrement vidée"
  ],
  "answer": 2,
  "explanation": "Un curseur ne lit que des lignes existantes plus récentes que le marque-page. Une ligne supprimée n'existe plus, donc rien ne le signale. Il faut un CDC (événement delete), une suppression logique (colonne supprime_le) ou un rechargement complet périodique."
}
```

## 2. Le paysage des outils (nov. 2026)

| Outil | Nature | Modèle | Points forts | Limites |
|---|---|---|---|---|
| **Airbyte** | plateforme ELT open source | interface web + connecteurs ; auto-hébergeable (Docker / Kubernetes) | des centaines de connecteurs prêts, modes complet / incrémental / CDC | une plateforme à exploiter (mises à jour, ressources) |
| **Fivetran** | ELT **SaaS managé** (*Software as a Service* : un logiciel loué en ligne, rien à installer) | configuration en clics, tarification à l'usage | référence du marché, quasi zéro maintenance | payant, données transitant par un tiers (à évaluer avec votre DPO) — le DPO (*Data Protection Officer*) est le délégué à la protection des données de l'entreprise |
| **dlt** (dltHub) | **bibliothèque Python** | du code : `pipeline.run(source)` | schéma inféré et évolutif, état incrémental intégré, destinations DuckDB / Postgres / entrepôts, idéal pédagogie et CI (intégration continue : tests automatiques à chaque modification du code, L165) | moins de connecteurs « clés en main » ; c'est vous qui codez |
| **Debezium** | **CDC** open source | connecteurs Kafka Connect qui lisent les journaux de transactions (Kafka Connect est le module de Kafka qui branche des sources et des destinations ; Kafka est présenté en L167) | suppressions, ordre des changements, faible charge | nécessite Kafka (ou Debezium Server) ; à exploiter en continu |

La règle de choix tient en trois questions : **Avez-vous une équipe pour exploiter une plateforme ?** (non → Fivetran ou dlt) **Les données peuvent-elles quitter votre infrastructure ?** (non → Airbyte auto-hébergé, dlt ou Debezium) **Avez-vous besoin des suppressions et de la fraîcheur à la minute ?** (oui → Debezium). Les outils se combinent : dlt peut par exemple réutiliser des sources Airbyte (voir la page [dltHub — Airbyte source](https://dlthub.com/context/source/airbyte)).

Le Data Engineering Zoomcamp de DataTalksClub consacre d'ailleurs son *Workshop 1* à l'ingestion avec dlt : c'est l'outil que nous utilisons en TP, gratuit et local.

```quiz
{
  "q": "Un cabinet comptable de 12 personnes, sans data engineer, veut copier chaque nuit les données de son logiciel de gestion SaaS vers un entrepôt. Les données peuvent être traitées par un sous-traitant européen sous contrat. Quel outil est le plus adapté ?",
  "options": [
    "Debezium sur un cluster Kafka auto-hébergé, pour la fraîcheur",
    "Un outil ELT managé de type Fivetran, s'il propose le connecteur",
    "Un script Bash avec cron et pg_dump",
    "Aucun outil : un export CSV manuel chaque soir"
  ],
  "answer": 1,
  "explanation": "Sans équipe pour exploiter une plateforme et avec un besoin nocturne, un service managé est le plus raisonnable. Debezium exige Kafka et une exploitation continue ; les solutions manuelles ne sont ni fiables ni rejouables."
}
```

## 3. TP : préparer l'ERP de Bréval pour l'incrémental

Vous repartez du dossier `breval/` construit en M31 : le conteneur `breval-postgres` (L151, déjà lancé avec `wal_level=logical`), le schéma `erp.*` et ses données chargées en L152 (120 000 commandes, 5 075 clients), et le fichier `data/raw/sav/tickets_sav.jsonl` exporté par l'outil SAV. Rien n'est à recréer.

Il manque une seule chose pour un curseur fiable : l'ERP ne met pas `mis_a_jour_le` à jour tout seul. Ajoutez un déclencheur (*trigger* : petit programme stocké dans la base, exécuté automatiquement à chaque `UPDATE` ; `plpgsql` est le langage de ces programmes dans Postgres) (les scripts de `sql/` ne s'exécutent qu'au premier démarrage, on l'applique donc à la main) :

```sql
-- breval/sql/02_trigger_mis_a_jour.sql — toute modification met à jour mis_a_jour_le (heure de Paris, sans fuseau, comme l'ERP)
CREATE OR REPLACE FUNCTION erp.maj_horodatage() RETURNS trigger AS $$
BEGIN
  NEW.mis_a_jour_le := (now() AT TIME ZONE 'Europe/Paris');
  RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trg_commandes_maj BEFORE UPDATE ON erp.commandes
  FOR EACH ROW EXECUTE FUNCTION erp.maj_horodatage();
CREATE OR REPLACE TRIGGER trg_clients_maj BEFORE UPDATE ON erp.clients
  FOR EACH ROW EXECUTE FUNCTION erp.maj_horodatage();
```

```bash
cd breval
docker exec -i breval-postgres psql -U breval -d breval < sql/02_trigger_mis_a_jour.sql
docker exec -it breval-postgres psql -U breval -d breval -c "SELECT statut, count(*) FROM erp.commandes GROUP BY 1 ORDER BY 2 DESC;"
```

> 🧭 **Pré-requis express** — Enregistrez d'abord le bloc SQL sous `breval/sql/02_trigger_mis_a_jour.sql`. Le conteneur doit tourner (`docker ps` doit lister `breval-postgres` ; sinon `docker compose up -d` depuis `breval/`). Si vous êtes déjà dans `breval/`, sautez la ligne `cd breval`.

> 🔍 **Ce que vous devez voir** — la première commande affiche trois lignes, `CREATE FUNCTION`, `CREATE TRIGGER`, `CREATE TRIGGER`. La seconde affiche un tableau `statut | count` de cinq lignes, une par statut (`brouillon`, `validee`, `livree`, `facturee`, `annulee`), triées du plus fréquent au moins fréquent, dont la somme fait **120000**.

> 🛠️ **Si ça ne marche pas** — « ERROR: relation "erp.commandes" does not exist » → les tables n'ont pas été créées ou remplies (L151-L152). « No such container » → conteneur arrêté ou renommé. Sous PowerShell, la redirection `<` n'existe pas : utilisez `Get-Content sql/02_trigger_mis_a_jour.sql | docker exec -i breval-postgres psql -U breval -d breval`.

| Source Bréval | Volume (échelle 1) | Stratégie retenue | Pourquoi |
|---|---|---|---|
| `erp.agences`, `erp.fournisseurs`, `erp.produits` | 3, 60, 1 200 lignes | complet (`replace`) | petites tables de référence |
| `erp.clients` | 5 075 | curseur `mis_a_jour_le` + fusion sur `client_id` | modifiées de temps en temps |
| `erp.commandes` | 120 000 | curseur `mis_a_jour_le` + fusion sur `commande_id` | volumineuse, statuts qui évoluent |
| `erp.lignes_commande` | 335 000 environ | curseur `ligne_id` (croissant) + fusion | ajout seulement, pas de colonne de mise à jour |
| `tickets_sav.jsonl` (outil SaaS) | 9 048 | relecture du fichier + fusion sur `ticket_id` | export complet fourni chaque heure ; les tickets changent de statut |

## 4. Ingestion incrémentale avec dlt

dlt (*data load tool*) transforme une source en tables, infère le schéma (*inférer* = deviner automatiquement les colonnes et leurs types à partir des données), et mémorise le curseur entre deux exécutions dans l'état du pipeline. Trois dispositions d'écriture (*write dispositions*) existent : `append` (ajout), `replace` (remplacement complet) et `merge` (fusion sur clé : c'est notre upsert idempotent de L161).

```bash
source .venv/bin/activate                                 # environnement de L151
pip install "dlt[duckdb,sql_database]" psycopg2-binary   # versions récentes : à vérifier sur dlthub.com/docs
export BREVAL_PG_URL="postgresql://breval:breval_local@localhost:5432/breval"
```

> 🧭 **Pré-requis express** — Une **variable d'environnement** (`export NOM=valeur`) est une valeur que le terminal transmet aux programmes lancés ensuite ; elle disparaît quand vous fermez le terminal : refaites l'`export` à chaque nouvelle session. Sous PowerShell : `$env:BREVAL_PG_URL="postgresql://…"`. L'URL se lit `postgresql://utilisateur:motdepasse@machine:port/base` : adaptez le mot de passe ou le port (5433) si vous les avez changés en L151. Créez aussi le dossier du script : `mkdir -p ingestion`.

```python
# breval/ingestion/ingest.py — ERP Postgres + tickets JSONL → DuckDB (schéma « bronze »), incrémental et idempotent
import json
import os
from pathlib import Path

import dlt
from dlt.sources.sql_database import sql_table

PG_URL = os.environ["BREVAL_PG_URL"]
DUCKDB_PATH = os.environ.get("BREVAL_DUCKDB_PATH", "data/breval.duckdb")   # entrepôt des ateliers M31 ; dlt y ajoute le schéma bronze
TICKETS = Path(os.environ.get("BREVAL_TICKETS", "data/raw/sav/tickets_sav.jsonl"))

def tables_erp():
    # Petites tables de référence : rechargement complet (voit aussi les suppressions)
    for nom in ("agences", "fournisseurs", "produits"):
        t = sql_table(credentials=PG_URL, schema="erp", table=nom)
        t.apply_hints(write_disposition="replace")
        yield t

    # Tables modifiables : curseur sur mis_a_jour_le + fusion sur la clé primaire
    for nom, cle in (("clients", "client_id"), ("commandes", "commande_id")):
        t = sql_table(credentials=PG_URL, schema="erp", table=nom,
                      incremental=dlt.sources.incremental("mis_a_jour_le"))
        t.apply_hints(write_disposition="merge", primary_key=cle)
        yield t

    # Lignes : jamais modifiées, identifiant croissant → curseur sur ligne_id
    t = sql_table(credentials=PG_URL, schema="erp", table="lignes_commande",
                  incremental=dlt.sources.incremental("ligne_id"))
    t.apply_hints(write_disposition="merge", primary_key="ligne_id")
    yield t

@dlt.resource(name="tickets_sav", write_disposition="merge", primary_key="ticket_id")
def tickets_sav():
    """Export JSONL de l'outil SAV : un ticket par ligne, champs imbriqués (messages, tags, agent)."""
    with TICKETS.open(encoding="utf-8") as f:
        for ligne in f:
            yield json.loads(ligne)

def main() -> None:
    pipeline = dlt.pipeline(
        pipeline_name="breval_ingestion",
        destination=dlt.destinations.duckdb(DUCKDB_PATH),
        dataset_name="bronze",
    )
    info = pipeline.run([*tables_erp(), tickets_sav()])
    print(info)
    print(pipeline.last_trace.last_normalize_info)   # nombre de lignes chargées par table à cette exécution

if __name__ == "__main__":
    main()
```

Lancez `python ingestion/ingest.py` deux fois.

> 🧭 **Pré-requis express** — Une **ressource** dlt (`@dlt.resource`) est une fonction Python qui produit des lignes avec `yield` (une à une, sans tout charger en mémoire) ; `sql_table` fabrique une ressource à partir d'une table Postgres. Lancez le script depuis `breval/`, dans le terminal où vous avez fait l'`export`.

> 🔍 **Ce que vous devez voir** — la première exécution prend quelques dizaines de secondes et se termine par un résumé du type `Pipeline breval_ingestion load step completed in 4.21 seconds` / `1 load package(s) were loaded to destination duckdb and into dataset bronze`, suivi d'un bloc `Normalized data for the following tables:` listant les lignes par table (`- commandes: 120000 row(s)`, `- clients: 5075 row(s)`, `- lignes_commande: …`, `- tickets_sav: 9048 row(s)`, `- tickets_sav__messages: …`). À la seconde exécution, les tables incrémentales affichent `0` (ou une poignée de lignes relues par sécurité).

> 🛠️ **Si ça ne marche pas** — « KeyError: 'BREVAL_PG_URL' » → l'`export` n'a pas été fait dans ce terminal. « connection to server at "localhost" … port 5432 failed: Connection refused » → Postgres arrêté, ou port changé en 5433. « password authentication failed » → mot de passe différent de `breval_local` (voir `.env`). « Could not set lock on file "data/breval.duckdb" » → un client `duckdb` ou un script de M31 a encore ce fichier ouvert. « ModuleNotFoundError: No module named 'psycopg2' » → relancez la ligne `pip install` dans la venv activée. La première exécution charge les 120 000 commandes ; la seconde n'en charge **aucune**, ou seulement celles dont `mis_a_jour_le` égale le dernier curseur (dlt les relit par sécurité et la fusion sur `commande_id` évite le doublon). Observez aussi les tickets : dlt **normalise** les champs imbriqués, `messages` et `tags` deviennent des tables enfants (`bronze.tickets_sav__messages`, `bronze.tickets_sav__tags`) et l'objet `agent`, apparu en juin 2025 (L151), devient des colonnes `agent__…` ajoutées sans intervention : c'est l'**évolution de schéma** automatique. Modifiez ensuite une commande :

```bash
docker exec -it breval-postgres psql -U breval -d breval -c "UPDATE erp.commandes SET statut='livree' WHERE commande_id=42;"
python ingestion/ingest.py
python -c "import duckdb; print(duckdb.connect('data/breval.duckdb').sql('SELECT commande_id, statut, mis_a_jour_le FROM bronze.commandes WHERE commande_id=42'))"
```

> 🔍 **Ce que vous devez voir** — `UPDATE 1` après la commande `psql` ; puis, après la nouvelle ingestion, un tableau d'**une seule ligne** pour la commande 42, au statut `livree`, avec un `mis_a_jour_le` égal à l'heure où vous avez lancé l'`UPDATE`. Deux lignes pour la commande 42 signaleraient une fusion mal configurée (clé primaire absente).

La commande 42 est mise à jour, sans doublon, grâce au déclencheur qui a fait avancer `mis_a_jour_le`. dlt ajoute aussi des colonnes techniques (`_dlt_load_id`, `_dlt_id`) qui tracent le chargement d'origine de chaque ligne : précieux pour la rejouabilité.

> 💡 **Autrement dit** — En L152, le bronze était une **photo** des exports CSV. Ici, le bronze devient un **miroir tenu à jour** : chaque exécution n'apporte que les différences.

> ⚠️ **Piège fréquent** — Les transactions longues. Une transaction ouverte à 23 h 59 et validée à 0 h 02 peut écrire un `mis_a_jour_le` **antérieur** au curseur déjà enregistré par une ingestion lancée à 0 h 00 : la ligne est sautée. Parades : relire une marge de recouvrement (par exemple les 10 dernières minutes) en comptant sur la fusion pour dédoublonner, ou passer au CDC.

> 🔗 **Documentation officielle** — [dlt — documentation](https://dlthub.com/docs) 🇬🇧 : chargement incrémental, dispositions d'écriture, source `sql_database`.

```mission
{
  "title": "Les dispositions d'écriture de dlt",
  "url": "https://dlthub.com/docs",
  "steps": ["Ouvrez la documentation de dlt", "Cherchez la page consacrée au chargement incrémental (incremental loading)", "Repérez la liste des write dispositions"],
  "question": "Quelles sont les trois dispositions d'écriture proposées par dlt, et laquelle exige une clé primaire ou une clé de fusion ?",
  "hint": "L'une d'elles correspond à l'upsert vu en L161.",
  "answer": "append, replace et merge ; merge s'appuie sur primary_key ou merge_key pour mettre à jour les lignes existantes (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 5. La capture de changements avec Debezium

Toute base relationnelle tient un **journal de transactions** pour pouvoir se réparer après une panne : le WAL (*write-ahead log*) dans Postgres, le binlog dans MySQL. Chaque insertion, mise à jour ou suppression y est écrite **avant** d'être appliquée. Le CDC « par journal » consiste à lire ce journal et à le transformer en **événements**.

```
Postgres ──(WAL, décodage logique pgoutput)──▶ Debezium (Kafka Connect) ──▶ topic Kafka breval.erp.commandes
                                                                              │  {op: "u", before: {...}, after: {...}, ts_ms}
                                                                              ▼
                                                                    consommateurs : bronze, index RAG…
```

Chaque événement Debezium contient l'opération (`c` création, `u` mise à jour, `d` suppression, `r` lecture initiale), l'état **avant** et **après**, et l'horodatage de la transaction. Trois prérequis côté Postgres : `wal_level=logical` (déjà dans notre `docker-compose.yml`), un **slot de réplication** (Debezium le crée) et une **publication** des tables suivies. Un **slot** est un « marque-page » que Postgres tient pour un lecteur du WAL (il garde le journal tant que ce lecteur ne l'a pas lu) ; une **publication** est la liste des tables dont on diffuse les changements. Le *topic* Kafka du schéma est une file de messages nommée (L167).

Pourquoi c'est crucial pour l'IA : quand un document ou une commande est supprimé à la source, l'événement `d` permet de supprimer les chunks correspondants dans l'index vectoriel. Sans cela, votre RAG continue de citer un document qui n'existe plus. C'est le scénario de « suppression propagée » du projet final (M37).

> ⚠️ **Piège fréquent** — Un slot de réplication que plus personne ne lit **retient le WAL** : le disque de la base de production se remplit. Surveillez `pg_replication_slots` et supprimez les slots abandonnés. Nous le mettrons en pratique dans l'atelier L169.

> 💡 **À retenir** — Curseur = simple, par lots, aveugle aux suppressions. CDC = flux d'événements ordonnés, suppressions comprises, mais une infrastructure de plus (Kafka) à exploiter. Le module M34 monte la chaîne complète Postgres → Debezium → Kafka → lakehouse.

```mission
{
  "title": "Le plugin de décodage logique du connecteur Postgres",
  "url": "https://debezium.io/documentation/",
  "steps": ["Ouvrez la documentation de Debezium", "Allez dans la référence des connecteurs, puis le connecteur PostgreSQL", "Cherchez la propriété plugin.name"],
  "question": "Quel plugin de décodage logique, intégré nativement à Postgres depuis la version 10, Debezium recommande-t-il ?",
  "hint": "Son nom commence par « pg » et ne nécessite aucune installation supplémentaire.",
  "answer": "pgoutput, le plug-in de décodage logique standard de PostgreSQL 10+, toujours présent (aucune bibliothèque à installer) ; il se déclare dans plugin.name, dont la valeur par défaut reste decoderbufs dans la version communautaire (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne** : prouvez par trois expériences les forces et faiblesses de votre ingestion dlt.
1. **Idempotence** : lancez `ingest.py` trois fois sans rien changer ; comparez `SELECT count(*), count(DISTINCT commande_id) FROM bronze.commandes` (et la même chose pour `bronze.tickets_sav` avec `ticket_id`).
2. **Mise à jour** : passez 10 commandes `validee` au statut `livree` dans l'ERP ; relancez ; vérifiez que les 10 sont à jour et que le nombre total n'a pas bougé.
3. **Suppression** : supprimez 5 commandes saisies par erreur, lignes comprises (`BEGIN; DELETE FROM erp.lignes_commande WHERE commande_id <= 5; DELETE FROM erp.commandes WHERE commande_id <= 5; COMMIT;`) ; relancez ; constatez qu'elles sont toujours dans `bronze.commandes` et `bronze.lignes_commande`. Proposez deux corrections.

**Critères de réussite** : `count(*) = count(DISTINCT commande_id)` après chaque exécution ; le tableau de résultats des trois expériences est rédigé ; deux corrections argumentées pour l'expérience 3.

**Corrigé (pistes)** : pour l'expérience 3, (a) une suppression logique côté ERP (colonne `supprimee_le`, mise à jour par l'application, donc suivie par le curseur), ou un rechargement complet hebdomadaire de contrôle qui repère les clés disparues ; (b) à terme, le CDC Debezium, qui émet un événement `d` pour chaque suppression : c'est l'atelier L169. Un `replace` complet de `erp.commandes` à chaque exécution fonctionnerait aussi à l'échelle 1, mais perdrait tout l'intérêt de l'incrémental à l'échelle 10 (1,2 million de commandes).

## ✅ Auto-évaluation express
1. Quelle stratégie d'ingestion détecte les suppressions sans requêter les tables ?
2. Que mémorise l'état (*state*) d'un pipeline dlt incrémental ?
3. Quel réglage Postgres est indispensable au CDC Debezium ?

**Réponses** : 1. Le CDC par lecture du journal de transactions (Debezium). 2. La dernière valeur du curseur (par exemple le plus grand `mis_a_jour_le` chargé). 3. `wal_level=logical` (plus un slot de réplication et une publication).

## 📚 Pour aller plus loin
- [dlt — documentation](https://dlthub.com/docs) 🇬🇧 — sources, incrémental, destinations.
- [Airbyte — documentation](https://docs.airbyte.com/) 🇬🇧 — déploiement auto-hébergé et catalogue de connecteurs.
- [Fivetran — documentation](https://fivetran.com/docs) 🇬🇧 — modèle managé et connecteurs.
- [Debezium — documentation](https://debezium.io/documentation/) 🇬🇧 et [exemples officiels](https://github.com/debezium/debezium-examples/wiki) 🇬🇧 — tous les connecteurs CDC.
- Rappel N3 : la leçon L090 (M20) traitait l'ingestion **documentaire** incrémentale d'un RAG ; ici, on industrialise l'ingestion de la base métier.

> ✅ **Si vous ne retenez que 3 choses** — 1. Trois stratégies : complet (simple, voit les suppressions, coûteux), incrémental par curseur (rapide, mais aveugle aux suppressions et aux mises à jour qui ne touchent pas la colonne curseur), CDC par journal (quasi temps réel, suppressions comprises, mais Kafka à exploiter). 2. dlt mémorise le curseur dans son état et, en disposition `merge` avec une clé primaire, rend l'ingestion rejouable sans doublon ; il fait évoluer le schéma automatiquement (tables enfants pour les listes imbriquées). 3. Un curseur n'est fiable que si **toute** modification met à jour la colonne (d'où le déclencheur) ; prévoyez une marge de recouvrement pour les transactions longues.

> 🗺️ **Et maintenant ?** — Vos données brutes arrivent proprement en bronze ; la leçon L163 les transforme en silver et gold avec dbt Core, tests et lignage compris.
