---
id: L161
module: M33
level: N5
title: "ETL ou ELT : architectures, couches bronze/silver/gold, idempotence et rejouabilité"
minutes: 35
objectives:
  - "Distinguer ETL et ELT et justifier un schéma hybride quand des données personnelles doivent être traitées avant chargement"
  - "Expliquer le rôle des couches bronze, silver et gold d'une architecture médaillon"
  - "Démontrer qu'un chargement est idempotent en le rejouant deux fois sans créer de doublon"
  - "Concevoir un pipeline rejouable à partir d'une couche bronze immuable"
skills: ["C5.2"]
sources:
  - { title: "O'Reilly — Fundamentals of Data Engineering (Reis & Housley, 2022)", url: "https://oreilly.com/library/view/fundamentals-of-data/9781098108298", lang: "en" }
  - { title: "DuckDB 2.0 — documentation (guide Python / Polars)", url: "https://duckdb.org/docs/2.0/guides/python/polars.html", lang: "en" }
  - { title: "DataTalksClub — Data Engineering Zoomcamp", url: "https://github.com/datatalksclub/data-engineering-zoomcamp", lang: "en" }
  - { title: "dbt — documentation officielle", url: "https://docs.getdbt.com/", lang: "en" }
---

# ETL ou ELT : architectures, couches bronze/silver/gold, idempotence et rejouabilité

> ⏱ 35 min · 🎯 Niveau 5 · 📚 Module 33

## 🎯 Ce que vous saurez faire
- Dire en une phrase la différence entre ETL et ELT, et expliquer pourquoi l'ELT est devenu la norme… sauf quand des données personnelles imposent un passage par l'ETL.
- Ranger les tables d'un pipeline dans les couches **bronze**, **silver** et **gold**, et savoir ce qui a le droit d'entrer dans chacune.
- Écrire un chargement **idempotent** (le relancer dix fois donne le même résultat qu'une fois) et le prouver par un test.
- Rejouer trois jours de traitement après un bug sans retourner interroger la base de production.

> 🧭 **En clair** — Imaginez la cuisine d'un restaurant. Les livraisons arrivent en chambre froide telles quelles, cageots compris (c'est le **bronze**). Le commis lave, épluche, découpe et range en bacs étiquetés (c'est le **silver**). Le chef dresse les assiettes que le client verra (c'est le **gold**). Si une sauce est ratée, on ne rappelle pas le maraîcher : on repart des légumes en chambre froide. Et une bonne recette se refait à l'identique : la cuisiner deux fois ne doit pas donner deux fois plus d'assiettes. C'est exactement ce qu'on attend d'un pipeline de données : des étages clairs, et le droit de tout refaire sans dégât.

## 1. ETL, ELT : où se fait la transformation ?

Dans le cycle de vie décrit par Joe Reis et Matt Housley (génération → stockage → ingestion → transformation → service, vu en M31), la question de cette leçon porte sur l'ordre de deux étapes : **transforme-t-on avant ou après le chargement ?**

| | **ETL** (*Extract, Transform, Load*) | **ELT** (*Extract, Load, Transform*) |
|---|---|---|
| Où se transforme la donnée ? | Sur un serveur ou un outil intermédiaire, **avant** l'entrepôt | **Dans** l'entrepôt ou le lakehouse, en SQL (dbt) |
| Ce qui est stocké | Seulement la donnée déjà nettoyée | La donnée **brute**, puis ses versions raffinées |
| Force | On filtre ou anonymise **avant** que la donnée n'entre | On peut tout recalculer : la matière brute est conservée |
| Faiblesse | Une erreur de transformation est définitive ; outils souvent propriétaires | On stocke aussi ce qu'on n'aurait pas dû (données personnelles brutes) |
| Époque typique | Entrepôts coûteux des années 1990-2010 | Stockage objet bon marché + moteurs colonnaires (Snowflake, BigQuery, DuckDB…) |

Pourquoi l'ELT a gagné ? Parce que le stockage est devenu très bon marché et que les moteurs colonnaires transforment des millions de lignes en SQL en quelques secondes. Garder la donnée brute coûte peu, et elle sauve la mise le jour où une règle de calcul change.

**Pour l'IA, le schéma est souvent hybride** : on charge le brut (ELT), mais on applique une **anonymisation des données personnelles en mode ETL** avant la couche silver, pour que les embeddings et les index vectoriels ne contiennent jamais un nom ou un IBAN en clair (l'IBAN est le numéro de compte bancaire international). La détection elle-même sera vue en M36 (L177, Presidio).

> 💡 **À retenir** — ETL ou ELT n'est pas une religion : c'est le choix de **l'endroit** où vous transformez. Règle pratique : ELT par défaut, ETL pour tout ce qui ne doit **jamais** entrer en clair dans l'entrepôt.

```quiz
{
  "q": "Une PME veut indexer ses tickets SAV dans un RAG, mais les tickets contiennent des numéros de téléphone de clients. Quelle architecture recommandez-vous ?",
  "options": [
    "ELT pur : on charge tout tel quel jusque dans l'index vectoriel, on nettoiera plus tard",
    "ETL pur sans aucune copie brute, pour ne jamais pouvoir rejouer",
    "Aucune : il est interdit de traiter des tickets SAV",
    "Hybride : brut en zone restreinte, anonymisation avant silver, puis ELT"
  ],
  "answer": 3,
  "explanation": "Le schéma hybride conserve la rejouabilité (le brut reste en bronze, à accès restreint et avec une durée de conservation définie) tout en garantissant que les couches consommées par l'IA ne contiennent pas les données personnelles en clair."
}
```

## 2. L'architecture médaillon : bronze, silver, gold

L'architecture **médaillon** organise le lakehouse en trois couches de raffinement. (Voir le lexique : le nom vient des médailles olympiques, du bronze à l'or.) Vous l'avez modélisée en M31 (L154) ; ici, on fixe les **règles du jeu** de chaque couche pour le pipeline.

```
 Sources                BRONZE                    SILVER                      GOLD
 (Postgres, API,   ──▶  copie brute, horodatée ──▶ typée, dédoublonnée,   ──▶ tables métier prêtes
  PDF, CSV)             append-only, immuable      une ligne = un fait,        à consommer : marts,
                        + métadonnées de charge    PII anonymisées             features, chunks RAG
                        (_charge_le, _source)      tests de qualité            contrats, SLA
```

*Lexique du schéma : **append-only** = on ne fait qu'ajouter des lignes, jamais modifier ; **immuable** = qui ne change plus une fois écrit ; **PII** (*Personally Identifiable Information*) = données personnelles ; **contrat** = engagement écrit sur le format et la qualité d'une table (L171) ; **SLA** (*Service Level Agreement*) = niveau de service promis, par exemple « à jour chaque matin à 7 h ».*

| Couche | Contenu | Règles | Qui la lit ? |
|---|---|---|---|
| **Bronze** | Copie fidèle des sources, y compris les erreurs | On **n'écrase jamais** ; on ajoute (*append*) avec la date de chargement ; types souvent textuels | Les data engineers, pour rejouer |
| **Silver** | Données nettoyées, typées, dédoublonnées, conformes | Clés uniques testées, formats normalisés, PII traitées | Data engineers, data scientists |
| **Gold** | Agrégats et tables orientées usage (CA par agence, features ML, chunks à indexer) | Contrat stable, documenté, testé | Métiers, tableaux de bord, applications IA |

Pour **Bréval Matériaux**, la PME fil rouge du niveau 5 présentée en L151 (ERP Postgres, tickets SAV en JSONL, documents internes), cela donne par exemple : `bronze.commandes` (l'export de l'ERP tel quel, que vous avez déjà produit en Parquet en L152) → `silver.commandes` (une ligne par commande, dernière version, types et statuts conformes) → `gold.ca_journalier_par_agence` (Nantes, Saint-Nazaire, Ancenis). En M31, vous avez construit ces couches à la main ; ce module les industrialise.

> 💡 **Autrement dit** — Bronze = « ce qu'on a reçu », silver = « ce qui est vrai », gold = « ce dont le métier a besoin ». Si vous hésitez sur la couche d'une table, demandez-vous qui a le droit de la lire.

> ⚠️ **Piège fréquent** — Faire des corrections « à la main » directement en silver ou en gold (un `UPDATE` pour réparer un montant). Au prochain recalcul, la correction disparaît. Toute correction doit être une **règle** dans le code de transformation, versionnée dans Git.

## 3. Idempotence : relancer sans casser

Une opération est **idempotente** si l'exécuter une fois ou plusieurs fois donne le même résultat. Appuyer sur le bouton d'appel d'un ascenseur est idempotent ; ajouter « 1 kg de farine » dans une recette ne l'est pas.

Pourquoi c'est vital : un pipeline **va** échouer (réseau, disque plein, API qui renvoie une erreur 503 (code HTTP « service indisponible »)). L'orchestrateur (L164) va le **relancer** automatiquement. Si le chargement n'est pas idempotent, chaque relance ajoute des doublons, et le chiffre d'affaires du tableau de bord double en silence.

Trois techniques classiques :

1. **Écrasement de partition** (*partition overwrite*) : pour le jour J, on supprime puis réécrit toute la partition J, dans une transaction. (Une **transaction** regroupe plusieurs ordres SQL qui réussissent tous ou échouent tous : si le programme plante entre le `DELETE` et l'`INSERT`, rien n'est perdu.)
2. **Upsert / MERGE** sur une clé métier : « si l'`id` existe, je mets à jour ; sinon j'insère ».
3. **Recalcul complet** (`CREATE OR REPLACE TABLE … AS SELECT`) : idempotent par construction, parfait tant que le volume le permet.

Le code suivant, exécutable avec `pip install duckdb`, montre la version naïve puis la version idempotente. Le dossier `data/landing/` joue le rôle de **zone d'atterrissage** : l'endroit où l'on dépose les fichiers bruts reçus, avant tout chargement.

```python
# l161_idempotence.py — démonstration avec DuckDB (pip install duckdb), à lancer depuis breval/
import datetime as dt
from pathlib import Path

import duckdb

LANDING = Path("data/landing")
JOUR = "2026-11-03"

# 1) Simuler l'export du jour de l'ERP Bréval : CSV « à la française » (séparateur ;, décimale ,)
(LANDING / JOUR).mkdir(parents=True, exist_ok=True)
(LANDING / JOUR / "commandes.csv").write_text(
    "commande_id;numero;client_id;agence_id;canal;statut;date_commande;montant_ht;mis_a_jour_le\n"
    "120001;CMD-2026-0040001;17;NAN;comptoir;validee;2026-11-03 09:12:00;1249,90;2026-11-03 09:12:00\n"
    "120002;CMD-2026-0040002;204;STN;telephone;brouillon;2026-11-03 10:40:00;389,00;2026-11-03 10:40:00\n"
    "120002;CMD-2026-0040002;204;STN;telephone;validee;2026-11-03 10:40:00;389,00;2026-11-03 11:05:00\n",
    encoding="utf-8",   # la commande 120002 apparaît deux fois : brouillon, puis validée
)

con = duckdb.connect("data/lab_l161.duckdb")
con.execute("CREATE SCHEMA IF NOT EXISTS bronze")
con.execute("CREATE SCHEMA IF NOT EXISTS silver")
con.execute("""
    CREATE TABLE IF NOT EXISTS bronze.commandes_export (
        commande_id VARCHAR, numero VARCHAR, client_id VARCHAR, agence_id VARCHAR, canal VARCHAR,
        statut VARCHAR, date_commande VARCHAR, montant_ht VARCHAR, mis_a_jour_le VARCHAR,
        _jour_chargement DATE, _charge_le TIMESTAMP
    )
""")

def lire_export(jour: str) -> str:
    # bronze : tout en texte, rien n'est corrigé (comme en L152)
    return f"read_csv('{LANDING / jour / 'commandes.csv'}', delim = ';', header = true, all_varchar = true)"

def charger_naif(jour: str) -> None:
    """NON idempotent : chaque relance ajoute les mêmes lignes une fois de plus."""
    con.execute(f"INSERT INTO bronze.commandes_export SELECT *, DATE '{jour}', now() FROM {lire_export(jour)}")

def charger_idempotent(jour: str) -> None:
    """Idempotent : on remplace la partition du jour, dans une transaction."""
    con.execute("BEGIN TRANSACTION")
    con.execute("DELETE FROM bronze.commandes_export WHERE _jour_chargement = ?", [jour])
    con.execute(f"INSERT INTO bronze.commandes_export SELECT *, DATE '{jour}', now() FROM {lire_export(jour)}")
    con.execute("COMMIT")

def construire_silver() -> None:
    """Recalcul complet : typage + dernière version de chaque commande (idempotent par construction)."""
    con.execute("""
        CREATE OR REPLACE TABLE silver.commandes AS
        SELECT CAST(commande_id AS BIGINT)                          AS commande_id,
               numero,
               CAST(client_id AS INTEGER)                           AS client_id,
               agence_id, canal, statut,
               CAST(date_commande AS TIMESTAMP)                     AS date_commande,
               CAST(replace(montant_ht, ',', '.') AS DECIMAL(12,2)) AS montant_ht,
               CAST(mis_a_jour_le AS TIMESTAMP)                     AS mis_a_jour_le
        FROM bronze.commandes_export
        QUALIFY row_number() OVER (PARTITION BY commande_id
                                   ORDER BY CAST(mis_a_jour_le AS TIMESTAMP) DESC) = 1
    """)

def compter() -> tuple[int, int]:
    b = con.execute("SELECT count(*) FROM bronze.commandes_export").fetchone()[0]
    s = con.execute("SELECT count(*) FROM silver.commandes").fetchone()[0]
    return b, s

con.execute("DELETE FROM bronze.commandes_export")  # repartir de zéro pour la démo
for essai in range(3):
    charger_idempotent(JOUR)   # remplacez par charger_naif(JOUR) pour voir la différence
    construire_silver()
    print(f"Exécution {essai + 1} → bronze, silver = {compter()}")

# Test d'idempotence automatisable : l'état après 3 exécutions == l'état après 1
assert compter() == (3, 2), "Le chargement n'est pas idempotent !"
print("Idempotence vérifiée le", dt.date.today())
```

> 🔍 **Ce que vous devez voir** — exactement quatre lignes : `Exécution 1 → bronze, silver = (3, 2)`, `Exécution 2 → bronze, silver = (3, 2)`, `Exécution 3 → bronze, silver = (3, 2)`, puis `Idempotence vérifiée le 2026-11-…` (la date du jour). En remplaçant par `charger_naif`, vous verrez `(3, 2)`, `(6, 2)`, `(9, 2)` puis une erreur `AssertionError: Le chargement n'est pas idempotent !` : c'est le résultat **attendu** de la démonstration, pas un bug.

> 🛠️ **Si ça ne marche pas** — Les nombres de départ ne sont pas `(3, 2)` → la base `data/lab_l161.duckdb` contient des restes d'un essai précédent (avec `charger_naif`, par exemple) : supprimez ce fichier et relancez. « Could not set lock on file » → fermez tout autre programme qui a ouvert `lab_l161.duckdb`. Le dossier `data/landing/` apparaît ailleurs que dans `breval/data/` → le script a été lancé depuis un autre dossier.

Avec `charger_idempotent`, vous obtenez `(3, 2)` à chaque exécution : 3 lignes brutes (dont deux versions de la commande 120002), 2 commandes en silver. Avec `charger_naif`, le bronze passe à 6 puis 9 lignes. Le silver reste juste grâce au `QUALIFY`, mais seulement par chance : une table gold construite directement sur le bronze, elle, doublerait.

> 🔗 **Documentation officielle** — [DuckDB 2.0 — guide « DuckDB et Polars »](https://duckdb.org/docs/2.0/guides/python/polars.html) 🇬🇧 (page vérifiée lors de nos recherches). Depuis le sommaire de cette documentation, vous trouverez aussi la clause `QUALIFY`, `read_csv` et les transactions, décrites dans la même documentation (version 2.0 LTS, nov. 2026).

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un INSERT INTO … SELECT exécuté par un orchestrateur avec 3 relances automatiques est idempotent tant que la requête SQL ne change pas.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. Un INSERT ajoute des lignes à chaque exécution : trois relances après un échec partiel peuvent produire des doublons. Il faut un écrasement de partition, un MERGE sur une clé, ou un recalcul complet."
}
```

## 4. Rejouabilité : pouvoir refaire le passé

La **rejouabilité** (*replayability*) est la capacité à recalculer n'importe quelle période à partir de données conservées, sans retourner interroger la source. Elle repose sur trois piliers :

- **Un bronze immuable et horodaté** : chaque chargement garde sa date (`_jour_chargement`) et n'est jamais modifié. Le lundi où vous découvrez que la TVA était mal calculée depuis trois semaines, vous corrigez la règle et rejouez les 21 partitions.
- **Des transformations paramétrées par la période** : le code reçoit « traite le 2026-11-03 », jamais « traite aujourd'hui ». L'orchestrateur fournit la date ; c'est ce qui rend possible le *backfill* (L164). (*backfill* = rattrapage : recalculer après coup une série de périodes passées, voir le lexique)
- **Des transformations déterministes** (même entrée = même sortie, à chaque fois) : pas de `now()` dans un calcul métier, pas de `random()` sans graine. Sinon, deux rejeux donnent deux résultats.

> 💡 **À retenir** — Un pipeline sain, c'est **bronze immuable + transformations idempotentes paramétrées par la période**. Avec ces deux propriétés, une panne n'est plus un drame : c'est une relance.

> ⚠️ **Piège fréquent** — Conserver indéfiniment un bronze plein de données personnelles « pour pouvoir rejouer ». Le RGPD impose une durée de conservation : définissez-la (par exemple 90 jours de bronze brut, puis seulement la version anonymisée), et documentez-la. Ce sujet est approfondi en M35 (L174).

```quiz
{
  "q": "Votre transformation silver contient « WHERE date_commande >= current_date - 1 ». Pourquoi est-ce un problème pour la rejouabilité ?",
  "options": [
    "Rejouée plus tard, elle traite une autre période : la date doit être un paramètre",
    "current_date n'existe pas en SQL standard, la requête échouera",
    "La requête est trop lente car elle relit toute la table",
    "Ce n'est pas un problème : c'est la bonne pratique pour un chargement incrémental"
  ],
  "answer": 0,
  "explanation": "Une transformation qui dépend de l'horloge donne un résultat différent selon le jour où on la lance. En passant la date de traitement en paramètre, on peut rejouer n'importe quel jour passé (backfill)."
}
```

```mission
{
  "title": "Les étapes du cycle de vie selon Reis & Housley",
  "url": "https://oreilly.com/library/view/fundamentals-of-data/9781098108298",
  "steps": ["Ouvrez la page O'Reilly du livre Fundamentals of Data Engineering", "Affichez la table des matières", "Repérez les chapitres de la Partie II"],
  "question": "Quelles étapes du cycle de vie la Partie II du livre détaille-t-elle, et laquelle correspond à cette leçon ?",
  "hint": "Cherchez les chapitres qui suivent « Source Systems ».",
  "answer": "Sources, stockage, ingestion, requêtes/modélisation/transformation, service (serving). Cette leçon porte sur l'articulation ingestion → transformation (table des matières consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🎮 Défi : le pipeline qui ment

Un collègue vous montre ce script quotidien : il lit l'export des commandes de l'ERP « depuis hier », fait `INSERT INTO gold.ca_journalier SELECT sum(montant_ht) …`, puis supprime le fichier téléchargé. Trouvez **trois** problèmes en moins de deux minutes. (Pistes : couche, idempotence, rejouabilité.)

## 🧪 Exercice pratique

**Consigne** : à partir du script `l161_idempotence.py`, ajoutez une couche gold `gold.ca_journalier_par_agence` (CA HT par jour de `date_commande` et par `agence_id`, uniquement les commandes au statut `validee`, `livree` ou `facturee` : les brouillons et les annulations ne comptent pas), puis :
1. déposez un second fichier pour le `2026-11-04` ;
2. exécutez le pipeline trois fois de suite pour chaque jour ;
3. écrivez une assertion qui compare le contenu de `gold.ca_journalier_par_agence` après la 1ʳᵉ et après la 3ᵉ exécution.

**Critères de réussite** : la table gold est reconstruite à partir du silver (pas du bronze) ; l'assertion passe ; aucune utilisation de `now()` ou `current_date` dans les calculs métier ; le `DELETE` et l'`INSERT` du bronze sont dans une même transaction.

**Corrigé (pistes)** : `CREATE OR REPLACE TABLE gold.ca_journalier_par_agence AS SELECT CAST(date_commande AS DATE) AS jour, agence_id, sum(montant_ht) AS ca_ht, count(*) AS nb_commandes FROM silver.commandes WHERE statut IN ('validee','livree','facturee') GROUP BY ALL ORDER BY ALL;` (n'oubliez pas `CREATE SCHEMA IF NOT EXISTS gold`). Pour comparer, stockez `con.execute("SELECT * FROM gold.ca_journalier_par_agence ORDER BY ALL").fetchall()` dans une variable après chaque exécution. Pour le défi : écriture directe en gold sans bronze, `INSERT` non idempotent, source supprimée donc aucun rejeu possible, et fenêtre « depuis hier » dépendante de l'horloge.

## ✅ Auto-évaluation express
1. Dans quel cas un ETL (transformation avant chargement) reste-t-il préférable ?
2. Quelle couche ne doit jamais être modifiée après écriture ?
3. Citez deux techniques pour rendre un chargement idempotent.

**Réponses** : 1. Quand une donnée ne doit jamais entrer en clair dans l'entrepôt (données personnelles, contraintes de souveraineté). 2. Le bronze (append-only, horodaté). 3. Écrasement de partition dans une transaction, MERGE/upsert sur une clé métier, ou recalcul complet `CREATE OR REPLACE`.

## 📚 Pour aller plus loin
- [Fundamentals of Data Engineering — O'Reilly](https://oreilly.com/library/view/fundamentals-of-data/9781098108298) 🇬🇧 — l'ouvrage de référence de Reis & Housley (2022), cité comme source d'inspiration.
- [DataTalksClub — Data Engineering Zoomcamp](https://github.com/datatalksclub/data-engineering-zoomcamp) 🇬🇧 — cours gratuit de 9 semaines ; les modules 2 (orchestration) et 4 (analytics engineering) prolongent ce module.
- [dbt — documentation](https://docs.getdbt.com/) 🇬🇧 — l'outil ELT que vous utiliserez en L163.

> ✅ **Si vous ne retenez que 3 choses** — 1. ELT par défaut (on charge le brut puis on transforme en SQL dans l'entrepôt), ETL pour ce qui ne doit jamais entrer en clair (données personnelles à anonymiser avant silver). 2. Bronze = ce qu'on a reçu (ajout seul, horodaté, jamais corrigé), silver = ce qui est vrai (typé, dédoublonné), gold = ce dont le métier a besoin ; toute correction est une règle dans le code, jamais un `UPDATE` à la main. 3. Un pipeline sain est idempotent (écrasement de partition en transaction, `MERGE`, ou recalcul complet) et rejouable (bronze conservé, traitements paramétrés par la période, sans `now()` ni hasard non fixé).

> 🗺️ **Et maintenant ?** — Vous savez ranger et rejouer ; la leçon L162 s'attaque à la question suivante : comment faire entrer dans le bronze **seulement ce qui a changé** depuis la dernière fois, avec dlt, Airbyte ou la capture de changements Debezium.
