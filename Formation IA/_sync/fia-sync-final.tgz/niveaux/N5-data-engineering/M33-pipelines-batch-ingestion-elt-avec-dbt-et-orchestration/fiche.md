---
module: M33
title: "Fiche mémo — Pipelines batch : ingestion, ELT avec dbt et orchestration"
---
# Fiche mémo — M33 · Pipelines batch : ingestion, ELT avec dbt et orchestration

> En une phrase : bronze immuable + transformations idempotentes paramétrées par la date. On n'ingère que ce qui a changé (dlt), on transforme et on teste en SQL (dbt), on laisse un orchestrateur relancer et alerter, et la CI ne reconstruit que ce qui a bougé.

## Les 7 idées à retenir
1. ELT par défaut : on charge le brut, puis on transforme dans l'entrepôt. On passe en ETL pour ce qui ne doit jamais entrer en clair, comme l'anonymisation des données personnelles avant la couche silver (`L161`).
2. Idempotent = une ou dix exécutions donnent le même résultat. Trois techniques : écraser la partition dans une transaction, `MERGE` sur une clé, ou `CREATE OR REPLACE` (`L161`).
3. Pour rejouer : un bronze horodaté, la date logique en paramètre (jamais `current_date`), pas de `now()` ni de `random()` dans un calcul métier (`L161`).
4. Chargement complet, curseur ou CDC. Un curseur `mis_a_jour_le` ne voit ni les suppressions ni les `UPDATE` sans déclencheur. Debezium lit le WAL et émet `op = d` (`L162`).
5. dbt = le « T » de l'ELT : `source()` / `ref()` dessinent le DAG. Un modèle incrémental a besoin d'un `unique_key`, sinon il fait de l'append. Le snapshot assure la SCD 2 (`L163`).
6. Trois garde-fous : le test de données vérifie le contenu réel, le unit test la logique sur des données inventées, le contrat la forme (colonnes et types) (`L163`).
7. L'orchestrateur gère dépendances, relances, backfill et alertes, mais il ne rend pas une tâche idempotente. Airflow pense en tâches (et en assets depuis la v3), Dagster en assets (1 modèle dbt = 1 asset) (`L164`, `L165`).

## Le schéma à connaître
```mermaid
flowchart LR
    PG["ERP Postgres<br/>+ tickets_sav.jsonl"] -->|"dlt : replace / merge + curseur"| BZ["bronze<br/>data/breval.duckdb"]
    BZ -->|"dbt staging (view)"| SI["silver<br/>stg_erp__*"]
    SI -->|"dbt marts (table / incremental)"| GO["gold<br/>fct_commandes, ca_journalier_par_agence"]
    SI --> SN["snapshots.snap_clients (SCD 2)"]
    OR["Airflow / Dagster : 2 h, 3 relances, alerte"] -.-> BZ
    OR -.-> GO
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Curseur | Le marque-page : « j'en étais à tel `mis_a_jour_le` » |
| CDC | L'abonnement à chaque rature du journal de transactions |
| Write disposition (dlt) | `append`, `replace` ou `merge` (upsert sur `primary_key`) |
| `is_incremental()` | Vraie si la table existe déjà, fausse au premier passage et avec `--full-refresh` |
| `{{ this }}` | La table déjà construite par le modèle incrémental |
| Asset | Un objet de données (table, index) dont l'outil déduit quoi exécuter |
| Date logique (`ds`) | La période à traiter, fournie par l'orchestrateur, même lors d'un backfill |
| CI slim | Ne construire que `state:modified` et ses dépendances |

## Les pièges classiques
- Corriger à la main par un `UPDATE` en silver ou en gold : la correction disparaît au recalcul.
- Écrire `INSERT INTO … WHERE date >= current_date - 1` : trois relances donnent un CA triplé.
- Garder un bronze de données personnelles indéfiniment : il faut fixer une durée de conservation.
- Laisser une transaction longue écrire un `mis_a_jour_le` antérieur au curseur : la ligne est sautée. On relit une marge de recouvrement.
- Laisser un slot de réplication abandonné : il retient le WAL et le disque se remplit.
- Écrire un nom de table en dur au lieu de `ref()` : on casse le lignage, la CI et le passage dev → prod.
- Changer la logique d'un modèle incrémental sans `--full-refresh`.
- Mettre du code lourd au niveau supérieur d'un fichier DAG Airflow.
- Ouvrir DuckDB dans deux processus écrivains en même temps.

## Les commandes / chiffres / dates utiles
```bash
pip install "dlt[duckdb,sql_database]" psycopg2-binary dbt-core dbt-duckdb
python ingestion/ingest.py                         # dlt, dataset « bronze » dans data/breval.duckdb
dbt init dbt_breval --skip-profile-setup ; dbt debug
dbt build                                          # snapshots, modèles, tests, unit tests, dans l'ordre du graphe
dbt build --full-refresh --select fct_commandes
dbt snapshot ; dbt source freshness ; dbt docs generate && dbt docs serve
dbt ls --select stg_erp__clients+                  # descendants (impact)   +modele = ancêtres
dbt parse                                          # manifest.json sans rien construire
dbt build --select "+state:modified+" --state etat-main --fail-fast   # CI sur base éphémère
dbt build --select state:modified+ --defer --state <prod>             # CI sur entrepôt partagé
airflow standalone                                 # UI sur localhost:8080
airflow backfill create --dag-id breval_ingestion --from-date 2026-10-01 --to-date 2026-10-31
dagster dev -f orchestration/defs.py               # UI sur localhost:3000
make up && make pipeline ; make test-idempotence
```
```python
sql_table(..., incremental=dlt.sources.incremental("mis_a_jour_le")).apply_hints(write_disposition="merge", primary_key="commande_id")
{{ config(materialized='incremental', unique_key='commande_id', incremental_strategy='delete+insert') }}
@dag(schedule=[Asset("breval_bronze")])            # Airflow 3 : déclenché par l'asset, from airflow.sdk
@dbt_assets(manifest=projet_dbt.manifest_path)     # Dagster : chaque modèle dbt devient un asset
@task(retries=3, retry_delay_seconds=60)           # Prefect 3
```
- **Tests dbt intégrés** : `unique`, `not_null`, `accepted_values`, `relationships`. Paramètres sous `arguments` depuis dbt 1.10, unit tests depuis 1.8, snapshots en YAML depuis 1.9. Fraîcheur : `warn_after` 24 h, `error_after` 48 h sur `loaded_at_field: mis_a_jour_le`.
- **Versions 2026** : Airflow 3.3.2 (17 sept. 2026, Task SDK `airflow.sdk`, assets, ex-datasets). Prefect rachète Dagster Labs (13 juillet 2026). Certification dbt alignée sur 1.11 : 65 questions, 2 h, 65 %. dbt Learn Fundamentals : environ 5 h, gratuit.
- **Debezium** : `op` = `c` / `u` / `d` / `r`. Plugin `pgoutput`, `wal_level=logical`, slot de réplication + publication.
- **Fichiers Bréval** : `sql/02_trigger_mis_a_jour.sql`, `ingestion/ingest.py`, `dbt_breval/` (`stg_<source>__<table>`, schémas `silver`, `gold`, `snapshots`), `orchestration/defs.py`, `tests_pipeline/test_idempotence.py`, `.github/workflows/dbt-ci-slim.yml` (jeu CI `--echelle 0.05`).

## Pour aller plus loin
- [dlt (dltHub) — documentation](https://dlthub.com/docs)
- [dbt — documentation officielle](https://docs.getdbt.com/)
- [Apache Airflow — Announcements](https://airflow.apache.org/announcements/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Pourquoi votre copie garde-t-elle des commandes supprimées dans l'ERP ?
2. Quel paramètre empêche un modèle dbt incrémental de dupliquer les lignes lors d'un rejeu ?
3. Pourquoi un test d'idempotence ajoute-t-il une somme de contrôle au `count(*)` ?

---
**Réponses.** 1) Un curseur ne lit que les lignes existantes plus récentes que le marque-page, et une ligne supprimée ne produit rien. Il faut du CDC, une suppression logique ou un rechargement complet de contrôle. 2) `unique_key`, avec la stratégie `delete+insert` ou `merge`. 3) Le nombre de lignes peut rester identique alors que des valeurs ont changé : le hash des colonnes métier le détecte.
