# Niveau 5 — Data engineering & Big Data pour l'IA (NF-IA-N5)

**Certificat Next Formation IA — Niveau 5 « Data engineer IA »** · Spécialisation · 30 h à distance (29 h de leçons, exercices et quiz + 1 h d'examen) · 7 modules · 34 leçons · 7 quiz · 1 examen · 5 ateliers évalués · 1 projet final avec soutenance · Version 1.0 — 5 novembre 2026.

> **Spécialisation hors parcours certifiant 150 h.** Le niveau 5 s'ajoute aux niveaux N1 à N4 (150 h) sans en modifier les totaux ; il est accessible dès la validation du niveau 3 et peut être suivi avant, après ou à la place du niveau 4.

## Promesse

À l'issue du niveau 5, vous **construisez et exploitez la chaîne de données qui alimente vos applications d'IA** : vous choisissez les bons formats (CSV, JSON/JSONL, Parquet, Avro, Arrow) et le bon moteur (DuckDB, Polars, Spark, entrepôt cloud), vous modélisez pour l'analytique (étoile, SCD type 2, Data Vault, architecture médaillon bronze/silver/gold), vous bâtissez un lakehouse en local (stockage objet MinIO, Delta Lake / Apache Iceberg), vous écrivez des pipelines ELT incrémentaux et idempotents (dlt, dbt Core, Airflow 3 ou Dagster, CI « slim »), vous propagez les changements d'une base métier en temps réel (CDC Postgres → Debezium → Kafka 4 en mode KRaft → table de lakehouse), vous garantissez la qualité et la conformité (tests dbt, Great Expectations / Soda, contrats ODCS v3.1, catalogue et lignage OpenLineage, RGPD, AI Act art. 10) et vous préparez des données dignes d'un LLM ou d'un RAG (extraction Docling, filtres qualité, déduplication MinHash/LSH, anonymisation Presidio, chunking, embeddings par lots, index vectoriel incrémental, versionnement). Le niveau se conclut par un **projet final : le pipeline de données de bout en bout d'un RAG d'entreprise**, sur le jeu de données fil rouge **Bréval Matériaux** (PME fictive de négoce de matériaux : commandes, clients, tickets SAV, documents internes), déjà rencontré en M20. Le niveau s'inspire de *Fundamentals of Data Engineering* (Reis & Housley), du DataTalksClub Data Engineering Zoomcamp, de Stanford CS246 / *Mining of Massive Datasets*, de CMU 15-445, Berkeley CS186 et MIT 6.5830 — avec des leçons entièrement originales.

## Public

Développeurs ayant validé le niveau 3 (ou équivalent), data analysts souhaitant passer à l'ingénierie, ingénieurs IA qui construisent des RAG et des agents et veulent fiabiliser leurs données, profils niveau 4 (data scientists, ingénieurs ML) souhaitant industrialiser les données d'entraînement et d'évaluation, développeurs visant le métier de data engineer (fiche APEC « Data Engineer », code ROME M1811).

## Prérequis

- Niveau 3 Next Formation validé **ou** expérience équivalente : Python (fonctions, classes, environnements virtuels), appels d'API, RAG en code (M20).
- SQL de base (SELECT, jointures, GROUP BY) ; les fonctions analytiques modernes sont enseignées en M31.
- Docker de base (images, conteneurs, `docker compose up`) : un **rappel express est intégré à M31** (L151).
- Git et ligne de commande.
- Test de positionnement d'entrée.

## Compétences du bloc 5 (référentiel de compétences)

| Code | Compétence |
|---|---|
| C5.1 | Concevoir un modèle de données analytique (étoile ou Data Vault) et choisir les formats et le stockage (Parquet, format de table ouvert, entrepôt cloud ou moteur local) adaptés à un volume, une latence et un budget donnés |
| C5.2 | Construire un pipeline batch ELT incrémental (ingestion, transformation dbt testée, orchestration) capable de reprendre après échec sans doublon |
| C5.3 | Traiter des données volumineuses ou en flux avec le moteur approprié (Spark, Polars/DuckDB, Kafka et Flink/Spark Streaming) en garantissant l'ordre, la fraîcheur et la sémantique de livraison requises |
| C5.4 | Mettre en œuvre la qualité, la gouvernance et la conformité des données : tests, contrat de données, catalogue et lignage, contrôle d'accès, règles RGPD |
| C5.5 | Préparer des données pour l'IA : extraction, nettoyage, déduplication, anonymisation des données personnelles, découpage et vectorisation, versionnement des jeux et, le cas échéant, génération de données synthétiques |
| C5.6 | Exploiter et optimiser une plateforme de données en production : observabilité (fraîcheur, volume, schéma, qualité, lignage), gestion d'incident, maîtrise des coûts et documentation |

## Modules et durées

| Module | Titre | Leçons | Durée | Compétences |
|---|---|---|---|---|
| M31 | Données, formats et SQL analytique moderne (cycle de vie du data engineering et rôle du data engineer IA ; formats CSV, JSON/JSONL, Parquet, Avro, ORC, Arrow mesurés ; SQL DuckDB : CTE, fenêtres, QUALIFY, MERGE, plan d'exécution ; 3NF, étoile, SCD type 2, Data Vault 2.0, médaillon ; atelier de profilage et de modélisation) | L151-L155 | 4 h 25 | C5.1 |
| M32 | Stockage, lakehouse et calcul distribué (de Hadoop au lakehouse, stockage objet S3/GCS/MinIO ; Delta Lake, Iceberg, Hudi, time travel, catalogues REST ; Snowflake, BigQuery, Databricks, Redshift, Fabric, ClickHouse, MotherDuck — choisir et chiffrer ; Spark et PySpark 4 ; Polars lazy, DuckDB, Dask et Ray) | L156-L160 | 4 h 30 | C5.1, C5.3 |
| M33 | Pipelines batch : ingestion, ELT avec dbt et orchestration (ETL/ELT, couches bronze/silver/gold, idempotence ; Airbyte, Fivetran, dlt, CDC Debezium ; dbt Core : modèles incrémentaux, snapshots, tests, lignage ; Airflow 3, Dagster, Prefect ; atelier dlt → DuckDB → dbt avec CI slim) | L161-L165 | 4 h 25 | C5.2 |
| M34 | Streaming et données temps réel (temps d'événement, fenêtres, retard, garanties de livraison ; Kafka 4 en mode KRaft, KIP-848, Avro et Schema Registry, Kafka Connect ; Flink, Spark Structured Streaming, Kafka Streams ; atelier CDC Postgres → Debezium → Kafka → Iceberg/Delta) | L166-L169 | 3 h 35 | C5.3 |
| M35 | Qualité, gouvernance et observabilité des données (dimensions de qualité, tests dbt, GX Core, Soda Core ; contrats ODCS v3.1 et évolution de schéma ; Unity Catalog, OpenMetadata, DataHub, OpenLineage ; les 5 piliers de l'observabilité, Elementary, gestion d'incident ; RGPD, contrôle d'accès, chiffrement, AI Act art. 10) | L170-L174 | 3 h 55 | C5.4, C5.6 |
| M36 | Préparer les données pour l'IA : LLM, ML et RAG (corpus texte : Docling, Trafilatura, filtres qualité méthode FineWeb ; déduplication exacte, MinHash/LSH, sémantique, décontamination ; Presidio et reconnaisseurs français NIR, IBAN, téléphone ; chunking, embeddings par lots Ray Data / Spark, bases vectorielles à l'échelle ; Feast, DVC, lakeFS, SDV et données synthétiques) | L175-L179 | 4 h 15 | C5.5 |
| M37 | Projet final : pipeline de données de bout en bout pour un RAG d'entreprise (cadrage et contrat de données ; ingestion documents + CDC vers bronze ; parsing, PII, déduplication, chunking en silver ; indexation vectorielle incrémentale et évaluation de la récupération ; industrialisation, observabilité, coût par document, soutenance) | L180-L184 | 3 h 55 | C5.1 à C5.6 |
| | **Total leçons, exercices et quiz** | 34 leçons | **29 h 00** | |
| | dont leçons et exercices (1 635 min) | | 27 h 15 | |
| | dont quiz de modules (7 × 15 min) | | 1 h 45 | |
| | Examen de niveau | | 1 h 00 | |
| | **Total niveau 5** | | **30 h 00** | |

## Modalités d'évaluation

- **7 quiz de fin de module** (10 questions, seuil 70 %) et **examen de niveau** (40 questions majoritairement en mises en situation, 60 min, seuil 70 %, surveillé à distance, 3 tentatives).
- **Cinq ateliers évalués** dans un dépôt Git (grille à 5 critères notés 0-3 ; compétence validée si ≥ 8/15 sans critère à 0) :
  1. Atelier de modélisation : profilage, nettoyage silver, modèle en étoile avec SCD type 2, contrôles de réconciliation et journal de nettoyage (L155) + étude de cas écrite de choix de format et de moteur (L152, L158) → C5.1
  2. Optimisation d'un traitement Spark : plans d'exécution annotés, jointure broadcast, effet de l'AQE sur un déséquilibre mesuré (L159), comparaison avec Polars/DuckDB (L160) → C5.3
  3. Pipeline ELT dlt → DuckDB → dbt orchestré : test d'idempotence vert, tests dbt, CI slim sur les modèles modifiés (L165) → C5.2
  4. Chaîne CDC Postgres → Debezium → Kafka → table Delta/Iceberg : latence médiane et p95 mesurées, aucune perte, aucun doublon après panne, suppressions propagées (L169) → C5.3
  5. Dossier qualité et conformité : règles de qualité bloquantes (L170), contrat ODCS validé par `datacontract lint`/`test` (L171), lignage OpenLineage et fiche catalogue (L172), post-mortem d'incident (L173), cartographie des données personnelles et politique d'accès (L174) → C5.4, C5.6
- **Exercices de préparation des données pour l'IA** (déduplication mesurée L176, rappel PII ≥ 90 % L177, choix de chunking justifié par recall@5/MRR L178) : intégrés au projet final → C5.5.
- **Projet final M37** (L180-L184) : pipeline de données de bout en bout pour un RAG d'entreprise — dossier d'architecture avec contrat ODCS, dépôt Docker Compose (MinIO, Postgres + Debezium + Kafka, Docling, Presidio, MinHash, chunking, embeddings par lots, Qdrant ou pgvector, dbt, Dagster ou Airflow), qualité et observabilité, évaluation de la récupération (30 questions, recall@k, MRR, test de suppression propagée, test de cloisonnement des droits), runbook et estimation de coût. Grille pondérée : fonctionnement de bout en bout 25 %, idempotence et incrémental/CDC 20 %, qualité/gouvernance/PII 20 %, évaluation RAG 15 %, observabilité et coûts 10 %, documentation et soutenance 10 % → C5.1 à C5.6.
- **Certification (option RS)** : soutenance de 15 min (démonstration du projet final, suivie des questions du jury) devant jury incluant un data engineer externe. Toutes les compétences C5.1 à C5.6 doivent être validées.

## Certifications tierces visées (en complément, hors Next Formation)

Le niveau 5 **prépare les fondamentaux communs** à ces certifications et donne une expérience projet ; il ne remplace pas la préparation spécifique à chaque fournisseur (services cloud propriétaires). Prix relevés le 5 novembre 2026, hors taxes, à revérifier.

- **dbt Analytics Engineering Certification Exam** (200 $, 65 questions, 2 h, dbt 1.11 ; préparation gratuite dbt Learn Fundamentals) — https://www.getdbt.com/certifications/analytics-engineer-certification-exam. Certification la plus proche du N5 (cœur : M33).
- **Databricks Certified Data Engineer Associate** (200 $, 45 questions, 90 min ; préparation gratuite Databricks Academy + Free Edition) — https://www.databricks.com/learn/certification/data-engineer-associate.
- **Google Cloud Professional Data Engineer** (200 $, 40-50 questions, 2 h ; parcours Google Skills path 16) — https://cloud.google.com/certification/data-engineer.
- **AWS Certified Data Engineer – Associate (DEA-C01)** (150 $, 65 questions, 130 min ; AWS Skill Builder) — https://aws.amazon.com/en/certification/certified-data-engineer-associate.
- **Microsoft Certified: Fabric Data Engineer Associate — examen DP-700** (tarif par pays, à vérifier ; renouvellement annuel gratuit ; remplace de fait DP-203, retirée le 31 mars 2025) — https://learn.microsoft.com/credentials/certifications/resources/study-guides/dp-700.
- **SnowPro Core Certification (COF-C03)** (175 $ selon une source tierce) — https://learn.snowflake.com/en/certifications/snowpro-core-c03.
- **Confluent Certified Developer for Apache Kafka (CCDAK)** (90 min ; prix non affiché, ≈ 150 $ selon des sources tierces, à vérifier) — https://www.confluent.io/en-gb/certification/.
- Cours gratuits recommandés : **DataTalksClub Data Engineering Zoomcamp** (9 semaines, prochaine cohorte janvier 2027, self-paced possible) — https://github.com/datatalksclub/data-engineering-zoomcamp ; livre ***Mining of Massive Datasets*** (PDF gratuit, ch. 2-4) — http://www.mmds.org ; vidéos **CMU 15-445** et notes **Berkeley CS186** — https://cs186berkeley.net/sp25/.

## Matériel et logiciels nécessaires

- Ordinateur Windows 10/11 (WSL2), macOS 13+ ou Linux ; **8 Go de RAM suffisent pour les modules M31-M33 à l'échelle 1 du jeu de données** ; 16 Go recommandés pour faire tourner simultanément la chaîne de streaming et le projet final (Kafka, Debezium, MinIO, Qdrant, Spark local) ; prévoir environ 20 Go d'espace disque libre pour les images Docker et les données (valeurs indicatives) ; webcam et micro pour l'examen surveillé et la soutenance.
- **Aucun GPU ni abonnement cloud requis** : tout le niveau tourne **gratuitement en local avec Docker Compose** (Postgres avec `wal_level=logical`, MinIO, Kafka 4 en mode KRaft, Kafka Connect + Debezium, Qdrant ou pgvector, Marquez pour le lignage). Les embeddings du projet final utilisent un modèle ouvert local (CPU) ou, au choix, une API d'embeddings (quelques centimes).
- **Logiciels gratuits** : Docker Desktop ou Docker Engine + Compose, Python 3.11+ (`uv` ou `venv`), Git, VS Code ou Jupyter, **DuckDB** (2.0 LTS), **Polars**, PyArrow, **dbt Core + adaptateur dbt-duckdb**, **dlt**, **Airflow 3** ou **Dagster**, PySpark 4 (Java 17 requis), `deltalake` / PyIceberg, `confluent-kafka`, Great Expectations (GX Core) et/ou Soda Core, `datacontract-cli`, OpenLineage / Marquez, Elementary, Docling, Trafilatura, `datasketch` (MinHash), Microsoft Presidio, Ray Data, Qdrant client, DVC ou lakeFS, Feast, SDV — versions figées dans le `requirements.txt` du dépôt fil rouge.
- **Comptes gratuits** : GitHub (dépôt et CI GitHub Actions pour la CI slim) ; **optionnels** pour comparer avec le cloud (L158) : **Databricks Free Edition** (gratuite, sans limite de durée) et **BigQuery sandbox** (gratuit ; conditions et quotas à vérifier sur la documentation Google Cloud), dbt Learn, Databricks Academy, Google Skills, Microsoft Learn, AWS Skill Builder pour la préparation des certifications tierces.
