---
id: L158
module: M32
level: N5
title: "Entrepôts et lakehouses cloud : Snowflake, BigQuery, Databricks, Redshift, Fabric, ClickHouse, MotherDuck — choisir et chiffrer"
minutes: 50
objectives:
  - "Décrire l'architecture et le modèle de facturation de sept plateformes analytiques cloud"
  - "Expliquer les leviers de coût communs (données scannées, temps de calcul, mise en veille, partitionnement, clustering) et les appliquer sur des exemples SQL"
  - "Construire un calculateur de coût paramétré à partir des pages de tarifs officielles"
  - "Évaluer et justifier le choix d'une plateforme pour un cas d'entreprise selon une grille multicritère (volume, usages, coût, compétences, souveraineté)"
skills: ["C5.1"]
sources:
  - { title: "Snowflake — documentation", url: "https://docs.snowflake.com/", lang: "en" }
  - { title: "Google BigQuery — documentation", url: "https://cloud.google.com/bigquery/docs", lang: "en" }
  - { title: "Databricks — documentation", url: "https://docs.databricks.com/", lang: "en" }
  - { title: "Amazon Redshift — documentation", url: "https://docs.aws.amazon.com/redshift/", lang: "en" }
  - { title: "Microsoft Fabric — documentation", url: "https://learn.microsoft.com/fabric/", lang: "en" }
  - { title: "ClickHouse — documentation", url: "https://clickhouse.com/docs", lang: "en" }
  - { title: "MotherDuck — documentation", url: "https://motherduck.com/docs/", lang: "en" }
  - { title: "Databricks — Learn, experiment and build with Free Edition", url: "https://www.databricks.com/blog/learn-experiment-and-build-databricks-free-edition", lang: "en" }
  - { title: "Google Cloud — Professional Data Engineer", url: "https://cloud.google.com/certification/data-engineer", lang: "en" }
  - { title: "Snowflake — SnowPro Core (COF-C03)", url: "https://learn.snowflake.com/en/certifications/snowpro-core-c03", lang: "en" }
---

# Entrepôts et lakehouses cloud : choisir et chiffrer

> ⏱ 50 min · 🎯 Niveau 5 · 📚 Module 32

## 🎯 Ce que vous saurez faire
- Situer Snowflake, BigQuery, Databricks, Redshift, Fabric, ClickHouse et MotherDuck sur une même carte.
- Prévoir l'ordre de grandeur de la facture d'une requête **avant** de la lancer.
- Écrire les trois ou quatre lignes de SQL qui divisent souvent une facture : partitionner, regrouper (*clustering*), mettre en veille, filtrer tôt.
- Recommander une plateforme à Bréval Matériaux avec une grille argumentée, pas avec une préférence.

> 🧭 **En clair** — Choisir un entrepôt cloud, c'est comme choisir entre louer une voiture à la journée, payer un taxi au kilomètre ou prendre un abonnement d'autopartage. Snowflake et Databricks facturent surtout le **temps** pendant lequel le moteur tourne (la location : on éteint quand on ne s'en sert pas) ; BigQuery facture par défaut les **données lues** (le kilomètre) ; d'autres vendent une **capacité** réservée (l'abonnement). Aucun n'est « le moins cher » dans l'absolu : tout dépend de votre façon de rouler. Le data engineer est celui qui sait estimer le trajet avant de démarrer.

## 1. Une architecture commune : stockage et calcul séparés

Toutes ces plateformes reprennent l'idée de L156 : les données sont stockées en colonnes (souvent sur du stockage objet), et des **ressources de calcul indépendantes** les interrogent. On peut donc faire grossir l'un sans l'autre, et éteindre le calcul la nuit.

| Plateforme | Modèle | Ce qu'il faut retenir | Certification liée (préparation) |
|---|---|---|---|
| **Snowflake** | entrepôt managé (*managé* : le fournisseur gère serveurs, mises à jour et sauvegardes) ; *virtual warehouses* (grappes de calcul de tailles XS à 6XL) | séparation stockage/calcul, Time Travel, partage de données, type `VARIANT` pour le semi-structuré, fonctions d'IA (Cortex) | SnowPro Core COF-C03 |
| **BigQuery** | *serverless* (aucun serveur à dimensionner) | facturation à l'octet scanné ou en capacité réservée (*slots*) — un *slot* est une unité de puissance de calcul louée, partitionnement et clustering, BigQuery ML | Google Professional Data Engineer |
| **Databricks** | lakehouse sur Delta (et Iceberg), Unity Catalog | Spark + SQL warehouses, Lakeflow (Jobs, Declarative Pipelines), notebooks | Databricks Data Engineer Associate |
| **Amazon Redshift** | entrepôt AWS (provisionné ou serverless) | intégré à S3, Glue, Athena, EMR, Kinesis | AWS DEA-C01 |
| **Microsoft Fabric** | plateforme SaaS unifiée autour de OneLake | lakehouse, warehouse, Real-Time Intelligence, Power BI ; facturation par capacité | DP-700 |
| **ClickHouse** | moteur OLAP colonnaire open source (OLAP, *OnLine Analytical Processing* : conçu pour analyser beaucoup de lignes, par opposition à l'OLTP d'un ERP qui enregistre des transactions une à une) (auto-hébergé ou cloud) | très rapide sur l'analytique temps réel, tables `MergeTree` | — |
| **MotherDuck** | DuckDB managé dans le cloud | exécution hybride local + cloud, idéal pour les petits volumes | — |

> 💡 **À retenir** — Les certifications citées couvrent chacune **une** plateforme en profondeur. Le niveau 5 vous en donne les fondamentaux communs ; la préparation spécifique (services, consoles, limites propres à chaque fournisseur) reste à faire avec leurs parcours officiels.

## 2. Comprendre la facture

| Mode de facturation | Plateformes typiques | Ce qui fait monter la facture | Levier principal |
|---|---|---|---|
| **Au volume scanné** | BigQuery (à la demande), Athena | `SELECT *`, absence de partition, requêtes répétées | lire moins de colonnes et de partitions |
| **Au temps de calcul** | Snowflake (crédits), Databricks (DBU), Redshift Serverless (RPU) — trois noms maison pour une même idée : une unité de calcul consommée par heure | grappe trop grosse, jamais mise en veille | mise en veille automatique, bonne taille |
| **À la capacité réservée** | Fabric (capacités F), BigQuery (éditions), Redshift provisionné | capacité sous-utilisée ou saturée | dimensionner sur la charge réelle |
| **Stockage** | tous | historique (Time Travel, versions), copies | rétention adaptée, compression |

Les **prix unitaires** (crédit, DBU, To scanné, capacité) changent selon l'édition, la région et la date : consultez toujours la page de tarifs officielle du fournisseur le jour de votre estimation, et indiquez cette date dans votre devis.

### 2.1 Les leviers en SQL

> 🧭 **Pré-requis express** — Les blocs de cette section sont écrits dans le dialecte SQL de **chaque plateforme cloud** : ils ne s'exécutent pas dans DuckDB et demandent un compte sur la plateforme concernée (voir l'exercice). Lisez-les pour reconnaître les leviers. Ici, **clustering** ne désigne pas un groupe de machines : c'est le fait de **trier physiquement** les données selon quelques colonnes (`CLUSTER BY agence_id, produit_sk`) pour que les filtres sur ces colonnes lisent moins de blocs.

```sql
-- BigQuery : partitionner par jour et regrouper par agence/produit -> moins d'octets lus
-- (variante dénormalisée du fait_ventes gold de L155 : date_commande à la place de date_sk)
CREATE TABLE breval.fait_ventes (
  ligne_id INT64, date_commande TIMESTAMP, agence_id STRING, produit_sk INT64,
  client_sk INT64, quantite NUMERIC, ca_ht NUMERIC, marge_ht NUMERIC)
PARTITION BY DATE(date_commande)
CLUSTER BY agence_id, produit_sk
OPTIONS (require_partition_filter = TRUE);        -- interdit les requêtes sans filtre de date
```

```bash
# BigQuery : connaître le volume scanné AVANT d'exécuter (simulation, gratuite)
bq query --use_legacy_sql=false --dry_run \
  'SELECT agence_id, SUM(ca_ht) FROM breval.fait_ventes
   WHERE DATE(date_commande) BETWEEN "2026-01-01" AND "2026-03-31" GROUP BY agence_id'
```

> 🧭 **Pré-requis express** — La commande `bq` fait partie du **Google Cloud SDK** (outil `gcloud`), à installer puis à relier à votre projet (`gcloud init`) ; la table `breval.fait_ventes` doit exister dans ce projet.

> 🔍 **Ce que vous devez voir** — aucune donnée, seulement un message du type `Query successfully validated. Assuming the tables are not modified, running this query will process 1234567 bytes of data.` : c'est ce nombre d'octets qui sera facturé à la demande.

> 🛠️ **Si ça ne marche pas** — « Not found: Dataset … breval » → créez d'abord le jeu de données (`bq mk breval`) et la table. « Cannot query over table … without a filter over column(s) 'date_commande' » → c'est l'effet voulu de `require_partition_filter` : ajoutez un `WHERE` sur la date.

```sql
-- Snowflake : une petite grappe qui s'endort après 60 s d'inactivité et se réveille seule
CREATE WAREHOUSE wh_breval WITH WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE;

-- Snowflake : semi-structuré (VARIANT) et Time Travel
SELECT t.raw:ticket_id::STRING AS ticket_id, m.value:texte::STRING AS texte
FROM tickets_sav_raw t, LATERAL FLATTEN(input => t.raw:messages) m;
SELECT count(*) FROM commandes AT(OFFSET => -3600);        -- la table il y a une heure
```

*Lecture : `raw:ticket_id::STRING` signifie « dans la colonne `raw` (type `VARIANT`), prends le champ `ticket_id` et convertis-le en texte » ; `LATERAL FLATTEN` est l'équivalent Snowflake du `unnest` de DuckDB (L153) : une ligne par message.*

```sql
-- ClickHouse : l'ordre de tri de la table est la clé de performance
CREATE TABLE fait_ventes (date_commande DateTime, agence_id LowCardinality(String),
                          produit_sk UInt32, ca_ht Decimal(12, 2))
ENGINE = MergeTree ORDER BY (agence_id, date_commande);
```

*`LowCardinality(String)` indique à ClickHouse qu'une colonne n'a que peu de valeurs distinctes (3 agences), ce qui lui permet de la stocker sous forme de dictionnaire (L152).*

```python
# MotherDuck : la même base DuckDB, dans le cloud (jeton dans la variable MOTHERDUCK_TOKEN)
import duckdb
con = duckdb.connect("md:")                                 # authentification par variable d'environnement
con.sql("CREATE DATABASE IF NOT EXISTS breval")
con.sql("CREATE OR REPLACE TABLE breval.main.fait_ventes AS FROM 'data/gold/fait_ventes.parquet'")
```

> 🛠️ **Si ça ne marche pas** — « MotherDuck token not found » ou une fenêtre de connexion qui s'ouvre dans le navigateur → la variable `MOTHERDUCK_TOKEN` n'est pas définie : créez un jeton (*token*, une clé d'accès personnelle) dans les paramètres de votre compte MotherDuck, puis `export MOTHERDUCK_TOKEN=…` (PowerShell : `$env:MOTHERDUCK_TOKEN="…"`) dans le même terminal avant de lancer Python. Ne collez jamais ce jeton dans le code ni dans Git.

> ⚠️ **Piège fréquent** — Un `SELECT * … LIMIT 10` sur BigQuery facturé à la demande lit **toutes** les colonnes de toutes les partitions : le `LIMIT` ne réduit pas le volume scanné. Utilisez l'aperçu de table (gratuit) ou filtrez sur la partition.

> ⚠️ **Piège fréquent** — Laisser une grappe Snowflake ou un cluster Databricks tourner tout le week-end. La mise en veille automatique et des **alertes budgétaires** sont la première chose à configurer sur un compte, avant même la première table.

```quiz
{
  "q": "Sur BigQuery facturé au volume scanné, laquelle de ces modifications réduit le plus la facture d'une requête quotidienne « CA d'hier par agence » ?",
  "options": ["Partitionner la table par date et filtrer sur la date d'hier", "Ajouter LIMIT 100 pour ne renvoyer que les premières lignes", "Passer de SUM à AVG", "Trier le résultat par agence avec un ORDER BY"],
  "answer": 0,
  "explanation": "Avec une table partitionnée par jour, la requête ne lit qu'une partition sur environ mille (trois ans de données). LIMIT et ORDER BY ne changent pas le volume lu, ni le choix de la fonction d'agrégation."
}
```

## 3. Un calculateur de coût paramétré

```python
# breval/cout_plateformes.py — estimer un mois d'usage ; TOUS LES PRIX sont des paramètres à renseigner
from dataclasses import dataclass

@dataclass
class Usage:
    to_scannes_mois: float            # pour les modèles « au volume »
    heures_calcul_mois: float         # temps où la grappe est réellement allumée
    go_stockes: float

def cout_au_volume(u: Usage, prix_to: float, prix_go_mois: float) -> float:
    return u.to_scannes_mois * prix_to + u.go_stockes * prix_go_mois

def cout_au_temps(u: Usage, unites_par_heure: float, prix_unite: float, prix_go_mois: float) -> float:
    return u.heures_calcul_mois * unites_par_heure * prix_unite + u.go_stockes * prix_go_mois

def cout_capacite(prix_capacite_mois: float, u: Usage, prix_go_mois: float) -> float:
    return prix_capacite_mois + u.go_stockes * prix_go_mois

# Hypothèses Bréval : 3 analystes, ~200 requêtes/jour ouvré sur le gold (≈ 30 Mo lus chacune grâce aux partitions),
# un pipeline nocturne de 15 min, des tableaux de bord rafraîchis toutes les heures en journée.
usage_breval = Usage(to_scannes_mois=200 * 21 * 30e6 / 1e12, heures_calcul_mois=21 * (0.25 + 9 * 0.1), go_stockes=1)
print(f"Volume scanné estimé : {usage_breval.to_scannes_mois:.3f} To/mois ; calcul : {usage_breval.heures_calcul_mois:.1f} h/mois")
# Renseignez ci-dessous les prix relevés sur les pages officielles (date de relevé obligatoire) :
# print(cout_au_volume(usage_breval, prix_to=..., prix_go_mois=...))
# print(cout_au_temps(usage_breval, unites_par_heure=..., prix_unite=..., prix_go_mois=...))
```

> 🔍 **Ce que vous devez voir** — en lançant `python cout_plateformes.py` tel quel, une seule ligne : `Volume scanné estimé : 0.126 To/mois ; calcul : 24.1 h/mois`. Les deux dernières lignes sont en commentaire (`#`) : retirez le `#` et remplacez chaque `...` par un prix relevé, sinon Python affiche une erreur.

Pour Bréval, le volume scanné reste de l'ordre de **0,1 To par mois** et le calcul d'environ **25 heures** : les deux modèles donnent des montants faibles, et le premier coût réel sera… le temps humain d'administration. C'est un argument fort pour les solutions simples (DuckDB local, MotherDuck, BigQuery à la demande) tant que le volume reste modeste.

```mission
{
  "title": "Les domaines de l'examen Google Professional Data Engineer",
  "url": "https://cloud.google.com/certification/data-engineer",
  "steps": ["Ouvrez la page officielle de la certification Professional Data Engineer", "Repérez la durée, le nombre de questions et le prix", "Ouvrez le guide d'examen lié et repérez la section consacrée aux données pour l'IA et le ML"],
  "question": "Quels sont la durée, le nombre de questions et le prix de l'examen, et quel sous-domaine traite de la préparation des données pour l'IA ?",
  "hint": "Le sous-domaine est numéroté 4.2.",
  "answer": "2 heures, 40 à 50 questions, 200 $ (+ taxes) ; sous-domaine 4.2 « Preparing data for AI and ML » (page consultée en nov. 2026 ; tarifs et contenus susceptibles d'évoluer) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Choisir : une grille, pas un coup de cœur

| Critère | Question à poser | Bréval (échelle 1 aujourd'hui, ×10 dans 5 ans) |
|---|---|---|
| Volume et croissance | Combien de Go/To aujourd'hui, dans 3 ans ? | < 1 Go en Parquet, quelques Go à terme |
| Usages | BI, ML, IA générative, temps réel, partage externe ? | BI + RAG (M37) ; temps réel limité aux statuts de commande |
| Concurrence | Combien d'utilisateurs simultanés ? | moins de 10 |
| Modèle de coût | Charge régulière ou en pointes ? | pointes le matin, rien la nuit et le week-end |
| Compétences | SQL seulement ? Python/Spark ? | une personne data, SQL + Python |
| Écosystème | Microsoft 365 / Power BI, Google Workspace, AWS ? | à vérifier chez le client |
| Souveraineté et RGPD | Où sont les données, sous quel droit ? Hébergeur établi dans l'UE ? | données clients personnelles : hébergement UE exigé |
| Ouverture | Peut-on partir sans tout migrer ? (Iceberg/Delta, Parquet) | priorité forte (petite structure) |
| Gratuit pour apprendre | Offre gratuite ou bac à sable ? | Databricks Free Edition, BigQuery sandbox, DuckDB |

Exemples de recommandations argumentées :

- **Bréval aujourd'hui** : DuckDB + Parquet/Iceberg sur stockage objet hébergé dans l'UE, éventuellement MotherDuck pour partager ; coût quasi nul, réversibilité maximale.
- **Bréval avec Microsoft 365 et Power BI partout** : Fabric devient cohérent (OneLake, Power BI intégré), à condition de dimensionner la capacité au plus juste.
- **Un groupe de négoce de 2 000 salariés, data science et IA à l'échelle** : Databricks ou Snowflake, avec un catalogue ouvert et des tables Iceberg/Delta pour limiter le verrouillage.

> 💡 **Autrement dit** — La bonne plateforme est celle dont le **modèle de facturation ressemble à votre usage**, que votre équipe sait **exploiter**, et que vous pouvez **quitter** sans tout réécrire.

```quiz
{
  "q": "Une PME interroge ses données 2 heures par jour ouvré et jamais la nuit. Quel réglage est le plus important sur une plateforme facturée au temps de calcul ?",
  "options": ["La plus grande taille de grappe, pour finir les requêtes plus vite", "La réplication dans trois régions", "La désactivation du cache de résultats", "La mise en veille automatique après quelques minutes d'inactivité"],
  "answer": 3,
  "explanation": "Facturé au temps, un moteur allumé 24 h/24 coûte environ douze fois plus qu'un moteur allumé 2 h par jour. La mise en veille automatique (AUTO_SUSPEND chez Snowflake, arrêt automatique des clusters chez Databricks) est le premier levier."
}
```

## 🧪 Exercice pratique

> 🧭 **Pré-requis express** — Avant de créer un compte cloud : utilisez une offre **sans carte bancaire** quand elle existe (Databricks Free Edition, BigQuery sandbox), et sinon configurez une **alerte budgétaire** (par exemple 5 €) avant de charger la moindre table. Pour charger `fait_ventes`, le plus simple est l'import de fichier de l'interface web (bouton « Créer une table » / « Upload ») à partir de `data/gold/fait_ventes.parquet` : aucune ligne de commande n'est nécessaire.

**Consigne** — (1) Ouvrez un compte gratuit sur **une** plateforme (Databricks Free Edition ou BigQuery sandbox), chargez `fait_ventes` (gold, L155) et exécutez la requête « CA par agence et par mois » ; relevez le volume scanné ou le temps de calcul affiché. (2) Complétez `cout_plateformes.py` avec les tarifs officiels de deux plateformes (page et date de relevé). (3) Rédigez une note de recommandation d'une page pour le dirigeant de Bréval, à partir de la grille, avec un scénario « aujourd'hui » et un scénario « dans 5 ans ».

**Critères de réussite** — La requête tourne dans le cloud ; deux estimations sont chiffrées avec leurs sources datées ; la recommandation s'appuie sur au moins trois critères chiffrés (volume, coût, latence ou concurrence), conformément à la compétence C5.1, et traite la réversibilité.

**Pistes de corrigé** — Une bonne note commence par la conclusion (« DuckDB + Iceberg aujourd'hui, réévaluation au-delà de X Go ou Y utilisateurs »), fixe des **seuils de révision** chiffrés et chiffre le coût de sortie (migration des tables, des requêtes, des tableaux de bord).

## ✅ Auto-évaluation express
1. Citez trois modes de facturation des plateformes analytiques.
2. Pourquoi `LIMIT` ne réduit-il pas la facture sur BigQuery à la demande ?
3. Que vérifier en priorité pour la souveraineté des données ?

**Réponses** — 1. Au volume scanné, au temps de calcul (crédits, DBU, RPU), à la capacité réservée (sans oublier le stockage). 2. La facturation porte sur les octets lus par la requête, pas sur les lignes renvoyées ; le `LIMIT` s'applique après la lecture. 3. La localisation des données et des sauvegardes, le droit applicable au fournisseur, les sous-traitants et transferts hors UE, et les certifications de l'hébergeur.

## 📚 Pour aller plus loin
- [Snowflake](https://docs.snowflake.com/) 🇬🇧 · [BigQuery](https://cloud.google.com/bigquery/docs) 🇬🇧 · [Databricks](https://docs.databricks.com/) 🇬🇧 · [Redshift](https://docs.aws.amazon.com/redshift/) 🇬🇧 · [Fabric](https://learn.microsoft.com/fabric/) · [ClickHouse](https://clickhouse.com/docs) 🇬🇧 · [MotherDuck](https://motherduck.com/docs/) 🇬🇧 — documentations officielles.
- [Databricks Free Edition](https://www.databricks.com/blog/learn-experiment-and-build-databricks-free-edition) 🇬🇧 — environnement gratuit pour pratiquer.
- [SnowPro Core COF-C03](https://learn.snowflake.com/en/certifications/snowpro-core-c03) 🇬🇧 — certification Snowflake, lancée en février 2026.

> ✅ **Si vous ne retenez que 3 choses** — 1. Toutes les plateformes séparent stockage et calcul ; elles diffèrent surtout par leur **modèle de facturation** : au volume scanné (BigQuery à la demande), au temps de calcul (Snowflake, Databricks), à la capacité réservée (Fabric). 2. Les leviers d'économie tiennent en quelques lignes : partitionner et trier (clustering), lire peu de colonnes, filtrer sur la partition, mettre en veille automatiquement, poser des alertes budgétaires ; et toujours estimer avant d'exécuter (`--dry_run`). 3. On choisit avec une grille (volume, usages, coût, compétences, souveraineté, réversibilité), en datant les prix relevés sur les pages officielles : pour Bréval aujourd'hui, DuckDB + Parquet/Iceberg suffit.

> 🗺️ **Et maintenant ?** — Derrière Databricks, Fabric et bien d'autres tourne le même moteur : Apache Spark. En L159, vous l'installez sur votre poste et apprenez à lire ses plans pour éviter les shuffles inutiles.
