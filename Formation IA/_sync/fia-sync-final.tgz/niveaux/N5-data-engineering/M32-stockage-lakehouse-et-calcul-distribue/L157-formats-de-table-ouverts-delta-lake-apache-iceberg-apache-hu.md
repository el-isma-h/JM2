---
id: L157
module: M32
level: N5
title: "Formats de table ouverts : Delta Lake, Apache Iceberg, Apache Hudi, time travel et catalogues REST (Unity Catalog, Polaris)"
minutes: 55
objectives:
  - "Expliquer ce qu'un format de table ajoute à des fichiers Parquet (transactions ACID, schéma, snapshots, suppressions, MERGE)"
  - "Décrire la structure interne de Delta Lake (journal _delta_log), d'Apache Iceberg (métadonnées, manifest lists, manifests) et d'Apache Hudi (timeline, copy-on-write / merge-on-read)"
  - "Appliquer en local écriture, MERGE, time travel, évolution de schéma et maintenance (compaction, vacuum) sur des tables Delta et Iceberg de Bréval"
  - "Comparer les trois formats et le rôle des catalogues (Iceberg REST, Unity Catalog, Apache Polaris) pour choisir une architecture"
skills: ["C5.1", "C5.3"]
sources:
  - { title: "RisingWave — Apache Iceberg vs Delta Lake vs Apache Hudi (2026)", url: "https://risingwave.com/blog/apache-iceberg-vs-delta-lake-vs-hudi-2026/", lang: "en" }
  - { title: "Data Lakehouse Hub — Metadata Platforms in 2026", url: "https://datalakehousehub.com/blog/metadata-platforms-in-2026/", lang: "en" }
  - { title: "Delta Lake — documentation", url: "https://delta.io/", lang: "en" }
  - { title: "Apache Iceberg — documentation", url: "https://iceberg.apache.org/", lang: "en" }
  - { title: "Apache Hudi — documentation", url: "https://hudi.apache.org/", lang: "en" }
  - { title: "Unity Catalog (open source)", url: "https://www.unitycatalog.io/", lang: "en" }
  - { title: "Apache Polaris", url: "https://polaris.apache.org/", lang: "en" }
  - { title: "PyIceberg — documentation", url: "https://py.iceberg.apache.org/", lang: "en" }
---

# Formats de table ouverts : Delta Lake, Apache Iceberg, Apache Hudi

> ⏱ 55 min · 🎯 Niveau 5 · 📚 Module 32

## 🎯 Ce que vous saurez faire
- Expliquer pourquoi « un dossier de fichiers Parquet » n'est pas une table, et ce qui en fait une.
- Créer des tables Delta et Iceberg pour Bréval, y appliquer un `MERGE`, revenir à une version d'hier et ajouter une colonne sans réécrire les données.
- Lire le journal d'une table pour savoir **qui a changé quoi, quand**.
- Choisir entre Delta, Iceberg et Hudi, et comprendre le rôle d'un catalogue.

> 🧭 **En clair** — Un dossier de fichiers Parquet ressemble à une pile de classeurs sans sommaire : si quelqu'un ajoute un classeur pendant que vous comptez, ou en retire un à moitié, vous ne savez plus ce qui fait foi. Un format de table ajoute un **registre** tenu à jour : « la table, à la version 12, c'est exactement ces 40 fichiers ». Chaque modification écrit de nouveaux fichiers puis une nouvelle page du registre, d'un seul coup. Résultat : on ne voit jamais une table à moitié modifiée, et on peut relire n'importe quelle page ancienne du registre pour voir la table telle qu'elle était hier. C'est le *time travel*.

## 1. Le problème : des fichiers ne font pas une table

Sur le stockage objet de L156, la couche silver de Bréval est un ensemble de fichiers. Trois situations tournent mal :

1. **Écriture concurrente** : le pipeline nocturne réécrit `commandes` pendant qu'un analyste lance une requête. Il lit un mélange d'anciens et de nouveaux fichiers.
2. **Mise à jour** : appliquer `clients_maj_2026-11-01` impose de réécrire tout le fichier, car un objet Parquet est immuable.
3. **Erreur** : un script supprime par erreur les commandes de 2025. Rien ne permet de revenir en arrière (sauf le versioning objet, fichier par fichier).

Un **format de table ouvert** résout ces trois problèmes avec des **métadonnées** stockées à côté des fichiers de données :

| Capacité | Ce que cela permet chez Bréval |
|---|---|
| Transactions ACID | une écriture est visible entièrement ou pas du tout |
| Snapshots / versions | relire la table « telle qu'elle était le 31 octobre » (*time travel*), auditer un chiffre |
| `MERGE`, `UPDATE`, `DELETE` | appliquer la mise à jour des clients, un droit à l'effacement RGPD |
| Évolution de schéma | ajouter la colonne `canal_detail` sans réécrire 3 ans de données |
| Statistiques et partitionnement | sauter des fichiers entiers à la lecture |
| Ouverture | plusieurs moteurs (Spark, DuckDB, Trino, Snowflake, BigQuery…) lisent la même table |

*ACID = Atomicité (tout ou rien), Cohérence (la table reste valide), Isolation (deux écritures simultanées ne se mélangent pas), Durabilité (ce qui est écrit le reste). Un **snapshot** est une « photo » de la table à un instant donné.*

> 💡 **À retenir** — Les données restent du **Parquet** ; le format de table est une couche de métadonnées par-dessus. Changer de moteur ne demande pas de copier les données.

## 2. Comment ça marche, format par format

### 2.1 Delta Lake : un journal de transactions

Une table Delta est un dossier contenant les fichiers Parquet et un sous-dossier **`_delta_log/`** de fichiers JSON numérotés (`00000000000000000000.json`, `…01.json`). Chaque fichier est un **commit** listant des actions (un *commit* est une modification validée d'un seul bloc, comme dans Git) : « ajouter tel fichier », « retirer tel fichier », « changer le schéma ». Tous les dix commits environ, un **checkpoint** Parquet résume l'état pour éviter de relire tout l'historique. L'état de la table à la version *n* est l'application des commits 0 à *n*. Delta est le format natif de Databricks et le plus intégré à Spark ; sa fonction **UniForm** écrit aussi des métadonnées compatibles Iceberg.

### 2.2 Apache Iceberg : un arbre de métadonnées

Iceberg (né chez Netflix) organise les métadonnées en arbre :

```
catalogue ──▶ metadata.json (version courante : schéma, partitionnement, liste des snapshots)
                  └─▶ snapshot ──▶ manifest list (une ligne par manifest, avec bornes de partition)
                                      └─▶ manifest ──▶ fichiers de données Parquet
                                                       (+ statistiques par colonne : min, max, nuls)
```

Le **catalogue** connaît seulement l'emplacement du `metadata.json` courant ; un commit consiste à remplacer atomiquement ce pointeur (en une seule opération indivisible : soit l'ancien emplacement, soit le nouveau, jamais un état intermédiaire). Deux fonctions distinguent Iceberg : le **partitionnement caché** (*hidden partitioning* : on déclare `months(date_commande)`, l'utilisateur filtre simplement sur `date_commande`, sans colonne `mois` à connaître) et l'**évolution du partitionnement** (passer de mensuel à quotidien sans réécrire l'historique). Iceberg dispose de la **prise en charge multi-moteurs la plus large** et d'une spécification de **catalogue REST** standardisée.

### 2.3 Apache Hudi : une timeline pour les upserts

Hudi (né chez Uber) maintient une **timeline** des actions et propose deux modes : *copy-on-write* (chaque mise à jour réécrit le fichier Parquet concerné : lecture rapide) et *merge-on-read* (les mises à jour vont dans des journaux de delta, fusionnés à la lecture puis compactés : écriture rapide). Il excelle sur les **upserts fréquents** (*upsert* = *update* + *insert* : mettre à jour si la ligne existe, l'insérer sinon, comme le `MERGE` de L153) et l'ingestion en flux, avec un index par enregistrement ; la version 1.1 ajoute une prise en charge native du format Iceberg (selon le comparatif RisingWave de mars 2026).

| Critère (comparatif tiers, mars 2026) | Delta Lake | Apache Iceberg | Apache Hudi |
|---|---|---|---|
| Point fort | intégration Spark / Databricks | ouverture multi-moteurs, spécification V3 mature (Iceberg 1.10) | upserts fréquents, streaming le plus mature (DeltaStreamer) |
| Métadonnées | journal JSON + checkpoints | arbre metadata → manifests | timeline |
| Partitionnement caché / évolutif | non (colonnes générées, *liquid clustering*) | **oui** | non |
| Catalogue standard | Unity Catalog | **REST catalog** (Polaris, Unity Catalog, Glue…) | Hive Metastore, catalogues tiers |

```quiz
{
  "q": "Dans Apache Iceberg, que fait concrètement un commit ?",
  "options": ["Il modifie en place les fichiers Parquet concernés, ligne par ligne", "Il écrit de nouveaux fichiers puis bascule atomiquement le pointeur du catalogue", "Il envoie un message Kafka à tous les lecteurs pour qu'ils rechargent la table", "Il verrouille le bucket S3 tant que des lectures sont en cours"],
  "answer": 1,
  "explanation": "Les fichiers sont immuables : on écrit à côté, puis on bascule le pointeur en une opération atomique. Les lecteurs voient soit l'ancien snapshot, soit le nouveau, jamais un état intermédiaire."
}
```

## 3. Atelier Delta Lake (delta-rs, sans Spark)

La bibliothèque **delta-rs** (paquet Python `deltalake`) lit et écrit des tables Delta sans JVM (la machine virtuelle Java dont Spark a besoin : ici, rien à installer en plus de Python) ; Polars et DuckDB savent s'en servir.

```bash
pip install deltalake "pyiceberg[sql-sqlite,pyarrow]" polars duckdb
```

> 🔍 **Ce que vous devez voir** — `Successfully installed deltalake-… pyiceberg-… sqlalchemy-…` (polars et duckdb sont déjà présents). Les crochets `[sql-sqlite,pyarrow]` installent des options de PyIceberg ; les guillemets évitent que votre terminal (zsh sur macOS notamment) ne les interprète.

```python
# breval/lakehouse_delta.py
from datetime import datetime
import duckdb
import polars as pl
from deltalake import DeltaTable

CMD = "lakehouse/delta/commandes"
commandes = pl.read_parquet("data/silver/commandes.parquet")

# Version 0 : 2024-2025 ; version 1 : ajout de 2026
commandes.filter(pl.col("date_commande") < datetime(2026, 1, 1)).write_delta(CMD, mode="overwrite")
commandes.filter(pl.col("date_commande") >= datetime(2026, 1, 1)).write_delta(CMD, mode="append")

dt = DeltaTable(CMD)
print("version courante :", dt.version())                     # 1
for h in dt.history():                                       # du plus récent au plus ancien
    print(h.get("version"), h.get("operation"), h.get("operationParameters"))

# Time travel : la table telle qu'elle était à la version 0
print(pl.read_delta(CMD, version=0).height, "commandes en version 0")
print(pl.read_delta(CMD).height, "commandes aujourd'hui")

# MERGE des clients (même logique qu'en L153, mais sur une table de fichiers)
CLI = "lakehouse/delta/clients"
pl.read_parquet("data/silver/clients.parquet").write_delta(CLI, mode="overwrite")
maj = pl.read_parquet("data/silver/clients_maj_2026_11_01.parquet").to_arrow()
resultat = (DeltaTable(CLI).merge(source=maj, predicate="t.client_id = s.client_id",
                                  source_alias="s", target_alias="t")
            .when_matched_update_all(predicate="s.mis_a_jour_le > t.mis_a_jour_le")
            .when_not_matched_insert_all()
            .execute())
print(resultat)                                              # nombre de lignes mises à jour / insérées

# Droit à l'effacement (RGPD) : suppression logique… puis physique
DeltaTable(CLI).delete("client_id = 4388")
print(DeltaTable(CLI).vacuum(retention_hours=168, dry_run=True)[:3])  # fichiers qui seraient purgés

# DuckDB lit la même table (extension delta)
print(duckdb.sql(f"SELECT statut, count(*) FROM delta_scan('{CMD}') GROUP BY ALL"))
```

> 🧭 **Pré-requis express** — Enregistrez ce script sous `breval/lakehouse_delta.py` et lancez-le depuis `breval/` (il lit `data/silver/`, produit en L155).

> 🔍 **Ce que vous devez voir** — `version courante : 1`, puis deux lignes d'historique (version 1 en `WRITE` mode `Append`, version 0 en `WRITE` ou `CREATE TABLE` mode `Overwrite`), un nombre de commandes en version 0 inférieur au total d'aujourd'hui (**119 989**), un dictionnaire de résultat du `MERGE` contenant notamment `'num_target_rows_updated': 200` et `'num_target_rows_inserted': 50`, une courte liste de chemins `….parquet` (les fichiers que `VACUUM` purgerait), et enfin un tableau `statut | count_star()` à cinq lignes.

> 🛠️ **Si ça ne marche pas** — La version affichée vaut 3, 5… au lieu de 1 → vous avez relancé le script : chaque `overwrite` ou `append` crée une nouvelle version. Pour repartir de zéro, supprimez le dossier `lakehouse/delta/` puis relancez. « Catalog Error: Table Function with name delta_scan does not exist » → DuckDB n'a pas pu télécharger l'extension `delta` : vérifiez votre connexion Internet, ou lancez `duckdb.sql("INSTALL delta; LOAD delta;")` une fois. La liste du `vacuum` est vide → normal si moins de 168 heures se sont écoulées : `dry_run=True` ne liste que les fichiers plus vieux que la rétention.

Ouvrez `lakehouse/delta/commandes/_delta_log/` : deux fichiers JSON, un par commit. Ouvrez le second : vous y lirez des actions `add` avec le chemin de chaque nouveau fichier Parquet, sa taille et ses statistiques.

> ⚠️ **Piège fréquent** — Croire qu'un `DELETE` efface la donnée. Il retire le fichier du **journal** ; le fichier physique reste (c'est ce qui permet le time travel) jusqu'à un `VACUUM` après le délai de rétention. (la **rétention** est la durée minimale pendant laquelle les anciens fichiers sont gardés : 7 jours, soit 168 heures, par défaut chez Delta) Pour un droit à l'effacement RGPD, la procédure doit inclure le `VACUUM` (et la purge des versions objet si le versioning S3 est actif) : documentez-la dans le registre des traitements.

> 💡 **Autrement dit** — Supprimer dans un format de table, c'est rayer une ligne du sommaire ; le classeur reste au fond de l'armoire tant qu'on ne vide pas l'armoire (`VACUUM`). Le time travel n'est possible que tant que l'armoire n'a pas été vidée.

## 4. Atelier Apache Iceberg (PyIceberg + catalogue SQLite)

En production, Iceberg s'utilise avec un catalogue (REST, Glue, Polaris…). Pour apprendre, **PyIceberg** propose un catalogue SQL qui tient dans un fichier SQLite. (SQLite est une petite base de données contenue dans un seul fichier, ici `lakehouse/iceberg/catalogue.db`.) Un **namespace** (`silver`) est un simple regroupement de tables, comme un schéma SQL.

```python
# breval/lakehouse_iceberg.py
from pathlib import Path
import duckdb
from pyiceberg.catalog.sql import SqlCatalog
from pyiceberg.exceptions import NamespaceAlreadyExistsError
from pyiceberg.expressions import EqualTo
from pyiceberg.types import StringType

ENTREPOT = Path("lakehouse/iceberg").absolute()
ENTREPOT.mkdir(parents=True, exist_ok=True)
catalogue = SqlCatalog("breval", uri=f"sqlite:///{ENTREPOT}/catalogue.db", warehouse=f"file://{ENTREPOT}")
try:
    catalogue.create_namespace("silver")
except NamespaceAlreadyExistsError:
    pass

def arrow(requete: str):
    res = duckdb.sql(requete).arrow()
    return res.read_all() if hasattr(res, "read_all") else res   # selon la version de DuckDB

avant_2026 = arrow("FROM 'data/silver/commandes.parquet' WHERE date_commande < TIMESTAMP '2026-01-01'")
table = catalogue.create_table_if_not_exists("silver.commandes", schema=avant_2026.schema)
if table.current_snapshot() is None:
    table.append(avant_2026)                                            # snapshot 1
    table.append(arrow("FROM 'data/silver/commandes.parquet' WHERE date_commande >= TIMESTAMP '2026-01-01'"))
    table.delete(delete_filter=EqualTo("statut", "brouillon"))         # snapshot 3 : on retire les brouillons

for s in table.snapshots():
    print(s.snapshot_id, s.timestamp_ms, s.summary.operation if s.summary else None)

premier = table.snapshots()[0].snapshot_id
print(table.scan(snapshot_id=premier).to_arrow().num_rows, "lignes au premier snapshot")
print(table.scan().to_arrow().num_rows, "lignes aujourd'hui")

# Évolution de schéma : ajout d'une colonne, sans réécrire un seul fichier de données
with table.update_schema() as maj_schema:
    maj_schema.add_column("canal_detail", StringType(), doc="précision du canal (nouvel outil caisse)")
print(table.schema())

# DuckDB lit la table à partir de son fichier de métadonnées courant (extension iceberg)
meta = table.metadata_location.removeprefix("file://")
print(duckdb.sql(f"SELECT count(*) FROM iceberg_scan('{meta}')"))
```

> 🔍 **Ce que vous devez voir** — trois lignes de snapshots (identifiant numérique, horodatage en millisecondes, opération `append`, `append` puis `delete` ou `overwrite`), le nombre de lignes au premier snapshot (commandes avant 2026) puis aujourd'hui (sans les brouillons), un schéma listant les colonnes avec, en dernier, `canal_detail: optional string`, et enfin un tableau `count_star()` égal au nombre de lignes « aujourd'hui ». Relancer le script n'ajoute pas de snapshot : le test `if table.current_snapshot() is None` l'en empêche.

> 🛠️ **Si ça ne marche pas** — Au second lancement, une erreur du type « Cannot add column, name already exists: canal_detail » → c'est l'évolution de schéma qui ne peut pas ajouter deux fois la même colonne : supprimez `lakehouse/iceberg/` pour tout rejouer, ou mettez les trois lignes `with table.update_schema()…` en commentaire. « NoSuchTableError » ou « NamespaceAlreadyExistsError » non capturée → le fichier `catalogue.db` et les dossiers ne correspondent plus (dossier supprimé à la main) : supprimez tout `lakehouse/iceberg/` et relancez. « Table Function with name iceberg_scan does not exist » → même remède que pour `delta_scan` : `INSTALL iceberg; LOAD iceberg;`.

> 🧭 **Pré-requis express** — Le bloc SQL suivant est une **illustration à lire**, pas à exécuter : il suppose un cluster Spark configuré avec un catalogue Iceberg nommé `lac`, que vous n'avez pas encore. Retenez la syntaxe ; vous pourrez l'essayer après L159.

Le partitionnement caché et son évolution s'expriment le plus simplement en SQL, par exemple avec Spark (L159) et les extensions Iceberg :

```sql
-- Spark SQL avec le catalogue Iceberg configuré (illustration)
CREATE TABLE lac.silver.commandes (commande_id BIGINT, date_commande TIMESTAMP, montant_ht DECIMAL(12,2), agence_id STRING)
USING iceberg
PARTITIONED BY (months(date_commande));                    -- partitionnement caché : aucune colonne « mois »

SELECT sum(montant_ht) FROM lac.silver.commandes
WHERE date_commande >= TIMESTAMP '2026-03-01';              -- l'utilisateur filtre sur la vraie colonne

ALTER TABLE lac.silver.commandes ADD PARTITION FIELD days(date_commande);   -- évolution, sans réécriture
SELECT * FROM lac.silver.commandes VERSION AS OF 1234567890123;            -- time travel par snapshot
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : après `add_column(\"canal_detail\")` sur la table Iceberg, tous les fichiers Parquet existants sont réécrits avec une colonne vide.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : l'évolution de schéma ne modifie que les métadonnées. Iceberg identifie les colonnes par un identifiant interne ; les anciens fichiers, qui n'ont pas la colonne, renvoient simplement NULL à la lecture."
}
```

## 5. Catalogues : qui sait où sont les tables ?

Un moteur doit savoir que `silver.commandes` correspond à tel emplacement et telle version courante : c'est le rôle du **catalogue technique**. Historiquement, le **Hive Metastore** (la base de métadonnées de l'écosystème Hadoop, L156) ; aujourd'hui, la spécification **Iceberg REST catalog** permet à n'importe quel moteur de parler à n'importe quel catalogue compatible.

| Catalogue | Statut 2026 (synthèse tierce, mi-2026) | Formats |
|---|---|---|
| **Unity Catalog** (OSS) | open source depuis 2024, hébergé par LF AI & Data ; la version Databricks ajoute lignage, tags, gouvernance avancée | Delta et Iceberg, endpoint Iceberg REST |
| **Apache Polaris** | projet Apache de premier niveau depuis février 2026 (selon la même source) ; RBAC, fédération | Iceberg uniquement |
| Apache Gravitino | fédération de plusieurs catalogues | multiples |
| AWS Glue, Snowflake Horizon, BigQuery… | catalogues des plateformes cloud, souvent compatibles Iceberg REST | selon fournisseur |

*RBAC (*Role-Based Access Control*) = droits attribués à des rôles (« analyste », « data engineer ») plutôt qu'à chaque personne ; **fédération** = un catalogue qui en regroupe plusieurs sous une seule vue. Trino, cité plus haut, est un moteur SQL open source qui interroge des données là où elles sont.*

La gouvernance au-delà du catalogue technique (glossaire, lignage de bout en bout, propriétaires des données) est l'objet de M35 (OpenMetadata, DataHub, OpenLineage).

> ⚠️ **Piège fréquent** — Laisser deux catalogues écrire la même table Iceberg. Chaque catalogue croit détenir le pointeur courant : les commits de l'un écrasent ceux de l'autre. Une table = un catalogue « maître » en écriture ; les autres lisent.

```mission
{
  "title": "Ce que le comparatif 2026 dit du streaming et des versions",
  "url": "https://risingwave.com/blog/apache-iceberg-vs-delta-lake-vs-hudi-2026/",
  "steps": ["Ouvrez le comparatif Iceberg vs Delta Lake vs Hudi (2026) de RisingWave", "Repérez la version d'Iceberg citée et l'état de sa spécification", "Repérez le format jugé le plus mature pour le streaming et l'outil associé"],
  "question": "Quelle version d'Iceberg et quelle version de spécification sont citées, et quel format est présenté comme le plus mature pour le streaming ?",
  "hint": "Il s'agit d'un article tiers daté de mars 2026, à lire avec recul.",
  "answer": "Iceberg 1.10 (2025) avec la spécification V3 arrivée à maturité ; Hudi est jugé le plus mature pour le streaming (DeltaStreamer) — article du 20 mars 2026, source tierce (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne** — (1) Exécutez les deux ateliers. (2) Sur la table Delta `clients`, retrouvez par time travel la ville du client que vous avez supprimé, puis exécutez un `VACUUM` réel avec une rétention de 0 heure (`enforce_retention_duration=False`) et constatez que le time travel ne fonctionne plus. (3) Sur la table Iceberg, retrouvez via `table.inspect.snapshots()` (ou `table.snapshots()`) le nombre de lignes ajoutées par chaque snapshot. (4) Rédigez une recommandation d'une demi-page : « Bréval doit-il choisir Delta ou Iceberg ? », avec au moins trois critères.

**Critères de réussite** — Le `MERGE` signale 200 lignes mises à jour (toutes plus récentes) et 50 insertions ; la démonstration du `VACUUM` est faite ; la recommandation cite l'outillage (moteurs utilisés), le catalogue envisagé et l'exigence RGPD d'effacement.

**Pistes de corrigé** — Pour une PME sans Databricks, qui veut garder DuckDB en local et pouvoir passer plus tard à Snowflake ou BigQuery, **Iceberg** est un choix robuste (multi-moteurs, catalogue REST). Si l'équipe adopte Databricks (Free Edition pour se former), **Delta** est le chemin naturel, et UniForm limite le verrouillage.

## ✅ Auto-évaluation express
1. Où sont stockées les données d'une table Delta ou Iceberg ?
2. Qu'est-ce que le partitionnement caché ?
3. Pourquoi un `DELETE` ne suffit-il pas pour un effacement RGPD ?

**Réponses** — 1. Dans des fichiers Parquet ordinaires ; le format ajoute seulement des métadonnées (journal ou arbre de manifests). 2. Le partitionnement est déclaré comme une transformation d'une colonne (`months(date_commande)`) ; l'utilisateur filtre sur la colonne d'origine et le moteur en déduit les partitions à lire. 3. Les fichiers supprimés logiquement restent lisibles par time travel jusqu'au `VACUUM` (ou à l'expiration des snapshots chez Iceberg) ; il faut purger physiquement, y compris les versions du stockage objet.

## 📚 Pour aller plus loin
- [Delta Lake](https://delta.io/) 🇬🇧 — protocole, delta-rs, UniForm.
- [Apache Iceberg](https://iceberg.apache.org/) 🇬🇧 — spécification, catalogue REST, partitionnement caché.
- [PyIceberg](https://py.iceberg.apache.org/) 🇬🇧 — l'API Python utilisée dans l'atelier.
- [Apache Hudi](https://hudi.apache.org/) 🇬🇧 — copy-on-write, merge-on-read, timeline.
- [Data Lakehouse Hub — Metadata Platforms in 2026](https://datalakehousehub.com/blog/metadata-platforms-in-2026/) 🇬🇧 — panorama des catalogues (source tierce).
- [Unity Catalog](https://www.unitycatalog.io/) 🇬🇧 · [Apache Polaris](https://polaris.apache.org/) 🇬🇧 — deux catalogues ouverts.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un format de table ouvert (Delta, Iceberg, Hudi) = des fichiers Parquet ordinaires + des métadonnées (journal ou arbre de snapshots) qui apportent transactions, `MERGE`/`DELETE`, évolution de schéma et time travel. 2. Un `DELETE` ne fait que rayer des fichiers du registre : pour un effacement RGPD réel, il faut aussi `VACUUM` (ou l'expiration des snapshots) et la purge des versions du stockage objet. 3. Le catalogue sait où se trouve la version courante de chaque table ; Iceberg brille par l'ouverture multi-moteurs (catalogue REST), Delta par l'intégration Spark/Databricks, Hudi par les upserts fréquents.

> 🗺️ **Et maintenant ?** — Vous savez construire un lakehouse ouvert sur votre poste ; L158 regarde les plateformes qui le vendent « clés en main » (Snowflake, BigQuery, Databricks…) et vous apprend à les comparer et à les chiffrer.
