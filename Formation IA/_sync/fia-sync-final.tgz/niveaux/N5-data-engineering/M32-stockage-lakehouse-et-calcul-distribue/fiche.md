---
module: M32
title: "Fiche mémo — Stockage, lakehouse et calcul distribué"
---
# Fiche mémo — M32 · Stockage, lakehouse et calcul distribué

> En une phrase : on stocke tout en Parquet dans un stockage objet, on ajoute un registre (Delta, Iceberg) pour en faire de vraies tables, et on choisit le plus petit moteur qui suffit : DuckDB ou Polars avant Spark.

## Les 7 idées à retenir
1. Hadoop déplaçait le calcul vers les données. Aujourd'hui, on sépare le stockage (objet) et le calcul (moteurs élastiques) : c'est la base du lakehouse (`L156`).
2. Un « dossier » S3 n'est qu'un préfixe de clé, et un objet est immuable. Une facture = stockage + requêtes PUT/GET + sortie réseau (egress). Le stockage coûte peu, le calcul et l'egress coûtent cher (`L156`).
3. Map → shuffle → reduce : le shuffle traverse le réseau, c'est l'étape chère. Chez Spark, il s'appelle `Exchange` (`L156`, `L159`).
4. Un format de table ajoute des métadonnées au Parquet : transactions ACID, time travel, `MERGE`/`DELETE`, évolution de schéma. Delta = journal `_delta_log/`, Iceberg = arbre metadata → manifests, Hudi = timeline (`L157`).
5. Les plateformes cloud facturent au volume scanné (BigQuery), au temps de calcul (Snowflake, Databricks) ou à la capacité (Fabric). Les leviers : partitionner, clustering, mise en veille automatique, dry run (`L158`).
6. Spark est paresseux : les transformations construisent un plan, les actions l'exécutent. Le broadcast d'une petite table évite le shuffle de la grande. L'AQE fusionne les partitions, convertit en broadcast et gère le skew (`L159`).
7. Polars lazy par défaut, DuckDB avec débordement sur disque. Règle : DuckDB ou Polars jusqu'à quelques centaines de Go, Spark, Ray ou un entrepôt cloud au-delà, avec un seuil de révision écrit (`L160`).

## Le schéma à connaître
```mermaid
flowchart TB
    C["Catalogue (REST, Polaris, Unity)"] --> M["metadata.json courant"]
    M --> S["snapshot"]
    S --> ML["manifest list"]
    ML --> MF["manifests (min, max, nuls)"]
    MF --> P["fichiers Parquet immuables"]
```
Un commit écrit de nouveaux fichiers, puis bascule atomiquement le pointeur du catalogue.

## Vocabulaire express
| Terme | En clair |
|---|---|
| Partition pruning | Le filtre sur `annee`/`mois` saute des dossiers entiers |
| Time travel | Relire la table telle qu'elle était à une version donnée |
| Partitionnement caché | On déclare `months(date_commande)` et l'utilisateur filtre sur la vraie colonne |
| `VACUUM` | Purge physique des fichiers retirés du journal |
| Transformation large | `groupBy`, `join`, `orderBy`, `distinct` : elle provoque un shuffle |
| Skew | Une clé énorme qui retient une seule tâche. Remèdes : AQE ou salting |
| Spark Connect | Client léger qui envoie des plans au serveur (gRPC, port 15002) |
| Spill | DuckDB déborde sur disque au lieu de planter |

## Les pièges classiques
- Créer des millions de petits fichiers, ou partitionner par `client_id`. On vise des Parquet de quelques centaines de Mo.
- Croire qu'un `DELETE` efface la donnée : elle reste lisible jusqu'au `VACUUM`. Pour le RGPD, il faut aussi purger les versions objet.
- Laisser deux catalogues écrire la même table Iceberg.
- Ajouter `LIMIT 10` sur BigQuery pour payer moins : le volume lu ne change pas.
- Laisser une grappe tourner tout le week-end, sans alerte budgétaire.
- Forcer `F.broadcast()` sur une table de plusieurs Go : on obtient un OutOfMemory.
- Utiliser `df.rdd` ou `spark.sparkContext` en Spark Connect.
- Écrire `.collect()` ou `.to_pandas()` au milieu d'une chaîne Polars.
- Recopier un tarif cloud d'un article au lieu de lire la page officielle du jour.

## Les commandes / chiffres / dates utiles
```sql
-- DuckDB sur MinIO : INSTALL httpfs; LOAD httpfs; CREATE SECRET minio (TYPE s3, ENDPOINT 'localhost:9000', URL_STYLE 'path', ...)
COPY (...) TO 's3://breval-lake/silver/commandes' (FORMAT parquet, PARTITION_BY (annee, mois));
SELECT * FROM read_parquet('s3://breval-lake/silver/commandes/*/*/*.parquet', hive_partitioning = true);
SELECT * FROM delta_scan('lakehouse/delta/commandes');      SELECT * FROM iceberg_scan('<metadata.json>');
SET memory_limit = '2GB'; SET temp_directory = 'tmp_duckdb'; SET preserve_insertion_order = false;
CREATE WAREHOUSE wh_breval WITH WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE;  -- Snowflake
PARTITION BY DATE(date_commande) CLUSTER BY agence_id, produit_sk                                 -- BigQuery
```
```python
pl.read_delta(CMD, version=0)                      # time travel Delta (delta-rs, sans Spark)
DeltaTable(CLI).merge(...).when_matched_update_all(...).when_not_matched_insert_all().execute()
DeltaTable(CLI).vacuum(retention_hours=168, dry_run=True)
table.scan(snapshot_id=premier).to_arrow()         # time travel PyIceberg
with table.update_schema() as m: m.add_column("canal_detail", StringType())   # sans réécrire les données
lignes.join(F.broadcast(produits), "produit_id"); ca.explain(mode="formatted")
pl.scan_parquet(...).collect(engine="streaming"); .sink_parquet(...)
```
```bash
bq query --use_legacy_sql=false --dry_run '...'     # volume scanné avant exécution
$SPARK_HOME/sbin/start-connect-server.sh            # SparkSession.builder.remote("sc://localhost:15002")
```
- **Spark** : `spark.sql.shuffle.partitions` = 200 par défaut, broadcast auto sous 10 Mo (`autoBroadcastJoinThreshold`), UI sur `localhost:4040`. AQE par défaut depuis la 3.2, Spark Connect depuis la 3.4, Spark 4 (2025) : ANSI par défaut, Java 17+. Doc PySpark « latest » 4.3.0 (nov. 2026).
- **Versions 2026** : Iceberg 1.10 (spéc. V3), Hudi 1.1, Apache Polaris projet de premier niveau depuis février 2026, Ray 2.60.0 (`ray.data.llm` : vLLM, SGLang, `build_processor`), SnowPro Core COF-C03 (février 2026).
- **HDFS** : blocs de 128 Mo répliqués 3 fois. **MinIO** : API sur le port 9000, console sur le port 9001.
- **Fichiers** : `breval-x10/` et `breval-x50/` (copies, `breval/` reste à l'échelle 1), `lakehouse/delta/`, `lakehouse/iceberg/catalogue.db`, bucket `breval-lake`.
- **Bréval** : environ 0,1 To scanné et environ 25 h de calcul par mois. L'échelle 50 donne environ 17 M de lignes.

## Pour aller plus loin
- [Apache Iceberg — documentation](https://iceberg.apache.org/)
- [Apache Spark — SQL performance tuning](https://spark.apache.org/docs/latest/sql-performance-tuning.html)
- [Polars — documentation](https://docs.pola.rs/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Que signale `Exchange hashpartitioning(commande_id, 200)` dans un plan Spark ?
2. Pourquoi Iceberg avec un catalogue REST pour lire les tables depuis DuckDB aujourd'hui et Snowflake demain ?
3. Deux personnes traitent 40 Go en 6 minutes avec DuckDB. Faut-il un cluster Spark ?

---
**Réponses.** 1) Un shuffle : les lignes sont redistribuées par `commande_id` en 200 partitions (la valeur par défaut, que l'AQE peut fusionner). 2) C'est le format le plus largement pris en charge par les moteurs, avec un catalogue REST standard : pas de copie et moins de verrouillage. 3) Non, pas pour l'instant. On écrit des seuils chiffrés de réévaluation (volume, durée, utilisateurs) et on garde des formats ouverts.
