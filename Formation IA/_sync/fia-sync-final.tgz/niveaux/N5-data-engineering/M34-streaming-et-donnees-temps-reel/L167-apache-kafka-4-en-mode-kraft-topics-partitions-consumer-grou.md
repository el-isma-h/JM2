---
id: L167
module: M34
level: N5
title: "Apache Kafka 4 en mode KRaft : topics, partitions, consumer groups (KIP-848), Avro et Schema Registry, Kafka Connect"
minutes: 55
objectives:
  - "Décrire l'architecture de Kafka 4 en mode KRaft : brokers, contrôleurs, topics, partitions, réplicas, offsets"
  - "Choisir une clé de partitionnement qui garantit l'ordre nécessaire au métier"
  - "Produire et consommer des événements en Python avec un groupe de consommateurs, validation manuelle des offsets et nouveau protocole KIP-848"
  - "Sérialiser en Avro avec un Schema Registry et tester la compatibilité d'une évolution de schéma"
  - "Expliquer le rôle de Kafka Connect et de ses connecteurs source et sink"
skills: ["C5.3"]
sources:
  - { title: "SSOJet — Kafka 4.0 release: simplified architecture with default KRaft", url: "https://ssojet.com/blog/kafka-40-release-simplified-architecture-with-default-kraft", lang: "en" }
  - { title: "Apache Kafka — téléchargements (version courante)", url: "https://kafka.apache.org/downloads", lang: "en" }
  - { title: "Apache Kafka — documentation (Kafka Connect)", url: "https://kafka.apache.org/documentation/#connect", lang: "en" }
  - { title: "Apache Avro — site officiel", url: "https://avro.apache.org/", lang: "en" }
  - { title: "Confluent — Certification (CCDAK)", url: "https://www.confluent.io/en-gb/certification/", lang: "en" }
  - { title: "DataTalksClub — Data Engineering Zoomcamp (module 7)", url: "https://github.com/datatalksclub/data-engineering-zoomcamp", lang: "en" }
---

# Apache Kafka 4 en mode KRaft : topics, partitions, consumer groups (KIP-848), Avro et Schema Registry, Kafka Connect

> ⏱ 55 min · 🎯 Niveau 5 · 📚 Module 34

## 🎯 Ce que vous saurez faire
- Lancer un Kafka 4 **sans ZooKeeper** (mode KRaft) dans Docker, en une commande.
- Expliquer ce que sont un topic, une partition, un offset et un groupe de consommateurs, et pourquoi l'ordre n'est garanti **qu'à l'intérieur d'une partition**.
- Écrire en Python un producteur fiable (idempotent, `acks=all`) et un consommateur qui valide ses offsets après traitement.
- Protéger vos messages par un schéma **Avro** enregistré dans un **Schema Registry**, et savoir quelles évolutions sont autorisées.
- Situer **Kafka Connect**, la plateforme de connecteurs sur laquelle tourne Debezium.

> 🧭 **En clair** — Kafka est un grand registre à feuillets numérotés, partagé par toute l'entreprise. Les comptoirs des trois agences de Bréval y écrivent une ligne par commande, toujours à la fin, sans jamais effacer. Pour aller plus vite, le registre est découpé en plusieurs cahiers (les **partitions**) que l'on peut remplir en parallèle. Chaque service lecteur (comptabilité, stock, assistant IA) garde son propre marque-page (l'**offset**) et lit à son rythme. Si un lecteur s'absente une heure, rien n'est perdu : il reprend à son marque-page.

## 1. L'architecture de Kafka 4

Apache Kafka est un **journal distribué** (*distributed log*) : une suite ordonnée et persistante de messages, répliquée sur plusieurs serveurs.

| Notion | Définition |
|---|---|
| **Broker** | serveur Kafka qui stocke les partitions et répond aux clients |
| **Contrôleur** | nœud qui gère les métadonnées du cluster (qui est leader de quelle partition) ; en **KRaft**, ce rôle est assuré par Kafka lui-même via un consensus de type Raft (un **consensus** est une méthode de vote entre serveurs pour se mettre d'accord sur une seule version des faits, même si l'un d'eux tombe en panne) |
| **Topic** | flux nommé de messages (`commandes-evenements`) |
| **Partition** | sous-journal ordonné d'un topic ; unité de parallélisme et d'ordre |
| **Offset** | numéro d'un message dans sa partition (0, 1, 2…) |
| **Réplica** | copie d'une partition sur un autre broker ; un leader, des suiveurs (le *leader* reçoit les écritures, les *suiveurs* le recopient ; l'**ISR**, *in-sync replicas*, est la liste des réplicas à jour) |
| **Rétention** | durée ou taille de conservation (par exemple 7 jours), indépendante de la lecture |

**Kafka 4.0** a marqué une rupture : **ZooKeeper est supprimé**, KRaft est le seul mode. Un service de moins à exploiter, des démarrages et basculements plus rapides. La même version a rendu disponible le nouveau protocole de groupes de consommateurs (**KIP-848**) et introduit en accès anticipé les « Queues for Kafka » (**KIP-932**, des *share groups* où plusieurs consommateurs se partagent les messages d'une même partition, comme une file d'attente classique). Côté environnement, Kafka 4.0 demande Java 11 pour les clients et Kafka Streams, Java 17 pour les brokers et Kafka Connect. La version courante en novembre 2026 est à vérifier sur la page de téléchargement officielle.

```
          topic « commandes-evenements » (3 partitions, rétention 7 jours)
P0 : [0][1][2][3][4][5][6]──▶      ← producteurs : écriture en fin de journal
P1 : [0][1][2][3]──▶
P2 : [0][1][2][3][4]──▶
          ▲            ▲
   groupe « stock »    groupe « ca-temps-reel » : chacun ses offsets, lecture indépendante
```

> 💡 **Autrement dit** — Une file d'attente classique supprime le message une fois lu. Kafka, lui, **garde** le message pendant toute la durée de rétention : dix applications peuvent le lire, et on peut même « rembobiner » pour relire hier.

## 2. Démarrer Kafka 4 en KRaft

```yaml
# breval/docker-compose.kafka.yml — un broker+contrôleur KRaft et un Schema Registry, à côté du Postgres de L151
services:
  kafka:
    image: apache/kafka:${KAFKA_TAG:-4.1.0}      # version courante : à vérifier sur kafka.apache.org/downloads
    container_name: breval-kafka
    ports: ["29092:29092"]
    environment:
      KAFKA_NODE_ID: 1
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_LISTENERS: INTERNE://:9092,EXTERNE://:29092,CONTROLLER://:9093
      KAFKA_ADVERTISED_LISTENERS: INTERNE://kafka:9092,EXTERNE://localhost:29092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: INTERNE:PLAINTEXT,EXTERNE:PLAINTEXT,CONTROLLER:PLAINTEXT
      KAFKA_INTER_BROKER_LISTENER_NAME: INTERNE
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@kafka:9093
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1          # 1 seul broker : réplication impossible en TP
      KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR: 1
      KAFKA_TRANSACTION_STATE_LOG_MIN_ISR: 1
      KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS: 0
      KAFKA_NUM_PARTITIONS: 3

  schema-registry:
    image: confluentinc/cp-schema-registry:${SR_TAG:-8.0.0}  # licence Confluent Community ; alternatives Apache 2.0 : Apicurio, Karapace
    container_name: breval-schema-registry
    depends_on: [kafka]
    ports: ["8081:8081"]
    environment:
      SCHEMA_REGISTRY_HOST_NAME: schema-registry
      SCHEMA_REGISTRY_KAFKASTORE_BOOTSTRAP_SERVERS: kafka:9092
      SCHEMA_REGISTRY_LISTENERS: http://0.0.0.0:8081
```

> 🧭 **Pré-requis express** — Enregistrez ce bloc sous `breval/docker-compose.kafka.yml` (à côté du `docker-compose.yml` de L151). Les ***listeners*** sont les « portes d'entrée » réseau du broker : `INTERNE` (port 9092) pour les autres conteneurs, `EXTERNE` (port 29092) pour vos scripts Python, `CONTROLLER` (9093) pour le vote interne. Prévoyez 2 Go de mémoire vive libre pour ces deux conteneurs.

```bash
# depuis breval/ : le fichier de L151 + celui-ci forment un seul projet Compose (même réseau)
docker compose -f docker-compose.yml -f docker-compose.kafka.yml up -d
K="docker exec breval-kafka /opt/kafka/bin"
$K/kafka-topics.sh --bootstrap-server kafka:9092 --create --topic commandes-evenements \
   --partitions 3 --replication-factor 1 --config retention.ms=604800000
$K/kafka-topics.sh --bootstrap-server kafka:9092 --describe --topic commandes-evenements
```

> 🔍 **Ce que vous devez voir** — `up -d` télécharge les images (quelques minutes la première fois) puis affiche `✔ Container breval-kafka  Started` et `✔ Container breval-schema-registry  Started`. La création du topic répond `Created topic commandes-evenements.` ; le `--describe` affiche une ligne d'en-tête `Topic: commandes-evenements … PartitionCount: 3  ReplicationFactor: 1  Configs: …retention.ms=604800000…` puis trois lignes `Partition: 0  Leader: 1  Replicas: 1  Isr: 1` (0, 1 et 2). `604800000` millisecondes = 7 jours.

> 🛠️ **Si ça ne marche pas** — « Connection to node -1 (kafka/…:9092) could not be established » ou « Timed out waiting for a node assignment » → Kafka démarre encore : attendez 20 secondes (`docker logs breval-kafka` doit afficher `Kafka Server started`). « Topic 'commandes-evenements' already exists » → il a été créé lors d'un essai précédent : passez à la suite. « K: command not found » ou `$K` vide → la ligne `K=…` a été tapée dans un autre terminal : redéfinissez-la. Sous PowerShell, cette syntaxe ne fonctionne pas : utilisez WSL ou Git Bash. « port is already allocated » sur 8081 → un autre service occupe ce port (souvent un ancien Schema Registry) : arrêtez-le ou changez `"8081:8081"`.

> ⚠️ **Piège fréquent** — Les *listeners*. Un client dans un conteneur doit joindre `kafka:9092`, un script sur votre machine `localhost:29092`. Si l'adresse annoncée (*advertised*) est fausse, la connexion initiale réussit puis échoue mystérieusement : le broker renvoie au client une adresse qu'il ne peut pas joindre.

## 3. Partitions, clés et ordre

Le producteur choisit la partition à partir de la **clé** du message : même clé, même partition (par hachage) (un calcul transforme la clé en numéro de partition, toujours le même pour la même clé), donc **ordre garanti** pour cette clé. Sans clé, les messages sont répartis pour équilibrer la charge, sans ordre global.

| Clé choisie | Ordre garanti pour… | Risque |
|---|---|---|
| `commande_id` | tous les événements d'une même commande (créée → validée → livrée) | aucun pour ce besoin |
| `client_id` | tous les événements d'un client | une partition « chaude » si une grosse entreprise du BTP commande beaucoup |
| `agence_id` | les événements d'une agence | 3 agences = au plus 3 partitions utiles, et Nantes (environ 55 % des commandes) concentre la charge |
| aucune | rien | une annulation peut être lue **avant** la création |

Le nombre de partitions fixe le **parallélisme maximal** d'un groupe de consommateurs : 3 partitions, au plus 3 consommateurs actifs dans le groupe. On peut augmenter ce nombre plus tard, mais cela change l'affectation des clés aux partitions : choisissez-le avec une marge dès le départ.

```quiz
{
  "q": "Les événements « commande créée » et « commande annulée » d'une même commande doivent être traités dans l'ordre. Quelle clé de message choisir ?",
  "options": [
    "L'identifiant de la commande",
    "L'agence qui a saisi la commande",
    "Aucune clé, pour mieux répartir la charge",
    "L'horodatage de l'événement"
  ],
  "answer": 0,
  "explanation": "Kafka garantit l'ordre à l'intérieur d'une partition, et une même clé va toujours dans la même partition. Avec commande_id comme clé, tous les événements d'une commande sont ordonnés. Un horodatage comme clé disperserait les événements d'une même commande."
}
```

## 4. Produire et consommer en Python

```bash
source .venv/bin/activate                     # environnement de L151
pip install "confluent-kafka[avro,schemaregistry]"
```

> 🧭 **Pré-requis express** — Créez le dossier `breval/streaming/` pour y enregistrer les scripts de cette section, et lancez-les depuis `breval/`. Le producteur envoie **500** événements par défaut ; pour en envoyer 2 000 comme dans l'exercice : `NB=2000 python streaming/l167_producteur.py`.

```python
# breval/streaming/l167_producteur.py — événements « commande validée » de Bréval en JSON, clé = commande_id
import json
import os
import random
import time
from datetime import datetime, timedelta, timezone

from confluent_kafka import Producer

BOOTSTRAP = os.environ.get("KAFKA_BOOTSTRAP", "localhost:29092")
TOPIC = "commandes-evenements"
AGENCES, POIDS = ["NAN", "STN", "ANC"], [55, 30, 15]          # répartition des agences de L151
CANAUX = ["comptoir", "telephone", "web", "commercial"]

producteur = Producer({
    "bootstrap.servers": BOOTSTRAP,
    "enable.idempotence": True,   # pas de doublon en cas de relance réseau du producteur
    "acks": "all",                # attendre la confirmation de tous les réplicas synchronisés
    "linger.ms": 20,              # regrouper les messages par petits lots
    "compression.type": "zstd",
})

def accuse(err, msg) -> None:
    if err is not None:
        print(f"❌ échec de livraison : {err}")

def maintenant_moins_retard() -> str:
    # Temps d'événement écrit par le producteur, en UTC ; un retard aléatoire simule des terminaux hors ligne
    t = datetime.now(timezone.utc) - timedelta(seconds=random.expovariate(1 / 20))
    return t.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]

for i in range(1, int(os.environ.get("NB", "500")) + 1):
    evenement = {
        "commande_id": i,
        "client_id": random.randint(1, 5075),
        "agence_id": random.choices(AGENCES, POIDS)[0],
        "canal": random.choice(CANAUX),
        "montant_ht": round(random.uniform(20, 2500), 2),
        "statut": "validee",
        "horodatage_utc": maintenant_moins_retard(),   # contrairement à l'ERP (heure locale, L151), l'événement est en UTC
    }
    producteur.produce(TOPIC, key=str(evenement["commande_id"]),
                       value=json.dumps(evenement).encode("utf-8"), on_delivery=accuse)
    producteur.poll(0)            # déclenche les accusés de réception
    time.sleep(0.05)
producteur.flush()
print("Production terminée")
```

*Lecture des réglages : `acks=all` = le producteur attend que tous les réplicas à jour aient écrit le message avant de le considérer comme livré ; `enable.idempotence` = Kafka élimine les doublons dus aux renvois automatiques du producteur ; `linger.ms` = délai d'attente pour regrouper plusieurs messages en un envoi ; `poll(0)` = « traite les accusés de réception arrivés » ; `flush()` = attendre que tout soit parti.*

> 🔍 **Ce que vous devez voir** — le producteur ne parle que s'il y a un problème (lignes `❌ échec de livraison`) : après environ 25 secondes pour 500 messages (une pause de 0,05 s entre chaque), il affiche seulement `Production terminée`.

```python
# breval/streaming/l167_consommateur.py — groupe « ca-temps-reel », validation manuelle des offsets
import json
import os
from collections import defaultdict

from confluent_kafka import Consumer, KafkaException

consommateur = Consumer({
    "bootstrap.servers": os.environ.get("KAFKA_BOOTSTRAP", "localhost:29092"),
    "group.id": "ca-temps-reel",
    "group.protocol": "consumer",     # nouveau protocole KIP-848 ; retirez la ligne si votre client ne le gère pas
    "enable.auto.commit": False,      # on valide nous-mêmes, APRÈS traitement → au moins une fois
    "auto.offset.reset": "earliest",  # premier démarrage du groupe : lire depuis le début
})
consommateur.subscribe(["commandes-evenements"])

ca_par_agence: dict[str, float] = defaultdict(float)
deja_vus: set[int] = set()            # idempotence naïve en mémoire (L169 fera mieux)
traites = 0
try:
    while True:
        msg = consommateur.poll(1.0)
        if msg is None:
            continue
        if msg.error():
            raise KafkaException(msg.error())
        evt = json.loads(msg.value())
        if evt["commande_id"] not in deja_vus:
            deja_vus.add(evt["commande_id"])
            ca_par_agence[evt["agence_id"]] += evt["montant_ht"]
        traites += 1
        if traites % 100 == 0:
            consommateur.commit(asynchronous=False)       # point de reprise durable
            print(f"partition {msg.partition()} offset {msg.offset()} → "
                  + ", ".join(f"{v}: {c:.0f} €" for v, c in sorted(ca_par_agence.items())))
except KeyboardInterrupt:
    pass
finally:
    consommateur.close()   # quitte proprement le groupe : les partitions sont réaffectées
```

> 🔍 **Ce que vous devez voir** — rien pendant quelques secondes (le consommateur rejoint le groupe), puis une ligne tous les 100 messages, par exemple `partition 1 offset 162 → ANC: 18542 €, NAN: 70311 €, STN: 38870 €`. Quand le producteur s'arrête, le consommateur **reste en attente** sans rien afficher : c'est normal, un flux n'a pas de fin. **Ctrl+C** pour l'arrêter proprement.

> 🛠️ **Si ça ne marche pas** — « KafkaException: … Broker: Unsupported version » ou une erreur sur `group.protocol` → votre broker ou votre client ne gère pas encore KIP-848 : supprimez la ligne `"group.protocol": "consumer"`. Rien ne s'affiche jamais → moins de 100 messages lus (seuil d'affichage), ou le groupe a déjà tout lu lors d'un essai précédent : produisez de nouveaux messages, ou changez `group.id`.

Lancez le consommateur dans deux terminaux, puis le producteur. Observez la répartition des partitions entre les deux instances, puis arrêtez-en une : ses partitions passent à l'autre. C'est le **rééquilibrage** (*rebalance*). Avec l'ancien protocole, tout le groupe s'interrompait pendant la réaffectation ; avec **KIP-848**, l'affectation est calculée par le broker (coordinateur du groupe) et appliquée de façon incrémentale, sans arrêt global. Certains réglages de l'ancien protocole (`partition.assignment.strategy`, `session.timeout.ms` côté client) ne s'appliquent plus avec `group.protocol=consumer`.

```bash
$K/kafka-consumer-groups.sh --bootstrap-server kafka:9092 --describe --group ca-temps-reel
# colonnes CURRENT-OFFSET, LOG-END-OFFSET et LAG : le retard du groupe, l'indicateur n° 1 à surveiller
```

> 🔍 **Ce que vous devez voir** — un tableau avec une ligne par partition : `GROUP | TOPIC | PARTITION | CURRENT-OFFSET | LOG-END-OFFSET | LAG | CONSUMER-ID | HOST | CLIENT-ID`. Avec deux consommateurs actifs, la colonne `CONSUMER-ID` montre deux identifiants différents (l'un a deux partitions, l'autre une). Si le groupe est arrêté, la commande indique `Consumer group 'ca-temps-reel' has no active members.` et affiche quand même les offsets.

> 💡 **À retenir** — Le **lag** (écart entre le dernier message écrit et le dernier offset validé) est la mesure de santé d'un consommateur. Un lag qui grandit sans cesse signifie que le consommateur ne suit plus : ajoutez des instances (dans la limite du nombre de partitions) ou accélérez le traitement.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un topic de 3 partitions lu par un groupe de 5 consommateurs a 5 consommateurs actifs.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux. Dans un groupe classique, une partition est lue par un seul consommateur du groupe : au plus 3 sont actifs, les 2 autres attendent en réserve. Les share groups de KIP-932 changent cette règle, mais ils étaient en accès anticipé dans Kafka 4.0."
}
```

## 5. Avro et Schema Registry : un contrat pour chaque message

Le JSON n'impose rien : un producteur qui renomme `montant_ht` en `montant` casse silencieusement tous les consommateurs. **Avro** est un format binaire **par ligne** décrit par un schéma (vu en M31, L152) ; le **Schema Registry** stocke les versions de ce schéma et refuse celles qui casseraient la compatibilité. Chaque message porte simplement l'identifiant de son schéma. Le schéma est rangé sous un **sujet** (*subject*), un nom qui regroupe ses versions successives, par défaut `<topic>-value`.

```python
# breval/streaming/l167_producteur_avro.py — même événement, sérialisé en Avro avec contrôle de schéma
import os
from datetime import datetime, timezone

from confluent_kafka import Producer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer
from confluent_kafka.serialization import MessageField, SerializationContext

SCHEMA = """
{
  "type": "record", "name": "CommandeEvenement", "namespace": "fr.breval.commandes",
  "fields": [
    {"name": "commande_id", "type": "long"},
    {"name": "client_id",   "type": "long"},
    {"name": "agence_id",   "type": "string"},
    {"name": "montant_ht",  "type": "double"},
    {"name": "statut",      "type": {"type": "enum", "name": "Statut",
                                     "symbols": ["brouillon", "validee", "livree", "facturee", "annulee"]}},
    {"name": "horodatage_utc", "type": {"type": "long", "logicalType": "timestamp-millis"}}
  ]
}
"""
TOPIC = "commandes-avro"
registre = SchemaRegistryClient({"url": os.environ.get("SCHEMA_REGISTRY_URL", "http://localhost:8081")})
serialiseur = AvroSerializer(registre, SCHEMA)
producteur = Producer({"bootstrap.servers": os.environ.get("KAFKA_BOOTSTRAP", "localhost:29092"),
                       "enable.idempotence": True, "acks": "all"})

evt = {"commande_id": 120001, "client_id": 17, "agence_id": "NAN", "montant_ht": 1249.9,
       "statut": "validee", "horodatage_utc": datetime.now(timezone.utc)}
producteur.produce(TOPIC, key=str(evt["commande_id"]),
                   value=serialiseur(evt, SerializationContext(TOPIC, MessageField.VALUE)))
producteur.flush()
print("Schéma enregistré sous le sujet", f"{TOPIC}-value")
```

> 🔍 **Ce que vous devez voir** — `Schéma enregistré sous le sujet commandes-avro-value`. Vérifiez dans le navigateur : `http://localhost:8081/subjects` affiche `["commandes-avro-value"]`.

> 🛠️ **Si ça ne marche pas** — « Connection refused » sur `localhost:8081` → le Schema Registry démarre après Kafka et peut s'arrêter s'il n'a pas pu le joindre : `docker compose -f docker-compose.yml -f docker-compose.kafka.yml up -d schema-registry`, puis `docker logs breval-schema-registry`.

Le schéma est enregistré automatiquement sous le **sujet** `commandes-avro-value`. Le mode de compatibilité par défaut est **BACKWARD** : un consommateur doté du nouveau schéma doit pouvoir lire les messages écrits avec l'ancien. Ajouter un champ **avec valeur par défaut** est accepté ; ajouter un champ **obligatoire sans défaut** est refusé. Testez-le avant de déployer :

```bash
curl -s -X POST -H "Content-Type: application/vnd.schemaregistry.v1+json" \
  --data '{"schema": "{\"type\":\"record\",\"name\":\"CommandeEvenement\",\"namespace\":\"fr.breval.commandes\",\"fields\":[{\"name\":\"commande_id\",\"type\":\"long\"},{\"name\":\"canal\",\"type\":\"string\"}]}"}' \
  http://localhost:8081/compatibility/subjects/commandes-avro-value/versions/latest
# → {"is_compatible":false} : le champ « canal » n'a pas de valeur par défaut
```

> 🛠️ **Si ça ne marche pas** — Sous PowerShell ou l'invite de commandes Windows, les guillemets de cette commande `curl` sont mal interprétés : lancez-la dans WSL ou Git Bash. « {"error_code":40401,"message":"Subject 'commandes-avro-value' not found."} » → lancez d'abord `l167_producteur_avro.py`, qui enregistre la première version du schéma.

> ⚠️ **Piège fréquent** — Passer le sujet en compatibilité `NONE` « pour débloquer un déploiement ». Vous venez de supprimer le seul garde-fou entre les producteurs et des dizaines de consommateurs. Faites plutôt évoluer le schéma de façon compatible (champ optionnel avec défaut), ou créez un nouveau topic versionné.

## 6. Kafka Connect

**Kafka Connect** est le cadre d'intégration de Kafka : au lieu d'écrire des producteurs et consommateurs pour chaque système, on déploie des **connecteurs** configurés en JSON.

- **Connecteurs source** : d'un système vers Kafka (Debezium pour Postgres, MySQL, MongoDB… ; fichiers ; API).
- **Connecteurs sink** : de Kafka vers un système (*sink* = « évier », la destination où l'on déverse les données) (entrepôt, stockage objet, Elasticsearch, tables Iceberg…).
- **Convertisseurs** (JSON, Avro avec Schema Registry) et **transformations unitaires** (*SMT*, *single message transforms* : renommer un champ, filtrer, router).
- **Mode distribué** : plusieurs *workers* se partagent les tâches (un *worker* est un processus qui exécute une partie du travail) ; configurations, offsets et statuts sont eux-mêmes stockés dans des topics Kafka.

Connect s'administre par une API REST (port 8083 par défaut) (on le pilote en envoyant des requêtes web, avec `curl` ou un navigateur) : `GET /connectors` pour lister, `POST /connectors` pour créer, `GET /connectors/<nom>/status` pour surveiller. Vous l'utiliserez concrètement en L169 pour déployer le connecteur Debezium Postgres.

> 🔗 **Documentation officielle** — [Apache Kafka — Kafka Connect](https://kafka.apache.org/documentation/#connect) 🇬🇧 et [Apache Avro](https://avro.apache.org/) 🇬🇧.

```mission
{
  "title": "Les versions de Java exigées par Kafka 4.0",
  "url": "https://ssojet.com/blog/kafka-40-release-simplified-architecture-with-default-kraft",
  "steps": ["Ouvrez l'article consacré à la sortie de Kafka 4.0", "Repérez la section sur les prérequis Java", "Distinguez clients et brokers"],
  "question": "Quelle version de Java Kafka 4.0 exige-t-il pour les clients et Kafka Streams, et laquelle pour les brokers et Kafka Connect ?",
  "hint": "Deux versions LTS de Java différentes sont citées.",
  "answer": "Java 11 pour les clients et Kafka Streams, Java 17 pour les brokers et Kafka Connect (article d'avril 2025 ; vérifiez les prérequis de la version courante sur kafka.apache.org) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Le format de la certification Confluent CCDAK",
  "url": "https://www.confluent.io/en-gb/certification/",
  "steps": ["Ouvrez la page Certification de Confluent", "Repérez la certification Developer for Apache Kafka", "Notez la durée, la langue et la durée de validité"],
  "question": "Quelle est la durée de l'examen CCDAK, dans quelle langue se passe-t-il et combien de temps la certification est-elle valable ?",
  "hint": "Le nombre de questions n'est pas publié ; cherchez la durée en minutes.",
  "answer": "90 minutes, surveillé, en anglais ; validité 2 ans (vérifié le 5 nov. 2026). Ce module en prépare les fondamentaux sans s'y substituer.",
  "xp": 15
}
```

## 🎮 Défi : rembobiner le temps

Créez un nouveau groupe `audit` et lisez le topic depuis le début ; puis, avec `kafka-consumer-groups.sh --reset-offsets --to-datetime …`, replacez le groupe `ca-temps-reel` à il y a 10 minutes (groupe arrêté). Que devient le chiffre d'affaires calculé par votre consommateur après redémarrage ? Pourquoi `deja_vus` ne vous protège-t-il plus ?

## 🧪 Exercice pratique

**Consigne** :
1. Créez le topic `commandes-evenements` (3 partitions), lancez 2 consommateurs du groupe `ca-temps-reel` et le producteur (`NB=2000`).
2. Pendant la production, arrêtez brutalement un consommateur (`kill -9`), puis relancez-le. (`kill -9 <numéro de processus>` tue un programme sans le laisser se fermer ; le numéro s'obtient avec `ps aux | grep l167_consommateur`. Fermer brutalement la fenêtre du terminal a le même effet.) Relevez le lag avant, pendant et après.
3. Comptez les messages traités deux fois (ajoutez un compteur de doublons détectés par `deja_vus`).
4. Faites évoluer le schéma Avro en ajoutant le champ `canal` (absent de la version 1 du schéma Avro) de type `string` **avec** `"default": "comptoir"` ; vérifiez que la compatibilité est acceptée, produisez un message avec le nouveau schéma.

**Critères de réussite** : le lag revient à 0 après la reprise ; aucun message perdu (somme des commandes uniques = 2 000) ; les doublons éventuels sont comptés et expliqués (messages traités après le dernier commit, avant l'arrêt) ; la nouvelle version du schéma apparaît dans `GET /subjects/commandes-avro-value/versions`.

**Corrigé (pistes)** : avec un commit tous les 100 messages, un `kill -9` peut faire relire jusqu'à 99 messages par partition affectée : c'est le « au moins une fois ». Commiter à chaque message réduirait les doublons mais ralentirait fortement ; la vraie solution est une sortie idempotente (L169). Pour le défi : après le retour en arrière, le consommateur relit 10 minutes de messages ; `deja_vus` est en mémoire, donc vide au redémarrage : le CA est surévalué. L'état doit être stocké de façon durable avec le résultat, ou la sortie doit être idempotente.

## ✅ Auto-évaluation express
1. Qu'a supprimé Kafka 4.0, et qu'est-ce qui le remplace ?
2. Pourquoi le nombre de partitions limite-t-il le parallélisme d'un groupe de consommateurs ?
3. Dans le mode BACKWARD, peut-on ajouter un champ obligatoire sans valeur par défaut ?

**Réponses** : 1. ZooKeeper ; les métadonnées sont gérées par KRaft, le consensus intégré à Kafka. 2. Parce que chaque partition n'est lue que par un seul consommateur du groupe à un instant donné. 3. Non : un consommateur doté du nouveau schéma ne saurait pas quelle valeur donner à ce champ dans les anciens messages.

## 📚 Pour aller plus loin
- [Apache Kafka — téléchargements](https://kafka.apache.org/downloads) 🇬🇧 — version courante et notes de version.
- [Apache Kafka — documentation](https://kafka.apache.org/documentation/#connect) 🇬🇧 — configuration des brokers, des clients et de Connect.
- [Confluent — Certification](https://www.confluent.io/en-gb/certification/) 🇬🇧 — CCDAK, la certification développeur Kafka à préparer.
- [Data Engineering Zoomcamp](https://github.com/datatalksclub/data-engineering-zoomcamp) 🇬🇧 — module 7 : Kafka, Kafka Streams, KSQL, Avro.

> ✅ **Si vous ne retenez que 3 choses** — 1. Kafka est un journal distribué : un topic est découpé en partitions, chaque message y reçoit un offset, et chaque groupe de consommateurs garde ses propres offsets ; les messages restent disponibles pendant la rétention, même après lecture. 2. L'ordre n'est garanti qu'à l'intérieur d'une partition : choisissez la clé (ici `commande_id`) pour que les événements d'une même entité restent ordonnés ; le nombre de partitions plafonne le nombre de consommateurs actifs d'un groupe, et le **lag** mesure leur retard. 3. Valider les offsets après traitement donne « au moins une fois » (doublons possibles après une reprise) ; Avro + Schema Registry empêche un producteur de casser les consommateurs (mode BACKWARD : nouveaux champs avec valeur par défaut).

> 🗺️ **Et maintenant ?** — Kafka transporte les événements ; la leçon L168 montre comment les **calculer** en continu avec Flink, Spark Structured Streaming et Kafka Streams, en appliquant les fenêtres et filigranes de L166.
