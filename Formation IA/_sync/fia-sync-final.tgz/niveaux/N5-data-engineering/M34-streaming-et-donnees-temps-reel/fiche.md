---
module: M34
title: "Fiche mémo — Streaming et données temps réel"
---
# Fiche mémo — M34 · Streaming et données temps réel

> En une phrase : un flux n'a jamais de fin. On le découpe en fenêtres en temps d'événement, un filigrane décide quand une fenêtre est close, Kafka garde les messages, et « au moins une fois + écriture idempotente » donne l'effet « exactement une fois ».

## Les 7 idées à retenir
1. Le flux se justifie quand la valeur de la donnée chute vite : fraude, stock, suppression à propager dans un RAG. Pour un tableau de bord lu le lundi, le lot suffit (`L166`).
2. Trois horloges : événement (le cachet de la poste), ingestion, traitement. On calcule en temps d'événement, écrit par le producteur en UTC (`L166`).
3. Filigrane = plus grand temps d'événement vu − retard toléré. Quand il dépasse la fin d'une fenêtre, la fenêtre est émise. Un événement qui arrive ensuite est un retardataire (`L166`, `L168`).
4. Kafka 4 = un journal distribué, sans ZooKeeper (KRaft seul). L'ordre n'est garanti que dans une partition, et une même clé va toujours dans la même partition. Le nombre de partitions limite le nombre de consommateurs actifs d'un groupe (`L167`).
5. Valider l'offset après le traitement donne « au moins une fois », le valider avant donne « au plus une fois ». Le lag est l'indicateur de santé n° 1 (`L166`, `L167`).
6. Avro + Schema Registry : un contrat par message. En BACKWARD (le défaut), un champ ajouté doit avoir une valeur par défaut (`L167`).
7. Flink traite événement par événement, Spark par micro-lots, Kafka Streams est une bibliothèque Java (Kafka → Kafka). Le CDC Debezium vers Delta reste sûr grâce au commit après écriture, au `MERGE` sur la clé et à la garde `s._lsn > t._lsn` (`L168`, `L169`).

## Le schéma à connaître
```mermaid
flowchart LR
    PG["Postgres ERP<br/>WAL, slot debezium_breval"] -->|"pgoutput"| DBZ["Kafka Connect<br/>+ Debezium"]
    DBZ -->|"breval.erp.commandes<br/>op c/u/d/r"| K["Kafka 4 KRaft"]
    K -->|"consume, puis MERGE"| D["Delta data/lake/commandes"]
    D -->|"commit offset APRÈS"| K
    D --> Q["DuckDB delta_scan"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Fenêtre fixe / glissante / session | Tranches contiguës / qui se recouvrent / séparées par une pause d'inactivité |
| Watermark (filigrane) | « Tout ce qui est antérieur à T est arrivé » |
| Offset / lag | Le marque-page du consommateur / le retard entre le dernier message écrit et le dernier offset validé |
| KIP-848 | Nouveau protocole de groupe : rééquilibrage incrémental calculé par le broker |
| KIP-932 | Share groups (« Queues for Kafka »), en accès anticipé dans Kafka 4.0 |
| Checkpoint / barrière | Photo cohérente des offsets et de l'état / le drapeau glissé dans le flux par Flink |
| LSN | Numéro de page du WAL : l'ordre total des changements |
| Tombstone | Message à valeur nulle qui suit une suppression, à ignorer |

## Les pièges classiques
- Horodater l'événement avec `now()` dans le consommateur au lieu de transporter l'heure d'origine.
- Se tromper de listeners : un conteneur utilise `kafka:9092`, l'hôte `localhost:29092`.
- Prendre `agence_id` comme clé : 3 partitions utiles au maximum, et Nantes concentre la charge.
- Passer le Schema Registry en `NONE` « pour débloquer ».
- Croire que l'exactly-once couvre les e-mails ou les API externes : il faut une clé d'idempotence côté service appelé.
- Modifier une agrégation à état en gardant le même `checkpointLocation`.
- Laisser l'état grossir sans watermark, sans fenêtre ni TTL.
- Oublier un slot de réplication : le WAL est retenu jusqu'à saturer le disque.
- Faire un `MERGE` toutes les 2 s sans compactage : on obtient des milliers de petits fichiers.

## Les commandes / chiffres / dates utiles
```bash
docker compose -f docker-compose.yml -f docker-compose.kafka.yml -f docker-compose.cdc.yml up -d
K="docker exec breval-kafka /opt/kafka/bin"
$K/kafka-topics.sh --bootstrap-server kafka:9092 --create --topic commandes-evenements --partitions 3 --replication-factor 1 --config retention.ms=604800000
$K/kafka-consumer-groups.sh --bootstrap-server kafka:9092 --describe --group ca-temps-reel   # colonne LAG
curl -s -X POST -H "Content-Type: application/json" --data @cdc/connecteur-breval.json http://localhost:8083/connectors
curl -s http://localhost:8083/connectors/breval-erp/status          # "RUNNING"
docker exec -it breval-postgres psql -U breval -d breval -c "SELECT slot_name, active, pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn)) FROM pg_replication_slots;"
```
```python
Producer({"enable.idempotence": True, "acks": "all", "linger.ms": 20, "compression.type": "zstd"})
Consumer({"group.id": "ca-temps-reel", "group.protocol": "consumer", "enable.auto.commit": False})
.withWatermark("temps_evenement", "10 minutes").groupBy(F.window("temps_evenement", "5 minutes"), "agence_id")
.writeStream.outputMode("append").foreachBatch(ecrire_lot).option("checkpointLocation", "checkpoints/ca_temps_reel")
.when_matched_update(updates=maj, predicate="s._op <> 'd' AND s._lsn > t._lsn")   # deltalake
```
```sql
WATERMARK FOR horodatage_utc AS horodatage_utc - INTERVAL '10' MINUTE        -- Flink SQL
FROM TABLE(TUMBLE(TABLE commandes_evenements, DESCRIPTOR(horodatage_utc), INTERVAL '5' MINUTES))
SET 'execution.checkpointing.interval' = '30s';
```
- **Kafka 4.0** : Java 11 pour les clients et Kafka Streams, Java 17 pour les brokers et Connect. Image du TP : `apache/kafka:4.1.0` (version courante à vérifier). Ports : Schema Registry 8081, Connect 8083.
- **Debezium** : image `quay.io/debezium/connect:3.2`. Snapshot initial = 120 000 commandes en `op = r`. `decimal.handling.mode=string`. Les `timestamp` arrivent en microsecondes depuis 1970, les `date` en jours. `REPLICA IDENTITY FULL` donne tout le `before`.
- **Spark** : modes de sortie `append`, `complete`, `update`. PySpark 4.3.0, connecteur `spark-sql-kafka-0-10_2.13`. **Kafka Streams** : `EXACTLY_ONCE_V2`, `TimeWindows.ofSizeAndGrace`. **Flink** : `forBoundedOutOfOrderness(Duration)`.
- **Repères** : DDIA 2e éd. (mars 2026, avec Chris Riccomini). CCDAK : 90 min, en anglais, valable 2 ans.

## Pour aller plus loin
- [Apache Kafka — documentation (Kafka Connect)](https://kafka.apache.org/documentation/#connect)
- [Apache Spark — Structured Streaming](https://spark.apache.org/docs/latest/streaming/index.html)
- [Debezium — documentation](https://debezium.io/documentation/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Watermark à 10:08, un événement de 10:02 arrive. Que devient-il avec des fenêtres de 5 min ?
2. Le topic a 6 partitions et les événements d'une commande doivent rester ordonnés. Quelle clé choisir ?
3. Crash entre le `MERGE` et le commit : le lot est relu. Qu'est-ce qui empêche une vieille mise à jour d'écraser une version récente ?

---
**Réponses.** 1) C'est un retardataire : la fenêtre 10:00-10:05 est déjà close, l'événement est écarté. 2) `commande_id` : une même clé va toujours dans la même partition, donc les événements restent dans l'ordre. 3) La garde `s._lsn > t._lsn` : le LSN du WAL donne l'ordre total des changements.
