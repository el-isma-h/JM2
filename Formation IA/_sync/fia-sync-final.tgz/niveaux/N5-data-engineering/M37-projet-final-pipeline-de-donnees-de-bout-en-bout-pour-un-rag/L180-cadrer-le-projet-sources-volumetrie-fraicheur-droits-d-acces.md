---
id: L180
module: M37
level: N5
title: "Cadrer le projet : sources, volumétrie, fraîcheur, droits d'accès, SLA, contrat de données et architecture cible"
minutes: 40
objectives:
  - "Traduire le cahier des charges du projet final en livrables, critères de réussite et compétences C5.1 à C5.6 évaluées"
  - "Mesurer la volumétrie réelle du corpus Bréval (documents, tickets, données personnelles) et en déduire le dimensionnement de l'index"
  - "Formuler des SLO de fraîcheur mesurables (modification, suppression, effacement RGPD) et la matrice de droits par agence et par service"
  - "Concevoir une architecture médaillon justifiée par des critères chiffrés et rédiger le contrat ODCS v3.1 de la table de chunks"
skills: ["C5.1", "C5.4"]
sources:
  - { title: "OpenClassrooms — Parcours Data Engineer (projet « Concevez et déployez un système RAG »)", url: "https://openclassrooms.com/fr/paths/1039-data-engineer", lang: "fr" }
  - { title: "Bitol — Open Data Contract Standard (ODCS)", url: "https://github.com/bitol-io/open-data-contract-standard", lang: "en" }
  - { title: "Data Contract CLI — Open Data Contract Standard", url: "https://docs.datacontract.com/docs/open-data-contract-standard.md", lang: "en" }
  - { title: "CNIL — Développement des systèmes d'IA : les recommandations de la CNIL pour respecter le RGPD", url: "https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd", lang: "fr" }
  - { title: "Qdrant — documentation", url: "https://qdrant.tech/documentation/", lang: "en" }
  - { title: "pgvector — dépôt officiel", url: "https://github.com/pgvector/pgvector", lang: "en" }
  - { title: "Data Lakehouse Hub — Orchestration in 2026: Airflow 3 vs Dagster vs Prefect", url: "https://datalakehousehub.com/blog/orchestration-in-2026/", lang: "en" }
  - { title: "O'Reilly — Fundamentals of Data Engineering (Reis & Housley)", url: "https://oreilly.com/library/view/fundamentals-of-data/9781098108298", lang: "en" }
---

# Cadrer le projet : sources, volumétrie, fraîcheur, droits d'accès, SLA, contrat de données et architecture cible

> ⏱ 40 min · 🎯 Niveau 5 · 📚 Module 37

## 🎯 Ce que vous saurez faire
- Transformer une demande floue (« on veut un assistant qui connaît nos documents ») en un cahier des charges chiffré, avec des livrables et une grille d'évaluation.
- Mesurer, avec un script, ce que pèse réellement le corpus de Bréval Matériaux, et en déduire la taille de l'index vectoriel.
- Écrire des objectifs de fraîcheur vérifiables : « un document supprimé disparaît de l'assistant en moins de 5 minutes », et non « l'index est à jour ».
- Poser la matrice des droits (qui voit quoi, par agence et par service) et le contrat ODCS de la table de chunks, avant d'écrire la moindre ligne de pipeline.

> 🧭 **En clair** — Avant de couler une dalle, un maçon fait un métré, vérifie le terrain et lit le plan : sinon il commande trop de ciment, ou pas assez, et la dalle fissure. Ce projet final, c'est le chantier complet de la donnée de Bréval Matériaux : on va relier ses documents et sa base métier à un assistant interne. Cette première leçon est le métré et le plan : combien de documents, à quelle vitesse ils changent, qui a le droit de voir quoi, quelles promesses on fait aux utilisateurs, et quelles briques on assemble. Tout ce qui suit (ingestion, nettoyage, index, supervision) découle des chiffres posés ici.

## 1. La commande : « Bréval Assist »

La direction de Bréval Matériaux (45 salariés, agences de Nantes, Saint-Nazaire et Ancenis, fil rouge depuis L151) veut un assistant interne, **Bréval Assist**, capable de répondre sur ses procédures, fiches techniques, CGV, notes internes et sur l'historique SAV des clients. Le prototype construit en N3 (M20) fonctionnait sur un poste ; il échouait sur trois points que seul un data engineer peut régler :

1. **La fraîcheur** : une procédure modifiée le matin était encore citée dans son ancienne version le soir ; une procédure supprimée restait citée indéfiniment.
2. **Les droits** : un vendeur de Nantes obtenait des extraits de notes de direction et des tickets de clients de Saint-Nazaire.
3. **Les données personnelles** : des numéros de téléphone de clients apparaissaient dans les réponses.

Le cahier des charges du projet (inspiré du §8.4 du programme N5, et proche de ce que demandent les parcours de data engineer du marché, par exemple le projet « Concevez et déployez un système RAG » du parcours OpenClassrooms) fixe cinq livrables.

| # | Livrable | Contenu attendu | Leçon |
|---|---|---|---|
| 1 | Dossier d'architecture (1-2 pages) | sources, volumétrie, SLA de fraîcheur, schéma médaillon, choix justifiés, **contrat ODCS** de la table de chunks | L180 |
| 2 | Dépôt Git + Docker Compose | MinIO, Postgres + Debezium + Kafka, Docling, Presidio, MinHash, chunking, embeddings par lots, upsert idempotent dans Qdrant (ou pgvector) avec droits, dbt, Dagster | L181-L184 |
| 3 | Qualité et observabilité | tests dbt + GX/Soda, moniteurs de fraîcheur et de volume, tableau de bord simple | L182, L184 |
| 4 | Évaluation | 30 questions (dont 10 synthétiques relues), recall@k et MRR, test de **suppression propagée**, test de **cloisonnement** | L183 |
| 5 | Exploitation | runbook, estimation de coût local / cloud, soutenance de 15 min | L184 |

La grille d'évaluation pondère ainsi : fonctionnement de bout en bout **25 %**, idempotence et incrémental/CDC **20 %**, qualité/gouvernance/PII **20 %**, évaluation RAG **15 %**, observabilité et coûts **10 %**, documentation et soutenance **10 %**. Chaque ligne correspond à des compétences du bloc 5 : C5.1 (choix de stockage justifiés), C5.2 (pipeline rejouable sans doublon), C5.3 (flux CDC à latence mesurée), C5.4 (contrat, contrôles, lignage, RGPD), C5.5 (préparation pour l'IA), C5.6 (exploitation, coûts, runbook).

> 💡 **À retenir** — Un projet de données se juge sur des **preuves rejouables** : un test qui échoue si l'idempotence casse, une mesure de latence, un rapport de qualité. « Ça marche sur ma machine » ne rapporte aucun point de la grille.

## 2. Le métré : sources et volumétrie

On ne dimensionne pas sur une intuition. Ce script lit les fichiers générés en L152 (`data/raw/`, version 1.0.0, graine 42) et sort les chiffres du dossier d'architecture. Créez `breval/cadrage/volumetrie.py` :

```python
# cadrage/volumetrie.py — métré du corpus RAG de Bréval (bibliothèque standard uniquement)
import csv
import json
import re
from collections import Counter
from pathlib import Path

RAW = Path("data/raw")
TEL = re.compile(r"(?:\+33\s?|0)[1-9](?:[ .]?\d{2}){4}")      # téléphones français, 4 écritures (L151)
DIMENSION, OCTETS = 1024, 4                                   # bge-m3, float32 (L178)

docs = list(csv.DictReader((RAW / "documents/documents.csv").open(encoding="utf-8"), delimiter=";"))
mots_docs, docs_avec_tel = 0, 0
for d in docs:
    texte = (RAW / d["chemin"]).read_text(encoding="utf-8")
    mots_docs += len(texte.split())
    docs_avec_tel += bool(TEL.search(texte))
print(f"Documents : {len(docs)} · {mots_docs:,} mots · {docs_avec_tel} contiennent un téléphone")
print("  par type            :", dict(Counter(d["type_document"] for d in docs)))
print("  par confidentialité :", dict(Counter(d["confidentialite"] for d in docs)))
print("  anciennes versions  :", [d["doc_id"] for d in docs if re.search(r"-v\d+$", d["doc_id"])])

n_tickets, mots_tickets, tickets_tel, mois = 0, 0, 0, Counter()
with (RAW / "sav/tickets_sav.jsonl").open(encoding="utf-8") as f:
    for ligne in f:
        t = json.loads(ligne)
        texte = "\n".join(m["texte"] for m in t["messages"])
        n_tickets += 1
        mots_tickets += len(texte.split())
        tickets_tel += bool(TEL.search(texte))
        mois[t["ouvert_le"][:7]] += 1
print(f"Tickets : {n_tickets:,} · {mots_tickets:,} mots · {tickets_tel:,} avec téléphone "
      f"({tickets_tel / n_tickets:.0%}) · ≈ {n_tickets / len(mois):.0f} nouveaux par mois")

# Hypothèses de cadrage (à remplacer par vos mesures de L182) : ~3 chunks utiles par document, 1 par ticket
chunks = 3 * len(docs) + n_tickets
print(f"Chunks estimés : {chunks:,} → vecteurs float32 ≈ {chunks * DIMENSION * OCTETS / 1e6:.0f} Mo ; "
      f"×10 (M32) ≈ {10 * chunks * DIMENSION * OCTETS / 1e9:.2f} Go")
```

```bash
cd breval && python cadrage/volumetrie.py
```

**Point de contrôle** — sortie attendue à l'échelle 1 :

```
Documents : 126 · 9,069 mots · 36 contiennent un téléphone
  par type            : {'procedure': 36, 'fiche_technique': 80, 'cgv': 6, 'note_interne': 4}
  par confidentialité : {'restreint': 21, 'interne': 19, 'public': 86}
  anciennes versions  : ['PRC-001-v2', 'PRC-002-v1', 'PRC-007-v1', 'PRC-019-v3', 'PRC-021-v3', 'PRC-027-v3']
Tickets : 9,048 · 361,467 mots · 1,380 avec téléphone (15%) · ≈ 259 nouveaux par mois
Chunks estimés : 9,426 → vecteurs float32 ≈ 39 Mo ; ×10 (M32) ≈ 0.39 Go
```

> 🛠️ **Si ça ne marche pas** — « FileNotFoundError: data/raw/documents/documents.csv » → vous n'êtes pas dans `breval/` (retirez `cd breval &&` si vous y êtes déjà) ou `data/raw/` a été supprimé : relancez `python generer_breval.py` (L152). Des nombres différents (par exemple 1 202 400 commandes ou 90 000 tickets) → `data/raw/` a été régénéré à une autre échelle : régénérez-le à l'échelle 1 avec la graine 42. Ce script n'a besoin d'aucune bibliothèque à installer.

Trois conclusions pour le dossier :

- **Le volume est petit, la difficulté est ailleurs.** 39 Mo de vecteurs tiennent dans la mémoire de n'importe quel serveur. Le défi n'est ni Spark ni le GPU, mais la **fraîcheur**, les **droits** et les **données personnelles** : c'est le cas de la plupart des PME.
- **Le corpus contient déjà des pièges.** Six anciennes versions de procédures cohabitent avec les versions en vigueur, et les CGV 2024, 2025 et 2026 ont un corps identique : sans déduplication, l'assistant citera des règles périmées (L182).
- **Les tickets dominent** : 96 % des chunks, 15 % avec un téléphone en clair. La pseudonymisation porte d'abord sur eux.

> ⚠️ **Piège fréquent** — Dimensionner sur le nombre de **fichiers** plutôt que sur le nombre de **chunks** et de **tokens**. Un PDF de 300 pages et une fiche produit comptent chacun pour un fichier, mais pas pour l'index ni pour la facture d'embeddings.

```quiz
{
  "q": "D'après le métré, quel est le principal risque technique du projet Bréval Assist ?",
  "options": ["Le volume : il faudra un cluster Spark pour les tickets", "La mémoire du serveur vectoriel, saturée par les vecteurs", "La fraîcheur, les droits et les données personnelles", "Le coût des embeddings, qui dépassera le budget annuel"],
  "answer": 2,
  "explanation": "Environ 9 400 chunks et 39 Mo de vecteurs : le volume est modeste. Les vraies difficultés sont la propagation des modifications et suppressions, le cloisonnement par agence et service, et les 1 380 tickets qui contiennent un téléphone."
}
```

## 3. Fraîcheur : SLA, SLO et SLI

Trois sigles, une idée simple :

- **SLI** (*service level indicator*) : ce que l'on **mesure**, par exemple « délai entre la suppression d'un document dans la GED et sa disparition de l'index ». (GED = gestion électronique des documents : le logiciel ou le serveur où l'entreprise range ses documents.)
- **SLO** (*service level objective*) : l'**objectif** fixé sur cet indicateur, par exemple « 95 % des suppressions propagées en moins de 5 minutes ».
- **SLA** (*service level agreement*) : l'**engagement** contractuel envers les utilisateurs, souvent plus souple que le SLO interne, avec ce qui se passe s'il n'est pas tenu.

> 💡 **Autrement dit** — Le SLI est le thermomètre, le SLO la température que l'on vise, le SLA la promesse faite au client. Sans thermomètre, la promesse est invérifiable.

Pour Bréval, les objectifs retenus (à discuter avec la direction, puis à écrire dans le contrat) :

| Événement à la source | SLI (mesuré où) | SLO | Mécanisme (leçon) |
|---|---|---|---|
| Document **supprimé** dans la GED | âge de l'événement CDC → point supprimé dans Qdrant (journal d'audit de l'indexeur) | **< 5 min** (p95) | CDC Debezium → Kafka → indexeur de suppressions (L181, L183) |
| Demande d'**effacement RGPD** d'un client | idem, sur `client_id` | **< 15 min** dans l'index ; dossier clos sous 1 mois (délai légal de principe) | même chaîne + exclusion dans le batch (L183) |
| Document **modifié** ou ajouté | `date de l'événement` → chunk indexé avec la nouvelle empreinte | **< 1 h** en heures ouvrées | micro-batch Dagster toutes les 15 min (L184) |
| Nouveau **ticket** SAV | ouverture → chunk indexé | **< 1 h** | export horaire de l'outil SAV + dlt (L162) |
| **Qualité de récupération** | recall@5 sur le jeu de 30 questions | **≥ 0,80** ; zéro fuite de droits | évaluation à chaque exécution (L183) |

Pourquoi des délais différents ? Une suppression est souvent **urgente** (document erroné, retrait juridique, droit à l'effacement) et coûte peu à appliquer : on la traite en flux. Une modification exige de re-parser, re-pseudonymiser, re-découper et re-vectoriser : un micro-batch toutes les 15 minutes est plus simple et suffit au besoin.

> ⚠️ **Piège fréquent** — Écrire « temps réel » dans le dossier. Personne ne sait le mesurer, et tout le monde l'interprète différemment. Écrivez un nombre, un percentile et l'endroit où il est mesuré. (Le **p95**, 95ᵉ percentile, est la valeur sous laquelle tombent 95 % des mesures : « p95 < 5 min » signifie que 19 suppressions sur 20 sont propagées en moins de 5 minutes.)

## 4. Droits d'accès et données personnelles

### 4.1 La matrice des droits

Chaque document porte une `confidentialite` (`public`, `interne`, `restreint`) et un `service` propriétaire dans `documents.csv`. Chaque ticket appartient à l'agence de la commande concernée (ou, à défaut, à l'agence de rattachement du client). On en déduit deux listes portées par **chaque chunk** : les `agences` qui peuvent le voir et les `groupes` autorisés. Un utilisateur voit un chunk si **au moins une** de ses agences et **au moins un** de ses groupes y figurent.

| Type de contenu | `agences` | `groupes` | Exemple |
|---|---|---|---|
| Document `public` ou `interne` | les trois agences | `tous` | fiche technique, procédure logistique |
| Document `restreint` | les trois agences | `service:<propriétaire>`, `service:direction` | PRC-001 Notes de frais (RH) |
| Document propre à une agence | celle-ci seulement | selon la confidentialité | NOTE-002 Réorganisation du dépôt de Saint-Nazaire |
| Ticket SAV | l'agence de la commande | `service:sav`, `service:commerce`, `service:direction` | SAV-0008640 (Saint-Nazaire) |

La règle tient dans un module unique, `breval/rag/droits.py`, utilisé à la fois par le pipeline (qui écrit les droits dans les chunks) et par les tests (qui vérifient le filtre de l'assistant). **Une seule source de vérité** : si la règle change, elle change partout.

```python
# rag/droits.py — matrice des droits (dossier d'architecture, L180) : une seule source de vérité
import hashlib
import json

AGENCES = ("NAN", "STN", "ANC")
AGENCES_SPECIFIQUES = {"NOTE-002": ("STN",)}          # documents qui ne concernent qu'une agence
GROUPES_TICKETS = ("service:commerce", "service:direction", "service:sav")

PROFILS = {   # personas de test (L183) ; en production : annuaire d'entreprise (SSO, groupes LDAP)
    "alice":    {"agences": ["NAN"], "groupes": ["tous", "service:commerce"]},
    "karim":    {"agences": ["STN"], "groupes": ["tous", "service:sav"]},
    "lea":      {"agences": ["NAN"], "groupes": ["tous", "service:rh"]},
    "erwan":    {"agences": ["ANC"], "groupes": ["tous", "service:logistique"]},
    "sandrine": {"agences": list(AGENCES), "groupes": ["tous", "service:direction"]},
}


def droits_document(doc_id: str, service: str, confidentialite: str) -> tuple[list[str], list[str]]:
    agences = list(AGENCES_SPECIFIQUES.get(doc_id, AGENCES))
    if confidentialite in ("public", "interne"):
        groupes = ["tous"]
    else:                                            # « restreint » : le service propriétaire et la direction
        groupes = sorted({f"service:{service}", "service:direction"})
    return agences, groupes


def droits_ticket(agence_id: str | None) -> tuple[list[str], list[str]]:
    return ([agence_id] if agence_id else list(AGENCES)), list(GROUPES_TICKETS)


def autorise(profil: dict, agences: list[str], groupes: list[str]) -> bool:
    """La règle exacte que le filtre Qdrant doit reproduire (utilisée par les tests de cloisonnement)."""
    return bool(set(profil["agences"]) & set(agences)) and bool(set(profil["groupes"]) & set(groupes))


def droits_hash(agences: list[str], groupes: list[str]) -> str:
    return hashlib.sha256(json.dumps([sorted(agences), sorted(groupes)]).encode()).hexdigest()[:16]
```

> 🧭 **Pré-requis express** — Créez le dossier `breval/rag/` et enregistrez-y ce fichier sous `droits.py`, ainsi qu'un fichier **vide** `rag/__init__.py` (il permet d'écrire `from rag.droits import …` depuis `breval/`). Les **personas** sont des utilisateurs fictifs qui représentent chacun un profil type ; en entreprise, agences et groupes viendraient de l'annuaire (le **SSO**, connexion unique, et l'annuaire **LDAP** où sont rangés comptes et groupes).

> 🔍 **Ce que vous devez voir** — pour vérifier la matrice sans rien installer, depuis `breval/`, lancez `python -c "from rag.droits import *; ag, gr = droits_document('PRC-001', 'rh', 'restreint'); print({p: autorise(PROFILS[p], ag, gr) for p in PROFILS})"` : `{'alice': False, 'karim': False, 'lea': True, 'erwan': False, 'sandrine': True}`. Avec `droits_ticket('STN')`, seuls `karim` et `sandrine` sont à `True`.

> 🛠️ **Si ça ne marche pas** — « ModuleNotFoundError: No module named 'rag' » → vous n'êtes pas dans `breval/`, ou le fichier `rag/__init__.py` manque.

Le `droits_hash` servira en L183 : si les droits d'un document changent **sans** que son texte change, l'indexeur mettra à jour les métadonnées des points sans recalculer les vecteurs.

```quiz
{
  "q": "Alice (commerce, agence de Nantes) interroge Bréval Assist sur « la réorganisation du dépôt de Saint-Nazaire ». Que doit-il se passer d'après la matrice ?",
  "options": ["Elle obtient NOTE-002, car son type est « note interne » et non « restreint »", "Aucun extrait : ni son agence ni son groupe ne sont autorisés", "Elle obtient les extraits de NOTE-002, mais sans le titre du document", "Elle obtient NOTE-002, car le groupe « tous » ouvre les notes de direction"],
  "answer": 1,
  "explanation": "NOTE-002 est restreinte (groupes service:direction) et limitée à l'agence STN. Alice n'a ni l'agence STN ni le groupe direction : le filtre doit l'exclure avant même le calcul de similarité."
}
```

### 4.2 Les données personnelles et leur base légale

Le critère de C5.4 exige que « les données personnelles et leur base légale soient identifiées ». Le métré en a trouvé deux familles :

| Où | Données | Base légale plausible (à valider par le DPO) | Traitement dans le pipeline |
|---|---|---|---|
| Tickets SAV (texte libre) | téléphone, parfois nom ou e-mail du client | exécution du contrat (traitement de la réclamation) ; intérêt légitime pour l'assistance interne | **pseudonymisation** HMAC des noms et e-mails, remplacement des téléphones par `<TELEPHONE>` (Presidio, L177) |
| Procédures | nom et téléphone du responsable (salarié) | intérêt légitime / exécution du contrat de travail (organisation interne) | nom **conservé** (utile : « à qui m'adresser ? »), téléphone remplacé (renvoi vers l'annuaire) |
| Registre RGPD | `client_id` des demandes d'effacement | obligation légale | sert à **exclure** et **supprimer** les chunks (L183) |

Ce tableau illustre la **minimisation** : on ne retire pas tout « par principe », on garde ce qui sert la finalité et on documente pourquoi. Les recommandations de la CNIL sur le développement des systèmes d'IA donnent le cadre (finalité, base légale, minimisation, droits des personnes).

## 5. L'architecture cible

```mermaid
flowchart LR
  subgraph Sources
    FS[Serveur de fichiers - Markdown et PDF]
    GED[(Postgres ged.documents)]
    ERP[(Postgres erp.*)]
    RG[(Postgres rgpd.demandes_effacement)]
    SAV[Outil SAV - export JSONL]
  end
  FS --> M1[(MinIO breval-docs - bronze objets)]
  GED --> K{{Kafka breval.*}}
  ERP --> K
  RG --> K
  K --> M2[(MinIO breval-lake - bronze CDC Parquet)]
  K --> IX[Indexeur de suppressions]
  SAV --> D[(DuckDB bronze)]
  M2 --> D
  D --> S1[dbt amont - documents courants et tickets]
  M1 --> P[Préparation - Docling, Presidio, MinHash, chunking]
  S1 --> P
  P --> S2[(silver.rag_chunks)]
  S2 --> G[(gold - suivi et qualité, tests)]
  S2 --> E[Embeddings par lots - cache Parquet]
  E --> Q[(Qdrant - alias chunks)]
  IX --> Q
  Q --> A[Bréval Assist - filtre agences et groupes]
```

Le schéma suit l'architecture **médaillon** (L161) : **bronze** = objets et événements bruts, immuables (MinIO, `bronze.*`) ; **silver** = documents courants, pseudonymisés, dédupliqués, découpés (`silver.rag_*`) ; **gold** = tables de suivi et de qualité pour les humains, et l'index vectoriel pour l'assistant. Deux chemins coexistent : le **flux** (Debezium → Kafka) pour les suppressions urgentes, le **micro-batch** (Dagster toutes les 15 min) pour tout le reste.

Le critère de C5.1 demande de justifier les choix par au moins **trois critères chiffrés**. Voici la table de décision de référence ; la vôtre peut conclure autrement si vos chiffres diffèrent.

| Décision | Option retenue | Alternative | Critères chiffrés |
|---|---|---|---|
| Moteur de transformation | DuckDB + dbt-duckdb | Spark (M32) | 30 Mo de sources, ~9 400 chunks ; mono-nœud, 0 € ; Spark n'apporte rien sous quelques dizaines de Go |
| Base vectorielle | Qdrant (alias, index de payload) | pgvector dans le Postgres existant | 39 Mo de vecteurs : les deux suffisent ; Qdrant offre la bascule d'alias atomique (L178) ; pgvector éviterait un service de plus (variante acceptée) |
| Capture des changements | Debezium (journal WAL) | curseur `mis_a_jour_le` (L162) | le curseur ne voit pas les suppressions (expérience 3 de L162) ; SLO suppression 5 min |
| Stockage bronze du CDC | Parquet immuable dans MinIO | écriture directe dans DuckDB | DuckDB n'accepte qu'un écrivain à la fois (L165) : un consommateur permanent bloquerait le pipeline |
| Orchestrateur | Dagster (assets, dagster-dbt) | Airflow 3, Prefect | lignage natif source → index, un modèle dbt = un asset (L164) ; Dagster est en cours de rachat par Prefect (annonce du 13 juillet 2026), l'OSS reste maintenu : à surveiller dans le dossier |

> 💡 **À retenir** — Une bonne justification compare **deux options sur les mêmes critères** et dit ce qui ferait changer d'avis (« au-delà de 10 millions de vecteurs, nous réévaluerons la quantification et le stockage sur disque »).

## 6. Le contrat de données de la table de chunks

La table `silver.rag_chunks` est l'interface entre la préparation (L182) et l'indexation (L183). (Elle n'existe pas encore : le contrat se rédige **avant** le code, comme expliqué dans le piège ci-dessous.) Son contrat ODCS v3.1.0 (structure vue en L171) fixe le schéma, les règles de qualité **bloquantes**, les objectifs de service et les responsables. Créez `breval/contrats/rag_chunks.odcs.yaml` :

```yaml
# contrats/rag_chunks.odcs.yaml — Open Data Contract Standard v3.1.0
# Vérifiez les noms de champs exacts (notamment items des tableaux) dans le schéma JSON officiel bitol-io
apiVersion: v3.1.0
kind: DataContract
id: breval-rag-chunks
name: rag_chunks
version: 1.0.0
status: active
domain: assistant-interne
dataProduct: breval_assist_corpus
description:
  purpose: "Chunks pseudonymisés, dédupliqués et porteurs de droits, prêts à vectoriser pour Bréval Assist."
  usage: "Lecture par l'indexeur (embeddings, Qdrant) et par l'évaluation. Interdit : export hors du SI, entraînement de modèles tiers."
  limitations: "Tickets pseudonymisés (HMAC) ; noms des responsables de procédures conservés (base légale : docs/architecture.md)."

schema:
  - name: rag_chunks
    physicalName: silver.rag_chunks
    physicalType: table
    logicalType: object
    description: "Une ligne = un morceau de texte indexable (ou exclu comme gabarit), avec ses droits."
    properties:
      - { name: chunk_id, logicalType: string, physicalType: VARCHAR, primaryKey: true, required: true, unique: true,
          description: "sha256(doc_id|chunking_v|position|texte_indexe), 32 caractères hexadécimaux" }
      - { name: doc_id, logicalType: string, physicalType: VARCHAR, required: true }
      - name: source_type
        logicalType: string
        physicalType: VARCHAR
        required: true
        logicalTypeOptions: { enum: [document, ticket] }
      - { name: texte_indexe, logicalType: string, physicalType: VARCHAR, required: true,
          description: "En-tête de contexte (titre › section) + texte pseudonymisé" }
      - { name: agences, logicalType: array, physicalType: "VARCHAR[]", required: true, items: { logicalType: string } }
      - { name: groupes, logicalType: array, physicalType: "VARCHAR[]", required: true, items: { logicalType: string } }
      - { name: confidentialite, logicalType: string, physicalType: VARCHAR, required: true }
      - { name: client_id, logicalType: integer, physicalType: BIGINT, required: false,
          description: "Renseigné pour les tickets : sert à l'effacement RGPD" }
      - { name: chunking_v, logicalType: string, physicalType: VARCHAR, required: true }
      - { name: indexable, logicalType: boolean, physicalType: BOOLEAN, required: true }
      - { name: prepare_le, logicalType: date, physicalType: TIMESTAMP, required: true }
    quality:
      - type: sql
        description: "Aucun téléphone en clair dans le texte indexé"
        query: |
          SELECT count(*) FROM silver.rag_chunks
          WHERE regexp_matches(texte_indexe, '(\+33\s?|0)[1-9]([ .]?\d{2}){4}')
        mustBe: 0
      - type: sql
        description: "Pas de doublon de chunk_id"
        query: "SELECT count(*) - count(DISTINCT chunk_id) FROM silver.rag_chunks"
        mustBe: 0
      - type: sql
        description: "Chaque chunk a au moins une agence et un groupe"
        query: "SELECT count(*) FROM silver.rag_chunks WHERE len(agences) = 0 OR len(groupes) = 0"
        mustBe: 0
      - type: sql
        description: "Un contenu restreint n'est jamais ouvert au groupe « tous »"
        query: "SELECT count(*) FROM silver.rag_chunks WHERE confidentialite = 'restreint' AND list_contains(groupes, 'tous')"
        mustBe: 0

slaProperties:
  - { property: frequency, value: 15, unit: min }      # micro-batch Dagster (L184)
  - { property: latency, value: 1, unit: h }           # modification à la source -> chunk prêt
  - { property: retention, value: 3, unit: y }         # hypothèse à valider avec le DPO

customProperties:
  - { property: slo_suppression_minutes, value: 5 }
  - { property: slo_effacement_rgpd_minutes, value: 15 }
  - { property: recall_at_5_minimum, value: 0.8 }

team:
  - { username: responsable-data, role: owner }
  - { username: equipe-data, role: data_engineer }
support:
  - { channel: "#breval-assist", tool: slack }
servers:
  - { server: local, type: duckdb, path: data/breval.duckdb }
```

```bash
pip install "datacontract-cli[duckdb]"
datacontract lint contrats/rag_chunks.odcs.yaml     # valide la structure dès maintenant ; « test » viendra en L182
```

> 🔍 **Ce que vous devez voir** — un message de succès du type `🟢 data contract is valid` ; en cas d'écart avec le standard, la liste des champs fautifs avec leur chemin (par exemple `schema[0].properties[5].items`).

> 🛠️ **Si ça ne marche pas** — Une erreur sur `items` (la description du type des éléments d'une colonne-liste comme `agences`) → comparez la syntaxe avec le schéma JSON officiel v3.1.0 du dépôt bitol-io (voir les pistes de corrigé de l'exercice). « command not found: datacontract » → l'installation s'est faite dans une autre venv.

> ⚠️ **Piège fréquent** — Rédiger le contrat **après** le pipeline, en recopiant ce que le code produit. Le contrat devient alors une photographie, pas un engagement. Écrit d'abord, il guide le code et sert de test d'acceptation.

```mission
{
  "title": "La commande qui confronte un contrat aux données réelles",
  "url": "https://docs.datacontract.com/docs/open-data-contract-standard.md",
  "steps": ["Ouvrez la page ODCS de la documentation Data Contract CLI", "Repérez les sous-commandes présentées pour un contrat ODCS", "Distinguez celle qui vérifie le fichier de celle qui interroge la base décrite dans servers"],
  "question": "Quelle sous-commande valide la structure du contrat, et laquelle exécute les règles de qualité sur la table réelle ?",
  "hint": "L'une vérifie la syntaxe comme un correcteur, l'autre « teste ».",
  "answer": "datacontract lint valide le fichier ; datacontract test exécute schéma et règles de qualité sur le serveur décrit (doc consultée en nov. 2026 ; les options évoluent) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 7. Le dossier d'architecture et l'arborescence du dépôt

Le dossier tient en deux pages. Ce squelette (`breval/docs/architecture.md`) reprend les sections attendues par la grille :

```markdown
# Bréval Assist — dossier d'architecture data (v1, <date>)
## 1. Contexte et finalité            — besoin, utilisateurs, ce que l'assistant ne fait PAS
## 2. Sources et volumétrie            — tableau du métré (L180 §2), croissance mensuelle, échelle ×10
## 3. Objectifs de service             — tableau SLI / SLO (L180 §3)
## 4. Droits et données personnelles   — matrice des droits, tableau PII + base légale, durée de conservation
## 5. Architecture                     — schéma médaillon, flux CDC vs micro-batch
## 6. Choix techniques                 — table de décision (≥ 3 critères chiffrés par choix)
## 7. Contrat de la table de chunks    — lien vers contrats/rag_chunks.odcs.yaml
## 8. Risques et points ouverts        — ex. rachat de Dagster, versions à figer, images MinIO
```

L'arborescence finale du dépôt, que les quatre leçons suivantes vont remplir (les fichiers des modules précédents sont conservés tels quels) :

```
breval/
├── docker-compose.yml          ← L181 : version consolidée (postgres, minio, kafka, connect, qdrant)
├── Makefile                    ← L165 + cibles du projet (L184)
├── sql/03_ged_rgpd.sql         ← L181 : registre documentaire et demandes d'effacement
├── cadrage/volumetrie.py       ← L180
├── contrats/rag_chunks.odcs.yaml
├── docs/architecture.md  docs/runbook.md  docs/post-mortem.md
├── ingestion/ingest.py (L162)  ingestion/ged_simulateur.py (L181)
├── cdc/connecteur-breval.json  cdc/cdc_vers_bronze.py (L181)  cdc/indexeur_suppressions.py (L183)
├── rag/  config.py droits.py bronze_cdc.py extraction.py pii.py dedup.py chunking.py preparer.py
│         embeddings.py index.py recherche.py evaluation.py obs.py lignage.py
├── dbt_breval/models/rag/{amont,aval}/   ← L182
├── qualite/gx_chunks.py  soda/            ← L182
├── evals/questions_projet.jsonl  evals/pii_annote.jsonl
├── tests_pipeline/test_idempotence.py (L165)  tests_pipeline/test_rag.py (L183)
├── observabilite/moniteurs_rag.py  couts/cout_par_document.py   ← L184
└── orchestration/defs.py (L164)  orchestration/defs_rag.py (L184)
```

> 🎮 **Défi** — Bréval rachète un concurrent vendéen : 4 agences de plus, 25 000 tickets par an, 600 documents. En 5 minutes, recalculez le nombre de chunks, la mémoire des vecteurs et dites si un seul de vos choix techniques change. *Piste : environ 25 000 + 3 × 726 ≈ 27 000 nouveaux chunks par an ; même après cinq ans (~140 000 chunks, ≈ 0,6 Go en float32), DuckDB et une seule collection Qdrant suffisent ; seule la matrice des droits grossit (7 agences).*

## 🧪 Exercice pratique

**Consigne** — Produisez le livrable 1 : (1) lancez `cadrage/volumetrie.py` et reportez ses chiffres ; (2) complétez `docs/architecture.md` (8 sections, 2 pages maximum) ; (3) créez `rag/droits.py` et vérifiez à la main, pour les cinq personas, l'accès à PRC-001, NOTE-002, FT-BRV-ISO-00075 et à un ticket de Saint-Nazaire ; (4) écrivez `contrats/rag_chunks.odcs.yaml` et faites passer `datacontract lint`.

**Critères de réussite** — Chaque SLO a un SLI, un seuil chiffré et un lieu de mesure ; la table de décision compte au moins trois choix justifiés par trois critères chiffrés ; le tableau 5 × 4 des accès est cohérent avec `autorise()` ; le contrat passe le lint et contient au moins quatre règles de qualité.

**Pistes de corrigé** — Tableau des accès : PRC-001 visible par Léa (RH) et Sandrine (direction) seulement ; NOTE-002 par Sandrine seulement ; FT-BRV-ISO-00075 par tous ; un ticket STN par Karim (STN, sav) et Sandrine, pas par Alice (bonne équipe, mauvaise agence) ni par Erwan. Si le lint échoue sur `items`, comparez avec le schéma JSON de la version v3.1.0 du dépôt bitol-io : c'est lui qui fait foi.

## ✅ Auto-évaluation express
1. Quelle différence entre un SLO et un SLI ?
2. Pourquoi les droits sont-ils portés par **chaque chunk** et non vérifiés seulement dans l'application ?
3. Citez deux pièges du corpus Bréval révélés par le métré.

**Réponses** — 1. Le SLI est la mesure (délai de propagation d'une suppression) ; le SLO est l'objectif fixé sur cette mesure (95 % en moins de 5 minutes). 2. Pour filtrer **pendant** la recherche vectorielle : un post-filtrage applicatif renvoie trop peu de résultats et un oubli dans le code exposerait tout l'index (L178, L174). 3. Les anciennes versions de procédures et les CGV au corps identique (doublons qui font citer des règles périmées) ; les téléphones présents dans 15 % des tickets.

## 📚 Pour aller plus loin
- [Bitol — Open Data Contract Standard](https://github.com/bitol-io/open-data-contract-standard) 🇬🇧 — le standard et son schéma JSON, référence pour valider votre contrat.
- [Data Contract CLI — ODCS](https://docs.datacontract.com/docs/open-data-contract-standard.md) 🇬🇧 — lint, test et export des contrats.
- [CNIL — Recommandations pour le développement des systèmes d'IA](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd) — finalité, base légale, minimisation.
- [Qdrant — documentation](https://qdrant.tech/documentation/) 🇬🇧 et [pgvector](https://github.com/pgvector/pgvector) 🇬🇧 — pour argumenter votre choix de base vectorielle.
- [OpenClassrooms — Parcours Data Engineer](https://openclassrooms.com/fr/paths/1039-data-engineer) — repère marché : un projet RAG figure dans ce parcours RNCP de niveau 7 (ce module en prépare les fondamentaux, sans s'y substituer).

> ✅ **Si vous ne retenez que 3 choses** — 1. On cadre avant de coder : un métré chiffré (126 documents, 9 048 tickets, ≈ 9 400 chunks, 39 Mo de vecteurs) montre que la difficulté d'une PME n'est pas le volume mais la fraîcheur, les droits et les données personnelles. 2. Chaque promesse de fraîcheur s'écrit en SLI (ce qu'on mesure, et où), SLO (l'objectif chiffré, en percentile) et SLA (l'engagement) : suppression < 5 min en flux CDC, modification < 1 h en micro-batch. 3. Les droits (agences × groupes) sont calculés par **une seule** règle (`rag/droits.py`) et portés par chaque chunk ; le contrat ODCS de `silver.rag_chunks` est écrit d'abord et sert de test d'acceptation.

> 🗺️ **Et maintenant ?** — Le plan est signé ; en L181, vous ouvrez le chantier par les fondations : faire entrer les documents dans le stockage objet et la base métier dans Kafka, sans rien perdre ni doubler.
