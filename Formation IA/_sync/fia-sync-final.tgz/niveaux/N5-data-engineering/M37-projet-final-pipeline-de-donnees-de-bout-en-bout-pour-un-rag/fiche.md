---
module: M37
title: "Fiche mémo — Projet final : pipeline de données de bout en bout pour un RAG d'entreprise"
---
# Fiche mémo — M37 · Projet final : pipeline de données de bout en bout pour un RAG d'entreprise

> En une phrase : Bréval Assist ne répond juste que si ses données sont fraîches, cloisonnées et sans données personnelles. Le projet le prouve par une chaîne rejouable : registre et CDC, bronze immuable, silver contrôlée, index incrémental avec droits, puis évaluation, moniteurs et runbook.

## Les 7 idées à retenir
1. On cadre avant de coder : un métré par script (126 documents, 9 048 tickets, environ 9 400 chunks, 39 Mo de vecteurs). Le risque n'est pas le volume, mais la fraîcheur, les droits et les PII (`L180`).
2. Un SLO s'écrit avec un chiffre, un percentile et un lieu de mesure : suppression < 5 min (p95), effacement RGPD < 15 min, modification < 1 h, recall@5 ≥ 0,80, zéro fuite (`L180`).
3. Le registre `ged.documents` fait foi : la suppression d'un document passe par le WAL, comme celle d'une commande. Le bronze CDC est un journal Parquet immuable, dédoublonné par `(_topic, _partition, _offset)` (`L181`).
4. L'ordre de la couche silver est imposé : l'état courant est recalculé depuis le journal, puis viennent la PII sur le document entier, la déduplication des documents, et enfin le chunking avec les droits. Presidio n'est relancé que si l'empreinte ou `PII_TRAITEMENT` a changé (`L182`).
5. La déduplication de L176 est réglée par la mesure sur ce corpus : corps sans en-tête, 3-grammes, documents seulement, garder le plus récent. Résultat : 126 → 116 documents (`L182`).
6. La synchronisation de l'index produit trois listes : insérer d'abord, mettre à jour les droits par `set_payload` sans recalculer de vecteur, puis supprimer les points obsolètes. Les suppressions urgentes passent par le flux, et le batch ne doit jamais les ressusciter (`L183`).
7. L'exploitation repose sur trois verrous dans Dagster (GX, tests dbt, fuites de droits), cinq piliers d'observabilité, un coût par document mesuré dans `obs.etapes` et un runbook organisé en tableau « alerte → diagnostic → action » (`L184`).

## Le schéma à connaître
```mermaid
flowchart LR
  GED[("Postgres ged.documents<br/>erp.* · rgpd.demandes_effacement")] -->|"Debezium"| K{{"Kafka breval.*"}}
  FS["Fichiers"] --> M1[("MinIO breval-docs<br/>bucket versionné")]
  K --> B[("MinIO breval-lake<br/>bronze CDC Parquet")]
  SAV["Export SAV JSONL"] -->|"dlt"| D[("DuckDB data/breval.duckdb<br/>bronze")]
  B --> D
  D -->|"dbt amont"| P["rag.preparer<br/>Docling · Presidio · MinHash · chunking"]
  M1 --> P
  P --> S[("silver.rag_chunks<br/>+ droits")]
  S -->|"GX · dbt aval · ODCS"| E["Embeddings par lots<br/>cache Parquet"]
  E --> Q[("Qdrant · alias chunks")]
  K -->|"indexeur_suppressions"| Q
  Q --> A["Bréval Assist<br/>filtre agences ET groupes"]
```

## La checklist de livraison
- [ ] Dossier d'architecture (2 pages) : métré, SLI et SLO, matrice des droits, PII et base légale, schéma, table de décision avec au moins 3 critères chiffrés par choix, écarts à L176 justifiés.
- [ ] `contrats/rag_chunks.odcs.yaml` : `datacontract lint`, puis `datacontract test` avec au moins 4 règles bloquantes.
- [ ] Docker Compose de 5 services (Postgres, MinIO, Kafka, Connect, Qdrant), connecteur sur 4 tables avec `column.exclude.list`.
- [ ] Bronze chargé deux fois (« 0 nouveaux événements ») et même nombre d'événements après un `kill -9`.
- [ ] Silver : seconde préparation sans appel Presidio, 10 doublons tracés dans `rapport_dedup.json`, rappel PII ≥ 90 %, blocage démontré par GX, dbt et le contrat.
- [ ] Index : deuxième synchronisation à 0 partout, changement de droits sans ré-embedding, 30 questions (dont 10 synthétiques relues), deux chunkings comparés, `test_rag.py` à 9 tests verts.
- [ ] Dagster planifié toutes les 15 min, cinq piliers historisés, incident simulé et son post-mortem, `make couts` commenté, runbook, soutenance de 15 min.

## La grille d'évaluation
| Critère | Poids | Preuve rejouable |
|---|---|---|
| Bout en bout | 25 % | `make plateforme connecteur`, puis une matérialisation complète dans Dagster |
| Idempotence, incrémental, CDC | 20 % | `test_idempotence.py`, `test_rag.py -k "idempotente or suppression"` |
| Qualité, gouvernance, PII | 20 % | `datacontract test`, `gx_chunks.py`, `evaluer_pii.py`, `gold.rag_qualite_corpus` |
| Évaluation RAG | 15 % | `rag.evaluation` sur les deux collections, `test_cloisonnement` |
| Observabilité et coûts | 10 % | `make moniteurs`, post-mortem, `make couts` |
| Documentation et soutenance | 10 % | dossier, runbook, contrat, `dbt docs` |

## Vocabulaire express
| Terme | En clair |
|---|---|
| SLI / SLO / SLA | Le thermomètre / la température visée / la promesse faite à l'utilisateur |
| Registre documentaire | La table qui dit quels documents existent : sa ligne supprimée devient un événement `d` |
| `droits_hash` | L'empreinte des agences et des groupes : si elle change, on modifie les métadonnées sans recalculer le vecteur |
| Gabarit | Une section répétée dans au moins 5 documents, exclue de l'index (« Respecter les règles de l'art… ») |
| Résurrection | Un document supprimé par le flux que le batch suivant réindexe par erreur |
| Bascule d'alias | Faire pointer `chunks` vers une nouvelle collection en une seule requête atomique |

## Les pièges classiques
- Faire la PII après le chunking : un téléphone coupé en deux échappe aux détecteurs.
- Passer les tickets dans MinHash : des milliers de cas clients distincts seraient fusionnés.
- Supprimer avant d'insérer, ou ne supprimer que dans la collection servie.
- Écrire le CDC directement dans DuckDB, ou lancer les tests pendant que Dagster tourne : un seul écrivain est accepté.
- Oublier l'ancien connecteur et le slot `debezium_breval` de L169 : la publication ne couvre alors que deux tables.
- Croire que `delete_object` efface un objet dans un bucket versionné : il ne pose qu'un marqueur de suppression.
- Générer une nouvelle `PII_HMAC_KEY` à chaque session : tout le corpus est alors ré-embeddé.

## Les commandes / chiffres / dates utiles
```bash
python cadrage/volumetrie.py ; datacontract lint contrats/rag_chunks.odcs.yaml
python ingestion/ged_simulateur.py init | modifier PRC-014 | supprimer PRC-014 | restaurer PRC-014 | effacer-client 937
python cdc/cdc_vers_bronze.py ; python -m rag.bronze_cdc ; python cdc/indexeur_suppressions.py
python -m rag.preparer ; python -m rag.embeddings ; python -m rag.index [--basculer chunks_…]
python -m rag.evaluation --collection chunks_bge_m3_v1 ; pytest -q -s tests_pipeline/test_rag.py
make dagster-rag ; make moniteurs ; make couts
```
- Chiffres de référence (échelle 1) : 126 documents → 116 après déduplication (taux 7,9 %), 9 426 chunks dont 9 326 indexables, 378 chunks de documents dont 100 gabarits, 116 en `doc-entier-v1`, PRC-014 = 4 points, 236 exemples PII (222 entités).
- Paramètres : bge-m3, 1 024 dimensions, `bge-m3@2026-11`, `struct-md-v2-max350-rec50`, collection `chunks_bge_m3_v1`, alias `chunks`, cron `*/15 7-19 * * 1-6` (Europe/Paris).
- Coût : Mistral Embed 0,10 $ par million de tokens (nov. 2026), soit moins de 0,10 $ pour tout le corpus (environ 0,8 M de tokens). Le rachat de Dagster par Prefect a été annoncé le 13 juillet 2026 : c'est un risque à suivre dans le dossier.

## Pour aller plus loin
- [Debezium — documentation](https://debezium.io/documentation/)
- [Qdrant — documentation](https://qdrant.tech/documentation/)
- [Bitol — Open Data Contract Standard](https://github.com/bitol-io/open-data-contract-standard)

## Auto-test (3 questions — réponses en bas de fiche)
1. Pourquoi la suppression d'un document passe-t-elle par Postgres plutôt que par MinIO ?
2. Les droits de PRC-024 changent sans que son texte change : que recalcule le pipeline ?
3. Qu'est-ce qui empêche le micro-batch de réindexer un document supprimé par le flux ?

---
**Réponses.** 1) Le registre `ged.documents` est la source de vérité : sa suppression produit un événement `d` ordonné et horodaté, que Debezium capte comme pour toute autre table. 2) La pseudonymisation est réutilisée (même empreinte) et le `chunk_id` est inchangé, donc aucun vecteur n'est recalculé. Seuls les droits et le `droits_hash` changent, et l'index applique `set_payload`. 3) Le batch lit `rag_documents_courants`, recalculé depuis le même journal CDC : un document dont le dernier événement est `d` en est exclu. Il en va de même pour les clients effacés dans `rag_tickets_a_indexer`.
