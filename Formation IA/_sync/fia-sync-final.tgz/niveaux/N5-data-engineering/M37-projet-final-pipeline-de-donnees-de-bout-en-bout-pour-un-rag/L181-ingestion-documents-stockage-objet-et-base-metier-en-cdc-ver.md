---
id: L181
module: M37
level: N5
title: "Ingestion : documents (stockage objet) et base métier en CDC vers la couche bronze"
minutes: 45
objectives:
  - "Déployer en local la plateforme du projet (Postgres, MinIO, Kafka KRaft, Debezium, Qdrant) avec un seul Docker Compose"
  - "Déposer les documents de Bréval dans un bucket versionné et tenir un registre documentaire dont chaque changement est capturé"
  - "Configurer Debezium pour publier dans Kafka les changements de l'ERP, du registre documentaire et du registre RGPD, en minimisant les données personnelles"
  - "Écrire un consommateur « au moins une fois » qui produit une couche bronze immuable en Parquet dans MinIO, puis la charger dans DuckDB sans doublon"
skills: ["C5.2", "C5.3"]
sources:
  - { title: "Debezium — documentation", url: "https://debezium.io/documentation/", lang: "en" }
  - { title: "Debezium examples — wiki", url: "https://github.com/debezium/debezium-examples/wiki", lang: "en" }
  - { title: "Apache Kafka — Kafka Connect", url: "https://kafka.apache.org/documentation/#connect", lang: "en" }
  - { title: "MinIO — documentation", url: "https://min.io/", lang: "en" }
  - { title: "dlt — documentation", url: "https://dlthub.com/docs", lang: "en" }
  - { title: "SSOJet — Kafka 4.0 release (KRaft par défaut)", url: "https://ssojet.com/blog/kafka-40-release-simplified-architecture-with-default-kraft", lang: "en" }
  - { title: "DuckDB 2.0 — Integration with Polars", url: "https://duckdb.org/docs/2.0/guides/python/polars.html", lang: "en" }
---

# Ingestion : documents (stockage objet) et base métier en CDC vers la couche bronze

> ⏱ 45 min · 🎯 Niveau 5 · 📚 Module 37

## 🎯 Ce que vous saurez faire
- Démarrer toute la plateforme du projet avec un seul `docker compose up -d` et vérifier chaque service.
- Faire entrer les documents de Bréval dans MinIO avec un registre documentaire Postgres dont **chaque** ajout, modification ou suppression devient un événement.
- Brancher Debezium sur quatre tables, sans recopier dans Kafka les données personnelles inutiles.
- Construire une couche bronze **immuable** et **rejouable** : des fichiers Parquet numérotés par offset Kafka, chargés dans DuckDB sans doublon.

> 🧭 **En clair** — Pensez au quai de réception du dépôt de Bréval. Chaque camion arrive avec un bon de livraison numéroté ; le magasinier range la marchandise **telle quelle** dans une zone de réception, note le numéro du bon dans son registre, et ne signe le bon qu'une fois la palette posée. Si le camion repasse avec le même bon, il le reconnaît et ne range rien en double. Ici, les camions sont les changements de la base de données (lus par Debezium), les bons numérotés sont les offsets Kafka, la zone de réception est la couche bronze dans MinIO, et « signer le bon » s'appelle valider l'offset. On ne transforme rien à ce stade : on reçoit, on range, on trace.

## 1. Trois chemins d'entrée, une seule couche bronze

| Source | Ce qui change | Chemin d'ingestion | Bronze | Pourquoi ce chemin |
|---|---|---|---|---|
| Serveur de fichiers (Markdown, PDF) | contenu des documents | dépôt dans le bucket versionné `breval-docs` + ligne dans `ged.documents` | objets MinIO | un document est un **fichier** : sa place est le stockage objet (L156) |
| Registre `ged.documents`, ERP `erp.commandes` / `erp.clients`, registre `rgpd.demandes_effacement` | lignes insérées, modifiées, **supprimées** | Debezium → Kafka → consommateur `bronze-cdc` | Parquet dans `breval-lake/bronze/cdc/` puis `bronze.cdc_evenements` | seul le journal (WAL) voit les suppressions (L162) |
| Outil SAV (SaaS) | tickets et messages | export JSONL horaire + dlt (L162, inchangé) | `bronze.tickets_sav`, `bronze.tickets_sav__messages` | la source n'offre qu'un export |

> 💡 **À retenir** — Le fichier est stocké dans MinIO, mais **l'événement** « ce fichier a changé » passe par la base : c'est le registre `ged.documents` qui fait foi. Ainsi, une suppression de document suit exactement le même chemin qu'une suppression de commande, et se propage en quelques secondes.

## 2. Démarrer la plateforme

Remplacez `breval/docker-compose.yml` (L151, complété en L156) par cette version consolidée. Le service `postgres` garde son nom et son volume : vos données de M31-M33 sont conservées. Elle remplace aussi `docker-compose.kafka.yml` (L167) et `docker-compose.cdc.yml` (L169) : si ces services tournent encore, arrêtez-les d'abord avec `docker compose -f docker-compose.yml -f docker-compose.kafka.yml -f docker-compose.cdc.yml down` (sans `-v`, pour garder le volume Postgres), sinon les noms `breval-kafka` et `breval-connect` entrent en conflit. Le Schema Registry de L167 n'est plus utilisé : le connecteur publie en JSON.

```yaml
# breval/docker-compose.yml — plateforme du projet final (Postgres, MinIO, Kafka KRaft, Debezium, Qdrant)
services:
  postgres:
    image: postgres:17
    container_name: breval-postgres
    environment:
      POSTGRES_DB: breval
      POSTGRES_USER: breval
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-breval_local}
    command: ["postgres", "-c", "wal_level=logical"]            # posé dès L151 pour ce moment
    ports: ["5432:5432"]
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./sql:/docker-entrypoint-initdb.d:ro

  minio:
    image: minio/minio:${MINIO_TAG:-latest}                     # figez un tag précis (avertissement de L156)
    container_name: breval-minio
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: breval
      MINIO_ROOT_PASSWORD: ${MINIO_ROOT_PASSWORD:-breval_local_123}
    ports: ["9000:9000", "9001:9001"]
    volumes: [minio:/data]

  kafka:
    image: apache/kafka:${KAFKA_TAG:-4.1.0}                     # version courante : à vérifier (L167)
    container_name: breval-kafka
    ports: ["29092:29092"]
    environment:
      KAFKA_NODE_ID: 1
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_LISTENERS: INTERNE://:9092,EXTERNE://:29092,CONTROLLER://:9093
      KAFKA_ADVERTISED_LISTENERS: INTERNE://kafka:9092,EXTERNE://localhost:29092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: INTERNE:PLAINTEXT,EXTERNE:PLAINTEXT,CONTROLLER:PLAINTEXT
      KAFKA_INTER_BROKER_LISTENER_NAME: INTERNE
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@kafka:9093
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR: 1
      KAFKA_TRANSACTION_STATE_LOG_MIN_ISR: 1

  connect:
    image: quay.io/debezium/connect:${DEBEZIUM_TAG:-3.2}        # compatibilité Kafka 4 : à vérifier sur debezium.io
    container_name: breval-connect
    depends_on: [kafka, postgres]
    ports: ["8083:8083"]
    environment:
      BOOTSTRAP_SERVERS: kafka:9092
      GROUP_ID: connect-breval
      CONFIG_STORAGE_TOPIC: connect_configs
      OFFSET_STORAGE_TOPIC: connect_offsets
      STATUS_STORAGE_TOPIC: connect_statuses

  qdrant:
    image: qdrant/qdrant:${QDRANT_TAG:-latest}                  # figez aussi ce tag une fois le projet validé
    container_name: breval-qdrant
    ports: ["6333:6333", "6334:6334"]
    volumes: [qdrant:/qdrant/storage]

volumes:
  pgdata:
  minio:
  qdrant:
```

```bash
cd breval
docker compose up -d
docker compose ps                                   # 5 services « running »
pip install boto3 confluent-kafka pyarrow psycopg2-binary qdrant-client duckdb
```

> 🛠️ **Si ça ne marche pas** — « Conflict. The container name "/breval-qdrant" is already in use » → vous avez démarré Qdrant à la main en L174 ou L178 : `docker rm -f breval-qdrant` (les données de ce conteneur de test sont perdues, ce qui est sans conséquence ici), puis relancez `docker compose up -d`. Même remède pour `breval-kafka` ou `breval-connect` si l'arrêt décrit ci-dessus a été oublié. Le Schema Registry de L167 peut rester arrêté : `docker rm -f breval-schema-registry`. Un service en `Restarting` → `docker compose logs <service>` pour lire la cause (souvent la mémoire : fermez Spark, Dagster ou Airflow).

**Point de contrôle** — `docker compose ps` affiche cinq services ; la console MinIO répond sur `http://localhost:9001`, l'API Kafka Connect sur `curl -s http://localhost:8083/` (un JSON avec la version), Qdrant sur `curl -s http://localhost:6333/collections` (liste vide).

> ⚠️ **Piège fréquent** — Le broker Kafka de ce TP n'a pas de volume : `docker compose down` efface les topics, mais **pas** les offsets mémorisés par vos consommateurs… qui sont eux aussi dans Kafka, donc effacés aussi. Après un `down`, tout repart de l'instantané initial de Debezium **avec des offsets qui recommencent à 0** : les nouveaux messages reprennent donc des triplets `(_topic, _partition, _offset)` déjà présents en bronze, et le dédoublonnage par clé de la section 6 garderait les anciennes lignes en **ignorant les nouvelles** (perte silencieuse de changements). Règle du TP : après un `docker compose down`, videz aussi la couche bronze CDC avant de relancer ; en production, donnez un volume persistant au broker (et ajoutez l'identifiant du cluster Kafka à la clé de dédoublonnage si un broker peut être recréé).

## 3. Le registre documentaire et le registre RGPD

Ajoutez `breval/sql/03_ged_rgpd.sql`. Les scripts de `sql/` ne s'exécutent qu'au premier démarrage (L151) : appliquez-le à la main.

```sql
-- breval/sql/03_ged_rgpd.sql — registre documentaire (GED) et registre des demandes d'effacement
CREATE SCHEMA IF NOT EXISTS ged;
CREATE TABLE IF NOT EXISTS ged.documents (
  doc_id          text PRIMARY KEY,                 -- PRC-001, FT-BRV-ISO-00075, CGV-2026-PRO…
  cle_objet       text NOT NULL,                    -- clé de l'objet dans le bucket breval-docs
  titre           text NOT NULL,
  type_document   text NOT NULL,
  service         text NOT NULL,
  version         text NOT NULL,
  date_maj        date NOT NULL,
  confidentialite text NOT NULL CHECK (confidentialite IN ('public', 'interne', 'restreint')),
  sha256          char(64) NOT NULL,                -- empreinte du fichier : détecte un vrai changement
  modifie_le      timestamptz NOT NULL DEFAULT now()
);
-- Une suppression publiera TOUTE l'ancienne ligne (service, titre…), utile à l'audit
ALTER TABLE ged.documents REPLICA IDENTITY FULL;

CREATE SCHEMA IF NOT EXISTS rgpd;
CREATE TABLE IF NOT EXISTS rgpd.demandes_effacement (
  demande_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  client_id  integer NOT NULL,                       -- pas de clé étrangère : le client pourra être anonymisé
  recue_le   timestamptz NOT NULL DEFAULT now(),
  motif      text NOT NULL DEFAULT 'article 17 RGPD'
);
```

```bash
docker exec -i breval-postgres psql -U breval -d breval < sql/03_ged_rgpd.sql
```

> 🔍 **Ce que vous devez voir** — `CREATE SCHEMA`, `CREATE TABLE`, `ALTER TABLE`, `CREATE SCHEMA`, `CREATE TABLE`. Relancé, le script répond par des avis `NOTICE: … already exists, skipping` sans erreur, grâce aux `IF NOT EXISTS`.

Pourquoi un **registre des demandes d'effacement** plutôt qu'un simple `DELETE` du client ? Parce que l'ERP ne peut pas supprimer un client qui a des commandes (clés étrangères, obligations comptables) : il l'anonymise (L174). Le registre transforme la demande en un **événement explicite**, que l'indexeur saura appliquer à l'index et que le batch saura respecter.

## 4. Les documents dans le stockage objet

Le projet est un paquet Python, `rag/`, lancé depuis `breval/` avec `export PYTHONPATH=$PWD`. (Un **paquet** est un dossier de modules Python qu'on importe par son nom, comme `from rag.config import s3` ; `PYTHONPATH` indique à Python où chercher ces paquets, ici le dossier courant. Cette variable disparaît quand on ferme le terminal : refaites l'`export` dans **chaque** nouveau terminal, sous PowerShell `$env:PYTHONPATH = $PWD`.) Son module de configuration lit tout depuis l'environnement :

```python
# rag/config.py — paramètres du projet, lus depuis l'environnement (aucun secret dans le code)
import os
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent              # dossier breval/
DUCKDB_PATH = os.environ.get("BREVAL_DUCKDB_PATH", str(RACINE / "data" / "breval.duckdb"))
PG_URL = os.environ.get("BREVAL_PG_URL", "postgresql://breval:breval_local@localhost:5432/breval")
S3_ENDPOINT = os.environ.get("S3_ENDPOINT", "http://localhost:9000")
S3_KEY = os.environ.get("MINIO_ROOT_USER", "breval")
S3_SECRET = os.environ.get("MINIO_ROOT_PASSWORD", "breval_local_123")
BUCKET_DOCS, BUCKET_LAKE = "breval-docs", "breval-lake"
KAFKA = os.environ.get("KAFKA_BOOTSTRAP", "localhost:29092")
TOPICS_CDC = ["breval.erp.commandes", "breval.erp.clients",
              "breval.ged.documents", "breval.rgpd.demandes_effacement"]
QDRANT_URL = os.environ.get("QDRANT_URL", "http://localhost:6333")
ALIAS = "chunks"                                              # l'assistant n'interroge que l'alias (L178)
COLLECTION = os.environ.get("RAG_COLLECTION", "chunks_bge_m3_v1")
MODELE_EMBEDDING = os.environ.get("EMBEDDING_MODEL", "BAAI/bge-m3")
MODELE_V = os.environ.get("EMBEDDING_MODEL_V", "bge-m3@2026-11")
DIMENSION = int(os.environ.get("EMBEDDING_DIM", "1024"))
CHUNKING_V = os.environ.get("CHUNKING_V", "struct-md-v2-max350-rec50")
DATA_RAG = RACINE / "data" / "rag"
EMBEDDINGS_DIR = DATA_RAG / "embeddings"
AUDIT_SUPPRESSIONS = DATA_RAG / "audit" / "suppressions.jsonl"
SLO_SUPPRESSION_S = 300                                       # 5 minutes (contrat, L180)


def s3():
    import boto3
    return boto3.client("s3", endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_KEY,
                        aws_secret_access_key=S3_SECRET, region_name="us-east-1")


def connexion_duckdb(read_only: bool = False):
    """Connexion DuckDB avec accès à MinIO (même secret qu'en L156)."""
    import duckdb
    con = duckdb.connect(DUCKDB_PATH, read_only=read_only)
    con.execute("INSTALL httpfs; LOAD httpfs;")
    hote = S3_ENDPOINT.split("://")[-1]
    con.execute(f"""CREATE OR REPLACE SECRET minio (TYPE s3, KEY_ID '{S3_KEY}', SECRET '{S3_SECRET}',
                    REGION 'us-east-1', ENDPOINT '{hote}', URL_STYLE 'path', USE_SSL false)""")
    return con
```

Bréval n'a pas de vraie GED : ce simulateur en joue le rôle. Il dépose les fichiers dans MinIO **et** tient le registre, dans un ordre qui ne laisse jamais une ligne pointer vers un fichier absent.

```python
# ingestion/ged_simulateur.py — la « GED » de Bréval : fichiers dans MinIO + registre ged.documents
# Usage : python ingestion/ged_simulateur.py init | modifier DOC_ID | supprimer DOC_ID | restaurer DOC_ID
#         | ajouter FICHIER --service S --confidentialite C --titre T | effacer-client CLIENT_ID
import argparse
import csv
import hashlib
import re
from datetime import date
from pathlib import Path

import psycopg2

from rag.config import BUCKET_DOCS, BUCKET_LAKE, PG_URL, s3

RAW = Path("data/raw/documents")
UPSERT = """
INSERT INTO ged.documents (doc_id, cle_objet, titre, type_document, service, version, date_maj,
                           confidentialite, sha256, modifie_le)
VALUES (%(doc_id)s, %(cle_objet)s, %(titre)s, %(type_document)s, %(service)s, %(version)s,
        %(date_maj)s, %(confidentialite)s, %(sha256)s, now())
ON CONFLICT (doc_id) DO UPDATE SET
  cle_objet = EXCLUDED.cle_objet, titre = EXCLUDED.titre, type_document = EXCLUDED.type_document,
  service = EXCLUDED.service, version = EXCLUDED.version, date_maj = EXCLUDED.date_maj,
  confidentialite = EXCLUDED.confidentialite, sha256 = EXCLUDED.sha256, modifie_le = now()
WHERE ged.documents.sha256 <> EXCLUDED.sha256                 -- pas d'UPDATE à vide : pas d'événement CDC inutile
   OR ged.documents.confidentialite <> EXCLUDED.confidentialite
"""


def preparer_buckets(c) -> None:
    existants = {b["Name"] for b in c.list_buckets().get("Buckets", [])}
    for nom in (BUCKET_DOCS, BUCKET_LAKE):
        if nom not in existants:
            c.create_bucket(Bucket=nom)
    c.put_bucket_versioning(Bucket=BUCKET_DOCS, VersioningConfiguration={"Status": "Enabled"})


def deposer(c, doc: dict, contenu: bytes, extension: str) -> dict:
    """1) l'objet d'abord, 2) la ligne ensuite : le registre ne pointe jamais vers un fichier absent."""
    doc = {**doc, "cle_objet": f"documents/{doc['doc_id']}.{extension}",
           "sha256": hashlib.sha256(contenu).hexdigest()}
    c.put_object(Bucket=BUCKET_DOCS, Key=doc["cle_objet"], Body=contenu, Metadata={"sha256": doc["sha256"]})
    with psycopg2.connect(PG_URL) as pg, pg.cursor() as cur:   # le bloc « with » valide la transaction
        cur.execute(UPSERT, doc)
    return doc


def catalogue() -> dict[str, dict]:
    with (RAW / "documents.csv").open(encoding="utf-8") as f:
        return {r["doc_id"]: r for r in csv.DictReader(f, delimiter=";")}


def depuis_catalogue(c, doc_id: str) -> dict:
    r = catalogue()[doc_id]
    meta = {k: r[k] for k in ("doc_id", "titre", "type_document", "service", "version", "date_maj", "confidentialite")}
    return deposer(c, meta, (RAW / "md" / f"{doc_id}.md").read_bytes(), "md")


def ligne(doc_id: str) -> dict:
    with psycopg2.connect(PG_URL) as pg, pg.cursor() as cur:
        cur.execute("SELECT doc_id, cle_objet, titre, type_document, service, version, date_maj, confidentialite "
                    "FROM ged.documents WHERE doc_id = %s", (doc_id,))
        valeurs = cur.fetchone()
        if valeurs is None:
            raise SystemExit(f"{doc_id} absent du registre")
        return dict(zip([d[0] for d in cur.description], valeurs))


def main() -> None:
    ap = argparse.ArgumentParser(description="Simulateur de GED (projet final M37)")
    ap.add_argument("commande", choices=["init", "modifier", "supprimer", "restaurer", "ajouter", "effacer-client"])
    ap.add_argument("cible", nargs="?")
    ap.add_argument("--service", default="direction")
    ap.add_argument("--confidentialite", default="interne")
    ap.add_argument("--titre")
    a = ap.parse_args()
    c = s3()

    if a.commande == "init":
        preparer_buckets(c)
        for doc_id in catalogue():
            depuis_catalogue(c, doc_id)
        print(f"{len(catalogue())} documents déposés et enregistrés")
    elif a.commande == "restaurer":
        depuis_catalogue(c, a.cible)
        print(f"{a.cible} restauré depuis le catalogue d'origine")
    elif a.commande == "modifier":
        doc = ligne(a.cible)
        texte = c.get_object(Bucket=BUCKET_DOCS, Key=doc["cle_objet"])["Body"].read().decode("utf-8")
        texte += f"\n## Mise à jour du {date.today():%d/%m/%Y}\nPrécision ajoutée par le service {doc['service']}.\n"
        m = re.fullmatch(r"v(\d+)", doc["version"])
        doc["version"] = f"v{int(m.group(1)) + 1}" if m else doc["version"] + ".1"
        doc["date_maj"] = date.today().isoformat()
        deposer(c, doc, texte.encode("utf-8"), doc["cle_objet"].rsplit(".", 1)[1])
        print(f"{a.cible} modifié → {doc['version']}")
    elif a.commande == "supprimer":
        with psycopg2.connect(PG_URL) as pg, pg.cursor() as cur:          # 1) la ligne : l'événement part
            cur.execute("DELETE FROM ged.documents WHERE doc_id = %s RETURNING cle_objet", (a.cible,))
            supprime = cur.fetchone()
        if supprime:
            c.delete_object(Bucket=BUCKET_DOCS, Key=supprime[0])       # 2) l'objet (marqueur de suppression)
        print(f"{a.cible} supprimé" if supprime else f"{a.cible} introuvable")
    elif a.commande == "ajouter":                                    # ex. un PDF déposé par un service (EXT-…)
        chemin = Path(a.cible)
        meta = {"doc_id": "EXT-" + re.sub(r"\W+", "-", chemin.stem).upper(), "titre": a.titre or chemin.stem,
                "type_document": "pdf_externe", "service": a.service, "version": "v1",
                "date_maj": date.today().isoformat(), "confidentialite": a.confidentialite}
        print(deposer(c, meta, chemin.read_bytes(), chemin.suffix.lstrip(".").lower())["doc_id"], "ajouté")
    elif a.commande == "effacer-client":
        with psycopg2.connect(PG_URL) as pg, pg.cursor() as cur:
            cur.execute("INSERT INTO rgpd.demandes_effacement (client_id) VALUES (%s) RETURNING demande_id",
                        (int(a.cible),))
            print("demande d'effacement n°", cur.fetchone()[0])


if __name__ == "__main__":
    main()
```

```bash
export PYTHONPATH=$PWD
python ingestion/ged_simulateur.py init
docker exec -it breval-postgres psql -U breval -d breval \
  -c "SELECT confidentialite, count(*) FROM ged.documents GROUP BY 1 ORDER BY 1"
python -c "from rag.config import s3, BUCKET_DOCS; print(s3().list_objects_v2(Bucket=BUCKET_DOCS)['KeyCount'])"
```

> 🛠️ **Si ça ne marche pas** — « ModuleNotFoundError: No module named 'rag' » → l'`export PYTHONPATH=$PWD` n'a pas été fait dans ce terminal, ou vous n'êtes pas dans `breval/`. « relation "ged.documents" does not exist » → `03_ged_rgpd.sql` n'a pas été appliqué. « Could not connect to the endpoint URL: "http://localhost:9000/…" » → MinIO n'est pas démarré. La dernière commande affiche `126` : c'est le nombre d'objets du bucket.

> 🔍 **Ce que vous devez voir** — `init` affiche `126 documents déposés et enregistrés` ; le `SELECT` affiche trois lignes `interne | 19`, `public | 86`, `restreint | 21`.

**Point de contrôle** — 126 documents enregistrés (`interne` 19, `public` 86, `restreint` 21) et 126 objets dans `breval-docs`. Relancez `init` : aucune ligne ne change (la clause `WHERE` de l'upsert évite les mises à jour à vide), donc **aucun événement CDC parasite** ne sera émis.

```quiz
{
  "q": "Pourquoi le simulateur supprime-t-il d'abord la ligne du registre, puis seulement l'objet dans MinIO ?",
  "options": ["Parce que MinIO refuse de supprimer un objet encore référencé par une ligne Postgres", "Pour que l'événement parte aussitôt et que le registre ne vise jamais un fichier absent", "Pour regrouper les deux suppressions dans une seule transaction Postgres", "L'ordre est sans importance : Debezium réordonne les événements par LSN"],
  "answer": 1,
  "explanation": "Si l'objet disparaissait d'abord, le pipeline pourrait lire une ligne encore présente et échouer en téléchargeant un fichier absent. Dans l'ordre inverse, le pire cas est un objet orphelin, sans conséquence et repérable par une réconciliation."
}
```

> ⚠️ **Piège fréquent** — Croire que `delete_object` efface le fichier. Dans un bucket **versionné**, il pose un **marqueur de suppression** : les versions précédentes restent lisibles. C'est précieux en cas d'erreur, mais pour un effacement RGPD il faut supprimer **toutes les versions** (`list_object_versions` puis `delete_object(..., VersionId=...)`) ou configurer une règle de cycle de vie (L156). Notez-le dans le runbook (L184).

## 5. Brancher Debezium sur quatre tables

```json
{
  "name": "breval-postgres",
  "config": {
    "connector.class": "io.debezium.connector.postgresql.PostgresConnector",
    "plugin.name": "pgoutput",
    "database.hostname": "postgres",
    "database.port": "5432",
    "database.user": "breval",
    "database.password": "breval_local",
    "database.dbname": "breval",
    "topic.prefix": "breval",
    "table.include.list": "erp.commandes,erp.clients,ged.documents,rgpd.demandes_effacement",
    "column.exclude.list": "erp.clients.nom,erp.clients.prenom,erp.clients.email,erp.clients.telephone",
    "slot.name": "debezium_breval",
    "publication.autocreate.mode": "filtered",
    "decimal.handling.mode": "string",
    "key.converter": "org.apache.kafka.connect.json.JsonConverter",
    "key.converter.schemas.enable": "false",
    "value.converter": "org.apache.kafka.connect.json.JsonConverter",
    "value.converter.schemas.enable": "false"
  }
}
```

Enregistrez ce JSON dans `cdc/connecteur-breval.json` : il remplace celui de L169 (connecteur `breval-erp`, deux tables). Si vous avez fait L169, retirez d'abord l'ancien connecteur, puis le slot et la publication qu'il a laissés dans Postgres, limités à `erp.commandes` et `erp.clients` ; le nouveau connecteur les recrée pour les quatre tables :

```bash
curl -s -X DELETE http://localhost:8083/connectors/breval-erp      # « 404 » si Kafka a été recréé entre-temps : sans gravité
docker exec -it breval-postgres psql -U breval -d breval \
  -c "SELECT pg_drop_replication_slot('debezium_breval')" -c "DROP PUBLICATION IF EXISTS dbz_publication"
```

La ligne `column.exclude.list` applique la **minimisation** dès la source : nom, prénom, e-mail et téléphone des clients n'entrent jamais dans Kafka, puisque l'assistant n'en a pas besoin. Le préfixe `breval` donne les topics `breval.<schéma>.<table>`, comme annoncé en L162.

```bash
curl -s -X POST -H "Content-Type: application/json" --data @cdc/connecteur-breval.json http://localhost:8083/connectors
curl -s http://localhost:8083/connectors/breval-postgres/status          # "state":"RUNNING" (connecteur et tâche)
docker exec breval-kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka:9092 --list | grep breval
docker exec breval-kafka /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server kafka:9092 \
  --topic breval.ged.documents --from-beginning --max-messages 1
```

**Point de contrôle** — quatre topics `breval.*` existent ; le premier message de `breval.ged.documents` porte `"op":"r"` (lecture de l'instantané initial) et un `after` complet. Regardez le champ `date_maj` : c'est un **entier** (nombre de jours depuis le 1er janvier 1970), pas une date lisible. C'est l'encodage par défaut de Debezium pour une colonne `date` (comportement à vérifier dans la doc selon `time.precision.mode`) ; vous le reconvertirez en L182.

```mission
{
  "title": "Le mode d'instantané initial de Debezium",
  "url": "https://debezium.io/documentation/",
  "steps": ["Ouvrez la documentation Debezium, puis la référence du connecteur PostgreSQL", "Cherchez la propriété snapshot.mode", "Relevez sa valeur par défaut et deux autres valeurs possibles"],
  "question": "Quelle est la valeur par défaut de snapshot.mode, et que fait-elle au premier démarrage du connecteur ?",
  "hint": "Elle explique pourquoi vous avez reçu des événements « r ».",
  "answer": "initial : au premier démarrage (aucun offset enregistré), le connecteur lit un instantané de toutes les tables suivies, puis passe au flux du WAL (doc consultée en nov. 2026 ; d'autres valeurs existent, par exemple never/no_data ou when_needed selon les versions) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 6. Le consommateur bronze : immuable, numéroté, rejouable

Le consommateur lit les quatre topics et écrit chaque lot en Parquet dans `s3://breval-lake/bronze/cdc/<table>/date=<jour>/p<partition>-o<premier offset>-<dernier offset>.parquet`. Il **n'écrit pas dans DuckDB** : DuckDB n'accepte qu'un processus écrivain (L165), et ce consommateur tourne en permanence ; il bloquerait le pipeline.

```python
# cdc/cdc_vers_bronze.py — Kafka (Debezium) -> Parquet immuables dans s3://breval-lake/bronze/cdc/ (au moins une fois)
import io
import json
import statistics
import time
from collections import defaultdict
from datetime import datetime, timezone

import pyarrow as pa
import pyarrow.parquet as pq
from confluent_kafka import Consumer, KafkaException

from rag.config import BUCKET_LAKE, KAFKA, TOPICS_CDC, s3

SCHEMA = pa.schema([
    ("_topic", pa.string()), ("_partition", pa.int32()), ("_offset", pa.int64()),
    ("op", pa.string()), ("lsn", pa.int64()), ("source_ts_ms", pa.int64()), ("ts_ms", pa.int64()),
    ("cle", pa.string()), ("avant", pa.string()), ("apres", pa.string()),
    ("_ingere_le", pa.timestamp("ms", tz="UTC")),
])


def convertir(m) -> dict:
    evt = json.loads(m.value())
    return {
        "_topic": m.topic(), "_partition": m.partition(), "_offset": m.offset(),
        "op": evt["op"], "lsn": evt["source"].get("lsn"), "source_ts_ms": evt["source"]["ts_ms"],
        "ts_ms": evt.get("ts_ms"), "cle": m.key().decode("utf-8") if m.key() else None,
        "avant": json.dumps(evt["before"], ensure_ascii=False) if evt.get("before") else None,
        "apres": json.dumps(evt["after"], ensure_ascii=False) if evt.get("after") else None,
        "_ingere_le": datetime.now(timezone.utc),
    }


def ecrire(client_s3, lot: list[dict]) -> str:
    premier, dernier = lot[0], lot[-1]
    table = premier["_topic"].split(".", 1)[1].replace(".", "_")      # breval.ged.documents -> ged_documents
    cle = (f"bronze/cdc/{table}/date={premier['_ingere_le']:%Y-%m-%d}/"
           f"p{premier['_partition']}-o{premier['_offset']:012d}-{dernier['_offset']:012d}.parquet")
    tampon = io.BytesIO()
    pq.write_table(pa.Table.from_pylist(lot, schema=SCHEMA), tampon, compression="zstd")
    client_s3.put_object(Bucket=BUCKET_LAKE, Key=cle, Body=tampon.getvalue())
    return cle


def main() -> None:
    client_s3 = s3()
    consommateur = Consumer({"bootstrap.servers": KAFKA, "group.id": "bronze-cdc",
                             "enable.auto.commit": False,        # on valide APRÈS l'écriture dans MinIO
                             "auto.offset.reset": "earliest"})
    consommateur.subscribe(TOPICS_CDC)
    try:
        while True:
            messages = consommateur.consume(num_messages=2000, timeout=5.0)
            if not messages:
                continue
            lots = defaultdict(list)                    # un fichier par (topic, partition) : offsets contigus
            for m in messages:
                if m.error():
                    raise KafkaException(m.error())
                if m.value() is None:                   # tombstone qui suit une suppression : ignoré
                    continue
                lots[(m.topic(), m.partition())].append(convertir(m))
            for lot in lots.values():
                ecrire(client_s3, lot)
            consommateur.commit(asynchronous=False)
            changements = [e for lot in lots.values() for e in lot if e["op"] != "r"]
            if changements:
                maintenant = time.time() * 1000
                latences = [(maintenant - e["source_ts_ms"]) / 1000 for e in changements]
                print(f"{len(changements)} changements · latence médiane {statistics.median(latences):.1f} s · "
                      f"max {max(latences):.1f} s")
            else:
                print(f"{sum(map(len, lots.values()))} lignes d'instantané écrites")
    except KeyboardInterrupt:
        pass
    finally:
        consommateur.close()


if __name__ == "__main__":
    main()
```

Si le processus s'arrête entre l'écriture et le `commit`, il relira le même lot au redémarrage : le fichier peut être réécrit à l'identique ou sous d'autres bornes d'offsets. Les lignes en double sont donc **possibles** en bronze (« au moins une fois ») ; elles sont éliminées au chargement grâce au triplet `(_topic, _partition, _offset)`, qui identifie un message Kafka de façon unique.

```python
# rag/bronze_cdc.py — lots CDC de MinIO -> bronze.cdc_evenements (DuckDB), sans doublon, rejouable
from rag.config import BUCKET_LAKE, connexion_duckdb, s3

DDL = """
CREATE TABLE IF NOT EXISTS bronze.cdc_evenements (
  _topic VARCHAR, _partition INTEGER, _offset BIGINT, op VARCHAR, lsn BIGINT, source_ts_ms BIGINT,
  ts_ms BIGINT, cle VARCHAR, avant VARCHAR, apres VARCHAR, _ingere_le TIMESTAMPTZ,
  PRIMARY KEY (_topic, _partition, _offset))"""


def charger_cdc(con) -> int:
    con.execute("CREATE SCHEMA IF NOT EXISTS bronze")
    con.execute(DDL)
    if not s3().list_objects_v2(Bucket=BUCKET_LAKE, Prefix="bronze/cdc/", MaxKeys=1).get("KeyCount"):
        return 0                                       # aucun lot encore écrit
    avant = con.execute("SELECT count(*) FROM bronze.cdc_evenements").fetchone()[0]
    con.execute(f"""
        INSERT OR IGNORE INTO bronze.cdc_evenements
        SELECT _topic, _partition, _offset, op, lsn, source_ts_ms, ts_ms, cle, avant, apres, _ingere_le
        FROM read_parquet('s3://{BUCKET_LAKE}/bronze/cdc/*/*/*.parquet',
                          hive_partitioning = false, union_by_name = true)
        QUALIFY row_number() OVER (PARTITION BY _topic, _partition, _offset ORDER BY _ingere_le) = 1""")
    return con.execute("SELECT count(*) FROM bronze.cdc_evenements").fetchone()[0] - avant


if __name__ == "__main__":
    con = connexion_duckdb()
    print(charger_cdc(con), "nouveaux événements CDC")
    print(con.sql("SELECT _topic, op, count(*) AS n FROM bronze.cdc_evenements GROUP BY ALL ORDER BY ALL"))
    con.close()
```

```bash
python cdc/cdc_vers_bronze.py          # terminal 1 : laissez-le tourner (instantané initial, puis flux)
python -m rag.bronze_cdc               # terminal 2 : chargement dans DuckDB
python -m rag.bronze_cdc               # relancé : « 0 nouveaux événements CDC »
```

> 🧭 **Pré-requis express** — `python -m rag.bronze_cdc` exécute le module `rag/bronze_cdc.py` **comme un script**, en le cherchant via `PYTHONPATH` : c'est pourquoi il faut l'`export` dans le terminal 2 aussi. `INSERT OR IGNORE` insère les lignes nouvelles et ignore silencieusement celles dont la clé primaire existe déjà.

> 🔍 **Ce que vous devez voir** — dans le terminal 1, une série de lignes `… lignes d'instantané écrites` (l'instantané arrive par paquets), puis le consommateur attend ; dans le terminal 2, `125201 nouveaux événements CDC` (126 + 120 000 + 5 075, à quelques unités près selon vos essais précédents) suivi d'un tableau `_topic | op | n`, puis, au second lancement, `0 nouveaux événements CDC`.

> 🛠️ **Si ça ne marche pas** — « Could not set lock on file "data/breval.duckdb" » → Dagster, `dbt docs serve` ou un autre script tient la base : arrêtez-les, c'est exactement la raison pour laquelle le consommateur écrit dans MinIO et non dans DuckDB. Le nombre est bien inférieur à 125 000 → l'instantané n'est pas terminé : attendez que le terminal 1 se calme, puis relancez le chargement.

**Point de contrôle** — Après l'instantané : 126 événements `r` sur `breval.ged.documents`, 120 000 sur `breval.erp.commandes` (119 995 si vous avez fait l'expérience 3 de L162 ; une minute environ), 5 075 sur `breval.erp.clients`, aucun sur le registre RGPD. Le second chargement annonce **0** : l'idempotence est démontrée. Vérifiez la minimisation : `SELECT apres FROM bronze.cdc_evenements WHERE _topic = 'breval.erp.clients' LIMIT 1` ne contient ni `nom` ni `email`.

> 💡 **Autrement dit** — Le bronze CDC est un **journal** : on n'y met jamais à jour une ligne, on y ajoute des événements. L'« état courant » d'un document (sa dernière version, ou le fait qu'il est supprimé) sera **recalculé** à partir du journal en L182. C'est ce qui rend tout rejouable : en cas de bogue en silver, on efface silver et on relit le journal.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : comme le consommateur valide ses offsets après l'écriture dans MinIO, la couche bronze ne contient jamais deux fois le même message Kafka.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Un arrêt entre l'écriture et le commit fait relire le lot : un même message peut se retrouver dans deux fichiers. C'est la garantie « au moins une fois ». Le doublon est neutralisé au chargement par la clé (_topic, _partition, _offset)."
}
```

## 7. Les tickets SAV et la latence du flux

Les tickets suivent le chemin de L162, sans changement : `make ingest` (ou `python ingestion/ingest.py`) charge `bronze.tickets_sav` et sa table enfant `bronze.tickets_sav__messages` créée par dlt. Vérifiez : `SELECT count(*) FROM bronze.tickets_sav` renvoie 9 048.

Mesurez maintenant la latence du flux documentaire, qui conditionne le SLO de suppression :

```bash
python ingestion/ged_simulateur.py modifier PRC-014      # terminal 2
# terminal 1 (consommateur) : « 1 changements · latence médiane 0.9 s · max 0.9 s » (ordre de grandeur)
python ingestion/ged_simulateur.py restaurer PRC-014     # retour à l'état d'origine (nouvel événement « u »)
```

La latence se mesure entre l'horodatage de validation de la transaction dans Postgres (`source.ts_ms`, le temps d'événement de L166) et l'écriture dans MinIO. Sur un poste, elle se compte en secondes : le budget de 5 minutes du SLO laisse une marge confortable pour l'indexeur de L183.

| Erreur fréquente | Symptôme | Parade |
|---|---|---|
| Slot de réplication abandonné | le disque de Postgres se remplit (WAL retenu) | surveiller `pg_replication_slots` (moniteur L184) ; supprimer le slot si le connecteur est retiré |
| `REPLICA IDENTITY` par défaut | la suppression ne contient que la clé primaire | `REPLICA IDENTITY FULL` sur les tables dont l'audit a besoin |
| Dates Debezium lues comme texte | `date_maj` vaut `20322` | conversion explicite en silver (jours depuis 1970) |
| Écrire le CDC directement dans DuckDB | « could not set lock on file » dans Dagster | fichiers immuables dans MinIO, chargement par le pipeline |
| Détection automatique des partitions Hive | colonne `date` en trop, `INSERT` en échec | `hive_partitioning = false` à la lecture |
| Données personnelles répliquées « au cas où » | e-mails des clients dans Kafka et MinIO | `column.exclude.list` dans le connecteur |

> ⚠️ **Piège fréquent** — Le mot de passe de la base en clair dans `connecteur-breval.json` et l'utilisateur `breval` propriétaire de tout : tolérable sur un poste de TP, jamais en production. Créez un rôle dédié limité à la réplication et à la lecture des quatre tables, et injectez le secret par un *config provider* de Kafka Connect (L169).

## 🧪 Exercice pratique

**Consigne** — (1) Démarrez la plateforme, appliquez `03_ged_rgpd.sql`, lancez `ged_simulateur.py init` et enregistrez le connecteur. (2) Lancez le consommateur bronze et chargez `bronze.cdc_evenements` deux fois. (3) Jouez le scénario : modifier PRC-014, supprimer FT-BRV-ELE-00005, effacer le client 937. (4) Rédigez un tableau « événement / op / topic / latence mesurée » et la requête SQL qui le prouve. (5) Arrêtez brutalement le consommateur (`kill -9`) pendant l'instantané, relancez-le, rechargez : le nombre d'événements distincts doit être identique à celui d'une exécution sans incident.

**Critères de réussite** — 5 services actifs ; 126 objets et 126 lignes de registre ; second chargement à 0 ; trois événements `u`, `d` et `c` visibles dans `bronze.cdc_evenements` avec latence inférieure à 10 s ; aucun champ `email` ni `telephone` dans les événements clients ; même nombre d'événements après le `kill -9`.

**Pistes de corrigé** — Requête de preuve : `SELECT _topic, op, json_extract_string(coalesce(apres, avant), '$.doc_id') AS doc, epoch_ms(source_ts_ms) AS a_la_source, _ingere_le, _ingere_le - epoch_ms(source_ts_ms) AS latence FROM bronze.cdc_evenements WHERE op <> 'r' ORDER BY source_ts_ms`. L'événement de suppression porte `op = 'd'`, `apres` nul et un `avant` complet grâce à `REPLICA IDENTITY FULL`. Après le `kill -9`, `count(*)` de bronze est identique car la clé primaire ignore les messages relus. Notez qu'en reprenant FT-BRV-ELE-00005 avec `restaurer`, vous obtiendrez un nouvel événement `c` (création).

## ✅ Auto-évaluation express
1. Pourquoi l'événement « document supprimé » passe-t-il par Postgres plutôt que par MinIO ?
2. Qu'est-ce qui identifie de façon unique un message Kafka, et à quoi cela sert-il ici ?
3. Quelle propriété du connecteur empêche les e-mails des clients d'entrer dans Kafka ?

**Réponses** — 1. Le registre `ged.documents` est la source de vérité ; sa suppression produit un événement ordonné, horodaté et capté par Debezium, comme toute autre table (le stockage objet sert les fichiers). 2. Le triplet topic, partition, offset : il permet de dédoublonner le bronze malgré la livraison « au moins une fois ». 3. `column.exclude.list` (minimisation à la source).

## 📚 Pour aller plus loin
- [Debezium — documentation](https://debezium.io/documentation/) 🇬🇧 — connecteur PostgreSQL : instantanés, `REPLICA IDENTITY`, types temporels, filtrage de colonnes.
- [Debezium examples](https://github.com/debezium/debezium-examples/wiki) 🇬🇧 — scénarios complets prêts à lancer.
- [Apache Kafka — Kafka Connect](https://kafka.apache.org/documentation/#connect) 🇬🇧 — workers, connecteurs, gestion des secrets.
- [MinIO — documentation](https://min.io/) 🇬🇧 — versioning, cycle de vie, notifications d'événements de bucket.
- [dlt — documentation](https://dlthub.com/docs) 🇬🇧 — tables enfants et évolution de schéma des tickets.

> ✅ **Si vous ne retenez que 3 choses** — 1. Trois chemins d'entrée alimentent une seule couche bronze : les fichiers dans un bucket MinIO versionné, les changements de tables (registre documentaire, ERP, registre RGPD) via Debezium → Kafka, les tickets via l'export SAV + dlt ; c'est le registre `ged.documents` qui fait foi pour l'état d'un document. 2. La minimisation commence à la source (`column.exclude.list` : nom, e-mail et téléphone n'entrent jamais dans Kafka) et les suppressions sont des événements à part entière (`REPLICA IDENTITY FULL`, registre des demandes d'effacement). 3. Le bronze CDC est un journal immuable de fichiers Parquet numérotés par offset, chargé dans DuckDB sans doublon grâce au triplet `(_topic, _partition, _offset)` : relancer le chargement donne 0 nouvel événement.

> 🗺️ **Et maintenant ?** — Tout est arrivé au quai, intact et tracé ; en L182, vous ouvrez les cartons : extraire le texte, masquer les données personnelles, écarter les doublons, découper, et prouver par des tests que rien de non conforme ne passe.
