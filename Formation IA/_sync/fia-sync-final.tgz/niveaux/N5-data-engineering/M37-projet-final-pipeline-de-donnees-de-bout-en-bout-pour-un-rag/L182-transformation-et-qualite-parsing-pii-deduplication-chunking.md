---
id: L182
module: M37
level: N5
title: "Transformation et qualité : parsing, PII, déduplication, chunking en silver ; tests et contrats"
minutes: 45
objectives:
  - "Recalculer avec dbt l'état courant des documents à partir du journal CDC et préparer les tickets avec leur agence et sans les clients effacés"
  - "Construire une couche silver incrémentale : extraction Docling, pseudonymisation Presidio par type de source, déduplication MinHash et chunking versionné"
  - "Mesurer le taux de doublons, la détection des PII (rappel ≥ 90 %) et justifier les paramètres par les mesures faites sur le corpus"
  - "Bloquer toute donnée non conforme avec des tests dbt, une suite GX Core, des contrôles Soda et le contrat ODCS"
skills: ["C5.4", "C5.5"]
sources:
  - { title: "Docling — RAG with OpenSearch", url: "https://docling-project.github.io/docling/examples/rag_opensearch", lang: "en" }
  - { title: "Microsoft Presidio — Data Protection and De-identification SDK", url: "https://microsoft.github.io/presidio", lang: "en" }
  - { title: "Mining of Massive Datasets (Leskovec, Rajaraman, Ullman)", url: "http://www.mmds.org", lang: "en" }
  - { title: "dbt — Add data tests to your DAG", url: "https://docs.getdbt.com/docs/build/data-tests", lang: "en" }
  - { title: "Great Expectations (GX Core)", url: "https://greatexpectations.io/", lang: "en" }
  - { title: "Soda", url: "https://soda.io/", lang: "en" }
  - { title: "Data Contract CLI — Open Data Contract Standard", url: "https://docs.datacontract.com/docs/open-data-contract-standard.md", lang: "en" }
  - { title: "UPPMAX LLM workshop — Data pipelines", url: "https://uppmax.github.io/LLM-workshop/day2/data_pipelines", lang: "en" }
---

# Transformation et qualité : parsing, PII, déduplication, chunking en silver ; tests et contrats

> ⏱ 45 min · 🎯 Niveau 5 · 📚 Module 37

## 🎯 Ce que vous saurez faire
- Reconstruire, à partir du seul journal des événements, la liste exacte des documents en vigueur : ni les supprimés, ni les anciennes versions.
- Enchaîner extraction, pseudonymisation, déduplication et découpage dans le **bon ordre**, et ne refaire que ce qui a changé.
- Régler la déduplication et le découpage **par la mesure** sur le corpus Bréval, pas en recopiant des paramètres publiés pour le web.
- Prouver qu'une donnée non conforme (un téléphone en clair, un document restreint ouvert à tous) **arrête** le pipeline.

> 🧭 **En clair** — Au dépôt de Bréval, les palettes reçues hier passent à l'atelier de préparation avant d'être expédiées sur les chantiers. On déballe (extraction du texte), on retire les étiquettes nominatives qui n'ont rien à faire sur le chantier (données personnelles), on écarte les cartons en double et les anciens modèles restés en stock (déduplication), on fait des lots de taille raisonnable étiquetés avec leur destination (chunks et droits), puis un contrôleur vérifie chaque lot avant qu'il ne parte : s'il trouve une erreur, le camion ne part pas. Cette leçon construit cet atelier et son contrôleur.

## 1. Le plan de la couche silver

```
bronze.cdc_evenements ─┐ dbt amont (vues)                  rag/preparer.py (Python)                     dbt aval + contrôles
bronze.tickets_sav*  ──┼──▶ rag_documents_courants ──┐  1. extraction (Markdown | Docling)            ┌─▶ rag_suivi_documents
erp staging (M33)    ──┘    rag_tickets_a_indexer ───┼─▶ 2. PII (Presidio, règle par source)  ──▶ silver.rag_documents ─┤   rag_qualite_corpus
                                                     │  3. déduplication (documents seulement)     silver.rag_chunks ───┼─▶ tests dbt, GX, Soda
objets MinIO breval-docs ────────────────────────────┘  4. chunking + droits + gabarits                                 └─▶ contrat ODCS
```

Trois règles d'ordre, qui sont aussi trois erreurs fréquentes :

1. **PII avant chunking.** Un numéro de téléphone coupé entre deux chunks (« 06 39 » | « 98 19 40 ») échappe aux détecteurs. On pseudonymise le document entier, puis on découpe.
2. **Déduplication avant chunking.** On compare des documents, pas des morceaux : une ancienne version de procédure doit disparaître en entier, avec tous ses chunks.
3. **Incrémental par empreinte.** Presidio coûte cher (un modèle spaCy par appel) : on ne le relance que si l'empreinte SHA-256 de la source ou la version du traitement a changé.

## 2. dbt amont : l'état courant se déduit du journal

Ajoutez au projet `dbt_breval` (L163) un dossier `models/rag/` en deux parties : `amont` (avant Python, en vues) et `aval` (après Python, en tables gold).

```yaml
# dbt_project.yml (extrait) — sous « models: breval: », à côté de staging et marts
    rag:
      amont:
        +materialized: view
        +schema: silver
      aval:
        +materialized: table
        +schema: gold
```

```yaml
# models/staging/_sources.yml (extrait) — ajoutez la table enfant créée par dlt sous la source « sav »
  - name: sav
    schema: bronze
    tables:
      - name: tickets_sav
      - name: tickets_sav__messages
```

Le registre documentaire n'existe en bronze que sous forme d'événements. On en déduit l'état courant : pour chaque `doc_id`, le **dernier** événement dans l'ordre du WAL (`lsn`), puis on écarte ceux dont le dernier événement est une suppression.

```sql
-- models/rag/amont/stg_cdc__ged_documents.sql — état courant du registre documentaire, recalculé depuis le journal CDC
with evenements as (
    select
        op, lsn, _offset,
        coalesce(apres, avant)                                  as ligne,   -- suppression : dernier état connu
        json_extract_string(coalesce(apres, avant), '$.doc_id') as doc_id,
        epoch_ms(source_ts_ms)                                  as source_le
    from {{ source('cdc', 'cdc_evenements') }}
    where _topic = 'breval.ged.documents'
),
dernier as (                                   -- le dernier événement de chaque document, dans l'ordre du WAL
    select * from evenements
    qualify row_number() over (partition by doc_id order by lsn desc, _offset desc) = 1
)
select
    doc_id,
    op = 'd'                                                  as supprime,
    source_le                                                 as dernier_changement_le,
    json_extract_string(ligne, '$.cle_objet')                 as cle_objet,
    json_extract_string(ligne, '$.titre')                     as titre,
    json_extract_string(ligne, '$.type_document')             as type_document,
    json_extract_string(ligne, '$.service')                   as service,
    json_extract_string(ligne, '$.version')                   as version,
    -- Debezium encode une colonne DATE en nombre de jours depuis le 1er janvier 1970
    date '1970-01-01' + cast(json_extract_string(ligne, '$.date_maj') as integer) as date_maj,
    json_extract_string(ligne, '$.confidentialite')           as confidentialite,
    json_extract_string(ligne, '$.sha256')                    as sha256
from dernier
```

```sql
-- models/rag/amont/stg_cdc__demandes_effacement.sql — registre RGPD rejoué depuis le journal
select
    cast(json_extract_string(apres, '$.demande_id') as bigint) as demande_id,
    cast(json_extract_string(apres, '$.client_id') as bigint)  as client_id,
    epoch_ms(source_ts_ms)                                     as recue_le
from {{ source('cdc', 'cdc_evenements') }}
where _topic = 'breval.rgpd.demandes_effacement'
  and op in ('c', 'r')
```

```sql
-- models/rag/amont/rag_documents_courants.sql — ce qui doit être indexé : les documents non supprimés
select doc_id, cle_objet, titre, type_document, service, version, date_maj, confidentialite, sha256,
       dernier_changement_le
from {{ ref('stg_cdc__ged_documents') }}
where not supprime
```

Les tickets deviennent des « documents » SAV : on recolle leurs messages, on récupère l'**agence** (celle de la commande, sinon celle du client) qui fixera les droits, et on écarte les clients ayant demandé l'effacement. Sans ce filtre, le batch suivant réindexerait ce que l'indexeur de suppressions vient d'effacer (L183).

```sql
-- models/rag/amont/rag_tickets_a_indexer.sql — un ticket = un « document » SAV, avec son agence, sans les clients effacés
with messages as (                             -- table enfant créée par dlt (L162)
    select _dlt_parent_id,
           string_agg('[' || auteur || '] ' || texte, chr(10) order by _dlt_list_idx) as texte_brut
    from {{ source('sav', 'tickets_sav__messages') }}
    group by _dlt_parent_id
),
effaces as (
    select distinct client_id from {{ ref('stg_cdc__demandes_effacement') }}
    where client_id is not null                -- un NULL dans un NOT IN filtrerait TOUS les tickets
)
select
    t.ticket_id,
    cast(t.client_id as bigint)                                               as client_id,
    coalesce(c.agence_id, cl.agence_id)                                       as agence_id,
    t.categorie,
    lower(t.statut)                                                           as statut,
    cast(timezone('Europe/Paris', cast(t.ouvert_le as timestamptz)) as date)  as ouvert_le,
    m.texte_brut,
    sha256(m.texte_brut)                                                      as sha256_source
from {{ source('sav', 'tickets_sav') }} t
join messages m on m._dlt_parent_id = t._dlt_id
left join {{ ref('stg_erp__commandes') }} c on c.commande_id = cast(t.commande_id as bigint)
left join {{ ref('stg_erp__clients') }} cl on cl.client_id = cast(t.client_id as bigint)
where cast(t.client_id as bigint) not in (select client_id from effaces)
```

```yaml
# models/rag/amont/_rag_amont.yml
version: 2
sources:
  - name: cdc
    schema: bronze
    tables:
      - name: cdc_evenements
        loaded_at_field: _ingere_le
        freshness:                    # un flux calme n'émet rien : voir le heartbeat Debezium en L184
          warn_after: {count: 12, period: hour}
models:
  - name: rag_documents_courants
    columns:
      - name: doc_id
        data_tests: [unique, not_null]
      - name: confidentialite
        data_tests:
          - accepted_values:
              arguments:
                values: ['public', 'interne', 'restreint']
  - name: rag_tickets_a_indexer
    columns:
      - name: ticket_id
        data_tests: [unique, not_null]
      - name: agence_id
        data_tests: [not_null]
```

```bash
export PYTHONPATH=$PWD
python -m rag.bronze_cdc && make ingest                  # journal CDC + tickets à jour
cd dbt_breval && dbt build --profiles-dir . --select path:models/staging path:models/rag/amont && cd ..
```

> 🧭 **Pré-requis express** — `--select path:models/rag/amont` demande à dbt de ne construire que les modèles rangés dans ce dossier (et `path:models/staging` les modèles d'étape dont ils dépendent). `make ingest` est la cible du Makefile de L165.

> 🛠️ **Si ça ne marche pas** — « Compilation Error … depends on a source named 'cdc.cdc_evenements' which was not found » → le fichier `models/rag/amont/_rag_amont.yml` n'est pas enregistré ou mal indenté. « … source named 'sav.tickets_sav__messages' which was not found » → l'ajout dans `models/staging/_sources.yml` a été oublié. « Catalog Error: Table with name cdc_evenements does not exist » → lancez d'abord `python -m rag.bronze_cdc` (L181). « Could not set lock on file » → arrêtez Dagster ou tout autre programme qui a ouvert `breval.duckdb`.

**Point de contrôle** — `SELECT count(*) FROM silver.rag_documents_courants` renvoie 126 sur l'état initial (moins les documents supprimés et non restaurés lors de l'exercice de L181) ; `SELECT count(*) FROM silver.rag_tickets_a_indexer` renvoie 9 048, moins les tickets des clients effacés ; les tests `unique` et `accepted_values` passent.

> 💡 **Autrement dit** — On ne demande pas à Postgres « quels documents existent ? » : on **relit le journal** de tout ce qui s'est passé et on en déduit la réponse. Si un jour le silver est faux, on l'efface et on relit le journal : on retombe sur le même résultat.

```quiz
{
  "q": "Dans rag_tickets_a_indexer, que se passerait-il si la sous-requête des clients effacés contenait une ligne avec client_id NULL ?",
  "options": ["Rien : NOT IN ignore les NULL de la sous-requête", "Seuls les tickets dont le client_id est NULL seraient exclus", "Plus aucun ticket : x NOT IN (…, NULL) n'est jamais vrai", "dbt refuserait de compiler le modèle rag_tickets_a_indexer"],
  "answer": 2,
  "explanation": "En SQL, x NOT IN (a, NULL) vaut NULL (inconnu), donc la ligne est filtrée. Un seul NULL vide toute la table : d'où le filtre « client_id is not null » dans la CTE effaces. Le test not_null et le moniteur de volume (L184) détecteraient l'effondrement."
}
```

## 3. Extraire et pseudonymiser

Copiez dans `rag/` les fichiers `reconnaisseurs_fr.py` et `analyseur_fr.py` de L177 ; dans `analyseur_fr.py`, remplacez `from reconnaisseurs_fr import NirRecognizer` par `from rag.reconnaisseurs_fr import NirRecognizer`. Installez les dépendances et créez une clé de pseudonymisation **une fois pour toutes** :

```bash
pip install presidio-analyzer presidio-anonymizer docling tiktoken polars pandas pytz \
            "great_expectations>=1.0" "datacontract-cli[duckdb]" soda-core-duckdb
python -m spacy download fr_core_news_lg
echo "PII_HMAC_KEY=$(python -c 'import secrets; print(secrets.token_hex(32))')" >> .env   # .env est dans .gitignore
set -a && source .env && set +a
```

> 🧭 **Pré-requis express** — La ligne `echo … >> .env` **ajoute** au fichier `.env` une clé tirée au hasard : ne la lancez **qu'une seule fois** dans la vie du projet (voir le piège ci-dessous) ; vérifiez avec `grep -c PII_HMAC_KEY .env`, qui doit afficher `1`. `set -a && source .env && set +a` lit le fichier `.env` et transforme chacune de ses lignes `NOM=valeur` en variable d'environnement exportée : refaites cette ligne (pas l'`echo` !) dans **chaque** nouveau terminal, avec l'`export PYTHONPATH=$PWD`.

> 🛠️ **Si ça ne marche pas** — `grep -c` affiche `2` ou plus → vous avez relancé l'`echo` : ouvrez `.env`, gardez la **première** ligne `PII_HMAC_KEY=…` (celle qui a servi à la première préparation) et supprimez les autres. « Can't find model 'fr_core_news_lg' » plus tard → le `spacy download` s'est fait dans une autre venv.

L'extraction reprend L175 : les Markdown passent tels quels, les PDF déposés par `ged_simulateur.py ajouter` passent par Docling, qui produit un Markdown avec ses titres `#` dont dépend le découpage.

```python
# rag/extraction.py — octets d'un objet MinIO -> texte Markdown (Docling pour les formats mis en page, L175)
import os
import tempfile
from pathlib import Path

_convertisseur = None


def extraire(cle_objet: str, contenu: bytes) -> tuple[str, str]:
    """Renvoie (markdown, extracteur). Le Markdown garde les titres « # » dont dépend le chunking."""
    global _convertisseur
    suffixe = Path(cle_objet).suffix.lower()
    if suffixe in (".md", ".txt"):
        return contenu.decode("utf-8"), "markdown"
    if suffixe in (".pdf", ".docx", ".html"):
        from docling.document_converter import DocumentConverter    # import tardif : modèles lourds
        if _convertisseur is None:
            _convertisseur = DocumentConverter()
        with tempfile.NamedTemporaryFile(suffix=suffixe, delete=False) as f:
            f.write(contenu)
        try:
            return _convertisseur.convert(f.name).document.export_to_markdown(), "docling"
        finally:
            os.unlink(f.name)
    raise ValueError(f"Format non pris en charge : {cle_objet}")
```

La pseudonymisation applique la politique décidée au cadrage (L180 §4.2) : dans les **tickets**, noms et e-mails deviennent des pseudonymes stables (le même client garde le même pseudonyme, l'assistant peut donc relier deux tickets) ; dans les **documents**, le nom du responsable de procédure est conservé ; partout, les téléphones sont remplacés.

```python
# rag/pii.py — pseudonymisation Presidio (L177), politique différente selon la source (dossier L180 §4.2)
import hashlib
import hmac
import os

from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

from rag.analyseur_fr import creer_analyseur      # copie de L177 (import de reconnaisseurs_fr adapté)

_CLE = os.environ["PII_HMAC_KEY"].encode()        # secret ≥ 32 caractères, jamais dans Git
# L'empreinte de la clé fait partie de la version : changer de clé force un nouveau traitement
PII_TRAITEMENT = "presidio-fr-v1+hmac:" + hashlib.sha256(_CLE).hexdigest()[:8]


def _pseudo(prefixe: str):
    return lambda v: f"<{prefixe}_{hmac.new(_CLE, v.lower().encode(), hashlib.sha256).hexdigest()[:6]}>"


_COMMUNS = {
    "EMAIL_ADDRESS": OperatorConfig("custom", {"lambda": _pseudo("EMAIL")}),
    "PHONE_NUMBER":  OperatorConfig("replace", {"new_value": "<TELEPHONE>"}),
    "IBAN_CODE":     OperatorConfig("replace", {"new_value": "<IBAN>"}),   # jamais de chiffré réversible dans un index
    "FR_NIR":        OperatorConfig("replace", {"new_value": "<NIR>"}),
    "LOCATION":      OperatorConfig("keep"),        # villes utiles au SAV et à la logistique
    "ORGANIZATION":  OperatorConfig("keep"),        # sinon les marques des fiches techniques disparaissent
    "DATE_TIME":     OperatorConfig("keep"),
    "DEFAULT":       OperatorConfig("replace", {"new_value": "<PII>"}),
}
OPERATEURS = {
    "ticket":   {**_COMMUNS, "PERSON": OperatorConfig("custom", {"lambda": _pseudo("PERSONNE")})},
    "document": {**_COMMUNS, "PERSON": OperatorConfig("keep")},   # responsables de procédure : nom conservé
}
_analyseur, _anonymiseur = None, AnonymizerEngine()


def pseudonymiser(texte: str, source_type: str) -> tuple[str, list[str]]:
    global _analyseur
    if _analyseur is None:
        _analyseur = creer_analyseur()               # chargement du modèle spaCy : une fois par processus
    resultats = _analyseur.analyze(text=texte, language="fr", score_threshold=0.4)
    sortie = _anonymiseur.anonymize(text=texte, analyzer_results=resultats, operators=OPERATEURS[source_type])
    return sortie.text, sorted({r.entity_type for r in resultats})
```

> ⚠️ **Piège fréquent** — Générer une nouvelle `PII_HMAC_KEY` à chaque session. Tous les pseudonymes changent, donc tous les textes, donc tous les `chunk_id` : 9 000 tickets repassent dans Presidio et dans le modèle d'embeddings. C'est pourquoi l'empreinte de la clé fait partie de `PII_TRAITEMENT` : un changement de clé doit être **voulu** (rotation documentée dans le runbook), jamais accidentel.

```mission
{
  "title": "Les opérateurs d'anonymisation de Presidio",
  "url": "https://microsoft.github.io/presidio",
  "steps": ["Ouvrez la documentation de Presidio", "Allez dans la partie Anonymizer", "Repérez la liste des opérateurs intégrés"],
  "question": "Quels opérateurs intégrés propose l'anonymiseur de Presidio, et lequel permet d'appliquer votre propre fonction (comme notre HMAC) ?",
  "hint": "Notre code en utilise trois : replace, keep et un troisième qui prend une lambda.",
  "answer": "replace, redact, hash, mask, encrypt (et decrypt côté désanonymisation), custom et keep ; custom applique une fonction fournie (doc consultée en nov. 2026, la liste peut évoluer) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Dédupliquer… ce qui doit l'être

Le code MinHash/LSH de L176 est la recette **générique** : 5-grammes de mots sur le texte entier, appliqués à **tout** le corpus (tickets compris), en gardant le texte le plus long. Ce réglage est pensé pour des pages web longues. Rejoué tel quel sur Bréval, il **échoue** : il écarte 1 746 tickets et **aucune** ancienne version de document. Les documents sont courts (29 à 136 mots), et le titre et la ligne « Version … — mise à jour le … » diffèrent toujours. Le Jaccard entre PRC-001 et son ancienne version PRC-001-v2 n'est que de 0,55, sous tout seuil raisonnable.

Le projet **s'écarte donc volontairement de L176 sur quatre points**, chacun justifié par une mesure sur ce corpus :

1. on compare le **corps sans en-tête** ;
2. on passe aux **3-grammes** ;
3. on limite la comparaison aux **documents internes** (voir le piège plus bas) ;
4. on garde le document **le plus récent**, et non le plus long.

Les 14 bandes × 8 lignes (seuil LSH ≈ 0,72) et le seuil de confirmation de 0,8 restent ceux de L176. La seule différence est que ce seuil s'applique au Jaccard exact des shingles, au lieu de l'estimation tirée des signatures. Le Jaccard des anciennes versions monte alors entre 0,86 et 0,90, celui des CGV 2024/2025/2026 à 1,0, et aucune paire de procédures distinctes ne dépasse 0,7. En résumé, L176 donne la méthode générale et M37 montre comment la régler sur un corpus précis : notez ces écarts et leurs mesures dans le dossier d'architecture.

```python
# rag/dedup.py — doublons exacts + quasi-doublons MinHash/LSH (L176), limités aux documents internes
import hashlib
import re
from collections import defaultdict

import numpy as np

K, N_PERM, BANDES, SEUIL = 3, 112, 14, 0.8      # 3-grammes : documents courts (mesuré sur Bréval, L182)
LIGNES = N_PERM // BANDES
P = (1 << 61) - 1
_rng = np.random.default_rng(42)                 # graine fixe : mêmes signatures à chaque exécution
A = _rng.integers(1, P, N_PERM, dtype=np.uint64).astype(object)
B = _rng.integers(0, P, N_PERM, dtype=np.uint64).astype(object)


def corps_sans_entete(texte: str) -> str:
    """Retire le titre (# …) et la ligne « Version … — mise à jour le … » : ils diffèrent toujours."""
    return "\n".join(l for l in texte.splitlines()
                     if not l.startswith("# ") and not l.startswith("Version "))


def shingles(texte: str) -> set[str]:
    mots = re.findall(r"\w+", corps_sans_entete(texte).lower())
    return {" ".join(mots[i:i + K]) for i in range(max(1, len(mots) - K + 1))}


def signature(sh: set[str]) -> np.ndarray:
    x = np.array([int.from_bytes(hashlib.blake2b(g.encode(), digest_size=8).digest(), "little") % P
                  for g in sh], dtype=object)
    return np.array([min((a * x + b) % P) for a, b in zip(A, B)], dtype=object)


def jaccard(a: set, b: set) -> float:
    return len(a & b) / max(1, len(a | b))


def dedupliquer(docs: list[dict]) -> tuple[dict[str, str], list[dict]]:
    """docs : [{doc_id, texte, date_maj, version}]. Renvoie {doc_id_retiré: doc_id_gardé} et le rapport."""
    sh = {d["doc_id"]: shingles(d["texte"]) for d in docs}
    parent = {d["doc_id"]: d["doc_id"] for d in docs}

    def racine(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    # 1) doublons exacts : même empreinte du corps normalisé
    par_empreinte = defaultdict(list)
    for d in docs:
        corps = re.sub(r"\s+", " ", corps_sans_entete(d["texte"]).lower()).strip()
        par_empreinte[hashlib.sha256(corps.encode()).hexdigest()].append(d["doc_id"])
    for ids in par_empreinte.values():
        for i in ids[1:]:
            parent[racine(i)] = racine(ids[0])
    # 2) quasi-doublons : LSH sur les signatures, puis confirmation par le Jaccard exact
    casiers = defaultdict(list)
    for d in docs:
        sig = signature(sh[d["doc_id"]])
        for b in range(BANDES):
            casiers[(b, tuple(sig[b * LIGNES:(b + 1) * LIGNES]))].append(d["doc_id"])
    paires = 0
    for membres in casiers.values():
        for i in membres[1:]:
            j = membres[0]
            paires += 1
            if racine(i) != racine(j) and jaccard(sh[i], sh[j]) >= SEUIL:
                parent[racine(i)] = racine(j)
    groupes = defaultdict(list)
    for d in docs:
        groupes[racine(d["doc_id"])].append(d)
    retires, rapport = {}, []
    for membres in groupes.values():
        if len(membres) == 1:
            continue
        garde = max(membres, key=lambda d: (str(d.get("date_maj")), str(d.get("version"))))   # le plus récent
        for d in membres:
            if d["doc_id"] != garde["doc_id"]:
                retires[d["doc_id"]] = garde["doc_id"]
                rapport.append({"retire": d["doc_id"], "garde": garde["doc_id"],
                                "jaccard": round(jaccard(sh[d["doc_id"]], sh[garde["doc_id"]]), 3)})
    return retires, rapport
```

Le document conservé est le **plus récent** (`date_maj`) : PRC-001 (v3) plutôt que PRC-001-v2, CGV-2026-PRO plutôt que 2024 et 2025. Résultat de référence : **126 documents → 116**, 10 retirés (6 anciennes versions de procédures, 4 CGV antérieures), soit un taux de doublons avant traitement de 7,9 %, et zéro après.

> ⚠️ **Piège fréquent** — Passer les **tickets** dans MinHash. Ils sont rédigés à partir de quelques formules (« Livraison CMD-… : produit abîmé, je demande un remplacement ») : des milliers de tickets distincts, de clients distincts, seraient fusionnés (la recette générique de L176 en écarte 1 746, alors que le générateur de L152 ne crée aucun ticket envoyé deux fois). Un ticket n'est pas un doublon parce qu'il ressemble à un autre : c'est un **cas** différent. La déduplication se limite aux documents internes, et chaque groupe retiré est tracé dans `data/rag/rapport_dedup.json` pour relecture humaine.

> 💡 **Autrement dit** — Deux documents « presque identiques » ne sont pas forcément des doublons : deux procédures différentes peuvent partager un gabarit, deux tickets se ressembler. On règle le seuil en **relisant** les paires détectées, et on limite la comparaison aux familles où « presque identique » veut vraiment dire « version périmée ».

## 5. Découper, étiqueter, écarter les gabarits

Le chunking reprend `decouper()` de L178 et ajoute trois choses : un **en-tête de contexte** (« Procédure — Notes de frais › Responsable ») pour qu'un chunk isolé reste compréhensible ; les **droits** calculés par `rag/droits.py` (L180) ; la détection des **gabarits**, ces sections identiques dans de nombreux documents (« Respecter les règles de l'art et la notice du fabricant » apparaît dans les 80 fiches techniques) qui pollueraient les résultats sans rien apprendre à personne. Deux configurations sont proposées : par sections (`struct-md-v2-max350-rec50`) ou document entier quand il est court (`doc-entier-v1`). C'est l'évaluation de L183 qui tranchera (critère de C5.5).

```python
# rag/chunking.py — découpage versionné (L178) + en-tête de contexte + droits + détection des gabarits
import hashlib
import re
from collections import defaultdict

import tiktoken

from rag.droits import droits_document, droits_hash, droits_ticket

enc = tiktoken.get_encoding("cl100k_base")
CONFIGS = {"struct-md-v2-max350-rec50": "sections", "doc-entier-v1": "document"}
SEUIL_GABARIT = 5          # un même corps de chunk présent dans ≥ 5 documents = texte gabarit


def decouper(markdown: str, max_tokens: int = 350, recouvrement: int = 50) -> list[tuple[str, str]]:
    """Identique à L178 : coupe aux titres, puis par fenêtres de tokens si une section est trop longue."""
    morceaux, section = [], "Préambule"
    for bloc in re.split(r"\n(?=#{1,3} )", markdown):
        if bloc.startswith("#"):
            section = bloc.splitlines()[0].lstrip("# ").strip()
        toks = enc.encode(bloc)
        pas = max_tokens - recouvrement
        for debut in range(0, max(1, len(toks)), pas):
            morceaux.append((section, enc.decode(toks[debut:debut + max_tokens])))
            if debut + max_tokens >= len(toks):
                break
    return morceaux


def chunker(doc: dict, chunking_v: str) -> list[dict]:
    """doc : une ligne de silver.rag_documents (texte déjà pseudonymisé et dédupliqué)."""
    if doc["source_type"] == "ticket":
        agences, groupes = droits_ticket(doc["agence_id"])
        entete = f"Ticket SAV {doc['doc_id']} — {doc['titre']}"
        morceaux = [("Échanges", t) for _, t in decouper(doc["texte_pseudo"], 350, 50)]
    else:
        agences, groupes = droits_document(doc["doc_id"], doc["service"], doc["confidentialite"])
        entete = doc["titre"]
        if CONFIGS[chunking_v] == "document" and len(enc.encode(doc["texte_pseudo"])) <= 350:
            morceaux = [(doc["titre"], doc["texte_pseudo"])]
        else:
            morceaux = decouper(doc["texte_pseudo"])
    sortie = []
    for pos, (section, texte) in enumerate(morceaux):
        texte_indexe = f"{entete} › {section}\n{texte}"          # le chunk « sait » d'où il vient
        cle = f"{doc['doc_id']}|{chunking_v}|{pos}|{texte_indexe}"
        sortie.append({
            "chunk_id": hashlib.sha256(cle.encode()).hexdigest()[:32],
            "doc_id": doc["doc_id"], "source_type": doc["source_type"], "position": pos,
            "section": section, "texte": texte, "texte_indexe": texte_indexe,
            "agences": agences, "groupes": groupes, "droits_hash": droits_hash(agences, groupes),
            "client_id": doc.get("client_id"), "date_maj": doc["date_maj"],
            "sha256_source": doc["sha256_source"], "chunking_v": chunking_v,
        })
    return sortie


def marquer_gabarits(chunks: list[dict]) -> None:
    """Un corps de section répété dans de nombreux documents n'apporte rien à la recherche."""
    docs_par_corps = defaultdict(set)
    for c in chunks:
        if c["source_type"] == "document":
            docs_par_corps[re.sub(r"\s+", " ", c["texte"].lower()).strip()].add(c["doc_id"])
    for c in chunks:
        corps = re.sub(r"\s+", " ", c["texte"].lower()).strip()
        c["gabarit"] = c["source_type"] == "document" and len(docs_par_corps[corps]) >= SEUIL_GABARIT
        c["indexable"] = not c["gabarit"] and len(c["texte"].split()) >= 3
```

Le module `rag/obs.py` chronomètre chaque étape dans `obs.etapes` : ces durées serviront au coût par document (L184).

```python
# rag/obs.py — chronométrage des étapes dans obs.etapes (sert au coût par document, L184)
import os
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone

_RUN_LOCAL = uuid.uuid4().hex[:12]


def run_id() -> str:
    return os.environ.get("RAG_RUN_ID", _RUN_LOCAL)        # Dagster le renseigne avec son identifiant de run


@contextmanager
def etape(con, nom: str):
    con.execute("CREATE SCHEMA IF NOT EXISTS obs")
    con.execute("""CREATE TABLE IF NOT EXISTS obs.etapes (run_id VARCHAR, etape VARCHAR, debut TIMESTAMPTZ,
                   duree_s DOUBLE, nb_elements BIGINT, tokens BIGINT)""")
    compteurs = {"n": 0, "tokens": 0}
    debut, t0 = datetime.now(timezone.utc), time.perf_counter()
    yield compteurs
    con.execute("INSERT INTO obs.etapes VALUES (?, ?, ?, ?, ?, ?)",
                [run_id(), nom, debut, time.perf_counter() - t0, compteurs["n"], compteurs["tokens"]])
```

Enfin, le chef d'orchestre de la couche silver :

```python
# rag/preparer.py — couche silver du RAG : extraction, PII, déduplication, chunking (incrémental par empreinte)
import json
from datetime import datetime, timezone

import pyarrow as pa

from rag import chunking, dedup
from rag.config import BUCKET_DOCS, CHUNKING_V, DATA_RAG, connexion_duckdb, s3
from rag.extraction import extraire
from rag.obs import etape
from rag.pii import PII_TRAITEMENT, pseudonymiser


def _lignes(con, requete: str) -> list[dict]:
    cur = con.execute(requete)
    colonnes = [c[0] for c in cur.description]
    return [dict(zip(colonnes, v)) for v in cur.fetchall()]


def _precedent(con) -> dict:
    """Ce qui a déjà été pseudonymisé : on ne relance Presidio que si l'empreinte ou le traitement a changé."""
    existe = con.execute("SELECT count(*) FROM information_schema.tables "
                         "WHERE table_schema = 'silver' AND table_name = 'rag_documents'").fetchone()[0]
    if not existe:
        return {}
    return {d["doc_id"]: d for d in _lignes(con, "SELECT doc_id, sha256_source, texte_pseudo, pii_types, "
                                                 "pii_traitement FROM silver.rag_documents")}


def _ecrire(con, nom: str, lignes: list[dict]) -> None:
    con.execute("CREATE SCHEMA IF NOT EXISTS silver")
    con.register("_lot", pa.Table.from_pylist(lignes))
    con.execute(f"CREATE OR REPLACE TABLE silver.{nom} AS SELECT * FROM _lot")   # remplacement atomique
    con.unregister("_lot")


def preparer(con, chunking_v: str = CHUNKING_V) -> dict:
    prec, client_s3 = _precedent(con), s3()
    docs, stats = [], {"pii_calculees": 0, "pii_reutilisees": 0}

    def texte_pseudo(doc_id, sha, source_type, lire_brut):
        p = prec.get(doc_id)
        if p and p["sha256_source"] == sha and p["pii_traitement"] == PII_TRAITEMENT:
            stats["pii_reutilisees"] += 1
            return p["texte_pseudo"], list(p["pii_types"])
        stats["pii_calculees"] += 1
        return pseudonymiser(lire_brut(), source_type)

    with etape(con, "extraction_pii") as compteur:
        for d in _lignes(con, "SELECT * FROM silver.rag_documents_courants"):
            lire = lambda d=d: extraire(d["cle_objet"],
                                        client_s3.get_object(Bucket=BUCKET_DOCS, Key=d["cle_objet"])["Body"].read())[0]
            texte, types = texte_pseudo(d["doc_id"], d["sha256"], "document", lire)
            docs.append({"doc_id": d["doc_id"], "source_type": "document", "titre": d["titre"],
                         "service": d["service"], "confidentialite": d["confidentialite"],
                         "version": d["version"], "date_maj": d["date_maj"], "agence_id": None,
                         "client_id": None, "sha256_source": d["sha256"], "texte_pseudo": texte, "pii_types": types})
        for t in _lignes(con, "SELECT * FROM silver.rag_tickets_a_indexer"):
            texte, types = texte_pseudo(t["ticket_id"], t["sha256_source"], "ticket", lambda t=t: t["texte_brut"])
            docs.append({"doc_id": t["ticket_id"], "source_type": "ticket",
                         "titre": f"{t['categorie']} · {t['statut']} · ouvert le {t['ouvert_le']:%d/%m/%Y}",
                         "service": "sav", "confidentialite": "restreint", "version": None,
                         "date_maj": t["ouvert_le"],                       # DATE (heure de Paris), cf. dbt
                         "agence_id": t["agence_id"], "client_id": t["client_id"],
                         "sha256_source": t["sha256_source"], "texte_pseudo": texte, "pii_types": types})
        compteur["n"] = len(docs)

    with etape(con, "deduplication") as compteur:      # documents internes seulement : jamais les tickets
        retires, rapport = dedup.dedupliquer([{"doc_id": d["doc_id"], "texte": d["texte_pseudo"],
                                               "date_maj": d["date_maj"], "version": d["version"]}
                                              for d in docs if d["source_type"] == "document"])
        compteur["n"] = len(retires)

    maintenant = datetime.now(timezone.utc)
    for d in docs:
        d.update(doublon_de=retires.get(d["doc_id"]), statut_dedup="doublon" if d["doc_id"] in retires else "garde",
                 pii_traitement=PII_TRAITEMENT, prepare_le=maintenant)

    with etape(con, "chunking") as compteur:
        chunks = [c for d in docs if d["statut_dedup"] == "garde" for c in chunking.chunker(d, chunking_v)]
        chunking.marquer_gabarits(chunks)
        confidentialite = {d["doc_id"]: d["confidentialite"] for d in docs}
        for c in chunks:
            c.update(confidentialite=confidentialite[c["doc_id"]], prepare_le=maintenant)
        compteur["n"] = len(chunks)
        compteur["tokens"] = sum(len(chunking.enc.encode(c["texte_indexe"])) for c in chunks if c["indexable"])

    _ecrire(con, "rag_documents", docs)
    _ecrire(con, "rag_chunks", chunks)
    DATA_RAG.mkdir(parents=True, exist_ok=True)
    (DATA_RAG / "rapport_dedup.json").write_text(json.dumps(rapport, ensure_ascii=False, indent=2), encoding="utf-8")
    return {**stats, "documents": sum(d["source_type"] == "document" for d in docs),
            "tickets": sum(d["source_type"] == "ticket" for d in docs), "doublons": len(retires),
            "chunks": len(chunks), "indexables": sum(c["indexable"] for c in chunks)}


if __name__ == "__main__":
    con = connexion_duckdb()
    print(preparer(con))
    con.close()
```

```bash
python -m rag.preparer       # 1re fois : plusieurs minutes (Presidio sur 9 048 tickets)
python -m rag.preparer       # 2e fois : quelques secondes
```

> 🛠️ **Si ça ne marche pas** — « KeyError: 'PII_HMAC_KEY' » → le `.env` n'a pas été chargé dans ce terminal (`set -a && source .env && set +a`). « ModuleNotFoundError: No module named 'rag' » → `export PYTHONPATH=$PWD`. « ModuleNotFoundError: No module named 'reconnaisseurs_fr' » → l'import de `rag/analyseur_fr.py` n'a pas été adapté en `from rag.reconnaisseurs_fr import …`. La seconde exécution recalcule encore tout (`pii_calculees` non nul) → la clé HMAC a changé entre les deux exécutions (voir le piège ci-dessus).

**Point de contrôle** — Sur l'état initial, la première exécution affiche `{'pii_calculees': 9174, 'pii_reutilisees': 0, 'documents': 126, 'tickets': 9048, 'doublons': 10, 'chunks': 9426, 'indexables': 9326}` ; la seconde, `pii_calculees: 0` et `pii_reutilisees: 9174`, avec les mêmes chunks. Dans `silver.rag_chunks`, 378 chunks de documents dont 100 gabarits (les 80 sections « Mise en œuvre » et 20 sections « Étapes » identiques), plus un chunk par ticket. Avec `CHUNKING_V=doc-entier-v1`, vous obtenez 116 chunks de documents, sans gabarit.

```quiz
{
  "q": "Vous modifiez uniquement la confidentialité de PRC-024 (interne → restreint) dans la GED. Que recalcule preparer() ?",
  "options": ["Tout : Presidio repasse sur l'ensemble du corpus, car la version du traitement change", "Rien : l'empreinte du fichier n'a pas changé, donc le document est ignoré", "Le texte pseudonymisé est réutilisé, mais les chunks reçoivent de nouveaux droits", "Seulement les embeddings de PRC-024, recalculés avec les nouveaux droits"],
  "answer": 2,
  "explanation": "La pseudonymisation dépend du contenu (sha256 inchangé) : elle est réutilisée. Le chunking, lui, est refait à chaque exécution et lit la nouvelle confidentialité : les groupes et le droits_hash changent, le chunk_id non. En L183, l'indexeur mettra à jour les métadonnées des points sans recalculer leurs vecteurs."
}
```

## 6. Les contrôles qui bloquent

Quatre filets, chacun à sa place (L170) : **dbt** dans l'entrepôt après chaque transformation, **GX** dans le code Python avant l'indexation, **Soda** pour des contrôles planifiés lisibles par le métier, le **contrat ODCS** comme test d'acceptation de l'interface.

### 6.1 dbt aval : suivi, qualité et tests

```yaml
# models/rag/aval/_rag_aval.yml — les tables écrites par rag/preparer.py deviennent des sources testées
version: 2
sources:
  - name: rag
    schema: silver
    tables:
      - name: rag_documents
        columns:
          - name: doc_id
            data_tests: [unique, not_null]
          - name: statut_dedup
            data_tests:
              - accepted_values:
                  arguments:
                    values: ['garde', 'doublon']
      - name: rag_chunks
        columns:
          - name: chunk_id
            data_tests: [unique, not_null]
          - name: source_type
            data_tests:
              - accepted_values:
                  arguments:
                    values: ['document', 'ticket']
          - name: doc_id
            data_tests:
              - not_null
              - relationships:
                  arguments:
                    to: source('rag', 'rag_documents')
                    field: doc_id
models:
  - name: rag_suivi_documents
    description: "Une ligne par document ou ticket : indexé, exclu (et pourquoi) ou supprimé à la source."
    columns:
      - name: doc_id
        data_tests: [not_null]
  - name: rag_qualite_corpus
    description: "Indicateurs de qualité du corpus à chaque préparation (taux de doublons, PII, gabarits)."
```

```sql
-- models/rag/aval/rag_suivi_documents.sql — gold : où en est chaque document ? (métier, runbook, soutenance)
with chunks as (
    select doc_id, count(*) as nb_chunks, count(*) filter (where indexable) as nb_indexables
    from {{ source('rag', 'rag_chunks') }}
    group by doc_id
)
select
    d.doc_id, d.source_type, d.titre, d.service, d.confidentialite, d.version, d.date_maj,
    case when d.statut_dedup = 'doublon'          then 'exclu : doublon de ' || d.doublon_de
         when coalesce(c.nb_indexables, 0) = 0    then 'exclu : aucun chunk indexable'
         else 'à indexer' end                     as statut,
    coalesce(c.nb_chunks, 0)                      as nb_chunks,
    coalesce(c.nb_indexables, 0)                  as nb_indexables,
    d.pii_types,
    d.prepare_le
from {{ source('rag', 'rag_documents') }} d
left join chunks c using (doc_id)
union all
select doc_id, 'document', titre, service, confidentialite, version, null,
       'supprimé à la source le ' || strftime(dernier_changement_le, '%d/%m/%Y %H:%M'), 0, 0, null, null
from {{ ref('stg_cdc__ged_documents') }}
where supprime
```

```sql
-- models/rag/aval/rag_qualite_corpus.sql — gold : une ligne d'indicateurs par préparation
with d as (select * from {{ source('rag', 'rag_documents') }}),
     c as (select * from {{ source('rag', 'rag_chunks') }})
select
    (select max(prepare_le) from d)                                                     as prepare_le,
    (select count(*) from d where source_type = 'document')                             as nb_documents,
    (select count(*) from d where source_type = 'ticket')                               as nb_tickets,
    (select count(*) from d where statut_dedup = 'doublon')                             as nb_doublons_retires,
    round((select count(*) from d where statut_dedup = 'doublon')
          / nullif((select count(*) from d where source_type = 'document'), 0), 4)      as taux_doublons_avant,
    (select count(*) from d where len(pii_types) > 0)                                   as nb_sources_avec_pii,
    (select count(*) from c)                                                            as nb_chunks,
    (select count(*) from c where gabarit)                                              as nb_chunks_gabarit,
    (select count(*) from c where indexable)                                            as nb_chunks_indexables,
    (select count(*) - count(distinct sha256(lower(texte))) from c where indexable
       and source_type = 'document')                                                    as doublons_exacts_restants
```

Deux tests singuliers, à placer dans `tests/rag/` :

```sql
-- tests/rag/rag_aucune_pii_residuelle.sql — bloquant : aucun téléphone en clair dans ce qui sera vectorisé
select chunk_id, doc_id
from {{ source('rag', 'rag_chunks') }}
where regexp_matches(texte_indexe, '(\+33\s?|0)[1-9]([ .]?\d{2}){4}')
```

```sql
-- tests/rag/rag_droits_coherents.sql — un contenu restreint n'est jamais ouvert au groupe « tous »
select chunk_id, doc_id
from {{ source('rag', 'rag_chunks') }}
where confidentialite = 'restreint' and list_contains(groupes, 'tous')
```

```bash
cd dbt_breval && dbt build --profiles-dir . --select "source:rag+" && cd ..
```

> 🧭 **Pré-requis express** — `source:rag+` signifie « tout ce qui dépend des tables de la source `rag` » (le `+` à droite = les descendants). `regexp_matches` teste une expression régulière ; `list_contains(groupes, 'tous')` vérifie si la liste `groupes` contient la valeur `'tous'`.

> 🔍 **Ce que vous devez voir** — une ligne par modèle et par test, dont `rag_suivi_documents`, `rag_qualite_corpus` et les deux tests singuliers en `PASS` (0 ligne fautive), puis `Done. PASS=… WARN=0 ERROR=0`.

Le sélecteur `source:rag+` construit tout ce qui descend des tables écrites par Python : les deux modèles gold et les tests attachés aux sources `rag`, dont les deux tests singuliers. Avec les tests de la partie amont, vous dépassez les cinq tests dbt exigés par C5.2.

### 6.2 GX Core, Soda et le contrat

```python
# qualite/gx_chunks.py — contrôle BLOQUANT de silver.rag_chunks avec GX Core 1.x (API de L170)
import sys

import great_expectations as gx

from rag.config import connexion_duckdb

TEL = r"(?s).*(\+33\s?|0)[1-9]([ .]?\d{2}){4}"     # (?s) : le point traverse aussi les retours à la ligne


def valider_chunks(df) -> tuple[bool, list[str]]:
    context = gx.get_context(mode="ephemeral")       # contexte neuf à chaque appel (sûr dans Dagster)
    lot = (context.data_sources.add_pandas("breval_rag")
           .add_dataframe_asset(name="rag_chunks").add_batch_definition_whole_dataframe("lot"))
    suite = context.suites.add(gx.ExpectationSuite(name="rag_chunks_bloquant"))
    for attente in [
        gx.expectations.ExpectTableRowCountToBeBetween(min_value=100),
        gx.expectations.ExpectColumnValuesToBeUnique(column="chunk_id"),
        gx.expectations.ExpectColumnValuesToNotBeNull(column="texte_indexe"),
        gx.expectations.ExpectColumnValuesToBeInSet(column="source_type", value_set=["document", "ticket"]),
        gx.expectations.ExpectColumnValuesToNotMatchRegex(column="texte_indexe", regex=TEL),
        gx.expectations.ExpectColumnValuesToBeBetween(column="nb_agences", min_value=1, max_value=3),
        gx.expectations.ExpectColumnValuesToBeBetween(column="nb_groupes", min_value=1, max_value=5),
    ]:
        suite.add_expectation(attente)
    resultat = context.validation_definitions.add(
        gx.ValidationDefinition(name="valider_rag_chunks", data=lot, suite=suite)
    ).run(batch_parameters={"dataframe": df})
    echecs = [f"{r.expectation_config.type} {r.expectation_config.kwargs.get('column', '')}".strip()
              for r in resultat.results if not r.success]
    return resultat.success, echecs


def charger(con):
    return con.sql("""SELECT chunk_id, source_type, texte_indexe, len(agences) AS nb_agences,
                             len(groupes) AS nb_groupes FROM silver.rag_chunks""").df()


if __name__ == "__main__":
    con = connexion_duckdb(read_only=True)
    ok, echecs = valider_chunks(charger(con))
    print("GX : succès" if ok else "GX : ÉCHEC → " + " ; ".join(echecs))
    sys.exit(0 if ok else 1)                         # code de sortie non nul : l'orchestrateur bloque la suite
```

> 🔍 **Ce que vous devez voir** — `python qualite/gx_chunks.py` (le chemin indiqué en tête du bloc) affiche `GX : succès` sur le silver propre, et la commande `echo $?` lancée juste après affiche `0` (`$?` contient le **code de sortie** du dernier programme : 0 = succès, 1 = échec, que l'orchestrateur lit pour décider de continuer).

```yaml
# soda/checks_rag_chunks.yml — SodaCL (syntaxe de L170 ; vérifiez-la pour votre version de Soda)
checks for rag_chunks:
  - row_count > 100
  - duplicate_count(chunk_id) = 0
  - missing_count(texte_indexe) = 0
  - invalid_count(source_type) = 0:
      valid values: [document, ticket]
  - freshness(prepare_le) < 1h
  - failed rows:
      name: contenu restreint ouvert à tous
      fail condition: confidentialite = 'restreint' AND list_contains(groupes, 'tous')
```

```bash
python qualite/gx_chunks.py                                        # « GX : succès », code de sortie 0
soda scan -d breval -c soda/configuration.yml soda/checks_rag_chunks.yml   # configuration.yml : type duckdb, path data/breval.duckdb (L170)
# La source de L170 vise le schéma main ; rag_chunks est dans silver : déclarez ce schéma pour la source
# (nom du paramètre à vérifier dans la doc Soda de votre version) ou copiez la table dans main pour le scan.
datacontract test contrats/rag_chunks.odcs.yaml                    # les 4 règles du contrat de L180
```

Démontrez maintenant que les filets **bloquent** : injectez un téléphone en clair dans un chunk, relancez les trois contrôles, puis réparez en relançant la préparation.

```bash
python -c "import duckdb; duckdb.connect('data/breval.duckdb').execute(\"UPDATE silver.rag_chunks SET texte_indexe = texte_indexe || ' Rappel au 06 39 98 12 34' WHERE chunk_id = (SELECT min(chunk_id) FROM silver.rag_chunks)\")"
python qualite/gx_chunks.py; echo "code de sortie : $?"           # ÉCHEC, code 1
datacontract test contrats/rag_chunks.odcs.yaml                    # règle « Aucun téléphone en clair » en échec
python -m rag.preparer                                             # silver reconstruit : tout repasse au vert
```

> 🔍 **Ce que vous devez voir** — `GX : ÉCHEC → …téléphone…` suivi de `code de sortie : 1`, puis un rapport `datacontract` où la règle « Aucun téléphone en clair » est `failed` ; après `rag.preparer`, les mêmes commandes repassent en succès (code 0). C'est **la preuve attendue** par la grille : gardez une copie de ces sorties.

### 6.3 Mesurer la détection des PII

Le critère de C5.5 est chiffré : « PII du jeu de test détectées à ≥ 90 % ». Un jeu annoté à la main coûte cher ; ici, le générateur de L152 nous dit **exactement** où il a placé les téléphones (après « Joignable au ») et les responsables (section « Responsable »). On en tire un jeu de référence de 236 exemples, sans circularité : l'annotation vient de la structure du générateur, la détection de Presidio.

```python
# qualite/annoter_pii.py — jeu annoté de référence : le générateur (L152) dit exactement où sont les PII
import csv
import json
import random
import re
from pathlib import Path

RAW = Path("data/raw")
rng = random.Random(7)
with (RAW / "sav/tickets_sav.jsonl").open(encoding="utf-8") as f:
    premiers = [json.loads(l)["messages"][0]["texte"] for l in f]       # 1er message client de chaque ticket
avec = [t for t in premiers if "Joignable au " in t]
sans = [t for t in premiers if "Joignable au " not in t]

exemples = []
for texte in rng.sample(avec, 150):                    # le téléphone suit « Joignable au » et précède le point final
    debut = texte.index("Joignable au ") + len("Joignable au ")
    exemples.append({"texte": texte, "entites": [{"type": "PHONE_NUMBER", "debut": debut, "fin": len(texte) - 1}]})
for texte in rng.sample(sans, 50):                     # négatifs : mesurent la précision (faux positifs)
    exemples.append({"texte": texte, "entites": []})
with (RAW / "documents/documents.csv").open(encoding="utf-8") as f:
    for d in csv.DictReader(f, delimiter=";"):
        if d["type_document"] != "procedure":
            continue
        texte = (RAW / d["chemin"]).read_text(encoding="utf-8")
        m = re.search(r"## Responsable\n(.+?), tél\. (.+)\n", texte)
        exemples.append({"texte": texte, "entites": [
            {"type": "PERSON", "debut": m.start(1), "fin": m.end(1)},
            {"type": "PHONE_NUMBER", "debut": m.start(2), "fin": m.end(2)}]})

Path("evals").mkdir(exist_ok=True)
with open("evals/pii_annote.jsonl", "w", encoding="utf-8") as f:
    for e in exemples:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
n = sum(len(e["entites"]) for e in exemples)
print(f"{len(exemples)} exemples, {n} entités annotées → evals/pii_annote.jsonl")
```

```bash
python qualite/annoter_pii.py          # 236 exemples, 222 entités annotées
python qualite/evaluer_pii.py          # script de L177 copié dans qualite/, import adapté : from rag.analyseur_fr import creer_analyseur
```

Si le rappel de `PHONE_NUMBER` est sous 90 %, regardez les lignes `MANQUÉ` : ce sont souvent les écritures `0639981940` (dix chiffres collés) ou `+33 6 …`. Ajoutez un `PatternRecognizer` dédié (comme le NIR en L177) plutôt que de baisser le seuil de score pour tout le monde, puis remesurez. Notez le tableau final dans le dossier : c'est une preuve de la grille (qualité/gouvernance/PII, 20 %).

| Erreur fréquente | Conséquence | Parade |
|---|---|---|
| PII après le chunking | téléphones coupés en deux, non détectés | pseudonymiser le document entier, puis découper |
| MinHash de L176 tel quel sur des documents courts | anciennes versions non détectées (Jaccard 0,55) | corps sans en-tête, 3-grammes, seuil validé par relecture |
| Dédupliquer les tickets | des milliers de cas clients fusionnés | dédup limitée aux documents internes |
| Garder les gabarits | « Respecter les règles de l'art » remonte sur toutes les questions | marquer les sections répétées dans ≥ 5 documents |
| Nouvelle clé HMAC à chaque session | ré-embedding complet inattendu | clé dans `.env`, rotation planifiée |
| Organisations traitées comme PII par défaut | marques des fiches techniques remplacées par `<PII>` | `ORGANIZATION` en `keep`, choix documenté |

## 🧪 Exercice pratique

**Consigne** — (1) Construisez les modèles `rag/amont`, lancez deux fois `rag.preparer` et relevez les compteurs. (2) Construisez `source:rag+` et produisez la table `gold.rag_qualite_corpus`. (3) Mesurez la détection des PII et améliorez-la jusqu'à 90 % de rappel sur `PHONE_NUMBER` et `PERSON`. (4) Prouvez le blocage : injection d'un téléphone, échec de GX, du contrat et du test dbt, réparation. (5) Lancez la préparation avec les deux configurations de chunking et conservez les deux tables (`CREATE TABLE silver.rag_chunks_doc_entier AS …`) pour l'évaluation de L183.

**Critères de réussite** — Seconde exécution sans aucun appel Presidio ; 10 doublons retirés, chacun justifié dans `rapport_dedup.json` ; au moins 5 tests dbt verts ; rappel PII ≥ 90 % documenté par type ; trace écrite d'un blocage effectif (sortie des trois contrôles) ; aucun ticket du client effacé dans `silver.rag_chunks`.

**Pistes de corrigé** — Pour la mesure du taux de doublons, `gold.rag_qualite_corpus` donne `taux_doublons_avant` (0,0794 sur l'état initial) et `doublons_exacts_restants` (0 attendu). Pour vérifier l'effacement : `SELECT count(*) FROM silver.rag_chunks WHERE client_id = 937` doit renvoyer 0. Si le contrat échoue sur une règle SQL qui passe dans DuckDB, vérifiez que `datacontract` lit bien `data/breval.duckdb` (chemin relatif au dossier de lancement).

## ✅ Auto-évaluation express
1. Pourquoi la pseudonymisation doit-elle précéder le découpage ?
2. Quels deux réglages rendent MinHash efficace sur les documents courts de Bréval, et comment les a-t-on justifiés ?
3. Comment le pipeline évite-t-il de relancer Presidio sur un ticket inchangé ?

**Réponses** — 1. Une donnée personnelle coupée entre deux chunks n'est plus reconnaissable ; sur le document entier, elle est détectée puis remplacée avant tout découpage. 2. Comparer le corps sans titre ni ligne de version, et utiliser des 3-grammes ; justifiés par la mesure du Jaccard sur les paires connues (0,55 avant, 0,86-0,90 après) et l'absence de faux positifs au-dessus de 0,7. 3. Il compare l'empreinte SHA-256 de la source et la version du traitement (`PII_TRAITEMENT`) à celles enregistrées dans `silver.rag_documents` et réutilise le texte pseudonymisé s'ils sont identiques.

## 📚 Pour aller plus loin
- [Docling — RAG with OpenSearch](https://docling-project.github.io/docling/examples/rag_opensearch) 🇬🇧 — conversion de documents mis en page en Markdown structuré pour le RAG.
- [Microsoft Presidio](https://microsoft.github.io/presidio) 🇬🇧 — analyseur, reconnaisseurs personnalisés et opérateurs d'anonymisation.
- [Mining of Massive Datasets](http://www.mmds.org) 🇬🇧 — chapitre 3 : shingling, MinHash, LSH et choix des bandes.
- [dbt — Data tests](https://docs.getdbt.com/docs/build/data-tests) 🇬🇧 — tests génériques et singuliers, sévérité, sélection.
- [Great Expectations](https://greatexpectations.io/) 🇬🇧 et [Soda](https://soda.io/) 🇬🇧 — contrôles de qualité en Python et en YAML.
- [Data Contract CLI — ODCS](https://docs.datacontract.com/docs/open-data-contract-standard.md) 🇬🇧 — `datacontract test` dans la CI.

> ✅ **Si vous ne retenez que 3 choses** — 1. La couche silver se reconstruit **depuis le journal** CDC (dernier événement par `doc_id` dans l'ordre du WAL, suppressions écartées) : rien n'est demandé à la base de production, tout est rejouable. 2. L'ordre compte : pseudonymiser le document entier, puis dédupliquer les seuls documents internes (corps sans en-tête, 3-grammes, version la plus récente gardée), puis découper en chunks porteurs de droits ; l'empreinte de la source et une clé HMAC stable évitent de relancer Presidio pour rien. 3. Quatre filets bloquent une donnée non conforme (tests dbt, GX, Soda, contrat ODCS) et le rappel des PII se mesure sur un jeu de référence : la preuve se fait en injectant volontairement une erreur et en montrant l'échec.

> 🗺️ **Et maintenant ?** — Les lots sont préparés, contrôlés et étiquetés ; en L183, vous les rangez dans l'index vectoriel sans jamais créer de doublon ni oublier une suppression, puis vous mesurez si l'assistant retrouve vraiment les bons documents, et seulement ceux qu'il a le droit de montrer.
