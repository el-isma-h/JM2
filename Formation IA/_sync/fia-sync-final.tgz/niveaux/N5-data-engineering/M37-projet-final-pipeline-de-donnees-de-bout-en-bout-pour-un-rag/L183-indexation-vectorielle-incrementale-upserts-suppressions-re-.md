---
id: L183
module: M37
level: N5
title: "Indexation vectorielle incrémentale (upserts, suppressions, ré-embedding) et évaluation de la récupération"
minutes: 45
objectives:
  - "Calculer des embeddings par lots en ne traitant que les chunks nouveaux pour un modèle donné"
  - "Synchroniser un index Qdrant de façon idempotente : insertions, mises à jour de droits sans ré-embedding, suppression des points obsolètes, alias"
  - "Propager en continu les suppressions de documents et les effacements RGPD, et prouver qu'aucun batch ne les annule"
  - "Évaluer la récupération (recall@k, MRR, fuites de droits) sur un jeu de 30 questions et justifier le chunking et le modèle par la mesure"
skills: ["C5.5", "C5.3", "C5.2"]
sources:
  - { title: "Qdrant — documentation", url: "https://qdrant.tech/documentation/", lang: "en" }
  - { title: "pgvector — dépôt officiel", url: "https://github.com/pgvector/pgvector", lang: "en" }
  - { title: "Ray — Working with LLMs (Ray Data LLM)", url: "https://docs.ray.io/en/latest/data/working-with-llms.html", lang: "en" }
  - { title: "Ray — Offline batch inference", url: "https://docs.ray.io/en/latest/data/batch_inference.html", lang: "en" }
  - { title: "Debezium — documentation", url: "https://debezium.io/documentation/", lang: "en" }
  - { title: "Mistral — Mistral Embed", url: "https://docs.mistral.ai/models/mistral-embed-23-12", lang: "en" }
  - { title: "Feast — documentation (llms.txt)", url: "https://docs.feast.dev/llms.txt", lang: "en" }
---

# Indexation vectorielle incrémentale (upserts, suppressions, ré-embedding) et évaluation de la récupération

> ⏱ 45 min · 🎯 Niveau 5 · 📚 Module 37

## 🎯 Ce que vous saurez faire
- Remplir l'index vectoriel de Bréval Assist, puis le tenir à jour toutes les 15 minutes en ne recalculant **que** ce qui a changé.
- Modifier les droits d'un document sans recalculer un seul vecteur, et supprimer les morceaux devenus obsolètes sans trou de disponibilité.
- Faire disparaître un document supprimé, ou les tickets d'un client qui exerce son droit à l'effacement, en quelques secondes, et le **prouver** par un test.
- Mesurer si l'assistant retrouve les bons documents, et seulement ceux que l'utilisateur a le droit de voir.

> 🧭 **En clair** — Imaginez le libre-service de l'agence de Nantes. Chaque article a une étiquette (l'identifiant du chunk) et une place en rayon (le vecteur). Chaque nuit, on met en rayon les nouveautés, on retire ce qui n'est plus au catalogue et on change les panneaux « réservé aux professionnels » sans déplacer la marchandise. Si un produit est rappelé par le fabricant, on ne l'enlève pas « la nuit prochaine » : on le retire tout de suite, et on s'assure que la livraison du lendemain ne le remette pas en rayon. Enfin, un client mystère vient régulièrement vérifier qu'on lui indique le bon rayon, et qu'on ne lui ouvre pas la réserve. Cette leçon installe tout cela dans l'index vectoriel.

## 1. Deux chemins, trois invariants

| Chemin | Déclencheur | Ce qu'il fait | Délai visé (L180) |
|---|---|---|---|
| **Micro-batch** (Dagster, L184) | toutes les 15 min | embeddings des chunks nouveaux, upserts, droits, suppression des points obsolètes | < 1 h |
| **Flux** (`indexeur_suppressions.py`) | événement Debezium `d` sur `ged.documents`, `c` sur `rgpd.demandes_effacement` | suppression immédiate par filtre `doc_id` ou `client_id` | < 5 min / < 15 min |

Trois invariants guident tout le code :

1. **Idempotence** : relancer une synchronisation sans changement ne fait **rien** (0 insertion, 0 suppression).
2. **Pas de trou** : quand un document change, ses nouveaux chunks sont insérés **avant** que les anciens soient supprimés.
3. **Pas de résurrection** : ce que le flux a supprimé, le batch ne doit jamais le remettre (d'où les filtres posés en L182 : documents non supprimés, clients non effacés).

## 2. Embeddings par lots, incrémentaux

Le contrat de L178 s'applique tel quel : un cache Parquet `data/rag/embeddings/` et une **anti-jointure** sur `(chunk_id, modele_v)`. Un chunk inchangé garde son identifiant, donc son vecteur ; un changement de modèle change `modele_v`, donc tout est recalculé, dans une nouvelle collection (section 6).

```bash
pip install sentence-transformers
```

```python
# rag/embeddings.py — embeddings par lots et incrémentaux : seuls les chunks absents du cache pour CE modèle
import os
from datetime import datetime, timezone

import pyarrow as pa
import pyarrow.parquet as pq

from rag.config import EMBEDDINGS_DIR, MODELE_EMBEDDING, MODELE_V, connexion_duckdb
from rag.obs import etape

_modele = None


def modele():
    global _modele
    if _modele is None:                     # chargé une fois par processus (comme un acteur Ray, L178)
        from sentence_transformers import SentenceTransformer
        _modele = SentenceTransformer(MODELE_EMBEDDING, device=os.environ.get("EMBEDDING_DEVICE", "cpu"))
    return _modele


def a_calculer(con) -> list[tuple[str, str]]:
    """Anti-jointure sur (chunk_id, modele_v) : la règle de L178."""
    if not list(EMBEDDINGS_DIR.glob("*.parquet")):
        return con.execute("SELECT chunk_id, texte_indexe FROM silver.rag_chunks WHERE indexable").fetchall()
    return con.execute(f"""
        SELECT c.chunk_id, c.texte_indexe FROM silver.rag_chunks c
        WHERE c.indexable AND c.chunk_id NOT IN (
            SELECT chunk_id FROM read_parquet('{EMBEDDINGS_DIR}/*.parquet') WHERE modele_v = ?)""",
        [MODELE_V]).fetchall()


def calculer(con, taille_lot: int = 64, par_fichier: int = 2048) -> int:
    EMBEDDINGS_DIR.mkdir(parents=True, exist_ok=True)
    lignes = a_calculer(con)
    with etape(con, "embeddings") as compteur:
        for debut in range(0, len(lignes), par_fichier):           # un fichier par paquet : reprise après panne
            paquet = lignes[debut:debut + par_fichier]
            vecteurs = modele().encode([t for _, t in paquet], batch_size=taille_lot,
                                       normalize_embeddings=True, show_progress_bar=False)
            maintenant = datetime.now(timezone.utc)
            table = pa.table({
                "chunk_id": [c for c, _ in paquet],
                "modele_v": [MODELE_V] * len(paquet),
                "vecteur": pa.array([v.tolist() for v in vecteurs], type=pa.list_(pa.float32())),
                "calcule_le": pa.array([maintenant] * len(paquet), type=pa.timestamp("ms", tz="UTC")),
            })
            nom = f"emb-{MODELE_V.replace('@', '_')}-{maintenant:%Y%m%dT%H%M%S}-{debut:06d}.parquet"
            pq.write_table(table, EMBEDDINGS_DIR / nom, compression="zstd")
            compteur["n"] += len(paquet)
            compteur["tokens"] += sum(len(t) for _, t in paquet) // 4      # ordre de grandeur (≈ 4 caractères/token)
    return len(lignes)


if __name__ == "__main__":
    con = connexion_duckdb()
    print(calculer(con), "chunks vectorisés (modèle", MODELE_V + ")")
    con.close()
```

```bash
python -m rag.embeddings     # 1re fois : 9 326 chunks (CPU : comptez quelques minutes à quelques dizaines)
python -m rag.embeddings     # 2e fois : 0 chunk vectorisé
```

> 🧭 **Pré-requis express** — Dans **chaque** terminal utilisé pour le projet, commencez par `cd breval && export PYTHONPATH=$PWD && set -a && source .env && set +a` (L181-L182). Le premier lancement télécharge le modèle `BAAI/bge-m3` (plus de 2 Go) s'il n'est pas déjà en cache depuis L176-L178.

> 🛠️ **Si ça ne marche pas** — « Killed » ou ordinateur figé → mémoire insuffisante pour le modèle et le lot : fermez les autres applications, ou baissez la taille des lots dans `rag/embeddings.py`. « Could not set lock on file » → Dagster ou un autre script tient `breval.duckdb`. La seconde exécution revectorise tout → `MODELE_V` ou `CHUNKING_V` ont changé entre les deux exécutions (variables d'environnement différentes d'un terminal à l'autre).

À cette échelle, une boucle par lots dans un seul processus suffit. Au-delà de quelques centaines de milliers de chunks, remplacez la boucle par le job Ray Data de L178 (`map_batches` sur un pool d'acteurs, CPU ou GPU) : il lit `a_calculer()` et écrit le **même** schéma Parquet, le reste du pipeline ne change pas. Le coût d'API, lui, reste anecdotique : à 0,10 $ par million de tokens pour Mistral Embed (tarif relevé en L089, nov. 2026), l'indexation complète du corpus Bréval, environ 0,8 million de tokens d'après `obs.etapes`, coûterait moins de 0,10 $ ; l'essentiel du coût est ailleurs (L184).

## 3. Synchroniser l'index : insérer, mettre à jour les droits, retirer

```python
# rag/index.py — Qdrant : collection, upsert idempotent, droits modifiés, points obsolètes, alias
import argparse
import uuid

from qdrant_client import QdrantClient, models

from rag.config import ALIAS, COLLECTION, DIMENSION, EMBEDDINGS_DIR, MODELE_V, QDRANT_URL, connexion_duckdb
from rag.obs import etape

CHAMPS = ["doc_id", "source_type", "titre", "section", "texte", "agences", "groupes", "droits_hash",
          "client_id", "confidentialite", "date_maj", "chunking_v"]
SELECT_PAYLOAD = """c.doc_id, c.source_type, split_part(c.texte_indexe, ' › ', 1) AS titre, c.section,
                    c.texte_indexe AS texte, c.agences, c.groupes, c.droits_hash, c.client_id,
                    c.confidentialite, strftime(c.date_maj, '%Y-%m-%d') AS date_maj, c.chunking_v"""


def client() -> QdrantClient:
    return QdrantClient(url=QDRANT_URL)


def point_id(chunk_id: str) -> str:
    return str(uuid.UUID(hex=chunk_id))          # même chunk -> même point : l'upsert est idempotent


def collection_servie(q) -> str | None:
    return next((a.collection_name for a in q.get_aliases().aliases if a.alias_name == ALIAS), None)


def assurer_collection(q, nom: str) -> None:
    if q.collection_exists(nom):
        return
    q.create_collection(nom, vectors_config=models.VectorParams(size=DIMENSION, distance=models.Distance.COSINE),
                        hnsw_config=models.HnswConfigDiff(m=16))
    for champ in ("agences", "groupes", "doc_id", "source_type"):       # index de payload : filtres rapides
        q.create_payload_index(nom, champ, field_schema=models.PayloadSchemaType.KEYWORD)
    q.create_payload_index(nom, "client_id", field_schema=models.PayloadSchemaType.INTEGER)


def etat_index(q, nom: str) -> dict[str, str]:
    """id de point -> droits_hash, en parcourant la collection sans les vecteurs."""
    etat, suivant = {}, None
    while True:
        points, suivant = q.scroll(nom, limit=1000, offset=suivant, with_payload=["droits_hash"], with_vectors=False)
        etat.update({str(p.id): (p.payload or {}).get("droits_hash") for p in points})
        if suivant is None:
            return etat


def paquets(liste: list, taille: int):
    for i in range(0, len(liste), taille):
        yield liste[i:i + taille]


def synchroniser(con, q, nom: str = COLLECTION) -> dict:
    assurer_collection(q, nom)
    attendus = {point_id(cid): (cid, h) for cid, h in
                con.execute("SELECT chunk_id, droits_hash FROM silver.rag_chunks WHERE indexable").fetchall()}
    present = etat_index(q, nom)
    a_inserer = [cid for pid, (cid, _) in attendus.items() if pid not in present]
    droits = [cid for pid, (cid, h) in attendus.items() if pid in present and present[pid] != h]
    a_supprimer = [pid for pid in present if pid not in attendus]
    bilan = {"inseres": 0, "droits_mis_a_jour": 0, "supprimes": 0, "sans_embedding": 0}
    with etape(con, "indexation") as compteur:
        # 1) Nouveaux points D'ABORD : un document modifié n'est jamais absent de l'index
        for lot in paquets(a_inserer, 256):
            lignes = con.execute(f"""
                SELECT c.chunk_id, {SELECT_PAYLOAD}, e.vecteur
                FROM silver.rag_chunks c JOIN read_parquet('{EMBEDDINGS_DIR}/*.parquet') e USING (chunk_id)
                WHERE e.modele_v = ? AND list_contains(?::VARCHAR[], c.chunk_id)
                QUALIFY row_number() OVER (PARTITION BY c.chunk_id ORDER BY e.calcule_le DESC) = 1""",
                [MODELE_V, lot]).fetchall()
            q.upsert(nom, wait=True, points=[
                models.PointStruct(id=point_id(r[0]), vector=list(r[-1]),
                                   payload={**dict(zip(CHAMPS, r[1:-1])), "modele_v": MODELE_V})
                for r in lignes])
            bilan["inseres"] += len(lignes)
            bilan["sans_embedding"] += len(lot) - len(lignes)        # seront insérés au prochain passage
        # 2) Droits modifiés sans changement de texte : métadonnées seulement, pas de nouveau vecteur
        for cid in droits:
            agences, groupes, h = con.execute("SELECT agences, groupes, droits_hash FROM silver.rag_chunks "
                                              "WHERE chunk_id = ?", [cid]).fetchone()
            q.set_payload(nom, payload={"agences": agences, "groupes": groupes, "droits_hash": h},
                          points=[point_id(cid)], wait=True)
            bilan["droits_mis_a_jour"] += 1
        # 3) Points obsolètes : document modifié ou supprimé, doublon, gabarit, client effacé…
        for lot in paquets(a_supprimer, 1000):
            q.delete(nom, points_selector=models.PointIdsList(points=lot), wait=True)
            bilan["supprimes"] += len(lot)
        compteur["n"] = sum(bilan[k] for k in ("inseres", "droits_mis_a_jour", "supprimes"))
    if collection_servie(q) is None:                   # premier déploiement : l'alias pointe sur cette collection
        basculer_alias(q, nom)
    return bilan


def basculer_alias(q, nouvelle: str) -> None:
    """Suppression + création dans UNE requête : bascule atomique (blue/green, L178)."""
    operations = []
    if collection_servie(q):
        operations.append(models.DeleteAliasOperation(delete_alias=models.DeleteAlias(alias_name=ALIAS)))
    operations.append(models.CreateAliasOperation(
        create_alias=models.CreateAlias(collection_name=nouvelle, alias_name=ALIAS)))
    q.update_collection_aliases(change_aliases_operations=operations)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--basculer", metavar="COLLECTION", help="fait pointer l'alias « chunks » vers COLLECTION")
    a = ap.parse_args()
    q = client()
    if a.basculer:
        basculer_alias(q, a.basculer)
        print("alias", ALIAS, "→", collection_servie(q))
    else:
        con = connexion_duckdb()
        print(COLLECTION, synchroniser(con, q))
        con.close()
```

La synchronisation compare **l'attendu** (`silver.rag_chunks` indexables) au **présent** (les points de la collection, lus par `scroll` sans leurs vecteurs) (`scroll` parcourt la collection page par page ; `set_payload`, plus bas, réécrit seulement la fiche de métadonnées d'un point) et en déduit trois listes :

- **à insérer** : chunks attendus absents de l'index (nouveaux documents, nouvelles versions, nouveaux tickets) ;
- **droits modifiés** : même chunk, `droits_hash` différent ; `set_payload` change les métadonnées sans toucher au vecteur ;
- **à supprimer** : points présents qui ne sont plus attendus (ancienne version, document supprimé, doublon, gabarit, client effacé).

```bash
python -m rag.index        # 1re fois : {'inseres': 9326, 'droits_mis_a_jour': 0, 'supprimes': 0, 'sans_embedding': 0}
python -m rag.index        # 2e fois : tout à 0 → idempotence démontrée
curl -s http://localhost:6333/collections/chunks_bge_m3_v1 | python -m json.tool | grep points_count   # 9326
```

> 🧭 **Pré-requis express** — `python -m json.tool` met en forme le JSON renvoyé par Qdrant (une clé par ligne) pour que `grep` puisse y trouver `points_count`.

> 🛠️ **Si ça ne marche pas** — « Connection refused » sur 6333 → le service `qdrant` du Compose de L181 n'est pas démarré (`docker compose up -d`). « Wrong input: Vector dimension error » → la collection a été créée avec une autre dimension (essai de L178 avec un autre modèle) : supprimez-la (`curl -X DELETE http://localhost:6333/collections/chunks_bge_m3_v1`) et relancez. `sans_embedding` non nul → lancez `rag.embeddings` avant `rag.index`.

Changez maintenant les droits d'un document sans toucher à son texte : passez PRC-024 (Tarification des professionnels) en `restreint`, puis rejouez le micro-batch à la main.

```bash
docker exec -it breval-postgres psql -U breval -d breval \
  -c "UPDATE ged.documents SET confidentialite = 'restreint', modifie_le = now() WHERE doc_id = 'PRC-024'"
python -m rag.bronze_cdc && (cd dbt_breval && dbt build --profiles-dir . --select path:models/rag/amont)
python -m rag.preparer && python -m rag.embeddings && python -m rag.index
# rag.preparer : pii_calculees 0 · rag.embeddings : 0 chunk · rag.index : droits_mis_a_jour = nombre de chunks indexables de PRC-024
```

**Point de contrôle** — l'embedding n'a rien recalculé, l'index a mis à jour les droits de PRC-024 seulement, et `python -m rag.recherche karim tarification des professionnels` ne renvoie plus PRC-024. Alice, elle, le voit toujours : en `restreint`, PRC-024 reste ouvert à son service propriétaire (`service:commerce`) et à la direction, et Alice est au commerce. Remettez `interne` pour la suite.

```quiz
{
  "q": "Pourquoi synchroniser() insère-t-elle les nouveaux points AVANT de supprimer les obsolètes ?",
  "options": ["Parce que Qdrant refuse une suppression qui précède un upsert dans le même lot", "Pour qu'un document modifié ne soit jamais absent de l'index entre les deux", "Pour réduire la mémoire occupée par le graphe HNSW pendant la mise à jour", "Pour que les identifiants de points restent triés dans l'ordre d'insertion"],
  "answer": 1,
  "explanation": "Dans l'ordre inverse, une question posée entre la suppression et l'insertion ne trouverait plus le document. Le prix à payer est inverse et plus acceptable : pendant quelques secondes, ancienne et nouvelle version coexistent."
}
```

## 4. Les suppressions en flux

```python
# cdc/indexeur_suppressions.py — applique EN CONTINU les suppressions de documents et les effacements RGPD
import json
import time
from datetime import datetime, timezone

from confluent_kafka import Consumer, KafkaException
from qdrant_client import models

from rag.config import AUDIT_SUPPRESSIONS, KAFKA
from rag.index import client

TOPICS = ["breval.ged.documents", "breval.rgpd.demandes_effacement"]


def cible(topic: str, evt: dict) -> tuple[str, object] | None:
    if topic == "breval.ged.documents" and evt["op"] == "d":
        return "doc_id", evt["before"]["doc_id"]
    if topic == "breval.rgpd.demandes_effacement" and evt["op"] in ("c", "r"):
        return "client_id", int(evt["after"]["client_id"])
    return None                                      # créations et modifications : affaire du micro-batch


def appliquer(q, champ: str, valeur) -> int:
    filtre = models.Filter(must=[models.FieldCondition(key=champ, match=models.MatchValue(value=valeur))])
    total = 0
    # TOUTES les collections du projet, y compris celle en construction lors d'un changement de modèle
    for nom in [c.name for c in q.get_collections().collections if c.name.startswith("chunks_")]:
        total += q.count(nom, count_filter=filtre, exact=True).count
        q.delete(nom, points_selector=models.FilterSelector(filter=filtre), wait=True)
    return total


def main() -> None:
    q = client()
    AUDIT_SUPPRESSIONS.parent.mkdir(parents=True, exist_ok=True)
    consommateur = Consumer({"bootstrap.servers": KAFKA, "group.id": "rag-indexeur",
                             "enable.auto.commit": False, "auto.offset.reset": "earliest"})
    consommateur.subscribe(TOPICS)
    try:
        with AUDIT_SUPPRESSIONS.open("a", encoding="utf-8") as journal:
            while True:
                m = consommateur.poll(1.0)
                if m is None:
                    continue
                if m.error():
                    raise KafkaException(m.error())
                quoi = cible(m.topic(), json.loads(m.value())) if m.value() is not None else None
                if quoi:
                    evt = json.loads(m.value())
                    n = appliquer(q, *quoi)
                    latence = time.time() - evt["source"]["ts_ms"] / 1000
                    journal.write(json.dumps({"champ": quoi[0], "valeur": quoi[1], "points_supprimes": n,
                                              "source_ts_ms": evt["source"]["ts_ms"], "latence_s": round(latence, 2),
                                              "applique_le": datetime.now(timezone.utc).isoformat()}) + "\n")
                    journal.flush()
                    print(f"{quoi[0]}={quoi[1]} : {n} points supprimés en {latence:.1f} s")
                # Commit APRÈS la suppression : rejouer une suppression est sans effet (idempotente)
                consommateur.commit(message=m, asynchronous=False)
    except KeyboardInterrupt:
        pass
    finally:
        consommateur.close()


if __name__ == "__main__":
    main()
```

```bash
python cdc/indexeur_suppressions.py                  # terminal 3 (le terminal 1 fait tourner cdc_vers_bronze.py)
python ingestion/ged_simulateur.py supprimer PRC-014 # terminal 2
# terminal 3 : « doc_id=PRC-014 : 4 points supprimés en 1.3 s » (4 chunks avec le découpage par sections ; latence : ordre de grandeur)
tail -1 data/rag/audit/suppressions.jsonl            # la preuve horodatée, lue par les moniteurs (L184)
```

> 🛠️ **Si ça ne marche pas** — Rien ne s'affiche dans le terminal 3 → l'indexeur n'était pas lancé **avant** la suppression, ou il a démarré en lisant le topic à partir de la fin : relancez-le, puis supprimez un autre document. « No such file or directory: data/rag/audit/suppressions.jsonl » → aucune suppression n'a encore été traitée. Le document réapparaît au micro-batch suivant → `rag_documents_courants` n'a pas été reconstruit (`dbt build … path:models/rag/amont`) après le chargement du nouvel événement CDC.

Trois détails comptent. L'indexeur **supprime par filtre** (`doc_id`, `client_id`) : il n'a pas besoin de connaître les identifiants des chunks. Il agit sur **toutes** les collections `chunks_*`, y compris celle qu'on serait en train de construire pour un nouveau modèle : sinon la bascule d'alias ressusciterait le document. Enfin, il valide l'offset **après** la suppression : en cas de plantage, la suppression est rejouée, ce qui est sans effet (une suppression est idempotente par nature).

Relancez maintenant le micro-batch : PRC-014 ne revient pas, car `rag_documents_courants` ne contient plus que les documents dont le dernier événement n'est pas `d`. C'est l'invariant « pas de résurrection ». Restaurez ensuite le document (`ged_simulateur.py restaurer PRC-014`) : le micro-batch suivant le réindexe.

> 💡 **Autrement dit** — Le flux est un pompier : il éteint tout de suite, sans réfléchir à la reconstruction. Le batch est l'architecte : il reconstruit ce qui doit l'être, en consultant le même registre que le pompier. Comme les deux lisent la même source de vérité, ils ne se contredisent jamais.

## 5. Chercher avec les droits

```python
# rag/recherche.py — la recherche de Bréval Assist : TOUJOURS l'alias, TOUJOURS le filtre de droits
from qdrant_client import models

from rag.config import ALIAS
from rag.embeddings import modele
from rag.index import client


def filtre(profil: dict) -> models.Filter:
    """Traduction exacte de rag.droits.autorise() : une agence ET un groupe en commun."""
    return models.Filter(must=[
        models.FieldCondition(key="agences", match=models.MatchAny(any=profil["agences"])),
        models.FieldCondition(key="groupes", match=models.MatchAny(any=profil["groupes"])),
    ])


def rechercher(question: str, profil: dict, k: int = 5, q=None, collection: str = ALIAS):
    vecteur = modele().encode(question, normalize_embeddings=True).tolist()
    return (q or client()).query_points(collection, query=vecteur, query_filter=filtre(profil),
                                        limit=k, with_payload=True).points


if __name__ == "__main__":
    import sys
    from rag.droits import PROFILS
    profil, question = sys.argv[1], " ".join(sys.argv[2:])
    for p in rechercher(question, PROFILS[profil]):
        print(f"{p.score:.3f}  {p.payload['doc_id']:18s} {p.payload['texte'][:90]!r}")
```

```bash
python -m rag.recherche sandrine "réorganisation du dépôt de Saint-Nazaire"   # NOTE-002 en tête
python -m rag.recherche alice "réorganisation du dépôt de Saint-Nazaire"      # aucun extrait de NOTE-002
python -m rag.recherche karim "commande CMD-2026-0034174"                     # SAV-0008640 (agence STN)
python -m rag.recherche alice "commande CMD-2026-0034174"                     # rien de STN
```

> 🔍 **Ce que vous devez voir** — pour chaque commande, jusqu'à 5 lignes `score  doc_id  'début du texte'`, par exemple `0.712  SAV-0008640        '[client] Livraison CMD-2026-0034174 : …'` ; pour Alice, des résultats d'autres agences ou documents, mais **aucun** `doc_id` de Saint-Nazaire. Chaque appel recharge le modèle d'embedding : comptez quelques secondes à quelques dizaines de secondes par recherche, c'est normal pour ce script de démonstration.

Le filtre est appliqué **pendant** la recherche, grâce aux index de payload sur `agences` et `groupes` : Qdrant ne parcourt que les points autorisés et renvoie bien `k` résultats, même pour un petit service (le piège du post-filtrage de L178).

```mission
{
  "title": "La condition « l'une de ces valeurs » dans les filtres Qdrant",
  "url": "https://qdrant.tech/documentation/",
  "steps": ["Ouvrez la documentation Qdrant, rubrique Filtering", "Repérez les conditions de correspondance (match)", "Cherchez comment elles s'appliquent à un champ de type tableau"],
  "question": "Quelle condition permet de tester qu'un champ vaut l'une de plusieurs valeurs, et que se passe-t-il quand le champ est un tableau (comme nos « agences ») ?",
  "hint": "Notre filtre l'utilise deux fois, sous le nom MatchAny dans le client Python.",
  "answer": "La condition match any (« match »: {« any »: [...]}) ; sur un tableau, la condition est satisfaite si au moins un élément du tableau correspond (doc consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 6. Évaluer la récupération

### 6.1 Le jeu de 30 questions

Le cahier des charges impose 30 questions, dont 10 synthétiques **relues**. Chaque ligne de `evals/questions_projet.jsonl` donne la question, le profil qui la pose et les **documents** attendus. On étiquette au niveau du document et non du chunk : les `chunk_id` changent avec la configuration de découpage, les `doc_id` non. C'est ce qui permet de comparer deux chunkings sur le même jeu. Voici les 12 premières, écrites à la main à partir du corpus :

```jsonl
{"id": "H01", "question": "Quel délai de règlement accorde-t-on aux clients professionnels ?", "doc_ids_attendus": ["CGV-2026-PRO"], "profil": "alice", "origine": "humain", "relu": true}
{"id": "H02", "question": "Quelle pénalité s'applique quand un particulier paie en retard ?", "doc_ids_attendus": ["CGV-2026-PAR"], "profil": "alice", "origine": "humain", "relu": true}
{"id": "H03", "question": "Comment se fait le remboursement des notes de frais ?", "doc_ids_attendus": ["PRC-001"], "profil": "lea", "origine": "humain", "relu": true}
{"id": "H04", "question": "Que faire pour renvoyer une marchandise à un fournisseur ?", "doc_ids_attendus": ["PRC-002"], "profil": "erwan", "origine": "humain", "relu": true}
{"id": "H05", "question": "Quelles sont les règles de sécurité pour conduire le chariot élévateur ?", "doc_ids_attendus": ["PRC-004"], "profil": "erwan", "origine": "humain", "relu": true}
{"id": "H06", "question": "Comment organiser une livraison directement sur un chantier ?", "doc_ids_attendus": ["PRC-014"], "profil": "karim", "origine": "humain", "relu": true}
{"id": "H07", "question": "Quel est le lambda de la laine de verre 100 mm Pro Nantia ?", "doc_ids_attendus": ["FT-BRV-ISO-00075"], "profil": "alice", "origine": "humain", "relu": true}
{"id": "H08", "question": "En quelle essence est le contreplaqué peuplier 15 mm Expert Ouest Bâti ?", "doc_ids_attendus": ["FT-BRV-BOI-00482"], "profil": "alice", "origine": "humain", "relu": true}
{"id": "H09", "question": "À quelle norme électrique répond l'interrupteur va-et-vient Premium Nantia ?", "doc_ids_attendus": ["FT-BRV-ELE-00613"], "profil": "erwan", "origine": "humain", "relu": true}
{"id": "H10", "question": "Où en est la réorganisation du dépôt de Saint-Nazaire ?", "doc_ids_attendus": ["NOTE-002"], "profil": "sandrine", "origine": "humain", "relu": true}
{"id": "H11", "question": "Quel problème le client a-t-il signalé sur la commande CMD-2026-0034174 ?", "doc_ids_attendus": ["SAV-0008640"], "profil": "karim", "origine": "humain", "relu": true}
{"id": "H12", "question": "Des produits sont-ils arrivés cassés sur la commande CMD-2026-0030392 ?", "doc_ids_attendus": ["SAV-0008364"], "profil": "alice", "origine": "humain", "relu": true}
```

Rédigez-en 8 de plus (H13 à H20), en variant les profils et les types : au moins deux tickets, deux procédures restreintes, une question formulée sans aucun mot du titre (« Qui contacter si je me blesse au dépôt ? »). Générez ensuite des candidates synthétiques avec le modèle local de L179 :

```python
# evals/generer_questions_synth.py — 10 questions candidates par un LLM local (méthode de L179), À RELIRE
import json
import os

from openai import OpenAI

from rag.config import connexion_duckdb

client = OpenAI(base_url=os.environ.get("LLM_BASE_URL", "http://localhost:11434/v1"),
                api_key=os.environ.get("LLM_API_KEY", "ollama"))       # aucune donnée ne sort du poste
MODELE = os.environ.get("LLM_MODEL", "qwen3.8:27b")                  # même modèle local qu'en L137/L179

con = connexion_duckdb(read_only=True)
echantillon = con.execute("""
    (SELECT doc_id, texte_indexe FROM silver.rag_chunks
     WHERE indexable AND source_type = 'document' ORDER BY hash(chunk_id) LIMIT 6)
    UNION ALL
    (SELECT doc_id, texte_indexe FROM silver.rag_chunks
     WHERE indexable AND source_type = 'ticket' ORDER BY hash(chunk_id) LIMIT 6)""").fetchall()   # stratifié, reproductible

with open("evals/questions_synth_a_relire.jsonl", "w", encoding="utf-8") as f:
    for n, (doc_id, texte) in enumerate(echantillon, start=1):
        consigne = ("Voici un extrait d'un document interne d'un négoce de matériaux. Rédigez UNE question "
                    "qu'un salarié poserait et dont la réponse se trouve dans l'extrait, SANS recopier ses phrases. "
                    'Répondez uniquement en JSON : {"question": "..."}\n\n' + texte)
        rep = client.chat.completions.create(model=MODELE, temperature=0.7,
                                             messages=[{"role": "user", "content": consigne}])
        brut = rep.choices[0].message.content.strip().removeprefix("```json").removesuffix("```")
        try:
            question = json.loads(brut)["question"]
        except (json.JSONDecodeError, KeyError):
            continue                                                   # sortie mal formée : jetée
        f.write(json.dumps({"id": f"S{n:02d}", "question": question, "doc_ids_attendus": [doc_id],
                            "profil": "sandrine", "origine": f"synthetique:{MODELE}", "relu": False},
                           ensure_ascii=False) + "\n")
print("Relisez evals/questions_synth_a_relire.jsonl, gardez-en 10, passez « relu » à true, "
      "puis ajoutez-les à evals/questions_projet.jsonl")
```

Relisez chaque candidate : jetez celles qui recopient l'extrait (une question qui reprend une phrase entière rend la recherche trop facile : c'est la décontamination de L176) ou qui seraient ambiguës (plusieurs fiches techniques répondent), corrigez les autres, passez `relu` à `true` et ajoutez-en 10 au jeu. Versionnez le fichier (Git, ou DVC comme en L179).

### 6.2 Les métriques

```python
# rag/evaluation.py — recall@k et MRR au niveau DOCUMENT, par profil, avec comptage des fuites de droits
import argparse
import json
import statistics
from collections import defaultdict
from datetime import datetime, timezone

from rag.config import ALIAS, CHUNKING_V, MODELE_V, RACINE, connexion_duckdb
from rag.droits import PROFILS, autorise
from rag.index import client, collection_servie
from rag.obs import run_id
from rag.recherche import rechercher

JEU = RACINE / "evals" / "questions_projet.jsonl"


def evaluer(k: int = 5, k_chunks: int = 20, collection: str = ALIAS) -> tuple[dict, list[dict]]:
    q = client()
    questions = [json.loads(l) for l in JEU.open(encoding="utf-8") if l.strip()]
    questions = [x for x in questions if x.get("relu", False)]        # une question non relue ne compte pas
    details = []
    for x in questions:
        profil = PROFILS[x["profil"]]
        points = rechercher(x["question"], profil, k=k_chunks, q=q, collection=collection)
        fuites = sum(not autorise(profil, p.payload["agences"], p.payload["groupes"]) for p in points)
        docs = list(dict.fromkeys(p.payload["doc_id"] for p in points))[:k]   # classement de documents
        attendus = set(x["doc_ids_attendus"])
        rang = next((i + 1 for i, d in enumerate(docs) if d in attendus), None)
        details.append({"id": x["id"], "origine": x["origine"].split(":")[0], "profil": x["profil"],
                        "recall": len(attendus & set(docs)) / len(attendus),
                        "rr": 1 / rang if rang else 0.0, "fuites": fuites, "top": docs})
    par_origine = defaultdict(list)
    for d in details:
        par_origine[d["origine"]].append(d)
    synthese = {
        "collection": collection_servie(q) if collection == ALIAS else collection,
        "chunking_v": CHUNKING_V, "modele_v": MODELE_V, "k": k, "n": len(details),
        "recall": round(statistics.mean(d["recall"] for d in details), 3),
        "mrr": round(statistics.mean(d["rr"] for d in details), 3),
        "fuites": sum(d["fuites"] for d in details),
        "par_origine": {o: {"n": len(v), "recall": round(statistics.mean(d["recall"] for d in v), 3),
                            "mrr": round(statistics.mean(d["rr"] for d in v), 3)} for o, v in par_origine.items()},
    }
    return synthese, details


def enregistrer(con, s: dict) -> None:
    con.execute("CREATE SCHEMA IF NOT EXISTS obs")
    con.execute("""CREATE TABLE IF NOT EXISTS obs.evaluations (run_id VARCHAR, evalue_le TIMESTAMPTZ,
                   collection VARCHAR, chunking_v VARCHAR, modele_v VARCHAR, k INTEGER, n INTEGER,
                   recall DOUBLE, mrr DOUBLE, fuites INTEGER)""")
    con.execute("INSERT INTO obs.evaluations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [run_id(), datetime.now(timezone.utc), s["collection"], s["chunking_v"], s["modele_v"],
                 s["k"], s["n"], s["recall"], s["mrr"], s["fuites"]])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--collection", default=ALIAS)
    ap.add_argument("--k", type=int, default=5)
    a = ap.parse_args()
    synthese, details = evaluer(k=a.k, collection=a.collection)
    print(json.dumps(synthese, ensure_ascii=False, indent=2))
    for d in details:
        if d["rr"] == 0:
            print("RATÉ", d["id"], d["profil"], d["top"])
    con = connexion_duckdb()
    enregistrer(con, synthese)
    con.close()
```

Trois choix à justifier dans votre dossier. **recall@5 au niveau document** : parmi les documents attendus, quelle part figure dans les 5 premiers documents distincts ? **MRR** (*mean reciprocal rank*) : en moyenne, 1 divisé par le rang du premier bon document (1 s'il est premier, 0,5 s'il est deuxième…). On demande 20 chunks puis on dédoublonne par document, car un document découpé en sections occuperait sinon plusieurs places du top 5. Enfin, les **fuites** : le nombre de chunks renvoyés que le profil n'avait pas le droit de voir. L'objectif est 0, sans exception.

```bash
python -m rag.evaluation                        # synthèse JSON + liste des questions ratées, enregistrée dans obs.evaluations
```

> 🔍 **Ce que vous devez voir** — un dictionnaire de synthèse du type `{'collection': 'chunks_bge_m3_v1', 'n_questions': 30, 'recall@5': 0.83, 'mrr': 0.71, 'fuites': 0, …}` suivi de la liste des questions ratées avec leurs documents attendus et obtenus.

> 🛠️ **Si ça ne marche pas** — « FileNotFoundError: evals/questions_projet.jsonl » → créez ce fichier à partir des 12 questions de la section 6.1 (une ligne JSON par question) avant de lancer l'évaluation. `fuites` > 0 → **arrêtez tout** : un profil voit un chunk interdit ; comparez son payload à `rag/droits.py` (voir les pistes de corrigé de l'exercice).

### 6.3 Justifier le chunking par la mesure

C5.5 demande que « la stratégie de chunking soit justifiée par une évaluation de récupération ». Construisez la seconde configuration dans une **autre** collection, sans toucher à l'alias :

```bash
# Arrêtez le micro-batch Dagster pendant l'expérience : silver va changer de configuration
CHUNKING_V=doc-entier-v1 python -m rag.preparer
python -m rag.embeddings
RAG_COLLECTION=chunks_bge_m3_docentier_v1 python -m rag.index      # l'alias reste sur chunks_bge_m3_v1
python -m rag.evaluation --collection chunks_bge_m3_v1
python -m rag.evaluation --collection chunks_bge_m3_docentier_v1
```

| Configuration | Chunks de documents | recall@5 | MRR | Fuites | Remarques |
|---|---|---|---|---|---|
| `struct-md-v2-max350-rec50` | 378 (278 indexables) | … | … | 0 | à remplir avec vos mesures |
| `doc-entier-v1` | 116 | … | … | 0 | |

Sur des documents courts comme ceux de Bréval, le document entier l'emporte souvent (le titre et le contenu restent ensemble) ; sur des CGV de quarante pages, ce serait l'inverse. C'est la mesure qui tranche, et vous l'écrivez dans le dossier. Basculez l'alias vers la meilleure collection (`python -m rag.index --basculer …`), relancez `rag.preparer` avec la configuration retenue, puis réactivez Dagster.

Analysez aussi les questions ratées. Les questions sur un numéro de commande (H11, H12) sont un cas d'école : un modèle d'embedding dense rapproche mal deux chaînes de chiffres. La recherche **hybride** (mots-clés + vecteurs, L092) est la parade naturelle ; notez-la comme amélioration dans le dossier plutôt que de « tricher » en reformulant la question.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : étiqueter le jeu d'évaluation par chunk_id plutôt que par doc_id rend la comparaison de deux configurations de chunking plus fiable.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Le chunk_id dépend de la configuration de découpage : avec une autre configuration, les identifiants attendus n'existent plus et la comparaison devient impossible. Le doc_id est stable, il permet d'évaluer toutes les configurations sur le même jeu."
}
```

### 6.4 Changer de modèle d'embedding sans coupure

La même mécanique sert au changement de modèle (L178) : nouvelles variables, nouvelle collection, évaluation, bascule atomique, ancienne collection conservée quelques jours pour un retour arrière.

```bash
export EMBEDDING_MODEL=<nouveau modèle> EMBEDDING_MODEL_V=<nom>@2026-12 EMBEDDING_DIM=<dimension>
export RAG_COLLECTION=chunks_<nom>_v1
python -m rag.embeddings && python -m rag.index           # construit la collection ; l'indexeur de flux y applique déjà les suppressions
python -m rag.evaluation --collection chunks_<nom>_v1     # meilleur que l'actuelle ? Zéro fuite ?
python -m rag.index --basculer chunks_<nom>_v1            # bascule en une requête ; l'assistant ne voit rien
```

## 7. Les tests de bout en bout

Les preuves de la grille (idempotence, suppression propagée, cloisonnement, effacement) deviennent un fichier de tests que le jury peut relancer :

```python
# tests_pipeline/test_rag.py — pytest -q -s tests_pipeline/test_rag.py
# Prérequis : plateforme démarrée, index construit, cdc_vers_bronze.py et indexeur_suppressions.py en marche,
# Dagster arrêté (DuckDB n'accepte qu'un écrivain).
import subprocess
import sys
import time

import pytest
from qdrant_client import models

from rag import embeddings
from rag.config import RACINE, SLO_SUPPRESSION_S, connexion_duckdb
from rag.droits import PROFILS, autorise
from rag.index import client, collection_servie, synchroniser
from rag.preparer import preparer
from rag.recherche import rechercher

SONDES = ["notes de frais", "réorganisation du dépôt de Saint-Nazaire", "produits cassés à la livraison",
          "plan de continuité d'activité", "facture incorrecte, remise oubliée", "consignes du chariot élévateur"]
CLIENT_TEST = 493                    # client du ticket SAV-0008372 ; non utilisé par le jeu de questions


def compter(champ: str, valeur) -> int:
    q = client()
    filtre = models.Filter(must=[models.FieldCondition(key=champ, match=models.MatchValue(value=valeur))])
    return q.count(collection_servie(q), count_filter=filtre, exact=True).count


def attendre_zero(champ: str, valeur, delai_max: float) -> float | None:
    debut = time.time()
    while time.time() - debut < delai_max:
        if compter(champ, valeur) == 0:
            return time.time() - debut
        time.sleep(2)
    return None


def simulateur(*args: str) -> None:
    subprocess.run([sys.executable, "ingestion/ged_simulateur.py", *args], check=True, cwd=RACINE)


def micro_batch() -> None:
    """Le micro-batch de Dagster (L184), lancé à la main : bronze CDC -> dbt amont -> silver -> index."""
    subprocess.run([sys.executable, "-m", "rag.bronze_cdc"], check=True, cwd=RACINE)
    subprocess.run(["dbt", "build", "--profiles-dir", ".", "--select", "path:models/rag/amont"],
                   check=True, cwd=RACINE / "dbt_breval")
    con = connexion_duckdb()
    try:
        preparer(con)
        embeddings.calculer(con)
        synchroniser(con, client(), collection_servie(client()))
    finally:
        con.close()


@pytest.mark.parametrize("nom", sorted(PROFILS))
def test_cloisonnement(nom):
    profil = PROFILS[nom]
    for sonde in SONDES:
        for p in rechercher(sonde, profil, k=30):
            assert autorise(profil, p.payload["agences"], p.payload["groupes"]), (nom, sonde, p.payload["doc_id"])


def test_cas_connus():
    alice = PROFILS["alice"]
    assert "NOTE-002" not in {p.payload["doc_id"] for p in rechercher("réorganisation du dépôt", alice, k=50)}
    assert "PRC-001" not in {p.payload["doc_id"] for p in rechercher("notes de frais", alice, k=50)}
    assert "SAV-0008640" not in {p.payload["doc_id"] for p in rechercher("commande CMD-2026-0034174", alice, k=50)}
    assert "PRC-001" in {p.payload["doc_id"] for p in rechercher("notes de frais", PROFILS["lea"], k=10)}


def test_synchronisation_idempotente():
    con = connexion_duckdb()
    try:
        synchroniser(con, client(), collection_servie(client()))
        second = synchroniser(con, client(), collection_servie(client()))
    finally:
        con.close()
    assert second == {"inseres": 0, "droits_mis_a_jour": 0, "supprimes": 0, "sans_embedding": 0}


def test_suppression_propagee():
    assert compter("doc_id", "PRC-014") > 0, "PRC-014 doit être indexé avant le test"
    simulateur("supprimer", "PRC-014")
    try:
        delai = attendre_zero("doc_id", "PRC-014", SLO_SUPPRESSION_S)
        assert delai is not None, f"PRC-014 encore indexé après {SLO_SUPPRESSION_S} s : SLO non tenu"
        print(f"\nSuppression propagée en {delai:.1f} s (SLO : {SLO_SUPPRESSION_S} s)")
        micro_batch()                                    # le batch suivant ne doit PAS ressusciter le document
        assert compter("doc_id", "PRC-014") == 0
    finally:
        simulateur("restaurer", "PRC-014")              # remet le jeu dans son état initial


def test_effacement_client():
    assert compter("client_id", CLIENT_TEST) > 0
    simulateur("effacer-client", str(CLIENT_TEST))       # irréversible hors TP : voir le runbook
    delai = attendre_zero("client_id", CLIENT_TEST, 900)
    assert delai is not None, "effacement non propagé en 15 min"
    micro_batch()
    assert compter("client_id", CLIENT_TEST) == 0
```

```bash
pytest -q -s tests_pipeline/test_rag.py
# ........  Suppression propagée en 3.9 s (SLO : 300 s)        ← ordre de grandeur sur un poste
# 9 passed
```

> 🧭 **Pré-requis express** — Ces tests rejouent tout le pipeline : Postgres, Kafka, Connect, MinIO et Qdrant doivent tourner, ainsi que le consommateur bronze et l'indexeur de suppressions dans leurs terminaux ; Dagster, lui, doit être **arrêté** (voir le piège ci-dessous). Comptez plusieurs minutes.

> 🛠️ **Si ça ne marche pas** — Un test échoue sur un délai (« suppression non propagée ») → l'indexeur de suppressions ne tourne pas. « could not set lock » → un autre programme a ouvert `breval.duckdb`.

| Erreur fréquente | Conséquence | Parade |
|---|---|---|
| Recalculer tous les embeddings à chaque exécution | coût et durée multipliés par 100 | anti-jointure `(chunk_id, modele_v)` sur le cache |
| Supprimer puis insérer | trou de disponibilité à chaque modification | insérer d'abord, supprimer ensuite |
| Re-vectoriser quand seuls les droits changent | calcul inutile, risque d'incohérence | `droits_hash` et `set_payload` |
| Supprimer en flux sans filtrer le batch | le document « revient » 15 minutes plus tard | même source de vérité pour les deux chemins |
| Supprimer dans la seule collection servie | la nouvelle collection ressuscite le document à la bascule | supprimer dans toutes les collections `chunks_*` |
| Évaluer sans profil | la mesure ignore le filtre et surestime la qualité | chaque question porte le profil qui la pose |

> ⚠️ **Piège fréquent** — Lancer les tests pendant que Dagster tourne : deux écrivains se disputent `data/breval.duckdb` et l'un échoue (« could not set lock »). Arrêtez le démon Dagster ou utilisez une copie de la base pour les tests.

## 🧪 Exercice pratique

**Consigne** — (1) Construisez l'index et démontrez l'idempotence (deux synchronisations). (2) Changez les droits de PRC-024 et prouvez qu'aucun vecteur n'a été recalculé. (3) Lancez l'indexeur de flux et mesurez la latence de 5 suppressions (moyenne et maximum, depuis `audit/suppressions.jsonl`). (4) Complétez le jeu à 30 questions (20 humaines, 10 synthétiques relues). (5) Comparez les deux configurations de chunking et basculez l'alias vers la meilleure. (6) Faites passer `test_rag.py`.

**Critères de réussite** — Deuxième synchronisation à 0 partout ; `droits_mis_a_jour` > 0 et 0 chunk vectorisé lors du changement de droits ; 5 latences de suppression sous 300 s ; jeu de 30 questions dont 10 marquées `synthetique` et `relu: true` ; tableau comparatif rempli avec recall@5, MRR et 0 fuite ; 9 tests verts.

**Pistes de corrigé** — Latences : `python -c "import json,statistics; L=[json.loads(l)['latence_s'] for l in open('data/rag/audit/suppressions.jsonl')]; print(statistics.mean(L), max(L))"`. Si `test_cloisonnement` échoue, comparez le payload fautif à `rag/droits.py` : le plus souvent, l'index contient encore des points d'une ancienne règle ; relancez `rag.preparer` puis `rag.index` (les `droits_hash` divergent et sont corrigés). Si recall@5 est sous 0,80, regardez d'abord les questions ratées par type (ticket, fiche technique, procédure) avant de toucher aux paramètres.

## ✅ Auto-évaluation express
1. Quelles sont les trois listes calculées par la synchronisation, et quelle opération Qdrant applique-t-on à chacune ?
2. Pourquoi l'indexeur de flux supprime-t-il dans toutes les collections `chunks_*` ?
3. Pourquoi évaluer au niveau du document et non du chunk ?

**Réponses** — 1. À insérer (`upsert` avec vecteur), droits modifiés (`set_payload` sans vecteur), à supprimer (`delete` par identifiants). 2. Pour qu'une collection en construction (changement de modèle) ne contienne pas un document supprimé entre-temps, qui réapparaîtrait au moment de la bascule d'alias. 3. Parce que les identifiants de chunks changent avec la configuration de découpage ; les identifiants de documents sont stables et permettent de comparer configurations et modèles sur le même jeu.

## 📚 Pour aller plus loin
- [Qdrant — documentation](https://qdrant.tech/documentation/) 🇬🇧 — filtres, index de payload, alias, `scroll`, `set_payload`, snapshots.
- [pgvector](https://github.com/pgvector/pgvector) 🇬🇧 — la variante SQL : `ON CONFLICT` pour l'upsert, politique RLS pour les droits (L174).
- [Ray — Offline batch inference](https://docs.ray.io/en/latest/data/batch_inference.html) 🇬🇧 — passer les embeddings à l'échelle sans changer le contrat du cache.
- [Mistral Embed](https://docs.mistral.ai/models/mistral-embed-23-12) 🇬🇧 — modèle d'embedding par API, hébergé en Europe, pour estimer le coût cloud.
- [Feast — documentation](https://docs.feast.dev/llms.txt) 🇬🇧 — les *online stores* vectoriels, autre façon de servir des chunks.

> ✅ **Si vous ne retenez que 3 choses** — 1. Le micro-batch ne recalcule que l'indispensable : embeddings des seuls chunks nouveaux (anti-jointure sur `(chunk_id, modele_v)`), insertion des absents, `set_payload` quand seuls les droits changent, suppression des points obsolètes **après** les insertions ; relancé sans changement, il ne fait rien. 2. Les suppressions de documents et les effacements RGPD passent en flux (indexeur Kafka, suppression par filtre dans **toutes** les collections, offset validé après) et le batch ne les ressuscite pas, car les deux chemins lisent le même registre. 3. On évalue au niveau du document, avec le profil qui pose chaque question : recall@5, MRR et **zéro fuite** de droits ; c'est cette mesure qui choisit le chunking et le modèle, et les tests `test_rag.py` en font des preuves rejouables.

> 🗺️ **Et maintenant ?** — Votre index est juste, frais et cloisonné quand vous le surveillez vous-même ; en L184, vous le rendez autonome : orchestration, moniteurs, coût par document, runbook, puis la soutenance qui présente tout cela en 15 minutes.
