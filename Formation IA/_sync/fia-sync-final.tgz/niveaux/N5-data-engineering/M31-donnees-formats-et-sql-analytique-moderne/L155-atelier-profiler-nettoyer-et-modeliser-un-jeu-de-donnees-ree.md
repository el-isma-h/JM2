---
id: L155
module: M31
level: N5
title: "Atelier : profiler, nettoyer et modéliser un jeu de données réel en Parquet avec DuckDB et Polars"
minutes: 45
objectives:
  - "Profiler un jeu de données (complétude, unicité, formats, valeurs aberrantes) avec DuckDB SUMMARIZE et Polars"
  - "Appliquer des règles de nettoyage traçables (normalisation, dédoublonnage, imputation signalée, quarantaine) pour produire une couche silver"
  - "Construire la couche gold (dimensions, dimension client SCD 2, fait des ventes) à partir de la couche silver"
  - "Évaluer le résultat par des contrôles de réconciliation chiffrés entre bronze, silver et gold"
skills: ["C5.1"]
sources:
  - { title: "DuckDB 2.0 — Integration with Polars", url: "https://duckdb.org/docs/2.0/guides/python/polars.html", lang: "en" }
  - { title: "Polars — documentation", url: "https://docs.pola.rs/", lang: "en" }
  - { title: "DuckDB — documentation", url: "https://duckdb.org/docs/", lang: "en" }
  - { title: "DataDriven — Data Observability: 5 Pillars and Tools (2026)", url: "https://datadriven.io/data-observability", lang: "en" }
  - { title: "INSEE — Répertoire Sirene (identifiants SIREN / SIRET)", url: "https://www.sirene.fr/", lang: "fr" }
---

# Atelier : profiler, nettoyer et modéliser Bréval en Parquet avec DuckDB et Polars

> ⏱ 45 min · 🎯 Niveau 5 · 📚 Module 31

## 🎯 Ce que vous saurez faire
- Dresser en dix minutes le « bilan de santé » d'un jeu de données inconnu.
- Transformer la couche bronze de Bréval en couche **silver** propre, sans jamais rien perdre en silence.
- Construire la couche **gold** (étoile des ventes) et prouver, chiffres à l'appui, qu'aucune ligne ne s'est évaporée.

> 🧭 **En clair** — Avant de cuisiner, on trie les légumes : ceux qui sont abîmés partent dans un bac à part (on ne les jette pas, le fournisseur devra s'expliquer), ceux qui sont sales sont lavés, ceux qui sont en double sont regroupés. Profiler, c'est inspecter le cageot ; nettoyer, c'est trier en notant tout ce qu'on a fait ; réconcilier, c'est vérifier qu'à la fin le poids des légumes cuisinés plus celui du bac à part égale bien le poids livré. Vous utilisez deux couteaux complémentaires : DuckDB (SQL) pour les calculs sur les montants, Polars (DataFrames) pour le travail fin sur le texte.

## 1. Profiler : le bilan de santé (10 min)

> 🧭 **Pré-requis express** — **Profiler** un jeu de données, c'est mesurer sa forme avant d'y toucher : nombre de lignes, valeurs vides, valeurs distinctes, formats. Un **DataFrame** (Polars, pandas) est un tableau en mémoire manipulé en Python, colonne par colonne ; `pl.read_parquet` en charge un d'un coup, `pl.scan_parquet` prépare une lecture « paresseuse » (*LazyFrame*) qui ne s'exécute qu'au `.collect()` (détails en L160). Lancez chaque script de cet atelier depuis `breval/`, venv activée : `python profilage.py`.

```python
# breval/profilage.py
import duckdb
import polars as pl

con = duckdb.connect()
print(con.sql("SUMMARIZE SELECT * FROM 'data/bronze/clients.parquet'"))   # min, max, distincts approx., % de nuls…

clients = pl.read_parquet("data/bronze/clients.parquet")
print(clients.null_count())

# « Masque de format » : on remplace chaque chiffre par 9 pour voir les familles d'écriture
print(clients.select(pl.col("telephone").str.replace_all(r"\d", "9").alias("masque"))
             .to_series().value_counts(sort=True))

# Doublons « métier » : même e-mail une fois normalisé
print(clients.select(pl.col("email").str.strip_chars().str.to_lowercase()).to_series()
             .drop_nulls().is_duplicated().sum() // 2, "paires de doublons (≈)")

print(con.sql("""
    SELECT count(*) - count(DISTINCT commande_id)                         AS doublons_export,
           count(*) FILTER (WHERE date_commande >= TIMESTAMP '2026-11-01') AS dates_futures
    FROM 'data/bronze/commandes.parquet'"""))
```

> 🔍 **Ce que vous devez voir** — d'abord un large tableau `SUMMARIZE` (une ligne par colonne de `clients`, avec `min`, `max`, `approx_unique`, `null_percentage`…), puis une ligne de comptage des nuls par colonne, puis un petit tableau `masque | count` montrant **quatre** familles d'écriture du téléphone (par exemple `99 99 99 99 99`, `9999999999`, `+99 9 99 99 99 99`, `99.99.99.99.99`), un nombre de paires de doublons d'e-mail, et enfin `doublons_export = 240`, `dates_futures = 11`. Le tableau `SUMMARIZE` est très large : agrandissez la fenêtre du terminal si les colonnes sont coupées (`…`).

Consignez vos constats dans un tableau avant de corriger quoi que ce soit. Avec le jeu de référence (graine 42, échelle 1), vous devez retrouver :

| Constat | Valeur attendue | Décision silver |
|---|---|---|
| Commandes exportées deux fois | 240 lignes | supprimer les doublons exacts |
| Commandes datées « 206x » | 11 | **quarantaine** (avec leurs 31 lignes) |
| Lignes à quantité négative | 171 | quarantaine (les retours doivent passer par un avoir) |
| Lignes sans prix unitaire | 340 | imputer par la médiane du produit sur l'année, **signaler** l'imputation |
| En-têtes dont le montant ≠ somme des lignes | 463 (dont 338 dus aux prix manquants) | recalculer depuis les lignes, garder l'écart en colonne |
| Clients en double (e-mail normalisé) | 75 | fusionner vers le plus ancien `client_id` |
| E-mails / codes postaux manquants | 75 / 59 | laisser nuls (pas d'invention) |
| Villes mal écrites | 92 | remplacer par la graphie de référence du code postal |
| Téléphones | 4 formats | normaliser au format international `+33…` |
| SIRET invalides (clé de Luhn) | 26 sur 1 636 | conserver, marquer `siret_valide = false` |
| `satisfaction` en texte | 66 tickets | convertir en entier |

*La **quarantaine** est une table à part où l'on range, avec un motif, les lignes écartées ; **imputer** une valeur, c'est la remplacer par une estimation (ici la **médiane**, la valeur du milieu quand on trie les prix) ; la **clé de Luhn** est un calcul de contrôle qui détecte les erreurs de frappe dans un SIRET ou un numéro de carte.*

> 💡 **À retenir** — Ces seuils rejoignent les dimensions classiques de la qualité : exactitude, complétude, cohérence, **unicité**, fraîcheur et validité. M35 automatisera ces contrôles (tests dbt, Great Expectations, Soda) ; ici, vous apprenez à les **penser**.

```quiz
{
  "q": "Pourquoi le masque de format (chiffres remplacés par 9) est-il plus utile qu'un simple comptage des valeurs distinctes du téléphone ?",
  "options": ["Il regroupe des milliers de numéros en quelques familles d'écriture", "Il est plus rapide à calculer qu'un COUNT DISTINCT sur la colonne", "Il anonymise les numéros de façon conforme au RGPD, sans autre traitement", "Il détecte les numéros invalides auprès de l'opérateur"],
  "answer": 0,
  "explanation": "Les numéros sont presque tous distincts : compter les valeurs ne dit rien. Le masque met en évidence les quatre façons d'écrire un numéro, donc les règles de normalisation à écrire. (Il ne suffit pas à anonymiser : c'est l'objet de M36.)"
}
```

## 2. Nettoyer : la couche silver (20 min)

Trois principes guident chaque règle : **ne rien supprimer en silence** (tout ce qui est écarté va en quarantaine avec un motif), **signaler toute valeur inventée** (colonne `prix_impute`), **rendre l'opération rejouable** (on relit toujours bronze, on réécrit silver entièrement).

```python
# breval/vers_silver.py — bronze -> silver (+ quarantaine)
from pathlib import Path
import duckdb
import polars as pl

BR, SI = Path("data/bronze"), Path("data/silver")
SI.mkdir(parents=True, exist_ok=True)

def luhn_ok(chiffres: str | None) -> bool | None:
    if chiffres is None:
        return None
    if len(chiffres) != 14 or not chiffres.isdigit():
        return False
    total = sum((d * 2 - 9 if d * 2 > 9 else d * 2) if i % 2 else d
                for i, d in enumerate(int(c) for c in reversed(chiffres)))
    return total % 10 == 0

def normaliser_clients(lf: pl.LazyFrame, villes_ref: pl.LazyFrame) -> pl.LazyFrame:
    tel = pl.col("telephone").str.replace_all(r"[^0-9+]", "")
    return (lf.with_columns(
                pl.col("email").str.strip_chars().str.to_lowercase().alias("email"),
                pl.when(tel.str.starts_with("+33")).then(tel)
                  .when(tel.str.starts_with("0") & (tel.str.len_chars() == 10))
                  .then(pl.concat_str([pl.lit("+33"), tel.str.slice(1)]))
                  .otherwise(None).alias("telephone"),
                pl.col("siret").map_elements(luhn_ok, return_dtype=pl.Boolean).alias("siret_valide"))
              .join(villes_ref, on="code_postal", how="left")
              .with_columns(pl.coalesce("ville_ref", pl.col("ville").str.strip_chars()).alias("ville"))
              .drop("ville_ref"))

# --- Clients (Polars) -----------------------------------------------------------
brut = pl.scan_parquet(BR / "clients.parquet")
villes_ref = (brut.filter(pl.col("code_postal").is_not_null())              # graphie la plus fréquente par CP
                  .group_by("code_postal", "ville").len()
                  .sort("len", descending=True)
                  .unique(subset="code_postal", keep="first", maintain_order=True)
                  .select("code_postal", pl.col("ville").alias("ville_ref")))
clients = (normaliser_clients(brut, villes_ref)
           .with_columns(pl.when(pl.col("email").is_null()).then(pl.col("client_id"))
                           .otherwise(pl.col("client_id").min().over("email"))
                           .alias("client_id_maitre"))
           .collect())
correspondance = clients.select("client_id", "client_id_maitre")             # pour re-rattacher les commandes
clients.filter(pl.col("client_id") == pl.col("client_id_maitre")).drop("client_id_maitre") \
       .write_parquet(SI / "clients.parquet")
correspondance.write_parquet(SI / "clients_correspondance.parquet")
# Le fichier de mise à jour reçoit EXACTEMENT le même nettoyage (sinon la SCD 2 verrait de faux changements)
normaliser_clients(pl.scan_parquet(BR / "clients_maj_2026_11_01.parquet"), villes_ref) \
    .collect().write_parquet(SI / "clients_maj_2026_11_01.parquet")

# --- Commandes, lignes, tickets (DuckDB : montants en DECIMAL exact) ----------------
con = duckdb.connect()
con.execute(f"""
CREATE TEMP TABLE commandes AS
SELECT DISTINCT * FROM '{BR}/commandes.parquet';

CREATE TEMP TABLE quarantaine AS
SELECT 'commandes' AS table_source, CAST(commande_id AS VARCHAR) AS cle, 'date_commande future' AS motif
FROM commandes WHERE date_commande >= TIMESTAMP '2026-11-01'
UNION ALL
SELECT 'lignes_commande', CAST(l.ligne_id AS VARCHAR), 'commande en quarantaine'
FROM '{BR}/lignes_commande.parquet' l JOIN commandes c USING (commande_id)
WHERE c.date_commande >= TIMESTAMP '2026-11-01'
UNION ALL
SELECT 'lignes_commande', CAST(l.ligne_id AS VARCHAR), 'quantite negative'
FROM '{BR}/lignes_commande.parquet' l JOIN commandes c USING (commande_id)
WHERE l.quantite < 0 AND c.date_commande < TIMESTAMP '2026-11-01';

CREATE TEMP TABLE lignes AS
SELECT l.*, year(c.date_commande) AS annee
FROM '{BR}/lignes_commande.parquet' l JOIN commandes c USING (commande_id)
WHERE c.date_commande < TIMESTAMP '2026-11-01' AND l.quantite >= 0;
""")
con.execute(f"""
COPY (
  SELECT ligne_id, commande_id, num_ligne, produit_id, quantite,
         coalesce(prix_unitaire_ht,
                  CAST(median(prix_unitaire_ht) OVER (PARTITION BY produit_id, annee) AS DECIMAL(10,2)))
                                       AS prix_unitaire_ht,
         prix_unitaire_ht IS NULL      AS prix_impute,
         remise_pct
  FROM lignes
) TO '{SI}/lignes_commande.parquet' (FORMAT parquet, COMPRESSION zstd);
""")
con.execute(f"""
COPY (
  WITH calc AS (
      SELECT commande_id, CAST(sum(quantite * prix_unitaire_ht * (1 - remise_pct / 100)) AS DECIMAL(12,2)) AS montant
      FROM '{SI}/lignes_commande.parquet' GROUP BY ALL
  )
  SELECT c.commande_id, c.numero, coalesce(m.client_id_maitre, c.client_id) AS client_id,
         c.client_id AS client_id_source, c.agence_id, c.canal, c.statut, c.date_commande,
         c.date_livraison_prevue, coalesce(calc.montant, 0) AS montant_ht,
         c.montant_ht - coalesce(calc.montant, 0) AS ecart_entete_ht,      -- trace de l'incohérence source
         c.mis_a_jour_le
  FROM commandes c
  LEFT JOIN calc USING (commande_id)
  LEFT JOIN '{SI}/clients_correspondance.parquet' m ON m.client_id = c.client_id
  WHERE c.date_commande < TIMESTAMP '2026-11-01'
) TO '{SI}/commandes.parquet' (FORMAT parquet, COMPRESSION zstd);

COPY (
  SELECT * REPLACE (TRY_CAST(satisfaction AS INTEGER) AS satisfaction,
                    CAST(ouvert_le AS TIMESTAMPTZ) AS ouvert_le,
                    CAST(ferme_le AS TIMESTAMPTZ) AS ferme_le)
  FROM '{BR}/tickets_sav.parquet'
) TO '{SI}/tickets_sav.parquet' (FORMAT parquet, COMPRESSION zstd);

COPY quarantaine TO '{SI}/quarantaine.parquet' (FORMAT parquet);
""")
for t in ["agences", "fournisseurs", "produits", "documents"]:                 # déjà propres : copie typée
    con.execute(f"COPY (FROM '{BR}/{t}.parquet') TO '{SI}/{t}.parquet' (FORMAT parquet, COMPRESSION zstd)")
print(con.sql(f"SELECT motif, count(*) FROM '{SI}/quarantaine.parquet' GROUP BY ALL ORDER BY 2 DESC"))
```

> 🔍 **Ce que vous devez voir** — après quelques secondes, un tableau `motif | count_star()` de trois lignes dont les totaux font **213** : environ 171 lignes à quantité négative, 31 lignes rattachées à une commande en quarantaine et 11 commandes à date future (les libellés exacts sont ceux du script). Le dossier `data/silver/` contient alors une dizaine de fichiers Parquet, dont `quarantaine.parquet` et `clients_correspondance.parquet`.

> 🛠️ **Si ça ne marche pas** — « ColumnNotFoundError » ou « SchemaError » côté Polars → votre couche bronze date d'une ancienne version de `vers_bronze.py` : relancez L152 (`python vers_bronze.py`). « TypeError » sur la ligne `def luhn_ok(chiffres: str | None)` → Python antérieur à 3.10 : utilisez le Python 3.12 de votre venv. Un avertissement `PolarsInefficientMapWarning` peut s'afficher à propos de `map_elements` → sans gravité, il rappelle seulement qu'une fonction Python ligne à ligne est plus lente qu'une expression Polars.

Remarquez l'aller-retour entre les deux outils : Polars écrit des Parquet que DuckDB relit aussitôt. Pour éviter même l'écriture, DuckDB peut interroger directement un DataFrame Polars par son **nom de variable** (`con.sql("SELECT count(*) FROM clients")`) et vous rendre un résultat Polars avec `.pl()` : les deux partagent le format mémoire Arrow.

> ⚠️ **Piège fréquent** — Corriger le fichier principal mais pas le fichier de mise à jour. Si `clients_maj` garde « NANTES » alors que silver dit « Nantes », la SCD 2 croit à un déménagement et crée des versions fantômes. Une règle de nettoyage est une **fonction**, appliquée à toutes les entrées de la même entité : d'où `normaliser_clients()`.

> 💡 **Autrement dit** — La couche silver ne cache rien : la commande garde son ancien `client_id` (`client_id_source`) et l'écart entre l'ancien et le nouveau montant (`ecart_entete_ht`) ; la ligne garde l'information « prix imputé ». Un auditeur peut toujours remonter à la source.

## 3. Modéliser : la couche gold (10 min)

> 🧭 **Pré-requis express** — Concrètement : copiez `sql/scd2_dim_client.sql` en `sql/scd2_dim_client_silver.sql` ; dans la copie, remplacez `FROM bz_clients;` par `FROM 'data/silver/clients.parquet';` et `'data/bronze/clients_maj_2026_11_01.parquet'` par `'data/silver/clients_maj_2026_11_01.parquet'`, puis exécutez-la comme en L154 (`duckdb data/breval.duckdb < sql/scd2_dim_client_silver.sql`). Le compteur final doit désormais afficher **5130 | 5050** (et non plus 5205 | 5125) : les 75 doublons fusionnés ont disparu.

Reprenez le script SCD 2 de L154 en remplaçant `bz_clients` par `'data/silver/clients.parquet'` et le fichier de mise à jour par sa version silver, puis construisez les dimensions et le fait :

```sql
-- breval/sql/gold.sql — à exécuter dans data/breval.duckdb après scd2_dim_client.sql (version silver)
CREATE OR REPLACE TABLE dim_produit AS
SELECT produit_id AS produit_sk, sku, libelle, famille, unite, prix_achat_ht, actif,
       attributs ->> '$.norme' AS norme
FROM 'data/silver/produits.parquet';

CREATE OR REPLACE TABLE dim_agence AS FROM 'data/silver/agences.parquet';

CREATE OR REPLACE TABLE dim_date AS
SELECT CAST(strftime(d, '%Y%m%d') AS INTEGER) AS date_sk, CAST(d AS DATE) AS jour,
       year(d) AS annee, quarter(d) AS trimestre, month(d) AS mois, isodow(d) AS jour_semaine_iso,
       weekofyear(d) AS semaine_iso, month(d) IN (8, 12) AS mois_creux_btp
FROM range(DATE '2024-01-01', DATE '2027-01-01', INTERVAL 1 DAY) AS t(d);

CREATE OR REPLACE TABLE fait_ventes AS
SELECT l.ligne_id, CAST(strftime(c.date_commande, '%Y%m%d') AS INTEGER) AS date_sk,
       d.client_sk, l.produit_id AS produit_sk, c.agence_id, c.canal, c.numero AS numero_commande,
       l.quantite, l.prix_impute,
       CAST(round(l.quantite * l.prix_unitaire_ht * (1 - l.remise_pct / 100), 2) AS DECIMAL(12,2))                        AS ca_ht,
       CAST(round(l.quantite * (l.prix_unitaire_ht * (1 - l.remise_pct / 100) - p.prix_achat_ht), 2) AS DECIMAL(12,2))     AS marge_ht
FROM 'data/silver/lignes_commande.parquet' l
JOIN 'data/silver/commandes.parquet' c USING (commande_id)
JOIN dim_produit p ON p.produit_sk = l.produit_id
JOIN dim_client d ON d.client_id = c.client_id
                 AND c.date_commande >= d.valide_du AND c.date_commande < d.valide_au
WHERE c.statut IN ('livree', 'facturee');

COPY fait_ventes TO 'data/gold/fait_ventes.parquet' (FORMAT parquet, COMPRESSION zstd);
COPY dim_client  TO 'data/gold/dim_client.parquet'  (FORMAT parquet, COMPRESSION zstd);
COPY dim_produit TO 'data/gold/dim_produit.parquet' (FORMAT parquet, COMPRESSION zstd);
COPY dim_date    TO 'data/gold/dim_date.parquet'    (FORMAT parquet, COMPRESSION zstd);
COPY dim_agence  TO 'data/gold/dim_agence.parquet'  (FORMAT parquet, COMPRESSION zstd);
```

Créez le dossier `data/gold` avant d'exécuter les `COPY` (`mkdir -p data/gold`).

> 🔍 **Ce que vous devez voir** — aucune sortie pour les `CREATE` et `COPY` (ou un nombre de lignes par ordre selon le client utilisé), puis cinq fichiers dans `data/gold/` : `fait_ventes.parquet`, `dim_client.parquet`, `dim_produit.parquet`, `dim_date.parquet`, `dim_agence.parquet`. `dim_date` compte 1 096 jours (2024, 2025 et 2026).

> 🛠️ **Si ça ne marche pas** — « IO Error: Cannot open file "data/gold/fait_ventes.parquet": No such file or directory » → le dossier `data/gold` n'existe pas encore : `mkdir -p data/gold` (PowerShell : `mkdir data\gold`) puis relancez. « Table with name dim_client does not exist » → la version silver du script SCD 2 n'a pas été exécutée **dans le même fichier** `data/breval.duckdb`.

## 4. Réconcilier : la preuve que rien ne s'est perdu (5 min)

> 🧭 **Pré-requis express** — **Réconcilier**, c'est comparer des totaux entre deux étapes du pipeline (lignes en entrée = lignes en sortie + lignes écartées) : le contrôle le plus simple, et le plus utile, d'un data engineer.

```sql
-- breval/sql/controles.sql — chaque ligne doit afficher ok = true
SELECT 'commandes : bronze dédoublonné = silver + quarantaine' AS controle,
       (SELECT count(DISTINCT commande_id) FROM 'data/bronze/commandes.parquet')
     = (SELECT count(*) FROM 'data/silver/commandes.parquet')
     + (SELECT count(*) FROM 'data/silver/quarantaine.parquet' WHERE table_source = 'commandes') AS ok
UNION ALL
SELECT 'lignes : bronze = silver + quarantaine',
       (SELECT count(*) FROM 'data/bronze/lignes_commande.parquet')
     = (SELECT count(*) FROM 'data/silver/lignes_commande.parquet')
     + (SELECT count(*) FROM 'data/silver/quarantaine.parquet' WHERE table_source = 'lignes_commande')
UNION ALL
SELECT 'clients silver uniques par e-mail',
       (SELECT count(*) FROM 'data/silver/clients.parquet' WHERE email IS NOT NULL)
     = (SELECT count(DISTINCT email) FROM 'data/silver/clients.parquet')
UNION ALL
SELECT 'CA gold = CA silver livré ou facturé',
       (SELECT sum(ca_ht) FROM fait_ventes)
     = (SELECT sum(CAST(round(l.quantite * l.prix_unitaire_ht * (1 - l.remise_pct / 100), 2) AS DECIMAL(12,2)))
        FROM 'data/silver/lignes_commande.parquet' l JOIN 'data/silver/commandes.parquet' c USING (commande_id)
        WHERE c.statut IN ('livree', 'facturee'));
```

> 🧭 **Pré-requis express** — Exécutez ce fichier dans la base qui contient `fait_ventes` : `duckdb data/breval.duckdb < sql/controles.sql` (ou via Python, comme en L154).

> 🔍 **Ce que vous devez voir** — un tableau de **quatre lignes** `controle | ok`, toutes à `true`.

> 🛠️ **Si ça ne marche pas** — Une ligne à `false` sur les commandes ou les lignes → `vers_silver.py` a été modifié ou la bronze a été régénérée entre-temps : relancez la chaîne dans l'ordre. `false` sur les clients → l'e-mail n'a pas été normalisé (minuscules, espaces) dans votre version de `normaliser_clients()`. `ok` vide (`NULL`) sur le CA → une des sommes est nulle, signe que `fait_ventes` est vide : vérifiez la jointure avec `dim_client` (valeurs 5 130 / 5 050).

Valeurs de référence : **119 989** commandes et **334 951** lignes en silver, **213** enregistrements en quarantaine (11 commandes, 31 lignes rattachées, 171 quantités négatives), **5 000** clients (75 doublons fusionnés, 1 744 commandes re-rattachées), `dim_client` à **5 130** versions dont **5 050** courantes, et **319 140** lignes dans `fait_ventes`.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : si le contrôle « CA gold = CA silver » est vrai, on peut affirmer que le chiffre d'affaires est exact.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : le contrôle prouve que la modélisation n'a rien perdu ni doublé entre silver et gold. Il ne dit rien de l'exactitude des données source (prix imputés, en-têtes incohérents). C'est pourquoi on garde prix_impute et ecart_entete_ht, et pourquoi M35 ajoute des tests de qualité sur la source."
}
```

```mission
{
  "title": "Les cinq piliers de l'observabilité des données",
  "url": "https://datadriven.io/data-observability",
  "steps": ["Ouvrez l'article « Data Observability: 5 Pillars and Tools »", "Repérez la liste des cinq piliers", "Associez à chacun un contrôle que vous avez écrit dans cet atelier"],
  "question": "Quels sont les cinq piliers de l'observabilité des données cités, et lequel vos contrôles de réconciliation couvrent-ils principalement ?",
  "hint": "L'un d'eux s'appelait autrefois « distribution ».",
  "answer": "Fraîcheur, volume, schéma, qualité (ex-« distribution ») et lignage (article consulté en nov. 2026) ; les contrôles de réconciliation couvrent surtout le volume (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne** — Exécutez la chaîne complète `generer_breval.py → vers_bronze.py → vers_silver.py → scd2_dim_client.sql (silver) → gold.sql → controles.sql`, puis : (1) ajoutez une règle silver pour les tickets dont `ferme_le` est antérieur à `ouvert_le` (comptez-les, décidez) ; (2) écrivez la requête gold « marge brute par famille et par agence en 2025, hors prix imputés » ; (3) relancez toute la chaîne à l'échelle 10, dans la copie `breval-x10/` de L152 (le dossier `breval/` doit rester à l'échelle 1 pour la suite du niveau), et notez le temps de chaque étape ; (4) rédigez un « journal de nettoyage » d'une page : règle, nombre de lignes concernées, justification métier.

**Critères de réussite** — Tous les contrôles affichent `ok = true` ; les valeurs de référence sont retrouvées à l'échelle 1 ; le journal liste au moins huit règles ; le temps de bout en bout à l'échelle 10 est mesuré (il servira de point de comparaison en L160).

**Pistes de corrigé** — (1) Le générateur n'en produit pas : le contrôle doit renvoyer 0, et c'est une bonne nouvelle **documentée** (un contrôle qui ne trouve rien a quand même de la valeur). (2) `SELECT p.famille, f.agence_id, sum(marge_ht) FROM fait_ventes f JOIN dim_produit p USING (produit_sk) JOIN dim_date d USING (date_sk) WHERE d.annee = 2025 AND NOT f.prix_impute GROUP BY ALL`.

## ✅ Auto-évaluation express
1. Pourquoi mettre en quarantaine plutôt que supprimer ?
2. Pourquoi appliquer `normaliser_clients()` au fichier de mise à jour ?
3. Que prouve, et que ne prouve pas, un contrôle de réconciliation ?

**Réponses** — 1. Pour pouvoir expliquer, corriger à la source et réintégrer : une ligne supprimée en silence fausse les totaux sans laisser de trace. 2. Pour que les deux sources d'une même entité soient comparables ; sinon la SCD 2 détecte de faux changements. 3. Il prouve qu'aucune ligne n'a été perdue ou dupliquée entre deux couches ; il ne prouve pas que la donnée source est juste.

## 📚 Pour aller plus loin
- [Polars — documentation](https://docs.pola.rs/) 🇬🇧 — expressions, API lazy, fonctions sur chaînes.
- [DuckDB 2.0 — Integration with Polars](https://duckdb.org/docs/2.0/guides/python/polars.html) 🇬🇧 — interroger un DataFrame Polars par son nom, `.pl()`.
- [DataDriven — Data Observability](https://datadriven.io/data-observability) 🇬🇧 — les cinq piliers, préparation de M35.
- [Répertoire Sirene (INSEE)](https://www.sirene.fr/) — référence officielle des SIREN/SIRET, pour vérifier qu'un identifiant valide existe vraiment.

> ✅ **Si vous ne retenez que 3 choses** — 1. Profiler avant de corriger : on mesure chaque défaut et on note une décision par défaut (supprimer, quarantaine, imputer en le signalant, normaliser). 2. La couche silver ne supprime rien en silence : quarantaine avec motif, colonnes de traçabilité (`prix_impute`, `client_id_source`, `ecart_entete_ht`), et une même fonction de nettoyage appliquée à toutes les entrées d'une entité. 3. Un contrôle de réconciliation (bronze = silver + quarantaine, CA gold = CA silver) prouve qu'aucune ligne ne s'est perdue ; il ne prouve pas que la source est juste.

> 🗺️ **Et maintenant ?** — Vos couches bronze, silver et gold vivent dans un dossier local ; le module M32 les installe dans un vrai lakehouse : stockage objet, formats de table ouverts avec historique, et moteurs capables de passer à l'échelle.
