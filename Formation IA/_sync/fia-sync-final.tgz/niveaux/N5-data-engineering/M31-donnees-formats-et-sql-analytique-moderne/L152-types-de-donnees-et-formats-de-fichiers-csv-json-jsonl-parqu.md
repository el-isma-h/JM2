---
id: L152
module: M31
level: N5
title: "Types de données et formats de fichiers : CSV, JSON/JSONL, Parquet, Avro, ORC, Arrow — mesurer taille et vitesse"
minutes: 55
objectives:
  - "Classer une donnée (structurée, semi-structurée, non structurée, flux, vecteur) et en déduire les contrôles à prévoir"
  - "Expliquer la différence entre stockage orienté lignes et orienté colonnes, et le fonctionnement interne d'un fichier Parquet (row groups, statistiques, encodages, compression)"
  - "Générer de façon reproductible le jeu de données Bréval Matériaux et le convertir en couche bronze Parquet typée avec DuckDB"
  - "Mesurer et comparer la taille et le temps de lecture d'un même jeu de données en CSV, JSONL, Parquet, ORC, Arrow IPC et Avro, et choisir un format selon l'usage"
skills: ["C5.1"]
sources:
  - { title: "DuckDB 2.0 — Integration with Polars", url: "https://duckdb.org/docs/2.0/guides/python/polars.html", lang: "en" }
  - { title: "Apache Parquet — documentation", url: "https://parquet.apache.org/", lang: "en" }
  - { title: "Apache Avro — documentation", url: "https://avro.apache.org/", lang: "en" }
  - { title: "Apache ORC", url: "https://orc.apache.org/", lang: "en" }
  - { title: "Apache Arrow", url: "https://arrow.apache.org/", lang: "en" }
  - { title: "UPPMAX LLM workshop — Data pipelines (formats et sharding)", url: "https://uppmax.github.io/LLM-workshop/day2/data_pipelines", lang: "en" }
  - { title: "O'Reilly — Fundamentals of Data Engineering (annexe sérialisation et compression)", url: "https://oreilly.com/library/view/fundamentals-of-data/9781098108298", lang: "en" }
  - { title: "Python — module zoneinfo", url: "https://docs.python.org/3/library/zoneinfo.html", lang: "en" }
---

# Types de données et formats de fichiers : CSV, JSON/JSONL, Parquet, Avro, ORC, Arrow

> ⏱ 55 min · 🎯 Niveau 5 · 📚 Module 31

## 🎯 Ce que vous saurez faire
- Dire en dix secondes si une donnée est structurée, semi-structurée, non structurée, un flux ou un vecteur, et ce que cela implique.
- Expliquer pourquoi un fichier Parquet est souvent plusieurs fois plus petit qu'un CSV et pourquoi une requête n'en lit qu'une partie.
- Générer le jeu Bréval Matériaux à l'identique sur n'importe quelle machine, puis construire sa **couche bronze** en Parquet.
- Mesurer vous-même taille et vitesse de six formats, au lieu de croire les benchmarks des autres.

> 🧭 **En clair** — Imaginez deux façons de ranger les fiches d'un fichier clients. Dans un classeur « par ligne », chaque fiche contient tout sur un client : pour connaître le chiffre d'affaires total, vous devez feuilleter toutes les fiches en entier. Dans un meuble « par colonne », un tiroir contient tous les montants, un autre toutes les villes : pour le total, vous n'ouvrez qu'un tiroir, et comme les montants se ressemblent, on peut les ranger serrés. CSV et JSON sont des classeurs par ligne, lisibles par un humain ; Parquet est le meuble à tiroirs, illisible à l'œil nu mais imbattable pour l'analyse. Avro sert surtout à faire voyager des messages, Arrow à partager les tiroirs entre programmes sans les recopier.

## 1. Cinq familles de données

| Famille | Exemples chez Bréval | Ce qu'il faut prévoir |
|---|---|---|
| Structurée | tables de l'ERP (`commandes`, `clients`) | schéma explicite, contraintes, contrôles simples |
| Semi-structurée | `tickets_sav.jsonl`, colonne `produits.attributs` | schéma implicite qui **dérive** (le champ `agent` apparaît en juin 2025), aplatissement (*flattening*) : transformer des objets imbriqués en colonnes simples |
| Non structurée | procédures, fiches techniques, CGV | extraction de texte, métadonnées, données personnelles ; matière première des RAG |
| Flux (événements) | changements de statut des commandes en temps réel (M34) | temps d'événement ≠ temps de traitement, ordre, doublons |
| Vectorielle | embeddings des documents (M36) | dimension, modèle d'origine, version, ré-indexation |

Réponse au défi de L151 : les tables ERP sont structurées, les tickets et la colonne `attributs` semi-structurés, les documents non structurés (même s'ils ont des métadonnées structurées dans `documents.csv`).

> 💡 **À retenir** — Une même information change de famille au cours du pipeline : un PDF (non structuré) devient des *chunks* avec métadonnées (semi-structuré), puis des vecteurs. Le data engineer choisit le bon format **à chaque étape**.

## 2. Générer le jeu de données Bréval (reproductible)

Le script ci-dessous n'utilise **que la bibliothèque standard** de Python 3.12+ : pas de dépendance dont une nouvelle version changerait les données. Le générateur pseudo-aléatoire `random.Random(graine)` produit la même suite de nombres partout ; les données sont donc identiques au bit près, ce que vérifie le fichier `MANIFEST.json` (nombre de lignes et empreinte SHA-256 : une « empreinte digitale » de 64 caractères qui change dès qu'un seul octet du fichier change de chaque fichier). Enregistrez-le sous `breval/generer_breval.py`.

> 🧭 **Pré-requis express** — Ce script est long (près de 500 lignes) : **vous n'avez pas à le comprendre ligne à ligne**. Copiez-le en entier (bouton « copier » du bloc), collez-le dans un fichier vide de votre éditeur (VS Code par exemple) et enregistrez-le dans le dossier `breval/` créé en L151. Vérifiez que la venv est activée (`(.venv)` en début d'invite) et que vous êtes **dans** `breval/` : la commande `cd breval` ci-dessous suppose que vous êtes dans le dossier parent.

```python
#!/usr/bin/env python3
"""generer_breval.py — jeu de données fil rouge du niveau 5 (Bréval Matériaux, PME fictive).

Bibliothèque standard uniquement (Python 3.12+) : le même --graine et la même --echelle
produisent exactement les mêmes fichiers, sur toutes les machines.

Usage :
    python generer_breval.py                      # échelle 1 (≈ 120 000 commandes)
    python generer_breval.py --echelle 10         # ≈ 1,2 M commandes (M32 : Spark, Polars lazy)
    python generer_breval.py --sortie data/raw --graine 42

Sortie (dossier --sortie, par défaut data/raw) :
    erp/agences.csv, erp/fournisseurs.csv, erp/produits.csv, erp/clients.csv,
    erp/clients_maj_2026-11-01.csv, erp/commandes.csv, erp/lignes_commande.csv
    sav/tickets_sav.jsonl
    documents/documents.csv + documents/md/<doc_id>.md
    MANIFEST.json (paramètres, nombre de lignes et empreinte SHA-256 de chaque fichier)

Les CSV imitent un export d'ERP français : séparateur « ; », décimale « , », UTF-8, dates ISO.
Des défauts de qualité sont injectés VOLONTAIREMENT (doublons, formats, valeurs aberrantes) :
ils servent de terrain d'exercice en L155 (profilage) et en M35 (qualité).
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import unicodedata
from datetime import date, datetime, timedelta
from bisect import bisect_right
from itertools import accumulate
from pathlib import Path
from zoneinfo import ZoneInfo  # Windows : pip install tzdata

VERSION = "1.0.0"
DEBUT, FIN = date(2024, 1, 1), date(2026, 10, 31)   # période des commandes
DATE_MAJ = date(2026, 11, 1)                        # date de l'export de mise à jour clients
PARIS = ZoneInfo("Europe/Paris")

AGENCES = [  # agence_id, nom, ville, code_postal, ouverture, poids
    ("NAN", "Bréval Nantes (siège)", "Nantes", "44000", "1998-03-02", 55),
    ("STN", "Bréval Saint-Nazaire", "Saint-Nazaire", "44600", "2007-09-03", 30),
    ("ANC", "Bréval Ancenis", "Ancenis-Saint-Géréon", "44150", "2016-05-02", 15),
]
VILLES = [  # ville, code postal, agence de rattachement
    ("Nantes", "44000", "NAN"), ("Saint-Herblain", "44800", "NAN"), ("Rezé", "44400", "NAN"),
    ("Orvault", "44700", "NAN"), ("Vertou", "44120", "NAN"), ("Carquefou", "44470", "NAN"),
    ("Bouguenais", "44340", "NAN"), ("Sainte-Luce-sur-Loire", "44980", "NAN"), ("Clisson", "44190", "NAN"),
    ("Machecoul-Saint-Même", "44270", "NAN"), ("Nort-sur-Erdre", "44390", "NAN"), ("Blain", "44130", "NAN"),
    ("Saint-Nazaire", "44600", "STN"), ("La Baule-Escoublac", "44500", "STN"), ("Pornic", "44210", "STN"),
    ("Guérande", "44350", "STN"), ("Pornichet", "44380", "STN"), ("Savenay", "44260", "STN"),
    ("Ancenis-Saint-Géréon", "44150", "ANC"), ("Châteaubriant", "44110", "ANC"),
    ("Cholet", "49300", "ANC"), ("Angers", "49000", "ANC"), ("Redon", "35600", "STN"),
]
PRENOMS = ["Camille", "Louis", "Léa", "Gabriel", "Manon", "Hugo", "Chloé", "Arthur", "Inès", "Jules",
           "Sarah", "Lucas", "Emma", "Nathan", "Jade", "Yanis", "Lina", "Théo", "Zoé", "Adam",
           "Nicolas", "Isabelle", "Thierry", "Sandrine", "Karim", "Fatima", "Pascal", "Nathalie",
           "Erwan", "Gwenaëlle", "Yannick", "Maëlle", "Sébastien", "Aurélie", "Mehdi", "Sophie",
           "Christophe", "Valérie", "Loïc", "Anaïs"]
NOMS = ["Martin", "Bernard", "Thomas", "Petit", "Robert", "Richard", "Durand", "Dubois", "Moreau",
        "Laurent", "Simon", "Michel", "Lefebvre", "Leroy", "Roux", "David", "Bertrand", "Morel",
        "Fournier", "Girard", "Bonnet", "Dupont", "Lambert", "Fontaine", "Rousseau", "Vincent",
        "Muller", "Lefèvre", "Faure", "André", "Mercier", "Blanc", "Guérin", "Boyer", "Garnier",
        "Chevalier", "François", "Legrand", "Gauthier", "Garcia", "Perrin", "Robin", "Clément",
        "Morin", "Nicolas", "Henry", "Roussel", "Mathieu", "Le Gall", "Le Goff", "Guillou",
        "Le Roux", "Tanguy", "Jaouen", "Benali", "Haddad", "Nguyen", "Da Silva", "Ferreira", "Kone"]
METIERS = ["Maçonnerie", "Couverture", "Menuiserie", "Plomberie", "Électricité", "Rénovation",
           "Charpente", "Carrelage", "Peinture", "Terrassement"]
FORMES = ["SARL", "SAS", "EURL", "EI", "SASU"]
DOMAINES = ["exemple.test", "courriel.test", "boite.test"]  # domaines réservés : aucune vraie adresse

# famille: (code, [(article de base, unité, prix de vente HT de référence en €)])
FAMILLES = {
    "gros_oeuvre": ("GRO", [("Ciment CEM II 35 kg", "sac", 9.9), ("Parpaing creux 20x20x50", "piece", 1.7),
                            ("Sable 0/4 big bag 1 t", "piece", 62.0), ("Mortier bâtard 25 kg", "sac", 8.4),
                            ("Treillis soudé ST25 2,4x6 m", "piece", 39.0), ("Gravier 6/10 big bag 1 t", "piece", 68.0),
                            ("Bloc béton cellulaire 20 cm", "piece", 4.6), ("Chaux NHL 3,5 25 kg", "sac", 17.5),
                            ("Palette de parpaings 20 cm (60 u.)", "palette", 98.0)]),
    "bois": ("BOI", [("Chevron sapin 63x75 4 m", "piece", 11.5), ("Panneau OSB3 18 mm", "m2", 9.8),
                     ("Lambourde pin traité 45x70", "ml", 3.1), ("Bastaing 63x175 4 m", "piece", 27.0),
                     ("Contreplaqué peuplier 15 mm", "m2", 21.0), ("Lame de terrasse pin 27x145", "ml", 4.2)]),
    "isolation": ("ISO", [("Laine de verre 100 mm", "m2", 5.2), ("Panneau PSE 80 mm", "m2", 7.9),
                          ("Laine de bois 120 mm", "m2", 16.5), ("Membrane pare-vapeur", "m2", 1.9),
                          ("Laine de roche 140 mm", "m2", 9.4), ("Panneau polyuréthane 60 mm", "m2", 14.0)]),
    "plomberie": ("PLB", [("Tube PER 16 mm", "ml", 1.1), ("Raccord laiton 20x27", "piece", 4.8),
                          ("Mitigeur évier", "piece", 79.0), ("Tube PVC 100 mm 4 m", "piece", 18.0),
                          ("Siphon de douche", "piece", 24.0), ("Vanne d'arrêt 1/4 de tour", "piece", 12.5)]),
    "electricite": ("ELE", [("Câble R2V 3G2,5", "ml", 2.3), ("Gaine ICTA 20 mm", "ml", 0.9),
                            ("Disjoncteur 16 A", "piece", 11.0), ("Tableau électrique 2 rangées", "piece", 69.0),
                            ("Prise 2P+T", "piece", 6.5), ("Interrupteur va-et-vient", "piece", 5.9)]),
    "outillage": ("OUT", [("Truelle 20 cm", "piece", 13.0), ("Niveau à bulle 120 cm", "piece", 39.0),
                          ("Disque diamant 230 mm", "piece", 45.0), ("Brouette 100 L", "piece", 89.0),
                          ("Mètre ruban 5 m", "piece", 9.5), ("Taloche polystyrène", "piece", 7.0)]),
    "peinture": ("PEI", [("Peinture acrylique blanc mat 10 L", "piece", 59.0), ("Sous-couche 15 L", "piece", 69.0),
                         ("Lasure bois 5 L", "piece", 49.0), ("Enduit de lissage 15 kg", "sac", 27.0)]),
    "carrelage": ("CAR", [("Carrelage grès cérame 60x60", "m2", 24.0), ("Colle carrelage C2 25 kg", "sac", 19.0),
                          ("Joint gris 5 kg", "sac", 12.0), ("Faïence murale 20x40", "m2", 19.5),
                          ("Plinthe grès 8x60", "piece", 3.4)]),
}
MARQUES = ["Ouest Bâti", "Atlantis", "Ligéria", "Armor Pro", "Estuaire", "Granit & Co", "Vendée Matériaux", "Nantia"]
GAMMES = ["Éco", "Standard", "Pro", "Premium", "Chantier", "Expert"]
NORMES = {"gros_oeuvre": "NF EN 197-1", "bois": "NF EN 14081", "isolation": "NF EN 13162",
          "plomberie": "NF EN ISO 15875", "electricite": "NF C 15-100", "carrelage": "NF EN 14411"}
PROCEDURES = ["Notes de frais", "Retour fournisseur", "Accueil d'un nouveau salarié", "Consigne sécurité chariot élévateur",
              "Gestion des avoirs client", "Ouverture de compte professionnel", "Inventaire annuel", "Litiges transport",
              "Réclamation client (SAV)", "Encaissement comptoir", "Relance des impayés", "Commande spéciale hors catalogue",
              "Location de matériel", "Livraison sur chantier", "Gestion des palettes consignées", "Congés et absences",
              "Télétravail (fonctions support)", "Prévention des chutes en dépôt", "Tri et valorisation des déchets",
              "Traitement des données personnelles clients", "Charte informatique", "Gestion des clés et badges",
              "Contrôle des livraisons fournisseurs", "Tarification des professionnels", "Remises exceptionnelles",
              "Ouverture et fermeture d'agence", "Plan de continuité d'activité", "Achats responsables",
              "Carte carburant", "Utilisation de l'assistant IA interne"]
SERVICES_PRC = ["rh", "logistique", "rh", "qualite", "commerce", "commerce", "logistique", "logistique",
                "commerce", "commerce", "direction", "commerce", "logistique", "logistique", "logistique", "rh",
                "rh", "qualite", "qualite", "direction", "direction", "direction", "logistique", "commerce",
                "direction", "direction", "direction", "direction", "rh", "direction"]
CATEGORIES_SAV = {  # catégorie: (poids, gabarits du premier message client)
    "casse": (25, ["Bonjour, sur la commande {cmd}, {n} unités de « {prod} » sont arrivées cassées.",
                   "Livraison {cmd} : produit « {prod} » abîmé, je demande un remplacement."]),
    "retard": (22, ["Ma commande {cmd} devait être livrée le {prev}, toujours rien.",
                    "Le chantier attend la commande {cmd}, pouvez-vous me donner une date ?"]),
    "erreur_produit": (15, ["Je n'ai pas reçu « {prod} » mais une autre référence (commande {cmd}).",
                            "Erreur de référence sur {cmd}, il manque {n} unités."]),
    "facturation": (18, ["La facture de la commande {cmd} ne tient pas compte de ma remise.",
                         "Montant facturé incorrect pour {cmd}, merci de vérifier."]),
    "retour": (12, ["Je souhaite retourner {n} unités de « {prod} » non utilisées (commande {cmd}).",
                    "Retour possible pour « {prod} » ? Le chantier est terminé."]),
    "autre": (8, ["Bonjour, avez-vous « {prod} » en stock à l'agence ?",
                  "Question sur mon compte client, merci de me rappeler."]),
}
REPONSES_AGENT = ["Bonjour, nous avons bien reçu votre demande et revenons vers vous sous 48 h.",
                  "Nous avons vérifié avec l'entrepôt : un remplacement part demain.",
                  "Un avoir a été émis sur votre compte, il apparaîtra sur votre prochain relevé.",
                  "Pouvez-vous nous envoyer une photo du produit et du bon de livraison ?",
                  "Le transporteur confirme une livraison sous 2 jours ouvrés.",
                  "Votre demande est clôturée, merci de votre confiance."]
FERIES = {(1, 1), (5, 1), (5, 8), (7, 14), (8, 15), (11, 1), (11, 11), (12, 25)}  # fériés fixes : agences fermées
POIDS_MOIS = [6, 7, 9, 10, 11, 11, 10, 6, 10, 9, 7, 4]    # saisonnalité du BTP (août et décembre creux)


def sans_accents(texte: str) -> str:
    """« Gwenaëlle Guérin » -> « gwenaelle-guerin » (pour fabriquer des adresses e-mail plausibles)."""
    nfkd = unicodedata.normalize("NFKD", texte)
    return "".join(c for c in nfkd if not unicodedata.combining(c)).lower().replace(" ", "-").replace("'", "")


def luhn_ok(chiffres: str) -> bool:
    total = 0
    for i, c in enumerate(reversed(chiffres)):
        d = int(c) * (2 if i % 2 else 1)
        total += d - 9 if d > 9 else d
    return total % 10 == 0


def siret(rng: random.Random, valide: bool = True) -> str:
    base = "".join(str(rng.randint(0, 9)) for _ in range(13))
    for c in "0123456789":                         # dernier chiffre choisi pour respecter Luhn
        if luhn_ok(base + c) == valide:
            return base + c
    return base + "0"


def telephone(rng: random.Random) -> str:
    """Numéros fictifs (plages 02 61 91 et 06 39 98), écrits de 4 façons différentes (défaut volontaire)."""
    prefixe = rng.choice(["0261 91", "0639 98"]).replace(" ", "")
    num = prefixe + f"{rng.randint(0, 9999):04d}"
    paires = " ".join(num[i:i + 2] for i in range(0, 10, 2))
    return rng.choices([paires, num, "+33 " + paires[1:], paires.replace(" ", ".")], [55, 20, 15, 10])[0]


def jour_ouvre(rng: random.Random, apres: date, avant: date) -> date:
    """Tire une date selon la saisonnalité, du lundi au samedi (le samedi est rare)."""
    while True:
        d = apres + timedelta(days=rng.randint(0, (avant - apres).days))
        if d.weekday() == 6 or (d.month, d.day) in FERIES or (d.weekday() == 5 and rng.random() > 0.35):
            continue
        croissance = 1 + 0.08 * (d.year - 2024)          # +8 %/an d'activité
        if rng.random() * 11 * 1.2 <= POIDS_MOIS[d.month - 1] * croissance:
            return d


class Ecrivain:
    """Écrit les CSV « façon ERP » (séparateur ;, décimale ,) et compte les lignes."""
    def __init__(self, racine: Path):
        self.racine, self.comptes = racine, {}

    def csv(self, nom: str, entetes: list[str], lignes) -> None:
        chemin = self.racine / nom
        chemin.parent.mkdir(parents=True, exist_ok=True)
        n = 0
        with chemin.open("w", encoding="utf-8", newline="") as f:
            w = csv.writer(f, delimiter=";", lineterminator="\n")
            w.writerow(entetes)
            for ligne in lignes:
                w.writerow(["" if v is None else (f"{v:.2f}".replace(".", ",") if isinstance(v, float) else v)
                            for v in ligne])
                n += 1
        self.comptes[nom] = n


def generer(sortie: Path, echelle: float, graine: int) -> dict:
    rng = random.Random(graine)
    out = Ecrivain(sortie)
    n_clients, n_commandes = int(5000 * echelle), int(120000 * echelle)

    # 1. Agences et fournisseurs --------------------------------------------------
    out.csv("erp/agences.csv", ["agence_id", "nom", "ville", "code_postal", "date_ouverture"],
            [a[:5] for a in AGENCES])
    fournisseurs = []
    racines = ["Ciments", "Bois", "Isolants", "Matériaux", "Négoce", "Fixations", "Sanitaires", "Couleurs"]
    regions = ["de l'Ouest", "Atlantique", "du Val de Loire", "Bretagne", "Europe", "Industrie", "Distribution"]
    for i in range(1, 61):
        pays = rng.choices(["FR", "DE", "ES", "IT", "BE", "PT"], [70, 10, 7, 5, 5, 3])[0]
        fournisseurs.append((i, f"{rng.choice(racines)} {rng.choice(regions)} {i:02d}", pays,
                             rng.randint(2, 6) if pays == "FR" else rng.randint(5, 21)))
    out.csv("erp/fournisseurs.csv", ["fournisseur_id", "nom", "pays", "delai_moyen_jours"], fournisseurs)

    # 2. Produits (catalogue fixe : 1 200 articles, indépendant de l'échelle) -----
    produits, pid = [], 0
    fam_liste = list(FAMILLES)
    while len(produits) < 1200:
        fam = fam_liste[pid % len(fam_liste)]
        code, articles = FAMILLES[fam]
        pid += 1
        (base, unite, prix_ref), gamme = rng.choice(articles), rng.choice(GAMMES)
        coef = {"Éco": 0.8, "Standard": 1.0, "Chantier": 0.95, "Pro": 1.15, "Premium": 1.4, "Expert": 1.5}[gamme]
        prix = round(prix_ref * coef * rng.uniform(0.9, 1.1), 2)
        attributs = {"poids_kg": round(rng.uniform(0.1, 40), 1), "conditionnement": rng.choice([1, 5, 10, 25, 50])}
        if fam in NORMES:
            attributs["norme"] = NORMES[fam]
        if fam == "bois":                                # schéma JSON qui varie selon la famille
            attributs["essence"] = rng.choice(["sapin", "pin", "douglas", "peuplier"])
            attributs["classe_emploi"] = rng.choice([2, 3, 4])
        if fam == "isolation":
            attributs["lambda_w_mk"] = round(rng.uniform(0.022, 0.040), 3)
        produits.append({
            "produit_id": pid, "sku": f"BRV-{code}-{pid:05d}", "libelle": f"{base} {gamme} {rng.choice(MARQUES)}",
            "famille": fam, "unite": unite, "prix_achat_ht": round(prix * rng.uniform(0.55, 0.78), 2),
            "prix_vente_ht": prix, "taux_tva": 20.0, "fournisseur_id": rng.randint(1, 60),
            "actif": "true" if rng.random() > 0.06 else "false",
            "attributs": json.dumps(attributs, ensure_ascii=False)})
    out.csv("erp/produits.csv", list(produits[0]), (list(p.values()) for p in produits))
    popularite = [1 / (rang + 10) for rang in range(len(produits))]   # loi de type Zipf
    rng.shuffle(popularite)

    # 3. Clients (+ doublons et défauts volontaires) ------------------------------
    clients, emails_vus = [], set()
    for cid in range(1, n_clients + 1):
        seg = rng.choices(["particulier", "artisan", "entreprise_btp", "collectivite"], [65, 25, 8, 2])[0]
        ville, cp, agence = rng.choices(VILLES, [8 if v[2] == "NAN" else 6 for v in VILLES])[0]
        prenom, nom = rng.choice(PRENOMS), rng.choice(NOMS)
        pro = seg != "particulier"
        if seg == "collectivite":
            raison = f"Mairie de {ville}"
        elif pro:
            raison = f"{nom} {rng.choice(METIERS)} {rng.choice(FORMES)}"
        else:
            raison = None
        email = (f"contact@{sans_accents(raison)[:24]}.test" if pro else
                 f"{sans_accents(prenom)}.{sans_accents(nom)}{rng.randint(1, 99)}@{rng.choice(DOMAINES)}")
        if email in emails_vus:                         # homonymes : on rend l'adresse unique
            email = email.replace("@", f".{cid}@")
        emails_vus.add(email)
        creation = date(2010, 1, 1) + timedelta(days=rng.randint(0, (FIN - date(2010, 1, 1)).days))
        if rng.random() < 0.20:
            creation = DEBUT + timedelta(days=rng.randint(0, (FIN - DEBUT).days))
        clients.append({
            "client_id": cid, "code_client": f"C{cid:07d}", "type_client": "PRO" if pro else "PART",
            "segment": seg, "raison_sociale": raison, "nom": nom, "prenom": prenom,
            "email": email if (pro or rng.random() > 0.02) else None, "telephone": telephone(rng),
            "siret": siret(rng, rng.random() > 0.02) if pro and seg != "collectivite" else None,
            "code_postal": cp if rng.random() > 0.01 else None,
            "ville": rng.choice([ville.upper(), ville.lower() + " ", ville]) if rng.random() < 0.03 else ville,
            "agence_id": agence, "date_creation": creation.isoformat(),
            "consentement_marketing": "true" if rng.random() < 0.38 else "false",
            "mis_a_jour_le": f"{creation.isoformat()} 09:00:00"})
    for _ in range(int(n_clients * 0.015)):              # 1,5 % de doublons « métier »
        src = dict(rng.choice(clients[:n_clients]))
        src["client_id"] = len(clients) + 1
        src["code_client"] = f"C{src['client_id']:07d}"
        if src["email"]:
            src["email"] = rng.choice([src["email"].upper(), " " + src["email"], src["email"].capitalize()])
        src["telephone"] = telephone(rng)
        clients.append(src)
    cols_clients = list(clients[0])
    out.csv("erp/clients.csv", cols_clients, (list(c.values()) for c in clients))

    # Export de mise à jour du 1er nov. 2026 : ~4 % de clients modifiés + 1 % de nouveaux (MERGE, SCD2)
    maj = []
    for c in rng.sample(clients[:n_clients], int(n_clients * 0.04)):
        c2 = dict(c)
        changement = rng.choice(["demenagement", "segment", "telephone", "consentement"])
        if changement == "demenagement":
            c2["ville"], c2["code_postal"], c2["agence_id"] = rng.choice(VILLES)
        elif changement == "segment" and c2["segment"] == "particulier":
            c2["segment"], c2["type_client"] = "artisan", "PRO"
            c2["raison_sociale"], c2["siret"] = f"{c2['nom']} {rng.choice(METIERS)} EI", siret(rng)
        elif changement == "telephone":
            c2["telephone"] = telephone(rng)
        else:
            c2["consentement_marketing"] = "false" if c2["consentement_marketing"] == "true" else "true"
        c2["mis_a_jour_le"] = f"{DATE_MAJ.isoformat()} 06:{rng.randint(0, 59):02d}:00"
        maj.append(c2)
    for k in range(int(n_clients * 0.01)):
        c2 = dict(rng.choice(clients[:n_clients]))
        c2["client_id"] = len(clients) + k + 1
        c2["code_client"] = f"C{c2['client_id']:07d}"
        c2["nom"], c2["prenom"] = rng.choice(NOMS), rng.choice(PRENOMS)
        c2["date_creation"], c2["mis_a_jour_le"] = DATE_MAJ.isoformat(), f"{DATE_MAJ.isoformat()} 06:00:00"
        maj.append(c2)
    out.csv("erp/clients_maj_2026-11-01.csv", cols_clients, (list(c.values()) for c in maj))

    # 4. Commandes et lignes -------------------------------------------------------
    # Les dates sont tirées d'abord puis triées : commande_id croît avec le temps (comme dans un vrai ERP),
    # ce qui permet le chargement incrémental (M33) et la capture de changements (M34).
    clients_tries = sorted(clients, key=lambda c: (c["date_creation"], c["client_id"]))
    creations = [c["date_creation"] for c in clients_tries]
    cum_clients = list(accumulate(6 if c["type_client"] == "PRO" else 1 for c in clients_tries))  # les pros commandent plus
    cum_produits = list(accumulate(popularite))
    tirages = []
    for _ in range(n_commandes):
        d = jour_ouvre(rng, DEBUT, FIN)
        k = bisect_right(creations, d.isoformat())       # seuls les clients déjà créés peuvent commander
        cli = clients_tries[bisect_right(cum_clients, rng.random() * cum_clients[k - 1], 0, k - 1)]
        tirages.append((datetime(d.year, d.month, d.day, rng.randint(7, 17), rng.randint(0, 59), rng.randint(0, 59)),
                        cli["client_id"]))
    tirages.sort()
    par_id = {c["client_id"]: c for c in clients}
    commandes, seq = [], {}
    QTE = {"sac": (5, 1), "palette": (0.6, 1), "piece": (5, 1), "m2": (12, 2), "ml": (10, 2)}  # (moyenne, minimum)

    def lignes_de_commande():
        """Génère les commandes (gardées en mémoire, compactes) et produit les lignes une à une :
        les lignes sont écrites au fil de l'eau, sans tout garder en mémoire (échelle 50 sur 8 Go)."""
        ligne_id = 0
        for cmd_id, (ts, client_id) in enumerate(tirages, start=1):
            cli, d = par_id[client_id], ts.date()
            pro = cli["type_client"] == "PRO"
            canal = rng.choices(["comptoir", "telephone", "web", "commercial"],
                                [40, 20, 10 + 5 * (d.year - 2024), 25 if pro else 0])[0]
            age = (FIN - d).days
            statut = (rng.choices(["brouillon", "validee"], [30, 70])[0] if age < 3 else
                      rng.choices(["validee", "livree"], [40, 60])[0] if age < 12 else
                      rng.choices(["facturee", "annulee", "livree"], [92, 4, 4])[0])
            seq[d.year] = seq.get(d.year, 0) + 1
            montant = 0.0
            for num in range(1, min(12, 1 + int(rng.expovariate(1 / (2.6 if pro else 1.3)))) + 1):
                p = rng.choices(produits, cum_weights=cum_produits)[0]
                moy, mini = QTE[p["unite"]]
                q = max(mini, int(rng.expovariate(1 / (moy * (1.5 if pro else 1)))) + mini)
                if p["unite"] in ("m2", "ml"):
                    q = round(q + rng.random(), 1)        # surfaces et longueurs décimales
                prix = round(p["prix_vente_ht"] * (1 + 0.03 * (d.year - 2024)), 2)   # hausse tarifaire annuelle
                remise = rng.choice([0, 0, 5, 10, 15]) if pro else rng.choice([0] * 9 + [5])
                if rng.random() < 0.0005:
                    q = -q                               # retour saisi en négatif (à investiguer)
                montant += q * prix * (1 - remise / 100)
                ligne_id += 1
                yield [ligne_id, cmd_id, num, p["produit_id"], float(q),
                       None if rng.random() < 0.001 else prix, remise]
            montant = round(montant, 2)
            if rng.random() < 0.001:
                montant = round(montant * 1.2, 2)        # en-tête TTC au lieu de HT (incohérence)
            maj_le = min(ts + timedelta(days=rng.randint(0, 20), hours=rng.randint(0, 8)),
                         datetime(FIN.year, FIN.month, FIN.day, 23, 0, 0))
            horodatage = ts.isoformat(sep=" ")
            if rng.random() < 0.0001:
                horodatage = "206" + horodatage[3:]      # faute de frappe : 2025 devient 2065
            commandes.append((cmd_id, f"CMD-{d.year}-{seq[d.year]:07d}", client_id,
                              cli["agence_id"] if rng.random() < 0.85 else rng.choice(AGENCES)[0], canal, statut,
                              horodatage, (d + timedelta(days=rng.randint(1, 10))).isoformat(), montant,
                              maj_le.isoformat(sep=" ")))

    out.csv("erp/lignes_commande.csv", ["ligne_id", "commande_id", "num_ligne", "produit_id", "quantite",
                                        "prix_unitaire_ht", "remise_pct"], lignes_de_commande())
    del tirages
    doublons = set(rng.sample(range(n_commandes), int(n_commandes * 0.002)))   # 0,2 % exportées deux fois

    def export_commandes():
        for i, c in enumerate(commandes):
            yield c
            if i in doublons:
                yield c
    out.csv("erp/commandes.csv", ["commande_id", "numero", "client_id", "agence_id", "canal", "statut",
                                  "date_commande", "date_livraison_prevue", "montant_ht", "mis_a_jour_le"],
            export_commandes())

    # 5. Tickets SAV (JSONL semi-structuré, horodatages avec fuseau) ----------------
    (sortie / "sav").mkdir(parents=True, exist_ok=True)
    cats = list(CATEGORIES_SAV)
    n_tickets = 0
    with (sortie / "sav" / "tickets_sav.jsonl").open("w", encoding="utf-8", newline="\n") as f:
        for cmd in commandes:
            if rng.random() > 0.075 or not cmd[6].startswith("202"):
                continue
            n_tickets += 1
            cat = rng.choices(cats, [CATEGORIES_SAV[k][0] for k in cats])[0]
            sans_cmd = cat == "autre" and rng.random() < 0.6
            jour = datetime.fromisoformat(cmd[6]).date() + timedelta(days=rng.randint(1, 15))
            ouvert = datetime(jour.year, jour.month, jour.day, rng.randint(8, 18), rng.randint(0, 59),
                              rng.randint(0, 59), tzinfo=PARIS)   # heure de Paris : +01:00 l'hiver, +02:00 l'été
            texte = rng.choice(CATEGORIES_SAV[cat][1]).format(cmd=cmd[1], n=rng.randint(1, 12),
                                                              prod=rng.choices(produits, cum_weights=cum_produits)[0]["libelle"],
                                                              prev=cmd[7])
            if rng.random() < 0.15:                      # données personnelles dans le texte libre (M36)
                texte += f" Joignable au {telephone(rng)}."
            messages = [{"horodatage": ouvert.isoformat(timespec="seconds"), "auteur": "client", "texte": texte}]
            t = ouvert
            k = rng.randint(0, 3)                        # accusé de réception, puis 0 à 2 échanges
            for texte_agent in ([REPONSES_AGENT[0]] + rng.sample(REPONSES_AGENT[1:5], k - 1) if k else []):
                t += timedelta(hours=rng.randint(1, 72))
                messages.append({"horodatage": t.isoformat(timespec="seconds"), "auteur": "agent", "texte": texte_agent})
            ferme = t + timedelta(hours=rng.randint(1, 48))
            limite = datetime(FIN.year, FIN.month, FIN.day, 23, 0, tzinfo=PARIS)
            statut = "clos" if ferme < limite - timedelta(days=5) else rng.choice(["ouvert", "en_cours", "resolu"])
            if statut == "clos" and k:
                messages.append({"horodatage": ferme.isoformat(timespec="seconds"), "auteur": "agent",
                                 "texte": REPONSES_AGENT[5]})
            sat = rng.choices([1, 2, 3, 4, 5, None], [5, 7, 15, 30, 25, 18])[0] if statut == "clos" else None
            ticket = {
                "ticket_id": f"SAV-{n_tickets:07d}", "client_id": cmd[2], "commande_id": None if sans_cmd else cmd[0],
                "ouvert_le": ouvert.isoformat(timespec="seconds"),
                "ferme_le": ferme.isoformat(timespec="seconds") if statut == "clos" else None,
                "canal": rng.choice(["email", "telephone", "web", "comptoir"]), "categorie": cat,
                "priorite": rng.choices(["basse", "normale", "haute"], [25, 60, 15])[0], "statut": statut,
                "satisfaction": str(sat) if (sat and rng.random() < 0.01) else sat,   # dérive de type
                "messages": messages, "tags": rng.sample(["chantier", "urgent", "pro", "relance", "photo"],
                                                          rng.randint(0, 2))}
            if ouvert.date() >= date(2025, 6, 1):        # dérive de schéma : nouvel outil SAV en juin 2025
                ticket["agent"] = {"id": f"AG{rng.randint(1, 14):02d}", "agence": cmd[3]}
            f.write(json.dumps(ticket, ensure_ascii=False) + "\n")
    out.comptes["sav/tickets_sav.jsonl"] = n_tickets

    # 6. Documents internes (métadonnées + texte Markdown, futur corpus RAG) -------
    docs, md_dir = [], sortie / "documents" / "md"
    md_dir.mkdir(parents=True, exist_ok=True)
    def ajouter(doc_id, titre, typ, service, version, maj, conf, corps):
        contenu = f"# {titre}\n\nVersion {version} — mise à jour le {maj} — service {service}\n\n{corps}\n"
        (md_dir / f"{doc_id}.md").write_text(contenu, encoding="utf-8")
        docs.append([doc_id, f"documents/md/{doc_id}.md", titre, typ, service, version, maj, conf,
                     hashlib.sha256(contenu.encode()).hexdigest(), max(1, len(contenu) // 1800)])
    for i, (titre, service) in enumerate(zip(PROCEDURES, SERVICES_PRC), start=1):
        v = rng.randint(1, 4)
        maj = (date(2022, 1, 1) + timedelta(days=rng.randint(0, 1700))).isoformat()
        corps = (f"## Objet\nCette procédure décrit : {titre.lower()}.\n\n## Responsable\n"
                 f"{rng.choice(PRENOMS)} {rng.choice(NOMS)}, tél. {telephone(rng)}\n\n## Étapes\n" +
                 "\n".join(f"{k}. Étape {k} : vérifier, saisir dans l'ERP, valider par le responsable."
                           for k in range(1, rng.randint(4, 9))))
        conf = "restreint" if service in ("rh", "direction") else "interne"
        ajouter(f"PRC-{i:03d}", f"Procédure — {titre}", "procedure", service, f"v{v}", maj, conf, corps)
        if v > 1 and rng.random() < 0.3:                  # ancienne version restée sur le serveur
            ajouter(f"PRC-{i:03d}-v{v - 1}", f"Procédure — {titre}", "procedure", service, f"v{v - 1}",
                    (date.fromisoformat(maj) - timedelta(days=400)).isoformat(), conf, corps.replace("valider", "signer"))
    for p in sorted(produits, key=lambda p: -popularite[p["produit_id"] - 1])[:80]:
        a = json.loads(p["attributs"])
        corps = (f"## Caractéristiques\n- Référence : {p['sku']}\n- Famille : {p['famille']}\n- Unité : {p['unite']}\n" +
                 "".join(f"- {k} : {v}\n" for k, v in a.items()) +
                 "\n## Mise en œuvre\nRespecter les règles de l'art et la notice du fabricant.\n")
        ajouter(f"FT-{p['sku']}", f"Fiche technique — {p['libelle']}", "fiche_technique", "commerce", "v1",
                (date(2023, 1, 1) + timedelta(days=rng.randint(0, 1300))).isoformat(), "public", corps)
    for annee in (2024, 2025, 2026):
        for cible in ("professionnels", "particuliers"):
            ajouter(f"CGV-{annee}-{cible[:3].upper()}", f"Conditions générales de vente {annee} — {cible}", "cgv",
                    "direction", f"{annee}.1", f"{annee}-01-02", "public",
                    f"## Paiement\nRèglement à {30 if cible == 'professionnels' else 0} jours.\n\n"
                    f"## Pénalités\nTaux de pénalité de retard : trois fois le taux d'intérêt légal.\n")
    for k, sujet in enumerate(["Objectifs commerciaux 2026", "Réorganisation du dépôt de Saint-Nazaire",
                               "Bilan SAV 2025", "Projet d'assistant IA documentaire"], start=1):
        ajouter(f"NOTE-{k:03d}", f"Note interne — {sujet}", "note_interne", "direction", "v1",
                f"2026-0{k + 2}-15", "restreint", f"## Contexte\n{sujet}.\n\n## Décisions\nÀ présenter en comité.\n")
    out.csv("documents/documents.csv", ["doc_id", "chemin", "titre", "type_document", "service", "version",
                                        "date_maj", "confidentialite", "sha256", "nb_pages"], docs)

    # 7. Manifeste : ce qui a été produit, avec quelles options ---------------------
    manifeste = {"generateur": "generer_breval.py", "version": VERSION, "graine": graine, "echelle": echelle,
                 "fichiers": {}}
    for nom, n in sorted(out.comptes.items()):
        contenu = (sortie / nom).read_bytes()
        manifeste["fichiers"][nom] = {"lignes": n, "octets": len(contenu),
                                      "sha256": hashlib.sha256(contenu).hexdigest()}
    (sortie / "MANIFEST.json").write_text(json.dumps(manifeste, indent=2, ensure_ascii=False), encoding="utf-8")
    return manifeste


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Génère le jeu de données Bréval Matériaux (niveau 5).")
    ap.add_argument("--sortie", type=Path, default=Path("data/raw"))
    ap.add_argument("--echelle", type=float, default=1.0, help="1 = 5 000 clients / 120 000 commandes")
    ap.add_argument("--graine", type=int, default=42)
    args = ap.parse_args()
    m = generer(args.sortie, args.echelle, args.graine)
    for nom, info in m["fichiers"].items():
        print(f"{nom:38s} {info['lignes']:>10,d} lignes {info['octets'] / 1e6:>8.1f} Mo")
```

```bash
cd breval && python generer_breval.py            # ≈ 5 s, ≈ 31 Mo dans data/raw
cat data/raw/MANIFEST.json | head -20
```

> 🛠️ **Si ça ne marche pas** — « No such file or directory » → vous êtes déjà dans `breval/` (retirez `cd breval &&`) ou le fichier n'a pas été enregistré à cet endroit. « SyntaxError » dès les premières lignes → la copie est incomplète ou votre Python est antérieur à 3.12 (`python --version`). `cat` ou `head` inconnus sous PowerShell → ouvrez simplement `data/raw/MANIFEST.json` dans votre éditeur.

Sortie attendue (version 1.0.0, graine 42, échelle 1) :

```
documents/documents.csv                       126 lignes      0.0 Mo
erp/agences.csv                                 3 lignes      0.0 Mo
erp/clients.csv                             5,075 lignes      0.8 Mo
erp/clients_maj_2026-11-01.csv                250 lignes      0.0 Mo
erp/commandes.csv                         120,240 lignes     12.9 Mo
erp/fournisseurs.csv                           60 lignes      0.0 Mo
erp/lignes_commande.csv                   335,153 lignes     10.8 Mo
erp/produits.csv                            1,200 lignes      0.2 Mo
sav/tickets_sav.jsonl                       9,048 lignes      7.3 Mo
```

> 🔍 **Ce que vous devez voir** — exactement ces neuf lignes, avec les **mêmes nombres de lignes** (les tailles en Mo peuvent varier d'un dixième). Le manifeste, lui, ressemble à `{"generateur": "generer_breval.py", "version": "1.0.0", "graine": 42, "echelle": 1.0, … "fichiers": {"documents/documents.csv": {"lignes": 126, "octets": …, …}, …}}`. Si un nombre de lignes diffère, ne continuez pas : toutes les leçons suivantes supposent ces chiffres.

Trois choix de conception méritent votre attention, car vous les retrouverez dans de vrais projets :

- **Les dates d'abord, les identifiants ensuite.** Les commandes sont tirées, triées par date, puis numérotées : `commande_id` croît avec le temps, comme dans un ERP réel.
- **Deux conventions d'horodatage.** L'ERP écrit `2025-03-14 10:22:05` (heure de Paris, sans fuseau) ; l'outil SAV écrit `2025-03-14T10:22:05+01:00` (ISO 8601 avec décalage, qui passe à `+02:00` l'été grâce au module `zoneinfo`). Mélanger les deux sans précaution décale des événements d'une ou deux heures.
- **Des défauts mesurables.** Chaque défaut est injecté avec une probabilité fixe : vous saurez en L155 si votre nettoyage les attrape tous.

> ⚠️ **Piège fréquent** — Utiliser `Faker` ou `numpy.random` sans figer la version pour « gagner du temps » : une mise à jour de bibliothèque change les données générées, et les résultats attendus des exercices ne correspondent plus. Pour un jeu de référence partagé, la stabilité prime sur la richesse.

```quiz
{
  "q": "Un collègue relance `generer_breval.py --graine 42` sur son Mac et obtient le même nombre de lignes, mais un SHA-256 différent pour `commandes.csv`. Quelle est l'explication la plus probable ?",
  "options": ["Le SHA-256 change à chaque exécution, c'est tout à fait normal", "Les Mac écrivent les CSV en UTF-16", "Script modifié, autre échelle ou autre version du générateur", "Le générateur dépend de l'heure système"],
  "answer": 2,
  "explanation": "Le script n'utilise ni l'horloge ni de bibliothèque externe : même version, même graine et même échelle donnent les mêmes octets. Un écart d'empreinte signale une différence d'entrée (script modifié, échelle, version) : c'est exactement le rôle du manifeste."
}
```

## 3. Lignes contre colonnes

Un CSV range les valeurs **ligne après ligne** : `1;CMD-2024-0000001;4388;NAN;…` puis la commande suivante. Pour calculer `SUM(montant_ht)`, le moteur doit lire et découper **tout** le fichier, convertir chaque texte en nombre, puis jeter 90 % de ce qu'il a lu.

Un format **colonnaire** range ensemble toutes les valeurs d'une même colonne. Trois bénéfices en découlent :

1. **Projection** (*projection pushdown*) — *pushdown* signifie « pousser le travail vers le stockage » pour lire moins : on ne lit que les colonnes utiles à la requête.
2. **Compression** : une colonne contient des valeurs du même type, souvent répétitives (`statut` n'a que 5 valeurs) : un **encodage par dictionnaire** remplace « facturee » par un petit entier, un encodage **RLE** (*run-length encoding*) écrit « 300 fois la même valeur » en une seule fois. Ces deux astuces sont automatiques : vous n'avez rien à régler.
3. **Saut de blocs** (*predicate pushdown*) : chaque bloc stocke le minimum et le maximum de chaque colonne ; une requête `WHERE date_commande >= '2026-01-01'` saute les blocs dont le maximum est antérieur.

```
CSV (lignes)                      Parquet (colonnes, par row group)
┌────────────────────────────┐    fichier.parquet
│1;CMD-..;4388;NAN;...;8542,7│    ├─ row group 0 (≈ 122 880 lignes)
│2;CMD-..;4702;ANC;...;4746,0│    │   ├─ colonne commande_id  [min=1, max=122880]  pages…
│3;CMD-..;1201;NAN;...; 312,9│    │   ├─ colonne statut       dictionnaire + RLE
│...                         │    │   └─ colonne montant_ht   [min, max, nb de nuls]
└────────────────────────────┘    ├─ row group 1 …
                                  └─ pied de page (footer) : schéma + statistiques
```

> 💡 **Autrement dit** — Parquet découpe le fichier en grandes tranches de lignes (*row groups*), et dans chaque tranche range chaque colonne à part, compressée, avec une petite fiche « valeur mini / valeur maxi ». Le moteur lit d'abord les fiches, puis seulement les tiroirs utiles. Le **pied de page** (*footer*), à la fin du fichier, contient le plan de tout le meuble : le schéma (noms et types des colonnes) et ces fiches min/max.

## 4. Les six formats à connaître

| Format | Nature | Schéma | Points forts | Limites | Usage type |
|---|---|---|---|---|---|
| **CSV** | texte, lignes | aucun (tout est texte) | universel, lisible, Excel | pas de types, séparateur et décimale variables (`;` et `,` en France), encodage | échange ponctuel, exports d'ERP |
| **JSON / JSONL** | texte, semi-structuré | implicite | objets imbriqués, API ; JSONL (un objet par ligne) se lit en flux et se découpe facilement | verbeux, types pauvres (pas de date) | API, logs, prototypage de corpus LLM |
| **Parquet** | binaire, **colonnes** | embarqué dans le pied de page | compression, projection, statistiques par row group | non modifiable en place, petits fichiers coûteux | analytique, lakehouse, jeux d'entraînement |
| **Avro** | binaire, **lignes** | embarqué (JSON), règles d'**évolution de schéma** | sérialisation compacte d'un enregistrement à la fois (*sérialiser* = transformer un objet en suite d'octets pour l'envoyer ou l'écrire) | peu efficace pour l'analytique | messages Kafka + Schema Registry, CDC (M34) |
| **ORC** | binaire, colonnes | embarqué | proche de Parquet, index légers | écosystème surtout Hive / Hadoop | historique Hadoop |
| **Arrow** | **en mémoire**, colonnes (+ fichier IPC/Feather) | embarqué | partage **zéro-copie** (plusieurs programmes lisent la même zone mémoire sans la dupliquer) entre DuckDB, Polars, pandas, Spark | pas conçu pour l'archivage long terme | échanges entre moteurs, cache local |

Pour les corpus d'IA, l'atelier LLM de l'UPPMAX recommande **JSONL pour prototyper et relire**, puis **Parquet ou Arrow en fichiers (*shards*) : morceaux d'un même jeu de données découpé en plusieurs fichiers de 50 à 500 Mo** à l'échelle, toujours accompagnés d'un manifeste de versions. Polars utilise d'ailleurs le format colonnaire d'Arrow comme modèle mémoire, ce qui permet à DuckDB de lui passer un résultat sans recopie (`.pl()`).

```quiz
{
  "q": "Bréval veut publier chaque changement de statut de commande dans Kafka, un message par événement, avec un schéma qui pourra évoluer. Quel format est le plus adapté aux messages ?",
  "options": ["Avro", "CSV", "Parquet", "ORC"],
  "answer": 0,
  "explanation": "Avro sérialise efficacement un enregistrement à la fois et gère l'évolution de schéma (avec un Schema Registry). Parquet et ORC sont faits pour stocker de gros volumes en colonnes, pas pour des messages unitaires."
}
```

## 5. Construire la couche bronze en Parquet

La **couche bronze** conserve la donnée **telle que la source l'a livrée**, mais dans un format typé et compressé. C'est le premier étage de l'**architecture médaillon** (bronze = brut, silver = nettoyé, gold = prêt à consommer), détaillée en L161 (voir le lexique). On n'y corrige rien (c'est le rôle de la couche silver, L155) ; on fixe seulement les types, pour ne pas perdre d'information : un code postal ou un SIRET lu comme nombre perd ses zéros initiaux, un montant « 8542,77 » lu sans préciser la décimale devient du texte.

```python
# breval/vers_bronze.py — data/raw (CSV ; JSONL) -> data/bronze (Parquet zstd), sans rien corriger
from pathlib import Path
import duckdb

RAW, BRONZE = Path("data/raw"), Path("data/bronze")
BRONZE.mkdir(parents=True, exist_ok=True)

# Types imposés : on ne laisse pas le moteur deviner ce qui doit rester du texte.
TYPES = {
    "agences": {"code_postal": "VARCHAR", "date_ouverture": "DATE"},
    "fournisseurs": {},
    "produits": {"prix_achat_ht": "DECIMAL(10,2)", "prix_vente_ht": "DECIMAL(10,2)",
                 "taux_tva": "DECIMAL(4,2)", "actif": "BOOLEAN", "attributs": "VARCHAR"},
    "clients": {"code_postal": "VARCHAR", "siret": "VARCHAR", "telephone": "VARCHAR",
                "date_creation": "DATE", "consentement_marketing": "BOOLEAN", "mis_a_jour_le": "TIMESTAMP"},
    "clients_maj_2026-11-01": {"code_postal": "VARCHAR", "siret": "VARCHAR", "telephone": "VARCHAR",
                               "date_creation": "DATE", "consentement_marketing": "BOOLEAN",
                               "mis_a_jour_le": "TIMESTAMP"},
    "commandes": {"date_commande": "TIMESTAMP", "date_livraison_prevue": "DATE",
                  "montant_ht": "DECIMAL(12,2)", "mis_a_jour_le": "TIMESTAMP"},
    "lignes_commande": {"quantite": "DECIMAL(10,1)", "prix_unitaire_ht": "DECIMAL(10,2)",
                        "remise_pct": "DECIMAL(4,1)"},
}

con = duckdb.connect()
for table, types in TYPES.items():
    struct = "{" + ", ".join(f"'{col}': '{typ}'" for col, typ in types.items()) + "}"
    option_types = f", types = {struct}" if types else ""
    con.execute(f"""
        COPY (SELECT * FROM read_csv('{RAW}/erp/{table}.csv', delim = ';', decimal_separator = ',',
                                     header = true{option_types}))
        TO '{BRONZE}/{table.replace("-", "_")}.parquet' (FORMAT parquet, COMPRESSION zstd)""")

# JSONL : sample_size = -1 force la lecture de TOUT le fichier pour deviner le schéma ;
# sinon un champ apparu tardivement (agent, depuis juin 2025) peut être ignoré à grande échelle.
con.execute(f"""
    COPY (SELECT * FROM read_json('{RAW}/sav/tickets_sav.jsonl', format = 'newline_delimited',
                                  sample_size = -1))
    TO '{BRONZE}/tickets_sav.parquet' (FORMAT parquet, COMPRESSION zstd)""")
con.execute(f"""
    COPY (SELECT * FROM read_csv('{RAW}/documents/documents.csv', delim = ';', header = true,
                                 types = {{'date_maj': 'DATE'}}))
    TO '{BRONZE}/documents.parquet' (FORMAT parquet, COMPRESSION zstd)""")

for f in sorted(BRONZE.glob("*.parquet")):
    n = con.execute(f"SELECT count(*) FROM '{f}'").fetchall()[0][0]   # DuckDB 2.0 : fetchall() clôt le résultat
    print(f"{f.name:32s} {n:>9,d} lignes {f.stat().st_size / 1e6:6.2f} Mo")
print(con.sql(f"DESCRIBE SELECT * FROM '{BRONZE}/tickets_sav.parquet'"))
```

> 🧭 **Pré-requis express** — Enregistrez ce code sous `breval/vers_bronze.py` et lancez-le depuis `breval/` avec `python vers_bronze.py` (venv activée).

> 🔍 **Ce que vous devez voir** — une ligne par fichier Parquet créé dans `data/bronze/`, par exemple `commandes.parquet   120,240 lignes   4.xx Mo` (les tailles exactes dépendent de votre version de DuckDB), puis un tableau `DESCRIBE` avec les colonnes `column_name | column_type | null | …` où l'on reconnaît `messages` en `STRUCT(…)[]` (le `[]` signifie « liste de ») et `satisfaction` en `JSON`.

> 🛠️ **Si ça ne marche pas** — « IO Error: No files found » → vous n'êtes pas dans `breval/` ou l'étape de génération n'a pas été faite. « Could not convert string '8542,77' to DECIMAL » → l'option `decimal_separator = ','` a été modifiée ou retirée de votre copie : recopiez le bloc.

Le `DESCRIBE` final montre que DuckDB a déduit du JSONL des types imbriqués : `messages` devient une liste de `STRUCT(horodatage, auteur, texte)` (un `STRUCT` est un petit objet à champs nommés rangé dans une seule cellule), `agent` un `STRUCT(id, agence)` nul avant juin 2025, et `satisfaction`, qui mélange nombres et textes, un type `JSON` (du texte, pas un entier). Notez-le : la dérive de type est **déjà visible** en bronze.

Regardez maintenant à l'intérieur d'un fichier Parquet :

```sql
-- dans python -c "import duckdb; ..." ou dans le client duckdb
SELECT row_group_id, row_group_num_rows, path_in_schema, compression,
       stats_min_value, stats_max_value, total_compressed_size
FROM parquet_metadata('data/bronze/commandes.parquet')
WHERE path_in_schema IN ('commande_id', 'date_commande', 'statut')
ORDER BY row_group_id, path_in_schema;
```

> 🧭 **Pré-requis express** — Pour exécuter une requête SQL comme celle-ci sans installer d'autre outil, lancez `python` puis tapez `import duckdb` et `duckdb.sql("""…collez la requête…""").show()`. Vous pouvez aussi installer le client en ligne de commande `duckdb` (un seul exécutable, voir duckdb.org) et coller la requête après l'invite `D`.

> 🔍 **Ce que vous devez voir** — un tableau de **3 lignes** à l'échelle 1 (une par colonne demandée, toutes avec `row_group_id = 0`), la compression `ZSTD`, et pour `commande_id` un minimum de `1` et un maximum de l'ordre de `120000`.

Vous verrez un petit nombre de row groups (un seul à l'échelle 1 : DuckDB écrit des row groups d'environ 122 880 lignes ; relancez à l'échelle 10 pour en voir une dizaine), avec pour `date_commande` des intervalles min/max qui **se suivent** (les commandes sont triées par date) : c'est ce qui rend le saut de blocs efficace. Les quelques dates « 206x » placées au milieu élargissent l'intervalle de leur row group : un seul défaut suffit à dégrader le *pruning* d'un bloc entier. (*pruning* = « élagage » : le fait de sauter un bloc sans le lire)

Dernière étape : remplir l'ERP Postgres de L151 (il servira de source en M33 et M34). On repasse par un CSV « standard » (virgule, point décimal) que `psql` sait lire, et on retire au passage les doublons d'export, qu'un ERP ne contiendrait pas :

```bash
mkdir -p data/pg
for t in agences fournisseurs produits clients commandes lignes_commande; do
  python -c "import duckdb; duckdb.sql(\"COPY (SELECT DISTINCT * FROM 'data/bronze/$t.parquet' ORDER BY 1) TO 'data/pg/$t.csv' (HEADER)\")"
  docker exec -i breval-postgres psql -U breval -d breval -c "\copy erp.$t FROM pstdin CSV HEADER" < data/pg/$t.csv
done
docker exec -it breval-postgres psql -U breval -d breval -c "SELECT count(*) FROM erp.commandes"   # 120000
```

> 🔍 **Ce que vous devez voir** — pour chaque table, une ligne `COPY 3`, `COPY 60`, `COPY 1200`, `COPY 5075`… (le nombre de lignes chargées), puis un tableau `count` contenant **120000**. Ce n'est pas une erreur si le générateur annonçait 120 240 commandes : le `SELECT DISTINCT` a retiré les 240 commandes exportées deux fois, qu'un vrai ERP ne contiendrait pas.

> 🛠️ **Si ça ne marche pas** — « duplicate key value violates unique constraint » → vous avez relancé la boucle sur des tables déjà remplies : videz-les avec `docker exec -it breval-postgres psql -U breval -d breval -c "TRUNCATE erp.lignes_commande, erp.commandes, erp.clients, erp.produits, erp.fournisseurs, erp.agences"` puis relancez. « No such container: breval-postgres » → `docker compose up -d` depuis `breval/`. La boucle `for … do … done` et la redirection `<` ne fonctionnent pas dans PowerShell → exécutez-la dans WSL ou Git Bash.

## 6. Mesurer taille et vitesse

Les benchmarks publiés ne valent que pour leurs données. Mesurez sur les vôtres. Installez deux bibliothèques de plus : `pip install fastavro` (pyarrow fournit déjà ORC et Arrow IPC).

```python
# breval/mesurer_formats.py — même table `commandes`, six formats, taille + temps de lecture
import time
from pathlib import Path
import duckdb
import fastavro
import pyarrow.feather as feather
import pyarrow.orc as orc

SRC, OUT = "data/bronze/commandes.parquet", Path("data/formats")
OUT.mkdir(parents=True, exist_ok=True)
con = duckdb.connect()

def chrono(fonction, repetitions: int = 3) -> float:
    meilleur = float("inf")
    for _ in range(repetitions):
        t0 = time.perf_counter(); fonction(); meilleur = min(meilleur, time.perf_counter() - t0)
    return meilleur

# 1. Écriture des variantes
con.execute(f"COPY (FROM '{SRC}') TO '{OUT}/commandes.csv' (FORMAT csv, HEADER)")
con.execute(f"COPY (FROM '{SRC}') TO '{OUT}/commandes.jsonl' (FORMAT json)")       # une ligne JSON par commande
for codec in ("uncompressed", "snappy", "zstd"):
    con.execute(f"COPY (FROM '{SRC}') TO '{OUT}/commandes_{codec}.parquet' (FORMAT parquet, COMPRESSION {codec})")
table = con.sql(f"FROM '{SRC}'").arrow()                                            # table Arrow en mémoire
if hasattr(table, "read_all"):                                                      # certaines versions renvoient un lecteur
    table = table.read_all()
orc.write_table(table, OUT / "commandes.orc")
feather.write_feather(table, OUT / "commandes.arrow", compression="zstd")           # Arrow IPC (Feather v2)
schema = fastavro.parse_schema({"type": "record", "name": "Commande", "fields": [
    {"name": "commande_id", "type": "long"}, {"name": "numero", "type": "string"},
    {"name": "client_id", "type": "long"}, {"name": "agence_id", "type": "string"},
    {"name": "canal", "type": "string"}, {"name": "statut", "type": "string"},
    {"name": "date_commande", "type": "string"}, {"name": "date_livraison_prevue", "type": "string"},
    {"name": "montant_ht", "type": "double"}, {"name": "mis_a_jour_le", "type": "string"}]})
rel = con.sql(f"""SELECT commande_id, numero, client_id, agence_id, canal, statut,
                         CAST(date_commande AS VARCHAR) AS date_commande,
                         CAST(date_livraison_prevue AS VARCHAR) AS date_livraison_prevue,
                         CAST(montant_ht AS DOUBLE) AS montant_ht, CAST(mis_a_jour_le AS VARCHAR) AS mis_a_jour_le
                  FROM '{SRC}'""")
colonnes = rel.columns
with open(OUT / "commandes.avro", "wb") as f:                                       # dates en texte, pour simplifier
    fastavro.writer(f, schema, (dict(zip(colonnes, r)) for r in rel.fetchall()), codec="deflate")

# 2. Une requête analytique typique : CA HT 2025 par agence (2 colonnes sur 10)
REQ = "SELECT agence_id, sum(montant_ht) FROM {src} WHERE date_commande >= '2025-01-01' AND date_commande < '2026-01-01' GROUP BY ALL"
sources = {
    "CSV": f"read_csv('{OUT}/commandes.csv')",
    "JSONL": f"read_json('{OUT}/commandes.jsonl')",
    "Parquet (non compressé)": f"'{OUT}/commandes_uncompressed.parquet'",
    "Parquet snappy": f"'{OUT}/commandes_snappy.parquet'",
    "Parquet zstd": f"'{OUT}/commandes_zstd.parquet'",
}
print(f"{'format':26s} {'taille (Mo)':>11s} {'requête DuckDB (ms)':>20s}")
for nom, src in sources.items():
    chemin = Path(src.split("'")[1])
    duree = chrono(lambda: con.execute(REQ.format(src=src)).fetchall())
    print(f"{nom:26s} {chemin.stat().st_size / 1e6:11.2f} {duree * 1000:20.1f}")

# 3. Lecture complète en mémoire, pour les formats sans lecteur SQL natif dans DuckDB
def lire_avro():
    with open(OUT / "commandes.avro", "rb") as f:
        return sum(1 for _ in fastavro.reader(f))
for nom, fichier, lecture in [("ORC", "commandes.orc", lambda: orc.read_table(OUT / "commandes.orc")),
                              ("Arrow IPC zstd", "commandes.arrow", lambda: feather.read_table(OUT / "commandes.arrow")),
                              ("Avro deflate", "commandes.avro", lire_avro)]:
    print(f"{nom:26s} {(OUT / fichier).stat().st_size / 1e6:11.2f} {'lecture complète':>11s} {chrono(lecture, 1) * 1000:8.1f} ms")
```

> 🔍 **Ce que vous devez voir** — un tableau d'environ huit lignes `format | taille (Mo) | type de mesure | temps (ms)`. Ordre de grandeur attendu à l'échelle 1 : le CSV et le JSONL pèsent plusieurs dizaines de Mo, le Parquet zstd quelques Mo seulement, et la requête SQL sur Parquet prend quelques millisecondes contre plusieurs dizaines (voire centaines) sur CSV. Vos chiffres exacts dépendent de votre machine.

> 🛠️ **Si ça ne marche pas** — « ModuleNotFoundError: No module named 'fastavro' » → `pip install fastavro` dans la venv activée. « No files found » sur `data/bronze/commandes.parquet` → lancez d'abord `vers_bronze.py`.

Ne comparez que ce qui est comparable : les cinq premières lignes du tableau mesurent la **même requête SQL** ; les trois dernières, une lecture **complète** en Python. Sur un portable récent, vous devriez constater que le Parquet zstd pèse **plusieurs fois moins** que le CSV et que la requête y est nettement plus rapide, l'écart grandissant avec `--echelle 10`. Notez vos chiffres réels : ils serviront d'argument chiffré dans votre étude de cas C5.1.

> ⚠️ **Piège fréquent** — Mesurer une seule fois. La première lecture remplit le cache du système d'exploitation et paraît lente ; la fonction `chrono` garde le **meilleur** de trois essais. Pour une mesure « à froid », il faudrait vider le cache, ce qui dépend de votre système.

```mission
{
  "title": "Comment DuckDB renvoie un résultat à Polars",
  "url": "https://duckdb.org/docs/2.0/guides/python/polars.html",
  "steps": ["Ouvrez le guide « Integration with Polars » de la documentation DuckDB 2.0", "Repérez l'exemple qui transforme un résultat DuckDB en DataFrame Polars", "Cherchez l'option qui renvoie un LazyFrame plutôt qu'un DataFrame"],
  "question": "Quelle méthode convertit un résultat DuckDB en objet Polars, et quel paramètre permet d'obtenir un LazyFrame ?",
  "hint": "La méthode tient en deux lettres.",
  "answer": "La méthode .pl() ; avec lazy=True elle renvoie un LazyFrame (doc DuckDB 2.0 consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne** — (1) Générez le jeu à l'échelle 1 et vérifiez votre `MANIFEST.json` contre la sortie attendue. (2) Construisez la couche bronze et chargez Postgres. (3) Lancez `mesurer_formats.py` aux échelles 1 et 10 (l'échelle 10 dans une copie du dossier, pour garder intact le jeu de référence dont dépendent les leçons suivantes : `cp -r breval breval-x10 && cd breval-x10 && python generer_breval.py --echelle 10 && python vers_bronze.py`, comme en L159) et remplissez un tableau « format × taille × temps ». (4) Rédigez en dix lignes une recommandation de format pour chacun de ces usages : export mensuel pour le cabinet comptable, archive des commandes pour l'analytique, messages de changement de statut, corpus de tickets pour un futur fine-tuning.

**Critères de réussite** — Les nombres de lignes correspondent au manifeste ; `erp.commandes` contient 120 000 lignes ; le tableau contient au moins six formats et deux échelles ; chaque recommandation cite au moins un chiffre mesuré.

**Pistes de corrigé** — Comptable : CSV `;` et décimale `,` (c'est ce qu'ouvre Excel en France). Analytique : Parquet zstd, trié par date. Messages : Avro avec schéma versionné. Corpus : JSONL pour relire et annoter, puis Parquet en shards de 50 à 500 Mo une fois le corpus stabilisé.

## ✅ Auto-évaluation express
1. Pourquoi faut-il imposer le type `VARCHAR` au SIRET et au code postal en bronze ?
2. Qu'est-ce qu'un row group, et à quoi servent ses statistiques min/max ?
3. Pourquoi Avro plutôt que Parquet pour un message Kafka ?

**Réponses** — 1. Ce sont des identifiants, pas des nombres : lus comme entiers, ils perdent leurs zéros initiaux et ne peuvent plus être joints ou validés. 2. Une tranche de lignes stockée colonne par colonne ; les min/max permettent de sauter les tranches qui ne peuvent pas contenir de lignes satisfaisant le filtre. 3. Avro est orienté ligne (un enregistrement à la fois), compact et conçu pour l'évolution de schéma ; Parquet n'est efficace que sur de gros lots.

## 📚 Pour aller plus loin
- [Apache Parquet — documentation](https://parquet.apache.org/) 🇬🇧 — spécification, encodages, row groups.
- [Apache Arrow](https://arrow.apache.org/) 🇬🇧 — format colonnaire en mémoire et IPC.
- [Apache Avro](https://avro.apache.org/) 🇬🇧 — schémas et règles d'évolution.
- [UPPMAX — LLM workshop, Data pipelines](https://uppmax.github.io/LLM-workshop/day2/data_pipelines) 🇬🇧 — formats et sharding des corpus d'entraînement.
- [DuckDB 2.0 — Integration with Polars](https://duckdb.org/docs/2.0/guides/python/polars.html) 🇬🇧 — échanges Arrow entre DuckDB et Polars.

> ✅ **Si vous ne retenez que 3 choses** — 1. Les formats texte (CSV, JSON/JSONL) sont lisibles et universels ; les formats colonnaires (Parquet, ORC) sont compacts et rapides pour l'analyse car ils ne lisent que les colonnes et les blocs utiles ; Avro sert aux messages, Arrow aux échanges en mémoire. 2. La couche bronze garde la donnée brute mais **typée** : imposez `VARCHAR` aux identifiants (SIRET, code postal, téléphone) et précisez la décimale française. 3. On ne croit pas les benchmarks des autres : on mesure sur ses propres données, en gardant le meilleur de plusieurs essais.

> 🗺️ **Et maintenant ?** — Vos données dorment en Parquet ; en L153, vous apprenez à les interroger avec le SQL analytique moderne de DuckDB, des fonctions de fenêtre jusqu'à la lecture d'un plan d'exécution.
