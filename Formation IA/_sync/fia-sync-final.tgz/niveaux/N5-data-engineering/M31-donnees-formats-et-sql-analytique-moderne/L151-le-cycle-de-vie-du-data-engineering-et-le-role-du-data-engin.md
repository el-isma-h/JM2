---
id: L151
module: M31
level: N5
title: "Le cycle de vie du data engineering et le rôle du data engineer IA (Reis & Housley, fiche APEC, ROME M1811)"
minutes: 40
objectives:
  - "Décrire les cinq étapes du cycle de vie du data engineering et ses six courants sous-jacents, et y situer chaque module du niveau 5"
  - "Distinguer les missions du data engineer IA de celles du data scientist, de l'analytics engineer et du ML engineer, à partir de la fiche APEC et du code ROME M1811"
  - "Expliquer le schéma du jeu de données fil rouge Bréval Matériaux (tables, clés, volumes, données personnelles) réutilisé dans tout le niveau 5"
  - "Installer l'environnement de travail local (Python, DuckDB, Polars, Postgres sous Docker Compose)"
skills: ["C5.1"]
sources:
  - { title: "O'Reilly — Fundamentals of Data Engineering (Reis & Housley, 2022)", url: "https://oreilly.com/library/view/fundamentals-of-data/9781098108298", lang: "en" }
  - { title: "Joe Reis — The Data Engineering Lifecycle and Undercurrents, 4 Years Later", url: "https://joereis.substack.com/p/the-data-engineering-lifecycle-and", lang: "en" }
  - { title: "APEC — Fiche métier Data Engineer", url: "https://www.apec.fr/tous-nos-metiers/informatique/data-engineer.html", lang: "fr" }
  - { title: "OPCO Direct — Fiche métier Data engineer (ROME M1811)", url: "https://opcodirect.fr/metier/data-engineer", lang: "fr" }
  - { title: "Choisir le service public — Data engineer", url: "https://choisirleservicepublic.gouv.fr/metiers/numerique/data-engineer/", lang: "fr" }
  - { title: "Michael Page — Grille de salaires Data & IA", url: "https://www.michaelpage.fr/grilles-de-salaires/technology/data-ia-data-engineer-data-scientist", lang: "fr" }
  - { title: "DataTalksClub — Data Engineering Zoomcamp", url: "https://github.com/datatalksclub/data-engineering-zoomcamp", lang: "en" }
  - { title: "Docker — documentation", url: "https://docs.docker.com/", lang: "en" }
---

# Le cycle de vie du data engineering et le rôle du data engineer IA

> ⏱ 40 min · 🎯 Niveau 5 · 📚 Module 31

## 🎯 Ce que vous saurez faire
- Dessiner de mémoire le cycle de vie du data engineering (génération → stockage → ingestion → transformation → service) et placer chaque module du niveau 5 dessus.
- Expliquer à un recruteur ou à un dirigeant de PME ce que fait un data engineer « IA », et ce qu'il ne fait pas.
- Présenter le jeu de données fil rouge **Bréval Matériaux** : ses sept tables métier, ses tickets SAV, ses documents internes, ses volumes et ses données personnelles.
- Lancer en local la base Postgres qui jouera le rôle de « système source » pendant tout le niveau.

> 🧭 **En clair** — Pensez à la cuisine d'un grand restaurant. Les producteurs livrent légumes et viandes (les **sources** de données), on les range en chambre froide (le **stockage**), on contrôle chaque livraison à la porte de service (l'**ingestion**), les commis épluchent et préparent (la **transformation**) et les assiettes partent en salle (le **service** : tableaux de bord, modèles d'IA, assistants). Le data engineer est le chef de cette logistique : il ne crée pas la recette du plat signature (c'est le travail du data scientist ou de l'ingénieur IA), mais sans lui, rien n'arrive frais, propre et à l'heure en cuisine. Ce niveau 5 vous apprend à tenir cette cuisine, avec une PME fictive comme terrain d'entraînement.

## 1. Le cycle de vie du data engineering

En 2022, Joe Reis et Matt Housley publient *Fundamentals of Data Engineering* (O'Reilly). Leur apport principal n'est pas un outil mais un **cadre** : quels que soient les logiciels à la mode, un data engineer gère toujours le même cycle.

```
   GÉNÉRATION ──▶ INGESTION ──▶ TRANSFORMATION ──▶ SERVICE (serving)
  (systèmes          │                 │              analytique, ML,
   sources)          ▼                 ▼              IA générative,
                  ┌─────────────── STOCKAGE ───────────┐  reverse ETL
                  └────────────────────────────────────┘
  ══════════════ courants sous-jacents (undercurrents) ══════════════
  sécurité · gestion des données · DataOps · architecture ·
  orchestration · génie logiciel
```

| Étape | Question qu'elle pose | Exemple chez une PME | Module N5 |
|---|---|---|---|
| Génération | D'où vient la donnée, qui la possède ? | l'ERP, l'outil SAV, le serveur de fichiers | M31 |
| Stockage | Où et sous quel format la garder, à quel coût ? | Parquet sur stockage objet, entrepôt | M31, M32 |
| Ingestion | Comment la récupérer sans rien perdre ni doubler ? | export nocturne, capture de changements (CDC) | M33, M34 |
| Transformation | Comment la rendre juste et utile ? | nettoyage, jointures, modèle en étoile | M31, M33 |
| Service | Qui la consomme, avec quelle fraîcheur ? | tableau de bord, index vectoriel d'un RAG | M36, M37 |

Les **courants sous-jacents** (*undercurrents*) traversent toutes les étapes : la sécurité (qui a le droit de lire quoi), la gestion des données (qualité, catalogue, RGPD — M35), le **DataOps** (tests, déploiement continu, supervision des pipelines), l'architecture, l'orchestration (M33) et les bonnes pratiques de génie logiciel (Git, revues de code, tests). Joe Reis est revenu sur ce cadre dans un billet intitulé « The Data Engineering Lifecycle and Undercurrents, 4 Years Later » (lien en fin de leçon).

> 💡 **Autrement dit** — Les cinq étapes sont le « quoi » (ce que la donnée traverse) ; les six courants sont le « comment bien le faire » (ce qu'il faut surveiller à chaque étape). Un pipeline qui marche mais qui n'est ni testé, ni sécurisé, ni documenté n'est pas terminé.

> 💡 **À retenir** — Le stockage n'est pas une étape « après » l'ingestion : il est présent tout au long du cycle (données brutes, intermédiaires, finales). C'est pourquoi le schéma le place en dessous de tout le reste.

```quiz
{
  "q": "Chez Bréval Matériaux, un script copie chaque nuit les nouvelles commandes de l'ERP vers le lac de données. À quelle étape du cycle de vie correspond-il ?",
  "options": ["L'ingestion", "La génération", "Le service", "La transformation"],
  "answer": 0,
  "explanation": "L'ingestion déplace la donnée depuis le système source (l'ERP, qui la génère) vers le stockage de la plateforme data. La transformation viendra ensuite, le service à la fin."
}
```

## 2. Le data engineer IA : un métier, plusieurs voisins

### 2.1 Ce que disent les fiches officielles

La **fiche APEC** décrit le data engineer comme celui qui met en place la collecte et le stockage, rend les données disponibles et industrialise les traitements : API de collecte, automatisation des traitements par lots (*batchs*), tests, nettoyage, documentation, respect du **cycle de vie RGPD**, support de production, et de plus en plus **déploiement et suivi de modèles de machine learning**. Compétences citées : SQL et NoSQL (bases non relationnelles, comme MongoDB ou Redis), Python/Java/Scala, Spark, Kafka, Flink, ETL/ELT, Hadoop/Hive (héritage historique, voir L156), cybersécurité. Pas d'inquiétude si ces noms vous sont inconnus : chacun est expliqué dans la leçon qui l'utilise (ETL/ELT en L161, Spark en L159, Kafka en L167, Flink en L168).

Côté France Travail, le code **ROME M1811 « Data engineer »** regroupe les appellations *big data engineer*, *data architect*, *data manager*, *big data developer*, *data quality analyst* ; il met en avant la modélisation, les bases SQL/NoSQL, les tests, la maintenance des infrastructures et l'**anticipation des coûts**. La fonction publique a aussi sa fiche (« conçoit l'architecture des données, contrôle la qualité, alimente les data scientists »).

### 2.2 Qui fait quoi ?

| Rôle | Livre principalement | Outils typiques | Question favorite |
|---|---|---|---|
| **Data engineer** | pipelines fiables, plateforme de données | SQL, Python, Spark, Kafka, orchestrateur (planificateur de tâches, M33) | « La donnée est-elle arrivée, complète et à l'heure ? » |
| Analytics engineer | modèles de données propres et testés pour l'analyse | SQL, dbt (outil de transformation en SQL, L163), entrepôt | « Ce chiffre de CA est-il défini une seule fois ? » |
| Data scientist | analyses, modèles prédictifs | Python, notebooks, statistiques | « Ce modèle prédit-il mieux que le hasard ? » |
| ML / AI engineer | modèles et applications d'IA en production | PyTorch, API LLM, RAG, MLOps (industrialisation des modèles : déploiement, suivi, mises à jour) | « Le modèle répond-il juste, vite, pour pas cher ? » |

Le **data engineer IA** est un data engineer qui sait que son « client final » est souvent un modèle : il prépare des corpus dédupliqués et anonymisés (M36), alimente un index vectoriel qui doit rester à jour quand un document est modifié ou supprimé (M37), et versionne les jeux d'entraînement. Le niveau 3 (M20) vous a montré le RAG **côté application** ; le niveau 5 traite le **volume, la fraîcheur, la qualité et le coût** des données qui l'alimentent.

> ⚠️ **Piège fréquent** — Croire que l'IA rend le data engineering obsolète. C'est l'inverse : un assistant RAG branché sur des procédures périmées ou des doublons répond faux avec aplomb. La qualité de la donnée devient visible… par les utilisateurs.

### 2.3 Marché et salaires (nov. 2026)

Selon l'APEC, 80 % des offres de data engineer se situent **entre 35 et 60 k€ brut annuel** (fixe + variable), avec une moyenne d'environ **47 k€**. La grille Michael Page (étude 2027, Île-de-France, fixe) indique **45 / 59 / 80 k€** (bas / moyen / haut), avec une décote de 5 à 20 % selon les régions. Les titres RNCP « data engineer » existants sont de niveau 7 (Bac+5) et comptent plusieurs centaines d'heures, par exemple **RNCP42655** (DataScientest/Liora, actif jusqu'en 2031) : le niveau 5 de cette formation, d'environ 30 heures, est une **spécialisation** qui prépare aux fondamentaux de ces parcours et des certifications du marché (Google Professional Data Engineer, AWS DEA-C01, Databricks, dbt…), sans s'y substituer.

```mission
{
  "title": "Le salaire d'un data engineer selon l'APEC",
  "url": "https://www.apec.fr/tous-nos-metiers/informatique/data-engineer.html",
  "steps": ["Ouvrez la fiche métier Data Engineer de l'APEC", "Descendez jusqu'au bloc consacré à la rémunération", "Relevez la fourchette qui concentre la majorité des offres et la moyenne"],
  "question": "Entre quels montants se situent 80 % des offres de data engineer, et quel est le salaire moyen indiqué ?",
  "hint": "Les montants sont exprimés en k€ brut annuel, fixe et variable compris.",
  "answer": "Entre 35 et 60 k€ brut annuel, moyenne d'environ 47 k€ (fiche consultée en nov. 2026 ; ces chiffres sont mis à jour régulièrement) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : dans une équipe data, c'est le data engineer qui choisit l'architecture du modèle de langage utilisé par l'assistant RAG.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Le choix du modèle relève de l'ingénieur IA / ML. Le data engineer garantit que les données qui alimentent le modèle (documents, chunks, métadonnées, droits) sont complètes, fraîches, propres et traçables."
}
```

## 3. Le fil rouge du niveau 5 : Bréval Matériaux

Vous connaissez déjà **Bréval Matériaux** si vous avez suivi le module M20 : PME fictive de 45 salariés, négoce de matériaux de construction en Loire-Atlantique, dont vous avez construit l'assistant documentaire. Au niveau 5, vous reprenez **toute sa donnée**, pas seulement ses procédures. Trois agences : Nantes (siège), Saint-Nazaire, Ancenis. Clients particuliers et professionnels (artisans, entreprises du BTP, collectivités). Période couverte : du **1er janvier 2024 au 31 octobre 2026**.

### 3.1 Les trois systèmes sources

| Système | Contenu | Format de l'export | Fraîcheur attendue |
|---|---|---|---|
| ERP (Postgres) | agences, fournisseurs, produits, clients, commandes, lignes | CSV « à la française » (`;`, décimale `,`) | chaque nuit, puis en continu (CDC : capture des changements au fil de l'eau, M34) |
| Outil SAV (SaaS) | tickets et fils de messages | JSON Lines (un ticket par ligne) | chaque heure |
| Serveur de fichiers | procédures, fiches techniques, CGV, notes internes | Markdown (+ métadonnées CSV) | à chaque modification |

### 3.2 Le schéma relationnel de l'ERP

```mermaid
erDiagram
    AGENCES ||--o{ CLIENTS : "rattache"
    AGENCES ||--o{ COMMANDES : "enregistre"
    FOURNISSEURS ||--o{ PRODUITS : "fournit"
    CLIENTS ||--o{ COMMANDES : "passe"
    COMMANDES ||--|{ LIGNES_COMMANDE : "contient"
    PRODUITS ||--o{ LIGNES_COMMANDE : "est vendu dans"
    CLIENTS ||--o{ TICKETS_SAV : "ouvre"
    COMMANDES |o--o{ TICKETS_SAV : "concerne"
```

### 3.3 Dictionnaire des données (échelle 1, graine 42)

> 🧭 **Pré-requis express** — Trois mots reviennent dans ce tableau. Le **grain** d'une table, c'est ce que représente exactement **une ligne** (une commande ? une ligne d'article ?) : se tromper de grain, c'est compter deux fois le même chiffre d'affaires. La **graine** (*seed*, ici 42) est le nombre qui initialise le tirage aléatoire du générateur : même graine = mêmes données sur toutes les machines. L'**échelle** multiplie le volume (échelle 1 = la taille « PME », échelle 10 = dix fois plus de lignes).

| Table / fichier | Lignes | Grain (une ligne =) | Colonnes principales |
|---|---|---|---|
| `agences` | 3 | une agence | `agence_id` (NAN, STN, ANC), `nom`, `ville`, `code_postal`, `date_ouverture` |
| `fournisseurs` | 60 | un fournisseur | `fournisseur_id`, `nom`, `pays`, `delai_moyen_jours` |
| `produits` | 1 200 | un article du catalogue | `produit_id`, `sku` (BRV-GRO-00001), `libelle`, `famille` (8 familles), `unite` (sac, piece, palette, m2, ml), `prix_achat_ht`, `prix_vente_ht`, `taux_tva`, `fournisseur_id`, `actif`, `attributs` (JSON dont les clés varient selon la famille) |
| `clients` | 5 075 | un compte client | `client_id`, `code_client`, `type_client` (PRO/PART), `segment`, `raison_sociale`, `nom`, `prenom`, `email`, `telephone`, `siret`, `code_postal`, `ville`, `agence_id`, `date_creation`, `consentement_marketing`, `mis_a_jour_le` |
| `clients_maj_2026-11-01` | 250 | un client modifié ou créé le 1er nov. 2026 | mêmes colonnes (sert au `MERGE` en L153 et à l'historisation en L154) |
| `commandes` | 120 240 | une commande (en-tête) | `commande_id` (croissant dans le temps), `numero` (CMD-2025-0001234), `client_id`, `agence_id`, `canal`, `statut`, `date_commande` (heure locale **sans fuseau**), `date_livraison_prevue`, `montant_ht`, `mis_a_jour_le` |
| `lignes_commande` | 335 153 | une ligne d'article d'une commande | `ligne_id`, `commande_id`, `num_ligne`, `produit_id`, `quantite`, `prix_unitaire_ht`, `remise_pct` |
| `tickets_sav.jsonl` | 9 048 | un ticket SAV | `ticket_id`, `client_id`, `commande_id` (parfois nul), `ouvert_le` / `ferme_le` (ISO 8601 **avec fuseau** +01:00/+02:00), `canal`, `categorie`, `priorite`, `statut`, `satisfaction`, `messages` (liste d'objets), `tags` (liste), `agent` (objet, seulement depuis juin 2025) |
| `documents.csv` + `md/` | 126 | un document interne | `doc_id`, `chemin`, `titre`, `type_document`, `service`, `version`, `date_maj`, `confidentialite`, `sha256`, `nb_pages` |

Une option `--echelle` multiplie clients, commandes et tickets (×10 : 1,2 million de commandes et 3,4 millions de lignes, utilisé en M32 pour Spark et Polars). Le catalogue et les agences restent identiques ; les documents gardent les mêmes familles (30 procédures, 80 fiches techniques, 6 CGV, 4 notes), mais leurs dates et les anciennes versions restées sur le serveur dépendent de l'échelle : les chiffres cités dans le niveau (126 documents, etc.) valent pour l'échelle 1.

**Défauts injectés volontairement** (vous les chasserez en L155 et en M35) : commandes exportées deux fois, années saisies « 206x », en-têtes de commande dont le montant ne correspond pas à la somme des lignes, quantités négatives, prix manquants, clients en double (même e-mail écrit différemment), téléphones dans quatre formats, villes mal orthographiées, SIRET invalides, satisfaction parfois écrite en texte, champ `agent` apparu en cours de route (dérive de schéma).

**Données personnelles** (RGPD) : `nom`, `prenom`, `email`, `telephone` des clients ; numéros de téléphone glissés dans le texte libre des tickets ; nom et téléphone des responsables dans certaines procédures. Toutes sont **fictives** : domaines e-mail réservés en `.test`, numéros dans des plages fictives. Elles serviront à l'anonymisation avec Presidio (bibliothèque open source qui repère et masque les données personnelles dans un texte) (M36).

> 🎮 **Défi** — Sans regarder la suite : pour chaque table du dictionnaire, dites si elle est plutôt « structurée », « semi-structurée » ou « non structurée ». Vérifiez votre réponse au début de la leçon L152.

```quiz
{
  "q": "Dans le jeu Bréval, pourquoi `commande_id` croît-il avec la date de commande ?",
  "options": ["Pour que les fichiers CSV soient plus petits et plus vite compressés", "Parce que Postgres l'impose pour toute clé primaire", "Pour masquer les données personnelles", "Pour servir de curseur à un chargement incrémental"],
  "answer": 3,
  "explanation": "Comme dans un vrai ERP, un identifiant croissant (ou une colonne mis_a_jour_le) sert de « curseur » pour ne charger que les nouveautés. M33 l'exploitera pour l'ingestion incrémentale."
}
```

## 4. Mettre en place l'environnement local (rappel Docker inclus)

Tout le niveau 5 tourne **gratuitement sur votre poste** (8 Go de RAM suffisent pour l'échelle 1). Rappel express de Docker : une **image** est un modèle figé (Postgres 17, par exemple), un **conteneur** est une instance qui tourne à partir de cette image, un **volume** conserve les données quand le conteneur est recréé, et **Docker Compose** décrit plusieurs conteneurs dans un fichier YAML lancé par `docker compose up -d`.

> 🧭 **Pré-requis express** — Avant cette section, installez **Python 3.12 ou plus récent** (`python3 --version` doit afficher `Python 3.12.x` ou plus) et **Docker Desktop**, puis lancez Docker Desktop (l'icône de la baleine doit être fixe, pas animée). Sous Windows, utilisez de préférence **WSL 2** ou **Git Bash** : les commandes `mkdir -p …{sql,data}` et `source` ci-dessous sont écrites pour un terminal Linux/macOS. Une **venv** (*virtual environment*) est un dossier `.venv` qui isole les bibliothèques Python du projet : on l'« active » à chaque nouvelle session de terminal.

Créez le dossier de travail qui servira jusqu'au projet final :

```bash
mkdir -p breval/{sql,data} && cd breval
python3 -m venv .venv && source .venv/bin/activate     # Windows : .venv\Scripts\activate
pip install duckdb polars pyarrow pandas               # doc DuckDB de référence : 2.0 LTS (nov. 2026)
python -c "import duckdb, polars; print(duckdb.__version__, polars.__version__)"
```

> 🔍 **Ce que vous devez voir** — l'invite du terminal commence par `(.venv)` une fois l'environnement activé, `pip install` se termine par `Successfully installed duckdb-… polars-… pyarrow-… pandas-…`, et la dernière commande affiche **deux numéros de version** sur une seule ligne, par exemple `2.0.1 1.32.0` (vos numéros peuvent différer).

> 🛠️ **Si ça ne marche pas** — « `python3` n'est pas reconnu » sous Windows → Python s'appelle `py` ou `python` : essayez `py -3.12 -m venv .venv`. « `source` n'est pas reconnu » dans PowerShell → activez avec `.venv\Scripts\Activate.ps1` (si PowerShell refuse : `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`). Un dossier nommé littéralement `{sql,data}` apparaît → votre terminal ne gère pas les accolades : créez `breval/sql` et `breval/data` séparément. « externally-managed-environment » au `pip install` → la venv n'est pas activée.

Le fichier `docker-compose.yml` démarre l'ERP simulé. Le paramètre `wal_level=logical` (réglage qui autorise Postgres à publier le détail de chaque modification de ligne) est inutile aujourd'hui mais évitera de reconstruire la base en M34, quand Debezium (outil qui lit ce journal pour diffuser les changements, L169) lira le journal de transactions (le *WAL*, *write-ahead log* : registre où Postgres note chaque écriture avant de l'appliquer).

```yaml
# breval/docker-compose.yml — système source « ERP » de Bréval Matériaux
services:
  postgres:
    image: postgres:17
    container_name: breval-postgres
    environment:
      POSTGRES_DB: breval
      POSTGRES_USER: breval
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-breval_local}   # surcharge possible via .env
    command: ["postgres", "-c", "wal_level=logical"]          # prêt pour la capture de changements (M34)
    ports: ["5432:5432"]
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./sql:/docker-entrypoint-initdb.d:ro                 # scripts exécutés au premier démarrage
volumes:
  pgdata:
```

Le schéma de l'ERP, en SQL Postgres, est la **référence** du niveau : les modules suivants s'appuieront sur ces noms exacts.

```sql
-- breval/sql/01_ddl_erp.sql — schéma source de Bréval Matériaux (Postgres 17)
CREATE SCHEMA IF NOT EXISTS erp;

CREATE TABLE erp.agences (
  agence_id      char(3) PRIMARY KEY,                -- NAN, STN, ANC
  nom            text    NOT NULL,
  ville          text    NOT NULL,
  code_postal    char(5) NOT NULL,
  date_ouverture date    NOT NULL
);

CREATE TABLE erp.fournisseurs (
  fournisseur_id    integer  PRIMARY KEY,
  nom               text     NOT NULL,
  pays              char(2)  NOT NULL,                -- code ISO 3166-1
  delai_moyen_jours smallint NOT NULL
);

CREATE TABLE erp.produits (
  produit_id     integer PRIMARY KEY,
  sku            text    NOT NULL UNIQUE,             -- BRV-<famille>-<n°>
  libelle        text    NOT NULL,
  famille        text    NOT NULL,
  unite          text    NOT NULL CHECK (unite IN ('sac', 'piece', 'palette', 'm2', 'ml')),
  prix_achat_ht  numeric(10,2) NOT NULL,
  prix_vente_ht  numeric(10,2) NOT NULL,
  taux_tva       numeric(4,2)  NOT NULL,
  fournisseur_id integer REFERENCES erp.fournisseurs,
  actif          boolean NOT NULL,
  attributs      jsonb                               -- clés variables selon la famille
);

CREATE TABLE erp.clients (
  client_id              integer PRIMARY KEY,
  code_client            text    NOT NULL UNIQUE,
  type_client            text    NOT NULL CHECK (type_client IN ('PRO', 'PART')),
  segment                text    NOT NULL,            -- particulier, artisan, entreprise_btp, collectivite
  raison_sociale         text,
  nom                    text    NOT NULL,            -- donnée personnelle
  prenom                 text    NOT NULL,            -- donnée personnelle
  email                  text,                        -- donnée personnelle
  telephone              text,                        -- donnée personnelle
  siret                  char(14),
  code_postal            char(5),
  ville                  text,
  agence_id              char(3) REFERENCES erp.agences,
  date_creation          date    NOT NULL,
  consentement_marketing boolean NOT NULL,
  mis_a_jour_le          timestamp NOT NULL
);

CREATE TABLE erp.commandes (
  commande_id           bigint  PRIMARY KEY,
  numero                text    NOT NULL UNIQUE,
  client_id             integer NOT NULL REFERENCES erp.clients,
  agence_id             char(3) NOT NULL REFERENCES erp.agences,
  canal                 text    NOT NULL,             -- comptoir, telephone, web, commercial
  statut                text    NOT NULL,             -- brouillon, validee, livree, facturee, annulee
  date_commande         timestamp NOT NULL,           -- heure de Paris, sans fuseau (héritage de l'ERP)
  date_livraison_prevue date,
  montant_ht            numeric(12,2) NOT NULL,
  mis_a_jour_le         timestamp NOT NULL
);
CREATE INDEX commandes_maj_idx ON erp.commandes (mis_a_jour_le);   -- curseur d'ingestion (M33)

CREATE TABLE erp.lignes_commande (
  ligne_id         bigint   PRIMARY KEY,
  commande_id      bigint   NOT NULL REFERENCES erp.commandes,
  num_ligne        smallint NOT NULL,
  produit_id       integer  NOT NULL REFERENCES erp.produits,
  quantite         numeric(10,1) NOT NULL,
  prix_unitaire_ht numeric(10,2),                     -- parfois manquant (défaut connu)
  remise_pct       numeric(4,1)  NOT NULL DEFAULT 0,
  UNIQUE (commande_id, num_ligne)
);
```

> 🧭 **Pré-requis express** — Enregistrez le bloc YAML ci-dessus sous `breval/docker-compose.yml` et ce bloc SQL sous `breval/sql/01_ddl_erp.sql` **avant** de lancer la commande suivante : Postgres n'exécute les fichiers du dossier `sql/` qu'au tout premier démarrage. Le **DDL** (*Data Definition Language*) désigne justement ces ordres `CREATE …` qui définissent la structure des tables.

```bash
docker compose up -d
docker exec -it breval-postgres psql -U breval -d breval -c "\dt erp.*"   # 6 tables vides attendues
```

> 🔍 **Ce que vous devez voir** — `docker compose up -d` se termine par une ligne du type `✔ Container breval-postgres  Started`. La commande `\dt erp.*` affiche un petit tableau `List of relations` avec les colonnes `Schema | Name | Type | Owner` et **six lignes** : `erp | agences | table | breval`, puis `clients`, `commandes`, `fournisseurs`, `lignes_commande`, `produits`, et enfin `(6 rows)`.

> 🛠️ **Si ça ne marche pas** — « Cannot connect to the Docker daemon » → Docker Desktop n'est pas lancé. « port is already allocated » ou « address already in use » sur 5432 → un autre Postgres tourne déjà sur votre poste : remplacez `"5432:5432"` par `"5433:5432"` dans le YAML (et utilisez le port 5433 ensuite). « Did not find any relation named "erp.*" » → le fichier SQL n'était pas dans `sql/` au premier démarrage : `docker compose down -v` puis `docker compose up -d`. « the input device is not a TTY » sous Git Bash → préfixez la commande par `winpty` ou retirez le `-t` de `-it`. « database system is starting up » → attendez dix secondes et relancez.

Les tables sont vides : vous les remplirez en L152, après avoir généré le jeu de données.

> ⚠️ **Piège fréquent** — Les scripts de `docker-entrypoint-initdb.d` ne s'exécutent qu'au **premier** démarrage, quand le volume est vide. Si vous modifiez le DDL (les ordres `CREATE TABLE`) ensuite, lancez `docker compose down -v` (cela efface les données) puis `docker compose up -d`.

> 🔗 **Documentation officielle** — [Docker](https://docs.docker.com/) 🇬🇧 · [Fiche APEC Data Engineer](https://www.apec.fr/tous-nos-metiers/informatique/data-engineer.html) · [Fundamentals of Data Engineering](https://oreilly.com/library/view/fundamentals-of-data/9781098108298) 🇬🇧

## 🧪 Exercice pratique

**Consigne** — Rédigez la « fiche d'identité data » de Bréval Matériaux (une page) : (1) un schéma du cycle de vie où chaque système source de la section 3.1 est relié à son mode d'ingestion et à au moins un usage (*serving*) ; (2) pour chaque table, le propriétaire métier probable (commerce, SAV, direction…) ; (3) la liste des colonnes contenant des données personnelles et une base légale RGPD plausible pour chacune ; (4) la preuve que votre Postgres tourne (capture de `\dt erp.*`).

**Critères de réussite** — Les cinq étapes et au moins trois courants sous-jacents apparaissent ; chaque table a un propriétaire ; au moins six données personnelles sont identifiées, y compris celles cachées dans le texte libre des tickets ; les 6 tables `erp.*` existent.

**Pistes de corrigé** — Usages : tableau de bord des ventes par agence (analytique), prévision des ruptures (ML), assistant SAV qui résume l'historique d'un client (RAG). Bases légales plausibles : exécution du contrat (coordonnées de facturation), intérêt légitime ou consentement selon l'usage (prospection : la colonne `consentement_marketing` existe pour cela). Données personnelles « cachées » : téléphones dans `messages[].texte`, responsables nommés dans les procédures.

## ✅ Auto-évaluation express
1. Citez les cinq étapes du cycle de vie dans l'ordre.
2. Quelle différence principale entre un data engineer et un analytics engineer ?
3. Pourquoi le fil rouge sépare-t-il l'ERP (CSV), l'outil SAV (JSONL) et les documents (Markdown) ?

**Réponses** — 1. Génération, ingestion, transformation, service, avec le stockage en support tout au long du cycle. 2. Le data engineer construit et exploite les pipelines et la plateforme ; l'analytics engineer modélise et teste les données dans l'entrepôt pour l'analyse (souvent avec dbt). 3. Parce que c'est la réalité d'une PME : trois systèmes, trois formats, trois fraîcheurs, ce qui oblige à choisir une stratégie d'ingestion et de stockage par source.

## 📚 Pour aller plus loin
- [O'Reilly — Fundamentals of Data Engineering](https://oreilly.com/library/view/fundamentals-of-data/9781098108298) 🇬🇧 — l'ouvrage de référence sur le cycle de vie et ses courants sous-jacents.
- [Joe Reis — The Data Engineering Lifecycle and Undercurrents, 4 Years Later](https://joereis.substack.com/p/the-data-engineering-lifecycle-and) 🇬🇧 — le retour de l'auteur sur son propre cadre.
- [OPCO Direct — Fiche Data engineer (ROME M1811)](https://opcodirect.fr/metier/data-engineer) — appellations et compétences reprises du ROME.
- [Choisir le service public — Data engineer](https://choisirleservicepublic.gouv.fr/metiers/numerique/data-engineer/) — le métier dans la fonction publique.
- [DataTalksClub — Data Engineering Zoomcamp](https://github.com/datatalksclub/data-engineering-zoomcamp) 🇬🇧 — cours gratuit de 9 semaines, excellent complément pratique.

> ✅ **Si vous ne retenez que 3 choses** — 1. Le cycle de vie suit cinq étapes (génération, ingestion, transformation, service, avec le stockage en support permanent) et six courants transversaux (sécurité, gestion des données, DataOps, architecture, orchestration, génie logiciel). 2. Le data engineer IA ne choisit pas le modèle : il garantit que les données qui l'alimentent sont complètes, fraîches, propres, traçables et peu coûteuses. 3. Bréval Matériaux (ERP Postgres en CSV, SAV en JSONL, documents en Markdown) est le terrain de tout le niveau : gardez précieusement le dossier `breval/` et le conteneur `breval-postgres`.

> 🗺️ **Et maintenant ?** — Vous connaissez la cuisine et ses fournisseurs ; en L152, vous générez les données de Bréval et découvrez pourquoi le même fichier peut peser dix fois moins et se lire bien plus vite selon son format.
