---
id: L153
module: M31
level: N5
title: "SQL analytique moderne avec DuckDB : CTE, fenêtres, QUALIFY, MERGE, JSON et lecture d'un plan d'exécution"
minutes: 55
objectives:
  - "Structurer une requête analytique lisible avec des CTE et les raccourcis de DuckDB (FROM en tête, GROUP BY ALL, EXCLUDE)"
  - "Appliquer les fonctions de fenêtre (ROW_NUMBER, LAG, cumuls, moyennes mobiles, parts) et filtrer leur résultat avec QUALIFY"
  - "Appliquer un MERGE idempotent pour intégrer un fichier de mise à jour de clients"
  - "Interroger des données semi-structurées (STRUCT, LIST, JSON, horodatages avec fuseau)"
  - "Lire un plan d'exécution (EXPLAIN, EXPLAIN ANALYZE) et vérifier les projections et filtres poussés vers Parquet"
skills: ["C5.1"]
sources:
  - { title: "DuckDB — documentation", url: "https://duckdb.org/docs/", lang: "en" }
  - { title: "DuckDB 2.0 — Integration with Polars", url: "https://duckdb.org/docs/2.0/guides/python/polars.html", lang: "en" }
  - { title: "Kaggle Learn — Intro to SQL", url: "https://www.kaggle.com/learn/intro-to-sql", lang: "en" }
  - { title: "Kaggle Learn — Advanced SQL", url: "https://www.kaggle.com/learn/advanced-sql", lang: "en" }
  - { title: "Berkeley CS186 — Introduction to Database Systems (SQL I/II)", url: "https://cs186berkeley.net/sp25/", lang: "en" }
  - { title: "PostgreSQL — Window Functions (tutoriel)", url: "https://www.postgresql.org/docs/current/tutorial-window.html", lang: "en" }
---

# SQL analytique moderne avec DuckDB

> ⏱ 55 min · 🎯 Niveau 5 · 📚 Module 31

## 🎯 Ce que vous saurez faire
- Écrire en quelques lignes le chiffre d'affaires mensuel par agence, sa croissance et sa moyenne mobile.
- Dédoublonner une table « au plus récent » en une seule clause `QUALIFY`.
- Intégrer le fichier de mise à jour des clients du 1er novembre 2026 avec un `MERGE` rejouable sans effet de bord.
- Exploiter les fils de messages imbriqués des tickets SAV, et lire le plan d'exécution d'une requête pour savoir **pourquoi** elle est rapide ou lente.

> 🧭 **En clair** — Le SQL de base répond à « combien ? » ; le SQL analytique répond à « combien par rapport à quoi ? » : par rapport au mois précédent, au reste de l'agence, aux trois derniers mois. Les fonctions de fenêtre sont comme une règle qu'on fait glisser sur un tableau : pour chaque ligne, on regarde ses voisines sans fusionner les lignes. DuckDB est le moteur idéal pour s'entraîner : un seul `pip install`, aucun serveur, et il lit vos fichiers Parquet comme s'il s'agissait de tables. Tout ce que vous apprenez ici se transpose presque mot pour mot dans Snowflake, BigQuery ou Databricks (L158).

## 1. Préparer l'espace de travail

DuckDB est une base **analytique embarquée** (elle n'a pas de serveur à installer : c'est une bibliothèque qui vit dans votre programme, comme SQLite) : elle tourne dans votre processus Python, stocke les données en colonnes et exécute les requêtes de façon vectorisée (par paquets de valeurs) sur tous les cœurs. La documentation stable est en version **2.0 LTS** (nov. 2026).

```python
# breval/sql_analytique.py — à exécuter depuis le dossier breval/
import duckdb

con = duckdb.connect("data/breval.duckdb")     # entrepôt du niveau (créé s'il n'existe pas ; dlt et dbt l'enrichiront en M33)
con.execute("SET TimeZone = 'Europe/Paris'")   # fuseau de référence pour les TIMESTAMPTZ
for t in ["agences", "produits", "clients", "commandes", "lignes_commande", "tickets_sav"]:
    con.execute(f"CREATE OR REPLACE VIEW bz_{t} AS FROM 'data/bronze/{t}.parquet'")
print(con.sql("SELECT count(*) AS n, count(DISTINCT commande_id) AS distinctes FROM bz_commandes"))
```

> 🧭 **Pré-requis express** — Enregistrez ce code sous `breval/sql_analytique.py` et lancez `python sql_analytique.py` **depuis le dossier `breval/`** (les vues `bz_…` pointent vers `data/bronze/…` en chemin relatif). Une **vue** (`VIEW`) est une requête enregistrée sous un nom, qui se comporte comme une table mais ne recopie aucune donnée. Pour exécuter les blocs SQL suivants, deux options : (a) ajoutez à la fin du script `con.sql("""…collez la requête…""").show()` ; (b) installez le client en ligne de commande `duckdb` et ouvrez le même fichier avec `duckdb data/breval.duckdb`, puis collez la requête après l'invite `D` (terminez par `;`). `TIMESTAMPTZ` est un horodatage **avec** fuseau horaire, `TIMESTAMP` un horodatage sans fuseau.

> 🔍 **Ce que vous devez voir** — un petit tableau encadré avec deux colonnes `n` et `distinctes` valant **120240** et **120000**, et un fichier `data/breval.duckdb` apparu dans votre dossier.

> 🛠️ **Si ça ne marche pas** — « IO Error: No files found that match the pattern "data/bronze/agences.parquet" » → vous n'êtes pas dans `breval/`, ou `vers_bronze.py` (L152) n'a pas été lancé. « Could not set lock on file "data/breval.duckdb" » → le fichier est déjà ouvert par un autre programme (un client `duckdb` ou un notebook resté ouvert) : DuckDB n'accepte qu'un seul processus en écriture à la fois, fermez l'autre (`.quit` dans le client).

`FROM 'fichier.parquet'` sans `SELECT` est un raccourci DuckDB équivalent à `SELECT *`. Le résultat attendu, 120 240 lignes pour 120 000 identifiants, confirme les doublons d'export : nous allons les traiter proprement.

## 2. CTE : découper une requête en étapes nommées

Une **CTE** (*Common Table Expression*, clause `WITH`) donne un nom à un résultat intermédiaire. Elle rend la requête lisible de haut en bas, comme une recette.

```sql
WITH commandes AS (                       -- étape 1 : une ligne par commande, hors annulations et dates aberrantes
    SELECT DISTINCT *
    FROM bz_commandes
    WHERE statut <> 'annulee' AND date_commande < TIMESTAMP '2026-11-01'
),
mensuel AS (                              -- étape 2 : CA par agence et par mois
    SELECT agence_id, date_trunc('month', date_commande) AS mois, sum(montant_ht) AS ca_ht
    FROM commandes
    GROUP BY ALL                          -- DuckDB regroupe par toutes les colonnes non agrégées
)
SELECT * FROM mensuel ORDER BY agence_id, mois;
```

> 🔍 **Ce que vous devez voir** — trois colonnes `agence_id | mois | ca_ht`, environ 34 mois × 3 agences ≈ une centaine de lignes, triées `ANC` puis `NAN` puis `STN`, avec des `mois` du type `2024-01-01 00:00:00` (`date_trunc` ramène chaque date au premier jour du mois).

`GROUP BY ALL` évite de recopier la liste des colonnes (et les oublis qui vont avec). D'autres raccourcis utiles : `SELECT * EXCLUDE (mis_a_jour_le)`, `SELECT * REPLACE (round(montant_ht) AS montant_ht)`, ou `COLUMNS('prix_.*')` pour appliquer une expression à toutes les colonnes dont le nom correspond.

## 3. Fonctions de fenêtre

Une fonction de fenêtre calcule une valeur pour chaque ligne à partir d'un **ensemble de lignes voisines**, défini par `OVER (PARTITION BY … ORDER BY … [cadre])` — ici, **partition** veut simplement dire « groupe de lignes » (par exemple toutes les lignes d'une même agence) ; rien à voir avec le partitionnement de fichiers vu en M32, sans regrouper les lignes comme le ferait `GROUP BY`.

```sql
WITH commandes AS (
    SELECT DISTINCT * FROM bz_commandes
    WHERE statut <> 'annulee' AND date_commande < TIMESTAMP '2026-11-01'
),
mensuel AS (
    SELECT agence_id, date_trunc('month', date_commande) AS mois, sum(montant_ht) AS ca_ht
    FROM commandes GROUP BY ALL
)
SELECT
    agence_id, mois, ca_ht,
    lag(ca_ht) OVER w                                             AS ca_mois_precedent,
    round(100 * (ca_ht / lag(ca_ht) OVER w - 1), 1)               AS croissance_pct,
    avg(ca_ht) OVER (PARTITION BY agence_id ORDER BY mois
                     ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)    AS moyenne_mobile_3m,
    sum(ca_ht) OVER (PARTITION BY agence_id, year(mois) ORDER BY mois) AS cumul_annuel,
    round(100 * ca_ht / sum(ca_ht) OVER (PARTITION BY mois), 1)   AS part_du_mois_pct
FROM mensuel
WINDOW w AS (PARTITION BY agence_id ORDER BY mois)               -- fenêtre nommée, réutilisée
ORDER BY agence_id, mois;
```

> 🔍 **Ce que vous devez voir** — les mêmes lignes que précédemment, avec cinq colonnes en plus. Sur la **première** ligne de chaque agence, `ca_mois_precedent` et `croissance_pct` valent `NULL` : c'est normal, il n'existe pas de mois précédent. Pour chaque mois, les trois valeurs de `part_du_mois_pct` (une par agence) doivent totaliser environ 100.

| Fonction | Ce qu'elle renvoie | Exemple Bréval |
|---|---|---|
| `row_number()` | 1, 2, 3… dans la partition | numéroter les commandes d'un client |
| `rank()` / `dense_rank()` | rang avec ex æquo (avec ou sans trous) | classement des produits par CA |
| `lag(x)` / `lead(x)` | valeur de la ligne précédente / suivante | CA du mois précédent |
| `sum(x) OVER (ORDER BY …)` | cumul | CA cumulé depuis janvier |
| `avg(x) OVER (… ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)` | moyenne glissante | lisser la saisonnalité (août creux) |
| `x / sum(x) OVER (PARTITION BY …)` | part relative | poids de Saint-Nazaire dans le CA du mois |

> ⚠️ **Piège fréquent** — Oublier le cadre (*frame*) d'une fenêtre ordonnée. (le *cadre* est la portion de la partition prise en compte pour chaque ligne : « les 2 lignes précédentes et la ligne courante », par exemple) Avec `ORDER BY` et sans cadre explicite, le cadre par défaut va du début de la partition à la ligne courante (en incluant les ex æquo) : c'est un **cumul**, pas un total. Pour un total par partition, n'écrivez pas d'`ORDER BY` dans `OVER`.

> 💡 **Autrement dit** — `GROUP BY` écrase les lignes en une seule par groupe ; une fenêtre garde toutes les lignes et ajoute à chacune une colonne calculée « en regardant autour ».

```quiz
{
  "q": "Vous voulez, pour chaque commande, le montant de la commande PRÉCÉDENTE du même client. Quelle expression utilisez-vous ?",
  "options": ["lead(montant_ht) OVER (PARTITION BY client_id ORDER BY date_commande)", "sum(montant_ht) OVER (PARTITION BY client_id)", "row_number() OVER (ORDER BY montant_ht)", "lag(montant_ht) OVER (PARTITION BY client_id ORDER BY date_commande)"],
  "answer": 3,
  "explanation": "lag() lit la ligne précédente dans l'ordre de la fenêtre, ici les commandes du même client triées par date. lead() lirait la suivante ; sum() sans ORDER BY donnerait le total du client."
}
```

## 4. QUALIFY : filtrer sur une fenêtre

`WHERE` filtre avant le calcul des fenêtres, `HAVING` après les agrégats ; **`QUALIFY`** filtre **après** les fenêtres. C'est la façon la plus nette de garder « la ligne la plus récente par clé », opération que vous ferez des centaines de fois en data engineering.

```sql
-- Une seule ligne par commande : la version la plus récente (les doublons exacts disparaissent aussi)
CREATE OR REPLACE TABLE commandes_dedup AS
SELECT *
FROM bz_commandes
QUALIFY row_number() OVER (PARTITION BY commande_id ORDER BY mis_a_jour_le DESC) = 1;

-- Les 3 produits qui rapportent le plus dans chaque famille
WITH ca_produit AS (
    SELECT p.famille, p.libelle, sum(l.quantite * l.prix_unitaire_ht * (1 - l.remise_pct / 100)) AS ca_ht
    FROM bz_lignes_commande l JOIN bz_produits p USING (produit_id)
    GROUP BY ALL
)
SELECT * FROM ca_produit
QUALIFY dense_rank() OVER (PARTITION BY famille ORDER BY ca_ht DESC) <= 3
ORDER BY famille, ca_ht DESC;
```

> 🔍 **Ce que vous devez voir** — la création de `commandes_dedup` n'affiche rien (ou `Count 120000` selon le client) ; vérifiez avec `SELECT count(*) FROM commandes_dedup` : **120000**. La seconde requête renvoie au plus 3 lignes par famille, soit environ 24 lignes (8 familles), davantage s'il y a des ex æquo.

`QUALIFY` n'est pas dans la norme SQL mais existe dans DuckDB, Snowflake, BigQuery et Databricks ; ailleurs (Postgres), on écrit la même chose avec une sous-requête et un `WHERE rn = 1`.

## 5. MERGE : intégrer une mise à jour sans doublon

Le fichier `clients_maj_2026-11-01` contient 250 clients : 200 existants modifiés (déménagement, passage en professionnel, nouveau téléphone, consentement) et 50 nouveaux. `MERGE` applique en **une seule instruction** « mettre à jour si la clé existe, insérer sinon ».

```sql
CREATE OR REPLACE TABLE clients_a_jour AS FROM bz_clients;    -- 5 075 lignes

MERGE INTO clients_a_jour AS c
USING (FROM 'data/bronze/clients_maj_2026_11_01.parquet') AS m
ON c.client_id = m.client_id
WHEN MATCHED AND m.mis_a_jour_le > c.mis_a_jour_le THEN      -- condition : rejouer le MERGE ne change rien
    UPDATE SET type_client = m.type_client, segment = m.segment, raison_sociale = m.raison_sociale,
               telephone = m.telephone, siret = m.siret, code_postal = m.code_postal, ville = m.ville,
               agence_id = m.agence_id, consentement_marketing = m.consentement_marketing,
               mis_a_jour_le = m.mis_a_jour_le
WHEN NOT MATCHED THEN
    INSERT (client_id, code_client, type_client, segment, raison_sociale, nom, prenom, email, telephone,
            siret, code_postal, ville, agence_id, date_creation, consentement_marketing, mis_a_jour_le)
    VALUES (m.client_id, m.code_client, m.type_client, m.segment, m.raison_sociale, m.nom, m.prenom,
            m.email, m.telephone, m.siret, m.code_postal, m.ville, m.agence_id, m.date_creation,
            m.consentement_marketing, m.mis_a_jour_le);

SELECT count(*) FROM clients_a_jour;                           -- 5 125 attendu
```

> 🔍 **Ce que vous devez voir** — **5125** (5 075 clients d'origine + 50 nouveaux ; les 200 clients modifiés ne créent pas de ligne). Relancez uniquement le `MERGE` puis le `count(*)` : toujours **5125**, preuve que l'opération est rejouable.

> 🛠️ **Si ça ne marche pas** — « Parser Error: syntax error at or near "MERGE" » → votre version de DuckDB est trop ancienne : `pip install -U duckdb`, ou utilisez la variante `INSERT … ON CONFLICT` décrite juste après. « No files found » sur `clients_maj_2026_11_01.parquet` → notez les **tirets bas** : `vers_bronze.py` a remplacé les tirets du nom d'origine.

La condition `m.mis_a_jour_le > c.mis_a_jour_le` rend l'opération **idempotente** (voir le lexique : rejouer l'opération ne change pas le résultat, comme appuyer deux fois sur le bouton d'un ascenseur) : exécutée deux fois, elle donne le même résultat, compétence exigée par C5.2 et qui vous évitera bien des nuits blanches. Si votre version de DuckDB ne reconnaît pas `MERGE` (vérifiez la page « MERGE » de la documentation de votre version), le même effet s'obtient avec une clé primaire et `INSERT INTO … ON CONFLICT (client_id) DO UPDATE SET … = excluded.…`.

> ⚠️ **Piège fréquent** — Un `MERGE` met à jour la ligne **en écrasant** l'ancienne valeur : l'ancienne ville du client a disparu. Pour l'analyse historique (« où habitait ce client quand il a commandé ? »), il faut une dimension à historisation de type SCD 2 (*Slowly Changing Dimension*, voir le lexique) : c'est l'objet de L154.

```quiz
{
  "q": "Pourquoi ajouter `AND m.mis_a_jour_le > c.mis_a_jour_le` à la clause WHEN MATCHED ?",
  "options": ["Pour accélérer la jointure entre la table cible et le fichier", "Parce que MERGE exige une condition supplémentaire dans WHEN MATCHED", "Pour qu'un rejeu ou un vieux fichier n'écrase pas une donnée récente", "Pour insérer les nouveaux clients absents de la table cible"],
  "answer": 2,
  "explanation": "La condition protège contre le rejeu et contre les fichiers arrivés dans le désordre : on ne remplace une ligne que par une version plus récente. C'est une technique classique d'idempotence."
}
```

## 6. Données semi-structurées : STRUCT, LIST, JSON, fuseaux

En bronze, `messages` est une **liste de structures** et `agent` une **structure**. DuckDB y accède par la notation pointée et les index (qui commencent à 1). `unnest` fait l'inverse d'un regroupement : il « déplie » une liste en autant de lignes qu'elle contient d'éléments.

```sql
-- Premier message de chaque ticket, nombre d'échanges, agent quand il existe
SELECT ticket_id, categorie,
       len(messages)            AS nb_messages,
       messages[1].texte        AS premier_message,
       agent.id                 AS agent_id,                    -- NULL avant juin 2025
       TRY_CAST(satisfaction AS INTEGER) AS satisfaction        -- les « "5" » texte deviennent 5
FROM bz_tickets_sav
LIMIT 5;

-- Une ligne par message (« dépliage ») puis délai de première réponse par catégorie
WITH msg AS (
    SELECT ticket_id, categorie, unnest(messages) AS m FROM bz_tickets_sav
),
premiere_reponse AS (
    SELECT ticket_id, categorie,
           min(CAST(m.horodatage AS TIMESTAMPTZ)) FILTER (WHERE m.auteur = 'client') AS demande,
           min(CAST(m.horodatage AS TIMESTAMPTZ)) FILTER (WHERE m.auteur = 'agent')  AS reponse
    FROM msg GROUP BY ALL
)
SELECT categorie, round(median(date_diff('minute', demande, reponse)) / 60, 1) AS delai_median_h
FROM premiere_reponse WHERE reponse IS NOT NULL
GROUP BY ALL ORDER BY delai_median_h DESC;

-- JSON stocké en texte : la colonne attributs des produits
SELECT famille, json_keys(attributs) AS cles, attributs ->> '$.norme' AS norme
FROM bz_produits QUALIFY row_number() OVER (PARTITION BY famille ORDER BY produit_id) = 1;
```

> 🔍 **Ce que vous devez voir** — la première requête renvoie 5 lignes, avec `agent_id` vide (`NULL`) pour les tickets ouverts avant juin 2025 ; la deuxième, une ligne par catégorie de ticket avec un délai médian en heures ; la troisième, une ligne par famille (8 lignes) avec des listes de clés **différentes** d'une famille à l'autre et `norme` parfois `NULL`.

La dernière requête montre la **dérive de schéma** : les produits bois ont `essence` et `classe_emploi`, l'isolation a `lambda_w_mk`, l'outillage n'a pas de `norme`.

Les fuseaux méritent une règle : on compare des instants dans **le même référentiel**. `date_commande` est une heure locale sans fuseau ; pour la rapprocher de `ouvert_le` (avec décalage), on l'interprète explicitement en heure de Paris : `timezone('Europe/Paris', date_commande)` renvoie un `TIMESTAMPTZ`. Faire l'inverse sans y penser décale les événements d'une heure l'hiver et de deux l'été.

## 7. Lire un plan d'exécution

`EXPLAIN` montre le plan prévu ; `EXPLAIN ANALYZE` exécute la requête et ajoute le temps et le nombre de lignes de chaque opérateur.

```sql
-- (les doublons d'export de bronze faussent un peu le total : l'objet est ici le plan)
EXPLAIN ANALYZE
SELECT c.agence_id, p.famille, sum(l.quantite * l.prix_unitaire_ht) AS ca_ht
FROM 'data/bronze/lignes_commande.parquet' l
JOIN 'data/bronze/commandes.parquet' c USING (commande_id)
JOIN 'data/bronze/produits.parquet' p USING (produit_id)
WHERE c.date_commande >= TIMESTAMP '2026-01-01'
GROUP BY ALL;
```

> 🔍 **Ce que vous devez voir** — un arbre dessiné en caractères, fait de boîtes empilées reliées par des traits : en bas, trois boîtes `TABLE_SCAN` ou `PARQUET_SCAN` (une par fichier) qui listent `Projections:` et, pour `commandes`, `Filters: date_commande>=…` ; au-dessus, deux boîtes `HASH_JOIN`, puis une boîte `HASH_GROUP_BY` (ou `PERFECT_HASH_GROUP_BY`) ; chaque boîte affiche un nombre de lignes et un temps. Les noms exacts varient légèrement selon la version : ce qui compte, c'est **où** apparaît le filtre.

Lisez le plan **de bas en haut** et cherchez quatre choses :

1. **Les opérateurs de lecture** des fichiers Parquet : la liste des *projections* ne doit contenir que les colonnes utilisées (projection poussée), et le filtre sur `date_commande` doit apparaître **dans** la lecture de `commandes` (filtre poussé), pas plus haut.
2. **Les jointures** (`HASH_JOIN`) (jointure par table de hachage : le moteur range la petite table dans un « annuaire » en mémoire, puis y cherche chaque ligne de la grande) : le côté « construction » (*build*) doit être la plus petite table ; ici `produits` (1 200 lignes) et les commandes filtrées.
3. **L'agrégation** (`HASH_GROUP_BY` ou équivalent) et son nombre de groupes en sortie (3 agences × 8 familles = 24).
4. **Les cardinalités** (nombre de lignes qui entrent et sortent de chaque opérateur) : un opérateur qui sort beaucoup plus de lignes qu'il n'en reçoit signale une jointure mal conditionnée (produit cartésien accidentel) — chaque ligne d'une table combinée avec chaque ligne de l'autre, ce qui fait exploser le volume.

> 💡 **À retenir** — Une requête rapide lit peu : peu de colonnes (format colonnaire), peu de blocs (filtres poussés et données triées), peu de lignes dans les jointures (filtrer avant de joindre). Le plan vous dit laquelle de ces trois règles est violée.

```mission
{
  "title": "Les fonctions analytiques dans le cours Advanced SQL de Kaggle",
  "url": "https://www.kaggle.com/learn/advanced-sql",
  "steps": ["Ouvrez la page du micro-cours Advanced SQL de Kaggle Learn", "Parcourez la liste des leçons", "Repérez celle qui traite des fonctions de fenêtre et celle qui traite des données imbriquées"],
  "question": "Quels sont les intitulés des leçons consacrées aux fonctions de fenêtre et aux données imbriquées, et sur quel entrepôt cloud le cours fait-il pratiquer ?",
  "hint": "Les fonctions de fenêtre y sont appelées « analytic functions ».",
  "answer": "« Analytic Functions » et « Nested and Repeated Data », exercices sur BigQuery (intitulés relevés en nov. 2026, susceptibles d'évoluer).",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne** — Sur la couche bronze de Bréval, écrivez quatre requêtes et enregistrez-les dans `breval/sql/analyses.sql` : (1) CA HT mensuel par agence avec croissance et moyenne mobile sur 3 mois ; (2) pour chaque client professionnel, le nombre de jours entre ses deux dernières commandes (`lag` + `QUALIFY`) ; (3) le `MERGE` des clients, exécuté **deux fois** ; (4) le taux de tickets SAV par famille de produits… attention, les tickets ne référencent qu'une commande, pas un produit : proposez et justifiez une règle d'attribution. Pour la requête (1), joignez la sortie d'`EXPLAIN ANALYZE` annotée.

**Critères de réussite** — Les doublons d'export et les dates « 206x » sont exclus ; le second `MERGE` ne modifie aucune ligne (`SELECT count(*)` et une somme de contrôle identiques) ; le plan annoté identifie au moins une projection et un filtre poussés.

**Pistes de corrigé** — (2) `QUALIFY row_number() OVER (PARTITION BY client_id ORDER BY date_commande DESC) = 1` après avoir calculé `date_diff('day', lag(date_commande) OVER (...), date_commande)`. (4) Deux règles défendables : attribuer le ticket à **chaque** famille présente dans la commande (compte multiple, à signaler) ou à la famille du montant le plus élevé ; l'important est de documenter le choix, car il change le résultat.

## ✅ Auto-évaluation express
1. Dans quel ordre s'appliquent `WHERE`, `GROUP BY`/`HAVING`, les fenêtres et `QUALIFY` ?
2. Que fait `GROUP BY ALL` ?
3. Comment reconnaît-on, dans un plan, qu'un filtre a été poussé vers Parquet ?

**Réponses** — 1. `WHERE` → `GROUP BY`/`HAVING` → fonctions de fenêtre → `QUALIFY` → `ORDER BY`/`LIMIT`. 2. Il regroupe par toutes les colonnes du `SELECT` qui ne sont pas des agrégats. 3. La condition figure dans l'opérateur de lecture du fichier (section filtres) au lieu d'un opérateur `FILTER` placé au-dessus.

## 📚 Pour aller plus loin
- [DuckDB — documentation](https://duckdb.org/docs/) 🇬🇧 — syntaxe « amicale » (FROM en tête, GROUP BY ALL, QUALIFY), fonctions JSON, EXPLAIN.
- [PostgreSQL — tutoriel sur les fonctions de fenêtre](https://www.postgresql.org/docs/current/tutorial-window.html) 🇬🇧 — la référence pédagogique du concept, valable pour tous les moteurs.
- [Kaggle Learn — Intro to SQL](https://www.kaggle.com/learn/intro-to-sql) 🇬🇧 et [Advanced SQL](https://www.kaggle.com/learn/advanced-sql) 🇬🇧 — micro-cours gratuits sur BigQuery.
- [Berkeley CS186](https://cs186berkeley.net/sp25/) 🇬🇧 — cours universitaire (SQL, jointures, optimisation), source d'inspiration.

> ✅ **Si vous ne retenez que 3 choses** — 1. Une CTE (`WITH`) découpe une requête en étapes nommées ; une fonction de fenêtre (`OVER`) ajoute à chaque ligne un calcul « en regardant ses voisines » sans fusionner les lignes. 2. `QUALIFY row_number() OVER (PARTITION BY clé ORDER BY date DESC) = 1` garde la ligne la plus récente par clé ; `MERGE` avec une condition de date est rejouable sans effet de bord (idempotent). 3. Un plan d'exécution se lit de bas en haut : une requête rapide lit peu de colonnes, peu de blocs et filtre avant de joindre.

> 🗺️ **Et maintenant ?** — Vous savez interroger ; reste à savoir **comment organiser** les tables pour que les questions soient simples et justes dans le temps : c'est la modélisation analytique de L154.
