---
module: M31
title: "Fiche mémo — Données, formats et SQL analytique moderne"
---
# Fiche mémo — M31 · Données, formats et SQL analytique moderne

> En une phrase : le data engineer est le chef de la logistique de la cuisine. Il range la donnée dans le bon format (Parquet), l'interroge avec un SQL qui « regarde autour » (fenêtres, QUALIFY), la modélise pour répondre (étoile + SCD 2) et prouve que rien ne s'est perdu.

## Les 7 idées à retenir
1. Cinq étapes : génération → ingestion → transformation → service, avec le stockage en support tout du long. Six courants sous-jacents les traversent : sécurité, gestion des données, DataOps, architecture, orchestration, génie logiciel (`L151`).
2. Le data engineer IA prépare des données pour un modèle : corpus dédupliqués et anonymisés, index vectoriel à jour. Il ne choisit pas le modèle (`L151`).
3. Un CSV n'a pas de types. En bronze, on impose `VARCHAR` au SIRET et au code postal, `DECIMAL` aux montants, et la décimale « , » (`L152`).
4. Parquet = colonnes + row groups avec min/max : on lit peu de colonnes (projection) et peu de blocs (predicate pushdown). Avro = lignes + évolution de schéma, pour Kafka. Arrow = mémoire, zéro-copie (`L152`).
5. `WHERE` → `GROUP BY`/`HAVING` → fenêtres → `QUALIFY` → `ORDER BY`/`LIMIT`. Seul `QUALIFY` filtre sur une fenêtre (`L153`).
6. Un `MERGE` avec condition `m.mis_a_jour_le > c.mis_a_jour_le` est idempotent, mais il écrase l'historique. Pour l'historique, on utilise une SCD 2 (`L153`, `L154`).
7. Bronze fidèle, silver propre, gold prêt à consommer. On ne supprime rien en silence : quarantaine avec motif, imputation signalée, réconciliation chiffrée (`L154`, `L155`).

## Le schéma à connaître
```mermaid
flowchart LR
    R["raw<br/>CSV ; et JSONL"] --> B["bronze<br/>Parquet typé, rien corrigé"]
    B --> S["silver<br/>nettoyé, dédoublonné"]
    B --> Q["quarantaine<br/>avec motif"]
    S --> G["gold<br/>fait_ventes + dim_client SCD 2"]
    G --> C{"bronze = silver + quarantaine ?"}
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Row group | Une tranche de lignes rangée colonne par colonne, avec sa fiche min/max |
| Projection / predicate pushdown | Lire seulement les colonnes utiles / sauter les blocs exclus par le filtre |
| Grain | Ce que représente une ligne du fait : ici, une ligne de commande |
| Clé de substitution (`_sk`) | Un entier propre à l'entrepôt, distinct de `client_id` |
| SCD 2 | On ferme l'ancienne version (`valide_au`) et on en ouvre une nouvelle |
| Dimension dégénérée | `numero_commande` gardé dans le fait, sans table propre |
| Data Vault 2.0 | Hubs (clés), links (relations), satellites (attributs historisés par source) |
| OBT | One Big Table : une table large pour la BI et le ML |

## Les pièges classiques
- Laisser `read_json` deviner le schéma sur un échantillon : le champ `agent` (depuis juin 2025) disparaît. Il faut écrire `sample_size = -1`.
- Mettre `ORDER BY` dans `OVER` pour un total : on obtient un cumul.
- Mélanger deux grains : le `montant_ht` d'en-tête dans un fait à la ligne se multiplie.
- Calculer le panier moyen avec `avg(ca_ht)` au lieu de `sum(ca_ht) / count(DISTINCT numero_commande)`.
- Nettoyer `clients` mais pas `clients_maj` : la SCD 2 crée des versions fantômes.
- Mesurer une seule fois : le cache fausse le chrono. On garde le meilleur de trois essais.
- Monter un Data Vault pour une PME à trois sources stables.
- Modifier le DDL sans `docker compose down -v` : les scripts d'init ne tournent qu'au premier démarrage.

## Les commandes / chiffres / dates utiles
```sql
CREATE OR REPLACE VIEW bz_commandes AS FROM 'data/bronze/commandes.parquet';
SELECT * FROM bz_commandes
QUALIFY row_number() OVER (PARTITION BY commande_id ORDER BY mis_a_jour_le DESC) = 1;
SELECT agence_id, date_trunc('month', date_commande) AS mois, sum(montant_ht) FROM bz_commandes GROUP BY ALL;
lag(ca_ht) OVER (PARTITION BY agence_id ORDER BY mois)                -- mois précédent
avg(ca_ht) OVER (PARTITION BY agence_id ORDER BY mois ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
SELECT messages[1].texte, agent.id, TRY_CAST(satisfaction AS INTEGER) FROM bz_tickets_sav;
SELECT unnest(messages) AS m FROM bz_tickets_sav;                    -- une ligne par message
SELECT json_keys(attributs), attributs ->> '$.norme' FROM bz_produits;
timezone('Europe/Paris', date_commande)                               -- heure locale -> TIMESTAMPTZ
COPY (...) TO 'x.parquet' (FORMAT parquet, COMPRESSION zstd);
SELECT * FROM parquet_metadata('data/bronze/commandes.parquet');
SUMMARIZE SELECT * FROM 'data/bronze/clients.parquet';
EXPLAIN ANALYZE SELECT ...;                                           -- se lit de bas en haut
```
```bash
python generer_breval.py --echelle 10 --graine 42   # stdlib Python 3.12+, MANIFEST.json (SHA-256)
docker compose up -d                                # postgres:17, wal_level=logical (pour M34)
```
- **Fichiers** : `breval/data/raw/` (erp/*.csv, sav/tickets_sav.jsonl, documents/), `data/bronze/`, `data/silver/` (+ `quarantaine.parquet`), `data/gold/`, entrepôt `data/breval.duckdb`. Scripts : `vers_bronze.py`, `vers_silver.py`, `sql/scd2_dim_client.sql`, `sql/gold.sql`, `sql/controles.sql`.
- **Jeu échelle 1** : 5 075 clients, 120 240 lignes de commandes (120 000 distinctes), 335 153 lignes, 9 048 tickets, 126 documents, 250 clients dans `clients_maj_2026-11-01`. Période : 1er janv. 2024 → 31 oct. 2026.
- **Après nettoyage** : 119 989 commandes, 334 951 lignes, 213 en quarantaine, 5 000 clients, `dim_client` 5 130 versions (5 050 courantes), `fait_ventes` 319 140 lignes.
- **DuckDB** : doc 2.0 LTS (nov. 2026), row groups d'environ 122 880 lignes, `.pl()` vers Polars (`lazy=True` pour un LazyFrame).
- **Corpus IA** : JSONL pour prototyper, puis shards Parquet ou Arrow de 50 à 500 Mo.
- **Salaires (APEC)** : 80 % des offres entre 35 et 60 k€, moyenne d'environ 47 k€. ROME M1811.

## Pour aller plus loin
- [O'Reilly — Fundamentals of Data Engineering](https://oreilly.com/library/view/fundamentals-of-data/9781098108298)
- [DuckDB — documentation](https://duckdb.org/docs/)
- [Apache Parquet — documentation](https://parquet.apache.org/)

## Auto-test (3 questions — réponses en bas de fiche)
1. Pourquoi Avro plutôt que Parquet pour un message Kafka ?
2. Un client nantais déménage le 1er novembre 2026. Avec une SCD 2, à quelle ville va son CA d'octobre ?
3. Le contrôle « CA gold = CA silver » est vrai. Le CA est-il exact ?

---
**Réponses.** 1) Avro est orienté ligne : il sérialise un enregistrement à la fois et gère l'évolution de schéma. Parquet n'est efficace que sur de gros lots. 2) À Nantes : la jointure par intervalle `valide_du` / `valide_au` prend la version en vigueur à la date de commande. 3) Non. Le contrôle prouve seulement que rien n'a été perdu ni doublé entre silver et gold, pas que la source est juste.
