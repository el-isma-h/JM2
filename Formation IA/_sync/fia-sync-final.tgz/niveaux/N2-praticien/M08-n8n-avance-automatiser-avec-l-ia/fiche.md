---
module: M08
title: "Fiche mémo — n8n avancé : automatiser avec l'IA"
---
# Fiche mémo — M08 · n8n avancé : automatiser avec l'IA

> En une phrase : dans n8n, tout est un tapis roulant d'items ; on protège chaque poste contre les pannes, on ne met un agent que là où une chaîne ne suffit pas, et aucune réponse ne sort sans validation humaine.

## Les 7 idées à retenir
1. **Tout est un tableau d'items** `{ json, binary }` : un nœud qui reçoit 50 items s'exécute 50 fois. Regardez le compteur avant tout envoi (`L032`).
2. **Expressions** : `$json` = le colis du poste précédent ; `$('Nom').item` = le même colis vu à un autre poste ; `.first()` = une valeur commune (`L032`).
3. **Trois étages anti-panne** : nœud (Retry On Fail, sortie *error*), workflow (Stop and Error), instance (Error Workflow sur deux canaux) (`L033`).
4. **Grappe IA** : un nœud racine + des sous-nœuds ; le Chat Model est toujours obligatoire. « Transformer ce texte en ce texte » = **chaîne** ; séquence d'actions qui dépend du contenu = **agent** (`L034`).
5. **RAG = un bibliothécaire** : charger → découper → vectoriser → stocker, puis chercher → générer. Même modèle d'embeddings des deux côtés (`L035`).
6. **Webhook = porte d'entrée** : toujours une serrure (Header Auth) ; la Test URL ne vit que pendant l'écoute (`L036`).
7. **Auto-héberger = acheter sa maison** : HTTPS par proxy, PostgreSQL, sauvegardes testées, et la clé `N8N_ENCRYPTION_KEY` gardée à part (`L037`, `L038`).

## Le schéma à connaître

```mermaid
flowchart LR
  A["Demande entrante<br/>webhook ou e-mail"] --> B["Normaliser<br/>+ accusé de réception"]
  B --> C{"Text Classifier<br/>Haiku 5.5"}
  C -- "facturation, technique, livraison" --> D["AI Agent Sonnet 5.5<br/>+ base_support (RAG)"]
  C -- "réclamation, autre" --> E["Escalade humaine"]
  D --> F{"Confiance basse ?"}
  F -- "oui" --> E
  F -- "non" --> G["Slack : Send and Wait<br/>Approuver / Rejeter"]
  G -- "approuvé" --> H["Gmail Reply + journal"]
  G -- "rejeté" --> I["Journal : à reprendre"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Split Out / Aggregate | Découper un colis en N / empiler N colis dans un carton |
| Idempotent | L'interrupteur « allumer » : deux appuis, un seul effet |
| Sous-workflow | La pâte brisée qu'on écrit une fois et que plusieurs recettes appellent |
| `$fromAI` | Laisser le modèle remplir un paramètre d'outil |
| Clé de session | Le numéro de dossier d'une conversation, un par client |
| Chunk / overlap | Une part de gâteau / la crème laissée au bord pour ne rien couper net |
| Scopes OAuth2 | Les cases cochées sur la procuration que vous signez |
| Send and Wait | Le workflow se met en pause jusqu'au clic humain |

## Les pièges classiques
- Renommer un nœud : toutes les expressions `$('Ancien nom')` cassent. Nommez dès le départ.
- Le nœud Code doit renvoyer `[{ json: {…} }]`, jamais un objet nu.
- Retry sur une création non idempotente : doublons. Vérifiez « existe déjà ? » avant.
- Un AI Agent partout : 3 à 10 fois plus d'appels, tests impossibles. Commencez par la chaîne.
- Clé de session fixe : tous les clients partagent la même conversation.
- Collection Qdrant en 1 536 dimensions + embeddings Ollama en 768 : « dimension mismatch ».
- Supprimer un fichier de Drive ne supprime pas ses vecteurs : purgez les chunks de la source.
- Exposer le port 5678 en clair sur Internet.

## Les commandes / chiffres / dates utiles
- **Mnémo des 3 sauvegardes « B-V-C »** : **B**ase PostgreSQL · **V**olume `n8n_data` · **C**lé de chiffrement (séparément). Testez la restauration chaque trimestre.
- Variables : `GENERIC_TIMEZONE=Europe/Paris`, `WEBHOOK_URL`, `N8N_EDITOR_BASE_URL`, `EXECUTIONS_DATA_PRUNE=true`. Mise à jour : `docker compose pull && docker compose up -d`.
- Error Workflow : `{{ $json.execution.url }}`, `{{ $json.execution.lastNodeExecuted }}`.
- AI Agent : *Max Iterations* 5 à 10 ; Simple Memory 5 tours par défaut ; pour Claude, laissez la **température vide** (refusée avec la version d'API 2026-10-21).
- Chunking de départ : 800 à 1 500 caractères, overlap 10 à 20 %. Anthropic ne propose pas d'embeddings.
- Coûts (nov. 2026) : 1 000 e-mails classés par Haiku 5.5 ≈ 0,04 $ ; assistant de support complet (1 540 tickets/mois) ≈ 20 à 25 €/mois.
- Objectifs de livraison : ≥ 90 % de bonnes catégories, ≥ 80 % de réponses conformes, **0 réclamation non escaladée**.
- **n8n 3.0** (27 oct. 2026) : changements incompatibles, vérifiez votre version. Certification officielle n8n : **pas encore lancée** (reportée à fin T4 2026) ; l'Academy (N8N101, 102, 103 ; 70 % requis) délivre des badges d'achèvement. MCP : spécification stable **2026-07-28**.

## Pour aller plus loin
- [n8n Academy — N8N103 In Practice](https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about)
- [n8n Docs — Store and search data with vectors](https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md)
- [n8n Docs — Install using Docker Compose](https://docs.n8n.io/deploy/host-n8n/install-options/install-using-docker-compose.md)

## Auto-test (3 questions — réponses en bas de fiche)
1. Une API renvoie `{ "commandes": [ …2 commandes… ] }` : combien d'items, et comment envoyer un e-mail par commande ?
2. Pourquoi classer avec Haiku 5.5 et rédiger avec Sonnet 5.5 ?
3. Un collègue a régénéré `N8N_ENCRYPTION_KEY` : que faire ?

---
**Réponses** — 1. Un seul item ; ajoutez un Split Out sur `commandes`. 2. Classer est simple : Haiku suffit pour vingt fois moins cher ; la rédaction client justifie Sonnet. 3. Restaurer l'ancienne clé et redémarrer ; si elle est perdue, ressaisir toutes les credentials.
