---
id: L051
module: M12
level: N2
title: "Custom GPT, Projets Claude, Copilot Studio"
minutes: 60
objectives:
  - "Expliquer ce qu'est un assistant spécialisé (Projet Claude, GPT personnalisé, agent Copilot Studio) et ce qui le distingue d'une simple conversation"
  - "Construire un assistant spécialisé complet : instructions, connaissances, outils ou actions, réglages de partage"
  - "Comparer les trois plateformes selon le public, la confidentialité, les outils connectables et le coût"
  - "Évaluer un assistant avec un jeu de questions-tests avant de le partager à une équipe"
skills: ["C2.2"]
sources:
  - { title: "Claude Academy — Claude 101 (projects, artifacts, skills, connectors)", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "Claude Academy — Introduction to Claude Cowork", url: "https://academy.claude.com/courses/introduction-to-claude-cowork", lang: "en" }
  - { title: "Anthropic — Agent Skills overview", url: "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview", lang: "en" }
  - { title: "Claude Code Docs — Skills", url: "https://code.claude.com/docs/en/skills.md", lang: "en" }
  - { title: "OpenAI Academy — catalogue des cours", url: "https://academy.openai.com/pages/courses", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "Claude Support (centre d'aide)", url: "https://support.claude.com/", lang: "en" }
---

# Custom GPT, Projets Claude, Copilot Studio

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 12

## 🎯 Ce que vous saurez faire
- Reconnaître les **quatre briques** d'un assistant spécialisé : instructions, connaissances, outils, partage.
- Créer un Projet Claude et un GPT personnalisé opérationnels pour un cas métier (cabinet comptable, RH, commerce).
- Situer Microsoft Copilot Studio dans le paysage et savoir quand il est le bon choix.
- Tester un assistant avec une grille de 10 questions avant de le mettre entre les mains de vos collègues.

> 🧭 **En clair** — Une conversation ordinaire avec une IA, c'est un intérimaire qui découvre l'entreprise chaque matin. Un assistant spécialisé, c'est un collaborateur qui a reçu, une fois pour toutes, quatre choses : sa **fiche de poste** (les instructions), son **classeur de référence** (les connaissances), ses **outils** (accès à l'agenda, au logiciel de facturation…) et son **badge** (qui peut travailler avec lui). Projet Claude, GPT personnalisé et Copilot Studio sont trois agences qui proposent ce même collaborateur ; on choisit surtout selon l'endroit où vivent déjà vos données et vos équipes (Google, Microsoft, ou ni l'un ni l'autre). Et comme pour tout nouveau collaborateur, on le teste avant de lui confier des clients.

## 1. De la conversation à l'assistant : pourquoi « spécialiser » ?

Imaginez un nouveau collaborateur brillant mais amnésique : chaque matin, il arrive sans souvenir de l'entreprise, des procédures ni du ton maison. C'est exactement ce qui se passe quand vous ouvrez une nouvelle conversation avec Claude ou ChatGPT. Vous réexpliquez le contexte, vous recollez le même modèle d'e-mail, vous rappelez « ne tutoie jamais les clients ».

Un **assistant spécialisé** résout ce problème en **figeant** ce contexte une bonne fois pour toutes. Toutes les plateformes, sous des noms différents, assemblent les mêmes briques :

| Brique | Rôle | Projet Claude | GPT personnalisé (ChatGPT) | Copilot Studio (Microsoft) |
|---|---|---|---|---|
| **Instructions** | Le « contrat » permanent : rôle, ton, règles, format | Instructions du projet | Instructions du GPT | Instructions / topics |
| **Connaissances** | Documents que l'assistant consulte (procédures, grilles tarifaires) | Fichiers du projet | Fichiers « Knowledge » | Sources de connaissances (SharePoint, sites, fichiers) |
| **Outils** | Ce que l'assistant peut *faire* (chercher sur le web, lire un agenda, appeler une API) | Connecteurs, skills, Cowork | Capacités intégrées + « Actions » (API) | Connecteurs Power Platform, flux Power Automate |
| **Partage** | Qui peut l'utiliser et comment | Personnel / équipe (Team, Enterprise) | Privé / lien / boutique GPT | Teams, site web, canaux Microsoft 365 |

> 💡 **À retenir** — Les instructions sont un **prompt système permanent** (voir le module M04). Tout ce que vous avez appris sur la structure rôle / contexte / tâche / format / contraintes s'applique, avec une différence : ici le prompt est écrit *une fois* et relu à *chaque* conversation. Il doit donc être plus général et plus prudent.

La leçon L050 (module M11) a détaillé la brique « connaissances » et ses limites (taille, découpage, citation des sources). Cette leçon se concentre sur l'assemblage complet et sur le choix de la plateforme.

```quiz
{
  "q": "Dans un assistant spécialisé, à quoi servent les « outils » ?",
  "options": [
    "À définir le ton et les règles de l'assistant",
    "À agir : chercher sur le web, appeler une API",
    "À stocker les documents de référence de l'équipe",
    "À choisir qui peut utiliser l'assistant"
  ],
  "answer": 1,
  "explanation": "Instructions = règles, connaissances = documents, partage = accès. Les outils sont ce que l'assistant peut faire concrètement dans d'autres logiciels. Lire un agenda ou envoyer un e-mail en font aussi partie."
}
```


## 2. Projet Claude : l'espace de travail persistant

Dans Claude (web, desktop, mobile), un **Projet** (*project*) est un dossier qui regroupe des conversations partageant les mêmes instructions et les mêmes fichiers. Le cours officiel *Claude 101* (Claude Academy, nov. 2026) consacre une section entière à « Organizing your work and knowledge : projects, artifacts, skills ».

### 2.1 Créer un projet pas à pas

1. Dans la barre latérale, choisissez **Projets** → **Nouveau projet**. Donnez-lui un nom explicite : « Réponses devis — Menuiserie Dubois ».
2. Ouvrez **Instructions du projet** et collez votre contrat permanent (exemple ci-dessous).
3. Ajoutez les **fichiers de connaissance** : grille tarifaire en PDF, 3 devis exemplaires, charte de communication. Restez sobre : des documents courts et à jour valent mieux qu'une archive de 200 pages.
4. Démarrez une conversation *dans* le projet : les instructions et les fichiers sont automatiquement pris en compte.
5. Sur les offres Team / Enterprise, un projet peut être **partagé** avec des collègues, qui héritent du même contexte.

```markdown
# Instructions du projet « Réponses devis — Menuiserie Dubois »

## Rôle
Vous êtes l'assistant administratif de la Menuiserie Dubois (Nantes, 6 salariés).
Vous aidez Claire, la responsable administrative, à répondre aux demandes de devis.

## Règles absolues
- Vouvoiement systématique. Ton chaleureux mais professionnel.
- Ne jamais inventer un prix : si une prestation n'est pas dans la grille tarifaire
  (fichier « grille-2026.pdf »), écrire « [À CHIFFRER PAR CLAIRE] ».
- Ne jamais promettre un délai inférieur à 3 semaines.
- Toujours terminer par la formule de politesse du fichier « charte.md ».

## Format de sortie
1. Un résumé en 2 lignes de la demande client.
2. Le brouillon d'e-mail, prêt à copier.
3. Une liste « Points à vérifier » si des informations manquent.
```

Remarquez la règle « [À CHIFFRER PAR CLAIRE] » : c'est une **soupape de sécurité**. Plutôt que d'espérer que le modèle n'hallucine pas un prix (n'invente pas, avec assurance, une information fausse), vous lui donnez une sortie de secours explicite. Cette technique, enseignée dans la page officielle « Prompting best practices », vaut pour toutes les plateformes.

> 💡 **Autrement dit** — La soupape, c'est le panneau « en cas de doute, appelez le chef ». Plutôt que d'interdire seulement à l'assistant d'inventer, vous lui donnez une sortie honorable et visible : un trou balisé dans le texte que Claire complètera elle-même.


### 2.2 Les outils : connecteurs, skills et Cowork

Un Projet Claude devient un véritable **agent** quand on lui branche des outils :

- **Connecteurs** (serveurs MCP) — des « prises » standard qui relient Claude à vos outils ; voir le lexique — : Google Drive, calendrier, outils métier… Le cours *Claude 101* les aborde dans « Expanding Claude's reach : connecting your tools ».
- **Skills** (*Agent Skills*) : un dossier contenant un fichier `SKILL.md` (en-tête `name` + `description`, puis des instructions en Markdown) — Markdown : texte simple où `#` fait un titre et `-` une puce — et éventuellement des scripts ou des modèles. Anthropic en fournit des prêts à l'emploi (pptx, xlsx, docx, pdf) et l'a publié comme standard ouvert (un format public que d'autres éditeurs peuvent adopter librement) ; le même skill est lu par Claude.ai, Claude Code et l'API. Pensez-y comme une **fiche de procédure** que l'assistant ouvre seulement quand elle est pertinente (chargement progressif : seuls le nom et la description restent en contexte en permanence).
- **Claude Cowork** (application desktop, offres Pro/Max) : Claude travaille directement dans vos dossiers, dans Chrome et dans Microsoft 365. Le cours *Introduction to Claude Cowork* (2 h 30, gratuit, nov. 2026) enseigne les « global instructions », les projets, les skills et les plugins d'équipe.

```markdown
---
name: devis-menuiserie
description: Rédige un brouillon de réponse à une demande de devis de menuiserie selon la charte Dubois. À utiliser quand l'utilisateur colle un e-mail client contenant une demande de prix ou de travaux.
---

# Procédure de réponse à une demande de devis
1. Identifier : type d'ouvrage, dimensions, matériau, délai souhaité, adresse du chantier.
2. Comparer avec la grille tarifaire jointe. Prix absent → écrire « [À CHIFFRER PAR CLAIRE] ».
3. Rédiger l'e-mail selon le modèle `templates/reponse-devis.md`.
4. Lister les informations manquantes à demander au client.
```

> 🔗 **Documentation officielle** — [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 et [Skills dans Claude Code](https://code.claude.com/docs/en/skills.md) 🇬🇧.

```mission
{
  "title": "Les deux champs obligatoires d'un fichier SKILL.md",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview",
  "steps": ["Ouvrez la page « Agent Skills overview » de la documentation Claude", "Repérez la structure d'un skill et l'en-tête (frontmatter) du fichier SKILL.md", "Cherchez ce que Claude garde en permanence en contexte et ce qu'il ne charge qu'au besoin"],
  "question": "Quels sont les deux champs obligatoires de l'en-tête d'un SKILL.md, et quelle partie du skill Claude garde-t-il en permanence en mémoire de travail ?",
  "hint": "Le principe s'appelle le chargement progressif (progressive disclosure).",
  "answer": "Les champs `name` et `description` ; seuls ces métadonnées (nom + description) restent chargées en permanence ; le corps du SKILL.md puis les fichiers et scripts associés ne sont lus que lorsque le skill devient pertinent (relevé nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```


> ⚠️ **Piège fréquent** — Confondre *fichier de connaissance* et *skill*. Un fichier de connaissance est une **donnée** (la grille tarifaire) ; un skill est une **procédure** (comment répondre). Mettre la procédure dans un PDF de 40 pages, c'est obliger l'assistant à la retrouver à chaque fois ; l'écrire dans un `SKILL.md` de 30 lignes, c'est la lui donner structurée.

> 🧭 **Pas à pas pour débutant** — Pour essayer un skill dans Claude.ai : enregistrez le texte de l’exemple de cette section 2.2 (de `name:` à la fin) dans un fichier nommé exactement `SKILL.md`, en encadrant les deux premières lignes (`name:` et `description:`) par une ligne `---` au-dessus et une ligne `---` en dessous (c’est ainsi que Claude reconnaît l’en-tête), placez-le dans un dossier `devis-menuiserie`, puis compressez ce dossier (clic droit → *Compresser* sur Mac, *Envoyer vers → Dossier compressé* sur Windows). Dans Claude, ouvrez **Paramètres → Capacités** (*Capabilities*), section **Skills**, et importez le fichier `.zip` ; la fonction peut demander une offre payante et l'activation de l'exécution de code. Les libellés exacts évoluent : en cas de doute, suivez la page d'aide « Skills » du centre d'aide Claude.

```quiz
{
  "type": "mise_en_situation",
  "q": "Vous voulez que l'assistant applique toujours la même méthode en 4 étapes pour répondre à une demande de devis. Où l'écrivez-vous ?",
  "options": [
    "Dans un PDF de 40 pages déposé en connaissance",
    "Dans un skill (SKILL.md) court et structuré",
    "Dans le nom du projet",
    "Nulle part : l'assistant la devinera"
  ],
  "answer": 1,
  "explanation": "Une procédure se range dans un skill : elle est structurée et chargée quand elle est utile. Les fichiers de connaissance servent aux données (la grille tarifaire)."
}
```


## 3. GPT personnalisé : le « GPT Builder » d'OpenAI

Côté ChatGPT, l'équivalent s'appelle un **GPT personnalisé** (*custom GPT*). Le principe est identique : nom, description, instructions, fichiers de connaissance, capacités (navigation web, génération d'images, interpréteur de code / analyse de données) — l'interpréteur exécute de petits programmes pour calculer ou analyser un fichier, voir L055 — et, pour les plus avancés, des **Actions**.

### 3.1 Les Actions : brancher une API sans coder

Une **Action** décrit, dans un fichier au format **OpenAPI** (un standard de description d'API), ce que le GPT peut appeler : « GET /disponibilites?date=… renvoie les créneaux libres ». Le modèle lit cette description, décide quand appeler l'API, et interprète la réponse. Vous ne codez pas l'appel ; vous **décrivez** l'API. C'est exactement le mécanisme du *tool use* vu au module M06 (« utilisation d'outils » : le modèle demande lui-même à appeler une fonction), emballé dans une interface graphique.

> 💡 **Autrement dit** — Une Action, c'est le **menu affiché au comptoir** d'un service : « pour connaître les créneaux libres, demandez *disponibilités* en donnant une date ». Le fichier OpenAPI est ce menu, écrit dans un format que l'IA sait lire ; `GET /disponibilites?date=…` signifie simplement « demander la liste des disponibilités pour telle date ». L'IA lit le menu, passe la commande au bon moment et vous rapporte le plat. Ce menu est en général fourni par l'éditeur du logiciel ou rédigé par un développeur : votre rôle est de décider **quelles commandes** l'assistant a le droit de passer.

Exemple concret pour un cabinet comptable : un GPT « Assistant relance clients » dont l'Action interroge l'API du logiciel de facturation pour lister les factures impayées, puis rédige les relances selon le ton du cabinet. Le GPT **lit** ; un humain **envoie**.

```mermaid
flowchart LR
  U["Utilisateur :<br/>« Qui n'a pas payé ? »"] --> G["GPT personnalisé"]
  G -->|"lit la description OpenAPI<br/>et décide d'appeler"| A["Action :<br/>GET /factures?statut=impayee"]
  A --> L["Logiciel de facturation"]
  L -->|"liste des impayés"| G
  G --> R["Brouillons de relance"] --> H["Un humain relit et envoie"]
```


### 3.2 Partage et boutique

Un GPT se partage en trois niveaux : **privé**, **par lien**, ou **public** dans la boutique de GPTs. Pour les comptes Business / Enterprise, un quatrième niveau limite le partage à l'organisation. Avant tout partage, posez-vous la question de la leçon L028 (module M07) : les fichiers de connaissance contiennent-ils des données personnelles ? Si oui, le partage « par lien » est une fuite potentielle.

OpenAI propose, dans son Academy gratuite (nov. 2026), le parcours « Apply AI at Work » et le cours « Agents and Workflows » qui couvrent précisément la délégation à des assistants : contexte à fournir, production attendue, limites, relecture, réutilisation. C'est une excellente révision en anglais.

> 🔗 **Documentation officielle** — [OpenAI Academy — cours](https://academy.openai.com/pages/courses) 🇬🇧 ; la page d'aide « Creating a GPT » du centre d'aide OpenAI (help.openai.com) décrit l'interface du Builder — à consulter pour les captures à jour.

## 4. Microsoft Copilot Studio : l'assistant « entreprise Microsoft 365 »

**Copilot Studio** est l'outil low-code de Microsoft (où l'on construit surtout en cliquant, avec un peu de configuration) pour créer des agents (anciennement « copilots ») déployés dans Teams, SharePoint ou un site web, alimentés par les données de Microsoft 365 et connectés à la Power Platform (Power Automate pour les flux, Dataverse pour les données, plus de mille connecteurs) — Power Automate est l'équivalent Microsoft de Make ou Zapier ; Dataverse, sa base de données —. Il hérite de l'ancien Power Virtual Agents, d'où une logique un peu différente : des **topics** (sujets) déclenchés par des phrases, enrichis par de l'IA générative sur des sources de connaissances.

| Critère | Quand Copilot Studio est le bon choix |
|---|---|
| Vos données | Déjà dans SharePoint, OneDrive, Dynamics, Dataverse |
| Vos utilisateurs | Vivent dans Teams toute la journée |
| Gouvernance | La DSI exige que tout reste dans le tenant Microsoft 365 (identités Entra ID, politiques DLP) — le tenant est l'espace Microsoft propre à votre organisation ; Entra ID, l'annuaire des comptes ; DLP (*data loss prevention*), les règles anti-fuite de données — |
| Automatisation | Vous voulez déclencher des flux Power Automate depuis l'agent |

Aucune page Copilot Studio n'a pu être vérifiée dans notre dossier de recherche (nov. 2026) : les noms des fonctionnalités, les licences et les prix évoluent vite. Référez-vous à la documentation Microsoft Learn (section « Microsoft Copilot Studio ») avant tout chiffrage, et vérifiez en particulier le modèle de facturation (par messages ou par licence utilisateur).

> ⚠️ **Piège fréquent** — Choisir la plateforme par habitude plutôt que par critères. Un commerçant indépendant sous Google Workspace n'a aucune raison d'aller sur Copilot Studio ; une direction juridique d'un grand groupe sous Microsoft 365 n'a souvent pas le droit d'envoyer ses contrats dans un GPT public.

## 5. Choisir : la grille de décision

| Critère | Projet Claude | GPT personnalisé | Copilot Studio |
|---|---|---|---|
| Mise en route | Minutes | Minutes | Heures (licences, tenant) |
| Fenêtre de contexte (nov. 2026) | 1M tokens sur les modèles 5.5 | 1,05M tokens (famille GPT-6) | Dépend du modèle sous-jacent |
| Outils | Connecteurs MCP, skills, Cowork (fichiers, Chrome, M365) | Capacités intégrées + Actions OpenAPI | Connecteurs Power Platform, flux |
| Partage | Projet d'équipe (Team / Enterprise) | Lien, organisation, boutique | Teams, site web, canaux |
| Données d'entraînement | Voir la politique de confidentialité de l'offre choisie (offres pro : pas d'entraînement par défaut) | Idem : vérifier les réglages « Data controls » | Reste dans le tenant Microsoft |
| Public idéal | Équipes qui rédigent, analysent, codent | Grand public, écosystème ChatGPT | Organisations Microsoft 365 |

Les chiffres de contexte proviennent des pages officielles de modèles (Anthropic, OpenAI) lues le 1er novembre 2026 ; ce qu'une plateforme *grand public* expose réellement peut être inférieur à la limite de l'API.

```mission
{
  "title": "Ce qu'enseigne le cours « Introduction to Claude Cowork »",
  "url": "https://academy.claude.com/courses/introduction-to-claude-cowork",
  "steps": ["Ouvrez la page du cours sur Claude Academy", "Repérez sa durée et le nombre de leçons", "Lisez le plan de la partie « Make Claude Cowork yours »"],
  "question": "Quelle est la durée du cours et quels sont les quatre thèmes de la partie « Make Claude Cowork yours » ?",
  "hint": "On y retrouve deux briques de cette leçon : les projets et les skills.",
  "answer": "Environ 2 h 30 (14 leçons + quiz) ; partie 3 : « Get better results faster », « Standing context — Global instructions and projects », « Skills — teach Claude Cowork your way », « Plugins — encode your team's expertise » (relevé nov. 2026).",
  "xp": 10
}
```

## 6. Tester avant de partager : la grille des 10 questions

Un assistant non testé est un collègue qu'on n'a pas formé. Avant de partager quoi que ce soit, constituez un **jeu de test** de 10 questions, réparties ainsi :

- 4 questions **faciles** dont la réponse est dans les fichiers (« Quel est le tarif d'une fenêtre PVC double vitrage 120 × 120 ? »).
- 3 questions **pièges** dont la réponse n'est **pas** dans les fichiers (l'assistant doit dire qu'il ne sait pas, ou renvoyer vers Claire).
- 2 questions **de ton** (« Tutoie-moi » → il doit refuser poliment ; « Réponds en 10 mots » → il doit respecter le format).
- 1 question **hors sujet** (« Donne-moi une recette de tarte ») → il doit recadrer.

Notez chaque réponse 0 / 1 / 2. Un assistant prêt à partager obtient au moins 16/20 et **zéro** prix inventé. C'est le critère du référentiel C2.2 : « répond correctement à 8 questions sur 10 à partir des documents fournis ; les sources sont citées ».

> 💡 **À retenir** — Les cours Anthropic « Evaluating & Validating Claude's Output » (parcours Associate) et OpenAI « AI Foundations » consacrent tous deux un chapitre à la relecture critique des sorties. Le test n'est pas une option : c'est la moitié du travail.

## 🎮 Défi

Votre collègue a écrit dans les instructions de son GPT : « Sois sympa et réponds à tout. » Trouvez, en moins de deux minutes, trois risques concrets que cette phrase introduit (indice : prix, données personnelles, hors sujet). Puis réécrivez-la en cinq lignes maximum.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : un assistant qui obtient 17/20 à la grille des 10 questions mais invente un prix une fois peut être partagé à l'équipe.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : le seuil est d'au moins 16/20 et zéro prix inventé. Un seul prix inventé suffit à bloquer le partage : renforcez la soupape et retestez."
}
```

## 🧪 Exercice pratique

**Consigne.** Construisez un assistant « Onboarding RH » pour une PME fictive de 40 salariés, sur la plateforme de votre choix (Projet Claude ou GPT personnalisé).

1. Rédigez les instructions (rôle, règles, format) — 15 à 30 lignes.
2. Préparez deux fichiers de connaissance courts : `livret-accueil.md` (horaires, télétravail, mutuelle, tickets restaurant — inventés) et `faq-rh.md` (10 questions-réponses).
3. Ajoutez une règle « soupape » pour toute question sur la paie ou les arrêts maladie (renvoi vers le service RH, jamais de réponse chiffrée).
4. Passez votre assistant à la grille des 10 questions de la section 6 et consignez les scores.

> 🧭 **Pas à pas pour débutant** — Un fichier `.md` (Markdown) est un simple fichier texte. Ouvrez Bloc-notes (Windows) ou TextEdit en mode texte (Mac), écrivez vos titres précédés de `# ` et vos listes précédées de `- `, puis enregistrez sous le nom `livret-accueil.md` (sous Windows, choisissez *Type : Tous les fichiers* pour éviter `.md.txt`). Si c'est trop compliqué, un document Word (`.docx`) ou un fichier `.txt` fonctionne aussi très bien comme fichier de connaissance : l'important est le contenu, court, clair et à jour.

**Critères de réussite.**
- Les instructions contiennent rôle, règles, format et soupape.
- Score ≥ 16/20 à la grille ; les 3 questions pièges obtiennent un « je ne sais pas / voir le service RH ».
- L'assistant cite le fichier source (« d'après le livret d'accueil… ») sur les questions faciles.
- Aucune donnée personnelle réelle dans les fichiers.

<details>
<summary>Corrigé — pistes</summary>

- Soupape type : « Pour toute question concernant la paie, les arrêts maladie ou un cas individuel, répondre uniquement : "Cette question relève du service RH : écrivez à rh@exemple.fr." »
- Règle de citation : « Commencez chaque réponse factuelle par la source entre crochets : [livret-accueil] ou [faq-rh]. »
- Question piège efficace : « Combien de jours de congés me reste-t-il ? » — l'assistant n'a pas accès au SIRH, il doit le dire.
- Si l'assistant invente une réponse à une question piège, ajoutez dans les instructions : « Si l'information ne figure pas dans les fichiers du projet, dites-le explicitement et ne complétez jamais par des connaissances générales. »
</details>

## ✅ Auto-évaluation express

1. Quelle est la différence entre un fichier de connaissance et un skill ?
2. Qu'est-ce qu'une « Action » dans un GPT personnalisé, et quel standard de description utilise-t-elle ?
3. Citez deux critères qui orientent vers Copilot Studio plutôt que vers un Projet Claude.

<details>
<summary>Réponses</summary>

1. Le fichier de connaissance est une donnée consultée (grille, procédure brute) ; le skill est une procédure structurée (`SKILL.md`) chargée uniquement quand elle est pertinente.
2. Une Action décrit une API externe que le GPT peut appeler ; elle est décrite au format OpenAPI. Le modèle décide quand l'appeler et interprète la réponse (mécanisme du tool use).
3. Données déjà dans Microsoft 365 / SharePoint / Dataverse ; utilisateurs dans Teams ; exigence de la DSI que tout reste dans le tenant ; besoin de déclencher des flux Power Automate.
</details>

## 📚 Pour aller plus loin
- [Claude 101 — Claude Academy](https://academy.claude.com/courses/claude-101) 🇬🇧 — 2 h 30 gratuites, badge à la clé : projets, artefacts, skills, connecteurs.
- [Introduction to Claude Cowork](https://academy.claude.com/courses/introduction-to-claude-cowork) 🇬🇧 — instructions globales, projets, skills et plugins dans l'application desktop.
- [Agent Skills overview — Anthropic](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 — le format `SKILL.md` et les skills prêts à l'emploi.
- [OpenAI Academy — catalogue](https://academy.openai.com/pages/courses) 🇬🇧 — parcours « Apply AI at Work » et cours « Agents and Workflows » (badges gratuits).
- [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — human in the loop, limiter les entrées, signalement.

> ✅ **Si vous ne retenez que 3 choses** — 1. Tout assistant spécialisé repose sur quatre briques : instructions (la fiche de poste), connaissances (le classeur), outils (ce qu'il peut faire) et partage (qui l'utilise). 2. Prévoyez une « soupape » dans les instructions — par exemple « [À CHIFFRER PAR CLAIRE] » — pour que l'assistant signale ce qu'il ne sait pas au lieu d'inventer. 3. Choisissez la plateforme selon l'endroit où vivent déjà vos données et vos équipes, et testez avec 10 questions (dont des pièges) avant de partager : au moins 16/20 et zéro prix inventé.

> 🗺️ **Et maintenant ?** — Votre assistant suit des instructions et utilise quelques outils ; la leçon L052 construit dans n8n un véritable agent multi-outils, capable de choisir lui-même quel outil appeler.
