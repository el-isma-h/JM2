---
module: M12
title: "Fiche mémo — Assistants et agents sans code"
---
# Fiche mémo — M12 · Assistants et agents sans code

> En une phrase : un assistant spécialisé, c'est un collaborateur avec une fiche de poste, un classeur, des outils et un badge ; plus on lui donne de pouvoirs (outils, code, écran), plus il faut de garde-fous et de validation humaine.

## Les 7 idées à retenir
1. **Quatre briques partout** : instructions, connaissances, outils, partage — Projet Claude, GPT personnalisé ou Copilot Studio (`L051`).
2. **La soupape** : donner une sortie de secours visible (« [À CHIFFRER PAR CLAIRE] ») plutôt qu'espérer que le modèle n'invente pas (`L051`).
3. **Fichier de connaissance = donnée ; skill = procédure** (`SKILL.md`, chargé seulement quand il sert) ; une **Action** de GPT décrit une API au format OpenAPI (`L051`).
4. **Un agent multi-outils ne voit que les étiquettes** : nom, description, paramètres. Dire quand utiliser l'outil, quand ne pas l'utiliser, ce qu'il renvoie (`L052`).
5. **Quatre garde-fous** : lecture seule d'abord · validation humaine (*Send and Wait*) avant d'agir · *Max Iterations* bas (5 à 8) · journal et évaluation (`L052`).
6. **Vibe coding** : vous décrivez (`SPEC.md`), l'agent construit, vous testez et refusez. Claude Code travaille chez vous ; Lovable, Bolt, v0 sur leur terrain : exigez l'export du code (`L053`).
7. **Computer use = dernier recours** : l'agent regarde l'écran et clique ; lent, cher, fragile, et exposé à toute page piégée (`L054`).

## Le schéma à connaître

```mermaid
flowchart TD
  A{"Le service a-t-il une API,<br/>un connecteur MCP ou un nœud n8n ?"} -- "Oui" --> B["API / connecteur<br/>fiable, rapide, bon marché"]
  A -- "Non" --> C{"Tâche 100 % répétitive<br/>sur interface stable ?"}
  C -- "Oui" --> D["Automatisation classique<br/>script, RPA, macro"]
  C -- "Non" --> E["Agent à écran<br/>en lecture, surveillé"]
  B --> F{"Action irréversible<br/>ou financière ?"}
  D --> F
  E --> F
  F -- "Oui" --> G["Un humain valide"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Instructions | La fiche de poste relue à chaque conversation (prompt système permanent) |
| Skill | Une fiche de procédure `SKILL.md` ouverte seulement quand elle est utile |
| Action (GPT) | Une API décrite en OpenAPI que le GPT peut appeler |
| Agent Builder (n8n) | Un agent « produit » déployé dans Slack, Teams, Telegram (préversion) |
| Mode plan | Claude Code réfléchit et propose sans toucher aux fichiers (`Shift+Tab`) |
| Computer use / browser use | L'agent pilote un ordinateur entier / seulement un navigateur |
| Injection indirecte | Un ordre caché dans une page, un e-mail ou une image que l'agent lit |

## Les pièges classiques
- « Sois sympa et réponds à tout » : prix inventés, données exposées, hors sujet.
- Mettre une procédure dans un PDF de 40 pages au lieu d'un `SKILL.md` de 30 lignes.
- Partager « par lien » un GPT dont les fichiers contiennent des données personnelles.
- Brancher « Gmail : envoyer » directement sur un agent : une injection suffit pour que la boîte parte ailleurs.
- La meilleure défense est l'**absence de capacité** : pas d'outil « liste des clients », pas de fuite possible.
- Sauter toutes les permissions de Claude Code dans un dossier qui contient autre chose.
- Mettre une clé API dans une page web : tout visiteur peut la lire.
- Laisser un agent à écran travailler avec **vos** sessions ouvertes (banque, messagerie, impôts).

## Les commandes / chiffres / dates utiles
- **Charte agent à écran, mnémo « I-C-P-L-V-S-J-D »** : **I**solement (profil ou VM dédiés) · **C**omptes à droits minimaux · aucun **P**aiement · **L**iste blanche de sites · **V**alidation humaine · **S**urveillance en direct · **J**ournal · **D**onnées minimisées.
- **Grille de test d'un assistant** : 10 questions (4 faciles, 3 pièges, 2 de ton, 1 hors sujet), notées 0/1/2 ; seuil **≥ 16/20** et **zéro** prix inventé.
- Claude Code : `/init` (crée `CLAUDE.md`), `Shift+Tab` deux fois (mode plan), `/help`, `/cost`, `/clear`, `/compact`. Boucle : explorer → planifier → coder → tester → commit.
- n8n : `$fromAI('nom', 'description', 'type')` ; *Max Iterations* 5 à 8 ; boucle de 8 tours sur Sonnet 5.5 ≈ 0,10 à 0,15 $.
- OWASP Top 10 LLM 2026 : **LLM01** injection (aussi multimodale) · **LLM03** agentivité excessive · **LLM10** gestion incorrecte des sorties (code généré non relu).
- Dates : computer use d'Anthropic en bêta le **22 oct. 2024** ; Operator en janv. 2025, fusionné dans ChatGPT agent en juillet 2025 ; « vibe coding », mot de l'année Collins 2025.

## Pour aller plus loin
- [Claude 101 — Claude Academy](https://academy.claude.com/courses/claude-101)
- [n8n Docs — Human in the loop for tools](https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md)
- [Claude Code 101 — Claude Academy](https://academy.claude.com/courses/claude-code-101)

## Auto-test (3 questions — réponses en bas de fiche)
1. Que « voit » le modèle d'un outil n8n quand il choisit ?
2. À quoi sert le mode plan de Claude Code ?
3. Pourquoi un agent à écran est-il plus lent et plus cher qu'un agent à API ?

---
**Réponses** — 1. Seulement le nom, la description et le schéma des paramètres, jamais le workflow. 2. À faire réfléchir et proposer l'agent sans modifier de fichier, pour valider l'approche avant de coder. 3. Chaque tour envoie une capture d'écran (beaucoup de tokens) et chaque action doit être vérifiée à l'image suivante.
