---
module: M10
title: "Fiche mémo — LLM locaux : faire tourner l'IA sur sa machine"
---
# Fiche mémo — M10 · LLM locaux : faire tourner l'IA sur sa machine

> En une phrase : un LLM local, c'est un chef cuisinier à domicile ; la mémoire décide quel chef tient dans la cuisine, la bande passante décide à quelle vitesse il cuisine, et l'API compatible OpenAI lui fait parvenir les commandes de tous vos logiciels.

## Les 7 idées à retenir
1. **Poids ouverts = fichier téléchargeable** ; rien ne quitte la machine. Mais « ouvert » ne veut pas dire « libre » : lisez la licence (`L041`).
2. **Quatre arguments** : confidentialité, coût (fixe au lieu de variable, temps humain compris), latence et disponibilité, souveraineté. Revers : moins capable qu'un modèle frontière (`L041`).
3. **Formule de mémoire** : Go ≈ milliards × bits ÷ 8 × 1,1, **plus** le KV cache du contexte. Téléchargez en 4 bits (Q4_K_M) par défaut (`L042`).
4. **La bande passante fait la vitesse** : tok/s ≈ Go/s ÷ Go lus par token. Les MoE (peu de paramètres actifs) sont les rois du local (`L042`).
5. **Ollama** : un serveur sur `localhost:11434`, des commandes à la Docker, un Modelfile pour fixer la fiche de poste (`L043`).
6. **Un utilisateur ou une équipe ?** LM Studio / Jan pour un poste ; Open WebUI au-dessus d'Ollama pour une équipe (`L044`).
7. **Choisir son modèle** par usage, par mémoire et par licence, puis tester en français sur vos documents ; brancher ensuite via la `base_url` (`L045`, `L046`).

## Le schéma à connaître

```mermaid
flowchart TD
  Q1{"Données interdites<br/>de sortie ?"} -- "Oui" --> L["LLM local"]
  Q1 -- "Non" --> Q2{"Volume élevé<br/>et régulier ?"}
  Q2 -- "Oui" --> G["Local ou GPU loué<br/>calcul à l'appui"]
  Q2 -- "Non" --> Q3{"Meilleur raisonnement<br/>du marché exigé ?"}
  Q3 -- "Oui" --> A["API cloud frontière<br/>+ contrat adapté"]
  Q3 -- "Non" --> S["SaaS ou API<br/>selon les compétences"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Quantization | Ranger les ingrédients dans des bocaux plus petits : 4 fois moins de place, goût presque intact |
| GGUF / MLX | Format de fichier pour llama.cpp, Ollama, LM Studio / format Apple Silicon |
| KV cache | Le bloc-notes du chef : il grossit avec la longueur du texte lu |
| Dense / MoE | Le chef qui goûte tout / la brigade où 2 ou 3 spécialistes interviennent |
| Modelfile | La fiche de poste collée sur le frigo (prompt système, paramètres) |
| `base_url` | L'adresse de livraison de la commande : local ou cloud |
| `host.docker.internal` | Depuis un conteneur, « la machine hôte » |

## Les pièges classiques
- Lancer un modèle « cloud » du catalogue Ollama sur des données confidentielles : vérifiez `ollama ps`.
- Oublier le contexte : un 14B qui « tient » déborde sur un PDF de 60 pages, la vitesse s'effondre de 5 à 10 fois.
- Comparer les machines sur la seule mémoire : sur un 27B, une RTX 5090 écrit 47 à 59 tok/s, un DGX Spark 10,8.
- « Local » ≠ « sécurisé » : dépôts officiels, `safetensors` ou GGUF, pare-feu, pas d'interface ouverte sans mot de passe.
- Dans Docker, `localhost` = le conteneur lui-même : 9 pannes « n8n ne voit pas Ollama » sur 10.
- Garder un nom OpenAI (`gpt-4o`) au lieu du nom exact d'Ollama : « model not found ».

## Les commandes / chiffres / dates utiles
- **Mnémo des ports « 11-12-80-80-50 »** : Ollama **11**434 · LM Studio **12**34 · llama-server **80**80 · vLLM **8**000 · KoboldCpp **50**01.
- Ollama : `ollama pull` · `run` · `list` · `ps` · `rm` · `create mon-assistant -f Modelfile` ; API native `/api/chat` (`options.num_ctx`, `"stream": false`) ; API OpenAI `/v1/chat/completions`.
- Exemples de mémoire (Q4) : 8B ≈ 4,4 Go · 27B ≈ 14,9 Go (16 à 19 Go réels) · 70B ≈ 38,5 Go · gpt-oss-120b ≈ 66 Go (MXFP4). Mémoire utilisable : ~90 % de la VRAM, ~70 à 75 % d'un Mac.
- Confort interactif : **≥ 20 tok/s**. Mac M4 Max sur un 7B : 83 tok/s ; RTX 5090 sur un 8B : 145 tok/s.
- Valeurs sûres 16 à 32 Go (nov. 2026) : Qwen3.8-27B, Gemma 4 26B-A4B, gpt-oss-20b, Qwen3.6-35B-A3B.
- Écart ouvert / fermé (Artificial Analysis v5, 27 oct. 2026) : Claude Opus 5.5 = 58 contre 32 pour les meilleurs poids publiés.
- Licences : Apache 2.0 / MIT = libre ; licences communautaires (Muse, Kimi K3) = accord au-delà de **20 M$** ; CC BY-NC = jamais en production commerciale.

## Pour aller plus loin
- [Ollama — Documentation](https://docs.ollama.com)
- [Open WebUI — Quick Start](https://docs.openwebui.com/getting-started/quick-start/)
- [Hugging Face — fiche Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B)

## Auto-test (3 questions — réponses en bas de fiche)
1. Combien de mémoire (poids seuls) pour un 14B en Q8 ?
2. Pourquoi gpt-oss-120b peut-il écrire plus vite qu'un 32B dense sur la même machine ?
3. Dans un Docker Compose où Ollama est le service `ollama`, quelle URL donner à n8n ?

---
**Réponses** — 1. 14 × 8 ÷ 8 × 1,1 = 15,4 Go. 2. C'est un MoE : il ne lit que 5,1B paramètres actifs (≈ 3,5 Go) par token, contre 17,6 Go pour le 32B. 3. `http://ollama:11434` (le nom du service).
