---
id: L042
module: M10
level: N2
title: "Matériel : paramètres, RAM / VRAM, stockage, vitesse — Mac, PC NVIDIA, CPU, DGX Spark"
minutes: 70
objectives:
  - "Calculer la mémoire nécessaire à un modèle à partir de son nombre de paramètres et de sa quantization (règle Go ≈ B × bits ÷ 8 × 1,1 + KV cache)"
  - "Estimer la vitesse de génération attendue (tokens/s) d'une machine à partir de sa bande passante mémoire"
  - "Choisir, pour une configuration donnée (Mac 8–128 Go, PC NVIDIA RTX 3060–5090, CPU seul, DGX Spark, AMD Strix Halo), la taille de modèle maximale confortable"
  - "Arbitrer entre acheter une machine et louer un GPU à l'heure avec des chiffres de novembre 2026"
skills: ["C2.3"]
sources:
  - { title: "Flavio Copes — LLM VRAM requirements (règle de calcul)", url: "https://flaviocopes.com/llm-vram-requirements/", lang: "en" }
  - { title: "llama.cpp — Performance of llama.cpp on Apple Silicon M-series (discussion #4167)", url: "https://github.com/ggml-org/llama.cpp/discussions/4167", lang: "en" }
  - { title: "Apple Machine Learning Research — Exploring LLMs with MLX and the Neural Accelerators in the M5 GPU", url: "https://machinelearning.apple.com/research/exploring-llms-mlx-m5", lang: "en" }
  - { title: "FormulaMod / Hardware Corner — Which NVIDIA GPU for local AI in 2026", url: "https://www.formulamod.net/blogs/new/which-nvidia-gpu-for-local-ai-in-2026-rtx-3090-vs-4060-ti-vs-4070-ti-super-vs-4090-vs-5090", lang: "en" }
  - { title: "Presenc — RTX 5090 local LLM benchmarks 2026", url: "https://presenc.ai/research/rtx-5090-local-llm-benchmarks-2026", lang: "en" }
  - { title: "IntuitionLabs — NVIDIA DGX Spark review", url: "https://intuitionlabs.ai/articles/nvidia-dgx-spark-review", lang: "en" }
  - { title: "Spheron — DGX Spark vs RTX 5090 for local LLMs (tokens per second, 2026)", url: "https://www.spheron.network/blog/dgx-spark-vs-rtx-5090-for-local-llms-tokens-per-second-2026/", lang: "en" }
  - { title: "Presenc — AMD Strix Halo local LLM benchmarks 2026", url: "https://presenc.ai/research/amd-strix-halo-local-llm-benchmarks-2026", lang: "en" }
  - { title: "Pinggy — Best Local LLM Tools and Models in 2026", url: "https://pinggy.io/blog/top_5_local_llm_tools_and_models/", lang: "en" }
  - { title: "Scaleway — Tarifs GPU", url: "https://www.scaleway.com/en/pricing/gpu", lang: "en" }
---

# Matériel : paramètres, RAM / VRAM, stockage, vitesse — Mac, PC NVIDIA, CPU, DGX Spark

> ⏱ 70 min · 🎯 Niveau 2 · 📚 Module 10

## 🎯 Ce que vous saurez faire
- Lire « 27B, Q4_K_M » sur une fiche de modèle et en déduire en dix secondes : « il me faut ~16 Go de mémoire et ~16 Go de disque ».
- Prédire si un modèle « tiendra » sur votre Mac, votre PC ou votre serveur, et à quelle vitesse il écrira, avant même de le télécharger.
- Expliquer pourquoi un DGX Spark à 128 Go peut être **plus lent** qu'une RTX 5090 à 32 Go, et dans quel cas on l'achète quand même.
- Chiffrer l'alternative « louer un GPU à l'heure ».

> 🧭 **En clair** — Pour accueillir votre chef cuisinier à domicile, il faut une cuisine à sa taille. La **mémoire** de l'ordinateur (RAM ou VRAM) — la RAM est la mémoire vive de l'ordinateur, la VRAM celle, séparée, de la carte graphique, c'est le plan de travail : si la recette (le modèle) ne tient pas dessus, impossible de cuisiner. La **bande passante**, c'est la vitesse à laquelle le chef attrape ses ingrédients : plus elle est élevée, plus les plats (les mots) sortent vite. La **quantization**, c'est l'art de ranger les ingrédients en bocaux plus petits pour gagner de la place, avec une perte de goût minime. Avec une seule formule et une calculatrice, vous saurez dire si un modèle tiendra sur votre machine — avant même de le télécharger.

C'est la leçon pivot du module : tout ce qui suit (Ollama, LM Studio, choix du modèle, intégration n8n) suppose que vous sachiez dimensionner. Prenez une calculatrice.

## 1. Les trois nombres qui comptent

Une fiche de modèle sur Hugging Face ou ollama.com vous donne trois informations décisives :

1. **Le nombre de paramètres**, noté en milliards (« B » pour *billion*) : 8B, 27B, 70B, 120B… Pour les modèles MoE (*Mixture of Experts*, vus au module 2), on distingue le **total** (ce qu'il faut stocker en mémoire) et les **actifs** (ce qui est calculé à chaque token : la vitesse). Exemple : gpt-oss-120b = 116,8B total, 5,1B actifs.
2. **La précision des poids**, en bits par paramètre (un bit est la plus petite unité d'information ; 8 bits font un octet) : FP16/BF16 (16 bits), Q8 (8 bits), Q4 (4 bits), parfois Q3, Q2 ou les formats GPU FP8, NVFP4, MXFP4. (Ce sont des noms de formats ; le chiffre indique, en gros, le nombre de bits : plus il est petit, plus le fichier est léger.)
3. **La fenêtre de contexte** que vous comptez réellement utiliser (la quantité de texte que le modèle garde « sous les yeux » en même temps : votre question, les documents fournis et la conversation) (8K, 32K, 128K tokens), qui coûte de la mémoire en plus.

Les deux autres caractéristiques de **votre machine** : la **mémoire accessible au modèle** (VRAM d'une carte NVIDIA, mémoire unifiée d'un Mac ou d'un DGX Spark, RAM pour un CPU) — « unifiée » signifie qu'une seule mémoire sert à la fois au processeur et à la partie graphique ; le CPU est le processeur principal et sa **bande passante** en Go/s.

> 🧭 **Pas à pas pour débutant** — Où lire les caractéristiques de **votre** ordinateur ? **Sur Mac** : menu Pomme (en haut à gauche) → **À propos de ce Mac** ; notez la *Puce* (par exemple « Apple M4 Pro ») et la *Mémoire* (par exemple « 24 Go ») : c'est la mémoire unifiée. **Sur Windows** : appuyez sur Ctrl + Maj + Échap pour ouvrir le **Gestionnaire des tâches**, onglet **Performances** ; *Mémoire* donne la RAM totale ; cliquez sur *GPU* : la ligne **Mémoire GPU dédiée** est votre VRAM (si vous ne voyez que « Intel UHD » ou « Radeon Graphics » avec très peu de mémoire dédiée, vous n'avez pas de carte graphique séparée : comptez en « CPU seul »). La **bande passante**, elle, ne s'affiche nulle part : retrouvez votre puce ou votre carte dans le grand tableau de la section 5, ou cherchez « nom de votre puce + memory bandwidth » sur le site du fabricant.

```quiz
{
  "q": "Sur la fiche du modèle « gpt-oss-120b », on lit « 116,8B total, 5,1B actifs ». Que signifie le chiffre « total » pour vous ?",
  "options": [
    "La vitesse d'écriture du modèle",
    "Ce qu'il faut stocker en mémoire",
    "Le nombre de mots qu'il connaît",
    "La taille de la fenêtre de contexte"
  ],
  "answer": 1,
  "explanation": "Pour un modèle MoE, le total détermine la mémoire nécessaire ; les paramètres actifs, eux, déterminent la vitesse, car seuls ceux-là sont lus à chaque token."
}
```

## 2. La quantization en cinq minutes (juste ce qu'il faut pour dimensionner)

Un paramètre est un nombre. À l'entraînement, il est stocké sur 16 bits (2 octets). La **quantization** consiste à arrondir ces nombres sur moins de bits — 8, 4, parfois 3 ou 2 — pour diviser la mémoire par 2 à 4. Analogie : une photo en 16 millions de couleurs convertie en 256 couleurs ; l'œil distingue à peine la différence, le fichier est quatre fois plus léger.

Ce qu'il faut retenir pour choisir :

| Précision | Octets / paramètre | Perte de qualité | Quand l'utiliser |
|---|---|---|---|
| FP16 / BF16 | 2 | Aucune (référence) | Serveur avec beaucoup de mémoire, fine-tuning |
| Q8_0 / FP8 | 1 | Négligeable | Quand la mémoire le permet |
| **Q4_K_M / 4 bits MLX / NVFP4 / MXFP4** | 0,5 | Faible, généralement acceptable | **Le standard du local en 2026** |
| Q3 / IQ3 | ~0,4 | Sensible | Pour faire tenir un modèle « trop gros » (ex. DeepSeek V4 Flash en 128 Go) |
| Q2 / IQ2 | ~0,3 | Forte | À éviter sauf expérimentation |

Les formats de fichiers : **GGUF** (llama.cpp, Ollama, LM Studio, Jan : suffixes `Q4_K_M`, `Q5_K_M`, `Q6_K`, `Q8_0`), **MLX** (Apple Silicon, 4 ou 8 bits) — le format optimisé par Apple pour ses puces M1 à M5, **AWQ / GPTQ / FP8 / NVFP4** (GPU NVIDIA via vLLM ou TensorRT-LLM). gpt-oss est distribué nativement en **MXFP4** par OpenAI. Vous n'avez pas besoin de connaître la différence interne entre Q4_K_M et Q4_0 ; retenez « Q4_K_M = le bon compromis par défaut ».

> 💡 **À retenir** — Règle d'or 2026 : **téléchargez en 4 bits par défaut**. Vous ne passerez en 8 bits que si la mémoire déborde largement, et en 3 bits que si c'est le seul moyen de faire tenir un modèle que vous tenez absolument à tester.

## 3. La formule de mémoire

Voici la règle que vous devez savoir appliquer de tête (source : règle de calcul de Flavio Copes, reprise par les calculateurs en ligne) :

```
Mémoire des poids (Go) ≈ Paramètres (milliards) × bits ÷ 8 × 1,1
```

Le `÷ 8` convertit des bits en octets ; le `× 1,1` ajoute 10 % d'overhead (tables de quantization, métadonnées, tampons du moteur d'inférence) — l'overhead est le « surplus » technique ; le moteur d'inférence est le logiciel qui fait tourner le modèle (Ollama, LM Studio…). Exemples :

- 8B en Q4 : 8 × 4 ÷ 8 × 1,1 = **4,4 Go**
- 27B en Q4 : 27 × 4 ÷ 8 × 1,1 = **14,9 Go** (les fichiers réels de Qwen3.8-27B mesurés par Pinggy font 16–19 Go : la pratique est un peu au-dessus de la théorie)
- 70B en Q4 : 70 × 4 ÷ 8 × 1,1 = **38,5 Go**
- 8B en FP16 : 8 × 16 ÷ 8 × 1,1 = **17,6 Go** (Apple mesure 17,46 Go pour Qwen3-8B en BF16 : la formule est fiable)

> 💡 **Autrement dit** — À la calculatrice, pour un « 27B en Q4 » : tapez **27** (les milliards de paramètres), **× 4** (les bits, le chiffre après le Q), **÷ 8**, **× 1,1**, et lisez **14,85** : il faut environ 15 Go de mémoire, plus un ou deux pour le contexte. Comparez ensuite au **plan de travail réellement disponible** : 75 % de la mémoire d'un Mac (un Mac 24 Go offre environ 18 Go), 90 % de la VRAM d'une carte NVIDIA (une carte 12 Go offre environ 10,8 Go). Si le résultat dépasse, le modèle ne tiendra pas confortablement.

Puis il faut ajouter le **KV cache** : la mémoire de travail de l'attention (le mécanisme par lequel le modèle relie chaque mot aux précédents), qui grandit linéairement avec le nombre de tokens de contexte. Sa formule exacte dépend de l'architecture (2 × couches × têtes KV × dimension de tête × tokens × octets par valeur), mais retenez des ordres de grandeur mesurés sur Llama 3 en FP16 :

- modèle 8B : ≈ **131 Mo par 1 000 tokens**, soit ≈ 1,05 Go pour 8K de contexte ;
- modèle 70B : ≈ **328 Mo par 1 000 tokens**, soit ≈ 2,6 Go pour 8K, et plus de 10 Go pour 32K.

D'où la version complète :

```
Mémoire totale ≈ (B × bits ÷ 8 × 1,1) + KV cache(contexte)
```

Et une dernière correction : vous ne pouvez pas remplir votre mémoire à 100 %. Comptez **~90 % de la VRAM** d'un GPU utilisable (le reste va au pilote et à l'affichage) — le pilote est le logiciel qui fait fonctionner la carte graphique et **~70–75 % de la mémoire unifiée d'un Mac** (macOS et vos applications prennent le reste ; une commande permet de relever ce plafond, mais restez prudents).

> ⚠️ **Piège fréquent** — Oublier le contexte. Un 14B Q4 (7,7 Go) « tient » sur une RTX 3060 12 Go… avec un contexte court. Demandez-lui de résumer un PDF de 60 pages (≈ 40 000 tokens) et le KV cache fera déborder le modèle en RAM système : la vitesse s'effondre d'un facteur 5 à 10. Dimensionnez pour le contexte que vous utiliserez vraiment.

> 💡 **Autrement dit** — Le *KV cache*, c'est le bloc-notes du chef : à mesure que vous lui donnez un long texte à lire, il prend des notes pour s'en souvenir. Plus le texte est long, plus le bloc-notes prend de place sur le plan de travail. Un modèle qui « tient » avec une question courte peut déborder quand vous lui confiez un PDF de 60 pages.

```quiz
{
  "q": "Avec la formule Go ≈ B × bits ÷ 8 × 1,1, combien de mémoire demandent les poids d'un modèle de 32B en 4 bits ?",
  "options": [
    "Environ 8,8 Go",
    "Environ 35 Go",
    "Environ 17,6 Go",
    "Environ 70 Go"
  ],
  "answer": 2,
  "explanation": "32 × 4 ÷ 8 × 1,1 = 17,6 Go. Il faut ensuite ajouter le KV cache selon la longueur du contexte utilisé."
}
```

### 3.1 Tableau « paramètres → mémoire → disque »

Calcul avec la formule (overhead 1,1 inclus, hors KV cache) ; le disque correspond au fichier GGUF Q4 à télécharger.

| Paramètres | FP16 | Q8 | Q4 (+ KV cache 8K) | Disque Q4 | Machine minimale confortable |
|---|---|---|---|---|---|
| 3–4B | 7–9 Go | 3,5–4,5 Go | 1,7–2,2 Go | ~2–2,5 Go | Tout PC 8 Go, téléphone haut de gamme |
| 8B | 17,6 Go | 8,8 Go | 4,4 Go (+1 Go ≈ 5,5 Go) | ~4,9 Go | GPU 8 Go / Mac 16 Go |
| 14B | 30,8 Go | 15,4 Go | 7,7 Go (≈ 9 Go) | ~8,5 Go | RTX 3060 12 Go (serré) / Mac 16 Go |
| 27B | 59 Go | 29,7 Go | 14,9 Go (16–19 Go mesurés) | ~16 Go | RTX 4090 24 Go / Mac 32 Go |
| 32B | 70 Go | 35 Go | 17,6 Go (≈ 20 Go) | ~19 Go | GPU 24 Go / Mac 32 Go |
| 70B | 154 Go | 77 Go | 38,5 Go (+2,6 Go ≈ 41 Go) | ~40 Go | 2 × RTX 3090/4090, Mac 64 Go (serré), 96 Go (confort) |
| 120B MoE (gpt-oss-120b) | 257 Go | — | MXFP4 ≈ 66 Go | ~63 Go | Mac 96–128 Go, DGX Spark, Strix Halo 128 Go |
| 235B MoE (Qwen3) | 517 Go | 258 Go | 129 Go | ~130 Go | 2 × DGX Spark, Mac Studio 256 Go |
| 671B MoE (DeepSeek R1/V3) | 1,48 To | 738 Go | 369 Go | ~370 Go | Cluster multi-GPU |
| 2,8T MoE (Kimi K3) | 6,2 To | — | MXFP4 ≈ 1,4 To | 1,56 To | ≥ 64 accélérateurs |

Mesures réelles qui confirment la règle (Apple, MLX, nov. 2025) : Qwen3-8B 4 bits = 5,61 Go ; Qwen3-14B 4 bits = 9,16 Go ; gpt-oss-20b MXFP4 = 12,08 Go ; Qwen3-30B-A3B 4 bits = 17,31 Go.

**Le stockage.** Prévoyez un SSD avec de la marge (disque rapide, sans pièce mobile ; le NVMe en est la version la plus rapide) : un praticien installe vite 5 à 10 modèles (de 2 à 20 Go chacun), plus les versions successives. **100 à 200 Go dédiés** est un minimum raisonnable sur un poste ; un SSD NVMe accélère aussi le chargement du modèle en mémoire (un fichier de 16 Go se charge en quelques secondes sur NVMe, en plus d'une minute sur un disque lent).

> 🔗 **Documentation officielle** — [Flavio Copes — LLM VRAM requirements](https://flaviocopes.com/llm-vram-requirements/) et le calculateur [InventiveHQ — LLM VRAM calculator](https://inventivehq.com/tools/llm-vram-calculator)

```mission
{
  "title": "Lisez la fiche d'un modèle sur Hugging Face : taille et licence",
  "url": "https://huggingface.co/Qwen/Qwen3.8-27B",
  "steps": ["Ouvrez la fiche (model card) Qwen3.8-27B sur Hugging Face", "Repérez le nombre de paramètres indiqué dans la fiche ou la colonne de droite (« Model size »)", "Repérez l'étiquette « License » en haut de la page", "Cherchez la longueur de contexte native"],
  "question": "Combien de paramètres, quelle licence et quelle longueur de contexte native pour Qwen3.8-27B ? En 4 bits, combien de mémoire prévoir selon la formule ?",
  "hint": "Le nom dit « 27B », mais la colonne de droite peut afficher un chiffre légèrement différent.",
  "answer": "Environ 27 à 28 milliards de paramètres (28B affichés par Hugging Face), licence Apache 2.0, contexte natif de 262K tokens. Formule : 27 × 4 ÷ 8 × 1,1 ≈ 14,9 Go, fichiers réels 16 à 19 Go (relevé nov. 2026).",
  "xp": 20
}
```


## 4. La vitesse : tout est dans la bande passante

Voici le fait le plus contre-intuitif du module. En génération de texte, à chaque token, le processeur doit **relire l'intégralité des poids** du modèle depuis la mémoire. Un 8B Q4 pèse ~4,4 Go : produire 100 tokens, c'est lire 440 Go. La limite n'est donc pas la puissance de calcul (les FLOPS), mais la **bande passante mémoire** (Go/s). Les FLOPS mesurent le nombre de calculs par seconde.

```
Vitesse maximale théorique (tok/s) ≈ Bande passante (Go/s) ÷ Taille des poids lus par token (Go)
```

En pratique, on atteint **50 à 70 %** de ce maximum. Vérifions : un M4 Max (546 Go/s) sur un 7B Q4 (~3,9 Go) : 546 ÷ 3,9 ≈ 140 tok/s théoriques ; mesuré : 83 tok/s (≈ 60 %). Une RTX 5090 (1 792 Go/s) sur un 8B Q4 : 1 792 ÷ 4,4 ≈ 407 théoriques ; mesuré : 145 tok/s (≈ 36 %, les très grosses bandes passantes sont moins bien exploitées). Un DGX Spark (273 Go/s) sur le même 8B : 273 ÷ 4,4 ≈ 62 théoriques ; mesuré : 38 tok/s (≈ 61 %).

Deux conséquences majeures :

- **Les modèles MoE sont les rois du local** : gpt-oss-120b stocke 117B paramètres mais n'en lit que 5,1B par token. Sur un Mac à 128 Go, il écrit presque aussi vite qu'un 8B dense (« dense » : un modèle classique dont tous les paramètres travaillent à chaque mot, par opposition aux MoE), tout en étant bien plus intelligent. C'est pourquoi Qwen3-30B-A3B, Gemma 4 26B-A4B ou gpt-oss-20b sont si populaires.
- **Le prefill (lecture de votre prompt) obéit à une autre loi** : il est borné par le calcul. C'est là que les puces récentes font la différence : les Neural Accelerators du M5 multiplient le prefill par ~4 par rapport au M4 (M5 Max : 3 220 tok/s contre 886 pour le M4 Max), alors que la génération ne gagne que 20 à 45 %.

> 💡 **À retenir** — **La mémoire décide de ce qui tient ; la bande passante décide de la vitesse.** Un modèle qui déborde de la mémoire GPU vers la RAM système passe de « rapide » à « inutilisable » : il vaut mieux un modèle plus petit qui tient qu'un plus gros qui déborde.

Pour un usage interactif confortable, visez **≥ 20 tok/s** (plus vite que vous ne lisez). Pour des traitements par lots (résumer 3 000 factures la nuit), 5 tok/s peuvent suffire si la machine tourne seule.

> 💡 **Autrement dit** — La **bande passante**, c'est la largeur du tuyau entre la mémoire et le processeur. Pour écrire chaque mot, le modèle doit faire passer **tout** son contenu dans ce tuyau. Un gros tuyau (une RTX 5090) remplit vite le seau ; un tuyau fin (un portable sans carte graphique) le remplit lentement, même si le seau (la mémoire) est immense. C'est pour cela qu'une machine avec beaucoup de mémoire n'est pas forcément rapide.

```mermaid
flowchart LR
  M["Mémoire<br/>(RAM / VRAM)"] -->|"décide"| T["Quel modèle<br/>TIENT"]
  B["Bande passante<br/>(Go/s)"] -->|"décide"| V["À quelle VITESSE<br/>il écrit"]
  C["Calcul<br/>(FLOPS)"] -->|"décide"| P["Vitesse de lecture<br/>du prompt (prefill)"]
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour qu'un modèle écrive plus vite, le plus important est la bande passante mémoire de la machine, plus que sa puissance de calcul (FLOPS).",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai : en génération, le modèle relit tous ses poids à chaque token ; c'est donc la bande passante mémoire qui limite la vitesse. Les FLOPS comptent surtout pour lire le prompt (prefill)."
}
```


## 5. Le grand tableau : quelle machine pour quel modèle, à quelle vitesse ?

Vitesse de **génération** attendue en tokens/s, modèle en 4 bits, contexte court (8–16K), un seul utilisateur. Les chiffres sont des mesures publiées (llama.cpp, Ollama, MLX) sur des modèles de référence (Llama 2/3 7–8B, Qwen3 8B/14B, Gemma 27B, gpt-oss) ; les cases « est. » sont des estimations par la règle de bande passante, à vérifier sur votre machine avec `ollama ps` ou `llama-bench` (deux commandes à taper dans un terminal, vues en L043).

| Machine (mémoire, bande passante) | 3–4B | 8B | 14B | 27–32B | 70B | gpt-oss-120b (MoE) |
|---|---|---|---|---|---|---|
| **Mac 8 Go** (M1/M2/M3 base, 68–100 Go/s) | ✅ ~25–40 | ⚠️ 14–22, contexte minuscule | ❌ | ❌ | ❌ | ❌ |
| **Mac 16 Go** (M4, 120 Go/s ; M4 Pro, 273 Go/s) | ✅ 50–100 est. | ✅ 24 (M4) / 51 (M4 Pro) | ⚠️ ~15–30, contexte court | ❌ | ❌ | ❌ |
| **Mac 32 Go** (M4 Pro 273 Go/s ; M4 Max 546 Go/s) | ✅ | ✅ 51 / 83 | ✅ ~30 / ~50 est. | ✅ ~15–25 / 30–40 est. (Qwen3.8-27B ≈ 65–69 sur M5 Max) | ❌ | ❌ |
| **Mac 64 Go** (M4 Max 546 Go/s ; M5 Max 614 Go/s) | ✅ | ✅ 83 / 120 | ✅ | ✅ ~35–45 est. | ⚠️ ~8–12 est., très serré | ❌ (66 Go > 75 % de 64) |
| **Mac 128 Go** (M4 Max / M5 Max ; M3 Ultra 800 Go/s ; M5 Ultra 1 228 Go/s) | ✅ | ✅ 83–179 | ✅ | ✅ 40–70 est. | ✅ ~10–15 (Max) / 40–52 (M5 Ultra) | ✅ ~35–45 est. (Max) ; 70,8 mesuré sur M3 Ultra |
| **PC RTX 3060 12 Go** (360 Go/s) | ✅ ~80 est. | ✅ 42 (31,9 à 32K) | ⚠️ 22,7, contexte court | ❌ déborde | ❌ | ❌ |
| **PC RTX 4070 12 Go** (504 Go/s) | ✅ | ✅ ~50–65 est. (entre 4060 Ti 34 et 4070 Ti Super 72) | ⚠️ ~30–40 est., serré | ❌ | ❌ | ❌ |
| **PC RTX 4090 24 Go** (1 008 Go/s) | ✅ | ✅ 104 | ✅ 69 | ✅ ~35–45 est. (32B Q4 tient) | ❌ (38,5 Go) | ❌ |
| **PC RTX 5090 32 Go** (1 792 Go/s) | ✅ | ✅ 145–150 | ✅ 103 | ✅ 47 (Gemma 3 27B) ; 59 (Qwen3.8-27B) ; gpt-oss-20b 205 | ❌ (27 tok/s avec **deux** cartes) | ❌ |
| **CPU seul, portable DDR5 16–32 Go** (~80–100 Go/s) | ✅ ~15–25 est. | ⚠️ < 10 mesuré, 15–20 au mieux | ⚠️ ~5 est. | ❌ (sauf MoE : Qwen3-30B-A3B reste agréable) | ❌ | ❌ |
| **NVIDIA DGX Spark 128 Go** (273 Go/s) | ✅ | ✅ 38 | ✅ ~22 est. | ⚠️ 10,8 (Gemma 3 27B Q4) | ⚠️ 2,7–4,7 (FP8) | ✅ 38,6–60,6 (40,5 à 32K) ; gpt-oss-20b 50–61 |
| **AMD Strix Halo 128 Go** (256 Go/s théor., ~215 mesurés) | ✅ | ✅ 46–53 (7B) | ✅ ~20 est. | ⚠️ ~10 est. ; Qwen3-30B-A3B 72–75 | ⚠️ ~5 | ✅ 31–34 |

Légende : ✅ confortable · ⚠️ possible mais lent ou contexte limité · ❌ ne tient pas en mémoire (ou vitesse inutilisable).

### 5.1 Lecture par famille de machines

**Mac Apple Silicon (mémoire unifiée).** Le GPU et le CPU partagent la même mémoire : un Mac 64 Go offre ~45 Go au modèle, ce qu'aucune carte grand public NVIDIA ne propose. La puce détermine la bande passante, donc la vitesse ; la quantité de mémoire détermine la taille de modèle. Repères de génération sur un 7B Q4 (llama.cpp, discussion officielle #4167) : M1 14 tok/s · M1 Pro 36 · M1 Max 61 · M2 Pro 39 · M2 Max 66 · M3 Pro 31 · M3 Max 66 · M4 24 · M4 Pro 51 · M4 Max 83 · M5 32 · M5 Pro 66 · M5 Max 120 · M5 Ultra 179. Règle d'achat : **le « Max » ou l'« Ultra » pour la vitesse, la mémoire pour la taille** ; un M4 Pro 48 Go est un excellent poste de praticien (27B à vitesse de lecture).

**PC avec carte NVIDIA.** La VRAM est séparée de la RAM : seule la VRAM compte pour la taille. Les cartes 12 Go (RTX 3060, 4070) couvrent les 8B et, serrés, les 14B ; les 16 Go (4060 Ti, 4070 Ti Super) font tenir un 14B à l'aise ; les 24 Go (3090 d'occasion ~650–900 $, 4090) ouvrent les 27–32B ; la 5090 (32 Go, ~1 999 $) est la plus rapide du marché grand public mais **ne fait toujours pas tenir un 70B** (38,5 Go). Deux cartes se combinent (Llama 3.3 70B ≈ 27 tok/s sur deux 5090), au prix d'un boîtier et d'une alimentation adaptés. Point fort décisif des GPU : le prefill très rapide et la compatibilité CUDA avec tout l'écosystème (vLLM, fine-tuning) — CUDA est la technologie logicielle propre aux cartes NVIDIA, utilisée par presque tous les outils d'IA.

**CPU seul.** Ça marche, mais lentement : une barrette DDR5 double canal plafonne vers 80–100 Go/s, soit 15–20 tok/s au mieux sur un 8B Q4, et souvent moins de 10 sur un portable. Les modèles **MoE à faibles paramètres actifs** (gpt-oss-20b, Qwen3-30B-A3B, Gemma 4 26B-A4B) sont les seuls « gros » modèles agréables sans GPU. C'est la solution pour tester sur n'importe quel PC de bureau avec 16–32 Go de RAM, pas pour un déploiement multi-utilisateurs.

**NVIDIA DGX Spark (GB10).** Un boîtier de bureau avec 128 Go de mémoire unifiée LPDDR5x, 6 144 cœurs CUDA, SSD 4 To, 240 W. Prix : 3 999 $ au lancement (oct. 2025), 4 699 $ en février 2026, ~6 950 $ en octobre 2026 selon ServeTheHome (crise de la mémoire) ; version OEM 64 Go dès 4 999 $ (oct. 2026) — c'est-à-dire vendue sous la marque d'un autre fabricant (Dell, Asus…). Sa bande passante de 273 Go/s est celle d'un M4 Pro : c'est une machine de **capacité** (modèles jusqu'à 200B en FP4, contexte long, fine-tuning jusqu'à 70B annoncé — Kaitchup conseille de rester sous 8B pour un confort réel), pas de **vitesse**. Sur ce qui tient dans 32 Go, une RTX 5090 décode environ **4 fois plus vite**. On l'achète pour gpt-oss-120b, Qwen3.8-Flash-Next (125B-A6B, 96–114 Go en 4 bits) ou pour servir plusieurs utilisateurs avec vLLM (289–313 tok/s agrégés sur 8 requêtes simultanées).

**AMD Ryzen AI Max+ 395 « Strix Halo » 128 Go.** L'alternative à prix réduit : Framework Desktop 3 449 $, GMKtec EVO-X2 3 649 $, Minisforum MS-S1 Max 3 799 $ (sept. 2026). Bande passante proche du Spark, résultats comparables sur gpt-oss-120b (31–34 tok/s contre 38,6), écosystème logiciel (ROCm/Vulkan) moins mûr que CUDA. (ROCm et Vulkan sont les équivalents de CUDA côté AMD : moins d'outils les prennent en charge.)

> ⚠️ **Piège fréquent** — Comparer les machines sur la seule mémoire. « 128 Go pour 3 500 $, c'est mieux qu'une 5090 à 2 000 $ avec 32 Go » est vrai pour la **taille** et faux pour la **vitesse** : sur un 27B, la 5090 écrit 47–59 tok/s, le Spark 10,8. Posez-vous d'abord la question : « quel est le plus gros modèle dont j'ai réellement besoin ? »

```mission
{
  "title": "Retrouvez la vitesse d'un Mac M4 Max dans le tableau de référence llama.cpp",
  "url": "https://github.com/ggml-org/llama.cpp/discussions/4167",
  "steps": ["Ouvrez la discussion #4167 du dépôt llama.cpp", "Repérez le tableau des puces Apple Silicon", "Trouvez la ligne M4 Max (40 cœurs GPU) et la colonne de génération en Q4_0"],
  "question": "Combien de tokens par seconde génère un M4 Max sur Llama 2 7B en Q4_0, et quelle est sa bande passante ?",
  "hint": "La colonne « TG » (text generation) correspond à la génération ; « PP » (prompt processing) au prefill.",
  "answer": "Environ 83 tok/s (83,1) en génération Q4_0, pour une bande passante de 546 Go/s (relevé nov. 2026 — le tableau est enrichi par la communauté).",
  "xp": 15
}
```

## 6. Acheter ou louer ?

Louer un GPU à l'heure permet de tester un gros modèle avant d'investir, ou d'absorber un pic (nov. 2026) :

| Option | Mémoire | Prix | Source |
|---|---|---|---|
| RTX 4090 (RunPod Community / Vast.ai) | 24 Go | 0,34 $/h | Spheron / CloudZero |
| L40S (Scaleway, France) | 48 Go | 1,40 € HT/h | scaleway.com |
| H100 PCIe (Scaleway) / H100 (OVHcloud) | 80 Go | 2,73 € HT/h / 2,80 €/h | scaleway.com / ovhcloud.com |
| H100 (RunPod Secure) | 80 Go | 2,89–2,99 $/h | Spheron |
| Hyperscalers (AWS, Azure) H100 — les géants du cloud | 80 Go | ~6,9–7 $/h | CloudZero |

Calcul type : à 0,34 $/h, une RTX 4090 louée coûte 238 $ pour 700 heures et il faut environ 13 800 heures (plus d'un an et demi à plein temps) pour atteindre le prix d'un DGX Spark à 4 699 $ — mais la 4090 louée n'offre que 24 Go, contre 128 Go pour le Spark ; un H100 Scaleway 8 h/jour, 20 jours/mois = 437 € HT/mois. Pour un usage quotidien sur un an, l'achat gagne ; pour un projet de trois semaines, la location gagne, sans parler de la revente impossible d'un GPU dont le prix a doublé entre-temps.

🎮 **Défi** — Sans regarder le tableau : votre collègue a un MacBook Air M4 16 Go. Quel est le plus gros modèle dense qu'il peut faire tourner confortablement, et à quelle vitesse approximative ? (Réponse : un 8B Q4, ~4,4 Go + KV, à ~24 tok/s ; un 14B Q4 passe mais avec un contexte très court.)

## 🧪 Exercice pratique

**Consigne.** Pour chacune des quatre configurations ci-dessous, (a) calculez avec la formule la mémoire nécessaire au modèle proposé en Q4 avec 8K de contexte, (b) dites s'il tient (en appliquant les 90 % / 75 % utilisables), (c) estimez la vitesse de génération avec la règle « bande passante ÷ taille × 0,6 », (d) proposez un modèle mieux adapté si le choix initial est mauvais.

1. MacBook Pro M4 Pro 24 Go (273 Go/s) → Qwen3.8-27B
2. PC RTX 3060 12 Go (360 Go/s) → Gemma 4 12B
3. PC de bureau sans GPU, 32 Go DDR5 (~90 Go/s) → Llama 3.1 70B
4. DGX Spark 128 Go (273 Go/s) → gpt-oss-120b (MXFP4, 5,1B actifs ≈ 3,5 Go lus par token)

**Critères de réussite.** Les quatre calculs sont posés avec la formule ; la marge mémoire utilisable est appliquée ; chaque vitesse est accompagnée du mot « estimation » ; au moins une reconfiguration est argumentée.

**Corrigé.**
1. 27 × 4 ÷ 8 × 1,1 = 14,9 Go (+ ~1,5 Go KV ≈ 16,5 Go ; fichiers réels 16–19 Go). Mémoire utilisable ≈ 18 Go : ça tient, **tout juste**, sans autre application lourde. Vitesse ≈ 273 ÷ 15 × 0,6 ≈ 11 tok/s : lent mais lisible. Mieux : Gemma 4 26B-A4B (MoE, 3,8B actifs, 16–18 Go) écrira 3 à 5 fois plus vite, ou gpt-oss-20b (12 Go).
2. 12 × 4 ÷ 8 × 1,1 = 6,6 Go (fichiers réels 7–8 Go) + ~1 Go KV ≈ 8–9 Go pour 10,8 Go utilisables : ça tient. Vitesse ≈ 360 ÷ 7 × 0,6 ≈ 30 tok/s (la 3060 mesure 22,7 sur un Qwen3 14B, l'ordre de grandeur est cohérent). Bon choix.
3. 70 × 4 ÷ 8 × 1,1 = 38,5 Go + 2,6 Go ≈ 41 Go > 32 Go : **ne tient pas**, et même en Q3 la vitesse serait de ~1–2 tok/s. Mieux : gpt-oss-20b (12 Go, 3,6B actifs) ou Qwen3-30B-A3B (17 Go, 3B actifs), seuls modèles « gros » agréables sur CPU (≈ 15–25 tok/s estimés).
4. ≈ 66 Go en MXFP4 + KV : tient largement dans ~115 Go utilisables, avec de la place pour un contexte de 32K. Vitesse ≈ 273 ÷ 3,5 × 0,6 ≈ 47 tok/s ; mesuré : 38,6–60,6 tok/s (40,5 à 32K). C'est exactement le cas d'usage du Spark.

## ✅ Auto-évaluation express

1. Combien de mémoire (poids seuls) demande un modèle de 14B en Q8 ?
2. Pourquoi un modèle MoE de 120B peut-il générer plus vite qu'un modèle dense de 32B sur la même machine ?
3. Qu'est-ce qui limite la vitesse de génération : les FLOPS ou la bande passante ?

*Réponses :* 1. 14 × 8 ÷ 8 × 1,1 = 15,4 Go. 2. Parce qu'à chaque token il ne lit que ses paramètres actifs (5,1B ≈ 3,5 Go en MXFP4) alors que le 32B dense relit ses 17,6 Go ; la vitesse suit la quantité lue par token. 3. La bande passante mémoire (le modèle entier est relu à chaque token) ; les FLOPS bornent le prefill.

## 📚 Pour aller plus loin
- [llama.cpp — Performance on Apple Silicon M-series (discussion #4167)](https://github.com/ggml-org/llama.cpp/discussions/4167) 🇬🇧 — le tableau de référence M1 → M5 Ultra, mis à jour par la communauté.
- [Apple — Exploring LLMs with MLX and the Neural Accelerators in the M5 GPU](https://machinelearning.apple.com/research/exploring-llms-mlx-m5) 🇬🇧 — mesures officielles Apple (mémoire des modèles, TTFT, génération).
- [FormulaMod — Which NVIDIA GPU for local AI in 2026](https://www.formulamod.net/blogs/new/which-nvidia-gpu-for-local-ai-in-2026-rtx-3090-vs-4060-ti-vs-4070-ti-super-vs-4090-vs-5090) 🇬🇧 — benchmarks llama-bench RTX 3090 → 5090.
- [Presenc — RTX 5090 local LLM benchmarks 2026](https://presenc.ai/research/rtx-5090-local-llm-benchmarks-2026) 🇬🇧 et [Presenc — AMD Strix Halo benchmarks](https://presenc.ai/research/amd-strix-halo-local-llm-benchmarks-2026) 🇬🇧.
- [IntuitionLabs — NVIDIA DGX Spark review](https://intuitionlabs.ai/articles/nvidia-dgx-spark-review) 🇬🇧 et [Spheron — DGX Spark vs RTX 5090](https://www.spheron.network/blog/dgx-spark-vs-rtx-5090-for-local-llms-tokens-per-second-2026/) 🇬🇧 — capacité contre vitesse, chiffres d'octobre 2026.
- [Ajit Singh — LLM inference speed comparison (RTX 3060)](https://singhajit.com/llm-inference-speed-comparison/) 🇬🇧 — pour les cartes d'entrée de gamme.
- [Scaleway — Tarifs GPU](https://www.scaleway.com/en/pricing/gpu) 🇬🇧 et [OVHcloud — Public Cloud prices](https://ovhcloud.com/en/public-cloud/prices) 🇬🇧 — la location à l'heure chez deux hébergeurs français.

> ✅ **Si vous ne retenez que 3 choses** — 1. Formule de mémoire : milliards de paramètres × bits ÷ 8 × 1,1, plus un peu pour le contexte ; par défaut, choisissez un modèle en 4 bits (Q4_K_M). 2. La mémoire décide si le modèle **tient** (n'en utilisez que 75 % sur Mac, 90 % sur carte NVIDIA) ; la bande passante décide de sa **vitesse**. 3. Mieux vaut un modèle plus petit qui tient entièrement qu'un gros qui déborde ; les modèles MoE offrent souvent le meilleur compromis sur une machine courante.

> 🗺️ **Et maintenant ?** — Vous savez quelle taille de modèle votre machine supporte : en L043, vous installez Ollama et vous lancez votre premier modèle local en une commande.
