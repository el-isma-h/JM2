---
id: L039
module: M09
level: N2
title: "Make : scénarios avec modules IA"
minutes: 60
objectives:
  - "Construire pas à pas un scénario Make qui reçoit un e-mail, le classe avec un modèle de langage (OpenAI ou Anthropic) et l'achemine vers le bon outil"
  - "Appliquer les routeurs, filtres, itérateurs et agrégateurs pour piloter le flux de bundles"
  - "Mettre en place une gestion d'erreurs (Ignore, Resume, Break, Rollback, Commit) et des exécutions incomplètes"
  - "Estimer le nombre d'opérations consommées par un scénario et le confronter à la grille tarifaire Make"
skills: ["C2.1"]
sources:
  - { title: "Make Academy — accueil", url: "https://academy.make.com/", lang: "en" }
  - { title: "Make Academy — vue d'ensemble des cours (community)", url: "https://community.make.com/t/make-academy-course-overview/29699", lang: "en" }
  - { title: "Make Academy — parcours Automation to AI Agents: Advanced", url: "https://academy.make.com/bundles/automation-to-ai-agents-advanced-builder", lang: "en" }
  - { title: "Anthropic — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Anthropic — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview", lang: "en" }
  - { title: "OpenAI — Documentation API", url: "https://developers.openai.com/api/docs", lang: "en" }
---

# Make : scénarios avec modules IA

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 9

## 🎯 Ce que vous saurez faire
- Lire un scénario Make comme une phrase : « *quand* ceci arrive, *alors* fais cela, *sauf si*… ».
- Brancher un **module IA** (OpenAI ou Anthropic Claude) au milieu d'un scénario, lui faire rendre une réponse **JSON exploitable** et l'utiliser dans les modules suivants.
- Faire bifurquer le flux avec un **routeur** et des **filtres**, éclater une liste avec un **itérateur** et la recomposer avec un **agrégateur**.
- Protéger le scénario avec des **gestionnaires d'erreurs** (*error handlers*) et comprendre ce que Make fait des exécutions incomplètes.
- Compter les **opérations** avant d'activer un scénario, et donc anticiper la facture.

> 🧭 **En clair** — Make, c'est une chaîne de montage pour vos tâches numériques répétitives. Imaginez un tapis roulant dans un atelier : un colis (un e-mail, une ligne de tableur…) arrive au début, passe devant plusieurs postes de travail (les « bulles » de Make), et chaque poste fait une seule chose — lire, trier, ranger, prévenir. L'IA n'est qu'un poste de plus sur le tapis : un employé très rapide qui lit le colis et colle dessus une étiquette « devis », « réclamation » ou « facture ». Make vous facture au nombre de passages devant un poste (les « opérations ») : moins il y a de postes inutiles, moins vous payez.

## 1. Make en une image : le scénario, le bundle, l'opération

Vous avez passé le module 8 dans n8n : des nœuds, des connexions, des *items*. Make (ex-Integromat, société tchèque rachetée par Celonis en 2020) raconte la même histoire avec un vocabulaire différent et une interface très visuelle — des **bulles rondes** reliées par des fils, dans lesquelles on voit littéralement circuler les données pendant l'exécution.

| n8n | Make | Ce que c'est |
|---|---|---|
| Workflow | **Scénario** (*scenario*) | L'automatisation complète |
| Nœud | **Module** | Une action ou un déclencheur d'une application |
| Item | **Bundle** | Un paquet de données qui traverse les modules |
| Exécution d'un nœud | **Opération** | L'unité facturée : *un module qui traite un bundle = une opération* |
| Trigger | **Module déclencheur** (instantané ou planifié) | Ce qui lance le scénario |

Trois idées suffisent à tout comprendre :

1. **Le scénario se lit de gauche à droite.** Le premier module est toujours le déclencheur ; les suivants reçoivent les bundles un par un.
2. **Un bundle, c'est une ligne.** Si Gmail renvoie 12 e-mails, 12 bundles partent du module déclencheur et chaque module **en aval** s'exécute 12 fois (situé après lui sur le fil) — donc 12 opérations par module en aval. **Le déclencheur, lui, ne compte qu'une opération par passage**, quel que soit le nombre de bundles renvoyés.
3. **Le déclencheur est soit « instant », soit « planifié ».** Un déclencheur *instant* (icône éclair) est un webhook : l'application prévient Make à la seconde. Un déclencheur *planifié* (icône horloge) interroge l'application à intervalle régulier (toutes les 15 minutes par défaut) et consomme **une opération à chaque passage, même s'il n'y a rien de nouveau**. Multipliez : 4 passages/heure × 24 h × 30 jours ≈ 2 880 opérations par mois juste pour « regarder ». C'est la première ligne de votre budget.

> 💡 **À retenir** — Dans Make, vous ne payez ni les scénarios ni les utilisateurs : vous payez les **opérations**. Chaque bulle qui traite un bundle en coûte une (sauf le déclencheur : une par passage, quel que soit le nombre de bundles renvoyés). Un scénario bien conçu commence donc par la question « combien de bundles vont passer ici ? ».

```quiz
{
  "q": "Un déclencheur planifié Gmail vérifie la boîte toutes les 15 minutes pendant une journée où aucun e-mail n'arrive. Combien d'opérations a-t-il consommées ?",
  "options": [
    "Environ 96, une par passage",
    "Aucune, puisqu'il n'y avait rien à traiter",
    "Une seule, pour la journée entière",
    "Cela dépend du nombre de modules en aval"
  ],
  "answer": 0,
  "explanation": "Un déclencheur planifié consomme une opération à chaque passage, même à vide : 4 passages par heure × 24 h = 96 opérations. C'est pour cela qu'un déclencheur instantané (webhook) est souvent plus économique."
}
```


## 2. Le scénario que nous allons construire : « Tri SAV assisté par IA »

Cas d'entreprise : **Menuiserie Lefèvre**, 9 salariés, reçoit 40 à 80 e-mails par jour sur `contact@`. Devis, réclamations, factures de fournisseurs, publicités. La responsable administrative passe une heure chaque matin à trier. Objectif : à chaque e-mail entrant, un modèle de langage le classe en `devis`, `reclamation`, `facture_fournisseur` ou `autre`, estime l'urgence, puis Make range l'e-mail et prévient la bonne personne.

```
[Gmail : Watch emails]
        │  (1 bundle par e-mail)
        ▼
[Anthropic Claude : Create a message]   ← prompt de classification, réponse JSON
        │
        ▼
[JSON : Parse JSON]                      ← transforme le texte en champs exploitables
        │
        ▼
     ◇ Routeur ◇
   ┌────┼────────┬──────────────┐
   ▼    ▼        ▼              ▼
devis  réclam.  facture_fourn.  autre
 │      │        │              │
Sheets  Slack    Drive+Sheets   Gmail (label « À lire plus tard »)
```

Pour le reproduire, créez un compte Make (une offre gratuite existe — voir la page tarifs), puis **Create a new scenario**. Nous allons poser les bulles une à une.

### 2.1 Le déclencheur Gmail

Cliquez sur le « + », cherchez **Gmail**, choisissez **Watch emails**. Make vous demande une **connexion** (l'équivalent des *credentials* n8n) : c'est l'OAuth Google habituel. Paramétrez le dossier (`INBOX`), le critère (`Unread emails`) et surtout la **limite** (*Maximum number of results*) : 10 est raisonnable. Cette limite plafonne le nombre de bundles par exécution — donc les opérations.

Faites un clic droit sur le module → **Run this module only** : Make récupère un vrai e-mail et vous montre sa structure (`Subject`, `Text content`, `Sender email address`, etc.). Ces champs apparaîtront ensuite en **jetons colorés** (*mapping*) dans tous les modules suivants. Cette manipulation — exécuter le déclencheur seul pour « voir la donnée » — est le réflexe n° 1 des constructeurs Make, et c'est le premier cours de la Make Academy (*Setting up my first scenario*).

### 2.2 Le module IA : Anthropic Claude ou OpenAI

Ajoutez un second module. Deux applications vous intéressent :

- **Anthropic Claude** → module *Create a Message* (API Messages).
- **OpenAI (ChatGPT, Sora, DALL-E)** → module *Create a Completion* (ou l'équivalent « Responses » selon la version de l'application Make ; vérifiez le libellé dans l'interface, il évolue).

Les deux demandent une **clé API** que vous créez sur la console du fournisseur (`platform.claude.com/settings/keys` ou le dashboard OpenAI) et que vous collez **une seule fois** dans la connexion Make — jamais dans un champ de texte du module.

Choix du modèle : pour une classification courte, un modèle rapide et bon marché suffit. En novembre 2026, Claude Haiku 5.5 est facturé à partir de 0,10 $ / 0,50 $ par million de tokens en entrée/sortie, et gpt-6-luna 0,10 $ / 0,50 $ (prix USD, tarif standard, nov. 2026, pages Pricing des deux éditeurs). Un e-mail de 400 mots plus votre prompt représente environ 800 tokens en entrée et 60 en sortie : **moins d'un centième de centime par e-mail**. Le coût IA est négligeable ; ce sont les opérations Make qui pèseront.

Remplissez les champs :

- **Model** : `claude-haiku-5-5` (ou `gpt-6-luna`).
- **System prompt** (ou *Instructions*) :

```
Tu es l'assistant de tri du courrier de la Menuiserie Lefèvre.
Classe l'e-mail dans UNE catégorie parmi : devis, reclamation, facture_fournisseur, autre.
Estime l'urgence : haute, normale, basse.
Réponds UNIQUEMENT par un objet JSON valide, sans texte autour, de la forme :
{"categorie": "...", "urgence": "...", "resume": "une phrase de 20 mots max"}
```

- **User message** : mappez les jetons `Subject` et `Text content` du module Gmail, par exemple :
  `Objet : {{1.subject}}\n\nCorps :\n{{1.text}}`
- **Max tokens** : 150. Inutile de payer plus pour trois champs.

> 🧭 **Pas à pas pour débutant** — Vous ne tapez pas `{{1.subject}}` au clavier. Cliquez dans le champ *User message* : un panneau s'ouvre à côté, avec la liste des données des modules précédents (le chiffre 1 désigne le module n° 1, Gmail). Tapez le texte fixe (`Objet : `), puis **cliquez sur le jeton** *Subject* : il s'insère sous forme d'étiquette colorée. Faites de même pour *Text content*. Si le panneau est vide, c'est que le module Gmail n'a pas encore été exécuté : refaites le clic droit → *Run this module only*. Le bouton **Run once** se trouve en bas à gauche de l'écran ; après une exécution, une bulle avec un chiffre apparaît au-dessus de chaque module : cliquez dessus pour voir ce qui est entré et sorti.

Exécutez une fois (*Run once*) : la sortie contient le texte JSON du modèle. Il est encore une **chaîne de caractères** (un simple texte, comme une cellule Excel remplie d'une phrase) : Make ne sait pas que `categorie` est un champ.

> ⚠️ **Piège fréquent** — Oublier « sans texte autour ». Les modèles adorent écrire « Voici le JSON demandé : ». Le module *Parse JSON* suivant tombe alors en erreur. La parade : l'instruction explicite, un exemple dans le prompt et, pour les sorties critiques, l'usage des **sorties structurées** (*structured outputs*) que proposent les API Anthropic ([documentation](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧) et OpenAI, et que vous programmerez vous-même au niveau 3.

> 💡 **Autrement dit** — Le modèle de langage vous répond par une phrase écrite, même si cette phrase ressemble à un formulaire. Make, lui, ne lit pas : il a besoin de cases bien séparées (« catégorie », « urgence », « résumé »). Le module *Parse JSON* fait le travail d'une secrétaire qui recopie la réponse dans les bonnes cases d'un formulaire. Le JSON (*JavaScript Object Notation*), c'est simplement ce formulaire écrit en texte, avec des accolades et des guillemets.

### 2.3 Parse JSON : rendre la réponse exploitable

Ajoutez le module **JSON → Parse JSON**, champ *JSON string* = la sortie texte du module IA (chez Anthropic, le texte est dans `content[].text` ; Make vous propose le jeton). Exécutez : vous obtenez trois jetons propres, `categorie`, `urgence`, `resume`, utilisables partout en aval. Une opération de plus par e-mail, mais elle vous évite dix expressions fragiles.

## 3. Routeurs et filtres : faire bifurquer le flux

Ajoutez un **Router** (outil *Flow Control*). Un routeur duplique chaque bundle vers **toutes** ses branches ; ce sont les **filtres** posés sur chaque fil qui laissent passer ou non. Cliquez sur le fil de la première branche, nommez-la « Devis » et posez la condition `categorie` **Equal to** `devis`. Faites de même pour les trois autres.

> 🧭 **Pas à pas pour débutant** — Pour poser un filtre : après le routeur, ajoutez un module à chaque branche, puis cliquez sur la **petite clé à molette** (ou sur le fil en pointillés lui-même) entre le routeur et le module → *Set up a filter*. Donnez un nom (« Devis »), dans *Condition* cliquez sur le jeton `categorie` issu de *Parse JSON*, choisissez l'opérateur *Text operators → Equal to* et tapez `devis` en minuscules, sans accent ni espace. Pour la branche de repli : clic sur le fil → cochez *Fallback route*. Un filtre qui ne laisse jamais rien passer vient presque toujours d'une majuscule ou d'un espace en trop dans la valeur.

Deux subtilités que la Make Academy insiste à faire comprendre :

- **L'ordre des branches compte.** Make exécute les branches de haut en bas, l'une après l'autre, pour chaque bundle. Si une branche met à jour une donnée qu'une autre lit, placez-la en premier.
- **La « fallback route ».** Un routeur peut déclarer une branche de repli qui ne reçoit que les bundles rejetés par toutes les autres. C'est là que vous rangez `autre` : si demain le modèle invente une cinquième catégorie, rien n'est perdu.

Un filtre qui bloque un bundle **ne consomme pas d'opération** ; c'est la façon la plus économique de dire « non ». Posez donc vos filtres le plus tôt possible : filtrer avant le module IA (par exemple exclure les expéditeurs `noreply@`) économise un appel au modèle **et** une opération.

Garnissez les branches :

| Branche | Module | Mapping utile |
|---|---|---|
| Devis | Google Sheets → *Add a row* | Date, expéditeur, `resume`, `urgence`, lien vers l'e-mail |
| Réclamation | Slack → *Create a message* (canal `#sav`) | `:rotating_light:` si `urgence = haute`, `resume`, expéditeur |
| Facture fournisseur | Google Drive → *Upload a file* (pièce jointe) puis Sheets | Nom du fichier = `{{formatDate(now; "YYYY-MM-DD")}}-{{1.sender}}` |
| Autre (fallback) | Gmail → *Modify email labels* | Ajouter le libellé « À lire plus tard » |

```quiz
{
  "type": "mise_en_situation",
  "q": "Votre routeur a trois branches filtrées (devis, réclamation, facture). Le modèle répond soudain « partenariat », une catégorie que vous n'aviez pas prévue. Que se passe-t-il sans branche de repli ?",
  "options": [
    "Make crée automatiquement une quatrième branche",
    "L'e-mail ne suit aucune branche et sort du flux sans erreur",
    "Le scénario s'arrête en erreur et se désactive",
    "Le bundle est envoyé dans la première branche, traitée par défaut"
  ],
  "answer": 1,
  "explanation": "Un bundle rejeté par tous les filtres est simplement abandonné, sans message d'erreur. La « fallback route » sert justement à récupérer ces cas imprévus."
}
```

## 4. Itérateurs et agrégateurs : éclater, puis recomposer

Un e-mail « facture fournisseur » contient parfois **trois pièces jointes**. Dans le bundle Gmail, elles forment un **tableau** (*array*) `Attachments[]` — au sens informatique : une liste d'éléments, pas un tableau Excel. Or un module *Upload a file* ne sait traiter qu'un fichier à la fois.

C'est le rôle de l'**Iterator** : il prend un tableau et émet **un bundle par élément**. Trois pièces jointes → trois bundles → trois uploads. Placez-le juste avant Drive, champ *Array* = `Attachments[]`.

Problème symétrique : vous voulez ensuite **une seule** ligne Sheets listant les trois fichiers, pas trois lignes. C'est l'**Aggregator** : il consomme tous les bundles issus d'un itérateur donné (champ *Source module*) et n'en ressort qu'un. Make en propose plusieurs : **Array aggregator** (reconstruit un tableau), **Text aggregator** (concatène du texte, séparateur au choix), **Numeric aggregator** (somme, moyenne…), et l'agrégateur spécifique de certaines apps (*Create an archive* pour fabriquer un zip). Ici : *Text aggregator*, séparateur `, `, valeur = le lien Drive de chaque fichier. Résultat : `facture-01.pdf, facture-02.pdf, bon-livraison.pdf` dans une seule cellule.

```
[Iterator: Attachments[]] ─▶ [Drive: Upload] ─▶ [Text aggregator (source = Iterator)] ─▶ [Sheets: Add a row]
     3 bundles                  3 opérations          1 bundle en sortie                    1 opération
```

Comptez : 1 (itérateur) + 3 (uploads) + 1 (agrégateur) + 1 (Sheets) = 6 opérations pour cet e-mail, contre 2 pour un e-mail sans pièce jointe. C'est exactement l'objet du cours *Introduction to Iterators and Array aggregators* (niveau *Make Intermediate*).

> 💡 **À retenir** — Itérateur = « un tableau devient plusieurs bundles ». Agrégateur = « plusieurs bundles redeviennent un ». Les deux vont presque toujours par paire, et l'agrégateur doit désigner son itérateur comme *source module*.

```mermaid
flowchart LR
  A["1 e-mail<br/>3 pièces jointes"] --> B["Itérateur<br/>(éclate)"]
  B --> C1["PJ 1"] --> D["Agrégateur<br/>(recompose)"]
  B --> C2["PJ 2"] --> D
  B --> C3["PJ 3"] --> D
  D --> E["1 ligne Sheets"]
```

> 💡 **Autrement dit** — L'itérateur, c'est la personne qui ouvre un carton de trois bouteilles pour les poser une par une sur le tapis. L'agrégateur, c'est celle qui, au bout du tapis, remet les trois bouteilles dans un seul carton avec une étiquette récapitulative.


## 5. Gestion des erreurs : les cinq directives

Un jeudi, l'API du fournisseur IA répond 529 (*overloaded*) — code d'erreur signifiant « serveur surchargé, réessayez plus tard ». Sans gestionnaire d'erreur, Make arrête l'exécution, la marque en erreur et — après un certain nombre d'échecs consécutifs — **désactive le scénario**. Vos e-mails ne sont plus triés et personne ne le sait. Le cours *Error handling* de la Make Academy existe pour cette raison.

Clic droit sur un module → **Add error handler**. Une branche en pointillés apparaît, dans laquelle vous posez l'une des **directives** suivantes :

| Directive | Effet | Cas typique |
|---|---|---|
| **Ignore** | On oublie le bundle fautif, le scénario continue avec le suivant | Un e-mail illisible sur 50 |
| **Resume** | On remplace la sortie du module par une valeur de substitution que vous définissez, puis on continue | Le modèle IA ne répond pas → `categorie = "autre"`, `urgence = "normale"` |
| **Break** | Le bundle est stocké comme **exécution incomplète** (*incomplete execution*) ; vous pourrez la relancer manuellement ou automatiquement ; le scénario continue | Erreur transitoire (429, 5xx) — 429 = trop de demandes, 5xx = panne passagère du serveur d'en face : cochez « Automatically complete execution » avec un nombre d'essais et un intervalle — c'est le *retry* de Make |
| **Rollback** | Arrête l'exécution et annule, quand les modules le permettent, les actions déjà faites (transactions SQL, par exemple) — une transaction regroupe plusieurs écritures en base de données qui réussissent toutes ou échouent toutes | Écriture en base partielle |
| **Commit** | Arrête l'exécution mais valide ce qui a été fait | Vous préférez garder les premières lignes écrites |

Pour notre scénario : sur le module IA, un gestionnaire **Resume** qui force `{"categorie":"autre","urgence":"normale","resume":"Classement automatique indisponible"}`. L'e-mail finit dans « À lire plus tard » au lieu de bloquer les 49 suivants. Sur le module Drive, un **Break** avec reprise automatique (3 essais, 10 minutes).

Et comme dans n8n, un étage global : dans les **réglages du scénario**, activez *Allow storing of incomplete executions* et fixez le *Number of consecutive errors* avant désactivation. Puis créez un **second scénario** dont le déclencheur est *Make → Watch scenario incomplete executions* et qui vous écrit sur Slack. C'est votre « workflow d'erreur » façon Make.

> ⚠️ **Piège fréquent** — Poser un *Ignore* sur un module qui **crée** quelque chose (facture, paiement, ligne de CRM) : l'erreur disparaît des radars, et avec elle la trace du bundle perdu. Réservez *Ignore* aux données dont la perte est acceptable ; sinon, *Break* (on garde le bundle) ou *Resume* (on garde une trace).

```quiz
{
  "q": "L'API du fournisseur IA renvoie une erreur 429 (trop de requêtes) de temps en temps. Quelle directive choisir pour ne perdre aucun e-mail et retenter automatiquement plus tard ?",
  "options": [
    "Ignore (on ignore l'erreur)",
    "Commit (on arrête et valide)",
    "Rollback (on arrête et annule)",
    "Break (reprise automatique)"
  ],
  "answer": 3,
  "explanation": "Break range le bundle en « exécution incomplète » et, avec l'option « Automatically complete execution », le relance après un intervalle : c'est le mécanisme de nouvel essai (retry) de Make."
}
```


## 6. Opérations, tarification et budget

Faisons le compte pour la menuiserie, avec 60 e-mails/jour dont 10 avec pièces jointes (2 en moyenne) :

> 💡 **Autrement dit** — Le petit programme ci-dessous est écrit en Python, mais vous n'avez **rien à installer ni à exécuter** : il fait exactement le même calcul qu'une feuille Excel avec quatre cellules. (e-mails × 3) + (e-mails avec pièces jointes × 4) + (passages du déclencheur), puis × 30 jours. Refaites-le dans un tableur avec vos propres chiffres : c'est le livrable demandé dans l'exercice.

```python
# estimation_operations.py — ordre de grandeur mensuel du scénario « Tri SAV »
emails_par_jour = 60
pj_par_jour = 10           # e-mails avec pièces jointes
pj_moyenne = 2             # pièces jointes par e-mail concerné
jours = 30

# Chaque e-mail : IA(1) + Parse JSON(1) + branche finale(1) ; le déclencheur Gmail est compté dans polling
base = emails_par_jour * 3
# Pièces jointes : itérateur(1) + uploads(n) + agrégateur(1), en plus de la branche Sheets déjà comptée
pieces = pj_par_jour * (1 + pj_moyenne + 1)
# Déclencheur planifié toutes les 15 min : une opération par passage, même à vide, quel que soit le nombre d'e-mails renvoyés
polling = 4 * 24

par_jour = base + pieces + polling
print(f"≈ {par_jour} opérations/jour, soit ≈ {par_jour * jours:,} opérations/mois".replace(",", " "))
```

Résultat : 180 + 40 + 96 = 316 opérations par jour, soit **≈ 9 480 opérations par mois**. Le palier gratuit de Make (quelques centaines à un millier d'opérations mensuelles — chiffre à vérifier sur la page tarifs, il change régulièrement) ne suffit pas ; un forfait payant d'entrée de gamme, vendu par tranche de milliers d'opérations, le couvre. Make facture en **crédits** : 1 opération = 1 crédit pour les modules à coût fixe, mais certains modules coûtent plus d'un crédit et les modules IA de Make ont un coût variable. Trois leviers pour réduire la note :

1. **Filtrer avant l'IA** (newsletters, `noreply@`) : –20 % d'opérations IA et Parse.
2. **Passer le déclencheur en instant** quand l'application le permet (webhook Gmail via Google Cloud Pub/Sub, ou un autre service de messagerie) — Pub/Sub est un service technique de Google qui transmet des notifications ; sa mise en place demande un compte Google Cloud et l'aide d'un technicien : les 96 opérations de *polling* quotidiennes sont remplacées par une opération par e-mail reçu (60 par jour ici).
3. **Demander au modèle de traiter un lot** : agréger 10 e-mails en un seul prompt qui renvoie un tableau JSON, puis itérer. Dix appels deviennent un. Attention : plus le lot est grand, plus une erreur de parsing coûte cher. (Le *parsing* est la lecture automatique du JSON : si elle échoue, c'est tout le lot de dix e-mails qui est à refaire.)

Côté tarification, retenez la structure plutôt que les chiffres : des **forfaits mensuels ou annuels** (Free, Core, Pro, Teams, Enterprise en nov. 2026) différenciés par le **volume d'opérations**, l'**intervalle minimal** du planificateur, la taille des **data stores** (petites bases de données intégrées à Make, l'équivalent des Data Tables de n8n), le nombre de scénarios actifs et les fonctions d'équipe. Les montants exacts, les paliers d'opérations et la politique de dépassement sont **à vérifier sur la page tarifs officielle** (`make.com/en/pricing`) au moment où vous construisez votre dossier : ils ne sont pas repris ici volontairement, car ils évoluent plusieurs fois par an.

> 🔗 **Documentation officielle** — Le prix des appels IA, lui, est public et stable sur quelques mois : [Anthropic — Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 et la documentation API d'[OpenAI](https://developers.openai.com/api/docs) 🇬🇧. Pour Make, la référence pédagogique gratuite est la [Make Academy](https://academy.make.com/) 🇬🇧 (badges Credly, 6 mois d'accès par inscription).

```mission
{
  "title": "Combien dure le parcours « Automation to AI Agents: Advanced » de la Make Academy ?",
  "url": "https://academy.make.com/bundles/automation-to-ai-agents-advanced-builder",
  "steps": ["Ouvrez la page du parcours sur la Make Academy", "Repérez la durée annoncée et le niveau requis", "Cherchez le nom du badge délivré à la fin"],
  "question": "Quelle est la durée indicative du parcours et quel badge obtient-on ?",
  "hint": "Le badge porte le nom d'un métier : « AI Agent … ».",
  "answer": "Environ 3 heures, niveau « Experienced », badge « AI Agent Builder » (relevé nov. 2026 — le contenu du parcours peut évoluer).",
  "xp": 15
}
```

## 7. Et les « AI Agents » de Make ?

Depuis 2025, Make propose, en plus des modules IA classiques, des **agents** : vous définissez un modèle, des instructions et une liste de scénarios que l'agent peut appeler comme des outils ; l'agent décide lui-même de l'ordre. C'est le sujet du parcours *Automation to AI Agents* de la Make Academy (volet *Foundation* : AI Fundamentals, Mastering LLMs, Using AI in Make, AI Agents in Make ; volet *Advanced*, ≈ 3 h, badge « AI Agent Builder » : MCP, sécurité de l'information, *context engineering* (l'art de choisir quelles informations donner au modèle à chaque étape), agent prêt pour la production). Un parcours plus récent, **AI Automation Explorer** (annoncé le 8 mars 2026), reprend ces thèmes pour les non-développeurs.

Pour la menuiserie, un agent serait **surdimensionné** : le tri est un chemin fixe, prévisible, et un routeur suffit. Règle générale que vous retrouverez en L040 et au module 12 : *chemin connu → scénario ; chemin inconnu à l'avance → agent*. Un agent coûte plus d'opérations (chaque appel d'outil en consomme) et se teste plus difficilement.

🎮 **Défi** — Sans ouvrir Make, dessinez sur papier le scénario « Chaque lundi 8 h, résumer avec Claude les 5 derniers avis Google de l'entreprise et poster le résumé sur Slack ». Combien d'opérations par semaine, en supposant que l'application Avis renvoie les 5 avis en un seul bundle de tableau ? (Réponse : déclencheur planifié 1 + Avis 1 + Text aggregator… non ! Si le tableau arrive dans un seul bundle, inutile d'itérer : Claude 1 + Slack 1 = **4 opérations**. Si l'application renvoie 5 bundles : le module Avis s'exécute une fois et produit 5 bundles, que l'agrégateur regroupe en un seul, soit plus probablement 1 + 1 + agrégateur 1 + Claude 1 + Slack 1 = 5 ; la doc Make ne traite pas explicitement ce cas : vérifiez dans l'historique d'exécution.)

```mission
{
  "title": "Les conditions d'accès gratuites de la Make Academy",
  "url": "https://academy.make.com/",
  "steps": ["Ouvrez l'accueil de la Make Academy", "Cherchez les informations sur le prix et la durée d'accès", "Repérez la plateforme qui délivre les badges"],
  "question": "La Make Academy est-elle payante, combien de temps dure l'accès après inscription et sur quelle plateforme les badges sont-ils émis ?",
  "hint": "La plateforme de badges est aussi utilisée par de nombreux éditeurs de logiciels pour leurs certifications.",
  "answer": "Gratuite, sans abonnement ; 6 mois d'accès par inscription ; badges délivrés via Credly (relevé nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne** — Reproduisez le scénario « Tri SAV assisté par IA » dans votre compte Make, avec votre propre boîte Gmail (ou un compte de test) et une clé API Anthropic ou OpenAI. Puis envoyez-vous **cinq e-mails de test** : un devis, une réclamation urgente, une facture avec deux pièces jointes PDF, une newsletter et un e-mail volontairement vide.

> 🧭 **Pas à pas pour débutant** — Pour poser le gestionnaire d'erreur *Resume* : clic droit sur le module IA → **Add error handler** → *Resume*, puis remplissez les trois champs de substitution (`categorie` = `autre`, etc.). Pour envoyer la facture « avec deux pièces jointes », envoyez-vous un e-mail depuis une autre adresse en joignant deux PDF quelconques. Pour suivre les exécutions, ouvrez le scénario et cliquez sur l'onglet **History** en haut : chaque ligne est un passage ; cliquez sur *Details* pour revoir les bulles et leurs données. Pensez à **activer** le scénario (interrupteur *Scheduling* / *ON* en bas de l'écran) une fois les tests manuels réussis, sinon il ne tournera pas seul.

**Critères de réussite**
1. Les cinq e-mails produisent chacun la bonne branche (observable dans l'historique d'exécution, onglet *History*).
2. La facture donne **une seule** ligne Sheets listant les deux fichiers uploadés (preuve que l'agrégateur est bien relié à l'itérateur).
3. L'e-mail vide ne bloque pas le scénario : le gestionnaire *Resume* l'envoie dans « À lire plus tard ».
4. Le scénario comporte un filtre **avant** le module IA qui exclut au moins un expéditeur.
5. Vous rendez une estimation chiffrée des opérations mensuelles pour 60 e-mails/jour, et vous indiquez le forfait Make qui conviendrait, en citant la page tarifs consultée (date de consultation).

**Pistes de corrigé** — Si le *Parse JSON* échoue sur un e-mail, affichez la sortie brute du module IA : neuf fois sur dix, le modèle a ajouté une phrase ou des accents graves ```` ``` ```` (trois apostrophes inversées que les modèles utilisent pour encadrer du code). Renforcez le prompt (« sans balises de code ») ou remplacez l'instruction par une sortie structurée. Si l'agrégateur renvoie un bundle par fichier, c'est que son *source module* pointe sur Drive au lieu de l'itérateur. Si le total d'opérations vous semble élevé, vérifiez d'abord l'intervalle du déclencheur : passer de 15 à 60 minutes divise le *polling* par quatre sans changer le résultat métier pour un tri de courrier.

## ✅ Auto-évaluation express

1. Un module Google Sheets reçoit 25 bundles d'un itérateur. Combien d'opérations consomme-t-il ?
2. Quelle directive de gestion d'erreur conserve le bundle fautif pour une reprise ultérieure, automatique ou manuelle ?
3. Votre routeur a quatre branches filtrées et un e-mail ne correspond à aucune. Que se passe-t-il, et comment l'éviter ?

**Réponses** — 1. 25 opérations : une par bundle traité, quel que soit le module. 2. **Break**, qui crée une *exécution incomplète* (avec l'option de reprise automatique pour les erreurs transitoires). 3. Le bundle est simplement abandonné sans erreur ; déclarez une **fallback route** sur le routeur pour le récupérer.

## 📚 Pour aller plus loin

- [Make Academy — accueil](https://academy.make.com/) 🇬🇧 — cours gratuits *Foundation* → *Advanced* (modules, bundles, itérateurs, agrégateurs, *Error handling*, webhooks, data stores) ; badges Credly. Nous vous encourageons à passer au moins le niveau *Make Basics*.
- [Make Academy — Automation to AI Agents: Advanced](https://academy.make.com/bundles/automation-to-ai-agents-advanced-builder) 🇬🇧 — ≈ 3 h, badge « AI Agent Builder » : MCP, context engineering, agent de production.
- [Liste des cours Make Academy (community)](https://community.make.com/t/make-academy-course-overview/29699) 🇬🇧 — les intitulés exacts des cours par niveau.
- [Annonce du parcours AI Automation Explorer](https://community.make.com/t/make-academy-news-ai-automation-explorer/105070) 🇬🇧 — 8 mars 2026.
- [Anthropic — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview) 🇬🇧 — pour rendre votre prompt de classification plus robuste (exemples, format de sortie).
- [Anthropic — Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 — tarifs par modèle, cache, Batch.

> ✅ **Si vous ne retenez que 3 choses** — 1. Dans Make, on paie des **opérations** : chaque bulle qui traite un paquet de données en consomme une, et un déclencheur planifié en consomme même quand il n'y a rien. 2. Pour utiliser la réponse d'une IA, demandez-lui du JSON « sans texte autour », puis passez-la dans *Parse JSON* ; un routeur avec filtres et une branche de repli fait ensuite le tri. 3. Posez un gestionnaire d'erreur sur les modules fragiles (IA, envois) : *Resume* ou *Break* pour ne rien perdre, *Ignore* seulement pour ce qui peut l'être.

> 🗺️ **Et maintenant ?** — Vous savez construire un scénario Make ; la leçon L040 vous montre Zapier et vous donne une grille pour choisir, en toute objectivité, entre n8n, Make et Zapier selon votre situation.
