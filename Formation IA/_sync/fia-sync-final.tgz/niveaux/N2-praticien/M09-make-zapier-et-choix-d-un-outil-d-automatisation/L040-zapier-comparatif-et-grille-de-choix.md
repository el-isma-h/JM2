---
id: L040
module: M09
level: N2
title: "Zapier, comparatif et grille de choix"
minutes: 60
objectives:
  - "Construire un Zap à plusieurs étapes intégrant AI by Zapier, un filtre et un chemin (Paths), et expliquer ce qu'est une « tâche » facturée"
  - "Comparer n8n, Make, Zapier, Dify et Flowise selon le coût, l'hébergement, la confidentialité, la courbe d'apprentissage et l'IA native"
  - "Évaluer un besoin d'automatisation avec une grille de décision pondérée et justifier le choix d'un outil"
  - "Résoudre trois cas d'entreprise en argumentant le choix retenu et les alternatives écartées"
skills: ["C2.1", "C2.6"]
sources:
  - { title: "Zapier Academy — AI Builder Path", url: "https://learn.zapier.com/path/ai-builder-path", lang: "en" }
  - { title: "Zapier Academy — Building AI Agents", url: "https://learn.zapier.com/building-ai-agents", lang: "en" }
  - { title: "Zapier — Solution Partner Program", url: "https://zapier.com/l/new-experts/info", lang: "en" }
  - { title: "n8n Academy — catalogue des cours", url: "https://learn.n8n.io/courses", lang: "en" }
  - { title: "n8n Docs — Hébergement (hub)", url: "https://docs.n8n.io/deploy/host-n8n.md", lang: "en" }
  - { title: "Make Academy — accueil", url: "https://academy.make.com/", lang: "en" }
  - { title: "Dify — dépôt GitHub", url: "https://github.com/langgenius/dify", lang: "en" }
  - { title: "Flowise — dépôt GitHub", url: "https://github.com/FlowiseAI/Flowise", lang: "en" }
  - { title: "Langflow — dépôt GitHub", url: "https://github.com/langflow-ai/langflow", lang: "en" }
  - { title: "Future AGI — Dify vs Flowise vs Langflow 2026", url: "https://futureagi.com/blog/dify-vs-flowise-vs-langflow-2026/", lang: "en" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
---

# Zapier, comparatif et grille de choix

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 9

## 🎯 Ce que vous saurez faire
- Monter un **Zap** complet avec déclencheur, filtre, étape **AI by Zapier**, **Paths** et actions, et savoir ce que Zapier vous facture (les *tâches*).
- Situer **Zapier Agents** et Zapier MCP par rapport aux agents de Make et de n8n.
- Remplir un **tableau comparatif** n8n / Make / Zapier / Dify / Flowise sur cinq critères, sans vous laisser impressionner par le marketing.
- Utiliser une **grille de décision pondérée** pour choisir un outil — et la défendre devant un dirigeant ou une DSI. (DSI : direction des systèmes d'information, le service informatique.)
- Résoudre trois cas d'entreprise réalistes.

> 🧭 **En clair** — Choisir un outil d'automatisation, c'est comme choisir un moyen de transport. Zapier, c'est le taxi : vous montez, vous donnez l'adresse, et vous ne vous occupez de rien — mais la course a un prix. Make, c'est la voiture de location : plus de liberté, quelques réglages à connaître. n8n, c'est votre propre voiture : vous la garez chez vous (vos données restent à la maison), mais il faut l'entretenir. Dify et Flowise ne sont pas des voitures : ce sont des ateliers pour fabriquer un assistant qui répond à partir de vos documents. Cette leçon vous donne une grille simple pour choisir sans vous laisser séduire par la publicité.

## 1. Zapier : le pionnier et sa logique de « tâches »

Zapier existe depuis 2011 (trois fondateurs de Columbia, Missouri, sortis de l'incubateur Y Combinator en 2012). C'est l'outil qui a popularisé la phrase « *When this happens, do that* ». Son catalogue dépasse plusieurs milliers d'applications connectées (nov. 2026 ; chiffre exact sur le site de Zapier), ce qui reste son premier argument : si un logiciel SaaS américain existe (logiciel utilisé en ligne, par abonnement, sans rien installer), il a presque certainement une intégration Zapier.

Vocabulaire, en regard des deux outils précédents :

| n8n | Make | Zapier | |
|---|---|---|---|
| Workflow | Scénario | **Zap** | L'automatisation |
| Nœud | Module | **Step** (*Trigger* puis *Actions*) | Une étape |
| Exécution de nœud | Opération | **Task** (*tâche*) | L'unité facturée : *une action qui réussit* |
| IF / Switch | Routeur + filtres | **Filter** et **Paths** | La logique |
| Set / Code | Fonctions `{{ }}` | **Formatter** et **Code by Zapier** | La transformation |

La différence de facturation est subtile mais décisive : Zapier compte les **tâches**, c'est-à-dire les **actions qui aboutissent**. Le déclencheur, les filtres, les Paths, le Formatter et les délais (*Delay*) ne comptent pas ; chaque action « utile » (envoyer un e-mail, créer une ligne) compte une tâche, qu'elle traite une ligne ou cent. Un Zap « Gmail → Filter → Slack » qui tourne 500 fois dans le mois et ne passe le filtre que 200 fois consomme **200 tâches**, pas 1 500 opérations comme dans Make. En revanche, le ticket d'entrée des forfaits payants Zapier est historiquement plus élevé que celui de Make, et le palier gratuit est limité à un petit nombre de tâches mensuelles et à des Zaps simples. Chiffres et conditions : **voir la page tarifs officielle** (`zapier.com/pricing`), elle change souvent.

> 💡 **À retenir** — Make facture *tout ce qui bouge* (opérations), Zapier facture *ce qui réussit* (tâches). Un même besoin peut coûter quatre fois plus cher dans l'un ou dans l'autre selon la part de filtrage et de transformation. Comptez avant de choisir.

```quiz
{
  "q": "Un Zap « Gmail → Filter → Formatter → Slack » se déclenche 300 fois dans le mois ; 120 e-mails passent le filtre. Combien de tâches Zapier facture-t-il ?",
  "options": [
    "120 tâches",
    "300 tâches",
    "480 tâches",
    "1 200 tâches"
  ],
  "answer": 0,
  "explanation": "Seules les actions réussies comptent : le déclencheur, le filtre et le Formatter sont gratuits. Il reste l'action Slack, exécutée 120 fois."
}
```


## 2. Construire un Zap avec AI by Zapier et Paths

Reprenons la Menuiserie Lefèvre de la leçon précédente, cette fois en Zap.

**Étape 1 — Trigger.** `Gmail → New Email` (ou *New Email Matching Search* pour pré-filtrer côté Google, gratuitement : `-from:noreply`). Zapier récupère un exemple d'e-mail et vous montre ses champs ; comme dans Make, c'est votre moment « voir la donnée ».

> 🧭 **Pas à pas pour débutant** — Dans Zapier : bouton **+ Create** (en haut à gauche) → **Zaps**. Cliquez sur la case *Trigger*, cherchez « Gmail », choisissez l'événement *New Email*, puis *Continue* : Zapier vous demande de connecter votre compte Google (fenêtre d'autorisation, comme en leçon 36). Dernier onglet de chaque étape : **Test** → *Test trigger* ; Zapier affiche un vrai e-mail et ses champs. Pour ajouter l'étape suivante, cliquez sur le **+** sous l'étape. Dans les étapes suivantes, les champs des étapes précédentes s'insèrent en cliquant dans une case puis en choisissant dans la liste qui s'ouvre (comme les jetons de Make). Une fois toutes les étapes testées, cliquez sur **Publish** : tant que le Zap n'est pas publié, il ne tourne pas.

**Étape 2 — Filter by Zapier.** Condition : `From` *does not contain* `noreply`. Un bundle bloqué ici ne coûte rien.

**Étape 3 — AI by Zapier.** C'est l'application intégrée qui appelle un modèle de langage **sans clé API à fournir** : l'appel est inclus dans votre forfait (dans les limites décrites sur la page tarifs). L'action la plus utile est *Analyze and Return Data* (ou *Extract Data*, selon le libellé actuel) : vous écrivez l'instruction et vous **déclarez les champs de sortie** attendus — `categorie`, `urgence`, `resume`. Zapier se charge de forcer un format exploitable : vous n'avez pas de *Parse JSON* à ajouter. C'est plus simple que Make ; c'est aussi moins souple (choix de modèle restreint, pas de réglage fin, les données transitent par Zapier **puis** par le fournisseur qu'il a choisi — point à vérifier dans ses conditions de traitement des données si vous manipulez des informations personnelles).

Si vous voulez votre propre modèle, utilisez plutôt l'application **Anthropic (Claude)** ou **OpenAI** du catalogue Zapier avec votre clé : vous retrouvez alors les mêmes réflexes que dans Make (prompt « JSON uniquement », puis *Formatter → Utilities → Line-item / JSON* pour extraire les champs) — le nom exact de l'option varie : cherchez dans *Formatter* une action dont le libellé contient « JSON » ou « Line-item ».

**Étape 4 — Paths by Zapier.** L'équivalent du routeur : jusqu'à 10 chemins par groupe, chacun avec sa règle (`categorie` *exactly matches* `devis`…). Comme le routeur Make, Paths évalue chaque chemin : tous ceux dont la règle est vraie s'exécutent, de gauche à droite (vérifié le 5 nov. 2026 sur la page d'aide « Paths » de Zapier) ; écrivez donc des règles qui s'excluent mutuellement si un seul chemin doit s'appliquer. Pensez à un chemin « *Otherwise* » (le repli).

**Étape 5 — Actions.** Dans chaque chemin : *Google Sheets → Create Spreadsheet Row*, *Slack → Send Channel Message*, *Gmail → Add Label*… Chaque action réussie = une tâche.

Compte : pour 60 e-mails/jour dont 50 passent le filtre, le Zap consomme 50 × (1 AI by Zapier + 1 action finale) = **100 tâches/jour, ≈ 3 000 par mois**. Le même besoin coûtait ≈ 9 480 opérations dans Make (L039, § 6, recalcul de nov. 2026). Ne concluez pas trop vite : ce qui compte est le **prix au mois** de chaque forfait pour ce volume, à lire le jour J sur les deux pages tarifs.

**Gestion d'erreurs.** Zapier réessaie automatiquement certaines erreurs transitoires, puis place le Zap en *Zap Runs → Errors* et vous notifie par e-mail ; au-delà d'un taux d'erreur, il peut mettre le Zap en pause. Depuis 2023, un module **Error handler** peut être ajouté sur une étape : il ouvre une branche exécutée en cas d'échec (par exemple, écrire la ligne dans un onglet « Erreurs » et prévenir sur Slack). Le réglage **Autoreplay** rejoue automatiquement les exécutions échouées quand le service revient. C'est moins fin que les cinq directives de Make, mais couvre 90 % des besoins.

> ⚠️ **Piège fréquent** — Croire que Zapier est « plus cher parce qu'il compte tout ». C'est l'inverse : Zapier ignore les étapes techniques. Il devient cher quand vous enchaînez **beaucoup d'actions par événement** (créer la ligne, envoyer le mail, poster sur Slack, mettre à jour le CRM = 4 tâches), et bon marché quand vous filtrez beaucoup.

> 💡 **Autrement dit** — Dans Make, un routeur ressemble à un facteur qui dépose une copie de la lettre dans chaque boîte, puis seules les boîtes « autorisées » la gardent. Dans Zapier, *Paths* fonctionne de la même façon : la lettre est copiée sur **chaque** rail dont la règle est vraie, l'un après l'autre ; seul le rail de repli (*fallback*) ne sert que si aucun autre ne convient.


## 3. Zapier Agents, Tables, Interfaces et MCP

Zapier ne se limite plus aux Zaps. Trois briques comptent pour une petite équipe (nov. 2026 ; disponibilité par forfait sur le site) :

- **Zapier Tables** et **Interfaces** : une base de données légère et un constructeur de formulaires/pages, pour ne pas dépendre de Google Sheets.
- **Zapier Agents** (anciennement *Zapier Central*) : un agent en langage naturel qui dispose de vos connexions comme **outils**. Vous écrivez « Chaque matin, lis les nouveaux tickets Zendesk, propose une réponse et dépose-la en brouillon », et l'agent décide des appels à faire. Même logique que les agents Make et l'*AI Agent node* de n8n : puissant quand le chemin n'est pas connu à l'avance, plus coûteux et plus difficile à tester qu'un Zap.
- **Zapier MCP** : expose vos actions Zapier comme serveur **MCP** à un client comme Claude Desktop ou Claude Code. Vous demandez à Claude « ajoute cette personne dans mon HubSpot » et Claude appelle l'action Zapier correspondante. C'est le pont entre le monde des assistants (module 12) et celui de l'automatisation.

La **Zapier Academy** (gratuite) propose un *AI Builder Path* et un cours *Building AI Agents*. Zapier n'a **pas de certification grand public** : son « programme de certification » s'adresse aux partenaires du **Solution Partner Program** (ex-Zapier Experts : site professionnel et e-mail de domaine requis, niveaux de partenariat). Pour vous, l'intérêt est pédagogique : suivez le parcours, il est court.

```mission
{
  "title": "Que faut-il pour devenir partenaire certifié Zapier ?",
  "url": "https://zapier.com/l/new-experts/info",
  "steps": ["Ouvrez la page du Solution Partner Program", "Repérez la liste des conditions d'admission", "Cherchez le délai de traitement d'une candidature"],
  "question": "Quelles sont les deux conditions de base pour candidater, et en combien de temps la candidature est-elle traitée ?",
  "hint": "Les deux conditions concernent votre présence en ligne professionnelle.",
  "answer": "Un site web professionnel et une adresse e-mail sur votre propre nom de domaine ; traitement en 7 à 21 jours ouvrés (relevé nov. 2026 — conditions susceptibles d'évoluer).",
  "xp": 10
}
```

## 4. Le tableau comparatif : n8n, Make, Zapier, Dify, Flowise

Avant le tableau, deux nouveaux venus qui ne sont **pas** des outils d'intégration d'applications mais des **constructeurs d'applications IA** (*LLM app builders*) :

- **Dify** (`langgenius/dify`, ≈ 140 000 étoiles GitHub, nov. 2026) — GitHub est le site où les développeurs publient leur code ; les « étoiles » sont l'équivalent des « j'aime » et donnent une idée de la popularité : studio open source auto-hébergeable (au code public et réutilisable librement) pour créer des **chatbots, workflows et agents** avec une **base de connaissances RAG intégrée**, des plugins, le support MCP, et des fonctions d'entreprise (RBAC, SSO) — RBAC : droits d'accès par rôle (lecteur, éditeur, administrateur) ; SSO : connexion unique avec le compte de l'entreprise (Microsoft, Google). Licence « Dify OSS License » : Apache 2.0 **plus des conditions** sur l'usage multi-locataire (une seule installation partagée entre plusieurs clients) et le retrait du logo — à lire avant de le proposer comme produit à des clients.
- **Flowise** (`FlowiseAI/Flowise`, ≈ 52 600 étoiles) : constructeur visuel, licence **Apache 2.0** pure, fondé sur les composants **LangChain / LlamaIndex** (deux boîtes à outils de programmation pour applications IA) : vous assemblez modèle, mémoire, *retriever* (le composant qui va chercher les passages pertinents dans la base documentaire), outils, sur un canevas très proche des *cluster nodes* n8n du module 8.
- Pour mémoire, **Langflow** (`langflow-ai/langflow`, ≈ 148 000 étoiles, licence MIT) joue dans la même catégorie, avec des composants Python et l'export d'un flux en **serveur MCP** ; son service hébergé (DataStax) a été arrêté en avril 2026 (source : comparatif Future AGI 2026 cité en fin de leçon).

| Critère | **n8n** | **Make** | **Zapier** | **Dify** | **Flowise** |
|---|---|---|---|---|---|
| **Nature** | Automatisation + nœuds IA (cluster nodes), Agent Builder | Automatisation visuelle + modules IA + agents | Automatisation grand public + AI by Zapier + Agents + MCP | Constructeur d'apps IA (chat, workflow, agent, RAG) | Constructeur d'apps IA (LangChain visuel) |
| **Coût** | Auto-hébergé : gratuit hors serveur (≈ 5-20 €/mois de VPS) ; Cloud : abonnement par exécutions (page tarifs) | Forfaits par **opérations** ; palier gratuit ; page tarifs | Forfaits par **tâches** ; palier gratuit limité ; ticket d'entrée plus élevé ; page tarifs | Gratuit auto-hébergé ; offre cloud payante ; + coût des appels LLM | Gratuit auto-hébergé ; offre cloud ; + coût des appels LLM |
| **Hébergement** | Cloud **ou** vos serveurs (Docker Compose, npm, queue mode) — trois modes d'installation, du plus simple au plus puissant | SaaS uniquement (UE/US selon la zone du compte) | SaaS uniquement (États-Unis) | Vos serveurs (Docker Compose) ou cloud éditeur | Vos serveurs (Docker) ou cloud éditeur |
| **Confidentialité / RGPD** | Maîtrise totale en auto-hébergement ; seul le LLM voit les données si vous le choisissez | Sous-traitant ; données en transit chez Make puis chez le LLM ; DPA à signer (*Data Processing Agreement* : le contrat de sous-traitance exigé par le RGPD ; le « sous-traitant » est le prestataire qui traite des données pour votre compte) | Sous-traitant US ; transfert hors UE à encadrer (clauses contractuelles) — les « clauses contractuelles types » de la Commission européenne, à annexer au contrat ; AI by Zapier ajoute un intermédiaire | Maîtrise totale ; peut appeler un **LLM local** (Ollama) → zéro sortie de données | Idem Dify |
| **Courbe d'apprentissage** | Moyenne : expressions JS, structure items/JSON ; Academy gratuite (N8N101-103) | Faible à moyenne : très visuel ; fonctions et agrégateurs à apprendre ; Academy gratuite | **La plus faible** : assistant pas à pas, peu de concepts | Moyenne : notions de RAG, prompts, variables ; interface soignée | Moyenne à élevée : il faut comprendre LangChain (chaînes, retrievers) |
| **IA native** | Forte : AI Agent, chaînes, vector stores, MCP client/serveur, évaluations | Bonne : modules IA, agents, MCP ; pas de RAG intégré | Bonne : AI by Zapier sans clé, Agents, MCP ; pas de RAG intégré | **Très forte** : RAG intégré, agents, plugins, MCP, évaluation des prompts | Forte : tout LangChain ; RAG via composants |
| **Catalogue d'intégrations** | Plusieurs centaines + nœud HTTP universel | Plus de 2 000 apps + HTTP | **Le plus large** (plusieurs milliers) + Webhooks | Faible : ce n'est pas son rôle (outils via API/MCP) | Faible (idem) |
| **Idéal pour** | Équipes avec un profil technique, données sensibles, volumes élevés | PME sans développeur voulant du visuel riche et de la logique | Solopreneurs et équipes voulant zéro maintenance et un catalogue maximal | Assistant/RAG interne auto-hébergé, chatbot documenté, multi-utilisateurs | Prototyper une app LLM, enseigner LangChain visuellement |

Lecture honnête : **n8n, Make et Zapier résolvent le même problème** (relier des applications, avec de l'IA en option) ; **Dify et Flowise en résolvent un autre** (construire une application dont l'IA est le cœur : un assistant qui répond à partir de vos documents). Dans la pratique, les deux familles se **combinent** : un Zap ou un scénario Make appelle un chatbot Dify via webhook, ou n8n alimente la base de connaissances Dify chaque nuit.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : Dify est un concurrent direct de Zapier pour relier Gmail, HubSpot et Slack entre eux.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : Dify est un constructeur d'applications IA (chatbot, RAG, agent). Son catalogue d'intégrations est faible ; on le combine plutôt avec un outil d'automatisation comme n8n, Make ou Zapier."
}
```

```mission
{
  "title": "Lisez la licence de Dify avant de le revendre",
  "url": "https://github.com/langgenius/dify",
  "steps": ["Ouvrez le dépôt GitHub langgenius/dify", "Cliquez sur le fichier LICENSE (ou la mention License dans la colonne de droite)", "Lisez les conditions ajoutées à la base Apache 2.0"],
  "question": "Comment s'appelle la licence de Dify et sur quels deux points ajoute-t-elle des conditions à Apache 2.0 ?",
  "hint": "Pensez à un éditeur qui voudrait proposer Dify à plusieurs clients sous sa propre marque.",
  "answer": "« Dify Open Source License » (Dify OSS License) : Apache 2.0 plus des conditions sur l'usage multi-locataire (plusieurs clients sur une même instance) et sur le retrait du logo / de la marque Dify (relevé nov. 2026 — relisez le fichier LICENSE, il peut changer) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```


> 🔗 **Documentation officielle** — [Dify sur GitHub](https://github.com/langgenius/dify) 🇬🇧 · [Flowise sur GitHub](https://github.com/FlowiseAI/Flowise) 🇬🇧 · [n8n — Hébergement](https://docs.n8n.io/deploy/host-n8n.md) 🇬🇧. Pour le volet RGPD, les [fiches pratiques IA de la CNIL](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 (fiche 3 : qualification des fournisseurs ; fiche 12 : sécurité).

## 5. La grille de décision pondérée

Un comparatif ne décide rien : il faut le **peser** avec les priorités de l'organisation. Méthode en quatre temps, que vous retrouverez formalisée au module 15 (politique d'usage de l'IA) :

1. **Lister les critères** (6 à 8, pas plus).
2. **Attribuer un poids** à chaque critère, total 100.
3. **Noter chaque outil** de 1 (faible) à 5 (excellent) sur chaque critère, *pour ce cas précis*.
4. **Calculer** la somme des notes × poids ; discuter les deux premiers, pas seulement le premier.

Critères recommandés et questions pour les pondérer :

| Critère | Question à poser au commanditaire |
|---|---|
| Coût total sur 12 mois | Budget mensuel acceptable ? Volume prévu (événements/mois) ? Qui paie le temps de maintenance ? |
| Confidentialité / RGPD | Données personnelles ? Données de santé, financières, RH ? Le DPO exige-t-il un hébergement UE ou interne ? |
| Hébergement et maintenance | Y a-t-il quelqu'un pour mettre à jour un Docker ? Astreinte ? |
| Courbe d'apprentissage | Qui construira ? Qui maintiendra dans deux ans quand cette personne sera partie ? |
| IA native | Simple appel de modèle, ou RAG, agents, mémoire ? |
| Intégrations nécessaires | Les 5 logiciels de l'entreprise sont-ils connectés nativement ? |
| Réversibilité | Peut-on exporter les flux (JSON) et partir ? |

Petit script pour éviter les erreurs de calcul en atelier (et pour que les poids fassent bien 100) :

> 💡 **Autrement dit** — Le script ci-dessous est en Python, mais une feuille Excel fait exactement la même chose. Colonne A : les critères ; colonne B : les poids (vérifiez en bas `=SOMME(B2:B7)` = 100) ; colonnes C, D, E, F : les notes de 1 à 5 de chaque outil. Sous chaque colonne d'outil, la formule `=SOMMEPROD($B$2:$B$7;C2:C7)/100` donne le score sur 5 (recopiez-la vers la droite). C'est la moyenne pondérée de vos bulletins scolaires. Changez un poids : les scores se recalculent sous vos yeux, ce qui est idéal en réunion.

```python
# grille_decision.py — somme pondérée de 1 à 5, poids en pourcentage
criteres = {            # critère : poids (total = 100)
    "cout": 20, "rgpd": 30, "hebergement": 15,
    "apprentissage": 15, "ia_native": 10, "integrations": 10,
}
assert sum(criteres.values()) == 100, "Les poids doivent totaliser 100"

notes = {               # notes 1-5, cas « cabinet comptable » (voir § 6.1)
    "n8n":    {"cout": 4, "rgpd": 5, "hebergement": 3, "apprentissage": 3, "ia_native": 4, "integrations": 4},
    "Make":   {"cout": 3, "rgpd": 3, "hebergement": 5, "apprentissage": 4, "ia_native": 3, "integrations": 4},
    "Zapier": {"cout": 2, "rgpd": 2, "hebergement": 5, "apprentissage": 5, "ia_native": 3, "integrations": 5},
    "Dify":   {"cout": 4, "rgpd": 5, "hebergement": 3, "apprentissage": 3, "ia_native": 5, "integrations": 2},
}

for outil, n in notes.items():
    score = sum(n[c] * p for c, p in criteres.items()) / 100
    print(f"{outil:<8} {score:.2f} / 5")
```

Sortie (cas 6.1) : n8n 4,00 ; Dify 3,90 ; Make 3,55 ; Zapier 3,30. Le résultat n'est pas une vérité : c'est un **support de discussion**. Si le DPO baisse le poids RGPD à 15 et que le dirigeant monte « apprentissage » à 30, Make passe devant. C'est précisément ce que la grille doit rendre visible.

> 💡 **À retenir** — Une grille pondérée ne sert pas à avoir raison, elle sert à **rendre les priorités explicites**. Montrez toujours ce qui ferait changer le classement.

```mermaid
flowchart LR
  A["1. Lister<br/>6 à 8 critères"] --> B["2. Pondérer<br/>total = 100"]
  B --> C["3. Noter<br/>chaque outil de 1 à 5"]
  C --> D["4. Calculer<br/>et discuter les 2 premiers"]
```

> 💡 **Autrement dit** — La grille pondérée, c'est la méthode du conseil de classe : chaque matière (critère) a un coefficient (poids), chaque élève (outil) reçoit une note, et la moyenne pondérée permet d'en discuter — sans oublier qu'un changement de coefficient peut changer le classement.


## 6. Trois cas d'entreprise résolus

### 6.1 Cabinet d'expertise comptable, 12 personnes, Lyon

**Besoin** : chaque mois, 300 clients envoient relevés et factures par e-mail ; il faut les classer par dossier, extraire date, montant, TVA, et les déposer dans l'outil de production comptable. Données **financières et personnelles**, secret professionnel. Un alternant en BTS SIO (diplôme d'informatique de niveau bac + 2), à l'aise avec Docker, est présent 3 jours par semaine ; le cabinet a déjà un petit serveur chez un hébergeur français.

**Analyse** : poids RGPD très élevé (30), coût modéré, hébergement interne possible grâce au serveur et à l'alternant. Le besoin est une **automatisation** (relier Gmail, un extracteur et l'outil comptable), pas un chatbot : Dify est moins adapté malgré sa bonne note.

**Décision** : **n8n auto-hébergé** (Docker Compose, PostgreSQL, sauvegardes), modèle de langage choisi pour l'extraction : soit un fournisseur avec DPA et option de résidence européenne, soit un **modèle local** (module 10) si les volumes le permettent. Workflow d'erreur global (L033), Data Table pour la file d'attente, revue humaine des montants > 5 000 €.

**Écartés** : Zapier (transfert US, coût des tâches à 300 × 4 actions = 1 200 tâches, mais surtout le DPO), Make (acceptable avec DPA mais n'apporte rien que n8n n'ait, et ajoute un sous-traitant).

**Risque à documenter** : la dépendance à l'alternant. Prévoir une documentation des workflows et une formation d'un second salarié — ou un n8n Cloud en plan B si l'auto-hébergement n'est plus tenu.

### 6.2 Agence de communication, 5 personnes, Nantes

**Besoin** : relier HubSpot (CRM), Notion (projets), Gmail, Slack et un outil de signature électronique. À chaque devis signé, créer le projet Notion, le canal Slack, l'e-mail de bienvenue rédigé par IA et la tâche de facturation. Environ 40 signatures par mois, plus quelques centaines d'événements secondaires. **Personne de technique** ; la fondatrice veut « que ça marche et que ce soit joli ». Données clients B2B, peu sensibles.

**Analyse** : apprentissage et absence de maintenance pèsent le plus (poids 30 et 20), RGPD modéré (15). Le volume est faible : ≈ 40 × 5 actions + 300 événements ≈ 500 tâches ou ≈ 2 500 opérations par mois — les deux outils SaaS entrent dans un forfait d'entrée de gamme (à vérifier sur les pages tarifs).

**Décision** : **Make**. Le routeur visuel, les agrégateurs (regrouper les lignes de devis en un e-mail) et le coût par opération à faible volume conviennent ; la Make Academy gratuite forme la fondatrice en deux soirées. Module IA Anthropic ou OpenAI avec clé propre pour la rédaction de l'e-mail, et un gestionnaire *Resume* qui envoie un texte générique si le modèle échoue.

**Alternative sérieuse** : **Zapier**, si l'un des cinq logiciels n'était pas disponible dans Make ou si l'équipe préfère la simplicité des Zaps linéaires à la richesse du canevas. C'est le cas où les deux outils sont presque interchangeables : tranchez sur la page tarifs et sur un essai gratuit de deux semaines chacun.

**Écartés** : n8n (pas de profil technique, le Cloud n8n serait possible mais la courbe d'apprentissage est plus raide), Dify/Flowise (hors sujet : ce n'est pas une application IA).

### 6.3 PME industrielle, 180 salariés, DSI de 4 personnes, Alsace

**Besoin** : un **assistant interne** qui répond aux questions des techniciens et commerciaux à partir de 2 000 fiches produit, notices et procédures qualité (PDF, Word, SharePoint). Authentification par l'annuaire d'entreprise (SSO), traçabilité des questions, et interdiction formelle de laisser sortir les documents techniques (secret industriel). Budget : un serveur avec GPU est disponible. (Le GPU est la carte graphique, le composant qui accélère l'IA ; voir le module 10.)

**Analyse** : c'est une **application IA** (RAG, chat multi-utilisateurs, droits), pas une automatisation. Les critères dominants sont la confidentialité (35), l'IA native (25) et l'hébergement interne (15). La DSI maîtrise Docker et Kubernetes. (Kubernetes : un outil qui pilote de nombreux conteneurs Docker à la fois, sur plusieurs serveurs.)

**Décision** : **Dify auto-hébergé** : base de connaissances avec découpage et embeddings intégrés, chatflow, SSO/RBAC, journal des conversations. Modèle de langage et modèle d'embeddings **locaux** via Ollama ou vLLM sur le serveur GPU (module 10) — deux logiciels qui font tourner des modèles ouverts ; vLLM vise les serveurs à fort trafic, ce qui annule le risque de fuite. Évaluation sur 50 questions de référence avant ouverture (critère de la compétence C2.2 : 8 bonnes réponses sur 10).

**Compléments** : un **n8n** à côté, qui surveille SharePoint et pousse chaque nouvelle fiche dans la base Dify via son API, chaque nuit. C'est l'exemple type de la combinaison « constructeur d'app IA + outil d'automatisation ».

**Écartés** : Flowise (licence plus permissive, mais pas de SSO/RBAC natif à ce niveau et une interface moins adaptée à 180 utilisateurs finaux — choix défendable pour prototyper), Make/Zapier (SaaS, données sortantes, pas de RAG), n8n seul (son Agent Builder et ses vector stores permettraient un prototype, mais pas une application de chat pour 180 personnes avec droits fins).

🎮 **Défi** — Une boulangerie-pâtisserie de 3 personnes veut recevoir sur WhatsApp un résumé IA des avis Google chaque dimanche soir et répondre aux avis en un clic. Quel outil, et pourquoi en deux phrases ? (Piste : volume minuscule, zéro maintenance, données publiques → **Zapier ou Make**, le premier qui propose nativement l'application d'avis et la messagerie souhaitées ; la confidentialité ne pèse presque rien ici.)

```quiz
{
  "type": "mise_en_situation",
  "q": "Une mutuelle veut un assistant interne qui répond aux questions des conseillers à partir de 500 procédures, avec interdiction de faire sortir les documents du réseau. Quel choix est le plus cohérent ?",
  "options": [
    "Zapier avec AI by Zapier",
    "Make avec un module OpenAI",
    "Dify auto-hébergé avec un modèle local via Ollama",
    "Un Zap qui envoie chaque question par e-mail à un expert"
  ],
  "answer": 2,
  "explanation": "Le besoin est une application IA (RAG, chat multi-utilisateurs) et la confidentialité est prioritaire : Dify auto-hébergé avec un modèle local garde toutes les données à l'intérieur, comme dans le cas 6.3."
}
```

## 🧪 Exercice pratique

**Consigne** — Choisissez une organisation que vous connaissez (votre employeur, un client, une association). Rédigez une **note de décision d'une page** comprenant :

1. le besoin en trois lignes, avec le volume mensuel estimé d'événements ;
2. la grille pondérée (6 à 8 critères, poids totalisant 100, notes 1-5 pour au moins quatre des cinq outils, scores calculés) ;
3. le choix retenu et les deux alternatives écartées, avec une phrase de justification chacune ;
4. ce qui ferait changer la décision (un poids, une contrainte) ;
5. le coût mensuel estimé : nombre de tâches **ou** d'opérations **ou** coût du serveur, plus le coût IA calculé à partir des pages tarifs des éditeurs (citez les pages et leur date de consultation).

> 🧭 **Pas à pas pour débutant** — Vous n'avez pas testé les cinq outils ? C'est normal. Justifiez chaque note par un **fait vérifiable** tiré de cette leçon ou d'une page officielle : « Zapier : hébergement aux États-Unis (tableau § 4) → RGPD 2/5 », « Make : Make Academy gratuite (L039) → apprentissage 4/5 ». Une note sans fait associé doit être considérée comme provisoire et signalée comme telle. Pour le volume mensuel, partez d'un comptage réel : par exemple le nombre d'e-mails reçus sur une semaine dans la boîte concernée, multiplié par 4.

**Critères de réussite** — Les poids totalisent 100 ; chaque note est justifiée par un fait (pas « Zapier est nul ») ; la distinction automatisation / application IA est explicite ; la question RGPD (où vont les données, quel sous-traitant, quel transfert) est traitée ; aucun chiffre de tarif n'est cité sans source datée.

**Pistes de corrigé** — Les erreurs classiques : oublier le coût du temps humain d'un auto-hébergement (comptez au moins 2 heures par mois de mises à jour et de sauvegardes) ; noter l'IA native 5/5 pour un besoin qui n'appelle le modèle qu'une fois ; choisir Dify pour relier deux applications ; choisir Zapier pour un flux avec dix actions par événement sans avoir multiplié. Une bonne note se termine toujours par un **pilote** : deux semaines d'essai gratuit avec cinq événements réels par jour.

## ✅ Auto-évaluation express

1. Un Zap « Nouveau formulaire → Filter → Formatter → Slack → Sheets » tourne 400 fois dans le mois ; 150 passent le filtre. Combien de tâches ?
2. Quel outil du tableau intègre nativement une base de connaissances RAG et peut appeler un modèle local pour qu'aucune donnée ne sorte du réseau ?
3. Dans une grille pondérée, à quoi sert de montrer « ce qui ferait changer le classement » ?

**Réponses** — 1. **300 tâches** : Filter et Formatter ne comptent pas, les deux actions réussies (Slack, Sheets) comptent pour chacune des 150 exécutions passantes. 2. **Dify** (Flowise le permet aussi en assemblant les composants, mais sans RAG « clé en main » ni SSO/RBAC natif). 3. À rendre les priorités explicites et à éviter qu'un choix d'outil se fasse sur un argument caché ; c'est aussi ce qui permet au décideur de s'approprier la décision.

## 📚 Pour aller plus loin

- [Zapier Academy — AI Builder Path](https://learn.zapier.com/path/ai-builder-path) 🇬🇧 — parcours gratuit : Zaps avec IA, Agents, bonnes pratiques.
- [Zapier Academy — Building AI Agents](https://learn.zapier.com/building-ai-agents) 🇬🇧 — cours dédié aux Zapier Agents.
- [Zapier — Solution Partner Program](https://zapier.com/l/new-experts/info) 🇬🇧 — le seul « programme de certification » Zapier, réservé aux partenaires.
- [n8n Academy — catalogue](https://learn.n8n.io/courses) 🇬🇧 — N8N101, N8N102, N8N103 (programme « n8n Foundations », 70 % requis, badge Accredible). Nous vous encourageons à passer les trois.
- [Make Academy](https://academy.make.com/) 🇬🇧 — cours gratuits et badges Credly.
- [Future AGI — Dify vs Flowise vs Langflow (2026)](https://futureagi.com/blog/dify-vs-flowise-vs-langflow-2026/) 🇬🇧 — comparatif technique des trois constructeurs d'applications IA.
- [Langflow sur GitHub](https://github.com/langflow-ai/langflow) 🇬🇧 — le troisième constructeur, licence MIT, export en serveur MCP.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — qualification des fournisseurs, sécurité, information des personnes.

> ✅ **Si vous ne retenez que 3 choses** — 1. Zapier facture les actions qui réussissent (tâches), Make tout ce qui passe dans une bulle (opérations) : comptez votre volume réel avant de comparer les prix. 2. n8n, Make et Zapier relient des applications ; Dify et Flowise fabriquent des assistants IA à partir de vos documents — les deux familles se combinent. 3. Pour choisir, utilisez une grille pondérée (poids = 100, notes de 1 à 5 justifiées par des faits) et montrez ce qui ferait changer le classement.

> 🗺️ **Et maintenant ?** — Plusieurs cas de cette leçon reposaient sur un « modèle local » : le module 10 (L041) vous explique pourquoi et quand faire tourner l'IA sur votre propre machine.
