---
module: M09
title: "Fiche mémo — Make, Zapier et choix d'un outil d'automatisation"
---
# Fiche mémo — M09 · Make, Zapier et choix d'un outil d'automatisation

> En une phrase : Make facture ce qui bouge (opérations), Zapier ce qui réussit (tâches), n8n ce que coûte votre serveur ; Dify et Flowise fabriquent des applications IA ; on choisit avec une grille pondérée, pas avec la publicité.

## Les 7 idées à retenir
1. **Make = un tapis roulant de bulles** : scénario, module, bundle. Un module qui traite un bundle = une opération ; le déclencheur ne compte qu'**une opération par passage** (`L039`).
2. **Le module IA rend du texte** : exigez « JSON uniquement, sans texte autour », puis *Parse JSON* (ou une sortie structurée) (`L039`).
3. **Routeur + filtres** : le routeur copie chaque bundle vers toutes les branches, les filtres trient ; un filtre qui bloque ne coûte rien ; prévoyez une *fallback route* (`L039`).
4. **Itérateur / agrégateur** vont par paire : ouvrir le carton de bouteilles, puis le refaire ; l'agrégateur désigne son itérateur comme *source module* (`L039`).
5. **Erreurs Make** : Ignore, Resume, Break (exécution incomplète, reprise), Rollback, Commit. Jamais *Ignore* sur une création (`L039`).
6. **Zapier = le taxi** : catalogue maximal, zéro maintenance ; déclencheur, Filter, Paths, Formatter et Delay ne comptent pas, chaque action réussie = une tâche (`L040`).
7. **Deux familles d'outils** : n8n, Make, Zapier relient des applications ; Dify et Flowise construisent une application dont l'IA est le cœur (RAG). Elles se combinent (`L040`).

## Le schéma à connaître

```mermaid
flowchart LR
  A["1. Lister<br/>6 à 8 critères"] --> B["2. Pondérer<br/>total = 100"]
  B --> C["3. Noter chaque outil<br/>de 1 à 5, pour ce cas"]
  C --> D["4. Calculer notes × poids"]
  D --> E["Discuter les 2 premiers<br/>et ce qui changerait le classement"]
  E --> F["Pilote de 2 semaines"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Scénario / Zap | L'automatisation complète chez Make / chez Zapier |
| Bundle | Une ligne de données qui traverse les modules (l'*item* de n8n) |
| Opération (Make) | Un passage devant un poste, facturé en **crédits** |
| Tâche (Zapier) | Une action qui aboutit |
| Polling | Le déclencheur qui va voir la boîte aux lettres à intervalle fixe |
| Exécution incomplète | Le bundle mis de côté par *Break*, à relancer plus tard |
| AI by Zapier | L'appel de modèle inclus dans le forfait, sans clé API |
| Zapier MCP | Vos actions Zapier exposées comme outils à Claude |

## Les pièges classiques
- Oublier que le déclencheur planifié coûte une opération **même quand il n'y a rien** : 15 min → ≈ 2 880 opérations par mois rien que pour regarder.
- Laisser le modèle écrire « Voici le JSON demandé : » : *Parse JSON* tombe en erreur.
- Filtrer après l'IA au lieu d'avant : vous payez l'appel et l'opération pour rien.
- Agrégateur relié au mauvais module : un bundle par fichier au lieu d'un seul.
- Croire Zapier « plus cher parce qu'il compte tout » : il devient cher quand on enchaîne beaucoup d'actions par événement.
- Choisir Dify pour relier deux applications, ou Zapier pour dix actions par événement sans multiplier.
- Oublier le temps humain d'un auto-hébergement (au moins 2 heures par mois).

## Les commandes / chiffres / dates utiles
- **Mnémo des directives Make « I-R-B-R-C »** : **I**gnore (on oublie) · **R**esume (valeur de secours) · **B**reak (on garde pour reprise) · **R**ollback (on annule) · **C**ommit (on valide).
- Calcul Make (60 e-mails/jour, sondage toutes les 15 min) : 180 + 40 + 96 = **316 opérations/jour ≈ 9 480/mois**. Le même besoin en Zapier ≈ 100 tâches/jour ≈ 3 000/mois. Comparez ensuite les **prix des forfaits** le jour J.
- 3 leviers d'économie Make : filtrer avant l'IA · déclencheur instantané (webhook) · traiter un lot de 10 e-mails en un seul prompt.
- Modules IA de Make : coût variable en crédits ; routeurs et filtres ne consomment rien.
- Coût IA d'un tri d'e-mail avec Haiku 5.5 ou gpt-6-luna (0,10 / 0,50 $ par M tokens) : moins d'un centième de centime.
- Licences : Flowise Apache 2.0 ; Langflow MIT ; Dify « Dify OSS License » (Apache 2.0 + conditions multi-locataire et logo). Zapier : pas de certification grand public. Make AI Automation Explorer annoncé le 8 mars 2026.
- Tarifs exacts : toujours sur `make.com/en/pricing` et `zapier.com/pricing`, avec la date de consultation.

## Pour aller plus loin
- [Make Academy](https://academy.make.com/)
- [Zapier Academy — AI Builder Path](https://learn.zapier.com/path/ai-builder-path)
- [Dify sur GitHub](https://github.com/langgenius/dify)

## Auto-test (3 questions — réponses en bas de fiche)
1. Un module Google Sheets reçoit 25 bundles d'un itérateur : combien d'opérations ?
2. Un Zap « Formulaire → Filter → Formatter → Slack → Sheets » tourne 400 fois, 150 passent le filtre : combien de tâches ?
3. Une PME industrielle veut un assistant interne sur 2 000 fiches, SSO et zéro fuite : quel outil ?

---
**Réponses** — 1. 25 opérations (une par bundle traité). 2. 300 tâches (2 actions × 150) ; Filter et Formatter ne comptent pas. 3. Dify auto-hébergé avec modèles locaux, et un n8n à côté pour alimenter la base chaque nuit.
