---
module: M13
title: "Fiche mémo — Données et analyse avec l'IA"
---
# Fiche mémo — M13 · Données et analyse avec l'IA

> En une phrase : l'IA est un comptable très rapide mais distrait ; donnez-lui des données propres, faites-la calculer avec une vraie calculatrice (du code), gardez un total de contrôle, et dans un reporting automatique : **le code calcule, le modèle rédige**.

## Les 7 idées à retenir
1. **Préparer avant d'envoyer** : une ligne d'en-têtes, noms explicites (HT/TTC, unité), point décimal, dates ISO, données pseudonymisées, un seul onglet (`L055`).
2. **De tête ou en code ?** Un calcul « de tête » n'a aucune garantie ; exigez du code exécuté et **affiché** (bac à sable) (`L055`).
3. **Les erreurs sont surtout des décisions silencieuses** : avoir exclu, doublon supprimé, vide remplacé par zéro. Décrivez vous-même les règles de nettoyage et demandez la liste des hypothèses (`L055`).
4. **Une figure = une question = un message dans le titre** ; le temps à l'horizontale, les barres partent de zéro, pas de camembert au-delà de 4 parts (`L056`).
5. **Text-to-SQL** : schéma + règles métier + dialecte + question = requête juste neuf fois sur dix (`L057`).
6. **Garde-fous mécaniques** : compte en lecture seule, copie de test aux réponses connues, totaux de contrôle (`L057`).
7. **Reporting automatique** : réveil → données → code (KPI) → LLM (rédaction, chiffres recopiés tels quels) → contrôle des chiffres → diffusion, avec Error Trigger (`L058`).

## Le schéma à connaître

```mermaid
flowchart LR
  A["Schedule Trigger<br/>lundi 7 h 30"] --> B["Google Sheets<br/>ou base en lecture seule"]
  B --> C["Code : calcule les KPI<br/>(un seul item JSON)"]
  C --> D["Basic LLM Chain<br/>rédige, ne recalcule pas"]
  D --> E{"Code : chaque chiffre<br/>du texte est-il dans le JSON ?"}
  E -- "oui" --> F["Gmail + Slack<br/>direction"]
  E -- "non" --> G["Responsable du reporting<br/>+ avertissement"]
  X["Error Trigger"] -.-> H["Alerte Slack #ops"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Bac à sable (sandbox) | La pièce fermée où l'IA fait tourner son petit programme de calcul |
| Total de contrôle | Un chiffre connu d'avance (total, nombre de lignes) qui doit tomber juste |
| Avoir | Une ligne négative (un retour client) : à garder, pas à « corriger » |
| Schéma | Le plan du meuble à tiroirs : tables, colonnes, types, règles métier |
| Dialecte SQL | L'accent du SQL (SQLite, PostgreSQL, MySQL…), surtout pour les dates |
| `JOIN` / `GROUP BY` / `HAVING` | Relier deux tables / regrouper et agréger / filtrer sur les totaux |
| Skill `xlsx` | Le mode d'emploi qui fait produire à Claude un Excel **avec formules** |

## Les pièges classiques
- Coller 300 lignes dans le chat : au-delà d'une centaine, joignez le fichier et exigez du code.
- « Supprime les lignes bizarres » : l'avoir, le gros client et une date disparaissent.
- Arrondir en cours de calcul (59,90 € → 60 €) : l'erreur se propage. Arrondis à la fin.
- Trois chiffres hallucinés : le plausible, le sans source, le recomposé (la somme des parties ≠ le total).
- SQL : un `WHERE quantite > 0` non demandé, un `WHERE` manquant, une division entière, un « meilleur » ambigu, une jointure qui multiplie.
- Coller un extrait de la vraie base « pour que l'IA comprenne » : le schéma suffit.
- Demander une comparaison sans fournir la semaine précédente dans le JSON : le modèle l'invente.

## Les commandes / chiffres / dates utiles
- **Vérification en 4 points, mnémo « T-S-E-C »** : **T**otal de contrôle · **S**omme des parties · cas **E**xtrême (« comment as-tu traité C-1016 ? ») · **C**ontre-épreuve tableur (`=SOMME.SI.ENS`).
- Jeu Mobidesk (fil rouge) : 24 lignes, CA total **33 500,00 €**, avoir C-1016 (−349 €), T1 → T2 **+39,4 %**. Si vous trouvez 34 198 €, l'avoir a été compté en positif ; 33 849 €, il a été exclu.
- Prompt d'analyse en 5 blocs : contexte, données, question, format (2 décimales), garde-fous (« exécute du code et affiche-le », « ne modifie aucune ligne sans me le signaler », « liste tes hypothèses »).
- Graphique : 6 informations obligatoires (données, question, type, axes et unités, titre-message, format) + « vérifie que la somme fait le total ».
- SQLite : ouvrir en `mode=ro` ; dates avec `strftime('%m', date)` (PostgreSQL : `EXTRACT(MONTH FROM date)`).
- Coût d'un rapport hebdomadaire avec Haiku 5.5 ≈ 0,0002 $ ; Message Batches à −50 % pour des centaines de rapports.

## Pour aller plus loin
- [Claude Platform — Code execution tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool)
- [Claude Platform — Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview)
- [n8n Academy — N8N103 In Practice](https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about)

## Auto-test (3 questions — réponses en bas de fiche)
1. La somme du CA par produit fait 33 210 € alors que le total affiché est 33 500 € : que s'est-il passé ?
2. Une jointure `ventes` × `objectifs` donne 67 000 € de CA : pourquoi ?
3. Le contrôle signale « 2 433,00 » inconnu dans le rapport : que fait le workflow ?

---
**Réponses** — 1. Une ligne perdue ou un chiffre recomposé (halluciné) : demandez le code et recalculez. 2. La jointure multiplie les lignes (deux objectifs par commercial) ; le total de contrôle le révèle. 3. Faute de recopie de 2 443,00 € : `controle_ok` est faux, le rapport part au responsable avec un avertissement, pas à la direction.
