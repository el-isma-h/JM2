---
id: L055
module: M13
level: N2
title: "Analyser un fichier CSV / Excel avec ChatGPT et Claude"
minutes: 60
objectives:
  - "Préparer un fichier tabulaire (CSV / Excel) avant de le confier à un assistant IA : structure, en-têtes, données sensibles"
  - "Rédiger un prompt d'analyse précis (objectif, colonnes, unités, format de sortie, demande de code) avec ChatGPT ou Claude"
  - "Vérifier systématiquement les chiffres produits par l'IA (recalcul, cohérence, code exécuté) et repérer un chiffre halluciné ou un arrondi trompeur"
  - "Expliquer la différence entre une réponse « de tête » du modèle et un calcul réellement exécuté dans un bac à sable"
skills: ["C2.4"]
sources:
  - { title: "Claude Platform — Files API", url: "https://platform.claude.com/docs/en/build-with-claude/files", lang: "en" }
  - { title: "Claude Platform — Code execution tool", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool", lang: "en" }
  - { title: "Claude Platform — Agent Skills overview (skills xlsx, docx, pptx, pdf)", url: "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview", lang: "en" }
  - { title: "Claude Platform — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "OpenAI — API Quickstart (fichiers, code interpreter)", url: "https://developers.openai.com/api/docs/quickstart", lang: "en" }
  - { title: "Claude Academy — Claude 101", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
---

# Analyser un fichier CSV / Excel avec ChatGPT et Claude

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 13

## 🎯 Ce que vous saurez faire
- Préparer un export de ventes (CSV ou Excel) — CSV : tableau enregistré en simple texte, une ligne par enregistrement, valeurs séparées par des virgules — pour qu'un assistant IA le lise sans se tromper.
- Formuler une demande d'analyse qui précise l'objectif, les colonnes, les unités et le format attendu.
- Distinguer une réponse « calculée de tête » par le modèle d'un calcul réellement exécuté en Python dans un bac à sable (*sandbox*).
- Détecter un chiffre inventé, un arrondi trompeur ou une ligne oubliée (avoir, doublon) avec une procédure de vérification en quatre points.
- Réutiliser le jeu de données **Mobidesk** qui servira de fil rouge dans tout le module.

> 🧭 **En clair** — Confier un tableau de ventes à ChatGPT ou Claude, c'est comme confier vos tickets de caisse à un comptable très rapide mais parfois distrait. Si vous lui donnez des tickets bien rangés, avec des étiquettes claires (« montant HT en euros », « une quantité négative = un retour »), il se trompe beaucoup moins. Et surtout, vous lui demandez de faire le calcul avec une vraie calculatrice (un petit programme qu'il exécute) plutôt que « de tête ». Enfin, vous gardez toujours un chiffre que vous connaissez déjà, comme le total du mois, pour vérifier qu'il ne s'est pas trompé.

## 1. Le jeu de données du module : les ventes de Mobidesk

Mobidesk SAS est une PME fictive de Nantes qui distribue du mobilier et des fournitures de bureau aux professionnels. Trois commerciaux couvrent trois régions. Le contrôleur de gestion exporte chaque semestre les lignes de commande depuis l'outil de facturation. Voici l'export du premier semestre 2026, **24 lignes**, que vous copierez dans un fichier texte nommé `ventes_mobidesk_2026_S1.csv` (encodage UTF-8, séparateur virgule, point décimal) — UTF-8 est la norme qui garantit que les accents s'affichent correctement ; le séparateur est le caractère qui sépare les colonnes — :

```csv
date,commande,commercial,region,categorie,produit,quantite,prix_unitaire_ht,montant_ht
2026-01-06,C-1001,Aïcha Benali,Île-de-France,Mobilier,Bureau Oslo,4,349.00,1396.00
2026-01-13,C-1002,Thomas Roussel,Auvergne-Rhône-Alpes,Éclairage,Lampe Halo,12,59.90,718.80
2026-01-20,C-1003,Léa Martin,Nouvelle-Aquitaine,Mobilier,Fauteuil Ergo+,3,289.00,867.00
2026-01-27,C-1004,Aïcha Benali,Île-de-France,Consommables,Pack papeterie,25,18.50,462.50
2026-02-03,C-1005,Thomas Roussel,Auvergne-Rhône-Alpes,Mobilier,Bureau Oslo,2,349.00,698.00
2026-02-10,C-1006,Léa Martin,Nouvelle-Aquitaine,Rangement,Caisson Nova,6,129.00,774.00
2026-02-17,C-1007,Aïcha Benali,Île-de-France,Mobilier,Fauteuil Ergo+,8,289.00,2312.00
2026-02-24,C-1008,Thomas Roussel,Auvergne-Rhône-Alpes,Consommables,Pack papeterie,40,18.50,740.00
2026-03-03,C-1009,Léa Martin,Nouvelle-Aquitaine,Éclairage,Lampe Halo,20,59.90,1198.00
2026-03-10,C-1010,Aïcha Benali,Île-de-France,Rangement,Caisson Nova,10,129.00,1290.00
2026-03-17,C-1011,Thomas Roussel,Auvergne-Rhône-Alpes,Mobilier,Fauteuil Ergo+,5,289.00,1445.00
2026-03-24,C-1012,Léa Martin,Nouvelle-Aquitaine,Mobilier,Bureau Oslo,6,349.00,2094.00
2026-04-07,C-1013,Aïcha Benali,Île-de-France,Éclairage,Lampe Halo,30,59.90,1797.00
2026-04-14,C-1014,Thomas Roussel,Auvergne-Rhône-Alpes,Rangement,Caisson Nova,4,129.00,516.00
2026-04-21,C-1015,Léa Martin,Nouvelle-Aquitaine,Consommables,Pack papeterie,60,18.50,1110.00
2026-04-28,C-1016,Aïcha Benali,Île-de-France,Mobilier,Bureau Oslo,-1,349.00,-349.00
2026-05-05,C-1017,Thomas Roussel,Auvergne-Rhône-Alpes,Mobilier,Fauteuil Ergo+,10,289.00,2890.00
2026-05-12,C-1018,Léa Martin,Nouvelle-Aquitaine,Rangement,Caisson Nova,8,129.00,1032.00
2026-05-19,C-1019,Aïcha Benali,Île-de-France,Mobilier,Fauteuil Ergo+,12,289.00,3468.00
2026-05-26,C-1020,Thomas Roussel,Auvergne-Rhône-Alpes,Éclairage,Lampe Halo,15,59.90,898.50
2026-06-02,C-1021,Léa Martin,Nouvelle-Aquitaine,Mobilier,Bureau Oslo,9,349.00,3141.00
2026-06-09,C-1022,Aïcha Benali,Île-de-France,Consommables,Pack papeterie,80,18.50,1480.00
2026-06-16,C-1023,Thomas Roussel,Auvergne-Rhône-Alpes,Mobilier,Bureau Oslo,7,349.00,2443.00
2026-06-23,C-1024,Léa Martin,Nouvelle-Aquitaine,Éclairage,Lampe Halo,18,59.90,1078.20
```

Regardez la ligne `C-1016` : une quantité de **−1** et un montant de **−349,00 €**. C'est un avoir (un bureau retourné par le client). Ce détail, parfaitement banal dans la vraie vie, est le premier piège que nous tendrons aux assistants IA : un modèle pressé l'ignore, le « corrige » ou le compte en positif.

> 🧭 **Pas à pas pour débutant** — Créer le fichier CSV : (1) sélectionnez tout le bloc de données ci-dessus, de `date,commande…` jusqu'à la dernière ligne, et copiez-le ; (2) ouvrez **Bloc-notes** (Windows) ou **TextEdit** (Mac, menu *Format → Convertir au format texte*) et collez ; (3) *Fichier → Enregistrer sous* : nom `ventes_mobidesk_2026_S1.csv`, **Type : Tous les fichiers** (Windows) et **Encodage : UTF-8** (liste déroulante en bas de la fenêtre). Vérification : en double-cliquant sur le fichier, il doit avoir l'icône d'Excel ou de votre tableur, et non celle d'un document texte. Si les accents apparaissent sous la forme « Ã© », l'encodage n'était pas UTF-8 : recommencez l'enregistrement.

Les **valeurs de référence** que vous devez retrouver tout au long du module (calculées à la main, vous les revérifierez vous-même dans l'exercice) :

| Indicateur | Valeur exacte |
|---|---|
| Chiffre d'affaires HT total (24 lignes, avoir compris) | **33 500,00 €** |
| CA par commercial | Aïcha Benali 11 856,50 € · Léa Martin 11 294,20 € · Thomas Roussel 10 349,30 € |
| CA par catégorie | Mobilier 20 405,00 € · Éclairage 5 690,50 € · Consommables 3 792,50 € · Rangement 3 612,00 € |
| Meilleur mois / moins bon mois | Mai 8 288,50 € / Avril 3 074,00 € |
| Panier moyen (24 lignes) / (23 lignes hors avoir) | 1 395,83 € / 1 471,70 € |
| T1 → T2 | 13 995,30 € → 19 504,70 €, soit **+39,4 %** |

> 💡 **À retenir** — Un jeu de données que vous connaissez par cœur est le meilleur détecteur d'hallucination qui existe. Avant de confier un vrai fichier de 40 000 lignes à un assistant, entraînez-le (et entraînez-vous) sur un petit fichier dont vous connaissez les réponses.

```quiz
{
  "type": "vrai_faux",
  "q": "Dans le fichier Mobidesk, la ligne C-1016 (quantité −1, montant −349 €) est une erreur de saisie qu'il faut supprimer avant l'analyse.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "C'est un avoir : un bureau retourné par le client. Il fait partie du chiffre d'affaires réel (33 500,00 € avoir compris). Le supprimer ou le compter en positif fausse le total."
}
```

## 2. Avant d'envoyer le fichier : la check-list de préparation

Un assistant IA lit un tableau comme vous liriez un tableau photocopié de travers : il devine. Plus vous enlevez de devinettes, plus les résultats sont fiables.

| Point à vérifier | Pourquoi | Que faire |
|---|---|---|
| **Une seule ligne d'en-têtes**, sans cellules fusionnées ni titre au-dessus | Le modèle (ou le code qu'il génère) prend la première ligne comme noms de colonnes | Dans Excel : supprimez les lignes de titre, « Convertir en tableau » (Ctrl + L) |
| **Noms de colonnes explicites** (`prix_unitaire_ht`, pas `PU`) | Le modèle devine l'unité et la nature des données à partir du nom | Renommez ; précisez HT/TTC, devise, unité |
| **Format des nombres** : point décimal, pas d'espace de milliers ni de symbole « € » dans les cellules | `1 396,00 €` est une chaîne de caractères, pas un nombre (du texte que l'ordinateur ne sait pas additionner) | Export CSV « international » ou nettoyage avant envoi |
| **Dates ISO** `AAAA-MM-JJ` | `06/01/2026` : 6 janvier ou 1er juin ? Les modèles anglophones penchent pour juin | Formatez les dates en ISO 8601 (la norme internationale année-mois-jour) |
| **Données personnelles** et secrets d'affaires | Un export clients contient souvent noms, e-mails, adresses, marges | Pseudonymisez (client 001, 002…) — remplacez les noms par des codes —, supprimez les colonnes inutiles, vérifiez la politique d'usage de votre entreprise (module 7) |
| **Taille** | Au-delà de quelques milliers de lignes, le modèle ne doit plus « lire » mais **calculer** | Utilisez un outil qui exécute du code (section 3) |

Sur le dernier point, la CNIL rappelle dans ses fiches pratiques IA le principe de minimisation : on ne transmet que les données nécessaires à la finalité. Pour une analyse de ventes, le nom du commercial est utile ; l'IBAN du client ne l'est jamais.

> ⚠️ **Piège fréquent** — Le fichier Excel contient trois onglets, dont un onglet « Brouillon » avec des chiffres de l'an dernier. L'assistant analyse le premier onglet trouvé, ou pire, mélange les deux. Envoyez un fichier à un seul onglet, ou nommez explicitement l'onglet dans votre prompt.

## 3. Deux façons de « lire » un tableau : de tête ou en exécutant du code

C'est la notion la plus importante de la leçon. Quand vous collez 24 lignes dans une conversation et demandez « quel est le total ? », deux choses peuvent se passer :

1. **Le modèle répond « de tête »** : il additionne les montants comme vous le feriez mentalement, token après token. Sur 24 lignes, les modèles récents (Claude Sonnet 5.5, GPT-6.1 Sol, nov. 2026) s'en sortent très souvent, mais il n'y a **aucune garantie** : une retenue oubliée, un signe négatif sauté, et le total est faux de 698 € sans que rien ne le signale.
2. **Le modèle écrit et exécute un programme** (Python en général) dans un bac à sable, puis vous rapporte le résultat du programme. Le calcul est alors exact ; ce qui peut encore être faux, c'est la logique du programme (par exemple exclure l'avoir sans vous le dire).

Dans ChatGPT, cette seconde voie est la fonction d'analyse de données historiquement appelée *Advanced Data Analysis* ou *Code Interpreter* ; côté API, OpenAI expose l'outil `code_interpreter` dans la Responses API (l'interface pour développeurs), facturé à la session (0,03 $ à 1,92 $ selon la mémoire allouée, nov. 2026). Dans Claude, l'application claude.ai analyse un fichier joint et produit des artefacts (des documents, tableaux ou graphiques affichés à côté de la conversation) (tableaux, graphiques) ; la plateforme propose aux développeurs la **Files API** (fichiers jusqu'à 500 Mo, nov. 2026) et l'outil **code execution** (1 550 heures gratuites par mois puis 0,05 $/h, nov. 2026) ; des *skills* pré-construits `xlsx`, `docx`, `pptx`, `pdf` lui servent de modes d'emploi pour créer un classeur Excel avec formules ; sur le bureau, **Claude Cowork** travaille directement dans vos dossiers. Gemini propose aussi l'exécution de code et s'intègre dans Google Sheets.

> 💡 **Autrement dit** — Chaque grand assistant possède une « calculatrice intégrée » : il écrit un petit programme, le fait tourner dans une pièce isolée (le bac à sable, une zone fermée où le code ne peut rien abîmer) et vous rend le résultat. Chez ChatGPT, on l'appelle analyse de données ou *Code Interpreter* ; chez Claude, c'est l'exécution de code, avec des fichiers joints et des modes d'emploi tout prêts (les *skills*) pour fabriquer un vrai fichier Excel. Peu importe le nom : ce qui compte, c'est de vérifier que la calculatrice a bien été utilisée.

Comment savoir quelle voie a été prise ? **Demandez-le** : « Montre-moi le code que tu as exécuté ». Un script et sa sortie, vous êtes dans le cas 2 ; une explication sans code, vous êtes dans le cas 1 et vous recalculez.

```
   Vous ──► "Total du CA ?" ──► Modèle
                                   │
              ┌────────────────────┴───────────────────┐
              ▼                                        ▼
     Réponse « de tête »                     Écrit un script Python
     (addition mentale, token par token)     ──► bac à sable l'exécute
     Risque : erreur silencieuse             ──► résultat retourné
     À faire : recalculer                    Risque : logique fausse
                                             À faire : lire le code
```

> 🔗 **Documentation officielle** — [Claude Platform — Code execution tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool) 🇬🇧 et [Files API](https://platform.claude.com/docs/en/build-with-claude/files) 🇬🇧 ; [OpenAI — Quickstart](https://developers.openai.com/api/docs/quickstart) 🇬🇧 (section « extend with files and tools »).

```quiz
{
  "q": "Vous demandez le CA total à l'assistant. Il répond « 33 500 € » avec une jolie phrase, mais sans aucun code. Que faites-vous ?",
  "options": [
    "Vous l'utilisez tel quel : sur 24 lignes, les modèles récents ne se trompent jamais",
    "Vous recalculez ou exigez le code exécuté",
    "Vous reposez la même question jusqu'à obtenir deux fois exactement le même chiffre",
    "Vous demandez au modèle s'il est vraiment sûr de lui, puis vous le croyez"
  ],
  "answer": 1,
  "explanation": "Sans code affiché, rien ne prouve qu'un calcul a été exécuté. Le modèle a peut-être additionné « de tête » : souvent juste, jamais garanti. Demandez le script ou recalculez dans le tableur."
}
```

```mission
{
  "title": "Quelle taille de fichier la Files API de Claude accepte-t-elle ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/files",
  "steps": ["Ouvrez la page Files API de la documentation Claude Platform", "Cherchez la section des limites (file storage / limits)", "Relevez la taille maximale d'un fichier et le stockage total par organisation"],
  "question": "Quelle est la taille maximale d'un fichier envoyé via la Files API, et quel est le plafond de stockage par organisation ?",
  "hint": "Les deux chiffres s'expriment l'un en mégaoctets, l'autre en téraoctets.",
  "answer": "500 Mo par fichier et 1 To par organisation (nov. 2026) — vérifiez : les limites évoluent (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 4. Le prompt d'analyse en cinq blocs

Un bon prompt d'analyse ressemble à une demande que vous feriez à un stagiaire en contrôle de gestion : contexte, données, question, format, garde-fous. Le guide *Prompting best practices* d'Anthropic insiste sur le même point : soyez explicite sur le résultat attendu et sur ce que le modèle doit faire en cas de doute.

```text
RÔLE : Tu es contrôleur de gestion dans une PME de distribution de mobilier de bureau.

DONNÉES : le fichier joint ventes_mobidesk_2026_S1.csv contient les lignes de commande
du 1er semestre 2026. Colonnes : date (ISO), commande, commercial, region, categorie,
produit, quantite (peut être négative = avoir), prix_unitaire_ht (€), montant_ht (€ HT).

TÂCHE : 1) CA HT total ; 2) CA par commercial et par mois (tableau croisé) ;
3) les trois constats les plus utiles pour la réunion commerciale de rentrée.

MÉTHODE : exécute du code pour tous les calculs et affiche-le. Ne modifie, n'exclus
et ne corrige aucune ligne sans me le signaler explicitement. Garde les avoirs.

FORMAT : montants en euros avec deux décimales et séparateur de milliers (ex. 11 856,50 €),
pourcentages à une décimale. Termine par la liste des hypothèses que tu as faites.
```

Décortiquons ce qui protège contre les erreurs :
- **« quantite peut être négative = avoir »** : vous retirez au modèle la tentation de « nettoyer » la ligne C-1016.
- **« exécute du code et affiche-le »** : vous forcez la voie 2 et vous obtenez la preuve.
- **« ne modifie aucune ligne sans me le signaler »** : la plupart des erreurs d'analyse IA ne sont pas des erreurs de calcul mais des décisions silencieuses (supprimer les doublons, remplacer les vides par zéro, convertir une date à l'envers).
- **« deux décimales »** : vous évitez les arrondis en cascade (section 5).
- **« liste des hypothèses »** : c'est là que vous découvrirez que le modèle a pris `region` pour la région du client alors que c'est celle du commercial.

🎮 **Défi** — Envoyez le même fichier avec le prompt minimal « Analyse ce fichier » puis avec le prompt en cinq blocs. Comparez : combien de chiffres identiques ? L'avoir a-t-il été traité de la même façon ?

```mission
{
  "title": "Combien coûte l'outil d'exécution de code de Claude ?",
  "url": "https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool",
  "steps": ["Ouvrez la page Code execution tool", "Repérez la section consacrée à l'usage et à la tarification (usage and pricing)", "Notez le nombre d'heures gratuites et le prix au-delà"],
  "question": "Combien d'heures d'exécution de code sont offertes chaque mois, et combien coûte l'heure supplémentaire ?",
  "hint": "Le quota gratuit dépasse le millier d'heures ; le prix horaire se compte en centimes de dollar.",
  "answer": "1 550 heures gratuites par mois, puis 0,05 $ de l'heure (nov. 2026) — vérifiez : les prix évoluent (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 5. Les trois pièges des chiffres : arrondi, hallucination, oubli

**L'arrondi qui dérive.** Demandez le CA de la Lampe Halo. Le prix est 59,90 €, 95 unités vendues : 5 690,50 €. Un modèle qui arrondit le prix à 60 € « pour simplifier » annonce 5 700 €, puis calcule une part de marché sur ce chiffre arrondi, puis une croissance sur cette part : l'erreur se propage. Règle : les arrondis se font **à la fin**, à l'affichage, jamais dans les étapes intermédiaires. Imposez-le dans le prompt.

**Le chiffre halluciné.** Il a trois visages. (1) *Le chiffre plausible* : « Le panier moyen est de 1 450 € » — c'est entre les deux vraies valeurs (1 395,83 € et 1 471,70 €), donc crédible, donc dangereux. (2) *Le chiffre sans source* : « Le secteur progresse de 4 % par an » — ce n'est pas dans votre fichier, c'est une connaissance générale du modèle, possiblement datée. (3) *Le chiffre recomposé* : le modèle vous donne le CA par commercial, puis un total qui n'est pas la somme des trois lignes qu'il vient d'écrire. Ce dernier cas est le plus facile à attraper : additionnez.

**L'oubli silencieux.** Dans une conversation longue, le modèle peut oublier une colonne ou n'analyser que les lignes qui « tiennent » dans sa mémoire de travail (sa fenêtre de contexte, la quantité de texte qu'il garde sous les yeux). Sur 24 lignes, aucun risque ; sur 3 000 lignes collées dans le chat, c'est fréquent. D'où la règle : au-delà d'une centaine de lignes, on **joint le fichier** et on exige du **code**.

> 💡 **À retenir** — Trois réflexes : *additionner* les sous-totaux pour vérifier le total ; *demander la provenance* de tout chiffre externe ; *imposer deux décimales* et des arrondis en fin de calcul.

## 6. La procédure de vérification en quatre points

Avant d'utiliser un chiffre produit par l'IA dans un e-mail, un tableau de bord ou une décision :

1. **Le total de contrôle.** Vous connaissez au moins un chiffre indépendant (total de la facturation, nombre de lignes, nombre de commerciaux). Il doit coïncider exactement. Pour Mobidesk : 24 lignes, 33 500,00 €, 3 commerciaux, 5 produits.
2. **La somme des parties.** CA par commercial : 11 856,50 + 11 294,20 + 10 349,30 = 33 500,00. Si la somme des sous-totaux n'est pas le total, l'une des lignes a été perdue ou comptée deux fois.
3. **Le cas extrême.** Repérez la ligne la plus bizarre (l'avoir, la plus grosse commande, un vide) et demandez : « Comment as-tu traité la commande C-1016 ? » La réponse vous dit si le modèle a lu le fichier ou l'a imaginé.
4. **La contre-épreuve dans le tableur.** Un `=SOMME.SI.ENS(I:I;C:C;"Léa Martin")` dans Excel ou Google Sheets prend dix secondes et vous donne 11 294,20 €. L'IA accélère ; le tableur arbitre.

> 🧭 **Pas à pas pour débutant** — Ouvrir ce CSV dans un **Excel français** sans casse : n'ouvrez pas le fichier par double-clic (Excel mettrait souvent tout dans la colonne A, ou transformerait `349.00` en texte). Ouvrez un classeur vide → onglet **Données** → **À partir d'un fichier texte/CSV** → choisissez le fichier ; dans l'aperçu, vérifiez *Origine du fichier : 65001 : Unicode (UTF-8)* et *Délimiteur : Virgule*, puis cliquez sur **Transformer les données** si les montants apparaissent alignés à gauche (texte) : sélectionnez les colonnes de nombres, *Type de données → Utilisation des paramètres régionaux… → Décimal, Anglais (États-Unis)*. Sinon, cliquez sur **Charger**. Les colonnes doivent alors aller de A (`date`) à I (`montant_ht`), et `=SOMME(I:I)` doit afficher 33 500. **Plus simple** : Google Sheets (*Fichier → Importer*, séparateur détecté automatiquement) lit correctement ce fichier dans la plupart des cas.

Ce que cette procédure ne détecte pas : une erreur d'interprétation (confondre région du client et région du commercial). Contre celle-ci, un seul remède : la **liste des hypothèses** demandée dans le prompt, que vous relisez ligne par ligne.

```quiz
{
  "q": "Mise en situation : l'assistant vous donne le CA par commercial (11 856,50 € + 11 294,20 € + 10 349,30 €) et annonce un total de 34 198,00 €. Quel point de la procédure vient de vous alerter, et quelle est la cause la plus probable ?",
  "options": [
    "Le cas extrême : la plus grosse commande, C-1019, a sans doute été comptée deux fois",
    "La contre-épreuve tableur : Excel et Python n'arrondissent pas de la même façon",
    "La somme des parties : l'avoir a été compté en positif",
    "Aucun : un écart d'environ 2 % est normal et acceptable avec une IA"
  ],
  "answer": 2,
  "explanation": "Les trois sous-totaux donnent 33 500,00 € : le total annoncé est donc recomposé. L'écart de 698 € vaut exactement 2 × 349 € : l'avoir C-1016 a été compté en +349 au lieu de −349."
}
```

## 7. Et avec un vrai fichier Excel de 40 000 lignes ?

Le principe ne change pas, mais la méthode s'adapte :
- **Joignez le fichier**, ne collez jamais le contenu. Dans claude.ai ou ChatGPT, le trombone ; dans Claude Cowork, donnez accès au dossier ; côté API, la Files API ou l'upload direct.
- **Demandez d'abord un profil** : « Décris le fichier : nombre de lignes, colonnes, types, valeurs manquantes, doublons sur `commande`, dates min et max. » Vous corrigez les problèmes de données avant de poser des questions.
- **Posez une question à la fois** et faites afficher le code à chaque fois. Un script de cinq lignes `pandas` (pandas est la bibliothèque Python de référence pour manipuler des tableaux) se relit en trente secondes même sans savoir programmer : repérez `dropna` (supprime les vides), `drop_duplicates` (supprime les doublons), `abs(` (rend positif), `[df.quantite > 0]` (exclut les avoirs).
- **Demandez un classeur en sortie** : avec le skill `xlsx`, Claude renvoie un fichier Excel contenant les **formules** et non des valeurs figées, ce qui permet à votre expert-comptable de tracer chaque chiffre.

> 💡 **Autrement dit** — Lire le code, c'est comme relire une recette sans être cuisinier : vous ne vérifiez pas chaque geste, vous cherchez les **mots qui changent le plat**. Dans la réponse de l'assistant, cliquez sur « Afficher le code », « Analyse » ou l'icône `</>` : un bloc de texte apparaît. Cherchez-y (Ctrl+F) `dropna`, `drop_duplicates`, `abs(`, `> 0` : chacun signale une ligne retirée ou modifiée. Si vous en trouvez un que vous n'avez pas demandé, posez la question : « Pourquoi as-tu utilisé dropna, et combien de lignes cela a-t-il retiré ? »

> ⚠️ **Piège fréquent** — Vous demandez « supprime les lignes bizarres » : le modèle supprime l'avoir, le gros client exceptionnel et la ligne dont la date est en 2025. Votre CA monte de 2 %, votre réunion commerciale repose sur un chiffre faux. Décrivez les règles de nettoyage vous-même, une par une.

## 🧪 Exercice pratique

**Consigne.** Créez le fichier `ventes_mobidesk_2026_S1.csv` à partir du bloc de la section 1. Puis, dans l'assistant de votre choix (Claude ou ChatGPT, en version gratuite ou payante) :

1. Envoyez le fichier avec le prompt en cinq blocs de la section 4 (adaptez-le à votre outil).
2. Relevez les six indicateurs du tableau de référence (section 1) tels que l'assistant les donne.
3. Posez la question piège : « Comment as-tu traité la commande C-1016 ? »
4. Dans Excel ou Google Sheets, recalculez le CA par commercial avec `SOMME.SI.ENS` et le total avec `SOMME`.
5. Rédigez cinq lignes : ce qui était juste, ce qui était faux ou arrondi, les hypothèses signalées par l'assistant.

**Critères de réussite.**
- Les six indicateurs coïncident au centime avec le tableau de référence (ou vous avez identifié et expliqué chaque écart).
- Vous avez obtenu et lu le code exécuté (ou constaté que l'outil n'en exécute pas, et conclu en conséquence).
- L'avoir C-1016 est explicitement mentionné dans la réponse de l'assistant.
- Votre contre-épreuve tableur est jointe (capture ou formules).

**Pistes de corrigé.** Le total doit être 33 500,00 € ; si vous obtenez 34 198,00 €, l'avoir a été compté en positif (33 500 + 2 × 349) ; si vous obtenez 33 849,00 €, il a été exclu. Un panier moyen de 1 395,83 € signifie 24 lignes incluses ; 1 471,70 € signifie que l'avoir a été écarté : les deux sont défendables, à condition que l'hypothèse soit annoncée. La croissance T1 → T2 doit être +39,4 % (19 504,70 / 13 995,30 − 1). Le meilleur commercial est Aïcha Benali malgré l'avoir qui lui est imputé.

## ✅ Auto-évaluation express

1. Vous collez 300 lignes de ventes dans le chat et demandez le total. Quel est le risque principal et comment le réduire ?
2. L'assistant annonce un CA par produit dont la somme fait 33 210 € alors que le total affiché est 33 500 €. Que s'est-il probablement passé ?
3. Pourquoi faut-il écrire « quantite peut être négative (avoir) » dans le prompt plutôt que de laisser le modèle le découvrir ?

**Réponses.** 1) Le modèle peut calculer « de tête » et se tromper silencieusement, ou n'analyser qu'une partie des lignes ; joignez le fichier et exigez du code exécuté et affiché. 2) Une ligne a été perdue ou exclue (ici 290 €, qui ne correspond à aucune ligne : il s'agit probablement d'un chiffre recomposé, donc halluciné) ; demandez le code et recalculez. 3) Parce que la plupart des erreurs sont des décisions silencieuses de nettoyage ; en décrivant la règle, vous interdisez au modèle de « corriger » la donnée.

## 📚 Pour aller plus loin
- [Claude Platform — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 — la page de référence pour structurer une demande et gérer l'incertitude.
- [Claude Platform — Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 — comment fonctionnent les skills `xlsx`, `docx`, `pptx`, `pdf`.
- [Claude Academy — Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 — leçon « Creating with artifacts » et usage des fichiers dans claude.ai.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — minimisation et données personnelles.
- [OpenAI Academy — catalogue](https://academy.openai.com/pages/courses) 🇬🇧 — parcours « Apply AI at Work », tâches tableur et données.

> ✅ **Si vous ne retenez que 3 choses** — 1. Préparez le fichier : une seule ligne d'en-têtes, noms de colonnes clairs (HT/TTC, unités), nombres sans « € », dates AAAA-MM-JJ, et aucune donnée personnelle inutile. 2. Exigez que l'assistant **calcule avec du code** et vous le montre, et qu'il ne supprime ou ne corrige aucune ligne sans le dire. 3. Vérifiez toujours : un total que vous connaissez, la somme des sous-totaux, la ligne la plus bizarre (l'avoir), et une contre-épreuve dans le tableur.

> 🗺️ **Et maintenant ?** — Vos chiffres sont fiables ; la leçon L056 vous apprend à les transformer en graphiques et en rapports clairs, sans vous faire piéger par un axe trompeur.
