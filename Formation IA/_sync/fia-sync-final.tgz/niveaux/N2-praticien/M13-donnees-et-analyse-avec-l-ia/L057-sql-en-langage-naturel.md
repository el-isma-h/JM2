---
id: L057
module: M13
level: N2
title: "SQL en langage naturel"
minutes: 60
objectives:
  - "Expliquer ce qu'est une base de données relationnelle, une table, un schéma et une requête SQL de lecture (SELECT, WHERE, GROUP BY, JOIN)"
  - "Faire générer par un assistant IA une requête SQL à partir d'une question en français, en fournissant le schéma et le dialecte"
  - "Vérifier une requête générée : lecture critique, exécution sur un jeu de test connu, totaux de contrôle"
  - "Identifier les risques du SQL généré (requêtes d'écriture, exposition de données, ambiguïtés, dialectes) et appliquer les garde-fous (accès en lecture seule, copie de test)"
skills: ["C2.4"]
sources:
  - { title: "Claude Platform — Structured outputs", url: "https://platform.claude.com/docs/en/build-with-claude/structured-outputs", lang: "en" }
  - { title: "Claude Platform — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "OpenAI — Structured outputs", url: "https://developers.openai.com/api/docs/guides/structured-outputs", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "n8n Docs — Data Tables", url: "https://docs.n8n.io/build/work-with-data/data-tables.md", lang: "en" }
  - { title: "n8n Academy — N8N102 Integrations: APIs & Connected Workflows", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about", lang: "en" }
---

# SQL en langage naturel

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 13

## 🎯 Ce que vous saurez faire
- Comprendre, sans être développeur, ce que fait une requête SQL de lecture et pourquoi c'est le langage des données d'entreprise.
- Décrire une base à un assistant IA (schéma, dialecte, règles métier) pour qu'il écrive des requêtes justes.
- Lire une requête générée en repérant les cinq endroits où elle peut mentir.
- Tester toute requête sur une copie dont vous connaissez les réponses (le jeu Mobidesk) avant de l'approcher de la vraie base.
- Mettre en place les deux garde-fous qui évitent la catastrophe : compte en lecture seule et base de test.

> 🧭 **En clair** — Une base de données, c'est un immense meuble à tiroirs bien étiquetés ; le SQL est la petite fiche de demande qu'on remet à l'archiviste (« sortez-moi toutes les ventes de mai, rangées par commercial »). Aujourd'hui, l'IA sait rédiger cette fiche à partir d'une phrase en français, à condition que vous lui montriez le plan du meuble (le **schéma**). Votre rôle : relire la fiche avant de la remettre, l'essayer d'abord sur un petit meuble dont vous connaissez le contenu, et ne donner à l'IA qu'une clé « lecture seule », qui permet de regarder dans les tiroirs mais jamais d'en jeter le contenu.

## 1. Pourquoi le SQL concerne aussi les non-développeurs

Votre logiciel de facturation, votre CRM, votre outil de paie, votre boutique en ligne : derrière chacun, une **base de données relationnelle** range les informations dans des **tables** (des feuilles de calcul très disciplinées) reliées entre elles par des identifiants. Le langage pour les interroger s'appelle **SQL** (*Structured Query Language*), normalisé depuis 1986 et toujours dominant quarante ans plus tard. Quand vous exportez un CSV « depuis le logiciel », quelqu'un, quelque part, a écrit une requête SQL.

Jusqu'ici, poser une question nouvelle à la base signifiait attendre le développeur ou le prestataire. Les modèles de langage changent cela : ils traduisent très bien une question en français en requête SQL (*text-to-SQL*) — « du texte vers le SQL » —, **à condition** de connaître la structure de la base. Ce qui ne change pas : la responsabilité de vérifier que la requête répond bien à la question posée. Une requête fausse qui renvoie un beau tableau est plus dangereuse qu'une erreur de syntaxe. (Une erreur de syntaxe est une faute de « grammaire » SQL : la base refuse la requête et affiche un message, donc on la voit tout de suite.)

Analogie : SQL est la langue du serveur d'archives. L'IA est l'interprète. Si vous demandez « les ventes du printemps » sans dire si le printemps commence le 20 ou le 21 mars, l'interprète choisira pour vous, sans vous le dire.

## 2. Le jeu Mobidesk en base de données

Nous reprenons les 24 lignes de la leçon 55 et nous ajoutons une seconde table, `objectifs`, pour apprendre la jointure. **SQLite** est parfait pour s'entraîner : gratuit, sans serveur, intégré à Python, et des outils graphiques existent (DB Browser for SQLite, extension VS Code). Le script ci-dessous crée la base `mobidesk.db` à partir du CSV :

```python
"""Crée mobidesk.db (SQLite) à partir de ventes_mobidesk_2026_S1.csv.
Usage : python creer_base.py
"""
import csv
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS ventes (
    date              TEXT    NOT NULL,   -- ISO AAAA-MM-JJ
    commande          TEXT    PRIMARY KEY,
    commercial        TEXT    NOT NULL,
    region            TEXT    NOT NULL,   -- région du COMMERCIAL, pas du client
    categorie         TEXT    NOT NULL,
    produit           TEXT    NOT NULL,
    quantite          INTEGER NOT NULL,   -- négatif = avoir
    prix_unitaire_ht  REAL    NOT NULL,   -- € HT
    montant_ht        REAL    NOT NULL    -- € HT = quantite × prix_unitaire_ht
);
CREATE TABLE IF NOT EXISTS objectifs (
    commercial   TEXT PRIMARY KEY,
    objectif_s1  REAL NOT NULL           -- objectif de CA HT du semestre, en €
);
"""

OBJECTIFS = [("Aïcha Benali", 11000.0), ("Léa Martin", 12000.0), ("Thomas Roussel", 10000.0)]

with sqlite3.connect("mobidesk.db") as con:
    con.executescript(SCHEMA)
    with open("ventes_mobidesk_2026_S1.csv", encoding="utf-8", newline="") as f:
        lignes = list(csv.DictReader(f))
    con.executemany(
        "INSERT OR REPLACE INTO ventes VALUES (:date, :commande, :commercial, :region, "
        ":categorie, :produit, :quantite, :prix_unitaire_ht, :montant_ht)", lignes)
    con.executemany("INSERT OR REPLACE INTO objectifs VALUES (?, ?)", OBJECTIFS)
    nb, total = con.execute("SELECT COUNT(*), ROUND(SUM(montant_ht), 2) FROM ventes").fetchone()
    print(f"{nb} lignes chargées · CA total {total} €")   # attendu : 24 lignes · 33500.0 €
```

Le **schéma** (la description des tables, colonnes, types et commentaires) est la pièce maîtresse : c'est lui que vous donnerez à l'assistant. Notez les commentaires `-- région du COMMERCIAL` et `-- négatif = avoir` : ce sont des **règles métier**, et sans elles l'IA devine.

> 🧭 **Pas à pas pour débutant** — Tout faire **sans Python**, avec **DB Browser for SQLite** (gratuit, sur sqlitebrowser.org) : (1) installez-le et ouvrez-le ; *Nouvelle base de données*, enregistrez-la sous `mobidesk.db`, puis fermez la fenêtre de création de table qui s'ouvre (*Annuler*). (2) *Fichier → Importer → Table depuis un fichier CSV*, choisissez `ventes_mobidesk_2026_S1.csv`, cochez *Noms de colonnes en première ligne*, séparateur *Virgule*, nom de table `ventes`, *OK*. (3) Onglet **Exécuter le SQL**, collez puis exécutez (bouton ▶ ou Ctrl+Entrée) : `CREATE TABLE objectifs (commercial TEXT PRIMARY KEY, objectif_s1 REAL NOT NULL); INSERT INTO objectifs VALUES ('Aïcha Benali', 11000), ('Léa Martin', 12000), ('Thomas Roussel', 10000);` puis cliquez sur **Écrire les modifications** (Ctrl+S). (4) Contrôle, dans le même onglet : `SELECT COUNT(*), ROUND(SUM(montant_ht), 2) FROM ventes;` doit afficher 24 et 33500. Si le total est faux, les montants ont été importés comme du texte : dans l'onglet *Structure de la base*, vérifiez les types (*Modifier la table*, type `REAL` pour les colonnes de montants). Note : l'import graphique ne crée pas la clé primaire `commande`, sans incidence pour l'exercice.

Quatre mots de vocabulaire suffisent pour lire 90 % des requêtes :

| Mot-clé | Rôle | Dans une phrase |
|---|---|---|
| `SELECT … FROM` | Quelles colonnes, depuis quelle table | « Donne-moi le commercial et le montant de la table ventes » |
| `WHERE` | Filtre sur les lignes | « … seulement en mai » |
| `GROUP BY` + `SUM`, `COUNT`, `AVG` | Regroupe et agrège | « … total par commercial » |
| `JOIN … ON` | Relie deux tables par une clé | « … avec l'objectif de chacun » |

```quiz
{
  "q": "Dans une requête, quel mot-clé sert à obtenir « le total par commercial » ?",
  "options": [
    "WHERE … AND …",
    "JOIN … ON …",
    "GROUP BY + SUM",
    "ORDER BY … DESC"
  ],
  "answer": 2,
  "explanation": "GROUP BY regroupe les lignes par commercial et SUM additionne les montants de chaque groupe. WHERE filtre des lignes, JOIN relie deux tables, ORDER BY se contente de trier."
}
```

## 3. Le prompt text-to-SQL

```text
Tu écris des requêtes SQL **SQLite** en lecture seule (SELECT uniquement).

SCHÉMA :
[coller le bloc CREATE TABLE ci-dessus, commentaires compris]

RÈGLES MÉTIER : montant_ht inclut les avoirs (quantite négative) ; le CA se calcule
toujours avoirs compris sauf indication contraire ; les mois se calculent sur la
colonne date au format ISO ; les montants sont en euros HT.

QUESTION : quel est le taux d'atteinte de l'objectif semestriel de chaque commercial,
du plus élevé au plus faible, en pourcentage à une décimale ?

RÉPONDS avec : 1) la requête dans un bloc ```sql ; 2) en deux phrases, ce qu'elle
calcule et les hypothèses prises ; 3) les résultats que tu attends si tu les connais.
N'invente pas de colonne qui n'est pas dans le schéma.
```

Réponse attendue (vous la vérifierez dans l'exercice) :

```sql
SELECT v.commercial,
       ROUND(SUM(v.montant_ht), 2)                                AS ca_ht,
       o.objectif_s1,
       ROUND(100.0 * SUM(v.montant_ht) / o.objectif_s1, 1)        AS taux_atteinte_pct
FROM ventes v
JOIN objectifs o ON o.commercial = v.commercial
GROUP BY v.commercial, o.objectif_s1
ORDER BY taux_atteinte_pct DESC;
```

Résultat sur Mobidesk : Aïcha Benali 11 856,50 € / 11 000 € → **107,8 %** ; Thomas Roussel 10 349,30 € / 10 000 € → **103,5 %** ; Léa Martin 11 294,20 € / 12 000 € → **94,1 %**. Le dernier au CA est le deuxième à l'objectif : c'est exactement le genre d'information qu'une jointure révèle et qu'un simple total masque.

Trois détails du prompt font toute la différence : **le dialecte** (SQLite, PostgreSQL, MySQL, SQL Server et BigQuery n'écrivent pas les dates de la même façon : `strftime('%m', date)` en SQLite, `EXTRACT(MONTH FROM date)` en PostgreSQL, `MONTH(date)` en MySQL) ; **« lecture seule »** ; et **« n'invente pas de colonne »** : les modèles adorent ajouter un `client_id` ou un `marge` qui n'existent pas.

> 💡 **Autrement dit** — Le « dialecte », c'est l'accent régional du SQL : la langue de base est la même partout, mais chaque logiciel (SQLite, PostgreSQL, MySQL…) a ses tournures, surtout pour les dates. Si vous ne dites pas à l'IA quel logiciel vous utilisez, elle écrira peut-être avec le mauvais accent, et votre base ne comprendra pas la requête.

> 💡 **À retenir** — Schéma + règles métier + dialecte + question = requête juste neuf fois sur dix. Sans schéma, l'assistant écrit une requête pour une base imaginaire.

## 4. Lire une requête générée : les cinq endroits où elle peut mentir

Même sans savoir écrire SQL, vous pouvez le **relire**. Cherchez ces cinq motifs :

1. **Le `WHERE` de trop.** `WHERE quantite > 0` exclut l'avoir : le CA d'Aïcha Benali passe à 12 205,50 €. Si vous n'avez pas demandé cette exclusion, elle est fautive.
2. **Le `WHERE` manquant.** Vous demandez « le CA de mai » et la requête n'a pas de filtre sur la date : elle renvoie le semestre (33 500 € au lieu de 8 288,50 €).
3. **La division entière.** `SUM(montant_ht) / objectif_s1` est sans risque ici (réels), mais `COUNT(avoirs) / COUNT(*)` donne 0 dans beaucoup de dialectes parce que deux entiers divisés donnent un entier. Cherchez le `100.0` ou le `CAST(… AS REAL)` (`CAST` convertit une valeur dans un autre type, ici en nombre à virgule).
4. **L'agrégat ambigu.** « Le meilleur commercial » : par CA du semestre (Aïcha Benali, 11 856,50 €), par progression T1 → T2 (Thomas Roussel, +87,3 %), par CA mobilier (Thomas Roussel, 7 476,00 €), par nombre de commandes (8 chacun) ? La requête choisit ; votre question aurait dû choisir.
5. **La jointure qui multiplie.** Si la table `objectifs` contenait deux lignes pour un même commercial (objectif T1 et objectif T2), la jointure doublerait le CA. Contrôle : le total de la requête jointe doit rester 33 500,00 €.

🎮 **Défi « trouve l'erreur »** — Cette requête est censée donner le CA par mois. Trouvez les deux problèmes avant de lire la suite.

```sql
SELECT strftime('%m', date) AS mois, SUM(montant_ht) AS ca
FROM ventes
WHERE quantite > 0
GROUP BY mois
ORDER BY ca DESC;
```

Réponse : `WHERE quantite > 0` écarte l'avoir (avril passe de 3 074,00 € à 3 423,00 €) ; `ORDER BY ca DESC` trie par montant et non par mois, ce qui rend le résultat illisible comme chronologie. Deux erreurs silencieuses, zéro erreur de syntaxe.

```quiz
{
  "q": "Mise en situation : vous demandez « le CA de mai » et la requête générée renvoie 33 500,00 €. Lequel des cinq motifs est en cause ?",
  "options": [
    "Le WHERE de trop : un filtre sur la quantité a exclu l'avoir",
    "La division entière, qui arrondit le résultat à zéro",
    "La jointure qui multiplie les lignes de la table objectifs",
    "Le WHERE manquant sur la date"
  ],
  "answer": 3,
  "explanation": "33 500,00 € est le total du semestre : la requête n'a pas filtré sur le mois. Le bon résultat pour mai est 8 288,50 €. Connaître le total de contrôle vous a permis de le voir en une seconde."
}
```

## 5. La procédure de test : toujours sur une copie connue

```
 Question en français
        │
        ▼
 Assistant IA ──► requête SQL ──► 1. relecture (5 motifs)
                                       │
                                       ▼
                               2. exécution sur mobidesk.db (24 lignes, réponses connues)
                                       │ total = 33 500,00 € ? nb lignes = 24 ?
                                       ▼
                               3. exécution sur une COPIE / un compte lecture seule
                                  de la vraie base
                                       │
                                       ▼
                               4. mise en production (vue, rapport, workflow n8n)
```

Le script Python ci-dessous exécute une requête et affiche les totaux de contrôle. Vous pouvez le lancer tel quel ; les développeurs y reconnaîtront le minimum vital, les autres y verront que « tester une requête » prend dix lignes.

> 🧭 **Pas à pas pour débutant** — L'équivalent sans Python dans DB Browser for SQLite : fermez la base, puis rouvrez-la avec **Fichier → Ouvrir une base de données en lecture seule** (Ctrl+Maj+O). Dans l'onglet *Exécuter le SQL*, collez la requête proposée par l'assistant et exécutez-la ; le résultat s'affiche en dessous, et le nombre de lignes renvoyées en bas de l'écran. Toute requête `UPDATE`, `DELETE` ou `INSERT` est alors refusée avec un message d'erreur : c'est le garde-fou de l'étape 4 de l'exercice. Si vous préférez le script Python, enregistrez votre requête dans un fichier texte nommé `requete.sql` (une seule requête, sans le bloc ```sql), dans le même dossier que `mobidesk.db`.

```python
"""Exécute une requête SELECT sur mobidesk.db et affiche les contrôles.
Usage : python tester_requete.py requete.sql
"""
import sqlite3
import sys

with open(sys.argv[1], encoding="utf-8") as f:
    sql = f.read().strip()

if not sql.lower().startswith("select"):
    sys.exit("Refusé : seules les requêtes SELECT sont autorisées ici.")

# Ouverture en LECTURE SEULE : même un DELETE glissé dans le fichier échouerait.
con = sqlite3.connect("file:mobidesk.db?mode=ro", uri=True)
con.row_factory = sqlite3.Row
lignes = con.execute(sql).fetchall()

print(f"{len(lignes)} ligne(s) renvoyée(s)")
if lignes:
    print(" | ".join(lignes[0].keys()))
    for l in lignes:
        print(" | ".join(str(v) for v in l))

# Totaux de contrôle de la base (indépendants de la requête testée)
nb, total = con.execute("SELECT COUNT(*), ROUND(SUM(montant_ht), 2) FROM ventes").fetchone()
print(f"\nContrôle base : {nb} lignes, CA total {total} € (attendu : 24 et 33500.0)")
```

Avec une vraie base (PostgreSQL, MySQL, SQL Server), demandez à votre administrateur un **compte en lecture seule** (`GRANT SELECT` et rien d'autre) — l'instruction SQL qui n'accorde que le droit de lire — et, idéalement, une **copie anonymisée** de la base pour les tests. Un modèle de langage ne lancera pas un `DELETE` tout seul si vous lui demandez un `SELECT`… mais un copier-coller précipité d'une requête `UPDATE` suggérée « pour corriger les avoirs », si. Le compte en lecture seule rend l'accident impossible.

> ⚠️ **Piège fréquent** — Coller dans le chat un extrait de la vraie base « pour que l'IA comprenne mieux ». Vous venez de transmettre des données clients à un service tiers. Le schéma suffit ; les données de test sont fictives (Mobidesk) ou anonymisées. C'est la règle de minimisation vue en leçon 55 et au module 7.

```quiz
{
  "type": "vrai_faux",
  "q": "Avec un compte en lecture seule (ou une ouverture en mode=ro), un UPDATE suggéré par l'assistant et collé par erreur échouera, quoi qu'il arrive.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "C'est tout l'intérêt du garde-fou : la protection est mécanique et ne repose pas sur votre vigilance. Même si vous ne demandez que des SELECT, un UPDATE ou un DELETE proposé « pour corriger » et collé trop vite sera refusé."
}
```

## 6. Où brancher le SQL généré dans la vraie vie

- **Dans le chat** (Claude, ChatGPT, Le Chat, Gemini) : vous obtenez la requête, vous l'exécutez vous-même dans votre outil de base de données. C'est le mode le plus sûr : l'IA ne touche jamais la base.
- **Avec un agent de code** (Claude Code, Codex) connecté à une base de test : l'agent écrit, exécute, corrige. Puissant pour explorer ; réservé à une copie.
- **Dans n8n** (module 8) : un nœud base de données (Postgres, MySQL…) exécute une requête fixe, validée une fois pour toutes, à chaque passage du workflow (on peut aussi l'enregistrer dans la base sous forme de « vue » : une requête sauvegardée qu'on interroge comme une table). Les **Data Tables** de n8n offrent même une petite base intégrée pour stocker des résultats sans serveur. C'est ce que nous ferons en leçon 58.
- **Via une API avec sorties structurées** : pour les développeurs, Claude et OpenAI proposent des sorties JSON contraintes par un schéma (*structured outputs*) ; on demande au modèle de renvoyer `{ "sql": "...", "hypotheses": [...] }` et un programme vérifie que `sql` commence bien par `SELECT` avant toute exécution. Le niveau 3 détaille cette approche.

Dans tous les cas, l'architecture saine est la même : **l'IA propose, un garde-fou mécanique vérifie (lecture seule, préfixe SELECT, limite de lignes), un humain valide la première fois, puis le workflow répète.**

> 🔗 **Documentation officielle** — [Claude Platform — Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧 ; [OpenAI — Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs) 🇬🇧 ; [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 (contraindre les entrées, humain dans la boucle).

```mission
{
  "title": "Comment forcer Claude à répondre en JSON qui respecte un schéma ?",
  "url": "https://platform.claude.com/docs/en/build-with-claude/structured-outputs",
  "steps": ["Ouvrez la page Structured outputs de la documentation Claude Platform", "Repérez le premier exemple de requête avec un schéma JSON", "Notez le nom du paramètre utilisé et la méthode d'aide du SDK Python"],
  "question": "Quel paramètre de requête active les sorties structurées chez Claude, et quelle méthode du SDK renvoie directement un objet validé ?",
  "hint": "Le paramètre est imbriqué dans un objet de configuration de sortie ; la méthode porte le nom du verbe « analyser » en anglais.",
  "answer": "output_config.format avec le type json_schema ; la méthode client.messages.parse() (nov. 2026) — vérifiez : l'API évolue (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Quel outil gratuit OpenAI recommande-t-il pour filtrer les contenus ?",
  "url": "https://developers.openai.com/api/docs/guides/safety-best-practices",
  "steps": ["Ouvrez la page Safety best practices d'OpenAI", "Parcourez la liste des bonnes pratiques", "Repérez l'API citée pour détecter les contenus problématiques, et la pratique qui consiste à faire valider par un humain"],
  "question": "Quelle API OpenAI cite-t-il pour filtrer les contenus, et comment s'appelle la pratique de validation humaine ?",
  "hint": "Le nom de l'API évoque la « modération » ; la pratique se résume par trois lettres : HITL.",
  "answer": "La Moderation API ; et l'« humain dans la boucle » (human in the loop, HITL) (nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.**
1. Créez `mobidesk.db` avec le script de la section 2 (Python 3.12 ; aucune bibliothèque à installer). Vérifiez l'affichage « 24 lignes chargées · CA total 33500.0 € ».
2. Avec l'assistant de votre choix et le prompt de la section 3, faites générer les cinq requêtes suivantes, puis testez-les avec `tester_requete.py` :
   a. CA HT par mois, dans l'ordre chronologique ;
   b. les trois meilleures ventes unitaires (lignes au montant le plus élevé) ;
   c. nombre de commandes et panier moyen par région, avoirs compris ;
   d. taux d'atteinte de l'objectif par commercial (section 3) ;
   e. produits dont la quantité totale vendue dépasse 30 unités.
3. Pour chaque requête, notez : les hypothèses annoncées par l'assistant, les motifs suspects (section 4), et si le résultat correspond aux valeurs de référence.
4. Demandez ensuite à l'assistant « une requête qui corrige l'avoir C-1016 en le mettant à zéro ». Constatez qu'il propose un `UPDATE`, puis vérifiez que `tester_requete.py` et le mode lecture seule le refusent.

**Critères de réussite.**
- Les cinq requêtes s'exécutent et donnent : a) 3 444,30 / 4 524,00 / 6 027,00 / 3 074,00 / 8 288,50 / 8 142,20 € ; b) C-1019 (3 468,00 €), C-1021 (3 141,00 €), C-1017 (2 890,00 €) ; c) 8 commandes par région, paniers moyens 1 482,06 € (Île-de-France), 1 411,78 € (Nouvelle-Aquitaine), 1 293,66 € (Auvergne-Rhône-Alpes) ; d) 107,8 / 103,5 / 94,1 % ; e) Pack papeterie (205), Lampe Halo (95), Fauteuil Ergo+ (38).
- Vous avez repéré au moins un `WHERE` ou un `ORDER BY` discutable et l'avez fait corriger.
- Le `UPDATE` a été refusé par le garde-fou.

**Pistes de corrigé.** Pour (a), la requête juste contient `GROUP BY strftime('%m', date)` et `ORDER BY mois` (pas `ORDER BY ca`). Pour (c), `AVG(montant_ht)` avoirs compris ; si l'assistant propose `AVG(ABS(montant_ht))`, c'est une décision silencieuse à refuser. Pour (e), le `HAVING SUM(quantite) > 30` est la bonne forme : `WHERE quantite > 30` filtrerait les lignes et non les totaux (et ne renverrait que les lignes de 40, 60 et 80 packs de papeterie).

> 💡 **Autrement dit** — `WHERE` trie les **tickets** avant de faire les totaux (« ne garde que les tickets de plus de 30 unités ») ; `HAVING` trie les **totaux** une fois faits (« ne garde que les produits dont le total dépasse 30 »). Exemple : aucune ligne de Lampe Halo ne dépasse 30 unités, mais leur total fait 95 ; avec `WHERE`, la lampe disparaît de la liste, avec `HAVING` elle y figure, comme attendu.

## ✅ Auto-évaluation express

1. Que manque-t-il au prompt « Écris une requête qui donne le CA par commercial » pour obtenir une réponse fiable ?
2. Une requête jointe entre `ventes` et `objectifs` renvoie un CA total de 67 000 €. Que s'est-il passé ?
3. Pourquoi ouvrir la base avec `mode=ro` alors que vous ne demandez que des `SELECT` ?

**Réponses.** 1) Le schéma (tables, colonnes, types), le dialecte SQL, les règles métier (avoirs compris ou non) et le format de réponse attendu. 2) La jointure multiplie les lignes : la table `objectifs` contient probablement deux lignes par commercial ; le total de contrôle (33 500 €) le révèle immédiatement. 3) Parce que la protection doit être mécanique et non reposer sur l'attention humaine : un `UPDATE` ou un `DELETE` suggéré par l'assistant et collé par erreur échouera quoi qu'il arrive.

## 📚 Pour aller plus loin
- [Claude Platform — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 — donner du contexte (schéma, règles) et demander les hypothèses.
- [n8n Docs — Data Tables](https://docs.n8n.io/build/work-with-data/data-tables.md) 🇬🇧 — une petite base intégrée à n8n pour stocker des résultats de requêtes.
- [n8n Academy — N8N102 Integrations](https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about) 🇬🇧 — APIs, credentials et nœuds de données, prérequis de la leçon 58.
- [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — contraindre les entrées et sorties, humain dans la boucle.

> ✅ **Si vous ne retenez que 3 choses** — 1. Pour qu'une IA écrive une requête juste, donnez-lui le **schéma** de la base, le **dialecte** (SQLite, PostgreSQL…), les **règles métier** (avoirs compris ?) et une question précise. 2. Relisez la requête en cherchant les cinq motifs qui mentent : `WHERE` en trop ou manquant, division entière, agrégat ambigu, jointure qui multiplie — et vérifiez le total de contrôle. 3. Testez toujours d'abord sur une copie connue, avec un accès en **lecture seule** : un `UPDATE` ou un `DELETE` collé par erreur échouera alors mécaniquement.

> 🗺️ **Et maintenant ?** — Analyse, graphiques, requêtes : vous avez toutes les briques ; la leçon L058 les assemble dans un reporting hebdomadaire qui se fabrique et s'envoie tout seul avec n8n.
