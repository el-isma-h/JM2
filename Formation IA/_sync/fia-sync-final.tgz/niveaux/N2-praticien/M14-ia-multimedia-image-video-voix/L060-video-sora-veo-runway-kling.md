---
id: L060
module: M14
level: N2
title: "Vidéo : Sora, Veo, Runway, Kling"
minutes: 60
objectives:
  - "Expliquer comment fonctionne un générateur de vidéo (texte-vers-vidéo, image-vers-vidéo) et pourquoi ses limites actuelles découlent de ce fonctionnement"
  - "Comparer Sora, Veo, Runway, Kling et Grok Imagine selon l'accès, la durée des plans, le contrôle offert et le coût"
  - "Construire un workflow de production vidéo IA en six étapes, du brief au fichier livré, avec un budget d'itérations"
  - "Évaluer les risques juridiques d'une vidéo générée (personnes, marques, deepfakes) et appliquer la mention de transparence"
skills: ["C2.5"]
sources:
  - { title: "OpenAI — Sora", url: "https://openai.com/sora", lang: "en" }
  - { title: "Google DeepMind — Veo", url: "https://deepmind.google/models/veo/", lang: "en" }
  - { title: "Runway", url: "https://runwayml.com", lang: "en" }
  - { title: "Kling AI", url: "https://klingai.com", lang: "en" }
  - { title: "xAI — Tarifs (Grok Imagine Video)", url: "https://docs.x.ai/developers/pricing", lang: "en" }
  - { title: "Google — Gemini API : modèles", url: "https://ai.google.dev/gemini-api/docs/models", lang: "en" }
  - { title: "Sénat — Réponse ministérielle sur les deepfakes (05/02/2026)", url: "https://www.senat.fr/questions/base/2025/qSEQ251006478.html", lang: "fr" }
  - { title: "donneespersonnelles.fr — Omnibus numérique IA", url: "https://donneespersonnelles.fr/omnibus-numerique-ia", lang: "fr" }
---

# Vidéo : Sora, Veo, Runway, Kling

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 14

## 🎯 Ce que vous saurez faire
- Comprendre ce qu'un générateur de vidéo sait faire aujourd'hui, et surtout ce qu'il ne sait pas faire, pour ne pas promettre l'impossible à votre direction.
- Choisir un outil (Sora, Veo, Runway, Kling, Grok Imagine) selon votre besoin : clip publicitaire, animation d'une photo produit, vidéo de formation, fond d'écran de salon.
- Dérouler un workflow de production en six étapes, avec storyboard, génération par plans, montage et sous-titres.
- Publier sans risque : personnes, marques, musique, mention « généré par IA ».

> 🧭 **En clair** — Un générateur de vidéo est un excellent caméraman de plans courts, mais il n'est pas réalisateur : il sait tourner une scène de cinq à vingt secondes à partir d'une description ou d'une photo, mais il oublie tout d'un plan à l'autre. Comme pour un film, c'est donc vous qui écrivez le découpage (le storyboard), qui fournissez la même photo de référence pour que le produit reste identique, puis qui montez les plans bout à bout avec la voix, la musique et les titres. Le coût machine se compte en euros ; le vrai coût, c'est le temps passé à refaire les essais ratés. Et comme pour l'image, pas de personne réelle sans accord, et une mention « généré par IA ».

## 1. Comment une IA fabrique dix secondes de film

En mars 2023, une vidéo de quelques secondes montrant « Will Smith mangeant des spaghettis » a fait le tour d'Internet : visage fondu, pâtes qui traversent les joues, mains à six doigts. Moins de deux ans plus tard, les mêmes outils produisent des plans que des professionnels peinent à distinguer d'un tournage. Que s'est-il passé ?

Les générateurs de vidéo sont des **modèles de diffusion** (vus en L059) appliqués non plus à une image, mais à un **bloc espace-temps** : l'outil débruite simultanément des dizaines d'images successives, en forçant leur cohérence. Les modèles de 2024-2026 (Sora d'OpenAI, annoncé en février 2024 ; Veo de Google DeepMind ; Gen-4 de Runway ; Kling du chinois Kuaishou) combinent cette diffusion avec une architecture *transformer* (la même famille de réseaux de neurones que les LLM) qui traite la vidéo comme une suite de « patchs » spatio-temporels, un peu comme un LLM traite des tokens. Plusieurs d'entre eux génèrent désormais **le son en même temps que l'image** (bruitages, ambiances, voire dialogues), ce qui change la nature du produit : on obtient un plan sonorisé et non plus un GIF muet (une courte animation sans son, du type de celles qu'on échange sur les messageries).

> 💡 **Autrement dit** — Pour une image, le modèle « dégrossit » une seule feuille de bruit. Pour une vidéo, il dégrossit d'un coup toute une pile de feuilles (les images successives du film) en s'assurant qu'elles se suivent logiquement, comme les pages d'un folioscope (*flip book*). Il découpe cette pile en petits cubes (les « patchs » spatio-temporels, un bout d'image sur un bout de temps) qu'il traite comme un LLM traite des mots. Certains modèles fabriquent en même temps la bande-son.

Trois modes d'entrée existent :

| Mode | Vous fournissez | L'outil produit | Usage typique |
|---|---|---|---|
| **Texte-vers-vidéo** (*text-to-video*) | Un prompt | Un plan de 5 à 20 s environ selon l'outil | Illustration abstraite, plan d'ambiance, prototype |
| **Image-vers-vidéo** (*image-to-video*) | Une image de départ (photo produit, visuel L059) + consigne de mouvement | Le même plan, animé | Animer une photo de catalogue, un logo, un packshot (photo de produit seul sur fond neutre) |
| **Vidéo-vers-vidéo** / extension | Une vidéo existante + consigne | Style modifié, plan prolongé, élément remplacé | Restylisation, effets, remplacement de décor |

> 💡 **À retenir** — Le mode **image-vers-vidéo** est le plus fiable en entreprise : vous contrôlez l'image de départ (produit exact, bonnes couleurs, pas d'invention) et ne laissez à l'IA que le mouvement. Les leçons L059 (image) et L060 (vidéo) s'enchaînent naturellement.

```quiz
{
  "q": "Une PME veut animer la photo officielle de son nouveau fauteuil pour une publicité, sans que la couleur ni la forme du produit ne changent. Quel mode choisir ?",
  "options": [
    "Texte-vers-vidéo, avec une description très détaillée du fauteuil",
    "Vidéo-vers-vidéo, à partir d'une publicité d'un concurrent",
    "Image-vers-vidéo, à partir de la photo du produit",
    "Aucun : les IA vidéo ne savent pas montrer de produit"
  ],
  "answer": 2,
  "explanation": "En image-vers-vidéo, vous fixez le produit exact, les couleurs et la composition ; l'IA ne fabrique que le mouvement. C'est le mode le plus fiable en entreprise."
}
```

## 2. Les outils (nov. 2026) et comment y accéder

| Outil | Éditeur | Accès | Ce qui le distingue | Ce que notre recherche a pu vérifier |
|---|---|---|---|---|
| **Sora** | OpenAI | Application et site Sora, ChatGPT selon l'offre, API | Qualité de rendu, remix de vidéos existantes, génération sonore | Page officielle citée ; détails d'offre et de prix non vérifiés dans notre dossier — consulter [openai.com/sora](https://openai.com/sora) |
| **Veo** (Veo 3 et suivants) | Google DeepMind | Gemini, Google AI Studio / Vertex AI (la plateforme cloud de Google pour les entreprises), outils Google Workspace et YouTube selon les offres | Son natif, intégration à l'écosystème Google ; l'API Gemini expose aussi un modèle vidéo (`gemini-omni-1.1-flash`) | Fiche modèles Gemini lue ; tarifs Veo non lus (page tronquée) — voir [deepmind.google/models/veo](https://deepmind.google/models/veo/) |
| **Runway** (Gen-4) | Runway (New York) | Application web, API | Outils de contrôle pour créatifs (caméra, références de personnages, *motion brush*) — un « pinceau de mouvement » : on peint la zone de l'image qui doit bouger —, historique de l'entreprise dans la post-production | Page officielle citée ; grille non vérifiée — [runwayml.com](https://runwayml.com) |
| **Kling** | Kuaishou (Chine) | Application web, API | Rapport qualité-prix souvent cité, plans longs, bon rendu des mouvements humains | Page officielle citée ; grille non vérifiée — [klingai.com](https://klingai.com) |
| **Grok Imagine Video** (1.5) | xAI | Abonnement X « Premium » (30 $/mois) et « Super » (100 $/mois, 1080p), API | Intégré à Grok, rapide | Tarif API vérifié : **à partir de 0,02 $ par seconde** de vidéo ; offres d'abonnement vérifiées (oct. 2026) |

Comment lire ce tableau sans se tromper :

- **Le marché bouge chaque trimestre.** Nous indiquons les faits que notre dossier de recherche a pu lire sur des pages officielles ; pour les autres (durée maximale, résolution, prix par clip), ouvrez la page de l'éditeur le jour où vous devez décider. Un tableau figé serait faux dans trois mois.
- **Le prix se raisonne à la seconde produite, itérations comprises.** À 0,02 $ la seconde (Grok Imagine, API), un plan de 10 s coûte 0,20 $ ; mais il vous faudra en moyenne cinq à dix essais pour un plan gardé, soit 1 à 2 $ par plan utile. Une vidéo de 60 s en six plans revient donc à quelques euros de génération… et à plusieurs heures de travail humain. Les abonnements grand public fonctionnent avec des crédits mensuels, même logique.
- **Les données partent chez l'éditeur** (y compris les images de référence que vous téléversez). Pas de visage de salarié, pas de plan d'usine confidentiel, pas de maquette non annoncée. Il n'existe pas, en novembre 2026, d'équivalent local de FLUX pour la vidéo qui soit à la fois ouvert, de qualité comparable et exécutable sur un poste de travail ; des modèles ouverts existent, mais exigent des GPU de serveur et restent en retrait.

> 🔗 **Documentation officielle** — [OpenAI — Sora](https://openai.com/sora) 🇬🇧 · [Google DeepMind — Veo](https://deepmind.google/models/veo/) 🇬🇧 · [xAI — Pricing](https://docs.x.ai/developers/pricing) 🇬🇧 · [Gemini API — Models](https://ai.google.dev/gemini-api/docs/models) 🇬🇧

## 3. Les limites, et pourquoi elles existent

Un générateur de vidéo n'est ni un moteur 3D ni un logiciel de montage : il **hallucine des pixels plausibles**. Ses limites en découlent directement.

| Limite | Pourquoi | Parade |
|---|---|---|
| **Plans courts** (quelques secondes à ~20 s) | Le coût de calcul croît avec la durée et la cohérence se dégrade | Raisonner en **plans**, pas en film : 6 à 10 plans montés |
| **Cohérence des personnages et des objets** entre deux plans | Chaque génération repart du bruit ; le modèle n'a pas de « mémoire » de votre produit | Image de référence identique pour chaque plan ; fonctions de référence (Runway, Kling) ; éviter les personnages récurrents |
| **Physique approximative** (liquides, mains, foules, texte) | Le modèle imite des statistiques visuelles, pas les lois de la physique | Éviter ces sujets ; privilégier plans larges, mouvements lents, objets simples |
| **Texte et logos illisibles ou déformés** | Même faiblesse qu'en image | Ajouter titres et logos au montage |
| **Contrôle limité de la caméra** | Le prompt est interprété, pas exécuté | Vocabulaire de cinéma précis (voir section 4) ; outils de contrôle de caméra quand ils existent |
| **Non-déterminisme** | Même prompt, résultat différent | Fixer la seed si l'outil le permet, garder les bons résultats, ne pas chercher à « reproduire » |
| **Son généré parfois incohérent** (lèvres, langue) | La synchronisation labiale en français est inégale | Générer les plans sans dialogue, ajouter la voix en L061 |

> ⚠️ **Piège fréquent** — Vouloir « la vidéo institutionnelle de 3 minutes en un prompt ». Aucun outil ne le fait. Le bon livrable d'un générateur, c'est **un plan**. Le film, c'est votre storyboard et votre montage.

```quiz
{
  "type": "vrai_faux",
  "q": "En novembre 2026, un bon générateur peut produire une vidéo institutionnelle de 3 minutes, cohérente du début à la fin, en un seul prompt.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Les plans restent courts (quelques secondes à ~20 s) et la cohérence se perd d'un plan à l'autre. Le bon livrable d'un générateur, c'est un plan ; le film naît de votre storyboard et de votre montage."
}
```

## 4. Le workflow de production en six étapes

```mermaid
flowchart LR
    A[1. Brief<br/>objectif, cible, durée, ton] --> B[2. Script et storyboard<br/>un plan = une ligne]
    B --> C[3. Images de référence<br/>L059 : photos ou visuels générés]
    C --> D[4. Génération par plan<br/>5-10 essais, sélection, seed notée]
    D --> E[5. Montage<br/>raccords, voix L061, musique, sous-titres]
    E --> F[6. Contrôle et publication<br/>droits, mention IA, formats]
```

**Étape 1 — Le brief.** Comme pour l'image : objectif (« annoncer l'ouverture de la boutique de Bordeaux »), cible, durée (15 s pour une story, 30 à 60 s pour une page d'accueil), ton, format (9:16 vertical pour les réseaux, 16:9 pour le site), contraintes de marque.

**Étape 2 — Script et storyboard.** Un tableau, une ligne par plan. C'est l'étape que les débutants sautent et qui fait tout gagner.

| N° | Durée | Description visuelle | Mouvement de caméra | Son / voix | Entrée |
|---|---|---|---|---|---|
| 1 | 5 s | Façade de la boutique au lever du jour, rue calme | Travelling avant lent | Ambiance ville, voix off « Bordeaux, 7 h » | Photo réelle de la façade |
| 2 | 4 s | Main qui retourne la pancarte « Ouvert » (sans texte lisible, ajouté au montage) | Fixe, gros plan | Cloche de porte | Texte-vers-vidéo |
| 3 | 6 s | Vitrine, produits alignés, lumière chaude | Panoramique gauche-droite | Musique montante | Visuel L059 (image-vers-vidéo) |

**Étape 3 — Images de référence.** Pour chaque plan où le produit, le lieu ou la charte comptent, partez d'une image : photo réelle ou visuel généré en L059 avec une seed fixée. C'est votre garantie de cohérence.

> 🧭 **Pas à pas pour débutant** — Dans la plupart des outils (Sora, Runway, Kling, Grok Imagine), le mode image-vers-vidéo se repère à une icône **image** ou **+** à côté de la zone de saisie du prompt, ou à un onglet *Image to Video*. Cliquez dessus, choisissez votre photo (JPEG ou PNG, de préférence au format final : verticale pour du 9:16), puis écrivez **uniquement le mouvement** dans le prompt (« la caméra avance lentement, la lumière bouge doucement ») : inutile de redécrire le produit, il est déjà dans l'image. Téléchargez chaque plan retenu en MP4 et nommez-le dans l'ordre du storyboard (`plan01.mp4`, `plan02.mp4`…).

**Étape 4 — Génération par plan.** Le prompt vidéo reprend S-S-C-L-C et ajoute le **mouvement** : du sujet (« la main retourne lentement la pancarte ») et de la caméra. Utilisez le vocabulaire du cinéma, que les modèles ont appris dans les descriptions de films : *travelling avant* (*dolly in*), *panoramique* (*pan*), *plan fixe* (*static shot*), *plongée* (*high angle*), *contre-plongée* (*low angle*), *ralenti* (*slow motion*), *profondeur de champ réduite* (*shallow depth of field*). Lancez 5 à 10 essais, sélectionnez, notez la seed et le prompt retenus.

**Étape 5 — Montage.** Assemblez dans un logiciel de montage (DaVinci Resolve, CapCut, Premiere) ou en ligne de commande avec `ffmpeg` : raccords, voix off et musique (L061), titres, sous-titres, normalisation du son (mise au même volume de tous les plans, pour éviter qu'un passage soit beaucoup plus fort qu'un autre).

**Étape 6 — Contrôle et publication.** Checklist juridique (section 5), mention « généré par IA », exports aux formats attendus (9:16, 16:9, 1:1), sous-titres incrustés pour les réseaux sociaux (la majorité des vidéos y sont regardées sans le son).

> 🧭 **Pas à pas pour débutant** — Monter sans terminal avec **CapCut** (gratuit, version ordinateur) : (1) *Nouveau projet*, importez vos plans `plan01.mp4`… et votre voix off ; (2) glissez les plans sur la ligne de temps dans l'ordre du storyboard, puis la voix off sur la piste audio en dessous ; (3) menu **Texte → Sous-titres automatiques** (*Légendes automatiques*), langue français : CapCut transcrit la voix ; relisez et corrigez chaque sous-titre ; (4) ajoutez titre et logo avec **Texte** et **Importer** (image) ; (5) pour la version réseaux sociaux, changez le **format** du projet en 9:16 et recadrez chaque plan ; (6) **Exporter** en 1080p, MP4. Vérifiez les conditions d'utilisation de CapCut pour un usage commercial et, si votre entreprise l'exige, préférez DaVinci Resolve (gratuit également).

Un script d'assemblage minimal, utile pour automatiser la sortie de plusieurs formats :

```bash
#!/usr/bin/env bash
# assembler.sh — concatène des plans générés, ajoute une voix off et incruste des sous-titres.
# Prérequis : ffmpeg installé ; plans plan01.mp4 … plan06.mp4, voix.mp3, sous-titres.srt dans le dossier.
set -euo pipefail

# 1. Liste des plans dans l'ordre du storyboard
printf "file '%s'\n" plan0{1..6}.mp4 > liste.txt

# 2. Concaténation en ré-encodant (les plans générés n'ont pas toujours les mêmes paramètres)
ffmpeg -y -f concat -safe 0 -i liste.txt -c:v libx264 -crf 20 -preset medium -an montage_muet.mp4

# 3. Voix off + sous-titres incrustés (police lisible sur mobile), piste audio normalisée (EBU R128)
ffmpeg -y -i montage_muet.mp4 -i voix.mp3 \
  -vf "subtitles=sous-titres.srt:force_style='FontSize=22,Outline=1'" \
  -af "loudnorm=I=-16:TP=-1.5:LRA=11" \
  -c:v libx264 -crf 20 -c:a aac -b:a 160k -shortest video_16x9.mp4

# 4. Déclinaison verticale 9:16 pour les réseaux (recadrage centré)
ffmpeg -y -i video_16x9.mp4 -vf "crop=ih*9/16:ih,scale=1080:1920" -c:a copy video_9x16.mp4
echo "Exports : video_16x9.mp4 et video_9x16.mp4"
```

🎮 **Défi** — Prenez une vidéo d'entreprise existante (la vôtre ou celle d'un concurrent, 30 s) et rédigez son storyboard inversé : un tableau par plan, avec durée, mouvement de caméra et son. Vous constaterez que les vidéos professionnelles enchaînent des plans de 2 à 6 secondes : exactement la longueur que les générateurs savent produire.

> 💡 **Autrement dit** — Le script `assembler.sh` ci-dessus est réservé aux personnes à l'aise avec le terminal : il fait automatiquement ce qu'un logiciel de montage fait à la souris. `ffmpeg` est un outil gratuit de traitement vidéo en ligne de commande ; un fichier `.srt` est un simple fichier texte de sous-titres (numéro, heure de début et de fin, texte) ; « EBU R128 » est la norme européenne de volume sonore des diffusions. Si vous montez dans CapCut ou DaVinci Resolve, vous pouvez passer ce script sans rien perdre.

```quiz
{
  "q": "Mise en situation : vous voulez une caméra qui avance lentement vers la vitrine. Quelle formulation donnera le résultat le plus fiable dans le prompt ?",
  "options": [
    "« Une vidéo dynamique, immersive et cinématographique de la vitrine »",
    "« Travelling avant lent (dolly in), 5 s »",
    "« Fais comme dans un grand film hollywoodien, avec beaucoup d'émotion »",
    "« Bouge un peu la caméra si tu penses que c'est mieux »"
  ],
  "answer": 1,
  "explanation": "Les modèles ont appris le vocabulaire du cinéma dans des descriptions de films : un mouvement nommé (travelling avant, dolly in) et une durée sont bien mieux interprétés que des adjectifs."
}
```

```mission
{
  "title": "Combien coûte une seconde de vidéo Grok Imagine par API ?",
  "url": "https://docs.x.ai/developers/pricing",
  "steps": ["Ouvrez la page Pricing de la documentation xAI", "Repérez la section consacrée à Grok Imagine (image et vidéo)", "Notez le tarif de la vidéo à la seconde, puis cherchez la remise accordée à l'API Batch"],
  "question": "À partir de quel prix par seconde la vidéo Grok Imagine est-elle facturée, et quelle remise offre la Batch API de xAI ?",
  "hint": "Le prix vidéo se compte en centimes de dollar ; la remise Batch est inférieure à celle d'Anthropic et d'OpenAI.",
  "answer": "À partir de 0,02 $ par seconde de vidéo ; Batch API −20 % (nov. 2026) — vérifiez : les prix évoluent (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 5. Droits, deepfakes et transparence

**Personnes réelles.** Animer la photo d'une personne (collègue, client, dirigeant, personnalité) sans consentement écrit expose au droit à l'image et, en cas de montage trompeur, à l'article **226-8 du Code pénal** tel que modifié par la loi SREN : jusqu'à **2 ans d'emprisonnement et 45 000 € d'amende** lorsque la diffusion a lieu en ligne. Le texte vise explicitement les contenus « générés par un traitement algorithmique ». Les outils eux-mêmes bloquent souvent les visages de personnalités, mais ce filtre n'est pas une autorisation.

**Marques, œuvres, personnages.** Un plan « dans l'univers d'un film connu », avec un personnage sous licence ou un logo tiers, viole le droit d'auteur et le droit des marques comme l'aurait fait un tournage. Décrivez plutôt l'ambiance que vous voulez.

**Musique.** Les générateurs produisent parfois une musique avec le plan ; pour une bande-son maîtrisée, voyez L061 (Suno et ses conditions) ou une banque sous licence. N'utilisez jamais un titre commercial « trouvé en ligne ».

**Transparence.** Depuis le **2 août 2026**, l'article 50 de l'AI Act impose le marquage des contenus vidéo générés ou manipulés par IA et, pour les *deepfakes* (contenus représentant des personnes, lieux ou événements réels de manière trompeuse), une mention explicite. Manquement : jusqu'à **15 M€ ou 3 % du chiffre d'affaires mondial** (réponse ministérielle au Sénat du 5 février 2026). En pratique : conservez les métadonnées de provenance insérées par l'outil, ajoutez « Vidéo générée par IA » dans la description et, pour les contenus réalistes, à l'écran.

> 💡 **À retenir** — Une vidéo générée est un **document de communication** comme un autre : mêmes droits, mêmes autorisations, plus une mention d'origine. La nouveauté n'est pas juridique, elle est dans la facilité de faire une bêtise en trente secondes.

> 🔗 **Documentation officielle** — [Sénat — réponse ministérielle, deepfakes et AI Act](https://www.senat.fr/questions/base/2025/qSEQ251006478.html) 🇫🇷 · [donneespersonnelles.fr — calendrier de l'AI Act](https://donneespersonnelles.fr/omnibus-numerique-ia) 🇫🇷 · [Règlement (UE) 2024/1689 — EUR-Lex](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) 🇫🇷

```mission
{
  "title": "Que dit le gouvernement sur les sanctions des deepfakes ?",
  "url": "https://www.senat.fr/questions/base/2025/qSEQ251006478.html",
  "steps": ["Ouvrez la question écrite publiée sur le site du Sénat", "Repérez la date de la réponse du ministère", "Cherchez dans la réponse le montant maximal des sanctions prévues par l'AI Act pour un manquement aux obligations de transparence"],
  "question": "À quelle date le ministère a-t-il répondu, et quel est le plafond de sanction cité pour un manquement à l'obligation de transparence ?",
  "hint": "La réponse est publiée au début de 2026 ; le plafond combine un montant en millions d'euros et un pourcentage du chiffre d'affaires mondial.",
  "answer": "Réponse publiée le 5 février 2026 ; jusqu'à 15 M€ ou 3 % du chiffre d'affaires annuel mondial.",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Une menuiserie artisanale de Haute-Savoie (8 salariés) ouvre un showroom. Elle vous demande une vidéo de 30 secondes pour Instagram (9:16) et son site (16:9) : ambiance atelier, bois, lumière chaude, aucun salarié à l'écran, un seul produit vedette (une table en chêne dont vous avez une photo).

1. Rédigez le brief (objectif, cible, durée, ton, formats, contraintes).
2. Construisez le storyboard : 6 plans de 4 à 6 s, avec pour chacun description, mouvement de caméra, son, type d'entrée (texte, image réelle, image générée).
3. Écrivez le prompt complet de **deux** plans : un texte-vers-vidéo (ambiance atelier) et un image-vers-vidéo (la table, à partir de la photo).
4. Estimez le budget de génération : nombre d'essais par plan, coût à la seconde (prenez 0,02 $/s comme ordre de grandeur) et temps humain.
5. Rédigez la checklist de publication (droits, musique, mention IA, formats).

**Critères de réussite.**
- Le storyboard tient en un tableau lisible ; la somme des durées fait 28 à 32 s.
- Les deux prompts contiennent sujet, style, composition, lumière, contraintes **et** un mouvement de caméra nommé.
- Le budget distingue coût machine (quelques euros) et coût humain (heures) et explique le ratio essais / plans gardés.
- La checklist mentionne l'absence de personne identifiable, l'origine de la musique et la mention « généré par IA ».

<details>
<summary>Pistes de corrigé</summary>

Plan image-vers-vidéo possible : *« À partir de la photo fournie de la table en chêne : plan fixe en légère contre-plongée, la caméra effectue un lent travelling circulaire de 20° autour de la table, lumière chaude de fin d'après-midi par une fenêtre à gauche, particules de poussière dans la lumière, profondeur de champ réduite, aucune personne, aucun texte, le produit reste strictement identique à la photo. 5 secondes, 9:16. »* Budget : 6 plans × 8 essais × 5 s × 0,02 $ ≈ 4,80 $ de génération ; temps humain estimé : 1 h de storyboard, 2 h de génération et tri, 2 h de montage et déclinaisons.
</details>

## ✅ Auto-évaluation express

1. Pourquoi le mode image-vers-vidéo est-il recommandé pour une vidéo produit ?
2. Un plan généré coûte 0,02 $/s ; combien coûte une vidéo de 6 plans de 5 s si l'on garde un essai sur huit ?
3. Que risque une entreprise qui publie une vidéo réaliste d'un concurrent « disant » quelque chose qu'il n'a jamais dit ?

<details>
<summary>Réponses</summary>

1. L'image de départ fixe le produit, les couleurs et la composition ; l'IA n'invente que le mouvement, ce qui limite les hallucinations et garantit la cohérence entre plans.
2. 6 × 8 × 5 s × 0,02 $ = 4,80 $ (contre 0,60 $ si tout était bon du premier coup) : le coût réel, c'est l'itération et le temps humain.
3. Article 226-8 du Code pénal (jusqu'à 2 ans et 45 000 € en cas de diffusion en ligne), action civile du concurrent (dénigrement, droit à l'image) et sanction AI Act art. 50 pour absence de marquage (jusqu'à 15 M€ ou 3 % du CA).
</details>

## 📚 Pour aller plus loin
- [Runway](https://runwayml.com) 🇬🇧 — outils de contrôle (caméra, références) et ressources pour créatifs.
- [Kling AI](https://klingai.com) 🇬🇧 — générateur de Kuaishou, application web et API.
- [Google DeepMind — Veo](https://deepmind.google/models/veo/) 🇬🇧 — présentation du modèle et accès via Gemini / Vertex AI.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — données personnelles (images, visages) dans les systèmes d'IA.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un générateur vidéo produit des **plans** de quelques secondes, pas un film : écrivez un storyboard, générez plan par plan (5 à 10 essais chacun) et montez ensuite avec voix, musique, titres et sous-titres. 2. Le mode **image-vers-vidéo**, à partir d'une photo réelle du produit, est le plus fiable : l'IA n'ajoute que le mouvement ; décrivez celui-ci avec le vocabulaire du cinéma (travelling, panoramique, plan fixe). 3. Mêmes règles que pour l'image : aucune personne réelle sans accord écrit, aucune marque ni musique tierce, et une mention « vidéo générée par IA ».

> 🗺️ **Et maintenant ?** — Vos plans sont muets ou presque ; la leçon L061 leur donne une voix, une transcription et une musique avec ElevenLabs, Whisper et Suno, en gardant les mêmes réflexes de consentement.
