---
module: M14
title: "Fiche mémo — IA multimédia : image, vidéo, voix"
---
# Fiche mémo — M14 · IA multimédia : image, vidéo, voix

> En une phrase : l'IA d'image sculpte du bruit selon votre brief, l'IA de vidéo tourne des plans courts que vous montez, l'IA audio transcrit, lit ou compose ; partout, la même règle avant publication : licence, consentement, mention « généré par IA ».

## Les 7 idées à retenir
1. **La diffusion** : partir d'une neige de pixels et la débruiter étape par étape, guidé par le texte. Le modèle synthétise du plausible, il ne cherche pas une photo (`L059`).
2. **Un prompt d'image est un brief de production** : méthode S-S-C-L-C ; itérez une seule variable à la fois, seed fixée ; jamais de texte dans l'image (`L059`).
3. **Fermé ou ouvert** : gpt-image, Nano Banana, Grok Imagine, Midjourney (quelques centimes l'image) contre FLUX / Stable Diffusion dans ComfyUI (confidentiel, la VRAM décide) (`L059`).
4. **Un générateur de vidéo est un caméraman de plans courts, pas un réalisateur** : le film, c'est votre storyboard et votre montage (`L060`).
5. **Image-vers-vidéo = le mode le plus fiable** : votre image fixe le produit, l'IA n'invente que le mouvement (`L060`).
6. **Trois métiers audio** : sténographe (STT, Whisper), comédien de doublage (TTS, ElevenLabs), compositeur (Suno). La transcription est le cas le plus rentable et le moins risqué (`L061`).
7. **La voix est une donnée personnelle** (biométrique si elle identifie) : pas de clonage sans consentement écrit, et un standard vocal se présente comme une IA (`L061`).

## Le schéma à connaître

```mermaid
flowchart LR
  A["1. Brief<br/>objectif, cible, durée, format"] --> B["2. Storyboard<br/>un plan = une ligne"]
  B --> C["3. Images de référence<br/>photo réelle ou visuel généré"]
  C --> D["4. Génération par plan<br/>5 à 10 essais, seed notée"]
  D --> E["5. Montage<br/>voix, musique, titres, sous-titres"]
  E --> F["6. Contrôle<br/>droits, mention IA, formats"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| S-S-C-L-C | Sujet, Style, Composition, Lumière, Contraintes |
| Negative prompt / `--no` | Ce qui doit être absent (Stable Diffusion / Midjourney) |
| KSampler | Le tableau de bord : étapes (coups de ciseau), CFG (obéissance), seed (numéro du bloc de marbre) |
| STT / TTS | Voix → texte / texte → voix |
| `initial_prompt` (Whisper) | La liste de mots glissée à la sténographe avant la réunion |

## Les pièges classiques
- Demander du texte ou un logo dans l'image ou la vidéo : ajoutez-les à la mise en page ou au montage.
- « Poids ouverts » ≠ libre de droits : FLUX.1 schnell est Apache 2.0, FLUX.1 dev ne l'est pas, SD 3.5 a une licence communautaire.
- « La vidéo de 3 minutes en un prompt » : aucun outil ne le fait.
- Envoyer un enregistrement de réunion à une API sans vérifier les conditions ni **informer les participants**.
- « Elle est d'accord à l'oral » pour un clonage vocal : il faut un écrit spécifique et révocable.

## Les commandes / chiffres / dates utiles
- **4 réflexes avant de publier une image, mnémo « L-P-M-A »** : **L**icence ou CGU compatibles · aucune **P**ersonne réelle sans accord écrit · **M**ention « généré par IA » si le contexte peut tromper · prompts et retouches **A**rchivés (preuve de l'apport humain).
- **3 questions d'un projet vocal** : qui parle ? qui écoute ? où vont les données ?
- Mémoire d'un modèle d'image : milliards × bits ÷ 8 × 1,1 **+ encodeur T5 + VAE**. FLUX (12 Md) : ≈ 26 Go en FP16, 24 Go de VRAM en FP8, 12 à 16 Go en 4 bits.
- Prix (nov. 2026) : Nano Banana 2.1 ≈ 0,034 $ l'image ; Grok Imagine 0,04 à 0,08 $ ; Grok Imagine Video dès 0,02 $/s (6 plans × 8 essais × 5 s ≈ 4,80 $) ; gpt-transcribe 0,0045 $/min (≈ 0,27 $/h) ; Voxtral TTS 3 13 $ par million de caractères.
- Whisper (sept. 2022, licence MIT) : `tiny` ≈ 1 Go → `large` ≈ 10 Go de VRAM. L'API `whisper-1` d'OpenAI s'arrête le 26 févr. 2027 ; le Whisper local n'est pas concerné.
- Droit : sortie brute non protégée (art. L111-1 CPI) ; deepfake image ou voix sans consentement diffusé en ligne : jusqu'à 2 ans et 45 000 € (art. 226-8 du code pénal) ; AI Act art. 50 depuis le 2 août 2026 (marquage technique des systèmes existants au 2 déc. 2026), jusqu'à 15 M€ ou 3 % du CA.

## Pour aller plus loin
- [ComfyUI (GitHub)](https://github.com/comfyanonymous/ComfyUI)
- [Whisper — dépôt GitHub](https://github.com/openai/whisper)
- [Hugging Face — Audio Course](https://huggingface.co/learn/audio-course)

## Auto-test (3 questions — réponses en bas de fiche)
1. FLUX.1 dev en FP16 sur une RTX 4060 Ti 16 Go : réaliste ?
2. Pourquoi l'image-vers-vidéo est-il recommandé pour une vidéo produit ?
3. Votre standard téléphonique IA doit-il dire qu'il est une IA ?

---
**Réponses** — 1. Non (≈ 26 Go + T5) ; oui en FP8 ou 4 bits, ou en déchargeant en RAM, plus lentement. 2. L'image fixe produit, couleurs et composition ; l'IA n'invente que le mouvement. 3. Oui (AI Act art. 50, depuis le 2 août 2026), avec une bascule possible vers un humain.
