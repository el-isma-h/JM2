# Niveau 2 — Praticien IA et automatisation (NF-IA-N2)

**Certificat Next Formation IA — Niveau 2 « Praticien IA & automatisation »** · 35 h à distance (34 h de leçons et exercices + 1 h d'évaluations) · 8 modules · 33 leçons · 8 quiz · 1 examen · 5 projets pratiques · Version 1.0 — 1er novembre 2026.

## Promesse

À l'issue du niveau 2, vous **automatisez des processus métier sans écrire de code** (n8n, Make, Zapier), vous déployez des assistants IA spécialisés alimentés par vos propres documents (RAG), vous faites tourner un modèle de langage **en local** sur votre machine en sachant le dimensionner, vous exploitez l'IA pour analyser des données et produire un reporting automatique, vous créez des contenus visuels, vidéo et audio dans le respect des droits, et vous cadrez l'usage de l'IA dans votre organisation (grille SaaS / API / local, politique interne conforme à l'AI Act et au RGPD).

## Public

Professionnels qui veulent passer de l'usage à la mise en œuvre sans être développeurs : assistants et office managers, chefs de projet, responsables marketing, commerciaux, RH, consultants, dirigeants de TPE/PME, indépendants, formateurs. C'est le niveau « automatisation et agents IA » le plus demandé sur le marché français (n8n, Make, agents, RAG).

## Prérequis

- Niveau 1 Next Formation validé ou connaissances équivalentes (usage courant d'un assistant IA, bases du prompt, notions RGPD/AI Act).
- À l'aise avec les outils bureautiques en ligne (Google Workspace ou Microsoft 365) et la notion de fichier CSV.
- Aucune programmation : les expressions n8n et quelques lignes de JavaScript/Python optionnelles sont expliquées pas à pas.

## Compétences du bloc 2 (référentiel de compétences)

| Code | Compétence |
|---|---|
| C2.1 | Construire un workflow d'automatisation n8n intégrant un modèle de langage, des sources de données externes et une gestion des erreurs |
| C2.2 | Déployer un assistant IA spécialisé (projet, GPT personnalisé, agent n8n) alimenté par une base de connaissances documentaire (RAG) |
| C2.3 | Dimensionner et installer un modèle de langage local adapté à une configuration matérielle donnée (mémoire, stockage, vitesse) |
| C2.4 | Exploiter l'IA pour analyser des données tabulaires et produire un reporting automatisé |
| C2.5 | Produire des contenus visuels, vidéo ou audio avec des outils génératifs en respectant les droits et la mention d'origine |
| C2.6 | Élaborer une politique d'usage de l'IA et une grille de choix (SaaS, API, local) pour une organisation, conforme à l'AI Act et au RGPD |

## Modules et durées

| Module | Titre | Leçons | Durée | Compétences |
|---|---|---|---|---|
| M08 | n8n avancé : automatiser avec l'IA (nœuds, erreurs, AI Agent, RAG, intégrations, Docker, projet support client) | L032-L038 | 6 h 50 | C2.1 |
| M09 | Make, Zapier et choix d'un outil d'automatisation | L039-L040 | 2 h 15 | C2.1 |
| M10 | LLM locaux : faire tourner l'IA sur sa machine (matériel, Ollama, LM Studio, choix de modèle, API locale) | L041-L046 | 6 h 15 | C2.3 |
| M11 | RAG et bases de connaissances (embeddings, n8n/Dify/Flowise/NotebookLM, chunking, projets Claude / GPT / Gems) | L047-L050 | 4 h 15 | C2.2 |
| M12 | Assistants et agents sans code (Custom GPT, Projets Claude, Copilot Studio, agents n8n, Claude Code / Lovable / Bolt / v0, computer use) | L051-L054 | 4 h 20 | C2.2 |
| M13 | Données et analyse avec l'IA (CSV/Excel, visualisations, SQL en langage naturel, reporting automatisé) | L055-L058 | 4 h 20 | C2.4 |
| M14 | IA multimédia : image, vidéo, voix | L059-L061 | 3 h 20 | C2.5 |
| M15 | Gouvernance et déploiement de l'IA en entreprise (SaaS/API/local, politique IA, conduite du changement) | L062-L064 | 2 h 25 | C2.6 |
| | **Total leçons et exercices** | 33 leçons | **34 h 00** | |
| | Quiz de modules (8 × 15 min) et examen de niveau (60 min) | | ≈ 1 h (comptés dans les 35 h) | |

## Modalités d'évaluation

- **8 quiz de fin de module** (10 questions, seuil 70 %) et **examen de niveau** (40 questions, 60 min, seuil 70 %, surveillé à distance, 3 tentatives).
- **Cinq épreuves pratiques évaluées sur grille** (5 critères notés 0-3 ; compétence validée si ≥ 8/15 sans critère à 0) :
  1. Workflow n8n livré — assistant de support client automatisé (L038) → C2.1
  2. Assistant RAG répondant à 8 questions sur 10 à partir des documents fournis, sources citées (L048 / L052) → C2.2
  3. Installation documentée d'un LLM local avec calcul de dimensionnement (L043) → C2.3
  4. Reporting hebdomadaire automatisé (L058) → C2.4
  5. Politique IA interne et grille de choix SaaS / API / local (L063) → C2.6 ; production multimédia évaluée sur grille (M14) → C2.5
- **Certification (option RS)** : soutenance de 20 min devant jury (démonstration du workflow et de l'assistant). Toutes les compétences C2.1 à C2.6 doivent être validées.

## Certifications tierces visées (en complément, hors Next Formation)

- **n8n Academy** — certificats de complétion N8N101, N8N102, N8N103 (programme « n8n Foundations », 70 % requis, badge Accredible) — https://learn.n8n.io/courses ; **certification officielle n8n** dès sa sortie (annoncée fin T4 2026).
- **Make Academy** — badges Credly « AI Agent Builder » et « AI Automation Explorer » (gratuits) — https://academy.make.com/.
- **Google AI Professional Certificate** (8 cours, Coursera / Google Skills) — https://www.coursera.org/professional-certificates/google-ai.
- Badges gratuits **Claude Academy** : « Introduction to Claude Cowork », « Introduction to Claude Tag », « Introduction to agent skills ».
- À confirmer après lecture du référentiel officiel : **AWS Certified AI Practitioner (AIF-C01)**.

## Matériel et logiciels nécessaires

- Ordinateur Windows 10/11, macOS 13+ ou Linux, **16 Go de RAM recommandés** (8 Go minimum) et 30 Go d'espace disque pour les modèles locaux ; webcam et micro pour l'examen et la soutenance. Un Mac Apple Silicon ou un PC avec GPU NVIDIA (≥ 8 Go de VRAM) est un plus pour le module 10, pas une obligation : les exercices sont calibrés pour des modèles de 3 à 8 milliards de paramètres en 4 bits (≈ 2 à 5,5 Go).
- **Comptes gratuits** : n8n Cloud (essai gratuit) ou n8n auto-hébergé (Docker Desktop, gratuit — L037), Make (plan gratuit), Zapier (plan gratuit), Claude, ChatGPT, Gemini (NotebookLM), Perplexity, Hugging Face (lecture des fiches de modèles).
- **Logiciels gratuits à installer** : Ollama (https://ollama.com/download), LM Studio ou Jan, Docker Desktop (pour n8n et Open WebUI), un tableur (LibreOffice, Excel ou Google Sheets).
- **Clé API d'un fournisseur de LLM** pour les nœuds IA de n8n (M08) : crédits de quelques euros suffisent (Anthropic, OpenAI, Mistral, Google ou Groq) — ou un modèle local via Ollama (L046) pour travailler sans frais.
- Module 14 : versions gratuites ou d'essai des outils d'image/vidéo/voix ; génération d'image locale (Flux/Stable Diffusion via ComfyUI) démontrée par le formateur si la machine ne le permet pas.
