---
id: L050
module: M11
level: N2
title: "Projets Claude, GPT personnalisés, Gems : la connaissance embarquée"
minutes: 55
objectives:
  - "Configurer un Projet Claude, un GPT personnalisé ou un Gem avec des instructions et des documents de référence adaptés à un cas métier"
  - "Rédiger des instructions types (rôle, périmètre, sources, format, refus) réutilisables d'un outil à l'autre"
  - "Identifier les limites de la connaissance embarquée (taille, fraîcheur, absence de filtres, confidentialité) et décider quand passer à un vrai RAG"
  - "Appliquer les règles de confidentialité : quels documents peuvent être déposés, sous quelle offre, avec quels réglages"
skills: ["C2.2"]
sources:
  - { title: "Claude Academy — Claude 101 (Introduction to projects)", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "Claude Academy — AI Fluency for small businesses", url: "https://academy.claude.com/courses/ai-fluency-for-small-businesses", lang: "en" }
  - { title: "Claude Help Center", url: "https://support.claude.com/", lang: "en" }
  - { title: "Claude Platform — Context windows", url: "https://platform.claude.com/docs/en/build-with-claude/context-windows", lang: "en" }
  - { title: "Claude Platform — PDF support", url: "https://platform.claude.com/docs/en/build-with-claude/pdf-support", lang: "en" }
  - { title: "Claude Platform — Files API", url: "https://platform.claude.com/docs/en/build-with-claude/files", lang: "en" }
  - { title: "Claude Platform — Citations", url: "https://platform.claude.com/docs/en/build-with-claude/citations", lang: "en" }
  - { title: "OpenAI — Tarifs (file search)", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "xAI — Collections search", url: "https://docs.x.ai/developers/tools/collections-search", lang: "en" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
---

# Projets Claude, GPT personnalisés, Gems : la connaissance embarquée

> ⏱ 55 min · 🎯 Niveau 2 · 📚 Module 11

## 🎯 Ce que vous saurez faire
- Créer en quinze minutes un assistant spécialisé dans Claude, ChatGPT ou Gemini, nourri de vos documents, sans aucun outil externe.
- Rédiger un bloc d'instructions qui tient sur une page et qui fonctionne dans les trois outils.
- Expliquer à votre direction pourquoi « déposer les documents dans un projet » n'est pas la même chose qu'« un RAG », et quand chacun convient.
- Appliquer une règle de confidentialité simple avant chaque dépôt de document.

> 🧭 **En clair** — Un Projet Claude, un GPT personnalisé ou un Gem, c'est un **classeur d'accueil** que vous remettez une fois pour toutes à votre assistant : en première page, sa fiche de poste (les instructions) ; derrière, vos documents de référence. Chaque nouvelle conversation commence avec ce classeur sous le bras, sans que vous ayez à tout réexpliquer. Tant que le classeur est fin, l'assistant le relit en entier à chaque question ; quand il devient épais, il ne feuillette plus que les pages qui lui semblent utiles. C'est parfait pour une personne ou une petite équipe — mais ce n'est pas une bibliothèque d'entreprise avec des droits d'accès et des mises à jour automatiques.

## 1. Trois noms, une même idée : l'assistant « pré-chargé »

Les trois grands assistants grand public proposent la même fonction sous trois noms :

| Outil | Nom de la fonction | Ce que vous configurez |
|---|---|---|
| **Claude** (Anthropic) | **Projet** (*Project*) | Instructions du projet + **connaissances** (fichiers, textes) + conversations regroupées |
| **ChatGPT** (OpenAI) | **GPT personnalisé** (*custom GPT*) | Instructions + fichiers de connaissances + capacités (navigation, images, code) + actions |
| **Gemini** (Google) | **Gem** | Instructions + fichiers (y compris depuis Google Drive) |

Le principe est celui du **contexte permanent** : au lieu de recoller vos consignes et vos documents à chaque conversation, vous les déposez une fois ; chaque nouvelle discussion démarre avec. Le cours « Claude 101 » de Claude Academy y consacre une leçon (« Introduction to projects »), et le cours « AI Fluency for small businesses » montre des usages TPE/PME.

Pour une PME, c'est l'outil le plus rentable de tout ce module : zéro installation, zéro maintenance, et une réponse à 80 % des besoins (« réponds à mes clients dans le ton de la maison », « relis mes devis selon nos CGV », « aide les nouveaux à trouver la bonne procédure »).

```mission
{
  "title": "Repérez la leçon consacrée aux projets dans le cours Claude 101",
  "url": "https://academy.claude.com/courses/claude-101",
  "steps": ["Ouvrez la page du cours Claude 101 sur Claude Academy", "Repérez la durée et le nombre de leçons", "Trouvez la partie qui traite de l'organisation du travail et des connaissances"],
  "question": "Combien de temps dure le cours Claude 101, et quelles sont les trois leçons de la partie « Organizing your work and knowledge » ?",
  "hint": "L'une de ces leçons porte exactement sur l'objet de la présente leçon.",
  "answer": "Environ 2 h 30 (13 leçons + quiz, certificat gratuit) ; partie 3 : « Introduction to projects », « Creating with artifacts », « Working with skills » (relevé nov. 2026).",
  "xp": 10
}
```


## 2. Comment ça marche vraiment : contexte long ou recherche ?

Quand vous déposez 15 fichiers dans un Projet Claude, que se passe-t-il à chaque question ? Deux mécanismes, et il est utile de savoir lequel s'applique :

1. **Tout tient dans la fenêtre de contexte.** Les modèles Claude 5.5 et Fable 5.1 disposent d'une fenêtre de 1 million de tokens (nov. 2026, soit environ 555 000 mots avec le tokenizer actuel (le découpeur qui transforme le texte en tokens), d'après la documentation Claude Platform). Tant que vos documents tiennent, le modèle les **lit intégralement** à chaque question. C'est le cas le plus simple et le plus fiable : aucun risque de rater un passage, puisque tout est lu. Côté API, la même approche s'appelle *long context prompting*, et le *prompt caching* (mise en cache : le fournisseur garde en mémoire les documents déjà lus et facture beaucoup moins cher leur relecture) évite de repayer la lecture des documents à chaque tour.
2. **Ça ne tient plus.** Au-delà d'un certain volume, les assistants basculent sur une **recherche dans les connaissances** : seuls les passages jugés pertinents sont fournis au modèle. C'est un RAG, mais dont vous ne contrôlez ni le découpage, ni la recherche, ni les filtres. Les seuils exacts et la disponibilité de ce mode dépendent de l'outil et de l'offre : vérifiez-les dans le centre d'aide de l'éditeur au moment de votre projet.

```
 Volume de documents ─────────────────────────────────────────────────►
 │ quelques pages          │ quelques centaines de pages    │ milliers de pages, mises à jour
 │ CONTEXTE LONG           │ RECHERCHE INTÉGRÉE (RAG caché) │ VRAI RAG (leçons 47-49)
 │ Projet / GPT / Gem      │ Projet / GPT / Gem             │ n8n, Dify, API + base vectorielle
 │ tout est lu             │ passages sélectionnés          │ vous contrôlez découpage, filtres, droits
```

> 💡 **À retenir** — Un Projet, un GPT ou un Gem est un **excellent RAG pour une personne ou une petite équipe sur un corpus stable**. Ce n'est pas un système documentaire d'entreprise : pas de droits par utilisateur, pas de filtres par date, pas de journal d'évaluation, pas de mise à jour automatique.

```quiz
{
  "q": "Vous déposez 20 pages de procédures dans un Projet Claude. Comment le modèle les utilise-t-il, le plus souvent ?",
  "options": [
    "Il ne les lit jamais, il répond de mémoire",
    "Il les envoie à une base vectorielle que vous devez configurer",
    "Il les lit en entier : elles tiennent dans le contexte",
    "Il n'en lit que les titres et la première page"
  ],
  "answer": 2,
  "explanation": "Avec une fenêtre de 1 million de tokens (environ 555 000 mots), 20 pages tiennent sans difficulté : tout est lu. La recherche par passages (RAG caché) n'intervient qu'au-delà d'un certain volume."
}
```


## 3. Les instructions types

Les instructions sont le levier numéro un. Le même bloc, à quelques mots près, fonctionne dans les trois outils. Modèle à copier-adapter :

```
RÔLE
Tu es l'assistant interne de [Menuiserie Lacombe], artisan menuisier à Angoulême.
Tu aides les salariés (atelier, pose, commercial) et tu t'adresses à eux avec « vous ».

PÉRIMÈTRE ET SOURCES
Tu réponds UNIQUEMENT à partir des documents déposés dans ce projet :
CGV 2026, grille tarifaire 2026, procédures POSE-01 à POSE-08, consignes de
sécurité SEC-01 à SEC-04, fiches fournisseurs. Si la réponse n'y figure pas,
dis « Cette information n'est pas dans la base » et indique à qui s'adresser.
En cas de contradiction entre deux documents, signale-la et privilégie le plus récent.

FORMAT
Réponse courte d'abord (2-3 phrases), puis détails si nécessaire.
Cite la source entre crochets après chaque information : [CGV 2026, art. 7].
Pour une procédure, utilise une liste numérotée en conservant l'ordre du document.

INTERDITS
Ne jamais inventer un prix, un délai ou une référence.
Ne jamais donner de conseil juridique au-delà du contenu des CGV : renvoyer
vers la direction. Ne pas traiter de données personnelles de clients.

STYLE
Français professionnel, concret, sans jargon inutile ; vocabulaire du métier
(dormant, ouvrant, bâti, quincaillerie) utilisé correctement.
```

Cinq blocs : **rôle, périmètre et sources, format, interdits, style**. Ils reprennent la structure de prompt du module 4 (niveau 1) et les consignes de citation du tutoriel n8n (leçon 48). Deux ajouts propres à la connaissance embarquée : la **liste explicite des documents** (le modèle sait ce qu'il est censé avoir) et la **règle de résolution des contradictions** (indispensable dès que deux versions d'un tarif cohabitent).

> 💡 **Autrement dit** — Les instructions, c'est la fiche de poste d'un nouvel employé : qui il est (rôle), où il a le droit de chercher (sources), comment il rend son travail (format), ce qu'il ne doit jamais faire (interdits), et sur quel ton il parle (style). Plus la fiche est claire, moins il improvise.

```quiz
{
  "type": "mise_en_situation",
  "q": "Votre GPT personnalisé donne un tarif concurrent trouvé sur Internet au lieu de votre grille tarifaire déposée. Quelle correction est la plus efficace ?",
  "options": [
    "Ajouter d'autres fichiers de tarifs, y compris des concurrents",
    "Passer à un modèle plus puissant et plus récent",
    "Renommer le GPT et changer son image de profil",
    "Couper la navigation web et exiger des citations des documents"
  ],
  "answer": 3,
  "explanation": "La navigation web laissée active et une consigne trop vague (« si besoin ») expliquent ce comportement. Restreindre les sources et imposer la citation règle le problème."
}
```


> ⚠️ **Piège fréquent** — Écrire « utilise les documents si besoin ». Le modèle répondra souvent de mémoire générale, avec des chiffres plausibles mais faux. Écrivez « **uniquement** à partir des documents » et imposez la citation : le modèle ne peut pas citer ce qu'il n'a pas lu.

## 4. Mise en place, outil par outil

> 🧭 **Pas à pas pour débutant** — Où trouver ces menus ? **Claude** (claude.ai) : barre latérale de gauche, entrée **Projets** (*Projects*), puis bouton **Nouveau projet** en haut à droite ; les instructions et les connaissances se règlent ensuite dans le panneau de droite du projet. **ChatGPT** : barre latérale, **GPT** (*Explorer les GPT*), puis **+ Créer** en haut à droite ; restez sur l'onglet *Configurer* plutôt que sur l'assistant de création guidé. **Gemini** : barre latérale, **Explorer les Gems** puis **Nouveau Gem**. Si le menu n'apparaît pas, votre offre ne propose pas encore la fonction (certaines sont réservées aux abonnements payants) : consultez l'aide de l'éditeur. Après chaque modification des instructions, ouvrez une **nouvelle conversation** pour tester : une conversation déjà ouverte garde les anciennes consignes.

### 4.1 Projet Claude

1. Dans Claude, menu *Projets → Nouveau projet*, nommez-le et décrivez-le (la description aide vos collègues à le retrouver).
2. *Instructions du projet* : collez le bloc de la section 3.
3. *Connaissances du projet* : ajoutez les fichiers (PDF, DOCX, TXT, Markdown…) ou collez des textes. Préférez des fichiers **propres** (un document = un sujet, titre explicite, version datée dans le nom : `CGV-2026-v3.pdf`). La jauge indique la part de capacité utilisée.
4. Selon votre offre, connectez des sources vivantes (Google Drive, SharePoint, connecteurs) — un connecteur relie le projet directement au dossier d'origine, qui reste ainsi à jour — plutôt que de déposer des copies qui vieilliront.
5. Testez avec cinq questions, dont une hors base et une qui exige une citation. Ajustez les instructions avant d'ajouter des documents : **une instruction corrige plus de choses qu'un fichier de plus**.
6. Sur les offres Team et Enterprise, partagez le projet à l'équipe : chacun y ouvre ses propres conversations avec les mêmes instructions et documents.

### 4.2 GPT personnalisé (ChatGPT)

1. *Explorer les GPT → Créer*. L'onglet *Configurer* donne accès au nom, à la description, aux **instructions**, aux **amorces de conversation** (les questions d'exemple proposées en boutons à l'utilisateur) et aux **connaissances** (fichiers).
2. Dans *Capacités*, désactivez la navigation web si vous voulez que l'assistant s'en tienne à vos documents (sinon il pourra aller chercher un tarif concurrent sur Internet au lieu du vôtre).
3. Les *Actions* permettent d'appeler une API externe (par exemple un webhook n8n de la leçon 48) : c'est le pont vers un vrai RAG quand les fichiers ne suffisent plus.
4. Publiez en **privé**, **par lien**, ou pour votre **espace de travail** (offres Team/Enterprise). Évitez le store public pour tout contenu interne. (Le « store » est la vitrine publique où n'importe quel utilisateur de ChatGPT peut trouver et utiliser votre GPT.)
5. Le nombre et la taille des fichiers de connaissances sont plafonnés (quelques dizaines de fichiers par GPT) : consultez l'aide OpenAI pour les valeurs en vigueur.

### 4.3 Gem (Gemini)

1. Dans Gemini, *Gems → Nouveau Gem* : nom, **instructions**, puis **fichiers** (envoi direct ou depuis Google Drive).
2. L'intérêt des Gems est l'intégration Workspace : un Gem nourri d'un dossier Drive partagé reste proche de vos documents de travail, et Gemini peut être appelé depuis Docs, Gmail ou Sheets selon votre offre.
3. Pour un corpus volumineux et des réponses sourcées passage par passage, NotebookLM (leçon 48) reste plus adapté qu'un Gem ; pour un assistant de rédaction « dans le ton de la maison » avec quelques documents de référence, le Gem suffit.

## 5. Les limites, et quand passer à un vrai RAG

| Limite | Projet / GPT / Gem | Vrai RAG (n8n, Dify, API) |
|---|---|---|
| **Taille** | Plafonds de fichiers et de capacité par projet ; au-delà, recherche intégrée non réglable | Illimité en pratique (base vectorielle) |
| **Fraîcheur** | Copies statiques, sauf connecteurs ; vous devez penser à remplacer le fichier | Ingestion automatique à chaque modification |
| **Droits d'accès** | Tout membre du projet voit tout | Filtres par métadonnées, un assistant par population |
| **Traçabilité** | Citations dans la réponse ; pas de journal structuré | Journaux, évaluations, scores (leçon 49) |
| **Intégration** | Conversation uniquement (plus les Actions pour les GPT) | Webhook, Slack, e-mail, CRM, agents |
| **Coût** | Inclus dans l'abonnement | Tokens + hébergement, mais prévisible |

Côté API, les mêmes éditeurs offrent une voie intermédiaire : chez Anthropic, la **Files API** (500 Mo par fichier, 1 To par organisation, nov. 2026) — une fonction pour développeurs qui stocke des fichiers chez Anthropic ; 1 To (téraoctet) = 1 000 Go — et le support PDF (jusqu'à 600 pages, 128 Mo par requête) permettent de charger des documents une fois, et la fonction **Citations** renvoie, pour chaque affirmation, le passage exact (`cited_text`, non facturé en sortie) — le champ qui contient la citation —. Chez OpenAI, l'outil *file search* est facturé 2,50 $ les 1 000 appels plus 0,10 $ par Go et par jour de stockage (1 Go gratuit, nov. 2026) ; chez xAI, les *Collections* se facturent 0,10 $ par Gio et par jour (un Gio, ou gibioctet, vaut environ 1,07 Go). Ces briques seront détaillées au niveau 3 ; retenez qu'entre « déposer un fichier dans un projet » et « monter une base vectorielle », il existe un palier.

> 💡 **Autrement dit** — Il existe trois niveaux, comme pour ranger des papiers : le **classeur posé sur le bureau** (Projet, GPT, Gem : simple, pour soi et quelques collègues), le **casier loué chez un prestataire**, que vos logiciels savent ouvrir (les fonctions « fichiers » des API, pour les développeurs), et la **salle d'archives** organisée avec index et droits d'accès (le vrai RAG des leçons 47 à 49). Vous n'avez pas à retenir les tarifs de ce paragraphe : seulement que le palier intermédiaire existe, et qu'il se met en place avec un développeur.

```mission
{
  "title": "Les limites du support PDF de l'API Claude",
  "url": "https://platform.claude.com/docs/en/build-with-claude/pdf-support",
  "steps": ["Ouvrez la page « PDF support » de la documentation Claude Platform", "Repérez la section des limites (taille de requête, nombre de pages)", "Notez la condition qui fait varier le nombre maximal de pages"],
  "question": "Quelle taille maximale de requête et quel nombre maximal de pages l'API Claude accepte-t-elle pour un PDF ?",
  "hint": "Le nombre maximal de pages dépend de la fenêtre de contexte du modèle utilisé.",
  "answer": "128 Mo par requête et jusqu'à 600 pages (limité à 100 pages pour les modèles dont la fenêtre de contexte est inférieure à 1 million de tokens) — relevé nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```


> 💡 **À retenir** — Passez à un vrai RAG dès que l'une de ces phrases devient vraie : « tout le monde ne doit pas tout voir », « les documents changent chaque semaine », « il faut prouver la qualité des réponses », « l'assistant doit agir dans un autre outil ».

## 6. Confidentialité : la règle des trois questions

Avant de déposer un document dans un projet, un GPT ou un Gem, posez-vous trois questions.

**1. Ce document peut-il quitter l'entreprise ?** Un assistant grand public est un service cloud : le fichier est stocké chez l'éditeur. Secrets d'affaires, données de santé, données RH nominatives, données clients couvertes par le secret professionnel (avocats, experts-comptables, médecins) : **non**, sauf offre d'entreprise avec contrat de traitement des données et analyse RGPD. Les fiches pratiques IA de la CNIL rappellent les obligations (base légale, minimisation, information des personnes).

**2. Sous quelle offre et avec quel réglage ?** Les offres professionnelles (Claude Team / Enterprise, ChatGPT Team / Enterprise, Google Workspace) prévoient en général que vos contenus ne servent pas à entraîner les modèles et offrent une administration centralisée ; sur une offre individuelle, ce comportement peut dépendre d'un **réglage de confidentialité** à vérifier dans les paramètres du compte et dans les conditions en vigueur de chaque éditeur. Ne vous fiez pas à ce que vous avez lu l'an dernier : relisez la page officielle le jour où vous déposez les documents.

**3. Ai-je minimisé ?** Déposez la grille tarifaire, pas l'export comptable complet ; la procédure, pas les e-mails qui l'ont fait naître ; une version anonymisée des exemples clients. Un assistant qui n'a pas la donnée ne peut pas la divulguer.

Et une quatrième question, pour les équipes : **qui a accès au projet ?** Un projet partagé à « toute l'organisation » avec les comptes rendus de direction est une fuite interne en attente. Un projet par population (atelier, commercial, direction), chacun avec ses documents, est la bonne pratique.

> 🔗 **Documentation officielle** — [Claude Help Center](https://support.claude.com/) 🇬🇧 pour les capacités et limites des projets selon l'offre ; [CNIL — fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) pour le cadre RGPD.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : dans un projet partagé, tout membre voit tous les documents déposés ; il vaut donc mieux créer un projet par population (atelier, commercial, direction).",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai : dans un projet, tout membre voit tout. La bonne pratique est un projet par population, chacun avec ses propres documents, et la minimisation de ce qui est déposé."
}
```

🎮 **Défi** — Une responsable commerciale a écrit dans son Projet : « Tu es mon assistant. Utilise les documents si besoin. » Repérez trois des cinq blocs d'instructions qui manquent, puis réécrivez la consigne en six lignes maximum avec une règle de refus et un format de citation. (Piste : il manque le périmètre et la liste des sources, le format, les interdits et le style ; « si besoin » doit devenir « uniquement à partir des documents ».)

## 🧪 Exercice pratique

**Consigne.** Choisissez un cas réel de votre activité (service client, onboarding, relecture de documents, support interne). Créez l'assistant correspondant **dans deux outils** parmi Projet Claude, GPT personnalisé et Gem, avec les **mêmes instructions** et les **mêmes 3 à 8 documents** (anonymisés). Rédigez les instructions selon les cinq blocs de la section 3. Posez-leur les 10 questions de votre jeu de test de la leçon 49 (ou un jeu équivalent) et notez-les sur la grille en quatre critères.

Rendez :
1. le bloc d'instructions final (une page maximum) ;
2. la liste des documents déposés, avec pour chacun la réponse aux trois questions de confidentialité ;
3. les deux grilles et un paragraphe de comparaison ;
4. votre décision argumentée : cet assistant reste-t-il en « connaissance embarquée » ou mérite-t-il un vrai RAG (leçons 48-49) ? Sur quel critère de la section 5 ?

**Critères de réussite.**
- Les instructions contiennent les cinq blocs, la liste explicite des documents, la règle de refus et le format de citation.
- Aucun document déposé ne contient de donnée personnelle non anonymisée ni d'information couverte par un secret, et chaque document est justifié.
- Les deux assistants atteignent 8/10 en exactitude avec sources citées, ou l'écart est expliqué (instructions, format des fichiers, mode de recherche de l'outil).
- La décision « embarqué ou RAG » cite au moins deux limites concrètes de la section 5.

<details>
<summary>Pistes de corrigé</summary>

Différences typiques : les trois outils citent correctement quand la citation est imposée dans les instructions ; les écarts viennent surtout des fichiers (un PDF scanné est ignoré en silence, un tableau est mal lu) et de la navigation web laissée active dans un GPT (réponses « d'Internet » au lieu des documents). La décision bascule vers un vrai RAG dès que le cas implique des droits différenciés (RH, direction) ou des documents mis à jour chaque semaine (tarifs, stocks).
</details>

## ✅ Auto-évaluation express

1. Qu'est-ce qui distingue le fonctionnement d'un Projet Claude avec 20 pages de documents de celui d'un projet avec 2 000 pages ?
2. Citez trois éléments que doit contenir un bloc d'instructions pour un assistant documentaire.
3. Une assistante de direction veut déposer dans un GPT personnalisé les fiches de paie de l'année pour « répondre aux questions des salariés ». Que lui répondez-vous ?

<details>
<summary>Réponses</summary>

1. À 20 pages, tout tient dans la fenêtre de contexte : le modèle lit l'intégralité à chaque question. À 2 000 pages, l'outil bascule sur une recherche dans les connaissances (RAG intégré) : seuls des passages sélectionnés sont lus, sans que vous contrôliez la sélection.
2. Le périmètre avec la liste explicite des sources, la règle « uniquement à partir des documents » avec refus explicite, le format de citation (et au choix : rôle, style, règle de résolution des contradictions, interdits).
3. Non : données personnelles et sensibles (rémunération) de tiers, finalité disproportionnée, et accès potentiellement partagé. La bonne réponse est un assistant qui connaît la **procédure** et les **règles générales** (convention collective, calendrier de paie), pas les bulletins ; les questions individuelles restent traitées par un humain, dans le SIRH. (Système d'information RH : le logiciel de gestion du personnel et de la paie.)
</details>

## 📚 Pour aller plus loin

- [Claude Academy — Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 — leçon « Introduction to projects » et usages par métier (badge gratuit).
- [Claude Academy — AI Fluency for small businesses](https://academy.claude.com/courses/ai-fluency-for-small-businesses) 🇬🇧 — cas d'usage TPE/PME de la connaissance embarquée.
- [Claude Help Center](https://support.claude.com/) 🇬🇧 — limites des projets, partage, réglages de confidentialité par offre.
- [Claude Platform — Files API](https://platform.claude.com/docs/en/build-with-claude/files) 🇬🇧 et [Citations](https://platform.claude.com/docs/en/build-with-claude/citations) 🇬🇧 — la version API de la connaissance embarquée, avec passages cités.
- [Claude Platform — Context windows](https://platform.claude.com/docs/en/build-with-claude/context-windows) 🇬🇧 — comprendre ce qui tient ou non dans la fenêtre.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) — le cadre RGPD avant tout dépôt de documents.

> ✅ **Si vous ne retenez que 3 choses** — 1. Projet Claude, GPT personnalisé et Gem font la même chose : un assistant qui démarre chaque conversation avec vos instructions et vos documents, sans rien installer. 2. Des instructions en cinq blocs (rôle, sources, format, interdits, style), avec « **uniquement** à partir des documents » et une citation obligatoire, corrigent plus de choses qu'un fichier de plus. 3. Avant de déposer un document : peut-il quitter l'entreprise, sous quelle offre, l'ai-je réduit au strict nécessaire, et qui aura accès au projet ?

> 🗺️ **Et maintenant ?** — Vous savez nourrir un assistant de vos documents ; le module 12 (L051) va plus loin en lui donnant des outils et des actions : GPT personnalisés avec actions, Projets Claude et Copilot Studio.
