---
id: L048
module: M11
level: N2
title: "Construire un RAG sans code : n8n, Dify, Flowise, NotebookLM"
minutes: 65
objectives:
  - "Construire dans n8n un pipeline d'ingestion (loader, splitter, embeddings, vector store) et un chat de consultation qui cite ses sources"
  - "Créer dans Dify (ou Flowise) une base de connaissances et une application de chat qui s'appuie dessus, avec le mode de recherche adapté"
  - "Monter en dix minutes un carnet NotebookLM à partir de documents internes et en exploiter les réponses sourcées"
  - "Comparer les trois approches (automatisation, plateforme d'applications, assistant personnel) selon le besoin, le volume et la confidentialité"
skills: ["C2.2"]
sources:
  - { title: "n8n Docs — Store and search data with vectors", url: "https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md", lang: "en" }
  - { title: "n8n Docs — Retrieve relevant context (RAG)", url: "https://docs.n8n.io/build/integrate-ai/understand-ai-components/retrieve-relevant-context.md", lang: "en" }
  - { title: "n8n Docs — LangChain in n8n (cluster nodes)", url: "https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md", lang: "en" }
  - { title: "n8n Docs — Chat Trigger", url: "https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.chattrigger.md", lang: "en" }
  - { title: "Dify — dépôt officiel GitHub", url: "https://github.com/langgenius/dify", lang: "en" }
  - { title: "Flowise — dépôt officiel GitHub", url: "https://github.com/FlowiseAI/Flowise", lang: "en" }
  - { title: "Langflow — dépôt officiel GitHub", url: "https://github.com/langflow-ai/langflow", lang: "en" }
  - { title: "Comparatif Dify vs Flowise vs Langflow 2026 (Future AGI)", url: "https://futureagi.com/blog/dify-vs-flowise-vs-langflow-2026/", lang: "en" }
  - { title: "NotebookLM (Google)", url: "https://notebooklm.google.com", lang: "fr" }
  - { title: "Ollama — Documentation", url: "https://docs.ollama.com", lang: "en" }
---

# Construire un RAG sans code : n8n, Dify, Flowise, NotebookLM

> ⏱ 65 min · 🎯 Niveau 2 · 📚 Module 11

## 🎯 Ce que vous saurez faire
- Monter, dans trois outils différents, un assistant qui répond **à partir de vos documents** et cite ses sources.
- Reconnaître les mêmes quatre temps du RAG (découper, vectoriser, chercher, générer) derrière trois interfaces très différentes.
- Choisir l'outil adapté : n8n quand le RAG s'insère dans une automatisation, Dify ou Flowise quand vous livrez une application de chat à des utilisateurs, NotebookLM quand vous voulez un assistant personnel en dix minutes.
- Savoir où vos documents sont stockés et traités dans chaque cas, pour décider en connaissance de cause.

> 🧭 **En clair** — Construire un RAG sans code, c'est donner à un nouvel employé très rapide un classeur de vos procédures, avec une consigne : « ne réponds qu'à partir de ce classeur, et dis-moi à quelle page tu as trouvé l'information ». Les trois outils de la leçon font ce même travail avec des styles différents. **NotebookLM**, c'est le classeur prêt à l'emploi : vous déposez vos documents, vous posez vos questions, rien à régler. **Dify** (ou Flowise), c'est le guichet d'accueil : vous ouvrez un service de questions-réponses à toute l'équipe, avec un historique. **n8n**, c'est le standardiste : il va chercher la réponse dans le classeur au milieu d'un processus (un e-mail qui arrive, un message Slack). Même mécanisme, trois usages.

## 0. Le fil rouge : la base « Procédures internes » de Menuiserie Lacombe

Tout au long de la leçon, nous travaillerons sur le même cas : **Menuiserie Lacombe**, artisan de 12 salariés à Angoulême. L'entreprise a 23 documents internes (PDF et DOCX) : procédures de pose, consignes de sécurité, grille tarifaire 2026, conditions générales de vente, fiches techniques des fournisseurs de quincaillerie. Objectif : qu'un apprenti ou une commerciale puisse demander « quelle vis pour une fixation sur béton cellulaire ? » ou « quel délai de rétractation pour un particulier ? » et obtenir une réponse sourcée. Préparez vos propres documents si vous préférez (5 à 20 fichiers suffisent), **sans données personnelles**.

Les trois tutoriels sont indépendants ; comptez 20 à 25 minutes chacun. Si vous n'avez le temps que pour un seul, faites celui qui correspond à votre usage (section 4).

## 1. Tutoriel A — n8n : le RAG au cœur d'une automatisation

### 1.1 Pourquoi n8n ?

Vous avez découvert au module 8 (leçon 35) les nœuds *cluster* de n8n : un nœud racine (Vector Store, AI Agent, chaîne Q&A) auquel se branchent des sous-nœuds (modèle, embeddings, loader, splitter, mémoire, outils). L'intérêt de n8n n'est pas d'être la meilleure interface de chat, c'est que le RAG **s'insère dans un flux** : ingestion automatique dès qu'un fichier arrive dans Google Drive, réponse dans Slack ou par e-mail, journalisation dans une Data Table.

### 1.2 Workflow 1 — Ingestion

> 🧭 **Pas à pas pour débutant** — Pas de Google Drive, ou n8n Cloud sans accès au disque ? Dans la liste ci-dessous, remplacez les étapes 1 et 2 par un déclencheur **On form submission** avec un champ *File*, exactement comme dans l'encadré « Pas à pas » de la leçon 35 : vous déposez chaque PDF dans le formulaire qui s'ouvre au clic sur *Execute workflow*. Pour les embeddings Mistral, la clé API se crée dans la console Mistral (*La Plateforme*, menu *API Keys*), puis se colle dans une credential *Mistral Cloud* de n8n. Contrôle : après l'exécution, le nœud Vector Store doit afficher un nombre d'items supérieur au nombre de fichiers (un item par morceau).

1. **Déclencheur.** Pour le tutoriel, un nœud *Manual Trigger* ; en production, un *Google Drive Trigger* (événement « fichier créé » dans le dossier « Procédures ») ou un *Schedule Trigger* hebdomadaire.
2. **Récupérer le fichier.** Nœud *Google Drive → Download* (ou *Read/Write Files from Disk* si n8n est auto-hébergé et que les PDF sont sur le serveur). La sortie est un fichier **binaire**.
3. **Nœud racine *Vector Store*** en mode **Insert Documents**. Pour un premier essai, choisissez *Simple Vector Store* (en mémoire, identifié par une *Memory Key* comme `lacombe-procedures`) ; pour conserver les données, *PGVector* (si votre n8n tourne avec PostgreSQL) ou *Qdrant*.
4. **Sous-nœud *Default Data Loader***. Type de données : *Binary* ; mode : *Load All Input Data*. Ajoutez les **métadonnées** : `titre` = `{{ $json.name }}`, `categorie` = `procedures` (ou une expression basée sur le dossier), `date_maj` = `{{ $now.toISODate() }}`. Ces champs ressortiront avec chaque passage trouvé : c'est ce qui permet de citer.
5. **Sous-nœud *Recursive Character Text Splitter*** branché au loader : *Chunk Size* 1 000, *Chunk Overlap* 150 (nous affinerons en leçon 49).
6. **Sous-nœud *Embeddings***. Trois options testées dans ce programme : *Embeddings OpenAI* (`text-embedding-3-small`), *Embeddings Mistral Cloud* (`mistral-embed`) ou *Embeddings Ollama* (`nomic-embed-text`, tout en local ; Ollama doit tourner et être joignable depuis n8n, par exemple `http://host.docker.internal:11434` sous Docker).
7. **Exécutez.** Le nœud Vector Store affiche le nombre de documents insérés. Ouvrez la sortie : chaque élément porte `pageContent` (le texte du morceau) et `metadata` (les métadonnées : titre, catégorie, date).

```
Manual Trigger ─► Google Drive (Download) ─► Vector Store (Insert Documents)
                                               ├─ Default Data Loader (binary + métadonnées)
                                               │    └─ Recursive Character Text Splitter (1000 / 150)
                                               └─ Embeddings Mistral Cloud (mistral-embed)
```

> ⚠️ **Piège fréquent** — Le *Simple Vector Store* vit dans la mémoire de l'instance n8n : **tout disparaît au redémarrage** et il n'est pas partagé entre workers en mode *queue* (configuration avancée où plusieurs copies de n8n se partagent le travail, vue en L037). Parfait pour apprendre, interdit en production.

> 💡 **Autrement dit** — Le workflow d'ingestion est un atelier de reliure : le *loader* ouvre le document, le *splitter* le découpe en fiches d'environ une page, l'*embedding* colle sur chaque fiche son « adresse » dans la bibliothèque du sens, et le *vector store* range les fiches sur les étagères. Les métadonnées, ce sont les mentions écrites au dos de chaque fiche (titre, date) qui permettront de citer la source.

```quiz
{
  "q": "Vous redémarrez votre serveur n8n et votre assistant ne trouve plus aucun document. Quelle est la cause la plus probable ?",
  "options": [
    "Le Simple Vector Store, gardé en mémoire, a été vidé",
    "Le modèle de langage a oublié ses consignes",
    "Le Chat Trigger a été désactivé par la mise à jour",
    "Les PDF ont été supprimés de Google Drive"
  ],
  "answer": 0,
  "explanation": "Le Simple Vector Store est conservé en mémoire : tout disparaît au redémarrage. Pour la production, utilisez PGVector ou Qdrant."
}
```


### 1.3 Workflow 2 — Consultation avec citation des sources

1. **Chat Trigger.** Ce nœud ouvre une interface de chat de test dans l'éditeur, et peut être rendu public (*Make Chat Publicly Available*) pour un lien partageable ou une intégration dans un site.
2. **AI Agent.** Branchez un *chat model* (Anthropic Claude Sonnet 5.5, OpenAI GPT-6.1 Terra, Mistral Small 4 ou un modèle Ollama local). Dans le *system message* :

```
Tu es l'assistant interne de Menuiserie Lacombe. Tu réponds UNIQUEMENT à partir
des passages renvoyés par l'outil « procedures_lacombe ». Pour chaque affirmation,
indique entre crochets le titre du document source (métadonnée `titre`).
Si les passages ne permettent pas de répondre, dis-le explicitement et propose
de contacter le responsable d'atelier. Ne devine jamais une valeur numérique.
```

3. **Outil Vector Store.** Ajoutez le même nœud *Vector Store* (même type, même *Memory Key* ou même collection) en mode **Retrieve Documents (As Tool for AI Agent)**, nom `procedures_lacombe`, description « Procédures, sécurité, tarifs et CGV de Menuiserie Lacombe », *Limit* 5. Branchez-lui **le même sous-nœud Embeddings** que l'ingestion.
4. **Mémoire** (facultatif) : *Simple Memory* pour que l'agent se souvienne des derniers échanges.
5. **Testez** dans le chat : « Quel délai de rétractation pour un particulier qui signe un devis à domicile ? » La réponse doit citer `[CGV 2026]` et donner 14 jours si c'est ce que disent vos CGV. Puis une question hors base : « Quel temps fera-t-il demain ? » Le bon comportement est un refus poli.

L'alternative à l'agent est la chaîne **Question and Answer Chain** avec un sous-nœud *Vector Store Retriever* : plus simple, plus déterministe, sans mémoire ni outils multiples ; recommandée pour un usage « une question, une réponse » par webhook.

```quiz
{
  "type": "mise_en_situation",
  "q": "Votre outil Vector Store de consultation utilise « Embeddings OpenAI » alors que l'ingestion a été faite avec « Embeddings Mistral Cloud ». Que va-t-il se passer ?",
  "options": [
    "Tout fonctionne, n8n traduit automatiquement",
    "Les réponses seront simplement un peu plus lentes",
    "Le Chat Trigger refusera de démarrer",
    "La recherche déraille : vecteurs d'espaces différents"
  ],
  "answer": 3,
  "explanation": "La question doit être vectorisée avec le même modèle que les documents. Branchez le même sous-nœud Embeddings sur l'ingestion et sur la consultation (règle vue en L047)."
}
```


> 🔗 **Documentation officielle** — [n8n — Retrieve relevant context (RAG)](https://docs.n8n.io/build/integrate-ai/understand-ai-components/retrieve-relevant-context.md) 🇬🇧 et [Chat Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.chattrigger.md) 🇬🇧. Les noms exacts des options évoluent avec les versions de n8n : fiez-vous à la documentation plutôt qu'à une capture d'écran.

## 2. Tutoriel B — Dify (ou Flowise) : livrer une application de chat

### 2.1 Les trois plateformes « builder » en nov. 2026

| Outil | Licence | Repères (recherche de ce programme) | Pour qui |
|---|---|---|---|
| **Dify** | « Dify Open Source License » (Apache 2.0 + conditions pour l'usage multi-locataire) | ~140 000 étoiles GitHub ; base de connaissances intégrée, workflows, MCP, gestion d'équipe (RBAC/SSO) | Équipe qui veut publier des applications de chat pour ses collaborateurs ou clients |
| **Flowise** | Apache 2.0 | ~52 600 étoiles ; composants LangChain / LlamaIndex glissés-déposés | Profils « bricoleurs » qui veulent voir chaque brique de la chaîne |
| **Langflow** | MIT | ~148 000 étoiles ; composants Python, export en serveur MCP ; service hébergé DataStax arrêté en avril 2026 | Proche de Flowise, plus orienté développeurs |

Les trois s'installent avec Docker en quelques minutes (voir les README des dépôts officiels) ; Dify propose aussi une version cloud hébergée. Nous détaillons Dify, dont la notion de **Knowledge** (base de connaissances) est la plus complète pour un non-développeur ; Flowise est traité en encadré.

```mission
{
  "title": "De quoi a besoin votre machine pour installer Dify ?",
  "url": "https://github.com/langgenius/dify",
  "steps": ["Ouvrez le dépôt GitHub langgenius/dify", "Faites défiler le README jusqu'à la section de démarrage rapide (Quick start)", "Repérez la configuration minimale exigée et la commande Docker de lancement"],
  "question": "Quelle configuration minimale (processeur, mémoire) le README de Dify demande-t-il, et avec quel outil lance-t-on l'installation ?",
  "hint": "La commande se lance depuis le dossier « docker » du dépôt.",
  "answer": "Au minimum 2 cœurs de processeur et 4 Go (4 GiB) de RAM ; lancement avec Docker Compose (`docker compose up -d` dans le dossier docker), puis ouverture de la page d'installation dans le navigateur (relevé nov. 2026 — vérifiez le README, il évolue) (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

### 2.2 Dify, étape par étape

> 🧭 **Pas à pas pour débutant** — Sans Docker, utilisez la **version cloud de Dify** : sur le site de Dify, cliquez sur *Get started* (ou *Start for free*), créez un compte avec votre e-mail ou votre compte Google ; une offre d'essai gratuite (*Sandbox*) suffit pour ce tutoriel, avec ses limites affichées sur la page tarifs. Les menus sont ensuite les mêmes : *Settings* (votre avatar en haut à droite) → *Model Provider*, puis cliquez sur la tuile du fournisseur (Anthropic, OpenAI, Mistral…) et collez votre clé API. Attention : en version cloud, vos documents sont traités par Dify ; n'y mettez que des documents non confidentiels.

1. **Connecter un fournisseur de modèles.** *Settings → Model Provider* : renseignez une clé Anthropic, OpenAI, Mistral ou Google, et un **modèle d'embeddings** (Dify demande les deux : un modèle de génération et un modèle d'embeddings ; Ollama peut servir pour les deux si vous voulez tout garder en local).
2. **Créer la base de connaissances.** Menu *Knowledge → Create Knowledge*. Importez les 23 fichiers de Menuiserie Lacombe (PDF, DOCX, TXT, Markdown acceptés — DOCX est le format des fichiers Word — ; Dify sait aussi synchroniser des sources web ou Notion).
3. **Régler le découpage.** Dify propose un mode automatique et un mode personnalisé : fixez un séparateur (`\n\n` pour couper aux paragraphes), une taille maximale (par exemple 800 tokens) et un chevauchement (10 à 15 %). Activez le nettoyage (suppression des espaces multiples, des URL si elles polluent). L'aperçu montre les morceaux : **lisez-en trois** et vérifiez qu'ils ont un sens seuls.
4. **Choisir l'indexation et la recherche.** « High Quality » (embeddings vectoriels) plutôt que « Economical » (mots-clés seulement) ; méthode de recherche **Hybrid** si disponible, avec *Top K* = 4 à 6 et un **seuil de score** (Top K : le nombre maximal de passages renvoyés ; seuil de score : la note de ressemblance minimale, entre 0 et 1, en dessous de laquelle un passage est écarté) (par exemple 0,5) sous lequel un passage n'est pas renvoyé. Vous pouvez activer un **reranking** si vous avez configuré un modèle de reclassement.
5. **Attendre l'indexation** (quelques minutes pour 23 documents), puis **tester la recherche** depuis l'onglet de test de la base : tapez « vis béton cellulaire » et regardez les passages renvoyés avec leur score. C'est le meilleur moment pour détecter un découpage raté.
6. **Créer l'application.** *Studio → Create from Blank → Chatbot* (mode basique). Dans *Orchestrate* : rédigez les instructions (reprenez le prompt système du tutoriel A, adapté), ajoutez la base dans **Context**, choisissez le modèle, cochez l'affichage des **citations** (Dify montre les passages sources sous chaque réponse).
7. **Tester, puis publier.** Le panneau de droite permet de converser ; *Publish* génère une page web, un script à intégrer dans l'intranet (un petit bout de code que votre prestataire web colle dans une page pour y faire apparaître la fenêtre de chat, appelée *widget*), et une API. Dans *Logs & Annotations*, vous relirez les vraies questions des utilisateurs : c'est votre futur jeu de test (leçon 49).

> 💡 **Autrement dit** — *Top K*, c'est le nombre de fiches que le bibliothécaire a le droit de rapporter à son bureau ; le **seuil de score**, c'est la règle « ne rapporte une fiche que si elle ressemble vraiment à la question ». Un seuil trop haut et il revient les mains vides ; trop bas et il rapporte des fiches hors sujet. Commencez à 0,5 et ajustez en regardant les scores dans l'onglet de test.

> 💡 **À retenir** — Dans Dify, **la base de connaissances et l'application sont deux objets distincts**. Une même base peut alimenter plusieurs applications (un chat pour l'atelier, un autre pour le commercial, avec des instructions différentes), et une application peut interroger plusieurs bases.

> 💡 **Autrement dit** — Dans Dify, la *Knowledge* est l'armoire à documents ; l'*App* est le guichet où l'on pose les questions. Plusieurs guichets (atelier, commercial) peuvent puiser dans la même armoire, chacun avec son propre ton et ses propres consignes.


### 2.3 Et avec Flowise ?

Dans Flowise, créez d'abord un **Document Store** : ajoutez un *loader* (PDF, Docx, dossier), un *text splitter* (Recursive Character, 1 000 / 150), prévisualisez les morceaux, puis « *Upsert* » vers un *vector store* (contraction d'*update* et *insert* : ajouter les morceaux nouveaux, mettre à jour les existants) (Chroma, Qdrant, pgvector…) avec un modèle d'embeddings. Créez ensuite un **Chatflow** : glissez un nœud *Conversational Retrieval QA Chain* (ou un *Agent* avec un outil *Retriever*), reliez-lui le modèle de chat, le *Document Store Retriever* et une mémoire. Le bouton de chat permet de tester ; l'icône « code » donne un widget à intégrer. L'avantage de Flowise est de **rendre visible chaque brique** du RAG, exactement comme dans le schéma de la leçon 47 ; l'inconvénient est qu'il faut en choisir et en relier davantage.

> ⚠️ **Piège fréquent** — Dans Dify comme dans Flowise, changer le modèle d'embeddings d'une base existante **sans la ré-indexer** rend la recherche incohérente (leçon 47). Les deux outils vous préviennent, mais pas toujours assez fort.

```mission
{
  "title": "Lancez Flowise en local : commande et adresse",
  "url": "https://github.com/FlowiseAI/Flowise",
  "steps": ["Ouvrez le dépôt GitHub FlowiseAI/Flowise", "Repérez la section de démarrage rapide (Quick Start) du README", "Notez la commande d'installation, la commande de lancement et l'adresse à ouvrir dans le navigateur"],
  "question": "Quelles commandes installent et démarrent Flowise, sur quelle adresse s'ouvre-t-il, et quelle est sa licence ?",
  "hint": "Flowise s'installe avec le gestionnaire de paquets de Node.js.",
  "answer": "`npm install -g flowise` puis `npx flowise start`, interface sur http://localhost:3000 ; une image Docker existe aussi ; licence Apache 2.0 (relevé nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```


## 3. Tutoriel C — NotebookLM : l'assistant personnel sourcé en dix minutes

### 3.1 Ce que c'est

**NotebookLM** est l'outil de Google (apparaissant aussi sous le nom « Gemini Notebook » dans certains supports Google de 2026 ; le nom commercial exact est à vérifier sur la page officielle) qui applique le principe du RAG à l'échelle d'un **carnet** : vous ajoutez vos sources, et un modèle Gemini ne répond **qu'à partir d'elles**, avec des citations cliquables renvoyant au passage exact. Il n'y a ni base vectorielle à choisir, ni découpage à régler : tout est caché. C'est à la fois sa force (zéro réglage) et sa limite (zéro réglage).

### 3.2 Pas à pas

1. Ouvrez NotebookLM avec un compte Google et créez un **nouveau carnet** « Lacombe — Procédures ».
2. **Ajoutez les sources** : fichiers PDF ou DOCX (glisser-déposer), documents Google Docs/Slides, pages web par URL, texte collé, et selon l'offre des vidéos YouTube ou des fichiers audio. Les limites du nombre de sources par carnet et de la taille de chaque source dépendent de votre offre (gratuite ou incluse dans un abonnement Google AI) : consultez la page d'aide officielle au moment de votre essai.
3. Attendez que chaque source affiche son **résumé automatique** : lisez-les, c'est un premier contrôle de qualité (un PDF scanné sans texte donnera un résumé vide : il faudra l'OCRiser avant (lui appliquer une reconnaissance de caractères, OCR, qui transforme l'image des pages en texte ; Adobe Acrobat ou de nombreux scanners le font)).
4. Dans le **chat**, posez la question « Quel délai de rétractation pour un particulier qui signe à domicile ? ». La réponse arrive avec des **numéros de citation** ; cliquez dessus pour voir le passage surligné dans la source.
5. Décochez des sources dans le panneau de gauche pour restreindre la recherche (par exemple seulement les fiches fournisseurs).
6. Exploitez les **fonctions « Studio »** : guide d'étude, FAQ, document de synthèse, et le résumé audio sous forme de dialogue entre deux voix (disponible en français). Pour un onboarding d'apprenti (l'accueil et la formation d'un nouvel arrivant), une FAQ générée à partir des 23 documents est un livrable immédiatement utile.
7. **Partagez** le carnet à des collègues (lecture ou édition) comme un Google Doc.

### 3.3 Ce qu'il faut savoir avant d'y mettre des documents d'entreprise

- Les données sont traitées par Google. La politique affichée par Google sur NotebookLM indique que vos sources et questions ne servent pas à entraîner les modèles ; pour un usage professionnel, préférez un compte **Google Workspace** administré par votre organisation, où ces engagements sont contractuels, et relisez les conditions en vigueur.
- Il n'y a pas d'API pour l'interroger depuis un workflow (l'édition Enterprise a une API, mais seulement pour gérer les carnets et leurs sources) : NotebookLM est un **outil de bureau** pour une personne ou une petite équipe, pas une brique d'automatisation.
- Vous ne contrôlez ni le découpage ni le nombre de passages : si une réponse est incomplète, votre seul levier est de **reformuler** ou de **réduire les sources actives**.

> 🔗 **Documentation officielle** — [NotebookLM](https://notebooklm.google.com) ; l'aide en ligne de Google détaille les limites par offre et les formats acceptés.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : NotebookLM est idéal pour brancher un RAG au milieu d'un workflow automatisé qui répond aux e-mails des clients.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : NotebookLM ne s'interroge pas depuis un workflow (l'API de l'édition Enterprise ne sert qu'à gérer carnets et sources). C'est un outil de bureau pour une personne ou une petite équipe. Pour l'automatisation, n8n est le bon choix."
}
```

## 4. Comparer et choisir

| Critère | n8n | Dify / Flowise | NotebookLM |
|---|---|---|---|
| Temps du premier résultat | 30-45 min | 20-30 min | 10 min |
| Qui utilise le résultat ? | Un workflow (Slack, e-mail, webhook, agent) | Des utilisateurs via une page de chat ou un widget | Vous-même et quelques collègues |
| Réglages du RAG | Tous (splitter, embeddings, base, k) | La plupart (découpage, hybride, seuil, reranking) | Aucun |
| Hébergement | Cloud n8n ou auto-hébergé ; données où vous voulez | Cloud Dify ou auto-hébergé (Docker) ; tout en local possible avec Ollama | Google uniquement |
| Citation des sources | À construire via les métadonnées et le prompt | Native (passages affichés) | Native (passages surlignés) |
| Mise à jour des documents | Automatisable (trigger Drive) | Synchronisation de sources web/Notion, ré-import manuel | Manuelle |
| Coût (nov. 2026) | Licence n8n (Community gratuite en auto-hébergé) — l'édition gratuite de n8n — + tokens | Licence gratuite en auto-hébergé + tokens | Gratuit avec limites ; plus avec un abonnement Google AI |

**Règle simple.** Besoin personnel ou test rapide → NotebookLM. Application de chat pour des utilisateurs, avec journaux et droits → Dify. Le RAG n'est qu'une étape d'un processus (qualifier un e-mail entrant, enrichir une fiche CRM, alimenter un agent) → n8n. Données confidentielles (RH, santé, avocats, experts-comptables) → n8n ou Dify **auto-hébergés avec Ollama** pour les embeddings et la génération.

> 💡 **À retenir** — Derrière les trois interfaces, c'est toujours le même mécanisme : des morceaux de texte, des vecteurs, une recherche de voisins, un modèle qui rédige. Ce que vous apprenez sur l'un se transpose sur les autres.

🎮 **Défi** — Trois demandes, trois outils, en une minute : (a) une avocate veut interroger seule, ce soir, les 12 PDF d'un dossier non confidentiel ; (b) une mutuelle veut un chatbot documentaire pour 60 conseillers, avec historique des questions, sans que rien ne sorte de ses serveurs ; (c) un e-commerçant veut qu'à chaque e-mail client, la réponse soit préparée à partir de sa FAQ puis déposée en brouillon dans Gmail. (Réponse : a → NotebookLM ; b → Dify auto-hébergé avec Ollama ; c → n8n.)

## 🧪 Exercice pratique

**Consigne.** Réalisez **au moins deux** des trois tutoriels avec un même jeu de 5 à 20 documents (les vôtres, anonymisés, ou un jeu de documents publics : par exemple des fiches pratiques du site service-public.fr sur le droit de rétractation, les délais de paiement et la garantie légale de conformité). Puis préparez **cinq questions** dont vous connaissez la réponse exacte, dont **une question hors sujet** (la bonne réponse est « je ne sais pas »).

Pour chaque outil, notez dans un tableau : la réponse obtenue, si elle est juste, si la source citée est la bonne, et le temps de mise en place.

**Critères de réussite.**
- Les deux assistants répondent correctement à au moins 3 des 4 questions « dans la base » et refusent la question hors sujet.
- Chaque réponse juste cite le bon document (titre ou passage).
- Vous êtes capable d'expliquer en deux phrases pourquoi un outil a mieux répondu que l'autre (découpage, k, modèle, qualité de l'extraction du PDF…).
- Dans n8n ou Dify, le modèle d'embeddings est **le même** pour l'ingestion et la consultation, et il est noté dans une Sticky Note ou la description de la base.

<details>
<summary>Pistes de corrigé</summary>

Les écarts typiques observés : NotebookLM répond souvent mieux « du premier coup » (découpage et recherche optimisés par Google) mais ne permet rien d'autre ; n8n avec Simple Vector Store et k = 5 répond bien aux questions factuelles mais peut rater une réponse répartie sur deux pages (augmentez l'overlap ou k) ; Dify en mode hybride retrouve mieux les références exactes (« article 12 ») que le vectoriel seul. Une question hors sujet acceptée par l'agent n8n signale un prompt système trop permissif : ajoutez la consigne explicite de refus.
</details>

## ✅ Auto-évaluation express

1. Dans n8n, pourquoi faut-il brancher un sous-nœud Embeddings à la fois sur le Vector Store en mode *Insert* et sur celui en mode *Retrieve* ?
2. Dans Dify, quelle différence entre une *Knowledge* et une *App* ?
3. Citez deux limites de NotebookLM pour un usage d'entreprise.

<details>
<summary>Réponses</summary>

1. Parce que la question doit être vectorisée **avec le même modèle** que les documents pour que la comparaison ait un sens ; chaque nœud Vector Store a besoin de connaître ce modèle.
2. La *Knowledge* est la base documentaire indexée (réutilisable par plusieurs applications) ; l'*App* est l'interface de chat avec ses instructions, son modèle et ses réglages, qui référence une ou plusieurs bases dans *Context*.
3. Pas d'API ni d'intégration dans un workflow ; aucun contrôle sur le découpage, la recherche ou l'hébergement (Google uniquement) ; limites de sources par carnet selon l'offre.
</details>

## 📚 Pour aller plus loin

- [n8n — Store and search data with vectors](https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md) 🇬🇧 — la page de référence sur les nœuds Vector Store et Embeddings.
- [n8n — LangChain in n8n](https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md) 🇬🇧 — comprendre nœuds racines et sous-nœuds.
- [Dify — dépôt GitHub](https://github.com/langgenius/dify) 🇬🇧 — installation Docker Compose et lien vers la documentation.
- [Flowise — dépôt GitHub](https://github.com/FlowiseAI/Flowise) 🇬🇧 — installation et exemples de chatflows.
- [Langflow — dépôt GitHub](https://github.com/langflow-ai/langflow) 🇬🇧 — l'alternative MIT, exportable en serveur MCP.
- [Dify vs Flowise vs Langflow 2026 (Future AGI)](https://futureagi.com/blog/dify-vs-flowise-vs-langflow-2026/) 🇬🇧 — comparatif détaillé des trois builders.
- [NotebookLM](https://notebooklm.google.com) — pour créer votre premier carnet.
- [Ollama — Documentation](https://docs.ollama.com) 🇬🇧 — faire tourner embeddings et génération en local pour un RAG 100 % confidentiel.

> ✅ **Si vous ne retenez que 3 choses** — 1. NotebookLM pour un besoin personnel en dix minutes ; Dify (ou Flowise) pour offrir un chat documentaire à une équipe ; n8n quand la recherche dans vos documents n'est qu'une étape d'un processus automatisé. 2. Derrière les trois, le même mécanisme : découper, vectoriser, chercher les passages voisins, faire rédiger avec citation des sources. 3. Testez toujours avec quelques questions dont vous connaissez la réponse, dont une hors sujet, et ne mettez dans un service cloud que des documents que vous avez le droit d'y envoyer.

> 🗺️ **Et maintenant ?** — Votre premier assistant documentaire répond ; la leçon L049 vous apprend à vérifier qu'il répond *juste*, en réglant le découpage des documents et en mesurant sa qualité avec un jeu de questions de référence.
