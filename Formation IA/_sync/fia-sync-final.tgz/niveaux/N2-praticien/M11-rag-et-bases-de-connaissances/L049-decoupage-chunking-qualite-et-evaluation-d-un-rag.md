---
id: L049
module: M11
level: N2
title: "Découpage (chunking), qualité et évaluation d'un RAG"
minutes: 60
objectives:
  - "Choisir une stratégie de découpage (taille, chevauchement, respect de la structure) adaptée à un type de document"
  - "Concevoir des métadonnées utiles (source, date, catégorie, droits) et les exploiter pour citer et filtrer"
  - "Construire un jeu de 10 questions test et une grille d'évaluation, puis mesurer la qualité d'un RAG avant et après un réglage"
  - "Diagnostiquer une mauvaise réponse en localisant la panne : extraction, découpage, recherche ou génération"
skills: ["C2.2"]
sources:
  - { title: "Claude Platform — Define success criteria and build evals", url: "https://platform.claude.com/docs/en/test-and-evaluate/develop-tests", lang: "en" }
  - { title: "n8n Docs — Understand why to test AI workflows (Evaluations)", url: "https://docs.n8n.io/build/integrate-ai/test-and-improve-ai-workflows/understand-why-to-test.md", lang: "en" }
  - { title: "n8n Docs — Evaluation node", url: "https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluation.md", lang: "en" }
  - { title: "Ragas — dépôt officiel GitHub", url: "https://github.com/vibrantlabsai/ragas", lang: "en" }
  - { title: "DeepEval vs Ragas vs promptfoo 2026 (QA Skills)", url: "https://qaskills.sh/blog/deepeval-vs-ragas-vs-promptfoo-2026", lang: "en" }
  - { title: "Claude Academy — Building with the Claude API (module RAG & agentic search)", url: "https://academy.claude.com/courses/building-with-the-claude-api", lang: "en" }
  - { title: "Mistral AI — OCR 4.1", url: "https://docs.mistral.ai/models/ocr-4-1", lang: "en" }
---

# Découpage (chunking), qualité et évaluation d'un RAG

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 11

## 🎯 Ce que vous saurez faire
- Expliquer pourquoi un RAG qui « répond à côté » est presque toujours un problème de **recherche**, pas de modèle.
- Régler taille et chevauchement des morceaux selon le document : FAQ, contrat, procédure, tableau.
- Décrire des métadonnées qui permettent de citer, filtrer et retirer un document périmé.
- Écrire 10 questions test, noter les réponses sur une grille en 4 critères, et obtenir un score comparable d'une version à l'autre.
- Nommer les métriques standard (fidélité, pertinence, rappel du contexte) et les outils qui les automatisent.

> 🧭 **En clair** — Un RAG, c'est une chaîne de quatre maillons : lire le document, le découper en fiches, retrouver les bonnes fiches, rédiger la réponse. Quand la réponse est fausse, c'est comme une recette ratée : avant d'accuser le chef (le modèle de langage), vérifiez les ingrédients qu'on lui a donnés (les passages retrouvés). Le découpage, c'est l'art de couper vos documents en fiches qui ont un sens seules, comme on découpe un livre de recettes en fiches « une recette par fiche » plutôt qu'au hasard tous les 1 000 caractères. Enfin, on ne règle rien « au feeling » : on prépare 10 questions dont on connaît la réponse, on note, on change un réglage, on renote.

## 1. Un RAG se règle, il ne se devine pas

Dans la leçon 48, votre assistant Menuiserie Lacombe a sans doute bien répondu à trois questions sur quatre. Le quart restant est le sujet de cette leçon. Un RAG est une chaîne de quatre maillons (extraire le texte, découper, chercher, générer) et **une réponse fausse vient du maillon le plus faible**. L'erreur classique des débutants est de changer de modèle de langage (« essayons Opus plutôt que Sonnet ») alors que le modèle n'a jamais reçu le bon passage. Diagnostic avant remède :

| Symptôme | Maillon probable | Vérification rapide |
|---|---|---|
| « Je ne trouve pas cette information » alors qu'elle est dans un PDF | Extraction (PDF scanné, tableau aplati, colonnes mélangées) | Ouvrez le texte extrait d'un morceau : est-il lisible ? |
| Réponse partielle (la moitié d'une procédure) | Découpage (l'idée est coupée en deux morceaux, un seul est renvoyé) | Cherchez le passage dans la base : sur combien de morceaux est-il réparti ? |
| Réponse sur le mauvais document (le tarif 2025 au lieu de 2026) | Recherche / métadonnées (pas de filtre sur la date, doublons) | Regardez les 5 passages renvoyés et leurs métadonnées |
| Bonne source citée, mais réponse inventée ou déformée | Génération (prompt trop permissif, modèle trop petit, trop de passages) | Relisez le passage et la réponse côte à côte |

> 💡 **À retenir** — Avant de toucher à quoi que ce soit, **regardez les passages renvoyés** par la recherche. Tous les outils de la leçon 48 les affichent (sortie du nœud Vector Store dans n8n, onglet de test de la base dans Dify, citations dans NotebookLM).

```quiz
{
  "type": "mise_en_situation",
  "q": "Votre assistant répond « je ne trouve pas cette information » alors que la réponse figure dans un vieux contrat scanné. Quel maillon suspectez-vous d'abord ?",
  "options": [
    "L'extraction : sans OCR, un scan n'a pas de texte",
    "La génération : il faut un modèle plus gros",
    "Le nombre de passages k, trop élevé",
    "La mémoire de conversation, saturée par l'historique"
  ],
  "answer": 0,
  "explanation": "Un PDF scanné est une image : sans reconnaissance optique de caractères (OCR), aucun texte n'est extrait, donc rien ne peut être retrouvé. Changer de modèle n'y changerait rien."
}
```


## 2. Le maillon zéro : extraire un texte propre

Un PDF n'est pas du texte, c'est un dessin de texte. Trois cas :
- **PDF natif** (exporté de Word) : l'extraction est bonne, sauf pour les tableaux (les cellules deviennent une ligne continue) et les en-têtes/pieds de page répétés (qui polluent chaque morceau : retirez-les).
- **PDF scanné** (photocopie, fax, ancien contrat) : aucun texte extractible. Il faut une **reconnaissance optique de caractères** (OCR). Mistral propose par exemple OCR 4.1 à 4 $ les 1 000 pages (nov. 2026) ; beaucoup d'outils bureautiques en ont une intégrée.
- **Tableaux et grilles tarifaires** : convertissez-les en Markdown ou en phrases (Markdown : façon d'écrire un tableau en texte simple, avec des barres verticales `|` entre les colonnes) (« Vis béton cellulaire 6×60 : 0,12 € HT l'unité ») avant l'ingestion ; un tableau découpé en morceaux de 1 000 caractères perd ses en-têtes de colonnes.

> 🧭 **Pas à pas pour débutant** — Pour convertir un tableau sans rien connaître au Markdown : copiez le tableau depuis Excel ou Word, collez-le dans Claude ou ChatGPT avec la consigne « Transforme ce tableau en une phrase par ligne, en répétant le nom de chaque colonne, par exemple : Vis béton cellulaire 6×60 : 0,12 € HT l'unité. » Relisez le résultat (surtout les chiffres), collez-le dans un document Word ou un fichier texte, et ingérez ce fichier à la place du tableau d'origine. N'envoyez pas ainsi un tableau contenant des données confidentielles (salaires, données clients) à un service en ligne.

Règle pratique : pour chaque **type** de document, ingérez-en un, ouvrez trois morceaux au hasard, et lisez-les comme si vous étiez le modèle. Si vous ne comprenez pas un morceau seul, le modèle non plus.

```mission
{
  "title": "Combien coûte l'OCR de 1 000 pages chez Mistral ?",
  "url": "https://docs.mistral.ai/models/ocr-4-1",
  "steps": ["Ouvrez la fiche du modèle OCR 4.1 dans la documentation Mistral", "Repérez la description de ce que fait le modèle (types de documents acceptés)", "Cherchez le prix, exprimé par lot de pages"],
  "question": "Combien coûte le traitement de 1 000 pages avec Mistral OCR 4.1, et combien vous coûterait un fonds de 12 000 pages d'anciens contrats scannés ?",
  "hint": "Le prix est donné pour 1 000 pages ; multipliez ensuite par 12.",
  "answer": "Environ 4 $ les 1 000 pages, soit environ 48 $ pour 12 000 pages (relevé nov. 2026 — vérifiez la page de tarifs Mistral avant de budgéter).",
  "xp": 15
}
```

## 3. Le découpage (chunking)

### 3.1 Pourquoi découper ?

> 💡 **Autrement dit** — Un embedding résume un texte en une seule « adresse ». Si vous résumez un chapitre entier en une adresse, elle devient vague (« quelque part dans le quartier de la menuiserie ») et ne correspond plus à aucune question précise. Des morceaux plus courts donnent des adresses plus précises — à condition que chaque morceau contienne encore une idée complète.


Deux raisons. La première est technique : un embedding résume un texte en un seul vecteur ; plus le texte est long, plus le vecteur devient un « moyen » flou qui ne ressemble plus à aucune question précise. La seconde est économique : on n'envoie au modèle que les morceaux utiles. Le découpage cherche donc un équilibre entre **morceaux assez petits pour être précis** et **assez grands pour contenir une idée complète**.

### 3.2 Les trois réglages

| Réglage | Ce qu'il fait | Point de départ |
|---|---|---|
| **Taille** (*chunk size*) | Longueur d'un morceau, en caractères ou en tokens (1 token ≈ 4 caractères en français) | 800-1 500 caractères (200-400 tokens) |
| **Chevauchement** (*overlap*) | Caractères repris entre deux morceaux consécutifs pour qu'une phrase coupée reste trouvable | 10-20 % de la taille |
| **Séparateurs** | Où couper en priorité : paragraphe (`\n\n`), puis ligne, puis phrase, puis mot | Le *Recursive Character Text Splitter* le fait par défaut |

### 3.3 Adapter au document

| Type de document | Stratégie recommandée | Pourquoi |
|---|---|---|
| **FAQ, fiches « question/réponse »** | Un morceau = une paire question/réponse (coupez sur un séparateur explicite, par exemple `###`) | La question de l'utilisateur ressemble à la question de la fiche : l'embedding sera très proche |
| **Procédures, modes opératoires** | Morceaux moyens (1 000-1 500 caractères) coupés aux titres de section ; conservez le titre de section au début de chaque morceau | Une étape sans son titre perd son sens (« serrez à 25 N·m » : de quoi ?) — newtons-mètres, l'unité de couple de serrage — |
| **Contrats, CGV, accords d'entreprise** | Un morceau = un article ou un alinéa, avec son numéro | Les questions juridiques visent un article précis ; le numéro permet la recherche lexicale |
| **Tableaux, tarifs** | Une ligne = un morceau en phrase, ou tableau Markdown complet si court | Les colonnes doivent rester attachées à leurs en-têtes |
| **E-mails, tickets de support** | Un message = un morceau, avec objet, date et auteur en métadonnées | La conversation entière mélangerait plusieurs sujets |

Une technique plus avancée, enseignée dans le module RAG du cours « Building with the Claude API » (Claude Academy), est la **récupération contextuelle** (*contextual retrieval*) : avant de vectoriser chaque morceau, on demande à un modèle de lui ajouter une ou deux phrases de contexte (« Ce passage provient des CGV 2026 de Menuiserie Lacombe, section Rétractation »). Le morceau devient compréhensible seul, et la recherche s'améliore nettement. Dify et n8n permettent de le faire avec une étape de génération avant l'insertion ; c'est un bon projet de niveau 3.

```mermaid
flowchart LR
  A["Document : CGV 2026"] --> B["Découpage<br/>1 article = 1 morceau"]
  B --> C["Ajout de contexte<br/>« Ce passage provient des CGV 2026,<br/>section Rétractation »"]
  C --> D["Embedding"] --> E["Base vectorielle<br/>+ métadonnées<br/>(source, date, type)"]
```


> ⚠️ **Piège fréquent** — Utiliser le même réglage pour tous les documents. Une base « FAQ + CGV + tarifs » mérite **trois ingestions** avec trois réglages, vers la même base vectorielle, chaque morceau portant une métadonnée `type`.

```quiz
{
  "q": "Pour des conditions générales de vente, quelle stratégie de découpage est recommandée ?",
  "options": [
    "Des morceaux fixes de 300 caractères, sans tenir compte des articles",
    "Un morceau par article ou alinéa, avec son numéro",
    "Un seul morceau pour tout le document",
    "Une phrase par morceau, sans chevauchement"
  ],
  "answer": 1,
  "explanation": "Les questions juridiques visent un article précis ; garder un article par morceau, avec son numéro, préserve le sens et permet aussi la recherche lexicale sur « article 12 »."
}
```


## 4. Les métadonnées : ce qui rend un RAG gouvernable

Un morceau sans métadonnées est un texte orphelin : impossible de dire d'où il vient, s'il est encore valable, ni qui a le droit de le lire. Les champs qui valent la peine dans une PME :

| Champ | Exemple | Sert à |
|---|---|---|
| `source` | `CGV-2026-v3.pdf` | Citer, et **supprimer** tous les morceaux d'un document remplacé |
| `titre` | « Conditions générales de vente 2026 » | Citation lisible dans la réponse |
| `section` | « Article 7 — Rétractation » | Citation précise, meilleur contexte |
| `date_maj` | `2026-09-12` | Filtrer les versions périmées, afficher la fraîcheur |
| `type` | `cgv`, `procedure`, `tarif`, `faq` | Restreindre la recherche (« ne cherche que dans les tarifs ») |
| `service` ou `confidentialite` | `atelier`, `direction`, `rh-confidentiel` | Ne renvoyer que ce que l'utilisateur a le droit de voir |
| `url` | lien intranet | Permettre à l'utilisateur d'ouvrir l'original |

Deux usages concrets :
1. **Citer** : avec `titre` et `section` dans chaque passage, le prompt système « indique entre crochets le titre et la section de la source » produit des réponses vérifiables.
2. **Filtrer** : Qdrant, pgvector, Dify et le nœud Vector Store de n8n acceptent un filtre sur les métadonnées (par exemple `type = tarif` et `date_maj ≥ 2026-01-01`). La recherche sémantique ne se fait alors que parmi les morceaux autorisés : c'est **plus précis et plus sûr** qu'espérer que le modèle « comprenne » qu'il ne doit pas utiliser l'ancien tarif.

> 💡 **À retenir** — La mise à jour d'un document, c'est : supprimer les morceaux où `source = ancien fichier`, ingérer le nouveau. Sans métadonnée `source`, vous ne pouvez pas supprimer proprement, et les deux versions cohabitent.

## 5. Évaluer simplement : 10 questions, 4 critères, un score

### 5.1 Pourquoi un jeu de test

Sans mesure, chaque réglage est une impression. Avec 10 questions et une grille, vous saurez si passer de 1 000 à 600 caractères a aidé ou nui, et vous pourrez le prouver à votre direction. La documentation Claude sur les évaluations recommande des critères **spécifiques et mesurables**, et distingue trois façons de noter : comparaison exacte (*exact match*) — la réponse doit être identique, mot pour mot, à la référence —, similarité (par exemple cosinus entre la réponse et la référence), et **notation par un modèle** (*LLM-as-judge*) sur une échelle. À notre niveau, nous commençons par une notation **humaine**, la plus fiable et la plus pédagogique.

### 5.2 Construire le jeu de 10 questions

Prenez les vraies questions de vos utilisateurs (journaux Dify, historique Slack, boîte « questions » de l'intranet) et couvrez volontairement :

| # | Type de question | Exemple Menuiserie Lacombe | Réponse attendue (référence) | Source attendue |
|---|---|---|---|---|
| 1 | Fait simple | Quel délai de rétractation pour un particulier démarché à domicile ? | 14 jours | CGV 2026, art. 7 |
| 2 | Fait chiffré | Prix HT de la vis béton cellulaire 6×60 ? | 0,12 € HT | Tarif 2026 |
| 3 | Procédure (plusieurs étapes) | Comment préparer un chantier de pose de fenêtre ? | Les 5 étapes de la fiche | Procédure POSE-03 |
| 4 | Reformulation libre | Un client veut annuler après signature, il a quels droits ? | 14 jours si vente hors établissement | CGV 2026, art. 7 |
| 5 | Référence exacte | Que dit l'article 12 des CGV ? | Clause de réserve de propriété | CGV 2026, art. 12 |
| 6 | Réponse répartie sur deux documents | Quel EPI pour la découpe de panneaux MDF, et où les commander ? (EPI : équipements de protection individuelle ; MDF : panneau de fibres de bois) | Masque FFP2 + lunettes ; fournisseur X | Sécurité SEC-01 + Fournisseurs |
| 7 | Version à jour | Quel est le tarif horaire de pose en 2026 ? | 52 € HT (pas 48 € de 2025) | Tarif 2026 |
| 8 | Question piège (information absente) | Quel est le tarif pour une pose de piscine ? | « Information absente de la base » | aucune |
| 9 | Question hors sujet | Quelle est la capitale de l'Australie ? | Refus poli | aucune |
| 10 | Question avec faute ou jargon | « delai retractation particlier » | 14 jours | CGV 2026, art. 7 |

Les questions 8 et 9 sont indispensables : un assistant qui **invente** un tarif de piscine est plus dangereux qu'un assistant qui se tait.

### 5.3 La grille de notation

Pour chaque question, notez 0 ou 1 sur quatre critères :

| Critère | Question à se poser | 1 point si… |
|---|---|---|
| **Exactitude** | La réponse est-elle conforme à la référence ? | Fait juste, chiffre juste, étapes complètes |
| **Source** | Le bon document est-il cité ? | Titre (et section) attendus présents |
| **Fidélité** | La réponse ne contient-elle **que** ce que disent les passages ? | Aucune information ajoutée, aucune extrapolation (rien de « déduit » au-delà de ce qui est écrit) |
| **Comportement** | L'assistant refuse-t-il quand il doit refuser, et répond-il quand il doit répondre ? | Refus sur Q8-Q9, réponse sur les autres |

Score = total sur 40, exprimé en pourcentage. Le référentiel de ce programme (compétence C2.2) attend **8 bonnes réponses sur 10 avec sources citées** : visez ≥ 80 % en exactitude **et** ≥ 80 % en source. Tenez un tableau de versions :

```
Version | Réglage                          | Exact. | Source | Fidél. | Compt. | Total
--------|----------------------------------|--------|--------|--------|--------|------
v1      | 1000/150, k=5, vectoriel         |  7/10  |  6/10  |  9/10  |  8/10  | 75 %
v2      | 800/120, k=5, hybride            |  9/10  |  9/10  |  9/10  |  8/10  | 88 %
v3      | v2 + prompt refus explicite      |  9/10  |  9/10  | 10/10  | 10/10  | 95 %
```

Changez **un seul réglage à la fois** entre deux versions, sinon vous ne saurez pas lequel a agi.

> 💡 **Autrement dit** — **Exactitude** et **fidélité** ne sont pas la même chose. Exactitude : « la réponse est-elle juste ? ». Fidélité : « l'assistant s'en est-il tenu à ce que disent les documents ? ». Un élève peut donner la bonne date sans l'avoir lue dans le texte (exact mais pas fidèle : il a eu de la chance, il pourrait inventer la prochaine fois), ou recopier fidèlement un passage périmé (fidèle mais pas exact : c'est la base qu'il faut corriger).

### 5.4 Automatiser quand le jeu grandit

Dix questions se notent à la main en vingt minutes. À cinquante, il faut de l'aide :
- **n8n** propose des nœuds *Evaluation Trigger* / *Evaluation* : une feuille Google Sheets contient questions et réponses attendues, le workflow est exécuté sur chaque ligne et les résultats (y compris une note donnée par un modèle juge) reviennent dans la feuille.
- **Ragas** (Apache 2.0) a popularisé les métriques standard du RAG : *faithfulness* (fidélité aux passages), *answer relevancy* (pertinence de la réponse), *context precision* et *context recall* (la recherche a-t-elle renvoyé les bons passages, et tous ?), *noise sensitivity* (la résistance aux passages hors sujet mélangés aux bons). Ce sont exactement nos quatre critères, calculés par un modèle juge.
- **DeepEval** et **promptfoo** (ce dernier racheté par OpenAI en mars 2026) font la même chose dans un style « tests unitaires » ou « fichier YAML » (deux façons de programmeur de décrire des tests : petites vérifications automatiques, ou fichier de configuration texte). Vous les manipulerez au niveau 3.

Pour garder le réflexe du calcul, voici un script qui lit votre grille au format CSV (CSV : un tableau enregistré en texte, valeurs séparées par des virgules ; Excel sait l'ouvrir et l'enregistrer) et affiche le score par critère (Python 3.12, aucune dépendance) :

```python
# score_rag.py — calcule le score d'une grille d'évaluation RAG
# Format attendu du CSV : id,exactitude,source,fidelite,comportement (valeurs 0 ou 1)
import csv
import sys

chemin = sys.argv[1] if len(sys.argv) > 1 else "grille.csv"
criteres = ["exactitude", "source", "fidelite", "comportement"]
totaux = {c: 0 for c in criteres}
nb = 0

with open(chemin, newline="", encoding="utf-8") as f:
    for ligne in csv.DictReader(f):
        nb += 1
        for c in criteres:
            totaux[c] += int(ligne[c])

for c in criteres:
    print(f"{c:<13}: {totaux[c]}/{nb}  ({100 * totaux[c] / nb:.0f} %)")
global_pts = sum(totaux.values())
print(f"{'TOTAL':<13}: {global_pts}/{nb * len(criteres)}  ({100 * global_pts / (nb * len(criteres)):.0f} %)")
```

> 🔗 **Documentation officielle** — [Claude Platform — Define success criteria and build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) 🇬🇧 (critères, notation exacte / cosinus / modèle juge) et [n8n — Understand why to test AI workflows](https://docs.n8n.io/build/integrate-ai/test-and-improve-ai-workflows/understand-why-to-test.md) 🇬🇧.

> 🧭 **Pas à pas pour débutant** — La grille du script Python ci-dessus, dans Excel, sans Python : ligne 1, les en-têtes `question`, `exactitude`, `source`, `fidelite`, `comportement` ; lignes 2 à 11, vos 10 questions avec des 0 ou des 1. En ligne 12, sous chaque critère, tapez `=SOMME(B2:B11)` (puis recopiez vers la droite) : vous obtenez le score sur 10. Dans une cellule à part, `=SOMME(B2:E11)/40` affiché au format pourcentage donne le score total. Dupliquez l'onglet pour chaque version (v1, v2, v3) : la comparaison est immédiate.

```mission
{
  "title": "Les trois façons de noter une évaluation selon la documentation Claude",
  "url": "https://platform.claude.com/docs/en/test-and-evaluate/develop-tests",
  "steps": ["Ouvrez la page « Define success criteria and build evaluations » de la documentation Claude", "Repérez la partie consacrée à la notation des résultats (grading)", "Listez les grandes familles de notation et leurs avantages"],
  "question": "Quelles sont les trois grandes familles de notation décrites, et laquelle est la plus rapide mais la moins souple ?",
  "hint": "L'une repose sur du code, une autre sur des personnes, la troisième sur un modèle.",
  "answer": "Notation par code (comparaison exacte, similarité cosinus…), notation humaine et notation par un modèle (LLM-as-judge). La notation par code est la plus rapide et la plus fiable mais manque de nuance pour les réponses ouvertes (relevé nov. 2026).",
  "xp": 15
}
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour gagner du temps, on peut changer à la fois la taille des morceaux, le mode de recherche et le prompt entre deux versions, puis comparer les scores.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : en changeant plusieurs réglages à la fois, vous ne saurez pas lequel a amélioré (ou dégradé) le score. Un seul réglage par version."
}
```

## 6. Les réglages qui font le plus de différence (par ordre d'effet)

1. **Qualité d'extraction** : un PDF scanné ou un tableau aplati annule tout le reste.
2. **Découpage respectueux de la structure** (titres conservés, un article = un morceau).
3. **Recherche hybride** quand les questions contiennent des références exactes.
4. **Filtres par métadonnées** (date, type) pour éliminer les versions périmées.
5. **k** (nombre de passages) : 4-6 ; au-delà, surveillez la fidélité.
6. **Prompt de génération** : consigne de refus explicite, format de citation imposé.
7. **Modèle de génération** : en dernier. Un modèle de taille moyenne avec de bons passages bat un modèle géant avec les mauvais.

🎮 **Défi** — Votre assistant répond « 48 € HT » à la question « tarif horaire de pose en 2026 », alors que la grille 2026 dit 52 €. Les passages renvoyés contiennent les deux grilles, 2025 et 2026. Quel maillon est en cause, et quels deux réglages de cette leçon corrigent le problème ? (Réponse : la recherche / les métadonnées ; ajouter une métadonnée `date_maj` avec un filtre, et supprimer les morceaux de l'ancienne version grâce à la métadonnée `source`.)

## 🧪 Exercice pratique

**Consigne.** Reprenez l'assistant construit à la leçon 48 (n8n ou Dify). Rédigez votre jeu de **10 questions** en respectant la répartition de la section 5.2 (au moins une question piège, une hors sujet, une référence exacte, une question sur une version à jour). Notez la version v1 sur la grille. Puis appliquez **un** changement parmi : réduire la taille des morceaux, activer la recherche hybride, ajouter une métadonnée `type` et un filtre, ou renforcer le prompt de refus. Notez la v2. Rédigez un compte rendu de dix lignes : ce qui a changé, pourquoi, et quel sera votre prochain réglage.

**Critères de réussite.**
- Le jeu de test couvre les 7 types de questions (fait, chiffre, procédure, reformulation, référence, multi-documents, pièges).
- La grille v1 et la grille v2 sont complètes (40 cases chacune) et le score global est calculé.
- Un seul réglage a changé entre v1 et v2, et le compte rendu relie l'évolution du score à ce réglage.
- La v2 atteint au moins 80 % en exactitude et 80 % en source, ou le compte rendu explique précisément pourquoi pas et quel maillon est en cause.

<details>
<summary>Pistes de corrigé</summary>

Résultats fréquents : réduire la taille des morceaux améliore les questions factuelles (Q1, Q2, Q5) mais peut dégrader la procédure (Q3) si les étapes se retrouvent dans deux morceaux : compensez avec un chevauchement plus grand ou un découpage aux titres. L'hybride règle presque toujours Q5 (article 12). Le filtre `date_maj` règle Q7. Le prompt de refus règle Q8-Q9 sans toucher au reste : c'est souvent le gain le plus rapide.
</details>

## ✅ Auto-évaluation express

1. Votre assistant cite le bon document mais donne un chiffre qui n'y figure pas. Quel maillon est en cause et quel critère de la grille chute ?
2. Pourquoi inclure une question dont la réponse n'est pas dans la base ?
3. Quelle métadonnée est indispensable pour remplacer proprement un document mis à jour ?

<details>
<summary>Réponses</summary>

1. La génération (le modèle extrapole) ; le critère **Fidélité** tombe à 0 alors que **Source** reste à 1. Remède : prompt plus strict, moins de passages, éventuellement modèle plus capable.
2. Pour mesurer le **comportement** : un RAG qui invente une réponse plausible à une question sans réponse est un risque métier (faux tarif, fausse procédure).
3. `source` (identifiant du fichier ou du document) : elle permet de supprimer tous les morceaux de l'ancienne version avant d'ingérer la nouvelle.
</details>

## 📚 Pour aller plus loin

- [Claude Platform — Define success criteria and build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) 🇬🇧 — méthodes de notation (exact match, cosinus, modèle juge) applicables à un RAG.
- [n8n — Evaluation node](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluation.md) 🇬🇧 — automatiser le jeu de test depuis une feuille de calcul.
- [Ragas — dépôt GitHub](https://github.com/vibrantlabsai/ragas) 🇬🇧 — les métriques de référence (faithfulness, context precision/recall).
- [DeepEval vs Ragas vs promptfoo (2026)](https://qaskills.sh/blog/deepeval-vs-ragas-vs-promptfoo-2026) 🇬🇧 — comparatif des trois outils d'évaluation.
- [Claude Academy — Building with the Claude API](https://academy.claude.com/courses/building-with-the-claude-api) 🇬🇧 — module « RAG & agentic search » : stratégies de découpage, BM25, reranking, contextual retrieval (badge gratuit).
- [Mistral — OCR 4.1](https://docs.mistral.ai/models/ocr-4-1) 🇬🇧 — pour rendre exploitables les PDF scannés.

> ✅ **Si vous ne retenez que 3 choses** — 1. Quand un RAG répond faux, regardez d'abord les passages qu'il a retrouvés : le problème vient presque toujours de l'extraction, du découpage ou de la recherche, rarement du modèle. 2. Découpez selon le type de document (une question/réponse, un article, une section avec son titre) et donnez à chaque morceau des métadonnées (`source`, `date_maj`, `type`) pour citer, filtrer et remplacer. 3. Évaluez avec 10 questions types notées sur 4 critères, et ne changez qu'un réglage à la fois entre deux versions.

> 🗺️ **Et maintenant ?** — Vous savez régler et mesurer un RAG ; la leçon L050 montre comment les Projets Claude, les GPT personnalisés et les Gems de Gemini embarquent cette connaissance directement dans un assistant, sans rien installer.
