---
module: M11
title: "Fiche mémo — RAG et bases de connaissances"
---
# Fiche mémo — M11 · RAG et bases de connaissances

> En une phrase : un RAG, c'est une bibliothèque rangée par le sens (embeddings) et un bibliothécaire (le LLM) qui ne lit que les 4 ou 5 fiches retrouvées ; si la réponse est fausse, vérifiez d'abord les fiches, pas le bibliothécaire.

## Les 7 idées à retenir
1. **Mots-clés = « contient ce mot ? » ; sémantique = « parle de la même chose ? »**. Un embedding est une adresse dans un espace de sens ; les meilleurs systèmes sont **hybrides** (`L047`).
2. **Le RAG en 4 temps** : découper → vectoriser → chercher (k passages) → générer avec citations. Le modèle ne lit jamais toute la base (`L047`).
3. **Un seul modèle d'embeddings par base** ; en changer impose de tout re-vectoriser. Anthropic ne propose pas d'embeddings (`L047`).
4. **Trois outils sans code** : NotebookLM (assistant personnel en 10 min), Dify / Flowise (application de chat pour une équipe), n8n (le RAG au milieu d'un processus) (`L048`).
5. **Une réponse fausse vient du maillon le plus faible** : extraction, découpage, recherche ou génération. Le modèle se change en dernier (`L049`).
6. **Découper selon le document** (une FAQ = une question/réponse, un contrat = un article) et étiqueter chaque morceau de **métadonnées** pour citer, filtrer et supprimer (`L049`).
7. **Projet Claude, GPT, Gem = un classeur d'accueil** : parfait pour une petite équipe sur un corpus stable ; pas de droits par utilisateur ni de mise à jour automatique (`L050`).

## Le schéma à connaître

```mermaid
flowchart LR
  subgraph P["Préparation (une fois, puis à chaque mise à jour)"]
    A["1. Découper"] --> B["2. Vectoriser"] --> C[("Base vectorielle<br/>+ métadonnées")]
  end
  Q["Question"] --> V["Vectoriser<br/>(même modèle)"]
  V --> R["3. Chercher<br/>k = 4 à 6 passages"]
  C --> R
  R --> G["4. Générer<br/>LLM + citations"]
  G --> S["Réponse sourcée"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| Embedding | L'étiquette qui dit où ranger un texte dans la bibliothèque du sens |
| Similarité cosinus | Les deux flèches pointent-elles dans la même direction ? (1 = oui, 0 = aucun rapport) |
| BM25 | La recherche lexicale moderne, forte sur les références exactes |
| Chunk / overlap | Une fiche d'environ une page / la phrase répétée d'une fiche à l'autre |
| Métadonnée | Les mentions au dos de la fiche : source, date, type, droits |
| Reranking | Un second modèle qui reclasse les passages trouvés |
| Récupération contextuelle | Ajouter à chaque morceau une phrase de contexte avant de le vectoriser |

## Les pièges classiques
- Renvoyer 30 passages « pour être sûr » : le modèle se noie, le coût explose. Commencez à k = 4 ou 5.
- Un PDF scanné sans OCR, un tableau aplati : l'extraction annule tout le reste.
- Un même réglage de découpage pour FAQ, CGV et tarifs : faites trois ingestions, avec une métadonnée `type`.
- Pas de métadonnée `source` : impossible de retirer l'ancienne version, les deux tarifs cohabitent.
- Simple Vector Store de n8n en production : tout disparaît au redémarrage.
- Écrire « utilise les documents si besoin » : écrivez « **uniquement** à partir des documents » et imposez la citation.
- Laisser la navigation web active dans un GPT : il répond « d'Internet » au lieu de vos documents.

## Les commandes / chiffres / dates utiles
- **Mnémo du diagnostic « E-D-R-G »** : **E**xtraction lisible ? → **D**écoupage complet ? → **R**echerche (bons passages, bonnes métadonnées) ? → **G**énération fidèle ?
- **Jeu de test** : 10 questions (fait, chiffre, procédure, reformulation, référence exacte, multi-documents, version à jour, information absente, hors sujet, faute de frappe). **Grille sur 4 critères** : exactitude, source, fidélité, comportement. Objectif : ≥ 80 % en exactitude **et** en source. Un réglage à la fois.
- Départ de découpage : 800 à 1 500 caractères, overlap 10 à 20 %.
- Dimensions : `nomic-embed-text` 768 · `mistral-embed` 1 024 · `text-embedding-3-small` 1 536.
- Coûts (nov. 2026) : `mistral-embed` 0,10 $/M tokens ; Mistral OCR 4.1 : 4 $ les 1 000 pages.
- Bases : pgvector pour commencer → Chroma pour expérimenter → Qdrant pour la production.
- API Anthropic : Files API (500 Mo par fichier), PDF jusqu'à 600 pages et 128 Mo par requête, Citations (`cited_text`). RAG : Lewis et al., 2020.

## Pour aller plus loin
- [n8n — Store and search data with vectors](https://docs.n8n.io/build/integrate-ai/understand-ai-components/store-and-search-data-with-vectors.md)
- [Claude Platform — Define success criteria and build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests)
- [Lewis et al., 2020 — Retrieval-Augmented Generation](https://arxiv.org/pdf/2005.11401)

## Auto-test (3 questions — réponses en bas de fiche)
1. L'assistant cite le bon document mais donne un chiffre qui n'y figure pas : quel maillon, quel critère chute ?
2. Il répond 48 € (tarif 2025) au lieu de 52 € (tarif 2026) : que corriger ?
3. Projet Claude avec 20 pages ou avec 2 000 pages : quelle différence de fonctionnement ?

---
**Réponses** — 1. La génération ; le critère **fidélité** tombe (la source reste juste). 2. La recherche et les métadonnées : filtre sur `date_maj` et suppression des morceaux de l'ancienne `source`. 3. À 20 pages, tout est lu à chaque question (contexte long) ; à 2 000, l'outil bascule sur une recherche intégrée que vous ne réglez pas.
