---
id: L064
module: M15
level: N2
title: "Conduite du changement et montée en compétence des équipes"
minutes: 50
objectives:
  - "Construire un plan de déploiement de l'IA en cinq étapes : diagnostic, pilote, champions, formation, mesure"
  - "Concevoir un plan de formation par population conforme à l'article 4 de l'AI Act, avec sa traçabilité"
  - "Identifier les résistances courantes et y répondre sans les nier"
skills: ["C2.6"]
sources:
  - { title: "Claude Academy — Building effective human-agent teams", url: "https://academy.claude.com/courses/building-effective-human-agent-teams", lang: "en" }
  - { title: "Claude Academy — AI Fluency: Framework & Foundations", url: "https://academy.claude.com/courses/ai-fluency-framework-foundations", lang: "en" }
  - { title: "CMS Law — European Commission clarifies AI literacy requirements", url: "https://cms.law/en/int/legal-updates/european-commission-clarifies-literacy-requirements-under-the-ai-act", lang: "en" }
  - { title: "OPIIEC / Syntec Ingénierie — IA : ce qu'il faut retenir (2025)", url: "https://www.syntec-ingenierie.fr/app/uploads/2025/06/20250428_OPIIEC_IA_A_RETENIR.pdf", lang: "fr" }
  - { title: "Le Monde Informatique — Plan Impulsion IA 2027", url: "https://www.lemondeinformatique.fr/actualites/lireamp-le-gouvernement-lance-un-plan-pour-former-a-l-ia-100805.html", lang: "fr" }
  - { title: "OpenAI Academy", url: "https://academy.openai.com/", lang: "en" }
---

# Conduite du changement et montée en compétence des équipes

> ⏱ 50 min · 🎯 Niveau 2 · 📚 Module 15

## 🎯 Ce que vous saurez faire
- Dérouler un déploiement IA en cinq étapes sans brûler la première (le diagnostic) ni oublier la dernière (la mesure).
- Écrire un plan de formation par population qui satisfait l'article 4 de l'AI Act et laisse une trace par salarié.
- Répondre aux trois résistances les plus fréquentes avec autre chose qu'un slogan.

> 🧭 **En clair** — Acheter un outil d'IA, c'est comme acheter un abonnement à une salle de sport pour toute l'équipe : la carte s'obtient en cinq minutes, mais personne ne devient plus en forme si l'on ne s'organise pas. On commence par regarder qui a vraiment besoin de quoi, on teste avec quelques volontaires, on s'appuie sur des « champions » qui motivent leurs collègues, on forme chacun selon son poste (pas tout le monde de la même façon), et on mesure régulièrement les progrès. L'AI Act (article 4) demande d'ailleurs des mesures de formation adaptées aux postes, et garder une trace permet de le prouver.

## 1. Pourquoi la technique n'est que la moitié du travail

Dans la branche numérique, ingénierie et conseil, l'OPIIEC estimait en 2025 (l'Observatoire des métiers de cette branche professionnelle) qu'environ 287 500 salariés restaient à former ou sensibiliser à l'IA, et que 26 % seulement l'étaient déjà ; les compétences attendues n'étaient pas d'abord techniques mais portaient sur le **cadre réglementaire, les usages et la conduite du changement**. L'État a suivi : plan « Osez l'IA » (2025, objectif de 15 millions de professionnels formés d'ici 2030), puis plan « Impulsion IA 2027 » (septembre 2026, plateforme publique « Explore IA », certification nationale de compétences IA en préparation avec l'ANSSI et l'Afpa (l'agence nationale de la sécurité des systèmes d'information et l'Agence nationale pour la formation professionnelle des adultes)). Le message est clair : l'outil s'achète en une heure, l'adoption se construit en des mois.

Analogie : installer un nouveau logiciel de caisse dans une boulangerie prend une matinée ; obtenir que les six vendeurs l'utilisent sans râler, sans contourner et sans erreur prend six semaines, et une seule personne qui y croit.

## 2. Les cinq étapes

```
1. DIAGNOSTIC ─► 2. PILOTE ─► 3. CHAMPIONS ─► 4. FORMATION ─► 5. MESURE ─┐
      ▲                                                                  │
      └──────────────────────── itération trimestrielle ◄────────────────┘
```

**1. Diagnostic (2 à 3 semaines).** Interrogez chaque équipe sur ses tâches répétitives, chronophages et à faible valeur (rédaction de comptes rendus, saisie, tri, recherche d'information). Recensez les usages déjà en place, officiels ou non (l'IA fantôme de la leçon L063 devient une ressource : ceux qui bricolent sont vos premiers experts). Classez les cas d'usage par valeur et par facilité ; gardez trois cas « rapides et visibles » pour le pilote.

**2. Pilote (6 à 8 semaines).** Un périmètre restreint, des volontaires, un objectif chiffré (« diviser par deux le temps de rédaction des comptes rendus de visite »), un jeu de tests, une date de fin. Le cours « Building effective human-agent teams » de Claude Academy résume les conditions d'un pilote réussi : des **rôles clairs**, un **objectif directeur écrit**, un **déploiement progressif** et un accès à l'information **approprié** (ni trop, ni trop peu). Mesurez avant et après ; publiez le résultat, même mitigé.

**3. Champions.** Un ou deux relais par équipe, volontaires, reconnus par leurs pairs, dotés de deux heures par semaine et d'un canal direct vers le référent IA. Ils collectent les bons prompts, animent un point mensuel de 30 minutes, remontent les irritants (les petites gênes du quotidien qui découragent l'usage). Sans champions, la formation s'évapore en trois mois.

**4. Formation par population.** Voir la section 3.

**5. Mesure.** Cinq indicateurs suffisent : taux d'adoption (utilisateurs actifs mensuels / sièges) — par exemple 18 personnes ayant utilisé l'outil au moins une fois dans le mois sur 25 licences payées = 72 % —, temps gagné déclaré sur les trois cas pilotes, qualité (taux de corrections sur un échantillon), incidents (registre de la L063), et satisfaction des équipes. Revue trimestrielle, décision : étendre, corriger ou arrêter un usage.

> 💡 **À retenir** — Un pilote qui échoue proprement (objectif chiffré, bilan publié) vaut mieux qu'un déploiement général qui réussit vaguement. La crédibilité du programme se joue sur l'honnêteté du premier bilan.

```quiz
{
  "q": "Dans quel ordre se déroulent les cinq étapes d'un déploiement IA ?",
  "options": [
    "Formation générale, déploiement à tous, mesure, champions, puis diagnostic final",
    "Pilote, diagnostic, mesure, formation, champions, puis déploiement général",
    "Diagnostic, pilote, champions, formation, mesure",
    "Champions, formation, pilote, diagnostic, mesure, puis itération annuelle"
  ],
  "answer": 2,
  "explanation": "On part des besoins réels (diagnostic), on teste sur un périmètre restreint avec un objectif chiffré (pilote), on installe des relais (champions), on forme selon les postes, puis on mesure et on recommence chaque trimestre."
}
```

## 3. Le plan de formation art. 4 : par population, et tracé

L'article 4 de l'AI Act demande des mesures **proportionnées** au contexte, aux connaissances, à l'expérience des personnes et aux systèmes utilisés. La Commission recommande de documenter un inventaire des systèmes, une politique interne, un plan de formation et une **trace par salarié** (type de formation, prestataire, contenu, date, recyclage). Voici un gabarit pour une PME de 50 personnes.

| Population | Contenu minimal | Durée | Support possible | Recyclage |
|---|---|---|---|---|
| **Tous les salariés** | Fonctionnement et limites d'un LLM, charte, classification des données, transparence, signalement d'incident | 2 h | Niveau 1 de cette formation (M01, M05, M07) ; AI Fluency (Claude Academy) ; OpenAI Academy « Apply AI at Work » | Annuel |
| **Utilisateurs intensifs** (rédaction, SAV, RH, compta) | Prompts structurés, vérification, projets / bases de connaissances, cas métier | 1 jour | Niveau 1 complet, M11-M12 | Semestriel |
| **Constructeurs** (automatisation, n8n, agents) | Workflows, RAG, sécurité des agents, coûts, tests | 3 à 5 jours | Niveau 2 (M08-M15) | À chaque nouvel usage |
| **Managers et direction** | Cas d'usage, gouvernance, art. 4, pilotage par indicateurs, équipes humain-agent | 3 h | Ce module ; « Building effective human-agent teams » ; OpenAI Academy « Lead AI Adoption » | Annuel |
| **Référent IA / DPO** | AI Act par rôle, RGPD et AIPD, procédure d'achat, veille | 1 jour + veille | L063 ; fiches CNIL | Continu |
| **Utilisateurs d'un système à haut risque** (RH, crédit) | Notice du fournisseur, contrôle humain, biais, journaux | 0,5 jour spécifique | Fournisseur + L063 | Avant toute mise en service, puis annuel |

La trace est un simple tableau : nom, population, formation suivie, date, résultat de l'évaluation, prochaine échéance. Exporté du LMS ou tenu dans un tableur (LMS : plateforme de formation en ligne, qui enregistre automatiquement qui a suivi quoi), il doit pouvoir être produit en une heure à qui le demande. Le certificat Next Formation de chaque niveau constitue une preuve de contenu et de date ; il ne remplace pas la décision de l'employeur sur ce qui est proportionné à chaque poste.

> 🧭 **Pas à pas pour débutant** — Monter la trace dans Excel en dix minutes : ligne 1, les en-têtes `Nom`, `Population`, `Formation suivie`, `Organisme / support`, `Date`, `Résultat`, `Prochaine échéance`. Sélectionnez la plage puis **Insertion → Tableau** (Ctrl+L) pour pouvoir filtrer par population. Dans la colonne *Prochaine échéance*, calculez la date de rappel, par exemple `=MOIS.DECALER(E2;12)` pour un recyclage annuel (6 pour un recyclage semestriel). Enfin, **Accueil → Mise en forme conditionnelle → Règles de mise en surbrillance des cellules → Inférieur à…** avec `=AUJOURDHUI()+30` : les rappels du mois à venir s'affichent en couleur. Rangez le fichier dans un dossier partagé avec historique des versions, accessible au référent IA et aux RH.

> 💡 **Autrement dit** — La « trace art. 4 », c'est le carnet de vaccination de l'entreprise pour l'IA : pour chaque personne, quelle formation, quand, avec quel résultat, et la date du prochain rappel. Personne ne vous demande un examen officiel, mais si un incident survient, c'est ce carnet qui prouvera que vous aviez pris les mesures raisonnables.

> ⚠️ **Piège fréquent** — Former tout le monde à la même chose. Deux heures de sensibilisation suffisent à un magasinier ; elles sont dangereusement insuffisantes pour la personne des RH qui paramètre un tri de candidatures. La proportionnalité joue dans les deux sens.

```quiz
{
  "type": "vrai_faux",
  "q": "Pour respecter l'article 4 de l'AI Act, le plus sûr est de donner exactement la même formation de deux heures à tous les salariés, du magasinier à la responsable RH.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "L'article 4 exige des mesures proportionnées au poste et aux systèmes utilisés. Deux heures suffisent au magasinier, mais sont très insuffisantes pour la personne qui paramètre un tri de candidatures (système à haut risque)."
}
```

```mission
{
  "title": "Que contient le cours « human-agent teams » de Claude Academy ?",
  "url": "https://academy.claude.com/courses/building-effective-human-agent-teams",
  "steps": ["Ouvrez la page du cours Building effective human-agent teams sur Claude Academy", "Relevez sa durée et le public visé", "Repérez les principes clés d'un pilote réussi cités dans la présentation"],
  "question": "Quelle est la durée de ce cours, à qui s'adresse-t-il, et quel est son statut ?",
  "hint": "Il dure moins d'une heure, s'adresse à des encadrants et porte une mention entre parenthèses dans son titre.",
  "answer": "Environ 45 minutes, pour les managers ; cours en version bêta (nov. 2026) — vérifiez : le catalogue évolue.",
  "xp": 10
}
```

## 4. Les résistances, et comment y répondre

| Ce que vous entendrez | Ce qui se cache derrière | Réponse utile |
|---|---|---|
| « Ça va nous remplacer. » | Peur légitime sur l'emploi | Dire la vérité sur ce qui change et ce qui ne change pas ; montrer les tâches supprimées (saisie) et celles qui gagnent du temps ; les études de marché 2026 montrent que les salariés qui utilisent l'IA progressent plus vite, pas qu'ils disparaissent (Randstad, juillet 2026). |
| « Ce n'est pas fiable. » | Expérience d'une hallucination | Donner raison : c'est pour cela qu'on vérifie (M05) ; montrer le jeu de tests du pilote et son taux d'erreur mesuré. |
| « On n'a pas le temps. » | Charge de travail réelle | Former sur un cas métier qui rend du temps dès la première semaine ; deux heures, pas deux jours. |
| « Juridiquement, c'est flou. » | Absence de politique écrite | Présenter la charte et la classification (L063) ; impliquer le CSE tôt. |

🎮 **Défi** — Choisissez la résistance que vous avez le plus entendue dans votre organisation et rédigez en trois phrases la réponse que vous donneriez lundi.

```quiz
{
  "q": "Mise en situation : en réunion, une gestionnaire déclare « Ce n'est pas fiable, la dernière fois l'IA a inventé une clause du bail. » Quelle réponse est la plus utile ?",
  "options": [
    "« Les nouveaux modèles ne se trompent plus, ce problème est réglé depuis 2025. »",
    "« Vous avez raison : voici le taux d'erreur du pilote et notre règle de relecture. »",
    "« C'est sans doute que votre prompt était mal rédigé, il faudra suivre la formation. »",
    "« La direction a décidé, on n'a pas vraiment le choix, il faut s'y mettre. »"
  ],
  "answer": 1,
  "explanation": "On ne nie pas une résistance fondée sur une vraie expérience : on lui donne raison, puis on montre le dispositif (jeu de tests, taux d'erreur mesuré, relecture humaine) qui rend l'usage maîtrisé."
}
```

```mission
{
  "title": "Les quatre « D » de l'AI Fluency",
  "url": "https://academy.claude.com/courses/ai-fluency-framework-foundations",
  "steps": ["Ouvrez la page du cours AI Fluency: Framework and foundations sur Claude Academy", "Relevez la durée annoncée du cours", "Notez les quatre compétences du cadre, toutes commençant par la lettre D"],
  "question": "Quelles sont les quatre compétences du cadre 4D et combien de temps dure le cours ?",
  "hint": "En anglais : Delegation, Description, …, … ; la durée se compte en heures.",
  "answer": "Délégation (Delegation), Description, Discernement (Discernment), Diligence ; environ 4 h (nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Pour l'agence immobilière des leçons précédentes (25 salariés : 12 négociateurs, 6 gestionnaires locatifs, 4 administratifs, 2 dirigeants, 1 assistante de direction formée à n8n), rédigez un plan de déploiement sur six mois : trois cas pilotes, deux champions nommés par fonction, un tableau de formation par population avec durées et dates, cinq indicateurs chiffrés, et la trace art. 4 vide prête à remplir.

**Critères de réussite.** Les cas pilotes ont un objectif chiffré et une date de fin ; chaque population a un contenu et une durée différents ; la trace comporte au moins les colonnes nom, formation, date, échéance ; un paragraphe traite d'au moins une résistance.

<details>
<summary>Pistes</summary>
Pilotes possibles : rédaction des annonces (négociateurs), réponse aux demandes locataires (gestion locative), extraction des diagnostics (administratif + n8n). Champions : un négociateur senior et une gestionnaire. Indicateurs : annonces rédigées par heure, délai de réponse locataires, taux de corrections sur 50 extractions, utilisateurs actifs, incidents.
</details>

## ✅ Auto-évaluation express

1. Pourquoi la trace de formation par salarié est-elle une pièce centrale de l'art. 4 ?
2. Quelle est la différence de durée et de contenu entre la formation d'un magasinier et celle d'un gestionnaire RH qui utilise un outil de tri de candidatures ?
3. Quel est le rôle d'un champion, et combien de temps lui donner ?

*Réponses : 1. L'art. 4 n'impose pas d'examen mais des mesures proportionnées ; sans trace (contenu, date, personne), impossible de démontrer qu'elles existent. 2. Deux heures de sensibilisation générale contre une journée (contenu intensif) plus une demi-journée spécifique au système à haut risque, avec recyclage annuel. 3. Relais de proximité : collecte des bons usages, point mensuel, remontée des irritants ; environ deux heures par semaine.*

## 📚 Pour aller plus loin

- [Claude Academy — Building effective human-agent teams](https://academy.claude.com/courses/building-effective-human-agent-teams) 🇬🇧 — 45 minutes pour managers : rôles, objectif directeur, déploiement progressif.
- [Claude Academy — AI Fluency: Framework & Foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations) 🇬🇧 — le cadre 4D (délégation, description, discernement, diligence), support idéal pour la population « tous les salariés ».
- [OpenAI Academy](https://academy.openai.com/) 🇬🇧 — parcours « Apply AI at Work » et « Lead AI Adoption », gratuits avec un compte.
- [OPIIEC — IA : ce qu'il faut retenir](https://www.syntec-ingenierie.fr/app/uploads/2025/06/20250428_OPIIEC_IA_A_RETENIR.pdf) — chiffres de la branche sur les besoins de formation.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un déploiement IA se fait en cinq étapes : diagnostic des besoins réels, pilote chiffré avec des volontaires, champions dans chaque équipe, formation par population, mesure trimestrielle. 2. L'article 4 de l'AI Act demande une formation **proportionnée au poste** — deux heures pour certains, plusieurs jours pour d'autres — et une trace par salarié (formation, date, prochain rappel). 3. Face aux résistances, on ne nie pas : on donne raison à ce qui est fondé, puis on montre les chiffres du pilote, la règle de relecture et la charte.

> 🗺️ **Et maintenant ?** — Le niveau 2 s'achève : vous savez utiliser, automatiser et encadrer l'IA. Le niveau 3 vous fait passer côté code avec la leçon L065 : installer Python ou TypeScript, un SDK et ranger proprement votre clé API.
