---
module: M15
title: "Fiche mémo — Gouvernance et déploiement de l'IA en entreprise"
---
# Fiche mémo — M15 · Gouvernance et déploiement de l'IA en entreprise

> En une phrase : choisissez la bonne porte pour chaque usage (SaaS, API ou local) au coût total sur 3 ans, écrivez le code de la route interne (politique IA), puis faites-le vivre (pilote, champions, formation tracée, mesure).

## Les 7 idées à retenir
1. **Trois portes** : le SaaS vend de la simplicité (sièges), l'API de la flexibilité (tokens), le local du contrôle (matériel). Une PME combine souvent les trois (`L062`).
2. **Le prix affiché n'est jamais le coût** : TCO sur 3 ans = coûts directs + mise en place + humain récurrent + sortie. Le temps humain renverse souvent le verdict (`L062`).
3. **La réversibilité se construit le jour de l'arrivée** : prompts, documents et jeux de tests hors de l'outil ; API compatible OpenAI ; plafond de dépense (`L062`).
4. **Vous êtes presque toujours déployeur** ; vous basculez fournisseur si vous vendez sous votre marque ou détournez un système vers un usage à haut risque (`L063`).
5. **Classifier les données en 4 niveaux** (public, interne, confidentiel, réglementé) : c'est la pierre angulaire qui dit quel outil a le droit de quoi (`L063`).
6. **Six pièces de politique IA** : charte signée, classification affichée, registre des usages, procédure d'achat (10 questions), procédure d'incident, plan de formation (`L063`).
7. **Déployer en 5 étapes** : diagnostic → pilote chiffré → champions → formation par population → mesure trimestrielle (`L064`).

## Le schéma à connaître

```mermaid
flowchart TD
  A{"Les données peuvent-elles<br/>sortir de l'entreprise ?"} -- "Non" --> L["LOCAL<br/>(ou GPU loué en Europe sous contrat)"]
  A -- "Oui, avec contrat" --> B{"Intégré dans un processus<br/>(n8n, code) ?"}
  B -- "Non" --> S["SaaS entreprise administré<br/>(au-delà de 15-20 sièges : comparer avec l'API)"]
  B -- "Oui" --> C{"Volume élevé et régulier<br/>ET compétences internes ?"}
  C -- "Non" --> P["API, petit modèle d'abord<br/>Batch, cache, plafond de dépense"]
  C -- "Oui" --> T["Comparer API et local au TCO<br/>jeu de tests + plan de sortie"]
```

## Vocabulaire express
| Terme | En clair |
|---|---|
| TCO | Le prix « tout compris » sur 3 ans, revente et garage inclus |
| Déployeur / fournisseur | Celui qui conduit la voiture / celui qui la fabrique et la vend sous son nom |
| Responsable de traitement / sous-traitant | L'entreprise qui décide / le déménageur qui transporte vos cartons (contrat art. 28) |
| AIPD | L'analyse d'impact RGPD, à faire **avant** le déploiement |
| Registre des usages IA | La liste vivante des outils, finalités, données, risques et contrôles |

## Les pièges classiques
- Comparer le prix des tokens et oublier le temps d'administration : à 12 personnes, le SaaS gagne malgré des tokens trois fois plus chers.
- Oublier que l'entrée inclut tout (prompt système, documents, historique) : la facture d'un chatbot grimpe avec la longueur de la conversation.
- Lier un processus critique à un seul modèle : retraits et hausses de prix arrivent.
- « Le haut risque est reporté, on verra en 2027 » : l'art. 4, l'art. 5 et le RGPD s'appliquent déjà.

## Les commandes / chiffres / dates utiles
- **Grille en 7 critères, mnémo « C-Q-V-I-C-C-R »** : **C**onfidentialité · **Q**ualité requise · **V**olume · **I**ntégration · **C**ompétences · **C**oût sur 3 ans · **R**éversibilité.
- **Les 3 questions éliminatoires au fournisseur** : entraînement sur mes données ? durée de conservation ? localisation et transferts hors UE (contrat art. 28) ? Sans réponse écrite, pas de données de niveau 3.
- Repères TCO (nov. 2026) : scénario A, 12 personnes : SaaS ≈ 16 300 € contre API ≈ 18 100 € (bascule vers ≈ 15 personnes) ; scénario B, 200 000 e-mails/mois : Haiku 5.5 ≈ 90 $/mois (45 $ en Batch) contre Sonnet 5.5 ≈ 1 800 $.
- Gemini API : depuis le 26 oct. 2026, `store=true` par défaut pour les nouveaux projets payants : vérifiez la conservation avant d'y envoyer des données.
- AI Act : interdits et art. 4 depuis le **2 févr. 2025** ; art. 50 depuis le **2 août 2026** ; haut risque annexe III au **2 déc. 2027** (omnibus, règlement (UE) 2026/1744, en vigueur le 27 juillet 2026, qui reformule aussi l'art. 4 : « favoriser » la maîtrise de l'IA, l'obligation de former demeure).
- RGPD : notification d'une violation sous **72 h** ; CSE informé avant déploiement.
- Formation : tous 2 h (annuel) · intensifs 1 jour · constructeurs 3 à 5 jours · managers 3 h · haut risque 0,5 jour en plus.

## Pour aller plus loin
- [CNIL — les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia)
- [Règlement (UE) 2024/1689 sur EUR-Lex](https://eur-lex.europa.eu/eli/reg/2024/1689/oj)
- [Claude Academy — Deploying Claude Enterprise with confidence](https://academy.claude.com/courses/deploying-claude-enterprise-with-confidence)

## Auto-test (3 questions — réponses en bas de fiche)
1. Une PME utilise Claude Team pour ses devis : fournisseur ou déployeur, et quelle obligation déjà applicable ?
2. Dans le tri de 200 000 e-mails, qu'est-ce qui pèse le plus : changer de fournisseur ou de taille de modèle ?
3. Pourquoi la trace de formation par salarié est-elle centrale pour l'art. 4 ?

---
**Réponses** — 1. Déployeur ; l'art. 4 (maîtrise de l'IA) depuis le 2 février 2025, plus le RGPD si des données personnelles circulent. 2. La taille du modèle : Sonnet coûte vingt fois Haiku chez le même fournisseur. 3. L'art. 4 n'impose pas d'examen mais des mesures proportionnées : sans trace (qui, quoi, quand), impossible de les prouver.
