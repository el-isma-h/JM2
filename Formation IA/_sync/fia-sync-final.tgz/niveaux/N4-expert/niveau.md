# Niveau 4 — Expert IA : du machine learning aux modèles de frontière (NF-IA-N4)

**Certificat Next Formation IA — Niveau 4 « Expert IA »** · 45 h à distance (44 h de leçons et exercices + 1 h d'évaluations) · 7 modules · 40 leçons · 7 quiz · 1 examen · 1 épreuve écrite · 4 projets de code · 1 rapport final · Version 1.0 — 1er novembre 2026.

## Promesse

À l'issue du niveau 4, vous **comprenez et construisez ce qu'il y a sous le capot** : les mathématiques nécessaires (algèbre linéaire, gradients, probabilités, optimisation), le machine learning classique (régression, arbres, k-means, PCA, scikit-learn), le deep learning avec PyTorch (MLP, rétropropagation, CNN, RNN), les Transformers et un GPT écrit from scratch (attention, tokenization BPE, lois d'échelle, SFT/RLHF/DPO, MoE et contexte long), le fine-tuning d'un modèle ouvert (LoRA/QLoRA avec PEFT, TRL, Unsloth) et son évaluation sur benchmarks, l'inférence et le déploiement en production (quantization, vLLM, llama.cpp, KV cache, GPU cloud, DGX Spark, edge/NPU, MLOps), et la sûreté des systèmes d'IA (alignement, red teaming, sécurité agentique OWASP/MITRE ATLAS, NIST AI RMF, ISO/IEC 42001, AI Act haut risque). Le niveau s'inspire des cours MIT 6.S191 et 6.390, Stanford CS229, CS224N, CS324, CS336 et CS25, des projets IA de l'École 42, de Karpathy et du Hugging Face LLM Course — avec des leçons entièrement originales.

## Public

Développeurs confirmés, ingénieurs logiciel et data, data scientists, ingénieurs ML/MLOps, étudiants d'écoles d'ingénieurs et de 42 (projets ft_linear_regression, DSLR, multilayer-perceptron, Leaffliction), chercheurs et profils techniques souhaitant passer de l'intégration d'API à la conception et à l'adaptation de modèles.

## Prérequis

- Niveau 3 Next Formation validé **ou** expérience en développement IA (API de LLM, RAG, agents).
- Python solide (classes, NumPy) ; Git ; ligne de commande ; notions de Docker.
- Mathématiques niveau bac + 1 (fonctions, dérivées, vecteurs) : une **remise à niveau complète est intégrée au module 24** ; aucune connaissance préalable de l'algèbre linéaire avancée ou des probabilités n'est exigée.
- Test de positionnement d'entrée.

## Compétences du bloc 4 (référentiel de compétences)

| Code | Compétence |
|---|---|
| C4.1 | Mobiliser les outils mathématiques (algèbre linéaire, calcul différentiel, probabilités, optimisation) nécessaires à la compréhension des modèles |
| C4.2 | Entraîner, évaluer et sélectionner un modèle de machine learning supervisé ou non supervisé sur un jeu de données réel |
| C4.3 | Implémenter et entraîner un réseau de neurones profond (MLP, CNN, transformer) avec un framework (PyTorch) |
| C4.4 | Adapter un modèle de langage ouvert à un domaine par fine-tuning (LoRA/QLoRA) ou via API, et mesurer le gain |
| C4.5 | Déployer un modèle en production (quantization, serveur d'inférence, GPU/edge) avec suivi des performances et des coûts |
| C4.6 | Évaluer la sûreté, la robustesse et la conformité d'un système d'IA (red teaming, sécurité agentique, NIST AI RMF, ISO/IEC 42001, AI Act) |

## Modules et durées

| Module | Titre | Leçons | Durée | Compétences |
|---|---|---|---|---|
| M24 | Mathématiques pour l'IA (algèbre linéaire inspirée de MIT 18.06, dérivées et gradients, probabilités, descente de gradient) | L111-L114 | 5 h 15 | C4.1 |
| M25 | Machine learning (inspiré Stanford CS229 et MIT 6.390 ; projets 42 ft_linear_regression et DSLR ; biais-variance, arbres et boosting, k-means/PCA, scikit-learn, projet) | L115-L120 | 6 h 15 | C4.2 |
| M26 | Deep learning (inspiré MIT 6.S191 ; perceptron et MLP — projet 42 multilayer-perceptron ; rétropropagation à la main — micrograd ; PyTorch ; CNN ; RNN/LSTM ; optimiseurs et GPU ; projet classifieur d'images) | L121-L127 | 7 h 15 | C4.3 |
| M27 | Transformers et LLM from scratch (inspiré CS224N, CS336, CS25 ; attention, architecture, tokenization BPE, nanoGPT, lois d'échelle et données, SFT/RLHF/DPO et modèles de raisonnement, architectures 2026 : MoE, contexte long, multimodal) | L128-L134 | 7 h 15 | C4.3 |
| M28 | Fine-tuning et adaptation de modèles (quand fine-tuner, LoRA/QLoRA avec PEFT/TRL/Unsloth, jeux de données et distillation, benchmarks et evals maison, fine-tuning via API, projet) | L135-L140 | 6 h 15 | C4.4 |
| M29 | Inférence, déploiement et MLOps (quantization/GGUF, vLLM/llama.cpp/TGI, KV cache/batching/speculative decoding, GPU cloud/on-premise/DGX Spark et coûts, MLOps, edge et NPU) | L141-L145 | 5 h 15 | C4.5 |
| M30 | Sécurité avancée, alignement et frontière de la recherche (alignement et interprétabilité, red teaming et jailbreaks, sécurité agentique OWASP/MITRE ATLAS, gouvernance NIST AI RMF / ISO/IEC 42001 / AI Act haut risque, veille scientifique et projet final) | L146-L150 | 6 h 30 | C4.6 |
| | **Total leçons et exercices** | 40 leçons | **44 h 00** | |
| | Quiz de modules (7 × 15 min) et examen de niveau (60 min) | | ≈ 1 h (comptés dans les 45 h) | |

## Modalités d'évaluation

- **7 quiz de fin de module** (10 questions, seuil 70 %) et **examen de niveau** (40 questions, 60 min, seuil 70 %, surveillé à distance, 3 tentatives).
- **Épreuve écrite de mathématiques** (M24, 90 min, surveillée à distance) → C4.1.
- **Quatre projets de code** dans un dépôt Git (grille à 5 critères notés 0-3 ; compétence validée si ≥ 8/15 sans critère à 0) :
  1. Projet ML : prédiction sur données réelles avec protocole de validation et détection du sur-apprentissage (L120) → C4.2
  2. Projet DL : classifieur d'images PyTorch convergent et reproductible (L127) → C4.3
  3. Projet fine-tuning : spécialisation d'un modèle ouvert (LoRA/QLoRA) avec gain mesuré sur une évaluation définie (L140) → C4.4
  4. Déploiement d'un modèle servi (vLLM ou llama.cpp) avec débit mesuré, coûts chiffrés et monitoring (M29) → C4.5
- **Rapport final de sûreté et de gouvernance** avec red teaming documenté et plan de gouvernance (L150) → C4.6.
- **Certification (option RS)** : soutenance de 30 min devant jury incluant un expert ML externe. Toutes les compétences C4.1 à C4.6 doivent être validées.

## Certifications tierces visées (en complément, hors Next Formation)

- **Hugging Face LLM Course** (certification exam du chapitre 1) et **a smol course** (certificats Fundamentals / Completion), gratuits — https://huggingface.co/learn/llm-course · https://huggingface.co/learn/smol-course.
- **IBM AI Engineering Professional Certificate** (13 cours, Coursera Plus) — https://www.coursera.org/professional-certificates/ai-engineer.
- **DeepLearning.AI Deep Learning Specialization** et **Machine Learning Specialization** (Stanford Online ; audit gratuit) — https://www.deeplearning.ai/deep-learning-specialization/.
- **Claude Certified Architect – Professional** (175 $, Claude Partner Network uniquement) — https://anthropic-partners.skilljar.com/claude-certified-architect-professional-certification.
- **Harvard CS50's Introduction to AI with Python** (certificat vérifié 299 $, audit gratuit) — https://pll.harvard.edu/course/cs50s-introduction-artificial-intelligence-Python.
- Pour aller plus loin (payant, cohortes) : Stanford Online Artificial Intelligence Professional Program (XCS229, XCS224N — 1 750 $ par cours).

## Matériel et logiciels nécessaires

- Ordinateur Windows 10/11 (WSL2), macOS 13+ (Apple Silicon recommandé, 16-32 Go de mémoire unifiée) ou Linux ; webcam et micro pour les épreuves surveillées et la soutenance.
- **GPU** : non obligatoire. Les modules 26-28 s'exécutent sur **Google Colab (gratuit ou Pro)**, **Kaggle Notebooks** (GPU gratuit) ou un **GPU cloud à l'heure** (RTX 4090 ≈ 0,34 $/h sur RunPod/Vast.ai ; L40S 1,40 €/h ou H100 PCIe 2,73 €/h HT chez Scaleway ; H100 2,80 €/h chez OVHcloud — prix nov. 2026). Budget cloud indicatif pour l'ensemble du niveau : **10 à 30 €** (projet de fine-tuning QLoRA d'un modèle 3-8B ≈ 1 à 3 h de GPU). Un GPU NVIDIA local ≥ 12 Go de VRAM (RTX 3060/4070) ou un Mac 32 Go permet de tout faire en local ; le DGX Spark et AMD Strix Halo sont étudiés, pas requis.
- **Logiciels gratuits** : Python 3.11+ (`uv`/`conda`), Jupyter / VS Code, Git, Docker, NumPy, pandas, matplotlib, scikit-learn, **PyTorch** (CUDA, MPS ou CPU), Hugging Face `transformers`, `datasets`, `peft`, `trl`, `accelerate`, **Unsloth**, `lm-evaluation-harness`, `vllm` (Linux/GPU) ou `llama.cpp` (tous OS), Ollama, Weights & Biases ou MLflow (suivi d'expériences), `promptfoo` / Inspect AI (red teaming et évals).
- **Comptes gratuits** : Hugging Face (téléchargement de modèles ouverts : Qwen3.8, Gemma 4, gpt-oss, Mistral Small 4, Ministral 3, Granite 4.2, SmolLM3 ; acceptation des licences), Kaggle, Google Colab, GitHub, un fournisseur de GPU cloud (RunPod, Vast.ai, Scaleway ou OVHcloud — carte bancaire requise, dépenses plafonnées), clés API OpenAI / Mistral / Google pour la leçon de fine-tuning via API (L139 — quelques euros ; la plateforme de fine-tuning OpenAI étant en arrêt progressif pour les nouveaux comptes, l'exercice s'appuie en priorité sur Mistral et Gemini).
