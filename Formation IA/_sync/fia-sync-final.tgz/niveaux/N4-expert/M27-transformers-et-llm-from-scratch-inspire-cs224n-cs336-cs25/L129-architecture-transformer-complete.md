---
id: L129
module: M27
level: N4
title: "Architecture transformer complète"
minutes: 60
objectives:
  - "Décrire l'enchaînement complet d'un bloc transformer décodeur et le rôle de chaque composant"
  - "Comparer les encodages de position appris, sinusoïdaux et RoPE, et démontrer la propriété relative de RoPE"
  - "Expliquer les différences entre LayerNorm et RMSNorm, pré-norm et post-norm, MLP GELU et SwiGLU"
  - "Implémenter en PyTorch un bloc transformer « style 2026 » et compter ses paramètres"
skills: ["C4.3"]
sources:
  - { title: "Vaswani et al. (2017) — Attention Is All You Need", url: "https://arxiv.org/abs/1706.03762", lang: "en" }
  - { title: "Su et al. (2021) — RoFormer: Enhanced Transformer with Rotary Position Embedding", url: "https://arxiv.org/abs/2104.09864", lang: "en" }
  - { title: "Zhang & Sennrich (2019) — Root Mean Square Layer Normalization", url: "https://arxiv.org/abs/1910.07467", lang: "en" }
  - { title: "Shazeer (2020) — GLU Variants Improve Transformer", url: "https://arxiv.org/abs/2002.05202", lang: "en" }
  - { title: "Xiong et al. (2020) — On Layer Normalization in the Transformer Architecture", url: "https://arxiv.org/abs/2002.04745", lang: "en" }
  - { title: "Stanford CS336 Spring 2026 — séance 3 Architectures, hyperparamètres", url: "https://cs336.stanford.edu/", lang: "en" }
---

# Architecture transformer complète

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 27

## 🎯 Ce que vous saurez faire
- Dessiner de mémoire un bloc transformer décodeur moderne et justifier l'ordre de ses composants.
- Choisir entre positions apprises, sinusoïdales et **RoPE** (*Rotary Position Embedding*), et vérifier par le code que RoPE encode des positions **relatives**.
- Expliquer pourquoi les LLM de 2026 utilisent presque tous **RMSNorm**, l'architecture **pré-norm** et un MLP **SwiGLU**.
- Implémenter le bloc complet en PyTorch, l'empiler, et estimer le nombre de paramètres d'un modèle à partir de sa configuration.

> 🧭 **En clair** — Si l'attention est la réunion où les mots échangent, le bloc transformer est la journée complète d'un service : un temps d'échange (l'attention), puis un temps de travail individuel où chacun digère ce qu'il a entendu (le MLP). Avant chaque temps, on règle le volume pour que personne ne parle trop fort (la normalisation), et chaque service annote le dossier sans jamais jeter les pages précédentes (les connexions résiduelles). Comme l'attention ne sait pas dans quel ordre les mots sont arrivés, on donne aussi à chacun un repère de place : aujourd'hui, une petite rotation de son vecteur, comme une aiguille de montre qui tourne selon la position (RoPE). Un grand modèle de langage, c'est ce bloc répété des dizaines de fois.

En L128, vous avez construit l'attention multi-têtes. Seule, elle ne suffit pas : elle ignore l'ordre des tokens, elle se contente de **mélanger** l'information entre positions, et un empilement naïf de dizaines de couches serait impossible à entraîner. Cette leçon ajoute les quatre pièces qui transforment l'attention en architecture : positions, normalisation, MLP et connexions résiduelles. C'est précisément le programme de la séance 3 du cours Stanford CS336 (« Architectures, hyperparameters ») et de la première partie de son devoir A1.

## 1. Vue d'ensemble : du transformer de 2017 au bloc de 2026

Un modèle décodeur (type GPT) se lit de bas en haut :

```
 tokens ──▶ Embedding (V × d) ──▶ [ Bloc 1 ] ──▶ … ──▶ [ Bloc L ] ──▶ Norm finale ──▶ Tête linéaire (d × V) ──▶ logits
                                     │
              ┌──────────────────────┴───────────────────────┐
              │  x ──┬──▶ RMSNorm ──▶ Attention causale (+RoPE) ──▶ (+) ──┬──▶ RMSNorm ──▶ SwiGLU ──▶ (+) ──▶ x'
              │      └───────────────── résidu ───────────────────┘      └────────── résidu ───────┘
              └──────────────────────────────────────────────────────────────────────────────────────┘
```

Les recettes ont convergé de façon frappante. Le tableau ci-dessous compare le transformer original à ce que l'on retrouve dans la plupart des modèles ouverts récents (Llama, Mistral, Qwen, DeepSeek, Gemma ; consultez la fiche technique de chaque modèle pour le détail exact).

| Composant | Transformer 2017 | GPT-2 (2019) | Bloc « standard » 2024-2026 |
|---|---|---|---|
| Positions | sinusoïdales, ajoutées à l'entrée | apprises, ajoutées à l'entrée | **RoPE**, appliqué à Q et K dans chaque couche |
| Normalisation | LayerNorm | LayerNorm | **RMSNorm** |
| Place de la norme | après le résidu (*post-norm*) | avant (*pré-norm*) | **pré-norm** |
| MLP | ReLU, largeur $4d$ | GELU, largeur $4d$ | **SwiGLU**, largeur $\approx \frac{8}{3}d$ |
| Biais dans les couches linéaires | oui | oui | généralement **non** |
| Attention | multi-têtes complète | multi-têtes complète | souvent **GQA** (têtes KV partagées, L134) |

> 💡 **À retenir** — Un bloc moderne s'écrit en deux lignes : $x \leftarrow x + \text{Attn}(\text{Norm}(x))$ puis $x \leftarrow x + \text{MLP}(\text{Norm}(x))$. Tout le reste est du détail d'implémentation… mais ce sont ces détails qui décident si l'entraînement converge.

## 2. Donner un ordre aux tokens : les encodages de position

L128 l'a montré : sans information de position, l'attention est équivariante par permutation. Trois grandes solutions se sont succédé.

**Positions apprises (GPT-2, BERT).** On crée une seconde table d'embeddings de taille $T_{\max} \times d$ et on ajoute la ligne $p$ à l'embedding du token en position $p$. Simple et efficace, mais le modèle ne sait rien faire au-delà de $T_{\max}$ : la position 2 049 n'a jamais été apprise.

**Positions sinusoïdales (Vaswani et al., 2017).** Pas de paramètres : chaque position reçoit un vecteur fixe
$$PE_{p,2i} = \sin\!\left(\frac{p}{10000^{2i/d}}\right), \qquad PE_{p,2i+1} = \cos\!\left(\frac{p}{10000^{2i/d}}\right)$$
Chaque paire de dimensions est une « aiguille d'horloge » qui tourne à sa propre vitesse : les premières dimensions tournent vite (elles distinguent les voisins immédiats), les dernières très lentement (elles situent la position à grande échelle). C'est l'analogie d'une montre à trotteuse, aiguille des minutes et aiguille des heures.

> 🔢 **Exemple à la main** — $PE_{p,2i}$ se lit « composante $2i$ du vecteur de position de la position $p$ » (les composantes paires reçoivent un sinus, les impaires un cosinus). Avec $d = 4$ et la position $p = 1$ :
> 1. Paire $i = 0$ : dénominateur $10000^{0} = 1$, angle $1$ → $\sin 1 \approx 0{,}841$ et $\cos 1 \approx 0{,}540$ (aiguille rapide).
> 2. Paire $i = 1$ : dénominateur $10000^{2/4} = \sqrt{10000} = 100$, angle $0{,}01$ → $\sin 0{,}01 \approx 0{,}010$ et $\cos 0{,}01 \approx 1{,}000$ (aiguille lente, à peine bougée).
>
> Vecteur ajouté au token en position 1 : $(0{,}841 ;\ 0{,}540 ;\ 0{,}010 ;\ 1{,}000)$. Les angles sont en **radians** (1 radian ≈ 57°). (Vérifié en Python.)

**RoPE (Su et al., 2021, arXiv 2104.09864).** Plutôt que d'**ajouter** une position à l'entrée, RoPE **fait tourner** les vecteurs de requête et de clé, paire de dimensions par paire de dimensions, d'un angle proportionnel à la position : $\theta_{p,i} = p / 10000^{2i/d_k}$. La magie vient d'une propriété des rotations : le produit scalaire entre une requête tournée de l'angle $p\theta$ et une clé tournée de $p'\theta$ ne dépend que de la **différence** $(p - p')\theta$. Le score d'attention devient donc une fonction de la distance relative entre tokens, ce qui correspond bien à l'intuition linguistique (« le mot juste avant » compte plus que « le mot en position 312 »). Le script de la section 6 le vérifie : `score(5, 2)` et `score(45, 42)` sont identiques.

> 💡 **Autrement dit** — Posez deux aiguilles sur un cadran et faites-les tourner toutes les deux du même angle : l'angle **entre** elles ne change pas. RoPE fait tourner la requête et la clé selon leur position ; leur score ne dépend donc que de l'écart entre les deux positions (« trois mots plus loin »), pas de l'endroit où elles se trouvent dans le texte.

> 🔢 **Exemple à la main** — Faire tourner une paire $(x_1, x_2)$ d'un angle $a$ donne $(x_1 \cos a - x_2 \sin a ;\ x_1 \sin a + x_2 \cos a)$ (formule de rotation du lycée, c'est exactement la ligne `tourne = ...` du code). Prenons $q = k = (1, 0)$ et un angle de $0{,}5$ radian par position.
> 1. Requête en position 5 → angle $2{,}5$ ; clé en position 2 → angle $1{,}0$. Deux vecteurs unitaires d'angles $2{,}5$ et $1{,}0$ ont pour produit scalaire $\cos(2{,}5 - 1{,}0) = \cos 1{,}5 \approx 0{,}0707$.
> 2. Positions 45 et 42 → angles $22{,}5$ et $21{,}0$ → $\cos(1{,}5)$ : **le même** $0{,}0707$.
>
> Seul l'écart (3 positions) compte. (Vérifié en Python.)

> ⚠️ **Piège fréquent** — Appliquer RoPE aux **valeurs** $V$ ou à l'entrée $x$. RoPE ne concerne que $Q$ et $K$, c'est-à-dire le calcul des scores. Les valeurs transportent le contenu et ne doivent pas être tournées. Autre erreur classique : apparier les dimensions de deux façons différentes (entrelacée `0::2 / 1::2` contre « moitié / moitié »). Les deux conventions existent dans les bibliothèques ; mélanger des poids entraînés avec l'une et un code écrit pour l'autre donne un modèle qui « parle » en charabia.

Le paramètre `base` (10 000 à l'origine) fixe la vitesse de rotation la plus lente. Les modèles à très long contexte l'augmentent fortement, ou utilisent des techniques d'extension comme YaRN, que nous verrons en L134.

```quiz
{
  "q": "Pourquoi RoPE est-il appliqué aux requêtes et aux clés, mais pas aux valeurs ?",
  "options": [
    "Parce que les valeurs sont déjà normalisées par RMSNorm",
    "Parce que tourner V doublerait le nombre de paramètres",
    "Parce que la position sert aux scores, pas au contenu transmis",
    "Parce que les modèles décodeurs n'ont pas de valeurs"
  ],
  "answer": 2,
  "explanation": "RoPE agit sur le produit scalaire q · k, donc sur les poids d'attention. Les valeurs transportent le contenu : les tourner le brouillerait sans rien apporter."
}
```

```mission
{
  "title": "La conclusion la plus drôle du deep learning",
  "url": "https://arxiv.org/abs/2002.05202",
  "steps": [
    "Ouvrez l'article « GLU Variants Improve Transformer » de Noam Shazeer",
    "Allez directement à la section Conclusions (dernière page)",
    "Lisez la dernière phrase"
  ],
  "question": "À quoi l'auteur attribue-t-il, avec humour, le succès des variantes GLU comme SwiGLU ?",
  "hint": "Il ne propose aucune explication théorique… et invoque une puissance supérieure.",
  "answer": "« We offer no explanation as to why these architectures seem to work; we attribute their success, as all else, to divine benevolence » : à la « bienveillance divine ». Leçon : beaucoup de choix d'architecture sont d'abord empiriques. Article de 2020, réponse stable.",
  "xp": 10
}
```

## 3. Normaliser : LayerNorm, RMSNorm, pré-norm

Au fil des couches, l'échelle des activations dérive. La **LayerNorm** (Ba, Kiros, Hinton, 2016) recentre et réduit chaque vecteur de token sur ses $d$ composantes, puis applique un gain $g$ et un biais $b$ appris :
$$\text{LN}(x) = g \odot \frac{x - \mu}{\sqrt{\sigma^2 + \varepsilon}} + b$$
La **RMSNorm** (Zhang & Sennrich, 2019) supprime le centrage et le biais et ne garde que la division par la moyenne quadratique :
$$\text{RMSNorm}(x) = g \odot \frac{x}{\sqrt{\frac{1}{d}\sum_i x_i^2 + \varepsilon}}$$
Les auteurs rapportent une qualité équivalente pour un coût moindre ; elle est disponible nativement depuis PyTorch 2.4 sous le nom `torch.nn.RMSNorm`.

> 🔢 **Exemple à la main** — Un vecteur de token $x = (1, 2, 3, 4)$, $d = 4$, gains $g = 1$, $b = 0$, $\varepsilon$ négligé ($\mu$ = moyenne, $\sigma^2$ = variance, $\odot$ = produit case par case).
> 1. LayerNorm : $\mu = 2{,}5$, $\sigma^2 = (2{,}25 + 0{,}25 + 0{,}25 + 2{,}25)/4 = 1{,}25$, $\sqrt{1{,}25} \approx 1{,}118$ → $(-1{,}342 ;\ -0{,}447 ;\ 0{,}447 ;\ 1{,}342)$.
> 2. RMSNorm : moyenne des carrés $(1 + 4 + 9 + 16)/4 = 7{,}5$, racine $\approx 2{,}739$ → $(0{,}365 ;\ 0{,}730 ;\ 1{,}095 ;\ 1{,}461)$ : même échelle « autour de 1 », mais sans recentrer.
>
> (Vérifié en NumPy.)

La **place** de la normalisation compte plus que sa formule. Dans le transformer original (*post-norm*), on normalisait après l'addition du résidu : $x \leftarrow \text{LN}(x + F(x))$. Xiong et al. (2020) ont montré qu'en post-norm les gradients près de la sortie sont très grands à l'initialisation, ce qui impose une phase de *warmup* délicate du taux d'apprentissage. En *pré-norm*, $x \leftarrow x + F(\text{LN}(x))$, le chemin résiduel reste une **identité pure** de l'entrée à la sortie, et l'entraînement de modèles profonds devient beaucoup plus stable. Comme la somme des résidus n'est jamais normalisée, on ajoute une **norme finale** juste avant la tête de sortie.

> 💡 **Autrement dit** — En post-norm, on mélange puis on « remet au propre » tout le dossier à chaque étape, ce qui rend les débuts d'entraînement instables. En pré-norm, chaque service lit une copie au bon volume du dossier, mais ajoute ses notes sur l'original : la voie principale reste intacte et le gradient y circule librement.

## 4. Le MLP : là où vivent la plupart des paramètres

Après l'attention, qui fait **communiquer** les tokens entre eux, chaque token passe **seul** dans un petit réseau à deux couches : c'est le *feed-forward* ou MLP. Karpathy résume : l'attention est la phase de communication, le MLP la phase de calcul. Les travaux d'interprétabilité suggèrent qu'une grande partie des connaissances factuelles (« Paris est la capitale de la France ») est stockée dans ces couches.

Le MLP classique est $W_2\,\text{GELU}(W_1 x)$ avec une couche cachée de largeur $4d$. Noam Shazeer (2020, arXiv 2002.05202) a montré que des **unités linéaires à porte** (*GLU variants*) font mieux. La variante **SwiGLU** calcule :
$$\text{SwiGLU}(x) = W_2\big(\text{SiLU}(W_1 x) \odot W_3 x\big), \qquad \text{SiLU}(z) = z\,\sigma(z)$$
La branche $W_3 x$ agit comme un **variateur** qui module, composante par composante, le signal de la branche activée. Comme il y a désormais trois matrices au lieu de deux, on réduit la largeur cachée à environ $\frac{8}{3}d$ pour garder le même budget : $3 \times d \times \frac{8}{3}d = 8d^2$, exactement comme $2 \times d \times 4d$.

> 🔢 **Exemple à la main** — SiLU : $\text{SiLU}(1) = 1 \times \sigma(1) \approx 0{,}731$ ; $\text{SiLU}(-1) \approx -0{,}269$. Pour une composante où $W_1 x = 1$ et $W_3 x = 2$ : $0{,}731 \times 2 \approx 1{,}462$ ; si la porte valait $W_3 x = 0$, la composante serait coupée. Budget avec $d = 4\,096$ : largeur $\lfloor 8 \times 4096/3 \rfloor = 10\,922$, donc $3 \times 4\,096 \times 10\,922 \approx 134{,}2$ millions de poids, contre $2 \times 4\,096 \times 16\,384 \approx 134{,}2$ millions pour un MLP classique de largeur $4d$. (Vérifié en Python.)

```quiz
{
  "q": "Un MLP SwiGLU utilise trois matrices au lieu de deux. Pour garder le même budget de paramètres qu'un MLP classique de largeur 4d, quelle largeur cachée choisit-on ?",
  "options": [
    "2 · d",
    "8/3 · d",
    "4 · d",
    "16/3 · d"
  ],
  "answer": 1,
  "explanation": "3 × d × (8/3)d = 8d², exactement comme 2 × d × 4d : on réduit la largeur pour compenser la troisième matrice."
}
```

## 5. Les connexions résiduelles : l'autoroute du gradient

Introduites par He et al. pour les ResNet (2015), les **connexions résiduelles** ajoutent l'entrée d'une sous-couche à sa sortie. Deux bénéfices décisifs pour un réseau de 32, 64 ou 100 couches :

- **Le gradient circule sans obstacle.** La dérivée de $x + F(x)$ par rapport à $x$ vaut $I + \partial F/\partial x$ : même si $\partial F/\partial x$ est petit, le terme identité transmet le gradient jusqu'aux premières couches (rappel de L112 sur la règle de la chaîne).
- **Le « flux résiduel »** (*residual stream*). On peut voir le vecteur $x$ comme un **bus** partagé : chaque sous-couche lit le bus (après normalisation), calcule une petite correction et l'y **ajoute**. Aucune couche n'écrase le travail des précédentes. Cette lecture est au cœur des méthodes d'interprétabilité mécaniste.

Analogie : un dossier client qui circule dans un cabinet. Chaque service (juridique, fiscal, social) ajoute ses annotations au dossier sans jamais jeter les pages précédentes. Le dossier final contient la contribution de tout le monde.

> 🎮 **Défi** — Un modèle a $d = 4096$, 32 couches, un vocabulaire de 128 000 tokens, une tête de sortie non partagée. En utilisant l'approximation « $12d^2$ par bloc », estimez son nombre total de paramètres. *(Réponse en fin de leçon.)*

## 6. Implémentation : un bloc « style 2026 » en PyTorch

Le code suivant assemble RMSNorm, RoPE, attention causale, SwiGLU et résidus en pré-norm. Il vérifie quatre propriétés : la forme de sortie, le nombre de paramètres par bloc (proche de $12d^2$), la propriété relative de RoPE, et l'égalité avec `nn.RMSNorm`. Il tourne en quelques secondes sur CPU.

```python
# bloc_transformer.py — L129 : un bloc « style 2026 » (pré-norm, RMSNorm, RoPE, SwiGLU)
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(0)

def positions_sinusoidales(T: int, d: int) -> torch.Tensor:
    """Encodage de Vaswani et al. (2017) : PE[p, 2i] = sin(p / 10000^(2i/d)), PE[p, 2i+1] = cos(...)."""
    p = torch.arange(T).float()[:, None]
    i = torch.arange(0, d, 2).float()[None, :]
    angle = p / (10000 ** (i / d))
    pe = torch.zeros(T, d)
    pe[:, 0::2], pe[:, 1::2] = torch.sin(angle), torch.cos(angle)
    return pe

class RMSNorm(nn.Module):
    """y = x / sqrt(moyenne(x²) + eps) * g  (pas de centrage, pas de biais)."""
    def __init__(self, d: int, eps: float = 1e-6):
        super().__init__()
        self.eps, self.g = eps, nn.Parameter(torch.ones(d))
    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps) * self.g

def rope_tables(T: int, d_k: int, base: float = 10000.0):
    """Angles θ_i = p / base^(2i/d_k) pour chaque position p et chaque paire de dimensions i."""
    inv_freq = 1.0 / (base ** (torch.arange(0, d_k, 2).float() / d_k))
    angles = torch.outer(torch.arange(T).float(), inv_freq)     # (T, d_k/2)
    return angles.cos(), angles.sin()

def appliquer_rope(x, cos, sin):
    """Fait tourner chaque paire (x_2i, x_2i+1) d'un angle qui dépend de la position."""
    x1, x2 = x[..., 0::2], x[..., 1::2]
    tourne = torch.stack((x1 * cos - x2 * sin, x1 * sin + x2 * cos), dim=-1)
    return tourne.flatten(-2)

class AttentionCausale(nn.Module):
    def __init__(self, d: int, h: int):
        super().__init__()
        self.h, self.d_k = h, d // h
        self.qkv = nn.Linear(d, 3 * d, bias=False)
        self.proj = nn.Linear(d, d, bias=False)
    def forward(self, x, cos, sin):
        B, T, D = x.shape
        q, k, v = self.qkv(x).split(D, dim=-1)
        q, k, v = (t.view(B, T, self.h, self.d_k).transpose(1, 2) for t in (q, k, v))
        q, k = appliquer_rope(q, cos[:T], sin[:T]), appliquer_rope(k, cos[:T], sin[:T])  # RoPE sur Q et K seulement
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.proj(y.transpose(1, 2).reshape(B, T, D))

class SwiGLU(nn.Module):
    """MLP à porte : W2( SiLU(W1 x) ⊙ W3 x ). Largeur ≈ 8/3 · d pour garder le budget d'un MLP 4·d."""
    def __init__(self, d: int):
        super().__init__()
        hidden = int(8 * d / 3)
        self.w1 = nn.Linear(d, hidden, bias=False)
        self.w3 = nn.Linear(d, hidden, bias=False)
        self.w2 = nn.Linear(hidden, d, bias=False)
    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))

class BlocTransformer(nn.Module):
    """x = x + Attn(Norm(x)) ; x = x + MLP(Norm(x))   (architecture pré-norm)."""
    def __init__(self, d: int, h: int):
        super().__init__()
        self.n1, self.attn = RMSNorm(d), AttentionCausale(d, h)
        self.n2, self.mlp = RMSNorm(d), SwiGLU(d)
    def forward(self, x, cos, sin):
        x = x + self.attn(self.n1(x), cos, sin)    # résidu 1 : « autoroute » du gradient
        x = x + self.mlp(self.n2(x))               # résidu 2
        return x

if __name__ == "__main__":
    d, h, T = 128, 4, 32
    cos, sin = rope_tables(T, d // h)
    pile = nn.ModuleList(BlocTransformer(d, h) for _ in range(4))
    x = torch.randn(2, T, d)
    for bloc in pile:
        x = bloc(x, cos, sin)
    print("Sortie :", tuple(x.shape))
    print("Paramètres par bloc :", sum(p.numel() for p in pile[0].parameters()), "(≈ 12·d² =", 12 * d * d, ")")

    # Propriété clé de RoPE : le score q·k ne dépend que de l'écart de positions
    cos64, sin64 = rope_tables(64, 16)
    q, k = torch.randn(16), torch.randn(16)
    def score(pq, pk):
        return (appliquer_rope(q, cos64[pq], sin64[pq]) @ appliquer_rope(k, cos64[pk], sin64[pk])).item()
    print(f"score(5, 2) = {score(5, 2):.4f} | score(45, 42) = {score(45, 42):.4f}  (même écart de 3)")

    # RMSNorm maison = torch.nn.RMSNorm
    z = torch.randn(3, d)
    print("Écart avec nn.RMSNorm :", (RMSNorm(d)(z) - nn.RMSNorm(d, eps=1e-6)(z)).abs().max().item())
    print("PE sinusoïdale (3 premières positions, 4 dims) :\n", positions_sinusoidales(3, 8)[:, :4].round(decimals=3))
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `positions_sinusoidales` : `torch.arange(T).float()[:, None]` a la forme `(T, 1)` et `i` la forme `(1, d/2)` ; leur division produit par diffusion `angle` `(T, d/2)`. `pe[:, 0::2]` désigne les colonnes paires (0, 2, 4…), `pe[:, 1::2]` les impaires.
> - `RMSNorm` : `x.pow(2).mean(-1, keepdim=True)` = moyenne des carrés de chaque token `(B, T, 1)` ; `torch.rsqrt` = $1/\sqrt{\cdot}$ ; `self.g` est un vecteur de $d$ gains appris (`nn.Parameter` le déclare comme paramètre).
> - `rope_tables` : `torch.outer(positions, inv_freq)` fabrique le tableau `(T, d_k/2)` de tous les angles $p \times \theta_i$ ; on renvoie leurs cosinus et sinus.
> - `appliquer_rope` : `x[..., 0::2]` et `x[..., 1::2]` séparent les composantes paires et impaires `(B, h, T, d_k/2)` ; `torch.stack(..., dim=-1)` les remet par paires `(…, d_k/2, 2)` et `flatten(-2)` les ré-entrelace `(…, d_k)`.
> - `AttentionCausale` : mêmes formes qu'en L128, `(2, 32, 128)` → `(2, 4, 32, 32)` (4 têtes de 32) ; `cos[:T]` ne garde que les $T$ premières positions.
> - `SwiGLU` : `hidden = int(8 * 128 / 3) = 341`. Décompte d'un bloc : attention $4 \times 128^2 = 65\,536$ ; SwiGLU $3 \times 128 \times 341 = 130\,944$ ; deux RMSNorm $2 \times 128 = 256$ ; total $196\,736$, le chiffre affiché.
> - `nn.ModuleList` range 4 blocs ; on y fait passer `x` `(2, 32, 128)` qui garde sa forme d'un bout à l'autre.

Résultat obtenu : sortie `(2, 32, 128)`, 196 736 paramètres par bloc pour $12d^2 = 196\,608$ (la différence vient des deux gains de RMSNorm et de l'arrondi de la largeur SwiGLU), deux scores RoPE strictement égaux et un écart nul avec `nn.RMSNorm`.

> 🔗 **Documentation officielle** — [torch.nn.RMSNorm](https://pytorch.org/docs/stable/generated/torch.nn.RMSNorm.html) 🇬🇧 et [Hugging Face Transformers](https://huggingface.co/docs/transformers/index) 🇬🇧 : les fichiers `modeling_*.py` des modèles Llama, Mistral ou Qwen contiennent des implémentations de référence de RoPE, RMSNorm et SwiGLU à comparer avec la vôtre.

```mission
{
  "title": "La taille du MLP en 2017",
  "url": "https://arxiv.org/abs/1706.03762",
  "steps": [
    "Ouvrez « Attention Is All You Need » (PDF)",
    "Lisez la section 3.3 « Position-wise Feed-Forward Networks »",
    "Vérifiez dans le tableau 3 la ligne « base »"
  ],
  "question": "Combien de couches N et quelle largeur cachée d_ff le modèle « base » de 2017 utilise-t-il ? Le ratio 4d du tableau de la section 1 est-il respecté ?",
  "hint": "Comparez d_ff à d_model = 512.",
  "answer": "N = 6 couches (côté encodeur comme côté décodeur), d_model = 512 et d_ff = 2 048, soit exactement 4 × d_model : le ratio 4d est respecté. Article de 2017, réponse stable (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 7. Compter les paramètres d'un LLM

Avec l'approximation par bloc ($4d^2$ pour l'attention + $8d^2$ pour le MLP $= 12d^2$), un modèle à $L$ couches compte environ :
$$N \approx 12\,L\,d^2 + \underbrace{V d}_{\text{embeddings}} + \underbrace{V d}_{\text{tête, si non partagée}}$$
Ce calcul « de coin de table » est un réflexe d'ingénieur : il permet de vérifier une fiche de modèle, d'estimer la mémoire (multipliez par 2 octets en BF16) ou le coût d'entraînement (L132). Il devient faux avec GQA (l'attention coûte moins de $4d^2$), avec une largeur MLP non standard, et bien sûr avec les MoE (L134), où il faut distinguer paramètres **totaux** et **actifs**.

> 🔢 **Exemple à la main** — Un petit modèle avec $d = 2\,048$, $L = 16$ couches, $V = 32\,000$ tokens et une tête non partagée :
> 1. Blocs : $12 \times 16 \times 2\,048^2 = 12 \times 16 \times 4\,194\,304 \approx 805$ millions.
> 2. Embeddings + tête : $2 \times 32\,000 \times 2\,048 \approx 131$ millions.
> 3. Total $\approx 936$ millions, soit un modèle « 0,9B » ; en BF16 (2 octets par paramètre) : $\approx 1{,}9$ Go de poids.
>
> (Vérifié en Python.)

```quiz
{
  "q": "Une fiche annonce un modèle dense : d = 4 096, 32 couches, vocabulaire de 128 000 tokens, tête de sortie partagée avec l'embedding. Quel ordre de grandeur de paramètres attendez-vous ?",
  "options": [
    "Environ 7 milliards",
    "Environ 0,7 milliard",
    "Environ 70 milliards",
    "Environ 1,6 milliard"
  ],
  "answer": 0,
  "explanation": "12 × 32 × 4 096² ≈ 6,4 milliards pour les blocs, plus 128 000 × 4 096 ≈ 0,5 milliard pour l'embedding (compté une seule fois puisqu'il est partagé) : environ 7 milliards. Avec GQA, un peu moins."
}
```

## 🧪 Exercice pratique

**Consigne.** Montrez expérimentalement l'utilité des connexions résiduelles.
1. Empilez 24 blocs `BlocTransformer(d=64, h=4)` ; propagez un lot aléatoire `(4, 16, 64)`, calculez `perte = sortie.pow(2).mean()`, rétropropagez, puis mesurez la norme du gradient des poids `qkv` de **chaque** bloc.
2. Créez une variante `BlocSansResidu` où `x = attn(n1(x))` puis `x = mlp(n2(x))`. Refaites la mesure.
3. Comparez le rapport « norme du gradient du bloc 1 / norme du gradient du bloc 24 » dans les deux cas et rédigez deux phrases d'interprétation.

**Critères de réussite.** (a) Le code s'exécute sans erreur sur CPU ; (b) avec résidus, les normes de gradient restent du même ordre de grandeur d'un bout à l'autre de la pile (rapport proche de 1 à 10) ; sans résidus, elles diffèrent de plusieurs ordres de grandeur ; (c) l'interprétation mentionne le terme identité de la dérivée de $x + F(x)$.

<details><summary>Corrigé</summary>

```python
import torch, torch.nn as nn
from bloc_transformer import BlocTransformer, rope_tables

class BlocSansResidu(BlocTransformer):
    def forward(self, x, cos, sin):
        x = self.attn(self.n1(x), cos, sin)
        return self.mlp(self.n2(x))

def normes_grad(classe, n=24, d=64, h=4, T=16):
    torch.manual_seed(0)
    pile = nn.ModuleList(classe(d, h) for _ in range(n))
    cos, sin = rope_tables(T, d // h)
    x = torch.randn(4, T, d)
    for b in pile:
        x = b(x, cos, sin)
    x.pow(2).mean().backward()
    return [b.attn.qkv.weight.grad.norm().item() for b in pile]

for classe in (BlocTransformer, BlocSansResidu):
    g = normes_grad(classe)
    print(f"{classe.__name__:16s} bloc 1 : {g[0]:.2e} | bloc 24 : {g[-1]:.2e} | rapport : {g[0] / g[-1]:.1e}")
```
Résultat obtenu sur CPU : avec résidus, bloc 1 ≈ 1,05 et bloc 24 ≈ 0,52 (rapport ≈ 2) ; sans résidus, bloc 1 ≈ 426 et bloc 24 ≈ 0,07 (rapport ≈ 6 400). Sans résidu, le gradient du bloc 1 est le produit de 48 jacobiennes successives : selon leurs normes, il **explose** (c'est le cas ici) ou **s'évanouit**, et aucun taux d'apprentissage unique ne convient à toutes les couches. Avec résidus, la dérivée $I + \partial F/\partial x$ fournit un chemin direct qui garde le signal à une échelle comparable dans toute la pile : c'est ce qui rend entraînables des modèles de 60 couches et plus.
</details>

## ✅ Auto-évaluation express
1. Pourquoi RoPE s'applique-t-il dans chaque couche d'attention, et non une seule fois à l'entrée comme les positions sinusoïdales ?
2. Quelle opération RMSNorm supprime-t-elle par rapport à LayerNorm ?
3. Pourquoi la largeur cachée d'un SwiGLU est-elle d'environ $\frac{8}{3}d$ et non $4d$ ?

## 📚 Pour aller plus loin
- [Su et al. (2021) — RoFormer / RoPE](https://arxiv.org/abs/2104.09864) 🇬🇧 — la démonstration complète de la propriété relative.
- [Shazeer (2020) — GLU Variants Improve Transformer](https://arxiv.org/abs/2002.05202) 🇬🇧 — quatre pages, très lisibles, avec une conclusion célèbre pour son humour.
- [Xiong et al. (2020) — Pré-norm vs post-norm](https://arxiv.org/abs/2002.04745) 🇬🇧 — l'analyse des gradients à l'initialisation.
- [He et al. (2015) — Deep Residual Learning](https://arxiv.org/abs/1512.03385) 🇬🇧 — l'origine des connexions résiduelles.
- [Stanford CS336 — supports de cours exécutables](https://github.com/stanford-cs336/lectures) 🇬🇧 — séance 3 sur les choix d'architecture et d'hyperparamètres (devoirs sous licence MIT).

**Réponses de l'auto-évaluation.** 1. Parce que RoPE agit sur le produit scalaire $q \cdot k$ : il faut tourner les requêtes et clés propres à chaque couche pour que le score dépende de la distance relative ; une addition unique à l'entrée se « dilue » au fil des couches. 2. Le centrage (soustraction de la moyenne) et le biais additif. 3. SwiGLU utilise trois matrices au lieu de deux ; avec une largeur $\frac{8}{3}d$, le total ($8d^2$) reste égal à celui d'un MLP classique de largeur $4d$. **Défi** : $12 \times 32 \times 4096^2 \approx 6{,}44$ milliards, plus $2 \times 128\,000 \times 4096 \approx 1{,}05$ milliard, soit environ **7,5 milliards** de paramètres (l'ordre de grandeur d'un modèle « 8B » ; la valeur exacte dépend de GQA et de la largeur MLP réelle).

> ✅ **Si vous ne retenez que 3 choses** — 1. Un bloc décodeur moderne = $x \leftarrow x + \text{Attn}(\text{RMSNorm}(x))$ puis $x \leftarrow x + \text{SwiGLU}(\text{RMSNorm}(x))$, répété $L$ fois, avec une norme finale avant la tête. 2. RoPE fait tourner $Q$ et $K$ selon la position, si bien que le score ne dépend que de l'écart entre tokens ; les connexions résiduelles (pré-norm) gardent un chemin direct pour le gradient. 3. Ordre de grandeur des paramètres : $\approx 12 L d^2 + 2Vd$ (moins avec GQA, à distinguer total/actif pour les MoE).

> 🗺️ **Et maintenant ?** — Le modèle sait maintenant traiter des tokens… mais que sont exactement ces tokens ? La leçon L130 ouvre la boîte de la tokenisation BPE.
