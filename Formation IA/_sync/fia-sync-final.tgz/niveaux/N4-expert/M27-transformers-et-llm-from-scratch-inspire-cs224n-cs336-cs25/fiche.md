---
module: M27
title: "Fiche mémo — Transformers et LLM from scratch (inspiré CS224N, CS336, CS25)"
---
# Fiche mémo — M27 · Transformers et LLM from scratch (inspiré CS224N, CS336, CS25)

> En une phrase : un LLM empile des blocs « attention causale + MLP » sur un flux résiduel, apprend à prédire le token suivant, puis est post-entraîné pour devenir un assistant.

## Les 7 idées à retenir
1. Requête, clé, valeur : la clé sert à être trouvé, la valeur à être transmise ; le masque causal interdit de lire le futur (`L128`).
2. Bloc 2026 : pré-norm RMSNorm, RoPE sur Q et K seulement, SwiGLU, résidus, souvent GQA (`L129`).
3. Le BPE au niveau des octets n'a jamais de mot inconnu ; le français paie une « taxe » de tokens (`L130`).
4. Contrôle n° 1 d'un GPT : perte initiale ≈ $\ln V$ ; train et validation en deux blocs contigus (`L131`).
5. Chinchilla : paramètres et tokens croissent ensemble (~20 tokens/paramètre) ; en 2026, on sur-entraîne de petits modèles pour l'inférence (`L132`).
6. SFT donne le format, préférences (RLHF, DPO) ce qui plaît, RLVR (GRPO) ce qui est juste (`L133`).
7. MoE : la mémoire suit le total, le calcul suit les actifs ; un contexte annoncé n'est pas un contexte utilisé (`L134`).

## Le schéma à connaître
```mermaid
flowchart LR
  T["Tokens BPE"] --> E["Embedding"]
  E --> B1["x + Attn(RMSNorm(x)), RoPE, masque causal"]
  B1 --> B2["x + SwiGLU(RMSNorm(x))"]
  B2 -. "× L blocs" .-> B1
  B2 --> H["Norm finale + tête → logits"]
  H --> P["Pré-entraînement → SFT → DPO / RLVR"]
```

## Les formules essentielles
| Formule | Intuition en mots simples |
|---|---|
| $\text{softmax}(QK^\top/\sqrt{d_k})V$, scores $-\infty$ si $j > i$ | Chaque token consulte les précédents et mélange leurs contenus, sans « tout ou rien ». |
| $\text{SwiGLU}(x) = W_2(\text{SiLU}(W_1x) \odot W_3x)$ | Une branche active, une branche variateur qui la module. |
| $N \approx 12Ld^2 + 2Vd$ | Compter les paramètres d'un LLM au coin de la table. |
| $C \approx 6ND$ | Chaque token fait travailler chaque paramètre six fois (2 à l'aller, 4 au retour). |
| $L(N,D) = E + A/N^\alpha + B/D^\beta$ | Hasard irréductible + pénalité « modèle trop petit » + pénalité « trop peu de données ». |
| $\mathcal{L}_{\text{DPO}} = -\log\sigma\big(\beta[\log\frac{\pi_\theta(y_w)}{\pi_{\text{ref}}(y_w)} - \log\frac{\pi_\theta(y_l)}{\pi_{\text{ref}}(y_l)}]\big)$ | Rendre la réponse préférée plus probable que la rejetée, par rapport à la référence. |
| $A_i = (r_i - \bar r)/\sigma_r$ | GRPO : le groupe de réponses sert de point de comparaison. |
| KV $= 2 \times \text{couches} \times \text{têtes}_{KV} \times d_{\text{tête}} \times \text{tokens} \times \text{octets}$ | Les fiches de lecture gardées pour chaque token déjà lu, à chaque couche. |

## Vocabulaire express
| Terme | En clair |
|---|---|
| Reward hacking | La politique trompe le juge au lieu de s'améliorer. |
| « 119B-A6B » | 119 milliards au total, 6 milliards actifs par token. |

## Les pièges classiques
- Diviser par $d_k$ au lieu de $\sqrt{d_k}$ : attention presque uniforme.
- Appliquer RoPE aux valeurs $V$.
- Prendre « 20 tokens par paramètre » pour une loi physique, ou croire que le RLHF ajoute des connaissances.
- Charger 800 pages dans 1M de tokens « parce que ça rentre » : préférez souvent un RAG.

## Les commandes / chiffres / dates utiles
```python
y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
enc = tiktoken.get_encoding("o200k_base"); n = len(enc.encode(texte))
self.tete.weight = self.tok.weight          # weight tying
torch.nn.RMSNorm(d)                         # natif depuis PyTorch 2.4
```
- Mémoire naïve de $QK^\top$ en float32 : 4 Mo à 1 024 tokens, 4,3 Go à 32 768.
- KV cache GQA (32 couches, 8 têtes KV, dim. 128, BF16) à 32 768 tokens : ≈ 4,3 Go par utilisateur.
- H100 : ~989 TFLOPS BF16, 40 % de MFU, 2,73 €/h → 1B × 20B tokens ≈ 230 €.
- Nov. 2026 : Mistral Small 4 119B/6B (Apache 2.0) ; gpt-oss-120b tient sur un GPU de 80 Go en MXFP4.
- Gemma 4 : audio en E2B/E4B seulement ; 26B-A4B et 31B : texte et image.
- Température sur Claude : refusée à partir de 4.7, et sur tous les modèles avec l'API 2026-10-21 (SDK v2).

## Pour aller plus loin
- [Stanford CS336 — Language Modeling from Scratch](https://cs336.stanford.edu/)
- [Vaswani et al. (2017) — Attention Is All You Need](https://arxiv.org/abs/1706.03762)
- [Hoffmann et al. (2022) — Chinchilla](https://arxiv.org/abs/2203.15556)

## Auto-test (3 questions — réponses en bas de fiche)
1. Vocabulaire de 96 caractères, perte de 87 à l'itération 0 : que faire ?
2. Combien de FLOPs pour 70B paramètres et 1 400B tokens ?
3. Que supprime DPO par rapport au RLHF avec PPO ?

---
**Réponses.** 1. S'arrêter : attendu $\ln 96 \approx 4{,}56$, vérifier l'initialisation (écart-type 0,02). 2. $6 \times 7\cdot10^{10} \times 1{,}4\cdot10^{12} \approx 5{,}9 \times 10^{23}$. 3. Le modèle de récompense séparé et la boucle de RL.
