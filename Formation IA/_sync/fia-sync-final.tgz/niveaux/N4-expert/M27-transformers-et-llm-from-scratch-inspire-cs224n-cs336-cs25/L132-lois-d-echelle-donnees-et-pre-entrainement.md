---
id: L132
module: M27
level: N4
title: "Lois d'échelle, données et pré-entraînement"
minutes: 60
objectives:
  - "Expliquer les lois d'échelle de Kaplan et al. (2020) et de Hoffmann et al. (2022, « Chinchilla ») et leurs conclusions divergentes"
  - "Calculer le budget de calcul d'un pré-entraînement avec la règle C ≈ 6ND et le convertir en heures-GPU et en euros"
  - "Décrire les étapes d'un pipeline de données de pré-entraînement (extraction, filtrage, déduplication, décontamination, mélange)"
  - "Évaluer un plan de pré-entraînement au regard du compromis coût d'entraînement / coût d'inférence"
skills: ["C4.3"]
sources:
  - { title: "Kaplan et al. (2020) — Scaling Laws for Neural Language Models", url: "https://arxiv.org/abs/2001.08361", lang: "en" }
  - { title: "Hoffmann et al. (2022) — Training Compute-Optimal Large Language Models (Chinchilla)", url: "https://arxiv.org/abs/2203.15556", lang: "en" }
  - { title: "Brown et al. (2020) — Language Models are Few-Shot Learners (GPT-3)", url: "https://arxiv.org/abs/2005.14165", lang: "en" }
  - { title: "Penedo et al. (2024) — The FineWeb Datasets", url: "https://arxiv.org/abs/2406.17557", lang: "en" }
  - { title: "Stanford CS336 Spring 2026 — séances 9, 11, 13, 14 ; devoirs A3 et A4", url: "https://cs336.stanford.edu/", lang: "en" }
  - { title: "Stanford CS324 — Understanding and Developing LLMs", url: "https://crfm.stanford.edu/courses.html", lang: "en" }
---

# Lois d'échelle, données et pré-entraînement

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 27

## 🎯 Ce que vous saurez faire
- Énoncer ce qu'est une **loi d'échelle** (*scaling law*) et lire une courbe log-log de perte.
- Expliquer pourquoi Kaplan et al. (2020) recommandaient de grossir surtout le modèle, et pourquoi Chinchilla (2022) a corrigé le tir.
- Calculer en une ligne le **budget de calcul** d'un entraînement ($C \approx 6ND$) et le traduire en heures-GPU et en euros.
- Décrire le chemin qui mène de pages web brutes à des milliers de milliards de tokens d'entraînement propres.
- Argumenter pourquoi les modèles de 2026 sont presque tous « sur-entraînés » par rapport à l'optimum de Chinchilla.

> 🧭 **En clair** — Une loi d'échelle, c'est une règle de cuisine pour les banquets géants : si je double les ingrédients, de combien le plat s'améliore-t-il ? Les chercheurs ont découvert que la qualité d'un modèle progresse de façon très prévisible quand on augmente trois choses : sa taille (le nombre de « boutons de réglage »), la quantité de texte qu'il lit et la puissance de calcul. En 2022, l'équipe Chinchilla a montré qu'on avait trop grossi les cerveaux sans leur donner assez à lire : mieux vaut un modèle plus petit qui lit beaucoup plus. Aujourd'hui, on va encore plus loin, car un modèle petit mais très entraîné coûte moins cher à chaque question posée. Et tout commence par les données : des milliards de pages web triées, nettoyées et dédoublonnées.

Votre mini-GPT de L131 compte 0,8 million de paramètres et a vu quelques millions de caractères. Les modèles de pointe comptent des centaines de milliards, voire des milliers de milliards de paramètres (Kimi K3 : 2,8T au total, nov. 2026, voir L134), et voient des dizaines de milliers de milliards de tokens. Entre les deux, aucune magie : les **mêmes** équations, poussées sur six à sept ordres de grandeur. Le miracle, c'est que ce passage à l'échelle soit **prévisible**. C'est ce que cette leçon explique, en s'inspirant des séances 9 et 11 (*scaling laws*), 13 et 14 (données) de Stanford CS336 et de ses devoirs A3 (ajuster une loi d'échelle) et A4 (de Common Crawl aux données de pré-entraînement).

## 1. Le pari de l'échelle

En 2020, OpenAI publie GPT-3 : **175 milliards de paramètres**, entraîné sur **300 milliards de tokens** (Brown et al., arXiv 2005.14165). Sans aucun fine-tuning, le modèle traduit, résume, écrit du code à partir de quelques exemples placés dans le prompt (*few-shot learning*). La communauté découvre que la taille seule fait émerger des capacités que personne n'avait programmées.

Ce pari reposait sur une étude publiée quelques mois plus tôt par la même équipe. Elle répondait à une question d'ingénieur très concrète : **si j'ai un budget de calcul donné, comment le dépenser ?** Plus de paramètres ? Plus de données ? Plus d'itérations ?

## 2. Kaplan et al. (2020) : la perte suit des lois de puissance

Jared Kaplan et ses coauteurs (arXiv 2001.08361) entraînent des centaines de modèles de tailles variées et observent que la perte de test $L$ décroît comme une **loi de puissance** de trois quantités, tant que les deux autres ne sont pas limitantes :

$$L(N) \propto N^{-\alpha_N},\qquad L(D) \propto D^{-\alpha_D},\qquad L(C) \propto C^{-\alpha_C}$$

avec $N$ le nombre de paramètres (hors embeddings), $D$ le nombre de tokens d'entraînement et $C$ le calcul. Les exposants mesurés sont petits ($\alpha_N \approx 0{,}076$, $\alpha_D \approx 0{,}095$) : pour diviser l'écart à la perte minimale par deux, il faut multiplier la taille par plusieurs milliers. Mais la régularité est stupéfiante : sur un graphique log-log, on obtient des **droites** sur sept ordres de grandeur.

> 💡 **Autrement dit** — Une loi de puissance devient une **droite** sur un graphique à échelles logarithmiques : chaque fois que l'on multiplie la taille par 10, la perte baisse d'un même pourcentage. C'est prévisible, mais cher : avec des exposants aussi petits, il faut multiplier les moyens par des facteurs énormes pour gagner un peu.

> 🧭 **Pré-requis express** — **$\propto$** se lit « proportionnel à » ; **$N^{-\alpha_N}$** est une puissance **négative**, c'est-à-dire $1/N^{\alpha_N}$ : plus $N$ grandit, plus le terme rétrécit, mais lentement si $\alpha$ est petit. Un graphique **log-log** gradue les deux axes en puissances de 10 (1, 10, 100, 1 000…), si bien que chaque « cran » représente une multiplication par 10.

> 🔢 **Exemple à la main** — Avec $\alpha_N = 0{,}076$ : multiplier la taille par 10 multiplie la perte (au-dessus de son plancher) par $10^{-0{,}076} \approx 0{,}84$, soit −16 %. Pour la diviser par 2, il faut un facteur $2^{1/0{,}076} = 2^{13{,}2} \approx 9\,000$ sur la taille : d'où « plusieurs milliers ». (Vérifié en Python.)

Leur recommandation d'allocation : quand le budget augmente, grossir **surtout le modèle** et un peu les données. D'où GPT-3, très grand et relativement peu entraîné (environ 1,7 token par paramètre).

> 💡 **À retenir** — Une loi d'échelle permet d'**extrapoler** : on entraîne une famille de petits modèles peu coûteux, on ajuste une droite en log-log, et l'on prédit la perte d'un modèle 100 fois plus grand avant de dépenser des millions. Toute l'industrie planifie ainsi ses entraînements.

```quiz
{
  "q": "Selon Kaplan et al. (2020), comment fallait-il dépenser un budget de calcul croissant ?",
  "options": [
    "Surtout en données, très peu en taille de modèle",
    "Surtout en taille de modèle, un peu en données",
    "Uniquement en allongeant la durée d'entraînement",
    "Exactement à parts égales entre modèle et données"
  ],
  "answer": 1,
  "explanation": "D'où GPT-3, très grand et peu entraîné (environ 1,7 token par paramètre). Chinchilla corrigera ce conseil deux ans plus tard."
}
```

## 3. Chinchilla (2022) : il manquait des données

En 2022, Jordan Hoffmann et l'équipe de DeepMind (arXiv 2203.15556) refont l'expérience avec un protocole plus soigné, notamment en adaptant la planification du taux d'apprentissage à la durée de chaque entraînement. Leur conclusion contredit Kaplan : à budget optimal, **$N$ et $D$ doivent croître au même rythme**, environ comme $C^{0,5}$ chacun. La règle pratique qui en découle est restée célèbre : environ **20 tokens d'entraînement par paramètre**.

La démonstration est spectaculaire : **Chinchilla** (70 milliards de paramètres, 1 400 milliards de tokens) bat **Gopher** (280 milliards de paramètres, 300 milliards de tokens), avec le même budget de calcul et un modèle quatre fois plus petit, donc quatre fois moins cher à utiliser. Les grands modèles de l'époque étaient massivement **sous-entraînés**.

Les auteurs proposent aussi une forme paramétrique de la perte :
$$L(N, D) = E + \frac{A}{N^{\alpha}} + \frac{B}{D^{\beta}}$$
où $E$ est l'entropie irréductible du langage (même un modèle parfait ne peut prédire un texte humain avec certitude), et les deux autres termes mesurent les pénalités d'un modèle trop petit et d'un entraînement trop court. Les valeurs publiées pour cette « approche 3 » sont $E = 1{,}69$, $A = 406{,}4$, $B = 410{,}7$, $\alpha = 0{,}34$, $\beta = 0{,}28$.

> 🔢 **Exemple à la main** — Formule paramétrique appliquée aux deux modèles du paragraphe précédent.
> 1. Chinchilla ($N = 7 \times 10^{10}$, $D = 1{,}4 \times 10^{12}$) : $A/N^{0{,}34} \approx 0{,}083$ et $B/D^{0{,}28} \approx 0{,}163$, donc $L \approx 1{,}69 + 0{,}083 + 0{,}163 \approx 1{,}937$.
> 2. Gopher ($N = 2{,}8 \times 10^{11}$, $D = 3 \times 10^{11}$) : $0{,}052 + 0{,}251$, donc $L \approx 1{,}993$.
>
> Gopher a une pénalité « modèle trop petit » plus faible (0,052) mais une pénalité « pas assez de données » bien plus forte (0,251) : au total, Chinchilla gagne. (Vérifié en Python.)

| | Kaplan et al. (2020) | Hoffmann et al. (2022) |
|---|---|---|
| Allocation optimale | $N$ croît plus vite que $D$ | $N$ et $D$ croissent ensemble ($\approx C^{0,5}$) |
| Tokens par paramètre (ordre de grandeur) | quelques-uns | ~20 |
| Modèle emblématique | GPT-3 (175 B, 300 B tokens) | Chinchilla (70 B, 1,4 T tokens) |
| Cause principale de l'écart | planification du taux d'apprentissage non adaptée à la durée, petits modèles | protocole corrigé, gamme plus large |

> ⚠️ **Piège fréquent** — Appliquer « 20 tokens par paramètre » comme une loi physique. C'est un **ordre de grandeur** issu d'un protocole, d'un jeu de données et d'une architecture précis. Le script de la section 6 montre d'ailleurs que la formule paramétrique publiée donne un rapport $D/N$ qui **augmente** avec le budget (de ~30 à plus de 100), ce qui ne colle pas exactement avec la règle des 20 : les trois méthodes d'estimation de l'article ne concordent pas parfaitement, et une tentative de réplication publiée en 2024 a remis en cause certaines valeurs ajustées. Retenez la leçon qualitative : **ne sous-entraînez pas vos modèles**.

```mission
{
  "title": "La règle de Chinchilla, dans le texte",
  "url": "https://arxiv.org/abs/2203.15556",
  "steps": [
    "Ouvrez la page arXiv de Hoffmann et al. (2022)",
    "Lisez l'abstract en entier",
    "Repérez la phrase sur le « doubling » et celle qui compare Chinchilla à Gopher"
  ],
  "question": "Quelle règle d'allocation l'abstract énonce-t-il, et combien de fois moins de paramètres Chinchilla compte-t-il que Gopher, à budget de calcul égal ?",
  "hint": "Cherchez « for every doubling of model size ».",
  "answer": "Taille du modèle et nombre de tokens doivent croître ensemble : à chaque doublement de la taille, doubler aussi les tokens. Chinchilla (70B) utilise le même budget que Gopher (280B) avec 4 fois moins de paramètres et 4 fois plus de données. Article de 2022, réponse stable.",
  "xp": 15
}
```

## 4. Au-delà de Chinchilla : penser au coût d'inférence

Chinchilla optimise **le coût d'entraînement seul**. Or un modèle populaire est entraîné une fois et interrogé des milliards de fois. Il devient alors rentable d'entraîner un modèle **plus petit, beaucoup plus longtemps** que l'optimum de Chinchilla : la perte finale est un peu moins bonne qu'avec un modèle plus grand au même budget, mais chaque requête coûte bien moins cher.

C'est la stratégie dominante depuis 2023. Meta indique avoir entraîné Llama 3 8B sur plus de 15 000 milliards de tokens, soit près de 1 900 tokens par paramètre, presque cent fois la règle de Chinchilla. Les petits modèles ouverts de 2026 qui tiennent sur un portable (Qwen3.8-27B, Gemma 4, gpt-oss-20b, nov. 2026, voir le module 29) sont tous le fruit de ce « sur-entraînement » délibéré. La conséquence est un **mur des données** : les textes humains de qualité disponibles sur le web ne sont pas infinis, d'où l'essor des données **synthétiques**, générées ou réécrites par des modèles, que la séance 14 de CS336 aborde explicitement.

```quiz
{
  "q": "Votre client va interroger son modèle des millions de fois par jour. À budget d'entraînement fixé, que privilégier ?",
  "options": [
    "Le modèle le plus grand possible, peu entraîné",
    "Exactement 20 tokens par paramètre, sans exception",
    "Un modèle plus petit, entraîné bien au-delà de Chinchilla",
    "Aucun pré-entraînement, uniquement du fine-tuning"
  ],
  "answer": 2,
  "explanation": "Chinchilla minimise le coût d'entraînement seul. Quand l'inférence domine la facture, un modèle plus petit et « sur-entraîné » coûte moins cher à chaque requête (stratégie de Llama 3 8B)."
}
```

## 5. Les données : de Common Crawl aux tokens

« *Garbage in, garbage out* » n'a jamais été aussi vrai. Le séminaire CS25 V6 a d'ailleurs consacré une séance à « l'avenir du pré-entraînement », présentée par Mistral. Un pipeline typique, comme celui que les étudiants de CS336 construisent dans le devoir A4, ressemble à ceci :

```
Common Crawl (archives WARC du web)
   │ 1. extraction du texte principal (retirer menus, publicités, HTML)
   ▼
   │ 2. identification de la langue (garder fr, en, code…)
   ▼
   │ 3. filtres de qualité : heuristiques (longueur, ratio de symboles, lignes répétées)
   │    + classifieur de qualité (« ressemble-t-il à un texte éducatif ? »)
   ▼
   │ 4. filtres de sécurité et de conformité : contenus toxiques, données personnelles, sites ayant refusé la collecte
   ▼
   │ 5. déduplication : exacte (hachage) et approchée (MinHash / LSH)
   ▼
   │ 6. décontamination : retirer les textes des benchmarks d'évaluation
   ▼
   │ 7. mélange (web, code, mathématiques, livres, articles scientifiques, données synthétiques) et tokenisation
   ▼
 Des milliers de milliards de tokens prêts pour l'entraînement
```

Le jeu de données ouvert **FineWeb** de Hugging Face (Penedo et al., 2024, arXiv 2406.17557) documente précisément ces étapes et totalise environ 15 000 milliards de tokens de web anglais filtré. Ses auteurs montrent qu'un filtrage soigneux améliore nettement les modèles, à nombre de tokens égal. La **déduplication** est particulièrement importante : des textes répétés poussent le modèle à mémoriser (vous l'avez constaté en L131 avec la fable répétée), et des copies de benchmarks dans les données faussent les évaluations.

Pour le français, la part du web est beaucoup plus faible que pour l'anglais : les producteurs de modèles ouverts constituent des sous-corpus multilingues dédiés. Côté réglementation, le règlement européen sur l'IA (AI Act) impose aux fournisseurs de modèles d'IA à usage général de publier un résumé suffisamment détaillé des contenus utilisés pour l'entraînement et de mettre en place une politique de respect du droit d'auteur ; ces points sont détaillés dans les modules de conformité de la formation.

```mission
{
  "title": "FineWeb en deux chiffres",
  "url": "https://arxiv.org/abs/2406.17557",
  "steps": [
    "Ouvrez la page arXiv de l'article FineWeb (Penedo et al., 2024)",
    "Lisez l'abstract",
    "Repérez le nombre de snapshots Common Crawl et la taille de FineWeb-Edu"
  ],
  "question": "À partir de combien de snapshots Common Crawl FineWeb est-il construit, et combien de tokens compte son sous-ensemble éducatif FineWeb-Edu ?",
  "hint": "Deux nombres : un nombre de snapshots et une quantité en « trillion tokens ».",
  "answer": "96 snapshots de Common Crawl (15 000 milliards de tokens au total) ; FineWeb-Edu compte 1 300 milliards (1,3T) de tokens, filtrés par un classifieur de qualité éducative. Chiffres de l'article de 2024 ; le jeu publié sur le Hub peut avoir été enrichi depuis.",
  "xp": 15
}
```

> 🔗 **Documentation officielle** — [Stanford CS336](https://cs336.stanford.edu/) 🇬🇧 (devoir A4 : Common Crawl → données de pré-entraînement) · [Stanford CRFM — cours CS324](https://crfm.stanford.edu/courses.html) 🇬🇧 (chapitres sur les données, les lois d'échelle et le coût environnemental).

## 6. Le calcul : FLOPs, heures-GPU, euros

Une règle d'une simplicité remarquable estime le calcul d'entraînement d'un transformer dense :
$$C \approx 6\,N\,D \quad \text{FLOPs}$$
Pour chaque paramètre et chaque token, la passe avant coûte environ 2 opérations (une multiplication, une addition) et la passe arrière environ 4 (gradients par rapport aux activations et aux poids). On divise ensuite par le débit **réellement obtenu** du matériel : un GPU H100 offre environ 989 TFLOPS en BF16 dense sur sa fiche technique, mais un entraînement bien optimisé n'en exploite que 35 à 50 % (c'est le *MFU*, *Model FLOPs Utilization*). Le dossier de recherche de la formation relève des tarifs cloud de 1,49 à 2,99 $/h pour un H100 et de 2,73 €/h chez Scaleway (H100 PCIe, nov. 2026).

> 💡 **Autrement dit** — Chaque token lu fait « travailler » chaque paramètre environ six fois : deux opérations à l'aller (la passe avant), quatre au retour pour calculer les corrections (la passe arrière). Multipliez par le nombre de paramètres et le nombre de tokens : vous obtenez la facture de calcul.

> 🔢 **Exemple à la main** — **FLOPs** = nombre d'opérations sur des nombres à virgule ; **TFLOPS** = $10^{12}$ opérations par seconde ; `1e20` = $10^{20}$. Modèle de 1 milliard de paramètres, 20 milliards de tokens :
> 1. $C = 6 \times 10^9 \times 2 \times 10^{10} = 1{,}2 \times 10^{20}$ FLOPs.
> 2. Débit réel d'un H100 : $989 \times 10^{12} \times 0{,}40 \approx 3{,}96 \times 10^{14}$ FLOPs/s.
> 3. Durée : $1{,}2 \times 10^{20} / 3{,}96 \times 10^{14} \approx 303\,000$ s $\approx 84$ heures-GPU, soit $84 \times 2{,}73 \approx 230$ €.
>
> C'est le chiffre annoncé plus bas. (Vérifié en Python.)

```python
# lois_echelle.py — L132 : budget de calcul, allocation Chinchilla et ajustement d'une loi de puissance
import math
import torch

# 1) Règle C ≈ 6·N·D (FLOPs d'entraînement : 2 pour l'avant, 4 pour l'arrière, par paramètre et par token)
def flops_entrainement(N, D):
    return 6 * N * D

# 2) Loi paramétrique de Hoffmann et al. (2022) : L(N, D) = E + A/N^α + B/D^β (valeurs publiées, « approche 3 »)
E, A, B, alpha, beta = 1.69, 406.4, 410.7, 0.34, 0.28
def perte_chinchilla(N, D):
    return E + A / N**alpha + B / D**beta

def allocation_optimale(C, pas=400):
    """Cherche N minimisant L(N, C/(6N)) à budget C fixé (balayage logarithmique)."""
    meilleurs = min(
        ((perte_chinchilla(N, C / (6 * N)), N) for N in (10 ** (6 + 7 * i / pas) for i in range(pas))),
    )
    L, N = meilleurs
    return N, C / (6 * N), L

print(f"{'Budget (FLOPs)':>14} | {'N optimal':>10} | {'D optimal':>10} | {'D/N':>5} | perte")
for C in (1e19, 1e21, 1e23, 1e25):
    N, D, L = allocation_optimale(C)
    print(f"{C:14.0e} | {N / 1e9:8.2f} B | {D / 1e9:8.0f} B | {D / N:5.0f} | {L:.3f}")

# 3) Combien coûte un modèle de 1 B paramètres entraîné « à la Chinchilla » (20 tokens/paramètre) ?
N, D = 1e9, 20e9
C = flops_entrainement(N, D)
debit = 989e12 * 0.40          # H100 : ~989 TFLOPS BF16 dense, à 40 % d'utilisation réelle (MFU)
heures = C / debit / 3600
print(f"\n1 B params × 20 B tokens = {C:.1e} FLOPs ≈ {heures:.0f} h-GPU H100 ≈ {heures * 2.73:.0f} € à 2,73 €/h")

# 4) Ajuster une loi de puissance L(N) = a·N^(-b) + c sur des mesures (ici simulées avec bruit)
torch.manual_seed(0)
Ns = torch.tensor([1e6, 3e6, 1e7, 3e7, 1e8, 3e8])
mesures = 2.0 + 30 * Ns ** -0.25 + 0.01 * torch.randn(6)
log_a, log_b, c = (torch.zeros(1, requires_grad=True) for _ in range(3))
opt = torch.optim.Adam([log_a, log_b, c], lr=0.05)
for _ in range(3000):
    pred = log_a.exp() * Ns ** (-log_b.exp()) + c
    perte = ((pred - mesures) ** 2).mean()
    opt.zero_grad(); perte.backward(); opt.step()
print(f"Ajustement : a={log_a.exp().item():.1f}  b={log_b.exp().item():.3f}  c={c.item():.3f}  (vrai : 30, 0.25, 2.0)")
print(f"Extrapolation à 1e9 paramètres : {(log_a.exp() * 1e9 ** (-log_b.exp()) + c).item():.3f}")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `allocation_optimale(C)` essaie 400 tailles $N$ réparties en échelle logarithmique de $10^6$ à $10^{13}$ (`10 ** (6 + 7 * i / pas)`), en déduit chaque fois $D = C/(6N)$ (tout le budget est dépensé), calcule la perte prédite et garde la plus basse (`min` sur des couples `(perte, N)` compare d'abord la perte).
> - Partie 3 : traduction directe du calcul de l'encadré précédent.
> - Partie 4 : on veut trouver $a$, $b$, $c$ tels que $a N^{-b} + c$ colle à 6 mesures. On optimise `log_a` et `log_b` plutôt que `a` et `b` : `log_a.exp()` est toujours positif, ce qui interdit à l'optimiseur de proposer une taille de loi négative absurde. Adam fait 3 000 pas sur l'erreur quadratique ; on extrapole ensuite à $10^9$ paramètres, bien au-delà des mesures.

Trois enseignements. D'abord, entraîner un modèle de 1 milliard de paramètres « à la Chinchilla » coûte de l'ordre de **230 € de calcul brut** : c'est à la portée d'un laboratoire universitaire ou d'une PME technique. Ensuite, refaire le calcul pour Llama 3 8B ($N = 8 \times 10^9$, $D = 15 \times 10^{12}$) donne $7{,}2 \times 10^{23}$ FLOPs, soit environ **500 000 heures-GPU** et **1,4 million d'euros** au même tarif, et le coût réel est supérieur (essais, expériences ratées, ingénieurs, stockage). Enfin, l'ajustement de la loi de puissance retrouve un exposant de 0,23 au lieu de 0,25 sur six points bruités : l'extrapolation est puissante, mais **fragile**, d'où l'usage de nombreux points et de marges d'erreur.

À cette échelle, un seul GPU ne suffit plus. On combine plusieurs formes de **parallélisme** (séances 7-8 de CS336, devoir A2 ; séance CS25 V6 sur le « parallélisme 5D » et les MoE par Hugging Face) : parallélisme de **données** (chaque GPU traite un lot différent ; ZeRO partage aussi les états de l'optimiseur), de **tenseurs** (une matrice découpée entre GPU), de **pipeline** (les couches réparties entre GPU), de **séquence** et d'**experts** (L134). Ajoutez la précision mixte BF16, des sauvegardes fréquentes et une surveillance des **pics de perte** (*loss spikes*) qui obligent parfois à revenir à un point de contrôle antérieur.

> 🎮 **Défi** — Un modèle de 70 milliards de paramètres entraîné sur 1 400 milliards de tokens (Chinchilla) : combien de FLOPs ? Combien d'heures-GPU H100 à 40 % de MFU ? *(Réponse en fin de leçon.)*

```quiz
{
  "q": "Combien de FLOPs faut-il, environ, pour entraîner un modèle de 1 milliard de paramètres sur 20 milliards de tokens ?",
  "options": [
    "1,2 × 10²⁰",
    "2 × 10¹⁹",
    "1,2 × 10¹⁸",
    "6 × 10²¹"
  ],
  "answer": 0,
  "explanation": "C ≈ 6 × N × D = 6 × 10⁹ × 2 × 10¹⁰ = 1,2 × 10²⁰ FLOPs."
}
```

## 🧪 Exercice pratique

**Consigne.** Une ETI française vous confie **10 000 € de calcul** (H100 à 2,73 €/h, MFU 40 %) pour pré-entraîner un petit modèle de langage spécialisé dans les documents comptables français.
1. Calculez le budget $C$ en FLOPs.
2. Déterminez la taille $N$ et le nombre de tokens $D$ « optimaux Chinchilla » avec la règle $D = 20N$.
3. Proposez une variante « orientée inférence » : un modèle 4 fois plus petit entraîné sur autant de calcul. Combien de tokens par paramètre ?
4. Discutez en cinq lignes : avez-vous assez de données comptables françaises ? Que proposez-vous ?

**Critères de réussite.** (a) $C \approx 5{,}2 \times 10^{21}$ FLOPs ; (b) $N \approx 6{,}6$ milliards et $D \approx 130$ milliards de tokens ; (c) la variante a environ 1,6 milliard de paramètres et ~320 tokens par paramètre ; (d) la discussion évoque le mélange avec des données générales, la déduplication, et le fine-tuning d'un modèle ouvert existant comme alternative (module 28).

<details><summary>Corrigé</summary>

1. $10\,000 / 2{,}73 \approx 3\,663$ heures-GPU ; $3\,663 \times 3\,600 \times 989 \times 10^{12} \times 0{,}40 \approx 5{,}2 \times 10^{21}$ FLOPs.
2. $C = 6 N D = 6 N (20 N) = 120 N^2$, donc $N = \sqrt{C / 120} \approx 6{,}6 \times 10^9$ et $D \approx 1{,}3 \times 10^{11}$ tokens.
3. $N' = N/4 \approx 1{,}65 \times 10^9$ ; $D' = C / (6 N') \approx 5{,}3 \times 10^{11}$ tokens, soit environ 320 tokens par paramètre : modèle moins bon à budget égal mais 4 fois moins cher à servir.
4. Aucun cabinet ne dispose de 130 milliards de tokens comptables : il faut un socle général (web filtré multilingue, dont du français), puis une part de données métier dédupliquées et nettoyées des données personnelles. Pour ce budget, la voie réaliste est souvent d'**adapter un modèle ouvert** déjà pré-entraîné sur des milliers de milliards de tokens (LoRA / QLoRA, module 28) plutôt que de pré-entraîner from scratch.
</details>

## ✅ Auto-évaluation express
1. D'où vient le facteur 6 dans $C \approx 6ND$ ?
2. Pourquoi Chinchilla 70B a-t-il battu Gopher 280B à calcul égal ?
3. Pourquoi les modèles de 2026 sont-ils entraînés bien au-delà de 20 tokens par paramètre ?

## 📚 Pour aller plus loin
- [Kaplan et al. (2020) — Scaling Laws for Neural Language Models](https://arxiv.org/abs/2001.08361) 🇬🇧 — les figures log-log qui ont lancé l'ère de l'échelle.
- [Hoffmann et al. (2022) — Chinchilla](https://arxiv.org/abs/2203.15556) 🇬🇧 — les trois approches d'estimation et la forme paramétrique.
- [Penedo et al. (2024) — FineWeb](https://arxiv.org/abs/2406.17557) 🇬🇧 — un pipeline de données de pré-entraînement documenté de bout en bout.
- [Stanford CS336 — supports exécutables](https://github.com/stanford-cs336/lectures) 🇬🇧 — séances sur les lois d'échelle et les données.
- [Stanford CS336 — vidéos (Stanford Online)](https://www.youtube.com/watch?v=JuoVZkPBiKk&list=PLoROMvodv4rMqXOcazWaTUHhq-yembLCV) 🇬🇧 — 18 vidéos du cours.

**Réponses de l'auto-évaluation.** 1. Environ 2 FLOPs par paramètre et par token pour la passe avant (multiplication + addition) et environ 4 pour la passe arrière. 2. Parce que Gopher était sous-entraîné : à calcul égal, mieux valait un modèle 4 fois plus petit vu sur 4,7 fois plus de tokens. 3. Parce que l'on optimise le coût total (entraînement + inférence) : un modèle plus petit et sur-entraîné est moins cher à servir des milliards de fois. **Défi** : $6 \times 7 \times 10^{10} \times 1{,}4 \times 10^{12} \approx 5{,}9 \times 10^{23}$ FLOPs, soit environ $5{,}9 \times 10^{23} / (3{,}96 \times 10^{14}) / 3\,600 \approx 413\,000$ heures-GPU H100.

> ✅ **Si vous ne retenez que 3 choses** — 1. La perte baisse de façon prévisible, en loi de puissance, avec la taille $N$, les données $D$ et le calcul $C$ : on extrapole depuis de petits modèles avant de dépenser des millions. 2. Chinchilla : à budget fixé, faire croître $N$ et $D$ ensemble (ordre de grandeur 20 tokens par paramètre) ; en 2026, on « sur-entraîne » volontairement de petits modèles car l'inférence coûte plus que l'entraînement. 3. Budget en une ligne : $C \approx 6ND$ FLOPs, divisé par le débit réel du GPU (35-50 % de sa fiche) pour obtenir des heures-GPU, puis des euros.

> 🗺️ **Et maintenant ?** — Le pré-entraînement produit un prédicteur de texte, pas un assistant. La leçon L133 montre comment SFT, RLHF, DPO et RL à récompense vérifiable le transforment en modèle utile qui raisonne.
