---
module: M28
title: "Fiche mémo — Fine-tuning et adaptation de modèles"
---
# Fiche mémo — M28 · Fine-tuning et adaptation de modèles

> En une phrase : on ne fine-tune qu'après avoir prouvé que le prompt et le RAG ne suffisent pas ; on le fait alors en QLoRA sur des données propres, et on livre le modèle avec la preuve chiffrée qu'il bat sa base.

## Les 7 idées à retenir
1. Prompt = quoi faire, RAG = avec quelles informations, fine-tuning = comment se comporter : il apprend une façon de faire, pas des faits (`L135`).
2. Le GPU pèse souvent moins de 5 % du coût : ce qui coûte, ce sont les humains et la maintenance (`L135`).
3. LoRA approxime la **mise à jour**, pas le modèle ; QLoRA gèle la base en NF4 et entraîne les adaptateurs en BF16 (`L136`).
4. La qualité bat la quantité (LIMA : 1 000 exemples soignés) ; séparer train/eval **avant** toute génération synthétique (`L137`).
5. Propriété des sorties ≠ droit d'en entraîner un modèle : lire licences et CGU (`L137`).
6. Deux étages d'évaluation : non-régression (lm-evaluation-harness) et gain métier (éval maison + juge calibré) (`L138`).
7. Fine-tuning hébergé : OpenAI ferme sa plateforme ; ce que vous possédez vraiment, ce sont vos données et vos évaluations (`L139`, `L140`).

## Le schéma à connaître
```mermaid
flowchart TD
  A["Besoin + 30 cas de test écrits"] --> B{"Prompt sur modèle de pointe suffisant ?"}
  B -- Oui --> C["STOP : prompt + cache"]
  B -- Non --> D{"Infos manquantes ou changeantes ?"}
  D -- Oui --> E["RAG avec citations"]
  D -- Non --> F{"Format, ton, tâche étroite + 300 à 5 000 exemples ?"}
  F -- Oui --> G["QLoRA + évaluation base vs fine-tuné"]
  F -- Non --> H["Revoir le besoin ou constituer les données"]
```

## Les formules essentielles
| Formule | Intuition en mots simples |
|---|---|
| $h = W_0x + \frac{\alpha}{r}BAx$, $B$ initialisée à 0 | Un post-it collé sur le livre gelé ; au départ il est vierge, donc le modèle ne change pas. |
| $\text{param}_{\text{LoRA}} = r(d + k)$ | Deux fines matrices au lieu d'une grande : 0,78 % pour $d = k = 4096$, $r = 16$. |
| $W' = W_0 + \frac{\alpha}{r}BA$ | On recolle le post-it dans le livre : zéro latence ajoutée (`merge_and_unload()`). |
| VRAM poids ≈ milliards × bits ÷ 8 × 1,1 | Combien de place prend le modèle en mémoire selon sa compression. |
| $\mathcal{L}_{\text{DPO}}$ sur `chosen` / `rejected`, réglée par $\beta$ | Rendre la réponse préférée plus probable, sans modèle de récompense. |

## Vocabulaire express
| Terme | En clair |
|---|---|
| NF4 | 16 niveaux placés aux quantiles d'une loi normale. |
| Prompt-completion | Format TRL où la perte ne porte que sur la réponse. |
| Distillation par séquences | L'élève est fine-tuné sur les réponses du professeur. |
| RFT | Fine-tuning par renforcement avec un correcteur (*grader*). |
| Oubli catastrophique | Le fine-tuning dégrade des capacités générales. |

## Les pièges classiques
- « Fine-tunons sur le catalogue » : pour des faits, c'est un RAG.
- Taux de full fine-tuning (1e-5) dans un LoRA : la perte ne bouge pas ; 1e-3 diverge.
- Écrire soi-même les balises `<|im_start|>` : laissez `apply_chat_template`.
- Évaluer sur des questions tirées du même export que l'entraînement.
- Juge LLM non calibré : biais de longueur, de position, d'auto-préférence.

## Les commandes / chiffres / dates utiles
```python
bnb_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=compute_dtype)
peft_config = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, bias="none", task_type="CAUSAL_LM",
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"])
model.save_pretrained_gguf("projet/gguf", tokenizer, quantization_method="q4_k_m")   # Unsloth
```
- Départ : `r` 16, `lora_alpha` 16 à 2r, lr 2e-4, 1 à 3 époques ; ~0,3 à 1 % de paramètres entraînés.
- Full fine-tuning : ~16 octets par paramètre ; QLoRA d'un 8B : ~10-12 Go de VRAM.
- 1 000 exemples × 500 tokens × 2 époques sur RTX 4090 louée (0,34 $/h) : 6 à 12 min.
- Gemma 4 E4B en GGUF Q4_K_M : prévoir ~4,5 à 5 Go (à mesurer).
- OpenAI : plus de nouveaux clients depuis le 7/05/2026, plus aucun nouveau job le **6/01/2027**.
- Cache de prompt Anthropic : lecture à 0,05× sur Sonnet 5.5 depuis le 7/10/2026.
- Projet C4.4 réussi : fine-tuné ≥ base + 15 points, non-régression ≤ 2 points, zéro invention grave.

## Pour aller plus loin
- [TRL — PEFT integration](https://huggingface.co/docs/trl/main/en/peft_integration)
- [Unsloth — documentation](https://unsloth.ai/docs)
- [lm-evaluation-harness](https://github.com/EleutherAI/lm-evaluation-harness)

## Auto-test (3 questions — réponses en bas de fiche)
1. Paramètres LoRA pour `up_proj` ($d = 14\,336$, $k = 4\,096$) avec $r = 8$ ?
2. Tarifs de 600 références mis à jour chaque trimestre : quelle approche ?
3. Comment réduire le biais de position d'un juge LLM ?

---
**Réponses.** 1. $8 \times (14\,336 + 4\,096) = 147\,456$. 2. Un RAG sur le catalogue, avec citations. 3. Évaluer A/B puis B/A et ne garder que les verdicts concordants.
