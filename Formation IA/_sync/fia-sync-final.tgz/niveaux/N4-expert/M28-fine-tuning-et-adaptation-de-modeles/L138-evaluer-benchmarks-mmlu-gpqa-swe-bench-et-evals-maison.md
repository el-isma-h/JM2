---
id: L138
module: M28
level: N4
title: "Évaluer : benchmarks (MMLU, GPQA, SWE-bench…) et evals maison"
minutes: 60
objectives:
  - "Expliquer ce que mesurent MMLU, GPQA, SWE-bench, HumanEval, ARC-AGI, HLE, LMArena et l'Artificial Analysis Index"
  - "Identifier les limites des benchmarks publics : saturation, contamination, auto-déclaration, loi de Goodhart"
  - "Construire une évaluation maison reproductible avec lm-evaluation-harness, Inspect AI et un juge LLM"
  - "Évaluer un modèle fine-tuné contre sa base et détecter une régression de capacités générales"
skills: ["C4.4"]
sources:
  - { title: "Atlan — LLM benchmarks explained (juil. 2026)", url: "https://atlan.com/know/llm-benchmarks-explained.md", lang: "en" }
  - { title: "EleutherAI — lm-evaluation-harness", url: "https://github.com/EleutherAI/lm-evaluation-harness", lang: "en" }
  - { title: "UK AISI — Inspect AI", url: "https://github.com/UKGovernmentBEIS/inspect_ai", lang: "en" }
  - { title: "SWE-bench", url: "https://www.swebench.com", lang: "en" }
  - { title: "Artificial Analysis — leaderboards", url: "https://artificialanalysis.ai/leaderboards/models", lang: "en" }
  - { title: "a smol course — unité Evaluation", url: "https://huggingface.co/learn/smol-course", lang: "en" }
  - { title: "OpenAI — Evals (guide)", url: "https://developers.openai.com/api/docs/guides/evals", lang: "en" }
---

# Évaluer : benchmarks (MMLU, GPQA, SWE-bench…) et evals maison

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 28

## 🎯 Ce que vous saurez faire
- Lire une fiche de modèle et dire ce que signifie concrètement « GPQA Diamond = 89,2 » ou « SWE-bench Verified = 77,2 % ».
- Repérer les quatre biais classiques des classements publics avant de citer un chiffre à un client.
- Mesurer votre modèle fine-tuné contre sa base sur (1) des benchmarks publics pour détecter les régressions et (2) une évaluation maison pour mesurer le gain métier.
- Écrire un juge LLM avec une grille explicite, et le calibrer contre un jugement humain.

> 🧭 **En clair** — Évaluer un modèle, c'est comme faire passer un examen à un candidat avant de l'embaucher. Les benchmarks publics (MMLU, GPQA, SWE-bench) sont des concours nationaux : utiles pour situer un candidat, mais certains sujets ont fuité, d'autres sont devenus trop faciles, et aucun ne ressemble exactement à votre poste. Il vous faut donc aussi votre propre épreuve, avec vos vrais cas (l'« éval maison »), et parfois un correcteur automatique : un grand modèle qui note les copies selon votre barème (le « juge LLM »). Comme tout correcteur, on vérifie d'abord qu'il note comme un humain. Dernière règle : s'assurer que le candidat formé n'a pas oublié ce qu'il savait avant (la non-régression).

## 1. Pourquoi évaluer est le cœur du métier

« Ce qui ne se mesure pas ne s'améliore pas » vaut doublement en fine-tuning : un entraînement peut améliorer le ton de 30 % et faire perdre en silence la capacité à calculer une TVA. La compétence C4.4 du référentiel l'exige d'ailleurs : *le modèle adapté surpasse la base sur l'évaluation définie*. Une évaluation sérieuse a toujours deux étages :

| Étage | Question | Outils |
|---|---|---|
| **Non-régression** | Le modèle a-t-il perdu des capacités générales ? | Benchmarks publics (MMLU, ARC, GSM8K…) via lm-evaluation-harness |
| **Gain métier** | Fait-il mieux la tâche pour laquelle on l'a entraîné ? | Jeu d'évaluation maison + métriques automatiques + juge LLM + relecture humaine |

```mermaid
flowchart TD
    M[Modèle de base + modèle fine-tuné] --> NR[Étage 1 : non-régression<br/>lm-evaluation-harness]
    M --> GM[Étage 2 : gain métier<br/>éval maison + juge LLM calibré]
    NR --> D{Les deux étages<br/>sont-ils au vert ?}
    GM --> D
    D -- Oui --> OK[Déployer et documenter les chiffres]
    D -- Non --> R[Revoir données ou hyperparamètres]
```

## 2. Les benchmarks publics à connaître (nov. 2026)

| Benchmark | Ce qu'il mesure | Repères 2026 | Statut |
|---|---|---|---|
| **MMLU / MMLU-Pro** | QCM de connaissances sur 57 matières (Hendrycks et al., 2020) ; Pro = version durcie à 10 options | gpt-oss-120b 90,0 ; Gemma 4 31B MMLU-Pro 85,2 | **Saturé** au-delà de 88 % |
| **GPQA Diamond** | 198 questions de sciences niveau doctorat, conçues pour résister à une recherche Google | Kimi K3 93,5 ; DeepSeek V4.1 Flash 90,9 ; Qwen3.8-27B 89,2 | Proche de la saturation |
| **SWE-bench Verified / Pro** | Résoudre de vraies *issues* GitHub, validé par les tests unitaires du dépôt ; Pro = jeu plus dur, en partie privé | Verified : Beam 81,6 %, Qwen3.6-27B 77,2 % ; Pro : Qwen3.8-Max 67,7 % | Référence du code agentique |
| **HumanEval** | 164 problèmes Python, métrique pass@1 (OpenAI, 2021) | Saturé ; remplacé par **LiveCodeBench** (Qwen3.8-27B v6 = 90,3) | Historique |
| **ARC-AGI 1/2/3** | Raisonnement abstrait visuel sur des grilles, généralisation à partir de très peu d'exemples (François Chollet, 2019) | v3 interactif (2026) | Encore loin d'être résolu |
| **Humanity's Last Exam (HLE)** | 2 500 questions d'experts sur plus de 100 sujets (CAIS + Scale AI, janv. 2025) | ~46,9 % au mieux (mai 2026) ; DeepSeek V4.1 Flash 36,8 (63,9 avec outils) | Frontière |
| **LMArena** | Elo issu de votes humains en aveugle entre deux réponses | Top fermé ~1 531 (Claude Mythos 5) ; meilleur ouvert Kimi K3 1 500 (31 oct. 2026) | Préférences, pas exactitude |
| **Artificial Analysis Intelligence Index v5** | Indice composite (27 oct. 2026), 60 % de tests privés, 4 familles à 25 % | Claude Opus 5.5 = 58 ; GPT-6 Astra = 57 ; meilleurs poids publiés = 32 | Moins contaminable |

> 🧭 **Pré-requis express** — **pass@1** = proportion de problèmes résolus dès la **première** tentative (pass@10 : au moins une réussite sur 10 essais). Un score **Elo** (emprunté aux échecs) ne se lit qu'en **écart** : 100 points d'écart signifient que le mieux classé gagne environ 64 % des duels, $1/(1 + 10^{-100/400}) \approx 0{,}64$ ; 31 points (1 531 contre 1 500) ne donnent qu'environ 54 % de victoires. **0-shot / few-shot** : sans exemple résolu dans la consigne / avec quelques exemples. **Saturé** : presque tous les modèles atteignent le plafond, l'écart restant ne veut plus rien dire. (Calculs vérifiés en Python.)

Ces chiffres sont majoritairement **auto-déclarés** par les éditeurs ou relevés par des tiers (Morph, Swfte, ActuIA) ; ils varient selon le protocole (nombre d'exemples *few-shot*, outils autorisés, effort de raisonnement).

> 💡 **À retenir** — Un benchmark mesure une tâche, dans un protocole, à une date. Citez toujours les trois : « GPQA Diamond, 0-shot, sans outils, chiffre éditeur d'août 2026 ».

```quiz
{
  "q": "Une fiche annonce « GPQA Diamond = 89,2 ». Que faut-il préciser pour citer ce chiffre correctement à un client ?",
  "options": [
    "Le nombre de paramètres du modèle",
    "Le prix du modèle par million de tokens",
    "Le protocole, la source et la date",
    "Rien : un score de benchmark est universel"
  ],
  "answer": 2,
  "explanation": "Un benchmark mesure une tâche, dans un protocole, à une date. Le même modèle peut gagner ou perdre plusieurs points selon le protocole."
}
```

## 3. Les quatre limites à garder en tête

1. **Saturation** : quand tous les modèles dépassent 88 % sur MMLU, l'écart restant tient du bruit et des erreurs d'étiquetage. Des réanalyses comme MMLU-Redux (2024) ont trouvé plusieurs pour cent de questions mal formulées ou mal corrigées.
2. **Contamination** : si les questions du test ont été vues pendant le pré-entraînement (elles circulent sur le web), le score mesure la mémoire. D'où les jeux privés (SWE-bench Pro, 60 % de l'index AA v5), les jeux datés (LiveCodeBench ne retient que des problèmes publiés après la date de coupure) et les tests renouvelés.
3. **Écart avec l'usage réel** : un QCM en anglais ne dit rien de la qualité d'un courrier de relance en français. Le banc communautaire Bestllmfor (sept. 2026) montre par exemple des modèles 8B rapides qui échouent sur des documents français.
4. **Loi de Goodhart** : « quand une mesure devient un objectif, elle cesse d'être une bonne mesure ». Les éditeurs optimisent pour les classements ; LMArena récompense aussi la longueur et la mise en forme des réponses.

> 💡 **Autrement dit** — Un élève qui ne révise que les annales finit par réussir l'examen sans maîtriser la matière. Les modèles aussi : plus un classement devient célèbre, plus il est « bachoté » par les éditeurs, et moins il dit de choses sur votre cas d'usage.

> ⚠️ **Piège fréquent** — Évaluer votre modèle fine-tuné sur des questions extraites du même export que vos données d'entraînement. C'est de la contamination fabriquée maison : le score sera excellent et ne voudra rien dire. Le jeu d'évaluation est figé **avant** l'entraînement (L137, section 3) et ne sert jamais à régler les hyperparamètres de façon répétée.

```quiz
{
  "type": "vrai_faux",
  "q": "Un benchmark est dit « contaminé » quand ses questions ont circulé sur le web et ont pu être vues pendant le pré-entraînement du modèle.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 0,
  "explanation": "Vrai : le score mesure alors en partie la mémoire et non la compétence. D'où les jeux privés ou renouvelés, et votre propre éval maison."
}
```

## 4. Non-régression avec lm-evaluation-harness

L'outil d'EleutherAI (licence MIT) est le moteur historique de l'Open LLM Leaderboard. Il évalue un modèle Hugging Face, avec ou sans adaptateur PEFT, sur des centaines de tâches standardisées.

```bash
pip install "lm-eval[hf]" peft
# 1) Modèle de base
lm_eval --model hf \
  --model_args pretrained=Qwen/Qwen3-8B,dtype=bfloat16 \
  --tasks arc_easy,hellaswag,gsm8k \
  --batch_size 8 --limit 300 \
  --output_path resultats/base

# 2) Même modèle + adaptateur LoRA du SFT
lm_eval --model hf \
  --model_args pretrained=Qwen/Qwen3-8B,peft=adapters/sav-qlora,dtype=bfloat16 \
  --tasks arc_easy,hellaswag,gsm8k \
  --batch_size 8 --limit 300 \
  --output_path resultats/sft
# lm_eval --tasks list  → affiche les tâches disponibles (dont des tâches multilingues ; vérifiez celles en français)
```

`--limit 300` restreint chaque tâche à 300 exemples : suffisant pour détecter une régression grossière en quelques minutes sur un GPU 24 Go, insuffisant pour publier un score. Règle pratique : une baisse de plus de 2 à 3 points sur une tâche générale signale un oubli catastrophique ; réduisez alors le taux d'apprentissage ou les époques, ou mélangez 10 à 20 % de données générales à vos données métier.

> 🔢 **Exemple à la main** — Pourquoi 300 exemples suffisent pour une régression « grossière » mais pas pour publier : sur $n$ questions, un score $p$ est connu à environ $\pm 1{,}96\sqrt{p(1-p)/n}$ près (intervalle à 95 %). Pour $p = 0{,}8$ : avec $n = 300$, $\pm 0{,}045$, soit **±4,5 points** ; avec $n = 50$ (une petite éval maison), $\pm 0{,}11$, soit **±11 points**. Un écart de 3 points sur 50 cas n'est donc qu'un bruit possible. (Vérifié en Python.)

## 5. Gain métier : une évaluation maison avec Inspect AI

**Inspect AI** (Institut britannique de sécurité de l'IA, licence MIT) structure une évaluation en trois briques : un **dataset** d'échantillons, un **solver** (comment interroger le modèle) et un **scorer** (comment noter). Il sait interroger un modèle servi par Ollama ou toute API compatible.

```python
"""eval_sav.py — Évaluation maison du SAV avec Inspect AI.
pip install inspect-ai openai
Lancer : inspect eval eval_sav.py --model ollama/sav-delorme
         inspect eval eval_sav.py --model ollama/qwen3:8b   (modèle de base, pour comparer)
Puis : inspect view   (interface de lecture des résultats)
"""
import json

from inspect_ai import Task, task
from inspect_ai.dataset import Sample
from inspect_ai.scorer import model_graded_qa
from inspect_ai.solver import generate, system_message

SYSTEM = "Vous êtes l'assistant SAV de la Maison Delorme. Répondez en français, avec courtoisie, en 120 mots maximum."

def charger(chemin: str = "eval.jsonl") -> list[Sample]:
    echantillons = []
    with open(chemin, encoding="utf-8") as f:
        for ligne in f:
            r = json.loads(ligne)
            question = r["prompt"][-1]["content"]
            reference = r["completion"][0]["content"]
            echantillons.append(Sample(input=question, target=reference))
    return echantillons

GRILLE = """Vous évaluez une réponse de service client.
Question : {question}
Réponse de référence : {criterion}
Réponse évaluée : {answer}
La réponse évaluée est CORRECTE si elle (1) apporte la même solution que la référence, (2) n'invente aucun
délai, prix ou engagement absent de la référence, (3) est courtoise et en français.
Expliquez brièvement, puis terminez par GRADE: C (correct) ou GRADE: I (incorrect)."""

@task
def sav_delorme():
    return Task(
        dataset=charger(),
        solver=[system_message(SYSTEM), generate()],
        # Le juge peut être un autre modèle que celui évalué : --model-role grader=... (voir la doc Inspect)
        scorer=model_graded_qa(template=GRILLE),
    )
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `charger` lit `eval.jsonl` (le format de L137) : `r["prompt"][-1]["content"]` est le **dernier** message de la consigne (la question du client), `r["completion"][0]["content"]` la réponse de référence ; chacun devient un `Sample(input=..., target=...)`. `GRILLE` est le gabarit de consigne du juge : Inspect remplace `{question}`, `{criterion}` (la référence) et `{answer}` (la réponse évaluée). Le décorateur `@task` déclare l'évaluation ; le `solver` ajoute la consigne système puis génère ; `model_graded_qa` fait noter chaque réponse et lit `GRADE: C` ou `GRADE: I`.

Vérifiez dans la documentation d'Inspect la syntaxe exacte pour désigner le modèle juge : par défaut, `model_graded_qa` utilise le modèle évalué lui-même, ce qui est un biais (section 6).

## 6. Le juge LLM, bien utilisé

Faire noter les réponses par un grand modèle (*LLM-as-a-judge*) permet d'évaluer des centaines de réponses ouvertes en minutes. C'est puissant et piégeux. Les biais documentés : préférence pour les réponses **longues**, pour la **première** réponse présentée, et pour son **propre style** (auto-préférence). Les parades :

| Biais | Parade |
|---|---|
| Longueur | Grille qui pénalise explicitement le hors-sujet ; limite de mots dans la consigne |
| Position | Comparer A/B **et** B/A, ne garder que les verdicts concordants |
| Auto-préférence | Juge d'une autre famille que le modèle évalué |
| Flou | Critères binaires et vérifiables plutôt qu'une note de 1 à 10 |
| Dérive | Calibrer : 50 réponses notées par un humain, mesurer l'accord avec le juge (viser > 80 %) |

Voici un juge comparatif minimal, indépendant de tout framework, qui confronte la base et le modèle fine-tuné :

```python
"""juge_ab.py — Comparaison A/B base vs fine-tuné par un juge LLM, avec inversion des positions.
Fichier d'entrée : reponses.jsonl, lignes {"question", "reference", "base", "ft"}.
Le juge est n'importe quel modèle derrière une API compatible OpenAI (local ou distant).
"""
import json
import os

from openai import OpenAI

juge = OpenAI(base_url=os.environ.get("JUDGE_BASE_URL", "http://localhost:11434/v1"),
              api_key=os.environ.get("JUDGE_API_KEY", "ollama"))
JUGE_MODELE = os.environ.get("JUDGE_MODEL", "qwen3.8:27b")

GRILLE = (
    "Vous comparez deux réponses de SAV à la même question, à l'aide de la référence.\n"
    "Critères, par ordre d'importance : exactitude par rapport à la référence ; aucune promesse inventée ; "
    "courtoisie ; concision. Ignorez la longueur si elle n'apporte rien.\n"
    "Question : {q}\nRéférence : {ref}\nRéponse A : {a}\nRéponse B : {b}\n"
    "Répondez uniquement par A, B ou EGALITE."
)

def verdict(q: str, ref: str, a: str, b: str) -> str:
    r = juge.chat.completions.create(
        model=JUGE_MODELE,
        messages=[{"role": "user", "content": GRILLE.format(q=q, ref=ref, a=a, b=b)}],
    )
    txt = r.choices[0].message.content.strip().upper()
    return "A" if txt.startswith("A") else "B" if txt.startswith("B") else "EGALITE"

score = {"ft": 0, "base": 0, "egalite": 0}
with open("reponses.jsonl", encoding="utf-8") as f:
    for ligne in f:
        r = json.loads(ligne)
        v1 = verdict(r["question"], r["reference"], r["ft"], r["base"])   # ft en position A
        v2 = verdict(r["question"], r["reference"], r["base"], r["ft"])   # ft en position B
        if v1 == "A" and v2 == "B":
            score["ft"] += 1
        elif v1 == "B" and v2 == "A":
            score["base"] += 1
        else:
            score["egalite"] += 1                                          # verdicts discordants = égalité

total = sum(score.values())
print({k: f"{v} ({v / total:.0%})" for k, v in score.items()})
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `verdict` envoie la grille au juge et ne garde que la première lettre de sa réponse (`A`, `B`, sinon égalité). Pour chaque question, on appelle le juge **deux fois** en inversant les positions : le fine-tuné ne marque un point que s'il gagne dans les deux ordres (`v1 == "A"` **et** `v2 == "B"`), la base de même ; tout verdict discordant devient une égalité. La dernière ligne affiche les trois compteurs et leurs pourcentages.

> 🔢 **Exemple à la main** — Trois questions. Q1 : verdicts (A, B) → point au fine-tuné. Q2 : (A, A) → le juge a préféré la position A les deux fois, c'est un biais de position → égalité. Q3 : (B, A) → point à la base. Résultat : `{'ft': '1 (33%)', 'base': '1 (33%)', 'egalite': '1 (33%)'}`. Calibrage : si, sur 50 paires, vous êtes d'accord avec le juge 42 fois, l'accord vaut $42/50 = 84$ %, au-dessus du seuil de 80 % du tableau.

Complétez toujours le juge par des **métriques déterministes** quand c'est possible : JSON valide (`json.loads`), présence d'un champ obligatoire, longueur maximale, absence de mots interdits, exact match sur une classification. Elles sont gratuites, rapides et ne se trompent pas.

> 🔗 **Documentation officielle** — [lm-evaluation-harness](https://github.com/EleutherAI/lm-evaluation-harness) · [Inspect AI](https://github.com/UKGovernmentBEIS/inspect_ai) · [OpenAI — Evals](https://developers.openai.com/api/docs/guides/evals)

```quiz
{
  "q": "Votre juge LLM préfère presque toujours la réponse présentée en premier. Quelle parade ?",
  "options": [
    "Lui demander une note de 1 à 10",
    "Évaluer en A/B puis B/A et croiser",
    "Choisir un juge de la même famille que le modèle évalué",
    "Allonger les réponses à comparer"
  ],
  "answer": 1,
  "explanation": "C'est le biais de position. Inverser l'ordre neutralise ce biais ; un juge de la même famille ajouterait un biais d'auto-préférence."
}
```

## 7. Lire un classement comme un expert

> 🎮 **Défi** — Un commercial vous affirme : « Notre modèle fait 91 % sur MMLU, contre 89 % pour le concurrent, il est donc meilleur pour votre service juridique. » Trouvez trois objections. *Pistes : MMLU est saturé (2 points = bruit) ; QCM anglais ≠ rédaction juridique française ; chiffre auto-déclaré, protocole inconnu ; seule une évaluation sur vos propres cas tranche.*

Pour choisir un modèle de base à fine-tuner, croisez trois sources : un indice composite peu contaminable (Artificial Analysis), un classement de préférences (LMArena) et **votre** évaluation maison sur 30 à 100 cas. C'est la troisième qui décide.

```mission
{
  "title": "Les trois jeux de GPQA",
  "url": "https://github.com/idavidrein/gpqa",
  "steps": [
    "Ouvrez le dépôt GitHub idavidrein/gpqa",
    "Lisez le README",
    "Repérez les tailles des jeux extended, main et diamond"
  ],
  "question": "Combien de questions comptent les jeux GPQA « extended », « main » et « diamond » ?",
  "hint": "Diamond est le plus petit des trois ; le tableau de la section 2 de la leçon donne déjà son effectif.",
  "answer": "Extended : 546 questions ; main : 448 ; diamond : 198 (les questions les plus fiables et les plus difficiles). Chiffres de l'article arXiv 2311.12022, lié depuis le README, qui ne les donne pas lui-même (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

```mission
{
  "title": "Qui a vérifié SWE-bench Verified ?",
  "url": "https://www.swebench.com",
  "steps": [
    "Ouvrez le site officiel swebench.com",
    "Repérez la présentation des différents jeux (Full, Lite, Verified…)",
    "Lisez la description de SWE-bench Verified"
  ],
  "question": "Combien de problèmes compte SWE-bench Verified, et comment ont-ils été sélectionnés ?",
  "hint": "Le mot « human » figure dans la description.",
  "answer": "500 problèmes, validés par des ingénieurs logiciels humains comme bien spécifiés et solubles (sous-ensemble publié en 2024 avec OpenAI). Vérifiez aussi la présence éventuelle de nouveaux jeux comme Pro sur la page (consultée en nov. 2026) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Pour le modèle fine-tuné en L136 (ou, à défaut, deux modèles Ollama de tailles différentes) :
1. Lancez lm-evaluation-harness sur 3 tâches générales, base vs fine-tuné, `--limit 200`.
2. Générez les réponses des deux modèles sur votre `eval.jsonl`, lancez `juge_ab.py`.
3. Notez vous-même 20 paires à l'aveugle et calculez votre taux d'accord avec le juge.
4. Rédigez une conclusion de 10 lignes : gain métier, régressions, fiabilité du juge.

**Critères de réussite.** Les deux étages (non-régression et gain métier) sont mesurés ; l'inversion des positions est appliquée ; le taux d'accord humain/juge est calculé ; la conclusion distingue un gain significatif d'un écart de bruit (sur 50 cas, quelques points d'écart ne prouvent rien).

<details><summary>Pistes de corrigé</summary>

Résultat typique d'un SFT LoRA bien réglé : tâches générales stables à ±1-2 points, net avantage du fine-tuné au juge A/B sur le ton et le format, mais quelques pertes sur des cas hors distribution. Un accord humain/juge inférieur à 70 % indique une grille trop floue : rendez les critères binaires.
</details>

## ✅ Auto-évaluation express
1. Pourquoi un score de 90 % sur MMLU est-il peu informatif en 2026 ?
2. Qu'est-ce que la contamination d'un benchmark ?
3. Citez deux parades au biais de position d'un juge LLM.

*Réponses : 1. Le benchmark est saturé, les écarts restants relèvent du bruit et des erreurs d'étiquetage. 2. La présence des questions du test dans les données d'entraînement, qui fait mesurer la mémoire plutôt que la compétence. 3. Évaluer dans les deux ordres A/B et B/A ; ne retenir que les verdicts concordants (ou randomiser l'ordre).*

## 📚 Pour aller plus loin
- [Atlan — LLM benchmarks explained](https://atlan.com/know/llm-benchmarks-explained.md) 🇬🇧 — panorama 2026 des benchmarks et de leur saturation.
- [Artificial Analysis — leaderboards](https://artificialanalysis.ai/leaderboards/models) 🇬🇧 — indice composite v5, coûts et vitesses.
- [SWE-bench](https://www.swebench.com) 🇬🇧 — méthodologie des variantes Verified et Pro.
- [ARC Prize](https://arcprize.org) 🇬🇧 — ARC-AGI et ses versions successives.
- [a smol course — Evaluation](https://huggingface.co/learn/smol-course) 🇬🇧 — unité consacrée à l'évaluation des modèles post-entraînés.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un benchmark mesure une tâche, dans un protocole, à une date : méfiez-vous de la saturation, de la contamination, de l'écart avec votre usage et de la loi de Goodhart. 2. Évaluez sur deux étages : non-régression (lm-evaluation-harness, base contre fine-tuné) et gain métier (jeu maison figé **avant** l'entraînement, métriques déterministes, juge LLM). 3. Un juge LLM se contrôle : positions inversées, autre famille de modèle, critères binaires, accord avec un humain mesuré ; et sur 50 cas, quelques points d'écart ne prouvent rien.

> 🗺️ **Et maintenant ?** — Et si l'on confiait l'entraînement à un fournisseur plutôt qu'à son propre GPU ? La leçon L139 fait le point sur le fine-tuning via API, un marché qui se contracte vite.
