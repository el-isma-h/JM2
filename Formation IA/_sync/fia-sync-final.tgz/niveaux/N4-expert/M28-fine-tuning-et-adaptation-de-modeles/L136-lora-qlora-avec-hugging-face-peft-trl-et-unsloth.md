---
id: L136
module: M28
level: N4
title: "LoRA / QLoRA avec Hugging Face PEFT, TRL et Unsloth"
minutes: 70
objectives:
  - "Expliquer la décomposition de rang faible de LoRA et calculer le nombre de paramètres entraînables"
  - "Régler les hyperparamètres r, alpha, dropout, modules cibles et taux d'apprentissage d'un fine-tuning LoRA"
  - "Expliquer la quantization 4 bits NF4 de QLoRA et estimer la VRAM nécessaire"
  - "Construire et exécuter un script SFT complet avec TRL + PEFT, puis sa variante Unsloth"
skills: ["C4.4"]
sources:
  - { title: "Hu et al. (2021) — LoRA: Low-Rank Adaptation of Large Language Models", url: "https://arxiv.org/abs/2106.09685v1", lang: "en" }
  - { title: "Dettmers et al. (2023) — QLoRA: Efficient Finetuning of Quantized LLMs", url: "https://arxiv.org/abs/2305.14314", lang: "en" }
  - { title: "Hugging Face TRL — PEFT integration", url: "https://huggingface.co/docs/trl/main/en/peft_integration", lang: "en" }
  - { title: "Unsloth — documentation", url: "https://unsloth.ai/docs", lang: "en" }
  - { title: "Axolotl — documentation (intégration Unsloth)", url: "https://docs.axolotl.ai/docs/unsloth.html", lang: "en" }
  - { title: "Hugging Face LLM Course — chapitre 11", url: "https://huggingface.co/learn/llm-course", lang: "en" }
---

# LoRA / QLoRA avec Hugging Face PEFT, TRL et Unsloth

> ⏱ 70 min · 🎯 Niveau 4 · 📚 Module 28

## 🎯 Ce que vous saurez faire
- Écrire et expliquer la formule $W' = W + \frac{\alpha}{r}BA$ et calculer à la main ce qu'elle économise.
- Choisir des valeurs défendables pour `r`, `lora_alpha`, `lora_dropout`, `target_modules` et le taux d'apprentissage.
- Expliquer ce que font NF4, la double quantization et les optimiseurs paginés de QLoRA, et estimer la VRAM d'un entraînement.
- Lancer un fine-tuning SFT complet d'un modèle de 8 milliards de paramètres sur un GPU de 16 à 24 Go (ou Colab), avec TRL + PEFT puis avec Unsloth.

> 🧭 **En clair** — Plutôt que de réimprimer un manuel de 8 milliards de pages pour y changer quelques habitudes, LoRA colle des post-it sur les pages concernées : le livre d'origine ne bouge pas, et les post-it (quelques dizaines de millions de nombres) portent toutes les corrections. On peut ranger plusieurs jeux de post-it, un pour le SAV, un pour le juridique, et changer de jeu en quelques secondes, ou les recopier définitivement dans le livre (la « fusion »). QLoRA va plus loin : le manuel lui-même est imprimé en tout petits caractères (4 bits) pour tenir sur une seule table, tandis que les post-it restent écrits lisiblement. Résultat : un modèle de 8 milliards de paramètres se spécialise sur une carte graphique de joueur, en moins d'une heure.

## 1. Le problème : mettre à jour 8 milliards de nombres coûte cher

Dans un fine-tuning complet (*full fine-tuning*), chaque poids du modèle reçoit un gradient et l'optimiseur AdamW garde pour lui deux moments (moyenne et variance, vus en L114). Comptez, en précision mixte, environ 16 octets par paramètre : poids en BF16 (2), gradients (2), copie maîtresse FP32 (4), deux moments FP32 (8). Pour un modèle de 8 milliards de paramètres : **~128 Go** avant même de stocker les activations. C'est le domaine des serveurs multi-GPU.

> 🔢 **Exemple à la main** — $8 \times 10^9$ paramètres × 16 octets $= 128 \times 10^9$ octets, soit environ **128 Go** de mémoire GPU, hors activations : deux GPU de 80 Go au minimum. Les seuls poids en BF16 en occupent déjà $8 \times 10^9 \times 2 = 16$ Go. (Calcul vérifié en Python.)

L'intuition de LoRA est née d'une observation : quand on adapte un modèle pré-entraîné à une tâche, la **modification** des poids $\Delta W$ a un « rang intrinsèque » faible. Autrement dit, elle peut s'écrire comme le produit de deux matrices beaucoup plus étroites. Vous avez rencontré l'idée en L111 avec la SVD : une matrice peut être approchée par peu de directions principales.

> 💡 **Autrement dit** — « Rang faible » signifie que la correction à apporter est simple : elle se résume à quelques grandes directions, comme une retouche de couleur appliquée à toute une photo plutôt que pixel par pixel. On peut donc l'écrire avec deux petites matrices au lieu d'une énorme : ce sont nos post-it.

## 2. Les mathématiques de LoRA

Soit une couche linéaire de poids $W_0 \in \mathbb{R}^{d \times k}$. LoRA **gèle** $W_0$ et ajoute deux matrices entraînables :

$$h = W_0 x + \Delta W x = W_0 x + \frac{\alpha}{r}\, B A x, \qquad B \in \mathbb{R}^{d \times r},\ A \in \mathbb{R}^{r \times k},\ r \ll \min(d,k)$$

- $A$ est initialisée aléatoirement (gaussienne), $B$ à **zéro** : au démarrage $BA = 0$ et le modèle adapté est exactement le modèle de base. L'entraînement part donc d'un point sûr.
- $\alpha$ (`lora_alpha`) est un facteur d'échelle : le ratio $\alpha / r$ règle l'amplitude de la mise à jour. Doubler $r$ sans toucher $\alpha$ réduit la contribution de chaque direction.
- À l'inférence, on peut **fusionner** : $W' = W_0 + \frac{\alpha}{r}BA$. Aucune latence supplémentaire, c'est ce que fait `merge_and_unload()`.

> 🧭 **Pré-requis express** — **$W_0 \in \mathbb{R}^{d \times k}$** : un tableau de $d$ lignes et $k$ colonnes (L111) ; **$r \ll \min(d, k)$** : le rang $r$ est « beaucoup plus petit » que la plus petite des deux dimensions ; **$\Delta W$** (delta W) = la correction ajoutée aux poids ; **$\alpha$** (alpha) = facteur d'échelle choisi par vous.

> 🔢 **Exemple à la main** — Version miniature : $W_0 = \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}$, $r = 1$, $B = \begin{pmatrix} 1 \\ 2 \end{pmatrix}$ ($2 \times 1$), $A = (3 \ \ 4)$ ($1 \times 2$), $\alpha / r = 1$, entrée $x = (1, 1)$.
> 1. $BA = \begin{pmatrix} 3 & 4 \\ 6 & 8 \end{pmatrix}$ : une matrice $2 \times 2$ entière, fabriquée avec seulement $2 + 2 = 4$ nombres (pour $4\,096 \times 4\,096$, ce serait $2 \times 4\,096 \times r$ nombres au lieu de 16,8 millions).
> 2. $W_0 x = (1, 1)$ et $BA\,x = (3 + 4 ;\ 6 + 8) = (7 ;\ 14)$, donc $h = (8 ;\ 15)$.
> 3. Au démarrage, $B = 0$ donc $BA = 0$ et $h = W_0 x = (1, 1)$ : le modèle de base exact.
>
> (Vérifié en NumPy.)

```mermaid
flowchart LR
    X[Entrée x] --> W[W₀ gelé<br/>le livre, d × k]
    X --> A[A : r × k<br/>entraînable]
    A --> B[B : d × r<br/>entraînable, initialisée à 0]
    B --> S[× α / r<br/>le post-it]
    W --> P((+))
    S --> P
    P --> H[Sortie h]
```

**Calcul de l'économie.** Pour une projection d'attention $d = k = 4\,096$ :

| | Paramètres |
|---|---|
| Matrice complète $W_0$ | $4\,096 \times 4\,096 = 16\,777\,216$ |
| LoRA, $r = 16$ : $r(d + k)$ | $16 \times 8\,192 = 131\,072$ |
| Ratio | **0,78 %** |

Sur l'ensemble d'un modèle de 8B avec les sept projections ciblées, on entraîne typiquement 20 à 80 millions de paramètres, soit **0,3 à 1 %** du total. L'adaptateur sauvegardé pèse quelques dizaines à quelques centaines de mégaoctets : vous pouvez en garder un par client ou par tâche et les échanger à chaud sur le même modèle de base.

> 💡 **À retenir** — LoRA n'approxime pas le modèle, il approxime la **mise à jour**. Le modèle de base reste intact, ce qui permet de stocker plusieurs adaptateurs légers et de revenir au point de départ à tout moment.

> 🎮 **Défi** — Une couche MLP `up_proj` d'un modèle a $d = 14\,336$ et $k = 4\,096$. Combien de paramètres LoRA avec $r = 8$ ? *Réponse : $8 \times (14\,336 + 4\,096) = 147\,456$, contre 58,7 millions pour la matrice complète.*

```quiz
{
  "q": "Pour une projection d'attention avec d = k = 4 096 et un rang r = 8, combien de paramètres LoRA entraîne-t-on ?",
  "options": [
    "65 536",
    "131 072",
    "16 777 216",
    "4 096"
  ],
  "answer": 0,
  "explanation": "r × (d + k) = 8 × 8 192 = 65 536, soit 0,39 % de la matrice complète (16,8 millions). 131 072 correspond à r = 16."
}
```

## 3. Les hyperparamètres, un par un

| Hyperparamètre | Rôle | Valeur de départ | Quand la changer |
|---|---|---|---|
| `r` (rang) | Capacité de l'adaptateur | 16 | 8 pour du style/format simple ; 32-64 pour une tâche riche ou beaucoup de données |
| `lora_alpha` | Échelle $\alpha/r$ | 16 à 2 × r (ex. 32 pour r = 16) | Garder le ratio constant quand vous changez `r` |
| `lora_dropout` | Régularisation sur l'entrée de l'adaptateur | 0,05 (0 avec Unsloth, optimisé pour) | 0,1 si le jeu est petit et que la perte de validation remonte |
| `target_modules` | Couches équipées d'un adaptateur | `q,k,v,o,gate,up,down_proj` (« all-linear ») | Attention seule si VRAM très contrainte, au prix d'une qualité moindre |
| Taux d'apprentissage | Pas d'optimisation | 2e-4 (LoRA), 1e-4 si instable | Beaucoup plus haut qu'en full fine-tuning (~1e-5) |
| Époques | Passes sur les données | 1 à 3 | Arrêter dès que la perte de validation stagne |
| `use_rslora` | Échelle $\alpha/\sqrt{r}$ (rsLoRA) | Faux | Utile pour les grands rangs (≥ 64) |
| `use_dora` | Décompose amplitude / direction (DoRA) | Faux | Gain parfois mesurable, entraînement plus lent |

Les noms de modules dépendent de l'architecture : `q_proj`, `k_proj`, `v_proj`, `o_proj`, `gate_proj`, `up_proj`, `down_proj` pour les familles Llama, Qwen, Mistral et Gemma. Dans PEFT, `target_modules="all-linear"` sélectionne automatiquement toutes les couches linéaires sauf la tête de sortie. Vérifiez avec `print(model)` en cas de doute.

> ⚠️ **Piège fréquent** — Copier un taux d'apprentissage de full fine-tuning (1e-5) dans un LoRA : la perte ne bouge presque pas et vous concluez à tort que « LoRA ne marche pas ». À l'inverse, 1e-3 fait diverger l'entraînement en quelques dizaines de pas. Restez entre 5e-5 et 3e-4 et regardez la courbe.

```quiz
{
  "q": "Votre LoRA est lancé avec un taux d'apprentissage de 1e-5 et la perte ne bouge presque pas. Que faites-vous en premier ?",
  "options": [
    "Passer r à 256",
    "Supprimer lora_alpha",
    "Basculer en full fine-tuning",
    "Remonter le taux vers 2e-4"
  ],
  "answer": 3,
  "explanation": "1e-5 est un taux de full fine-tuning : trop faible pour des adaptateurs partis de zéro. Commencez à 2e-4, et descendez à 1e-4 si l'entraînement est instable."
}
```

## 4. QLoRA : le modèle de base en 4 bits

QLoRA (Dettmers et al., mai 2023) ajoute trois idées à LoRA :

1. **NF4 (*4-bit NormalFloat*)** : les poids pré-entraînés suivent à peu près une loi normale ; NF4 place ses 16 niveaux de quantization aux quantiles de cette loi, ce qui perd moins d'information qu'un découpage régulier. Les poids gelés sont stockés en 4 bits et **déquantifiés à la volée** en BF16 pour le calcul.
2. **Double quantization** : les constantes d'échelle de la quantization sont elles-mêmes quantifiées, ce qui économise environ 0,4 bit par paramètre.
3. **Optimiseurs paginés** : les états de l'optimiseur peuvent déborder vers la RAM du processeur lors des pics de mémoire au lieu de provoquer une erreur *out of memory*.

Les gradients ne traversent que les adaptateurs LoRA, qui restent en BF16. L'article montre qu'un modèle de 65B se fine-tune sur un seul GPU de 48 Go en conservant la qualité d'un fine-tuning 16 bits sur leurs évaluations.

> 💡 **Autrement dit** — Le manuel (le modèle de base) est compressé en 4 bits et ne bouge plus ; seuls les post-it (les adaptateurs LoRA) apprennent, en 16 bits. NF4 place intelligemment ses 16 niveaux de compression là où se trouvent la plupart des poids, et les optimiseurs paginés évitent le plantage quand la mémoire déborde un instant.

### Estimer la VRAM

Reprenons la règle du module sur les LLM locaux : mémoire des poids ≈ paramètres (milliards) × bits ÷ 8 × 1,1.

> 🔢 **Exemple à la main** — 4 bits = $2^4 = 16$ niveaux possibles par poids, d'où les « 16 niveaux » de NF4. Pour un 8B : $8 \times 4 \div 8 \times 1{,}1 = 4{,}4$ Go de poids, la valeur basse de la ligne « 8B » du tableau (le « × 1,1 » couvre les constantes d'échelle et les couches gardées en plus haute précision). (Vérifié en Python.)

| Modèle | Poids 4 bits | Adaptateur + optimiseur (r = 16) | Activations (séquence 2 048, batch 2, gradient checkpointing) | **Total estimé** | GPU adapté |
|---|---|---|---|---|---|
| 4B (Gemma 4 E4B, Qwen3-4B) | ~2,5 Go | ~0,5 Go | ~2-3 Go | **~6-8 Go** | T4 16 Go (Colab), RTX 3060 12 Go |
| 8B (Qwen3-8B, Ministral 3 8B) | ~4,4-5,5 Go | ~1 Go | ~3-5 Go | **~10-12 Go** | RTX 4060 Ti 16 Go, L4 24 Go |
| 27B (Qwen3.8-27B) | ~15 Go | ~2 Go | ~5-7 Go | **~22-26 Go** | RTX 4090/5090, L40S 48 Go |

Ces chiffres sont des estimations à vérifier avec `torch.cuda.max_memory_allocated()` ; Unsloth annonce jusqu'à 70 % de VRAM en moins et un entraînement 2 fois plus rapide que la pile standard (documentation Unsloth, nov. 2026).

```quiz
{
  "type": "vrai_faux",
  "q": "Dans QLoRA, les adaptateurs LoRA sont eux aussi stockés et entraînés en 4 bits.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : seuls les poids gelés du modèle de base sont en NF4 (4 bits). Les adaptateurs restent en BF16 et reçoivent les gradients."
}
```

## 5. Script SFT complet : TRL + PEFT + bitsandbytes

Installation (Python 3.12, GPU NVIDIA, CUDA récent) :

```bash
python -m venv .venv && source .venv/bin/activate
pip install -U "torch" "transformers" "datasets" "peft" "trl" "bitsandbytes" "accelerate"
# Facultatif : suivi des courbes
pip install -U tensorboard
```

Données : un fichier `train.jsonl` au format *prompt-completion conversationnel* (la leçon L137 détaille sa construction). Une ligne :

```json
{"prompt": [{"role": "system", "content": "Vous êtes l'assistant SAV de la Maison Delorme."}, {"role": "user", "content": "Ma commande 4512 n'est pas arrivée."}], "completion": [{"role": "assistant", "content": "Bonjour, je suis désolé pour ce retard..."}]}
```

Avec ce format, TRL ne calcule la perte que sur la partie `completion` : le modèle apprend à **répondre**, pas à recopier les questions.

```python
"""sft_qlora.py — Fine-tuning QLoRA d'un modèle ouvert avec TRL + PEFT.
Exécution : python sft_qlora.py
Variables d'environnement facultatives : MODEL_ID, TRAIN_FILE, EVAL_FILE, OUTPUT_DIR, HF_TOKEN.
"""
import os

import torch
from datasets import load_dataset
from peft import LoraConfig
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from trl import SFTConfig, SFTTrainer

# Modèle de base : Qwen3-8B (Apache 2.0). Remplacez par une variante Qwen3.8 ou Gemma 4
# après avoir vérifié l'identifiant exact et la licence sur sa fiche Hugging Face.
MODEL_ID = os.environ.get("MODEL_ID", "Qwen/Qwen3-8B")
TRAIN_FILE = os.environ.get("TRAIN_FILE", "train.jsonl")
EVAL_FILE = os.environ.get("EVAL_FILE", "eval.jsonl")
OUTPUT_DIR = os.environ.get("OUTPUT_DIR", "adapters/sav-qlora")

# BF16 sur Ampere et plus récent (RTX 30xx/40xx/50xx, A100, L4, H100) ; FP16 sur T4 (Colab gratuit).
bf16_ok = torch.cuda.is_available() and torch.cuda.is_bf16_supported()
compute_dtype = torch.bfloat16 if bf16_ok else torch.float16

# 1) Quantization 4 bits NF4 + double quantization (QLoRA)
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=compute_dtype,
)

tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, token=os.environ.get("HF_TOKEN"))
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    quantization_config=bnb_config,
    device_map="auto",
    dtype=compute_dtype,  # sur les versions plus anciennes de transformers : torch_dtype=
    attn_implementation="sdpa",
    token=os.environ.get("HF_TOKEN"),
)

# 2) Adaptateur LoRA sur toutes les projections linéaires
peft_config = LoraConfig(
    r=16,
    lora_alpha=32,
    lora_dropout=0.05,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    bias="none",
    task_type="CAUSAL_LM",
)

# 3) Données au format prompt/completion conversationnel
data = load_dataset("json", data_files={"train": TRAIN_FILE, "eval": EVAL_FILE})

# 4) Hyperparamètres d'entraînement
args = SFTConfig(
    output_dir=OUTPUT_DIR,
    num_train_epochs=2,
    per_device_train_batch_size=2,
    gradient_accumulation_steps=8,      # batch effectif = 16
    learning_rate=2e-4,
    lr_scheduler_type="cosine",
    warmup_ratio=0.05,
    weight_decay=0.0,
    max_length=2048,                    # anciennes versions de TRL : max_seq_length
    gradient_checkpointing=True,
    bf16=bf16_ok,
    fp16=not bf16_ok,
    optim="paged_adamw_8bit",           # optimiseur paginé (QLoRA)
    logging_steps=10,
    eval_strategy="steps",
    eval_steps=50,
    save_strategy="steps",
    save_steps=50,
    save_total_limit=2,
    load_best_model_at_end=True,
    metric_for_best_model="eval_loss",
    report_to="tensorboard",
    seed=42,
)

trainer = SFTTrainer(
    model=model,
    args=args,
    train_dataset=data["train"],
    eval_dataset=data["eval"],
    processing_class=tokenizer,
    peft_config=peft_config,
)
trainer.model.print_trainable_parameters()  # vérifie qu'on entraîne bien < 1 % des poids

trainer.train()
trainer.save_model(OUTPUT_DIR)              # sauvegarde uniquement l'adaptateur (quelques centaines de Mo)
tokenizer.save_pretrained(OUTPUT_DIR)

pic = torch.cuda.max_memory_allocated() / 1e9 if torch.cuda.is_available() else 0
print(f"Pic de VRAM : {pic:.1f} Go — adaptateur sauvegardé dans {OUTPUT_DIR}")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True, ...)` : les trois réglages de QLoRA (section 4) ; `bnb_4bit_compute_dtype` est la précision des calculs après déquantification.
> - `tokenizer.pad_token = tokenizer.eos_token` : certains modèles n'ont pas de jeton de remplissage ; on réutilise celui de fin de texte pour égaliser les longueurs dans un lot.
> - `device_map="auto"` laisse la bibliothèque placer les couches sur le GPU (et déborder sur le CPU si besoin) ; `attn_implementation="sdpa"` utilise l'attention optimisée de PyTorch (L128).
> - `LoraConfig(r=16, lora_alpha=32, ...)` : échelle $\alpha/r = 2$ ; les sept noms de `target_modules` sont les projections d'attention et du MLP SwiGLU (L129).
> - `SFTConfig` : 2 exemples par passage × 8 accumulations = lot effectif de 16 ; avec 1 000 exemples, environ $1\,000/16 \approx 63$ pas par époque, 126 pour deux époques ; évaluation et sauvegarde tous les 50 pas, et `load_best_model_at_end` recharge le point de contrôle de meilleure perte de validation.
> - `print_trainable_parameters()` affiche le nombre de paramètres entraînables et leur pourcentage : il doit être inférieur à 1 %. `save_model` n'écrit que l'adaptateur.

**Lire les courbes.** Lancez `tensorboard --logdir adapters/`. La perte d'entraînement doit baisser régulièrement ; la perte de validation baisse puis se stabilise. Si elle **remonte** alors que la perte d'entraînement continue de chuter, vous sur-apprenez (vu en L116) : réduisez les époques, augmentez le dropout ou ajoutez des données.

**Tester l'adaptateur** sans fusion :

```python
"""test_adapter.py — Génère une réponse avec le modèle de base + adaptateur LoRA."""
import os

import torch
from peft import AutoPeftModelForCausalLM
from transformers import AutoTokenizer

ADAPTER = os.environ.get("OUTPUT_DIR", "adapters/sav-qlora")
tok = AutoTokenizer.from_pretrained(ADAPTER)
model = AutoPeftModelForCausalLM.from_pretrained(ADAPTER, device_map="auto", dtype=torch.bfloat16)

messages = [
    {"role": "system", "content": "Vous êtes l'assistant SAV de la Maison Delorme."},
    {"role": "user", "content": "Je veux retourner un article reçu abîmé, comment faire ?"},
]
inputs = tok.apply_chat_template(messages, add_generation_prompt=True, return_tensors="pt").to(model.device)
out = model.generate(inputs, max_new_tokens=300, do_sample=False)
print(tok.decode(out[0][inputs.shape[1]:], skip_special_tokens=True))
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `AutoPeftModelForCausalLM.from_pretrained(ADAPTER)` lit dans le dossier de l'adaptateur le nom du modèle de base, le charge, puis greffe les matrices LoRA. `apply_chat_template(..., add_generation_prompt=True, return_tensors="pt")` met la conversation au format du modèle (tokens spéciaux, L130) et renvoie un tenseur d'identifiants de forme `(1, n)`. `do_sample=False` = décodage glouton (reproductible). `out[0][inputs.shape[1]:]` retire les `n` premiers tokens (la question) pour n'afficher que la réponse générée.

## 6. Variante Unsloth : même résultat, moins de VRAM

Unsloth réécrit les noyaux de calcul critiques (attention, RoPE, pertes) et fournit des modèles pré-quantifiés. L'API s'appuie sur TRL : votre `SFTConfig` reste valable. Installation : `pip install unsloth` (ou l'installeur et l'image Docker `unsloth/unsloth` décrits dans la documentation).

```python
"""sft_unsloth.py — Même fine-tuning QLoRA, version Unsloth (import en premier : il patche transformers)."""
import os

from unsloth import FastLanguageModel  # doit être importé avant transformers/trl

from datasets import load_dataset
from trl import SFTConfig, SFTTrainer

MODEL_ID = os.environ.get("MODEL_ID", "unsloth/Qwen3-8B-unsloth-bnb-4bit")  # vérifiez le nom exact sur huggingface.co/unsloth
MAX_LEN = 2048

model, tokenizer = FastLanguageModel.from_pretrained(
    model_name=MODEL_ID,
    max_seq_length=MAX_LEN,
    load_in_4bit=True,
    dtype=None,  # détection automatique BF16/FP16
)

model = FastLanguageModel.get_peft_model(
    model,
    r=16,
    lora_alpha=16,
    lora_dropout=0,  # 0 = chemin optimisé par Unsloth
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    bias="none",
    use_gradient_checkpointing="unsloth",  # checkpointing économe en VRAM
    random_state=3407,
)

data = load_dataset("json", data_files={"train": "train.jsonl", "eval": "eval.jsonl"})

trainer = SFTTrainer(
    model=model,
    processing_class=tokenizer,
    train_dataset=data["train"],
    eval_dataset=data["eval"],
    args=SFTConfig(
        output_dir="adapters/sav-unsloth",
        per_device_train_batch_size=2,
        gradient_accumulation_steps=8,
        num_train_epochs=2,
        learning_rate=2e-4,
        warmup_ratio=0.05,
        lr_scheduler_type="cosine",
        optim="adamw_8bit",
        max_length=MAX_LEN,
        logging_steps=10,
        eval_strategy="steps",
        eval_steps=50,
        seed=3407,
        report_to="none",
    ),
)
stats = trainer.train()
print(f"Durée : {stats.metrics['train_runtime'] / 60:.1f} min")
model.save_pretrained("adapters/sav-unsloth")
tokenizer.save_pretrained("adapters/sav-unsloth")
```

L'export GGUF vers Ollama, une ligne avec Unsloth, est traité dans le projet L140.

> 🔗 **Documentation officielle** — [TRL — PEFT integration](https://huggingface.co/docs/trl/main/en/peft_integration) · [Unsloth docs](https://unsloth.ai/docs) · [Axolotl + Unsloth](https://docs.axolotl.ai/docs/unsloth.html)

## 7. Temps et coût : ordres de grandeur

Pour 1 000 exemples de ~500 tokens, 2 époques, soit ~1 million de tokens traités :

| Configuration | Débit d'entraînement estimé | Durée estimée | Coût estimé (nov. 2026) |
|---|---|---|---|
| 8B QLoRA, RTX 4090 louée | ~1 500-3 000 tokens/s | 6 à 12 min (+ chargement) | < 0,20 $ à 0,34 $/h (RunPod Community) |
| 8B QLoRA, L4 24 Go Scaleway | ~700-1 500 tokens/s | 12 à 25 min | ~0,30 € à 0,75 €/h |
| 4B QLoRA, T4 Colab | ~400-800 tokens/s | 20 à 45 min | Gratuit selon disponibilité Colab |
| 27B QLoRA, L40S 48 Go Scaleway | ~400-800 tokens/s | 20 à 45 min | ~1 € à 1,40 €/h |

Les débits sont des **estimations** pédagogiques : mesurez-les sur votre machine (TRL affiche `train_samples_per_second`). La conclusion, elle, est robuste : sur ce volume, le GPU coûte moins qu'un café.

> 🔢 **Exemple à la main** — 1 000 exemples × 500 tokens × 2 époques $= 10^6$ tokens. À 2 000 tokens/s : $10^6 / 2\,000 = 500$ s $\approx 8$ min. À 0,34 $/h, cela coûte $0{,}34 \times 500/3\,600 \approx 0{,}05$ dollar, d'où « moins qu'un café ». (Calcul vérifié en Python.)

**Quel outil choisir ?** TRL + PEFT pour comprendre et contrôler chaque paramètre ; Unsloth pour aller vite sur un seul GPU ; **Axolotl** pour décrire tout l'entraînement dans un fichier YAML reproductible et passer au multi-GPU.

```mission
{
  "title": "Ce que LoRA économise, d'après ses auteurs",
  "url": "https://arxiv.org/abs/2106.09685v1",
  "steps": [
    "Ouvrez la page arXiv de l'article LoRA (Hu et al., 2021)",
    "Lisez l'abstract",
    "Repérez les deux facteurs de réduction annoncés et la phrase sur la latence d'inférence"
  ],
  "question": "Face au fine-tuning complet de GPT-3 175B avec Adam, de combien LoRA réduit-il le nombre de paramètres entraînables et la mémoire GPU ? Ajoute-t-il de la latence à l'inférence ?",
  "hint": "Deux facteurs : l'un à cinq chiffres, l'autre à un chiffre.",
  "answer": "10 000 fois moins de paramètres entraînables et 3 fois moins de mémoire GPU, sans latence d'inférence supplémentaire (les post-it peuvent être fusionnés dans les poids). Article de 2021, réponse stable.",
  "xp": 15
}
```

```mission
{
  "title": "Guanaco, la vitrine de QLoRA",
  "url": "https://arxiv.org/abs/2305.14314",
  "steps": [
    "Ouvrez la page arXiv de QLoRA (Dettmers et al., 2023)",
    "Lisez l'abstract",
    "Repérez le nom de la famille de modèles, le score obtenu et la durée d'entraînement"
  ],
  "question": "Quel niveau la meilleure version de Guanaco atteint-elle par rapport à ChatGPT sur le benchmark Vicuna, et en combien de temps de fine-tuning sur un seul GPU ?",
  "hint": "Cherchez un pourcentage proche de 100 et une durée en heures.",
  "answer": "99,3 % du niveau de ChatGPT sur le benchmark Vicuna, après seulement 24 heures de fine-tuning sur un seul GPU (un modèle de 65B tient sur un GPU de 48 Go). Article de 2023, réponse stable ; le benchmark Vicuna est aujourd'hui dépassé.",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** Sur Colab ou un GPU loué, fine-tunez un modèle de 4 à 8B avec `sft_qlora.py` sur 200 exemples (vous pouvez utiliser un jeu public de chat en français du Hub, en vérifiant sa licence). Faites ensuite deux variantes : `r = 8, alpha = 16` puis `r = 64, alpha = 128`. Notez pour chaque essai : paramètres entraînables, pic de VRAM, durée, perte de validation finale.

**Critères de réussite.** Les trois entraînements terminent sans erreur ; le tableau comparatif est rempli ; vous savez expliquer pourquoi la VRAM varie peu entre r = 8 et r = 64 (ce sont les poids 4 bits et les activations qui dominent) ; vous avez lancé `test_adapter.py` et comparé une réponse avant/après.

<details><summary>Pistes de corrigé</summary>

Avec un 8B, r = 8 entraîne ~20 M de paramètres, r = 64 ~170 M ; la VRAM ne prend qu'environ 1 à 2 Go de plus. Sur 200 exemples, r = 64 tend à sur-apprendre (perte de validation qui remonte après la première époque). La variante r = 16 / alpha = 32 est généralement le meilleur compromis pour ce volume.
</details>

## ✅ Auto-évaluation express
1. Pourquoi initialise-t-on $B$ à zéro dans LoRA ?
2. Que stocke-t-on en 4 bits dans QLoRA, et qu'est-ce qui reste en 16 bits ?
3. Vous passez de r = 16 à r = 32 : que faites-vous de `lora_alpha` pour garder la même échelle de mise à jour ?

*Réponses : 1. Pour que $BA = 0$ au départ : le modèle adapté commence identique au modèle de base. 2. Les poids gelés du modèle de base en NF4 ; les adaptateurs LoRA et les calculs (déquantification à la volée) restent en BF16/FP16. 3. Vous le doublez (32 → 64) pour conserver le ratio $\alpha / r$.*

## 📚 Pour aller plus loin
- [Hu et al. — LoRA (2021)](https://arxiv.org/abs/2106.09685v1) 🇬🇧 — l'article fondateur, section 4 pour la méthode.
- [Dettmers et al. — QLoRA (2023)](https://arxiv.org/abs/2305.14314) 🇬🇧 — NF4, double quantization, optimiseurs paginés.
- [TRL — PEFT integration](https://huggingface.co/docs/trl/main/en/peft_integration) 🇬🇧 — SFTTrainer, DPOTrainer et GRPO avec adaptateurs.
- [Unsloth — documentation](https://unsloth.ai/docs) 🇬🇧 — notebooks Colab par modèle, export GGUF.
- [Hugging Face LLM Course](https://huggingface.co/learn/llm-course) 🇬🇧 — chapitre 11 « Fine-tune Large Language Models ».

> ✅ **Si vous ne retenez que 3 choses** — 1. LoRA gèle le modèle et apprend une correction de rang faible $\frac{\alpha}{r}BA$ ($B$ initialisée à zéro) : moins de 1 % des paramètres, un adaptateur léger que l'on peut fusionner ou échanger. 2. QLoRA stocke en plus le modèle de base en 4 bits (NF4, double quantization, optimiseurs paginés) : un 8B se fine-tune sur un GPU de 16 à 24 Go. 3. Points de départ : `r = 16`, `lora_alpha = 32`, toutes les projections linéaires, taux 2e-4, 1 à 3 époques, et surveillez la perte de validation.

> 🗺️ **Et maintenant ?** — Un LoRA ne vaut que ce que valent ses exemples : la leçon L137 vous apprend à construire, nettoyer et enrichir le jeu de données qui l'alimente.
