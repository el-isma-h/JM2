---
id: L137
module: M28
level: N4
title: "Jeux de données, données synthétiques, distillation"
minutes: 60
objectives:
  - "Construire un jeu de données de fine-tuning aux formats chat, prompt-completion et préférences (DPO)"
  - "Appliquer un pipeline de nettoyage : déduplication, filtrage, pseudonymisation, séparation train/eval"
  - "Générer des données synthétiques avec un grand modèle en vérifiant licences et conditions d'utilisation"
  - "Expliquer la distillation et l'alignement par préférences (RLHF, DPO) et lancer un DPO avec TRL"
skills: ["C4.4"]
sources:
  - { title: "Hugging Face LLM Course — chapitre 10 « Curate high-quality datasets »", url: "https://huggingface.co/learn/llm-course", lang: "en" }
  - { title: "a smol course — Instruction tuning, Preference alignment, Synthetic data", url: "https://huggingface.co/learn/smol-course", lang: "en" }
  - { title: "Hugging Face TRL — PEFT integration (SFT, DPO)", url: "https://huggingface.co/docs/trl/main/en/peft_integration", lang: "en" }
  - { title: "DeepSeek-R1 — fiche modèle (distillats, licence MIT)", url: "https://huggingface.co/deepseek-ai/DeepSeek-R1", lang: "en" }
  - { title: "CNIL — Développement des systèmes d'IA : les recommandations de la CNIL", url: "https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd", lang: "fr" }
  - { title: "Stanford CS336 — Lectures 14-17 (données, post-training)", url: "https://cs336.stanford.edu/", lang: "en" }
---

# Jeux de données, données synthétiques, distillation

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 28

## 🎯 Ce que vous saurez faire
- Écrire des exemples d'entraînement aux trois formats que TRL comprend : *messages*, *prompt-completion*, *préférences*.
- Nettoyer un export brut (courriels, tickets) : déduplication, filtres de qualité, pseudonymisation RGPD, découpage train/eval sans fuite.
- Générer des données synthétiques avec un grand modèle et vérifier que la licence et les conditions d'utilisation l'autorisent.
- Expliquer la distillation, RLHF et DPO, et lancer un entraînement DPO sur des paires de préférence.

> 🧭 **En clair** — Un modèle fine-tuné ressemble à un élève qui imite fidèlement ce qu'on lui montre, erreurs comprises : il ne vaut que ce que valent ses exemples. Cette leçon est donc une leçon de cuisine… des données : trier, enlever les doublons, retirer les noms et numéros de téléphone (RGPD), et mettre de côté un jeu de contrôle que l'élève ne verra jamais. Quand les exemples manquent, un grand modèle peut en rédiger (les données synthétiques), à condition de vérifier que sa licence l'autorise. La distillation, c'est un grand chef dont l'apprenti reproduit les plats ; l'alignement par préférences, c'est l'apprenti cuisinier corrigé par des goûteurs qui disent laquelle de deux assiettes est la meilleure.

## 1. La qualité bat la quantité

En mai 2023, l'article **LIMA** (*Less Is More for Alignment*, Meta) montrait qu'un modèle de 65B fine-tuné sur seulement **1 000 exemples soigneusement choisis** produisait des réponses jugées comparables à celles de systèmes entraînés sur des volumes bien plus grands. Deux mois plus tôt, Stanford avait publié **Alpaca** : 52 000 instructions générées par un modèle d'OpenAI pour moins de 600 dollars, qui avaient suffi à transformer un modèle de base en assistant convenable. Ces deux résultats résument la leçon : en fine-tuning, **un exemple faux coûte plus cher qu'un exemple manquant**. Le modèle apprend fidèlement vos erreurs.

Ordres de grandeur utiles pour un fine-tuning LoRA de spécialisation :

| Objectif | Nombre d'exemples typique |
|---|---|
| Format strict (JSON, gabarit) | 200 à 1 000 |
| Ton / style de marque | 500 à 2 000 |
| Tâche métier riche (SAV multi-cas, rédaction juridique simplifiée) | 1 000 à 10 000 |
| Préférences (DPO) en complément d'un SFT | 300 à 3 000 paires |

```quiz
{
  "q": "Qu'a montré l'article LIMA (Meta, 2023) ?",
  "options": [
    "Qu'il faut au moins un million d'exemples pour aligner un modèle",
    "Que 1 000 exemples bien choisis peuvent suffire",
    "Que les données synthétiques sont interdites en fine-tuning",
    "Que le SFT dégrade toujours un modèle de 65B"
  ],
  "answer": 1,
  "explanation": "La qualité et la diversité des exemples comptent plus que leur nombre : c'est le fil rouge de toute la leçon."
}
```

## 2. Les formats de données

TRL reconnaît plusieurs formats ; les trois suivants couvrent 95 % des besoins.

**a) Conversationnel « messages »** — la conversation complète ; la perte porte par défaut sur toute la séquence (sauf option `assistant_only_loss`, qui exige un modèle de chat compatible).

```json
{"messages": [{"role": "system", "content": "Vous êtes l'assistant RH de la société Ardent."}, {"role": "user", "content": "Combien de jours de congés payés j'acquiers par mois ?"}, {"role": "assistant", "content": "En règle générale, 2,5 jours ouvrables par mois de travail effectif, soit 30 jours ouvrables (5 semaines) par an. Votre convention collective peut prévoir plus : je vous invite à vérifier auprès du service RH."}]}
```

**b) Prompt-completion conversationnel** — recommandé pour un SFT : la perte ne porte que sur `completion`.

```json
{"prompt": [{"role": "user", "content": "Classe ce ticket : « Le lien de paiement ne fonctionne pas »"}], "completion": [{"role": "assistant", "content": "{\"categorie\": \"paiement\", \"priorite\": \"haute\"}"}]}
```

**c) Préférences** — pour DPO : une même consigne, une réponse préférée, une réponse rejetée.

```json
{"prompt": [{"role": "user", "content": "Mon colis est en retard de 10 jours."}], "chosen": [{"role": "assistant", "content": "Je suis désolé pour ce retard. Pouvez-vous me donner votre numéro de commande ? Je lance immédiatement une enquête auprès du transporteur et je reviens vers vous sous 48 h."}], "rejected": [{"role": "assistant", "content": "Les délais de livraison ne dépendent pas de nous, contactez le transporteur."}]}
```

> 💡 **À retenir** — Le **chat template** (balises spéciales propres à chaque famille de modèles) est appliqué automatiquement par le tokenizer. N'écrivez jamais vous-même les balises `<|im_start|>` ou `<start_of_turn>` dans vos données : fournissez des listes de messages et laissez `apply_chat_template` faire le travail.

```quiz
{
  "q": "Vous préparez un entraînement DPO. Quel format de données utilisez-vous ?",
  "options": [
    "Conversationnel « messages » (system, user, assistant)",
    "Prompt-completion",
    "Préférences : prompt, chosen, rejected",
    "Texte brut, un document par ligne"
  ],
  "answer": 2,
  "explanation": "DPO apprend à préférer une réponse à une autre : il lui faut des paires chosen / rejected pour une même consigne."
}
```

## 3. Le pipeline de nettoyage

Un export brut de 3 ans de courriels SAV contient des doublons, des réponses d'une ligne, des signatures, des numéros de téléphone et des réponses fausses. Voici un script complet qui transforme un CSV `question,reponse` en jeux d'entraînement et d'évaluation propres.

```python
"""prepare_data.py — Nettoie un export CSV (colonnes : question, reponse) et produit train.jsonl / eval.jsonl.
Usage : python prepare_data.py export_sav.csv
"""
import hashlib
import json
import random
import re
import sys

import pandas as pd

SYSTEM = "Vous êtes l'assistant SAV de la Maison Delorme. Répondez en français, avec courtoisie, en 120 mots maximum."

# 1) Pseudonymisation : on remplace les données personnelles par des marqueurs (RGPD, minimisation)
PATTERNS = {
    "[EMAIL]": r"[\w.+-]+@[\w-]+\.[\w.-]+",
    "[TELEPHONE]": r"(?:\+33\s?|0)[1-9](?:[\s.-]?\d{2}){4}",
    "[IBAN]": r"\bFR\d{2}(?:\s?[\dA-Z]{4}){5}\s?[\dA-Z]{3}\b",
    "[NUM_COMMANDE]": r"\b(?:commande|cde)\s*(?:n°|no|#)?\s*\d{4,}\b",
}

def pseudonymiser(texte: str) -> str:
    for marqueur, motif in PATTERNS.items():
        texte = re.sub(motif, marqueur, texte, flags=re.IGNORECASE)
    return texte

def nettoyer(texte: str) -> str:
    texte = re.split(r"\n--\s*\n|Cordialement,?\s*\n", str(texte))[0]  # coupe la signature
    texte = re.sub(r"\s+", " ", texte).strip()
    return pseudonymiser(texte)

def empreinte(texte: str) -> str:
    """Empreinte normalisée pour détecter les quasi-doublons (casse, ponctuation, chiffres)."""
    norm = re.sub(r"[^a-zàâçéèêëîïôûùüÿœ ]", "", texte.lower())
    norm = re.sub(r"\s+", " ", norm).strip()   # espaces doubles laissés par les chiffres retirés
    return hashlib.sha1(norm.encode()).hexdigest()

df = pd.read_csv(sys.argv[1]).dropna(subset=["question", "reponse"])
df["question"] = df["question"].map(nettoyer)
df["reponse"] = df["reponse"].map(nettoyer)

# 2) Filtres de qualité
n0 = len(df)
df = df[df["reponse"].str.split().str.len().between(15, 250)]           # ni trop court, ni trop long
df = df[~df["reponse"].str.contains(r"\b(?:test|xxx|lorem)\b", case=False)]
df = df.drop_duplicates(subset=["question"]).copy()
df["h"] = df["question"].map(empreinte)
df = df.drop_duplicates(subset=["h"])
print(f"{n0} lignes brutes -> {len(df)} après nettoyage")

# 3) Séparation train / eval AVANT toute augmentation (sinon fuite d'information)
lignes = df[["question", "reponse"]].to_dict("records")
random.Random(42).shuffle(lignes)
n_eval = max(30, len(lignes) // 10)
eval_set, train_set = lignes[:n_eval], lignes[n_eval:]

def to_record(r: dict) -> dict:
    return {
        "prompt": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": r["question"]}],
        "completion": [{"role": "assistant", "content": r["reponse"]}],
    }

for nom, jeu in [("train.jsonl", train_set), ("eval.jsonl", eval_set)]:
    with open(nom, "w", encoding="utf-8") as f:
        for r in jeu:
            f.write(json.dumps(to_record(r), ensure_ascii=False) + "\n")
    print(f"{nom} : {len(jeu)} exemples")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `PATTERNS` associe un marqueur à une **expression régulière** (un motif de recherche) : `[\w.+-]+@[\w-]+\.[\w.-]+` = « des lettres/chiffres, une arobase, un domaine avec un point » ; dans le motif du téléphone, `(?:\+33\s?|0)` = « +33 ou 0 », puis `[1-9]` et quatre groupes de deux chiffres séparés ou non par espace, point ou tiret. `re.sub(motif, marqueur, texte, flags=re.IGNORECASE)` remplace chaque occurrence.
> - `nettoyer` coupe tout ce qui suit « -- » ou « Cordialement », remplace les suites d'espaces et de retours à la ligne par un seul espace, puis pseudonymise.
> - `empreinte` met en minuscules, ne garde que les lettres (accents compris) et les espaces, puis calcule un **hachage** SHA-1 : une « empreinte digitale » de 40 caractères, identique pour deux textes normalisés identiques.
> - Filtres pandas : `.str.split().str.len()` compte les mots de chaque réponse et `.between(15, 250)` garde celles de 15 à 250 mots ; `~` inverse un filtre (« ne contient pas ») ; `drop_duplicates(subset=[...])` supprime les doublons sur la colonne indiquée.
> - Séparation : `random.Random(42).shuffle` mélange de façon reproductible ; `n_eval = max(30, len // 10)` réserve 10 % des exemples à l'évaluation, avec un minimum de 30 (les 30 cas de test de L135).
> - `to_record` produit le format prompt-completion de la section 2 ; `json.dumps(..., ensure_ascii=False)` garde les accents lisibles, une ligne JSON par exemple (format `.jsonl`).

Après ce script, **relisez à la main un échantillon de 50 exemples**. Aucun filtre automatique ne détecte une réponse factuellement fausse ou un geste commercial accordé à tort.

> 🔢 **Exemple à la main** — Avec 1 000 lignes propres : `n_eval` $= \max(30, 1000 // 10) = 100$, donc 900 en entraînement ; avec 200 lignes : $\max(30, 20) = 30$. Empreintes : « Où est ma commande ? » et « où est ma commande !! » se normalisent toutes deux en « où est ma commande » et reçoivent le **même** hachage (doublon détecté) ; « Où est ma commande 4512 ? » donne un hachage différent, car la suppression des chiffres laisse deux espaces consécutifs. Une reformulation (« Ma commande, elle est où ? ») n'est pas détectée non plus : d'où la relecture humaine et la déduplication par embeddings évoquée dans le corrigé. Le motif du téléphone remplace bien « 06 12 34 56 78 » comme « +33 6 12 34 56 78 » par `[TELEPHONE]`. (Vérifié en Python.)

> ⚠️ **Piège fréquent** — La fuite entre entraînement et évaluation. Si la même question (reformulée) figure dans les deux jeux, votre évaluation mesure la mémoire, pas la compétence. Séparez **avant** l'augmentation et la génération synthétique, et dédupliquez par empreinte normalisée, pas seulement par égalité stricte.

**Côté RGPD**, des courriels clients sont des données personnelles : base légale (intérêt légitime documenté le plus souvent), minimisation, pseudonymisation, durée de conservation, information des personnes. La CNIL a publié des recommandations et des fiches pratiques dédiées au développement des systèmes d'IA, finalisées en juillet 2025 ; elles s'appliquent pleinement à la constitution d'un jeu de fine-tuning.

> 🎮 **Défi** — Trouvez les trois défauts de cette ligne d'entraînement : `{"prompt": [{"role": "user", "content": "Bonjour, je suis Mme Durand (06 12 34 56 78), où en est ma commande ?"}], "completion": [{"role": "assistant", "content": "ok"}]}`. *Réponse : nom et numéro de téléphone non pseudonymisés (RGPD) ; réponse d'un mot, sans valeur à imiter (filtre de qualité) ; aucune trace de provenance (champ `origine`).*

## 4. Les données synthétiques

Quand vous n'avez pas assez d'exemples, un grand modèle peut en produire. La méthode remonte à *Self-Instruct* (Wang et al., 2022), reprise par Alpaca. Le pipeline sûr :

1. **Graines humaines** : 30 à 100 exemples réels relus.
2. **Génération** : le grand modèle produit des variantes (nouvelles situations clients, reformulations, cas limites).
3. **Filtrage** : déduplication, contrôle de format, et idéalement un second passage du modèle en juge (L138).
4. **Relecture humaine** d'un échantillon, puis séparation train/eval.

```python
"""synth.py — Génère des questions SAV synthétiques avec un modèle ouvert servi en local (Ollama, API compatible OpenAI).
Prérequis : ollama pull qwen3.8:27b ; pip install openai
"""
import json
import os

from openai import OpenAI

# Par défaut : Qwen3.8-27B (Apache 2.0) via Ollama en local — aucune donnée ne sort du poste.
client = OpenAI(base_url=os.environ.get("TEACHER_BASE_URL", "http://localhost:11434/v1"),
                api_key=os.environ.get("TEACHER_API_KEY", "ollama"))
TEACHER = os.environ.get("TEACHER_MODEL", "qwen3.8:27b")

GRAINES = [
    "Mon colis est indiqué livré mais je ne l'ai pas reçu.",
    "Puis-je échanger une taille sur un article soldé ?",
    "Le bouton de paiement affiche une erreur 502.",
]

consigne = (
    "Tu génères des données d'entraînement pour le SAV d'une boutique française de linge de maison. "
    "À partir des exemples suivants, écris 10 NOUVELLES questions clients variées (ton, longueur, situations), "
    "réalistes, en français, sans données personnelles réelles. Réponds uniquement par une liste JSON de chaînes.\n"
    + "\n".join(f"- {g}" for g in GRAINES)
)

rep = client.chat.completions.create(model=TEACHER, messages=[{"role": "user", "content": consigne}])
texte = rep.choices[0].message.content.strip().removeprefix("```json").removesuffix("```")
questions = json.loads(texte)

with open("questions_synth.jsonl", "a", encoding="utf-8") as f:
    for q in questions:
        f.write(json.dumps({"question": q, "origine": f"synthetique:{TEACHER}"}, ensure_ascii=False) + "\n")
print(f"{len(questions)} questions ajoutées")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `OpenAI(base_url="http://localhost:11434/v1", api_key="ollama")` utilise la bibliothèque cliente d'OpenAI pour parler à **Ollama en local**, qui imite la même API (la clé est factice). La consigne colle les phrases graines sous forme de liste. `rep.choices[0].message.content` est le texte renvoyé ; `.removeprefix("```json").removesuffix("```")` enlève l'éventuel bloc de code que le modèle ajoute autour du JSON, puis `json.loads` le transforme en liste Python. Si le modèle renvoie autre chose qu'une liste JSON valide, `json.loads` lève une erreur : en production, on entoure cet appel d'un `try` et on relance. Le mode `"a"` (*append*) ajoute à la fin du fichier sans l'écraser.

Notez le champ `origine` : tracer la provenance de chaque exemple est une bonne pratique de gouvernance (et un réflexe utile face aux obligations de documentation de l'AI Act pour les fournisseurs de modèles).

### Licences et conditions d'utilisation : la question qui fâche

Utiliser les sorties d'un modèle pour en entraîner un autre n'est pas neutre juridiquement.

| Source des données synthétiques | Situation (nov. 2026) | Recommandation |
|---|---|---|
| Modèle ouvert **Apache 2.0 / MIT** (Qwen3.8-27B, gpt-oss, Mistral Small 4, Gemma 4) | Licences permissives sur les poids ; vérifiez toutefois la fiche du modèle et toute politique d'usage associée | Choix le plus sûr pour un usage commercial |
| **DeepSeek-R1** (MIT) | La fiche du modèle autorise explicitement les travaux dérivés, y compris la distillation | Professeur de raisonnement possible |
| Licences communautaires (Llama 4, Muse, Kimi K3, Qwen3.8-Max) | Seuils de revenus, mentions obligatoires, usages interdits ; clauses éventuelles sur l'entraînement d'autres modèles | Lire la licence ligne à ligne avant usage |
| **API commerciales** (OpenAI, Anthropic, Google, Mistral…) | Les conditions d'utilisation des grands fournisseurs encadrent historiquement l'usage des sorties pour développer des modèles concurrents | Vérifier les CGU en vigueur ; en cas de doute, demander un avis juridique |

> ⚠️ **Piège fréquent** — « Les sorties m'appartiennent, donc je peux en faire ce que je veux. » La propriété des sorties et le **droit d'en entraîner un modèle** sont deux questions distinctes, réglées par les conditions d'utilisation. Documentez la source et la version des CGU consultées dans votre dossier de projet.

```quiz
{
  "q": "Vous voulez générer des données synthétiques avec l'API d'un fournisseur commercial pour entraîner un modèle que vous commercialiserez. Que vérifiez-vous en premier ?",
  "options": [
    "La température utilisée pour générer",
    "La taille de votre GPU",
    "Le nombre de tokens générés",
    "Les CGU du fournisseur sur l'entraînement"
  ],
  "answer": 3,
  "explanation": "La propriété des sorties et le droit d'en entraîner un modèle sont deux questions distinctes : les CGU des grands fournisseurs encadrent cet usage."
}
```

## 5. Distillation : le professeur et l'élève

La **distillation de connaissances** (Hinton, Vinyals et Dean, 2015) consiste à entraîner un petit modèle « élève » à imiter un grand modèle « professeur ». Deux variantes :

- **Distillation des logits** (historique) : l'élève apprend la distribution de probabilité complète du professeur sur chaque token. Elle exige l'accès aux probabilités, donc en pratique un professeur ouvert partageant le même tokenizer.
- **Distillation par séquences** (la plus courante avec les LLM) : le professeur génère des réponses complètes, l'élève est fine-tuné dessus en SFT. C'est exactement le script `synth.py` suivi de `sft_qlora.py`.

> 💡 **Autrement dit** — Distillation des logits : l'élève voit les hésitations du professeur (« 70 % ce mot, 20 % celui-là »). Distillation par séquences : l'élève ne voit que la copie finale. La seconde est moins riche, mais elle fonctionne avec n'importe quel professeur, même accessible seulement par API.

L'exemple le plus célèbre est **DeepSeek-R1-Distill** : des modèles de 1,5B à 70B (bases Qwen et Llama) entraînés sur des traces de raisonnement produites par DeepSeek-R1 (671B), qui héritent d'une large part de ses capacités en mathématiques et en code. Pour une PME, la distillation est souvent le vrai cas d'usage : prototyper avec Claude Opus 5.5 ou Qwen3.8-27B, puis distiller le comportement validé dans un modèle de 4B servi pour presque rien (sous réserve des CGU, section 4).

```mission
{
  "title": "Les élèves de DeepSeek-R1",
  "url": "https://huggingface.co/deepseek-ai/DeepSeek-R1",
  "steps": [
    "Ouvrez la fiche du modèle DeepSeek-R1 sur Hugging Face",
    "Descendez jusqu'à la section « DeepSeek-R1-Distill Models »",
    "Lisez le tableau des modèles distillés et la section « License »"
  ],
  "question": "Quels modèles distillés sont construits sur une base Llama, et quelle condition de licence la fiche rappelle-t-elle pour ces modèles distillés ?",
  "hint": "Le tableau indique pour chaque modèle distillé son « Base Model ».",
  "answer": "DeepSeek-R1-Distill-Llama-8B (base Llama 3.1 8B) et DeepSeek-R1-Distill-Llama-70B (base Llama 3.3 70B Instruct) ; le dépôt est sous licence MIT (distillation autorisée), mais les modèles distillés restent soumis aux licences de leurs bases (Apache 2.0 pour Qwen 2.5, licences Llama 3.1 / 3.3). Fiche consultée en nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 6. Alignement par préférences : RLHF et DPO

Le SFT montre au modèle **une** bonne réponse. Les préférences lui apprennent à distinguer **la meilleure de deux**.

- **RLHF** (InstructGPT, OpenAI, 2022) : des humains classent des réponses ; on entraîne un modèle de récompense ; on optimise le LLM avec PPO contre ce modèle. Puissant mais lourd : quatre modèles en mémoire (politique, référence, récompense, critique de PPO), instabilité.
- **DPO** (*Direct Preference Optimization*, Rafailov et al., 2023) : une perte de classification directement sur les paires `chosen`/`rejected`, sans modèle de récompense ni boucle de renforcement. Le paramètre `beta` règle la distance tolérée par rapport au modèle de référence (le modèle SFT).

> 💡 **Autrement dit** — Revenons à l'apprenti cuisinier corrigé par des goûteurs : le RLHF forme d'abord un « goûteur artificiel », puis fait cuisiner l'apprenti pour lui plaire ; DPO montre directement à l'apprenti les paires d'assiettes « préférée / refusée », sans goûteur intermédiaire.

Vous avez vu ces méthodes en théorie en L133. Voici la pratique, sur l'adaptateur SFT de L136 :

```python
"""dpo.py — DPO avec TRL sur un modèle déjà fine-tuné en SFT (adaptateur LoRA).
Données : prefs.jsonl au format {"prompt": [...], "chosen": [...], "rejected": [...]}.
"""
import os

import torch
from datasets import load_dataset
from peft import AutoPeftModelForCausalLM
from transformers import AutoTokenizer
from trl import DPOConfig, DPOTrainer

SFT_ADAPTER = os.environ.get("SFT_ADAPTER", "adapters/sav-qlora")

tokenizer = AutoTokenizer.from_pretrained(SFT_ADAPTER)
# is_trainable=True : on continue d'entraîner l'adaptateur SFT ; avec un modèle PEFT,
# TRL utilise le modèle sans adaptateur comme référence (pas de second modèle en mémoire).
model = AutoPeftModelForCausalLM.from_pretrained(
    SFT_ADAPTER, is_trainable=True, device_map="auto", dtype=torch.bfloat16
)

prefs = load_dataset("json", data_files="prefs.jsonl", split="train").train_test_split(test_size=0.1, seed=42)

args = DPOConfig(
    output_dir="adapters/sav-dpo",
    beta=0.1,                        # plus petit = s'éloigne davantage de la référence
    learning_rate=5e-6,              # DPO : bien plus bas que le SFT
    per_device_train_batch_size=1,
    gradient_accumulation_steps=8,
    num_train_epochs=1,
    max_length=1536,
    gradient_checkpointing=True,
    bf16=True,
    logging_steps=10,
    eval_strategy="steps",
    eval_steps=50,
    report_to="none",
)

trainer = DPOTrainer(
    model=model,
    ref_model=None,
    args=args,
    train_dataset=prefs["train"],
    eval_dataset=prefs["test"],
    processing_class=tokenizer,
)
trainer.train()
trainer.save_model("adapters/sav-dpo")
# Indicateur clé dans les logs : rewards/accuracies (part des paires où chosen > rejected), doit monter vers 0,7-0,9.
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `AutoPeftModelForCausalLM.from_pretrained(SFT_ADAPTER, is_trainable=True)` recharge le modèle de base et l'adaptateur SFT en le laissant entraînable. `train_test_split(test_size=0.1, seed=42)` met 10 % des paires de côté pour l'évaluation. `ref_model=None` : avec un modèle PEFT, TRL obtient la référence $\pi_{\text{ref}}$ en désactivant temporairement l'adaptateur (pas de second modèle en mémoire). Le lot effectif est $1 \times 8 = 8$ paires ; le taux $5 \times 10^{-6}$ est 40 fois plus petit que celui du SFT ($2 \times 10^{-4}$). Dans les journaux, `rewards/accuracies` = part des paires où le modèle préfère désormais `chosen` à `rejected` (0,5 = hasard).

**Où trouver les paires ?** Les meilleures viennent de vos réponses réelles : la réponse validée par le responsable SAV (`chosen`) contre le premier jet ou la réponse générée par le modèle SFT (`rejected`). Un juge LLM peut aussi départager deux générations, à condition de relire un échantillon.

> 🔗 **Documentation officielle** — [TRL — PEFT integration](https://huggingface.co/docs/trl/main/en/peft_integration) · [a smol course — unités 1, 3 et 6](https://huggingface.co/learn/smol-course) · [CNIL — recommandations pour le développement des systèmes d'IA](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd)

```mission
{
  "title": "Où pratiquer DPO et données synthétiques",
  "url": "https://huggingface.co/learn/smol-course",
  "steps": [
    "Ouvrez « a smol course » sur Hugging Face Learn",
    "Parcourez la liste des unités",
    "Repérez l'unité sur l'alignement par préférences et celle sur les données synthétiques"
  ],
  "question": "Quelles unités du smol course traitent de l'alignement par préférences (DPO) et des données synthétiques ?",
  "hint": "Le cours compte sept unités, de l'instruction tuning à la cérémonie de remise des prix.",
  "answer": "Unité 3 « Preference Alignment » (DPO) et unité 6 « Synthetic Data » ; l'unité 1 couvre l'instruction tuning (SFT, chat templates). Plan relevé en nov. 2026 : le cours est publié par vagues et peut évoluer (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 🧪 Exercice pratique

**Consigne.** À partir de 40 questions-réponses que vous rédigez pour un domaine de votre choix (SAV, RH, comptabilité) :
1. Passez-les dans `prepare_data.py` (ajoutez volontairement 3 doublons reformulés et 2 adresses e-mail pour vérifier le nettoyage).
2. Générez 100 questions synthétiques avec `synth.py`, faites produire les réponses par le professeur, filtrez, relisez-en 20.
3. Construisez 30 paires de préférence (`chosen` = votre réponse, `rejected` = une réponse volontairement sèche ou fausse).
4. Rédigez une note de provenance : sources, modèle professeur, licence, version des CGU consultées.

**Critères de réussite.** Les doublons et données personnelles sont éliminés ; aucun exemple d'évaluation ne figure dans l'entraînement ; chaque exemple porte son origine ; la licence du professeur autorise l'usage prévu.

<details><summary>Pistes de corrigé</summary>

Le filtre par empreinte normalisée attrape les doublons qui ne diffèrent que par la ponctuation, pas ceux qui sont reformulés : ajoutez une déduplication par similarité d'embeddings (seuil cosinus ~0,92) pour ces derniers. Professeur recommandé : un modèle Apache 2.0 servi localement (Qwen3.8-27B, Mistral Small 4) ; noter « licence Apache 2.0, fiche Hugging Face consultée le … ».
</details>

## ✅ Auto-évaluation express
1. Quel format de données permet de ne calculer la perte que sur la réponse ?
2. Pourquoi faut-il séparer train et eval avant la génération synthétique ?
3. Quelle différence fondamentale entre RLHF et DPO ?

*Réponses : 1. Le format prompt-completion. 2. Pour éviter que des variantes d'exemples d'évaluation se retrouvent dans l'entraînement (fuite). 3. DPO optimise directement sur les paires de préférence, sans modèle de récompense ni boucle PPO.*

## 📚 Pour aller plus loin
- [a smol course](https://huggingface.co/learn/smol-course) 🇬🇧 — unités Instruction Tuning, Preference Alignment (DPO) et Synthetic Data.
- [Hugging Face LLM Course](https://huggingface.co/learn/llm-course) 🇬🇧 — chapitre 10 « Curate high-quality datasets ».
- [Stanford CS336](https://cs336.stanford.edu/) 🇬🇧 — séances sur les données (filtrage, déduplication, données synthétiques) et devoir A5 (SFT, RL, DPO optionnel).
- [CNIL — les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) — base légale, minimisation, information des personnes.
- [DeepSeek-R1 — fiche modèle](https://huggingface.co/deepseek-ai/DeepSeek-R1) 🇬🇧 — distillats et conditions de licence.

> ✅ **Si vous ne retenez que 3 choses** — 1. Quelques centaines à quelques milliers d'exemples **relus** valent mieux qu'un gros volume brut ; utilisez le format prompt-completion (perte sur la réponse) ou les paires chosen/rejected pour DPO, sans écrire les balises du chat template. 2. Nettoyez (signatures, doublons, données personnelles), puis séparez train/eval **avant** toute augmentation ou génération synthétique, et tracez l'origine de chaque exemple. 3. Données synthétiques et distillation exigent un professeur dont la licence ou les CGU autorisent l'usage ; DPO s'entraîne comme un SFT, avec un taux bien plus bas.

> 🗺️ **Et maintenant ?** — Vous avez des données propres et un modèle entraîné : la leçon L138 vous apprend à prouver qu'il est réellement meilleur, sans vous laisser piéger par les classements.
