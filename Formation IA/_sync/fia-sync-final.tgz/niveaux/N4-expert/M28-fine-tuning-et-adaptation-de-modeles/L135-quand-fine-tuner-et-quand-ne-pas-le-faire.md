---
id: L135
module: M28
level: N4
title: "Quand fine-tuner (et quand ne pas le faire)"
minutes: 55
objectives:
  - "Distinguer ce que changent le prompt, le RAG et le fine-tuning dans un système à base de LLM"
  - "Appliquer un arbre de décision prompt / RAG / fine-tuning à un cas d'entreprise et justifier le choix"
  - "Estimer l'ordre de grandeur du coût (données, GPU, maintenance) d'un projet de fine-tuning"
  - "Identifier les signaux qui rendent un fine-tuning rentable et ceux qui le condamnent"
skills: ["C4.4"]
sources:
  - { title: "Hugging Face LLM Course — chapitre 11 « Fine-tune Large Language Models »", url: "https://huggingface.co/learn/llm-course", lang: "en" }
  - { title: "OpenAI — Model optimization (guide)", url: "https://developers.openai.com/api/docs/guides/model-optimization", lang: "en" }
  - { title: "Anthropic — Prompt engineering overview", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview", lang: "en" }
  - { title: "Hu et al. (2021) — LoRA: Low-Rank Adaptation of Large Language Models", url: "https://arxiv.org/abs/2106.09685v1", lang: "en" }
  - { title: "Lewis et al. (2020) — Retrieval-Augmented Generation", url: "https://arxiv.org/pdf/2005.11401", lang: "en" }
---

# Quand fine-tuner (et quand ne pas le faire)

> ⏱ 55 min · 🎯 Niveau 4 · 📚 Module 28

## 🎯 Ce que vous saurez faire
- Expliquer en une phrase ce que chacun des trois leviers modifie : le **prompt** change la consigne, le **RAG** change l'information disponible, le **fine-tuning** change le comportement du modèle lui-même.
- Dérouler un arbre de décision sur un cas réel (SAV, cabinet comptable, service RH) et défendre votre choix devant un client.
- Chiffrer grossièrement un projet de fine-tuning : nombre d'exemples, heures de GPU, temps humain, coût de maintenance.
- Reconnaître les quatre situations où le fine-tuning est le bon outil et les trois où il ne fera que coûter de l'argent.

> 🧭 **En clair** — Avant de « rééduquer » un modèle, demandez-vous ce qui lui manque vraiment. S'il manque une consigne claire, réécrivez sa fiche de poste (le prompt). S'il manque des informations à jour, donnez-lui accès au classeur (le RAG). S'il manque un réflexe, une façon de faire répétée mille fois par jour (un format, un ton maison), alors seulement formez-le en profondeur (le fine-tuning). C'est comme chez le garagiste : on vérifie la pression des pneus avant de changer le moteur. Et quand on change le moteur, c'est surtout le temps humain qui coûte (préparer des exemples, évaluer, entretenir), bien plus que la puissance de calcul.

## 1. Trois leviers, trois natures de changement

Dans la leçon L133 (module 27) vous avez vu comment un modèle de base devient un assistant : pré-entraînement sur des milliers de milliards de tokens, puis **post-entraînement** (SFT, RLHF, DPO). Le fine-tuning que vous allez pratiquer dans ce module est exactement la même mécanique, en miniature : vous prenez un modèle déjà post-entraîné et vous lui ajoutez une couche d'habitudes propres à votre domaine.

Une analogie aide à ne jamais se tromper de levier. Imaginez que vous embauchiez un excellent comptable débutant dans votre cabinet :

| Levier | Analogie « nouveau collaborateur » | Ce qui change techniquement | Délai de mise en place |
|---|---|---|---|
| **Prompt** (consigne, exemples *few-shot*) | Vous lui donnez une fiche de consignes le matin | Le texte d'entrée ; les poids sont intacts | Minutes |
| **RAG** (*Retrieval-Augmented Generation*) | Vous lui donnez accès au classeur des dossiers clients | Les documents injectés dans le contexte à chaque requête | Jours |
| **Fine-tuning** | Vous le formez six mois jusqu'à ce que les réflexes du cabinet deviennent les siens | Les **poids** du modèle (ou un adaptateur LoRA greffé dessus) | Semaines |

Conséquence capitale : **le fine-tuning apprend une façon de faire, pas des faits fiables**. Entraîné sur 2 000 réponses SAV, un modèle apprend le ton, la structure et les réflexes du service client, mais ne devient pas une base fiable de vos 4 000 références : il les mélange et en invente. Pour les faits changeants (tarifs, stocks, conventions collectives), le RAG s'impose ; Lewis et al. l'ont formalisé en 2020 pour séparer mémoire paramétrique (les poids) et non paramétrique (un index de documents).

> 💡 **À retenir** — Prompt = *quoi faire maintenant*. RAG = *avec quelles informations*. Fine-tuning = *comment se comporter par défaut*. Le fine-tuning est la seule des trois options qui modifie le modèle, donc la seule qui exige un protocole d'évaluation et une maintenance.

```quiz
{
  "q": "Un assistant doit connaître des tarifs qui changent chaque mois. Quel levier choisir ?",
  "options": [
    "Un fine-tuning refait tous les mois",
    "Un RAG branché sur la grille tarifaire à jour",
    "Une température plus basse",
    "Un modèle plus grand, sans autre changement"
  ],
  "answer": 1,
  "explanation": "Les faits changeants doivent rester hors des poids : le RAG injecte l'information à jour à chaque requête, avec la possibilité de citer la source."
}
```

## 2. L'arbre de décision

Voici l'arbre que nous utiliserons dans tout le module. Il se lit de haut en bas et chaque question coûte moins cher que la suivante.

```mermaid
flowchart TD
    A[Besoin métier formulé + 30 cas de test écrits] --> B{Un bon prompt sur un modèle de pointe<br/>atteint-il le seuil de qualité ?}
    B -- Oui --> C[STOP : prompt + éventuellement cache de prompt]
    B -- Non --> D{L'échec vient-il d'informations<br/>manquantes ou changeantes ?}
    D -- Oui --> E[RAG : index documentaire + citations]
    D -- Non --> F{L'échec vient-il du format, du ton,<br/>d'une tâche étroite et répétitive ?}
    F -- Non --> G[Revoir le besoin : découper la tâche,<br/>agent, outils, humain dans la boucle]
    F -- Oui --> H{Disposez-vous de 300 à 5 000 exemples<br/>de qualité et d'une évaluation ?}
    H -- Non --> I[Constituer les données d'abord<br/>L137 : synthétiques, distillation]
    H -- Oui --> J{Contrainte de coût, latence,<br/>confidentialité ou hors-ligne ?}
    J -- Oui --> K[Fine-tuning LoRA/QLoRA d'un petit modèle ouvert<br/>L136, L140]
    J -- Non --> L[Fine-tuning via API si disponible<br/>L139 — ou rester sur prompt + RAG]
```

Trois remarques. **La première case est obligatoire** : sans 30 cas de test écrits d'avance, vous ne saurez jamais si le fine-tuning a apporté quelque chose (L138). **Le prompt passe toujours en premier** : les guides d'Anthropic et d'OpenAI recommandent d'optimiser la consigne, de mesurer, puis seulement d'entraîner ; un prompt soigné sur Claude Sonnet 5.5 (2 $/10 $ par million de tokens, nov. 2026) ou Qwen3.8-27B règle la grande majorité des besoins de rédaction, classification et extraction. **RAG et fine-tuning se combinent** : petit modèle fine-tuné pour le ton et le format, alimenté par un RAG pour les faits (on parle parfois de *RAFT*).

> 💡 **Autrement dit** — On essaie toujours la solution la moins chère d'abord, et l'on ne descend d'une case que si l'on peut **prouver**, avec les 30 cas de test, que la case précédente ne suffit pas.

> ⚠️ **Piège fréquent** — « Notre modèle ne connaît pas nos produits, fine-tunons-le sur le catalogue. » C'est le contresens le plus coûteux du métier. Le fine-tuning injecte mal les connaissances factuelles nouvelles et augmente souvent les hallucinations sur ces faits. Pour un catalogue, une FAQ, un règlement intérieur : RAG.

## 3. Les quatre bonnes raisons de fine-tuner

1. **Un format strict et répétitif** : extraire des champs de 50 000 bons de livraison vers un JSON précis, classer des tickets dans 40 catégories internes, produire des comptes rendus au gabarit maison. Un petit modèle spécialisé y devient plus régulier qu'un grand modèle généraliste guidé par prompt.
2. **Un ton ou un style de marque** : la voix d'une maison de champagne, les formules d'une mutuelle, le registre d'un cabinet d'avocats. Décrire un style dans un prompt est difficile ; le montrer 1 000 fois est efficace.
3. **Le coût et la latence à grande échelle** : remplacer un grand modèle API par un modèle ouvert de 4 à 8 milliards de paramètres fine-tuné, servi en local. C'est la logique de la **distillation** (L137) : le grand modèle sert de professeur, le petit fait le travail quotidien.
4. **La confidentialité et le hors-ligne** : données de santé, dossiers RH, poste sans connexion, usine. Un modèle ouvert sous licence Apache 2.0 (Gemma 4, Qwen3.8-27B, Mistral Small 4, gpt-oss) fine-tuné et servi par Ollama ne fait sortir aucune donnée.

## 4. Les trois mauvaises raisons

| Mauvaise raison | Pourquoi ça échoue | Alternative |
|---|---|---|
| « Lui apprendre nos documents » | Les faits nouveaux sont mal mémorisés, les mises à jour imposent un ré-entraînement | RAG avec citations |
| « Le prompt est trop long » | Le cache de prompt réduit fortement le coût des préfixes répétés (lecture du cache facturée 0,1× le prix d'entrée chez Anthropic, et 0,05× sur Sonnet 5.5 depuis le 7 octobre 2026) | Cache de prompt, compression du contexte |
| « C'est plus professionnel » | Un fine-tuning sans évaluation dégrade souvent les capacités générales (*oubli catastrophique*) | Prompt + évaluation |

> 🎮 **Défi (2 min)** — Classez ces cinq demandes dans « Prompt », « RAG » ou « Fine-tuning » : (a) répondre aux questions sur la convention collective Syntec ; (b) rédiger les relances clients avec le ton de la maison ; (c) traduire des fiches produit ; (d) extraire 15 champs de 80 000 factures fournisseurs chaque mois avec un modèle local ; (e) résumer une réunion. *Réponses : (a) RAG, (b) fine-tuning si le prompt échoue, (c) prompt, (d) fine-tuning, (e) prompt.*

```quiz
{
  "type": "vrai_faux",
  "q": "Fine-tuner un modèle sur votre catalogue produits est la méthode la plus fiable pour qu'il cite des prix exacts.",
  "options": [
    "Vrai",
    "Faux"
  ],
  "answer": 1,
  "explanation": "Faux : le fine-tuning apprend une façon de faire, il mémorise mal les faits précis et impose un ré-entraînement à chaque mise à jour. Les prix relèvent du RAG."
}
```

## 5. Chiffrer un projet de fine-tuning

Le calcul du GPU est la partie la plus facile ; ce qui coûte, ce sont les humains. Voici une estimation réaliste pour une PME qui spécialise un modèle de 4 à 8 milliards de paramètres en QLoRA.

| Poste | Ordre de grandeur | Base de calcul |
|---|---|---|
| Rédaction / validation des exemples | 1 000 exemples × 2 min = ~33 h | Un expert métier relit chaque exemple |
| Données synthétiques (option) | Quelques dollars à quelques dizaines de dollars d'API | Génération par un grand modèle (L137) |
| Entraînement QLoRA d'un 8B | 1 à 2 h de GPU 24 Go | RTX 4090 louée 0,34 $/h (RunPod Community, août 2026) ; L4 24 Go à 0,75 €/h ou L40S à 1,40 €/h chez Scaleway |
| Évaluation | 4 à 8 h humaines + quelques dollars de juge LLM | L138 |
| Maintenance | Ré-entraînement à chaque évolution de la base ou du modèle | Prévoir un cycle trimestriel |

> 🔢 **Exemple à la main** — Chiffrage d'un premier cycle, avec une **hypothèse** de coût chargé de 50 € par heure d'expert (à remplacer par le vôtre) :
> 1. Exemples : $1\,000 \times 2$ min $= 2\,000$ min $\approx 33{,}3$ h, soit $\approx 1\,667$ €.
> 2. Entraînement : 2 h de L4 à 0,75 €/h $= 1{,}50$ €.
> 3. Évaluation : 8 h humaines $= 400$ €, plus une trentaine d'euros de juge LLM et de données synthétiques.
>
> Total $\approx 2\,100$ € : le GPU en représente moins de **0,1 %**, bien sous la barre des 5 % annoncée ci-dessous ; et chaque ré-entraînement trimestriel relance surtout les postes humains. (Calcul vérifié en Python.)

Le GPU pèse donc souvent **moins de 5 % du coût total** ; la vraie question est le coût de maintien d'un modèle maison face à des modèles API qui progressent tous les trimestres. L'écart fermé/ouvert reste d'environ 26 points sur l'Artificial Analysis Intelligence Index v5 (27 oct. 2026) : un petit modèle fine-tuné ne rattrapera pas Claude Opus 5.5 sur les tâches ouvertes, mais peut l'égaler sur une tâche étroite, pour bien moins cher.

> 💡 **À retenir** — Règle des trois « oui » : fine-tunez si (1) la tâche est étroite et répétitive, (2) vous avez au moins quelques centaines d'exemples relus, (3) vous savez mesurer le gain. Un seul « non » : restez sur prompt + RAG.

```quiz
{
  "q": "Dans un projet QLoRA typique pour une PME, quel poste pèse le plus lourd dans le coût total ?",
  "options": [
    "La location du GPU",
    "L'électricité",
    "Le temps des experts métier",
    "La licence du modèle Apache 2.0"
  ],
  "answer": 2,
  "explanation": "Le GPU pèse souvent moins de 5 % du total ; les heures d'experts métier et la maintenance dominent. Une licence Apache 2.0 est gratuite."
}
```

## 6. Un mot d'histoire : pourquoi le fine-tuning est devenu accessible

En juin 2021, Edward Hu et ses collègues de Microsoft publient **LoRA** : on gèle le modèle et on n'entraîne que de petites matrices de rang faible (sur GPT-3, 10 000 fois moins de paramètres entraînables). En mai 2023, **QLoRA** ajoute un modèle de base quantifié en 4 bits : un 65B se fine-tune sur un seul GPU de 48 Go. Unsloth, Axolotl et PEFT ont ensuite rendu l'opération accessible à un notebook Colab (L136). Paradoxe de 2026 : le fine-tuning via API se raréfie, OpenAI arrêtant progressivement sa plateforme, fermée aux nouveaux comptes (nov. 2026, voir L139).

> 🔗 **Documentation officielle** — [OpenAI — Model optimization](https://developers.openai.com/api/docs/guides/model-optimization) · [Anthropic — Prompt engineering overview](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview) · [Hugging Face LLM Course](https://huggingface.co/learn/llm-course)

```mission
{
  "title": "La mémoire « non paramétrique » du RAG original",
  "url": "https://arxiv.org/pdf/2005.11401",
  "steps": [
    "Ouvrez l'article de Lewis et al. (2020) sur le RAG",
    "Lisez l'abstract",
    "Repérez ce qui joue le rôle de « mémoire paramétrique » et de « mémoire non paramétrique »"
  ],
  "question": "Dans le RAG original, quelle source de connaissances sert de mémoire non paramétrique, et comment est-elle interrogée ?",
  "hint": "La source est une encyclopédie très connue, transformée en vecteurs.",
  "answer": "Un index vectoriel dense de Wikipédia, interrogé par un retriever neuronal pré-entraîné ; la mémoire paramétrique est un modèle seq2seq pré-entraîné. C'est exactement la séparation de la leçon : les faits dans l'index, le comportement dans les poids. Article de 2020, réponse stable.",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Contexte.** La société *Ateliers Morvan* (menuiserie, 45 salariés, Dijon) reçoit 300 courriels clients par semaine : demandes de devis, suivi de chantier, réclamations. Elle dispose de 3 ans d'archives de réponses rédigées par sa chargée de clientèle, d'un catalogue de 600 références dont les prix changent chaque trimestre, et ne veut pas envoyer ses données clients hors de l'UE.

**Consigne.** En une page maximum :
1. Appliquez l'arbre de décision de la section 2 question par question.
2. Proposez une architecture (quels leviers, quel modèle, où il tourne).
3. Chiffrez le projet avec le tableau de la section 5.
4. Écrivez 5 des 30 cas de test (entrée + réponse attendue ou critère).

**Critères de réussite.** Les prix sont traités par RAG et non par fine-tuning ; la contrainte de localisation conduit à un modèle ouvert sous licence permissive servi en local ou chez un hébergeur européen ; le budget humain est explicitement supérieur au budget GPU ; les cas de test sont vérifiables.

<details><summary>Pistes de corrigé</summary>

Prompt seul : insuffisant pour le ton maison et pour les prix. Informations changeantes : oui (prix) → RAG sur le catalogue. Ton et structure : oui → fine-tuning envisageable, les 3 ans d'archives fournissent des milliers d'exemples à nettoyer et à pseudonymiser (RGPD). Contrainte de confidentialité → modèle ouvert Apache 2.0 de 4 à 8B (Gemma 4 E4B, Qwen3-8B, Ministral 3 8B) fine-tuné en QLoRA, servi par Ollama sur un serveur interne ou un GPU Scaleway. Budget : ~40 h humaines pour les données et l'évaluation, ~2 h de GPU. Cas de test : « Demande de devis pour un escalier quart tournant en chêne » → la réponse demande les dimensions, cite le délai standard issu du RAG, ne donne pas de prix inventé.
</details>

## ✅ Auto-évaluation express
1. Quel levier choisir pour qu'un assistant connaisse les tarifs mis à jour chaque mois ?
2. Pourquoi faut-il écrire des cas de test avant de fine-tuner ?
3. Citez deux contraintes qui orientent vers un petit modèle ouvert fine-tuné plutôt qu'une API.

*Réponses : 1. Le RAG, car les faits changeants doivent rester hors des poids. 2. Pour mesurer objectivement le gain par rapport au prompt et au modèle de base. 3. Confidentialité / hors-ligne, coût ou latence à grande échelle.*

## 📚 Pour aller plus loin
- [Hugging Face LLM Course](https://huggingface.co/learn/llm-course) 🇬🇧 — chapitres 3 et 11 sur le fine-tuning, licence Apache 2.0.
- [a smol course (Hugging Face)](https://huggingface.co/learn/smol-course) 🇬🇧 — cours de post-entraînement (SFT, évaluation, DPO) avec TRL et PEFT ; certificats gratuits à passer.
- [OpenAI — Model optimization](https://developers.openai.com/api/docs/guides/model-optimization) 🇬🇧 — la démarche « évaluer, optimiser le prompt, puis entraîner ».
- [Lewis et al. — Retrieval-Augmented Generation (2020)](https://arxiv.org/pdf/2005.11401) 🇬🇧 — l'article fondateur du RAG.

> ✅ **Si vous ne retenez que 3 choses** — 1. Prompt = la consigne du moment, RAG = les informations à jour, fine-tuning = le comportement par défaut ; le fine-tuning apprend une façon de faire, pas des faits fiables. 2. Descendez l'arbre de décision dans l'ordre (prompt → RAG → fine-tuning) et seulement avec 30 cas de test écrits d'avance qui prouvent que l'étape précédente ne suffit pas. 3. Fine-tunez pour un format strict, un style, le coût/la latence ou la confidentialité ; dans le budget, l'humain (données, évaluation, maintenance) pèse bien plus que le GPU.

> 🗺️ **Et maintenant ?** — Vous savez quand fine-tuner ; la leçon L136 vous montre comment le faire à petit prix, avec LoRA et QLoRA.
