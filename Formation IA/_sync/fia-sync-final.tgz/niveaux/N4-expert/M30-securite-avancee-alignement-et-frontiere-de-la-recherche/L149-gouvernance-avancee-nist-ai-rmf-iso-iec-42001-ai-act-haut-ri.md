---
id: L149
module: M30
level: N4
title: "Gouvernance avancée : NIST AI RMF, ISO/IEC 42001, AI Act haut risque"
minutes: 60
objectives:
  - "Expliquer les quatre fonctions du NIST AI RMF (Govern, Map, Measure, Manage) et le profil IA générative NIST AI 600-1"
  - "Identifier la structure d'un système de management de l'IA selon ISO/IEC 42001 et ce qu'implique une certification"
  - "Appliquer les obligations de l'AI Act aux systèmes à haut risque, aux déployeurs et aux modèles GPAI, avec le calendrier révisé"
  - "Construire un tableau de correspondance entre les trois cadres et un plan de gouvernance proportionné"
skills: ["C4.6"]
sources:
  - { title: "NIST — AI Risk Management Framework", url: "https://www.nist.gov/itl/ai-risk-management-framework", lang: "en" }
  - { title: "ISO/IEC 42001:2023 — Systèmes de management de l'IA", url: "https://www.iso.org/standard/81230.html", lang: "en" }
  - { title: "EUR-Lex — Règlement (UE) 2024/1689 (AI Act)", url: "https://eur-lex.europa.eu/eli/reg/2024/1689/oj", lang: "fr" }
  - { title: "donneespersonnelles.fr — Omnibus numérique IA (calendrier, màj 12/09/2026)", url: "https://donneespersonnelles.fr/omnibus-numerique-ia", lang: "fr" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "CNIL — Recommandations pour le développement des systèmes d'IA", url: "https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd", lang: "fr" }
  - { title: "Sénat — Réponse ministérielle du 05/02/2026 (sanctions AI Act)", url: "https://www.senat.fr/questions/base/2025/qSEQ251006478.html", lang: "fr" }
  - { title: "Stanford HAI — AI Index Report 2026 (chapitre Responsible AI)", url: "https://hai.stanford.edu/ai-index/2026-ai-index-report", lang: "en" }
---

# Gouvernance avancée : NIST AI RMF, ISO/IEC 42001, AI Act haut risque

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 30

Le rapport *AI Index 2026* de Stanford HAI recense **362 incidents IA signalés en 2025**, un record. Chaque incident pose la même question au lendemain : « qui était responsable, qu'avait-on mesuré, qu'avait-on décidé ? ». La gouvernance de l'IA, c'est la capacité à répondre **avant** l'incident. Au niveau 1 (M07, L028-L029) et au niveau 2 (politique IA interne, L063), vous avez vu les bases de l'AI Act et du RGPD. Ce niveau expert vous apprend à manier **trois cadres complémentaires** — un cadre de gestion des risques américain, une norme internationale certifiable et un règlement européen contraignant — et à les assembler en un seul dispositif.

## 🎯 Ce que vous saurez faire
- Structurer une démarche de risque IA selon les quatre fonctions du NIST AI RMF.
- Expliquer à une direction ce qu'exige une certification ISO/IEC 42001 et ce qu'elle n'apporte pas.
- Qualifier un système au regard de l'AI Act (haut risque, GPAI, transparence) et dérouler les obligations correspondantes avec le **calendrier révisé** de 2026.
- Produire un **tableau de correspondance** qui évite de faire trois fois le même travail.

> 🧭 **En clair** — Gouverner l'IA, c'est tenir la **maison en ordre avant l'inspection**. Trois référentiels s'y croisent, comme dans une cuisine de restaurant : le **NIST AI RMF** est la *méthode* (repérer les points dangereux, mesurer, corriger), l'**ISO/IEC 42001** est le *label* qu'un auditeur vient vérifier sur l'organisation, et l'**AI Act** est la *loi* européenne, avec ses dates et ses amendes. Bonne nouvelle : la plupart des documents servent aux trois à la fois. Le travail d'un expert consiste à produire chaque preuve une seule fois et à savoir montrer à quel article, à quelle clause et à quelle fonction elle répond.

## 1. NIST AI RMF : penser le risque en quatre fonctions

Le **NIST AI Risk Management Framework 1.0** (publication NIST AI 100-1, janvier 2023) est un cadre **volontaire**, non certifiable, conçu pour toute organisation. Il définit d'abord ce qu'est une IA **digne de confiance** à travers sept caractéristiques : valide et fiable ; sûre ; sécurisée et résiliente ; responsable et transparente ; explicable et interprétable ; respectueuse de la vie privée ; équitable, avec gestion des biais préjudiciables.

Il organise ensuite l'action en quatre **fonctions**, découpées en catégories et sous-catégories :

| Fonction | Question | Exemples d'activités |
|---|---|---|
| **GOVERN** (transversale) | Qui décide, selon quelles règles ? | Politique IA, rôles et responsabilités, culture du risque, gestion des tiers fournisseurs, formation |
| **MAP** | Dans quel contexte ce système opère-t-il ? | Finalité, parties prenantes, catégorisation, impacts possibles, limites connues |
| **MEASURE** | Comment évaluer les risques identifiés ? | Métriques, évaluations, red teaming (L147), tests de biais, suivi en production |
| **MANAGE** | Que fait-on des risques mesurés ? | Priorisation, traitement (éviter, réduire, transférer, accepter), plan de réponse aux incidents, mise hors service |

GOVERN irrigue les trois autres : sans gouvernance, MAP, MEASURE et MANAGE restent des exercices techniques sans décision. Le NIST publie un **Playbook** de suggestions d'actions par sous-catégorie.

En juillet 2024, le NIST a ajouté le **Generative AI Profile** (NIST AI 600-1), qui liste douze risques propres ou amplifiés par l'IA générative, parmi lesquels : la **confabulation** (hallucination), l'accès facilité à des informations CBRN, les contenus violents ou dégradants, la confidentialité des données, la sécurité de l'information, la propriété intellectuelle, l'intégrité de l'information, les biais et l'homogénéisation, la configuration humain-IA (sur-confiance), l'intégrité de la chaîne de valeur et l'impact environnemental.

**Analogie** : le NIST AI RMF est la **méthode HACCP** de l'IA. Comme en restauration, on n'invente pas un règlement : on identifie les points critiques, on mesure, on corrige, on documente.

> 💡 **À retenir** — NIST AI RMF = **méthode** (comment réfléchir au risque). Il ne dit pas *quel* niveau de risque est acceptable : c'est à l'organisation de le décider dans GOVERN.

```
              ┌───────────── GOVERN (règles, rôles, culture) ─────────────┐
              │                                                           │
              ▼                                                           │
   MAP (contexte, impacts) ──► MEASURE (tests, métriques) ──► MANAGE (traiter, réagir)
              ▲                                                           │
              └──────────────────── retour d'expérience ──────────────────┘
```

```quiz
{
  "q": "Mise en situation : votre équipe a mesuré un taux de biais de 4 % sur l'outil de tri de CV, mais personne ne sait qui doit décider si ce taux est acceptable. Quelle fonction du NIST AI RMF fait défaut ?",
  "options": ["MAP", "MEASURE", "MANAGE", "GOVERN"],
  "answer": 3,
  "explanation": "La mesure existe (MEASURE). Ce qui manque, c'est la définition des rôles et du seuil de risque acceptable : c'est GOVERN, la fonction transversale sans laquelle les trois autres restent des exercices techniques."
}
```

```mission
{
  "title": "Le profil IA générative du NIST",
  "url": "https://www.nist.gov/itl/ai-risk-management-framework",
  "steps": ["Ouvrez la page AI Risk Management Framework du NIST", "Repérez la publication consacrée à l'IA générative (Generative AI Profile)", "Notez son numéro de publication, sa date et le nombre de risques qu'elle liste"],
  "question": "Quel est le numéro de publication du Generative AI Profile, quand est-il paru et combien de risques recense-t-il ?",
  "hint": "Même série que le cadre lui-même (NIST AI 100-1), mais avec un numéro en 600.",
  "answer": "NIST AI 600-1, publié en juillet 2024, qui recense 12 risques (dont la confabulation) — document figé, mais vérifiez qu'aucune révision n'a été publiée depuis.",
  "xp": 10
}
```

## 2. ISO/IEC 42001 : un système de management certifiable

**ISO/IEC 42001:2023** (publiée en décembre 2023) est la première norme internationale de **système de management de l'IA** (SMIA, en anglais AIMS). Elle suit la **structure harmonisée** des normes de management ISO : si votre entreprise est certifiée ISO 9001 (qualité) ou ISO/IEC 27001 (sécurité de l'information), vous en connaissez déjà l'ossature.

| Chapitre | Contenu | Livrable typique |
|---|---|---|
| 4 Contexte | Enjeux internes/externes, parties intéressées, périmètre du SMIA, rôle de l'organisation (fournisseur, utilisateur…) | Note de périmètre |
| 5 Leadership | Engagement de la direction, **politique IA**, rôles | Politique signée |
| 6 Planification | Appréciation et traitement des risques IA, **évaluation d'impact** des systèmes, objectifs | Registre des risques, déclaration d'applicabilité |
| 7 Support | Ressources, compétences, sensibilisation, communication, documentation | Plan de formation (lien avec l'art. 4 AI Act) |
| 8 Fonctionnement | Maîtrise opérationnelle du cycle de vie des systèmes | Procédures, dossiers de conception |
| 9 Évaluation des performances | Surveillance, **audit interne**, revue de direction | Rapports d'audit |
| 10 Amélioration | Non-conformités, actions correctives, amélioration continue | Plan d'actions |

L'**annexe A** fournit une liste de mesures de référence (politiques, organisation interne, ressources, évaluation des impacts, cycle de vie, données, information des parties intéressées, usage responsable, relations avec les tiers) ; l'organisation justifie dans une **déclaration d'applicabilité** celles qu'elle retient ou exclut. L'annexe B guide leur mise en œuvre. La norme s'articule avec ISO/IEC 23894 (lignes directrices de gestion des risques IA) et, depuis 2025, avec des normes complémentaires sur l'évaluation d'impact et sur les organismes certificateurs (références exactes à vérifier sur iso.org).

**Ce que la certification apporte** : une preuve, auditée par un tiers accrédité, que l'organisation **pilote** ses systèmes d'IA de manière structurée — argument fort en appel d'offres. **Ce qu'elle n'apporte pas** : la conformité automatique à l'AI Act, ni la garantie qu'un modèle donné est sûr.

> ⚠️ **Piège fréquent** — Confondre certification du **système de management** (ISO/IEC 42001, l'organisation) et évaluation de **conformité d'un produit** (marquage CE d'un système à haut risque sous l'AI Act). Les deux se complètent mais ne se remplacent pas.

> 💡 **Autrement dit** — L'ISO/IEC 42001, c'est le **contrôle d'hygiène de la cuisine** : on vérifie que le restaurant a des procédures, les applique et s'améliore. Le marquage CE de l'AI Act, c'est le **contrôle d'un plat précis** avant sa mise sur la carte. Une cuisine impeccable peut encore servir un plat raté, et inversement.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : une entreprise certifiée ISO/IEC 42001 est automatiquement conforme à l'AI Act pour ses systèmes à haut risque.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : la certification porte sur le système de management de l'organisation. Un système à haut risque exige en plus son évaluation de conformité, sa documentation technique, son marquage CE et son enregistrement (art. 43, 47-49)."
}
```

## 3. AI Act : haut risque, GPAI et calendrier révisé

### 3.1 Le calendrier au 1er novembre 2026

| Date | Ce qui s'applique |
|---|---|
| 2 février 2025 | Pratiques interdites (art. 5) ; maîtrise de l'IA (art. 4) |
| 2 août 2025 | Obligations des fournisseurs de **modèles GPAI** (art. 53 et suivants), gouvernance, autorités nationales |
| 2 août 2026 | Transparence (art. 50 ; marquage des contenus synthétiques différé au 2 déc. 2026 pour les systèmes déjà sur le marché), sanctions (chapitre XII), début du contrôle national |
| 2 décembre 2026 | Nouvelles pratiques interdites ajoutées par l'omnibus (génération d'images intimes non consenties, matériel pédopornographique) ; marquage des contenus synthétiques pour les systèmes déjà sur le marché |
| **2 décembre 2027** | Systèmes **à haut risque de l'annexe III** (emploi et RH, éducation, crédit, accès aux services essentiels, biométrie, justice…) — **reporté** du 2 août 2026 par l'omnibus numérique IA, règlement (UE) 2026/1744 (publié au JOUE le 24 juillet 2026, en vigueur depuis le 27 juillet 2026) |
| **2 août 2028** | Haut risque de l'**annexe I** (IA intégrée à des produits réglementés : machines, dispositifs médicaux…) — reporté |
| 2 août 2030 | Systèmes à haut risque utilisés par les autorités publiques (art. 111(2)) |

Sanctions maximales : **35 M€ ou 7 %** du chiffre d'affaires mondial (pratiques interdites), **15 M€ ou 3 %** (autres manquements), **7,5 M€ ou 1 %** (informations inexactes).

> 💡 **À jour (vérification du 5 nov. 2026)** — L'omnibus 2026/1744 apporte aussi : (1) au **2 décembre 2026**, de **nouvelles pratiques interdites** — les systèmes générant des images intimes non consenties (applications dites « nudifier ») et du matériel pédopornographique ; (2) un **article 4 reformulé** : fournisseurs et déployeurs prennent des mesures qui *favorisent* la maîtrise de l'IA, sans niveau individuel imposé à chaque personne — l'obligation de former demeure ; (3) des allègements étendus aux PME et aux *small mid-caps*. Vérifiez la formulation exacte sur la version consolidée d'EUR-Lex.

> 💡 **Autrement dit** — Le report n'efface pas l'obligation, il **décale la date de l'examen**. Un outil RH mis sur le marché à partir du 2 décembre 2027 devra être conforme dès son lancement, et un outil déjà en service y sera soumis s'il est modifié de façon importante (art. 111(2), à vérifier dans le texte consolidé) : c'est maintenant qu'il faut ouvrir le cahier.

```mission
{
  "title": "L'omnibus IA au Journal officiel de l'UE",
  "url": "https://eur-lex.europa.eu/eli/reg/2026/1744/oj",
  "steps": ["Ouvrez la page EUR-Lex du règlement (UE) 2026/1744", "Repérez la date de publication au Journal officiel et l'article sur l'entrée en vigueur", "Cherchez la nouvelle date d'application des obligations « haut risque » de l'annexe III du règlement 2024/1689"],
  "question": "Quand le règlement 2026/1744 a-t-il été publié et quand est-il entré en vigueur ? Quelle est la nouvelle échéance pour l'annexe III ?",
  "hint": "Publication fin juillet 2026, entrée en vigueur quelques jours plus tard ; l'échéance annexe III tombe en fin d'année 2027.",
  "answer": "JOUE du 24 juillet 2026, entrée en vigueur le 27 juillet 2026 ; annexe III reportée au 2 décembre 2027 (annexe I au 2 août 2028). Dates vérifiées le 5 nov. 2026 par recoupement de sources ; à relire sur EUR-Lex.",
  "xp": 15
}
```

### 3.2 Obligations du fournisseur d'un système à haut risque

Un report n'est pas une dispense : un système RH lancé en 2026 devra être conforme au 2 décembre 2027, et la documentation ne s'écrit pas en trois semaines.

| Article | Obligation |
|---|---|
| 9 | **Système de gestion des risques** sur tout le cycle de vie |
| 10 | Gouvernance des **données** d'entraînement, de validation et de test (pertinence, représentativité, biais) |
| 11 + annexe IV | **Documentation technique** |
| 12 | **Journalisation** automatique des événements |
| 13 | Transparence et **notice d'utilisation** pour le déployeur |
| 14 | **Contrôle humain** effectif |
| 15 | Exactitude, **robustesse** et **cybersécurité** (dont la résistance aux attaques visant les données ou le modèle) |
| 17 | **Système de gestion de la qualité** |
| 43, 47-49 | Évaluation de la conformité, déclaration UE, marquage CE, enregistrement dans la base de l'UE |
| 72-73 | **Surveillance après commercialisation** et signalement des incidents graves |

Le **déployeur** (l'entreprise qui utilise le système, art. 26) doit l'utiliser conformément à la notice, confier le contrôle humain à des personnes compétentes, surveiller le fonctionnement, conserver les journaux au moins six mois et informer les travailleurs concernés. Certains déployeurs (organismes publics, et par exemple l'évaluation de solvabilité ou la tarification d'assurance vie et santé) réalisent en outre une **analyse d'impact sur les droits fondamentaux** (art. 27).

### 3.3 Modèles GPAI et code de pratique

Tout fournisseur de modèle d'IA à usage général (art. 53) doit tenir une documentation technique, informer les fournisseurs en aval qui intègrent le modèle, mettre en place une **politique de respect du droit d'auteur** et publier un **résumé du contenu d'entraînement** selon le modèle de la Commission (24 juillet 2025). Un modèle est présumé **à risque systémique** au-delà de 10²⁵ FLOP de calcul d'entraînement (art. 51) ; il doit alors en plus (art. 55) être **évalué, y compris par des tests adversariaux**, atténuer les risques systémiques, signaler les incidents graves et assurer un niveau de cybersécurité adéquat.

Le **code de pratique GPAI** publié en juillet 2025 propose une voie de conformité volontaire en trois chapitres : transparence, droit d'auteur, sûreté et sécurité. Plusieurs grands fournisseurs l'ont signé (vérifiez la liste à jour des signataires sur le site de la Commission européenne avant de l'affirmer à un client). Faites le lien avec L146 : les politiques de type RSP ou Frontier Safety Framework des laboratoires sont la matière première du chapitre « sûreté et sécurité ».

### 3.4 Et le RGPD ?

L'AI Act ne remplace pas le RGPD. Les **15 fiches pratiques IA** (numérotées de 1 à 13) de la CNIL restent la référence française : finalité, base légale, minimisation, information, droits des personnes, et une **AIPD** (analyse d'impact relative à la protection des données) « de fait obligatoire » pour les systèmes à haut risque au sens de l'AI Act.

> 🔗 **Documentation officielle** — [EUR-Lex — Règlement (UE) 2024/1689](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) · [NIST AI RMF](https://www.nist.gov/itl/ai-risk-management-framework) 🇬🇧 · [ISO/IEC 42001:2023](https://www.iso.org/standard/81230.html) 🇬🇧 · [CNIL — fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia)

## 4. Le tableau de correspondance des trois cadres

Le principe : **une seule preuve, plusieurs usages**. Chaque livrable produit une fois sert les trois cadres.

| Thème | NIST AI RMF | ISO/IEC 42001 | AI Act (haut risque / GPAI) | Livrable unique |
|---|---|---|---|---|
| Politique et rôles | GOVERN 1-2 | Ch. 5, annexe A (politiques, organisation) | Art. 17 (SGQ), art. 26 (déployeur) | Politique IA + matrice RACI |
| Inventaire et contexte | MAP 1 | Ch. 4 | Qualification (art. 5, 6, annexe III, art. 50) | Registre des systèmes IA |
| Analyse de risques | MAP 4-5, MANAGE 1 | Ch. 6 | Art. 9 | Registre des risques |
| Impacts sur les personnes | MAP 5 | Ch. 6, annexe A (évaluation d'impact) | Art. 27 (FRIA) + AIPD RGPD | Étude d'impact combinée |
| Données | MAP 2-3, MEASURE 2 | Annexe A (données) | Art. 10 | Fiche de données (*datasheet*) |
| Documentation | GOVERN 1, MAP 2 | Ch. 7 | Art. 11, annexe IV ; art. 53 (GPAI) | Dossier technique |
| Tests et robustesse | MEASURE 1-2 | Ch. 8-9 | Art. 15 ; art. 55 (tests adversariaux GPAI) | Rapport de red teaming (L147) |
| Contrôle humain | MANAGE 2 | Annexe A (usage responsable) | Art. 14, 26 | Procédure de supervision |
| Journalisation et suivi | MEASURE 3, MANAGE 4 | Ch. 9 | Art. 12, 26, 72 | Plan de surveillance + journaux (L148) |
| Incidents | MANAGE 4 | Ch. 10 | Art. 73 ; art. 55 | Procédure de gestion des incidents |
| Fournisseurs tiers | GOVERN 6 | Annexe A (relations avec les tiers) | Art. 25 (chaîne de valeur), art. 53 | Grille d'évaluation fournisseurs |
| Compétences | GOVERN 2 | Ch. 7 | Art. 4 (maîtrise de l'IA) | Plan de formation tracé |

> 🎮 **Défi** — Un éditeur français de logiciel RH (60 salariés) intègre un modèle GPAI d'un grand fournisseur pour classer les candidatures. Est-il fournisseur ou déployeur ? Du système ou du modèle ? *Réponse : il est **fournisseur d'un système à haut risque** (annexe III, emploi) — obligations des art. 9 à 17, 43 et suivants — et **fournisseur en aval** du modèle GPAI, en droit de recevoir la documentation de l'art. 53 du fournisseur du modèle. Ses clients sont **déployeurs** (art. 26).*

## 🧪 Exercice pratique

**Consigne (35 min)** — Reprenez le cabinet RH de L148 (agent de tri de candidatures).
1. **Qualifiez** le système (catégorie AI Act, rôle de chaque acteur, échéance applicable).
2. Remplissez le **tableau de correspondance** de la section 4 pour ce cas : une ligne par thème, avec le livrable concret, son propriétaire et sa date cible.
3. Rédigez un **plan de gouvernance proportionné** sur 12 mois : quelles mesures maintenant, lesquelles avant le 2 décembre 2027, et la décision (argumentée) de viser ou non une certification ISO/IEC 42001.
4. Ajoutez la ligne RGPD : AIPD, base légale, information des candidats.

**Critères de réussite** : qualification exacte (haut risque annexe III) ; calendrier révisé correctement appliqué et présenté avec sa référence (règlement (UE) 2026/1744, en vigueur le 27 juillet 2026) ; chaque livrable sert au moins deux cadres ; le plan est réaliste pour 25 personnes (pas de « comité d'éthique de 12 membres »).

**Pistes de corrigé** : priorités immédiates — inventaire, politique IA, plan de formation art. 4 (déjà exigible), AIPD, contrôle humain sur chaque décision de rejet, journalisation. Avant fin 2027 — vérifier que le fournisseur de l'outil fournit notice et documentation (le cabinet est **déployeur** s'il achète un outil ; **fournisseur** s'il le développe lui-même). ISO/IEC 42001 : rarement justifiée pour 25 personnes, sauf exigence client ; s'en inspirer sans certification est une réponse défendable.

## ✅ Auto-évaluation express

1. Quelle fonction du NIST AI RMF est transversale aux trois autres ?
2. ISO/IEC 42001 certifie-t-elle qu'un modèle est sûr ?
3. Quelle est l'échéance d'application des obligations « haut risque » de l'annexe III après l'omnibus de 2026 ?

**Réponses** : 1) GOVERN. 2) Non : elle certifie un **système de management** de l'organisation, pas la sûreté d'un modèle ni la conformité d'un produit. 3) Le 2 décembre 2027 (règlement (UE) 2026/1744, publié au JOUE le 24 juillet 2026).

## 📚 Pour aller plus loin
- [NIST — AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework) 🇬🇧 — cadre, Playbook et profil GenAI (NIST AI 600-1).
- [ISO/IEC 42001:2023](https://www.iso.org/standard/81230.html) 🇬🇧 — fiche officielle de la norme (achat du texte intégral).
- [EUR-Lex — Règlement (UE) 2024/1689](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) — texte consolidé de l'AI Act.
- [donneespersonnelles.fr — Omnibus numérique IA](https://donneespersonnelles.fr/omnibus-numerique-ia) — calendrier révisé (màj 12/09/2026).
- [CNIL — Recommandations pour le développement des systèmes d'IA](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd) — RGPD appliqué à l'IA.
- [Stanford HAI — AI Index 2026](https://hai.stanford.edu/ai-index/2026-ai-index-report) 🇬🇧 — chapitre 3 « Responsible AI » et chapitre 8 « Policy and Governance ».
- [EUR-Lex — Règlement (UE) 2026/1744 (omnibus IA)](https://eur-lex.europa.eu/eli/reg/2026/1744/oj) — texte officiel des reports et des nouvelles interdictions.

> ✅ **Si vous ne retenez que 3 choses** — 1. NIST AI RMF = une **méthode** volontaire en quatre fonctions (GOVERN transversale, puis MAP, MEASURE, MANAGE) ; ISO/IEC 42001 = un **système de management** certifiable de l'organisation, qui ne certifie ni un modèle ni un produit. 2. AI Act : qualifiez d'abord le système (interdit, haut risque, GPAI, transparence) et votre rôle (fournisseur ou déployeur) ; après l'omnibus 2026/1744, le haut risque de l'annexe III s'applique au 2 décembre 2027, un report qui ne dispense pas de préparer la documentation dès maintenant. 3. Une seule preuve, plusieurs usages : le tableau de correspondance évite de produire trois fois le même livrable (registre, analyse de risques, red teaming, journaux, procédure d'incident).

> 🗺️ **Et maintenant ?** — Vous maîtrisez les cadres d'aujourd'hui ; la leçon L150, dernière du parcours, vous apprend à suivre la recherche de demain (articles fondateurs, veille arXiv) et vous lance dans le projet final.
