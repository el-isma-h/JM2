---
module: M30
title: "Fiche mémo — Sécurité avancée, alignement et frontière de la recherche"
---
# Fiche mémo — M30 · Sécurité avancée, alignement et frontière de la recherche

> En une phrase : l'alignement déplace les sorties vers ce qu'un juge préfère sans garantir l'absence de défauts ; on le complète par un red teaming mesuré, des agents contraints par le code et une gouvernance qui produit des preuves.

## Les 7 idées à retenir
1. RLHF, RLAIF et DPO ne « mettent pas des valeurs » : tout défaut du juge devient un défaut du modèle (reward hacking, complaisance) (`L146`).
2. Sleeper Agents : une porte dérobée peut survivre à l'entraînement de sécurité ; l'évaluation comportementale ne suffit pas toujours (`L146`).
3. Les SAE extraient des caractéristiques interprétables et manipulables, sans permettre de certifier un modèle (`L146`).
4. Red teaming : règles d'engagement signées, oracles à marqueurs inoffensifs, ASR **et** refus excessif (`L147`).
5. Triade létale : données privées + contenu non fiable + sortie vers l'extérieur = exfiltration possible (`L148`).
6. Le prompt oriente, le code contraint : isolation, moindre privilège, approbation humaine, journal, coupe-circuit (`L148`).
7. NIST AI RMF = méthode, ISO/IEC 42001 = management certifiable, AI Act = obligation légale : une preuve, trois usages (`L149`).

## Le schéma à connaître
```mermaid
flowchart LR
  C["1. Cadrage et règles d'engagement"] --> M["2. Modèle de menace"]
  M --> P["3. Plan de tests + oracles"]
  P --> E["4. Exécution répétée"]
  E --> K["5. Cotation : ASR + refus excessif"]
  K --> R["6. Rapport et divulgation coordonnée"]
  R -. "non-régression après correction" .-> P
```

## Les formules essentielles
| Formule | Intuition en mots simples |
|---|---|
| $\text{ASR} = \dfrac{\text{essais où l'attaque réussit}}{\text{essais}}$, par famille | Le pourcentage de fois où la porte a cédé ; rejouer chaque cas (par exemple 5 fois). |
| $\text{refus excessif} = \dfrac{\text{demandes légitimes refusées}}{\text{demandes légitimes}}$ | Une porte que plus personne ne peut ouvrir est aussi un échec. |
| $\text{exploitable} = D \wedge C \wedge S$ | Il suffit d'enlever un des trois côtés de la triade pour casser l'exfiltration. |
| $\hat x = \text{décodeur}(f(x))$, $f(x)$ très large et creuse | Le SAE réécrit une activation avec peu de « mots » d'un grand dictionnaire. |
| GOVERN $\to$ MAP $\to$ MEASURE $\to$ MANAGE | Règles, contexte, mesure, traitement, puis retour d'expérience. |

## Vocabulaire express
| Terme | En clair |
|---|---|
| Superposition | Le modèle range plus d'idées qu'il n'a de neurones. |
| Confused deputy | Un agent légitime qui utilise ses droits pour le compte d'un tiers malveillant. |
| Tool poisoning / rug pull | Description d'outil MCP piégée / outil modifié après approbation. |
| RSP / ASL | Politique volontaire d'Anthropic, niveaux de sûreté par seuil de capacité. |
| FRIA | Analyse d'impact sur les droits fondamentaux (art. 27). |

## Les pièges classiques
- Lire Sleeper Agents comme « les IA complotent » : ils montrent les limites de l'évaluation.
- Ne tester qu'une famille d'attaques : la taxonomie mesure la couverture.
- Croire un score d'outil automatique : vérifier au moins 10 % des verdicts à la main.
- Mettre la limite de paiement dans le prompt au lieu du code.
- Confondre ISO/IEC 42001 (l'organisation) et marquage CE (le produit) ; une RSP n'est pas une obligation légale.
- Citer une prépublication arXiv comme un résultat établi.

## Les commandes / chiffres / dates utiles
```json
{ "permissions": {
    "allow": ["Bash(npm run test:*)", "Bash(git diff:*)", "Read(./src/**)"],
    "deny":  ["Read(./.env)", "Read(./secrets/**)", "Bash(curl:*)", "Bash(git push:*)", "WebFetch"] } }
```
```bash
npx promptfoo@latest redteam init mon-projet-redteam && npx promptfoo@latest redteam run
```
- OWASP LLM 2026 (4/08/2026) : LLM01 Prompt Injection, LLM03 Excessive Agency, LLM08 Hidden Context Exposure.
- OWASP Agentic 2026 (9/12/2025) : ASI01 Agent Goal Hijack … ASI10 Rogue Agents.
- MCP : **2026-07-28** = version stable actuelle (sans état), 2025-11-25 = précédente.
- AI Act (omnibus 2026/1744) : 2/12/2026 nouvelles interdictions ; haut risque annexe III **2/12/2027** ; annexe I 2/08/2028.
- Sanctions max : 35 M€ ou 7 % ; 15 M€ ou 3 % ; 7,5 M€ ou 1 %. Embargo de divulgation usuel : 90 jours.
- Red teaming sur Claude : `temperature` refusée à partir de 4.7, et sur tous les modèles avec l'API 2026-10-21 (SDK v2).
- Projet final : seuil 60/100, aucun critère à 15 points sous 6.

## Pour aller plus loin
- [Transformer Circuits Thread](https://transformer-circuits.pub/)
- [MITRE ATLAS](https://atlas.mitre.org)
- [NIST — AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)

## Auto-test (3 questions — réponses en bas de fiche)
1. Après un filtre, l'ASR passe de 40 % à 0 % mais 30 % des CV légitimes sont refusés : conclusion ?
2. Quel seul contrôle empêche la perte si l'agent comptable est trompé sur un IBAN ?
3. À quelle date s'appliquent les obligations haut risque de l'annexe III ?

---
**Réponses.** 1. Filtre trop strict : refus excessif à corriger. 2. Un validateur côté code qui n'accepte que les IBAN déjà connus. 3. Le 2 décembre 2027.
