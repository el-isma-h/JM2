---
id: L148
module: M30
level: N4
title: "Sécurité des systèmes agentiques : OWASP Agentic, MITRE ATLAS"
minutes: 60
objectives:
  - "Identifier les menaces propres aux agents (détournement d'objectif, abus d'outils, empoisonnement de mémoire, défaillances en cascade) à l'aide de l'OWASP Agentic"
  - "Expliquer le problème du « confused deputy » et les menaces spécifiques à MCP (tool poisoning, rug pull, token passthrough)"
  - "Construire une architecture d'agent appliquant isolation, moindre privilège, approbation humaine et journalisation inviolable"
  - "Appliquer MITRE ATLAS pour modéliser un scénario d'attaque de bout en bout contre un agent"
skills: ["C4.6"]
sources:
  - { title: "OWASP GenAI Security Project", url: "https://genai.owasp.org/", lang: "en" }
  - { title: "OWASP — Agentic AI: Threats and Mitigations", url: "https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/", lang: "en" }
  - { title: "Modulos — OWASP Top 10 for Agentic Applications", url: "https://docs.modulos.ai/frameworks/owasp-top-10-agentic/", lang: "en" }
  - { title: "MITRE ATLAS", url: "https://atlas.mitre.org", lang: "en" }
  - { title: "MCP — Specification (Authorization, 2025-11-25)", url: "https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization", lang: "en" }
  - { title: "Claude Code — Permissions", url: "https://code.claude.com/docs/en/permissions.md", lang: "en" }
  - { title: "Claude Code — Sandboxing", url: "https://code.claude.com/docs/en/sandboxing.md", lang: "en" }
  - { title: "Claude Code — Security", url: "https://code.claude.com/docs/en/security.md", lang: "en" }
  - { title: "Claude Code — Hooks reference", url: "https://code.claude.com/docs/en/hooks.md", lang: "en" }
  - { title: "Claude Agent SDK — Overview", url: "https://code.claude.com/docs/en/agent-sdk/overview", lang: "en" }
  - { title: "Greshake et al. (2023) — Indirect Prompt Injection", url: "https://arxiv.org/abs/2302.12173", lang: "en" }
---

# Sécurité des systèmes agentiques : OWASP Agentic, MITRE ATLAS

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 30

Un chatbot qui se trompe écrit une bêtise. Un **agent** qui se trompe **agit** : il envoie l'e-mail, exécute la commande, paie la facture. En 2026, avec le Claude Agent SDK, les Managed Agents, l'OpenAI Agents SDK, LangGraph ou n8n, et la spécification MCP (version stable actuelle 2026-07-28, publiée le 28 juillet 2026 ; la documentation Anthropic cite encore la version stable précédente 2025-11-25), la question n'est plus « le modèle va-t-il mal répondre ? » mais « **que peut-il casser, et comment le saurai-je ?** ». En M23 (L106) vous avez rencontré l'OWASP Agentic en une section ; ici, nous en faisons une méthode d'architecture.

## 🎯 Ce que vous saurez faire
- Dérouler les dix catégories de l'OWASP Top 10 for Agentic Applications sur un agent réel.
- Repérer un **confused deputy** et les failles spécifiques à MCP dans un schéma d'architecture.
- Concevoir un agent selon cinq principes : isolation, moindre privilège, approbation humaine, journalisation, coupe-circuit.
- Écrire un scénario d'attaque structuré par les tactiques MITRE ATLAS.

> 🧭 **En clair** — Un chatbot, c'est un conseiller au téléphone : au pire, il donne un mauvais conseil. Un **agent**, c'est un employé à qui l'on a confié **les clés, la carte bancaire et le courrier** : s'il se fait berner, il agit. La sécurité des agents consiste donc à faire ce que toute entreprise fait déjà avec un nouvel employé : ne lui donner que les clés nécessaires, faire valider par un responsable les gros paiements, tout noter dans un registre, et pouvoir lui retirer son badge en un instant. L'OWASP Agentic (dix risques numérotés ASI01 à ASI10) et MITRE ATLAS (le catalogue des techniques d'attaque contre l'IA) servent de check-lists pour n'oublier aucune porte.

## 1. Pourquoi un agent change le modèle de menace

Un agent combine trois ingrédients : un **modèle** qui décide, des **outils** qui agissent, une **boucle** qui enchaîne décisions et actions, souvent avec une **mémoire** persistante. Chaque ingrédient ajoute une surface.

Le chercheur Simon Willison a popularisé en 2025 une règle mnémotechnique, la **« triade létale »** (*lethal trifecta*) : un agent devient exploitable pour l'exfiltration dès qu'il cumule (1) un accès à des **données privées**, (2) une exposition à du **contenu non fiable** (web, e-mails, documents tiers) et (3) un moyen de **communiquer vers l'extérieur** (requête HTTP, e-mail, lien cliquable). Retirer un seul des trois côtés casse la chaîne d'attaque.

```
        Données privées (CRM, paie, boîte mail)
                    ▲
                    │
   Contenu non fiable ◄──── AGENT ────► Sortie vers l'extérieur
   (PDF, web, e-mail)                  (HTTP, e-mail, image distante)

   Les trois côtés présents  ⇒  une injection indirecte peut exfiltrer
```

**Analogie** : un stagiaire qui a les clés du coffre (données), ouvre tout le courrier sans filtre (contenu non fiable) et peut poster des colis à n'importe quelle adresse (sortie). Personne n'a besoin de le corrompre : il suffit d'une lettre bien tournée.

```quiz
{
  "q": "Mise en situation : un agent lit les e-mails entrants des clients et interroge le CRM, mais il ne peut ni envoyer d'e-mail, ni ouvrir de lien, ni appeler d'API externe. La triade létale est-elle complète ?",
  "options": ["Oui, car il lit du contenu non fiable", "Oui, car il accède à des données privées", "Non : sans canal de sortie, pas d'exfiltration directe", "Non : il lui manque l'accès aux données privées"],
  "answer": 2,
  "explanation": "Données privées (CRM) et contenu non fiable (e-mails) sont présents, mais sans canal de sortie l'injection ne peut pas exfiltrer. Restent d'autres risques (réponses trompeuses, empoisonnement de mémoire) : la triade n'est pas la seule menace."
}
```

## 2. L'OWASP Top 10 for Agentic Applications

D'après la version publiée par l'OWASP GenAI Security Project fin 2025 (identifiants **ASI01 à ASI10**), les dix catégories sont les suivantes. ⚠️ Comme indiqué en M23, relisez l'intitulé exact sur genai.owasp.org avant tout audit contractuel et citez la version datée.

| Id | Catégorie | Exemple dans une PME | Contre-mesure principale |
|---|---|---|---|
| ASI01 | **Détournement d'objectif** (*Agent Goal Hijack*) | Un devis PDF contient une consigne cachée qui réoriente l'agent commercial | Séparer données/instructions, réduire les capacités |
| ASI02 | **Abus et exploitation d'outils** (*Tool Misuse*) | L'agent utilise l'outil « export CSV » pour aspirer tout le CRM | Paramètres bornés, quotas par outil |
| ASI03 | **Abus d'identité et de privilèges** | L'agent agit avec le jeton OAuth administrateur du dirigeant | Identité propre à l'agent, jetons courts et limités |
| ASI04 | **Chaîne d'approvisionnement agentique** | Serveur MCP communautaire installé sans revue | Registre interne, revue de code, épinglage de version |
| ASI05 | **Exécution de code inattendue** | L'agent exécute un script trouvé dans un ticket | Bac à sable, pas d'exécution hors conteneur |
| ASI06 | **Empoisonnement de mémoire et de contexte** | Une fausse règle (« le client X a droit à −40 % ») persiste en mémoire | Mémoire validée, horodatée, révisable |
| ASI07 | **Communication inter-agents non sécurisée** | Un agent fournisseur (A2A) envoie des ordres falsifiés | Authentification mutuelle, messages signés |
| ASI08 | **Défaillances en cascade** | Un agent hallucine un montant, le suivant le paie | Contrôles de cohérence entre étapes, plafonds |
| ASI09 | **Exploitation de la confiance humain-agent** | L'agent présente une action risquée de façon rassurante et l'humain clique « OK » | Résumés d'approbation factuels, diff des effets |
| ASI10 | **Agents voyous** (*Rogue Agents*) | Un agent continue d'agir hors mandat après un changement de configuration | Inventaire, supervision, coupe-circuit |

Le document *Agentic AI – Threats and Mitigations* (OWASP, février 2025) détaille ces menaces et propose des parades par couche (modèle, outils, mémoire, orchestration).

> 💡 **À retenir** — L'OWASP LLM 2026 a fait monter **Excessive Agency** de la 6e à la 3e place. L'OWASP Agentic est la déclinaison détaillée de ce risque : utilisez les deux listes ensemble dès qu'un modèle appelle un outil.

> 💡 **Précision (vérification du 5 nov. 2026)** — L'édition de référence est le *OWASP Top 10 for Agentic Applications for 2026*, publié le **9 décembre 2025**. Les intitulés anglais officiels sont : ASI01 Agent Goal Hijack · ASI02 Tool Misuse and Exploitation · ASI03 Identity and Privilege Abuse · ASI04 Agentic Supply Chain Vulnerabilities · ASI05 Unexpected Code Execution (RCE) · ASI06 Memory & Context Poisoning · ASI07 Insecure Inter-Agent Communication · ASI08 Cascading Failures · ASI09 Human-Agent Trust Exploitation · ASI10 Rogue Agents. Les libellés français du tableau ci-dessus en sont des traductions.

```mission
{
  "title": "La fiche officielle de l'OWASP Top 10 Agentic",
  "url": "https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/",
  "steps": ["Ouvrez la page de ressource de l'OWASP GenAI Security Project consacrée au Top 10 for Agentic Applications", "Relevez la date de publication", "Repérez l'intitulé anglais exact de l'entrée ASI06"],
  "question": "Quand cette édition a-t-elle été publiée, et quel est l'intitulé officiel d'ASI06 ?",
  "hint": "Elle s'appelle « for 2026 » mais a été publiée l'année précédente.",
  "answer": "Publiée le 9 décembre 2025 (édition 2026) ; ASI06 = « Memory & Context Poisoning » (vérifié le 5 nov. 2026 via une synthèse ; à relire sur genai.owasp.org avant un audit contractuel).",
  "xp": 10
}
```

```quiz
{
  "q": "Un agent comptable mémorise, après lecture d'un e-mail piégé, que « le client X bénéficie d'une remise de 40 % », et l'applique ensuite pendant des semaines. Quelle entrée de l'OWASP Agentic est concernée au premier chef ?",
  "options": ["ASI07 Insecure Inter-Agent Communication", "ASI06 Memory & Context Poisoning", "ASI10 Rogue Agents", "ASI05 Unexpected Code Execution"],
  "answer": 1,
  "explanation": "Une fausse information qui persiste dans la mémoire de l'agent et oriente ses décisions futures relève de l'empoisonnement de mémoire et de contexte. Parade : mémoire validée, horodatée et révisable."
}
```

## 3. Le « confused deputy » et les menaces MCP

### 3.1 Une faille de 1988

En 1988, Norm Hardy décrit *The Confused Deputy* : un compilateur, autorisé à écrire dans un fichier de facturation système, reçoit d'un utilisateur l'ordre d'écrire sa sortie… dans ce même fichier. Le compilateur n'est pas malveillant : il est **confus** sur l'autorité au nom de laquelle il agit. Il utilise **ses** droits pour exécuter la demande d'**un autre**.

Un agent LLM est le *deputy* parfait : il détient des droits (lire la boîte mail, appeler l'API de paie) et reçoit des demandes de sources multiples (l'utilisateur, mais aussi chaque document lu). Toute injection indirecte est, au fond, une attaque de *confused deputy*.

### 3.2 Menaces spécifiques à MCP

| Menace | Mécanisme | Parade |
|---|---|---|
| **Tool poisoning** | La *description* d'un outil MCP (lue par le modèle, rarement par l'humain) contient des instructions cachées | Revue des descriptions, affichage intégral à l'installation, registre interne |
| **Rug pull** | Un serveur change la définition de ses outils après approbation | Épinglage de version, empreinte (hash) des définitions, alerte en cas de changement |
| **Tool shadowing** | Un serveur malveillant déclare un outil au nom proche d'un outil légitime ou influence l'usage d'un autre serveur | Espaces de noms, liste blanche de serveurs par agent |
| **Token passthrough** | Un serveur MCP relaie tel quel le jeton reçu du client vers une API aval | Interdit par les bonnes pratiques de la spécification : le serveur doit valider que le jeton lui est destiné (audience) |
| **Confused deputy OAuth** | Un serveur MCP mandataire réutilise un consentement obtenu pour un autre client | Consentement par client, vérification stricte des redirections |

La spécification MCP (section *Authorization*, version 2025-11-25) s'appuie sur OAuth 2.1 et traite explicitement le *confused deputy* et le *token passthrough* dans ses bonnes pratiques de sécurité. Côté menaces sur la chaîne d'approvisionnement, rappelez-vous la règle LLM04:2026 : un serveur MCP tiers est du **code exécuté chez vous**.

> 💡 **À jour (nov. 2026)** — La révision **2026-07-28**, désormais stable, rend le protocole **sans état** : plus d'échange `initialize` ni d'identifiant de session, la version et les capacités voyagent avec chaque requête, et **l'autorisation est vérifiée à chaque requête** (contrôle de l'émetteur `iss` côté OAuth ; l'enregistrement dynamique de clients, DCR, est déprécié au profit de CIMD). Roots, Sampling, Logging et le transport HTTP+SSE sont dépréciés. Les principes de cette section restent valables ; vérifiez les détails dans le changelog officiel avant d'auditer un serveur, et prévoyez qu'un code qui suppose une session MCP doit évoluer.

> 💡 **Autrement dit** — Le *confused deputy*, c'est le coursier d'entreprise qui porte un badge « accès à tous les étages » : si un visiteur lui glisse « montez ce paquet au coffre », il le fait avec **son** badge. Le *token passthrough*, c'est prêter ce badge tel quel à un sous-traitant, sans vérifier qu'il lui était destiné.

```mission
{
  "title": "Le statut officiel de la spécification MCP 2026-07-28",
  "url": "https://github.com/modelcontextprotocol/specification/releases/tag/2026-07-28",
  "steps": ["Ouvrez la page de release 2026-07-28 du dépôt de la spécification MCP", "Lisez la première phrase de la note de version", "Repérez la date de publication et l'étiquette de la release"],
  "question": "Que dit la note de version sur le statut de la révision 2026-07-28, et quelle est la version stable précédente ?",
  "hint": "Le mot-clé est « stable » ; la version précédente date de novembre 2025.",
  "answer": "« This release marks the stable release of the 2026-07-28 revision of the Model Context Protocol » (28 juillet 2026, étiquette Latest au 5 nov. 2026) ; la stable précédente est 2025-11-25.",
  "xp": 10
}
```

> 🔗 **Documentation officielle** — [MCP — Authorization (2025-11-25)](https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization) 🇬🇧 · [OWASP — Agentic AI Threats and Mitigations](https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/) 🇬🇧

## 4. Cinq principes d'architecture

**1. Isolation.** L'agent s'exécute dans un conteneur ou une micro-VM jetable, système de fichiers limité au projet, **réseau sortant en liste blanche**. Claude Code propose un mode *sandboxing* (isolation du système de fichiers et du réseau) ; les Managed Agents d'Anthropic tournent dans des environnements cloud ou *self-hosted sandboxes*.

**2. Moindre privilège.** Une identité par agent (compte de service), des jetons à **durée courte** et **portée minimale** (lecture seule par défaut), un outil = une capacité précise (`creer_brouillon_email` plutôt que `envoyer_email`). Les secrets restent hors du contexte du modèle (coffre, injection côté serveur).

**3. Approbation humaine** des actions **irréversibles ou coûteuses** (paiement, suppression, envoi externe, modification de droits), avec un résumé factuel des effets — pas une phrase rédigée par l'agent lui-même (ASI09).

**4. Journalisation inviolable.** Chaque appel d'outil est tracé : horodatage, agent, utilisateur mandant, outil, paramètres, résultat, décision (autorisée/refusée/approuvée par qui). Le chaînage par empreintes rend toute altération détectable. Pour un système à haut risque, l'AI Act impose la journalisation automatique (art. 12) et la conservation des journaux par le déployeur pendant au moins six mois (art. 26).

**5. Coupe-circuit.** Budget maximal (tokens, euros, nombre d'actions), limite de durée, arrêt d'urgence centralisé. Le Claude Agent SDK expose par exemple un plafond de budget par exécution.

### 4.1 Exemple : politique de permissions Claude Code

```json
{
  "permissions": {
    "allow": [
      "Bash(npm run test:*)",
      "Bash(git diff:*)",
      "Read(./src/**)"
    ],
    "deny": [
      "Read(./.env)",
      "Read(./secrets/**)",
      "Bash(curl:*)",
      "Bash(git push:*)",
      "WebFetch"
    ]
  }
}
```

Ce fichier `.claude/settings.json` applique le moindre privilège : tests et lecture du code autorisés, secrets et sorties réseau refusés. Un *hook* `PreToolUse` peut ajouter des contrôles dynamiques (voir la référence des hooks).

### 4.2 Exemple : un garde de politique pour vos propres outils

```python
"""Garde de politique pour les appels d'outils d'un agent :
liste blanche, plafonds, approbation humaine, journal chaîné par empreintes.
Python 3.12+, aucune dépendance externe.
"""
import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class RegleOutil:
    nom: str
    irreversible: bool = False          # exige une approbation humaine
    plafond_appels: int = 20            # par session
    validateur: Callable[[dict], bool] = lambda p: True  # contrôle des paramètres


@dataclass
class Garde:
    agent_id: str
    mandant: str                        # utilisateur au nom duquel l'agent agit
    regles: dict[str, RegleOutil]
    journal_fichier: str = "journal_agent.jsonl"
    compteurs: dict[str, int] = field(default_factory=dict)
    derniere_empreinte: str = "GENESE"

    def _journaliser(self, evenement: dict[str, Any]) -> None:
        evenement |= {"ts": time.time(), "agent": self.agent_id,
                      "mandant": self.mandant, "prec": self.derniere_empreinte}
        ligne = json.dumps(evenement, ensure_ascii=False, sort_keys=True)
        self.derniere_empreinte = hashlib.sha256(ligne.encode()).hexdigest()
        with open(self.journal_fichier, "a", encoding="utf-8") as f:
            f.write(json.dumps({"e": evenement, "h": self.derniere_empreinte},
                               ensure_ascii=False) + "\n")

    def autoriser(self, outil: str, params: dict,
                  approbateur: Callable[[str], bool]) -> bool:
        regle = self.regles.get(outil)
        if regle is None:
            self._journaliser({"outil": outil, "decision": "refus", "motif": "hors liste blanche"})
            return False
        n = self.compteurs.get(outil, 0)
        if n >= regle.plafond_appels:
            self._journaliser({"outil": outil, "decision": "refus", "motif": "plafond atteint"})
            return False
        if not regle.validateur(params):
            self._journaliser({"outil": outil, "decision": "refus", "motif": "paramètres invalides",
                               "params": params})
            return False
        if regle.irreversible:
            resume = f"{self.agent_id} veut exécuter {outil} avec {json.dumps(params, ensure_ascii=False)}"
            if not approbateur(resume):
                self._journaliser({"outil": outil, "decision": "refus", "motif": "refus humain"})
                return False
        self.compteurs[outil] = n + 1
        self._journaliser({"outil": outil, "decision": "autorise", "params": params})
        return True


if __name__ == "__main__":
    garde = Garde(
        agent_id="agent-compta-01",
        mandant="c.martin@exemple.fr",
        regles={
            "lire_facture": RegleOutil("lire_facture", plafond_appels=100),
            "payer_facture": RegleOutil(
                "payer_facture", irreversible=True, plafond_appels=5,
                validateur=lambda p: 0 < p.get("montant_eur", 0) <= 2_000
                and p.get("iban", "").startswith("FR"),
            ),
        },
    )
    approbation_console = lambda resume: input(f"{resume}\nApprouver ? (o/n) ") == "o"
    print(garde.autoriser("payer_facture", {"montant_eur": 1250, "iban": "FR7612345"}, approbation_console))
    print(garde.autoriser("supprimer_client", {"id": 42}, approbation_console))  # refusé
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `RegleOutil` décrit un outil autorisé : est-il irréversible (approbation humaine obligatoire), combien d'appels par session, et une fonction `validateur` qui reçoit les paramètres et répond `True`/`False` (par défaut `lambda p: True`, tout accepter). `field(default_factory=dict)` donne à chaque `Garde` son propre dictionnaire de compteurs.
> - `autoriser` applique les contrôles **dans l'ordre** : outil absent de la liste blanche → refus ; plafond atteint → refus ; paramètres invalides → refus ; outil irréversible → on montre à l'humain un résumé **construit par le code** (pas par le modèle) et on attend sa décision. Chaque décision est journalisée.
> - `_journaliser` ajoute à l'événement l'heure, l'agent, le mandant et l'empreinte de l'événement **précédent** (`prec`, « GENESE » pour le premier), puis calcule l'empreinte SHA-256 du nouvel événement (`evenement |= {...}` fusionne deux dictionnaires).
> - Dans la démonstration, `payer_facture` n'accepte qu'un montant entre 0 et 2 000 € vers un IBAN commençant par « FR » ; `supprimer_client` n'est pas dans la liste blanche.

Le garde s'exécute **dans votre code**, hors du modèle : une injection peut convaincre le LLM, pas le `if`.

> 🔢 **Exemple à la main** — Exécution de la démonstration (en approuvant à la console) : le paiement de 1 250 € passe les trois contrôles, est approuvé et renvoie `True` ; `supprimer_client` est refusé (`False`, « hors liste blanche »). Le journal contient alors deux lignes : la première a `prec = "GENESE"` et une empreinte `h₁` ; la seconde a `prec = h₁` et son empreinte `h₂`. Si quelqu'un modifie après coup le montant de la première ligne, son empreinte recalculée ne vaut plus `h₁`, et la chaîne se rompt à la ligne suivante : la falsification est détectable, comme dans un registre à pages numérotées. Un paiement de 2 500 € aurait été refusé par le validateur avant même de solliciter l'humain. (Script exécuté.)

> ⚠️ **Piège fréquent** — Mettre la règle de sécurité **dans le prompt** (« n'effectuez jamais de paiement supérieur à 2 000 € ») au lieu du code. Le prompt oriente, le code contraint.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : avec `Garde.autoriser`, un paiement de 3 500 € vers un IBAN français est soumis à l'approbation humaine.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : le validateur (montant entre 0 et 2 000 €) le refuse avant même l'étape d'approbation, et le refus est journalisé avec le motif « paramètres invalides ». L'humain n'est sollicité que pour les demandes déjà conformes."
}
```

## 5. Modéliser l'attaque avec MITRE ATLAS

MITRE ATLAS (*Adversarial Threat Landscape for Artificial-Intelligence Systems*) organise les attaques contre l'IA en **tactiques** (l'objectif de l'attaquant à une étape) et **techniques** (le moyen), complétées par des **études de cas** réelles. Écrire un scénario en suivant les tactiques oblige à penser la chaîne complète, donc à placer les défenses à plusieurs endroits.

| Tactique ATLAS | Étape du scénario « agent de comptabilité » | Défense placée |
|---|---|---|
| Reconnaissance | L'attaquant apprend que la PME traite ses factures fournisseurs par un agent | Discrétion sur l'architecture |
| Accès initial | Il envoie une facture PDF contenant une consigne cachée | Filtrage des pièces jointes, conversion en texte brut |
| Exécution | L'agent lit la consigne (injection indirecte de prompt) | Séparation données/instructions |
| Évasion des défenses | La consigne demande de ne pas mentionner l'opération dans le résumé | Résumé d'approbation généré par le code, pas par l'agent |
| Exfiltration / impact | L'agent modifie l'IBAN du fournisseur et déclenche un paiement | Validateur d'IBAN (liste des IBAN connus), approbation humaine, plafond |

Les techniques correspondantes (injection de prompt d'un LLM, directe ou indirecte, jailbreak, fuite de données…) ont un identifiant `AML.T…` : vérifiez-le sur atlas.mitre.org et reportez-le dans votre rapport pour qu'un SOC puisse relier vos constats à ses règles de détection.

> 🎮 **Défi** — Dans le scénario ci-dessus, quel est le **seul** contrôle qui, à lui seul, empêche la perte financière même si toutes les autres défenses échouent ? *Réponse : le validateur côté code qui n'accepte que des IBAN déjà enregistrés et vérifiés hors bande (rappel téléphonique au fournisseur), exactement comme la procédure anti-fraude « au président » qu'appliquent déjà les services comptables.*

## 🧪 Exercice pratique

**Consigne (35 min)** — Un cabinet RH de 25 personnes veut un agent qui lit les candidatures reçues par e-mail, met à jour l'ATS (logiciel de suivi des candidats) via un serveur MCP et envoie des réponses aux candidats.
1. Dessinez l'architecture et indiquez si la **triade létale** est présente.
2. Passez l'agent au crible des **10 catégories ASI** : une ligne par catégorie (pertinent ? scénario ? mesure ?).
3. Proposez la configuration de permissions (outils autorisés, en lecture seule, soumis à approbation, interdits).
4. Écrivez un scénario ATLAS de 5 étapes et placez au moins une défense par étape.
5. Définissez le format du journal (champs) et sa durée de conservation, en justifiant (AI Act : un système de tri de CV relève de l'annexe III).

**Critères de réussite** : la triade est correctement analysée ; au moins 8 catégories ASI sont traitées avec une mesure concrète ; aucun outil d'envoi externe sans approbation ou gabarit fermé ; le journal permet de reconstituer qui a décidé quoi.

**Pistes de corrigé** : la triade est complète (données des candidats + e-mails entrants + envoi de réponses). Parade la plus forte : l'envoi aux candidats passe par des **gabarits fermés** (le modèle choisit un gabarit et remplit des champs validés, il ne rédige pas librement d'e-mail vers une adresse arbitraire) et le destinataire est imposé par le code (adresse de l'expéditeur d'origine). Serveur MCP de l'ATS : interne, version épinglée, jeton de l'agent limité aux candidatures. Journal conservé au moins 6 mois, accès restreint, données minimisées (CNIL).

## ✅ Auto-évaluation express

1. Quels sont les trois côtés de la triade létale ?
2. Qu'est-ce que le *token passthrough* et pourquoi est-il dangereux ?
3. Pourquoi le résumé présenté à l'humain pour approbation ne doit-il pas être rédigé par l'agent ?

**Réponses** : 1) Accès à des données privées, exposition à du contenu non fiable, capacité de communiquer vers l'extérieur. 2) Un serveur MCP qui relaie tel quel le jeton du client vers une API aval : il contourne le contrôle d'audience et transforme le serveur en *confused deputy*. 3) Parce qu'un agent détourné peut présenter une action dangereuse de façon rassurante (ASI09) ; le résumé doit être produit par le code à partir des paramètres réels.

## 📚 Pour aller plus loin
- [OWASP GenAI Security Project](https://genai.owasp.org/) 🇬🇧 — Top 10 LLM 2026, Top 10 Agentic et guides associés.
- [Modulos — OWASP Top 10 for Agentic Applications](https://docs.modulos.ai/frameworks/owasp-top-10-agentic/) 🇬🇧 — synthèse et correspondances.
- [MITRE ATLAS](https://atlas.mitre.org) 🇬🇧 — matrice, techniques et études de cas.
- [Claude Code — Security](https://code.claude.com/docs/en/security.md) 🇬🇧 et [Sandboxing](https://code.claude.com/docs/en/sandboxing.md) 🇬🇧 — isolation et modèle de permissions d'un agent de code.
- [Claude Code — Hooks](https://code.claude.com/docs/en/hooks.md) 🇬🇧 — contrôles `PreToolUse` / `PermissionRequest`.
- [Claude Agent SDK](https://code.claude.com/docs/en/agent-sdk/overview) 🇬🇧 — permissions, hooks et déploiement sécurisé.
- [Indirect Prompt Injection (arXiv 2302.12173)](https://arxiv.org/abs/2302.12173) 🇬🇧 — l'article qui a nommé l'attaque.

> ✅ **Si vous ne retenez que 3 choses** — 1. Un agent **agit** : dès qu'il cumule données privées, contenu non fiable et sortie vers l'extérieur (la triade létale), une injection indirecte peut exfiltrer ; passez-le au crible des dix catégories OWASP Agentic (ASI01-ASI10) et des menaces MCP (tool poisoning, rug pull, token passthrough, *confused deputy*). 2. Cinq principes d'architecture : isolation, moindre privilège, approbation humaine des actions irréversibles, journal inviolable, coupe-circuit. 3. Les règles de sécurité vivent **dans le code** (liste blanche, validateurs, plafonds), pas dans le prompt : une injection peut convaincre le modèle, pas un `if`.

> 🗺️ **Et maintenant ?** — Vos agents sont cadrés techniquement ; la leçon L149 relie ces contrôles au cadre de gouvernance qui les exige : NIST AI RMF, ISO/IEC 42001 et obligations « haut risque » de l'AI Act.
