---
id: L150
module: M30
level: N4
title: "Veille scientifique, articles fondateurs et projet final"
minutes: 65
objectives:
  - "Construire un dispositif de veille scientifique durable (arXiv, conférences, blogs de laboratoires, agrégateurs) en moins de 2 heures par semaine"
  - "Appliquer une méthode de lecture critique d'un article de recherche en trois passes"
  - "Situer les 15 articles fondateurs des LLM et expliquer l'apport de chacun"
  - "Concevoir, sécuriser et gouverner un système d'IA complet dans un dossier final évalué sur 100 et soutenu devant un jury"
skills: ["C4.6"]
sources:
  - { title: "arXiv — cs.CL (Computation and Language), nouveautés", url: "https://arxiv.org/list/cs.CL/recent", lang: "en" }
  - { title: "arXiv — cs.LG (Machine Learning), nouveautés", url: "https://arxiv.org/list/cs.LG/recent", lang: "en" }
  - { title: "Hugging Face — Daily Papers", url: "https://huggingface.co/papers", lang: "en" }
  - { title: "OpenReview", url: "https://openreview.net/", lang: "en" }
  - { title: "NeurIPS", url: "https://neurips.cc/", lang: "en" }
  - { title: "ICML", url: "https://icml.cc/", lang: "en" }
  - { title: "ICLR", url: "https://iclr.cc/", lang: "en" }
  - { title: "Anthropic — Research", url: "https://www.anthropic.com/research", lang: "en" }
  - { title: "Stanford CS25 — Transformers United V6", url: "https://web.stanford.edu/class/cs25/index.html", lang: "en" }
  - { title: "Stanford HAI — AI Index Report 2026", url: "https://hai.stanford.edu/ai-index/2026-ai-index-report", lang: "en" }
  - { title: "Vaswani et al. (2017) — Attention Is All You Need", url: "https://arxiv.org/abs/1706.03762", lang: "en" }
---

# Veille scientifique, articles fondateurs et projet final

> ⏱ 65 min · 🎯 Niveau 4 · 📚 Module 30

Dernière leçon de la formation. Vous avez appris à utiliser l'IA (N1), l'automatiser (N2), la développer (N3), puis à en comprendre les mathématiques, l'entraînement, le déploiement et la sûreté (N4). Reste une compétence qui ne s'enseigne pas une fois pour toutes : **rester à jour**. Le champ produit des centaines de prépublications par jour ; ce que vous savez aujourd'hui sera partiellement dépassé dans six mois. Cette leçon vous donne un **système** de veille, une **bibliothèque** de 15 articles fondateurs à connaître, puis le cahier des charges du **projet final** qui valide la compétence C4.6.

## 🎯 Ce que vous saurez faire
- Monter en une heure un dispositif de veille filtré, soutenable et partageable avec votre équipe.
- Lire un article de 20 pages en 30 minutes sans vous perdre, et juger s'il mérite davantage.
- Expliquer en une phrase l'apport des 15 articles qui ont construit les LLM actuels.
- Produire et soutenir un dossier de conception, de sécurité et de gouvernance d'un système d'IA complet.

> 🧭 **En clair** — En IA, le savoir se périme comme le lait : ce qui est vrai aujourd'hui sera en partie dépassé dans six mois. Faire de la veille, c'est comme **trier son courrier** : on jette vite les prospectus (lecture rapide des titres), on ouvre les lettres importantes (lecture attentive de deux ou trois articles), et l'on classe ce qui doit être gardé (une synthèse partagée avec l'équipe). Cette leçon vous donne la boîte aux lettres (les sources), le coupe-papier (la lecture en trois passes) et les quinze « lettres fondatrices » que tout expert doit avoir lues. Elle se termine par le projet final, où vous assemblez tout ce que vous avez appris.

## 1. Les sources de la veille

| Source | Ce qu'on y trouve | Rythme conseillé |
|---|---|---|
| **arXiv** (catégories cs.CL, cs.LG, cs.AI, cs.CR pour la sécurité) | Prépublications, souvent **avant** relecture par les pairs | Survol des titres 2 fois par semaine |
| **Hugging Face Papers** | Sélection quotidienne commentée par la communauté, liens vers code et modèles | 10 min par jour ou résumé hebdo |
| **OpenReview** | Soumissions et **relectures publiques** de ICLR (et d'autres conférences) | Pendant les périodes de relecture |
| **Conférences** : NeurIPS (décembre), ICML (été), ICLR (printemps), ACL/EMNLP (TAL) | Articles relus, ateliers (*workshops*) spécialisés sûreté et agents | Programme et prix des meilleurs articles |
| **Blogs de laboratoires** : Anthropic Research, Transformer Circuits, OpenAI, Google DeepMind, Mistral AI | Annonces, *system cards*, travaux d'alignement et d'interprétabilité | Abonnement RSS |
| **Rapports de synthèse** : Stanford AI Index (annuel) | Tendances chiffrées : performance, incidents, investissements, régulation | Une fois par an |
| **Cours ouverts** : Stanford CS25 (séminaires d'invités), CS336 | Exposés de chercheurs sur les sujets de l'année | Une séance par mois |

Une précision historique utile : **Papers with Code**, longtemps la référence pour relier articles, code et classements, a été arrêté en 2025 ; la page *Papers* de Hugging Face assure aujourd'hui une partie de ce rôle (vérifiez l'état des services avant de les recommander à un client, ce paysage change vite).

> ⚠️ **Piège fréquent** — Une prépublication arXiv **n'est pas relue par les pairs**. Un titre spectaculaire relayé sur les réseaux sociaux peut reposer sur un protocole fragile. Règle : avant de citer un résultat à un client, cherchez s'il a été accepté en conférence, reproduit par une autre équipe, ou au moins publié avec son code.

> 💡 **Autrement dit** — Une prépublication arXiv, c'est un **brouillon déposé à la bibliothèque** : tout le monde peut le lire, mais aucun relecteur ne l'a encore vérifié. La relecture par les pairs (*peer review*), c'est le passage devant un comité de spécialistes avant publication en conférence. Utile, rapide, mais à manier comme une rumeur sérieuse tant qu'elle n'est pas confirmée.

```quiz
{
  "q": "Mise en situation : un client vous transfère un article arXiv publié il y a trois jours qui annonce « une défense qui bloque 100 % des injections de prompt ». Que répondez-vous d'abord ?",
  "options": ["« Déployons-la, le chiffre est clair »", "« Les prépublications arXiv sont toujours fausses »", "« Il faut attendre dix ans »", "« Prometteur : vérifions protocole, code et reproduction »"],
  "answer": 3,
  "explanation": "Une prépublication n'est pas relue par les pairs, et un 100 % doit alerter (rappel de L147 : aucune robustesse parfaite n'est démontrée). On lit le protocole, on cherche le code et une reproduction indépendante avant de recommander quoi que ce soit."
}
```

### 1.1 Un pipeline de veille automatisé

Le script suivant interroge l'API publique d'arXiv sur des mots-clés, et produit un résumé Markdown hebdomadaire à partager dans le canal de l'équipe. Il respecte les règles d'usage d'arXiv (une requête, délai raisonnable).

```python
"""Veille arXiv hebdomadaire : derniers articles sur des thèmes choisis.
Python 3.12+, bibliothèque standard uniquement.
"""
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import date

THEMES = ['"sparse autoencoder"', '"prompt injection"', '"AI agents" AND security',
          '"reward hacking"', '"red teaming" AND "language models"']
NS = {"a": "http://www.w3.org/2005/Atom"}


def chercher(requete: str, n: int = 5) -> list[dict]:
    params = urllib.parse.urlencode({
        "search_query": f"all:{requete}",
        "sortBy": "submittedDate", "sortOrder": "descending", "max_results": n,
    })
    url = f"https://export.arxiv.org/api/query?{params}"
    with urllib.request.urlopen(url, timeout=30) as r:
        racine = ET.fromstring(r.read())
    articles = []
    for e in racine.findall("a:entry", NS):
        articles.append({
            "titre": " ".join(e.findtext("a:title", "", NS).split()),
            "lien": e.findtext("a:id", "", NS),
            "date": e.findtext("a:published", "", NS)[:10],
        })
    return articles


def main() -> None:
    lignes = [f"# Veille IA — semaine du {date.today():%d/%m/%Y}\n"]
    for theme in THEMES:
        lignes.append(f"\n## {theme}\n")
        for a in chercher(theme):
            lignes.append(f"- {a['date']} — [{a['titre']}]({a['lien']})")
    with open("veille.md", "w", encoding="utf-8") as f:
        f.write("\n".join(lignes))
    print("veille.md écrit.")


if __name__ == "__main__":
    main()
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `urllib.parse.urlencode` fabrique la partie « paramètres » de l'adresse (recherche, tri par date de dépôt décroissante, 5 résultats) ; `urllib.request.urlopen(..., timeout=30)` interroge l'API d'arXiv, qui répond en XML au format **Atom** (un format de flux d'actualités). `ET.fromstring` analyse ce XML ; `NS` déclare l'espace de noms Atom, d'où les préfixes `a:` dans `findall("a:entry", NS)` et `findtext("a:title", "", NS)`. `" ".join(titre.split())` supprime les retours à la ligne du titre ; `[:10]` ne garde que la date `AAAA-MM-JJ`. `main` écrit un fichier Markdown avec un titre par thème et une ligne par article.

Étape suivante possible : passer chaque résumé (*abstract*) à un modèle (par exemple Claude Haiku 5.5, le moins coûteux de la gamme en nov. 2026) avec la consigne « en 2 lignes : contribution, preuve apportée, limite principale » — en gardant le lien vers l'article original et **en lisant vous-même** ce qui compte.

## 2. Lire un article en trois passes

La méthode popularisée par S. Keshav (*How to Read a Paper*, 2007) reste la plus efficace :

1. **Passe 1 (5-10 min)** : titre, résumé, introduction, titres de sections, figures, conclusion. Vous devez pouvoir répondre aux « 5 C » : catégorie, contexte, correction apparente, contributions, clarté. Décision : continuer ou non.
2. **Passe 2 (≈ 1 h)** : lecture complète sans les preuves ; regardez attentivement les **figures et tableaux** (axes, barres d'erreur, comparaisons honnêtes ?), notez les références à lire.
3. **Passe 3 (plusieurs heures)** : reconstruire mentalement le travail, ou **reproduire** l'expérience avec le code publié. Réservée aux articles centraux pour votre projet.

Grille critique pour la passe 2 : *Quelle est l'hypothèse ? Quelle base de comparaison ? Les gains dépassent-ils la variance ? Le jeu de test a-t-il pu fuiter dans l'entraînement ? Qu'est-ce qui n'a pas été testé ?*

> 💡 **À retenir** — La veille utile n'est pas « tout lire » : c'est **trier vite** (passe 1 sur 20 articles), **comprendre bien** (passe 2 sur 2 ou 3) et **partager** une synthèse sourcée.

```
 20 articles ──passe 1 (10 min)──► 3 retenus ──passe 2 (1 h)──► 1 central ──passe 3──► reproduction
     │                                 │                            │
  titres, résumé, figures      figures, comparaisons, limites    code, expérience refaite
```

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : selon la méthode de Keshav, la première passe sert à décider si l'article mérite d'être lu plus en profondeur.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai : en 5 à 10 minutes (titre, résumé, introduction, figures, conclusion), on répond aux « 5 C » puis l'on décide de continuer ou non. La reproduction de l'expérience relève de la troisième passe."
}
```

## 3. Les 15 articles fondateurs

| # | Article (année) | Apport en une phrase | Lien |
|---|---|---|---|
| 1 | **Attention Is All You Need** — Vaswani et al. (2017) | Le Transformer : l'attention seule remplace la récurrence et rend l'entraînement massivement parallèle | [arXiv 1706.03762](https://arxiv.org/abs/1706.03762) |
| 2 | **BERT** — Devlin et al. (2018) | Pré-entraînement bidirectionnel par masquage, puis adaptation à de multiples tâches | [arXiv 1810.04805](https://arxiv.org/abs/1810.04805) |
| 3 | **Scaling Laws for Neural Language Models** — Kaplan et al. (2020) | La perte décroît en loi de puissance avec paramètres, données et calcul : on peut **prévoir** les gains | [arXiv 2001.08361](https://arxiv.org/abs/2001.08361) |
| 4 | **GPT-3 : Language Models are Few-Shot Learners** — Brown et al. (2020) | À 175 milliards de paramètres, l'apprentissage **en contexte** à partir de quelques exemples émerge | [arXiv 2005.14165](https://arxiv.org/abs/2005.14165) |
| 5 | **RAG** — Lewis et al. (2020) | Coupler un générateur à un index documentaire pour des réponses actualisables et sourcées | [arXiv 2005.11401](https://arxiv.org/abs/2005.11401) |
| 6 | **LoRA** — Hu et al. (2021) | Adapter un grand modèle en n'entraînant que des matrices de faible rang : fine-tuning à coût réduit | [arXiv 2106.09685](https://arxiv.org/abs/2106.09685) |
| 7 | **Chain-of-Thought Prompting** — Wei et al. (2022) | Faire écrire les étapes de raisonnement améliore nettement les tâches à plusieurs étapes | [arXiv 2201.11903](https://arxiv.org/abs/2201.11903) |
| 8 | **InstructGPT** — Ouyang et al. (2022) | SFT + RLHF : un modèle 100 fois plus petit préféré à GPT-3 par les annotateurs | [arXiv 2203.02155](https://arxiv.org/abs/2203.02155) |
| 9 | **Chinchilla : Training Compute-Optimal LLMs** — Hoffmann et al. (2022) | À budget fixé, il faut augmenter données et paramètres **en proportion** : les modèles de l'époque étaient sous-entraînés | [arXiv 2203.15556](https://arxiv.org/abs/2203.15556) |
| 10 | **ReAct** — Yao et al. (2022) | Alterner raisonnement et actions (outils) : l'ancêtre direct des agents actuels | [arXiv 2210.03629](https://arxiv.org/abs/2210.03629) |
| 11 | **Constitutional AI** — Bai et al. (2022) | Aligner par des principes écrits et du retour d'IA (RLAIF) | [arXiv 2212.08073](https://arxiv.org/abs/2212.08073) |
| 12 | **Toolformer** — Schick et al. (2023) | Un modèle apprend lui-même quand et comment appeler des API externes | [arXiv 2302.04761](https://arxiv.org/abs/2302.04761) |
| 13 | **DPO** — Rafailov et al. (2023) | Optimiser les préférences sans modèle de récompense ni RL explicite | [arXiv 2305.18290](https://arxiv.org/abs/2305.18290) |
| 14 | **Toy Models of Superposition** — Elhage et al. (2022) | Pourquoi les neurones sont polysémantiques : base théorique de l'interprétabilité par dictionnaire | [arXiv 2209.10652](https://arxiv.org/abs/2209.10652) |
| 15 | **DeepSeek-R1** — DeepSeek-AI (2025) | Le raisonnement long obtenu principalement par apprentissage par renforcement, publié en poids ouverts | [arXiv 2501.12948](https://arxiv.org/abs/2501.12948) |

**Bonus sûreté** (lus en L146-L147) : *Concrete Problems in AI Safety* ([arXiv 1606.06565](https://arxiv.org/abs/1606.06565)), *Deep RL from Human Preferences* ([arXiv 1706.03741](https://arxiv.org/abs/1706.03741)), *Sleeper Agents* ([arXiv 2401.05566](https://arxiv.org/abs/2401.05566)), *Indirect Prompt Injection* ([arXiv 2302.12173](https://arxiv.org/abs/2302.12173)). **Bonus efficacité** (M28-M29) : QLoRA ([arXiv 2305.14314](https://arxiv.org/abs/2305.14314)), FlashAttention ([arXiv 2205.14135](https://arxiv.org/abs/2205.14135)).

> 🎮 **Défi** — Remettez dans l'ordre chronologique de leur **première version arXiv** : Chinchilla, ReAct, InstructGPT, Chain-of-Thought. *Réponse : Chain-of-Thought (janv. 2022) → InstructGPT (mars 2022) → Chinchilla (fin mars 2022, un peu plus de trois semaines après) → ReAct (oct. 2022). Indice : le numéro arXiv commence par AAMM.*

> 🔗 **Documentation officielle** — [arXiv cs.CL](https://arxiv.org/list/cs.CL/recent) 🇬🇧 · [Hugging Face Papers](https://huggingface.co/papers) 🇬🇧 · [OpenReview](https://openreview.net/) 🇬🇧

```mission
{
  "title": "Passe 1 sur l'article qui a tout lancé",
  "url": "https://arxiv.org/abs/1706.03762",
  "steps": ["Ouvrez la page arXiv de « Attention Is All You Need »", "Lisez uniquement le résumé (passe 1)", "Relevez le score obtenu en traduction anglais-allemand et le coût d'entraînement annoncé"],
  "question": "Quel score BLEU le Transformer obtient-il sur WMT 2014 anglais-allemand, et combien de temps et de GPU l'entraînement anglais-français a-t-il demandé ?",
  "hint": "Le résumé cite deux scores BLEU et une durée en jours.",
  "answer": "28,4 BLEU en anglais-allemand ; 3,5 jours d'entraînement sur huit GPU pour l'anglais-français (article de 2017, chiffres figés) (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

```mission
{
  "title": "Ce que Chinchilla a changé dans le dimensionnement",
  "url": "https://arxiv.org/abs/2203.15556",
  "steps": ["Ouvrez la page arXiv de « Training Compute-Optimal Large Language Models »", "Lisez le résumé", "Repérez la règle d'échelle proposée et la comparaison entre Chinchilla et Gopher"],
  "question": "Que recommande l'article quand on double la taille du modèle, et en quoi Chinchilla diffère-t-il de Gopher ?",
  "hint": "Deux grandeurs doivent croître au même rythme ; Chinchilla est 4 fois plus petit que Gopher.",
  "answer": "Doubler aussi le nombre de tokens d'entraînement (paramètres et données à l'échelle égale) ; Chinchilla (70B) utilise le même budget de calcul que Gopher (280B) avec environ 4 fois plus de données, et le surpasse (article de 2022, chiffres figés).",
  "xp": 10
}
```

## 4. Projet final de la formation

### 4.1 Le sujet

Vous concevez un **système d'IA complet** pour une organisation française réelle ou réaliste (PME, cabinet, collectivité, association, organisme de formation), au choix parmi trois cas, ou un cas personnel validé par le formateur référent :

- **A. Assistant de pré-qualification des candidatures** pour un cabinet de recrutement (haut risque, annexe III).
- **B. Agent de traitement des factures fournisseurs** pour une PME industrielle (agent avec outils de paiement).
- **C. Assistant documentaire RAG** pour un cabinet d'expertise comptable (données clients confidentielles, conseil fiscal).

### 4.2 Le dossier attendu (25 à 40 pages, annexes comprises)

1. **Synthèse exécutive** (1 page) : besoin, solution, risques majeurs, décision demandée.
2. **Conception** : architecture (schéma), choix du ou des modèles (API ou poids ouverts, justifiés par coût, performance, souveraineté — M27-M29), RAG / fine-tuning / agents, plan d'évaluation de la qualité.
3. **Sécurité** : registre des risques OWASP LLM 2026 + Agentic (L106, L148), scénario d'attaque MITRE ATLAS, architecture de permissions, **rapport de red teaming** exécuté sur un prototype (L147 : harnais, ASR, refus excessif).
4. **Alignement et fiabilité** : modes d'échec pertinents (complaisance, hallucination, reward hacking) et tests associés (L146).
5. **Gouvernance et conformité** : qualification AI Act et calendrier, tableau de correspondance NIST / ISO / AI Act rempli (L149), AIPD simplifiée, contrôle humain, journalisation, procédure d'incident.
6. **Plan de déploiement et de surveillance** : indicateurs, coûts, critères d'arrêt.
7. **Annexes** : code du prototype (dépôt Git), journaux de tests, bibliographie (au moins 8 références dont 4 articles de recherche).

### 4.3 La grille d'évaluation sur 100

| Critère | Points | Atteint quand… |
|---|---|---|
| Analyse du besoin et pertinence métier | 10 | Le problème est chiffré, les utilisateurs et les bénéfices sont identifiés |
| Architecture et choix techniques | 15 | Les choix sont justifiés par des mesures (coût, latence, qualité), des alternatives sont discutées |
| Prototype fonctionnel et évaluation qualité | 10 | Le prototype s'exécute ; un jeu d'évaluation et des métriques sont fournis |
| Analyse de menaces (OWASP + ATLAS) | 15 | Toutes les entrées pertinentes sont traitées ; le scénario ATLAS place des défenses à chaque étape |
| Red teaming exécuté et rapporté | 15 | Campagne reproductible, ASR avant/après, refus excessif, limites, aucun contenu nuisible produit |
| Alignement et fiabilité | 5 | Au moins deux modes d'échec testés avec protocole |
| Gouvernance et conformité | 15 | Qualification AI Act exacte, correspondance des cadres, AIPD, contrôle humain, journaux, incidents |
| Qualité du dossier et des sources | 5 | Clair, structuré, sources primaires et datées, réserves signalées |
| Soutenance | 10 | Présentation claire, réponses argumentées, alternatives discutées |
| **Total** | **100** | **Seuil de validation : 60/100, et aucun des critères à 15 points en dessous de 6** |

> 🔢 **Exemple à la main** — Le double seuil se vérifie critère par critère. Dossier 1 : $8 + 12 + 7 + 11 + 5 + 4 + 12 + 4 + 5 = 68$ points, mais le red teaming n'obtient que 5/15 (sous 6) : **non validé**, malgré un total supérieur à 60. Dossier 2 : $7 + 10 + 6 + 9 + 8 + 3 + 9 + 3 + 6 = 61$, tous les critères à 15 points à 6 ou plus (10, 9, 8, 9) : **validé**. (Chiffres fictifs, sommes vérifiées en Python.)

Ce barème se convertit dans la grille commune du référentiel d'évaluation (cinq critères notés de 0 à 3 ; validation de la compétence à 8/15 sans critère à 0) : fonctionnement ← prototype ; qualité/structure ← architecture et dossier ; pertinence métier ← besoin ; conformité et sécurité ← menaces, red teaming, gouvernance ; explication ← soutenance.

### 4.4 La soutenance

- **Format** : 20 minutes de présentation + 15 minutes de questions, à distance, devant un **jury de deux membres** dont au moins un professionnel extérieur à l'équipe pédagogique.
- **Démonstration** obligatoire de 5 minutes : le prototype, puis **une attaque rejouée** et la défense qui la bloque.
- **Questions types** : « Que se passe-t-il si le modèle fournisseur change de version ? », « Quelle mesure supprimeriez-vous en premier si le budget était divisé par deux, et pourquoi ? », « Montrez-nous la ligne du journal qui prouve qu'un humain a validé cette action. »

> 💡 **À retenir** — Le jury n'attend pas un système parfait mais un système **dont vous connaissez les limites** et pour lequel vous avez des preuves. « Nous n'avons pas testé X, voici pourquoi et voici le plan » vaut mieux qu'une affirmation non démontrée.

```quiz
{
  "q": "Un candidat obtient 72/100 au projet final, dont 5/15 au critère « Red teaming exécuté et rapporté ». Le projet est-il validé ?",
  "options": ["Oui, car 72 dépasse le seuil de 60", "Non : 5/15 en red teaming, sous 6", "Oui, si la soutenance dépasse 8/10", "Non, car il faut au moins 80/100"],
  "answer": 1,
  "explanation": "Le seuil exige 60/100 ET aucun des critères à 15 points en dessous de 6. Avec 5/15 en red teaming, le projet n'est pas validé malgré un total suffisant."
}
```

### 4.5 Et après ?

Ce projet constitue une excellente préparation aux certifications tierces dont la formation couvre les référentiels — par exemple les examens de la gamme Claude Certified d'Anthropic (domaines *Security & Safety* et *Governance, Safety & Risk* ; examens réservés aux employés d'organisations membres du Claude Partner Network, voir L011), ou une démarche de type auditeur ISO/IEC 42001. Nous vous **encourageons à les passer** : elles sont délivrées par leurs propres organismes, selon leurs propres règles, et viennent compléter votre certificat Next Formation.

## 🧪 Exercice pratique

**Consigne (25 min, amorce du projet final)** —
1. Lancez le script de veille sur 3 thèmes liés à votre cas de projet ; sélectionnez 1 article et faites-en la **passe 1** (fiche de 5 lignes : les « 5 C »).
2. Choisissez votre cas (A, B ou C) et rédigez la **synthèse exécutive** provisoire (1 page).
3. Dressez le **plan de votre dossier** en reprenant les 7 parties de la section 4.2, avec pour chacune la leçon de la formation qui vous servira de point d'appui.

**Critères de réussite** : l'article choisi est récent (moins de 12 mois) et pertinent pour le cas ; la synthèse tient en une page et nomme les trois risques principaux ; le plan est complet et relié aux leçons.

**Pistes de corrigé** : pour le cas B, thèmes de veille pertinents — « prompt injection » + « agents » + « tool use security » ; risques principaux — injection indirecte via PDF (ASI01), paiement frauduleux (ASI02/ASI03), défaillance en cascade sur un montant (ASI08). Appuis : L148 pour l'architecture de permissions, L147 pour la campagne, L149 pour la qualification (système non haut risque a priori, mais obligations RGPD et art. 4 applicables).

## ✅ Auto-évaluation express

1. Pourquoi faut-il se méfier d'une prépublication arXiv citée seule ?
2. Quel article a montré qu'à budget de calcul fixé, les modèles de 2020-2021 étaient sous-entraînés en données ?
3. Quel est le seuil de validation du projet final ?

**Réponses** : 1) Elle n'a pas été relue par les pairs ; il faut vérifier acceptation en conférence, reproduction ou code publié. 2) Chinchilla (Hoffmann et al., 2022). 3) 60/100, sans aucun critère à 15 points noté sous 6/15.

## 📚 Pour aller plus loin
- [arXiv — cs.LG, nouveautés](https://arxiv.org/list/cs.LG/recent) 🇬🇧 — flux quotidien en apprentissage automatique.
- [NeurIPS](https://neurips.cc/) 🇬🇧 · [ICML](https://icml.cc/) 🇬🇧 · [ICLR](https://iclr.cc/) 🇬🇧 — programmes, articles acceptés, ateliers sûreté.
- [Anthropic — Research](https://www.anthropic.com/research) 🇬🇧 — alignement, interprétabilité, impacts sociétaux.
- [Stanford CS25 — Transformers United V6](https://web.stanford.edu/class/cs25/index.html) 🇬🇧 — séminaires d'invités des laboratoires (source d'inspiration, non reproduite).
- [Stanford HAI — AI Index Report 2026](https://hai.stanford.edu/ai-index/2026-ai-index-report) 🇬🇧 — la synthèse annuelle de référence.
- [Hugging Face Papers](https://huggingface.co/papers) 🇬🇧 — sélection quotidienne avec code et modèles.

> ✅ **Si vous ne retenez que 3 choses** — 1. Une veille soutenable trie vite et partage : quelques sources (arXiv, Hugging Face Papers, OpenReview, blogs de laboratoires, AI Index), un rythme fixe, et une prépublication n'est jamais une preuve à elle seule. 2. Lisez en trois passes (survol, compréhension, reproduction) et appliquez la grille critique : hypothèse, base de comparaison, variance, fuite du jeu de test. 3. Le projet final réunit conception, sécurité, alignement et gouvernance : le jury attend un système dont vous connaissez et prouvez les limites, validé à 60/100 sans aucun critère à 15 points sous 6.

> 🗺️ **Et maintenant ?** — C'est la dernière leçon : place au projet final et à sa soutenance, puis à votre propre système de veille, qui prendra le relais de cette formation pour vous garder à jour.
