---
module: M24
title: "Fiche mémo — Mathématiques pour l'IA"
---
# Fiche mémo — M24 · Mathématiques pour l'IA

> En une phrase : un réseau de neurones, ce sont des produits de matrices, une perte tirée d'une hypothèse probabiliste, des pentes calculées par la règle de la chaîne et des petits pas pour descendre cette perte.

## Les 7 idées à retenir
1. Vecteur = donnée ou embedding, matrice = transformation ou couche, produit = appliquer la couche (`L111`).
2. Attention = similarités $QK^\top$, softmax, moyenne pondérée des $V$ ; la matrice $T \times T$ rend le coût quadratique (`L111`).
3. La SVD garde les directions fortes d'une matrice : c'est l'intuition de LoRA, qui apprend $\Delta W = BA$ de rang faible (`L111`).
4. Le gradient a la forme du paramètre ; la rétropropagation (règle de la chaîne en mode inverse) donne tous les gradients en un passage (`L112`).
5. Choisir une perte, c'est choisir une hypothèse sur le bruit : gaussienne → MSE, Bernoulli → BCE, catégorielle → entropie croisée (`L113`).
6. Perte d'un LLM = entropie croisée moyenne en nats ; perplexité = $e^{\mathcal{L}}$ (`L113`).
7. Le taux d'apprentissage est l'hyperparamètre n° 1 ; AdamW + warm-up + cosinus + écrêtage à 1,0 forment la recette de départ d'un transformer (`L114`).

## Le schéma à connaître
```mermaid
flowchart LR
  X["Entrée x"] --> L["Couche y = Wx + b"]
  L --> S["Softmax → probabilités"]
  S --> P["Perte : entropie croisée"]
  P -. "backward : règle de la chaîne" .-> G["Gradients ∇L"]
  G --> O["AdamW : θ ← θ − η·pas"]
  O -. "pas suivant" .-> L
```

## Les formules essentielles
| Formule | Intuition en mots simples |
|---|---|
| $\cos(x,y) = \dfrac{x \cdot y}{\|x\|\,\|y\|}$ | Deux flèches vont-elles dans le même sens, quelle que soit leur longueur ? |
| $\text{softmax}\!\left(QK^\top/\sqrt{d_k}\right)V$ | Chaque mot compare sa question aux étiquettes des autres, puis mélange leurs contenus. |
| $A = U\Sigma V^\top$ | Toute matrice = tourner, étirer, tourner ; les gros étirements suffisent souvent. |
| $\dfrac{dy}{dx} = \dfrac{dy}{dg}\cdot\dfrac{dg}{dx}$ | Les sensibilités se multiplient le long d'un chemin, s'additionnent entre chemins. |
| $\dfrac{\partial L}{\partial W} = \delta x^\top,\ \dfrac{\partial L}{\partial x} = W^\top\delta$ | Erreur × entrée corrige le poids ; l'erreur redescend à travers $W^\top$. |
| $D_{\mathrm{KL}}(p\|q) = H(p,q) - H(p) \ge 0$ | Surcoût de surprise quand on se fie à $q$ au lieu de la réalité $p$ ; non symétrique. |
| $\pi_k = e^{z_k/T} / \sum_j e^{z_j/T}$ | La température est un thermostat d'audace : basse = favori, haute = outsiders. |
| $\theta_{t+1} = \theta_t - \eta\,\nabla L(\theta_t)$, convergence si $\eta < 2/\lambda_{\max}$ | Un pas vers le bas ; la direction la plus raide fixe le pas maximal. |
| $\theta_{t+1} = \theta_t - \eta\big(\hat m_t/(\sqrt{\hat v_t}+\varepsilon) + \lambda\theta_t\big)$ | AdamW : un pas d'environ $\eta$ par paramètre, la décroissance des poids à part. |

## Vocabulaire express
| Terme | En clair |
|---|---|
| Rang | Nombre de colonnes indépendantes : borne l'expressivité d'une couche. |
| Jacobienne | Tableau des sensibilités sortie/entrée ; pour $Wx$, c'est $W$. |
| NLL | Log-vraisemblance négative, ce qu'on minimise. |
| Conditionnement $\kappa$ | $\lambda_{\max}/\lambda_{\min}$ : vallée ronde ou couloir étroit. |

## Les pièges classiques
- `*` en NumPy multiplie terme à terme ; le produit matriciel s'écrit `@`.
- Comparer des embeddings de deux modèles différents n'a aucun sens : réindexez tout.
- Oublier `optimizer.zero_grad()` : PyTorch accumule les gradients.
- `Adam(weight_decay=0.1)` n'est pas AdamW (L2 couplée) : utilisez `torch.optim.AdamW`.
- Un softmax à 0,99 n'est pas une probabilité calibrée ; une perte s'exprime en nats.

## Les commandes / chiffres / dates utiles
```python
Y = X @ W.T + b                          # nn.Linear : W de forme (sorties, entrées)
U, s, Vt = np.linalg.svd(A)              # valeurs singulières triées
perte = F.cross_entropy(logits, cibles)  # attend des logits, pas des probabilités
torch.nn.utils.clip_grad_norm_(modele.parameters(), max_norm=1.0)
# cœur de boucle : zero_grad → backward → écrêtage → opt.step → sched.step
```
- LoRA sur $4096 \times 4096$ : 16,8 M de paramètres pleins contre 65 536 avec $r = 8$ (moins de 1 %).
- État d'Adam pour 7 milliards de paramètres en float32 : 56 Go en plus des poids.
- `AdamW` par défaut : `lr=1e-3`, `weight_decay=1e-2` ; pré-entraînements de LLM : souvent $\beta_2 = 0{,}95$, weight decay ~0,1.
- Température : Claude la refuse à partir de 4.7, et sur tous les modèles avec la version d'API 2026-10-21 (SDK v2).

## Pour aller plus loin
- [MIT OCW 18.06 Linear Algebra — Gilbert Strang](https://www.ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/video_galleries/video-lectures)
- [PyTorch — A Gentle Introduction to torch.autograd](https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html)
- [PyTorch — torch.optim](https://pytorch.org/docs/stable/optim.html)

## Auto-test (3 questions — réponses en bas de fiche)
1. $A \in \mathbb{R}^{3 \times 5}$, $B \in \mathbb{R}^{5 \times 2}$ : taille de $AB$ ? $BA$ existe-t-il ?
2. Une perte moyenne de $\ln 10$ nats correspond à quelle perplexité ?
3. Hessienne de plus grande valeur propre 200 : quel taux maximal pour la descente simple ?

---
**Réponses.** 1. $3 \times 2$ ; $BA$ n'est pas défini. 2. 10. 3. $\eta < 2/200 = 0{,}01$.
