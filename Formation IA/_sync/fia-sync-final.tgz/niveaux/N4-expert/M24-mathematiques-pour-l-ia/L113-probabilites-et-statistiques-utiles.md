---
id: L113
module: M24
level: N4
title: "Probabilités et statistiques utiles"
minutes: 70
objectives:
  - "Calculer espérance et variance d'une variable aléatoire et identifier les lois de Bernoulli, catégorielle et gaussienne dans un modèle d'IA"
  - "Appliquer le maximum de vraisemblance pour estimer un paramètre et expliquer pourquoi il mène à la perte quadratique et à l'entropie croisée"
  - "Calculer entropie, entropie croisée et divergence KL et interpréter leur valeur"
  - "Construire un softmax numériquement stable avec température et l'utiliser pour calculer la perte d'un LLM, sa perplexité et échantillonner des tokens"
skills: ["C4.1"]
sources:
  - { title: "Stanford CS229 — Machine Learning (notes publiques)", url: "https://cs229.stanford.edu/", lang: "en" }
  - { title: "MIT 6.390 IntroML — Fall 2026", url: "https://introml.mit.edu/fall26/info", lang: "en" }
  - { title: "Deep Learning (Goodfellow, Bengio, Courville) — chap. 3 Probability and Information Theory", url: "https://www.deeplearningbook.org/", lang: "en" }
  - { title: "Dive into Deep Learning (d2l.ai)", url: "https://d2l.ai/", lang: "en" }
  - { title: "PyTorch — torch.nn.CrossEntropyLoss", url: "https://pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html", lang: "en" }
  - { title: "NumPy — génération de nombres aléatoires (numpy.random)", url: "https://numpy.org/doc/stable/reference/random/index.html", lang: "en" }
  - { title: "Andrej Karpathy — Neural Networks: Zero to Hero (makemore)", url: "https://karpathy.ai/zero-to-hero.html", lang: "en" }
---

# Probabilités et statistiques utiles

> ⏱ 70 min · 🎯 Niveau 4 · 📚 Module 24

## 🎯 Ce que vous saurez faire
- Reconnaître la loi de probabilité cachée derrière chaque sortie de modèle : Bernoulli pour un classifieur binaire, catégorielle pour un LLM, gaussienne pour une régression.
- Calculer espérance, variance, entropie, entropie croisée et divergence KL à la main et en NumPy.
- Dériver une estimation par maximum de vraisemblance et en déduire les fonctions de perte classiques.
- Expliquer ce que signifient la « loss » et la perplexité d'un LLM, et comment la température, le top-k et le top-p modifient la génération.

> 🧭 **En clair** — Une IA ne « sait » jamais : elle **parie**. Quand elle complète votre phrase, elle a attribué une chance à chacun des mots possibles, comme un bookmaker qui donne une cote à chaque cheval, puis elle tire au sort selon ces cotes. Les probabilités servent à décrire ces paris ; les statistiques servent à juger si les paris sont bons. La « perte » d'un modèle mesure sa **surprise** face à la bonne réponse : plus il avait misé sur le bon mot, moins il est surpris. Et la « température » est un bouton qui rend le parieur plus prudent (toujours le favori) ou plus audacieux (il tente des outsiders).

## 1. Pourquoi un LLM est d'abord un objet probabiliste

> 🧠 **L'intuition d'abord** — Deviner une phrase entière d'un coup est impossible ; deviner **le mot suivant**, puis le suivant, est faisable. La probabilité de toute la phrase est simplement le produit des probabilités de chaque mot, sachant ceux d'avant. **Analogie :** la probabilité d'arriver à l'heure au bureau = (proba d'avoir le bus) × (proba que le métro roule, *sachant* que vous avez eu le bus) × (proba que l'ascenseur marche, *sachant* le reste).

Quand vous tapez « Le cabinet comptable envoie la » et que le modèle propose « facture », il n'a pas « choisi » ce mot : il a calculé une **distribution de probabilité** sur tout son vocabulaire (de l'ordre de 100 000 à 200 000 tokens pour les modèles récents) puis il a **tiré** un token dans cette distribution. Un modèle de langage estime

$$p(x_1, \dots, x_T) = \prod_{t=1}^{T} p(x_t \mid x_1, \dots, x_{t-1})$$

> 💡 **Autrement dit** — Le grand $\prod$ signifie « multiplier les uns après les autres ». Un LLM n'est donc qu'un **prédicteur du mot suivant** qu'on appelle en boucle : chaque mot produit est ajouté au texte, et on recommence.

> 🧭 **Pré-requis express** — **$p(x_t \mid x_1, \dots, x_{t-1})$** se lit « probabilité du token $x_t$ **sachant** les tokens $x_1$ à $x_{t-1}$ » : la barre verticale $\mid$ veut dire « sachant que » (c'est une **probabilité conditionnelle**). $x_t$ est le token n° $t$ et $T$ la longueur de la phrase. Exemple : si $p(\text{le}) = 0{,}1$, $p(\text{chat} \mid \text{le}) = 0{,}05$ et $p(\text{dort} \mid \text{le chat}) = 0{,}2$, alors $p(\text{le chat dort}) = 0{,}1 \times 0{,}05 \times 0{,}2 = 0{,}001$, soit une chance sur mille.

Cette décomposition (la règle de la chaîne des probabilités) transforme la tâche impossible « modéliser toutes les phrases » en une tâche répétable : « prédire le token suivant ». Toute cette leçon sert à comprendre cette ligne, la perte qui l'entraîne et la manière dont on en tire du texte.

## 2. Variables aléatoires, espérance, variance

Une **variable aléatoire** $X$ associe un nombre au résultat d'une expérience incertaine : le nombre de clients entrant dans une boutique entre 9 h et 10 h (discrète), le délai de paiement d'une facture (continue), l'identifiant du prochain token (discrète, à valeurs dans le vocabulaire).

- Cas discret : une **fonction de masse** $p(x) = P(X = x)$, avec $\sum_x p(x) = 1$.
- Cas continu : une **densité** $p(x)$, avec $\int p(x)\,dx = 1$. Attention, une densité peut dépasser 1 ; seules ses intégrales sont des probabilités.

> 🧭 **Pré-requis express** — **$P(X = x)$** se lit « probabilité que $X$ prenne la valeur $x$ ». **$\sum_x$** additionne sur toutes les valeurs possibles (voir L111) ; pour un dé, $\sum_x p(x) = 6 \times \tfrac16 = 1$. **$\int \dots dx$** (intégrale) est la version « continue » de la somme : l'**aire sous la courbe**. Quand la variable peut prendre une infinité de valeurs (un délai de 3,27 jours), on ne parle plus de probabilité d'une valeur exacte mais de l'aire au-dessus d'un intervalle ; l'aire totale vaut 1.

> 🧠 **L'intuition d'abord** — L'**espérance**, c'est ce que vous obtiendriez « en moyenne » si vous répétiez l'expérience des milliers de fois ; la **variance**, c'est à quel point les résultats s'éparpillent autour de cette moyenne. **Analogie :** deux livreurs arrivent en moyenne à 10 h (même espérance). Le premier arrive toujours entre 9 h 55 et 10 h 05 (faible variance) ; le second entre 8 h et midi (forte variance). Vous préférez évidemment le premier, même si leur moyenne est identique.

L'**espérance** est la moyenne pondérée par les probabilités, et la **variance** mesure la dispersion autour d'elle :

$$\mathbb{E}[X] = \sum_x x\,p(x), \qquad \text{Var}(X) = \mathbb{E}\big[(X - \mathbb{E}[X])^2\big] = \mathbb{E}[X^2] - \mathbb{E}[X]^2$$

Exemple du dé à six faces : $\mathbb{E}[X] = 3{,}5$ et $\text{Var}(X) = \tfrac{91}{6} - 3{,}5^2 = \tfrac{35}{12} \approx 2{,}92$ ; écart-type $\sigma \approx 1{,}71$.

> 💡 **Autrement dit** — $\mathbb{E}[X]$ : chaque résultat multiplié par sa chance, puis tout additionné. $\text{Var}(X)$ : la moyenne des **écarts au carré** par rapport à cette moyenne (au carré pour que les écarts négatifs ne compensent pas les positifs). L'écart-type $\sigma$ est sa racine, pour revenir dans la même unité que $X$.

> 🔢 **Exemple à la main** — Le dé à six faces, chaque face ayant la probabilité $\tfrac16$.
> 1. $\mathbb{E}[X] = (1 + 2 + 3 + 4 + 5 + 6) \times \tfrac16 = 21/6 = 3{,}5$.
> 2. $\mathbb{E}[X^2] = (1 + 4 + 9 + 16 + 25 + 36) \times \tfrac16 = 91/6 \approx 15{,}17$.
> 3. $\text{Var}(X) = 15{,}17 - 3{,}5^2 = 15{,}17 - 12{,}25 \approx 2{,}92$, et $\sigma = \sqrt{2{,}92} \approx 1{,}71$.
>
> Lecture : on obtient en moyenne 3,5 et l'on s'en écarte typiquement d'environ 1,7. (Vérifié en Python.) **$\mathbb{E}$** (E « ajouré ») se lit « espérance de » ; les crochets entourent la quantité dont on fait la moyenne.

Trois propriétés servent tout le temps :

| Propriété | Formule | Usage en IA |
|---|---|---|
| Linéarité de l'espérance | $\mathbb{E}[aX + bY] = a\,\mathbb{E}[X] + b\,\mathbb{E}[Y]$ | le gradient d'un mini-batch est un estimateur sans biais du vrai gradient (L114) |
| Variance d'une somme indépendante | $\text{Var}(X+Y) = \text{Var}(X) + \text{Var}(Y)$ | initialisation des poids, facteur $\sqrt{d_k}$ de l'attention (L111) |
| Loi des grands nombres | la moyenne empirique tend vers $\mathbb{E}[X]$ | toute évaluation sur un jeu de test |

Application directe : la sortie d'un neurone $z = \sum_{i=1}^{n} w_i x_i$ avec des $w_i$ et $x_i$ indépendants, centrés, a une variance $n\,\text{Var}(w)\,\text{Var}(x)$. Pour que le signal ne grossisse ni ne s'éteigne de couche en couche, on choisit $\text{Var}(w) \propto 1/n$ : c'est l'idée des initialisations de Xavier Glorot (2010) et de Kaiming He (2015), qui prend $\text{Var}(w) = 2/n$ pour compenser la moitié des activations annulées par ReLU.

> 🔢 **Exemple à la main** — Le symbole **$\propto$** se lit « proportionnel à ». Neurone à $n = 4$ entrées, avec $\text{Var}(x) = 1$. Si $\text{Var}(w) = 1$ : $\text{Var}(z) = 4 \times 1 \times 1 = 4$, le signal grossit (écart-type 2). Avec $\text{Var}(w) = 1/n = 1/4$ : $\text{Var}(z) = 4 \times 0{,}25 \times 1 = 1$, le signal garde sa taille. Sur 100 couches, un facteur 4 à chaque couche donnerait $4^{100}$ : l'explosion assurée. (Vérifié en Python.)

> 💡 **À retenir** — En deep learning, la variance n'est pas qu'une statistique descriptive : c'est un **budget** à contrôler à chaque couche. Initialisation, normalisation (LayerNorm) et division par $\sqrt{d_k}$ poursuivent le même but, garder des activations de variance proche de 1.

### 2.1 Probabilité conditionnelle et Bayes, en une minute

> 🧠 **L'intuition d'abord** — Bayes, c'est **mettre à jour une croyance** quand un indice arrive, sans oublier à quel point la chose était rare au départ. **Analogie :** l'alarme incendie de votre immeuble sonne. Faut-il paniquer ? Si l'alarme se déclenche souvent pour un toast brûlé et que les vrais incendies sont rarissimes, une sonnerie signifie plus souvent « toast » que « feu ».

$P(A \mid B) = P(A \cap B)/P(B)$, et la formule de Bayes retourne le conditionnement : $P(A \mid B) = P(B \mid A)\,P(A)/P(B)$. Cas d'école d'une PME e-commerce : 1 % des commandes sont frauduleuses, un détecteur repère 95 % des fraudes mais alerte aussi sur 5 % des commandes saines. Sachant qu'une alerte sonne, la probabilité de fraude vaut $\dfrac{0{,}95 \times 0{,}01}{0{,}95 \times 0{,}01 + 0{,}05 \times 0{,}99} \approx 16\,\%$. Un « détecteur à 95 % » se trompe donc dans 84 % de ses alertes : ne jamais lire un score sans le taux de base.

> 🧭 **Pré-requis express** — **$P(A \mid B)$** : probabilité de $A$ **sachant** que $B$ s'est produit (on ne regarde plus que les cas où $B$ est vrai). **$A \cap B$** (« A inter B ») : $A$ **et** $B$ à la fois. Exemple : sur 100 clients, 30 ont commandé ($B$), dont 6 ont réclamé ($A$ et $B$). Alors $P(A \mid B) = 6/30 = 20\,\%$, alors que $P(A \cap B) = 6/100 = 6\,\%$. Les deux nombres ne répondent pas à la même question.

> 💡 **Autrement dit** — Dans l'exemple de fraude, sur 10 000 commandes : 100 fraudes, dont 95 repérées ; 9 900 commandes saines, dont 495 signalées à tort. Sur 590 alertes, seules 95 sont de vraies fraudes, soit 16 %. Quand l'événement est rare, les fausses alertes sont plus nombreuses que les vraies.

```quiz
{
  "q": "Un détecteur de CV frauduleux repère 98 % des fraudes et ne signale à tort que 2 % des CV honnêtes ; or seulement 0,5 % des CV reçus sont réellement frauduleux. Votre DRH vous demande s'il faut rejeter automatiquement chaque CV signalé. Que répondez-vous ?",
  "options": ["Oui : avec 98 % de fiabilité, presque toutes les alertes sont justes", "Oui, à condition de relancer le détecteur deux fois sur chaque CV", "Non : vu la rareté, beaucoup d'alertes seront fausses", "Non, car aucun détecteur automatique ne dépasse 50 % de fiabilité"],
  "answer": 2,
  "explanation": "C'est le piège du taux de base (Bayes). Quand l'événement est rare, même un bon détecteur produit une majorité de fausses alertes : sur 10 000 CV, 49 vraies alertes contre 199 fausses, soit environ 20 % d'alertes justes. On lit jamais un score sans la fréquence réelle du phénomène."
}
```

## 3. Trois lois qui couvrent 90 % des modèles

| Loi | Paramètres | Espérance | Variance | Sortie de modèle correspondante |
|---|---|---|---|---|
| **Bernoulli** $X \in \{0, 1\}$ | $p$ | $p$ | $p(1-p)$ | sigmoïde d'un classifieur binaire (spam / pas spam) |
| **Catégorielle** $X \in \{1..K\}$ | $\pi_1..\pi_K$, $\sum \pi_k = 1$ | (non pertinente) | (non pertinente) | softmax d'un classifieur multiclasse ou d'un LLM |
| **Gaussienne** $X \in \mathbb{R}$ | $\mu, \sigma^2$ | $\mu$ | $\sigma^2$ | sortie d'une régression, bruit des modèles de diffusion |

> 🧭 **Pré-requis express** — **$X \in \{0, 1\}$** : $X$ ne peut valoir que 0 ou 1 (les accolades listent les valeurs possibles) ; **$\{1..K\}$** : un entier de 1 à $K$ (par exemple $K$ = taille du vocabulaire). **$\pi_k$** (pi indicé, rien à voir avec 3,14) est la probabilité de la catégorie $k$. **$\mu$** (mu) est la moyenne, **$\sigma^2$** la variance (donc $\sigma$ l'écart-type). Exemple : un classifieur 3 classes qui sort $\pi = (0{,}7 ;\ 0{,}2 ;\ 0{,}1)$ décrit une loi catégorielle avec $K = 3$.

> 🧠 **L'intuition d'abord** — La gaussienne est la fameuse **courbe en cloche** : beaucoup de valeurs autour de la moyenne, de moins en moins à mesure qu'on s'en éloigne. La formule a l'air effrayante, mais elle dit seulement « plus vous êtes loin de $\mu$, plus c'est improbable, et ça chute très vite ». **Analogie :** la taille des adultes dans une ville. La plupart sont proches de la moyenne ; quelques-uns sont très grands ou très petits ; presque personne ne mesure 2,30 m.

La densité gaussienne vaut

$$\mathcal{N}(x \mid \mu, \sigma^2) = \frac{1}{\sqrt{2\pi\sigma^2}}\exp\!\left(-\frac{(x-\mu)^2}{2\sigma^2}\right)$$

> 💡 **Autrement dit** — $\mu$ place le sommet de la cloche, $\sigma$ règle sa largeur. Le terme $(x-\mu)^2/(2\sigma^2)$ mesure « à combien d'écarts-types je suis du centre » (au carré, divisé par 2) ; l'exponentielle négative transforme cette distance en une densité de probabilité qui s'effondre vite ; la fraction devant sert juste à ce que l'aire totale vaille 1.

> 🔢 **Exemple à la main** — Gaussienne standard ($\mu = 0$, $\sigma^2 = 1$) : la fraction devant vaut $1/\sqrt{2\pi} \approx 0{,}399$.
> 1. En $x = 0$ : $\exp(0) = 1$, densité $\approx 0{,}399$ (le sommet).
> 2. En $x = 1$ (un écart-type) : $\exp(-1/2) \approx 0{,}607$, densité $\approx 0{,}242$.
> 3. En $x = 2$ : $\exp(-2) \approx 0{,}135$, densité $\approx 0{,}054$, déjà 7 fois plus bas que le sommet.
>
> (Vérifié en Python.) $\exp(\dots)$ est une autre écriture de $e^{\dots}$.

Environ 68 % de la masse se trouve à moins d'un écart-type de $\mu$, 95 % à moins de deux. Le **théorème central limite** explique son omniprésence : une somme de nombreux petits effets indépendants tend vers une gaussienne, ce qui justifie aussi d'initialiser les poids par tirage gaussien.

> ⚠️ **Piège fréquent** — Le softmax d'un réseau produit des nombres positifs qui somment à 1, donc une distribution catégorielle **valide**, mais pas une probabilité **calibrée**. Un modèle peut afficher 0,99 et se tromper souvent. La calibration se mesure (diagramme de fiabilité, module 25) ; elle ne se suppose pas.

## 4. Le maximum de vraisemblance : d'où viennent les fonctions de perte

> 🧠 **L'intuition d'abord** — Le maximum de vraisemblance consiste à se demander : « parmi toutes les explications possibles, laquelle rendait **le moins surprenant** ce que j'ai observé ? ». **Analogie :** un détective. Face à des traces de pas boueuses, il retient le suspect dont l'histoire explique le mieux *toutes* les traces à la fois. Ici, si le vrai taux était 50 %, 12 achats sur 200 seraient incroyablement improbables ; un taux de 6 % les rend parfaitement normaux.

Une boutique en ligne observe 12 achats sur 200 visites. Quel taux de conversion $p$ croire ? Le **maximum de vraisemblance** (*maximum likelihood estimation*, MLE) choisit le paramètre qui rend les données observées les plus probables. Avec $k$ succès sur $n$ essais de Bernoulli indépendants :

$$\mathcal{L}(p) = p^{k}(1-p)^{n-k}, \qquad \log \mathcal{L}(p) = k \log p + (n-k)\log(1-p)$$

On passe au logarithme (un produit de 200 nombres inférieurs à 1 sous-déborde en flottant, une somme non) et on annule la dérivée (L112) :

$$\frac{d \log\mathcal{L}}{dp} = \frac{k}{p} - \frac{n-k}{1-p} = 0 \quad\Rightarrow\quad \hat p = \frac{k}{n} = \frac{12}{200} = 6\,\%$$

> 💡 **Autrement dit** — On écrit « la probabilité d'avoir vu exactement ces données si le taux vaut $p$ », on passe au logarithme pour transformer les multiplications en additions (plus stable pour l'ordinateur), puis on cherche le $p$ où la pente est nulle, c'est-à-dire le sommet de la courbe.

> 🧭 **Pré-requis express** — **$\mathcal{L}(p)$** (L calligraphié) désigne la **vraisemblance** : la probabilité des données observées si le paramètre vaut $p$. Ici **$\log$ = $\ln$**, le logarithme népérien ; sa propriété clé est $\log(a \times b) = \log a + \log b$ et $\log(a^k) = k \log a$, ce qui transforme le produit en somme. Le chapeau de **$\hat p$** (« p chapeau ») signale une **estimation** calculée à partir des données, par opposition à la vraie valeur inconnue $p$.

> 🔢 **Exemple à la main** — Comparons deux hypothèses pour 12 achats sur 200 visites.
> 1. $p = 0{,}06$ : $\log\mathcal{L} = 12 \ln 0{,}06 + 188 \ln 0{,}94 = 12 \times (-2{,}813) + 188 \times (-0{,}0619) \approx -33{,}76 - 11{,}63 = -45{,}39$.
> 2. $p = 0{,}5$ : $\log\mathcal{L} = 200 \ln 0{,}5 \approx -138{,}63$.
> 3. $p = 0{,}10$ : $\log\mathcal{L} \approx -47{,}44$.
>
> La valeur la moins négative (la plus haute) est celle de $p = 0{,}06$ : c'est bien $\hat p = 12/200$. (Vérifié en Python.)

Le résultat est intuitif ; ce qui compte est la **méthode**, qui s'applique telle quelle aux réseaux de neurones. Le modèle produit une distribution $p_\theta(y \mid x)$ et l'on maximise $\sum_i \log p_\theta(y_i \mid x_i)$, ou, ce qui revient au même, on **minimise la log-vraisemblance négative** (*negative log-likelihood*, NLL). Selon la loi choisie pour la sortie, on retrouve les pertes usuelles :

| Hypothèse sur $y \mid x$ | $-\log p_\theta(y \mid x)$ | Perte obtenue |
|---|---|---|
| Gaussienne $\mathcal{N}(f_\theta(x), \sigma^2)$ | $\frac{(y - f_\theta(x))^2}{2\sigma^2} + \text{cte}$ | erreur quadratique moyenne (MSE) |
| Bernoulli de paramètre $\sigma(f_\theta(x))$ | $-y\log \hat p - (1-y)\log(1-\hat p)$ | entropie croisée binaire (BCE) |
| Catégorielle $\text{softmax}(f_\theta(x))$ | $-\log \hat\pi_{y}$ | entropie croisée (CE), perte des LLM |

> 🧭 **Pré-requis express** — **$\theta$** (thêta) désigne ici **l'ensemble de tous les paramètres** du modèle (tous ses poids) ; $p_\theta(y \mid x)$ se lit « probabilité que le modèle de paramètres $\theta$ donne la réponse $y$ pour l'entrée $x$ », et $f_\theta(x)$ est la sortie brute du réseau. $\hat p$ et $\hat\pi_y$ sont les probabilités prédites ; « cte » signifie « constante » (un terme qui ne dépend pas de $\theta$, donc sans effet sur l'apprentissage). Exemple : si le modèle donne $\hat p = 0{,}8$ et que la vraie réponse est $y = 1$, la BCE vaut $-\ln 0{,}8 \approx 0{,}22$.

Les notes publiques de CS229 (Stanford) développent ce lien dans le cadre des modèles linéaires généralisés ; le chapitre 5 de Goodfellow et al. le généralise.

> 💡 **À retenir** — Choisir une fonction de perte, c'est choisir une **hypothèse probabiliste** sur le bruit des données. La MSE suppose un bruit gaussien de variance constante ; si vos erreurs ont des valeurs aberrantes fréquentes (délais de paiement, par exemple), une hypothèse plus robuste (perte L1 ou Huber) est souvent préférable.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : la perte d'entropie croisée utilisée pour entraîner les LLM n'est rien d'autre que la log-vraisemblance négative d'une loi catégorielle produite par le softmax.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. Avec une sortie catégorielle softmax(f(x)), −log p(y|x) = −log π_y : c'est exactement l'entropie croisée. Minimiser la perte revient à maximiser la vraisemblance des données."
}
```

## 5. Entropie, entropie croisée, divergence KL

Claude Shannon a défini en 1948 la quantité d'**information** d'un événement de probabilité $p$ comme $-\log_2 p$ bits : un événement certain n'apprend rien, un événement rare apprend beaucoup.

> 🧭 **Pré-requis express** — **$\log_2$** est le logarithme en base 2 : « combien de fois faut-il multiplier 2 pour obtenir ce nombre ? ». $\log_2 8 = 3$ (car $2^3 = 8$), $\log_2 1 = 0$. Comme une probabilité est inférieure à 1, son logarithme est négatif, d'où le signe moins. Exemples : pile ou face ($p = 0{,}5$) apporte $-\log_2 0{,}5 = 1$ bit ; un événement à une chance sur 1 024 apporte $-\log_2(1/1024) = 10$ bits.

> 🧠 **L'intuition d'abord** — L'information, c'est la **surprise**. « Il a fait jour ce matin » n'apprend rien (événement certain) ; « il a neigé à Marseille en juillet » apprend énormément (événement rare). L'**entropie** mesure la surprise moyenne d'une situation ; l'**entropie croisée**, la surprise moyenne quand on se fie à de mauvaises prévisions ; la **KL**, le supplément de surprise dû à ces mauvaises prévisions. **Analogie :** un météorologue local (qui connaît le climat réel) contre un météorologue parachuté d'une autre région. La KL mesure combien le second sera plus souvent surpris que le premier.

**Entropie** : l'information moyenne, c'est-à-dire l'incertitude d'une distribution.

$$H(p) = -\sum_x p(x)\log p(x)$$

**Entropie croisée** : le coût moyen quand les événements suivent $p$ mais qu'on les code (ou prédit) avec $q$.

$$H(p, q) = -\sum_x p(x)\log q(x)$$

**Divergence de Kullback-Leibler** : le surcoût dû au fait d'utiliser $q$ au lieu de $p$.

$$D_{\mathrm{KL}}(p \,\|\, q) = \sum_x p(x)\log\frac{p(x)}{q(x)} = H(p, q) - H(p) \;\geq\; 0$$

> 🧭 **Pré-requis express** — Dans **$D_{\mathrm{KL}}(p \,\|\, q)$**, les doubles barres ne sont **pas** une norme (L111) : elles séparent simplement les deux distributions comparées, « $p$ par rapport à $q$ ». **$\geq$** se lit « supérieur ou égal à ». $H(p, q)$ se lit « entropie croisée de $p$ et $q$ ».

> 💡 **Autrement dit** — $H(p)$ : l'incertitude « incompressible » de la réalité. $H(p, q)$ : l'incertitude ressentie par le modèle qui croit $q$. $D_{\mathrm{KL}}$ : l'écart entre les deux, toujours positif ou nul, et nul seulement si le modèle a parfaitement raison ($q = p$).

Exemple chiffré (en bits) avec $p = (0{,}5;\ 0{,}25;\ 0{,}25)$ la vraie répartition des motifs d'appel d'un service client et $q = (0{,}4;\ 0{,}4;\ 0{,}2)$ la prédiction du modèle :

| Quantité | Calcul | Valeur |
|---|---|---|
| $H(p)$ | $0{,}5 \times 1 + 2 \times 0{,}25 \times 2$ | $1{,}5$ bit |
| $H(p, q)$ | $-0{,}5\log_2 0{,}4 - 0{,}25\log_2 0{,}4 - 0{,}25\log_2 0{,}2$ | $\approx 1{,}572$ bit |
| $D_{\mathrm{KL}}(p\|q)$ | différence | $\approx 0{,}072$ bit |

> 🔢 **Exemple à la main** — Détail de $H(p, q)$, terme par terme ($\log_2 0{,}4 \approx -1{,}322$ ; $\log_2 0{,}2 \approx -2{,}322$) :
> 1. $-0{,}5 \times (-1{,}322) = 0{,}661$ ;
> 2. $-0{,}25 \times (-1{,}322) = 0{,}330$ ;
> 3. $-0{,}25 \times (-2{,}322) = 0{,}580$.
>
> Total : $0{,}661 + 0{,}330 + 0{,}580 \approx 1{,}572$ bit, et $D_{\mathrm{KL}} = 1{,}572 - 1{,}5 = 0{,}072$ bit. (Vérifié en Python.)

Trois conséquences pratiques :

1. Pendant l'entraînement, $p$ (les données) est fixe, donc **minimiser l'entropie croisée équivaut à minimiser la KL** : on rapproche le modèle de la distribution des données.
2. Avec une étiquette « one-hot » (le vrai token a la probabilité 1), $H(p) = 0$ et l'entropie croisée se réduit à $-\log q(\text{bonne réponse})$.
3. La KL **n'est pas symétrique** : ici $D_{\mathrm{KL}}(p\|q) \approx 0{,}050$ nat mais $D_{\mathrm{KL}}(q\|p) \approx 0{,}054$ nat. On la retrouve dans le RLHF (pénalité KL qui empêche le modèle aligné de trop s'écarter du modèle de référence), dans la distillation et dans les VAE.

> ⚠️ **Piège fréquent** — Bits ou nats ? $\log_2$ donne des bits, $\ln$ donne des nats ($1$ nat $\approx 1{,}443$ bit). PyTorch et toutes les courbes de « loss » utilisent le logarithme népérien : une perte de 2,0 signifie 2,0 nats par token.

```quiz
{
  "q": "Pour un exemple donné, un LLM attribue la probabilité 0,5 au bon token. Que vaut la perte d'entropie croisée affichée par PyTorch pour ce token ?",
  "options": ["0,5", "−0,5", "1 bit, donc la valeur 1,0", "environ 0,693 (ln 2)"],
  "answer": 3,
  "explanation": "Avec une étiquette one-hot, la perte vaut −ln(0,5) = ln 2 ≈ 0,693 nat. PyTorch utilise le logarithme népérien : 0,693 nat correspond bien à 1 bit, mais la valeur affichée est 0,693."
}
```

## 6. Softmax et température : de la perte des LLM à l'échantillonnage

> 🧠 **L'intuition d'abord** — Le softmax transforme des **notes brutes** (n'importe quels nombres, même négatifs) en **pourcentages** qui somment à 100 %, en exagérant les écarts grâce à l'exponentielle. La température est un **thermostat d'audace** : basse, le favori rafle presque tout ; haute, les écarts se tassent et les outsiders ont leur chance. **Analogie :** un jury de concours culinaire. Les notes brutes sont 18, 15 et 12 ; le softmax les convertit en « chances de gagner ». Un jury intransigeant (basse température) donne quasiment toutes les chances au 18 ; un jury bon enfant (haute température) laisse une vraie chance au 12.

Le réseau produit des **logits** $z \in \mathbb{R}^K$, des scores réels sans contrainte. Le **softmax** les transforme en distribution catégorielle, et la **température** $T > 0$ en règle l'acuité :

$$\pi_k = \text{softmax}(z / T)_k = \frac{e^{z_k / T}}{\sum_{j} e^{z_j / T}}$$

> 💡 **Autrement dit** — On divise chaque note par $T$, on prend l'exponentielle (tout devient positif, les grands écarts s'amplifient), puis on divise par le total pour obtenir des pourcentages. Diviser par un petit $T$ creuse les écarts ; par un grand $T$, les aplatit.

Avec les logits $z = (2{,}0;\ 1{,}0;\ 0{,}1)$ pour les tokens « facture », « relance », « devis » :

| Température | « facture » | « relance » | « devis » | Effet |
|---|---|---|---|---|
| $T = 0{,}5$ | 0,864 | 0,117 | 0,019 | distribution pointue, texte prévisible |
| $T = 1$ | 0,659 | 0,242 | 0,099 | distribution apprise par le modèle |
| $T = 2$ | 0,502 | 0,304 | 0,194 | distribution aplatie, texte plus varié et plus risqué |

> 🔢 **Exemple à la main** — La ligne $T = 1$ du tableau : $e^{2{,}0} \approx 7{,}389$, $e^{1{,}0} \approx 2{,}718$, $e^{0{,}1} \approx 1{,}105$ ; somme $\approx 11{,}213$. Divisions : $7{,}389 / 11{,}213 \approx 0{,}659$, $2{,}718 / 11{,}213 \approx 0{,}242$, $1{,}105 / 11{,}213 \approx 0{,}099$. Pour $T = 0{,}5$, on refait le même calcul avec les logits doublés $(4 ;\ 2 ;\ 0{,}2)$. (Vérifié en Python.)

Quand $T \to 0$, on tend vers le choix systématique du plus probable (*greedy decoding*) ; quand $T \to \infty$, vers le tirage uniforme. La température est l'un des paramètres exposés par les API de génération (OpenAI, Mistral, serveurs locaux… ; Claude la refuse à partir de 4.7, et sur tous les modèles avec la version d'API 2026-10-21 (SDK v2) ; seule l'ancienne version d'API `2023-06-01` l'accepte encore sur Sonnet 4.6 et les modèles antérieurs, voir L008) ; sa plage autorisée et sa valeur par défaut varient selon le fournisseur, à vérifier dans leur documentation.

> 🧭 **Pré-requis express** — **$T \to 0$** se lit « quand $T$ devient de plus en plus proche de 0 » et **$T \to \infty$** « quand $T$ devient de plus en plus grand » ($\infty$ = l'infini). Ce sont des façons de décrire un comportement limite, pas des valeurs qu'on règle réellement.

### 6.1 La perte d'un LLM et la perplexité

> 🧠 **L'intuition d'abord** — À chaque position du texte, on regarde quelle probabilité le modèle donnait au **vrai** mot suivant, et on mesure sa surprise ($-\log$). La perte est la surprise moyenne ; la perplexité la traduit en « nombre de mots entre lesquels le modèle hésitait ». **Analogie :** un jeu télévisé de complétion de proverbes. Un candidat qui hésite toujours entre 4 réponses a une perplexité de 4 ; un expert qui trouve presque toujours du premier coup approche de 1.

Sur une séquence de $T$ tokens, la perte d'entraînement est l'entropie croisée moyenne :

$$\mathcal{L} = -\frac{1}{T}\sum_{t=1}^{T}\log \pi_\theta(x_t \mid x_{<t})$$

La **perplexité** est son exponentielle : $\text{PPL} = e^{\mathcal{L}}$. Elle s'interprète comme un « nombre effectif de choix » : si le modèle attribue en moyenne une probabilité de $1/4$ au bon token, $\mathcal{L} = \ln 4 \approx 1{,}386$ et $\text{PPL} = 4$, comme s'il hésitait entre quatre tokens équiprobables. Un modèle au hasard sur 100 000 tokens aurait une perplexité de 100 000.

> 💡 **Autrement dit** — Perte de 0 = le modèle n'est jamais surpris (impossible en langage naturel). Perplexité de 4 = « autant hésiter entre 4 mots ». Quand la courbe de perte d'un LLM baisse pendant l'entraînement, c'est que ce nombre d'hésitations diminue.

> 🔢 **Exemple à la main** — Attention : dans la formule de la perte, **$T$ est le nombre de tokens** (pas la température de la section précédente), et $x_{<t}$ signifie « tous les tokens avant la position $t$ ». Trois tokens, auxquels le modèle donnait les probabilités 0,5 ; 0,25 ; 0,125.
> 1. Surprises : $-\ln 0{,}5 \approx 0{,}693$ ; $-\ln 0{,}25 \approx 1{,}386$ ; $-\ln 0{,}125 \approx 2{,}079$.
> 2. Moyenne ($\tfrac1T \sum$ avec $T = 3$) : $(0{,}693 + 1{,}386 + 2{,}079)/3 \approx 1{,}386$.
> 3. Perplexité : $e^{1{,}386} = 4$.
>
> Le modèle se comporte comme s'il hésitait entre 4 tokens. (Vérifié en Python.)

### 6.2 Stabilité numérique : le log-sum-exp

$e^{1000}$ déborde en flottant. On utilise l'identité $\text{softmax}(z) = \text{softmax}(z - \max z)$ et, pour la perte, on calcule directement $\log \pi_k = z_k - \log\sum_j e^{z_j}$ avec l'astuce **log-sum-exp**. C'est pourquoi `torch.nn.CrossEntropyLoss` prend des **logits** et non des probabilités.

> 🔢 **Exemple à la main** — Logits $(1000 ;\ 999)$ : $e^{1000}$ dépasse le plus grand nombre représentable (environ $10^{308}$) et donne `inf`. On retire le maximum : $(0 ;\ -1)$, puis $e^0 = 1$ et $e^{-1} \approx 0{,}368$, d'où softmax $= (1/1{,}368 ;\ 0{,}368/1{,}368) \approx (0{,}731 ;\ 0{,}269)$, le même résultat que pour $(1 ;\ 0)$ : seul l'écart entre les scores compte. (Vérifié en Python.)

### 6.3 Échantillonner : greedy, température, top-k, top-p

- **Top-k** : on ne garde que les $k$ tokens les plus probables, on renormalise, on tire.
- **Top-p** (*nucleus sampling*, Holtzman et al., 2019) : on garde le plus petit ensemble de tokens dont la probabilité cumulée atteint $p$ (par exemple 0,9), ce qui s'adapte à l'incertitude du contexte.

> 🔢 **Exemple à la main** — Avec les probabilités $(0{,}659 ;\ 0{,}242 ;\ 0{,}099)$ du tableau ($T = 1$) : **top-k = 2** garde « facture » et « relance » et renormalise : $0{,}659/0{,}901 \approx 0{,}73$ et $0{,}242/0{,}901 \approx 0{,}27$. **Top-p = 0,85** : cumul $0{,}659$ (insuffisant), puis $0{,}659 + 0{,}242 = 0{,}901 \geq 0{,}85$ : on garde les deux mêmes tokens et « devis » ne peut plus sortir. (Vérifié en Python.)

```python
import numpy as np

def softmax(z, T=1.0):
    """Softmax stable avec température."""
    z = np.asarray(z, dtype=float) / T
    z = z - z.max()                       # aucune exponentielle ne déborde
    e = np.exp(z)
    return e / e.sum()

def log_softmax(z):
    z = np.asarray(z, dtype=float)
    m = z.max()
    return z - (m + np.log(np.exp(z - m).sum()))   # astuce log-sum-exp

def entropie(p):
    p = np.asarray(p, dtype=float); p = p[p > 0]
    return -(p * np.log(p)).sum()

def entropie_croisee(p, q):
    return -(np.asarray(p) * np.log(q)).sum()

def kl(p, q):
    return entropie_croisee(p, q) - entropie(p)

def echantillonner(logits, T=1.0, top_k=None, top_p=None, rng=None):
    rng = rng or np.random.default_rng()
    probs = softmax(logits, T)
    ordre = np.argsort(-probs)            # indices du plus au moins probable
    garde = np.ones_like(probs, dtype=bool)
    if top_k is not None:
        garde[ordre[top_k:]] = False
    if top_p is not None:
        cumul = np.cumsum(probs[ordre])
        n = np.searchsorted(cumul, top_p) + 1      # plus petit noyau atteignant top_p
        garde[ordre[n:]] = False
    probs = np.where(garde, probs, 0.0)
    return rng.choice(len(probs), p=probs / probs.sum())

# 1. Température
z = [2.0, 1.0, 0.1]
for T in (0.5, 1.0, 2.0):
    print(f"T={T}: {np.round(softmax(z, T), 3)}  entropie={entropie(softmax(z, T)):.3f} nat")

# 2. Entropie croisée et KL (en bits pour retrouver le tableau)
p, q = np.array([0.5, 0.25, 0.25]), np.array([0.4, 0.4, 0.2])
print(f"H(p)={entropie(p)/np.log(2):.3f} bit  H(p,q)={entropie_croisee(p, q)/np.log(2):.3f} bit  "
      f"KL(p||q)={kl(p, q):.4f} nat  KL(q||p)={kl(q, p):.4f} nat")

# 3. Perte et perplexité d'un mini « LLM » sur 4 positions (vocabulaire de 5 tokens)
rng = np.random.default_rng(0)
logits = rng.normal(size=(4, 5)) * 2
cibles = np.array([1, 0, 3, 3])
nll = -np.array([log_softmax(l)[c] for l, c in zip(logits, cibles)])
print(f"perte moyenne={nll.mean():.3f} nat  perplexité={np.exp(nll.mean()):.2f}")

# 4. Fréquences empiriques de l'échantillonnage (loi des grands nombres)
tirages = [echantillonner(z, T=1.0, rng=rng) for _ in range(20_000)]
print("fréquences T=1 :", np.round(np.bincount(tirages, minlength=3) / 20_000, 3))
tirages = [echantillonner(z, top_p=0.85, rng=rng) for _ in range(5_000)]
print("top-p=0.85 garde les tokens :", sorted(set(tirages)))
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `np.asarray(z, dtype=float)` convertit une liste Python en tableau NumPy ; `z - z.max()` est l'astuce de stabilité de la section 6.2 ; `log_softmax` calcule $\log \pi_k$ directement, sans passer par des probabilités minuscules.
> - `entropie` : `p[p > 0]` retire les cases nulles (car $\log 0$ n'existe pas) ; `(p * np.log(p)).sum()` est la somme $\sum p \log p$ écrite case par case.
> - `echantillonner` : `np.argsort(-probs)` donne les **indices** triés du plus probable au moins probable ; `garde` est un masque de `True` ; `np.cumsum` fait les sommes cumulées (0,659 ; 0,901 ; 1) ; `np.searchsorted(cumul, top_p)` trouve la première position où le cumul atteint `top_p` ; `np.where(garde, probs, 0.0)` met à 0 les tokens exclus ; `rng.choice(3, p=...)` tire un indice selon ces probabilités.
> - Partie 3 : `logits` a la forme `(4, 5)` (4 positions × 5 tokens possibles), `cibles` la forme `(4,)` (le bon token à chaque position) ; `zip` parcourt les deux ensemble et `[c]` lit la case du bon token.
> - Partie 4 : `np.bincount` compte combien de fois chaque token a été tiré ; sur 20 000 tirages, les fréquences doivent approcher (0,659 ; 0,242 ; 0,099).

Le même calcul en PyTorch, qui vérifie que `cross_entropy` sur des logits égale bien la NLL du log-softmax :

```python
# pip install torch
import torch
import torch.nn.functional as F

torch.manual_seed(0)
logits = torch.randn(4, 5) * 2           # (positions, vocabulaire)
cibles = torch.tensor([1, 0, 3, 3])

perte = F.cross_entropy(logits, cibles)  # attend des logits, applique log-softmax en interne
manuel = -F.log_softmax(logits, dim=-1)[torch.arange(4), cibles].mean()
print(f"cross_entropy={perte.item():.4f}  manuel={manuel.item():.4f}  PPL={perte.exp().item():.2f}")

# Échantillonnage avec température
probs = F.softmax(torch.tensor([2.0, 1.0, 0.1]) / 0.7, dim=-1)
print("token tiré :", torch.multinomial(probs, num_samples=1).item())
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `torch.randn(4, 5) * 2` : tenseur de forme `(4, 5)`, une ligne de 5 logits pour chacune des 4 positions ; `cibles` est un tenseur d'entiers de forme `(4,)`.
> - `F.cross_entropy(logits, cibles)` attend exactement ces deux formes (`(N, K)` et `(N,)`) et renvoie **un seul nombre**, la perte moyenne.
> - `F.log_softmax(logits, dim=-1)` applique le log-softmax sur la dernière dimension (les 5 tokens de chaque ligne) ; `[torch.arange(4), cibles]` lit, ligne 0 à 3, la case du bon token (ligne 0 colonne 1, ligne 1 colonne 0, etc.) → forme `(4,)` ; `.mean()` fait la moyenne. Les deux valeurs affichées doivent être identiques.
> - `torch.multinomial(probs, num_samples=1)` tire un indice au hasard selon `probs` (ici avec une température de 0,7).

> 🔗 **Documentation officielle** — [PyTorch : torch.nn.CrossEntropyLoss](https://pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html) précise que l'entrée doit être des logits non normalisés et documente les options `ignore_index` (utile pour le padding) et `label_smoothing`.

```mission
{
  "title": "Les valeurs par défaut de CrossEntropyLoss",
  "url": "https://pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html",
  "steps": ["Ouvrez la page torch.nn.CrossEntropyLoss de la documentation PyTorch", "Lisez la signature de la classe tout en haut de la page", "Repérez les paramètres ignore_index, reduction et label_smoothing"],
  "question": "Quelles sont les valeurs par défaut de ignore_index, reduction et label_smoothing ?",
  "hint": "ignore_index vaut un nombre négatif « magique » souvent utilisé pour masquer le padding.",
  "answer": "ignore_index = -100, reduction = 'mean', label_smoothing = 0.0 (vérifié le 5 nov. 2026) ; à revoir à chaque version majeure de PyTorch.",
  "xp": 15
}
```

## 🧪 Exercice pratique

**Consigne.** Un modèle de classification d'e-mails entrants pour un cabinet RH produit, pour un e-mail donné, les logits $z = (3{,}0;\ 1{,}0;\ 0{,}0;\ -1{,}0)$ pour les classes (candidature, relance, facture, spam). La bonne classe est « relance ».
1. Calculez à la main (calculatrice autorisée) le softmax à $T = 1$, puis la perte d'entropie croisée.
2. Calculez la température $T$ pour laquelle « candidature » et « relance » auraient une probabilité dans un rapport de 2 pour 1.
3. Sur 1 000 e-mails, le taux de spam observé est de 87. Donnez l'estimateur du maximum de vraisemblance et l'écart-type de cet estimateur, $\sqrt{\hat p(1-\hat p)/n}$.
4. Codez une fonction `top_p` en NumPy et vérifiez qu'avec $p = 0{,}9$ et $T = 1$, seuls deux tokens restent possibles.

**Critères de réussite.** Valeurs justes à $10^{-2}$ près ; explication de l'effet de la température ; code testé.

<details>
<summary>Corrigé</summary>

1. $e^{3} = 20{,}09$ ; $e^{1} = 2{,}718$ ; $e^{0} = 1$ ; $e^{-1} = 0{,}368$ ; somme $= 24{,}17$. Softmax $\approx (0{,}831;\ 0{,}112;\ 0{,}041;\ 0{,}015)$. Perte $= -\ln 0{,}112 \approx 2{,}19$ nats : le modèle se trompe avec assurance, la perte est forte.
2. Le rapport des probabilités vaut $e^{(z_1 - z_2)/T} = e^{2/T}$. On veut $e^{2/T} = 2$, donc $T = 2/\ln 2 \approx 2{,}89$.
3. $\hat p = 87/1000 = 8{,}7\,\%$ ; écart-type $\sqrt{0{,}087 \times 0{,}913/1000} \approx 0{,}89$ point, soit un intervalle à 95 % d'environ $8{,}7 \pm 1{,}7\,\%$.
4. Les deux premières probabilités cumulées valent $0{,}831$ puis $0{,}943 \geq 0{,}9$ : le noyau contient « candidature » et « relance ».

```python
import numpy as np

def top_p(probs, p):
    ordre = np.argsort(-probs)
    n = np.searchsorted(np.cumsum(probs[ordre]), p) + 1
    filtre = np.zeros_like(probs)
    filtre[ordre[:n]] = probs[ordre[:n]]
    return filtre / filtre.sum()

z = np.array([3.0, 1.0, 0.0, -1.0])
probs = np.exp(z - z.max()); probs /= probs.sum()
print(np.round(probs, 3), "perte =", round(-np.log(probs[1]), 3))
print(np.round(top_p(probs, 0.9), 3))      # deux valeurs non nulles
```
</details>

## 🎮 Défi

Un collègue affirme : « Notre modèle a une perte de validation de 0 : il est parfait. » Donnez deux explications plus probables. (Pistes : fuite de données, les cibles se trouvant dans l'entrée ; ou masque de perte erroné, `ignore_index` excluant tous les tokens, ce qui produit une moyenne vide ou nulle selon l'implémentation. Une perte d'entropie croisée exactement nulle exige une probabilité de 1 sur chaque bon token, ce qui n'arrive pas sur du langage naturel.)

## ✅ Auto-évaluation express

1. Quelle loi décrit la sortie d'un LLM pour un token donné ?
2. Pourquoi minimiser l'entropie croisée revient-il à minimiser la divergence KL pendant l'entraînement ?
3. Une perte moyenne de $\ln 10 \approx 2{,}30$ nats correspond à quelle perplexité ?

**Réponses.** 1. Une loi catégorielle sur le vocabulaire, paramétrée par le softmax des logits. 2. Parce que $H(p, q) = H(p) + D_{\mathrm{KL}}(p\|q)$ et que $H(p)$ ne dépend pas du modèle. 3. 10.

## 📚 Pour aller plus loin
- [Deep Learning (Goodfellow, Bengio, Courville)](https://www.deeplearningbook.org/) 🇬🇧 — chapitre 3 (probabilités et théorie de l'information), section 5.5 (maximum de vraisemblance).
- [Stanford CS229 — Machine Learning](https://cs229.stanford.edu/) 🇬🇧 — notes publiques : régression logistique, modèles linéaires généralisés, modèles génératifs.
- [Dive into Deep Learning](https://d2l.ai/) 🇬🇧 — annexe mathématique (probabilités, théorie de l'information) avec code exécutable.
- [Andrej Karpathy — Neural Networks: Zero to Hero](https://karpathy.ai/zero-to-hero.html) 🇬🇧 — vidéo 2 (makemore) : un modèle de langage par comptage, la NLL et l'échantillonnage, codés pas à pas.
- [PyTorch — CrossEntropyLoss](https://pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html) 🇬🇧 — la référence de la perte des classifieurs et des LLM.
- [NumPy — numpy.random](https://numpy.org/doc/stable/reference/random/index.html) 🇬🇧 — générateurs, lois usuelles et `Generator.choice` utilisé pour l'échantillonnage.

```mission
{
  "title": "Comment NumPy recommande-t-il de tirer des nombres aléatoires ?",
  "url": "https://numpy.org/doc/stable/reference/random/index.html",
  "steps": ["Ouvrez la page « Random sampling (numpy.random) »", "Lisez le paragraphe d'introduction et l'exemple de démarrage rapide", "Repérez la fonction utilisée pour créer un générateur"],
  "question": "Quelle fonction NumPy recommande-t-il pour créer un générateur aléatoire (plutôt que les anciennes fonctions np.random.rand, np.random.seed…) ?",
  "hint": "C'est la fonction utilisée dans tous les exemples de cette leçon : rng = np.random.…(42).",
  "answer": "np.random.default_rng(), qui renvoie un objet Generator (avec .normal, .choice, .integers…) ; l'ancienne API RandomState est conservée pour la compatibilité. Doc NumPy stable, nov. 2026.",
  "xp": 10
}
```

> ✅ **Si vous ne retenez que 3 choses** — 1. Un LLM produit à chaque pas une distribution de probabilités (softmax des logits) sur le token suivant, puis tire dedans ; la température creuse ($T < 1$) ou aplatit ($T > 1$) cette distribution, top-k et top-p coupent la traîne. 2. La perte d'un LLM est la surprise moyenne $-\ln p(\text{bon token})$ (entropie croisée) ; la perplexité $e^{\text{perte}}$ est le « nombre de mots entre lesquels il hésite ». 3. Bayes rappelle de toujours regarder le taux de base, et la variance est un budget à surveiller couche après couche.

> 🗺️ **Et maintenant ?** — Vous savez définir l'erreur d'un modèle et en calculer la pente ; la leçon L114 assemble les deux pour **descendre** cette erreur pas à pas : c'est la descente de gradient et ses variantes (momentum, Adam).
