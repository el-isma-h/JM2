---
id: L127
module: M26
level: N4
title: "Projet DL : classifieur d'images"
minutes: 65
objectives:
  - "Cadrer un projet de classification d'images : besoin, métrique, seuil d'acceptation, contraintes et baseline"
  - "Construire et entraîner de bout en bout un CNN reproductible en PyTorch (données, augmentation, modèle, optimiseur, calendrier, sauvegarde)"
  - "Évaluer le modèle avec exactitude, précision, rappel, F1 par classe et matrice de confusion, et analyser ses erreurs"
  - "Rédiger un rapport technique exploitable et s'auto-évaluer avec la grille de la compétence C4.3"
skills: ["C4.3", "C4.2"]
sources:
  - { title: "MIT 6.S191 (2026) — projet final et Lecture 3", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "Stanford CS231n Spring 2026 — programme", url: "https://cs231n.stanford.edu/schedule.html", lang: "en" }
  - { title: "PyTorch — Training a Classifier (CIFAR-10)", url: "https://pytorch.org/tutorials/beginner/blitz/cifar10_tutorial.html", lang: "en" }
  - { title: "torchvision — Datasets", url: "https://pytorch.org/vision/stable/datasets.html", lang: "en" }
  - { title: "scikit-learn — confusion_matrix", url: "https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html", lang: "en" }
  - { title: "PyTorch — Reproducibility", url: "https://pytorch.org/docs/stable/notes/randomness.html", lang: "en" }
  - { title: "École 42 — Leaffliction (dépôt étudiant public)", url: "https://github.com/jainavas/leaffliction", lang: "en" }
---

# Projet DL : classifieur d'images

> ⏱ 65 min · 🎯 Niveau 4 · 📚 Module 26

## 🎯 Ce que vous saurez faire
- Transformer une demande floue (« on voudrait trier les photos automatiquement ») en un problème mesurable, avec un seuil d'acceptation.
- Livrer un script d'entraînement reproductible qui produit, à chaque exécution, un dossier complet : configuration, historique, meilleur modèle, matrice de confusion, rapport.
- Lire une matrice de confusion et en tirer des décisions (données à collecter, classes à fusionner, seuil à ajuster).
- Évaluer votre propre projet avec la grille utilisée pour la compétence C4.3 du référentiel.

> 🧭 **En clair** — Ce projet, c'est votre **chef-d'œuvre de compagnon** : construire de bout en bout un programme qui reconnaît ce qu'il y a sur une photo. Avant de coder, on fixe avec le client ce qu'on appellera un succès (comme un cahier des charges). Ensuite, on prépare les photos, on entraîne un réseau convolutif (la « loupe » de L124), on garde un lot de photos jamais vues pour l'examen final, et on analyse les erreurs : quelles classes le modèle confond-il, et pourquoi ? Enfin, on rédige un rapport qui répond d'abord à la question du client (« peut-on automatiser le tri, et à quelles conditions ? »), puis seulement à la technique.

Ce projet clôt le module. Il mobilise tout ce que vous avez construit : le MLP et la softmax (L121), la rétropropagation (L122), la boucle PyTorch (L123), les CNN (L124) et les techniques d'entraînement (L126). Comme le projet final de MIT 6.S191 ou les projets de CS231n, il est évalué sur **la démarche** autant que sur le score.

## 1. Le cadrage : avant la première ligne de code

### 1.1 Le cas

Une PME lyonnaise de petites annonces en ligne reçoit chaque jour plusieurs milliers de photos déposées par des particuliers. Une équipe de modération les range à la main dans dix catégories (véhicules, animaux, etc.). La direction voudrait « que l'IA le fasse ». Pour ce projet de formation, nous utilisons **CIFAR-10** comme substitut : dix classes d'objets du quotidien (avion, automobile, oiseau, chat, cerf, chien, grenouille, cheval, bateau, camion), assez proches du cas pour poser les bonnes questions.

CIFAR-10 a été constitué en 2009 par Alex Krizhevsky, Vinod Nair et Geoffrey Hinton (université de Toronto). Il contient 60 000 images en couleur de 32 × 32 pixels, 6 000 par classe, réparties en 50 000 images d'entraînement et 10 000 de test. Les classes sont **équilibrées**, ce qui est rarement le cas dans la vraie vie.

### 1.2 La fiche de cadrage

Remplissez-la avec le commanditaire avant de coder. Elle tient sur une page et évite 80 % des malentendus.

| Rubrique | Question | Réponse pour notre cas |
|---|---|---|
| Objectif métier | Quel problème résout-on, pour qui ? | réduire le temps de tri manuel de l'équipe de modération |
| Décision | Que fait-on de la prédiction ? | classement automatique si confiance élevée, sinon file de vérification humaine |
| Métrique principale | Comment mesure-t-on le succès ? | exactitude sur un jeu de test jamais vu ; F1 par classe en complément |
| Seuil d'acceptation | À partir de quand le modèle est-il utile ? | exactitude $\ge 80\,\%$ et aucune classe sous 65 % de rappel |
| Coût des erreurs | Toutes les erreurs se valent-elles ? | non : classer une voiture en « animal » choque plus que « automobile » ↔ « camion » |
| Baseline | Que fait-on sans deep learning ? | hasard 10 % ; MLP de L123 adapté : environ 50 % |
| Contraintes | Matériel, latence, budget, données personnelles | entraînement sur un portable CPU ou un GPU loué ; inférence en moins de 50 ms par image ; aucune photo de personne conservée (RGPD) |
| Livrables | Qu'est-ce qui sera remis ? | script, modèle, rapport, matrice de confusion, procédure de réentraînement |

> ⚠️ **Piège fréquent** — Choisir la métrique après avoir vu les résultats. Une fois l'exactitude connue, il est tentant de mettre en avant « le F1 de la classe bateau, qui est excellent ». Figez la métrique et le seuil **avant** l'entraînement, notez-les dans le rapport, et tenez-vous-y.

```quiz
{
  "q": "Dans la fiche de cadrage, pourquoi prévoir une « file de vérification humaine » pour les images où le modèle est peu confiant ?",
  "options": ["Pour augmenter artificiellement l'exactitude affichée", "Parce que la loi interdit toute décision automatique portant sur des images", "Pour automatiser les cas sûrs et garder un humain sur les doutes", "Pour entraîner le modèle en continu sans validation"],
  "answer": 2,
  "explanation": "C'est la décision métier associée à la prédiction : au-dessus d'un seuil de confiance, classement automatique ; en dessous, revue humaine. On choisit le seuil pour équilibrer volume automatisé et taux d'erreur acceptable."
}
```

### 1.3 Le protocole de données

Les 50 000 images d'entraînement sont séparées en **45 000 pour l'entraînement** et **5 000 pour la validation** (choix des hyperparamètres, arrêt, sélection du meilleur modèle). Les 10 000 images de test ne sont utilisées **qu'une fois**, à la toute fin. L'augmentation (recadrage aléatoire avec marge de 4 pixels, retournement horizontal) ne s'applique qu'à l'entraînement : la validation voit les images brutes. Le script ci-dessous charge donc deux « vues » du même jeu, l'une augmentée, l'autre non, et les découpe avec les mêmes indices.

> 💡 **Autrement dit** — Trois tas de photos, trois rôles : l'**entraînement** pour apprendre, la **validation** pour régler et choisir (comme des examens blancs), le **test** pour l'examen final, ouvert une seule fois. Les variantes « retournées et recadrées » (augmentation) ne servent qu'à l'entraînement : à l'examen, on présente les vraies photos.

## 2. Le script complet

Un seul fichier, environ 160 lignes, qui suit la même structure que les scripts de L123 et L126. Chaque exécution crée un dossier horodaté `runs/AAAAMMJJ-HHMMSS/`, ce qui permet de comparer les essais sans rien écraser.

```python
"""projet_cifar10.py — classifieur d'images de bout en bout (CIFAR-10).
Usage : python projet_cifar10.py --epoques 15        (CPU : plusieurs minutes par époque ; GPU : quelques secondes)
        python projet_cifar10.py --epoques 1 --sous-ensemble 5000   (essai rapide)
Sorties : runs/<date>/  -> config.json, historique.csv, meilleur.pt, matrice_confusion.png, rapport.md"""
import argparse, csv, json, os, random, time
from datetime import datetime

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Subset, random_split
from torchvision import datasets, transforms

CLASSES = ["avion", "automobile", "oiseau", "chat", "cerf", "chien", "grenouille", "cheval", "bateau", "camion"]

# ---------------------------------------------------------------- 1. Configuration et graines
def lire_config():
    p = argparse.ArgumentParser()
    p.add_argument("--epoques", type=int, default=15)
    p.add_argument("--lot", type=int, default=128)
    p.add_argument("--lr", type=float, default=3e-3)
    p.add_argument("--weight-decay", type=float, default=5e-4)
    p.add_argument("--graine", type=int, default=42)
    p.add_argument("--sous-ensemble", type=int, default=0, help="0 = tout le jeu d'entraînement")
    p.add_argument("--donnees", default="donnees")
    return p.parse_args()

def fixer_graines(g):
    random.seed(g); np.random.seed(g); torch.manual_seed(g)

# ---------------------------------------------------------------- 2. Données
def charger_donnees(cfg):
    moy, ect = (0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)
    t_train = transforms.Compose([transforms.RandomCrop(32, padding=4), transforms.RandomHorizontalFlip(),
                                  transforms.ToTensor(), transforms.Normalize(moy, ect)])
    t_eval = transforms.Compose([transforms.ToTensor(), transforms.Normalize(moy, ect)])
    # Deux vues du même jeu : augmentée pour le train, brute pour la validation
    train_aug = datasets.CIFAR10(cfg.donnees, train=True, download=True, transform=t_train)
    train_brut = datasets.CIFAR10(cfg.donnees, train=True, download=True, transform=t_eval)
    test = datasets.CIFAR10(cfg.donnees, train=False, download=True, transform=t_eval)
    idx = torch.randperm(len(train_aug), generator=torch.Generator().manual_seed(cfg.graine)).tolist()
    idx_val, idx_tr = idx[:5000], idx[5000:]
    if cfg.sous_ensemble:
        idx_tr = idx_tr[:cfg.sous_ensemble]
    kw = dict(batch_size=cfg.lot, num_workers=2)
    return (DataLoader(Subset(train_aug, idx_tr), shuffle=True, **kw),
            DataLoader(Subset(train_brut, idx_val), **kw),
            DataLoader(test, **kw))

# ---------------------------------------------------------------- 3. Modèle
def bloc(c_in, c_out):
    return nn.Sequential(
        nn.Conv2d(c_in, c_out, 3, padding=1, bias=False), nn.BatchNorm2d(c_out), nn.ReLU(inplace=True),
        nn.Conv2d(c_out, c_out, 3, padding=1, bias=False), nn.BatchNorm2d(c_out), nn.ReLU(inplace=True),
        nn.MaxPool2d(2))

class ReseauCIFAR(nn.Module):
    def __init__(self, n_classes=10):
        super().__init__()
        self.corps = nn.Sequential(bloc(3, 32), bloc(32, 64), bloc(64, 128))    # 32 -> 16 -> 8 -> 4
        self.tete = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Dropout(0.3),
                                  nn.Linear(128, n_classes))
    def forward(self, x):
        return self.tete(self.corps(x))

# ---------------------------------------------------------------- 4. Entraînement et évaluation
def une_epoque(modele, dl, critere, opt, sched, device):
    modele.train(); cumul = n = 0
    for xb, yb in dl:
        xb, yb = xb.to(device), yb.to(device)
        perte = critere(modele(xb), yb)
        opt.zero_grad(set_to_none=True); perte.backward(); opt.step(); sched.step()
        cumul += perte.item() * len(xb); n += len(xb)
    return cumul / n

@torch.no_grad()
def predire(modele, dl, device):
    modele.eval(); ys, ps = [], []
    for xb, yb in dl:
        ps.append(modele(xb.to(device)).argmax(1).cpu()); ys.append(yb)
    return torch.cat(ys), torch.cat(ps)

def matrice_confusion(y, p, k=10):
    m = torch.zeros(k, k, dtype=torch.long)
    m.index_put_((y, p), torch.ones_like(y), accumulate=True)   # ligne = vraie classe, colonne = prédite
    return m

def metriques(m):
    vp = m.diag().float()
    precision = vp / m.sum(0).clamp(min=1)
    rappel = vp / m.sum(1).clamp(min=1)
    f1 = 2 * precision * rappel / (precision + rappel).clamp(min=1e-12)
    return {"exactitude": (vp.sum() / m.sum()).item(), "precision": precision.tolist(),
            "rappel": rappel.tolist(), "f1": f1.tolist(), "f1_macro": f1.mean().item()}

def tracer_matrice(m, chemin):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    norm = (m.float() / m.sum(1, keepdim=True).clamp(min=1)).numpy()
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(norm, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(10), CLASSES, rotation=45, ha="right"); ax.set_yticks(range(10), CLASSES)
    ax.set_xlabel("classe prédite"); ax.set_ylabel("vraie classe")
    for i in range(10):
        for j in range(10):
            ax.text(j, i, f"{norm[i, j]:.2f}", ha="center", va="center", fontsize=7,
                    color="white" if norm[i, j] > 0.5 else "black")
    fig.colorbar(im); fig.tight_layout(); fig.savefig(chemin, dpi=150); plt.close(fig)

# ---------------------------------------------------------------- 5. Programme principal
def main():
    cfg = lire_config(); fixer_graines(cfg.graine)
    device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
    dossier = os.path.join("runs", datetime.now().strftime("%Y%m%d-%H%M%S")); os.makedirs(dossier)
    json.dump(vars(cfg) | {"device": device, "torch": torch.__version__},
              open(os.path.join(dossier, "config.json"), "w"), indent=2)

    dl_tr, dl_va, dl_te = charger_donnees(cfg)
    modele = ReseauCIFAR().to(device)
    n_params = sum(p.numel() for p in modele.parameters())
    critere = nn.CrossEntropyLoss(label_smoothing=0.1)
    opt = torch.optim.AdamW(modele.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=cfg.lr, total_steps=cfg.epoques * len(dl_tr))
    print(f"{n_params:_} paramètres | appareil {device} | {len(dl_tr.dataset)} images d'entraînement".replace("_", " "))

    meilleure, historique = 0.0, []
    for e in range(1, cfg.epoques + 1):
        t0 = time.perf_counter()
        perte = une_epoque(modele, dl_tr, critere, opt, sched, device)
        y, p = predire(modele, dl_va, device)
        acc = (y == p).float().mean().item()
        historique.append({"epoque": e, "perte_train": round(perte, 4), "exactitude_valid": round(acc, 4)})
        print(f"époque {e:2d} | perte {perte:.3f} | valid {acc:.1%} | {time.perf_counter() - t0:.0f} s")
        if acc > meilleure:
            meilleure = acc; torch.save(modele.state_dict(), os.path.join(dossier, "meilleur.pt"))
    with open(os.path.join(dossier, "historique.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=historique[0].keys()); w.writeheader(); w.writerows(historique)

    # Évaluation finale, une seule fois, sur le test, avec le meilleur modèle
    modele.load_state_dict(torch.load(os.path.join(dossier, "meilleur.pt"), map_location=device, weights_only=True))
    y, p = predire(modele, dl_te, device)
    m = matrice_confusion(y, p); res = metriques(m)
    tracer_matrice(m, os.path.join(dossier, "matrice_confusion.png"))
    confusions = sorted(((m[i, j].item(), CLASSES[i], CLASSES[j]) for i in range(10) for j in range(10) if i != j),
                        reverse=True)[:3]
    lignes = [f"# Rapport — classifieur CIFAR-10 ({datetime.now():%d/%m/%Y})", "",
              f"- Paramètres : {n_params} ; appareil : {device} ; époques : {cfg.epoques} ; graine : {cfg.graine}",
              f"- Meilleure exactitude de validation : {meilleure:.2%}",
              f"- **Exactitude de test : {res['exactitude']:.2%}** ; F1 macro : {res['f1_macro']:.3f}", "",
              "| Classe | Précision | Rappel | F1 |", "|---|---|---|---|"]
    lignes += [f"| {c} | {pr:.3f} | {rc:.3f} | {f:.3f} |"
               for c, pr, rc, f in zip(CLASSES, res["precision"], res["rappel"], res["f1"])]
    lignes += ["", "Confusions les plus fréquentes (vraie → prédite) :"]
    lignes += [f"- {a} → {b} : {n} images" for n, a, b in confusions]
    open(os.path.join(dossier, "rapport.md"), "w").write("\n".join(lignes) + "\n")
    print("\n".join(lignes))

if __name__ == "__main__":
    main()
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - Partie 1 : `argparse` lit les options de la ligne de commande (`--epoques 15`, `--lot 128`…) ; `fixer_graines` fige les trois générateurs aléatoires (Python, NumPy, PyTorch).
> - Partie 2 : deux « vues » du même jeu CIFAR-10, l'une avec augmentation (recadrage aléatoire après un cadre de 4 pixels, retournement) pour l'entraînement, l'autre brute pour la validation ; `torch.randperm(50000)` mélange les indices, les 5 000 premiers servent à la validation. `Subset(jeu, indices)` ne garde que les images choisies.
> - Partie 3 : formes pour un lot de 128 images couleur `(128, 3, 32, 32)` : `bloc(3, 32)` → `(128, 32, 16, 16)` (le `MaxPool2d(2)` final divise la taille par 2) → `bloc(32, 64)` → `(128, 64, 8, 8)` → `bloc(64, 128)` → `(128, 128, 4, 4)` → `AdaptiveAvgPool2d(1)` fait la moyenne de chaque canal sur les $4 \times 4$ cases → `(128, 128, 1, 1)` → `Flatten` → `(128, 128)` → `Linear(128, 10)` → `(128, 10)`.
> - Partie 4 : `sched.step()` est appelé **à chaque lot** (calendrier `OneCycleLR` défini en étapes). `predire` concatène (`torch.cat`) les étiquettes et prédictions de tous les lots en deux vecteurs. `m.index_put_((y, p), 1, accumulate=True)` ajoute 1 dans la case (vraie classe, classe prédite) pour chaque image. Dans `metriques`, `m.sum(0)` additionne les colonnes (combien de fois chaque classe a été **prédite**), `m.sum(1)` les lignes (combien d'images de chaque **vraie** classe) ; `.clamp(min=1)` évite une division par zéro.
> - Partie 5 : un dossier `runs/<date>/` reçoit la configuration, l'historique, le meilleur modèle, la matrice de confusion et le rapport : tout ce qu'il faut pour rejouer l'expérience.

Lancement :

```bash
python projet_cifar10.py --epoques 1 --sous-ensemble 5000   # essai rapide : le pipeline fonctionne-t-il ?
python projet_cifar10.py --epoques 15                        # entraînement complet
python projet_cifar10.py --epoques 15 --graine 7             # deuxième graine pour mesurer la variabilité
```

Le réseau compte **288 746 paramètres** : trois étages de deux convolutions (32, 64 puis 128 canaux) avec normalisation par lot, suivis d'une moyenne globale (*global average pooling*) et d'une couche dense. Il combine AdamW, le calendrier `OneCycleLR` (échauffement puis décroissance, avancé à **chaque lot**) et le lissage des étiquettes (L126). Un réseau de cette famille dépasse couramment l'objectif de 80 % en une quinzaine d'époques ; mesurez votre propre résultat et reportez-le tel quel, avec la graine et la machine.

> 🔢 **Exemple à la main** — Un `bloc(c_in, c_out)` contient deux convolutions $3 \times 3$ sans biais ($c_{\text{in}} \times c_{\text{out}} \times 9$ puis $c_{\text{out}} \times c_{\text{out}} \times 9$) et deux normalisations par lot ($2 \times c_{\text{out}}$ chacune).
> 1. `bloc(3, 32)` : $864 + 64 + 9\,216 + 64 = 10\,208$.
> 2. `bloc(32, 64)` : $18\,432 + 128 + 36\,864 + 128 = 55\,552$.
> 3. `bloc(64, 128)` : $73\,728 + 256 + 147\,456 + 256 = 221\,696$.
> 4. Tête : $128 \times 10 + 10 = 1\,290$.
>
> Total : $10\,208 + 55\,552 + 221\,696 + 1\,290 = 288\,746$. Le dernier étage pèse à lui seul 77 % du réseau. (Vérifié en Python.)

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : dans ce script, OneCycleLR est défini en nombre total d'étapes (époques × lots), donc sched.step() doit être appelé après chaque lot et non une fois par époque.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. total_steps = epoques × len(dl_tr) : le calendrier compte des lots. Un appel par époque laisserait le taux bloqué en tout début d'échauffement pendant presque tout l'entraînement (piège de L126)."
}
```

> 💡 **À retenir** — La première exécution d'un projet n'est **pas** l'entraînement complet : c'est un essai d'une époque sur un sous-ensemble, pour vérifier que tout le pipeline (données, modèle, sauvegarde, rapport) fonctionne en deux minutes. Découvrir une faute de frappe dans `tracer_matrice` après trois heures d'entraînement est une expérience que l'on ne fait qu'une fois.

## 3. L'évaluation : au-delà de l'exactitude

### 3.1 Les métriques par classe

> 🧠 **L'intuition d'abord** — Pour chaque catégorie, deux questions : « quand le modèle crie *chat*, est-ce vraiment un chat ? » (**précision**) et « parmi tous les chats, combien a-t-il reconnus ? » (**rappel**). Le F1 résume les deux en un seul nombre qui reste bas si l'un des deux est mauvais. **Analogie :** un chien truffier. Précision : quand il gratte le sol, y a-t-il vraiment une truffe ? Rappel : sur toutes les truffes du terrain, combien en a-t-il trouvées ?

Pour chaque classe $c$, avec $\text{VP}_c$ les vrais positifs, $\text{FP}_c$ les faux positifs (images prédites $c$ à tort) et $\text{FN}_c$ les faux négatifs (images de $c$ manquées) :

$$\text{précision}_c = \frac{\text{VP}_c}{\text{VP}_c + \text{FP}_c}, \qquad \text{rappel}_c = \frac{\text{VP}_c}{\text{VP}_c + \text{FN}_c}, \qquad F_1 = \frac{2 \cdot \text{précision} \cdot \text{rappel}}{\text{précision} + \text{rappel}}$$

> 💡 **Autrement dit** — Faux positifs (FP) = fausses alertes ; faux négatifs (FN) = oublis. La précision pénalise les fausses alertes, le rappel les oublis. Le F1 est une moyenne « exigeante » (harmonique) : 1,0 de précision et 0,2 de rappel donnent un F1 de 0,33, pas 0,6.

> 🔢 **Exemple à la main** — Classe « chat », 1 000 vrais chats dans le test. Le modèle répond « chat » 850 fois, dont 680 à raison : $\text{VP} = 680$, $\text{FP} = 850 - 680 = 170$, $\text{FN} = 1\,000 - 680 = 320$. Précision $= 680/850 = 0{,}80$ ; rappel $= 680/1\,000 = 0{,}68$ ; $F_1 = 2 \times 0{,}80 \times 0{,}68/(0{,}80 + 0{,}68) \approx 0{,}735$. Ce rappel de 68 % passe juste au-dessus du seuil de 65 % fixé dans la fiche de cadrage. (Vérifié en Python.)

La **précision** répond à « quand le modèle dit chat, a-t-il raison ? » ; le **rappel**, à « parmi les chats, combien en trouve-t-il ? ». Le **F1 macro** est la moyenne simple des F1 des classes : il pèse autant les petites classes que les grandes, ce qui le rend précieux sur des données déséquilibrées (le cas de Leaffliction, ou de vos données réelles).

### 3.2 Lire une matrice de confusion

> 🧠 **L'intuition d'abord** — Une matrice de confusion est un **tableau de rangement** : en ligne, la vraie catégorie de la photo ; en colonne, la catégorie choisie par le modèle. Tout ce qui est sur la diagonale est bien rangé ; chaque case hors diagonale indique précisément **quel tiroir a été confondu avec quel autre**. **Analogie :** le relevé des erreurs d'un centre de tri postal : « 15 % des lettres pour Lyon 3e sont parties à Lyon 7e » vous dit exactement où réorganiser.

La fonction `matrice_confusion` du script range la vraie classe en **ligne** et la classe prédite en **colonne** (même convention que `sklearn.metrics.confusion_matrix`). La diagonale contient les bonnes réponses ; tout le reste est une erreur, avec son « adresse ». La figure est normalisée par ligne : chaque case donne la proportion des images d'une vraie classe envoyées vers chaque prédiction, et la diagonale est donc le rappel.

```
                 prédit →
vrai ↓       avion  auto  oiseau  chat  …  chien  …  camion
avion         0,88  0,01   0,03   0,01      0,00      0,02
automobile    0,01  0,92   0,00   0,00      0,00      0,05   ← confusion auto/camion
chat          0,01  0,00   0,04   0,68      0,15      0,01   ← la classe la plus difficile
chien         0,00  0,00   0,03   0,12      0,80      0,00
```

*(Valeurs illustratives : relevez les vôtres dans `matrice_confusion.png`.)*

```quiz
{
  "q": "Dans votre matrice normalisée par ligne, la case (vraie classe « automobile », prédite « camion ») vaut 0,12 et la case (vraie « camion », prédite « automobile ») vaut 0,03. Que pouvez-vous en déduire ?",
  "options": ["Les autos sont plus souvent prises pour des camions que l'inverse", "Le modèle confond les deux classes de façon parfaitement symétrique, à 12 %", "La précision de la classe camion vaut 0,88 (1 − 0,12)", "Il y a 12 automobiles mal classées dans tout le jeu de test"],
  "answer": 0,
  "explanation": "Normalisée par ligne, chaque case donne la part des images d'une vraie classe envoyées vers une prédiction. La confusion est ici asymétrique. La précision se lit par colonne, et on ne connaît pas les effectifs sans la matrice brute."
}
```

Sur CIFAR-10, les mêmes motifs reviennent presque toujours : **chat ↔ chien** (pelage, posture, 32 × 32 pixels), **automobile ↔ camion**, **avion ↔ bateau** (fond bleu uniforme), **cerf ↔ cheval**. Chaque motif suggère une action :

| Observation | Hypothèse | Action possible |
|---|---|---|
| Chat ↔ chien concentrent les erreurs | la résolution ne suffit pas | augmenter la résolution (données réelles), transfert depuis un ResNet pré-entraîné (L124) |
| Avion ↔ bateau | le modèle s'appuie sur le fond (ciel, mer) | augmentation de couleur, vérifier les exemples mal classés |
| Une classe a un rappel très bas | peu d'exemples ou étiquettes bruitées | collecter, nettoyer, pondérer la perte |
| Deux classes indiscernables même pour un humain | catégories mal définies | revoir la taxonomie avec le métier, éventuellement fusionner |

### 3.3 Regarder les erreurs

Les chiffres ne suffisent pas : **affichez les 30 images les plus mal classées** (celles où la probabilité de la vraie classe est la plus faible). On y découvre régulièrement des étiquettes fausses dans le jeu de données, des images ambiguës, ou un biais (toutes les erreurs « bateau » sont des photos prises de nuit). C'est l'étape qui distingue une analyse d'un simple compte rendu. Pour notre PME, c'est aussi là que se décide le **seuil de confiance** : en ne classant automatiquement que les images où la probabilité maximale dépasse, par exemple, 0,9, on abaisse fortement le taux d'erreur au prix d'une part d'images renvoyée aux modérateurs.

> 🔗 **Documentation officielle** — [scikit-learn : confusion_matrix](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html) (même convention lignes/colonnes, utile pour vérifier votre implémentation) et le tutoriel [Training a Classifier](https://pytorch.org/tutorials/beginner/blitz/cifar10_tutorial.html) de PyTorch, qui part du même jeu de données avec un réseau plus simple.

```mission
{
  "title": "Vérifiez la convention et la normalisation de confusion_matrix",
  "url": "https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html",
  "steps": ["Ouvrez la page de référence sklearn.metrics.confusion_matrix", "Lisez la phrase qui définit l'élément (i, j) et l'exemple du cas binaire", "Lisez la description du paramètre normalize"],
  "question": "Que représente l'élément (i, j) de la matrice, quelles valeurs accepte normalize, et laquelle correspond à la figure de cette leçon ?",
  "hint": "La figure de la leçon est normalisée « par ligne », c'est-à-dire sur les vraies classes.",
  "answer": "L'élément (i, j) est le nombre d'observations de vraie classe i prédites dans la classe j ; normalize accepte 'true' (sur les lignes, vraies classes), 'pred' (sur les colonnes) ou 'all' (sur l'ensemble), None par défaut. La figure de la leçon correspond à normalize='true'. Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Le rapport

Le script génère `rapport.md` avec les chiffres ; il vous reste à écrire l'analyse. Structure attendue (deux à quatre pages) :

1. **Contexte et cadrage** : la fiche de la section 1.2, dont la métrique et le seuil fixés à l'avance.
2. **Données** : source, licence, taille, répartition, protocole de séparation, augmentations.
3. **Modèle et entraînement** : architecture (nombre de paramètres), optimiseur, calendrier, régularisation, matériel, durée.
4. **Résultats** : courbes (perte d'entraînement, exactitude de validation), exactitude et F1 macro de test **moyennés sur au moins deux graines** (avec l'écart), tableau par classe, matrice de confusion.
5. **Analyse des erreurs** : les trois principales confusions, des exemples d'images mal classées, des hypothèses.
6. **Comparaison** : baseline MLP, votre CNN, et une variante (transfert depuis un ResNet-18 ou ablation d'une technique de L126).
7. **Limites et prochaines étapes** : ce que le modèle ne sait pas faire, risques en production (dérive des données, biais), données à collecter.
8. **Reproductibilité** : commande exacte, versions (`config.json`), graines, emplacement du meilleur modèle.

> 💡 **À retenir** — Un rapport utile répond à la question du commanditaire (« peut-on automatiser le tri, et à quelles conditions ? ») avant de décrire la technique. La première phrase doit contenir le résultat de test, le seuil visé et la recommandation.

```mission
{
  "title": "Rendre aussi le DataLoader reproductible",
  "url": "https://pytorch.org/docs/stable/notes/randomness.html",
  "steps": ["Ouvrez la page « Reproducibility » de la documentation PyTorch", "Lisez la section consacrée au DataLoader", "Repérez les deux arguments à passer au DataLoader et la fonction utilitaire proposée"],
  "question": "Quels arguments la documentation recommande-t-elle de passer au DataLoader pour que le mélange et les processus de chargement soient reproductibles ?",
  "hint": "L'un initialise chaque « worker », l'autre est un générateur aléatoire dont on fixe la graine.",
  "answer": "worker_init_fn=seed_worker (une petite fonction qui fixe numpy et random à partir de torch.initial_seed()) et generator=g, avec g = torch.Generator() et g.manual_seed(0). La page signale aussi torch.use_deterministic_algorithms(True) pour les opérations non déterministes. Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 5. La grille d'évaluation

Cette grille traduit les critères de la compétence **C4.3** du référentiel (« le modèle converge ; la rétropropagation est expliquée ; les résultats sont reproductibles »). Utilisez-la pour vous auto-évaluer avant de rendre.

| Critère | Points | Attendu pour la note maximale |
|---|---|---|
| Cadrage | 10 | fiche complète, métrique et seuil fixés avant l'entraînement, baseline chiffrée |
| Protocole de données | 15 | séparation train/validation/test correcte, test lu une seule fois, augmentation sur le train uniquement, normalisation justifiée |
| Modèle et entraînement | 20 | architecture justifiée (formes et paramètres calculés), convergence visible sur les courbes, choix d'optimiseur et de calendrier expliqués |
| Évaluation | 20 | exactitude, F1 macro, métriques par classe, matrice de confusion lue et commentée, seuil atteint ou écart expliqué |
| Analyse des erreurs | 10 | exemples d'erreurs affichés, au moins trois hypothèses argumentées, une action testée |
| Reproductibilité | 15 | graines fixées, configuration sauvegardée, deux graines au moins, commande unique pour tout refaire |
| Compréhension | 10 | à l'oral : expliquer la rétropropagation dans une convolution, le rôle de la normalisation par lot, le choix du calendrier |
| **Total** | **100** | **validation à 70 points**, dont au moins la moitié des points de chaque critère |

## 6. Variantes pour aller plus loin

- **Transfert d'apprentissage** : remplacez `ReseauCIFAR` par le ResNet-18 pré-entraîné de L124 (images agrandies à 224 × 224 ou première couche adaptée), comparez score, temps d'entraînement et taille du modèle.
- **Vos propres données** : rangez vos images dans `donnees/train/<classe>/` et utilisez `datasets.ImageFolder`. C'est le chemin du projet 42 **Leaffliction** (maladies des feuilles, plus de 90 % d'exactitude visés sur au moins 100 images de validation d'après les dépôts publics), et celui de la plupart des projets d'entreprise : pièces défectueuses, documents scannés, photos de chantier.
- **Équité et robustesse** : le Lab 2 de MIT 6.S191 2026 porte sur les biais d'un détecteur de visages. Mesurez vos performances par sous-groupe (luminosité, arrière-plan) et documentez les écarts.

## 🧪 Exercice pratique

**Consigne.** Réalisez le projet complet :
1. Remplissez la fiche de cadrage (section 1.2) **avant** tout entraînement et enregistrez-la dans `cadrage.md`.
2. Lancez l'essai rapide, puis deux entraînements complets avec deux graines différentes.
3. Ajoutez au script une fonction `pires_erreurs(modele, dl, n=30)` qui renvoie les images dont la probabilité de la vraie classe est la plus faible, et enregistrez-les dans une planche `erreurs.png`.
4. Entraînez une variante (transfert ResNet-18 **ou** ablation d'une technique de L126) et comparez.
5. Rédigez le rapport selon la section 4 et auto-évaluez-vous avec la grille de la section 5.

**Critères de réussite.** Exactitude de test $\ge 80\,\%$ (ou écart au seuil expliqué et chiffré) ; aucune classe sous 65 % de rappel, ou plan d'action argumenté ; deux graines rapportées avec leur écart ; rapport de deux à quatre pages qui commence par la recommandation ; auto-évaluation $\ge 70/100$.

<details><summary>Pistes de correction</summary>

- `pires_erreurs` : sous `torch.no_grad()`, calculez `p = torch.softmax(modele(xb), 1)`, puis `p_vraie = p[torch.arange(len(yb)), yb]` ; gardez les `n` plus petites valeurs avec `torch.topk(-p_vraie_totale, n)` et retrouvez les images via les indices. Pour l'affichage, « dé-normalisez » (`x * ect + moy`) avant `plt.imshow(x.permute(1, 2, 0))`.
- Si l'exactitude de validation plafonne nettement sous l'objectif : vérifiez que `sched.step()` est bien appelé à chaque lot, que `modele.train()` est rappelé à chaque époque, et que l'augmentation n'est pas appliquée à la validation.
- Écart entre deux graines supérieur à un point : c'est normal sur 15 époques ; rapportez la moyenne et l'écart, ne choisissez pas la meilleure graine.
- Pour le transfert, la normalisation doit redevenir celle d'ImageNet (L124).
</details>

## 🎮 Défi

Votre modèle atteint 85 % d'exactitude. En ne classant automatiquement que les images où la confiance dépasse 0,9, vous mesurez sur la validation 97 % d'exactitude sur 70 % des images. Sur 3 000 photos par jour, combien sont traitées automatiquement, combien d'erreurs automatiques par jour, et combien de photos restent aux modérateurs ? Réponse : 2 100 classées automatiquement, environ 63 erreurs ($3\,\%$ de 2 100), et 900 photos en revue humaine. C'est ce type de chiffre, et non « 85 % », que le commanditaire attend.

## ✅ Auto-évaluation express

1. Pourquoi l'augmentation de données ne doit-elle pas être appliquée au jeu de validation ?
2. Dans la matrice de confusion du script, que représente la case (ligne « chat », colonne « chien ») ?
3. Pourquoi rapporter les résultats de plusieurs graines plutôt que du meilleur entraînement ?

**Réponses.** 1. La validation doit estimer la performance sur des images réelles telles qu'elles arriveront en production ; des images transformées aléatoirement la rendraient bruitée et non comparable d'une époque à l'autre. 2. La proportion (ou le nombre) de vrais chats que le modèle a classés comme chiens. 3. Parce que le score varie d'une graine à l'autre ; ne garder que le meilleur revient à sur-ajuster sur le hasard et surestime la performance réelle.

## 📚 Pour aller plus loin
- [MIT 6.S191 Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 — séance 3 (vision) et présentations de projets finaux de l'édition 2026 ; Lab 2 sur les biais.
- [Stanford CS231n — programme Spring 2026](https://cs231n.stanford.edu/schedule.html) 🇬🇧 — l'ensemble du cours de référence en vision, de la classification à la détection et à la segmentation.
- [PyTorch — Training a Classifier](https://pytorch.org/tutorials/beginner/blitz/cifar10_tutorial.html) 🇬🇧 — le tutoriel officiel sur CIFAR-10.
- [scikit-learn — confusion_matrix](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html) 🇬🇧 — définition et conventions de la matrice de confusion.
- [Dépôt public Leaffliction](https://github.com/jainavas/leaffliction) 🇬🇧 — un projet 42 de classification d'images sur données réelles, déséquilibrées.
- [fast.ai — Practical Deep Learning for Coders](https://course.fast.ai/) 🇬🇧 — leçons 1 et 2 : de l'entraînement au déploiement d'un classifieur d'images.

> ✅ **Si vous ne retenez que 3 choses** — 1. Fixez la métrique et le seuil d'acceptation **avant** d'entraîner, séparez train / validation / test, n'augmentez que le train et ne lisez le test qu'une fois. 2. Lancez toujours un essai rapide (une époque, un sous-ensemble) avant l'entraînement complet, et sauvegardez configuration, graines, historique et meilleur modèle. 3. Évaluez au-delà de l'exactitude : précision, rappel et F1 par classe, matrice de confusion lue case par case, images mal classées, et résultats sur au moins deux graines.

> 🗺️ **Et maintenant ?** — Vous savez entraîner et évaluer un réseau de bout en bout ; le module M27 ouvre la boîte des Transformers, l'architecture fondée sur l'attention qui fait tourner tous les grands modèles de langage.
