---
module: M26
title: "Fiche mémo — Deep learning (inspiré MIT 6.S191)"
---
# Fiche mémo — M26 · Deep learning (inspiré MIT 6.S191)

> En une phrase : un réseau profond empile couches linéaires et non-linéarités, s'entraîne par rétropropagation en cinq gestes PyTorch, et converge grâce à la bonne architecture et aux bons réglages.

## Les 7 idées à retenir
1. Un perceptron trace une seule frontière linéaire (échec sur XOR) ; la couche cachée « plie » l'espace (`L121`).
2. Softmax + entropie croisée donnent le gradient $(P - Y)/B$ ; on soustrait toujours le max des logits (`L121`).
3. Rétropropager = « dérivée locale × gradient aval », et on **additionne** quand une valeur sert deux fois (`L122`).
4. Boucle PyTorch : passe avant, perte, `zero_grad`, `backward`, `step` ; `backward()` ne met rien à jour (`L123`).
5. Convolution = couche linéaire à poids partagés et connexions locales ; ResNet ($y = F(x) + x$) donne une autoroute au gradient (`L124`).
6. Le gradient du RNN s'évanouit ; le LSTM le sauve par une mise à jour additive ; l'attention supprime le calcul séquentiel (`L125`).
7. Projet : métrique et seuil figés avant l'entraînement, test lu une fois, deux graines au moins (`L127`).

## Le schéma à connaître
```mermaid
flowchart LR
  B["Lot xb, yb"] --> F["1. Passe avant : logits"]
  F --> L["2. Perte : CrossEntropyLoss"]
  L --> Z["3. zero_grad"]
  Z --> K["4. backward : gradients"]
  K --> S["5. step : mise à jour"]
  S -. "lot suivant" .-> B
```

## Les formules essentielles
| Formule | Intuition en mots simples |
|---|---|
| $Z^{[l]} = A^{[l-1]}W^{[l]} + b^{[l]},\ A^{[l]} = g(Z^{[l]})$ | Chaque couche fait un mélange pondéré, puis un filtre non linéaire. |
| $\partial\mathcal{L}/\partial Z^{[L]} = (P - Y)/B$ | Le signal d'erreur est simplement « prédit moins voulu ». |
| $n_{\text{sortie}} = \lfloor (n + 2p - k)/s \rfloor + 1$ | Le nombre de positions que la loupe peut occuper sur l'image. |
| $\text{param} = C_{\text{out}}(C_{\text{in}}k^2 + 1)$ | Chaque filtre a ses poids plus un biais, et on en a $C_{\text{out}}$. |
| $y = F(x) + x$ | Sortie = entrée + retouche : si le bloc n'apporte rien, il peut s'effacer. |
| $c_t = f_t \odot c_{t-1} + i_t \odot g_t$ | La mémoire du LSTM s'additionne au lieu de se multiplier : le gradient traverse. |
| $g \leftarrow g \cdot \min(1, \tau/\|g\|)$ | Limiteur de vitesse : même direction, longueur plafonnée. |
| $\text{Var}(w) = 2/n_{\text{in}}$ (He) | Plus une couche a d'entrées, plus ses poids de départ sont petits ; le 2 compense ReLU. |
| $\hat x = (x - \mu_{\text{lot}})/\sqrt{\sigma^2_{\text{lot}} + \varepsilon}$, $y = \gamma\hat x + \beta$ | BatchNorm recentre chaque canal, puis laisse le réseau réajuster l'échelle. |

## Vocabulaire express
| Terme | En clair |
|---|---|
| BPTT | Rétropropagation à travers le temps d'un RNN déroulé. |
| Transfert | Garder l'extracteur pré-entraîné, réentraîner la tête. |
| `bfloat16` | 16 bits avec la plage du `float32` : pas de `GradScaler`. |

## Les pièges classiques
- Sigmoïde dans les couches cachées : dérivée ≤ 0,25, le gradient s'évanouit.
- Oublier `modele.eval()` à l'évaluation (dropout, BatchNorm).
- `float64` NumPy contre `float32` PyTorch : `mat1 and mat2 must have the same dtype`.
- `nn.LSTM` sans `batch_first=True` attend $(T, B, d)$ : aucun message d'erreur.
- Augmenter les images avant la séparation train/validation.

## Les commandes / chiffres / dates utiles
```python
optimiseur.zero_grad(); perte.backward(); optimiseur.step()
torch.nn.utils.clip_grad_norm_(modele.parameters(), 1.0)   # entre backward et step
with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
    perte = critere(modele(xb), yb)
for p in modele.parameters(): p.requires_grad = False       # transfert : geler
modele.fc = nn.Linear(modele.fc.in_features, 4)              # nouvelle tête
```
- Perte initiale attendue en classification à $K$ classes : $\approx \ln K$ (2,30 pour 10).
- Adam/AdamW : 2 valeurs d'état par paramètre, soit 56 Go en `float32` pour 7 milliards.
- `Conv2d(32, 64, 3)` : 18 496 paramètres ; ResNet-18 : ~11,7 M, tête à 4 classes : 2 052.
- LSTM pour $d = H = 256$ : 526 336 paramètres ; GRU : ~25 % de moins.
- Sauvegarder le `state_dict()` ; `torch.load` d'un fichier inconnu seulement avec `weights_only=True`.
- Grille C4.3 sur 100 points, validation à 70.

## Pour aller plus loin
- [MIT 6.S191 Introduction to Deep Learning](https://introtodeeplearning.com/)
- [PyTorch — Learn the Basics](https://pytorch.org/tutorials/beginner/basics/intro.html)
- [Andrej Karpathy — Neural Networks: Zero to Hero](https://karpathy.ai/zero-to-hero.html)

## Auto-test (3 questions — réponses en bas de fiche)
1. Combien de paramètres pour `nn.Conv2d(1, 32, kernel_size=3, padding=1)` ?
2. Votre perte initiale à 10 classes vaut 9,0 : que vérifier ?
3. Pourquoi le LSTM retient-il le premier symbole à $T = 50$ alors que le RNN échoue ?

---
**Réponses.** 1. $32 \times (1 \cdot 9 + 1) = 320$. 2. Attendu ≈ 2,3 : dernière couche mal initialisée ou softmax appliquée deux fois. 3. Sa mémoire $c_t$ se met à jour par addition (porte d'oubli ouverte), alors que le gradient du RNN est un produit de jacobiennes qui s'évanouit.
