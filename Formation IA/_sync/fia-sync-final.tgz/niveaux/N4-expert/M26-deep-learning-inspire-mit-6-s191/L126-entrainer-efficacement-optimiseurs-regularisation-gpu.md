---
id: L126
module: M26
level: N4
title: "Entraîner efficacement : optimiseurs, régularisation, GPU"
minutes: 60
objectives:
  - "Expliquer et vérifier expérimentalement le rôle de l'initialisation (Xavier, He) sur la propagation du signal"
  - "Comparer SGD, momentum, Adam et AdamW et choisir un calendrier de taux d'apprentissage (échauffement, cosinus, OneCycle)"
  - "Appliquer les techniques de normalisation et de régularisation (BatchNorm, LayerNorm, dropout, weight decay, lissage des étiquettes, augmentation)"
  - "Accélérer un entraînement sur GPU (précision mixte, transferts, torch.compile) et déboguer méthodiquement un entraînement qui échoue"
skills: ["C4.3"]
sources:
  - { title: "Stanford CS231n Spring 2026 — Lecture 3 : Regularization and optimization", url: "https://cs231n.stanford.edu/schedule.html", lang: "en" }
  - { title: "MIT 6.S191 (2026) — Lecture 1 et Lecture 9 : Massively Parallel Training", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "PyTorch — torch.optim", url: "https://pytorch.org/docs/stable/optim.html", lang: "en" }
  - { title: "PyTorch — Automatic Mixed Precision (torch.amp)", url: "https://pytorch.org/docs/stable/amp.html", lang: "en" }
  - { title: "PyTorch — torch.nn.init", url: "https://pytorch.org/docs/stable/nn.init.html", lang: "en" }
  - { title: "Kingma, Ba (2014) — Adam: A Method for Stochastic Optimization", url: "https://arxiv.org/abs/1412.6980", lang: "en" }
  - { title: "Loshchilov, Hutter (2017) — Decoupled Weight Decay Regularization (AdamW)", url: "https://arxiv.org/abs/1711.05101", lang: "en" }
  - { title: "Ioffe, Szegedy (2015) — Batch Normalization", url: "https://arxiv.org/abs/1502.03167", lang: "en" }
---

# Entraîner efficacement : optimiseurs, régularisation, GPU

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 26

## 🎯 Ce que vous saurez faire
- Choisir une initialisation adaptée à l'activation et le démontrer par une mesure.
- Écrire les règles de mise à jour de SGD, du momentum et d'Adam, et savoir pourquoi AdamW est l'optimiseur par défaut en 2026.
- Régler un taux d'apprentissage et un calendrier (échauffement puis décroissance cosinus).
- Placer correctement normalisation, dropout et décroissance des poids, et activer la précision mixte sur GPU.
- Suivre une procédure de débogage en cinq vérifications quand « ça n'apprend pas ».

> 🧭 **En clair** — Avoir une bonne recette ne suffit pas : il faut aussi savoir cuisiner. Entraîner un réseau, c'est régler une série de « boutons » : comment répartir les poids au départ (l'initialisation, comme accorder un instrument avant le concert), quel pilote automatique utiliser pour descendre la pente de l'erreur (l'optimiseur), à quelle vitesse et avec quels freins (le taux d'apprentissage et son calendrier), quelles **ceintures de sécurité contre l'apprentissage par cœur** boucler (la régularisation), et comment faire travailler la carte graphique à plein régime. Cette leçon donne les réglages qui marchent dans la plupart des cas, et une méthode pour trouver la panne quand « ça n'apprend pas ».

On dit souvent que le deep learning est autant un artisanat qu'une science : à architecture égale, deux équipes obtiennent des résultats très différents selon leurs réglages. Cette leçon rassemble les savoir-faire couverts par la séance 3 de CS231n (régularisation et optimisation), les leçons 17 à 20 de fast.ai partie 2 (initialisation, SGD accéléré, dropout, précision mixte) et la séance 9 de MIT 6.S191 2026 sur l'entraînement massivement parallèle.

## 1. L'initialisation : bien démarrer

### 1.1 Le problème

Chaque couche multiplie son entrée par une matrice. Si les poids sont trop petits, l'écart type des activations **rétrécit** à chaque couche ; trop grands, il **explose**. Après vingt couches, le signal (et donc le gradient, qui fait le chemin inverse) a disparu ou saturé. C'est la cousine du gradient qui s'évanouit des RNN (L125), mais dans la profondeur plutôt que dans le temps.

> 🧠 **L'intuition d'abord** — Un signal qui traverse vingt couches est comme un **son qui traverse vingt amplificateurs** branchés à la suite : si chacun baisse un peu le volume, on n'entend plus rien à la fin ; si chacun le monte un peu, ça sature. L'initialisation choisit le réglage de départ de chaque amplificateur pour que le volume reste à peu près constant.

L'idée de Xavier Glorot et Yoshua Bengio (2010) : choisir la variance des poids pour que la variance des activations **reste constante** d'une couche à l'autre. Pour une couche à $n_{\text{in}}$ entrées :

| Schéma | Variance des poids | Pour quelle activation |
|---|---|---|
| Xavier / Glorot (2010) | $\dfrac{2}{n_{\text{in}} + n_{\text{out}}}$ | tanh, sigmoïde (symétriques) |
| He / Kaiming (2015) | $\dfrac{2}{n_{\text{in}}}$ | ReLU et variantes (la moitié des neurones sont à zéro, d'où le facteur 2) |
| Défaut de `nn.Linear` | uniforme sur $\pm 1/\sqrt{n_{\text{in}}}$ | compromis raisonnable pour les petits réseaux |

> 💡 **Autrement dit** — Plus une couche reçoit d'entrées, plus ses poids de départ doivent être **petits**, pour que la somme ne grossisse pas. D'où la division par $n_{\text{in}}$. Le facteur 2 de He compense le fait que ReLU met à zéro, en moyenne, la moitié des signaux.

> 🔢 **Exemple à la main** — Couche $512 \to 512$ ($n_{\text{in}} = n_{\text{out}} = 512$) :
> 1. He : variance $2/512 \approx 0{,}0039$, donc écart-type $\sqrt{0{,}0039} = 0{,}0625$.
> 2. Xavier : variance $2/(512 + 512) \approx 0{,}00195$, écart-type $\approx 0{,}044$.
> 3. Défaut de `nn.Linear` : tirages uniformes entre $-1/\sqrt{512} \approx -0{,}044$ et $+0{,}044$.
>
> Le réglage « $\mathcal N(0, 1)$ » du tableau suivant tire des poids d'écart-type 1, soit **16 fois** trop grands par rapport à He : sur 20 couches, l'écart se multiplie. (Vérifié en Python.)

C'est l'initialisation de He que vous avez utilisée dans le MLP NumPy de L121 : `rng.normal(0, np.sqrt(2 / n_in), …)`.

### 1.2 La mesure

```python
"""initialisation.py — l'écart type des activations à travers 20 couches ReLU."""
import torch
from torch import nn

torch.manual_seed(0)
x0 = torch.randn(1024, 512)

def profil(init):
    x, ecarts = x0, []
    for _ in range(20):
        couche = nn.Linear(512, 512, bias=False)
        init(couche.weight)
        x = torch.relu(couche(x))
        ecarts.append(x.std().item())
    return ecarts

schemas = {
    "N(0, 0,01²)":     lambda w: nn.init.normal_(w, std=0.01),
    "N(0, 1)":         lambda w: nn.init.normal_(w, std=1.0),
    "Xavier (Glorot)": nn.init.xavier_normal_,
    "He (Kaiming)":    lambda w: nn.init.kaiming_normal_(w, nonlinearity="relu"),
}
for nom, init in schemas.items():
    e = profil(init)
    print(f"{nom:16s} | couche 1 : {e[0]:.2e} | couche 10 : {e[9]:.2e} | couche 20 : {e[19]:.2e}")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `x0` a la forme `(1024, 512)` : 1 024 exemples de 512 nombres. À chaque tour, on crée une couche `nn.Linear(512, 512, bias=False)` (poids `(512, 512)`), on l'initialise avec le schéma testé, puis `x = torch.relu(couche(x))` garde la forme `(1024, 512)`. `x.std().item()` mesure l'écart-type de **toutes** les activations de la couche. Les fonctions `nn.init.normal_`, `kaiming_normal_`, etc. se terminent par un tiret bas : convention PyTorch pour « modifie le tenseur **sur place** ».

| Initialisation | Couche 1 | Couche 10 | Couche 20 | Diagnostic |
|---|---|---|---|---|
| $\mathcal N(0, 0{,}01^2)$ | $1{,}3 \cdot 10^{-1}$ | $8{,}9 \cdot 10^{-9}$ | $9{,}7 \cdot 10^{-17}$ | le signal s'éteint |
| $\mathcal N(0, 1)$ | $1{,}3 \cdot 10^{1}$ | $8{,}2 \cdot 10^{11}$ | $1{,}3 \cdot 10^{24}$ | le signal explose |
| Xavier | $5{,}8 \cdot 10^{-1}$ | $2{,}5 \cdot 10^{-2}$ | $1{,}1 \cdot 10^{-3}$ | lente érosion (Xavier n'est pas conçue pour ReLU) |
| He | $8{,}3 \cdot 10^{-1}$ | $7{,}3 \cdot 10^{-1}$ | $6{,}1 \cdot 10^{-1}$ | **stable** |

> 💡 **À retenir** — L'initialisation n'est pas un détail : c'est elle qui décide si le premier gradient a une chance d'atteindre les premières couches. ReLU → He ; tanh → Xavier. Avec des normalisations (section 3) et des connexions résiduelles (L124), le réseau devient beaucoup plus tolérant, ce qui explique pourquoi les Transformers modernes s'entraînent avec des initialisations simples.

```mission
{
  "title": "Le piège de la valeur par défaut de kaiming_normal_",
  "url": "https://pytorch.org/docs/stable/nn.init.html",
  "steps": ["Ouvrez la page torch.nn.init de la documentation PyTorch", "Repérez la fonction torch.nn.init.kaiming_normal_ et lisez sa signature", "Repérez aussi la fonction calculate_gain et son tableau de gains recommandés"],
  "question": "Quelle est la valeur par défaut du paramètre nonlinearity de kaiming_normal_, et quel gain calculate_gain recommande-t-il pour ReLU ?",
  "hint": "La valeur par défaut n'est pas 'relu' : c'est sa variante « qui fuit ». Le gain de ReLU est une racine carrée.",
  "answer": "nonlinearity='leaky_relu' par défaut (avec a=0, ce qui revient au même gain que ReLU), mode='fan_in' ; calculate_gain('relu') = √2, d'où la variance 2/n_in. Le script de la section 1.2 passe nonlinearity='relu' explicitement, par clarté. Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 2. Les optimiseurs

### 2.1 De SGD à Adam

Notons $g_t = \nabla_\theta \mathcal L$ le gradient calculé sur le lot courant et $\eta$ le taux d'apprentissage.

**SGD** (descente de gradient stochastique, vue en M24) : $\theta \leftarrow \theta - \eta\, g_t$. Simple, mais lent dans les « ravins » où la pente est forte dans une direction et faible dans l'autre : il zigzague.

> 🧠 **L'intuition d'abord** — Les optimiseurs sont des **pilotes automatiques** pour la descente de la pente d'erreur. SGD est un randonneur dans le brouillard qui fait un pas dans la direction de la pente ; le momentum lui donne de l'élan, comme une bille qui roule ; Adam ajuste en plus la longueur du pas **pour chaque paramètre**, prudent là où le terrain est chaotique, plus audacieux là où il est régulier. **Analogie :** SGD, c'est conduire en regardant uniquement le mètre de route devant soi ; Adam, c'est un régulateur adaptatif qui tient compte des virages récents et du revêtement.

**Momentum** : on accumule une vitesse, comme une bille qui dévale une pente et garde son élan.

$$v_t = \beta\, v_{t-1} + g_t, \qquad \theta \leftarrow \theta - \eta\, v_t \qquad (\beta \approx 0{,}9)$$

Les oscillations s'annulent, les directions constantes s'accélèrent.

> 💡 **Autrement dit** — $v_t$ est une moyenne glissante des pentes récentes : 90 % de l'ancienne vitesse plus la nouvelle pente. Ce qui va toujours dans le même sens s'additionne ; ce qui change de sens à chaque pas se compense.

**Adam** (Kingma et Ba, 2014) combine le momentum et un taux **adapté à chaque paramètre**, divisé par la racine de la moyenne des carrés des gradients récents :

$$m_t = \beta_1 m_{t-1} + (1-\beta_1)\, g_t, \qquad v_t = \beta_2 v_{t-1} + (1-\beta_2)\, g_t^2$$

$$\hat m_t = \frac{m_t}{1 - \beta_1^t}, \quad \hat v_t = \frac{v_t}{1 - \beta_2^t}, \qquad \theta \leftarrow \theta - \eta\, \frac{\hat m_t}{\sqrt{\hat v_t} + \varepsilon}$$

avec par défaut $\beta_1 = 0{,}9$, $\beta_2 = 0{,}999$, $\varepsilon = 10^{-8}$. Les termes $\hat m, \hat v$ corrigent le biais vers zéro des premières itérations. Un paramètre rarement mis à jour (un mot rare dans un plongement) reçoit des pas plus grands ; un paramètre aux gradients bruités, des pas plus prudents.

> 🧭 **Pré-requis express** — Mêmes notations qu'en L114 : **$g_t$** est le gradient au pas $t$, **$g_t^2$** son carré case par case, **$\beta_1^t$** une puissance ($0{,}9^1 = 0{,}9$, $0{,}9^{20} \approx 0{,}12$), **$\varepsilon$** un minuscule nombre anti-division par zéro et **$\hat m$** (« m chapeau ») la version corrigée de $m$. Au premier pas, $\hat m_1 = g_1$ et $\hat v_1 = g_1^2$, donc le pas vaut exactement $\eta$ dans la direction opposée au gradient (calcul détaillé en L114). Dans AdamW, **$\lambda$** est le coefficient de décroissance des poids.

> 💡 **Autrement dit** — $m$ : « dans quelle direction vais-je en moyenne ? » ; $v$ : « quelle est la taille habituelle de mes pentes ? ». Le pas final divise l'un par la racine de l'autre : un paramètre aux pentes toujours énormes fait des pas modérés, un paramètre aux pentes minuscules n'est pas oublié.

**AdamW** (Loshchilov et Hutter, 2017) corrige un défaut subtil : dans Adam, la pénalité $L_2$ ajoutée au gradient est elle aussi divisée par $\sqrt{\hat v}$, ce qui affaiblit la régularisation des paramètres à grands gradients. AdamW **découple** la décroissance des poids : $\theta \leftarrow \theta - \eta\left(\frac{\hat m}{\sqrt{\hat v} + \varepsilon} + \lambda\,\theta\right)$. C'est l'optimiseur par défaut de la plupart des entraînements de Transformers.

```quiz
{
  "q": "Pourquoi AdamW est-il préféré à « Adam + pénalité L2 » pour entraîner un Transformer ?",
  "options": ["Sa décroissance des poids n'est pas divisée par √v̂", "Parce qu'il consomme deux fois moins de mémoire GPU qu'Adam", "Parce qu'il n'a pas besoin de taux d'apprentissage", "Parce qu'il remplace le momentum par du dropout, plus stable"],
  "answer": 0,
  "explanation": "Dans Adam + L2, la pénalité passe par la normalisation adaptative : les paramètres à grands gradients sont moins régularisés. AdamW découple la décroissance des poids. La mémoire est la même (deux moments par paramètre)."
}
```

| Optimiseur | Mémoire d'état par paramètre | Points forts | Usage typique |
|---|---|---|---|
| SGD + momentum | 1 valeur | généralise très bien, peu de mémoire | CNN de vision avec un calendrier soigné |
| Adam | 2 valeurs | robuste, peu sensible au réglage | prototypage, RNN |
| AdamW | 2 valeurs | idem + régularisation correcte | Transformers, LLM, choix par défaut |

Les deux valeurs d'état d'Adam ont un coût : pour un modèle de 7 milliards de paramètres, elles occupent à elles seules 56 Go en `float32`. C'est une des raisons pour lesquelles l'ajustement fin de LLM recourt à LoRA (M28).

### 2.2 Le taux d'apprentissage et son calendrier

> 🧠 **L'intuition d'abord** — Le calendrier du taux d'apprentissage est un **programme de vitesse** : démarrage doux (échauffement, le temps que les mesures d'Adam se stabilisent), vitesse de croisière, puis ralentissement progressif pour se garer précisément au fond de la vallée. **Analogie :** un avion. Roulage lent, décollage et croisière à pleine vitesse, puis longue descente en douceur avant l'atterrissage.

Le taux d'apprentissage est **l'hyperparamètre le plus important**. Trop grand, la perte oscille ou diverge ; trop petit, l'entraînement s'éternise ou s'enlise. Deux pratiques dominent :

- **Échauffement** (*warmup*) : on part d'un taux quasi nul et l'on monte linéairement pendant les premiers pour cent des étapes. Au début, les estimations de $\hat v$ d'Adam sont peu fiables et les normalisations ne sont pas stabilisées ; un grand pas immédiat peut tout casser.
- **Décroissance cosinus** : ensuite, le taux descend suivant une demi-période de cosinus jusqu'à près de zéro. Les derniers petits pas affinent la solution.

`OneCycleLR` de PyTorch (popularisé par fast.ai) combine les deux en un seul calendrier. Pour trouver l'ordre de grandeur du taux maximal, le **test de plage** (*LR range test*) fait croître le taux exponentiellement sur quelques centaines de lots et note la perte : on retient une valeur environ dix fois plus petite que celle où la perte commence à remonter.

> ⚠️ **Piège fréquent** — Appeler `scheduler.step()` une fois par **époque** alors que le calendrier a été défini en nombre d'**étapes** (ou l'inverse). Le taux reste bloqué en phase d'échauffement, ou s'effondre en une époque. Affichez `scheduler.get_last_lr()` à chaque époque pendant les premiers essais.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : l'échauffement (warmup) consiste à commencer l'entraînement avec un taux d'apprentissage très élevé pour sortir rapidement de l'initialisation aléatoire.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux : c'est l'inverse. On part d'un taux quasi nul et on le fait monter progressivement, car au début les estimations d'Adam et les normalisations ne sont pas fiables ; un grand pas immédiat peut déstabiliser durablement l'entraînement."
}
```

## 3. Normaliser et régulariser

### 3.1 Les normalisations

> 🧠 **L'intuition d'abord** — Normaliser, c'est **remettre les compteurs au même niveau** à chaque couche : on recentre les valeurs autour de 0 et on les ramène à une dispersion de 1, puis on laisse le réseau réajuster lui-même l'échelle s'il en a besoin ($\gamma$, $\beta$). **Analogie :** un professeur qui harmonise les notes de plusieurs correcteurs plus ou moins sévères avant de les additionner. BatchNorm harmonise à l'échelle d'un paquet de copies (le lot) ; LayerNorm, copie par copie.

**BatchNorm** (Ioffe et Szegedy, 2015) normalise chaque canal en utilisant la moyenne et la variance **du lot**, puis applique un facteur d'échelle $\gamma$ et un décalage $\beta$ appris :

$$\hat x = \frac{x - \mu_{\text{lot}}}{\sqrt{\sigma^2_{\text{lot}} + \varepsilon}}, \qquad y = \gamma\,\hat x + \beta$$

> 💡 **Autrement dit** — $\hat x$ = « combien d'écarts-types au-dessus ou en dessous de la moyenne du lot ». $\gamma$ et $\beta$ sont deux boutons appris qui permettent de redonner l'échelle et le décalage qui conviennent à la couche suivante.

> 🔢 **Exemple à la main** — Un canal vaut $(2, 4, 6, 8)$ sur un lot de 4 exemples.
> 1. $\mu_{\text{lot}} = 5$ ; $\sigma^2_{\text{lot}} = (9 + 1 + 1 + 9)/4 = 5$ ; $\sqrt{5} \approx 2{,}236$.
> 2. $\hat x = (2 - 5)/2{,}236 \approx -1{,}34$ ; puis $-0{,}45$ ; $0{,}45$ ; $1{,}34$ (moyenne 0, écart-type 1).
> 3. Avec $\gamma = 2$ et $\beta = 1$ appris : $y = 2\hat x + 1 \approx (-1{,}68 ;\ 0{,}11 ;\ 1{,}89 ;\ 3{,}68)$.
>
> ($\varepsilon$ est négligé ici ; il évite de diviser par 0 si toutes les valeurs du lot sont égales.) (Vérifié en NumPy.)

En évaluation, elle utilise des moyennes mobiles accumulées pendant l'entraînement : c'est pourquoi `modele.eval()` est indispensable (L123). Elle accélère fortement les CNN, mais se comporte mal avec de très petits lots.

**LayerNorm** (Ba, Kiros et Hinton, 2016) normalise sur les **variables de chaque exemple**, indépendamment du lot. Elle se comporte de la même façon à l'entraînement et en évaluation, ce qui en fait la normalisation des Transformers (et sa variante RMSNorm, dans la plupart des LLM récents).

### 3.2 Les régularisations

| Technique | Principe | Réglage de départ | Où |
|---|---|---|---|
| Décroissance des poids (*weight decay*) | ramène les poids vers 0 (a priori gaussien, M25 L116) | 0,01 à 0,1 avec AdamW, **pas** sur les biais ni les normalisations | partout |
| Dropout (Srivastava, Hinton et al., 2014) | met à zéro une fraction $p$ des activations à l'entraînement, et multiplie les autres par $1/(1-p)$ ; désactivé en évaluation | 0,1 à 0,5 | couches denses, Transformers |
| Augmentation de données | crée des variantes réalistes des exemples (L124) | dépend du domaine | vision, audio |
| Lissage des étiquettes (*label smoothing*) | cible 0,9 pour la bonne classe au lieu de 1 et répartit 0,1 sur les autres | 0,05 à 0,1 | classification |
| Arrêt anticipé | garder les poids de la meilleure validation (L121) | patience de 5 à 20 époques | partout |

> 🔢 **Exemple à la main** — Dropout avec $p = 0{,}5$ sur les activations $(2, 4, 6, 8)$ : un tirage au hasard éteint par exemple la 2e et la 4e, et les survivantes sont multipliées par $1/(1 - 0{,}5) = 2$, d'où $(4, 0, 12, 0)$. En moyenne sur beaucoup de tirages, chaque activation garde sa valeur d'origine (la moitié du temps 0, la moitié du temps le double) ; en évaluation, on garde simplement $(2, 4, 6, 8)$. Lissage des étiquettes à 0,1 sur 10 classes : la cible devient 0,9 pour la bonne classe et $0{,}1/9 \approx 0{,}011$ pour chacune des autres (dans la variante décrite dans le tableau).

> 🧠 **L'intuition d'abord** — Toutes ces techniques sont des **ceintures de sécurité contre l'apprentissage par cœur**. Le dropout, par exemple, « endort » au hasard une partie des neurones à chaque lot : le réseau ne peut compter sur aucun neurone en particulier et doit répartir son savoir. **Analogie :** une équipe dont un membre au hasard est absent chaque jour. Elle apprend à documenter et partager ses connaissances, et devient plus robuste qu'une équipe qui dépend d'une seule « star ».

> 💡 **À retenir** — Ordre de priorité face au sur-apprentissage : (1) plus de données ou d'augmentation, (2) décroissance des poids et arrêt anticipé, (3) dropout, (4) réduire le modèle. Réduire le modèle en premier est souvent une erreur en deep learning : un grand modèle bien régularisé généralise mieux qu'un petit.

## 4. Aller vite : GPU et précision mixte

### 4.1 La précision mixte

> 🧠 **L'intuition d'abord** — Calculer en 16 bits, c'est **écrire les nombres avec moins de chiffres** : on va deux fois plus vite et on prend deux fois moins de place, au prix d'un peu de précision. On garde l'original précis (32 bits) pour ce qui compte vraiment. **Analogie :** un architecte qui fait ses esquisses au crayon gras (rapide, approximatif) mais garde le plan coté au millimètre pour la construction.

Un `float32` occupe 4 octets ; un `bfloat16` ou un `float16`, 2. Les cœurs spécialisés des GPU récents (Tensor Cores chez NVIDIA) calculent bien plus vite en 16 bits. La **précision mixte** exécute les produits matriciels en 16 bits et garde en 32 bits ce qui est sensible (poids maîtres, accumulations, pertes) :

| Format | Bits d'exposant / de mantisse | Plage | Remarque |
|---|---|---|---|
| `float32` | 8 / 23 | $\approx 10^{\pm 38}$ | référence |
| `float16` | 5 / 10 | max ≈ 65 504 | petits gradients arrondis à zéro : il faut un `GradScaler` qui multiplie la perte avant `backward` |
| `bfloat16` | 8 / 7 | comme `float32` | moins précis mais même plage : pas besoin de `GradScaler` ; format standard d'entraînement des LLM sur GPU récents |

Dans PyTorch, deux lignes suffisent : `with torch.autocast(device_type="cuda", dtype=torch.bfloat16):` autour de la passe avant et de la perte, et, en `float16` seulement, un `torch.amp.GradScaler`. Gain typique sur GPU récent : jusqu'à 2 à 3 fois plus rapide et deux fois moins de mémoire d'activations.

> 💡 **Autrement dit** — `float16` a une plage étroite : les tout petits gradients sont arrondis à zéro. Le `GradScaler` multiplie temporairement la perte (et donc les gradients) pour les garder visibles, puis divise avant la mise à jour. `bfloat16` a la même plage que `float32`, il n'en a pas besoin.

> 🔢 **Exemple à la main** — En `float16`, un gradient de $10^{-8}$ devient exactement **0** (trop petit pour la plage), et $70\,000$ devient `inf` (au-delà du maximum 65 504). Multiplié par $1\,024$ par le `GradScaler`, le même gradient vaut $\approx 1{,}0 \times 10^{-5}$ et reste représentable ; on redivise par 1 024 en 32 bits avant la mise à jour. Côté mémoire : 7 milliards de poids occupent $7 \times 10^9 \times 4 = 28$ Go en `float32` et $14$ Go en 16 bits. (Vérifié avec `np.float16`.)

```mission
{
  "title": "Pourquoi PyTorch recommande-t-il le « gradient scaling » ?",
  "url": "https://pytorch.org/docs/stable/amp.html",
  "steps": ["Ouvrez la page « Automatic Mixed Precision package - torch.amp »", "Allez à la section « Gradient Scaling »", "Lisez le paragraphe qui explique le problème des petites valeurs de gradient"],
  "question": "Quel problème le gradient scaling résout-il en float16, et comment le GradScaler procède-t-il ?",
  "hint": "Le mot-clé anglais est « underflow ».",
  "answer": "En float16, des gradients de faible amplitude peuvent « underflow », c'est-à-dire être arrondis à zéro, et ne plus mettre à jour les paramètres ; le GradScaler multiplie la perte par un facteur d'échelle avant backward, puis « désécale » les gradients avant optimizer.step() et ajuste dynamiquement le facteur (il saute l'étape si des inf/nan apparaissent). Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

### 4.2 Les autres leviers

- **Le chargement des données** est souvent le vrai goulot : `num_workers > 0`, `pin_memory=True` et `xb.to(device, non_blocking=True)`. Si le GPU est utilisé à 30 % dans `nvidia-smi`, c'est que le CPU ne suit pas.
- **`torch.compile(modele)`** (PyTorch 2.x) fusionne les opérations en noyaux optimisés ; le premier lot est lent (compilation), les suivants nettement plus rapides.
- **Taille de lot** : la plus grande qui tient en mémoire n'est pas toujours la meilleure ; si vous la multipliez par $k$, augmentez le taux d'apprentissage (règle empirique : de $\sqrt{k}$ à $k$) et refaites un test de plage.
- **Accumulation de gradients** : pour simuler un lot de 512 avec une mémoire de 128, faites quatre `backward()` avant un `step()` (en divisant la perte par 4). Les gradients s'accumulent, souvenez-vous de L122.
- **Plusieurs GPU** : `torch.nn.parallel.DistributedDataParallel` (une copie du modèle par GPU, gradients moyennés), puis FSDP pour découper le modèle lui-même. C'est le sujet de la séance 9 de MIT 6.S191 et de M29.

> 🔗 **Documentation officielle** — [Automatic Mixed Precision (torch.amp)](https://pytorch.org/docs/stable/amp.html) pour `autocast` et `GradScaler` ; [torch.optim](https://pytorch.org/docs/stable/optim.html) pour les optimiseurs et la section « How to adjust learning rate » sur les calendriers.

## 5. Une boucle d'entraînement de production, avec ses garde-fous

Ce script rassemble toute la leçon. Il utilise des données synthétiques (étiquettes produites par un réseau « professeur » caché) pour tourner partout, sans téléchargement, en une à deux minutes sur CPU.

```python
"""recette.py — une boucle d'entraînement « de production » : AdamW, warmup + cosinus,
écrêtage, précision mixte, vérifications de débogage. Données synthétiques : tourne partout."""
import math
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

torch.manual_seed(0)
device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"

# ---------- Données synthétiques : 10 classes, 64 variables, frontières non linéaires ----------
N, D, K = 20_000, 64, 10
X = torch.randn(N, D)
professeur = nn.Sequential(nn.Linear(D, 32), nn.Tanh(), nn.Linear(32, K))   # « vérité » cachée
with torch.no_grad():
    y = professeur(X).argmax(1)                     # étiquettes déterministes (aucun bruit)
ds_train = TensorDataset(X[:16_000], y[:16_000])
ds_valid = TensorDataset(X[16_000:], y[16_000:])
dl_train = DataLoader(ds_train, batch_size=256, shuffle=True)
dl_valid = DataLoader(ds_valid, batch_size=1024)

def creer_modele(p_dropout=0.1):
    return nn.Sequential(
        nn.Linear(D, 256), nn.LayerNorm(256), nn.GELU(), nn.Dropout(p_dropout),
        nn.Linear(256, 256), nn.LayerNorm(256), nn.GELU(), nn.Dropout(p_dropout),
        nn.Linear(256, K),
    ).to(device)

# ---------- Vérification n°1 : la perte initiale doit valoir environ ln(K) ----------
modele = creer_modele()
with torch.no_grad():
    p0 = nn.functional.cross_entropy(modele(X[:1024].to(device)), y[:1024].to(device)).item()
print(f"perte initiale {p0:.3f} (attendu ≈ ln({K}) = {math.log(K):.3f})")

# ---------- Vérification n°2 : le modèle doit pouvoir sur-apprendre UN lot ----------
xb, yb = next(iter(dl_train))
xb, yb = xb[:32].to(device), yb[:32].to(device)
m_test = creer_modele(p_dropout=0.0)
opt_test = torch.optim.AdamW(m_test.parameters(), lr=1e-3)
for _ in range(300):
    perte = nn.functional.cross_entropy(m_test(xb), yb)
    opt_test.zero_grad(); perte.backward(); opt_test.step()
print(f"sur-apprentissage d'un lot de 32 : perte {perte.item():.4f} (doit tendre vers 0)")

# ---------- Entraînement complet ----------
EPOQUES = 12
etapes_totales = EPOQUES * len(dl_train)
echauffement = int(0.05 * etapes_totales)
# AdamW : on n'applique pas la décroissance de poids aux biais ni aux normalisations
decay = [p for n, p in modele.named_parameters() if p.ndim >= 2]
no_decay = [p for n, p in modele.named_parameters() if p.ndim < 2]
optimiseur = torch.optim.AdamW([{"params": decay, "weight_decay": 0.05},
                                {"params": no_decay, "weight_decay": 0.0}], lr=3e-3, betas=(0.9, 0.999))

def facteur_lr(etape):                               # warmup linéaire puis décroissance cosinus
    if etape < echauffement:
        return (etape + 1) / echauffement
    progres = (etape - echauffement) / max(1, etapes_totales - echauffement)
    return 0.5 * (1 + math.cos(math.pi * progres))
planificateur = torch.optim.lr_scheduler.LambdaLR(optimiseur, facteur_lr)

# Précision mixte, activée sur GPU NVIDIA seulement (sur CPU, bfloat16 est possible mais souvent plus lent) :
# bfloat16 si la carte le permet (Ampere et plus récentes), sinon float16 + GradScaler
amp_actif = device == "cuda"
type_amp = torch.bfloat16 if amp_actif and torch.cuda.is_bf16_supported() else torch.float16
scaler = torch.amp.GradScaler(enabled=amp_actif and type_amp == torch.float16)
critere = nn.CrossEntropyLoss(label_smoothing=0.05)

for epoque in range(1, EPOQUES + 1):
    modele.train()
    for xb, yb in dl_train:
        xb, yb = xb.to(device), yb.to(device)
        with torch.autocast(device_type=device, dtype=type_amp, enabled=amp_actif):
            perte = critere(modele(xb), yb)
        if not torch.isfinite(perte):                     # vérification n°3 : arrêt immédiat si nan/inf
            raise RuntimeError("perte non finie : baissez le taux d'apprentissage")
        optimiseur.zero_grad(set_to_none=True)
        scaler.scale(perte).backward()
        scaler.unscale_(optimiseur)                       # pour écrêter les vrais gradients
        norme = nn.utils.clip_grad_norm_(modele.parameters(), max_norm=1.0)
        scaler.step(optimiseur)
        scaler.update()
        planificateur.step()                              # calendrier défini en ÉTAPES
    modele.eval()
    with torch.no_grad():
        justes = sum((modele(xv.to(device)).argmax(1) == yv.to(device)).sum().item() for xv, yv in dl_valid)
    if epoque % 3 == 0 or epoque == 1:
        print(f"époque {epoque:2d} | lr {planificateur.get_last_lr()[0]:.2e} | "
              f"norme grad {norme:.2f} | exactitude valid {justes / len(ds_valid):.1%}")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - Données : `X` `(20000, 64)` ; un petit réseau « professeur » non entraîné fabrique les étiquettes `y` `(20000,)` (10 classes). `TensorDataset` associe `X` et `y` ligne à ligne ; 16 000 lignes pour l'entraînement (63 lots de 256), 4 000 pour la validation.
> - `creer_modele` : `(B, 64)` → `(B, 256)` → `LayerNorm`, `GELU`, `Dropout` (formes inchangées) → `(B, 256)` → `(B, 10)`.
> - Vérification n°1 : un réseau qui ne sait rien donne à peu près $1/10$ à chaque classe, donc une perte $-\ln(0{,}1) = \ln 10 \approx 2{,}303$. Vérification n°2 : 300 pas sur un seul lot de 32 exemples doivent faire tomber la perte près de 0.
> - `named_parameters()` renvoie des couples (nom, tenseur) ; `p.ndim >= 2` sélectionne les matrices (poids), `< 2` les vecteurs (biais, LayerNorm), exclus de la décroissance.
> - Calendrier : $12 \times 63 = 756$ étapes, dont $\lfloor 0{,}05 \times 756 \rfloor = 37$ d'échauffement ; `planificateur.step()` est appelé **à chaque lot**, comme le calendrier est défini en étapes.
> - `torch.autocast(...)` exécute la passe avant en 16 bits si `amp_actif` ; `scaler.scale(perte).backward()` multiplie la perte avant `backward`, `scaler.unscale_` redivise les gradients avant l'écrêtage, `scaler.step` puis `scaler.update` appliquent le pas. Sur CPU, tout cela est désactivé et se comporte comme un `backward()` / `step()` ordinaire.
> - `torch.isfinite(perte)` est faux si la perte vaut `nan` ou `inf` : on arrête tout de suite au lieu d'abîmer les poids.

Sortie obtenue sur CPU : perte initiale **2,391** pour $\ln 10 = 2{,}303$ attendu (vérification n°1 réussie) ; le lot de 32 est appris par cœur (perte 0,0005, vérification n°2 réussie) ; l'exactitude de validation passe de 80,0 % après la première époque à **85,3 %** à la fin, avec un taux qui descend de $3 \cdot 10^{-3}$ à 0. Quand `GradScaler` est désactivé, ses méthodes ne font rien : le même code sert sur CPU, MPS et GPU.

## 6. Déboguer un entraînement : la méthode

Andrej Karpathy a résumé dans son billet « A Recipe for Training Neural Networks » (2019) une démarche que tous les praticiens finissent par adopter : **partir simple, vérifier chaque hypothèse, complexifier ensuite**. Voici notre version, en cinq vérifications, à faire **dans l'ordre**.

> 💡 **Autrement dit** — Comme un garagiste face à une voiture qui ne démarre pas : on vérifie d'abord qu'il y a de l'essence (les données), puis la batterie (la perte initiale), puis qu'on peut faire tourner le moteur au point mort (sur-apprendre un lot), avant de soupçonner l'injection électronique. On ne démonte pas le moteur en premier.

```quiz
{
  "q": "Un classifieur à 10 classes affiche une perte de 9,8 dès la toute première itération, avant tout apprentissage. Que concluez-vous ?",
  "options": ["Tout va bien : la perte va baisser dès les premières époques", "Un bug d'initialisation ou de perte : on attend ≈ 2,3", "Le jeu de validation est trop petit", "Il faut augmenter le dropout pour stabiliser le départ"],
  "answer": 1,
  "explanation": "Un modèle qui n'a rien appris devrait répartir ses probabilités à peu près uniformément : perte ≈ ln(K) = 2,3. Une perte de 9,8 signale une dernière couche mal initialisée (logits énormes), une softmax appliquée deux fois ou des étiquettes mal formées."
}
```

| # | Vérification | Résultat attendu | Si ce n'est pas le cas |
|---|---|---|---|
| 1 | Regarder les données (afficher 20 images et leurs étiquettes, la distribution des classes) | étiquettes justes, classes connues | bug de chargement, d'ordre des canaux, d'étiquetage |
| 2 | Perte initiale | $\approx \ln K$ en classification à $K$ classes | dernière couche mal initialisée, softmax appliquée deux fois |
| 3 | Sur-apprendre un seul lot (sans dropout ni augmentation) | perte proche de 0 en quelques centaines d'étapes | bug dans le modèle, la perte ou la boucle (souvent `zero_grad`, `eval` ou forme des étiquettes) |
| 4 | Baseline simple (régression logistique, petit MLP) | un score de référence | sans baseline, impossible de dire si 85 % est bon |
| 5 | Surveiller pendant l'entraînement : perte train et validation, taux d'apprentissage, norme du gradient | perte train décroissante, écart train/valid raisonnable | voir le tableau ci-dessous |

| Symptôme | Diagnostic probable | Action |
|---|---|---|
| Perte `nan` après quelques étapes | taux trop élevé, $\log 0$, explosion | taux ÷ 10, écrêtage, vérifier les entrées (valeurs infinies) |
| Perte plate dès le départ | taux trop faible, gradients nuls (ReLU morts), données non normalisées | test de plage, initialisation de He, normaliser les entrées |
| Perte train baisse, validation remonte | sur-apprentissage | régularisation, augmentation, arrêt anticipé |
| Les deux pertes stagnent haut | sous-apprentissage | modèle plus grand, entraîner plus longtemps, taux plus élevé |
| Bon score en validation, mauvais en production | fuite de données ou décalage de distribution | revoir la séparation, collecter des données de production |
| Résultats différents à chaque exécution | graines non fixées, algorithmes non déterministes | `torch.manual_seed`, voir la page Reproducibility (L123) |

> ⚠️ **Piège fréquent** — Changer trois réglages à la fois parce que « ça n'apprend pas ». Vous ne saurez jamais lequel a compté. Une modification par expérience, et un journal (fichier CSV ou outil de suivi comme TensorBoard) qui garde la configuration et les courbes de chaque essai.

## 🧪 Exercice pratique

**Consigne.** Partez de `recette.py` et menez une **étude d'ablation** : en ne changeant qu'un élément à la fois, mesurez l'exactitude de validation finale pour
1. SGD sans momentum, SGD avec momentum 0,9, Adam, AdamW (même taux de départ après un rapide test de plage pour chacun) ;
2. avec et sans échauffement ; avec un taux constant au lieu du cosinus ;
3. avec et sans LayerNorm ; dropout 0 ; 0,1 ; 0,5 ;
4. un taux volontairement dix fois trop grand : observez la norme du gradient et l'effet de l'écrêtage.

Présentez les résultats dans un tableau (une ligne par expérience, trois graines par configuration, moyenne ± écart type) et concluez en cinq phrases.

**Critères de réussite.** Au moins 10 configurations, chacune avec 3 graines ; une seule variable modifiée par ligne ; une conclusion qui distingue les écarts significatifs (supérieurs à deux écarts types) des écarts de bruit.

<details><summary>Pistes de correction</summary>

- Encapsulez l'entraînement dans une fonction `entrainer(config: dict, graine: int) -> float` et bouclez sur une liste de dictionnaires ; sauvegardez avec `csv.DictWriter`.
- Attendez-vous à ce que SGD sans momentum soit nettement en retrait à nombre d'époques égal, et à ce que le dropout 0,5 dégrade les résultats sur ce problème sans bruit (il n'y a pas de sur-apprentissage à combattre).
- Sans écrêtage et avec un taux trop grand, la norme du gradient monte par à-coups avant l'apparition des `nan` : c'est le signal d'alerte à surveiller dans vos journaux.
</details>

## 🎮 Défi

Un modèle de 1 milliard de paramètres est entraîné avec AdamW en précision mixte `bfloat16`, avec des poids maîtres en `float32`. Combien de mémoire pour les poids, les gradients et l'état de l'optimiseur, hors activations ? Réponse : poids `float32` 4 Go + copie `bfloat16` 2 Go + gradients 2 à 4 Go + deux moments Adam en `float32` 8 Go, soit **16 à 18 Go**. D'où l'intérêt des techniques de découpage (FSDP, ZeRO) vues en M29.

## ✅ Auto-évaluation express

1. Pourquoi l'initialisation de He utilise-t-elle une variance $2/n_{\text{in}}$ plutôt que $1/n_{\text{in}}$ ?
2. Quelle est la différence entre Adam avec pénalité $L_2$ et AdamW ?
3. Pourquoi n'a-t-on pas besoin de `GradScaler` en `bfloat16` alors qu'il est nécessaire en `float16` ?

**Réponses.** 1. Parce que ReLU annule en moyenne la moitié des activations, ce qui divise la variance par deux ; le facteur 2 compense. 2. Dans Adam, la pénalité est ajoutée au gradient et donc divisée par $\sqrt{\hat v}$ ; AdamW applique la décroissance des poids directement aux paramètres, indépendamment de l'adaptation. 3. `bfloat16` a la même plage d'exposant que `float32` : les petits gradients ne sont pas arrondis à zéro, contrairement à `float16` dont la plage est bien plus étroite.

## 📚 Pour aller plus loin
- [Stanford CS231n — programme Spring 2026](https://cs231n.stanford.edu/schedule.html) 🇬🇧 — séance 3 (SGD, momentum, AdaGrad, Adam, calendriers) et séance 6 (BatchNorm).
- [PyTorch — torch.optim](https://pytorch.org/docs/stable/optim.html) 🇬🇧 — optimiseurs, groupes de paramètres et calendriers de taux.
- [PyTorch — Automatic Mixed Precision](https://pytorch.org/docs/stable/amp.html) 🇬🇧 — `autocast`, `GradScaler` et la liste des opérations par précision.
- [Adam: A Method for Stochastic Optimization](https://arxiv.org/abs/1412.6980) 🇬🇧 et [Decoupled Weight Decay Regularization](https://arxiv.org/abs/1711.05101) 🇬🇧 — les deux articles fondateurs d'Adam et d'AdamW.
- [Andrej Karpathy — A Recipe for Training Neural Networks](http://karpathy.github.io/2019/04/25/recipe/) 🇬🇧 — la méthode de débogage pas à pas dont s'inspire la section 6.
- [fast.ai — Practical Deep Learning for Coders](https://course.fast.ai/) 🇬🇧 — partie 2, leçons 17 à 20 : initialisation et normalisation, SGD accéléré, dropout, précision mixte.

> ✅ **Si vous ne retenez que 3 choses** — 1. Initialisez selon l'activation (He pour ReLU, Xavier pour tanh) pour que le signal garde une taille constante à travers les couches ; normalisations et connexions résiduelles rendent le réseau plus tolérant. 2. Recette par défaut : AdamW (sans décroissance sur biais et normalisations), échauffement puis cosinus, écrêtage à 1, précision mixte `bfloat16` sur GPU ; le taux d'apprentissage est le premier bouton à régler. 3. Quand « ça n'apprend pas » : regarder les données, vérifier la perte initiale ($\approx \ln K$), sur-apprendre un lot, comparer à une baseline, puis surveiller les courbes, en ne changeant qu'un réglage à la fois.

> 🗺️ **Et maintenant ?** — Vous avez toutes les techniques ; la leçon L127 les réunit dans un projet complet : un classifieur d'images de bout en bout, de la collecte des données au modèle prêt à servir.
