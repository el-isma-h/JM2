---
id: L120
module: M25
level: N4
title: "Projet ML : prédiction sur données réelles"
minutes: 70
objectives:
  - "Cadrer un problème de prédiction : question métier, classe positive, coût des erreurs, métrique et critère de succès"
  - "Conduire une analyse exploratoire qui oriente les choix de modélisation (déséquilibre, asymétrie, redondance, fuites)"
  - "Construire un protocole d'évaluation sans fuite : test scellé, validation croisée répétée, baselines, choix du seuil hors pli"
  - "Évaluer un modèle final avec incertitude (intervalle bootstrap) et rédiger un rapport et une carte du modèle"
skills: ["C4.2"]
sources:
  - { title: "scikit-learn — Toy datasets (Breast Cancer Wisconsin diagnostic)", url: "https://scikit-learn.org/stable/datasets/toy_dataset.html", lang: "en" }
  - { title: "scikit-learn — Common pitfalls and recommended practices", url: "https://scikit-learn.org/stable/common_pitfalls.html", lang: "en" }
  - { title: "scikit-learn — Metrics and scoring", url: "https://scikit-learn.org/stable/modules/model_evaluation.html", lang: "en" }
  - { title: "Stanford CS229 — Machine Learning (projets de fin de cours)", url: "https://cs229.stanford.edu/", lang: "en" }
  - { title: "École 42 — branche Algo/AI/data (liste des projets, dépôt étudiant)", url: "https://github.com/jmcheon/42cursus", lang: "en" }
  - { title: "Kaggle Learn — micro-cours Intro et Intermediate Machine Learning", url: "https://www.kaggle.com/learn", lang: "en" }
---

# Projet ML : prédiction sur données réelles

> ⏱ 70 min · 🎯 Niveau 4 · 📚 Module 25

## 🎯 Ce que vous saurez faire
- Transformer une demande floue (« on voudrait de l'IA pour… ») en une question de prédiction mesurable.
- Dérouler, dans l'ordre et sans fuite, les six étapes d'un projet de machine learning supervisé.
- Présenter un résultat avec son incertitude, ses limites et ses conditions d'usage.
- Vous auto-évaluer avec la grille utilisée pour l'épreuve « projet de code » de la compétence C4.2.

> 🧭 **En clair** — Un projet de machine learning ressemble à une enquête bien menée. D'abord, on définit précisément **la question** et ce qui compterait comme un succès (avant de regarder les indices). Ensuite, on examine les données comme un enquêteur inspecte les lieux. On met de côté un **témoin scellé** (le jeu de test) qu'on n'interrogera qu'une seule fois, à la toute fin. On compare plusieurs pistes (modèles) dans les mêmes conditions, on règle le niveau de prudence (le seuil), puis on rend un rapport honnête, qui dit aussi ce qu'on ne sait pas. Sauter une étape, c'est risquer de « résoudre » l'affaire avec de fausses preuves.

## 1. Le projet, ou l'art de ne pas sauter d'étape

Les cinq leçons précédentes vous ont donné les briques : modèles linéaires (L115), diagnostic biais-variance et validation croisée (L116), ensembles d'arbres (L117), méthodes non supervisées (L118), pipelines sans fuite (L119). Un projet réel ne demande pas de briques nouvelles ; il demande de les poser **dans le bon ordre** et de **justifier** chaque choix. C'est la philosophie des projets de fin de cours de Stanford CS229, où l'on évalue autant la démarche que le score, et celle de la branche « Algo, AI, data » de l'École 42 (ft_linear_regression, DSLR, multilayer-perceptron…), où chaque projet se défend oralement devant un pair.

Nous travaillons sur un jeu de données **public et réel** : le *Breast Cancer Wisconsin (Diagnostic)*, constitué à l'université du Wisconsin et diffusé publiquement en 1995 (W. H. Wolberg, W. N. Street, O. L. Mangasarian). Chacun des 569 cas décrit, par 30 mesures, les noyaux cellulaires visibles sur une image numérisée de ponction à l'aiguille fine (rayon, texture, périmètre, concavité…, chacun en moyenne, erreur type et « pire » valeur). La cible : tumeur maligne ou bénigne. C'est le jeu du projet 42 multilayer-perceptron, il est livré avec scikit-learn, donc votre code tourne hors ligne.

Le schéma ci-dessous est votre feuille de route. Les flèches de retour sont normales : l'EDA remet souvent le cadrage en question.

```
 1. Cadrage ──► 2. EDA ──► 3. Protocole ──► 4. Modèles ──► 5. Seuil ──► 6. Test + rapport
     ▲            │             ▲               │
     └────────────┘             └───────────────┘   (itérations autorisées AVANT le test,
                                                      jamais après)
```

> ⚠️ **Piège fréquent** — Ce projet est un exercice d'apprentissage. Un système d'aide au diagnostic médical relève d'un tout autre cadre : marquage des dispositifs médicaux, classement « à haut risque » par l'AI Act, validation clinique, données de santé protégées par le RGPD. Ne présentez jamais ce type de modèle comme un outil de diagnostic.

## 2. Étape 1 — Cadrer avant de coder

Un bon cadrage tient en une demi-page et répond à six questions. Les voici, remplies pour notre cas :

| Question | Réponse pour ce projet |
|---|---|
| Quelle décision le modèle aide-t-il à prendre ? | Prioriser les dossiers à faire relire en premier par un spécialiste |
| Quelle est la classe positive ? | « malin » (attention : dans scikit-learn, `target = 0` signifie malin) |
| Quelle erreur coûte le plus cher ? | le **faux négatif** (une tumeur maligne classée bénigne) |
| Quelle métrique principale ? | le **rappel** de la classe « malin », sous contrainte de précision acceptable |
| Quel critère de succès, fixé à l'avance ? | rappel ≥ 0,98 en validation croisée, AUC ≥ 0,98, précision ≥ 0,90 |
| Quelle baseline faut-il battre ? | le classifieur « classe majoritaire » et une règle simple à une variable |

Fixer le critère **avant** de voir les résultats est essentiel : sinon, on finit toujours par trouver une métrique qui flatte le modèle. Dans une entreprise, ce tableau se remplit avec le métier : pour un modèle de détection de fraude aux notes de frais, le directeur administratif et financier dira combien coûte un contrôle inutile (FP) et combien coûte une fraude ratée (FN).

```quiz
{
  "q": "Dans ce projet sur les tumeurs, pourquoi choisit-on le rappel de la classe « malin » comme métrique principale ?",
  "options": ["Parce que c'est la métrique la plus élevée sur ce jeu de données", "Parce que scikit-learn l'impose pour les données médicales", "Parce que la précision ne peut pas être calculée avec 569 cas", "Parce que rater une tumeur maligne est l'erreur la plus grave"],
  "answer": 3,
  "explanation": "Le cadrage part du coût des erreurs. Rater une tumeur maligne est bien plus grave qu'une relecture inutile : on maximise donc la part des cas malins effectivement repérés, c'est-à-dire le rappel, sous contrainte d'une précision acceptable."
}
```

## 3. Étape 2 — Explorer pour décider

L'analyse exploratoire (*Exploratory Data Analysis*, EDA) n'est pas une galerie de graphiques : chaque constat doit déboucher sur une **décision**. Le script ci-dessous vérifie la qualité des données, l'équilibre des classes, l'asymétrie, la redondance et le pouvoir séparateur de chaque variable.

```python
"""Étape 2 — Analyse exploratoire (EDA) du jeu Breast Cancer Wisconsin (diagnostic)."""
import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import load_breast_cancer

data = load_breast_cancer(as_frame=True)
df = data.frame.copy()
df["diagnostic"] = np.where(df.target == 0, "malin", "bénin")   # attention : 0 = malin dans ce jeu

print("Dimensions :", df.shape)
print("Valeurs manquantes :", int(df.isna().sum().sum()))
print("Doublons :", int(df.duplicated().sum()))
print(df.diagnostic.value_counts(normalize=True).round(3).to_string())

# Asymétrie : quelles variables gagneraient à une transformation log ?
skew = df.drop(columns=["target", "diagnostic"]).skew().sort_values(ascending=False)
print("\nVariables les plus asymétriques :\n", skew.head(5).round(2).to_string())

# Redondance : paires de variables très corrélées
corr = df.drop(columns=["target", "diagnostic"]).corr().abs()
pairs = corr.where(np.triu(np.ones(corr.shape, dtype=bool), k=1)).stack().sort_values(ascending=False)
print(f"\nPaires avec |r| > 0,95 : {int((pairs > 0.95).sum())}")
print(pairs.head(5).round(3).to_string())

# Pouvoir séparateur univarié : écart des moyennes en écarts-types
X = df.drop(columns=["target", "diagnostic"])
d = ((X[df.target == 0].mean() - X[df.target == 1].mean()) / X.std()).abs().sort_values(ascending=False)
print("\nVariables les plus discriminantes (|écart standardisé|) :\n", d.head(5).round(2).to_string())

fig, axes = plt.subplots(1, 3, figsize=(14, 4))
for ax, col in zip(axes, d.index[:3]):
    for lab, color in (("malin", "tab:red"), ("bénin", "tab:blue")):
        ax.hist(df.loc[df.diagnostic == lab, col], bins=30, alpha=0.6, color=color, label=lab)
    ax.set_title(col); ax.legend()
fig.tight_layout(); fig.savefig("eda_histogrammes.png", dpi=120)
print("\nFigure enregistrée : eda_histogrammes.png")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `load_breast_cancer(as_frame=True).frame` : tableau pandas des 30 mesures + la colonne `target` ; avec la colonne `diagnostic` ajoutée, `df.shape` affiche `(569, 32)`. `np.where(condition, a, b)` met « malin » là où `target == 0`, « bénin » ailleurs.
> - `df.isna().sum().sum()` compte toutes les cases vides ; `value_counts(normalize=True)` donne les proportions de chaque diagnostic (0,627 / 0,373).
> - `.skew()` calcule l'**asymétrie** de chaque colonne (0 = symétrique, > 1 = longue traîne à droite).
> - `corr().abs()` : tableau `(30, 30)` des corrélations en valeur absolue. `np.triu(..., k=1)` ne garde que le triangle au-dessus de la diagonale (sinon chaque paire apparaîtrait deux fois, plus les 1 de la diagonale) ; `.stack()` transforme le tableau en liste de paires.
> - `d` : pour chaque colonne, (moyenne des malins − moyenne des bénins) / écart-type, en valeur absolue ; trié du plus discriminant au moins discriminant.

> 💡 **Autrement dit** — Le « pouvoir séparateur » calculé à la fin du script répond à une question simple : « de combien d'écarts-types les moyennes des deux groupes (malin / bénin) sont-elles éloignées ? ». Un écart de 0 : la variable ne distingue rien ; un écart de 2 : les histogrammes se chevauchent encore sur environ un tiers de leur surface (deux cloches de même largeur) ; vers 4, ils ne se touchent presque plus.

> 🔢 **Exemple à la main** — Variable « worst perimeter » (valeurs réelles du jeu) : moyenne des cas malins $\approx 141{,}4$, des cas bénins $\approx 87{,}0$, écart-type global $\approx 33{,}6$. Écart standardisé : $(141{,}4 - 87{,}0)/33{,}6 \approx 1{,}62$. C'est l'une des trois variables les plus discriminantes du jeu (avec « worst concave points », 1,64, et « mean concave points », 1,60). (Calculé avec pandas.)

Ce que l'on en tire, constat par constat :

- **Aucune valeur manquante, aucun doublon** : pas d'imputation nécessaire (mais gardez un `SimpleImputer` dans le pipeline si le modèle doit servir sur de nouvelles données).
- **37 % de cas malins** : déséquilibre modéré. Validation croisée **stratifiée** obligatoire, exactitude insuffisante comme métrique.
- **Fortes asymétries** sur les variables « error », dont « area error » (coefficient d'asymétrie supérieur à 3 ; « mean area » et « worst area » restent vers 1,6-1,9) : une transformation logarithmique aidera un modèle linéaire ; elle est inutile pour les arbres.
- **Quinze paires corrélées à plus de 0,95** (rayon, périmètre et aire mesurent presque la même chose, ce qui est géométriquement logique) : un modèle linéaire non régularisé serait instable, et l'importance par permutation sera « partagée » entre ces variables (L117).
- **Plusieurs variables très discriminantes** à elles seules (écart de plus de 1,5 écart-type entre les classes) : attendez-vous à des scores élevés, et méfiez-vous d'écarts de quelques millièmes entre modèles.

> 💡 **À retenir** — L'EDA se fait sur le jeu d'entraînement dès que des choix en dépendent. Ici, les constats sont descriptifs et généraux ; mais si vous choisissez des variables ou des seuils d'écrêtage à partir de l'EDA, faites-la après avoir mis le test de côté, sinon vous créez une fuite « humaine ».

```mission
{
  "title": "Vérifiez la composition du jeu Breast Cancer Wisconsin",
  "url": "https://scikit-learn.org/stable/datasets/toy_dataset.html",
  "steps": ["Ouvrez la page « Toy datasets » de scikit-learn", "Allez à la section « Breast cancer Wisconsin (diagnostic) dataset »", "Lisez les « Data Set Characteristics », en particulier la ligne « Class Distribution »"],
  "question": "Combien de cas malins et de cas bénins compte le jeu, et combien de variables numériques décrivent chaque cas ?",
  "hint": "La somme des deux classes doit faire 569.",
  "answer": "212 cas malins (Malignant) et 357 bénins (Benign), décrits par 30 attributs numériques (10 mesures × moyenne, erreur type et « pire » valeur), soit environ 37 % de malins, comme le trouve l'EDA. Fiche stable (vérifié le 5 nov. 2026).",
  "xp": 10
}
```

## 4. Étapes 3 à 6 — Protocole, modèles, seuil, test

### 4.1 Le protocole

1. **Mettre le test sous scellé** : 20 % stratifiés, graine fixée, mis de côté avant toute modélisation. On n'y touchera qu'une fois.
2. **Validation croisée répétée** sur les 80 % restants : `RepeatedStratifiedKFold` (5 plis × 3 répétitions). Avec 455 lignes, un seul découpage serait trop bruité ; la répétition donne un écart-type fiable.
3. **Mêmes plis pour tous les modèles**, baseline comprise, et même budget de réglage.
4. **Plusieurs métriques** : AUC (classement global), précision moyenne (*average precision*, résumé de la courbe précision-rappel), rappel et précision au seuil par défaut.

> 🔢 **Exemple à la main** — 569 cas, test de 20 % stratifié : $114$ cas mis sous scellé (dont 42 malins), $455$ pour l'entraînement. `RepeatedStratifiedKFold(5 plis × 3 répétitions)` entraîne chaque modèle $5 \times 3 = 15$ fois, sur environ $455 \times 4/5 = 364$ lignes, et l'évalue sur les $\approx 91$ restantes ; la moyenne et l'écart-type portent donc sur 15 scores. (Vérifié en Python.)

### 4.2 Le choix du modèle

Le principe de parcimonie (le « rasoir d'Occam ») tranche les égalités : à performance comparable, on préfère le modèle **le plus simple, le plus stable et le plus explicable**. C'est ce que fait le script : la régression logistique, précédée d'un `log1p` et d'une standardisation, égale ou dépasse ici forêt et boosting. Ce n'est pas une surprise : 569 cas, des variables continues bien séparées, des relations proches du linéaire après transformation logarithmique.

> 💡 **Autrement dit** — Si un vélo et une voiture de course vous amènent aussi vite à la boulangerie du coin, prenez le vélo : moins cher, moins de pannes, et tout le monde comprend comment il marche. En ML, à score égal, le modèle simple est plus facile à expliquer, à maintenir et à faire valider.

### 4.3 Le seuil

> 🧠 **L'intuition d'abord** — Le modèle donne une probabilité ; le **seuil** décide à partir de quand on « sonne l'alarme ». Baisser le seuil, c'est rendre l'alarme plus sensible : elle rate moins de vrais cas, mais se déclenche plus souvent pour rien. **Analogie :** le réglage d'un détecteur de fumée. Très sensible, il sonne aussi pour un toast grillé ; peu sensible, il risque de rester muet au début d'un vrai feu. Pour un détecteur d'incendie comme pour un tri médical, on préfère la sensibilité.

Le critère de succès porte sur le rappel. On choisit donc le seuil à partir de **probabilités hors pli** calculées sur l'entraînement (`cross_val_predict`), jamais sur le test : on retient le seuil le plus élevé qui atteint un rappel de 0,98. Ce seuil, nettement inférieur à 0,5, traduit la décision du cadrage : on accepte quelques fausses alertes de plus pour rater moins de tumeurs malignes.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : pour atteindre l'objectif de rappel de 0,98, il est acceptable d'ajuster le seuil en regardant directement les résultats sur le jeu de test, puisqu'on ne réentraîne pas le modèle.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Le seuil est un réglage comme un autre : le choisir sur le test transforme le test en jeu de validation, et le score publié devient optimiste. On le choisit sur des prédictions hors pli de l'entraînement (cross_val_predict)."
}
```

### 4.4 Le script complet

```python
"""Étapes 3 à 6 — Protocole, modèles, seuil, évaluation finale, interprétation, livrables."""
import json
import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.datasets import load_breast_cancer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, make_scorer, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import (GridSearchCV, RepeatedStratifiedKFold, StratifiedKFold,
                                     cross_val_predict, cross_validate, train_test_split)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler

SEED = 42
data = load_breast_cancer(as_frame=True)
X = data.data
y = (data.target == 0).astype(int)              # 1 = malin : la classe positive est celle qu'on cherche

# --- Étape 3 : protocole. Le test est mis sous scellé AVANT toute modélisation ---
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)
cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=SEED)
scoring = {"auc": "roc_auc", "ap": "average_precision", "rappel": "recall",
           "precision": make_scorer(precision_score, zero_division=0)}   # la baseline ne prédit jamais "malin"

# --- Étape 4 : baselines puis candidats, tous sur les mêmes plis ---
candidats = {
    "Baseline (classe majoritaire)": DummyClassifier(strategy="most_frequent"),
    "Régression logistique": make_pipeline(FunctionTransformer(np.log1p), StandardScaler(),
                                           LogisticRegression(max_iter=5_000)),
    "Forêt aléatoire": RandomForestClassifier(n_estimators=400, random_state=SEED, n_jobs=-1),
    "Gradient boosting (HGB)": HistGradientBoostingClassifier(learning_rate=0.05, random_state=SEED),
}
lignes = []
for nom, modele in candidats.items():
    r = cross_validate(modele, X_tr, y_tr, cv=cv, scoring=scoring)
    lignes.append({"modèle": nom, **{k: f"{r['test_' + k].mean():.3f} ± {r['test_' + k].std():.3f}"
                                     for k in scoring}})
print(pd.DataFrame(lignes).to_string(index=False))

# --- Réglage du candidat retenu (ici la régression logistique : simple, stable, explicable) ---
pipe = candidats["Régression logistique"]
search = GridSearchCV(pipe, {"logisticregression__C": np.logspace(-3, 2, 11)},
                      cv=StratifiedKFold(5, shuffle=True, random_state=SEED), scoring="roc_auc").fit(X_tr, y_tr)
C = search.best_params_["logisticregression__C"]
print(f"\nC retenu : {C:.3g} (AUC CV {search.best_score_:.4f})")

# --- Étape 5 : choix du seuil sur des prédictions hors pli de l'ENTRAÎNEMENT ---
proba_oof = cross_val_predict(search.best_estimator_, X_tr, y_tr,
                              cv=StratifiedKFold(5, shuffle=True, random_state=SEED),
                              method="predict_proba")[:, 1]
OBJECTIF_RAPPEL = 0.98
seuils = np.linspace(0.01, 0.99, 99)
ok = [s for s in seuils if recall_score(y_tr, proba_oof >= s) >= OBJECTIF_RAPPEL]
seuil = max(ok)                                   # le plus haut seuil qui tient l'objectif de rappel
print(f"Seuil retenu : {seuil:.2f} (rappel hors pli {recall_score(y_tr, proba_oof >= seuil):.3f}, "
      f"précision {precision_score(y_tr, proba_oof >= seuil):.3f})")

# --- Étape 6 : évaluation finale, UNE seule fois, sur le test scellé ---
final = search.best_estimator_                    # déjà réentraîné sur tout X_tr (refit=True)
p_te = final.predict_proba(X_te)[:, 1]
pred = (p_te >= seuil).astype(int)
vn, fp, fn, vp = confusion_matrix(y_te, pred).ravel()
print(f"\nTEST — AUC {roc_auc_score(y_te, p_te):.3f} | rappel {recall_score(y_te, pred):.3f} | "
      f"précision {precision_score(y_te, pred):.3f} | VP={vp} FN={fn} FP={fp} VN={vn}")

# Intervalle de confiance du rappel par bootstrap (le test ne compte que 42 cas malins)
rng = np.random.default_rng(SEED)
yt, pr = y_te.to_numpy(), pred
boot = []
for _ in range(2_000):
    idx = rng.integers(0, len(yt), len(yt))
    if yt[idx].sum() > 0:
        boot.append(recall_score(yt[idx], pr[idx]))
print(f"Rappel test : IC 95 % bootstrap [{np.percentile(boot, 2.5):.3f} ; {np.percentile(boot, 97.5):.3f}]")

# Interprétation : importance par permutation sur le test
imp = permutation_importance(final, X_te, y_te, scoring="roc_auc", n_repeats=30, random_state=SEED)
top = pd.Series(imp.importances_mean, index=X.columns).sort_values(ascending=False).head(5)
print("\nVariables les plus utiles (permutation, test) :\n", top.round(4).to_string())

# Livrables : modèle + carte d'identité du modèle (model card minimale)
joblib.dump({"pipeline": final, "seuil": seuil}, "modele_tumeurs_v1.joblib")
carte = {
    "objectif": "aide au tri, ne remplace pas un diagnostic médical",
    "classe_positive": "malin", "seuil": round(float(seuil), 2), "C": float(C),
    "test": {"auc": round(roc_auc_score(y_te, p_te), 4), "rappel": round(recall_score(y_te, pred), 4),
             "precision": round(precision_score(y_te, pred), 4), "FN": int(fn), "FP": int(fp)},
    "donnees": "Breast Cancer Wisconsin (Diagnostic), 569 cas, via sklearn.datasets",
    "versions": {"scikit-learn": sklearn.__version__}, "graine": SEED,
}
with open("carte_modele.json", "w", encoding="utf-8") as f:
    json.dump(carte, f, ensure_ascii=False, indent=2)
print("\nLivrables : modele_tumeurs_v1.joblib, carte_modele.json")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `y = (data.target == 0).astype(int)` inverse le codage pour que **1 = malin** (la classe recherchée).
> - `scoring` est un dictionnaire de 4 métriques ; `cross_validate` renvoie pour chacune un tableau de 15 scores (`r["test_auc"]`, etc.), résumé en « moyenne ± écart-type ».
> - `np.logspace(-3, 2, 11)` : 11 valeurs de `C` de 0,001 à 100. `cross_val_predict(..., method="predict_proba")[:, 1]` donne, pour chacune des 455 lignes d'entraînement, la probabilité « malin » calculée par un modèle qui **ne l'a pas vue** (prédiction hors pli), forme `(455,)`.
> - `proba_oof >= s` transforme les probabilités en décisions 0/1 pour un seuil `s` ; `ok` liste les seuils qui tiennent un rappel ≥ 0,98, et `max(ok)` prend le plus haut.
> - `confusion_matrix(...).ravel()` aplatit le tableau $2 \times 2$ dans l'ordre VN, FP, FN, VP.
> - Bootstrap : `rng.integers(0, 114, 114)` tire 114 indices **avec remise** (certains cas plusieurs fois, d'autres jamais) ; on recalcule le rappel 2 000 fois, et `np.percentile(boot, [2.5, 97.5])` donne les bornes de l'intervalle à 95 %.
> - `joblib.dump` sauvegarde le pipeline **et** le seuil ensemble, pour ne jamais les séparer en production.

### 4.5 Lire honnêtement le résultat

> 🧠 **L'intuition d'abord** — Le **bootstrap** consiste à rejouer l'évaluation des milliers de fois sur des tirages au hasard (avec remise) du jeu de test, pour voir à quel point le score aurait pu varier « par malchance ». **Analogie :** un sondage sur 42 personnes. Si 40 répondent oui, on annonce 95 %, mais on sait qu'avec 42 autres personnes on aurait pu obtenir 88 % ou 100 %. L'intervalle de confiance rend cette incertitude visible.

> 💡 **Autrement dit** — Avec seulement 42 cas positifs, chaque cas pèse 2,4 points de rappel. Un écart de 3 points avec l'objectif n'est donc ni une réussite ni un échec démontré : c'est un signal pour collecter davantage de cas avant de conclure.

> 🔢 **Exemple à la main** — 42 cas malins dans le test. 40 trouvés : rappel $= 40/42 \approx 0{,}952$. Un seul cas manqué de plus : $39/42 \approx 0{,}929$. Chaque cas vaut donc $1/42 \approx 0{,}024$, soit 2,4 points. Atteindre 0,98 exigerait $0{,}98 \times 42 = 41{,}2$, c'est-à-dire **zéro** cas manqué (42/42 = 1) : avec un si petit test, l'objectif se joue à un patient près. (Vérifié en Python.)

Sur le test, le modèle classe très bien (AUC proche de 0,99), mais le rappel mesuré (environ 0,95 : 2 cas malins manqués sur 42) est **inférieur** à l'objectif de 0,98 atteint en validation croisée. Faut-il conclure à un échec ? L'intervalle de confiance bootstrap répond : avec seulement 42 cas positifs dans le test, le rappel est connu à quelques points près (l'intervalle à 95 % va d'environ 0,88 à 1). Un cas de plus ou de moins fait varier le rappel de 2,4 points. Trois attitudes professionnelles, et une interdite :

- ✅ **Rapporter** le chiffre du test tel quel, avec son intervalle, et le comparer à l'objectif.
- ✅ **Recommander** une validation sur davantage de données avant tout usage, puisque l'incertitude couvre l'objectif.
- ✅ **Analyser** les deux faux négatifs : sont-ils des cas limites (probabilité proche du seuil) ou des erreurs franches ?
- ❌ **Interdit** : baisser le seuil en regardant le test jusqu'à atteindre 0,98, puis annoncer ce score. Le test deviendrait un jeu de validation et le chiffre publié serait faux.

> 🔗 **Documentation officielle** — [scikit-learn — Metrics and scoring](https://scikit-learn.org/stable/modules/model_evaluation.html) 🇬🇧 (courbes précision-rappel, `average_precision`, réglage du seuil de décision).

```mission
{
  "title": "La règle d'or anti-fuite du guide « Common pitfalls »",
  "url": "https://scikit-learn.org/stable/common_pitfalls.html",
  "steps": ["Ouvrez la page « Common pitfalls and recommended practices »", "Allez à la section « Data leakage » puis « How to avoid data leakage »", "Notez les deux premières recommandations"],
  "question": "Que recommande scikit-learn de faire en tout premier, avant toute étape de prétraitement, et que ne faut-il jamais appeler sur les données de test ?",
  "hint": "La première recommandation concerne le découpage ; la seconde, deux méthodes qui apprennent.",
  "answer": "Séparer les données en entraînement et test en tout premier, avant tout prétraitement ; ne jamais appeler fit ni fit_transform sur les données de test (et utiliser des pipelines pour que la validation croisée respecte cette règle). Doc stable, nov. 2026.",
  "xp": 15
}
```

## 5. Le rapport : écrire pour être relu

Votre rapport (4 à 6 pages, ou un notebook propre) suit une structure fixe. Un lecteur pressé doit trouver la conclusion en trente secondes, un relecteur technique doit pouvoir **reproduire** chaque chiffre.

1. **Résumé** (5 lignes) : question, données, meilleur modèle, chiffre clé du test avec son intervalle, recommandation.
2. **Cadrage** : le tableau du § 2, avec le critère de succès fixé à l'avance.
3. **Données** : provenance, licence, taille, période, qualité, constats d'EDA et décisions associées.
4. **Protocole** : découpage, validation croisée, métriques, graines, ce qui a été fait pour éviter les fuites.
5. **Résultats** : tableau comparatif (moyenne ± écart-type) incluant la baseline, réglage, seuil, puis score de test unique.
6. **Interprétation** : variables importantes (par permutation), analyse des erreurs, limites (taille du test, population d'origine, variables corrélées).
7. **Carte du modèle** (*model card*) : usage prévu et usages interdits, performances, données, versions, contact. Le script en produit une version minimale (`carte_modele.json`).
8. **Reproductibilité** : versions des bibliothèques, commande exacte pour relancer, empreinte des données.

> 🎮 **Défi** — Remplacez la régression logistique par le gradient boosting comme modèle final, sans rien changer d'autre au protocole. Le rappel du test change-t-il ? L'écart observé est-il plus grand que la largeur de l'intervalle bootstrap ? Concluez en une phrase sur l'intérêt de changer de modèle.

## 6. La grille d'évaluation

Voici la grille proposée pour l'épreuve « projet de code » associée à la compétence C4.2 (« entraîner, évaluer et sélectionner un modèle de machine learning sur un jeu de données réel »). Elle reprend les critères du référentiel : protocole correct, performances interprétées, sur-apprentissage détecté. Notez-vous honnêtement : 70 points sur 100 sont requis.

| Critère | Ce qui est attendu | Points |
|---|---|---|
| Cadrage | classe positive, coût des erreurs, métrique et critère de succès fixés **avant** les résultats | 10 |
| EDA utile | qualité, équilibre, distributions, corrélations ; chaque constat mène à une décision | 10 |
| Protocole sans fuite | test scellé, prétraitements dans le pipeline, découpage adapté (stratifié, groupes, temps) | 20 |
| Baselines et comparaison | au moins une baseline triviale, ≥ 2 familles de modèles, mêmes plis, moyenne ± écart-type | 15 |
| Diagnostic biais-variance | écart entraînement / validation commenté, régularisation ou réglage justifié | 10 |
| Seuil et métriques | seuil choisi hors test et relié au cadrage, matrice de confusion commentée | 10 |
| Évaluation finale | test utilisé une fois, intervalle de confiance, comparaison à l'objectif | 10 |
| Interprétation et limites | importance par permutation, analyse d'erreurs, limites et usages interdits | 10 |
| Reproductibilité | code exécutable de bout en bout, graines, versions, carte du modèle | 5 |
| **Total** | | **100** |

Éliminatoire, quel que soit le total : une fuite de données avérée (score de test obtenu après réglage sur le test, prétraitement ajusté sur toutes les données, variable connue après l'événement).

```quiz
{
  "q": "Un candidat obtient 85/100 à la grille, mais son StandardScaler a été ajusté sur l'ensemble des 569 cas avant le découpage. Quel est le verdict ?",
  "options": ["Validé avec 85/100, puisque le seuil de 70 est dépassé", "Non validé : c'est une fuite avérée, éliminatoire", "Validé avec une pénalité de 10 points", "Validé si l'AUC de test dépasse 0,98"],
  "answer": 1,
  "explanation": "La grille précise qu'une fuite de données avérée est éliminatoire, quel que soit le total. Ajuster le scaler avant le découpage laisse les statistiques du test influencer l'entraînement."
}
```

## 🧪 Exercice pratique

**Consigne.** Menez votre propre projet complet sur **un autre jeu de données public**, en appliquant la même démarche et en rendant le rapport en huit parties du § 5. Trois propositions de difficulté croissante :
1. **Régression** — *California Housing* (`sklearn.datasets.fetch_california_housing`, téléchargé au premier appel) : prédire la valeur médiane des logements d'un quartier ; métrique MAE en dollars ; attention aux valeurs plafonnées de la cible et à la dimension géographique (essayez un découpage par zones avec `GroupKFold`).
2. **Classification tabulaire mixte** — le *Titanic* de Kaggle (compétition d'initiation « Titanic - Machine Learning from Disaster ») : variables catégorielles, valeurs manquantes, fuites possibles (numéro de cabine, de billet) ; idéal pour le `ColumnTransformer` de L119.
3. **Données françaises** — les fichiers publics de demandes de valeurs foncières (DVF), diffusés en open data par la DGFiP : prédire le prix au mètre carré d'une vente dans votre département ; découpage **temporel** obligatoire (entraînement sur les années passées, test sur la plus récente).

**Critères de réussite.** La grille du § 6, avec au moins 70 points ; le code tourne de bout en bout par une seule commande ; le score de test est accompagné d'un intervalle de confiance et comparé au critère de succès fixé dans le cadrage.

**Pistes de corrigé.** Pour California Housing, une régression Ridge sur variables transformées donne une baseline honnête ; un `HistGradientBoostingRegressor` l'améliore nettement grâce aux interactions latitude-longitude. Les cibles plafonnées (valeurs maximales identiques) doivent être signalées : le modèle ne peut pas prédire au-delà. Pour DVF, filtrez les ventes atypiques (lots multiples, dépendances seules) et justifiez chaque filtre dans le rapport ; sans découpage temporel, l'évolution des prix crée une fuite. Pour le Titanic, le titre extrait du nom (« Mr », « Mrs », « Master ») est un exemple classique d'ingénierie de variables légitime.

## ✅ Auto-évaluation express
1. Pourquoi fixer le critère de succès avant de voir les résultats ?
2. Sur quelles données choisit-on le seuil de décision, et pourquoi pas sur le test ?
3. Votre rappel de test est de 0,95 pour un objectif de 0,98, avec un intervalle bootstrap [0,88 ; 1]. Que rapportez-vous ?

**Réponses.** 1. Pour éviter de choisir a posteriori la métrique ou le seuil qui flatte le modèle : c'est l'équivalent ML du pré-enregistrement d'une étude scientifique. 2. Sur des prédictions hors pli de l'entraînement (`cross_val_predict`) ; choisir sur le test revient à l'utiliser pour régler un hyperparamètre, et son score devient optimiste. 3. Le chiffre tel quel, son intervalle, le fait que l'objectif n'est pas démontré atteint mais reste compatible avec l'incertitude, et la recommandation de valider sur davantage de cas positifs avant tout usage.

## 📚 Pour aller plus loin
- [scikit-learn — Toy datasets](https://scikit-learn.org/stable/datasets/toy_dataset.html) 🇬🇧 — fiche descriptive du *Breast Cancer Wisconsin (Diagnostic)* et des autres jeux intégrés.
- [scikit-learn — Common pitfalls and recommended practices](https://scikit-learn.org/stable/common_pitfalls.html) 🇬🇧 — la check-list anti-fuite à relire avant de rendre le projet.
- [Kaggle Learn](https://www.kaggle.com/learn) 🇬🇧 — micro-cours gratuits « Intro to Machine Learning » et « Intermediate Machine Learning » (pipelines, validation croisée, XGBoost, fuites).
- [Stanford CS229 — Machine Learning](https://cs229.stanford.edu/) 🇬🇧 — consignes et exemples des projets de fin de trimestre.
- [MIT 6.390 IntroML (Fall 2026)](https://introml.mit.edu/fall26/info) 🇬🇧 — pour revoir les fondements de tout ce module dans un cours universitaire complet.
- [École 42 — liste des projets de la branche Algo/AI/data (dépôt étudiant)](https://github.com/jmcheon/42cursus) 🇬🇧 — pour situer ce projet dans la progression 42 (ft_linear_regression, DSLR, multilayer-perceptron, Total-Perspective-Vortex).

> ✅ **Si vous ne retenez que 3 choses** — 1. Cadrez avant de coder : classe positive, erreur la plus coûteuse, métrique et critère de succès fixés **avant** de voir les résultats. 2. Mettez le test sous scellé, comparez baseline et modèles sur les mêmes plis, choisissez le seuil sur des prédictions hors pli de l'entraînement, puis touchez le test **une seule fois**. 3. Rapportez le score de test avec son intervalle de confiance (bootstrap) et ses limites ; à performance égale, préférez le modèle le plus simple.

> 🗺️ **Et maintenant ?** — Vous maîtrisez le machine learning « classique » ; le module 26 ouvre le deep learning avec la leçon L121 : le perceptron et les réseaux multicouches, qui empilent des régressions logistiques pour apprendre des formes bien plus complexes.
