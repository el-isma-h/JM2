---
id: L119
module: M25
level: N4
title: "scikit-learn en pratique"
minutes: 65
objectives:
  - "Construire un Pipeline complet avec ColumnTransformer pour des données mixtes (numériques, catégorielles, valeurs manquantes)"
  - "Régler des hyperparamètres avec GridSearchCV ou RandomizedSearchCV et estimer la performance par validation croisée imbriquée"
  - "Identifier et corriger les quatre grandes familles de fuites de données (prétraitement, sélection, cible, temps)"
  - "Écrire un transformateur personnalisé compatible scikit-learn et persister un modèle de façon sûre et reproductible"
skills: ["C4.2"]
sources:
  - { title: "scikit-learn — User Guide", url: "https://scikit-learn.org/stable/user_guide.html", lang: "en" }
  - { title: "scikit-learn — Pipelines and composite estimators", url: "https://scikit-learn.org/stable/modules/compose.html", lang: "en" }
  - { title: "scikit-learn — Tuning the hyper-parameters of an estimator", url: "https://scikit-learn.org/stable/modules/grid_search.html", lang: "en" }
  - { title: "scikit-learn — Common pitfalls and recommended practices", url: "https://scikit-learn.org/stable/common_pitfalls.html", lang: "en" }
  - { title: "scikit-learn — Model persistence", url: "https://scikit-learn.org/stable/model_persistence.html", lang: "en" }
  - { title: "Inria — MOOC « Machine learning in Python with scikit-learn » (support libre)", url: "https://inria.github.io/scikit-learn-mooc/", lang: "en" }
---

# scikit-learn en pratique

> ⏱ 65 min · 🎯 Niveau 4 · 📚 Module 25

## 🎯 Ce que vous saurez faire
- Assembler en un seul objet tout le chemin « données brutes → prédiction » : imputation, encodage, mise à l'échelle, modèle.
- Régler les hyperparamètres de ce pipeline sans jamais contaminer l'évaluation.
- Repérer une fuite de données dans le code d'un collègue en moins de deux minutes.
- Sauvegarder, recharger et versionner un modèle, en connaissant les risques de sécurité du format `pickle`.

> 🧭 **En clair** — scikit-learn, c'est une **boîte de Lego** du machine learning : toutes les pièces s'emboîtent de la même façon (`fit` pour apprendre, `predict` pour prédire, `transform` pour préparer). Un **pipeline** est une chaîne de montage qui enchaîne nettoyage, préparation et modèle, et qu'on traite comme une seule machine. Pourquoi est-ce si important ? Parce que le piège numéro un du ML est la **fuite de données** : laisser le modèle apercevoir, sans le vouloir, les réponses de l'examen. Comme un élève qui aurait vu le corrigé : ses notes sont superbes, mais il échouera dans la vraie vie. Mettre chaque étape dans le pipeline, c'est garder le corrigé sous clé.

## 1. Une bibliothèque, une grammaire

scikit-learn est né en 2007 d'un projet Google Summer of Code de David Cournapeau ; une équipe de l'Inria (Gaël Varoquaux, Fabian Pedregosa, Alexandre Gramfort, Vincent Michel…) en publie la première version publique en 2010. C'est l'une des plus belles réussites du logiciel scientifique français, et la raison de son succès tient en un mot : **cohérence**. Tous les objets parlent la même langue :

| Rôle | Méthodes | Exemples |
|---|---|---|
| Estimateur | `fit(X, y)` | tout objet qui apprend quelque chose |
| Prédicteur | `predict(X)`, `predict_proba(X)`, `score(X, y)` | `LogisticRegression`, `RandomForestClassifier` |
| Transformateur | `transform(X)`, `fit_transform(X)` | `StandardScaler`, `OneHotEncoder`, `PCA` |
| Méta-estimateur | enveloppe d'autres estimateurs | `Pipeline`, `GridSearchCV`, `ColumnTransformer` |

Les hyperparamètres se passent au constructeur, les paramètres appris portent un tiret bas final (`coef_`, `feature_importances_`, `n_iter_`). Cette grammaire permet d'emboîter les objets comme des briques, et c'est exactement ce que nous allons faire. Le projet 42 **Total-Perspective-Vortex** (interface cerveau-machine sur EEG) l'exige d'ailleurs explicitement : la réduction de dimension que vous codez vous-même doit hériter de `BaseEstimator` et `TransformerMixin` pour s'insérer dans un pipeline scikit-learn.

> 💡 **Autrement dit** — Deux sortes de réglages : ceux que **vous** choisissez avant l'apprentissage (hyperparamètres, ex. `C=1`, passés entre parenthèses) et ceux que le **modèle** apprend tout seul (paramètres, ex. `coef_`, reconnaissables à leur tiret bas final, et qui n'existent qu'après `fit`).

> 💡 **À retenir** — Si une étape **apprend** quoi que ce soit des données (une moyenne, un écart-type, une liste de catégories, une sélection de variables, une valeur d'imputation), elle doit vivre **dans** le pipeline. C'est la règle qui élimine la majorité des fuites de données.

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : calculer la moyenne et l'écart-type de toutes les données (entraînement + test) pour standardiser, avant de les séparer, est sans conséquence puisqu'il ne s'agit pas du modèle lui-même.",
  "options": ["Vrai", "Faux"],
  "answer": 1,
  "explanation": "Faux. Le StandardScaler apprend quelque chose (moyenne, écart-type) : s'il voit le test, une information du test s'infiltre dans l'entraînement. Toute étape qui apprend doit vivre dans le pipeline et n'être ajustée que sur l'entraînement."
}
```

## 2. Pipeline et ColumnTransformer : des données réelles, donc sales

Les données d'une entreprise mélangent des colonnes numériques, catégorielles, avec des trous. Prenons un cas concret : un éditeur de logiciel de caisse pour commerçants veut prédire la **résiliation** (*churn*) de ses abonnés. Chaque type de colonne a son traitement :

```
                         ┌── numériques ──► SimpleImputer(médiane) ─► StandardScaler ──┐
données brutes (DataFrame)├── catégorielles ► SimpleImputer(constante) ► OneHotEncoder ──┼─► modèle
                         └── ordinales ───► OrdinalEncoder ─────────────────────────────┘
```

> 🧠 **L'intuition d'abord** — Chaque type de colonne a besoin d'un traitement différent : on bouche les trous des nombres avec la médiane puis on les met à l'échelle ; on transforme les catégories en colonnes oui/non. **Analogie :** le tri dans une cuisine de restaurant. Les légumes partent au poste de découpe, la viande au grill, les desserts à la pâtisserie ; à la fin, tout se retrouve sur la même assiette (le modèle). Le `ColumnTransformer` est le chef qui dispatche.

Le `ColumnTransformer` aiguille chaque groupe de colonnes vers son sous-pipeline, puis recolle les résultats. Le `Pipeline` enchaîne ce prétraitement et le modèle. Le tout se comporte comme **un seul estimateur** : `fit`, `predict`, validation croisée et recherche d'hyperparamètres s'appliquent à l'ensemble.

```python
"""Pipeline complet sur données mixtes : imputation, encodage, modèle, recherche d'hyperparamètres."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder, StandardScaler

# --- 1. Données simulées d'abonnés (remplacez par pd.read_csv("abonnes.csv")) ---
rng = np.random.default_rng(0)
n = 3_000
df = pd.DataFrame({
    "anciennete_mois": rng.integers(1, 72, n),
    "panier_moyen_eur": rng.lognormal(3.5, 0.5, n).round(2),
    "tickets_support_6m": rng.poisson(1.5, n),
    "secteur": rng.choice(["boulangerie", "coiffure", "restauration", "prêt-à-porter"], n),
    "region": rng.choice(["IDF", "AURA", "PACA", "Occitanie", "Grand Est"], n),
    "formule": rng.choice(["Essentiel", "Pro", "Premium"], n, p=[0.5, 0.35, 0.15]),
})
logit = (-1.0 - 0.04 * df.anciennete_mois + 0.45 * df.tickets_support_6m
         + 0.6 * (df.secteur == "restauration") - 0.5 * (df.formule == "Premium"))
df["resilie"] = (rng.uniform(size=n) < 1 / (1 + np.exp(-logit))).astype(int)
for col in ("panier_moyen_eur", "secteur"):                  # trous réalistes (5 %)
    df.loc[rng.uniform(size=n) < 0.05, col] = np.nan

X, y = df.drop(columns="resilie"), df["resilie"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=0)

# --- 2. Prétraitement par type de colonne ---
num_cols = ["anciennete_mois", "panier_moyen_eur", "tickets_support_6m"]
cat_cols = ["secteur", "region"]
ord_cols = ["formule"]
preprocess = ColumnTransformer([
    ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num_cols),
    ("cat", Pipeline([("imp", SimpleImputer(strategy="constant", fill_value="inconnu")),
                      ("ohe", OneHotEncoder(handle_unknown="ignore"))]), cat_cols),
    ("ord", OrdinalEncoder(categories=[["Essentiel", "Pro", "Premium"]]), ord_cols),
])
pipe = Pipeline([("prep", preprocess), ("model", LogisticRegression(max_iter=2_000))])

# --- 3. Recherche d'hyperparamètres : on peut même faire varier le modèle lui-même ---
grid = [
    {"model": [LogisticRegression(max_iter=2_000)], "model__C": [0.01, 0.1, 1, 10]},
    {"model": [HistGradientBoostingClassifier(random_state=0)],
     "model__learning_rate": [0.05, 0.1], "model__max_depth": [3, None]},
]
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
search = GridSearchCV(pipe, grid, cv=cv, scoring="roc_auc", n_jobs=-1).fit(X_tr, y_tr)

print("Meilleure configuration :", search.best_params_)
print(f"AUC validation croisée  : {search.best_score_:.3f}")
proba = search.predict_proba(X_te)[:, 1]
print(f"AUC test (une seule fois): {roc_auc_score(y_te, proba):.3f}")
print(classification_report(y_te, (proba >= 0.5).astype(int), digits=3))
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - Partie 1 : `df` est un tableau pandas de **3 000 lignes × 6 colonnes** ; `rng.poisson(1.5, n)` tire des nombres entiers de tickets (en moyenne 1,5) ; `rng.choice([...], n, p=[0.5, 0.35, 0.15])` tire des formules avec ces probabilités. La ligne `df.loc[masque, col] = np.nan` crée des trous (NaN = valeur manquante) dans 5 % des lignes.
> - `df.drop(columns="resilie")` : `X` `(3000, 6)` ; `y` `(3000,)`. Le découpage donne 2 400 lignes d'entraînement et 600 de test.
> - Partie 2 : chaque triplet du `ColumnTransformer` est `(nom, traitement, colonnes)`. `OneHotEncoder` transforme une colonne catégorielle en autant de colonnes 0/1 que de valeurs : « boulangerie » devient `[1, 0, 0, 0, 0]` sur (boulangerie, coiffure, inconnu, prêt-à-porter, restauration). `OrdinalEncoder` code Essentiel/Pro/Premium en 0/1/2, en respectant l'ordre donné.
> - Partie 3 : `grid` est une **liste de deux grilles** ; la clé `"model"` remplace l'étape entière, `"model__C"` règle le paramètre `C` de cette étape. 4 + 2 × 2 = 8 candidats × 5 plis = 40 entraînements, plus un réentraînement final du meilleur sur tout `X_tr`.
> - `search.predict_proba(X_te)` renvoie `(600, 2)` (probabilité de chaque classe) ; `[:, 1]` garde la colonne « résilie » → `(600,)`.

Regardez le rapport de classification : avec le seuil par défaut de 0,5, le rappel de la classe « résilie » est très faible, alors que l'AUC est correcte. Le modèle classe bien les abonnés par risque, mais le seuil est mal placé pour une classe minoritaire (environ 17 % ici) : c'est exactement la décision métier de L115 (§ 4.3). Depuis la version 1.5, `TunedThresholdClassifierCV` permet de régler ce seuil par validation croisée.

Remarquez aussi la syntaxe `étape__paramètre` (deux tirets bas) qui permet d'atteindre n'importe quel hyperparamètre au fond du pipeline, y compris dans le `ColumnTransformer` : `prep__num__imp__strategy` est un nom valide. `handle_unknown="ignore"` protège la production contre une catégorie inédite (un nouveau secteur « fleuriste » ajouté par le commercial) qui ferait sinon planter `predict`.

```quiz
{
  "q": "En production, le modèle de churn reçoit un abonné du secteur « fleuriste », absent des données d'entraînement. Quelle option du pipeline évite que predict plante ?",
  "options": ["SimpleImputer(strategy=\"median\") sur la colonne secteur", "StandardScaler(with_mean=False)", "OneHotEncoder(handle_unknown=\"ignore\")", "GridSearchCV(refit=False)"],
  "answer": 2,
  "explanation": "Avec handle_unknown=\"ignore\", une catégorie inconnue est encodée par des zéros dans toutes les colonnes du one-hot au lieu de déclencher une erreur. L'imputation ne traite que les valeurs manquantes, pas les valeurs nouvelles."
}
```

> 🔗 **Documentation officielle** — [scikit-learn — Pipelines and composite estimators](https://scikit-learn.org/stable/modules/compose.html) 🇬🇧 · [Tuning the hyper-parameters of an estimator](https://scikit-learn.org/stable/modules/grid_search.html) 🇬🇧

```mission
{
  "title": "Comment atteindre un hyperparamètre au fond d'un pipeline ?",
  "url": "https://scikit-learn.org/stable/modules/compose.html",
  "steps": ["Ouvrez la page « Pipelines and composite estimators »", "Dans la section Pipeline, lisez la partie sur l'accès aux paramètres imbriqués (« Access to nested parameters »)", "Repérez la syntaxe utilisée dans l'exemple avec GridSearchCV"],
  "question": "Quelle syntaxe permet de régler le paramètre C d'une étape nommée « clf » dans un Pipeline, et peut-on aussi remplacer une étape entière par la recherche ?",
  "hint": "Deux tirets bas séparent le nom de l'étape et le nom du paramètre.",
  "answer": "La syntaxe <étape>__<paramètre>, ici clf__C ; et oui, on peut faire varier une étape entière en donnant une liste d'estimateurs au nom de l'étape (ex. « clf »: [SVC(), LogisticRegression()]), voire la désactiver avec 'passthrough'. Doc stable, nov. 2026.",
  "xp": 15
}
```

### 2.1 Grille, hasard ou divisions successives ?

`GridSearchCV` teste **toutes** les combinaisons : 4 valeurs × 4 valeurs × 3 valeurs × 5 plis = 240 entraînements. Au-delà de trois hyperparamètres, préférez `RandomizedSearchCV` avec des **distributions** (par exemple `scipy.stats.loguniform(1e-3, 1e2)` pour `C`) : Bergstra et Bengio (2012) ont montré qu'à budget égal la recherche aléatoire trouve d'aussi bons réglages, car seuls quelques hyperparamètres comptent vraiment. `HalvingGridSearchCV` et `HalvingRandomSearchCV` (encore marqués expérimentaux, à activer par `from sklearn.experimental import enable_halving_search_cv`) éliminent tôt les mauvais candidats en leur donnant d'abord peu de données.

> 🔢 **Exemple à la main** — Le nombre d'entraînements d'une grille est le **produit** du nombre de valeurs de chaque hyperparamètre, multiplié par le nombre de plis : $4 \times 4 \times 3 \times 5 = 240$. Ajoutez un 4e hyperparamètre à 5 valeurs et vous passez à $240 \times 5 = 1\,200$ : la grille explose vite, d'où l'intérêt de la recherche aléatoire, dont le budget (`n_iter`) est fixé d'avance. **loguniform(1e-3, 1e2)** tire des valeurs entre 0,001 et 100 réparties uniformément **en ordre de grandeur** : autant de chances de tomber entre 0,001 et 0,01 qu'entre 10 et 100.

> 💡 **Autrement dit** — La grille explore méthodiquement chaque case d'un quadrillage ; la recherche aléatoire lance des fléchettes au hasard sur la même cible. Comme seuls un ou deux réglages comptent vraiment, les fléchettes testent bien plus de valeurs différentes de ces réglages-là pour le même nombre d'essais.

### 2.2 La validation croisée imbriquée

`search.best_score_` est **légèrement optimiste** : c'est le meilleur de plusieurs scores, donc un maximum, biaisé vers le haut. Pour estimer honnêtement la performance de « la procédure entière, réglage compris », on emboîte la recherche dans une validation croisée externe : `cross_val_score(search, X, y, cv=outer_cv)`. C'est coûteux, mais c'est le chiffre à écrire dans un rapport quand vous n'avez pas de jeu de test séparé.

> 💡 **Autrement dit** — Si vous lancez 20 fois un dé et ne retenez que le meilleur lancer, vous surestimez « le dé moyen ». De même, le meilleur des scores de validation surestime un peu la performance réelle. La validation imbriquée refait tout le choix dans chaque pli externe pour mesurer la procédure entière, réglage compris.

## 3. Les fuites de données : quand le modèle triche

> 🧠 **L'intuition d'abord** — Une fuite, c'est un modèle qui **triche sans le savoir** : on lui a laissé un indice qui ne sera pas disponible le jour où il servira vraiment. **Analogie :** un élève qui révise avec des annales dont les réponses sont discrètement surlignées. Il obtient 19/20 à l'examen blanc, puis s'effondre à l'examen réel, où personne n'a surligné quoi que ce soit.

Une **fuite de données** (*data leakage*) survient quand une information indisponible au moment de la prédiction réelle s'invite dans l'entraînement ou l'évaluation. Le score est excellent, le modèle est inutile. Le guide officiel de scikit-learn y consacre une page entière (« Common pitfalls »), et le micro-cours Kaggle *Intermediate Machine Learning* en fait un chapitre. Quatre familles :

| Famille | Exemple en entreprise | Correction |
|---|---|---|
| **Prétraitement avant découpage** | `StandardScaler().fit(X)` sur tout le jeu, puis `train_test_split` | mettre le scaler dans le pipeline |
| **Sélection de variables avant validation** | garder les 20 variables les plus corrélées à $y$ sur tout le jeu, puis valider | `SelectKBest` dans le pipeline |
| **Fuite de cible** (*target leakage*) | prédire la résiliation avec la variable « date d'envoi du courrier de clôture » | supprimer toute variable connue seulement après l'événement |
| **Fuite temporelle ou de groupe** | lignes du même client ou de la même semaine dans train et test | `GroupKFold`, `TimeSeriesSplit` (L116) |

La deuxième famille est la plus sournoise, parce que le code « a l'air propre ». La démonstration suivante utilise des données de **bruit pur** : aucune variable n'a de lien avec la cible, la vraie exactitude atteignable est donc 50 %.

```python
"""Démonstration de fuite : sélection de variables hors pipeline sur du bruit pur."""
import numpy as np
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline

rng = np.random.default_rng(0)
X = rng.normal(size=(200, 5_000))       # 200 lignes, 5 000 variables de bruit
y = rng.integers(0, 2, 200)             # cible aléatoire : rien à apprendre

# ❌ Mauvais : la sélection "voit" toutes les cibles, y compris celles des plis de validation
X_sel = SelectKBest(f_classif, k=20).fit_transform(X, y)
fuite = cross_val_score(LogisticRegression(max_iter=1_000), X_sel, y, cv=5).mean()

# ✅ Correct : la sélection est refaite dans chaque pli, sur l'entraînement seulement
pipe = make_pipeline(SelectKBest(f_classif, k=20), LogisticRegression(max_iter=1_000))
propre = cross_val_score(pipe, X, y, cv=5).mean()

print(f"Exactitude avec fuite : {fuite:.2f}  (illusion)")
print(f"Exactitude sans fuite : {propre:.2f}  (réalité : hasard ≈ 0,50)")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — `X` a la forme `(200, 5000)` : bien plus de colonnes que de lignes. `SelectKBest(f_classif, k=20)` garde les 20 colonnes qui semblent les plus liées à `y` → `X_sel` `(200, 20)`. Dans la version fautive, ce tri a vu **toutes** les cibles avant la validation croisée ; dans le pipeline, il est refait à chaque pli sur les seules lignes d'entraînement. Sorties réelles avec cette graine : **0,79** avec fuite, **0,51** sans.

> 🔢 **Exemple à la main** — Pourquoi la fuite marche aussi bien sur du bruit ? Avec 200 lignes, la corrélation d'une colonne aléatoire avec `y` fluctue autour de 0 avec un écart-type d'environ $1/\sqrt{200} \approx 0{,}07$. Sur 5 000 colonnes, les plus chanceuses atteignent par hasard $0{,}20$ à $0{,}30$ (mesuré : 0,30 pour la meilleure, 0,20 pour la 20e) : assez pour « prédire » les lignes qui ont servi à les choisir. (Vérifié en Python.)

Avec la fuite, le modèle affiche une exactitude très supérieure au hasard sur des données qui n'en contiennent aucune : parmi 5 000 variables aléatoires, quelques-unes sont corrélées à $y$ **par chance**, et la sélection les a choisies en regardant les réponses de validation. Ce scénario (beaucoup de variables, peu de lignes) est courant en génomique, en marketing (milliers d'indicateurs comportementaux) et en finance.

```quiz
{
  "q": "Un modèle de prédiction de résiliation affiche une AUC de 0,99 grâce à une seule variable : « nombre de courriers de clôture envoyés ». Quel est le diagnostic le plus probable ?",
  "options": ["Une fuite de cible : variable connue après la résiliation", "Un excellent modèle, à déployer immédiatement en production", "Un sous-apprentissage dû à un manque de variables", "Un problème de standardisation des variables numériques"],
  "answer": 0,
  "explanation": "Le courrier de clôture est une conséquence de la résiliation, pas un signe avant-coureur. Au moment de prédire (avant l'événement), cette variable vaut toujours 0 : le modèle serait inutile en production."
}
```

> ⚠️ **Piège fréquent** — La fuite de cible déguisée en « super variable ». Si une seule variable donne à elle seule une AUC de 0,99, ne vous réjouissez pas : demandez **quand** elle est renseignée dans le système d'information. « Montant remboursé », « motif de clôture », « nombre de relances contentieuses » sont souvent remplis *après* l'événement que vous voulez prédire.

## 4. Écrire son propre transformateur

Quand une transformation métier n'existe pas (calculer un ratio, extraire le mois d'une date, appliquer une réduction de dimension maison comme le CSP de Total-Perspective-Vortex), écrivez une classe compatible. Trois règles : le constructeur ne fait que stocker ses arguments ; `fit` apprend et renvoie `self` ; ce qui est appris porte un tiret bas final.

```python
"""Transformateur personnalisé compatible Pipeline, GridSearchCV et clone()."""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin, clone
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline


class WinsorizerQuantiles(BaseEstimator, TransformerMixin):
    """Écrête chaque colonne entre deux quantiles appris sur l'entraînement."""

    def __init__(self, bas=0.01, haut=0.99):
        self.bas = bas          # aucun calcul ici : seulement stocker
        self.haut = haut

    def fit(self, X, y=None):
        X = np.asarray(X, dtype=float)
        self.bornes_basses_ = np.quantile(X, self.bas, axis=0)
        self.bornes_hautes_ = np.quantile(X, self.haut, axis=0)
        self.n_features_in_ = X.shape[1]
        return self

    def transform(self, X):
        X = np.asarray(X, dtype=float)
        return np.clip(X, self.bornes_basses_, self.bornes_hautes_)


rng = np.random.default_rng(1)
X = pd.DataFrame({"surface_m2": rng.normal(80, 25, 500), "pieces": rng.integers(1, 7, 500)})
y = 3_200 * X.surface_m2 + 8_000 * X.pieces + rng.normal(0, 20_000, 500)
X.loc[:2, "surface_m2"] = 9_999                     # 3 erreurs de saisie (0,6 %)

pipe = make_pipeline(WinsorizerQuantiles(0.01, 0.99), LinearRegression())
print("R² avec écrêtage :", cross_val_score(pipe, X, y, cv=5).mean().round(3))
print("R² sans écrêtage :", cross_val_score(LinearRegression(), X, y, cv=5).mean().round(3))
print("Paramètres exposés :", clone(pipe).get_params()["winsorizerquantiles__haut"])
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `__init__` se contente de ranger `bas` et `haut` (règle scikit-learn : aucun calcul ici).
> - `fit` : `np.quantile(X, 0.01, axis=0)` calcule, **colonne par colonne**, la valeur sous laquelle se trouvent 1 % des données → un tableau `(2,)` pour nos 2 colonnes ; idem pour 99 %. Le tiret bas final (`bornes_basses_`) signale « appris pendant `fit` ».
> - `transform` : `np.clip(X, bas, haut)` ramène toute valeur trop petite à la borne basse et toute valeur trop grande à la borne haute (les surfaces de 9 999 m² deviennent ≈ la valeur du 99e centile).
> - `clone(pipe).get_params()` montre que l'hyperparamètre est accessible sous le nom `winsorizerquantiles__haut`, donc réglable par `GridSearchCV`.

Hériter de `BaseEstimator` fournit gratuitement `get_params` et `set_params` (donc la compatibilité avec `GridSearchCV` et `clone`) ; `TransformerMixin` fournit `fit_transform`. La fonction `sklearn.utils.estimator_checks.check_estimator` permet de vérifier la conformité complète d'un estimateur maison avant de le partager.

> 💡 **Autrement dit** — Respecter la « grammaire » scikit-learn (stocker sans calculer dans `__init__`, apprendre dans `fit`, nommer avec `_` ce qui est appris) permet à votre pièce de Lego maison de s'emboîter partout : pipelines, recherche d'hyperparamètres, validation croisée.

## 5. Persister et déployer

Un modèle entraîné n'a de valeur que s'il peut être rechargé ailleurs (une API, un traitement nocturne, le poste du contrôleur de gestion). Trois options :

| Format | Pour | Contre |
|---|---|---|
| `joblib.dump` / `pickle` | standard, efficace pour les gros tableaux NumPy | **exécute du code au chargement** : ne jamais charger un fichier d'origine inconnue ; lié à la version de scikit-learn |
| `skops.io` | format sûr qui liste les types avant chargement | paquet supplémentaire (`pip install skops`) |
| ONNX (`skl2onnx`) | indépendant de Python, servi en C++, C#, JavaScript | tous les estimateurs ne sont pas convertibles |

```python
"""Sauvegarde et rechargement d'un pipeline, avec les métadonnées de reproductibilité."""
import json
import platform
import joblib
import sklearn
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_breast_cancer(return_X_y=True)
pipe = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2_000)).fit(X, y)

joblib.dump(pipe, "modele_v1.joblib")
with open("modele_v1.json", "w") as f:            # la "carte d'identité" du modèle
    json.dump({"sklearn": sklearn.__version__, "python": platform.python_version(),
               "n_features": int(pipe.n_features_in_), "jeu": "load_breast_cancer",
               "score_train": round(pipe.score(X, y), 4)}, f, indent=2)

charge = joblib.load("modele_v1.joblib")           # uniquement des fichiers que VOUS avez produits
assert (charge.predict(X) == pipe.predict(X)).all()
print("Modèle rechargé à l'identique ; scikit-learn", sklearn.__version__)
```

Bonne pratique : figez les versions (`requirements.txt` avec `scikit-learn==x.y.z`), enregistrez à côté du modèle la version, les données d'entraînement (empreinte ou date d'extraction) et les scores. Recharger un modèle avec une autre version de scikit-learn déclenche un avertissement `InconsistentVersionWarning` : prenez-le au sérieux. Le module M29 (inférence, déploiement et MLOps) prolonge ce sujet.

> 💡 **Autrement dit** — Un fichier `pickle`, c'est un colis qui contient non seulement le modèle, mais aussi des **instructions que Python exécute en ouvrant le colis**. Ouvrir un colis d'expéditeur inconnu, c'est potentiellement exécuter n'importe quoi sur votre machine.

```mission
{
  "title": "Les formats de sauvegarde recommandés par scikit-learn",
  "url": "https://scikit-learn.org/stable/model_persistence.html",
  "steps": ["Ouvrez la page « Model persistence » de scikit-learn", "Lisez le tableau ou le résumé qui compare les méthodes de persistance", "Repérez l'avertissement de sécurité sur pickle et les alternatives proposées"],
  "question": "Quel format la documentation présente-t-elle comme une alternative plus sûre à pickle pour charger un modèle d'origine non fiable, et lequel pour servir un modèle sans Python ?",
  "hint": "L'un est un paquet de l'écosystème Hugging Face / scikit-learn, l'autre un standard d'échange de modèles.",
  "answer": "skops.io (qui permet d'inspecter et de n'autoriser que des types de confiance avant chargement) ; ONNX (via skl2onnx) pour servir le modèle hors de Python. pickle/joblib ne doivent être chargés que s'ils viennent d'une source de confiance. Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

> 🎮 **Défi** — Dans le premier script, ajoutez `.set_output(transform="pandas")` au `ColumnTransformer`, puis affichez `search.best_estimator_["prep"].get_feature_names_out()`. Combien de colonnes le modèle voit-il vraiment après encodage ?

## 🧪 Exercice pratique

**Consigne.** Un collègue vous transmet ce code de prédiction de retards de paiement pour un cabinet d'expertise comptable. Trouvez et corrigez **toutes** les fuites et fragilités, puis réécrivez-le sous la forme d'un unique `Pipeline` réglé par `RandomizedSearchCV`.

```text
# Code à auditer (extrait volontairement incomplet : df n'est pas défini)
df["montant_std"] = (df.montant - df.montant.mean()) / df.montant.std()
df = pd.get_dummies(df, columns=["secteur"])
df["retard_moyen_client"] = df.groupby("client_id")["en_retard"].transform("mean")
best = SelectKBest(k=10).fit(df.drop(columns="en_retard"), df.en_retard)
X_tr, X_te, y_tr, y_te = train_test_split(best.transform(df.drop(columns="en_retard")), df.en_retard)
model = RandomForestClassifier().fit(X_tr, y_tr)
print(model.score(X_te, y_te))
```

**Critères de réussite.**
- Au moins cinq problèmes identifiés et expliqués en une phrase chacun.
- Le pipeline final contient l'imputation, l'encodage et la sélection éventuelle.
- Le découpage respecte les clients (aucun `client_id` à la fois en entraînement et en test).
- La métrique est adaptée à une classe minoritaire et les graines aléatoires sont fixées.

**Pistes de corrigé.** (1) La standardisation est calculée sur tout le jeu. (2) `get_dummies` hors pipeline casse en production si un secteur apparaît ou disparaît : `OneHotEncoder(handle_unknown="ignore")`. (3) `retard_moyen_client` est une **fuite de cible** : la moyenne inclut la ligne elle-même et les factures futures ; il faut la calculer uniquement sur les factures antérieures. (4) `SelectKBest` est ajusté sur toutes les cibles. (5) `train_test_split` aléatoire mélange les factures d'un même client : `GroupShuffleSplit` sur `client_id`, voire découpage temporel. (6) `score` renvoie l'exactitude, trompeuse si 8 % des factures sont en retard : utilisez AUC, rappel et précision. (7) Ni `random_state` ni `stratify`.

## ✅ Auto-évaluation express
1. Quelle est la différence entre `search.best_score_` et le score sur le jeu de test ?
2. Pourquoi `OneHotEncoder(handle_unknown="ignore")` est-il important en production ?
3. Un prestataire vous envoie un fichier `modele.pkl` par e-mail. Que faites-vous avant de le charger ?

**Réponses.** 1. `best_score_` est la moyenne de validation croisée du meilleur candidat : un maximum parmi plusieurs, donc optimiste ; le test, utilisé une seule fois, donne une estimation non biaisée. 2. Sans lui, une catégorie absente de l'entraînement provoque une erreur au `predict` ; avec lui, elle est encodée en zéros. 3. On ne le charge pas tel quel : `pickle` peut exécuter du code arbitraire. On demande un format sûr (skops, ONNX) ou les données et le code d'entraînement pour le reproduire soi-même, ou au minimum on l'inspecte dans un environnement isolé.

## 📚 Pour aller plus loin
- [scikit-learn — Common pitfalls and recommended practices](https://scikit-learn.org/stable/common_pitfalls.html) 🇬🇧 — prétraitement incohérent, fuites, contrôle de l'aléa : la page à relire avant chaque projet.
- [scikit-learn — Model persistence](https://scikit-learn.org/stable/model_persistence.html) 🇬🇧 — comparaison pickle, joblib, skops, ONNX et risques de sécurité.
- [scikit-learn — User Guide](https://scikit-learn.org/stable/user_guide.html) 🇬🇧 — la référence complète, exemples exécutables à chaque section.
- [Inria — Machine learning in Python with scikit-learn](https://inria.github.io/scikit-learn-mooc/) 🇬🇧 — le MOOC des créateurs de la bibliothèque, support libre (à confirmer sur la page : licence CC BY 4.0).
- [Google — Machine Learning Crash Course](https://developers.google.com/machine-learning/crash-course) 🇬🇧 — modules « Numerical Data » et « Categorical Data » sur la préparation des variables.

> ✅ **Si vous ne retenez que 3 choses** — 1. Tout ce qui apprend quelque chose des données (moyenne, catégories, sélection, imputation) va **dans** un `Pipeline` / `ColumnTransformer` : c'est ce qui empêche la plupart des fuites. 2. Réglez les hyperparamètres par `GridSearchCV` ou `RandomizedSearchCV` (syntaxe `étape__paramètre`) et n'utilisez le test qu'une fois ; méfiez-vous d'une « super variable » trop parfaite. 3. Ne chargez jamais un `pickle`/`joblib` d'origine inconnue, et enregistrez versions et scores à côté du modèle.

> 🗺️ **Et maintenant ?** — Vous avez toute la boîte à outils ; la leçon L120 la met en œuvre de bout en bout sur un vrai projet de prédiction, de l'exploration des données au rapport final pour le client.
