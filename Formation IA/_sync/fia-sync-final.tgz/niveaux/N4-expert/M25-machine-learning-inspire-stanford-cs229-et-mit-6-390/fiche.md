---
module: M25
title: "Fiche mémo — Machine learning (inspiré Stanford CS229 et MIT 6.390)"
---
# Fiche mémo — M25 · Machine learning (inspiré Stanford CS229 et MIT 6.390)

> En une phrase : un modèle supervisé, c'est une hypothèse, un coût et un optimiseur ; on le juge sur des données qu'il n'a jamais vues, avec un protocole sans fuite et une métrique choisie avant les résultats.

## Les 7 idées à retenir
1. Régressions linéaire et logistique ont le même gradient $\frac1m X^\top(\hat y - y)$ ; seule la fonction de lien change (`L115`).
2. Standardiser avant la descente de gradient ; mettre à jour tous les $\theta$ simultanément (`L115`).
3. Sur données déséquilibrées, l'exactitude ment : rappel, précision, F1, AUC ; le seuil est une décision métier (`L115`).
4. Erreur d'entraînement haute = biais ; écart entraînement/validation = variance ; remèdes opposés (`L116`).
5. Forêt : arbres profonds en parallèle, la variance baisse ; boosting : petits arbres en série, le biais baisse (`L117`).
6. PCA = SVD des données centrées ; t-SNE et UMAP sont des cartes de voisinage, pas des mesures (`L118`).
7. Toute étape qui apprend des données vit dans le `Pipeline` ; le test scellé ne sert qu'une fois (`L119`, `L120`).

## Le schéma à connaître
```mermaid
flowchart LR
  C["1. Cadrage : métrique et critère fixés"] --> E["2. EDA sur l'entraînement"]
  E --> P["3. Protocole : test scellé + CV"]
  P --> M["4. Modèles + baseline, mêmes plis"]
  M --> S["5. Seuil hors test"]
  S --> T["6. Test unique + rapport"]
  E -. "itérations avant le test" .-> C
```

## Les formules essentielles
| Formule | Intuition en mots simples |
|---|---|
| $J = -\frac1m\sum\big[y\log\hat p + (1-y)\log(1-\hat p)\big]$ | La BCE punit le modèle d'autant plus qu'il était sûr de lui et se trompait. |
| $\theta = (X^\top X)^{-1}X^\top y$ | La solution exacte de la régression linéaire : votre descente de gradient doit la retrouver. |
| $\mathbb{E}[(y-\hat f)^2] = \text{biais}^2 + \text{variance} + \sigma^2$ | Se tromper en moyenne, être instable, ou subir un bruit que personne ne peut battre. |
| $J_{\text{Ridge}} = \frac{1}{2m}\|X\theta-y\|^2 + \frac{\lambda}{2}\|\theta\|_2^2$ | On paie pour les gros coefficients ; avec $L_1$ (Lasso), certains tombent exactement à zéro. |
| $\text{Gini} = 1 - \sum_k p_k^2$ | Le désordre d'un nœud : 0 si une seule classe, 0,5 pour un 50/50. |
| $\text{Var} = \rho\sigma^2 + \frac{1-\rho}{B}\sigma^2$ | Moyenner des arbres aide, mais seulement s'ils sont décorrélés. |
| $F_t = F_{t-1} + \eta\,h_t$ | Chaque petit arbre corrige les résidus laissés par les précédents. |
| $\text{var}_j = s_j^2/(m-1)$ | La part de dispersion captée par chaque axe de la PCA. |
| $F_1 = 2PR/(P+R)$ | Moyenne harmonique : elle punit un déséquilibre entre précision et rappel. |

## Vocabulaire express
| Terme | En clair |
|---|---|
| OOB | Les ~37 % de lignes qu'un arbre n'a pas vues : une validation gratuite. |
| MDI | Importance par baisse d'impureté : gratuite, mais biaisée. |
| Silhouette | Un point est-il plus proche de son groupe que du voisin ? |
| Fuite de cible | Variable connue seulement après l'événement à prédire. |
| CV imbriquée | Régler et estimer sans prendre le meilleur score pour la vérité. |

## Les pièges classiques
- Standardiser ou sélectionner les variables sur tout le jeu avant le découpage.
- `KFold` mélangé sur une série temporelle : utilisez `TimeSeriesSplit` ; plusieurs lignes par client : `GroupKFold`.
- Régulariser ou lancer k-means sans standardiser.
- Croire `feature_importances_` : une colonne de bruit peut arriver en tête ; préférez la permutation.
- Charger un `pickle` d'origine inconnue : il exécute du code.
- Baisser le seuil en regardant le test.

## Les commandes / chiffres / dates utiles
```python
pipe = Pipeline([("prep", preprocess), ("model", LogisticRegression(max_iter=2_000))])
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
search = GridSearchCV(pipe, {"model__C": [0.01, 0.1, 1, 10]}, cv=cv, scoring="roc_auc").fit(X_tr, y_tr)
HistGradientBoostingClassifier(learning_rate=0.05, max_iter=500, early_stopping=True)
permutation_importance(rf, X_te, y_te, scoring="roc_auc", n_repeats=20, random_state=0)
```
- scikit-learn : `alpha` = $\lambda$ ; `LogisticRegression` prend `C` = $1/\lambda$.
- Boosting : `learning_rate` 0,03 à 0,1 avec arrêt précoce, `max_depth` 3 à 8.
- Forêt : `max_features` ≈ $\sqrt{p}$ ; chaque arbre voit ~63 % des lignes ($1 - 1/e$).
- Grille d'épreuve C4.2 sur 100 points ; une fuite avérée est éliminatoire.

## Pour aller plus loin
- [Stanford CS229 — Machine Learning](https://cs229.stanford.edu/)
- [scikit-learn — Common pitfalls and recommended practices](https://scikit-learn.org/stable/common_pitfalls.html)
- [scikit-learn — Cross-validation](https://scikit-learn.org/stable/modules/cross_validation.html)

## Auto-test (3 questions — réponses en bas de fiche)
1. AUC de 0,99 en entraînement et 0,71 en validation : biais ou variance ?
2. 50 lignes par client pour 400 clients : quel découpage de validation croisée ?
3. Pourquoi le Lasso annule-t-il des coefficients, contrairement à Ridge ?

---
**Réponses.** 1. Variance : plus de régularisation, modèle plus simple ou plus de données. 2. `GroupKFold` (ou `StratifiedGroupKFold`) groupé par client. 3. La boule $L_1$ a des coins sur les axes, où la perte la touche le plus souvent.
