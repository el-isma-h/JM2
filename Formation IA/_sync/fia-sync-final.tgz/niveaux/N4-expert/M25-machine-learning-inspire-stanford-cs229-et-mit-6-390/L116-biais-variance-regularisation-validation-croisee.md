---
id: L116
module: M25
level: N4
title: "Biais-variance, régularisation, validation croisée"
minutes: 60
objectives:
  - "Expliquer la décomposition biais-variance de l'erreur et la relier au sous- et au sur-apprentissage"
  - "Appliquer une régularisation L2 (Ridge), L1 (Lasso) ou Elastic Net et justifier le choix par l'interprétation bayésienne (lien M24)"
  - "Construire un protocole de validation croisée adapté aux données (k-fold, stratifiée, par groupes, temporelle)"
  - "Diagnostiquer un modèle à partir de courbes d'apprentissage et de validation"
skills: ["C4.2", "C4.1"]
sources:
  - { title: "Stanford CS229 — notes : Learning theory, regularization and model selection", url: "https://cs229.stanford.edu/", lang: "en" }
  - { title: "MIT 6.036 Introduction to Machine Learning (OCW, Fall 2020)", url: "https://live.ocw.mit.edu/courses/6-036-introduction-to-machine-learning-fall-2020", lang: "en" }
  - { title: "scikit-learn — Cross-validation: evaluating estimator performance", url: "https://scikit-learn.org/stable/modules/cross_validation.html", lang: "en" }
  - { title: "scikit-learn — Validation curves and learning curves", url: "https://scikit-learn.org/stable/modules/learning_curve.html", lang: "en" }
  - { title: "DeepLearning.AI — Machine Learning Specialization (cours 2, semaine 3)", url: "https://deeplearning.ai/courses/machine-learning-specialization", lang: "en" }
---

# Biais-variance, régularisation, validation croisée

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 25

## 🎯 Ce que vous saurez faire
- Écrire et commenter la décomposition $\text{erreur} = \text{biais}^2 + \text{variance} + \text{bruit}$, puis la mesurer par simulation.
- Choisir entre Ridge, Lasso et Elastic Net, et régler leur force $\lambda$ sans tricher.
- Mettre en place la bonne validation croisée : k-fold, stratifiée, par groupes ou temporelle.
- Lire une courbe d'apprentissage et décider s'il faut plus de données, un modèle plus riche ou plus de régularisation.

> 🧭 **En clair** — Un bon modèle n'est pas celui qui récite parfaitement ses exemples, c'est celui qui réussit **le jour de l'examen**, sur des cas qu'il n'a jamais vus. Deux défauts guettent : être trop simpliste (il rate tout, toujours de la même façon) ou apprendre par cœur (il connaît ses exemples, mais s'écroule face à la nouveauté). La **régularisation** est une ceinture de sécurité contre l'apprentissage par cœur : on « taxe » les modèles trop compliqués. Et la **validation croisée** est un examen blanc répété plusieurs fois, sur des questions mises de côté, pour mesurer honnêtement le niveau réel.

## 1. Le dilemme de l'élève qui révise

Imaginez deux candidats au code de la route. Le premier a retenu une règle unique : « dans le doute, je cède le passage ». Il se trompe régulièrement, mais toujours de la même façon : c'est un **biais** élevé. Le second a appris par cœur les 1 000 questions de son livre, avec leurs réponses. Il fait zéro faute sur le livre et s'effondre le jour de l'examen sur des photos qu'il n'a jamais vues : sa performance **varie** énormément selon les questions tirées. C'est une **variance** élevée.

Le machine learning tout entier est une recherche d'équilibre entre ces deux élèves. Stanford CS229 consacre une partie entière de ses notes à cette « théorie de l'apprentissage » ; Andrew Ng en fait le cœur de ses « conseils pratiques » (Machine Learning Specialization, cours 2, semaine 3), en répétant qu'un praticien efficace se distingue d'abord par sa capacité à **diagnostiquer** biais ou variance avant de toucher au code.

## 2. La décomposition biais-variance

> 🧠 **L'intuition d'abord** — L'erreur d'un modèle vient de trois sources qui s'additionnent : il **vise à côté** en moyenne (biais), il **tremble** d'un jeu de données à l'autre (variance), et la réalité elle-même est **imprévisible** en partie (bruit). **Analogie :** un tireur à l'arc. Biais = viseur mal réglé, toutes les flèches groupées mais à côté du centre. Variance = main qui tremble, flèches éparpillées autour du centre. Bruit = rafales de vent, que même le meilleur archer ne peut maîtriser.

Supposons que les données obéissent à $y = f(x) + \varepsilon$, avec un bruit $\varepsilon$ de moyenne nulle et de variance $\sigma^2$. On entraîne un modèle $\hat f_D$ sur un jeu d'entraînement $D$ tiré au hasard. Pour un point $x$ fixé, l'erreur quadratique attendue (sur les tirages de $D$ et de $\varepsilon$) se décompose exactement :

$$\mathbb{E}\big[(y - \hat f_D(x))^2\big] = \underbrace{\big(f(x) - \mathbb{E}_D[\hat f_D(x)]\big)^2}_{\text{biais}^2} + \underbrace{\mathbb{E}_D\big[(\hat f_D(x) - \mathbb{E}_D[\hat f_D(x)])^2\big]}_{\text{variance}} + \underbrace{\sigma^2}_{\text{bruit irréductible}}$$

> 🧭 **Pré-requis express** — **$f(x)$** est la « vraie » relation (inconnue), **$\hat f_D$** (« f chapeau indice D ») le modèle appris sur le jeu de données $D$. **$\mathbb{E}_D[\dots]$** est une espérance (L113) **sur les jeux de données** : « la moyenne que l'on obtiendrait si l'on refaisait l'entraînement sur des centaines de jeux $D$ différents ». Les accolades $\underbrace{\ \cdot\ }_{\text{nom}}$ ne font qu'étiqueter chaque morceau de la somme.

> 💡 **Autrement dit** — Erreur totale = (distance entre le centre de vos flèches et la cible)² + (dispersion de vos flèches) + (vent). On peut réduire les deux premiers termes, jamais le troisième.

> 🔢 **Exemple à la main** — En un point $x$, la vraie valeur est $f(x) = 10$ et le bruit a une variance $\sigma^2 = 4$. Quatre entraînements sur quatre jeux différents prédisent $12, 14, 12, 14$.
> 1. Prédiction moyenne : $13$ → biais² $= (10 - 13)^2 = 9$.
> 2. Variance des prédictions autour de 13 : $(1 + 1 + 1 + 1)/4 = 1$.
> 3. Erreur attendue : $9 + 1 + 4 = 14$.
>
> Contrôle direct : écarts au carré $(10 - 12)^2 = 4$ et $(10 - 14)^2 = 16$, moyenne $10 = 9 + 1$, plus le bruit $4$ : $14$. (Vérifié en Python.)

La démonstration tient en quatre lignes avec les outils de M24 L113 : on ajoute et on retranche $\mathbb{E}_D[\hat f_D(x)]$, on développe le carré, et les termes croisés s'annulent car l'espérance d'un écart à la moyenne est nulle. Trois enseignements :

- le **bruit** $\sigma^2$ est un plancher : aucun modèle ne fera mieux. Si vos ventes dépendent de la météo et que vous n'avez pas la météo, ce plancher est haut ;
- le **biais** mesure l'erreur « moyenne » du modèle : une droite pour une relation en cloche aura toujours tort ;
- la **variance** mesure la sensibilité au jeu d'entraînement : un polynôme de degré 15 sur 30 points change du tout au tout si l'on remplace trois points.

Vérifions-le numériquement : on tire 200 jeux d'entraînement, on entraîne trois polynômes et on mesure biais et variance.

```python
"""Mesure empirique du biais et de la variance de régressions polynomiales."""
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

rng = np.random.default_rng(0)
f = lambda x: np.sin(2 * np.pi * x)          # la "vraie" relation, inconnue en pratique
sigma = 0.3
x_test = np.linspace(0, 1, 100)

for degree in (1, 4, 15):
    preds = []
    for _ in range(200):                        # 200 jeux d'entraînement différents
        x = rng.uniform(0, 1, 30)
        y = f(x) + rng.normal(0, sigma, 30)
        model = make_pipeline(PolynomialFeatures(degree), StandardScaler(), LinearRegression())
        model.fit(x.reshape(-1, 1), y)
        preds.append(model.predict(x_test.reshape(-1, 1)))
    preds = np.array(preds)
    mean_pred = preds.mean(axis=0)
    bias2 = ((f(x_test) - mean_pred) ** 2).mean()
    var = preds.var(axis=0).mean()
    print(f"degré {degree:>2} : biais²={bias2:.3f}  variance={var:.3f}  "
          f"erreur attendue≈{bias2 + var + sigma**2:.3f}")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `np.linspace(0, 1, 100)` : 100 points régulièrement espacés entre 0 et 1, forme `(100,)`.
> - Pour chaque degré, 200 fois : on tire 30 points `x` `(30,)` et leurs `y` bruités, on entraîne un pipeline « polynôme → standardisation → régression ». `x.reshape(-1, 1)` transforme `(30,)` en `(30, 1)` : scikit-learn exige **un tableau à 2 dimensions** (lignes = exemples, colonnes = variables), le `-1` voulant dire « calcule toi-même ce nombre ».
> - `preds` devient un tableau `(200, 100)` : 200 modèles × 100 points de test. `preds.mean(axis=0)` fait la moyenne **des 200 modèles** en chaque point → `(100,)` ; `preds.var(axis=0)` leur dispersion ; on moyenne ensuite sur les 100 points.

Vous obtenez un biais énorme au degré 1 (sous-apprentissage, *underfitting*), un équilibre au degré 4, et une variance qui explose au degré 15 (sur-apprentissage, *overfitting*) : des dizaines de milliers de fois celle du degré 4 (≈ 774 contre ≈ 0,03 avec cette graine), à cause de polynômes qui s'envolent aux bords de l'intervalle, là où les points sont rares (ces quelques ajustements extrêmes font même grimper le biais² mesuré). La courbe classique « en U » de l'erreur de test en fonction de la complexité est sous vos yeux.

> 💡 **À retenir** — Erreur d'entraînement élevée → problème de **biais** (modèle trop simple, variables manquantes). Erreur d'entraînement faible mais erreur de validation élevée → problème de **variance** (modèle trop complexe, trop peu de données). Le remède est opposé dans les deux cas.

> ⚠️ **Piège fréquent** — Croire que le dilemme est une loi absolue. Les réseaux de neurones très surparamétrés présentent une « double descente » (*double descent*) où l'erreur de test redescend au-delà du point d'interpolation. Pour les modèles classiques de ce module, le U reste le bon guide (la double descente a été popularisée par Belkin et al., 2019).

```quiz
{
  "q": "Votre modèle de prévision des ventes fait 2 % d'erreur sur les données d'entraînement et 25 % sur les données de validation. Que faites-vous en premier ?",
  "options": ["Ajouter encore des variables et augmenter la complexité du modèle", "Rien : 2 % d'erreur en entraînement prouve que le modèle est excellent", "Retirer le jeu de validation, il est trop pessimiste", "Régulariser davantage, simplifier ou collecter plus de données"],
  "answer": 3,
  "explanation": "Erreur d'entraînement faible et de validation élevée : c'est de la variance (apprentissage par cœur). Le remède est de contraindre le modèle (régularisation, modèle plus simple) ou de lui donner plus d'exemples."
}
```

## 3. Régulariser : payer pour la complexité

### 3.1 Ridge (L2) et Lasso (L1)

> 🧠 **L'intuition d'abord** — La régularisation est une **ceinture de sécurité contre l'apprentissage par cœur** : on ajoute à la facture d'erreur une « taxe » proportionnelle à la taille des coefficients. Le modèle ne gonfle un coefficient que si cela réduit vraiment l'erreur, pas pour coller au moindre point bizarre. **Analogie :** un budget de voyage plafonné. Sans plafond, vous réservez l'hôtel le plus cher pour chaque caprice ; avec un plafond, vous ne dépensez que là où c'est vraiment utile.

Plutôt que de choisir le degré à la main, on garde un modèle riche et on **pénalise** les grands coefficients. Avec la norme $L_2$ (M24 L111), on obtient la **régression Ridge** (Hoerl et Kennard, 1970) :

$$J_{\text{Ridge}}(\theta) = \frac{1}{2m}\|X\theta - y\|_2^2 + \frac{\lambda}{2}\|\theta\|_2^2 \quad\Rightarrow\quad \theta^\star = (X^\top X + m\lambda I)^{-1}X^\top y$$

> 💡 **Autrement dit** — Ridge = « erreur habituelle + $\lambda$ × somme des carrés des coefficients ». Plus $\lambda$ est grand, plus la taxe est lourde et plus les coefficients sont rabotés vers zéro. $\lambda = 0$ : on retombe sur la régression ordinaire.

> 🧭 **Pré-requis express** — **$\|v\|_2^2$** est la norme $L_2$ **au carré** (L111), donc simplement la somme des carrés : $\|(3 ;\ 0{,}1)\|_2^2 = 9 + 0{,}01 = 9{,}01$. **$\|\theta\|_1$** est la somme des valeurs absolues : $3 + 0{,}1 = 3{,}1$. **$\lambda$** (lambda) est ici la **force de la pénalité** choisie par vous. **$\theta^\star$** (« thêta étoile ») désigne la meilleure valeur, la solution. $I$ est la matrice identité (L111).

Le terme $m\lambda I$ ajouté à $X^\top X$ a un bonus numérique : il rend la matrice toujours inversible, même quand deux variables sont parfaitement corrélées (le chiffre d'affaires HT et TTC d'une même facture, par exemple).

> 🔢 **Exemple à la main** — Une seule variable, sans constante : $x = (1, 2, 3)$, $y = (2, 4, 6)$. Dans ce cas la formule se réduit à $\theta^\star = \frac{\sum x_i y_i}{\sum x_i^2 + m\lambda}$.
> 1. $\sum x_i y_i = 2 + 8 + 18 = 28$ ; $\sum x_i^2 = 1 + 4 + 9 = 14$.
> 2. Sans pénalité ($\lambda = 0$) : $\theta^\star = 28/14 = 2$, la vraie pente.
> 3. Avec $m\lambda = 14$ : $\theta^\star = 28/28 = 1$ : le coefficient est « raboté » de moitié.
>
> (Vérifié en Python.)

> 🧠 **L'intuition d'abord** — Le Lasso taxe la **valeur absolue** des coefficients plutôt que leur carré. Résultat : pour les variables peu utiles, il préfère payer zéro en les **supprimant complètement**. **Analogie :** Ridge, c'est un régime qui fait maigrir toutes les dépenses un peu ; Lasso, c'est un grand ménage qui résilie franchement les abonnements inutiles et garde les autres.

Avec la norme $L_1$, on obtient le **Lasso** (Tibshirani, 1996) :

$$J_{\text{Lasso}}(\theta) = \frac{1}{2m}\|X\theta - y\|_2^2 + \lambda\|\theta\|_1$$

Le Lasso n'a pas de solution analytique (la valeur absolue n'est pas dérivable en 0), mais il a une propriété précieuse : il met **exactement à zéro** les coefficients inutiles. Géométriquement, la boule $L_1$ est un losange dont les sommets sont sur les axes ; les ellipses de niveau de la MSE la touchent le plus souvent en un sommet, donc avec des coordonnées nulles. Ridge, dont la boule est ronde, réduit tout sans rien annuler. L'**Elastic Net** combine les deux.

> 💡 **Autrement dit** — Besoin de savoir **quelles** variables comptent vraiment (rapport au client, coût de collecte) ? Lasso. Beaucoup de variables corrélées qui comptent toutes un peu ? Ridge. Entre les deux ? Elastic Net.

> 🔢 **Exemple à la main** — Pourquoi le Lasso annule et Ridge non : prenez deux coefficients, $3$ et $0{,}1$. Ramener le petit de $0{,}1$ à $0$ fait économiser, en Ridge, $0{,}1^2 = 0{,}01$ de pénalité (presque rien, donc Ridge le laisse vivre) ; en Lasso, $|0{,}1| = 0{,}1$, soit **dix fois plus** : le Lasso a intérêt à le supprimer dès qu'il n'apporte pas au moins autant d'erreur en moins. (Vérifié en Python.)

```quiz
{
  "type": "vrai_faux",
  "q": "Vrai ou faux : sur 40 indicateurs comptables d'une PME, si vous voulez un modèle qui n'en garde qu'une poignée pour l'expliquer simplement au dirigeant, le Lasso est plus adapté que Ridge.",
  "options": ["Vrai", "Faux"],
  "answer": 0,
  "explanation": "Vrai. La pénalité L1 met exactement à zéro les coefficients des variables peu utiles : le modèle « sélectionne » lui-même un petit nombre d'indicateurs. Ridge réduirait les 40 sans en annuler aucun."
}
```

| | Ridge (L2) | Lasso (L1) | Elastic Net |
|---|---|---|---|
| Effet sur les coefficients | tous réduits, aucun nul | beaucoup exactement nuls | intermédiaire |
| Variables corrélées | les partage | en garde une au hasard | les garde en groupe |
| Sélection de variables | non | oui | oui |
| Prior bayésien (M24 L113) | gaussien | de Laplace | mélange |
| Classe scikit-learn | `Ridge`, `RidgeCV` | `Lasso`, `LassoCV` | `ElasticNet`, `ElasticNetCV` |

### 3.2 Pourquoi c'est du bayésien déguisé

> 🧠 **L'intuition d'abord** — Avant même de voir les données, on a une opinion : « les effets sont probablement petits ». La régularisation n'est que la traduction mathématique de ce préjugé raisonnable. **Analogie :** un recruteur qui part du principe qu'un candidat est « dans la moyenne » et n'en change que face à des preuves solides. Plus $\lambda$ est grand, plus il faut de preuves pour le convaincre.

Le **maximum a posteriori** (MAP) prolonge le maximum de vraisemblance vu en M24 L113 en ajoutant un a priori sur les paramètres : $\theta_{\text{MAP}} = \arg\max_\theta \log p(y \mid X, \theta) + \log p(\theta)$. Si l'on suppose un a priori gaussien $\theta_j \sim \mathcal N(0, \tau^2)$, $\log p(\theta)$ vaut $-\|\theta\|_2^2/(2\tau^2)$ à une constante près : c'est la pénalité Ridge. Avec un a priori de Laplace, on retrouve la pénalité $L_1$. **Régulariser, c'est déclarer qu'on croit a priori que les effets sont petits.** Un $\lambda$ grand exprime une croyance forte.

> 🧭 **Pré-requis express** — **$\arg\max_\theta$** : « la valeur de $\theta$ qui rend l'expression la plus grande » (comme `argmax` en NumPy, mais sur toutes les valeurs possibles de $\theta$). **$\log p(\theta)$** mesure à quel point des paramètres $\theta$ semblent plausibles **avant** d'avoir vu les données (l'**a priori**). **$\tau$** (tau) est la largeur de cet a priori : $\tau$ petit = « je crois fort que les effets sont proches de 0 ». La loi de **Laplace** est une cousine de la gaussienne, plus pointue en 0.

Dans le code ci-dessous, sur le jeu *Diabetes* (442 patients, 10 variables), observez combien de coefficients le Lasso annule quand $\lambda$ augmente. Notez que scikit-learn appelle $\lambda$ `alpha`, et que `LogisticRegression` utilise l'inverse `C` $= 1/\lambda$ : grand `C` = peu de régularisation.

```python
"""Ridge vs Lasso : effet de la force de régularisation sur les coefficients."""
import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.linear_model import Lasso, Ridge
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_diabetes(return_X_y=True, as_frame=True)

print(f"{'alpha':>8} | {'Ridge R² (CV)':>13} | {'Lasso R² (CV)':>13} | coefs nuls Lasso")
for alpha in (0.01, 0.1, 1, 10, 100):
    ridge = make_pipeline(StandardScaler(), Ridge(alpha=alpha))
    lasso = make_pipeline(StandardScaler(), Lasso(alpha=alpha, max_iter=10_000))
    r_ridge = cross_val_score(ridge, X, y, cv=5, scoring="r2").mean()
    r_lasso = cross_val_score(lasso, X, y, cv=5, scoring="r2").mean()
    n_zero = int(np.sum(lasso.fit(X, y)[-1].coef_ == 0))
    print(f"{alpha:>8} | {r_ridge:>13.3f} | {r_lasso:>13.3f} | {n_zero}/10")

lasso = make_pipeline(StandardScaler(), Lasso(alpha=5)).fit(X, y)
kept = [c for c, w in zip(X.columns, lasso[-1].coef_) if w != 0]
print("Variables conservées par le Lasso (alpha=5) :", kept)
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `load_diabetes(..., as_frame=True)` renvoie `X` sous forme de tableau pandas `(442, 10)` (avec des noms de colonnes) et `y` `(442,)`.
> - `make_pipeline(StandardScaler(), Ridge(alpha=alpha))` enchaîne standardisation puis modèle ; `alpha` est le $\lambda$ du texte.
> - `cross_val_score(..., cv=5, scoring="r2")` renvoie **5 scores** (un par pli) ; `.mean()` en fait la moyenne.
> - `lasso.fit(X, y)[-1]` récupère la **dernière étape** du pipeline (le Lasso lui-même) ; `.coef_` est le tableau `(10,)` de ses coefficients, et `np.sum(coef_ == 0)` compte ceux qui valent exactement 0.
> - La dernière boucle `zip(X.columns, coef_)` associe chaque nom de variable à son coefficient pour n'afficher que les variables gardées.

> ⚠️ **Piège fréquent** — Régulariser sans standardiser. La pénalité porte sur la taille des coefficients ; si le salaire est en euros et l'ancienneté en années, le coefficient du salaire est minuscule par construction et échappe à la pénalité. Toujours `StandardScaler` avant Ridge, Lasso ou une régression logistique régularisée.

```mission
{
  "title": "Comment RidgeCV choisit-il alpha par défaut ?",
  "url": "https://scikit-learn.org/stable/modules/linear_model.html",
  "steps": ["Ouvrez la page « Linear Models » de scikit-learn", "Allez à la section Ridge, sous-section « Setting the regularization parameter: leave-one-out Cross-Validation »", "Lisez comment RidgeCV procède quand on ne lui fournit pas de paramètre cv"],
  "question": "Quelle stratégie de validation croisée RidgeCV utilise-t-il par défaut, et pourquoi est-elle rapide ?",
  "hint": "Le titre de la sous-section contient la réponse ; on parle aussi de « Generalized Cross-Validation ».",
  "answer": "Par défaut, RidgeCV utilise une validation croisée « leave-one-out » efficace (Generalized Cross-Validation, GCV), calculée de façon analytique sans réentraîner le modèle pour chaque exemple. Avec cv=k, il passe à un k-fold classique. Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 4. Valider sans se mentir

### 4.1 Trois jeux, trois rôles

Le **jeu d'entraînement** sert à apprendre les paramètres $\theta$. Le **jeu de validation** sert à choisir les hyperparamètres ($\lambda$, degré, profondeur d'arbre). Le **jeu de test** sert une seule fois, à la fin, à estimer la performance réelle. Si vous choisissez $\lambda$ en regardant le test, votre score de test devient optimiste : vous avez « appris » le test.

### 4.2 La validation croisée k-fold

> 🧠 **L'intuition d'abord** — Un seul examen blanc peut tomber, par chance, sur des questions faciles. On organise donc **plusieurs** examens blancs, chaque fois sur une part différente des données, et on fait la moyenne. **Analogie :** une dégustation à l'aveugle avec 5 jurys différents plutôt qu'un seul ; la note moyenne et son écart vous disent si le vin est vraiment bon ou si un jury a été trop indulgent.

Sur 442 patients, sacrifier 20 % pour la validation coûte cher et rend le score instable. La **validation croisée en k blocs** (*k-fold cross-validation*) découpe l'entraînement en $k$ parts, entraîne $k$ fois sur $k-1$ parts et évalue sur la part restante, puis moyenne :

```
Pli 1 : [VAL][ tr ][ tr ][ tr ][ tr ]
Pli 2 : [ tr ][VAL][ tr ][ tr ][ tr ]
Pli 3 : [ tr ][ tr ][VAL][ tr ][ tr ]     score = moyenne ± écart-type des 5
Pli 4 : [ tr ][ tr ][ tr ][VAL][ tr ]
Pli 5 : [ tr ][ tr ][ tr ][ tr ][VAL]     (le jeu de TEST reste à part)
```

> 🔢 **Exemple à la main** — 442 patients, $k = 5$ : chaque pli de validation contient environ $442/5 \approx 88$ patients, et chaque entraînement porte sur les $\approx 354$ autres. On entraîne donc **5 modèles** et l'on rapporte, par exemple, « R² = 0,48 ± 0,05 » (moyenne ± écart-type des 5 scores). Chaque patient sert exactement une fois en validation. (Vérifié en Python.)

Le choix du découpage dépend de la **structure des données**, et c'est là que se jouent la plupart des erreurs professionnelles :

| Situation | Découpage | Classe scikit-learn |
|---|---|---|
| Données i.i.d., régression | k-fold mélangé | `KFold(shuffle=True)` |
| Classification déséquilibrée | proportions de classes conservées | `StratifiedKFold` |
| Plusieurs lignes par client, patient, magasin | un groupe entier par pli | `GroupKFold`, `StratifiedGroupKFold` |
| Séries temporelles (ventes, trafic) | passé → futur, jamais l'inverse | `TimeSeriesSplit` |
| Choisir les hyperparamètres ET estimer la performance | validation croisée imbriquée | `GridSearchCV` dans `cross_val_score` |

> 🧭 **Pré-requis express** — **i.i.d.** signifie « indépendantes et identiquement distribuées » : chaque ligne est un tirage séparé, sans lien avec les autres (pas deux lignes du même client, pas d'ordre dans le temps), et toutes viennent de la même population. C'est l'hypothèse qui autorise à mélanger les lignes au hasard.

Exemple vécu : une enseigne de boulangeries prédit ses invendus par magasin et par jour. Avec un `KFold` mélangé, le modèle voit le mardi et le jeudi d'une semaine pour prédire le mercredi : score superbe, production catastrophique. Avec `TimeSeriesSplit`, le score baisse… et devient vrai.

> 💡 **Autrement dit** — La règle d'or : la validation doit **imiter l'usage réel**. Si demain le modèle prédira des clients jamais vus, la validation doit tester des clients jamais vus (`GroupKFold`). S'il prédira le futur, elle doit tester le futur à partir du passé uniquement (`TimeSeriesSplit`).

```quiz
{
  "q": "Une mutuelle prédit le risque d'hospitalisation à partir de 5 ans de dossiers, avec plusieurs lignes par adhérent (une par année). Quel découpage de validation croisée choisissez-vous ?",
  "options": ["KFold(shuffle=True), le plus simple et le plus courant", "GroupKFold, groupé par identifiant d'adhérent", "Aucun : on évalue sur les données d'entraînement", "StratifiedKFold sur l'année de chaque dossier, pour équilibrer"],
  "answer": 1,
  "explanation": "Avec plusieurs lignes par adhérent, un découpage mélangé met le même adhérent des deux côtés : le modèle le « reconnaît » et le score est trop optimiste. GroupKFold garantit qu'un adhérent est entièrement en entraînement ou entièrement en validation."
}
```

> 🔗 **Documentation officielle** — [scikit-learn — Cross-validation: evaluating estimator performance](https://scikit-learn.org/stable/modules/cross_validation.html) 🇬🇧 (schémas de chaque stratégie de découpage).

```mission
{
  "title": "Le découpage caché derrière cv=5",
  "url": "https://scikit-learn.org/stable/modules/cross_validation.html",
  "steps": ["Ouvrez la page « Cross-validation: evaluating estimator performance »", "Lisez la section « Computing cross-validated metrics » sur cross_val_score", "Repérez la note qui explique quelle stratégie est utilisée quand cv est un entier"],
  "question": "Quand vous écrivez cross_val_score(clf, X, y, cv=5) avec un classifieur, quel type de découpage scikit-learn utilise-t-il, et les données sont-elles mélangées ?",
  "hint": "Pour un classifieur, scikit-learn tient à conserver les proportions de classes dans chaque pli.",
  "answer": "Un StratifiedKFold à 5 plis (KFold pour un régresseur), sans mélange par défaut (shuffle=False) ; pour mélanger, il faut passer explicitement cv=StratifiedKFold(5, shuffle=True, random_state=…). Doc stable, nov. 2026 (vérifié le 5 nov. 2026).",
  "xp": 15
}
```

## 5. Courbes d'apprentissage et de validation

Deux graphiques suffisent pour savoir quoi faire ensuite :

- la **courbe de validation** : score d'entraînement et de validation en fonction d'un hyperparamètre (la complexité). Elle montre le U du §2 et le bon réglage ;
- la **courbe d'apprentissage** : les mêmes scores en fonction de la **taille du jeu d'entraînement**. Si les deux courbes se rejoignent à un niveau médiocre, c'est du biais : plus de données n'aidera pas, il faut un modèle plus riche ou de meilleures variables. Si un écart persiste entre elles, c'est de la variance : plus de données ou plus de régularisation aideront.

```python
"""Courbe de validation (complexité) et courbe d'apprentissage (taille des données)."""
import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, learning_curve, validation_curve
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_breast_cancer(return_X_y=True)
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=5_000))

Cs = np.logspace(-4, 4, 17)                    # C = 1/lambda
tr, va = validation_curve(model, X, y, param_name="logisticregression__C",
                          param_range=Cs, cv=cv, scoring="roc_auc")
best = Cs[va.mean(axis=1).argmax()]
print(f"Meilleur C ≈ {best:.3g} (AUC validation {va.mean(axis=1).max():.4f})")

sizes, tr_l, va_l = learning_curve(make_pipeline(StandardScaler(), LogisticRegression(C=best, max_iter=5_000)),
                                   X, y, cv=cv, scoring="roc_auc",
                                   train_sizes=np.linspace(0.1, 1.0, 8))

fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4))
a1.semilogx(Cs, tr.mean(axis=1), label="entraînement")
a1.semilogx(Cs, va.mean(axis=1), label="validation")
a1.set(xlabel="C (inverse de la régularisation)", ylabel="ROC AUC", title="Courbe de validation")
a2.plot(sizes, tr_l.mean(axis=1), "o-", label="entraînement")
a2.plot(sizes, va_l.mean(axis=1), "o-", label="validation")
a2.set(xlabel="taille du jeu d'entraînement", title="Courbe d'apprentissage")
for a in (a1, a2):
    a.legend(); a.grid(alpha=0.3)
fig.tight_layout(); fig.savefig("courbes_biais_variance.png", dpi=120)
print("Graphique enregistré : courbes_biais_variance.png")
```

> 🔍 **Ce que fait ce code, ligne par ligne** — 
> - `load_breast_cancer` : `X` `(569, 30)`, `y` `(569,)` (tumeur bénigne ou maligne).
> - `np.logspace(-4, 4, 17)` : 17 valeurs de `C` réparties **en échelle logarithmique** de $10^{-4}$ à $10^{4}$ (0,0001 ; 0,00032 ; 0,001 ; … ; 10 000), chaque valeur étant $\sqrt{10} \approx 3{,}16$ fois la précédente.
> - `validation_curve(..., param_name="logisticregression__C")` : le nom suit la convention « étape du pipeline (en minuscules) + deux tirets bas + paramètre ». Elle renvoie `tr` et `va` de forme `(17, 5)` : 17 valeurs de `C` × 5 plis ; `va.mean(axis=1)` moyenne sur les plis → `(17,)` ; `.argmax()` donne l'indice du meilleur `C`.
> - `learning_curve` réentraîne le modèle sur 10 %, 23 %, … 100 % des données (`np.linspace(0.1, 1.0, 8)`) ; `semilogx` trace avec un axe horizontal logarithmique.

À gauche, quand `C` est minuscule (régularisation écrasante), les deux scores sont bas : biais. Quand `C` est énorme, l'entraînement frôle 1 et la validation décroche légèrement : variance. Le sommet de la courbe de validation désigne le bon réglage.

> 💡 **Autrement dit** — Deux courbes basses et collées : le modèle est trop simple (biais), donnez-lui plus de liberté. Une courbe d'entraînement haute et une courbe de validation nettement plus basse : il apprend par cœur (variance), serrez la ceinture (régularisation) ou donnez-lui plus d'exemples.

> 🎮 **Défi** — Remplacez la régression logistique par `DecisionTreeClassifier` et faites varier `max_depth` de 1 à 20 dans `validation_curve`. À partir de quelle profondeur l'arbre commence-t-il à sur-apprendre ? Gardez la réponse pour L117.

## 🧪 Exercice pratique

**Consigne.** Une PME de livraison vous confie 24 mois de données journalières (nombre de colis, jour de la semaine, météo, promotions) pour prédire le volume du lendemain. Simulez ces données avec NumPy (tendance + saisonnalité hebdomadaire + bruit), puis : (1) comparez le R² moyen obtenu avec `KFold(shuffle=True)` et avec `TimeSeriesSplit(n_splits=5)` sur un modèle `Ridge` avec variables de jour encodées ; (2) choisissez `alpha` par `RidgeCV` ; (3) tracez la courbe d'apprentissage et concluez : faut-il collecter plus d'historique ?

**Critères de réussite.**
- Les deux protocoles sont exécutés sur exactement le même modèle et les mêmes variables.
- Vous expliquez par écrit (5 lignes) pourquoi le score `KFold` est optimiste.
- Le choix de `alpha` est fait sans jamais utiliser les 3 derniers mois, réservés au test final.
- La conclusion « biais » ou « variance » est justifiée par la forme des courbes.

**Pistes de corrigé.** Le `KFold` mélangé est optimiste parce que des jours voisins (fortement corrélés) se retrouvent de part et d'autre de la frontière entraînement/validation : le modèle « interpole » au lieu de prévoir. Ajoutez des variables décalées (*lags*, volume de la veille et de J-7) **calculées uniquement à partir du passé**. Si les courbes d'apprentissage convergent vers un R² modeste, la limite est le biais : enrichissez les variables (jours fériés, vacances scolaires) plutôt que l'historique.

## ✅ Auto-évaluation express
1. Votre modèle a 0,99 d'AUC en entraînement et 0,71 en validation. Biais ou variance ? Citez deux remèdes.
2. Pourquoi le Lasso produit-il des coefficients exactement nuls, contrairement à Ridge ?
3. Vous avez 50 lignes par client pour 400 clients. Quel découpage de validation croisée utilisez-vous ?

**Réponses.** 1. Variance (sur-apprentissage) : plus de régularisation, un modèle plus simple, plus de données ou moins de variables. 2. La boule $L_1$ a des « coins » sur les axes, où les contours de la perte la touchent le plus souvent ; le sous-gradient de $|\theta_j|$ permet de rester à 0. 3. `GroupKFold` (ou `StratifiedGroupKFold`) avec l'identifiant client comme groupe, pour qu'aucun client ne soit à la fois en entraînement et en validation.

## 📚 Pour aller plus loin
- [Stanford CS229 — Machine Learning](https://cs229.stanford.edu/) 🇬🇧 — notes « Learning theory » et « Regularization and model selection » (biais-variance, sélection de modèle, validation croisée).
- [MIT 6.036 Introduction to Machine Learning (OCW)](https://live.ocw.mit.edu/courses/6-036-introduction-to-machine-learning-fall-2020) 🇬🇧 — semaines « Regression » et régularisation, licence CC BY-NC-SA 4.0.
- [scikit-learn — Validation curves and learning curves](https://scikit-learn.org/stable/modules/learning_curve.html) 🇬🇧 — API `validation_curve`, `learning_curve` et leur lecture.
- [scikit-learn — Linear Models](https://scikit-learn.org/stable/modules/linear_model.html) 🇬🇧 — Ridge, Lasso, Elastic Net et leurs variantes `CV`.
- [Google — Machine Learning Crash Course](https://developers.google.com/machine-learning/crash-course) 🇬🇧 — module « Datasets, Generalization, and Overfitting ».

> ✅ **Si vous ne retenez que 3 choses** — 1. Erreur = biais² + variance + bruit : erreur d'entraînement haute → biais (modèle trop simple) ; écart entraînement/validation → variance (régularisez ou ajoutez des données). 2. Ridge rabote tous les coefficients, Lasso en met à zéro ; standardisez toujours avant, et réglez $\lambda$ (`alpha`, ou `C` = $1/\lambda$) par validation croisée. 3. La validation doit imiter l'usage réel : `StratifiedKFold`, `GroupKFold` ou `TimeSeriesSplit` selon la structure, et le jeu de test ne sert qu'une fois.

> 🗺️ **Et maintenant ?** — Vous savez diagnostiquer et contraindre un modèle linéaire ; la leçon L117 passe aux **arbres de décision** et à leurs ensembles (forêts aléatoires, gradient boosting), qui dominent encore les données tabulaires des entreprises.
