/** Test d'intégration : charge TOUT le contenu réel de la formation (CONTENT_DIR ou dossier parent). */
import { describe, expect, it } from "vitest";
import { buildExamOrder, seededRandom } from "@/domain/exam";
import { drawExamQuestionIds, questionsPerAttempt } from "@/domain/exam-draw";
import {
  extractHeadings,
  getExam,
  getExamQuestionsForAttempt,
  getFlatLessons,
  getLesson,
  getLessonNavigation,
  getCoreLevelIds,
  getLevel,
  getMemoModuleIds,
  getModule,
  getModuleMemo,
  getModuleMemos,
  getProgramme,
  getPublicExam,
  getPublicQuiz,
  getQuiz,
  getResourceLibrary,
  getStructure,
  headingPlainText,
  isSpecialisationLevel,
  parseLessonFile,
  parseMemoFile,
} from "./loader";

describe("contenu réel", () => {
  it("programme : au moins 4 niveaux (N1…N4 : 30 modules, 150 leçons), ids et niveaux uniques et ordonnés", () => {
    const prog = getProgramme();
    expect(prog.code).toBe("NF-IA-150");
    expect(prog.levels.length).toBeGreaterThanOrEqual(4);
    // Les niveaux sont N1, N2, … dans l'ordre (un niveau N5 et suivants peut être ajouté).
    expect(prog.levels.map((l) => l.id)).toEqual(prog.levels.map((_, i) => `N${i + 1}`));
    const firstFour = getStructure().levels.slice(0, 4);
    expect(firstFour.flatMap((l) => l.modules)).toHaveLength(30);
    expect(firstFour.flatMap((l) => l.modules.flatMap((m) => m.lessons))).toHaveLength(150);
    const ids = getFlatLessons().map((l) => l.id);
    expect(new Set(ids).size).toBe(ids.length);
    const modules = getStructure().levels.flatMap((l) => l.modules.map((m) => m.id));
    expect(new Set(modules).size).toBe(modules.length);
  });

  it("chaque leçon se charge, en-tête cohérent avec programme.json", () => {
    for (const ref of getFlatLessons()) {
      const lesson = getLesson(ref.id);
      expect(lesson, ref.id).not.toBeNull();
      expect(lesson!.id).toBe(ref.id);
      expect(lesson!.module).toBe(ref.moduleId);
      expect(lesson!.level).toBe(ref.levelId);
      expect(lesson!.body.startsWith("---")).toBe(false);
      expect(lesson!.headings.length).toBeGreaterThan(0);
    }
  });

  it("chaque module, quiz et examen se charge ; réponses dans les bornes", () => {
    for (const level of getProgramme().levels) {
      expect(getLevel(level.id)?.intro.length).toBeGreaterThan(0);
      for (const m of level.modules) {
        const mod = getModule(m.id)!;
        expect(mod.level).toBe(level.id);
        expect(mod.lessons.map((l) => l.id)).toEqual(m.lessons.map((l) => l.id));
        const quiz = getQuiz(m.id)!;
        expect(quiz.questions.length).toBeGreaterThanOrEqual(5);
        for (const q of quiz.questions) expect(q.answer).toBeLessThan(q.options.length);
      }
      // Un niveau de spécialisation peut être publié avant son examen (l'application affiche alors « bientôt disponible ») ;
      // les niveaux du tronc certifiant (N1 à N4) ont toujours le leur.
      const exam = getExam(level.id);
      if (!isSpecialisationLevel(level)) expect(exam, level.id).not.toBeNull();
      if (!exam) continue;
      // Banque à tirage (v1.3) : `bankSize` questions dans le fichier, `drawPerAttempt` (40) posées par tentative.
      expect(exam.questions.length, level.id).toBe(exam.bankSize ?? 40);
      expect(questionsPerAttempt(exam), level.id).toBe(40);
      expect(new Set(exam.questions.map((q) => q.id)).size, level.id).toBe(exam.questions.length);
      for (const q of exam.questions) expect(q.answer).toBeLessThan(q.options.length);
      if (exam.drawPerAttempt) {
        const drawn = drawExamQuestionIds(exam.questions, { competences: exam.competences, drawPerAttempt: exam.drawPerAttempt, rand: seededRandom(1) });
        expect(drawn, level.id).toHaveLength(exam.drawPerAttempt);
        const comps = new Set(drawn.map((id) => exam.questions.find((q) => q.id === id)!.competence));
        expect(comps.size, level.id).toBe(Object.keys(exam.competences).length);
      }
    }
  });

  it("versions publiques : ni answer ni explanation", () => {
    const pq = getPublicQuiz("M01")!;
    const pe = getPublicExam("N1")!;
    for (const q of [...pq.questions, ...pe.questions]) {
      expect(q).not.toHaveProperty("answer");
      expect(q).not.toHaveProperty("explanation");
    }
    const order = buildExamOrder(getExam("N1")!.questions, seededRandom(7));
    const shown = getExamQuestionsForAttempt("N1", order);
    expect(shown).toHaveLength(getExam("N1")!.questions.length);
    expect(JSON.stringify(shown)).not.toContain('"answer"');
  });

  it("navigation précédente / suivante", () => {
    const first = getLessonNavigation("L001")!;
    expect(first.prev).toBeNull();
    expect(first.next?.id).toBe("L002");
    const flat = getFlatLessons();
    const lastOfM01 = flat.filter((l) => l.moduleId === "M01").at(-1)!;
    const nav = getLessonNavigation(lastOfM01.id)!;
    expect(nav.isLastOfModule).toBe(true);
    expect(nav.next?.moduleId).toBe("M02");
    expect(getLessonNavigation(flat.at(-1)!.id)!.next).toBeNull();
    expect(getLesson("L999")).toBeNull();
  });

  it("parcours : tronc certifiant N1 à N4 (150 h), spécialisations à part", () => {
    const prog = getProgramme();
    expect(getCoreLevelIds().slice(0, 4)).toEqual(["N1", "N2", "N3", "N4"]);
    const coreHours = prog.levels.filter((l) => !isSpecialisationLevel(l)).reduce((s, l) => s + l.hours, 0);
    expect(coreHours).toBe(prog.totalHours);
    for (const l of prog.levels.filter(isSpecialisationLevel)) expect(Number(l.id.slice(1))).toBeGreaterThan(4);
  });

  it("fiches mémo : chaque fiche présente se charge, sans en-tête ni titre # de tête", () => {
    const ids = getMemoModuleIds();
    const memos = getModuleMemos();
    expect(memos.map((m) => m.moduleId)).toEqual([...ids]);
    for (const ref of memos) {
      const memo = getModuleMemo(ref.moduleId)!;
      expect(memo.levelId).toBe(ref.levelId);
      expect(memo.title.length).toBeGreaterThan(0);
      expect(memo.body.startsWith("---")).toBe(false);
      expect(/^#\s/.test(memo.body)).toBe(false);
    }
    expect(getModuleMemo("M99")).toBeNull();
  });

  it("bibliothèque de liens", () => {
    const lib = getResourceLibrary();
    expect(lib.sections.length).toBeGreaterThanOrEqual(20);
    expect(lib.linkCount).toBeGreaterThan(500);
    const link = lib.sections[0].subsections[0].links[0];
    expect(link.url).toMatch(/^https:\/\//);
  });
});

describe("analyse Markdown", () => {
  it("fiche mémo : titre de l'en-tête, sinon du # de tête, sinon titre de secours", () => {
    expect(parseMemoFile('---\nmodule: M01\ntitle: "Fiche mémo — A"\n---\n# Fiche mémo — M01 · A\n\n> En une phrase\n', "X")).toEqual({ title: "Fiche mémo — A", body: "> En une phrase\n" });
    expect(parseMemoFile("# Titre **gras**\n\n## Section\n", "X")).toEqual({ title: "Titre gras", body: "## Section\n" });
    expect(parseMemoFile("---\ntitle: [oups\n---\nTexte", "Secours")).toEqual({ title: "Secours", body: "Texte" });
  });
  it("front-matter + corps", () => {
    const { meta, body } = parseLessonFile('---\nid: L001\nmodule: M01\nlevel: N1\ntitle: "T"\nminutes: 40\n---\n\n# Titre\n', "x.md");
    expect(meta.id).toBe("L001");
    expect(body).toBe("# Titre\n");
  });
  it("titres : ancres façon rehype-slug, code ignoré, doublons suffixés", () => {
    const h = extractHeadings("## 1. Quatre **mots**\n```\n## pas un titre\n```\n## 1. Quatre mots\n### Sous `code`\n");
    expect(h).toEqual([
      { depth: 2, text: "1. Quatre mots", id: "1-quatre-mots" },
      { depth: 2, text: "1. Quatre mots", id: "1-quatre-mots-1" },
      { depth: 3, text: "Sous code", id: "sous-code" },
    ]);
    expect(headingPlainText("[Lien](https://x) et *emphase*")).toBe("Lien et emphase");
  });
});
