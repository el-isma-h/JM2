/** v1.4 : parcours métiers et examens blancs — analyse pure et contenu réel (dossiers parcours-metiers/, examens-blancs/). */
import { describe, expect, it } from "vitest";
import { extractLessonBlocks } from "@/lib/lesson-blocks";
import {
  getFlatLessons,
  getMetier,
  getMetierCatalog,
  getPracticeExam,
  getPracticeExams,
  getPracticeGuide,
  getPublicPracticeExam,
  parseMetierFile,
  parseMetierReadmeTable,
  parsePracticeGuide,
  practiceGuideSection,
} from "./loader";

const SAMPLE = `# Parcours métier — Juriste

> 🧭 Pour les **juristes** d'entreprise.

## 1. Ce que l'IA change

Texte (L021 « Cas »).

## 2. Parcours conseillé

**Socle N1** — 2 leçons

| Leçon | Titre | Durée (min) |
|---|---|---|
| L005 | Qu'est-ce qu'un **LLM** ? | 45 |
| L008 | Fenêtre de contexte | 40 |

**Facultatives** — 1 leçon

| Leçon | Titre | Durée (min) |
|---|---|---|
| L013 | Perplexity | 40 |
| L999 | Inconnue | 10 |

> ⏱ **Durée totale du parcours conseillé : 1 h 25** de leçons, **2 h 05** avec toutes les leçons facultatives.
`;

describe("analyse d'un parcours métier", () => {
  it("titre, public, leçons prioritaires / facultatives, durées", () => {
    const m = parseMetierFile(SAMPLE, "juriste", new Set(["L005", "L008", "L013"]));
    expect(m.title).toBe("Juriste");
    expect(m.summary).toBe("Pour les juristes d'entreprise.");
    expect(m.lessons.map((l) => [l.id, l.priority])).toEqual([
      ["L005", true],
      ["L008", true],
      ["L013", false],
    ]);
    expect(m.lessons[0]).toMatchObject({ title: "Qu'est-ce qu'un LLM ?", minutes: 45, group: "Socle N1" });
    expect([m.priorityDuration, m.fullDuration]).toEqual(["1 h 25", "2 h 05"]);
    expect(m.body.startsWith("> 🧭")).toBe(true);
    expect(m.headings.map((h) => h.text)).toEqual(["1. Ce que l'IA change", "2. Parcours conseillé"]);
  });

  it("tableau du README", () => {
    const t = parseMetierReadmeTable("| [RH](rh.md) | N1 · N2 (M11) | 14 h 50 | 21 h 20 |\n| Métier | x | y | z |");
    expect([...t.entries()]).toEqual([["rh", { scope: "N1 · N2 (M11)", priority: "14 h 50", full: "21 h 20" }]]);
  });
});

describe("parcours métiers (contenu réel)", () => {
  const catalog = getMetierCatalog();
  const known = new Set(getFlatLessons().map((l) => l.id));

  it("dix parcours, README exclu, introduction présente", () => {
    expect(catalog.metiers.length).toBeGreaterThanOrEqual(10);
    expect(catalog.metiers.some((m) => m.slug.toLowerCase() === "readme")).toBe(false);
    expect(catalog.intro.length).toBeGreaterThan(50);
  });

  it("chaque parcours : résumé, durées, leçons prioritaires connues, blocs quiz et mission valides", () => {
    for (const ref of catalog.metiers) {
      const m = getMetier(ref.slug)!;
      expect(m.summary, ref.slug).not.toBe("");
      expect(m.priorityDuration, ref.slug).toMatch(/\d+ h/);
      expect(m.priorityLessons, ref.slug).toBeGreaterThan(0);
      for (const l of m.lessons) expect(known.has(l.id), `${ref.slug} ${l.id}`).toBe(true);
      const blocks = extractLessonBlocks(m.body);
      expect(blocks.filter((b) => b.kind === "quiz" && b.quiz).length, ref.slug).toBeGreaterThanOrEqual(1);
      expect(blocks.filter((b) => b.kind === "mission" && b.mission).length, ref.slug).toBeGreaterThanOrEqual(1);
    }
    expect(getMetier("README")).toBeNull();
    expect(getMetier("../programme/programme")).toBeNull();
  });
});

describe("examens blancs (contenu réel)", () => {
  it("chaque examen se charge ; la version publique ne contient ni réponse ni explication", () => {
    const exams = getPracticeExams();
    expect(exams.length).toBeGreaterThanOrEqual(5);
    for (const ref of exams) {
      const full = getPracticeExam(ref.slug)!;
      expect(full.questions.length).toBe(ref.questionCount);
      expect(full.timeLimitMinutes).toBeGreaterThan(0);
      const domains = new Set(full.domaines.map((d) => d.nom));
      for (const q of full.questions) expect(domains.has(q.domaine), `${ref.slug} ${q.id}`).toBe(true);
      const pub = getPublicPracticeExam(ref.slug)!;
      for (const q of pub.questions) {
        expect(q).not.toHaveProperty("answer");
        expect(q).not.toHaveProperty("explanation");
      }
    }
    expect(getPracticeExam("../examens/N1-examen")).toBeNull();
  });

  it("README : avertissement, mode d'emploi, une section (conditions, liens officiels) par certification", () => {
    const guide = getPracticeGuide();
    expect(guide.warning).toMatch(/non officiels/);
    expect(guide.howTo).toMatch(/temps limité/);
    for (const ref of getPracticeExams()) {
      const s = practiceGuideSection(guide, ref.certification);
      expect(s, ref.slug).not.toBeNull();
      expect(s!.body).toMatch(/https:\/\//);
    }
  });

  it("découpage du README", () => {
    const g = parsePracticeGuide("# T\n\n## ⚠️ Avertissement\n\nA\n\n---\n\n## 1. Les examens\n\n### Mode d'emploi conseillé\n\n1. X\n\n---\n\n## 2. Google AI Essentials\n\nB\n");
    expect(g.warning).toBe("A");
    expect(g.howTo).toBe("1. X");
    expect(practiceGuideSection(g, "Google AI Essentials")?.body).toBe("B");
  });
});
