/**
 * Types du contenu de la formation (fichiers du dossier parent, voir FORMAT.md).
 * Ce fichier ne contient que des types : il peut être importé depuis un composant client (`import type`).
 *
 * Règle de sécurité : les types `Public*` ne contiennent NI `answer` NI `explanation`. Seuls eux peuvent être
 * passés en props à un composant client avant la soumission d'un quiz / examen.
 */

export type SourceRef = { title: string; url: string; lang?: string };

export type LessonRef = { id: string; title: string; minutes: number };

/** Module tel que résumé dans programme.json. */
export type ProgrammeModule = {
  id: string;
  title: string;
  hours: number;
  minutes: number;
  quizMinutes: number;
  lessons: LessonRef[];
};

/** Parcours d'un niveau : « core » = tronc certifiant (150 h, N1 à N4) ; « specialisation » = niveau optionnel (N5…). */
export type LevelTrack = "core" | "specialisation";

export type ProgrammeLevel = {
  id: string; // "N1"
  code: string; // "NF-IA-N1"
  title: string;
  hours: number;
  /** `track` de programme.json (absent → « core »). */
  track: LevelTrack;
  audience: string;
  prerequisites: string;
  certificate: string;
  alignedWith: string[];
  examMinutes: number;
  modules: ProgrammeModule[];
};

export type Programme = {
  code: string; // "NF-IA-150"
  title: string;
  subtitle: string;
  version: string;
  versionDate: string;
  language: string;
  organisme: string;
  totalHours: number;
  /** Heures des niveaux de spécialisation (hors `totalHours` certifiantes) ; 0 si absent. */
  specialisationHours: number;
  modality: string;
  passScore: number;
  quizPerModule: number;
  examPerLevel: number;
  levels: ProgrammeLevel[];
};

/** module.json (métadonnées détaillées d'un module). */
export type ModuleMeta = {
  id: string;
  level: string;
  title: string;
  minutes: number;
  description: string;
  objectives: string[];
  skills: string[];
  alignedWith: string[];
  sources: SourceRef[];
  lessons: (LessonRef & { file: string })[];
};

export type ModuleDetail = ModuleMeta & {
  /** Position 1-based dans le niveau / dans la formation. */
  indexInLevel: number;
  globalIndex: number;
  quizMinutes: number;
  hasQuiz: boolean;
  /** Fiche mémo `fiche.md` présente (v1.2). */
  hasMemo: boolean;
};

/** En-tête YAML d'une leçon. */
export type LessonFrontMatter = {
  id: string;
  module: string;
  level: string;
  title: string;
  minutes: number;
  objectives: string[];
  skills: string[];
  sources: SourceRef[];
};

export type Heading = { depth: 2 | 3; text: string; id: string };

export type Lesson = LessonFrontMatter & {
  /** Corps Markdown, en-tête YAML retiré. */
  body: string;
  /** Titres h2 (et h3) pour le sommaire ; `id` = ancre générée par rehype-slug. */
  headings: Heading[];
  /** Nombre de mots (indicatif). */
  wordCount: number;
  /** Position 1-based dans le module et dans la formation. */
  indexInModule: number;
  globalIndex: number;
};

export type LessonNavigation = {
  prev: (LessonRef & { moduleId: string; levelId: string }) | null;
  next: (LessonRef & { moduleId: string; levelId: string }) | null;
  /** Vrai si la leçon est la dernière de son module (le quiz du module vient ensuite). */
  isLastOfModule: boolean;
  moduleId: string;
  levelId: string;
};

export type QuestionType = "qcm" | "vrai_faux" | "trouve_erreur" | "mise_en_situation";

/** Question complète (serveur uniquement). */
export type QuizQuestion = {
  id: string;
  lessonId: string;
  type: QuestionType;
  q: string;
  options: string[];
  /** Index 0-based de la bonne réponse. */
  answer: number;
  explanation: string;
  source?: SourceRef;
};

export type Quiz = { moduleId: string; title: string; passScore: number; questions: QuizQuestion[] };

export type PublicQuizQuestion = Omit<QuizQuestion, "answer" | "explanation">;
export type PublicQuiz = Omit<Quiz, "questions"> & { questions: PublicQuizQuestion[] };

export type ExamQuestion = QuizQuestion & { competence: string };

export type Exam = {
  levelId: string;
  title: string;
  passScore: number;
  timeLimitMinutes: number;
  /** Compétence → ids de questions. */
  competences: Record<string, string[]>;
  questions: ExamQuestion[];
  /** Banque de questions (v1.3) : taille annoncée de la banque (informatif). */
  bankSize?: number;
  /** Banque de questions (v1.3) : nombre de questions tirées à chaque tentative (stratifié par compétence). Absent : toutes. */
  drawPerAttempt?: number;
};

export type PublicExamQuestion = Omit<ExamQuestion, "answer" | "explanation">;
export type PublicExam = Omit<Exam, "questions"> & { questions: PublicExamQuestion[] };

/** Présentation d'un niveau (niveau.md + programme.json). */
export type LevelDetail = ProgrammeLevel & {
  index: number; // 1-based
  /** Corps Markdown de niveaux/Nx-…/niveau.md (vide si absent). */
  intro: string;
  lessonsCount: number;
};

/** Bibliothèque de liens (ressources/bibliotheque-liens.md). */
export type ResourceLink = { title: string; url: string; flag: string | null; description: string };
export type ResourceSubsection = { id: string; title: string; links: ResourceLink[] };
export type ResourceSection = { id: string; title: string; intro: string; subsections: ResourceSubsection[] };
export type ResourceLibrary = {
  /** Markdown complet (pour un rendu brut). */
  markdown: string;
  /** Texte d'introduction (avant la 1re section). */
  intro: string;
  sections: ResourceSection[];
  linkCount: number;
};

/** Terme du lexique (glossaire/glossaire.json, FORMAT.md § Lexique). */
export type GlossaryTerm = {
  terme: string;
  slug: string;
  categorie: string;
  /** « N1 »… ou chaîne vide si non précisé. */
  niveau: string;
  definition: string;
  analogie: string | null;
  exemple: string | null;
  voirAussi: string[];
  lecons: string[];
  source: SourceRef | null;
};

export type Glossary = {
  terms: GlossaryTerm[];
  /** missing : fichier absent ; invalid : JSON illisible ; ok sinon (les entrées invalides sont ignorées). */
  status: "ok" | "missing" | "invalid";
  skipped: number;
};

/** Fiche mémo de module (niveaux/Nx-…/Mxx-…/fiche.md, FORMAT.md § 5). */
export type ModuleMemo = {
  moduleId: string;
  levelId: string;
  /** Titre de l'en-tête YAML (sinon le titre # du fichier, sinon « Fiche mémo — titre du module »). */
  title: string;
  /** Corps Markdown, en-tête YAML et titre # de tête retirés (le titre est affiché par la page). */
  body: string;
  headings: Heading[];
  wordCount: number;
};

/** Entrée de la liste des fiches (page /fiches). */
export type ModuleMemoRef = { moduleId: string; levelId: string; title: string; moduleTitle: string; wordCount: number };

// ---------- Parcours métiers (v1.4 : parcours-metiers/*.md) ----------

/** Leçon citée dans la section « Parcours conseillé » d'un parcours métier. */
export type MetierLesson = {
  id: string;
  title: string;
  minutes: number;
  /** Prioritaire (socle, prioritaires) ou facultative. */
  priority: boolean;
  /** Libellé du groupe tel qu'écrit dans le fichier (« Socle N1 », « Prioritaires N2 », « Facultatives »…). */
  group: string;
};

/** Entrée de la liste des parcours métiers (/metiers). */
export type MetierRef = {
  slug: string;
  /** Intitulé du métier (titre « # Parcours métier — … » sans le préfixe). */
  title: string;
  /** Public visé : encadré 🧭 en tête du fichier, texte brut. */
  summary: string;
  /** Durée du parcours prioritaire et avec facultatives (« 14 h 50 »), lues dans le fichier (⏱) ou le README. */
  priorityDuration: string;
  fullDuration: string;
  /** Niveaux et modules mobilisés (colonne du README), ex. « N1 · N2 (M11, M12, M15) ». */
  scope: string;
  priorityLessons: number;
  optionalLessons: number;
};

export type Metier = MetierRef & {
  /** Corps Markdown, titre # de tête retiré. */
  body: string;
  headings: Heading[];
  lessons: MetierLesson[];
  wordCount: number;
};

export type MetierCatalog = {
  metiers: MetierRef[];
  /** Introduction : paragraphes du README.md avant la première section « ## » (vide si absent). */
  intro: string;
  /** Section « Ce que contient chaque fichier » du README (Markdown, titre retiré ; vide si absente). */
  contents: string;
};

// ---------- Examens blancs (v1.4 : examens-blancs/*.json) ----------

export type PracticeDomain = { nom: string; /** Libellé de la pondération (« 27 % », « 40-45 % »). */ poids: string; questions: number; source: string };

export type PracticeQuestion = QuizQuestion & { domaine: string };
export type PublicPracticeQuestion = Omit<PracticeQuestion, "answer" | "explanation">;

/** Examen blanc COMPLET (avec réponses) : serveur uniquement. */
export type PracticeExam = {
  slug: string;
  title: string;
  certification: string;
  passScore: number;
  timeLimitMinutes: number;
  domaines: PracticeDomain[];
  notes: string;
  avertissement: string;
  questions: PracticeQuestion[];
};

export type PublicPracticeExam = Omit<PracticeExam, "questions"> & { questions: PublicPracticeQuestion[] };

export type PracticeExamRef = Omit<PracticeExam, "questions"> & { questionCount: number };

/** README des examens blancs découpé : avertissement, sections par certification. */
export type PracticeGuide = {
  /** Markdown de la section « ⚠️ Avertissement » (titre retiré). */
  warning: string;
  /** Markdown de la section « Mode d'emploi conseillé ». */
  howTo: string;
  /** Sections « ## n. Titre » : titre et Markdown (titre retiré). */
  sections: { title: string; body: string }[];
};
