/**
 * Examens blancs d'entraînement (v1.4) — lectures serveur : historique, meilleurs scores, correction d'une session.
 * La correction n'est produite qu'à partir d'une session SOUMISE (practice_attempts) appartenant à l'apprenant.
 */
import "server-only";
import { and, desc, eq } from "drizzle-orm";
import { getPracticeExam, type PracticeExam } from "@/content";
import { db, schema } from "@/db";
import type { PracticeAttempt } from "@/db/schema";

export type PracticeSummary = { attempts: number; best: number | null; last: { percent: number; passed: boolean; at: Date } | null };

/** Résumé par examen (nombre de sessions, meilleur score, dernière session). */
export async function practiceSummaries(userId: string): Promise<Map<string, PracticeSummary>> {
  const rows = await db
    .select({ examId: schema.practiceAttempts.examId, percent: schema.practiceAttempts.percent, passed: schema.practiceAttempts.passed, at: schema.practiceAttempts.submittedAt })
    .from(schema.practiceAttempts)
    .where(eq(schema.practiceAttempts.userId, userId))
    .orderBy(desc(schema.practiceAttempts.submittedAt));
  const out = new Map<string, PracticeSummary>();
  for (const r of rows) {
    const s = out.get(r.examId) ?? { attempts: 0, best: null, last: null };
    s.attempts++;
    s.best = s.best === null ? r.percent : Math.max(s.best, r.percent);
    s.last ??= { percent: r.percent, passed: r.passed, at: r.at };
    out.set(r.examId, s);
  }
  return out;
}

/** Historique d'un examen blanc, du plus récent au plus ancien. */
export async function practiceHistory(userId: string, examId: string, limit = 30): Promise<PracticeAttempt[]> {
  return db
    .select()
    .from(schema.practiceAttempts)
    .where(and(eq(schema.practiceAttempts.userId, userId), eq(schema.practiceAttempts.examId, examId)))
    .orderBy(desc(schema.practiceAttempts.submittedAt))
    .limit(limit);
}

export type PracticeCorrectionItem = {
  index: number;
  questionId: string;
  lessonId: string | null;
  domaine: string;
  type: string;
  q: string;
  options: string[];
  given: number | null;
  correctIndex: number;
  correct: boolean;
  explanation: string;
  source: { title: string; url: string } | null;
};

export type PracticeResult = { attempt: PracticeAttempt; exam: PracticeExam; number: number; items: PracticeCorrectionItem[] };

/** Session soumise de l'apprenant + correction dans l'ordre vu ; null si inconnue ou d'un autre apprenant. */
export async function getPracticeResult(userId: string, attemptId: string): Promise<PracticeResult | null> {
  if (!/^[0-9a-f-]{36}$/i.test(attemptId)) return null;
  const [attempt] = await db
    .select()
    .from(schema.practiceAttempts)
    .where(and(eq(schema.practiceAttempts.id, attemptId), eq(schema.practiceAttempts.userId, userId)))
    .limit(1);
  if (!attempt) return null;
  const exam = getPracticeExam(attempt.examId);
  if (!exam) return null;
  const all = await db
    .select({ id: schema.practiceAttempts.id, at: schema.practiceAttempts.submittedAt })
    .from(schema.practiceAttempts)
    .where(and(eq(schema.practiceAttempts.userId, userId), eq(schema.practiceAttempts.examId, attempt.examId)))
    .orderBy(schema.practiceAttempts.submittedAt);
  const number = all.findIndex((a) => a.id === attempt.id) + 1;
  const byId = new Map(exam.questions.map((q) => [q.id, q]));
  const given = new Map(attempt.answers.map((a) => [a.questionId, a]));
  const items: PracticeCorrectionItem[] = [];
  for (const id of attempt.questionOrder) {
    const q = byId.get(id);
    if (!q) continue;
    const a = given.get(id);
    items.push({
      index: items.length + 1,
      questionId: q.id,
      lessonId: q.lessonId || null,
      domaine: q.domaine,
      type: q.type,
      q: q.q,
      options: q.options,
      given: a?.choice ?? null,
      correctIndex: q.answer,
      correct: a?.correct ?? false,
      explanation: q.explanation,
      source: q.source ? { title: q.source.title, url: q.source.url } : null,
    });
  }
  return { attempt, exam, number, items };
}
