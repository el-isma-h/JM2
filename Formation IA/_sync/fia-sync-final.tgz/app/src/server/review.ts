/**
 * Révisions espacées (/revisions) et blocs pédagogiques des leçons — services serveur.
 *
 *   await reviewOverview(userId)            → { due, pool } (carte du tableau de bord)
 *   await buildReviewSession(userId)        → 10 questions PUBLIQUES (sans réponse) à réviser
 *   await gradeReview(userId, key, choice)  → correction, nouvelle boîte, XP +2
 *
 * Questions : quiz de module (`quiz:{moduleId}:{questionId}`) dont la leçon est terminée, et quiz éclair des leçons
 * terminées (`quizflash:{lessonId}:{index}`). La correction se fait ici, jamais côté client.
 */
import "server-only";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema, type DbOrTx } from "@/db";
import { getFlatLessons, getLesson, getQuiz } from "@/content";
import type { SourceRef } from "@/content/types";
import { countDueReviews, isDue, parisDayKey, reviewXp, scheduleReview, selectReviewQuestions, type ReviewCandidate, type ReviewItemState } from "@/domain";
import { extractLessonBlocks, type LessonBlock } from "@/lib/lesson-blocks";
import { awardXp, syncBadges } from "./gamification";

// ---------- Blocs des leçons (cache par contenu) ----------

const blockCache = new Map<string, { body: string; blocks: LessonBlock[] }>();

/** Blocs ```quiz / ```mission d'une leçon (analyse mise en cache tant que le fichier ne change pas). */
export function lessonBlocks(lessonId: string): LessonBlock[] {
  const lesson = getLesson(lessonId);
  if (!lesson) return [];
  const hit = blockCache.get(lessonId);
  if (hit && hit.body === lesson.body) return hit.blocks;
  const blocks = extractLessonBlocks(lesson.body);
  blockCache.set(lessonId, { body: lesson.body, blocks });
  return blocks;
}

// ---------- Questions de révision ----------

export type ReviewQuestion = {
  key: string;
  origin: "quiz" | "quizflash";
  lessonId: string;
  moduleId: string;
  q: string;
  options: string[];
  answer: number;
  explanation: string;
  source: SourceRef | null;
};

/** Question publique (avant réponse) : sans `answer` ni `explanation`. */
export type PublicReviewQuestion = Omit<ReviewQuestion, "answer" | "explanation" | "source"> & { lessonTitle: string };

const KEY = /^(quiz):(M\d{2}):([\w.-]+)$|^(quizflash):(L\d{3}):(\d{1,3})$/;

export function isReviewKey(key: unknown): key is string {
  return typeof key === "string" && key.length < 80 && KEY.test(key);
}

/** Retrouve une question à partir de sa clé (null si elle n'existe plus dans le contenu). */
export function resolveReviewQuestion(key: string): ReviewQuestion | null {
  const m = KEY.exec(key);
  if (!m) return null;
  if (m[1] === "quiz") {
    const q = getQuiz(m[2])?.questions.find((x) => x.id === m[3]);
    if (!q) return null;
    return { key, origin: "quiz", lessonId: q.lessonId, moduleId: m[2], q: q.q, options: q.options, answer: q.answer, explanation: q.explanation, source: q.source ?? null };
  }
  const lessonId = m[5];
  const index = Number(m[6]);
  const block = lessonBlocks(lessonId).find((b) => b.kind === "quiz" && b.index === index);
  if (!block || block.kind !== "quiz" || !block.quiz) return null;
  const lesson = getLesson(lessonId);
  return { key, origin: "quizflash", lessonId, moduleId: lesson?.module ?? "", q: block.quiz.q, options: block.quiz.options, answer: block.quiz.answer, explanation: block.quiz.explanation, source: null };
}

/** Questions éligibles : celles des leçons terminées, avec la date de fin de leçon et les échecs passés. */
async function candidatesFor(userId: string, conn: DbOrTx = db): Promise<ReviewCandidate[]> {
  const [done, attempts] = await Promise.all([
    conn
      .select({ lessonId: schema.lessonProgress.lessonId, completedAt: schema.lessonProgress.completedAt })
      .from(schema.lessonProgress)
      .where(and(eq(schema.lessonProgress.userId, userId), eq(schema.lessonProgress.status, "completed"))),
    conn.select({ moduleId: schema.quizAttempts.moduleId, answers: schema.quizAttempts.answers }).from(schema.quizAttempts).where(eq(schema.quizAttempts.userId, userId)),
  ]);
  if (done.length === 0) return [];
  const completedAt = new Map(done.map((d) => [d.lessonId, d.completedAt ?? new Date(0)]));
  const missed = new Set<string>();
  for (const a of attempts) for (const r of a.answers ?? []) if (!r.correct) missed.add(`quiz:${a.moduleId}:${r.questionId}`);

  const out: ReviewCandidate[] = [];
  const modules = new Set<string>();
  for (const l of getFlatLessons()) {
    const at = completedAt.get(l.id);
    if (!at) continue;
    modules.add(l.moduleId);
    for (const b of lessonBlocks(l.id)) if (b.kind === "quiz" && b.quiz) out.push({ key: `quizflash:${l.id}:${b.index}`, learnedAt: at, missedBefore: false });
  }
  for (const moduleId of modules) {
    for (const q of getQuiz(moduleId)?.questions ?? []) {
      const at = completedAt.get(q.lessonId);
      if (!at) continue;
      const key = `quiz:${moduleId}:${q.id}`;
      out.push({ key, learnedAt: at, missedBefore: missed.has(key) });
    }
  }
  return out;
}

async function itemsFor(userId: string, conn: DbOrTx = db): Promise<Map<string, ReviewItemState>> {
  const rows = await conn.select().from(schema.reviewItems).where(eq(schema.reviewItems.userId, userId));
  return new Map(rows.map((r) => [r.questionKey, { box: r.box, dueAt: r.dueAt, wrongCount: r.wrongCount, correctCount: r.correctCount }]));
}

export type ReviewOverview = { due: number; pool: number; mastered: number };

export async function reviewOverview(userId: string, now = new Date()): Promise<ReviewOverview> {
  const [candidates, items] = await Promise.all([candidatesFor(userId), itemsFor(userId)]);
  const keys = new Set(candidates.map((c) => c.key));
  let mastered = 0;
  for (const k of keys) if ((items.get(k)?.box ?? 0) >= 4) mastered++;
  return { due: countDueReviews(candidates, items, now), pool: keys.size, mastered };
}

export async function buildReviewSession(userId: string, now = new Date()): Promise<{ questions: PublicReviewQuestion[]; overview: ReviewOverview }> {
  const [candidates, items] = await Promise.all([candidatesFor(userId), itemsFor(userId)]);
  const keys = selectReviewQuestions(candidates, items, now);
  const titles = new Map(getFlatLessons().map((l) => [l.id, l.title]));
  const questions: PublicReviewQuestion[] = [];
  for (const key of keys) {
    const q = resolveReviewQuestion(key);
    if (!q) continue;
    questions.push({ key, origin: q.origin, lessonId: q.lessonId, moduleId: q.moduleId, q: q.q, options: q.options, lessonTitle: titles.get(q.lessonId) ?? q.lessonId });
  }
  const pool = new Set(candidates.map((c) => c.key));
  let mastered = 0;
  for (const k of pool) if ((items.get(k)?.box ?? 0) >= 4) mastered++;
  return { questions, overview: { due: countDueReviews(candidates, items, now), pool: pool.size, mastered } };
}

/** Enregistre une réponse (révision ou quiz éclair raté) dans la boîte de Leitner. */
export async function recordReviewAnswer(userId: string, key: string, correct: boolean, now = new Date(), conn: DbOrTx = db): Promise<{ box: number; dueAt: Date; wasDue: boolean }> {
  const [prev] = await conn
    .select()
    .from(schema.reviewItems)
    .where(and(eq(schema.reviewItems.userId, userId), eq(schema.reviewItems.questionKey, key)))
    .limit(1);
  const next = scheduleReview(prev ?? null, correct, now);
  await conn
    .insert(schema.reviewItems)
    .values({ userId, questionKey: key, box: next.box, dueAt: next.dueAt, lastReviewedAt: now, correctCount: correct ? 1 : 0, wrongCount: correct ? 0 : 1, createdAt: now })
    .onConflictDoUpdate({
      target: [schema.reviewItems.userId, schema.reviewItems.questionKey],
      set: {
        box: next.box,
        dueAt: next.dueAt,
        lastReviewedAt: now,
        correctCount: (prev?.correctCount ?? 0) + (correct ? 1 : 0),
        wrongCount: (prev?.wrongCount ?? 0) + (correct ? 0 : 1),
      },
    });
  return { ...next, wasDue: isDue(prev ? { dueAt: prev.dueAt } : undefined, now) };
}

export type ReviewGrade = { correct: boolean; answer: number; explanation: string; source: SourceRef | null; box: number; xp: number; badges: string[] };

/** Corrige une question de révision : la leçon d'origine doit être terminée. XP +2 si la question était due. */
export async function gradeReview(userId: string, key: string, choice: number, now = new Date()): Promise<ReviewGrade | null> {
  const q = resolveReviewQuestion(key);
  if (!q || !Number.isInteger(choice) || choice < 0 || choice >= q.options.length) return null;
  const [done] = await db
    .select({ s: schema.lessonProgress.status })
    .from(schema.lessonProgress)
    .where(and(eq(schema.lessonProgress.userId, userId), eq(schema.lessonProgress.lessonId, q.lessonId), eq(schema.lessonProgress.status, "completed")))
    .limit(1);
  if (!done) return null;
  const correct = choice === q.answer;
  const r = await recordReviewAnswer(userId, key, correct, now);
  const xp = correct && r.wasDue ? await awardXp(userId, reviewXp(key, parisDayKey(now)), { at: now }) : 0;
  const badges = xp > 0 ? await syncBadges(userId, { at: now }) : [];
  return { correct, answer: q.answer, explanation: q.explanation, source: q.source, box: r.box, xp, badges };
}

/** Références des blocs déjà validés d'une leçon (quiz éclair réussis, missions accomplies). */
export async function lessonBlockProgress(userId: string, lessonId: string): Promise<{ quiz: number[]; mission: number[] }> {
  const refs = lessonBlocks(lessonId).map((b) => (b.kind === "quiz" ? `quizflash:${lessonId}:${b.index}` : `mission:${lessonId}:${b.index}`));
  if (refs.length === 0) return { quiz: [], mission: [] };
  const rows = await db
    .select({ refId: schema.xpEvents.refId, reason: schema.xpEvents.reason })
    .from(schema.xpEvents)
    .where(and(eq(schema.xpEvents.userId, userId), inArray(schema.xpEvents.refId, refs)));
  const idx = (r: string) => Number(r.split(":")[2]);
  return {
    quiz: rows.filter((r) => r.reason === "quiz_flash").map((r) => idx(r.refId)),
    mission: rows.filter((r) => r.reason === "mission").map((r) => idx(r.refId)),
  };
}
