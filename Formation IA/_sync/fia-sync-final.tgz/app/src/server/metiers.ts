/**
 * Parcours métiers (v1.4) — lectures serveur : blocs interactifs d'un parcours, état de l'apprenant, « Mon métier ».
 */
import "server-only";
import { and, eq, inArray } from "drizzle-orm";
import { getFlatLessons, getMetier, type Metier } from "@/content";
import { metierBlockRef, metierProgress, type MetierProgress } from "@/domain";
import { extractLessonBlocks, type LessonBlock } from "@/lib/lesson-blocks";
import { db, schema } from "@/db";

const blockCache = new Map<string, { body: string; blocks: LessonBlock[] }>();

/** Blocs ```quiz / ```mission d'un parcours métier (index par type, ordre du document : même règle que les leçons). */
export function metierBlocks(slug: string): LessonBlock[] {
  const metier = getMetier(slug);
  if (!metier) return [];
  const hit = blockCache.get(slug);
  if (hit && hit.body === metier.body) return hit.blocks;
  const blocks = extractLessonBlocks(metier.body);
  blockCache.set(slug, { body: metier.body, blocks });
  return blocks;
}

/** Blocs déjà validés (XP accordée) : index des quiz éclair réussis et des missions accomplies. */
export async function metierBlockProgress(userId: string, slug: string): Promise<{ quiz: number[]; mission: number[] }> {
  const blocks = metierBlocks(slug);
  if (blocks.length === 0) return { quiz: [], mission: [] };
  const refs = [...new Set(blocks.map((b) => metierBlockRef(slug, b.index)))];
  const rows = await db
    .select({ refId: schema.xpEvents.refId, reason: schema.xpEvents.reason })
    .from(schema.xpEvents)
    .where(and(eq(schema.xpEvents.userId, userId), inArray(schema.xpEvents.refId, refs), inArray(schema.xpEvents.reason, ["metier_quiz", "metier_mission"])));
  const idx = (r: string) => Number(r.split(":")[2]);
  return {
    quiz: rows.filter((r) => r.reason === "metier_quiz").map((r) => idx(r.refId)),
    mission: rows.filter((r) => r.reason === "metier_mission").map((r) => idx(r.refId)),
  };
}

/** « Mon métier » de l'apprenant (slug d'un parcours existant), null sinon. */
export async function getUserMetier(userId: string): Promise<string | null> {
  const [row] = await db.select({ metier: schema.users.metier }).from(schema.users).where(eq(schema.users.id, userId)).limit(1);
  const slug = row?.metier ?? null;
  return slug && getMetier(slug) ? slug : null;
}

export async function completedLessonIds(userId: string): Promise<Set<string>> {
  const rows = await db
    .select({ lessonId: schema.lessonProgress.lessonId })
    .from(schema.lessonProgress)
    .where(and(eq(schema.lessonProgress.userId, userId), eq(schema.lessonProgress.status, "completed")));
  return new Set(rows.map((r) => r.lessonId));
}

/** Progression de l'apprenant sur les leçons prioritaires d'un parcours. */
export function progressFor(metier: Metier, completed: ReadonlySet<string>): MetierProgress {
  return metierProgress(metier.lessons, completed, getFlatLessons().map((l) => l.id));
}
