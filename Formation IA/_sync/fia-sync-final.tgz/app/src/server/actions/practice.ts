"use server";

/**
 * Server action v1.4 : envoi d'une session d'examen blanc (mode entraînement).
 * Correction côté serveur uniquement (le client n'a reçu que les questions publiques) ; tentatives illimitées ;
 * aucun certificat, aucun XP d'examen : +20 XP par session terminée, au plus une fois par jour et par examen.
 */
import { z } from "zod";
import { getPracticeExam } from "@/content";
import { gradePractice, parisDayKey, practiceDurationSeconds, practiceXp } from "@/domain";
import { getSession } from "@/server/auth";
import { awardXp, syncBadges } from "@/server/gamification";
import { db, schema } from "@/db";
import { routes } from "@/lib/paths";
import { sharedLimiter } from "@/lib/rate-limit";
import { toRewardBadges, type Rewards } from "@/lib/rewards";

const limiter = sharedLimiter("practice-submit", { limit: 12, windowMs: 60_000 });

const inputSchema = z.object({
  examId: z.string().regex(/^[a-z0-9][a-z0-9-]*$/).max(80),
  startedAt: z.string().max(40),
  order: z.array(z.string().max(40)).max(500),
  answers: z.record(z.string().max(40), z.number().int().min(0).max(9).nullable()),
});

export type PracticeSubmitResult = { ok: true; url: string; rewards: Rewards } | { ok: false; error: string };

export async function submitPracticeAction(input: unknown): Promise<PracticeSubmitResult> {
  const user = await getSession();
  if (!user) return { ok: false, error: "Session expirée : reconnectez-vous. Vos réponses restent affichées." };
  const parsed = inputSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "Requête invalide." };
  if (!limiter.hit(user.id).allowed) return { ok: false, error: "Trop d'envois rapprochés : patientez quelques secondes." };
  const exam = getPracticeExam(parsed.data.examId);
  if (!exam) return { ok: false, error: "Examen blanc introuvable." };

  const now = new Date();
  // Ordre affiché : permutation exacte des questions du fichier, sinon ordre du fichier.
  const ids = exam.questions.map((q) => q.id);
  const order = parsed.data.order.length === ids.length && new Set(parsed.data.order).size === ids.length && parsed.data.order.every((id) => ids.includes(id)) ? parsed.data.order : ids;
  const started = new Date(parsed.data.startedAt);
  const startedAt = Number.isNaN(started.getTime()) || started > now ? now : started;
  const grade = gradePractice(exam.questions, parsed.data.answers, exam.passScore, exam.domaines.map((d) => d.nom));

  const [row] = await db
    .insert(schema.practiceAttempts)
    .values({
      userId: user.id,
      examId: exam.slug,
      startedAt,
      submittedAt: now,
      durationSeconds: practiceDurationSeconds(startedAt, now),
      timeLimitMinutes: Math.round(exam.timeLimitMinutes),
      questionOrder: order,
      answers: grade.items,
      byDomain: grade.byDomain,
      score: grade.score,
      total: grade.total,
      percent: grade.percent,
      passScore: Math.round(exam.passScore),
      passed: grade.passed,
    })
    .returning({ id: schema.practiceAttempts.id });

  const xp = await awardXp(user.id, practiceXp(exam.slug, parisDayKey(now)), { at: now });
  const badges = xp > 0 ? await syncBadges(user.id) : [];
  return { ok: true, url: routes.practiceResult(exam.slug, row.id), rewards: { xp, badges: toRewardBadges(badges) } };
}
