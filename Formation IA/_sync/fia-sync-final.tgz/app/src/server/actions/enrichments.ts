"use server";

/**
 * Server actions v1.1 : quiz éclair et missions documentation des leçons, lexique, révisions.
 * Chaque action revérifie la session et l'accès ; la correction et le barème (XP du bloc) sont lus dans le contenu,
 * jamais reçus du client. Récompenses idempotentes (xp_events, index unique).
 */
import { z } from "zod";
import { getGlossary } from "@/content";
import { canAccessLesson, flashQuizXp, missionXp } from "@/domain";
import { getSession } from "@/server/auth";
import { loadAccess } from "@/server/learner";
import { awardXp, syncBadges } from "@/server/gamification";
import { gradeReview, isReviewKey, lessonBlocks, recordReviewAnswer } from "@/server/review";
import { db, schema } from "@/db";
import { sharedLimiter } from "@/lib/rate-limit";
import { toRewardBadges, type Rewards } from "@/lib/rewards";
import { flashQuizRef } from "@/lib/lesson-blocks";

type Fail = { ok: false; error: string };

const lessonIdSchema = z.string().regex(/^L\d{3}$/);
const indexSchema = z.number().int().min(0).max(999);
const limiter = sharedLimiter("enrichments", { limit: 240, windowMs: 60_000 });

async function learnerWithLesson(lessonId: unknown, index: unknown) {
  const user = await getSession();
  if (!user) return { error: "Session expirée : reconnectez-vous." } as const;
  const l = lessonIdSchema.safeParse(lessonId);
  const i = indexSchema.safeParse(index);
  if (!l.success || !i.success) return { error: "Requête invalide." } as const;
  if (!limiter.hit(user.id).allowed) return { error: "Trop de requêtes : patientez quelques secondes." } as const;
  const { access } = await loadAccess(user.id);
  if (!canAccessLesson(access, l.data)) return { error: "Cette leçon n'est pas encore débloquée." } as const;
  return { user, lessonId: l.data, index: i.data } as const;
}

// ---------- Quiz éclair ----------

export type FlashQuizResult = { ok: true; correct: boolean; answer: number; explanation: string; rewards: Rewards } | Fail;

export async function answerFlashQuizAction(lessonId: string, index: number, choice: number): Promise<FlashQuizResult> {
  const ctx = await learnerWithLesson(lessonId, index);
  if ("error" in ctx) return { ok: false, error: ctx.error ?? "Requête invalide." };
  const block = lessonBlocks(ctx.lessonId).find((b) => b.kind === "quiz" && b.index === ctx.index);
  const quiz = block?.kind === "quiz" ? block.quiz : null;
  if (!quiz || !Number.isInteger(choice) || choice < 0 || choice >= quiz.options.length) return { ok: false, error: "Question inconnue." };
  const correct = choice === quiz.answer;
  let xp = 0;
  let badges: string[] = [];
  if (correct) {
    xp = await awardXp(ctx.user.id, flashQuizXp(ctx.lessonId, ctx.index));
    if (xp > 0) badges = await syncBadges(ctx.user.id);
  } else {
    // Ratée : à revoir en priorité dans les révisions.
    await recordReviewAnswer(ctx.user.id, flashQuizRef(ctx.lessonId, ctx.index), false);
  }
  return { ok: true, correct, answer: quiz.answer, explanation: quiz.explanation, rewards: { xp, badges: toRewardBadges(badges) } };
}

// ---------- Mission documentation ----------

export type MissionResult = { ok: true; alreadyDone: boolean; rewards: Rewards } | Fail;

export async function completeMissionAction(lessonId: string, index: number): Promise<MissionResult> {
  const ctx = await learnerWithLesson(lessonId, index);
  if ("error" in ctx) return { ok: false, error: ctx.error ?? "Requête invalide." };
  const block = lessonBlocks(ctx.lessonId).find((b) => b.kind === "mission" && b.index === ctx.index);
  const mission = block?.kind === "mission" ? block.mission : null;
  if (!mission) return { ok: false, error: "Mission inconnue." };
  const xp = await awardXp(ctx.user.id, missionXp(ctx.lessonId, ctx.index, mission.xp));
  const badges = xp > 0 ? await syncBadges(ctx.user.id) : [];
  return { ok: true, alreadyDone: xp === 0, rewards: { xp, badges: toRewardBadges(badges) } };
}

// ---------- Lexique ----------

export type LexiconViewResult = { ok: true; rewards: Rewards } | Fail;

/** Note qu'un terme a été consulté (badge « Lexicographe »). Idempotent. */
export async function viewLexiconTermAction(slug: string): Promise<LexiconViewResult> {
  const user = await getSession();
  if (!user) return { ok: false, error: "Session expirée : reconnectez-vous." };
  if (typeof slug !== "string" || !getGlossary().terms.some((t) => t.slug === slug)) return { ok: false, error: "Terme inconnu." };
  if (!limiter.hit(user.id).allowed) return { ok: false, error: "Trop de requêtes." };
  const inserted = await db.insert(schema.lexiconViews).values({ userId: user.id, slug }).onConflictDoNothing().returning({ slug: schema.lexiconViews.slug });
  const badges = inserted.length ? await syncBadges(user.id) : [];
  return { ok: true, rewards: { xp: 0, badges: toRewardBadges(badges) } };
}

// ---------- Révisions ----------

export type ReviewAnswerResult = { ok: true; correct: boolean; answer: number; explanation: string; source: { title: string; url: string } | null; box: number; rewards: Rewards } | Fail;

export async function answerReviewAction(key: string, choice: number): Promise<ReviewAnswerResult> {
  const user = await getSession();
  if (!user) return { ok: false, error: "Session expirée : reconnectez-vous." };
  if (!isReviewKey(key) || !Number.isInteger(choice)) return { ok: false, error: "Requête invalide." };
  if (!limiter.hit(user.id).allowed) return { ok: false, error: "Trop de requêtes : patientez quelques secondes." };
  const g = await gradeReview(user.id, key, choice);
  if (!g) return { ok: false, error: "Cette question n'est plus disponible." };
  return { ok: true, correct: g.correct, answer: g.answer, explanation: g.explanation, source: g.source ? { title: g.source.title, url: g.source.url } : null, box: g.box, rewards: { xp: g.xp, badges: toRewardBadges(g.badges) } };
}
