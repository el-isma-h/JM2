"use server";

/**
 * Server action du Labo (v1.3) : note qu'un outil a été utilisé (badge « Laborantin »). Idempotent (une ligne par
 * outil et par apprenant). Les calculs eux-mêmes restent 100 % côté client (src/domain/labo).
 */
import { db, schema } from "@/db";
import { isLaboToolId } from "@/domain/labo/tools";
import { getSession } from "@/server/auth";
import { syncBadges } from "@/server/gamification";
import { sharedLimiter } from "@/lib/rate-limit";
import { toRewardBadges, type Rewards } from "@/lib/rewards";

const limiter = sharedLimiter("labo", { limit: 60, windowMs: 60_000 });

export type LaboUseResult = { ok: true; firstUse: boolean; rewards: Rewards } | { ok: false; error: string };

export async function markLaboToolUsedAction(toolId: string): Promise<LaboUseResult> {
  const user = await getSession();
  if (!user) return { ok: false, error: "Session expirée : reconnectez-vous." };
  if (!isLaboToolId(toolId)) return { ok: false, error: "Outil inconnu." };
  if (!limiter.hit(user.id).allowed) return { ok: false, error: "Trop de requêtes." };
  const inserted = await db.insert(schema.laboUses).values({ userId: user.id, toolId }).onConflictDoNothing().returning({ toolId: schema.laboUses.toolId });
  const badges = inserted.length ? await syncBadges(user.id) : [];
  return { ok: true, firstUse: inserted.length > 0, rewards: { xp: 0, badges: toRewardBadges(badges) } };
}
