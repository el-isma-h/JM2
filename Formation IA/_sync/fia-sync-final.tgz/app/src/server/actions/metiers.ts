"use server";

/**
 * Server actions v1.4 : quiz éclair et missions des parcours métiers, choix « Mon métier ».
 * La correction et le barème sont lus dans le fichier du parcours, jamais reçus du client.
 * XP une seule fois par bloc : refId stable `metier:{slug}:{index}` (index unique xp_events).
 * Les parcours métiers sont ouverts à tout apprenant connecté (supports de lecture, pas une étape du parcours).
 */
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { getMetier } from "@/content";
import { metierMissionXp, metierQuizXp } from "@/domain";
import { getSession } from "@/server/auth";
import { awardXp, syncBadges } from "@/server/gamification";
import { metierBlocks } from "@/server/metiers";
import { db, schema } from "@/db";
import { sharedLimiter } from "@/lib/rate-limit";
import { toRewardBadges, type Rewards } from "@/lib/rewards";

type Fail = { ok: false; error: string };

const slugSchema = z.string().regex(/^[a-z0-9][a-z0-9-]*$/).max(80);
const indexSchema = z.number().int().min(0).max(999);
const limiter = sharedLimiter("metiers", { limit: 240, windowMs: 60_000 });

async function context(slug: unknown, index: unknown) {
  const user = await getSession();
  if (!user) return { error: "Session expirée : reconnectez-vous." } as const;
  const s = slugSchema.safeParse(slug);
  const i = indexSchema.safeParse(index);
  if (!s.success || !i.success || !getMetier(s.data)) return { error: "Requête invalide." } as const;
  if (!limiter.hit(user.id).allowed) return { error: "Trop de requêtes : patientez quelques secondes." } as const;
  return { user, slug: s.data, index: i.data } as const;
}

export type MetierQuizResult = { ok: true; correct: boolean; answer: number; explanation: string; rewards: Rewards } | Fail;

export async function answerMetierQuizAction(slug: string, index: number, choice: number): Promise<MetierQuizResult> {
  const ctx = await context(slug, index);
  if ("error" in ctx) return { ok: false, error: ctx.error ?? "Requête invalide." };
  const block = metierBlocks(ctx.slug).find((b) => b.kind === "quiz" && b.index === ctx.index);
  const quiz = block?.kind === "quiz" ? block.quiz : null;
  if (!quiz || !Number.isInteger(choice) || choice < 0 || choice >= quiz.options.length) return { ok: false, error: "Question inconnue." };
  const correct = choice === quiz.answer;
  let xp = 0;
  let badges: string[] = [];
  if (correct) {
    xp = await awardXp(ctx.user.id, metierQuizXp(ctx.slug, ctx.index));
    if (xp > 0) badges = await syncBadges(ctx.user.id);
  }
  return { ok: true, correct, answer: quiz.answer, explanation: quiz.explanation, rewards: { xp, badges: toRewardBadges(badges) } };
}

export type MetierMissionResult = { ok: true; alreadyDone: boolean; rewards: Rewards } | Fail;

export async function completeMetierMissionAction(slug: string, index: number): Promise<MetierMissionResult> {
  const ctx = await context(slug, index);
  if ("error" in ctx) return { ok: false, error: ctx.error ?? "Requête invalide." };
  const block = metierBlocks(ctx.slug).find((b) => b.kind === "mission" && b.index === ctx.index);
  const mission = block?.kind === "mission" ? block.mission : null;
  if (!mission) return { ok: false, error: "Mission inconnue." };
  const xp = await awardXp(ctx.user.id, metierMissionXp(ctx.slug, ctx.index, mission.xp));
  const badges = xp > 0 ? await syncBadges(ctx.user.id) : [];
  return { ok: true, alreadyDone: xp === 0, rewards: { xp, badges: toRewardBadges(badges) } };
}

/** « Mon métier » : slug d'un parcours existant, ou null pour retirer le choix. Autorisé sur le compte démo. */
export async function setMyMetierAction(slug: string | null): Promise<{ ok: boolean; error?: string }> {
  const user = await getSession();
  if (!user) return { ok: false, error: "Session expirée : reconnectez-vous." };
  if (slug !== null && (!slugSchema.safeParse(slug).success || !getMetier(slug))) return { ok: false, error: "Métier inconnu." };
  await db.update(schema.users).set({ metier: slug }).where(eq(schema.users.id, user.id));
  revalidatePath("/");
  revalidatePath("/profil");
  revalidatePath("/metiers", "layout");
  return { ok: true };
}
