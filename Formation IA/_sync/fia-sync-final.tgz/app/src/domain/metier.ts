/**
 * Parcours métiers (v1.4) : progression d'un apprenant sur les leçons prioritaires de son métier.
 * Fonctions pures : la liste des leçons vient de la couche contenu, l'état de l'apprenant de la base.
 */

export type MetierLessonRef = { id: string; priority: boolean };

export type MetierProgress = {
  /** Leçons prioritaires terminées / total. */
  done: number;
  total: number;
  percent: number;
  /** Prochaine leçon prioritaire non terminée (ordre pédagogique du programme), null si toutes sont terminées. */
  nextLessonId: string | null;
};

/**
 * Prochaine leçon prioritaire : la première non terminée dans l'ORDRE DU PROGRAMME (`order` : ids des leçons dans
 * l'ordre pédagogique), car les leçons se débloquent dans cet ordre. Une leçon absente de `order` passe en dernier,
 * dans l'ordre du fichier métier.
 */
export function metierProgress(lessons: readonly MetierLessonRef[], completed: ReadonlySet<string>, order: readonly string[]): MetierProgress {
  const rank = new Map(order.map((id, i) => [id, i]));
  const priority = lessons.filter((l) => l.priority);
  const sorted = priority
    .map((l, i) => ({ id: l.id, key: rank.get(l.id) ?? order.length + i }))
    .sort((a, b) => a.key - b.key)
    .map((x) => x.id);
  const done = priority.filter((l) => completed.has(l.id)).length;
  const total = priority.length;
  return { done, total, percent: total ? Math.round((done / total) * 100) : 0, nextLessonId: sorted.find((id) => !completed.has(id)) ?? null };
}

/** Référence XP stable d'un bloc ```quiz / ```mission d'un parcours métier : `metier:{slug}:{index}`. */
export const metierBlockRef = (slug: string, index: number) => `metier:${slug}:${index}`;
