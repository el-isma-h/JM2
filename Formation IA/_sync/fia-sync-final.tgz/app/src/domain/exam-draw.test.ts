import { describe, expect, it } from "vitest";
import { competenceGroups, drawExamQuestionIds, questionsPerAttempt, seenQuestionCounts, stratifiedQuotas } from "./exam-draw";
import { buildExamOrder, seededRandom } from "./exam";
import { buildCorrection } from "./exam-session";

/** Banque de 80 questions : C1 = 24, C2 = 16, C3 = 20, C4 = 12, C5 = 8. */
const SIZES: Record<string, number> = { "C1.1": 24, "C1.2": 16, "C1.3": 20, "C1.4": 12, "C1.5": 8 };
let n = 0;
const competences: Record<string, string[]> = {};
const bank: { id: string; competence: string; options: string[] }[] = [];
for (const [c, size] of Object.entries(SIZES)) {
  competences[c] = [];
  for (let i = 0; i < size; i++) {
    const id = `N1-E${String(++n).padStart(2, "0")}`;
    competences[c].push(id);
    bank.push({ id, competence: c, options: ["a", "b", "c", "d"] });
  }
}
const compOf = new Map(bank.map((q) => [q.id, q.competence]));
const countBy = (ids: string[]) => ids.reduce<Record<string, number>>((acc, id) => ((acc[compOf.get(id)!] = (acc[compOf.get(id)!] ?? 0) + 1), acc), {});

describe("tirage stratifié des examens (banques de 80 questions)", () => {
  it("sans drawPerAttempt : toutes les questions (comportement actuel)", () => {
    expect(drawExamQuestionIds(bank, { competences })).toEqual(bank.map((q) => q.id));
    expect(drawExamQuestionIds(bank, { competences, drawPerAttempt: null })).toHaveLength(80);
    expect(drawExamQuestionIds(bank, { competences, drawPerAttempt: 120 })).toHaveLength(80);
    expect(questionsPerAttempt({ questions: bank })).toBe(80);
    expect(questionsPerAttempt({ questions: bank, drawPerAttempt: 40 })).toBe(40);
  });

  it("quotas proportionnels à la map competences (40 sur 80 → moitié de chaque compétence)", () => {
    const ids = drawExamQuestionIds(bank, { competences, drawPerAttempt: 40, rand: seededRandom(1) });
    expect(ids).toHaveLength(40);
    expect(new Set(ids).size).toBe(40);
    expect(countBy(ids)).toEqual({ "C1.1": 12, "C1.2": 8, "C1.3": 10, "C1.4": 6, "C1.5": 4 });
  });

  it("plus forts restes : la somme des quotas vaut exactement le tirage", () => {
    const sizes = new Map(Object.entries(SIZES));
    for (const draw of [1, 7, 25, 33, 41, 79]) {
      const q = stratifiedQuotas(sizes, draw);
      expect([...q.values()].reduce((a, b) => a + b, 0)).toBe(draw);
      for (const [c, v] of q) {
        const exact = (SIZES[c] / 80) * draw;
        expect(v).toBeGreaterThanOrEqual(Math.floor(exact));
        expect(v).toBeLessThanOrEqual(Math.ceil(exact));
      }
    }
    // 33 sur 80 : 9,9 / 6,6 / 8,25 / 4,95 / 3,3 → 10 / 7 / 8 / 5 / 3
    expect(Object.fromEntries(stratifiedQuotas(sizes, 33))).toEqual({ "C1.1": 10, "C1.2": 7, "C1.3": 8, "C1.4": 5, "C1.5": 3 });
  });

  it("déterministe avec une graine, différent avec une autre", () => {
    const a = drawExamQuestionIds(bank, { competences, drawPerAttempt: 40, rand: seededRandom(42) });
    const b = drawExamQuestionIds(bank, { competences, drawPerAttempt: 40, rand: seededRandom(42) });
    const c = drawExamQuestionIds(bank, { competences, drawPerAttempt: 40, rand: seededRandom(43) });
    expect(a).toEqual(b);
    expect(a).not.toEqual(c);
  });

  it("évite en priorité les questions déjà vues : deux tentatives de 40 couvrent les 80 questions", () => {
    const first = drawExamQuestionIds(bank, { competences, drawPerAttempt: 40, rand: seededRandom(5) });
    const second = drawExamQuestionIds(bank, { competences, drawPerAttempt: 40, seen: seenQuestionCounts([first]), rand: seededRandom(6) });
    expect(second.filter((id) => first.includes(id))).toEqual([]);
    expect(new Set([...first, ...second]).size).toBe(80);
    expect(countBy(second)).toEqual(countBy(first));
  });

  it("3e tentative : complète avec les questions les moins vues", () => {
    const first = drawExamQuestionIds(bank, { competences, drawPerAttempt: 50, rand: seededRandom(1) });
    const second = drawExamQuestionIds(bank, { competences, drawPerAttempt: 50, seen: seenQuestionCounts([first]), rand: seededRandom(2) });
    const seen = seenQuestionCounts([first, second]);
    const third = drawExamQuestionIds(bank, { competences, drawPerAttempt: 50, seen, rand: seededRandom(3) });
    // Chaque question vue deux fois n'est reprise que si une compétence manque de questions vues une seule fois.
    const twice = [...seen].filter(([, k]) => k === 2).map(([id]) => id);
    const onceByComp = countBy([...seen].filter(([, k]) => k === 1).map(([id]) => id));
    for (const id of third.filter((x) => twice.includes(x))) {
      const comp = compOf.get(id)!;
      expect(countBy(third)[comp]).toBeGreaterThan(onceByComp[comp] ?? 0);
    }
    expect(third).toHaveLength(50);
  });

  it("questions hors map : regroupées par leur champ competence", () => {
    const extra = [...bank, { id: "X1", competence: "C1.9", options: ["a", "b"] }, { id: "X2", competence: "C1.9", options: ["a", "b"] }];
    const groups = competenceGroups(extra, competences);
    expect(groups.get("C1.9")).toEqual(["X1", "X2"]);
    const ids = drawExamQuestionIds(extra, { competences, drawPerAttempt: 41, rand: seededRandom(9) });
    expect(ids).toHaveLength(41);
    expect(ids.filter((id) => id.startsWith("X")).length).toBeGreaterThanOrEqual(1);
  });

  it("l'ordre de la tentative ne contient que les questions tirées, options mélangées", () => {
    const ids = new Set(drawExamQuestionIds(bank, { competences, drawPerAttempt: 40, rand: seededRandom(3) }));
    const order = buildExamOrder(
      bank.filter((q) => ids.has(q.id)),
      seededRandom(4),
    );
    expect(order.questionOrder).toHaveLength(40);
    expect(new Set(order.questionOrder)).toEqual(ids);
    expect(Object.keys(order.optionOrders)).toHaveLength(40);
  });

  it("scores par compétence calculés sur les seules questions tirées", () => {
    const ids = new Set(drawExamQuestionIds(bank, { competences, drawPerAttempt: 40, rand: seededRandom(8) }));
    const full = bank.map((q) => ({ ...q, type: "qcm", q: q.id, answer: 0, explanation: "" }));
    const order = buildExamOrder(
      full.filter((q) => ids.has(q.id)),
      seededRandom(9),
    );
    const answers = Object.fromEntries(order.questionOrder.map((id) => [id, 0]));
    const c = buildCorrection(full, { ...order, answers }, 70);
    expect(c.total).toBe(40);
    expect(c.percent).toBe(100);
    expect(Object.fromEntries(c.byCompetence.map((b) => [b.competence, b.total]))).toEqual({ "C1.1": 12, "C1.2": 8, "C1.3": 10, "C1.4": 6, "C1.5": 4 });
  });
});
