/**
 * Tirage des questions d'une tentative d'examen dans une BANQUE (examen JSON avec `bankSize` et `drawPerAttempt`).
 *
 * - Stratification par compétence : chaque compétence reçoit un quota proportionnel à son poids dans la map
 *   `competences` de l'examen (méthode des plus forts restes, quotas bornés par le nombre de questions disponibles,
 *   le reliquat éventuel étant redistribué aux compétences qui ont encore des questions).
 * - Non-répétition : dans chaque compétence, les questions jamais vues par l'apprenant (tentatives précédentes) passent
 *   en premier ; les questions déjà vues ne complètent le quota que si les inédites manquent (les moins vues d'abord).
 * - Déterminisme : à graine égale (`rand` = seededRandom(seed)), même tirage.
 * - Sans `drawPerAttempt` (ou s'il couvre toute la banque) : toutes les questions, comportement historique.
 *
 * L'ordre final (questions ET options) est ensuite mélangé par `buildExamOrder` comme pour un examen classique.
 */
import { shuffle } from "./exam";

export type DrawableQuestion = { id: string; competence?: string };

export type DrawOptions = {
  /** Map compétence → ids de questions (champ `competences` de l'examen). */
  competences?: Readonly<Record<string, readonly string[]>>;
  drawPerAttempt?: number | null;
  /** Nombre de fois où chaque question a déjà été posée à l'apprenant (tentatives précédentes). */
  seen?: ReadonlyMap<string, number> | Readonly<Record<string, number>>;
  rand?: () => number;
};

function seenCount(seen: DrawOptions["seen"], id: string): number {
  if (!seen) return 0;
  if (seen instanceof Map) return seen.get(id) ?? 0;
  return (seen as Record<string, number>)[id] ?? 0;
}

/** Groupes de questions par compétence : d'abord la map `competences`, puis le champ `competence` des questions restantes. */
export function competenceGroups(questions: readonly DrawableQuestion[], competences?: DrawOptions["competences"]): Map<string, string[]> {
  const ids = new Set(questions.map((q) => q.id));
  const placed = new Set<string>();
  const groups = new Map<string, string[]>();
  for (const [comp, list] of Object.entries(competences ?? {})) {
    const members = list.filter((id) => ids.has(id) && !placed.has(id));
    members.forEach((id) => placed.add(id));
    if (members.length) groups.set(comp, members);
  }
  for (const q of questions) {
    if (placed.has(q.id)) continue;
    const comp = q.competence ?? "—";
    groups.set(comp, [...(groups.get(comp) ?? []), q.id]);
    placed.add(q.id);
  }
  return groups;
}

/** Quotas par compétence (plus forts restes), dont la somme vaut min(draw, nombre de questions). */
export function stratifiedQuotas(sizes: ReadonlyMap<string, number>, draw: number): Map<string, number> {
  const entries = [...sizes.entries()].filter(([, n]) => n > 0).sort((a, b) => a[0].localeCompare(b[0], "fr", { numeric: true }));
  const total = entries.reduce((s, [, n]) => s + n, 0);
  const target = Math.max(0, Math.min(Math.floor(draw), total));
  const quotas = new Map<string, number>();
  if (target === 0 || total === 0) {
    entries.forEach(([c]) => quotas.set(c, 0));
    return quotas;
  }
  const raw = entries.map(([c, n]) => ({ c, n, exact: (n / total) * target }));
  raw.forEach((r) => quotas.set(r.c, Math.min(r.n, Math.floor(r.exact))));
  let left = target - [...quotas.values()].reduce((s, v) => s + v, 0);
  // Plus forts restes d'abord ; à égalité, la compétence la plus fournie, puis l'ordre alphabétique (stable).
  const byRemainder = [...raw].sort((a, b) => b.exact - Math.floor(b.exact) - (a.exact - Math.floor(a.exact)) || b.n - a.n || a.c.localeCompare(b.c, "fr", { numeric: true }));
  while (left > 0) {
    let progressed = false;
    for (const r of byRemainder) {
      if (left === 0) break;
      if (quotas.get(r.c)! < r.n) {
        quotas.set(r.c, quotas.get(r.c)! + 1);
        left--;
        progressed = true;
      }
    }
    if (!progressed) break;
  }
  return quotas;
}

/**
 * Ids des questions tirées pour une tentative, dans l'ordre de la banque (le mélange vient ensuite).
 * Renvoie toutes les questions si `drawPerAttempt` est absent, invalide ou ≥ taille de la banque.
 */
export function drawExamQuestionIds(questions: readonly DrawableQuestion[], opts: DrawOptions = {}): string[] {
  const all = questions.map((q) => q.id);
  const draw = opts.drawPerAttempt;
  if (draw === null || draw === undefined || !Number.isFinite(draw) || draw <= 0 || draw >= all.length) return all;
  const rand = opts.rand ?? Math.random;
  const groups = competenceGroups(questions, opts.competences);
  const quotas = stratifiedQuotas(new Map([...groups].map(([c, ids]) => [c, ids.length])), draw);
  const picked = new Set<string>();
  for (const [comp, ids] of [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0], "fr", { numeric: true }))) {
    const quota = quotas.get(comp) ?? 0;
    if (quota === 0) continue;
    // Mélange puis tri stable par nombre de passages : inédites d'abord, au hasard entre elles.
    const ordered = shuffle(ids, rand)
      .map((id, i) => ({ id, i, n: seenCount(opts.seen, id) }))
      .sort((a, b) => a.n - b.n || a.i - b.i);
    ordered.slice(0, quota).forEach((o) => picked.add(o.id));
  }
  return all.filter((id) => picked.has(id));
}

/** Compte les passages de chaque question dans des tentatives précédentes (`questionOrder` stockés). */
export function seenQuestionCounts(previousOrders: readonly (readonly string[] | null | undefined)[]): Map<string, number> {
  const seen = new Map<string, number>();
  for (const order of previousOrders) for (const id of order ?? []) seen.set(id, (seen.get(id) ?? 0) + 1);
  return seen;
}

/** Nombre de questions posées à chaque tentative (affichage des règles). */
export function questionsPerAttempt(exam: { questions: readonly unknown[]; drawPerAttempt?: number | null }): number {
  const d = exam.drawPerAttempt;
  return d && d > 0 && d < exam.questions.length ? Math.floor(d) : exam.questions.length;
}
