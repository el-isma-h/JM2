/**
 * Catalogue des badges et règles d'obtention. `evaluateBadges(ctx)` renvoie la liste des badges mérités ;
 * la couche serveur (`syncBadges`) insère ceux qui manquent dans `user_badges` (jamais de retrait).
 *
 * `icon` est le nom d'une icône @phosphor-icons/react (voir components/badges/badge-icon.tsx).
 */
import { earnsLaborantin } from "./labo/tools";

export type BadgeCategory = "progression" | "regularite" | "maitrise" | "certification" | "exploration";

export type BadgeDef = {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: BadgeCategory;
};

export const BADGES = [
  { id: "premiere-lecon", title: "Premier pas", description: "Terminer votre première leçon.", icon: "Footprints", category: "progression" },
  { id: "lecons-10", title: "Lancé", description: "Terminer 10 leçons.", icon: "BookOpen", category: "progression" },
  { id: "lecons-50", title: "Assidu", description: "Terminer 50 leçons.", icon: "Books", category: "progression" },
  { id: "lecons-150", title: "Intégrale", description: "Terminer toutes les leçons de la formation.", icon: "Crown", category: "progression" },
  { id: "module-termine", title: "Module bouclé", description: "Terminer toutes les leçons d'un module et réussir son quiz.", icon: "SquaresFour", category: "progression" },
  { id: "premier-quiz", title: "Premier quiz", description: "Réussir votre premier quiz de module.", icon: "Question", category: "maitrise" },
  { id: "sans-faute", title: "Sans faute", description: "Obtenir 100 % à un quiz de module.", icon: "Target", category: "maitrise" },
  { id: "sans-faute-5", title: "Précision", description: "Obtenir 100 % à cinq quiz de module différents.", icon: "Crosshair", category: "maitrise" },
  { id: "serie-3", title: "Trois jours", description: "Apprendre trois jours d'affilée.", icon: "Flame", category: "regularite" },
  { id: "serie-7", title: "Une semaine", description: "Apprendre sept jours d'affilée.", icon: "CalendarCheck", category: "regularite" },
  { id: "serie-30", title: "Un mois", description: "Apprendre trente jours d'affilée.", icon: "Medal", category: "regularite" },
  { id: "oiseau-de-nuit", title: "Oiseau de nuit", description: "Terminer une leçon entre minuit et 5 h.", icon: "MoonStars", category: "regularite" },
  { id: "leve-tot", title: "Lève-tôt", description: "Terminer une leçon entre 5 h et 7 h.", icon: "SunHorizon", category: "regularite" },
  { id: "niveau-1", title: "Utilisateur IA certifié", description: "Réussir l'examen du niveau 1.", icon: "Certificate", category: "certification" },
  { id: "niveau-2", title: "Praticien IA", description: "Réussir l'examen du niveau 2.", icon: "Lightning", category: "certification" },
  { id: "niveau-3", title: "Développeur IA", description: "Réussir l'examen du niveau 3.", icon: "Code", category: "certification" },
  { id: "niveau-4", title: "Expert IA", description: "Réussir l'examen du niveau 4.", icon: "Brain", category: "certification" },
  { id: "examen-premier-coup", title: "Du premier coup", description: "Réussir un examen de niveau dès la première tentative.", icon: "Trophy", category: "certification" },
  { id: "tuteur-consulte", title: "Bonne question", description: "Poser une première question au tuteur IA.", icon: "ChatCircleDots", category: "exploration" },
  { id: "cle-api", title: "Autonome", description: "Configurer votre propre clé API.", icon: "Key", category: "exploration" },
  // v1.1 — enrichissements pédagogiques (missions documentation, quiz éclair, lexique)
  { id: "detective-5", title: "Détective de la doc", description: "Accomplir 5 missions documentation.", icon: "MagnifyingGlass", category: "exploration" },
  { id: "detective-25", title: "Détective de la doc II", description: "Accomplir 25 missions documentation.", icon: "Binoculars", category: "exploration" },
  { id: "detective-100", title: "Détective de la doc III", description: "Accomplir 100 missions documentation.", icon: "Detective", category: "exploration" },
  { id: "eclair-50", title: "Éclair", description: "Répondre juste à 50 quiz éclair dans les leçons.", icon: "LightningA", category: "maitrise" },
  { id: "lexicographe", title: "Lexicographe", description: "Consulter 30 termes du lexique.", icon: "BookBookmark", category: "exploration" },
  // v1.3 — Labo
  { id: "laborantin", title: "Laborantin", description: "Utiliser les cinq outils du Labo.", icon: "Flask", category: "exploration" },
] as const satisfies readonly BadgeDef[];

export type BadgeId = (typeof BADGES)[number]["id"];

export const BADGE_BY_ID: Record<string, BadgeDef> = Object.fromEntries(BADGES.map((b) => [b.id, b]));

/** Seuils des badges v1.1. */
export const BADGE_THRESHOLDS = { missions: [5, 25, 100], flashQuizCorrect: 50, lexiconTerms: 30 } as const;

const LEVEL_BADGE = /^niveau-([1-9])$/;

/** Badge d'examen de niveau `niveau-{n}` : défini au catalogue pour N1 à N4, générique au-delà (N5…). */
export function levelBadgeId(levelId: string): string | null {
  const m = /^N([1-9])$/.exec(levelId);
  return m ? `niveau-${m[1]}` : null;
}

function genericLevelBadge(n: number): BadgeDef {
  return { id: `niveau-${n}`, title: `Niveau ${n} validé`, description: `Réussir l'examen du niveau ${n}.`, icon: "SealCheck", category: "certification" };
}

/** Définition d'un badge (catalogue, ou badge de niveau générique pour un niveau ajouté au programme). */
export function badgeDef(id: string): BadgeDef | undefined {
  if (BADGE_BY_ID[id]) return BADGE_BY_ID[id];
  const m = LEVEL_BADGE.exec(id);
  return m ? genericLevelBadge(Number(m[1])) : undefined;
}

/**
 * Catalogue affiché pour un programme donné : les badges fixes, plus un badge de niveau générique pour chaque niveau
 * du programme qui n'en a pas (N5…), inséré après les badges de niveau existants.
 */
export function badgeCatalog(levelIds: readonly string[]): BadgeDef[] {
  const extra = levelIds
    .map(levelBadgeId)
    .filter((id): id is string => id !== null && !BADGE_BY_ID[id])
    .map((id) => genericLevelBadge(Number(id.slice("niveau-".length))));
  const out: BadgeDef[] = [...BADGES];
  if (extra.length) {
    const last = out.reduce((acc, b, i) => (LEVEL_BADGE.test(b.id) ? i : acc), -1);
    out.splice(last + 1, 0, ...extra);
  }
  return out;
}

export type BadgeContext = {
  /** Dates de fin des leçons terminées. */
  lessonCompletions: readonly Date[];
  /** Nombre de modules terminés (leçons + quiz réussi). */
  modulesCompleted: number;
  /** Tentatives de quiz (au moins `moduleId`, `percent`, `passed`). */
  quizAttempts: readonly { moduleId: string; percent: number; passed: boolean }[];
  /** Niveaux dont l'examen est réussi. */
  passedExams: ReadonlySet<string>;
  /** Pour chaque niveau réussi : numéro (1-based) de la tentative réussie, hors tentatives annulées. */
  examPassAttemptNumber: Readonly<Record<string, number>>;
  /** Plus longue série de jours. */
  longestStreak: number;
  tutorQuestions: number;
  hasPersonalApiKey: boolean;
  /** Nombre total de leçons du programme (badge « Intégrale ») ; 150 par défaut. */
  totalLessons?: number;
  /** Missions documentation accomplies (v1.1). */
  missionsCompleted?: number;
  /** Quiz éclair des leçons réussis (v1.1). */
  flashQuizCorrect?: number;
  /** Termes distincts consultés dans le lexique (v1.1). */
  lexiconTermsViewed?: number;
  /** Outils du Labo utilisés (ids, v1.3). */
  laboToolsUsed?: readonly string[];
  /** Heure (0-23, Europe/Paris) d'un instant : injectée pour garder le domaine pur et testable. */
  hourOf: (d: Date) => number;
};

export function evaluateBadges(ctx: BadgeContext): string[] {
  const earned: string[] = [];
  const add = (id: BadgeId | `niveau-${number}`, cond: boolean) => {
    if (cond) earned.push(id);
  };
  const lessons = ctx.lessonCompletions.length;
  const perfectModules = new Set(ctx.quizAttempts.filter((a) => a.percent >= 100).map((a) => a.moduleId));
  const hours = ctx.lessonCompletions.map(ctx.hourOf);

  add("premiere-lecon", lessons >= 1);
  add("lecons-10", lessons >= 10);
  add("lecons-50", lessons >= 50);
  add("lecons-150", lessons >= Math.max(1, ctx.totalLessons ?? 150));
  add("module-termine", ctx.modulesCompleted >= 1);
  add("premier-quiz", ctx.quizAttempts.some((a) => a.passed));
  add("sans-faute", perfectModules.size >= 1);
  add("sans-faute-5", perfectModules.size >= 5);
  add("serie-3", ctx.longestStreak >= 3);
  add("serie-7", ctx.longestStreak >= 7);
  add("serie-30", ctx.longestStreak >= 30);
  add("oiseau-de-nuit", hours.some((h) => h >= 0 && h < 5));
  add("leve-tot", hours.some((h) => h >= 5 && h < 7));
  // Un badge par niveau réussi, quel que soit le nombre de niveaux du programme (niveau-1 … niveau-9).
  for (const levelId of [...ctx.passedExams].sort()) {
    const id = levelBadgeId(levelId);
    if (id) add(id as `niveau-${number}`, true);
  }
  add("examen-premier-coup", Object.values(ctx.examPassAttemptNumber).some((n) => n === 1));
  add("tuteur-consulte", ctx.tutorQuestions >= 1);
  add("cle-api", ctx.hasPersonalApiKey);
  const missions = ctx.missionsCompleted ?? 0;
  add("detective-5", missions >= BADGE_THRESHOLDS.missions[0]);
  add("detective-25", missions >= BADGE_THRESHOLDS.missions[1]);
  add("detective-100", missions >= BADGE_THRESHOLDS.missions[2]);
  add("eclair-50", (ctx.flashQuizCorrect ?? 0) >= BADGE_THRESHOLDS.flashQuizCorrect);
  add("lexicographe", (ctx.lexiconTermsViewed ?? 0) >= BADGE_THRESHOLDS.lexiconTerms);
  add("laborantin", earnsLaborantin(ctx.laboToolsUsed ?? []));
  return earned;
}

/** Badges mérités qui ne sont pas encore attribués. */
export function newBadges(earned: readonly string[], owned: readonly string[]): string[] {
  const have = new Set(owned);
  return earned.filter((id) => !have.has(id));
}
