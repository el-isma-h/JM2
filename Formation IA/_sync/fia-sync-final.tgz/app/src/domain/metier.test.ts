import { describe, expect, it } from "vitest";
import { metierBlockRef, metierProgress } from "./metier";

const order = ["L001", "L002", "L005", "L008", "L011", "L015", "L021"];

describe("parcours métier", () => {
  it("prochaine leçon prioritaire = première non terminée dans l'ordre du programme", () => {
    const lessons = [
      { id: "L015", priority: true },
      { id: "L011", priority: true },
      { id: "L005", priority: true },
      { id: "L021", priority: false },
    ];
    expect(metierProgress(lessons, new Set(), order).nextLessonId).toBe("L005");
    expect(metierProgress(lessons, new Set(["L005"]), order).nextLessonId).toBe("L011");
    const p = metierProgress(lessons, new Set(["L005", "L011"]), order);
    expect(p).toMatchObject({ done: 2, total: 3, percent: 67, nextLessonId: "L015" });
  });

  it("les facultatives ne comptent pas ; tout terminé → null", () => {
    const lessons = [
      { id: "L002", priority: true },
      { id: "L021", priority: false },
    ];
    expect(metierProgress(lessons, new Set(["L002"]), order)).toEqual({ done: 1, total: 1, percent: 100, nextLessonId: null });
  });

  it("une leçon inconnue du programme passe en dernier ; parcours vide → 0 %", () => {
    expect(metierProgress([{ id: "L999", priority: true }, { id: "L008", priority: true }], new Set(), order).nextLessonId).toBe("L008");
    expect(metierProgress([], new Set(), order)).toEqual({ done: 0, total: 0, percent: 0, nextLessonId: null });
  });

  it("référence XP stable", () => {
    expect(metierBlockRef("rh", 2)).toBe("metier:rh:2");
  });
});
