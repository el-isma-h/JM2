/**
 * Examens blancs d'entraînement (v1.4) : correction et score par domaine. Fonctions pures.
 * Aucun certificat, aucun XP d'examen : +20 XP par session terminée, au plus une fois par jour et par examen.
 */

export type PracticeGradable = { id: string; domaine: string; answer: number; options: readonly string[] };

export type PracticeDomainScore = { domaine: string; correct: number; total: number; percent: number };

export type PracticeGrade = {
  score: number;
  total: number;
  /** Arrondi à 0,1. */
  percent: number;
  passed: boolean;
  answered: number;
  byDomain: PracticeDomainScore[];
  /** Réponse donnée (index d'origine) et justesse, par question. */
  items: { questionId: string; choice: number | null; correct: boolean }[];
};

const round1 = (v: number) => Math.round(v * 10) / 10;

/**
 * Corrige une session. `answers` : id de question → index d'option choisi (ordre du fichier), null ou absent = sans réponse.
 * Une réponse hors bornes compte comme sans réponse. Les domaines sont listés dans l'ordre `domainOrder`, puis dans
 * l'ordre d'apparition des questions.
 */
export function gradePractice(questions: readonly PracticeGradable[], answers: Readonly<Record<string, number | null | undefined>>, passScore: number, domainOrder: readonly string[] = []): PracticeGrade {
  const domains = new Map<string, { correct: number; total: number }>();
  for (const d of domainOrder) domains.set(d, { correct: 0, total: 0 });
  let score = 0;
  let answered = 0;
  const items = questions.map((q) => {
    const raw = answers[q.id];
    const choice = typeof raw === "number" && Number.isInteger(raw) && raw >= 0 && raw < q.options.length ? raw : null;
    const correct = choice !== null && choice === q.answer;
    if (choice !== null) answered++;
    if (correct) score++;
    const d = domains.get(q.domaine) ?? { correct: 0, total: 0 };
    d.total++;
    if (correct) d.correct++;
    domains.set(q.domaine, d);
    return { questionId: q.id, choice, correct };
  });
  const total = questions.length;
  const percent = total ? round1((score / total) * 100) : 0;
  return {
    score,
    total,
    percent,
    passed: total > 0 && percent >= passScore,
    answered,
    byDomain: [...domains.entries()].filter(([, v]) => v.total > 0).map(([domaine, v]) => ({ domaine, correct: v.correct, total: v.total, percent: round1((v.correct / v.total) * 100) })),
    items,
  };
}

/** Durée retenue d'une session (secondes) : écart borné entre 0 et 6 h (horloge client indicative). */
export function practiceDurationSeconds(startedAt: Date, submittedAt: Date): number {
  const s = Math.round((submittedAt.getTime() - startedAt.getTime()) / 1000);
  return Number.isFinite(s) ? Math.max(0, Math.min(6 * 3600, s)) : 0;
}

/** Leçons à réviser : celles des questions ratées ou sans réponse, par fréquence décroissante puis ordre d'apparition. */
export function lessonsToReview(questions: readonly { id: string; lessonId: string }[], items: readonly { questionId: string; correct: boolean }[], limit = 8): string[] {
  const byId = new Map(questions.map((q) => [q.id, q.lessonId]));
  const count = new Map<string, number>();
  for (const it of items) {
    if (it.correct) continue;
    const l = byId.get(it.questionId);
    if (l && /^L\d{3}$/.test(l)) count.set(l, (count.get(l) ?? 0) + 1);
  }
  return [...count.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([id]) => id);
}
