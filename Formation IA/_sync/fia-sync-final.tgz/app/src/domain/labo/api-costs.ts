/**
 * Labo — comparateur de coûts API (leçon L067, module M16 ; grille confirmée par `_recherche/01`, `02` et `07`).
 *
 * Reprend EXACTEMENT le calculateur Python de L067 (`calcul_cout.py`) :
 *   coût d'un appel = (entrée non cachée × prix entrée + sortie × prix sortie
 *                      + tokens lus en cache × prix cache lecture + tokens écrits en cache × prix cache écriture) ÷ 1 000 000
 *   × multiplicateur batch si le mode batch est utilisé
 *   coût mensuel = coût d'un appel × appels par jour × jours (22 jours ouvrés par défaut)
 *                  + écritures de cache (n par jour × jours)
 * Tarifs en dollars par million de tokens (tarif standard), pages officielles lues le 1er novembre 2026.
 * Les hypothèses de L067 sont conservées (xAI : écriture de cache au tarif d'entrée ; Mistral : batch 0,5 à vérifier ;
 * Google : cache 0,1× à vérifier).
 */

export type Provider = "Anthropic" | "OpenAI" | "xAI" | "Google" | "Mistral";

export type Tariff = {
  id: string;
  label: string;
  provider: Provider;
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
  /** Multiplicateur du mode batch (0,5 = −50 %). */
  batch: number;
  /** Palier « longues requêtes » : au-delà de `above` tokens d'entrée, autres prix. */
  longContext?: { above: number; input: number; output: number; cacheRead: number; cacheWrite: number };
  note?: string;
};

export const PRICING_DATE = "1er novembre 2026";
export const PRICING_LABEL = "nov. 2026";

export const PROVIDER_PRICING_URL: Record<Provider, string> = {
  Anthropic: "https://platform.claude.com/docs/en/about-claude/pricing",
  OpenAI: "https://developers.openai.com/api/docs/pricing",
  xAI: "https://docs.x.ai/developers/pricing",
  Google: "https://ai.google.dev/gemini-api/docs/pricing",
  Mistral: "https://docs.mistral.ai/inference/pricing",
};

export const TARIFFS: Tariff[] = [
  {
    id: "claude-haiku-5-5",
    label: "Claude Haiku 5.5",
    provider: "Anthropic",
    input: 0.1,
    output: 0.5,
    cacheRead: 0.01,
    cacheWrite: 0.125,
    batch: 0.5,
    longContext: { above: 100_000, input: 0.5, output: 2.5, cacheRead: 0.05, cacheWrite: 0.625 },
    note: "Tarif plus élevé au-delà de 100k tokens d'entrée par requête.",
  },
  { id: "claude-sonnet-5-5", label: "Claude Sonnet 5.5", provider: "Anthropic", input: 2, output: 10, cacheRead: 0.1, cacheWrite: 2.5, batch: 0.5 },
  { id: "claude-opus-5-5", label: "Claude Opus 5.5", provider: "Anthropic", input: 4, output: 20, cacheRead: 0.2, cacheWrite: 5, batch: 0.5 },
  { id: "gpt-6-astra", label: "GPT-6 Astra", provider: "OpenAI", input: 10, output: 50, cacheRead: 1, cacheWrite: 12.5, batch: 0.5 },
  { id: "gpt-6.1-sol", label: "GPT-6.1 Sol", provider: "OpenAI", input: 2, output: 10, cacheRead: 0.1, cacheWrite: 2.5, batch: 0.5 },
  { id: "gpt-6.1-terra", label: "GPT-6.1 Terra", provider: "OpenAI", input: 1, output: 5, cacheRead: 0.05, cacheWrite: 1.25, batch: 0.5 },
  { id: "gpt-6-luna", label: "GPT-6 Luna", provider: "OpenAI", input: 0.1, output: 0.5, cacheRead: 0.01, cacheWrite: 0.125, batch: 0.5 },
  {
    id: "grok-4.7",
    label: "Grok 4.7",
    provider: "xAI",
    input: 2,
    output: 6,
    cacheRead: 0.5,
    cacheWrite: 2,
    batch: 0.8,
    longContext: { above: 200_000, input: 4, output: 12, cacheRead: 0.5, cacheWrite: 4 },
    note: "Batch −20 %. Prix doublés au-delà de 200k tokens.",
  },
  { id: "gemini-4-argon", label: "Gemini 4 Argon", provider: "Google", input: 2, output: 10, cacheRead: 0.2, cacheWrite: 2, batch: 0.5, note: "Passe à 4 / 20 $ le 1er décembre 2026." },
  { id: "gemini-3.8-flash", label: "Gemini 3.8 Flash", provider: "Google", input: 0.75, output: 3.75, cacheRead: 0.075, cacheWrite: 0.75, batch: 0.5, note: "Passe à 1,50 / 7,50 $ le 1er janvier 2027." },
  { id: "mistral-large-4", label: "Mistral Large 4", provider: "Mistral", input: 0.7, output: 2.1, cacheRead: 0.07, cacheWrite: 0.7, batch: 0.5, note: "Multiplicateur batch non chiffré sur la page : hypothèse 0,5." },
  { id: "mistral-small-4", label: "Mistral Small 4", provider: "Mistral", input: 0.15, output: 0.6, cacheRead: 0.015, cacheWrite: 0.15, batch: 0.5, note: "Multiplicateur batch non chiffré sur la page : hypothèse 0,5." },
];

export const TARIFF_BY_ID: Record<string, Tariff> = Object.fromEntries(TARIFFS.map((t) => [t.id, t]));

export type CallTokens = {
  /** Tokens d'entrée NON cachés. */
  input: number;
  output: number;
  cacheRead?: number;
  cacheWrite?: number;
};

function rates(t: Tariff, totalInput: number) {
  return t.longContext && totalInput > t.longContext.above ? t.longContext : t;
}

/** Coût en USD d'un appel (fonction `cout_appel` de L067). */
export function callCost(t: Tariff, c: CallTokens, batch = false): number {
  const totalInput = c.input + (c.cacheRead ?? 0) + (c.cacheWrite ?? 0);
  const r = rates(t, totalInput);
  const usd = (c.input * r.input + c.output * r.output + (c.cacheRead ?? 0) * r.cacheRead + (c.cacheWrite ?? 0) * r.cacheWrite) / 1_000_000;
  return batch ? usd * t.batch : usd;
}

export type Scenario = {
  /** Tokens d'entrée par requête (dont la partie mise en cache). */
  inputTokens: number;
  outputTokens: number;
  requestsPerDay: number;
  daysPerMonth: number;
  /** Tokens du préfixe stable (prompt système, documents) lus depuis le cache ; 0 = pas de cache. */
  cachedTokens: number;
  /** Réécritures du cache par jour (expiration du TTL, pauses, nuit). L067 : ~20 par jour. */
  cacheWritesPerDay: number;
  batch: boolean;
};

export const DEFAULT_SCENARIO: Scenario = { inputTokens: 900, outputTokens: 120, requestsPerDay: 300, daysPerMonth: 22, cachedTokens: 0, cacheWritesPerDay: 20, batch: false };

export type MonthlyCost = { tariff: Tariff; perCall: number; monthly: number; withoutOptimisations: number; savingsPercent: number };

/** Coût mensuel d'un scénario pour un modèle. */
export function monthlyCost(t: Tariff, s: Scenario): MonthlyCost {
  const cached = Math.min(Math.max(0, s.cachedTokens), Math.max(0, s.inputTokens));
  const fresh = Math.max(0, s.inputTokens) - cached;
  const calls = Math.max(0, s.requestsPerDay) * Math.max(0, s.daysPerMonth);
  const perCall = callCost(t, { input: fresh, output: Math.max(0, s.outputTokens), cacheRead: cached }, s.batch);
  const writes = cached > 0 ? callCost(t, { input: 0, output: 0, cacheWrite: cached }, false) * Math.max(0, s.cacheWritesPerDay) * Math.max(0, s.daysPerMonth) : 0;
  const monthly = perCall * calls + writes;
  const withoutOptimisations = callCost(t, { input: Math.max(0, s.inputTokens), output: Math.max(0, s.outputTokens) }) * calls;
  const savingsPercent = withoutOptimisations > 0 ? (1 - monthly / withoutOptimisations) * 100 : 0;
  return { tariff: t, perCall, monthly, withoutOptimisations, savingsPercent };
}

export function compareCosts(s: Scenario, tariffs: readonly Tariff[] = TARIFFS): MonthlyCost[] {
  return tariffs.map((t) => monthlyCost(t, s)).sort((a, b) => a.monthly - b.monthly);
}

/** Format « 19,80 $ » ; centimes de dollar pour les petits montants. */
export function formatUsd(v: number): string {
  if (v > 0 && v < 0.01) return `${v.toLocaleString("fr-FR", { maximumSignificantDigits: 2 })} $`;
  const digits = v < 1 && v > 0 ? 3 : 2;
  return `${v.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: digits })} $`;
}
