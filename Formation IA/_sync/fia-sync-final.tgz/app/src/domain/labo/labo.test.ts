import { describe, expect, it } from "vitest";
import { MACHINES, MOE_UNIFIED_BANDWIDTH_CAP, estimateLlm, kvCacheGb, machineSpeedTps, machineVerdict, speedTps, weightsGb } from "./llm-memory";
import { LANGUAGE_PAIRS, detectLanguage, estimateClaudeTokens, inputCostUsd, splitWord, tokenStats, tokenize } from "./tokenizer";
import { CAT_CANDIDATES, applyTemperature, entropyBits, keptCount, sampleIndex, shapeDistribution } from "./sampling";
import { DEFAULT_SCENARIO, TARIFF_BY_ID, callCost, compareCosts, monthlyCost } from "./api-costs";
import { L047_PHRASES, cosine, isNearestGuess, nearest, rankNeighbours, snap } from "./embeddings";
import { LABO_TOOL_IDS, earnsLaborantin, laboToolsUsedCount } from "./tools";
import { seededRandom } from "../exam";

const machine = (id: string) => MACHINES.find((m) => m.id === id)!;
const close = (a: number, b: number, eps = 0.05) => expect(Math.abs(a - b)).toBeLessThanOrEqual(eps);

describe("calculateur LLM local (exemples de L042)", () => {
  it("applique Go ≈ B × bits ÷ 8 × 1,1", () => {
    close(weightsGb(8, 4), 4.4);
    close(weightsGb(27, 4), 14.85);
    close(weightsGb(70, 4), 38.5);
    close(weightsGb(8, 16), 17.6);
    close(weightsGb(32, 4), 17.6); // quiz de L042
    close(weightsGb(14, 8), 15.4); // auto-évaluation de L042
  });

  it("estime le KV cache aux ordres de grandeur de la leçon (Llama 3 FP16)", () => {
    close(kvCacheGb(8, 8000), 1.05); // 131 Mo / 1 000 tokens
    close(kvCacheGb(70, 8000), 2.62); // 328 Mo / 1 000 tokens
    expect(kvCacheGb(70, 32_000)).toBeGreaterThan(10); // « plus de 10 Go pour 32K »
    close(kvCacheGb(27, 8000), 1.5, 0.1); // corrigé de l'exercice 1 (~1,5 Go)
  });

  it("totalise poids + KV cache et calcule le disque", () => {
    const e = estimateLlm({ totalB: 70, precision: "Q4", contextTokens: 8000 });
    close(e.totalGb, 41.1, 0.2); // « 38,5 Go (+2,6 Go ≈ 41 Go) »
    close(e.diskGb, 38.5);
    expect(e.readPerTokenGb).toBeCloseTo(e.weightsGb);
  });

  it("vitesse = bande passante ÷ Go lus × rendement (exemples de L042)", () => {
    close(speedTps(546, 3.9, 1), 140, 0.5); // M4 Max sur 7B Q4 : ≈ 140 théoriques
    close(speedTps(1792, 4.4, 1), 407, 1); // RTX 5090 : ≈ 407 théoriques
    close(speedTps(273, 4.4, 1), 62, 0.5); // DGX Spark : ≈ 62 théoriques
  });

  it("retrouve les vitesses mesurées d'un 8B Q4 citées par la leçon", () => {
    const e = estimateLlm({ totalB: 8, precision: "Q4", contextTokens: 8192 });
    close(machineVerdict(machine("mac16"), e).tokensPerSecond!, 24, 1);
    close(machineVerdict(machine("rtx3060"), e).tokensPerSecond!, 42, 1);
    close(machineVerdict(machine("rtx4090"), e).tokensPerSecond!, 104, 2);
    close(machineVerdict(machine("rtx5090"), e).tokensPerSecond!, 145, 3);
    close(machineVerdict(machine("spark"), e).tokensPerSecond!, 38, 1);
  });

  it("verdicts du grand tableau : 70B ne tient pas sur une 5090, gpt-oss-120b tient sur le Spark", () => {
    const d70 = estimateLlm({ totalB: 70, precision: "Q4", contextTokens: 8192 });
    expect(machineVerdict(machine("rtx5090"), d70).verdict).toBe("impossible");
    expect(machineVerdict(machine("mac64"), d70).verdict).toBe("lent"); // ⚠️ ~8–12 tok/s
    expect(machineVerdict(machine("mac128"), d70).fits).toBe(true);
    const oss = estimateLlm({ totalB: 116.8, activeB: 5.1, precision: "Q4", contextTokens: 32_768 });
    const spark = machineVerdict(machine("spark"), oss);
    expect(spark.fits).toBe(true);
    // Plafond MoE en mémoire unifiée : ≈ 40 tok/s, mesuré 40,5 tok/s à 32K (fourchette 38,6–60,6) dans le tableau de L042.
    close(spark.tokensPerSecond!, 40.5, 1.5);
    expect(spark.tokensPerSecond!).toBeGreaterThanOrEqual(38.6);
    // La règle simple de l'exercice 4 (× 0,6, sans plafond) reste celle de la leçon : ≈ 47 tok/s.
    close(speedTps(273, 3.5, 0.6), 47, 0.5);
    expect(machineVerdict(machine("mac64"), oss).fits).toBe(false); // 66 Go > 75 % de 64
    const mac16 = machineVerdict(machine("mac16"), estimateLlm({ totalB: 8, precision: "Q4", contextTokens: 8192 }));
    expect(mac16.verdict).toBe("confort"); // défi de L042 : MacBook Air M4 16 Go → 8B Q4
  });

  it("gpt-oss-120b sur Mac 128 Go : ≈ 35–45 tok/s comme dans L042 (plafond MoE en mémoire unifiée)", () => {
    const oss = estimateLlm({ totalB: 116.8, activeB: 5.1, precision: "Q4", contextTokens: 8192 });
    close(oss.readPerTokenGb, 3.5, 0.05); // « 5,1B actifs ≈ 3,5 Go lus par token »
    const mac = machineVerdict(machine("mac128"), oss);
    expect(mac.fits).toBe(true);
    expect(mac.tokensPerSecond!).toBeGreaterThanOrEqual(35);
    expect(mac.tokensPerSecond!).toBeLessThanOrEqual(45);
    expect(mac.verdict).toBe("confort");
    // Sans plafond, la règle dense donnait ≈ 104 tok/s : trop optimiste par rapport à la leçon.
    close(speedTps(546, oss.readPerTokenGb, 0.67), 104, 1);
    close(MOE_UNIFIED_BANDWIDTH_CAP / oss.readPerTokenGb, 40, 0.5);
    // gpt-oss-20b sur DGX Spark : 50–61 tok/s mesurés.
    const oss20 = estimateLlm({ totalB: 21, activeB: 3.6, precision: "Q4", contextTokens: 8192 });
    const spark20 = machineVerdict(machine("spark"), oss20).tokensPerSecond!;
    expect(spark20).toBeGreaterThanOrEqual(50);
    expect(spark20).toBeLessThanOrEqual(61);
  });

  it("le plafond MoE ne touche ni les modèles denses, ni les GPU NVIDIA", () => {
    const d8 = estimateLlm({ totalB: 8, precision: "Q4", contextTokens: 8192 });
    expect(d8.moe).toBe(false);
    close(machineSpeedTps(machine("mac128"), d8), speedTps(546, d8.readPerTokenGb, 0.67), 1e-9); // 8B dense : ≈ 83 tok/s
    close(machineSpeedTps(machine("mac128"), d8), 83, 2);
    const oss20 = estimateLlm({ totalB: 21, activeB: 3.6, precision: "Q4", contextTokens: 8192 });
    expect(machineSpeedTps(machine("rtx5090"), oss20)).toBeCloseTo(speedTps(1792, oss20.readPerTokenGb, 0.36));
    // Mac 16 Go (120 Go/s) : déjà sous le plafond, inchangé.
    expect(machineSpeedTps(machine("mac16"), oss20)).toBeCloseTo(speedTps(120, oss20.readPerTokenGb, 0.88));
  });

  it("un MoE n'est pas plus lourd à stocker, mais bien plus rapide", () => {
    const dense = estimateLlm({ totalB: 120, precision: "Q4", contextTokens: 8192 });
    const moe = estimateLlm({ totalB: 120, activeB: 5, precision: "Q4", contextTokens: 8192 });
    expect(moe.totalGb).toBeCloseTo(dense.totalGb);
    expect(moe.readPerTokenGb).toBeLessThan(dense.readPerTokenGb / 10);
  });
});

describe("tokeniseur visuel", () => {
  it("reproduit l'exemple de L005", () => {
    const toks = tokenize("Le cabinet comptable envoie une relance.").map((t) => t.text);
    expect(toks).toEqual(["Le", " cabinet", " compt", "able", " envoie", " une", " rel", "ance", "."]);
    expect(tokenStats("Le cabinet comptable envoie une relance.").tokens).toBe(9);
  });

  it("recompose exactement le texte d'origine", () => {
    const text = "Bonjour,\nma chaudière de 2009 claque ! Coût : 1 234,50 € (estimation).";
    expect(
      tokenize(text)
        .map((t) => t.text)
        .join(""),
    ).toBe(text);
  });

  it("garde les mots courants entiers et découpe les mots longs", () => {
    expect(splitWord(" maison")).toEqual([" maison"]);
    expect(splitWord("anticonstitutionnellement").length).toBeGreaterThan(3);
    expect(tokenize("12345").map((t) => t.text)).toEqual(["123", "45"]);
  });

  it("compte mots et caractères, détecte la langue", () => {
    const s = tokenStats("Le chat est assis sur le tapis.");
    expect(s.words).toBe(7);
    expect(s.chars).toBe(31);
    expect(detectLanguage("The cat is sitting on the mat.")).toBe("en");
    expect(detectLanguage("Le chat est assis sur le tapis.")).toBe("fr");
  });

  it("le français pèse plus lourd que l'anglais (paires d'exemples)", () => {
    for (const pair of LANGUAGE_PAIRS) {
      const fr = tokenStats(pair.fr, "fr");
      const en = tokenStats(pair.en, "en");
      expect(fr.claudeEstimate).toBeGreaterThan(en.claudeEstimate);
    }
  });

  it("applique la règle de L067 (1,8 token / mot anglais, 2,5 / mot français) et le prix d'entrée", () => {
    expect(estimateClaudeTokens(1000, "fr")).toBe(2500); // « 1 000 mots de français ≈ 2 500 tokens »
    expect(estimateClaudeTokens(1000, "en")).toBe(1800);
    expect(inputCostUsd(1_000_000, 2)).toBe(2);
    close(inputCostUsd(2500, 4), 0.01, 1e-9);
  });
});

describe("température, top-k, top-p", () => {
  const probs = CAT_CANDIDATES.map((c) => c.p);

  it("la distribution d'exemple somme à 1", () => {
    close(
      probs.reduce((a, b) => a + b, 0),
      1,
      1e-9,
    );
  });

  it("T = 1 ne change rien ; T = 0 choisit toujours le plus probable", () => {
    applyTemperature(probs, 1).forEach((q, i) => close(q, probs[i], 1e-9));
    expect(applyTemperature(probs, 0)).toEqual([1, 0, 0, 0, 0, 0, 0, 0]);
  });

  it("plus la température monte, plus le tirage est ouvert (entropie croissante)", () => {
    const e = [0.3, 0.7, 1, 1.5, 2].map((t) => entropyBits(applyTemperature(probs, t)));
    for (let i = 1; i < e.length; i++) expect(e[i]).toBeGreaterThan(e[i - 1]);
    expect(e.at(-1)!).toBeLessThanOrEqual(3);
  });

  it("top-k et top-p coupent la queue puis renormalisent", () => {
    const k2 = shapeDistribution(CAT_CANDIDATES, { temperature: 1, topK: 2, topP: 1 });
    expect(keptCount(k2)).toBe(2);
    close(k2[0].q, 0.4 / 0.6, 1e-9);
    const p5 = shapeDistribution(CAT_CANDIDATES, { temperature: 1, topK: 8, topP: 0.5 });
    expect(p5.filter((c) => c.kept).map((c) => c.token)).toEqual(["tapis", "canapé"]); // 0,40 + 0,20 ≥ 0,5
    const p9 = shapeDistribution(CAT_CANDIDATES, { temperature: 1, topK: 8, topP: 0.9 });
    expect(p9.find((c) => c.token === "nuage")!.kept).toBe(false);
    close(
      p9.reduce((s, c) => s + c.q, 0),
      1,
      1e-9,
    );
  });

  it("tirages reproductibles avec une graine, jamais un mot coupé", () => {
    const shaped = shapeDistribution(CAT_CANDIDATES, { temperature: 1.2, topK: 5, topP: 0.95 });
    const draw = (seed: number) => {
      const r = seededRandom(seed);
      return Array.from({ length: 50 }, () => sampleIndex(shaped, r()));
    };
    expect(draw(7)).toEqual(draw(7));
    for (const i of draw(11)) expect(shaped[i].kept).toBe(true);
    expect(sampleIndex(shaped, 0)).toBe(0);
  });
});

describe("comparateur de coûts API (calcul_cout.py de L067)", () => {
  const sonnet = TARIFF_BY_ID["claude-sonnet-5-5"];

  it("coût d'un appel typique (900 entrée, 120 sortie) sur Sonnet 5.5 : 0,003 $", () => {
    close(callCost(sonnet, { input: 900, output: 120 }), 0.003, 1e-9);
  });

  it("scénario Chauffage Martin : 300 appels/jour, 22 jours", () => {
    const expected: Record<string, [number, number]> = {
      "claude-opus-5-5": [39.6, 19.8],
      "claude-sonnet-5-5": [19.8, 9.9],
      "claude-haiku-5-5": [0.99, 0.495],
      "gpt-6.1-sol": [19.8, 9.9],
      "gpt-6-luna": [0.99, 0.495],
      "mistral-small-4": [1.3662, 0.6831],
      "gemini-3.8-flash": [7.425, 3.7125],
    };
    for (const [id, [month, batch]] of Object.entries(expected)) {
      close(monthlyCost(TARIFF_BY_ID[id], DEFAULT_SCENARIO).monthly, month, 0.01);
      close(monthlyCost(TARIFF_BY_ID[id], { ...DEFAULT_SCENARIO, batch: true }).monthly, batch, 0.01);
    }
  });

  it("prompt caching sur Sonnet 5.5 : 19,80 → 12,94 $/mois (−35 %)", () => {
    const c = monthlyCost(sonnet, { ...DEFAULT_SCENARIO, cachedTokens: 600, cacheWritesPerDay: 20 });
    close(c.monthly, 12.94, 0.01);
    close(c.withoutOptimisations, 19.8, 0.01);
    expect(Math.round(c.savingsPercent)).toBe(35);
  });

  it("paliers longues requêtes (Haiku > 100k, Grok > 200k) et batch xAI à −20 %", () => {
    const haiku = TARIFF_BY_ID["claude-haiku-5-5"];
    close(callCost(haiku, { input: 150_000, output: 0 }), 0.075, 1e-9);
    close(callCost(haiku, { input: 90_000, output: 0 }), 0.009, 1e-9);
    const grok = TARIFF_BY_ID["grok-4.7"];
    close(callCost(grok, { input: 1_000_000, output: 0 }), 4, 1e-9);
    close(callCost(grok, { input: 1000, output: 0 }, true), 0.0016, 1e-9);
  });

  it("classe les modèles du moins cher au plus cher", () => {
    const list = compareCosts(DEFAULT_SCENARIO);
    for (let i = 1; i < list.length; i++) expect(list[i].monthly).toBeGreaterThanOrEqual(list[i - 1].monthly);
    expect(list.at(-1)!.tariff.id).toBe("gpt-6-astra");
  });
});

describe("embeddings 2D (exemple de L047)", () => {
  const byId = (id: string) => L047_PHRASES.find((p) => p.id === id)!;

  it("similarités cosinus de la leçon", () => {
    close(cosine(byId("enfant"), byId("vacances")), 0.99, 0.005);
    close(cosine(byId("enfant"), byId("prime")), 0.32, 0.005);
    expect(cosine({ x: 1, y: 0 }, { x: 0, y: 1 })).toBe(0);
    expect(cosine({ x: 0, y: 0 }, { x: 1, y: 1 })).toBe(0);
  });

  it("défi de L047 : « frais de transport » est voisine de la prime, pas des congés", () => {
    expect(nearest(byId("transport"), L047_PHRASES)!.id).toBe("prime");
    expect(isNearestGuess(byId("transport"), "prime", L047_PHRASES)).toBe(true);
    expect(isNearestGuess(byId("transport"), "enfant", L047_PHRASES)).toBe(false);
    const ranked = rankNeighbours(byId("enfant"), L047_PHRASES);
    expect(ranked[0].phrase.id).toBe("vacances");
    for (let i = 1; i < ranked.length; i++) expect(ranked[i].cos).toBeLessThanOrEqual(ranked[i - 1].cos);
  });

  it("aligne les positions sur la grille 0-10 au pas de 0,5", () => {
    expect(snap(3.26)).toBe(3.5);
    expect(snap(-2)).toBe(0);
    expect(snap(12)).toBe(10);
  });
});

describe("badge Laborantin", () => {
  it("demande les cinq outils distincts", () => {
    expect(earnsLaborantin([...LABO_TOOL_IDS])).toBe(true);
    expect(earnsLaborantin(["memoire-llm", "tokeniseur", "temperature", "couts-api"])).toBe(false);
    expect(earnsLaborantin(["memoire-llm", "memoire-llm", "tokeniseur", "temperature", "couts-api", "inconnu"])).toBe(false);
    expect(laboToolsUsedCount(["tokeniseur", "tokeniseur", "x"])).toBe(1);
  });
});
