/**
 * Labo — tokeniseur visuel (leçons L005 et L067).
 *
 * Ce n'est PAS le tokenizer d'un fournisseur : c'est une découpe pédagogique « façon BPE », documentée et
 * reproductible, qui montre les phénomènes de la leçon L005 (mots courants entiers, mots longs ou rares coupés en
 * morceaux, espace collé au mot suivant, ponctuation à part, chiffres par paquets de 3). Elle reproduit l'exemple de
 * L005 : « Le cabinet comptable envoie une relance. » → [Le][ cabinet][ compt][able][ envoie][ une][ rel][ance][.]
 *
 * Règles :
 * 1. pré-découpage (un retour à la ligne reste un token à part) : (espace(s) + lettres) | (espace + 1 à 3 chiffres) | (espace + 1 signe) | blancs restants ;
 * 2. mot du vocabulaire courant (≈ 300 mots français et anglais) → 1 token ;
 * 3. mot de ≤ 4 lettres → 1 token ;
 * 4. sinon, si le mot se termine par un suffixe fréquent (tion, ment, able, ance, ière, ing…) et qu'il reste une racine
 *    d'au moins 3 lettres : racine (découpée par 4 lettres si elle en a plus de 5 et n'est pas au vocabulaire) + suffixe ;
 * 5. sinon : morceaux de 4 lettres (le dernier peut être plus court).
 *
 * Pour le COÛT, on applique la règle chiffrée de L067 (tokenizer Claude depuis Opus 4.7) :
 * ≈ 1,8 token par mot anglais, ≈ 2,5 tokens par mot français.
 */

const VOCAB_FR =
  "le la les un une des de du au aux et ou mais donc or ni car que qui quoi dont où ce cet cette ces mon ton son ma ta sa mes tes ses notre votre leur nos vos leurs je tu il elle on nous vous ils elles me te se lui y en ne pas plus moins très bien mal tout tous toute toutes avec sans pour par sur sous dans entre vers chez avant après depuis pendant comme si est sont était être avoir a ai as ont fait faire dit dire peut peux veut aller va vont vient voir sait jour jours an ans mois heure temps fois chose homme femme enfant monde pays ville maison travail cabinet envoie client clients bonjour merci madame monsieur cordialement semaine passer bruit gaz demande réponse question service équipe projet prix coût mot mots texte page modèle données chat assis tapis fenêtre lit toit petit grand bon nouveau autre même aussi encore déjà jamais toujours ici là oui non deux trois quatre cinq dix cent mille premier dernier lundi mardi mercredi jeudi vendredi samedi dimanche facture devis contrat email courriel mail rendez vous rue ville lille paris français anglais langue machine ordinateur".split(
    " ",
  );
const VOCAB_EN =
  "the a an and or but so of to in on at by for with from as is are was were be been being have has had do does did will would can could should may might must not no yes this that these those it its i you he she we they me him her us them my your his our their what which who whom where when why how all any each every some many much more most other such only own same than too very just also new old good great first last long little big high small large next early young important few public bad able get got make made go goes went see know take come think look want give use find tell ask work seem feel try leave call day days time year years people way man woman child world life hand part place case week company system program question government number night point home water room mother area money story fact month lot right study book eye job word business issue side kind head house service friend father power hour game line end member law car city community name president team minute idea kid body information back parent face others level office door health person art war history party result change morning reason research girl guy moment air teacher force education hello thanks please dear regards accounting firm sends reminder boiler noise starting cat sitting mat window bed roof price cost token tokens text model data english french language computer meeting street invoice".split(
    " ",
  );

export const VOCABULARY: ReadonlySet<string> = new Set([...VOCAB_FR, ...VOCAB_EN]);

/** Suffixes fréquents, du plus long au plus court. */
const SUFFIXES = [
  "ationnel", "ellement", "issement", "ations", "ements", "ment", "tions", "tion", "sion", "ables", "able", "ibles", "ible",
  "ances", "ance", "ences", "ence", "ières", "ière", "iers", "ier", "euses", "euse", "eurs", "eur", "ismes", "isme", "istes", "iste",
  "ités", "ité", "ique", "iques", "ives", "ive", "ness", "ing", "ings", "ers", "ally", "ful", "less", "ous", "ity", "ize", "ise",
  "ées", "ée", "és", "ed", "ly", "er", "es",
].sort((a, b) => b.length - a.length);

export type TokenKind = "word" | "piece" | "number" | "punct" | "space";
export type Token = { text: string; kind: TokenKind };

const PRE = /([^\S\n]*[\p{L}\p{M}'’]+)|([^\S\n]?\p{N}{1,3})|([^\S\n]?[^\s\p{L}\p{M}\p{N}])|(\s+)/gu;

function chunk(s: string, size = 4): string[] {
  const out: string[] = [];
  for (let i = 0; i < s.length; i += size) out.push(s.slice(i, i + size));
  return out;
}

/** Découpe un mot (avec son éventuel espace initial) en morceaux. Les longueurs suivent le mot d'origine (casse conservée). */
export function splitWord(raw: string): string[] {
  const lead = /^\s*/.exec(raw)?.[0] ?? "";
  const word = raw.slice(lead.length);
  const lower = word.toLocaleLowerCase("fr-FR").replace(/[’']/g, "'");
  const bare = lower.replace(/'/g, "");
  if (VOCABULARY.has(bare) || word.length <= 4) return [raw];
  let pieces: string[] | null = null;
  for (const suf of SUFFIXES) {
    if (lower.endsWith(suf) && lower.length - suf.length >= 3) {
      const stemLen = word.length - suf.length;
      const stem = word.slice(0, stemLen);
      const stemLower = lower.slice(0, stemLen);
      const stemPieces = stem.length <= 5 || VOCABULARY.has(stemLower) ? [stem] : chunk(stem);
      pieces = [...stemPieces, word.slice(stemLen)];
      break;
    }
  }
  pieces ??= chunk(word);
  pieces[0] = lead + pieces[0];
  return pieces;
}

/** Découpe pédagogique d'un texte en tokens. */
export function tokenize(text: string): Token[] {
  const out: Token[] = [];
  for (const m of text.matchAll(PRE)) {
    if (m[1] !== undefined) {
      const parts = splitWord(m[1]);
      parts.forEach((p) => out.push({ text: p, kind: parts.length > 1 ? "piece" : "word" }));
    } else if (m[2] !== undefined) out.push({ text: m[2], kind: "number" });
    else if (m[3] !== undefined) out.push({ text: m[3], kind: "punct" });
    else if (m[4] !== undefined) out.push({ text: m[4], kind: "space" });
  }
  return out;
}

export function countWords(text: string): number {
  return (text.match(/[\p{L}\p{N}][\p{L}\p{M}\p{N}'’-]*/gu) ?? []).length;
}

export function countChars(text: string): number {
  return [...text].length;
}

const FR_MARKERS = new Set("le la les une des du est et pour avec dans sur que qui pas nous vous être très aussi cette".split(" "));
const EN_MARKERS = new Set("the and is are of to for with in on that this you we be very also it".split(" "));

/** Langue probable (heuristique : accents et mots outils). */
export function detectLanguage(text: string): "fr" | "en" {
  const words = (text.toLocaleLowerCase("fr-FR").match(/\p{L}+/gu) ?? []).slice(0, 400);
  let fr = /[àâçéèêëîïôûùüÿœæ]/i.test(text) ? 2 : 0;
  let en = 0;
  for (const w of words) {
    if (FR_MARKERS.has(w)) fr++;
    if (EN_MARKERS.has(w)) en++;
  }
  return en > fr ? "en" : "fr";
}

/** Règle L067 (tokenizer Claude depuis Opus 4.7). */
export const TOKENS_PER_WORD = { en: 1.8, fr: 2.5 } as const;

export function estimateClaudeTokens(words: number, lang: "fr" | "en"): number {
  return Math.round(words * TOKENS_PER_WORD[lang]);
}

/** Tarifs d'ENTRÉE ($ / million de tokens), L067 — pages officielles lues le 1er nov. 2026. */
export const TOKENIZER_MODELS = [
  { id: "claude-haiku-5-5", label: "Claude Haiku 5.5", inputPerMTok: 0.1 },
  { id: "claude-sonnet-5-5", label: "Claude Sonnet 5.5", inputPerMTok: 2 },
  { id: "claude-opus-5-5", label: "Claude Opus 5.5", inputPerMTok: 4 },
] as const;

export function inputCostUsd(tokens: number, perMTok: number): number {
  return (tokens * perMTok) / 1_000_000;
}

export type TokenStats = { tokens: number; words: number; chars: number; tokensPerWord: number; lang: "fr" | "en"; claudeEstimate: number };

export function tokenStats(text: string, lang: "fr" | "en" = detectLanguage(text)): TokenStats {
  const tokens = tokenize(text).filter((t) => t.kind !== "space" || t.text.includes("\n")).length;
  const words = countWords(text);
  return { tokens, words, chars: countChars(text), tokensPerWord: words ? tokens / words : 0, lang, claudeEstimate: estimateClaudeTokens(words, lang) };
}

/** Paires d'exemples français / anglais (même sens) pour la comparaison. */
export const LANGUAGE_PAIRS = [
  {
    id: "cabinet",
    fr: "Le cabinet comptable envoie une relance.",
    en: "The accounting firm sends a reminder.",
  },
  {
    id: "chaudiere",
    fr: "Bonjour, ma chaudière gaz de 2009 fait un bruit de claquement au démarrage, pouvez-vous passer cette semaine ?",
    en: "Hello, my 2009 gas boiler makes a clicking noise when starting, can you come by this week?",
  },
  {
    id: "anticonstitutionnellement",
    fr: "Une décision prise anticonstitutionnellement reste contestable.",
    en: "A decision taken unconstitutionally remains open to challenge.",
  },
] as const;
