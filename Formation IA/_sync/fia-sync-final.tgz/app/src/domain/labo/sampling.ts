/**
 * Labo — simulateur de température, top-k et top-p (leçons L006 et L008).
 *
 * Le modèle produit une probabilité pour chaque token candidat, puis en TIRE UN AU SORT. Ordre d'application
 * (celui des bibliothèques courantes) : température → top-k → top-p → renormalisation → tirage.
 * - Température T : p_i ∝ p_i^(1/T) (équivaut à diviser les logits par T) ; T = 0 → choix glouton du plus probable.
 * - top-k : on ne garde que les k candidats les plus probables.
 * - top-p (nucleus) : on garde le plus petit ensemble dont la probabilité cumulée atteint p.
 *
 * Rappel L008 : avec l'API Claude 2026-10-21 (SDK v2), `temperature`, `top_p` et `top_k` renvoient une erreur 400
 * sur tous les modèles ; ces réglages restent disponibles chez d'autres éditeurs et en local (Ollama, LM Studio).
 */

export type Candidate = { token: string; p: number };

/** « Le chat est assis sur le… » — distribution d'exemple (température 1). */
export const CAT_PROMPT = "Le chat est assis sur le…";
export const CAT_CANDIDATES: Candidate[] = [
  { token: "tapis", p: 0.4 },
  { token: "canapé", p: 0.2 },
  { token: "lit", p: 0.12 },
  { token: "rebord", p: 0.09 },
  { token: "toit", p: 0.07 },
  { token: "clavier", p: 0.06 },
  { token: "journal", p: 0.04 },
  { token: "nuage", p: 0.02 },
];

export type SamplingParams = { temperature: number; topK: number; topP: number };
export const DEFAULT_SAMPLING: SamplingParams = { temperature: 1, topK: 8, topP: 1 };

export type ShapedCandidate = Candidate & { /** Probabilité après réglages (0 si coupé). */ q: number; kept: boolean; rank: number };

function normalize(values: number[]): number[] {
  const s = values.reduce((a, b) => a + b, 0);
  return s > 0 ? values.map((v) => v / s) : values.map(() => 0);
}

/** Applique la température seule (distribution complète). */
export function applyTemperature(probs: readonly number[], temperature: number): number[] {
  if (probs.length === 0) return [];
  if (temperature <= 0.01) {
    const max = Math.max(...probs);
    const i = probs.indexOf(max);
    return probs.map((_, k) => (k === i ? 1 : 0));
  }
  // Exposant en espace logarithmique pour la stabilité numérique.
  const logs = probs.map((p) => (p > 0 ? Math.log(p) / temperature : -Infinity));
  const m = Math.max(...logs);
  return normalize(logs.map((l) => (l === -Infinity ? 0 : Math.exp(l - m))));
}

/** Distribution finale après température, top-k et top-p (dans l'ordre d'origine des candidats). */
export function shapeDistribution(candidates: readonly Candidate[], params: SamplingParams): ShapedCandidate[] {
  const t = applyTemperature(
    candidates.map((c) => c.p),
    params.temperature,
  );
  const order = t.map((q, i) => ({ q, i })).sort((a, b) => b.q - a.q || a.i - b.i);
  const keep = new Set<number>();
  const k = Math.max(1, Math.min(candidates.length, Math.round(params.topK)));
  const p = Math.min(1, Math.max(0, params.topP));
  let cum = 0;
  for (let r = 0; r < order.length; r++) {
    if (r >= k) break;
    if (order[r].q <= 0 && keep.size > 0) break;
    keep.add(order[r].i);
    cum += order[r].q;
    if (cum >= p - 1e-9) break;
  }
  const kept = normalize(t.map((q, i) => (keep.has(i) ? q : 0)));
  const rankOf = new Map(order.map((o, r) => [o.i, r + 1]));
  return candidates.map((c, i) => ({ ...c, q: kept[i], kept: keep.has(i), rank: rankOf.get(i)! }));
}

/** Tire un candidat selon la distribution façonnée (`r` uniforme dans [0, 1)). Renvoie l'indice. */
export function sampleIndex(shaped: readonly { q: number }[], r: number): number {
  let acc = 0;
  let last = -1;
  for (let i = 0; i < shaped.length; i++) {
    if (shaped[i].q <= 0) continue;
    last = i;
    acc += shaped[i].q;
    if (r < acc) return i;
  }
  return last;
}

/** Entropie en bits (0 = aucune surprise possible, 3 = 8 candidats équiprobables). */
export function entropyBits(probs: readonly number[]): number {
  return -probs.reduce((s, p) => (p > 0 ? s + p * Math.log2(p) : s), 0);
}

/** Nombre de candidats encore possibles. */
export function keptCount(shaped: readonly ShapedCandidate[]): number {
  return shaped.filter((c) => c.kept && c.q > 0).length;
}
