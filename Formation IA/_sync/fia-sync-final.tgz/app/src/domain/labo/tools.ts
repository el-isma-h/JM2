/**
 * Catalogue des outils du Labo (/labo) et règle du badge « Laborantin » (utiliser les 5 outils).
 * `lessons` : leçons dont l'outil illustre une règle (liens « Pour aller plus loin »).
 */

export const LABO_TOOL_IDS = ["memoire-llm", "tokeniseur", "temperature", "couts-api", "embeddings"] as const;
export type LaboToolId = (typeof LABO_TOOL_IDS)[number];

export type LaboTool = {
  id: LaboToolId;
  title: string;
  /** Ce que l'on fait avec l'outil, en une phrase. */
  summary: string;
  /** Question à laquelle l'outil répond. */
  question: string;
  lessons: string[];
};

export const LABO_TOOLS: LaboTool[] = [
  {
    id: "memoire-llm",
    title: "Calculateur LLM local",
    summary: "Mémoire, disque et vitesse d'un modèle ouvert selon sa taille, sa précision et le contexte.",
    question: "Ce modèle tiendra-t-il sur ma machine, et à quelle vitesse écrira-t-il ?",
    lessons: ["L042", "L043", "L045"],
  },
  {
    id: "tokeniseur",
    title: "Tokeniseur visuel",
    summary: "Voir un texte découpé en tokens, comparer français et anglais, estimer le coût d'envoi.",
    question: "Combien « pèse » mon texte pour un modèle de langage ?",
    lessons: ["L005", "L067"],
  },
  {
    id: "temperature",
    title: "Température et top-p",
    summary: "Régler l'audace du tirage du mot suivant et lancer des tirages successifs.",
    question: "Pourquoi la même question donne-t-elle deux réponses différentes ?",
    lessons: ["L006", "L008", "L017"],
  },
  {
    id: "couts-api",
    title: "Comparateur de coûts API",
    summary: "Coût mensuel d'un usage réel chez Anthropic, OpenAI, xAI, Google et Mistral, avec cache et batch.",
    question: "Combien coûtera cette fonctionnalité IA par mois ?",
    lessons: ["L067", "L084", "L086", "L087", "L088"],
  },
  {
    id: "embeddings",
    title: "Embeddings en 2D",
    summary: "Placer des phrases sur une carte du sens et mesurer leur proximité par le cosinus.",
    question: "Comment une machine sait-elle que deux phrases parlent de la même chose ?",
    lessons: ["L047", "L048"],
  },
];

export const LABO_TOOL_BY_ID: Record<LaboToolId, LaboTool> = Object.fromEntries(LABO_TOOLS.map((t) => [t.id, t])) as Record<LaboToolId, LaboTool>;

export function isLaboToolId(v: unknown): v is LaboToolId {
  return typeof v === "string" && (LABO_TOOL_IDS as readonly string[]).includes(v);
}

/** Nombre d'outils distincts (et valides) utilisés. */
export function laboToolsUsedCount(used: readonly string[]): number {
  return new Set(used.filter(isLaboToolId)).size;
}

/** Badge « Laborantin » : les cinq outils du Labo utilisés au moins une fois. */
export function earnsLaborantin(used: readonly string[]): boolean {
  return laboToolsUsedCount(used) >= LABO_TOOL_IDS.length;
}
