/**
 * Labo — similarité d'embeddings en 2D (leçon L047, module M11).
 *
 * Reprend l'exemple de la feuille quadrillée : axe horizontal = « temps de travail / absence », axe vertical =
 * « argent / rémunération », coordonnées de 0 à 10. Similarité cosinus = produit scalaire ÷ (norme a × norme b) :
 * 1 = même direction, 0 = perpendiculaires, −1 = opposés. L047 : enfant malade (9, 1) ~ vacances (9, 2) ≈ 0,99 ;
 * enfant malade ~ prime (2, 9) ≈ 0,32.
 */

export type Vec2 = { x: number; y: number };
export type Phrase = { id: string; label: string; x: number; y: number; fromLesson?: boolean };

export const AXIS_X = "Temps de travail / absence";
export const AXIS_Y = "Argent / rémunération";
export const GRID_MAX = 10;

export const L047_PHRASES: Phrase[] = [
  { id: "prime", label: "Prime de fin d'année : versement en décembre", x: 2, y: 9, fromLesson: true },
  { id: "indemnite", label: "Indemnité de congés payés", x: 6, y: 7, fromLesson: true },
  { id: "enfant", label: "Absence pour enfant malade", x: 9, y: 1, fromLesson: true },
  { id: "vacances", label: "Poser des jours de vacances", x: 9, y: 2, fromLesson: true },
  { id: "transport", label: "Remboursement des frais de transport", x: 3, y: 8, fromLesson: true },
  { id: "teletravail", label: "Télétravail le vendredi", x: 7, y: 3 },
  { id: "augmentation", label: "Demande d'augmentation de salaire", x: 1, y: 10 },
  { id: "rtt", label: "Solde de RTT non pris", x: 7, y: 5 },
];

export function dot(a: Vec2, b: Vec2): number {
  return a.x * b.x + a.y * b.y;
}

export function norm(a: Vec2): number {
  return Math.hypot(a.x, a.y);
}

/** Similarité cosinus ; 0 si l'un des vecteurs est nul (direction indéfinie). */
export function cosine(a: Vec2, b: Vec2): number {
  const n = norm(a) * norm(b);
  return n === 0 ? 0 : dot(a, b) / n;
}

export function euclidean(a: Vec2, b: Vec2): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/** Angle (degrés) entre deux vecteurs. */
export function angleDeg(a: Vec2, b: Vec2): number {
  return (Math.acos(Math.max(-1, Math.min(1, cosine(a, b)))) * 180) / Math.PI;
}

/** Voisins d'une phrase, du plus proche au plus lointain (cosinus décroissant). */
export function rankNeighbours(target: Phrase, phrases: readonly Phrase[]): { phrase: Phrase; cos: number }[] {
  return phrases
    .filter((p) => p.id !== target.id)
    .map((p) => ({ phrase: p, cos: cosine(target, p) }))
    .sort((a, b) => b.cos - a.cos || a.phrase.id.localeCompare(b.phrase.id));
}

export function nearest(target: Phrase, phrases: readonly Phrase[]): Phrase | null {
  return rankNeighbours(target, phrases)[0]?.phrase ?? null;
}

/** Une manche du mini-jeu : la réponse est-elle (à égalité près) la plus proche ? */
export function isNearestGuess(target: Phrase, guessId: string, phrases: readonly Phrase[]): boolean {
  const ranked = rankNeighbours(target, phrases);
  if (!ranked.length) return false;
  const best = ranked[0].cos;
  return ranked.some((r) => r.phrase.id === guessId && Math.abs(r.cos - best) < 1e-9);
}

/** Borne et arrondit une coordonnée (grille 0-10, pas de 0,5). */
export function snap(v: number): number {
  return Math.max(0, Math.min(GRID_MAX, Math.round(v * 2) / 2));
}

/** Format « 0,99 ». */
export function formatCos(v: number): string {
  return v.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
