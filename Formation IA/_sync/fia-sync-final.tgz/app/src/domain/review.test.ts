import { describe, expect, it } from "vitest";
import { countDueReviews, isDue, LEITNER_INTERVAL_DAYS, scheduleReview, selectReviewQuestions, type ReviewCandidate, type ReviewItemState } from "./review";

const now = new Date("2026-11-05T10:00:00Z");
const day = 86_400_000;
const ago = (d: number) => new Date(now.getTime() - d * day);

describe("scheduleReview (Leitner)", () => {
  it("bonne réponse : boîte suivante, échéance espacée", () => {
    expect(scheduleReview(null, true, now)).toEqual({ box: 2, dueAt: new Date(now.getTime() + LEITNER_INTERVAL_DAYS[2] * day) });
    expect(scheduleReview({ box: 3 }, true, now).box).toBe(4);
    expect(scheduleReview({ box: 5 }, true, now)).toEqual({ box: 5, dueAt: new Date(now.getTime() + 16 * day) });
  });
  it("erreur : retour en boîte 1, à revoir dans 10 min", () => {
    const r = scheduleReview({ box: 4 }, false, now);
    expect(r.box).toBe(1);
    expect(r.dueAt.getTime() - now.getTime()).toBe(10 * 60_000);
  });
  it("isDue", () => {
    expect(isDue(undefined, now)).toBe(true);
    expect(isDue({ dueAt: ago(1) }, now)).toBe(true);
    expect(isDue({ dueAt: new Date(now.getTime() + 1000) }, now)).toBe(false);
  });
});

describe("selectReviewQuestions", () => {
  const c = (key: string, learnedDaysAgo: number, missedBefore = false): ReviewCandidate => ({ key, learnedAt: ago(learnedDaysAgo), missedBefore });
  const item = (box: number, dueDaysAgo: number, wrongCount = 0): ReviewItemState => ({ box, dueAt: ago(dueDaysAgo), wrongCount, correctCount: 0 });

  it("ratées d'abord, puis échues (petite boîte), puis nouvelles (plus anciennes d'abord)", () => {
    const candidates = [c("new-recent", 1), c("new-old", 30), c("missed-quiz", 2, true), c("due-box3", 5), c("due-box2", 5), c("wrong-review", 3), c("not-due", 10)];
    const items = new Map<string, ReviewItemState>([
      ["due-box3", item(3, 1)],
      ["due-box2", item(2, 0.5)],
      ["wrong-review", item(1, 0.01, 1)],
      ["not-due", item(4, -3)],
    ]);
    expect(selectReviewQuestions(candidates, items, now)).toEqual(["missed-quiz", "wrong-review", "due-box2", "due-box3", "new-old", "new-recent"]);
  });

  it("10 questions au plus, sans doublon", () => {
    const candidates = Array.from({ length: 30 }, (_, i) => c(`q${i}`, i));
    const r = selectReviewQuestions([...candidates, ...candidates], new Map(), now);
    expect(r).toHaveLength(10);
    expect(new Set(r).size).toBe(10);
    expect(r[0]).toBe("q29");
  });

  it("countDueReviews", () => {
    const items = new Map<string, ReviewItemState>([["b", item(2, -1)]]);
    expect(countDueReviews([c("a", 1), c("b", 1), c("a", 1)], items, now)).toBe(1);
  });
});
