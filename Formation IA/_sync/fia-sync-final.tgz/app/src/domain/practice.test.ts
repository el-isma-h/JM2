import { describe, expect, it } from "vitest";
import { gradePractice, lessonsToReview, practiceDurationSeconds } from "./practice";
import { practiceXp, XP } from "./xp";

const opts = ["a", "b", "c", "d"];
const qs = [
  { id: "Q1", domaine: "Agents", answer: 0, options: opts, lessonId: "L095" },
  { id: "Q2", domaine: "Agents", answer: 1, options: opts, lessonId: "L095" },
  { id: "Q3", domaine: "MCP", answer: 2, options: opts, lessonId: "L070" },
  { id: "Q4", domaine: "MCP", answer: 3, options: opts, lessonId: "L099" },
];

describe("examens blancs", () => {
  it("note la session et calcule le score par domaine", () => {
    const g = gradePractice(qs, { Q1: 0, Q2: 2, Q3: 2, Q4: null }, 70, ["MCP", "Agents", "Vide"]);
    expect(g).toMatchObject({ score: 2, total: 4, percent: 50, passed: false, answered: 3 });
    expect(g.byDomain).toEqual([
      { domaine: "MCP", correct: 1, total: 2, percent: 50 },
      { domaine: "Agents", correct: 1, total: 2, percent: 50 },
    ]);
    expect(g.items.map((i) => i.correct)).toEqual([true, false, true, false]);
  });

  it("réponse hors bornes = sans réponse ; seuil atteint = réussi", () => {
    const g = gradePractice(qs, { Q1: 0, Q2: 1, Q3: 2, Q4: 9 }, 72);
    expect(g.answered).toBe(3);
    expect(g.items[3]).toEqual({ questionId: "Q4", choice: null, correct: false });
    expect(gradePractice(qs, { Q1: 0, Q2: 1, Q3: 2, Q4: 3 }, 72)).toMatchObject({ percent: 100, passed: true });
    expect(gradePractice(qs, { Q1: 0, Q2: 1, Q3: 2 }, 75)).toMatchObject({ percent: 75, passed: true });
  });

  it("leçons à réviser, durée bornée", () => {
    const g = gradePractice(qs, { Q1: 1, Q2: 1, Q3: 0 }, 70);
    expect(lessonsToReview(qs, g.items)).toEqual(["L095", "L070", "L099"]);
    expect(lessonsToReview(qs, gradePractice(qs, {}, 70).items)).toEqual(["L095", "L070", "L099"]); // L095 : deux erreurs
    const t0 = new Date("2026-11-05T10:00:00Z");
    expect(practiceDurationSeconds(t0, new Date("2026-11-05T10:12:30Z"))).toBe(750);
    expect(practiceDurationSeconds(t0, new Date("2026-11-05T09:00:00Z"))).toBe(0);
  });

  it("+20 XP par session terminée, une fois par jour et par examen", () => {
    expect(practiceXp("google-ai-essentials", "2026-11-05")).toEqual([{ reason: "practice", refId: "practice:google-ai-essentials:2026-11-05", amount: XP.practiceSession }]);
    expect(XP.practiceSession).toBe(20);
  });
});
