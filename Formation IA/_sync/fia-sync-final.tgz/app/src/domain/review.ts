/**
 * Révisions espacées (/revisions) — répétition espacée simple par boîtes de Leitner (1 à 5).
 *
 * - Une bonne réponse fait monter la question d'une boîte (max 5) et l'éloigne : 1 j, 2 j, 4 j, 8 j puis 16 j.
 * - Une erreur la renvoie en boîte 1, à revoir dans 10 minutes (prochaine session).
 * - Session : 10 questions parmi celles des leçons terminées, en priorité les ratées, puis les échues les moins
 *   maîtrisées (petite boîte, échéance la plus ancienne), puis les jamais révisées des leçons les plus anciennes.
 *
 * Fonctions pures : l'heure est passée en paramètre.
 */

export const REVIEW_SESSION_SIZE = 10;
export const LEITNER_MAX_BOX = 5;
/** Délai (jours) avant la prochaine révision quand la question ARRIVE dans la boîte n (index = boîte). */
export const LEITNER_INTERVAL_DAYS = [0, 1, 2, 4, 8, 16] as const;
/** Après une erreur : à revoir dans 10 minutes. */
export const REVIEW_RETRY_MINUTES = 10;

export type ReviewItemState = { box: number; dueAt: Date; wrongCount: number; correctCount: number };

export type ReviewCandidate = {
  key: string;
  /** Date de fin de la leçon d'origine (ancienneté). */
  learnedAt: Date;
  /** Ratée au moins une fois hors révisions (quiz de module, quiz éclair). */
  missedBefore: boolean;
};

const DAY = 86_400_000;

export function clampBox(box: number): number {
  return Math.min(LEITNER_MAX_BOX, Math.max(1, Math.round(box) || 1));
}

/** Nouvel état d'une question après une réponse. */
export function scheduleReview(prev: Pick<ReviewItemState, "box"> | null, correct: boolean, now: Date): { box: number; dueAt: Date } {
  if (!correct) return { box: 1, dueAt: new Date(now.getTime() + REVIEW_RETRY_MINUTES * 60_000) };
  const box = prev ? clampBox(prev.box + 1) : 2;
  return { box, dueAt: new Date(now.getTime() + LEITNER_INTERVAL_DAYS[box] * DAY) };
}

/** La question est-elle à réviser maintenant ? (jamais révisée = oui) */
export function isDue(item: Pick<ReviewItemState, "dueAt"> | undefined, now: Date): boolean {
  return !item || item.dueAt.getTime() <= now.getTime();
}

type Ranked = { key: string; group: number; box: number; time: number };

function rank(c: ReviewCandidate, item: ReviewItemState | undefined): Ranked {
  if (item) {
    const missed = item.box === 1 && item.wrongCount > 0;
    return { key: c.key, group: missed ? 0 : 1, box: item.box, time: item.dueAt.getTime() };
  }
  return { key: c.key, group: c.missedBefore ? 0 : 2, box: 1, time: c.learnedAt.getTime() };
}

/**
 * Questions à réviser, dans l'ordre de priorité. `limit` = taille de session (10 par défaut).
 * Groupes : 0 ratées, 1 échues déjà révisées (petite boîte d'abord), 2 jamais révisées (leçons anciennes d'abord).
 */
export function selectReviewQuestions(
  candidates: readonly ReviewCandidate[],
  items: ReadonlyMap<string, ReviewItemState>,
  now: Date,
  limit = REVIEW_SESSION_SIZE,
): string[] {
  const seen = new Set<string>();
  return candidates
    .filter((c) => {
      if (seen.has(c.key)) return false;
      seen.add(c.key);
      return isDue(items.get(c.key), now);
    })
    .map((c) => rank(c, items.get(c.key)))
    .sort((a, b) => a.group - b.group || a.box - b.box || a.time - b.time || a.key.localeCompare(b.key))
    .slice(0, Math.max(0, limit))
    .map((r) => r.key);
}

/** Nombre de questions dues maintenant (carte « Réviser » du tableau de bord). */
export function countDueReviews(candidates: readonly ReviewCandidate[], items: ReadonlyMap<string, ReviewItemState>, now: Date): number {
  const keys = new Set(candidates.map((c) => c.key));
  let n = 0;
  for (const k of keys) if (isDue(items.get(k), now)) n++;
  return n;
}
