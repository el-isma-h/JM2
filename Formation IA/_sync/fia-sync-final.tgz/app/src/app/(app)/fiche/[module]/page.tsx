import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, BookOpenText, Notepad, Path, Question } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { loadAccess } from "@/server/learner";
import { findProgrammeModule, getLevel, getModuleMemo, getModuleMemos, getProgramme, isSpecialisationLevel } from "@/content";
import { moduleIdFromParam, routes } from "@/lib/paths";
import { cn, formatMinutes } from "@/lib/utils";
import { Markdown } from "@/components/markdown/markdown";
import { SpecialisationBadge, StatusBadge } from "@/components/ui/badge";
import { FadeIn } from "@/components/ui/motion";
import { PrintButton } from "@/components/fiche/print-button";

export async function generateMetadata({ params }: { params: Promise<{ module: string }> }): Promise<Metadata> {
  const { module } = await params;
  const id = moduleIdFromParam(module);
  const memo = id ? getModuleMemo(id) : null;
  return { title: memo ? `${memo.title}` : "Fiche mémo" };
}

/**
 * Fiche mémo d'un module (niveaux/…/Mxx-…/fiche.md) : une page de révision, imprimable sur une feuille A4
 * (globals.css § impression : fond blanc, sans navigation, deux colonnes). Ouverte à tout apprenant connecté,
 * comme le lexique : c'est un support de révision, pas une étape du parcours.
 */
export default async function FicheModulePage({ params }: { params: Promise<{ module: string }> }) {
  const { module } = await params;
  const user = await requireUser();
  const moduleId = moduleIdFromParam(module);
  const memo = moduleId ? getModuleMemo(moduleId) : null;
  const found = moduleId ? findProgrammeModule(moduleId) : null;
  if (!memo || !found || !moduleId) notFound();

  const { access } = await loadAccess(user.id);
  const level = getLevel(found.level.id);
  const mod = found.module;
  const ma = access.modules[moduleId];
  const all = getModuleMemos();
  const i = all.findIndex((m) => m.moduleId === moduleId);
  const prev = all[i - 1] ?? null;
  const next = all[i + 1] ?? null;
  const readMinutes = Math.max(3, Math.round(memo.wordCount / 160));
  const spec = isSpecialisationLevel(found.level);
  const prog = getProgramme();

  return (
    <div>
      <FadeIn>
        <header className="memo-print-head border-b border-line pb-7">
          <nav className="flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3 print:hidden" aria-label="Fil d'Ariane">
            <Link href={routes.memos} className="hover:text-ink">
              Fiches mémo
            </Link>
            <span aria-hidden>/</span>
            <Link href={routes.level(found.level.id)} className="hover:text-ink">
              Niveau {level?.index ?? found.level.id.slice(1)}
            </Link>
            <span aria-hidden>/</span>
            <span>Module {moduleId.slice(1)}</span>
          </nav>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-x-6 gap-y-2 print:mt-0">
            <p className="flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-accent">
              <Notepad size={14} aria-hidden className="print:hidden" />
              Fiche mémo · Module {moduleId.slice(1)} · Niveau {level?.index ?? found.level.id.slice(1)}
              {spec ? <SpecialisationBadge className="ml-1" /> : null}
            </p>
            <p className="hidden font-mono text-[9px] uppercase tracking-[0.2em] text-ink-3 print:block">
              Next Formation IA · {prog.code}
            </p>
          </div>
          <h1 className="mt-4 max-w-[28ch] text-[25px] leading-[1.06] text-ink sm:text-[36px]">{memo.title}</h1>
          <div className="mt-5 flex flex-wrap items-center justify-between gap-4 print:hidden">
            <p className="num text-[12px] text-ink-3">
              {mod.title} · {mod.lessons.length} leçons · {formatMinutes(readMinutes)} de lecture
            </p>
            <PrintButton />
          </div>
        </header>
      </FadeIn>

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1fr)_240px] xl:gap-14 print:mt-0 print:block">
        <article className="min-w-0" aria-label={memo.title}>
          <Markdown source={memo.body} className="memo-sheet" />
        </article>

        <aside className="print:hidden">
          <div className="space-y-6 lg:sticky lg:top-10">
            <section className="border border-line bg-bg-elev p-5" aria-labelledby="memo-module">
              <div className="flex flex-wrap items-center gap-2">
                <h2 id="memo-module" className="font-mono text-[10px] font-medium tracking-[0.24em] text-ink-3">
                  Module {moduleId.slice(1)}
                </h2>
                {ma ? <StatusBadge status={ma.state} /> : null}
              </div>
              <ul className="mt-4 space-y-1">
                {mod.lessons.map((l) => {
                  const la = access.lessons[l.id];
                  const open = la?.accessible || la?.state === "completed";
                  return (
                    <li key={l.id}>
                      {open ? (
                        <Link href={routes.lesson(l.id)} className="group flex gap-2.5 py-1 text-[12.5px] leading-snug text-ink-2 transition-colors hover:text-ink">
                          <span className="num shrink-0 text-[10.5px] text-ink-3 group-hover:text-accent">{l.id}</span>
                          <span>{l.title}</span>
                        </Link>
                      ) : (
                        <span className="flex gap-2.5 py-1 text-[12.5px] leading-snug text-ink-3">
                          <span className="num shrink-0 text-[10.5px]">{l.id}</span>
                          <span>{l.title}</span>
                        </span>
                      )}
                    </li>
                  );
                })}
              </ul>
              <div className="mt-4 flex flex-col gap-2 border-t border-line pt-4">
                <Link href={routes.level(found.level.id)} className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors hover:text-accent">
                  <Path size={14} aria-hidden /> Chemin du niveau
                </Link>
                {ma?.quizUnlocked || ma?.quizPassed ? (
                  <Link href={routes.quiz(moduleId)} className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors hover:text-accent">
                    <Question size={14} aria-hidden /> Quiz du module
                  </Link>
                ) : null}
              </div>
            </section>

            <nav className="grid gap-px border border-line bg-line" aria-label="Fiches précédente et suivante">
              {prev ? (
                <Link href={routes.memo(prev.moduleId)} className="flex flex-col gap-1 bg-bg p-4 transition-colors hover:bg-bg-sunken">
                  <span className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">
                    <ArrowLeft size={12} aria-hidden /> Fiche {prev.moduleId}
                  </span>
                  <span className="text-[12.5px] leading-snug text-ink">{prev.moduleTitle}</span>
                </Link>
              ) : null}
              {next ? (
                <Link href={routes.memo(next.moduleId)} className="flex flex-col items-end gap-1 bg-bg p-4 text-right transition-colors hover:bg-bg-sunken">
                  <span className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">
                    Fiche {next.moduleId} <ArrowRight size={12} aria-hidden />
                  </span>
                  <span className="text-[12.5px] leading-snug text-ink">{next.moduleTitle}</span>
                </Link>
              ) : null}
              <Link href={routes.memos} className={cn("flex items-center gap-2 bg-bg p-4 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors hover:bg-bg-sunken hover:text-ink")}>
                <BookOpenText size={14} aria-hidden /> Toutes les fiches
              </Link>
            </nav>
          </div>
        </aside>
      </div>
    </div>
  );
}
