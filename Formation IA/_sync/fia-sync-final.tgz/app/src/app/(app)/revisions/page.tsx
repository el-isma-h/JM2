import type { Metadata } from "next";
import Link from "next/link";
import { ArrowsClockwise, CheckCircle } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { buildReviewSession } from "@/server/review";
import { routes } from "@/lib/paths";
import { plural } from "@/lib/utils";
import { PageHeader } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import { ReviewRunner } from "@/components/revisions/review-runner";

export const metadata: Metadata = { title: "Révisions" };
export const dynamic = "force-dynamic";

/**
 * Révisions espacées : 10 questions des quiz de module et des quiz éclair des leçons terminées, ratées et anciennes
 * d'abord (boîtes de Leitner, domain/review.ts). Correction côté serveur, +2 XP par bonne réponse.
 */
export default async function RevisionsPage() {
  const user = await requireUser();
  const now = new Date();
  const { questions, overview } = await buildReviewSession(user.id, now);

  return (
    <div>
      <PageHeader
        title="Révisions"
        description="Dix questions des leçons déjà terminées, celles que vous avez ratées d'abord. Une bonne réponse espace la prochaine révision ; une erreur la ramène vite."
        actions={
          overview.pool ? (
            <dl className="flex gap-6 text-right">
              <div>
                <dt className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-ink-3">Dues</dt>
                <dd className="num mt-1 text-[20px] leading-none text-ink">{overview.due}</dd>
              </div>
              <div>
                <dt className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-ink-3">Maîtrisées</dt>
                <dd className="num mt-1 text-[20px] leading-none text-ink">
                  {overview.mastered}
                  <span className="text-[12px] text-ink-3">/{overview.pool}</span>
                </dd>
              </div>
            </dl>
          ) : null
        }
      />

      {overview.pool === 0 ? (
        <Empty
          icon={<ArrowsClockwise size={22} aria-hidden />}
          title="Rien à réviser pour l'instant"
          text="Les révisions reprennent les questions des leçons que vous avez terminées. Terminez votre première leçon pour lancer une session."
          cta={{ href: routes.parcours, label: "Aller au parcours" }}
        />
      ) : questions.length === 0 ? (
        <Empty
          icon={<CheckCircle size={22} aria-hidden />}
          title="Tout est à jour"
          text={`Vos ${plural(overview.pool, "question")} sont révisées. Les prochaines reviendront à leur échéance : continuez le parcours en attendant.`}
          cta={{ href: routes.home, label: "Tableau de bord" }}
        />
      ) : (
        <ReviewRunner key={`${now.getTime()}`} questions={questions} />
      )}
    </div>
  );
}

function Empty({ icon, title, text, cta }: { icon: React.ReactNode; title: string; text: string; cta: { href: string; label: string } }) {
  return (
    <div className="mx-auto max-w-[560px] border border-dashed border-line-strong px-6 py-14 text-center">
      <span className="mx-auto flex h-12 w-12 items-center justify-center border border-line-strong bg-bg-elev text-accent">{icon}</span>
      <p className="mt-6 font-display text-[17px] font-light uppercase tracking-[0.06em] text-ink">{title}</p>
      <p className="mx-auto mt-3 max-w-[44ch] text-[13.5px] text-ink-2">{text}</p>
      <Button asChild className="mt-7">
        <Link href={cta.href}>{cta.label}</Link>
      </Button>
    </div>
  );
}
