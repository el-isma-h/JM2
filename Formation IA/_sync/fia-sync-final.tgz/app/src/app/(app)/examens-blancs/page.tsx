import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Clock, Exam, ListNumbers, Target } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { practiceSummaries } from "@/server/practice";
import { getFlatLessons, getPracticeExams, getPracticeGuide } from "@/content";
import { XP } from "@/domain";
import { routes } from "@/lib/paths";
import { formatDate, plural } from "@/lib/utils";
import { EmptyState, PageHeader } from "@/components/ui/surface";
import { Badge } from "@/components/ui/badge";
import { FadeIn, Stagger, StaggerItem } from "@/components/ui/motion";
import { Markdown } from "@/components/markdown/markdown";
import { PracticeWarning } from "@/components/practice/practice-warning";

export const metadata: Metadata = { title: "Examens blancs" };
export const dynamic = "force-dynamic";

const pct = (v: number) => `${v.toLocaleString("fr-FR", { maximumFractionDigits: 1 })} %`;

/**
 * Examens blancs d'entraînement aux certifications tierces (examens-blancs/*.json + README.md).
 * Mode entraînement uniquement : tentatives illimitées, aucun certificat, aucun XP d'examen.
 */
export default async function PracticeListPage() {
  const user = await requireUser();
  const exams = getPracticeExams();
  const guide = getPracticeGuide();
  const summaries = await practiceSummaries(user.id);
  const lessonIds = getFlatLessons().map((l) => l.id);

  return (
    <div>
      <PageHeader
        title="Examens blancs"
        description={`S'entraîner aux certifications tierces que la formation prépare : ${plural(exams.length, "examen blanc", "examens blancs")}, questions originales, correction immédiate avec score par domaine et leçons à réviser. Tentatives illimitées ; +${XP.practiceSession} XP par session terminée, une fois par jour et par examen.`}
      />

      <FadeIn>
        <PracticeWarning className="mb-10">
          {guide.warning ? (
            <Markdown source={guide.warning} lessonLinks={lessonIds} className="text-[13.5px] [&>ol]:mt-0 [&_li]:my-1.5" />
          ) : (
            <p className="text-[13.5px]">
              Ces examens blancs sont des outils d&apos;entraînement <strong>non officiels</strong> rédigés par Next Formation, sans lien avec les éditeurs des certifications. Ils ne reproduisent aucune question réelle d&apos;examen et un bon score ne garantit pas la réussite à l&apos;examen officiel.
            </p>
          )}
        </PracticeWarning>
      </FadeIn>

      {exams.length === 0 ? (
        <EmptyState icon={<Exam size={28} aria-hidden />} title="Examens blancs en préparation" description="Ils seront bientôt disponibles." />
      ) : (
        <Stagger className="grid gap-px border border-line bg-line md:grid-cols-2">
          {exams.map((e, i) => {
            const s = summaries.get(e.slug);
            return (
              <StaggerItem key={e.slug} className={i === exams.length - 1 && i % 2 === 0 ? "bg-bg-elev md:col-span-2" : "bg-bg-elev"}>
                <Link href={routes.practiceExam(e.slug)} className="group relative flex h-full min-h-[236px] flex-col overflow-hidden p-5 transition-colors duration-500 hover:bg-bg-sunken sm:p-6">
                  <span aria-hidden className="filigrane pointer-events-none absolute -bottom-6 -right-1 text-[104px] text-ink">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="relative flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-accent">
                      <Exam size={13} aria-hidden /> Examen blanc
                    </span>
                    <Badge tone="warn">Non officiel</Badge>
                  </span>
                  <span className="relative mt-3 max-w-[30ch] font-display text-[19px] font-light uppercase leading-[1.12] tracking-[0.05em] text-ink">{e.certification}</span>
                  <span className="relative mt-4 flex flex-wrap gap-x-5 gap-y-1.5 text-[12.5px] text-ink-2">
                    <span className="inline-flex items-center gap-1.5">
                      <ListNumbers size={13} className="text-ink-3" aria-hidden />
                      <span className="num">{e.questionCount}</span> questions
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Clock size={13} className="text-ink-3" aria-hidden />
                      <span className="num">{e.timeLimitMinutes}</span> min indicatives
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Target size={13} className="text-ink-3" aria-hidden />
                      seuil <span className="num">{e.passScore} %</span>
                    </span>
                  </span>
                  <span className="relative mt-auto flex flex-wrap items-end justify-between gap-3 pt-6">
                    <span className="text-[12px] text-ink-3">
                      {s ? (
                        <>
                          Meilleur score <span className="num text-[14px] text-ink">{pct(s.best ?? 0)}</span> · {plural(s.attempts, "session")} · dernière le {formatDate(s.last?.at)}
                        </>
                      ) : (
                        `${plural(e.domaines.length, "domaine")} · jamais passé`
                      )}
                    </span>
                    <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors group-hover:text-accent">
                      Conditions et entraînement <ArrowRight size={12} className="transition-transform duration-500 group-hover:translate-x-1" aria-hidden />
                    </span>
                  </span>
                </Link>
              </StaggerItem>
            );
          })}
        </Stagger>
      )}

      {guide.howTo ? (
        <FadeIn delay={0.1}>
          <section className="mt-10 grid gap-5 border-t border-line pt-8 md:grid-cols-[240px_minmax(0,1fr)] md:gap-10" aria-labelledby="mode-emploi">
            <h2 id="mode-emploi" className="text-[15px] text-ink">
              Mode d&apos;emploi conseillé
            </h2>
            <Markdown source={guide.howTo.replace("indiquées ci-dessous", "indiquées sur la page de chaque examen")} className="max-w-[72ch] text-[13.5px] [&>ol]:mt-0" />
          </section>
        </FadeIn>
      ) : null}
    </div>
  );
}
