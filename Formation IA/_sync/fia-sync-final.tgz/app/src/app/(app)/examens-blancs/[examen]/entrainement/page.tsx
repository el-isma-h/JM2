import type { Metadata } from "next";
import { randomInt } from "node:crypto";
import { notFound } from "next/navigation";
import { requireUser } from "@/server/auth";
import { getPublicPracticeExam } from "@/content";
import { routes, withBase } from "@/lib/paths";
import { PracticeRunner } from "@/components/practice/practice-runner";

export const metadata: Metadata = { title: "Examen blanc — entraînement" };
export const dynamic = "force-dynamic";

/** Mélange de Fisher-Yates (ordre des questions propre à chaque session). */
function shuffled<T>(list: readonly T[]): T[] {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Session d'entraînement : questions publiques uniquement (les bonnes réponses restent sur le serveur). */
export default async function PracticeTrainPage({ params }: { params: Promise<{ examen: string }> }) {
  const { examen } = await params;
  await requireUser();
  const exam = getPublicPracticeExam(examen);
  if (!exam) notFound();
  return (
    <PracticeRunner
      examId={exam.slug}
      title={exam.title}
      certification={exam.certification}
      timeLimitMinutes={exam.timeLimitMinutes}
      questions={shuffled(exam.questions)}
      startedAt={new Date().toISOString()}
      exitHref={withBase(routes.practiceExam(exam.slug))}
    />
  );
}
