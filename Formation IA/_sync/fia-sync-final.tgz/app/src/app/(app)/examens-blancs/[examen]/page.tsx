import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Exam, Play } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { practiceHistory } from "@/server/practice";
import { getFlatLessons, getPracticeExam, getPracticeGuide, practiceGuideSection } from "@/content";
import { XP } from "@/domain";
import { routes } from "@/lib/paths";
import { formatDateTime, formatSeconds, plural } from "@/lib/utils";
import { Panel } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FadeIn } from "@/components/ui/motion";
import { Markdown } from "@/components/markdown/markdown";
import { ScoreRule } from "@/components/exam/score-rule";
import { PracticeWarning } from "@/components/practice/practice-warning";

export async function generateMetadata({ params }: { params: Promise<{ examen: string }> }): Promise<Metadata> {
  const { examen } = await params;
  const e = getPracticeExam(examen);
  return { title: e ? `Examen blanc — ${e.certification}` : "Examen blanc" };
}

export const dynamic = "force-dynamic";

const pct = (v: number) => `${v.toLocaleString("fr-FR", { maximumFractionDigits: 1 })} %`;

export default async function PracticeExamPage({ params }: { params: Promise<{ examen: string }> }) {
  const { examen } = await params;
  const user = await requireUser();
  const exam = getPracticeExam(examen);
  if (!exam) notFound();
  const history = await practiceHistory(user.id, exam.slug);
  const section = practiceGuideSection(getPracticeGuide(), exam.certification);
  const lessonIds = getFlatLessons().map((l) => l.id);
  const best = history.length ? Math.max(...history.map((h) => h.percent)) : null;

  return (
    <div>
      <FadeIn>
        <header className="border-b border-line pb-7">
          <nav className="flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3" aria-label="Fil d'Ariane">
            <Link href={routes.practice} className="hover:text-ink">
              Examens blancs
            </Link>
            <span aria-hidden>/</span>
            <span>{exam.certification}</span>
          </nav>
          <p className="mt-6 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-accent">
            <Exam size={14} aria-hidden /> Examen blanc · mode entraînement
          </p>
          <h1 className="mt-4 max-w-[26ch] text-[26px] leading-[1.08] text-ink sm:text-[36px]">{exam.certification}</h1>
          <div className="mt-6 flex flex-wrap items-end justify-between gap-5">
            <dl className="grid grid-cols-2 gap-px border border-line bg-line sm:grid-cols-4">
              {[
                { k: "Questions", v: String(exam.questions.length) },
                { k: "Durée indicative", v: `${exam.timeLimitMinutes} min` },
                { k: "Seuil d'entraînement", v: `${exam.passScore} %` },
                { k: "Meilleur score", v: best === null ? "—" : pct(best) },
              ].map((x) => (
                <div key={x.k} className="min-w-[132px] bg-bg px-4 py-3">
                  <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">{x.k}</dt>
                  <dd className="num mt-1 text-[17px] text-ink">{x.v}</dd>
                </div>
              ))}
            </dl>
            <Button asChild variant="accent" size="lg">
              <Link href={routes.practiceTrain(exam.slug)}>
                <Play size={14} weight="fill" aria-hidden /> {history.length ? "Nouvelle session" : "Commencer l'entraînement"}
              </Link>
            </Button>
          </div>
          <p className="mt-4 max-w-[72ch] text-[12.5px] text-ink-3">
            Tentatives illimitées · chronomètre indicatif (rien n&apos;est envoyé automatiquement) · correction et explications à la fin · aucun certificat · +{XP.practiceSession} XP par session terminée, une fois par jour.
          </p>
        </header>
      </FadeIn>

      <FadeIn delay={0.05}>
        <PracticeWarning className="mt-8">
          <p className="max-w-[90ch] text-[13.5px] leading-relaxed">{exam.avertissement || "Examen blanc d'entraînement non officiel, sans lien avec l'éditeur de la certification."}</p>
          <p className="mt-2 text-[12.5px] text-ink-2">
            Revérifiez prix et conditions sur la page officielle avant toute inscription.{" "}
            <Link href={routes.practice} className="text-accent underline underline-offset-4">
              Avertissement complet
            </Link>
          </p>
        </PracticeWarning>
      </FadeIn>

      <div className="mt-10 grid gap-10 lg:grid-cols-[minmax(0,1fr)_340px] xl:gap-14">
        <div className="min-w-0">
          {section ? (
            <section aria-labelledby="conditions">
              <h2 id="conditions" className="text-[20px] text-ink">
                Conditions d&apos;accès, prix et liens officiels
              </h2>
              <p className="mt-1 text-[12.5px] text-ink-3">{section.title.replace(/^\d+\.\s*/, "")}</p>
              <Markdown source={section.body} lessonLinks={lessonIds} className="mt-2 [&>h3:first-child]:mt-4" />
            </section>
          ) : null}
          {exam.notes ? (
            <section className="mt-10 border-t border-line pt-6" aria-labelledby="notes">
              <h2 id="notes" className="font-mono text-[10px] font-medium tracking-[0.22em] text-ink-3">
                Notes sur cet examen blanc
              </h2>
              <p className="mt-3 max-w-[72ch] text-[13.5px] leading-relaxed text-ink-2">{exam.notes}</p>
            </section>
          ) : null}
        </div>

        <aside className="min-w-0 space-y-6">
          <Panel>
            <div className="border-b border-line px-5 py-4">
              <h2 className="font-mono text-[10px] font-medium tracking-[0.24em] text-ink-3">Domaines évalués</h2>
            </div>
            <ul className="divide-y divide-line">
              {exam.domaines.map((d) => (
                <li key={d.nom} className="flex items-baseline justify-between gap-4 px-5 py-3">
                  <span className="min-w-0 text-[13px] leading-snug text-ink">{d.nom}</span>
                  <span className="num shrink-0 text-right text-[12px] text-ink-3">
                    {d.poids ? `${d.poids} · ` : ""}
                    {plural(d.questions, "q.", "q.")}
                  </span>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel>
            <div className="flex items-baseline justify-between gap-3 border-b border-line px-5 py-4">
              <h2 className="font-mono text-[10px] font-medium tracking-[0.24em] text-ink-3">Historique des scores</h2>
              <span className="num text-[11px] text-ink-3">{plural(history.length, "session")}</span>
            </div>
            {history.length === 0 ? (
              <p className="px-5 py-5 text-[13px] text-ink-2">Vos sessions terminées apparaîtront ici, avec leur score et leur correction.</p>
            ) : (
              <ol className="divide-y divide-line">
                {history.map((h, i) => (
                  <li key={h.id}>
                    <Link href={routes.practiceResult(exam.slug, h.id)} className="group grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-4 gap-y-2 px-5 py-3 transition-colors hover:bg-bg-sunken">
                      <span className="min-w-0">
                        <span className="block text-[12px] text-ink-3">
                          Session {history.length - i} · {formatDateTime(h.submittedAt)}
                        </span>
                        <ScoreRule value={h.percent} threshold={h.passScore} className="mt-2" label={`Score ${h.percent} %, seuil ${h.passScore} %`} />
                      </span>
                      <span className="flex flex-col items-end gap-1">
                        <span className="num text-[15px] text-ink">{pct(h.percent)}</span>
                        <span className="num text-[11px] text-ink-3">{formatSeconds(h.durationSeconds)}</span>
                      </span>
                      <span className="col-span-2 flex items-center justify-between">
                        <Badge tone={h.passed ? "ok" : "neutral"}>{h.passed ? "Seuil atteint" : "Sous le seuil"}</Badge>
                        <span className="inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3 group-hover:text-accent">
                          Correction <ArrowRight size={11} aria-hidden />
                        </span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ol>
            )}
          </Panel>
        </aside>
      </div>
    </div>
  );
}
