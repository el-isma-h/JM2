import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, ArrowsClockwise } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { getPracticeResult } from "@/server/practice";
import { getFlatLessons } from "@/content";
import { lessonsToReview } from "@/domain";
import { routes } from "@/lib/paths";
import { formatDateTime, formatSeconds } from "@/lib/utils";
import { PageHeader, Panel } from "@/components/ui/surface";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FadeIn } from "@/components/ui/motion";
import { ResultHero } from "@/components/exam/result-hero";
import { ScoreRule } from "@/components/exam/score-rule";
import { CorrectionList } from "@/components/exam/correction-list";
import { PracticeWarning } from "@/components/practice/practice-warning";

export const metadata: Metadata = { title: "Correction de l'examen blanc" };
export const dynamic = "force-dynamic";

const pct = (v: number) => `${v.toLocaleString("fr-FR", { maximumFractionDigits: 1 })} %`;

export default async function PracticeResultPage({ params }: { params: Promise<{ examen: string; tentative: string }> }) {
  const { examen, tentative } = await params;
  const user = await requireUser();
  const r = await getPracticeResult(user.id, tentative);
  if (!r) redirect(routes.practiceExam(examen));
  if (r.exam.slug !== examen) redirect(routes.practiceResult(r.exam.slug, r.attempt.id));
  const { attempt: a, exam } = r;

  const lessons = getFlatLessons();
  const cited = new Set(r.items.map((i) => i.lessonId).filter(Boolean));
  const lessonTitles = Object.fromEntries(lessons.filter((l) => cited.has(l.id)).map((l) => [l.id, l.title]));
  const lessonHref = Object.fromEntries(lessons.filter((l) => cited.has(l.id)).map((l) => [l.id, routes.lesson(l.id)]));
  const toReview = lessonsToReview(
    exam.questions.map((q) => ({ id: q.id, lessonId: q.lessonId })),
    a.answers,
  ).filter((id) => lessonTitles[id]);
  const needed = Math.ceil((a.passScore / 100) * a.total);
  const items = r.items.map((it) => ({ ...it, competence: it.domaine }));
  const overtime = a.durationSeconds > a.timeLimitMinutes * 60;

  return (
    <div>
      <PageHeader
        breadcrumb={[{ label: "Examens blancs", href: routes.practice }, { label: exam.certification, href: routes.practiceExam(exam.slug) }, { label: `Session ${r.number}` }]}
        title={a.passed ? "Seuil d'entraînement atteint" : "Correction de la session"}
        description={
          a.passed
            ? "Bon signe, sans garantie pour l'examen officiel : relisez les explications, y compris pour les questions réussies."
            : `Il manquait ${Math.max(1, needed - a.score)} bonne${needed - a.score > 1 ? "s" : ""} réponse${needed - a.score > 1 ? "s" : ""} pour le seuil d'entraînement. Révisez les domaines sous ${a.passScore} %, puis recommencez.`
        }
        actions={<Badge tone={a.passed ? "ok" : "neutral"}>{a.passed ? "Seuil atteint" : "Sous le seuil"}</Badge>}
      />

      <section className="grid min-w-0 gap-8 border-b border-line pb-10 lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-14">
        <ResultHero percent={a.percent} passScore={a.passScore} passed={a.passed} celebrateNow={false} cleanHref={routes.practiceResult(exam.slug, a.id)} />
        <dl className="grid grid-cols-2 content-start gap-px self-start border border-line bg-line">
          {[
            { k: "Bonnes réponses", v: `${a.score} / ${a.total}` },
            { k: "Seuil", v: `${needed} / ${a.total}` },
            { k: "Durée", v: formatSeconds(a.durationSeconds) },
            { k: "Session", v: `n° ${r.number}` },
          ].map((x) => (
            <div key={x.k} className="bg-bg px-4 py-3.5">
              <dt className="text-[12px] text-ink-3">{x.k}</dt>
              <dd className="num mt-1 text-[18px] text-ink">{x.v}</dd>
            </div>
          ))}
          <div className="col-span-2 bg-bg px-4 py-3 text-[12px] text-ink-3">
            Terminée le {formatDateTime(a.submittedAt)} · {a.timeLimitMinutes} min indicatives{overtime ? " (dépassées)" : ""}
          </div>
        </dl>
      </section>

      <FadeIn delay={0.15}>
        <section className="grid gap-8 border-b border-line py-8 md:grid-cols-2" aria-label="Après la session">
          <div className="min-w-0">
            <h2 className="text-[15px] text-ink">Et maintenant ?</h2>
            <p className="mt-3 max-w-[52ch] text-[13.5px] text-ink-2">Tentatives illimitées : chaque nouvelle session mélange l&apos;ordre des questions. Pour chaque domaine sous {a.passScore} %, révisez les leçons indiquées, puis la documentation officielle citée en source.</p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button asChild variant="accent" size="sm">
                <Link href={routes.practiceTrain(exam.slug)}>
                  <ArrowsClockwise size={13} aria-hidden /> Nouvelle session
                </Link>
              </Button>
              <Button asChild variant="secondary" size="sm">
                <Link href={routes.practiceExam(exam.slug)}>Historique et conditions</Link>
              </Button>
            </div>
          </div>
          {toReview.length ? (
            <div className="min-w-0">
              <h2 className="text-[15px] text-ink">Leçons à réviser</h2>
              <ul className="mt-3 divide-y divide-line border-y border-line">
                {toReview.map((id) => (
                  <li key={id}>
                    <Link href={routes.lesson(id)} className="flex items-center gap-3 py-2.5 text-[13px] text-ink transition-colors hover:text-accent">
                      <span className="num w-10 shrink-0 text-ink-3">{id}</span>
                      <span className="min-w-0 flex-1 truncate">{lessonTitles[id]}</span>
                      <ArrowRight size={12} className="shrink-0 text-ink-3" aria-hidden />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <p className="self-center text-[13.5px] text-ok-ink">Aucune erreur : rien à réviser sur cette session.</p>
          )}
        </section>
      </FadeIn>

      <section className="py-10" aria-labelledby="domaines">
        <div className="mb-6 flex flex-wrap items-baseline justify-between gap-3">
          <h2 id="domaines" className="text-[15px] text-ink">
            Score par domaine
          </h2>
          <p className="text-[12px] text-ink-3">Trait vertical : seuil d&apos;entraînement de {a.passScore} %</p>
        </div>
        <Panel>
          <ul className="divide-y divide-line">
            {a.byDomain.map((d, i) => {
              const meta = exam.domaines.find((x) => x.nom === d.domaine);
              return (
                <li key={d.domaine} className="grid gap-x-6 gap-y-2 px-5 py-4 md:grid-cols-[minmax(0,1fr)_minmax(180px,260px)_96px] md:items-center">
                  <span className="min-w-0">
                    <span className="block text-[13px] leading-snug text-ink">{d.domaine}</span>
                    {meta?.poids ? <span className="num mt-0.5 block text-[11px] text-ink-3">Pondération {meta.poids}</span> : null}
                  </span>
                  <ScoreRule value={d.percent} threshold={a.passScore} delay={0.3 + i * 0.06} label={`${d.domaine} : ${d.percent} %`} />
                  <span className="num text-[13px] text-ink md:text-right">
                    {d.correct}/{d.total}
                    <span className="ml-2 text-ink-3">{pct(d.percent)}</span>
                  </span>
                </li>
              );
            })}
          </ul>
        </Panel>
      </section>

      <section className="pb-6" aria-labelledby="correction">
        <h2 id="correction" className="mb-5 text-[15px] text-ink">
          Correction détaillée
        </h2>
        <CorrectionList items={items} lessonTitles={lessonTitles} lessonHref={lessonHref} groupLabel="Domaine" />
      </section>

      <PracticeWarning className="mt-6" title="Rappel">
        <p className="text-[13px] leading-relaxed">{exam.avertissement}</p>
      </PracticeWarning>
    </div>
  );
}
