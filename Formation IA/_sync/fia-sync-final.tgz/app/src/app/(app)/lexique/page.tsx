import type { Metadata } from "next";
import { BookBookmark } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { loadAccess } from "@/server/learner";
import { getFlatLessons, getGlossary } from "@/content";
import { canAccessLesson } from "@/domain";
import { plural } from "@/lib/utils";
import { PageHeader } from "@/components/ui/surface";
import { LexiconBrowser, type LessonLink } from "@/components/lexique/lexicon-browser";

export const metadata: Metadata = { title: "Lexique" };

/** Lexique de la formation (glossaire/glossaire.json). Fichier absent : page vide qui explique la suite. */
export default async function LexiquePage({ searchParams }: { searchParams: Promise<{ terme?: string | string[] }> }) {
  const user = await requireUser();
  const { terme } = await searchParams;
  const glossary = getGlossary();
  const { access } = await loadAccess(user.id);

  const referenced = new Set(glossary.terms.flatMap((t) => t.lecons));
  const lessons: Record<string, LessonLink> = {};
  for (const l of getFlatLessons()) if (referenced.has(l.id)) lessons[l.id] = { id: l.id, title: l.title, accessible: canAccessLesson(access, l.id) };

  return (
    <div>
      <PageHeader
        title="Lexique"
        description={
          glossary.terms.length
            ? `${plural(glossary.terms.length, "terme")} de l'IA expliqués simplement, avec une analogie, un exemple et les leçons où ils apparaissent. Tapez « / » pour rechercher.`
            : "Les mots de l'IA expliqués simplement, avec une analogie, un exemple et les leçons où ils apparaissent."
        }
      />
      {glossary.terms.length ? (
        <LexiconBrowser terms={glossary.terms} lessons={lessons} initialSlug={typeof terme === "string" ? terme : null} />
      ) : (
        <div className="relative overflow-hidden border border-dashed border-line-strong px-6 py-16 text-center sm:py-24">
          <span aria-hidden className="filigrane pointer-events-none absolute -bottom-10 left-1/2 -translate-x-1/2 text-[180px] text-ink sm:text-[240px]">
            A–Z
          </span>
          <span className="relative mx-auto flex h-12 w-12 items-center justify-center border border-line-strong bg-bg-elev text-accent">
            <BookBookmark size={22} aria-hidden />
          </span>
          <p className="relative mt-6 font-display text-[18px] font-light uppercase tracking-[0.06em] text-ink">Le lexique arrive bientôt</p>
          <p className="relative mx-auto mt-3 max-w-[48ch] text-[13.5px] text-ink-2">
            {glossary.status === "invalid"
              ? "Le fichier du lexique est en cours de mise à jour. Revenez dans quelques instants."
              : "Les définitions des termes de la formation sont en cours de rédaction. En attendant, le tuteur IA de chaque leçon peut vous expliquer un mot inconnu."}
          </p>
        </div>
      )}
    </div>
  );
}
