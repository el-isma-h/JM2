import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, Briefcase, Check, Lock } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { loadAccess } from "@/server/learner";
import { completedLessonIds, getUserMetier, metierBlockProgress, progressFor } from "@/server/metiers";
import { getFlatLessons, getMetier, getMetierSlugs } from "@/content";
import { routes } from "@/lib/paths";
import { cn, formatMinutes } from "@/lib/utils";
import { Markdown } from "@/components/markdown/markdown";
import { FadeIn } from "@/components/ui/motion";
import { Progress } from "@/components/ui/progress";
import { ReadingArticle, TableOfContents } from "@/components/lecon/reading";
import { MyMetierButton } from "@/components/metiers/my-metier";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const m = getMetier(slug);
  return { title: m ? `Parcours métier — ${m.title}` : "Parcours métier" };
}

/** Encadré 🧭 de tête : déjà affiché dans l'en-tête de la page. */
const stripLead = (body: string) => body.replace(/^>\s*🧭[^\n]*(?:\n>[^\n]*)*\n*/u, "");

export default async function MetierPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const user = await requireUser();
  const metier = getMetier(slug);
  if (!metier) notFound();

  const [mine, completed, blocks, { access }] = await Promise.all([getUserMetier(user.id), completedLessonIds(user.id), metierBlockProgress(user.id, slug), loadAccess(user.id)]);
  const prog = progressFor(metier, completed);
  const lessonIds = getFlatLessons().map((l) => l.id);
  const slugs = getMetierSlugs();
  const i = slugs.indexOf(slug);
  const prev = i > 0 ? getMetier(slugs[i - 1]) : null;
  const next = i >= 0 && i < slugs.length - 1 ? getMetier(slugs[i + 1]) : null;
  const toc = metier.headings.filter((h) => h.depth === 2).map((h) => ({ id: h.id, text: h.text }));
  const priority = metier.lessons.filter((l) => l.priority);
  const nextLesson = prog.nextLessonId ? metier.lessons.find((l) => l.id === prog.nextLessonId) ?? null : null;
  const nextOpen = nextLesson ? Boolean(access.lessons[nextLesson.id]?.accessible) : false;

  return (
    <div>
      <FadeIn>
        <header className="border-b border-line pb-7">
          <nav className="flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3" aria-label="Fil d'Ariane">
            <Link href={routes.metiers} className="hover:text-ink">
              Parcours métiers
            </Link>
            <span aria-hidden>/</span>
            <span>{metier.title}</span>
          </nav>
          <div className="mt-6 flex flex-wrap items-start justify-between gap-x-6 gap-y-4">
            <div className="min-w-0">
              <p className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-accent">
                <Briefcase size={14} aria-hidden /> Parcours métier {i >= 0 ? `· ${String(i + 1).padStart(2, "0")}` : ""}
              </p>
              <h1 className="mt-4 max-w-[24ch] text-[28px] leading-[1.06] text-ink sm:text-[40px]">{metier.title}</h1>
            </div>
            <MyMetierButton slug={slug} title={metier.title} selected={mine === slug} />
          </div>
          {metier.summary ? <p className="mt-4 max-w-[72ch] font-serif text-[19px] italic leading-snug text-ink-2">{metier.summary}</p> : null}
          <dl className="mt-6 grid grid-cols-2 gap-px border border-line bg-line sm:grid-cols-4">
            {[
              { k: "Parcours prioritaire", v: metier.priorityDuration || "—" },
              { k: "Avec facultatives", v: metier.fullDuration || "—" },
              { k: "Leçons prioritaires", v: `${prog.done} / ${prog.total}` },
              { k: "Facultatives", v: String(metier.optionalLessons) },
            ].map((x) => (
              <div key={x.k} className="bg-bg px-4 py-3">
                <dt className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">{x.k}</dt>
                <dd className="num mt-1 text-[17px] text-ink">{x.v}</dd>
              </div>
            ))}
          </dl>
          {metier.scope ? <p className="num mt-3 font-mono text-[11px] text-ink-3">Niveaux et modules mobilisés : {metier.scope}</p> : null}
        </header>
      </FadeIn>

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1fr)_260px] xl:gap-14">
        <div className="min-w-0">
          <div className="mb-8 lg:hidden">
            <TableOfContents items={toc} variant="inline" />
          </div>
          <ReadingArticle>
            <Markdown
              source={stripLead(metier.body)}
              metier={{ slug, doneQuiz: blocks.quiz, doneMissions: blocks.mission }}
              lessonLinks={lessonIds}
              className="[&>h2:first-child]:mt-0 [&>h2:first-child]:border-t-0 [&>h2:first-child]:pt-0"
            />
          </ReadingArticle>

          <nav className="mt-14 grid max-w-[704px] gap-px border border-line bg-line sm:grid-cols-2" aria-label="Parcours précédent et suivant">
            {prev ? (
              <Link href={routes.metier(prev.slug)} className="flex flex-col gap-1 bg-bg p-5 transition-colors hover:bg-bg-sunken">
                <span className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">
                  <ArrowLeft size={12} aria-hidden /> Parcours précédent
                </span>
                <span className="text-[13px] text-ink">{prev.title}</span>
              </Link>
            ) : (
              <span className="bg-bg p-5" />
            )}
            {next ? (
              <Link href={routes.metier(next.slug)} className="flex flex-col items-end gap-1 bg-bg p-5 text-right transition-colors hover:bg-bg-sunken">
                <span className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">
                  Parcours suivant <ArrowRight size={12} aria-hidden />
                </span>
                <span className="text-[13px] text-ink">{next.title}</span>
              </Link>
            ) : (
              <span className="bg-bg p-5" />
            )}
          </nav>
        </div>

        <aside className="min-w-0">
          <div className="space-y-6 lg:sticky lg:top-10">
            <section className="border border-line bg-bg-elev" aria-labelledby="metier-progression">
              <div className="border-b border-line px-5 py-4">
                <h2 id="metier-progression" className="font-mono text-[10px] font-medium tracking-[0.24em] text-ink-3">
                  Votre progression
                </h2>
                <Progress className="mt-3" value={prog.done} max={Math.max(1, prog.total)} label={`${prog.done} leçons prioritaires terminées sur ${prog.total}`} tone="accent" />
                <p className="num mt-2 text-[12px] text-ink-2">
                  {prog.done}/{prog.total} leçons prioritaires · {prog.percent} %
                </p>
              </div>
              {nextLesson ? (
                <div className="px-5 py-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-accent">Prochaine leçon prioritaire</p>
                  <Link href={routes.lesson(nextLesson.id)} className="group mt-2 block">
                    <span className="num text-[11px] text-ink-3">{nextLesson.id}</span>
                    <span className="mt-0.5 block text-[13.5px] leading-snug text-ink transition-colors group-hover:text-accent">{nextLesson.title}</span>
                    <span className="mt-1.5 inline-flex items-center gap-1.5 text-[11.5px] text-ink-3">
                      {nextOpen ? null : <Lock size={11} aria-hidden />}
                      {formatMinutes(nextLesson.minutes)}
                      {nextOpen ? "" : " · s'ouvre avec le parcours"}
                    </span>
                  </Link>
                </div>
              ) : prog.total ? (
                <p className="px-5 py-4 text-[13px] text-ok-ink">Toutes les leçons prioritaires sont terminées.</p>
              ) : null}
            </section>

            {priority.length ? (
              <section className="hidden border border-line bg-bg-elev p-5 lg:block" aria-labelledby="metier-lecons">
                <h2 id="metier-lecons" className="font-mono text-[10px] font-medium tracking-[0.24em] text-ink-3">
                  Leçons prioritaires
                </h2>
                <ul className="mt-3 max-h-[42vh] space-y-0.5 overflow-y-auto pr-1">
                  {priority.map((l) => {
                    const done = completed.has(l.id);
                    return (
                      <li key={l.id}>
                        <Link href={routes.lesson(l.id)} className="group flex gap-2.5 py-1 text-[12px] leading-snug text-ink-2 transition-colors hover:text-ink">
                          <span className={cn("mt-px flex size-3.5 shrink-0 items-center justify-center border", done ? "border-ok bg-ok text-bg" : l.id === prog.nextLessonId ? "border-accent" : "border-line-strong")} aria-hidden>
                            {done ? <Check size={9} weight="bold" /> : null}
                          </span>
                          <span className="num shrink-0 text-[10.5px] text-ink-3 group-hover:text-accent">{l.id}</span>
                          <span className={cn(done && "text-ink-3")}>
                            {l.title}
                            <span className="sr-only">{done ? " (terminée)" : ""}</span>
                          </span>
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </section>
            ) : null}

            <div className="hidden lg:block">
              <TableOfContents items={toc} variant="aside" />
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
