import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Briefcase, Check, Clock } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { completedLessonIds, getUserMetier, progressFor } from "@/server/metiers";
import { getMetier, getMetierCatalog } from "@/content";
import { routes } from "@/lib/paths";
import { cn, plural } from "@/lib/utils";
import { PageHeader } from "@/components/ui/surface";
import { Progress } from "@/components/ui/progress";
import { FadeIn, Stagger, StaggerItem } from "@/components/ui/motion";
import { EmptyState } from "@/components/ui/surface";
import { Markdown } from "@/components/markdown/markdown";

export const metadata: Metadata = { title: "Parcours métiers" };

/** Liens relatifs vers d'autres fichiers Markdown du dépôt : sans objet dans l'application, gardés en texte. */
const unlinkFiles = (md: string) => md.replace(/\[([^\]]+)\]\((?!https?:)[^)]*\.md\)/g, "$1");

/** Dernière carte : s'étend pour compléter la dernière ligne (2 colonnes dès sm, 3 dès xl). */
function fillLastRow(i: number, n: number): string {
  if (i !== n - 1) return "";
  const sm = n % 2 === 1 ? "sm:col-span-2" : "";
  const xl = n % 3 === 1 ? "xl:col-span-3" : n % 3 === 2 ? "xl:col-span-2" : sm ? "xl:col-span-1" : "";
  return cn(sm, xl);
}

/**
 * Parcours métiers (parcours-metiers/*.md) : la formation relue par métier. Ouverts à tout apprenant connecté ;
 * les leçons citées restent soumises aux règles de déblocage du parcours.
 */
export default async function MetiersPage() {
  const user = await requireUser();
  const [mine, completed] = await Promise.all([getUserMetier(user.id), completedLessonIds(user.id)]);
  const catalog = getMetierCatalog();

  return (
    <div>
      <PageHeader
        title="Parcours métiers"
        description={`${plural(catalog.metiers.length, "parcours", "parcours")} qui relisent la formation par métier : ce que l'IA change pour vous, les leçons à suivre en priorité, des cas d'usage, des projets, des missions et des quiz.`}
        actions={
          <Link href={routes.profile + "#metier"} className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors hover:text-accent">
            <Briefcase size={14} aria-hidden /> {mine ? "Changer de métier" : "Choisir mon métier"}
          </Link>
        }
      />

      {catalog.metiers.length === 0 ? (
        <EmptyState icon={<Briefcase size={28} aria-hidden />} title="Parcours en préparation" description="Les parcours métiers seront bientôt disponibles." />
      ) : (
        <>
          {catalog.intro ? (
            <FadeIn>
              <div className="mb-10 grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px] lg:gap-12">
                <Markdown source={unlinkFiles(catalog.intro)} className="max-w-[72ch] [&>p:first-child]:mt-0" />
                <p className="self-start border-l-2 border-accent bg-accent-soft px-4 py-3 text-[12.5px] leading-relaxed text-ink">
                  Un parcours métier est un <strong>sous-ensemble</strong> de la formation. Le certificat d&apos;un niveau suppose de suivre ce niveau en entier.
                </p>
              </div>
            </FadeIn>
          ) : null}

          <Stagger className="grid gap-px border border-line bg-line sm:grid-cols-2 xl:grid-cols-3">
            {catalog.metiers.map((m, i) => {
              const full = getMetier(m.slug);
              const prog = full ? progressFor(full, completed) : null;
              const selected = mine === m.slug;
              return (
                <StaggerItem key={m.slug} className={cn("bg-bg-elev", fillLastRow(i, catalog.metiers.length))}>
                  <Link
                    href={routes.metier(m.slug)}
                    className="group relative flex h-full min-h-[264px] flex-col overflow-hidden p-5 transition-colors duration-500 hover:bg-bg-sunken sm:p-6"
                  >
                    <span aria-hidden className="filigrane pointer-events-none absolute -bottom-6 -right-1 text-[104px] text-ink">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="relative flex flex-wrap items-center gap-2">
                      <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-accent">
                        <Briefcase size={13} aria-hidden /> Métier {String(i + 1).padStart(2, "0")}
                      </span>
                      {selected ? (
                        <span className="inline-flex items-center gap-1 border border-accent bg-accent px-2 py-0.5 font-mono text-[10px] uppercase leading-4 tracking-[0.14em] text-accent-ink">
                          <Check size={10} weight="bold" aria-hidden /> Mon métier
                        </span>
                      ) : null}
                    </span>
                    <span className="relative mt-3 font-display text-[19px] font-light uppercase leading-[1.1] tracking-[0.05em] text-ink">{m.title}</span>
                    {m.summary ? <span className="relative mt-3 line-clamp-3 max-w-[48ch] text-[13px] leading-relaxed text-ink-2">{m.summary}</span> : null}
                    <span className="relative mt-auto block pt-5">
                      <span className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                        <span className="inline-flex items-center gap-1.5 text-[13px] text-ink">
                          <Clock size={13} className="text-ink-3" aria-hidden />
                          <span className="num">{m.priorityDuration || "—"}</span>
                          <span className="text-ink-3">prioritaires</span>
                        </span>
                        {m.fullDuration ? <span className="num text-[11.5px] text-ink-3">{m.fullDuration} avec facultatives</span> : null}
                      </span>
                      {m.scope ? <span className="num mt-1.5 block truncate font-mono text-[10.5px] text-ink-3">{m.scope}</span> : null}
                      {prog && prog.total ? (
                        <span className="mt-4 block">
                          <Progress value={prog.done} max={prog.total} label={`${m.title} : ${prog.done} leçons prioritaires terminées sur ${prog.total}`} tone="accent" />
                          <span className="mt-1.5 flex items-center justify-between gap-2 text-[11.5px] text-ink-3">
                            <span className="num">
                              {prog.done}/{prog.total} leçons prioritaires
                            </span>
                            <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors group-hover:text-accent">
                              Ouvrir <ArrowRight size={12} className="transition-transform duration-500 group-hover:translate-x-1" aria-hidden />
                            </span>
                          </span>
                        </span>
                      ) : null}
                    </span>
                  </Link>
                </StaggerItem>
              );
            })}
          </Stagger>

          {catalog.contents ? (
            <FadeIn delay={0.1}>
              <details className="group mt-10 border border-line bg-bg-elev">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-5 py-4 text-[14px] text-ink marker:hidden">
                  Ce que contient chaque parcours
                  <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3 group-open:hidden">Afficher</span>
                  <span className="hidden font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3 group-open:inline">Masquer</span>
                </summary>
                <div className="border-t border-line px-5 pb-5 pt-1">
                  <Markdown source={unlinkFiles(catalog.contents)} className="max-w-[78ch]" />
                </div>
              </details>
            </FadeIn>
          ) : null}
        </>
      )}
    </div>
  );
}
