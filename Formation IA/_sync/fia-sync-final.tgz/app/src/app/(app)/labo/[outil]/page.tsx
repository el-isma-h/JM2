import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { requireUser } from "@/server/auth";
import { loadAccess } from "@/server/learner";
import { getFlatLessons } from "@/content";
import { canAccessLesson } from "@/domain";
import { LABO_TOOL_BY_ID, isLaboToolId, type LaboToolId } from "@/domain/labo/tools";
import { ToolFrame, type LessonRef } from "@/components/labo/tool-frame";
import { LlmCalculator } from "@/components/labo/llm-calculator";
import { TokenizerTool } from "@/components/labo/tokenizer-tool";
import { SamplingTool } from "@/components/labo/sampling-tool";
import { ApiCostsTool } from "@/components/labo/api-costs-tool";
import { EmbeddingsTool } from "@/components/labo/embeddings-tool";

type Props = { params: Promise<{ outil: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { outil } = await params;
  return { title: isLaboToolId(outil) ? `${LABO_TOOL_BY_ID[outil].title} · Labo` : "Labo" };
}

const EN_CLAIR: Record<LaboToolId, React.ReactNode> = {
  "memoire-llm": (
    <p>
      La mémoire de l&apos;ordinateur, c&apos;est le plan de travail du chef : si la recette (le modèle) ne tient pas dessus, impossible de cuisiner. La bande passante, c&apos;est la vitesse à laquelle il attrape ses ingrédients : elle décide du nombre de mots écrits par seconde. Réglez la taille du modèle, sa précision et la longueur du texte à traiter : l&apos;outil applique la formule de la leçon L042 et dit, machine par machine, si ça tient et à quelle vitesse.
    </p>
  ),
  tokeniseur: (
    <p>
      Un modèle ne lit pas des mots mais des tokens, des petits morceaux de texte : c&apos;est l&apos;unité du prix, du contexte et de la vitesse. Les mots courants restent entiers, les mots longs ou rares sont coupés en plusieurs bouts, et le français demande plus de morceaux que l&apos;anglais. Collez un texte pour le voir découpé et savoir combien il coûtera à envoyer.
    </p>
  ),
  temperature: (
    <p>
      Pour écrire, le modèle donne une chance à chaque mot possible, puis tire au sort. La température est le bouton d&apos;audace de ce tirage : basse, il sert presque toujours le mot le plus probable ; haute, il ose des mots improbables. Top-k et top-p coupent la queue des options absurdes avant le tirage. Bougez les curseurs et tirez plusieurs fois pour voir la différence.
    </p>
  ),
  "couts-api": (
    <p>
      Une API se paie comme un transporteur facturé au poids : vous payez les tokens envoyés (l&apos;entrée) et, plus cher, ceux que le modèle renvoie (la sortie). Ce n&apos;est pas un appel qui coûte cher, c&apos;est la multiplication par le nombre de requêtes. Décrivez votre usage pour comparer douze modèles, puis activez le cache et le batch pour voir la facture fondre.
    </p>
  ),
  embeddings: (
    <p>
      Un embedding est l&apos;adresse d&apos;un texte sur une carte du sens : deux phrases qui parlent de la même chose habitent le même quartier, même sans mot commun. Le cosinus mesure si leurs flèches, tracées depuis l&apos;origine, pointent dans la même direction : 1 pour « même sujet », 0 pour « aucun rapport ». Déplacez les phrases de la leçon L047 et regardez le score changer.
    </p>
  ),
};

const TOOLS: Record<LaboToolId, React.ComponentType> = {
  "memoire-llm": LlmCalculator,
  tokeniseur: TokenizerTool,
  temperature: SamplingTool,
  "couts-api": ApiCostsTool,
  embeddings: EmbeddingsTool,
};

export default async function LaboToolPage({ params }: Props) {
  const user = await requireUser();
  const { outil } = await params;
  if (!isLaboToolId(outil)) notFound();
  const tool = LABO_TOOL_BY_ID[outil];
  const { access } = await loadAccess(user.id);
  const flat = new Map(getFlatLessons().map((l) => [l.id, l]));
  const lessons: LessonRef[] = tool.lessons
    .map((id) => flat.get(id))
    .filter((l): l is NonNullable<typeof l> => Boolean(l))
    .map((l) => ({ id: l.id, title: l.title, accessible: canAccessLesson(access, l.id) }));
  const Tool = TOOLS[outil];
  return (
    <ToolFrame tool={tool} enClair={EN_CLAIR[outil]} lessons={lessons}>
      <Tool />
    </ToolFrame>
  );
}
