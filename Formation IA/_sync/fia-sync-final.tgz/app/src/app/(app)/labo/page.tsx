import type { Metadata } from "next";
import Link from "next/link";
import { eq } from "drizzle-orm";
import { ArrowRight, ChartScatter, CheckCircle, Coins, Cpu, Flask, Scissors, Thermometer } from "@phosphor-icons/react/ssr";
import type { Icon } from "@phosphor-icons/react";
import { requireUser } from "@/server/auth";
import { db, schema } from "@/db";
import { LABO_TOOLS, LABO_TOOL_IDS, laboToolsUsedCount, type LaboToolId } from "@/domain/labo/tools";
import { PageHeader } from "@/components/ui/surface";
import { Progress } from "@/components/ui/progress";
import { routes } from "@/lib/paths";

export const metadata: Metadata = { title: "Labo" };

const TOOL_ICONS: Record<LaboToolId, Icon> = { "memoire-llm": Cpu, tokeniseur: Scissors, temperature: Thermometer, "couts-api": Coins, embeddings: ChartScatter };

/** Labo : cinq outils pédagogiques 100 % côté client (src/domain/labo), badge « Laborantin » après les cinq. */
export default async function LaboPage() {
  const user = await requireUser();
  const uses = await db.select({ toolId: schema.laboUses.toolId }).from(schema.laboUses).where(eq(schema.laboUses.userId, user.id));
  const used = new Set(uses.map((u) => u.toolId));
  const count = laboToolsUsedCount([...used]);
  const total = LABO_TOOL_IDS.length;

  return (
    <div>
      <PageHeader
        title="Labo"
        description="Cinq instruments pour manipuler ce que les leçons expliquent : la mémoire d'un modèle local, les tokens, la température, la facture d'une API et la géométrie du sens. Tout se calcule dans votre navigateur."
      />

      <div className="mb-8 flex flex-wrap items-center gap-x-6 gap-y-3 border border-line bg-bg-elev px-5 py-4">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center border border-line-strong text-accent">
          <Flask size={20} aria-hidden />
        </span>
        <div className="min-w-[200px] flex-1">
          <p className="text-[13.5px] text-ink">
            {count >= total ? "Badge « Laborantin » obtenu : vous avez utilisé les cinq outils." : `Badge « Laborantin » : utilisez les cinq outils (${count} sur ${total}).`}
          </p>
          <Progress className="mt-2 max-w-md" value={count} max={total} label="Outils du Labo utilisés" />
        </div>
      </div>

      <ul className="border-t border-line">
        {LABO_TOOLS.map((t) => {
          const I = TOOL_ICONS[t.id];
          const done = used.has(t.id);
          return (
            <li key={t.id} className="border-b border-line">
              <Link href={routes.laboTool(t.id)} className="group grid gap-x-8 gap-y-3 px-1 py-6 transition-colors duration-500 hover:bg-bg-elev sm:grid-cols-[3rem_minmax(0,1fr)_auto] sm:px-4">
                <span className="flex h-11 w-11 items-center justify-center border border-line-strong text-ink transition-colors duration-500 group-hover:border-accent group-hover:text-accent">
                  <I size={22} aria-hidden />
                </span>
                <div className="min-w-0">
                  <h2 className="text-[20px] text-ink sm:text-[24px]">{t.title}</h2>
                  <p className="mt-2 font-serif text-[19px] italic leading-snug text-ink-2">{t.question}</p>
                  <p className="mt-2 max-w-[70ch] text-[13.5px] text-ink-2">{t.summary}</p>
                  <p className="num mt-3 text-[11px] text-ink-3">Leçons {t.lessons.join(" · ")}</p>
                </div>
                <div className="flex items-center gap-4 self-center">
                  {done ? (
                    <span className="inline-flex items-center gap-1.5 text-[12px] text-ok-ink">
                      <CheckCircle size={14} weight="fill" aria-hidden /> Utilisé
                    </span>
                  ) : null}
                  <span className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors duration-500 group-hover:text-accent">
                    Ouvrir <ArrowRight size={14} aria-hidden className="transition-transform duration-500 group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            </li>
          );
        })}
      </ul>
      <p className="mt-6 max-w-[78ch] text-[12.5px] text-ink-3">
        Les chiffres affichés sont des estimations construites avec les règles et les tarifs cités dans les leçons (novembre 2026). Ils servent à raisonner, pas à remplacer une mesure sur votre machine ou la page officielle d&apos;un fournisseur.
      </p>
    </div>
  );
}
