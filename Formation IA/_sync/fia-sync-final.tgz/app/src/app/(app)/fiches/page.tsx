import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Notepad } from "@phosphor-icons/react/ssr";
import { requireUser } from "@/server/auth";
import { loadAccess } from "@/server/learner";
import { getModuleMemos, getProgramme, isSpecialisationLevel } from "@/content";
import { routes } from "@/lib/paths";
import { plural } from "@/lib/utils";
import { PageHeader } from "@/components/ui/surface";
import { SpecialisationBadge, StatusBadge } from "@/components/ui/badge";
import { Stagger, StaggerItem } from "@/components/ui/motion";

export const metadata: Metadata = { title: "Fiches mémo" };

/** Toutes les fiches mémo, par niveau : une page par module pour réviser en cinq minutes, imprimable. */
export default async function FichesPage() {
  const user = await requireUser();
  const { access } = await loadAccess(user.id);
  const prog = getProgramme();
  const memos = getModuleMemos();
  const byModule = new Map(memos.map((m) => [m.moduleId, m]));

  return (
    <div>
      <PageHeader
        title="Fiches mémo"
        description={`Une page par module pour réviser en cinq minutes : idées clés, schéma, vocabulaire, pièges et auto-test. ${plural(memos.length, "fiche disponible", "fiches disponibles")}, imprimables au format A4.`}
      />

      <div className="space-y-12">
        {prog.levels.map((level, li) => {
          const list = level.modules.filter((m) => byModule.has(m.id));
          const spec = isSpecialisationLevel(level);
          return (
            <section key={level.id} aria-labelledby={`fiches-${level.id}`}>
              <div className="mb-4 flex flex-wrap items-center gap-3">
                <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-ink-3">
                  Niveau {li + 1} · {plural(list.length, "fiche")}
                </span>
                {spec ? <SpecialisationBadge /> : null}
              </div>
              <h2 id={`fiches-${level.id}`} className="max-w-[40ch] text-[20px] text-ink sm:text-[22px]">
                {level.title}
              </h2>
              {list.length === 0 ? (
                <p className="mt-4 border border-dashed border-line-strong bg-bg-sunken/50 px-5 py-4 text-[13px] text-ink-2">Les fiches de ce niveau sont en préparation.</p>
              ) : (
                <Stagger className="mt-5 grid gap-px border border-line bg-line sm:grid-cols-2 xl:grid-cols-3">
                  {list.map((m) => {
                    const memo = byModule.get(m.id)!;
                    const ma = access.modules[m.id];
                    return (
                      <StaggerItem key={m.id} className="bg-bg-elev">
                        <Link href={routes.memo(m.id)} className="group relative flex h-full min-h-[148px] flex-col overflow-hidden p-5 transition-colors duration-500 hover:bg-bg-sunken">
                          <span aria-hidden className="filigrane pointer-events-none absolute -bottom-4 -right-1 text-[92px] text-ink">
                            {m.id.slice(1)}
                          </span>
                          <span className="relative flex flex-wrap items-center gap-2">
                            <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-accent">
                              <Notepad size={13} aria-hidden /> Module {m.id.slice(1)}
                            </span>
                            {ma ? <StatusBadge status={ma.state} /> : null}
                          </span>
                          <span className="relative mt-3 max-w-[30ch] text-[14px] leading-snug text-ink">{m.title}</span>
                          <span className="relative mt-auto inline-flex items-center gap-2 pt-5 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 transition-colors group-hover:text-accent">
                            Ouvrir la fiche · {Math.max(3, Math.round(memo.wordCount / 160))} min
                            <ArrowRight size={12} className="transition-transform duration-500 group-hover:translate-x-1" aria-hidden />
                          </span>
                        </Link>
                      </StaggerItem>
                    );
                  })}
                </Stagger>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}
