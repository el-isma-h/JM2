"use client";

/**
 * Lexique (/lexique) : recherche instantanée (accents ignorés), filtres catégorie et niveau, index alphabétique et
 * fiche du terme (définition, analogie, exemple, voir aussi, leçons liées, source). L'URL suit le terme ouvert
 * (`?terme=slug`) ; chaque fiche ouverte est notée côté serveur (badge « Lexicographe »).
 */
import * as React from "react";
import Link from "next/link";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ArrowLeft, ArrowSquareOut, BookOpenText, Lock, MagnifyingGlass, X } from "@phosphor-icons/react";
import type { GlossaryTerm } from "@/content/types";
import { filterLexicon, initialOf, lexiconFacets } from "@/lib/lexicon-filter";
import { routes, withBase } from "@/lib/paths";
import { viewLexiconTermAction } from "@/server/actions/enrichments";
import { announceRewards } from "@/components/feedback/toaster";
import { cn, plural } from "@/lib/utils";

export type LessonLink = { id: string; title: string; accessible: boolean };

export function LexiconBrowser({ terms, lessons, initialSlug }: { terms: GlossaryTerm[]; lessons: Record<string, LessonLink>; initialSlug: string | null }) {
  const reduce = useReducedMotion();
  const [query, setQuery] = React.useState("");
  const [categorie, setCategorie] = React.useState<string | null>(null);
  const [niveau, setNiveau] = React.useState<string | null>(null);
  const [selected, setSelected] = React.useState<string | null>(initialSlug && terms.some((t) => t.slug === initialSlug) ? initialSlug : null);
  const deferred = React.useDeferredValue(query);
  const facets = React.useMemo(() => lexiconFacets(terms), [terms]);
  const result = React.useMemo(() => filterLexicon(terms, { query: deferred, categorie, niveau }), [terms, deferred, categorie, niveau]);
  const bySlug = React.useMemo(() => new Map(terms.map((t) => [t.slug, t])), [terms]);
  const term = selected ? bySlug.get(selected) ?? null : null;
  const inputRef = React.useRef<HTMLInputElement>(null);
  const ficheRef = React.useRef<HTMLElement>(null);
  const viewed = React.useRef(new Set<string>());

  // Groupes alphabétiques (sans recherche) ; liste à plat par pertinence pendant une recherche.
  const groups = React.useMemo(() => {
    if (deferred.trim()) return [{ letter: null as string | null, items: result }];
    const map = new Map<string, GlossaryTerm[]>();
    for (const t of result) {
      const k = initialOf(t.terme);
      map.set(k, [...(map.get(k) ?? []), t]);
    }
    return [...map.entries()].sort(([a], [b]) => (a === "#" ? -1 : b === "#" ? 1 : a.localeCompare(b))).map(([letter, items]) => ({ letter, items }));
  }, [result, deferred]);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (e.key === "/" && t?.tagName !== "INPUT" && t?.tagName !== "TEXTAREA") {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Fiche ouverte → URL partageable + trace « terme consulté » (une fois par terme et par visite).
  React.useEffect(() => {
    try {
      const url = new URL(window.location.href);
      if (selected) url.searchParams.set("terme", selected);
      else url.searchParams.delete("terme");
      window.history.replaceState(window.history.state, "", url);
    } catch {
      /* historique indisponible */
    }
    if (!selected || viewed.current.has(selected)) return;
    viewed.current.add(selected);
    void viewLexiconTermAction(selected).then((r) => {
      if (r.ok && r.rewards.badges.length) announceRewards(r.rewards);
    });
  }, [selected]);

  const open = (slug: string, focus = false) => {
    setSelected(slug);
    if (focus || window.matchMedia("(max-width: 1023px)").matches) {
      requestAnimationFrame(() => {
        ficheRef.current?.focus({ preventScroll: true });
        ficheRef.current?.scrollIntoView({ block: "start", behavior: reduce ? "auto" : "smooth" });
      });
    }
  };

  const filtered = Boolean(deferred.trim() || categorie || niveau);

  return (
    <div>
      <div className="sticky top-14 z-20 -mx-4 border-b border-line bg-bg/95 px-4 py-4 backdrop-blur sm:-mx-8 sm:px-8 lg:top-0 lg:-mx-12 lg:px-12">
        <label htmlFor="lex-search" className="sr-only">
          Rechercher un terme
        </label>
        <div className="relative">
          <MagnifyingGlass size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-3" aria-hidden />
          <input
            ref={inputRef}
            id="lex-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher un terme : token, RAG, agent…"
            autoComplete="off"
            className="h-12 w-full border border-line-strong bg-bg-elev pl-10 pr-20 text-[14px] text-ink outline-none transition-colors placeholder:text-ink-3 focus:border-ink"
          />
          {query ? (
            <button type="button" onClick={() => setQuery("")} className="absolute right-2 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center text-ink-3 hover:text-ink" aria-label="Effacer la recherche">
              <X size={14} />
            </button>
          ) : (
            <kbd className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 border border-line-strong px-1.5 font-mono text-[10px] text-ink-3 sm:block">/</kbd>
          )}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
          <div className="scrollbar-thin -mx-1 flex w-full min-w-0 gap-1.5 overflow-x-auto px-1 pb-1 sm:w-auto sm:flex-1" role="group" aria-label="Filtrer par catégorie">
            <Chip active={categorie === null} onClick={() => setCategorie(null)}>
              Toutes
            </Chip>
            {facets.categories.map((c) => (
              <Chip key={c.id} active={categorie === c.id} onClick={() => setCategorie(categorie === c.id ? null : c.id)}>
                {c.id} <span className="num opacity-60">{c.count}</span>
              </Chip>
            ))}
          </div>
          {facets.niveaux.length ? (
            <div className="scrollbar-thin flex max-w-full shrink-0 gap-px overflow-x-auto border border-line-strong bg-line-strong" role="group" aria-label="Filtrer par niveau">
              {[null, ...facets.niveaux].map((n) => (
                <button
                  key={n ?? "all"}
                  type="button"
                  aria-pressed={niveau === n}
                  onClick={() => setNiveau(n)}
                  className={cn("h-8 px-2.5 font-mono text-[10px] uppercase tracking-[0.12em] transition-colors", niveau === n ? "bg-ink text-bg" : "bg-bg text-ink-2 hover:text-ink")}
                >
                  {n ?? "Tous niveaux"}
                </button>
              ))}
            </div>
          ) : null}
        </div>
        <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3" aria-live="polite">
          {filtered ? `${plural(result.length, "terme")} sur ${terms.length}` : plural(terms.length, "terme")}
        </p>
      </div>

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)] lg:gap-12">
        {/* Liste */}
        <div className={cn("min-w-0", term && "hidden lg:block")}>
          {result.length === 0 ? (
            <div className="border border-dashed border-line-strong px-6 py-14 text-center">
              <p className="font-display text-[15px] font-light uppercase tracking-[0.06em] text-ink">Aucun terme ne correspond</p>
              <p className="mt-2 text-[13px] text-ink-2">Essayez un autre mot, ou retirez les filtres.</p>
              <button type="button" onClick={() => (setQuery(""), setCategorie(null), setNiveau(null))} className="mt-5 font-mono text-[10px] uppercase tracking-[0.2em] text-accent hover:underline">
                Tout afficher
              </button>
            </div>
          ) : (
            <div className="space-y-8">
              {groups.map((g) => (
                <section key={g.letter ?? "resultats"} aria-label={g.letter ? `Lettre ${g.letter}` : "Résultats"}>
                  {g.letter ? (
                    <h2 className="flex items-baseline gap-3 border-b border-line-strong pb-2 text-[22px] text-ink">
                      {g.letter}
                      <span className="num font-mono text-[10px] tracking-[0.18em] text-ink-3">{g.items.length}</span>
                    </h2>
                  ) : null}
                  <ul className="divide-y divide-line">
                    {g.items.map((t) => {
                      const on = t.slug === selected;
                      return (
                        <li key={t.slug}>
                          <a
                            href={withBase(routes.lexiconTerm(t.slug))}
                            onClick={(e) => {
                              if (e.metaKey || e.ctrlKey || e.shiftKey) return;
                              e.preventDefault();
                              open(t.slug);
                            }}
                            aria-current={on ? "true" : undefined}
                            className={cn("group relative grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-x-4 py-3 pl-3 pr-1 transition-colors", on ? "bg-bg-sunken" : "hover:bg-bg-sunken/60")}
                          >
                            {on ? <motion.span layoutId={reduce ? undefined : "lex-signal"} className="absolute inset-y-0 left-0 w-[2px] bg-accent" /> : null}
                            <span className="min-w-0">
                              <span className={cn("block text-[14.5px]", on ? "text-accent" : "text-ink group-hover:text-accent")}>{t.terme}</span>
                              <span className="mt-0.5 line-clamp-1 block text-[12.5px] text-ink-2">{t.definition}</span>
                            </span>
                            <span className="flex shrink-0 items-center gap-2 font-mono text-[9.5px] uppercase tracking-[0.14em] text-ink-3">
                              <span className="hidden sm:inline">{t.categorie}</span>
                              {t.niveau ? <span className="num border border-line-strong px-1.5 py-px">{t.niveau}</span> : null}
                            </span>
                          </a>
                        </li>
                      );
                    })}
                  </ul>
                </section>
              ))}
            </div>
          )}
        </div>

        {/* Fiche */}
        <div className={cn("min-w-0", !term && "hidden lg:block")}>
          <div className="lg:sticky lg:top-[184px]">
            <AnimatePresence mode="wait" initial={false}>
              {term ? (
                <motion.article
                  key={term.slug}
                  ref={ficheRef}
                  tabIndex={-1}
                  aria-labelledby="lex-term"
                  initial={reduce ? false : { opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={reduce ? undefined : { opacity: 0 }}
                  transition={{ duration: 0.22 }}
                  className="scroll-mt-48 border border-line-strong bg-bg-elev outline-none"
                >
                  <div className="border-b border-line px-5 py-5 sm:px-7 sm:py-6">
                    <button type="button" onClick={() => setSelected(null)} className="mb-4 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-ink-2 hover:text-ink lg:hidden">
                      <ArrowLeft size={12} aria-hidden /> Tous les termes
                    </button>
                    <div className="flex flex-wrap items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em]">
                      <span className="text-accent">{term.categorie}</span>
                      {term.niveau ? <span className="num border border-line-strong px-1.5 py-px text-ink-2">{term.niveau}</span> : null}
                    </div>
                    <h2 id="lex-term" className="mt-3 text-[26px] leading-[1.05] text-ink sm:text-[32px]">
                      {term.terme}
                    </h2>
                    <p className="mt-4 max-w-[62ch] text-[15px] leading-relaxed text-ink">{term.definition}</p>
                  </div>

                  {term.analogie ? (
                    <div className="border-b border-line px-5 py-5 sm:px-7">
                      <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-ink-3">Analogie</p>
                      <p className="mt-2 max-w-[56ch] font-serif text-[19px] italic leading-[1.45] text-ink sm:text-[20px]">{term.analogie}</p>
                    </div>
                  ) : null}

                  {term.exemple ? (
                    <div className="border-b border-line px-5 py-5 sm:px-7">
                      <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-ink-3">Exemple</p>
                      <p className="mt-2 max-w-[62ch] border-l-2 border-line-strong bg-bg-sunken px-4 py-3 text-[13.5px] leading-relaxed text-ink">{term.exemple}</p>
                    </div>
                  ) : null}

                  {term.voirAussi.length || term.lecons.length ? (
                    <div className="grid gap-px border-b border-line bg-line sm:grid-cols-2">
                      <div className="bg-bg-elev px-5 py-5 sm:px-7">
                        <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-ink-3">Voir aussi</p>
                        {term.voirAussi.length ? (
                          <ul className="mt-3 flex flex-wrap gap-1.5">
                            {term.voirAussi.map((slug) => {
                              const other = bySlug.get(slug);
                              return (
                                <li key={slug}>
                                  {other ? (
                                    <button type="button" onClick={() => open(slug, true)} className="h-8 border border-line-strong px-3 text-[12.5px] text-ink transition-colors hover:border-accent hover:text-accent">
                                      {other.terme}
                                    </button>
                                  ) : (
                                    <span className="inline-flex h-8 items-center border border-dashed border-line px-3 text-[12.5px] text-ink-3">{slug}</span>
                                  )}
                                </li>
                              );
                            })}
                          </ul>
                        ) : (
                          <p className="mt-3 text-[12.5px] text-ink-3">Aucun terme associé.</p>
                        )}
                      </div>
                      <div className="bg-bg-elev px-5 py-5 sm:px-7">
                        <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-ink-3">Leçons liées</p>
                        {term.lecons.length ? (
                          <ul className="mt-3 space-y-2">
                            {term.lecons.map((id) => {
                              const l = lessons[id];
                              return (
                                <li key={id}>
                                  <Link href={routes.lesson(id)} className="group flex items-start gap-2.5 text-[13px] leading-snug">
                                    <span className="num mt-px shrink-0 font-mono text-[11px] text-accent">{id}</span>
                                    <span className="min-w-0 text-ink group-hover:text-accent">{l?.title ?? "Leçon"}</span>
                                    {l && !l.accessible ? <Lock size={12} className="mt-0.5 shrink-0 text-ink-3" aria-label="verrouillée" /> : <BookOpenText size={13} className="mt-0.5 shrink-0 text-ink-3" aria-hidden />}
                                  </Link>
                                </li>
                              );
                            })}
                          </ul>
                        ) : (
                          <p className="mt-3 text-[12.5px] text-ink-3">Aucune leçon liée.</p>
                        )}
                      </div>
                    </div>
                  ) : null}

                  {term.source ? (
                    <div className="px-5 py-4 sm:px-7">
                      <a href={term.source.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-[12.5px] text-accent underline decoration-1 underline-offset-4 hover:decoration-2">
                        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3 no-underline">Source</span>
                        {term.source.title} <ArrowSquareOut size={12} aria-hidden />
                        <span className="sr-only">(nouvel onglet)</span>
                      </a>
                    </div>
                  ) : null}
                </motion.article>
              ) : (
                <motion.div key="vide" initial={false} className="border border-dashed border-line-strong px-8 py-16 text-center">
                  <p className="font-display text-[15px] font-light uppercase tracking-[0.06em] text-ink">Choisissez un terme</p>
                  <p className="mx-auto mt-2 max-w-[40ch] text-[13px] text-ink-2">Sa fiche s&apos;affiche ici : définition simple, analogie, exemple et leçons où il apparaît.</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "inline-flex h-8 shrink-0 items-center gap-1.5 whitespace-nowrap border px-3 font-mono text-[10px] uppercase tracking-[0.14em] transition-colors duration-300",
        active ? "border-ink bg-ink text-bg" : "border-line-strong text-ink-2 hover:border-ink hover:text-ink",
      )}
    >
      {children}
    </button>
  );
}
