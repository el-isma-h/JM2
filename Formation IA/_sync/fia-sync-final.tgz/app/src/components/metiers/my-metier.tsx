"use client";

/**
 * « Mon métier » (v1.4) : bouton de la page d'un parcours et choix exclusif du profil.
 * Enregistré par setMyMetierAction ; le tableau de bord affiche ensuite la carte « Votre parcours métier ».
 */
import * as React from "react";
import { useRouter } from "next/navigation";
import { motion, useReducedMotion } from "motion/react";
import { Briefcase, Check, X } from "@phosphor-icons/react";
import { setMyMetierAction } from "@/server/actions/metiers";
import { toast } from "@/components/feedback/toaster";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function useSetMetier() {
  const router = useRouter();
  const [pending, start] = React.useTransition();
  const save = (slug: string | null, label: string, onFail?: () => void) =>
    start(async () => {
      const r = await setMyMetierAction(slug);
      if (!r.ok) {
        onFail?.();
        toast({ kind: "error", title: r.error ?? "Choix non enregistré." });
        return;
      }
      toast({ title: slug ? `Mon métier : ${label}` : "Métier retiré du profil" });
      router.refresh();
    });
  return { pending, save };
}

/** Bouton de la page d'un parcours : « Choisir comme mon métier » / « Mon métier » (retirer). */
export function MyMetierButton({ slug, title, selected }: { slug: string; title: string; selected: boolean }) {
  const { pending, save } = useSetMetier();
  if (selected) {
    return (
      <div className="flex items-center gap-2">
        <span className="inline-flex h-8 items-center gap-1.5 border border-accent bg-accent-soft px-3 font-mono text-[10px] uppercase tracking-[0.18em] text-accent">
          <Check size={12} weight="bold" aria-hidden /> Mon métier
        </span>
        <Button variant="ghost" size="sm" onClick={() => save(null, title)} loading={pending} aria-label="Retirer ce métier de mon profil">
          <X size={12} aria-hidden /> Retirer
        </Button>
      </div>
    );
  }
  return (
    <Button variant="secondary" size="sm" onClick={() => save(slug, title)} loading={pending}>
      <Briefcase size={13} aria-hidden /> Choisir comme mon métier
    </Button>
  );
}

/** Choix exclusif du profil (radiogroup natif : flèches du clavier). */
export function MetierChoice({ value, options }: { value: string | null; options: { slug: string; title: string; duration: string }[] }) {
  const reduce = useReducedMotion();
  const [current, setCurrent] = React.useState<string>(value ?? "");
  const { pending, save } = useSetMetier();
  const all = [...options.map((o) => ({ value: o.slug, label: o.title, detail: o.duration ? `${o.duration} prioritaires` : "" })), { value: "", label: "Aucun", detail: "Pas de carte métier" }];
  const onChange = (v: string) => {
    const prev = current;
    setCurrent(v);
    save(v || null, all.find((o) => o.value === v)?.label ?? v, () => setCurrent(prev));
  };
  return (
    <fieldset aria-busy={pending}>
      <legend className="sr-only">Mon métier</legend>
      <div className="grid grid-cols-1 gap-px border border-line bg-line min-[420px]:grid-cols-2 xl:grid-cols-3">
        {all.map((o) => {
          const on = o.value === current;
          return (
            <label
              key={o.value || "none"}
              className={cn(
                // « Aucun » (dernier choix) complète la dernière ligne de la grille.
                !o.value && "min-[420px]:col-span-2",
                "relative flex cursor-pointer flex-col gap-1 p-4 transition-colors duration-300 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-focus",
                on ? "bg-bg" : "bg-bg-elev hover:bg-bg-sunken",
              )}
            >
              <input type="radio" name="metier" value={o.value} checked={on} onChange={() => onChange(o.value)} className="sr-only" />
              {on ? <motion.span layoutId="seg-metier" className="absolute inset-x-0 top-0 h-[2px] bg-accent" transition={reduce ? { duration: 0 } : { type: "spring", stiffness: 500, damping: 40 }} /> : null}
              <span className={cn("flex items-center gap-2 text-[13px]", on ? "text-ink" : "text-ink-2")}>
                {o.label}
                {on ? <Check size={13} weight="bold" className="ml-auto shrink-0 text-accent" aria-hidden /> : null}
              </span>
              {o.detail ? <span className="num text-[11px] text-ink-3">{o.detail}</span> : null}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
