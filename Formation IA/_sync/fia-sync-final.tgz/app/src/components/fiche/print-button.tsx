"use client";

import { Printer } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/** « Imprimer / PDF » : ouvre la boîte d'impression du navigateur (« Enregistrer en PDF » y est proposé). */
export function PrintButton({ className, size = "sm" }: { className?: string; size?: "sm" | "md" | "lg" }) {
  return (
    <Button type="button" variant="primary" size={size} className={cn("print:hidden", className)} onClick={() => window.print()}>
      <Printer size={15} aria-hidden /> Imprimer / PDF
    </Button>
  );
}
