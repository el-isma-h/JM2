/**
 * Gabarit serveur d'une page d'outil du Labo : en-tête, encadré « 🧭 En clair », l'outil (client), leçons liées.
 */
import Link from "next/link";
import { ArrowUpRight, LockSimple } from "@phosphor-icons/react/ssr";
import { PageHeader } from "@/components/ui/surface";
import { routes } from "@/lib/paths";
import type { LaboTool } from "@/domain/labo/tools";

export type LessonRef = { id: string; title: string; accessible: boolean };

export function ToolFrame({ tool, enClair, lessons, children }: { tool: LaboTool; enClair: React.ReactNode; lessons: LessonRef[]; children: React.ReactNode }) {
  return (
    <div>
      <PageHeader title={tool.title} description={tool.summary} breadcrumb={[{ label: "Labo", href: routes.labo }, { label: tool.title }]} />
      <aside className="mb-8 max-w-[78ch] border-s-2 border-accent bg-accent-soft px-4 py-3 text-[14px] leading-relaxed text-ink" aria-label="En clair">
        <p className="mb-1 font-medium">🧭 En clair</p>
        {enClair}
      </aside>
      {children}
      <section aria-labelledby="lecons-liees" className="mt-10 border-t border-line pt-6">
        <h2 id="lecons-liees" className="text-[13px] text-ink">
          Leçons liées
        </h2>
        <ul className="mt-4 grid border-l border-t border-line sm:grid-cols-2 lg:grid-cols-3">
          {lessons.map((l) => (
            <li key={l.id} className="border-b border-r border-line bg-bg-elev">
              {l.accessible ? (
                <Link href={routes.lesson(l.id)} className="group flex h-full items-start justify-between gap-3 px-4 py-3 transition-colors duration-300 hover:bg-bg-sunken">
                  <span className="min-w-0">
                    <span className="num block text-[11px] text-accent">{l.id}</span>
                    <span className="mt-0.5 block text-[13.5px] text-ink">{l.title}</span>
                  </span>
                  <ArrowUpRight size={14} className="mt-1 shrink-0 text-ink-3 transition-colors group-hover:text-ink" aria-hidden />
                </Link>
              ) : (
                <div className="flex h-full items-start justify-between gap-3 px-4 py-3" title="Leçon pas encore débloquée dans votre parcours">
                  <span className="min-w-0">
                    <span className="num block text-[11px] text-ink-3">{l.id}</span>
                    <span className="mt-0.5 block text-[13.5px] text-ink-2">{l.title}</span>
                  </span>
                  <LockSimple size={14} className="mt-1 shrink-0 text-ink-3" aria-label="Verrouillée" />
                </div>
              )}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
