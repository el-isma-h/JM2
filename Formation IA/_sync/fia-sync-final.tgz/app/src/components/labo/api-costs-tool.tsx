"use client";

import * as React from "react";
import { motion, useReducedMotion } from "motion/react";
import { ArrowSquareOut } from "@phosphor-icons/react";
import { DEFAULT_SCENARIO, PRICING_DATE, PROVIDER_PRICING_URL, compareCosts, formatUsd, type Provider, type Scenario } from "@/domain/labo/api-costs";
import { Notice } from "@/components/ui/surface";
import { Challenge, NumberField, Range, Segmented, ToggleRow, useLaboUse } from "./controls";
import { cn } from "@/lib/utils";

const PROVIDERS: Provider[] = ["Anthropic", "OpenAI", "xAI", "Google", "Mistral"];
const nf = (n: number) => n.toLocaleString("fr-FR");

export function ApiCostsTool() {
  const reduce = useReducedMotion();
  const markUsed = useLaboUse("couts-api");
  const [s, setS] = React.useState<Scenario>(DEFAULT_SCENARIO);
  const [useCache, setUseCache] = React.useState(false);
  const [cached, setCached] = React.useState(600);
  const [filter, setFilter] = React.useState<Provider | "all">("all");
  const scenario: Scenario = { ...s, cachedTokens: useCache ? Math.min(cached, s.inputTokens) : 0 };
  const rows = compareCosts(scenario).filter((r) => filter === "all" || r.tariff.provider === filter);
  const set = (patch: Partial<Scenario>) => {
    markUsed();
    setS((p) => ({ ...p, ...patch }));
  };
  // Échelle logarithmique : de 0,01 $ au plus cher, pour lire ensemble Haiku et GPT-6 Astra (facteur 100).
  const max = Math.max(...compareCosts(scenario).map((r) => r.monthly), 0.02);
  const logw = (v: number) => (v <= 0.01 ? 2 : Math.max(2, (Math.log10(v / 0.01) / Math.log10(max / 0.01)) * 100));
  const cheapest = rows[0];
  const calls = s.requestsPerDay * s.daysPerMonth;

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-8">
      <div className="grid grid-cols-[minmax(0,1fr)] gap-6 lg:items-start lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <div className="grid content-start gap-5 border border-line bg-bg-elev p-5">
          <div className="grid grid-cols-2 gap-3">
            <NumberField id="api-in" label="Entrée / requête" suffix="tokens" value={s.inputTokens} max={2_000_000} onChange={(v) => set({ inputTokens: Math.round(v) })} />
            <NumberField id="api-out" label="Sortie / requête" suffix="tokens" value={s.outputTokens} max={200_000} onChange={(v) => set({ outputTokens: Math.round(v) })} />
          </div>
          <Range
            id="api-rpd"
            label="Requêtes par jour"
            value={Math.round(Math.log10(Math.max(1, s.requestsPerDay)) * 20)}
            min={0}
            max={100}
            onChange={(v) => set({ requestsPerDay: Math.max(1, Math.round(10 ** (v / 20))) })}
            display={nf(s.requestsPerDay)}
            valueText={`${s.requestsPerDay} requêtes par jour`}
          />
          <Segmented
            label="Jours facturés par mois"
            value={s.daysPerMonth}
            options={[
              { value: 22, label: "22 j ouvrés" },
              { value: 30, label: "30 j" },
            ]}
            onChange={(v) => set({ daysPerMonth: v })}
          />
          <ToggleRow
            id="api-cache"
            label="Prompt caching"
            hint="Le préfixe stable (prompt système, documents) est relu depuis le cache à prix réduit."
            checked={useCache}
            onChange={(v) => {
              markUsed();
              setUseCache(v);
            }}
          />
          {useCache ? (
            <div className="grid gap-4 border-s-2 border-accent ps-4">
              <Range
                id="api-cached"
                label="Tokens mis en cache"
                value={Math.min(cached, s.inputTokens)}
                min={0}
                max={Math.max(1, s.inputTokens)}
                step={Math.max(1, Math.round(s.inputTokens / 100))}
                onChange={(v) => {
                  markUsed();
                  setCached(v);
                }}
                display={`${nf(Math.min(cached, s.inputTokens))} sur ${nf(s.inputTokens)}`}
              />
              <Range id="api-writes" label="Réécritures du cache par jour" value={s.cacheWritesPerDay} min={0} max={200} onChange={(v) => set({ cacheWritesPerDay: v })} hint="Expiration du cache (pauses, nuit) : la leçon L067 en compte une vingtaine par jour." />
            </div>
          ) : null}
          <ToggleRow id="api-batch" label="Traitement par lots (batch)" hint="Réponse différée (jusqu'à 24 h), −50 % chez la plupart des fournisseurs, −20 % chez xAI." checked={s.batch} onChange={(v) => set({ batch: v })} />
          <p className="border-t border-line pt-3 text-[12.5px] text-ink-2">
            <span className="num text-ink">{nf(calls)}</span> requêtes par mois.
          </p>
        </div>

        <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] content-start gap-4">
          <div className="border border-line bg-bg-elev">
            <div className="flex flex-wrap items-end justify-between gap-3 border-b border-line px-5 py-4">
              <div>
                <h2 className="text-[13px] text-ink">Coût mensuel estimé</h2>
                <p className="mt-1 text-[12px] text-ink-3">Tarifs standard en dollars, pages officielles lues le {PRICING_DATE}. Barres en échelle logarithmique.</p>
              </div>
              <Segmented
                label="Fournisseur"
                value={filter}
                columns={3}
                options={[{ value: "all" as const, label: "Tous" }, ...PROVIDERS.map((p) => ({ value: p, label: p }))]}
                onChange={(v) => {
                  markUsed();
                  setFilter(v);
                }}
                className="w-full sm:w-[300px]"
              />
            </div>
            <ul className="divide-y divide-line">
              {rows.map((r) => (
                <li key={r.tariff.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-4 gap-y-1 px-5 py-2.5 sm:grid-cols-[10.5rem_minmax(0,1fr)_7rem]">
                  <div className="min-w-0">
                    <p className="truncate text-[13.5px] text-ink">{r.tariff.label}</p>
                    <p className="truncate text-[11px] text-ink-3">
                      {r.tariff.provider} · {formatUsd(r.perCall)} / requête
                    </p>
                  </div>
                  <div className="order-3 col-span-2 h-2 bg-bg-sunken sm:order-none sm:col-span-1" aria-hidden>
                    <motion.div
                      className={cn("h-full", r === cheapest ? "bg-accent" : "bg-ink")}
                      initial={false}
                      animate={{ width: `${logw(r.monthly)}%` }}
                      transition={reduce ? { duration: 0 } : { duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                    />
                  </div>
                  <div className="text-right">
                    <p className="num text-[15px] text-ink">{formatUsd(r.monthly)}</p>
                    {r.savingsPercent > 0.5 ? <p className="num text-[11px] text-ok-ink">−{Math.round(r.savingsPercent)} %</p> : null}
                  </div>
                  {r.tariff.note ? <p className="order-4 col-span-2 text-[11px] text-ink-3 sm:col-span-3">{r.tariff.note}</p> : null}
                </li>
              ))}
            </ul>
          </div>
          <div className="border border-line bg-bg-elev px-5 py-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Pages officielles des tarifs</p>
            <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-1.5 text-[13px]">
              {PROVIDERS.map((p) => (
                <li key={p}>
                  <a href={PROVIDER_PRICING_URL[p]} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-accent underline-offset-4 hover:underline">
                    {p} <ArrowSquareOut size={12} aria-hidden />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <Notice tone="warn" title="Tarifs de novembre 2026">
        Les prix changent souvent (Gemini 4 Argon double au 1er décembre 2026) : datez vos estimations et vérifiez la page du fournisseur avant de vous engager. Hypothèses de la leçon L067 conservées : écriture de cache xAI au tarif d&apos;entrée, batch Mistral à 0,5, cache Google à 0,1 ×. Le même texte ne compte pas le même nombre de tokens chez deux fournisseurs.
      </Notice>

      <Challenge
        prompt="Scénario Chauffage Martin de la leçon L067 : 300 e-mails par jour, 900 tokens d'entrée et 120 de sortie, 22 jours. Combien coûte Claude Sonnet 5.5 par mois, sans cache ni batch ?"
        options={["Environ 1 $", "Environ 7 $", "Environ 20 $", "Environ 100 $"]}
        answer={2}
        onAnswer={markUsed}
        explanation={<p>0,003 $ par appel × 300 × 22 = 19,80 $. Avec le cache sur les 600 tokens du prompt système, on descend à 12,94 $ ; avec Haiku 5.5, à moins d&apos;un dollar.</p>}
      />
    </div>
  );
}
