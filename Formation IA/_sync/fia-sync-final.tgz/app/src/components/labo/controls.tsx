"use client";

/**
 * Commandes partagées des outils du Labo : curseur, sélecteur segmenté, champ numérique, interrupteur libellé,
 * suivi d'utilisation (badge « Laborantin ») et mini-défi. Identité Next Formation : angles droits, filets 1 px,
 * étiquettes mono, accent violet unique.
 */
import * as React from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { CheckCircle, XCircle, Target } from "@phosphor-icons/react";
import { Switch } from "@/components/ui/switch";
import { announceRewards } from "@/components/feedback/toaster";
import { markLaboToolUsedAction } from "@/server/actions/labo";
import type { LaboToolId } from "@/domain/labo/tools";
import { cn } from "@/lib/utils";

/** Note l'utilisation de l'outil (une seule fois par chargement) au premier geste de l'apprenant. */
export function useLaboUse(toolId: LaboToolId): () => void {
  const done = React.useRef(false);
  return React.useCallback(() => {
    if (done.current) return;
    done.current = true;
    void markLaboToolUsedAction(toolId)
      .then((r) => {
        if (r.ok && r.rewards.badges.length) announceRewards(r.rewards);
      })
      .catch(() => {
        done.current = false;
      });
  }, [toolId]);
}

export function FieldLabel({ htmlFor, children, value, id }: { htmlFor?: string; id?: string; children: React.ReactNode; value?: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <label htmlFor={htmlFor} id={id} className="font-mono text-[10px] font-medium uppercase tracking-[0.2em] text-ink-3">
        {children}
      </label>
      {value !== undefined ? <span className="num text-[13px] text-ink">{value}</span> : null}
    </div>
  );
}

export function Range({
  id,
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  display,
  valueText,
  hint,
}: {
  id: string;
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  display?: React.ReactNode;
  /** Valeur lue par les lecteurs d'écran. */
  valueText?: string;
  hint?: React.ReactNode;
}) {
  const fill = max > min ? ((value - min) / (max - min)) * 100 : 0;
  return (
    <div className="grid gap-1">
      <FieldLabel htmlFor={id} value={display ?? value}>
        {label}
      </FieldLabel>
      <input
        id={id}
        type="range"
        className="labo-range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-valuetext={valueText}
        style={{ "--fill": `${fill}%` } as React.CSSProperties}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      {hint ? <p className="text-[12px] text-ink-3">{hint}</p> : null}
    </div>
  );
}

export function Segmented<T extends string | number>({
  label,
  value,
  options,
  onChange,
  className,
  columns,
}: {
  label: string;
  value: T;
  options: { value: T; label: React.ReactNode; title?: string }[];
  onChange: (v: T) => void;
  className?: string;
  columns?: number;
}) {
  const id = React.useId();
  const refs = React.useRef<(HTMLButtonElement | null)[]>([]);
  const index = options.findIndex((o) => o.value === value);
  const move = (delta: number) => {
    const next = (index + delta + options.length) % options.length;
    onChange(options[next].value);
    refs.current[next]?.focus();
  };
  return (
    <div className={cn("grid gap-1.5", className)}>
      <FieldLabel id={id}>{label}</FieldLabel>
      <div
        role="radiogroup"
        aria-labelledby={id}
        className="grid border border-line"
        style={{ gridTemplateColumns: `repeat(${columns ?? options.length}, minmax(0, 1fr))` }}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight" || e.key === "ArrowDown") {
            e.preventDefault();
            move(1);
          } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
            e.preventDefault();
            move(-1);
          }
        }}
      >
        {options.map((o, i) => {
          const active = o.value === value;
          return (
            <button
              key={String(o.value)}
              ref={(el) => {
                refs.current[i] = el;
              }}
              type="button"
              role="radio"
              aria-checked={active}
              tabIndex={active || (index === -1 && i === 0) ? 0 : -1}
              title={o.title}
              onClick={() => onChange(o.value)}
              className={cn(
                "relative -ml-px -mt-px min-h-9 border-l border-t border-line px-2 py-1.5 font-mono text-[11px] tracking-[0.04em] transition-colors duration-300",
                active ? "bg-ink text-bg" : "bg-bg-elev text-ink-2 hover:bg-bg-sunken hover:text-ink",
              )}
            >
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function NumberField({
  id,
  label,
  value,
  onChange,
  min = 0,
  max,
  step = 1,
  suffix,
}: {
  id: string;
  label: string;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
}) {
  // Brouillon uniquement pendant la saisie ; sinon la valeur fait foi.
  const [draft, setDraft] = React.useState<string | null>(null);
  return (
    <div className="grid gap-1.5">
      <FieldLabel htmlFor={id}>{label}</FieldLabel>
      <div className="flex items-center border border-line-strong bg-bg-elev focus-within:border-accent">
        <input
          id={id}
          inputMode="numeric"
          className="num h-10 w-full min-w-0 bg-transparent px-3 text-[14px] text-ink outline-none"
          value={draft ?? String(value)}
          onFocus={() => setDraft(String(value))}
          onChange={(e) => {
            setDraft(e.target.value);
            const n = Number(e.target.value.replace(/\s/g, "").replace(",", "."));
            if (Number.isFinite(n)) onChange(Math.max(min, max !== undefined ? Math.min(max, n) : n));
          }}
          onBlur={() => setDraft(null)}
          step={step}
        />
        {suffix ? <span className="shrink-0 pe-3 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">{suffix}</span> : null}
      </div>
    </div>
  );
}

export function ToggleRow({ id, label, hint, checked, onChange }: { id: string; label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-start justify-between gap-4 border border-line bg-bg-elev px-3 py-2.5">
      <div className="min-w-0">
        <label htmlFor={id} className="text-[13.5px] text-ink">
          {label}
        </label>
        {hint ? <p className="mt-0.5 text-[12px] text-ink-3">{hint}</p> : null}
      </div>
      <Switch id={id} checked={checked} onCheckedChange={onChange} className="mt-0.5" />
    </div>
  );
}

/** Mini-défi : une question dont la réponse se trouve avec l'outil. */
export function Challenge({
  prompt,
  options,
  answer,
  explanation,
  onAnswer,
}: {
  prompt: React.ReactNode;
  options: string[];
  answer: number;
  explanation: React.ReactNode;
  onAnswer?: () => void;
}) {
  const reduce = useReducedMotion();
  const [choice, setChoice] = React.useState<number | null>(null);
  const correct = choice === answer;
  return (
    <section aria-labelledby="defi-titre" className="border border-line bg-bg-elev">
      <div className="flex items-center gap-2 border-b border-line px-5 py-3">
        <Target size={16} className="text-accent" aria-hidden />
        <h2 id="defi-titre" className="text-[13px] text-ink">
          Mini-défi
        </h2>
      </div>
      <div className="px-5 py-4">
        <p className="max-w-[68ch] text-[14px] text-ink">{prompt}</p>
        <div className="mt-4 grid gap-2 sm:grid-cols-2" role="group" aria-label="Réponses possibles">
          {options.map((o, i) => {
            const picked = choice === i;
            const showRight = choice !== null && i === answer;
            return (
              <button
                key={o}
                type="button"
                aria-pressed={picked}
                disabled={choice !== null && correct}
                onClick={() => {
                  setChoice(i);
                  onAnswer?.();
                }}
                className={cn(
                  "flex items-center justify-between gap-3 border px-3 py-2.5 text-left text-[13.5px] transition-colors duration-300",
                  showRight ? "border-ok/60 bg-ok-soft text-ink" : picked ? "border-danger/60 bg-danger-soft text-ink" : "border-line-strong text-ink-2 hover:border-ink hover:text-ink",
                )}
              >
                <span>{o}</span>
                {showRight ? <CheckCircle size={16} weight="fill" className="shrink-0 text-ok-ink" aria-hidden /> : picked ? <XCircle size={16} weight="fill" className="shrink-0 text-danger-ink" aria-hidden /> : null}
              </button>
            );
          })}
        </div>
        <AnimatePresence initial={false}>
          {choice !== null ? (
            <motion.div
              key={correct ? "ok" : `ko-${choice}`}
              initial={reduce ? false : { opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reduce ? undefined : { opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="mt-4 border-s-2 border-line-strong ps-3 text-[13.5px] text-ink-2"
              role="status"
            >
              <p className={cn("font-medium", correct ? "text-ok-ink" : "text-danger-ink")}>{correct ? "Bien vu." : "Pas tout à fait. Réessayez avec l'outil."}</p>
              {correct ? <div className="mt-1">{explanation}</div> : null}
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>
    </section>
  );
}

/** Lecture principale d'un outil : grand nombre Archivo fin + unité + légende. */
export function Readout({ value, unit, caption, className, size = "lg" }: { value: React.ReactNode; unit?: string; caption?: React.ReactNode; className?: string; size?: "lg" | "md" }) {
  return (
    <div className={cn("min-w-0", className)}>
      <p className={cn("font-display font-light leading-none tracking-[0.01em] text-ink", size === "lg" ? "text-[56px] sm:text-[72px]" : "text-[34px] sm:text-[40px]")}>
        <span className="tabular-nums">{value}</span>
        {unit ? <span className={cn("ms-2 font-mono uppercase tracking-[0.14em] text-ink-3", size === "lg" ? "text-[13px]" : "text-[11px]")}>{unit}</span> : null}
      </p>
      {caption ? <p className="mt-2 text-[12.5px] text-ink-2">{caption}</p> : null}
    </div>
  );
}
