"use client";

import * as React from "react";
import { LANGUAGE_PAIRS, TOKENIZER_MODELS, TOKENS_PER_WORD, inputCostUsd, tokenStats, tokenize, type Token } from "@/domain/labo/tokenizer";
import { formatUsd } from "@/domain/labo/api-costs";
import { Notice } from "@/components/ui/surface";
import { Challenge, FieldLabel, Readout, Segmented, useLaboUse } from "./controls";
import { cn } from "@/lib/utils";

const DEFAULT_TEXT = "Bonjour, ma chaudière gaz de 2009 fait un bruit de claquement au démarrage, pouvez-vous passer cette semaine ?";
const FILLS = ["bg-accent-soft", "bg-bg-muted", "bg-info-soft"];
const nf = (n: number, d = 0) => n.toLocaleString("fr-FR", { maximumFractionDigits: d, minimumFractionDigits: d });

function TokenStrip({ tokens, label, max = 400 }: { tokens: Token[]; label: string; max?: number }) {
  const shown = tokens.slice(0, max);
  return (
    <div>
      <p className="sr-only">{label}</p>
      <div className="flex flex-wrap gap-y-1.5 font-mono text-[13px] leading-6 text-ink" aria-hidden>
        {shown.map((t, i) =>
          t.kind === "space" ? (
            t.text.includes("\n") ? <span key={i} className="basis-full" /> : <span key={i}>&nbsp;</span>
          ) : (
            <span
              key={i}
              className={cn("whitespace-pre border-b px-[1px]", FILLS[i % FILLS.length], t.kind === "piece" ? "border-accent" : "border-transparent")}
              title={JSON.stringify(t.text)}
            >
              {t.text.replace(/ /g, "·")}
            </span>
          ),
        )}
        {tokens.length > max ? <span className="ms-2 text-ink-3">… {nf(tokens.length - max)} de plus</span> : null}
      </div>
    </div>
  );
}

export function TokenizerTool() {
  const markUsed = useLaboUse("tokeniseur");
  const [text, setText] = React.useState(DEFAULT_TEXT);
  const [langMode, setLangMode] = React.useState<"auto" | "fr" | "en">("auto");
  const [pairId, setPairId] = React.useState<string>(LANGUAGE_PAIRS[1].id);
  const deferred = React.useDeferredValue(text);
  const tokens = React.useMemo(() => tokenize(deferred), [deferred]);
  const stats = React.useMemo(() => tokenStats(deferred, langMode === "auto" ? undefined : langMode), [deferred, langMode]);
  const pair = LANGUAGE_PAIRS.find((p) => p.id === pairId)!;
  const fr = tokenStats(pair.fr, "fr");
  const en = tokenStats(pair.en, "en");

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-8">
      <div className="grid grid-cols-[minmax(0,1fr)] gap-6 lg:items-start lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        <div className="grid content-start gap-4 border border-line bg-bg-elev p-5">
          <div className="grid gap-1.5">
            <FieldLabel htmlFor="tok-text">Votre texte</FieldLabel>
            <textarea
              id="tok-text"
              rows={5}
              value={text}
              onChange={(e) => {
                markUsed();
                setText(e.target.value);
              }}
              className="w-full resize-y border border-line-strong bg-bg px-3 py-2.5 text-[14px] leading-relaxed text-ink outline-none focus:border-accent"
              maxLength={20000}
            />
          </div>
          <div>
            <p className="mb-2 font-mono text-[10px] font-medium uppercase tracking-[0.2em] text-ink-3">Découpe pédagogique</p>
            <div className="max-h-[320px] overflow-y-auto border border-line bg-bg px-3 py-3 scrollbar-thin" aria-live="polite">
              {tokens.length ? <TokenStrip tokens={tokens} label={`${stats.tokens} tokens`} /> : <p className="text-[13px] text-ink-3">Tapez ou collez un texte pour le voir découpé.</p>}
            </div>
            <p className="mt-2 text-[12px] text-ink-3">
              Un bloc de couleur = un token. Les espaces sont collés au mot qui suit (·). Souligné : mot coupé en plusieurs morceaux.
            </p>
          </div>
        </div>

        <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] content-start gap-4">
          <div className="border border-line bg-bg-elev p-5">
            <Readout value={nf(stats.tokens)} unit="tokens" caption="Selon la découpe pédagogique (pas celle d'un fournisseur)." />
            <dl className="mt-5 grid grid-cols-3 gap-4 border-t border-line pt-4 text-[13px]">
              <div>
                <dt className="text-ink-3">Mots</dt>
                <dd className="num mt-0.5 text-[18px] text-ink">{nf(stats.words)}</dd>
              </div>
              <div>
                <dt className="text-ink-3">Caractères</dt>
                <dd className="num mt-0.5 text-[18px] text-ink">{nf(stats.chars)}</dd>
              </div>
              <div>
                <dt className="text-ink-3">Tokens / mot</dt>
                <dd className="num mt-0.5 text-[18px] text-ink">{nf(stats.tokensPerWord, 2)}</dd>
              </div>
            </dl>
          </div>
          <div className="border border-line bg-bg-elev p-5">
            <Segmented
              label="Langue du texte"
              value={langMode}
              options={[
                { value: "auto", label: `Auto (${stats.lang === "fr" ? "FR" : "EN"})` },
                { value: "fr", label: "Français" },
                { value: "en", label: "Anglais" },
              ]}
              onChange={(v) => {
                markUsed();
                setLangMode(v);
              }}
            />
            <p className="mt-4 text-[13px] text-ink-2">
              Estimation Claude (règle L067 : {nf(TOKENS_PER_WORD[stats.lang], 1)} token par mot {stats.lang === "fr" ? "français" : "anglais"}) :{" "}
              <span className="num text-ink">{nf(stats.claudeEstimate)} tokens</span>
            </p>
            <table className="data-table mt-3 text-[13px]">
              <thead>
                <tr>
                  <th>Envoyer ce texte</th>
                  <th className="num">1 fois</th>
                  <th className="num">1 000 fois</th>
                </tr>
              </thead>
              <tbody>
                {TOKENIZER_MODELS.map((m) => (
                  <tr key={m.id}>
                    <td>
                      {m.label}
                      <span className="block text-[11px] text-ink-3">{nf(m.inputPerMTok, 2)} $ / M tokens d&apos;entrée</span>
                    </td>
                    <td className="num">{formatUsd(inputCostUsd(stats.claudeEstimate, m.inputPerMTok))}</td>
                    <td className="num">{formatUsd(inputCostUsd(stats.claudeEstimate * 1000, m.inputPerMTok))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-2 text-[11.5px] text-ink-3">Tarifs d&apos;entrée des pages officielles lues le 1er novembre 2026 (leçon L067). La réponse du modèle (sortie) se paie en plus.</p>
          </div>
        </div>
      </div>

      <section aria-labelledby="fr-en" className="border border-line bg-bg-elev">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-line px-5 py-4">
          <div>
            <h2 id="fr-en" className="text-[13px] text-ink">
              Français contre anglais
            </h2>
            <p className="mt-1 text-[13px] text-ink-2">La même phrase, dans les deux langues : laquelle pèse le plus ?</p>
          </div>
          <Segmented
            label="Exemple"
            value={pairId}
            options={LANGUAGE_PAIRS.map((p, i) => ({ value: p.id, label: `Phrase ${i + 1}` }))}
            onChange={(v) => {
              markUsed();
              setPairId(v);
            }}
            className="w-full sm:w-auto sm:min-w-[300px]"
          />
        </div>
        <div className="grid divide-y divide-line md:grid-cols-2 md:divide-x md:divide-y-0">
          {[
            { lang: "Français", s: fr, txt: pair.fr },
            { lang: "Anglais", s: en, txt: pair.en },
          ].map(({ lang, s, txt }) => (
            <div key={lang} className="p-5">
              <div className="flex items-baseline justify-between gap-3">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">{lang}</p>
                <p className="num text-[12.5px] text-ink-2">
                  {nf(s.tokens)} tokens · {nf(s.words)} mots · Claude ≈ {nf(s.claudeEstimate)}
                </p>
              </div>
              <div className="mt-3">
                <TokenStrip tokens={tokenize(txt)} label={`${lang} : ${s.tokens} tokens`} />
              </div>
            </div>
          ))}
        </div>
        <p className="border-t border-line px-5 py-3 text-[13px] text-ink-2">
          Ici, le français demande <span className="num text-ink">{nf(fr.claudeEstimate / Math.max(1, en.claudeEstimate), 2)} ×</span> plus de tokens que l&apos;anglais (règle L067). Les leçons retiennent 1,3 à 1,5 × en moyenne.
        </p>
      </section>

      <Notice tone="info" title="Une découpe pédagogique">
        Chaque fournisseur a son propre tokenizer : le même e-mail peut valoir 280 tokens chez l&apos;un et 320 chez l&apos;autre. Pour un chiffre exact, utilisez <code className="font-mono">count_tokens</code> chez Anthropic ou <code className="font-mono">tiktoken</code> chez OpenAI (leçon L067).
      </Notice>

      <Challenge
        prompt="Votre prompt système fait 1 000 mots en français. Combien de tokens d'entrée faut-il prévoir avec le tokenizer Claude, d'après la règle de la leçon L067 ?"
        options={["Environ 750", "Environ 1 300", "Environ 1 800", "Environ 2 500"]}
        answer={3}
        onAnswer={markUsed}
        explanation={<p>≈ 2,5 tokens par mot français : 1 000 mots ≈ 2 500 tokens. En anglais, la même consigne ferait plutôt 1 800 tokens.</p>}
      />
    </div>
  );
}
