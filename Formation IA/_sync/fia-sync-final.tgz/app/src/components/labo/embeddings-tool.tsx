"use client";

import * as React from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ArrowCounterClockwise, CheckCircle, Plus, XCircle } from "@phosphor-icons/react";
import { AXIS_X, AXIS_Y, GRID_MAX, L047_PHRASES, angleDeg, cosine, formatCos, isNearestGuess, rankNeighbours, snap, type Phrase } from "@/domain/labo/embeddings";
import { Button } from "@/components/ui/button";
import { Challenge, FieldLabel, Readout, useLaboUse } from "./controls";
import { cn } from "@/lib/utils";

/** Repère SVG : 0-10 → 8-92 (marges pour les libellés). */
const PAD = 8;
const SPAN = 100 - 2 * PAD;
const sx = (x: number) => PAD + (x / GRID_MAX) * SPAN;
const sy = (y: number) => 100 - PAD - (y / GRID_MAX) * SPAN;
const short = (s: string) => (s.length > 24 ? `${s.slice(0, 22).trimEnd()}…` : s);
const coord = (v: number) => v.toLocaleString("fr-FR", { maximumFractionDigits: 1 });

export function EmbeddingsTool() {
  const reduce = useReducedMotion();
  const markUsed = useLaboUse("embeddings");
  const [phrases, setPhrases] = React.useState<Phrase[]>(L047_PHRASES);
  const [a, setA] = React.useState("enfant");
  const [b, setB] = React.useState("vacances");
  const [drag, setDrag] = React.useState<string | null>(null);
  const [draft, setDraft] = React.useState("");
  const svgRef = React.useRef<SVGSVGElement>(null);
  const pa = phrases.find((p) => p.id === a) ?? phrases[0];
  const pb = phrases.find((p) => p.id === b) ?? phrases[1];
  const cos = cosine(pa, pb);

  const move = (id: string, x: number, y: number) => {
    markUsed();
    setPhrases((list) => list.map((p) => (p.id === id ? { ...p, x: snap(x), y: snap(y) } : p)));
  };
  const select = (id: string) => {
    markUsed();
    if (id === a) return;
    setB(a);
    setA(id);
  };
  const fromPointer = (e: React.PointerEvent) => {
    const r = svgRef.current!.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * 100;
    const py = ((e.clientY - r.top) / r.height) * 100;
    return { x: ((px - PAD) / SPAN) * GRID_MAX, y: ((100 - PAD - py) / SPAN) * GRID_MAX };
  };

  // Mini-jeu « trouve la phrase la plus proche »
  const [round, setRound] = React.useState(0);
  const [score, setScore] = React.useState({ ok: 0, total: 0 });
  const [guess, setGuess] = React.useState<{ id: string; ok: boolean } | null>(null);
  const target = phrases[(round * 3 + 2) % phrases.length];
  const ranking = rankNeighbours(target, phrases);

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-8">
      <div className="grid grid-cols-[minmax(0,1fr)] gap-6 lg:items-start lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        <div className="border border-line bg-bg-elev p-3 sm:p-5">
          <svg
            ref={svgRef}
            viewBox="0 0 100 100"
            className="block aspect-square w-full touch-none select-none"
            role="group"
            aria-label={`Carte du sens. Axe horizontal : ${AXIS_X}. Axe vertical : ${AXIS_Y}. Chaque phrase est un point déplaçable.`}
            onPointerMove={(e) => {
              if (!drag) return;
              const p = fromPointer(e);
              move(drag, p.x, p.y);
            }}
            onPointerUp={() => setDrag(null)}
            onPointerLeave={() => setDrag(null)}
          >
            {Array.from({ length: GRID_MAX + 1 }, (_, i) => (
              <g key={i}>
                <line x1={sx(i)} y1={sy(0)} x2={sx(i)} y2={sy(GRID_MAX)} stroke="var(--line)" strokeWidth={0.2} />
                <line x1={sx(0)} y1={sy(i)} x2={sx(GRID_MAX)} y2={sy(i)} stroke="var(--line)" strokeWidth={0.2} />
                {i % 2 === 0 ? (
                  <>
                    <text x={sx(i)} y={sy(0) + 4} fontSize={2.4} textAnchor="middle" fill="var(--ink-3)" className="font-mono">
                      {i}
                    </text>
                    {i > 0 ? (
                      <text x={sx(0) - 2} y={sy(i) + 0.8} fontSize={2.4} textAnchor="end" fill="var(--ink-3)" className="font-mono">
                        {i}
                      </text>
                    ) : null}
                  </>
                ) : null}
              </g>
            ))}
            <line x1={sx(0)} y1={sy(0)} x2={sx(GRID_MAX)} y2={sy(0)} stroke="var(--line-strong)" strokeWidth={0.35} />
            <line x1={sx(0)} y1={sy(0)} x2={sx(0)} y2={sy(GRID_MAX)} stroke="var(--line-strong)" strokeWidth={0.35} />
            <text x={sx(GRID_MAX)} y={98.5} fontSize={2.5} textAnchor="end" fill="var(--ink-2)">
              {AXIS_X} →
            </text>
            <text x={2} y={sy(GRID_MAX) - 3} fontSize={2.5} fill="var(--ink-2)">
              ↑ {AXIS_Y}
            </text>
            {/* Vecteurs A et B depuis l'origine */}
            {[pa, pb].map((p, i) => (
              <motion.line
                key={i === 0 ? "va" : "vb"}
                x1={sx(0)}
                y1={sy(0)}
                initial={false}
                animate={{ x2: sx(p.x), y2: sy(p.y) }}
                transition={reduce || drag ? { duration: 0 } : { type: "spring", stiffness: 300, damping: 30 }}
                stroke={i === 0 ? "var(--accent)" : "var(--ink)"}
                strokeWidth={0.5}
                strokeDasharray={i === 0 ? undefined : "1.2 0.8"}
              />
            ))}
            {phrases.map((p) => {
              const isA = p.id === pa.id;
              const isB = p.id === pb.id;
              const right = p.x > 6.5;
              return (
                <g
                  key={p.id}
                  tabIndex={0}
                  role="button"
                  aria-label={`${p.label}, position ${coord(p.x)} ; ${coord(p.y)}${isA ? ", phrase A" : isB ? ", phrase B" : ""}. Entrée pour choisir, flèches pour déplacer.`}
                  className="cursor-grab outline-none focus-visible:[&>rect]:stroke-[var(--focus)]"
                  onPointerDown={(e) => {
                    (e.currentTarget.ownerSVGElement as SVGSVGElement).setPointerCapture?.(e.pointerId);
                    setDrag(p.id);
                    select(p.id);
                  }}
                  onKeyDown={(e) => {
                    const step = e.shiftKey ? 2 : 0.5;
                    const d: Record<string, [number, number]> = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, step], ArrowDown: [0, -step] };
                    if (d[e.key]) {
                      e.preventDefault();
                      move(p.id, p.x + d[e.key][0], p.y + d[e.key][1]);
                    } else if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      select(p.id);
                    }
                  }}
                >
                  <rect x={sx(p.x) - 4} y={sy(p.y) - 4} width={8} height={8} fill="transparent" stroke="transparent" strokeWidth={0.4} />
                  <rect
                    x={sx(p.x) - 1.3}
                    y={sy(p.y) - 1.3}
                    width={2.6}
                    height={2.6}
                    fill={isA ? "var(--accent)" : isB ? "var(--ink)" : "var(--bg-elev)"}
                    stroke={isA ? "var(--accent)" : "var(--ink)"}
                    strokeWidth={0.35}
                  />
                  <text x={sx(p.x) + (right ? -2.4 : 2.4)} y={sy(p.y) + 0.9} fontSize={2.5} textAnchor={right ? "end" : "start"} fill={isA ? "var(--accent)" : "var(--ink)"} className={cn(isA || isB ? "font-medium" : "")}>
                    {short(p.label)}
                  </text>
                </g>
              );
            })}
          </svg>
          <p className="mt-2 px-1 text-[12px] text-ink-3">Glissez un point à la souris ou au doigt ; au clavier : Tab pour le choisir, flèches pour le déplacer (Maj + flèche : pas de 2).</p>
        </div>

        <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] content-start gap-4">
          <div className="border border-line bg-bg-elev p-5">
            <Readout value={formatCos(cos)} unit="cosinus" caption={cos > 0.9 ? "Même direction : les deux phrases parlent de la même chose." : cos > 0.6 ? "Assez proches." : cos > 0.3 ? "Peu de rapport." : "Presque perpendiculaires : aucun rapport."} />
            <div className="mt-4 grid gap-2 border-t border-line pt-4 text-[13px]">
              <p className="flex gap-2">
                <span className="mt-1 inline-block h-2.5 w-2.5 shrink-0 bg-accent" aria-hidden />
                <span>
                  <span className="text-ink-3">A</span> {pa.label} <span className="num text-ink-3">({coord(pa.x)} ; {coord(pa.y)})</span>
                </span>
              </p>
              <p className="flex gap-2">
                <span className="mt-1 inline-block h-2.5 w-2.5 shrink-0 bg-ink" aria-hidden />
                <span>
                  <span className="text-ink-3">B</span> {pb.label} <span className="num text-ink-3">({coord(pb.x)} ; {coord(pb.y)})</span>
                </span>
              </p>
              <p className="break-words border-t border-line pt-2 font-mono text-[11.5px] text-ink-2">
                ({coord(pa.x)}×{coord(pb.x)} + {coord(pa.y)}×{coord(pb.y)}) ÷ (‖A‖ × ‖B‖) = {formatCos(cos)} · angle {Math.round(angleDeg(pa, pb))}°
              </p>
            </div>
          </div>
          <form
            className="border border-line bg-bg-elev p-5"
            onSubmit={(e) => {
              e.preventDefault();
              const label = draft.trim();
              if (!label || phrases.length >= 12) return;
              markUsed();
              const id = `perso-${Date.now()}`;
              setPhrases((l) => [...l, { id, label, x: 5, y: 5 }]);
              setB(a);
              setA(id);
              setDraft("");
            }}
          >
            <FieldLabel htmlFor="emb-new">Placer votre phrase</FieldLabel>
            <div className="mt-1.5 flex gap-2">
              <input
                id="emb-new"
                value={draft}
                maxLength={60}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="Ex. : Ticket restaurant du mois"
                className="h-10 min-w-0 flex-1 border border-line-strong bg-bg px-3 text-[13.5px] text-ink outline-none focus:border-accent"
              />
              <Button type="submit" variant="secondary" disabled={!draft.trim() || phrases.length >= 12}>
                <Plus size={14} aria-hidden /> Ajouter
              </Button>
            </div>
            <p className="mt-2 text-[12px] text-ink-3">Elle apparaît au centre (5 ; 5) : placez-la là où son sens la range.</p>
            <button
              type="button"
              className="mt-3 inline-flex items-center gap-1.5 text-[12px] text-ink-2 hover:text-ink"
              onClick={() => {
                setPhrases(L047_PHRASES);
                setA("enfant");
                setB("vacances");
              }}
            >
              <ArrowCounterClockwise size={12} aria-hidden /> Revenir à l&apos;exemple de L047
            </button>
          </form>
        </div>
      </div>

      <section aria-labelledby="jeu-proche" className="border border-line bg-bg-elev">
        <div className="flex flex-wrap items-baseline justify-between gap-3 border-b border-line px-5 py-3">
          <h2 id="jeu-proche" className="text-[13px] text-ink">
            Trouve la phrase la plus proche
          </h2>
          <span className="num text-[12.5px] text-ink-2">
            {score.ok} / {score.total}
          </span>
        </div>
        <div className="px-5 py-4">
          <p className="text-[13.5px] text-ink-2">
            D&apos;après la carte (cosinus), quelle phrase est la plus proche de <span className="font-serif text-[18px] italic text-ink">« {target.label} »</span> ?
          </p>
          <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {phrases
              .filter((p) => p.id !== target.id)
              .map((p) => {
                const picked = guess?.id === p.id;
                const right = guess !== null && isNearestGuess(target, p.id, phrases);
                return (
                  <button
                    key={p.id}
                    type="button"
                    disabled={guess !== null}
                    onClick={() => {
                      markUsed();
                      const ok = isNearestGuess(target, p.id, phrases);
                      setGuess({ id: p.id, ok });
                      setScore((s) => ({ ok: s.ok + (ok ? 1 : 0), total: s.total + 1 }));
                    }}
                    className={cn(
                      "flex items-center justify-between gap-2 border px-3 py-2 text-left text-[13px] transition-colors duration-300",
                      right ? "border-ok/60 bg-ok-soft text-ink" : picked ? "border-danger/60 bg-danger-soft text-ink" : "border-line-strong text-ink-2 enabled:hover:border-ink enabled:hover:text-ink",
                    )}
                  >
                    <span>{p.label}</span>
                    {guess ? <span className="num shrink-0 text-[11px] text-ink-3">{formatCos(cosine(target, p))}</span> : null}
                  </button>
                );
              })}
          </div>
          <AnimatePresence initial={false}>
            {guess ? (
              <motion.div key={`${round}`} initial={reduce ? false : { opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="mt-4 flex flex-wrap items-center justify-between gap-3" role="status">
                <p className={cn("flex items-center gap-2 text-[13.5px]", guess.ok ? "text-ok-ink" : "text-danger-ink")}>
                  {guess.ok ? <CheckCircle size={16} weight="fill" aria-hidden /> : <XCircle size={16} weight="fill" aria-hidden />}
                  {guess.ok ? "Exact." : `La plus proche : « ${ranking[0]?.phrase.label} » (${formatCos(ranking[0]?.cos ?? 0)}).`}
                </p>
                <Button
                  size="sm"
                  onClick={() => {
                    setGuess(null);
                    setRound((r) => r + 1);
                  }}
                >
                  Phrase suivante
                </Button>
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>
      </section>

      <Challenge
        prompt="Défi de la leçon L047 : sur la feuille, où placeriez-vous « Remboursement des frais de transport » ?"
        options={["Près de (9 ; 1), avec les absences", "Près de (3 ; 8), avec la prime", "Au centre (5 ; 5)", "À l'origine (0 ; 0)"]}
        answer={1}
        onAnswer={markUsed}
        explanation={<p>Elle parle d&apos;argent, très peu d&apos;absence : vers (3 ; 8). Son cosinus avec la prime (2 ; 9) dépasse 0,98 ; avec « Absence pour enfant malade » (9 ; 1), il tombe sous 0,5.</p>}
      />
    </div>
  );
}
