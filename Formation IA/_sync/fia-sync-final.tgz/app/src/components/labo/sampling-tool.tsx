"use client";

import * as React from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ArrowCounterClockwise, DiceFive } from "@phosphor-icons/react";
import { CAT_CANDIDATES, CAT_PROMPT, DEFAULT_SAMPLING, entropyBits, keptCount, sampleIndex, shapeDistribution, type SamplingParams } from "@/domain/labo/sampling";
import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/surface";
import { Challenge, Range, useLaboUse } from "./controls";
import { cn } from "@/lib/utils";

const pct = (q: number) => `${(q * 100).toLocaleString("fr-FR", { maximumFractionDigits: q < 0.1 ? 1 : 0 })} %`;
const dec = (v: number, d = 2) => v.toLocaleString("fr-FR", { minimumFractionDigits: d, maximumFractionDigits: d });

const PRESETS: { label: string; params: SamplingParams }[] = [
  { label: "Extraction (T 0)", params: { temperature: 0, topK: 8, topP: 1 } },
  { label: "Rédaction (T 0,7)", params: { temperature: 0.7, topK: 8, topP: 1 } },
  { label: "Brainstorming (T 1,5)", params: { temperature: 1.5, topK: 8, topP: 1 } },
  { label: "Nucleus (top-p 0,9)", params: { temperature: 1, topK: 8, topP: 0.9 } },
];

export function SamplingTool() {
  const reduce = useReducedMotion();
  const markUsed = useLaboUse("temperature");
  const [params, setParams] = React.useState<SamplingParams>(DEFAULT_SAMPLING);
  const [history, setHistory] = React.useState<string[]>([]);
  const [last, setLast] = React.useState<{ token: string; n: number } | null>(null);
  const shaped = React.useMemo(() => shapeDistribution(CAT_CANDIDATES, params), [params]);
  const set = (patch: Partial<SamplingParams>) => {
    markUsed();
    setParams((p) => ({ ...p, ...patch }));
  };
  const draw = (count: number) => {
    markUsed();
    const out: string[] = [];
    for (let i = 0; i < count; i++) out.push(CAT_CANDIDATES[sampleIndex(shaped, Math.random())].token);
    setHistory((h) => [...out.reverse(), ...h].slice(0, 200));
    setLast((l) => ({ token: out[0], n: (l?.n ?? 0) + 1 }));
  };
  const tally = React.useMemo(() => {
    const m = new Map<string, number>();
    history.forEach((t) => m.set(t, (m.get(t) ?? 0) + 1));
    return m;
  }, [history]);
  const maxQ = Math.max(...shaped.map((c) => c.q), 0.01);
  const entropy = entropyBits(shaped.map((c) => c.q));

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-8">
      <div className="grid grid-cols-[minmax(0,1fr)] gap-6 lg:items-start lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <div className="grid content-start gap-5 border border-line bg-bg-elev p-5">
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button
                key={p.label}
                type="button"
                onClick={() => set(p.params)}
                className={cn(
                  "border px-2.5 py-1 text-[12px] transition-colors duration-300",
                  p.params.temperature === params.temperature && p.params.topP === params.topP && p.params.topK === params.topK ? "border-ink bg-ink text-bg" : "border-line-strong text-ink-2 hover:border-ink hover:text-ink",
                )}
              >
                {p.label}
              </button>
            ))}
          </div>
          <Range
            id="smp-t"
            label="Température"
            value={params.temperature}
            min={0}
            max={2}
            step={0.05}
            onChange={(v) => set({ temperature: v })}
            display={dec(params.temperature)}
            hint={params.temperature <= 0.01 ? "0 : toujours le mot le plus probable (choix glouton)." : params.temperature < 1 ? "Sous 1 : les mots probables sont renforcés." : params.temperature > 1 ? "Au-dessus de 1 : la distribution s'aplatit, les mots improbables gagnent des chances." : "1 : les probabilités du modèle, inchangées."}
          />
          <Range
            id="smp-p"
            label="Top-p (nucleus)"
            value={params.topP}
            min={0.05}
            max={1}
            step={0.05}
            onChange={(v) => set({ topP: v })}
            display={dec(params.topP)}
            hint="Garde le plus petit groupe de mots dont les probabilités cumulées atteignent p."
          />
          <Range id="smp-k" label="Top-k" value={params.topK} min={1} max={8} step={1} onChange={(v) => set({ topK: v })} display={params.topK} hint="Ne garde que les k mots les plus probables." />
          <dl className="grid grid-cols-2 gap-4 border-t border-line pt-4 text-[13px]">
            <div>
              <dt className="text-ink-3">Mots encore possibles</dt>
              <dd className="num mt-0.5 text-[18px] text-ink">{keptCount(shaped)} / 8</dd>
            </div>
            <div>
              <dt className="text-ink-3">Incertitude (entropie)</dt>
              <dd className="num mt-0.5 text-[18px] text-ink">{dec(entropy)} bit{entropy >= 2 ? "s" : ""}</dd>
            </div>
          </dl>
        </div>

        <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] content-start gap-4">
          <div className="border border-line bg-bg-elev p-5">
            <p className="font-serif text-[26px] italic leading-snug text-ink sm:text-[32px]">
              {CAT_PROMPT.replace("…", "")}{" "}
              <span className="relative inline-block min-w-[5ch] border-b border-accent not-italic">
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span
                    key={last ? `${last.token}-${last.n}` : "vide"}
                    className={cn("inline-block font-display text-[22px] font-light uppercase tracking-[0.06em] sm:text-[26px]", last ? "text-accent" : "text-ink-3")}
                    initial={reduce ? false : { opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={reduce ? undefined : { opacity: 0, y: 10 }}
                    transition={{ type: "spring", stiffness: 420, damping: 28 }}
                  >
                    {last?.token ?? "…"}
                  </motion.span>
                </AnimatePresence>
              </span>
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button onClick={() => draw(1)}>
                <DiceFive size={14} aria-hidden /> Tirer un mot
              </Button>
              <Button variant="secondary" onClick={() => draw(20)}>
                Tirer 20 fois
              </Button>
              {history.length ? (
                <Button
                  variant="ghost"
                  onClick={() => {
                    setHistory([]);
                    setLast(null);
                  }}
                >
                  <ArrowCounterClockwise size={14} aria-hidden /> Effacer
                </Button>
              ) : null}
            </div>
            <p className="sr-only" aria-live="polite">
              {last ? `Mot tiré : ${last.token}` : ""}
            </p>
          </div>

          <div className="border border-line bg-bg-elev">
            <div className="flex items-baseline justify-between gap-3 border-b border-line px-5 py-3">
              <h2 className="text-[13px] text-ink">Probabilités du mot suivant</h2>
              <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">{history.length ? `${history.length} tirages` : "après réglages"}</span>
            </div>
            <ul className="grid gap-2 px-5 py-4" aria-label="Distribution après réglages">
              {shaped.map((c) => {
                const drawn = tally.get(c.token) ?? 0;
                return (
                  <li key={c.token} className="grid grid-cols-[4.75rem_minmax(0,1fr)_2.25rem_3.25rem] items-center gap-2 text-[13px] sm:grid-cols-[5.5rem_minmax(0,1fr)_2.5rem_3.5rem] sm:gap-3">
                    <span className={cn("truncate", c.kept ? "text-ink" : "text-ink-3 line-through")}>{c.token}</span>
                    <div className="relative h-5 bg-bg-sunken" aria-hidden>
                      {c.kept ? null : <div className="labo-hachures absolute inset-y-0 left-0" style={{ width: `${(c.p / Math.max(maxQ, 0.4)) * 100}%` }} />}
                      <motion.div
                        className="absolute inset-y-0 left-0 bg-accent"
                        initial={false}
                        animate={{ width: `${(c.q / Math.max(maxQ, 0.4)) * 100}%` }}
                        transition={reduce ? { duration: 0 } : { type: "spring", stiffness: 260, damping: 30 }}
                      />
                      <div className="absolute inset-y-[-3px] w-px bg-ink" style={{ left: `${(c.p / Math.max(maxQ, 0.4)) * 100}%` }} title="Probabilité d'origine (T = 1)" />
                    </div>
                    <span className="num text-right text-[11px] text-ink-3">{drawn ? `×${drawn}` : ""}</span>
                    <span className="num text-right text-ink">{c.kept ? pct(c.q) : "coupé"}</span>
                  </li>
                );
              })}
            </ul>
            <p className="border-t border-line px-5 py-2.5 text-[11.5px] text-ink-3">Trait noir : probabilité d&apos;origine du modèle (température 1). Hachures : mot écarté par top-k ou top-p. «&nbsp;×n&nbsp;» : nombre de fois où le mot est sorti.</p>
          </div>
        </div>
      </div>

      <Notice tone="warn" title="Et chez Claude ?">
        Avec la version d&apos;API 2026-10-21 (celle des SDK v2), <code className="font-mono">temperature</code>, <code className="font-mono">top_p</code> et <code className="font-mono">top_k</code> renvoient une erreur 400 sur tous les modèles Claude, même à leur valeur par défaut : on pilote plutôt l&apos;effort de raisonnement. Ces réglages restent disponibles chez d&apos;autres éditeurs et en local (Ollama, LM Studio). Leçons L008 et L017.
      </Notice>

      <Challenge
        prompt="Vous réglez top-p à 0,5 (température 1). Quels mots peuvent encore sortir après « Le chat est assis sur le… » ?"
        options={["Seulement « tapis »", "« tapis » et « canapé »", "Les quatre premiers", "Les huit mots"]}
        answer={1}
        onAnswer={markUsed}
        explanation={<p>« tapis » (40 %) ne suffit pas à atteindre 0,5 ; avec « canapé » (20 %), le cumul atteint 60 % : le tirage se fait entre ces deux mots, renormalisés à 67 % et 33 %.</p>}
      />
    </div>
  );
}
