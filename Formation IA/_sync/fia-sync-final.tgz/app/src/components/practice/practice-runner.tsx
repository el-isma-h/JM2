"use client";

/**
 * Session d'entraînement à un examen blanc (v1.4) : chronomètre INDICATIF (rien n'est envoyé à zéro, le dépassement
 * s'affiche), navigation par numéros, marquage « à revoir », envoi pour correction côté serveur.
 * Ne reçoit que des questions publiques (aucune bonne réponse côté client). Brouillon gardé dans cet onglet
 * (sessionStorage) : un rechargement reprend la session en cours.
 */
import * as React from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ArrowLeft, ArrowRight, BookmarkSimple, Clock, GridFour, Warning, X } from "@phosphor-icons/react";
import type { PublicPracticeQuestion } from "@/content/types";
import { submitPracticeAction } from "@/server/actions/practice";
import { announceRewards } from "@/components/feedback/toaster";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent } from "@/components/ui/dialog";
import { Logo } from "@/components/ui/logo";
import { cn } from "@/lib/utils";

const LETTERS = ["A", "B", "C", "D", "E", "F"];
const TYPE_LABEL: Record<string, string> = { qcm: "QCM", vrai_faux: "Vrai ou faux", trouve_erreur: "Trouvez l'erreur", mise_en_situation: "Mise en situation" };

function fmtClock(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const mm = String(m).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  return h ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

type Draft = { startedAt: string; order: string[]; answers: Record<string, number>; flagged: string[] };
const draftKey = (examId: string) => `nfia-practice:${examId}`;

export type PracticeRunnerProps = {
  examId: string;
  title: string;
  certification: string;
  timeLimitMinutes: number;
  /** Questions publiques, dans l'ordre mélangé de cette session. */
  questions: PublicPracticeQuestion[];
  startedAt: string;
  exitHref: string;
};

export function PracticeRunner(props: PracticeRunnerProps) {
  const { examId, certification, timeLimitMinutes, exitHref } = props;
  const router = useRouter();
  const reduce = useReducedMotion();
  const [questions, setQuestions] = React.useState(props.questions);
  const [startedAt, setStartedAt] = React.useState(props.startedAt);
  const [answers, setAnswers] = React.useState<Record<string, number>>({});
  const [flagged, setFlagged] = React.useState<Set<string>>(() => new Set());
  const [index, setIndex] = React.useState(0);
  const [direction, setDirection] = React.useState(1);
  const [navOpen, setNavOpen] = React.useState(false);
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [restored, setRestored] = React.useState(false);
  const total = questions.length;

  // ---- Reprise d'une session en cours dans cet onglet ----
  React.useEffect(() => {
    try {
      const raw = sessionStorage.getItem(draftKey(examId));
      if (raw) {
        const d = JSON.parse(raw) as Draft;
        const byId = new Map(props.questions.map((q) => [q.id, q]));
        const age = Date.now() - new Date(d.startedAt).getTime();
        if (d.order?.length === props.questions.length && d.order.every((id) => byId.has(id)) && age >= 0 && age < 6 * 3600_000) {
          /* eslint-disable react-hooks/set-state-in-effect -- reprise unique du brouillon local après hydratation */
          setQuestions(d.order.map((id) => byId.get(id)!));
          setStartedAt(d.startedAt);
          setAnswers(d.answers ?? {});
          setFlagged(new Set(d.flagged ?? []));
          const firstEmpty = d.order.findIndex((id) => d.answers?.[id] === undefined);
          setIndex(firstEmpty === -1 ? 0 : firstEmpty);
          if (Object.keys(d.answers ?? {}).length) setRestored(true);
          /* eslint-enable react-hooks/set-state-in-effect */
        }
      }
    } catch {
      /* stockage indisponible */
    }
  }, [examId, props.questions]);

  React.useEffect(() => {
    try {
      const d: Draft = { startedAt, order: questions.map((q) => q.id), answers, flagged: [...flagged] };
      sessionStorage.setItem(draftKey(examId), JSON.stringify(d));
    } catch {
      /* stockage indisponible */
    }
  }, [examId, startedAt, questions, answers, flagged]);

  // ---- Chronomètre indicatif ----
  const limit = timeLimitMinutes * 60;
  const [now, setNow] = React.useState<number | null>(null);
  React.useEffect(() => {
    const tick = () => setNow(Date.now());
    tick();
    const id = setInterval(tick, 500);
    return () => clearInterval(id);
  }, []);
  const elapsed = now === null ? 0 : Math.max(0, (now - new Date(startedAt).getTime()) / 1000);
  const remaining = limit - elapsed;
  const over = remaining <= 0;
  const low = !over && remaining <= 300;
  const timePct = Math.max(0, Math.min(100, (remaining / limit) * 100));

  const q = questions[index];
  const choose = (i: number) => {
    if (submitting) return;
    setAnswers((a) => {
      const n = { ...a };
      if (n[q.id] === i) delete n[q.id];
      else n[q.id] = i;
      return n;
    });
  };
  const toggleFlag = () =>
    setFlagged((f) => {
      const n = new Set(f);
      if (n.has(q.id)) n.delete(q.id);
      else n.add(q.id);
      return n;
    });
  const go = (i: number) => {
    const next = Math.max(0, Math.min(total - 1, i));
    setDirection(next >= index ? 1 : -1);
    setIndex(next);
    setNavOpen(false);
  };

  const submit = async () => {
    if (submitting) return;
    setSubmitting(true);
    setError(null);
    const final: Record<string, number | null> = {};
    for (const x of questions) final[x.id] = answers[x.id] ?? null;
    try {
      const r = await submitPracticeAction({ examId, startedAt, order: questions.map((x) => x.id), answers: final });
      if (r.ok) {
        try {
          sessionStorage.removeItem(draftKey(examId));
        } catch {
          /* stockage indisponible */
        }
        if (r.rewards.xp > 0 || r.rewards.badges.length) announceRewards(r.rewards);
        router.replace(r.url);
        return;
      }
      setError(r.error);
    } catch {
      setError("Connexion perdue. Vos réponses sont conservées dans cet onglet : réessayez dans un instant.");
    }
    setSubmitting(false);
  };

  // Clavier : A–D / 1–4 répondre, ← → naviguer, R marquer.
  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (confirmOpen || e.metaKey || e.ctrlKey || e.altKey) return;
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
      const k = e.key.toLowerCase();
      const n = "abcdef".indexOf(k) !== -1 ? "abcdef".indexOf(k) : "123456".indexOf(k);
      if (n !== -1 && n < q.options.length) {
        e.preventDefault();
        choose(n);
      } else if (e.key === "ArrowRight") go(index + 1);
      else if (e.key === "ArrowLeft") go(index - 1);
      else if (k === "r") toggleFlag();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const answeredCount = questions.filter((x) => answers[x.id] !== undefined).length;
  const unanswered = questions.map((x, i) => ({ id: x.id, n: i + 1 })).filter((x) => answers[x.id] === undefined);
  const flaggedList = questions.map((x, i) => ({ id: x.id, n: i + 1 })).filter((x) => flagged.has(x.id));

  const navigator = (
    <div>
      <div className="grid grid-cols-8 gap-1.5">
        {questions.map((x, i) => {
          const done = answers[x.id] !== undefined;
          const fl = flagged.has(x.id);
          return (
            <button
              key={x.id}
              type="button"
              onClick={() => go(i)}
              aria-label={`Question ${i + 1}${done ? ", répondue" : ", sans réponse"}${fl ? ", à revoir" : ""}`}
              aria-current={i === index ? "step" : undefined}
              className={cn(
                "num relative flex aspect-square items-center justify-center border text-[12px] transition-colors duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-focus",
                done ? "border-ink bg-ink text-bg" : "border-line-strong text-ink-2 hover:border-ink hover:text-ink",
                i === index && "outline-2 outline-offset-2 outline-accent",
              )}
            >
              {i + 1}
              {fl ? <span className="absolute right-0 top-0 size-0 border-l-[9px] border-t-[9px] border-l-transparent border-t-accent" aria-hidden /> : null}
            </button>
          );
        })}
      </div>
      <dl className="mt-5 grid grid-cols-3 border border-line text-[12px] text-ink-2">
        {[
          { k: "Répondues", v: answeredCount },
          { k: "Vides", v: total - answeredCount },
          { k: "À revoir", v: flagged.size },
        ].map((x, i) => (
          <div key={x.k} className={cn("px-3 py-2.5", i && "border-l border-line")}>
            <dd className="font-display text-[20px] font-light leading-none tabular-nums text-ink">{x.v}</dd>
            <dt className="mt-1.5">{x.k}</dt>
          </div>
        ))}
      </dl>
    </div>
  );

  return (
    <section className="fixed inset-0 z-[35] flex flex-col bg-bg" aria-label={props.title}>
      <header className="relative flex h-16 shrink-0 items-center gap-3 border-b border-line px-4 sm:px-6">
        <div className="hidden min-w-0 flex-1 items-center gap-4 md:flex">
          <Logo taille={20} />
          <span className="h-6 w-px bg-line" aria-hidden />
          <span className="truncate text-[12.5px] text-ink-2">Examen blanc · {certification}</span>
        </div>
        <div className="flex min-w-0 flex-1 items-center gap-2.5 md:justify-center">
          <Clock size={16} className={cn("shrink-0", over ? "text-warn-ink" : "text-ink-3")} aria-hidden />
          <div
            role="timer"
            aria-live="off"
            aria-label={over ? `Temps indicatif dépassé de ${fmtClock(-remaining)}` : `Temps indicatif restant ${fmtClock(remaining)}`}
            className={cn("font-display tabular-nums text-[26px] font-light leading-none tracking-[0.04em] transition-colors duration-700 sm:text-[30px]", over ? "text-warn-ink" : low ? "text-warn-ink" : "text-ink")}
            suppressHydrationWarning
          >
            {now === null ? fmtClock(limit) : over ? `+${fmtClock(-remaining)}` : fmtClock(remaining)}
          </div>
          <span className="hidden font-mono text-[9.5px] uppercase tracking-[0.18em] text-ink-3 sm:inline">{over ? "dépassé" : "indicatif"}</span>
        </div>
        <div className="flex flex-1 items-center justify-end gap-3">
          <Button variant="primary" size="sm" onClick={() => setConfirmOpen(true)} disabled={submitting}>
            Terminer
          </Button>
        </div>
        <span className="absolute inset-x-0 bottom-[-1px] h-px bg-line" aria-hidden>
          <span className={cn("block h-px transition-[width] duration-1000 ease-linear", over || low ? "bg-warn" : "bg-accent")} style={{ width: `${over ? 100 : timePct}%` }} />
        </span>
      </header>

      <AnimatePresence>
        {over || restored ? (
          <motion.div
            key={over ? "over" : "restored"}
            initial={reduce ? false : { height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className={cn("shrink-0 overflow-hidden border-b", over ? "border-warn/60 bg-warn-soft" : "border-line bg-bg-elev")}
            role="status"
          >
            <div className={cn("flex items-center gap-3 px-4 py-2.5 text-[13px] sm:px-6", over ? "text-warn-ink" : "text-ink-2")}>
              {over ? <Warning size={16} weight="bold" aria-hidden /> : <BookmarkSimple size={16} aria-hidden />}
              <span className="flex-1">
                {over
                  ? `Les ${timeLimitMinutes} minutes indicatives sont écoulées. Rien n'est envoyé automatiquement : terminez quand vous voulez.`
                  : "Session reprise là où vous l'aviez laissée dans cet onglet."}
              </span>
              {!over ? (
                <button type="button" onClick={() => setRestored(false)} aria-label="Masquer" className="p-1 hover:text-ink">
                  <X size={14} />
                </button>
              ) : null}
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto grid max-w-[1180px] gap-10 px-4 pb-28 pt-8 sm:px-6 lg:grid-cols-[minmax(0,1fr)_300px] lg:pb-12 lg:pt-12">
          <div className="min-w-0">
            <div className="mb-6 flex flex-wrap items-center gap-x-4 gap-y-2">
              <p className="font-display text-[13px] font-normal uppercase tracking-[0.14em] text-ink">
                Question <span className="tabular-nums">{index + 1}</span>
                <span className="text-ink-3"> / {total}</span>
              </p>
              <span className="min-w-0 text-[12px] text-ink-3">
                {TYPE_LABEL[q.type] ?? q.type} · {q.domaine}
              </span>
              <button
                type="button"
                onClick={toggleFlag}
                aria-pressed={flagged.has(q.id)}
                className={cn(
                  "ml-auto inline-flex items-center gap-1.5 border px-2.5 py-1 text-[12px] transition-colors duration-300",
                  flagged.has(q.id) ? "border-accent bg-accent-soft text-accent" : "border-line-strong text-ink-2 hover:border-ink hover:text-ink",
                )}
              >
                <BookmarkSimple size={13} weight={flagged.has(q.id) ? "fill" : "regular"} aria-hidden />
                {flagged.has(q.id) ? "À revoir" : "Marquer à revoir"}
              </button>
            </div>

            <AnimatePresence mode="wait" initial={false} custom={direction}>
              <motion.div
                key={q.id}
                initial={reduce ? false : { opacity: 0, x: 18 * direction }}
                animate={{ opacity: 1, x: 0 }}
                exit={reduce ? { opacity: 0 } : { opacity: 0, x: -18 * direction }}
                transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              >
                <p id={`enonce-${q.id}`} role="heading" aria-level={1} className="max-w-[68ch] text-[18px] leading-[1.5] text-ink sm:text-[20px]" style={{ textWrap: "pretty" }}>
                  {q.q}
                </p>
                <fieldset className="mt-8" aria-labelledby={`enonce-${q.id}`}>
                  <div className="grid gap-2">
                    {q.options.map((opt, i) => {
                      const sel = answers[q.id] === i;
                      return (
                        <label
                          key={i}
                          className={cn(
                            "group relative flex cursor-pointer items-start gap-4 border px-4 py-3.5 transition-colors duration-300 has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-focus",
                            sel ? "border-accent bg-accent-soft" : "border-line hover:border-line-strong hover:bg-bg-elev",
                          )}
                        >
                          <input type="radio" name={`q-${q.id}`} className="sr-only" checked={sel} onChange={() => choose(i)} onClick={() => sel && choose(i)} />
                          <span
                            className={cn("num flex size-7 shrink-0 items-center justify-center border text-[12px] transition-colors duration-300", sel ? "border-accent bg-accent text-accent-ink" : "border-line-strong text-ink-2 group-hover:border-ink")}
                            aria-hidden
                          >
                            {LETTERS[i]}
                          </span>
                          <span className="pt-0.5 text-[14.5px] leading-relaxed text-ink">{opt}</span>
                          {sel ? <motion.span layoutId="practice-choice-mark" className="absolute inset-y-0 left-0 w-[3px] bg-accent" transition={{ type: "spring", stiffness: 500, damping: 40 }} aria-hidden /> : null}
                        </label>
                      );
                    })}
                  </div>
                </fieldset>
              </motion.div>
            </AnimatePresence>

            <div className="mt-8 flex items-center justify-between gap-3 border-t border-line pt-5">
              <Button variant="ghost" onClick={() => go(index - 1)} disabled={index === 0}>
                <ArrowLeft size={14} aria-hidden /> Précédente
              </Button>
              <p className="hidden text-[12px] text-ink-3 sm:block">Touches A–D pour répondre, ← → pour naviguer, R pour marquer</p>
              {index < total - 1 ? (
                <Button variant="secondary" onClick={() => go(index + 1)}>
                  Suivante <ArrowRight size={14} aria-hidden />
                </Button>
              ) : (
                <Button variant="primary" onClick={() => setConfirmOpen(true)} disabled={submitting}>
                  Terminer
                </Button>
              )}
            </div>
            {error ? (
              <p className="mt-4 border-s-2 border-danger px-3 py-2 text-[13px] text-danger-ink" role="alert">
                {error}
              </p>
            ) : null}
          </div>

          <aside className="hidden lg:block" aria-label="Navigation entre les questions">
            <div className="sticky top-0">
              <p className="mb-3 text-[12px] text-ink-3">
                <span className="num text-ink">{answeredCount}</span> sur {total} répondues
              </p>
              {navigator}
              <p className="mt-6 border-l-2 border-line-strong pl-3 text-[12px] leading-relaxed text-ink-3">Entraînement non officiel : tentatives illimitées, correction et explications dès l&apos;envoi.</p>
              <a href={exitHref} className="mt-6 inline-block text-[12px] text-ink-3 underline-offset-4 hover:text-ink hover:underline">
                Quitter (la session reste dans cet onglet)
              </a>
            </div>
          </aside>
        </div>
      </div>

      <div className="shrink-0 border-t border-line bg-bg px-4 pb-[max(env(safe-area-inset-bottom),12px)] pt-3 lg:hidden">
        <div className="flex items-center gap-3">
          <button type="button" onClick={() => setNavOpen(true)} className="flex flex-1 items-center gap-2 border border-line-strong px-3 py-2.5 text-[13px] text-ink">
            <GridFour size={16} aria-hidden />
            <span>
              Questions · <span className="num">{answeredCount}</span>/{total}
            </span>
            {flagged.size ? <span className="ml-auto text-[12px] text-accent">{flagged.size} à revoir</span> : null}
          </button>
          <a href={exitHref} className="shrink-0 px-2 py-2.5 text-[12px] text-ink-3 underline-offset-4 hover:text-ink hover:underline">
            Quitter
          </a>
        </div>
      </div>
      <AnimatePresence>
        {navOpen ? (
          <>
            <motion.div className="fixed inset-0 z-[36] bg-encre/50 lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setNavOpen(false)} />
            <motion.div
              className="fixed inset-x-0 bottom-0 z-[37] border-t border-line-strong bg-bg px-4 pb-[max(env(safe-area-inset-bottom),20px)] pt-4 lg:hidden"
              initial={reduce ? false : { y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 420, damping: 40 }}
              role="dialog"
              aria-label="Questions"
            >
              <div className="mb-4 flex items-center justify-between">
                <p className="text-[13px] text-ink">Aller à la question</p>
                <button type="button" onClick={() => setNavOpen(false)} className="p-1 text-ink-2" aria-label="Fermer">
                  <X size={16} />
                </button>
              </div>
              {navigator}
            </motion.div>
          </>
        ) : null}
      </AnimatePresence>

      <Dialog open={confirmOpen} onOpenChange={(o) => !submitting && setConfirmOpen(o)}>
        <DialogContent
          title="Terminer la session ?"
          description={unanswered.length ? `${unanswered.length} question${unanswered.length > 1 ? "s" : ""} sans réponse : elle${unanswered.length > 1 ? "s" : ""} compter${unanswered.length > 1 ? "ont" : "a"} comme fausse${unanswered.length > 1 ? "s" : ""}.` : "Toutes les questions ont une réponse."}
        >
          {unanswered.length ? <RecapList label="Sans réponse" items={unanswered} onPick={(n) => (setConfirmOpen(false), go(n - 1))} /> : null}
          {flaggedList.length ? <RecapList label="Marquées à revoir" items={flaggedList} onPick={(n) => (setConfirmOpen(false), go(n - 1))} accent /> : null}
          <p className="mt-5 text-[13px] text-ink-2">
            Temps passé : <span className="num text-ink">{fmtClock(elapsed)}</span> sur {timeLimitMinutes} min indicatives. La correction s&apos;affiche dès l&apos;envoi ; vous pourrez recommencer autant de fois que vous le souhaitez.
          </p>
          <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <DialogClose asChild>
              <Button variant="ghost" disabled={submitting}>
                Continuer
              </Button>
            </DialogClose>
            <Button variant="accent" loading={submitting} onClick={() => void submit()}>
              Voir la correction
            </Button>
          </div>
          {error ? (
            <p className="mt-4 text-[13px] text-danger-ink" role="alert">
              {error}
            </p>
          ) : null}
        </DialogContent>
      </Dialog>
    </section>
  );
}

function RecapList({ label, items, onPick, accent }: { label: string; items: { id: string; n: number }[]; onPick: (n: number) => void; accent?: boolean }) {
  return (
    <div className="mt-4">
      <p className="mb-2 text-[12px] text-ink-3">{label}</p>
      <div className="flex flex-wrap gap-1.5">
        {items.map((x) => (
          <button
            key={x.id}
            type="button"
            onClick={() => onPick(x.n)}
            className={cn("num flex h-8 min-w-8 items-center justify-center border px-2 text-[12px] transition-colors hover:border-ink hover:text-ink", accent ? "border-accent text-accent" : "border-line-strong text-ink-2")}
          >
            {x.n}
          </button>
        ))}
      </div>
    </div>
  );
}
