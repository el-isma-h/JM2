import { Warning } from "@phosphor-icons/react/ssr";
import { cn } from "@/lib/utils";

/** Avertissement des examens blancs (README § Avertissement) : toujours visible, en tête de page. */
export function PracticeWarning({ children, title = "Entraînement non officiel", className }: { children: React.ReactNode; title?: string; className?: string }) {
  return (
    <section role="note" aria-label={title} className={cn("border border-warn/70 bg-warn-soft", className)}>
      <div className="flex items-center gap-2.5 border-b border-warn/40 px-5 py-3 text-warn-ink">
        <Warning size={18} weight="bold" aria-hidden />
        <p className="font-mono text-[10.5px] font-medium uppercase tracking-[0.22em]">{title}</p>
      </div>
      <div className="px-5 py-4 text-ink">{children}</div>
    </section>
  );
}
