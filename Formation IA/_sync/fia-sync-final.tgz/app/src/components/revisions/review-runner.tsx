"use client";

/**
 * Session de révision (/revisions) façon Duolingo : une question à la fois, correction serveur, explication,
 * +2 XP par bonne réponse, bilan final. Touches 1–4 pour choisir, Entrée pour vérifier puis continuer.
 */
import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ArrowRight, ArrowSquareOut, ArrowsClockwise, Check, Lightning, X } from "@phosphor-icons/react";
import { answerReviewAction, type ReviewAnswerResult } from "@/server/actions/enrichments";
import type { PublicReviewQuestion } from "@/server/review";
import { routes } from "@/lib/paths";
import { announceRewards, toast } from "@/components/feedback/toaster";
import { celebrate } from "@/components/ui/celebrate";
import { Button } from "@/components/ui/button";
import { ProgressRing } from "@/components/ui/progress";
import { ChoiceList } from "@/components/markdown/choice-list";
import { cn, plural } from "@/lib/utils";

type Answered = Extract<ReviewAnswerResult, { ok: true }> & { chosen: number };

const BOX_LABEL = ["", "À revoir", "Fragile", "En cours", "Solide", "Maîtrisée"];

export function ReviewRunner({ questions }: { questions: PublicReviewQuestion[] }) {
  const router = useRouter();
  const reduce = useReducedMotion();
  const [index, setIndex] = React.useState(0);
  const [value, setValue] = React.useState<number | null>(null);
  const [answers, setAnswers] = React.useState<Record<string, Answered>>({});
  const [pending, start] = React.useTransition();
  const [finished, setFinished] = React.useState(false);
  const continueRef = React.useRef<HTMLButtonElement>(null);

  const q = questions[index];
  const fb = q ? answers[q.key] : undefined;
  const correct = Object.values(answers).filter((a) => a.correct).length;
  const xp = Object.values(answers).reduce((s, a) => s + a.rewards.xp, 0);

  const check = React.useCallback(() => {
    if (!q || value === null || fb || pending) return;
    const chosen = value;
    start(async () => {
      const r = await answerReviewAction(q.key, chosen);
      if (!r.ok) {
        toast({ kind: "error", title: r.error });
        return;
      }
      setAnswers((a) => ({ ...a, [q.key]: { ...r, chosen } }));
      if (r.rewards.badges.length) announceRewards({ xp: 0, badges: r.rewards.badges });
      requestAnimationFrame(() => continueRef.current?.focus());
    });
  }, [q, value, fb, pending]);

  const next = React.useCallback(() => {
    if (index + 1 >= questions.length) {
      setFinished(true);
      if (correct >= Math.ceil(questions.length * 0.8)) void celebrate("small");
      return;
    }
    setIndex((i) => i + 1);
    setValue(null);
  }, [index, questions.length, correct]);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (finished || !q) return;
      const t = e.target as HTMLElement | null;
      if (t?.tagName === "TEXTAREA" || (t?.tagName === "INPUT" && (t as HTMLInputElement).type !== "radio")) return;
      const n = Number(e.key);
      if (!fb && Number.isInteger(n) && n >= 1 && n <= q.options.length) {
        setValue(n - 1);
        return;
      }
      if (e.key === "Enter" && t?.tagName !== "BUTTON" && t?.tagName !== "A") {
        e.preventDefault();
        if (fb) next();
        else check();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [q, fb, finished, check, next]);

  if (finished) {
    const total = questions.length;
    return (
      <motion.div initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-[640px] border border-line bg-bg-elev p-6 text-center sm:p-10">
        <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-ink-3">Session terminée</p>
        <div className="mt-8 flex justify-center">
          <ProgressRing value={correct} max={total} size={150} stroke={4}>
            <span className="num text-[36px] leading-none text-ink">
              {correct}
              <span className="text-[16px] text-ink-3">/{total}</span>
            </span>
          </ProgressRing>
        </div>
        <h2 className="mt-8 text-[26px] text-ink sm:text-[32px]">{correct === total ? "Sans faute" : correct >= total * 0.7 ? "Bien révisé" : "À reprendre"}</h2>
        <p className="mx-auto mt-3 max-w-[46ch] text-[13.5px] text-ink-2">
          {correct === total
            ? "Toutes les réponses sont justes : ces questions reviendront plus tard, à intervalles plus longs."
            : `${plural(total - correct, "question ratée", "questions ratées")} ${total - correct > 1 ? "reviendront" : "reviendra"} en priorité dans votre prochaine session.`}
        </p>
        {xp > 0 ? (
          <p className="num mt-5 inline-flex items-center gap-1.5 border border-accent/40 bg-accent-soft px-3 py-1.5 text-[13px] text-accent">
            <Lightning size={14} weight="fill" aria-hidden />+{xp} XP · la série continue
          </p>
        ) : null}
        <div className="mt-8 flex flex-col justify-center gap-2 sm:flex-row">
          <Button size="lg" onClick={() => router.refresh()}>
            <ArrowsClockwise size={15} aria-hidden /> Nouvelle session
          </Button>
          <Button asChild size="lg" variant="secondary">
            <Link href={routes.home}>Tableau de bord</Link>
          </Button>
        </div>
      </motion.div>
    );
  }

  if (!q) return null;

  return (
    <div className="mx-auto max-w-[720px]">
      <div className="flex items-center gap-4">
        <ol className="grid flex-1 gap-1" style={{ gridTemplateColumns: `repeat(${questions.length}, minmax(0, 1fr))` }} aria-label={`Question ${index + 1} sur ${questions.length}`}>
          {questions.map((x, i) => {
            const a = answers[x.key];
            return <li key={x.key} className={cn("h-1.5", a ? (a.correct ? "bg-ok" : "bg-danger") : i === index ? "bg-ink" : "bg-bg-muted")} />;
          })}
        </ol>
        <span className="num shrink-0 text-[12px] text-ink-3">
          {index + 1}/{questions.length}
        </span>
      </div>

      <AnimatePresence mode="wait" initial={false}>
        <motion.section
          key={q.key}
          initial={reduce ? false : { opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={reduce ? undefined : { opacity: 0, x: -24 }}
          transition={{ duration: 0.26, ease: [0.165, 0.84, 0.44, 1] }}
          className="mt-8"
          aria-labelledby="rev-question"
        >
          <p className="flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[10px] uppercase tracking-[0.2em]">
            <span className="text-accent">{q.origin === "quizflash" ? "Quiz éclair" : "Quiz du module"}</span>
            <Link href={routes.lesson(q.lessonId)} className="truncate normal-case tracking-normal text-ink-3 hover:text-ink">
              <span className="num">{q.lessonId}</span> · {q.lessonTitle}
            </Link>
          </p>
          <p id="rev-question" role="heading" aria-level={2} className="mt-3 max-w-[60ch] text-[18px] font-medium leading-snug text-ink sm:text-[21px]">
            {q.q}
          </p>
          <div className="mt-7">
            <ChoiceList name={`rev-${q.key}`} labelledBy="rev-question" options={q.options} value={value} onChange={setValue} verdict={fb ? { answer: fb.answer, chosen: fb.chosen } : null} disabled={pending} size="lg" />
          </div>
          {!fb ? (
            <div className="mt-8 flex items-center justify-between gap-4">
              <p className="hidden font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3 sm:block">Touches 1–{q.options.length} puis Entrée</p>
              <Button size="lg" onClick={check} disabled={value === null} loading={pending} className="w-full sm:w-auto">
                Vérifier
              </Button>
            </div>
          ) : null}
        </motion.section>
      </AnimatePresence>

      <AnimatePresence>
        {fb ? (
          <motion.div
            key={`fb-${q.key}`}
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ type: "spring", stiffness: 380, damping: 32 }}
            className={cn("sticky bottom-[calc(env(safe-area-inset-bottom)+4.75rem)] z-10 mt-8 border-l-2 bg-bg-elev p-5 shadow-[var(--shadow-2)] sm:p-6 lg:bottom-6", fb.correct ? "border-ok" : "border-danger")}
            role="status"
          >
            <div className="flex items-start gap-3">
              <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center", fb.correct ? "bg-ok-soft text-ok-ink" : "bg-danger-soft text-danger-ink")}>
                {fb.correct ? <Check size={16} weight="bold" aria-hidden /> : <X size={16} weight="bold" aria-hidden />}
              </span>
              <div className="min-w-0 flex-1">
                <p className={cn("flex flex-wrap items-center gap-x-3 font-display text-[16px] font-light uppercase tracking-[0.06em]", fb.correct ? "text-ok-ink" : "text-danger-ink")}>
                  {fb.correct ? "Bonne réponse" : "Pas tout à fait"}
                  {fb.rewards.xp > 0 ? (
                    <span className="num inline-flex items-center gap-1 font-mono text-[11px] normal-case tracking-normal text-accent">
                      <Lightning size={11} weight="fill" aria-hidden />+{fb.rewards.xp} XP
                    </span>
                  ) : null}
                  <span className="font-mono text-[10px] tracking-[0.16em] text-ink-3">{BOX_LABEL[fb.box] ?? ""}</span>
                </p>
                {fb.explanation ? <p className="mt-2 text-[13.5px] leading-relaxed text-ink">{fb.explanation}</p> : null}
                {fb.source ? (
                  <a href={fb.source.url} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1.5 text-[12.5px] text-accent underline decoration-1 underline-offset-4 hover:decoration-2">
                    {fb.source.title} <ArrowSquareOut size={12} aria-hidden />
                  </a>
                ) : null}
              </div>
            </div>
            <div className="mt-5 flex justify-end">
              <Button ref={continueRef} size="lg" variant={fb.correct ? "primary" : "secondary"} onClick={next} className="w-full sm:w-auto">
                {index + 1 >= questions.length ? "Voir le bilan" : "Continuer"} <ArrowRight size={14} aria-hidden />
              </Button>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}
