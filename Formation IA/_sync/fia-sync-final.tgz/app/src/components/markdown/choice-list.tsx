"use client";

/**
 * Liste de choix d'une question (quiz éclair, révisions) : vrais boutons radio natifs (flèches du clavier, lecteurs
 * d'écran) habillés aux couleurs de la marque. Après correction : bonne réponse en vert, choix erroné en rouge.
 */
import * as React from "react";
import { motion, useReducedMotion } from "motion/react";
import { Check, X } from "@phosphor-icons/react";
import { cn } from "@/lib/utils";

export type ChoiceVerdict = { answer: number; chosen: number } | null;

export function ChoiceList({
  name,
  labelledBy,
  options,
  value,
  onChange,
  verdict,
  disabled,
  size = "md",
}: {
  name: string;
  labelledBy: string;
  options: string[];
  value: number | null;
  onChange: (i: number) => void;
  verdict: ChoiceVerdict;
  disabled?: boolean;
  size?: "md" | "lg";
}) {
  const reduce = useReducedMotion();
  const twoCols = options.length === 2 && options.every((o) => o.length <= 12);
  return (
    <div role="radiogroup" aria-labelledby={labelledBy} className={cn("grid gap-2", twoCols && "grid-cols-2")}>
      {options.map((opt, i) => {
        const state = verdict ? (i === verdict.answer ? "right" : i === verdict.chosen ? "wrong" : "none") : value === i ? "selected" : "idle";
        const anim = state === "wrong" && !reduce ? { x: [0, -6, 6, -3, 3, 0] } : state === "right" && !reduce ? { scale: [1, 1.015, 1] } : undefined;
        return (
          <motion.label
            key={i}
            animate={anim}
            transition={{ duration: 0.38 }}
            className={cn(
              "group relative flex items-start gap-3 border px-3.5 py-3 text-left transition-[border-color,background-color] duration-200 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-[var(--focus)]",
              size === "lg" ? "text-[15px] sm:px-4 sm:py-3.5" : "text-[14px]",
              state === "idle" && "border-line-strong bg-bg hover:border-ink hover:bg-bg-sunken",
              state === "selected" && "border-ink bg-bg-sunken",
              state === "right" && "border-ok bg-ok-soft",
              state === "wrong" && "border-danger bg-danger-soft",
              state === "none" && "border-line bg-bg opacity-60",
              disabled || verdict ? "cursor-default" : "cursor-pointer",
            )}
          >
            <input
              type="radio"
              name={name}
              value={i}
              checked={verdict ? verdict.chosen === i : value === i}
              disabled={disabled || verdict !== null}
              onChange={() => onChange(i)}
              className="sr-only"
            />
            <span
              aria-hidden
              className={cn(
                "num flex h-6 w-6 shrink-0 items-center justify-center border text-[11px]",
                state === "right" ? "border-ok bg-ok text-bg" : state === "wrong" ? "border-danger bg-danger text-bg" : state === "selected" ? "border-ink bg-ink text-bg" : "border-line-strong text-ink-2",
              )}
            >
              {state === "right" ? <Check size={12} weight="bold" /> : state === "wrong" ? <X size={12} weight="bold" /> : String.fromCharCode(65 + i)}
            </span>
            <span className="min-w-0 flex-1 leading-snug text-ink">{opt}</span>
            {state === "right" ? <span className="sr-only">(bonne réponse)</span> : state === "wrong" ? <span className="sr-only">(votre réponse, incorrecte)</span> : null}
          </motion.label>
        );
      })}
    </div>
  );
}
