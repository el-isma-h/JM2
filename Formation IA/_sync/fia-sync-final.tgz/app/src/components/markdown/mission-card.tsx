"use client";

/**
 * Mission documentation (bloc ```mission) : aller chercher une information dans une documentation officielle.
 * Lien ouvert dans un nouvel onglet, étapes, réponse libre (brouillon gardé dans ce navigateur), indice et réponse
 * de référence à la demande, puis « Mission accomplie » (+XP une seule fois, barème lu côté serveur).
 * v1.4 : `metier` (slug) → mission d'un parcours métier (completeMetierMissionAction).
 */
import * as React from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ArrowSquareOut, CheckCircle, Eye, Lightbulb, Lightning, MagnifyingGlass } from "@phosphor-icons/react";
import type { Mission } from "@/lib/lesson-blocks";
import { completeMissionAction } from "@/server/actions/enrichments";
import { completeMetierMissionAction } from "@/server/actions/metiers";
import { announceRewards, toast } from "@/components/feedback/toaster";
import { celebrate } from "@/components/ui/celebrate";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const draftKey = (lessonId: string, index: number) => `nfia-mission:${lessonId}:${index}`;

function hostOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

export function MissionCard({ lessonId, index, mission, done, metier }: { lessonId: string; index: number; mission: Mission; done: boolean; metier?: string }) {
  const reduce = useReducedMotion();
  const id = React.useId();
  const [draft, setDraft] = React.useState("");
  const [showHint, setShowHint] = React.useState(false);
  const [showAnswer, setShowAnswer] = React.useState(false);
  const [accomplished, setAccomplished] = React.useState(done);
  const [gained, setGained] = React.useState(0);
  const [pending, start] = React.useTransition();

  React.useEffect(() => {
    try {
      const saved = localStorage.getItem(draftKey(lessonId, index));
      // eslint-disable-next-line react-hooks/set-state-in-effect -- lecture unique du brouillon local après hydratation
      if (saved) setDraft(saved);
    } catch {
      /* stockage indisponible */
    }
  }, [lessonId, index]);

  const onDraft = (v: string) => {
    setDraft(v);
    try {
      if (v) localStorage.setItem(draftKey(lessonId, index), v);
      else localStorage.removeItem(draftKey(lessonId, index));
    } catch {
      /* stockage indisponible */
    }
  };

  const complete = () =>
    start(async () => {
      const r = metier ? await completeMetierMissionAction(metier, index) : await completeMissionAction(lessonId, index);
      if (!r.ok) {
        toast({ kind: "error", title: r.error });
        return;
      }
      setAccomplished(true);
      if (!r.alreadyDone) {
        setGained(r.rewards.xp);
        void celebrate("small");
        announceRewards(r.rewards);
      }
    });

  return (
    <section className="nf-block border border-line-strong bg-bg-elev" aria-labelledby={`${id}-title`}>
      <header className="flex items-center justify-between gap-3 border-b border-line bg-bg-sunken px-4 py-2.5 sm:px-5">
        <span className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-ink-2">
          <MagnifyingGlass size={13} weight="bold" className="text-accent" aria-hidden />
          Mission documentation
        </span>
        {accomplished ? (
          <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-ok-ink">
            <CheckCircle size={13} weight="fill" aria-hidden /> Accomplie
          </span>
        ) : (
          <span className="num font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">+{mission.xp} XP</span>
        )}
      </header>

      <div className="px-4 pb-5 pt-4 sm:px-5">
        <h3 id={`${id}-title`} className="max-w-[40ch] text-[17px] leading-[1.2] text-ink">
          {mission.title}
        </h3>

        <a
          href={mission.url}
          target="_blank"
          rel="noopener noreferrer"
          className="group mt-3 flex w-full items-center justify-between gap-3 border border-accent px-3 py-2 text-accent transition-colors duration-300 hover:bg-accent hover:text-accent-ink sm:inline-flex sm:w-auto sm:max-w-full sm:justify-start"
        >
          <span className="min-w-0">
            <span className="block text-[12.5px] font-medium">Ouvrir la documentation</span>
            <span className="block truncate font-mono text-[10.5px] opacity-75">{hostOf(mission.url)}</span>
          </span>
          <ArrowSquareOut size={15} className="shrink-0" aria-hidden />
          <span className="sr-only">(nouvel onglet)</span>
        </a>

        {mission.steps.length ? (
          <ol className="mt-4 space-y-1.5" aria-label="Étapes">
            {mission.steps.map((s, i) => (
              <li key={i} className="flex gap-3 text-[13.5px] leading-snug text-ink-2">
                <span aria-hidden className="num mt-px w-5 shrink-0 text-right font-mono text-[11px] text-accent">
                  {i + 1}.
                </span>
                <span>{s}</span>
              </li>
            ))}
          </ol>
        ) : null}

        <div className="mt-5 border-t border-line pt-4">
          <label htmlFor={`${id}-answer`} className="block text-[14px] font-medium text-ink">
            {mission.question}
          </label>
          <textarea
            id={`${id}-answer`}
            value={draft}
            onChange={(e) => onDraft(e.target.value)}
            rows={2}
            placeholder="Notez ce que vous avez trouvé…"
            className="mt-2 block w-full resize-y border border-line-strong bg-bg px-3 py-2 text-[14px] text-ink placeholder:text-ink-3 focus:border-ink focus:outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--focus)]"
          />
        </div>

        <AnimatePresence initial={false}>
          {showHint && mission.hint ? (
            <motion.div
              key="hint"
              id={`${id}-hint`}
              initial={reduce ? { opacity: 0 } : { opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={reduce ? { opacity: 0 } : { opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <p className="mt-3 flex gap-2 border-l-2 border-warn bg-warn-soft px-3 py-2 text-[13px] text-ink">
                <Lightbulb size={15} className="mt-0.5 shrink-0 text-warn-ink" aria-hidden />
                <span>
                  <span className="sr-only">Indice : </span>
                  {mission.hint}
                </span>
              </p>
            </motion.div>
          ) : null}
          {showAnswer ? (
            <motion.div
              key="answer"
              id={`${id}-ref`}
              initial={reduce ? { opacity: 0 } : { opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={reduce ? { opacity: 0 } : { opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="mt-3 border-l-2 border-accent bg-accent-soft px-3 py-2.5">
                <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-accent">Réponse de référence</p>
                <p className="mt-1 text-[13.5px] leading-relaxed text-ink">{mission.answer}</p>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>

        <div className="mt-4 flex flex-col-reverse gap-2 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-2">
            {mission.hint ? (
              <Button variant="ghost" size="sm" onClick={() => setShowHint((v) => !v)} aria-expanded={showHint} aria-controls={`${id}-hint`}>
                <Lightbulb size={13} aria-hidden /> {showHint ? "Masquer l'indice" : "Voir l'indice"}
              </Button>
            ) : null}
            <Button variant="ghost" size="sm" onClick={() => setShowAnswer((v) => !v)} aria-expanded={showAnswer} aria-controls={`${id}-ref`}>
              <Eye size={13} aria-hidden /> {showAnswer ? "Masquer la réponse" : "Révéler la réponse"}
            </Button>
          </div>
          {accomplished ? (
            <p className={cn("inline-flex items-center gap-2 text-[13px] text-ok-ink")} role="status">
              <CheckCircle size={16} weight="fill" aria-hidden /> Mission accomplie
              {gained > 0 ? (
                <span className="num inline-flex items-center gap-1 text-accent">
                  <Lightning size={12} weight="fill" aria-hidden />+{gained} XP
                </span>
              ) : null}
            </p>
          ) : (
            <Button variant="accent" size="sm" onClick={complete} loading={pending} className="w-full sm:w-auto">
              <CheckCircle size={14} weight="bold" aria-hidden /> Mission accomplie
            </Button>
          )}
        </div>
      </div>
    </section>
  );
}
