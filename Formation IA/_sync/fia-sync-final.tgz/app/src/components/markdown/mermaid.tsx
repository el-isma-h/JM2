"use client";

import * as React from "react";
import { MERMAID_THEMES, type MermaidTheme } from "./mermaid-theme";

/**
 * Diagramme Mermaid rendu côté client (import dynamique : mermaid n'est chargé que si la page en contient un).
 *
 * v1.2 : le diagramme est rendu UNE fois dans chaque thème (clair et sombre) et le CSS affiche le bon
 * (`.mermaid-light` / `.mermaid-dark`) : bascule de thème instantanée, et l'impression utilise toujours la version
 * claire (fond blanc) même si l'écran est en sombre. Les rendus sont mis en file : `mermaid.initialize` est global,
 * deux diagrammes rendus en parallèle dans deux thèmes différents se mélangeraient sinon.
 * En cas d'erreur de syntaxe : code source affiché tel quel.
 */
let counter = 0;
let queue: Promise<unknown> = Promise.resolve();

function renderSerial(code: string, theme: MermaidTheme): Promise<string> {
  const job = queue.then(async () => {
    const mermaid = (await import("mermaid")).default;
    mermaid.initialize({
      startOnLoad: false,
      securityLevel: "strict",
      theme: "base",
      fontFamily: "Inter Variable, Inter, system-ui, sans-serif",
      themeVariables: MERMAID_THEMES[theme],
      flowchart: { htmlLabels: true, useMaxWidth: true },
      sequence: { useMaxWidth: true },
    });
    const { svg } = await mermaid.render(`mermaid-${theme}-${++counter}`, code);
    return svg;
  });
  queue = job.catch(() => undefined);
  return job;
}

export function MermaidDiagram({ code }: { code: string }) {
  const lightRef = React.useRef<HTMLDivElement>(null);
  const darkRef = React.useRef<HTMLDivElement>(null);
  const [error, setError] = React.useState(false);

  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        // Le thème affiché d'abord, l'autre ensuite (bascule de thème et impression).
        const order: MermaidTheme[] = document.documentElement.classList.contains("dark") ? ["dark", "light"] : ["light", "dark"];
        for (const theme of order) {
          const svg = await renderSerial(code, theme);
          if (cancelled) return;
          const el = theme === "dark" ? darkRef.current : lightRef.current;
          if (el) el.innerHTML = svg;
        }
      } catch {
        if (!cancelled) setError(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [code]);

  if (error) return <pre>{code}</pre>;
  return (
    <div className="mermaid-figure" role="img" aria-label="Diagramme">
      <div ref={lightRef} className="mermaid-light" />
      <div ref={darkRef} className="mermaid-dark" />
    </div>
  );
}
