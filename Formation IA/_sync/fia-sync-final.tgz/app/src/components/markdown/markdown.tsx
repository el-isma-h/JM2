/**
 * Rendu Markdown des leçons et ressources (SPEC § Rendu des leçons) — composant SERVEUR.
 *
 * Chaîne : remark-gfm + remark-math → rehype-raw (HTML des fichiers, ex. <details>) → rehype-sanitize (liste blanche)
 * → rehype-katex (formules) → rehype-highlight (code) → rehype-slug (ancres identiques à lesson.headings).
 * Les blocs ```mermaid sont rendus côté client (MermaidDiagram). Encadrés 💡 / ⚠️ / 🔗 → blockquote[data-callout].
 * Liens externes : target=_blank rel="noopener noreferrer".
 * v1.4 : encadrés typés par l'émoji ET le libellé en gras (lib/callouts.ts) : 🧭 En clair / Pas à pas pour débutant /
 * Pré-requis express, ✅ Si vous ne retenez que 3 choses, 🔍 Ce que fait ce code, 🛠️ Si ça ne marche pas, 💡 Autrement dit.
 * v1.2 : les prix en dollars (« 0,10 $ … 10 $ ») sont échappés avant l'analyse pour ne plus être lus comme une formule.
 * v1.1 : encadré « 🧭 En clair » (citation mise en avant) ; blocs ```quiz (quiz éclair) et ```mission (mission
 * documentation) rendus interactifs quand `lesson` est fourni ; JSON invalide → bloc brut affiché tel quel.
 *
 * v1.4 : `metier` → blocs ```quiz / ```mission d'un parcours métier (XP `metier:{slug}:{index}`) ; `lessonLinks`
 * (ids de leçons connus) → « L021 » écrit en clair devient un lien vers /lecon/L021 (Link interne, basePath géré).
 *
 *   <Markdown source={lesson.body} />
 *   <Markdown source={body} lesson={{ id: "L001", doneQuiz: [0], doneMissions: [] }} />
 *   <Markdown source={metier.body} metier={{ slug: "rh", doneQuiz: [], doneMissions: [] }} lessonLinks={ids} />
 */
import * as React from "react";
import Link from "next/link";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeRaw from "rehype-raw";
import rehypeSanitize, { defaultSchema, type Options as SanitizeSchema } from "rehype-sanitize";
import rehypeKatex from "rehype-katex";
import rehypeHighlight from "rehype-highlight";
import rehypeSlug from "rehype-slug";
import { Backpack, ChatCircleText, Code, Compass, Footprints, ListChecks, Wrench } from "@phosphor-icons/react/ssr";
import { cn } from "@/lib/utils";
import { FLASH_QUIZ_XP, parseMissionBlock, parseQuizBlock, remarkLessonBlocks, toPublicFlashQuiz } from "@/lib/lesson-blocks";
import { escapeCurrencyDollars } from "@/lib/lesson-text";
import { lessonHrefPattern, remarkLessonLinks } from "@/lib/lesson-links";
import { CALLOUT_LABEL, calloutInfo, type CalloutInfo, type CalloutKind } from "@/lib/callouts";
import { MermaidDiagram } from "./mermaid";
import { FlashQuizCard } from "./flash-quiz";
import { MissionCard } from "./mission-card";

/** Contexte d'une leçon : active les blocs interactifs (quiz éclair, missions) et l'état déjà acquis. */
export type LessonBlocksContext = { id: string; doneQuiz: readonly number[]; doneMissions: readonly number[] };
/** v1.4 : contexte d'un parcours métier (mêmes blocs, actions dédiées). */
export type MetierBlocksContext = { slug: string; doneQuiz: readonly number[]; doneMissions: readonly number[] };

const schema: SanitizeSchema = {
  ...defaultSchema,
  // Pas de préfixe « user-content- » : les ancres sont posées après le nettoyage par rehype-slug.
  clobberPrefix: "",
  tagNames: [...(defaultSchema.tagNames ?? []), "details", "summary", "kbd", "mark", "figure", "figcaption"],
  attributes: {
    ...defaultSchema.attributes,
    details: ["open"],
    code: [...(defaultSchema.attributes?.code ?? []), ["className", /^language-./, "math-inline", "math-display"], "dataBlock", "dataBlockIndex"],
    span: [...(defaultSchema.attributes?.span ?? []), ["className", "math-inline", "math-display"]],
    div: [...(defaultSchema.attributes?.div ?? []), ["className", "math-display"]],
  },
};

function textOf(node: React.ReactNode): string {
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(textOf).join("");
  if (React.isValidElement<{ children?: React.ReactNode }>(node)) return textOf(node.props.children);
  return "";
}

type Lead = { info: CalloutInfo | undefined; label: React.ReactNode | null; rest: React.ReactNode[] };

/**
 * Début d'un paragraphe d'encadré : « émoji **Libellé** — texte ». Renvoie le type (lib/callouts.ts), le contenu du
 * libellé en gras (s'il est reconnu) et le reste du paragraphe, émoji, libellé et tiret retirés.
 */
function splitLead(p: React.ReactElement<{ children?: React.ReactNode }>): Lead {
  const parts = React.Children.toArray(p.props.children);
  const text = textOf(parts);
  let i = 0;
  let emojiOnly = false;
  if (typeof parts[0] === "string" && /^\s*\p{Extended_Pictographic}\uFE0F?\s*$/u.test(parts[0])) {
    emojiOnly = true;
    i = 1;
  }
  const bold = emojiOnly && React.isValidElement<{ children?: React.ReactNode }>(parts[i]) && (parts[i] as React.ReactElement).type === "strong" ? (parts[i] as React.ReactElement<{ children?: React.ReactNode }>) : null;
  const info = calloutInfo(text, bold ? textOf(bold.props.children) : null);
  if (!info) return { info, label: null, rest: parts };
  let rest: React.ReactNode[];
  if (bold && info.labelled) rest = parts.slice(i + 1);
  else if (bold && info.kind === "plain" && /^en clair\s*:?$/i.test(textOf(bold.props.children).trim())) rest = parts.slice(i + 1);
  else if (info.kind === "plain") {
    rest = parts.slice(i);
    if (typeof rest[0] === "string") rest[0] = (rest[0] as string).replace(/^\s*🧭\s*/u, "");
  } else return { info, label: null, rest: parts };
  if (typeof rest[0] === "string") rest[0] = (rest[0] as string).replace(/^\s*[—–:-]\s*/, "");
  return { info, label: bold && info.labelled ? bold.props.children : null, rest };
}

const isEmpty = (nodes: React.ReactNode[]) => nodes.every((n) => typeof n === "string" && !n.trim());

const CALLOUT_ICON: Partial<Record<CalloutKind, typeof Compass>> = { steps: Footprints, prereq: Backpack, recap: ListChecks, code: Code, fix: Wrench, restate: ChatCircleText };

function CalloutLabel({ kind, children, sub }: { kind: CalloutKind; children: React.ReactNode; sub?: boolean }) {
  const Icon = CALLOUT_ICON[kind];
  return (
    <p className={cn("callout-label", sub && "callout-label-sub")} data-kind={kind}>
      {Icon ? <Icon size={14} weight="regular" aria-hidden /> : null}
      <span>{children}</span>
    </p>
  );
}

/**
 * Contenu d'un encadré : le 1er paragraphe perd son émoji et son libellé (affiché en en-tête) ; un paragraphe suivant
 * qui ouvre un autre encadré à libellé (ex. 🔍 dans un « Pré-requis express ») reçoit son propre sous-titre.
 */
function renderCallout(children: React.ReactNode, kind: CalloutKind): { label: React.ReactNode | null; body: React.ReactNode[] } {
  let label: React.ReactNode | null = null;
  let first = true;
  const body: React.ReactNode[] = [];
  React.Children.toArray(children).forEach((child, idx) => {
    if (!React.isValidElement<{ children?: React.ReactNode }>(child) || child.type !== "p") {
      body.push(child);
      return;
    }
    const lead = splitLead(child);
    if (first) {
      first = false;
      label = lead.label;
      if (lead.info && (lead.info.labelled || lead.info.kind === "plain") && lead.info.kind === kind) {
        if (!isEmpty(lead.rest)) body.push(React.cloneElement(child, { key: `p${idx}` }, ...lead.rest));
        return;
      }
      body.push(child);
      return;
    }
    if (lead.info?.labelled && lead.label) {
      body.push(<CalloutLabel key={`l${idx}`} kind={lead.info.kind} sub>{lead.label}</CalloutLabel>);
      if (!isEmpty(lead.rest)) body.push(React.cloneElement(child, { key: `p${idx}` }, ...lead.rest));
      return;
    }
    body.push(child);
  });
  return { label, body };
}

/** Type de l'encadré : premier paragraphe (émoji + libellé en gras). */
function calloutOf(children: React.ReactNode): CalloutInfo | undefined {
  const first = React.Children.toArray(children).find((c) => React.isValidElement(c));
  if (React.isValidElement<{ children?: React.ReactNode }>(first) && first.type === "p") return splitLead(first).info;
  return calloutInfo(textOf(children).trimStart(), null);
}

function codeBlock(children: React.ReactNode): { lang: string; text: string; block?: string; index?: number } | null {
  const child = React.Children.toArray(children)[0];
  if (!React.isValidElement<{ className?: string; children?: React.ReactNode; "data-block"?: string; "data-block-index"?: string }>(child)) return null;
  const lang = /\blanguage-([\w-]+)/.exec(child.props.className ?? "")?.[1] ?? "";
  const idx = child.props["data-block-index"];
  return { lang, text: textOf(child.props.children), block: child.props["data-block"], index: idx !== undefined ? Number(idx) : undefined };
}

function makeComponents(lesson: LessonBlocksContext | undefined, metier?: MetierBlocksContext): Components {
  return {
    a: ({ href, children, ...props }) => {
      if (typeof href === "string" && lessonHrefPattern.test(href)) {
        return (
          <Link href={href} className="lesson-ref">
            {children}
          </Link>
        );
      }
      const external = typeof href === "string" && /^https?:\/\//.test(href);
      return (
        <a href={href} {...props} {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}>
          {children}
        </a>
      );
    },
    blockquote: ({ children, ...props }) => {
      const info = calloutOf(children);
      if (!info) return <blockquote {...props}>{children}</blockquote>;
      const kind = info.kind;
      if (kind === "plain") {
        const { body } = renderCallout(children, "plain");
        return (
          <blockquote data-callout="plain" {...props}>
            <p className="en-clair-label" aria-hidden>
              <Compass size={14} weight="regular" /> En clair
            </p>
            <span className="sr-only">En clair : </span>
            {body}
          </blockquote>
        );
      }
      if (info.labelled) {
        const { label, body } = renderCallout(children, kind);
        return (
          <blockquote data-callout={kind} {...props}>
            <CalloutLabel kind={kind}>{label ?? CALLOUT_LABEL[kind]}</CalloutLabel>
            {body}
          </blockquote>
        );
      }
      return (
        <blockquote data-callout={kind} {...props}>
          {children}
        </blockquote>
      );
    },
    pre: ({ children, ...props }) => {
      const code = codeBlock(children);
      if (code?.lang === "mermaid") return <MermaidDiagram code={code.text} />;
      if (metier && code?.block && code.index !== undefined && Number.isInteger(code.index)) {
        if (code.block === "quiz") {
          const quiz = parseQuizBlock(code.text);
          if (quiz) return <FlashQuizCard lessonId={`metier:${metier.slug}`} metier={metier.slug} index={code.index} quiz={toPublicFlashQuiz(quiz)} done={metier.doneQuiz.includes(code.index)} xp={FLASH_QUIZ_XP} />;
        } else if (code.block === "mission") {
          const mission = parseMissionBlock(code.text);
          if (mission) return <MissionCard lessonId={`metier:${metier.slug}`} metier={metier.slug} index={code.index} mission={mission} done={metier.doneMissions.includes(code.index)} />;
        }
      }
      if (lesson && code?.block && code.index !== undefined && Number.isInteger(code.index)) {
        if (code.block === "quiz") {
          const quiz = parseQuizBlock(code.text);
          if (quiz) return <FlashQuizCard lessonId={lesson.id} index={code.index} quiz={toPublicFlashQuiz(quiz)} done={lesson.doneQuiz.includes(code.index)} xp={FLASH_QUIZ_XP} />;
        } else if (code.block === "mission") {
          const mission = parseMissionBlock(code.text);
          if (mission) return <MissionCard lessonId={lesson.id} index={code.index} mission={mission} done={lesson.doneMissions.includes(code.index)} />;
        }
      }
      return <pre {...props}>{children}</pre>;
    },
    table: ({ children, ...props }) => <table {...props}>{children}</table>,
  };
}

const staticComponents = makeComponents(undefined);

export function Markdown({ source, className, lesson, metier, lessonLinks }: { source: string; className?: string; lesson?: LessonBlocksContext; metier?: MetierBlocksContext; lessonLinks?: readonly string[] }) {
  return (
    <div className={cn("prose-nf", className)}>
      <ReactMarkdown
        remarkPlugins={lessonLinks?.length ? [remarkGfm, remarkMath, remarkLessonBlocks, [remarkLessonLinks, lessonLinks]] : [remarkGfm, remarkMath, remarkLessonBlocks]}
        rehypePlugins={[rehypeRaw, [rehypeSanitize, schema], rehypeKatex, [rehypeHighlight, { detect: false, plainText: ["mermaid", "text", "txt", "quiz", "mission"] }], rehypeSlug]}
        components={lesson || metier ? makeComponents(lesson, metier) : staticComponents}
      >
        {escapeCurrencyDollars(source)}
      </ReactMarkdown>
    </div>
  );
}
