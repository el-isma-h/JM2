/** Préparation du texte des leçons pour le lecteur (fonctions pures). */

/** Retire un éventuel émoji de tête (« 🎯 Ce que… » → « Ce que… »). */
export function cleanHeading(text: string): string {
  return text.replace(/^[\p{Extended_Pictographic}️‍\s]+/u, "").trim() || text;
}

/**
 * Retire du corps Markdown ce que l'en-tête de page affiche déjà : le titre `# …` initial et la ligne de méta
 * `> ⏱ 45 min · …` qui le suit. Le reste du contenu est intact.
 */
export function stripLessonPreamble(body: string): string {
  const lines = body.split(/\r?\n/);
  let i = 0;
  const skipBlank = () => {
    while (i < lines.length && lines[i].trim() === "") i++;
  };
  skipBlank();
  if (/^#\s+/.test(lines[i] ?? "")) {
    i++;
    skipBlank();
    if (/^>\s*⏱/.test(lines[i] ?? "")) {
      i++;
      while (i < lines.length && /^>/.test(lines[i])) i++;
    }
  } else {
    return body;
  }
  return lines.slice(i).join("\n").replace(/^\s+/, "");
}

const SP = "[ \\u00a0\\u202f]";
/** « 10 $ », « 0,50 $/M », « 20,92 Md$ », « 3 k$ » : montant (chiffre, espace ou unité) suivi d'un dollar. */
const CURRENCY_DOLLAR = new RegExp(`(\\d(?:${SP}+|${SP}*(?:k|K|M|Md|Mds|G|B|bn)${SP}?))\\$(?![\\p{L}\\d])`, "gu");

/**
 * Les prix en dollars (« 0,10 $ par million de tokens … 10 $ ») étaient lus comme une formule `$…$` par remark-math
 * (texte en italique KaTeX, espaces perdus). On échappe en `\$` les dollars précédés d'un montant (chiffre suivi
 * d'une espace ou d'une unité k / M / Md…), hors blocs de code, code en ligne et blocs `$$ … $$`.
 * Une vraie formule ne se ferme pas par « chiffre + espace + $ » (on écrit `$n = 3$`) : elle reste intacte.
 */
export function escapeCurrencyDollars(md: string): string {
  if (!md.includes("$")) return md;
  const lines = md.split("\n");
  let fence: string | null = null;
  let displayMath = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const f = /^[\s>]*(`{3,}|~{3,})(.*)$/.exec(line);
    if (f) {
      if (fence === null) fence = f[1];
      else if (f[1][0] === fence[0] && f[1].length >= fence.length && f[2].trim() === "") fence = null;
      continue;
    }
    if (fence) continue;
    const t = line.trim();
    if (t.startsWith("$$")) {
      // « $$ » seul ouvre / ferme un bloc ; « $$ … $$ » sur une ligne est un bloc complet.
      if (t === "$$" || !(t.length > 4 && t.endsWith("$$"))) displayMath = !displayMath;
      continue;
    }
    if (displayMath && t.endsWith("$$")) {
      displayMath = false;
      continue;
    }
    if (displayMath || !line.includes("$")) continue;
    // Code en ligne laissé tel quel : on ne traite que les segments hors `…`.
    lines[i] = line
      .split(/(`+[^`]*`+)/)
      .map((seg, k) => (k % 2 === 1 ? seg : seg.replace(CURRENCY_DOLLAR, "$1\\$")))
      .join("");
  }
  return lines.join("\n");
}
