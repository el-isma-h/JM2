import { describe, expect, it } from "vitest";
import { calloutInfo } from "./callouts";

describe("type des encadrés", () => {
  it("🧭 : libellé en gras → En clair, Pas à pas, Pré-requis express", () => {
    expect(calloutInfo("🧭 En clair — Pour accueillir…", "En clair")).toEqual({ kind: "plain", labelled: true });
    expect(calloutInfo("🧭 Pas à pas pour débutant — Tapez…", "Pas à pas pour débutant")).toEqual({ kind: "steps", labelled: true });
    expect(calloutInfo("🧭 Pré-requis express — async / await — …", "Pré-requis express — async / await")).toEqual({ kind: "prereq", labelled: true });
    // 🧭 sans libellé reconnu : comportement antérieur (« En clair »).
    expect(calloutInfo("🧭 Pour les juristes…", null)).toEqual({ kind: "plain", labelled: false });
    expect(calloutInfo("🧭 Autre chose — …", "Autre chose")).toEqual({ kind: "plain", labelled: false });
  });

  it("nouveaux encadrés ✅ 🔍 🛠️ 💡 Autrement dit", () => {
    expect(calloutInfo("✅ Si vous ne retenez que 3 choses — 1. …", "Si vous ne retenez que 3 choses")?.kind).toBe("recap");
    expect(calloutInfo("🔍 Ce que fait ce code, ligne par ligne —", "Ce que fait ce code, ligne par ligne")?.kind).toBe("code");
    expect(calloutInfo("🛠️ Si ça ne marche pas —", "Si ça ne marche pas")?.kind).toBe("fix");
    expect(calloutInfo("🛠 Si ça ne marche pas —", "Si ça ne marche pas")?.kind).toBe("fix");
    expect(calloutInfo("💡 Autrement dit — Les cinq briques…", "Autrement dit")).toEqual({ kind: "restate", labelled: true });
  });

  it("encadrés existants inchangés", () => {
    expect(calloutInfo("💡 À retenir — …", "À retenir")).toEqual({ kind: "tip", labelled: false });
    expect(calloutInfo("⚠️ Piège fréquent — …", "Piège fréquent")?.kind).toBe("warn");
    expect(calloutInfo("🔗 Documentation officielle — …", "Documentation officielle")?.kind).toBe("link");
    expect(calloutInfo("⏱ Durée : 45 min", null)?.kind).toBe("meta");
    expect(calloutInfo("Une citation ordinaire", null)).toBeUndefined();
    expect(calloutInfo("✅ Coché", null)).toBeUndefined();
  });
});

describe("encadrés v1.4.1", () => {
  it("reconnaît « Ce que vous devez voir », « Exemple à la main » et « L'intuition d'abord »", () => {
    expect(calloutInfo("🔍 Ce que vous devez voir — x", "Ce que vous devez voir")).toEqual({ kind: "code", labelled: true });
    expect(calloutInfo("🔢 Exemple à la main — x", "Exemple à la main")).toEqual({ kind: "code", labelled: true });
    expect(calloutInfo("🧠 L'intuition d'abord — x", "L'intuition d'abord")).toEqual({ kind: "restate", labelled: true });
  });
});
