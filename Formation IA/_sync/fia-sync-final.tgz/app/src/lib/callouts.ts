/**
 * Encadrés des leçons (blockquotes) : type déduit de l'émoji ET du libellé en gras qui le suit (v1.4).
 *
 *   > 🧭 **En clair** — …                       → plain   (citation mise en avant)
 *   > 🧭 **Pas à pas pour débutant** — …        → steps   (style « étapes »)
 *   > 🧭 **Pré-requis express — sujet** — …     → prereq  (style « rappel »)
 *   > ✅ **Si vous ne retenez que 3 choses** — … → recap
 *   > 🔍 **Ce que fait ce code, ligne par ligne** — … → code
 *   > 🛠️ **Si ça ne marche pas** — …            → fix
 *   > 💡 **Autrement dit** — …                   → restate
 *   > 🔍 **Ce que vous devez voir** — … et 🔢 **Exemple à la main** — … → code · 🧠 **L'intuition d'abord** — … → restate (v1.4.1)
 *   > 💡 … (autres, ex. « À retenir »)  → tip · ⚠️ → warn · 🔗 → link · ⏱ → meta (inchangés)
 *
 * `labelled` : le libellé en gras est retiré du texte et affiché en en-tête d'encadré par le lecteur.
 * Un 🧭 sans libellé reconnu reste « En clair » (comportement antérieur). Fonction pure.
 */
export type CalloutKind = "plain" | "steps" | "prereq" | "recap" | "code" | "fix" | "restate" | "tip" | "warn" | "link" | "meta";

export type CalloutInfo = { kind: CalloutKind; labelled: boolean };

const norm = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[’']/g, "'")
    .toLowerCase()
    .trim();

/** Libellé (texte brut du gras de tête) → type, pour les encadrés à libellé. */
export function calloutFromLabel(emoji: string, label: string): CalloutKind | null {
  const l = norm(label);
  if (emoji === "🧭") {
    if (l.startsWith("pas a pas")) return "steps";
    if (l.startsWith("pre-requis") || l.startsWith("prerequis")) return "prereq";
    if (l.startsWith("en clair")) return "plain";
    return null;
  }
  if (emoji === "✅" && l.startsWith("si vous ne retenez")) return "recap";
  if (emoji === "🔍" && (l.startsWith("ce que fait ce code") || l.startsWith("ce que vous devez voir"))) return "code";
  if (emoji === "🔢" && l.startsWith("exemple")) return "code";
  if (emoji === "🧠" && l.startsWith("l'intuition")) return "restate";
  if (emoji === "🛠" && l.startsWith("si ca ne marche pas")) return "fix";
  if (emoji === "💡" && l.startsWith("autrement dit")) return "restate";
  return null;
}

const LEAD = /^\s*(🧭|✅|🔍|🔢|🧠|🛠️|🛠|💡|⚠️|⚠|🔗|⏱️?)\s*/u;

/**
 * Type d'un encadré à partir du texte brut de son début (`text`) et, s'il existe, du libellé en gras qui suit l'émoji.
 * Renvoie undefined pour une citation ordinaire.
 */
export function calloutInfo(text: string, boldLabel: string | null): CalloutInfo | undefined {
  const m = LEAD.exec(text);
  if (!m) return undefined;
  const emoji = m[1].replace(/️/g, "");
  if (boldLabel) {
    const kind = calloutFromLabel(emoji, boldLabel);
    if (kind) return { kind, labelled: true };
  }
  if (emoji === "🧭") return { kind: "plain", labelled: false };
  if (emoji === "💡") return { kind: "tip", labelled: false };
  if (emoji === "⚠") return { kind: "warn", labelled: false };
  if (emoji === "🔗") return { kind: "link", labelled: false };
  if (emoji === "⏱") return { kind: "meta", labelled: false };
  return undefined;
}

/** Libellé affiché pour un type d'encadré à libellé (le texte exact du gras est conservé quand il précise un sujet). */
export const CALLOUT_LABEL: Partial<Record<CalloutKind, string>> = {
  plain: "En clair",
  steps: "Pas à pas pour débutant",
  prereq: "Pré-requis express",
  recap: "Si vous ne retenez que 3 choses",
  code: "Ce que fait ce code, ligne par ligne",
  fix: "Si ça ne marche pas",
  restate: "Autrement dit",
};
