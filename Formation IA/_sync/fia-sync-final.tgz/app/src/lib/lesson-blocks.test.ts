import { describe, expect, it } from "vitest";
import { extractLessonBlocks, findMissionBlock, findQuizBlock, flashQuizRef, missionRef, MISSION_MAX_XP, parseMissionBlock, parseQuizBlock, toPublicFlashQuiz } from "./lesson-blocks";

const quiz = (q: string, answer = 1) => `\`\`\`quiz\n${JSON.stringify({ q, options: ["A", "B", "C"], answer, explanation: "Parce que." })}\n\`\`\``;
const mission = JSON.stringify({ title: "Trouvez le prix", url: "https://platform.claude.com/docs/en/about-claude/pricing", steps: ["Ouvrir", "Lire"], question: "Combien ?", hint: "Ligne Haiku", answer: "0,50 $", xp: 15 });

const body = [
  "# Titre",
  "",
  "## Section",
  quiz("Première ?"),
  "",
  "````markdown",
  "```quiz",
  '{"q":"exemple dans un exemple","options":["a","b"],"answer":0}',
  "```",
  "````",
  "",
  "```mission",
  mission,
  "```",
  "",
  "```quiz",
  "{ pas du json",
  "```",
  "",
  quiz("Troisième ?", 2),
].join("\n");

describe("extractLessonBlocks", () => {
  it("indexe les blocs par type, dans l'ordre, y compris les invalides, en ignorant les exemples imbriqués", () => {
    const blocks = extractLessonBlocks(body);
    expect(blocks.map((b) => `${b.kind}:${b.index}`)).toEqual(["quiz:0", "mission:0", "quiz:1", "quiz:2"]);
    expect(blocks[2].kind === "quiz" && blocks[2].quiz).toBeNull();
    expect(findQuizBlock(body, 2)?.q).toBe("Troisième ?");
    expect(findQuizBlock(body, 1)).toBeNull();
    expect(findMissionBlock(body, 0)?.xp).toBe(15);
    expect(findMissionBlock(body, 1)).toBeNull();
  });
  it("références stables", () => {
    expect(flashQuizRef("L001", 0)).toBe("quizflash:L001:0");
    expect(missionRef("L001", 1)).toBe("mission:L001:1");
  });
});

describe("parseQuizBlock", () => {
  it("valide un quiz et accepte vrai/faux", () => {
    expect(parseQuizBlock('{"q":"Q","options":["Vrai","Faux"],"answer":1,"explanation":"E","type":"vrai_faux"}')).toEqual({ q: "Q", options: ["Vrai", "Faux"], answer: 1, explanation: "E", type: "vrai_faux" });
  });
  it("rejette un JSON invalide ou incohérent", () => {
    expect(parseQuizBlock("{")).toBeNull();
    expect(parseQuizBlock('{"q":"Q","options":["A"],"answer":0}')).toBeNull();
    expect(parseQuizBlock('{"q":"Q","options":["A","B"],"answer":2}')).toBeNull();
    expect(parseQuizBlock('["q"]')).toBeNull();
  });
  it("version publique sans réponse ni explication", () => {
    const q = parseQuizBlock('{"q":"Q","options":["A","B"],"answer":1,"explanation":"E"}')!;
    expect(toPublicFlashQuiz(q)).toEqual({ q: "Q", options: ["A", "B"], type: "qcm" });
  });
});

describe("parseMissionBlock", () => {
  it("valide une mission, XP par défaut et borné", () => {
    expect(parseMissionBlock(mission)).toMatchObject({ title: "Trouvez le prix", steps: ["Ouvrir", "Lire"], hint: "Ligne Haiku", xp: 15 });
    const noXp = JSON.parse(mission);
    delete noXp.xp;
    delete noXp.hint;
    expect(parseMissionBlock(JSON.stringify(noXp))).toMatchObject({ xp: 10, hint: null });
    expect(parseMissionBlock(JSON.stringify({ ...noXp, xp: 999 }))?.xp).toBe(MISSION_MAX_XP);
  });
  it("refuse une URL non https", () => {
    expect(parseMissionBlock(JSON.stringify({ ...JSON.parse(mission), url: "javascript:alert(1)" }))).toBeNull();
  });
});
