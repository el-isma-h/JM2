/**
 * Recherche et filtres du lexique (/lexique) : recherche instantanée insensible à la casse et aux accents
 * (terme, définition, analogie, exemple, catégorie), filtres catégorie et niveau. Fonctions pures (client).
 */
import type { GlossaryTerm } from "@/content/types";
import { normalizeSearch, searchTokens } from "./resource-filter";

export type LexiconFilters = { query: string; categorie: string | null; niveau: string | null };

export function filterLexicon(terms: readonly GlossaryTerm[], f: LexiconFilters): GlossaryTerm[] {
  const tokens = searchTokens(f.query);
  const scored: { t: GlossaryTerm; score: number }[] = [];
  for (const t of terms) {
    if (f.categorie && t.categorie !== f.categorie) continue;
    if (f.niveau && t.niveau !== f.niveau) continue;
    if (tokens.length === 0) {
      scored.push({ t, score: 0 });
      continue;
    }
    const name = normalizeSearch(t.terme);
    const hay = normalizeSearch([t.terme, t.slug, t.categorie, t.definition, t.analogie ?? "", t.exemple ?? ""].join(" "));
    if (!tokens.every((k) => hay.includes(k))) continue;
    // Le terme lui-même d'abord : nom exact, puis commençant par la recherche, puis le contenant.
    const q = tokens.join(" ");
    const score = name === q ? 0 : name.startsWith(q) ? 1 : name.includes(q) ? 2 : 3;
    scored.push({ t, score });
  }
  return scored.sort((a, b) => a.score - b.score).map((s) => s.t);
}

/** Initiale d'un terme pour l'index alphabétique (« Éval » → « E », « 3D » → « # »). */
export function initialOf(terme: string): string {
  const c = normalizeSearch(terme).charAt(0).toUpperCase();
  return /[A-Z]/.test(c) ? c : "#";
}

/** Catégories et niveaux présents (pour les filtres), triés. */
export function lexiconFacets(terms: readonly GlossaryTerm[]): { categories: { id: string; count: number }[]; niveaux: string[] } {
  const cats = new Map<string, number>();
  const lv = new Set<string>();
  for (const t of terms) {
    cats.set(t.categorie, (cats.get(t.categorie) ?? 0) + 1);
    if (t.niveau) lv.add(t.niveau);
  }
  return {
    categories: [...cats.entries()].map(([id, count]) => ({ id, count })).sort((a, b) => a.id.localeCompare(b.id, "fr")),
    niveaux: [...lv].sort(),
  };
}
