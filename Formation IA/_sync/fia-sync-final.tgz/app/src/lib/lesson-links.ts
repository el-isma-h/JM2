/**
 * Plugin remark (v1.4) : transforme les identifiants de leçon écrits en clair (« L021 », « L180-L184 », cellules de
 * tableau « | L005 | ») en liens internes `/lecon/Lxxx`. Seuls les ids connus (`ids`) sont liés ; le texte des liens,
 * du code et des blocs ```quiz / ```mission n'est pas touché. Fonction pure, sans E/S.
 */
type MdNode = { type: string; value?: string; url?: string; children?: MdNode[] };

const SKIP = new Set(["link", "linkReference", "code", "inlineCode", "html", "definition", "image", "imageReference", "math", "inlineMath"]);
const LESSON_ID = /\bL\d{3}\b/g;

export const lessonHrefPattern = /^\/lecon\/(L\d{3})$/;

function splitText(value: string, ids: ReadonlySet<string>): MdNode[] | null {
  LESSON_ID.lastIndex = 0;
  if (!LESSON_ID.test(value)) return null;
  LESSON_ID.lastIndex = 0;
  const out: MdNode[] = [];
  let last = 0;
  let changed = false;
  for (const m of value.matchAll(LESSON_ID)) {
    if (!ids.has(m[0])) continue;
    const at = m.index ?? 0;
    if (at > last) out.push({ type: "text", value: value.slice(last, at) });
    out.push({ type: "link", url: `/lecon/${m[0]}`, children: [{ type: "text", value: m[0] }] });
    last = at + m[0].length;
    changed = true;
  }
  if (!changed) return null;
  if (last < value.length) out.push({ type: "text", value: value.slice(last) });
  return out;
}

export function linkLessonIds(tree: MdNode, ids: ReadonlySet<string>): void {
  if (!tree.children || SKIP.has(tree.type)) return;
  const next: MdNode[] = [];
  for (const child of tree.children) {
    if (child.type === "text" && typeof child.value === "string") {
      const parts = splitText(child.value, ids);
      if (parts) {
        next.push(...parts);
        continue;
      }
    } else linkLessonIds(child, ids);
    next.push(child);
  }
  tree.children = next;
}

/** `remarkPlugins={[[remarkLessonLinks, ids]]}` */
export function remarkLessonLinks(ids: readonly string[]) {
  const set = new Set(ids);
  return (tree: unknown) => linkLessonIds(tree as MdNode, set);
}
