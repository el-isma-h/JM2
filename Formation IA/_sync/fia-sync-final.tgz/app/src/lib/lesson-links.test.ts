import { describe, expect, it } from "vitest";
import { fromMarkdown } from "mdast-util-from-markdown";
import { linkLessonIds } from "./lesson-links";

type N = { type: string; value?: string; url?: string; children?: N[] };
const links = (n: N): string[] => (n.type === "link" ? [n.url!] : (n.children ?? []).flatMap(links));
const ids = new Set(["L005", "L021", "L180", "L184"]);

function run(md: string) {
  const tree = fromMarkdown(md) as unknown as N;
  linkLessonIds(tree, ids);
  return tree;
}

describe("liens vers les leçons", () => {
  it("lie les ids connus dans le texte, les tableaux et les plages", () => {
    expect(links(run("Leçon : L021 « Cas d'usage » et L180-L184."))).toEqual(["/lecon/L021", "/lecon/L180", "/lecon/L184"]);
    const t = run("| Leçon | Titre |\n|---|---|\n| L005 | LLM |\n");
    expect(links(t)).toEqual(["/lecon/L005"]);
  });

  it("garde le texte autour, ignore les ids inconnus, le code et les liens existants", () => {
    const t = run("Voir L021, puis L999. `L005` [L005](https://x.y)\n\n```quiz\n{\"q\":\"L005\"}\n```");
    expect(links(t)).toEqual(["/lecon/L021", "https://x.y"]);
    const p = t.children![0];
    expect(p.children![0]).toEqual({ type: "text", value: "Voir " });
    expect(p.children![2]).toEqual({ type: "text", value: ", puis L999. " });
    expect(links(run("XL0050 et L0050"))).toEqual([]);
  });
});
