/**
 * Blocs pédagogiques des leçons (FORMAT.md § « Enrichissements pédagogiques ») : ```quiz et ```mission.
 *
 * - `extractLessonBlocks(body)` : liste ordonnée des blocs d'une leçon, avec leur index (0-based) PAR TYPE.
 *   L'index est la position du bloc parmi les blocs de même type, dans l'ordre du document, qu'il soit valide ou non :
 *   c'est lui qui forme les références stables `quizflash:{lessonId}:{index}` et `mission:{lessonId}:{index}`.
 * - `remarkLessonBlocks` : plugin remark du lecteur qui pose le même index sur les nœuds `code` (même analyseur
 *   micromark que react-markdown → même ordre que côté serveur).
 * - `parseQuizBlock` / `parseMissionBlock` : validation stricte du JSON ; null si invalide (le lecteur affiche alors
 *   le bloc brut, sans planter).
 *
 * Fonctions pures, sans E/S : utilisables par les server actions, le lecteur et les tests.
 */
import { fromMarkdown } from "mdast-util-from-markdown";

export type LessonBlockKind = "quiz" | "mission";

export type FlashQuiz = {
  q: string;
  options: string[];
  /** Index 0-based de la bonne réponse. */
  answer: number;
  explanation: string;
  type: "qcm" | "vrai_faux";
};

/** Version sûre pour le client (avant réponse) : sans `answer` ni `explanation`. */
export type PublicFlashQuiz = Omit<FlashQuiz, "answer" | "explanation">;

export type Mission = {
  title: string;
  url: string;
  steps: string[];
  question: string;
  hint: string | null;
  answer: string;
  xp: number;
};

export type LessonBlock =
  | { kind: "quiz"; index: number; raw: string; quiz: FlashQuiz | null }
  | { kind: "mission"; index: number; raw: string; mission: Mission | null };

export const MISSION_DEFAULT_XP = 10;
export const MISSION_MAX_XP = 50;
export const FLASH_QUIZ_XP = 5;

const isStr = (v: unknown): v is string => typeof v === "string" && v.trim().length > 0;

function parseJson(raw: string): Record<string, unknown> | null {
  try {
    const v: unknown = JSON.parse(raw);
    return v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

export function parseQuizBlock(raw: string): FlashQuiz | null {
  const o = parseJson(raw);
  if (!o) return null;
  const { q, options, answer, explanation, type } = o;
  if (!isStr(q) || !Array.isArray(options) || options.length < 2 || options.length > 6 || !options.every(isStr)) return null;
  if (typeof answer !== "number" || !Number.isInteger(answer) || answer < 0 || answer >= options.length) return null;
  if (explanation !== undefined && typeof explanation !== "string") return null;
  return { q: q.trim(), options: options.map((x) => x.trim()), answer, explanation: (explanation ?? "").trim(), type: type === "vrai_faux" ? "vrai_faux" : "qcm" };
}

export function parseMissionBlock(raw: string): Mission | null {
  const o = parseJson(raw);
  if (!o) return null;
  const { title, url, steps, question, hint, answer, xp } = o;
  if (!isStr(title) || !isStr(url) || !/^https:\/\/\S+$/.test(url.trim()) || !isStr(question) || !isStr(answer)) return null;
  if (steps !== undefined && (!Array.isArray(steps) || !steps.every(isStr))) return null;
  if (hint !== undefined && hint !== null && typeof hint !== "string") return null;
  const n = typeof xp === "number" && Number.isFinite(xp) ? Math.round(xp) : MISSION_DEFAULT_XP;
  return {
    title: title.trim(),
    url: url.trim(),
    steps: ((steps as string[] | undefined) ?? []).map((s) => s.trim()),
    question: question.trim(),
    hint: isStr(hint) ? hint.trim() : null,
    answer: answer.trim(),
    xp: Math.min(MISSION_MAX_XP, Math.max(1, n)),
  };
}

export function toPublicFlashQuiz(q: FlashQuiz): PublicFlashQuiz {
  return { q: q.q, options: q.options, type: q.type };
}

// ---------- Parcours de l'arbre Markdown ----------

type MdNode = { type: string; lang?: string | null; value?: string; children?: MdNode[]; data?: Record<string, unknown> };

function blockKind(node: MdNode): LessonBlockKind | null {
  if (node.type !== "code") return null;
  const lang = (node.lang ?? "").trim().toLowerCase();
  return lang === "quiz" || lang === "mission" ? lang : null;
}

/** Parcours en profondeur, ordre du document. */
function walk(node: MdNode, visit: (n: MdNode) => void) {
  visit(node);
  for (const c of node.children ?? []) walk(c, visit);
}

export function extractLessonBlocks(body: string): LessonBlock[] {
  const out: LessonBlock[] = [];
  const counters = { quiz: 0, mission: 0 };
  walk(fromMarkdown(body) as unknown as MdNode, (n) => {
    const kind = blockKind(n);
    if (!kind) return;
    const raw = n.value ?? "";
    const index = counters[kind]++;
    if (kind === "quiz") out.push({ kind, index, raw, quiz: parseQuizBlock(raw) });
    else out.push({ kind, index, raw, mission: parseMissionBlock(raw) });
  });
  return out;
}

export function findQuizBlock(body: string, index: number): FlashQuiz | null {
  const b = extractLessonBlocks(body).find((x) => x.kind === "quiz" && x.index === index);
  return b && b.kind === "quiz" ? b.quiz : null;
}

export function findMissionBlock(body: string, index: number): Mission | null {
  const b = extractLessonBlocks(body).find((x) => x.kind === "mission" && x.index === index);
  return b && b.kind === "mission" ? b.mission : null;
}

/** Référence XP / révision d'un quiz éclair. */
export const flashQuizRef = (lessonId: string, index: number) => `quizflash:${lessonId}:${index}`;
export const missionRef = (lessonId: string, index: number) => `mission:${lessonId}:${index}`;

/**
 * Plugin remark : pose `data-block` et `data-block-index` sur les blocs ```quiz / ```mission (attributs HTML du
 * `<code>`), pour que le lecteur sache quel bloc il rend.
 */
export function remarkLessonBlocks() {
  return (tree: unknown) => {
    const counters = { quiz: 0, mission: 0 };
    walk(tree as MdNode, (n) => {
      const kind = blockKind(n);
      if (!kind) return;
      const index = counters[kind]++;
      const data = (n.data ??= {});
      data.hProperties = { ...((data.hProperties as Record<string, unknown>) ?? {}), dataBlock: kind, dataBlockIndex: String(index) };
    });
  };
}
