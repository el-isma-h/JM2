import { describe, expect, it } from "vitest";
import type { GlossaryTerm } from "@/content/types";
import { filterLexicon, initialOf, lexiconFacets } from "./lexicon-filter";
import { parseGlossary } from "@/content/loader";

const t = (terme: string, categorie: string, niveau: string, definition = "…"): GlossaryTerm => ({ terme, slug: terme.toLowerCase(), categorie, niveau, definition, analogie: null, exemple: null, voirAussi: [], lecons: [], source: null });
const terms = [t("Token", "LLM", "N1", "Morceau de texte"), t("Tokenizer", "LLM", "N2", "Découpe le texte en tokens"), t("Embedding", "RAG", "N3", "Vecteur représentant un texte"), t("Évaluation", "Qualité", "N4")];

describe("filterLexicon", () => {
  it("recherche sans accents, terme exact d'abord", () => {
    expect(filterLexicon(terms, { query: "token", categorie: null, niveau: null }).map((x) => x.terme)).toEqual(["Token", "Tokenizer"]);
    expect(filterLexicon(terms, { query: "evaluation", categorie: null, niveau: null })).toHaveLength(1);
    expect(filterLexicon(terms, { query: "texte", categorie: null, niveau: null })).toHaveLength(3);
  });
  it("filtres catégorie et niveau", () => {
    expect(filterLexicon(terms, { query: "", categorie: "LLM", niveau: null })).toHaveLength(2);
    expect(filterLexicon(terms, { query: "", categorie: "LLM", niveau: "N2" }).map((x) => x.terme)).toEqual(["Tokenizer"]);
  });
  it("initiales et facettes", () => {
    expect(initialOf("Évaluation")).toBe("E");
    expect(initialOf("3D")).toBe("#");
    expect(lexiconFacets(terms)).toEqual({ categories: [{ id: "LLM", count: 2 }, { id: "Qualité", count: 1 }, { id: "RAG", count: 1 }], niveaux: ["N1", "N2", "N3", "N4"] });
  });
});

describe("parseGlossary", () => {
  it("ignore les entrées invalides et les doublons, trie par terme", () => {
    const g = parseGlossary(
      JSON.stringify([
        { terme: "Token", slug: "token", categorie: "LLM", niveau: "N1", definition: "Morceau.", lecons: ["l005", "x"], source: { title: "Doc", url: "https://example.org" } },
        { terme: "Agent", slug: "agent", definition: "Programme." },
        { terme: "Sans définition", slug: "sans" },
        { terme: "Token bis", slug: "token", definition: "Doublon." },
      ]),
    );
    expect(g.status).toBe("ok");
    expect(g.skipped).toBe(2);
    expect(g.terms.map((x) => x.slug)).toEqual(["agent", "token"]);
    expect(g.terms[1].lecons).toEqual(["L005"]);
    expect(g.terms[0]).toMatchObject({ categorie: "Général", niveau: "", source: null });
  });
  it("JSON illisible → lexique vide", () => {
    expect(parseGlossary("[{")).toEqual({ terms: [], status: "invalid", skipped: 0 });
  });
});
