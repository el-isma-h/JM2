/**
 * Connexion unique depuis Next Formation (route /sso) : anti-rejeu (table `sso_nonces`) et rapprochement du compte.
 *
 *   const v = verifySsoToken(token, secret);              // src/lib/sso.ts (signature, version, dates)
 *   if (!(await consumeSsoNonce(v.payload)))  → jeton rejoué
 *   const r = await resolveSsoUser(v.payload);            // compte démo, ou compte trouvé / créé par e-mail
 *   await createSession(r.user.id);
 */
import "server-only";
import { eq, lt } from "drizzle-orm";
import { db, schema } from "@/db";
import { normalizeEntitlements } from "@/domain/entitlements";
import { randomToken } from "@/lib/crypto";
import type { SsoPayload } from "@/lib/sso";
import { demoEnabled, findDemoUser } from "./auth";
import { hashPassword } from "./passwords";

/**
 * Enregistre le nonce ; false s'il a déjà été vu (rejeu). Les nonces expirés sont purgés au passage
 * (un jeton expiré est refusé avant d'arriver ici, la purge ne réouvre donc aucune fenêtre de rejeu).
 */
export async function consumeSsoNonce(payload: Pick<SsoPayload, "nonce" | "exp">, now = new Date()): Promise<boolean> {
  await db.delete(schema.ssoNonces).where(lt(schema.ssoNonces.expiresAt, now));
  const inserted = await db
    .insert(schema.ssoNonces)
    .values({ nonce: payload.nonce, expiresAt: new Date(payload.exp * 1000), usedAt: now })
    .onConflictDoNothing()
    .returning({ nonce: schema.ssoNonces.nonce });
  return inserted.length === 1;
}

export type SsoResolve =
  | { ok: true; user: typeof schema.users.$inferSelect; created: boolean }
  | { ok: false; reason: "demo_unavailable" | "disabled" };

/**
 * `demo: true` → compte démo existant (jamais créé ici). Sinon : compte trouvé par e-mail (droits mis à jour, nom
 * complété s'il était vide, mot de passe conservé) ou créé (`ssoOnly`, mot de passe aléatoire jamais communiqué).
 */
export async function resolveSsoUser(payload: SsoPayload): Promise<SsoResolve> {
  if (payload.demo) {
    const demo = demoEnabled() ? await findDemoUser() : null;
    return demo ? { ok: true, user: demo, created: false } : { ok: false, reason: "demo_unavailable" };
  }
  const entitlements = normalizeEntitlements(payload.entitlements);
  const [existing] = await db.select().from(schema.users).where(eq(schema.users.email, payload.email)).limit(1);
  if (existing) {
    if (existing.disabledAt) return { ok: false, reason: "disabled" };
    const patch: Partial<typeof schema.users.$inferInsert> = { entitlements };
    if (!existing.firstName && payload.firstName) patch.firstName = payload.firstName;
    if (!existing.lastName && payload.lastName) patch.lastName = payload.lastName;
    const [user] = await db.update(schema.users).set(patch).where(eq(schema.users.id, existing.id)).returning();
    return { ok: true, user, created: false };
  }
  const [user] = await db
    .insert(schema.users)
    .values({
      email: payload.email,
      firstName: payload.firstName,
      lastName: payload.lastName,
      role: "learner",
      ssoOnly: true,
      entitlements,
      // Aucun mot de passe utilisable : l'accès est géré par Next Formation.
      passwordHash: await hashPassword(randomToken(32)),
    })
    .returning();
  return { ok: true, user, created: true };
}
