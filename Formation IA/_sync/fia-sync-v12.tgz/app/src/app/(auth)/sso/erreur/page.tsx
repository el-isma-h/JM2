import type { Metadata } from "next";
import Link from "next/link";
import { ArrowSquareOut } from "@phosphor-icons/react/ssr";
import { nfLinks } from "@/lib/nf";
import { routes } from "@/lib/paths";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = { title: "Connexion depuis Next Formation" };

/** Messages volontairement non techniques : le motif précis est dans les journaux du serveur (route /sso). */
const MESSAGES: Record<string, { title: string; text: string }> = {
  config: {
    title: "Connexion unique non configurée",
    text: "La connexion depuis Next Formation n'est pas encore activée sur cet espace. Contactez votre organisme de formation.",
  },
  invalide: {
    title: "Lien de connexion invalide",
    text: "Ce lien de connexion n'est pas reconnu. Rouvrez votre espace e-learning depuis votre dossier Next Formation.",
  },
  expire: {
    title: "Lien de connexion expiré",
    text: "Ce lien n'est valable que quelques minutes. Rouvrez votre espace e-learning depuis votre dossier Next Formation pour obtenir un nouveau lien.",
  },
  rejoue: {
    title: "Lien déjà utilisé",
    text: "Chaque lien de connexion ne sert qu'une fois. Rouvrez votre espace e-learning depuis votre dossier Next Formation.",
  },
  demo: {
    title: "Démonstration indisponible",
    text: "Le compte de démonstration n'est pas disponible pour le moment. Réessayez plus tard ou contactez votre organisme de formation.",
  },
  compte: {
    title: "Compte indisponible",
    text: "Ce compte ne peut pas être ouvert pour le moment. Contactez votre organisme de formation.",
  },
  trop: {
    title: "Trop de tentatives",
    text: "Patientez une minute puis rouvrez votre espace e-learning depuis votre dossier Next Formation.",
  },
};

export default async function SsoErreurPage({ searchParams }: { searchParams: Promise<{ code?: string }> }) {
  const { code } = await searchParams;
  const m = MESSAGES[code ?? ""] ?? MESSAGES.invalide;
  const nf = nfLinks();
  return (
    <div>
      <p className="etiquette">Connexion depuis Next Formation</p>
      <h1 className="mt-4 text-[30px] text-ink">{m.title}</h1>
      <p className="mt-3 text-[13.5px] text-ink-2">{m.text}</p>
      <div className="mt-8 flex flex-col gap-3">
        {nf ? (
          <Button asChild size="lg" className="w-full">
            <a href={nf.dossier}>
              Ouvrir mon dossier Next Formation <ArrowSquareOut size={14} aria-hidden />
            </a>
          </Button>
        ) : null}
        <Button asChild variant={nf ? "secondary" : "primary"} size="lg" className="w-full">
          <Link href={routes.login}>Aller à la connexion</Link>
        </Button>
      </div>
    </div>
  );
}
