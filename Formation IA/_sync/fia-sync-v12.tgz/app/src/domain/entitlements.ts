/**
 * Droits par niveau (« entitlements ») transmis par Next Formation dans le jeton SSO.
 *
 * - `null` / `undefined` : aucune restriction, tous les niveaux sont accessibles (comportement historique des comptes
 *   invités et du compte démo).
 * - tableau de niveaux (`["N1", "N2"]`) : seuls ces niveaux sont inclus dans l'inscription ; les autres sont
 *   verrouillés dans le parcours (message « Ce niveau n'est pas inclus dans votre inscription »), quel que soit l'état
 *   du déblocage séquentiel ou des déblocages manuels.
 * - l'offre `PARCOURS` (N1 à N4) est acceptée telle quelle et développée en N1-N4.
 */
import type { LevelId } from "./types";

export type Entitlements = readonly string[] | null | undefined;

export const PARCOURS_LEVELS: readonly LevelId[] = ["N1", "N2", "N3", "N4"];

/** Normalise une liste de droits : majuscules, `PARCOURS` développé, doublons retirés, codes inconnus ignorés. */
export function normalizeEntitlements(raw: unknown): LevelId[] | null {
  if (raw === null || raw === undefined) return null;
  if (!Array.isArray(raw)) return [];
  const out = new Set<LevelId>();
  for (const item of raw) {
    if (typeof item !== "string") continue;
    const code = item.trim().toUpperCase();
    if (code === "PARCOURS") PARCOURS_LEVELS.forEach((l) => out.add(l));
    else if (/^N[1-9]$/.test(code)) out.add(code);
  }
  return [...out].sort();
}

/** Le niveau est-il inclus dans l'inscription ? (`null` = tous les niveaux). */
export function isLevelAllowed(entitlements: Entitlements, levelId: LevelId): boolean {
  if (entitlements === null || entitlements === undefined) return true;
  const wanted = levelId.toUpperCase();
  return entitlements.some((e) => {
    const code = String(e).trim().toUpperCase();
    return code === wanted || (code === "PARCOURS" && PARCOURS_LEVELS.includes(wanted));
  });
}
