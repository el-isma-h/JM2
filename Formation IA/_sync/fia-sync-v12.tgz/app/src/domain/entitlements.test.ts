import { describe, expect, it } from "vitest";
import { isLevelAllowed, normalizeEntitlements } from "./entitlements";
import { emptyLearnerState, type LearnerState, type ProgrammeStructure } from "./types";
import { canAccessLesson, canOpenExam, canTakeQuiz, computeAccess } from "./unlock";

describe("isLevelAllowed", () => {
  it("null / undefined = tous les niveaux (comptes invités)", () => {
    expect(isLevelAllowed(null, "N1")).toBe(true);
    expect(isLevelAllowed(undefined, "N5")).toBe(true);
  });
  it("liste de niveaux : seuls ceux-ci", () => {
    expect(isLevelAllowed(["N1", "N2"], "N1")).toBe(true);
    expect(isLevelAllowed(["N1", "N2"], "N3")).toBe(false);
    expect(isLevelAllowed([], "N1")).toBe(false);
  });
  it("PARCOURS = N1 à N4, pas N5 ; casse ignorée", () => {
    expect(isLevelAllowed(["PARCOURS"], "N4")).toBe(true);
    expect(isLevelAllowed(["PARCOURS"], "N5")).toBe(false);
    expect(isLevelAllowed(["parcours", "n5"], "N5")).toBe(true);
    expect(isLevelAllowed(["n2"], "N2")).toBe(true);
  });
});

describe("normalizeEntitlements", () => {
  it("null reste null ; liste normalisée, PARCOURS développé, inconnus ignorés", () => {
    expect(normalizeEntitlements(null)).toBeNull();
    expect(normalizeEntitlements(undefined)).toBeNull();
    expect(normalizeEntitlements(["n2", "N1", "N1", "X9", 3])).toEqual(["N1", "N2"]);
    expect(normalizeEntitlements(["PARCOURS", "N5"])).toEqual(["N1", "N2", "N3", "N4", "N5"]);
    expect(normalizeEntitlements("N1")).toEqual([]);
  });
});

const structure: ProgrammeStructure = {
  levels: [
    { id: "N1", modules: [{ id: "M01", lessons: ["L001", "L002"] }] },
    { id: "N2", modules: [{ id: "M02", lessons: ["L003"] }] },
    { id: "N3", modules: [{ id: "M03", lessons: ["L004"] }] },
  ],
};

function state(p: Partial<{ completedLessons: string[]; passedQuizzes: string[]; passedExams: string[]; modules: string[]; levels: string[]; entitlements: string[] | null }> = {}): LearnerState {
  const s = emptyLearnerState();
  return {
    ...s,
    completedLessons: new Set(p.completedLessons ?? []),
    passedQuizzes: new Set(p.passedQuizzes ?? []),
    passedExams: new Set(p.passedExams ?? []),
    manualUnlocks: { modules: new Set(p.modules ?? []), levels: new Set(p.levels ?? []) },
    entitlements: p.entitlements,
  };
}

describe("computeAccess avec droits par niveau", () => {
  it("sans droits (undefined) : comportement inchangé, entitled = true partout", () => {
    const m = computeAccess(structure, state({ passedExams: ["N1"] }));
    expect(m.levels.N1.entitled && m.levels.N2.entitled && m.levels.N3.entitled).toBe(true);
    expect(m.levels.N2.unlocked).toBe(true);
    expect(canAccessLesson(m, "L003")).toBe(true);
  });

  it("niveau hors droits : verrouillé en bloc même si l'examen précédent est réussi", () => {
    const m = computeAccess(structure, state({ passedExams: ["N1", "N2"], completedLessons: ["L001", "L002", "L003"], passedQuizzes: ["M01", "M02"], entitlements: ["N1"] }));
    expect(m.levels.N1.unlocked).toBe(true);
    expect(m.levels.N2.entitled).toBe(false);
    expect(m.levels.N2.unlocked).toBe(false);
    expect(m.levels.N2.state).toBe("completed"); // examen réussi : l'historique reste visible
    expect(m.modules.M02.unlocked).toBe(false);
    expect(canAccessLesson(m, "L003")).toBe(false);
    expect(canTakeQuiz(m, "M02")).toBe(false);
    expect(canOpenExam(m, "N3")).toBe(false);
    expect(m.levels.N3.unlocked).toBe(false);
  });

  it("le déblocage manuel ne contourne pas les droits", () => {
    const m = computeAccess(structure, state({ levels: ["N3"], modules: ["M02"], entitlements: ["N1"] }));
    expect(m.levels.N3.unlocked).toBe(false);
    expect(m.modules.M02.unlocked).toBe(false);
    expect(canAccessLesson(m, "L004")).toBe(false);
  });

  it("le déblocage séquentiel reste identique à l'intérieur des droits", () => {
    const m = computeAccess(structure, state({ entitlements: ["N1", "N2"] }));
    expect(canAccessLesson(m, "L001")).toBe(true);
    expect(canAccessLesson(m, "L002")).toBe(false);
    expect(m.levels.N2.entitled).toBe(true);
    expect(m.levels.N2.unlocked).toBe(false); // examen N1 non réussi
    const after = computeAccess(structure, state({ passedExams: ["N1"], entitlements: ["N1", "N2"] }));
    expect(after.levels.N2.unlocked).toBe(true);
    expect(after.levels.N3.unlocked).toBe(false);
    expect(after.levels.N3.entitled).toBe(false);
  });
});
