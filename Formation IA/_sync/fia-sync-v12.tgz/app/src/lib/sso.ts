/**
 * Jeton de connexion unique Next Formation → Next Formation IA (contrat : next-formation/docs/formation-ia-integration.md).
 *
 * Format : `<payload>.<signature>` avec payload = base64url(JSON) et signature = base64url(HMAC-SHA256(payload, secret)).
 * JSON : { v: 1, sub, email, firstName, lastName, iat, exp (= iat + 300 s), nonce (24 car.), demo, entitlements,
 *         orgSlug, enrollmentId, back }.
 *
 * Ce module ne touche ni à la base ni aux cookies (testable) : `verifySsoToken` vérifie la forme, la signature
 * (comparaison en temps constant), la version, les dates ; la détection de rejeu (nonce) est faite par
 * `src/server/sso.ts` avec la table `sso_nonces`. `signSsoToken` sert aux tests et à la recette locale.
 */
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

export const SSO_VERSION = 1;
/** Durée de vie maximale acceptée (le jeton est émis pour 300 s ; tolérance pour une horloge un peu décalée). */
export const SSO_MAX_TTL_SECONDS = 15 * 60;
/** Tolérance sur `iat` dans le futur (horloges désynchronisées). */
export const SSO_CLOCK_SKEW_SECONDS = 60;
export const SSO_MIN_SECRET_LENGTH = 32;

export type SsoPayload = {
  v: number;
  /** Identifiant de l'utilisateur côté Next Formation. */
  sub: string;
  email: string;
  firstName: string;
  lastName: string;
  /** Secondes epoch. */
  iat: number;
  exp: number;
  nonce: string;
  demo: boolean;
  /** Niveaux inclus (["N1","N2"], "PARCOURS" accepté) ; null = tous. */
  entitlements: string[] | null;
  orgSlug: string | null;
  enrollmentId: string | null;
  /** URL de retour vers le dossier Next Formation. */
  back: string | null;
};

export type SsoFailure = "malformed" | "signature" | "version" | "expired" | "not_yet_valid" | "payload";
export type SsoVerification = { ok: true; payload: SsoPayload } | { ok: false; reason: SsoFailure };

function b64url(input: Buffer | string): string {
  return Buffer.from(input).toString("base64url");
}

function hmac(payload: string, secret: string): Buffer {
  return createHmac("sha256", secret).update(payload).digest();
}

/** Signe un jeton (tests, recette locale). `iat`/`exp` par défaut : maintenant et +300 s. */
export function signSsoToken(input: Partial<SsoPayload> & { email: string }, secret: string, now = new Date()): string {
  const iat = input.iat ?? Math.floor(now.getTime() / 1000);
  const payload: SsoPayload = {
    v: input.v ?? SSO_VERSION,
    sub: input.sub ?? "nf-user",
    email: input.email,
    firstName: input.firstName ?? "",
    lastName: input.lastName ?? "",
    iat,
    exp: input.exp ?? iat + 300,
    nonce: input.nonce ?? randomBytes(18).toString("base64url").slice(0, 24),
    demo: input.demo ?? false,
    entitlements: input.entitlements === undefined ? null : input.entitlements,
    orgSlug: input.orgSlug ?? null,
    enrollmentId: input.enrollmentId ?? null,
    back: input.back ?? null,
  };
  const encoded = b64url(JSON.stringify(payload));
  return `${encoded}.${b64url(hmac(encoded, secret))}`;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function parsePayload(json: string): SsoPayload | null {
  let raw: unknown;
  try {
    raw = JSON.parse(json);
  } catch {
    return null;
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
  const r = raw as Record<string, unknown>;
  const email = typeof r.email === "string" ? r.email.trim().toLowerCase() : "";
  if (!EMAIL_RE.test(email) || email.length > 254) return null;
  if (typeof r.iat !== "number" || typeof r.exp !== "number" || !Number.isFinite(r.iat) || !Number.isFinite(r.exp)) return null;
  if (typeof r.nonce !== "string" || r.nonce.length < 16 || r.nonce.length > 128) return null;
  let entitlements: string[] | null = null;
  if (Array.isArray(r.entitlements)) entitlements = r.entitlements.filter((e): e is string => typeof e === "string");
  else if (r.entitlements !== null && r.entitlements !== undefined) return null;
  const str = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");
  const strOrNull = (v: unknown, max: number) => (typeof v === "string" && v.trim() ? v.trim().slice(0, max) : null);
  return {
    v: typeof r.v === "number" ? r.v : -1,
    sub: str(r.sub, 120),
    email,
    firstName: str(r.firstName, 80),
    lastName: str(r.lastName, 80),
    iat: r.iat,
    exp: r.exp,
    nonce: r.nonce,
    demo: r.demo === true,
    entitlements,
    orgSlug: strOrNull(r.orgSlug, 120),
    enrollmentId: strOrNull(r.enrollmentId, 120),
    back: strOrNull(r.back, 500),
  };
}

/**
 * Vérifie un jeton `payload.signature`. Ordre : forme → signature (temps constant) → version → dates.
 * Ne vérifie PAS le rejeu (nonce) : voir `consumeSsoNonce` dans src/server/sso.ts.
 */
export function verifySsoToken(token: string, secret: string, now = new Date()): SsoVerification {
  if (typeof token !== "string" || token.length > 8192) return { ok: false, reason: "malformed" };
  const parts = token.split(".");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return { ok: false, reason: "malformed" };
  if (!/^[A-Za-z0-9_-]+$/.test(parts[0]) || !/^[A-Za-z0-9_-]+$/.test(parts[1])) return { ok: false, reason: "malformed" };
  const expected = hmac(parts[0], secret);
  const given = Buffer.from(parts[1], "base64url");
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return { ok: false, reason: "signature" };
  const payload = parsePayload(Buffer.from(parts[0], "base64url").toString("utf8"));
  if (!payload) return { ok: false, reason: "payload" };
  if (payload.v !== SSO_VERSION) return { ok: false, reason: "version" };
  const nowS = Math.floor(now.getTime() / 1000);
  if (payload.exp <= nowS) return { ok: false, reason: "expired" };
  if (payload.iat > nowS + SSO_CLOCK_SKEW_SECONDS) return { ok: false, reason: "not_yet_valid" };
  if (payload.exp - payload.iat > SSO_MAX_TTL_SECONDS || payload.exp < payload.iat) return { ok: false, reason: "expired" };
  return { ok: true, payload };
}

/** Secret SSO configuré et assez long ? (NF_SSO_SECRET, identique à IA_SSO_SECRET côté Next Formation). */
export function ssoSecret(): string | null {
  const s = process.env.NF_SSO_SECRET?.trim();
  return s && s.length >= SSO_MIN_SECRET_LENGTH ? s : null;
}
