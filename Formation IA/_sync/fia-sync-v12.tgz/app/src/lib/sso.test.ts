import { describe, expect, it } from "vitest";
import { SSO_MAX_TTL_SECONDS, signSsoToken, verifySsoToken } from "./sso";

const SECRET = "ia-sso-test-secret-0123456789abcdef0123456789abcdef";
const NOW = new Date("2026-11-05T10:00:00Z");
const base = { email: "Lea.Martin@example.org", firstName: "Léa", lastName: "Martin", sub: "u-42", entitlements: ["N1", "N2"] };

describe("verifySsoToken", () => {
  it("accepte un jeton valide et normalise l'e-mail", () => {
    const token = signSsoToken(base, SECRET, NOW);
    const r = verifySsoToken(token, SECRET, NOW);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.payload.email).toBe("lea.martin@example.org");
    expect(r.payload.firstName).toBe("Léa");
    expect(r.payload.entitlements).toEqual(["N1", "N2"]);
    expect(r.payload.demo).toBe(false);
    expect(r.payload.nonce).toHaveLength(24);
    expect(r.payload.exp - r.payload.iat).toBe(300);
  });

  it("refuse une signature invalide (autre secret) sans révéler le motif précis", () => {
    const token = signSsoToken(base, "autre-secret-0123456789abcdef0123456789abcdef", NOW);
    expect(verifySsoToken(token, SECRET, NOW)).toEqual({ ok: false, reason: "signature" });
  });

  it("refuse un payload modifié après signature", () => {
    const token = signSsoToken(base, SECRET, NOW);
    const [payload, sig] = token.split(".");
    const json = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    json.entitlements = ["N1", "N2", "N3", "N4"];
    const forged = `${Buffer.from(JSON.stringify(json)).toString("base64url")}.${sig}`;
    expect(verifySsoToken(forged, SECRET, NOW)).toEqual({ ok: false, reason: "signature" });
  });

  it("refuse les jetons mal formés", () => {
    expect(verifySsoToken("", SECRET, NOW).ok).toBe(false);
    expect(verifySsoToken("abc", SECRET, NOW).ok).toBe(false);
    expect(verifySsoToken("a.b.c", SECRET, NOW).ok).toBe(false);
    expect(verifySsoToken("a b.c", SECRET, NOW).ok).toBe(false);
  });

  it("refuse un jeton expiré", () => {
    const token = signSsoToken(base, SECRET, NOW);
    const later = new Date(NOW.getTime() + 301_000);
    expect(verifySsoToken(token, SECRET, later)).toEqual({ ok: false, reason: "expired" });
  });

  it("refuse un jeton dont la durée de vie dépasse le maximum, même signé", () => {
    const iat = Math.floor(NOW.getTime() / 1000);
    const token = signSsoToken({ ...base, iat, exp: iat + SSO_MAX_TTL_SECONDS + 1 }, SECRET, NOW);
    expect(verifySsoToken(token, SECRET, NOW)).toEqual({ ok: false, reason: "expired" });
  });

  it("refuse un jeton émis trop loin dans le futur", () => {
    const iat = Math.floor(NOW.getTime() / 1000) + 600;
    const token = signSsoToken({ ...base, iat, exp: iat + 300 }, SECRET, NOW);
    expect(verifySsoToken(token, SECRET, NOW)).toEqual({ ok: false, reason: "not_yet_valid" });
  });

  it("refuse une version inconnue", () => {
    const token = signSsoToken({ ...base, v: 2 }, SECRET, NOW);
    expect(verifySsoToken(token, SECRET, NOW)).toEqual({ ok: false, reason: "version" });
  });

  it("refuse un e-mail absent ou invalide et un nonce trop court", () => {
    expect(verifySsoToken(signSsoToken({ ...base, email: "pas-un-email" }, SECRET, NOW), SECRET, NOW)).toEqual({ ok: false, reason: "payload" });
    expect(verifySsoToken(signSsoToken({ ...base, nonce: "court" }, SECRET, NOW), SECRET, NOW)).toEqual({ ok: false, reason: "payload" });
  });

  it("conserve demo, entitlements null et back", () => {
    const token = signSsoToken({ ...base, demo: true, entitlements: null, back: "https://formation.nikaholding.world/moi" }, SECRET, NOW);
    const r = verifySsoToken(token, SECRET, NOW);
    expect(r.ok && r.payload.demo).toBe(true);
    expect(r.ok && r.payload.entitlements).toBeNull();
    expect(r.ok && r.payload.back).toBe("https://formation.nikaholding.world/moi");
  });

  it("le rejeu est détecté par le nonce : deux jetons signés séparément ont des nonces différents", () => {
    const a = verifySsoToken(signSsoToken(base, SECRET, NOW), SECRET, NOW);
    const b = verifySsoToken(signSsoToken(base, SECRET, NOW), SECRET, NOW);
    expect(a.ok && b.ok && a.payload.nonce !== b.payload.nonce).toBe(true);
    // Un même jeton présenté deux fois porte le même nonce : c'est ce que la table sso_nonces refuse.
    const token = signSsoToken(base, SECRET, NOW);
    const r1 = verifySsoToken(token, SECRET, NOW);
    const r2 = verifySsoToken(token, SECRET, NOW);
    expect(r1.ok && r2.ok && r1.payload.nonce === r2.payload.nonce).toBe(true);
  });
});
