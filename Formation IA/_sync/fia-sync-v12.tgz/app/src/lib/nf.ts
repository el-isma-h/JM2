/**
 * Liens vers Next Formation (le logiciel qui vend, inscrit et suit la Formation IA). `NF_APP_URL` = origine de
 * Next Formation (ex. https://formation.nikaholding.world) ; absente : les liens retour ne sont pas affichés.
 *
 * Lecture côté serveur uniquement (process.env) : les composants client reçoivent les URL en props.
 */

/** Origine de Next Formation sans barre finale, ou null si `NF_APP_URL` n'est pas définie. */
export function nfAppUrl(): string | null {
  const raw = process.env.NF_APP_URL?.trim();
  if (!raw) return null;
  try {
    const u = new URL(raw);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return raw.replace(/\/+$/, "");
  } catch {
    return null;
  }
}

export type NfLinks = {
  /** Accueil de Next Formation. */
  home: string;
  /** Extranet apprenant (« Mon dossier »). */
  dossier: string;
  /** Carte « Ma formation IA » du dossier (compléter l'inscription, ajouter un niveau). */
  formationIa: string;
};

/** Liens retour vers Next Formation, ou null si `NF_APP_URL` n'est pas définie. */
export function nfLinks(): NfLinks | null {
  const base = nfAppUrl();
  if (!base) return null;
  return { home: base, dossier: `${base}/moi`, formationIa: `${base}/moi/formation-ia` };
}
