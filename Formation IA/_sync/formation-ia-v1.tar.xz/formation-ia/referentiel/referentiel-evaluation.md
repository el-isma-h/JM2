# Référentiel d'évaluation — Formation IA Next Formation (NF-IA-150)

## 1. Principes

- Chaque niveau est validé par **trois types d'épreuves** : (a) les quiz de fin de module (10 questions, seuil 70 %), (b) l'examen de niveau (40 questions, 60 min, seuil 70 %, surveillé à distance), (c) une ou plusieurs **épreuves pratiques** évaluées sur grille par un formateur-évaluateur (à partir du niveau 2).
- Le certificat Next Formation du niveau est délivré lorsque **toutes** les compétences du bloc sont validées (règle « pas de compensation entre compétences » : une compétence non atteinte peut être repassée dans un délai de 6 mois).
- Les quiz formatifs sont illimités et comportent une explication par question ; l'examen de niveau est passable au maximum 3 fois (délai de 7 jours entre deux tentatives).
- Les épreuves pratiques sont les projets des modules de projet (M08-L038, M11-L048, M17-L077, M18-L083, M20-L094, M21-L100, M22-L105, M23-L110, M25-L120, M26-L127, M28-L140, M30-L150).
- Un jury de certification (2 membres, dont au moins un professionnel extérieur à l'équipe pédagogique) valide les résultats de chaque session et délivre les parchemins.

## 2. Tableau des épreuves par niveau

| Niveau | Quiz modules | Examen | Épreuves pratiques | Compétences validées |
|---|---|---|---|---|
| N1 | 7 × 10 questions | 40 questions / 60 min | Atelier prompts (L020), étude de cas RGPD/AI Act (L028-L029) — auto-corrigés avec grille | C1.1 → C1.6 |
| N2 | 8 × 10 questions | 40 questions / 60 min | Workflow n8n livré (L038) ; assistant RAG (L048/L052) ; installation LLM local documentée (L043) ; reporting automatisé (L058) ; politique IA (L063) | C2.1 → C2.6 |
| N3 | 8 × 10 questions | 40 questions / 60 min | Dépôt Git : assistant Claude (L077), portage OpenAI (L083), RAG (L094), agent + serveur MCP (L100), application déployée (L105), audit sécurité (L110) | C3.1 → C3.6 |
| N4 | 7 × 10 questions | 40 questions / 60 min | Épreuve écrite maths (M24) ; projets ML (L120), DL (L127), fine-tuning (L140) ; rapport final sûreté/gouvernance (L150) | C4.1 → C4.6 |

## 3. Grille d'évaluation des épreuves pratiques (modèle)

| Critère | Insuffisant (0) | Partiel (1) | Atteint (2) | Expert (3) |
|---|---|---|---|---|
| Fonctionnement | Ne s'exécute pas | S'exécute avec erreurs | S'exécute sur les cas de test | S'exécute et gère les cas limites |
| Qualité / structure | Désorganisé | Lisible mais fragile | Structuré, documenté | Réutilisable, testé |
| Pertinence métier | Hors sujet | Répond partiellement au besoin | Répond au besoin | Dépasse le besoin (valeur ajoutée) |
| Conformité & sécurité | Données sensibles exposées | Risques non traités | Règles respectées | Risques anticipés et documentés |
| Explication orale/écrite | Absente | Confuse | Claire | Argumentée avec alternatives |

Validation de la compétence : ≥ 8/15 et aucun critère à 0.

## 4. Conformité FOAD (décret 2017-382)

- Assistance technique et pédagogique : formateur référent joignable (messagerie de la plateforme, réponse sous 24 h ouvrées), classes virtuelles hebdomadaires optionnelles.
- Séquencement : parcours imposé module par module ; déverrouillage du module suivant après quiz réussi.
- Justification de la réalisation : temps de connexion par leçon, résultats des quiz et examens, dépôts de projets, relevés d'émargement électronique ; validation humaine du temps comptabilisé (fonction native de Next Formation : `elearning_progress.validatedBy`).
- Durée estimée : 150 h, dont 141 h de leçons et exercices, 9 h d'évaluations.

## 5. Accessibilité

Supports textuels compatibles lecteurs d'écran, transcriptions des vidéos externes recommandées, temps majoré d'un tiers aux examens sur demande (référent handicap de l'organisme).
