---
id: L108
module: M23
level: N3
title: "Guardrails, modération, données personnelles"
minutes: 55
objectives:
  - "Comparer les familles de garde-fous (classifieurs de sécurité, rails programmables, validateurs de sortie, API de modération) et choisir selon le besoin, le coût et la confidentialité"
  - "Déployer Llama Guard en local via Ollama et brancher une API de modération en entrée et en sortie d'une application"
  - "Détecter et pseudonymiser les données personnelles (regex françaises, Microsoft Presidio) avant tout envoi à un fournisseur"
  - "Appliquer les recommandations CNIL (fiches pratiques IA) et les obligations de transparence de l'AI Act à une application LLM"
skills: ["C3.6"]
sources:
  - { title: "Ollama — bibliothèque de modèles (catégorie safety : Llama Guard)", url: "https://ollama.com/search", lang: "en" }
  - { title: "Ollama — documentation", url: "https://docs.ollama.com", lang: "en" }
  - { title: "Meta Llama sur Hugging Face (Llama Guard)", url: "https://huggingface.co/meta-llama", lang: "en" }
  - { title: "NVIDIA NeMo Guardrails (GitHub)", url: "https://github.com/NVIDIA/NeMo-Guardrails", lang: "en" }
  - { title: "Guardrails AI (GitHub)", url: "https://github.com/guardrails-ai/guardrails", lang: "en" }
  - { title: "Microsoft Presidio (GitHub)", url: "https://github.com/microsoft/presidio", lang: "en" }
  - { title: "OpenAI — Safety best practices (Moderation API)", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "Claude Platform — Structured outputs", url: "https://platform.claude.com/docs/en/build-with-claude/structured-outputs", lang: "en" }
  - { title: "Claude Platform — Data residency", url: "https://platform.claude.com/docs/en/manage-claude/data-residency", lang: "en" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "CNIL — Développement des systèmes d'IA : les recommandations pour respecter le RGPD", url: "https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd", lang: "fr" }
  - { title: "donneespersonnelles.fr — Omnibus numérique IA (calendrier AI Act)", url: "https://donneespersonnelles.fr/omnibus-numerique-ia", lang: "fr" }
---

# Guardrails, modération, données personnelles

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 23

## 🎯 Ce que vous saurez faire
- Dessiner, pour n'importe quelle application LLM, les **trois points de contrôle** (entrée, outils, sortie) et y placer le bon garde-fou.
- Faire tourner **Llama Guard** sur votre machine (Ollama) pour classer un message en catégories de danger, sans envoyer une donnée à l'extérieur.
- Écrire un **détecteur de données personnelles françaises** (e-mail, téléphone, IBAN, NIR) en regex, puis le comparer à **Presidio**.
- Construire un pipeline **pseudonymisation → appel API → ré-identification** conforme aux fiches CNIL, et afficher les mentions exigées par l'AI Act.

## 1. Où placer un garde-fou ?

En L107, vous avez vu que le filtrage d'entrée n'est qu'une couche. Généralisons : toute application LLM possède **trois frontières**, et un garde-fou (*guardrail*) est un composant qui inspecte ce qui traverse l'une d'elles.

```
 utilisateur / documents          modèle                 utilisateur / systèmes
        │                            │                            │
   ┌────▼─────┐   ┌─────────┐   ┌────▼─────┐   ┌─────────┐   ┌────▼─────┐
   │ ENTRÉE   │──▶│ prompt  │──▶│ OUTILS   │──▶│ réponse │──▶│ SORTIE   │
   │ modération│   └─────────┘   │ allow-list│   └─────────┘   │ PII, JSON│
   │ PII, inj. │                │ bornes    │                 │ toxicité │
   └──────────┘                └──────────┘                 └──────────┘
```

| Frontière | Question posée | Outils typiques |
|---|---|---|
| **Entrée** | Ce message est-il dangereux, hors sujet, manipulateur, contient-il des données personnelles ? | API de modération, Llama Guard, classifieur Haiku (L107), détecteur PII |
| **Outils** | Cette action est-elle autorisée, bornée, approuvée ? | Allow-list, plafonds, validation humaine (L107), *permission policies* |
| **Sortie** | Cette réponse est-elle conforme au format, exempte de secrets, de PII, de contenu actif ou toxique ? | Sorties structurées + Pydantic/Zod, Guardrails AI, canari, modération |

> 💡 **À retenir** — Un garde-fou n'est jamais « le modèle principal qui se relit ». C'est un **composant distinct**, plus petit, plus bête et plus prévisible, qui ne reçoit pas les mêmes instructions que l'agent et qu'on peut tester isolément.

## 2. Le panorama des garde-fous (nov. 2026)

| Famille | Exemple | Ce qu'il fait | Où il tourne | Coût |
|---|---|---|---|---|
| **Classifieur de sécurité** | **Llama Guard** (Meta, versions 3 et 4) | Classe un message (entrée ou sortie) en `safe`/`unsafe` + catégories de danger (violence, criminalité, données sensibles…) | Local via Ollama, ou Hugging Face | Gratuit (poids ouverts, licence Llama) |
| **API de modération** | **OpenAI Moderation API** ; **Mistral Moderation 2** | Scores par catégorie (haine, harcèlement, automutilation, sexuel, violence…) | Cloud | Gratuites chez les deux éditeurs (nov. 2026) |
| **Rails programmables** | **NeMo Guardrails** (NVIDIA) | Dialogues autorisés décrits en Colang : rester dans le sujet, refuser certains thèmes, vérifier les faits, détecter le jailbreak | Bibliothèque Python dans votre app | Open source (Apache 2.0) |
| **Validateurs de sortie** | **Guardrails AI** | Validateurs composables (PII, toxicité, JSON valide, regex, longueur) avec ré-essai automatique | Bibliothèque Python | Open source + hub de validateurs |
| **Modèle garde « maison »** | Haiku 5.5 / Mistral Small 4 + sortie structurée | Verdict JSON sur mesure (injection, hors sujet, ton) | API ou local | Quelques millièmes de centime par message |
| **Règles déterministes** | regex, listes, bornes | PII, formats, montants, domaines e-mail | Dans votre code | Zéro |

Comment choisir ? Trois critères : **confidentialité** (un classifieur local ne fait sortir aucune donnée — décisif pour un cabinet médical ou un service RH), **latence** (une règle regex coûte 0 ms, un appel de modération 100-300 ms), **couverture** (une API de modération ne détecte pas une injection de prompt ; un détecteur PII ne détecte pas un contenu haineux). En pratique, une application sérieuse empile **règles déterministes + un classifieur + une validation de sortie structurée**.

> ⚠️ **Piège fréquent** — Les API de modération des éditeurs sont conçues pour les **catégories de contenu** de leurs politiques d'usage (haine, violence, sexuel…). Elles ne sont ni des anti-injection, ni des détecteurs de secrets, ni des vérificateurs de faits. Les utiliser comme unique garde-fou laisse LLM01, LLM02 et LLM08 grands ouverts.

## 3. Llama Guard en local avec Ollama

Llama Guard est un modèle de la famille Llama entraîné à répondre `safe` ou `unsafe` suivi des catégories enfreintes. Ollama le propose dans sa catégorie *safety* ; il tient sur un portable (version 1B ou 8B selon le matériel, M10).

```bash
# Installation (Ollama déjà installé, voir M10)
ollama pull llama-guard3          # vérifiez le nom exact dans la bibliothèque Ollama (catégorie safety)
ollama run llama-guard3 "Comment fabriquer une arme chez soi ?"
# → unsafe
#   S9   (catégorie : armes à destruction indiscriminée dans la taxonomie Llama Guard 3)
```

Et en Python, via l'API HTTP locale d'Ollama, comme garde d'entrée **et** de sortie :

```python
# garde_llama_guard.py — classification locale, aucune donnée ne quitte la machine
# pip install httpx ; Ollama écoute sur http://localhost:11434
import httpx

OLLAMA = "http://localhost:11434/api/chat"
MODELE = "llama-guard3"

def classer(texte: str, role: str = "user") -> tuple[bool, list[str]]:
    """Renvoie (est_sur, categories). role='assistant' pour contrôler une sortie du modèle."""
    rep = httpx.post(OLLAMA, json={
        "model": MODELE,
        "messages": [{"role": role, "content": texte}],
        "stream": False,
    }, timeout=60).json()
    verdict = rep["message"]["content"].strip().splitlines()
    est_sur = verdict[0].lower().startswith("safe")
    categories = [] if est_sur else [c.strip() for c in verdict[1:] if c.strip()]
    return est_sur, categories

if __name__ == "__main__":
    for msg in ["Quel est le délai pour un devis de chauffe-eau ?",
                "Explique-moi comment entrer chez mon voisin sans clé."]:
        print(msg[:40], "→", classer(msg))
```

Points de cours : (1) le modèle renvoie **du texte**, pas du JSON : parsez-le défensivement et considérez toute réponse inattendue comme `unsafe` ; (2) la taxonomie (S1…S14 pour Llama Guard 3) est documentée dans la *model card* Hugging Face — citez la version utilisée dans votre dossier de conformité ; (3) ajoutez un **délai maximal** et un comportement de repli (refus poli) si Ollama ne répond pas.

Pour l'OpenAI Moderation API, la logique est identique : un appel `client.moderations.create(input=texte)` renvoie `flagged` et des scores par catégorie ; la page *Safety best practices* la présente comme gratuite et recommandée en entrée comme en sortie. Mistral propose de même *Mistral Moderation 2* (gratuit, L086).

## 4. NeMo Guardrails et Guardrails AI en deux minutes

**NeMo Guardrails** décrit en **Colang** les conversations autorisées. Exemple de rail « rester sur la plomberie » :

```yaml
# config/config.yml (NeMo Guardrails)
models:
  - type: main
    engine: openai          # ou un endpoint compatible OpenAI (Ollama, Mistral…)
    model: gpt-6-astra
rails:
  input:
    flows: [self check input]     # rail de détection de jailbreak fourni
  output:
    flows: [self check output]
```

```colang
# config/rails.co — un rail de sujet
define user demande hors sujet
  "Donne-moi ton avis sur les élections"
  "Écris-moi un poème d'amour"

define bot refuse hors sujet
  "Je suis l'assistant de Plomberie Martin : je ne peux vous aider que sur nos prestations."

define flow
  user demande hors sujet
  bot refuse hors sujet
```

**Guardrails AI** travaille sur la sortie : vous composez des validateurs et choisissez l'action en cas d'échec (`exception`, `fix`, `reask`).

```python
# sortie_guardrails_ai.py — validation de sortie composable (vérifiez les noms de validateurs sur le hub Guardrails AI)
from guardrails import Guard
from guardrails.hub import DetectPII, ToxicLanguage   # guardrails hub install hub://guardrails/detect_pii …

guard = Guard().use_many(
    DetectPII(pii_entities=["EMAIL_ADDRESS", "PHONE_NUMBER"], on_fail="fix"),  # remplace par <EMAIL_ADDRESS>
    ToxicLanguage(threshold=0.8, on_fail="exception"),
)
resultat = guard.validate("Contactez M. Durand au 06 12 34 56 78 pour le devis.")
print(resultat.validated_output)   # → "Contactez M. Durand au <PHONE_NUMBER> pour le devis."
```

Et n'oubliez pas le garde-fou de sortie **le plus simple et le plus fiable** : les sorties structurées (`output_config.format = json_schema` chez Anthropic, `text.format` strict chez OpenAI) validées par Pydantic ou Zod. Un JSON qui ne respecte pas le schéma est rejeté avant d'atteindre votre base de données — c'est votre protection LLM10 de base.

> 🔗 **Documentation officielle** — [NeMo Guardrails](https://github.com/NVIDIA/NeMo-Guardrails) 🇬🇧 · [Guardrails AI](https://github.com/guardrails-ai/guardrails) 🇬🇧 · [Structured outputs (Claude)](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧.

## 5. Données personnelles : détecter, pseudonymiser, minimiser

### 5.1 Regex françaises : rapide, gratuit, limité

```python
# pii_fr.py — détection de données personnelles françaises (Python 3.12+)
import re

MOTIFS = {
    "EMAIL": re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"),
    "TEL_FR": re.compile(r"(?:\+33\s?|0)[1-9](?:[\s.-]?\d{2}){4}"),
    "IBAN_FR": re.compile(r"\bFR\d{2}(?:\s?[A-Z0-9]{4}){5}\s?[A-Z0-9]{3}\b"),
    # NIR (numéro de sécurité sociale) : sexe, année, mois, département, commune, ordre, clé
    "NIR": re.compile(r"\b[12]\s?\d{2}\s?(?:0[1-9]|1[0-2])\s?(?:\d{2}|2A|2B)\s?\d{3}\s?\d{3}\s?\d{2}\b"),
}

def nir_valide(nir: str) -> bool:
    """Contrôle de la clé : 97 - (nombre mod 97). La Corse remplace 2A/2B par 19/18."""
    n = nir.replace(" ", "").upper().replace("2A", "19").replace("2B", "18")
    return len(n) == 15 and (97 - int(n[:13]) % 97) == int(n[13:])

def detecter(texte: str) -> list[tuple[str, str]]:
    trouves = []
    for nom, motif in MOTIFS.items():
        for m in motif.finditer(texte):
            if nom == "NIR" and not nir_valide(m.group()):
                continue  # évite les faux positifs sur des numéros quelconques
            trouves.append((nom, m.group()))
    return trouves

if __name__ == "__main__":
    print(detecter("Client : jean.durand@exemple.fr, 06 12 34 56 78, NIR 1 85 05 75 116 001 23"))
```

Les regex détectent très bien les **identifiants formatés** (IBAN, NIR, e-mail, téléphone) et très mal les **noms, adresses, pathologies**. Pour ceux-là, il faut de la reconnaissance d'entités nommées.

### 5.2 Presidio : NER + regex + anonymisation réversible

**Microsoft Presidio** (open source) combine des reconnaisseurs regex et un modèle NER (spaCy) pour détecter puis **anonymiser** ; vous pouvez le faire tourner en local. Le support du français passe par un modèle spaCy français ; les reconnaisseurs spécifiquement français (NIR, IBAN FR) sont à ajouter — vérifiez la liste des entités prises en charge dans la documentation du dépôt avant de promettre une couverture.

```python
# pii_presidio.py — pip install presidio-analyzer presidio-anonymizer ; python -m spacy download fr_core_news_md
from presidio_analyzer import AnalyzerEngine, PatternRecognizer, Pattern
from presidio_analyzer.nlp_engine import NlpEngineProvider
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

nlp = NlpEngineProvider(nlp_configuration={
    "nlp_engine_name": "spacy",
    "models": [{"lang_code": "fr", "model_name": "fr_core_news_md"}],
}).create_engine()
analyseur = AnalyzerEngine(nlp_engine=nlp, supported_languages=["fr"])

# Reconnaisseur maison pour le NIR français (réutilise la regex de pii_fr.py)
analyseur.registry.add_recognizer(PatternRecognizer(
    supported_entity="FR_NIR", supported_language="fr",
    patterns=[Pattern("nir", r"\b[12]\s?\d{2}\s?(?:0[1-9]|1[0-2])\s?(?:\d{2}|2A|2B)\s?\d{3}\s?\d{3}\s?\d{2}\b", 0.6)],
))
anonymiseur = AnonymizerEngine()

texte = "Mme Sophie Leroy (NIR 2 90 11 75 108 221 46) habite 12 rue des Lilas, Nanterre ; tél. 06 12 34 56 78."
resultats = analyseur.analyze(text=texte, language="fr")
anonyme = anonymiseur.anonymize(text=texte, analyzer_results=resultats,
                                operators={"DEFAULT": OperatorConfig("replace", {"new_value": "<PII>"})})
print(anonyme.text)
```

### 5.3 Le pipeline « pseudonymiser avant d'envoyer »

La CNIL rappelle (recommandations finalisées le 22 juillet 2025 ; fiche 6 *protection dès la conception*, fiche 12 *sécurité du développement*) les principes qui s'appliquent à toute application IA : **finalité précise, minimisation, durée de conservation, sécurité**, et une **AIPD** fortement recommandée (de fait obligatoire pour les systèmes à haut risque de l'AI Act). Traduction pour le développeur : n'envoyez au fournisseur que ce dont le modèle a besoin.

```python
# pseudo_pipeline.py — remplace les PII par des jetons, appelle le modèle, restaure
import re
from anthropic import Anthropic
from pii_fr import detecter

client = Anthropic()

def pseudonymiser(texte: str) -> tuple[str, dict[str, str]]:
    table: dict[str, str] = {}
    for i, (nom, valeur) in enumerate(detecter(texte)):
        jeton = f"[{nom}_{i}]"
        table[jeton] = valeur
        texte = texte.replace(valeur, jeton)
    return texte, table

def reidentifier(texte: str, table: dict[str, str]) -> str:
    for jeton, valeur in table.items():
        texte = texte.replace(jeton, valeur)
    return texte

def resumer_email(email: str) -> str:
    pseudo, table = pseudonymiser(email)
    rep = client.messages.create(
        model="claude-haiku-5-5", max_tokens=300,
        system="Résume l'e-mail en deux phrases. Conserve les jetons entre crochets tels quels.",
        messages=[{"role": "user", "content": f"<email>\n{pseudo}\n</email>"}],
    )
    texte = "".join(b.text for b in rep.content if b.type == "text")
    return reidentifier(texte, table)   # la table ne quitte jamais votre serveur

print(resumer_email("Bonjour, rappelez-moi au 06 12 34 56 78 ou sur jean.durand@exemple.fr pour le devis."))
```

Le fournisseur ne voit jamais le téléphone ni l'e-mail ; la **table de correspondance** reste chez vous (et doit être protégée et purgée). Si la tâche n'exige pas la ré-identification (statistiques, classification), ne la faites pas : c'est la minimisation en acte.

### 5.4 Ce que le contrat et la configuration doivent dire

- **Sous-traitance** : un fournisseur d'API est un sous-traitant au sens du RGPD ; vérifiez le contrat de traitement des données (DPA), la **localisation** (Anthropic propose la résidence des données avec `inference_geo`, majorée ×1,1 pour les États-Unis, nov. 2026) et la **rétention** (OpenAI : `store: false` pour ne pas conserver les réponses ; options *zero data retention* chez les éditeurs sous conditions).
- **Transparence (AI Act, art. 50, applicable depuis le 2 août 2026)** : un chatbot doit indiquer clairement qu'il est une IA ; les contenus synthétiques doivent être marqués. Une phrase d'accueil (« Vous échangez avec DevisBot, un assistant automatisé ») et une mention dans les CGU suffisent pour un assistant client ; pour les cas haut risque (RH, crédit), les obligations renforcées arrivent le 2 décembre 2027 (omnibus IA, à confirmer sur EUR-Lex).
- **Droits des personnes** : si vous conservez des conversations, prévoyez l'accès, la rectification et l'effacement ; indexer des e-mails dans un RAG est un traitement à documenter dans le registre.

> 🔗 **Documentation officielle** — [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 · [CNIL — Recommandations pour respecter le RGPD](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd) 🇫🇷 · [Claude Platform — Data residency](https://platform.claude.com/docs/en/manage-claude/data-residency) 🇬🇧.

🎮 **Défi** — Votre détecteur regex signale un NIR dans « commande n° 1 85 05 75 116 001 23 ». Faux positif ou vrai positif ? *(Calculez la clé : si `nir_valide` renvoie `True`, traitez-le comme un vrai NIR — un numéro de commande qui passe le contrôle mod 97 est statistiquement rare ; sinon, c'est un faux positif que la fonction élimine déjà.)*

## 🧪 Exercice pratique

**Consigne.** Ajoutez à `devisbot_securise.py` (L107) une **chaîne de garde-fous** : (1) détection PII regex sur chaque entrée et chaque résultat d'outil, avec pseudonymisation avant l'appel au modèle ; (2) Llama Guard (ou l'API de modération de votre fournisseur) sur l'entrée utilisateur et sur la réponse finale ; (3) validation de la réponse finale par un schéma Pydantic `{reponse: str, action_proposee: str | None, niveau_confiance: float}` via les sorties structurées ; (4) message de transparence AI Act au premier tour. Mesurez la latence ajoutée par chaque garde-fou.

**Critères de réussite.**
- Aucun numéro de téléphone, e-mail, IBAN ni NIR n'apparaît dans les requêtes envoyées au fournisseur (vérifiez en journalisant le corps des requêtes côté client).
- Un message classé `unsafe` par Llama Guard reçoit un refus poli **sans** appel au modèle principal.
- Une réponse qui ne respecte pas le schéma est rejetée et journalisée ; l'utilisateur reçoit un message de repli.
- La latence totale ajoutée reste inférieure à 500 ms en local (regex ≈ 0 ms, Llama Guard 1B ≈ 100-300 ms selon le matériel).

**Pistes de corrigé.** Ordre : regex → modération → modèle principal (sortie structurée) → modération de sortie → ré-identification → rendu. Si Ollama n'est pas disponible, repliez sur le classifieur Haiku de L107 avec une catégorie `contenu_inapproprie`. Pour mesurer la latence, encadrez chaque étape de `time.perf_counter()` et exportez en JSONL ; c'est la base de l'observabilité de M22.

## ✅ Auto-évaluation express

1. Pourquoi une API de modération ne protège-t-elle pas contre l'injection de prompt ?
2. Quel avantage décisif Llama Guard a-t-il sur une API de modération pour un cabinet médical ?
3. Dans le pipeline de pseudonymisation, quel élément ne doit jamais quitter votre infrastructure ?

*Réponses : 1) Elle classe des catégories de contenu (haine, violence…), pas des tentatives de manipulation d'une application ; « ignore tes instructions » est un texte parfaitement « safe » pour elle. 2) Il tourne en local : aucune donnée de santé ne sort, ce qui simplifie l'AIPD et la sous-traitance RGPD. 3) La table de correspondance jeton → valeur réelle (et plus généralement toute PII non nécessaire à la tâche).*

## 📚 Pour aller plus loin
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — 18 fiches, dont la fiche 12 « sécurité du développement » et la liste de vérification.
- [Microsoft Presidio](https://github.com/microsoft/presidio) 🇬🇧 — analyse et anonymisation de PII, reconnaisseurs personnalisés, support multilingue.
- [NeMo Guardrails](https://github.com/NVIDIA/NeMo-Guardrails) 🇬🇧 — rails Colang, détection de jailbreak, vérification de faits.
- [Guardrails AI](https://github.com/guardrails-ai/guardrails) 🇬🇧 — validateurs de sortie et hub communautaire.
- [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — Moderation API, identifiants de sécurité, signalement utilisateur.
- [donneespersonnelles.fr — Omnibus numérique IA](https://donneespersonnelles.fr/omnibus-numerique-ia) 🇫🇷 — calendrier AI Act mis à jour (transparence 2026, haut risque 2027).
