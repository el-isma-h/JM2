---
id: L104
module: M22
level: N3
title: "CI/CD et tests de prompts"
minutes: 45
objectives:
  - "Construire un pipeline GitHub Actions qui exécute les tests unitaires, le typage et la suite promptfoo à chaque pull request"
  - "Définir des seuils de qualité bloquants (taux de réussite, coût, latence) et empêcher la fusion en cas de régression"
  - "Versionner les prompts comme du code et piloter leur activation par feature flags"
  - "Déployer progressivement (canary, pourcentage d'utilisateurs) et revenir en arrière en une commande"
skills: ["C3.5"]
sources:
  - { title: "GitHub Actions — documentation", url: "https://docs.github.com/en/actions", lang: "en" }
  - { title: "promptfoo — documentation", url: "https://www.promptfoo.dev/docs", lang: "en" }
  - { title: "promptfoo — dépôt GitHub", url: "https://github.com/promptfoo/promptfoo", lang: "en" }
  - { title: "Claude Code — GitHub Actions", url: "https://code.claude.com/docs/en/github-actions.md", lang: "en" }
  - { title: "Vercel — documentation (déploiements, environnements)", url: "https://vercel.com/docs", lang: "en" }
  - { title: "Langfuse (gestion des prompts)", url: "https://langfuse.com", lang: "en" }
  - { title: "Claude Platform — Define success criteria & build evals", url: "https://platform.claude.com/docs/en/test-and-evaluate/develop-tests", lang: "en" }
---

# CI/CD et tests de prompts

> ⏱ 45 min · 🎯 Niveau 3 · 📚 Module 22

## 🎯 Ce que vous saurez faire
- Écrire un workflow GitHub Actions complet : lint, typage, tests unitaires (Vitest), suite promptfoo, puis déploiement.
- Faire de la qualité des réponses un **critère bloquant** au même titre qu'un test unitaire rouge.
- Gérer les prompts comme des fichiers versionnés, avec un identifiant de version propagé jusqu'aux traces.
- Activer un nouveau prompt ou un nouveau modèle pour 5 % des utilisateurs, mesurer, puis généraliser — ou revenir en arrière.

## 1. Un prompt est du code : traitez-le comme tel

Dans les équipes qui débutent, le prompt système vit dans une chaîne de caractères au milieu du route handler ; on le modifie « pour voir », on déploie, et une semaine plus tard personne ne sait pourquoi l'assistant répond en anglais. Un prompt a pourtant toutes les propriétés du code : il a des versions, il peut régresser, il se teste, il se revoit en pull request.

Trois pratiques simples :

1. **Un fichier par prompt**, dans `prompts/`, avec un en-tête de métadonnées (version, modèle cible, date, auteur). Le route handler le charge au démarrage.
2. **Un identifiant de version** (`PROMPT_VERSION`), dérivé du nom de fichier ou d'un hash du contenu, propagé dans les traces (métadonnée `promptVersion` de L103). Vous pourrez ainsi comparer le taux de pouce haut de la v3 et de la v4.
3. **Une revue à deux** : toute modification de `prompts/` déclenche la suite d'évaluation et exige un relecteur, comme une migration de base de données.

```
prompts/
├── systeme-v3.txt      # version en production
├── systeme-v4.txt      # candidate, testée en CI, activée par feature flag
└── CHANGELOG.md        # ce qui a changé et pourquoi (ex. « v4 : ajoute la règle "citer la source" »)
```

Si vous préférez gérer les prompts hors du dépôt, [Langfuse](https://langfuse.com) propose une **gestion de prompts** versionnée avec labels (`production`, `staging`) et récupération par SDK ; LangSmith a un *Prompt Hub* équivalent. L'avantage : un responsable métier peut modifier le texte sans redéploiement. L'inconvénient : le prompt échappe à la CI si vous ne branchez pas la suite d'évaluation sur chaque changement de label. Pour un cabinet de 50 personnes, le fichier dans le dépôt reste le choix le plus sûr.

> 💡 **À retenir** — « Qui a changé le prompt, quand, et avec quel effet mesuré ? » doit avoir une réponse en moins d'une minute. Git + traces taguées par version y répondent.

## 2. Le pipeline GitHub Actions

Le workflow ci-dessous s'exécute à chaque pull request et à chaque push sur `main`. Il enchaîne quatre étapes : qualité du code, tests unitaires, évaluation des prompts, déploiement. Les secrets (`ANTHROPIC_API_KEY`, etc.) sont stockés dans **Settings → Secrets and variables → Actions** du dépôt, jamais dans le YAML (voir [GitHub Actions](https://docs.github.com/en/actions)).

```yaml
# .github/workflows/ci.yml — Compta-Chat (nov. 2026)
name: CI Compta-Chat

on:
  pull_request:
  push:
    branches: [main]

concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true          # une nouvelle poussée annule l'exécution précédente (économise des appels LLM)

jobs:
  qualite-code:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - run: npm run lint
      - run: npx tsc --noEmit
      - run: npx vitest run --coverage          # tests unitaires des outils, quotas, cache sémantique

  evaluation-prompts:
    needs: qualite-code
    runs-on: ubuntu-latest
    # On n'évalue que si le prompt, les outils ou la config d'évaluation ont changé — ou sur main
    if: github.ref == 'refs/heads/main' || contains(github.event.pull_request.labels.*.name, 'eval') || github.event_name == 'pull_request'
    env:
      ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
      PROMPTFOO_CACHE_PATH: ~/.promptfoo/cache
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - name: Cache des réponses promptfoo (évite de repayer les cas inchangés)
        uses: actions/cache@v4
        with:
          path: ~/.promptfoo/cache
          key: promptfoo-${{ hashFiles('promptfooconfig.yaml', 'prompts/**', 'tests/**') }}
      - name: Évaluation promptfoo
        run: npx promptfoo eval -c promptfooconfig.yaml --output resultats.json --no-progress-bar
      - name: Seuils de qualité bloquants
        run: node scripts/verifier-seuils.mjs resultats.json
      - uses: actions/upload-artifact@v4
        if: always()
        with: { name: resultats-promptfoo, path: resultats.json }

  deploiement:
    needs: evaluation-prompts
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production                     # protection : approbation manuelle configurable
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 22 }
      - run: npm i -g vercel
      - run: vercel pull --yes --environment=production --token=${{ secrets.VERCEL_TOKEN }}
      - run: vercel build --prod --token=${{ secrets.VERCEL_TOKEN }}
      - run: vercel deploy --prebuilt --prod --token=${{ secrets.VERCEL_TOKEN }}
```

Points à noter : `concurrency` évite de payer des évaluations pour des commits déjà obsolètes ; le **cache** promptfoo (clé = hash des prompts et des tests) fait que seuls les cas modifiés sont réellement envoyés au fournisseur ; l'étape `environment: production` permet d'exiger une approbation humaine avant tout déploiement. promptfoo publie aussi une action GitHub dédiée qui commente la pull request avec le tableau de résultats — voir sa [documentation](https://www.promptfoo.dev/docs). Pour un VPS, remplacez le job `deploiement` par un `ssh` + `docker compose pull && docker compose up -d` (L105).

> ⚠️ **Piège fréquent** — Lancer la suite d'évaluation sur chaque commit de chaque branche sans cache ni `concurrency` : 20 cas × 2 modèles × 2 prompts × 30 poussées par jour = 2 400 appels quotidiens. Le coût n'est pas dramatique avec Haiku, mais il explose avec un juge Sonnet et des rubriques longues. Mesurez le coût de votre CI comme celui de votre production.

## 3. Seuils bloquants : transformer un score en décision

`promptfoo eval` renvoie déjà un code de sortie non nul si une assertion échoue. Mais « un cas sur cinquante échoue » n'est pas toujours une raison de bloquer, alors que « le coût moyen a doublé » l'est. D'où un petit script de seuils qui lit `resultats.json` :

```javascript
// scripts/verifier-seuils.mjs — échoue (exit 1) si un seuil global n'est pas respecté
import fs from "node:fs";

const SEUILS = {
  tauxReussiteMin: 0.92,     // 92 % des assertions doivent passer
  coutMoyenMax: 0.006,       // $ par réponse (nov. 2026, Haiku/Sonnet 5.5)
  latenceP95Max: 9000,       // ms
  casCritiques: ["Résistance à l'injection", "Refus propre hors périmètre"],   // 100 % obligatoire
};

const r = JSON.parse(fs.readFileSync(process.argv[2], "utf8")).results;
const lignes = r.results;                                     // une ligne = (prompt, fournisseur, cas)
const total = lignes.length;
const reussis = lignes.filter((l) => l.success).length;
const couts = lignes.map((l) => l.cost ?? 0);
const latences = lignes.map((l) => l.latencyMs ?? 0).sort((a, b) => a - b);
const p95 = latences[Math.floor(latences.length * 0.95)] ?? 0;
const coutMoyen = couts.reduce((a, b) => a + b, 0) / total;

const erreurs = [];
if (reussis / total < SEUILS.tauxReussiteMin) erreurs.push(`taux de réussite ${(100 * reussis / total).toFixed(1)} % < ${100 * SEUILS.tauxReussiteMin} %`);
if (coutMoyen > SEUILS.coutMoyenMax) erreurs.push(`coût moyen ${coutMoyen.toFixed(4)} $ > ${SEUILS.coutMoyenMax} $`);
if (p95 > SEUILS.latenceP95Max) erreurs.push(`latence p95 ${p95} ms > ${SEUILS.latenceP95Max} ms`);
for (const nom of SEUILS.casCritiques) {
  const echecs = lignes.filter((l) => l.testCase?.description === nom && !l.success);
  if (echecs.length) erreurs.push(`cas critique « ${nom} » en échec (${echecs.length})`);
}

console.log(`Réussite ${reussis}/${total} · coût moyen ${coutMoyen.toFixed(4)} $ · p95 ${p95} ms`);
if (erreurs.length) { console.error("❌ Seuils non respectés :\n - " + erreurs.join("\n - ")); process.exit(1); }
console.log("✅ Seuils respectés.");
```

Les noms de champs du JSON (`results.results[].success`, `cost`, `latencyMs`, `testCase.description`) correspondent au format de sortie de promptfoo au moment de la rédaction ; vérifiez-les sur un fichier généré par votre version. La logique, elle, est universelle : **taux global**, **coût**, **latence**, et **cas critiques à 100 %** (sécurité, refus). Cette séparation reflète la page [Define success criteria](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) d'Anthropic : certains critères sont des moyennes, d'autres des planchers absolus.

### Et les tests unitaires ?

Tout ce qui n'est pas le modèle se teste **sans** le modèle, en Vitest, gratuitement et en millisecondes : la fonction `echeanceTva`, le calcul `coutUsd`, le seuil du cache sémantique, la validation Zod du corps de requête. Pour tester le route handler lui-même sans appeler Anthropic, le Vercel AI SDK fournit `MockLanguageModelV2` (paquet `ai/test`) qui simule un flux de tokens et d'appels d'outils. Règle : **80 % des tests ne touchent pas au LLM**, 20 % sont des évaluations.

## 4. Feature flags et déploiement progressif

Déployer un prompt v4 « pour tout le monde » après une suite verte reste un pari : la suite couvre 50 cas, la production en voit 2 000 par jour. Le déploiement **progressif** réduit le risque :

```typescript
// src/lib/flags.ts — sélection du prompt par pourcentage d'utilisateurs (hash stable, pas de hasard par requête)
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";

const PROMPTS = {
  v3: readFileSync("prompts/systeme-v3.txt", "utf8"),
  v4: readFileSync("prompts/systeme-v4.txt", "utf8"),
};
const POURCENT_V4 = Number(process.env.FLAG_PROMPT_V4_POURCENT ?? 0);   // 0 → personne ; 100 → tout le monde
const FORCE = (process.env.FLAG_PROMPT_V4_UTILISATEURS ?? "").split(",").filter(Boolean); // testeurs internes

export function choisirPrompt(userId: string): { version: "v3" | "v4"; texte: string } {
  if (FORCE.includes(userId)) return { version: "v4", texte: PROMPTS.v4 };
  const h = createHash("sha256").update(`prompt-v4:${userId}`).digest();
  const seau = h.readUInt16BE(0) % 100;              // 0-99, stable pour un utilisateur donné
  const version = seau < POURCENT_V4 ? "v4" : "v3";
  return { version, texte: PROMPTS[version] };
}
```

Le hash garantit qu'un même utilisateur voit toujours la même version (pas de réponses incohérentes d'un message à l'autre) et que 5 % signifie bien 5 % des utilisateurs, pas 5 % des requêtes. La version choisie part dans les traces (`promptVersion`), ce qui permet de comparer dans Langfuse le taux de pouce haut v3 vs v4 sur de vrais utilisateurs. Même mécanisme pour un **changement de modèle** (`FLAG_MODELE_HAIKU_POURCENT`).

Le protocole :

| Étape | Pourcentage | Durée | Critère pour passer à l'étape suivante |
|---|---|---|---|
| Testeurs internes | liste `FORCE` | 1-2 jours | aucun bug fonctionnel |
| Canary | 5 % | 2-3 jours | pouce haut v4 ≥ v3 ; erreurs d'outil ≤ v3 ; coût/trace ≤ +10 % |
| Élargissement | 25 % puis 50 % | 2-3 jours chacun | mêmes critères, significativité (au moins 200 traces par version) |
| Généralisation | 100 % | — | supprimer le flag et la v3 au prochain cycle |

**Retour arrière** : `FLAG_PROMPT_V4_POURCENT=0` dans les variables d'environnement (Vercel : *Settings → Environment Variables*, puis redéploiement en quelques secondes ; VPS : `docker compose up -d` après modification de `.env`). Sur [Vercel](https://vercel.com/docs), chaque déploiement est immuable : *Instant Rollback* rebascule le domaine sur le déploiement précédent sans reconstruction. C'est le filet de sécurité du pipeline : si la CI est passée mais que la production se dégrade, on revient en une minute.

Pour aller plus loin dans l'automatisation, Claude Code s'intègre à [GitHub Actions](https://code.claude.com/docs/en/github-actions.md) : un agent peut relire la pull request, commenter les changements de prompt et proposer des cas de test supplémentaires — à condition de garder un humain comme approbateur final.

> 🔗 **Documentation officielle** — [GitHub Actions](https://docs.github.com/en/actions) · [promptfoo](https://www.promptfoo.dev/docs) · [Vercel](https://vercel.com/docs)

🎮 **Défi** — Avec un hash SHA-256 et `% 100`, les utilisateurs du seau 0-4 reçoivent toujours les nouveautés en premier. Proposez une modification d'une ligne pour que chaque *nouveau* flag tire des utilisateurs différents, sans perdre la stabilité par utilisateur.

## 🧪 Exercice pratique

**Consigne.** Mettez Compta-Chat sous intégration continue :
1. créez `.github/workflows/ci.yml` avec les trois jobs (qualité, évaluation, déploiement) ; le déploiement cible soit Vercel (preview sur PR, production sur `main`), soit votre VPS ;
2. écrivez au moins 6 tests Vitest sans LLM (`echeanceTva`, `coutUsd`, validation Zod, `choisirPrompt` avec 1 000 identifiants : vérifiez que la proportion v4 est à ±2 % du pourcentage) ;
3. adaptez `verifier-seuils.mjs` à votre `resultats.json` réel et rendez les deux cas de sécurité bloquants à 100 % ;
4. créez une pull request qui dégrade volontairement le prompt (supprimez la consigne « répondez en français ») et montrez que la CI la bloque.

**Critères de réussite.**
- La PR de dégradation est rouge avec un message explicite listant le seuil violé ; la PR corrigée est verte.
- Le job d'évaluation réutilise le cache : la deuxième exécution sans changement de prompt fait moins de 5 appels au fournisseur (vérifiez dans la console Usage).
- Le déploiement n'a lieu que sur `main` et uniquement si l'évaluation est passée.
- La variable `FLAG_PROMPT_V4_POURCENT` change le comportement sans redéploiement du code.

**Pistes de corrigé.** Pour le test de proportion, générez `user-0001` … `user-1000` et comptez les `v4` avec `POURCENT_V4 = 20` : attendez-vous à 180-220. Pour bloquer la PR, protégez la branche `main` (*Settings → Branches → Require status checks*) et cochez les trois jobs. Pour le cache promptfoo, l'étape `actions/cache` doit s'exécuter **avant** `promptfoo eval`.

## ✅ Auto-évaluation express

1. Pourquoi le pourcentage d'un feature flag doit-il être calculé à partir d'un hash de l'identifiant utilisateur plutôt qu'avec `Math.random()` ?
2. Citez deux mécanismes du workflow qui limitent le coût de la CI en appels LLM.
3. Quelle différence entre un seuil « moyenne » et un seuil « plancher » dans `verifier-seuils.mjs` ?

**Réponses.** 1. Pour qu'un utilisateur voie toujours la même version (cohérence de l'expérience) et que les comparaisons v3/v4 dans les traces portent sur des populations stables. 2. `concurrency` avec `cancel-in-progress` (annule les exécutions obsolètes) et le cache promptfoo indexé sur le hash des prompts et des tests (ne rejoue que les cas modifiés) ; on peut ajouter un déclenchement conditionnel par chemin ou label. 3. Une moyenne (taux de réussite ≥ 92 %, coût moyen) tolère quelques échecs ; un plancher (cas de sécurité à 100 %) bloque au premier échec, parce que certains défauts sont inacceptables quelle que soit leur fréquence.

## 📚 Pour aller plus loin
- [GitHub Actions — documentation](https://docs.github.com/en/actions) 🇬🇧 — syntaxe des workflows, secrets, environnements protégés, cache.
- [promptfoo — documentation](https://www.promptfoo.dev/docs) 🇬🇧 — intégration CI, action GitHub, format de sortie JSON, cache.
- [Vercel — documentation](https://vercel.com/docs) 🇬🇧 — déploiements preview/production, variables d'environnement, Instant Rollback.
- [Claude Code — GitHub Actions](https://code.claude.com/docs/en/github-actions.md) 🇬🇧 — faire relire vos pull requests par un agent.
- [Claude Platform — Define success criteria & build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) 🇬🇧 — la méthode pour choisir ce qui est bloquant.
