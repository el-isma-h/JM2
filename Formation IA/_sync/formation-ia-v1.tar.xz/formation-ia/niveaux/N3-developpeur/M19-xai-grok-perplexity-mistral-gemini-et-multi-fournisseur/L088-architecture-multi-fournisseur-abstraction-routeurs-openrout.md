---
id: L088
module: M19
level: N3
title: "Architecture multi-fournisseur : abstraction, routeurs (OpenRouter, LiteLLM), repli"
minutes: 75
objectives:
  - "Concevoir une couche d'abstraction maison (interface commune, adaptateurs) qui expose Claude, GPT-6, Grok, Mistral et Gemini derrière un même contrat"
  - "Comparer et mettre en œuvre LiteLLM, OpenRouter et le Vercel AI SDK comme alternatives à l'abstraction maison"
  - "Construire un routeur par coût, latence et qualité avec repli (fallback), retries à backoff exponentiel et cache de réponses"
  - "Évaluer les fournisseurs par tests A/B (promptfoo, jeu d'or) et instrumenter l'observabilité (coût, latence, erreurs par fournisseur)"
skills: ["C3.1", "C3.5"]
sources:
  - { title: "Claude Platform — OpenAI SDK compatibility", url: "https://platform.claude.com/docs/en/cli-sdks-libraries/libraries/openai-sdk", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — Define success / build evals", url: "https://platform.claude.com/docs/en/test-and-evaluate/develop-tests", lang: "en" }
  - { title: "OpenAI — Pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "xAI — Pricing", url: "https://docs.x.ai/developers/pricing", lang: "en" }
  - { title: "Mistral — Pricing", url: "https://docs.mistral.ai/inference/pricing", lang: "en" }
  - { title: "Gemini API — Pricing", url: "https://ai.google.dev/gemini-api/docs/pricing", lang: "en" }
  - { title: "Perplexity — Agent API models & pricing", url: "https://docs.perplexity.ai/docs/agent-api/models.md", lang: "en" }
  - { title: "Hugging Face — Inference Providers, premier appel", url: "https://huggingface.co/docs/inference-providers/main/guides/first-api-call", lang: "en" }
  - { title: "Vercel AI SDK — Introduction", url: "https://ai-sdk.dev/docs/introduction", lang: "en" }
  - { title: "LiteLLM — Documentation", url: "https://docs.litellm.ai/docs/", lang: "en" }
  - { title: "OpenRouter — Quickstart", url: "https://openrouter.ai/docs/quickstart", lang: "en" }
  - { title: "promptfoo (GitHub)", url: "https://github.com/promptfoo/promptfoo", lang: "en" }
  - { title: "Infrabase — LLM observability tools compared", url: "https://infrabase.ai/blog/llm-observability-tools-compared", lang: "en" }
---

# Architecture multi-fournisseur : abstraction, routeurs (OpenRouter, LiteLLM), repli

> ⏱ 75 min · 🎯 Niveau 3 · 📚 Module 19

## 🎯 Ce que vous saurez faire
- Écrire une **interface commune** et des **adaptateurs** pour que votre application parle à Claude, GPT-6, Grok, Mistral et Gemini sans savoir lequel répond.
- Choisir en connaissance de cause entre l'abstraction maison, une bibliothèque (**LiteLLM**, **Vercel AI SDK**) et une passerelle (**OpenRouter**, LiteLLM Proxy).
- Router chaque requête vers le modèle le moins cher qui fait le travail, basculer automatiquement en cas de panne, réessayer intelligemment, mettre en cache et **mesurer** tout cela.
- Organiser des tests A/B entre fournisseurs pour que le choix repose sur des chiffres, pas sur une préférence.

## 1. Pourquoi aucune application sérieuse ne dépend d'un seul fournisseur

Les quatre leçons précédentes ont montré des API différentes mais un même constat : **le marché bouge tous les trimestres**. En 2026 seulement, vous avez vu : Perplexity arrêter ses Sonar Chat Completions le 27 septembre (L085) ; Google annoncer le **doublement** des tarifs Gemini au 1er décembre 2026 et au 1er janvier 2027 (L087) ; Mistral retirer `mistral-medium-2508` le 31 août (L086) ; Anthropic retirer Sonnet 4.5 de l'API au 30 novembre 2026 (`_recherche/01`). Ajoutez les pannes (chaque fournisseur a sa page de statut pour une raison), les files d'attente aux heures de pointe, les rate limits et les contraintes de souveraineté, et vous obtenez la règle d'architecture de cette leçon :

> 💡 **À retenir** — Le fournisseur de modèle est une **dépendance remplaçable**, comme une base de données ou un service d'e-mail. Votre code métier ne doit jamais importer `anthropic`, `openai` ou `google.genai` directement : il importe **votre** interface.

Trois bénéfices concrets pour une PME ou une agence : (1) **résilience** — si Gemini renvoie 503, Mistral répond ; (2) **coût** — 80 % des requêtes d'un assistant RH sont simples et peuvent partir sur Haiku 5.5, Small 4 ou `gpt-6-luna` à 0,10-0,15 $/M, les 20 % restants sur Sonnet 5.5 ou Argon ; (3) **négociation et conformité** — vous pouvez promettre à un client « vos données ne sortent pas d'Europe » en routant son tenant vers Mistral, sans réécrire l'application.

## 2. Trois niveaux d'abstraction : maison, bibliothèque, passerelle

| Approche | Exemples | Où tourne la logique | Avantages | Inconvénients |
|---|---|---|---|---|
| **Couche maison** | Interface + adaptateurs (section 3) | Dans votre code | Contrôle total, zéro dépendance supplémentaire, format interne adapté à votre métier | Vous maintenez les adaptateurs à chaque changement d'API |
| **Bibliothèque** | **LiteLLM** (Python), **Vercel AI SDK** (TypeScript) | Dans votre processus | 100+ fournisseurs, format unifié, retries et fallback intégrés | Une dépendance de plus, abstraction parfois « plus petit dénominateur commun » |
| **Passerelle (gateway)** | **OpenRouter** (SaaS), **LiteLLM Proxy** (auto-hébergé), Hugging Face Inference Providers (`router.huggingface.co/v1`) | Serveur intermédiaire | Une seule clé, une seule facture, routage et quotas centralisés, utilisable sans code (n8n) | Un intermédiaire voit vos données ; latence ajoutée ; commission ou coût d'exploitation |

La bonne réponse dépend de votre contexte : un prototype sur n8n passera par OpenRouter ; une application TypeScript Next.js prendra le Vercel AI SDK ; une plateforme Python avec exigences de conformité préférera LiteLLM Proxy auto-hébergé ou une couche maison. Dans tous les cas, **comprendre la couche maison** vous permet de juger les autres.

## 3. La couche maison en Python : interface, adaptateurs, routeur, repli, cache

Le code ci-dessous tient en un fichier et couvre tout le pipeline. Lisez-le bloc par bloc.

```bash
pip install "anthropic>=2.3" "openai>=2" mistralai google-genai
export ANTHROPIC_API_KEY=... OPENAI_API_KEY=... XAI_API_KEY=... MISTRAL_API_KEY=... GEMINI_API_KEY=...
```

```python
"""llm_gateway.py — couche multi-fournisseur minimale mais complète (Python 3.12+).

Interface commune -> adaptateurs -> routeur (coût / latence / qualité) -> repli + retries -> cache -> traces.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import time
from dataclasses import dataclass, field
from typing import Protocol

log = logging.getLogger("llm_gateway")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

# ---------- 1. Contrat commun ----------------------------------------------------------

@dataclass
class Message:
    role: str        # "user" | "assistant"
    content: str

@dataclass
class LLMResult:
    text: str
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    latency_ms: float
    cost_usd: float
    cached: bool = False

class LLMProvider(Protocol):
    name: str
    model: str
    def complete(self, system: str, messages: list[Message], max_tokens: int) -> LLMResult: ...

# Tarifs USD / M tokens, input / output (nov. 2026, pages Pricing officielles) — à relire chaque trimestre
PRICES: dict[str, tuple[float, float]] = {
    "claude-haiku-5-5": (0.10, 0.50), "claude-sonnet-5-5": (2.00, 10.00),
    "gpt-6-luna": (0.10, 0.50), "gpt-6.1-sol": (2.00, 10.00),
    "grok-4.7": (2.00, 6.00),
    "mistral-small-latest": (0.15, 0.60), "mistral-large-latest": (0.70, 2.10),
    "gemini-3.8-flash": (0.75, 3.75), "gemini-4-argon": (2.00, 10.00),
}

def cost(model: str, inp: int, out: int) -> float:
    p_in, p_out = PRICES.get(model, (0.0, 0.0))
    return (inp * p_in + out * p_out) / 1_000_000

# ---------- 2. Adaptateurs ---------------------------------------------------------------

class AnthropicProvider:
    name = "anthropic"
    def __init__(self, model: str = "claude-haiku-5-5"):
        import anthropic
        self.client, self.model = anthropic.Anthropic(), model          # lit ANTHROPIC_API_KEY
    def complete(self, system, messages, max_tokens):
        t0 = time.perf_counter()
        r = self.client.messages.create(
            model=self.model, max_tokens=max_tokens, system=system,
            messages=[{"role": m.role, "content": m.content} for m in messages],
        )
        text = "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
        return LLMResult(text, self.name, self.model, r.usage.input_tokens, r.usage.output_tokens,
                         (time.perf_counter() - t0) * 1000, cost(self.model, r.usage.input_tokens, r.usage.output_tokens))

class OpenAICompatibleProvider:
    """OpenAI, xAI, et tout endpoint compatible Responses (base_url différente, même code)."""
    def __init__(self, name: str, model: str, api_key_env: str, base_url: str | None = None):
        from openai import OpenAI
        self.name, self.model = name, model
        self.client = OpenAI(api_key=os.environ[api_key_env], base_url=base_url)
    def complete(self, system, messages, max_tokens):
        t0 = time.perf_counter()
        r = self.client.responses.create(
            model=self.model, instructions=system, max_output_tokens=max_tokens,
            input=[{"role": m.role, "content": m.content} for m in messages],
        )
        return LLMResult(r.output_text, self.name, self.model, r.usage.input_tokens, r.usage.output_tokens,
                         (time.perf_counter() - t0) * 1000, cost(self.model, r.usage.input_tokens, r.usage.output_tokens))

class MistralProvider:
    name = "mistral"
    def __init__(self, model: str = "mistral-small-latest"):
        from mistralai import Mistral
        self.client, self.model = Mistral(api_key=os.environ["MISTRAL_API_KEY"]), model
    def complete(self, system, messages, max_tokens):
        t0 = time.perf_counter()
        r = self.client.chat.complete(
            model=self.model, max_tokens=max_tokens,
            messages=[{"role": "system", "content": system}] + [{"role": m.role, "content": m.content} for m in messages],
        )
        u = r.usage
        return LLMResult(r.choices[0].message.content, self.name, self.model, u.prompt_tokens, u.completion_tokens,
                         (time.perf_counter() - t0) * 1000, cost(self.model, u.prompt_tokens, u.completion_tokens))

class GeminiProvider:
    name = "gemini"
    def __init__(self, model: str = "gemini-3.8-flash"):
        from google import genai
        self.client, self.model = genai.Client(), model                  # lit GEMINI_API_KEY
    def complete(self, system, messages, max_tokens):
        from google.genai import types
        t0 = time.perf_counter()
        contents = [types.Content(role="user" if m.role == "user" else "model",
                                  parts=[types.Part(text=m.content)]) for m in messages]
        r = self.client.models.generate_content(
            model=self.model, contents=contents,
            config=types.GenerateContentConfig(system_instruction=system, max_output_tokens=max_tokens),
        )
        u = r.usage_metadata
        return LLMResult(r.text or "", self.name, self.model, u.prompt_token_count, u.candidates_token_count,
                         (time.perf_counter() - t0) * 1000, cost(self.model, u.prompt_token_count, u.candidates_token_count))

# ---------- 3. Repli + retries + cache + traces -----------------------------------------

RETRYABLE = ("429", "500", "502", "503", "504", "timeout", "overloaded")

def is_retryable(err: Exception) -> bool:
    s = str(err).lower()
    return any(code in s for code in RETRYABLE)

@dataclass
class Gateway:
    chains: dict[str, list[LLMProvider]]          # "simple" -> [Haiku, Small 4, Luna] ; "complexe" -> [Sonnet, Argon, Sol]
    max_retries: int = 2
    cache: dict[str, LLMResult] = field(default_factory=dict)
    stats: dict[str, dict[str, float]] = field(default_factory=dict)   # latence moyenne et erreurs par fournisseur

    def _key(self, tier, system, messages, max_tokens) -> str:
        raw = json.dumps({"t": tier, "s": system, "m": [(m.role, m.content) for m in messages], "k": max_tokens}, ensure_ascii=False)
        return hashlib.sha256(raw.encode()).hexdigest()

    def _record(self, provider: str, latency_ms: float, ok: bool):
        s = self.stats.setdefault(provider, {"n": 0, "lat": 0.0, "err": 0})
        s["n"] += 1; s["err"] += 0 if ok else 1
        s["lat"] = latency_ms if s["n"] == 1 else 0.8 * s["lat"] + 0.2 * latency_ms   # moyenne mobile exponentielle

    def complete(self, tier: str, system: str, messages: list[Message], max_tokens: int = 512) -> LLMResult:
        key = self._key(tier, system, messages, max_tokens)
        if key in self.cache:                                            # cache exact (réponses déterministes seulement)
            hit = self.cache[key]; hit.cached = True; return hit
        last_error: Exception | None = None
        for provider in self.chains[tier]:                               # repli : fournisseur suivant si échec
            for attempt in range(self.max_retries + 1):
                try:
                    res = provider.complete(system, messages, max_tokens)
                    self._record(provider.name, res.latency_ms, True)
                    log.info("ok provider=%s model=%s in=%d out=%d cost=%.6f$ latency=%.0fms attempt=%d",
                             res.provider, res.model, res.input_tokens, res.output_tokens, res.cost_usd, res.latency_ms, attempt)
                    self.cache[key] = res
                    return res
                except Exception as err:                                 # noqa: BLE001 — on journalise tout
                    last_error = err
                    self._record(provider.name, 0.0, False)
                    if not is_retryable(err):
                        log.warning("erreur non réessayable sur %s : %s -> repli", provider.name, err); break
                    delay = min(8.0, (2 ** attempt) + random.uniform(0, 0.5))   # backoff exponentiel + jitter
                    log.warning("erreur %s sur %s, nouvel essai dans %.1fs", err, provider.name, delay); time.sleep(delay)
        raise RuntimeError(f"Tous les fournisseurs du palier '{tier}' ont échoué : {last_error}")

# ---------- 4. Routage par difficulté (coût) --------------------------------------------

def classify_tier(question: str) -> str:
    """Heuristique de départ : longueur et mots-clés. En production : pplx-decider ou Haiku 5.5 en juge (voir section 5)."""
    complexe = any(w in question.lower() for w in ("analyse", "compare", "rédige un contrat", "plan détaillé", "pourquoi"))
    return "complexe" if complexe or len(question) > 600 else "simple"

if __name__ == "__main__":
    gw = Gateway(chains={
        "simple":   [AnthropicProvider("claude-haiku-5-5"), MistralProvider("mistral-small-latest"),
                     OpenAICompatibleProvider("openai", "gpt-6-luna", "OPENAI_API_KEY")],
        "complexe": [AnthropicProvider("claude-sonnet-5-5"), GeminiProvider("gemini-4-argon"),
                     OpenAICompatibleProvider("xai", "grok-4.7", "XAI_API_KEY", base_url="https://api.x.ai/v1")],
    })
    system = "Vous êtes l'assistant RH d'une PME française. Répondez en français, précisément."
    for q in ["Combien de jours de congés payés acquiert-on par mois ?",
              "Compare le CDD et l'intérim pour un pic d'activité de 4 mois dans une PME de 30 salariés, avec les risques juridiques."]:
        tier = classify_tier(q)
        res = gw.complete(tier, system, [Message("user", q)])
        print(f"\n[{tier} → {res.provider}/{res.model} · {res.cost_usd:.5f} $ · {res.latency_ms:.0f} ms · cache={res.cached}]\n{res.text[:400]}")
    print("\nStatistiques :", json.dumps(gw.stats, indent=2))
```

Ce que ce fichier vous apprend, au-delà de la syntaxe :

- **Le contrat est pauvre volontairement** (`system`, `messages`, `max_tokens` → `LLMResult`). Plus votre interface est riche, plus chaque adaptateur devient fragile. Ajoutez le streaming, les outils ou les images **quand un besoin réel l'exige**, et acceptez que certaines fonctions ne soient disponibles que chez certains fournisseurs (voir pièges, section 8).
- **Le repli (fallback) et les retries sont deux choses différentes.** On réessaie le **même** fournisseur sur une erreur transitoire (429, 5xx, timeout) avec un délai croissant et un bruit aléatoire (le *jitter* évite que mille clients réessaient à la même seconde). On bascule vers le **suivant** quand l'erreur n'est pas transitoire (400, 401, contenu refusé) ou après épuisement des essais.
- **Le cache exact** (empreinte SHA-256 de la requête) ne vaut que pour des requêtes répétées à l'identique (FAQ, classification). Pour un cache « sémantique » (questions proches), on compare des embeddings (M20). N'oubliez pas les caches **côté fournisseur** : prompt caching Anthropic (lecture à 0,1× voire 0,025×, L073), `cached input` xAI, context caching Gemini (L087) : ce sont souvent les économies les plus faciles.
- **Les statistiques par fournisseur** (latence moyenne mobile, taux d'erreur) sont la matière première d'un routage par latence : il suffit de trier `chains[tier]` par `stats[name]["lat"]` toutes les minutes pour que le plus rapide passe en tête.

🎮 **Défi** — Coupez le réseau (ou mettez une clé Anthropic fausse) et relancez : vous devez voir « erreur non réessayable → repli » puis une réponse de Mistral. Ensuite, mettez une fausse `base_url` sur xAI : cette fois vous devez voir les retries, puis le repli.

## 4. Les mêmes briques avec LiteLLM (Python) et OpenRouter

### 4.1 LiteLLM : un `completion()` pour cent fournisseurs

[LiteLLM](https://docs.litellm.ai/docs/) (licence MIT) expose un appel unique au format Chat Completions, traduit vers chaque fournisseur ; le modèle se nomme `fournisseur/modèle`. Son `Router` intègre fallback, retries, répartition de charge et budget. Le même outil existe en **proxy** auto-hébergé (une passerelle OpenAI-compatible avec clés virtuelles, quotas par équipe et journal des coûts).

```python
"""Équivalent de la section 3 avec LiteLLM (pip install litellm). Les clés sont lues dans l'environnement."""
from litellm import Router

router = Router(
    model_list=[
        {"model_name": "simple",   "litellm_params": {"model": "anthropic/claude-haiku-5-5"}},
        {"model_name": "simple",   "litellm_params": {"model": "mistral/mistral-small-latest"}},
        {"model_name": "complexe", "litellm_params": {"model": "anthropic/claude-sonnet-5-5"}},
        {"model_name": "complexe", "litellm_params": {"model": "gemini/gemini-4-argon"}},
        {"model_name": "complexe", "litellm_params": {"model": "xai/grok-4.7"}},
    ],
    fallbacks=[{"complexe": ["simple"]}],   # si tout le palier complexe échoue, dégrader vers le palier simple
    num_retries=2,
    routing_strategy="latency-based-routing",  # ou "simple-shuffle", "least-busy", "cost-based-routing" (voir doc)
)

resp = router.completion(
    model="complexe",
    messages=[{"role": "system", "content": "Assistant RH, français."},
              {"role": "user", "content": "Compare CDD et intérim pour un pic de 4 mois."}],
    max_tokens=400,
)
print(resp.choices[0].message.content[:300])
print("Modèle réellement utilisé :", resp.model, "| coût estimé :", resp._hidden_params.get("response_cost"))
```

Vérifiez les noms exacts des stratégies de routage et des paramètres sur la documentation : LiteLLM évolue vite et ces identifiants peuvent changer entre versions.

### 4.2 OpenRouter : une clé, une facture, tous les modèles

[OpenRouter](https://openrouter.ai/docs/quickstart) est une passerelle SaaS : vous pointez le SDK OpenAI vers `https://openrouter.ai/api/v1` avec une clé `OPENROUTER_API_KEY`, et vous nommez les modèles avec un préfixe d'éditeur. Vous n'avez **aucune clé** chez les fournisseurs eux-mêmes : OpenRouter facture votre consommation (avec une commission, consultez la page tarifaire du moment) et gère le repli entre hébergeurs.

```typescript
// openrouter.ts — le SDK OpenAI, une base_url différente, et c'est tout
import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENROUTER_API_KEY,
  baseURL: "https://openrouter.ai/api/v1",
  defaultHeaders: { "HTTP-Referer": "https://mon-app.example", "X-Title": "Assistant RH" }, // attribution facultative
});

const r = await client.chat.completions.create({
  model: "mistralai/mistral-small-latest", // identifiant OpenRouter : vérifiez la graphie exacte dans le catalogue
  messages: [{ role: "user", content: "Résume en 2 phrases la différence entre CDD et intérim." }],
});
console.log(r.choices[0].message.content);
```

Quand choisir OpenRouter ? Prototypage, hackathon, n8n ou Make (une seule connexion), équipes sans service achats pour cinq fournisseurs. Quand l'éviter ? Données réglementées (un intermédiaire supplémentaire voit les prompts), applications à très fort volume (commission), besoin de fonctions avancées spécifiques (Files API Gemini, Collections xAI).

> 🔗 **Documentation officielle** — Pour les modèles ouverts hébergés (Qwen, Llama, DeepSeek, gpt-oss…), la passerelle Hugging Face [Inference Providers](https://huggingface.co/docs/inference-providers/main/guides/first-api-call) joue le même rôle : endpoint `https://router.huggingface.co/v1`, tarifs du fournisseur sans marge (nov. 2026).

## 5. Vercel AI SDK : le multi-fournisseur côté TypeScript

Le [Vercel AI SDK](https://ai-sdk.dev/docs/introduction) (Apache 2.0) est la bibliothèque de référence en TypeScript : un cœur (`ai`) et un paquet par fournisseur (`@ai-sdk/anthropic`, `@ai-sdk/openai`, `@ai-sdk/xai`, `@ai-sdk/mistral`, `@ai-sdk/google`). L'objet `model` est interchangeable, ce qui rend le repli trivial.

```bash
npm install ai @ai-sdk/anthropic @ai-sdk/openai @ai-sdk/xai @ai-sdk/mistral @ai-sdk/google
```

```typescript
// gateway.ts — routage + repli + retries + cache + traces avec le Vercel AI SDK (npx tsx gateway.ts)
import { generateText, type LanguageModel } from "ai";
import { anthropic } from "@ai-sdk/anthropic";
import { openai, createOpenAI } from "@ai-sdk/openai";
import { xai } from "@ai-sdk/xai";
import { mistral } from "@ai-sdk/mistral";
import { google } from "@ai-sdk/google";
import { createHash } from "node:crypto";

// Tarifs USD / M tokens (nov. 2026) — à relire chaque trimestre
const PRICES: Record<string, [number, number]> = {
  "claude-haiku-5-5": [0.1, 0.5], "claude-sonnet-5-5": [2, 10], "gpt-6-luna": [0.1, 0.5],
  "grok-4.7": [2, 6], "mistral-small-latest": [0.15, 0.6], "gemini-4-argon": [2, 10],
};

type Candidate = { id: string; provider: string; model: LanguageModel };
const perplexity = createOpenAI({ baseURL: "https://api.perplexity.ai", apiKey: process.env.PERPLEXITY_API_KEY }); // exemple d'endpoint compatible

const CHAINS: Record<"simple" | "complexe", Candidate[]> = {
  simple: [
    { id: "claude-haiku-5-5", provider: "anthropic", model: anthropic("claude-haiku-5-5") },
    { id: "mistral-small-latest", provider: "mistral", model: mistral("mistral-small-latest") },
    { id: "gpt-6-luna", provider: "openai", model: openai("gpt-6-luna") },
  ],
  complexe: [
    { id: "claude-sonnet-5-5", provider: "anthropic", model: anthropic("claude-sonnet-5-5") },
    { id: "gemini-4-argon", provider: "google", model: google("gemini-4-argon") },
    { id: "grok-4.7", provider: "xai", model: xai("grok-4.7") },
  ],
};

const cache = new Map<string, string>();
const stats: Record<string, { n: number; lat: number; err: number }> = {};

function record(id: string, lat: number, ok: boolean) {
  const s = (stats[id] ??= { n: 0, lat: 0, err: 0 });
  s.n++; if (!ok) s.err++;
  s.lat = s.n === 1 ? lat : 0.8 * s.lat + 0.2 * lat;
}

export async function complete(tier: "simple" | "complexe", system: string, prompt: string) {
  const key = createHash("sha256").update(JSON.stringify({ tier, system, prompt })).digest("hex");
  if (cache.has(key)) return { text: cache.get(key)!, id: "cache", cost: 0 };

  // Routage par latence : les candidats les plus rapides (statistiques récentes) passent en premier
  const ordered = [...CHAINS[tier]].sort((a, b) => (stats[a.id]?.lat ?? 0) - (stats[b.id]?.lat ?? 0));

  let lastError: unknown;
  for (const c of ordered) {
    const t0 = performance.now();
    try {
      const r = await generateText({ model: c.model, system, prompt, maxOutputTokens: 500, maxRetries: 2 }); // retries intégrés (backoff)
      const lat = performance.now() - t0;
      record(c.id, lat, true);
      const [pIn, pOut] = PRICES[c.id] ?? [0, 0];
      const cost = ((r.usage.inputTokens ?? 0) * pIn + (r.usage.outputTokens ?? 0) * pOut) / 1e6;
      console.info(JSON.stringify({ event: "llm_ok", provider: c.provider, model: c.id, lat: Math.round(lat), cost, usage: r.usage }));
      cache.set(key, r.text);
      return { text: r.text, id: c.id, cost };
    } catch (err) {
      lastError = err; record(c.id, performance.now() - t0, false);
      console.warn(JSON.stringify({ event: "llm_fail", provider: c.provider, model: c.id, error: String(err).slice(0, 200) }));
    }
  }
  throw new Error(`Tous les fournisseurs du palier ${tier} ont échoué : ${String(lastError)}`);
}

// Démo
const system = "Vous êtes l'assistant RH d'une PME française. Répondez en français.";
const r1 = await complete("simple", system, "Combien de jours de congés payés acquiert-on par mois ?");
console.log(`[${r1.id} · ${r1.cost.toFixed(5)} $]`, r1.text.slice(0, 200));
const r2 = await complete("simple", system, "Combien de jours de congés payés acquiert-on par mois ?");
console.log(`[${r2.id}]`, "réponse servie depuis le cache :", r2.id === "cache");
console.log(stats);
```

Deux remarques : `maxRetries` du SDK gère les erreurs transitoires avec backoff pour vous, mais pas le repli entre fournisseurs, que la boucle ajoute ; `createOpenAI({ baseURL })` permet d'enrôler tout endpoint compatible (xAI, Perplexity, LiteLLM Proxy, vLLM local). Vérifiez les noms de champs `usage` (ils ont changé entre les versions majeures du SDK).

## 6. Routage par coût, latence et qualité : la méthode

Un routeur a trois entrées et une sortie :

```
   requête ─► [classifieur de difficulté] ─► palier (simple / complexe / recherche / documents)
                                               │
   stats latence/erreurs ──────────────────────┤
   contraintes (souveraineté, budget tenant) ──┤
                                               ▼
                                        liste ordonnée de candidats ─► repli séquentiel
```

- **Coût** : le classifieur décide du **palier**. Commencez par des règles (longueur, mots-clés, présence de pièce jointe) ; puis entraînez ou configurez un petit modèle juge : `pplx-decider-flash-v1.2` (0,01 $/M, L085) ou Claude Haiku 5.5 (0,10 $/M) avec un prompt « Cette question nécessite-t-elle un raisonnement complexe ? Réponds `simple` ou `complexe` ». Même à 1 000 décisions pour 0,01 $, le juge est rentable dès que 20 % des requêtes évitent un modèle à 10 $/M en sortie.
- **Latence** : triez les candidats d'un palier par latence moyenne mobile récente (sections 3 et 5). Ajoutez un **disjoncteur** (*circuit breaker*) : après N échecs consécutifs, retirez le fournisseur pendant 60 s au lieu de lui faire perdre du temps à chaque requête.
- **Qualité** : elle ne se devine pas, elle se mesure (section 7). Chaque palier contient les modèles qui atteignent le score minimal sur votre jeu de test ; au sein du palier, le prix et la latence départagent.
- **Contraintes** : un tenant « données européennes » ne voit qu'une chaîne Mistral (inférence régionale, L086) ; une requête « actualité » part vers Grok, Perplexity ou Gemini grounding ; un PDF de 400 pages va vers Gemini ou Claude (1 M de contexte).

> ⚠️ **Piège fréquent** — Le routage par coût dégrade silencieusement la qualité si le classifieur se trompe. Journalisez le palier choisi et **mesurez le taux de reprise** (l'utilisateur reformule ou clique « réessayer avec un meilleur modèle »). Un routeur sans métrique de satisfaction n'est pas un routeur, c'est un pari.

## 7. Tests A/B et évaluation entre fournisseurs

La page Anthropic [Define success / build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) donne la méthode, valable pour tous les fournisseurs : des critères **SMART**, un jeu de cas représentatif (50 à 200 exemples par tâche, avec les cas limites), des métriques automatiques (correspondance exacte, similarité cosinus, ROUGE-L pour les résumés) et un **LLM juge** avec une échelle de Likert ou un verdict binaire pour les tâches ouvertes.

L'outil le plus simple pour comparer des fournisseurs est [promptfoo](https://github.com/promptfoo/promptfoo) (MIT ; rachat par OpenAI annoncé le 9 mars 2026) : un fichier YAML liste les fournisseurs, les prompts et les assertions ; une commande produit une matrice de résultats et de coûts.

```yaml
# promptfooconfig.yaml — même prompt, cinq fournisseurs, assertions identiques
prompts:
  - "Vous êtes l'assistant RH d'une PME française. Question : {{question}}. Répondez en français, en citant l'article du Code du travail si pertinent."
providers:
  - anthropic:messages:claude-haiku-5-5
  - openai:responses:gpt-6-luna
  - mistral:mistral-small-latest
  - google:gemini-3.8-flash
  - xai:grok-4.7
tests:
  - vars: { question: "Combien de jours de congés payés acquiert-on par mois de travail effectif ?" }
    assert:
      - type: icontains
        value: "2,5"
      - type: llm-rubric
        value: "La réponse mentionne 2,5 jours ouvrables par mois (30 jours par an) et ne contient aucune affirmation juridique fausse."
  - vars: { question: "Un salarié peut-il refuser une modification de son lieu de travail ?" }
    assert:
      - type: llm-rubric
        value: "Distingue clause de mobilité, modification du contrat et simple changement des conditions de travail."
```

Lancez `npx promptfoo eval` puis `npx promptfoo view` : vous obtenez, par fournisseur, le taux de réussite, la latence et le coût. C'est **ce tableau** qui décide de la composition des paliers, et il se relance à chaque nouveau modèle ou hausse de prix. Pour le A/B **en production** (deux fournisseurs servent chacun 50 % des utilisateurs), ajoutez un identifiant de variante dans vos traces et comparez les métriques d'usage (reformulations, pouces, durée de session). Les noms des fournisseurs dans promptfoo (`anthropic:messages:`, `openai:responses:`…) sont à confirmer dans sa documentation selon la version installée.

## 8. Observabilité : ce qu'il faut tracer, et avec quoi

Chaque appel doit produire **une trace** contenant au minimum : identifiant de requête, tenant, palier, fournisseur et modèle **réellement** utilisés, tentative, latence, tokens in/out/cache, coût calculé, statut, et un hachage du prompt (pas le prompt en clair si les données sont sensibles). Les journaux JSON des sections 3 et 5 sont un début ; en production, envoyez-les à une plateforme.

| Outil (nov. 2026, source Infrabase) | Modèle | Intérêt multi-fournisseur |
|---|---|---|
| **Langfuse** | Open source (MIT, cœur) ; Hobby gratuit 50 k unités/mois, Core 29 $/mois ; racheté par ClickHouse (janv. 2026) | Coûts par modèle, prompts versionnés, évals, auto-hébergeable |
| **LangSmith** | SaaS | Tracing natif LangChain/LangGraph |
| **Arize Phoenix** | Source disponible ; AX gratuit 25 k spans/mois | OpenTelemetry, local |
| **Helicone** | Apache 2.0 ; gratuit 10 k req./mois | Proxy « une ligne » devant n'importe quelle API |
| **Opik**, **W&B Weave**, **MLflow GenAI** | Apache 2.0 | Métriques intégrées, tracing |

Deux réflexes d'ingénieur : (1) une **alerte de budget** par tenant et par fournisseur (le risque « consommation non bornée » est au Top 10 OWASP LLM 2026, M23) ; (2) un **tableau de bord hebdomadaire** coût par palier, taux de repli, latence p95 par fournisseur. Si le taux de repli d'un fournisseur dépasse 5 % sur une semaine, retirez-le ou renégociez.

> 🔗 **Documentation officielle** — L'[observabilité](https://infrabase.ai/blog/llm-observability-tools-compared) et les évaluations sont approfondies en L103 et L104 (module M22).

## 9. Les pièges de l'abstraction (ce que la couche commune ne peut pas cacher)

| Différence entre fournisseurs | Conséquence pour votre adaptateur |
|---|---|
| Rôle système : paramètre `system` (Anthropic), `instructions` (Responses OpenAI/xAI), message `system` (Mistral), `system_instruction` (Gemini) | L'adaptateur traduit ; votre interface n'expose qu'un champ `system` |
| `max_tokens` obligatoire chez Anthropic ; `max_output_tokens` ailleurs ; exigé par l'Agent API Perplexity pour les modèles Anthropic | Toujours le fournir |
| `temperature` refusée (erreur 400) sur Claude ≥ 4.7 (`_recherche/01`) ; `logprobs` absents sur Grok ≥ 4.20 | Ne mettez pas ces paramètres dans l'interface commune ; passez-les par un dictionnaire d'options propre à chaque fournisseur |
| Tokenizers différents (le nouveau tokenizer Claude compte ~30 % de tokens en plus sur Haiku 5.5 qu'en 4.5) | Comparez les **coûts en dollars**, jamais les tokens |
| Sorties structurées : `output_config.format` (Anthropic), `text.format` (Responses), `response_format` (Mistral), `response_schema` (Gemini) | Implémentez `complete_json(schema)` par adaptateur et validez toujours côté code (Pydantic/Zod) |
| Outils serveur propriétaires (`x_search`, grounding Google, Files API, Collections) | Ce sont des **raisons de choisir** un fournisseur, pas des fonctions à abstraire |
| Fenêtres et tarifs par paliers (xAI ×2 au-delà de 200 k ; Haiku 5.5 ×5 au-delà de 100 k) | Le routeur doit connaître la taille de l'entrée avant de choisir |

> 💡 **À retenir** — Une bonne abstraction est **mince** : elle unifie les 80 % communs (texte, système, tokens, coût, erreurs) et laisse passer les 20 % spécifiques par une porte explicite. Une abstraction qui promet « tout, partout » finit par n'offrir que le plus petit dénominateur commun.

## 🧪 Exercice pratique

**Consigne.** Vous livrez à un cabinet d'expertise comptable un assistant interne multi-fournisseur. À partir de `llm_gateway.py` (Python) **ou** de `gateway.ts` (TypeScript), réalisez :

1. **Trois paliers** : `simple` (Haiku 5.5 → Mistral Small 4 → `gpt-6-luna`), `complexe` (Sonnet 5.5 → Gemini 4 Argon → Grok 4.7), `souverain` (Mistral Large 4 → Mistral Small 4 uniquement), et un drapeau `tenant_eu: bool` qui force le palier `souverain`.
2. Un **classifieur** de difficulté par modèle juge (Haiku 5.5 ou `pplx-decider-flash-v1.2`), avec journalisation de la décision.
3. Un **disjoncteur** : après 3 échecs consécutifs, un fournisseur est ignoré pendant 60 secondes.
4. Un fichier **promptfoo** avec 10 questions comptables (TVA, amortissements, délais de dépôt) et des assertions, exécuté sur les trois modèles du palier `simple`.
5. Un **rapport** d'une page : coût moyen par requête et par palier, latence p95 par fournisseur, taux de repli, et votre recommandation de composition des paliers chiffrée.

**Critères de réussite.**
- Aucune clé en dur ; chaque fournisseur manquant (variable absente) est **désactivé proprement** au démarrage, pas à la première requête.
- Une panne simulée (clé invalide) sur le premier fournisseur d'un palier n'augmente la latence que d'un appel raté, pas de trois.
- Le rapport cite les tarifs officiels (nov. 2026) et mentionne la hausse Gemini de janvier 2027 dans la projection.
- Les requêtes du tenant européen n'apparaissent **jamais** dans les traces d'un fournisseur non européen.

**Pistes de corrigé.** Pour le disjoncteur, stockez `open_until: float` par fournisseur dans `stats` et sautez-le si `time.time() < open_until`. Pour le classifieur, demandez une sortie structurée `{ "tier": "simple" | "complexe" }` au modèle juge et retombez sur l'heuristique en cas d'erreur. Pour le p95, conservez les 1 000 dernières latences par fournisseur dans un `deque` et prenez `sorted(l)[int(0.95 * len(l))]`.

## ✅ Auto-évaluation express

1. Quelle est la différence entre un *retry* et un *fallback*, et quelles erreurs justifient l'un ou l'autre ?
2. Pourquoi comparer les fournisseurs en dollars plutôt qu'en tokens ?
3. Citez un cas où une passerelle comme OpenRouter est déconseillée.

**Réponses.** 1) Le retry réessaie le **même** fournisseur après un délai croissant sur une erreur transitoire (429, 5xx, timeout) ; le fallback bascule vers un **autre** fournisseur sur une erreur non transitoire (400, 401, refus) ou après épuisement des retries. 2) Parce que chaque fournisseur a son tokenizer : un même texte ne donne pas le même nombre de tokens, et seuls les tarifs appliqués aux tokens réellement comptés sont comparables. 3) Données réglementées ou sensibles (un intermédiaire supplémentaire voit les prompts), très forts volumes (commission), ou besoin d'une fonction propriétaire non exposée par la passerelle.

## 📚 Pour aller plus loin
- [Claude Platform — Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model) 🇬🇧 — grille de choix coût / intelligence / latence.
- [Vercel AI SDK — Introduction](https://ai-sdk.dev/docs/introduction) 🇬🇧 — `generateText`, `streamText`, outils et agents en TypeScript (approfondi en L101).
- [LiteLLM — Documentation](https://docs.litellm.ai/docs/) 🇬🇧 — Router, fallbacks, proxy auto-hébergé, budgets.
- [QA Skills — DeepEval vs Ragas vs promptfoo 2026](https://qaskills.sh/blog/deepeval-vs-ragas-vs-promptfoo-2026) 🇬🇧 — choisir son outil d'évaluation.
- [Hugging Face — Inference Providers pricing](https://huggingface.co/docs/inference-providers/pricing) 🇬🇧 — la passerelle des modèles ouverts.
