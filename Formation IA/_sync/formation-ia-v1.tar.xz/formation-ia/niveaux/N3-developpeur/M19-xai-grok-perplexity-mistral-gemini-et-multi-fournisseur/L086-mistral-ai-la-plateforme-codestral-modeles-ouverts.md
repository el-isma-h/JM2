---
id: L086
module: M19
level: N3
title: "Mistral AI : La Plateforme, Codestral, modèles ouverts"
minutes: 50
objectives:
  - "Appeler Mistral Large 4 et Mistral Small 4 depuis Python et TypeScript avec le SDK officiel mistralai, en streaming, avec une clé lue depuis l'environnement"
  - "Utiliser Codestral en complétion de code (fill-in-the-middle) et expliquer la place de Devstral et de Vibe dans l'offre"
  - "Choisir entre API hébergée en Europe et poids ouverts auto-hébergés selon les contraintes de souveraineté, de licence et de coût"
  - "Lire la grille tarifaire et le cycle de vie des modèles Mistral pour planifier une migration"
skills: ["C3.1"]
sources:
  - { title: "Mistral — Models overview", url: "https://docs.mistral.ai/getting-started/models/", lang: "en" }
  - { title: "Mistral — Catalogue des modèles", url: "https://docs.mistral.ai/models", lang: "en" }
  - { title: "Mistral — Pricing", url: "https://docs.mistral.ai/inference/pricing", lang: "en" }
  - { title: "Mistral — Codestral 25.08", url: "https://docs.mistral.ai/models/codestral-25-08", lang: "en" }
  - { title: "Mistral — Regional inference", url: "https://docs.mistral.ai/inference/regional-inference", lang: "en" }
  - { title: "Mistral — Model lifecycle", url: "https://docs.mistral.ai/inference/model-lifecycle", lang: "en" }
  - { title: "Mistral — Référence API", url: "https://docs.mistral.ai/api", lang: "en" }
  - { title: "Mistral — AI Studio (ex-La Plateforme)", url: "https://docs.mistral.ai/studio", lang: "en" }
  - { title: "Mistral — Vibe (CLI de code)", url: "https://docs.mistral.ai/vibe", lang: "en" }
  - { title: "Mistral — annonce Mistral Small 4", url: "https://mistral.ai/news/mistral-small-4/", lang: "en" }
---

# Mistral AI : La Plateforme, Codestral, modèles ouverts

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 19

## 🎯 Ce que vous saurez faire
- Créer une clé sur la console Mistral (AI Studio, ex-La Plateforme), l'enregistrer dans `MISTRAL_API_KEY` et obtenir une réponse de **Mistral Large 4** en Python et en TypeScript.
- Faire compléter du code par **Codestral** au milieu d'un fichier (fill-in-the-middle), comme le font les extensions d'IDE.
- Argumenter devant un DSI ou un DPO pourquoi Mistral est l'option « souveraineté européenne », et où s'arrête cet argument.
- Décider, modèle par modèle, entre l'API et l'auto-hébergement des poids ouverts (Apache 2.0 ou licence Mistral).

## 1. Le champion français : ce que cela change concrètement

Mistral AI est née à Paris en 2023, fondée par trois chercheurs passés par DeepMind et Meta. En trois ans, elle est devenue l'alternative européenne de référence aux fournisseurs américains, pour deux raisons que vos clients vous citeront :

1. **Souveraineté** : l'entreprise est française, soumise au RGPD en tant que responsable européen, et propose une [inférence régionale](https://docs.mistral.ai/inference/regional-inference) permettant de choisir où tournent vos requêtes. Pour un cabinet comptable, une mutuelle ou une collectivité, « les données restent en Europe » est souvent un critère d'appel d'offres avant même la qualité du modèle.
2. **Poids ouverts** : une partie du catalogue est publiée sous **Apache 2.0** (Mistral Small 4, Ministral 3), c'est-à-dire librement auto-hébergeable, y compris pour un usage commercial, sans redevance. Vous pouvez prototyper sur l'API puis rapatrier le modèle sur vos serveurs si les volumes ou la confidentialité l'exigent (voir les modules M29 et `_recherche/04` pour le matériel).

> ⚠️ **Piège fréquent** — « Mistral = open source » est un raccourci. **Mistral Large 4** est publié sous la *Mistral Ecosystem Open Weight License*, qui n'est pas Apache 2.0 : lisez-la avant un déploiement commercial. Seuls Small 4 et Ministral 3 sont Apache 2.0 (nov. 2026, [page Models](https://docs.mistral.ai/getting-started/models/)).

La plateforme développeur s'appelait **La Plateforme** ; la documentation la nomme désormais **AI Studio** ([doc](https://docs.mistral.ai/studio), console sur [console.mistral.ai](https://console.mistral.ai)). Les deux noms circulent : c'est le même produit.

## 2. Le catalogue (nov. 2026)

Source : [Models overview](https://docs.mistral.ai/getting-started/models/) et [catalogue](https://docs.mistral.ai/models).

| Famille | Modèle (version) | Licence | Points forts |
|---|---|---|---|
| Généraliste phare | **Mistral Large 4** (v26.10) | Mistral Ecosystem Open Weight License | Multimodal, raisonnement, agents |
| Généraliste efficace | **Mistral Small 4** (v26.03) | Apache 2.0 | Hybride instruct / raisonnement / code ; 119 B paramètres dont 6 B actifs (annonce du 16 mars 2026) |
| Petits modèles | **Ministral 3** 14B / 8B / 3B (v25.12) | Apache 2.0 | Texte + vision, embarqué ou edge |
| Code | **Codestral** (v25.08) | API | Complétion FIM, génération, tests |
| Code (agents) | **Devstral 2** + CLI **Vibe** | voir annonce | Agents de développement, terminal |
| Documents | **OCR 4.1**, OCR 3 | API | PDF et images → Markdown structuré |
| Voix | **Voxtral** Mini/Small Transcribe 3, Realtime, TTS 3 | API (poids partiels sur Hugging Face) | Transcription, synthèse |
| Embeddings | Mistral Embed, Codestral Embed | API | RAG texte et code (M20) |
| Sécurité | Shieldstral 1.0, Mistral Moderation 2 | API (Moderation gratuite) | Garde-fous (M23) |
| Séries temporelles | Timestral 1.0 | API | Prévision |
| Tiers hébergés | GLM 5.3 / 5.3 Flash (Z.ai), DeepSeek V4.1 Flash (1 M contexte) | — | Modèles chinois servis depuis l'infrastructure Mistral |

Le [cycle de vie](https://docs.mistral.ai/inference/model-lifecycle) est explicite et daté : `mistral-medium-2508` retiré le 31 août 2026, `devstral-2512` et `mistral-small-2506` le 31 juillet 2026, `mistral-medium-3-5` sera retiré le 30 avril 2027 au profit de Large 4. Notez ces dates dans votre backlog : une migration de modèle non planifiée est une panne de production.

## 3. Premier appel : Python et TypeScript

```bash
export MISTRAL_API_KEY="..."           # créée sur console.mistral.ai
pip install mistralai                  # SDK Python officiel
npm install @mistralai/mistralai       # SDK TypeScript officiel
```

### 3.1 Python, avec streaming

```python
"""Mistral Large 4 en streaming : rédaction d'une réponse à un avis Google pour un restaurant."""
import os
from mistralai import Mistral

client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])

messages = [
    {"role": "system", "content": "Vous êtes le gérant d'un restaurant lyonnais. Ton chaleureux, 4 phrases maximum, en français."},
    {"role": "user", "content": "Avis 2/5 : « Service lent, mais la quenelle était excellente. » Rédigez la réponse publique."},
]

# L'alias -latest suit la dernière version stable ; en production, figez la version datée (ex. mistral-large-2610)
with client.chat.stream(model="mistral-large-latest", messages=messages) as stream:
    for event in stream:
        delta = event.data.choices[0].delta.content
        if delta:
            print(delta, end="", flush=True)
print()
```

Hors streaming, `client.chat.complete(model=..., messages=...)` renvoie `choices[0].message.content` et un objet `usage` (`prompt_tokens`, `completion_tokens`) avec lequel vous calculerez le coût.

### 3.2 TypeScript, avec sortie JSON

```typescript
// mistral-json.ts — npx tsx mistral-json.ts
import { Mistral } from "@mistralai/mistralai";

const client = new Mistral({ apiKey: process.env.MISTRAL_API_KEY ?? "" });

async function main() {
  const result = await client.chat.complete({
    model: "mistral-small-latest", // Small 4 : 0,15 $/M in, 0,60 $/M out (nov. 2026)
    messages: [
      { role: "system", content: "Tu extrais des données de devis d'artisan. Réponds uniquement en JSON." },
      { role: "user", content: "Devis plomberie : remplacement chauffe-eau 200 L, main d'œuvre 380 € HT, fourniture 650 € HT, TVA 10 %." },
    ],
    responseFormat: { type: "json_object" }, // JSON garanti syntaxiquement ; validez le schéma côté code (Zod)
  });
  const content = result.choices?.[0]?.message?.content;
  console.log(typeof content === "string" ? JSON.parse(content) : content);
  console.log("Usage :", result.usage);
}

main().catch((e) => { console.error(e.message); process.exit(1); });
```

> 💡 **À retenir** — Les SDK Mistral reprennent le vocabulaire Chat Completions (`messages`, `choices`, `usage`). Si vous avez suivi L078 (OpenAI), vous êtes en terrain connu. La [référence API](https://docs.mistral.ai/api) liste aussi les endpoints `fim`, `ocr`, `embeddings`, `audio`, `moderations` et `agents`.

## 4. Codestral : la complétion de code « au milieu »

Les assistants de code dans l'IDE ne génèrent pas seulement « à la suite » : ils remplissent le **trou entre ce qui précède et ce qui suit**. C'est le *fill-in-the-middle* (FIM), et [Codestral](https://docs.mistral.ai/models/codestral-25-08) en est spécialiste. L'endpoint dédié prend un `prompt` (avant le curseur) et un `suffix` (après).

```python
"""Codestral en fill-in-the-middle : compléter le corps d'une fonction entre une signature et ses tests."""
import os
from mistralai import Mistral

client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])

prompt = '''def calcul_tva(montant_ht: float, taux: float = 0.20) -> float:
    """Renvoie le montant de TVA arrondi au centime."""
'''
suffix = '''

assert calcul_tva(100) == 20.0
assert calcul_tva(38.0, 0.10) == 3.8
'''

completion = client.fim.complete(
    model="codestral-latest",   # 0,30 $/M in, 0,90 $/M out (nov. 2026)
    prompt=prompt,
    suffix=suffix,
    max_tokens=128,
    temperature=0,              # complétion déterministe pour du code
)
print(prompt + completion.choices[0].message.content + suffix)
```

Autour de Codestral, Mistral a construit une offre « agent de code » : **Devstral 2** (modèle d'agent) et **Vibe**, une CLI de code dans le terminal ([doc Vibe](https://docs.mistral.ai/vibe), [annonce](https://mistral.ai/news/devstral-2-vibe-cli/)), concurrente de Claude Code, Codex CLI et Gemini CLI. Pour une équipe qui veut un agent de code dont les requêtes ne quittent pas l'Europe, c'est l'option à tester en premier.

🎮 **Défi** — Dans le script FIM, remplacez `temperature=0` par `temperature=0.8` et lancez trois fois. Combien de versions passent les `assert` ? Vous venez de comprendre pourquoi les outils de complétion travaillent à température basse.

## 5. Tarifs (nov. 2026) et grille de décision API vs auto-hébergement

Source : [page Pricing](https://docs.mistral.ai/inference/pricing), USD par million de tokens (facturation possible en EUR), tier Standard. Des tiers Batch et [Priority](https://docs.mistral.ai/inference/priority-tier) existent.

| Modèle | Input | Input en cache | Output |
|---|---|---|---|
| Mistral Large 4 | 0,70 | 0,07 | 2,10 |
| Mistral Small 4 | 0,15 | 0,015 | 0,60 |
| Ministral 3 14B | 0,20 | 0,02 | 0,20 |
| Ministral 3 8B / 3B | 0,15 / 0,10 | — | — (voir page) |
| Codestral | 0,30 | 0,03 | 0,90 |
| GLM 5.3 / GLM 5.3 Flash | 1,40 / 0,15 | 0,14 / 0,03 | 4,40 / 0,50 |
| DeepSeek V4.1 Flash | 0,30 | 0,007 | 1,20 |

Hors tokens : OCR 4.1 **4 $ / 1 000 pages** (OCR 3 : 2 $) ; Voxtral Mini Transcribe 3 0,0035 $/min (Realtime 0,008 $/min) ; TTS 3 13 $/M caractères ; Codestral Embed 0,15 $ et Mistral Embed 0,10 $ par M tokens ; Moderation 2 **gratuite** ; agents vocaux de 0,04 à 0,08 $/min. Le fine-tuning n'est pas tarifé sur la page lue (à vérifier sur la page officielle).

**Lecture** : Mistral Large 4 à 0,70 $/2,10 $ coûte environ **trois fois moins** que Claude Sonnet 5.5 ou `gpt-6.1-sol` (2 $/10 $) en entrée, et presque cinq fois moins en sortie. Mistral Small 4 est dans la catégorie de Claude Haiku 5.5 (0,10 $/0,50 $) et `gpt-6-luna`. Ce positionnement prix est le second argument commercial après la souveraineté ; le revers est un écart de qualité sur les tâches les plus difficiles, à mesurer sur **vos** cas (L088, section évaluation).

### Grille API ou auto-hébergement ?

| Question | Réponse « API Mistral » | Réponse « poids ouverts chez vous » |
|---|---|---|
| Volume mensuel | < quelques centaines de millions de tokens | Très élevé et régulier (le GPU est amorti) |
| Confidentialité | Données pseudonymisées, contrat et inférence régionale suffisent | Données qui ne doivent **jamais** sortir du SI (santé, défense, secret industriel) |
| Compétences | Équipe applicative | Équipe capable d'exploiter vLLM / GPU (M29) |
| Modèle | Large 4, Codestral, OCR, Voxtral (API seule ou licence spécifique) | Small 4, Ministral 3 (Apache 2.0) |
| Délai | Aujourd'hui | Semaines (matériel, sécurité, MLOps) |

> 💡 **À retenir** — La bonne séquence pour une PME française : prototyper sur l'API avec `mistral-small-latest`, mesurer la qualité, et **seulement si** la confidentialité ou le volume l'imposent, auto-héberger Small 4 ou Ministral 3 sous Apache 2.0. Le code de l'application ne change presque pas, car les serveurs d'inférence ouverts (vLLM, Ollama) exposent une API compatible OpenAI (L088).

## 6. Où Mistral se distingue, où il ne faut pas le survendre

**Points forts différenciants** : souveraineté et contrat européen ; inférence régionale ; licences Apache 2.0 sur les modèles compacts ; OCR performant et bon marché pour les documents administratifs français ; Codestral/Devstral/Vibe pour le code ; Moderation gratuite ; excellent rapport qualité/prix sur les tâches courantes (classification, extraction, rédaction).

**Limites à dire honnêtement** : sur l'indice Artificial Analysis v5 d'octobre 2026, Mistral Large 4 a reculé dans le classement (article [ActuIA](https://www.actuia.com/en/news/mistral-large-4-drops-from-38-to-25-on-new-artificial-analysis-index/)) ; l'écosystème d'outils serveur (recherche web, exécution de code) est moins fourni que chez xAI, OpenAI ou Google ; le « 100 % européen » s'arrête si vous hébergez vous-même sur un cloud américain. Un bon consultant présente les deux colonnes.

> 🔗 **Documentation officielle** — [Model selection guide](https://docs.mistral.ai/inference/model-selection-guide), [Prompting](https://docs.mistral.ai/inference/prompting), [OCR 4.1](https://docs.mistral.ai/models/ocr-4-1).

## 🧪 Exercice pratique

**Consigne.** Un cabinet d'expertise comptable de Nantes reçoit chaque jour des factures fournisseurs en PDF. Écrivez `pipeline_factures.py` qui : (1) envoie un PDF à l'endpoint OCR 4.1 de Mistral et récupère le Markdown ; (2) passe ce Markdown à `mistral-small-latest` avec `response_format` JSON pour extraire `{ fournisseur, siret, date, total_ht, tva, total_ttc, lignes: [...] }` ; (3) valide le JSON avec Pydantic (le TTC doit égaler HT + TVA à 1 centime près) ; (4) affiche le coût total (OCR à 4 $/1 000 pages + tokens Small 4).

**Critères de réussite.**
1. La clé vient de `MISTRAL_API_KEY` ; aucune donnée de facture n'est écrite dans les logs.
2. Une facture de 2 pages coûte moins de 0,01 $ (vous le prouvez par le calcul affiché).
3. Une incohérence HT/TVA/TTC lève une exception explicite plutôt qu'un JSON silencieusement faux.
4. Le modèle est figé sur une version datée (pas `-latest`) dans la configuration de production.

**Pistes de corrigé.** L'endpoint OCR est documenté sur la [référence API](https://docs.mistral.ai/api) (section `ocr`) : consultez-y le format exact d'envoi du document (URL ou base64). Pour la validation, utilisez un `@model_validator` Pydantic qui compare `round(total_ht + tva, 2)` à `total_ttc`. Pour le coût : 2 pages × 0,004 $ + tokens (environ 1 500 in × 0,15 $/M + 300 out × 0,60 $/M ≈ 0,0004 $), soit ≈ 0,0084 $.

## ✅ Auto-évaluation express

1. Quelle licence couvre Mistral Small 4 et qu'autorise-t-elle ?
2. Quel endpoint et quels deux champs utilise-t-on pour une complétion de code « au milieu » ?
3. Un client dit « avec Mistral, mes données ne quittent pas l'Europe » : quelle condition rend cette phrase vraie ?

**Réponses.** 1) Apache 2.0 : usage, modification et redistribution libres, y compris commerciaux, sans redevance. 2) L'endpoint `fim` (`client.fim.complete`) avec `prompt` (avant le curseur) et `suffix` (après). 3) Utiliser l'inférence régionale européenne de l'API Mistral, ou auto-héberger les poids sur une infrastructure située en Europe ; héberger soi-même sur un cloud non européen annule l'argument.

## 📚 Pour aller plus loin
- [Mistral — Voxtral Mini Transcribe 3](https://docs.mistral.ai/models/voxtral-mini-transcribe-3-0) 🇬🇧 — transcription à 0,0035 $/min pour les comptes rendus de réunion.
- [Mistral — Codestral Embed](https://docs.mistral.ai/models/codestral-embed-25-05) 🇬🇧 — embeddings spécialisés code pour un RAG sur votre dépôt (M20).
- [Collection Hugging Face Mistral Small 4](https://huggingface.co/collections/mistralai/mistral-small-4) 🇬🇧 — télécharger les poids Apache 2.0.
- [Mistral — Priority tier](https://docs.mistral.ai/inference/priority-tier) 🇬🇧 — latence garantie pour les applications temps réel.
