---
id: L093
module: M20
level: N3
title: "Évaluer un RAG : Ragas, jeux de test, métriques"
minutes: 50
objectives:
  - "Construire un jeu de test RAG (question, contextes attendus, réponse de référence) à la main et par génération assistée, et le versionner"
  - "Calculer des métriques de recherche sans LLM (hit rate, recall@k, MRR) et des métriques de génération avec Ragas (faithfulness, answer relevancy, context precision/recall)"
  - "Mettre en place des tests automatisés avec DeepEval (style pytest) et interpréter les scores pour diagnostiquer ingestion, recherche ou génération"
  - "Organiser une boucle d'amélioration mesurée : changer une variable, relancer, comparer, décider"
skills: ["C3.3"]
sources:
  - { title: "Ragas — dépôt officiel", url: "https://github.com/vibrantlabsai/ragas", lang: "en" }
  - { title: "DeepEval — dépôt officiel", url: "https://github.com/confident-ai/deepeval", lang: "en" }
  - { title: "promptfoo — dépôt officiel", url: "https://github.com/promptfoo/promptfoo", lang: "en" }
  - { title: "Claude Cookbook — Building evals", url: "https://platform.claude.com/cookbook/misc-building-evals", lang: "en" }
  - { title: "Claude Cookbook — Generate test cases", url: "https://platform.claude.com/cookbook/misc-generate-test-cases", lang: "en" }
  - { title: "Claude Academy — Building with the Claude API (module Prompt evaluation)", url: "https://academy.claude.com/courses/building-with-the-claude-api", lang: "en" }
  - { title: "Langfuse — observabilité et évaluation", url: "https://langfuse.com", lang: "en" }
  - { title: "MLflow — GenAI evaluate", url: "https://mlflow.org", lang: "en" }
  - { title: "Claude Platform — Structured outputs", url: "https://platform.claude.com/docs/en/build-with-claude/structured-outputs", lang: "en" }
---

# Évaluer un RAG : Ragas, jeux de test, métriques

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 20

## 🎯 Ce que vous saurez faire
- Remplacer « ça a l'air de marcher » par « 92 % de rappel du contexte à k = 5, fidélité 0,94, sur 60 questions versionnées ».
- Savoir en dix minutes, quand une réponse est mauvaise, si la faute vient de l'ingestion, de la recherche ou du modèle.
- Faire échouer la CI quand une mise à jour de dépendance dégrade votre RAG.

## 1. Pourquoi évaluer, et pourquoi c'est difficile

Un RAG est un système à trois étages (ingestion → recherche → génération) et chaque étage peut dégrader la réponse. Pire : les erreurs sont *silencieuses*. Le modèle écrit une phrase fluide, polie, avec une citation — fausse. Sans mesure, vous ne verrez le problème que lorsque la DRH de Bréval Matériaux viendra vous voir avec un salarié à qui l'assistant a promis 35 jours de congés.

Difficulté supplémentaire : il n'y a pas « une » bonne réponse. « Le délai est de 30 jours » et « Vous avez un mois pour transmettre vos notes de frais » sont toutes deux justes. On ne peut donc pas comparer des chaînes ; il faut soit des métriques de **recherche** (là, on sait quel morceau est attendu), soit des **juges** (un LLM qui note selon des critères précis — « LLM-as-a-judge »).

Le module « Prompt evaluation » du cours [Building with the Claude API](https://academy.claude.com/courses/building-with-the-claude-api) et le [cookbook « Building evals »](https://platform.claude.com/cookbook/misc-building-evals) décrivent la même démarche : un jeu de test, un critère de notation (par code ou par modèle), une boucle.

## 2. Le jeu de test : votre actif le plus précieux

### 2.1 Format

Un fichier JSONL, versionné avec le code, une ligne par cas :

```json
{"id": "rh-012", "question": "Combien de temps ai-je pour transmettre une note de frais ?",
 "contextes_attendus": ["notes-de-frais-v3.pdf#2"],
 "reponse_reference": "30 jours après la dépense, avec le justificatif original.",
 "type": "factuel", "service": "RH", "auteur": "DRH", "ajoute_le": "2026-10-14"}
```

`contextes_attendus` identifie les morceaux (ou pages) qui *doivent* remonter : c'est ce qui permet d'évaluer la recherche sans LLM. `reponse_reference` est rédigée par un humain qui connaît la procédure. Visez **40 à 80 cas** pour un corpus de PME, répartis ainsi :

| Type | Part | Exemple | Ce qu'il teste |
|---|---|---|---|
| Factuel simple | 40 % | « Quel est le plafond repas ? » | la chaîne de base |
| Multi-morceaux | 15 % | « Quelles sont les étapes d'un retour fournisseur et qui signe ? » | rappel à k > 1 |
| Référence exacte | 15 % | « Que dit la PR-2024-17 ? » | la recherche lexicale (L092) |
| Formulation familière | 15 % | « c'est quoi le truc pour les frais ? » | multi-query, robustesse |
| **Hors périmètre** | 15 % | « Quel est le menu de la cantine ? » | le refus : la bonne réponse est « je n'ai pas cette information » |

> 💡 **À retenir** — Les cas « hors périmètre » sont les plus importants et les plus oubliés. Un RAG qui répond à tout est un RAG qui hallucine. Leur `reponse_reference` est un refus, et un modèle qui « trouve » quand même une réponse échoue le test.

### 2.2 Génération assistée du jeu de test

Rédiger 60 cas à la main prend une demi-journée à la DRH. Accélérez : pour chaque morceau (ou page) du corpus, demandez à Claude de produire une question et sa réponse *strictement tirées du morceau*, avec sorties structurées pour obtenir du JSON validé ([page Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs)). Puis **faites relire par un humain** : on supprime les questions triviales ou ambiguës, on garde le reste. La recette [« Generate test cases »](https://platform.claude.com/cookbook/misc-generate-test-cases) du cookbook suit ce schéma.

```python
# generer_tests.py — questions/réponses de référence à partir des morceaux (à relire par un humain !)
import os, json
from pydantic import BaseModel
from anthropic import Anthropic
import psycopg

client = Anthropic()

class CasDeTest(BaseModel):
    question: str
    reponse_reference: str
    type: str          # 'factuel' | 'multi' | 'reference_exacte' | 'familier'

def generer(contenu: str, source: str, page: int) -> dict | None:
    r = client.messages.parse(
        model="claude-sonnet-5-5", max_tokens=400,
        system="Vous préparez un jeu de test pour un assistant documentaire d'une PME. À partir de l'extrait, rédigez UNE question "
               "qu'un salarié poserait réellement et sa réponse, qui doit être entièrement contenue dans l'extrait. "
               "Si l'extrait ne permet pas de question utile (sommaire, pied de page), renvoyez question vide.",
        messages=[{"role": "user", "content": f"Extrait ({source}, p.{page}) :\n{contenu}"}],
        output_format=CasDeTest,
    )
    cas = r.parsed_output
    if not cas.question.strip():
        return None
    return {"question": cas.question, "reponse_reference": cas.reponse_reference, "type": cas.type,
            "contextes_attendus": [f"{source}#{page}"], "auteur": "généré — À RELIRE"}

if __name__ == "__main__":
    with psycopg.connect(os.environ["PG_DSN"]) as conn, open("tests_a_relire.jsonl", "w", encoding="utf-8") as f:
        rows = conn.execute("SELECT c.contenu, d.source, c.page FROM chunks c JOIN documents d ON d.id = c.document_id "
                            "ORDER BY random() LIMIT 80").fetchall()
        for i, (contenu, source, page) in enumerate(rows):
            cas = generer(contenu, source, page)
            if cas:
                f.write(json.dumps({"id": f"gen-{i:03d}", **cas}, ensure_ascii=False) + "\n")
```

## 3. Évaluer la recherche sans LLM : rapide, gratuit, déterministe

Avant toute métrique sophistiquée, trois chiffres que vous pouvez calculer en une seconde sur 60 questions :

- **Hit rate@k** : part des questions dont *au moins un* morceau attendu figure dans le top k.
- **Recall@k** (rappel) : part des morceaux attendus retrouvés dans le top k, en moyenne.
- **MRR** (Mean Reciprocal Rank) : moyenne de 1 / rang du premier morceau attendu (1 si en tête, 0,5 si deuxième…).

```python
# eval_recherche.py — métriques de récupération sur le jeu de test, pour n'importe quelle fonction de recherche
import json, statistics
from collections.abc import Callable

def charger(chemin: str) -> list[dict]:
    with open(chemin, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]

def cle(morceau: dict) -> str:
    return f"{morceau['source']}#{morceau.get('page')}"

def evaluer_recherche(rechercher: Callable[[str], list[dict]], cas: list[dict], k: int = 5) -> dict:
    hits, recalls, rr = [], [], []
    for c in cas:
        if not c["contextes_attendus"]:
            continue                                   # cas hors périmètre : pas de contexte attendu
        top = [cle(m) for m in rechercher(c["question"])[:k]]
        attendus = set(c["contextes_attendus"])
        trouves = attendus & set(top)
        hits.append(1.0 if trouves else 0.0)
        recalls.append(len(trouves) / len(attendus))
        rangs = [i + 1 for i, t in enumerate(top) if t in attendus]
        rr.append(1.0 / rangs[0] if rangs else 0.0)
    return {"k": k, "n": len(hits), "hit_rate": round(statistics.mean(hits), 3),
            "recall": round(statistics.mean(recalls), 3), "mrr": round(statistics.mean(rr), 3)}

if __name__ == "__main__":
    from recherche_pgvector import rechercher as vectoriel          # L089
    from recherche_hybride import rechercher_hybride                 # L092
    from reranking import rechercher_rerank                          # L092
    cas = charger("tests.jsonl")
    for nom, fn in [("vectoriel", vectoriel), ("hybride", rechercher_hybride), ("hybride+rerank", rechercher_rerank)]:
        print(nom, evaluer_recherche(fn, cas, k=5))
```

Cette seule boucle répond déjà à la question « le reranking vaut-il ses 200 ms ? ». Lancez-la à chaque changement de découpage, de modèle d'embedding ou de paramètre HNSW : c'est votre test de non-régression de la recherche.

## 4. Évaluer la génération avec Ragas

[Ragas](https://github.com/vibrantlabsai/ragas) (Apache 2.0, v0.4.x en 2026) est la bibliothèque de référence pour les métriques RAG. Quatre métriques à connaître, toutes notées de 0 à 1 par un LLM juge :

| Métrique | Question posée | Ce qu'un score bas révèle |
|---|---|---|
| **Faithfulness** (fidélité) | Chaque affirmation de la réponse est-elle soutenue par les contextes récupérés ? | hallucination : le modèle a ajouté ce qu'il « savait » |
| **Answer relevancy** | La réponse répond-elle bien à la question posée (ni hors sujet, ni incomplète) ? | prompt trop vague, contexte bruité, modèle qui digresse |
| **Context precision** | Les contextes pertinents sont-ils classés en tête parmi ceux récupérés ? | recherche qui ramène du bruit avant l'essentiel → reranking |
| **Context recall** | Les contextes récupérés couvrent-ils tout ce qu'il faut pour la réponse de référence ? | découpage trop fin, k trop petit, mauvais modèle d'embedding |

Lecture croisée, le vrai outil de diagnostic :

- **context recall bas** → problème d'ingestion ou de recherche (L090/L092) : inutile de toucher au prompt.
- **context recall haut, faithfulness bas** → problème de génération : le modèle ignore le contexte ; durcissez le prompt (« répondez uniquement à partir des extraits »), baissez la température, changez de modèle.
- **tout haut, answer relevancy bas** → le modèle a la bonne information mais répond à côté ; revoyez le format de réponse demandé.

```python
# eval_ragas.py — pip install ragas langchain-anthropic langchain-huggingface
# Vérifiez la syntaxe exacte pour votre version de Ragas (0.4.x) dans la documentation du dépôt.
import os, json
from ragas import evaluate, EvaluationDataset
from ragas.metrics import Faithfulness, AnswerRelevancy, LLMContextPrecisionWithReference, LLMContextRecall
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from langchain_anthropic import ChatAnthropic
from langchain_huggingface import HuggingFaceEmbeddings
from eval_recherche import charger
from rag_app import repondre          # L094 : repondre(question) -> {"reponse": str, "contextes": [str, ...]}

juge = LangchainLLMWrapper(ChatAnthropic(model="claude-sonnet-5-5"))  # le juge : un modèle solide (pas de temperature : 400 sur Claude ≥ 4.7)
emb = LangchainEmbeddingsWrapper(HuggingFaceEmbeddings(model_name=os.environ.get("LOCAL_EMBEDDING_MODEL", "BAAI/bge-m3")))

lignes = []
for c in charger("tests.jsonl"):
    sortie = repondre(c["question"])
    lignes.append({"user_input": c["question"], "retrieved_contexts": sortie["contextes"],
                   "response": sortie["reponse"], "reference": c["reponse_reference"]})

dataset = EvaluationDataset.from_list(lignes)
resultat = evaluate(dataset, metrics=[Faithfulness(), AnswerRelevancy(), LLMContextPrecisionWithReference(), LLMContextRecall()],
                    llm=juge, embeddings=emb)
print(resultat)                                   # moyennes par métrique
df = resultat.to_pandas()
df.to_csv("eval_ragas.csv", index=False)          # détail par question : c'est là que l'on apprend
print(df.sort_values("faithfulness").head(5)[["user_input", "faithfulness", "context_recall"]])
```

Trois précautions. Le **juge** doit être au moins aussi bon que le modèle évalué (Sonnet 5.5 pour juger Haiku 5.5, par exemple), sans paramètre `temperature` (refusé, erreur 400, par les modèles Claude ≥ 4.7) : la stabilité vient d'une rubrique précise et d'un format de sortie imposé. Un juge LLM a lui-même une **variance** : relancez deux fois et regardez l'écart avant de conclure qu'un changement de 0,02 est un progrès. Et le **coût** : 60 questions × 4 métriques × quelques appels = quelques centaines d'appels au juge ; avec Sonnet 5.5 (2 $ / M tokens en entrée, nov. 2026) cela reste de l'ordre d'un euro par campagne, mais mettez-le en Batch si vous évaluez chaque nuit.

> ⚠️ **Piège fréquent** — Évaluer uniquement la moyenne. Une fidélité moyenne de 0,93 peut cacher trois questions à 0,2 — précisément les cas « hors périmètre » où le modèle invente. Triez toujours le CSV par score croissant et lisez les cinq pires : c'est là que se trouve le prochain bug.

## 5. DeepEval : des tests unitaires pour votre RAG

[DeepEval](https://github.com/confident-ai/deepeval) (Apache 2.0) reprend les mêmes métriques (Faithfulness, Answer Relevancy, Contextual Precision/Recall, Hallucination, G-Eval pour vos propres critères) dans un format **pytest** : chaque cas est un test, avec un seuil, qui passe ou échoue. Idéal pour la CI.

```python
# test_rag.py — pytest + DeepEval : la CI échoue si la fidélité passe sous 0,8 sur un cas
import pytest
from deepeval import assert_test
from deepeval.test_case import LLMTestCase
from deepeval.metrics import FaithfulnessMetric, AnswerRelevancyMetric, ContextualRecallMetric
from eval_recherche import charger
from rag_app import repondre

CAS = charger("tests.jsonl")

@pytest.mark.parametrize("cas", CAS, ids=[c["id"] for c in CAS])
def test_rag(cas):
    sortie = repondre(cas["question"])
    test_case = LLMTestCase(input=cas["question"], actual_output=sortie["reponse"],
                            expected_output=cas["reponse_reference"], retrieval_context=sortie["contextes"])
    metriques = [FaithfulnessMetric(threshold=0.8), AnswerRelevancyMetric(threshold=0.7)]
    if cas["contextes_attendus"]:                                   # pas de rappel à mesurer sur un cas hors périmètre
        metriques.append(ContextualRecallMetric(threshold=0.7))
    assert_test(test_case, metriques)
```

Lancez `deepeval test run test_rag.py` (ou `pytest`). DeepEval utilise par défaut un modèle OpenAI comme juge ; configurez-le pour Claude ou un modèle local selon la documentation du dépôt. Troisième outil du paysage, [promptfoo](https://github.com/promptfoo/promptfoo) (MIT, racheté par OpenAI en mars 2026 d'après notre recherche) décrit les mêmes tests en YAML et excelle pour comparer plusieurs modèles ou prompts côte à côte ; vous l'utiliserez en M22.

## 6. La boucle d'amélioration

```
   jeu de test versionné (tests.jsonl)
          │
          ▼
   mesurer (recherche sans LLM + Ragas)  ──▶ lire les 5 pires cas
          │                                        │
          ▼                                        ▼
   changer UNE variable  ◀────────── hypothèse (découpage ? k ? prompt ? modèle ?)
          │
          ▼
   re-mesurer ──▶ garder si gain > bruit du juge, sinon revenir en arrière
          │
          ▼
   consigner (date, variable, avant/après) dans un journal d'expériences
```

Règles du jeu : **une variable à la fois** ; **le jeu de test ne change pas** pendant une série d'expériences (sinon vous comparez des pommes et des poires) ; quand un utilisateur signale une mauvaise réponse en production, elle **devient un cas de test** ; et tous les trimestres, on ajoute les nouvelles procédures et leurs questions. En production, un outil d'observabilité comme [Langfuse](https://langfuse.com) (cœur open source) ou [MLflow](https://mlflow.org) (`mlflow.genai.evaluate()`) collecte les vraies questions, les scores et les coûts, et vous permet de rejouer les évaluations sur des traces réelles — vous l'approfondirez en M22.

> 💡 **À retenir** — Un jeu de test de 60 questions relues par la DRH vaut plus que n'importe quel framework. C'est lui qui transforme vos choix techniques (taille de morceau, hybride, reranking, modèle) en décisions chiffrées, et c'est lui que vous présenterez au client comme preuve de qualité.

> 🔗 **Documentation officielle** — [Ragas](https://github.com/vibrantlabsai/ragas) 🇬🇧 · [DeepEval](https://github.com/confident-ai/deepeval) 🇬🇧 · [Claude Cookbook — Building evals](https://platform.claude.com/cookbook/misc-building-evals) 🇬🇧

## 🧪 Exercice pratique

**Consigne.** Constituez `tests.jsonl` pour Bréval Matériaux : 20 cas rédigés à la main (dont 3 hors périmètre et 3 à référence exacte) + 20 cas générés puis relus. Mesurez la recherche (hit rate, recall@5, MRR) pour les configurations A à D de L092, puis Ragas sur la meilleure configuration. Menez ensuite **une** expérience : taille des morceaux 300 → 500 tokens. Re-mesurez.

**Critères de réussite.**
1. `tests.jsonl` versionné, 40 cas, champs complets, aucun cas généré sans mention de relecture.
2. Un tableau recherche (4 configurations × 3 métriques) et un tableau Ragas (4 métriques, moyenne + 5 pires cas).
3. Pour les 3 cas hors périmètre, la réponse est un refus explicite ; sinon vous corrigez le prompt et re-mesurez.
4. Une conclusion chiffrée sur l'expérience 300 → 500 tokens, avec la décision (garder / revenir) et le journal d'expérience correspondant.

**Pistes de corrigé.** Sur des procédures courtes, passer à 500 tokens fait souvent *baisser* la context precision (plus de texte hors sujet par morceau) sans améliorer le rappel : la décision rationnelle est de revenir à 300. Si vos cas hors périmètre obtiennent une fidélité élevée mais une réponse inventée, c'est que les contextes récupérés contiennent des bribes utilisées abusivement : ajoutez un seuil de score minimal (L089) avant même d'appeler le modèle.

## ✅ Auto-évaluation express

1. Context recall = 0,55, faithfulness = 0,95. Où est le problème, et que ne faut-il surtout pas faire ?
2. Pourquoi mesurer hit rate et MRR *avant* d'utiliser Ragas ?
3. Que devient une mauvaise réponse signalée par un utilisateur ?

**Réponses.** 1. La recherche ne ramène pas les bons morceaux (ingestion, découpage, k, modèle d'embedding) ; le modèle, lui, est fidèle à ce qu'on lui donne. Il ne faut pas retoucher le prompt de génération : ce n'est pas lui le coupable. 2. Elles sont gratuites, déterministes, instantanées, et isolent l'étage de recherche ; Ragas coûte des appels LLM et mélange les étages. 3. Un cas de test de plus dans `tests.jsonl`, avec la réponse de référence validée par un humain, pour qu'elle ne se reproduise jamais sans déclencher une alerte.

## 📚 Pour aller plus loin
- [Ragas](https://github.com/vibrantlabsai/ragas) 🇬🇧 — métriques, génération de jeux de test synthétiques, intégrations.
- [DeepEval](https://github.com/confident-ai/deepeval) 🇬🇧 — tests pytest, G-Eval, métriques RAG et agents.
- [Claude Cookbook — Building evals](https://platform.claude.com/cookbook/misc-building-evals) 🇬🇧 — notation par code et par modèle, pas à pas.
- [promptfoo](https://github.com/promptfoo/promptfoo) 🇬🇧 — tests de prompts en YAML, comparaison de modèles, red-teaming.
- [Langfuse](https://langfuse.com) 🇬🇧 — tracer et évaluer en production (vu en M22).
