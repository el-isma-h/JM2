---
id: L091
module: M20
level: N3
title: "LangChain et LlamaIndex"
minutes: 55
objectives:
  - "Construire le même pipeline RAG (chargement, découpage, embeddings, base vectorielle, génération) avec LangChain 1.x puis avec LlamaIndex"
  - "Expliquer l'architecture des deux frameworks (Documents, splitters, VectorStore, retriever, LCEL ; Nodes, Index, QueryEngine) et leurs philosophies"
  - "Décider, pour un projet donné, entre LangChain, LlamaIndex, Haystack et du code sans framework, à partir de critères explicites"
  - "Identifier les pièges de versions et d'abstractions (dépendances, API mouvantes, coûts cachés) et s'en protéger"
skills: ["C3.3"]
sources:
  - { title: "LangChain — changelog (langchain 1.4.x, langchain-core 1.7, LangGraph 1.2)", url: "https://docs.langchain.com/oss/python/releases/changelog.md", lang: "en" }
  - { title: "LlamaIndex — documentation", url: "https://docs.llamaindex.ai", lang: "en" }
  - { title: "Haystack (deepset) — site officiel", url: "https://haystack.deepset.ai", lang: "en" }
  - { title: "LangSmith — observabilité LangChain", url: "https://smith.langchain.com", lang: "en" }
  - { title: "Hugging Face — Agents Course (unité 2.2 LlamaIndex, 2.3 LangGraph, unité 3 RAG agentique)", url: "https://huggingface.co/learn/agents-course", lang: "en" }
  - { title: "Claude Platform — Citations", url: "https://platform.claude.com/docs/en/build-with-claude/citations", lang: "en" }
  - { title: "Qdrant — documentation", url: "https://qdrant.tech/documentation/", lang: "en" }
  - { title: "pgvector — dépôt officiel", url: "https://github.com/pgvector/pgvector", lang: "en" }
---

# LangChain et LlamaIndex

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 20

## 🎯 Ce que vous saurez faire
- Réécrire en 40 lignes, avec LangChain puis avec LlamaIndex, le pipeline que vous avez codé à la main en L089-L090 — et comprendre ce que chaque ligne cache.
- Répondre sans hésiter à la question du chef de projet : « on prend un framework ou pas ? ».
- Brancher Claude, Mistral ou un modèle local sur l'un ou l'autre sans réécrire le pipeline.

## 1. Pourquoi des frameworks, et pourquoi s'en méfier

En L089-L090, vous avez écrit un parseur, un découpeur, une fonction `embed()` et une requête SQL. Environ 250 lignes, que vous comprenez entièrement. Un framework RAG vous offre les mêmes briques, déjà écrites, **interchangeables** : 80 loaders de documents, 15 splitters, 50 bases vectorielles, 30 fournisseurs de modèles derrière une interface commune. Le prix : des abstractions à apprendre, des dépendances lourdes et des API qui bougent.

Deux acteurs dominent (licence MIT, Python et TypeScript) :

- **LangChain** (LangChain Inc.) — boîte à outils généraliste : chaînes, outils, agents ; en nov. 2026, `langchain` 1.4.6, `langchain-core` 1.7.0 et **LangGraph 1.2** pour les agents avec état (source : [changelog officiel](https://docs.langchain.com/oss/python/releases/changelog.md)). La version 1.0 (2025) a recentré le paquet `langchain` sur un noyau stable et poussé les intégrations dans des paquets séparés (`langchain-openai`, `langchain-anthropic`, `langchain-postgres`…).
- **LlamaIndex** — né pour le RAG (« LlamaIndex = data framework for LLM applications ») : chargement, indexation, requête documentaire, avec une attention particulière aux documents structurés. Documentation : [docs.llamaindex.ai](https://docs.llamaindex.ai).

Et un troisième, plus discret : **Haystack** (deepset, Apache 2.0), orienté pipelines de production explicites ([haystack.deepset.ai](https://haystack.deepset.ai)).

> 💡 **À retenir** — Un framework ne rend pas un RAG meilleur ; il rend le *premier* RAG plus rapide à écrire et le *changement de brique* (base, modèle) moins coûteux. La qualité vient toujours de l'ingestion (L090), de la recherche (L092) et de l'évaluation (L093).

## 2. LangChain : le pipeline de Bréval Matériaux

### 2.1 Les concepts en une image

```
Document(page_content, metadata)
   │  DocumentLoader (PyPDFLoader, Docx2txtLoader, BSHTMLLoader…)
   ▼
TextSplitter (RecursiveCharacterTextSplitter) ──▶ [Document, Document, …]
   ▼
Embeddings (OpenAIEmbeddings, MistralAIEmbeddings, HuggingFaceEmbeddings)
   ▼
VectorStore (PGVector, Chroma, QdrantVectorStore) ──▶ .as_retriever(k=5)
   ▼
Runnable (LCEL) : prompt | modèle | parseur  ──▶ réponse + sources
```

Tout est un **Runnable** : on compose avec l'opérateur `|` (LangChain Expression Language, LCEL), ce qui donne gratuitement le streaming, le batch et le tracing.

### 2.2 Le code

```bash
pip install -U langchain langchain-core langchain-community langchain-text-splitters \
               langchain-anthropic langchain-huggingface langchain-postgres pypdf
```

```python
# rag_langchain.py — ingestion + question/réponse avec LangChain 1.x, pgvector et Claude
import os
from pathlib import Path
from langchain_community.document_loaders import PyPDFLoader, BSHTMLLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_postgres import PGVector
from langchain_anthropic import ChatAnthropic
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableLambda

# 1. Modèles : embeddings locaux (gratuit, données en interne) + Claude pour la génération
embeddings = HuggingFaceEmbeddings(model_name=os.environ.get("LOCAL_EMBEDDING_MODEL", "BAAI/bge-m3"))
llm = ChatAnthropic(model="claude-sonnet-5-5", max_tokens=800)       # ANTHROPIC_API_KEY

# 2. Base vectorielle : la table est créée par LangChain (schéma propre à langchain-postgres)
store = PGVector(embeddings=embeddings, collection_name="breval_langchain",
                 connection=os.environ["PG_DSN"], use_jsonb=True)

def ingerer(racine: Path) -> int:
    docs = []
    for chemin in racine.rglob("*"):
        if chemin.suffix.lower() == ".pdf":
            docs += PyPDFLoader(str(chemin)).load()                   # un Document par page, metadata['page']
        elif chemin.suffix.lower() in (".html", ".htm"):
            docs += BSHTMLLoader(str(chemin)).load()
    for d in docs:
        d.metadata["service"] = Path(d.metadata["source"]).parent.name  # dossier = service
        d.metadata["source"] = Path(d.metadata["source"]).name
    splitter = RecursiveCharacterTextSplitter(chunk_size=1200, chunk_overlap=150,   # en caractères !
                                              separators=["\n\n", "\n", ". ", " "])
    morceaux = splitter.split_documents(docs)
    ids = [f"{m.metadata['source']}#{m.metadata.get('page', 0)}#{i}" for i, m in enumerate(morceaux)]
    store.add_documents(morceaux, ids=ids)                             # ids stables = ré-ingestion sans doublon
    return len(morceaux)

# 3. Chaîne de question/réponse
retriever = store.as_retriever(search_kwargs={"k": 5})

prompt = ChatPromptTemplate.from_messages([
    ("system", "Vous êtes l'assistant documentaire de Bréval Matériaux. Répondez uniquement à partir des extraits fournis. "
               "Si l'information n'y figure pas, dites-le. Citez la source entre crochets, ex. [notes-de-frais-v3.pdf p.2]."),
    ("human", "Extraits :\n{contexte}\n\nQuestion : {question}"),
])

def formater(docs) -> str:
    return "\n\n".join(f"[{d.metadata['source']} p.{d.metadata.get('page', '?')}]\n{d.page_content}" for d in docs)

chaine = (
    {"contexte": retriever | RunnableLambda(formater), "question": RunnablePassthrough()}
    | prompt | llm | StrOutputParser()
)

if __name__ == "__main__":
    print("morceaux indexés :", ingerer(Path(os.environ.get("DOCS_DIR", "./procedures"))))
    for token in chaine.stream("Quel est le délai pour transmettre une note de frais ?"):
        print(token, end="", flush=True)
```

Points à remarquer :

- `RecursiveCharacterTextSplitter` compte en **caractères** par défaut ; `RecursiveCharacterTextSplitter.from_tiktoken_encoder(chunk_size=300, chunk_overlap=40)` compte en tokens — préférez-le pour rester cohérent avec L090.
- `PGVector` crée ses **propres tables** (`langchain_pg_collection`, `langchain_pg_embedding`) : vous ne contrôlez pas le schéma de L089. C'est le compromis de tout framework.
- `chaine.stream()` diffuse la réponse token par token sans une ligne de plus : c'est l'intérêt de LCEL.
- Pour un **agent** (le modèle décide s'il cherche, reformule, cherche encore), LangChain 1.x propose `create_agent` et LangGraph pour les graphes avec état ; vous le verrez en M21.

### 2.3 TypeScript : la même chaîne en LangChain.js

```typescript
// rag.ts — npm i langchain @langchain/core @langchain/anthropic @langchain/openai @langchain/community pg
import { ChatAnthropic } from "@langchain/anthropic";
import { OpenAIEmbeddings } from "@langchain/openai";
import { PGVectorStore } from "@langchain/community/vectorstores/pgvector";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { StringOutputParser } from "@langchain/core/output_parsers";

const store = await PGVectorStore.initialize(
  new OpenAIEmbeddings({ model: process.env.OPENAI_EMBEDDING_MODEL ?? "text-embedding-3-small" }), // ID à vérifier
  { postgresConnectionOptions: { connectionString: process.env.PG_DSN }, tableName: "breval_js" },
);
const retriever = store.asRetriever({ k: 5 });
const prompt = ChatPromptTemplate.fromMessages([
  ["system", "Répondez uniquement à partir des extraits. Citez [source p.page]."],
  ["human", "Extraits :\n{contexte}\n\nQuestion : {question}"],
]);
const llm = new ChatAnthropic({ model: "claude-sonnet-5-5", maxTokens: 800 });

export async function repondre(question: string): Promise<string> {
  const docs = await retriever.invoke(question);
  const contexte = docs.map((d) => `[${d.metadata.source} p.${d.metadata.page ?? "?"}]\n${d.pageContent}`).join("\n\n");
  return prompt.pipe(llm).pipe(new StringOutputParser()).invoke({ contexte, question });
}
```

## 3. LlamaIndex : la même chose, pensée « données »

### 3.1 Les concepts

LlamaIndex parle de **Documents** (fichiers), **Nodes** (morceaux avec métadonnées et relations précédent/suivant), **Index** (`VectorStoreIndex`, mais aussi index par mots-clés, par résumé, arborescents) et **QueryEngine** (recherche + synthèse). Le réglage global passe par l'objet `Settings`.

```bash
pip install -U llama-index llama-index-llms-anthropic llama-index-embeddings-huggingface llama-index-vector-stores-qdrant qdrant-client
```

```python
# rag_llamaindex.py — même pipeline avec LlamaIndex, Qdrant et Claude
import os
from llama_index.core import Settings, SimpleDirectoryReader, VectorStoreIndex, StorageContext
from llama_index.core.node_parser import SentenceSplitter
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.llms.anthropic import Anthropic
from llama_index.vector_stores.qdrant import QdrantVectorStore
from qdrant_client import QdrantClient

Settings.embed_model = HuggingFaceEmbedding(model_name=os.environ.get("LOCAL_EMBEDDING_MODEL", "BAAI/bge-m3"))
Settings.llm = Anthropic(model="claude-sonnet-5-5", max_tokens=800)      # ANTHROPIC_API_KEY
Settings.node_parser = SentenceSplitter(chunk_size=300, chunk_overlap=40)  # en tokens

client = QdrantClient(url=os.environ.get("QDRANT_URL", "http://localhost:6333"))
vector_store = QdrantVectorStore(client=client, collection_name="breval_llamaindex")
storage = StorageContext.from_defaults(vector_store=vector_store)

def ingerer(racine: str) -> VectorStoreIndex:
    # SimpleDirectoryReader choisit le lecteur selon l'extension (PDF, DOCX, HTML, MD…) et remplit file_name / page_label
    docs = SimpleDirectoryReader(racine, recursive=True, required_exts=[".pdf", ".docx", ".html"],
                                 file_metadata=lambda p: {"service": os.path.basename(os.path.dirname(p))}).load_data()
    return VectorStoreIndex.from_documents(docs, storage_context=storage, show_progress=True)

def ouvrir() -> VectorStoreIndex:
    return VectorStoreIndex.from_vector_store(vector_store)                # réutilise l'index existant

if __name__ == "__main__":
    index = ingerer(os.environ.get("DOCS_DIR", "./procedures")) if os.environ.get("INGEST") else ouvrir()
    moteur = index.as_query_engine(similarity_top_k=5, response_mode="compact")
    reponse = moteur.query("Quel est le délai pour transmettre une note de frais ?")
    print(reponse.response)
    for n in reponse.source_nodes:                                          # traçabilité intégrée
        print(f"  ↳ score {n.score:.3f} — {n.metadata.get('file_name')} p.{n.metadata.get('page_label')}")
```

Ce que LlamaIndex vous donne « en plus » sans effort : les **métadonnées de page** (`page_label`), les **relations entre nœuds** (utile pour élargir le contexte au morceau voisin), les **modes de synthèse** (`compact`, `refine`, `tree_summarize` pour les corpus longs) et un `as_retriever()` si vous voulez garder la main sur le prompt final. Il sait aussi faire des agents (unité 2.2 du [cours Agents de Hugging Face](https://huggingface.co/learn/agents-course)), mais c'est LangGraph qui y est le plus répandu.

> ⚠️ **Piège fréquent** — Mélanger les versions. Chaque intégration (`llama-index-vector-stores-qdrant`, `langchain-postgres`…) est un paquet avec sa propre cadence. Épinglez les versions dans `requirements.txt` ou `pyproject.toml`, relisez le changelog avant toute montée de version, et gardez un test de bout en bout (L093) qui casse si une API a changé.

## 4. Quand utiliser quoi ?

| Critère | Sans framework (L089-L090) | LangChain | LlamaIndex | Haystack |
|---|---|---|---|---|
| Compréhension totale du code | ✅ | partielle | partielle | bonne (pipelines explicites) |
| Vitesse du premier prototype | moyenne | ✅ très rapide | ✅ très rapide | rapide |
| Documents complexes (PDF structurés, tableaux, hiérarchies) | selon votre parseur | correct | ✅ point fort | correct |
| Agents, outils, graphes avec état | à coder | ✅ LangGraph | possible | possible |
| Changer de base vectorielle / de modèle | réécrire 30 lignes | ✅ une ligne | ✅ une ligne | ✅ une ligne |
| Contrôle du schéma SQL | ✅ total | non (tables du framework) | partiel | partiel |
| Observabilité | à brancher (OpenTelemetry, Langfuse) | LangSmith natif, Langfuse | callbacks, Langfuse | tracing intégré |
| Dépendances | minimales | nombreuses | nombreuses | moyennes |

Grille de décision pratique :

1. **Projet d'apprentissage ou outil interne simple sur < 1 000 pages** : sans framework. Vous saurez exactement ce qui se passe quand ça ne marche pas.
2. **Prototype à montrer en deux jours, puis itérer** : LangChain ou LlamaIndex. Choisissez LlamaIndex si le cœur du problème est *documentaire* (PDF variés, hiérarchies, tableaux) ; LangChain si vous savez que le RAG n'est qu'une étape d'un agent plus large.
3. **Production avec SLA, plusieurs équipes** : Haystack ou LangChain + LangGraph, avec observabilité (LangSmith, Langfuse) et suite d'évaluation (L093). Ou sans framework si l'équipe est senior et le périmètre stable.

Vous constaterez que les trois pipelines de cette leçon (L090 à la main, LangChain, LlamaIndex) produisent des réponses **comparables** sur le corpus de Bréval : la différence ne se joue pas sur le framework. Elle se jouera en L092 (recherche hybride, reranking) et L093 (mesure).

> 💡 **À retenir** — Quelle que soit la voie, gardez **trois frontières nettes** dans votre code : ingestion, recherche, génération. Un framework qui vous force à les mélanger (un `QueryEngine` qui fait tout) est confortable le premier jour et opaque le trentième. Avec des frontières nettes, vous pouvez remplacer la recherche par la version hybride de L092 sans toucher au reste.

> 🔗 **Documentation officielle** — [LangChain changelog](https://docs.langchain.com/oss/python/releases/changelog.md) 🇬🇧 · [LlamaIndex](https://docs.llamaindex.ai) 🇬🇧 · [Haystack](https://haystack.deepset.ai) 🇬🇧 · [Citations Claude](https://platform.claude.com/docs/en/build-with-claude/citations) 🇬🇧

## 5. Un détail qui change tout : les citations fiables

Dans les deux pipelines, la citation `[source p.2]` est produite par le modèle *à partir d'une instruction*. Il peut se tromper de page ou inventer une source. Pour une citation garantie par l'API, passez les morceaux à Claude sous forme de blocs `document` avec `"citations": {"enabled": True}` : la réponse revient avec des `cited_text` exacts, non facturés en sortie ([page Citations](https://platform.claude.com/docs/en/build-with-claude/citations) ; détail en L072 et L094). Avec LangChain, cela se fait en construisant le message `content` vous-même ; avec LlamaIndex, via `as_retriever()` puis un appel direct au SDK Anthropic. C'est précisément pour cela qu'on garde la frontière « recherche / génération » nette.

## 🧪 Exercice pratique

**Consigne.** Reprenez le corpus de L090 et faites tourner les trois pipelines (maison, LangChain, LlamaIndex) sur les mêmes **8 questions** (4 RH, 2 sécurité, 2 logistique). Pour chaque pipeline et chaque question, notez : la source citée en premier, le temps de réponse, et si la réponse contient la bonne information (oui / partiel / non).

**Critères de réussite.**
1. Un tableau 8 × 3 rempli, avec un total de réussite par pipeline.
2. Pour au moins une question, les trois pipelines ne renvoient pas la même première source : expliquez pourquoi (découpage différent ? comptage en caractères vs tokens ? préfixe de contexte absent ?).
3. Vous avez changé le modèle de génération (Claude → Mistral Small 4 ou un modèle Ollama) dans LangChain **et** LlamaIndex en modifiant une seule ligne par pipeline.

**Pistes de corrigé.** Les écarts viennent presque toujours du découpage : `RecursiveCharacterTextSplitter(chunk_size=1200)` en caractères ≈ 340 tokens, `SentenceSplitter(chunk_size=300)` en tokens, et votre découpeur maison qui ne coupe pas les FAQ. Harmonisez les trois à 300 tokens / 40 de chevauchement et recommencez : les premiers résultats convergent. Pour le changement de modèle : `ChatMistralAI(model="mistral-small-latest")` (paquet `langchain-mistralai`) ou `ChatOllama` ; côté LlamaIndex, `llama_index.llms.mistralai.MistralAI` ou `llama_index.llms.ollama.Ollama`.

## ✅ Auto-évaluation express

1. Que gagne-t-on en composant une chaîne LangChain avec `|` plutôt qu'en appelant les fonctions à la suite ?
2. Citez deux choses que LlamaIndex fournit nativement sur les documents et que vous avez dû coder vous-même en L090.
3. Pourquoi conserver une frontière nette entre recherche et génération, même avec un framework ?

**Réponses.** 1. Les Runnables composés offrent sans code supplémentaire le streaming (`.stream`), le traitement par lots (`.batch`), l'asynchrone et le tracing (LangSmith / callbacks). 2. Les métadonnées de page (`page_label`), les relations entre nœuds voisins, les modes de synthèse (`compact`, `refine`, `tree_summarize`), le choix automatique du lecteur par extension. 3. Pour pouvoir remplacer la recherche (hybride, reranking — L092), l'évaluer séparément (L093) et brancher des fonctionnalités d'API comme les citations garanties de Claude, qui exigent de construire soi-même le message final.

## 📚 Pour aller plus loin
- [LangChain — changelog](https://docs.langchain.com/oss/python/releases/changelog.md) 🇬🇧 — l'état exact des versions 1.x et de LangGraph.
- [LlamaIndex — documentation](https://docs.llamaindex.ai) 🇬🇧 — guides « Loading », « Indexing », « Querying ».
- [Haystack](https://haystack.deepset.ai) 🇬🇧 — l'alternative orientée pipelines de production.
- [Hugging Face — Agents Course](https://huggingface.co/learn/agents-course) 🇬🇧 — unité 2 (LlamaIndex, LangGraph) et unité 3 (RAG agentique) ; gratuit, certificat offert.
- [LangSmith](https://smith.langchain.com) 🇬🇧 — tracer chaque étape d'une chaîne LangChain.
