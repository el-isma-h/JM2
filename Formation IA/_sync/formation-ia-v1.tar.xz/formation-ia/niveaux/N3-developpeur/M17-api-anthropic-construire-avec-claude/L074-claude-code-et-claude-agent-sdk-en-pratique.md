---
id: L074
module: M17
level: N3
title: "Claude Code et Claude Agent SDK en pratique"
minutes: 50
objectives:
  - "Installer et configurer Claude Code (CLAUDE.md, permissions, hooks, subagents) et appliquer le workflow explorer → planifier → coder → valider"
  - "Automatiser Claude Code en mode headless (claude -p) et dans une CI (GitHub Actions)"
  - "Construire un agent autonome avec le Claude Agent SDK (Python et TypeScript) : outils, permissions, budget, sessions"
  - "Situer Claude Code, l'Agent SDK et les Managed Agents dans l'offre Anthropic et choisir selon le cas d'usage"
skills: ["C3.4", "C3.1"]
sources:
  - { title: "Claude Code — Documentation (overview)", url: "https://code.claude.com/docs", lang: "en" }
  - { title: "Claude Code — Memory (CLAUDE.md)", url: "https://code.claude.com/docs/en/memory.md", lang: "en" }
  - { title: "Claude Code — Hooks reference", url: "https://code.claude.com/docs/en/hooks.md", lang: "en" }
  - { title: "Claude Code — Subagents", url: "https://code.claude.com/docs/en/sub-agents.md", lang: "en" }
  - { title: "Claude Code — Headless mode", url: "https://code.claude.com/docs/en/headless.md", lang: "en" }
  - { title: "Claude Code — GitHub Actions", url: "https://code.claude.com/docs/en/github-actions.md", lang: "en" }
  - { title: "Claude Code — Best practices", url: "https://code.claude.com/docs/en/best-practices.md", lang: "en" }
  - { title: "Claude Agent SDK — Overview", url: "https://code.claude.com/docs/en/agent-sdk/overview", lang: "en" }
  - { title: "Claude Agent SDK — Python reference", url: "https://code.claude.com/docs/en/agent-sdk/python.md", lang: "en" }
  - { title: "Claude Agent SDK — TypeScript reference", url: "https://code.claude.com/docs/en/agent-sdk/typescript.md", lang: "en" }
  - { title: "Claude Platform — Managed Agents overview", url: "https://platform.claude.com/docs/en/managed-agents/overview", lang: "en" }
  - { title: "Claude Academy — Claude Code 101", url: "https://academy.claude.com/courses/claude-code-101", lang: "en" }
---

# Claude Code et Claude Agent SDK en pratique

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Prendre en main Claude Code sur un dépôt réel, le configurer avec un `CLAUDE.md` qui tient en une page, choisir le bon mode de permission et brancher des hooks de sécurité.
- Le piloter sans interface (`claude -p`) depuis un script ou une CI pour automatiser revues, migrations et rapports.
- Réutiliser **le même moteur** dans vos propres produits grâce au Claude Agent SDK, avec outils personnalisés, budget et sessions.
- Expliquer à un client la différence entre « l'API », « l'Agent SDK », « Claude Code » et « Managed Agents » — question récurrente des certifications Anthropic.

## 1. Claude Code : un agent de code dans votre terminal

### 1.1 Qu'est-ce que c'est ?

Claude Code est l'agent de développement d'Anthropic : il lit votre dépôt, planifie, modifie les fichiers, lance les tests, commite. Techniquement, c'est **la boucle d'outils de L070** (lecture/écriture de fichiers, bash, grep, recherche web) exécutée localement, avec un système de permissions. Il fonctionne dans le terminal, VS Code, JetBrains, l'application Desktop, le web (`claude.ai/code`) et mobile (page [Overview](https://code.claude.com/docs)).

```bash
# Installation native (nov. 2026)
curl -fsSL https://claude.ai/install.sh | bash          # macOS / Linux
# Windows PowerShell : irm https://claude.ai/install.ps1 | iex
# ou : brew install --cask claude-code · winget install Anthropic.ClaudeCode

cd mon-projet
claude            # session interactive ; authentification par abonnement Claude ou ANTHROPIC_API_KEY
```

### 1.2 Le workflow qui marche : explorer → planifier → coder → valider

Le cours « Claude Code 101 » et la page [Best practices](https://code.claude.com/docs/en/best-practices.md) enseignent un rituel simple :

1. **Explorer** : « Lis `src/facturation/` et explique-moi comment la TVA est calculée. Ne modifie rien. »
2. **Planifier** (mode *plan*, touche Maj+Tab ou `/plan`) : « Propose un plan pour ajouter le taux 5,5 % sur les travaux de rénovation énergétique. »
3. **Coder** : « Applique le plan, étape par étape, lance les tests après chaque étape. »
4. **Valider** : relire le diff, `git diff`, tests, puis commit (Claude rédige un message conventionnel).

Le secret n'est pas dans la magie du modèle mais dans **la boucle de retour** : donnez à Claude un moyen de vérifier son travail (tests, linter, compilation) et il corrige ses propres erreurs.

### 1.3 CLAUDE.md : la mémoire du projet

Le fichier `CLAUDE.md` à la racine (ou `~/.claude/CLAUDE.md` pour vos préférences personnelles, ou `AGENTS.md` lu par plusieurs agents) est chargé automatiquement à chaque session (page [Memory](https://code.claude.com/docs/en/memory.md)). Gardez-le **court et factuel** :

```markdown
# Projet Facturly — API de facturation (FastAPI + PostgreSQL)

## Commandes
- Tests : `uv run pytest -q`  ·  Lint : `uv run ruff check .`  ·  Migrations : `uv run alembic upgrade head`

## Règles
- Montants en centimes (int), jamais en float. Raison : erreurs d'arrondi sur la TVA.
- Toute nouvelle route a un test dans `tests/api/`.
- Ne jamais modifier `migrations/versions/*` existantes ; créer une nouvelle migration.
- Les messages de commit suivent Conventional Commits en français.

## Contexte métier
- TVA : 20 % par défaut, 10 % rénovation logement > 2 ans, 5,5 % rénovation énergétique.
```

### 1.4 Permissions, hooks, subagents

**Permissions.** Par défaut, Claude Code demande confirmation avant chaque écriture ou commande ; vous pouvez autoriser des outils précis (`Bash(uv run pytest*)`) dans `.claude/settings.json`, passer en mode « accept edits », ou, dans un bac à sable isolé, désactiver les confirmations (page [Permissions](https://code.claude.com/docs/en/permissions.md)). Règle enseignée dans le cours partenaire « Claude Code, MCP & Integration » : **le mode de permission se choisit selon le risque de l'environnement**, pas selon la confiance dans le modèle.

**Hooks.** Des commandes shell déclenchées sur **32 événements** (page [Hooks reference](https://code.claude.com/docs/en/hooks.md)) : `SessionStart`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `PermissionRequest`, `Stop`, `PreCompact`, `SubagentStart`… Exemple : bloquer tout `rm -rf` et formater automatiquement après chaque écriture.

```json
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "Bash",
      "hooks": [{ "type": "command",
                  "command": "python3 .claude/hooks/garde_fou.py" }]
    }],
    "PostToolUse": [{
      "matcher": "Edit|Write",
      "hooks": [{ "type": "command", "command": "uv run ruff format $CLAUDE_FILE_PATHS 2>/dev/null || true" }]
    }]
  }
}
```

```python
# .claude/hooks/garde_fou.py — hook PreToolUse : lit la commande sur stdin (JSON), refuse les commandes destructrices
import json, re, sys
evenement = json.load(sys.stdin)
commande = evenement.get("tool_input", {}).get("command", "")
if re.search(r"rm\s+-rf|git\s+push\s+--force|DROP\s+TABLE", commande, re.I):
    print(f"Commande bloquée par le hook : {commande}", file=sys.stderr)
    sys.exit(2)      # code 2 = refus, le message est transmis à Claude
sys.exit(0)
```

**Subagents.** Un subagent (`/agents`, page [Subagents](https://code.claude.com/docs/en/sub-agents.md)) est un assistant spécialisé avec **sa propre fenêtre de contexte**, son system prompt et ses outils restreints : un « relecteur sécurité » en lecture seule, un « rédacteur de tests ». Le cours « Introduction to subagents » insiste sur trois bonnes pratiques : format de sortie structuré, signalement explicite des blocages, restriction des outils.

## 2. Automatiser : headless et CI

Le mode headless (page [Headless](https://code.claude.com/docs/en/headless.md)) exécute une consigne sans interface et renvoie le résultat (texte ou JSON) :

```bash
# Revue d'un diff dans un script ; sortie JSON exploitable
git diff main...HEAD > /tmp/diff.txt
claude -p "Relis ce diff ($(wc -l < /tmp/diff.txt) lignes) et liste les risques de régression sur la TVA. \
Réponds en JSON {risques: [{fichier, ligne, gravite, explication}]}" \
  --output-format json --allowedTools "Read,Grep" --max-turns 8 < /tmp/diff.txt > revue.json
```

Dans GitHub Actions (page [GitHub Actions](https://code.claude.com/docs/en/github-actions.md)), l'action officielle lance Claude Code sur chaque PR : revue automatique, réponse aux `@claude` dans les commentaires, correction d'issues. La clé API est un secret du dépôt ; les permissions sont limitées par le workflow. Les Routines (tâches planifiées cloud) et les Channels (Slack, etc.) étendent le même principe. Surveillez les coûts via la page [Costs](https://code.claude.com/docs/en/costs.md) : `/cost` en session, et les rapports d'usage de la Console.

> ⚠️ **Piège fréquent** — Laisser un hook ou une CI en mode « sans confirmation » avec accès au réseau et aux secrets de production. Un fichier malveillant lu par l'agent (injection indirecte) peut lui faire exécuter des commandes. Isolez (conteneur, page [Sandboxing](https://code.claude.com/docs/en/sandboxing.md)), limitez les outils, loggez.

## 3. Claude Agent SDK : le moteur de Claude Code dans vos produits

### 3.1 Positionnement

Le [Claude Agent SDK](https://code.claude.com/docs/en/agent-sdk/overview) (Python et TypeScript) expose **exactement** la boucle, les outils, les hooks, les sessions et les permissions de Claude Code, pour construire vos propres agents : assistant de migration de code, agent de support qui lit une base documentaire, robot d'analyse de données. Deux règles contractuelles de la page officielle : l'usage est régi par les **Commercial Terms** d'Anthropic (pas de connexion claude.ai pour un produit tiers : clé API, Bedrock, Vertex ou Foundry), et vous pouvez nommer votre produit « … powered by Claude Agent », **pas** « Claude Code ».

| | Messages API | Agent SDK | Claude Code | Managed Agents |
|---|---|---|---|---|
| Qui héberge la boucle ? | vous (L070) | vous (SDK) | votre machine / CI | **Anthropic** (sandbox cloud ou self-hosted) |
| Outils fichiers/bash inclus | non | oui | oui | oui |
| Quand ? | contrôle total, intégration fine | produit agentique sur mesure | développement logiciel | agents long-running sans infra ; 0,08 $/h de session + tokens (nov. 2026) |

### 3.2 Premier agent en Python

```bash
pip install claude-agent-sdk          # Python ; Node.js requis (le SDK embarque le moteur Claude Code)
npm install @anthropic-ai/claude-agent-sdk   # TypeScript
export ANTHROPIC_API_KEY="sk-ant-..."
```

```python
# agent_audit.py — agent qui audite un dossier de factures et produit un rapport, avec budget plafonné
import asyncio
from claude_agent_sdk import query, ClaudeAgentOptions

async def main():
    options = ClaudeAgentOptions(
        system_prompt="Vous êtes un auditeur comptable. Vous lisez les fichiers CSV du dossier 'factures/' "
                      "et rédigez 'rapport.md' : anomalies (doublons, TVA incohérente, montants négatifs). "
                      "Ne modifiez jamais les fichiers sources.",
        allowed_tools=["Read", "Glob", "Grep", "Write"],   # pas de Bash : lecture + un seul fichier écrit
        permission_mode="acceptEdits",                    # écrit sans confirmation (dans ce dossier seulement)
        cwd="./audit",
        max_turns=25,
        max_budget_usd=0.50,                              # plafond de dépense pour cette session
    )
    async for message in query(prompt="Audite les factures d'octobre 2026 et écris le rapport.", options=options):
        # Les messages sont typés : assistant (texte / tool_use), user (tool_result), result (fin)
        tipe = type(message).__name__
        if tipe == "AssistantMessage":
            for bloc in message.content:
                if getattr(bloc, "text", None):
                    print("Claude :", bloc.text[:200])
                elif getattr(bloc, "name", None):
                    print("  ↳ outil", bloc.name, getattr(bloc, "input", ""))
        elif tipe == "ResultMessage":
            print(f"\nTerminé · tours : {message.num_turns} · coût : {message.total_cost_usd:.4f} $")

asyncio.run(main())
```

### 3.3 Le même agent en TypeScript, avec un outil personnalisé

Le SDK permet de déclarer vos propres outils **en process** (page [Custom tools](https://code.claude.com/docs/en/agent-sdk/custom-tools)) : ils sont exposés à l'agent comme un petit serveur MCP interne (L075).

```typescript
// agent_audit.ts — agent TypeScript avec un outil personnalisé « verifier_siret »
import { query, tool, createSdkMcpServer } from "@anthropic-ai/claude-agent-sdk";
import { z } from "zod";

// Outil métier : vérification de format SIRET (14 chiffres, clé de Luhn)
const verifierSiret = tool(
  "verifier_siret",
  "Vérifie qu'un numéro SIRET (14 chiffres) est bien formé (clé de Luhn). Renvoie 'valide' ou la raison du rejet.",
  { siret: z.string().describe("14 chiffres, sans espaces") },
  async ({ siret }) => {
    const ok = /^\d{14}$/.test(siret) && luhn(siret);
    return { content: [{ type: "text", text: ok ? "valide" : "invalide (format ou clé de Luhn)" }] };
  },
);
function luhn(s: string) {
  let somme = 0;
  for (let i = 0; i < s.length; i++) {
    let d = Number(s[s.length - 1 - i]);
    if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
    somme += d;
  }
  return somme % 10 === 0;
}

const outilsMetier = createSdkMcpServer({ name: "metier", tools: [verifierSiret] });

async function main() {
  for await (const message of query({
    prompt: "Lis factures/*.csv, vérifie le SIRET de chaque fournisseur avec l'outil verifier_siret et écris rapport.md.",
    options: {
      systemPrompt: "Vous êtes un auditeur comptable prudent. Ne modifiez jamais les fichiers sources.",
      allowedTools: ["Read", "Glob", "Write", "mcp__metier__verifier_siret"],
      permissionMode: "acceptEdits",
      mcpServers: { metier: outilsMetier },
      maxTurns: 25,
      cwd: "./audit",
    },
  })) {
    if (message.type === "result") {
      console.log("Terminé ·", message.subtype, "· coût :", (message as any).total_cost_usd, "$");
    }
  }
}
main();
```

Les noms exacts des options (`permission_mode` / `permissionMode`, `max_budget_usd`, `allowed_tools`, `mcp_servers`) sont ceux des références [Python](https://code.claude.com/docs/en/agent-sdk/python.md) et [TypeScript](https://code.claude.com/docs/en/agent-sdk/typescript.md) ; vérifiez-les pour votre version. Le SDK gère aussi les **sessions** (reprendre une conversation), le **streaming**, les **sorties structurées**, les **hooks**, les **subagents**, les **skills** (L076) et le **suivi des coûts** (pages `sessions`, `streaming-output`, `structured-outputs`, `hooks`, `subagents`, `cost-tracking`).

> 💡 **À retenir** — Agent SDK = « Claude Code sans le terminal ». Si votre besoin ressemble à « un agent qui lit/écrit des fichiers et exécute des commandes dans un environnement », prenez le SDK ; si c'est « un appel bien contrôlé avec trois outils métier », la Messages API (L070) suffit et coûte moins de tokens.

## 4. Managed Agents : la boucle hébergée par Anthropic

Depuis avril 2026, les [Managed Agents](https://platform.claude.com/docs/en/managed-agents/overview) (bêta, en-tête `managed-agents-2026-04-01`) permettent de définir un **Agent** (modèle + system prompt + outils + serveurs MCP + skills), de l'exécuter dans un **Environment** (sandbox cloud Anthropic ou auto-hébergé) au sein de **Sessions**, et d'en suivre les **Events** en SSE. Tarif : 0,08 $ par heure de session active + tokens (nov. 2026). Ils ne sont pas éligibles aux offres ZDR/HIPAA. Le cours « Claude Platform 101 » y consacre un module ; nous y reviendrons dans M21 (agents en code).

🎮 **Défi** — Pour chaque besoin, choisissez l'outil (API / Agent SDK / Claude Code / Managed Agents) : (a) chatbot FAQ avec 2 outils ; (b) agent qui migre 300 fichiers d'un framework à un autre dans la CI ; (c) un agent « veille réglementaire » qui tourne 24 h/24 sans serveur à maintenir ; (d) vous-même, aujourd'hui, pour écrire les tests du projet M17. *(a : API ; b : Claude Code headless ou Agent SDK ; c : Managed Agents ; d : Claude Code.)*

## 🧪 Exercice pratique

**Consigne.** Sur un petit dépôt Python ou TypeScript (par exemple le code des leçons précédentes) :
1. Écrivez un `CLAUDE.md` ≤ 40 lignes (commandes, règles motivées, contexte métier).
2. Ajoutez un hook `PreToolUse` qui bloque `git push --force` et `rm -rf`, et un hook `PostToolUse` qui lance le formateur.
3. Créez un subagent « relecteur » en lecture seule (outils `Read`, `Grep`) dont la sortie est un JSON `{problemes: [...]}`.
4. En mode headless, générez un rapport de revue sur un diff ; consultez `/cost`.
5. Avec l'Agent SDK (Python **ou** TypeScript), écrivez un agent qui lit `factures/*.csv`, appelle un outil personnalisé `verifier_siret`, et écrit `rapport.md`, avec `max_turns ≤ 25` et un budget plafonné.

**Critères de réussite.** Le hook bloque effectivement la commande dangereuse (testez !) ; le subagent ne modifie aucun fichier ; le rapport headless est un JSON valide ; l'agent SDK termine avec un message `result` et un coût affiché < 0,50 $.

<details>
<summary>Pistes</summary>

- Testez le hook en demandant à Claude Code : « Supprime le dossier build avec rm -rf » ; il doit expliquer le refus.
- Pour le subagent, définissez-le dans `.claude/agents/relecteur.md` avec un frontmatter `tools: Read, Grep`.
- Si l'Agent SDK ne trouve pas Node.js, installez Node 20+ : le SDK embarque le moteur de Claude Code.
</details>

## ✅ Auto-évaluation express

1. Quel fichier Claude Code lit-il automatiquement pour connaître les conventions du projet ?
2. Quel code de sortie un hook doit-il renvoyer pour refuser une action, et que devient le message ?
3. Citez deux différences entre l'Agent SDK et les Managed Agents.

**Réponses.** 1. `CLAUDE.md` (projet ou utilisateur), ou `AGENTS.md`. 2. Le code 2 ; le message sur stderr est transmis à Claude pour qu'il s'adapte. 3. Agent SDK : boucle hébergée par vous, facturée aux tokens ; Managed Agents : boucle hébergée par Anthropic (sandbox cloud), facturée 0,08 $/h de session + tokens, non éligible ZDR/HIPAA.

## 📚 Pour aller plus loin
- [Claude Code — documentation](https://code.claude.com/docs) 🇬🇧 — installation, quickstart, index complet (`llms.txt`).
- [Hooks guide](https://code.claude.com/docs/en/hooks-guide.md) 🇬🇧 — exemples de hooks de sécurité et de qualité.
- [Agent SDK — Overview](https://code.claude.com/docs/en/agent-sdk/overview) 🇬🇧 — concepts, conditions d'usage, liens vers sessions, permissions, coûts.
- [Claude Code 101 (Claude Academy)](https://academy.claude.com/courses/claude-code-101) 🇬🇧 et [Claude Code in action](https://academy.claude.com/courses/claude-code-in-action) 🇬🇧 — cours gratuits avec badge, que nous vous encourageons à suivre.
- [Claude Code: A Highly Agentic Coding Assistant (DeepLearning.AI)](https://deeplearning.ai/short-courses/claude-code-a-highly-agentic-coding-assistant) 🇬🇧 — cours court gratuit (worktrees, GitHub, hooks).
- [The AI-native SDLC playbook](https://academy.claude.com/courses/ai-native-sdlc-playbook) 🇬🇧 — intégrer Claude Code dans le cycle de développement d'une équipe.
