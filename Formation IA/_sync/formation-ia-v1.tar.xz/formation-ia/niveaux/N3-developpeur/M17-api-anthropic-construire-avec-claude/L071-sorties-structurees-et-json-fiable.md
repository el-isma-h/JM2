---
id: L071
module: M17
level: N3
title: "Sorties structurées et JSON fiable"
minutes: 45
objectives:
  - "Obtenir un JSON conforme à un schéma avec output_config.format (json_schema) et les helpers parse() / Pydantic / Zod"
  - "Comparer les trois approches (prompt seul, outil « extracteur », sorties structurées natives) et choisir selon le cas"
  - "Valider et post-traiter la sortie, gérer les refus et les troncatures, et connaître les incompatibilités (citations, préremplissage)"
skills: ["C3.2"]
sources:
  - { title: "Claude Platform — Structured outputs", url: "https://platform.claude.com/docs/en/build-with-claude/structured-outputs", lang: "en" }
  - { title: "Claude Platform — Strict tool use", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use", lang: "en" }
  - { title: "Claude Platform — Handling stop reasons", url: "https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons", lang: "en" }
  - { title: "Claude Cookbook — Extracting structured JSON with tool use", url: "https://platform.claude.com/cookbook/tool-use-extracting-structured-json", lang: "en" }
  - { title: "Claude Platform — Prompting best practices (Control the format)", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
---

# Sorties structurées et JSON fiable

> ⏱ 45 min · 🎯 Niveau 3 · 📚 Module 17

## 🎯 Ce que vous saurez faire
- Faire produire à Claude un JSON **garanti conforme** à un schéma, sans regex ni `try/except json.loads`.
- Utiliser `output_config.format` à la main, puis les helpers `client.messages.parse()` (Pydantic) et `zodOutputFormat` (Zod) des SDK v2.
- Savoir quand une sortie structurée est le bon outil, quand un outil « extracteur » est préférable, et quand un simple prompt suffit.
- Anticiper les cas limites : refus, `max_tokens`, schémas trop complexes, incompatibilité avec les citations.

## 1. Pourquoi le JSON « à la main » finit toujours par casser

Vous avez tous écrit ce code : « Réponds uniquement en JSON », puis `json.loads(reponse)`. Et un jour, Claude ajoute « Voici le JSON demandé : », ou un commentaire, ou une virgule finale, et votre pipeline de 50 000 factures s'arrête à la facture 3 412 à 2 h du matin. Le problème n'est pas la qualité du modèle, c'est **l'absence de contrat**.

Trois approches existent en nov. 2026 :

| Approche | Garantie | Quand l'utiliser |
|---|---|---|
| **Prompt + description du format** | aucune (le modèle « fait de son mieux ») | prototypes, sorties lues par un humain |
| **Outil « extracteur »** avec `strict: true` (L070) | arguments de l'outil conformes au schéma | quand l'extraction est **une étape** d'un agent avec d'autres outils |
| **Sorties structurées natives** (`output_config.format`) | **réponse finale** conforme au schéma JSON | extraction, classification, formulaires, tout pipeline qui parse |

La page officielle [Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) décrit la troisième : vous fournissez un schéma JSON dans `output_config.format` (type `json_schema`) ; l'API contraint la génération pour que le texte renvoyé **soit** un document JSON valide conforme au schéma.

## 2. Sorties structurées natives : la forme brute

```python
# structured_raw.py — extraction d'un devis d'artisan vers un JSON conforme à un schéma
import json
from anthropic import Anthropic

client = Anthropic()

SCHEMA = {
    "type": "object",
    "properties": {
        "client": {"type": "string", "description": "Nom du client tel qu'écrit sur le devis"},
        "date": {"type": "string", "description": "Date du devis au format AAAA-MM-JJ"},
        "lignes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "designation": {"type": "string"},
                    "quantite": {"type": "number"},
                    "prix_unitaire_ht": {"type": "number"},
                },
                "required": ["designation", "quantite", "prix_unitaire_ht"],
                "additionalProperties": False,
            },
        },
        "tva_pct": {"type": "number", "enum": [5.5, 10, 20]},
        "total_ht": {"type": "number"},
        "incertitudes": {"type": "array", "items": {"type": "string"},
                         "description": "Champs illisibles ou ambigus ; vide si tout est clair"},
    },
    "required": ["client", "date", "lignes", "tva_pct", "total_ht", "incertitudes"],
    "additionalProperties": False,
}

DEVIS = """DEVIS n° 2026-117 — 3 novembre 2026
Client : SCI Les Tilleuls
Remplacement chauffe-eau 200 L : 1 x 689,00 € HT
Main d'œuvre : 3 h x 55,00 € HT
Évacuation ancien appareil : 1 x 40,00 € HT
TVA 10 % (logement > 2 ans)"""

r = client.messages.create(
    model="claude-sonnet-5-5",
    max_tokens=800,
    system="Vous extrayez des données de devis d'artisans français. N'inventez aucune valeur : "
           "signalez les doutes dans 'incertitudes'.",
    messages=[{"role": "user", "content": DEVIS}],
    output_config={"format": {"type": "json_schema", "schema": SCHEMA}},
)

assert r.stop_reason == "end_turn", f"réponse incomplète : {r.stop_reason}"
donnees = json.loads(r.content[0].text)    # garanti parsable et conforme
print(json.dumps(donnees, ensure_ascii=False, indent=2))

# Contrôle métier (le schéma garantit la FORME, pas la VÉRITÉ) :
calcule = sum(l["quantite"] * l["prix_unitaire_ht"] for l in donnees["lignes"])
if abs(calcule - donnees["total_ht"]) > 0.01:
    print(f"⚠️ total incohérent : {calcule:.2f} vs {donnees['total_ht']:.2f}")
```

```typescript
// structured_raw.ts — même extraction en TypeScript
import Anthropic from "@anthropic-ai/sdk";
const client = new Anthropic();

const schema = {
  type: "object",
  properties: {
    client: { type: "string" },
    date: { type: "string", description: "AAAA-MM-JJ" },
    lignes: { type: "array", items: { type: "object",
      properties: { designation: { type: "string" }, quantite: { type: "number" }, prix_unitaire_ht: { type: "number" } },
      required: ["designation", "quantite", "prix_unitaire_ht"], additionalProperties: false } },
    tva_pct: { type: "number", enum: [5.5, 10, 20] },
    total_ht: { type: "number" },
    incertitudes: { type: "array", items: { type: "string" } },
  },
  required: ["client", "date", "lignes", "tva_pct", "total_ht", "incertitudes"],
  additionalProperties: false,
} as const;

async function main() {
  const r = await client.messages.create({
    model: "claude-sonnet-5-5", max_tokens: 800,
    system: "Vous extrayez des données de devis d'artisans français. N'inventez aucune valeur.",
    messages: [{ role: "user", content: "DEVIS n° 2026-117 — 3 novembre 2026\nClient : SCI Les Tilleuls\nRemplacement chauffe-eau 200 L : 1 x 689,00 € HT\nMain d'œuvre : 3 h x 55,00 € HT\nTVA 10 %" }],
    output_config: { format: { type: "json_schema", schema } },
  });
  if (r.stop_reason !== "end_turn") throw new Error(`réponse incomplète : ${r.stop_reason}`);
  const bloc = r.content[0];
  const donnees = JSON.parse(bloc.type === "text" ? bloc.text : "{}");
  console.log(donnees);
}
main();
```

> 💡 **À retenir** — Une sortie structurée garantit la **forme** (le JSON est valide et respecte le schéma), jamais le **fond** (les valeurs peuvent être fausses). Gardez toujours un contrôle métier (totaux, dates plausibles, références existantes) et un champ « incertitudes » pour que le modèle puisse avouer un doute au lieu d'inventer.

## 3. Les helpers des SDK v2 : Pydantic et Zod

Écrire un schéma JSON à la main est fastidieux et source d'erreurs. Les SDK v2 fournissent `client.messages.parse()` (Python, avec un modèle Pydantic) et `zodOutputFormat` (TypeScript, avec un schéma Zod) : le schéma est généré, la réponse est validée et désérialisée en objet typé.

```python
# structured_pydantic.py — extraction typée avec client.messages.parse() et Pydantic
from pydantic import BaseModel, Field
from anthropic import Anthropic

client = Anthropic()

class Ligne(BaseModel):
    designation: str
    quantite: float
    prix_unitaire_ht: float

class Devis(BaseModel):
    client: str
    date: str = Field(description="AAAA-MM-JJ")
    lignes: list[Ligne]
    tva_pct: float
    total_ht: float
    incertitudes: list[str] = Field(default_factory=list)

r = client.messages.parse(
    model="claude-sonnet-5-5",
    max_tokens=800,
    system="Vous extrayez des données de devis d'artisans français. N'inventez aucune valeur.",
    messages=[{"role": "user", "content": "DEVIS du 3 nov. 2026, client Boulangerie Martin : "
                                           "pétrin 1 x 2 400 € HT, livraison 1 x 120 € HT, TVA 20 %"}],
    output_format=Devis,          # le SDK génère le json_schema et valide la réponse
)
devis: Devis = r.parsed_output    # objet Pydantic typé (nom de l'attribut : voir la doc de votre version du SDK)
print(devis.client, devis.total_ht, [l.designation for l in devis.lignes])
```

```typescript
// structured_zod.ts — extraction typée avec Zod (SDK TypeScript v2)
import Anthropic from "@anthropic-ai/sdk";
import { zodOutputFormat } from "@anthropic-ai/sdk/helpers/zod";
import { z } from "zod";

const client = new Anthropic();

const Devis = z.object({
  client: z.string(),
  date: z.string().describe("AAAA-MM-JJ"),
  lignes: z.array(z.object({ designation: z.string(), quantite: z.number(), prix_unitaire_ht: z.number() })),
  tva_pct: z.number(),
  total_ht: z.number(),
  incertitudes: z.array(z.string()),
});

async function main() {
  const r = await client.messages.parse({
    model: "claude-sonnet-5-5", max_tokens: 800,
    system: "Vous extrayez des données de devis d'artisans français. N'inventez aucune valeur.",
    messages: [{ role: "user", content: "DEVIS du 3 nov. 2026, client Boulangerie Martin : pétrin 1 x 2 400 € HT, livraison 1 x 120 € HT, TVA 20 %" }],
    output_format: zodOutputFormat(Devis),
  });
  const devis = r.parsed_output; // typé z.infer<typeof Devis>
  console.log(devis?.client, devis?.total_ht);
}
main();
```

Les noms exacts des helpers (`parse`, `parsed_output`, chemin d'import de `zodOutputFormat`) sont ceux documentés sur la page Structured outputs en nov. 2026 ; en cas de divergence avec votre version du SDK, la forme brute de la section 2 fonctionne toujours.

## 4. Règles, limites et incompatibilités

La page officielle précise plusieurs contraintes (nov. 2026) :

- **Sous-ensemble de JSON Schema** : objets, tableaux, chaînes, nombres, booléens, `enum`, `required`, `additionalProperties: false` sont supportés ; certaines contraintes (expressions régulières complexes, `minimum`/`maximum`, récursivité profonde) peuvent être ignorées ou refusées. Vérifiez la liste sur la page avant de concevoir un schéma exotique ; au besoin, validez les contraintes numériques dans votre code.
- **Incompatible avec les citations** (L072) et avec l'ancien préremplissage : une requête avec `citations` et `output_config.format` est refusée. Pour « extraire avec sources », faites deux appels, ou demandez des champs `citation_texte` dans le schéma.
- **Premier appel plus lent** : la contrainte de grammaire est compilée puis mise en cache côté Anthropic ; les appels suivants avec le même schéma sont rapides.
- **`stop_reason`** : si `max_tokens` est atteint, le JSON est tronqué (et donc invalide). Dimensionnez `max_tokens` selon la taille attendue ; en cas de `refusal`, il n'y a pas de JSON du tout. Testez toujours `stop_reason == "end_turn"`.
- **Streaming** : compatible ; vous recevez des `text_delta` qui forment progressivement le JSON (utile pour afficher un formulaire qui se remplit).
- **Classification** : un schéma `{"type": "object", "properties": {"categorie": {"enum": [...]}, "confiance": {"type": "number"}}}` avec Haiku 5.5 est la façon la moins chère (0,10 $/MTok en entrée) et la plus fiable de router des tickets, e-mails ou factures.

> ⚠️ **Piège fréquent** — Mettre dans le schéma des champs que le document ne contient pas (« SIRET du client » sur un devis manuscrit). Comme le champ est `required`, le modèle **doit** le remplir… et invente. Rendez optionnels les champs incertains (`"type": ["string", "null"]`) ou ajoutez le champ « incertitudes ».

## 5. Choisir : sortie structurée ou outil extracteur ?

| Critère | Sortie structurée | Outil `strict` |
|---|---|---|
| La structure est la réponse finale | ✅ | ❌ (il faut un tour de plus) |
| L'extraction est une étape parmi d'autres outils | ❌ | ✅ |
| Besoin de citations sur les sources | ❌ (incompatible) | ✅ (ajoutez un champ) |
| Forçage de l'appel sur Claude 5.5 | n/a | ❌ (`tool_choice` forcé → erreur) |
| Simplicité du code | ✅ (`parse()`) | moyenne (boucle) |

La recette officielle [Extracting structured JSON with tool use](https://platform.claude.com/cookbook/tool-use-extracting-structured-json) montre l'approche « outil » ; depuis les sorties structurées natives, elle reste pertinente surtout à l'intérieur d'un agent.

🎮 **Défi** — Faites classer 20 objets d'e-mails de PME (« Relance facture 2026-089 », « Candidature spontanée », « Panne serveur ») en `{"categorie": "compta" | "rh" | "it" | "commercial" | "autre", "urgence": 1-5}` avec Haiku 5.5. Calculez le coût : 20 e-mails × ~60 tokens = 1 200 tokens d'entrée ≈ **0,00012 $**. Oui, douze cent-millièmes de dollar.

## 🧪 Exercice pratique

**Consigne.** Construisez un **extracteur de CV** pour un cabinet de recrutement :
1. Schéma (Pydantic **et** Zod) : `nom`, `email` (nullable), `annees_experience` (nombre), `competences` (liste), `langues` (liste d'objets `{langue, niveau ∈ {A1…C2, natif}}`), `incertitudes`.
2. Testez sur 3 CV texte (dont un incomplet sans e-mail et un avec une expérience ambiguë).
3. Ajoutez un contrôle métier : si `annees_experience > 50` ou si une compétence apparaît en double, marquez le CV « à vérifier ».
4. Mesurez le coût total avec `usage` et comparez Haiku 5.5 / Sonnet 5.5 sur la qualité de l'extraction.

**Critères de réussite.** Aucun `json.loads` ne lève d'exception sur les 3 CV ; le CV sans e-mail renvoie `null` et non une adresse inventée ; l'ambiguïté apparaît dans `incertitudes` ; `stop_reason` est contrôlé.

<details>
<summary>Pistes</summary>

- Pour un champ nullable en Pydantic : `email: str | None = None` ; en Zod : `z.string().nullable()`.
- Pour le niveau de langue : `Literal["A1","A2","B1","B2","C1","C2","natif"]` / `z.enum([...])`.
- Le CV ambigu doit faire apparaître une phrase du type « expérience 2019-2026 chevauche deux postes » dans `incertitudes`.
</details>

## ✅ Auto-évaluation express

1. Que garantit `output_config.format` : la forme ou le fond du JSON ?
2. Pourquoi ne peut-on pas combiner sorties structurées et citations ?
3. Quelle approche choisir pour extraire des données **au milieu** d'une boucle d'agent avec d'autres outils ?

**Réponses.** 1. La forme uniquement (JSON valide et conforme au schéma) ; les valeurs doivent être contrôlées. 2. Les deux fonctionnalités sont documentées comme incompatibles (nov. 2026) ; il faut deux appels ou des champs de citation dans le schéma. 3. Un outil extracteur avec `strict: true`.

## 📚 Pour aller plus loin
- [Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧 — schéma supporté, helpers `parse()`, limites et incompatibilités.
- [Strict tool use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use) 🇬🇧 — garantie de schéma sur les arguments d'outils.
- [Cookbook — Classification guide](https://platform.claude.com/cookbook/capabilities-classification-guide) 🇬🇧 — classer à grande échelle avec évaluation.
- [Handling stop reasons](https://platform.claude.com/docs/en/build-with-claude/handling-stop-reasons) 🇬🇧 — `refusal`, `max_tokens` et leurs conséquences sur un JSON.
