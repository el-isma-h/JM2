---
id: L097
module: M21
level: N3
title: "OpenAI Agents SDK, Claude Agent SDK, Pydantic AI"
minutes: 55
objectives:
  - "Implémenter le même agent métier (outils, sortie structurée, limites, garde-fous) avec OpenAI Agents SDK, Claude Agent SDK et Pydantic AI"
  - "Comparer les trois SDK sur des critères objectifs : philosophie, portabilité entre modèles, typage, outils intégrés, contrôle humain, coût, verrouillage"
  - "Choisir et justifier un SDK pour un cas d'usage donné, et situer les alternatives (Google ADK, smolagents, Vercel AI SDK)"
skills: ["C3.4", "C3.2", "C3.1"]
sources:
  - { title: "OpenAI — Agents SDK (guide)", url: "https://developers.openai.com/api/docs/guides/agents/sdk", lang: "en" }
  - { title: "OpenAI — Agents SDK Python (documentation)", url: "https://openai.github.io/openai-agents-python/", lang: "en" }
  - { title: "OpenAI — openai-agents-python (GitHub)", url: "https://github.com/openai/openai-agents-python", lang: "en" }
  - { title: "OpenAI — openai-agents-js (GitHub)", url: "https://github.com/openai/openai-agents-js", lang: "en" }
  - { title: "OpenAI — Guardrails & approvals", url: "https://developers.openai.com/api/docs/guides/agents/guardrails-approvals", lang: "en" }
  - { title: "Claude Agent SDK — Overview", url: "https://code.claude.com/docs/en/agent-sdk/overview", lang: "en" }
  - { title: "Claude Agent SDK — Custom tools", url: "https://code.claude.com/docs/en/agent-sdk/custom-tools", lang: "en" }
  - { title: "Claude Agent SDK — Structured outputs", url: "https://code.claude.com/docs/en/agent-sdk/structured-outputs", lang: "en" }
  - { title: "Claude Agent SDK — Hooks", url: "https://code.claude.com/docs/en/agent-sdk/hooks", lang: "en" }
  - { title: "Pydantic AI — documentation", url: "https://ai.pydantic.dev", lang: "en" }
  - { title: "Google ADK — documentation", url: "https://google.github.io/adk-docs/", lang: "en" }
  - { title: "Hugging Face — smolagents", url: "https://huggingface.co/docs/smolagents", lang: "en" }
  - { title: "Comparatif Claude Agent SDK / OpenAI Agents SDK / Google ADK (Composio)", url: "https://composio.dev/blog/claude-agents-sdk-vs-openai-agents-sdk-vs-google-adk", lang: "en" }
---

# OpenAI Agents SDK, Claude Agent SDK, Pydantic AI

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 21

## 🎯 Ce que vous saurez faire
- Écrire **le même agent** trois fois, dans trois SDK, et constater par vous-même ce qui change (et ce qui ne change pas).
- Expliquer en une phrase la philosophie de chacun : « agents + handoffs + guardrails » (OpenAI), « Claude Code sans terminal » (Anthropic), « FastAPI des agents » (Pydantic AI).
- Remplir une grille de choix défendable devant une DSI, y compris sur le verrouillage fournisseur.

## 1. Le cas commun : l'agent « demandes de congés »

Pour comparer honnêtement, nous fixons un cahier des charges unique, inspiré d'une PME française de 60 salariés :

- **Entrée** : un message libre (« Je voudrais poser du 22 au 26 décembre, Karim »).
- **Outils** : `solde_conges(employe)` → jours restants ; `poser_conge(employe, debut, fin)` → enregistre (action sensible).
- **Sortie structurée** obligatoire : `{"statut": "accepte" | "refuse" | "a_valider", "jours": int, "message": str}`.
- **Règles** : jamais plus de jours que le solde ; plus de 10 jours ouvrés → `a_valider` par le manager, sans appeler `poser_conge`.
- **Limites** : 8 tours maximum, garde-fou d'entrée (refuser les demandes qui ne concernent pas les congés).

Le modèle de données et les fonctions métier sont partagés par les trois implémentations :

```python
# commun.py — règles métier partagées (aucune dépendance IA)
from datetime import date
from pydantic import BaseModel, Field

SOLDES = {"karim": 12, "sophie": 3}
JOURNAL: list[dict] = []

class DecisionConge(BaseModel):
    statut: str = Field(description="accepte, refuse ou a_valider")
    jours: int = Field(ge=0, description="nombre de jours ouvrés demandés")
    message: str = Field(description="réponse à envoyer au salarié, en français, vouvoiement")

def jours_ouvres(debut: date, fin: date) -> int:
    return sum(1 for i in range((fin - debut).days + 1) if (debut.toordinal() + i) % 7 not in (5, 6))

def solde(employe: str) -> int:
    return SOLDES.get(employe.lower().strip(), 0)

def enregistrer(employe: str, debut: date, fin: date) -> str:
    n = jours_ouvres(debut, fin)
    if n > solde(employe):
        return f"ERREUR : {n} jours demandés, solde {solde(employe)}"
    SOLDES[employe.lower()] -= n
    JOURNAL.append({"employe": employe, "debut": str(debut), "fin": str(fin), "jours": n})
    return f"Congé enregistré : {n} jours ouvrés, nouveau solde {SOLDES[employe.lower()]}"
```

## 2. OpenAI Agents SDK : agents, handoffs, guardrails

L'[Agents SDK](https://developers.openai.com/api/docs/guides/agents/sdk) (Python et TypeScript, MIT, `pip install openai-agents`) s'organise autour de quatre primitives : **Agent** (instructions + outils + type de sortie), **Runner** (la boucle), **Handoffs** (un agent délègue à un autre, vu en L098) et **Guardrails** (validations d'entrée/sortie qui peuvent déclencher un *tripwire*). Il embarque le traçage (OpenTelemetry) et reste **agnostique** : plus de 100 modèles via LiteLLM d'après la doc, même si l'expérience est la plus fluide avec la Responses API d'OpenAI.

```python
# version_openai.py — Agents SDK : outils décorés, sortie typée, guardrail d'entrée, max_turns
from datetime import date
from pydantic import BaseModel
from agents import (Agent, Runner, function_tool, input_guardrail, GuardrailFunctionOutput,
                    InputGuardrailTripwireTriggered)
from commun import DecisionConge, solde, enregistrer

@function_tool
def solde_conges(employe: str) -> int:
    """Renvoie le solde de congés (jours ouvrés) d'un salarié, à partir de son prénom."""
    return solde(employe)

@function_tool
def poser_conge(employe: str, debut: str, fin: str) -> str:
    """Enregistre un congé (dates ISO AAAA-MM-JJ). Action irréversible : vérifier le solde avant.
    Ne jamais appeler si la demande dépasse 10 jours ouvrés (validation manager requise)."""
    return enregistrer(employe, date.fromisoformat(debut), date.fromisoformat(fin))

# Guardrail : un petit agent classifieur, économique, décide si la demande est bien une demande de congé
class Verdict(BaseModel):
    concerne_les_conges: bool
    raison: str

classifieur = Agent(name="filtre", model="gpt-6-luna",
                    instructions="Réponds si le message est une demande de congés / absence.", output_type=Verdict)

@input_guardrail
async def filtre_conges(ctx, agent, entree):
    r = await Runner.run(classifieur, entree, context=ctx.context)
    return GuardrailFunctionOutput(output_info=r.final_output, tripwire_triggered=not r.final_output.concerne_les_conges)

agent_rh = Agent(
    name="assistant-conges",
    model="gpt-6.1-sol",                                   # 2 $/M entrée, 10 $/M sortie (nov. 2026)
    instructions=("Vous êtes l'assistant RH d'une PME française. Vérifiez le solde avec solde_conges. "
                  "Plus de 10 jours ouvrés : statut a_valider, n'appelez pas poser_conge. "
                  "Sinon, si le solde suffit, enregistrez avec poser_conge et répondez statut accepte."),
    tools=[solde_conges, poser_conge],
    output_type=DecisionConge,                             # sortie structurée validée par Pydantic
    input_guardrails=[filtre_conges],
)

if __name__ == "__main__":
    try:
        r = Runner.run_sync(agent_rh, "Je voudrais poser du 22 au 26 décembre 2026, Karim", max_turns=8)
        print(r.final_output)                               # DecisionConge(statut='accepte', jours=5, ...)
        print("Tours :", len(r.raw_responses), "· tokens :", sum(x.usage.total_tokens for x in r.raw_responses))
    except InputGuardrailTripwireTriggered as e:
        print("Demande hors périmètre :", e.guardrail_result.output.output_info.raison)
```

Le même agent existe en TypeScript (`npm install @openai/agents`, schémas `zod`) ; la structure `Agent` / `run` / `tool` est identique ([dépôt JS](https://github.com/openai/openai-agents-js)).

**Ce qu'on aime** : les guardrails en parallèle (le classifieur tourne pendant que l'agent démarre, et l'arrête si besoin), le traçage intégré, la simplicité. **Ce qu'il faut savoir** : l'exécution se fait **dans votre application** (à distinguer de l'« Agents API » hébergée par OpenAI) ; les approbations humaines passent par le mécanisme *approvals* ([guide](https://developers.openai.com/api/docs/guides/agents/guardrails-approvals)) ; vérifiez les noms exacts pour votre version du SDK.

## 3. Claude Agent SDK : un agent qui a déjà des mains

Le [Claude Agent SDK](https://code.claude.com/docs/en/agent-sdk/overview) (vu en L074) part d'un postulat différent : l'agent **vient équipé** (lecture/écriture de fichiers, bash, recherche web, serveurs MCP, sous-agents, hooks, sessions, permissions) et vous **ajoutez** vos outils métier sous forme d'un serveur MCP en mémoire. Les garde-fous sont des **hooks** et des **modes de permission**, et la facture se plafonne avec `max_budget_usd`.

```python
# version_claude.py — Claude Agent SDK : outils métier via serveur MCP interne, hook de garde, sortie JSON
import asyncio, json
from datetime import date
from claude_agent_sdk import (query, tool, create_sdk_mcp_server, ClaudeAgentOptions, HookMatcher)
from commun import DecisionConge, solde, enregistrer, jours_ouvres

@tool("solde_conges", "Renvoie le solde de congés (jours ouvrés) d'un salarié à partir de son prénom.", {"employe": str})
async def solde_conges(args):
    return {"content": [{"type": "text", "text": str(solde(args["employe"]))}]}

@tool("poser_conge", "Enregistre un congé (dates ISO). Irréversible : vérifier le solde avant. Interdit au-delà de 10 jours ouvrés.",
      {"employe": str, "debut": str, "fin": str})
async def poser_conge(args):
    res = enregistrer(args["employe"], date.fromisoformat(args["debut"]), date.fromisoformat(args["fin"]))
    return {"content": [{"type": "text", "text": res}], "is_error": res.startswith("ERREUR")}

serveur_rh = create_sdk_mcp_server(name="rh", version="1.0.0", tools=[solde_conges, poser_conge])

# Hook PreToolUse : garde-fou déterministe, indépendant du modèle — bloque poser_conge > 10 jours ouvrés
async def garde_fou(input_data, tool_use_id, context):
    if input_data.get("tool_name") == "mcp__rh__poser_conge":
        a = input_data["tool_input"]
        if jours_ouvres(date.fromisoformat(a["debut"]), date.fromisoformat(a["fin"])) > 10:
            return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny",
                    "permissionDecisionReason": "Plus de 10 jours ouvrés : validation manager requise (statut a_valider)."}}
    return {}

async def main():
    options = ClaudeAgentOptions(
        model="claude-sonnet-5-5",
        system_prompt="Vous êtes l'assistant RH d'une PME française. Vérifiez le solde avant toute décision. "
                      "Répondez uniquement par le JSON demandé.",
        mcp_servers={"rh": serveur_rh},
        allowed_tools=["mcp__rh__solde_conges", "mcp__rh__poser_conge"],   # pas de fichiers, pas de bash
        hooks={"PreToolUse": [HookMatcher(matcher="mcp__rh__poser_conge", hooks=[garde_fou])]},
        output_format={"type": "json_schema", "schema": DecisionConge.model_json_schema()},
        max_turns=8,
        max_budget_usd=0.05,
    )
    async for m in query(prompt="Je voudrais poser du 22 au 26 décembre 2026, Karim", options=options):
        if type(m).__name__ == "ResultMessage":
            decision = DecisionConge.model_validate(m.structured_output)   # validation Pydantic côté client
            print(decision, "· coût :", f"{m.total_cost_usd:.4f} $", "· tours :", m.num_turns)

asyncio.run(main())
```

**Ce qu'on aime** : le hook `PreToolUse` est un garde-fou **en code**, exécuté avant l'outil quoi que « pense » le modèle — c'est la bonne façon d'implémenter une règle métier non négociable ; le budget en dollars ; la continuité avec Claude Code (mêmes sessions, mêmes skills, mêmes serveurs MCP). **Ce qu'il faut savoir** : le SDK embarque le moteur de Claude Code (Node.js requis), est conçu pour les modèles Claude (API, Bedrock, Vertex, Foundry), et son usage est régi par les Commercial Terms d'Anthropic. Les noms `output_format`, `structured_output`, `HookMatcher` sont ceux des pages [Structured outputs](https://code.claude.com/docs/en/agent-sdk/structured-outputs) et [Hooks](https://code.claude.com/docs/en/agent-sdk/hooks) en nov. 2026 ; vérifiez-les pour votre version.

## 4. Pydantic AI : le typage comme garde-fou

[Pydantic AI](https://ai.pydantic.dev) (MIT) est né de l'équipe Pydantic avec une ambition : apporter aux agents l'ergonomie que FastAPI a apportée aux API. Tout est typé : les dépendances injectées (`deps_type`), les outils (signature → schéma), la sortie (`output_type`, revalidée et **renvoyée au modèle en cas d'échec**), les limites d'usage (`UsageLimits`). Le modèle est une chaîne `fournisseur:modele` : changer de fournisseur est une ligne.

```python
# version_pydantic_ai.py — Pydantic AI : dépendances typées, outils, sortie validée, limites d'usage
from dataclasses import dataclass
from datetime import date
from pydantic_ai import Agent, RunContext, ModelRetry
from pydantic_ai.usage import UsageLimits
from commun import DecisionConge, solde, enregistrer, jours_ouvres

@dataclass
class Deps:                       # tout ce dont les outils ont besoin : connexion BDD, identifiant, etc.
    societe: str

agent = Agent(
    "anthropic:claude-sonnet-5-5",          # ou "openai:gpt-6.1-sol", "mistral:mistral-large-latest"…
    deps_type=Deps,
    output_type=DecisionConge,
    instructions="Vous êtes l'assistant RH de {societe}. Vérifiez le solde avant toute décision. "
                 "Plus de 10 jours ouvrés : statut a_valider, sans enregistrer.",
)

@agent.instructions
def contexte(ctx: RunContext[Deps]) -> str:
    return f"Société : {ctx.deps.societe}. Date du jour : {date.today().isoformat()}."

@agent.tool
def solde_conges(ctx: RunContext[Deps], employe: str) -> int:
    """Renvoie le solde de congés (jours ouvrés) d'un salarié à partir de son prénom."""
    return solde(employe)

@agent.tool
def poser_conge(ctx: RunContext[Deps], employe: str, debut: date, fin: date) -> str:
    """Enregistre un congé. Irréversible : vérifier le solde avant."""
    if jours_ouvres(debut, fin) > 10:
        raise ModelRetry("Plus de 10 jours ouvrés : ne pas enregistrer, répondre a_valider.")  # renvoyé au modèle
    return enregistrer(employe, debut, fin)

@agent.output_validator
def coherence(ctx: RunContext[Deps], sortie: DecisionConge) -> DecisionConge:
    if sortie.statut == "accepte" and sortie.jours > 10:
        raise ModelRetry("Incohérent : accepte avec plus de 10 jours. Corrigez le statut.")
    return sortie

if __name__ == "__main__":
    r = agent.run_sync("Je voudrais poser du 22 au 26 décembre 2026, Karim",
                       deps=Deps(societe="Menuiserie Dubois"),
                       usage_limits=UsageLimits(request_limit=8, total_tokens_limit=20_000))
    print(r.output)                                   # DecisionConge validé
    print("Usage :", r.usage())                       # requêtes, tokens entrée/sortie
```

**Ce qu'on aime** : `ModelRetry` transforme une règle métier en observation réinjectée (le modèle corrige), `output_validator` ferme la porte aux sorties incohérentes, les tests se font avec `TestModel` sans appel réseau, l'instrumentation OpenTelemetry (Logfire ou tout autre collecteur) est native, et `pydantic-evals` sert à évaluer. **Ce qu'il faut savoir** : pas d'outils « physiques » intégrés (fichiers, bash) ni de sandbox : vous les ajoutez vous-même ou via MCP (L099).

## 5. Grille de comparaison (nov. 2026)

| Critère | OpenAI Agents SDK | Claude Agent SDK | Pydantic AI |
|---|---|---|---|
| Philosophie | agents + handoffs + guardrails | « Claude Code sans terminal » : agent déjà outillé | typage de bout en bout, injection de dépendances |
| Langages | Python, TypeScript | Python, TypeScript | Python |
| Licence | MIT | SDK ouvert, usage sous Commercial Terms Anthropic | MIT |
| Portabilité modèles | OpenAI natif ; 100+ via LiteLLM | modèles Claude (API, Bedrock, Vertex, Foundry) | multi-fournisseurs natif (chaîne `fournisseur:modele`) |
| Outils intégrés | web search, file search, code interpreter, computer use (via Responses) | fichiers, bash, grep, web, MCP, sous-agents, skills | aucun (vous les écrivez ou MCP) |
| Sortie structurée | `output_type` (Pydantic / zod) | `output_format` JSON schema | `output_type` + `output_validator` + `ModelRetry` |
| Garde-fous | guardrails (tripwire), approvals | hooks (`PreToolUse`…), modes de permission | validators, `UsageLimits`, `ModelRetry` |
| Humain dans la boucle | approvals | permissions, hooks `PermissionRequest` | à implémenter (pause applicative) ou via LangGraph |
| Plafond de coût | `max_turns` | `max_turns`, `max_budget_usd` | `UsageLimits` (requêtes, tokens) |
| Observabilité | traces intégrées, exporteurs OTel | `cost-tracking`, `observability` (OTel) | OpenTelemetry / Logfire |
| Idéal pour | assistants conversationnels multi-agents, voix | agents qui manipulent fichiers, code, environnements | services typés, testables, multi-modèles |

Deux alternatives méritent une place dans votre veille : **Google ADK** ([docs](https://google.github.io/adk-docs/) ; Python, TS, Java, Go ; workflows en graphe, A2A natif, intégration Vertex AI) et **smolagents** de Hugging Face ([docs](https://huggingface.co/docs/smolagents) ; agents « code-acting » : le modèle écrit du Python exécuté dans un bac à sable au lieu d'émettre des appels JSON — élégant, mais à isoler sérieusement). Côté TypeScript pur, le **Vercel AI SDK** (`ai-sdk.dev`) couvre le streaming d'interface et des agents simples.

> ⚠️ **Piège fréquent** — Choisir un SDK pour sa démo YouTube. Les questions qui comptent : quel modèle demain ? qui valide les actions sensibles ? comment je teste sans appel réseau ? où sont les traces ? combien ça coûte à 10 000 exécutions ? Faites tourner **votre** cas (comme ici) dans deux SDK avant de trancher.

> 💡 **À retenir** — Les trois SDK implémentent la même boucle que L095. Ce qui les distingue, c'est où ils placent les garde-fous : dans des *guardrails* parallèles (OpenAI), dans des *hooks* et permissions (Anthropic), dans le *système de types* (Pydantic AI).

🎮 **Défi** — Une banque veut un agent qui lit des relevés PDF dans un dossier, les classe, et écrit un rapport, avec interdiction absolue d'accéder au réseau. Quel SDK, et quelle option clé ? *(Claude Agent SDK, `allowed_tools` limité à Read/Glob/Write sans WebSearch ni Bash, plus un hook qui refuse tout chemin hors du dossier ; ou Pydantic AI avec vos propres outils de lecture, si vous voulez pouvoir changer de modèle.)*

## 🧪 Exercice pratique

**Consigne.** Implémentez l'agent « demandes de congés » dans **deux** des trois SDK (au choix), puis :
1. Ajoutez un troisième outil `jours_feries(annee)` (liste fixe) et faites exclure les jours fériés du calcul.
2. Écrivez 5 cas de test communs (demande simple, solde insuffisant, > 10 jours, demande hors sujet, dates inversées) et exécutez-les dans les deux SDK ; consignez pour chacun : statut obtenu, tours, tokens ou coût.
3. Dans Pydantic AI, utilisez `TestModel` (ou un modèle de fonction) pour tester la logique sans appel API ; dans le Claude Agent SDK, vérifiez que le hook bloque bien un appel > 10 jours même si vous retirez la règle du prompt système.
4. Rédigez une page de recommandation (≤ 300 mots) pour la DRH : SDK retenu, pourquoi, risques, coût mensuel estimé pour 400 demandes.

**Critères de réussite.** Les 5 cas donnent le même statut dans les deux SDK ; aucun `poser_conge` n'est exécuté sur le cas > 10 jours ni sur le cas « solde insuffisant » ; la sortie est toujours un `DecisionConge` valide ; le coût par demande est chiffré et sourcé (pages Pricing).

<details>
<summary>Pistes</summary>

- Dates inversées : faites lever une erreur explicite par l'outil (« fin < début »), le modèle doit répondre `refuse` avec un message clair.
- Pour l'estimation de coût, journalisez `usage` sur 5 exécutions, prenez la moyenne, multipliez par 400.
- Si deux SDK divergent sur un cas, c'est presque toujours une description d'outil ou une instruction ambiguë : corrigez le texte, pas le code.
</details>

## ✅ Auto-évaluation express

1. Quel mécanisme, dans chaque SDK, empêche l'agent d'enregistrer un congé de 15 jours même si le modèle le « veut » ?
2. Quel SDK permet de changer de fournisseur de modèle en modifiant une seule chaîne de caractères ?
3. Qu'embarque le Claude Agent SDK que les deux autres n'embarquent pas ?

**Réponses.** 1. OpenAI : un guardrail ou une vérification dans l'outil ; Claude : un hook `PreToolUse` qui renvoie `deny` ; Pydantic AI : `ModelRetry` dans l'outil et/ou un `output_validator`. 2. Pydantic AI (`"anthropic:…"` → `"openai:…"`) ; l'Agents SDK le permet aussi via LiteLLM, avec un peu plus de configuration. 3. Les outils d'environnement (fichiers, bash, recherche web), les sous-agents, les skills et le système de permissions hérités de Claude Code.

## 📚 Pour aller plus loin
- [OpenAI Agents SDK — guide](https://developers.openai.com/api/docs/guides/agents/sdk) 🇬🇧 et [documentation Python](https://openai.github.io/openai-agents-python/) 🇬🇧 — agents, handoffs, guardrails, traçage, voix.
- [Claude Agent SDK — Custom tools](https://code.claude.com/docs/en/agent-sdk/custom-tools) 🇬🇧, [Hooks](https://code.claude.com/docs/en/agent-sdk/hooks) 🇬🇧, [Structured outputs](https://code.claude.com/docs/en/agent-sdk/structured-outputs) 🇬🇧 — les trois pages utilisées dans cette leçon.
- [Pydantic AI](https://ai.pydantic.dev) 🇬🇧 — documentation complète (agents, outils, dépendances, tests, évals, MCP).
- [Google ADK](https://google.github.io/adk-docs/) 🇬🇧 et [smolagents](https://huggingface.co/docs/smolagents) 🇬🇧 — deux alternatives à connaître (A2A natif ; agents « code-acting »).
- [Comparatif Composio](https://composio.dev/blog/claude-agents-sdk-vs-openai-agents-sdk-vs-google-adk) 🇬🇧 — lecture tierce, utile pour confronter notre grille.
