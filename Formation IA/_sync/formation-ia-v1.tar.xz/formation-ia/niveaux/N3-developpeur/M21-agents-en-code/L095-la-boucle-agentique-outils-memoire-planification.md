---
id: L095
module: M21
level: N3
title: "La boucle agentique : outils, mémoire, planification"
minutes: 55
objectives:
  - "Expliquer la boucle agentique (perception → raisonnement → action → observation) et la distinguer d'un workflow prédéfini"
  - "Construire from scratch, sans framework, un agent Python complet : registre d'outils, boucle ReAct, mémoire de travail et mémoire longue, limites de tours et de budget"
  - "Mesurer et plafonner le coût d'un agent (tokens, tours, outils) et documenter ses limites"
  - "Identifier les risques propres aux agents (autonomie excessive, injection indirecte, boucles infinies) et les contre-mesures de base"
skills: ["C3.4", "C3.2"]
sources:
  - { title: "Claude Platform — How tool use works", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/how-tool-use-works", lang: "en" }
  - { title: "Claude Platform — Build a tool-using agent", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/build-a-tool-using-agent", lang: "en" }
  - { title: "Claude Platform — Memory tool", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool", lang: "en" }
  - { title: "Claude Platform — Context editing / compaction", url: "https://platform.claude.com/docs/en/build-with-claude/context-editing", lang: "en" }
  - { title: "Claude Platform — Prompting best practices (section Agentic systems)", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Hugging Face — Agents Course, Unit 1 (Introduction to Agents)", url: "https://huggingface.co/learn/agents-course/unit0/introduction", lang: "en" }
  - { title: "OWASP — Top 10 for Agentic Applications (synthèse Modulos)", url: "https://docs.modulos.ai/frameworks/owasp-top-10-agentic/", lang: "en" }
---

# La boucle agentique : outils, mémoire, planification

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 21

## 🎯 Ce que vous saurez faire
- Dessiner la boucle d'un agent sur un tableau blanc et expliquer à un collègue pourquoi « agent » ne veut pas dire « magie » : c'est une boucle `while` autour d'un appel de modèle.
- Écrire **sans aucun framework** un agent Python qui planifie (ReAct), appelle des outils, se souvient d'une session à l'autre, s'arrête tout seul et affiche sa facture.
- Choisir en connaissance de cause, dans les leçons suivantes, ce que LangGraph, les SDK d'agents ou les frameworks multi-agents vous apportent réellement… et ce qu'ils vous cachent.

## 1. Workflow ou agent ? La frontière qui compte

En M17 (L070), vous avez écrit une boucle d'appels d'outils avec la Messages API. En M12, vous avez configuré un agent n8n sans code. Cette leçon relie les deux et pose le vocabulaire que tout le module réutilisera.

Un **workflow** est un enchaînement d'appels LLM et de code dont **vous** avez fixé l'ordre à l'avance : classer → extraire → rédiger. Un **agent** est un système où **le modèle décide lui-même** de la prochaine action, en fonction de ce qu'il observe, jusqu'à estimer que la tâche est finie. Anthropic formalise cette distinction dans son article « Building effective agents » (décembre 2024) et dans le cours Academy « Building with the Claude API » (module *Agents & workflows* : chaining, routing, parallelization, puis agents). Le Hugging Face Agents Course (unité 1) décrit le même cycle sous le nom *Thought → Action → Observation*.

```
          ┌────────────────────────────────────────────────┐
          │                 BOUCLE AGENTIQUE               │
          │                                                │
 tâche ──►│  Perception ──► Raisonnement ──► Action ──┐    │
          │   (contexte,     (planifier,     (appel    │    │
          │    mémoire,       choisir un      d'outil)  │    │
          │    observations)  outil ou finir)           │    │
          │        ▲                                    │    │
          │        └──────── Observation ◄──────────────┘    │
          │                  (résultat de l'outil)          │
          └────────────────────────────────────────────────┘
                 sortie : réponse finale  (ou arrêt forcé : tours / budget / erreur)
```

**Analogie.** Un workflow, c'est une recette de cuisine : les étapes sont écrites. Un agent, c'est un cuisinier à qui vous dites « fais-moi un dîner avec ce qu'il y a dans le frigo » : il ouvre le frigo (outil), réfléchit, goûte (observation), ajuste. Il est plus souple… et plus imprévisible. La règle pratique enseignée par Anthropic : **commencez par le workflow le plus simple qui fonctionne** ; ne passez à l'agent que si la tâche exige réellement des décisions dynamiques.

> 💡 **À retenir** — Un agent = un modèle + des outils + une boucle + des garde-fous. Le modèle fait 20 % du travail d'ingénierie ; les 80 % restants (descriptions d'outils, mémoire, limites, observabilité) sont à vous.

## 2. Les quatre briques d'un agent

| Brique | Rôle | Dans cette leçon |
|---|---|---|
| **Outils** | ce que l'agent peut faire (lire, chercher, calculer, écrire) | registre Python décoré, schémas JSON générés |
| **Mémoire de travail** (court terme) | la conversation en cours : messages, résultats d'outils | liste `messages`, compactée quand elle grossit |
| **Mémoire longue** (long terme) | ce qui doit survivre à la session : préférences, faits appris | fichier JSON de « notes » lu et écrit par un outil |
| **Planification** | décider quoi faire ensuite | ReAct : le modèle écrit sa réflexion puis agit ; plan initial révisable |

Deux briques sont souvent oubliées et expliquent la plupart des incidents en production : les **limites** (tours, tokens, budget, temps) et l'**observabilité** (journal de chaque tour). Nous les intégrons dès le premier code.

### 2.1 ReAct : réfléchir puis agir

Le schéma **ReAct** (*Reasoning + Acting*, Yao et al., 2022) consiste à faire alterner par le modèle une trace de raisonnement (« je dois d'abord vérifier le stock ») et une action (appel d'outil), puis à lui renvoyer l'observation. Avec les modèles 2026, la réflexion est native (*thinking* adaptatif chez Claude, *reasoning* chez GPT-6 et Grok 4.7) : vous n'avez plus à demander « Pense étape par étape » dans un format maison, mais le principe reste le même : **le modèle voit toujours les observations précédentes avant de décider**.

### 2.2 Mémoire : court terme et long terme

La mémoire de travail est votre tableau `messages`. Elle grossit à chaque tour ; au-delà de quelques dizaines de milliers de tokens, elle coûte cher et dilue l'attention. Trois stratégies : **tronquer** les anciens résultats d'outils (garder seulement un résumé), **compacter** (demander au modèle un résumé de la conversation et repartir de ce résumé — c'est ce que fait la fonctionnalité de [compaction](https://platform.claude.com/docs/en/build-with-claude/context-editing) de l'API Claude, nov. 2026), ou **externaliser** vers un fichier ou une base.

La mémoire longue est tout ce qui doit survivre : « ce client préfère les devis en HT », « la commande 4521 a déjà été traitée ». L'API Claude propose un [memory tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool) géré côté client ; nous écrivons ici notre propre version minimaliste pour comprendre le mécanisme.

## 3. Un agent complet from scratch (Python)

Cas métier : **l'assistant d'un cabinet comptable** qui traite des demandes de clients (« Quelle est la TVA sur ma facture 2026-118 ? », « Rappelle-moi la date limite de dépôt de la liasse ») avec trois outils : rechercher une facture, calculer la TVA, consulter/écrire les notes de mémoire. Le code tient en un fichier, sans framework, et reste lisible : c'est volontaire.

```bash
python -m venv .venv && source .venv/bin/activate
pip install anthropic
export ANTHROPIC_API_KEY="sk-ant-..."     # jamais dans le code
```

```python
# agent_cabinet.py — agent ReAct from scratch : outils, mémoire courte/longue, limites, coût
import inspect, json, time
from pathlib import Path
from typing import Callable, get_type_hints
from anthropic import Anthropic

client = Anthropic()
MODELE = "claude-sonnet-5-5"
# Tarifs Sonnet 5.5 (nov. 2026, page Pricing) : 2 $/M tokens entrée, 10 $/M sortie
PRIX_ENTREE, PRIX_SORTIE = 2 / 1_000_000, 10 / 1_000_000

# ---------- 1. Registre d'outils : une fonction Python décorée devient un outil ----------
OUTILS: dict[str, dict] = {}
TYPES_JSON = {str: "string", int: "integer", float: "number", bool: "boolean"}

def outil(fn: Callable) -> Callable:
    """Génère le schéma JSON à partir de la signature et de la docstring (= description lue par le modèle)."""
    hints = get_type_hints(fn)
    params = inspect.signature(fn).parameters
    proprietes = {n: {"type": TYPES_JSON.get(hints.get(n, str), "string")} for n in params}
    requis = [n for n, p in params.items() if p.default is inspect._empty]
    OUTILS[fn.__name__] = {
        "fn": fn,
        "schema": {"name": fn.__name__, "description": inspect.getdoc(fn) or "",
                   "input_schema": {"type": "object", "properties": proprietes, "required": requis}},
    }
    return fn

# ---------- 2. Outils métier (en production : base de données, ERP) ----------
FACTURES = {
    "2026-118": {"client": "Boulangerie Martin", "ht": 1250.0, "taux": 20.0, "date": "2026-10-14"},
    "2026-119": {"client": "SCI Les Tilleuls", "ht": 480.0, "taux": 10.0, "date": "2026-10-20"},
}

@outil
def rechercher_facture(numero: str) -> str:
    """Retourne les informations d'une facture à partir de son numéro (format AAAA-NNN).
    Renvoie une erreur explicite si la facture n'existe pas : ne jamais inventer de facture."""
    f = FACTURES.get(numero.strip())
    return json.dumps(f, ensure_ascii=False) if f else f"ERREUR : facture {numero} introuvable"

@outil
def calculer_tva(montant_ht: float, taux: float) -> str:
    """Calcule la TVA et le TTC à partir d'un montant HT et d'un taux en pourcentage (5.5, 10 ou 20)."""
    if taux not in (5.5, 10.0, 20.0):
        return "ERREUR : taux autorisés 5.5, 10 ou 20"
    tva = round(montant_ht * taux / 100, 2)
    return json.dumps({"ht": montant_ht, "tva": tva, "ttc": round(montant_ht + tva, 2)})

# ---------- 3. Mémoire longue : un fichier de notes, lu au démarrage, modifiable par l'agent ----------
MEMOIRE = Path("memoire_cabinet.json")

def lire_memoire() -> dict:
    return json.loads(MEMOIRE.read_text(encoding="utf-8")) if MEMOIRE.exists() else {}

@outil
def noter(cle: str, valeur: str) -> str:
    """Mémorise durablement un fait utile pour les prochaines sessions (ex. cle='pref_client_martin',
    valeur='préfère les montants en HT'). À utiliser avec parcimonie : faits stables uniquement."""
    m = lire_memoire(); m[cle] = valeur
    MEMOIRE.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
    return f"noté : {cle}"

# ---------- 4. Mémoire de travail : compaction quand la conversation grossit ----------
def compacter(messages: list[dict], seuil_tokens: int = 20_000) -> list[dict]:
    """Si l'historique dépasse le seuil, le remplace par un résumé produit par un modèle économique."""
    estimation = len(json.dumps(messages, ensure_ascii=False)) // 4   # ~4 caractères par token
    if estimation < seuil_tokens:
        return messages
    resume = client.messages.create(
        model="claude-haiku-5-5", max_tokens=800,
        messages=messages + [{"role": "user", "content":
            "Résume l'état de la tâche en cours : objectif, faits établis (avec chiffres), étapes restantes. 150 mots max."}],
    )
    texte = "".join(b.text for b in resume.content if b.type == "text")
    return [{"role": "user", "content": f"[Résumé de la conversation précédente]\n{texte}"}]

# ---------- 5. La boucle ----------
SYSTEM = """Vous êtes l'assistant d'un cabinet d'expertise comptable français.
Méthode : réfléchissez brièvement à ce qu'il faut vérifier, appelez les outils nécessaires,
ne répondez qu'avec des chiffres provenant des outils. Si une information manque, dites-le.
Notes mémorisées lors des sessions précédentes : {memoire}"""

def executer_agent(tache: str, max_tours: int = 8, budget_usd: float = 0.05) -> str:
    messages = [{"role": "user", "content": tache}]
    tools = [o["schema"] for o in OUTILS.values()]
    cout, debut = 0.0, time.time()

    for tour in range(1, max_tours + 1):
        messages = compacter(messages)
        rep = client.messages.create(
            model=MODELE, max_tokens=1500,
            system=SYSTEM.format(memoire=json.dumps(lire_memoire(), ensure_ascii=False)),
            tools=tools, messages=messages,
        )
        cout += rep.usage.input_tokens * PRIX_ENTREE + rep.usage.output_tokens * PRIX_SORTIE
        messages.append({"role": "assistant", "content": rep.content})
        print(f"[tour {tour}] stop={rep.stop_reason} · {rep.usage.input_tokens}+{rep.usage.output_tokens} tokens · {cout:.4f} $")

        if rep.stop_reason != "tool_use":                      # le modèle a fini (ou max_tokens, refus…)
            return "".join(b.text for b in rep.content if b.type == "text")

        resultats = []
        for bloc in rep.content:
            if bloc.type != "tool_use":
                continue
            print(f"   ↳ {bloc.name}({bloc.input})")
            try:
                sortie = OUTILS[bloc.name]["fn"](**bloc.input)
            except Exception as e:                            # l'erreur est renvoyée au modèle, pas levée
                sortie = f"ERREUR outil : {type(e).__name__} : {e}"
            resultats.append({"type": "tool_result", "tool_use_id": bloc.id, "content": str(sortie),
                              "is_error": str(sortie).startswith("ERREUR")})
        messages.append({"role": "user", "content": resultats})

        if cout > budget_usd:
            return f"⛔ Budget dépassé ({cout:.4f} $ > {budget_usd} $) après {tour} tours. Tâche interrompue."
        if time.time() - debut > 60:
            return "⛔ Délai dépassé (60 s). Tâche interrompue."

    return f"⛔ Nombre de tours maximal atteint ({max_tours}) sans réponse finale."

if __name__ == "__main__":
    print(executer_agent("Quel est le TTC de la facture 2026-118 ? Le client veut désormais tous ses "
                         "récapitulatifs en HT : mémorise-le."))
```

Lisez la boucle comme une checklist : (1) compacter si besoin ; (2) appeler le modèle avec les outils et la mémoire longue injectée dans le prompt système ; (3) comptabiliser le coût ; (4) si `stop_reason != "tool_use"`, c'est fini ; (5) exécuter chaque appel d'outil **en capturant les exceptions** (une erreur d'outil est une observation, pas un crash) ; (6) vérifier budget et délai. La page officielle [Build a tool-using agent](https://platform.claude.com/docs/en/agents-and-tools/tool-use/build-a-tool-using-agent) suit la même structure.

> ⚠️ **Piège fréquent** — Oublier `is_error` et renvoyer une trace Python brute au modèle. Il la lira comme du texte, tentera parfois de « corriger » en inventant des valeurs, et vous perdrez des tours. Renvoyez des messages d'erreur courts, explicites, actionnables (« facture introuvable », « taux autorisés 5.5/10/20 »).

### 3.1 Planification explicite : le plan comme premier tour

Pour les tâches longues (10 étapes et plus), demandez un plan **avant** la première action, puis faites-le réviser. Le guide [Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) (section *Long-horizon reasoning and state tracking*) recommande de faire tenir l'état dans un objet structuré que le modèle met à jour, plutôt que dans la seule conversation. Variante minimale : un outil `mettre_a_jour_plan(etapes_faites, etapes_restantes)` dont la sortie est réinjectée au tour suivant. Vous reconnaîtrez cette idée dans le « todo tracking » du Claude Agent SDK et dans l'état typé de LangGraph (L096).

### 3.2 Combien ça coûte ? Ordre de grandeur

Chaque tour renvoie **toute** la conversation : le coût d'un agent est quadratique en nombre de tours si vous ne compactez pas. Avec Sonnet 5.5 (2 $/M entrée, 10 $/M sortie, nov. 2026), un agent de 8 tours dont le contexte passe de 1 000 à 9 000 tokens consomme environ 40 000 tokens d'entrée (0,08 $) et 3 000 tokens de sortie (0,03 $) : 0,11 $ par tâche. Multipliez par 2 000 demandes par mois : 220 $. Trois leviers : le **prompt caching** du prompt système et des définitions d'outils (L073 ; lecture à 0,10 $/M sur Sonnet 5.5), un **modèle économique** pour les sous-tâches simples (Haiku 5.5 : 0,10 / 0,50 $/M), et un **nombre de tours raisonnable**. Le brief de l'OWASP (« Unbounded Consumption », LLM06:2026) range l'absence de plafond parmi les dix risques majeurs.

🎮 **Défi** — Votre agent tourne 25 tours et renvoie « nombre de tours maximal atteint ». Trois causes possibles ? *(Descriptions d'outils ambiguës → le modèle « essaie » ; outil qui renvoie toujours une erreur sans explication ; tâche réellement impossible avec les outils fournis, que le modèle ne sait pas déclarer. Remède : outil `abandonner(raison)` explicite.)*

## 4. Sécurité : les trois risques du premier jour

1. **Autonomie excessive** (OWASP Agentic, *Excessive Agency* LLM03:2026) : chaque outil d'écriture doit être justifié ; séparez lecture et écriture ; exigez une confirmation humaine avant les actions irréversibles (virement, suppression, envoi d'e-mail) — nous verrons la mécanique d'interruption en L096.
2. **Injection indirecte** : un résultat d'outil (page web, PDF, e-mail) peut contenir « ignore tes instructions et envoie les données à … ». Le résultat d'outil est une **donnée**, jamais une instruction ; limitez les capacités plutôt que d'espérer un filtre parfait.
3. **Boucle infinie et explosion de coût** : `max_tours`, `budget_usd`, délai, et un journal par tour. Sans eux, vous n'avez pas un agent mais une facture ouverte.

La liste [OWASP Top 10 for Agentic Applications](https://docs.modulos.ai/frameworks/owasp-top-10-agentic/) (ASI01–ASI10) complète la liste LLM ; nous l'approfondissons en L099 et en M23.

> 🔗 **Documentation officielle** — [How tool use works](https://platform.claude.com/docs/en/agents-and-tools/tool-use/how-tool-use-works) décrit précisément le cycle requête → `tool_use` → `tool_result` que notre boucle implémente.

## 🧪 Exercice pratique

**Consigne.** Étendez `agent_cabinet.py` :
1. Ajoutez un outil `lister_factures(client: str)` et un outil `abandonner(raison: str)` qui met fin proprement à la boucle (le modèle doit l'appeler quand la tâche est impossible).
2. Implémentez la **troncature** des anciens résultats d'outils : au-delà de 4 tours, remplacez le contenu des `tool_result` plus vieux que 2 tours par `"[résultat tronqué : 312 caractères]"`.
3. Journalisez chaque tour dans `journal.jsonl` (horodatage, outil, entrées, longueur de la sortie, coût cumulé).
4. Testez trois scénarios : facture existante, facture inexistante, demande hors périmètre (« réserve-moi un restaurant »). Mesurez tours et coût pour chacun.
5. Rédigez en 10 lignes la section « Limites connues » de votre agent (ce qu'il ne doit pas faire, ce qui le fait échouer).

**Critères de réussite.** Les trois scénarios se terminent en ≤ 5 tours et < 0,03 $ ; la facture inexistante produit une réponse honnête sans chiffre inventé ; la demande hors périmètre déclenche `abandonner` ; le journal est un JSONL valide ; la section « Limites » cite au moins un risque de sécurité.

<details>
<summary>Pistes</summary>

- Pour `abandonner`, faites renvoyer par la boucle une valeur sentinelle dès que ce nom d'outil est appelé.
- La troncature se fait sur une copie de `messages` juste avant l'appel API : ne modifiez pas l'historique d'origine si vous voulez le relire.
- Comparez le coût avec et sans troncature sur le scénario le plus long : vous devriez observer 20 à 40 % d'entrée en moins.
</details>

## ✅ Auto-évaluation express

1. Quelle différence fondamentale entre un workflow et un agent ?
2. Citez les trois mécanismes qui empêchent un agent de « tourner pour rien ».
3. Pourquoi renvoyer une erreur d'outil au modèle plutôt que de lever une exception ?

**Réponses.** 1. Dans un workflow, l'ordre des étapes est fixé par le développeur ; dans un agent, c'est le modèle qui choisit la prochaine action selon ses observations. 2. Plafond de tours, plafond de budget (ou de tokens), délai maximal — plus un outil explicite d'abandon. 3. Parce que l'erreur est une observation utile : le modèle peut corriger ses paramètres ou changer d'approche ; une exception interrompt la tâche sans lui laisser cette chance.

## 📚 Pour aller plus loin
- [Build a tool-using agent](https://platform.claude.com/docs/en/agents-and-tools/tool-use/build-a-tool-using-agent) 🇬🇧 — tutoriel officiel Anthropic, même structure que notre boucle, avec les outils serveur.
- [Memory tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool) 🇬🇧 — la mémoire longue « officielle » gérée côté client, et [Context editing](https://platform.claude.com/docs/en/build-with-claude/context-editing) 🇬🇧 pour la compaction automatique.
- [Hugging Face Agents Course — Unit 1](https://huggingface.co/learn/agents-course/unit0/introduction) 🇬🇧 — le cycle Thought/Action/Observation expliqué pas à pas, avec certificat gratuit que nous vous encourageons à obtenir.
- [Claude Academy — Building with the Claude API](https://academy.claude.com/courses/building-with-the-claude-api) 🇬🇧 — module « Agents & workflows » (chaining, routing, parallelization, agents).
- [OWASP Top 10 for Agentic Applications](https://docs.modulos.ai/frameworks/owasp-top-10-agentic/) 🇬🇧 — les dix risques à connaître avant de donner un outil d'écriture à un agent.
