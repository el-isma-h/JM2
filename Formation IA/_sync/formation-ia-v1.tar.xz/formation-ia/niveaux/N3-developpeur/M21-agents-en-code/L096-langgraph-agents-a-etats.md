---
id: L096
module: M21
level: N3
title: "LangGraph : agents à états"
minutes: 55
objectives:
  - "Modéliser un agent comme un graphe à états (nœuds, arêtes conditionnelles, état typé, réducteurs) et expliquer ce que ce modèle apporte par rapport à une boucle libre"
  - "Construire avec LangGraph 1.x un agent ReAct complet avec persistance (checkpointer), reprise de session (thread_id) et mémoire longue (store)"
  - "Implémenter l'humain dans la boucle : interruption avant une action sensible, validation ou modification, reprise"
  - "Appliquer les bonnes pratiques de production : délais par nœud, gestion d'erreurs, traçage"
skills: ["C3.4"]
sources:
  - { title: "LangChain Docs — LangGraph overview", url: "https://docs.langchain.com/oss/python/langgraph/overview", lang: "en" }
  - { title: "LangChain Docs — Changelog (LangGraph 1.2, LangChain 1.4)", url: "https://docs.langchain.com/oss/python/releases/changelog.md", lang: "en" }
  - { title: "LangChain Docs — accueil", url: "https://docs.langchain.com", lang: "en" }
  - { title: "LangSmith (traçage et évaluation)", url: "https://smith.langchain.com", lang: "en" }
  - { title: "Claude Platform — Tool use overview", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview", lang: "en" }
  - { title: "DeepLearning.AI — AI Agents in LangGraph", url: "https://www.deeplearning.ai/courses/ai-agents-in-langgraph", lang: "en" }
  - { title: "Hugging Face — Agents Course (unité 2.3 LangGraph)", url: "https://huggingface.co/learn/agents-course/unit0/introduction", lang: "en" }
---

# LangGraph : agents à états

> ⏱ 55 min · 🎯 Niveau 3 · 📚 Module 21

## 🎯 Ce que vous saurez faire
- Traduire la boucle libre de L095 en un **graphe** dont chaque nœud est testable et chaque transition explicite.
- Rendre un agent **persistant** : il s'arrête, redémarre, reprend exactement où il en était, sur la même conversation, des jours plus tard.
- Mettre un **humain dans la boucle** sans bricolage : l'agent se suspend avant une action sensible, un collaborateur valide, l'agent reprend.
- Savoir quand LangGraph est le bon outil… et quand la boucle de 60 lignes de L095 suffit.

## 1. Pourquoi un graphe ?

La boucle de L095 a une faiblesse : tout est implicite. Où en est l'agent ? Dans une liste de messages. Que se passe-t-il si le processus meurt au tour 6 ? Tout est perdu. Comment interrompre avant un virement ? Il faut bricoler un `if`. Comment tester le nœud « chiffrer » seul ? Impossible sans relancer tout.

**LangGraph** (LangChain Inc., licence MIT, v1.2.0 publiée le 12 mai 2026 d'après le [changelog officiel](https://docs.langchain.com/oss/python/releases/changelog.md)) propose de décrire un agent comme une **machine à états** : un **état** typé (un dictionnaire dont vous déclarez les champs), des **nœuds** (fonctions qui lisent l'état et renvoient une mise à jour), des **arêtes** (fixes ou conditionnelles). Le moteur exécute le graphe, **sauvegarde l'état après chaque nœud** (checkpointer) et sait se suspendre et reprendre.

```
        ┌────────┐      tool_calls ?      ┌────────┐
START ─►│ agent  │ ──── oui ────────────► │ outils │
        │ (LLM)  │ ◄───────────────────── │        │
        └───┬────┘                        └────────┘
            │ non
            ▼
           END          état = {messages: [...], etapes: 3, valide_par_humain: false}
```

**Analogie.** La boucle de L095 est un trajet improvisé ; le graphe est le plan du métro : les stations (nœuds) sont nommées, les correspondances (arêtes) sont connues, et si vous descendez à une station, vous pouvez reprendre le lendemain au même endroit. Vous perdez un peu de liberté, vous gagnez la reproductibilité.

> 💡 **À retenir** — LangGraph ne « rend pas l'agent plus intelligent » : le modèle décide toujours. Il rend l'**exécution** observable, persistante et interruptible. C'est de l'ingénierie, pas de l'IA.

## 2. Premier graphe : l'agent ReAct en 50 lignes

Cas métier : **le gestionnaire de réclamations d'un e-commerçant** (« ma commande 7731 est arrivée cassée »). Outils : consulter une commande, créer un avoir. La création d'avoir est une action sensible : nous l'isolerons en section 4.

```bash
pip install -U langgraph langchain langchain-anthropic
export ANTHROPIC_API_KEY="sk-ant-..."
```

```python
# reclamations_graph.py — agent ReAct avec LangGraph : état typé, nœud agent, nœud outils, arête conditionnelle
import json
from typing import Annotated, TypedDict
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import SystemMessage
from langchain_core.tools import tool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

COMMANDES = {"7731": {"client": "Mme Leroy", "article": "Lampe Nordica", "montant_ttc": 89.90, "statut": "livrée"}}

@tool
def consulter_commande(numero: str) -> str:
    """Retourne les informations d'une commande (client, article, montant TTC, statut) à partir de son numéro."""
    c = COMMANDES.get(numero)
    return json.dumps(c, ensure_ascii=False) if c else f"ERREUR : commande {numero} introuvable"

@tool
def creer_avoir(numero: str, montant: float, motif: str) -> str:
    """Crée un avoir (remboursement partiel ou total) sur une commande. Action irréversible :
    n'appeler qu'après avoir vérifié la commande et le montant."""
    return f"Avoir de {montant:.2f} € créé sur la commande {numero} (motif : {motif})."

OUTILS = [consulter_commande, creer_avoir]

# ---- 1. L'état : un TypedDict ; `add_messages` est un réducteur qui AJOUTE au lieu de remplacer ----
class Etat(TypedDict):
    messages: Annotated[list, add_messages]
    nb_appels_outils: int

# ---- 2. Les nœuds ----
llm = ChatAnthropic(model="claude-sonnet-5-5", max_tokens=1200).bind_tools(OUTILS)
SYSTEM = SystemMessage("Vous êtes le service réclamations d'une boutique en ligne française. "
                       "Vérifiez toujours la commande avant de proposer un geste commercial. "
                       "Un avoir ne dépasse jamais le montant TTC de la commande.")

def noeud_agent(etat: Etat) -> dict:
    reponse = llm.invoke([SYSTEM] + etat["messages"])
    return {"messages": [reponse]}                      # mise à jour partielle : le réducteur fusionne

def noeud_outils_compte(etat: Etat) -> dict:
    return {"nb_appels_outils": etat.get("nb_appels_outils", 0) + 1}

def doit_continuer(etat: Etat) -> str:
    dernier = etat["messages"][-1]
    if getattr(dernier, "tool_calls", None):
        if etat.get("nb_appels_outils", 0) >= 6:        # limite de tours, comme en L095
            return "fin"
        return "outils"
    return "fin"

# ---- 3. Le graphe ----
g = StateGraph(Etat)
g.add_node("agent", noeud_agent)
g.add_node("outils", ToolNode(OUTILS))                   # nœud prêt à l'emploi : exécute les tool_calls
g.add_node("compteur", noeud_outils_compte)
g.add_edge(START, "agent")
g.add_conditional_edges("agent", doit_continuer, {"outils": "outils", "fin": END})
g.add_edge("outils", "compteur")
g.add_edge("compteur", "agent")
graphe = g.compile()

if __name__ == "__main__":
    final = graphe.invoke({"messages": [("user", "Ma commande 7731 est arrivée cassée, je veux un remboursement.")],
                           "nb_appels_outils": 0})
    print(final["messages"][-1].content)
    print("Appels d'outils :", final["nb_appels_outils"])
```

Trois points à retenir du code. **Le réducteur** `add_messages` : sans lui, renvoyer `{"messages": [reponse]}` *remplacerait* l'historique ; avec lui, il s'y ajoute. **`ToolNode`** fait exactement ce que faisait notre boucle `for bloc in rep.content` en L095 (exécution, capture d'erreur, création des `ToolMessage`). **L'arête conditionnelle** est la ligne `if rep.stop_reason != "tool_use"` devenue une fonction nommée, testable isolément.

Le même agent s'écrit en une ligne avec le constructeur prêt à l'emploi de LangChain 1.x (`create_agent` dans le paquet `langchain`, qui succède au `create_react_agent` de LangGraph) — pratique pour prototyper, mais vous perdez la visibilité sur les nœuds. Le [changelog](https://docs.langchain.com/oss/python/releases/changelog.md) documente cette transition ; vérifiez les noms exacts pour votre version (langchain 1.4.6 / LangGraph 1.2.0 en nov. 2026).

## 3. Persistance : le checkpointer et le `thread_id`

Un graphe compilé avec un **checkpointer** sauvegarde l'état après chaque nœud, par conversation (`thread_id`). Conséquences : reprise après crash, conversations multi-sessions, « voyage dans le temps » (rejouer depuis un checkpoint), et surtout… l'interruption humaine de la section 4.

```python
# persistance.py — même graphe, avec sauvegarde SQLite et reprise de conversation
from langgraph.checkpoint.sqlite import SqliteSaver          # pip install langgraph-checkpoint-sqlite
from reclamations_graph import g                             # le StateGraph non compilé

with SqliteSaver.from_conn_string("reclamations.db") as checkpointer:
    graphe = g.compile(checkpointer=checkpointer)
    config = {"configurable": {"thread_id": "client-leroy-7731"}}   # 1 thread = 1 conversation

    graphe.invoke({"messages": [("user", "Ma commande 7731 est arrivée cassée.")], "nb_appels_outils": 0}, config)
    # ... le processus peut s'arrêter ici ; le lendemain :
    rep = graphe.invoke({"messages": [("user", "Finalement je préfère un avoir de 30 € plutôt qu'un retour.")]}, config)
    print(rep["messages"][-1].content)

    instantane = graphe.get_state(config)                    # état courant + prochain nœud à exécuter
    print("Prochain nœud :", instantane.next, "· messages :", len(instantane.values["messages"]))
```

En développement, `InMemorySaver` (module `langgraph.checkpoint.memory`) suffit ; en production, SQLite pour un service mono-instance, Postgres (`langgraph-checkpoint-postgres`) pour plusieurs instances. La **mémoire longue** (faits partagés entre threads : « Mme Leroy est cliente depuis 2019 ») passe par un **store** (`InMemoryStore` ou un store Postgres), passé à `compile(store=...)` et accessible dans les nœuds ; c'est l'équivalent structuré du fichier `memoire_cabinet.json` de L095.

> ⚠️ **Piège fréquent** — Utiliser le même `thread_id` pour tous les utilisateurs (« principal »). Les conversations se mélangent, les données personnelles fuient d'un client à l'autre (OWASP LLM02:2026). Un `thread_id` = un utilisateur × une conversation, et une politique de purge (RGPD : durée de conservation).

## 4. L'humain dans la boucle : `interrupt` et `Command`

Créer un avoir est irréversible. Nous voulons que l'agent **se suspende** avant, qu'un gestionnaire valide (ou corrige le montant), puis que l'agent **reprenne**. LangGraph fournit `interrupt()` : appelé dans un nœud, il arrête l'exécution, persiste l'état (checkpointer obligatoire) et renvoie une charge utile à l'application ; la reprise se fait avec `Command(resume=...)`.

```python
# humain_dans_la_boucle.py — validation humaine avant toute création d'avoir
import json
from langchain_core.messages import ToolMessage
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode
from langgraph.types import interrupt, Command
from reclamations_graph import Etat, noeud_agent, consulter_commande, creer_avoir

def noeud_validation(etat: Etat) -> dict:
    """Si le dernier message demande creer_avoir, suspend le graphe et attend la décision humaine."""
    dernier = etat["messages"][-1]
    mises_a_jour = []
    for appel in dernier.tool_calls:
        if appel["name"] != "creer_avoir":
            continue
        decision = interrupt({                                  # ← le graphe s'arrête ICI
            "question": "Valider cet avoir ?",
            "proposition": appel["args"],
        })
        if not decision.get("approuve"):
            mises_a_jour.append(ToolMessage(tool_call_id=appel["id"],
                                            content="REFUSÉ par le gestionnaire : " + decision.get("motif", "")))
        elif "montant" in decision:                              # l'humain peut corriger le montant
            appel["args"]["montant"] = decision["montant"]
    return {"messages": mises_a_jour} if mises_a_jour else {}

def router(etat: Etat) -> str:
    dernier = etat["messages"][-1]
    if not getattr(dernier, "tool_calls", None):
        return "fin"
    return "validation" if any(a["name"] == "creer_avoir" for a in dernier.tool_calls) else "outils"

g = StateGraph(Etat)
g.add_node("agent", noeud_agent)
g.add_node("validation", noeud_validation)
g.add_node("outils", ToolNode([consulter_commande, creer_avoir]))
g.add_edge(START, "agent")
g.add_conditional_edges("agent", router, {"validation": "validation", "outils": "outils", "fin": END})
g.add_edge("validation", "outils")
g.add_edge("outils", "agent")
graphe = g.compile(checkpointer=InMemorySaver())

config = {"configurable": {"thread_id": "demo-avoir"}}
resultat = graphe.invoke({"messages": [("user", "Commande 7731 cassée, faites un avoir intégral.")],
                          "nb_appels_outils": 0}, config)

if "__interrupt__" in resultat:                                  # le graphe est suspendu
    demande = resultat["__interrupt__"][0].value
    print("⏸ Validation demandée :", json.dumps(demande, ensure_ascii=False))
    # ... ici : notification Slack, formulaire web, file d'attente. Simulation d'une décision :
    decision = {"approuve": True, "montant": 60.0}              # le gestionnaire réduit à 60 €
    resultat = graphe.invoke(Command(resume=decision), config)   # reprise exactement au point d'arrêt

print(resultat["messages"][-1].content)
```

Ce schéma couvre les trois besoins classiques : **approuver / refuser**, **corriger** les paramètres, et **différer** (la reprise peut avoir lieu dans un autre processus, des heures plus tard, grâce au checkpointer). Le refus devient un `ToolMessage` : le modèle lit « REFUSÉ » comme une observation et propose autre chose, exactement comme une erreur d'outil en L095.

🎮 **Défi** — Le gestionnaire met 3 jours à répondre. Que doit faire votre application le 4ᵉ jour ? *(Un délai d'expiration applicatif : relancer le thread avec `Command(resume={"approuve": False, "motif": "délai de validation dépassé"})` et notifier le client ; LangGraph ne le fera pas à votre place.)*

## 5. Production : délais, erreurs, traces

- **Délais et erreurs par nœud** : LangGraph 1.2 (mai 2026) a introduit des *timeouts* et une gestion d'erreur configurables **par nœud** ([changelog](https://docs.langchain.com/oss/python/releases/changelog.md)) : un outil ERP qui ne répond pas ne bloque plus tout le graphe. Vérifiez la syntaxe exacte dans la documentation de votre version.
- **Traçage** : avec `LANGSMITH_TRACING=true` et une clé, chaque exécution est tracée dans [LangSmith](https://smith.langchain.com) (nœuds, tokens, latence). Des alternatives ouvertes (Langfuse, Arize Phoenix via OpenTelemetry) sont vues en M22.
- **Streaming** : `graphe.stream(..., stream_mode="updates")` renvoie les mises à jour nœud par nœud — indispensable pour afficher « l'agent consulte la commande… » dans une interface.
- **Tests** : chaque nœud est une fonction pure (état → mise à jour) : testez-la avec un état fabriqué, sans appel API, puis testez le routage.

| Besoin | Boucle maison (L095) | LangGraph |
|---|---|---|
| Prototype en 1 h, 3 outils | ✅ | surdimensionné |
| Reprise après crash, multi-sessions | à coder | ✅ checkpointer |
| Validation humaine avant action | `if` + base maison | ✅ `interrupt` / `Command` |
| Plusieurs chemins (routage, parallélisme, sous-graphes) | spaghetti rapide | ✅ nœuds et arêtes |
| Dépendances | `anthropic` seulement | `langgraph`, `langchain-*` (mises à jour fréquentes) |

> 🔗 **Documentation officielle** — [LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview) : concepts (state, nodes, edges, persistence, human-in-the-loop, streaming) avec exemples Python et JavaScript.

## 🧪 Exercice pratique

**Consigne.** Construisez l'agent **« onboarding RH »** d'une PME : un nouveau salarié arrive, l'agent doit (1) créer son compte e-mail, (2) commander son ordinateur, (3) planifier le rendez-vous d'accueil. Outils simulés : `creer_compte(prenom, nom)`, `commander_materiel(modele, budget)`, `planifier_rdv(date)`.
1. État typé avec `messages`, `etapes_faites: list[str]` (réducteur qui concatène) et `budget_restant: float`.
2. `commander_materiel` est sensible si `budget > 1500` : nœud de validation avec `interrupt`, l'humain peut réduire le budget.
3. Checkpointer SQLite ; démontrez une reprise dans un second processus (deux scripts : `lancer.py` et `reprendre.py`).
4. Limite : 10 appels d'outils ; au-delà, nœud `fin_forcee` qui résume ce qui a été fait et ce qui reste.
5. Streaming des mises à jour dans la console, avec le nom du nœud.

**Critères de réussite.** Le graphe s'interrompt sur une commande à 1 800 €, reprend avec 1 400 € ; `etapes_faites` contient les trois étapes dans l'ordre à la fin ; le second processus reprend sans rejouer les étapes déjà faites ; les tests unitaires du routeur passent sans appel API.

<details>
<summary>Pistes</summary>

- Réducteur de liste : `Annotated[list[str], lambda a, b: a + b]`.
- Pour vérifier la reprise, affichez `graphe.get_state(config).values["etapes_faites"]` au début de `reprendre.py`.
- Pour les tests du routeur, fabriquez un `AIMessage(content="", tool_calls=[{"name": "commander_materiel", "args": {...}, "id": "x"}])`.
</details>

## ✅ Auto-évaluation express

1. Que fait le réducteur `add_messages`, et que se passerait-il sans lui ?
2. Quelle condition technique est nécessaire pour utiliser `interrupt()` ?
3. Donnez un cas où LangGraph est surdimensionné et un cas où il est quasi indispensable.

**Réponses.** 1. Il fusionne la mise à jour avec la liste existante (ajout) au lieu de la remplacer ; sans lui, chaque nœud effacerait l'historique. 2. Un checkpointer : l'état doit être persisté pour que le graphe puisse être repris. 3. Surdimensionné : un prototype à 2 outils sans persistance ; indispensable : un agent multi-sessions avec validation humaine différée et reprise après crash.

## 📚 Pour aller plus loin
- [LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview) 🇬🇧 — documentation officielle (persistence, human-in-the-loop, streaming, sous-graphes, multi-agents).
- [Changelog LangChain / LangGraph](https://docs.langchain.com/oss/python/releases/changelog.md) 🇬🇧 — pour suivre les évolutions d'API (versions 1.x) avant toute mise à jour.
- [AI Agents in LangGraph (DeepLearning.AI)](https://www.deeplearning.ai/courses/ai-agents-in-langgraph) 🇬🇧 — cours court gratuit, de la boucle maison au graphe persistant.
- [Hugging Face Agents Course](https://huggingface.co/learn/agents-course/unit0/introduction) 🇬🇧 — l'unité 2.3 est consacrée à LangGraph ; certificat gratuit.
- [LangSmith](https://smith.langchain.com) 🇬🇧 — traçage des exécutions LangGraph (gratuit pour démarrer ; vérifiez les conditions sur le site).
