---
id: L098
module: M21
level: N3
title: "Multi-agents : CrewAI, AutoGen / AG2"
minutes: 50
objectives:
  - "Distinguer les architectures multi-agents (orchestrateur-workers, séquentiel, hiérarchique, handoffs, évaluateur-optimiseur) et dire quand un seul agent suffit"
  - "Construire une équipe d'agents avec CrewAI et un workflow d'agents avec Microsoft Agent Framework (successeur d'AutoGen et Semantic Kernel), puis un orchestrateur-workers sans framework"
  - "Identifier les pièges des systèmes multi-agents (coût, téléphone arabe, boucles, sécurité, évaluation) et appliquer les parades"
skills: ["C3.4"]
sources:
  - { title: "CrewAI — documentation", url: "https://docs.crewai.com", lang: "en" }
  - { title: "Microsoft Agent Framework (GitHub)", url: "https://github.com/microsoft/agent-framework", lang: "en" }
  - { title: "Microsoft Agent Framework 1.0 — synthèse (Atlan)", url: "https://atlan.com/know/ai-agent/microsoft/agent-framework/", lang: "en" }
  - { title: "Semantic Kernel — overview (Microsoft Learn)", url: "https://learn.microsoft.com/en-us/semantic-kernel/overview/", lang: "en" }
  - { title: "AG2 — fork communautaire d'AutoGen (GitHub)", url: "https://github.com/ag2ai/ag2", lang: "en" }
  - { title: "Claude Cookbook — Orchestrator-workers", url: "https://platform.claude.com/cookbook/patterns-agents-orchestrator-workers", lang: "en" }
  - { title: "Claude Cookbook — Evaluator-optimizer", url: "https://platform.claude.com/cookbook/patterns-agents-evaluator-optimizer", lang: "en" }
  - { title: "Claude Agent SDK — Subagents", url: "https://code.claude.com/docs/en/agent-sdk/subagents", lang: "en" }
  - { title: "Claude Platform — Managed Agents : multiagent orchestration", url: "https://platform.claude.com/docs/en/managed-agents/multiagent-orchestration", lang: "en" }
  - { title: "Claude Academy — Introduction to subagents", url: "https://academy.claude.com/courses/introduction-to-subagents", lang: "en" }
  - { title: "DeepLearning.AI — Multi AI Agent Systems with crewAI", url: "https://www.deeplearning.ai/short-courses/multi-ai-agent-systems-with-crewai/", lang: "en" }
---

# Multi-agents : CrewAI, AutoGen / AG2

> ⏱ 50 min · 🎯 Niveau 3 · 📚 Module 21

## 🎯 Ce que vous saurez faire
- Reconnaître les cinq architectures multi-agents qui reviennent dans toutes les bibliothèques et les dessiner avant de coder.
- Monter une « équipe » CrewAI en 40 lignes, un workflow Microsoft Agent Framework, et un orchestrateur-workers à la main avec l'API Claude.
- Répondre à la question que tout le monde esquive : « est-ce que j'ai vraiment besoin de plusieurs agents ? »

## 1. Pourquoi plusieurs agents ? (et pourquoi souvent non)

Un agent unique avec 25 outils et un prompt système de 3 000 mots finit par se tromper d'outil, oublier une règle, diluer son attention. Découper en **plusieurs agents spécialisés**, chacun avec son contexte, ses outils et son prompt courts, améliore souvent la qualité — c'est l'argument du cours Academy « Introduction to subagents » (fenêtre de contexte séparée, outils restreints, sortie structurée). Mais chaque agent supplémentaire ajoute des appels, des tokens, des messages entre agents (où l'information se perd) et des points de défaillance.

Règle empirique enseignée dans ce module : **un agent par domaine de compétence réellement distinct, jamais un agent par étape**. « Rédacteur » puis « relecteur » est un bon découpage (critères différents) ; « agent qui ouvre le fichier » puis « agent qui le lit » n'en est pas un.

### 1.1 Les cinq architectures

```
1. Séquentiel (pipeline)        A ──► B ──► C          chaque agent transforme la sortie du précédent
2. Orchestrateur-workers        O ──► W1, W2, W3 ──► O  l'orchestrateur découpe, délègue (souvent en parallèle), fusionne
3. Hiérarchique (manager)       M ◄──► A, B, C          un manager assigne les tâches dynamiquement et relance
4. Handoffs (relais)            A ──(transfère)──► B    l'agent courant passe la main, l'utilisateur ne voit qu'un interlocuteur
5. Évaluateur-optimiseur        G ──► E ──► G …          un générateur produit, un évaluateur critique, jusqu'à validation
```

Le [cookbook Anthropic](https://platform.claude.com/cookbook/patterns-agents-orchestrator-workers) implémente 2 et 5 en quelques dizaines de lignes ; l'OpenAI Agents SDK fait du 4 sa primitive centrale (`handoffs`, L097) ; CrewAI couvre 1 et 3 ; LangGraph permet tout (chaque agent est un nœud ou un sous-graphe, L096).

> 💡 **À retenir** — L'architecture se choisit sur une question : **qui décide de la prochaine étape ?** Vous (séquentiel), un agent chef (orchestrateur, manager), l'agent courant (handoff), ou un critique (évaluateur).

## 2. CrewAI : des rôles, des tâches, une équipe

[CrewAI](https://docs.crewai.com) (Python, MIT) modélise une équipe comme au bureau : des **Agents** définis par un rôle, un objectif et une « histoire » (`backstory`), des **Tasks** avec un résultat attendu, et une **Crew** qui les exécute en mode `sequential` ou `hierarchical` (un manager LLM distribue). Les **Flows** ajoutent un contrôle événementiel pour les cas complexes.

Cas : **due diligence d'un fournisseur** pour le service achats d'une ETI — collecter les informations, analyser les risques, rédiger la note de synthèse.

```bash
pip install crewai
export ANTHROPIC_API_KEY="sk-ant-..."
```

```python
# crew_fournisseur.py — CrewAI : trois agents spécialisés, trois tâches, exécution séquentielle
from crewai import Agent, Task, Crew, Process
from crewai.tools import tool

@tool("fiche_entreprise")
def fiche_entreprise(siren: str) -> str:
    """Renvoie la fiche d'identité d'une entreprise à partir de son SIREN (raison sociale, date de création,
    effectif, chiffre d'affaires). Données simulées : en production, API Sirene / Pappers."""
    return '{"raison_sociale": "Métallerie Vauban SAS", "creation": "2009", "effectif": 48, "ca_2025": 6400000}'

@tool("procedures_collectives")
def procedures_collectives(siren: str) -> str:
    """Indique si l'entreprise fait l'objet d'une procédure collective (sauvegarde, redressement, liquidation)."""
    return "Aucune procédure collective en cours (nov. 2026)."

MODELE = "anthropic/claude-sonnet-5-5"          # CrewAI route vers le fournisseur via LiteLLM

collecteur = Agent(
    role="Analyste données entreprise",
    goal="Rassembler les faits vérifiables sur le fournisseur {siren}",
    backstory="Vous travaillez au service achats d'une ETI industrielle française. Vous ne rapportez que des faits sourcés.",
    tools=[fiche_entreprise, procedures_collectives], llm=MODELE, max_iter=6, verbose=True,
)
analyste_risques = Agent(
    role="Analyste risques fournisseurs",
    goal="Évaluer la dépendance, la solidité financière et les risques de continuité",
    backstory="Vous appliquez la grille interne : dépendance > 30 % du CA du fournisseur = risque élevé.",
    llm=MODELE, max_iter=4,
)
redacteur = Agent(
    role="Rédacteur de notes achats",
    goal="Rédiger une note d'une page pour le comité achats, en français, structurée et prudente",
    backstory="Vous écrivez pour des décideurs pressés : titre, 3 points clés, recommandation, réserves.",
    llm=MODELE, max_iter=3,
)

t_collecte = Task(description="Collectez la fiche et la situation judiciaire du fournisseur SIREN {siren}.",
                  expected_output="Liste de faits datés, avec l'outil source pour chacun.", agent=collecteur)
t_risques = Task(description="À partir des faits collectés, évaluez les risques. Notre volume d'achats prévu : {achats} €/an.",
                 expected_output="Tableau risque / niveau (faible, moyen, élevé) / justification.", agent=analyste_risques,
                 context=[t_collecte])
t_note = Task(description="Rédigez la note de synthèse pour le comité achats.",
              expected_output="Note Markdown d'une page : titre, points clés, recommandation, réserves.", agent=redacteur,
              context=[t_collecte, t_risques], output_file="note_fournisseur.md")

equipe = Crew(agents=[collecteur, analyste_risques, redacteur], tasks=[t_collecte, t_risques, t_note],
              process=Process.sequential, verbose=True)

if __name__ == "__main__":
    resultat = equipe.kickoff(inputs={"siren": "512345678", "achats": "2100000"})
    print(resultat.raw[:800])
    print("Tokens :", resultat.token_usage)
```

Points d'attention : `context=[...]` est la **seule** information que reçoit l'agent suivant (pas toute la conversation) : c'est une force (contexte court) et un risque (perte d'information, section 5) ; `max_iter` est votre plafond de tours par agent ; en mode `hierarchical`, ajoutez `manager_llm=` et laissez le manager assigner — plus souple, plus cher, moins prévisible. Les noms exacts (`token_usage`, `output_file`) sont ceux de la documentation en nov. 2026 ; vérifiez pour votre version.

## 3. Microsoft Agent Framework : après AutoGen et Semantic Kernel

Petite histoire utile en entretien : **AutoGen** (Microsoft Research, 2023) a popularisé les agents qui « discutent » entre eux (`GroupChat`) ; **Semantic Kernel** était le SDK d'entreprise de Microsoft (.NET, Python, plugins). Les deux convergent dans le **Microsoft Agent Framework**, en **v1.0 GA depuis le 3 avril 2026** (.NET et Python, MIT) ; AutoGen est en maintenance depuis le 2 octobre 2025 et Semantic Kernel ne reçoit plus que des correctifs critiques (synthèse [Atlan](https://atlan.com/know/ai-agent/microsoft/agent-framework/), [dépôt](https://github.com/microsoft/agent-framework)). La communauté a forké AutoGen 0.2 sous le nom [AG2](https://github.com/ag2ai/ag2) (Apache 2.0) : si vous rencontrez du code `autogen` en 2026, c'est l'un ou l'autre.

Le framework distingue les **agents** (modèle + instructions + outils, compatibles MCP et A2A) des **workflows** (graphes d'exécuteurs typés, avec checkpoints et humain dans la boucle). Il fournit des orchestrations prêtes : séquentielle, concurrente, handoffs, « group chat », et *Magentic* (le manager planificateur hérité de Magentic-One).

```bash
pip install agent-framework --pre          # Python 3.10+ ; vérifiez la commande exacte dans le README
export OPENAI_API_KEY="sk-..."
```

```python
# maf_support.py — Microsoft Agent Framework : deux agents enchaînés (rédacteur → relecteur) dans un workflow
import asyncio
from agent_framework import SequentialBuilder
from agent_framework.openai import OpenAIChatClient

client = OpenAIChatClient(model_id="gpt-6.1-sol")       # ou AzureOpenAIChatClient, ou un autre connecteur

redacteur = client.create_agent(
    name="redacteur",
    instructions="Vous rédigez la réponse à une réclamation client pour une PME française : ton calme, "
                 "vouvoiement, une solution concrète, 120 mots maximum.",
)
relecteur = client.create_agent(
    name="relecteur",
    instructions="Vous relisez la réponse précédente. Vérifiez : aucune promesse de remboursement non autorisée, "
                 "aucune donnée personnelle superflue, orthographe. Renvoyez la version corrigée, puis une ligne "
                 "'Modifications : …'.",
)

async def main():
    workflow = SequentialBuilder().participants([redacteur, relecteur]).build()
    reclamation = ("Bonjour, ma commande 4521 (table en chêne) est arrivée avec un pied fendu. "
                   "Je veux une solution rapide. Mme Garnier")
    async for evenement in workflow.run_stream(reclamation):
        if getattr(evenement, "data", None):              # messages produits par chaque agent
            print(f"[{getattr(evenement, 'executor_id', '?')}] {str(evenement.data)[:300]}")

asyncio.run(main())
```

Les constructeurs (`SequentialBuilder`, `ConcurrentBuilder`, `HandoffBuilder`, `MagenticBuilder`…) et les connecteurs de modèles évoluent vite : prenez cette structure comme un **patron** et confirmez les noms dans le dépôt officiel. L'intérêt stratégique du framework pour une DSI : intégration Azure (AI Foundry, identité, observabilité) et support officiel .NET, rare chez les concurrents.

## 4. Orchestrateur-workers sans framework, avec l'API Claude

Le schéma le plus utile en production se code en 60 lignes, et vous en comprendrez chaque ligne. Cas : **localisation d'un catalogue produit** — l'orchestrateur découpe par langue, les workers traduisent en parallèle, l'orchestrateur assemble et vérifie.

```python
# orchestrateur_workers.py — découpage par l'orchestrateur, workers parallèles (asyncio), fusion
import asyncio, json
from anthropic import AsyncAnthropic

client = AsyncAnthropic()
ORCH, WORKER = "claude-sonnet-5-5", "claude-haiku-5-5"     # orchestrateur plus capable, workers économiques

async def orchestrer(fiche: str, langues: list[str]) -> dict:
    # 1. L'orchestrateur produit un PLAN structuré : quoi traduire, contraintes par langue
    plan = await client.messages.create(
        model=ORCH, max_tokens=1200,
        system="Vous préparez la localisation d'une fiche produit e-commerce. Répondez en JSON strict : "
               '{"glossaire": {terme: traduction_interdite_ou_imposee}, "taches": [{"langue": …, "consignes": …}]}',
        messages=[{"role": "user", "content": f"Fiche :\n{fiche}\n\nLangues : {langues}. Les noms de marque ne se traduisent pas."}],
    )
    plan_json = json.loads("".join(b.text for b in plan.content if b.type == "text"))

    # 2. Les WORKERS traduisent en parallèle, chacun avec un contexte minimal
    async def worker(tache: dict) -> dict:
        rep = await client.messages.create(
            model=WORKER, max_tokens=800,
            system=f"Traducteur professionnel vers {tache['langue']}. Glossaire imposé : {plan_json['glossaire']}. "
                   f"Consignes : {tache['consignes']}. Rendez uniquement la fiche traduite.",
            messages=[{"role": "user", "content": fiche}],
        )
        return {"langue": tache["langue"], "texte": "".join(b.text for b in rep.content if b.type == "text"),
                "tokens": rep.usage.input_tokens + rep.usage.output_tokens}
    resultats = await asyncio.gather(*(worker(t) for t in plan_json["taches"]))

    # 3. L'orchestrateur VÉRIFIE (évaluateur) et assemble
    verif = await client.messages.create(
        model=ORCH, max_tokens=600,
        system='Contrôle qualité de traductions. Répondez en JSON : {"ok": bool, "problemes": [{"langue", "detail"}]}',
        messages=[{"role": "user", "content": json.dumps({"source": fiche, "traductions": resultats}, ensure_ascii=False)}],
    )
    return {"traductions": resultats, "controle": json.loads("".join(b.text for b in verif.content if b.type == "text"))}

if __name__ == "__main__":
    fiche = "Lampe Nordica — Lampe de bureau LED 8 W, bras articulé, finition chêne. Garantie 2 ans. Fabriquée en France."
    out = asyncio.run(orchestrer(fiche, ["en", "de", "es"]))
    for t in out["traductions"]:
        print(f"--- {t['langue']} ({t['tokens']} tokens) ---\n{t['texte']}\n")
    print("Contrôle :", out["controle"])
```

Ce code illustre deux principes du guide de prompting d'Anthropic (section *Subagent orchestration*) : **l'orchestrateur transmet aux workers des consignes complètes et autonomes** (ils ne voient pas la conversation), et **le retour des workers est structuré** pour être fusionné sans ambiguïté. Dans le Claude Agent SDK, ce schéma s'obtient avec des [sous-agents](https://code.claude.com/docs/en/agent-sdk/subagents) déclarés (contexte séparé, outils restreints) ; dans les Managed Agents, avec la page [Multiagent orchestration](https://platform.claude.com/docs/en/managed-agents/multiagent-orchestration) (sessions enfants).

## 5. Les pièges des multi-agents (et les parades)

| Piège | Symptôme | Parade |
|---|---|---|
| **Explosion de coût** | 3 agents × 6 tours × contexte croissant = 10× le coût d'un agent | workers sur un modèle économique ; `max_iter` par agent ; budget global ; mesurer avant de généraliser |
| **Téléphone arabe** | l'information se dégrade à chaque passage (chiffre arrondi, réserve oubliée) | passer des **objets structurés** (JSON validé), pas de la prose ; conserver la source brute accessible |
| **Débat sans fin** | générateur et évaluateur se renvoient la balle | nombre maximal de cycles (2-3) ; critères d'acceptation explicites ; sortie « échec documenté » |
| **État partagé incohérent** | deux agents écrivent le même fichier / la même ligne | un seul agent écrit ; les autres proposent ; ou un état typé avec réducteurs (LangGraph) |
| **Sécurité en cascade** | un worker lit une page web piégée et contamine l'orchestrateur | résultats de workers = données non fiables ; outils d'écriture réservés à l'orchestrateur ; validation humaine avant action |
| **Évaluation impossible** | « ça a l'air mieux » | jeu de test de bout en bout + métriques par agent (M22) ; comparer avec la baseline mono-agent |

> ⚠️ **Piège fréquent** — Donner un `backstory` romanesque (« vous êtes un analyste légendaire de Wall Street ») et croire que la qualité en dépend. Ce qui compte, c'est la précision des **consignes**, des **résultats attendus** et des **outils**. Le rôle sert à cadrer, pas à flatter.

🎮 **Défi** — Votre crew « due diligence » coûte 0,42 $ par fournisseur et l'analyste risques ignore parfois la procédure collective. Deux corrections ? *(1. Faire renvoyer par le collecteur un JSON avec un champ obligatoire `procedure_collective` ; 2. Passer le collecteur et le rédacteur sur Haiku 5.5, garder Sonnet 5.5 pour les risques ; mesurer à nouveau.)*

## 🧪 Exercice pratique

**Consigne.** Un cabinet de recrutement veut automatiser la **présélection de candidatures** (5 CV fictifs en texte, 1 fiche de poste).
1. Implémentez-la **en mono-agent** (boucle L095 ou un SDK de L097) : score et justification par CV. Mesurez coût et qualité sur un jeu de 5 CV dont vous connaissez le classement attendu.
2. Implémentez-la en **orchestrateur-workers** sans framework : un worker par CV (Haiku 5.5), l'orchestrateur (Sonnet 5.5) fournit la grille et fusionne.
3. Implémentez-la avec **CrewAI** (collecteur de critères → évaluateur → rédacteur de synthèse) **ou** avec Microsoft Agent Framework (séquentiel).
4. Comparez les trois versions dans un tableau : coût par lot, latence, classement obtenu vs attendu, lisibilité du code, facilité de test.
5. Ajoutez la parade « téléphone arabe » : chaque passage transmet un JSON validé (schéma Pydantic), jamais de prose seule.

**Critères de réussite.** Les trois versions produisent le même top 2 ; la version orchestrateur-workers est la moins chère (workers parallèles sur Haiku) ; le tableau comparatif cite des chiffres mesurés ; aucune donnée personnelle de CV n'est journalisée en clair (anonymisez : « candidat A »).

<details>
<summary>Pistes</summary>

- Classement attendu : fabriquez vos 5 CV avec un « bon », deux « moyens », deux « hors sujet » ; la qualité se mesure alors sans ambiguïté.
- Pour mesurer le coût avec CrewAI, lisez `token_usage` ; avec l'API Claude, additionnez `usage` par appel.
- Si l'orchestrateur fusionne mal, c'est presque toujours parce que les workers renvoient des formats différents : imposez le schéma dans le prompt système du worker.
</details>

## ✅ Auto-évaluation express

1. Citez les cinq architectures multi-agents et, pour chacune, qui décide de la prochaine étape.
2. Que sont devenus AutoGen et Semantic Kernel en 2026 ?
3. Quelle est la parade principale au « téléphone arabe » entre agents ?

**Réponses.** 1. Séquentiel (vous), orchestrateur-workers (l'orchestrateur), hiérarchique (le manager), handoffs (l'agent courant), évaluateur-optimiseur (l'évaluateur). 2. Ils convergent dans Microsoft Agent Framework (v1.0 GA, avril 2026) ; AutoGen est en maintenance, Semantic Kernel en correctifs critiques ; AG2 est le fork communautaire d'AutoGen. 3. Transmettre des objets structurés validés (JSON avec schéma) plutôt que des résumés en prose, et garder la source brute accessible.

## 📚 Pour aller plus loin
- [CrewAI — documentation](https://docs.crewai.com) 🇬🇧 — agents, tasks, crews, flows, outils, mémoire.
- [Microsoft Agent Framework (GitHub)](https://github.com/microsoft/agent-framework) 🇬🇧 — README, exemples Python et .NET, orchestrations ; et l'historique [Semantic Kernel](https://learn.microsoft.com/en-us/semantic-kernel/overview/) 🇬🇧.
- [Claude Cookbook — Orchestrator-workers](https://platform.claude.com/cookbook/patterns-agents-orchestrator-workers) 🇬🇧 et [Evaluator-optimizer](https://platform.claude.com/cookbook/patterns-agents-evaluator-optimizer) 🇬🇧 — les deux patrons en code minimal.
- [Introduction to subagents (Claude Academy)](https://academy.claude.com/courses/introduction-to-subagents) 🇬🇧 — 45 min, badge gratuit : concevoir des sous-agents efficaces.
- [Multi AI Agent Systems with crewAI (DeepLearning.AI)](https://www.deeplearning.ai/short-courses/multi-ai-agent-systems-with-crewai/) 🇬🇧 — cours court gratuit par l'équipe CrewAI.
