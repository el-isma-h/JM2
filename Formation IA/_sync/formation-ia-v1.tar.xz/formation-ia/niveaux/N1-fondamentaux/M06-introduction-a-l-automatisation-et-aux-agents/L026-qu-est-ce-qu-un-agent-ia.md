---
id: L026
module: M06
level: N1
title: "Qu'est-ce qu'un agent IA ?"
minutes: 40
objectives:
  - "Expliquer la différence entre un chatbot, un workflow automatisé et un agent IA"
  - "Décrire la boucle d'un agent : objectif, raisonnement, outils, observation, répétition"
  - "Identifier un cas d'usage d'agent réaliste dans son métier et ses garde-fous"
skills: ["C1.5"]
sources:
  - { title: "n8n Docs — What agents do", url: "https://docs.n8n.io/build/integrate-ai/understand-ai-components/what-agents-do.md", lang: "en" }
  - { title: "n8n Docs — Build and manage agents (préversion)", url: "https://docs.n8n.io/build/build-and-manage-agents.md", lang: "en" }
  - { title: "Claude Platform — Managed Agents overview", url: "https://platform.claude.com/docs/en/managed-agents/overview", lang: "en" }
  - { title: "Claude Platform — Tool use overview", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview", lang: "en" }
  - { title: "Claude Cookbook — Basic workflows (patterns d'agents)", url: "https://platform.claude.com/cookbook/patterns-agents-basic-workflows", lang: "en" }
  - { title: "Claude Academy — Building effective human-agent teams", url: "https://academy.claude.com/courses/building-effective-human-agent-teams", lang: "en" }
  - { title: "OpenAI — Agents (vue d'ensemble)", url: "https://developers.openai.com/api/docs/guides/agents", lang: "en" }
---

# Qu'est-ce qu'un agent IA ?

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 6

## 🎯 Ce que vous saurez faire
- Dire en une phrase ce qui distingue un **agent IA** d'un chatbot et d'un workflow classique.
- Dessiner la **boucle** d'un agent et nommer ses quatre ingrédients : objectif, modèle, outils, garde-fous.
- Proposer un cas d'usage d'agent dans votre métier, étape par étape, avec ses limites.

## 1. Le mot le plus galvaudé de 2026

« Agent » est partout : dans les annonces des fournisseurs, dans les offres d'emploi, dans les plaquettes des cabinets de conseil. Anthropic a lancé ses **Managed Agents** en avril 2026 ; OpenAI parle d'*Agents API* et d'*Agents SDK* ; n8n a renommé son nœud phare **AI Agent** et propose depuis 2026 un **Agent Builder** en préversion ; Make vend un badge « AI Agent Builder ». Derrière le mot, il y a une idée simple, et beaucoup de marketing. Commençons par l'idée.

### 1.1 Trois niveaux d'autonomie

Reprenons le workflow de la leçon précédente et comparons-le à deux autres façons d'obtenir un résumé des avis clients.

| | Chatbot | Workflow | Agent |
|---|---|---|---|
| Qui décide des étapes ? | Vous, à chaque message | Vous, une fois pour toutes, en dessinant le flux | Le **modèle**, au fil de l'exécution |
| Exemple | Vous collez les avis dans Claude et demandez un résumé | Chaque lundi, n8n envoie les avis au modèle puis l'e-mail | « Prépare le point qualité du lundi » : l'agent va chercher les avis, vérifie les tickets du support, compare avec la semaine précédente, rédige, puis demande votre accord avant d'envoyer |
| Quand ça se passe bien | Rapide, contrôlé | Fiable, prévisible, peu coûteux | S'adapte aux imprévus, enchaîne des étapes non prévues |
| Quand ça se passe mal | Vous recommencez | Il échoue proprement au nœud fautif | Il peut tourner en rond, se tromper d'outil, coûter cher |

Un **workflow** est une **recette** : des étapes fixées à l'avance, exécutées dans l'ordre. Un **agent** est un **cuisinier** : il reçoit un objectif (« un dîner pour six, sans gluten, avec ce qu'il y a dans le frigo »), regarde ce dont il dispose, choisit ses ustensiles, goûte, corrige. La documentation de n8n formule la même distinction : dans une *chaîne* (comme la Basic LLM Chain), les étapes sont écrites par vous ; dans un *agent*, le modèle **décide lui-même quels outils appeler, dans quel ordre, et quand s'arrêter**.

> 💡 **À retenir** — Un agent IA est un modèle de langage à qui l'on a donné un **objectif**, des **outils** et le droit de **boucler** : agir, observer le résultat, agir de nouveau, jusqu'à atteindre l'objectif ou atteindre une limite.

## 2. La boucle de l'agent

### 2.1 Les quatre temps

```
                 ┌──────────────────────────────────────────────┐
   OBJECTIF ───▶ │  1. RAISONNER : « que me manque-t-il ? »      │
   « Prépare le  │  2. AGIR : appeler un OUTIL                   │
   point qualité │     (lire les avis, chercher un ticket,       │
   du lundi »    │      calculer, envoyer un e-mail…)            │
                 │  3. OBSERVER : lire le résultat de l'outil    │
                 │  4. DÉCIDER : terminé ? sinon, retour en 1    │
                 └──────────────────────────────────────────────┘
                                   │
                                   ▼
                      RÉSULTAT + (souvent) validation humaine
```

Les **outils** (*tools*) sont la clé. Un modèle de langage, seul, ne sait que produire du texte : il ne peut ni lire votre agenda, ni envoyer un e-mail, ni consulter le stock. Un outil est une **fonction** que vous mettez à sa disposition, décrite en langage clair (« `chercher_ticket(numero)` : renvoie le ticket du support correspondant ») : le modèle produit alors un petit JSON indiquant « j'appelle `chercher_ticket` avec `numero = 4521` », votre logiciel exécute la fonction, et renvoie le résultat au modèle, qui continue. C'est ce que la documentation Anthropic appelle *tool use* et OpenAI *function calling* ; vous avez vu, dans la leçon 24, que le JSON est la langue de cet échange. Les agents de 2026 disposent en plus d'outils « intégrés » fournis par les plateformes : recherche web, lecture de pages, exécution de code, manipulation de fichiers, pilotage d'un navigateur.

### 2.2 Les quatre ingrédients d'un agent

1. **Un modèle** capable de raisonner et d'appeler des outils de manière fiable. Toutes les familles actuelles le font (Claude Fable 5.1 / Opus 5.5 / Sonnet 5.5 / Haiku 5.5, GPT-6, Gemini 4, Mistral Large 4, Grok 4.7, nov. 2026) ; les modèles plus petits et plus anciens s'en sortent moins bien.
2. **Des instructions** (le *system prompt*) : le rôle, le périmètre, le ton, ce qui est interdit. Tout ce que vous avez appris au module 4 s'applique, avec une exigence supplémentaire : dire à l'agent **quand s'arrêter et demander**.
3. **Des outils**, le moins possible mais les bons : chaque outil ajouté est une source d'erreur possible.
4. **Des garde-fous** : une limite de tours ou de budget, des permissions (lecture seule sur la comptabilité, écriture interdite), et une **validation humaine** (*human in the loop*) avant toute action irréversible comme envoyer, payer, supprimer. Chez Anthropic, les Managed Agents formalisent cela par des *permission policies* et des *budgets* ; n8n documente le schéma « human in the loop for tools ».

> ⚠️ **Piège fréquent** — Croire qu'un agent « comprend » l'entreprise parce qu'il parle bien. Il ne connaît que ce que ses outils lui renvoient et ce que ses instructions lui disent. Un agent sans accès au CRM inventera des clients avec un aplomb parfait. Avant de déployer, listez les informations dont il a besoin et vérifiez qu'un outil les lui fournit.

## 3. Des agents que vous pouvez déjà rencontrer

- **Les agents de code** (Claude Code, Codex CLI, Gemini CLI, Cursor, GitHub Copilot…) lisent un projet, modifient des fichiers, lancent des tests, recommencent : ce sont les agents les plus aboutis de 2026 et la raison de l'engouement actuel. Le module 17 vous y fera entrer.
- **Les agents « bureau »** : Claude Cowork (fichiers, navigateur, Microsoft 365) ou Claude Tag dans Slack exécutent des tâches de plusieurs étapes à partir d'une demande en langage naturel, sous votre contrôle.
- **Les agents hébergés** : les **Managed Agents** d'Anthropic (nov. 2026 : 0,08 $ par heure de session, plus les tokens) font tourner un agent avec ses outils, sa mémoire et son environnement dans le cloud du fournisseur, sans infrastructure à gérer. OpenAI propose l'équivalent avec son *Agents SDK*.
- **Les agents no-code** : le nœud **AI Agent** de n8n (modèle + outils + mémoire) ou l'**Agent Builder** de n8n (préversion 2026 : instructions, outils, recherche web, base de connaissances, canaux Slack ou Teams, planification). Même chose chez Make (« AI Agents in Make »).
- **Les équipes d'agents** : un agent « chef de projet » délègue à des sous-agents spécialisés (recherche, rédaction, vérification). Le cours Anthropic « Introduction to subagents » décrit cette organisation ; entre entreprises différentes, un protocole dédié, **A2A** (*Agent2Agent*, v1.0 publiée en 2026 sous la Linux Foundation), permet à des agents de se parler. Nous y reviendrons dans la leçon sur MCP.

> 🔗 **Documentation officielle** — [n8n Docs — What agents do](https://docs.n8n.io/build/integrate-ai/understand-ai-components/what-agents-do.md) 🇬🇧 · [Claude Platform — Managed Agents overview](https://platform.claude.com/docs/en/managed-agents/overview) 🇬🇧.

## 4. Faut-il un agent ? La question à poser avant tout

Anthropic, dans ses recettes de « patterns d'agents », insiste sur un point que les vendeurs oublient : **commencez par le plus simple**. Un prompt bien écrit suffit souvent ; sinon un workflow à étapes fixes ; l'agent n'arrive qu'en dernier, quand les étapes ne peuvent pas être connues à l'avance.

| Si votre besoin… | Alors… |
|---|---|
| se décrit en étapes fixes (« chaque lundi, résume, envoie ») | **Workflow** (n8n, Make) : fiable, pas cher, traçable |
| varie à chaque cas (« traite cette réclamation », dont la nature change) | **Agent**, avec outils limités et validation humaine |
| est ponctuel et créatif (« rédige-moi cette proposition ») | **Chatbot** ou projet Claude / GPT personnalisé |
| est critique (paiement, juridique, santé) | Workflow + humain ; l'agent, s'il y en a un, ne fait que **proposer** |

Trois exemples français réalistes :

- **Cabinet comptable** : un agent trie les e-mails clients entrants, cherche la pièce manquante dans le dossier, prépare une réponse. **Garde-fou** : il ne répond jamais seul ; le collaborateur valide en un clic.
- **Commerce de proximité** : un agent surveille les avis Google et les messages, propose une réponse personnalisée, signale les avis à problème. **Garde-fou** : réponse publiée uniquement après validation du gérant.
- **Service RH d'une PME** : un agent répond aux questions des salariés sur la mutuelle ou les congés à partir des accords d'entreprise (base de connaissances), et crée un ticket pour le reste. **Garde-fou** : accès en lecture seule, aucune donnée de paie individuelle.

🎮 **Défi** — Pour chacune de ces situations, dites « workflow » ou « agent » : (a) convertir chaque PDF reçu en texte et l'archiver ; (b) organiser une réunion à six en trouvant un créneau, une salle et en rédigeant l'ordre du jour ; (c) envoyer un SMS de rappel la veille d'un rendez-vous ; (d) diagnostiquer pourquoi un colis n'est pas arrivé en interrogeant trois transporteurs. *(a et c : workflow ; b et d : agent, avec validation avant envoi.)*

## 🧪 Exercice pratique

**Consigne.** Rédigez la **fiche de cadrage** d'un agent IA pour votre métier (une page), avec les rubriques suivantes :

1. **Objectif** en une phrase (« Préparer chaque matin la liste des relances clients à faire »).
2. **Pourquoi un agent plutôt qu'un workflow** (deux lignes : en quoi les étapes varient selon les cas).
3. **Outils** nécessaires (3 à 5), avec pour chacun : ce qu'il lit ou écrit, et le droit accordé (lecture seule / écriture).
4. **Déroulé type** en 5 à 8 étapes, du déclenchement au résultat, en marquant d'un ✋ les points de validation humaine.
5. **Limites** : ce que l'agent n'a pas le droit de faire, le budget maximal (tours ou euros), ce qui se passe en cas de doute.

**Critères de réussite.**
- Le vocabulaire est exact : objectif, outil, boucle, validation humaine (critère de la compétence C1.5).
- Le cas est réaliste et décrit étape par étape ; au moins un ✋ précède chaque action irréversible.
- Chaque outil est relié à une information précise ; aucune information « magique » n'apparaît sans outil pour la fournir.

<details>
<summary>Pistes de correction (relances clients d'un artisan)</summary>

Objectif : chaque matin, préparer les relances des factures en retard. Pourquoi un agent : le ton et le canal varient (bon client, litige en cours, première relance ou troisième). Outils : `factures_en_retard()` (lecture, logiciel de facturation) ; `historique_client(id)` (lecture, CRM) ; `rediger_sms`/`rediger_email` (production de texte) ; `envoyer(message)` (écriture, **après validation**). Déroulé : déclenchement 8 h → liste des retards → pour chaque facture, lecture de l'historique → choix du ton → rédaction → ✋ l'artisan valide ou modifie → envoi → journal. Limites : jamais d'envoi sans validation ; pas de relance si un litige est ouvert ; maximum 20 relances par jour ; en cas de doute, mettre de côté avec une note.

</details>

## ✅ Auto-évaluation express

1. Qu'est-ce qui différencie fondamentalement un agent d'un workflow ?
2. Que fait un modèle quand il « appelle un outil » ?
3. Citez deux garde-fous indispensables avant de laisser un agent agir en entreprise.

<details>
<summary>Réponses</summary>

1. Dans un workflow, les étapes sont fixées à l'avance par vous ; dans un agent, le modèle choisit lui-même les outils à appeler, leur ordre, et le moment où s'arrêter (il boucle).
2. Il produit une demande structurée (JSON) indiquant le nom de l'outil et ses paramètres ; votre logiciel exécute l'outil et renvoie le résultat au modèle, qui poursuit son raisonnement.
3. Par exemple : des permissions limitées (lecture seule), une limite de tours ou de budget, et une validation humaine avant toute action irréversible (envoyer, payer, supprimer).

</details>

## 📚 Pour aller plus loin
- [Claude Academy — Building effective human-agent teams](https://academy.claude.com/courses/building-effective-human-agent-teams) 🇬🇧 — 45 min, gratuit : ce qui fait d'un agent un « coéquipier » et comment préparer son organisation (rôles clairs, déploiement progressif).
- [Claude Cookbook — Basic workflows](https://platform.claude.com/cookbook/patterns-agents-basic-workflows) 🇬🇧 — les patterns prompt chaining, routing, parallélisation, et la règle « commencez simple ».
- [n8n Docs — Build and manage agents (préversion)](https://docs.n8n.io/build/build-and-manage-agents.md) 🇬🇧 — l'Agent Builder de n8n : instructions, outils, mémoire, canaux.
- [OpenAI — Agents](https://developers.openai.com/api/docs/guides/agents) 🇬🇧 — la vision d'OpenAI : agents, outils intégrés, garde-fous et approbations.
- [Claude Platform — Tool use overview](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview) 🇬🇧 — comment un modèle appelle un outil (pour les curieux ; traité en détail au niveau 3).
