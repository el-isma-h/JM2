---
id: L025
module: M06
level: N1
title: "n8n : découverte et premier workflow (aligné n8n Level 1)"
minutes: 50
objectives:
  - "Identifier les éléments de l'interface n8n : canevas, nœuds, connexions, déclencheurs, identifiants, exécutions"
  - "Construire pas à pas un premier workflow déclencheur → nœud IA → envoi d'e-mail"
  - "Tester, lire les données qui circulent entre les nœuds et activer un workflow"
skills: ["C1.5"]
sources:
  - { title: "n8n Academy — N8N101 Essentials: Your First Workflows", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N101+2026H2/about", lang: "en" }
  - { title: "n8n Academy — catalogue des cours", url: "https://learn.n8n.io/courses", lang: "en" }
  - { title: "n8n Docs — Build your first workflow", url: "https://docs.n8n.io/build-your-first-workflow.md", lang: "en" }
  - { title: "n8n Docs — Learning paths", url: "https://docs.n8n.io/learning-paths", lang: "en" }
  - { title: "n8n Docs — LangChain in n8n (nœuds IA)", url: "https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md", lang: "en" }
  - { title: "n8n Docs — Install using Docker Compose", url: "https://docs.n8n.io/deploy/host-n8n/install-options/install-using-docker-compose.md", lang: "en" }
  - { title: "n8n Community — The n8n Academy is here (16 juin 2026)", url: "https://community.n8n.io/t/the-n8n-academy-is-here/299695", lang: "en" }
---

# n8n : découverte et premier workflow (aligné n8n Level 1)

> ⏱ 50 min · 🎯 Niveau 1 · 📚 Module 6

## 🎯 Ce que vous saurez faire
- Vous repérer dans n8n : le canevas, les nœuds, les connexions, le panneau d'exécution, les identifiants.
- Construire, tester et activer votre **premier workflow** : chaque lundi à 8 h, un modèle d'IA résume les avis clients de la semaine et vous envoie le résumé par e-mail.
- Lire les données JSON qui passent d'un nœud à l'autre et les réutiliser avec une **expression**.

## 1. n8n, c'est quoi ?

**n8n** (prononcez « n-eight-n », pour *nodemation*) est un outil d'automatisation **visuel** : au lieu d'écrire du code, vous posez des blocs sur une toile et vous les reliez. Chaque bloc, appelé **nœud** (*node*), fait une chose : recevoir un e-mail, interroger une API, appeler un modèle d'IA, écrire dans un tableur. Les nœuds reliés forment un **workflow** (un flux de travail), qui s'exécute tout seul lorsque son **déclencheur** (*trigger*) se réveille.

Pourquoi n8n plutôt que Make ou Zapier ? Les trois reposent sur les mêmes principes et nous vous encourageons à essayer les trois. n8n a deux particularités : il peut s'installer **sur votre propre serveur** (vos données ne quittent pas l'entreprise, ce qui compte pour le RGPD, voir module 7), et il intègre nativement une famille de **nœuds IA** (modèles de langage, agents, mémoire, outils) que nous exploiterons jusqu'au niveau 3.

Depuis le 16 juin 2026, n8n propose une plateforme de cours gratuits, la **n8n Academy** (learn.n8n.io), qui remplace les anciens cours texte « Level 1 » et « Level 2 ». Cette leçon suit le découpage du premier cours, **N8N101 « Essentials: Your First Workflows »** (2 à 4 h) : section 1, prise en main (canevas, nœuds, connexions, exécutions, déclencheurs, planification, identifiants) ; section 2, flux de données et transformation (structure des données, expressions, mapping). Chaque cours de l'Academy est validé par des quiz (10 %), des exercices pratiques (55 %) et un examen final (35 %), avec 70 % requis et un badge Accredible à la clé (nov. 2026). Nous vous invitons à le suivre après cette leçon : vous y serez déjà à l'aise.

> 🔗 **Documentation officielle** — [n8n Academy — N8N101 Essentials: Your First Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N101+2026H2/about) 🇬🇧 · [n8n Docs — Build your first workflow](https://docs.n8n.io/build-your-first-workflow.md) 🇬🇧.

## 2. Obtenir une instance n8n (10 min)

Deux chemins, au choix :

**Chemin A, le plus simple : n8n Cloud.** Créez un compte d'essai gratuit sur n8n.io (durée de l'essai : voir la page officielle, elle évolue). Vous obtenez une adresse du type `votre-nom.app.n8n.cloud`, rien à installer. C'est la voie recommandée par la n8n Academy pour débuter.

**Chemin B, pour les curieux : auto-hébergement avec Docker.** Si Docker Desktop est installé sur votre ordinateur, créez un dossier, placez-y ce fichier `docker-compose.yml`, puis lancez `docker compose up -d`. n8n sera accessible sur `http://localhost:5678`.

```yaml
# docker-compose.yml — installation locale minimale de n8n (nov. 2026)
services:
  n8n:
    image: docker.n8n.io/n8nio/n8n
    restart: unless-stopped
    ports:
      - "5678:5678"
    environment:
      - GENERIC_TIMEZONE=Europe/Paris      # fuseau horaire des déclencheurs planifiés
      - TZ=Europe/Paris
      - N8N_ENCRYPTION_KEY=${N8N_ENCRYPTION_KEY}  # clé de chiffrement des identifiants, définie dans un fichier .env
    volumes:
      - n8n_data:/home/node/.n8n           # vos workflows et identifiants survivent aux redémarrages
volumes:
  n8n_data:
```

```bash
# Génère une clé de chiffrement aléatoire dans .env, puis démarre n8n
echo "N8N_ENCRYPTION_KEY=$(openssl rand -hex 24)" > .env
docker compose up -d
```

> ⚠️ **Piège fréquent** — Oublier `GENERIC_TIMEZONE`. Sans ce réglage, votre « lundi 8 h » tombe à l'heure UTC du serveur, soit 9 h ou 10 h en France selon la saison. La doc n8n le rappelle dans son guide Docker Compose.

> 🔗 **Documentation officielle** — [n8n Docs — Install using Docker Compose](https://docs.n8n.io/deploy/host-n8n/install-options/install-using-docker-compose.md) 🇬🇧.

## 3. Visite guidée de l'interface (5 min)

À la première connexion, créez un nouveau workflow (« Create workflow »). Vous voyez :

```
┌──────────────────────────────────────────────────────────────────────┐
│  Mon premier workflow          [Editor] [Executions]     Inactive ○  │  ← nom, onglets, interrupteur d'activation
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│      ┌──────────┐      ┌──────────┐      ┌──────────┐      [ + ]     │  ← le CANEVAS (canvas)
│      │ Trigger  │─────▶│  Nœud 2  │─────▶│  Nœud 3  │                │     nœuds reliés par des connexions
│      └──────────┘      └──────────┘      └──────────┘                │
│                                                                      │
├──────────────────────────────────────────────────────────────────────┤
│  ▶ Execute workflow                                                   │  ← test manuel
└──────────────────────────────────────────────────────────────────────┘
```

- Le **canevas** accueille les nœuds ; le bouton `+` (ou la touche `Tab`) ouvre le catalogue de plus de 400 intégrations.
- Un nœud s'ouvre en double-cliquant : à gauche, les données **reçues** (*input*) ; au centre, ses **paramètres** ; à droite, les données **produites** (*output*). Trois vues pour les données : **Table**, **JSON**, **Schema**.
- L'onglet **Executions** garde l'historique de chaque exécution, réussie ou échouée, avec les données de chaque nœud : c'est votre boîte noire.
- Les **identifiants** (*credentials*) sont rangés dans un coffre chiffré, séparé des workflows : clé API Anthropic, compte Gmail, etc. Vous les créez une fois et les réutilisez partout.

> 💡 **À retenir** — Dans n8n, les données circulent de nœud en nœud sous forme d'une **liste d'éléments** (*items*), chacun étant un objet JSON. Un nœud reçoit des items, en produit d'autres. C'est le cœur de la section 2 du cours N8N101.

## 4. Construire le workflow pas à pas (25 min)

Objectif : **chaque lundi à 8 h, résumer les avis clients de la semaine et m'envoyer le résumé par e-mail.** Pour rester concentrés sur l'essentiel, les avis seront saisis dans le workflow lui-même ; au niveau 2, vous les lirez depuis un vrai formulaire ou une base de données.

### Étape 1 : le déclencheur (Schedule Trigger)

1. Cliquez sur « Add first step » et cherchez **Schedule Trigger**.
2. Réglez : *Trigger Interval* = `Weeks`, *Weeks Between Triggers* = `1`, *Trigger on Weekdays* = `Monday`, *Trigger at Hour* = `8`, *Trigger at Minute* = `0`.
3. Fermez le nœud. Pendant la construction, vous pourrez l'exécuter à la main : un déclencheur planifié ne vous oblige pas à attendre lundi.

D'autres déclencheurs existent et vous les reconnaîtrez grâce à la leçon précédente : **Webhook** (un autre logiciel vous prévient), **On form submission** (un formulaire n8n), **Gmail Trigger** (un e-mail arrive), **Manual Trigger** (vous cliquez). Un workflow commence **toujours** par un déclencheur.

### Étape 2 : les données à traiter (Edit Fields)

1. Cliquez sur le `+` à droite du déclencheur, ajoutez le nœud **Edit Fields (Set)**.
2. Ajoutez un champ : *Name* = `avis`, *Type* = `String`, *Value* = collez trois ou quatre avis clients, par exemple :

```
Avis 1 (Boulangerie Martin, Tours) : « Site livré en avance, équipe réactive, je recommande. »
Avis 2 (Garage Petit, Blois) : « Le formulaire de devis ne fonctionnait pas sur mobile pendant deux jours. »
Avis 3 (Cabinet Rousseau, Orléans) : « Très bon accompagnement, mais la facture est arrivée en retard. »
```

3. Cliquez sur **Execute step** : à droite, le panneau *Output* affiche un item avec la clé `avis`. Vous venez de produire votre premier JSON dans n8n.

### Étape 3 : le nœud IA (Basic LLM Chain + modèle Anthropic)

1. Ajoutez le nœud **Basic LLM Chain** (catégorie *AI*). C'est un nœud « racine » qui a besoin d'un **sous-nœud** modèle : cliquez sur le petit `+` sous *Model* et choisissez **Anthropic Chat Model** (ou OpenAI, Google Gemini, Groq, Mistral : la logique est identique).
2. Dans le sous-nœud, créez un identifiant : *Credential* → *Create new* → collez votre clé API (créée sur la console Anthropic, voir leçon 24). Choisissez le modèle `claude-haiku-5-5` : rapide et économique, largement suffisant pour un résumé (nov. 2026 : 0,10 $ par million de tokens en entrée ; un résumé hebdomadaire coûtera une fraction de centime).
3. Revenez dans *Basic LLM Chain* : *Prompt* = `Define below`, puis saisissez le prompt en **mode Expression** (le petit interrupteur *Fixed / Expression* au-dessus du champ) :

```
Vous êtes l'assistant de direction d'une agence web française.
Voici les avis clients reçus cette semaine :

{{ $json.avis }}

Rédigez un résumé en trois parties, en français :
1. Points forts cités (une à deux phrases).
2. Problèmes à corriger (liste à puces, un problème par ligne).
3. Une action prioritaire pour la semaine.
Ne dépassez pas 150 mots.
```

4. Cliquez sur **Execute step**. Dans le panneau *Output*, le résumé apparaît dans un champ nommé `text`.

Ce que vous venez d'apprendre : `{{ $json.avis }}` est une **expression**. Les doubles accolades disent à n8n « remplace-moi par une valeur » ; `$json` désigne l'item reçu du nœud précédent ; `.avis` est le chemin vers la clé, exactement comme `client.nom` dans la leçon 24. Vous pouvez aussi faire glisser une clé depuis le panneau *Input* vers le champ : n8n écrit l'expression pour vous.

> ⚠️ **Piège fréquent** — Laisser le champ en mode *Fixed* : le modèle reçoit alors littéralement le texte `{{ $json.avis }}` au lieu des avis et répond « je ne vois aucun avis ». Si une expression apparaît en vert avec un aperçu en dessous, elle est active ; si elle apparaît en texte brut, basculez l'interrupteur.

**Chaîne ou agent ?** Vous avez utilisé une *Basic LLM Chain* : une question, une réponse, point. Le nœud voisin **AI Agent** ajoute des **outils** et une **mémoire** : le modèle peut décider d'appeler une recherche web ou un calendrier avant de répondre. C'est le sujet de la leçon suivante, et du cours N8N103 de l'Academy.

### Étape 4 : l'envoi de l'e-mail (Gmail)

1. Ajoutez le nœud **Gmail**, opération *Send a message* (si votre entreprise utilise Outlook, prenez **Microsoft Outlook** ; sans compte, prenez **Send Email**, qui fonctionne avec n'importe quel serveur SMTP).
2. Créez l'identifiant Gmail : n8n vous guide dans une connexion OAuth2 (une fenêtre Google s'ouvre, vous autorisez n8n à envoyer des e-mails en votre nom ; aucun mot de passe n'est stocké dans n8n).
3. Paramètres : *To* = votre adresse ; *Subject* = `Résumé des avis clients — semaine du {{ $now.format('dd/MM/yyyy') }}` (en mode Expression) ; *Email Type* = `Text` ; *Message* = `{{ $json.text }}` (en mode Expression : c'est la sortie du nœud IA).
4. **Execute step** : vérifiez votre boîte de réception.

### Étape 5 : tester de bout en bout, puis activer

1. Cliquez sur **Execute workflow** en bas du canevas : les nœuds s'exécutent dans l'ordre, chacun affiche une coche verte et le nombre d'items produits (`1 item`). Un nœud rouge indique une erreur : ouvrez-le, l'onglet *Output* explique la cause (identifiant invalide, champ vide, JSON mal formé…).
2. Renommez les nœuds (double-clic sur le titre) : « Chaque lundi 8 h », « Avis de la semaine », « Résumé par Claude », « E-mail à la direction ». Un workflow lisible est un workflow maintenable ; c'est l'une des bonnes pratiques enseignées dans N8N103.
3. Enregistrez (`Ctrl+S`) puis basculez l'interrupteur **Inactive → Active** (sur certaines versions : **Publish**). À partir de maintenant, le workflow tourne sans vous. L'onglet *Executions* vous montrera chaque lundi ce qui s'est passé.

```
[Chaque lundi 8 h] ──▶ [Avis de la semaine] ──▶ [Résumé par Claude] ──▶ [E-mail à la direction]
  Schedule Trigger        Edit Fields (Set)        Basic LLM Chain            Gmail
                                                     └─ Anthropic Chat Model
```

## 5. Ce que vous avez appris sans vous en rendre compte

| Notion n8n | Ce que vous avez fait | Section N8N101 |
|---|---|---|
| Déclencheur et planification | Schedule Trigger, lundi 8 h, fuseau horaire | Section 1 |
| Nœuds et connexions | Quatre nœuds reliés dans l'ordre | Section 1 |
| Identifiants | Clé API Anthropic, OAuth2 Gmail dans le coffre | Section 1 |
| Exécutions | *Execute step*, *Execute workflow*, onglet *Executions* | Section 1 |
| Structure des données | Items, clés `avis` et `text`, vues Table / JSON / Schema | Section 2 |
| Expressions et mapping | `{{ $json.avis }}`, `{{ $json.text }}`, `$now` | Section 2 |
| Nœuds IA (racine + sous-nœud) | Basic LLM Chain + Anthropic Chat Model | Prépare N8N103 |

🎮 **Défi** — Sans ajouter de nœud, modifiez le workflow pour qu'il tourne **du lundi au vendredi à 18 h** et que l'objet de l'e-mail contienne le **nom du jour** en français. *(Pistes : *Trigger Interval* = `Days` avec les jours cochés, ou `Custom (Cron)` avec `0 18 * * 1-5` ; objet : `{{ $now.setLocale('fr').toFormat('cccc dd LLLL') }}`.)*

## 🧪 Exercice pratique

**Consigne.** Reconstruisez le workflow de cette leçon, puis adaptez-le à **votre** métier en changeant uniquement le contenu du nœud *Edit Fields* et le prompt. Exemples : un commerçant résume les messages Instagram de la semaine ; une responsable RH résume les questions reçues sur la mutuelle ; un artisan résume les demandes de devis. Exportez le workflow (menu `…` → *Download*) : vous obtenez un fichier JSON, que vous joindrez à votre rendu avec une capture d'écran de l'e-mail reçu.

**Critères de réussite.**
1. Le workflow contient exactement quatre nœuds, tous renommés en français, et s'exécute de bout en bout avec des coches vertes.
2. Le prompt utilise au moins une expression `{{ $json… }}` correctement affichée en vert, et impose un format de sortie (parties numérotées, longueur maximale).
3. L'e-mail reçu contient bien le résumé (champ `text`) et un objet daté.
4. Aucune clé API n'apparaît dans le fichier JSON exporté (n8n ne les exporte jamais : vérifiez-le, c'est rassurant).

<details>
<summary>Pistes de correction</summary>

- Nœud rouge sur le modèle Anthropic : clé API absente ou mal collée, ou crédit insuffisant sur la console ; recréez l'identifiant.
- Le modèle répond « je ne vois aucun avis » : le prompt est en mode *Fixed*.
- Gmail refuse l'envoi : reconnectez l'identifiant OAuth2 ; vérifiez que le champ *Message* est en mode Expression.
- L'e-mail arrive vide : le nœud IA a produit `text`, mais vous avez écrit `{{ $json.texte }}` ou `{{ $json.output }}` ; ouvrez le panneau *Input* du nœud Gmail et faites glisser la bonne clé.

</details>

## ✅ Auto-évaluation express

1. Par quel type de nœud commence obligatoirement un workflow n8n ?
2. Que signifie `{{ $json.text }}` dans le nœud Gmail ?
3. Quelle est la différence entre *Execute workflow* et l'interrupteur *Active* ?

<details>
<summary>Réponses</summary>

1. Par un déclencheur (*trigger*) : planifié, webhook, formulaire, e-mail entrant, manuel…
2. Une expression qui insère la valeur de la clé `text` de l'item reçu du nœud précédent (ici, le résumé produit par le nœud IA).
3. *Execute workflow* lance une exécution de test, à la main, une seule fois ; *Active* met le workflow en production : il se déclenchera tout seul selon son déclencheur, et chaque exécution sera consignée dans l'onglet *Executions*.

</details>

## 📚 Pour aller plus loin
- [n8n Academy — N8N101 Essentials: Your First Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N101+2026H2/about) 🇬🇧 — le cours officiel gratuit (2-4 h) que cette leçon prépare ; passez-le pour obtenir votre premier badge n8n. Les cours N8N102 et N8N103 complètent le programme « n8n Foundations » ; une certification officielle chronométrée est annoncée pour fin 2026 (à vérifier sur n8n.io/education).
- [n8n Docs — Learning paths](https://docs.n8n.io/learning-paths) 🇬🇧 — les parcours de lecture recommandés par n8n selon votre profil.
- [n8n Docs — LangChain in n8n](https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md) 🇬🇧 — comprendre les nœuds « racine » (chaînes, agent) et « sous-nœuds » (modèles, mémoire, outils) que vous venez d'utiliser.
- [Make Academy](https://academy.make.com/) 🇬🇧 — l'équivalent gratuit chez Make : « Setting up my first scenario » reproduit le même exercice avec un autre outil ; comparer les deux est très formateur.
