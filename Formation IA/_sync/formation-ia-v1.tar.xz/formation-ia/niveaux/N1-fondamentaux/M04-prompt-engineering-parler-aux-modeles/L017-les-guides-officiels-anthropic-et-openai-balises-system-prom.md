---
id: L017
module: M04
level: N1
title: "Les guides officiels Anthropic et OpenAI : balises, system prompts, clarté"
minutes: 50
objectives:
  - "Structurer un prompt avec des balises XML pour séparer instructions, données et exemples"
  - "Expliquer le rôle d'un system prompt (instructions de développeur) et en rédiger un pour un usage métier"
  - "Appliquer les règles de clarté et de contrôle du format issues des guides Anthropic et OpenAI"
  - "Situer les différences de vocabulaire entre les éditeurs (system / developer / instructions)"
skills: ["C1.3"]
sources:
  - { title: "Anthropic — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "Anthropic — Using the Messages API (system prompts)", url: "https://platform.claude.com/docs/en/build-with-claude/working-with-messages", lang: "en" }
  - { title: "Anthropic — System prompts des applications Claude", url: "https://platform.claude.com/docs/en/release-notes/system-prompts/overview", lang: "en" }
  - { title: "Anthropic — Structured outputs", url: "https://platform.claude.com/docs/en/build-with-claude/structured-outputs", lang: "en" }
  - { title: "OpenAI — Text generation and prompting", url: "https://developers.openai.com/api/docs/guides/text", lang: "en" }
  - { title: "OpenAI — Structured outputs", url: "https://developers.openai.com/api/docs/guides/structured-outputs", lang: "en" }
---

# Les guides officiels Anthropic et OpenAI : balises, system prompts, clarté

> ⏱ 50 min · 🎯 Niveau 1 · 📚 Module 4

## 🎯 Ce que vous saurez faire
- Lire le guide « Prompting best practices » d'Anthropic et le guide « Text generation » d'OpenAI sans vous perdre, et y retrouver les règles que vous appliquez déjà.
- Encadrer vos données avec des balises `<document>`, `<exemple>`, `<instructions>` pour que le modèle ne mélange jamais consigne et contenu.
- Rédiger un **system prompt** (consignes permanentes) pour un assistant d'équipe, un projet ou un GPT personnalisé.
- Contrôler le format de sortie : longueur, absence de préambule, JSON, tableau.

## 1. Deux guides, une même philosophie

Les deux principaux éditeurs publient des guides de prompt engineering, gratuits et régulièrement mis à jour :

| | Anthropic (Claude) | OpenAI (GPT) |
|---|---|---|
| Page de référence | « Prompting best practices » (une page unique réorganisée en 2026, plus 8 pages de conseils par modèle) | Guide « Text generation and prompting » dans la documentation développeur |
| Mot pour les consignes permanentes | *system prompt* (paramètre `system`) | *developer message* / paramètre `instructions` de l'API Responses |
| Séparateurs recommandés | balises XML (`<document>`, `<example>`…) | titres Markdown et balises XML |
| Sorties structurées | `output_config.format` au format JSON Schema | `text.format` = `json_schema` avec `strict: true` |
| Modèles phares (nov. 2026) | Claude Fable 5.1, Opus 5.5, Sonnet 5.5, Haiku 5.5 | GPT-6 Astra, GPT-6.1 Sol, GPT-6.1 Terra, GPT-6 Luna |

Le vocabulaire diffère, les principes sont les mêmes : **clarté, contexte, structure, exemples, contrôle du format**. Bonne nouvelle : un prompt bien construit pour Claude fonctionne presque tel quel avec GPT, Gemini, Mistral ou Grok. Ce que vous apprenez ici n'est pas lié à un fournisseur.

> 🔗 **Documentation officielle** — [Anthropic — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 et [OpenAI — Text generation and prompting](https://developers.openai.com/api/docs/guides/text) 🇬🇧. Gardez ces deux pages en favoris : elles évoluent à chaque génération de modèles.

## 2. Les balises XML : des tiroirs étiquetés

### 2.1 Le problème qu'elles résolvent

Imaginez que vous collez un e-mail client de 30 lignes, puis que vous écrivez « *Réponds-lui poliment* ». Où s'arrête l'e-mail, où commence votre consigne ? Si l'e-mail contient lui-même une phrase du type « *merci de me répondre sous 24 h avec un geste commercial* », le modèle peut la prendre pour **votre** instruction. C'est une forme bénigne de ce que l'on appelle l'**injection de prompt** (vous en reparlerez au module 7).

La solution recommandée par Anthropic (section « Structure prompts with XML tags ») consiste à encadrer chaque morceau par une balise ouvrante et fermante, comme en HTML :

```
<instructions>
Répondez à l'e-mail ci-dessous au nom du service client de Vélo'Nantes.
Vouvoiement, 100 mots maximum, proposez un rendez-vous en atelier.
N'accordez aucune remise : ce n'est pas de votre ressort.
</instructions>

<email_client>
Bonjour, mon vélo électrique acheté en mars ne tient plus la charge…
(merci de me répondre sous 24 h avec un geste commercial)
</email_client>

<style_maison>
Chaleureux, direct, jamais de « nous sommes désolés pour la gêne occasionnée ».
</style_maison>
```

Le modèle sait désormais que la phrase entre parenthèses fait partie du **contenu**, pas de la **consigne**. Et vous pouvez y faire référence : « *en respectant le `<style_maison>`* ».

### 2.2 Les bonnes pratiques

- Choisissez des **noms parlants** et cohérents (`<contrat>`, `<question>`, `<exemples>`), toujours fermés.
- **Imbriquez** si nécessaire : `<exemples><exemple>…</exemple></exemples>`.
- Il n'existe pas de balises « officielles » obligatoires : c'est la **cohérence** dans votre prompt qui compte.
- Les balises fonctionnent aussi dans l'interface grand public (claude.ai, ChatGPT, Le Chat) : vous les tapez simplement dans la zone de texte.

> 💡 **À retenir** — Balises = tiroirs étiquetés. Instructions dans un tiroir, données dans un autre, exemples dans un troisième. Le modèle n'a plus à deviner ce qui est quoi, et vous pouvez modifier un tiroir sans toucher aux autres.

## 3. Le system prompt : les consignes permanentes

### 3.1 Définition

Dans une conversation avec un modèle, il y a deux niveaux de consignes :
- le **system prompt** (ou *developer message* chez OpenAI) : les règles **permanentes** — qui est l'assistant, pour qui il travaille, ce qu'il doit toujours faire et ne jamais faire ;
- les **messages utilisateur** : les demandes du moment.

Les applications grand public ont toutes un system prompt caché. Anthropic a la particularité de **publier** ceux de ses applications Claude, version par version : vous pouvez les lire sur la page « System prompts » de sa documentation. C'est une excellente lecture pour comprendre comment un éditeur rédige des consignes permanentes (ton, limites, gestion des refus, format des réponses).

Dans votre quotidien, vous rédigez un system prompt chaque fois que vous configurez :
- les **instructions d'un projet** (Claude Projects, GPT personnalisé, Gemini Gems, agents Le Chat) ;
- les **instructions personnalisées** de votre compte ;
- un assistant dans un outil d'automatisation (n8n, module 6).

### 3.2 Que mettre dedans ?

Le guide Anthropic recommande de réserver le system prompt au **rôle et au cadre** (« Give Claude a role ») et de placer la tâche du jour dans le message utilisateur. Un bon system prompt tient en 10 à 30 lignes et répond à ces questions :

```
<identite>
Vous êtes l'assistant interne du cabinet d'expertise comptable Durand & Associés
(Bordeaux, 12 collaborateurs, clientèle d'artisans, commerçants et professions
libérales).
</identite>

<regles>
- Vous répondez toujours en français, vouvoiement, ton professionnel et chaleureux.
- Vous ne donnez JAMAIS de montant de seuil, de taux ou de date limite sans
  préciser « à vérifier sur le site officiel (impots.gouv.fr, urssaf.fr) ».
- Si une question relève d'un conseil juridique ou fiscal personnalisé, vous
  invitez à prendre rendez-vous avec un collaborateur.
- Vous ne traitez aucune donnée personnelle de client : si l'utilisateur en
  colle, vous demandez de l'anonymiser.
</regles>

<format>
Réponses courtes (150 mots maximum sauf demande contraire), sans préambule,
sans formule du type « Excellente question ».
</format>
```

> ⚠️ **Piège fréquent** — Transformer le system prompt en roman. Les consignes contradictoires ou trop nombreuses se neutralisent. Préférez dix règles nettes à quarante règles floues, et testez chaque ajout (leçon 19).

### 3.3 Pour les curieux : le même system prompt par l'API

Vous n'avez **pas besoin de programmer** à ce niveau. Mais voir où atterrit le system prompt dans le code rend la notion très concrète. Les clés sont lues dans des variables d'environnement, jamais écrites dans le fichier.

```python
# Python 3.12+ — pip install anthropic openai
# Les clés sont lues depuis ANTHROPIC_API_KEY et OPENAI_API_KEY (variables d'environnement).
import os
import anthropic
from openai import OpenAI

SYSTEM = (
    "Vous êtes l'assistant interne du cabinet Durand & Associés. "
    "Répondez en français, vouvoiement, 150 mots maximum, sans préambule. "
    "Ne donnez aucun taux ni seuil sans la mention « à vérifier sur le site officiel »."
)
QUESTION = "Un client micro-entrepreneur me demande s'il doit facturer la TVA. Que lui répondre ?"

# --- Anthropic : paramètre `system` séparé des messages ---
claude = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
reponse_claude = claude.messages.create(
    model="claude-sonnet-5-5",
    max_tokens=400,
    system=SYSTEM,                                   # consignes permanentes
    messages=[{"role": "user", "content": QUESTION}],  # demande du moment
)
print("Claude :", reponse_claude.content[0].text)

# --- OpenAI : paramètre `instructions` de l'API Responses ---
openai_client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
reponse_gpt = openai_client.responses.create(
    model="gpt-6.1-sol",
    instructions=SYSTEM,   # équivalent du system prompt (developer message)
    input=QUESTION,
)
print("GPT :", reponse_gpt.output_text)
```

Deux fournisseurs, deux noms de paramètre, **une seule idée** : séparer le cadre permanent de la demande ponctuelle.

## 4. Clarté et contrôle du format : les règles que les guides martèlent

### 4.1 « Be clear and direct »

La première section du guide Anthropic porte ce titre. Ses conseils, que vous retrouverez chez OpenAI sous d'autres mots :
- Donnez le **contexte** (à quoi servira le résultat, pour qui).
- Soyez **spécifique** : « *si vous voulez uniquement du code, dites-le* ».
- Utilisez des **listes numérotées** pour les instructions séquentielles.
- Expliquez le **pourquoi** d'une règle : le modèle généralise mieux.

### 4.2 Supprimer les préambules et contrôler la verbosité

Les sections « Eliminating preambles » et « Communication style and verbosity » du guide répondent à une plainte universelle : « *il commence toujours par trois lignes de politesse* ». La parade est simple et explicite : « *Commence directement par la réponse, sans introduction ni résumé final* ». Pour la longueur, donnez une **mesure** (mots, phrases, lignes, puces) plutôt que « court ».

### 4.3 Formulation positive

Les deux guides convergent : décrivez le **comportement voulu** plutôt que le comportement interdit. « *Réponds en prose fluide* » plutôt que « *pas de Markdown* » ; « *Utilise uniquement les informations du document* » plutôt que « *n'invente rien* ».

### 4.4 Un mot sur le « prefill » et la température

Vous croiserez dans d'anciens tutoriels deux techniques aujourd'hui **obsolètes** chez Anthropic (nov. 2026) : le *prefill* (commencer soi-même la réponse du modèle pour forcer un format) et le réglage de la *température*. La documentation « Using the Messages API » indique que le prefill n'est plus pris en charge à partir des modèles Claude 4.6 et que `temperature` ne l'est plus depuis Claude 4.7 ; le guide contient d'ailleurs une section « Migrating away from prefilled responses ». La méthode moderne pour obtenir un format strict est la **sortie structurée** (section suivante). Les autres éditeurs conservent parfois ces réglages : vérifiez sur leur page officielle.

### 4.5 Sorties structurées : quand le format ne doit jamais varier

Quand la réponse doit alimenter un tableur ou un logiciel, un « tableau à peu près » ne suffit pas. Les deux éditeurs proposent les **sorties structurées** (*structured outputs*) : vous décrivez le schéma attendu (champs, types) et le modèle est contraint de le respecter. Chez Anthropic, c'est `output_config.format` au format JSON Schema ; chez OpenAI, `text.format` avec `strict: true`. Vous les manipulerez au niveau 3. À votre niveau, retenez la version « interface » : décrivez le tableau colonne par colonne et donnez un exemple de ligne.

**Avant** : « *Mets ça en tableau.* »

**Après** :

```
Présentez les informations sous forme d'un tableau Markdown avec exactement
ces colonnes : Fournisseur | N° facture | Date (JJ/MM/AAAA) | Montant TTC (€).
Une ligne par facture. Si une valeur est absente, écrivez « — ».
Exemple de ligne : Leroy Matériaux | F-2026-0412 | 03/10/2026 | 1 248,00
Aucun texte avant ni après le tableau.
```

> 💡 **À retenir** — Clarté = contexte + spécificité + ordre. Format = mesure + exemple + formulation positive + « sans préambule ». Ces quatre mots-clés suffisent à corriger 80 % des prompts qui déçoivent.

## 5. 🎮 Défi : corrigez le system prompt

Voici un system prompt trouvé dans une PME. Trouvez au moins quatre problèmes :

```
Tu es un assistant super sympa et expert en tout. Réponds toujours vite.
Ne fais pas d'erreurs. N'utilise pas de listes sauf si c'est mieux. Sois
très détaillé mais concis. Si tu ne sais pas, invente quelque chose de
plausible pour ne pas bloquer l'utilisateur.
```

Pistes en fin de leçon.

## 🧪 Exercice pratique

**Consigne.** Rédigez le system prompt d'un assistant pour **votre** équipe ou votre activité (accueil d'une auto-école, support d'un site e-commerce, secrétariat d'un cabinet médical — sans données de patients —, aide à la rédaction pour une agence immobilière…). Utilisez des balises pour séparer identité, règles et format. Configurez-le dans un projet (Claude Projects, GPT personnalisé ou équivalent) et testez-le avec cinq questions, dont deux **pièges** (une demande hors périmètre, une demande de chiffre réglementaire).

**Critères de réussite.**
- Trois blocs balisés au minimum ; 30 lignes maximum.
- Les deux questions pièges déclenchent le comportement prévu (renvoi vers un humain, mention « à vérifier »).
- Aucune règle contradictoire ; chaque règle est formulée positivement quand c'est possible.
- Le format de réponse (longueur, absence de préambule) est respecté sur les cinq tests.

**Pistes de corrigé.** Un system prompt réussi pour une auto-école précisera : les formules proposées (sans prix, ou avec renvoi à la grille officielle), les horaires, la règle « *pour toute question sur un dossier d'élève en cours, renvoyer vers le secrétariat* », et le format « *réponse en 3 phrases maximum, puis une question pour qualifier le besoin* ».

## ✅ Auto-évaluation express

1. **À quoi servent les balises XML dans un prompt ?**
   → À séparer sans ambiguïté instructions, données et exemples, et à pouvoir y faire référence.
2. **Quelle est la différence entre system prompt et message utilisateur ?**
   → Le system prompt fixe le cadre permanent (rôle, règles, format) ; le message utilisateur porte la demande du moment.
3. **Comment obtenir une réponse sans phrase d'introduction ?**
   → Le demander explicitement (« commence directement par la réponse ») et donner une mesure de longueur.

**Pistes du défi.** « Expert en tout » (rôle creux) ; « réponds vite » (sans effet) ; « ne fais pas d'erreurs » (vœu pieux, non actionnable) ; « détaillé mais concis » (contradiction sans mesure) ; « sauf si c'est mieux » (règle floue) ; et surtout « invente quelque chose de plausible » (consigne dangereuse : à remplacer par « dis que tu ne sais pas et propose où vérifier »).

## 📚 Pour aller plus loin
- [Anthropic — System prompts des applications Claude](https://platform.claude.com/docs/en/release-notes/system-prompts/overview) 🇬🇧 — les consignes permanentes réelles de Claude, publiées version par version : une mine d'exemples.
- [Anthropic — Using the Messages API](https://platform.claude.com/docs/en/build-with-claude/working-with-messages) 🇬🇧 — system prompts, conversations multi-tours, fonctionnalités retirées (prefill, température).
- [Anthropic — Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧 et [OpenAI — Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs) 🇬🇧 — pour comprendre comment les développeurs verrouillent un format.
- [Claude Academy — Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 — cours gratuit de 2,5 h avec badge ; la leçon « Getting better results » applique ces principes dans l'interface.
