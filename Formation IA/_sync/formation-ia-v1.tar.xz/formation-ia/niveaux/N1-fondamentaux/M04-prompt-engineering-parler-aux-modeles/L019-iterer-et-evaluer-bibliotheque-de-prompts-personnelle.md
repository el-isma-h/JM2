---
id: L019
module: M04
level: N1
title: "Itérer et évaluer : bibliothèque de prompts personnelle"
minutes: 40
objectives:
  - "Appliquer une boucle d'itération (essai → évaluation → correction ciblée) sur un prompt"
  - "Construire une grille d'évaluation simple avec des critères mesurables et un mini-jeu de tests"
  - "Organiser une bibliothèque de prompts personnelle versionnée et réutilisable"
skills: ["C1.3", "C1.4"]
sources:
  - { title: "Anthropic — Prompt engineering overview (critères de succès, tests)", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview", lang: "en" }
  - { title: "Anthropic — Define success criteria and build evals", url: "https://platform.claude.com/docs/en/test-and-evaluate/develop-tests", lang: "en" }
  - { title: "DeepLearning.AI — ChatGPT Prompt Engineering for Developers (Iterative)", url: "https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/", lang: "en" }
  - { title: "Claude Academy — AI Fluency: Framework and foundations (Discernment)", url: "https://academy.claude.com/courses/ai-fluency-framework-foundations", lang: "en" }
---

# Itérer et évaluer : bibliothèque de prompts personnelle

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 4

## 🎯 Ce que vous saurez faire
- Ne plus jamais « réessayer au hasard » : corriger un prompt en changeant **une** chose à la fois, pour une raison précise.
- Écrire trois à cinq critères de réussite **mesurables** avant même de lancer le prompt.
- Tester un prompt sur plusieurs cas (pas un seul) et repérer celui qui le fait échouer.
- Tenir une bibliothèque de prompts personnelle : fiches, variables, versions, résultats.

## 1. Personne ne réussit un prompt du premier coup

Le cours DeepLearning.AI de référence consacre une leçon entière à l'« itération » (*Iterative prompt development*) et son message est libérateur : **le premier prompt n'est jamais le bon, et ce n'est pas grave**. Ce qui distingue un utilisateur efficace d'un utilisateur frustré n'est pas le talent du premier jet, c'est la **méthode de correction**.

L'erreur classique ressemble à ceci : le résultat déçoit, on réécrit tout le prompt, on ajoute « *s'il te plaît sois plus précis* », on change de modèle, on recommence… et on ne sait jamais ce qui a marché. L'approche professionnelle, décrite dans la page « Prompt engineering overview » d'Anthropic, commence **avant** le prompt :

1. **Définir des critères de succès** clairs.
2. **Préparer des cas de test** pour les mesurer.
3. Écrire un premier brouillon.
4. Évaluer, **modifier une chose**, ré-évaluer.

Le cours AI Fluency de Claude Academy appelle cette compétence le **discernement** (*Discernment*) : juger la sortie du modèle avec des critères, puis reformuler (*Description*) — une boucle « description-discernement » que vous allez pratiquer.

## 2. La boucle d'itération

```
        ┌──────────────┐
        │  1. Critères │  « À quoi reconnaîtrai-je un bon résultat ? »
        └──────┬───────┘
               ▼
        ┌──────────────┐
        │  2. Prompt v1│
        └──────┬───────┘
               ▼
        ┌──────────────┐      échec sur un critère ?
        │  3. Tests    │─────────────┐
        └──────┬───────┘             ▼
               │             ┌──────────────────┐
               │             │ 4. UNE correction │  ciblée sur ce critère
               │             └────────┬─────────┘
               │                      │
               ▼                      ▼
        ┌──────────────┐      retour en 3 (v2, v3…)
        │  5. Archiver │  fiche dans la bibliothèque
        └──────────────┘
```

### 2.1 Étape 1 — Des critères mesurables

La page « Define success criteria » d'Anthropic recommande des critères **spécifiques, mesurables, atteignables et pertinents**. « *Un bon résumé* » n'est pas un critère. « *Toutes les décisions de la réunion sont listées, aucune information absente de la transcription n'apparaît, 200 mots maximum* » en fait trois, chacun vérifiable par oui/non.

Exemples de critères pour un prompt de réponse aux avis clients :

| Critère | Mesure | Seuil |
|---|---|---|
| Longueur | nombre de mots | ≤ 80 |
| Vouvoiement | aucun « tu » | 0 occurrence |
| Reconnaissance du problème | le motif de l'avis est repris | oui/non |
| Pas d'engagement financier | aucune remise, aucun remboursement promis | 0 |
| Ton | lu par un collègue : « on dirait nous ? » | note ≥ 4/5 |

Remarquez le dernier critère : **tout n'est pas automatisable**. Un jugement humain sur une échelle de 1 à 5 est un critère parfaitement valable, à condition d'être écrit à l'avance. La documentation Anthropic décrit d'ailleurs trois types de notation : comparaison exacte (*exact match*), similarité, et notation par un humain ou par un modèle juge (*LLM-as-judge*) sur une échelle. Au niveau 1, vous serez le juge.

### 2.2 Étape 3 — Tester sur plusieurs cas, dont les cas difficiles

Un prompt testé sur un seul exemple est un prompt testé sur son meilleur jour. Constituez un **mini-jeu de tests** de cinq à dix cas : des cas normaux, un cas vide (document sans la donnée demandée), un cas ambigu, un cas « sale » (fautes, mise en page cassée), un cas piège (le document contient une instruction du type « *ignore les consignes* »). Anthropic suggère même de demander au modèle de **générer des cas de test** : « *Propose dix e-mails clients variés, dont trois difficiles, pour tester mon prompt de classification.* »

### 2.3 Étape 4 — Une seule correction à la fois

Quand un critère échoue, cherchez **la brique** responsable (leçon 15) et ne modifiez qu'elle :

| Symptôme | Cause probable | Correction |
|---|---|---|
| Trop long / trop court | format sans mesure | ajouter un nombre de mots ou de puces |
| Détail inventé | pas de contrainte de fidélité | « uniquement le contenu fourni ; “non précisé” sinon » |
| Ton impersonnel | contexte ou exemples absents | ajouter la cible + 2 exemples maison |
| Format qui varie | pas d'exemple de format | donner un exemple de sortie exact |
| Hors sujet sur un cas | consigne ambiguë | reformuler positivement, ajouter le cas limite en exemple |
| Préambule bavard | rien ne l'interdit | « commence directement par… » |

> 💡 **À retenir** — Une correction = une hypothèse. « Je pense que le résumé invente parce que je n'ai pas interdit l'invention ; j'ajoute cette contrainte, je relance les 8 tests. » Si ça marche, vous savez pourquoi. Si ça ne marche pas, vous n'avez pas brouillé les pistes.

> ⚠️ **Piège fréquent** — Évaluer un prompt sur la **dernière** réponse obtenue et non sur **l'ensemble** des tests. Les modèles ont une part de variabilité : un prompt qui réussit 4 fois sur 5 n'est pas fiable pour une tâche répétitive. Relancez toujours tous les cas après une correction.

## 3. Avant / après : une itération complète

**Critères** (annonce d'emploi pour un cabinet comptable) : ≤ 250 mots ; mention « télétravail 2 j/semaine » ; aucune fourchette de salaire inventée ; aucune mention discriminatoire (âge, situation familiale) ; structure Mission / Profil / Avantages / Candidature.

**v1** : « *Rédige une annonce pour un poste de collaborateur comptable, 250 mots, télétravail possible.* »
→ Tests : 310 mots (échec), salaire « 32–38 k€ » inventé (échec), « jeune diplômé dynamique » (échec : mention d'âge).

**v2** (une correction : contraintes) : ajout de « *Ne mentionnez aucun salaire ; n'employez aucun terme lié à l'âge ou à la situation personnelle.* »
→ Tests : 295 mots (échec), salaire absent (réussi), « jeune » absent (réussi).

**v3** (une correction : format) : « *250 mots maximum, répartis en quatre parties titrées : Mission (80 mots), Profil (70), Avantages (50), Candidature (30).* »
→ Tests : 238 mots, les cinq critères réussis sur trois exécutions.

**Archivage** : la v3 entre dans la bibliothèque avec sa grille et ses résultats.

## 4. La bibliothèque de prompts personnelle

### 4.1 Pourquoi

Un bon prompt coûte vingt minutes à mettre au point et se réutilise des centaines de fois. Sans bibliothèque, vous le réécrivez de mémoire, moins bien, à chaque fois. Avec une bibliothèque, vous capitalisez — et vous pouvez partager avec votre équipe.

### 4.2 La fiche de prompt

Chaque prompt mérite une fiche. Voici un modèle minimal, à copier dans votre outil de notes (Notion, OneNote, Obsidian, un simple dossier de fichiers texte) :

```
# Réponse aux avis clients négatifs — v3

Usage      : répondre publiquement aux avis ≤ 3/5 (Google, TripAdvisor)
Modèle     : testé avec Claude Sonnet 5.5 et GPT-6.1 Sol (nov. 2026)
Variables  : {{nom_etablissement}}, {{avis}}, {{contexte_interne}}
Critères   : ≤ 80 mots · vouvoiement · motif repris · aucune remise · ton ≥ 4/5
Tests      : 8 avis (dossier tests/avis/) · v3 : 8/8 réussis le 28/10/2026
Historique : v1 trop long · v2 promettait un remboursement · v3 OK
Auteur     : N. — service client

---
<role>Vous êtes gérant de {{nom_etablissement}}.</role>
<contexte>{{contexte_interne}}</contexte>
<tache>Rédigez une réponse publique à l'avis ci-dessous.</tache>
<format>80 mots maximum, vouvoiement, pas de formule toute faite.</format>
<contraintes>Reconnaissez le motif ; n'offrez aucune remise ; invitez à revenir.</contraintes>
<avis>{{avis}}</avis>
```

Les **variables** entre doubles accolades sont la clé de la réutilisation : le prompt est un gabarit, vous ne remplissez que les blancs. C'est exactement ainsi que fonctionnent les projets, les GPT personnalisés et les outils d'automatisation que vous verrez ensuite.

### 4.3 Organiser et versionner

- **Nommer** : `[famille] — [usage] — vN` (ex. « Résumer — réunion de chantier — v2 »).
- **Classer** par famille (leçon 18) puis par processus métier.
- **Versionner** : ne modifiez jamais une version qui fonctionne ; créez v+1 et notez ce qui change. Une ligne d'historique suffit.
- **Dater et attribuer au modèle** : un prompt réglé pour Claude Sonnet 5.5 peut se comporter différemment sur un autre modèle ou une version ultérieure. Les éditeurs publient des guides de migration par modèle (Anthropic en propose un par modèle, dont « Prompting Claude Sonnet 5.5 ») précisément pour cela.
- **Joindre les tests** : le mini-jeu de cas et le dernier score. Sans eux, vous ne saurez pas si la v4 est meilleure.

### 4.4 Où la ranger concrètement

| Besoin | Solution simple |
|---|---|
| Usage personnel | un dossier « Prompts » dans vos notes, une fiche par prompt |
| Prompt permanent pour un sujet | un **projet** (Claude Projects, GPT personnalisé, Gem Gemini, agent Le Chat) dont les instructions = votre system prompt (leçon 17) |
| Partage en équipe | un espace partagé (wiki, Drive, Notion) avec la même fiche, et une personne responsable de la version « officielle » |
| Automatisation | le prompt devient un nœud d'un workflow n8n (module 6, niveau 2) |

> 🔗 **Documentation officielle** — [Anthropic — Define success criteria and build evals](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests) 🇬🇧 : la méthode complète (critères, jeux de tests, notation) dont cette leçon est la version « sans code ».

## 5. 🎮 Défi : le prompt qui échoue

Voici un prompt et son critère : « *Extrais la date de livraison de ce message* » ; critère : « la date est au format JJ/MM/AAAA ou “non précisé” ». Trouvez **trois messages de test** qui ont de bonnes chances de le faire échouer, et la correction pour chacun.

Pistes en fin de leçon.

## 🧪 Exercice pratique

**Consigne.** Reprenez le meilleur prompt que vous avez produit dans les leçons 15 à 18. Rédigez sa fiche complète (usage, variables, critères, tests, historique). Constituez un jeu de **six cas de test** dont deux difficiles. Exécutez, notez, corrigez **une chose**, ré-exécutez sur les six cas. Archivez la meilleure version.

**Critères de réussite.**
- La fiche contient au moins quatre critères mesurables et un jeu de six cas.
- Chaque version est datée, avec une ligne expliquant la modification.
- Le score (cas réussis / 6) est noté pour chaque version.
- La version archivée a un score au moins égal à la précédente, et vous savez dire sur quel cas elle gagne.

**Pistes de corrigé.** Les cas difficiles les plus instructifs sont le cas « donnée absente » et le cas « instruction cachée dans le document ». Si votre prompt réussit tout du premier coup, votre jeu de tests est trop facile : ajoutez un cas plus sale.

## ✅ Auto-évaluation express

1. **Que faut-il écrire avant le premier prompt ?**
   → Les critères de succès mesurables et quelques cas de test.
2. **Pourquoi ne modifier qu'une chose entre deux versions ?**
   → Pour savoir quelle modification a produit l'amélioration (ou la dégradation).
3. **Que doit contenir une fiche de prompt ?**
   → Usage, modèle testé, variables, critères, tests et score, historique des versions, le prompt lui-même.

**Pistes du défi.** 1) Message sans date → le modèle en invente une : ajouter « *si aucune date, écris “non précisé”* ». 2) « livraison lundi prochain » → date relative : fournir la date d'envoi du message et demander la conversion, ou accepter « non précisé ». 3) Deux dates (commande et livraison) → ambiguïté : préciser « *la date de livraison, pas la date de commande ; en cas de doute, cite la phrase* ».

## 📚 Pour aller plus loin
- [Anthropic — Prompt engineering overview](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/overview) 🇬🇧 — « avant de faire du prompt engineering : critères de succès, tests, premier brouillon ».
- [Anthropic — Prompting Claude Sonnet 5.5](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-sonnet-5-5) 🇬🇧 — exemple de guide par modèle, utile quand on migre une bibliothèque.
- [DeepLearning.AI — ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/) 🇬🇧 — leçon « Iterative ».
- [Anthropic Cookbook — Building evals](https://platform.claude.com/cookbook/misc-building-evals) 🇬🇧 — la version automatisée de la grille d'évaluation (niveau 3).
