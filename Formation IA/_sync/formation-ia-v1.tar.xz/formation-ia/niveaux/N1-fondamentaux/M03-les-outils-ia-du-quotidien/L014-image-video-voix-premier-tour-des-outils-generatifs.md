---
id: L014
module: M03
level: N1
title: "Image, vidéo, voix : premier tour des outils génératifs"
minutes: 40
objectives:
  - "Identifier les principaux outils de génération d'images, de vidéos, de voix et de musique disponibles en 2026, fermés et ouverts"
  - "Rédiger un prompt d'image efficace (sujet, style, cadrage, contraintes) et itérer sur le résultat"
  - "Transcrire un enregistrement et produire une voix de synthèse pour un usage professionnel simple"
  - "Appliquer les règles de base : transparence (AI Act art. 50), droit à l'image, droit d'auteur, mention de l'origine"
skills: ["C1.2", "C1.6"]
sources:
  - { title: "OpenAI — Image generation guide", url: "https://developers.openai.com/api/docs/guides/image-generation", lang: "en" }
  - { title: "OpenAI — Pricing (images, audio, transcription)", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "Gemini API — Image generation", url: "https://ai.google.dev/gemini-api/docs/image-generation", lang: "en" }
  - { title: "xAI — Image generation", url: "https://docs.x.ai/developers/tools/image-generation", lang: "en" }
  - { title: "Mistral AI — Voxtral TTS 3", url: "https://docs.mistral.ai/models/voxtral-mini-tts-3-0", lang: "en" }
  - { title: "Hugging Face — Diffusion Course", url: "https://huggingface.co/learn/diffusion-course", lang: "en" }
  - { title: "Hugging Face — Audio Course", url: "https://huggingface.co/learn/audio-course", lang: "en" }
  - { title: "Réponse ministérielle Sénat — deepfakes et sanctions", url: "https://www.senat.fr/questions/base/2025/qSEQ251006478.html", lang: "fr" }
---

# Image, vidéo, voix : premier tour des outils génératifs

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 3

## 🎯 Ce que vous saurez faire
- Nommer les grands outils génératifs 2026 pour l'image, la vidéo, la voix et la musique, et savoir lesquels sont ouverts (exécutables chez vous).
- Écrire un prompt d'image qui donne un résultat exploitable du premier coup, puis l'améliorer.
- Transcrire une réunion et générer une voix de synthèse pour un message simple.
- Respecter les trois règles qui évitent les ennuis : transparence, droit à l'image, droit d'auteur.

## 1. Comment une machine « peint »

Les générateurs d'images modernes reposent sur des **modèles de diffusion** : pendant l'entraînement, on apprend au modèle à retirer progressivement du « bruit » (une neige de pixels aléatoires) pour retrouver une image ; à l'usage, on part d'un bruit pur et on le débruite étape par étape en le guidant avec votre texte. Un modèle de langage traduit d'abord votre phrase en une représentation numérique que le modèle de diffusion sait suivre. La vidéo généralise l'idée à des séquences d'images cohérentes ; la voix de synthèse (*text-to-speech*, TTS) et la musique suivent des principes voisins ; la transcription (*speech-to-text*, STT) fait le chemin inverse, de l'audio au texte.

Anecdote : en 2015, les premières images « rêvées » par un réseau de neurones (DeepDream, Google) ressemblaient à des hallucinations de chiens multicolores. En 2022, DALL·E 2, Midjourney et Stable Diffusion ont rendu la génération crédible ; en 2026, la frontière entre photo et synthèse est souvent invisible à l'œil nu — d'où les règles de la section 6.

> 💡 **À retenir** — Un générateur d'images ne « cherche » pas une photo existante : il en fabrique une nouvelle, pixel par pixel. C'est pourquoi il peut produire un paysage qui n'existe pas… ou un visage qui ressemble à quelqu'un sans l'avoir voulu.

## 2. Image : le panorama 2026

| Outil (nov. 2026) | Éditeur | Accès | Ouvert ? | Repère de coût (sourcé) |
|---|---|---|---|---|
| gpt-image-2.5 (Sunburst, Flare), gpt-image-2 | OpenAI | ChatGPT, API | non | API : 8 $ par million de tokens d'image en entrée / 30 $ en sortie (2.5) ; 4 $ / 15 $ (gpt-image-2) |
| Nano Banana 2.1 / 2 / Pro | Google | Gemini, API | non | API : environ 0,034 $ par image 1K (Nano Banana 2.1) |
| Grok Imagine Image 2.0 | xAI | Grok, API | non | API : 0,04 à 0,08 $ par image |
| Midjourney v7 | Midjourney | web, Discord | non | abonnement — voir page tarifs officielle |
| FLUX.1 Schnell | Black Forest Labs | local, API tierces | **oui (Apache 2.0)** | gratuit en local |
| Stable Diffusion 3.5 Large | Stability AI | local | oui (Stability Community License) | gratuit en local sous conditions |
| ComfyUI | communauté | local (interface à nœuds) | oui | gratuit |

Sources : pages Pricing OpenAI, Gemini API et xAI (nov. 2026) ; fiches Hugging Face pour FLUX et SD 3.5. Dans les applications grand public (ChatGPT, Gemini, Grok, Le Chat), la génération est incluse dans votre offre avec des quotas : **consultez la page tarifs officielle** de chacun.

### Prise en main en quatre étapes (valable partout)
1. **Décrivez le sujet** précisément : « une vitrine de fleuriste » plutôt que « quelque chose de joli ».
2. **Fixez le style et le support** : photo réaliste, illustration plate, aquarelle, 3D ; affiche A4, bannière 16:9, carré pour Instagram.
3. **Cadrez et éclairez** : plan large ou gros plan, lumière du matin, fond uni.
4. **Posez les contraintes** : « sans texte », « sans personne identifiable », « couleurs de la charte : vert #2E7D32 et blanc ».

```
Photo réaliste d'une vitrine de fleuriste de quartier à Lyon, pivoines
roses et eucalyptus, lumière douce de fin d'après-midi, plan frontal,
format 16:9, sans texte, sans personne visible, style éditorial.
```

Puis itérez : « même scène, de nuit » ; « remplace les pivoines par des tulipes » ; « version illustration plate pour une affiche ». Les outils 2026 conservent la cohérence d'une variation à l'autre (*editing*) : vous pouvez aussi envoyer une photo de votre produit et demander une mise en scène.

> ⚠️ **Piège fréquent** — Les mains, le texte dans l'image et les logos restent les points faibles. Demandez « sans texte » et ajoutez vos mots dans un logiciel de mise en page : le résultat sera propre et vous garderez la maîtrise de la typographie.

## 3. Vidéo : impressionnant, coûteux, à utiliser avec méthode

Les générateurs de vidéo (texte → vidéo ou image → vidéo) sont les outils qui progressent le plus vite : **Sora** (OpenAI), **Veo** (Google DeepMind), **Runway**, **Kling** (Kuaishou) et **Grok Imagine Video** (xAI, à partir de 0,02 $ la seconde en API, nov. 2026). Google liste aussi un modèle vidéo `gemini-omni-1.1-flash` dans son catalogue (nov. 2026). Les accès grand public passent par les abonnements (ChatGPT, Gemini, X Subscription Premium pour la vidéo chez Grok) : **tarifs à vérifier sur les pages officielles**.

**Bons usages en entreprise** : clips de quelques secondes pour les réseaux sociaux, animation d'un visuel produit, fond d'écran de salon, storyboard avant un vrai tournage. **Limites** : durée courte (quelques secondes à une minute), physique parfois fantaisiste, texte et mains imparfaits, coût élevé par seconde, et surtout le risque de **deepfake** : ne générez jamais une personne réelle sans son accord écrit (section 6).

## 4. Voix : transcrire, parler, traduire

### Transcription (speech-to-text)
- **Whisper** (OpenAI, licence MIT) : le modèle ouvert de référence, exécutable sur votre ordinateur ; intégré dans de nombreux logiciels de prise de notes.
- **gpt-transcribe** (OpenAI) : 0,0045 $ par minute en API (nov. 2026) ; **Voxtral Mini Transcribe 3** (Mistral) : 0,0035 $ par minute ; Gemini propose `gemini-3.5-transcribe`. Une réunion d'une heure coûte donc **moins de 30 centimes** à transcrire.
- Dans les applications : ChatGPT, Gemini et Claude acceptent un fichier audio ou une dictée ; Copilot résume les réunions Teams ; de nombreux outils de visioconférence intègrent la transcription.

### Synthèse vocale (text-to-speech)
- **Voxtral TTS 3** (Mistral) : 13 $ par million de caractères ; **xAI Voice** : 15 $ par million de caractères ; **Gemini 3.8 Flash TTS** ; **ElevenLabs** (référence du marché pour le clonage et les voix expressives — tarifs sur le site officiel) ; modèles ouverts Kokoro, Qwen3-TTS, Voxtral TTS 4B (CC BY-NC 4.0, usage non commercial). Un message d'accueil téléphonique de 500 caractères coûte une fraction de centime.
- **Conversation en temps réel** : ChatGPT (mode vocal), Gemini Live, Grok Voice ; côté API, OpenAI `gpt-realtime-2.1` et Gemini Live. Usage typique : s'entraîner à un entretien, traduire en direct avec un client étranger.

### Musique
**Suno** (fermé) et **Lyria 3.5** (Google) ; en ouvert, **ACE-Step 1.5**. Utile pour un jingle de podcast interne ; vérifiez les conditions commerciales de chaque service avant toute diffusion publique.

> 🔗 **Documentation officielle** — [OpenAI — Pricing](https://developers.openai.com/api/docs/pricing) 🇬🇧 (images, audio, transcription) et [Mistral — Voxtral TTS 3](https://docs.mistral.ai/models/voxtral-mini-tts-3-0) 🇬🇧.

## 5. Choisir : fermé ou ouvert, application ou API ?

```
Besoin                                   → Piste
────────────────────────────────────────────────────────────────
Un visuel vite fait, pas confidentiel     → ChatGPT / Gemini / Grok (inclus)
Des centaines de visuels charte, en lot   → API (gpt-image, Nano Banana) ou FLUX local
Données sensibles (produits non lancés)   → FLUX / SD 3.5 en local (rien ne sort)
Transcrire 50 h d'entretiens              → Whisper local (gratuit) ou API (~15 $)
Voix d'accueil, podcast interne           → TTS API (Voxtral, Gemini) ou ElevenLabs
Clip de 10 s pour les réseaux             → Sora / Veo / Grok Imagine selon votre abonnement
```

Les outils **ouverts** (FLUX.1 Schnell, Stable Diffusion 3.5, Whisper, Kokoro…) s'installent sur une machine correctement équipée (module 10) : coût marginal nul, confidentialité totale, mais prise en main plus technique. Les outils **fermés** sont plus simples et souvent meilleurs sur la qualité brute, au prix d'un abonnement et d'un envoi de vos données chez l'éditeur.

## 6. Les trois règles d'or (avant-goût du module 7)

1. **Transparence.** Depuis le **2 août 2026**, l'article 50 du règlement européen sur l'IA (règlement (UE) 2024/1689) impose de signaler les contenus synthétiques et les **deepfakes** (marquage lisible par machine, mention explicite) ; les manquements relèvent du barème général jusqu'à **15 M€ ou 3 % du chiffre d'affaires mondial** (nov. 2026, calendrier et montants rappelés par la réponse ministérielle du Sénat du 5 février 2026). Bonne pratique immédiate : ajoutez « image générée par IA » dans la légende ou les métadonnées de vos visuels diffusés.
2. **Droit à l'image et deepfakes.** En France, l'article 226-8 du code pénal, renforcé par la loi SREN du 21 mai 2024, punit la diffusion d'un montage ou d'un contenu généré représentant une personne sans son consentement : jusqu'à **2 ans d'emprisonnement et 45 000 € d'amende** lorsqu'il est diffusé sur un réseau social. Ne clonez jamais une voix ni un visage sans accord écrit.
3. **Droit d'auteur.** Une image produite par une machine seule n'est pas protégée par le droit d'auteur français (article L111-1 du code de la propriété intellectuelle : il faut une intervention créative humaine). Vos retouches, votre composition, votre direction artistique le sont. Documentez votre apport (prompts, versions, retouches) et vérifiez les conditions d'utilisation commerciale de chaque service. Évitez aussi de demander « dans le style de » un artiste vivant pour un usage commercial.

> 💡 **À retenir** — Générer est facile ; **diffuser** engage votre responsabilité. Mention d'origine + consentement + conditions d'utilisation lues = les trois cases à cocher avant publication.

## 🎮 Défi
Générez le même visuel (« une tasse de café sur un bureau en bois, lumière du matin, style photo ») dans deux outils différents, puis demandez à chacun « rends-la plus chaleureuse ». Comparez cohérence, réalisme et respect de la consigne. Si l'un des deux a ajouté du texte ou un objet non demandé, vous venez de rencontrer la « sur-interprétation » typique des générateurs.

## 🧪 Exercice pratique

**Consigne.** Une boulangerie-pâtisserie de quartier (3 salariés) vous demande, pour sa page Instagram : (a) un visuel carré annonçant les galettes des rois, sans texte, dans ses couleurs (bordeaux et crème) ; (b) la transcription d'un mémo vocal de 2 minutes dicté par la gérante, transformé en légende de 60 mots ; (c) un message vocal d'accueil de 20 secondes pour le répondeur.

1. Rédigez le prompt image selon la méthode en quatre étapes, générez, itérez une fois.
2. Transcrivez le mémo (dictez-le vous-même si besoin) avec l'outil de votre choix, puis faites rédiger la légende.
3. Faites générer la voix d'accueil avec un service TTS et écoutez-la.
4. Rédigez la mention de transparence à ajouter sous le visuel et listez les vérifications juridiques faites.

**Critères de réussite.**
- Le visuel respecte les couleurs, le format carré, l'absence de texte et ne montre aucune personne identifiable.
- La légende de 60 mots est fidèle au mémo (aucun prix ou horaire inventé).
- La voix d'accueil est intelligible, en français, sans faute de prononciation sur le nom de la boutique (sinon : réécrire le nom phonétiquement).
- La mention « visuel généré par IA » est présente et vous avez vérifié les conditions d'utilisation commerciale du service employé.

**Pistes de corrigé.** Prompt image type : « Photo réaliste d'une galette des rois dorée sur un plateau en bois, serviette bordeaux, fond crème uni, lumière chaude latérale, cadrage carré, sans texte, sans personne, style éditorial gourmand ». Pour la voix : écrivez le texte avec la ponctuation qui respire (« Bonjour, et bienvenue à la Maison Martin. Nous sommes ouverts du mardi au dimanche, de 7 h à 19 h 30. ») ; un nom difficile se dicte en phonétique.

## ✅ Auto-évaluation express

1. Qu'est-ce qu'un modèle de diffusion, en une phrase ?
2. Citez un outil d'image et un outil de transcription **ouverts**, et l'avantage principal de ce choix.
3. Quelles sont les deux obligations à respecter avant de publier un visuel généré représentant une personne ?

**Réponses.** 1) Un modèle qui apprend à retirer du bruit d'une image et qui, à l'usage, « débruite » un aléa en le guidant avec votre texte pour fabriquer une image nouvelle. 2) FLUX.1 Schnell (Apache 2.0) ou Stable Diffusion 3.5 pour l'image ; Whisper (MIT) pour la transcription ; avantage : exécution locale, aucune donnée ne quitte votre machine, coût marginal nul. 3) Le consentement écrit de la personne (article 226-8 du code pénal, loi SREN) et la mention de transparence « contenu généré par IA » (AI Act art. 50, applicable depuis le 2 août 2026).

## 📚 Pour aller plus loin
- [Gemini API — Image generation](https://ai.google.dev/gemini-api/docs/image-generation) 🇬🇧 — génération et édition d'images avec les modèles Nano Banana.
- [OpenAI — Image generation guide](https://developers.openai.com/api/docs/guides/image-generation) 🇬🇧 — les modèles gpt-image et leurs options.
- [xAI — Image generation](https://docs.x.ai/developers/tools/image-generation) 🇬🇧 — Grok Imagine côté API.
- [Hugging Face — Diffusion Course](https://huggingface.co/learn/diffusion-course) 🇬🇧 — comprendre et faire tourner les modèles de diffusion ouverts (niveau 2).
- [Hugging Face — Audio Course](https://huggingface.co/learn/audio-course) 🇬🇧 — transcription et synthèse vocale avec des modèles ouverts.
- [Réponse ministérielle, Sénat, 5 février 2026](https://www.senat.fr/questions/base/2025/qSEQ251006478.html) 🇫🇷 — deepfakes : calendrier de l'AI Act et sanctions françaises.
