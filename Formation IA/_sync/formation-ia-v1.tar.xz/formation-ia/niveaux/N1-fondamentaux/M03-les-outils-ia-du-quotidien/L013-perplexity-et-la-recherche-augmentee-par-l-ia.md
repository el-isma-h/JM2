---
id: L013
module: M03
level: N1
title: "Perplexity et la recherche augmentée par l'IA"
minutes: 40
objectives:
  - "Expliquer ce qu'est un moteur de réponse (answer engine) et en quoi il diffère d'un moteur de recherche et d'un chatbot"
  - "Utiliser Perplexity pour obtenir une réponse sourcée, filtrer les sources et lancer une recherche approfondie"
  - "Vérifier les sources d'une réponse générée et repérer les signaux d'une citation fragile"
  - "Comparer les fonctions de recherche web de Perplexity, ChatGPT, Gemini, Claude et Grok"
skills: ["C1.2", "C1.4"]
sources:
  - { title: "Perplexity — Pricing (API)", url: "https://docs.perplexity.ai/getting-started/pricing", lang: "en" }
  - { title: "Perplexity — Agent API : modèles", url: "https://docs.perplexity.ai/docs/agent-api/models.md", lang: "en" }
  - { title: "Perplexity — Migrate from Sonar", url: "https://docs.perplexity.ai/docs/agent-api/migrate-from-sonar/overview.md", lang: "en" }
  - { title: "Perplexity — Search API overview", url: "https://docs.perplexity.ai/docs/search/overview.md", lang: "en" }
  - { title: "Gemini API — Grounding with Google Search", url: "https://ai.google.dev/gemini-api/docs/google-search", lang: "en" }
  - { title: "Claude Platform — Web search tool", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool", lang: "en" }
---

# Perplexity et la recherche augmentée par l'IA

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 3

## 🎯 Ce que vous saurez faire
- Distinguer moteur de recherche, chatbot et **moteur de réponse**, et savoir lequel ouvrir selon la question.
- Obtenir avec Perplexity une réponse sourcée, restreindre les sources (web, actualités, académique, vos fichiers) et lancer une recherche approfondie.
- Contrôler les citations d'une réponse IA en moins de deux minutes.
- Situer les fonctions de recherche des autres assistants (ChatGPT, Gemini, Claude, Grok).

## 1. Trois façons de chercher

Imaginez trois collègues à qui vous demandez « quel est le délai légal de rétractation pour un achat en ligne ? » :

- **Le documentaliste** (moteur de recherche classique, type Google) vous tend dix liens : à vous de lire.
- **Le beau parleur** (chatbot sans accès au web) répond de mémoire : souvent juste, parfois périmé, jamais sourcé.
- **Le journaliste** (moteur de réponse, *answer engine*) va lire les pages, rédige une synthèse de dix lignes et **met un numéro de note après chaque phrase** renvoyant à la source.

Perplexity, start-up californienne lancée fin 2022 (quelques semaines après ChatGPT), a popularisé cette troisième approche. Techniquement, c'est une application du principe **RAG** (*retrieval-augmented generation*, module 11) : chercher d'abord, générer ensuite, en obligeant le modèle à s'appuyer sur les documents trouvés. Depuis, tous les grands assistants ont ajouté une recherche web ; Perplexity reste la référence parce que la **citation est au cœur de l'interface**, pas une option.

> 💡 **À retenir** — Une réponse sourcée n'est pas une réponse vraie : c'est une réponse **vérifiable**. La valeur de Perplexity tient à ce que vous pouvez cliquer sur chaque note et lire la phrase d'origine.

## 2. Prise en main pas à pas

1. **Accès** : [perplexity.ai](https://www.perplexity.ai/) sur le web, applications mobiles et de bureau, extension de navigateur. Un compte gratuit suffit pour commencer ; la connexion (e-mail, Google, Apple) sauvegarde votre historique et vos espaces.
2. **Première question** : tapez-la en langage naturel et complet, comme à un collègue : « Quelles aides publiques existent en 2026 pour une TPE qui veut installer des panneaux solaires sur son atelier en Occitanie ? » Plus la question est précise, plus la recherche l'est.
3. **Lisez la réponse… et les sources** : au-dessus ou à côté de la réponse, les cartes « Sources » listent les pages consultées ; chaque phrase porte un numéro. Survolez ou cliquez : la page s'ouvre. Prenez l'habitude de vérifier **au moins les sources des chiffres et des dates**.
4. **Choisissez le périmètre** (sélecteur « Sources » ou « Focus » selon la version) : tout le web, actualités, publications académiques, réseaux sociaux, ou **vos propres fichiers** importés. Pour une question réglementaire, limitez-vous aux sites officiels en ajoutant dans la question « uniquement d'après service-public.fr et legifrance.gouv.fr ».
5. **Questions de suivi** : la conversation garde le fil ; « et pour une SCI ? » relance une recherche ciblée sans tout répéter.
6. **Recherche approfondie** (*Deep Research*) : pour un dossier (benchmark, état de l'art, due diligence), le mode approfondi enchaîne des dizaines de recherches et rédige un rapport structuré en quelques minutes. Comptez-le comme un stagiaire rapide : excellent pour défricher, à relire avant de diffuser.
7. **Espaces** (*Spaces*) : regroupez des conversations, des fichiers et des instructions permanentes autour d'un sujet, comme les projets de ChatGPT et Claude.

> ⚠️ **Piège fréquent** — Une source numérotée peut être un forum, un article sponsorisé ou une page d'un concurrent. Perplexity cite ce qu'il trouve, pas ce qui fait autorité. Regardez **le domaine** (gouv.fr, europa.eu, site de l'éditeur) avant de faire confiance.

## 3. Fonctions clés et offres (nov. 2026)

| Fonction | Ce que ça apporte | Exemple métier |
|---|---|---|
| Réponses citées en temps réel | Information datée du jour, avec liens | Veille concurrentielle hebdomadaire |
| Sélection des sources | Web, actualités, académique, fichiers | Revue de littérature pour un dossier technique |
| Recherche approfondie | Rapport multi-sources en quelques minutes | Comparatif de logiciels de caisse |
| Espaces | Projets persistants avec fichiers et instructions | Espace « Appel d'offres » avec le cahier des charges |
| Import de documents | Interroger vos PDF au même titre que le web | Croiser une norme interne et la réglementation publique |
| Navigateur et assistant d'agent | Perplexity propose aussi un navigateur et des outils d'automatisation (Comet, Labs…) | À explorer au niveau 2 |

**Offres grand public.** Une version gratuite et des abonnements (Pro, Max, offres entreprise) existent ; **les prix et quotas n'ont pas pu être vérifiés dans notre recherche : consultez la page tarifs officielle** sur perplexity.ai avant toute communication.

**Côté développeurs (vérifié, nov. 2026).** Perplexity vend sa recherche sous forme d'API : la **Search API** coûte 5 $ pour 1 000 requêtes réussies (1 $ en mode rapide), et l'**Agent API** permet d'interroger des modèles de nombreux éditeurs (OpenAI, Google, xAI, Anthropic, DeepSeek, Moonshot…) avec un outil `web_search` facturé 2,50 $ pour 1 000 appels. Fait marquant : les anciens modèles « Sonar » en *chat completions* ont été **arrêtés le 27 septembre 2026** ; tout passe désormais par l'Agent API, avec un niveau d'effort (`fast`, `low`, `high`, `xhigh`) à la place des anciens noms de modèles. Ces chiffres montrent une chose utile même pour un non-développeur : **une recherche web coûte réellement quelque chose** (entre 0,1 et 0,5 centime), ce qui explique les quotas des offres gratuites.

> 🔗 **Documentation officielle** — [Perplexity — Pricing](https://docs.perplexity.ai/getting-started/pricing) 🇬🇧 et [Agent API — modèles](https://docs.perplexity.ai/docs/agent-api/models.md) 🇬🇧.

## 4. Les autres assistants cherchent aussi

| Assistant (nov. 2026) | Recherche web | Particularité | Repère de coût API |
|---|---|---|---|
| ChatGPT | oui (bouton globe) + Deep research | large écosystème, citations en fin de réponse | outil web search 10 $ / 1 000 appels |
| Gemini | ancrage sur Google Search + Deep Research | accès direct à l'index Google, Maps | 5 000 requêtes gratuites/mois puis 14 $ / 1 000 |
| Claude | recherche web + Research | citations précises, très long contexte pour digérer les résultats | web search 10 $ / 1 000 recherches, web fetch gratuit |
| Grok | web + publications X | temps réel sur les réseaux sociaux | web_search 5 $ / 1 000 ; x_search 5 $ / 1 000 posts |
| Perplexity | cœur du produit | sources en avant, filtres, espaces | Search API 5 $ / 1 000 (1 $ en rapide) |

Sources : pages Pricing OpenAI, Gemini API, Claude Platform, xAI et Perplexity (nov. 2026).

**Comment choisir ?** Perplexity pour une question factuelle rapide à sourcer ; Gemini quand l'index Google ou Maps compte (horaires, lieux, actualité locale) ; ChatGPT ou Claude quand la recherche n'est qu'une étape d'un travail plus large (rédiger ensuite un rapport de 20 pages) ; Grok pour la température du réseau X.

## 5. Vérifier une réponse sourcée en 120 secondes (compétence C1.4)

1. **Repérez les affirmations à risque** : chiffres, dates, montants, noms propres, articles de loi.
2. **Ouvrez la source de chacune** : la phrase citée s'y trouve-t-elle vraiment ? Un résumé IA peut « glisser » d'un paragraphe à l'autre et attribuer à une source ce qu'elle ne dit pas.
3. **Datez la source** : une page de 2023 sur un seuil fiscal est probablement périmée.
4. **Évaluez l'autorité** : site officiel, éditeur reconnu, presse établie > blog, forum, page commerciale.
5. **Croisez** : deux sources indépendantes qui concordent valent mieux qu'une seule, même officielle.
6. **Signalez** les points non vérifiables (« à confirmer ») au lieu de les lisser.

```
Affirmation         Source      Phrase présente ?   Date     Autorité    Verdict
──────────────────────────────────────────────────────────────────────────────
« délai 14 jours »  [1] gouv    oui                 2026     officielle  ✔ validé
« 30 % des TPE »    [3] blog    non (dit 23 %)      2022     faible      ✖ à corriger
```

> 💡 **À retenir** — Le mot « source » ne protège pas. Ce qui protège, c'est **l'ouverture de la source**. Deux minutes de vérification évitent un e-mail embarrassant… ou un contentieux.

## 6. Limites et bons usages

**Perplexity est excellent** pour : la veille, les questions factuelles récentes, la préparation d'un rendez-vous client (« que fait cette entreprise, quelle actualité ? »), les comparatifs, la recherche académique (filtre « academic »), la première lecture d'un sujet inconnu.

**Il est moins adapté** pour : la rédaction longue et stylée (préférez Claude ou ChatGPT), le travail sur vos fichiers volumineux (préférez un projet Claude ou Gemini Notebook), les questions sans réponse publique (il « trouvera » quand même quelque chose), et tout ce qui touche à des données confidentielles — ce que vous tapez devient une requête envoyée à des moteurs tiers. Vérifiez les réglages de confidentialité (conservation de l'historique, utilisation pour l'amélioration) sur un compte individuel.

## 🎮 Défi
Demandez à Perplexity : « Combien d'entreprises ont été créées en France en 2025 ? Cite la source INSEE. » Ouvrez la source citée. Le chiffre et l'année correspondent-ils exactement ? Si un écart apparaît, vous avez attrapé votre première citation approximative — bravo, c'est tout l'objet de cette leçon.

## 🧪 Exercice pratique

**Consigne.** Vous préparez pour votre direction une note d'une page sur **l'obligation de formation à l'IA (article 4 du règlement européen sur l'IA)**. Dans Perplexity :
1. Posez la question en limitant les sources aux sites officiels (Union européenne, gouvernement français, CNIL).
2. Lancez ensuite une recherche approfondie sur « sanctions et calendrier d'application 2026 ».
3. Construisez un tableau de vérification (modèle de la section 5) pour cinq affirmations de la réponse.
4. Rédigez la note (200 mots) en ne gardant que les affirmations validées, avec les URL en bas de page.

**Critères de réussite.**
- Les cinq affirmations vérifiées comportent chacune : source ouverte, date, autorité, verdict.
- Au moins une affirmation a été corrigée ou marquée « à confirmer ».
- La note ne contient aucune URL que vous n'avez pas ouverte vous-même.
- Les dates clés (2 février 2025 pour l'article 4, 2 août 2026 pour la surveillance et les sanctions) apparaissent et sont sourcées.

**Pistes de corrigé.** Les sources de référence sont le texte du règlement (UE) 2024/1689 sur EUR-Lex et les pages de la CNIL. Une erreur fréquente des moteurs de réponse : présenter une amende spécifique à l'article 4, alors que le règlement ne prévoit pas de sanction propre à cet article (la surveillance de marché et la responsabilité civile s'appliquent). Si votre réponse l'affirme, c'est précisément le type de glissement à corriger.

## ✅ Auto-évaluation express

1. Quelle est la différence essentielle entre un chatbot sans accès au web et un moteur de réponse ?
2. Que signifie « sourcé » et pourquoi n'est-ce pas synonyme de « vrai » ?
3. Quel outil choisir pour une question d'actualité locale avec horaires et adresses ?

**Réponses.** 1) Le chatbot répond de mémoire (connaissances arrêtées à sa date de coupure) ; le moteur de réponse cherche d'abord sur le web, puis rédige une synthèse en citant chaque source. 2) Sourcé = chaque affirmation renvoie à une page consultable ; mais la page peut être erronée, périmée, peu fiable, ou mal résumée : seule l'ouverture et la lecture de la source valident l'information. 3) Gemini, grâce à l'ancrage sur Google Search et Maps ; Perplexity convient aussi pour l'actualité, moins pour les horaires et lieux.

## 📚 Pour aller plus loin
- [Perplexity — Search API overview](https://docs.perplexity.ai/docs/search/overview.md) 🇬🇧 — comment la recherche de Perplexity est exposée aux applications (utile pour comprendre les filtres par domaine, date et langue).
- [Perplexity — Migrate from Sonar](https://docs.perplexity.ai/docs/agent-api/migrate-from-sonar/overview.md) 🇬🇧 — l'arrêt des modèles Sonar (27 sept. 2026) et les niveaux d'effort.
- [Gemini API — Grounding with Google Search](https://ai.google.dev/gemini-api/docs/google-search) 🇬🇧 — l'ancrage des réponses sur l'index Google.
- [Claude — Web search tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool) 🇬🇧 — la recherche web côté Claude, avec citations.
