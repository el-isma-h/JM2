---
id: L012
module: M03
level: N1
title: "Gemini, Copilot, Grok, Le Chat : forces et usages"
minutes: 40
objectives:
  - "Prendre en main Gemini, Microsoft Copilot, Grok et Le Chat et repérer leurs fonctions distinctives"
  - "Comparer ces quatre assistants selon des critères professionnels (intégration, sources, confidentialité, coût, ouverture)"
  - "Sélectionner l'assistant adapté à une situation de travail donnée et justifier le choix"
skills: ["C1.2"]
sources:
  - { title: "Google — Gemini API : modèles", url: "https://ai.google.dev/gemini-api/docs/models", lang: "en" }
  - { title: "Google — Gemini API : tarifs", url: "https://ai.google.dev/gemini-api/docs/pricing", lang: "en" }
  - { title: "xAI — Models", url: "https://docs.x.ai/developers/models", lang: "en" }
  - { title: "xAI — Pricing", url: "https://docs.x.ai/developers/pricing", lang: "en" }
  - { title: "Mistral AI — Models overview", url: "https://docs.mistral.ai/getting-started/models/", lang: "en" }
  - { title: "Mistral AI — Pricing", url: "https://docs.mistral.ai/inference/pricing", lang: "en" }
  - { title: "Microsoft Learn — guide d'étude AI-900 (retiré, remplacé par AI-901)", url: "https://learn.microsoft.com/certifications/resources/study-guides/AI-900", lang: "en" }
  - { title: "Google AI Essentials (Coursera)", url: "https://www.coursera.org/google-specializations/ai-essentials-google", lang: "en" }
---

# Gemini, Copilot, Grok, Le Chat : forces et usages

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 3

## 🎯 Ce que vous saurez faire
- Lancer une conversation dans Gemini, Copilot, Grok et Le Chat, et activer leurs fonctions phares.
- Dire en une phrase ce que chacun fait mieux que les autres, et où il est moins bon.
- Choisir l'assistant adapté à un cas professionnel (et le justifier avec au moins deux critères).

## 1. Pourquoi quatre assistants de plus ?

ChatGPT et Claude (leçons L010 et L011) couvrent la majorité des besoins. Mais trois réalités professionnelles poussent à élargir la panoplie :

1. **L'intégration** : si votre entreprise vit dans Google Workspace (Gmail, Docs, Drive) ou dans Microsoft 365 (Outlook, Word, Teams), l'assistant intégré à ces suites évite les copier-coller et respecte les droits d'accès existants.
2. **La souveraineté et l'ouverture** : Mistral AI est une entreprise française dont plusieurs modèles sont publiés en poids ouverts (vous pouvez les faire tourner sur vos propres machines, module 10).
3. **L'accès à l'information en temps réel** : Grok est branché sur le réseau social X et met en avant l'actualité à la minute.

Nous allons présenter chaque outil selon le même plan : prise en main, fonctions clés 2026, offres, bons usages, limites.

## 2. Gemini (Google)

**Prise en main.** Rendez-vous sur [gemini.google.com](https://gemini.google.com/) avec un compte Google (personnel ou Workspace). L'application mobile remplace l'assistant Google sur Android. Tapez votre demande, joignez des fichiers depuis votre ordinateur ou **directement depuis Google Drive**, et demandez des réponses « avec recherche Google » pour obtenir des sources.

**Modèles (nov. 2026).** La page officielle des modèles liste `gemini-4-argon` (modèle phare, raisonnement, contexte unifié de 1 million de tokens) et `gemini-3.8-flash` (rapide, 1 048 576 tokens en entrée, texte + image + vidéo + audio + PDF). Gemini est historiquement fort sur la **vidéo et l'audio** : vous pouvez lui donner un enregistrement de réunion d'une heure et demander le compte rendu.

**Fonctions clés** (citées par les cours officiels Google AI, nov. 2026) : **Canvas** (volet d'édition de texte ou de code, équivalent des artefacts), **Deep Research** (enquête web avec rapport), **Gemini dans Workspace** (rédaction dans Gmail/Docs, résumé de fils, formules dans Sheets), **Gemini Notebook** (carnet de sources pour interroger vos propres documents), génération d'images **Nano Banana** (`gemini-nano-banana-2.1`), et pour les techniciens **Google AI Studio** et **Gemini CLI**.

**Offres.** Version gratuite généreuse ; abonnement **Google AI Pro** (inclus 3 mois avec le certificat Google AI Professional) et une offre supérieure. Prix : **voir la page tarifs officielle Google One / Gemini** (non vérifiés dans notre recherche). Côté API, à titre de repère : `gemini-3.8-flash` 0,75 $ / 3,75 $ par million de tokens avec palier gratuit, `gemini-4-argon` 2 $ / 10 $ — avec une **hausse annoncée** au 1er décembre 2026 (4 $ / 20 $) puis au 1er janvier 2027 pour les autres modèles (page Pricing, nov. 2026).

**Bons usages** : tout ce qui touche à vos documents Google, l'analyse de vidéos et d'audios, la recherche ancrée sur Google (grounding), les visuels rapides. **Limites** : dépendance à l'écosystème Google ; les réglages de confidentialité (historique des activités Gemini, utilisation pour l'amélioration) doivent être vérifiés sur un compte personnel ; qualité de rédaction française parfois moins naturelle que Claude.

> 🔗 **Documentation officielle** — [Gemini API — Models](https://ai.google.dev/gemini-api/docs/models) 🇬🇧 : capacités de chaque modèle (vision, audio, vidéo, outils).

## 3. Microsoft Copilot

**Prise en main.** Deux produits portent le nom : **Copilot** grand public ([copilot.microsoft.com](https://copilot.microsoft.com/), intégré à Windows, Edge et Bing) et **Microsoft 365 Copilot**, l'assistant payant intégré à Word, Excel, PowerPoint, Outlook et Teams pour les entreprises abonnées. Dans Word, un bouton Copilot ouvre un volet : « Rédige une introduction à partir de ces notes » ; dans Teams, il résume une réunion à laquelle vous n'avez pas assisté ; dans Excel, il propose des formules et des graphiques.

**Ce qui le distingue.** Copilot respecte les **permissions** de votre organisation : il ne vous montre que ce que vous avez déjà le droit de voir dans SharePoint ou OneDrive. Pour un service RH ou juridique, c'est l'argument n° 1. Microsoft s'appuie sur des modèles OpenAI et sur ses propres modèles ; les détails (modèle utilisé, quotas, prix par utilisateur) **sont à vérifier sur les pages officielles Microsoft**, car notre recherche n'a pas pu les confirmer au 1er novembre 2026.

**Certification associée.** Microsoft a **retiré l'examen AI-900** le 30 juin 2026 et l'a remplacé par **AI-901** (même titre « Azure AI Fundamentals », score 700/1000, deux domaines : concepts et capacités de l'IA ; implémentation de solutions avec Microsoft Foundry). Notre niveau 1 couvre la partie « concepts et capacités » ; nous vous encourageons à tenter l'examen si votre entreprise est cliente Microsoft.

**Bons usages** : rédaction et synthèse dans Office, comptes rendus Teams, exploitation de fichiers internes sans les sortir de l'entreprise. **Limites** : nécessite une licence d'entreprise pour la version intégrée ; moins souple que ChatGPT pour les tâches créatives ; interface qui change souvent de nom et de périmètre.

> ⚠️ **Piège fréquent** — Confondre Copilot (gratuit, grand public, données hors tenant) et Microsoft 365 Copilot (licence entreprise, données dans votre tenant). Avant de coller un document interne, vérifiez dans quel Copilot vous êtes.

## 4. Grok (xAI)

**Prise en main.** Grok est l'assistant de xAI, la société d'Elon Musk. Il est accessible sur [grok.com](https://grok.com/), dans les applications mobiles et directement dans X (ex-Twitter). Comptes gratuits possibles ; connexion avec un compte X, Google ou e-mail.

**Modèles et fonctions (nov. 2026).** Le modèle phare est **grok-4.7** (connaissances arrêtées en mai 2026, contexte 500 000 tokens). Les fonctions mises en avant : **Grok Imagine** (génération d'images et de vidéos), **Grok Build** (création d'applications), **Grok Bot**, et une recherche qui combine le web et les publications X (outils `web_search` et `x_search` côté API). Le ton de Grok est volontairement plus familier et moins filtré que celui des concurrents : un atout pour certains, un risque en contexte professionnel.

**Offres.** Depuis le 12 octobre 2026, xAI vend ses accès au sein de « The X Subscription » : **Plus** 8 $/mois, **Premium** 30 $/mois (génération vidéo, Grok Bot), **Super** 100 $/mois, **Ultra** 200 $/mois ; le gratuit donne accès au chat, à Imagine et à Build avec des limites, sans vidéo ni API (source tierce ai-toolbox.co, vérifiée le 25 oct. 2026 — à confirmer sur la page tarifs officielle). API : grok-4.7 à 2 $ / 6 $ par million de tokens (page Pricing xAI, nov. 2026).

**Bons usages** : veille sur l'actualité et les tendances de X, génération rapide d'images/vidéos, exploration. **Limites** : sources parfois issues de publications non vérifiées sur X ; modération plus permissive ; peu adapté aux données confidentielles d'entreprise sans contrat dédié.

> 🔗 **Documentation officielle** — [xAI — Models](https://docs.x.ai/developers/models) 🇬🇧 et [Pricing](https://docs.x.ai/developers/pricing) 🇬🇧.

## 5. Le Chat (Mistral AI)

**Prise en main.** Le Chat est l'assistant de **Mistral AI**, entreprise française fondée à Paris en 2023. Accès sur [chat.mistral.ai](https://chat.mistral.ai/) et sur mobile. L'interface est sobre : conversation, fichiers, recherche web, génération d'images, agents.

**Modèles (nov. 2026).** La page officielle liste **Mistral Large 4** (version 26.10, multimodal, publié sous la « Mistral Ecosystem Open Weight License ») et **Mistral Small 4** (version 26.03, licence **Apache 2.0**, donc librement réutilisable, y compris commercialement), ainsi que des modèles spécialisés : **OCR 4.1** (lecture de documents scannés), **Voxtral** (transcription et synthèse vocale), **Codestral** (code). L'outil de code en ligne de commande s'appelle **Vibe**, et la plateforme développeur **AI Studio**.

**Offres.** Version gratuite ; abonnements Pro, Team et Entreprise — **prix à vérifier sur la page tarifs officielle** (non confirmés dans notre recherche). Repère API : Mistral Large 4 à 0,70 $ / 2,10 $ et Mistral Small 4 à 0,15 $ / 0,60 $ par million de tokens (nov. 2026), parmi les moins chers du marché pour ce niveau de qualité.

**Bons usages** : entreprises et administrations françaises sensibles à la localisation des données et à la transparence (modèles à poids ouverts, possibilité d'hébergement sur vos serveurs — module 10) ; OCR de documents ; usage quotidien à coût maîtrisé. **Limites** : écosystème d'applications moins riche (moins de connecteurs grand public) ; modèles phares légèrement en retrait des leaders sur les tâches les plus complexes selon les classements publics ; documentation principalement en anglais malgré l'origine française.

> 💡 **À retenir** — « Poids ouverts » (open weights) signifie que le fichier du modèle est téléchargeable. C'est la seule façon d'exécuter un assistant **sans qu'aucune donnée ne quitte votre machine**. Mistral Small 4 (Apache 2.0) est l'exemple de référence en 2026.

## 6. Tableau comparatif et grille de choix

| Critère (nov. 2026) | Gemini | Copilot (M365) | Grok | Le Chat |
|---|---|---|---|---|
| Éditeur / pays | Google (US) | Microsoft (US) | xAI (US) | Mistral AI (FR) |
| Modèle phare | gemini-4-argon | modèles OpenAI + Microsoft | grok-4.7 | Mistral Large 4 |
| Contexte max. | 1 M tokens | selon modèle | 500 k tokens | selon modèle |
| Intégration bureautique | Workspace (natif) | Microsoft 365 (natif) | X | faible |
| Sources en temps réel | Recherche Google | Bing + données internes | Web + X | Recherche web |
| Modèles ouverts | Gemma (famille ouverte) | non | non | oui (Small 4 Apache 2.0) |
| Point fort | audio/vidéo, Drive | permissions d'entreprise | actualité X, images/vidéo | souveraineté, coût |
| Vigilance | écosystème Google | licence requise | modération permissive | écosystème réduit |

**Grille de décision en trois questions** (compétence C1.2) :
1. **Où sont mes documents ?** Workspace → Gemini ; Microsoft 365 → Copilot ; nulle part en particulier → ChatGPT/Claude/Le Chat.
2. **Mes données peuvent-elles sortir de l'entreprise ?** Non → Copilot M365, offres Entreprise, ou modèle ouvert hébergé (Mistral) ; oui, données anonymisées → n'importe lequel.
3. **Ai-je besoin du temps réel ?** Actualité et réseaux → Grok, Gemini, Perplexity (L013) ; non → le plus confortable pour vous.

> ⚠️ **Piège fréquent** — Choisir un outil parce qu'il est « le meilleur au classement ». Les classements changent chaque mois ; l'intégration à vos outils et la politique de données, elles, conditionnent l'usage au quotidien. Deux critères valent mieux qu'un score.

## 🎮 Défi
Posez la même question aux quatre assistants : « Quelles sont les trois dernières annonces de la CNIL concernant l'IA ? Cite tes sources. » Notez pour chacun : nombre de sources, fraîcheur, présence de liens cliquables, exactitude vérifiée sur cnil.fr. Vous obtiendrez votre propre classement, bien plus utile que celui des médias.

## 🧪 Exercice pratique

**Consigne.** Un cabinet d'avocats de 12 personnes (Microsoft 365), une agence de communication de 5 personnes (Google Workspace) et une mairie de 3 000 habitants (documents sensibles, budget serré) vous demandent chacun **un** assistant IA principal. Pour chaque organisation, rédigez une recommandation de 5 à 8 lignes : outil choisi, deux critères déterminants, une fonction clé à activer, un point de vigilance.

**Critères de réussite.**
- Chaque recommandation cite au moins deux critères parmi : intégration, confidentialité, coût, sources, ouverture du modèle.
- La fonction clé nommée existe réellement dans l'outil (Canvas, Deep Research, Copilot dans Teams, OCR, Imagine…).
- Le point de vigilance est concret (licence, réglage de données, modération, hébergement).
- Les prix ne sont avancés que s'ils proviennent d'une page officielle consultée ce jour.

**Pistes de corrigé.** Cabinet d'avocats → Microsoft 365 Copilot (permissions, données dans le tenant ; vigilance : licence par utilisateur et formation au secret professionnel). Agence de communication → Gemini (Drive, Canvas, images Nano Banana ; vigilance : réglages d'historique). Mairie → Le Chat ou un modèle Mistral ouvert hébergé en interne (souveraineté, coût ; vigilance : écosystème réduit, nécessité d'un prestataire pour l'hébergement) — ChatGPT ou Claude en offre Team sont des alternatives acceptables si les données sont anonymisées.

## ✅ Auto-évaluation express

1. Quelle différence entre Copilot et Microsoft 365 Copilot ?
2. Pourquoi Mistral Small 4 intéresse-t-il particulièrement les organisations soucieuses de confidentialité ?
3. Quel assistant privilégier pour analyser l'enregistrement vidéo d'une réunion stockée dans Google Drive ?

**Réponses.** 1) Copilot est l'assistant grand public gratuit (Windows, Edge, web) ; Microsoft 365 Copilot est la licence d'entreprise intégrée à Word, Excel, Teams… qui respecte les permissions de votre organisation et garde les données dans votre tenant. 2) Il est publié sous licence Apache 2.0 avec ses poids : on peut l'exécuter sur ses propres serveurs, sans qu'aucune donnée ne sorte. 3) Gemini : modèles multimodaux (vidéo, audio) et intégration native à Drive et Workspace.

## 📚 Pour aller plus loin
- [Gemini API — Pricing](https://ai.google.dev/gemini-api/docs/pricing) 🇬🇧 — repères de coût et hausses annoncées (déc. 2026, janv. 2027).
- [Mistral AI — Models overview](https://docs.mistral.ai/getting-started/models/) 🇬🇧 — licences et modèles ouverts, dont Small 4 (Apache 2.0).
- [Microsoft Learn — AI-900 (retiré) et AI-901](https://learn.microsoft.com/certifications/resources/study-guides/AI-900) 🇬🇧 — le référentiel « Azure AI Fundamentals », base d'une certification reconnue.
- [Google AI Essentials](https://www.coursera.org/google-specializations/ai-essentials-google) 🇬🇧 — spécialisation Google/Coursera (5 cours, dont « Maximize Productivity With AI Tools ») alignée avec ce module.
