---
id: L023
module: M05
level: N1
title: "Vérifier, sourcer, corriger : la relecture critique des sorties IA"
minutes: 40
objectives:
  - "Appliquer une méthode de vérification en cinq étapes à toute production IA avant utilisation"
  - "Identifier les signaux d'alerte d'une hallucination (références trop parfaites, chiffres précis sans source, absence de doute)"
  - "Remonter à la source primaire (Légifrance, INSEE, site de l'éditeur) et contre-vérifier avec un second outil"
  - "Corriger une sortie IA erronée en argumentant chaque correction et en gardant une trace"
skills: ["C1.4", "C1.1"]
sources:
  - { title: "Claude Academy — AI Fluency: Framework and foundations (Discernment, Diligence)", url: "https://academy.claude.com/courses/ai-fluency-framework-foundations", lang: "en" }
  - { title: "Claude Academy — AI capabilities and limitations", url: "https://academy.claude.com/courses/ai-capabilities-and-limitations", lang: "en" }
  - { title: "Claude Platform — Citations", url: "https://platform.claude.com/docs/en/build-with-claude/citations", lang: "en" }
  - { title: "Claude Platform — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "Anthropic Partner Academy — Evaluating & Validating Claude's Output", url: "https://anthropic-partners.skilljar.com/evaluating-validating-claudes-output", lang: "en" }
  - { title: "Stanford HAI — AI Index Report 2026 (chapitre Responsible AI)", url: "https://hai.stanford.edu/ai-index/2026-ai-index-report", lang: "en" }
  - { title: "Légifrance", url: "https://www.legifrance.gouv.fr/", lang: "fr" }
  - { title: "INSEE", url: "https://www.insee.fr/", lang: "fr" }
  - { title: "Service-public.fr", url: "https://www.service-public.fr/", lang: "fr" }
---

# Vérifier, sourcer, corriger : la relecture critique des sorties IA

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 5

## 🎯 Ce que vous saurez faire
- Dérouler, en deux à dix minutes selon l'enjeu, une vérification en cinq étapes : classer, repérer, remonter à la source, contre-vérifier, corriger et tracer.
- Reconnaître les signaux d'alerte d'une hallucination avant même d'ouvrir un navigateur.
- Savoir *où* vérifier en France : textes de loi, chiffres publics, informations d'entreprise, documentation technique.
- Rédiger une correction argumentée et garder une trace de ce qui a été vérifié (et par qui).

## 1. Pourquoi cette leçon est la plus importante du niveau 1

La leçon L008 vous a expliqué *pourquoi* un modèle de langage invente : il produit la suite la plus plausible, même là où il ne sait rien. Cette leçon vous apprend *quoi faire* concrètement. Dans le cadre 4D du cours *AI Fluency*, c'est la compétence de **Discernement** (juger la sortie) prolongée par la **Diligence** (en assumer la responsabilité). Dans le référentiel de la certification Claude Certified Associate – Foundations, le domaine « Output Evaluation & Validation » pèse 21 % de l'examen (nov. 2026, chiffre rapporté par des sources tierces) : c'est le premier domaine en poids. Ce n'est pas un hasard.

L'AI Index 2026 de Stanford recense **362 incidents liés à l'IA signalés en 2025**, un record. Une partie d'entre eux tient à une seule cause : quelqu'un a utilisé une sortie sans la vérifier.

### 1.1 Cinq affaires documentées à raconter à vos collègues

Les cas ci-dessous ont été largement rapportés par la presse de référence. Nous les résumons avec prudence : avant de les réutiliser dans un support client ou une formation interne, **relisez un article de presse de référence** pour les détails exacts.

| Année | Affaire | Ce qui s'est passé | Leçon |
|---|---|---|---|
| 2023 | **Mata c. Avianca** (tribunal fédéral de New York) | Deux avocats déposent un mémoire citant six décisions de justice… inventées par ChatGPT, avec des citations et des numéros de dossier plausibles. Le juge sanctionne les avocats (amende de 5 000 $) | Une référence qui « a l'air vraie » n'est pas une référence vérifiée |
| 2023 | **Démonstration de Google Bard** | Dans une publicité de lancement, Bard affirme que le télescope James-Webb a pris la première image d'une exoplanète ; c'est faux (la première image date de 2004, par le VLT). La capitalisation d'Alphabet chute d'environ 100 milliards de dollars le jour même | Un chiffre ou un « premier » affirmé avec assurance est à contrôler |
| 2024 | **Moffatt c. Air Canada** (tribunal civil de Colombie-Britannique) | Le chatbot du site invente une politique de tarif « deuil » remboursable après coup. Le tribunal condamne la compagnie : elle est responsable des informations données par son chatbot | Ce que votre IA dit à un client vous engage |
| 2025 | **Liste de lectures d'été** (supplément diffusé par le *Chicago Sun-Times*) | Un supplément publie une liste de livres pour l'été dont plusieurs titres n'existent pas, attribués à de vrais auteurs ; le pigiste reconnaît avoir utilisé une IA sans vérifier | Les mélanges vrai/faux (vrai auteur, faux livre) sont les plus difficiles à repérer |
| 2025 | **Rapport Deloitte pour le gouvernement australien** | Un rapport d'audit facturé plusieurs centaines de milliers de dollars australiens contient des références universitaires inexistantes et une citation de jugement inventée ; le cabinet rembourse une partie des honoraires | Même les grands cabinets se font piéger quand la relecture saute |

> 💡 **À retenir** — Dans les cinq affaires, personne n'a « mal utilisé » l'outil au sens technique. Il manquait une seule chose : **une vérification humaine proportionnée à l'enjeu**.

## 2. La méthode en cinq étapes

```
① CLASSER ──► ② REPÉRER ──► ③ REMONTER À LA SOURCE ──► ④ CONTRE-VÉRIFIER ──► ⑤ CORRIGER ET TRACER
 (quel type        (signaux          (source primaire,          (second outil,            (correction argumentée,
  d'affirmation ?)  d'alerte)         pas un résumé)             méthode des 2 sources)    registre, mention)
```

### Étape 1 — Classer chaque affirmation

Relisez la sortie en surlignant mentalement chaque phrase selon son type :

| Type | Exemple | Risque | Effort de vérification |
|---|---|---|---|
| **Fait vérifiable** (date, nom, événement) | « La loi SREN date du 21 mai 2024 » | Élevé | Source primaire obligatoire |
| **Chiffre** | « Le reste à charge CPF est de 150 € » | Élevé | Source primaire + date de validité |
| **Référence** (article, arrêt, URL, livre, étude) | « article L. 1234-9-2 du Code du travail » | **Très élevé** | Ouvrir la référence elle-même |
| **Raisonnement / calcul** | « donc la marge est de 12 % » | Moyen | Refaire le calcul |
| **Formulation / style** | « Nous vous prions d'agréer… » | Faible | Relecture simple |
| **Opinion / recommandation** | « Je recommande l'option B » | Variable | Juger avec votre expertise |

Ce classement vous dit où mettre votre temps : sur les références et les chiffres, pas sur le style.

### Étape 2 — Repérer les signaux d'alerte

Avant toute recherche, certains indices doivent faire monter votre vigilance :
- **Précision suspecte** : une référence complète (numéro d'article, date, juridiction) alors que vous n'avez fourni aucun document.
- **Trop beau pour être vrai** : la citation dit *exactement* ce que vous vouliez entendre.
- **Absence de nuance** : aucun « il semble », « à vérifier », « selon la version en vigueur ».
- **Mélange vrai/faux** : un auteur réel, un titre inconnu ; un vrai site, une URL qui n'existe pas.
- **Date de connaissance** : tout fait postérieur à la date de connaissance du modèle (juin 2026 pour les modèles Claude 5.5, nov. 2026) est inconnu, donc potentiellement inventé si la recherche web n'est pas activée.
- **Fausse prémisse acceptée** : vous avez glissé une erreur dans la question et le modèle a brodé dessus au lieu de la corriger (biais de complaisance, L008).

🎮 **Défi** — Demandez à un assistant, recherche web désactivée : « Résume l'arrêt de la Cour de cassation du 12 mars 2025 sur le télétravail des alternants. » Il n'existe pas d'arrêt de ce type à notre connaissance. Observez : l'assistant refuse-t-il, demande-t-il la référence, ou produit-il un résumé convaincant ? Les modèles de 2026 refusent plus souvent qu'en 2023, mais pas toujours.

### Étape 3 — Remonter à la source primaire

Une **source primaire** est le document d'origine : le texte de loi, le rapport, la page de l'éditeur, le jugement, le bilan. Un résumé, un article de blog ou… une autre réponse d'IA ne sont pas des sources primaires.

| Pour vérifier… | Allez sur | Réflexe |
|---|---|---|
| Un article de loi, un décret, une convention collective | [Légifrance](https://www.legifrance.gouv.fr/) | Vérifiez la **version en vigueur** à la date qui vous intéresse |
| Une démarche, un seuil, un barème administratif | [Service-public.fr](https://www.service-public.fr/) | Regardez la date de mise à jour de la page |
| Une statistique nationale | [INSEE](https://www.insee.fr/) | Notez l'année et le périmètre de la donnée |
| Une donnée de protection des données | Site de la CNIL (fiches pratiques IA, recommandations) | Le texte applicable prime sur la synthèse |
| Une fonctionnalité, un prix, une limite d'un outil IA | Documentation officielle de l'éditeur (ex. [tarifs Claude](https://platform.claude.com/docs/en/about-claude/pricing), [modèles OpenAI](https://developers.openai.com/api/docs/models)) | Les prix et limites changent plusieurs fois par an |
| Une information sur une entreprise | Son site officiel, ses comptes publiés | Pas un agrégateur |
| Une URL donnée par l'IA | Ouvrez-la | Une erreur 404 = référence inventée jusqu'à preuve du contraire |

> ⚠️ **Piège fréquent** — Vérifier une sortie d'IA… en posant la question à la même IA (« Es-tu sûr ? »). Le modèle peut confirmer son erreur avec la même assurance, ou se rétracter à tort. La question « es-tu sûr ? » n'est pas une vérification, c'est un second tirage au sort.

### Étape 4 — Contre-vérifier

Pour tout ce qui engage (🟠 et 🔴 de la leçon L021), appliquez la **règle des deux sources indépendantes** : deux sources qui ne se citent pas l'une l'autre. Trois techniques complémentaires :

1. **Second outil avec recherche sourcée** : posez la même question à Perplexity, ou à Claude / ChatGPT avec la recherche web activée, et ouvrez les pages citées. Les assistants « sourcés » appliquent automatiquement la parade « fournir la source » (L008), mais une page citée peut elle-même être fausse ou obsolète : lisez-la.
2. **Citations contraintes** : demandez « cite le passage exact du document qui justifie chaque affirmation, avec le numéro de page ». L'API Claude propose une fonction *Citations* qui renvoie les extraits sources ; dans l'interface, une consigne explicite suffit souvent. Une affirmation sans passage citable est suspecte.
3. **Autocritique structurée** : dans une *nouvelle* conversation, collez la sortie et demandez « Liste toutes les affirmations factuelles de ce texte et, pour chacune, indique si elle est vérifiable et comment ». Vous obtenez une check-list, pas une vérité — mais une check-list utile.

> 🔗 **Documentation officielle** — Anthropic documente la fonction [Citations](https://platform.claude.com/docs/en/build-with-claude/citations) 🇬🇧 et consacre une section de ses [Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 à la réduction des hallucinations et à l'extraction de citations en contexte long. OpenAI recommande dans ses [Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 de garder un « humain dans la boucle » et de communiquer les limites du modèle aux utilisateurs.

### Étape 5 — Corriger et tracer

Corriger ne suffit pas ; il faut que la correction soit **argumentée** et **traçable** :
- Remplacez l'affirmation fausse par la bonne, **avec sa source et sa date** (« Reste à charge CPF : 150 € depuis le 2 avril 2026, décret 2026-234 »).
- Si vous ne pouvez pas vérifier, **supprimez** l'affirmation ou marquez-la « [à vérifier] » : une information absente vaut mieux qu'une information fausse.
- Tenez un **registre d'erreurs** (un simple tableau : date, outil, tâche, erreur constatée, correction). Au bout d'un mois, vous saurez précisément où votre outil se trompe — et vous ajusterez vos prompts (M04) ou votre choix d'outil (M03).
- Pour un document diffusé, ajoutez la mention « Produit avec l'aide d'une IA, relu et validé par [nom], le [date] ». Ce n'est pas (encore) une obligation générale pour un texte interne, mais c'est la pratique recommandée par la plupart des chartes d'entreprise, et une bonne préparation aux obligations de transparence de l'AI Act (article 50, module M07).

## 3. Proportionner : la règle « enjeu × réversibilité »

Vous ne pouvez pas vérifier chaque mot de chaque sortie. Le bon niveau se fixe en croisant deux questions : *quel est le coût d'une erreur ?* et *puis-je revenir en arrière ?*

| | Réversible (brouillon, interne) | Irréversible (envoyé, publié, signé) |
|---|---|---|
| **Enjeu faible** | Relecture rapide (étape 1 + style) | Étapes 1-2, contrôle des chiffres |
| **Enjeu fort** (argent, droit, santé, réputation, personnes) | Étapes 1-4 avant de passer à l'étape suivante | **Les 5 étapes + validation d'un expert métier** |

Un post LinkedIn interne : deux minutes. Une proposition commerciale avec engagement de prix : dix minutes et une relecture par un collègue. Un courrier juridique : la méthode complète *et* l'avocat.

## 🧪 Exercice pratique

**Consigne.** Vous êtes assistant(e) de direction dans une PME. Vous avez demandé à un assistant IA une note sur le CPF pour les salariés. Voici sa réponse (fictive, volontairement truffée d'erreurs) :

> « Depuis le 1er janvier 2026, tout salarié doit payer un reste à charge de 100 € pour toute formation CPF, conformément au décret n° 2025-1182 du 3 octobre 2025. Les formations en IA inscrites au Répertoire spécifique sont plafonnées à 2 000 € de prise en charge. L'article L. 6323-4-2 du Code du travail précise que les formations suivies à distance ne sont pas éligibles. Selon l'INSEE, 47 % des salariés français ont déjà utilisé leur CPF pour une formation en intelligence artificielle. »

Appliquez les cinq étapes : 1) classez chaque affirmation ; 2) listez les signaux d'alerte ; 3) indiquez pour chacune la source primaire à consulter ; 4) proposez une contre-vérification ; 5) rédigez la note corrigée, avec les mentions « [à vérifier] » là où vous n'avez pas pu conclure, et une ligne de traçabilité.

**Critères de réussite.**
- Les quatre affirmations sont classées (chiffre, référence, référence, chiffre) et toutes signalées comme à vérifier.
- Au moins trois signaux d'alerte sont nommés (références précises sans document fourni, pourcentage très précis sur un sujet récent, absence de nuance, formulation « tout salarié »).
- Les sources primaires proposées sont les bonnes (Légifrance pour les décrets et le Code du travail, Service-public.fr pour les règles CPF, INSEE pour la statistique).
- La note corrigée ne contient aucune affirmation non sourcée.

**Pistes de corrigé (d'après notre dossier de recherche, nov. 2026 — à confirmer sur Légifrance et Service-public.fr).** Le reste à charge CPF est de **150 €** (et non 100 €) depuis le **2 avril 2026** (décret 2026-234) ; le plafond de prise en charge pour les certifications du Répertoire spécifique est de **1 500 €** (décret 2026-127), non 2 000 € ; la formation à distance est bel et bien possible (article D. 6313-3-1 : assistance, durée estimée des activités, évaluations) — l'article « L. 6323-4-2 » cité et son contenu sont à considérer comme inventés tant que vous ne les avez pas trouvés sur Légifrance ; la statistique « 47 % » ne correspond à aucune publication connue de l'INSEE : à supprimer. Ligne de traçabilité : « Note rédigée avec l'aide d'une IA, vérifiée sur Légifrance et Service-public.fr par [nom] le [date] ».

## ✅ Auto-évaluation express

1. Quelles sont les cinq étapes de la méthode ?
2. Pourquoi « Es-tu sûr ? » n'est-il pas une vérification ?
3. Dans l'affaire Air Canada (2024), qu'a retenu le tribunal ?

**Réponses.** 1) Classer, repérer les signaux d'alerte, remonter à la source primaire, contre-vérifier (deux sources indépendantes, second outil, citations), corriger et tracer. 2) Parce que le modèle produit une nouvelle réponse plausible, qui peut confirmer l'erreur ou se rétracter à tort ; seule une source extérieure vérifie. 3) Que l'entreprise est responsable des informations données par son chatbot : une politique inventée par l'IA a dû être honorée.

## 📚 Pour aller plus loin
- [AI Fluency: Framework and foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations) 🇬🇧 — les modules « Discernment » et « Diligence », avec la boucle Description-Discernement.
- [AI capabilities and limitations](https://academy.claude.com/courses/ai-capabilities-and-limitations) 🇬🇧 — 3,5 h gratuites pour comprendre, exercices à l'appui, pourquoi le modèle sait certaines choses et pas d'autres.
- [Evaluating & Validating Claude's Output](https://anthropic-partners.skilljar.com/evaluating-validating-claudes-output) 🇬🇧 — le cours (74 min) du parcours Associate d'Anthropic correspondant au premier domaine de l'examen ; page lisible sans compte.
- [AI Index Report 2026](https://hai.stanford.edu/ai-index/2026-ai-index-report) 🇬🇧 — chapitre 3 « Responsible AI » : incidents, évaluation, confiance.
- [CNIL — les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — la source primaire française pour tout ce qui touche aux données personnelles.
