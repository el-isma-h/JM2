---
id: L003
module: M01
level: N1
title: "Les grandes familles d'IA : vision, langage, recommandation, prédiction"
minutes: 40
objectives:
  - "Identifier les quatre grandes familles d'applications de l'IA (vision, langage, recommandation, prédiction) et leurs tâches types"
  - "Associer un besoin métier concret à la famille d'IA et au type de modèle adaptés"
  - "Expliquer pourquoi les modèles multimodaux de 2026 brouillent les frontières entre familles"
skills: ["C1.1", "C1.2"]
sources:
  - { title: "Microsoft Learn — Guide d'étude AI-900 (domaines : vision, NLP, IA générative)", url: "https://learn.microsoft.com/certifications/resources/study-guides/AI-900", lang: "en" }
  - { title: "MIT 6.S191 — Introduction to Deep Learning (séances vision et séquences)", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "Harvard CS50's Introduction to Artificial Intelligence with Python", url: "https://pll.harvard.edu/course/cs50s-introduction-artificial-intelligence-Python", lang: "en" }
  - { title: "Microsoft — AI for Beginners (parties Computer Vision et NLP)", url: "https://github.com/microsoft/ai-for-beginners", lang: "en" }
  - { title: "Claude Platform — Choosing a model", url: "https://platform.claude.com/docs/en/about-claude/models/choosing-a-model", lang: "en" }
  - { title: "Ollama — catalogue de modèles ouverts", url: "https://ollama.com/search", lang: "en" }
---

# Les grandes familles d'IA : vision, langage, recommandation, prédiction

> ⏱ 40 min · 🎯 Niveau 1 · 📚 Module 1

## 🎯 Ce que vous saurez faire
- Nommer les quatre grandes familles d'applications de l'IA et, pour chacune, trois tâches concrètes avec un exemple d'entreprise française.
- Face à un besoin (« je veux lire mes factures automatiquement », « je veux prévoir mes ventes »), dire quelle famille mobiliser et quel type d'outil regarder.
- Comprendre ce qu'est un modèle **multimodal** et pourquoi, en 2026, un même assistant peut voir, lire, écouter et écrire.

## 1. Une carte pour s'orienter

La leçon précédente a montré *comment* une machine apprend. Celle-ci répond à la question *pour faire quoi ?* Les référentiels des certifications grand public — le guide d'étude Microsoft AI-900, Google AI Essentials — découpent le paysage de la même façon : par **type de donnée d'entrée** et par **type de sortie**. Nous retiendrons quatre familles principales, plus deux familles « transversales ».

```
            ENTRÉE                       FAMILLE                    SORTIE TYPIQUE
  image, vidéo, scan      ──►   👁  VISION PAR ORDINATEUR   ──►  étiquette, boîte, texte lu
  texte, parole           ──►   💬  LANGAGE (NLP / LLM)     ──►  classe, résumé, traduction, texte
  historique d'usages     ──►   🎯  RECOMMANDATION          ──►  classement personnalisé
  tableaux, séries        ──►   📈  PRÉDICTION (ML tabulaire)──►  nombre, probabilité, alerte
  ─────────────────────────────────────────────────────────────────────────────────
  tout                    ──►   🧩  GÉNÉRATIF MULTIMODAL    ──►  texte, image, son, vidéo, code
  un environnement        ──►   🤖  DÉCISION / ROBOTIQUE    ──►  une action
```

## 2. 👁 Vision par ordinateur (*computer vision*)

La machine « regarde » des pixels et en tire du sens. Les grandes tâches, par difficulté croissante :

| Tâche | Question posée | Exemple professionnel français |
|---|---|---|
| **Classification d'images** | « Qu'est-ce que c'est ? » | Un négociant en vins trie les photos d'étiquettes par appellation |
| **Détection d'objets** | « Où sont les objets, et lesquels ? » | Une usine agroalimentaire compte les pièces sur un convoyeur et repère les défauts |
| **Segmentation** | « Quels pixels appartiennent à quoi ? » | Un cabinet de radiologie délimite une lésion sur une IRM |
| **OCR / lecture de documents** | « Que dit ce texte imprimé ou manuscrit ? » | Un cabinet comptable extrait montant, TVA et date de 2 000 factures fournisseurs par mois |
| **Reconnaissance faciale / biométrie** | « Qui est-ce ? » | Déverrouillage de téléphone ; attention : usage très encadré par le RGPD et l'AI Act (module 7) |

Technologie dominante : les **réseaux convolutifs** (CNN), stars de la révolution de 2012 (AlexNet) — le MIT 6.S191 leur consacre sa séance « Deep Computer Vision » — rejoints depuis par les *vision transformers*. Anecdote : le premier succès industriel du deep learning en vision date de 1998, lorsque le réseau LeNet de Yann LeCun lisait les chiffres manuscrits des chèques bancaires aux États-Unis.

En 2026, l'OCR « classique » est largement remplacé par des modèles multimodaux : vous glissez la photo d'une facture dans Claude, Gemini ou ChatGPT et vous obtenez directement un tableau structuré. Pour un usage massif et confidentiel, des modèles ouverts à capacité visuelle (Qwen3.8, Gemma 4) tournent en local (niveau 2).

> ⚠️ **Piège fréquent** — Croire qu'un modèle de vision « comprend » la scène. Il associe des motifs de pixels à des étiquettes vues à l'entraînement. Un autocollant sur un panneau stop peut suffire à tromper un détecteur, et un modèle entraîné sur des visages majoritairement clairs reconnaît moins bien les peaux foncées — le lab 2 du MIT 6.S191 porte précisément sur ce biais algorithmique.

## 3. 💬 Langage (*natural language processing*, NLP)

La famille qui a changé le travail de bureau. Avant 2018, chaque tâche avait son modèle spécialisé ; depuis les Transformers et les LLM, un seul modèle généraliste accomplit la plupart d'entre elles.

| Tâche | Exemple professionnel |
|---|---|
| **Classification de texte / analyse de sentiment** | Une enseigne de magasins trie 10 000 avis clients en positifs, négatifs, à traiter en urgence |
| **Extraction d'entités** | Un service juridique repère noms, dates, montants et clauses dans des contrats |
| **Résumé** | Une DRH résume 40 pages de convention collective en une fiche |
| **Traduction** | Un artisan exporte vers l'Allemagne avec des devis traduits |
| **Question-réponse sur documents** | Un cabinet d'expertise interroge sa base de notes techniques (vous construirez cela au niveau 2, c'est le « RAG ») |
| **Génération** | Rédaction de fiches produit, d'e-mails, de comptes rendus, de code |
| **Parole** (*speech-to-text*, *text-to-speech*) | Transcription automatique de réunions ; serveur vocal d'un cabinet médical |

Les LLM de référence en novembre 2026 : Claude Fable 5.1, Opus 5.5, Sonnet 5.5 et Haiku 5.5 (Anthropic), la famille GPT-6 (OpenAI), Gemini 4 (Google), Grok 4.7 (xAI), Mistral Large 4 et Small 4 (Mistral AI, France) ; côté modèles à poids ouverts : Qwen3.8, Gemma 4, gpt-oss, DeepSeek V4.1, Kimi K3, Llama 4. Le module 2 leur est entièrement consacré ; le module 3 vous apprendra à choisir entre eux.

> 🔗 **Documentation officielle** — [Claude Platform — Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model) 🇬🇧 présente la logique de choix entre un modèle rapide et économique (Haiku) et un modèle de raisonnement avancé (Opus, Fable) — exactement le type d'arbitrage que vous ferez au module 3.

## 4. 🎯 Recommandation

La famille la plus discrète et la plus rentable. Netflix, Amazon, Spotify, TikTok, mais aussi votre site de vente en ligne de pièces détachées : « les clients qui ont acheté ceci ont aussi acheté… ».

Deux grandes techniques, enseignées notamment dans la spécialisation *Machine Learning* d'Andrew Ng :
- **Filtrage collaboratif** : on ne regarde pas le contenu des produits, seulement les comportements. Si Marie et Paul ont acheté les mêmes six articles et que Marie en achète un septième, on le propose à Paul.
- **Recommandation basée sur le contenu** : on décrit les produits (catégorie, prix, mots-clés, et aujourd'hui *embeddings* — des vecteurs de sens que vous rencontrerez au niveau 2) et on propose ce qui ressemble à ce que l'utilisateur aime.

Exemple PME : une librairie indépendante de Lyon avec 30 000 références utilise un module de recommandation de sa plateforme e-commerce ; aucune donnée personnelle sensible, juste l'historique d'achats anonymisé. Point de vigilance : l'**effet bulle** (on ne propose que du semblable) et, pour les plateformes, les obligations de transparence des systèmes de recommandation prévues par le règlement européen sur les services numériques (DSA).

## 5. 📈 Prédiction sur données tabulaires

La famille historique du machine learning en entreprise, et de loin la plus répandue dans les PME, l'industrie et la banque. Les données sont des **tableaux** (lignes = observations, colonnes = variables) et la sortie, un nombre ou une probabilité.

| Besoin | Type | Exemple |
|---|---|---|
| Prévoir les ventes de la semaine prochaine | Régression / séries temporelles | Une boulangerie-pâtisserie ajuste sa production selon la météo et le calendrier |
| Estimer la probabilité qu'un client parte | Classification (*churn*) | Un opérateur télécom cible ses offres de rétention |
| Détecter une transaction frauduleuse | Classification / détection d'anomalie | Une banque bloque un paiement inhabituel en 50 millisecondes |
| Prédire la panne d'une machine | Maintenance prédictive | Un parc d'éoliennes planifie ses interventions |
| Évaluer un risque de crédit | Scoring | Un organisme de crédit — usage classé **haut risque** par l'AI Act (module 7) |

Ici, ce ne sont pas les réseaux de neurones qui dominent mais des méthodes plus sobres et explicables : régression logistique, **arbres de décision** et forêts aléatoires, *gradient boosting* (XGBoost). Elles sont au programme de tous les cours d'introduction — MIT 6.036/6.390, Stanford CS229, cours 4 « Learning » de CS50 AI — et vous les pratiquerez au niveau 4. Avantage décisif en entreprise : on peut souvent **expliquer** pourquoi le modèle a décidé, ce que le RGPD et l'AI Act exigent dans de nombreux cas.

> 💡 **À retenir** — Quatre familles, quatre entrées : pixels (vision), mots (langage), comportements (recommandation), tableaux (prédiction). Les LLM sont impressionnants, mais pour prévoir des ventes à partir d'un tableau Excel, un modèle de prédiction classique est souvent meilleur, moins cher et plus explicable.

## 6. Les familles transversales de 2026

### 6.1 Le génératif multimodal : la fusion des familles

Un modèle **multimodal** accepte plusieurs types d'entrées (texte, image, audio, vidéo, PDF) et produit plusieurs types de sorties. Les assistants actuels — Claude, ChatGPT, Gemini, Grok — lisent une photo de tableau blanc, écoutent un mémo vocal et répondent en texte ; des modèles dédiés génèrent images, vidéos et musique. Conséquence pour votre carte mentale : la frontière entre « vision » et « langage » s'efface **à l'usage**, mais pas dans l'architecture : un modèle multimodal reste un grand modèle de langage auquel on a greffé des « yeux » et des « oreilles ».

Trois réflexes :
1. Pour une tâche ponctuelle (lire une facture, décrire une photo), le modèle multimodal généraliste suffit.
2. Pour un flux industriel (100 000 images par jour, temps réel, confidentialité), un modèle de vision spécialisé reste plus pertinent et moins cher.
3. Tout contenu généré (image, voix, vidéo) relève d'obligations de transparence (AI Act art. 50, applicable depuis le 2 août 2026) — vous le verrez en L004 et au module 7.

### 6.2 Décision et robotique

L'apprentissage par renforcement et la planification (famille « recherche » des cours 6.034 et CS50 AI) servent à **agir** : piloter un robot d'entrepôt, optimiser une tournée de livraison, jouer au go. Les **agents IA** de 2026 — des LLM qui enchaînent eux-mêmes des actions (chercher sur le web, remplir un formulaire, lancer un programme) — appartiennent à cette logique de décision : vous les découvrirez au module 6. Pour fixer les idées : l'AI Index 2026 de Stanford relève que la réussite des agents sur le benchmark OSWorld (tâches sur ordinateur) est passée d'environ 5 % en 2024 à 66,3 % en 2025, contre 72,35 % pour des humains (nov. 2026).

🎮 **Défi éclair** — Pour chaque besoin, trouvez la famille en moins de dix secondes : (a) « Repérer les colis abîmés sur la chaîne » ; (b) « Proposer la formation suivante à chaque salarié selon son parcours » ; (c) « Anticiper les retards de paiement » ; (d) « Rédiger les comptes rendus de réunion ». (Réponses : a vision ; b recommandation ; c prédiction tabulaire ; d langage génératif.)

> 🔗 **Documentation officielle** — Le [guide d'étude Microsoft AI-900](https://learn.microsoft.com/certifications/resources/study-guides/AI-900) 🇬🇧 liste les charges de travail IA (vision, NLP, documents, IA générative) et les six principes d'IA responsable de Microsoft ; ce référentiel (examen remplacé par AI-901 depuis juin 2026) reste une excellente grille de lecture. Le catalogue [Ollama — Search](https://ollama.com/search) 🇬🇧 montre concrètement les familles de modèles ouverts : texte, vision, embeddings, outils.

## 🧪 Exercice pratique

**Consigne.** Vous êtes consultant pour **Menuiserie Dubois**, PME de 35 salariés en Loire-Atlantique (fabrication de fenêtres sur mesure, vente aux particuliers et aux artisans). La direction a listé six irritants :

1. Les devis sont saisis à la main à partir des croquis cotés envoyés par les artisans (photos de carnets).
2. Le service après-vente reçoit 60 e-mails par jour, dont un tiers de questions récurrentes.
3. Le stock de profilés aluminium est tantôt en rupture, tantôt pléthorique.
4. Le site e-commerce de quincaillerie vend 4 000 références, mais le panier moyen stagne.
5. Les techniciens photographient chaque pose ; personne ne vérifie la conformité avant la facturation.
6. La dirigeante voudrait un rapport hebdomadaire lisible à partir du tableau de bord Excel de production.

Pour chaque irritant, indiquez : **la famille d'IA**, **le type d'entrée et de sortie**, **si un assistant généraliste suffit ou s'il faut un modèle spécialisé**, et **un risque à surveiller**.

**Critères de réussite.**
- Les six irritants sont correctement rattachés à une famille (au moins quatre familles différentes apparaissent).
- Pour au moins deux irritants, vous expliquez pourquoi un LLM généraliste multimodal suffit ; pour au moins un, pourquoi un modèle spécialisé ou classique est préférable.
- Chaque ligne comporte un risque concret (hallucination, biais, confidentialité, explicabilité, coût).

<details>
<summary>Pistes de corrigé</summary>

| # | Famille | Entrée → sortie | Généraliste ou spécialisé | Risque |
|---|---|---|---|---|
| 1 | Vision multimodale (lecture de croquis) | Photo → cotes structurées | Généraliste multimodal pour commencer, avec validation humaine | Erreur de cote → fenêtre inutilisable : contrôle obligatoire |
| 2 | Langage | E-mail → classe + brouillon | Généraliste (LLM) | Hallucination de délai ; données clients dans le prompt (RGPD) |
| 3 | Prédiction tabulaire | Historique de ventes, saisonnalité → quantité | Modèle classique (régression / séries temporelles) | Données historiques incomplètes ; sur-apprentissage |
| 4 | Recommandation | Historique d'achats → suggestions | Module e-commerce existant (filtrage collaboratif) | Effet bulle, faible volume de données |
| 5 | Vision (détection) | Photos de pose → conforme / non conforme | Spécialisé si volume ; généraliste multimodal en pilote | Biais d'éclairage, faux positifs ; photos de domiciles (RGPD) |
| 6 | Langage génératif + analyse de données | Tableau → rapport rédigé | Généraliste | Chiffres mal recopiés : vérifier les totaux |

</details>

## ✅ Auto-évaluation express

1. Quelle famille d'IA mobilisez-vous pour estimer, à partir d'un historique de 5 ans, le chiffre d'affaires du mois prochain ?
2. Un modèle multimodal est-il un modèle de vision ou un modèle de langage ?
3. Pourquoi préfère-t-on souvent un arbre de décision à un réseau de neurones pour un scoring de crédit ?

<details>
<summary>Réponses</summary>

1. La prédiction sur données tabulaires (régression / séries temporelles), pas un LLM.
2. C'est d'abord un grand modèle de langage auquel on a ajouté des entrées image et audio ; à l'usage, il couvre les deux familles.
3. Parce que sa décision est explicable, ce que le RGPD et l'AI Act exigent pour un usage à haut risque comme le crédit, et parce qu'il est souvent aussi performant sur des données tabulaires.

</details>

## 📚 Pour aller plus loin
- [Harvard CS50 AI — Introduction to Artificial Intelligence with Python](https://pll.harvard.edu/course/cs50s-introduction-artificial-intelligence-Python) 🇬🇧 — sept semaines (recherche, connaissance, incertitude, optimisation, apprentissage, réseaux de neurones, langage) ; audit gratuit.
- [Microsoft — AI for Beginners](https://github.com/microsoft/ai-for-beginners) 🇬🇧 — parties IV « Computer Vision » et V « NLP », avec notebooks (licence MIT).
- [MIT 6.S191 — Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 — séances « Deep Computer Vision », « Deep Sequence Modeling » et « Deep Reinforcement Learning ».
- [Stanford HAI — AI Index Report 2026](https://hai.stanford.edu/ai-index/2026-ai-index-report) 🇬🇧 — chapitre « Technical Performance » : où en est chaque famille.
