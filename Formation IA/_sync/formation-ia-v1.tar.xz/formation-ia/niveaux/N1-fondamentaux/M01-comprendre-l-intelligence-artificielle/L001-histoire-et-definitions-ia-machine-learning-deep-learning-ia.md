---
id: L001
module: M01
level: N1
title: "Histoire et définitions : IA, machine learning, deep learning, IA générative"
minutes: 45
objectives:
  - "Distinguer les quatre notions emboîtées : intelligence artificielle, machine learning, deep learning et IA générative"
  - "Situer les dix dates clés de l'histoire de l'IA, de Turing (1950) aux modèles de 2026"
  - "Reconnaître dans un exemple professionnel à quelle famille appartient un système d'IA"
skills: ["C1.1"]
sources:
  - { title: "MIT 6.S191 — Introduction to Deep Learning (2026)", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "MIT OCW 6.034 — Artificial Intelligence (Patrick Winston)", url: "https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/pages/syllabus/", lang: "en" }
  - { title: "MIT OCW 6.S087 — Foundation Models and Generative AI", url: "https://ocw.mit.edu/courses/6-s087-foundation-models-and-generative-ai-january-iap-2024/", lang: "en" }
  - { title: "Elements of AI (version française)", url: "https://www.elementsofai.com/", lang: "fr" }
  - { title: "Microsoft — AI for Beginners", url: "https://github.com/microsoft/ai-for-beginners", lang: "en" }
  - { title: "Claude Academy — AI Fluency: Framework and Foundations", url: "https://academy.claude.com/courses/ai-fluency-framework-foundations", lang: "en" }
---

# Histoire et définitions : IA, machine learning, deep learning, IA générative

> ⏱ 45 min · 🎯 Niveau 1 · 📚 Module 1

## 🎯 Ce que vous saurez faire
- Expliquer avec vos propres mots la différence entre *intelligence artificielle*, *machine learning*, *deep learning* et *IA générative*, et dessiner le schéma des « poupées russes » qui les relie.
- Raconter l'histoire de l'IA en dix dates exactes, sans confondre les époques ni les héros.
- Classer un outil que vous utilisez au travail (filtre anti-spam, GPS, ChatGPT, Claude…) dans la bonne famille.

## 1. Quatre mots, quatre poupées russes

Au café, « l'IA » désigne tout et n'importe quoi : le robot de science-fiction, l'assistant vocal du téléphone, le chatbot qui rédige vos e-mails. Pour travailler sérieusement avec ces outils, il faut d'abord ranger le vocabulaire. Les quatre termes du titre de cette leçon ne sont pas des synonymes : ce sont des **ensembles emboîtés**, comme des poupées russes.

```
┌──────────────────────────────────────────────────────────┐
│ INTELLIGENCE ARTIFICIELLE (IA)                           │
│  « faire faire à une machine ce qui demande de           │
│  l'intelligence à un humain » — règles, recherche, logique│
│  ┌────────────────────────────────────────────────────┐  │
│  │ MACHINE LEARNING (apprentissage automatique)       │  │
│  │  la machine apprend des régularités dans des données│  │
│  │  ┌──────────────────────────────────────────────┐  │  │
│  │  │ DEEP LEARNING (apprentissage profond)        │  │  │
│  │  │  réseaux de neurones à nombreuses couches     │  │  │
│  │  │  ┌────────────────────────────────────────┐  │  │  │
│  │  │  │ IA GÉNÉRATIVE                          │  │  │  │
│  │  │  │  produit du nouveau contenu : texte,   │  │  │  │
│  │  │  │  image, son, code (ChatGPT, Claude…)   │  │  │  │
│  │  │  └────────────────────────────────────────┘  │  │  │
│  │  └──────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

### 1.1 Intelligence artificielle (IA) : le grand parapluie

L'expression *artificial intelligence* est née en 1956, dans la proposition d'un atelier d'été au Dartmouth College (États-Unis), rédigée notamment par John McCarthy, Marvin Minsky, Claude Shannon et Nathaniel Rochester. L'ambition affichée : décrire chaque aspect de l'intelligence si précisément qu'une machine puisse le simuler. Aujourd'hui, le terme désigne **tout programme qui accomplit une tâche réputée demander de l'intelligence** : jouer aux échecs, traduire, reconnaître un visage, planifier un trajet.

Point important : une IA **n'apprend pas forcément**. Le GPS de votre voiture calcule le meilleur itinéraire grâce à un algorithme de recherche (le même principe que celui enseigné dans le cours 6.034 du MIT ou dans CS50 AI de Harvard) ; il ne s'est jamais « entraîné » sur vos trajets. On parle d'**IA symbolique** ou de « bonne vieille IA » : des règles écrites à la main par des experts. Les premiers **systèmes experts** médicaux des années 1970-1980 fonctionnaient ainsi, avec des centaines de règles « SI fièvre ET toux ALORS… ».

### 1.2 Machine learning : la machine apprend des exemples

Avec le *machine learning* (ML, apprentissage automatique), on change de méthode : au lieu d'écrire les règles, **on fournit des exemples et la machine trouve les règles elle-même**. L'informaticien américain Arthur Samuel, qui faisait apprendre le jeu de dames à un ordinateur IBM dès la fin des années 1950, est souvent cité pour cette idée : donner aux ordinateurs la capacité d'apprendre sans être explicitement programmés.

Analogie du quotidien : pour apprendre à un enfant ce qu'est un chat, vous ne lui dictez pas « quatre pattes, moustaches, queue, oreilles pointues » (le chien aurait trois critères sur quatre). Vous lui montrez des chats. Beaucoup de chats. Le ML fait pareil avec des milliers d'exemples étiquetés.

Exemple professionnel : le **filtre anti-spam** de votre messagerie est du machine learning classique. Il a vu des millions d'e-mails marqués « spam » ou « légitime » et a appris quels mots, expéditeurs et structures sont suspects. La leçon suivante (L002) détaille comment se passe cet apprentissage.

### 1.3 Deep learning : des réseaux de neurones empilés

Le *deep learning* (apprentissage profond) est **une famille de méthodes du machine learning** fondée sur les **réseaux de neurones artificiels** : des couches de petites unités de calcul inspirées — très librement — des neurones biologiques. « Profond » signifie simplement **beaucoup de couches** (des dizaines, voire des centaines). Chaque couche extrait des caractéristiques de plus en plus abstraites : pour une photo, la première couche repère des contours, la suivante des formes, puis des yeux, puis un visage.

Pourquoi cette famille a-t-elle tout emporté depuis 2012 ? Trois ingrédients réunis au même moment : des **données** massives (Internet), de la **puissance de calcul** (les cartes graphiques, GPU, conçues pour les jeux vidéo) et des **algorithmes** affinés depuis les années 1980 (la rétropropagation du gradient, que vous rencontrerez en L002). Le cours MIT 6.S191 consacre sa toute première séance à ce trio.

### 1.4 IA générative : la machine produit du contenu

L'**IA générative** est le sous-ensemble du deep learning dont les modèles **créent du contenu nouveau** — texte, image, musique, vidéo, code — plutôt que de classer ou de prédire une étiquette. ChatGPT, Claude, Gemini, Grok, Mistral, Midjourney ou Suno en font partie. Un **grand modèle de langage** (*large language model*, LLM) est un modèle génératif spécialisé dans le texte : il a appris, sur une gigantesque quantité de textes, à prédire le mot suivant, et cette capacité en apparence modeste suffit pour rédiger, résumer, traduire ou coder.

> 💡 **À retenir** — IA ⊃ machine learning ⊃ deep learning ⊃ IA générative. Tout LLM est une IA, mais toute IA n'est pas un LLM : votre GPS, votre filtre anti-spam et Claude sont trois « IA » qui n'ont presque rien en commun techniquement.

> ⚠️ **Piège fréquent** — Dire « l'IA » pour parler uniquement de ChatGPT. Dans une réunion, précisez toujours de quelle famille il s'agit : un logiciel de détection de fraude bancaire (ML classique) ne présente pas les mêmes risques ni les mêmes coûts qu'un assistant génératif.

## 2. Soixante-quinze ans d'histoire en dix dates

L'IA a connu des étés enthousiastes et des **hivers** (*AI winters*) où les financements se sont taris parce que les promesses n'étaient pas tenues. Connaître cette chronologie vous protège du double piège de l'emballement et du scepticisme.

| Année | Événement | Pourquoi c'est important |
|---|---|---|
| **1950** | Alan Turing publie *Computing Machinery and Intelligence* et propose le « jeu de l'imitation » (test de Turing) | Première formulation sérieuse de la question « une machine peut-elle penser ? » |
| **1956** | Atelier de Dartmouth : le terme *artificial intelligence* est officialisé | Naissance de la discipline |
| **1957-1958** | Frank Rosenblatt présente le **perceptron**, ancêtre du neurone artificiel | Premier modèle qui apprend ses poids à partir d'exemples |
| **1966** | ELIZA (Joseph Weizenbaum, MIT) simule un psychothérapeute par simples règles de reformulation | Premier « chatbot » ; déjà, des utilisateurs s'y attachent — l'« effet ELIZA » |
| **1974-1980 puis 1987-1993** | Deux hivers de l'IA | Les promesses excessives (traduction automatique, systèmes experts) déçoivent, les budgets chutent |
| **1986** | Rumelhart, Hinton et Williams popularisent la **rétropropagation** pour entraîner des réseaux multicouches | L'algorithme qui fait encore tourner le deep learning en 2026 |
| **1997** | Deep Blue (IBM) bat le champion du monde d'échecs Garry Kasparov | Triomphe de l'IA symbolique et de la force de calcul (pas d'apprentissage) |
| **2012** | AlexNet (Krizhevsky, Sutskever, Hinton) écrase la compétition de reconnaissance d'images ImageNet grâce à un réseau profond sur GPU | Point de départ de la vague deep learning |
| **2016** | AlphaGo (DeepMind) bat Lee Sedol au jeu de go, 4 parties à 1 | Combinaison deep learning + apprentissage par renforcement sur un jeu jugé hors de portée |
| **2017** | Article *Attention Is All You Need* (Vaswani et al., Google) : l'architecture **Transformer** | Le « T » de GPT ; base de tous les LLM actuels |
| **30 nov. 2022** | Lancement public de ChatGPT (OpenAI) | L'IA générative entre dans le grand public ; adoption la plus rapide de l'histoire du numérique |
| **2024** | Prix Nobel de physique à John Hopfield et Geoffrey Hinton (réseaux de neurones) ; prix Nobel de chimie à Demis Hassabis et John Jumper (AlphaFold) avec David Baker | L'IA reconnue comme science fondamentale |
| **2026** | Génération actuelle : Claude Fable 5.1 / Opus 5.5 / Sonnet 5.5 / Haiku 5.5 (Anthropic), famille GPT-6 (OpenAI), Gemini 4 (Google), Grok 4.7 (xAI), Mistral Large 4 ; modèles ouverts Qwen3.8, Gemma 4, DeepSeek V4.1, Kimi K3 (nov. 2026) | Fenêtres de contexte d'un million de tokens, agents capables d'exécuter des tâches de plusieurs heures |

🎮 **Défi** — Sans regarder le tableau, placez dans l'ordre : AlphaGo, Deep Blue, ChatGPT, Dartmouth, le Transformer. (Réponse : Dartmouth 1956 → Deep Blue 1997 → AlphaGo 2016 → Transformer 2017 → ChatGPT 2022.)

Anecdote exacte : en 1965, Herbert Simon, futur prix Nobel d'économie, prédisait que les machines seraient capables « d'ici vingt ans » de faire tout travail qu'un homme peut faire. Il s'est trompé de plusieurs décennies — et c'est précisément ce genre d'annonce qui a déclenché le premier hiver. Gardez ce réflexe : **une démonstration spectaculaire n'est pas un déploiement industriel**.

> 🔗 **Documentation officielle** — Le cours [MIT 6.S191 — Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 (supports sous licence MIT) retrace ce basculement vers le deep learning dans sa première séance ; le cours historique [MIT OCW 6.034 — Artificial Intelligence](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/pages/syllabus/) 🇬🇧 de Patrick Winston couvre l'IA symbolique (recherche, règles, contraintes).

## 3. Trois approches, trois façons de « réfléchir »

Pour affiner, les chercheurs distinguent trois grandes approches qui coexistent dans les produits de 2026.

| Approche | Comment la machine « sait » | Exemple vécu | Force | Faiblesse |
|---|---|---|---|---|
| **Symbolique** (règles, logique, recherche) | Un humain écrit les règles | GPS, moteur de règles d'un logiciel de paie, Deep Blue | Explicable, prévisible | Ne gère pas l'imprévu, coûteux à maintenir |
| **Statistique / ML classique** | Elle apprend des régularités chiffrées dans des tableaux de données | Scoring crédit, anti-spam, prévision des ventes | Efficace sur des données structurées, peu gourmande | Demande des caractéristiques préparées à la main |
| **Connexionniste / deep learning** | Des millions de paramètres ajustés sur des données brutes (pixels, mots, sons) | Reconnaissance faciale, traduction, Claude, ChatGPT | Traite l'image, le son, le langage naturel | Opaque, gourmande en données et en calcul, peut « halluciner » |

Dans une PME française typique, les trois cohabitent : le logiciel de comptabilité applique des règles fiscales (symbolique), l'outil de relance client classe les factures à risque (ML classique) et l'assistant qui rédige le brouillon de relance est un LLM (deep learning génératif).

> ⚠️ **Piège fréquent** — Croire qu'un LLM « raisonne » comme un logiciel de règles. Un LLM produit la suite de mots la plus probable ; il peut écrire avec aplomb une règle fiscale fausse. Vous apprendrez en L002 et au module 2 pourquoi, et au module 5 comment vérifier.

## 4. Vocabulaire minimal pour la suite du parcours

- **Modèle** : le programme obtenu après apprentissage (un fichier de paramètres plus un peu de code).
- **Paramètres** (*weights*) : les nombres ajustés pendant l'entraînement ; on parle de milliards (B) pour les LLM.
- **Entraînement** / **inférence** : la phase d'apprentissage, coûteuse et rare ; puis la phase d'utilisation, à chaque question posée (détail en L002).
- **Données d'entraînement** : les exemples montrés au modèle ; leur qualité fait celle du modèle.
- **Token** : l'unité de texte manipulée par un LLM (environ trois quarts d'un mot anglais ; le français en consomme 30 à 50 % de plus). Vous y reviendrez en module 2.
- **Modèle de fondation** (*foundation model*) : grand modèle entraîné une fois sur des données générales, puis adapté à mille usages — le cours MIT 6.S087 lui est entièrement consacré.

> 🔗 **Documentation officielle** — [MIT OCW 6.S087 — Foundation Models and Generative AI](https://ocw.mit.edu/courses/6-s087-foundation-models-and-generative-ai-january-iap-2024/) 🇬🇧, cours non technique sur l'histoire de l'IA et les modèles de fondation ; [Microsoft — AI for Beginners](https://github.com/microsoft/ai-for-beginners) 🇬🇧 (licence MIT), dont la première partie « Intro & History » et la deuxième « Symbolic AI » complètent cette leçon.

## 🧪 Exercice pratique

**Consigne.** Listez cinq outils numériques que vous utilisez dans votre activité (ou votre vie quotidienne) et qui contiennent « de l'IA » : par exemple la suggestion de mots du clavier du téléphone, le GPS, le filtre anti-spam, la recommandation de vidéos, un assistant conversationnel, la détection de fraude de votre banque, un logiciel de reconnaissance de caractères sur une facture.

Pour chacun, remplissez un tableau à quatre colonnes : **Outil · Famille (symbolique / ML classique / deep learning / IA générative) · Indice qui justifie votre choix · Ce que l'outil produit (une décision, un score, un contenu ?)**.

**Critères de réussite.**
1. Les cinq outils sont classés et au moins trois familles différentes apparaissent.
2. Chaque classement s'appuie sur un indice concret (« il a appris sur mes e-mails », « il génère un texte nouveau », « il applique une règle fixe »).
3. Vous avez repéré au moins un outil qui mélange deux familles (un GPS avec prévision de trafic apprise, par exemple).

<details>
<summary>Corrigé indicatif</summary>

| Outil | Famille | Indice | Produit |
|---|---|---|---|
| GPS (calcul d'itinéraire) | Symbolique (recherche de chemin) ; la prévision de trafic est du ML | Règle fixe : plus court chemin ; le trafic est appris sur l'historique | Une décision (itinéraire) |
| Filtre anti-spam | ML classique | Il s'améliore quand vous signalez un spam | Un score / une classe |
| Clavier prédictif | Deep learning (petit modèle de langage) | Propose le mot suivant selon le contexte | Un contenu court |
| Recommandation de vidéos | ML / deep learning | Apprend de vos clics et de ceux des autres | Un classement |
| Claude / ChatGPT | IA générative (LLM) | Rédige un texte inédit | Un contenu |
| OCR de factures | Deep learning (vision) | Lit des images de caractères variés | Un texte extrait |

</details>

## ✅ Auto-évaluation express

1. Le deep learning est-il un sous-ensemble du machine learning, ou l'inverse ?
2. Quel événement de 2017 est à l'origine de l'architecture de tous les LLM actuels ?
3. Un moteur de règles de paie qui applique le Code du travail est-il de l'IA générative ?

<details>
<summary>Réponses</summary>

1. Le deep learning est un sous-ensemble du machine learning (réseaux de neurones à nombreuses couches).
2. La publication de l'article *Attention Is All You Need* qui introduit le Transformer.
3. Non : c'est de l'IA symbolique (règles écrites par des humains) ; il ne génère pas de contenu nouveau et n'apprend pas.

</details>

## 📚 Pour aller plus loin
- [Elements of AI — Introduction à l'IA](https://www.elementsofai.com/) 🇫🇷 — le MOOC gratuit de l'université d'Helsinki, disponible en français (Sorbonne Université) ; chapitre 1 « Qu'est-ce que l'IA ? ».
- [Claude Academy — AI Fluency: Framework and Foundations](https://academy.claude.com/courses/ai-fluency-framework-foundations) 🇬🇧 — cours gratuit d'Anthropic (badge) sur les fondamentaux de la collaboration avec l'IA ; nous vous encourageons à le suivre en parallèle de ce niveau.
- [MIT OCW RES.6-013 — AI 101](https://ocw.mit.edu/courses/res-6-013-ai-101-fall-2021/) 🇬🇧 — atelier vidéo grand public du MIT.
- [DeepLearning.AI — AI For Everyone](https://www.deeplearning.ai/courses/ai-for-everyone) 🇬🇧 — le cours d'Andrew Ng pour non-techniciens (semaine 1 : « Qu'est-ce que l'IA ? »).
