---
id: L114
module: M24
level: N4
title: "Optimisation : descente de gradient"
minutes: 80
objectives:
  - "Appliquer la règle de mise à jour de la descente de gradient et prédire l'effet du taux d'apprentissage sur la convergence"
  - "Comparer descente par batch complet, SGD et mini-batch selon le coût, le bruit et l'usage GPU"
  - "Expliquer le rôle de la convexité et du conditionnement, et relier la limite du taux d'apprentissage aux valeurs propres de la hessienne"
  - "Implémenter momentum et Adam en NumPy et distinguer Adam avec régularisation L2 et AdamW"
  - "Construire un schedule warm-up + décroissance cosinus et une boucle d'entraînement PyTorch avec AdamW et écrêtage de gradient"
skills: ["C4.1"]
sources:
  - { title: "Kingma & Ba — Adam: A Method for Stochastic Optimization (arXiv:1412.6980)", url: "https://arxiv.org/abs/1412.6980", lang: "en" }
  - { title: "Loshchilov & Hutter — Decoupled Weight Decay Regularization (AdamW, arXiv:1711.05101)", url: "https://arxiv.org/abs/1711.05101", lang: "en" }
  - { title: "PyTorch — torch.optim (optimiseurs et schedulers)", url: "https://pytorch.org/docs/stable/optim.html", lang: "en" }
  - { title: "Stanford CS231n — Lecture 3 Regularization and optimization", url: "https://cs231n.stanford.edu/schedule.html", lang: "en" }
  - { title: "3Blue1Brown — Neural Networks (chap. 2 : Gradient descent)", url: "https://www.3blue1brown.com/topics/neural-networks", lang: "en" }
  - { title: "Deep Learning (Goodfellow, Bengio, Courville) — chap. 8 Optimization", url: "https://www.deeplearningbook.org/", lang: "en" }
  - { title: "MIT 6.390 IntroML — Fall 2026", url: "https://introml.mit.edu/fall26/info", lang: "en" }
---

# Optimisation : descente de gradient

> ⏱ 80 min · 🎯 Niveau 4 · 📚 Module 24

## 🎯 Ce que vous saurez faire
- Écrire et appliquer la règle $\theta \leftarrow \theta - \eta\,\nabla L(\theta)$, et prédire si elle converge, oscille ou diverge.
- Choisir entre batch complet, SGD et mini-batch, et régler un taux d'apprentissage de façon méthodique.
- Implémenter momentum et Adam à partir des formules, et expliquer ce qu'AdamW change.
- Mettre en place un warm-up suivi d'une décroissance cosinus dans une vraie boucle PyTorch.

## 1. Le randonneur dans le brouillard

Imaginez-vous sur un massif des Alpes, en plein brouillard, cherchant à rejoindre la vallée. Vous ne voyez pas la carte, mais vous sentez la pente sous vos pieds. Stratégie raisonnable : faire un pas dans la direction qui descend le plus, recommencer. C'est la **descente de gradient**. L'altitude est la perte $L(\theta)$, votre position les paramètres $\theta$, la pente le gradient (L112) et la longueur du pas le **taux d'apprentissage** (*learning rate*) $\eta$ :

$$\theta_{t+1} = \theta_t - \eta\,\nabla L(\theta_t)$$

Augustin-Louis Cauchy proposait déjà cette méthode en 1847 pour résoudre des systèmes d'équations. Cent quatre-vingts ans plus tard, elle entraîne tous les LLM : seules la manière d'estimer le gradient et la manière de régler le pas ont changé.

### 1.1 Le taux d'apprentissage, sur un exemple qu'on résout à la main

Prenons $L(x) = x^2$, de gradient $2x$. La règle devient $x_{t+1} = x_t - 2\eta x_t = (1 - 2\eta)\,x_t$, donc $x_t = (1-2\eta)^t x_0$ :

| $\eta$ | Facteur $1 - 2\eta$ | Comportement |
|---|---|---|
| 0,1 | 0,8 | converge lentement et régulièrement |
| 0,5 | 0 | atteint le minimum en un pas (cas idéal, introuvable en pratique) |
| 0,9 | −0,8 | converge en **oscillant** de part et d'autre du minimum |
| 1,1 | −1,2 | **diverge** : chaque pas fait grandir l'erreur |

```python
import numpy as np

for eta in (0.1, 0.5, 0.9, 1.1):
    x = 5.0
    for _ in range(20):
        x -= eta * 2 * x              # gradient de x² : 2x
    print(f"η={eta}: x après 20 pas = {x:.3e}")
```

> 💡 **À retenir** — Trop petit, le taux d'apprentissage gaspille du calcul ; trop grand, il fait osciller puis exploser la perte (les fameux `loss = nan`). C'est l'hyperparamètre le plus important de tout l'entraînement : si vous ne deviez en régler qu'un, ce serait lui.

## 2. Convexité et conditionnement : quand la descente est facile

Une fonction est **convexe** si le segment qui relie deux points de sa courbe reste au-dessus de la courbe :

$$L(\lambda a + (1-\lambda) b) \leq \lambda L(a) + (1-\lambda) L(b), \quad \forall \lambda \in [0, 1]$$

Pour une fonction deux fois dérivable, cela équivaut à une **hessienne** $H = \nabla^2 L$ (la matrice des dérivées secondes) semi-définie positive, c'est-à-dire à valeurs propres positives ou nulles (L111). Atout décisif : **tout minimum local est global**. La régression linéaire avec la MSE et la régression logistique sont convexes ; c'est pourquoi le module 25 peut garantir leur convergence.

Près d'un minimum, toute fonction régulière ressemble à une quadratique $\tfrac12 \theta^\top H \theta$. Dans la base des vecteurs propres de $H$, la descente agit indépendamment sur chaque direction avec le facteur $1 - \eta\lambda_i$, exactement comme dans le tableau précédent. D'où deux résultats :

- la descente converge si et seulement si $\eta < 2/\lambda_{\max}$ : c'est **la direction la plus raide qui fixe le pas maximal** ;
- la vitesse dans la direction la plus plate est alors limitée par $\lambda_{\min}/\lambda_{\max} = 1/\kappa$, où $\kappa$ est le **conditionnement**. Une vallée très allongée ($\kappa$ grand) se descend en zigzag, lentement.

C'est pour cela qu'on **standardise les variables** d'entrée (moyenne 0, écart-type 1) : une variable en euros et une autre en milliers d'euros créent une vallée allongée artificielle.

Les réseaux de neurones, eux, ne sont **pas convexes**. Pourtant la descente fonctionne remarquablement bien : en très grande dimension, la plupart des points critiques rencontrés sont des **points-selles** (on descend dans certaines directions) plutôt que de mauvais minima locaux, et le bruit du gradient stochastique aide à s'en échapper. Le chapitre 8 de Goodfellow et al. détaille ces phénomènes ; ils restent un sujet de recherche actif.

> ⚠️ **Piège fréquent** — « La perte ne baisse plus, donc on est dans un minimum local. » Très souvent, c'est faux : on est sur un plateau, le taux d'apprentissage est trop faible ou trop fort, ou les gradients s'évanouissent (L112). Vérifiez la norme des gradients et la courbe de perte avant de conclure.

## 3. Batch, SGD, mini-batch : estimer le gradient à moindre coût

La perte d'entraînement est une moyenne sur $N$ exemples : $L(\theta) = \frac1N\sum_{i=1}^{N}\ell_i(\theta)$. Calculer le gradient exact exige de parcourir **tout** le jeu de données à chaque pas. Trois stratégies :

| Méthode | Gradient utilisé à chaque pas | Pas par époque | Avantages | Inconvénients |
|---|---|---|---|---|
| **Batch complet** (*batch GD*) | moyenne sur les $N$ exemples | 1 | gradient exact, trajectoire lisse | très coûteux, impossible pour des milliards de tokens |
| **SGD** (stochastique pur) | un seul exemple tiré au hasard | $N$ | pas très bon marché, bruit qui aide à explorer | très bruité, n'exploite pas le parallélisme GPU |
| **Mini-batch** | moyenne sur $B$ exemples (32 à quelques milliers) | $N/B$ | bon compromis bruit / coût, parfait pour les GPU | un hyperparamètre de plus ($B$) |

Par linéarité de l'espérance (L113), le gradient d'un mini-batch tiré au hasard est un **estimateur sans biais** du vrai gradient, et sa variance décroît en $1/B$ : doubler la taille du batch ne divise le bruit (écart-type) que par $\sqrt 2$. Dans le langage courant, « SGD » désigne presque toujours la version mini-batch. Pour les LLM, la taille de batch se compte en **tokens** (souvent plusieurs millions par pas pour les grands pré-entraînements).

Expérience sur des données simulées : les ventes quotidiennes de croissants d'une boulangerie en fonction de la température, du week-end et des jours fériés.

```python
import numpy as np

# Données simulées : ventes quotidiennes de croissants d'une boulangerie
# variables standardisées : température, week-end, jour férié
rng = np.random.default_rng(1)
n = 2_000
X = np.column_stack([rng.normal(size=n), rng.integers(0, 2, n), rng.integers(0, 2, n) * 1.0])
X = (X - X.mean(0)) / X.std(0)
w_vrai, b_vrai = np.array([-8.0, 25.0, 12.0]), 120.0
y = X @ w_vrai + b_vrai + rng.normal(scale=5.0, size=n)

def perte(w, b):
    return np.mean((X @ w + b - y) ** 2)

def entrainer(taille_batch, eta, epoques=20):
    w, b = np.zeros(3), 0.0
    for _ in range(epoques):
        idx = rng.permutation(n)                      # on mélange à chaque époque
        for debut in range(0, n, taille_batch):
            j = idx[debut:debut + taille_batch]
            err = X[j] @ w + b - y[j]                 # (B,)
            gw = 2 * X[j].T @ err / len(j)            # gradient de la MSE (L112)
            gb = 2 * err.mean()
            w, b = w - eta * gw, b - eta * gb
    return w, b

for nom, B, eta in [("batch complet", n, 0.1), ("SGD (B=1)", 1, 0.001), ("mini-batch B=32", 32, 0.02)]:
    w, b = entrainer(B, eta)
    pas = 20 * int(np.ceil(n / B))
    print(f"{nom:16s} {pas:6d} pas  perte={perte(w, b):7.2f}  w={np.round(w, 1)}  b={b:.1f}")
print(f"perte minimale théorique ≈ variance du bruit = {5.0**2}")
```

Résultat typique : à nombre d'époques égal, le batch complet n'a fait que 20 pas et n'a pas fini de converger ; SGD et mini-batch atteignent le plancher de bruit (≈ 25), mais le mini-batch le fait en 30 fois moins de pas que SGD, chacun parfaitement vectorisé.

## 4. Momentum : donner de l'inertie à la bille

Dans une vallée allongée, la descente simple zigzague. Le **momentum** (Polyak, 1964) remplace le gradient par une moyenne glissante des gradients passés, comme une bille qui prend de l'élan :

$$v_{t} = \beta\,v_{t-1} + \nabla L(\theta_t), \qquad \theta_{t+1} = \theta_t - \eta\,v_t, \qquad \beta \approx 0{,}9$$

Les composantes qui changent de signe d'un pas à l'autre (le zigzag) s'annulent ; celles qui pointent toujours dans le même sens (le fond de la vallée) s'additionnent, jusqu'à environ $1/(1-\beta) = 10$ fois. La variante de **Nesterov** évalue le gradient au point « anticipé » $\theta_t - \eta\beta v_{t-1}$ ; elle est disponible dans PyTorch via `SGD(..., nesterov=True)`.

## 5. Adam et AdamW : un pas adapté à chaque paramètre

### 5.1 Adam

Adam (*Adaptive Moment Estimation*, Kingma et Ba, 2014) combine le momentum (moyenne des gradients, **moment d'ordre 1**) et une normalisation par la moyenne des gradients au carré (**moment d'ordre 2**), coordonnée par coordonnée :

$$m_t = \beta_1 m_{t-1} + (1-\beta_1)\,g_t, \qquad v_t = \beta_2 v_{t-1} + (1-\beta_2)\,g_t^2$$

$$\hat m_t = \frac{m_t}{1-\beta_1^t}, \qquad \hat v_t = \frac{v_t}{1-\beta_2^t}, \qquad \theta_{t+1} = \theta_t - \eta\,\frac{\hat m_t}{\sqrt{\hat v_t} + \varepsilon}$$

Valeurs proposées par l'article : $\beta_1 = 0{,}9$, $\beta_2 = 0{,}999$, $\varepsilon = 10^{-8}$. Trois idées à comprendre :

1. **Correction de biais** : $m$ et $v$ démarrent à 0, donc sous-estiment les moments les premiers pas ; la division par $1 - \beta^t$ corrige ce biais.
2. **Invariance d'échelle** : le rapport $\hat m/\sqrt{\hat v}$ est de l'ordre de $\pm 1$ quelle que soit l'échelle du gradient. Le pas effectif de chaque paramètre est donc d'environ $\eta$ : un paramètre aux gradients minuscules (un embedding de token rare) avance autant qu'un paramètre aux gradients énormes.
3. **Coût mémoire** : deux tenseurs d'état ($m$ et $v$) de la taille du modèle. Pour un modèle de 7 milliards de paramètres en float32, c'est 56 Go d'état d'optimiseur en plus des poids, ce qui explique l'intérêt des optimiseurs à état réduit ou quantifié (module 28).

### 5.2 AdamW : le weight decay découplé

La régularisation L2 ajoute $\tfrac{\lambda}{2}\|\theta\|^2$ à la perte, donc $\lambda\theta$ au gradient. Avec SGD, cela revient exactement à « rétrécir » les poids à chaque pas (*weight decay*). Avec Adam, non : le terme $\lambda\theta$ passe dans la normalisation par $\sqrt{\hat v}$, et les poids à fort gradient sont moins régularisés que les autres. Loshchilov et Hutter (2017, publié à ICLR 2019) ont proposé de **découpler** la décroissance du poids de la mise à jour adaptative :

$$\theta_{t+1} = \theta_t - \eta\left(\frac{\hat m_t}{\sqrt{\hat v_t} + \varepsilon} + \lambda\,\theta_t\right)$$

AdamW est devenu l'optimiseur par défaut des transformers. Dans PyTorch, `torch.optim.AdamW` a pour valeurs par défaut `lr=1e-3`, `betas=(0.9, 0.999)` et `weight_decay=1e-2` ; beaucoup de pré-entraînements de LLM publiés utilisent plutôt $\beta_2 = 0{,}95$ et un weight decay de l'ordre de 0,1, valeurs à vérifier au cas par cas dans les rapports techniques.

> ⚠️ **Piège fréquent** — Écrire `torch.optim.Adam(params, weight_decay=0.1)` n'est **pas** AdamW : c'est la régularisation L2 couplée. Utilisez `torch.optim.AdamW`. Et, par convention, on exclut souvent du weight decay les biais et les paramètres de normalisation (LayerNorm), via des groupes de paramètres.

### 5.3 Comparaison sur une vallée mal conditionnée

```python
import numpy as np

# f(θ) = ½ θᵀ A θ, valeurs propres 1 et 50 : conditionnement κ = 50
A = np.diag([1.0, 50.0])
grad = lambda th: A @ th

def descente(maj, n=200):
    th, etat = np.array([10.0, 1.0]), {}
    for t in range(1, n + 1):
        th = maj(th, grad(th), etat, t)
    return 0.5 * th @ A @ th

def gd(th, g, s, t, eta=0.035):                       # η < 2/λmax = 0,04
    return th - eta * g

def momentum(th, g, s, t, eta=0.035, beta=0.9):
    s["v"] = beta * s.get("v", 0) + g
    return th - eta * s["v"]

def adam(th, g, s, t, eta=0.3, b1=0.9, b2=0.999, eps=1e-8):
    s["m"] = b1 * s.get("m", 0) + (1 - b1) * g
    s["v"] = b2 * s.get("v", 0) + (1 - b2) * g**2
    m_hat = s["m"] / (1 - b1**t)                      # correction de biais
    v_hat = s["v"] / (1 - b2**t)
    return th - eta * m_hat / (np.sqrt(v_hat) + eps)

for nom, f in [("GD", gd), ("Momentum", momentum), ("Adam", adam)]:
    print(f"{nom:9s} perte après 200 pas : {descente(f):.2e}")
```

Momentum et Adam battent la descente simple de plusieurs ordres de grandeur. Faites l'essai : avec `eta=0.03`, Adam reste loin du minimum après 200 pas, car il avance d'environ $\eta$ par pas et doit parcourir une distance de 10. Le taux d'apprentissage d'Adam se raisonne donc **en unités de paramètre**, pas en unités de gradient.

## 6. Schedules et warm-up : faire varier le pas dans le temps

Un taux constant est rarement optimal : grand au début pour avancer, petit à la fin pour se poser au fond de la vallée sans être secoué par le bruit du mini-batch. Les **schedules** usuels :

| Schedule | Formule (pas $t$ sur $T$) | Usage typique |
|---|---|---|
| Constant | $\eta_t = \eta_0$ | prototypage, fine-tuning court |
| Par paliers (*step*) | $\eta_0 \cdot \gamma^{\lfloor t/s \rfloor}$ | vision classique (ResNet) |
| Décroissance linéaire | $\eta_0 (1 - t/T)$ | fine-tuning de transformers |
| Cosinus | $\eta_{\min} + \tfrac12(\eta_0 - \eta_{\min})(1 + \cos(\pi t/T))$ | pré-entraînement de LLM |
| Warm-up linéaire | $\eta_0 \cdot t / t_w$ pour $t < t_w$ | début de presque tout entraînement de transformer |

Le **warm-up** (montée progressive sur les premières centaines ou milliers de pas) se justifie ainsi : au départ, les estimations de $v_t$ d'Adam reposent sur très peu de gradients, et les poids aléatoires produisent des gradients grands et désordonnés ; un grand pas immédiat peut déstabiliser définitivement l'entraînement. Il s'accompagne presque toujours d'un **écrêtage du gradient** (*gradient clipping*) : si $\|g\| > c$ (souvent $c = 1$), on remplace $g$ par $c\,g/\|g\|$. Certains pré-entraînements récents utilisent aussi un schedule « warm-up, plateau, décroissance » (souvent noté WSD), qui permet de reprendre l'entraînement à partir du plateau.

```mermaid
xychart-beta
  title "Warm-up linéaire (1 000 pas) puis cosinus de 3e-4 à 3e-5"
  x-axis "pas (milliers)" [0, 1, 2, 4, 6, 8, 10]
  y-axis "taux d'apprentissage (×1e-4)" 0 --> 3.2
  line [0, 3.0, 2.92, 2.33, 1.42, 0.62, 0.3]
```

## 7. Tout assembler : une boucle d'entraînement PyTorch

```python
# pip install torch
import math
import torch
from torch import nn

torch.manual_seed(0)
# Données simulées : 2 000 exemples, 3 variables (cf. section 3)
X = torch.randn(2000, 3)
y = X @ torch.tensor([-8.0, 25.0, 12.0]) + 120 + 5 * torch.randn(2000)

modele = nn.Sequential(nn.Linear(3, 32), nn.ReLU(), nn.Linear(32, 1))

# Pas de weight decay sur les biais (paramètres 1D)
decay = [p for p in modele.parameters() if p.ndim >= 2]
no_decay = [p for p in modele.parameters() if p.ndim < 2]
opt = torch.optim.AdamW(
    [{"params": decay, "weight_decay": 0.1}, {"params": no_decay, "weight_decay": 0.0}],
    lr=3e-2, betas=(0.9, 0.95),
)

pas_total, warmup = 2000, 100
def facteur(t):                         # multiplicateur appliqué au lr de base
    if t < warmup:
        return (t + 1) / warmup         # montée linéaire
    progres = (t - warmup) / (pas_total - warmup)
    return 0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * progres))   # cosinus jusqu'à 10 %
sched = torch.optim.lr_scheduler.LambdaLR(opt, facteur)

perte_fn = nn.MSELoss()
for t in range(pas_total):
    idx = torch.randint(0, len(X), (64,))           # mini-batch de 64
    perte = perte_fn(modele(X[idx]).squeeze(-1), y[idx])
    opt.zero_grad()                                 # les gradients s'accumulent (L112)
    perte.backward()
    torch.nn.utils.clip_grad_norm_(modele.parameters(), max_norm=1.0)
    opt.step()
    sched.step()
    if t % 400 == 0 or t == pas_total - 1:
        print(f"pas {t:4d}  lr={sched.get_last_lr()[0]:.2e}  perte={perte.item():8.2f}")
```

L'ordre des cinq lignes du cœur de boucle (`zero_grad`, `backward`, écrêtage, `step` de l'optimiseur, `step` du scheduler) est à connaître par cœur ; il se retrouve à l'identique dans les modules 26 à 28.

> 🔗 **Documentation officielle** — [PyTorch : torch.optim](https://pytorch.org/docs/stable/optim.html) décrit chaque optimiseur (SGD, Adam, AdamW…), les groupes de paramètres et tous les schedulers (`LambdaLR`, `CosineAnnealingLR`, `OneCycleLR`, `SequentialLR`).

> 💡 **À retenir** — Recette de départ pour un transformer : AdamW, warm-up sur 1 à 5 % des pas, décroissance cosinus ou linéaire, écrêtage à 1,0, weight decay hors biais et normalisations. Puis réglez **d'abord** le taux d'apprentissage, sur une échelle logarithmique (1e-4, 3e-4, 1e-3…).

## 🧪 Exercice pratique

**Consigne.**
1. À la main : pour $L(\theta) = 2\theta_1^2 + 8\theta_2^2$, donnez la hessienne, le taux d'apprentissage maximal assurant la convergence de la descente simple et le conditionnement.
2. Calculez à la main les deux premiers pas d'Adam ($\eta = 0{,}1$, $\beta_1 = 0{,}9$, $\beta_2 = 0{,}999$, $\varepsilon$ négligeable) sur $L(x) = x^2$ en partant de $x_0 = 1$.
3. Écrivez une fonction NumPy `lr_warmup_cosinus(t, total, warmup, lr_max, lr_min)` et vérifiez : valeur nulle ou quasi nulle à $t=0$, maximum à $t = $ `warmup`, `lr_min` à la fin, décroissance monotone après le warm-up.
4. Dans la boucle PyTorch, retirez le warm-up et multipliez `lr` par 10 : décrivez ce que vous observez.

**Critères de réussite.** Valeurs exactes en (1) et (2) ; assertions qui passent en (3) ; observation argumentée en (4).

<details>
<summary>Corrigé</summary>

1. $H = \begin{pmatrix} 4 & 0 \\ 0 & 16 \end{pmatrix}$, $\eta_{\max} = 2/16 = 0{,}125$ (strictement inférieur), $\kappa = 16/4 = 4$.

2. Pas 1 : $g_1 = 2$, $m_1 = 0{,}2$, $v_1 = 0{,}004$, $\hat m_1 = 2$, $\hat v_1 = 4$, d'où $x_1 = 1 - 0{,}1 \times 2/2 = 0{,}9$. Au premier pas, Adam avance toujours de $\eta$ exactement (dans le sens opposé au gradient). Pas 2 : $g_2 = 1{,}8$, $m_2 = 0{,}9 \times 0{,}2 + 0{,}1 \times 1{,}8 = 0{,}36$, $\hat m_2 = 0{,}36/0{,}19 \approx 1{,}895$ ; $v_2 = 0{,}999 \times 0{,}004 + 0{,}001 \times 3{,}24 = 0{,}007236$, $\hat v_2 = 0{,}007236/0{,}001999 \approx 3{,}620$, $\sqrt{\hat v_2} \approx 1{,}903$ ; $x_2 \approx 0{,}9 - 0{,}1 \times 0{,}996 \approx 0{,}800$.

3. Fonction et tests :

```python
import math
import numpy as np

def lr_warmup_cosinus(t, total, warmup, lr_max, lr_min=0.0):
    if t < warmup:
        return lr_max * t / warmup
    progres = min(1.0, (t - warmup) / max(1, total - warmup))
    return lr_min + 0.5 * (lr_max - lr_min) * (1 + math.cos(math.pi * progres))

total, warmup = 10_000, 1_000
lrs = np.array([lr_warmup_cosinus(t, total, warmup, 3e-4, 3e-5) for t in range(total + 1)])
assert lrs[0] == 0.0 and np.isclose(lrs[warmup], 3e-4) and np.isclose(lrs[-1], 3e-5)
assert np.all(np.diff(lrs[warmup:]) <= 1e-15)        # décroissance monotone
print("schedule OK :", [f"{lrs[t]:.2e}" for t in (0, 500, 1000, 5500, 10000)])
```

4. Sans warm-up et avec un taux dix fois plus grand, la perte fait de grands sauts dans les premiers pas, peut exploser puis redescendre, voire stagner à un niveau élevé (neurones ReLU « morts » après un pas trop violent). L'écrêtage limite les dégâts sans les supprimer. C'est la démonstration empirique de l'utilité du warm-up.
</details>

## 🎮 Défi

Une start-up lyonnaise vous montre une courbe de perte qui baisse bien pendant 3 000 pas, puis remonte brutalement et affiche `nan`. Donnez trois causes plausibles et le premier réglage à tester. (Pistes : taux d'apprentissage trop élevé pour la phase avancée, absence de décroissance ; absence d'écrêtage de gradient face à un batch aberrant ; débordement numérique en float16 ou softmax non stabilisé (L113). Premier test : diviser le taux par 3 et activer `clip_grad_norm_`.)

## ✅ Auto-évaluation express

1. Sur une quadratique dont la hessienne a pour plus grande valeur propre 200, quel est le taux maximal de la descente simple ?
2. Pourquoi Adam a-t-il besoin d'une correction de biais ?
3. Quelle différence entre `Adam(weight_decay=0.1)` et `AdamW(weight_decay=0.1)` ?

**Réponses.** 1. $\eta < 2/200 = 0{,}01$. 2. Parce que $m$ et $v$ sont initialisés à 0 et sous-estiment les moments pendant les premiers pas. 3. Le premier ajoute $\lambda\theta$ au gradient, qui est ensuite normalisé par $\sqrt{\hat v}$ (régularisation L2 couplée) ; le second applique la décroissance directement aux poids, indépendamment de la normalisation adaptative.

## 📚 Pour aller plus loin
- [Kingma & Ba — Adam: A Method for Stochastic Optimization](https://arxiv.org/abs/1412.6980) 🇬🇧 — l'article original, algorithme 1 et preuve de la correction de biais.
- [Loshchilov & Hutter — Decoupled Weight Decay Regularization](https://arxiv.org/abs/1711.05101) 🇬🇧 — l'article qui introduit AdamW.
- [PyTorch — torch.optim](https://pytorch.org/docs/stable/optim.html) 🇬🇧 — optimiseurs, groupes de paramètres, schedulers.
- [Stanford CS231n — programme](https://cs231n.stanford.edu/schedule.html) 🇬🇧 — leçon 3 « Regularization and optimization » (SGD, momentum, AdaGrad, Adam, schedules).
- [3Blue1Brown — Neural Networks, chapitre 2 « Gradient descent »](https://www.3blue1brown.com/topics/neural-networks) 🇬🇧 — l'intuition visuelle de la descente dans un paysage de perte.
- [Deep Learning (Goodfellow, Bengio, Courville)](https://www.deeplearningbook.org/) 🇬🇧 — chapitre 8 « Optimization for Training Deep Models ».
