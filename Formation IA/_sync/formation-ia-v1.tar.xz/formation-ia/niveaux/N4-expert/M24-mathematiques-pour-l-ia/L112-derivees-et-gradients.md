---
id: L112
module: M24
level: N4
title: "Dérivées et gradients"
minutes: 70
objectives:
  - "Calculer une dérivée, une dérivée partielle et un gradient, et interpréter le gradient comme la direction de plus forte pente"
  - "Appliquer la règle de la chaîne sur un graphe de calcul, en scalaire puis en forme matricielle (jacobienne)"
  - "Dérouler à la main la rétropropagation sur un neurone puis la vérifier en NumPy par différences finies"
  - "Expliquer ce que fait l'autograd de PyTorch et pourquoi le mode inverse est efficace pour entraîner un réseau"
skills: ["C4.1"]
sources:
  - { title: "3Blue1Brown — Neural Networks (chap. 3 et 4 : backpropagation)", url: "https://www.3blue1brown.com/topics/neural-networks", lang: "en" }
  - { title: "Andrej Karpathy — Neural Networks: Zero to Hero (vidéo 1 : micrograd)", url: "https://karpathy.ai/zero-to-hero.html", lang: "en" }
  - { title: "Karpathy — micrograd (dépôt GitHub)", url: "https://github.com/karpathy/micrograd", lang: "en" }
  - { title: "PyTorch — A Gentle Introduction to torch.autograd", url: "https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html", lang: "en" }
  - { title: "MIT 6.390 IntroML — Fall 2026", url: "https://introml.mit.edu/fall26/info", lang: "en" }
  - { title: "Deep Learning (Goodfellow, Bengio, Courville) — chap. 4 et 6.5", url: "https://www.deeplearningbook.org/", lang: "en" }
---

# Dérivées et gradients

> ⏱ 70 min · 🎯 Niveau 4 · 📚 Module 24

## 🎯 Ce que vous saurez faire
- Calculer à la main la dérivée des fonctions qui peuplent les réseaux de neurones (sigmoïde, tanh, ReLU, exponentielle, logarithme).
- Écrire le gradient d'une fonction de plusieurs variables et dire dans quelle direction il « pousse ».
- Appliquer la règle de la chaîne nœud par nœud sur un graphe de calcul, puis sous forme de produits de jacobiennes.
- Dérouler une rétropropagation complète sur papier, la coder en NumPy, la vérifier numériquement et la retrouver avec `torch.autograd`.

## 1. La dérivée : une pente locale, rien de plus

Vous dirigez une boulangerie et vous augmentez le prix de la baguette de 1 centime : de combien bouge votre chiffre d'affaires ? Cette question, « si je touche un peu à l'entrée, de combien bouge la sortie ? », est exactement ce que mesure une **dérivée**. Formellement :

$$f'(x) = \lim_{h \to 0} \frac{f(x+h) - f(x)}{h}$$

C'est la pente de la tangente à la courbe au point $x$. Si $f'(x) > 0$, augmenter $x$ fait monter $f$ ; si $f'(x) < 0$, cela la fait baisser ; si $f'(x) = 0$, on est sur un plat (minimum, maximum ou palier).

L'entraînement d'un réseau de neurones repose sur cette idée unique : la sortie à surveiller est la **perte** (*loss*), qui mesure l'erreur du modèle, et les entrées sur lesquelles on agit sont les **paramètres** (poids). La dérivée de la perte par rapport à chaque poids dit dans quel sens tourner chaque « bouton » pour faire baisser l'erreur. Un LLM de 70 milliards de paramètres, c'est 70 milliards de boutons, et à chaque pas d'entraînement on calcule 70 milliards de dérivées.

### 1.1 Les dérivées à connaître par cœur

| Fonction | Dérivée | Où on la rencontre |
|---|---|---|
| $x^n$ | $n\,x^{n-1}$ | perte quadratique $(\hat y - y)^2$ |
| $e^x$ | $e^x$ | softmax |
| $\ln x$ | $1/x$ | log-vraisemblance, entropie croisée |
| $\sigma(x) = \dfrac{1}{1+e^{-x}}$ | $\sigma(x)\,(1-\sigma(x))$ | régression logistique, portes LSTM |
| $\tanh x$ | $1 - \tanh^2 x$ | anciens MLP, RNN |
| $\text{ReLU}(x) = \max(0,x)$ | $1$ si $x>0$, $0$ si $x<0$ | quasiment tous les réseaux modernes |

Deux règles complètent le tableau : la dérivée d'une somme est la somme des dérivées, et $(uv)' = u'v + uv'$.

> 💡 **À retenir** — La dérivée de la sigmoïde vaut au maximum $0{,}25$ (en $x = 0$). Empilez dix couches sigmoïdes et le signal de gradient est multiplié par au plus $0{,}25^{10} \approx 10^{-6}$ : c'est le **gradient qui s'évanouit** (*vanishing gradient*), principale raison pour laquelle ReLU et ses variantes (GELU, SiLU) ont remplacé la sigmoïde dans les couches cachées.

### 1.2 La dérivée numérique, votre filet de sécurité

On peut toujours approcher une dérivée sans aucune formule, par **différences finies centrées** :

$$f'(x) \approx \frac{f(x+h) - f(x-h)}{2h}, \quad h \approx 10^{-5}$$

C'est lent (deux évaluations de $f$ par paramètre, impensable pour des milliards de poids) mais imparable pour **vérifier** un gradient calculé à la main. On appelle cela le *gradient checking*, et nous l'utiliserons plus bas.

## 2. Plusieurs variables : dérivées partielles et gradient

Une perte dépend de nombreux paramètres à la fois. La **dérivée partielle** $\partial f / \partial x_i$ mesure la sensibilité de $f$ à $x_i$ *en gelant toutes les autres variables*. Exemple :

$$f(x, y) = x^2 y + 3y \quad\Rightarrow\quad \frac{\partial f}{\partial x} = 2xy, \qquad \frac{\partial f}{\partial y} = x^2 + 3$$

Le **gradient** regroupe toutes les dérivées partielles dans un vecteur :

$$\nabla f(x) = \left( \frac{\partial f}{\partial x_1}, \dots, \frac{\partial f}{\partial x_n} \right)^\top$$

Au point $(1, 2)$ : $\nabla f = (4,\ 4)^\top$. Trois propriétés géométriques en font l'outil central de l'IA :

1. $\nabla f$ pointe dans la **direction de plus forte montée** ; $-\nabla f$ pointe donc vers la plus forte descente.
2. Sa norme $\|\nabla f\|$ mesure la raideur de la pente.
3. Il est **orthogonal aux lignes de niveau** (les courbes où $f$ est constante), comme la ligne de plus grande pente d'une carte IGN coupe les courbes de niveau à angle droit.

```
   lignes de niveau de f (vue de dessus)
        ___________
      /   _______   \        ↗ ∇f : monte le plus vite
     |   /  ___  \   |      ↙ -∇f : descend le plus vite
     |  |  ( · )  |  |      · minimum : ∇f = 0
      \  \_______/  /
        \_________/
```

La **dérivée directionnelle** dans la direction d'un vecteur unitaire $u$ vaut $\nabla f \cdot u = \|\nabla f\|\cos\theta$ (produit scalaire vu en L111) : elle est maximale quand $u$ est aligné avec le gradient. Voilà pourquoi la descente de gradient (L114) avance selon $-\nabla f$.

> ⚠️ **Piège fréquent** — Le gradient a **la même forme que la variable** par rapport à laquelle on dérive. Si $W \in \mathbb{R}^{64 \times 128}$, alors $\partial L / \partial W \in \mathbb{R}^{64 \times 128}$. En PyTorch, `W.grad.shape == W.shape` toujours. Si vos dimensions ne collent pas, vous avez oublié une transposée.

## 3. La règle de la chaîne : le cœur de la rétropropagation

Un réseau de neurones est une **composition** de fonctions simples : couche linéaire, puis activation, puis couche linéaire, puis perte. Pour dériver une composition, on utilise la règle de la chaîne (*chain rule*) :

$$y = f(g(x)) \quad\Rightarrow\quad \frac{dy}{dx} = \frac{dy}{dg}\cdot\frac{dg}{dx}$$

Analogie de la chaîne de production : si le prix du blé monte de 1 €, la farine monte de 0,80 €, et chaque euro de farine ajoute 0,30 € au prix du pain, alors le pain monte de $1 \times 0{,}80 \times 0{,}30 = 0{,}24$ €. Les sensibilités **se multiplient** le long de la chaîne.

Quand une variable influence la sortie par **plusieurs chemins**, on **additionne** les contributions de chaque chemin :

$$\frac{\partial L}{\partial x} = \sum_{k} \frac{\partial L}{\partial u_k}\,\frac{\partial u_k}{\partial x}$$

C'est la règle « multiplier le long d'un chemin, additionner entre les chemins ». Dans le code, elle se traduit par l'accumulation `grad += ...`, et c'est exactement pour cette raison que PyTorch **accumule** les gradients et qu'il faut appeler `optimizer.zero_grad()` à chaque pas.

### 3.1 Le graphe de calcul

On représente le calcul sous forme de graphe : chaque nœud est une opération élémentaire dont on connaît la dérivée locale. La **passe avant** (*forward*) calcule les valeurs de gauche à droite ; la **passe arrière** (*backward*) propage les gradients de droite à gauche en multipliant par les dérivées locales.

```mermaid
flowchart LR
  x((x)) --> M["z = w·x + b"]
  w((w)) --> M
  b((b)) --> M
  M --> S["a = σ(z)"]
  S --> P["L = ½(a − y)²"]
  P -. "∂L/∂a" .-> S
  S -. "∂L/∂z" .-> M
  M -. "∂L/∂w, ∂L/∂b" .-> w
```

## 4. Exemple numérique à la main : un neurone

Prenons un neurone sigmoïde qui prédit si une facture sera payée en retard ($y = 1$) à partir d'un seul indicateur $x$ (le nombre de retards passés du client, normalisé). Valeurs : $x = 1{,}5$, $w = 0{,}8$, $b = -0{,}2$, cible $y = 1$, perte $L = \tfrac12 (a - y)^2$.

**Passe avant.**

| Étape | Calcul | Valeur |
|---|---|---|
| $z = wx + b$ | $0{,}8 \times 1{,}5 - 0{,}2$ | $1{,}0$ |
| $a = \sigma(z)$ | $1/(1+e^{-1})$ | $0{,}7311$ |
| $L = \tfrac12(a-y)^2$ | $\tfrac12(0{,}7311 - 1)^2$ | $0{,}03616$ |

**Passe arrière** (on remonte en multipliant les dérivées locales).

| Gradient | Règle locale | Valeur |
|---|---|---|
| $\partial L / \partial a$ | $a - y$ | $-0{,}2689$ |
| $\partial a / \partial z$ | $a(1-a)$ | $0{,}1966$ |
| $\partial L / \partial z$ | produit des deux | $-0{,}05288$ |
| $\partial L / \partial w$ | $\dfrac{\partial L}{\partial z}\cdot x$ | $-0{,}07932$ |
| $\partial L / \partial b$ | $\dfrac{\partial L}{\partial z}\cdot 1$ | $-0{,}05288$ |

Les deux gradients sont négatifs : augmenter $w$ et $b$ ferait baisser la perte, ce qui est logique puisque la prédiction (0,73) est trop basse par rapport à la cible (1). Un pas de descente avec un taux $\eta = 1$ donnerait $w \leftarrow 0{,}8 + 0{,}079$ et $b \leftarrow -0{,}2 + 0{,}053$.

Vérifions en NumPy, gradient analytique contre gradient numérique :

```python
import numpy as np

def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))

def perte(w, b, x=1.5, y=1.0):
    a = sigmoid(w * x + b)
    return 0.5 * (a - y) ** 2

# Passe avant + arrière « à la main »
x, w, b, y = 1.5, 0.8, -0.2, 1.0
z = w * x + b
a = sigmoid(z)
dL_da = a - y
da_dz = a * (1 - a)
dL_dz = dL_da * da_dz
dL_dw, dL_db = dL_dz * x, dL_dz

# Vérification par différences finies centrées
h = 1e-5
num_dw = (perte(w + h, b) - perte(w - h, b)) / (2 * h)
num_db = (perte(w, b + h) - perte(w, b - h)) / (2 * h)

print(f"z={z:.4f}  a={a:.4f}  L={perte(w, b):.5f}")
print(f"dL/dw analytique={dL_dw:.6f}  numérique={num_dw:.6f}")
print(f"dL/db analytique={dL_db:.6f}  numérique={num_db:.6f}")
assert abs(dL_dw - num_dw) < 1e-8 and abs(dL_db - num_db) < 1e-8
```

## 5. Passer à l'échelle : la jacobienne

Quand une fonction prend un vecteur et rend un vecteur, $f : \mathbb{R}^n \to \mathbb{R}^m$, ses dérivées partielles forment une matrice $m \times n$, la **jacobienne** :

$$J_f = \begin{pmatrix} \dfrac{\partial f_1}{\partial x_1} & \cdots & \dfrac{\partial f_1}{\partial x_n} \\ \vdots & \ddots & \vdots \\ \dfrac{\partial f_m}{\partial x_1} & \cdots & \dfrac{\partial f_m}{\partial x_n} \end{pmatrix}$$

Deux jacobiennes à connaître :

- **couche linéaire** $z = Wx + b$ : $\partial z / \partial x = W$. La jacobienne d'une transformation linéaire est la matrice elle-même (L111) ;
- **activation élément par élément** $a = \text{ReLU}(z)$ : la jacobienne est **diagonale**, avec $1$ là où $z_i > 0$ et $0$ ailleurs.

La règle de la chaîne devient un **produit de jacobiennes** : $J_{f \circ g} = J_f \cdot J_g$. Pour une perte scalaire $L$ au bout d'une chaîne $x \to z \to a \to L$ :

$$\underbrace{\frac{\partial L}{\partial x}}_{1 \times n} = \underbrace{\frac{\partial L}{\partial a}}_{1 \times m}\;\underbrace{\frac{\partial a}{\partial z}}_{m \times m}\;\underbrace{\frac{\partial z}{\partial x}}_{m \times n}$$

### 5.1 Pourquoi on calcule « de droite à gauche »

On peut évaluer ce produit dans deux ordres. De gauche à droite, on commence par un **vecteur ligne** $\partial L/\partial a$ et chaque multiplication donne encore un vecteur : c'est le **mode inverse** (*reverse mode*), qui ne manipule jamais de matrice jacobienne complète, seulement des *produits vecteur-jacobienne* (VJP). Pour une sortie scalaire et des milliards de paramètres, un seul passage arrière suffit pour obtenir tous les gradients, pour un coût du même ordre que la passe avant (Goodfellow et al., chap. 6.5, donnent une analyse détaillée). La rétropropagation, c'est cela : la règle de la chaîne évaluée en mode inverse.

### 5.2 Le gradient d'une couche linéaire, la formule qui sert partout

Avec $z = Wx + b$, $W \in \mathbb{R}^{m \times n}$, et $\delta = \partial L / \partial z \in \mathbb{R}^m$ (le gradient qui « arrive » de la couche suivante) :

$$\frac{\partial L}{\partial W} = \delta\, x^\top \;(m \times n), \qquad \frac{\partial L}{\partial b} = \delta, \qquad \frac{\partial L}{\partial x} = W^\top \delta$$

Pour un mini-batch $X \in \mathbb{R}^{B \times n}$ stocké en lignes (convention PyTorch, $Z = XW^\top + b$), cela devient $\partial L/\partial W = \Delta^\top X$ et $\partial L/\partial X = \Delta W$, et $\partial L/\partial b$ est la somme des lignes de $\Delta$. Retenez le motif : **le gradient des poids est un produit extérieur entre le signal d'erreur et l'entrée**, et **l'erreur redescend à travers $W^\top$**.

> 🔗 **Documentation officielle** — [PyTorch : A Gentle Introduction to torch.autograd](https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html) explique le graphe dynamique, `requires_grad` et les produits vecteur-jacobienne.

## 6. Rétropropagation complète : un MLP à deux couches en NumPy

Réseau : $x \in \mathbb{R}^3 \to$ couche cachée de 4 neurones ReLU $\to$ sortie scalaire, perte quadratique moyenne sur un batch de 5 exemples. On code la passe arrière avec les formules de la section 5.2, puis on la vérifie par différences finies sur **tous** les paramètres.

```python
import numpy as np

rng = np.random.default_rng(42)
B, n, h = 5, 3, 4
X = rng.normal(size=(B, n))           # 5 exemples, 3 variables
y = rng.normal(size=(B, 1))           # cibles
params = {
    "W1": rng.normal(size=(n, h)) * 0.5, "b1": np.zeros(h),
    "W2": rng.normal(size=(h, 1)) * 0.5, "b2": np.zeros(1),
}

def forward(p, X, y):
    z1 = X @ p["W1"] + p["b1"]        # (B, h)
    a1 = np.maximum(0, z1)            # ReLU
    yhat = a1 @ p["W2"] + p["b2"]     # (B, 1)
    L = np.mean((yhat - y) ** 2)
    return L, (z1, a1, yhat)

def backward(p, X, y, cache):
    z1, a1, yhat = cache
    d_yhat = 2 * (yhat - y) / len(X)  # dL/dyhat, (B, 1)
    g = {"W2": a1.T @ d_yhat, "b2": d_yhat.sum(0)}
    d_a1 = d_yhat @ p["W2"].T         # l'erreur redescend à travers W2ᵀ
    d_z1 = d_a1 * (z1 > 0)            # jacobienne diagonale de ReLU
    g["W1"] = X.T @ d_z1
    g["b1"] = d_z1.sum(0)
    return g

L, cache = forward(params, X, y)
grads = backward(params, X, y, cache)

# Gradient checking sur chaque coefficient de chaque paramètre
eps, pire = 1e-6, 0.0
for nom, P in params.items():
    for idx in np.ndindex(P.shape):
        old = P[idx]
        P[idx] = old + eps; Lp, _ = forward(params, X, y)
        P[idx] = old - eps; Lm, _ = forward(params, X, y)
        P[idx] = old
        num = (Lp - Lm) / (2 * eps)
        rel = abs(num - grads[nom][idx]) / max(1e-12, abs(num) + abs(grads[nom][idx]))
        pire = max(pire, rel)
print(f"perte={L:.5f}  erreur relative max={pire:.2e}")
assert pire < 1e-6, "gradient faux"
```

Une erreur relative de l'ordre de $10^{-9}$ à $10^{-7}$ signifie que votre rétropropagation est juste ; au-delà de $10^{-4}$, cherchez le bug (transposée oubliée, somme sur le batch manquante, facteur 2).

> ⚠️ **Piège fréquent** — Au point exact $z = 0$, ReLU n'est pas dérivable : le gradient checking peut alors signaler une fausse erreur. Les frameworks choisissent par convention la valeur 0 en ce point ; en pratique, la probabilité de tomber pile sur 0 avec des flottants est négligeable.

## 7. Le même calcul avec PyTorch autograd

PyTorch enregistre chaque opération dans un graphe pendant la passe avant, puis `backward()` parcourt ce graphe en mode inverse. On retrouve les valeurs de la section 4 :

```python
# pip install torch
import torch

x = torch.tensor(1.5)
y = torch.tensor(1.0)
w = torch.tensor(0.8, requires_grad=True)
b = torch.tensor(-0.2, requires_grad=True)

a = torch.sigmoid(w * x + b)
L = 0.5 * (a - y) ** 2
L.backward()                       # rétropropagation automatique

print(f"L={L.item():.5f}  dL/dw={w.grad.item():.5f}  dL/db={b.grad.item():.5f}")
# Attendu : L=0.03616  dL/dw=-0.07932  dL/db=-0.05288

# Vérification automatique de gradients sur une fonction vectorielle (double précision)
f = lambda W, X: torch.relu(X @ W).pow(2).sum()
W = torch.randn(3, 4, dtype=torch.double, requires_grad=True)
X = torch.randn(5, 3, dtype=torch.double)
print("gradcheck :", torch.autograd.gradcheck(f, (W, X)))
```

## 8. Construire son propre autograd en 40 lignes

Dans la première vidéo de *Neural Networks: Zero to Hero*, Andrej Karpathy construit **micrograd**, un moteur d'autograd scalaire minimal. Voici notre propre version, écrite pour cette leçon, qui suit la même idée : chaque valeur mémorise ses parents et la façon de leur renvoyer le gradient.

```python
import math

class Valeur:
    """Scalaire qui mémorise son graphe de calcul pour la rétropropagation."""
    def __init__(self, data, parents=(), op=""):
        self.data, self.grad = data, 0.0
        self._parents, self._op = parents, op
        self._retour = lambda: None          # propage self.grad vers les parents

    def __add__(self, autre):
        autre = autre if isinstance(autre, Valeur) else Valeur(autre)
        out = Valeur(self.data + autre.data, (self, autre), "+")
        def _retour():
            self.grad += out.grad            # dérivée locale = 1
            autre.grad += out.grad
        out._retour = _retour
        return out

    def __mul__(self, autre):
        autre = autre if isinstance(autre, Valeur) else Valeur(autre)
        out = Valeur(self.data * autre.data, (self, autre), "*")
        def _retour():
            self.grad += autre.data * out.grad
            autre.grad += self.data * out.grad
        out._retour = _retour
        return out

    def sigmoid(self):
        s = 1 / (1 + math.exp(-self.data))
        out = Valeur(s, (self,), "σ")
        def _retour():
            self.grad += s * (1 - s) * out.grad
        out._retour = _retour
        return out

    def carre(self):
        out = Valeur(self.data ** 2, (self,), "²")
        def _retour():
            self.grad += 2 * self.data * out.grad
        out._retour = _retour
        return out

    def backward(self):
        ordre, vus = [], set()
        def topo(v):                         # tri topologique du graphe
            if v not in vus:
                vus.add(v)
                for p in v._parents:
                    topo(p)
                ordre.append(v)
        topo(self)
        self.grad = 1.0                      # dL/dL = 1
        for v in reversed(ordre):
            v._retour()

w, b = Valeur(0.8), Valeur(-0.2)
L = ((w * 1.5 + b).sigmoid() + (-1.0)).carre() * 0.5
L.backward()
print(f"L={L.data:.5f}  dL/dw={w.grad:.5f}  dL/db={b.grad:.5f}")
```

Le `+=` dans chaque `_retour` est la règle « additionner entre les chemins » : si une valeur est utilisée deux fois, elle reçoit deux contributions.

> 💡 **À retenir** — Un framework de deep learning, c'est : (1) des opérations dont on connaît la dérivée locale, (2) un graphe enregistré pendant la passe avant, (3) un parcours en ordre topologique inverse qui multiplie et accumule. Tout le reste (GPU, tenseurs, fusion de noyaux) est de l'optimisation.

## 🧪 Exercice pratique

**Consigne.**
1. À la main, calculez le gradient de $f(x, y) = \ln(1 + e^{xy}) + y^2$ au point $(x, y) = (0, 1)$.
2. Ajoutez à la classe `Valeur` une méthode `relu()` et une méthode `__pow__` (exposant entier), puis vérifiez sur $g(a, b) = (\text{ReLU}(a\,b))^3$ en $a = 2$, $b = -0{,}5$ puis $a = 2$, $b = 0{,}5$.
3. Dans le MLP NumPy de la section 6, remplacez ReLU par $\tanh$ et adaptez `backward` ; le gradient checking doit toujours passer.

**Critères de réussite.** Gradient exact en (1) ; deux résultats en (2), dont un gradient nul justifié ; erreur relative $< 10^{-6}$ en (3).

<details>
<summary>Corrigé</summary>

1. $\partial f/\partial x = \dfrac{y\,e^{xy}}{1+e^{xy}} = y\,\sigma(xy)$ et $\partial f/\partial y = x\,\sigma(xy) + 2y$. En $(0, 1)$ : $\sigma(0) = 0{,}5$, donc $\nabla f = (0{,}5;\ 2)$.

2. Méthodes à ajouter :

```python
def relu(self):
    out = Valeur(max(0.0, self.data), (self,), "ReLU")
    def _retour():
        self.grad += (1.0 if self.data > 0 else 0.0) * out.grad
    out._retour = _retour
    return out

def __pow__(self, k):
    out = Valeur(self.data ** k, (self,), f"**{k}")
    def _retour():
        self.grad += k * self.data ** (k - 1) * out.grad
    out._retour = _retour
    return out
```

En $b = -0{,}5$ : $ab = -1 < 0$, ReLU renvoie 0 et les gradients sont **nuls** (le neurone est « mort » pour cet exemple). En $b = 0{,}5$ : $g = (ab)^3$, $\partial g/\partial a = 3(ab)^2 b = 1{,}5$ et $\partial g/\partial b = 3(ab)^2 a = 6$.

3. Remplacer `a1 = np.maximum(0, z1)` par `a1 = np.tanh(z1)` et `d_z1 = d_a1 * (z1 > 0)` par `d_z1 = d_a1 * (1 - a1 ** 2)`.
</details>

## 🎮 Défi

Sans rien calculer : dans `Valeur`, que se passe-t-il si l'on écrit `L = w * w` puis `L.backward()` ? Le gradient obtenu vaut-il bien $2w$ ? (Réponse : oui, grâce au `+=` : `w` reçoit deux fois la contribution `w.data * out.grad`. Avec un simple `=`, on obtiendrait $w$ au lieu de $2w$, l'un des bugs classiques montrés dans la vidéo micrograd.)

## ✅ Auto-évaluation express

1. Quelle est la forme de $\partial L/\partial W$ si $W \in \mathbb{R}^{256 \times 512}$ et $L$ est scalaire ?
2. Pourquoi la rétropropagation utilise-t-elle le mode inverse plutôt que le mode direct ?
3. Que vaut $\sigma'(0)$, et pourquoi cette valeur pose-t-elle problème dans les réseaux profonds ?

**Réponses.** 1. $256 \times 512$, la même forme que $W$. 2. Parce que la sortie est un scalaire (la perte) et les entrées sont très nombreuses : un seul passage arrière donne tous les gradients par produits vecteur-jacobienne. 3. $0{,}25$, son maximum : multiplié couche après couche, le gradient s'évanouit.

## 📚 Pour aller plus loin
- [3Blue1Brown — Neural Networks, chapitres 3 et 4 (backpropagation)](https://www.3blue1brown.com/topics/neural-networks) 🇬🇧 — l'intuition visuelle puis le calcul de la rétropropagation.
- [Andrej Karpathy — Neural Networks: Zero to Hero](https://karpathy.ai/zero-to-hero.html) 🇬🇧 — vidéo 1 (micrograd, 2 h 25) et vidéo 5 (« Becoming a Backprop Ninja »), indispensables à ce niveau.
- [micrograd sur GitHub](https://github.com/karpathy/micrograd) 🇬🇧 — le moteur d'autograd minimal de Karpathy, à comparer avec votre classe `Valeur`.
- [PyTorch — A Gentle Introduction to torch.autograd](https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html) 🇬🇧 — le tutoriel officiel sur l'autograd.
- [Deep Learning (Goodfellow, Bengio, Courville)](https://www.deeplearningbook.org/) 🇬🇧 — chapitre 4 (calcul numérique) et section 6.5 (back-propagation).
- [MIT 6.390 IntroML Fall 2026](https://introml.mit.edu/fall26/info) 🇬🇧 — les gradients matriciels figurent explicitement dans les prérequis.
