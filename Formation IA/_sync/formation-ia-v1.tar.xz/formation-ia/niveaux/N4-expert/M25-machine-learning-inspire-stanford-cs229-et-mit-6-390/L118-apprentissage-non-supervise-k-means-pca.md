---
id: L118
module: M25
level: N4
title: "Apprentissage non supervisé : k-means, PCA"
minutes: 60
objectives:
  - "Implémenter l'algorithme de k-means (Lloyd) et choisir k avec la méthode du coude et le coefficient de silhouette"
  - "Comparer k-means, DBSCAN et le clustering hiérarchique selon la forme des groupes et la présence de bruit"
  - "Calculer une analyse en composantes principales par SVD (lien M24) et interpréter la variance expliquée"
  - "Utiliser t-SNE et UMAP pour visualiser des données en grande dimension sans sur-interpréter les graphiques"
skills: ["C4.2", "C4.1"]
sources:
  - { title: "Stanford CS229 — notes : k-means, EM, PCA, ICA", url: "https://cs229.stanford.edu/", lang: "en" }
  - { title: "MIT 6.036 — Lecture 13 : Clustering (vidéos Fall 2020)", url: "https://tamarabroderick.com/ml.html", lang: "en" }
  - { title: "scikit-learn — Clustering", url: "https://scikit-learn.org/stable/modules/clustering.html", lang: "en" }
  - { title: "scikit-learn — Decomposing signals in components (PCA)", url: "https://scikit-learn.org/stable/modules/decomposition.html", lang: "en" }
  - { title: "scikit-learn — Manifold learning (t-SNE)", url: "https://scikit-learn.org/stable/modules/manifold.html", lang: "en" }
  - { title: "UMAP — documentation", url: "https://umap-learn.readthedocs.io/en/latest/", lang: "en" }
---

# Apprentissage non supervisé : k-means, PCA

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 25

## 🎯 Ce que vous saurez faire
- Coder k-means en vingt lignes de NumPy et expliquer pourquoi il converge (mais pas forcément vers le meilleur résultat).
- Choisir entre k-means, DBSCAN et clustering hiérarchique en regardant la forme des données.
- Retrouver une PCA à partir de la décomposition en valeurs singulières vue en M24 (L111).
- Lire honnêtement une carte t-SNE ou UMAP : ce qu'elle montre, et ce qu'elle ne montre pas.

## 1. Apprendre sans étiquettes

Jusqu'ici, chaque exemple venait avec sa réponse $y$ : le prix, la maison de Poudlard, le devis signé. Dans la vraie vie d'une PME, la réponse manque souvent. Une enseigne de jardinerie a 40 000 fiches clients et aucune étiquette « type de client » ; un atelier de mécanique enregistre des vibrations de machines sans savoir lesquelles annoncent une panne. L'**apprentissage non supervisé** cherche de la structure dans $X$ seul. Il répond à deux grandes questions :

- **Y a-t-il des groupes ?** C'est le *clustering* (partitionnement) : segmentation clients, regroupement de documents, détection d'anomalies (ce qui n'appartient à aucun groupe).
- **Peut-on résumer ?** C'est la **réduction de dimension** : compresser 30 variables en 3, visualiser, débruiter, accélérer un modèle supervisé.

Stanford CS229 consacre la troisième partie de ses notes à ces méthodes (k-means, mélanges gaussiens et algorithme EM, analyse factorielle, PCA, ICA) ; MIT 6.036 termine sa série Fall 2020 par une leçon sur le clustering ; Andrew Ng ouvre le troisième cours de sa Specialization par le clustering et la détection d'anomalies. Le point commun de ces cours, et notre fil conducteur : **sans étiquette, il n'y a pas de « bonne réponse » unique**, il faut donc des critères internes et, surtout, un regard métier.

## 2. k-means : des centres qui se déplacent

### 2.1 L'algorithme de Lloyd

L'idée a été proposée par Stuart Lloyd aux Bell Labs en 1957 (publiée seulement en 1982) ; le nom « k-means » vient de James MacQueen (1967). On fixe un nombre de groupes $k$ et l'on cherche des centres $\mu_1, \dots, \mu_k$ qui minimisent l'**inertie**, la somme des distances au carré de chaque point à son centre :

$$J(c, \mu) = \sum_{i=1}^{m} \big\|x^{(i)} - \mu_{c^{(i)}}\big\|_2^2$$

L'algorithme alterne deux étapes, comme un manager qui réorganise ses équipes :

1. **Affectation** : chaque point rejoint le centre le plus proche, $c^{(i)} = \arg\min_j \|x^{(i)} - \mu_j\|^2$.
2. **Mise à jour** : chaque centre se place à la moyenne de ses points, $\mu_j = \frac{1}{|C_j|}\sum_{i \in C_j} x^{(i)}$.

Chaque étape fait baisser $J$ (ou le laisse stable) ; comme il n'existe qu'un nombre fini de partitions, l'algorithme s'arrête. Mais $J$ n'est pas convexe : on aboutit à un **minimum local**, qui dépend de l'initialisation. D'où deux parades systématiques : l'initialisation **k-means++** (Arthur et Vassilvitskii, 2007), qui choisit des centres initiaux éloignés les uns des autres, et plusieurs redémarrages (`n_init`) dont on garde le meilleur.

```python
"""k-means from scratch vs scikit-learn, puis choix de k (coude et silhouette)."""
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

rng = np.random.default_rng(7)
# Segmentation RFM simulée : récence (jours), fréquence (achats/an), montant (€/an)
profils = {"fidèles": (20, 18, 1_500), "occasionnels": (90, 4, 300), "dormants": (300, 1, 80)}
X = np.vstack([rng.normal(loc, [loc[0] * 0.3, loc[1] * 0.3, loc[2] * 0.3], size=(300, 3))
               for loc in profils.values()]).clip(min=0)
# Log du montant (très asymétrique) puis standardisation : sinon les euros écrasent tout le reste
Xs = StandardScaler().fit_transform(np.c_[X[:, :2], np.log1p(X[:, 2])])


def kmeans(X, k, n_iter=100, seed=0):
    rng = np.random.default_rng(seed)
    centers = X[rng.choice(len(X), k, replace=False)]           # initialisation naïve
    for _ in range(n_iter):
        d = ((X[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)   # distances (m, k)
        labels = d.argmin(axis=1)                                 # 1. affectation
        new = np.array([X[labels == j].mean(axis=0) if np.any(labels == j) else centers[j]
                        for j in range(k)])                       # 2. mise à jour
        if np.allclose(new, centers):
            break
        centers = new
    inertia = ((X - centers[labels]) ** 2).sum()
    return labels, centers, inertia


_, _, J_maison = kmeans(Xs, 3)
km = KMeans(n_clusters=3, n_init=10, random_state=0).fit(Xs)
print(f"Inertie from scratch : {J_maison:.1f} | scikit-learn (k-means++) : {km.inertia_:.1f}")

print(" k | inertie | silhouette")
for k in range(2, 8):
    model = KMeans(n_clusters=k, n_init=10, random_state=0).fit(Xs)
    print(f"{k:>2} | {model.inertia_:>7.1f} | {silhouette_score(Xs, model.labels_):.3f}")

# Interprétation métier : centres ramenés dans les unités d'origine
for j in range(3):
    r, f, m = X[km.labels_ == j].mean(axis=0)
    print(f"Segment {j} : récence {r:.0f} j, fréquence {f:.1f}/an, montant {m:.0f} €/an "
          f"({np.sum(km.labels_ == j)} clients)")
```

### 2.2 Choisir k

L'inertie baisse toujours quand $k$ augmente (avec $k = m$, elle vaut 0). On cherche donc un **coude**, l'endroit où ajouter un groupe ne rapporte plus grand-chose. Plus rigoureux, le **coefficient de silhouette** compare, pour chaque point, la distance moyenne $a$ à son propre groupe et la distance moyenne $b$ au groupe voisin le plus proche : $s = (b - a)/\max(a, b)$, entre $-1$ et $1$. Une silhouette moyenne proche de 1 signale des groupes compacts et bien séparés. Dans le script, $k = 3$ l'emporte : c'est bien le nombre de profils simulés. Faites l'essai sans le logarithme du montant : la silhouette hésite alors entre 2 et 3 groupes, preuve que la préparation des variables pèse autant que l'algorithme.

Mais le critère final est **métier**. Si le service marketing ne peut gérer que quatre campagnes, $k = 4$ est peut-être le bon choix même si la silhouette préfère 3. Un segment n'existe que s'il donne lieu à une action différente.

> ⚠️ **Piège fréquent** — Lancer k-means sur des variables brutes. Les distances euclidiennes additionnent des euros et des jours : le montant, aux valeurs les plus grandes, décide seul des groupes. Standardisez (ou transformez en logarithme les montants très asymétriques) avant tout algorithme fondé sur des distances.

## 3. Quand les groupes ne sont pas des boules

k-means suppose implicitement des groupes **sphériques** et de tailles comparables, et il range de force chaque point dans un groupe, y compris les aberrations. Deux alternatives couvrent la plupart des autres cas :

- **DBSCAN** (Ester, Kriegel, Sander et Xu, 1996) définit un groupe comme une zone **dense** : un point est « cœur » s'il a au moins `min_samples` voisins dans un rayon `eps`. Les groupes sont des chaînes de points cœurs ; les points isolés sont étiquetés **bruit** (`-1`). Pas besoin de fixer $k$, formes arbitraires acceptées, et la détection d'anomalies est offerte. En contrepartie, `eps` est délicat à régler et un seul `eps` convient mal à des densités très différentes (HDBSCAN, disponible dans scikit-learn, assouplit ce point).
- **Clustering hiérarchique ascendant** (agglomératif) : chaque point commence seul, puis on fusionne pas à pas les deux groupes les plus proches. Le critère de **Ward** fusionne ceux qui augmentent le moins l'inertie. Le résultat est un **dendrogramme**, un arbre qu'on coupe à la hauteur voulue : très parlant pour présenter une typologie à une direction.

| Critère | k-means | DBSCAN | Hiérarchique (Ward) |
|---|---|---|---|
| Nombre de groupes | à fixer | déduit de la densité | choisi en coupant l'arbre |
| Forme des groupes | sphérique | quelconque | plutôt compacte |
| Bruit / anomalies | non géré | étiquette `-1` | non géré |
| Passage à l'échelle | excellent (`MiniBatchKMeans`) | bon avec index spatial | quadratique en mémoire |
| Usage typique | segmentation clients | géolocalisation, anomalies | typologie présentée en dendrogramme |

```python
"""k-means vs DBSCAN vs hiérarchique sur des données en croissants."""
from sklearn.cluster import DBSCAN, AgglomerativeClustering, KMeans
from sklearn.datasets import make_moons
from sklearn.metrics import adjusted_rand_score
from sklearn.preprocessing import StandardScaler

X, y_true = make_moons(n_samples=600, noise=0.07, random_state=0)
X = StandardScaler().fit_transform(X)

modeles = {
    "k-means (k=2)": KMeans(n_clusters=2, n_init=10, random_state=0),
    "Hiérarchique Ward": AgglomerativeClustering(n_clusters=2, linkage="ward"),
    "Hiérarchique single": AgglomerativeClustering(n_clusters=2, linkage="single"),
    "DBSCAN (eps=0.3)": DBSCAN(eps=0.3, min_samples=5),
}
for nom, m in modeles.items():
    labels = m.fit_predict(X)
    n_bruit = int((labels == -1).sum())
    # ARI : accord avec les vrais groupes (1 = parfait), connu ici car données simulées
    print(f"{nom:<20} ARI = {adjusted_rand_score(y_true, labels):.3f}  points de bruit = {n_bruit}")
```

Sur deux croissants imbriqués, k-means et Ward coupent bêtement en deux moitiés ; DBSCAN et le lien simple (*single linkage*) suivent les formes. L'indice de Rand ajusté (ARI) n'est calculable qu'ici, parce que nous connaissons la vérité : en production, vous n'aurez que la silhouette et votre jugement.

## 4. PCA : trouver les directions qui comptent

### 4.1 L'idée

Karl Pearson publie en 1901 la recherche des « lignes et plans les plus proches » d'un nuage de points ; Harold Hotelling formalise l'**analyse en composantes principales** (*Principal Component Analysis*, PCA) en 1933. Le but : trouver la direction $u_1$ (vecteur unitaire) le long de laquelle les données **varient le plus**, puis la direction $u_2$ orthogonale qui capture le plus de variance restante, etc. Projeter sur les $d$ premières directions donne le meilleur résumé linéaire en $d$ dimensions, au sens de l'erreur de reconstruction.

Sur des données **centrées** $X$ ($m \times p$), la variance le long de $u$ vaut $u^\top \Sigma u$ avec $\Sigma = \frac{1}{m-1}X^\top X$ la matrice de covariance. Maximiser sous la contrainte $\|u\| = 1$ (multiplicateur de Lagrange) donne $\Sigma u = \lambda u$ : **les composantes principales sont les vecteurs propres de la covariance**, et la variance capturée est la valeur propre.

### 4.2 Le lien avec la SVD

En M24 L111, vous avez vu que toute matrice se décompose en $X = U S V^\top$. Alors :

$$X^\top X = V S U^\top U S V^\top = V S^2 V^\top \quad\Rightarrow\quad \Sigma = V\,\frac{S^2}{m-1}\,V^\top$$

Les colonnes de $V$ sont les composantes principales, et la variance expliquée par la composante $j$ vaut $s_j^2/(m-1)$. C'est ainsi que scikit-learn calcule la PCA : par SVD de $X$, sans jamais former $X^\top X$, ce qui est plus stable numériquement. Vérifions-le sur les 1 797 chiffres manuscrits $8\times8$ du jeu *Digits* (64 variables).

```python
"""PCA par SVD (NumPy) vs scikit-learn, et variance expliquée cumulée."""
import numpy as np
from sklearn.datasets import load_digits
from sklearn.decomposition import PCA

X, y = load_digits(return_X_y=True)          # 1 797 images, 64 pixels
Xc = X - X.mean(axis=0)                       # centrage OBLIGATOIRE

U, S, Vt = np.linalg.svd(Xc, full_matrices=False)
var_svd = S ** 2 / (len(X) - 1)
ratio_svd = var_svd / var_svd.sum()

pca = PCA().fit(X)
print("Variance expliquée (5 premières), SVD maison :", np.round(ratio_svd[:5], 4))
print("Variance expliquée (5 premières), sklearn    :", np.round(pca.explained_variance_ratio_[:5], 4))
# Les composantes sont égales au signe près (un vecteur propre est défini à ±1 près)
print("Mêmes composantes au signe près :", np.allclose(np.abs(Vt[:5]), np.abs(pca.components_[:5]), atol=1e-6))

cum = np.cumsum(pca.explained_variance_ratio_)
for seuil in (0.80, 0.90, 0.95):
    print(f"{int(seuil * 100)} % de la variance avec {np.searchsorted(cum, seuil) + 1} composantes sur 64")

# Compression / reconstruction avec 20 composantes
pca20 = PCA(n_components=20).fit(X)
X_rec = pca20.inverse_transform(pca20.transform(X))
print(f"Erreur de reconstruction moyenne (20 comp.) : {np.mean((X - X_rec) ** 2):.2f} (pixels de 0 à 16)")
```

Usages professionnels : résumer un questionnaire de satisfaction de 40 items en 3 « axes » (prix, service, qualité), débruiter des mesures de capteurs, réduire la dimension avant un k-means, ou visualiser. Rappel : la PCA est sensible à l'échelle, standardisez si les unités diffèrent (ce n'est pas nécessaire pour *Digits*, dont tous les pixels sont sur la même échelle).

> 💡 **À retenir** — PCA = SVD des données centrées. Les composantes sont les vecteurs singuliers droits $V$, les variances expliquées sont $s_j^2/(m-1)$. La même SVD tronquée sert en recommandation (factorisation de matrices) et pour LoRA en fine-tuning (M28).

## 5. t-SNE et UMAP : des cartes, pas des mesures

La PCA est **linéaire** : elle aplatit. Pour visualiser des structures courbes (les 10 chiffres de *Digits*, des embeddings de texte en 1 024 dimensions), on utilise des méthodes **non linéaires** qui préservent les **voisinages** :

- **t-SNE** (Laurens van der Maaten et Geoffrey Hinton, 2008) transforme les distances en probabilités de voisinage, en haute dimension (gaussienne) et en 2D (loi de Student, à queues lourdes), puis minimise leur divergence de Kullback-Leibler (M24 L113). Hyperparamètre clé : la **perplexité** (5 à 50), qui fixe approximativement le nombre de voisins considérés.
- **UMAP** (Leland McInnes, John Healy et James Melville, 2018) repose sur une construction de graphe de voisinage ; il est généralement plus rapide et conserve un peu mieux la structure globale. Il est fourni par le paquet `umap-learn`, pas par scikit-learn.

```python
"""Visualisation 2D de Digits : PCA, t-SNE et (si installé) UMAP."""
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE

X, y = load_digits(return_X_y=True)
X_pca50 = PCA(n_components=50, random_state=0).fit_transform(X)   # pré-réduction conseillée

projections = {
    "PCA (linéaire)": PCA(n_components=2).fit_transform(X),
    "t-SNE (perplexité 30)": TSNE(n_components=2, perplexity=30, init="pca", random_state=0).fit_transform(X_pca50),
}
try:
    import umap  # pip install umap-learn
    projections["UMAP"] = umap.UMAP(n_neighbors=15, min_dist=0.1, random_state=0).fit_transform(X_pca50)
except ImportError:
    print("(umap-learn non installé : pip install umap-learn)")

fig, axes = plt.subplots(1, len(projections), figsize=(5 * len(projections), 4.5))
for ax, (titre, Z) in zip(axes, projections.items()):
    sc = ax.scatter(Z[:, 0], Z[:, 1], c=y, cmap="tab10", s=6)
    ax.set_title(titre); ax.set_xticks([]); ax.set_yticks([])
fig.colorbar(sc, ax=axes, ticks=range(10), label="chiffre")
fig.savefig("projections_digits.png", dpi=120)
print("Graphique enregistré : projections_digits.png")
```

> ⚠️ **Piège fréquent** — Sur une carte t-SNE ou UMAP, la **taille** des groupes et les **distances entre groupes** ne veulent presque rien dire, et deux exécutions avec des graines différentes donnent des cartes différentes. Ce sont des outils d'exploration : ne calculez jamais un clustering « officiel » ni une conclusion chiffrée à partir des coordonnées t-SNE. Et n'utilisez pas t-SNE comme pré-traitement d'un modèle supervisé : il n'a pas de `transform` pour de nouvelles données.

> 🎮 **Défi** — Relancez t-SNE avec une perplexité de 2 puis de 100. À quoi ressemble la carte dans chaque cas ? Que vous apprend cette expérience sur la confiance à accorder à une seule carte ?

## 🧪 Exercice pratique

**Consigne.** Une chaîne de 12 magasins de bricolage vous confie un export (simulé) de 3 000 clients : récence, fréquence, montant annuel, part des achats en ligne, part des achats « jardin ». Générez ces données avec quatre profils sous-jacents de votre choix, puis :
1. Transformez le montant en logarithme et standardisez toutes les variables.
2. Choisissez $k$ par silhouette (de 2 à 8) et entraînez un k-means.
3. Faites une PCA à 2 composantes, affichez les clients colorés par segment, et interprétez les deux axes à partir de `pca.components_`.
4. Testez DBSCAN : combien de clients « atypiques » (bruit) détecte-t-il ? Qui sont-ils ?
5. Rédigez une fiche d'une page : nom métier de chaque segment, taille, chiffres clés et une action marketing par segment.

**Critères de réussite.**
- Le $k$ retenu est justifié à la fois par la silhouette et par un argument métier.
- Chaque axe de la PCA est nommé à partir de ses coefficients (ex. « axe 1 = valeur client »).
- Les centres sont présentés dans les **unités d'origine** (€, jours), pas en valeurs standardisées.
- La fiche ne contient aucune donnée personnelle identifiante (pas de nom ni d'e-mail : pensez RGPD).

**Pistes de corrigé.** Pour revenir aux unités d'origine, calculez les moyennes par segment sur le DataFrame brut (`df.groupby(labels).mean()`) plutôt que d'inverser la standardisation à la main. Un axe PCA dont les coefficients sont forts et positifs sur fréquence et montant, et négatifs sur récence, est un axe « valeur » ; un axe dominé par la part en ligne est un axe « canal ». Pour DBSCAN, choisissez `eps` avec la courbe des distances au $k$-ième voisin (`NearestNeighbors`), en repérant le coude.

## ✅ Auto-évaluation express
1. Pourquoi k-means peut-il donner deux résultats différents sur les mêmes données, et comment s'en prémunir ?
2. Dans une PCA par SVD, comment obtient-on la variance expliquée par chaque composante ?
3. Sur une carte t-SNE, le groupe A est deux fois plus étendu que le groupe B. Peut-on dire qu'A est plus hétérogène ?

**Réponses.** 1. L'objectif est non convexe : le résultat dépend des centres initiaux. On utilise k-means++ et plusieurs initialisations (`n_init`), en gardant l'inertie la plus faible. 2. Par $s_j^2/(m-1)$, où $s_j$ est la $j$-ième valeur singulière des données centrées ; le ratio est $s_j^2/\sum_k s_k^2$. 3. Non : t-SNE ne préserve pas les tailles ni les densités ; il faut mesurer l'hétérogénéité dans l'espace d'origine.

## 📚 Pour aller plus loin
- [Stanford CS229 — Machine Learning](https://cs229.stanford.edu/) 🇬🇧 — notes « Unsupervised learning » : k-means, mélanges gaussiens et EM, PCA, ICA.
- [scikit-learn — Clustering](https://scikit-learn.org/stable/modules/clustering.html) 🇬🇧 — tableau comparatif de tous les algorithmes et de leurs hypothèses de forme.
- [scikit-learn — Decomposing signals in components](https://scikit-learn.org/stable/modules/decomposition.html) 🇬🇧 — PCA, PCA incrémentale, SVD tronquée, NMF.
- [scikit-learn — Manifold learning](https://scikit-learn.org/stable/modules/manifold.html) 🇬🇧 — t-SNE et ses conseils pratiques (perplexité, pré-réduction par PCA).
- [UMAP — documentation](https://umap-learn.readthedocs.io/en/latest/) 🇬🇧 — paramètres `n_neighbors` et `min_dist`, et mises en garde sur l'interprétation.
- [MIT 18.06 Linear Algebra (OCW) — vidéos](https://www.ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/video_galleries/video-lectures) 🇬🇧 — leçon 29 sur la SVD, pour revoir le fondement mathématique de la PCA.
