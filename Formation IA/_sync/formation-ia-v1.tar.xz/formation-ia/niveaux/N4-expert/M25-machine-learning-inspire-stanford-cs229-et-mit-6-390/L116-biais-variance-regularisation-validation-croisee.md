---
id: L116
module: M25
level: N4
title: "Biais-variance, régularisation, validation croisée"
minutes: 60
objectives:
  - "Expliquer la décomposition biais-variance de l'erreur et la relier au sous- et au sur-apprentissage"
  - "Appliquer une régularisation L2 (Ridge), L1 (Lasso) ou Elastic Net et justifier le choix par l'interprétation bayésienne (lien M24)"
  - "Construire un protocole de validation croisée adapté aux données (k-fold, stratifiée, par groupes, temporelle)"
  - "Diagnostiquer un modèle à partir de courbes d'apprentissage et de validation"
skills: ["C4.2", "C4.1"]
sources:
  - { title: "Stanford CS229 — notes : Learning theory, regularization and model selection", url: "https://cs229.stanford.edu/", lang: "en" }
  - { title: "MIT 6.036 Introduction to Machine Learning (OCW, Fall 2020)", url: "https://live.ocw.mit.edu/courses/6-036-introduction-to-machine-learning-fall-2020", lang: "en" }
  - { title: "scikit-learn — Cross-validation: evaluating estimator performance", url: "https://scikit-learn.org/stable/modules/cross_validation.html", lang: "en" }
  - { title: "scikit-learn — Validation curves and learning curves", url: "https://scikit-learn.org/stable/modules/learning_curve.html", lang: "en" }
  - { title: "DeepLearning.AI — Machine Learning Specialization (cours 2, semaine 3)", url: "https://deeplearning.ai/courses/machine-learning-specialization", lang: "en" }
---

# Biais-variance, régularisation, validation croisée

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 25

## 🎯 Ce que vous saurez faire
- Écrire et commenter la décomposition $\text{erreur} = \text{biais}^2 + \text{variance} + \text{bruit}$, puis la mesurer par simulation.
- Choisir entre Ridge, Lasso et Elastic Net, et régler leur force $\lambda$ sans tricher.
- Mettre en place la bonne validation croisée : k-fold, stratifiée, par groupes ou temporelle.
- Lire une courbe d'apprentissage et décider s'il faut plus de données, un modèle plus riche ou plus de régularisation.

## 1. Le dilemme de l'élève qui révise

Imaginez deux candidats au code de la route. Le premier a retenu une règle unique : « dans le doute, je cède le passage ». Il se trompe régulièrement, mais toujours de la même façon : c'est un **biais** élevé. Le second a appris par cœur les 1 000 questions de son livre, avec leurs réponses. Il fait zéro faute sur le livre et s'effondre le jour de l'examen sur des photos qu'il n'a jamais vues : sa performance **varie** énormément selon les questions tirées. C'est une **variance** élevée.

Le machine learning tout entier est une recherche d'équilibre entre ces deux élèves. Stanford CS229 consacre une partie entière de ses notes à cette « théorie de l'apprentissage » ; Andrew Ng en fait le cœur de ses « conseils pratiques » (Machine Learning Specialization, cours 2, semaine 3), en répétant qu'un praticien efficace se distingue d'abord par sa capacité à **diagnostiquer** biais ou variance avant de toucher au code.

## 2. La décomposition biais-variance

Supposons que les données obéissent à $y = f(x) + \varepsilon$, avec un bruit $\varepsilon$ de moyenne nulle et de variance $\sigma^2$. On entraîne un modèle $\hat f_D$ sur un jeu d'entraînement $D$ tiré au hasard. Pour un point $x$ fixé, l'erreur quadratique attendue (sur les tirages de $D$ et de $\varepsilon$) se décompose exactement :

$$\mathbb{E}\big[(y - \hat f_D(x))^2\big] = \underbrace{\big(f(x) - \mathbb{E}_D[\hat f_D(x)]\big)^2}_{\text{biais}^2} + \underbrace{\mathbb{E}_D\big[(\hat f_D(x) - \mathbb{E}_D[\hat f_D(x)])^2\big]}_{\text{variance}} + \underbrace{\sigma^2}_{\text{bruit irréductible}}$$

La démonstration tient en quatre lignes avec les outils de M24 L113 : on ajoute et on retranche $\mathbb{E}_D[\hat f_D(x)]$, on développe le carré, et les termes croisés s'annulent car l'espérance d'un écart à la moyenne est nulle. Trois enseignements :

- le **bruit** $\sigma^2$ est un plancher : aucun modèle ne fera mieux. Si vos ventes dépendent de la météo et que vous n'avez pas la météo, ce plancher est haut ;
- le **biais** mesure l'erreur « moyenne » du modèle : une droite pour une relation en cloche aura toujours tort ;
- la **variance** mesure la sensibilité au jeu d'entraînement : un polynôme de degré 15 sur 30 points change du tout au tout si l'on remplace trois points.

Vérifions-le numériquement : on tire 200 jeux d'entraînement, on entraîne trois polynômes et on mesure biais et variance.

```python
"""Mesure empirique du biais et de la variance de régressions polynomiales."""
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

rng = np.random.default_rng(0)
f = lambda x: np.sin(2 * np.pi * x)          # la "vraie" relation, inconnue en pratique
sigma = 0.3
x_test = np.linspace(0, 1, 100)

for degree in (1, 4, 15):
    preds = []
    for _ in range(200):                        # 200 jeux d'entraînement différents
        x = rng.uniform(0, 1, 30)
        y = f(x) + rng.normal(0, sigma, 30)
        model = make_pipeline(PolynomialFeatures(degree), StandardScaler(), LinearRegression())
        model.fit(x.reshape(-1, 1), y)
        preds.append(model.predict(x_test.reshape(-1, 1)))
    preds = np.array(preds)
    mean_pred = preds.mean(axis=0)
    bias2 = ((f(x_test) - mean_pred) ** 2).mean()
    var = preds.var(axis=0).mean()
    print(f"degré {degree:>2} : biais²={bias2:.3f}  variance={var:.3f}  "
          f"erreur attendue≈{bias2 + var + sigma**2:.3f}")
```

Vous obtenez un biais énorme au degré 1 (sous-apprentissage, *underfitting*), un équilibre au degré 4, et une variance qui explose au degré 15 (sur-apprentissage, *overfitting*) : des dizaines de milliers de fois celle du degré 4 (≈ 774 contre ≈ 0,03 avec cette graine), à cause de polynômes qui s'envolent aux bords de l'intervalle, là où les points sont rares (ces quelques ajustements extrêmes font même grimper le biais² mesuré). La courbe classique « en U » de l'erreur de test en fonction de la complexité est sous vos yeux.

> 💡 **À retenir** — Erreur d'entraînement élevée → problème de **biais** (modèle trop simple, variables manquantes). Erreur d'entraînement faible mais erreur de validation élevée → problème de **variance** (modèle trop complexe, trop peu de données). Le remède est opposé dans les deux cas.

> ⚠️ **Piège fréquent** — Croire que le dilemme est une loi absolue. Les réseaux de neurones très surparamétrés présentent une « double descente » (*double descent*) où l'erreur de test redescend au-delà du point d'interpolation. Pour les modèles classiques de ce module, le U reste le bon guide (la double descente a été popularisée par Belkin et al., 2019).

## 3. Régulariser : payer pour la complexité

### 3.1 Ridge (L2) et Lasso (L1)

Plutôt que de choisir le degré à la main, on garde un modèle riche et on **pénalise** les grands coefficients. Avec la norme $L_2$ (M24 L111), on obtient la **régression Ridge** (Hoerl et Kennard, 1970) :

$$J_{\text{Ridge}}(\theta) = \frac{1}{2m}\|X\theta - y\|_2^2 + \frac{\lambda}{2}\|\theta\|_2^2 \quad\Rightarrow\quad \theta^\star = (X^\top X + m\lambda I)^{-1}X^\top y$$

Le terme $m\lambda I$ ajouté à $X^\top X$ a un bonus numérique : il rend la matrice toujours inversible, même quand deux variables sont parfaitement corrélées (le chiffre d'affaires HT et TTC d'une même facture, par exemple).

Avec la norme $L_1$, on obtient le **Lasso** (Tibshirani, 1996) :

$$J_{\text{Lasso}}(\theta) = \frac{1}{2m}\|X\theta - y\|_2^2 + \lambda\|\theta\|_1$$

Le Lasso n'a pas de solution analytique (la valeur absolue n'est pas dérivable en 0), mais il a une propriété précieuse : il met **exactement à zéro** les coefficients inutiles. Géométriquement, la boule $L_1$ est un losange dont les sommets sont sur les axes ; les ellipses de niveau de la MSE la touchent le plus souvent en un sommet, donc avec des coordonnées nulles. Ridge, dont la boule est ronde, réduit tout sans rien annuler. L'**Elastic Net** combine les deux.

| | Ridge (L2) | Lasso (L1) | Elastic Net |
|---|---|---|---|
| Effet sur les coefficients | tous réduits, aucun nul | beaucoup exactement nuls | intermédiaire |
| Variables corrélées | les partage | en garde une au hasard | les garde en groupe |
| Sélection de variables | non | oui | oui |
| Prior bayésien (M24 L113) | gaussien | de Laplace | mélange |
| Classe scikit-learn | `Ridge`, `RidgeCV` | `Lasso`, `LassoCV` | `ElasticNet`, `ElasticNetCV` |

### 3.2 Pourquoi c'est du bayésien déguisé

Le **maximum a posteriori** (MAP) prolonge le maximum de vraisemblance vu en M24 L113 en ajoutant un a priori sur les paramètres : $\theta_{\text{MAP}} = \arg\max_\theta \log p(y \mid X, \theta) + \log p(\theta)$. Si l'on suppose un a priori gaussien $\theta_j \sim \mathcal N(0, \tau^2)$, $\log p(\theta)$ vaut $-\|\theta\|_2^2/(2\tau^2)$ à une constante près : c'est la pénalité Ridge. Avec un a priori de Laplace, on retrouve la pénalité $L_1$. **Régulariser, c'est déclarer qu'on croit a priori que les effets sont petits.** Un $\lambda$ grand exprime une croyance forte.

Dans le code ci-dessous, sur le jeu *Diabetes* (442 patients, 10 variables), observez combien de coefficients le Lasso annule quand $\lambda$ augmente. Notez que scikit-learn appelle $\lambda$ `alpha`, et que `LogisticRegression` utilise l'inverse `C` $= 1/\lambda$ : grand `C` = peu de régularisation.

```python
"""Ridge vs Lasso : effet de la force de régularisation sur les coefficients."""
import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.linear_model import Lasso, Ridge
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_diabetes(return_X_y=True, as_frame=True)

print(f"{'alpha':>8} | {'Ridge R² (CV)':>13} | {'Lasso R² (CV)':>13} | coefs nuls Lasso")
for alpha in (0.01, 0.1, 1, 10, 100):
    ridge = make_pipeline(StandardScaler(), Ridge(alpha=alpha))
    lasso = make_pipeline(StandardScaler(), Lasso(alpha=alpha, max_iter=10_000))
    r_ridge = cross_val_score(ridge, X, y, cv=5, scoring="r2").mean()
    r_lasso = cross_val_score(lasso, X, y, cv=5, scoring="r2").mean()
    n_zero = int(np.sum(lasso.fit(X, y)[-1].coef_ == 0))
    print(f"{alpha:>8} | {r_ridge:>13.3f} | {r_lasso:>13.3f} | {n_zero}/10")

lasso = make_pipeline(StandardScaler(), Lasso(alpha=5)).fit(X, y)
kept = [c for c, w in zip(X.columns, lasso[-1].coef_) if w != 0]
print("Variables conservées par le Lasso (alpha=5) :", kept)
```

> ⚠️ **Piège fréquent** — Régulariser sans standardiser. La pénalité porte sur la taille des coefficients ; si le salaire est en euros et l'ancienneté en années, le coefficient du salaire est minuscule par construction et échappe à la pénalité. Toujours `StandardScaler` avant Ridge, Lasso ou une régression logistique régularisée.

## 4. Valider sans se mentir

### 4.1 Trois jeux, trois rôles

Le **jeu d'entraînement** sert à apprendre les paramètres $\theta$. Le **jeu de validation** sert à choisir les hyperparamètres ($\lambda$, degré, profondeur d'arbre). Le **jeu de test** sert une seule fois, à la fin, à estimer la performance réelle. Si vous choisissez $\lambda$ en regardant le test, votre score de test devient optimiste : vous avez « appris » le test.

### 4.2 La validation croisée k-fold

Sur 442 patients, sacrifier 20 % pour la validation coûte cher et rend le score instable. La **validation croisée en k blocs** (*k-fold cross-validation*) découpe l'entraînement en $k$ parts, entraîne $k$ fois sur $k-1$ parts et évalue sur la part restante, puis moyenne :

```
Pli 1 : [VAL][ tr ][ tr ][ tr ][ tr ]
Pli 2 : [ tr ][VAL][ tr ][ tr ][ tr ]
Pli 3 : [ tr ][ tr ][VAL][ tr ][ tr ]     score = moyenne ± écart-type des 5
Pli 4 : [ tr ][ tr ][ tr ][VAL][ tr ]
Pli 5 : [ tr ][ tr ][ tr ][ tr ][VAL]     (le jeu de TEST reste à part)
```

Le choix du découpage dépend de la **structure des données**, et c'est là que se jouent la plupart des erreurs professionnelles :

| Situation | Découpage | Classe scikit-learn |
|---|---|---|
| Données i.i.d., régression | k-fold mélangé | `KFold(shuffle=True)` |
| Classification déséquilibrée | proportions de classes conservées | `StratifiedKFold` |
| Plusieurs lignes par client, patient, magasin | un groupe entier par pli | `GroupKFold`, `StratifiedGroupKFold` |
| Séries temporelles (ventes, trafic) | passé → futur, jamais l'inverse | `TimeSeriesSplit` |
| Choisir les hyperparamètres ET estimer la performance | validation croisée imbriquée | `GridSearchCV` dans `cross_val_score` |

Exemple vécu : une enseigne de boulangeries prédit ses invendus par magasin et par jour. Avec un `KFold` mélangé, le modèle voit le mardi et le jeudi d'une semaine pour prédire le mercredi : score superbe, production catastrophique. Avec `TimeSeriesSplit`, le score baisse… et devient vrai.

> 🔗 **Documentation officielle** — [scikit-learn — Cross-validation: evaluating estimator performance](https://scikit-learn.org/stable/modules/cross_validation.html) 🇬🇧 (schémas de chaque stratégie de découpage).

## 5. Courbes d'apprentissage et de validation

Deux graphiques suffisent pour savoir quoi faire ensuite :

- la **courbe de validation** : score d'entraînement et de validation en fonction d'un hyperparamètre (la complexité). Elle montre le U du §2 et le bon réglage ;
- la **courbe d'apprentissage** : les mêmes scores en fonction de la **taille du jeu d'entraînement**. Si les deux courbes se rejoignent à un niveau médiocre, c'est du biais : plus de données n'aidera pas, il faut un modèle plus riche ou de meilleures variables. Si un écart persiste entre elles, c'est de la variance : plus de données ou plus de régularisation aideront.

```python
"""Courbe de validation (complexité) et courbe d'apprentissage (taille des données)."""
import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, learning_curve, validation_curve
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_breast_cancer(return_X_y=True)
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=5_000))

Cs = np.logspace(-4, 4, 17)                    # C = 1/lambda
tr, va = validation_curve(model, X, y, param_name="logisticregression__C",
                          param_range=Cs, cv=cv, scoring="roc_auc")
best = Cs[va.mean(axis=1).argmax()]
print(f"Meilleur C ≈ {best:.3g} (AUC validation {va.mean(axis=1).max():.4f})")

sizes, tr_l, va_l = learning_curve(make_pipeline(StandardScaler(), LogisticRegression(C=best, max_iter=5_000)),
                                   X, y, cv=cv, scoring="roc_auc",
                                   train_sizes=np.linspace(0.1, 1.0, 8))

fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4))
a1.semilogx(Cs, tr.mean(axis=1), label="entraînement")
a1.semilogx(Cs, va.mean(axis=1), label="validation")
a1.set(xlabel="C (inverse de la régularisation)", ylabel="ROC AUC", title="Courbe de validation")
a2.plot(sizes, tr_l.mean(axis=1), "o-", label="entraînement")
a2.plot(sizes, va_l.mean(axis=1), "o-", label="validation")
a2.set(xlabel="taille du jeu d'entraînement", title="Courbe d'apprentissage")
for a in (a1, a2):
    a.legend(); a.grid(alpha=0.3)
fig.tight_layout(); fig.savefig("courbes_biais_variance.png", dpi=120)
print("Graphique enregistré : courbes_biais_variance.png")
```

À gauche, quand `C` est minuscule (régularisation écrasante), les deux scores sont bas : biais. Quand `C` est énorme, l'entraînement frôle 1 et la validation décroche légèrement : variance. Le sommet de la courbe de validation désigne le bon réglage.

> 🎮 **Défi** — Remplacez la régression logistique par `DecisionTreeClassifier` et faites varier `max_depth` de 1 à 20 dans `validation_curve`. À partir de quelle profondeur l'arbre commence-t-il à sur-apprendre ? Gardez la réponse pour L117.

## 🧪 Exercice pratique

**Consigne.** Une PME de livraison vous confie 24 mois de données journalières (nombre de colis, jour de la semaine, météo, promotions) pour prédire le volume du lendemain. Simulez ces données avec NumPy (tendance + saisonnalité hebdomadaire + bruit), puis : (1) comparez le R² moyen obtenu avec `KFold(shuffle=True)` et avec `TimeSeriesSplit(n_splits=5)` sur un modèle `Ridge` avec variables de jour encodées ; (2) choisissez `alpha` par `RidgeCV` ; (3) tracez la courbe d'apprentissage et concluez : faut-il collecter plus d'historique ?

**Critères de réussite.**
- Les deux protocoles sont exécutés sur exactement le même modèle et les mêmes variables.
- Vous expliquez par écrit (5 lignes) pourquoi le score `KFold` est optimiste.
- Le choix de `alpha` est fait sans jamais utiliser les 3 derniers mois, réservés au test final.
- La conclusion « biais » ou « variance » est justifiée par la forme des courbes.

**Pistes de corrigé.** Le `KFold` mélangé est optimiste parce que des jours voisins (fortement corrélés) se retrouvent de part et d'autre de la frontière entraînement/validation : le modèle « interpole » au lieu de prévoir. Ajoutez des variables décalées (*lags*, volume de la veille et de J-7) **calculées uniquement à partir du passé**. Si les courbes d'apprentissage convergent vers un R² modeste, la limite est le biais : enrichissez les variables (jours fériés, vacances scolaires) plutôt que l'historique.

## ✅ Auto-évaluation express
1. Votre modèle a 0,99 d'AUC en entraînement et 0,71 en validation. Biais ou variance ? Citez deux remèdes.
2. Pourquoi le Lasso produit-il des coefficients exactement nuls, contrairement à Ridge ?
3. Vous avez 50 lignes par client pour 400 clients. Quel découpage de validation croisée utilisez-vous ?

**Réponses.** 1. Variance (sur-apprentissage) : plus de régularisation, un modèle plus simple, plus de données ou moins de variables. 2. La boule $L_1$ a des « coins » sur les axes, où les contours de la perte la touchent le plus souvent ; le sous-gradient de $|\theta_j|$ permet de rester à 0. 3. `GroupKFold` (ou `StratifiedGroupKFold`) avec l'identifiant client comme groupe, pour qu'aucun client ne soit à la fois en entraînement et en validation.

## 📚 Pour aller plus loin
- [Stanford CS229 — Machine Learning](https://cs229.stanford.edu/) 🇬🇧 — notes « Learning theory » et « Regularization and model selection » (biais-variance, sélection de modèle, validation croisée).
- [MIT 6.036 Introduction to Machine Learning (OCW)](https://live.ocw.mit.edu/courses/6-036-introduction-to-machine-learning-fall-2020) 🇬🇧 — semaines « Regression » et régularisation, licence CC BY-NC-SA 4.0.
- [scikit-learn — Validation curves and learning curves](https://scikit-learn.org/stable/modules/learning_curve.html) 🇬🇧 — API `validation_curve`, `learning_curve` et leur lecture.
- [scikit-learn — Linear Models](https://scikit-learn.org/stable/modules/linear_model.html) 🇬🇧 — Ridge, Lasso, Elastic Net et leurs variantes `CV`.
- [Google — Machine Learning Crash Course](https://developers.google.com/machine-learning/crash-course) 🇬🇧 — module « Datasets, Generalization, and Overfitting ».
