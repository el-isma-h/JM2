---
id: L124
module: M26
level: N4
title: "Réseaux convolutifs et vision"
minutes: 60
objectives:
  - "Expliquer pourquoi la convolution convient aux images (partage de poids, localité, invariance par translation)"
  - "Calculer la taille de sortie, le nombre de paramètres et le champ récepteur d'une pile de convolutions et de poolings"
  - "Implémenter une convolution en NumPy, la vérifier contre PyTorch, puis entraîner un CNN qui bat le MLP de L123"
  - "Appliquer l'apprentissage par transfert avec un ResNet pré-entraîné de torchvision et une augmentation de données adaptée"
skills: ["C4.3"]
sources:
  - { title: "MIT 6.S191 (2026) — Lecture 3 : Deep Computer Vision", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "Stanford CS231n Spring 2026 — Lectures 5-6 : CNNs, CNN architectures", url: "https://cs231n.stanford.edu/schedule.html", lang: "en" }
  - { title: "He et al. (2015) — Deep Residual Learning for Image Recognition", url: "https://arxiv.org/abs/1512.03385", lang: "en" }
  - { title: "PyTorch — torch.nn.Conv2d", url: "https://pytorch.org/docs/stable/generated/torch.nn.Conv2d.html", lang: "en" }
  - { title: "torchvision — Models and pre-trained weights", url: "https://pytorch.org/vision/stable/models.html", lang: "en" }
  - { title: "PyTorch — Transfer Learning for Computer Vision Tutorial", url: "https://pytorch.org/tutorials/beginner/transfer_learning_tutorial.html", lang: "en" }
  - { title: "École 42 — Leaffliction (dépôt étudiant public)", url: "https://github.com/jainavas/leaffliction", lang: "en" }
---

# Réseaux convolutifs et vision

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 26

## 🎯 Ce que vous saurez faire
- Justifier le choix d'un réseau convolutif (*convolutional neural network*, CNN) plutôt que d'un MLP pour des images.
- Calculer à la main la forme de sortie et le nombre de paramètres de chaque couche d'un CNN.
- Coder une convolution en NumPy et la vérifier contre `torch.nn.functional.conv2d`.
- Entraîner un petit CNN sur Fashion-MNIST qui dépasse le MLP de L123.
- Réutiliser un ResNet pré-entraîné sur ImageNet pour un problème métier avec peu d'images.

La séance 3 de MIT 6.S191 (« Deep Computer Vision ») et les séances 5 et 6 de Stanford CS231n (édition Spring 2026) couvrent ce terrain ; cette leçon en propose une version originale, orientée pratique.

## 1. Pourquoi le MLP ne suffit pas pour les images

Une photo de produit de 224 × 224 pixels en couleur, c'est $224 \times 224 \times 3 = 150\,528$ nombres. Une seule couche dense de 1 000 neurones demanderait **150 millions de poids**, pour une seule couche. Pire, le MLP ne sait pas qu'un pixel est voisin d'un autre : si le sac à main se décale de dix pixels vers la droite, toutes les entrées changent et il faut tout réapprendre.

Les images ont deux propriétés que l'on peut exploiter :

- **Localité** : un motif (un bord, un coin, une texture) se lit sur quelques pixels voisins.
- **Invariance par translation** : un bord est un bord, qu'il soit en haut à gauche ou au centre.

D'où l'idée de la convolution : un **petit filtre** (3 × 3, par exemple) que l'on fait glisser sur toute l'image, avec **les mêmes poids partout**. Neuf poids au lieu de 150 millions, et la détection d'un motif fonctionne à n'importe quelle position.

### 1.1 Repères historiques

| Année | Étape |
|---|---|
| 1959-1962 | Hubel et Wiesel découvrent dans le cortex visuel du chat des neurones sensibles à des orientations de bords dans une petite zone (prix Nobel 1981) |
| 1980 | Kunihiko Fukushima propose le *Neocognitron*, hiérarchie de couches locales inspirée de ces travaux |
| 1989-1998 | Yann LeCun et ses collègues (Bell Labs) entraînent des CNN par rétropropagation pour lire les chiffres manuscrits ; LeNet-5 (1998) sert à la lecture automatique de chèques |
| 2012 | AlexNet (Krizhevsky, Sutskever, Hinton) remporte le défi ImageNet avec une erreur top-5 d'environ 15 %, contre environ 26 % pour le deuxième : début de l'ère du deep learning |
| 2015 | ResNet (He et al., Microsoft Research) entraîne des réseaux de 152 couches grâce aux connexions résiduelles et gagne ImageNet 2015 |
| 2020 | Les Vision Transformers (ViT) montrent qu'un Transformer peut rivaliser avec les CNN à grande échelle (vous les verrez en M27) |

## 2. La convolution, pas à pas

### 2.1 Définition

Pour une image à un canal $X$ et un noyau (*kernel*) $K$ de taille $k \times k$, la sortie (*feature map*) vaut :

$$Y_{i,j} = b + \sum_{u=0}^{k-1}\sum_{v=0}^{k-1} K_{u,v}\, X_{i+u,\, j+v}$$

(Les mathématiciens appellent cela une corrélation croisée ; les frameworks l'appellent convolution, et le nom est resté.) Avec $C_{\text{in}}$ canaux d'entrée et $C_{\text{out}}$ filtres, chaque filtre a la forme $C_{\text{in}} \times k \times k$ et produit **un** canal de sortie.

### 2.2 Les trois formules à savoir

Pour une entrée de côté $n$, un noyau $k$, un remplissage (*padding*) $p$ et un pas (*stride*) $s$ :

$$n_{\text{sortie}} = \left\lfloor \frac{n + 2p - k}{s} \right\rfloor + 1$$

$$\text{paramètres} = C_{\text{out}} \times (C_{\text{in}} \times k \times k + 1)$$

Le **champ récepteur** d'un neurone (la zone de l'image d'origine qui l'influence) grandit avec la profondeur : deux convolutions 3 × 3 empilées voient une zone 5 × 5, trois en voient 7 × 7, pour moins de paramètres qu'une seule 7 × 7 ($3 \times 9 = 27$ contre $49$ par couple de canaux). C'est l'idée maîtresse de VGG (2014).

| Couche | Entrée | Réglages | Sortie | Paramètres |
|---|---|---|---|---|
| Conv2d | $1 \times 28 \times 28$ | 32 filtres, $k=3$, $p=1$ | $32 \times 28 \times 28$ | $32 \times (1 \cdot 9 + 1) = 320$ |
| MaxPool2d | $32 \times 28 \times 28$ | $2 \times 2$, $s=2$ | $32 \times 14 \times 14$ | 0 |
| Conv2d | $32 \times 14 \times 14$ | 64 filtres, $k=3$, $p=1$ | $64 \times 14 \times 14$ | $64 \times (32 \cdot 9 + 1) = 18\,496$ |
| MaxPool2d | | $2 \times 2$ | $64 \times 7 \times 7$ | 0 |
| Linear | $3\,136$ | 10 sorties | $10$ | $31\,370$ |

Total : environ **50 000 paramètres**, deux fois moins que le MLP 784 → 128 → 64 → 10 de L123 (109 386) et près de cinq fois moins que le MLP entraîné sur Fashion-MNIST (235 146), pour de meilleures performances.

### 2.3 Le pooling

Le *max pooling* $2 \times 2$ garde le maximum de chaque bloc de quatre pixels : il divise la résolution par deux, rend le réseau un peu plus tolérant aux petits décalages et réduit le calcul des couches suivantes. Il n'a **aucun paramètre**. En fin de réseau, le *global average pooling* (moyenne de chaque canal sur toute l'image) remplace souvent les grosses couches denses : c'est ce que fait ResNet.

> 💡 **À retenir** — Une convolution, c'est une couche linéaire avec **poids partagés** et **connexions locales**. Les premières couches apprennent des bords et des textures ; les suivantes, des motifs ; les dernières, des parties d'objets. La hiérarchie émerge de l'entraînement, personne ne la programme.

### 2.4 Une convolution en NumPy, vérifiée par PyTorch

```python
"""conv_numpy.py — convolution 2D (un canal) à la main, comparée à PyTorch."""
import numpy as np
import torch
import torch.nn.functional as F

def conv2d(X, K, pas=1, rembourrage=0):
    X = np.pad(X, rembourrage)
    k = K.shape[0]
    n_out = (X.shape[0] - k) // pas + 1
    m_out = (X.shape[1] - k) // pas + 1
    Y = np.zeros((n_out, m_out))
    for i in range(n_out):
        for j in range(m_out):
            fenetre = X[i * pas:i * pas + k, j * pas:j * pas + k]
            Y[i, j] = np.sum(fenetre * K)          # produit terme à terme puis somme
    return Y

# Une image 6x6 : moitié gauche sombre, moitié droite claire
X = np.zeros((6, 6)); X[:, 3:] = 1.0
# Filtre de Sobel : détecte les bords verticaux
K = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=float)
Y = conv2d(X, K)
print(Y)                                        # fortes valeurs (4) sur les colonnes du bord

# Vérification : PyTorch attend (lot, canaux, hauteur, largeur)
Yt = F.conv2d(torch.tensor(X)[None, None], torch.tensor(K)[None, None])
print("identique à PyTorch :", np.allclose(Y, Yt[0, 0].numpy()))
print("forme avec p=1, s=2 :", conv2d(X, K, pas=2, rembourrage=1).shape)   # (3, 3)
```

Le filtre de Sobel a été choisi à la main ; un CNN **apprend** ses filtres par rétropropagation. Le gradient d'une convolution est lui-même une convolution (avec le noyau retourné), ce qui explique pourquoi les GPU, optimisés pour cette opération, accélèrent aussi bien la passe arrière.

## 3. Un CNN qui bat le MLP

Reprenez le script `entrainer_fashion.py` de L123 et remplacez uniquement la classe du modèle. Tout le reste (données, boucle, sauvegarde) est inchangé : c'est l'intérêt d'une boucle bien écrite.

```python
"""cnn_fashion.py — à coller à la place de la classe MLP de entrainer_fashion.py (L123)."""
import torch
from torch import nn

class PetitCNN(nn.Module):
    def __init__(self, n_classes=10):
        super().__init__()
        self.extracteur = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.MaxPool2d(2),                                   # 28 -> 14
            nn.Conv2d(32, 64, kernel_size=3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.MaxPool2d(2),                                   # 14 -> 7
        )
        self.classifieur = nn.Sequential(
            nn.Flatten(),
            nn.Dropout(0.25),
            nn.Linear(64 * 7 * 7, n_classes),
        )

    def forward(self, x):
        return self.classifieur(self.extracteur(x))

if __name__ == "__main__":
    modele = PetitCNN()
    print("paramètres :", sum(p.numel() for p in modele.parameters()))
    print(modele(torch.randn(8, 1, 28, 28)).shape)            # torch.Size([8, 10])
```

Le décompte affiche **50 378 paramètres** (les 50 186 du tableau plus 192 pour les deux normalisations par lot, expliquées en L126). Dans le script de L123, remplacez `modele = MLP().to(device)` par `modele = PetitCNN().to(device)`. Sur Fashion-MNIST, ce réseau atteint en général **91 à 92 %** d'exactitude de test en dix époques, contre 88-89 % pour le MLP, avec près de cinq fois moins de paramètres (50 378 contre 235 146). Comptez quelques minutes par époque sur un CPU de portable, quelques secondes sur GPU.

> ⚠️ **Piège fréquent** — Se tromper dans la taille d'entrée de la première couche dense (`64 * 7 * 7`). Plutôt que de la calculer, faites passer un lot factice dans `extracteur` et lisez `.shape`, ou utilisez `nn.LazyLinear(n_classes)`, qui déduit la taille au premier appel.

## 4. ResNet : la connexion qui a permis la profondeur

Avant 2015, empiler plus de vingt couches **dégradait** l'exactitude, même sur les données d'entraînement : ce n'était pas du sur-apprentissage, c'était un problème d'optimisation. L'idée de Kaiming He et de ses collègues : au lieu d'apprendre une fonction $H(x)$, chaque bloc apprend une **correction** $F(x)$ que l'on ajoute à l'entrée :

$$y = F(x) + x$$

En arrière, le nœud d'addition est un **distributeur** (L122, section 3) : le gradient de $y$ arrive intact à $x$, quelle que soit la qualité de $F$. Sur cinquante blocs, le signal a une autoroute pour remonter jusqu'aux premières couches. Cette idée est aujourd'hui partout, y compris dans chaque bloc de Transformer (M27).

```python
import torch
from torch import nn

class BlocResiduel(nn.Module):
    """Bloc de base de ResNet-18/34 : deux convolutions 3x3 et un raccourci."""
    def __init__(self, canaux):
        super().__init__()
        self.f = nn.Sequential(
            nn.Conv2d(canaux, canaux, 3, padding=1, bias=False), nn.BatchNorm2d(canaux), nn.ReLU(),
            nn.Conv2d(canaux, canaux, 3, padding=1, bias=False), nn.BatchNorm2d(canaux),
        )
    def forward(self, x):
        return torch.relu(self.f(x) + x)          # y = F(x) + x

bloc = BlocResiduel(64)
print(bloc(torch.randn(2, 64, 14, 14)).shape)     # la forme est conservée : (2, 64, 14, 14)
```

## 5. L'apprentissage par transfert

Une PME n'a ni un million d'images étiquetées ni des semaines de GPU. Elle a, disons, 600 photos de pièces usinées « conformes » ou « défaut », ou 1 200 photos de feuilles de vigne réparties en quatre maladies. La bonne stratégie est de **réutiliser un réseau déjà entraîné** sur ImageNet (1,2 million d'images, 1 000 classes) : ses couches basses savent déjà voir des bords, des textures et des formes, ce qui est utile pour presque toutes les images naturelles.

| Stratégie | Ce qu'on entraîne | Quand l'utiliser |
|---|---|---|
| Extraction de caractéristiques (*feature extraction*) | uniquement la nouvelle tête | très peu d'images (quelques centaines), domaine proche des photos courantes |
| Ajustement fin (*fine-tuning*) partiel | la tête + les derniers blocs | quelques milliers d'images |
| Ajustement fin complet | tout le réseau, avec un petit taux d'apprentissage | beaucoup d'images ou domaine éloigné (radiographies, images satellites) |
| Entraînement depuis zéro | tout, initialisation aléatoire | très grand jeu de données propre au domaine |

```python
"""transfert.py — ResNet-18 pré-entraîné sur ImageNet, nouvelle tête à 4 classes.
Données attendues : dossier images/train/<classe>/*.jpg et images/valid/<classe>/*.jpg"""
import torch
from torch import nn
from torchvision import datasets, models, transforms

device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
poids = models.ResNet18_Weights.DEFAULT                 # poids ImageNet (téléchargés une fois)
modele = models.resnet18(weights=poids)

# 1. Geler l'extracteur de caractéristiques
for p in modele.parameters():
    p.requires_grad = False
# 2. Remplacer la tête (1 000 classes ImageNet -> nos 4 classes) ; elle seule sera entraînée
modele.fc = nn.Linear(modele.fc.in_features, 4)
modele = modele.to(device)

# 3. Prétraitements : ceux du pré-entraînement + augmentation sur le train seulement
normalisation = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
t_train = transforms.Compose([
    transforms.RandomResizedCrop(224, scale=(0.7, 1.0)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ColorJitter(brightness=0.2, contrast=0.2),
    transforms.ToTensor(), normalisation,
])
t_valid = transforms.Compose([transforms.Resize(256), transforms.CenterCrop(224),
                              transforms.ToTensor(), normalisation])
train = datasets.ImageFolder("images/train", transform=t_train)
valid = datasets.ImageFolder("images/valid", transform=t_valid)
dl_train = torch.utils.data.DataLoader(train, batch_size=32, shuffle=True, num_workers=2)
dl_valid = torch.utils.data.DataLoader(valid, batch_size=64, num_workers=2)
print("classes :", train.classes)

optimiseur = torch.optim.AdamW(modele.fc.parameters(), lr=1e-3)
critere = nn.CrossEntropyLoss()
for epoque in range(5):
    modele.train()
    for xb, yb in dl_train:
        xb, yb = xb.to(device), yb.to(device)
        perte = critere(modele(xb), yb)
        optimiseur.zero_grad(); perte.backward(); optimiseur.step()
    modele.eval(); justes = total = 0
    with torch.no_grad():
        for xb, yb in dl_valid:
            pred = modele(xb.to(device)).argmax(1).cpu()
            justes += (pred == yb).sum().item(); total += len(yb)
    print(f"époque {epoque + 1} : exactitude valid {justes / total:.1%}")
torch.save(modele.state_dict(), "resnet18_feuilles.pt")
```

Points clés : ResNet-18 compte environ 11,7 millions de paramètres, mais seuls les $512 \times 4 + 4 = 2\,052$ paramètres de la nouvelle tête sont entraînés ici, ce qui tient sur un CPU. La normalisation doit être **celle du pré-entraînement** (moyennes et écarts types d'ImageNet). Pour passer ensuite à un ajustement fin partiel, dégelez `modele.layer4` et ajoutez ses paramètres à l'optimiseur avec un taux dix fois plus petit.

> 🔗 **Documentation officielle** — [torchvision : Models and pre-trained weights](https://pytorch.org/vision/stable/models.html) liste les architectures disponibles, leurs poids et leurs scores ; le [tutoriel officiel de transfert](https://pytorch.org/tutorials/beginner/transfer_learning_tutorial.html) détaille les deux stratégies. Vérifiez la **licence des poids** avant tout usage commercial.

### 5.1 Le lien avec le projet 42 Leaffliction

Le projet *Leaffliction* de la branche IA de 42 porte exactement sur ce cas : classer des maladies de feuilles. D'après les dépôts d'étudiants publics (le sujet officiel est sur l'intranet), il enchaîne quatre programmes : `Distribution` (analyse de la répartition des classes), `Augmentation` (retournement, rotation, inclinaison, cisaillement, recadrage, distorsion), `Transformation` (traitements d'image avec PlantCV : flou, masque, région d'intérêt, pseudo-repères, histogrammes) et `Classification` (entraînement et prédiction), avec un objectif de plus de 90 % d'exactitude sur au moins 100 images de validation. Le script `transfert.py` ci-dessus est une base solide pour la partie `Classification` ; l'analyse de la distribution est indispensable, car les classes y sont déséquilibrées.

> ⚠️ **Piège fréquent** — Appliquer l'augmentation aux images de validation, ou générer des images augmentées **avant** la séparation train/validation : des quasi-copies d'une même feuille se retrouvent des deux côtés, et l'exactitude de validation devient trompeuse. Séparez d'abord, augmentez ensuite le train seulement.

## 🧪 Exercice pratique

**Consigne.** Sur **CIFAR-10** (`torchvision.datasets.CIFAR10` : 50 000 images d'entraînement et 10 000 de test, en couleur, 32 × 32, 10 classes) :
1. Entraînez le MLP de L123 adapté à $3 \times 32 \times 32$ entrées pendant 10 époques ; notez l'exactitude de test.
2. Entraînez un CNN à trois étages `Conv-BN-ReLU-Conv-BN-ReLU-MaxPool` (32, 64 puis 128 canaux) avec `RandomCrop(32, padding=4)` et `RandomHorizontalFlip()` sur le train.
3. Remplissez un tableau : paramètres, temps par époque, exactitude de test, pour les deux modèles.

**Critères de réussite.** Le CNN dépasse le MLP d'au moins 15 points (attendu : environ 50-55 % pour le MLP, plus de 75 % pour le CNN) ; la forme de chaque couche est justifiée par la formule de la section 2.2 ; l'augmentation n'est appliquée qu'au train.

<details><summary>Pistes de correction</summary>

- Normalisation CIFAR-10 usuelle : moyenne `(0.4914, 0.4822, 0.4465)`, écart type `(0.2470, 0.2435, 0.2616)`.
- Après trois MaxPool, $32 \to 16 \to 8 \to 4$ : la couche dense reçoit $128 \times 4 \times 4 = 2\,048$ entrées.
- Si le CNN plafonne vers 65 %, vérifiez que `modele.train()` est bien rappelé au début de chaque époque après l'évaluation (sinon la normalisation par lot reste figée).
</details>

## 🎮 Défi

Une entrée $3 \times 224 \times 224$ passe dans `Conv2d(3, 64, kernel_size=7, stride=2, padding=3)`. Quelle est la forme de sortie et combien de paramètres ? Réponse : $\lfloor (224 + 6 - 7)/2 \rfloor + 1 = 112$, donc $64 \times 112 \times 112$, et $64 \times (3 \cdot 49 + 1) = 9\,472$ paramètres. C'est la première couche de ResNet (sans biais dans torchvision, d'où 9 408).

## ✅ Auto-évaluation express

1. Quelles sont les deux propriétés des images exploitées par la convolution ?
2. Combien de paramètres possède `Conv2d(64, 128, kernel_size=3)` ?
3. Pourquoi les connexions résiduelles facilitent-elles l'entraînement des réseaux très profonds ?

**Réponses.** 1. La localité des motifs et l'invariance par translation (d'où des connexions locales et des poids partagés). 2. $128 \times (64 \times 9 + 1) = 73\,856$. 3. Parce que l'addition $F(x) + x$ transmet le gradient intact vers les couches précédentes : le signal n'est plus obligé de traverser toutes les transformations.

## 📚 Pour aller plus loin
- [MIT 6.S191 Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 — séance 3, « Deep Computer Vision » (CNN, détection, segmentation), et Lab 2 sur la détection de visages et les biais.
- [Stanford CS231n — programme Spring 2026](https://cs231n.stanford.edu/schedule.html) 🇬🇧 — séances 5 (CNN) et 6 (BatchNorm, transfert, AlexNet, VGG, ResNet).
- [Deep Residual Learning for Image Recognition](https://arxiv.org/abs/1512.03385) 🇬🇧 — l'article fondateur de ResNet (He et al., 2015).
- [torchvision — Models and pre-trained weights](https://pytorch.org/vision/stable/models.html) 🇬🇧 — architectures, poids, métriques et prétraitements associés.
- [fast.ai — Practical Deep Learning for Coders](https://course.fast.ai/) 🇬🇧 — leçon 8 (convolutions) et l'approche « transfert d'abord » de Jeremy Howard.
- [Dépôt public Leaffliction](https://github.com/jainavas/leaffliction) 🇬🇧 — un exemple de rendu du projet 42 de vision.
