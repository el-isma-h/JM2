---
id: L121
module: M26
level: N4
title: "Perceptron et réseaux multicouches (projet 42 multilayer-perceptron)"
minutes: 65
objectives:
  - "Expliquer le fonctionnement du perceptron de Rosenblatt et démontrer sur XOR la limite d'un classifieur linéaire"
  - "Écrire la passe avant d'un réseau multicouche (MLP) en notation matricielle par lots et choisir une fonction d'activation adaptée"
  - "Dériver le couple softmax + entropie croisée et l'implémenter de façon numériquement stable"
  - "Construire from scratch en NumPy un MLP conforme aux contraintes du projet 42 multilayer-perceptron (séparation, entraînement, prédiction, courbes, sauvegarde)"
skills: ["C4.3", "C4.1"]
sources:
  - { title: "MIT 6.S191 Introduction to Deep Learning (2026) — Lecture 1", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "École 42 — multilayer-perceptron (dépôt étudiant public)", url: "https://github.com/agiordan101/multilayer_perceptron_42", lang: "en" }
  - { title: "École 42 — branche Algo, AI, data (liste des projets)", url: "https://github.com/jmcheon/42cursus", lang: "en" }
  - { title: "3Blue1Brown — Neural Networks, chapitre 1", url: "https://www.3blue1brown.com/topics/neural-networks", lang: "en" }
  - { title: "scikit-learn — load_breast_cancer", url: "https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_breast_cancer.html", lang: "en" }
  - { title: "NumPy documentation", url: "https://numpy.org/doc/stable/", lang: "en" }
---

# Perceptron et réseaux multicouches (projet 42 multilayer-perceptron)

> ⏱ 65 min · 🎯 Niveau 4 · 📚 Module 26

## 🎯 Ce que vous saurez faire
- Entraîner un perceptron à la main et expliquer pourquoi il échoue sur le « OU exclusif » (XOR).
- Écrire la passe avant d'un réseau multicouche (*multilayer perceptron*, MLP) pour un lot d'exemples, avec les bonnes dimensions à chaque couche.
- Choisir une fonction d'activation et justifier ce choix.
- Implémenter softmax et l'entropie croisée sans débordement numérique, et retrouver leur gradient $P - Y$.
- Livrer un MLP NumPy qui respecte l'esprit du projet 42 *multilayer-perceptron* : trois programmes, au moins deux couches cachées, sortie softmax, courbes d'apprentissage et modèle sauvegardé.

Ce module s'inspire du cours **MIT 6.S191 « Introduction to Deep Learning »** (édition 2026, Alexander et Ava Amini) : sa première séance part du perceptron pour arriver à la rétropropagation, et c'est le chemin que nous suivons. Nous reprenons les notations de M24 : lots d'exemples **rangés en lignes** $X \in \mathbb{R}^{B \times n}$, signal d'erreur $\delta$ (ou $\Delta$ pour un lot), taux d'apprentissage $\eta$.

## 1. Le perceptron : un neurone qui vote

### 1.1 Un peu d'histoire (exacte)

En 1943, Warren McCulloch et Walter Pitts proposent un modèle logique du neurone : il additionne des signaux et « s'allume » au-delà d'un seuil. En 1958, le psychologue **Frank Rosenblatt** ajoute ce qui manquait : une **règle d'apprentissage**. Son perceptron, d'abord simulé sur un IBM 704 puis construit en matériel (le *Mark I Perceptron*, au Cornell Aeronautical Laboratory), apprend à reconnaître des formes simples. En 1969, Marvin Minsky et Seymour Papert publient *Perceptrons*, où ils démontrent rigoureusement qu'un perceptron à une couche ne peut pas représenter certaines fonctions, dont XOR. Le livre refroidit durablement le financement de la recherche sur les réseaux de neurones. Il faudra attendre 1986 et l'article de Rumelhart, Hinton et Williams sur la **rétropropagation** pour que les réseaux multicouches deviennent entraînables en pratique.

### 1.2 Le modèle

Pour un vecteur d'entrée $x \in \mathbb{R}^n$, le perceptron calcule un score puis un vote :

$$\hat y = \operatorname{signe}(w^\top x + b) \in \{-1, +1\}$$

Géométriquement, $w^\top x + b = 0$ est un **hyperplan** (une droite en 2D) : tout ce qui est d'un côté vote $+1$, le reste $-1$. Analogie : un comité de recrutement où chaque critère du CV ($x_i$) reçoit un poids ($w_i$) ; on additionne, on compare à une barre ($-b$), on dit oui ou non.

La règle d'apprentissage de Rosenblatt est d'une simplicité désarmante : on parcourt les exemples ; si l'exemple $(x, y)$ est mal classé, c'est-à-dire si $y\,(w^\top x + b) \le 0$, on corrige

$$w \leftarrow w + \eta\, y\, x, \qquad b \leftarrow b + \eta\, y$$

et on ne touche à rien sinon. Le **théorème de convergence du perceptron** garantit que, si les données sont **linéairement séparables**, l'algorithme s'arrête après un nombre fini de corrections.

```python
import numpy as np

def entrainer_perceptron(X, y, epoques=20, eta=1.0):
    """Règle de Rosenblatt : on ne corrige que les exemples mal classés."""
    w, b = np.zeros(X.shape[1]), 0.0
    for _ in range(epoques):
        erreurs = 0
        for xi, yi in zip(X, y):                 # yi vaut -1 ou +1
            if yi * (xi @ w + b) <= 0:           # mal classé (ou sur la frontière)
                w += eta * yi * xi
                b += eta * yi
                erreurs += 1
        if erreurs == 0:                         # convergence : tout est bien classé
            break
    return w, b, erreurs

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
for nom, y in {"ET": [-1, -1, -1, 1], "OU": [-1, 1, 1, 1], "XOR": [-1, 1, 1, -1]}.items():
    w, b, err = entrainer_perceptron(X, np.array(y))
    print(f"{nom:>3} : w={w}, b={b:+.0f}, erreurs à la dernière époque = {err}")
```

Sortie obtenue : ET converge (`w=[3. 2.], b=-4`), OU aussi (`w=[2. 2.], b=-1`), mais XOR finit avec **4 erreurs sur 4** : les poids oscillent sans jamais se stabiliser. Dessinez les quatre points : $(0,1)$ et $(1,0)$ d'un côté, $(0,0)$ et $(1,1)$ de l'autre. Aucune droite ne les sépare.

> 💡 **À retenir** — Un perceptron (comme une régression logistique) trace **une seule frontière linéaire**. Toute la suite du deep learning consiste à apprendre une **représentation** des données dans laquelle les classes deviennent séparables linéairement par la dernière couche.

## 2. Empiler des couches : le réseau multicouche

### 2.1 Résoudre XOR avec deux neurones cachés

Remarquez que $\text{XOR}(x_1, x_2) = \text{OU}(x_1, x_2)\ \text{ET NON}\ \text{ET}(x_1, x_2)$. Un premier neurone calcule le OU, un second le ET, un troisième combine les deux. En choisissant la fonction ReLU, $\text{ReLU}(z) = \max(0, z)$, une solution exacte est :

$$h_1 = \text{ReLU}(x_1 + x_2), \quad h_2 = \text{ReLU}(x_1 + x_2 - 1), \quad \hat y = h_1 - 2h_2$$

Vérifiez : $(0,0) \mapsto 0$ ; $(1,0) \mapsto 1$ ; $(0,1) \mapsto 1$ ; $(1,1) \mapsto 2 - 2 = 0$. La couche cachée a **plié l'espace** : dans le plan $(h_1, h_2)$, les quatre points deviennent séparables par une droite.

### 2.2 La passe avant en notation matricielle

Un MLP à $L$ couches transforme un lot $A^{[0]} = X \in \mathbb{R}^{B \times n_0}$ couche après couche :

$$Z^{[l]} = A^{[l-1]}\,W^{[l]} + b^{[l]}, \qquad A^{[l]} = g^{[l]}\!\left(Z^{[l]}\right), \qquad l = 1, \dots, L$$

avec $W^{[l]} \in \mathbb{R}^{n_{l-1} \times n_l}$, $b^{[l]} \in \mathbb{R}^{n_l}$ (diffusé sur les $B$ lignes) et $g^{[l]}$ une fonction d'activation appliquée élément par élément. C'est la convention du code NumPy de M24 L112 ; `nn.Linear` de PyTorch stocke la transposée et écrit $XW^\top + b$ (vous la retrouverez en L123).

Exemple de dimensions pour le projet de cette leçon, 30 variables, deux couches cachées de 24 neurones, 2 sorties :

| Couche | Forme de $W$ | Paramètres | Forme de $A$ (lot de 16) |
|---|---|---|---|
| entrée | — | — | $16 \times 30$ |
| cachée 1 (ReLU) | $30 \times 24$ | $30 \cdot 24 + 24 = 744$ | $16 \times 24$ |
| cachée 2 (ReLU) | $24 \times 24$ | $600$ | $16 \times 24$ |
| sortie (softmax) | $24 \times 2$ | $50$ | $16 \times 2$ |
| **total** | | **1 394** | |

### 2.3 Pourquoi la non-linéarité est indispensable

Sans $g$, deux couches donnent $X W^{[1]} W^{[2]} + \dots$, soit encore une fonction affine : empiler cent couches linéaires ne sert à rien. C'est l'activation qui permet de plier l'espace. Le **théorème d'approximation universelle** (Cybenko 1989 pour la sigmoïde, Hornik 1991 plus généralement) affirme qu'une seule couche cachée suffisamment large peut approcher n'importe quelle fonction continue sur un compact. Attention à ce qu'il ne dit pas : il ne dit ni combien de neurones il faut, ni que la descente de gradient les trouvera. En pratique, **la profondeur** est bien plus économe que la largeur, d'où le « deep » de deep learning.

## 3. Les fonctions d'activation

| Activation | Formule | Dérivée | Avantages | Inconvénients | Usage 2026 |
|---|---|---|---|---|---|
| Sigmoïde $\sigma$ | $1/(1+e^{-z})$ | $\sigma(1-\sigma)$, max 0,25 | sortie dans $]0,1[$ | sature, gradient qui s'évanouit | sortie binaire, portes LSTM |
| tanh | $(e^z - e^{-z})/(e^z + e^{-z})$ | $1 - \tanh^2$ | centrée en 0 | sature aussi | RNN classiques |
| ReLU | $\max(0, z)$ | 1 si $z>0$, 0 sinon | rapide, ne sature pas à droite | neurones « morts » si $z<0$ toujours | CNN, MLP par défaut |
| Leaky ReLU | $\max(0{,}01z, z)$ | 0,01 ou 1 | pas de neurone mort | un hyperparamètre de plus | variante robuste |
| GELU | $z\,\Phi(z)$ ($\Phi$ = répartition gaussienne) | lisse | lisse autour de 0 | un peu plus coûteuse | Transformers (BERT, GPT) |
| SiLU / Swish | $z\,\sigma(z)$ | lisse | idem | idem | LLM récents (dans SwiGLU) |

> ⚠️ **Piège fréquent** — Mettre une sigmoïde dans les couches cachées d'un réseau profond « parce que c'est la fonction du cours ». Sa dérivée ne dépasse pas 0,25 : à travers dix couches, le gradient est divisé par au moins un million (M24 L112). Par défaut : **ReLU** (ou GELU) dans les couches cachées, et l'activation de sortie dictée par la tâche.

| Tâche | Sortie | Perte |
|---|---|---|
| Régression (prix d'un véhicule) | linéaire (aucune activation) | MSE |
| Binaire (fraude oui/non) | 1 sigmoïde **ou** 2 softmax | BCE / entropie croisée |
| Multiclasse exclusive (catégorie de produit) | $K$ softmax | entropie croisée |
| Multi-étiquettes (tags d'un article) | $K$ sigmoïdes indépendantes | BCE par étiquette |

## 4. Softmax et entropie croisée

### 4.1 Définitions

Pour un vecteur de scores (*logits*) $z \in \mathbb{R}^K$, la fonction **softmax** fabrique une distribution de probabilité :

$$p_k = \operatorname{softmax}(z)_k = \frac{e^{z_k}}{\sum_{j=1}^{K} e^{z_j}}, \qquad p_k > 0,\ \sum_k p_k = 1$$

Elle porte mal son nom : c'est un « argmax adouci ». Si l'on multiplie tous les scores par 10, la distribution se concentre sur le plus grand ; si on les divise par 10, elle s'aplatit. C'est exactement le rôle de la **température** des LLM (vue au niveau 1), qui divise les logits avant la softmax.

L'**entropie croisée** pour une cible codée en *one-hot* $y$ (un 1 à la bonne classe $c$, des 0 ailleurs) vaut

$$\mathcal{L} = -\sum_{k} y_k \log p_k = -\log p_c$$

C'est la log-vraisemblance négative de la loi catégorielle (M24 L113). Pour $K = 2$, elle se réduit à l'**entropie croisée binaire** (BCE) : $-[y \log p + (1-y)\log(1-p)]$.

### 4.2 Le gradient le plus élégant du deep learning

En dérivant $\mathcal{L} = -z_c + \log \sum_j e^{z_j}$ par rapport à $z_k$, on obtient $-y_k + p_k$. Pour un lot de $B$ exemples avec la perte moyenne :

$$\frac{\partial \mathcal{L}}{\partial Z^{[L]}} = \frac{1}{B}\,(P - Y)$$

Toute la complexité de l'exponentielle et du logarithme disparaît : le signal d'erreur est **la différence entre ce qu'on prédit et ce qu'on voulait**. C'est pour cela que les frameworks fusionnent les deux opérations (`nn.CrossEntropyLoss` de PyTorch prend directement des logits).

### 4.3 La stabilité numérique

$e^{1000}$ déborde en `float64` et renvoie `inf`. Or softmax est invariante par translation : $\operatorname{softmax}(z) = \operatorname{softmax}(z - c)$ pour toute constante $c$. On soustrait donc le maximum avant l'exponentielle, ce qui garantit des exposants $\le 0$. Côté perte, on évite $\log 0$ en ajoutant un petit $\varepsilon$ ou, mieux, en calculant directement $\log p_c = z_c - \operatorname{logsumexp}(z)$.

> 💡 **À retenir** — Softmax + entropie croisée = gradient $P - Y$. Soustrayez toujours le maximum des logits. Ne passez jamais des probabilités à une fonction de perte qui attend des logits (bug classique en PyTorch).

## 5. Le projet 42 multilayer-perceptron

Le projet *multilayer-perceptron* fait partie de la branche « Algo, AI, data » du cursus 42, après ft_linear_regression et DSLR (vus en M25). Le sujet officiel est diffusé sur l'intranet de l'école et n'est pas public : ce qui suit est reconstitué à partir de dépôts d'étudiants publics. **Vérifiez la version en vigueur sur l'intranet avant de rendre votre projet.**

| Élément | Ce que l'on retrouve dans les dépôts publics |
|---|---|
| Données | Wisconsin Diagnostic Breast Cancer : 569 tumeurs, un identifiant, un diagnostic (M = maligne, B = bénigne) et 30 variables numériques (moyenne, erreur type et « pire » valeur de 10 caractéristiques des noyaux cellulaires) |
| Objectif | Classer chaque tumeur en maligne ou bénigne avec un MLP **écrit from scratch** (pas de framework qui calcule les gradients à votre place) |
| Programmes | un programme de **séparation** (train / validation), un programme d'**entraînement**, un programme de **prédiction** |
| Architecture | au moins deux couches cachées, sortie **softmax** |
| Évaluation | entropie croisée binaire sur le jeu de validation |
| Suivi | affichage des métriques à chaque époque et **courbes d'apprentissage** (perte et exactitude, entraînement et validation) |
| Persistance | sauvegarde du modèle (topologie et poids) réutilisée par le programme de prédiction |
| Bonus fréquents | arrêt anticipé (*early stopping*), optimiseurs avancés (momentum, RMSprop, Adam), métriques supplémentaires, comparaison de plusieurs courbes |

> 🔗 **Documentation officielle** — Le même jeu de données est fourni par [scikit-learn (`load_breast_cancer`)](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_breast_cancer.html), ce qui permet de s'exercer sans le fichier de l'école. Attention : scikit-learn code 0 = maligne et 1 = bénigne.

## 6. Le code complet : un MLP NumPy de bout en bout

Le script ci-dessous tient en un fichier pour la lecture ; l'exercice vous demandera de le découper en trois programmes. Il réunit tout ce qui précède : standardisation calculée **sur l'entraînement seulement**, initialisation de He (justifiée en L126), ReLU, softmax stable, gradient $P - Y$, mini-lots, arrêt anticipé et sauvegarde.

```python
"""MLP from scratch en NumPy, dans l'esprit du projet 42 multilayer-perceptron.
Données : Wisconsin Diagnostic Breast Cancer (569 tumeurs, 30 variables).
Exécution : python mlp_numpy.py  (Python 3.12, numpy, scikit-learn pour charger les données)"""
import numpy as np
from sklearn.datasets import load_breast_cancer   # uniquement pour lire les données

rng = np.random.default_rng(42)

# ---------- 1. Données : séparation train / validation, standardisation ----------
X, y = load_breast_cancer(return_X_y=True)        # y : 0 = malin, 1 = bénin
idx = rng.permutation(len(X))
n_val = int(0.2 * len(X))
val, tr = idx[:n_val], idx[n_val:]
mu, sd = X[tr].mean(0), X[tr].std(0)               # statistiques du TRAIN uniquement
Xtr, Xva = (X[tr] - mu) / sd, (X[val] - mu) / sd
ytr, yva = y[tr], y[val]
Ytr = np.eye(2)[ytr]                                # one-hot : 2 sorties softmax

# ---------- 2. Briques ----------
def relu(z):
    return np.maximum(0.0, z)

def softmax(z):
    z = z - z.max(axis=1, keepdims=True)            # stabilité numérique
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)

def bce(p1, y, eps=1e-12):
    """Entropie croisée binaire, la métrique d'évaluation demandée par le sujet 42."""
    p1 = np.clip(p1, eps, 1 - eps)
    return -np.mean(y * np.log(p1) + (1 - y) * np.log(1 - p1))

class MLP:
    def __init__(self, tailles):                    # ex. [30, 24, 24, 2]
        self.W = [rng.normal(0, np.sqrt(2 / n_in), (n_in, n_out))   # init de He
                  for n_in, n_out in zip(tailles[:-1], tailles[1:])]
        self.b = [np.zeros(n_out) for n_out in tailles[1:]]

    def forward(self, X):
        self.A, self.Z = [X], []
        for l, (W, b) in enumerate(zip(self.W, self.b)):
            Z = self.A[-1] @ W + b                  # (B, n_l)
            self.Z.append(Z)
            dernier = l == len(self.W) - 1
            self.A.append(softmax(Z) if dernier else relu(Z))
        return self.A[-1]

    def backward(self, Y, eta):
        B = len(Y)
        dZ = (self.A[-1] - Y) / B                   # softmax + entropie croisée : P - Y
        for l in reversed(range(len(self.W))):
            dW = self.A[l].T @ dZ
            db = dZ.sum(0)
            if l > 0:                               # l'erreur redescend à travers Wᵀ
                dZ = (dZ @ self.W[l].T) * (self.Z[l - 1] > 0)
            self.W[l] -= eta * dW
            self.b[l] -= eta * db

# ---------- 3. Entraînement par mini-batchs avec arrêt anticipé ----------
modele = MLP([30, 24, 24, 2])
eta, taille_lot, patience = 0.05, 16, 15
meilleur, attente, historique = np.inf, 0, []
for epoque in range(1, 301):
    ordre = rng.permutation(len(Xtr))
    for i in range(0, len(ordre), taille_lot):
        lot = ordre[i:i + taille_lot]
        modele.forward(Xtr[lot])
        modele.backward(Ytr[lot], eta)
    Ptr, Pva = modele.forward(Xtr), modele.forward(Xva)
    l_tr, l_va = bce(Ptr[:, 1], ytr), bce(Pva[:, 1], yva)
    acc_va = np.mean(Pva.argmax(1) == yva)
    historique.append((l_tr, l_va, acc_va))
    if epoque % 10 == 0 or epoque == 1:
        print(f"epoch {epoque:03d}/300 - loss: {l_tr:.4f} - val_loss: {l_va:.4f} - val_acc: {acc_va:.3f}")
    if l_va < meilleur - 1e-4:
        meilleur, attente = l_va, 0
        sauvegarde = ([W.copy() for W in modele.W], [b.copy() for b in modele.b])
    else:
        attente += 1
        if attente >= patience:
            print(f"Arrêt anticipé à l'époque {epoque} (meilleure val_loss = {meilleur:.4f})")
            break

# ---------- 4. Sauvegarde : topologie + poids + normalisation ----------
modele.W, modele.b = sauvegarde
np.savez("modele_mlp.npz", mu=mu, sd=sd,
         **{f"W{l}": W for l, W in enumerate(modele.W)},
         **{f"b{l}": b for l, b in enumerate(modele.b)})
Pva = modele.forward(Xva)
print(f"Validation finale : BCE = {bce(Pva[:, 1], yva):.4f}, exactitude = {np.mean(Pva.argmax(1) == yva):.3f}")
```

Résultat obtenu avec la graine 42 (CPU, moins d'une seconde) : la perte de validation atteint son minimum vers l'époque 28, l'arrêt anticipé se déclenche à l'époque 43, et l'on termine avec une **BCE de validation ≈ 0,107** et une **exactitude ≈ 95,6 %**. Remarquez que la perte d'entraînement continue de baisser (0,01) pendant que celle de validation remonte : c'est le sur-apprentissage (M25 L116) en direct, et c'est précisément ce que l'arrêt anticipé intercepte.

Trois détails qui distinguent un rendu solide d'un rendu fragile :

1. **La normalisation fait partie du modèle.** `mu` et `sd` sont sauvegardés avec les poids : le programme de prédiction doit appliquer exactement la même transformation.
2. **On garde les meilleurs poids**, pas les derniers : `sauvegarde` est mise à jour à chaque amélioration de la validation.
3. **La graine est fixée** (`default_rng(42)`), ce qui rend la séparation et l'entraînement reproductibles, un critère de la compétence C4.3.

> ⚠️ **Piège fréquent** — Standardiser avant de séparer (moyenne et écart type calculés sur les 569 tumeurs) fait fuiter de l'information du jeu de validation vers l'entraînement. L'écart est faible ici, mais c'est la faute de protocole la plus repérée en soutenance.

### 6.1 En contexte professionnel

Remplacez « tumeur » par « dossier de crédit » d'un courtier, « facture » d'un cabinet comptable (anomalie oui/non) ou « pièce » d'un atelier d'usinage (conforme / non conforme) : la structure est identique. Sur des données tabulaires de quelques centaines de lignes, un MLP n'est d'ailleurs **pas** toujours le meilleur choix ; un gradient boosting (M25) fait souvent aussi bien. L'intérêt du projet est pédagogique : c'est la brique de base de tous les réseaux du module.

## 🧪 Exercice pratique

**Consigne.** Découpez le script en trois programmes, comme dans le projet 42 :
1. `separer.py` : lit les données, mélange avec une graine, écrit `train.csv` et `valid.csv` (80/20).
2. `entrainer.py --couches 24 24 --epoques 300 --lr 0.05 --lot 16` : entraîne, affiche à chaque époque `epoch xx/yy - loss - val_loss`, trace les **deux** courbes (perte et exactitude, train et validation) avec matplotlib dans `courbes.png`, sauvegarde `modele.npz` en y incluant la liste des tailles de couches.
3. `predire.py valid.csv` : recharge le modèle, reconstruit le réseau à partir de la topologie sauvegardée et affiche la BCE et l'exactitude.

**Bonus.** Ajoutez le momentum ($v \leftarrow \beta v + \nabla$, $W \leftarrow W - \eta v$, $\beta = 0{,}9$) et comparez les deux courbes de validation sur une même figure.

**Critères de réussite.**
- `predire.py` fonctionne dans un nouveau terminal, sans réentraîner, et donne le même résultat que la fin de `entrainer.py`.
- Exactitude de validation $\ge 95\,\%$ et BCE $\le 0{,}12$.
- Deux exécutions successives avec la même graine donnent exactement les mêmes chiffres.
- Aucun import de PyTorch, TensorFlow ou Keras.

<details><summary>Pistes de correction</summary>

- Sauvegardez `tailles=np.array([30, 24, 24, 2])` dans le `.npz` ; dans `predire.py`, faites `MLP(list(f["tailles"]))` puis réaffectez `W0…Wn` et `b0…bn`.
- Les CSV de 42 n'ont pas d'en-tête : lisez-les avec `np.genfromtxt(..., delimiter=",", dtype=str)`, convertissez `M`/`B` en 1/0 et ignorez la colonne identifiant.
- Pour les courbes, conservez `historique` et tracez deux sous-figures (`plt.subplots(1, 2)`).
- Si l'exactitude plafonne à 63 %, le réseau prédit toujours la classe majoritaire : vérifiez la standardisation et le signe de la mise à jour.
</details>

## 🎮 Défi

Sans ordinateur : combien de paramètres possède un MLP $784 \to 128 \to 64 \to 10$ (le classique de MNIST) ? Réponse : $784 \cdot 128 + 128 + 128 \cdot 64 + 64 + 64 \cdot 10 + 10 = 109\,386$. Vous le retrouverez en une ligne avec PyTorch en L123.

## ✅ Auto-évaluation express

1. Pourquoi un perceptron ne peut-il pas apprendre XOR, alors qu'un MLP à deux neurones cachés le peut ?
2. Que vaut $\partial \mathcal{L} / \partial z$ pour softmax suivie de l'entropie croisée, et pourquoi est-ce pratique ?
3. Pourquoi soustrait-on $\max_k z_k$ avant de calculer la softmax, et cela change-t-il le résultat ?

**Réponses.** 1. XOR n'est pas linéairement séparable ; la couche cachée transforme l'espace (par exemple en OU et ET) pour rendre les classes séparables par la sortie. 2. $p - y$ (divisé par $B$ pour une moyenne sur le lot) : un signal simple, stable, sans dérivée d'exponentielle ou de logarithme à manipuler. 3. Pour éviter le débordement de l'exponentielle ; le résultat est inchangé car softmax est invariante par translation des logits.

## 📚 Pour aller plus loin
- [MIT 6.S191 Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 — séance 1 de l'édition 2026 (perceptron, réseaux denses, pertes, descente de gradient) ; slides et labs sous licence MIT.
- [3Blue1Brown — Neural Networks](https://www.3blue1brown.com/topics/neural-networks) 🇬🇧 — chapitre 1, « But what is a Neural Network? », la meilleure intuition visuelle d'un MLP.
- [Dépôt public multilayer_perceptron_42](https://github.com/agiordan101/multilayer_perceptron_42) 🇬🇧 — un exemple de rendu étudiant (à consulter après avoir écrit votre propre version).
- [Branche « Algo, AI, data » de 42](https://github.com/jmcheon/42cursus) 🇬🇧 — la liste des projets de la branche (ft_linear_regression, DSLR, Leaffliction, multilayer-perceptron…).
- [NumPy documentation](https://numpy.org/doc/stable/) 🇬🇧 — diffusion (*broadcasting*), `keepdims`, générateurs aléatoires.
- [CMU 11-785 Introduction to Deep Learning](https://deeplearning.cs.cmu.edu/S25/index.html) 🇬🇧 — séance 2 : les réseaux comme approximateurs universels.
