---
id: L123
module: M26
level: N4
title: "PyTorch : tenseurs, autograd, boucle d'entraînement"
minutes: 65
objectives:
  - "Manipuler des tenseurs PyTorch (forme, type, appareil, diffusion, pont NumPy) sans erreur de dimension"
  - "Expliquer le fonctionnement de l'autograd de PyTorch (graphe dynamique, accumulation, no_grad, detach) en le reliant au moteur construit en L122"
  - "Construire un modèle avec nn.Module, l'alimenter avec Dataset et DataLoader et écrire une boucle d'entraînement et d'évaluation complète"
  - "Exécuter le même script sur CPU, GPU NVIDIA (CUDA) ou Apple Silicon (MPS) et rendre un entraînement reproductible"
skills: ["C4.3"]
sources:
  - { title: "PyTorch — Learn the Basics", url: "https://pytorch.org/tutorials/beginner/basics/intro.html", lang: "en" }
  - { title: "PyTorch — Datasets & DataLoaders", url: "https://pytorch.org/tutorials/beginner/basics/data_tutorial.html", lang: "en" }
  - { title: "PyTorch — Optimizing Model Parameters", url: "https://pytorch.org/tutorials/beginner/basics/optimization_tutorial.html", lang: "en" }
  - { title: "PyTorch — MPS backend", url: "https://pytorch.org/docs/stable/notes/mps.html", lang: "en" }
  - { title: "PyTorch — Reproducibility", url: "https://pytorch.org/docs/stable/notes/randomness.html", lang: "en" }
  - { title: "torchvision — Datasets", url: "https://pytorch.org/vision/stable/datasets.html", lang: "en" }
  - { title: "MIT 6.S191 (2026) — Lab 1 : Deep Learning in Python", url: "https://introtodeeplearning.com/", lang: "en" }
---

# PyTorch : tenseurs, autograd, boucle d'entraînement

> ⏱ 65 min · 🎯 Niveau 4 · 📚 Module 26

## 🎯 Ce que vous saurez faire
- Créer, transformer et déplacer des tenseurs en maîtrisant leur forme (*shape*), leur type (*dtype*) et leur appareil (*device*).
- Lire un message d'erreur de dimension et le corriger en moins d'une minute.
- Relier chaque mécanisme de l'autograd de PyTorch à votre moteur de L122.
- Écrire de mémoire la boucle d'entraînement en cinq gestes, et la boucle d'évaluation qui l'accompagne.
- Lancer le même script sur un portable, un serveur GPU NVIDIA ou un Mac Apple Silicon.

PyTorch est né en 2016 chez Facebook AI Research (aujourd'hui Meta) ; il est hébergé depuis 2022 par la **PyTorch Foundation**, sous l'égide de la Linux Foundation. C'est le framework des cours de référence de ce niveau (CS231n, CS224N, CS336, fast.ai) et du premier lab de MIT 6.S191, qui propose PyTorch et TensorFlow. Pour la version et la commande d'installation exactes (nov. 2026), fiez-vous au sélecteur officiel [pytorch.org/get-started/locally](https://pytorch.org/get-started/locally/) : il dépend de votre système et de votre carte graphique.

```bash
python3.12 -m venv .venv && source .venv/bin/activate
pip install torch torchvision numpy scikit-learn matplotlib
python -c "import torch; print(torch.__version__, torch.cuda.is_available(), torch.backends.mps.is_available())"
```

## 1. Les tenseurs : des tableaux NumPy qui savent voyager

Un tenseur est un tableau multidimensionnel, comme un `ndarray` NumPy, avec deux super-pouvoirs : il peut vivre sur un **accélérateur** (GPU, Apple MPS) et il peut **mémoriser son graphe de calcul** pour l'autograd.

```python
import numpy as np
import torch

# Création
a = torch.tensor([[1.0, 2.0], [3.0, 4.0]])          # depuis une liste
z = torch.zeros(2, 3)                                # remplis de zéros
r = torch.randn(4, 3, generator=torch.Generator().manual_seed(0))  # loi normale
print(a.shape, a.dtype, a.device)                    # torch.Size([2, 2]) torch.float32 cpu

# Types : float32 par défaut ; les étiquettes de classes sont des entiers int64
y = torch.tensor([3, 0, 1])
print(y.dtype)                                       # torch.int64

# Formes : view (sans copie, mémoire contiguë) et reshape (copie si nécessaire)
x = torch.arange(12)
print(x.view(3, 4).shape, x.reshape(2, -1).shape)    # -1 : « déduis cette dimension »
img = torch.randn(28, 28)
print(img.unsqueeze(0).shape)                        # ajoute un axe : (1, 28, 28)
print(img.flatten().shape)                           # (784,)

# Diffusion (broadcasting) : mêmes règles que NumPy
lot = torch.randn(64, 10)
biais = torch.randn(10)
print((lot + biais).shape)                           # (64, 10)

# Pont NumPy : la mémoire est PARTAGÉE sur CPU
n = np.ones(3)
t = torch.from_numpy(n)
n[0] = 42
print(t)                                             # tensor([42., 1., 1.], dtype=torch.float64)

# Réductions et indexation avancée
scores = torch.tensor([[0.1, 2.0, -1.0], [1.5, 0.2, 0.3]])
print(scores.argmax(dim=1))                          # tensor([1, 0]) : classe prédite par ligne
print(scores[torch.arange(2), torch.tensor([1, 0])]) # score de la bonne classe : tensor([2.0, 1.5])
```

| Besoin | NumPy | PyTorch |
|---|---|---|
| Produit matriciel | `A @ B` | `A @ B` ou `torch.matmul` |
| Axe de réduction | `axis=1` | `dim=1` |
| Changer de forme | `reshape` | `view` (sans copie) ou `reshape` |
| Ajouter un axe | `x[None]` / `np.expand_dims` | `x.unsqueeze(0)` |
| Vers un scalaire Python | `float(x)` | `x.item()` |
| Vers NumPy | — | `x.detach().cpu().numpy()` |

> ⚠️ **Piège fréquent** — Mélanger `float64` et `float32`. NumPy crée du `float64` par défaut ; PyTorch attend du `float32` pour les poids. `torch.from_numpy(X)` sur des données NumPy produit donc un tenseur `float64`, et la première couche lève `RuntimeError: mat1 and mat2 must have the same dtype`. Réflexe : `torch.from_numpy(X).float()`. Sur Apple MPS, `float64` n'est d'ailleurs pas pris en charge.

## 2. L'autograd de PyTorch, vu depuis votre moteur

Tout ce que vous avez codé en L122 existe dans PyTorch, avec un autre nom :

| Votre moteur (L122) | PyTorch | Rôle |
|---|---|---|
| `Valeur(…)` paramètre | `torch.tensor(…, requires_grad=True)` ou `nn.Parameter` | feuille du graphe dont on veut le gradient |
| `_parents`, `_retour` | `x.grad_fn` (et sa chaîne `next_functions`) | nœud du graphe et sa dérivée locale |
| `L.backward()` | `loss.backward()` | parcours topologique inverse |
| `p.grad = 0.0` | `optimizer.zero_grad()` | remise à zéro (les gradients s'**accumulent**) |
| `p.data -= eta * p.grad` | `optimizer.step()` | mise à jour des paramètres |
| — | `with torch.no_grad():` | ne pas construire de graphe (évaluation) |
| — | `x.detach()` | couper le graphe à cet endroit |

```python
import torch

a = torch.tensor(1.5, requires_grad=True)
b = torch.tensor(-2.0, requires_grad=True)
c = torch.tensor(5.0, requires_grad=True)
f = torch.tensor(-3.0, requires_grad=True)
L = (a * b + c) * f                     # le graphe de L122, section 2
print(L.grad_fn)                        # <MulBackward0 …> : le dernier nœud
L.backward()
print(a.grad, b.grad, c.grad, f.grad)   # tensor(6.) tensor(-4.5000) tensor(-3.) tensor(2.)

# Les gradients s'accumulent : un second backward ajoute aux valeurs existantes
L = (a * b + c) * f
L.backward()
print(a.grad)                           # tensor(12.) et non 6 : d'où zero_grad()

# En évaluation, pas de graphe : plus rapide, moins de mémoire
with torch.no_grad():
    sortie = a * b
print(sortie.requires_grad)             # False
```

Le graphe de PyTorch est **dynamique** (*define-by-run*) : il est reconstruit à chaque passe avant, en suivant le code Python réellement exécuté. Un `if` ou une boucle de longueur variable dans `forward` ne pose donc aucun problème, contrairement aux graphes statiques des premières versions de TensorFlow. Après `backward()`, le graphe est libéré.

> 💡 **À retenir** — `backward()` remplit `.grad` des feuilles ; il ne met **rien** à jour. C'est `optimizer.step()` qui modifie les poids, et `optimizer.zero_grad()` qui efface les gradients avant le lot suivant.

## 3. Construire un modèle avec `nn.Module`

`nn.Module` est l'équivalent professionnel de vos classes `Neurone`, `Couche` et `MLP` : il enregistre automatiquement les paramètres de ses sous-modules et sait les déplacer, les sauvegarder et les basculer en mode entraînement ou évaluation.

```python
import torch
from torch import nn

class MLP(nn.Module):
    def __init__(self, n_entrees=784, n_cachees=(128, 64), n_classes=10):
        super().__init__()
        couches, dim = [nn.Flatten()], n_entrees      # (B, 1, 28, 28) -> (B, 784)
        for h in n_cachees:
            couches += [nn.Linear(dim, h), nn.ReLU()]
            dim = h
        couches.append(nn.Linear(dim, n_classes))     # logits : PAS de softmax ici
        self.reseau = nn.Sequential(*couches)

    def forward(self, x):
        return self.reseau(x)

modele = MLP()
print(modele)
print("paramètres :", sum(p.numel() for p in modele.parameters()))   # 109386 (défi de L121)
print(modele(torch.randn(32, 1, 28, 28)).shape)                       # torch.Size([32, 10])
```

Trois remarques :

1. `nn.Linear(n, m)` stocke un poids de forme $(m, n)$ et calcule $XW^\top + b$ : c'est la convention annoncée en M24 L111.
2. La dernière couche renvoie des **logits**. `nn.CrossEntropyLoss` applique elle-même la log-softmax, de façon stable (L121, section 4).
3. `modele.train()` et `modele.eval()` changent le comportement de certaines couches (dropout, normalisation par lot, vus en L126). Oublier `eval()` au moment de mesurer donne des scores faux et non reproductibles.

## 4. Les données : `Dataset` et `DataLoader`

Un `Dataset` répond à deux questions : combien d'exemples (`__len__`) et quel est l'exemple numéro `i` (`__getitem__`). Un `DataLoader` les assemble en **lots**, les mélange à chaque époque et peut paralléliser le chargement.

```python
import torch
from torch.utils.data import Dataset, DataLoader

class TableauDataset(Dataset):
    """Données tabulaires en mémoire (par ex. le jeu de L121)."""
    def __init__(self, X, y):
        self.X = torch.as_tensor(X, dtype=torch.float32)
        self.y = torch.as_tensor(y, dtype=torch.long)
    def __len__(self):
        return len(self.X)
    def __getitem__(self, i):
        return self.X[i], self.y[i]

ds = TableauDataset(torch.randn(100, 30), torch.randint(0, 2, (100,)))
dl = DataLoader(ds, batch_size=16, shuffle=True)
xb, yb = next(iter(dl))
print(xb.shape, yb.shape)          # torch.Size([16, 30]) torch.Size([16])
```

Pour les images, `torchvision.datasets` fournit des jeux prêts à l'emploi (MNIST, Fashion-MNIST, CIFAR-10, etc.) que l'on télécharge une fois. **Fashion-MNIST**, publié par Zalando Research en 2017, contient 60 000 images d'entraînement et 10 000 de test, en niveaux de gris 28 × 28, réparties en 10 catégories de vêtements (t-shirt, pantalon, pull, robe, manteau, sandale, chemise, basket, sac, bottine). Il a été conçu comme remplaçant plus difficile de MNIST, sur lequel même des modèles simples dépassent 97 %.

> 🔗 **Documentation officielle** — [Datasets & DataLoaders](https://pytorch.org/tutorials/beginner/basics/data_tutorial.html) et la [liste des jeux torchvision](https://pytorch.org/vision/stable/datasets.html).

## 5. La boucle d'entraînement complète

Voici le script de référence de ce module, à connaître par cœur. Il tourne sur CPU en quelques minutes.

```python
"""entrainer_fashion.py — MLP sur Fashion-MNIST, CPU / CUDA / MPS.
Exécution : python entrainer_fashion.py   (télécharge ~30 Mo au premier lancement)"""
import time
import torch
from torch import nn
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, transforms

# ---------- 0. Reproductibilité et choix de l'appareil ----------
torch.manual_seed(42)
if torch.cuda.is_available():
    device = torch.device("cuda")          # GPU NVIDIA
elif torch.backends.mps.is_available():
    device = torch.device("mps")           # Apple Silicon
else:
    device = torch.device("cpu")
print("appareil :", device)

# ---------- 1. Données ----------
transfo = transforms.Compose([
    transforms.ToTensor(),                           # PIL -> tenseur (1, 28, 28) dans [0, 1]
    transforms.Normalize((0.2860,), (0.3530,)),      # moyenne / écart type de Fashion-MNIST
])
complet = datasets.FashionMNIST("donnees", train=True, download=True, transform=transfo)
test = datasets.FashionMNIST("donnees", train=False, download=True, transform=transfo)
train, valid = random_split(complet, [55_000, 5_000], generator=torch.Generator().manual_seed(42))
charge = dict(batch_size=128, num_workers=2, pin_memory=device.type == "cuda")
dl_train = DataLoader(train, shuffle=True, **charge)
dl_valid = DataLoader(valid, **charge)
dl_test = DataLoader(test, **charge)

# ---------- 2. Modèle, perte, optimiseur ----------
class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.reseau = nn.Sequential(
            nn.Flatten(),
            nn.Linear(784, 256), nn.ReLU(),
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, 10),
        )
    def forward(self, x):
        return self.reseau(x)

modele = MLP().to(device)
critere = nn.CrossEntropyLoss()
optimiseur = torch.optim.AdamW(modele.parameters(), lr=1e-3, weight_decay=1e-4)

# ---------- 3. Fonctions d'entraînement et d'évaluation ----------
def entrainer_une_epoque(dl):
    modele.train()
    total, perte_cumulee = 0, 0.0
    for xb, yb in dl:
        xb, yb = xb.to(device), yb.to(device)
        logits = modele(xb)                  # 1. passe avant
        perte = critere(logits, yb)          # 2. perte
        optimiseur.zero_grad()               # 3. remise à zéro des gradients
        perte.backward()                     # 4. rétropropagation
        optimiseur.step()                    # 5. mise à jour
        perte_cumulee += perte.item() * len(xb)
        total += len(xb)
    return perte_cumulee / total

@torch.no_grad()                             # aucun graphe en évaluation
def evaluer(dl):
    modele.eval()
    total, justes, perte_cumulee = 0, 0, 0.0
    for xb, yb in dl:
        xb, yb = xb.to(device), yb.to(device)
        logits = modele(xb)
        perte_cumulee += critere(logits, yb).item() * len(xb)
        justes += (logits.argmax(1) == yb).sum().item()
        total += len(xb)
    return perte_cumulee / total, justes / total

# ---------- 4. Boucle principale avec sauvegarde du meilleur modèle ----------
meilleure = 0.0
for epoque in range(1, 11):
    t0 = time.perf_counter()
    perte_tr = entrainer_une_epoque(dl_train)
    perte_va, acc_va = evaluer(dl_valid)
    if acc_va > meilleure:
        meilleure = acc_va
        torch.save(modele.state_dict(), "meilleur_mlp.pt")
    print(f"époque {epoque:2d} | perte train {perte_tr:.4f} | perte valid {perte_va:.4f} "
          f"| exactitude valid {acc_va:.2%} | {time.perf_counter() - t0:.1f} s")

# ---------- 5. Évaluation finale, UNE fois, sur le test ----------
modele.load_state_dict(torch.load("meilleur_mlp.pt", map_location=device))
perte_te, acc_te = evaluer(dl_test)
print(f"TEST : perte {perte_te:.4f} | exactitude {acc_te:.2%}")
```

Avec cette architecture, comptez une exactitude de test **de l'ordre de 88 à 89 %** après dix époques (la valeur exacte dépend de la machine et de la version). C'est la référence (*baseline*) que le réseau convolutif de L124 devra battre.

Les **cinq gestes** de la boucle (passe avant, perte, `zero_grad`, `backward`, `step`) sont les mêmes pour un MLP de 100 000 paramètres et pour un LLM de plusieurs centaines de milliards : seuls changent le modèle, les données et l'infrastructure. Notez aussi trois habitudes professionnelles : la perte est **pondérée par la taille du lot** (le dernier lot est plus petit), le meilleur modèle est **sauvegardé sur la validation**, et le test n'est lu **qu'une seule fois**, à la fin (M25 L116).

> 💡 **À retenir** — On sauvegarde le `state_dict()` (un dictionnaire de tenseurs), pas l'objet modèle entier. Pour recharger : recréer la classe, puis `load_state_dict(torch.load(...))`. Ne chargez jamais avec `torch.load` un fichier `.pt` reçu d'une source inconnue sans `weights_only=True` : le format peut embarquer du code Python.

## 6. CPU, GPU NVIDIA, Apple Silicon

| Appareil | Test de présence | Points d'attention |
|---|---|---|
| CPU | toujours disponible | idéal pour déboguer ; `torch.set_num_threads` si la machine est partagée |
| GPU NVIDIA (CUDA) | `torch.cuda.is_available()` | `pin_memory=True` et `non_blocking=True` accélèrent les transferts ; surveiller la mémoire avec `nvidia-smi` |
| Apple Silicon (MPS) | `torch.backends.mps.is_available()` | pas de `float64` ; certaines opérations retombent sur le CPU (variable `PYTORCH_ENABLE_MPS_FALLBACK=1`) |
| AMD (ROCm) | `torch.cuda.is_available()` (même API) | version spécifique de PyTorch à installer |

La règle d'or : **le modèle et les données doivent être sur le même appareil**. L'erreur `Expected all tensors to be on the same device` signifie qu'un `.to(device)` manque, presque toujours sur le lot de données ou sur un tenseur créé dans `forward` (créez-le avec `device=x.device`).

> 🔗 **Documentation officielle** — [MPS backend](https://pytorch.org/docs/stable/notes/mps.html) pour les Mac, et [Reproducibility](https://pytorch.org/docs/stable/notes/randomness.html) pour les graines et le déterminisme : même avec `torch.manual_seed`, un GPU peut donner des résultats légèrement différents d'une exécution à l'autre, sauf à activer `torch.use_deterministic_algorithms(True)` (au prix de la vitesse).

## 7. Lire les erreurs de forme comme un professionnel

| Message | Traduction | Correctif habituel |
|---|---|---|
| `mat1 and mat2 shapes cannot be multiplied (128x784 and 512x10)` | la couche attend 512 entrées, elle en reçoit 784 | corriger `in_features`, ou ajouter `nn.Flatten()` |
| `Expected input batch_size (64) to match target batch_size (32)` | logits et étiquettes n'ont pas le même nombre de lignes | un `view` mal placé a mélangé lot et canaux |
| `expected scalar type Long but found Float` | les étiquettes de `CrossEntropyLoss` doivent être des entiers | `y.long()` |
| `element 0 of tensors does not require grad` | la perte n'est reliée à aucun paramètre | un `detach()`, un `.item()` ou un `no_grad` de trop dans la passe avant |
| `CUDA out of memory` | le lot ne tient pas en mémoire | réduire `batch_size`, précision mixte (L126) |

Un réflexe qui fait gagner des heures : imprimer `x.shape` après chaque couche lors du premier essai, ou faire passer un lot factice `torch.randn(2, 1, 28, 28)` dans le modèle avant de lancer l'entraînement.

## 🧪 Exercice pratique

**Consigne.** Portez le MLP NumPy de L121 (cancer du sein, $30 \to 24 \to 24 \to 2$) en PyTorch :
1. Un `TableauDataset` pour les données standardisées (statistiques calculées sur l'entraînement).
2. Une classe `nn.Module`, `nn.CrossEntropyLoss`, `torch.optim.SGD(lr=0.05)`, lots de 16.
3. Un arrêt anticipé avec une patience de 15 époques et la sauvegarde du meilleur `state_dict`.
4. Comparez avec votre version NumPy : exactitude, perte de validation, temps d'exécution.

**Critères de réussite.**
- Exactitude de validation $\ge 95\,\%$, proche de la version NumPy (à 2 points près).
- Le script choisit tout seul CPU, CUDA ou MPS et tourne sans modification sur les trois.
- Deux lancements consécutifs donnent les mêmes chiffres sur CPU.
- La boucle contient les cinq gestes dans le bon ordre, et l'évaluation se fait sous `torch.no_grad()` avec `modele.eval()`.

<details><summary>Pistes de correction</summary>

- Séparez avec `torch.randperm(len(X), generator=torch.Generator().manual_seed(42))`.
- Avec `SGD` et la même initialisation que NumPy (`nn.init.kaiming_normal_` sur les poids, biais à zéro), les courbes sont presque superposables ; la différence restante vient de l'ordre de tirage des lots.
- Sur un jeu aussi petit, PyTorch n'est **pas** plus rapide que NumPy : le surcoût par lot domine. L'avantage apparaît avec des modèles et des lots plus grands, surtout sur GPU.
</details>

## 🎮 Défi

Que contient `a.grad` après ce code, et pourquoi ?
`a = torch.tensor(3.0, requires_grad=True); y = a * a; y.backward(); a.grad = None; z = a ** 3; z.backward()`. Réponse : `tensor(27.)`, soit $3a^2$ en $a=3$. Remettre `.grad` à `None` (ce que fait `zero_grad()` par défaut) supprime l'accumulation du premier `backward`.

## ✅ Auto-évaluation express

1. Citez dans l'ordre les cinq gestes de la boucle d'entraînement.
2. Pourquoi ne met-on pas de softmax à la fin d'un modèle entraîné avec `nn.CrossEntropyLoss` ?
3. À quoi servent `modele.eval()` et `torch.no_grad()`, et sont-ils interchangeables ?

**Réponses.** 1. Passe avant, calcul de la perte, `zero_grad()`, `backward()`, `step()` (le `zero_grad` peut aussi se placer en tout début de boucle). 2. Parce que la perte attend des logits et applique elle-même une log-softmax stable ; une softmax en plus écraserait les gradients. 3. Non : `eval()` change le comportement de couches comme le dropout et la normalisation par lot ; `no_grad()` désactive la construction du graphe. En évaluation, on utilise les deux.

## 📚 Pour aller plus loin
- [PyTorch — Learn the Basics](https://pytorch.org/tutorials/beginner/basics/intro.html) 🇬🇧 — le parcours officiel : tenseurs, données, modèle, autograd, optimisation, sauvegarde.
- [PyTorch — Optimizing Model Parameters](https://pytorch.org/tutorials/beginner/basics/optimization_tutorial.html) 🇬🇧 — la boucle d'entraînement expliquée par l'équipe PyTorch.
- [PyTorch — A Gentle Introduction to torch.autograd](https://pytorch.org/tutorials/beginner/blitz/autograd_tutorial.html) 🇬🇧 — le graphe dynamique en détail.
- [torchvision — Datasets](https://pytorch.org/vision/stable/datasets.html) 🇬🇧 — MNIST, Fashion-MNIST, CIFAR-10 et les autres jeux intégrés.
- [MIT 6.S191 Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 — Lab 1 de l'édition 2026 : prise en main de PyTorch puis génération de musique.
- [Stanford CS336 — supports de cours](https://github.com/stanford-cs336/lectures) 🇬🇧 — la séance 2 compte FLOPs et mémoire d'un modèle PyTorch (niveau avancé, utile en M27).
