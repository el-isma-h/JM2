---
id: L125
module: M26
level: N4
title: "Séquences : RNN, LSTM et leurs limites"
minutes: 60
objectives:
  - "Écrire les équations d'un réseau récurrent (RNN) et expliquer la rétropropagation à travers le temps"
  - "Démontrer, par le calcul puis par l'expérience, le phénomène des gradients qui s'évanouissent ou explosent"
  - "Expliquer comment les portes et l'état de cellule d'un LSTM préservent l'information, et appliquer l'écrêtage de gradient"
  - "Évaluer les limites des architectures récurrentes (calcul séquentiel, goulot d'étranglement) et en déduire la motivation de l'attention et des Transformers"
skills: ["C4.3", "C4.1"]
sources:
  - { title: "MIT 6.S191 (2026) — Lecture 2 : Deep Sequence Modeling", url: "https://introtodeeplearning.com/", lang: "en" }
  - { title: "Stanford CS231n Spring 2026 — Lecture 7 : Recurrent networks", url: "https://cs231n.stanford.edu/schedule.html", lang: "en" }
  - { title: "CMU 11-785 (Spring 2025) — Lectures 13-14 : RNN, stabilité, LSTM", url: "https://deeplearning.cs.cmu.edu/S25/index.html", lang: "en" }
  - { title: "PyTorch — torch.nn.LSTM", url: "https://pytorch.org/docs/stable/generated/torch.nn.LSTM.html", lang: "en" }
  - { title: "Bahdanau, Cho, Bengio (2014) — Neural Machine Translation by Jointly Learning to Align and Translate", url: "https://arxiv.org/abs/1409.0473", lang: "en" }
  - { title: "Vaswani et al. (2017) — Attention Is All You Need", url: "https://arxiv.org/abs/1706.03762", lang: "en" }
---

# Séquences : RNN, LSTM et leurs limites

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 26

## 🎯 Ce que vous saurez faire
- Écrire et dérouler dans le temps les équations d'un réseau récurrent (*recurrent neural network*, RNN).
- Expliquer pourquoi le gradient s'évanouit (ou explose) en remontant une longue séquence, et le mesurer.
- Lire les équations d'un LSTM et dire à quoi sert chaque porte.
- Utiliser `nn.RNN`, `nn.LSTM` et l'écrêtage de gradient dans PyTorch.
- Expliquer à un collègue pourquoi les Transformers ont remplacé les RNN dans les LLM, et où les modèles récurrents reviennent en 2026.

Cette leçon suit l'esprit de la séance 2 de MIT 6.S191 (« Deep Sequence Modeling »), qui va des RNN aux Transformers en une heure, et des séances 13-14 de CMU 11-785, consacrées à la stabilité des réseaux récurrents. Elle prépare directement le module M27.

## 1. Pourquoi les séquences demandent une architecture à part

Une boulangerie qui veut prévoir ses ventes de demain, un cabinet RH qui classe des lettres de motivation, un assistant vocal qui transcrit une phrase : dans les trois cas, les données sont des **séquences** dont l'ordre compte. « Le client n'est pas satisfait, il est ravi » et « le client est satisfait, il n'est pas ravi » contiennent les mêmes mots.

Un modèle de séquences doit :

1. accepter des **longueurs variables** (une phrase de 5 ou de 50 mots) ;
2. respecter l'**ordre** ;
3. **partager ses paramètres** dans le temps (la règle « un adjectif suit souvent un nom » vaut à la position 3 comme à la position 30) ;
4. capturer des **dépendances lointaines** (« Les factures que le cabinet a envoyées la semaine dernière à nos trois clients lyonnais **sont** arrivées » : l'accord se décide douze mots plus tôt).

Un MLP ne remplit que la troisième condition si l'on fixe la longueur, et aucune autre. Un CNN 1D gère l'ordre local mais pas les dépendances lointaines sans empiler beaucoup de couches.

## 2. Le réseau récurrent

### 2.1 Les équations

L'idée, formalisée par Jeffrey Elman en 1990, est de donner au réseau une **mémoire** : un état caché $h_t$ qui résume tout ce qui a été lu jusqu'au pas $t$. À chaque pas, le même calcul combine l'entrée courante et la mémoire précédente :

$$h_t = \tanh\!\left(x_t W_{xh} + h_{t-1} W_{hh} + b_h\right), \qquad \hat y_t = h_t W_{hy} + b_y$$

avec $x_t \in \mathbb{R}^{d}$, $h_t \in \mathbb{R}^{H}$, $W_{xh} \in \mathbb{R}^{d \times H}$, $W_{hh} \in \mathbb{R}^{H \times H}$, et $h_0 = 0$. Les **mêmes** matrices servent à chaque pas : c'est le partage de paramètres, l'équivalent temporel de la convolution (L124).

### 2.2 Le déroulement dans le temps

```
   x₁        x₂        x₃              x_T
   │         │         │               │
   ▼         ▼         ▼               ▼
h₀─►[ RNN ]─h₁─►[ RNN ]─h₂─►[ RNN ]─h₃─ … ─►[ RNN ]─h_T ─► ŷ (ou ŷ_t à chaque pas)
       (mêmes W_xh, W_hh, b à chaque pas)
```

« Dérouler » le RNN donne un réseau très profond (une couche par pas de temps) dont toutes les couches partagent les poids. On l'entraîne par **rétropropagation à travers le temps** (*backpropagation through time*, BPTT) : c'est la rétropropagation de L122, appliquée à ce graphe déroulé. Comme $W_{hh}$ est utilisée à chaque pas, son gradient est la **somme** des contributions de tous les pas (le motif « collecteur »).

Selon la tâche, on lit la sortie au dernier pas (classer un avis client), à chaque pas (prédire le mot suivant, étiqueter chaque mot), ou l'on enchaîne un encodeur et un décodeur (traduire une phrase : architecture *seq2seq* de Sutskever, Vinyals et Le, 2014).

## 3. Le problème central : le gradient qui s'évanouit

### 3.1 Le calcul

Supposons que la perte ne dépende que du dernier état $h_T$. Pour savoir comment une entrée lointaine $x_k$ l'influence, la règle de la chaîne traverse tous les pas intermédiaires :

$$\frac{\partial h_T}{\partial h_k} = \prod_{t=k+1}^{T} \frac{\partial h_t}{\partial h_{t-1}} = \prod_{t=k+1}^{T} \operatorname{diag}\!\left(1 - h_t^2\right) W_{hh}^\top$$

C'est un **produit de $T - k$ matrices**. Sa norme est majorée par $\left(\gamma\,\|W_{hh}\|\right)^{T-k}$, où $\gamma \le 1$ borne la dérivée de $\tanh$. Deux régimes :

- si $\gamma\,\|W_{hh}\| < 1$ (plus précisément, si le plus grand facteur de contraction est inférieur à 1), le produit décroît **exponentiellement** : le gradient s'évanouit (*vanishing gradient*), le réseau ne peut pas apprendre de dépendances lointaines ;
- si le plus grand facteur dépasse 1, il peut croître exponentiellement : le gradient **explose** (*exploding gradient*), la perte devient `nan`.

Ce diagnostic a été posé par Sepp Hochreiter dans son mémoire de diplôme (1991), puis par Bengio, Simard et Frasconi (1994). Analogie : le téléphone arabe. Chaque intermédiaire déforme un peu le message ; au vingtième, il ne reste rien du message d'origine, ou bien il a été amplifié jusqu'à l'absurde.

### 3.2 L'expérience

Ce script mesure, pour une séquence de 100 pas, la norme du gradient de la perte (qui ne dépend que du dernier pas) par rapport à chaque entrée $x_t$.

```python
"""gradient_temps.py — de combien le gradient survit-il en remontant le temps ?"""
import torch
from torch import nn

torch.manual_seed(0)
T, B, d, h = 100, 32, 8, 64
x = torch.randn(B, T, d, requires_grad=True)          # (lot, temps, variables)

rnn = nn.RNN(d, h, batch_first=True)
lstm = nn.LSTM(d, h, batch_first=True)
lstm_oubli = nn.LSTM(d, h, batch_first=True)
with torch.no_grad():                                 # biais de la porte d'oubli à 3 : f ≈ σ(3) ≈ 0,95
    lstm_oubli.bias_ih_l0[h:2 * h].fill_(3.0)         # ordre PyTorch des portes : i, f, g, o
    lstm_oubli.bias_hh_l0[h:2 * h].fill_(0.0)

for nom, couche in {"RNN": rnn, "LSTM": lstm, "LSTM, oubli=3": lstm_oubli}.items():
    sorties, _ = couche(x)                            # (B, T, h)
    perte = sorties[:, -1].pow(2).sum()               # la perte ne dépend que du DERNIER pas
    x.grad = None
    perte.backward()
    norme = x.grad.norm(dim=(0, 2))                   # norme du gradient pour chaque pas t
    print(f"{nom:13s} | ‖∂L/∂x_t‖ pour t = 99, 90, 50, 0 : "
          + "  ".join(f"{norme[t].item():.1e}" for t in (99, 90, 50, 0)))
```

Résultats obtenus (PyTorch 2.x, CPU, graine 0) :

| Modèle (non entraîné) | $t = 99$ | $t = 90$ | $t = 50$ | $t = 0$ |
|---|---|---|---|---|
| RNN | $8{,}9$ | $1{,}5 \cdot 10^{-2}$ | $4{,}3 \cdot 10^{-13}$ | $0$ (sous la précision du `float32`) |
| LSTM, initialisation par défaut | $6{,}2 \cdot 10^{-1}$ | $3{,}2 \cdot 10^{-3}$ | $2{,}7 \cdot 10^{-11}$ | $8{,}2 \cdot 10^{-21}$ |
| LSTM, biais d'oubli à 3 | $1{,}7$ | $4{,}3 \cdot 10^{-1}$ | $5{,}5 \cdot 10^{-1}$ | $3{,}7$ |

Pour le RNN, l'information de l'entrée $x_0$ n'atteint **jamais** la perte : le gradient perd treize ordres de grandeur en 49 pas, puis passe sous la plus petite valeur représentable en `float32` (environ $10^{-45}$). Le LSTM avec son initialisation par défaut ne fait pas beaucoup mieux, et c'est instructif : sa porte d'oubli vaut alors environ $\sigma(0) = 0{,}5$, donc la mémoire est divisée par deux à chaque pas. Dès que la porte d'oubli est ouverte (biais positif, une astuce recommandée notamment par Jozefowicz, Zaremba et Sutskever en 2015), le gradient traverse les 100 pas sans s'atténuer.

> 💡 **À retenir** — Le gradient qui s'évanouit n'est pas un bug de code : c'est une propriété mathématique des produits de jacobiennes. On le combat en offrant au gradient un **chemin additif** (état de cellule du LSTM, connexion résiduelle de ResNet) au lieu d'une suite de multiplications.

### 3.3 Le remède à l'explosion : l'écrêtage

L'explosion se traite simplement : si la norme globale du gradient dépasse un seuil $\tau$, on le rééchelonne,

$$g \leftarrow g \cdot \min\!\left(1, \frac{\tau}{\|g\|}\right)$$

ce qui garde la direction et limite la taille du pas (Pascanu, Mikolov et Bengio, 2013). Dans PyTorch : `torch.nn.utils.clip_grad_norm_(modele.parameters(), 1.0)`, placé entre `backward()` et `step()`. On l'utilise encore en 2026 pour entraîner les LLM.

## 4. Le LSTM : une mémoire à portes

### 4.1 Les équations

Le *Long Short-Term Memory* a été proposé par Hochreiter et Schmidhuber en 1997 ; la porte d'oubli a été ajoutée en 2000 par Gers, Schmidhuber et Cummins. Il maintient **deux** états : la sortie $h_t$ et un **état de cellule** $c_t$, une sorte de tapis roulant de l'information. Avec $u_t = [x_t, h_{t-1}]$ (concaténation) :

$$
\begin{aligned}
f_t &= \sigma(u_t W_f + b_f) && \text{porte d'oubli : que garder de } c_{t-1} \text{ ?}\\
i_t &= \sigma(u_t W_i + b_i) && \text{porte d'entrée : qu'écrire ?}\\
g_t &= \tanh(u_t W_g + b_g) && \text{candidat : le contenu à écrire}\\
o_t &= \sigma(u_t W_o + b_o) && \text{porte de sortie : que montrer ?}\\
c_t &= f_t \odot c_{t-1} + i_t \odot g_t && \text{mise à jour additive}\\
h_t &= o_t \odot \tanh(c_t)
\end{aligned}
$$

où $\odot$ est le produit terme à terme. La ligne clé est celle de $c_t$ : la mémoire est **mise à jour par addition**, modulée par $f_t$. Si $f_t \approx 1$ et $i_t \approx 0$, l'information traverse le pas sans être déformée, et $\partial c_t / \partial c_{t-1} = f_t \approx 1$ : le gradient aussi.

Analogie : un dossier client dans un cabinet comptable. À chaque nouvelle pièce, le collaborateur décide quoi archiver (oubli), quoi ajouter (entrée) et quoi mentionner dans la synthèse du jour (sortie). Le dossier lui-même n'est jamais réécrit de zéro.

### 4.2 GRU et comparaison

La *Gated Recurrent Unit* (Cho et al., 2014) simplifie le LSTM en deux portes (mise à jour et réinitialisation) et un seul état. Elle a souvent des performances proches, avec 25 % de paramètres en moins.

| | RNN simple | LSTM | GRU |
|---|---|---|---|
| États | $h_t$ | $h_t$ et $c_t$ | $h_t$ |
| Blocs de poids | 1 | 4 (f, i, g, o) | 3 |
| Paramètres pour $d = H = 256$ | $\approx 131\,000$ | $\approx 526\,000$ | $\approx 395\,000$ |
| Dépendances lointaines | faibles (≈ 10 pas) | bonnes (centaines de pas) | bonnes |
| Usage historique | pédagogique | traduction, voix, écriture manuscrite (2014-2017) | idem, plus léger |

(Chiffres PyTorch, qui utilise deux vecteurs de biais par bloc : $4 \times (256 \cdot 256 \cdot 2 + 2 \cdot 256) = 526\,336$ pour le LSTM.)

### 4.3 L'expérience qui tranche : se souvenir du premier symbole

La tâche est minimale : on lit une séquence de $T$ symboles aléatoires (parmi 8) et l'on doit restituer, à la fin, le **premier**. Le hasard donne 12,5 %.

```python
"""memoire.py — tâche de mémoire : retrouver le PREMIER symbole d'une séquence de longueur T.
RNN simple contre LSTM, sur CPU, en deux minutes environ."""
import torch
from torch import nn

torch.manual_seed(0)
V = 8                                                # taille du vocabulaire de symboles

def lot(B, T):
    x = torch.randint(0, V, (B, T))
    return x, x[:, 0].clone()                        # cible : le premier symbole

class Lecteur(nn.Module):
    def __init__(self, type_rnn, h=64):
        super().__init__()
        self.emb = nn.Embedding(V, 16)
        self.rnn = {"RNN": nn.RNN, "LSTM": nn.LSTM}[type_rnn](16, h, batch_first=True)
        if type_rnn == "LSTM":                       # astuce classique : biais d'oubli positif
            with torch.no_grad():
                self.rnn.bias_ih_l0[h:2 * h].fill_(2.0)
        self.tete = nn.Linear(h, V)
    def forward(self, x):
        sorties, _ = self.rnn(self.emb(x))
        return self.tete(sorties[:, -1])             # on lit l'état au DERNIER pas

def experience(type_rnn, T, etapes=800):
    torch.manual_seed(0)
    modele = Lecteur(type_rnn)
    opt = torch.optim.Adam(modele.parameters(), lr=3e-3)
    for _ in range(etapes):
        x, y = lot(64, T)
        perte = nn.functional.cross_entropy(modele(x), y)
        opt.zero_grad()
        perte.backward()
        nn.utils.clip_grad_norm_(modele.parameters(), 1.0)   # écrêtage : contre l'explosion
        opt.step()
    with torch.no_grad():
        x, y = lot(2000, T)
        return (modele(x).argmax(1) == y).float().mean().item()

print("hasard = 12,5 %")
for T in (5, 20, 50):
    print(f"T={T:3d} | RNN {experience('RNN', T):6.1%} | LSTM {experience('LSTM', T):6.1%}")
```

| Longueur $T$ | RNN simple | LSTM |
|---|---|---|
| 5 | 100 % | 100 % |
| 20 | 12,1 % (hasard) | 100 % |
| 50 | 13,3 % (hasard) | 100 % |

Le RNN réussit quand le premier symbole est à 5 pas, et échoue complètement à 20 : le signal d'erreur n'atteint plus l'entrée concernée, exactement comme mesuré en 3.2. Le LSTM, avec sa porte d'oubli ouverte, retient l'information sur 50 pas sans difficulté.

> ⚠️ **Piège fréquent** — Avec `batch_first=False` (la valeur par défaut de `nn.RNN` et `nn.LSTM`), PyTorch attend des entrées de forme $(T, B, d)$, pas $(B, T, d)$. Si vous passez $(B, T, d)$ sans l'option, le code tourne mais le réseau lit le lot comme s'il s'agissait du temps : résultats absurdes, aucune erreur. Précisez toujours `batch_first=True`.

> 🔗 **Documentation officielle** — [torch.nn.LSTM](https://pytorch.org/docs/stable/generated/torch.nn.LSTM.html) donne les équations exactes utilisées par PyTorch, l'ordre des portes dans les poids et les formes d'entrée et de sortie.

## 5. Les limites des RNN, et ce qui les a remplacés

Même un LSTM bien réglé garde trois défauts structurels :

1. **Le calcul est séquentiel.** $h_t$ dépend de $h_{t-1}$ : impossible de traiter les 1 000 mots d'un document en parallèle. Sur un GPU conçu pour des milliers d'opérations simultanées, c'est un gâchis, et cela a plafonné la taille des modèles et des jeux de données entraînables.
2. **Le goulot d'étranglement.** Dans un *seq2seq*, toute la phrase source est compressée dans **un seul** vecteur $h_T$ de taille fixe avant d'être traduite. Pour une phrase de 50 mots, c'est trop peu.
3. **La distance reste longue.** Entre le mot 1 et le mot 500, le signal doit traverser 499 pas. Le LSTM l'atténue moins, mais le chemin existe toujours.

### 5.1 L'attention, puis le Transformer

En 2014, Bahdanau, Cho et Bengio proposent l'**attention** pour la traduction : au lieu de lire seulement $h_T$, le décodeur calcule à chaque mot une **moyenne pondérée de tous les états** de l'encodeur, avec des poids appris (« sur quels mots source dois-je me concentrer pour produire ce mot ? »). Le goulot disparaît. En 2017, Vaswani et ses collègues (Google) franchissent le pas suivant dans *Attention Is All You Need* : ils **suppriment la récurrence** et ne gardent que l'attention. C'est le Transformer, architecture de tous les LLM actuels.

| Propriété | RNN / LSTM | Transformer (auto-attention) |
|---|---|---|
| Chemin entre deux positions éloignées | $O(n)$ pas | $O(1)$ : lien direct |
| Parallélisme à l'entraînement | non (séquentiel dans le temps) | oui (toutes les positions à la fois) |
| Coût mémoire en fonction de la longueur $n$ | $O(n)$ | $O(n^2)$ pour la matrice d'attention |
| Coût par nouveau mot à l'inférence | constant (un état) | croît avec le contexte (cache KV) |
| Usage dominant en 2026 | séries temporelles légères, embarqué | LLM, vision (ViT), audio, multimodal |

Le tableau montre aussi pourquoi l'histoire n'est pas terminée : l'attention coûte $O(n^2)$, alors qu'un réseau récurrent a une mémoire de taille fixe et un coût constant par mot. Les **modèles à espace d'états** (*state space models*, SSM, comme Mamba), qui sont des récurrences linéaires entraînables en parallèle, et des architectures hybrides mêlant couches récurrentes et couches d'attention cherchent à combiner les deux avantages. Le séminaire Stanford CS25 V6 (printemps 2026) y consacre une séance entière (« SSM vs Transformers », avec Albert Gu). Vous étudierez l'attention et ces architectures en M27.

> 💡 **À retenir** — Les RNN ont posé le problème (mémoire, ordre, longueurs variables) ; les LSTM ont résolu le gradient qui s'évanouit par un chemin additif ; l'attention a supprimé le goulot et le calcul séquentiel. Comprendre ces trois étapes, c'est comprendre pourquoi les LLM ont l'architecture qu'ils ont.

## 🧪 Exercice pratique

**Consigne.** Modèle de langage au niveau des caractères sur un texte français de votre choix (au moins 50 000 caractères ; par exemple un roman du domaine public téléchargé sur Wikisource ou le Projet Gutenberg, ou l'export texte de la documentation interne de votre entreprise) :
1. Construisez le vocabulaire des caractères, découpez le texte en séquences de 100 caractères, la cible étant la séquence décalée d'un caractère.
2. Entraînez un `nn.LSTM(64, 256, num_layers=2, batch_first=True)` précédé d'un `nn.Embedding` et suivi d'un `nn.Linear` (perte d'entropie croisée sur **chaque** pas), avec `clip_grad_norm_(…, 1.0)`.
3. Écrivez une fonction `generer(debut, n=300, temperature=0.8)` qui échantillonne caractère par caractère.
4. Remplacez le LSTM par un `nn.RNN` de même taille et comparez les pertes de validation.

**Critères de réussite.** La perte de validation passe sous 1,6 (soit une perplexité inférieure à 5 par caractère) avec le LSTM ; le texte généré contient des mots français réels, des espaces et une ponctuation plausibles ; le tableau de comparaison RNN / LSTM est rempli et commenté en trois phrases.

<details><summary>Pistes de correction</summary>

- Avec `sorties` de forme $(B, T, V)$ et cibles $(B, T)$ : `F.cross_entropy(sorties.reshape(-1, V), cibles.reshape(-1))`.
- Pour générer, gardez l'état `(h, c)` renvoyé par le LSTM et réinjectez-le à chaque pas : `logits, etat = modele(x, etat)` ; échantillonnez avec `torch.multinomial(torch.softmax(logits / temperature, -1), 1)`.
- Une température de 0,2 répète des mots fréquents ; 1,5 produit un charabia inventif. C'est le même réglage que celui des LLM (niveau 1).
- L'écart RNN / LSTM est souvent modeste sur des séquences de 100 caractères ; il se creuse quand on allonge les séquences, ce qui confirme la section 3.
</details>

## 🎮 Défi

Un RNN a 50 pas de temps et, à chaque pas, la jacobienne $\partial h_t / \partial h_{t-1}$ a une norme d'environ 0,8. Par combien le gradient est-il multiplié entre le dernier et le premier pas ? Et si la norme vaut 1,2 ? Réponse : $0{,}8^{49} \approx 1{,}8 \cdot 10^{-5}$ (évanouissement) ; $1{,}2^{49} \approx 7{,}6 \cdot 10^{3}$ (explosion). Une différence de 0,4 sur un facteur donne neuf ordres de grandeur d'écart.

## ✅ Auto-évaluation express

1. Pourquoi parle-t-on de « rétropropagation à travers le temps », et qu'a-t-elle de particulier pour le gradient de $W_{hh}$ ?
2. Quelle équation du LSTM explique sa résistance au gradient qui s'évanouit ?
3. Citez deux limites des RNN que l'attention résout.

**Réponses.** 1. Parce qu'on déroule le RNN en un graphe d'une couche par pas de temps, puis qu'on rétropropage dans ce graphe ; $W_{hh}$ étant partagée par tous les pas, son gradient est la somme des contributions de chaque pas. 2. $c_t = f_t \odot c_{t-1} + i_t \odot g_t$ : la mise à jour est additive, et $\partial c_t/\partial c_{t-1} = f_t$ reste proche de 1 quand la porte d'oubli est ouverte. 3. Le calcul séquentiel (non parallélisable) et le goulot d'étranglement d'un état de taille fixe ; ainsi que la longueur du chemin entre positions éloignées.

## 📚 Pour aller plus loin
- [MIT 6.S191 Introduction to Deep Learning](https://introtodeeplearning.com/) 🇬🇧 — séance 2, « Deep Sequence Modeling » : RNN, LSTM, attention et Transformers ; Lab 1 : génération de musique avec un RNN.
- [CMU 11-785 Introduction to Deep Learning](https://deeplearning.cs.cmu.edu/S25/index.html) 🇬🇧 — séances 13 et 14 : séries temporelles, stabilité, mémoire et LSTM, avec les démonstrations détaillées.
- [Stanford CS231n — programme Spring 2026](https://cs231n.stanford.edu/schedule.html) 🇬🇧 — séance 7 : RNN, LSTM, GRU et légendage d'images.
- [Neural Machine Translation by Jointly Learning to Align and Translate](https://arxiv.org/abs/1409.0473) 🇬🇧 — l'article de 2014 qui introduit l'attention.
- [Attention Is All You Need](https://arxiv.org/abs/1706.03762) 🇬🇧 — l'article du Transformer (2017), point de départ de M27.
- [Stanford CS25 Transformers United V6](https://web.stanford.edu/class/cs25/index.html) 🇬🇧 — séminaire ouvert à tous, dont une séance « SSM vs Transformers ».
