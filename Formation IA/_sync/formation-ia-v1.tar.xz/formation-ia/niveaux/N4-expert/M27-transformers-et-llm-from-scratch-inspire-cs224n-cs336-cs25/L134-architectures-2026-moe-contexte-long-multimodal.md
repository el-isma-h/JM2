---
id: L134
module: M27
level: N4
title: "Architectures 2026 : MoE, contexte long, multimodal"
minutes: 60
objectives:
  - "Expliquer le fonctionnement d'une couche Mixture of Experts (routage top-k, équilibrage de charge) et distinguer paramètres totaux et actifs"
  - "Calculer la taille du KV cache et comparer MHA, GQA, MQA et l'attention latente"
  - "Décrire les techniques de contexte long (extension de RoPE, fenêtres glissantes, noyaux optimisés) et leurs limites"
  - "Expliquer comment un transformer devient multimodal (patchs d'image, encodeur de vision, projection)"
  - "Évaluer un modèle ouvert de 2026 à partir de sa fiche technique (architecture, contexte, licence, mémoire)"
skills: ["C4.3"]
sources:
  - { title: "Shazeer et al. (2017) — Outrageously Large Neural Networks: The Sparsely-Gated Mixture-of-Experts Layer", url: "https://arxiv.org/abs/1701.06538", lang: "en" }
  - { title: "Fedus, Zoph, Shazeer (2021) — Switch Transformers", url: "https://arxiv.org/abs/2101.03961", lang: "en" }
  - { title: "Ainslie et al. (2023) — GQA: Training Generalized Multi-Query Transformer Models", url: "https://arxiv.org/abs/2305.13245", lang: "en" }
  - { title: "DeepSeek-AI (2024) — DeepSeek-V2 (Multi-head Latent Attention)", url: "https://arxiv.org/abs/2405.04434", lang: "en" }
  - { title: "Peng et al. (2023) — YaRN: Efficient Context Window Extension", url: "https://arxiv.org/abs/2309.00071", lang: "en" }
  - { title: "Gu & Dao (2023) — Mamba: Linear-Time Sequence Modeling with Selective State Spaces", url: "https://arxiv.org/abs/2312.00752", lang: "en" }
  - { title: "Stanford CS25 Transformers United V6 (SSM vs Transformers, parallélisme et MoE, multimodal natif)", url: "https://web.stanford.edu/class/cs25/index.html", lang: "en" }
  - { title: "Mistral AI — Mistral Small 4", url: "https://mistral.ai/news/mistral-small-4/", lang: "en" }
---

# Architectures 2026 : MoE, contexte long, multimodal

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 27

## 🎯 Ce que vous saurez faire
- Expliquer pourquoi la plupart des grands modèles ouverts de 2026 sont des **Mixture of Experts** (MoE), et lire une notation comme « 119B-A6B ».
- Implémenter une couche MoE avec routeur top-k et perte d'équilibrage de charge.
- Calculer le **KV cache** d'un modèle et comprendre pourquoi GQA, MQA et l'attention latente (MLA) ont été inventées.
- Décrire les techniques qui permettent des contextes de 256 000 à 1 million de tokens, et leurs limites réelles.
- Expliquer comment un transformer « voit » une image, et situer les alternatives à l'attention (modèles à espace d'états).
- Lire la fiche technique d'un modèle ouvert et en déduire la mémoire nécessaire et les conditions de licence.

Le transformer de L129 est un modèle **dense** : chaque token traverse tous les paramètres. Les modèles de 2026 gardent ce squelette mais modifient trois organes : le MLP devient un ensemble d'experts, l'attention est réorganisée pour réduire la mémoire, et l'entrée accepte des images, de l'audio et de la vidéo. Cette leçon s'appuie sur la séance 4 de CS336 (« alternatives à l'attention, MoE ») et sur la saison V6 du séminaire CS25 (Spring 2026), qui a accueilli Albert Gu sur les modèles à espace d'états, Hugging Face sur le parallélisme 5D et les MoE, Mistral sur l'avenir du pré-entraînement et Thinking Machines sur l'intelligence multimodale native.

## 1. Le paysage ouvert de novembre 2026

Le dossier de recherche de la formation (nov. 2026) dresse un constat net : le haut des classements ouverts est dominé par des **MoE géants**, majoritairement chinois, tandis que des modèles plus compacts restent la norme pour le poste de travail.

| Modèle (éditeur) | Paramètres totaux / actifs | Contexte | Licence | Remarque |
|---|---|---|---|---|
| Kimi K3 (Moonshot) | 2,8T / 104B (896 experts, 16 actifs) | 1M | Kimi K3 License (conditions au-delà de seuils de revenus et d'audience) | ~1,4 To de mémoire en MXFP4 : cluster ≥ 64 accélérateurs |
| DeepSeek-V4.1-Flash | 552B / 8B (prefill) – 16B (decode) | 1M | MIT | très fort en code agentique |
| Mistral Small 4 (Mistral AI) | 119B / 6B (128 experts, 4 actifs) | 256K | Apache 2.0 | fusionne raisonnement, code et vision ; `reasoning_effort` |
| gpt-oss-120b (OpenAI) | 116,8B / 5,1B | 128K | Apache 2.0 | tient sur un GPU de 80 Go en MXFP4 |
| Gemma 4 26B-A4B (Google) | 25,2B / 3,8B | 256K | Apache 2.0 | texte, image, vidéo ; 16-18 Go en 4 bits |
| Qwen3.8-27B (Alibaba) | 27B dense | 262K natif → 1M | Apache 2.0 | vision-langage natif |
| Llama 4 Scout (Meta, 2025) | 109B / 17B | 10M | Llama 4 Community License | contexte extrême annoncé |

Sur l'Artificial Analysis Intelligence Index v5 (27 oct. 2026), les meilleurs modèles fermés (Claude Opus 5.5 : 58, GPT-6 Astra : 57) devancent nettement les meilleurs poids publiés (DeepSeek V4.1 Flash et GLM-5.3 : 32). Les chiffres évoluent chaque mois : vérifiez toujours la date d'un classement.

> 💡 **À retenir** — « 119B-A6B » se lit « 119 milliards de paramètres au total, 6 milliards **actifs** par token ». La **mémoire** dépend du total (tous les experts doivent être chargés), la **vitesse et le coût de calcul** dépendent des actifs. Un MoE est un modèle qui « sait » comme un gros et « calcule » comme un petit.

## 2. Mixture of Experts : spécialiser sans tout calculer

L'idée remonte à 1991 (Jacobs, Jordan, Nowlan, Hinton) et a été adaptée aux réseaux profonds par Noam Shazeer et ses coauteurs en 2017 (arXiv 1701.06538), avec une couche de plusieurs milliers d'experts entre deux LSTM. Dans un transformer, on remplace le MLP de chaque bloc par $N$ MLP indépendants (les **experts**) et un **routeur**, une simple couche linéaire qui produit un score par expert :

$$p = \text{softmax}(W_r\, x), \qquad y = \sum_{e \in \text{top-}k(p)} \tilde{p}_e \cdot \text{Expert}_e(x)$$

où $\tilde{p}$ sont les poids des $k$ experts retenus, renormalisés. Analogie : un cabinet pluridisciplinaire avec 128 spécialistes ; l'accueil (le routeur) oriente chaque dossier vers les 4 plus pertinents, et la facture ne compte que leurs honoraires.

Trois difficultés font tout le sel du sujet :

1. **L'effondrement du routage.** Au début de l'entraînement, un expert un peu meilleur reçoit plus de tokens, s'améliore, en reçoit encore plus… et les autres meurent. Le *Switch Transformer* (Fedus, Zoph, Shazeer, 2021, arXiv 2101.03961, routage top-1) ajoute une **perte d'équilibrage** $N \sum_e f_e \cdot P_e$, où $f_e$ est la fraction de tokens envoyés à l'expert $e$ et $P_e$ sa probabilité moyenne ; elle vaut 1 quand la charge est parfaitement uniforme. DeepSeek-V3 (arXiv 2412.19437) a popularisé une approche sans perte auxiliaire, par ajustement de biais du routeur.
2. **La granularité.** Mixtral 8x7B (Mistral AI, 2024, arXiv 2401.04088) utilisait 8 gros experts dont 2 actifs ; les MoE récents utilisent des centaines d'experts plus fins (896 pour Kimi K3), souvent complétés par un ou plusieurs **experts partagés** traversés par tous les tokens.
3. **Le système.** Les experts sont répartis entre GPU (*parallélisme d'experts*), ce qui implique des échanges massifs de tokens entre machines. C'est l'objet de la séance CS25 V6 sur le parallélisme 5D, et la raison pour laquelle un MoE de 2,8T exige un cluster.

## 3. Attention efficace : la bataille du KV cache

En génération, le modèle produit un token à la fois. Pour éviter de recalculer les clés et valeurs de tout le contexte à chaque pas, on les **met en cache**. La formule retenue dans le dossier de recherche (nov. 2026) est :

$$\text{KV cache (octets)} = 2 \times \text{couches} \times \text{têtes}_{KV} \times d_{\text{tête}} \times \text{tokens} \times \text{octets par valeur}$$

Le facteur 2 compte les clés **et** les valeurs. Ce cache croît linéairement avec le contexte et le nombre d'utilisateurs simultanés, et devient vite le premier poste de mémoire d'un serveur. Les architectures récentes l'attaquent sur le terme « têtes KV » :

| Variante | Idée | Têtes KV (pour 32 têtes de requête) | Référence |
|---|---|---|---|
| MHA (*multi-head*) | une clé/valeur par tête | 32 | Vaswani et al., 2017 |
| MQA (*multi-query*) | une seule clé/valeur partagée par toutes les têtes | 1 | Shazeer, 2019 (arXiv 1911.02150) |
| GQA (*grouped-query*) | des groupes de têtes de requête partagent une clé/valeur | 8 (typique) | Ainslie et al., 2023 (arXiv 2305.13245) |
| MLA (*multi-head latent attention*) | clés et valeurs compressées dans un vecteur latent de petite dimension, décompressé à la volée | n/a (cache latent) | DeepSeek-V2, 2024 (arXiv 2405.04434) |

GQA est devenu le standard des modèles denses : il divise le cache par 4 avec une perte de qualité négligeable selon ses auteurs, là où MQA dégrade davantage. MLA, introduite par DeepSeek, va plus loin en compressant le cache. Le script de la section 6 chiffre l'effet.

Deux autres techniques complètent la panoplie. La **fenêtre glissante** (*sliding window attention*, Longformer en 2020, Mistral 7B en 2023) limite chaque token aux $W$ précédents : le coût devient $O(T \cdot W)$ et le cache est plafonné à $W$ tokens. On l'alterne souvent avec des couches à attention globale. Le **décodage spéculatif** (Leviathan et al., 2022, arXiv 2211.17192) fait proposer plusieurs tokens par un petit modèle « brouillon » et les fait vérifier en une seule passe par le grand modèle, avec des gains typiques de 2 à 3 fois sans changer la distribution de sortie (dossier de recherche, nov. 2026). Le module 29 approfondira ces optimisations d'inférence.

## 4. Contexte long : promesses et limites

Passer de 4 000 à 1 million de tokens de contexte combine plusieurs ingrédients :

- **Étendre RoPE.** Un modèle entraîné jusqu'à 8K positions n'a jamais vu les angles de rotation correspondant à la position 500 000. On augmente la `base` de RoPE ou l'on interpole les positions ; **YaRN** (Peng et al., 2023, arXiv 2309.00071) ajuste différemment les hautes et basses fréquences et permet d'étendre le contexte avec un court fine-tuning. C'est le sens de la mention « 262K natif → 1M » de la fiche Qwen3.8-27B.
- **Entraîner progressivement** : la majorité du pré-entraînement se fait sur des séquences courtes, puis une phase dédiée (*long-context mid-training*) allonge la fenêtre.
- **Des noyaux exacts et économes** (FlashAttention, L128) et un KV cache réduit (section 3), complétés par le parallélisme de séquence entre GPU.

Un contexte annoncé n'est pas un contexte **utilisé**. L'étude « Lost in the Middle » (Liu et al., 2023, arXiv 2307.03172) a montré que des modèles exploitent bien mieux l'information placée au début ou à la fin du contexte qu'au milieu. Les tests « aiguille dans une botte de foin » sont devenus trop faciles ; les évaluations sérieuses demandent de **raisonner** sur plusieurs passages dispersés.

> ⚠️ **Piège fréquent** — Charger 800 pages de contrats dans un contexte de 1M tokens « parce que ça rentre ». Le coût (facturé au token, rappel L130), la latence et la mémoire explosent, et la qualité de réponse sur les détails enfouis au milieu n'est pas garantie. Pour une PME, un pipeline RAG bien conçu (module 20) reste souvent plus fiable et bien moins cher ; le contexte long sert à **compléter** la recherche, pas à la remplacer.

## 5. Au-delà de l'attention, et au-delà du texte

**Les modèles à espace d'états.** Les SSM comme **Mamba** (Gu & Dao, 2023, arXiv 2312.00752) remplacent l'attention par une récurrence linéaire dont les paramètres dépendent de l'entrée (« sélective »). Leur coût est **linéaire** en $T$ et leur état a une taille **fixe**, sans KV cache qui grossit. En contrepartie, ils compressent le passé et sont moins bons pour retrouver une information précise loin dans le contexte. La tendance 2025-2026 est aux **architectures hybrides** qui intercalent quelques couches d'attention entre des couches SSM ou à attention linéaire. La séance d'Albert Gu dans CS25 V6 (« SSM vs Transformers ») en fait le point.

**Les transformers multimodaux.** Le *Vision Transformer* (ViT, Dosovitskiy et al., 2020, arXiv 2010.11929) a montré qu'une image découpée en **patchs** de 16 × 16 pixels, chacun projeté linéairement en vecteur, se traite exactement comme une suite de tokens : « *An Image is Worth 16x16 Words* ». CLIP (Radford et al., 2021, arXiv 2103.00020) aligne images et textes dans un même espace par apprentissage contrastif. La recette LLaVA (Liu et al., 2023, arXiv 2304.08485) branche un encodeur de vision pré-entraîné sur un LLM via une petite **projection** apprise : les « tokens visuels » sont insérés dans la séquence, et le reste du modèle ne change pas.

```
image ─▶ patchs 16×16 ─▶ encodeur de vision (ViT) ─▶ projection ─▶ [v1 v2 … vn] ─┐
texte ─▶ tokenizer BPE ─▶ embeddings ─────────────────────────────▶ [t1 t2 … tm] ─┴─▶ transformer décodeur ─▶ texte
```

Les modèles de 2026 vont vers le **multimodal natif**, entraîné dès le pré-entraînement sur des données mêlées : Gemma 4 accepte texte, image et audio (plus la vidéo pour les grandes tailles), Qwen3.8-27B image et vidéo, Muse Spark Open de Meta texte, image, audio et vidéo en entrée (nov. 2026, dossier de recherche). Le coût caché est la longueur : une image ou quelques secondes de vidéo peuvent représenter des centaines ou des milliers de tokens, ce qui renvoie directement aux sections 3 et 4.

## 6. Démonstration : MoE, KV cache et fenêtre glissante

```python
# architectures_2026.py — L134 : couche MoE top-k, coût du KV cache (MHA / GQA / MQA), masque à fenêtre glissante
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(0)

class MoE(nn.Module):
    """N experts SwiGLU, k actifs par token, + perte d'équilibrage de charge (style Switch Transformer)."""
    def __init__(self, d, n_experts=8, k=2, hidden=None):
        super().__init__()
        hidden = hidden or 2 * d
        self.k, self.n = k, n_experts
        self.routeur = nn.Linear(d, n_experts, bias=False)
        self.w1 = nn.Parameter(torch.randn(n_experts, d, hidden) * 0.02)
        self.w3 = nn.Parameter(torch.randn(n_experts, d, hidden) * 0.02)
        self.w2 = nn.Parameter(torch.randn(n_experts, hidden, d) * 0.02)

    def forward(self, x):                                   # x : (tokens, d)
        probs = F.softmax(self.routeur(x), dim=-1)          # (tokens, N)
        poids, choix = probs.topk(self.k, dim=-1)           # k experts par token
        poids = poids / poids.sum(-1, keepdim=True)         # renormalisation sur les k élus
        y = torch.zeros_like(x)
        for e in range(self.n):                             # boucle lisible (les vrais noyaux regroupent les tokens)
            ligne, rang = (choix == e).nonzero(as_tuple=True)
            if ligne.numel() == 0:
                continue
            h = F.silu(x[ligne] @ self.w1[e]) * (x[ligne] @ self.w3[e])
            y.index_add_(0, ligne, poids[ligne, rang, None] * (h @ self.w2[e]))
        # équilibrage : N · Σ_e (fraction de tokens routés vers e) × (proba moyenne de e)
        fraction = F.one_hot(choix[:, 0], self.n).float().mean(0)
        perte_eq = self.n * (fraction * probs.mean(0)).sum()
        return y, perte_eq, choix

moe = MoE(d=64, n_experts=8, k=2)
x = torch.randn(512, 64)
y, perte_eq, choix = moe(x)
total = sum(p.numel() for p in moe.parameters())
actifs = moe.routeur.weight.numel() + 2 * (moe.w1[0].numel() + moe.w3[0].numel() + moe.w2[0].numel())
print(f"MoE : {total:,} paramètres au total, ~{actifs:,} actifs par token ({actifs / total:.0%})")
print("Tokens par expert :", torch.bincount(choix.flatten(), minlength=8).tolist(),
      f"| perte d'équilibrage = {perte_eq.item():.3f} (1,0 = parfait)")

# KV cache : 2 (K et V) × couches × têtes_KV × dim_tête × tokens × octets
def kv_cache_go(couches, tetes_kv, dim_tete, tokens, octets=2):
    return 2 * couches * tetes_kv * dim_tete * tokens * octets / 1e9

print("\nKV cache d'un modèle 32 couches, 32 têtes de requête, dim_tête 128, en BF16 :")
for nom, kv in (("MHA (32 têtes KV)", 32), ("GQA (8 têtes KV)", 8), ("MQA (1 tête KV)", 1)):
    print(f"  {nom:18s}  8K tokens : {kv_cache_go(32, kv, 128, 8_192):6.2f} Go"
          f" | 128K tokens : {kv_cache_go(32, kv, 128, 131_072):6.1f} Go")

# Fenêtre glissante : chaque token ne regarde que les W précédents (coût O(T·W) au lieu de O(T²))
def masque_fenetre(T, W):
    i, j = torch.arange(T)[:, None], torch.arange(T)[None, :]
    return (j <= i) & (j > i - W)                          # True = autorisé

print("\nMasque fenêtre glissante T=6, W=3 :\n", masque_fenetre(6, 3).int())
q = k = v = torch.randn(1, 2, 6, 16)
sortie = F.scaled_dot_product_attention(q, k, v, attn_mask=masque_fenetre(6, 3))
print("Sortie attention fenêtrée :", tuple(sortie.shape))
```

Résultats obtenus sur CPU : la couche MoE à 8 experts dont 2 actifs utilise environ **25 %** de ses paramètres par token (49 664 sur 197 120), la répartition des 512 tokens entre experts reste équilibrée (de 108 à 142 tokens par expert, perte d'équilibrage 1,004). Pour un modèle de 32 couches à dimension de tête 128, le KV cache en BF16 passe de **68,7 Go** (MHA) à **17,2 Go** (GQA à 8 têtes KV) et **2,1 Go** (MQA) pour un seul utilisateur à 128K tokens ; la valeur GQA à 8K (1,07 Go) correspond à l'ordre de grandeur relevé pour Llama 3 8B dans le dossier de recherche.

> 🎮 **Défi** — Un serveur dispose de 40 Go libres pour le KV cache d'un modèle GQA (32 couches, 8 têtes KV, dimension 128, BF16). Combien d'utilisateurs simultanés peut-il servir avec des conversations de 32K tokens ? *(Réponse en fin de leçon.)*

> 🔗 **Documentation officielle** — [Mistral AI — Mistral Small 4](https://mistral.ai/news/mistral-small-4/) 🇬🇧 (MoE 128 experts, 4 actifs, Apache 2.0) · [Stanford CS25 V6](https://web.stanford.edu/class/cs25/index.html) 🇬🇧 (séances SSM, MoE, multimodal natif, serving en production) · [Hugging Face Transformers](https://huggingface.co/docs/transformers/index) 🇬🇧 (fichiers de configuration `config.json` : `num_key_value_heads`, `num_experts`, `rope_scaling`…).

## 🧪 Exercice pratique

**Consigne.** Vous conseillez une PME qui veut héberger un assistant interne sur un GPU de 80 Go.
1. **Lecture de fiche** : pour gpt-oss-120b (116,8B total, 5,1B actifs, MXFP4 ≈ 66 Go d'après le dossier de recherche) et Gemma 4 26B-A4B (16-18 Go en 4 bits), indiquez la mémoire restante pour le KV cache et la licence.
2. **KV cache** : avec la fonction `kv_cache_go`, estimez le nombre d'utilisateurs simultanés à 16K tokens pour un modèle hypothétique de 48 couches, 8 têtes KV, dimension 128, BF16, sur la mémoire restante de chacun des deux cas.
3. **MoE** : modifiez la classe `MoE` pour ajouter un **expert partagé** traversé par tous les tokens (à la DeepSeek) et vérifiez que la sortie garde la forme `(512, 64)`.
4. Rédigez une recommandation de cinq lignes.

**Critères de réussite.** (a) Les calculs de mémoire sont posés explicitement et cohérents (≈ 14 Go restants contre ≈ 62 Go) ; (b) le nombre d'utilisateurs est un entier arrondi par défaut ; (c) l'expert partagé est ajouté sans casser le routage ; (d) la recommandation arbitre entre qualité, concurrence et licence.

<details><summary>Pistes de corrigé</summary>

- KV cache par utilisateur à 16K : $2 \times 48 \times 8 \times 128 \times 16\,384 \times 2 \approx 3{,}2$ Go. Avec gpt-oss-120b, il reste ≈ 80 − 66 = 14 Go, soit 4 utilisateurs simultanés (en pratique moins, à cause des activations et de la fragmentation). Avec Gemma 4 26B-A4B, il reste ≈ 62 Go, soit 19 utilisateurs.
- Expert partagé : créez `self.partage = SwiGLU(d)` (ou trois matrices dédiées) et ajoutez `y = y + self.partage(x)` à la fin de `forward`.
- Recommandation type : les deux modèles sont sous Apache 2.0 ; gpt-oss-120b offre plus de qualité mais peu de concurrence sur un seul GPU ; Gemma 4 26B-A4B sert beaucoup plus d'utilisateurs, accepte les images, et suffit pour la plupart des tâches de bureautique ; tester les deux sur un jeu d'évaluation métier avant de décider (module 29).
</details>

## ✅ Auto-évaluation express
1. Pourquoi un MoE de 119B paramètres totaux et 6B actifs génère-t-il presque aussi vite qu'un modèle dense de 6B, mais demande-t-il autant de mémoire qu'un modèle de 119B ?
2. Quelle quantité GQA réduit-elle, et de quel facteur avec 32 têtes de requête et 8 têtes KV ?
3. Quel avantage et quel inconvénient principal un modèle à espace d'états (Mamba) présente-t-il face à l'attention ?

## 📚 Pour aller plus loin
- [Fedus, Zoph, Shazeer (2021) — Switch Transformers](https://arxiv.org/abs/2101.03961) 🇬🇧 — routage top-1 et perte d'équilibrage.
- [Jiang et al. (2024) — Mixtral of Experts](https://arxiv.org/abs/2401.04088) 🇬🇧 — le MoE ouvert de Mistral AI qui a popularisé l'approche.
- [DeepSeek-AI (2024) — DeepSeek-V3 Technical Report](https://arxiv.org/abs/2412.19437) 🇬🇧 — MLA, experts fins et partagés, équilibrage sans perte auxiliaire.
- [Liu et al. (2023) — Lost in the Middle](https://arxiv.org/abs/2307.03172) 🇬🇧 — ce que les modèles font vraiment de leur long contexte.
- [Dosovitskiy et al. (2020) — Vision Transformer](https://arxiv.org/abs/2010.11929) 🇬🇧 — l'image comme suite de patchs.
- [Stanford CS336 — Language Modeling from Scratch](https://cs336.stanford.edu/) 🇬🇧 — séances 4 (alternatives à l'attention, MoE), 10 (inférence) et 17 (multimodalité).

**Réponses de l'auto-évaluation.** 1. Chaque token ne traverse que les experts sélectionnés (≈ 6B paramètres de calcul), mais tous les experts doivent rester en mémoire car le routeur peut choisir n'importe lequel au token suivant. 2. Le nombre de têtes clé/valeur, donc la taille du KV cache : division par 4. 3. Avantage : coût linéaire en longueur et état de taille fixe (pas de KV cache croissant) ; inconvénient : le passé est compressé, ce qui rend plus difficile le rappel exact d'une information lointaine. **Défi** : $2 \times 32 \times 8 \times 128 \times 32\,768 \times 2 \approx 4{,}3$ Go par utilisateur, donc 9 utilisateurs simultanés.
