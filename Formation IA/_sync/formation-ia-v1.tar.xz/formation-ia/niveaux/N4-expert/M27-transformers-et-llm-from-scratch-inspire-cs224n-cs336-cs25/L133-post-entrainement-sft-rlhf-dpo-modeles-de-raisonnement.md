---
id: L133
module: M27
level: N4
title: "Post-entraînement : SFT, RLHF, DPO, modèles de raisonnement"
minutes: 60
objectives:
  - "Décrire les étapes qui transforment un modèle de base en assistant : SFT, modèle de récompense, RLHF/PPO"
  - "Dériver et implémenter la perte DPO et expliquer ce qu'elle évite par rapport au RLHF classique"
  - "Expliquer le principe du RLAIF et de l'IA constitutionnelle"
  - "Expliquer l'apprentissage par renforcement sur récompenses vérifiables (RLVR, GRPO) et son rôle dans les modèles de raisonnement"
  - "Implémenter un RL jouet à avantages normalisés par groupe sur une tâche vérifiable"
skills: ["C4.3"]
sources:
  - { title: "Ouyang et al. (2022) — Training language models to follow instructions with human feedback (InstructGPT)", url: "https://arxiv.org/abs/2203.02155", lang: "en" }
  - { title: "Rafailov et al. (2023) — Direct Preference Optimization", url: "https://arxiv.org/abs/2305.18290", lang: "en" }
  - { title: "Bai et al. (2022) — Constitutional AI: Harmlessness from AI Feedback", url: "https://arxiv.org/abs/2212.08073", lang: "en" }
  - { title: "Shao et al. (2024) — DeepSeekMath (GRPO)", url: "https://arxiv.org/abs/2402.03300", lang: "en" }
  - { title: "DeepSeek-AI (2025) — DeepSeek-R1", url: "https://arxiv.org/abs/2501.12948", lang: "en" }
  - { title: "Hugging Face TRL — documentation", url: "https://huggingface.co/docs/trl/index", lang: "en" }
  - { title: "Stanford CS336 Spring 2026 — séances 15-17 ; devoir A5", url: "https://cs336.stanford.edu/", lang: "en" }
---

# Post-entraînement : SFT, RLHF, DPO, modèles de raisonnement

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 27

## 🎯 Ce que vous saurez faire
- Expliquer pourquoi un modèle pré-entraîné n'est **pas** un assistant, et ce que chaque étape du post-entraînement lui apporte.
- Décrire le RLHF d'InstructGPT : SFT, modèle de récompense, optimisation PPO avec pénalité KL.
- Écrire et coder la perte **DPO** (*Direct Preference Optimization*), puis expliquer ce qu'elle simplifie.
- Expliquer le **RLAIF** et l'**IA constitutionnelle** d'Anthropic.
- Expliquer comment le **RL sur récompenses vérifiables** (RLVR) et l'algorithme **GRPO** ont produit les modèles de raisonnement, et le démontrer sur un exemple jouet exécutable sur CPU.

Le module 26 et les leçons précédentes ont produit un **modèle de base** (*base model*) : un prédicteur de texte. Demandez-lui « Rédige un courriel de relance pour une facture impayée » : il risque de continuer par « Rédige un courriel de remerciement pour… », comme s'il complétait une liste d'exercices trouvée sur le web. Le **post-entraînement** en fait un assistant qui suit les instructions, refuse les demandes dangereuses et, depuis 2024, **raisonne** avant de répondre. Cette leçon suit le fil des séances 15 (*mid/post-training*, SFT/RLHF), 16 (*RLVR*) et 17 (alignement) de Stanford CS336, ainsi que la lecture 10 de CS224N (Winter 2024).

## 1. Vue d'ensemble : trois étages

```
Modèle de base ──▶ SFT (démonstrations) ──▶ Optimisation des préférences ──▶ RL sur récompenses vérifiables ──▶ Assistant « raisonneur »
  (prédit le web)    « répondre comme un      (RLHF/PPO, DPO, RLAIF)          (maths, code, tâches à correction
                       assistant »            « répondre comme on préfère »     automatique : RLVR, GRPO)
```

| Étape | Données | Signal d'apprentissage | Ce que le modèle gagne |
|---|---|---|---|
| SFT (*supervised fine-tuning*) | paires (instruction, réponse idéale) rédigées par des humains ou des modèles | entropie croisée sur la réponse | le format « assistant », le suivi d'instructions |
| RLHF / DPO | comparaisons « réponse A préférée à B » | préférence humaine (ou d'IA) | utilité, ton, honnêteté, refus appropriés |
| RLVR | problèmes dont la réponse se vérifie automatiquement | récompense binaire ou graduée calculée par programme | raisonnement long, auto-correction |

## 2. SFT : apprendre par l'exemple

Le SFT est un fine-tuning classique : on continue l'entraînement du modèle de base sur des conversations formatées avec le gabarit de conversation du modèle (tokens spéciaux vus en L130), en ne calculant la perte que sur les tokens **de la réponse**. Quelques dizaines de milliers d'exemples de grande qualité suffisent souvent à installer le « comportement assistant ». C'est aussi la technique que vous emploierez au module 28 pour adapter un modèle ouvert à un domaine (avec LoRA/QLoRA). Sa limite : le modèle imite ses exemples, y compris leurs défauts, et ne reçoit **aucun** signal sur ce qui rend une réponse meilleure qu'une autre.

## 3. RLHF : apprendre des préférences humaines

L'apprentissage par renforcement à partir de retours humains (Christiano et al., 2017, pour des agents ; appliqué aux LLM par InstructGPT, Ouyang et al., 2022, arXiv 2203.02155) se déroule en trois temps :

1. **SFT** sur des démonstrations.
2. **Modèle de récompense** : pour une même instruction, on échantillonne plusieurs réponses ; des annotateurs les classent ; on entraîne un modèle $r_\phi(x, y)$ à donner un score plus élevé à la réponse préférée, avec la perte de Bradley-Terry $-\log \sigma\big(r_\phi(x, y_w) - r_\phi(x, y_l)\big)$ où $y_w$ est la gagnante et $y_l$ la perdante.
3. **Optimisation par RL** (algorithme PPO, Schulman et al., 2017) de la politique $\pi_\theta$ pour maximiser la récompense, **sous contrainte** de ne pas trop s'éloigner du modèle SFT de référence :
$$\max_\theta\ \mathbb{E}_{y \sim \pi_\theta}\big[r_\phi(x, y)\big] - \beta\, \mathrm{KL}\big(\pi_\theta \,\|\, \pi_{\text{ref}}\big)$$

La pénalité KL est cruciale : sans elle, la politique découvre des réponses qui trompent le modèle de récompense (*reward hacking*) — longueur excessive, flatterie, formules creuses — plutôt que d'être réellement meilleure. Résultat marquant d'InstructGPT : les annotateurs préféraient les réponses du modèle InstructGPT de **1,3 milliard** de paramètres à celles de GPT-3 **175 milliards**. L'alignement sur les préférences valait plus qu'un facteur 100 en taille.

> ⚠️ **Piège fréquent** — Croire que le RLHF « ajoute des connaissances ». Il réorganise surtout la façon dont le modèle **utilise** ce qu'il sait déjà : choix du format, du niveau de détail, des refus. Un fait absent du pré-entraînement ne sera pas appris par quelques milliers de comparaisons ; il risque au contraire d'encourager le modèle à inventer avec assurance.

## 4. DPO : les préférences sans RL

Le RLHF est lourd : quatre modèles en mémoire (politique, référence, récompense, critique de PPO), des hyperparamètres capricieux, des échantillonnages coûteux. En 2023, Rafael Rafailov et ses coauteurs de Stanford (arXiv 2305.18290) montrent que l'objectif « récompense moins pénalité KL » admet une solution analytique, ce qui permet de **réécrire la récompense en fonction de la politique elle-même**. On obtient une simple perte de classification sur les paires de préférences :

$$\mathcal{L}_{\text{DPO}} = -\log \sigma\!\left(\beta \left[\log \frac{\pi_\theta(y_w \mid x)}{\pi_{\text{ref}}(y_w \mid x)} - \log \frac{\pi_\theta(y_l \mid x)}{\pi_{\text{ref}}(y_l \mid x)}\right]\right)$$

Lecture : on augmente la probabilité relative (par rapport à la référence) de la réponse préférée et on diminue celle de la réponse rejetée. Le coefficient $\beta$ joue le rôle de la pénalité KL : petit, il autorise de grands écarts à la référence. Plus de modèle de récompense séparé, plus d'échantillonnage pendant l'entraînement : DPO s'entraîne comme un SFT. Le sous-titre de l'article résume l'idée : « *Your Language Model is Secretly a Reward Model* ».

> 🔗 **Documentation officielle** — [Hugging Face TRL](https://huggingface.co/docs/trl/index) 🇬🇧 fournit `SFTTrainer`, `DPOTrainer` et `GRPOTrainer`, compatibles avec LoRA via PEFT ([intégration PEFT](https://huggingface.co/docs/trl/main/en/peft_integration) 🇬🇧). Vous les utiliserez au module 28.

## 5. RLAIF et IA constitutionnelle

Faire annoter des millions de comparaisons par des humains est lent et coûteux, et exposer des annotateurs à des contenus toxiques pose des questions éthiques. L'**IA constitutionnelle** d'Anthropic (Bai et al., 2022, arXiv 2212.08073) remplace une grande partie du retour humain par du retour d'**IA**, guidé par une liste explicite de principes : la « constitution ».

1. **Phase supervisée** : le modèle produit une réponse, la **critique** au regard d'un principe tiré de la constitution (« identifiez ce qui, dans votre réponse, pourrait être nuisible »), puis la **réécrit**. On fait un SFT sur les réponses révisées.
2. **Phase RL** : un modèle compare deux réponses selon un principe ; ces préférences générées par IA entraînent le modèle de récompense. C'est le **RLAIF** (*RL from AI Feedback*).

L'intérêt est double : le passage à l'échelle et la **transparence**, puisque les valeurs visées sont écrites noir sur blanc et peuvent être discutées. La lecture 17 de CS224N (Winter 2024, « Human Centered NLP ») y est en partie consacrée. Anthropic publie la constitution de ses modèles Claude sur son site.

## 6. Modèles de raisonnement : le RL sur récompenses vérifiables

En septembre 2024, OpenAI présente o1, un modèle qui « réfléchit » longuement avant de répondre. En janvier 2025, DeepSeek publie **DeepSeek-R1** (arXiv 2501.12948) avec une recette ouverte : une variante, **R1-Zero**, est obtenue par RL **directement** sur le modèle de base, sans SFT préalable, avec des récompenses calculées **par programme** : la réponse finale à un problème de mathématiques est-elle exacte ? Le code passe-t-il les tests ? Le format est-il respecté ? Au fil de l'entraînement, les réponses s'allongent spontanément, et l'on voit apparaître de la vérification, du retour en arrière et des reformulations : les auteurs parlent d'un moment « aha ». On parle de **RLVR** (*RL with Verifiable Rewards*), sujet de la séance 16 de CS336 et du devoir A5 (SFT puis RL sur des problèmes de mathématiques).

L'algorithme utilisé est **GRPO** (*Group Relative Policy Optimization*), introduit avec DeepSeekMath (Shao et al., 2024, arXiv 2402.03300). Pour chaque question, on échantillonne un **groupe** de $G$ réponses, on calcule leurs récompenses $r_1, \dots, r_G$, et l'**avantage** de chaque réponse est sa récompense normalisée **au sein du groupe** :
$$A_i = \frac{r_i - \text{moyenne}(r_1..r_G)}{\text{écart-type}(r_1..r_G)}$$
On augmente la probabilité des réponses meilleures que la moyenne du groupe, on diminue les autres. Plus besoin du réseau « critique » de PPO qui estimait la valeur attendue : le groupe sert de référence. Les modèles ouverts de 2026 exposent souvent un réglage `reasoning_effort` qui contrôle la longueur de ce raisonnement (Mistral Small 4, Qwen3.8, nov. 2026, voir L134), et la **distillation** transfère ces capacités à de petits modèles (DeepSeek-R1-Distill de 1,5 à 70 milliards de paramètres).

| | RLHF (PPO) | DPO | RLVR (GRPO) |
|---|---|---|---|
| Signal | modèle de récompense appris | paires de préférences, directement | vérificateur programmatique |
| Modèles en mémoire | politique, référence, récompense, critique | politique, référence | politique, référence (KL optionnelle) |
| Échantillonnage en ligne | oui | non (hors ligne) | oui, $G$ réponses par question |
| Risque principal | *reward hacking* du modèle de récompense | sur-optimisation des paires, verbosité | vérificateur incomplet exploité, domaines non vérifiables |
| Domaine de prédilection | style, utilité, sécurité | idem, à moindre coût | maths, code, tâches agentiques à correction automatique |

> 💡 **À retenir** — Les préférences enseignent **ce qui plaît** ; les récompenses vérifiables enseignent **ce qui est juste**. Les assistants de 2026 combinent les deux, et la qualité du vérificateur (tests unitaires, solveurs, environnements) est devenue un actif stratégique.

## 7. Démonstration exécutable : DPO et RLVR en miniature

Le script ci-dessous ne fine-tune pas un LLM (il faudrait un GPU et des heures) : il isole la **mécanique** des deux objectifs sur des politiques minuscules. Partie 1 : une politique choisit entre quatre réponses à un client ; cinq paires de préférences suffisent à DPO pour concentrer la probabilité sur la réponse « polie et exacte ». Partie 2 : une politique apprend à additionner deux chiffres **sans jamais voir la bonne réponse**, seulement une récompense de 0 ou 1 calculée par un vérificateur, avec des avantages normalisés par groupe à la GRPO.

```python
# post_entrainement_jouet.py — L133 : la perte DPO et un RL « à la GRPO » sur récompense vérifiable
import torch
import torch.nn.functional as F

torch.manual_seed(0)

# ---------- 1. DPO sur une « politique » jouet ----------
# Une question client, 4 réponses candidates. La politique est une distribution (logits) sur ces réponses.
reponses = ["Réponse sèche", "Réponse polie et exacte", "Réponse polie mais fausse", "Hors sujet"]
logits_ref = torch.zeros(4)                       # modèle de référence (après SFT) : uniforme
logits = torch.zeros(4, requires_grad=True)       # politique à entraîner, initialisée = référence
# Paires de préférences (gagnante, perdante) annotées par des humains (ou par un modèle : RLAIF)
paires = [(1, 0), (1, 2), (1, 3), (0, 3), (2, 3)]
beta = 0.1

def perte_dpo(logits, logits_ref, gagnante, perdante, beta):
    lp, lr = F.log_softmax(logits, -1), F.log_softmax(logits_ref, -1)
    marge = beta * ((lp[gagnante] - lr[gagnante]) - (lp[perdante] - lr[perdante]))
    return -F.logsigmoid(marge)                   # -log σ(β · (écart des log-ratios))

opt = torch.optim.SGD([logits], lr=1.0)
for etape in range(200):
    perte = torch.stack([perte_dpo(logits, logits_ref, g, p, beta) for g, p in paires]).mean()
    opt.zero_grad(); perte.backward(); opt.step()
print("DPO — probabilités finales :")
for r, p in zip(reponses, torch.softmax(logits, -1).tolist()):
    print(f"  {p:5.2f}  {r}")

# ---------- 2. RL sur récompense vérifiable (RLVR), avantages normalisés par groupe ----------
# Tâche : additionner deux nombres. La « politique » choisit une réponse parmi 0..18.
# La récompense est vérifiée par programme : 1 si la réponse est juste, 0 sinon. Pas de modèle de récompense.
politique = torch.nn.Sequential(                  # entrée : a et b en one-hot ; sortie : logits de la somme
    torch.nn.Linear(19 + 19, 128), torch.nn.ReLU(), torch.nn.Linear(128, 19))
opt = torch.optim.Adam(politique.parameters(), lr=0.01)

def encoder(a, b):
    return torch.cat([F.one_hot(a, 19), F.one_hot(b, 19)], -1).float()

G = 8                                             # taille du groupe : 8 réponses échantillonnées par question
for etape in range(601):
    a, b = torch.randint(0, 10, (32,)), torch.randint(0, 10, (32,))
    dist = torch.distributions.Categorical(logits=politique(encoder(a, b)))
    echantillons = dist.sample((G,))                         # (G, 32)
    recompense = (echantillons == (a + b)).float()           # vérificateur exact
    # avantage = (r - moyenne du groupe) / écart-type du groupe : pas besoin de réseau « critique »
    avantage = (recompense - recompense.mean(0)) / (recompense.std(0) + 1e-6)
    perte = -(avantage * dist.log_prob(echantillons)).mean()
    opt.zero_grad(); perte.backward(); opt.step()
    if etape % 100 == 0:
        print(f"RLVR étape {etape:3d} | taux de bonnes réponses : {recompense.mean():.2f}")

# Évaluation « gloutonne » (argmax) sur les 100 additions possibles
a, b = torch.meshgrid(torch.arange(10), torch.arange(10), indexing="ij")
a, b = a.flatten(), b.flatten()
with torch.no_grad():
    exact = (politique(encoder(a, b)).argmax(-1) == a + b).float().mean()
print(f"Exactitude gloutonne finale : {exact:.0%}")
```

Résultats obtenus sur CPU : DPO amène la réponse polie et exacte à une probabilité de 0,99 (avec $\beta = 0{,}1$ et sans régularisation supplémentaire, DPO pousse volontiers les probabilités aux extrêmes, ce qui illustre son risque de sur-optimisation). Le RLVR fait passer le taux de bonnes réponses échantillonnées de 4 % (le hasard, 1 chance sur 19) à environ 80 % en 600 étapes, et l'exactitude gloutonne finale atteint 79 % sur les 100 additions possibles : le modèle a appris l'addition à partir d'un simple signal « juste / faux ».

> 🎮 **Défi** — Dans la partie 2, que vaut l'avantage de toutes les réponses d'un groupe si les 8 réponses sont fausses ? Qu'en déduisez-vous sur les problèmes trop difficiles pour le modèle ? *(Réponse en fin de leçon.)*

## 🧪 Exercice pratique

**Consigne.** À partir du script de la section 7 :
1. **DPO** : faites varier $\beta \in \{0{,}01;\ 0{,}1;\ 1\}$ avec 50 étapes seulement. Relevez la probabilité finale de la réponse préférée. Ajoutez une paire **contradictoire** $(0, 1)$ (un annotateur préfère la réponse sèche) et observez l'effet.
2. **RLVR** : remplacez la récompense binaire par une récompense **partielle** `1 - |réponse - (a+b)| / 18`. Comparez la vitesse d'apprentissage et l'exactitude gloutonne finale.
3. **Reward hacking** : écrivez un vérificateur volontairement **défaillant** qui récompense toute réponse paire. Que devient la politique ? Rédigez trois lignes sur le lien avec les modèles de raisonnement réels.

**Critères de réussite.** (a) Un tableau présente la probabilité finale pour chaque $\beta$ ; (b) l'effet de la paire contradictoire est expliqué ; (c) les deux courbes RLVR sont comparées ; (d) le paragraphe sur le reward hacking établit que la politique optimise **le vérificateur, pas l'intention**.

<details><summary>Pistes de corrigé</summary>

- Avec 50 étapes, $\beta$ petit donne des marges faibles et un gradient faible : la politique bouge peu ; $\beta = 1$ fait converger beaucoup plus vite. La paire contradictoire ralentit la concentration sur la réponse 1 : DPO ajuste un compromis entre préférences incohérentes, comme le ferait un modèle de récompense de Bradley-Terry.
- La récompense partielle fournit un signal même quand la réponse est fausse mais proche : l'apprentissage démarre plus vite. Elle peut aussi pousser vers des réponses « presque justes » : en mathématiques réelles, on préfère souvent la récompense exacte.
- Avec le vérificateur « nombre pair », la politique converge vers des réponses paires quelconques et l'exactitude s'effondre vers celle du hasard. En vrai, un jeu de tests unitaires incomplet peut être satisfait par un code qui code « en dur » les cas testés : la qualité du vérificateur borne la qualité du modèle.
</details>

## ✅ Auto-évaluation express
1. Pourquoi ajoute-t-on une pénalité KL vers le modèle de référence dans le RLHF ?
2. Quel composant du RLHF classique DPO supprime-t-il, et comment ?
3. En quoi GRPO se passe-t-il du réseau critique de PPO ?

## 📚 Pour aller plus loin
- [Ouyang et al. (2022) — InstructGPT](https://arxiv.org/abs/2203.02155) 🇬🇧 — la recette RLHF qui a précédé ChatGPT.
- [Rafailov et al. (2023) — DPO](https://arxiv.org/abs/2305.18290) 🇬🇧 — la dérivation complète, étonnamment courte.
- [Bai et al. (2022) — Constitutional AI](https://arxiv.org/abs/2212.08073) 🇬🇧 — critique, révision et RLAIF.
- [Lee et al. (2023) — RLAIF vs. RLHF](https://arxiv.org/abs/2309.00267) 🇬🇧 — comparaison expérimentale des retours d'IA et humains.
- [DeepSeek-AI (2025) — DeepSeek-R1](https://arxiv.org/abs/2501.12948) 🇬🇧 — RL sur récompenses vérifiables, R1-Zero et distillation.
- [Hugging Face LLM Course — chapitres 11 et 12](https://huggingface.co/learn/llm-course/chapter1/1) 🇬🇧 — « Fine-tune LLMs » et « Build Reasoning Models », avec TRL.

**Réponses de l'auto-évaluation.** 1. Pour empêcher la politique de s'éloigner du modèle SFT au point d'exploiter les failles du modèle de récompense (*reward hacking*) et de perdre ses capacités linguistiques. 2. Le modèle de récompense explicite (et la boucle RL) : la récompense est réexprimée par le log-rapport entre la politique et la référence, ce qui donne une perte supervisée sur les paires. 3. La valeur de référence d'une réponse est la moyenne des récompenses de son groupe ; normaliser par le groupe fournit directement l'avantage. **Défi** : récompenses toutes nulles, donc avantages tous nuls : aucun gradient. Un problème trop difficile n'enseigne rien ; on construit des curriculums de difficulté adaptée et l'on filtre les problèmes résolus 0 ou 8 fois sur 8.
