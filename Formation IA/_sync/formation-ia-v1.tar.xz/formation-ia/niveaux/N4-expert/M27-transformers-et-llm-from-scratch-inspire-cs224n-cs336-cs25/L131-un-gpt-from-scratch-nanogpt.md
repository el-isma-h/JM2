---
id: L131
module: M27
level: N4
title: "Un GPT from scratch (nanoGPT)"
minutes: 70
objectives:
  - "Construire de bout en bout un modèle de langage décodeur (données, modèle, entraînement, génération) en PyTorch sur CPU"
  - "Appliquer les bonnes pratiques d'entraînement : initialisation, AdamW, planification du taux d'apprentissage, écrêtage du gradient, évaluation train/validation"
  - "Implémenter et comparer les stratégies d'échantillonnage : glouton, température, top-k, top-p"
  - "Diagnostiquer une mémorisation ou une fuite entre jeux d'entraînement et de validation à partir des courbes de perte"
skills: ["C4.3"]
sources:
  - { title: "Andrej Karpathy — Let's build GPT: from scratch, in code, spelled out", url: "https://www.youtube.com/watch?v=kCc8FmEb1nY", lang: "en" }
  - { title: "Andrej Karpathy — nanoGPT (dépôt GitHub)", url: "https://github.com/karpathy/nanoGPT", lang: "en" }
  - { title: "Karpathy — Neural Networks: Zero to Hero", url: "https://karpathy.ai/zero-to-hero.html", lang: "en" }
  - { title: "Holtzman et al. (2019) — The Curious Case of Neural Text Degeneration (top-p)", url: "https://arxiv.org/abs/1904.09751", lang: "en" }
  - { title: "Loshchilov & Hutter (2017) — Decoupled Weight Decay Regularization (AdamW)", url: "https://arxiv.org/abs/1711.05101", lang: "en" }
  - { title: "Stanford CS224N Winter 2026 — projet final (implémenter un GPT puis l'adapter)", url: "https://web.stanford.edu/class/cs224n/slides_w26/cs224n-2026-lecture01-intro.pdf", lang: "en" }
---

# Un GPT from scratch (nanoGPT)

> ⏱ 70 min · 🎯 Niveau 4 · 📚 Module 27

## 🎯 Ce que vous saurez faire
- Écrire **un seul fichier Python** d'environ 150 lignes qui charge un corpus français, définit un GPT, l'entraîne sur votre ordinateur portable et génère du texte.
- Vérifier qu'un entraînement démarre correctement (perte initiale attendue, initialisation, gradient) et qu'il progresse (courbes train/validation).
- Régler la génération avec la **température**, le **top-k** et le **top-p** (*nucleus sampling*), et expliquer l'effet de chacun.
- Reconnaître une **mémorisation** et une **fuite de données** entre entraînement et validation.

Cette leçon est le point culminant des trois précédentes : l'attention (L128), le bloc transformer (L129) et la tokenisation (L130) vont s'assembler en un modèle qui apprend vraiment. Elle s'inspire de la vidéo « Let's build GPT: from scratch, in code, spelled out » d'Andrej Karpathy (1 h 56, septième épisode de *Neural Networks: Zero to Hero*) et de son dépôt **nanoGPT**, dont la promesse est restée célèbre : le code le plus simple possible pour entraîner un GPT de taille moyenne. Le projet final de CS224N (Winter 2026) suit la même logique : implémenter un GPT, puis l'adapter. Le code ci-dessous est une réécriture originale, commentée en français, et pensée pour tourner **sur CPU** en quelques minutes.

## 1. Le plan d'ensemble

```
corpus.txt ─▶ tokenisation (caractères) ─▶ tenseur d'entiers ─┬─▶ 90 % entraînement
                                                              └─▶ 10 % validation
lots (x, y) où y = x décalé d'un cran
        │
        ▼
Embedding token + Embedding position ─▶ 4 blocs (LayerNorm, attention causale, MLP, résidus) ─▶ LayerNorm ─▶ tête ─▶ logits
        │
        ▼
perte = entropie croisée(logits, y) ─▶ rétropropagation ─▶ AdamW ─▶ … ─▶ génération autorégressive
```

| Hyperparamètre | Valeur ici (CPU) | GPT-2 « small » (2019) | Rôle |
|---|---|---|---|
| `block` (contexte) | 64 caractères | 1 024 tokens | longueur maximale vue par le modèle |
| `d` (dimension) | 128 | 768 | largeur du flux résiduel |
| `h` (têtes) | 4 | 12 | têtes d'attention par couche |
| `couches` | 4 | 12 | profondeur |
| vocabulaire | ~50-100 caractères | 50 257 tokens BPE | taille de la sortie |
| paramètres | ~0,8 million | ~124 millions | capacité |

Nous restons au niveau des **caractères** pour garder un vocabulaire minuscule et un code lisible ; remplacer `encode`/`decode` par le BPE de L130 ou par `tiktoken` est l'une des pistes de l'exercice. Nous gardons aussi l'architecture de GPT-2 (LayerNorm, positions apprises, GELU) pour rester fidèle à nanoGPT ; passer aux composants « 2026 » de L129 (RMSNorm, RoPE, SwiGLU) est une seconde piste.

## 2. Les données : un corpus français libre de droits

Pour apprendre, le modèle a besoin d'un texte dont nous avons le droit de nous servir. Les œuvres d'auteurs morts depuis plus de 70 ans sont dans le **domaine public** en France : Jean de La Fontaine, Victor Hugo, Jules Verne, Alexandre Dumas, Molière… Le script intègre, en secours, « Le Corbeau et le Renard » (La Fontaine, 1668) ; pour un vrai entraînement, téléchargez un roman complet au format « Plain Text UTF-8 » sur [Project Gutenberg](https://www.gutenberg.org/) et enregistrez-le sous `corpus.txt` à côté du script.

Le principe de l'apprentissage auto-supervisé est d'une simplicité désarmante : on découpe des fenêtres de `block` caractères ; l'entrée `x` est la fenêtre, la cible `y` est la **même fenêtre décalée d'un caractère**. Une seule fenêtre de 64 caractères fournit donc 64 exemples d'entraînement simultanés : prédire le 2e caractère à partir du 1er, le 3e à partir des deux premiers, et ainsi de suite jusqu'au 65e. C'est le masque causal de L128 qui rend ce parallélisme honnête.

> ⚠️ **Piège fréquent** — Découper train et validation **au hasard, caractère par caractère ou phrase par phrase**. Des passages quasi identiques se retrouvent alors des deux côtés et la perte de validation devient trompeusement basse. On coupe le texte en **deux blocs contigus** (90 % / 10 %), et l'on vérifie qu'aucun passage n'est dupliqué. Le script, avec l'extrait intégré répété 30 fois, tombe volontairement dans ce piège : vous verrez en section 6 à quoi il ressemble.

## 3. Le modèle, pièce par pièce

Le modèle reprend fidèlement ce que vous avez construit en L128-L129 :

- **Deux tables d'embeddings** : une pour les tokens ($V \times d$), une pour les positions ($\text{block} \times d$). Leur somme forme l'entrée du premier bloc.
- **Une pile de blocs pré-norm** : $x \leftarrow x + \text{Attn}(\text{LN}(x))$, puis $x \leftarrow x + \text{MLP}(\text{LN}(x))$, l'attention passant par `F.scaled_dot_product_attention(..., is_causal=True)`.
- **Une norme finale et une tête linéaire** qui produit, pour chaque position, un vecteur de $V$ **logits** (scores non normalisés pour chaque token possible).
- **Le partage des poids** (*weight tying*, Press & Wolf, 2016) : la tête de sortie réutilise la matrice d'embeddings des tokens. Intuition : si deux tokens ont des embeddings voisins en entrée, ils doivent aussi avoir des scores voisins en sortie. C'est aussi une économie de $V \times d$ paramètres, considérable quand $V$ vaut 100 000 ou plus.
- **Une initialisation soignée** : poids tirés selon une loi normale d'écart-type 0,02, biais à zéro, comme GPT-2. Lors de la mise au point de ce script, l'oubli de cette ligne donnait une perte initiale d'environ **87** au lieu de 4 : avec le partage de poids, les embeddings initialisés par défaut (écart-type 1) produisaient des logits énormes.

## 4. L'entraînement et ses garde-fous

**Le contrôle de la perte initiale.** Avant tout apprentissage, un modèle bien initialisé doit prédire une distribution à peu près **uniforme** sur les $V$ symboles. Son entropie croisée vaut alors $-\ln(1/V) = \ln V$. Avec 53 caractères, on attend $\ln 53 \approx 3{,}97$ ; le script affiche 4,03. Si vous lisez 10 ou 87, inutile d'attendre : il y a un bug d'initialisation. Ce contrôle de cinq secondes est l'un des réflexes recommandés par Karpathy, et il vous fera gagner des heures.

**L'optimiseur AdamW** (Loshchilov & Hutter, 2017) : Adam avec une régularisation par *weight decay* **découplée** du gradient, le standard de l'entraînement des transformers. Nous l'avons rencontré au module 26.

**Le taux d'apprentissage planifié** : `OneCycleLR` monte linéairement pendant les 10 premiers pourcents des itérations (*warmup*), puis redescend en cosinus. Le warmup évite les grands pas au moment où les statistiques d'Adam sont encore mal estimées ; la décroissance finale permet de « se poser » dans un bon minimum.

**L'écrêtage du gradient** (`clip_grad_norm_` à 1,0) : si une itération produit un gradient anormalement grand, on le ramène à une norme maximale. C'est une assurance contre les pics de perte qui ruinent un entraînement.

**L'évaluation régulière** sur train **et** validation, en mode `eval()` (dropout désactivé) et sans calcul de gradient. L'écart entre les deux courbes est votre principal outil de diagnostic.

## 5. La génération : température, top-k, top-p

Une fois entraîné, le modèle génère **un token à la fois** : il calcule les logits du dernier position, les transforme en probabilités, tire un token, l'ajoute à la séquence et recommence. Trois réglages contrôlent le tirage :

| Réglage | Opération sur les logits $z$ | Effet | Usage typique |
|---|---|---|---|
| Glouton | $\arg\max z$ | déterministe, souvent répétitif | extraction de données, code |
| Température $\tau$ | $\text{softmax}(z / \tau)$ | $\tau < 1$ : distribution plus pointue, texte plus sûr et plus prévisible ; $\tau > 1$ : plus créatif et plus risqué | $\tau \approx 0{,}2$ pour une réponse factuelle, $0{,}7$-$1$ pour une rédaction |
| Top-k | ne garder que les $k$ meilleurs logits | coupe la longue traîne des tokens absurdes | $k$ de 10 à 50 |
| Top-p (nucleus) | ne garder que le plus petit ensemble dont la probabilité cumulée atteint $p$ | taille du « noyau » adaptative : étroit quand le modèle est sûr, large quand il hésite | $p$ de 0,9 à 0,95 |

Le top-p a été proposé par Holtzman et al. (2019) après un constat : la recherche par faisceau et le tirage pur produisent respectivement des textes répétitifs et des textes incohérents. En adaptant la taille du noyau à la confiance du modèle, le nucleus sampling corrige les deux défauts. Les paramètres `temperature` et `top_p` que vous réglez dans les API (OpenAI, Mistral ; Claude jusqu'à la version 4.6, ces paramètres étant refusés à partir de 4.7, voir L008) ou dans Ollama sont exactement ceux-ci.

> 💡 **À retenir** — La température **déforme** la distribution, top-k et top-p la **tronquent**. On les combine souvent : d'abord diviser par $\tau$, puis tronquer, puis tirer. À $\tau \to 0$, tout converge vers le glouton.

## 6. Le code complet

Installez `pip install torch numpy`, copiez le fichier, lancez `python mini_gpt.py`. Comptez de une à quelques minutes sur un portable récent (le script a été testé sur un serveur CPU à deux cœurs, nettement plus lent, en 6 à 7 minutes).

```python
# mini_gpt.py — L131 : un GPT au niveau caractère, entraîné sur CPU (inspiré de nanoGPT, code original)
# Usage : python mini_gpt.py            (utilise corpus.txt s'il existe, sinon un extrait intégré)
import math, os, time
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(1337)

# ---------- 1. Données ----------
EXTRAIT = """Maître Corbeau, sur un arbre perché,
Tenait en son bec un fromage.
Maître Renard, par l'odeur alléché,
Lui tint à peu près ce langage :
Hé ! bonjour, Monsieur du Corbeau.
Que vous êtes joli ! que vous me semblez beau !
Sans mentir, si votre ramage
Se rapporte à votre plumage,
Vous êtes le Phénix des hôtes de ces bois.
A ces mots le Corbeau ne se sent pas de joie ;
Et pour montrer sa belle voix,
Il ouvre un large bec, laisse tomber sa proie.
Le Renard s'en saisit, et dit : Mon bon Monsieur,
Apprenez que tout flatteur
Vit aux dépens de celui qui l'écoute :
Cette leçon vaut bien un fromage, sans doute.
Le Corbeau, honteux et confus,
Jura, mais un peu tard, qu'on ne l'y prendrait plus.
"""
texte = open("corpus.txt", encoding="utf-8").read() if os.path.exists("corpus.txt") else EXTRAIT * 30
chars = sorted(set(texte))
stoi = {c: i for i, c in enumerate(chars)}
itos = {i: c for c, i in stoi.items()}
encode = lambda s: [stoi[c] for c in s]
decode = lambda ids: "".join(itos[i] for i in ids)

data = torch.tensor(encode(texte), dtype=torch.long)
n = int(0.9 * len(data))
train, val = data[:n], data[n:]
print(f"Corpus : {len(texte):,} caractères | vocabulaire : {len(chars)} symboles")

# ---------- 2. Hyperparamètres (taille « CPU ») ----------
cfg = dict(block=64, d=128, h=4, couches=4, dropout=0.1)
batch, iters, lr, eval_every = 32, 1000, 3e-3, 200

def lot(split):
    src = train if split == "train" else val
    ix = torch.randint(len(src) - cfg["block"] - 1, (batch,))
    x = torch.stack([src[i:i + cfg["block"]] for i in ix])
    y = torch.stack([src[i + 1:i + cfg["block"] + 1] for i in ix])   # cible = entrée décalée d'un cran
    return x, y

# ---------- 3. Modèle ----------
class Bloc(nn.Module):
    def __init__(self, d, h, p):
        super().__init__()
        self.h = h
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.qkv, self.proj = nn.Linear(d, 3 * d), nn.Linear(d, d)
        self.mlp = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d), nn.Dropout(p))
        self.p = p
    def forward(self, x):
        B, T, D = x.shape
        q, k, v = self.qkv(self.ln1(x)).split(D, dim=-1)
        q, k, v = (t.view(B, T, self.h, D // self.h).transpose(1, 2) for t in (q, k, v))
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True,
                                           dropout_p=self.p if self.training else 0.0)
        x = x + self.proj(y.transpose(1, 2).reshape(B, T, D))
        return x + self.mlp(self.ln2(x))

class MiniGPT(nn.Module):
    def __init__(self, vocab, block, d, h, couches, dropout):
        super().__init__()
        self.block = block
        self.tok = nn.Embedding(vocab, d)
        self.pos = nn.Embedding(block, d)                 # positions apprises, comme GPT-2
        self.blocs = nn.Sequential(*[Bloc(d, h, dropout) for _ in range(couches)])
        self.ln_f = nn.LayerNorm(d)
        self.tete = nn.Linear(d, vocab, bias=False)
        self.tete.weight = self.tok.weight                # partage des poids entrée/sortie (weight tying)
        self.apply(self._init)

    @staticmethod
    def _init(m):
        # petite initialisation (σ = 0,02, comme GPT-2) : sinon les logits initiaux explosent
        if isinstance(m, (nn.Linear, nn.Embedding)):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
        if isinstance(m, nn.Linear) and m.bias is not None:
            nn.init.zeros_(m.bias)

    def forward(self, idx, cibles=None):
        T = idx.size(1)
        x = self.tok(idx) + self.pos(torch.arange(T))
        logits = self.tete(self.ln_f(self.blocs(x)))
        perte = None if cibles is None else F.cross_entropy(logits.view(-1, logits.size(-1)), cibles.view(-1))
        return logits, perte

    @torch.no_grad()
    def generer(self, idx, n, temperature=1.0, top_k=None, top_p=None):
        for _ in range(n):
            logits, _ = self(idx[:, -self.block:])
            logits = logits[:, -1, :] / max(temperature, 1e-5)          # température
            if top_k is not None:                                         # top-k : garder les k meilleurs
                seuil = torch.topk(logits, top_k).values[:, [-1]]
                logits = logits.masked_fill(logits < seuil, float("-inf"))
            if top_p is not None:                                         # top-p (nucleus)
                tri, ordre = torch.sort(logits, descending=True)
                cumul = torch.softmax(tri, -1).cumsum(-1)
                retirer = cumul - torch.softmax(tri, -1) > top_p          # on garde le token qui franchit p
                tri = tri.masked_fill(retirer, float("-inf"))
                logits = torch.full_like(logits, float("-inf")).scatter(-1, ordre, tri)
            suivant = torch.multinomial(torch.softmax(logits, -1), 1)
            idx = torch.cat([idx, suivant], dim=1)
        return idx

model = MiniGPT(len(chars), **cfg)
print(f"Paramètres : {sum(p.numel() for p in model.parameters()) / 1e6:.2f} M")
print(f"Perte attendue au hasard : ln({len(chars)}) = {math.log(len(chars)):.2f}")

# ---------- 4. Entraînement ----------
opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.1)
sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=lr, total_steps=iters, pct_start=0.1)

@torch.no_grad()
def evaluer():
    model.eval()
    res = {s: torch.stack([model(*lot(s))[1] for _ in range(10)]).mean().item() for s in ("train", "val")}
    model.train()
    return res

t0 = time.time()
for it in range(iters):
    if it % eval_every == 0 or it == iters - 1:
        r = evaluer()
        print(f"it {it:5d} | train {r['train']:.3f} | val {r['val']:.3f} | {time.time() - t0:5.1f} s")
    x, y = lot("train")
    _, perte = model(x, y)
    opt.zero_grad(set_to_none=True)
    perte.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)       # écrêtage du gradient
    opt.step(); sched.step()

torch.save(model.state_dict(), "mini_gpt.pt")

# ---------- 5. Génération ----------
model.eval()
amorce = torch.tensor([encode("Maître ")], dtype=torch.long)
for reglage in (dict(temperature=0.5), dict(temperature=1.0, top_k=10), dict(temperature=1.2, top_p=0.9)):
    torch.manual_seed(0)
    print(f"\n--- {reglage} ---")
    print(decode(model.generer(amorce, 200, **reglage)[0].tolist()))
```

**Lecture des résultats avec l'extrait intégré.** La perte part de 4,03 (contrôle réussi), tombe sous 0,15 dès 200 itérations et finit vers 0,06, **en validation comme en entraînement**. Les trois réglages d'échantillonnage restituent alors la fable mot pour mot. Ce n'est pas un modèle génial : c'est une **mémorisation**. Le texte étant la même fable répétée 30 fois, le bloc de validation contient exactement des passages vus à l'entraînement ; la courbe de validation ne mesure donc plus la généralisation. C'est le piège annoncé en section 2, en grandeur réelle.

**Avec un vrai corpus.** Pour tester la généralisation, nous avons entraîné exactement le même script sur un corpus d'environ 700 000 caractères de prose pédagogique française, sans répétition (vocabulaire de 96 symboles, perte initiale 4,62 pour $\ln 96 \approx 4{,}56$). En 1 000 itérations et environ 3 minutes sur CPU, la perte descend à **1,64 en entraînement et 1,70 en validation** : les deux courbes restent proches, signe d'un apprentissage et non d'une mémorisation. Les générations sont alors du « faux français » très instructif. À $\tau = 0{,}5$, le modèle radote des mots fréquents (« de le contre de le comparatiques de pas de compte… ») : basse température, faible diversité. Avec top-k = 10 à $\tau = 1$, on lit « Maître dans un cabne de le cas, la suive. », des retours à la ligne et une numérotation de sections imitant la mise en page du corpus. Avec top-p = 0,9 à $\tau = 1{,}2$, apparaissent davantage de mots inventés et de chiffres incongrus. Le modèle a appris l'orthographe locale, les espaces, la ponctuation et la structure des documents, mais pas le sens : avec 0,8 million de paramètres et 3 minutes de calcul, c'est exactement ce qu'il faut attendre. Plus de données, de paramètres et d'itérations améliorent ces résultats de façon prévisible : c'est le sujet de L132.

## 7. Et après ? Passer à l'échelle

Le même code, avec quatre changements, devient un véritable outil de recherche :

1. **Tokenizer BPE** (L130) au lieu des caractères : séquences 3 à 4 fois plus courtes, contexte plus riche.
2. **GPU, précision mixte et compilation** : `model.to("cuda")`, `torch.autocast(dtype=torch.bfloat16)` et `torch.compile(model)` multiplient la vitesse par un facteur important.
3. **Plus de données et un modèle plus grand**, dimensionnés ensemble selon les lois d'échelle de L132.
4. **Un vrai suivi** : journalisation des pertes, sauvegardes régulières, reprise après interruption.

nanoGPT reproduit ainsi GPT-2 (124 M paramètres) sur OpenWebText, sur un nœud de 8 GPU A100 en quelques jours d'après son README. Karpathy a depuis publié d'autres projets pédagogiques de la même veine ; le cours CS336 de Stanford pousse la logique jusqu'au bout en faisant écrire aux étudiants leur propre tokenizer, leur transformer et leur optimiseur (devoir A1), puis leurs noyaux GPU (A2).

> 🔗 **Documentation officielle** — [nanoGPT](https://github.com/karpathy/nanoGPT) 🇬🇧 (README : configurations, reproduction de GPT-2, échantillonnage) · [PyTorch — torch.compile](https://pytorch.org/docs/stable/generated/torch.compile.html) 🇬🇧.

> 🎮 **Défi** — À l'itération 0, votre script affiche une perte de 4,62 avec un vocabulaire de 96 caractères. Votre initialisation est-elle correcte ? Et si elle affichait 6,9 ? *(Réponse en fin de leçon.)*

## 🧪 Exercice pratique

**Consigne.**
1. Téléchargez un roman français du domaine public sur Project Gutenberg (au moins 500 000 caractères), nettoyez l'en-tête et le pied de page anglais de Gutenberg, enregistrez-le sous `corpus.txt`.
2. Entraînez le modèle tel quel et notez la meilleure perte de validation.
3. **Ablation** : supprimez l'embedding de position (`x = self.tok(idx)` seulement), réentraînez, comparez. Expliquez le résultat avec L128.
4. **Échantillonnage** : générez 300 caractères avec la même amorce et la même graine pour $\tau \in \{0{,}2;\ 0{,}8;\ 1{,}5\}$, puis avec top-p à 0,9. Décrivez en une phrase chaque sortie.
5. **Bonus** : remplacez la tokenisation par caractères par le BPE de L130 (vocabulaire de 512) et comparez la qualité du texte à nombre d'itérations égal.

**Critères de réussite.** (a) La perte initiale est à moins de 0,2 de $\ln V$ ; (b) la perte de validation finale avec positions est inférieure d'au moins 0,1 à celle obtenue sans positions ; (c) l'écart train/validation est commenté (sur-apprentissage ou non) ; (d) les descriptions d'échantillonnage associent bien basse température et répétitions, haute température et fautes ou mots inventés.

<details><summary>Pistes de corrigé</summary>

- Sans positions, le modèle ne sait plus **où** se trouvent les caractères du contexte : l'attention devient un « sac de caractères » (équivariance par permutation, L128). La perte de validation remonte nettement, et le texte généré perd la structure des mots.
- À $\tau = 0{,}2$, le texte est très régulier, souvent répétitif (boucles sur des mots fréquents) ; à $0{,}8$, il est varié et plausible ; à $1{,}5$, les mots inventés et la ponctuation erratique se multiplient. Le top-p à 0,9 coupe les pires écarts tout en gardant de la variété.
- Si la perte d'entraînement continue de baisser alors que la validation remonte, le modèle sur-apprend : augmentez le `dropout`, réduisez la taille du modèle ou ajoutez des données.
- Avec le BPE, chaque token porte plus de sens : à itérations égales, les mots sont plus souvent corrects, mais le vocabulaire plus grand demande plus de données pour bien apprendre chaque embedding.
</details>

## ✅ Auto-évaluation express
1. Pourquoi une fenêtre de 64 caractères fournit-elle 64 exemples d'entraînement à la fois ?
2. Quelle valeur de perte attendez-vous à l'itération 0 pour un vocabulaire de $V$ symboles, et pourquoi ?
3. Quelle est la différence de principe entre top-k et top-p ?

## 📚 Pour aller plus loin
- [Karpathy — Let's build GPT: from scratch, in code, spelled out](https://www.youtube.com/watch?v=kCc8FmEb1nY) 🇬🇧 — la construction pas à pas qui a inspiré cette leçon.
- [Karpathy — Neural Networks: Zero to Hero](https://karpathy.ai/zero-to-hero.html) 🇬🇧 — les huit épisodes, de micrograd au tokenizer.
- [Holtzman et al. (2019) — Nucleus sampling](https://arxiv.org/abs/1904.09751) 🇬🇧 — pourquoi la génération « dégénère » et comment le top-p y remédie.
- [Press & Wolf (2016) — Using the Output Embedding to Improve Language Models](https://arxiv.org/abs/1608.05859) 🇬🇧 — l'origine du partage de poids.
- [Stanford CS336 — Language Modeling from Scratch](https://cs336.stanford.edu/) 🇬🇧 — le devoir A1 (tokenizer, transformer, optimiseur, boucle d'entraînement), sous licence MIT.

**Réponses de l'auto-évaluation.** 1. Parce que la cible est la fenêtre décalée d'un cran et que le masque causal permet de calculer en une seule passe les 64 prédictions « caractère suivant » à partir de préfixes de longueur 1 à 64. 2. $\ln V$, l'entropie croisée d'une prédiction uniforme : un modèle bien initialisé n'a encore aucune préférence. 3. Top-k garde un **nombre fixe** de candidats ; top-p garde un **nombre variable**, le plus petit ensemble dont la probabilité cumulée atteint $p$, qui s'adapte à la confiance du modèle. **Défi** : $\ln 96 \approx 4{,}56$, donc 4,62 est correct ; 6,9 signalerait des logits initiaux trop grands (initialisation à revoir).
