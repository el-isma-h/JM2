---
id: L128
module: M27
level: N4
title: "Le mécanisme d'attention"
minutes: 60
objectives:
  - "Expliquer le rôle des requêtes, clés et valeurs et dériver la formule de l'attention par produit scalaire mis à l'échelle"
  - "Justifier mathématiquement la division par la racine de d_k et l'usage du masque causal"
  - "Implémenter en PyTorch une attention multi-têtes causale et la vérifier contre F.scaled_dot_product_attention"
  - "Évaluer le coût mémoire et calcul de l'attention en fonction de la longueur de séquence"
skills: ["C4.3"]
sources:
  - { title: "Vaswani et al. (2017) — Attention Is All You Need", url: "https://arxiv.org/abs/1706.03762", lang: "en" }
  - { title: "Bahdanau, Cho, Bengio (2014) — Neural Machine Translation by Jointly Learning to Align and Translate", url: "https://arxiv.org/abs/1409.0473", lang: "en" }
  - { title: "Stanford CS224N Winter 2024 — lecture 8 Transformers", url: "https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1244/", lang: "en" }
  - { title: "Stanford CS25 Transformers United V6", url: "https://web.stanford.edu/class/cs25/index.html", lang: "en" }
  - { title: "PyTorch — torch.nn.functional.scaled_dot_product_attention", url: "https://pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html", lang: "en" }
---

# Le mécanisme d'attention

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 27

## 🎯 Ce que vous saurez faire
- Expliquer avec une analogie concrète, puis avec une formule, ce que sont les **requêtes** (*queries*), les **clés** (*keys*) et les **valeurs** (*values*).
- Démontrer pourquoi on divise les scores par $\sqrt{d_k}$, et ce qui se passe si on l'oublie.
- Construire le **masque causal** qui empêche un modèle de langage de « tricher » en lisant le futur.
- Implémenter une **attention multi-têtes** (*multi-head attention*) complète en PyTorch, sur CPU, et la valider contre l'implémentation optimisée de la bibliothèque.
- Chiffrer le coût quadratique de l'attention et comprendre pourquoi il conditionne la taille des fenêtres de contexte.

Ce module est le cœur « moteur » du niveau expert. Dans le module 24 (leçon L111, §4.3), vous avez lu la formule de l'attention comme un produit de matrices ; dans le module 26, vous avez entraîné des réseaux profonds avec PyTorch. Nous gardons exactement les mêmes notations : une séquence de $T$ tokens est une matrice $X \in \mathbb{R}^{T \times d}$, chaque ligne étant l'embedding d'un token de dimension $d$ (on écrit aussi $d_{\text{model}}$).

## 1. D'où vient l'attention ? Une courte histoire

En 2014, la traduction automatique neuronale reposait sur des réseaux récurrents (RNN, LSTM) de type encodeur-décodeur : l'encodeur lisait la phrase source mot à mot et la comprimait dans **un seul vecteur** de taille fixe, que le décodeur devait ensuite « déplier » en phrase cible. Pour une phrase de 50 mots, ce goulot d'étranglement était catastrophique. Dzmitry Bahdanau, Kyunghyun Cho et Yoshua Bengio proposent alors de laisser le décodeur **regarder à nouveau tous les états de l'encodeur** et d'en faire une moyenne pondérée, recalculée à chaque mot produit : c'est la naissance de l'attention (arXiv 1409.0473).

Trois ans plus tard, huit chercheurs de Google publient « Attention Is All You Need » (Vaswani et al., NeurIPS 2017, arXiv 1706.03762). Leur idée radicale : **supprimer complètement la récurrence** et ne garder que l'attention, appliquée à la séquence sur elle-même (*self-attention*). Conséquence décisive : tous les tokens sont traités **en parallèle**, ce qui colle parfaitement aux GPU. Presque tous les grands modèles de 2026 (Claude, GPT, Gemini, Mistral, Qwen, DeepSeek, Kimi…) descendent de cette architecture, même si leurs variantes (MoE, attention latente, fenêtres glissantes) seront l'objet de la leçon L134.

> 🔗 **Documentation officielle** — Le séminaire Stanford [CS25 Transformers United V6](https://web.stanford.edu/class/cs25/index.html) 🇬🇧 s'ouvre chaque saison par un « Overview of Transformers » qui retrace cette histoire ; le cours [CS224N Winter 2024](https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1244/) 🇬🇧 y consacre sa lecture 8. Ils servent ici de sources d'inspiration : le contenu de cette leçon est original.

## 2. L'intuition : un moteur de recherche interne

Imaginez le service archives d'un cabinet d'expertise comptable. Un collaborateur arrive avec une **question** (« le dossier TVA de la boulangerie Martin »). Chaque classeur porte une **étiquette** sur sa tranche, et contient un **contenu**. Le collaborateur compare sa question à toutes les étiquettes, repère celles qui correspondent le mieux, puis lit surtout le contenu de ces classeurs-là, un peu celui des voisins, et presque pas le reste.

L'attention fait exactement cela, pour chaque token :

| Rôle | Dans l'analogie | Dans le modèle | Question que se pose le token |
|---|---|---|---|
| Requête $q_i$ | la question du collaborateur | $q_i = x_i W_Q$ | « Qu'est-ce que je cherche ? » |
| Clé $k_j$ | l'étiquette du classeur | $k_j = x_j W_K$ | « Qu'est-ce que je propose ? » |
| Valeur $v_j$ | le contenu du classeur | $v_j = x_j W_V$ | « Qu'est-ce que je transmets si on me choisit ? » |

Prenons la phrase : « *Le comptable a relancé le client car il n'avait pas payé.* » Pour produire une bonne représentation de « il », le modèle doit savoir à qui ce pronom renvoie. La requête de « il » (qui encode quelque chose comme « je cherche un nom masculin, sujet d'une dette ») sera fortement alignée avec la clé de « client » ; le vecteur de sortie de « il » héritera donc surtout de la valeur de « client ». Personne n'a programmé cette règle : les matrices $W_Q, W_K, W_V$ sont **apprises** par descente de gradient.

> 💡 **À retenir** — Séparer clé et valeur est l'idée maîtresse : ce qui sert à **être trouvé** (la clé) n'est pas forcément ce qui mérite d'être **transmis** (la valeur). Un même token peut s'annoncer comme « nom propre » et transmettre « entreprise du secteur BTP ».

## 3. La formule, pas à pas

À partir de $X \in \mathbb{R}^{T \times d}$, on calcule trois projections linéaires avec des matrices apprises $W_Q, W_K \in \mathbb{R}^{d \times d_k}$ et $W_V \in \mathbb{R}^{d \times d_v}$ :

$$Q = X W_Q, \qquad K = X W_K, \qquad V = X W_V$$

puis l'attention par **produit scalaire mis à l'échelle** (*scaled dot-product attention*) :

$$\text{Attention}(Q, K, V) = \text{softmax}\!\left(\frac{QK^\top}{\sqrt{d_k}}\right) V$$

Lisons-la de l'intérieur vers l'extérieur :

1. $S = QK^\top \in \mathbb{R}^{T \times T}$ : la case $(i, j)$ vaut $q_i \cdot k_j$, la similarité entre la requête du token $i$ et la clé du token $j$.
2. Division par $\sqrt{d_k}$ : une remise à l'échelle (section 4).
3. $\text{softmax}$ appliqué **ligne par ligne** : chaque ligne devient une distribution de probabilités $\alpha_{i,\cdot}$ (positive, somme égale à 1), comme vu en L113.
4. Produit par $V$ : la sortie du token $i$ est $o_i = \sum_j \alpha_{ij}\, v_j$, une **moyenne pondérée des valeurs**.

```
X (T×d) ─W_Q─▶ Q ─┐
X (T×d) ─W_K─▶ K ─┴─▶ Q·Kᵀ (T×T) ─÷√d_k─▶ [masque] ─▶ softmax ─▶ α (T×T) ─┐
X (T×d) ─W_V─▶ V ─────────────────────────────────────────────────────────┴─▶ α·V (T×d_v)
```

Une propriété souvent négligée : sans information de position, l'attention est **équivariante par permutation**. Si vous mélangez l'ordre des tokens d'entrée, les sorties sont mélangées de la même façon, mais chacune reste identique. Pour le modèle, « le chien mord le facteur » et « le facteur mord le chien » seraient le même sac de mots ! C'est pourquoi la leçon L129 ajoute des **encodages de position**.

## 4. Pourquoi diviser par $\sqrt{d_k}$ ?

Supposons que les composantes de $q$ et $k$ soient indépendantes, de moyenne 0 et de variance 1 (c'est à peu près le cas à l'initialisation). Leur produit scalaire $q \cdot k = \sum_{m=1}^{d_k} q_m k_m$ est une somme de $d_k$ termes de variance 1, donc de **variance $d_k$** et d'écart-type $\sqrt{d_k}$ (rappel de L113 : les variances de variables indépendantes s'additionnent). Avec $d_k = 128$, typique d'une tête de LLM, les scores ont un écart-type d'environ 11.

Or le softmax d'un vecteur dont les écarts sont de l'ordre de 10 ou 20 est quasiment un **one-hot** : toute la masse tombe sur le maximum. Le gradient du softmax devient alors presque nul partout (saturation), et l'apprentissage stagne. Diviser par $\sqrt{d_k}$ ramène l'écart-type des scores à 1, dans la zone où le softmax reste « doux » et différentiable utilement. Le script de la section 7 le vérifie numériquement : pour $d_k = 4096$, l'écart-type brut vaut 64, et 1,00 après mise à l'échelle.

> ⚠️ **Piège fréquent** — Diviser par $d_k$ au lieu de $\sqrt{d_k}$. Cela écrase les scores (écart-type $1/\sqrt{d_k}$) et rend l'attention presque **uniforme** : chaque token fait la moyenne de tous les autres, sans rien sélectionner. Le modèle apprend quand même, mais beaucoup plus lentement. Le facteur exact compte.

## 5. Le masque causal : interdiction de lire la suite

Un modèle de langage de type GPT apprend à prédire le token $t+1$ à partir des tokens $1 \dots t$. Pendant l'entraînement, on lui donne pourtant toute la phrase d'un coup, pour profiter du parallélisme. Sans précaution, le token 3 pourrait « regarder » le token 4 qu'il est censé deviner : c'est la fuite d'information par excellence.

La parade est élégante : avant le softmax, on remplace par $-\infty$ tous les scores $S_{ij}$ tels que $j > i$. Comme $e^{-\infty} = 0$, ces positions reçoivent un poids nul, et chaque ligne se renormalise sur le passé uniquement. La matrice des poids devient **triangulaire inférieure** :

```
           clés →  t1    t2    t3    t4
requête t1       [1.00  0     0     0   ]
requête t2       [0.49  0.51  0     0   ]
requête t3       [0.62  0.03  0.35  0   ]
requête t4       [0.20  0.62  0.10  0.07]
```

Ce masque est ce qui distingue les trois grandes familles d'architectures :

| Famille | Masque | Exemples | Usage typique |
|---|---|---|---|
| Encodeur seul | aucun (bidirectionnel) | BERT, modèles d'embeddings | classification, recherche sémantique |
| Décodeur seul | causal | GPT, Claude, Llama, Mistral, Qwen | génération de texte, chat, agents |
| Encodeur-décodeur | aucun côté encodeur, causal côté décodeur, + attention croisée | T5, transformer original de 2017 | traduction, résumé |

Dans l'**attention croisée** (*cross-attention*), les requêtes viennent du décodeur et les clés/valeurs de l'encodeur : c'est la version moderne de l'idée de Bahdanau.

## 6. Plusieurs têtes valent mieux qu'une

Une seule attention calcule une seule moyenne pondérée par token. Or un token a souvent besoin de plusieurs informations à la fois : son sujet grammatical, le dernier montant cité, le nom de l'entreprise, la négation qui le précède… L'**attention multi-têtes** découpe l'espace de dimension $d$ en $h$ sous-espaces de dimension $d_k = d/h$, calcule $h$ attentions indépendantes en parallèle, concatène les résultats et les mélange avec une matrice de sortie $W_O \in \mathbb{R}^{d \times d}$ :

$$\text{MHA}(X) = \text{Concat}(\text{tête}_1, \dots, \text{tête}_h)\, W_O, \qquad \text{tête}_i = \text{Attention}(XW_Q^{(i)}, XW_K^{(i)}, XW_V^{(i)})$$

Point remarquable : à $d$ fixé, le nombre de paramètres **ne dépend pas de $h$** ($4d^2$ pour $W_Q, W_K, W_V, W_O$ sans biais). On ne paie pas plus cher, on répartit simplement la capacité. Les études d'interprétabilité ont identifié des têtes spécialisées, par exemple des *induction heads* qui recopient un motif déjà vu dans le contexte, mécanisme central de l'apprentissage « en contexte ».

> 🎮 **Défi** — Avec $d = 4096$ et $h = 32$ (dimensions courantes d'un modèle de 7-8 milliards de paramètres), quelle est la dimension de chaque tête, et combien de paramètres compte la couche d'attention complète ? *(Réponse en fin de leçon.)*

## 7. Implémentation complète en PyTorch (CPU)

Le script suivant implémente l'attention « à la main », le masque causal, la version multi-têtes, puis vérifie trois choses : chaque ligne de poids somme à 1, notre résultat coïncide avec `F.scaled_dot_product_attention` (la fonction optimisée de PyTorch, qui dispatche vers des noyaux de type FlashAttention sur GPU), et la mise à l'échelle stabilise bien la variance. Installez simplement `pip install torch numpy`.

```python
# attention_from_scratch.py — L128 : attention, masque causal, multi-têtes
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(0)

def attention(q, k, v, causal=False):
    """q, k, v : (..., T, d_k). Renvoie (sortie, poids)."""
    d_k = q.size(-1)
    scores = q @ k.transpose(-2, -1) / math.sqrt(d_k)          # (..., T, T)
    if causal:
        T = q.size(-2)
        masque = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
        scores = scores.masked_fill(masque, float("-inf"))      # interdit le futur
    poids = torch.softmax(scores, dim=-1)                       # chaque ligne somme à 1
    return poids @ v, poids

class MultiHeadAttention(nn.Module):
    def __init__(self, d_model: int, n_heads: int):
        super().__init__()
        assert d_model % n_heads == 0, "d_model doit être divisible par n_heads"
        self.h, self.d_k = n_heads, d_model // n_heads
        self.qkv = nn.Linear(d_model, 3 * d_model, bias=False)  # W_Q, W_K, W_V fusionnées
        self.proj = nn.Linear(d_model, d_model, bias=False)     # W_O

    def forward(self, x, causal=True):
        B, T, D = x.shape
        q, k, v = self.qkv(x).split(D, dim=-1)
        # (B, T, D) -> (B, h, T, d_k) : chaque tête travaille dans son sous-espace
        q, k, v = (t.view(B, T, self.h, self.d_k).transpose(1, 2) for t in (q, k, v))
        y, _ = attention(q, k, v, causal=causal)
        y = y.transpose(1, 2).contiguous().view(B, T, D)       # concaténation des têtes
        return self.proj(y)

if __name__ == "__main__":
    # 1) Mini-exemple lisible : 4 tokens, d_k = 8
    T, d_k = 4, 8
    q, k, v = torch.randn(T, d_k), torch.randn(T, d_k), torch.randn(T, d_k)
    sortie, poids = attention(q, k, v, causal=True)
    print("Poids d'attention causaux (triangulaires) :\n", poids.round(decimals=2))
    print("Somme de chaque ligne :", poids.sum(-1))

    # 2) Vérification contre l'implémentation optimisée de PyTorch
    ref = F.scaled_dot_product_attention(q[None], k[None], v[None], is_causal=True)[0]
    print("Écart max avec F.scaled_dot_product_attention :", (sortie - ref).abs().max().item())

    # 3) Pourquoi diviser par sqrt(d_k) ? Variance des scores selon la dimension
    for d in (16, 256, 4096):
        a, b = torch.randn(10_000, d), torch.randn(10_000, d)
        brut = (a * b).sum(-1)
        print(f"d_k={d:5d}  écart-type brut={brut.std():6.1f}  mis à l'échelle={(brut / math.sqrt(d)).std():.2f}")

    # 4) Multi-têtes sur un lot
    mha = MultiHeadAttention(d_model=64, n_heads=8)
    x = torch.randn(2, 10, 64)                                  # (batch, T, d_model)
    print("Sortie multi-têtes :", tuple(mha(x).shape),
          "| paramètres :", sum(p.numel() for p in mha.parameters()))
```

Sortie obtenue (PyTorch 2.x, CPU) : un écart maximal de l'ordre de $10^{-7}$ avec la fonction officielle (simple bruit d'arrondi en float32), des écarts-types bruts de 4, 16 et 64 ramenés à 1,00, et $16\,384 = 4 \times 64^2$ paramètres pour la couche multi-têtes, conformément au calcul de la section 6.

> 🔗 **Documentation officielle** — [torch.nn.functional.scaled_dot_product_attention](https://pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html) 🇬🇧 : paramètres `attn_mask`, `is_causal`, `dropout_p`, `scale`, et choix automatique du noyau (FlashAttention, *memory-efficient*, mathématique).

## 8. Le prix à payer : un coût quadratique

La matrice $QK^\top$ a $T \times T$ cases, pour chaque tête et chaque couche. Le calcul coûte de l'ordre de $T^2 \cdot d$ opérations et, dans une implémentation naïve, la mémoire croît en $T^2$. Doubler le contexte quadruple ce poste. Quelques ordres de grandeur, pour une seule tête en float32 :

| Longueur $T$ | Cases de $QK^\top$ | Mémoire naïve (4 octets) |
|---|---|---|
| 1 024 | ~1 million | 4 Mo |
| 32 768 | ~1,07 milliard | 4,3 Go |
| 1 048 576 (1M) | ~1,1 × 10¹² | ~4,4 To |

Personne ne matérialise donc cette matrice pour de longs contextes. **FlashAttention** (Dao et al., 2022) calcule l'attention par tuiles dans la mémoire rapide du GPU, sans jamais stocker la matrice complète : même résultat exact, mémoire linéaire en $T$. Le cours CS336 de Stanford consacre ses séances 5-6 (GPU, noyaux, Triton) et son devoir A2 à réimplémenter FlashAttention 2. En génération, on évite aussi de recalculer les clés et valeurs déjà vues grâce au **KV cache**, dont le coût mémoire pilote toutes les innovations présentées en L134 (GQA, MQA, attention latente).

> 💡 **À retenir** — L'attention est **exacte mais quadratique**. Les « contextes de 1 million de tokens » annoncés en 2026 (Kimi K3, DeepSeek V4, nov. 2026, voir L134) reposent sur des noyaux optimisés, la réduction du KV cache et souvent des schémas d'attention partiellement locaux, pas sur une attention naïve.

## 🧪 Exercice pratique

**Consigne.** À partir du script de la section 7 :
1. Vérifiez expérimentalement l'**équivariance par permutation** : pour une entrée `x` de forme `(1, 6, 64)` et une permutation aléatoire `perm = torch.randperm(6)`, montrez que `mha(x[:, perm], causal=False)` est égal à `mha(x, causal=False)[:, perm]`.
2. Montrez que cette propriété **n'est plus vraie** avec `causal=True`, et expliquez pourquoi en une phrase.
3. Implémentez une fonction `attention_croisee(x_dec, x_enc, Wq, Wk, Wv)` où les requêtes viennent de `x_dec` (forme `(T_dec, d)`) et les clés/valeurs de `x_enc` (forme `(T_enc, d)`). Quelle est la forme de la matrice des poids ?

**Critères de réussite.** (a) L'écart maximal de la question 1 est inférieur à $10^{-5}$ ; (b) l'explication de la question 2 mentionne que le masque dépend des **positions** ; (c) la matrice de poids de la question 3 est de forme `(T_dec, T_enc)` et chaque ligne somme à 1.

<details><summary>Corrigé</summary>

```python
import torch
from attention_from_scratch import MultiHeadAttention, attention

torch.manual_seed(0)
mha = MultiHeadAttention(64, 8)
x = torch.randn(1, 6, 64)
perm = torch.randperm(6)
print("Sans masque :", (mha(x[:, perm], causal=False) - mha(x, causal=False)[:, perm]).abs().max().item())
print("Avec masque :", (mha(x[:, perm], causal=True) - mha(x, causal=True)[:, perm]).abs().max().item())

def attention_croisee(x_dec, x_enc, Wq, Wk, Wv):
    q, k, v = x_dec @ Wq, x_enc @ Wk, x_enc @ Wv
    return attention(q, k, v, causal=False)

d = 32
W = [torch.randn(d, d) / d**0.5 for _ in range(3)]
sortie, poids = attention_croisee(torch.randn(5, d), torch.randn(9, d), *W)
print(tuple(poids.shape), poids.sum(-1))      # (5, 9), lignes = 1
```
Question 2 : le masque causal autorise ou interdit une paire $(i, j)$ selon que $j \le i$ ; il dépend donc de l'**ordre** des tokens, et la permutation change l'ensemble des tokens visibles par chacun. Sans masque, l'attention ignore totalement l'ordre.
</details>

## ✅ Auto-évaluation express
1. Dans $\text{softmax}(QK^\top/\sqrt{d_k})V$, sur quelle dimension s'applique le softmax, et pourquoi ?
2. Que se passe-t-il pour le gradient si l'on oublie la division par $\sqrt{d_k}$ avec $d_k = 256$ ?
3. Pourquoi remplit-on les positions masquées par $-\infty$ plutôt que par 0 ?

## 📚 Pour aller plus loin
- [Vaswani et al. (2017) — Attention Is All You Need](https://arxiv.org/abs/1706.03762) 🇬🇧 — l'article fondateur ; lire les sections 3.2 (attention) et 3.5 (positions).
- [Bahdanau, Cho, Bengio (2014)](https://arxiv.org/abs/1409.0473) 🇬🇧 — la première attention, en traduction automatique.
- [Dao et al. (2022) — FlashAttention](https://arxiv.org/abs/2205.14135) 🇬🇧 — l'attention exacte et économe en mémoire.
- [Andrej Karpathy — Let's build GPT: from scratch, in code, spelled out](https://www.youtube.com/watch?v=kCc8FmEb1nY) 🇬🇧 — la construction de l'attention en direct, préparation idéale à L131.
- [Stanford CS336 — Language Modeling from Scratch](https://cs336.stanford.edu/) 🇬🇧 — séances 2-3 (comptabilité des ressources, architectures) et devoir A1.
- [Hugging Face LLM Course — chapitre 1, Transformer models](https://huggingface.co/learn/llm-course/chapter1/1) 🇬🇧 — vue d'ensemble encodeur / décodeur / encodeur-décodeur (licence Apache 2.0).

**Réponses de l'auto-évaluation.** 1. Sur la dernière dimension (les clés) : chaque requête répartit une masse totale de 1 entre les tokens qu'elle peut regarder. 2. Les scores ont un écart-type d'environ 16 ; le softmax sature (quasi one-hot) et ses gradients deviennent quasi nuls, l'apprentissage ralentit fortement. 3. Parce que le softmax exponentie : $e^0 = 1$ donnerait encore du poids au futur, alors que $e^{-\infty} = 0$ l'annule exactement. **Défi** : $d_k = 4096/32 = 128$ ; $4 \times 4096^2 \approx 67$ millions de paramètres par couche d'attention.
