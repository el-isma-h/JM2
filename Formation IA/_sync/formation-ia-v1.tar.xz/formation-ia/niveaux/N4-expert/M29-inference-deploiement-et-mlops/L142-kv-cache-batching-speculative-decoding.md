---
id: L142
module: M29
level: N4
title: "KV cache, batching, speculative decoding"
minutes: 60
objectives:
  - "Calculer la taille du KV cache d'un modèle à partir de sa configuration (couches, têtes KV, dimension de tête, précision) et en déduire la concurrence maximale"
  - "Expliquer PagedAttention, le batching continu, le chunked prefill et le prefix caching, et leur effet sur le débit"
  - "Appliquer le speculative decoding (modèle brouillon, n-grammes) et estimer son gain à partir du taux d'acceptation"
  - "Mesurer TTFT, TPOT, latence de bout en bout et débit agrégé avec un script de charge"
skills: ["C4.5"]
sources:
  - { title: "Kwon et al. (2023) — Efficient Memory Management for LLM Serving with PagedAttention (vLLM)", url: "https://arxiv.org/abs/2309.06180", lang: "en" }
  - { title: "Leviathan et al. (2022) — Fast Inference from Transformers via Speculative Decoding", url: "https://arxiv.org/abs/2211.17192", lang: "en" }
  - { title: "vLLM — Quickstart", url: "https://docs.vllm.ai/en/latest/getting_started/quickstart/", lang: "en" }
  - { title: "Flavio Copes — LLM VRAM requirements (formule KV cache)", url: "https://flaviocopes.com/llm-vram-requirements/", lang: "en" }
  - { title: "BoringBot — KV caching and speculative decoding", url: "https://boringbot.substack.com/p/kv-caching-and-speculative-decoding", lang: "en" }
  - { title: "Daily Dose of DS — Speculative decoding in LLMs", url: "https://www.dailydoseofds.com/p/speculative-decoding-in-llms/", lang: "en" }
  - { title: "Anthropic — Prompt caching", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-caching", lang: "en" }
  - { title: "Stanford CS336 — Language Modeling from Scratch", url: "https://cs336.stanford.edu/", lang: "en" }
---

# KV cache, batching, speculative decoding

> ⏱ 60 min · 🎯 Niveau 4 · 📚 Module 29

## 🎯 Ce que vous saurez faire
- Calculer à la main la mémoire de KV cache d'une requête et d'un serveur, et en déduire combien d'utilisateurs simultanés tiennent sur un GPU.
- Expliquer pourquoi vLLM sert deux à quatre fois plus de requêtes qu'un serveur naïf sur le même GPU.
- Activer le speculative decoding et le prefix caching, et prévoir quand ils aident ou nuisent.
- Mesurer TTFT, TPOT et débit agrégé avec un script Python asynchrone, et lire les métriques Prometheus d'un serveur.

## 1. Deux phases, deux goulots

Une requête de chat se déroule en deux temps :

```
 prompt (2 000 tokens)                 réponse (300 tokens)
┌─────────────────────────┐   ┌──┬──┬──┬──┬──┬──┬──┬── … ──┐
│ PREFILL : 1 passe        │   │t1│t2│t3│t4│t5│t6│t7│  …   │  DECODE : 1 passe par token
│ tous les tokens en //    │   └──┴──┴──┴──┴──┴──┴──┴── … ──┘
│ → borné par le CALCUL    │   → borné par la BANDE PASSANTE (lecture poids + KV)
└─────────────────────────┘
        ▲ TTFT = durée du prefill (+ file d'attente)
                               ▲ TPOT = temps moyen entre deux tokens
```

Le **prefill** traite tout le prompt d'un coup : grosses multiplications matricielles, le GPU calcule à plein régime. Le **decode** produit un token à la fois : à chaque pas, il faut relire tous les poids et tout l'historique d'attention pour une petite quantité de calcul. L'**intensité arithmétique** (opérations par octet lu), notion centrale de la séance « Inférence » de Stanford CS336, est élevée au prefill et minuscule au decode. Toutes les techniques de cette leçon visent à remplir le GPU pendant le decode.

## 2. Le KV cache : la mémoire qui grandit avec la conversation

Dans l'attention, chaque nouveau token compare sa requête $Q$ aux clés $K$ de tous les tokens précédents et combine leurs valeurs $V$. Recalculer $K$ et $V$ de tout l'historique à chaque pas coûterait un temps quadratique : on les **met en cache**. C'est le KV cache, et c'est lui, plus que les poids, qui limite le nombre d'utilisateurs simultanés.

$$\text{KV (octets/token)} = 2 \times n_{\text{couches}} \times n_{\text{têtes KV}} \times d_{\text{tête}} \times \text{octets par valeur}$$

Le facteur 2 compte $K$ et $V$. Lisez les trois paramètres dans le `config.json` du modèle sur Hugging Face : `num_hidden_layers`, `num_key_value_heads`, `head_dim` (ou `hidden_size / num_attention_heads`).

| Modèle | Couches | Têtes KV | $d_{\text{tête}}$ | KV/token en BF16 | 8K tokens | 32K tokens |
|---|---|---|---|---|---|---|
| Llama 3.1 8B | 32 | 8 | 128 | 128 Kio | 1,07 Go | 4,3 Go |
| Qwen3-8B | 36 | 8 | 128 | 144 Kio | 1,2 Go | 4,8 Go |
| Llama 3.1 70B | 80 | 8 | 128 | 320 Kio | 2,7 Go | 10,7 Go |

Ces valeurs concordent avec la règle donnée en L042 (≈ 131 Mo par millier de tokens pour un 8B, ≈ 328 Mo pour un 70B). Passez maintenant au serveur : **32 utilisateurs** qui ont chacun 8 000 tokens de contexte sur Qwen3-8B, c'est 32 × 1,2 = **38 Go de KV cache**, sept fois les poids en 4 bits. D'où trois leviers d'architecture et de configuration :

- **GQA / MQA** (*grouped / multi-query attention*) : plusieurs têtes de requête partagent les mêmes têtes K/V. Llama 3 a 64 têtes de requête mais 8 têtes KV pour le 70B : le cache est divisé par 8 par rapport à une attention multi-têtes classique.
- **MLA** (*multi-head latent attention*, DeepSeek) : K et V sont compressés dans un vecteur latent de faible dimension, d'où des contextes de 1M tokens supportables.
- **Quantization du KV cache** : `--kv-cache-dtype fp8` dans vLLM, `--cache-type-k q8_0 --cache-type-v q8_0` dans llama.cpp. Le cache est divisé par deux avec une perte généralement faible ; à valider par votre évaluation (L141).

```python
# kv_calc.py — taille du KV cache et concurrence maximale à partir du config.json HF
import json, os, sys
from huggingface_hub import hf_hub_download

def kv_par_token(cfg: dict, octets: float = 2.0) -> float:
    n_layers = cfg["num_hidden_layers"]
    n_kv = cfg.get("num_key_value_heads", cfg["num_attention_heads"])
    d_head = cfg.get("head_dim") or cfg["hidden_size"] // cfg["num_attention_heads"]
    return 2 * n_layers * n_kv * d_head * octets

repo = sys.argv[1] if len(sys.argv) > 1 else "Qwen/Qwen3-8B"
cfg = json.load(open(hf_hub_download(repo, "config.json", token=os.environ.get("HF_TOKEN"))))

vram_go, poids_go, util = 48.0, 5.5, 0.90      # ex. L40S 48 Go, poids AWQ ~5,5 Go
contexte = 8192                                 # tokens par requête (prompt + réponse)
for nom, octets in (("BF16", 2.0), ("FP8", 1.0)):
    par_req = kv_par_token(cfg, octets) * contexte / 1e9
    budget = vram_go * util - poids_go - 2.0    # 2 Go réservés (activations, graphes CUDA)
    print(f"{repo} KV {nom}: {kv_par_token(cfg, octets)/1024:.0f} Kio/token, "
          f"{par_req:.2f} Go/requête → {int(budget // par_req)} requêtes de {contexte} tokens")
```

> 💡 **À retenir** — Les poids déterminent si le modèle **tient** ; le KV cache détermine **combien d'utilisateurs** il sert. Au lancement, vLLM affiche « Maximum concurrency for N tokens per request » : comparez-le à votre calcul.

## 3. PagedAttention : la mémoire virtuelle appliquée au KV cache

Avant 2023, les serveurs réservaient pour chaque requête un bloc contigu de la taille du contexte **maximal** possible. Une requête qui annonçait 4 096 tokens mais s'arrêtait à 200 gaspillait 95 % de sa réservation. Kwon et al. (article vLLM, 2023) ont mesuré que les systèmes existants n'utilisaient effectivement que 20 à 38 % de la mémoire de KV cache réservée.

PagedAttention reprend l'idée des pages de la mémoire virtuelle d'un système d'exploitation : le cache est découpé en **blocs de taille fixe** (16 tokens par défaut dans vLLM), alloués à la demande, non contigus, et retrouvés via une **table de blocs** par requête.

```
Requête A : table [7, 2, 9]      Mémoire GPU (blocs de 16 tokens)
Requête B : table [7, 4]         ┌──┬──┬──┬──┬──┬──┬──┬──┬──┬──┐
                                 │  │  │A1│  │B1│  │  │P0│  │A2│ …
  bloc 7 = préfixe partagé (P0)  └──┴──┴──┴──┴──┴──┴──┴──┴──┴──┘
  (même prompt système, compteur de références = 2)
```

Bénéfices : gaspillage limité au dernier bloc de chaque requête (moins de 4 % selon les auteurs), **partage** de blocs entre requêtes (échantillonnage parallèle, recherche en faisceau, préfixes communs) avec copie à l'écriture, et un débit 2 à 4 fois supérieur aux systèmes de référence de l'époque à latence égale. Quand la mémoire manque, vLLM **préempte** une requête (il libère ses blocs puis la recalcule plus tard) au lieu de planter : surveillez ces préemptions dans les journaux, elles signalent un GPU sous-dimensionné.

## 4. Le batching continu

Le **batching statique** regroupe N requêtes, les traite ensemble et attend que **la plus longue** soit finie avant d'en accepter d'autres : les requêtes courtes laissent des places vides. Le **batching continu** (*iteration-level scheduling*, proposé par Orca en 2022 et généralisé par vLLM, TGI et SGLang) réévalue le lot **à chaque pas de génération** : dès qu'une requête émet son token de fin, une nouvelle prend sa place.

```
Statique :   [A A A A A A A A]  [D D D …]       ← B et C finis tôt, places vides
             [B B B · · · · ·]
             [C C C C · · · ·]
Continu :    [A A A A A A A A]
             [B B B D D D D D]                  ← D entre dès que B sort
             [C C C C E E E E]
```

Deux raffinements à connaître :
- **Chunked prefill** : un long prompt (50 000 tokens de RAG) est découpé en morceaux traités entre les pas de decode des autres requêtes, pour que leur génération ne gèle pas. Paramètre clé dans vLLM : `--max-num-batched-tokens`.
- **Désagrégation prefill / decode** : sur les grosses grappes, des GPU différents font le prefill et le decode, et se transfèrent le KV cache. Pertinent au-delà de quelques dizaines de GPU ; hors sujet pour une PME.

Conséquence pratique : le débit agrégé croît avec la concurrence, jusqu'à saturer le calcul ou la mémoire KV, pendant que la vitesse **perçue par chaque utilisateur** baisse doucement. Votre travail est de trouver le point de fonctionnement qui respecte la latence promise.

## 5. Prefix caching : ne jamais recalculer deux fois le même début

Dans une application réelle, la majorité des prompts commence pareil : prompt système de 1 500 tokens, définitions d'outils, consignes de style, parfois le même document. Avec `--enable-prefix-caching` (activé par défaut dans les versions récentes de vLLM, à vérifier pour la vôtre), le serveur calcule une **empreinte** de chaque bloc plein de KV cache, chaînée avec celle du bloc précédent. Une requête dont le début correspond à des blocs déjà en mémoire les réutilise : son prefill ne porte que sur la partie nouvelle, et le TTFT chute.

C'est l'équivalent, côté auto-hébergement, du **prompt caching** des API : chez Anthropic, la lecture d'un préfixe en cache est facturée 0,1 fois le prix d'entrée (et même 0,05 fois sur Opus et Sonnet 5.5, nov. 2026), avec une durée de vie de 5 minutes ou 1 heure. La règle d'ingénierie est la même des deux côtés : **mettez le contenu stable en tête** (système, outils, documents), et le contenu variable (question de l'utilisateur, date du jour) **à la fin**. Une date insérée au début du prompt système suffit à rendre le cache inutile.

> ⚠️ **Piège fréquent** — Mesurer un serveur avec des prompts aléatoires puis s'étonner que la production soit plus rapide (ou l'inverse). Le taux de réussite du cache de préfixes dépend de votre trafic réel : rejouez un échantillon de vrais prompts.

## 6. Speculative decoding : deviner pour aller plus vite

Idée (Leviathan et al. et Chen et al., 2022-2023) : un petit modèle **brouillon** propose $\gamma$ tokens (souvent 3 à 5) ; le grand modèle les **vérifie tous en une seule passe**, ce qui coûte à peu près le prix d'un pas de decode puisque celui-ci est limité par la lecture des poids, pas par le calcul. On garde le plus long préfixe accepté plus un token corrigé. Grâce à un schéma d'acceptation par échantillonnage de rejet, **la distribution de sortie est exactement celle du grand modèle** : ce n'est pas une approximation.

Si chaque token proposé est accepté avec une probabilité $\alpha$, le nombre moyen de tokens produits par vérification vaut :

$$E = \frac{1 - \alpha^{\gamma+1}}{1 - \alpha}$$

Avec $\alpha = 0{,}8$ et $\gamma = 4$ : $E = (1 - 0{,}8^5)/0{,}2 \approx 3{,}4$ tokens par passe du grand modèle. Le gain réel, diminué du coût du brouillon, se situe typiquement entre 2 et 3 fois (1,9 fois mesuré dans l'exemple de Daily Dose of DS ; NVIDIA annonce 2,6 fois sur Qwen-235B en NVFP4 sur deux DGX Spark, relevé IntuitionLabs).

Les variantes :

| Méthode | Brouillon | Quand l'utiliser |
|---|---|---|
| Modèle brouillon | petit modèle de la même famille (même tokenizer) | cas général |
| **N-grammes / prompt lookup** | copie de séquences présentes dans le prompt | résumé, extraction, réécriture de code : la sortie recopie l'entrée |
| EAGLE, Medusa | têtes légères entraînées sur le grand modèle | gain maximal, demande des poids dédiés |
| MTP (*multi-token prediction*) | têtes natives du modèle (DeepSeek V3 et suivants) | si le modèle les fournit |

```bash
# vLLM : speculative decoding par n-grammes (aucun modèle supplémentaire)
vllm serve Qwen/Qwen3-8B-AWQ --max-model-len 32768 \
  --speculative-config '{"method": "ngram", "num_speculative_tokens": 4, "prompt_lookup_max": 4}'

# llama.cpp : modèle brouillon de la même famille (-md), 8 tokens proposés au maximum
./llama.cpp/build/bin/llama-server -m ./gguf/qwen3-8b-Q4_K_M.gguf \
  -md ./gguf/qwen3-0.6b-Q8_0.gguf --draft-max 8 --draft-min 1 -ngl 99 -ngld 99 -c 16384
```

> ⚠️ **Piège fréquent** — Activer le speculative decoding sur un serveur très chargé. À forte concurrence, le GPU est déjà occupé par le batching : les tokens rejetés deviennent du calcul gaspillé, et le débit agrégé peut **baisser**. Le speculative decoding est un outil de **latence à faible charge** (assistant individuel, agent de code), pas de débit.

## 7. Mesurer : TTFT, TPOT, latence, débit

| Métrique | Définition | Ce qu'elle trahit |
|---|---|---|
| **TTFT** (*time to first token*) | du clic au premier token | file d'attente + prefill ; réactivité perçue |
| **TPOT / ITL** (*time per output token*, *inter-token latency*) | temps moyen entre deux tokens | vitesse de lecture ; 1/TPOT = tokens/s par utilisateur |
| **Latence E2E** | TTFT + TPOT × (n − 1) | ce que vit un appel d'API non streamé |
| **Débit agrégé** | tokens de sortie / s, tous utilisateurs | capacité du serveur, base du dimensionnement (L143) |

Un repère de confort : un humain lit environ 5 à 8 tokens par seconde, donc un TPOT inférieur à 100 ms paraît fluide en streaming ; un agent qui enchaîne des appels a, lui, besoin d'une latence de bout en bout faible. Toujours raisonner en **percentiles** (p50, p95, p99) : la moyenne cache les utilisateurs mécontents.

```python
# charge.py — TTFT, TPOT et débit agrégé contre tout serveur compatible OpenAI (Python 3.12)
import asyncio, os, statistics, time
from openai import AsyncOpenAI

client = AsyncOpenAI(base_url=os.environ.get("LLM_BASE_URL", "http://localhost:8000/v1"),
                     api_key=os.environ.get("LLM_API_KEY", "local"))
MODELE = os.environ.get("LLM_MODEL", "Qwen/Qwen3-8B-AWQ")
PREFIXE = "Vous êtes l'assistant fiscal du cabinet. " * 100   # préfixe commun (~1 000 tokens)

async def une_requete(i: int) -> tuple[float, float, int]:
    t0 = time.perf_counter(); premier = None; n = 0
    flux = await client.chat.completions.create(
        model=MODELE, stream=True, max_tokens=256, temperature=0,
        messages=[{"role": "system", "content": PREFIXE},
                  {"role": "user", "content": f"Question {i} : expliquez l'autoliquidation de TVA."}])
    async for morceau in flux:
        if morceau.choices and morceau.choices[0].delta.content:
            n += 1  # approximation : un fragment streamé ≈ un token
            premier = premier or time.perf_counter()
    fin = time.perf_counter()
    ttft = (premier or fin) - t0
    tpot = (fin - premier) / max(n - 1, 1) if premier else 0.0
    return ttft, tpot, n

async def campagne(concurrence: int, total: int = 64) -> None:
    sem = asyncio.Semaphore(concurrence)
    async def borne(i):
        async with sem:
            return await une_requete(i)
    t0 = time.perf_counter()
    res = await asyncio.gather(*(borne(i) for i in range(total)))
    duree = time.perf_counter() - t0
    ttfts = sorted(r[0] for r in res); tpots = sorted(r[1] for r in res)
    p95 = lambda xs: xs[int(0.95 * (len(xs) - 1))]
    print(f"concurrence {concurrence:>3} | TTFT p50 {statistics.median(ttfts)*1000:6.0f} ms "
          f"p95 {p95(ttfts)*1000:6.0f} ms | TPOT p50 {statistics.median(tpots)*1000:5.1f} ms "
          f"| débit {sum(r[2] for r in res)/duree:7.1f} tok/s")

async def main():
    for c in (1, 4, 16, 32):
        await campagne(c)

asyncio.run(main())
```

En production, ne recalculez pas tout côté client : vLLM expose un point `/metrics` au format Prometheus (histogrammes de TTFT et de temps par token, nombre de requêtes en cours et en attente, taux d'occupation du KV cache, préemptions). Les noms exacts varient selon les versions ; affichez-les avec `curl -s localhost:8000/metrics | grep -E "^vllm:" | cut -d'{' -f1 | sort -u`. Vous les brancherez sur l'autoscaling en L143 et le monitoring en L144.

## 🧪 Exercice pratique

**Consigne.** Sur un GPU loué (L4, L40S ou RTX 4090) :
1. Calculez avec `kv_calc.py` la concurrence théorique de Qwen3-8B-AWQ à 8K tokens, en BF16 puis FP8 pour le KV cache. Comparez avec la valeur annoncée au démarrage de vLLM.
2. Lancez `charge.py` à concurrence 1, 4, 16, 32 dans trois configurations : (a) `--no-enable-prefix-caching`, (b) prefix caching actif, (c) prefix caching + speculative decoding n-grammes.
3. Tracez débit agrégé et TPOT p50 en fonction de la concurrence pour les trois configurations.

**Critères de réussite.** Écart de moins de 20 % entre votre calcul et la concurrence annoncée par vLLM (ou explication de l'écart) ; trois courbes ; une phrase expliquant l'effet du prefix caching sur le TTFT et une autre expliquant pourquoi le speculative decoding aide à concurrence 1 mais pas à 32.

<details><summary>Pistes de corrigé</summary>

Qwen3-8B : 144 Kio/token en BF16, soit environ 1,2 Go par requête de 8K ; sur 48 Go avec 90 % d'utilisation, près de 30 requêtes ; le double en FP8. Le prefix caching réduit fortement le TTFT (le préfixe de 1 000 tokens n'est calculé qu'une fois) et augmente un peu le débit. Le speculative decoding n-grammes améliore le TPOT à concurrence 1 si les réponses reprennent des mots du prompt ; à concurrence 32, son gain disparaît ou devient négatif.
</details>

## ✅ Auto-évaluation express
1. Combien de KV cache pour 10 requêtes de 16 000 tokens sur Llama 3.1 70B en BF16 ?
2. Quel problème PagedAttention résout-il, et par quelle analogie ?
3. Avec $\alpha = 0{,}6$ et $\gamma = 3$, combien de tokens en moyenne par passe du grand modèle ?

*Réponses : 1. 320 Kio × 16 000 ≈ 5,2 Go par requête, soit environ 52 Go pour 10. 2. La fragmentation et la sur-réservation du KV cache, résolues par des blocs non contigus alloués à la demande, comme les pages de la mémoire virtuelle. 3. $(1 - 0{,}6^4)/0{,}4 = 0{,}8704/0{,}4 \approx 2{,}2$ tokens.*

## 📚 Pour aller plus loin
- [Kwon et al. — PagedAttention / vLLM (2023)](https://arxiv.org/abs/2309.06180) 🇬🇧 — l'article fondateur, figures de fragmentation à lire absolument.
- [Leviathan et al. — Speculative Decoding (2022)](https://arxiv.org/abs/2211.17192) 🇬🇧 — la preuve que la sortie est inchangée.
- [vLLM — documentation](https://docs.vllm.ai/en/latest/getting_started/quickstart/) 🇬🇧 — sections prefix caching, speculative decoding, métriques.
- [Anthropic — Prompt caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) 🇬🇧 — le même principe côté API, avec la grille tarifaire.
- [BoringBot — KV caching and speculative decoding](https://boringbot.substack.com/p/kv-caching-and-speculative-decoding) 🇬🇧 — explication illustrée.
- [Stanford CS336](https://cs336.stanford.edu/) 🇬🇧 — séance 10 « Inférence » : intensité arithmétique et goulots mémoire.
