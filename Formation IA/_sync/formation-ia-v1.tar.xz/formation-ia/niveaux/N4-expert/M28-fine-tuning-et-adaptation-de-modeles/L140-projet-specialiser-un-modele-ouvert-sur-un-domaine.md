---
id: L140
module: M28
level: N4
title: "Projet : spécialiser un modèle ouvert sur un domaine"
minutes: 70
objectives:
  - "Construire un protocole complet de spécialisation d'un petit modèle ouvert, du cadrage à la livraison"
  - "Appliquer un fine-tuning QLoRA avec Unsloth sur un domaine français (SAV ou droit du travail simplifié)"
  - "Exporter le modèle en GGUF et le servir avec Ollama"
  - "Évaluer le gain par rapport au modèle de base avec une grille pondérée et défendre les résultats"
skills: ["C4.4"]
sources:
  - { title: "Unsloth — documentation (fine-tuning et export GGUF)", url: "https://unsloth.ai/docs", lang: "en" }
  - { title: "Hugging Face TRL — PEFT integration", url: "https://huggingface.co/docs/trl/main/en/peft_integration", lang: "en" }
  - { title: "Ollama — documentation (Modelfile, import)", url: "https://docs.ollama.com", lang: "en" }
  - { title: "Gemma 4 sur LiteRT-LM (tailles E2B/E4B)", url: "https://ai.google.dev/edge/litert-lm/models/gemma-4", lang: "en" }
  - { title: "Qwen3.8-27B — fiche modèle", url: "https://huggingface.co/Qwen/Qwen3.8-27B", lang: "en" }
  - { title: "Légifrance — Code du travail", url: "https://www.legifrance.gouv.fr/codes/texte_lc/LEGITEXT000006072050/", lang: "fr" }
  - { title: "UK AISI — Inspect AI", url: "https://github.com/UKGovernmentBEIS/inspect_ai", lang: "en" }
---

# Projet : spécialiser un modèle ouvert sur un domaine

> ⏱ 70 min · 🎯 Niveau 4 · 📚 Module 28

## 🎯 Ce que vous saurez faire
- Mener de bout en bout un projet de fine-tuning conforme à la compétence C4.4 : jeu de données construit correctement, modèle adapté qui **surpasse la base sur l'évaluation définie**.
- Entraîner un adaptateur QLoRA sur un petit modèle ouvert (Gemma 4 E4B ou équivalent) avec Unsloth, en moins d'une heure de GPU.
- Exporter le modèle en GGUF, l'importer dans Ollama et l'interroger par API.
- Présenter vos résultats avec une grille d'évaluation pondérée, comme devant un jury ou un client.

Ce projet réutilise les scripts des leçons L136 (entraînement), L137 (données) et L138 (évaluation). Il sert de support à l'épreuve « projet de code » de la compétence C4.4.

## 1. Le cahier des charges

Choisissez **un** des deux sujets.

| | Sujet A — SAV « Maison Delorme » | Sujet B — Droit du travail simplifié |
|---|---|---|
| Contexte | Boutique en ligne fictive de linge de maison (Roubaix, 12 salariés) ; 400 demandes clients par semaine | Assistant interne d'information RH pour les salariés d'une PME de 80 personnes |
| Comportement visé | Réponses courtoises, en 120 mots maximum, structure « empathie → solution → prochaine étape », jamais de promesse de remboursement non prévue par la politique | Réponses claires et prudentes, citant l'article du Code du travail concerné, renvoyant aux RH et à la convention collective, sans jamais se présenter comme un conseil juridique |
| Données | 300 à 1 000 couples question/réponse (rédigés + synthétiques relus) | 300 à 800 couples rédigés à partir du Code du travail (Légifrance) et relus par une personne compétente |
| Particularité | Les faits (délais, frais de port) peuvent figurer dans le prompt système | Les textes évoluent : en production, ce sujet exige un RAG sur les articles à jour ; le fine-tuning ne porte que sur le **style** et la **prudence** |
| Modèle conseillé | Gemma 4 E4B (Apache 2.0) | Gemma 4 E4B ou une petite variante Qwen3.8 |

> ⚠️ **Piège fréquent** — Sur le sujet B, croire que le modèle fine-tuné « connaît le droit du travail ». Il a appris une manière de répondre, et il hallucinera des numéros d'articles plausibles. Votre évaluation doit inclure un critère « article cité exact » vérifié contre Légifrance, et votre conclusion doit recommander un RAG pour la production (L135).

**Choix du modèle de base.** Gemma 4 E2B et E4B (2,3 et 4,5 milliards de paramètres effectifs, Apache 2.0, avril 2026) sont conçus pour l'embarqué et tiennent en QLoRA sur un GPU de 12 à 16 Go. La famille Qwen3.8 (août 2026) existe en plusieurs tailles inférieures au 27B : vérifiez l'identifiant exact et la licence de la variante choisie sur sa fiche avant de l'utiliser. Si un point de contrôle multimodal pose problème à l'entraînement en texte seul, basculez sur un modèle textuel éprouvé (Qwen3-8B, Ministral 3 8B, tous deux Apache 2.0) : le protocole est identique.

## 2. Le protocole en sept étapes

```
 1 Cadrer        2 Mesurer la base     3 Données          4 Entraîner
 cas de test ──▶ prompt seul       ──▶ train / eval   ──▶ QLoRA Unsloth
 grille          (Ollama)              figés              (≤ 1 h GPU)
                                                              │
 7 Livrer      ◀── 6 Évaluer        ◀── 5 Exporter  ◀─────────┘
 rapport +         base vs FT           GGUF → Ollama
 Modelfile         grille pondérée
```

### Étape 1 — Cadrer (10 min)
Rédigez 40 cas d'évaluation **avant** tout entraînement : 30 cas « nominaux », 10 cas « pièges » (client agressif, demande hors périmètre, question à laquelle il faut répondre « je ne sais pas »). Fixez les critères de la grille (section 3) et le seuil de succès : *le modèle fine-tuné doit battre la base de 15 points sur la note globale, sans régression de plus de 2 points sur les tâches générales*.

### Étape 2 — Mesurer la base (10 min)
Une mesure de référence honnête utilise le **même prompt système** que celui du modèle final. C'est votre ligne « prompt seul » de l'arbre de décision de L135 : si elle atteint déjà le seuil, le fine-tuning n'est pas justifié, et c'est une conclusion valable du projet.

```bash
ollama pull gemma4:e4b     # vérifiez le nom exact du tag sur ollama.com/search
```

### Étape 3 — Données (20 min de préparation, plus le temps de rédaction)
Utilisez `prepare_data.py` (L137) pour produire `train.jsonl` et `eval.jsonl` au format prompt-completion, avec le **même** prompt système partout. Les 40 cas de l'étape 1 constituent `eval.jsonl` ; ils ne doivent jamais apparaître dans l'entraînement, même reformulés.

### Étape 4 — Entraîner avec Unsloth

```python
"""train_projet.py — QLoRA Unsloth d'un petit modèle ouvert + export GGUF pour Ollama.
pip install unsloth   (GPU NVIDIA ; Colab T4 suffit pour un modèle de ~4B)
Variables : MODEL_ID (vérifiez le nom exact sur huggingface.co/unsloth ou huggingface.co/google), HF_TOKEN si nécessaire.
"""
import os

from unsloth import FastModel  # importer Unsloth en premier

import torch
from datasets import load_dataset
from trl import SFTConfig, SFTTrainer

MODEL_ID = os.environ.get("MODEL_ID", "unsloth/gemma-4-E4B-it")  # repli : "unsloth/Qwen3-8B-unsloth-bnb-4bit"
MAX_LEN = 1024
OUT = "projet/adapter"

model, tokenizer = FastModel.from_pretrained(
    model_name=MODEL_ID,
    max_seq_length=MAX_LEN,
    load_in_4bit=True,          # QLoRA
    token=os.environ.get("HF_TOKEN"),
)
model = FastModel.get_peft_model(
    model,
    r=16,
    lora_alpha=32,
    lora_dropout=0,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    bias="none",
    use_gradient_checkpointing="unsloth",
    random_state=42,
)

data = load_dataset("json", data_files={"train": "train.jsonl", "eval": "eval.jsonl"})

trainer = SFTTrainer(
    model=model,
    processing_class=tokenizer,
    train_dataset=data["train"],
    eval_dataset=data["eval"],
    args=SFTConfig(
        output_dir="projet/checkpoints",
        num_train_epochs=2,
        per_device_train_batch_size=4,
        gradient_accumulation_steps=4,
        learning_rate=2e-4,
        lr_scheduler_type="cosine",
        warmup_ratio=0.05,
        optim="adamw_8bit",
        max_length=MAX_LEN,
        logging_steps=10,
        eval_strategy="epoch",
        save_strategy="epoch",
        seed=42,
        report_to="none",
    ),
)
stats = trainer.train()
print(f"Durée : {stats.metrics['train_runtime'] / 60:.1f} min · "
      f"pic VRAM : {torch.cuda.max_memory_allocated() / 1e9:.1f} Go")

model.save_pretrained(OUT)          # adaptateur LoRA seul (versionnable)
tokenizer.save_pretrained(OUT)

# Étape 5 — Export GGUF quantifié Q4_K_M (fusion de l'adaptateur incluse)
model.save_pretrained_gguf("projet/gguf", tokenizer, quantization_method="q4_k_m")
print("GGUF écrit dans projet/gguf/")
```

**Estimation de ressources** (à mesurer et à reporter dans votre rapport) :

| Élément | Modèle ~4B (Gemma 4 E4B) | Modèle 8B (repli) |
|---|---|---|
| VRAM pic estimée | ~6-9 Go | ~10-13 Go |
| GPU suffisant | T4 16 Go (Colab), RTX 3060 12 Go | RTX 4060 Ti 16 Go, L4 24 Go |
| Durée pour 800 exemples × 2 époques | ~10-30 min selon le GPU | ~15-40 min |
| Coût en location | < 0,50 € (L4 Scaleway 0,75 €/h ; RTX 4090 RunPod 0,34 $/h) | < 1 € |
| Taille GGUF Q4_K_M | ~3 Go | ~5 Go |

### Étape 5 — Exporter vers Ollama
Si `save_pretrained_gguf` échoue (version de llama.cpp, architecture récente), utilisez la voie manuelle : fusion avec PEFT puis conversion avec llama.cpp.

```bash
# Voie manuelle : fusionner l'adaptateur dans le modèle 16 bits
python - <<'EOF'
import torch
from peft import AutoPeftModelForCausalLM
from transformers import AutoTokenizer
m = AutoPeftModelForCausalLM.from_pretrained("projet/adapter", dtype=torch.bfloat16)
m = m.merge_and_unload()            # W' = W + (alpha/r)·BA, plus d'adaptateur séparé
m.save_pretrained("projet/merged", safe_serialization=True)
AutoTokenizer.from_pretrained("projet/adapter").save_pretrained("projet/merged")
EOF

git clone https://github.com/ggml-org/llama.cpp && pip install -r llama.cpp/requirements.txt
python llama.cpp/convert_hf_to_gguf.py projet/merged --outfile projet/sav-f16.gguf --outtype f16
cmake -S llama.cpp -B llama.cpp/build && cmake --build llama.cpp/build --target llama-quantize -j
llama.cpp/build/bin/llama-quantize projet/sav-f16.gguf projet/sav-q4_k_m.gguf Q4_K_M
```

Créez ensuite le **Modelfile** Ollama, qui embarque le prompt système et les paramètres d'échantillonnage :

```bash
GGUF=$(ls projet/gguf/*.gguf projet/*.gguf 2>/dev/null | grep -i q4_k_m | head -1)
cat > Modelfile <<EOF
FROM ./${GGUF}
SYSTEM """Vous êtes l'assistant SAV de la Maison Delorme. Répondez en français, avec courtoisie, en 120 mots maximum."""
PARAMETER temperature 0.3
PARAMETER num_ctx 4096
EOF
ollama create sav-delorme -f Modelfile
ollama run sav-delorme "Mon colis est indiqué livré mais je ne l'ai pas reçu."
```

Ollama lit en général le modèle de conversation (*chat template*) dans les métadonnées du GGUF ; si les réponses contiennent des balises parasites, ajoutez une directive `TEMPLATE` reprenant celui de la famille de modèles (voir la documentation Ollama).

### Étape 6 — Évaluer
Générez les réponses des deux modèles sur `eval.jsonl`, appliquez les métriques automatiques, puis le juge A/B de L138.

```python
"""compare.py — Réponses base vs fine-tuné via Ollama + métriques déterministes. Produit reponses.jsonl pour juge_ab.py.
pip install openai ; Ollama doit servir les deux modèles (BASE_MODEL, FT_MODEL).
"""
import json
import os
import re

from openai import OpenAI

client = OpenAI(base_url=os.environ.get("OLLAMA_URL", "http://localhost:11434/v1"), api_key="ollama")
BASE, FT = os.environ.get("BASE_MODEL", "gemma4:e4b"), os.environ.get("FT_MODEL", "sav-delorme")
SYSTEM = "Vous êtes l'assistant SAV de la Maison Delorme. Répondez en français, avec courtoisie, en 120 mots maximum."

def repondre(modele: str, question: str) -> str:
    r = client.chat.completions.create(model=modele, temperature=0.3,
                                       messages=[{"role": "system", "content": SYSTEM},
                                                 {"role": "user", "content": question}])
    return r.choices[0].message.content.strip()

def metriques(rep: str) -> dict:
    return {
        "longueur_ok": len(rep.split()) <= 120,
        "courtoisie": bool(re.search(r"\b(bonjour|désolé|merci|je comprends)\b", rep, re.I)),
        "prochaine_etape": bool(re.search(r"\b(sous \d+|je (lance|transmets|vous recontacte)|n'hésitez pas)\b", rep, re.I)),
        "montant_invente": bool(re.search(r"\d+[,.]?\d*\s?€", rep)),   # à vérifier à la main si vrai
    }

agg = {BASE: {}, FT: {}}
with open("eval.jsonl", encoding="utf-8") as f_in, open("reponses.jsonl", "w", encoding="utf-8") as f_out:
    for ligne in f_in:
        ex = json.loads(ligne)
        q, ref = ex["prompt"][-1]["content"], ex["completion"][0]["content"]
        rb, rf = repondre(BASE, q), repondre(FT, q)
        for modele, rep in [(BASE, rb), (FT, rf)]:
            for k, v in metriques(rep).items():
                agg[modele][k] = agg[modele].get(k, 0) + int(v)
        f_out.write(json.dumps({"question": q, "reference": ref, "base": rb, "ft": rf}, ensure_ascii=False) + "\n")

for modele, m in agg.items():
    print(modele, m)
print("Étape suivante : python juge_ab.py (L138), puis relecture humaine de 20 paires à l'aveugle.")
```

N'oubliez pas l'étage **non-régression** : `lm_eval` sur 2 ou 3 tâches générales, base vs adaptateur (L138, section 4).

## 3. La grille d'évaluation

Notez chaque réponse du jeu d'évaluation, pour la base et pour le modèle fine-tuné. Les critères 1 à 3 sont vérifiés par un humain (ou un juge LLM calibré), les critères 4 à 6 automatiquement.

| # | Critère | Poids | Mode de vérification | Sujet A | Sujet B |
|---|---|---|---|---|---|
| 1 | Exactitude de la solution par rapport à la référence | 30 % | Humain / juge calibré | Bonne procédure de retour, bon délai | Règle correcte, article cité **exact** (contrôle Légifrance) |
| 2 | Aucune invention (prix, délai, engagement, article) | 20 % | Humain + regex | Pas de geste commercial inventé | Pas d'article inexistant |
| 3 | Ton et structure attendus | 15 % | Juge A/B | Empathie → solution → étape | Clair, prudent, renvoi RH/convention |
| 4 | Contraintes de format | 10 % | Script | ≤ 120 mots, français | ≤ 200 mots, mention « information générale » |
| 5 | Cas pièges correctement gérés | 15 % | Humain | Refus poli hors périmètre, désescalade | « Je ne sais pas » + renvoi quand il le faut |
| 6 | Non-régression générale | 10 % | lm-evaluation-harness | Écart ≤ 2 points | Écart ≤ 2 points |

**Note globale** = somme pondérée sur 100. **Succès du projet** : fine-tuné ≥ base + 15 points **et** critère 6 respecté **et** zéro invention grave sur les cas pièges. Un projet qui conclut, preuves à l'appui, que le prompt seul suffisait est aussi un projet réussi : vous aurez démontré la compétence d'évaluation.

> 💡 **À retenir** — Le livrable n'est pas « un modèle », c'est **un modèle + la preuve qu'il est meilleur** : données versionnées, scripts, chiffres de la grille, limites connues. C'est exactement ce que vérifie un jury de certification et ce qu'attend un client.

## 4. Le livrable

Votre dépôt de rendu contient :

```
projet-c44/
├── README.md              ← contexte, choix du modèle (licence), résultats, limites
├── data/
│   ├── train.jsonl        ← pseudonymisé, avec champ d'origine
│   ├── eval.jsonl         ← figé avant entraînement
│   └── provenance.md      ← sources, modèle professeur éventuel, licences, CGU consultées
├── scripts/               ← prepare_data.py, train_projet.py, compare.py, juge_ab.py
├── resultats/             ← sorties lm_eval, reponses.jsonl, grille remplie (CSV)
└── Modelfile              ← pour ollama create
```

Le README répond à cinq questions : quel problème, quel modèle et pourquoi (taille, licence), quelles données (volume, origine, RGPD), quels résultats (grille, juge, non-régression, coût et durée mesurés), quelles limites et quelle suite (RAG, DPO, ré-entraînement).

> 🔗 **Documentation officielle** — [Unsloth docs](https://unsloth.ai/docs) · [Ollama docs](https://docs.ollama.com) · [TRL — PEFT integration](https://huggingface.co/docs/trl/main/en/peft_integration) · [Légifrance — Code du travail](https://www.legifrance.gouv.fr/codes/texte_lc/LEGITEXT000006072050/)

> 🎮 **Défi bonus** — Ajoutez une passe DPO (script `dpo.py` de L137) sur 100 paires construites à partir des réponses du modèle SFT que vous avez corrigées. Le gain sur le critère 3 compense-t-il le temps passé ?

## 🧪 Exercice pratique

**Consigne.** Réalisez le projet complet sur le sujet A ou B en suivant les sept étapes, et remettez le dépôt décrit en section 4.

**Critères de réussite** (alignés sur la compétence C4.4) :
- le jeu de données est construit correctement : format valide, pseudonymisé, sans fuite entre entraînement et évaluation, provenance documentée ;
- l'entraînement est reproductible (graine, versions des bibliothèques notées, hyperparamètres dans le README) ;
- le modèle est servi par Ollama et répond par API ;
- la grille est remplie pour la base et le fine-tuné, avec le juge A/B en double ordre et 20 paires relues à l'aveugle ;
- la conclusion est honnête : gain chiffré, régressions éventuelles, limites (notamment le besoin de RAG sur le sujet B).

<details><summary>Pistes de corrigé</summary>

Résultats typiques sur le sujet A avec ~800 exemples : la base respecte mal la limite de 120 mots et la structure en trois temps ; le fine-tuné les tient dans la grande majorité des cas, gain de 15 à 30 points sur la note globale, non-régression stable à ±2 points. Points faibles fréquents : cas pièges sous-représentés dans l'entraînement (ajoutez-en 10 %), montants inventés quand la politique commerciale n'est pas dans le prompt système. Sur le sujet B, le critère « article exact » reste le plus fragile : c'est l'argument chiffré en faveur d'un RAG sur Légifrance en production.
</details>

## ✅ Auto-évaluation express
1. Pourquoi mesurer la base avec le même prompt système que le modèle final ?
2. Que contient le Modelfile Ollama du projet, et à quoi sert-il ?
3. Quelles sont les trois conditions de succès du projet ?

*Réponses : 1. Pour isoler l'effet du fine-tuning : sinon une partie du gain viendrait du prompt. 2. La référence au fichier GGUF (`FROM`), le prompt système (`SYSTEM`) et les paramètres (`PARAMETER`) ; il permet `ollama create` puis de servir le modèle en local. 3. Gain d'au moins 15 points sur la grille, non-régression générale ≤ 2 points, aucune invention grave sur les cas pièges.*

## 📚 Pour aller plus loin
- [Unsloth — documentation](https://unsloth.ai/docs) 🇬🇧 — notebooks par famille de modèles et options d'export GGUF.
- [Ollama — documentation](https://docs.ollama.com) 🇬🇧 — import de GGUF, Modelfile, API compatible OpenAI.
- [Gemma 4 — modèles embarqués (LiteRT-LM)](https://ai.google.dev/edge/litert-lm/models/gemma-4) 🇬🇧 — tailles E2B/E4B et déploiement sur appareil.
- [a smol course](https://huggingface.co/learn/smol-course) 🇬🇧 — projet final et certificat de complétion à viser après ce module.
- [Inspect AI](https://github.com/UKGovernmentBEIS/inspect_ai) 🇬🇧 — pour transformer votre grille en évaluation automatisée réutilisable.
