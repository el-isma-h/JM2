---
id: L061
module: M14
level: N2
title: "Voix et audio : ElevenLabs, Whisper, Suno"
minutes: 60
objectives:
  - "Distinguer les trois familles d'IA audio (synthèse vocale, reconnaissance vocale, génération musicale) et nommer un outil fermé et un outil ouvert pour chacune"
  - "Transcrire et sous-titrer un enregistrement en français avec Whisper en local, puis produire un fichier SRT exploitable"
  - "Construire un cas d'usage professionnel (sous-titrage, podcast, support vocal) avec un budget et un choix d'outil justifié"
  - "Appliquer les règles de consentement, de données biométriques et de transparence au clonage vocal et aux contenus audio générés"
skills: ["C2.5", "C2.3"]
sources:
  - { title: "OpenAI — Whisper (dépôt GitHub, licence MIT)", url: "https://github.com/openai/whisper", lang: "en" }
  - { title: "OpenAI — Speech to text guide", url: "https://developers.openai.com/api/docs/guides/speech-to-text", lang: "en" }
  - { title: "OpenAI — Text to speech guide", url: "https://developers.openai.com/api/docs/guides/text-to-speech", lang: "en" }
  - { title: "OpenAI — Realtime guide", url: "https://developers.openai.com/api/docs/guides/realtime", lang: "en" }
  - { title: "ElevenLabs", url: "https://elevenlabs.io", lang: "en" }
  - { title: "Mistral — Voxtral TTS 3 (docs)", url: "https://docs.mistral.ai/models/voxtral-mini-tts-3-0", lang: "en" }
  - { title: "Hugging Face — Voxtral 4B TTS (model card)", url: "https://huggingface.co/mistralai/Voxtral-4B-TTS-2603", lang: "en" }
  - { title: "Suno", url: "https://suno.com", lang: "en" }
  - { title: "KoboldCpp — wiki (TTS, Whisper, musique en local)", url: "https://github.com/LostRuins/koboldcpp/wiki", lang: "en" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "Village de la Justice — Les apports de la loi SREN", url: "https://www.village-justice.com/articles/les-apports-loi-visant-reguler-espace-numerique,52322.html", lang: "fr" }
---

# Voix et audio : ElevenLabs, Whisper, Suno

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 14

## 🎯 Ce que vous saurez faire
- Reconnaître les trois familles d'IA audio et savoir laquelle appeler : faire parler un texte, transcrire une parole, composer une musique.
- Transcrire une réunion ou une vidéo en français sur votre machine avec Whisper, et en sortir des sous-titres SRT.
- Monter un cas d'usage complet (sous-titrage, podcast, support vocal) avec outil, budget et limites.
- Dire non, avec les bons arguments juridiques, à un clonage vocal sans consentement.

## 1. Trois familles, trois métiers

L'« IA audio » regroupe trois technologies très différentes, que l'on confond souvent parce qu'elles sortent du même haut-parleur :

| Famille | Terme anglais | Entrée → sortie | Outils fermés (nov. 2026) | Outils ouverts, exécutables en local |
|---|---|---|---|---|
| **Synthèse vocale** | *text-to-speech* (TTS) | Texte → voix | ElevenLabs ; Voxtral TTS 3 (Mistral, API) ; Gemini 3.8 Flash TTS ; xAI Voice ; OpenAI TTS | **Voxtral 4B TTS** (Mistral, CC BY-NC 4.0), Kokoro, Qwen3-TTS, OuteTTS |
| **Reconnaissance vocale** | *speech-to-text* (STT), transcription | Voix → texte | gpt-transcribe (OpenAI) ; Voxtral Transcribe 3 (Mistral) ; gemini-3.5-transcribe (Google) ; xAI STT | **Whisper** (OpenAI, licence MIT), ses dérivés whisper.cpp et faster-whisper |
| **Génération musicale** | *music generation* | Texte (et parfois paroles) → morceau | Suno ; Lyria 3.5 (Google) | **ACE-Step 1.5** (intégré à KoboldCpp) |

Une quatrième catégorie émerge : la **conversation vocale en temps réel** (*speech-to-speech*), où le modèle écoute et répond à la voix sans passer par du texte intermédiaire (OpenAI Realtime, Gemini Live, Mistral Voice agents, xAI STS). C'est la brique des assistants téléphoniques de nouvelle génération ; nous la situons en section 4.

Analogie : la TTS est un **comédien de doublage** qui lit votre script ; la STT est une **sténographe** ; la génération musicale est un **compositeur de musique de film** qui travaille à partir d'une note d'intention. On ne demande pas au comédien de prendre des notes.

> 💡 **À retenir** — La transcription est, de loin, le cas d'usage le plus rentable et le moins risqué en entreprise : elle ne crée rien, elle convertit. Commencez par là.

## 2. Transcrire : Whisper, l'outil ouvert devenu standard

En septembre 2022, OpenAI publie **Whisper**, un modèle de reconnaissance vocale entraîné sur 680 000 heures d'audio multilingue, sous **licence MIT** : code et poids librement réutilisables, y compris commercialement. Il reconnaît le français, traduit vers l'anglais, horodate les segments, et tourne sur un simple portable. Trois ans plus tard, il reste la référence ouverte, et ses variantes optimisées (whisper.cpp en C++, faster-whisper) équipent la plupart des outils de sous-titrage, y compris LocalAI et KoboldCpp qui l'exposent sur un endpoint `/v1/audio/transcriptions` compatible OpenAI.

### 2.1 Choisir la taille du modèle

Le dépôt propose plusieurs tailles (de `tiny` à `large`, plus `turbo`, version accélérée du grand modèle). D'après le README du dépôt, les besoins vont d'environ 1 Go de VRAM pour `tiny` à environ 10 Go pour `large`, `turbo` se situant autour de 6 Go ; à vérifier sur la page du dépôt pour la version installée. Sur CPU seul, `small` ou `base` restent utilisables pour du français propre ; `turbo` ou `large` s'imposent pour des réunions bruyantes, des accents ou du vocabulaire technique. Règle du module 10 : si le modèle tient en VRAM, il est rapide ; s'il déborde, il rame.

### 2.2 Transcrire et sous-titrer en local

```python
# transcrire.py — Python 3.12+ ; pip install -U openai-whisper ; ffmpeg doit être installé.
# Transcrit un enregistrement en français et écrit un fichier de sous-titres SRT.
# Tout reste sur la machine : aucune donnée n'est envoyée à un service externe.
import sys
from datetime import timedelta

import whisper


def horodatage(secondes: float) -> str:
    """Convertit 83.4 → '00:01:23,400' (format SRT)."""
    t = timedelta(seconds=secondes)
    heures, reste = divmod(int(t.total_seconds()), 3600)
    minutes, sec = divmod(reste, 60)
    return f"{heures:02}:{minutes:02}:{sec:02},{int(t.microseconds / 1000):03}"


fichier_audio = sys.argv[1] if len(sys.argv) > 1 else "reunion.mp3"

modele = whisper.load_model("turbo")               # tiny / base / small / medium / large / turbo
resultat = modele.transcribe(
    fichier_audio,
    language="fr",                                   # forcer le français évite les erreurs de détection
    initial_prompt="Réunion de direction, société Dupont Menuiserie, devis, chantier, TVA.",  # vocabulaire attendu
)

with open("reunion.srt", "w", encoding="utf-8") as srt:
    for i, segment in enumerate(resultat["segments"], start=1):
        srt.write(f"{i}\n{horodatage(segment['start'])} --> {horodatage(segment['end'])}\n{segment['text'].strip()}\n\n")

with open("reunion.txt", "w", encoding="utf-8") as txt:
    txt.write(resultat["text"])

print(f"Transcription : reunion.txt · Sous-titres : reunion.srt · {len(resultat['segments'])} segments")
```

Deux astuces de praticien : le paramètre `initial_prompt` « amorce » le modèle avec le vocabulaire attendu (noms propres, sigles, termes métier), ce qui réduit nettement les erreurs ; et un passage préalable par `ffmpeg` (extraction de la piste audio, conversion en mono 16 kHz) accélère le traitement :

```bash
# Extraire l'audio d'une vidéo de formation, en mono 16 kHz (format natif de Whisper)
ffmpeg -y -i formation.mp4 -vn -ac 1 -ar 16000 reunion.wav
python3 transcrire.py reunion.wav
```

### 2.3 Et par API, quand le volume ou la vitesse l'exigent

Si vous transcrivez des centaines d'heures ou si vous avez besoin de temps réel (sous-titres en direct d'un webinaire), les API sont compétitives. Tarifs lus sur les pages officielles (nov. 2026) : **gpt-transcribe 0,0045 $/min** (soit 0,27 $ l'heure), **gpt-live-transcribe 0,017 $/min** en flux, **gpt-realtime-translate 0,034 $/min** ; chez Mistral, **Voxtral Mini Transcribe 3 0,0035 $/min** et sa version temps réel 0,008 $/min ; chez xAI, STT par lot 0,10 $/h et 0,20 $/h en flux. Pour mémoire, une heure de transcription humaine se facture plusieurs dizaines d'euros.

> ⚠️ **Piège fréquent** — Envoyer à une API un enregistrement de réunion contenant des données personnelles ou des informations confidentielles sans vérifier les conditions du fournisseur (hébergement, conservation, réutilisation pour l'entraînement) ni informer les participants. Whisper en local supprime le premier problème, pas le second : **enregistrer une réunion suppose d'en informer les participants** ; transcrire un entretien RH relève d'un traitement de données personnelles (fiches CNIL).

> 🔗 **Documentation officielle** — [Whisper — dépôt GitHub](https://github.com/openai/whisper) 🇬🇧 · [OpenAI — Speech to text](https://developers.openai.com/api/docs/guides/speech-to-text) 🇬🇧 · [KoboldCpp — wiki](https://github.com/LostRuins/koboldcpp/wiki) 🇬🇧

## 3. Faire parler : ElevenLabs et les TTS ouverts

Fondée en 2022, **ElevenLabs** s'est imposée par le naturel de ses voix multilingues (le français y est bon, intonations et liaisons comprises), ses voix de bibliothèque, le doublage automatique et le **clonage vocal** : à partir de quelques minutes d'enregistrement, le service reproduit un timbre. Accès par application web et API ; les offres et prix de nov. 2026 n'ont pas été vérifiés dans notre dossier, consultez [elevenlabs.io](https://elevenlabs.io).

Les alternatives tarifées à l'API et vérifiées : **Voxtral TTS 3** de Mistral (13 $ par million de caractères, soit environ 0,013 $ pour une page de 1 000 caractères), **Gemini 3.8 Flash TTS** (0,50 $ par million de tokens en entrée, 9 $ en sortie), **xAI** (15 $ par million de caractères). Et en local : **Voxtral 4B TTS** (poids ouverts, publié le 23 mars 2026 sous licence CC BY-NC 4.0, donc **pas d'usage commercial direct**), Kokoro, Qwen3-TTS ou OuteTTS, tous intégrables via KoboldCpp ou LocalAI.

Exemple avec le SDK ElevenLabs (noms de modèle et de voix à contrôler dans la documentation du service, qui évolue vite) :

```python
# lire_texte.py — Python 3.12+ ; pip install elevenlabs
# Transforme un script de podcast en fichier MP3 avec une voix de bibliothèque.
import os

from elevenlabs.client import ElevenLabs

client = ElevenLabs(api_key=os.environ["ELEVENLABS_API_KEY"])   # clé dans l'environnement, jamais dans le code

script = (
    "Bonjour et bienvenue dans « Paie en clair », le podcast de cinq minutes du cabinet Martin et Associés. "
    "Aujourd'hui : ce qui change sur le bulletin de paie au premier janvier."
)

# voice_id : identifiant d'une voix de la bibliothèque (à copier depuis l'interface) ; model_id : modèle multilingue courant
audio = client.text_to_speech.convert(
    voice_id=os.environ.get("ELEVENLABS_VOICE_ID", "JBFqnCBsd6RMkjVDRZzb"),
    model_id="eleven_multilingual_v2",
    text=script,
    output_format="mp3_44100_128",
)

with open("episode01.mp3", "wb") as f:
    for morceau in audio:                      # la réponse est un flux d'octets
        f.write(morceau)
print("Fichier généré : episode01.mp3")
```

Bonnes pratiques d'écriture pour la TTS : écrivez **pour l'oreille** (phrases courtes, chiffres en toutes lettres quand la prononciation est ambiguë, « 1er janvier 2027 » plutôt que « 01/01/27 »), ajoutez la ponctuation qui guide le rythme, et **écoutez** avant de publier : une voix synthétique prononce mal certains sigles et noms propres, que l'on corrige en les réécrivant phonétiquement (« U-R-S-S-A-F »).

> 🔗 **Documentation officielle** — [ElevenLabs](https://elevenlabs.io) 🇬🇧 · [Mistral — Voxtral TTS 3](https://docs.mistral.ai/models/voxtral-mini-tts-3-0) 🇬🇧 · [OpenAI — Text to speech](https://developers.openai.com/api/docs/guides/text-to-speech) 🇬🇧

## 4. Composer : Suno et la musique générée

**Suno** produit en quelques secondes un morceau complet (voix chantée, paroles, instruments) à partir d'une description et, si vous le souhaitez, de vos propres paroles. L'usage professionnel typique : jingle de podcast, musique d'attente, fond sonore d'une vidéo (L060). Deux points de vigilance :

- **Les droits sur le morceau dépendent de votre offre.** Chez Suno comme chez ses concurrents, l'usage commercial est en général réservé aux abonnements payants, et les conditions précisent qui est titulaire des droits. Lisez-les avant de mettre un jingle dans une publicité. Rappel de L059 : un morceau généré sans apport créatif humain n'est pas protégé par le droit d'auteur français (art. L111-1 CPI) ; vos paroles, elles, le sont.
- **Le contentieux sur les données d'entraînement est ouvert.** En juin 2024, les grandes maisons de disques américaines ont assigné Suno et Udio pour l'utilisation présumée d'enregistrements protégés ; en Europe, la GEMA a obtenu une première décision contre OpenAI à Munich en novembre 2025 sur des paroles de chansons (appel en cours). Évitez les prompts « à la manière de [artiste] » et les imitations de voix de chanteurs identifiables.

En local, **ACE-Step 1.5** (poids ouverts, intégré à KoboldCpp) permet d'expérimenter sans envoyer vos paroles à un tiers, avec une qualité en retrait des services fermés.

## 5. Cas d'usage professionnels

| Cas d'usage | Chaîne d'outils | Ce que ça coûte (ordre de grandeur, nov. 2026) | Limites |
|---|---|---|---|
| **Sous-titrage** de vidéos de formation, de webinaires, de réunions | ffmpeg → Whisper local (ou gpt-transcribe) → SRT → relecture → incrustation (L060) | Local : temps machine seulement ; API : ≈ 0,27 $/h d'audio | Noms propres et sigles à corriger ; relecture humaine indispensable pour la publication |
| **Compte rendu de réunion** | Whisper → LLM (résumé, décisions, actions) → relecture | Transcription + quelques centimes de LLM | Information préalable des participants ; pas de données sensibles vers une API sans cadre |
| **Podcast ou vidéo de marque** | Script (LLM relu) → TTS (ElevenLabs, Voxtral) → Suno pour le jingle → montage | De l'ordre de quelques centimes par minute de TTS ; abonnement musique | Mention « voix générée par IA » ; licence musique ; pas de clonage sans consentement |
| **Support vocal** (standard téléphonique intelligent, FAQ vocale) | STT temps réel → LLM + base de connaissances (module 11) → TTS, ou modèle *speech-to-speech* (OpenAI Realtime 32 $ / 64 $ par million de tokens audio ; gpt-live-1 0,05 $/min ; Mistral Voice agents 0,04-0,08 $/min ; xAI STS 0,08 $/min) | ≈ 3 à 5 $ l'heure de conversation selon le fournisseur | Obligation d'informer l'appelant qu'il parle à une IA (AI Act art. 50) ; bascule vers un humain à prévoir ; latence |
| **Accessibilité** (lecture audio de documents, transcription pour malentendants) | TTS pour la lecture ; STT pour les sous-titres en direct | Faible | Qualité à vérifier avec les personnes concernées |

🎮 **Défi** — Chronométrez-vous : à partir d'une vidéo de 5 minutes de votre entreprise, produisez un fichier SRT relu avec Whisper. Les premiers y passent 30 minutes, les habitués 10. Puis calculez ce que coûterait le même sous-titrage sur 50 vidéos par un prestataire.

## 6. Consentement, clonage vocal et transparence

La voix est une **donnée personnelle**, et, lorsqu'elle sert à identifier une personne, une **donnée biométrique** au sens du RGPD, soumise à un régime renforcé (consentement explicite ou autre exception stricte). Le clonage vocal ajoute trois niveaux de risque.

**1. Le consentement de la personne clonée.** Cloner la voix d'un salarié pour « faire lire » des communications internes, celle d'un dirigeant pour un message client, celle d'un comédien pour une publicité : chaque cas exige un **consentement écrit, spécifique et révocable**, précisant les usages autorisés, la durée et la rémunération éventuelle. Un contrat de travail n'emporte pas autorisation de cloner une voix. Les services sérieux (ElevenLabs en tête) exigent une déclaration de consentement et bloquent les voix de personnalités ; ce filtre ne remplace pas votre autorisation écrite.

**2. Le deepfake audio.** L'article **226-8 du Code pénal**, modifié par la loi SREN du 21 mai 2024, sanctionne le fait de publier le montage réalisé avec les **paroles** ou l'image d'une personne sans son consentement, y compris lorsqu'il est généré par un traitement algorithmique, s'il n'apparaît pas à l'évidence qu'il s'agit d'un montage : jusqu'à **2 ans d'emprisonnement et 45 000 € d'amende** en cas de diffusion en ligne. En janvier 2024, un appel automatisé imitant la voix du président des États-Unis a dissuadé des électeurs du New Hampshire d'aller voter : l'affaire a conduit les fournisseurs de clonage à durcir leurs contrôles, et illustre pourquoi la fraude au « faux dirigeant » par téléphone est désormais un risque de sécurité pour toute entreprise (sensibilisez votre service comptable : un ordre de virement oral, même avec la bonne voix, se confirme par un autre canal).

**3. La transparence.** Depuis le **2 août 2026**, l'article 50 de l'AI Act impose (a) d'informer une personne qu'elle interagit avec un système d'IA, sauf évidence (votre standard vocal doit se présenter comme tel), et (b) de marquer les contenus audio générés ou manipulés, avec mention explicite pour les deepfakes. Sanction : jusqu'à **15 M€ ou 3 % du chiffre d'affaires mondial**.

> 💡 **À retenir** — Trois questions avant tout projet vocal : *Qui parle ?* (voix de bibliothèque sous licence, ou consentement écrit de la personne clonée) ; *Qui écoute ?* (information des participants enregistrés, de l'appelant qui parle à une IA) ; *Où vont les données ?* (local, hébergeur européen, API américaine : décision documentée, comme en L041).

> 🔗 **Documentation officielle** — [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 · [Village de la Justice — Les apports de la loi SREN](https://www.village-justice.com/articles/les-apports-loi-visant-reguler-espace-numerique,52322.html) 🇫🇷 · [Règlement (UE) 2024/1689 — EUR-Lex](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) 🇫🇷

## 🧪 Exercice pratique

**Consigne.** Un organisme de formation de 20 personnes possède 40 vidéos de cours (en moyenne 25 min chacune) sans sous-titres, et veut lancer un podcast mensuel de 10 minutes présenté par « une voix de la marque ». Le dirigeant propose de cloner la voix de la formatrice vedette « pour gagner du temps ».

1. **Sous-titrage.** Décrivez la chaîne d'outils (local ou API), estimez le temps machine et humain pour les 40 vidéos, et le coût API si vous choisissiez gpt-transcribe (0,0045 $/min).
2. **Podcast.** Proposez deux options pour la voix (bibliothèque sous licence / clonage avec consentement) et rédigez les cinq clauses minimales d'une autorisation de clonage.
3. **Transparence.** Rédigez la mention à insérer dans la description du podcast et le message d'accueil d'un éventuel standard vocal.
4. **Données.** Justifiez en trois lignes le choix local / API pour la transcription, en citant un critère de confidentialité et un critère de volume.

**Critères de réussite.**
- Le calcul est posé : 40 × 25 = 1 000 min ; coût API ≈ 4,50 $ ; temps humain de relecture estimé (ordre de grandeur : 1 à 2 fois la durée de la vidéo).
- L'autorisation de clonage contient : identité et voix concernée, usages autorisés, durée, révocation, rémunération ou contrepartie, et renvoi à la suppression des données à la fin.
- La mention de transparence est explicite (« voix générée par IA ») et le standard se présente comme une IA dès les premières secondes.
- Le choix local / API est argumenté, pas affirmé.

<details>
<summary>Pistes de corrigé</summary>

Sous-titrage : extraction audio ffmpeg, Whisper `turbo` sur un poste avec GPU (quelques minutes par vidéo) ou gpt-transcribe (1 000 min × 0,0045 $ = 4,50 $) ; relecture humaine 25 à 50 h au total, c'est elle qui coûte. Local justifié si les vidéos contiennent des échanges avec des stagiaires (données personnelles) ; API acceptable pour des cours magistraux déjà publics, à condition de vérifier la conservation. Podcast : option A, voix de bibliothèque (licence incluse dans l'abonnement, aucun risque de personne) ; option B, clonage de la formatrice avec autorisation écrite (usages : podcast mensuel uniquement ; durée : 2 ans ; révocation à tout moment avec préavis d'un mois ; contrepartie : prime ou mention au contrat ; suppression du modèle de voix à la fin). Mention : « Ce podcast est présenté par une voix générée par intelligence artificielle. » Standard : « Bonjour, vous parlez à l'assistant vocal automatisé de [organisme] ; dites “conseiller” à tout moment pour joindre une personne. »
</details>

## ✅ Auto-évaluation express

1. Quelle licence couvre Whisper et que permet-elle ?
2. Un prestataire propose de cloner la voix de votre directrice commerciale pour des messages clients, « elle est d'accord à l'oral ». Suffisant ?
3. Votre standard téléphonique IA doit-il dire qu'il est une IA ?

<details>
<summary>Réponses</summary>

1. Licence MIT : utilisation, modification et redistribution libres, y compris commerciales, avec conservation de la notice ; les poids et le code tournent en local sans envoyer de données.
2. Non : la voix est une donnée personnelle (biométrique si elle identifie) ; il faut un consentement écrit, spécifique, limité dans ses usages et révocable, et documenter la conservation du modèle de voix.
3. Oui : AI Act art. 50 (applicable depuis le 2 août 2026) impose d'informer la personne qu'elle interagit avec un système d'IA, sauf évidence ; prévoir en plus la bascule vers un humain.
</details>

## 📚 Pour aller plus loin
- [OpenAI — Realtime guide](https://developers.openai.com/api/docs/guides/realtime) 🇬🇧 — conversations vocales en temps réel (speech-to-speech), base des agents téléphoniques.
- [Hugging Face — Audio Course](https://huggingface.co/learn/audio-course) 🇬🇧 — cours gratuit : transcription, synthèse vocale et classification audio avec *transformers*.
- [Hugging Face — Voxtral 4B TTS](https://huggingface.co/mistralai/Voxtral-4B-TTS-2603) 🇬🇧 — synthèse vocale ouverte de Mistral (licence CC BY-NC 4.0, usage non commercial).
- [LocalAI](https://localai.io) 🇬🇧 — serveur local tout-en-un (LLM, images, Whisper, TTS) à API compatible OpenAI.
