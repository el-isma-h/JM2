---
id: L060
module: M14
level: N2
title: "Vidéo : Sora, Veo, Runway, Kling"
minutes: 60
objectives:
  - "Expliquer comment fonctionne un générateur de vidéo (texte-vers-vidéo, image-vers-vidéo) et pourquoi ses limites actuelles découlent de ce fonctionnement"
  - "Comparer Sora, Veo, Runway, Kling et Grok Imagine selon l'accès, la durée des plans, le contrôle offert et le coût"
  - "Construire un workflow de production vidéo IA en six étapes, du brief au fichier livré, avec un budget d'itérations"
  - "Évaluer les risques juridiques d'une vidéo générée (personnes, marques, deepfakes) et appliquer la mention de transparence"
skills: ["C2.5"]
sources:
  - { title: "OpenAI — Sora", url: "https://openai.com/sora", lang: "en" }
  - { title: "Google DeepMind — Veo", url: "https://deepmind.google/models/veo/", lang: "en" }
  - { title: "Runway", url: "https://runwayml.com", lang: "en" }
  - { title: "Kling AI", url: "https://klingai.com", lang: "en" }
  - { title: "xAI — Tarifs (Grok Imagine Video)", url: "https://docs.x.ai/developers/pricing", lang: "en" }
  - { title: "Google — Gemini API : modèles", url: "https://ai.google.dev/gemini-api/docs/models", lang: "en" }
  - { title: "Sénat — Réponse ministérielle sur les deepfakes (05/02/2026)", url: "https://www.senat.fr/questions/base/2025/qSEQ251006478.html", lang: "fr" }
  - { title: "donneespersonnelles.fr — Omnibus numérique IA", url: "https://donneespersonnelles.fr/omnibus-numerique-ia", lang: "fr" }
---

# Vidéo : Sora, Veo, Runway, Kling

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 14

## 🎯 Ce que vous saurez faire
- Comprendre ce qu'un générateur de vidéo sait faire aujourd'hui, et surtout ce qu'il ne sait pas faire, pour ne pas promettre l'impossible à votre direction.
- Choisir un outil (Sora, Veo, Runway, Kling, Grok Imagine) selon votre besoin : clip publicitaire, animation d'une photo produit, vidéo de formation, fond d'écran de salon.
- Dérouler un workflow de production en six étapes, avec storyboard, génération par plans, montage et sous-titres.
- Publier sans risque : personnes, marques, musique, mention « généré par IA ».

## 1. Comment une IA fabrique dix secondes de film

En mars 2023, une vidéo de quelques secondes montrant « Will Smith mangeant des spaghettis » a fait le tour d'Internet : visage fondu, pâtes qui traversent les joues, mains à six doigts. Moins de deux ans plus tard, les mêmes outils produisent des plans que des professionnels peinent à distinguer d'un tournage. Que s'est-il passé ?

Les générateurs de vidéo sont des **modèles de diffusion** (vus en L059) appliqués non plus à une image, mais à un **bloc espace-temps** : l'outil débruite simultanément des dizaines d'images successives, en forçant leur cohérence. Les modèles de 2024-2026 (Sora d'OpenAI, annoncé en février 2024 ; Veo de Google DeepMind ; Gen-4 de Runway ; Kling du chinois Kuaishou) combinent cette diffusion avec une architecture *transformer* qui traite la vidéo comme une suite de « patchs » spatio-temporels, un peu comme un LLM traite des tokens. Plusieurs d'entre eux génèrent désormais **le son en même temps que l'image** (bruitages, ambiances, voire dialogues), ce qui change la nature du produit : on obtient un plan sonorisé et non plus un GIF muet.

Trois modes d'entrée existent :

| Mode | Vous fournissez | L'outil produit | Usage typique |
|---|---|---|---|
| **Texte-vers-vidéo** (*text-to-video*) | Un prompt | Un plan de 5 à 20 s environ selon l'outil | Illustration abstraite, plan d'ambiance, prototype |
| **Image-vers-vidéo** (*image-to-video*) | Une image de départ (photo produit, visuel L059) + consigne de mouvement | Le même plan, animé | Animer une photo de catalogue, un logo, un packshot |
| **Vidéo-vers-vidéo** / extension | Une vidéo existante + consigne | Style modifié, plan prolongé, élément remplacé | Restylisation, effets, remplacement de décor |

> 💡 **À retenir** — Le mode **image-vers-vidéo** est le plus fiable en entreprise : vous contrôlez l'image de départ (produit exact, bonnes couleurs, pas d'invention) et ne laissez à l'IA que le mouvement. Les leçons L059 (image) et L060 (vidéo) s'enchaînent naturellement.

## 2. Les outils (nov. 2026) et comment y accéder

| Outil | Éditeur | Accès | Ce qui le distingue | Ce que notre recherche a pu vérifier |
|---|---|---|---|---|
| **Sora** | OpenAI | Application et site Sora, ChatGPT selon l'offre, API | Qualité de rendu, remix de vidéos existantes, génération sonore | Page officielle citée ; détails d'offre et de prix non vérifiés dans notre dossier — consulter [openai.com/sora](https://openai.com/sora) |
| **Veo** (Veo 3 et suivants) | Google DeepMind | Gemini, Google AI Studio / Vertex AI, outils Google Workspace et YouTube selon les offres | Son natif, intégration à l'écosystème Google ; l'API Gemini expose aussi un modèle vidéo (`gemini-omni-1.1-flash`) | Fiche modèles Gemini lue ; tarifs Veo non lus (page tronquée) — voir [deepmind.google/models/veo](https://deepmind.google/models/veo/) |
| **Runway** (Gen-4) | Runway (New York) | Application web, API | Outils de contrôle pour créatifs (caméra, références de personnages, *motion brush*), historique de l'entreprise dans la post-production | Page officielle citée ; grille non vérifiée — [runwayml.com](https://runwayml.com) |
| **Kling** | Kuaishou (Chine) | Application web, API | Rapport qualité-prix souvent cité, plans longs, bon rendu des mouvements humains | Page officielle citée ; grille non vérifiée — [klingai.com](https://klingai.com) |
| **Grok Imagine Video** (1.5) | xAI | Abonnement X « Premium » (30 $/mois) et « Super » (100 $/mois, 1080p), API | Intégré à Grok, rapide | Tarif API vérifié : **à partir de 0,02 $ par seconde** de vidéo ; offres d'abonnement vérifiées (oct. 2026) |

Comment lire ce tableau sans se tromper :

- **Le marché bouge chaque trimestre.** Nous indiquons les faits que notre dossier de recherche a pu lire sur des pages officielles ; pour les autres (durée maximale, résolution, prix par clip), ouvrez la page de l'éditeur le jour où vous devez décider. Un tableau figé serait faux dans trois mois.
- **Le prix se raisonne à la seconde produite, itérations comprises.** À 0,02 $ la seconde (Grok Imagine, API), un plan de 10 s coûte 0,20 $ ; mais il vous faudra en moyenne cinq à dix essais pour un plan gardé, soit 1 à 2 $ par plan utile. Une vidéo de 60 s en six plans revient donc à quelques euros de génération… et à plusieurs heures de travail humain. Les abonnements grand public fonctionnent avec des crédits mensuels, même logique.
- **Les données partent chez l'éditeur** (y compris les images de référence que vous téléversez). Pas de visage de salarié, pas de plan d'usine confidentiel, pas de maquette non annoncée. Il n'existe pas, en novembre 2026, d'équivalent local de FLUX pour la vidéo qui soit à la fois ouvert, de qualité comparable et exécutable sur un poste de travail ; des modèles ouverts existent, mais exigent des GPU de serveur et restent en retrait.

> 🔗 **Documentation officielle** — [OpenAI — Sora](https://openai.com/sora) 🇬🇧 · [Google DeepMind — Veo](https://deepmind.google/models/veo/) 🇬🇧 · [xAI — Pricing](https://docs.x.ai/developers/pricing) 🇬🇧 · [Gemini API — Models](https://ai.google.dev/gemini-api/docs/models) 🇬🇧

## 3. Les limites, et pourquoi elles existent

Un générateur de vidéo n'est ni un moteur 3D ni un logiciel de montage : il **hallucine des pixels plausibles**. Ses limites en découlent directement.

| Limite | Pourquoi | Parade |
|---|---|---|
| **Plans courts** (quelques secondes à ~20 s) | Le coût de calcul croît avec la durée et la cohérence se dégrade | Raisonner en **plans**, pas en film : 6 à 10 plans montés |
| **Cohérence des personnages et des objets** entre deux plans | Chaque génération repart du bruit ; le modèle n'a pas de « mémoire » de votre produit | Image de référence identique pour chaque plan ; fonctions de référence (Runway, Kling) ; éviter les personnages récurrents |
| **Physique approximative** (liquides, mains, foules, texte) | Le modèle imite des statistiques visuelles, pas les lois de la physique | Éviter ces sujets ; privilégier plans larges, mouvements lents, objets simples |
| **Texte et logos illisibles ou déformés** | Même faiblesse qu'en image | Ajouter titres et logos au montage |
| **Contrôle limité de la caméra** | Le prompt est interprété, pas exécuté | Vocabulaire de cinéma précis (voir section 4) ; outils de contrôle de caméra quand ils existent |
| **Non-déterminisme** | Même prompt, résultat différent | Fixer la seed si l'outil le permet, garder les bons résultats, ne pas chercher à « reproduire » |
| **Son généré parfois incohérent** (lèvres, langue) | La synchronisation labiale en français est inégale | Générer les plans sans dialogue, ajouter la voix en L061 |

> ⚠️ **Piège fréquent** — Vouloir « la vidéo institutionnelle de 3 minutes en un prompt ». Aucun outil ne le fait. Le bon livrable d'un générateur, c'est **un plan**. Le film, c'est votre storyboard et votre montage.

## 4. Le workflow de production en six étapes

```mermaid
flowchart LR
    A[1. Brief<br/>objectif, cible, durée, ton] --> B[2. Script et storyboard<br/>un plan = une ligne]
    B --> C[3. Images de référence<br/>L059 : photos ou visuels générés]
    C --> D[4. Génération par plan<br/>5-10 essais, sélection, seed notée]
    D --> E[5. Montage<br/>raccords, voix L061, musique, sous-titres]
    E --> F[6. Contrôle et publication<br/>droits, mention IA, formats]
```

**Étape 1 — Le brief.** Comme pour l'image : objectif (« annoncer l'ouverture de la boutique de Bordeaux »), cible, durée (15 s pour une story, 30 à 60 s pour une page d'accueil), ton, format (9:16 vertical pour les réseaux, 16:9 pour le site), contraintes de marque.

**Étape 2 — Script et storyboard.** Un tableau, une ligne par plan. C'est l'étape que les débutants sautent et qui fait tout gagner.

| N° | Durée | Description visuelle | Mouvement de caméra | Son / voix | Entrée |
|---|---|---|---|---|---|
| 1 | 5 s | Façade de la boutique au lever du jour, rue calme | Travelling avant lent | Ambiance ville, voix off « Bordeaux, 7 h » | Photo réelle de la façade |
| 2 | 4 s | Main qui retourne la pancarte « Ouvert » (sans texte lisible, ajouté au montage) | Fixe, gros plan | Cloche de porte | Texte-vers-vidéo |
| 3 | 6 s | Vitrine, produits alignés, lumière chaude | Panoramique gauche-droite | Musique montante | Visuel L059 (image-vers-vidéo) |

**Étape 3 — Images de référence.** Pour chaque plan où le produit, le lieu ou la charte comptent, partez d'une image : photo réelle ou visuel généré en L059 avec une seed fixée. C'est votre garantie de cohérence.

**Étape 4 — Génération par plan.** Le prompt vidéo reprend S-S-C-L-C et ajoute le **mouvement** : du sujet (« la main retourne lentement la pancarte ») et de la caméra. Utilisez le vocabulaire du cinéma, que les modèles ont appris dans les descriptions de films : *travelling avant* (*dolly in*), *panoramique* (*pan*), *plan fixe* (*static shot*), *plongée* (*high angle*), *contre-plongée* (*low angle*), *ralenti* (*slow motion*), *profondeur de champ réduite* (*shallow depth of field*). Lancez 5 à 10 essais, sélectionnez, notez la seed et le prompt retenus.

**Étape 5 — Montage.** Assemblez dans un logiciel de montage (DaVinci Resolve, CapCut, Premiere) ou en ligne de commande avec `ffmpeg` : raccords, voix off et musique (L061), titres, sous-titres, normalisation du son.

**Étape 6 — Contrôle et publication.** Checklist juridique (section 5), mention « généré par IA », exports aux formats attendus (9:16, 16:9, 1:1), sous-titres incrustés pour les réseaux sociaux (la majorité des vidéos y sont regardées sans le son).

Un script d'assemblage minimal, utile pour automatiser la sortie de plusieurs formats :

```bash
#!/usr/bin/env bash
# assembler.sh — concatène des plans générés, ajoute une voix off et incruste des sous-titres.
# Prérequis : ffmpeg installé ; plans plan01.mp4 … plan06.mp4, voix.mp3, sous-titres.srt dans le dossier.
set -euo pipefail

# 1. Liste des plans dans l'ordre du storyboard
printf "file '%s'\n" plan0{1..6}.mp4 > liste.txt

# 2. Concaténation en ré-encodant (les plans générés n'ont pas toujours les mêmes paramètres)
ffmpeg -y -f concat -safe 0 -i liste.txt -c:v libx264 -crf 20 -preset medium -an montage_muet.mp4

# 3. Voix off + sous-titres incrustés (police lisible sur mobile), piste audio normalisée (EBU R128)
ffmpeg -y -i montage_muet.mp4 -i voix.mp3 \
  -vf "subtitles=sous-titres.srt:force_style='FontSize=22,Outline=1'" \
  -af "loudnorm=I=-16:TP=-1.5:LRA=11" \
  -c:v libx264 -crf 20 -c:a aac -b:a 160k -shortest video_16x9.mp4

# 4. Déclinaison verticale 9:16 pour les réseaux (recadrage centré)
ffmpeg -y -i video_16x9.mp4 -vf "crop=ih*9/16:ih,scale=1080:1920" -c:a copy video_9x16.mp4
echo "Exports : video_16x9.mp4 et video_9x16.mp4"
```

🎮 **Défi** — Prenez une vidéo d'entreprise existante (la vôtre ou celle d'un concurrent, 30 s) et rédigez son storyboard inversé : un tableau par plan, avec durée, mouvement de caméra et son. Vous constaterez que les vidéos professionnelles enchaînent des plans de 2 à 6 secondes : exactement la longueur que les générateurs savent produire.

## 5. Droits, deepfakes et transparence

**Personnes réelles.** Animer la photo d'une personne (collègue, client, dirigeant, personnalité) sans consentement écrit expose au droit à l'image et, en cas de montage trompeur, à l'article **226-8 du Code pénal** tel que modifié par la loi SREN : jusqu'à **2 ans d'emprisonnement et 45 000 € d'amende** lorsque la diffusion a lieu en ligne. Le texte vise explicitement les contenus « générés par un traitement algorithmique ». Les outils eux-mêmes bloquent souvent les visages de personnalités, mais ce filtre n'est pas une autorisation.

**Marques, œuvres, personnages.** Un plan « dans l'univers d'un film connu », avec un personnage sous licence ou un logo tiers, viole le droit d'auteur et le droit des marques comme l'aurait fait un tournage. Décrivez plutôt l'ambiance que vous voulez.

**Musique.** Les générateurs produisent parfois une musique avec le plan ; pour une bande-son maîtrisée, voyez L061 (Suno et ses conditions) ou une banque sous licence. N'utilisez jamais un titre commercial « trouvé en ligne ».

**Transparence.** Depuis le **2 août 2026**, l'article 50 de l'AI Act impose le marquage des contenus vidéo générés ou manipulés par IA et, pour les *deepfakes* (contenus représentant des personnes, lieux ou événements réels de manière trompeuse), une mention explicite. Manquement : jusqu'à **15 M€ ou 3 % du chiffre d'affaires mondial** (réponse ministérielle au Sénat du 5 février 2026). En pratique : conservez les métadonnées de provenance insérées par l'outil, ajoutez « Vidéo générée par IA » dans la description et, pour les contenus réalistes, à l'écran.

> 💡 **À retenir** — Une vidéo générée est un **document de communication** comme un autre : mêmes droits, mêmes autorisations, plus une mention d'origine. La nouveauté n'est pas juridique, elle est dans la facilité de faire une bêtise en trente secondes.

> 🔗 **Documentation officielle** — [Sénat — réponse ministérielle, deepfakes et AI Act](https://www.senat.fr/questions/base/2025/qSEQ251006478.html) 🇫🇷 · [donneespersonnelles.fr — calendrier de l'AI Act](https://donneespersonnelles.fr/omnibus-numerique-ia) 🇫🇷 · [Règlement (UE) 2024/1689 — EUR-Lex](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) 🇫🇷

## 🧪 Exercice pratique

**Consigne.** Une menuiserie artisanale de Haute-Savoie (8 salariés) ouvre un showroom. Elle vous demande une vidéo de 30 secondes pour Instagram (9:16) et son site (16:9) : ambiance atelier, bois, lumière chaude, aucun salarié à l'écran, un seul produit vedette (une table en chêne dont vous avez une photo).

1. Rédigez le brief (objectif, cible, durée, ton, formats, contraintes).
2. Construisez le storyboard : 6 plans de 4 à 6 s, avec pour chacun description, mouvement de caméra, son, type d'entrée (texte, image réelle, image générée).
3. Écrivez le prompt complet de **deux** plans : un texte-vers-vidéo (ambiance atelier) et un image-vers-vidéo (la table, à partir de la photo).
4. Estimez le budget de génération : nombre d'essais par plan, coût à la seconde (prenez 0,02 $/s comme ordre de grandeur) et temps humain.
5. Rédigez la checklist de publication (droits, musique, mention IA, formats).

**Critères de réussite.**
- Le storyboard tient en un tableau lisible ; la somme des durées fait 28 à 32 s.
- Les deux prompts contiennent sujet, style, composition, lumière, contraintes **et** un mouvement de caméra nommé.
- Le budget distingue coût machine (quelques euros) et coût humain (heures) et explique le ratio essais / plans gardés.
- La checklist mentionne l'absence de personne identifiable, l'origine de la musique et la mention « généré par IA ».

<details>
<summary>Pistes de corrigé</summary>

Plan image-vers-vidéo possible : *« À partir de la photo fournie de la table en chêne : plan fixe en légère contre-plongée, la caméra effectue un lent travelling circulaire de 20° autour de la table, lumière chaude de fin d'après-midi par une fenêtre à gauche, particules de poussière dans la lumière, profondeur de champ réduite, aucune personne, aucun texte, le produit reste strictement identique à la photo. 5 secondes, 9:16. »* Budget : 6 plans × 8 essais × 5 s × 0,02 $ ≈ 4,80 $ de génération ; temps humain estimé : 1 h de storyboard, 2 h de génération et tri, 2 h de montage et déclinaisons.
</details>

## ✅ Auto-évaluation express

1. Pourquoi le mode image-vers-vidéo est-il recommandé pour une vidéo produit ?
2. Un plan généré coûte 0,02 $/s ; combien coûte une vidéo de 6 plans de 5 s si l'on garde un essai sur huit ?
3. Que risque une entreprise qui publie une vidéo réaliste d'un concurrent « disant » quelque chose qu'il n'a jamais dit ?

<details>
<summary>Réponses</summary>

1. L'image de départ fixe le produit, les couleurs et la composition ; l'IA n'invente que le mouvement, ce qui limite les hallucinations et garantit la cohérence entre plans.
2. 6 × 8 × 5 s × 0,02 $ = 4,80 $ (contre 0,60 $ si tout était bon du premier coup) : le coût réel, c'est l'itération et le temps humain.
3. Article 226-8 du Code pénal (jusqu'à 2 ans et 45 000 € en cas de diffusion en ligne), action civile du concurrent (dénigrement, droit à l'image) et sanction AI Act art. 50 pour absence de marquage (jusqu'à 15 M€ ou 3 % du CA).
</details>

## 📚 Pour aller plus loin
- [Runway](https://runwayml.com) 🇬🇧 — outils de contrôle (caméra, références) et ressources pour créatifs.
- [Kling AI](https://klingai.com) 🇬🇧 — générateur de Kuaishou, application web et API.
- [Google DeepMind — Veo](https://deepmind.google/models/veo/) 🇬🇧 — présentation du modèle et accès via Gemini / Vertex AI.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — données personnelles (images, visages) dans les systèmes d'IA.
