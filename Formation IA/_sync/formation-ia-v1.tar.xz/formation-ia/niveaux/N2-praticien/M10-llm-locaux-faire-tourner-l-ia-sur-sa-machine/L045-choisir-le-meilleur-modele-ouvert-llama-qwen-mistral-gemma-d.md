---
id: L045
module: M10
level: N2
title: "Choisir le meilleur modèle ouvert : Llama, Qwen, Mistral, Gemma, DeepSeek, gpt-oss"
minutes: 60
objectives:
  - "Situer les grandes familles de modèles à poids ouverts de 2026 (Qwen3.8, Gemma 4, gpt-oss, Mistral Small 4, DeepSeek V4, Kimi K3, Llama 4, Granite, Phi) par éditeur, taille et licence"
  - "Lire une fiche de modèle (model card) et un classement (LMArena, Artificial Analysis, Open LLM Leaderboard) sans se faire piéger par les scores auto-déclarés"
  - "Sélectionner un modèle adapté à un usage (rédaction en français, extraction de données, code, vision, raisonnement) et à une mémoire disponible (8 à 128 Go)"
  - "Vérifier qu'une licence (Apache 2.0, MIT, licences communautaires, non commerciales) autorise l'usage prévu"
skills: ["C2.3", "C2.6"]
sources:
  - { title: "Hugging Face — Qwen/Qwen3.8-27B (model card)", url: "https://huggingface.co/Qwen/Qwen3.8-27B", lang: "en" }
  - { title: "Mistral AI — Mistral Small 4", url: "https://mistral.ai/news/mistral-small-4/", lang: "en" }
  - { title: "DataNorth — Google releases Gemma 4 open models", url: "https://datanorth.ai/news/google-releases-gemma-4-open-models", lang: "en" }
  - { title: "Morph — gpt-oss (fiche)", url: "https://www.morphllm.com/gpt-oss", lang: "en" }
  - { title: "Morph — Best open source LLM (oct. 2026)", url: "https://www.morphllm.com/best-open-source-llm", lang: "en" }
  - { title: "Hugging Face blog — Open source LLM models to run locally (mai 2026)", url: "https://huggingface.co/blog/daya-shankar/open-source-llm-models-to-run-locally", lang: "en" }
  - { title: "Artificial Analysis — Recent open weights model launches", url: "https://www.artificialanalysis.ai/articles/recent-open-weights-model-launches", lang: "en" }
  - { title: "Wikipédia — Llama (language model)", url: "https://en.wikipedia.org/wiki/Llama_(language_model)", lang: "en" }
  - { title: "Pinggy — Best Local LLM Tools and Models in 2026", url: "https://pinggy.io/blog/top_5_local_llm_tools_and_models/", lang: "en" }
  - { title: "Bestllmfor — Benchmarks (tests en français)", url: "https://bestllmfor.com/benchmarks/", lang: "en" }
---

# Choisir le meilleur modèle ouvert : Llama, Qwen, Mistral, Gemma, DeepSeek, gpt-oss

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 10

## 🎯 Ce que vous saurez faire
- Ne plus confondre les familles : savoir qui publie quoi, sous quelle licence, à quelle taille.
- Répondre en trente secondes à « quel modèle pour mon Mac 16 Go / ma RTX 4090 / mon serveur 128 Go ? », en novembre 2026 — et savoir où revérifier dans six mois, car ce paysage bouge tous les trimestres.
- Lire un classement avec un œil critique et une *model card* avec un œil juridique.

## 2026 en une phrase : le paysage a basculé

Il y a deux ans, « modèle ouvert » voulait dire Llama (Meta) et Mistral. En novembre 2026, les classements ouverts sont dominés par des **laboratoires chinois** (Moonshot/Kimi K3, DeepSeek, Alibaba/Qwen, Z.ai/GLM, MiniMax), tandis que Meta a abandonné la marque Llama au profit de **Muse** (Muse Spark Open, licence restrictive). Côté occidental, trois surprises : **Google** publie Gemma 4 sous Apache 2.0, **OpenAI** publie gpt-oss (ses premiers poids ouverts depuis GPT-2, août 2025), et **Mistral AI** (Paris) met toute sa gamme en Apache 2.0, de Ministral 3 à Mistral Large 3 (675B). L'écart avec les modèles fermés reste réel : 26 points sur l'indice Artificial Analysis v5 (27 oct. 2026) entre Claude Opus 5.5 (58) et les meilleurs poids publiés (DeepSeek V4.1 Flash et GLM-5.3, 32). Mais pour la plupart des usages d'entreprise, un modèle de 20 à 30 milliards de paramètres bien choisi fait le travail.

## 1. Les familles, éditeur par éditeur

| Famille (éditeur) | Tailles utiles en local (nov. 2026) | Licence | Signature |
|---|---|---|---|
| **Qwen3.8 / Qwen3.6** (Alibaba, Chine) | 27B dense (vision + vidéo natives), 35B-A3B MoE ; Flash-Next 125B-A6B ; Max 2,4T (serveur) | Apache 2.0 (27B) ; licences Qwen propres pour Flash-Next et Max | « Meilleur rapport qualité/Go » (Pinggy) : Terminal-Bench 2.1 = 73,0, GPQA Diamond = 89,2, LiveCodeBench v6 = 90,3 pour le 27B ; 1 600+ quantizations communautaires |
| **Gemma 4** (Google, avril 2026) | E2B / E4B (embarqué, texte + image + audio), 12B, 26B-A4B MoE, 31B dense | Apache 2.0 | Multimodal partout, vidéo 60 s sur 26B/31B, 256K de contexte ; 31B = 3e ouvert sur LMArena à sa sortie |
| **gpt-oss** (OpenAI, août 2025) | 20b (3,6B actifs, ~12 Go MXFP4), 120b (5,1B actifs, ~66 Go) | Apache 2.0 | Raisonnement réglable, excellent sur CPU et machines 128 Go ; MMLU 90,0 pour le 120b |
| **Mistral** (Paris) | Ministral 3 (3B / 8B / 14B dense), Mistral Small 4 (119B-A6B MoE, mars 2026), Devstral 2 (code), Mistral Large 3 (675B-A41B) | Apache 2.0 (Large 4 : licence propre) | Français natif, function calling, choix « souverain » européen ; Small 4 fusionne raisonnement, code et vision |
| **DeepSeek** (Chine) | R1-Distill 1,5B → 70B ; V4-Flash 284B-A13B ; V4.1-Flash 552B ; V4-Pro 1,6T | MIT | Raisonnement, code (Codeforces 3471 pour V4.1 Flash) ; les gros nécessitent un serveur |
| **Kimi K3 / K2.x** (Moonshot, Chine) | K3 : 2,8T-A104B (1,4 To de mémoire) ; K2.7 Code 1T-A32B | Kimi K3 License (accord au-delà de 20 M$ de revenus) ; Modified MIT (K2) | Meilleur ouvert sur LMArena (1500 Elo) ; hors de portée d'un poste |
| **Llama / Muse** (Meta) | Llama 3.1 8B (toujours la référence des benchmarks matériels) ; Llama 4 Scout 109B-A17B ; Muse Spark Open 816B-A42B | Llama Community / Muse Model License (non OSI) | Contexte 10M (Scout) ; Llama supplanté par Muse depuis avril 2026 |
| **Granite 4.2** (IBM) | 3B, 8B, 30B | Apache 2.0 | Orienté entreprise, raisonnement, disponible sur Ollama |
| **Phi-4** (Microsoft) | mini 3,8B ; reasoning 14B ; reasoning-vision 15B | MIT | Maths, sciences, CPU |
| **Nemotron 3** (NVIDIA) | Super (~64–72 Go en 4 bits), Ultra 550B-A55B | OpenMDW-1.1 | Meilleur ouvert non chinois avec Gemma 4 (AA, avril 2026) |
| **SmolLM3** (Hugging Face) | 3B | Apache 2.0 | « Fully open » (données et recettes publiées), 6 langues dont le français |

> 💡 **À retenir** — Pour un poste de travail de 16 à 32 Go, la recherche du module identifie quatre « valeurs sûres » de fin 2026 : **Qwen3.8-27B** (dense, vision, 16–19 Go), **Gemma 4 26B-A4B** (MoE rapide, 16–18 Go), **gpt-oss-20b** (12–16 Go) et **Qwen3.6-35B-A3B** (~23 Go). Commencez par l'un d'eux.

## 2. Dense ou MoE : le choix qui change la vitesse

Vous l'avez vu en L042 : un modèle **dense** lit tous ses paramètres à chaque token ; un **MoE** n'en lit qu'une fraction (les « experts » actifs). Concrètement, sur la même machine 32 Go :

- Qwen3.8-27B (dense) : excellente qualité, mais la vitesse d'un 27B (≈ 59 tok/s sur RTX 5090, ≈ 11 tok/s sur un M4 Pro).
- Gemma 4 26B-A4B (MoE, 3,8B actifs) : qualité un cran en dessous sur les tâches difficiles, mais la vitesse d'un 4B — trois à cinq fois plus rapide.
- gpt-oss-20b (MoE, 3,6B actifs) : 205 tok/s sur RTX 5090, agréable même sur CPU.

Règle pratique : **dense pour la qualité maximale à mémoire donnée ; MoE pour la vitesse et le CPU**. Pour un assistant conversationnel multi-utilisateurs, le MoE l'emporte presque toujours.

## 3. Choisir par usage

| Usage | Premier choix (nov. 2026) | Alternatives | Pourquoi |
|---|---|---|---|
| **Rédaction et résumé en français** (courriers, comptes rendus) | Mistral Small 4 (si ≥ 64 Go) ou Ministral 3 14B / 8B | Qwen3.8-27B, Gemma 4 | Mistral est entraîné avec un français natif ; Qwen et Gemma couvrent 100+ langues |
| **Extraction structurée** (factures → JSON, classification) | Qwen3.8-27B ou gpt-oss-20b, température 0 | Granite 4.2 8B, Ministral 3 8B | Suivi d'instructions et sorties JSON fiables ; la qualité d'un 8B suffit souvent |
| **Assistant documentaire (RAG)** | Gemma 4 26B-A4B (vitesse) + un modèle d'embedding ouvert (catégorie *embeddings* d'Ollama) | Qwen3.8-27B | Le RAG demande surtout de la vitesse et du contexte (256K pour Gemma 4) — module 11 |
| **Code** | Devstral 2 (Mistral) ou Qwen3.6-27B (SWE-bench Verified 77,2 %) | Qwen3-Coder-Next (46 Go), gpt-oss-120b (62,4 %) | Les modèles « code » dédiés battent les généralistes de même taille |
| **Vision** (lire une facture scannée, une photo de chantier) | Qwen3.8-27B (image + vidéo, OmniDocBench 91,1) | Gemma 4 (image + audio, vidéo 60 s), Phi-4-reasoning-vision 15B | Multimodalité native, pas un module greffé |
| **Raisonnement lourd** (maths, analyse) | gpt-oss-120b (si 96–128 Go) ou Gemma 4 31B | DeepSeek-R1-Distill 32B/70B, Phi-4-reasoning | `reasoning_effort` réglable ; AIME 2026 = 89,2 % pour Gemma 4 31B |
| **Embarqué / téléphone / Raspberry Pi** | Gemma 4 E2B / E4B | Ministral 3 3B, SmolLM3 3B, Phi-4-mini | Conçus pour LiteRT et le CPU |
| **Agents avec outils** (function calling, n8n) | Qwen3.8-27B, gpt-oss | Ministral 3 8B, Granite 4.2 | Catalogue Ollama : filtrer sur la capacité *tools* |

Un test maison vaut mieux que tous les classements : le banc Bestllmfor (sept. 2026) évalue des modèles 8–12B sur un exercice de code **en français** et des documents français ; `qwen3:8b` et `mistral-nemo:12b` réussissent, `hermes3:8b` échoue malgré sa vitesse. Moralité : **testez en français sur vos propres documents** avant de choisir.

## 4. Choisir par mémoire disponible

Synthèse (quantization 4 bits, source Pinggy, mise à jour 5 oct. 2026, croisée avec L042) :

| Mémoire | Modèles recommandés | Taille approx. |
|---|---|---|
| **8 Go** | Gemma 4 E4B, Ministral 3 3B, Phi-4-mini, SmolLM3 ; Gemma 4 12B « serré » (7–8 Go) | 2–8 Go |
| **16 Go** | Gemma 4 12B ; gpt-oss-20b ; Ministral 3 8B / Qwen3 8B ; Gemma 4 26B-A4B et Qwen3.8-27B « serrés » (16–19 Go, contexte court, Mac 16 Go seulement avec prudence) | 7–19 Go |
| **32 Go** | Qwen3.6-35B-A3B (meilleur polyvalent) ; Qwen3.8-27B (meilleur rapport qualité/Go) ; Gemma 4 31B | 16–23 Go |
| **64 Go** | Qwen3-Coder-Next (46 Go) ; Mistral Small 4 ; gpt-oss-120b « limite » (~66 Go, ne tient pas sur un Mac 64 Go) | 46–66 Go |
| **128 Go** (Mac, DGX Spark, Strix Halo) | gpt-oss-120b (66 Go) ; Nemotron 3 Super (64–72 Go) ; Qwen3.8-Flash-Next (96–114 Go) ; DeepSeek-V4-Flash en 3 bits (110–135 Go, limite) | 66–135 Go |
| **256 Go et plus** (Mac Studio 256 Go, 2 × DGX Spark, serveur) | Qwen3-235B, Mistral Large 3, GLM-5.3-Flash, Beam (501B-A23B) | 130–370 Go |

> ⚠️ **Piège fréquent** — « 27B tient dans 16 Go » est vrai sur une RTX 4060 Ti 16 Go… à condition d'un contexte minuscule, et faux sur un Mac 16 Go où seuls ~12 Go sont réellement disponibles. Sur 16 Go, le choix confortable reste un 8–12B dense ou gpt-oss-20b.

## 5. Lire les classements sans se faire avoir

Trois sources principales, trois méthodes :

- **LMArena** (ex-Chatbot Arena) : des humains votent à l'aveugle entre deux réponses ; score Elo. Mesure la **préférence humaine**, donc le style autant que l'exactitude. Relevé du 31 oct. 2026 : Claude Mythos 5 (1531) en tête des fermés ; meilleurs ouverts Kimi K3 (1500), Qwen3.8-Max (1491), GLM-5.2 (1483), DeepSeek V4 Pro (1461).
- **Artificial Analysis Intelligence Index** : indice composite, version 5 depuis le 27 oct. 2026 avec 60 % de tests privés (donc difficiles à « bachoter »), quatre familles (travail intellectuel, code, science, culture générale). Son changement de version a fait chuter Mistral Large 4 de 38 à 25 : **un score n'a de sens qu'avec sa version d'indice**.
- **Open LLM Leaderboard v3** (Hugging Face, janv. 2026) : refonte axée raisonnement, suivi d'instructions et tâches réelles, après le gel de la v2 en 2025.

Et les **scores auto-déclarés** des fiches de modèles (SWE-bench, GPQA, AIME…) : utiles pour comparer deux modèles du même éditeur, à prendre avec prudence entre éditeurs (choix des outils, du nombre d'essais, de la « réflexion » autorisée). Morph, qui compile ces chiffres, le rappelle explicitement.

Trois réflexes :
1. Regardez la **date** et la **version** de l'indice.
2. Comparez des modèles de **taille comparable** (un 27B contre un 2,4T n'apprend rien).
3. Cherchez le benchmark **le plus proche de votre tâche** (Terminal-Bench pour les agents, LiveCodeBench pour le code, OmniDocBench pour la lecture de documents, un test maison en français pour le reste).

## 6. Les licences : le point que l'on ne saute pas

| Famille | Exemples (nov. 2026) | Usage commercial | Pièges |
|---|---|---|---|
| **Apache 2.0 / MIT** (reconnues OSI) | Qwen3.8-27B, Gemma 4, gpt-oss, Mistral Small 4 / Large 3 / Ministral 3, DeepSeek (MIT), GLM-5.2 / 5.3-Flash (MIT), Granite, Phi, SmolLM3 | Libre | Aucun, hors usage des marques ; conservez la notice de licence |
| **Licences communautaires « semi-ouvertes »** | Llama 4 Community, Muse Model License, Kimi K3 License, Qwen3.8-Max, GLM-5.3, MiniMax Community | Oui, **sous conditions** : seuils de revenus (accord écrit au-delà de 20 M$ pour Muse et Kimi K3), mention obligatoire (« Built with Muse Spark Open »), usages interdits | Non reconnues « open source » par l'OSI ; relisez les conditions à chaque nouvelle version |
| **Non commerciales** | Cohere Command A (CC BY-NC), Voxtral TTS (CC BY-NC 4.0) | **Non** | Interdites en production commerciale, même en interne chez un client |

Procédure en entreprise : (1) ouvrir la *model card* sur Hugging Face et lire le champ *License* ; (2) si ce n'est ni Apache 2.0 ni MIT, lire le texte complet ; (3) consigner le modèle, sa version, sa licence et sa date de téléchargement dans votre registre (il servira pour la documentation AI Act, module 15) ; (4) conserver une copie du fichier de poids : un modèle retiré du Hub n'est plus téléchargeable.

> 🔗 **Documentation officielle** — [Hugging Face — fiche Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B) (exemple de model card complète : licence, contexte, benchmarks, quantizations) et [Mistral AI — Mistral Small 4](https://mistral.ai/news/mistral-small-4/)

🎮 **Défi** — Trois clients, trois réponses en une ligne chacune : (a) une mairie veut un assistant hors ligne pour ses agents sur des PC 16 Go sans GPU ; (b) une agence immobilière veut lire automatiquement des diagnostics scannés ; (c) une ESN veut un assistant de code sur un serveur RTX 5090. (Pistes : a. gpt-oss-20b ou Gemma 4 12B ; b. Qwen3.8-27B ; c. Devstral 2 ou Qwen3.6-27B.)

## 🧪 Exercice pratique

**Consigne.** Vous dirigez le service informatique d'un cabinet d'expertise comptable de 40 personnes. Le cabinet dispose d'un serveur avec une RTX 4090 (24 Go) et veut un assistant interne capable de : (1) répondre en français aux questions des collaborateurs sur les procédures internes ; (2) extraire les champs de factures scannées ; (3) rédiger des courriers clients.

Rédigez une **note de sélection d'une page** comprenant : deux modèles candidats avec leur taille en 4 bits et leur licence ; un tableau usage → modèle ; le résultat d'un test réel (si vous avez le matériel) de chaque candidat sur une facture et sur un courrier, avec vos observations sur le français ; une recommandation finale et un plan de revue dans six mois.

**Critères de réussite.** Les deux candidats tiennent dans ~21 Go utilisables avec un contexte de 16K (justifiez avec la formule de L042) ; la licence de chacun est citée avec sa famille ; au moins un critère de choix est un test maison et non un classement ; la note mentionne le registre (modèle, version, licence, date).

**Pistes de corrigé.** Candidats naturels : Qwen3.8-27B (dense, vision native pour les factures, 16–19 Go, Apache 2.0) et Gemma 4 26B-A4B (MoE rapide pour le chat multi-utilisateurs, 16–18 Go, Apache 2.0). Une architecture à deux modèles est acceptable (Ollama en garde un seul chargé à la fois par défaut : prévoyez `OLLAMA_MAX_LOADED_MODELS` ou un délai de bascule, à vérifier dans la FAQ d'Ollama). Mistral Small 4 (119B) ne tient pas sur 24 Go ; Ministral 3 14B est un bon troisième candidat pour les courriers.

## ✅ Auto-évaluation express

1. Quel modèle de 20 à 30B offre le « meilleur rapport qualité/Go » selon la synthèse d'octobre 2026, et sous quelle licence ?
2. Pourquoi un score Artificial Analysis de juin 2026 n'est-il pas comparable à un score d'octobre 2026 ?
3. Une PME peut-elle utiliser Muse Spark Open dans un produit commercial ?

*Réponses :* 1. Qwen3.8-27B, Apache 2.0. 2. L'indice est passé en version 5 le 27 oct. 2026 (nouvelles épreuves, 60 % privées) : Mistral Large 4 est passé de 38 à 25 sans changer de modèle. 3. Oui en dessous de 20 M$ de chiffre d'affaires et avec la mention obligatoire, sous réserve des usages interdits ; au-delà, accord écrit de Meta. Ce n'est pas une licence open source au sens de l'OSI.

## 📚 Pour aller plus loin
- [Hugging Face — Qwen/Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B) 🇬🇧 — model card de référence pour apprendre à lire licence, contexte et quantizations.
- [Mistral AI — Mistral Small 4](https://mistral.ai/news/mistral-small-4/) 🇬🇧 — l'annonce du modèle européen Apache 2.0 fusionnant raisonnement, code et vision.
- [DataNorth — Google releases Gemma 4](https://datanorth.ai/news/google-releases-gemma-4-open-models) 🇬🇧 — tailles, scores et licence de la famille Gemma 4.
- [Morph — gpt-oss](https://www.morphllm.com/gpt-oss) 🇬🇧 et [Morph — Best open source LLM](https://www.morphllm.com/best-open-source-llm) 🇬🇧 — tableaux comparatifs mis à jour en octobre 2026 (avec l'avertissement sur les scores auto-déclarés).
- [Hugging Face blog — Open source LLMs to run locally](https://huggingface.co/blog/daya-shankar/open-source-llm-models-to-run-locally) 🇬🇧 — sélection commentée par taille.
- [Artificial Analysis — Recent open weights launches](https://www.artificialanalysis.ai/articles/recent-open-weights-model-launches) 🇬🇧 — l'écart ouvert / fermé dans le temps.
- [Wikipédia — Llama (language model)](https://en.wikipedia.org/wiki/Llama_(language_model)) 🇬🇧 — l'histoire de la famille Llama et pourquoi sa licence n'est pas « open source ».
- [Bestllmfor — Benchmarks](https://bestllmfor.com/benchmarks/) 🇬🇧 — tests de petits modèles sur des tâches en français.
