---
id: L043
module: M10
level: N2
title: "Ollama : installer, télécharger un modèle, dialoguer, API locale"
minutes: 60
objectives:
  - "Installer Ollama sur macOS, Windows ou Linux et vérifier que le serveur local répond sur le port 11434"
  - "Télécharger, lancer, lister et supprimer des modèles avec les commandes exactes de la CLI Ollama"
  - "Appeler le modèle local depuis un script via l'API REST native et via l'API compatible OpenAI"
  - "Créer un modèle personnalisé (Modelfile) avec un prompt système et des paramètres d'échantillonnage"
skills: ["C2.3"]
sources:
  - { title: "Ollama — Documentation officielle", url: "https://docs.ollama.com", lang: "en" }
  - { title: "Ollama — Téléchargement", url: "https://ollama.com/download", lang: "en" }
  - { title: "Ollama — Catalogue de modèles", url: "https://ollama.com/search", lang: "en" }
  - { title: "Guide — Ollama : run large language models on your machine", url: "https://kx.cloudingenium.com/en/ollama-local-llm-run-large-language-models-machine-guide/", lang: "en" }
  - { title: "Pinggy — Best Local LLM Tools and Models in 2026", url: "https://pinggy.io/blog/top_5_local_llm_tools_and_models/", lang: "en" }
---

# Ollama : installer, télécharger un modèle, dialoguer, API locale

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 10

## 🎯 Ce que vous saurez faire
- Passer de « rien » à « un modèle qui répond dans le terminal » en moins de dix minutes.
- Manipuler le cycle de vie des modèles (`pull`, `run`, `list`, `ps`, `rm`) comme on manipule des images Docker.
- Interroger votre modèle depuis Python, TypeScript ou `curl`, en API native **et** en API compatible OpenAI, ce qui prépare directement la L046 (n8n, Open WebUI).
- Fabriquer votre propre « assistant » local avec un Modelfile.

## 1. Ollama, c'est quoi ?

**Ollama** est un petit logiciel (licence MIT) qui joue deux rôles : un **serveur** qui charge les modèles en mémoire et répond à des requêtes HTTP, et une **ligne de commande** (CLI) qui télécharge et pilote les modèles. Il s'appuie sur le moteur **llama.cpp** et le format **GGUF** (vus en L042), gère automatiquement le GPU (Metal sur Mac, CUDA sur NVIDIA, ROCm sur AMD) et bascule sur le CPU si nécessaire.

Si vous avez déjà touché à Docker, vous allez vous sentir chez vous : `ollama pull` télécharge une image, `ollama run` la lance, `ollama list` affiche ce qui est installé, `ollama ps` ce qui tourne. Ce n'est pas un hasard : l'équipe d'Ollama a sciemment copié cette ergonomie, et c'est ce qui en a fait l'outil le plus répandu chez les développeurs (le dossier de recherche du module le classe en tête des recommandations « développeur » avec Open WebUI).

Ce qu'Ollama n'est **pas** : une interface graphique riche (voir L044) ni un serveur haute performance multi-utilisateurs (pour cela, vLLM, qui sera évoqué au module 29). Pour un poste de travail ou un petit serveur d'équipe, c'est l'outil idéal.

> ⚠️ **Piège fréquent** — Depuis 2025, le catalogue d'Ollama contient aussi des **modèles « cloud »**, exécutés sur les serveurs d'Ollama et non sur votre machine. Même commande `ollama run`, mais vos données partent sur Internet. Dans le catalogue, vérifiez le tag et la mention *cloud* avant de lancer un modèle sur des données confidentielles. Un bon réflexe : `ollama ps` doit montrer le modèle **chargé localement** (avec sa taille et son processeur GPU/CPU) ; un modèle cloud n'occupe pas votre mémoire.

## 2. Installation (10 minutes, tous systèmes)

| Système | Méthode | Vérification |
|---|---|---|
| **macOS** (Apple Silicon et Intel) | Télécharger l'application sur ollama.com/download, la glisser dans Applications, la lancer : une icône apparaît dans la barre de menus | `ollama --version` dans le Terminal |
| **Windows** 10/11 | Installeur `.exe` sur ollama.com/download ; détecte automatiquement une carte NVIDIA ou AMD | `ollama --version` dans PowerShell |
| **Linux** | Une ligne de commande (ci-dessous) ; installe aussi un service `systemd` | `systemctl status ollama` ou `ollama --version` |
| **Docker** | Image officielle `ollama/ollama` (utile sur un serveur) | `docker ps` |

```bash
# Linux : installation en une ligne (script officiel)
curl -fsSL https://ollama.com/install.sh | sh

# Vérifier la version installée (tous systèmes)
ollama --version

# Démarrer le serveur à la main si nécessaire (il tourne déjà en service sur Linux
# et via l'icône de barre de menus / barre des tâches sur macOS et Windows)
ollama serve
```

Le serveur écoute par défaut sur **`http://localhost:11434`**. Pour vérifier qu'il répond, ouvrez cette adresse dans un navigateur : vous devez lire « Ollama is running ». Retenez ce numéro de port, vous le taperez dix fois dans ce module.

> 🔗 **Documentation officielle** — [Ollama — Téléchargement](https://ollama.com/download) et [Ollama — Documentation](https://docs.ollama.com)

## 3. Télécharger et lancer un premier modèle

Le catalogue est sur **ollama.com/search**. Chaque modèle a un **nom** et des **tags** (variantes) : `qwen3.8:27b`, `gemma4:26b`, `gpt-oss:20b`, `gpt-oss:120b`, `mistral-small`, `llama3.1:8b`… Le tag précise souvent la taille (`:8b`, `:27b`) et parfois la quantization (`:27b-q8_0`). Sans tag, Ollama prend la variante par défaut, généralement en 4 bits.

Appliquez d'abord ce que vous avez appris en L042 : lisez la taille du téléchargement affichée dans le catalogue et comparez-la à votre mémoire utilisable. Sur un portable 16 Go, commencez par un 8B ou gpt-oss-20b ; sur 32 Go, un 27B ; sur 128 Go, gpt-oss-120b.

```bash
# Télécharger seulement (sans ouvrir de chat)
ollama pull gemma4:26b

# Télécharger si besoin PUIS ouvrir un chat interactif dans le terminal
ollama run qwen3.8:27b

# Lister les modèles installés sur le disque (nom, identifiant, taille, date)
ollama list

# Voir les modèles actuellement chargés en mémoire, leur taille et s'ils tournent
# sur GPU ou CPU (colonne PROCESSOR : « 100% GPU » est ce que vous voulez lire)
ollama ps

# Afficher la fiche d'un modèle : architecture, paramètres, contexte, quantization, licence
ollama show qwen3.8:27b

# Supprimer un modèle du disque
ollama rm llama3.1:8b
```

Dans le chat interactif, quelques commandes commencent par une barre oblique : `/set parameter temperature 0.2` ajuste la température pour la session, `/show info` affiche la fiche, `/bye` quitte. Les modèles multimodaux (Qwen3.8-27B, Gemma 4) acceptent une image en glissant son chemin dans le prompt.

Première conversation suggérée, pour se rendre compte de la qualité en français :

```
>>> Rédige en français un e-mail de relance courtois pour une facture impayée de 1 250 € HT,
    échue depuis 15 jours, adressé à un client régulier. Ton professionnel, 6 lignes maximum.
```

Observez trois choses : le **temps avant le premier mot** (prefill), la **vitesse d'écriture** (génération), et la **qualité du français**. Puis tapez `/bye` et lancez `ollama ps` : vous verrez le modèle encore chargé (Ollama le garde en mémoire 5 minutes par défaut pour répondre vite à la requête suivante).

> 💡 **À retenir** — `ollama run` fait trois choses à la fois : télécharger si absent, charger en mémoire, ouvrir le chat. Pour un serveur, préférez `pull` (au déploiement) puis des appels API (à l'usage) ; le chat interactif est un outil de test, pas de production.

## 4. Où vont les fichiers, et comment les déplacer ?

Les modèles sont stockés dans `~/.ollama/models` (macOS, Linux) ou `C:\Users\<vous>\.ollama\models` (Windows). Avec 5 à 10 modèles, le dossier atteint vite 50 à 150 Go : sur un portable au SSD saturé, déplacez-le vers un disque externe rapide ou une seconde partition avec la variable d'environnement `OLLAMA_MODELS`. Deux autres variables servent souvent : `OLLAMA_HOST` pour écouter sur une autre adresse ou un autre port (par exemple `0.0.0.0:11434` pour rendre le serveur accessible depuis d'autres machines du réseau — à ne faire que derrière un pare-feu), et `OLLAMA_KEEP_ALIVE` pour changer la durée pendant laquelle un modèle reste chargé. La liste complète et la façon de les définir par système sont dans la documentation (section FAQ), vérifiez-y la syntaxe exacte pour votre OS.

## 5. L'API locale : le vrai pouvoir d'Ollama

Tout ce que fait la CLI, l'API HTTP le fait aussi. C'est elle que vous brancherez sur n8n, Open WebUI, vos scripts et vos applications. Elle existe en **deux dialectes** sur le même port.

### 5.1 API native Ollama (`/api/generate`, `/api/chat`)

```bash
# Génération simple (un prompt → une réponse), sans streaming pour lire d'un bloc
curl http://localhost:11434/api/generate -d '{
  "model": "qwen3.8:27b",
  "prompt": "Explique en deux phrases ce qu est la TVA à un apprenti boulanger.",
  "stream": false
}'

# Conversation multi-tours avec un prompt système
curl http://localhost:11434/api/chat -d '{
  "model": "qwen3.8:27b",
  "messages": [
    { "role": "system", "content": "Tu es l assistant RH d une PME française. Réponds en français, de façon concise." },
    { "role": "user", "content": "Combien de jours de congés payés acquiert-on par mois travaillé ?" }
  ],
  "stream": false,
  "options": { "temperature": 0.2, "num_ctx": 8192 }
}'

# Liste des modèles installés, en JSON (équivalent de ollama list)
curl http://localhost:11434/api/tags
```

Le champ `options` permet de régler la **température** (0 à 1 : plus bas = plus déterministe, idéal pour l'extraction de données ; plus haut = plus créatif), `top_p`, et surtout **`num_ctx`**, la taille de la fenêtre de contexte allouée. Rappel de L042 : plus `num_ctx` est grand, plus le KV cache consomme de mémoire. Ollama applique une valeur par défaut modeste ; pour résumer de longs documents, montez-la explicitement (16384, 32768) après avoir vérifié avec `ollama ps` que tout reste sur le GPU.

Par défaut, l'API renvoie la réponse en **streaming** (une ligne JSON par morceau de texte) : c'est ce qui permet d'afficher le texte au fil de l'eau dans une interface. Mettez `"stream": false` pour recevoir un seul objet JSON, plus simple à traiter dans un script ou dans n8n.

### 5.2 API compatible OpenAI (`/v1/chat/completions`)

C'est la fonctionnalité la plus importante de ce module. Ollama expose les mêmes chemins et le même format JSON que l'API d'OpenAI sur **`http://localhost:11434/v1`**. Conséquence : **tout outil capable de parler à OpenAI peut parler à votre modèle local** en changeant simplement l'adresse de base et en mettant n'importe quelle chaîne comme clé API. La documentation d'Ollama indique aussi (2026) une compatibilité avec les clients au format Anthropic.

```bash
# Même requête, format OpenAI. La clé est obligatoire pour le client mais ignorée par Ollama.
curl http://localhost:11434/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ollama" \
  -d '{
    "model": "qwen3.8:27b",
    "messages": [
      { "role": "system", "content": "Tu réponds en français, en une phrase." },
      { "role": "user", "content": "Quelle est la capitale de la Nouvelle-Aquitaine ?" }
    ],
    "temperature": 0
  }'
```

### 5.3 Depuis Python

Deux options : la bibliothèque officielle `ollama` (`pip install ollama`) ou le SDK `openai` pointé vers le serveur local. La seconde a un avantage énorme : **le même code fonctionne avec un modèle local ou avec l'API OpenAI** en changeant deux variables d'environnement. C'est le schéma recommandé pour les projets « hybrides » décrits en L041.

```python
# fichier : demo_ollama.py — Python 3.12+, pip install openai
# Lancer : OPENAI_BASE_URL=http://localhost:11434/v1 OPENAI_API_KEY=ollama python demo_ollama.py
import os
from openai import OpenAI

# Les deux variables sont lues dans l'environnement : aucune clé dans le code.
# Pour basculer sur OpenAI, il suffit de les changer (base_url par défaut + vraie clé).
client = OpenAI(
    base_url=os.environ.get("OPENAI_BASE_URL", "http://localhost:11434/v1"),
    api_key=os.environ.get("OPENAI_API_KEY", "ollama"),  # ignorée par Ollama, mais requise par le SDK
)

MODELE = os.environ.get("MODELE_LOCAL", "qwen3.8:27b")

def classer_ticket(texte: str) -> str:
    """Classe un ticket de support en une catégorie parmi quatre, température 0 pour la stabilité."""
    reponse = client.chat.completions.create(
        model=MODELE,
        temperature=0,
        messages=[
            {"role": "system", "content": (
                "Tu es un assistant de support d'une PME française. "
                "Classe le message dans UNE catégorie : facturation, technique, commercial, autre. "
                "Réponds uniquement par le nom de la catégorie, en minuscules."
            )},
            {"role": "user", "content": texte},
        ],
    )
    return reponse.choices[0].message.content.strip()

if __name__ == "__main__":
    tickets = [
        "Bonjour, je n'ai toujours pas reçu l'avoir pour la facture F-2026-118.",
        "L'application plante au démarrage depuis la mise à jour d'hier.",
        "Pouvez-vous m'envoyer un devis pour 25 licences supplémentaires ?",
    ]
    for t in tickets:
        print(f"{classer_ticket(t):<12} ← {t}")
```

### 5.4 Depuis TypeScript

```typescript
// fichier : demo_ollama.ts — Node 22+, npm install openai ; lancer : npx tsx demo_ollama.ts
import OpenAI from "openai";

// Même logique : adresse et clé lues dans l'environnement, jamais en dur dans le code.
const client = new OpenAI({
  baseURL: process.env.OPENAI_BASE_URL ?? "http://localhost:11434/v1",
  apiKey: process.env.OPENAI_API_KEY ?? "ollama",
});

async function resumer(texte: string): Promise<string> {
  // Streaming : on affiche les morceaux au fil de l'eau, comme dans une interface de chat.
  const flux = await client.chat.completions.create({
    model: process.env.MODELE_LOCAL ?? "gemma4:26b",
    stream: true,
    messages: [
      { role: "system", content: "Résume en français, en trois puces, le texte fourni." },
      { role: "user", content: texte },
    ],
  });
  let resultat = "";
  for await (const morceau of flux) {
    const delta = morceau.choices[0]?.delta?.content ?? "";
    process.stdout.write(delta); // affichage progressif
    resultat += delta;
  }
  process.stdout.write("\n");
  return resultat;
}

resumer(
  "Le conseil municipal a voté le budget 2027 : 2,3 M€ d'investissement, dont 800 k€ pour la " +
  "rénovation énergétique de l'école, 500 k€ pour la voirie et 300 k€ pour la médiathèque. " +
  "Les taux d'imposition restent inchangés pour la troisième année consécutive."
).catch(console.error);
```

> 💡 **À retenir** — Trois adresses à mémoriser : `http://localhost:11434` (le serveur), `/api/chat` (API native, avec `options.num_ctx`), `/v1/chat/completions` (API compatible OpenAI, pour tous les outils tiers).

## 6. Personnaliser un modèle : le Modelfile

Un **Modelfile** est à Ollama ce qu'un Dockerfile est à Docker : un fichier texte qui part d'un modèle de base et fixe un prompt système, des paramètres, voire un gabarit de conversation. Résultat : un nouveau nom de modèle, prêt à l'emploi pour toute l'équipe, qui n'oublie jamais ses consignes.

```bash
# fichier : Modelfile (sans extension), dans le dossier courant
# Modèle de base : choisir un tag réellement installé (ollama list)
cat > Modelfile <<'EOF'
FROM qwen3.8:27b

# Paramètres d'échantillonnage : bas pour un assistant « sérieux »
PARAMETER temperature 0.2
PARAMETER top_p 0.9
# Fenêtre de contexte allouée (attention à la mémoire, voir L042)
PARAMETER num_ctx 16384

# Consignes permanentes
SYSTEM """
Tu es « Compta-Assistant », l'assistant interne d'un cabinet d'expertise comptable français.
Tu réponds toujours en français, de manière structurée et prudente.
Tu ne donnes jamais de conseil fiscal définitif : tu rappelles de vérifier auprès de l'expert-comptable référent.
Quand on te fournit une facture, tu extrais : fournisseur, date, numéro, montant HT, TVA, TTC, au format JSON.
"""
EOF

# Construire le modèle personnalisé
ollama create compta-assistant -f Modelfile

# L'utiliser comme n'importe quel modèle (CLI ou API avec "model": "compta-assistant")
ollama run compta-assistant
```

Le Modelfile accepte d'autres instructions (`TEMPLATE`, `ADAPTER` pour charger un adaptateur LoRA issu d'un fine-tuning, `LICENSE`, `MESSAGE` pour des exemples) : la référence complète est dans la documentation. Il peut aussi partir directement d'un fichier GGUF téléchargé sur Hugging Face (`FROM ./mon-modele.gguf`), ce qui permet d'exécuter un modèle absent du catalogue officiel.

> ⚠️ **Piège fréquent** — Un Modelfile ne crée **pas** une copie des poids : `ollama create` ajoute une petite couche de configuration par-dessus le modèle de base. Vous pouvez donc créer dix assistants spécialisés sans multiplier l'espace disque par dix. En revanche, si vous supprimez le modèle de base, les dérivés cessent de fonctionner.

## 7. Dépannage express

| Symptôme | Cause probable | Remède |
|---|---|---|
| `ollama ps` affiche « CPU » ou un pourcentage GPU partiel | Le modèle ou son KV cache déborde de la VRAM / mémoire unifiée | Modèle plus petit, quantization plus forte, ou `num_ctx` plus bas |
| Première réponse très lente, puis rapide | Chargement du modèle depuis le disque | Normal ; augmentez `OLLAMA_KEEP_ALIVE` sur un serveur |
| « connection refused » sur 11434 | Le serveur n'est pas lancé | `ollama serve` (Linux : `systemctl start ollama`) |
| n8n ou Open WebUI dans Docker ne joint pas Ollama | `localhost` dans le conteneur ≠ `localhost` de l'hôte | Utiliser `host.docker.internal:11434` ou `--network=host` (voir L046) |
| Le modèle répond en anglais | Prompt système absent | Ajoutez « Réponds en français » dans `SYSTEM` ou le premier message |

## 🧪 Exercice pratique

**Consigne.** Sur votre machine (ou une machine de la salle) :

1. Installez Ollama et vérifiez que `http://localhost:11434` répond.
2. En appliquant la L042, choisissez un modèle adapté à votre mémoire (8B ou gpt-oss-20b en 16 Go ; 27B en 32 Go) et téléchargez-le avec `ollama pull`.
3. Lancez-le avec `ollama run`, posez trois questions professionnelles en français, notez la vitesse approximative (mots par seconde) et `ollama ps` (GPU ou CPU ?).
4. Créez un Modelfile « assistant-<votre métier> » avec un prompt système en français et `temperature 0.2`, construisez-le avec `ollama create`.
5. Appelez-le une fois via `curl` sur `/api/chat` (`"stream": false`) et une fois via `/v1/chat/completions`.
6. Bonus : adaptez `demo_ollama.py` pour classer cinq messages de votre activité.

**Critères de réussite.** Le serveur répond ; `ollama ps` montre « 100% GPU » (ou vous expliquez pourquoi ce n'est pas le cas) ; le modèle personnalisé apparaît dans `ollama list` ; les deux appels API renvoient un JSON valide contenant une réponse en français ; aucune clé ni adresse n'est écrite en dur dans le script bonus.

**Pistes de corrigé.** Si `ollama ps` indique un pourcentage CPU, c'est presque toujours un problème de taille (reprenez la formule de L042) ou de `num_ctx` trop ambitieux. La réponse de `/api/chat` est dans `message.content` ; celle de `/v1/chat/completions` dans `choices[0].message.content` : c'est précisément cette seconde structure que n8n et Open WebUI attendent.

## ✅ Auto-évaluation express

1. Quelle différence entre `ollama pull` et `ollama run` ?
2. Sur quel port et quel chemin un outil « compatible OpenAI » doit-il pointer pour utiliser Ollama ?
3. Que vérifie-t-on avec `ollama ps` et pourquoi est-ce important pour la vitesse ?

*Réponses :* 1. `pull` télécharge seulement ; `run` télécharge si besoin, charge en mémoire et ouvre un chat interactif. 2. `http://localhost:11434/v1` (par exemple `/v1/chat/completions`), avec une clé API quelconque. 3. Les modèles chargés, leur taille et la répartition GPU/CPU ; un modèle partiellement sur CPU est 5 à 10 fois plus lent (déport mémoire, L042).

## 📚 Pour aller plus loin
- [Ollama — Documentation officielle](https://docs.ollama.com) 🇬🇧 — référence de la CLI, de l'API (`/api/generate`, `/api/chat`), de la compatibilité OpenAI et du Modelfile.
- [Ollama — Catalogue de modèles](https://ollama.com/search) 🇬🇧 — pour lire les tags, tailles et licences avant de télécharger ; filtrez par capacités (vision, outils, embeddings).
- [Guide — Ollama : run large language models on your machine](https://kx.cloudingenium.com/en/ollama-local-llm-run-large-language-models-machine-guide/) 🇬🇧 — pas-à-pas illustré des commandes et des ordres de grandeur mémoire.
- [Pinggy — Best Local LLM Tools and Models in 2026](https://pinggy.io/blog/top_5_local_llm_tools_and_models/) 🇬🇧 — Ollama comparé aux autres outils, licences et ports par défaut.
