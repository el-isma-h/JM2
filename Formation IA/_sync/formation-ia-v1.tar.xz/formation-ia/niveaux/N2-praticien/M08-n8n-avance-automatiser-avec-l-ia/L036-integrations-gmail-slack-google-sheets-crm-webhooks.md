---
id: L036
module: M08
level: N2
title: "Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks"
minutes: 55
objectives:
  - "Configurer les credentials OAuth2 Google et Slack et expliquer la différence entre déclencheur par sondage (polling) et par webhook"
  - "Construire un Webhook Trigger sécurisé (authentification, URL de test / production, réponse immédiate ou différée)"
  - "Appliquer les nœuds Gmail, Slack, Google Sheets et un nœud CRM (HubSpot / Pipedrive) dans un flux complet avec expressions exactes"
  - "Construire un appel d'API sans nœud dédié avec HTTP Request (authentification, pagination)"
skills: ["C2.1"]
sources:
  - { title: "n8n Academy — N8N102 Integrations: APIs & Connected Workflows", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about", lang: "en" }
  - { title: "n8n Docs — Build your first workflow", url: "https://docs.n8n.io/build-your-first-workflow.md", lang: "en" }
  - { title: "n8n Docs — Human in the loop for tools", url: "https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md", lang: "en" }
  - { title: "n8n Docs — Data Tables", url: "https://docs.n8n.io/build/work-with-data/data-tables.md", lang: "en" }
---

# Intégrations : Gmail, Slack, Google Sheets, CRM, webhooks

> ⏱ 55 min · 🎯 Niveau 2 · 📚 Module 8

## 🎯 Ce que vous saurez faire
- Connecter n8n à Google (Gmail, Sheets, Drive), Slack et un CRM via OAuth2, en comprenant ce que vous autorisez.
- Recevoir des données de n'importe quelle application grâce au **Webhook Trigger**, et répondre correctement.
- Écrire les paramètres exacts des nœuds Gmail, Slack, Google Sheets, avec leurs expressions.
- Appeler une API qui n'a pas de nœud n8n avec **HTTP Request**, pagination comprise.
- Choisir entre déclencheur par sondage, webhook et planification.

## 1. Trois façons de démarrer un workflow

Tout workflow commence par un déclencheur ; le cours N8N101 en distingue trois familles, et le choix conditionne la réactivité et la charge :

| Famille | Exemple | Délai de réaction | Coût / charge |
|---|---|---|---|
| **Planifié** (*Schedule Trigger*) | Tous les jours à 7 h 30, toutes les 15 minutes | Fixé par vous | Nul entre deux passages |
| **Sondage** (*polling*, ex. Gmail Trigger, Google Sheets Trigger) | n8n interroge le service toutes les N minutes | 1 à 60 min selon le réglage | Une requête par intervalle, même sans nouveauté |
| **Webhook** (*Webhook Trigger*, Slack Trigger, HubSpot Trigger, Stripe, Typeform…) | Le service appelle n8n dès qu'un événement survient | Quasi immédiat | Nul au repos, mais n8n doit être **joignable depuis Internet** (HTTPS, leçon 37) |

Analogie : le sondage, c'est aller voir la boîte aux lettres toutes les heures ; le webhook, c'est le facteur qui sonne. Gmail n'a pas de webhook natif dans n8n : le Gmail Trigger est un sondage (par défaut toutes les minutes). Slack, HubSpot, Stripe, Typeform, Calendly ou votre propre site offrent de vrais webhooks.

## 2. OAuth2 : ce que vous signez

Google et Slack utilisent OAuth2. Concrètement : vous créez une « application » dans la console du fournisseur (Google Cloud Console, api.slack.com), vous y collez l'**OAuth Redirect URL** affichée par n8n dans la credential, vous récupérez *Client ID* et *Client Secret*, puis vous cliquez *Sign in* : une fenêtre du fournisseur vous demande d'autoriser des **scopes** (périmètres : « lire vos e-mails », « envoyer des messages », « modifier vos feuilles »). n8n stocke le jeton et le rafraîchit seul. Sur n8n Cloud, des applications Google et Slack pré-enregistrées simplifient l'étape ; en auto-hébergement, vous créez les vôtres.

Trois réflexes : (1) utilisez un **compte de service ou un compte dédié** (`automatisation@votre-domaine.fr`), pas le compte personnel du dirigeant ; (2) n'accordez que les scopes nécessaires ; (3) notez la date d'expiration des secrets (Google impose un renouvellement pour les applications en mode « test »).

> ⚠️ **Piège fréquent** — Credential Google créée avec un compte personnel ; la personne quitte l'entreprise, son compte est fermé, toutes les automatisations tombent le même jour. Les credentials doivent appartenir à l'organisation.

## 3. Gmail : lire, trier, répondre

**Gmail Trigger** : *Event → Message Received*, filtres `label`, `from`, `subject`, ou une requête Gmail (`is:unread to:support@… -label:traite`). Il renvoie un item par e-mail avec, entre autres, `{{ $json.id }}`, `{{ $json.threadId }}`, `{{ $json.from.value[0].address }}` (selon l'option *Simplify*), `{{ $json.subject }}`, `{{ $json.text }}` ou `{{ $json.snippet }}`. Activez *Simplify* pour avoir des champs plats, et testez toujours avec un vrai e-mail pour vérifier les chemins exacts (ils dépendent de la version du nœud).

**Gmail node** : *Message → Reply* (répondre dans le fil, paramètre `Message ID` = `{{ $('Gmail Trigger').item.json.id }}`), *Send* (nouvel e-mail), *Add Label* / *Remove Label* (idéal pour marquer « traité » et éviter de retraiter), *Create Draft* (brouillon à relire par un humain, parfait pour la validation). Le corps accepte du texte ou du HTML :

```text
To      : {{ $('Gmail Trigger').item.json.from.value[0].address }}
Subject : Re: {{ $('Gmail Trigger').item.json.subject }}
Message : Bonjour {{ $json.prenom }},

{{ $json.reponse }}

Bien cordialement,
L'équipe support — ticket {{ $json.ticket_id }}
```

## 4. Slack : notifier et interagir

Le nœud Slack fonctionne avec une **Slack App** (jeton *Bot* OAuth2 ou *Bot Token*) invitée dans le canal cible. Opérations clés : *Message → Send* (canal ou utilisateur, texte, blocs), *Send and Wait for Approval* (le message contient des boutons Approuver / Rejeter et le workflow **attend** la réponse : c'est la brique « validation humaine » du projet de la leçon 38), *Message → Update*, *Reaction → Add*, *File → Upload*. Le **Slack Trigger** réagit aux messages, mentions ou réactions, en vrai webhook.

Le texte supporte la syntaxe Slack (`*gras*`, `<url|texte>`, `:emoji:`) et les expressions :

```text
=:inbox_tray: *Nouveau ticket* {{ $json.ticket_id }}
> {{ $json.resume }}
Catégorie : `{{ $json.categorie }}` · Priorité : {{ $json.priorite === 'haute' ? ':red_circle:' : ':large_blue_circle:' }}
```

> 💡 **À retenir** — Le préfixe `=` au début d'un champ indique à n8n que tout le champ est une expression (mode *Expression*). Dans l'interface, le basculement *Fixed / Expression* fait la même chose.

## 5. Google Sheets : la base de données du pauvre (et c'est très bien)

Opérations : *Append Row* (ajouter), *Append or Update* (ajouter ou mettre à jour selon une **colonne de correspondance**, par exemple `ticket_id` : la plus utile), *Get Row(s)* (avec filtre), *Update Row*, *Delete*, *Clear*. Le **mapping** se fait automatiquement par nom de colonne (*Map Automatically*, les clés de `$json` doivent porter le nom des colonnes) ou manuellement (*Map Each Column Below*). Le **Google Sheets Trigger** (sondage) détecte les lignes ajoutées ou modifiées.

Pour un journal de tickets, prévoyez les colonnes `date`, `ticket_id`, `client`, `categorie`, `statut`, `reponse`, `validee_par`. Quand le volume dépasse quelques milliers de lignes ou que plusieurs workflows écrivent en même temps, passez aux **Data Tables** de n8n ou à PostgreSQL.

## 6. CRM : HubSpot, Pipedrive, et les autres

n8n a des nœuds dédiés pour HubSpot, Pipedrive, Salesforce, Zoho CRM, Brevo, et des déclencheurs webhook pour la plupart. Le schéma type « créer ou mettre à jour un contact » :

```
Webhook (formulaire site) ─► Edit Fields (normaliser email en minuscules, nom, source)
   ─► HubSpot : Contact → Get (par email) [On Error: Continue (error output)]
        ├─ trouvé   ─► HubSpot : Contact → Update (ajouter note « a rempli le formulaire »)
        └─ introuvable (sortie error ou item vide) ─► HubSpot : Contact → Create
```

Rappel de la leçon 33 : une création sans vérification préalable produit des doublons au premier retry. Et pensez RGPD : le formulaire doit informer la personne, et la finalité du traitement (prospection) doit être documentée (module 7).

## 7. Le Webhook Trigger : la porte d'entrée universelle

Le nœud **Webhook** donne à votre workflow une URL. Paramètres :

- **HTTP Method** : POST pour recevoir des données, GET pour un simple appel.
- **Path** : `support-entrant` → URL `https://n8n.votre-domaine.fr/webhook/support-entrant`.
- **Authentication** : *Header Auth* (un en-tête secret `X-Token: …` que l'appelant doit envoyer), *Basic Auth*, ou *JWT*. **Ne laissez jamais un webhook de production sans authentification** : n'importe qui trouvant l'URL pourrait déclencher vos workflows et vos envois.
- **Respond** : *Immediately* (répond « reçu » tout de suite, puis traite), *When Last Node Finishes* (répond avec la sortie du dernier nœud), *Using 'Respond to Webhook' Node* (vous construisez la réponse où vous voulez dans le flux, avec code HTTP et corps personnalisés).

Deux URLs existent : **Test URL** (active seulement pendant que vous cliquez *Listen for test event*, affiche les données dans l'éditeur) et **Production URL** (active quand le workflow est *Active*). Les données arrivent dans `{{ $json.body.… }}` (corps), `{{ $json.headers.… }}`, `{{ $json.query.… }}` (paramètres d'URL).

Test depuis votre terminal :

```bash
# Envoi d'une demande de support fictive au webhook (URL de test)
curl -X POST "https://n8n.votre-domaine.fr/webhook-test/support-entrant" \
  -H "Content-Type: application/json" \
  -H "X-Token: $N8N_WEBHOOK_TOKEN" \
  -d '{"email":"c.martin@exemple.fr","sujet":"Facture en double","message":"Bonjour, j ai reçu deux fois la facture F-2026-118."}'
```

> ⚠️ **Piège fréquent** — Tester avec la Test URL, puis activer le workflow et s'étonner que « plus rien n'arrive » : l'appelant doit passer à la **Production URL** (`/webhook/` sans `-test`).

## 8. HTTP Request : quand il n'y a pas de nœud

Pour les API sans nœud dédié (votre logiciel de caisse, un ERP, une API publique), le nœud **HTTP Request** est le couteau suisse : méthode, URL, en-têtes, paramètres de requête, corps JSON, authentification par credential (*Predefined* : réutiliser la credential HubSpot, OpenAI… ; *Generic* : Header Auth, Basic, OAuth2, Digest, Query Auth). Dans *Options* : **Pagination** (par page, par curseur ou par URL « suivante » renvoyée dans la réponse, avec une condition d'arrêt), **Batching** (N requêtes par lot, pause entre lots pour respecter les limites de débit), **Timeout**, **Response → Include headers and status**.

```text
URL        : https://api.exemple.fr/v1/factures
Query      : statut = impayee ; page = {{ $pageIndex ?? 1 }}   (géré par l'option Pagination)
Auth       : Generic → Header Auth (credential « ERP — prod »)
Pagination : Update a Parameter in Each Request → page, +1 ; Pause 500 ms ; Complete when `{{ $response.body.factures.length === 0 }}`
```

Si l'API renvoie un objet enveloppant (`{ "factures": [...] }`), enchaînez un **Split Out** sur `factures` pour obtenir un item par facture (leçon 32).

> 🔗 **Documentation officielle** — [n8n Academy — N8N102](https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about) 🇬🇧 (section 2 : GET/POST/PUT/PATCH/DELETE, clé API, OAuth2, Bearer, pagination, Webhook Trigger, Data Tables) et [n8n Docs — Human in the loop for tools](https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md) 🇬🇧 (validation Slack).

## 🎮 Défi : où est la fuite ?

Un workflow « Webhook (sans authentification) → AI Agent → Gmail Send » est actif depuis trois semaines pour répondre aux questions d'un formulaire. Le compte Gmail est suspendu pour « envoi massif ». Que s'est-il passé, et quelles sont les deux corrections ? Réponse en fin de leçon.

## 🧪 Exercice pratique

**Consigne.** Montez le flux « ticket entrant » : (1) Webhook POST `support-entrant` protégé par Header Auth, réponse via *Respond to Webhook* renvoyant `{ "ticket_id": "…" }` ; (2) Edit Fields générant `ticket_id` = `{{ 'T-' + $now.toFormat('yyyyMMdd') + '-' + $execution.id.slice(-4) }}` ; (3) Google Sheets *Append or Update* sur `ticket_id` ; (4) Slack *Send* dans `#support` avec le message de la section 4 ; (5) Gmail *Send* (ou *Create Draft*) d'accusé de réception au client. Testez avec la commande `curl` ci-dessus, puis activez le workflow et retestez avec l'URL de production. Variante sans Google : remplacez Sheets par une Data Table et Gmail par un nœud *Send Email* SMTP.

**Critères de réussite.**
- Un appel sans en-tête `X-Token` est refusé (code 403), un appel avec est accepté et reçoit le `ticket_id` en réponse.
- La ligne apparaît dans Sheets, le message dans Slack, l'e-mail dans la boîte du « client » (vous).
- Un second appel avec le même `ticket_id` met la ligne à jour au lieu de la dupliquer.
- Toutes les credentials appartiennent à un compte dédié, aucune clé en clair.

**Pistes de corrigé.** Pour *Respond to Webhook*, placez-le juste après Edit Fields avec *Respond With → JSON* et `={{ { "ticket_id": $json.ticket_id } }}` ; le reste du flux continue après. Si Slack renvoie `not_in_channel`, invitez l'application dans le canal (`/invite @votre-app`).

## ✅ Auto-évaluation express

1. **Gmail Trigger : webhook ou sondage ?**
   → Sondage (n8n interroge Gmail à intervalle régulier).
2. **Quelle différence entre Test URL et Production URL ?**
   → La Test URL n'écoute que pendant l'écoute manuelle dans l'éditeur ; la Production URL fonctionne quand le workflow est actif.
3. **Quelle opération Google Sheets évite les doublons ?**
   → *Append or Update* avec une colonne de correspondance (par exemple `ticket_id`).

**Réponse du défi.** L'URL du webhook, sans authentification, a été découverte (ou simplement devinée) et appelée des milliers de fois, chaque appel déclenchant un e-mail. Corrections : (1) Header Auth ou JWT sur le webhook, et un contrôle du format des données reçues (IF sur la présence et la validité de l'e-mail) ; (2) un plafond de sécurité (Limit par heure via Data Table, et *Create Draft* au lieu de *Send* tant que la validation humaine n'est pas en place).

## 📚 Pour aller plus loin
- [n8n Academy — N8N102 Integrations: APIs & Connected Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about) 🇬🇧 — le cours de référence sur les API et les intégrations (4 à 6 h).
- [n8n Docs — Build your first workflow](https://docs.n8n.io/build-your-first-workflow.md) 🇬🇧 — tutoriel officiel avec credentials et premier déclencheur.
- [n8n Docs — Data Tables](https://docs.n8n.io/build/work-with-data/data-tables.md) 🇬🇧 — l'alternative intégrée à Google Sheets.
- [n8n Docs — Use templates](https://docs.n8n.io/build/ways-of-building-workflows/use-templates.md) 🇬🇧 — des centaines de templates Gmail / Slack / Sheets / CRM à lire nœud par nœud avant usage.
