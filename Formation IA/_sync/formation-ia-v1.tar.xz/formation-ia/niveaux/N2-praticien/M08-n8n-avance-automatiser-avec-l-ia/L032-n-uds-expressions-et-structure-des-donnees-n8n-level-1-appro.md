---
id: L032
module: M08
level: N2
title: "Nœuds, expressions et structure des données (n8n Level 1 approfondi)"
minutes: 55
objectives:
  - "Expliquer la structure de données de n8n (tableau d'items { json, binary }) et son effet sur chaque nœud"
  - "Écrire des expressions {{ $json… }}, $('Nœud'), $now, $env exactes pour transformer des données"
  - "Appliquer les nœuds Edit Fields (Set), IF, Switch, Merge, Loop Over Items et Code à un flux métier"
skills: ["C2.1"]
sources:
  - { title: "n8n Academy — N8N101 Essentials: Your First Workflows", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N101+2026H2/about", lang: "en" }
  - { title: "n8n Academy — N8N102 Integrations: APIs & Connected Workflows", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about", lang: "en" }
  - { title: "n8n Docs — Build your first workflow", url: "https://docs.n8n.io/build-your-first-workflow.md", lang: "en" }
  - { title: "n8n Docs — Learning paths", url: "https://docs.n8n.io/learning-paths", lang: "en" }
  - { title: "n8n Docs — Data Tables", url: "https://docs.n8n.io/build/work-with-data/data-tables.md", lang: "en" }
---

# Nœuds, expressions et structure des données (n8n Level 1 approfondi)

> ⏱ 55 min · 🎯 Niveau 2 · 📚 Module 8

## 🎯 Ce que vous saurez faire
- Lire n'importe quelle sortie de nœud n8n comme un **tableau d'items** et prédire ce que le nœud suivant va recevoir.
- Écrire des expressions exactes : `{{ $json.email }}`, `{{ $('Webhook').item.json.body.nom }}`, `{{ $now.toFormat('dd/MM/yyyy') }}`.
- Choisir sans hésiter entre Edit Fields (Set), IF, Switch, Merge, Filter, Split Out, Aggregate, Loop Over Items et Code.
- Reconnaître les deux modes du nœud Code et écrire une transformation JavaScript qui respecte le format n8n.

## 1. Pourquoi « approfondi » : ce que le niveau 1 vous a caché

Au module 6, vous avez construit vos premiers workflows : un déclencheur, deux ou trois nœuds, un résultat. Vous avez probablement cliqué sur « Execute » en croisant les doigts. Ce module commence là où la magie s'arrête et où la **compréhension** commence.

Depuis le 16 juin 2026, n8n a remplacé ses anciens cours texte « Level 1 / Level 2 » par la **n8n Academy** (learn.n8n.io). Le parcours **n8n Foundations** enchaîne trois cours : N8N101 *Essentials* (2 à 4 h), N8N102 *Integrations* (4 à 6 h) et N8N103 *In Practice: AI, Testing & Best Practices* (3 à 4 h). Chacun est évalué de la même façon : quiz de section 10 %, exercices pratiques 55 %, examen final 35 %, **70 % requis**, badge Accredible à la clé (nov. 2026). Les leçons 32 et 33 couvrent le contenu de N8N101 et N8N102 ; les leçons 34 à 38 couvrent N8N103 et vont au-delà. Nous vous encourageons à suivre ces cours en parallèle : ils sont gratuits à l'inscription (n8n Cloud en essai ou instance auto-hébergée) et la certification officielle chronométrée, repoussée à fin T4 2026, s'appuiera sur ce référentiel.

> 💡 **À retenir** — n8n Foundations = N8N101 + N8N102 + N8N103. Le certificat Next Formation atteste vos compétences selon notre référentiel ; il ne remplace pas le badge n8n, qu'il vous prépare à obtenir.

## 2. La structure de données : tout est un tableau d'items

Voici la règle qui explique 80 % des bugs n8n : **chaque nœud reçoit un tableau d'items et renvoie un tableau d'items**. Un item est un objet avec une clé `json` (vos données) et, optionnellement, une clé `binary` (fichiers).

```json
[
  { "json": { "nom": "Dupont", "email": "a.dupont@exemple.fr", "montant": 1250 } },
  { "json": { "nom": "Martin", "email": "c.martin@exemple.fr", "montant": 480 } }
]
```

Analogie : imaginez une chaîne de tri postal. Chaque nœud est un poste de travail ; les items sont les lettres qui défilent sur le tapis. Un poste peut lire chaque lettre, la tamponner, en jeter certaines, en découper une en plusieurs ou, à l'inverse, empiler toutes les lettres dans un seul carton. Mais le tapis transporte **toujours des lettres** : jamais une lettre « nue » hors enveloppe.

Trois conséquences pratiques :

| Situation | Ce que fait n8n | Ce que vous devez retenir |
|---|---|---|
| Un nœud reçoit 50 items | Il s'exécute **une fois par item** (la plupart des nœuds d'intégration) | 50 e-mails partent, pas un seul |
| Un nœud Google Sheets renvoie 200 lignes | 200 items, un par ligne | Le nœud suivant traitera 200 fois |
| Une API renvoie `{ "clients": [ … ] }` | **1 item** contenant un tableau dans `json.clients` | Il faut un **Split Out** pour obtenir un item par client |

Le paramètre **« Execute Once »** (onglet *Settings* de chaque nœud) force le nœud à ne traiter que le premier item : précieux pour envoyer une seule notification de synthèse.

> ⚠️ **Piège fréquent** — « Mon Slack a envoyé 37 messages identiques ! » Le nœud Slack recevait 37 items. Avant chaque nœud à effet de bord (e-mail, message, écriture), regardez le compteur d'items affiché sur la connexion.

## 3. Les expressions : le langage de n8n

Une expression s'écrit entre doubles accolades et commence par `$`. Tout ce qui est à l'intérieur est du JavaScript. Voici les variables que vous utiliserez tous les jours :

| Expression | Signification |
|---|---|
| `{{ $json.email }}` | Le champ `email` de l'item courant venant du nœud **précédent** |
| `{{ $json.adresse.ville }}` | Accès imbriqué (objet dans objet) |
| `{{ $json.lignes[0].prix }}` | Premier élément d'un tableau |
| `{{ $('Webhook').item.json.body.nom }}` | Même item, mais dans la sortie du nœud nommé *Webhook* (où qu'il soit en amont) |
| `{{ $('Google Sheets').first().json.total }}` | Premier item d'un nœud, utile pour un paramètre global |
| `{{ $('Google Sheets').all().length }}` | Nombre d'items produits par ce nœud |
| `{{ $input.item.json.x }}` / `{{ $input.all() }}` | Dans le nœud Code : item courant / tous les items |
| `{{ $now }}` · `{{ $today }}` | Date-heure actuelle (objet Luxon) · minuit du jour |
| `{{ $now.toFormat('dd/MM/yyyy HH:mm') }}` | Formatage français |
| `{{ $today.minus({ days: 30 }).toISODate() }}` | Il y a 30 jours au format `AAAA-MM-JJ` |
| `{{ $env.CRM_URL }}` | Variable d'environnement (auto-hébergement, leçon 37) |
| `{{ $execution.id }}` · `{{ $workflow.name }}` | Métadonnées de l'exécution et du workflow |
| `{{ $itemIndex }}` · `{{ $runIndex }}` | Position de l'item · numéro de passage (boucles) |

Le JavaScript complet est disponible : `{{ $json.nom.toUpperCase() }}`, `{{ $json.montant * 1.2 }}`, `{{ $json.email.includes('@') ? 'ok' : 'ko' }}`. n8n ajoute des fonctions de confort sur les chaînes, nombres, dates et tableaux (par exemple `{{ $json.texte.extractEmail() }}`, `{{ $json.liste.unique() }}`, `{{ $json.prix.round(2) }}`) : la liste exacte évolue avec les versions, consultez la section *Expressions* de la documentation via l'index `llms.txt` ou l'autocomplétion de l'éditeur (tapez `.` après une valeur).

Exemple professionnel : un cabinet comptable reçoit des notes de frais par formulaire. Le nœud Edit Fields crée trois champs :

```text
reference  → {{ 'NDF-' + $today.toFormat('yyyyMM') + '-' + $itemIndex.toString().padStart(3, '0') }}
ttc        → {{ ($json.ht * (1 + $json.tva / 100)).round(2) }}
alerte     → {{ $json.ht > 500 ? 'Validation manager requise' : 'Auto-validée' }}
```

> 💡 **À retenir** — `$json` = item courant du nœud précédent. `$('Nom').item` = « le même item, vu depuis un autre nœud » (n8n suit la filiation des items, *item linking*). `$('Nom').first()` = une valeur unique, à utiliser pour les paramètres globaux.

> ⚠️ **Piège fréquent** — Renommer un nœud casse toutes les expressions `$('Ancien nom')` qui y font référence. Nommez vos nœuds dès le départ (« Lire clients Sheets », pas « Google Sheets1 ») et ne les renommez plus.

## 4. Les nœuds de logique, un par un

### 4.1 Edit Fields (Set) : transformer, renommer, nettoyer
Le nœud le plus utilisé. Mode *Manual Mapping* : vous ajoutez des champs avec leur type (string, number, boolean, array, object). Option **« Include Other Input Fields »** : conserver ou non les champs d'origine. Mode *JSON* : vous écrivez l'objet complet, expressions comprises. Usage type : préparer le payload exact qu'attend un CRM.

### 4.2 IF et Switch : router
**IF** : une ou plusieurs conditions (ET / OU) avec des opérateurs typés (*is equal to*, *contains*, *is empty*, *is after* pour les dates, *exists*…). Deux sorties : *true* / *false*. **Switch** : plusieurs sorties nommées, par règles (mode *Rules*) ou par expression renvoyant le numéro ou le nom de sortie (mode *Expression*). Règle d'or : IF pour deux chemins, Switch dès trois.

```text
Switch (Rules) sur {{ $json.categorie }}
  → "facturation"  : sortie 0
  → "technique"    : sortie 1
  → "commercial"   : sortie 2
  → Fallback       : sortie "autre"
```

### 4.3 Filter, Split Out, Aggregate, Summarize, Sort, Limit, Remove Duplicates
Ce sont les nœuds « de tri postal ». **Filter** ne garde que les items qui passent la condition (IF sans branche *false*). **Split Out** transforme un item contenant un tableau en N items. **Aggregate** fait l'inverse : N items → 1 item avec un tableau. **Summarize** calcule des agrégats (somme, moyenne, compte, concaténation) groupés par champ, comme un tableau croisé dynamique. **Remove Duplicates** dédoublonne sur un ou plusieurs champs.

### 4.4 Merge : réunir deux branches
Quatre modes à connaître : **Append** (empiler les items des deux entrées), **Combine by Matching Fields** (jointure sur une clé, comme un RECHERCHEV), **Combine by Position** (item 1 avec item 1…), **SQL Query** (jointure écrite en SQL). Et **Choose Branch** pour simplement attendre que les deux branches soient terminées. Le Merge attend ses deux entrées : si l'une n'envoie rien, il ne se déclenche pas (sauf réglage *Always Output Data* en amont).

### 4.5 Loop Over Items et Wait
n8n boucle déjà naturellement item par item. **Loop Over Items** (ex-*Split in Batches*) sert à traiter par **paquets** (par exemple 10 items par appel API pour respecter une limite de débit) ou à exécuter une séquence complète par item avant de passer au suivant. Sa sortie *loop* repart dans le traitement, sa sortie *done* continue quand tout est fini. **Wait** suspend l'exécution : durée fixe, date précise, ou attente d'un appel webhook / d'une validation (reprise dans la leçon 38).

### 4.6 Code : quand les nœuds ne suffisent plus
Deux modes. *Run Once for All Items* : vous recevez `$input.all()` et renvoyez un tableau d'items. *Run Once for Each Item* : vous recevez `$input.item` et renvoyez un item. JavaScript par défaut ; Python disponible selon la configuration de l'instance.

```javascript
// Mode « Run Once for All Items » : regrouper les montants par client
const totaux = {};
for (const item of $input.all()) {
  const { email, montant } = item.json;          // lecture des champs
  totaux[email] = (totaux[email] || 0) + Number(montant);
}
// n8n exige un tableau d'objets { json: … }
return Object.entries(totaux).map(([email, total]) => ({
  json: { email, total: Math.round(total * 100) / 100 }
}));
```

> ⚠️ **Piège fréquent** — Renvoyer `return totaux;` (un objet) ou `return [1, 2, 3]` fait échouer le nœud : la sortie **doit** être `[{ json: {…} }, …]`.

### 4.7 Data Tables : la petite base de données intégrée
Depuis 2025, n8n propose des **Data Tables**, des tables stockées dans l'instance (lignes/colonnes typées, opérations insérer, lire, mettre à jour, supprimer). Elles remplacent avantageusement un Google Sheets « technique » pour mémoriser un état (dernier identifiant traité, liste de clients déjà contactés) sans dépendre d'un service externe.

## 5. 🎮 Défi : lisez avant d'exécuter

Un nœud HTTP Request renvoie :

```json
[{ "json": { "commandes": [ { "id": 1, "total": 30 }, { "id": 2, "total": 70 } ] } }]
```

Question 1 : combien d'items sortent ? Question 2 : quelle expression donne le total de la commande 2 directement dans le nœud suivant ? Question 3 : quel nœud ajouter pour envoyer un e-mail **par commande** ? (Réponses en fin de leçon.)

> 🔗 **Documentation officielle** — [n8n Docs — Build your first workflow](https://docs.n8n.io/build-your-first-workflow.md) 🇬🇧 et le cours [N8N101 Essentials](https://learn.n8n.io/courses/course-v1:n8n+N8N101+2026H2/about) 🇬🇧 (section 2 *Data flow & Transformation* : structure des données, expressions, mapping, merge, binaires).

## 🧪 Exercice pratique

**Consigne.** Une PME d'artisanat reçoit ses commandes dans une feuille Google Sheets (colonnes : `client`, `email`, `produit`, `quantite`, `prix_unitaire`, `date`). Construisez un workflow déclenché manuellement qui : (1) lit la feuille ; (2) calcule `total_ht` et `total_ttc` (TVA 20 %) via Edit Fields ; (3) filtre les commandes du mois en cours ; (4) via Switch, classe en « petite » (< 100 €), « moyenne » (100 à 500 €), « grosse » (> 500 €) ; (5) avec Summarize, produit le chiffre d'affaires par catégorie ; (6) avec Aggregate puis un nœud Code, construit un seul item de synthèse contenant un texte du type « 3 grosses commandes pour 2 140 € ». Si vous n'avez pas de compte Google, remplacez l'étape 1 par un nœud Code qui renvoie 8 items fictifs.

**Critères de réussite.**
- Chaque nœud est nommé explicitement et aucune expression ne contient `Sheets1`.
- Le filtre sur le mois utilise `$today` et non une date écrite en dur.
- Le compteur d'items affiche le bon nombre à chaque étape (vous savez l'expliquer).
- Le nœud Code renvoie exactement un item `{ json: { synthese: "…" } }`.

**Pistes de corrigé.** Filtre du mois : condition *Date & Time → is after* avec `{{ $today.startOf('month') }}`. Switch mode *Rules* avec opérateurs numériques sur `{{ $json.total_ttc }}`. Pour la synthèse, Aggregate (*All Item Data*) puis Code en mode *All Items* : `const d = $input.first().json.data; return [{ json: { synthese: \`${d.length} commandes…\` } }];`.

## ✅ Auto-évaluation express

1. **Que reçoit et que renvoie tout nœud n8n ?**
   → Un tableau d'items, chacun de la forme `{ json: {…}, binary?: {…} }`.
2. **Quelle différence entre `$json.x` et `$('Webhook').item.json.x` ?**
   → Le premier lit l'item courant du nœud précédent ; le second lit l'item lié dans la sortie d'un nœud nommé, même éloigné en amont.
3. **Quand utiliser Switch plutôt que IF ?**
   → Dès qu'il y a trois chemins ou plus, ou un routage sur la valeur d'un champ.

**Réponses du défi.** 1) Un seul item. 2) `{{ $json.commandes[1].total }}` (index 0-based). 3) Un nœud *Split Out* sur le champ `commandes` : vous obtenez deux items, donc deux e-mails.

## 📚 Pour aller plus loin
- [n8n Academy — N8N101 Essentials: Your First Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N101+2026H2/about) 🇬🇧 — le cours de référence (2 à 4 h), premier tiers du parcours n8n Foundations.
- [n8n Academy — N8N102 Integrations: APIs & Connected Workflows](https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about) 🇬🇧 — section 1 : IF, Switch, Loop Over Items, Merge, Split Out, Aggregate, Filter, Summarize, nœud Code.
- [n8n Docs — Learning paths](https://docs.n8n.io/learning-paths) 🇬🇧 — parcours recommandés par profil.
- [n8n Docs — Data Tables](https://docs.n8n.io/build/work-with-data/data-tables.md) 🇬🇧 — la base de données intégrée.
- [n8n Docs — index llms.txt](https://docs.n8n.io/llms.txt) 🇬🇧 — l'index complet de la documentation (pratique pour retrouver la page *Expressions* ou *Built-in methods and variables*).
