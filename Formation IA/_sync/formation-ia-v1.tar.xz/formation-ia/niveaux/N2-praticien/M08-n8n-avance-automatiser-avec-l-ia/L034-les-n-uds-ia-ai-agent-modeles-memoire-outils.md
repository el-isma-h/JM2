---
id: L034
module: M08
level: N2
title: "Les nœuds IA : AI Agent, modèles, mémoire, outils"
minutes: 55
objectives:
  - "Expliquer l'architecture en grappe (cluster nodes) des nœuds IA de n8n : root node et sub-nodes"
  - "Construire un AI Agent avec un modèle de chat (Claude, OpenAI, Ollama), une mémoire et au moins deux outils"
  - "Choisir le modèle Claude adapté (Haiku 5.5 / Sonnet 5.5) selon le coût et la difficulté de la tâche"
  - "Évaluer quand une chaîne (Basic LLM Chain) suffit et quand un agent est justifié"
skills: ["C2.1", "C2.2"]
sources:
  - { title: "n8n Docs — LangChain in n8n", url: "https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md", lang: "en" }
  - { title: "n8n Docs — AI Agent node", url: "https://docs.n8n.io/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.agent.md", lang: "en" }
  - { title: "n8n Docs — What agents do", url: "https://docs.n8n.io/build/integrate-ai/understand-ai-components/what-agents-do.md", lang: "en" }
  - { title: "n8n Docs — MCP servers in n8n", url: "https://docs.n8n.io/build/integrate-ai/mcp-servers.md", lang: "en" }
  - { title: "Anthropic — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Anthropic — Claude Haiku 5.5 overview", url: "https://platform.claude.com/docs/en/models/haiku-5-5/overview", lang: "en" }
---

# Les nœuds IA : AI Agent, modèles, mémoire, outils

> ⏱ 55 min · 🎯 Niveau 2 · 📚 Module 8

## 🎯 Ce que vous saurez faire
- Lire un workflow IA n8n comme une **grappe** : un nœud racine et ses sous-nœuds branchés dessous.
- Assembler un AI Agent complet : Chat Trigger → AI Agent + Anthropic Chat Model + Simple Memory + outils.
- Donner à l'agent des outils sûrs : un sous-workflow n8n, un calculateur, une requête HTTP, un serveur MCP.
- Décider entre Basic LLM Chain, Information Extractor, Text Classifier et AI Agent, et chiffrer le coût d'un appel.

## 1. Une architecture en grappe, pas une suite de nœuds

Jusqu'ici, un workflow n8n était une ligne : les items passent de gauche à droite. Les nœuds IA introduisent une seconde dimension, **verticale**. Un **nœud racine** (*root node*) reçoit les items comme d'habitude, mais il a besoin de « briques » attachées sous lui : les **sous-nœuds** (*sub-nodes*). La documentation appelle cet ensemble un *cluster node*.

```
          ┌──────────────┐          ┌───────────────┐
Chat ────►│   AI Agent   │─────────►│ Slack / Sheets│
Trigger   └──┬───┬───┬───┘          └───────────────┘
             │   │   │
   ┌─────────┘   │   └──────────────┐
   ▼             ▼                  ▼
┌──────────┐ ┌──────────┐   ┌──────────────────────┐
│ Chat     │ │ Memory   │   │ Tools : Calculator,   │
│ Model    │ │ (Simple) │   │ Call n8n Workflow,    │
│ Anthropic│ │          │   │ HTTP Request, MCP…    │
└──────────┘ └──────────┘   └──────────────────────┘
```

Les nœuds racines (nov. 2026, doc *LangChain in n8n*) : les **chaînes** (Basic LLM Chain, Question and Answer Chain, Summarization Chain), l'**AI Agent**, les **Vector Stores** (leçon 35), plus des nœuds spécialisés très pratiques : **Information Extractor** (extraire des champs structurés d'un texte), **Text Classifier** (classer dans des catégories que vous définissez), **Sentiment Analysis**. Les sous-nœuds se rangent en familles : *chat models* (Anthropic, OpenAI, Google Gemini, Mistral, Ollama, OpenRouter…), *memory* (Simple, Postgres, Redis…), *tools*, *embeddings*, *retrievers*, *document loaders*, *text splitters*, *output parsers*.

Analogie : le nœud racine est un chef de cuisine ; les sous-nœuds sont ses équipements. Le chef (AI Agent) décide quoi faire ; le four (modèle) produit ; le carnet (mémoire) rappelle la commande précédente ; les ustensiles (outils) agissent sur le monde. Sans four, pas de cuisine : **le sous-nœud Chat Model est toujours obligatoire**.

> 💡 **À retenir** — La **mémoire** ne se connecte qu'à l'AI Agent (et à certaines chaînes), pas aux nœuds d'extraction ou de classification, qui sont sans état par conception.

## 2. Chaîne ou agent ? La question à se poser d'abord

Le cours N8N103 (section 1) insiste sur cette distinction, et c'est la plus rentable de la leçon.

| | Chaîne (Basic LLM Chain, Extractor, Classifier) | AI Agent |
|---|---|---|
| Nombre d'appels au modèle | **1** par item, prévisible | 1 à N (l'agent boucle tant qu'il décide d'appeler des outils) |
| Coût | Connu à l'avance | Variable, à plafonner (*Max Iterations*) |
| Outils | Non | Oui |
| Mémoire de conversation | Non (sauf Chain avec mémoire) | Oui |
| Cas d'usage | Résumer, classer, extraire, reformuler, traduire | Répondre à une question en allant chercher l'info, exécuter une action décidée à la volée |

Règle du praticien : **si vous pouvez décrire la tâche comme « transformer ce texte en ce texte », c'est une chaîne.** Un agent n'est justifié que si la **séquence d'actions** dépend du contenu. Classer un e-mail de support en « facturation / technique / commercial » est une chaîne (Text Classifier). Répondre au client en consultant sa commande, puis la base documentaire, puis en créant un ticket si besoin : c'est un agent.

> ⚠️ **Piège fréquent** — Mettre un AI Agent partout « parce que c'est plus puissant ». Vous payez trois à dix fois plus d'appels, vous perdez la prévisibilité et vous rendez les tests impossibles. Commencez toujours par la chaîne.

## 3. Choisir le modèle : Claude dans n8n

Le sous-nœud **Anthropic Chat Model** demande une credential (clé API lue depuis votre compte Claude Platform ; stockée chiffrée, leçon 33) et un modèle. Au 1er novembre 2026, les deux choix raisonnables pour l'automatisation sont (tarifs page Pricing d'Anthropic, USD par million de tokens, entrée / sortie) :

| Modèle | ID API | Entrée / sortie | Contexte | Usage conseillé en n8n |
|---|---|---|---|---|
| **Claude Haiku 5.5** | `claude-haiku-5-5` | 0,10 / 0,50 (jusqu'à 100 k tokens de contexte) | 1 M | Classification, extraction, tri, réponses courtes : **le modèle par défaut des workflows** |
| **Claude Sonnet 5.5** | `claude-sonnet-5-5` | 2 / 10 | 1 M | Rédaction soignée, raisonnement multi-étapes, agent avec plusieurs outils |
| Claude Opus 5.5 | `claude-opus-5-5` | 4 / 20 | 1 M | Cas difficiles, rarement nécessaire dans un workflow |

Ordre de grandeur : classer 1 000 e-mails de 400 tokens chacun avec Haiku 5.5 coûte environ 1 000 × 400 × 0,10 / 1 000 000 ≈ **0,04 $** en entrée, plus quelques centimes de sortie. Le même travail avec Sonnet 5.5 coûte vingt fois plus, pour un gain de qualité nul sur une tâche de classification. Si votre instance n8n est auto-hébergée et que la confidentialité l'impose, le sous-nœud **Ollama Chat Model** fait tourner un modèle ouvert local (module 10) : zéro envoi de données, au prix d'une qualité et d'une vitesse moindres.

Deux réglages importants du sous-nœud : la **température** (0 à 0,3 pour les tâches de classification et d'extraction ; attention, certains modèles Claude récents refusent ce paramètre lorsque le raisonnement est actif, laissez-le vide en cas d'erreur 400) et le **nombre maximal de tokens de sortie** (plafonnez-le : une réponse de support n'a pas besoin de 4 000 tokens).

> 🔗 **Documentation officielle** — [Anthropic — Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 et [Claude Haiku 5.5 overview](https://platform.claude.com/docs/en/models/haiku-5-5/overview) 🇬🇧.

## 4. Anatomie de l'AI Agent

Le nœud AI Agent a trois champs essentiels :

1. **Prompt (user message)** : par défaut `{{ $json.chatInput }}` quand il suit un Chat Trigger ; sinon, une expression vers votre texte (`{{ $json.body.message }}` après un Webhook).
2. **System Message** (dans *Options*) : le rôle, les règles, le format de sortie. C'est votre prompt structuré du module 4, appliqué à un agent.
3. **Max Iterations** : le nombre maximal de tours « réflexion → outil → réflexion ». Mettez 5 à 10 : un agent qui boucle trente fois a un problème, pas une mission.

Exemple de System Message pour un assistant de support d'une PME de domotique :

```text
Vous êtes l'assistant support de Maison Connectée SAS. Vous répondez en français, vouvoiement, ton chaleureux et précis.
Règles :
1. Pour toute question sur une commande, utilisez l'outil « Rechercher commande » avant de répondre. N'inventez jamais un numéro de suivi.
2. Pour les questions techniques, utilisez l'outil « Base de connaissances » et citez le titre de la fiche utilisée.
3. Si la demande concerne un remboursement ou une réclamation, ne répondez pas : renvoyez exactement le mot ESCALADE et résumez la demande en une phrase.
4. Ne dépassez pas 120 mots. Terminez par une question si une information manque.
```

Le **Structured Output Parser** (sous-nœud *output parser*, option *Require Specific Output Format*) force l'agent à renvoyer un JSON conforme à un exemple ou un schéma : indispensable quand le nœud suivant est un IF ou un Switch qui attend `{ "action": "repondre" | "escalader", "reponse": "…" }`.

## 5. La mémoire : se souvenir du tour précédent

Sans mémoire, chaque message est une nouvelle conversation : « Et pour la commande dont je vous parlais ? » n'a aucun sens pour l'agent. Le sous-nœud **Simple Memory** (ex-*Window Buffer Memory*) conserve les N derniers échanges (*Context Window Length*, par défaut 5) en mémoire de l'instance, indexés par une **clé de session** : `{{ $json.sessionId }}` fourni par le Chat Trigger, ou, après un Webhook, l'identifiant de votre choix (adresse e-mail du client, identifiant de conversation Slack). Pour la production, préférez **Postgres Chat Memory** ou **Redis Chat Memory** : la mémoire survit aux redémarrages et peut être partagée entre plusieurs workers.

> ⚠️ **Piège fréquent** — Utiliser une clé de session fixe (« support ») : tous les clients partagent alors la même conversation et l'agent mélange les demandes. La clé doit identifier **une** conversation.

## 6. Les outils : ce que l'agent a le droit de faire

Un outil est un sous-nœud décrit par un **nom** et une **description** : c'est la description que lit le modèle pour décider de l'appeler. Les outils à connaître :

| Outil | Ce qu'il fait | Conseil |
|---|---|---|
| **Call n8n Workflow Tool** | Appelle un sous-workflow (leçon 33) avec des paramètres | L'outil universel : tout ce que n8n sait faire devient un outil |
| **Code Tool** | Exécute un petit JavaScript | Calculs, formatage |
| **HTTP Request Tool** | Appelle une API | Lecture d'un statut de commande, météo, etc. |
| **Calculator** | Arithmétique fiable | Évite les erreurs de calcul du modèle |
| **Vector Store Tool** | Interroge une base vectorielle (leçon 35) | Le cœur du RAG |
| **Wikipedia, SerpAPI…** | Recherche | Avec parcimonie (coût, fiabilité) |
| **MCP Client Tool** | Se connecte à un serveur MCP (Model Context Protocol) | Accès à des dizaines d'outils standardisés |

Quand un outil a des paramètres, vous laissez le modèle les remplir avec la fonction `$fromAI` :

```text
{{ $fromAI('numero_commande', 'Le numéro de commande au format CMD-XXXXX', 'string') }}
```

n8n génère alors le schéma d'appel d'outil pour le modèle : le modèle extrait le numéro de commande du message du client et le passe au sous-workflow.

**MCP en un clic.** Depuis le panneau d'outils de l'AI Agent, n8n propose un **registre de serveurs MCP** : vous choisissez un serveur (par exemple un connecteur Slack, GitHub ou base de données), vous indiquez les outils à inclure (*tous*, *liste*, *tous sauf*) et l'agent les voit immédiatement. Le **MCP Client Tool** manuel permet d'ajouter un serveur MCP non listé via son URL ; à l'inverse, le **MCP Server Trigger** expose vos propres workflows n8n comme outils MCP consommables par Claude Desktop, Claude Code ou un autre agent. Le MCP est un standard ouvert (spécification stable 2025-11-25, puis 2026-07-28), aujourd'hui porté par une fondation Linux : apprendre une fois, brancher partout.

> 💡 **À retenir** — Un outil = une capacité **et** un risque. Donnez à l'agent le minimum d'outils nécessaires (principe du moindre privilège) et, pour tout outil qui **écrit** (envoi d'e-mail, remboursement), exigez une validation humaine (leçon 38, nœud *Send and Wait*).

## 7. 🎮 Défi : chaîne ou agent ?

Pour chaque besoin, dites « chaîne » ou « agent » et nommez le nœud : (a) traduire en anglais chaque avis client ; (b) extraire montant, date et fournisseur d'une facture en texte ; (c) répondre au salarié qui demande « combien de jours de congé me reste-t-il et puis-je poser du 12 au 16 ? » ; (d) classer les candidatures en trois piles. Réponses en fin de leçon.

## 🧪 Exercice pratique

**Consigne.** Construisez l'assistant « Maison Connectée » : (1) Chat Trigger ; (2) AI Agent avec le System Message de la section 4 ; (3) Anthropic Chat Model sur `claude-haiku-5-5` (ou Ollama en local) ; (4) Simple Memory avec `{{ $json.sessionId }}` et 8 tours ; (5) outil Calculator ; (6) outil Call n8n Workflow « Rechercher commande » : un sous-workflow qui reçoit `numero_commande` via `$fromAI` et renvoie, depuis une Data Table ou un nœud Code, le statut d'une commande parmi cinq commandes fictives ; (7) Structured Output Parser imposant `{ "action": "repondre" | "escalader", "reponse": "…" }`. Testez dans le chat intégré : « Où en est ma commande CMD-10042 ? », « Je veux être remboursé », puis « et la CMD-10043 ? ».

**Critères de réussite.**
- L'agent appelle l'outil pour la première question (visible dans le journal d'exécution) et ne répond jamais avec un statut inventé pour un numéro inconnu.
- La demande de remboursement renvoie `action: "escalader"`.
- La troisième question fonctionne grâce à la mémoire (l'agent comprend « et la… »).
- Vous savez estimer le coût de 500 conversations de 6 tours avec Haiku 5.5.

**Pistes de corrigé.** Description de l'outil : « Renvoie le statut et la date de livraison d'une commande à partir de son numéro. À utiliser avant toute réponse sur une commande ». Coût : 500 × 6 × ~1 200 tokens (contexte croissant) ≈ 3,6 M tokens d'entrée × 0,10 $ ≈ 0,36 $, plus la sortie ≈ 0,1 $ : moins d'un demi-dollar.

## ✅ Auto-évaluation express

1. **Quel sous-nœud est obligatoire pour tout nœud racine IA ?**
   → Le Chat Model (modèle de langage).
2. **À quoi sert `$fromAI` ?**
   → À laisser le modèle remplir un paramètre d'outil (nom, description, type) à partir de la conversation.
3. **Pourquoi plafonner *Max Iterations* ?**
   → Pour borner le coût et la durée d'un agent qui pourrait boucler entre réflexion et outils.

**Réponses du défi.** (a) chaîne, Basic LLM Chain ; (b) chaîne, Information Extractor ; (c) agent, avec outils « solde congés » et « vérifier calendrier » ; (d) chaîne, Text Classifier.

## 📚 Pour aller plus loin
- [n8n Docs — LangChain in n8n](https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md) 🇬🇧 — la liste des nœuds racines et sous-nœuds.
- [n8n Docs — AI Agent node](https://docs.n8n.io/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.agent.md) 🇬🇧 — paramètres, outils, parser.
- [n8n Docs — What agents do](https://docs.n8n.io/build/integrate-ai/understand-ai-components/what-agents-do.md) 🇬🇧 — la boucle d'un agent expliquée.
- [n8n Docs — MCP servers in n8n](https://docs.n8n.io/build/integrate-ai/mcp-servers.md) 🇬🇧 — registre MCP et MCP Client Tool.
- [n8n Docs — Chat Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.chattrigger.md) 🇬🇧 — chat intégré et chat public hébergé.
- [n8n Docs — Agents (préversion) : Agent Builder](https://docs.n8n.io/build/build-and-manage-agents.md) 🇬🇧 — la nouvelle façon de créer des agents « hors canvas » (modèle, instructions, outils, mémoire, canaux Slack/Teams/Telegram).
