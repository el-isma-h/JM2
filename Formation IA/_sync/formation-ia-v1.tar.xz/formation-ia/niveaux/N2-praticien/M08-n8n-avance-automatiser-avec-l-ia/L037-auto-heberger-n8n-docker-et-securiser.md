---
id: L037
module: M08
level: N2
title: "Auto-héberger n8n (Docker) et sécuriser"
minutes: 50
objectives:
  - "Comparer n8n Cloud et l'auto-hébergement (coût, confidentialité, maintenance, obligations RGPD)"
  - "Déployer n8n avec Docker Compose, PostgreSQL et les variables d'environnement indispensables"
  - "Sécuriser l'instance : HTTPS via reverse proxy, clé de chiffrement, comptes, secrets, mises à jour"
  - "Mettre en place sauvegardes, restauration et purge des exécutions"
skills: ["C2.1", "C2.6"]
sources:
  - { title: "n8n Docs — Host n8n (hub)", url: "https://docs.n8n.io/deploy/host-n8n.md", lang: "en" }
  - { title: "n8n Docs — Install options", url: "https://docs.n8n.io/deploy/host-n8n/install-options.md", lang: "en" }
  - { title: "n8n Docs — Install with Docker", url: "https://docs.n8n.io/deploy/host-n8n/install-options/install-with-docker.md", lang: "en" }
  - { title: "n8n Docs — Install using Docker Compose", url: "https://docs.n8n.io/deploy/host-n8n/install-options/install-using-docker-compose.md", lang: "en" }
  - { title: "n8n Docs — Scaling / queue mode", url: "https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling.md", lang: "en" }
  - { title: "Docker — Compose documentation", url: "https://docs.docker.com/compose/", lang: "en" }
---

# Auto-héberger n8n (Docker) et sécuriser

> ⏱ 50 min · 🎯 Niveau 2 · 📚 Module 8

## 🎯 Ce que vous saurez faire
- Décider, chiffres à l'appui, entre n8n Cloud et une instance auto-hébergée.
- Lancer une instance n8n complète (n8n + PostgreSQL + reverse proxy HTTPS) avec un fichier `docker-compose.yml` que vous comprenez ligne par ligne.
- Nommer les variables d'environnement qui comptent, et savoir laquelle ne doit **jamais** être perdue.
- Sauvegarder, restaurer, mettre à jour, et expliquer ces choix à un responsable informatique ou à un DPO.

## 1. Cloud ou auto-hébergement ?

n8n est un logiciel **à code source disponible** (licence *Sustainable Use License* : usage interne libre, revente de n8n lui-même interdite) que vous pouvez faire tourner où vous voulez. Deux options :

| Critère | n8n Cloud | Auto-hébergé (Docker) |
|---|---|---|
| Mise en route | 5 minutes, essai gratuit | 1 à 2 heures la première fois |
| Coût | Abonnement mensuel par nombre d'exécutions (grille sur n8n.io, nov. 2026) | Serveur (VPS 2 vCPU / 4 Go dès quelques euros par mois chez un hébergeur européen) + votre temps |
| Données | Hébergées par n8n (régions proposées, à vérifier dans l'offre) | Chez vous ou chez l'hébergeur de votre choix : **vous êtes responsable de traitement et hébergeur** |
| Mises à jour, sauvegardes, HTTPS | Inclus | À votre charge |
| Modèles locaux (Ollama), base Qdrant, accès au réseau interne | Impossible ou compliqué | Natif : tout tourne sur la même machine |
| Pour qui | Débuter, petites équipes sans compétence serveur | Confidentialité (RH, santé, juridique), volumes élevés, IA locale, contrôle |

Règle du praticien : commencez sur n8n Cloud ou sur votre poste (Docker Desktop) pour apprendre ; passez à l'auto-hébergement dès que vous traitez des données personnelles sensibles ou que le volume rend l'abonnement plus cher qu'un VPS. Les workflows s'exportent en JSON et se réimportent à l'identique ; seules les credentials sont à recréer.

## 2. Docker en trois phrases

Docker emballe une application avec tout ce dont elle a besoin dans une **image** ; vous lancez un **conteneur** à partir de l'image ; un **volume** conserve les données quand le conteneur est recréé. **Docker Compose** décrit plusieurs conteneurs (n8n, sa base, le proxy) dans un seul fichier YAML et les démarre ensemble. La page « Install with Docker » de la documentation n8n est désormais marquée obsolète au profit de « Install using Docker Compose » : c'est donc Compose que nous utilisons.

## 3. Le fichier `docker-compose.yml` commenté

Prérequis : un serveur Linux avec Docker et le plugin Compose installés (documentation Docker), un nom de domaine pointant vers le serveur (`n8n.votre-domaine.fr`), les ports 80 et 443 ouverts.

```yaml
# docker-compose.yml — n8n + PostgreSQL + Caddy (HTTPS automatique)
services:
  postgres:
    image: postgres:16
    restart: unless-stopped
    environment:
      POSTGRES_USER: n8n
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}      # lu depuis le fichier .env
      POSTGRES_DB: n8n
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U n8n -d n8n"]
      interval: 10s
      retries: 5

  n8n:
    image: docker.n8n.io/n8nio/n8n          # image officielle ; épinglez une version en production (ex. :2.x)
    restart: unless-stopped
    depends_on:
      postgres:
        condition: service_healthy
    environment:
      # --- Base de données (PostgreSQL au lieu du SQLite par défaut) ---
      DB_TYPE: postgresdb
      DB_POSTGRESDB_HOST: postgres
      DB_POSTGRESDB_PORT: 5432
      DB_POSTGRESDB_DATABASE: n8n
      DB_POSTGRESDB_USER: n8n
      DB_POSTGRESDB_PASSWORD: ${POSTGRES_PASSWORD}
      # --- Identité publique de l'instance (webhooks, liens dans les e-mails d'erreur) ---
      N8N_HOST: n8n.votre-domaine.fr
      N8N_PROTOCOL: https
      N8N_PORT: 5678
      WEBHOOK_URL: https://n8n.votre-domaine.fr/
      N8N_EDITOR_BASE_URL: https://n8n.votre-domaine.fr/
      # --- Fuseau horaire (Schedule Trigger, $now) ---
      GENERIC_TIMEZONE: Europe/Paris
      TZ: Europe/Paris
      # --- LA variable à ne jamais perdre : chiffre toutes les credentials ---
      N8N_ENCRYPTION_KEY: ${N8N_ENCRYPTION_KEY}
      # --- Hygiène : purge des exécutions anciennes ---
      EXECUTIONS_DATA_PRUNE: "true"
      EXECUTIONS_DATA_MAX_AGE: 336              # heures (14 jours)
      EXECUTIONS_DATA_SAVE_ON_SUCCESS: none     # "all" pendant le rodage, "none" ensuite
    volumes:
      - n8n_data:/home/node/.n8n                # données locales de n8n
      - ./fichiers:/files                       # dossier partagé pour les nœuds de fichiers (optionnel)
    # Pas de "ports:" : n8n n'est joignable que via Caddy

  caddy:
    image: caddy:2
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile
      - caddy_data:/data

volumes:
  postgres_data:
  n8n_data:
  caddy_data:
```

Le fichier `Caddyfile`, deux lignes, obtient et renouvelle seul un certificat Let's Encrypt :

```text
n8n.votre-domaine.fr {
    reverse_proxy n8n:5678
}
```

Et le fichier `.env` (jamais commité, jamais partagé) :

```bash
# .env — secrets de l'instance (chmod 600)
POSTGRES_PASSWORD=un-mot-de-passe-long-et-aleatoire
N8N_ENCRYPTION_KEY=une-chaine-aleatoire-de-32-caracteres-ou-plus   # ex. : openssl rand -hex 32
```

Démarrage, journaux, arrêt :

```bash
docker compose up -d          # démarre les trois services en arrière-plan
docker compose logs -f n8n    # suit les journaux de n8n
docker compose down           # arrête (les volumes sont conservés)
```

Ouvrez `https://n8n.votre-domaine.fr`, créez le compte **propriétaire** (owner) : c'est le compte d'administration ; donnez-lui un mot de passe fort et activez l'authentification à deux facteurs dans les réglages.

> 💡 **À retenir** — `N8N_ENCRYPTION_KEY` chiffre toutes les credentials en base. Si vous la perdez (ou la changez), **toutes les credentials deviennent illisibles** et sont à ressaisir. Sauvegardez-la dans votre gestionnaire de mots de passe, séparément des sauvegardes.

> ⚠️ **Piège fréquent** — Exposer le port 5678 directement (`ports: "5678:5678"`) sur un serveur public, « pour tester ». Sans HTTPS, les mots de passe et les données des webhooks circulent en clair ; sans proxy, l'interface est accessible au monde entier. Testez en local (`http://localhost:5678` sur votre poste), jamais en clair sur Internet.

## 4. Les variables d'environnement qui comptent

| Variable | Rôle | Valeur type |
|---|---|---|
| `N8N_ENCRYPTION_KEY` | Chiffrement des credentials | Aléatoire, 32+ caractères |
| `DB_TYPE` + `DB_POSTGRESDB_*` | Base PostgreSQL (SQLite par défaut : suffisant pour tester, pas pour produire) | `postgresdb` |
| `WEBHOOK_URL`, `N8N_EDITOR_BASE_URL`, `N8N_HOST`, `N8N_PROTOCOL` | URLs publiques (webhooks de production, OAuth redirect, liens dans les notifications d'erreur) | `https://n8n.votre-domaine.fr/` |
| `GENERIC_TIMEZONE`, `TZ` | Heure des Schedule Triggers et de `$now` | `Europe/Paris` |
| `EXECUTIONS_DATA_PRUNE`, `EXECUTIONS_DATA_MAX_AGE` | Purge automatique des exécutions | `true`, `336` |
| `N8N_SECURE_COOKIE` | Cookie de session en HTTPS uniquement (défaut `true` : laissez-le, c'est ce qui bloque l'accès en HTTP clair) | `true` |
| `EXECUTIONS_MODE=queue` + Redis | Mode file d'attente : plusieurs *workers* pour monter en charge (page *Scaling*) | Au-delà de quelques milliers d'exécutions/jour |
| `N8N_RUNNERS_ENABLED` | Exécuteurs isolés pour le nœud Code | Obsolète depuis n8n 2.0 : activés par défaut (nov. 2026) |

Les variables sont lisibles dans les expressions via `{{ $env.NOM }}` ; par défaut, n8n peut restreindre cet accès (`N8N_BLOCK_ENV_ACCESS_IN_NODE`) : ne stockez dans l'environnement que des paramètres (URLs, noms), jamais de secrets destinés aux workflows : ceux-ci vont dans les **credentials**.

## 5. Sécuriser au-delà du HTTPS

1. **Comptes et rôles** : un compte par personne, rôle *Member* par défaut, *Admin* pour deux personnes maximum, 2FA pour tous. Utilisez les **projets** pour cloisonner credentials et workflows par équipe.
2. **Webhooks authentifiés** (leçon 36) et, si possible, filtrage d'IP au niveau du proxy pour les webhooks internes.
3. **Nœuds communautaires** : ce sont des paquets npm tiers exécutés avec les droits de n8n ; n'installez que des paquets au code source vérifié, ou désactivez-les (`N8N_COMMUNITY_PACKAGES_ENABLED=false`).
4. **Mises à jour** : épinglez une version (`n8nio/n8n:2.x.y`), lisez les notes de version, mettez à jour mensuellement : `docker compose pull && docker compose up -d`. Testez d'abord sur une instance de pré-production si vos workflows sont critiques.
5. **Pare-feu** : seuls 80, 443 et votre port SSH ouverts ; Postgres, Qdrant, Ollama restent sur le réseau Docker interne.
6. **Journalisation** : conservez les exécutions en échec (`EXECUTIONS_DATA_SAVE_ON_ERROR=all`) pour l'analyse, purgez les succès.
7. **Secrets** : fichier `.env` en `chmod 600` ; pour les grandes organisations, n8n propose des *external secrets* (coffres-forts comme HashiCorp Vault, AWS Secrets Manager) sur les offres entreprise.

Côté RGPD, auto-héberger n8n fait de vous l'hébergeur des données qui transitent : inscrivez l'instance au registre des traitements, limitez la conservation des exécutions (c'est tout l'intérêt de `EXECUTIONS_DATA_MAX_AGE`), et vérifiez les clauses des fournisseurs d'IA appelés par vos workflows (module 7 et module 15). Les données envoyées au modèle de chat (Anthropic, OpenAI, Mistral) quittent votre serveur ; les modèles Ollama, non.

> 🔗 **Documentation officielle** — [n8n Docs — Install using Docker Compose](https://docs.n8n.io/deploy/host-n8n/install-options/install-using-docker-compose.md) 🇬🇧 et [n8n Docs — Host n8n](https://docs.n8n.io/deploy/host-n8n.md) 🇬🇧.

## 6. Sauvegarder et restaurer

Trois choses à sauvegarder : la **base PostgreSQL** (workflows, credentials chiffrées, exécutions), le **volume `n8n_data`** (réglages locaux), et la **clé `N8N_ENCRYPTION_KEY`**. Script quotidien, à planifier avec `cron` :

```bash
#!/usr/bin/env bash
# sauvegarde-n8n.sh — dump PostgreSQL + export des workflows, conservés 30 jours
set -euo pipefail
DATE=$(date +%F)
DEST=/var/backups/n8n
mkdir -p "$DEST"
# 1. Base de données complète (workflows + credentials chiffrées)
docker compose exec -T postgres pg_dump -U n8n n8n | gzip > "$DEST/n8n-db-$DATE.sql.gz"
# 2. Workflows en JSON lisible (pratique pour relire, versionner dans Git)
docker compose exec -T n8n n8n export:workflow --all --output=/tmp/workflows.json
docker compose cp n8n:/tmp/workflows.json "$DEST/workflows-$DATE.json"
# 3. Rotation : suppression des sauvegardes de plus de 30 jours
find "$DEST" -type f -mtime +30 -delete
echo "Sauvegarde terminée : $DEST ($DATE)"
```

Copiez ensuite `$DEST` hors du serveur (stockage objet, autre machine). **Testez la restauration** une fois par trimestre : nouveau serveur, même `.env`, `docker compose up -d`, puis `gunzip -c n8n-db-DATE.sql.gz | docker compose exec -T postgres psql -U n8n n8n`. Une sauvegarde jamais restaurée n'est qu'une hypothèse.

## 🎮 Défi : l'incident du lundi

Après une mise à jour, un collègue a « nettoyé » le fichier `.env` et régénéré `N8N_ENCRYPTION_KEY` « pour plus de sécurité ». Tous les workflows affichent des erreurs d'authentification. Que faire ? Réponse en fin de leçon.

## 🧪 Exercice pratique

**Consigne.** Sur votre poste (Docker Desktop) ou sur un VPS d'essai : (1) créez `docker-compose.yml`, `.env` et, si vous avez un domaine, `Caddyfile` ; sur un poste local, supprimez le service Caddy et exposez `127.0.0.1:5678:5678` ; (2) démarrez, créez le compte propriétaire avec 2FA ; (3) importez le workflow d'erreur de la leçon 33 et vérifiez que `{{ $json.execution.url }}` produit une URL correcte (grâce à `N8N_EDITOR_BASE_URL`) ; (4) ajoutez le service Qdrant de la leçon 35 ; (5) exécutez le script de sauvegarde, détruisez le conteneur n8n (`docker compose rm -sf n8n`), relancez et vérifiez que tout est intact ; (6) rédigez une fiche d'une page pour votre responsable informatique : architecture, ports ouverts, variables sensibles, procédure de sauvegarde et de restauration.

**Critères de réussite.**
- L'instance démarre avec PostgreSQL (vérifiable dans les journaux : aucune mention de SQLite).
- Aucun port autre que 80/443 (ou 127.0.0.1:5678 en local) n'est exposé : `docker compose ps` le confirme.
- Après destruction et relance du conteneur, workflows et credentials sont toujours là.
- La fiche mentionne la clé de chiffrement, l'emplacement des sauvegardes hors serveur et la fréquence des mises à jour.

**Pistes de corrigé.** Si Caddy n'obtient pas de certificat, vérifiez que le DNS pointe bien vers le serveur et que le port 80 est ouvert (Let's Encrypt l'utilise pour la validation). Si n8n refuse la connexion en HTTP local avec un message sur le cookie sécurisé, utilisez bien `localhost` ; ne désactivez `N8N_SECURE_COOKIE` qu'en local, jamais sur un serveur public.

## ✅ Auto-évaluation express

1. **Quelle variable chiffre les credentials et ne doit jamais être perdue ?**
   → `N8N_ENCRYPTION_KEY`.
2. **Pourquoi ne pas exposer le port 5678 directement sur Internet ?**
   → Pas de HTTPS (données et mots de passe en clair) et interface accessible à tous ; on passe par un reverse proxy (Caddy, Traefik, Nginx) avec certificat.
3. **Que faut-il sauvegarder ?**
   → La base PostgreSQL, le volume `n8n_data` et la clé de chiffrement, avec un test de restauration régulier.

**Réponse du défi.** Restaurer l'ancienne `N8N_ENCRYPTION_KEY` depuis le gestionnaire de mots de passe (ou la sauvegarde du `.env`) et redémarrer : les credentials redeviennent lisibles. Si l'ancienne clé est définitivement perdue, il faut ressaisir toutes les credentials, d'où l'importance de la règle de la section 3.

## 📚 Pour aller plus loin
- [n8n Docs — Install options](https://docs.n8n.io/deploy/host-n8n/install-options.md) 🇬🇧 — Docker, Compose, npm, Kubernetes, hébergeurs.
- [n8n Docs — Install with Docker](https://docs.n8n.io/deploy/host-n8n/install-options/install-with-docker.md) 🇬🇧 — page historique (volume `n8n_data`, port 5678, `GENERIC_TIMEZONE`, `N8N_ENCRYPTION_KEY`), désormais orientée vers Compose.
- [n8n Docs — Scaling and queue mode](https://docs.n8n.io/deploy/host-n8n/configure-n8n/scaling.md) 🇬🇧 — workers et Redis quand le volume monte.
- [Docker — Compose](https://docs.docker.com/compose/) 🇬🇧 — la référence du format `docker-compose.yml`.
