---
id: L033
module: M08
level: N2
title: "n8n Level 2 : traitement d'erreurs, sous-workflows, bonnes pratiques"
minutes: 55
objectives:
  - "Construire un workflow d'erreur (Error Trigger) qui notifie et journalise chaque échec avec son contexte"
  - "Appliquer les réglages de nœud Retry On Fail, On Error et Always Output Data au bon endroit"
  - "Découper un workflow en sous-workflows réutilisables et gérer les credentials (OAuth2, clé API, Bearer) proprement"
  - "Expliquer les bonnes pratiques de nommage, documentation, tests et publication du cours N8N103"
skills: ["C2.1"]
sources:
  - { title: "n8n Academy — N8N102 Integrations: APIs & Connected Workflows", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about", lang: "en" }
  - { title: "n8n Academy — N8N103 In Practice: AI, Testing & Best Practices", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about", lang: "en" }
  - { title: "n8n Docs — Use templates", url: "https://docs.n8n.io/build/ways-of-building-workflows/use-templates.md", lang: "en" }
  - { title: "n8n Docs — Evaluation node", url: "https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluation.md", lang: "en" }
---

# n8n Level 2 : traitement d'erreurs, sous-workflows, bonnes pratiques

> ⏱ 55 min · 🎯 Niveau 2 · 📚 Module 8

## 🎯 Ce que vous saurez faire
- Faire la différence entre une erreur « normale » (API indisponible deux secondes) et une erreur « bloquante », et traiter chacune au bon niveau.
- Brancher un **workflow d'erreur** global qui vous prévient sur Slack avec le nom du workflow, le nœud fautif et le lien vers l'exécution.
- Découper une automatisation en **sous-workflows** appelés comme des fonctions, avec des entrées et des sorties définies.
- Créer, tester et partager des **credentials** sans jamais coller une clé API dans un nœud.
- Appliquer la check-list de mise en production du cours N8N103.

## 1. Un workflow qui ne gère pas ses erreurs n'est pas fini

Anecdote vraie, mille fois répétée dans les forums n8n : une agence immobilière automatise l'envoi des relances de loyer. Tout fonctionne six semaines. Un lundi, l'API du logiciel de gestion répond une erreur 502 pendant dix minutes. Le workflow s'arrête au milieu de sa liste ; personne n'est averti ; vingt-trois locataires ne reçoivent pas leur relance, et personne ne s'en rend compte avant la fin du mois. Le workflow était « terminé » selon son auteur. Il ne l'était pas.

La compétence C2.1 de notre référentiel exige explicitement que « les cas d'erreur sont gérés ». Le cours N8N102 y consacre deux nœuds (*Error Trigger*, *Stop and Error*) et N8N103 une section complète (*Testing & debugging* : journal d'exécution, debugger, Try/Catch). Voici le système complet, en trois étages.

```
Étage 1 — le nœud        : Retry On Fail, On Error, Always Output Data
Étage 2 — le workflow    : branche d'erreur (sortie « error »), Stop and Error
Étage 3 — l'instance     : Error Workflow global (Error Trigger → Slack / e-mail / journal)
```

## 2. Étage 1 : les réglages de chaque nœud

Ouvrez n'importe quel nœud, onglet **Settings**. Quatre réglages changent tout :

| Réglage | Effet | Quand l'utiliser |
|---|---|---|
| **Retry On Fail** (*Max Tries*, *Wait Between Tries*) | Réessaie automatiquement après un échec | Appels HTTP, API externes, envois d'e-mail : les erreurs réseau transitoires (429, 502, 503, timeout) |
| **On Error → Stop Workflow** (défaut) | L'exécution s'arrête, marquée en erreur | Quand continuer n'aurait aucun sens (impossible de lire le fichier source) |
| **On Error → Continue** | L'item fautif passe au nœud suivant **sans** le résultat attendu | Rarement : risque de propager des données vides |
| **On Error → Continue (using error output)** | Le nœud gagne une seconde sortie *error* où vont les items en échec | Le mode professionnel : vous traitez les échecs dans une branche dédiée |
| **Always Output Data** | Le nœud émet un item vide même s'il n'a rien trouvé | Pour que le Merge ou l'IF suivant se déclenche quand même |

Exemple : une relance par e-mail. Retry 3 fois, 5 secondes d'attente, puis *Continue (using error output)* ; la sortie *error* alimente un nœud Google Sheets « Relances échouées » avec `{{ $json.error.message }}`, puis le workflow continue avec les autres locataires. Vingt-trois relances perdues deviennent zéro relance perdue et une ligne dans un tableau.

> ⚠️ **Piège fréquent** — Activer *Retry On Fail* sur un nœud **qui crée quelque chose** (création de facture, paiement) sans vérifier que l'API est idempotente. Si l'API a créé l'objet mais a renvoyé une erreur réseau, le retry crée un doublon. Dans ce cas, préférez une vérification « existe déjà ? » avant la création.

## 3. Étage 2 : la logique d'erreur dans le workflow

Le nœud **Stop and Error** lève volontairement une erreur avec votre message : « Montant négatif reçu pour la facture {{ $json.id }} ». Il arrête l'exécution et déclenche l'étage 3. Utilisez-le comme une assertion : dès qu'une donnée viole une règle métier, échouez **vite et clairement** plutôt que d'envoyer un e-mail absurde au client.

Le motif « Try/Catch » de N8N103 se construit avec *Continue (using error output)* : la sortie normale est le *try*, la sortie *error* est le *catch*. Le **Debugger** (bouton *Debug in editor* sur une exécution ayant échoué) recharge les données exactes de l'exécution dans l'éditeur : vous rejouez le nœud fautif avec les vraies données, sans relancer tout le flux. C'est l'outil n° 1 pour comprendre un échec survenu à 3 h du matin.

## 4. Étage 3 : le workflow d'erreur global (Error Trigger)

Créez un workflow séparé, appelé par exemple « Erreurs — notification ». Son déclencheur est le nœud **Error Trigger**. Puis, dans chaque workflow de production, *Settings du workflow → Error Workflow* : sélectionnez-le. Désormais, **toute** exécution en échec (y compris celles qui tournent la nuit sans personne) déclenche ce workflow avec un item décrivant l'incident :

```text
{{ $json.workflow.name }}                  → nom du workflow en échec
{{ $json.execution.id }}                   → identifiant de l'exécution
{{ $json.execution.url }}                  → lien direct vers l'exécution
{{ $json.execution.lastNodeExecuted }}     → le nœud qui a échoué
{{ $json.execution.error.message }}        → le message d'erreur
{{ $json.execution.mode }}                 → manual / trigger / webhook…
```

Voici un workflow d'erreur minimal, importable (collez le JSON dans l'éditeur n8n via *Ctrl+V* ; les `typeVersion` peuvent différer selon votre version et seront ajustés automatiquement) :

```json
{
  "name": "Erreurs — notification Slack",
  "nodes": [
    { "parameters": {}, "name": "Error Trigger", "type": "n8n-nodes-base.errorTrigger", "typeVersion": 1, "position": [0, 0] },
    {
      "parameters": {
        "select": "channel",
        "channelId": { "__rl": true, "mode": "name", "value": "#ops-n8n" },
        "text": "=:rotating_light: *{{ $json.workflow.name }}* a échoué\n• Nœud : `{{ $json.execution.lastNodeExecuted }}`\n• Erreur : {{ $json.execution.error.message }}\n• Exécution : {{ $json.execution.url }}"
      },
      "name": "Alerte Slack", "type": "n8n-nodes-base.slack", "typeVersion": 2.2, "position": [260, 0],
      "credentials": { "slackApi": { "name": "Slack ops" } }
    }
  ],
  "connections": { "Error Trigger": { "main": [[{ "node": "Alerte Slack", "type": "main", "index": 0 }]] } }
}
```

Bonne pratique complémentaire : ajouter un nœud Google Sheets ou Data Table « Journal des incidents » (date, workflow, nœud, message) pour repérer les erreurs récurrentes. Et un **Schedule Trigger** hebdomadaire qui compte les lignes de ce journal : si un workflow échoue trois fois par semaine, ce n'est plus un incident, c'est un défaut de conception.

> 💡 **À retenir** — Un Error Workflow ne peut pas se surveiller lui-même : s'il échoue (Slack indisponible), vous ne saurez rien. Donnez-lui deux canaux (Slack **et** e-mail) et gardez-le très simple.

## 5. Sous-workflows : écrire des fonctions

Quand un workflow dépasse vingt nœuds ou qu'un même bloc (« normaliser une adresse e-mail », « créer un contact CRM s'il n'existe pas ») apparaît dans trois workflows, découpez. Un **sous-workflow** commence par le déclencheur **When Executed by Another Workflow** (ex-*Execute Workflow Trigger*), où vous déclarez les champs d'entrée attendus (nom, type) ou acceptez tout. Le workflow appelant utilise le nœud **Execute Sub-workflow** : il envoie ses items, attend, et récupère les items renvoyés par le dernier nœud du sous-workflow.

```
Workflow principal                         Sous-workflow « Normaliser contact »
┌────────────┐   ┌───────────────────┐     ┌──────────────────────────┐   ┌──────────┐
│ Webhook    │──►│ Execute           │────►│ When Executed by Another │──►│ Edit     │──► retour
│ formulaire │   │ Sub-workflow      │◄────│ Workflow (email, nom)    │   │ Fields   │
└────────────┘   └───────────────────┘     └──────────────────────────┘   └──────────┘
```

Avantages : testabilité (vous testez la fonction seule avec un *pin* de données), réutilisation, lisibilité, et surtout **isolation des erreurs** : un sous-workflow possède ses propres réglages et son propre Error Workflow. Dans la leçon 34, vous verrez que l'AI Agent peut appeler un sous-workflow comme **outil** : c'est le même mécanisme.

> ⚠️ **Piège fréquent** — Un sous-workflow qui modifie des données « en passant » (écrit dans un Sheets, envoie un e-mail) sans que son nom l'indique. Règle : le nom dit tout ce que le sous-workflow fait (« SW — Créer contact HubSpot + notifier »).

## 6. Credentials : la bonne manière de s'authentifier

N8N102 (section 2) détaille les quatre schémas d'authentification que vous rencontrerez :

| Schéma | Exemple | Dans n8n |
|---|---|---|
| **Clé API** dans un en-tête ou un paramètre | `x-api-key: …`, `?api_key=…` | Credential *Header Auth* ou *Query Auth*, ou credential dédiée du nœud |
| **Bearer token** | `Authorization: Bearer sk-…` | *Header Auth* avec la valeur `Bearer …`, ou credential dédiée |
| **Basic Auth** | login:mot de passe encodés | *Basic Auth* |
| **OAuth2** | Google, Slack, HubSpot, Microsoft | Credential OAuth2 : n8n gère la redirection (*OAuth Redirect URL* à copier dans la console de l'éditeur) et le rafraîchissement du token |

Les credentials sont stockées **chiffrées** dans la base n8n avec la clé `N8N_ENCRYPTION_KEY` (leçon 37) ; elles ne transitent jamais dans les exports de workflow (seul leur nom apparaît). Trois règles : (1) une credential par usage et par environnement (« HubSpot — prod », « HubSpot — test ») ; (2) jamais de clé en clair dans un champ de nœud ou un nœud Code (le JSON du workflow est exportable et lisible par tous les éditeurs) ; (3) le partage se fait par les **projets** et rôles de n8n, pas en envoyant la clé sur Slack. Pour les API sans nœud dédié, le nœud **HTTP Request** accepte toutes ces credentials (*Authentication → Generic Credential Type* ou *Predefined Credential Type*), gère la **pagination** (onglet *Options → Pagination*) et les verbes GET/POST/PUT/PATCH/DELETE.

## 7. Bonnes pratiques N8N103 : la check-list de mise en production

La section 3 du cours N8N103 (*Organisation et bonnes pratiques*) se résume en une liste que vous pouvez afficher au mur :

1. **Nommage** : workflows préfixés par domaine (« RH — Onboarding », « Support — Tri tickets »), nœuds nommés par action.
2. **Dossiers et tags** : un dossier par projet, des tags `prod`, `test`, `ia`, `critique`.
3. **Documentation** : une **Sticky Note** en haut de chaque workflow (objectif, déclencheur, propriétaire, date de dernière modification) ; les notes supportent le Markdown.
4. **Tests** : épingler (*pin*) des données réalistes sur le déclencheur ; conserver un jeu de cas difficiles ; pour les workflows IA, utiliser les nœuds **Evaluation Trigger / Evaluation** avec un jeu de test (leçon 38).
5. **Publication** : un workflow n'est actif qu'après le bouton *Active* ; vérifier l'Error Workflow, le fuseau horaire (`GENERIC_TIMEZONE`), l'URL de production des webhooks.
6. **Planification** : Schedule Trigger en cron ou intervalle ; éviter les heures rondes si beaucoup de workflows (tous à 9 h 00 = pic).
7. **Monitoring et récupération** : consulter la liste des exécutions, activer la sauvegarde des exécutions réussies le temps du rodage puis la désactiver pour économiser la base, et savoir **rejouer** (*Retry*) une exécution depuis le nœud en échec.
8. **Templates** : partir de la bibliothèque de templates n8n (plus de 2 000 workflows communautaires) en lisant chaque nœud avant d'activer : un template n'est pas audité pour vos données.

> 🔗 **Documentation officielle** — [n8n Academy — N8N103 In Practice](https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about) 🇬🇧 (sections 2 et 3) et [n8n Docs — Use templates](https://docs.n8n.io/build/ways-of-building-workflows/use-templates.md) 🇬🇧.

## 🧪 Exercice pratique

**Consigne.** Reprenez le workflow « commandes » de la leçon 32 et rendez-le robuste : (1) ajoutez un nœud HTTP Request vers une URL volontairement fausse (`https://api.exemple-invalide.test/stock`) avec *Retry On Fail* (2 essais, 2 s) et *On Error → Continue (using error output)* ; (2) la sortie *error* alimente une Data Table « incidents » (date, nœud, message) ; (3) ajoutez un Stop and Error si `total_ttc` est négatif ; (4) créez le workflow « Erreurs — notification » avec Error Trigger et un e-mail (ou Slack), et reliez-le dans les réglages ; (5) extrayez le calcul `total_ht / total_ttc` dans un sous-workflow « SW — Calculer totaux » appelé par Execute Sub-workflow. Testez en injectant un item avec `quantite: -1`.

**Critères de réussite.**
- L'exécution avec l'URL fausse se termine **sans** statut d'erreur, avec une ligne dans « incidents ».
- L'item à quantité négative déclenche Stop and Error, et vous recevez la notification contenant le nom du nœud et le lien vers l'exécution.
- Le sous-workflow possède des champs d'entrée déclarés et renvoie les items enrichis.
- Aucune clé ni mot de passe n'apparaît dans le JSON exporté du workflow.

**Pistes de corrigé.** Message Stop and Error : `=Quantité négative sur la commande de {{ $json.client }}`. Dans l'Error Workflow, l'e-mail utilise `{{ $json.execution.url }}` ; si le lien pointe vers `localhost`, c'est que `WEBHOOK_URL` / `N8N_EDITOR_BASE_URL` ne sont pas configurés (leçon 37).

## ✅ Auto-évaluation express

1. **Quel réglage permet de traiter les items en échec dans une branche dédiée ?**
   → *On Error → Continue (using error output)*.
2. **Quelle expression donne le nom du nœud fautif dans un Error Workflow ?**
   → `{{ $json.execution.lastNodeExecuted }}`.
3. **Pourquoi découper en sous-workflows ?**
   → Réutilisation, lisibilité, tests isolés, gestion d'erreur propre, et réutilisation comme outil d'un agent IA.

## 📚 Pour aller plus loin
- [n8n Academy — N8N102 Integrations](https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about) 🇬🇧 — Error Trigger, Stop and Error, sous-workflows, authentification, pagination, Webhook Trigger.
- [n8n Academy — N8N103 In Practice](https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about) 🇬🇧 — tests, débogage, organisation, publication, monitoring, examen final.
- [n8n Docs — Evaluation node](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluation.md) 🇬🇧 — tester un workflow sur un jeu de cas.
- [n8n Docs — Understand why to test AI workflows](https://docs.n8n.io/build/integrate-ai/test-and-improve-ai-workflows/understand-why-to-test.md) 🇬🇧 — la philosophie d'évaluation reprise en leçon 38.
