---
id: L038
module: M08
level: N2
title: "Projet : assistant de support client automatisé"
minutes: 65
objectives:
  - "Construire de bout en bout un workflow n8n : réception (webhook / e-mail) → classification IA → RAG → réponse validée par un humain → envoi et journalisation"
  - "Appliquer la gestion d'erreurs, les sous-workflows, les credentials et la validation humaine (Send and Wait) dans un cas réel"
  - "Évaluer l'assistant sur un jeu de 10 cas avec le nœud Evaluation et chiffrer son coût mensuel"
  - "Documenter et livrer le workflow (JSON, Sticky Notes, fiche d'exploitation) selon les bonnes pratiques N8N103"
skills: ["C2.1", "C2.2"]
sources:
  - { title: "n8n Academy — N8N103 In Practice: AI, Testing & Best Practices", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about", lang: "en" }
  - { title: "n8n Docs — Human in the loop for tools", url: "https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md", lang: "en" }
  - { title: "n8n Docs — Understand why to test AI workflows", url: "https://docs.n8n.io/build/integrate-ai/test-and-improve-ai-workflows/understand-why-to-test.md", lang: "en" }
  - { title: "n8n Docs — Evaluation node", url: "https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluation.md", lang: "en" }
  - { title: "n8n Docs — Evaluation Trigger", url: "https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluationtrigger.md", lang: "en" }
  - { title: "Anthropic — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
---

# Projet : assistant de support client automatisé

> ⏱ 65 min · 🎯 Niveau 2 · 📚 Module 8

## 🎯 Ce que vous saurez faire
- Livrer un **assistant de support** complet, de la demande entrante à la réponse envoyée, en assemblant tout ce que le module a appris.
- Placer l'humain au bon endroit : l'IA propose, une personne valide en un clic dans Slack, n8n envoie et archive.
- Mesurer la qualité (taux de bonnes réponses, taux de validation sans retouche) et le coût réel.
- Remettre un livrable professionnel : workflows exportés, documentation, fiche d'exploitation, plan d'amélioration.

## 1. Le cahier des charges

**Contexte.** Maison Connectée SAS, PME de 18 personnes qui vend des objets domotiques en ligne, reçoit 60 à 80 demandes de support par jour par formulaire web et par e-mail. Deux personnes y répondent, souvent aux mêmes questions (livraison, retour, appairage d'un capteur, facture). Objectif : **réduire le temps de première réponse de 6 heures à 15 minutes**, sans jamais envoyer une réponse non relue pendant les trois premiers mois.

**Règles métier.**
1. Toute demande reçoit un accusé de réception immédiat avec un numéro de ticket.
2. Les demandes « facturation », « technique » et « livraison » obtiennent une réponse rédigée par l'IA à partir de la base de connaissances, **proposée** dans Slack ; un agent humain approuve, modifie ou rejette.
3. Les demandes « réclamation / remboursement » et tout message au ton agressif sont **escaladés** directement à la responsable, sans réponse IA.
4. Chaque ticket est journalisé (Google Sheets ou Data Table) avec catégorie, réponse, validateur, durée.
5. Toute erreur technique déclenche une alerte ; aucune demande ne doit être perdue silencieusement.

## 2. L'architecture

```
 ENTRÉES                     TRI                         RÉPONSE                        SORTIE
┌──────────────┐      ┌────────────────┐      ┌───────────────────────────┐      ┌─────────────────┐
│ Webhook POST │──┐   │ Text Classifier│      │ AI Agent (Sonnet 5.5)     │      │ Slack : Send and│
│ (formulaire) │  ├──►│ Haiku 5.5      │─┬───►│  ├─ Vector Store Tool     │─────►│ Wait (Approve / │
├──────────────┤  │   │ 5 catégories   │ │    │  │   (Qdrant + Ollama emb.)│      │ Reject + texte) │
│ Gmail Trigger│──┘   └────────────────┘ │    │  └─ Structured Output     │      └────────┬────────┘
│ (support@)   │   Normaliser (SW)       │    └───────────────────────────┘               │
└──────────────┘   + accusé réception    │                                        approuvé│   rejeté
                                         │  réclamation / agressif                        ▼         ▼
                                         └──────────────────────► Slack @responsable   Gmail Reply  Journal
                                                                   + Journal « escaladé »  + Journal   « à reprendre »

 Transverse : Error Workflow (leçon 33) · Journal Sheets/Data Table · Evaluation (jeu de 10 cas)
```

Les deux entrées convergent vers un **sous-workflow « SW — Normaliser demande »** qui produit un item standard, quelle que soit la source :

```json
{ "ticket_id": "T-20261101-7f3a", "canal": "email", "email": "c.martin@exemple.fr",
  "nom": "Claire Martin", "sujet": "Facture en double", "message": "…", "recu_le": "2026-11-01T09:14:00+01:00" }
```

Cette normalisation est ce qui rend le reste du workflow indépendant de la source : ajouter demain un canal WhatsApp ou un chat sur le site ne demande qu'une nouvelle entrée.

## 3. Étape par étape

### 3.1 Entrées et accusé de réception (leçon 36)
- **Webhook** `POST /support-entrant`, Header Auth, *Respond → Using Respond to Webhook node* : la réponse renvoie `{ "ticket_id": … }` au site, qui l'affiche au client.
- **Gmail Trigger** sur `support@maison-connectee.fr`, requête `is:unread -label:n8n-traite`, *Simplify* activé ; aussitôt lu, un nœud Gmail *Add Label* `n8n-traite` empêche tout retraitement.
- **SW — Normaliser demande** : Edit Fields avec `ticket_id` = `{{ 'T-' + $now.toFormat('yyyyMMdd') + '-' + $execution.id.slice(-4) }}`, `email` en minuscules (`{{ $json.email.toLowerCase().trim() }}`), `nom` extrait de l'en-tête *From* si besoin.
- **Accusé de réception** : Gmail *Send* court (« Nous avons bien reçu votre demande, ticket T-… ; une réponse vous parviendra sous 15 minutes en heures ouvrées »). Journal : *Append or Update* sur `ticket_id`, statut `recu`.

### 3.2 Classification (leçon 34, chaîne et non agent)
Nœud **Text Classifier** avec Anthropic Chat Model `claude-haiku-5-5`, catégories et descriptions précises :

```text
facturation   : facture, paiement, avoir, TVA, doublon de prélèvement
technique     : installation, appairage, application mobile, panne, mise à jour
livraison     : délai, suivi de colis, adresse, colis endommagé à la réception
reclamation   : demande de remboursement, litige, menace d'avis négatif, ton agressif ou insultant
autre         : tout ce qui ne rentre pas dans les catégories ci-dessus (partenariat, presse, candidature)
```

Le classifieur a une sortie par catégorie : pas besoin de Switch. Ajoutez dans ses options une consigne : « En cas de doute entre réclamation et une autre catégorie, choisissez réclamation ». Mieux vaut escalader à tort que répondre automatiquement à un client en colère.

### 3.3 Rédaction par RAG (leçon 35)
Sur les sorties *facturation*, *technique*, *livraison* : un **AI Agent** avec Anthropic Chat Model `claude-sonnet-5-5` (la rédaction mérite le modèle supérieur ; la classification, non), **sans mémoire** (chaque ticket est indépendant), un outil **Qdrant Vector Store – Retrieve Documents (As Tool for AI Agent)** nommé `base_support` (Limit 5, embeddings Ollama `nomic-embed-text`, les mêmes qu'à l'ingestion) et un **Structured Output Parser** imposant :

```json
{ "reponse": "texte de la réponse au client, 80 à 150 mots, vouvoiement",
  "sources": ["Titre de fiche 1", "Titre de fiche 2"],
  "confiance": "haute | moyenne | basse",
  "info_manquante": "question à poser au client si nécessaire, sinon vide" }
```

System Message (extrait) : « Vous rédigez des réponses de support pour Maison Connectée. Utilisez l'outil base_support avant toute réponse. Ne répondez qu'à partir des passages renvoyés ; si aucun ne répond, mettez confiance = basse et proposez une question de clarification. N'inventez jamais un délai, un prix ou un numéro de suivi. Ton chaleureux, phrases courtes, pas de jargon. » Un **IF** sur `{{ $json.output.confiance === 'basse' }}` route les cas douteux vers l'escalade humaine plutôt que vers la validation.

### 3.4 Validation humaine (Send and Wait)
Nœud **Slack → Send and Wait for Approval** (ou *Send and Wait for Response* en mode formulaire, qui permet de **modifier** le texte avant envoi), canal `#support-validation` :

```text
=:memo: *Ticket {{ $('SW — Normaliser demande').item.json.ticket_id }}* · {{ $('Text Classifier').item.json.categorie ?? 'catégorie' }} · confiance {{ $json.output.confiance }}
*Client :* {{ $('SW — Normaliser demande').item.json.nom }} — _{{ $('SW — Normaliser demande').item.json.sujet }}_
*Demande :* {{ $('SW — Normaliser demande').item.json.message.slice(0, 400) }}
*Réponse proposée :*
{{ $json.output.reponse }}
_Sources : {{ $json.output.sources.join(', ') }}_
```

Le workflow **se met en pause** (sans consommer de ressources) jusqu'au clic ; réglez une **limite d'attente** (par exemple 4 heures ouvrées) : à expiration, un rappel part à la responsable. Le résultat arrive dans `{{ $json.data.approved }}` (true / false) ou, en mode formulaire, dans les champs du formulaire (`{{ $json.data['Réponse finale'] }}`), chemins à vérifier sur votre version du nœud en exécutant une fois le test.

### 3.5 Envoi et journalisation
- **Approuvé** → Gmail *Reply* dans le fil (`threadId` conservé depuis la normalisation) ou, pour le canal web, Gmail *Send* ; puis journal : statut `repondu`, `validee_par` = `{{ $json.data.user ?? 'slack' }}`, `duree_min` = `{{ Math.round($now.diff($('SW — Normaliser demande').item.json.recu_le.toDateTime(), 'minutes').minutes) }}`.
- **Rejeté** → journal statut `a_reprendre`, message Slack au validateur : « Ticket à traiter manuellement ».
- **Escalade** (réclamation, autre, confiance basse) → Slack avec mention de la responsable, journal statut `escalade`. Aucune réponse IA n'est envoyée.

### 3.6 Robustesse (leçon 33)
Error Workflow relié ; *Retry On Fail* (3 × 5 s) sur Gmail, Slack, Sheets ; *On Error → Continue (using error output)* sur l'AI Agent avec, en sortie d'erreur, une escalade humaine « IA indisponible » : le client reçoit toujours une réponse, par un humain si la machine échoue. Sticky Note en tête de workflow : objectif, propriétaire, modèles utilisés, date d'ingestion de la base.

## 4. Le squelette importable

Le JSON ci-dessous contient le cœur du flux (webhook → classifieur → agent RAG → validation Slack → réponse). Importez-le, puis complétez les credentials, les champs marqués `À COMPLÉTER`, l'entrée Gmail, le sous-workflow de normalisation et le journal. Les `typeVersion` sont indicatifs : n8n les ajuste à l'import.

```json
{
  "name": "Support — Assistant IA (squelette)",
  "nodes": [
    { "parameters": { "httpMethod": "POST", "path": "support-entrant", "authentication": "headerAuth", "responseMode": "responseNode" },
      "name": "Webhook formulaire", "type": "n8n-nodes-base.webhook", "typeVersion": 2, "position": [0, 300] },
    { "parameters": { "respondWith": "json", "responseBody": "={{ { \"ticket_id\": $json.ticket_id } }}" },
      "name": "Répondre au site", "type": "n8n-nodes-base.respondToWebhook", "typeVersion": 1.1, "position": [460, 480] },
    { "parameters": { "assignments": { "assignments": [
        { "name": "ticket_id", "type": "string", "value": "={{ 'T-' + $now.toFormat('yyyyMMdd') + '-' + $execution.id.slice(-4) }}" },
        { "name": "email", "type": "string", "value": "={{ $json.body.email.toLowerCase().trim() }}" },
        { "name": "nom", "type": "string", "value": "={{ $json.body.nom }}" },
        { "name": "sujet", "type": "string", "value": "={{ $json.body.sujet }}" },
        { "name": "message", "type": "string", "value": "={{ $json.body.message }}" },
        { "name": "recu_le", "type": "string", "value": "={{ $now.toISO() }}" } ] } },
      "name": "SW — Normaliser demande", "type": "n8n-nodes-base.set", "typeVersion": 3.4, "position": [230, 300] },
    { "parameters": { "inputText": "=Sujet : {{ $json.sujet }}\nMessage : {{ $json.message }}",
        "categories": { "categories": [
          { "category": "facturation", "description": "facture, paiement, avoir, TVA, doublon de prélèvement" },
          { "category": "technique", "description": "installation, appairage, application mobile, panne, mise à jour" },
          { "category": "livraison", "description": "délai, suivi de colis, adresse, colis endommagé" },
          { "category": "reclamation", "description": "remboursement, litige, menace d'avis négatif, ton agressif" },
          { "category": "autre", "description": "partenariat, presse, candidature, hors sujet" } ] } },
      "name": "Text Classifier", "type": "@n8n/n8n-nodes-langchain.textClassifier", "typeVersion": 1, "position": [460, 300] },
    { "parameters": { "model": "claude-haiku-5-5", "options": { "maxTokensToSample": 256 } },
      "name": "Claude Haiku 5.5 (tri)", "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic", "typeVersion": 1.3, "position": [460, 520],
      "credentials": { "anthropicApi": { "name": "Anthropic — support" } } },
    { "parameters": { "promptType": "define", "text": "=Demande du client {{ $('SW — Normaliser demande').item.json.nom }} :\n{{ $('SW — Normaliser demande').item.json.message }}",
        "hasOutputParser": true,
        "options": { "systemMessage": "À COMPLÉTER : System Message de la section 3.3", "maxIterations": 6 } },
      "name": "AI Agent rédaction", "type": "@n8n/n8n-nodes-langchain.agent", "typeVersion": 2, "position": [760, 200] },
    { "parameters": { "model": "claude-sonnet-5-5", "options": { "maxTokensToSample": 600 } },
      "name": "Claude Sonnet 5.5 (rédaction)", "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic", "typeVersion": 1.3, "position": [700, 440],
      "credentials": { "anthropicApi": { "name": "Anthropic — support" } } },
    { "parameters": { "mode": "retrieve-as-tool", "toolName": "base_support",
        "toolDescription": "Recherche dans les fiches de support Maison Connectée (produits, livraison, retours, facturation).",
        "qdrantCollection": { "__rl": true, "mode": "list", "value": "support_fiches" }, "topK": 5 },
      "name": "Qdrant base_support", "type": "@n8n/n8n-nodes-langchain.vectorStoreQdrant", "typeVersion": 1.1, "position": [860, 440],
      "credentials": { "qdrantApi": { "name": "Qdrant local" } } },
    { "parameters": { "model": "nomic-embed-text" },
      "name": "Embeddings Ollama", "type": "@n8n/n8n-nodes-langchain.embeddingsOllama", "typeVersion": 1, "position": [860, 600] },
    { "parameters": { "jsonSchemaExample": "{\"reponse\":\"…\",\"sources\":[\"…\"],\"confiance\":\"haute\",\"info_manquante\":\"\"}" },
      "name": "Structured Output Parser", "type": "@n8n/n8n-nodes-langchain.outputParserStructured", "typeVersion": 1.2, "position": [1020, 440] },
    { "parameters": { "operation": "sendAndWait", "select": "channel",
        "channelId": { "__rl": true, "mode": "name", "value": "#support-validation" },
        "message": "À COMPLÉTER : message de la section 3.4", "options": { "limitWaitTime": { "values": { "limitType": "afterTimeInterval", "resumeAmount": 4, "resumeUnit": "hours" } } } },
      "name": "Validation Slack", "type": "n8n-nodes-base.slack", "typeVersion": 2.3, "position": [1120, 200],
      "credentials": { "slackApi": { "name": "Slack support" } } },
    { "parameters": { "conditions": { "conditions": [ { "leftValue": "={{ $json.data.approved }}", "rightValue": true, "operator": { "type": "boolean", "operation": "true" } } ] } },
      "name": "Approuvé ?", "type": "n8n-nodes-base.if", "typeVersion": 2.2, "position": [1380, 200] },
    { "parameters": { "sendTo": "={{ $('SW — Normaliser demande').item.json.email }}",
        "subject": "=Re: {{ $('SW — Normaliser demande').item.json.sujet }} — ticket {{ $('SW — Normaliser demande').item.json.ticket_id }}",
        "message": "=Bonjour {{ $('SW — Normaliser demande').item.json.nom }},\n\n{{ $('AI Agent rédaction').item.json.output.reponse }}\n\nBien cordialement,\nL'équipe support Maison Connectée" },
      "name": "Gmail — envoyer réponse", "type": "n8n-nodes-base.gmail", "typeVersion": 2.1, "position": [1640, 120],
      "credentials": { "gmailOAuth2": { "name": "Gmail support@" } } },
    { "parameters": { "select": "channel", "channelId": { "__rl": true, "mode": "name", "value": "#support-escalade" },
        "text": "=:warning: Ticket {{ $('SW — Normaliser demande').item.json.ticket_id }} à traiter manuellement ({{ $('SW — Normaliser demande').item.json.email }})." },
      "name": "Escalade humaine", "type": "n8n-nodes-base.slack", "typeVersion": 2.3, "position": [1120, 560],
      "credentials": { "slackApi": { "name": "Slack support" } } }
  ],
  "connections": {
    "Webhook formulaire": { "main": [[ { "node": "SW — Normaliser demande", "type": "main", "index": 0 } ]] },
    "SW — Normaliser demande": { "main": [[ { "node": "Répondre au site", "type": "main", "index": 0 }, { "node": "Text Classifier", "type": "main", "index": 0 } ]] },
    "Text Classifier": { "main": [
      [ { "node": "AI Agent rédaction", "type": "main", "index": 0 } ],
      [ { "node": "AI Agent rédaction", "type": "main", "index": 0 } ],
      [ { "node": "AI Agent rédaction", "type": "main", "index": 0 } ],
      [ { "node": "Escalade humaine", "type": "main", "index": 0 } ],
      [ { "node": "Escalade humaine", "type": "main", "index": 0 } ] ] },
    "Claude Haiku 5.5 (tri)": { "ai_languageModel": [[ { "node": "Text Classifier", "type": "ai_languageModel", "index": 0 } ]] },
    "Claude Sonnet 5.5 (rédaction)": { "ai_languageModel": [[ { "node": "AI Agent rédaction", "type": "ai_languageModel", "index": 0 } ]] },
    "Qdrant base_support": { "ai_tool": [[ { "node": "AI Agent rédaction", "type": "ai_tool", "index": 0 } ]] },
    "Embeddings Ollama": { "ai_embedding": [[ { "node": "Qdrant base_support", "type": "ai_embedding", "index": 0 } ]] },
    "Structured Output Parser": { "ai_outputParser": [[ { "node": "AI Agent rédaction", "type": "ai_outputParser", "index": 0 } ]] },
    "AI Agent rédaction": { "main": [[ { "node": "Validation Slack", "type": "main", "index": 0 } ]] },
    "Validation Slack": { "main": [[ { "node": "Approuvé ?", "type": "main", "index": 0 } ]] },
    "Approuvé ?": { "main": [ [ { "node": "Gmail — envoyer réponse", "type": "main", "index": 0 } ], [ { "node": "Escalade humaine", "type": "main", "index": 0 } ] ] }
  },
  "settings": { "executionOrder": "v1", "timezone": "Europe/Paris" }
}
```

> ⚠️ **Piège fréquent** — Oublier d'ingérer la base (workflow A de la leçon 35) avant de tester : l'agent répond « je n'ai pas cette information » à tout, et vous cherchez le bug au mauvais endroit. Vérifiez d'abord le nombre de vecteurs dans la collection Qdrant.

## 5. Tester avant de livrer : le nœud Evaluation

La documentation n8n le dit sans détour : un workflow IA ne se teste pas « à l'œil » sur deux exemples. Créez une feuille Google Sheets `tests_support` de **10 cas** : colonnes `message`, `categorie_attendue`, `elements_attendus` (mots-clés que la réponse doit contenir), `doit_escalader` (oui/non). Exemples : facture en double (facturation ; « avoir », « 5 jours ») ; capteur qui ne s'appaire pas (technique ; « bouton », « 10 secondes ») ; « c'est inadmissible, je veux être remboursé immédiatement » (réclamation ; escalade = oui) ; question sur un produit inexistant (confiance basse ; escalade = oui).

Le nœud **Evaluation Trigger** lit cette feuille et injecte chaque cas à la place du webhook ; le flux tourne (en désactivant l'envoi réel : un IF sur `{{ $execution.mode === 'evaluation' }}` ou un nœud *Evaluation → Check if evaluating* bascule vers une sortie « simulation ») ; le nœud **Evaluation → Set Outputs / Set Metrics** enregistre pour chaque ligne la catégorie obtenue, la présence des éléments attendus et la décision d'escalade. Vous obtenez un **tableau de bord** : taux de bonne catégorie, taux de réponses conformes, faux négatifs d'escalade (les plus graves). Objectif de livraison : **≥ 90 % de bonnes catégories, ≥ 80 % de réponses conformes, 0 réclamation non escaladée**.

Puis, en production, un second indicateur gratuit : le **taux de validation sans modification** dans Slack. S'il monte de 40 % à 85 % après trois semaines d'enrichissement de la base, vous avez la preuve chiffrée de la valeur de l'assistant.

## 6. Combien ça coûte ? (nov. 2026)

Hypothèses : 70 tickets/jour, 22 jours/mois = 1 540 tickets ; tarifs page Pricing d'Anthropic.

| Poste | Calcul | Coût mensuel |
|---|---|---|
| Classification Haiku 5.5 | 1 540 × ~600 tokens entrée × 0,10 $/M + 1 540 × 20 tokens sortie × 0,50 $/M | ≈ 0,11 $ |
| Rédaction Sonnet 5.5 (≈ 70 % des tickets) | 1 078 × ~3 000 tokens entrée (system + passages RAG) × 2 $/M + 1 078 × 250 sortie × 10 $/M | ≈ 6,5 $ + 2,7 $ ≈ 9,2 $ |
| Embeddings (Ollama local) | — | 0 $ |
| n8n auto-hébergé + Qdrant (VPS 4 Go) | abonnement hébergeur | ≈ 10 à 15 €/mois |
| **Total** | | **≈ 20 à 25 €/mois** |

Face à cela : 70 tickets/jour × 8 minutes gagnées = plus de 9 heures par jour de travail de support redéployées. Faites ce calcul **avec vos chiffres** : c'est l'argument qui fait passer un projet. Et si la confidentialité l'exige, remplacez Claude par un modèle local via Ollama (module 10) : coût API nul, qualité à re-mesurer avec le nœud Evaluation.

## 7. Livrable et plan d'amélioration

Votre dossier de livraison contient : (1) les trois exports JSON (ingestion, assistant, workflow d'erreur) ; (2) une fiche d'exploitation d'une page (déclencheurs, credentials et leurs propriétaires, modèles et coûts, procédure de ré-ingestion de la base, contact en cas d'alerte) ; (3) le tableau d'évaluation à 10 cas avec les scores ; (4) un plan en trois lignes : passer de *Approve/Reject* à l'envoi automatique pour la catégorie « livraison » quand le taux de validation sans retouche dépasse 90 % trois semaines d'affilée ; ajouter un canal ; enrichir la base à partir des tickets « à reprendre ».

> 💡 **À retenir** — L'automatisation progressive (proposer → valider → automatiser une catégorie à la fois, mesure à l'appui) est ce qui distingue un projet IA accepté par les équipes d'un projet rejeté au premier incident.

> 🔗 **Documentation officielle** — [n8n Docs — Human in the loop for tools](https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md) 🇬🇧, [Evaluation node](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluation.md) 🇬🇧 et [Evaluation Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.evaluationtrigger.md) 🇬🇧.

## 🧪 Exercice pratique

**Consigne (projet évalué, compétences C2.1 et C2.2).** Réalisez l'assistant complet pour Maison Connectée, ou adaptez-le à votre propre activité (même structure, vos catégories, vos fiches). Livrables : les exports JSON, la base de connaissances ingérée (≥ 6 fiches), la feuille de 10 cas de test et ses résultats, la fiche d'exploitation, le calcul de coût. Démonstration : trois demandes en direct (une facturation, une technique, une réclamation) depuis le formulaire ou un e-mail.

**Critères de réussite (grille d'évaluation).**
- Les trois demandes aboutissent : deux réponses proposées dans Slack et envoyées après validation, une escalade sans réponse IA.
- Le jeu de test donne ≥ 8/10 réponses conformes et aucune réclamation non escaladée.
- Une panne simulée (credential Anthropic invalide) déclenche l'alerte et l'escalade « IA indisponible » ; aucun ticket perdu.
- Aucune clé en clair ; credentials sur un compte dédié ; Sticky Note de documentation présente ; nœuds nommés.
- Le coût mensuel est chiffré et sourcé.

**Pistes de corrigé.** Si le Structured Output Parser échoue souvent (« could not parse »), activez l'option de **réparation automatique** du parser (ou ajoutez un exemple de JSON dans le System Message) et réduisez la température. Si la validation Slack ne reprend pas, vérifiez `WEBHOOK_URL` : le bouton Slack appelle une URL de reprise sur votre instance, qui doit être joignable en HTTPS (leçon 37).

## ✅ Auto-évaluation express

1. **Pourquoi classer avec Haiku et rédiger avec Sonnet ?**
   → La classification est une tâche simple où Haiku 5.5 suffit pour vingt fois moins cher ; la rédaction client bénéficie de la qualité de Sonnet 5.5 ; on paie le modèle fort seulement là où il apporte.
2. **Quel nœud met le workflow en pause jusqu'à la décision humaine ?**
   → Slack *Send and Wait for Approval* (ou *for Response*) ; la même logique existe pour Gmail, Telegram, Teams et le nœud Wait.
3. **Que mesure-t-on avant de livrer, et avec quoi ?**
   → Taux de bonnes catégories, conformité des réponses et escalades manquées, sur un jeu de 10 cas, avec Evaluation Trigger + Evaluation.

## 📚 Pour aller plus loin
- [n8n Academy — N8N103 In Practice: AI, Testing & Best Practices](https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about) 🇬🇧 — le cours qui conclut n8n Foundations ; passez son examen final après ce projet.
- [n8n Docs — Understand why to test AI workflows](https://docs.n8n.io/build/integrate-ai/test-and-improve-ai-workflows/understand-why-to-test.md) 🇬🇧 — la méthode d'évaluation.
- [n8n Docs — MCP Server Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.mcptrigger.md) 🇬🇧 — exposer cet assistant comme outil MCP pour Claude ou un autre agent.
- [n8n Community — point sur la certification officielle](https://community.n8n.io/t/no-official-n8n-certification-yet/318573?tl=en) 🇬🇧 — examen chronométré annoncé pour fin T4 2026.
- [Anthropic — Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 — pour refaire le calcul de coût avec vos volumes.
