---
id: L062
module: M15
level: N2
title: "SaaS, API ou local : coûts, risques, grille de décision"
minutes: 60
objectives:
  - "Distinguer les trois modes de consommation de l'IA en entreprise (SaaS, API, local) et leurs conséquences sur les données, les coûts et les compétences"
  - "Calculer un coût total de possession (TCO) sur 3 ans à partir des tarifs publics de novembre 2026 pour trois scénarios d'entreprise"
  - "Évaluer les risques (dépendance, dépréciation des modèles, fuite de données) et la réversibilité de chaque option"
  - "Appliquer une grille de décision en sept critères pour recommander une architecture à une organisation"
skills: ["C2.6", "C1.2"]
sources:
  - { title: "Anthropic — Pricing (Claude Platform)", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "OpenAI — API pricing", url: "https://developers.openai.com/api/docs/pricing", lang: "en" }
  - { title: "Mistral AI — Pricing", url: "https://docs.mistral.ai/inference/pricing", lang: "en" }
  - { title: "Google — Gemini API pricing", url: "https://ai.google.dev/gemini-api/docs/pricing", lang: "en" }
  - { title: "Scaleway — Tarifs GPU", url: "https://www.scaleway.com/en/pricing/gpu", lang: "en" }
  - { title: "OVHcloud — Public Cloud prices", url: "https://ovhcloud.com/en/public-cloud/prices", lang: "en" }
  - { title: "IntuitionLabs — NVIDIA DGX Spark review", url: "https://intuitionlabs.ai/articles/nvidia-dgx-spark-review", lang: "en" }
  - { title: "Claude Academy — Deploying Claude Enterprise with confidence", url: "https://academy.claude.com/courses/deploying-claude-enterprise-with-confidence", lang: "en" }
  - { title: "Anthropic — Model deprecations", url: "https://platform.claude.com/docs/en/about-claude/model-deprecations", lang: "en" }
---

# SaaS, API ou local : coûts, risques, grille de décision

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 15

## 🎯 Ce que vous saurez faire
- Expliquer à une direction, en cinq minutes, la différence entre « abonner les salariés à un outil », « brancher une API » et « installer un modèle chez nous ».
- Chiffrer un coût total de possession (*Total Cost of Ownership*, TCO) sur trois ans, en incluant ce que les devis oublient : le temps humain, la formation, la sortie.
- Repérer les trois risques qui coûtent le plus cher a posteriori : la dépendance à un fournisseur, le retrait d'un modèle, la fuite de données.
- Rendre une recommandation argumentée avec une grille de sept critères, réutilisable dans l'étude de cas de fin de module.

## 1. Trois façons de consommer l'IA

Au module 10 (leçon L041), vous avez comparé local et cloud sous l'angle technique. Ici, nous changeons de chaise : vous êtes la personne qui signe le bon de commande. Trois portes s'offrent à vous.

| Mode | Ce que vous achetez | Qui opère ? | Exemples (nov. 2026) |
|---|---|---|---|
| **SaaS** (*Software as a Service*) | Des sièges utilisateurs sur une application prête à l'emploi | L'éditeur, de bout en bout | Claude Team / Enterprise, ChatGPT Business / Enterprise, Gemini dans Google Workspace, Mistral Le Chat |
| **API** (*Application Programming Interface*) | Des tokens consommés par vos propres applications ou workflows (n8n, Open WebUI, scripts) | Vous assemblez, l'éditeur fait tourner le modèle | Claude Sonnet 5.5 à 2 $ / 10 $ par million de tokens, Mistral Small 4 à 0,15 $ / 0,60 $, Gemini 3.8 Flash à 0,75 $ / 3,75 $ |
| **Local** (ou GPU loué) | Du matériel (ou des heures de GPU) sur lequel tourne un modèle à poids ouverts | Vous, intégralement | Qwen3.8-27B sur une station RTX 5090 ; gpt-oss-120b sur un DGX Spark ; H100 Scaleway à 2,73 € HT/h |

Analogie : pour nourrir une équipe, vous pouvez prendre un abonnement à une cantine (SaaS : simple, prix par couvert, menu imposé), commander des ingrédients au kilo chez un grossiste et cuisiner vous-même (API : vous payez ce que vous consommez, mais il faut un cuisinier), ou acheter une cuisine professionnelle (local : gros ticket d'entrée, puis liberté totale et huis clos). Aucune n'est « la meilleure » : tout dépend de combien de couverts vous servez, de ce qu'il y a dans l'assiette, et de qui peut cuisiner.

Ces trois modes se combinent souvent. Une PME typique de 2026 a des sièges SaaS pour la bureautique, une ou deux automatisations n8n branchées sur une API, et parfois un petit modèle local pour les données qui ne doivent pas sortir.

> 💡 **À retenir** — Le SaaS vend de la **simplicité**, l'API vend de la **flexibilité**, le local vend du **contrôle**. Votre travail n'est pas de choisir le « meilleur » mais de mettre chaque usage derrière la bonne porte.

## 2. Les sept critères de la grille

Avant de parler argent, posez sept questions. L'ordre compte : les deux premières peuvent éliminer une option à elles seules.

1. **Confidentialité et conformité** — Les données traitées peuvent-elles sortir de l'entreprise ? Vers un sous-traitant hors UE ? (Le détail juridique est en L063.) Un « non » ferme la porte du SaaS grand public et impose au minimum une offre entreprise avec engagement contractuel de non-entraînement, ou le local.
2. **Qualité requise** — La tâche exige-t-elle un modèle frontière (rédaction juridique, code complexe) ou un modèle « suffisant » (classification, extraction, résumé) ? Un modèle ouvert de 27 milliards de paramètres fait très bien le second cas, rarement le premier.
3. **Volume et régularité** — 50 requêtes par jour ou 50 000 ? Un pic ponctuel ou un flux continu ? Le local s'amortit avec un flux élevé et régulier ; l'API absorbe les pics sans investissement.
4. **Intégration** — L'IA doit-elle être dans un chat (SaaS suffit) ou à l'intérieur d'un processus (API ou local, via n8n ou du code) ?
5. **Compétences internes** — Qui va installer, surveiller, mettre à jour ? Sans personne, le local est un piège ; l'API demande au moins une personne à l'aise avec n8n ou un script.
6. **Coût total sur 3 ans** — Le sujet de la section suivante.
7. **Réversibilité** — Combien coûte le départ ? Que se passe-t-il si l'éditeur retire le modèle, triple ses prix ou disparaît ?

🎮 **Défi** — Avant de lire la suite, notez pour votre propre organisation la réponse aux questions 1, 3 et 5. Ce sont celles qui tranchent le plus souvent.

## 3. Calculer un coût total de possession

Un devis SaaS affiche un prix par siège ; une page de tarifs API affiche un prix au million de tokens ; une station de travail a un prix d'achat. Aucun des trois n'est un coût total. Le TCO additionne, sur une période fixée (nous prendrons 3 ans, durée de vie raisonnable d'une décision IA), quatre familles de coûts :

```
TCO (3 ans) = Coûts directs       (sièges, tokens, matériel, hébergement, électricité)
            + Coûts de mise en place (paramétrage, intégration, migration des données)
            + Coûts humains récurrents (administration, supervision, formation art. 4 AI Act)
            + Coût de sortie       (export, réécriture des prompts/workflows, double tournée)
```

Deux conventions pour toute la leçon : les tarifs API sont en dollars US tels qu'affichés sur les pages officielles (nov. 2026) et nous supposons une parité 1 $ ≈ 1 € pour simplifier les comparaisons (appliquez le taux du jour dans un vrai dossier) ; le temps humain est valorisé 650 € HT la journée, tarif courant d'un intégrateur indépendant.

Pour estimer une consommation API, il faut compter les tokens. Rappel du module 2 : en français, 1 000 tokens représentent environ 700 mots. Une requête type « analyser un document de 5 pages » consomme environ 3 000 tokens en entrée (consigne + document) et 300 en sortie.

> ⚠️ **Piège fréquent** — Oublier que les tokens d'**entrée** incluent tout ce que vous envoyez à chaque appel : le prompt système, les exemples, les documents joints, l'historique de conversation. Dans un chatbot, l'historique est renvoyé à chaque message : la facture grimpe au carré de la longueur de la conversation. Le *prompt caching* (lecture en cache à 0,10 $/MTok sur Sonnet 5.5 au lieu de 2 $) et le mode *Batch* (-50 % chez Anthropic, OpenAI, Google) sont vos deux leviers.

## 4. Trois scénarios chiffrés

### Scénario A — Cabinet comptable, 12 collaborateurs, usage bureautique

**Besoin** : rédaction de courriers, synthèse de textes réglementaires, aide Excel. Pas de documents clients nominatifs dans les prompts (règle de la charte, voir L063). Volume : environ 20 échanges par personne et par jour ouvré.

**Option SaaS** — Offre entreprise d'un éditeur (Claude Team, ChatGPT Business…). Les prix publics par siège changent souvent : nous posons une **hypothèse H = 25 € HT / utilisateur / mois**, à remplacer par le tarif lu sur la page officielle le jour du devis. Mise en place : une demi-journée d'administration (SSO, groupes, plafond de dépense : le cours « Deploying Claude Enterprise with confidence » détaille ces cinq décisions). Formation : une demi-journée par personne.

**Option API** — Interface Open WebUI (vue en L044) hébergée sur un petit serveur virtuel, branchée sur Claude Sonnet 5.5 (2 $ / 10 $ par MTok). Consommation estimée : 20 échanges × 3 000 tokens entrée × 20 jours = 1,2 M tokens entrée et 0,48 M sortie par personne et par mois.

| Poste | SaaS (H = 25 €) | API + Open WebUI |
|---|---|---|
| Sièges / tokens | 12 × 25 × 36 mois = **10 800 €** | (1,2 × 2 $ + 0,48 × 10 $) = 7,20 $ / pers. / mois → 12 × 7,20 × 36 = **3 110 €** |
| Hébergement | inclus | VPS ~20 €/mois × 36 = 720 € |
| Mise en place | 0,5 j = 325 € | 3 j (installation, SSO, sauvegardes) = 1 950 € |
| Administration récurrente | ~0,5 j/an = 975 € | ~1 j/trimestre = 7 800 € |
| Formation (identique) | 6 j = 3 900 € | 6 j = 3 900 € |
| Sortie | export des conversations : 0,5 j = 325 € | réinstallation ailleurs : 1 j = 650 € |
| **TCO 3 ans** | **≈ 16 300 €** | **≈ 18 100 €** |

Verdict : à 12 personnes, le SaaS gagne, non pas sur les tokens (l'API coûte trois fois moins) mais sur le **temps humain**. Refaites le calcul à 60 personnes : les sièges passent à 54 000 € alors que l'administration de l'API reste quasiment identique ; avec ces hypothèses, la balance s'inverse dès une quinzaine d'utilisateurs (chaque siège SaaS coûte 900 € sur 3 ans contre environ 260 € de tokens, et l'écart de 641 € par personne rembourse les 9 500 € de surcoût fixe de l'API à partir de 15 personnes). C'est tout l'intérêt d'un TCO paramétré plutôt que d'une intuition.

### Scénario B — E-commerce, tri de 200 000 e-mails clients par mois

**Besoin** : classer chaque e-mail entrant (réclamation, suivi de commande, question produit…), extraire le numéro de commande, proposer une réponse. Tâche de « modèle suffisant », en flux continu, intégrée dans n8n. Consommation : 3 000 tokens entrée (prompt système + e-mail + historique) et 300 sortie, soit 600 M tokens entrée et 60 M sortie par mois.

| Option | Calcul mensuel | Coût 3 ans (tokens seuls) |
|---|---|---|
| Claude Haiku 5.5 (0,10 $ / 0,50 $) | 60 + 30 = 90 $ ; en Batch (0,05 / 0,25) : 45 $ | 3 240 $ (1 620 $ en Batch) |
| Mistral Small 4 (0,15 $ / 0,60 $) | 90 + 36 = 126 $ | 4 536 $ |
| Gemini 3.8 Flash (0,75 $ / 3,75 $, hausse annoncée au 1er janv. 2027) | 450 + 225 = 675 $ | 24 300 $ (avant hausse) |
| Claude Sonnet 5.5 (2 $ / 10 $) | 1 200 + 600 = 1 800 $ | 64 800 $ |
| GPU loué Scaleway L40S 48 Go (1,40 € HT/h, 24 h/24) avec Qwen3.8-27B | 1 008 € | 36 300 € + 10 j d'exploitation/an (19 500 €) ≈ **55 800 €** |

Verdict : pour une tâche simple à fort volume, un petit modèle via API coûte quelques dizaines de dollars par mois. Le GPU loué ne devient compétitif que si la confidentialité l'impose ou si le volume est dix fois supérieur. Et le choix du modèle pèse plus que le choix du fournisseur : passer de Sonnet à Haiku divise la facture par vingt, à qualité suffisante pour une classification. Testez toujours la qualité du petit modèle sur 200 e-mails réels avant de conclure.

### Scénario C — Cabinet d'avocats, 15 personnes, 2 000 pièces par mois sous secret professionnel

**Besoin** : résumer et indexer des pièces de procédure. Critère 1 de la grille : les données ne sortent pas. Le SaaS grand public est exclu ; l'API ne serait acceptable qu'avec un contrat entreprise et une analyse juridique (L063) ; le cabinet choisit de comparer deux options « sous contrôle ». Consommation : 8 000 tokens entrée et 500 sortie par pièce, soit 16 M entrée et 1 M sortie par mois.

| Option | Coûts directs 3 ans | Humain 3 ans | TCO 3 ans |
|---|---|---|---|
| **Station locale** : PC avec RTX 5090 32 Go (~1 999 $ la carte, ~3 500 € la machine) + Qwen3.8-27B Q4 (~16-19 Go, ≈ 59 tokens/s) | 3 500 € + électricité ~150 €/an = 3 950 € | Installation 2 j + maintenance 2 j/an = 5 200 € | **≈ 9 150 €** |
| **DGX Spark 128 Go** (~6 950 $ en oct. 2026, +74 % depuis le lancement à 3 999 $) + gpt-oss-120b (≈ 40-60 tokens/s) | 6 950 € + 300 € = 7 250 € | idem 5 200 € | ≈ 12 450 € |
| **GPU loué en France** (Scaleway L40S, 8 h × 21 j = 235 € HT/mois) | 8 460 € | 2 j + 3 j/an = 7 150 € | ≈ 15 600 € |
| (Pour mémoire) API Sonnet 5.5 : 32 + 10 = 42 $/mois | 1 512 $ | 2 j + 1 j/an = 3 250 € | ≈ 4 760 € — **mais exclue par le critère 1** |

Verdict : la station locale est la moins chère **et** la plus conforme. Vérifiez la charge : 1 M tokens générés par mois à 59 tokens/s représentent moins de 5 heures de calcul mensuel, la machine est très loin de saturer. La dernière ligne illustre une leçon importante : l'API est souvent l'option la moins chère sur le papier ; c'est la conformité, pas le prix, qui pousse vers le local.

> 🔗 **Documentation officielle** — Tarifs à relire avant tout devis : [Anthropic Pricing](https://platform.claude.com/docs/en/about-claude/pricing), [OpenAI Pricing](https://developers.openai.com/api/docs/pricing), [Mistral Pricing](https://docs.mistral.ai/inference/pricing), [Gemini API Pricing](https://ai.google.dev/gemini-api/docs/pricing), [Scaleway GPU](https://www.scaleway.com/en/pricing/gpu), [OVHcloud](https://ovhcloud.com/en/public-cloud/prices).

### Votre calculateur TCO

Le script ci-dessous reproduit les scénarios et vous permet d'en ajouter. Les tarifs sont des paramètres : mettez-les à jour, ne les gravez pas.

```python
# tco.py — calculateur de coût total de possession sur N années (Python 3.12+)
# Tarifs API en $/MTok (nov. 2026), à actualiser depuis les pages officielles.
from dataclasses import dataclass

TARIFS = {  # (entrée, sortie) en $ par million de tokens
    "claude-haiku-5-5": (0.10, 0.50),
    "claude-sonnet-5-5": (2.00, 10.00),
    "mistral-small-4": (0.15, 0.60),
    "gemini-3.8-flash": (0.75, 3.75),
}
JOUR_HOMME = 650  # € HT, intégrateur indépendant

@dataclass
class Option:
    nom: str
    direct_mensuel: float = 0.0   # tokens, sièges, location GPU, électricité
    capex: float = 0.0            # achat de matériel (une fois)
    mise_en_place_j: float = 0.0  # jours-homme (une fois)
    recurrent_j_an: float = 0.0   # jours-homme par an
    formation_j: float = 0.0      # jours-homme (une fois)
    sortie_j: float = 0.0         # jours-homme (une fois)

    def tco(self, annees: int = 3) -> float:
        humain = (self.mise_en_place_j + self.formation_j + self.sortie_j
                  + self.recurrent_j_an * annees) * JOUR_HOMME
        return self.capex + self.direct_mensuel * 12 * annees + humain

def cout_api(modele: str, m_tokens_in: float, m_tokens_out: float, batch: bool = False) -> float:
    """Coût mensuel en $ pour un volume en millions de tokens."""
    p_in, p_out = TARIFS[modele]
    facteur = 0.5 if batch else 1.0
    return (m_tokens_in * p_in + m_tokens_out * p_out) * facteur

# Scénario B : 600 M tokens entrée, 60 M sortie par mois
for modele in TARIFS:
    print(f"{modele:18} {cout_api(modele, 600, 60):8.0f} $/mois")

# Scénario C : station locale vs GPU loué
options = [
    Option("Station RTX 5090", direct_mensuel=12.5, capex=3500, mise_en_place_j=2, recurrent_j_an=2),
    Option("GPU loué L40S 8h/j", direct_mensuel=235, mise_en_place_j=2, recurrent_j_an=3),
]
for o in options:
    print(f"{o.nom:20} TCO 3 ans ≈ {o.tco():,.0f} €")
```

## 5. Risques et réversibilité

Le TCO mesure ce que vous paierez si tout se passe comme prévu. La réversibilité mesure ce que vous paierez si ce n'est pas le cas. Quatre risques à inscrire dans tout dossier.

**Dépréciation des modèles.** Les éditeurs retirent régulièrement des modèles : Claude Sonnet 4.5 est retiré de l'API le 30 novembre 2026 ; Mistral a retiré `mistral-small-2506` le 31 juillet 2026 et annonce la fin de `mistral-medium-3-5` au 30 avril 2027 ; OpenAI ferme progressivement sa plateforme de fine-tuning aux nouveaux utilisateurs (nov. 2026). Un prompt réglé au millimètre sur un modèle peut se comporter différemment sur son successeur. Parade : conserver un jeu de tests (20 à 50 cas réels avec la réponse attendue, voir L049 pour la méthode) et le rejouer à chaque migration.

**Hausse de prix.** Google a annoncé un doublement des tarifs de Gemini 4 Argon au 1er décembre 2026 et de Gemini 3.8 Flash au 1er janvier 2027. Le DGX Spark est passé de 3 999 $ à ~6 950 $ en un an. Parade : ne jamais lier un processus critique à un seul fournisseur ; inscrire un plafond de dépense (*spend cap*) et des alertes dès le premier jour.

**Dépendance technique (*lock-in*).** Les fonctions propriétaires (projets, GPT personnalisés, connecteurs maison) ne s'exportent pas. Parade : garder vos prompts, vos documents de référence et vos jeux de tests **hors** de l'outil, dans un dépôt versionné. Côté API, la plupart des fournisseurs et tous les serveurs locaux (Ollama, LM Studio, vLLM) exposent une API « compatible OpenAI » : écrire ses workflows contre cette interface rend le changement de modèle presque indolore.

**Fuite ou mauvais usage des données.** Un salarié qui colle un fichier client dans un chat grand public, un connecteur qui indexe un dossier partagé entier, un agent qui a trop de droits (« Excessive Agency », n° 3 du Top 10 OWASP LLM 2026). Parade : la politique IA de la leçon suivante, et des comptes professionnels administrés plutôt que des comptes personnels.

| Critère de réversibilité | SaaS | API | Local |
|---|---|---|---|
| Export des données | Variable selon l'éditeur | Vous détenez tout | Vous détenez tout |
| Changement de modèle | Imposé par l'éditeur | Un paramètre dans le code | Un téléchargement |
| Coût de sortie typique | Faible à moyen | Faible si API compatible OpenAI | Moyen (matériel à amortir) |
| Risque de disparition de l'offre | Moyen | Moyen | Nul (poids téléchargés), hors licence |

> 💡 **À retenir** — La réversibilité ne se décrète pas le jour du départ : elle se construit le jour de l'arrivée, en gardant prompts, jeux de tests et données hors de l'outil.

## 6. La grille de décision en un schéma

```
Les données peuvent-elles sortir de l'entreprise ?
├── NON ──────────────────────────────► LOCAL (ou GPU loué chez un hébergeur
│                                        européen sous contrat, après analyse L063)
└── OUI (ou oui avec contrat entreprise)
    │
    L'IA doit-elle être intégrée dans un processus (n8n, code) ?
    ├── NON (usage conversationnel) ──► SaaS, offre entreprise administrée
    │                                    (si > 15-20 sièges et compétences serveur : comparer
    │                                     avec API + interface interne type Open WebUI)
    └── OUI
        │
        Volume élevé et régulier ET compétences internes ?
        ├── NON ──────────────────────► API, petit modèle d'abord (Haiku, Small, Flash),
        │                                 Batch et cache, plafond de dépense
        └── OUI ──────────────────────► Comparer API vs local avec le calculateur TCO ;
                                         exiger un jeu de tests et un plan de sortie
```

Cette grille sera votre livrable dans l'étude de cas du module. Elle n'est pas gravée : si votre entreprise a un critère propre (par exemple l'empreinte carbone, que le référentiel RS7232 de CCI France inclut dans « analyser les possibilités »), ajoutez-le en question 8.

## 🧪 Exercice pratique

**Consigne.** Une agence immobilière de 25 personnes veut (a) donner un assistant de rédaction à tous les salariés, (b) extraire automatiquement les informations des 3 000 diagnostics techniques PDF qu'elle reçoit chaque mois (environ 6 000 tokens chacun), (c) rester conforme : les diagnostics contiennent des adresses et des noms de propriétaires. Personne en interne ne sait administrer un serveur, mais l'assistante de direction maîtrise n8n depuis le module 8.

Produisez un document d'une page comportant : la réponse aux sept critères pour chacun des deux besoins ; un TCO sur 3 ans pour deux options par besoin (adaptez `tco.py`) ; une recommandation finale ; un paragraphe « plan de sortie ».

**Critères de réussite.**
- Les besoins (a) et (b) sont traités séparément et peuvent aboutir à des modes différents.
- Les tokens sont comptés (entrée **et** sortie) et la source des tarifs est citée avec la date.
- Le temps humain et la formation apparaissent dans le TCO.
- La recommandation cite explicitement le critère qui a tranché.

<details>
<summary>Pistes de corrigé</summary>

- (a) Usage conversationnel, pas d'intégration, données courantes : SaaS entreprise administré. À 25 sièges, l'option API + Open WebUI serait moins chère sur le papier (≈ 17 600 € contre ≈ 24 100 € de TCO hors formation, avec H = 25 €), mais l'absence de compétences serveur (critère 5) tranche pour le SaaS, sauf à sous-traiter l'hébergement de l'interface.
- (b) 3 000 × 6 000 = 18 M tokens entrée et ~1,5 M sortie par mois : Haiku 5.5 ≈ 2,55 $/mois, Sonnet 5.5 ≈ 51 $/mois. Données personnelles mais non sensibles : API acceptable avec contrat entreprise, clauses de non-entraînement et de sous-traitance (L063), pseudonymisation des noms avant envoi si possible. Le local n'est pas justifié : aucune compétence serveur et volume faible.
- Plan de sortie : prompts et jeu de 50 diagnostics de test dans un dépôt ; workflow n8n écrit contre l'interface compatible OpenAI ; export trimestriel des conversations SaaS.
</details>

## ✅ Auto-évaluation express

1. Pourquoi l'API coûte-t-elle trois fois moins que le SaaS en tokens dans le scénario A, et pourtant le SaaS l'emporte au TCO ?
2. Dans le scénario B, qu'est-ce qui a le plus d'impact sur la facture : changer de fournisseur ou changer de taille de modèle ?
3. Citez deux mesures prises **le jour de l'arrivée** qui rendent un départ moins coûteux.

*Réponses : 1. Parce que le TCO inclut le temps humain d'administration (1 jour par trimestre pour l'option API contre une demi-journée par an pour le SaaS) ; à 12 personnes, ce poste dépasse l'économie de tokens. 2. La taille du modèle : Sonnet coûte vingt fois Haiku chez le même fournisseur, alors que Haiku, Small 4 et Flash sont dans un rapport de 1 à 7. 3. Conserver prompts, documents et jeux de tests hors de l'outil ; écrire les intégrations contre une API compatible OpenAI ; fixer un plafond de dépense ; prévoir un export régulier.*

## 📚 Pour aller plus loin

- [Claude Academy — Deploying Claude Enterprise with confidence](https://academy.claude.com/courses/deploying-claude-enterprise-with-confidence) 🇬🇧 — les cinq décisions d'un déploiement SaaS entreprise : organisation, groupes, accès, gouvernance des personnalisations, plafonds de dépense.
- [Anthropic — Model deprecations](https://platform.claude.com/docs/en/about-claude/model-deprecations) 🇬🇧 — calendrier des retraits de modèles, à surveiller pour tout processus en production.
- [Anthropic — Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model) 🇬🇧 — méthode officielle pour arbitrer coût, vitesse et intelligence.
- [Mistral — Model lifecycle](https://docs.mistral.ai/inference/model-lifecycle) 🇬🇧 — politique de dépréciation du fournisseur français.
- [IntuitionLabs — NVIDIA DGX Spark review](https://intuitionlabs.ai/articles/nvidia-dgx-spark-review) 🇬🇧 — fiche complète, prix et vitesses mesurées de la machine « capacité » du local.
