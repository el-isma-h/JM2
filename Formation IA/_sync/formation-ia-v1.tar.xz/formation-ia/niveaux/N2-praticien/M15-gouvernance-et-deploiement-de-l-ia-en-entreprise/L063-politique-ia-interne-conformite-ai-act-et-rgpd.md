---
id: L063
module: M15
level: N2
title: "Politique IA interne, conformité AI Act et RGPD"
minutes: 60
objectives:
  - "Identifier le rôle de son organisation au sens de l'AI Act (fournisseur ou déployeur) et les obligations qui en découlent selon le niveau de risque et le calendrier d'application"
  - "Appliquer le RGPD aux usages de l'IA : qualification des acteurs, base légale, minimisation, transferts, analyse d'impact (AIPD)"
  - "Construire une politique IA interne complète : charte, classification des données, registre des usages, procédure d'achat, gestion des incidents"
  - "Évaluer un fournisseur d'IA à l'aide d'une liste de questions contractuelles et techniques"
skills: ["C2.6", "C1.6"]
sources:
  - { title: "EUR-Lex — Règlement (UE) 2024/1689 (AI Act)", url: "https://eur-lex.europa.eu/eli/reg/2024/1689/oj", lang: "fr" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
  - { title: "CNIL — Développement des systèmes d'IA : les recommandations pour respecter le RGPD", url: "https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd", lang: "fr" }
  - { title: "CNIL — Finalisation des recommandations sur le développement des systèmes d'IA", url: "https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia", lang: "fr" }
  - { title: "donneespersonnelles.fr — Omnibus numérique IA : nouveau calendrier", url: "https://donneespersonnelles.fr/omnibus-numerique-ia", lang: "fr" }
  - { title: "CMS Law — European Commission clarifies AI literacy requirements", url: "https://cms.law/en/int/legal-updates/european-commission-clarifies-literacy-requirements-under-the-ai-act", lang: "en" }
  - { title: "Sénat — Réponse ministérielle sur les deepfakes et l'AI Act (05/02/2026)", url: "https://www.senat.fr/questions/base/2025/qSEQ251006478.html", lang: "fr" }
  - { title: "Anthropic — API and data retention", url: "https://platform.claude.com/docs/en/manage-claude/api-and-data-retention", lang: "en" }
  - { title: "NIST — AI Risk Management Framework", url: "https://www.nist.gov/itl/ai-risk-management-framework", lang: "en" }
---

# Politique IA interne, conformité AI Act et RGPD

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 15

## 🎯 Ce que vous saurez faire
- Dire en une phrase si votre entreprise est « fournisseur » ou « déployeur » au sens de l'AI Act, et ce que cela change.
- Classer n'importe quel usage IA de l'entreprise dans une case du calendrier réglementaire (interdit, haut risque, transparence, minimal) avec les bonnes dates.
- Appliquer les réflexes RGPD à un prompt, à un connecteur, à un agent : qui est responsable, sur quelle base, avec quelles données, vers où.
- Livrer les six pièces d'une politique IA : charte, classification des données, registre des usages, procédure d'achat, procédure d'incident, plan de formation (ce dernier en L064).

## 1. Pourquoi une politique IA, et pourquoi maintenant

Le plan « Osez l'IA » (juillet 2025) partait d'un constat : seulement 8 % des TPE et 13 % des PME françaises utilisaient une IA « clé en main ». Mais ce chiffre mesure l'usage **officiel**. Dans les faits, une part des salariés utilise déjà ChatGPT, Claude ou Gemini sur un compte personnel, avec des données de l'entreprise : c'est l'« IA fantôme » (*shadow AI*). Une politique IA ne sert pas à interdire ; elle sert à transformer un usage caché et risqué en usage visible et encadré.

Trois textes structurent le sujet en France (nov. 2026) :

- le **RGPD** (2016, applicable depuis 2018), qui n'a pas changé mais que la CNIL a détaillé pour l'IA dans **18 fiches pratiques** finalisées en juillet 2025 ;
- l'**AI Act** (règlement (UE) 2024/1689), entré en vigueur le 1er août 2024, appliqué par étapes ;
- la **loi SREN** (2024), qui punit notamment les *deepfakes* d'une personne sans son consentement (jusqu'à 2 ans de prison et 45 000 € d'amende, art. 226-8 du code pénal).

> 💡 **À retenir** — Le message de la CNIL est explicite : « l'idée reçue selon laquelle le RGPD empêcherait l'innovation en IA est fausse ». Les règles existent pour permettre l'usage, à condition de le documenter.

## 2. AI Act : quel est votre rôle ?

L'AI Act distingue des **rôles**, et chaque rôle a ses obligations.

| Rôle | Définition simplifiée | Exemples |
|---|---|---|
| **Fournisseur** (*provider*) | Développe un système d'IA (ou le fait développer) et le met sur le marché **sous son nom** | Anthropic, OpenAI, Mistral ; mais aussi une PME qui vend un logiciel « IA de tri de CV » à ses clients |
| **Déployeur** (*deployer*) | Utilise un système d'IA sous sa propre autorité, dans un cadre professionnel | Le cabinet comptable qui abonne ses salariés à Claude ; l'e-commerçant qui trie ses e-mails avec n8n + Haiku |
| Importateur / distributeur | Met sur le marché européen un système d'un fournisseur tiers | Revendeur, intégrateur |
| Fournisseur de **modèle à usage général** (GPAI) | Entraîne un modèle de fondation | Les éditeurs de LLM, soumis à l'art. 53 (politique droit d'auteur, résumé public des données d'entraînement) depuis le 2 août 2025 |

Dans la quasi-totalité des cas vus dans cette formation, **vous êtes déployeur**. Attention au basculement : si vous modifiez substantiellement un système, si vous l'utilisez pour une finalité à haut risque que le fournisseur n'avait pas prévue, ou si vous commercialisez sous votre marque un outil construit sur une API, vous pouvez devenir fournisseur, avec les obligations lourdes qui vont avec (documentation technique, gestion de la qualité, marquage CE pour le haut risque). Une PME qui vend « notre IA de recrutement » bâtie sur n8n et une API s'engage sur ce terrain : faites-le en connaissance de cause.

## 3. Le calendrier et les quatre niveaux de risque

L'AI Act classe les **usages**, pas les technologies. Le même modèle peut être à risque minimal dans un cas et à haut risque dans un autre.

| Niveau | Exemples | Obligations du déployeur | Applicable depuis |
|---|---|---|---|
| **Inacceptable** (art. 5) | Notation sociale, manipulation subliminale, reconnaissance des émotions au travail (hors sécurité/santé), catégorisation biométrique sensible | Interdit | 2 février 2025 |
| **Haut risque** (annexe III) | Recrutement, évaluation et promotion des salariés, accès au crédit, éducation, santé, justice | Utiliser selon la notice du fournisseur, assurer un **contrôle humain** par des personnes formées, vérifier la pertinence des données d'entrée, conserver les journaux, **informer les salariés et leurs représentants** avant mise en service, réaliser une AIPD | **Reporté au 2 décembre 2027** par l'omnibus numérique (règlement (UE) 2026/1744 selon donneespersonnelles.fr ; à confirmer sur EUR-Lex) |
| **Transparence** (art. 50) | Chatbots, contenus générés, *deepfakes* | Informer l'utilisateur qu'il parle à une IA ; marquer les contenus synthétiques ; signaler les *deepfakes* | 2 août 2026 (art. 50(2) différé au 2 décembre 2026 pour les systèmes déjà sur le marché) |
| **Minimal** | Rédaction assistée, résumé, tri d'e-mails, code | Aucune obligation spécifique, **sauf l'art. 4** | — |

Et l'**article 4**, transversal, applicable depuis le **2 février 2025** à tout déployeur : garantir « dans toute la mesure du possible » un niveau suffisant de **maîtrise de l'IA** (*AI literacy*) de son personnel. Pas d'examen imposé, des mesures proportionnées ; la Commission a précisé (mai 2025) qu'un simple manuel ou un message automatique serait « probablement insuffisant ». La leçon L064 en fait un plan de formation.

Côté sanctions, le chapitre XII s'applique depuis le 2 août 2026 : jusqu'à 35 M€ ou 7 % du chiffre d'affaires mondial pour les pratiques interdites, 15 M€ ou 3 % pour les autres manquements (dont l'art. 50, confirmé par une réponse ministérielle au Sénat en février 2026), 7,5 M€ ou 1 % pour des informations inexactes. L'art. 4 n'a pas d'amende propre, mais il devient le **standard de diligence** qu'un juge regardera en cas de dommage.

> ⚠️ **Piège fréquent** — « Le haut risque est reporté, donc on verra en 2027. » Faux à deux titres : d'une part l'art. 4 et l'art. 5 s'appliquent déjà ; d'autre part un outil de tri de CV traite des données personnelles **aujourd'hui** sous le RGPD, AIPD comprise. Le report concerne les obligations spécifiques de l'AI Act, pas le droit existant.

> 🔗 **Documentation officielle** — [Règlement (UE) 2024/1689 sur EUR-Lex](https://eur-lex.europa.eu/eli/reg/2024/1689/oj) (texte consolidé, en français) ; [calendrier après l'omnibus numérique](https://donneespersonnelles.fr/omnibus-numerique-ia).

## 4. RGPD : les cinq réflexes appliqués à l'IA

Le RGPD s'applique dès qu'un prompt, un document joint ou une base de connaissances contient des **données personnelles** (nom, e-mail, adresse, voix, photo…). Cinq réflexes, tirés des fiches CNIL.

1. **Qui est responsable ?** L'entreprise qui décide de l'usage est **responsable de traitement** ; l'éditeur SaaS ou le fournisseur d'API est son **sous-traitant** (art. 28) et doit signer un contrat précisant finalités, durée de conservation, sous-traitants ultérieurs, localisation. Un salarié qui utilise un compte personnel n'a aucun contrat : l'entreprise est responsable sans aucune garantie. C'est le premier argument pour des comptes professionnels administrés.
2. **Sur quelle base légale ?** Dans le secteur privé, l'**intérêt légitime** est la base usuelle (fiche 8 CNIL), à trois conditions : intérêt réel, nécessité du traitement, équilibre avec les droits des personnes. Le consentement est rarement la bonne base en contexte salarié (déséquilibre).
3. **Quelles données, combien de temps ?** Minimisation : n'envoyez que ce qui est nécessaire ; pseudonymisez (remplacer « Mme Martin, 12 rue X » par « Client 0427 ») quand le modèle n'a pas besoin de l'identité. Vérifiez la **durée de conservation** chez le fournisseur : les pages « data retention » des éditeurs précisent les délais standard et les options « zéro rétention » des offres entreprise.
4. **Vers où ?** Un transfert hors UE exige un cadre (clauses contractuelles types, décision d'adéquation). Les offres de résidence des données en Europe, ou l'hébergement local (L062), simplifient la question.
5. **Faut-il une AIPD ?** L'**analyse d'impact relative à la protection des données** (art. 35 RGPD, fiche 5 CNIL) est obligatoire quand le traitement présente un risque élevé : la CNIL la considère **de fait obligatoire** pour tout système à haut risque au sens de l'AI Act, et fortement recommandée pour les autres usages touchant des salariés ou des clients à grande échelle. Une AIPD décrit le traitement, évalue nécessité et proportionnalité, cartographie les risques et les mesures. Elle se fait **avant** le déploiement, pas après l'incident.

Les droits des personnes (accès, rectification, opposition, effacement) s'exercent aussi sur les données passées dans un système d'IA, et la CNIL rappelle qu'ils peuvent concerner le modèle lui-même s'il n'est pas anonyme.

> 🔗 **Documentation officielle** — [CNIL — les 18 fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) ; [synthèse des recommandations CNIL](https://www.cnil.fr/fr/developpement-des-systemes-dia-les-recommandations-de-la-cnil-pour-respecter-le-rgpd) ; [Anthropic — API and data retention](https://platform.claude.com/docs/en/manage-claude/api-and-data-retention) 🇬🇧 (exemple de page à lire chez tout fournisseur).

## 5. Classifier les données : la pierre angulaire

Tout le reste de la politique repose sur une classification simple, que chaque salarié peut appliquer en trois secondes.

| Niveau | Exemples | Compte grand public (gratuit / perso) | SaaS entreprise sous contrat | API sous contrat (clauses art. 28) | Local |
|---|---|---|---|---|---|
| **1. Public** | Site web, communiqués, fiches produits | ✅ | ✅ | ✅ | ✅ |
| **2. Interne** | Procédures, comptes rendus sans noms, brouillons | ❌ | ✅ | ✅ | ✅ |
| **3. Confidentiel** | Données clients et salariés, contrats, chiffres non publiés | ❌ | ✅ si résidence UE et non-entraînement ; pseudonymiser | ✅ mêmes conditions | ✅ |
| **4. Réglementé / sensible** | Santé, secret professionnel, données bancaires, art. 9 RGPD, secrets de fabrication | ❌ | ❌ sauf analyse juridique et AIPD | ❌ sauf analyse juridique et AIPD | ✅ (option par défaut) |

Imprimez ce tableau. Collez-le près des écrans. Il vaut mieux qu'un document de 40 pages que personne ne lit.

## 6. Le registre des usages IA

L'art. 30 du RGPD impose déjà un **registre des traitements**. Le registre des usages IA en est le prolongement, et c'est la pièce que les autorités et les auditeurs demanderont en premier ; la Commission la recommande explicitement au titre de l'art. 4 (inventaire des systèmes, politique interne, plan de formation, trace des formations par salarié).

| Colonne | Exemple |
|---|---|
| Identifiant / nom de l'usage | U-07 « Tri des e-mails SAV » |
| Finalité | Classer les e-mails entrants et proposer une réponse |
| Système et fournisseur | n8n + Claude Haiku 5.5 (API, contrat entreprise) |
| Mode (L062) | API |
| Niveau de données (section 5) | 3 — confidentiel (e-mails clients), pseudonymisé |
| Niveau de risque AI Act | Minimal + transparence (réponse signée « rédigée avec l'aide d'une IA ») |
| Base légale RGPD / AIPD | Intérêt légitime ; AIPD non requise, note de risque jointe |
| Responsable métier / référent IA | Responsable SAV / DPO |
| Contrôle humain | Validation humaine avant envoi des réponses « réclamation » |
| Jeu de tests et date de dernière évaluation | 200 e-mails, 94 % de classification correcte, 12/10/2026 |
| Date de revue | Trimestrielle |

Un registre vivant de 15 lignes vaut mieux qu'un registre parfait jamais mis à jour : prévoyez la revue dans le calendrier du référent IA.

## 7. La procédure d'achat : dix questions au fournisseur

Avant de signer un abonnement, une API ou un matériel, le référent IA et l'acheteur posent dix questions. Les réponses vont dans le registre.

1. Mes données servent-elles à entraîner vos modèles ? Par défaut ? Puis-je refuser contractuellement ?
2. Quelle est la durée de conservation des prompts et des sorties ? Existe-t-il une option « zéro rétention » ?
3. Où sont hébergées et traitées les données ? Puis-je imposer l'Union européenne ?
4. Quel contrat de sous-traitance (art. 28) et quelles clauses pour les transferts hors UE ?
5. Quels sous-traitants ultérieurs (hébergeur, support) ?
6. Quelles certifications de sécurité (ISO 27001, SOC 2) et quelle procédure de notification d'incident ?
7. Quelle administration : SSO, groupes, droits, **plafond de dépense**, journal d'audit, export des données ?
8. Quelle politique de dépréciation des modèles et quel préavis (L062) ?
9. Quelles conditions d'usage (politique d'usage acceptable, usages interdits) et comment m'informez-vous des obligations de transparence art. 50 ?
10. Que se passe-t-il à la résiliation : export, suppression, délai ?

Un fournisseur qui ne répond pas aux questions 1 à 4 par écrit ne passe pas en niveau 3 de données. Point.

## 8. Assembler la politique IA

Une politique IA complète tient en six pièces, et un document de pilotage d'une page qui les relie :

```
POLITIQUE IA DE L'ENTREPRISE
├── 1. Charte d'usage (annexe ci-dessous)            ← signée par chaque salarié
├── 2. Classification des données (section 5)         ← affichée
├── 3. Registre des usages IA (section 6)             ← tenu par le référent IA
├── 4. Procédure d'achat / dix questions (section 7)  ← achats + référent IA + DPO
├── 5. Procédure d'incident                           ← fuite, sortie erronée, prompt injection
└── 6. Plan de formation art. 4 (L064)                ← RH
```

La **procédure d'incident** tient en quatre lignes : qui prévenir (référent IA, DPO, DSI), dans quel délai (immédiatement pour une fuite de données personnelles : la notification CNIL doit intervenir sous 72 heures), quoi conserver (prompt, réponse, horodatage), et un registre des incidents relu chaque trimestre. Pour structurer la gestion des risques à plus grande échelle, le cadre **NIST AI RMF** (Govern, Map, Measure, Manage) et la norme **ISO/IEC 42001** (système de management de l'IA) sont les références internationales ; une PME n'a pas besoin de les certifier, mais s'en inspirer donne un vocabulaire commun avec les grands donneurs d'ordre.

Enfin, le droit du travail s'invite : l'introduction d'un outil d'IA qui modifie les conditions de travail ou permet un contrôle de l'activité suppose l'**information-consultation du CSE** quand il existe, et l'AI Act impose d'informer salariés et représentants avant tout système à haut risque. Une politique IA présentée au CSE avant déploiement évite bien des conflits.

## Annexe — Modèle de charte d'usage de l'IA (à adapter)

> **Charte d'usage des outils d'intelligence artificielle — [Nom de l'entreprise] — version du [date]**
>
> **Art. 1 — Objet.** La présente charte fixe les règles d'utilisation des outils d'IA générative (assistants conversationnels, API, agents, modèles locaux) par les salariés, prestataires et stagiaires. Elle complète la charte informatique et le règlement intérieur.
>
> **Art. 2 — Outils autorisés.** Seuls les outils listés au registre des usages IA, fournis sur un compte professionnel administré, sont autorisés pour des données de niveau 2 et plus. Les comptes personnels sont limités aux données publiques (niveau 1).
>
> **Art. 3 — Données.** Chaque utilisateur applique la classification à quatre niveaux affichée en annexe. Les données de niveau 4 ne sont traitées que par les systèmes locaux ou expressément validés par le DPO. Les données personnelles sont pseudonymisées chaque fois que l'identité n'est pas nécessaire à la tâche.
>
> **Art. 4 — Responsabilité humaine.** Toute production d'IA est relue, vérifiée et assumée par un humain avant usage externe. L'IA ne prend aucune décision produisant des effets juridiques sur une personne (recrutement, évaluation, sanction, crédit) sans décision humaine documentée.
>
> **Art. 5 — Transparence.** Les contenus générés diffusés à l'extérieur sont signalés quand la loi ou l'usage l'exige (art. 50 AI Act) ; les interlocuteurs d'un chatbot sont informés qu'ils dialoguent avec une IA. Aucune image, voix ou vidéo d'une personne réelle n'est générée sans son accord écrit.
>
> **Art. 6 — Propriété intellectuelle.** Les utilisateurs ne soumettent pas de contenus protégés dont l'entreprise ne détient pas les droits ; la part humaine des créations assistées est documentée.
>
> **Art. 7 — Sécurité.** Les clés API sont stockées dans un gestionnaire de secrets, jamais dans un document ou un message. Les agents disposent du minimum de droits nécessaires et d'un plafond de dépense. Tout comportement anormal est signalé selon la procédure d'incident.
>
> **Art. 8 — Formation.** Chaque utilisateur suit la formation initiale et les mises à jour prévues au plan de formation (art. 4 AI Act) ; la participation est tracée.
>
> **Art. 9 — Contrôle et sanctions.** Le respect de la charte peut être vérifié par les journaux d'administration, dans le respect du droit du travail et après information du CSE. Les manquements relèvent du règlement intérieur.
>
> **Art. 10 — Révision.** La charte est revue au moins une fois par an par le référent IA et le DPO, et à chaque évolution réglementaire majeure.
>
> Lu et approuvé le __/__/____ — Signature

## 🧪 Exercice pratique

**Consigne.** Reprenez l'agence immobilière de l'exercice L062 (25 salariés, assistant de rédaction pour tous, extraction automatique de 3 000 diagnostics PDF par mois, noms et adresses de propriétaires, une assistante de direction formée à n8n). Produisez : (1) le tableau de classification adapté à l'agence avec trois exemples par niveau ; (2) les deux lignes du registre des usages ; (3) la charte en adaptant au moins cinq articles du modèle ; (4) une note de dix lignes indiquant si une AIPD est nécessaire pour l'extraction des diagnostics, et pourquoi.

**Critères de réussite.**
- Le rôle AI Act (déployeur) et le niveau de risque de chaque usage sont nommés, avec la date d'application correspondante.
- La base légale RGPD est indiquée et le sous-traitant identifié.
- La classification distingue bien les données des propriétaires (niveau 3) des diagnostics anonymisés (niveau 2).
- La charte contient une règle de transparence envers les clients et une règle sur les comptes personnels.

<details>
<summary>Pistes de corrigé</summary>

- Usage « assistant de rédaction » : risque minimal, art. 4 applicable, SaaS entreprise, données de niveau 1-2 (niveau 3 uniquement avec pseudonymisation).
- Usage « extraction de diagnostics » : risque minimal (pas d'annexe III), API sous contrat art. 28, intérêt légitime, données de niveau 3. AIPD : non obligatoire au sens strict (pas de haut risque, pas de données sensibles), mais une **note de risque** documentée est recommandée compte tenu du volume (36 000 documents par an) ; elle deviendrait obligatoire si l'agence croisait ces données pour profiler ou noter les propriétaires.
- Transparence : les courriers générés et envoyés aux clients sont relus et signés par un humain ; un éventuel chatbot sur le site annonce sa nature.
</details>

## ✅ Auto-évaluation express

1. Une PME utilise Claude Team pour rédiger ses devis. Est-elle fournisseur ou déployeur ? Quelle est sa principale obligation déjà applicable ?
2. Quelle différence entre « le haut risque est reporté au 2 décembre 2027 » et « je peux trier des CV avec une IA sans précaution jusque-là » ?
3. Citez les trois questions du fournisseur sans réponse écrite desquelles aucune donnée de niveau 3 ne doit lui être confiée.

*Réponses : 1. Déployeur ; l'art. 4 (maîtrise de l'IA du personnel), applicable depuis le 2 février 2025, et le RGPD si des données personnelles figurent dans les devis. 2. Le report ne concerne que les obligations spécifiques de l'AI Act pour l'annexe III ; le tri de CV reste un traitement de données personnelles à risque élevé sous le RGPD (AIPD, information des candidats, décision humaine), et l'art. 5 interdit déjà certaines pratiques comme la reconnaissance des émotions. 3. Entraînement sur mes données, durée de conservation, localisation / transferts hors UE (et le contrat de sous-traitance art. 28 qui les formalise).*

## 📚 Pour aller plus loin

- [CNIL — Finalisation des recommandations sur le développement des systèmes d'IA](https://cnil.fr/fr/ia-finalisation-recommandations-developpement-des-systemes-ia) — le communiqué qui présente les 18 fiches et la liste de vérification.
- [CMS Law — La Commission clarifie l'obligation d'AI literacy (art. 4)](https://cms.law/en/int/legal-updates/european-commission-clarifies-literacy-requirements-under-the-ai-act) 🇬🇧 — ce que « mesures proportionnées » veut dire concrètement.
- [RTR (Autriche) — AI literacy, art. 4](https://www.rtr.at/rtr/service/ki-servicestelle/ai-act/ai_literacy.en.html) 🇬🇧 — fiche d'une autorité nationale sur l'obligation de maîtrise de l'IA.
- [NIST — AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework) 🇬🇧 — le cadre Govern / Map / Measure / Manage et son profil IA générative.
- [OWASP GenAI Security Project](https://genai.owasp.org/) 🇬🇧 — Top 10 LLM 2026 et Top 10 agentique, pour la procédure d'incident.
- [Claude Academy — Deploying Claude Enterprise with confidence](https://academy.claude.com/courses/deploying-claude-enterprise-with-confidence) 🇬🇧 — gouvernance des personnalisations et plafonds de dépense, côté administrateur.
