---
id: L055
module: M13
level: N2
title: "Analyser un fichier CSV / Excel avec ChatGPT et Claude"
minutes: 60
objectives:
  - "Préparer un fichier tabulaire (CSV / Excel) avant de le confier à un assistant IA : structure, en-têtes, données sensibles"
  - "Rédiger un prompt d'analyse précis (objectif, colonnes, unités, format de sortie, demande de code) avec ChatGPT ou Claude"
  - "Vérifier systématiquement les chiffres produits par l'IA (recalcul, cohérence, code exécuté) et repérer un chiffre halluciné ou un arrondi trompeur"
  - "Expliquer la différence entre une réponse « de tête » du modèle et un calcul réellement exécuté dans un bac à sable"
skills: ["C2.4"]
sources:
  - { title: "Claude Platform — Files API", url: "https://platform.claude.com/docs/en/build-with-claude/files", lang: "en" }
  - { title: "Claude Platform — Code execution tool", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool", lang: "en" }
  - { title: "Claude Platform — Agent Skills overview (skills xlsx, docx, pptx, pdf)", url: "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview", lang: "en" }
  - { title: "Claude Platform — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "OpenAI — API Quickstart (fichiers, code interpreter)", url: "https://developers.openai.com/api/docs/quickstart", lang: "en" }
  - { title: "Claude Academy — Claude 101", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "CNIL — Les fiches pratiques IA", url: "https://cnil.fr/fr/les-fiches-pratiques-ia", lang: "fr" }
---

# Analyser un fichier CSV / Excel avec ChatGPT et Claude

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 13

## 🎯 Ce que vous saurez faire
- Préparer un export de ventes (CSV ou Excel) pour qu'un assistant IA le lise sans se tromper.
- Formuler une demande d'analyse qui précise l'objectif, les colonnes, les unités et le format attendu.
- Distinguer une réponse « calculée de tête » par le modèle d'un calcul réellement exécuté en Python dans un bac à sable (*sandbox*).
- Détecter un chiffre inventé, un arrondi trompeur ou une ligne oubliée (avoir, doublon) avec une procédure de vérification en quatre points.
- Réutiliser le jeu de données **Mobidesk** qui servira de fil rouge dans tout le module.

## 1. Le jeu de données du module : les ventes de Mobidesk

Mobidesk SAS est une PME fictive de Nantes qui distribue du mobilier et des fournitures de bureau aux professionnels. Trois commerciaux couvrent trois régions. Le contrôleur de gestion exporte chaque semestre les lignes de commande depuis l'outil de facturation. Voici l'export du premier semestre 2026, **24 lignes**, que vous copierez dans un fichier texte nommé `ventes_mobidesk_2026_S1.csv` (encodage UTF-8, séparateur virgule, point décimal) :

```csv
date,commande,commercial,region,categorie,produit,quantite,prix_unitaire_ht,montant_ht
2026-01-06,C-1001,Aïcha Benali,Île-de-France,Mobilier,Bureau Oslo,4,349.00,1396.00
2026-01-13,C-1002,Thomas Roussel,Auvergne-Rhône-Alpes,Éclairage,Lampe Halo,12,59.90,718.80
2026-01-20,C-1003,Léa Martin,Nouvelle-Aquitaine,Mobilier,Fauteuil Ergo+,3,289.00,867.00
2026-01-27,C-1004,Aïcha Benali,Île-de-France,Consommables,Pack papeterie,25,18.50,462.50
2026-02-03,C-1005,Thomas Roussel,Auvergne-Rhône-Alpes,Mobilier,Bureau Oslo,2,349.00,698.00
2026-02-10,C-1006,Léa Martin,Nouvelle-Aquitaine,Rangement,Caisson Nova,6,129.00,774.00
2026-02-17,C-1007,Aïcha Benali,Île-de-France,Mobilier,Fauteuil Ergo+,8,289.00,2312.00
2026-02-24,C-1008,Thomas Roussel,Auvergne-Rhône-Alpes,Consommables,Pack papeterie,40,18.50,740.00
2026-03-03,C-1009,Léa Martin,Nouvelle-Aquitaine,Éclairage,Lampe Halo,20,59.90,1198.00
2026-03-10,C-1010,Aïcha Benali,Île-de-France,Rangement,Caisson Nova,10,129.00,1290.00
2026-03-17,C-1011,Thomas Roussel,Auvergne-Rhône-Alpes,Mobilier,Fauteuil Ergo+,5,289.00,1445.00
2026-03-24,C-1012,Léa Martin,Nouvelle-Aquitaine,Mobilier,Bureau Oslo,6,349.00,2094.00
2026-04-07,C-1013,Aïcha Benali,Île-de-France,Éclairage,Lampe Halo,30,59.90,1797.00
2026-04-14,C-1014,Thomas Roussel,Auvergne-Rhône-Alpes,Rangement,Caisson Nova,4,129.00,516.00
2026-04-21,C-1015,Léa Martin,Nouvelle-Aquitaine,Consommables,Pack papeterie,60,18.50,1110.00
2026-04-28,C-1016,Aïcha Benali,Île-de-France,Mobilier,Bureau Oslo,-1,349.00,-349.00
2026-05-05,C-1017,Thomas Roussel,Auvergne-Rhône-Alpes,Mobilier,Fauteuil Ergo+,10,289.00,2890.00
2026-05-12,C-1018,Léa Martin,Nouvelle-Aquitaine,Rangement,Caisson Nova,8,129.00,1032.00
2026-05-19,C-1019,Aïcha Benali,Île-de-France,Mobilier,Fauteuil Ergo+,12,289.00,3468.00
2026-05-26,C-1020,Thomas Roussel,Auvergne-Rhône-Alpes,Éclairage,Lampe Halo,15,59.90,898.50
2026-06-02,C-1021,Léa Martin,Nouvelle-Aquitaine,Mobilier,Bureau Oslo,9,349.00,3141.00
2026-06-09,C-1022,Aïcha Benali,Île-de-France,Consommables,Pack papeterie,80,18.50,1480.00
2026-06-16,C-1023,Thomas Roussel,Auvergne-Rhône-Alpes,Mobilier,Bureau Oslo,7,349.00,2443.00
2026-06-23,C-1024,Léa Martin,Nouvelle-Aquitaine,Éclairage,Lampe Halo,18,59.90,1078.20
```

Regardez la ligne `C-1016` : une quantité de **−1** et un montant de **−349,00 €**. C'est un avoir (un bureau retourné par le client). Ce détail, parfaitement banal dans la vraie vie, est le premier piège que nous tendrons aux assistants IA : un modèle pressé l'ignore, le « corrige » ou le compte en positif.

Les **valeurs de référence** que vous devez retrouver tout au long du module (calculées à la main, vous les revérifierez vous-même dans l'exercice) :

| Indicateur | Valeur exacte |
|---|---|
| Chiffre d'affaires HT total (24 lignes, avoir compris) | **33 500,00 €** |
| CA par commercial | Aïcha Benali 11 856,50 € · Léa Martin 11 294,20 € · Thomas Roussel 10 349,30 € |
| CA par catégorie | Mobilier 20 405,00 € · Éclairage 5 690,50 € · Consommables 3 792,50 € · Rangement 3 612,00 € |
| Meilleur mois / moins bon mois | Mai 8 288,50 € / Avril 3 074,00 € |
| Panier moyen (24 lignes) / (23 lignes hors avoir) | 1 395,83 € / 1 471,70 € |
| T1 → T2 | 13 995,30 € → 19 504,70 €, soit **+39,4 %** |

> 💡 **À retenir** — Un jeu de données que vous connaissez par cœur est le meilleur détecteur d'hallucination qui existe. Avant de confier un vrai fichier de 40 000 lignes à un assistant, entraînez-le (et entraînez-vous) sur un petit fichier dont vous connaissez les réponses.

## 2. Avant d'envoyer le fichier : la check-list de préparation

Un assistant IA lit un tableau comme vous liriez un tableau photocopié de travers : il devine. Plus vous enlevez de devinettes, plus les résultats sont fiables.

| Point à vérifier | Pourquoi | Que faire |
|---|---|---|
| **Une seule ligne d'en-têtes**, sans cellules fusionnées ni titre au-dessus | Le modèle (ou le code qu'il génère) prend la première ligne comme noms de colonnes | Dans Excel : supprimez les lignes de titre, « Convertir en tableau » (Ctrl + L) |
| **Noms de colonnes explicites** (`prix_unitaire_ht`, pas `PU`) | Le modèle devine l'unité et la nature des données à partir du nom | Renommez ; précisez HT/TTC, devise, unité |
| **Format des nombres** : point décimal, pas d'espace de milliers ni de symbole « € » dans les cellules | `1 396,00 €` est une chaîne de caractères, pas un nombre | Export CSV « international » ou nettoyage avant envoi |
| **Dates ISO** `AAAA-MM-JJ` | `06/01/2026` : 6 janvier ou 1er juin ? Les modèles anglophones penchent pour juin | Formatez les dates en ISO 8601 |
| **Données personnelles** et secrets d'affaires | Un export clients contient souvent noms, e-mails, adresses, marges | Pseudonymisez (client 001, 002…), supprimez les colonnes inutiles, vérifiez la politique d'usage de votre entreprise (module 7) |
| **Taille** | Au-delà de quelques milliers de lignes, le modèle ne doit plus « lire » mais **calculer** | Utilisez un outil qui exécute du code (section 3) |

Sur le dernier point, la CNIL rappelle dans ses fiches pratiques IA le principe de minimisation : on ne transmet que les données nécessaires à la finalité. Pour une analyse de ventes, le nom du commercial est utile ; l'IBAN du client ne l'est jamais.

> ⚠️ **Piège fréquent** — Le fichier Excel contient trois onglets, dont un onglet « Brouillon » avec des chiffres de l'an dernier. L'assistant analyse le premier onglet trouvé, ou pire, mélange les deux. Envoyez un fichier à un seul onglet, ou nommez explicitement l'onglet dans votre prompt.

## 3. Deux façons de « lire » un tableau : de tête ou en exécutant du code

C'est la notion la plus importante de la leçon. Quand vous collez 24 lignes dans une conversation et demandez « quel est le total ? », deux choses peuvent se passer :

1. **Le modèle répond « de tête »** : il additionne les montants comme vous le feriez mentalement, token après token. Sur 24 lignes, les modèles récents (Claude Sonnet 5.5, GPT-6.1 Sol, nov. 2026) s'en sortent très souvent, mais il n'y a **aucune garantie** : une retenue oubliée, un signe négatif sauté, et le total est faux de 698 € sans que rien ne le signale.
2. **Le modèle écrit et exécute un programme** (Python en général) dans un bac à sable, puis vous rapporte le résultat du programme. Le calcul est alors exact ; ce qui peut encore être faux, c'est la logique du programme (par exemple exclure l'avoir sans vous le dire).

Dans ChatGPT, cette seconde voie est la fonction d'analyse de données historiquement appelée *Advanced Data Analysis* ou *Code Interpreter* ; côté API, OpenAI expose l'outil `code_interpreter` dans la Responses API, facturé à la session (0,03 $ à 1,92 $ selon la mémoire allouée, nov. 2026). Dans Claude, l'application claude.ai analyse un fichier joint et produit des artefacts (tableaux, graphiques) ; la plateforme propose aux développeurs la **Files API** (fichiers jusqu'à 500 Mo, nov. 2026) et l'outil **code execution** (1 550 heures gratuites par mois puis 0,05 $/h, nov. 2026) ; des *skills* pré-construits `xlsx`, `docx`, `pptx`, `pdf` lui servent de modes d'emploi pour créer un classeur Excel avec formules ; sur le bureau, **Claude Cowork** travaille directement dans vos dossiers. Gemini propose aussi l'exécution de code et s'intègre dans Google Sheets.

Comment savoir quelle voie a été prise ? **Demandez-le** : « Montre-moi le code que tu as exécuté ». Un script et sa sortie, vous êtes dans le cas 2 ; une explication sans code, vous êtes dans le cas 1 et vous recalculez.

```
   Vous ──► "Total du CA ?" ──► Modèle
                                   │
              ┌────────────────────┴───────────────────┐
              ▼                                        ▼
     Réponse « de tête »                     Écrit un script Python
     (addition mentale, token par token)     ──► bac à sable l'exécute
     Risque : erreur silencieuse             ──► résultat retourné
     À faire : recalculer                    Risque : logique fausse
                                             À faire : lire le code
```

> 🔗 **Documentation officielle** — [Claude Platform — Code execution tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool) 🇬🇧 et [Files API](https://platform.claude.com/docs/en/build-with-claude/files) 🇬🇧 ; [OpenAI — Quickstart](https://developers.openai.com/api/docs/quickstart) 🇬🇧 (section « extend with files and tools »).

## 4. Le prompt d'analyse en cinq blocs

Un bon prompt d'analyse ressemble à une demande que vous feriez à un stagiaire en contrôle de gestion : contexte, données, question, format, garde-fous. Le guide *Prompting best practices* d'Anthropic insiste sur le même point : soyez explicite sur le résultat attendu et sur ce que le modèle doit faire en cas de doute.

```text
RÔLE : Tu es contrôleur de gestion dans une PME de distribution de mobilier de bureau.

DONNÉES : le fichier joint ventes_mobidesk_2026_S1.csv contient les lignes de commande
du 1er semestre 2026. Colonnes : date (ISO), commande, commercial, region, categorie,
produit, quantite (peut être négative = avoir), prix_unitaire_ht (€), montant_ht (€ HT).

TÂCHE : 1) CA HT total ; 2) CA par commercial et par mois (tableau croisé) ;
3) les trois constats les plus utiles pour la réunion commerciale de rentrée.

MÉTHODE : exécute du code pour tous les calculs et affiche-le. Ne modifie, n'exclus
et ne corrige aucune ligne sans me le signaler explicitement. Garde les avoirs.

FORMAT : montants en euros avec deux décimales et séparateur de milliers (ex. 11 856,50 €),
pourcentages à une décimale. Termine par la liste des hypothèses que tu as faites.
```

Décortiquons ce qui protège contre les erreurs :
- **« quantite peut être négative = avoir »** : vous retirez au modèle la tentation de « nettoyer » la ligne C-1016.
- **« exécute du code et affiche-le »** : vous forcez la voie 2 et vous obtenez la preuve.
- **« ne modifie aucune ligne sans me le signaler »** : la plupart des erreurs d'analyse IA ne sont pas des erreurs de calcul mais des décisions silencieuses (supprimer les doublons, remplacer les vides par zéro, convertir une date à l'envers).
- **« deux décimales »** : vous évitez les arrondis en cascade (section 5).
- **« liste des hypothèses »** : c'est là que vous découvrirez que le modèle a pris `region` pour la région du client alors que c'est celle du commercial.

🎮 **Défi** — Envoyez le même fichier avec le prompt minimal « Analyse ce fichier » puis avec le prompt en cinq blocs. Comparez : combien de chiffres identiques ? L'avoir a-t-il été traité de la même façon ?

## 5. Les trois pièges des chiffres : arrondi, hallucination, oubli

**L'arrondi qui dérive.** Demandez le CA de la Lampe Halo. Le prix est 59,90 €, 95 unités vendues : 5 690,50 €. Un modèle qui arrondit le prix à 60 € « pour simplifier » annonce 5 700 €, puis calcule une part de marché sur ce chiffre arrondi, puis une croissance sur cette part : l'erreur se propage. Règle : les arrondis se font **à la fin**, à l'affichage, jamais dans les étapes intermédiaires. Imposez-le dans le prompt.

**Le chiffre halluciné.** Il a trois visages. (1) *Le chiffre plausible* : « Le panier moyen est de 1 450 € » — c'est entre les deux vraies valeurs (1 395,83 € et 1 471,70 €), donc crédible, donc dangereux. (2) *Le chiffre sans source* : « Le secteur progresse de 4 % par an » — ce n'est pas dans votre fichier, c'est une connaissance générale du modèle, possiblement datée. (3) *Le chiffre recomposé* : le modèle vous donne le CA par commercial, puis un total qui n'est pas la somme des trois lignes qu'il vient d'écrire. Ce dernier cas est le plus facile à attraper : additionnez.

**L'oubli silencieux.** Dans une conversation longue, le modèle peut oublier une colonne ou n'analyser que les lignes qui « tiennent » dans sa mémoire de travail. Sur 24 lignes, aucun risque ; sur 3 000 lignes collées dans le chat, c'est fréquent. D'où la règle : au-delà d'une centaine de lignes, on **joint le fichier** et on exige du **code**.

> 💡 **À retenir** — Trois réflexes : *additionner* les sous-totaux pour vérifier le total ; *demander la provenance* de tout chiffre externe ; *imposer deux décimales* et des arrondis en fin de calcul.

## 6. La procédure de vérification en quatre points

Avant d'utiliser un chiffre produit par l'IA dans un e-mail, un tableau de bord ou une décision :

1. **Le total de contrôle.** Vous connaissez au moins un chiffre indépendant (total de la facturation, nombre de lignes, nombre de commerciaux). Il doit coïncider exactement. Pour Mobidesk : 24 lignes, 33 500,00 €, 3 commerciaux, 5 produits.
2. **La somme des parties.** CA par commercial : 11 856,50 + 11 294,20 + 10 349,30 = 33 500,00. Si la somme des sous-totaux n'est pas le total, l'une des lignes a été perdue ou comptée deux fois.
3. **Le cas extrême.** Repérez la ligne la plus bizarre (l'avoir, la plus grosse commande, un vide) et demandez : « Comment as-tu traité la commande C-1016 ? » La réponse vous dit si le modèle a lu le fichier ou l'a imaginé.
4. **La contre-épreuve dans le tableur.** Un `=SOMME.SI.ENS(I:I;C:C;"Léa Martin")` dans Excel ou Google Sheets prend dix secondes et vous donne 11 294,20 €. L'IA accélère ; le tableur arbitre.

Ce que cette procédure ne détecte pas : une erreur d'interprétation (confondre région du client et région du commercial). Contre celle-ci, un seul remède : la **liste des hypothèses** demandée dans le prompt, que vous relisez ligne par ligne.

## 7. Et avec un vrai fichier Excel de 40 000 lignes ?

Le principe ne change pas, mais la méthode s'adapte :
- **Joignez le fichier**, ne collez jamais le contenu. Dans claude.ai ou ChatGPT, le trombone ; dans Claude Cowork, donnez accès au dossier ; côté API, la Files API ou l'upload direct.
- **Demandez d'abord un profil** : « Décris le fichier : nombre de lignes, colonnes, types, valeurs manquantes, doublons sur `commande`, dates min et max. » Vous corrigez les problèmes de données avant de poser des questions.
- **Posez une question à la fois** et faites afficher le code à chaque fois. Un script de cinq lignes `pandas` se relit en trente secondes même sans savoir programmer : repérez `dropna` (supprime les vides), `drop_duplicates` (supprime les doublons), `abs(` (rend positif), `[df.quantite > 0]` (exclut les avoirs).
- **Demandez un classeur en sortie** : avec le skill `xlsx`, Claude renvoie un fichier Excel contenant les **formules** et non des valeurs figées, ce qui permet à votre expert-comptable de tracer chaque chiffre.

> ⚠️ **Piège fréquent** — Vous demandez « supprime les lignes bizarres » : le modèle supprime l'avoir, le gros client exceptionnel et la ligne dont la date est en 2025. Votre CA monte de 2 %, votre réunion commerciale repose sur un chiffre faux. Décrivez les règles de nettoyage vous-même, une par une.

## 🧪 Exercice pratique

**Consigne.** Créez le fichier `ventes_mobidesk_2026_S1.csv` à partir du bloc de la section 1. Puis, dans l'assistant de votre choix (Claude ou ChatGPT, en version gratuite ou payante) :

1. Envoyez le fichier avec le prompt en cinq blocs de la section 4 (adaptez-le à votre outil).
2. Relevez les six indicateurs du tableau de référence (section 1) tels que l'assistant les donne.
3. Posez la question piège : « Comment as-tu traité la commande C-1016 ? »
4. Dans Excel ou Google Sheets, recalculez le CA par commercial avec `SOMME.SI.ENS` et le total avec `SOMME`.
5. Rédigez cinq lignes : ce qui était juste, ce qui était faux ou arrondi, les hypothèses signalées par l'assistant.

**Critères de réussite.**
- Les six indicateurs coïncident au centime avec le tableau de référence (ou vous avez identifié et expliqué chaque écart).
- Vous avez obtenu et lu le code exécuté (ou constaté que l'outil n'en exécute pas, et conclu en conséquence).
- L'avoir C-1016 est explicitement mentionné dans la réponse de l'assistant.
- Votre contre-épreuve tableur est jointe (capture ou formules).

**Pistes de corrigé.** Le total doit être 33 500,00 € ; si vous obtenez 34 198,00 €, l'avoir a été compté en positif (33 500 + 2 × 349) ; si vous obtenez 33 849,00 €, il a été exclu. Un panier moyen de 1 395,83 € signifie 24 lignes incluses ; 1 471,70 € signifie que l'avoir a été écarté : les deux sont défendables, à condition que l'hypothèse soit annoncée. La croissance T1 → T2 doit être +39,4 % (19 504,70 / 13 995,30 − 1). Le meilleur commercial est Aïcha Benali malgré l'avoir qui lui est imputé.

## ✅ Auto-évaluation express

1. Vous collez 300 lignes de ventes dans le chat et demandez le total. Quel est le risque principal et comment le réduire ?
2. L'assistant annonce un CA par produit dont la somme fait 33 210 € alors que le total affiché est 33 500 €. Que s'est-il probablement passé ?
3. Pourquoi faut-il écrire « quantite peut être négative (avoir) » dans le prompt plutôt que de laisser le modèle le découvrir ?

**Réponses.** 1) Le modèle peut calculer « de tête » et se tromper silencieusement, ou n'analyser qu'une partie des lignes ; joignez le fichier et exigez du code exécuté et affiché. 2) Une ligne a été perdue ou exclue (ici 290 €, qui ne correspond à aucune ligne : il s'agit probablement d'un chiffre recomposé, donc halluciné) ; demandez le code et recalculez. 3) Parce que la plupart des erreurs sont des décisions silencieuses de nettoyage ; en décrivant la règle, vous interdisez au modèle de « corriger » la donnée.

## 📚 Pour aller plus loin
- [Claude Platform — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 — la page de référence pour structurer une demande et gérer l'incertitude.
- [Claude Platform — Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 — comment fonctionnent les skills `xlsx`, `docx`, `pptx`, `pdf`.
- [Claude Academy — Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 — leçon « Creating with artifacts » et usage des fichiers dans claude.ai.
- [CNIL — Les fiches pratiques IA](https://cnil.fr/fr/les-fiches-pratiques-ia) 🇫🇷 — minimisation et données personnelles.
- [OpenAI Academy — catalogue](https://academy.openai.com/pages/courses) 🇬🇧 — parcours « Apply AI at Work », tâches tableur et données.
