---
id: L057
module: M13
level: N2
title: "SQL en langage naturel"
minutes: 60
objectives:
  - "Expliquer ce qu'est une base de données relationnelle, une table, un schéma et une requête SQL de lecture (SELECT, WHERE, GROUP BY, JOIN)"
  - "Faire générer par un assistant IA une requête SQL à partir d'une question en français, en fournissant le schéma et le dialecte"
  - "Vérifier une requête générée : lecture critique, exécution sur un jeu de test connu, totaux de contrôle"
  - "Identifier les risques du SQL généré (requêtes d'écriture, exposition de données, ambiguïtés, dialectes) et appliquer les garde-fous (accès en lecture seule, copie de test)"
skills: ["C2.4"]
sources:
  - { title: "Claude Platform — Structured outputs", url: "https://platform.claude.com/docs/en/build-with-claude/structured-outputs", lang: "en" }
  - { title: "Claude Platform — Prompting best practices", url: "https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices", lang: "en" }
  - { title: "OpenAI — Structured outputs", url: "https://developers.openai.com/api/docs/guides/structured-outputs", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "n8n Docs — Data Tables", url: "https://docs.n8n.io/build/work-with-data/data-tables.md", lang: "en" }
  - { title: "n8n Academy — N8N102 Integrations: APIs & Connected Workflows", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about", lang: "en" }
---

# SQL en langage naturel

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 13

## 🎯 Ce que vous saurez faire
- Comprendre, sans être développeur, ce que fait une requête SQL de lecture et pourquoi c'est le langage des données d'entreprise.
- Décrire une base à un assistant IA (schéma, dialecte, règles métier) pour qu'il écrive des requêtes justes.
- Lire une requête générée en repérant les cinq endroits où elle peut mentir.
- Tester toute requête sur une copie dont vous connaissez les réponses (le jeu Mobidesk) avant de l'approcher de la vraie base.
- Mettre en place les deux garde-fous qui évitent la catastrophe : compte en lecture seule et base de test.

## 1. Pourquoi le SQL concerne aussi les non-développeurs

Votre logiciel de facturation, votre CRM, votre outil de paie, votre boutique en ligne : derrière chacun, une **base de données relationnelle** range les informations dans des **tables** (des feuilles de calcul très disciplinées) reliées entre elles par des identifiants. Le langage pour les interroger s'appelle **SQL** (*Structured Query Language*), normalisé depuis 1986 et toujours dominant quarante ans plus tard. Quand vous exportez un CSV « depuis le logiciel », quelqu'un, quelque part, a écrit une requête SQL.

Jusqu'ici, poser une question nouvelle à la base signifiait attendre le développeur ou le prestataire. Les modèles de langage changent cela : ils traduisent très bien une question en français en requête SQL (*text-to-SQL*), **à condition** de connaître la structure de la base. Ce qui ne change pas : la responsabilité de vérifier que la requête répond bien à la question posée. Une requête fausse qui renvoie un beau tableau est plus dangereuse qu'une erreur de syntaxe.

Analogie : SQL est la langue du serveur d'archives. L'IA est l'interprète. Si vous demandez « les ventes du printemps » sans dire si le printemps commence le 20 ou le 21 mars, l'interprète choisira pour vous, sans vous le dire.

## 2. Le jeu Mobidesk en base de données

Nous reprenons les 24 lignes de la leçon 55 et nous ajoutons une seconde table, `objectifs`, pour apprendre la jointure. **SQLite** est parfait pour s'entraîner : gratuit, sans serveur, intégré à Python, et des outils graphiques existent (DB Browser for SQLite, extension VS Code). Le script ci-dessous crée la base `mobidesk.db` à partir du CSV :

```python
"""Crée mobidesk.db (SQLite) à partir de ventes_mobidesk_2026_S1.csv.
Usage : python creer_base.py
"""
import csv
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS ventes (
    date              TEXT    NOT NULL,   -- ISO AAAA-MM-JJ
    commande          TEXT    PRIMARY KEY,
    commercial        TEXT    NOT NULL,
    region            TEXT    NOT NULL,   -- région du COMMERCIAL, pas du client
    categorie         TEXT    NOT NULL,
    produit           TEXT    NOT NULL,
    quantite          INTEGER NOT NULL,   -- négatif = avoir
    prix_unitaire_ht  REAL    NOT NULL,   -- € HT
    montant_ht        REAL    NOT NULL    -- € HT = quantite × prix_unitaire_ht
);
CREATE TABLE IF NOT EXISTS objectifs (
    commercial   TEXT PRIMARY KEY,
    objectif_s1  REAL NOT NULL           -- objectif de CA HT du semestre, en €
);
"""

OBJECTIFS = [("Aïcha Benali", 11000.0), ("Léa Martin", 12000.0), ("Thomas Roussel", 10000.0)]

with sqlite3.connect("mobidesk.db") as con:
    con.executescript(SCHEMA)
    with open("ventes_mobidesk_2026_S1.csv", encoding="utf-8", newline="") as f:
        lignes = list(csv.DictReader(f))
    con.executemany(
        "INSERT OR REPLACE INTO ventes VALUES (:date, :commande, :commercial, :region, "
        ":categorie, :produit, :quantite, :prix_unitaire_ht, :montant_ht)", lignes)
    con.executemany("INSERT OR REPLACE INTO objectifs VALUES (?, ?)", OBJECTIFS)
    nb, total = con.execute("SELECT COUNT(*), ROUND(SUM(montant_ht), 2) FROM ventes").fetchone()
    print(f"{nb} lignes chargées · CA total {total} €")   # attendu : 24 lignes · 33500.0 €
```

Le **schéma** (la description des tables, colonnes, types et commentaires) est la pièce maîtresse : c'est lui que vous donnerez à l'assistant. Notez les commentaires `-- région du COMMERCIAL` et `-- négatif = avoir` : ce sont des **règles métier**, et sans elles l'IA devine.

Quatre mots de vocabulaire suffisent pour lire 90 % des requêtes :

| Mot-clé | Rôle | Dans une phrase |
|---|---|---|
| `SELECT … FROM` | Quelles colonnes, depuis quelle table | « Donne-moi le commercial et le montant de la table ventes » |
| `WHERE` | Filtre sur les lignes | « … seulement en mai » |
| `GROUP BY` + `SUM`, `COUNT`, `AVG` | Regroupe et agrège | « … total par commercial » |
| `JOIN … ON` | Relie deux tables par une clé | « … avec l'objectif de chacun » |

## 3. Le prompt text-to-SQL

```text
Tu écris des requêtes SQL **SQLite** en lecture seule (SELECT uniquement).

SCHÉMA :
[coller le bloc CREATE TABLE ci-dessus, commentaires compris]

RÈGLES MÉTIER : montant_ht inclut les avoirs (quantite négative) ; le CA se calcule
toujours avoirs compris sauf indication contraire ; les mois se calculent sur la
colonne date au format ISO ; les montants sont en euros HT.

QUESTION : quel est le taux d'atteinte de l'objectif semestriel de chaque commercial,
du plus élevé au plus faible, en pourcentage à une décimale ?

RÉPONDS avec : 1) la requête dans un bloc ```sql ; 2) en deux phrases, ce qu'elle
calcule et les hypothèses prises ; 3) les résultats que tu attends si tu les connais.
N'invente pas de colonne qui n'est pas dans le schéma.
```

Réponse attendue (vous la vérifierez dans l'exercice) :

```sql
SELECT v.commercial,
       ROUND(SUM(v.montant_ht), 2)                                AS ca_ht,
       o.objectif_s1,
       ROUND(100.0 * SUM(v.montant_ht) / o.objectif_s1, 1)        AS taux_atteinte_pct
FROM ventes v
JOIN objectifs o ON o.commercial = v.commercial
GROUP BY v.commercial, o.objectif_s1
ORDER BY taux_atteinte_pct DESC;
```

Résultat sur Mobidesk : Aïcha Benali 11 856,50 € / 11 000 € → **107,8 %** ; Thomas Roussel 10 349,30 € / 10 000 € → **103,5 %** ; Léa Martin 11 294,20 € / 12 000 € → **94,1 %**. Le dernier au CA est le deuxième à l'objectif : c'est exactement le genre d'information qu'une jointure révèle et qu'un simple total masque.

Trois détails du prompt font toute la différence : **le dialecte** (SQLite, PostgreSQL, MySQL, SQL Server et BigQuery n'écrivent pas les dates de la même façon : `strftime('%m', date)` en SQLite, `EXTRACT(MONTH FROM date)` en PostgreSQL, `MONTH(date)` en MySQL) ; **« lecture seule »** ; et **« n'invente pas de colonne »** : les modèles adorent ajouter un `client_id` ou un `marge` qui n'existent pas.

> 💡 **À retenir** — Schéma + règles métier + dialecte + question = requête juste neuf fois sur dix. Sans schéma, l'assistant écrit une requête pour une base imaginaire.

## 4. Lire une requête générée : les cinq endroits où elle peut mentir

Même sans savoir écrire SQL, vous pouvez le **relire**. Cherchez ces cinq motifs :

1. **Le `WHERE` de trop.** `WHERE quantite > 0` exclut l'avoir : le CA d'Aïcha Benali passe à 12 205,50 €. Si vous n'avez pas demandé cette exclusion, elle est fautive.
2. **Le `WHERE` manquant.** Vous demandez « le CA de mai » et la requête n'a pas de filtre sur la date : elle renvoie le semestre (33 500 € au lieu de 8 288,50 €).
3. **La division entière.** `SUM(montant_ht) / objectif_s1` est sans risque ici (réels), mais `COUNT(avoirs) / COUNT(*)` donne 0 dans beaucoup de dialectes parce que deux entiers divisés donnent un entier. Cherchez le `100.0` ou le `CAST(… AS REAL)`.
4. **L'agrégat ambigu.** « Le meilleur commercial » : par CA du semestre (Aïcha Benali, 11 856,50 €), par progression T1 → T2 (Thomas Roussel, +87,3 %), par CA mobilier (Thomas Roussel, 7 476,00 €), par nombre de commandes (8 chacun) ? La requête choisit ; votre question aurait dû choisir.
5. **La jointure qui multiplie.** Si la table `objectifs` contenait deux lignes pour un même commercial (objectif T1 et objectif T2), la jointure doublerait le CA. Contrôle : le total de la requête jointe doit rester 33 500,00 €.

🎮 **Défi « trouve l'erreur »** — Cette requête est censée donner le CA par mois. Trouvez les deux problèmes avant de lire la suite.

```sql
SELECT strftime('%m', date) AS mois, SUM(montant_ht) AS ca
FROM ventes
WHERE quantite > 0
GROUP BY mois
ORDER BY ca DESC;
```

Réponse : `WHERE quantite > 0` écarte l'avoir (avril passe de 3 074,00 € à 3 423,00 €) ; `ORDER BY ca DESC` trie par montant et non par mois, ce qui rend le résultat illisible comme chronologie. Deux erreurs silencieuses, zéro erreur de syntaxe.

## 5. La procédure de test : toujours sur une copie connue

```
 Question en français
        │
        ▼
 Assistant IA ──► requête SQL ──► 1. relecture (5 motifs)
                                       │
                                       ▼
                               2. exécution sur mobidesk.db (24 lignes, réponses connues)
                                       │ total = 33 500,00 € ? nb lignes = 24 ?
                                       ▼
                               3. exécution sur une COPIE / un compte lecture seule
                                  de la vraie base
                                       │
                                       ▼
                               4. mise en production (vue, rapport, workflow n8n)
```

Le script Python ci-dessous exécute une requête et affiche les totaux de contrôle. Vous pouvez le lancer tel quel ; les développeurs y reconnaîtront le minimum vital, les autres y verront que « tester une requête » prend dix lignes.

```python
"""Exécute une requête SELECT sur mobidesk.db et affiche les contrôles.
Usage : python tester_requete.py requete.sql
"""
import sqlite3
import sys

with open(sys.argv[1], encoding="utf-8") as f:
    sql = f.read().strip()

if not sql.lower().startswith("select"):
    sys.exit("Refusé : seules les requêtes SELECT sont autorisées ici.")

# Ouverture en LECTURE SEULE : même un DELETE glissé dans le fichier échouerait.
con = sqlite3.connect("file:mobidesk.db?mode=ro", uri=True)
con.row_factory = sqlite3.Row
lignes = con.execute(sql).fetchall()

print(f"{len(lignes)} ligne(s) renvoyée(s)")
if lignes:
    print(" | ".join(lignes[0].keys()))
    for l in lignes:
        print(" | ".join(str(v) for v in l))

# Totaux de contrôle de la base (indépendants de la requête testée)
nb, total = con.execute("SELECT COUNT(*), ROUND(SUM(montant_ht), 2) FROM ventes").fetchone()
print(f"\nContrôle base : {nb} lignes, CA total {total} € (attendu : 24 et 33500.0)")
```

Avec une vraie base (PostgreSQL, MySQL, SQL Server), demandez à votre administrateur un **compte en lecture seule** (`GRANT SELECT` et rien d'autre) et, idéalement, une **copie anonymisée** de la base pour les tests. Un modèle de langage ne lancera pas un `DELETE` tout seul si vous lui demandez un `SELECT`… mais un copier-coller précipité d'une requête `UPDATE` suggérée « pour corriger les avoirs », si. Le compte en lecture seule rend l'accident impossible.

> ⚠️ **Piège fréquent** — Coller dans le chat un extrait de la vraie base « pour que l'IA comprenne mieux ». Vous venez de transmettre des données clients à un service tiers. Le schéma suffit ; les données de test sont fictives (Mobidesk) ou anonymisées. C'est la règle de minimisation vue en leçon 55 et au module 7.

## 6. Où brancher le SQL généré dans la vraie vie

- **Dans le chat** (Claude, ChatGPT, Le Chat, Gemini) : vous obtenez la requête, vous l'exécutez vous-même dans votre outil de base de données. C'est le mode le plus sûr : l'IA ne touche jamais la base.
- **Avec un agent de code** (Claude Code, Codex) connecté à une base de test : l'agent écrit, exécute, corrige. Puissant pour explorer ; réservé à une copie.
- **Dans n8n** (module 8) : un nœud base de données (Postgres, MySQL…) exécute une requête fixe, validée une fois pour toutes, à chaque passage du workflow. Les **Data Tables** de n8n offrent même une petite base intégrée pour stocker des résultats sans serveur. C'est ce que nous ferons en leçon 58.
- **Via une API avec sorties structurées** : pour les développeurs, Claude et OpenAI proposent des sorties JSON contraintes par un schéma (*structured outputs*) ; on demande au modèle de renvoyer `{ "sql": "...", "hypotheses": [...] }` et un programme vérifie que `sql` commence bien par `SELECT` avant toute exécution. Le niveau 3 détaille cette approche.

Dans tous les cas, l'architecture saine est la même : **l'IA propose, un garde-fou mécanique vérifie (lecture seule, préfixe SELECT, limite de lignes), un humain valide la première fois, puis le workflow répète.**

> 🔗 **Documentation officielle** — [Claude Platform — Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs) 🇬🇧 ; [OpenAI — Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs) 🇬🇧 ; [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 (contraindre les entrées, humain dans la boucle).

## 🧪 Exercice pratique

**Consigne.**
1. Créez `mobidesk.db` avec le script de la section 2 (Python 3.12 ; aucune bibliothèque à installer). Vérifiez l'affichage « 24 lignes chargées · CA total 33500.0 € ».
2. Avec l'assistant de votre choix et le prompt de la section 3, faites générer les cinq requêtes suivantes, puis testez-les avec `tester_requete.py` :
   a. CA HT par mois, dans l'ordre chronologique ;
   b. les trois meilleures ventes unitaires (lignes au montant le plus élevé) ;
   c. nombre de commandes et panier moyen par région, avoirs compris ;
   d. taux d'atteinte de l'objectif par commercial (section 3) ;
   e. produits dont la quantité totale vendue dépasse 30 unités.
3. Pour chaque requête, notez : les hypothèses annoncées par l'assistant, les motifs suspects (section 4), et si le résultat correspond aux valeurs de référence.
4. Demandez ensuite à l'assistant « une requête qui corrige l'avoir C-1016 en le mettant à zéro ». Constatez qu'il propose un `UPDATE`, puis vérifiez que `tester_requete.py` et le mode lecture seule le refusent.

**Critères de réussite.**
- Les cinq requêtes s'exécutent et donnent : a) 3 444,30 / 4 524,00 / 6 027,00 / 3 074,00 / 8 288,50 / 8 142,20 € ; b) C-1019 (3 468,00 €), C-1021 (3 141,00 €), C-1017 (2 890,00 €) ; c) 8 commandes par région, paniers moyens 1 482,06 € (Île-de-France), 1 411,78 € (Nouvelle-Aquitaine), 1 293,66 € (Auvergne-Rhône-Alpes) ; d) 107,8 / 103,5 / 94,1 % ; e) Pack papeterie (205), Lampe Halo (95), Fauteuil Ergo+ (38).
- Vous avez repéré au moins un `WHERE` ou un `ORDER BY` discutable et l'avez fait corriger.
- Le `UPDATE` a été refusé par le garde-fou.

**Pistes de corrigé.** Pour (a), la requête juste contient `GROUP BY strftime('%m', date)` et `ORDER BY mois` (pas `ORDER BY ca`). Pour (c), `AVG(montant_ht)` avoirs compris ; si l'assistant propose `AVG(ABS(montant_ht))`, c'est une décision silencieuse à refuser. Pour (e), le `HAVING SUM(quantite) > 30` est la bonne forme : `WHERE quantite > 30` filtrerait les lignes et non les totaux (et ne renverrait que les lignes de 40, 60 et 80 packs de papeterie).

## ✅ Auto-évaluation express

1. Que manque-t-il au prompt « Écris une requête qui donne le CA par commercial » pour obtenir une réponse fiable ?
2. Une requête jointe entre `ventes` et `objectifs` renvoie un CA total de 67 000 €. Que s'est-il passé ?
3. Pourquoi ouvrir la base avec `mode=ro` alors que vous ne demandez que des `SELECT` ?

**Réponses.** 1) Le schéma (tables, colonnes, types), le dialecte SQL, les règles métier (avoirs compris ou non) et le format de réponse attendu. 2) La jointure multiplie les lignes : la table `objectifs` contient probablement deux lignes par commercial ; le total de contrôle (33 500 €) le révèle immédiatement. 3) Parce que la protection doit être mécanique et non reposer sur l'attention humaine : un `UPDATE` ou un `DELETE` suggéré par l'assistant et collé par erreur échouera quoi qu'il arrive.

## 📚 Pour aller plus loin
- [Claude Platform — Prompting best practices](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices) 🇬🇧 — donner du contexte (schéma, règles) et demander les hypothèses.
- [n8n Docs — Data Tables](https://docs.n8n.io/build/work-with-data/data-tables.md) 🇬🇧 — une petite base intégrée à n8n pour stocker des résultats de requêtes.
- [n8n Academy — N8N102 Integrations](https://learn.n8n.io/courses/course-v1:n8n+N8N102+2026H2/about) 🇬🇧 — APIs, credentials et nœuds de données, prérequis de la leçon 58.
- [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — contraindre les entrées et sorties, humain dans la boucle.
