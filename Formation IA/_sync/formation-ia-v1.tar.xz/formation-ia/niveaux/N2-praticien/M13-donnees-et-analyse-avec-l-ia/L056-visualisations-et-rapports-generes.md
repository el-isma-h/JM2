---
id: L056
module: M13
level: N2
title: "Visualisations et rapports générés"
minutes: 60
objectives:
  - "Choisir le type de graphique adapté à une question métier (évolution, comparaison, répartition, relation)"
  - "Rédiger un prompt de visualisation complet (données, type, axes, unités, titre, message) pour Claude ou ChatGPT et obtenir un graphique exploitable"
  - "Évaluer un graphique généré par l'IA : axes tronqués, camemberts illisibles, couleurs, chiffres incohérents avec les données"
  - "Produire un rapport d'analyse structuré (constats, chiffres, recommandations) et l'exporter dans le format attendu (image, Excel, PowerPoint, PDF)"
skills: ["C2.4"]
sources:
  - { title: "Claude Academy — Claude 101 (Creating with artifacts)", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "Claude Platform — Agent Skills overview (skills xlsx, pptx, docx, pdf)", url: "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview", lang: "en" }
  - { title: "Claude Platform — Code execution tool", url: "https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool", lang: "en" }
  - { title: "OpenAI — API Quickstart", url: "https://developers.openai.com/api/docs/quickstart", lang: "en" }
  - { title: "Google AI Professional Certificate (module AI for Data Analysis)", url: "https://www.coursera.org/professional-certificates/google-ai", lang: "en" }
  - { title: "Gemini API — fiche Gemini 3.8 Flash (exécution de code)", url: "https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash", lang: "en" }
---

# Visualisations et rapports générés

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 13

## 🎯 Ce que vous saurez faire
- Transformer une question métier (« qui progresse ? », « qu'est-ce qui pèse le plus ? ») en un type de graphique précis.
- Demander à Claude ou ChatGPT un graphique propre, titré, en euros, avec le message en une phrase.
- Relire un graphique généré comme un auditeur : axe tronqué, camembert à dix parts, chiffres qui ne collent pas au fichier.
- Obtenir un rapport de deux pages structuré (constats → chiffres → recommandations) et l'exporter en PNG, Excel, PowerPoint ou PDF.

Nous reprenons le fichier `ventes_mobidesk_2026_S1.csv` de la leçon 55 (24 lignes, CA total 33 500,00 €).

## 1. Un graphique répond à une question, pas à un fichier

« Fais-moi des graphiques » est la demande qui produit les pires résultats : l'assistant génère six figures dont trois camemberts, sans message. La bonne approche part de la question que votre lecteur se pose. Quatre familles couvrent 90 % des besoins d'un gestionnaire :

| Question du lecteur | Famille | Graphique recommandé | Exemple Mobidesk |
|---|---|---|---|
| « Comment ça évolue ? » | Évolution dans le temps | Courbe (ou barres verticales si peu de périodes) | CA mensuel janvier → juin |
| « Qui est devant ? » | Comparaison entre catégories | Barres horizontales triées | CA par commercial, par produit |
| « Qu'est-ce qui pèse le plus ? » | Répartition d'un tout | Barres 100 % ou barres triées ; camembert **seulement** si ≤ 4 parts | Part des catégories dans le CA |
| « Est-ce lié ? » | Relation entre deux mesures | Nuage de points | Quantité vendue vs prix unitaire |

Deux règles de métier, héritées des travaux de statisticiens comme William Playfair (inventeur de la courbe et de l'histogramme à barres à la fin du XVIIIᵉ siècle) et reprises par tous les manuels modernes : **le temps va toujours sur l'axe horizontal**, et **les barres partent de zéro**. Un modèle qui tronque l'axe des ordonnées pour « mieux voir les différences » transforme un écart de 5 % en gouffre visuel.

Ce que l'IA fait très bien ici : traduire la question en graphique, écrire le code, produire l'image en quelques secondes. Ce qu'elle fait mal si vous ne cadrez pas : choisir la question, et résister à l'envie de tout montrer.

> 💡 **À retenir** — Une figure = une question = un message en une phrase écrit dans le titre. « CA mensuel » est un sujet ; « Le CA a presque triplé entre avril et mai (3 074 € → 8 289 €) » est un message.

## 2. Le prompt de visualisation : six informations obligatoires

Une demande de graphique efficace, dans Claude (qui produit un **artefact** : une image ou un graphique interactif affiché à côté de la conversation) ou dans ChatGPT (qui exécute du Python et affiche l'image), contient : les données, la question, le type, les axes et unités, le titre-message, le format de sortie.

```text
DONNÉES : fichier joint ventes_mobidesk_2026_S1.csv (colonnes : date ISO, commercial,
categorie, produit, quantite, montant_ht en € HT ; la ligne C-1016 est un avoir à garder).

QUESTION : comment le CA mensuel a-t-il évolué sur le semestre ?

GRAPHIQUE : barres verticales, un mois par barre, janvier à juin dans l'ordre.
Axe vertical en euros HT à partir de zéro, étiquettes de valeur au-dessus de chaque
barre au format « 8 289 € ». Axe horizontal : noms de mois en français.

TITRE (message) : une phrase qui dit ce qu'on voit, avec les chiffres clés.

MÉTHODE : calcule avec du code, affiche le code, puis l'image en PNG 1600 × 900.
Vérifie que la somme des six barres fait 33 500,00 € et dis-le-moi.
```

La dernière ligne est votre assurance : si la somme des barres n'est pas 33 500 €, le graphique est faux, quelle que soit sa beauté.

Pour une comparaison, remplacez le bloc GRAPHIQUE par « barres horizontales triées de la plus grande à la plus petite, une couleur neutre, le premier en couleur d'accent ». Pour une répartition : « barres horizontales triées avec le pourcentage du total en étiquette ; pas de camembert ».

> ⚠️ **Piège fréquent** — Le modèle reçoit un fichier avec des dates ISO et produit un graphique dont les mois sont triés par ordre alphabétique (Avril, Février, Janvier, Juin, Mai, Mars). Ajoutez toujours « dans l'ordre chronologique » et vérifiez l'axe.

## 3. Lire un graphique généré comme un auditeur

Voici la grille de relecture en six points, à appliquer en trente secondes à chaque figure :

1. **Les chiffres sont-ils ceux du fichier ?** Comparez deux valeurs au hasard avec votre tableau de référence (mai = 8 288,50 € ; avril = 3 074,00 €).
2. **L'axe vertical part-il de zéro ?** Sinon, demandez la correction ou justifiez explicitement la troncature dans la légende.
3. **Le camembert a-t-il plus de quatre parts ?** Cinq produits en camembert : les parts de Caisson Nova (10,8 %) et de Pack papeterie (11,3 %) sont indiscernables à l'œil. Barres triées.
4. **Les couleurs ont-elles un sens ?** Six couleurs vives pour six mois n'apportent rien ; une seule couleur et un accent sur le point important, si.
5. **Le titre dit-il quelque chose ?** « Graphique 1 : CA » ne dit rien ; « Avril : le creux du semestre (−49 % vs mars), rattrapé en mai » dit tout.
6. **Le graphique répond-il à la question posée ?** Si vous avez demandé l'évolution et que vous recevez la répartition, recommencez.

🎮 **Défi** — Demandez à l'assistant « un graphique qui montre que Thomas Roussel est en difficulté ». Puis demandez « un graphique qui montre que Thomas Roussel progresse ». Les deux sont possibles avec les mêmes 24 lignes (il est dernier au total avec 10 349,30 €, mais il a réalisé 2 890 € en mai et 2 443 € en juin). Vous venez de comprendre pourquoi un graphique IA n'est jamais neutre : c'est votre question qui l'oriente.

## 4. Produire les graphiques vous-même : le script de référence

Même sans être développeur, disposer d'un script que vous pouvez relancer tous les mois est précieux : il rend le rapport **reproductible**, ce qu'une conversation de chat n'est pas. Demandez à l'assistant de le générer, puis conservez-le. Voici celui que nous utiliserons dans la leçon 58 (Python 3.12, bibliothèques `pandas` et `matplotlib` : `pip install pandas matplotlib`) :

```python
"""Graphiques de référence Mobidesk — S1 2026.
Usage : python graphiques_mobidesk.py ventes_mobidesk_2026_S1.csv
Produit : ca_mensuel.png, ca_commercial.png, ca_categorie.png
"""
import sys
from decimal import Decimal, ROUND_HALF_UP
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # rendu sans écran (serveur, tâche planifiée)
import matplotlib.pyplot as plt

MOIS_FR = ["janv.", "févr.", "mars", "avr.", "mai", "juin",
           "juil.", "août", "sept.", "oct.", "nov.", "déc."]

def euros(x: float) -> str:
    """Formate 8288.5 en '8 289 €' (espace insécable comme séparateur de milliers).
    Attention : f"{8288.5:.0f}" donne '8288' (arrondi « bancaire » au pair) ;
    on force l'arrondi commercial (0,5 → vers le haut) attendu par un lecteur français."""
    entier = int(Decimal(str(x)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return f"{entier:,} €".replace(",", "\u202f")

def charger(chemin: str) -> pd.DataFrame:
    df = pd.read_csv(chemin, parse_dates=["date"])
    # Contrôles de cohérence : on arrête tout si le fichier n'est pas celui attendu
    assert (df["quantite"] * df["prix_unitaire_ht"]).round(2).equals(df["montant_ht"].round(2)), \
        "montant_ht ≠ quantite × prix_unitaire_ht sur au moins une ligne"
    return df

def barres(valeurs: pd.Series, titre: str, fichier: str, horizontal: bool = False) -> None:
    fig, ax = plt.subplots(figsize=(16, 9), dpi=100)
    couleurs = ["#9aa5b1"] * len(valeurs)
    couleurs[valeurs.values.argmax()] = "#1f6feb"  # accent sur la plus grande valeur
    if horizontal:
        valeurs = valeurs.sort_values()
        couleurs = ["#9aa5b1"] * len(valeurs); couleurs[-1] = "#1f6feb"
        bars = ax.barh(valeurs.index, valeurs.values, color=couleurs)
        ax.bar_label(bars, labels=[euros(v) for v in valeurs.values], padding=4)
        ax.set_xlabel("CA HT (€)")
    else:
        bars = ax.bar(valeurs.index, valeurs.values, color=couleurs)
        ax.bar_label(bars, labels=[euros(v) for v in valeurs.values], padding=4)
        ax.set_ylabel("CA HT (€)")
    ax.set_ylim(bottom=0) if not horizontal else ax.set_xlim(left=0)  # jamais d'axe tronqué
    ax.set_title(titre, loc="left", fontsize=16, fontweight="bold")
    for cote in ("top", "right"):
        ax.spines[cote].set_visible(False)
    fig.tight_layout()
    fig.savefig(fichier)
    plt.close(fig)

if __name__ == "__main__":
    df = charger(sys.argv[1] if len(sys.argv) > 1 else "ventes_mobidesk_2026_S1.csv")
    total = df["montant_ht"].sum()
    print(f"Lignes : {len(df)} · CA total : {total:,.2f} €")

    par_mois = df.groupby(df["date"].dt.month)["montant_ht"].sum()
    par_mois.index = [MOIS_FR[m - 1] for m in par_mois.index]
    assert abs(par_mois.sum() - total) < 0.01, "la somme des mois ≠ total"
    pire, meilleur = par_mois.idxmin(), par_mois.idxmax()
    barres(par_mois, f"{meilleur.capitalize()} est le meilleur mois ({euros(par_mois.max())}) ; "
                     f"{pire} le plus faible ({euros(par_mois.min())})", "ca_mensuel.png")

    par_com = df.groupby("commercial")["montant_ht"].sum()
    barres(par_com, f"{par_com.idxmax()} réalise {par_com.max() / total:.1%} du CA du semestre",
           "ca_commercial.png", horizontal=True)

    par_cat = df.groupby("categorie")["montant_ht"].sum()
    barres(par_cat, f"Le mobilier pèse {par_cat['Mobilier'] / total:.1%} du CA",
           "ca_categorie.png", horizontal=True)
    print("Graphiques enregistrés : ca_mensuel.png, ca_commercial.png, ca_categorie.png")
```

Lisez les deux lignes `assert` : ce sont les contrôles de la leçon 55 transposés dans le code. Si le fichier change de structure ou si la somme des mois ne fait plus le total, le script s'arrête **au lieu de produire un joli graphique faux**. C'est exactement ce que vous devez exiger de tout script généré par un assistant : des contrôles qui échouent bruyamment.

## 5. Du graphique au rapport : la structure qui marche

Un rapport d'analyse n'est pas une galerie d'images. La structure la plus efficace pour un lecteur pressé (dirigeant, directeur commercial) tient en quatre blocs, que vous demanderez explicitement :

1. **L'essentiel en trois phrases** (ce qu'il faut retenir, chiffres à l'appui).
2. **Les constats**, un par paragraphe, chacun appuyé sur un graphique et un chiffre vérifiable.
3. **Les points d'attention** (données manquantes, avoir, hypothèses).
4. **Les recommandations**, formulées comme des décisions à prendre, avec leur impact chiffré.

Prompt type, à envoyer une fois les graphiques validés :

```text
À partir des trois graphiques validés et du fichier, rédige un rapport d'une page
pour le directeur commercial de Mobidesk. Structure : 1) L'essentiel en trois phrases ;
2) Trois constats (un paragraphe chacun, un chiffre vérifiable par constat, référence
au graphique) ; 3) Points d'attention (avoir C-1016, un seul semestre de données,
région = région du commercial) ; 4) Deux recommandations avec impact estimé en euros,
en précisant l'hypothèse de calcul. Ton factuel, pas d'adjectif, montants au format
« 11 856,50 € ». N'invente aucun chiffre externe au fichier.
```

Sur Mobidesk, un rapport correct dira par exemple : le CA du T2 dépasse celui du T1 de 39,4 % ; le mobilier représente 60,9 % du CA (20 405,00 €) ; avril est un creux (3 074,00 €) suivi d'un record en mai (8 288,50 €) ; les trois commerciaux sont à moins de 15 % d'écart. Et il refusera d'écrire « le marché du mobilier de bureau est en croissance de 5 % » parce que ce chiffre n'est pas dans le fichier.

> ⚠️ **Piège fréquent** — Le rapport généré contient des recommandations génériques (« renforcer la prospection », « optimiser le mix produit ») qui pourraient s'appliquer à n'importe quelle entreprise. Exigez un chiffre et une hypothèse pour chaque recommandation : « Si Thomas Roussel atteignait la moyenne des deux autres (11 575,35 €), le CA semestriel gagnerait 1 226,05 € ». Un chiffre faux se corrige ; une généralité ne sert à rien.

## 6. Exporter : image, Excel, PowerPoint, PDF

| Besoin | Format | Comment l'obtenir |
|---|---|---|
| Illustrer un e-mail ou un message Slack | PNG (1600 × 900) | Téléchargement de l'artefact (Claude) ou de l'image (ChatGPT) ; `savefig` dans le script |
| Laisser le lecteur refaire les calculs | Classeur **Excel avec formules** | Skill `xlsx` de Claude (demandez « des formules, pas des valeurs figées ») ; dans ChatGPT, demandez un fichier `.xlsx` généré par code |
| Présenter en réunion | PowerPoint | Skill `pptx` de Claude ; ou exportez les PNG et montez-les dans votre modèle d'entreprise |
| Archiver / diffuser | PDF | Skill `pdf` ou impression du rapport ; vérifiez que les polices et les accents sont conservés |
| Graphique interactif (survol, filtre) | Artefact HTML / React | Claude produit des artefacts interactifs ; utile pour un tableau de bord interne, à ne pas envoyer par e-mail |

Le skill `xlsx` de Claude est un mode d'emploi chargé automatiquement quand la tâche concerne un classeur ; il sait écrire des formules (`=SOMME.SI.ENS`, `=SIERREUR`) et mettre en forme. Résultat : votre expert-comptable clique sur une cellule et voit d'où vient le chiffre. C'est le critère qui distingue un livrable d'analyse professionnel d'une capture d'écran.

Côté Google, les titulaires du *Google AI Professional Certificate* suivent un module « AI for Data Analysis » centré sur Gemini dans Sheets : le principe est identique (poser une question en langage naturel, obtenir une formule ou un graphique, vérifier). Les fonctions précises disponibles dans Sheets évoluant vite, référez-vous à la page officielle Google Workspace de votre abonnement.

> 🔗 **Documentation officielle** — [Claude Platform — Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 (skills `xlsx`, `pptx`, `docx`, `pdf`) ; [Claude Academy — Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 (« Creating with artifacts »).

## 🧪 Exercice pratique

**Consigne.** Avec le fichier Mobidesk et l'assistant de votre choix :

1. Obtenez les trois graphiques (CA mensuel, CA par commercial, CA par catégorie) avec un prompt complet par graphique (six informations de la section 2), en exigeant la vérification de la somme.
2. Passez chaque graphique à la grille de relecture en six points (section 3) ; notez les défauts et faites-les corriger.
3. Demandez le rapport d'une page avec le prompt de la section 5.
4. Exportez : les trois PNG, et un classeur Excel contenant les trois tableaux agrégés **avec formules** (ou, à défaut, décrivez pourquoi votre outil ne le permet pas).
5. Facultatif : exécutez le script de la section 4 sur votre machine et comparez ses images à celles de l'assistant.

**Critères de réussite.**
- Chaque graphique porte un titre-message avec au moins un chiffre exact.
- Aucun axe tronqué, aucun camembert à plus de quatre parts, mois dans l'ordre chronologique.
- Le rapport contient trois constats chiffrés exacts, les points d'attention, deux recommandations avec hypothèse de calcul, et aucun chiffre externe au fichier.
- Le classeur Excel recalcule le total à 33 500,00 € quand on modifie une ligne.

**Pistes de corrigé.** Titres attendus (à vos mots près) : « Mai, meilleur mois du semestre (8 289 €), après un creux en avril (3 074 €) » ; « Aïcha Benali réalise 35,4 % du CA » ; « Le mobilier pèse 60,9 % du CA ». Si le graphique par commercial donne Aïcha Benali à 12 205,50 €, l'avoir a été exclu : demandez la correction. Recommandation chiffrée possible : « le Fauteuil Ergo+ (10 982,00 €, 38 unités) est le premier produit ; une offre pack bureau + fauteuil sur les 27 bureaux Oslo vendus sans fauteuil associé représente un potentiel de 27 × 289 € = 7 803 € HT, si le taux d'attache atteignait 100 % (hypothèse haute) ».

## ✅ Auto-évaluation express

1. Vous voulez montrer la part de chaque produit dans le CA (cinq produits). Camembert ou barres, et pourquoi ?
2. Le graphique du CA mensuel affiche des barres de 3 000 à 8 500 € avec un axe qui démarre à 2 500 €. Quel est le problème ?
3. Quelle phrase ajoutez-vous à tout prompt de graphique pour détecter un calcul faux ?

**Réponses.** 1) Barres horizontales triées avec pourcentages : cinq parts dont deux presque égales (10,8 % et 11,3 %) sont illisibles en camembert. 2) L'axe tronqué exagère visuellement les écarts : avril paraît quasi nul alors qu'il représente 37 % de mai ; les barres doivent partir de zéro. 3) « Vérifie que la somme des valeurs affichées fait 33 500,00 € (le total du fichier) et dis-le-moi » : un total de contrôle indépendant.

## 📚 Pour aller plus loin
- [Claude Academy — Claude 101](https://academy.claude.com/courses/claude-101) 🇬🇧 — artefacts, projets, fichiers dans claude.ai.
- [Claude Platform — Code execution tool](https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool) 🇬🇧 — comment Claude exécute du Python et produit des fichiers côté API.
- [Google AI Professional Certificate](https://www.coursera.org/professional-certificates/google-ai) 🇬🇧 — module « AI for Data Analysis » (1 h) avec Gemini dans Workspace ; une certification tierce que nous vous encourageons à passer.
- [Gemini API — Gemini 3.8 Flash](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash) 🇬🇧 — capacités d'exécution de code et de lecture de fichiers du modèle.
- [OpenAI — API Quickstart](https://developers.openai.com/api/docs/quickstart) 🇬🇧 — fichiers et outil `code_interpreter` dans la Responses API.
