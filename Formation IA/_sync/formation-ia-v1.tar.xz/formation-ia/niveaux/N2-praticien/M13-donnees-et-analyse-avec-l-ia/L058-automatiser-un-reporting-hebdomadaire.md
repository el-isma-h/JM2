---
id: L058
module: M13
level: N2
title: "Automatiser un reporting hebdomadaire"
minutes: 60
objectives:
  - "Concevoir l'architecture d'un reporting automatisé : source de données → calculs déterministes → rédaction par un LLM → diffusion (e-mail, Slack) → gestion des erreurs"
  - "Construire dans n8n un workflow planifié qui lit une feuille Google Sheets, calcule les indicateurs dans un nœud Code et fait rédiger le commentaire par un modèle de langage"
  - "Rédiger le prompt de rédaction d'un rapport à partir de chiffres déjà calculés, avec interdiction d'inventer ou de recalculer"
  - "Évaluer la fiabilité et le coût d'un reporting automatisé et prévoir les contrôles humains (relecture, alerte en cas d'anomalie)"
skills: ["C2.4", "C2.1"]
sources:
  - { title: "n8n Docs — Build your first workflow", url: "https://docs.n8n.io/build-your-first-workflow.md", lang: "en" }
  - { title: "n8n Docs — LangChain in n8n (nœuds IA, chaînes, modèles)", url: "https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md", lang: "en" }
  - { title: "n8n Docs — Human in the loop for tools", url: "https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md", lang: "en" }
  - { title: "n8n Academy — N8N103 In Practice: AI, Testing & Best Practices", url: "https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about", lang: "en" }
  - { title: "Claude Platform — Pricing", url: "https://platform.claude.com/docs/en/about-claude/pricing", lang: "en" }
  - { title: "Claude Platform — Get started (SDK Python, clé API)", url: "https://platform.claude.com/docs/en/get-started", lang: "en" }
  - { title: "Claude Platform — Batch processing", url: "https://platform.claude.com/docs/en/build-with-claude/batch-processing", lang: "en" }
---

# Automatiser un reporting hebdomadaire

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 13

## 🎯 Ce que vous saurez faire
- Dessiner le circuit complet d'un rapport hebdomadaire automatique, de la feuille de calcul au message Slack du lundi matin.
- Appliquer la règle d'or « **le code calcule, le modèle rédige** » pour que les chiffres soient toujours exacts.
- Construire le workflow dans n8n (déclencheur planifié, Google Sheets, nœud Code, chaîne LLM, Gmail, Slack, gestion d'erreurs).
- Écrire un prompt de rédaction qui interdit au modèle d'inventer ou de recalculer.
- Estimer le coût mensuel, prévoir les contrôles et savoir quand préférer un script Python.

Ce projet clôt le module : il réutilise le fichier Mobidesk (leçon 55), les graphiques (leçon 56) et la logique d'agrégation (leçon 57). Il mobilise les nœuds n8n vus au module 8.

## 1. Le scénario et la règle d'or

Chaque lundi à 7 h 30, le directeur commercial de Mobidesk veut recevoir : le CA de la semaine écoulée, la comparaison avec la semaine précédente, le cumul du semestre, le commercial et le produit de la semaine, et trois lignes de commentaire. Aujourd'hui, l'assistante de direction y passe quarante minutes, quand elle n'oublie pas.

Première tentation : envoyer toute la feuille de ventes au modèle de langage et lui demander « rédige le rapport de la semaine ». Vous savez depuis la leçon 55 pourquoi c'est une mauvaise idée : un chiffre calculé « de tête » n'a aucune garantie, et un rapport envoyé automatiquement à la direction n'est relu par personne.

D'où la règle d'or de tout reporting automatisé :

> 💡 **À retenir** — **Le code calcule, le modèle rédige.** Les totaux, variations et classements sont produits par un nœud Code (ou une requête SQL, ou un script) dont le résultat est déterministe et testable. Le modèle de langage reçoit ces chiffres **déjà calculés** et n'a qu'un rôle : les mettre en phrases claires. Il lui est interdit d'inventer ou de recalculer.

Avec cette séparation, une erreur de calcul devient impossible par construction, et une erreur de rédaction (un « +12 % » recopié « −12 % ») reste possible mais détectable : nous ajouterons un contrôle.

## 2. L'architecture en six étapes

```
 ┌─────────────────┐   ┌──────────────────┐   ┌──────────────────┐
 │ 1. Schedule      │──►│ 2. Google Sheets │──►│ 3. Code (JS)     │
 │ lundi 07:30      │   │ Get Row(s)       │   │ calcule les KPI  │
 └─────────────────┘   └──────────────────┘   └────────┬─────────┘
                                                        ▼
 ┌─────────────────┐   ┌──────────────────┐   ┌──────────────────┐
 │ 6. Gmail + Slack │◄──│ 5. Code (JS)     │◄──│ 4. Basic LLM     │
 │ diffusion        │   │ contrôle chiffres│   │ Chain : rédige   │
 └─────────────────┘   └──────────────────┘   └──────────────────┘
          ▲
          │  Error Trigger (workflow séparé) → message Slack « reporting en échec »
```

| Étape | Nœud n8n | Ce qu'il fait | Ce qu'il ne doit pas faire |
|---|---|---|---|
| 1 | **Schedule Trigger** | Déclenche chaque lundi à 7 h 30 (fuseau Europe/Paris) | — |
| 2 | **Google Sheets** (opération *Get Row(s)*) | Lit la feuille `ventes` (mêmes colonnes que le CSV) ; un item n8n par ligne | Filtrer par date dans le nœud (plus simple et testable dans le Code) |
| 3 | **Code** (JavaScript) | Calcule semaine N, semaine N−1, cumul, variation, meilleurs commercial et produit ; renvoie **un seul item** `kpi` | Appeler un modèle |
| 4 | **Basic LLM Chain** + sous-nœud modèle (Anthropic, OpenAI, Mistral, Ollama…) | Rédige le commentaire à partir du JSON `kpi` | Recevoir les lignes brutes |
| 5 | **Code** | Vérifie que chaque montant du texte figure dans `kpi` ; sinon, ajoute un avertissement | — |
| 6 | **Gmail** (*Send*) et **Slack** (*Post message*) | Envoie le rapport ; le Slack contient le résumé, l'e-mail le détail | Envoyer si l'étape 5 a levé une alerte bloquante |

Deux remarques d'architecture. La feuille Google Sheets est ici la source ; dans une entreprise équipée, l'étape 2 devient un nœud Postgres ou MySQL exécutant la requête validée en leçon 57 (compte en lecture seule), ou un nœud HTTP Request vers l'API du logiciel de facturation. Et le **Error Trigger** est un second workflow, minuscule, qui s'exécute quand le premier échoue : sans lui, un lundi sans rapport passe inaperçu jusqu'au mardi.

> 🔗 **Documentation officielle** — [n8n Docs — Build your first workflow](https://docs.n8n.io/build-your-first-workflow.md) 🇬🇧 ; [n8n Docs — LangChain in n8n](https://docs.n8n.io/build/integrate-ai/langchain-in-n8n.md) 🇬🇧 (chaînes, modèles, sous-nœuds).

## 3. Étape 3 : le nœud Code qui calcule les indicateurs

Le nœud Code reçoit un item par ligne de la feuille. Il renvoie un seul item avec les indicateurs. Collez ce code (mode *Run Once for All Items*) ; il suppose que l'exécution a lieu le lundi et que la semaine va du lundi au dimanche précédents. Pour tester sur Mobidesk, fixez la date de référence au 29 juin 2026.

```javascript
// Nœud Code — "Calcul des KPI de la semaine"
// Entrée : un item par ligne de la feuille ventes (colonnes du CSV Mobidesk)
// Sortie : un item { kpi: {...} } — tous les chiffres sont calculés ICI, jamais par le LLM.

// Toutes les dates sont manipulées en UTC à minuit pour éviter les décalages de fuseau.
const jour = s => new Date(String(s).slice(0, 10) + "T00:00:00Z");
const DATE_REF = jour($env.DATE_REF || new Date().toISOString()); // ex. "2026-06-29" pour tester
const lundi = new Date(DATE_REF);
lundi.setUTCDate(lundi.getUTCDate() - ((lundi.getUTCDay() + 6) % 7)); // lundi de la semaine en cours
const debutN = new Date(lundi); debutN.setUTCDate(debutN.getUTCDate() - 7);    // lundi précédent
const debutN1 = new Date(lundi); debutN1.setUTCDate(debutN1.getUTCDate() - 14);

const lignes = $input.all().map(i => i.json);
const num = v => Number(String(v).replace(/\s/g, "").replace(",", "."));   // "1 078,20" → 1078.2
const dans = (l, d1, d2) => { const d = jour(l.date); return d >= d1 && d < d2; };

const semN  = lignes.filter(l => dans(l, debutN, lundi));
const semN1 = lignes.filter(l => dans(l, debutN1, debutN));
const somme = arr => Math.round(arr.reduce((s, l) => s + num(l.montant_ht), 0) * 100) / 100;
const parCle = (arr, cle) => {
  const m = {};
  for (const l of arr) m[l[cle]] = (m[l[cle]] || 0) + num(l.montant_ht);
  return Object.entries(m).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ nom: k, ca: Math.round(v * 100) / 100 }));
};

const caN = somme(semN), caN1 = somme(semN1);
const variation = caN1 === 0 ? null : Math.round((caN - caN1) / caN1 * 1000) / 10;
const avoirs = semN.filter(l => num(l.quantite) < 0).length;
const fmt = d => d.toISOString().slice(0, 10);

return [{ json: { kpi: {
  periode: { debut: fmt(debutN), fin: fmt(new Date(lundi - 1)) },
  nb_lignes_semaine: semN.length,
  ca_semaine: caN,
  ca_semaine_precedente: caN1,
  variation_pct: variation,            // null si pas de référence
  cumul_semestre: somme(lignes),       // toutes les lignes de la feuille
  avoirs_semaine: avoirs,
  top_commerciaux: parCle(semN, "commercial"),
  top_produits: parCle(semN, "produit"),
  alerte: semN.length === 0 ? "Aucune ligne cette semaine : vérifier la source" : null
} } }];
```

Testé sur Mobidesk avec `DATE_REF = 2026-06-29` : semaine du 22 au 28 juin → 1 ligne, **1 078,20 €** (Léa Martin, Lampe Halo), semaine précédente 2 443,00 €, variation **−55,9 %**, cumul 33 500,00 €, zéro avoir. Vérifiez ces quatre chiffres à la main avant d'aller plus loin : c'est votre jeu de test, exactement comme en leçon 57.

Deux détails qui évitent des heures de débogage : la fonction `num` convertit les montants que Google Sheets peut renvoyer en texte avec virgule ; et l'`alerte` sur semaine vide empêche d'envoyer un rapport à 0 € un lundi où la synchronisation a échoué.

## 4. Étape 4 : le prompt de rédaction

Le sous-nœud modèle peut être Anthropic (Claude Haiku 5.5 suffit largement pour ce travail de rédaction : 0,10 $ / 0,50 $ par million de tokens en entrée / sortie, nov. 2026), OpenAI, Mistral, ou un modèle local via Ollama (module 10) si les chiffres ne doivent pas quitter l'entreprise. Le prompt est le même :

```text
Tu es l'assistant du directeur commercial de Mobidesk. Tu rédiges le rapport hebdomadaire
à partir du JSON ci-dessous. Tous les chiffres y sont déjà calculés et vérifiés.

RÈGLES STRICTES :
- Utilise UNIQUEMENT les chiffres du JSON, recopiés tels quels (deux décimales, format
  « 1 078,20 € », pourcentage « −55,9 % »). N'effectue aucun calcul, aucune estimation.
- Si variation_pct est null, écris « pas de semaine de référence » sans inventer.
- Si avoirs_semaine > 0, mentionne-le dans les points d'attention.
- Si alerte n'est pas null, le rapport se limite à : « Rapport non généré : » + alerte.
- Aucune information externe au JSON (pas de contexte marché, pas de saison).
- Ton factuel, 120 mots maximum, sans adjectif.

FORMAT :
Objet : Mobidesk — ventes semaine du {debut} au {fin}
1. Chiffre de la semaine (CA, variation vs semaine précédente, cumul semestre)
2. Faits marquants (commercial et produit en tête, avec montants)
3. Points d'attention (avoirs, semaine faible, absence de données)

JSON :
{{ JSON.stringify($json.kpi, null, 2) }}
```

L'expression `{{ JSON.stringify($json.kpi, null, 2) }}` injecte le résultat du nœud Code dans le prompt. La contrainte « recopiés tels quels » est la clé : le modèle ne traduit pas 1078.2 en « environ 1 100 € », il écrit 1 078,20 €. Pour obtenir ce format français, le plus sûr est de **formater les chiffres dans le nœud Code** (chaînes « 1 078,20 € » déjà prêtes) plutôt que de confier le formatage au modèle.

> ⚠️ **Piège fréquent** — Le prompt dit « compare avec la semaine précédente » sans fournir la semaine précédente dans le JSON. Le modèle ne dira pas « je ne sais pas » : il produira une comparaison plausible. Tout ce que le rapport doit dire doit être dans le JSON.

## 5. Étape 5 : le contrôle automatique des chiffres recopiés

Même avec un prompt strict, un modèle peut inverser un signe ou mélanger deux montants. Un second nœud Code vérifie que chaque nombre présent dans le texte existe bien dans `kpi` :

```javascript
// Nœud Code — "Contrôle des chiffres du rapport"
const texte = $json.text ?? $json.output ?? "";            // sortie de la Basic LLM Chain
const kpi = $('Calcul des KPI de la semaine').first().json.kpi;

// Tous les nombres autorisés : valeurs du JSON (en valeur absolue, arrondies à 2 décimales)
const autorises = new Set();
const collecter = v => {
  if (typeof v === "number") autorises.add(Math.abs(Math.round(v * 100) / 100));
  else if (v && typeof v === "object") Object.values(v).forEach(collecter);
};
collecter(kpi);

// Nombres trouvés dans le texte (formats « 1 078,20 », « 55,9 », « 33500.00 »),
// après avoir retiré les dates ISO (2026-06-22) et en ignorant les années isolées.
const sansDates = texte.replace(/\d{4}-\d{2}-\d{2}/g, " ");
const trouves = [...sansDates.matchAll(/\d[\d\s\u202f]*(?:[.,]\d+)?/g)]
  .map(m => Number(m[0].replace(/[\s\u202f]/g, "").replace(",", ".")))
  .filter(n => !Number.isNaN(n) && n >= 1 && !(n >= 2000 && n <= 2100));
const inconnus = [...new Set(trouves)].filter(n => !autorises.has(n));

return [{ json: {
  texte,
  controle_ok: inconnus.length === 0,
  chiffres_inconnus: inconnus,
  texte_final: inconnus.length === 0 ? texte
    : texte + `\n\n⚠️ CONTRÔLE AUTOMATIQUE : chiffres non reconnus ${inconnus.join(", ")} — rapport à relire avant diffusion.`
} }];
```

Ensuite, un nœud **IF** sur `controle_ok` : si vrai, Gmail + Slack vers la direction ; si faux, e-mail à la seule personne responsable du reporting, avec l'avertissement. C'est le principe du **humain dans la boucle** (*human in the loop*) documenté par n8n : l'automatisation ne décide pas seule quand quelque chose cloche. Les jours d'un filtre comme celui-ci ne sont pas comptés en heures d'ingénierie mais en réunions évitées.

## 6. Diffusion, erreurs, coût

**Gmail** (*Message → Send*) : destinataire `direction-commerciale@…`, objet repris de la première ligne du texte, corps = `{{ $json.texte_final }}`. Joignez les graphiques de la leçon 56 si votre instance n8n exécute le script Python (nœud *Execute Command* en auto-hébergement) ou produisez-les avec un nœud *QuickChart*. **Slack** (*Message → Post*) : canal `#ventes`, message = les trois premières lignes.

**Error Trigger** : créez un workflow « Alerte reporting » contenant un nœud *Error Trigger* suivi d'un Slack vers `#ops` ; dans les réglages du workflow principal, désignez-le comme *Error Workflow*. Testez-le en coupant volontairement la credential Google.

**Coût (nov. 2026)**. Le prompt pèse environ 900 tokens, la réponse 250. Avec Claude Haiku 5.5 : (900 × 0,10 $ + 250 × 0,50 $) / 1 000 000 ≈ **0,0002 $ par rapport**, soit un centime par an. Le coût réel est celui de l'hébergement n8n (gratuit en auto-hébergement, abonnement Cloud sinon) et du temps de construction : comptez une demi-journée pour un premier workflow robuste. Si vous générez des centaines de rapports (un par agence, par commercial, par client), l'API de traitement par lots de Claude (*Message Batches*, −50 %, résultats en moins d'une heure en général) devient intéressante : vous préparez tous les JSON, vous envoyez le lot le dimanche soir.

**Fiabilité**. Trois contrôles à conserver après la mise en production : (1) un rapport de test envoyé à vous seul pendant deux semaines avant d'ajouter la direction ; (2) une relecture humaine mensuelle d'un rapport pris au hasard, chiffres comparés à la feuille ; (3) un journal des exécutions n8n consulté quand un lundi semble silencieux.

## 7. Variante : le script Python (optionnel)

Si vous n'avez pas n8n, ou si votre service informatique préfère un script planifié (cron sous Linux, Planificateur de tâches Windows), voici l'équivalent complet. Il lit le CSV, calcule les indicateurs, appelle l'API Anthropic (clé dans la variable d'environnement `ANTHROPIC_API_KEY`, SDK `pip install anthropic pandas`), contrôle les chiffres et envoie l'e-mail. Les développeurs du niveau 3 reconnaîtront la structure ; les autres peuvent le faire tourner tel quel.

```python
"""Reporting hebdomadaire Mobidesk — version script.
Usage : DATE_REF=2026-06-29 python reporting_hebdo.py ventes_mobidesk_2026_S1.csv
Variables d'environnement : ANTHROPIC_API_KEY (obligatoire),
  SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, RAPPORT_TO (pour l'envoi ; sinon affichage).
"""
import json
import os
import re
import smtplib
import sys
from datetime import datetime, timedelta
from email.message import EmailMessage

import pandas as pd
from anthropic import Anthropic

MODELE = "claude-haiku-5-5"   # suffisant pour de la rédaction ; nov. 2026

def euros(x: float) -> str:
    return f"{x:,.2f} €".replace(",", "\u202f").replace(".", ",")

def calculer_kpi(df: pd.DataFrame, date_ref: datetime) -> dict:
    """Tous les chiffres sont calculés ici : le modèle ne fera que les recopier."""
    lundi = (date_ref - timedelta(days=date_ref.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    debut_n, debut_n1 = lundi - timedelta(days=7), lundi - timedelta(days=14)
    sem_n = df[(df["date"] >= debut_n) & (df["date"] < lundi)]
    sem_n1 = df[(df["date"] >= debut_n1) & (df["date"] < debut_n)]
    ca_n, ca_n1 = round(sem_n["montant_ht"].sum(), 2), round(sem_n1["montant_ht"].sum(), 2)
    variation = None if ca_n1 == 0 else round((ca_n - ca_n1) / ca_n1 * 100, 1)
    top = lambda col: [{"nom": k, "ca": euros(v)} for k, v in
                       sem_n.groupby(col)["montant_ht"].sum().sort_values(ascending=False).items()]
    return {
        "periode": {"debut": debut_n.date().isoformat(), "fin": (lundi - timedelta(days=1)).date().isoformat()},
        "nb_lignes_semaine": int(len(sem_n)),
        "ca_semaine": euros(ca_n),
        "ca_semaine_precedente": euros(ca_n1),
        "variation_pct": None if variation is None else f"{variation:+.1f} %".replace(".", ",").replace("-", "−"),
        "cumul_semestre": euros(round(df["montant_ht"].sum(), 2)),
        "avoirs_semaine": int((sem_n["quantite"] < 0).sum()),
        "top_commerciaux": top("commercial"),
        "top_produits": top("produit"),
        "alerte": "Aucune ligne cette semaine : vérifier la source" if len(sem_n) == 0 else None,
    }

PROMPT = """Tu es l'assistant du directeur commercial de Mobidesk. Rédige le rapport hebdomadaire
à partir du JSON ci-dessous, dont tous les chiffres sont déjà calculés et formatés.
RÈGLES : recopie les chiffres tels quels, sans calcul ni estimation ; si variation_pct est null,
écris « pas de semaine de référence » ; si alerte n'est pas null, réponds uniquement
« Rapport non généré : » suivi de l'alerte ; aucune information externe ; 120 mots maximum.
FORMAT : ligne 1 « Objet : Mobidesk — ventes semaine du {debut} au {fin} », puis
1. Chiffre de la semaine  2. Faits marquants  3. Points d'attention.
JSON :
"""

def rediger(kpi: dict) -> str:
    client = Anthropic()  # lit ANTHROPIC_API_KEY dans l'environnement
    reponse = client.messages.create(
        model=MODELE, max_tokens=600,
        messages=[{"role": "user", "content": PROMPT + json.dumps(kpi, ensure_ascii=False, indent=2)}],
    )
    return "".join(bloc.text for bloc in reponse.content if bloc.type == "text")

def controler(texte: str, kpi: dict) -> list[str]:
    """Renvoie les montants du texte absents du JSON (chiffre inventé, inversé, arrondi...).
    Les espaces (normaux ou insécables) sont ignorés : « 1 078,20 » et « 1078,20 » sont équivalents."""
    motif = r"\d[\d \u202f\u00a0]*,\d{2}"
    normaliser = lambda s: re.sub(r"[ \u202f\u00a0]", "", s)
    autorises = {normaliser(m) for m in re.findall(motif, json.dumps(kpi, ensure_ascii=False))}
    trouves = {normaliser(m) for m in re.findall(motif, texte)}
    return sorted(trouves - autorises)

if __name__ == "__main__":
    df = pd.read_csv(sys.argv[1] if len(sys.argv) > 1 else "ventes_mobidesk_2026_S1.csv", parse_dates=["date"])
    date_ref = datetime.fromisoformat(os.environ.get("DATE_REF", datetime.now().date().isoformat()))
    kpi = calculer_kpi(df, date_ref)
    texte = rediger(kpi)
    inconnus = controler(texte, kpi)
    if inconnus:
        texte += f"\n\n⚠️ CONTRÔLE AUTOMATIQUE : montants non reconnus {', '.join(inconnus)} — à relire avant diffusion."
    if os.environ.get("RAPPORT_TO") and not inconnus:
        msg = EmailMessage()
        msg["Subject"] = texte.splitlines()[0].replace("Objet : ", "")
        msg["From"], msg["To"] = os.environ["SMTP_USER"], os.environ["RAPPORT_TO"]
        msg.set_content(texte)
        with smtplib.SMTP(os.environ["SMTP_HOST"], int(os.environ.get("SMTP_PORT", "587"))) as s:
            s.starttls(); s.login(os.environ["SMTP_USER"], os.environ["SMTP_PASSWORD"]); s.send_message(msg)
        print("Rapport envoyé.")
    else:
        print(texte)
```

Remarquez que les montants sont **formatés avant** d'être envoyés au modèle (« 1 078,20 € ») : le contrôle final n'a plus qu'à vérifier que chaque montant du texte existe dans le JSON. Un chiffre inventé ou inversé est attrapé avant l'envoi.

> 🔗 **Documentation officielle** — [Claude Platform — Get started](https://platform.claude.com/docs/en/get-started) 🇬🇧 (installation du SDK, clé API) ; [Pricing](https://platform.claude.com/docs/en/about-claude/pricing) 🇬🇧 ; [Batch processing](https://platform.claude.com/docs/en/build-with-claude/batch-processing) 🇬🇧.

## 🧪 Exercice pratique

**Consigne — projet de fin de module.** Construisez le reporting hebdomadaire Mobidesk, dans n8n (recommandé) ou avec le script Python.

1. Importez le CSV Mobidesk dans une feuille Google Sheets nommée `ventes` (ou gardez le CSV pour le script).
2. Assemblez les six étapes de la section 2 : Schedule Trigger (lundi 7 h 30, Europe/Paris), Google Sheets, Code KPI, Basic LLM Chain avec le modèle de votre choix, Code de contrôle, IF, Gmail et Slack (ou seulement Gmail vers vous-même).
3. Testez avec la date de référence `2026-06-29` : le rapport doit annoncer 1 078,20 € pour la semaine du 22 au 28 juin, 2 443,00 € la semaine précédente, −55,9 %, cumul 33 500,00 €.
4. Testez avec `2026-05-04` (semaine du 27 avril au 3 mai : l'avoir C-1016, −349,00 €) : le rapport doit mentionner l'avoir et une semaine négative.
5. Testez avec `2026-08-03` (aucune vente) : le rapport doit se limiter à « Rapport non généré : … ».
6. Provoquez une erreur (credential Google désactivée) et vérifiez que l'Error Trigger envoie l'alerte.
7. Livrez : l'export JSON du workflow (ou le script), trois captures des trois rapports, et une note d'une demi-page : coût mensuel estimé, contrôles humains prévus, ce que vous feriez pour passer de Google Sheets à la vraie base de facturation.

**Critères de réussite.**
- Les quatre chiffres du test 3 sont exacts et recopiés tels quels dans le texte.
- Le test 4 mentionne explicitement l'avoir ; le test 5 ne produit aucun chiffre inventé.
- Aucun chiffre du rapport n'est calculé par le modèle (le JSON `kpi` contient tout).
- Le contrôle automatique et l'Error Trigger fonctionnent (preuve par capture).
- La note chiffre le coût et nomme au moins deux contrôles humains.

**Pistes de corrigé.** Semaine du 27 avril au 3 mai : une seule ligne, C-1016, CA −349,00 € ; semaine précédente (20–26 avril) : 1 110,00 € ; variation −131,4 %. Un modèle qui écrit « baisse de 131 % » recopie correctement ; un modèle qui écrit « le CA est nul » ou « environ −350 € » viole la règle et doit être attrapé par le contrôle (−350,00 n'est pas dans le JSON). Pour le passage à la vraie base : remplacer le nœud Google Sheets par un nœud Postgres avec la requête « CA par ligne depuis 15 jours » validée en leçon 57, sur un compte en lecture seule.

## ✅ Auto-évaluation express

1. Pourquoi ne pas envoyer les 24 lignes au modèle et lui demander directement le rapport ?
2. Que doit contenir le JSON transmis au modèle pour qu'il puisse « comparer avec la semaine précédente » ?
3. Le contrôle automatique signale un chiffre inconnu « 2 433,00 ». Que s'est-il probablement passé et que fait le workflow ?

**Réponses.** 1) Parce que les chiffres calculés par un modèle ne sont pas garantis et qu'un rapport automatique n'est relu par personne ; le code calcule, le modèle rédige. 2) Le CA de la semaine précédente et, idéalement, la variation déjà calculée ; tout ce que le rapport affirme doit être dans le JSON. 3) Le modèle a probablement recopié 2 443,00 € avec une faute de frappe (inversion de chiffres) ; `controle_ok` est faux, l'IF route le rapport vers le responsable avec l'avertissement au lieu de la direction.

## 📚 Pour aller plus loin
- [n8n Academy — N8N103 In Practice: AI, Testing & Best Practices](https://learn.n8n.io/courses/course-v1:n8n+N8N103+2026H2/about) 🇬🇧 — nœuds IA, tests, Try/Catch, monitoring ; le cours à suivre après ce module (badge de complétion n8n).
- [n8n Docs — Human in the loop for tools](https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md) 🇬🇧 — faire valider une étape par un humain.
- [Claude Platform — Batch processing](https://platform.claude.com/docs/en/build-with-claude/batch-processing) 🇬🇧 — générer des centaines de rapports à moitié prix.
- [n8n Docs — Data Tables](https://docs.n8n.io/build/work-with-data/data-tables.md) 🇬🇧 — conserver l'historique des KPI hebdomadaires sans base externe.
