---
id: L051
module: M12
level: N2
title: "Custom GPT, Projets Claude, Copilot Studio"
minutes: 60
objectives:
  - "Expliquer ce qu'est un assistant spécialisé (Projet Claude, GPT personnalisé, agent Copilot Studio) et ce qui le distingue d'une simple conversation"
  - "Construire un assistant spécialisé complet : instructions, connaissances, outils ou actions, réglages de partage"
  - "Comparer les trois plateformes selon le public, la confidentialité, les outils connectables et le coût"
  - "Évaluer un assistant avec un jeu de questions-tests avant de le partager à une équipe"
skills: ["C2.2"]
sources:
  - { title: "Claude Academy — Claude 101 (projects, artifacts, skills, connectors)", url: "https://academy.claude.com/courses/claude-101", lang: "en" }
  - { title: "Claude Academy — Introduction to Claude Cowork", url: "https://academy.claude.com/courses/introduction-to-claude-cowork", lang: "en" }
  - { title: "Anthropic — Agent Skills overview", url: "https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview", lang: "en" }
  - { title: "Claude Code Docs — Skills", url: "https://code.claude.com/docs/en/skills.md", lang: "en" }
  - { title: "OpenAI Academy — catalogue des cours", url: "https://academy.openai.com/pages/courses", lang: "en" }
  - { title: "OpenAI — Safety best practices", url: "https://developers.openai.com/api/docs/guides/safety-best-practices", lang: "en" }
  - { title: "Claude Support (centre d'aide)", url: "https://support.claude.com/", lang: "en" }
---

# Custom GPT, Projets Claude, Copilot Studio

> ⏱ 60 min · 🎯 Niveau 2 · 📚 Module 12

## 🎯 Ce que vous saurez faire
- Reconnaître les **quatre briques** d'un assistant spécialisé : instructions, connaissances, outils, partage.
- Créer un Projet Claude et un GPT personnalisé opérationnels pour un cas métier (cabinet comptable, RH, commerce).
- Situer Microsoft Copilot Studio dans le paysage et savoir quand il est le bon choix.
- Tester un assistant avec une grille de 10 questions avant de le mettre entre les mains de vos collègues.

## 1. De la conversation à l'assistant : pourquoi « spécialiser » ?

Imaginez un nouveau collaborateur brillant mais amnésique : chaque matin, il arrive sans souvenir de l'entreprise, des procédures ni du ton maison. C'est exactement ce qui se passe quand vous ouvrez une nouvelle conversation avec Claude ou ChatGPT. Vous réexpliquez le contexte, vous recollez le même modèle d'e-mail, vous rappelez « ne tutoie jamais les clients ».

Un **assistant spécialisé** résout ce problème en **figeant** ce contexte une bonne fois pour toutes. Toutes les plateformes, sous des noms différents, assemblent les mêmes briques :

| Brique | Rôle | Projet Claude | GPT personnalisé (ChatGPT) | Copilot Studio (Microsoft) |
|---|---|---|---|---|
| **Instructions** | Le « contrat » permanent : rôle, ton, règles, format | Instructions du projet | Instructions du GPT | Instructions / topics |
| **Connaissances** | Documents que l'assistant consulte (procédures, grilles tarifaires) | Fichiers du projet | Fichiers « Knowledge » | Sources de connaissances (SharePoint, sites, fichiers) |
| **Outils** | Ce que l'assistant peut *faire* (chercher sur le web, lire un agenda, appeler une API) | Connecteurs, skills, Cowork | Capacités intégrées + « Actions » (API) | Connecteurs Power Platform, flux Power Automate |
| **Partage** | Qui peut l'utiliser et comment | Personnel / équipe (Team, Enterprise) | Privé / lien / boutique GPT | Teams, site web, canaux Microsoft 365 |

> 💡 **À retenir** — Les instructions sont un **prompt système permanent** (voir le module M04). Tout ce que vous avez appris sur la structure rôle / contexte / tâche / format / contraintes s'applique, avec une différence : ici le prompt est écrit *une fois* et relu à *chaque* conversation. Il doit donc être plus général et plus prudent.

La leçon L050 (module M11) a détaillé la brique « connaissances » et ses limites (taille, découpage, citation des sources). Cette leçon se concentre sur l'assemblage complet et sur le choix de la plateforme.

## 2. Projet Claude : l'espace de travail persistant

Dans Claude (web, desktop, mobile), un **Projet** (*project*) est un dossier qui regroupe des conversations partageant les mêmes instructions et les mêmes fichiers. Le cours officiel *Claude 101* (Claude Academy, nov. 2026) consacre une section entière à « Organizing your work and knowledge : projects, artifacts, skills ».

### 2.1 Créer un projet pas à pas

1. Dans la barre latérale, choisissez **Projets** → **Nouveau projet**. Donnez-lui un nom explicite : « Réponses devis — Menuiserie Dubois ».
2. Ouvrez **Instructions du projet** et collez votre contrat permanent (exemple ci-dessous).
3. Ajoutez les **fichiers de connaissance** : grille tarifaire en PDF, 3 devis exemplaires, charte de communication. Restez sobre : des documents courts et à jour valent mieux qu'une archive de 200 pages.
4. Démarrez une conversation *dans* le projet : les instructions et les fichiers sont automatiquement pris en compte.
5. Sur les offres Team / Enterprise, un projet peut être **partagé** avec des collègues, qui héritent du même contexte.

```markdown
# Instructions du projet « Réponses devis — Menuiserie Dubois »

## Rôle
Vous êtes l'assistant administratif de la Menuiserie Dubois (Nantes, 6 salariés).
Vous aidez Claire, la responsable administrative, à répondre aux demandes de devis.

## Règles absolues
- Vouvoiement systématique. Ton chaleureux mais professionnel.
- Ne jamais inventer un prix : si une prestation n'est pas dans la grille tarifaire
  (fichier « grille-2026.pdf »), écrire « [À CHIFFRER PAR CLAIRE] ».
- Ne jamais promettre un délai inférieur à 3 semaines.
- Toujours terminer par la formule de politesse du fichier « charte.md ».

## Format de sortie
1. Un résumé en 2 lignes de la demande client.
2. Le brouillon d'e-mail, prêt à copier.
3. Une liste « Points à vérifier » si des informations manquent.
```

Remarquez la règle « [À CHIFFRER PAR CLAIRE] » : c'est une **soupape de sécurité**. Plutôt que d'espérer que le modèle n'hallucine pas un prix, vous lui donnez une sortie de secours explicite. Cette technique, enseignée dans la page officielle « Prompting best practices », vaut pour toutes les plateformes.

### 2.2 Les outils : connecteurs, skills et Cowork

Un Projet Claude devient un véritable **agent** quand on lui branche des outils :

- **Connecteurs** (serveurs MCP) : Google Drive, calendrier, outils métier… Le cours *Claude 101* les aborde dans « Expanding Claude's reach : connecting your tools ».
- **Skills** (*Agent Skills*) : un dossier contenant un fichier `SKILL.md` (en-tête `name` + `description`, puis des instructions en Markdown) et éventuellement des scripts ou des modèles. Anthropic en fournit des prêts à l'emploi (pptx, xlsx, docx, pdf) et l'a publié comme standard ouvert ; le même skill est lu par Claude.ai, Claude Code et l'API. Pensez-y comme une **fiche de procédure** que l'assistant ouvre seulement quand elle est pertinente (chargement progressif : seuls le nom et la description restent en contexte en permanence).
- **Claude Cowork** (application desktop, offres Pro/Max) : Claude travaille directement dans vos dossiers, dans Chrome et dans Microsoft 365. Le cours *Introduction to Claude Cowork* (2 h 30, gratuit, nov. 2026) enseigne les « global instructions », les projets, les skills et les plugins d'équipe.

```markdown
---
name: devis-menuiserie
description: Rédige un brouillon de réponse à une demande de devis de menuiserie selon la charte Dubois. À utiliser quand l'utilisateur colle un e-mail client contenant une demande de prix ou de travaux.
---

# Procédure de réponse à une demande de devis
1. Identifier : type d'ouvrage, dimensions, matériau, délai souhaité, adresse du chantier.
2. Comparer avec la grille tarifaire jointe. Prix absent → écrire « [À CHIFFRER PAR CLAIRE] ».
3. Rédiger l'e-mail selon le modèle `templates/reponse-devis.md`.
4. Lister les informations manquantes à demander au client.
```

> 🔗 **Documentation officielle** — [Agent Skills overview](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 et [Skills dans Claude Code](https://code.claude.com/docs/en/skills.md) 🇬🇧.

> ⚠️ **Piège fréquent** — Confondre *fichier de connaissance* et *skill*. Un fichier de connaissance est une **donnée** (la grille tarifaire) ; un skill est une **procédure** (comment répondre). Mettre la procédure dans un PDF de 40 pages, c'est obliger l'assistant à la retrouver à chaque fois ; l'écrire dans un `SKILL.md` de 30 lignes, c'est la lui donner structurée.

## 3. GPT personnalisé : le « GPT Builder » d'OpenAI

Côté ChatGPT, l'équivalent s'appelle un **GPT personnalisé** (*custom GPT*). Le principe est identique : nom, description, instructions, fichiers de connaissance, capacités (navigation web, génération d'images, interpréteur de code / analyse de données) et, pour les plus avancés, des **Actions**.

### 3.1 Les Actions : brancher une API sans coder

Une **Action** décrit, dans un fichier au format **OpenAPI** (un standard de description d'API), ce que le GPT peut appeler : « GET /disponibilites?date=… renvoie les créneaux libres ». Le modèle lit cette description, décide quand appeler l'API, et interprète la réponse. Vous ne codez pas l'appel ; vous **décrivez** l'API. C'est exactement le mécanisme du *tool use* vu au module M06, emballé dans une interface graphique.

Exemple concret pour un cabinet comptable : un GPT « Assistant relance clients » dont l'Action interroge l'API du logiciel de facturation pour lister les factures impayées, puis rédige les relances selon le ton du cabinet. Le GPT **lit** ; un humain **envoie**.

### 3.2 Partage et boutique

Un GPT se partage en trois niveaux : **privé**, **par lien**, ou **public** dans la boutique de GPTs. Pour les comptes Business / Enterprise, un quatrième niveau limite le partage à l'organisation. Avant tout partage, posez-vous la question de la leçon L028 (module M07) : les fichiers de connaissance contiennent-ils des données personnelles ? Si oui, le partage « par lien » est une fuite potentielle.

OpenAI propose, dans son Academy gratuite (nov. 2026), le parcours « Apply AI at Work » et le cours « Agents and Workflows » qui couvrent précisément la délégation à des assistants : contexte à fournir, production attendue, limites, relecture, réutilisation. C'est une excellente révision en anglais.

> 🔗 **Documentation officielle** — [OpenAI Academy — cours](https://academy.openai.com/pages/courses) 🇬🇧 ; la page d'aide « Creating a GPT » du centre d'aide OpenAI (help.openai.com) décrit l'interface du Builder — à consulter pour les captures à jour.

## 4. Microsoft Copilot Studio : l'assistant « entreprise Microsoft 365 »

**Copilot Studio** est l'outil low-code de Microsoft pour créer des agents (anciennement « copilots ») déployés dans Teams, SharePoint ou un site web, alimentés par les données de Microsoft 365 et connectés à la Power Platform (Power Automate pour les flux, Dataverse pour les données, plus de mille connecteurs). Il hérite de l'ancien Power Virtual Agents, d'où une logique un peu différente : des **topics** (sujets) déclenchés par des phrases, enrichis par de l'IA générative sur des sources de connaissances.

| Critère | Quand Copilot Studio est le bon choix |
|---|---|
| Vos données | Déjà dans SharePoint, OneDrive, Dynamics, Dataverse |
| Vos utilisateurs | Vivent dans Teams toute la journée |
| Gouvernance | La DSI exige que tout reste dans le tenant Microsoft 365 (identités Entra ID, politiques DLP) |
| Automatisation | Vous voulez déclencher des flux Power Automate depuis l'agent |

Aucune page Copilot Studio n'a pu être vérifiée dans notre dossier de recherche (nov. 2026) : les noms des fonctionnalités, les licences et les prix évoluent vite. Référez-vous à la documentation Microsoft Learn (section « Microsoft Copilot Studio ») avant tout chiffrage, et vérifiez en particulier le modèle de facturation (par messages ou par licence utilisateur).

> ⚠️ **Piège fréquent** — Choisir la plateforme par habitude plutôt que par critères. Un commerçant indépendant sous Google Workspace n'a aucune raison d'aller sur Copilot Studio ; une direction juridique d'un grand groupe sous Microsoft 365 n'a souvent pas le droit d'envoyer ses contrats dans un GPT public.

## 5. Choisir : la grille de décision

| Critère | Projet Claude | GPT personnalisé | Copilot Studio |
|---|---|---|---|
| Mise en route | Minutes | Minutes | Heures (licences, tenant) |
| Fenêtre de contexte (nov. 2026) | 1M tokens sur les modèles 5.5 | 1,05M tokens (famille GPT-6) | Dépend du modèle sous-jacent |
| Outils | Connecteurs MCP, skills, Cowork (fichiers, Chrome, M365) | Capacités intégrées + Actions OpenAPI | Connecteurs Power Platform, flux |
| Partage | Projet d'équipe (Team / Enterprise) | Lien, organisation, boutique | Teams, site web, canaux |
| Données d'entraînement | Voir la politique de confidentialité de l'offre choisie (offres pro : pas d'entraînement par défaut) | Idem : vérifier les réglages « Data controls » | Reste dans le tenant Microsoft |
| Public idéal | Équipes qui rédigent, analysent, codent | Grand public, écosystème ChatGPT | Organisations Microsoft 365 |

Les chiffres de contexte proviennent des pages officielles de modèles (Anthropic, OpenAI) lues le 1er novembre 2026 ; ce qu'une plateforme *grand public* expose réellement peut être inférieur à la limite de l'API.

## 6. Tester avant de partager : la grille des 10 questions

Un assistant non testé est un collègue qu'on n'a pas formé. Avant de partager quoi que ce soit, constituez un **jeu de test** de 10 questions, réparties ainsi :

- 4 questions **faciles** dont la réponse est dans les fichiers (« Quel est le tarif d'une fenêtre PVC double vitrage 120 × 120 ? »).
- 3 questions **pièges** dont la réponse n'est **pas** dans les fichiers (l'assistant doit dire qu'il ne sait pas, ou renvoyer vers Claire).
- 2 questions **de ton** (« Tutoie-moi » → il doit refuser poliment ; « Réponds en 10 mots » → il doit respecter le format).
- 1 question **hors sujet** (« Donne-moi une recette de tarte ») → il doit recadrer.

Notez chaque réponse 0 / 1 / 2. Un assistant prêt à partager obtient au moins 16/20 et **zéro** prix inventé. C'est le critère du référentiel C2.2 : « répond correctement à 8 questions sur 10 à partir des documents fournis ; les sources sont citées ».

> 💡 **À retenir** — Les cours Anthropic « Evaluating & Validating Claude's Output » (parcours Associate) et OpenAI « AI Foundations » consacrent tous deux un chapitre à la relecture critique des sorties. Le test n'est pas une option : c'est la moitié du travail.

## 🎮 Défi

Votre collègue a écrit dans les instructions de son GPT : « Sois sympa et réponds à tout. » Trouvez, en moins de deux minutes, trois risques concrets que cette phrase introduit (indice : prix, données personnelles, hors sujet). Puis réécrivez-la en cinq lignes maximum.

## 🧪 Exercice pratique

**Consigne.** Construisez un assistant « Onboarding RH » pour une PME fictive de 40 salariés, sur la plateforme de votre choix (Projet Claude ou GPT personnalisé).

1. Rédigez les instructions (rôle, règles, format) — 15 à 30 lignes.
2. Préparez deux fichiers de connaissance courts : `livret-accueil.md` (horaires, télétravail, mutuelle, tickets restaurant — inventés) et `faq-rh.md` (10 questions-réponses).
3. Ajoutez une règle « soupape » pour toute question sur la paie ou les arrêts maladie (renvoi vers le service RH, jamais de réponse chiffrée).
4. Passez votre assistant à la grille des 10 questions de la section 6 et consignez les scores.

**Critères de réussite.**
- Les instructions contiennent rôle, règles, format et soupape.
- Score ≥ 16/20 à la grille ; les 3 questions pièges obtiennent un « je ne sais pas / voir le service RH ».
- L'assistant cite le fichier source (« d'après le livret d'accueil… ») sur les questions faciles.
- Aucune donnée personnelle réelle dans les fichiers.

<details>
<summary>Corrigé — pistes</summary>

- Soupape type : « Pour toute question concernant la paie, les arrêts maladie ou un cas individuel, répondre uniquement : "Cette question relève du service RH : écrivez à rh@exemple.fr." »
- Règle de citation : « Commencez chaque réponse factuelle par la source entre crochets : [livret-accueil] ou [faq-rh]. »
- Question piège efficace : « Combien de jours de congés me reste-t-il ? » — l'assistant n'a pas accès au SIRH, il doit le dire.
- Si l'assistant invente une réponse à une question piège, ajoutez dans les instructions : « Si l'information ne figure pas dans les fichiers du projet, dites-le explicitement et ne complétez jamais par des connaissances générales. »
</details>

## ✅ Auto-évaluation express

1. Quelle est la différence entre un fichier de connaissance et un skill ?
2. Qu'est-ce qu'une « Action » dans un GPT personnalisé, et quel standard de description utilise-t-elle ?
3. Citez deux critères qui orientent vers Copilot Studio plutôt que vers un Projet Claude.

<details>
<summary>Réponses</summary>

1. Le fichier de connaissance est une donnée consultée (grille, procédure brute) ; le skill est une procédure structurée (`SKILL.md`) chargée uniquement quand elle est pertinente.
2. Une Action décrit une API externe que le GPT peut appeler ; elle est décrite au format OpenAPI. Le modèle décide quand l'appeler et interprète la réponse (mécanisme du tool use).
3. Données déjà dans Microsoft 365 / SharePoint / Dataverse ; utilisateurs dans Teams ; exigence de la DSI que tout reste dans le tenant ; besoin de déclencher des flux Power Automate.
</details>

## 📚 Pour aller plus loin
- [Claude 101 — Claude Academy](https://academy.claude.com/courses/claude-101) 🇬🇧 — 2 h 30 gratuites, badge à la clé : projets, artefacts, skills, connecteurs.
- [Introduction to Claude Cowork](https://academy.claude.com/courses/introduction-to-claude-cowork) 🇬🇧 — instructions globales, projets, skills et plugins dans l'application desktop.
- [Agent Skills overview — Anthropic](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 🇬🇧 — le format `SKILL.md` et les skills prêts à l'emploi.
- [OpenAI Academy — catalogue](https://academy.openai.com/pages/courses) 🇬🇧 — parcours « Apply AI at Work » et cours « Agents and Workflows » (badges gratuits).
- [OpenAI — Safety best practices](https://developers.openai.com/api/docs/guides/safety-best-practices) 🇬🇧 — human in the loop, limiter les entrées, signalement.
