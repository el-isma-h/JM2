import fs from "node:fs";
import path from "node:path";

export const ROOT = path.resolve(new URL("..", import.meta.url).pathname);
export const LEVEL_DIRS = { N1: "N1-fondamentaux", N2: "N2-praticien", N3: "N3-developpeur", N4: "N4-expert" };

export function slugify(s) {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

export function loadProgramme() {
  return JSON.parse(fs.readFileSync(path.join(ROOT, "programme/programme.json"), "utf8"));
}

export function moduleDir(level, mod) {
  return path.join(ROOT, "niveaux", LEVEL_DIRS[level.id], `${mod.id}-${slugify(mod.title)}`);
}

export function lessonFile(level, mod, lesson) {
  const dir = moduleDir(level, mod);
  if (fs.existsSync(dir)) {
    const found = fs.readdirSync(dir).find((f) => f.startsWith(`${lesson.id}-`) && f.endsWith(".md"));
    if (found) return path.join(dir, found);
  }
  return path.join(dir, `${lesson.id}-${slugify(lesson.title)}.md`);
}

/** Parse un en-tête YAML minimal (clés simples, listes "- ", objets inline { a: b }). */
export function parseFrontmatter(md) {
  const m = md.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
  if (!m) return { data: null, body: md };
  const data = {};
  let currentKey = null;
  for (const raw of m[1].split("\n")) {
    if (!raw.trim()) continue;
    const list = raw.match(/^\s+-\s+(.*)$/);
    if (list && currentKey) {
      (data[currentKey] ||= []).push(parseScalar(list[1]));
      continue;
    }
    const kv = raw.match(/^([A-Za-z_][\w-]*):\s*(.*)$/);
    if (kv) {
      currentKey = kv[1];
      const v = kv[2].trim();
      if (v === "") data[currentKey] = [];
      else if (v.startsWith("[") && v.endsWith("]")) data[currentKey] = v.slice(1, -1).split(/,(?![^{]*})/).map((x) => parseScalar(x.trim())).filter((x) => x !== "");
      else data[currentKey] = parseScalar(v);
    }
  }
  return { data, body: m[2] };
}

function parseScalar(v) {
  v = v.trim();
  if (/^".*"$/.test(v) || /^'.*'$/.test(v)) return v.slice(1, -1);
  if (/^\{.*\}$/.test(v)) {
    const o = {};
    for (const part of v.slice(1, -1).split(/,(?=\s*[a-zA-Z_]+\s*:)/)) {
      const kv = part.match(/^\s*([a-zA-Z_]+)\s*:\s*(.*)$/);
      if (kv) o[kv[1]] = parseScalar(kv[2]);
    }
    return o;
  }
  if (/^-?\d+(\.\d+)?$/.test(v)) return Number(v);
  if (v === "true") return true;
  if (v === "false") return false;
  return v;
}

export function wordCount(s) {
  return s.replace(/```[\s\S]*?```/g, " ").split(/\s+/).filter(Boolean).length;
}

export function fmtHours(min) {
  const h = Math.floor(min / 60), m = min % 60;
  return m ? `${h} h ${String(m).padStart(2, "0")}` : `${h} h`;
}
