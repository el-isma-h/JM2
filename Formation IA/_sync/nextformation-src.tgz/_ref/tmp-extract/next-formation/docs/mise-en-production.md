# Mise en production : Next Formation sur le serveur Nika Holding

Domaine : `formation.nikaholding.world`. Le serveur est Hetzner, avec Caddy en frontal et le PostgreSQL de l'hôte. Tout se lance depuis le Mac.

## 1. Avant le premier déploiement

- Docker Desktop doit être démarré sur le Mac (pour la construction de l'image linux/amd64).
- L'accès SSH `root@188.245.54.227` doit fonctionner. Sinon, utilisez `HOST=... bash deploy/nikaholding.sh`.
- L'enregistrement DNS `A formation.nikaholding.world → 188.245.54.227` doit déjà exister. Caddy obtient alors le certificat HTTPS tout seul.

## 2. Déployer (et chaque mise à jour)

```bash
cd ~/Desktop/JM/"Next Formation"
bash deploy/nikaholding.sh
```

Le script est idempotent. Il fait les opérations suivantes :

1. Il construit l'image et la transfère sur le serveur.
2. Au premier passage seulement, il crée la base, le dossier `/opt/nextformation` et le fichier `.env` avec des secrets générés sur le serveur. Ces secrets ne sont jamais affichés.
3. Il démarre le conteneur. Les migrations, le compte administrateur et les données de référence sont créés au démarrage.
4. Il configure Caddy et la tâche cron (chaque minute).
5. Il vérifie `/api/health`, `/robots.txt`, `/sitemap.xml` et le catalogue public Excellentia.

Le mot de passe administrateur se récupère avec la commande affichée à la fin du script. Changez-le après la première connexion.

> Si le serveur a déjà un `/opt/nextformation/.env` issu d'un déploiement précédent, il est conservé tel quel. Retirez la ligne `SKIP_CONFIG_CHECK=1` si elle y figure : le contrôle de configuration n'exige plus Resend. Les lignes `ANTHROPIC_API_KEY`, `RESEND_API_KEY`, `MAIL_FROM` et `MAIL_ENABLED` doivent être vides ou absentes : une valeur non vide dans `.env` prime sur l'administration.

## 3. Créer Excellentia Formation et ExF Éducation

Une seule fois, après le premier déploiement :

```bash
ssh root@188.245.54.227 "docker exec nextformation npm run setup:excellentia"
```

Cette commande crée :

- le groupe « Excellentia · ExF » ;
- l'organisme Excellentia Formation (OF) et le CFA ExF Éducation, à Toulouse ;
- les 109 formations du catalogue 2026, publiées directement, avec leurs familles, l'éligibilité CPF, les objectifs, la description et la certification associée (TOSA, CléA, TOEIC, Voltaire) ;
- les 5 formations CFA avec leur tarif catalogue ;
- la grille tarifaire ExF dans les paramètres de l'OF.

La commande est relançable sans créer de doublon.

Elle affiche aussi **deux liens d'invitation** pour Essi AYIVOR (`essiayivor@excellentia-formation.fr`), un par organisme, valables 14 jours. Comme l'envoi d'e-mails est coupé, transmettez-les-lui vous-même. En les acceptant, elle devient **propriétaire** de chaque organisme (rôle direction). Si vous relancez la commande, de nouveaux liens sont générés et les anciens cessent de fonctionner.

Restent à compléter dans Paramètres, car ces informations n'ont pas été fournies : SIRET, NDA, UAI du CFA, adresse exacte, numéro Qualiopi, durées des formations (laissées à 0 h), codes RNCP des titres CFA, et lien d'avis Google.

**Grille tarifaire, rattachement à valider avec la cliente.** Les catégories suivantes sont une proposition de ma part :

| Catégorie | Familles rattachées |
|---|---|
| Cadres et dirigeants | « Formations pour les cadres et dirigeants » |
| Techniques | Bureautique, Solutions numériques, Comptabilité et Gestion, Sécurité, Santé, CléA numérique |
| Générales | Langues, Management et RH, Développement professionnel, Commerce et Vente, CléA socle, CléA Management, Pratiques alternatives |

Le rattachement se modifie formation par formation dans le catalogue.

## 4. Clés API (IA, e-mail)

Allez dans **Admin → Clés API** (compte administrateur plateforme) :

- Les clés sont chiffrées en base (AES-256-GCM avec `APP_SECRET`) et appliquées immédiatement, sans redémarrage.
- Elles sont rechargées automatiquement à chaque démarrage.
- Une variable non vide dans `/opt/nextformation/.env` garde la priorité. La page l'indique (« Environnement du serveur »), et il faut alors la vider dans `.env` puis redémarrer.
- Seuls les 4 derniers caractères sont affichés. Aucune clé n'apparaît dans les journaux.
- Pour l'IA, une seule clé suffit (Anthropic, OpenAI ou xAI).
- Pour l'e-mail, plus tard : `RESEND_API_KEY`, `MAIL_FROM` sur un domaine vérifié chez Resend, puis `MAIL_ENABLED=true`. D'ici là, tous les e-mails restent consultables dans **Admin → Boîte d'envoi**.

**Ne changez jamais `APP_SECRET`** : il déchiffre les clés, les IBAN, les NIR et les secrets TOTP. Sauvegardez-le hors du serveur.

## 5. SEO

- Les pages marketing ont leurs balises title, description, canonical, Open Graph et données structurées (Organization, SoftwareApplication, FAQ, fil d'Ariane).
- `/sitemap.xml` est dynamique : il contient les pages marketing et les catalogues publics des organismes clients (hors démonstration).
- `/robots.txt` interdit l'indexation des espaces privés, des API et des widgets embarqués.
- Le catalogue public `/catalogue-public/excellentia` est indexable. Il porte une URL canonique et des données structurées `ItemList` / `Course` pour Google.
- Les espaces privés reçoivent l'en-tête `X-Robots-Tag: noindex`.
- Après la mise en ligne, renseignez `GOOGLE_SITE_VERIFICATION` dans `/opt/nextformation/.env`, redémarrez, puis déclarez le sitemap dans Google Search Console.
- Les mentions légales se renseignent dans `.env` (`LEGAL_*`). Tant qu'elles sont vides, la page affiche « à renseigner ».

## 6. Site Excellentia (WordPress)

Le plugin se trouve dans `integrations/wordpress/next-formation-catalogue/`. Pour l'installer :

1. Zippez ce dossier.
2. Dans WordPress, allez dans Extensions → Ajouter → Téléverser.
3. Dans les réglages, indiquez l'URL `https://formation.nikaholding.world` et l'organisme.
4. Placez le shortcode `[next_formation_catalogue]` dans une page.

Pour un site qui n'est pas sous WordPress, il existe deux options : le widget iframe `/embed/catalogue/excellentia` ou l'API JSON publique (voir le README du plugin). Les formations publiées dans Next Formation apparaissent automatiquement sur le site.

## 7. Sauvegardes et vérification

- Sauvegarde et restauration : Admin → Sauvegardes (voir `docs/sauvegarde.md` s'il est présent). Pensez aussi à sauvegarder `/opt/nextformation/storage`.
- Santé : `curl https://formation.nikaholding.world/api/health`.
- Journaux : `ssh root@188.245.54.227 "docker logs --tail 100 nextformation"`.
