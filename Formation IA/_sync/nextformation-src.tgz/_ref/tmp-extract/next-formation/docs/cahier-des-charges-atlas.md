Gestion intégrée d’un organisme de formation et d’un CFA

Excellentia Formation • ExF Éducation  
Commanditaire : Essi AYIVOR  
Version 1.0 • 23 octobre 2026

## La promesse du produit

À tout moment, chaque membre de l’équipe doit savoir où en est un
dossier, ce qui manque, quelle action lui revient et quelle étape peut
suivre. La direction doit pouvoir piloter l’activité sans reconstituer
les informations dans plusieurs outils.

ATLAS doit prolonger le travail métier déjà construit : une interface
légère, un dossier cohérent de bout en bout, des relais entre personnes,
des documents fiables et des preuves de réalisation traçables. La
qualité se construit au fil du travail quotidien.

## Objet de la consultation

Confier à un développeur professionnel la reprise et la
professionnalisation d’ATLAS, jusqu’à une version exploitable,
sécurisée, documentée et maintenable. Une reconstruction éventuelle doit
être motivée et chiffrée face à une reprise de l’existant. Elle ne peut
entraîner la perte des règles métier, des données ou des historiques.

## Ce que le prestataire doit remettre

- Une proposition par lots : périmètre, exclusions, charges, prix,
  dépendances, calendrier et critères de réception.

- Une application démontrée sur des parcours OF et CFA, accompagnée de
  ses sources, tests, procédures d’exploitation et documentation.

- Une reprise des données contrôlée et un passage de relais permettant
  de changer de prestataire.

## Lecture du document

Pages 2–3 : principes et périmètre. Pages 4–8 : parcours,
fonctionnalités et règles. Pages 9–10 : sécurité et exploitation. Pages
11–12 : recette, livraison et consultation. Page 13 : références et
décisions de cadrage.

Les exigences du socle sont attendues pour la réception. Les options et
valeurs proposées restent à arbitrer avec la commanditaire avant
engagement contractuel.

# 1. Préserver l’esprit d’ATLAS

## Une continuité métier, du premier contact à la clôture

L’application relie entreprises, contacts, besoins, candidats,
placements, inscriptions, parcours, documents, financements et qualité.
Une personne peut avoir plusieurs inscriptions ; une inscription n’est
ni une séance ni une cohorte d’examen. Les liens doivent rester visibles
et fiables.

| Principe                        | Traduction attendue                                                                                                |
|---------------------------------|--------------------------------------------------------------------------------------------------------------------|
| Une saisie utile une seule fois | Réutiliser les coordonnées et données validées ; signaler les doublons sans fusion automatique risquée.            |
| Une prochaine action claire     | Afficher les pièces manquantes, blocages, responsables et échéances directement dans le dossier.                   |
| Des relais entre métiers        | Une étape terminée peut créer une tâche pour le bon destinataire, sans ressaisie et sans notification en double.   |
| Une qualité intégrée            | Relier les preuves aux actions réelles ; distinguer absence de preuve, non-applicabilité et analyse humaine.       |
| Une vérité explicable           | Afficher l’origine, la période, la règle et la date d’actualisation d’un calcul ou d’un indicateur.                |
| Une simplicité quotidienne      | Vocabulaire français, accès rapides, filtres conservés, messages compréhensibles et retour vers le dossier source. |
| Une sécurité discrète et réelle | Montrer les fonctions utiles au rôle ; refuser également les accès non autorisés sur le serveur et en base.        |

## Exemple de fonctionnement attendu

Un commercial qualifie un besoin et associe un candidat. L’administratif
poursuit le même dossier, vérifie ses pièces et son financement. Le
responsable pédagogique prépare le parcours. Le formateur retrouve
seulement ses séances et apprenants autorisés. Les présences alimentent
les heures réalisées. La qualité voit les preuves disponibles et les
actions restant à mener ; la direction suit l’ensemble.

## Autonomie maîtrisée

Les règles automatisées doivent être visibles et configurées par une
personne habilitée. Le système ne doit ni inventer une preuve, ni
déclarer une présence future, ni considérer un document généré comme
signé. Toute dérogation autorisée conserve son motif et son auteur.

# 2. Périmètre et stratégie de reprise

## Socle à livrer

- CRM entreprises et contacts, besoins, candidats et placements ;
  catalogue et sessions ; inscriptions OF/CFA et dossiers associés.

- Planification, groupes, affectations, présences, évaluations, livrets,
  suivi en entreprise et examens.

- Documents, financements, factures et règlements ; qualité, preuves,
  actions et tableaux de bord ; agenda et tâches par personne.

- Gestion des utilisateurs et habilitations, identité institutionnelle,
  journalisation, sauvegarde, import/export et reprise de l’existant.

## Options à chiffrer séparément

Portails apprenant, employeur ou formateur externe étendus ; connexions
Moodle, Microsoft 365, comptabilité ou plateformes métier ; signature
électronique par prestataire ; IA ; paiement en ligne ; application
mobile native. Le prestataire doit identifier les fonctions déjà
présentes pour éviter de facturer une recréation inutile. La
dictée/navigation vocale existante doit être inventoriée et son maintien
proposé explicitement.

## Hors périmètre par défaut

Gestion du coworking, de l’immobilier, de la paie et comptabilité
générale complète ; commercialisation d’un logiciel SaaS à des
organismes tiers. Le socle doit néanmoins conserver son isolation
multi-organismes.

## Reprise avant reconstruction

Le premier lot produit une correspondance entre les exigences de ce
document, les fonctions présentes, les preuves de test et les écarts.
L’analyse porte sur les zones nécessaires à la reprise ; les constats
déjà documentés sont réutilisés. Une réécriture générale ne peut être
décidée par le prestataire seul.

Le prestataire identifie la version source, la version déployée et
l’état SQL réel. Les archives, migrations appliquées manuellement et
historiques CLI doivent être rapprochés avant toute synchronisation. Les
numéros de dossier ou d’archive ne constituent pas une preuve de
version.

## Statut des éléments

| Catégorie                        | Traitement                                                                       |
|----------------------------------|----------------------------------------------------------------------------------|
| Règles métier actées             | À conserver, notamment 0045, 0046, 0061 R3, 0062 et 0063.                        |
| Existant documenté               | À reprendre et démontrer ; présence du code ≠ validation complète en production. |
| Exigence de professionnalisation | À intégrer au devis : tests réels, exploitation, réversibilité, documentation.   |
| Option / arbitrage               | À isoler du prix ferme et à faire décider avant développement.                   |

# 3. Commercial, catalogue et inscriptions

## F01 — Entreprises, contacts, besoins et placement

Gérer les fiches entreprises et contacts, les besoins de recrutement ou
de formation, les échanges et prochaines relances. Associer un candidat
à un besoin, suivre la proposition et le placement, puis réutiliser les
informations dans l’inscription. Conserver les statuts et l’historique
des échanges utiles. Les CV et notes sensibles ne doivent pas être
diffusés à tous les commerciaux par défaut.

## F02 — Catalogue et offres

Décrire formations, versions de programmes, objectifs, prérequis,
modalités, durée, blocs/modules et certifications. Gérer BTS, titres
professionnels, formations courtes et activités retenues au cadrage,
sans coder en dur un diplôme ou un rythme. Une évolution de programme ne
modifie pas rétroactivement un parcours contractualisé.

## F03 — Sessions, cycles et inscriptions

Créer une session ou un cycle, ses dates, son site, sa capacité, ses
modalités et responsables. Inscrire un candidat en réutilisant son
dossier ; gérer les groupes, l’entreprise, le tuteur et le financement
associé. Les rythmes doivent être paramétrables : un jour/quatre jours,
deux jours/huit jours ou autres calendriers réellement retenus.

Distinguer statut commercial, statut d’inscription, progression
pédagogique, financement et examen. Une clôture pédagogique ne signifie
pas automatiquement que le dossier financier est soldé. Les inscriptions
historiques restent consultables et modifiables dans le périmètre
autorisé, avec traçabilité.

## F04 — Dossier central

Présenter une synthèse avec coordonnées, parcours, dates, intervenants,
état administratif, documents, progression, financements et alertes
selon les droits. Séparer les pièces administratives,
commentaires/interventions, informations internes et notes pédagogiques.
La présence d’un rôle pédagogique ne donne pas automatiquement accès aux
pièces administratives.

## Critères de réception

- Un candidat connu peut être inscrit sans recréer sa fiche ; ses
  inscriptions restent distinctes.

- Un changement de groupe ou de session est contrôlé, journalisé et ne
  rattache pas des heures ou pièces au mauvais dossier.

- Un statut enregistré est conservé après rechargement ; un échec laisse
  les données saisies et affiche une cause compréhensible.

- La recherche, le filtrage et les exports respectent le même périmètre
  de droits que les fiches.

# 4. Parcours pédagogique et heures

## F05 — Planification et affectations

Planifier les séances à partir du parcours, des modules, des
disponibilités et fermetures. Affecter formateur, groupe, site et salle.
Détecter les conflits de personnes, groupes et salles avant validation.
Préserver la distinction entre heures prévues, programmées, effectuées,
justifiées et validées ; ne pas les additionner comme si elles étaient
équivalentes.

## F06 — Émargement et verrouillage : règles impératives

- Une séance journalière comporte une ou deux périodes indépendantes ;
  matin et après-midi ont leurs propres horaires, présences, signature
  et clôture.

- La préparation est possible avant la séance. La présence ne peut être
  saisie avant le début réel de la période ; signature de fin et clôture
  ne peuvent intervenir avant sa fin réelle.

- Le serveur est la référence temporelle. Les dates métier utilisent
  Europe/Paris, changements d’heure inclus ; modifier l’horloge du
  navigateur ne contourne aucun contrôle.

- Retards, départs anticipés, absences et justificatifs sont pris en
  compte. La pause méridienne est exclue ; aucune durée n’est comptée
  deux fois.

- Les séances/périodes clôturées et leurs présences ne peuvent être
  modifiées ou supprimées directement. Toute correction exceptionnelle
  suit un circuit tracé à valider au cadrage, sans effacer l’original.

- Les anciennes feuilles journalières restent conservées ; aucune
  signature par demi-journée n’est fabriquée. Les soldes historiques non
  réconciliés restent distincts des heures justifiées.

## F07 — Progression, évaluations et suivi

Relier positionnement, plan individuel, modules/blocs, évaluations et
livret au bon parcours. Distinguer évaluations en cours de formation et
résultat final. Refuser les résultats d’évaluations futures. Gérer le
suivi en entreprise, les échanges avec le tuteur et les actions utiles,
selon le périmètre attribué.

## Critères de réception

Pour une journée 9 h–12 h et 14 h–17 h, une présence complète représente
6 h. Une présence uniquement le matin représente 3 h. La clôture du
matin laisse l’après-midi indépendant. Un changement de module ou une
actualisation de page ne double pas les heures. Un formateur non affecté
ne peut ni lire ni s’attribuer un apprenant en manipulant une présence.

# 5. Examens et gestion documentaire

## F08 — Cohortes d’examen

Créer une cohorte avec formation, code, libellé, date, capacité,
responsable et périmètre : examen complet ou blocs. L’écran de gestion
charge et modifie uniquement la cohorte sélectionnée. L’affectation doit
vérifier formation, admissibilité métier, capacité et absence de
doublon, y compris en cas d’envois simultanés.

Une inscription terminée peut rester éligible à l’examen selon les
règles du parcours. Enregistrer résultat, observations et aménagements
sur le bon membre de la bonne cohorte. Contrôler ce couple côté serveur
; une information transmise par formulaire ne constitue pas une
autorisation. Prévoir les résultats partiels et rattrapages si retenus
au cadrage.

## F09 — Documents du parcours

Produire depuis des modèles les documents effectivement utilisés :
conventions/contrats, convocations, annexe de parcours/planning,
livrets, attestations, certificats de réalisation et documents
financiers selon le périmètre validé. Réutiliser les données du dossier
et l’identité institutionnelle, sans copier les informations d’un autre
organisme.

Gérer les pièces attendues par activité et financement, leur dépôt,
contrôle, acceptation ou refus motivé, version et échéance. Distinguer
brouillon, généré, transmis, signé et validé. Conserver les versions
émises et leur historique ; une régénération ne doit pas remplacer
silencieusement un document déjà signé.

## F10 — Charte institutionnelle et stockage

Seul le propriétaire actif peut modifier raison sociale, SIRET, NDA,
signataire, coordonnées, logo, couleurs et pied de page. Les autres
utilisateurs autorisés consultent en lecture seule. Les contrôles
portent aussi sur les dépôts de logos et les appels directs au stockage.

Les fichiers confidentiels restent privés, accessibles par autorisation
et liens temporaires si nécessaire. Les restrictions sur les actifs
institutionnels ne doivent pas bloquer les autres usages légitimes du
même espace, notamment les plans d’accès des sites.

## Critères de réception

- Modifier l’examen B ne change ni le formulaire, ni les membres, ni les
  résultats de l’examen A.

- Une convocation reprend les bonnes dates et son annexe de parcours
  reste lisible sur plusieurs pages.

- Un utilisateur non propriétaire ne peut modifier la charte par
  interface, URL/API ou accès direct aux données/fichiers.

# 6. Finances, qualité et preuves

## F11 — Suivi financier opérationnel

Relier financement, financeur, montant, accord, échéancier, factures,
règlements et solde à l’inscription ou au dossier concerné. Distinguer
prévision, accord obtenu, facturation et encaissement. Tracer
modifications et justificatifs. Les calculs doivent être reproductibles
; toute référence de prise en charge doit porter sa source et sa date de
validité.

Préciser au cadrage les circuits de facturation, avoirs, taxes,
numérotation, exports comptables et obligations applicables. Aucun
connecteur comptable, paiement en ligne ou dépôt automatique auprès d’un
financeur n’est présumé inclus.

## F12 — RIB central

Pour le document existant rib_cfa : lecture par owner ou finance.view ;
dépôt, remplacement, validation, refus et suppression par owner ou
finance.manage. Appliquer ces règles aux RPC, tables, événements,
fichiers courants et fichiers migrés. Préserver les droits métier des
autres documents d’organisation.

Conserver la page /finance/rib et adapter le lien du dossier financier :
« Consulter le RIB central » ou « Gérer le RIB central ». Les droits de
lecture et de gestion doivent être testés séparément.

## F13 — Qualité et conformité explicable

Gérer un référentiel versionné, sa source, ses dates d’effet et son
périmètre d’activité. Conserver les analyses comme des photographies
immuables : version du moteur, date de référence, contrôles, preuves et
résultat. La synthèse du dossier et l’analyse complète doivent utiliser
la même photographie.

Une preuve ajoutée ultérieurement nécessite une nouvelle analyse. Une
correction conserve l’original, ajoute un événement d’invalidation ou
remplacement, un motif, un auteur et une date. Les anciennes analyses
restent inchangées. Distinguer preuves individuelles, collectives et
organisationnelles ; ne pas multiplier artificiellement une preuve
collective par apprenant.

Afficher « aucune analyse » en l’absence de photographie. Un pourcentage
de preuves détectées ne constitue pas une attestation de conformité. Les
contrôles nécessitant une appréciation humaine restent explicitement à
examiner. Un examen final ne remplace pas le suivi des acquis pendant le
parcours.

## Applicabilité réglementaire

Les libellés historiques « V9 » et « RNQ 2026 » sont des références du
projet. Le prestataire doit prévoir la validation des textes, versions
et dates d’effet par le responsable métier avant activation. Aucun
nouveau référentiel ne doit devenir applicable sur la seule base d’un
libellé présent dans le code.

# 7. Tâches, pilotage et expérience utilisateur

## F14 — Tâches et relais automatiques

Chaque tâche comporte objet, dossier lié, responsable, échéance,
priorité, statut et historique. Proposer « Mes tâches », une vue par
personne pour la supervision et des filtres par activité, retard et
dossier. Affecter les alertes Qualiopi à un responsable identifiable.

Les transitions reposent sur des prérequis explicites : données
présentes, pièces validées ou décision humaine requise. Expliquer ce qui
bloque le passage à l’étape suivante. Un événement ne doit créer qu’une
seule tâche attendue, même après nouvelle tentative. Les réaffectations,
absences et relais doivent préserver la responsabilité et la trace des
actions.

## F15 — Pilotage

Tableaux de bord adaptés au rôle : candidatures et placements,
inscriptions actives, tâches en retard, pièces manquantes, heures
prévues/réalisées/validées, absences, examens, financements et
encaissements, preuves et actions qualité. Chaque indicateur ouvre la
liste qui le compose et affiche période, filtre et date de mise à jour.

Les indicateurs de satisfaction, retour de questionnaires, abandon et
réussite doivent avoir une définition, un dénominateur et des exclusions
explicites. Les objectifs sont paramétrables ; un objectif n’est jamais
affiché comme un résultat mesuré.

## F16 — Interface attendue

- Navigation stable en français, écrans sobres et lisibles, formulaires
  adaptés au rôle et information essentielle en premier.

- Recherche et filtres utilisables sans connaissance technique ;
  conservation du contexte au retour d’un dossier.

- Messages de succès ou d’erreur près de l’action concernée ;
  conservation des champs en cas d’échec ; confirmation avant une action
  irréversible.

- Utilisation au clavier, libellés associés aux champs, contraste
  lisible et statuts compréhensibles sans dépendre de la couleur.

- Affichage adapté à l’ordinateur et à la tablette ; usage du téléphone
  à tester pour les actions retenues, notamment la consultation et les
  présences.

## Démonstration attendue

Le prestataire présente un dossier avec pièce manquante, le traitement
de cette pièce par l’administratif, le relais vers la pédagogie et la
disparition justifiée du blocage. La direction doit retrouver la tâche,
son responsable et sa résolution sans parcourir plusieurs modules.

# 8. Habilitations : règles non négociables

Le tenant désigne le périmètre d’isolation d’un organisme. Les rôles
sont additifs pour les fonctions métier ; leur cumul ne confère jamais
le statut de propriétaire. Tout accès dépend d’un utilisateur actif, du
tenant, de la permission et du dossier concerné.

| Profil                   | Accès cible et limites                                                                                                                                            |
|--------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Owner actif              | Administration sécurité et modification de la charte ; accès de gestion prévu dans son tenant uniquement.                                                         |
| Direction / agence       | Pilotage et opérations selon permissions ; aucune administration de sécurité par défaut.                                                                          |
| Responsable pédagogique  | Supervision, parcours, groupes, formateurs, examens ; commentaires/interventions et informations internes. Pas de pièces administratives du seul fait de ce rôle. |
| Formateur seul           | Séances et apprenants effectivement affectés ; pas de blocs internes, pièces administratives ni finances confidentielles.                                         |
| Administratif            | Inscriptions et pièces administratives selon périmètre ; finance en lecture si attribuée ; pas de sécurité.                                                       |
| Finance                  | Lecture/gestion financière selon droits ; aucune ouverture automatique des CV et notes pédagogiques.                                                              |
| Qualité / auditeur       | Preuves et contrôles autorisés ; auditeur en lecture seule, périmètre à valider.                                                                                  |
| Commercial / recrutement | Besoins, candidats et placements selon fonction ; accès aux CV explicitement attribué.                                                                            |

## S01 — Administration exclusivement owner

Le menu, l’URL et chaque action de sécurité vérifient le propriétaire
actif du tenant, indépendamment de users.view, users.manage, roles.view,
roles.manage ou audit.view. Réutiliser atlas_is_active_tenant_owner ou
une équivalence prouvée. Vérifier le statut avant toute
création/utilisation du client privilégié. Filtrer role_permissions côté
serveur par les identifiants des rôles du tenant ; aucun rôle signifie
aucune requête globale.

## S02 — Protection de bout en bout

Les politiques SQL restrictives doivent empêcher les contournements par
des permissions génériques ou futures exceptions. Protéger lectures,
mutations, exports, RPC et fichiers. Une clé service_role contourne la
RLS : elle reste secrète et chaque opération exige son propre contrôle
serveur. Ne jamais faire confiance au tenant transmis par le navigateur.

## Cas impératif : cumul de Nathalie

Trainer + agency_manager + pedagogy_manager conserve la supervision et
les blocs internes, ainsi que la consultation financière attribuée. Ce
cumul ne permet ni administration sécurité, ni modification de la
charte, ni modification du RIB avec le seul finance.view. Les
permissions opérationnelles utiles ne doivent pas être retirées pour
masquer un défaut de garde.

# 9. Architecture, données et exploitation

## T01 — Socle maintenable

La base existante est Next.js, TypeScript et Supabase : PostgreSQL, Auth
et Storage ; Vercel est l’hébergement utilisé dans l’historique. La
conserver par défaut. Toute alternative doit expliquer coût de
migration, équivalence des protections, exploitation et réversibilité.
Dépendances verrouillées, versions identifiées, secrets hors dépôt et
hors navigateur.

## T02 — Environnements et livraison

Séparer développement, recette et production. Utiliser un dépôt Git sous
contrôle de la commanditaire, des versions identifiables et des
migrations incrémentales. Ne pas réécrire les migrations historiques ni
lancer une synchronisation globale sans rapprochement préalable. Chaque
livraison contient prérequis, contrôles avant/après et retour coordonné
code/base.

## T03 — Reprise et intégrité

Inventorier tables, pièces, identités et historiques utiles ; établir
les correspondances et traiter les doublons sans perte silencieuse.
Répéter la migration en recette. Comparer comptes d’enregistrements,
liens, montants, heures et accès aux fichiers. Conserver identifiants ou
correspondances, documents signés, analyses et journaux. Documenter les
éléments non repris avec décision de la commanditaire.

## T04 — Protection des données

Limiter les données collectées et les accès, particulièrement aux pièces
personnelles et aménagements. Prévoir une politique de conservation
paramétrée par catégorie, les exports demandés par les personnes et les
opérations d’anonymisation/suppression autorisées. Faire valider les
durées, responsabilités, sous-traitants et localisation d’hébergement
dans le cadrage de protection des données. Les journaux ne contiennent
ni mots de passe ni clés ni copies inutiles de pièces sensibles.

## T05 — Sauvegarde et continuité

Couvrir schéma, données, rôles, Auth, fichiers Storage et configuration
nécessaire à la restauration. Chiffrer, surveiller les échecs et tester
une restauration isolée. Proposition de départ à contractualiser : perte
maximale de données de 24 h, remise en service en 8 h ouvrées,
sauvegarde quotidienne et exercice de restauration trimestriel. Le coût
de ces engagements doit être explicite.

## T06 — Performance et suivi

Proposition de recette : 20 utilisateurs simultanés, 5 000 inscriptions
et 100 000 lignes de présence, à ajuster aux volumes inventoriés. Cible
: 95 % des listes/fiches courantes en moins de 2 secondes dans
l’environnement convenu ; traitements longs avec progression et reprise.
Journaliser erreurs et incidents, sans fuite de données, et définir qui
reçoit les alertes.

# 10. Recette et preuves attendues

La réception repose sur des résultats observables dans un environnement
de recette représentatif. TypeScript et build réussis sont nécessaires
mais ne suffisent pas. Les tests simulés doivent être distingués des
essais navigateur et Supabase réels.

| ID  | Scénario                              | Résultat exigé                                                                                                              |
|-----|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------|
| R01 | Deux owners, tenants A et B           | A ne reçoit aucun rôle, permission, dossier ou fichier B ; même test inverse, y compris exports et accès directs.           |
| R02 | Cumul Nathalie                        | Supervision conservée ; refus administration par menu, URL et action directe ; charte et RIB en lecture seule selon droits. |
| R03 | Formateur affecté / non affecté       | Seulement les apprenants autorisés ; impossibilité de fabriquer une affectation par écriture directe.                       |
| R04 | Séance future et journée fractionnée  | Préparation possible ; présence/clôture anticipées refusées ; 6 h pour 9–12/14–17 ; pas de double compte.                   |
| R05 | Séance clôturée et historique         | Modification/suppression refusées ; anciennes signatures et heures non réconciliées préservées.                             |
| R06 | Deux cohortes et inscription terminée | Bonne cohorte chargée ; candidat éligible affectable ; résultat conservé sur le bon membre uniquement.                      |
| R07 | Charte, RIB actuel et migré           | Owner/finance autorisés selon règle ; non habilités refusés côté données et stockage ; autres documents préservés.          |
| R08 | Preuve invalidée et nouvelle analyse  | Ancien snapshot intact ; nouvelle analyse tient compte de l’invalidation ; synthèse cohérente ; revue humaine visible.      |
| R09 | Document et financement               | Bonne identité, bonnes données, versions conservées ; échéancier et solde explicables après rechargement.                   |
| R10 | Relais et sauvegarde                  | Une tâche créée malgré nouvelle tentative ; restauration indépendante avec pièces accessibles et droits conservés.          |

## Profils et organisation des essais

Couvrir owner, direction, agence, pédagogie, formateur, cumul Nathalie,
administratif, finance, commercial, anonyme, membre inactif, owner
expiré et autre tenant. Utiliser des identités fictives. L’équipe pilote
choisit 2 ou 3 dossiers OF et 1 dossier CFA représentatifs ; chacun
réalise son parcours habituel et consigne résultat attendu, obtenu,
capture utile et gravité.

## Condition de réception proposée

Tous les scénarios impératifs passent ; aucune anomalie bloquante ou
majeure de sécurité, intégrité ou parcours essentiel ne reste ouverte.
Les anomalies mineures acceptées sont listées avec échéance. La décision
de réception appartient à Essi AYIVOR ; le nombre de tests ne vaut pas
validation métier à lui seul.

# 11. Livrables, lots et consultation

| Lot                         | Livrable et point de validation                                                                                                               |
|-----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| 0 • Reprise cadrée          | Inventaire ciblé, correspondance exigences/existant/écarts, versions et données identifiées, proposition reprise ou reconstruction justifiée. |
| 1 • Socle fiable            | Environnements, habilitations, reprise pilote, sauvegarde/restauration et protections 0045/0046/0063 démontrées.                              |
| 2 • Parcours complets       | Commercial → inscription → pédagogie → documents → finance → examens ; démonstrations OF et CFA.                                              |
| 3 • Qualité et coordination | Analyses versionnées, preuves, tâches, relais et pilotage ; cohérence des synthèses et droits.                                                |
| 4 • Mise en service         | Recette signée, reprise finale, déploiement autorisé, formation, surveillance initiale et passage de relais.                                  |

## Livrables obligatoires

- Sources complètes et historique Git, schéma et migrations, verrou de
  dépendances, tests et jeux de données anonymisés, inventaire des
  services et licences.

- Documentation d’architecture, dictionnaire des données, matrice des
  droits et règles de calcul ; mise à jour des cinq documents ATLAS de
  référence.

- Guide utilisateur par rôle et guide administrateur ; procédures
  d’installation, sauvegarde, restauration, incident, mise à jour et
  export complet.

- Rapport de recette lié à la version livrée, registre des anomalies,
  rapport de reprise et preuve de restauration ; formation de la
  direction et du noyau pilote.

## Format demandé pour le devis

Pour chaque lot : exigences couvertes, éléments réutilisés, travaux
nouveaux, charge en jours, prix, hypothèses, dépendances, durée et
critères de paiement/réception. Indiquer séparément hébergement,
stockage, emails, signature, licences, maintenance et options. Fournir
le coût initial et le coût récurrent sur 12 mois, ainsi que les
conditions de sortie.

## Cadre de collaboration à contractualiser

Démonstrations courtes et régulières avec décisions écrites ; aucun
élargissement tacite. Les comptes d’hébergement, le dépôt et les accès
essentiels restent sous contrôle de la commanditaire. Définir les droits
d’usage et de modification des sources, les composants tiers, la
garantie de correction, les délais de prise en charge et la maintenance.
Proposition : garantie corrective de 3 mois après réception, à négocier
explicitement.

Ne pas imposer un calendrier artificiel avant l’inventaire. Le
prestataire fournit un calendrier ferme après le lot 0, avec dépendances
à la validation métier. Chaque changement de périmètre précise son effet
sur prix, délai et recette avant réalisation.

# 12. Références et arbitrages de départ

## Corpus de reprise

Référence documentaire consultée :
ATLAS_0063_VERSION_CONSOLIDEE_2026-10-19.zip, livraison
ATLAS-0063-CONSOLIDEE-20261019. Fichiers de référence :
ATLAS_CONTEXTE.md, ATLAS_ARCHITECTURE.md, ATLAS_AVANCEMENT.md,
ATLAS_REGLES_DEVELOPPEMENT.md et ATLAS_ANOMALIES.md ; note
ATLAS_POINT_ET_MISE_A_DISPOSITION_2026-10-19.md. Les décisions métier
ultérieures et le présent cahier des charges priment sur les matrices
initiales devenues contradictoires.

La consolidation documente la correction serveur de role_permissions,
les tests locaux et leurs limites. Elle signale que le TSX du premier
paquet final Administration n’intégrait pas le patch correct. Le
prestataire doit partir d’une version identifiée et corrigée, et non du
seul nom d’une archive. Les confirmations ultérieures d’installation et
de déploiement doivent être rapprochées de leurs versions au démarrage.

## Acquis métier à transmettre explicitement

- 0045 : périmètre formateur et confidentialité des dossiers ; 0046 :
  périodes, contrôle temporel, heures et verrouillage.

- 0057–0060 : isolation des cohortes, éligibilité des inscriptions
  terminées, affectation et enregistrement des résultats.

- 0061 R3 : référentiel versionné, analyses immuables et corrections par
  ajout au journal ; 0062 : synthèse issue du même snapshot.

- 0063 : propriétaire actif pour la sécurité et la charte, RIB selon
  droits financiers, isolation serveur des permissions de rôles.

## Décisions à prendre lors du lot 0

| Décision                   | Responsable / résultat attendu                                                                                         |
|----------------------------|------------------------------------------------------------------------------------------------------------------------|
| Structures et tenants      | Essi + prestataire : séparation Excellentia/ExF, droits transversaux éventuels et documents émis par chaque structure. |
| Catalogue et activités     | Essi : activités incluses au premier lancement et cas particuliers à couvrir.                                          |
| Droits détaillés           | Essi + responsables métier : matrice par opération, dossier et pièce ; arbitrage des cumuls hors règles impératives.   |
| Intégrations et signatures | Essi : priorités, prestataires et valeur attendue ; devis distinct des options.                                        |
| Volumes et service         | Prestataire + Essi : volumétrie, temps de réponse, restauration, disponibilité et coûts retenus.                       |
| Reprise et bascule         | Prestataire + équipe : données à reprendre, répétition, fenêtre de bascule et critères de retour.                      |

## Message au développeur

La réussite se mesure à la continuité des parcours et à la confiance de
l’équipe dans les données. Vous devez conserver les décisions métier
déjà mûries, rendre les règles compréhensibles, prouver les protections
et nous laisser un outil que nous pouvons exploiter et faire évoluer
durablement.
