/**
 * Calcul des tarifs Next Formation à partir du prix de référence public.
 * Module pur (aucune dépendance serveur) : utilisable dans les pages, les formulaires client et les tests.
 */
import { floorCents } from "../../lib/money";

/** Remise par défaut : 10 % exprimée en points de base (1000 bp = 10 %). */
export const DEFAULT_DISCOUNT_BP = 1000;
/** Plafond contrôlé : le prix Next Formation ne doit jamais dépasser 90 % de la référence. */
export const MAX_RATIO_BP = 9000;

/**
 * Prix proposé = floor(référence × (10000 - remise) / 10000), tronqué au centime inférieur.
 * Jamais arrondi au-dessus : la remise annoncée n'est jamais rognée.
 */
export function proposePrice(referenceCents: number | null | undefined, discountBp = DEFAULT_DISCOUNT_BP): number | null {
  if (referenceCents === null || referenceCents === undefined) return null;
  if (!Number.isInteger(referenceCents) || referenceCents < 0) throw new Error("Prix de référence invalide (centimes entiers attendus).");
  if (!Number.isInteger(discountBp) || discountBp < 0 || discountBp > 10000) throw new Error("Remise invalide (0 à 10000 points de base).");
  return floorCents((referenceCents * (10000 - discountBp)) / 10000);
}

export type PriceCheck =
  | { level: "ok"; message: string }
  | { level: "info"; message: string }
  | { level: "danger"; message: string };

/** Contrôle d'une ligne : signale tout prix au-dessus de référence × 0,90 et tout écart avec la proposition. */
export function checkPrice(line: { priceCents: number | null; referencePriceCents: number | null; discountRate: number; unit: string }): PriceCheck {
  if (line.unit === "sur_devis" || line.priceCents === null) return { level: "ok", message: "Sur devis : pas de comparaison chiffrée." };
  if (line.unit === "inclus") {
    return line.priceCents === 0 ? { level: "ok", message: "Inclus sans surcoût." } : { level: "danger", message: "Une fonction incluse ne doit pas être facturée." };
  }
  if (line.referencePriceCents === null) return { level: "info", message: "Aucun prix de référence : prix fixé manuellement." };
  // Comparaison entière : prix × 10000 > référence × 9000 ⇔ prix > référence × 0,90.
  if (line.priceCents * 10000 > line.referencePriceCents * MAX_RATIO_BP) {
    return { level: "danger", message: `Prix supérieur à 90 % de la référence (plafond ${centsLabel(Math.floor((line.referencePriceCents * MAX_RATIO_BP) / 10000))}).` };
  }
  const proposed = proposePrice(line.referencePriceCents, line.discountRate);
  if (proposed !== null && proposed !== line.priceCents) return { level: "info", message: `Différent de la proposition (${centsLabel(proposed)}), sous le plafond.` };
  return { level: "ok", message: "Conforme à la règle de calcul." };
}

/** Note de calcul lisible : « 3,11 € × 0,90 = 2,799 € ; tronqué au centime inférieur : 2,79 € ». */
export function calculationNote(referenceCents: number | null, discountBp = DEFAULT_DISCOUNT_BP): string | null {
  if (referenceCents === null) return null;
  const factor = (10000 - discountBp) / 10000;
  const exact = (referenceCents * (10000 - discountBp)) / 10000 / 100;
  const proposed = proposePrice(referenceCents, discountBp)!;
  const exactLabel = exact.toLocaleString("fr-FR", { minimumFractionDigits: 3, maximumFractionDigits: 4 });
  const factorLabel = factor.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 4 });
  return `${centsLabel(referenceCents)} × ${factorLabel} = ${exactLabel} € ; tronqué au centime inférieur : ${centsLabel(proposed)}`;
}

function centsLabel(c: number) {
  return `${(c / 100).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
}

export const pricingUnitLabels: Record<string, string> = {
  forfait_mois: "forfait mensuel (engagement annuel)",
  option_mois: "option mensuelle",
  par_apprenant_an: "par apprenant et par an",
  par_organisme_mois: "par organisme et par mois",
  sur_devis: "sur devis",
  inclus: "inclus",
};
