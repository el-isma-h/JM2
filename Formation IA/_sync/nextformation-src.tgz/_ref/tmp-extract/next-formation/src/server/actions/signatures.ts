"use server";

import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireOrg } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { clientIp, hit, tooManyMessage } from "@/server/rate-limit";
import { cancelSignatureRequest, createSignatureRequest, resendSignatureLinks, sendOtp, signWithToken, SIGNER_ROLES } from "@/server/documents/signatures";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

const signerSchema = z.object({
  name: z.string().trim().min(2, "Nom du signataire requis.").max(120),
  email: z.string().trim().toLowerCase().email("Adresse e-mail du signataire invalide."),
  role: z.enum(SIGNER_ROLES, { message: "Rôle de signataire invalide." }),
});

/** Crée une demande de signature (jusqu'à 4 signataires : champs signer{N}Name / Email / Role). */
export async function createSignatureRequestAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const documentId = uuid.parse(str(fd, "documentId"));
    const signers: z.infer<typeof signerSchema>[] = [];
    for (let i = 0; i < 4; i++) {
      const name = str(fd, `signer${i}Name`);
      const email = str(fd, `signer${i}Email`);
      if (!name && !email) continue;
      signers.push(signerSchema.parse({ name, email, role: str(fd, `signer${i}Role`) || "autre" }));
    }
    const message = str(fd, "message").slice(0, 1000);
    const ctx = await requireOrg(orgId, "documents.generate");
    const res = await createSignatureRequest({ ctx, documentId, signers, message });
    revalidatePath(`/app/${orgId}/documents/${documentId}`);
    revalidatePath(`/app/${orgId}/signatures`);
    if (res.notConfiguredMessage) return { ok: true, message: res.notConfiguredMessage };
    const sent = res.mailStatus === "sent";
    const note = sent ? "Les signataires ont reçu leur lien par e-mail." : ctx.org.isDemo ? "Démonstration : aucun e-mail ne part ; les liens de signature sont affichés ci-dessous." : "E-mail non configuré : transmettez vous-même les liens ci-dessous (personnels, valables 30 jours).";
    return { ok: true, message: `Demande de signature créée. ${note}`, data: sent ? {} : { links: res.links.map((l) => `${l.name} (${l.email}) : ${l.url}`).join("\n") } };
  } catch (e) {
    return fail(e, "Création de la demande impossible.");
  }
}

export async function cancelSignatureRequestAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const requestId = uuid.parse(str(fd, "requestId"));
    const reason = z.string().trim().min(3, "Indiquez le motif.").max(500).parse(str(fd, "reason"));
    const ctx = await requireOrg(orgId, "documents.generate");
    await cancelSignatureRequest(ctx, requestId, reason);
    revalidatePath(`/app/${orgId}/signatures`);
    return { ok: true, message: "Demande annulée : les liens envoyés ne fonctionnent plus." };
  } catch (e) {
    return fail(e, "Annulation impossible.");
  }
}

export async function resendSignatureAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const requestId = uuid.parse(str(fd, "requestId"));
    const ctx = await requireOrg(orgId, "documents.generate");
    const links = await resendSignatureLinks(ctx, requestId);
    revalidatePath(`/app/${orgId}/signatures`);
    const shown = ctx.org.isDemo || !process.env.RESEND_API_KEY;
    return { ok: true, message: `Relance envoyée à ${links.length} signataire(s) ; les anciens liens sont invalidés.`, data: shown ? { links: links.map((l) => `${l.name} (${l.email}) : ${l.url}`).join("\n") } : {} };
  } catch (e) {
    return fail(e, "Relance impossible.");
  }
}

/* ---------- Côté signataire (page publique /signer/[token], sans session) ---------- */

export async function requestSignOtpAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const token = z.string().min(20).max(128).parse(str(fd, "token"));
    const rl = await hit("sign-otp:ip", await clientIp(), { limit: 10, windowSeconds: 15 * 60 });
    if (!rl.ok) return { error: tooManyMessage(rl) };
    const res = await sendOtp(token);
    if (!res.ok) return { error: res.error };
    const base = res.mailStatus === "sent" ? "Un code à 6 chiffres vous a été envoyé par e-mail (valable 10 minutes)." : "Le code n'a pas pu être envoyé par e-mail (service non configuré ou démonstration).";
    return { ok: true, message: res.demoCode ? `${base} Code affiché pour cet environnement : ${res.demoCode}` : base, data: res.demoCode ? { demoCode: res.demoCode } : {} };
  } catch (e) {
    return fail(e, "Envoi du code impossible.");
  }
}

export async function signDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const token = z.string().min(20).max(128).parse(str(fd, "token"));
    const otp = z.string().trim().regex(/^\d{6}$/, "Le code comporte 6 chiffres.").parse(str(fd, "otp"));
    const consent = str(fd, "consent") === "on" || str(fd, "consent") === "1";
    const signaturePng = String(fd.get("signature") ?? "");
    const rl = await hit("sign:ip", await clientIp(), { limit: 30, windowSeconds: 15 * 60 });
    if (!rl.ok) return { error: tooManyMessage(rl) };
    const h = await headers();
    const res = await signWithToken({ token, otp, signaturePngBase64: signaturePng, consent, ip: await clientIp(), userAgent: h.get("user-agent") });
    if (!res.ok) return { error: res.error };
    return { ok: true, message: res.completed ? "Document signé par tous les signataires : le PDF signé et sa page de preuve sont enregistrés." : "Votre signature est enregistrée. Le document sera finalisé quand tous les signataires auront signé.", data: { completed: res.completed ? "1" : "0" } };
  } catch (e) {
    return fail(e, "Signature impossible.");
  }
}
