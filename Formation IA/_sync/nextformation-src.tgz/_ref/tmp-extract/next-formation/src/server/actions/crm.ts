"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { checkSiren, checkSiret, checkPostalCode } from "@/lib/validators";
import { todayParis } from "@/lib/time";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { createDocument, issueDownloadLink } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { clientIp, hit, tooManyMessage } from "@/server/rate-limit";
import { bool, fail, fullName, int, isoDate, optEmail, str, tagList, uuid } from "@/server/crm/helpers";
import { duplicateWarning, findCompanyDuplicates, findPersonDuplicates } from "@/server/crm/queries";
import { relayWonNeed } from "@/server/crm/relay";
import type { ActionState } from "./auth";

const COMPANY_STATUS = schema.companyStatusEnum.enumValues;
const NEED_STAGES = schema.needStageEnum.enumValues;
const NEED_KINDS = schema.needKindEnum.enumValues;
const PLACEMENT_STATUS = schema.placementStatusEnum.enumValues;
const INTERACTION_KINDS = schema.interactionKindEnum.enumValues;
const PERSON_STATUS = schema.personStatusEnum.enumValues;
const CIVILITIES = schema.civilityEnum.enumValues;

function base(orgId: string) {
  return `/app/${orgId}`;
}

async function loadCompany(ctx: OrgContext, id: string) {
  const [c] = await db.select().from(schema.companies).where(and(eq(schema.companies.id, id), eq(schema.companies.orgId, ctx.org.id))).limit(1);
  if (!c) throw new Error("Entreprise introuvable dans cet organisme.");
  return c;
}
async function loadContact(ctx: OrgContext, id: string) {
  const [c] = await db.select().from(schema.contacts).where(and(eq(schema.contacts.id, id), eq(schema.contacts.orgId, ctx.org.id))).limit(1);
  if (!c) throw new Error("Contact introuvable dans cet organisme.");
  return c;
}
async function loadPerson(ctx: OrgContext, id: string) {
  const [p] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, id), eq(schema.persons.orgId, ctx.org.id))).limit(1);
  if (!p) throw new Error("Personne introuvable dans cet organisme.");
  return p;
}
async function loadNeed(ctx: OrgContext, id: string) {
  const [n] = await db.select().from(schema.needs).where(and(eq(schema.needs.id, id), eq(schema.needs.orgId, ctx.org.id))).limit(1);
  if (!n) throw new Error("Besoin introuvable dans cet organisme.");
  return n;
}
/** Un identifiant transmis par formulaire n'est jamais une autorisation : on vérifie l'appartenance à l'organisme. */
async function optionalRef(ctx: OrgContext, formData: FormData, key: string, table: "companies" | "contacts" | "persons" | "programs" | "needs"): Promise<string | null> {
  const raw = str(formData, key, 40);
  if (!raw) return null;
  const id = uuid.parse(raw);
  const t = schema[table];
  const [row] = await db.select({ id: t.id }).from(t).where(and(eq(t.id, id), eq(t.orgId, ctx.org.id))).limit(1);
  if (!row) throw new Error("Élément rattaché introuvable dans cet organisme.");
  return row.id;
}
async function optionalUserRef(ctx: OrgContext, formData: FormData, key: string): Promise<string | null> {
  const raw = str(formData, key, 40);
  if (!raw) return null;
  const id = uuid.parse(raw);
  const [m] = await db.select({ id: schema.memberships.id }).from(schema.memberships).where(and(eq(schema.memberships.orgId, ctx.org.id), eq(schema.memberships.userId, id), eq(schema.memberships.active, true))).limit(1);
  if (!m) throw new Error("Commercial référent introuvable parmi les membres actifs.");
  return id;
}

// ---------------------------------------------------------------------------
// Entreprises
// ---------------------------------------------------------------------------

async function companyValues(ctx: OrgContext, formData: FormData) {
  const name = z.string().trim().min(2, "Raison sociale requise (2 caractères minimum)").max(200).parse(formData.get("name"));
  let siren: string | null = null;
  let siret: string | null = null;
  const rawSiren = str(formData, "siren", 20);
  if (rawSiren) {
    const r = checkSiren(rawSiren);
    if (!r.ok) throw new Error(r.error);
    siren = r.value;
  }
  const rawSiret = str(formData, "siret", 20);
  if (rawSiret) {
    const r = checkSiret(rawSiret, siren);
    if (!r.ok) throw new Error(r.error);
    siret = r.value;
    if (!siren) siren = siret.slice(0, 9);
  }
  const rawPostal = str(formData, "postalCode", 10);
  let postalCode: string | null = null;
  if (rawPostal) {
    const r = checkPostalCode(rawPostal);
    if (!r.ok) throw new Error(r.error);
    postalCode = r.value;
  }
  const status = z.enum(COMPANY_STATUS).parse(formData.get("status") || "prospect");
  return {
    name,
    siren,
    siret,
    apeCode: str(formData, "apeCode", 10),
    idcc: str(formData, "idcc", 10),
    opco: str(formData, "opco", 120),
    sector: str(formData, "sector", 120),
    headcount: int(formData, "headcount", { min: 0, max: 10_000_000 }),
    addressLine1: str(formData, "addressLine1", 200),
    addressLine2: str(formData, "addressLine2", 200),
    postalCode,
    city: str(formData, "city", 120),
    email: optEmail(formData, "email"),
    phone: str(formData, "phone", 40),
    website: str(formData, "website", 200),
    status,
    source: str(formData, "source", 120),
    assignedUserId: await optionalUserRef(ctx, formData, "assignedUserId"),
    tags: tagList(str(formData, "tags", 1000)),
    notes: str(formData, "notes", 5000),
  };
}

export async function createCompanyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let orgId = "";
  let createdId = "";
  try {
    orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const values = await companyValues(ctx, formData);
    if (!bool(formData, "ignoreDuplicates")) {
      const dups = await findCompanyDuplicates(ctx.org.id, { name: values.name, siret: values.siret });
      const w = duplicateWarning("entreprise", dups, (r: { name: string; siret: string | null; city: string | null }) => `${r.name}${r.siret ? ` SIRET ${r.siret}` : ""}${r.city ? `, ${r.city}` : ""}`);
      if (w) return { error: `${w} Cochez « Créer malgré tout » si c'est bien une autre entreprise.` };
    }
    const [row] = await db.insert(schema.companies).values({ ...values, orgId: ctx.org.id, isDemo: ctx.org.isDemo }).returning({ id: schema.companies.id });
    await audit({ action: "company.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "company", entityId: row.id, after: values });
    revalidatePath(`${base(orgId)}/entreprises`);
    createdId = row.id;
  } catch (e) {
    return fail(e, "Création impossible.");
  }
  redirect(`${base(orgId)}/entreprises/${createdId}`);
}

export async function updateCompanyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const before = await loadCompany(ctx, uuid.parse(formData.get("companyId")));
    const values = await companyValues(ctx, formData);
    await db.update(schema.companies).set(values).where(eq(schema.companies.id, before.id));
    await audit({ action: "company.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "company", entityId: before.id, before, after: values });
    revalidatePath(`${base(orgId)}/entreprises/${before.id}`);
    revalidatePath(`${base(orgId)}/entreprises`);
    return { ok: true, message: "Entreprise enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function setCompanyStatusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const c = await loadCompany(ctx, uuid.parse(formData.get("companyId")));
    const status = z.enum(COMPANY_STATUS).parse(formData.get("status"));
    if (status === c.status) return { ok: true, message: "Statut inchangé." };
    await db.update(schema.companies).set({ status }).where(eq(schema.companies.id, c.id));
    await audit({ action: "company.status", userId: ctx.user.id, orgId: ctx.org.id, entityType: "company", entityId: c.id, before: { status: c.status }, after: { status } });
    revalidatePath(`${base(orgId)}/entreprises/${c.id}`);
    revalidatePath(`${base(orgId)}/entreprises`);
    return { ok: true, message: "Statut mis à jour." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

// ---------------------------------------------------------------------------
// Contacts
// ---------------------------------------------------------------------------

async function contactValues(ctx: OrgContext, formData: FormData) {
  const rawCiv = str(formData, "civility", 10);
  return {
    companyId: await optionalRef(ctx, formData, "companyId", "companies"),
    civility: rawCiv ? z.enum(CIVILITIES).parse(rawCiv) : null,
    firstName: z.string().trim().min(1, "Prénom requis").max(80).parse(formData.get("firstName")),
    lastName: z.string().trim().min(1, "Nom requis").max(80).parse(formData.get("lastName")),
    jobTitle: str(formData, "jobTitle", 120),
    email: optEmail(formData, "email"),
    phone: str(formData, "phone", 40),
    mobile: str(formData, "mobile", 40),
    isSignatory: bool(formData, "isSignatory"),
    isTutor: bool(formData, "isTutor"),
    isBilling: bool(formData, "isBilling"),
    notes: str(formData, "notes", 3000),
  };
}

export async function createContactAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const values = await contactValues(ctx, formData);
    const [row] = await db.insert(schema.contacts).values({ ...values, orgId: ctx.org.id }).returning({ id: schema.contacts.id });
    await audit({ action: "contact.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "contact", entityId: row.id, after: values });
    revalidatePath(`${base(orgId)}/contacts`);
    if (values.companyId) revalidatePath(`${base(orgId)}/entreprises/${values.companyId}`);
    return { ok: true, message: `Contact ${values.firstName} ${values.lastName} ajouté.` };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function updateContactAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const before = await loadContact(ctx, uuid.parse(formData.get("contactId")));
    const values = await contactValues(ctx, formData);
    await db.update(schema.contacts).set(values).where(eq(schema.contacts.id, before.id));
    await audit({ action: "contact.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "contact", entityId: before.id, before, after: values });
    revalidatePath(`${base(orgId)}/contacts`);
    for (const cid of [before.companyId, values.companyId]) if (cid) revalidatePath(`${base(orgId)}/entreprises/${cid}`);
    return { ok: true, message: "Contact enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

// ---------------------------------------------------------------------------
// Échanges (journal CRM)
// ---------------------------------------------------------------------------

export async function addInteractionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const companyId = await optionalRef(ctx, formData, "companyId", "companies");
    const personId = await optionalRef(ctx, formData, "personId", "persons");
    const needId = await optionalRef(ctx, formData, "needId", "needs");
    const contactId = await optionalRef(ctx, formData, "contactId", "contacts");
    if (!companyId && !personId && !needId) return { error: "Un échange doit être rattaché à une entreprise, une personne ou un besoin." };
    const kind = z.enum(INTERACTION_KINDS).parse(formData.get("kind") || "note");
    const subject = z.string().trim().min(2, "Objet de l'échange requis").max(200).parse(formData.get("subject"));
    const body = str(formData, "body", 5000);
    const atDate = isoDate(formData, "atDate") ?? todayParis();
    const nextActionAt = isoDate(formData, "nextActionAt");
    const nextAction = str(formData, "nextAction", 300);
    if (nextAction && !nextActionAt) return { error: "Indiquez la date de la prochaine action." };
    const values = { orgId: ctx.org.id, companyId, personId, needId, contactId, kind, subject, body, at: new Date(`${atDate}T12:00:00Z`), nextActionAt, nextAction: nextActionAt ? nextAction || "Relance" : null, userId: ctx.user.id };
    const [row] = await db.insert(schema.interactions).values(values).returning({ id: schema.interactions.id });
    await audit({ action: "interaction.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "interaction", entityId: row.id, after: values });
    if (companyId) revalidatePath(`${base(orgId)}/entreprises/${companyId}`);
    if (personId) revalidatePath(`${base(orgId)}/candidats/${personId}`);
    if (needId) revalidatePath(`${base(orgId)}/besoins/${needId}`);
    revalidatePath(`${base(orgId)}/entreprises`);
    return { ok: true, message: nextActionAt ? `Échange enregistré, prochaine action le ${nextActionAt.split("-").reverse().join("/")}.` : "Échange enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

// ---------------------------------------------------------------------------
// Besoins (pipeline)
// ---------------------------------------------------------------------------

async function needValues(ctx: OrgContext, formData: FormData) {
  const amountRaw = str(formData, "amountEuros", 30);
  let amountCents: number | null = null;
  if (amountRaw) {
    const v = amountRaw.replace(/[\s €]/g, "").replace(",", ".");
    if (!/^\d+(\.\d{1,2})?$/.test(v)) throw new Error("Montant estimé invalide (ex. 2 450,00).");
    const [i, d = ""] = v.split(".");
    amountCents = Number(i) * 100 + Number(d.padEnd(2, "0"));
  }
  const companyId = await optionalRef(ctx, formData, "companyId", "companies");
  const contactId = await optionalRef(ctx, formData, "contactId", "contacts");
  const personId = await optionalRef(ctx, formData, "personId", "persons");
  if (!companyId && !personId) throw new Error("Rattachez le besoin à une entreprise ou à une personne.");
  return {
    companyId,
    contactId,
    personId,
    kind: z.enum(NEED_KINDS).parse(formData.get("kind") || "formation"),
    title: z.string().trim().min(2, "Intitulé du besoin requis").max(200).parse(formData.get("title")),
    description: str(formData, "description", 5000),
    programId: await optionalRef(ctx, formData, "programId", "programs"),
    headcount: int(formData, "headcount", { min: 1, max: 10000 }) ?? 1,
    amountCents,
    probability: int(formData, "probability", { min: 0, max: 100 }) ?? 20,
    expectedCloseDate: isoDate(formData, "expectedCloseDate"),
    assignedUserId: await optionalUserRef(ctx, formData, "assignedUserId"),
    nextActionAt: isoDate(formData, "nextActionAt"),
    nextAction: str(formData, "nextAction", 300),
    source: str(formData, "source", 120),
  };
}

export async function createNeedAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let orgId = "";
  let id = "";
  try {
    orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const values = await needValues(ctx, formData);
    const [row] = await db.insert(schema.needs).values({ ...values, orgId: ctx.org.id, stage: "nouveau", isDemo: ctx.org.isDemo }).returning({ id: schema.needs.id });
    await audit({ action: "need.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "need", entityId: row.id, after: values });
    revalidatePath(`${base(orgId)}/besoins`);
    id = row.id;
  } catch (e) {
    return fail(e, "Création impossible.");
  }
  redirect(`${base(orgId)}/besoins/${id}`);
}

export async function updateNeedAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const before = await loadNeed(ctx, uuid.parse(formData.get("needId")));
    const values = await needValues(ctx, formData);
    await db.update(schema.needs).set(values).where(eq(schema.needs.id, before.id));
    await audit({ action: "need.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "need", entityId: before.id, before, after: values });
    revalidatePath(`${base(orgId)}/besoins/${before.id}`);
    revalidatePath(`${base(orgId)}/besoins`);
    return { ok: true, message: "Besoin enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function setNeedStageAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const need = await loadNeed(ctx, uuid.parse(formData.get("needId")));
    const stage = z.enum(NEED_STAGES).parse(formData.get("stage"));
    if (stage === need.stage) return { ok: true, message: "Étape inchangée." };
    const lostReason = str(formData, "lostReason", 500);
    if (stage === "perdu" && !lostReason) return { error: "Indiquez le motif de la perte." };
    const patch: Partial<typeof schema.needs.$inferInsert> = { stage };
    if (stage === "gagne") {
      patch.wonAt = new Date();
      patch.lostAt = null;
      patch.lostReason = null;
      patch.probability = 100;
    } else if (stage === "perdu") {
      patch.lostAt = new Date();
      patch.lostReason = lostReason;
      patch.wonAt = null;
      patch.probability = 0;
    } else {
      patch.wonAt = null;
      patch.lostAt = null;
      patch.lostReason = null;
      if (need.stage === "gagne" || need.stage === "perdu") patch.probability = 50;
    }
    const [after] = await db.update(schema.needs).set(patch).where(eq(schema.needs.id, need.id)).returning();
    await audit({ action: stage === "gagne" ? "need.won" : stage === "perdu" ? "need.lost" : "need.stage", userId: ctx.user.id, orgId: ctx.org.id, entityType: "need", entityId: need.id, before: { stage: need.stage }, after: { stage, lostReason } });
    if (stage === "gagne") await relayWonNeed({ orgId: ctx.org.id, userId: ctx.user.id, isDemo: ctx.org.isDemo }, after);
    if (need.stage === "gagne" && stage !== "gagne") await resolveTaskByKey(ctx.org.id, `need:${need.id}:won`, "Le besoin n'est plus en « gagné ».", ctx.user.id);
    revalidatePath(`${base(orgId)}/besoins/${need.id}`);
    revalidatePath(`${base(orgId)}/besoins`);
    return { ok: true, message: stage === "gagne" ? "Besoin gagné. Une tâche « Créer l'inscription » a été transmise à l'administratif si aucune inscription n'existe." : stage === "perdu" ? "Besoin marqué perdu." : "Étape mise à jour." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

// ---------------------------------------------------------------------------
// Placements
// ---------------------------------------------------------------------------

export async function addPlacementAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const need = await loadNeed(ctx, uuid.parse(formData.get("needId")));
    const person = await loadPerson(ctx, uuid.parse(formData.get("personId")));
    const [dup] = await db.select({ id: schema.placements.id }).from(schema.placements).where(and(eq(schema.placements.needId, need.id), eq(schema.placements.personId, person.id))).limit(1);
    if (dup) return { error: `${fullName(person)} est déjà associé(e) à ce besoin.` };
    const [row] = await db.insert(schema.placements).values({ orgId: ctx.org.id, needId: need.id, personId: person.id, status: "propose", notes: str(formData, "notes", 2000), createdBy: ctx.user.id }).returning({ id: schema.placements.id });
    await audit({ action: "placement.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "placement", entityId: row.id, after: { needId: need.id, personId: person.id } });
    revalidatePath(`${base(orgId)}/besoins/${need.id}`);
    revalidatePath(`${base(orgId)}/candidats/${person.id}`);
    return { ok: true, message: `${fullName(person)} proposé(e) sur ce besoin.` };
  } catch (e) {
    return fail(e, "Association impossible.");
  }
}

export async function setPlacementStatusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const id = uuid.parse(formData.get("placementId"));
    const [p] = await db.select().from(schema.placements).where(and(eq(schema.placements.id, id), eq(schema.placements.orgId, ctx.org.id))).limit(1);
    if (!p) return { error: "Placement introuvable." };
    const status = z.enum(PLACEMENT_STATUS).parse(formData.get("status"));
    if (status === p.status) return { ok: true, message: "Statut inchangé." };
    if (p.enrollmentId && status !== "place") return { error: "Une inscription existe déjà pour ce placement : son statut ne peut plus être modifié ici." };
    const patch: Partial<typeof schema.placements.$inferInsert> = { status, notes: str(formData, "notes", 2000) ?? p.notes };
    if (status === "entretien") patch.interviewAt = new Date();
    if (["retenu", "refuse", "place", "abandonne"].includes(status)) patch.decidedAt = new Date();
    await db.update(schema.placements).set(patch).where(eq(schema.placements.id, p.id));
    await audit({ action: "placement.status", userId: ctx.user.id, orgId: ctx.org.id, entityType: "placement", entityId: p.id, before: { status: p.status }, after: { status } });
    revalidatePath(`${base(orgId)}/besoins/${p.needId}`);
    revalidatePath(`${base(orgId)}/candidats/${p.personId}`);
    return { ok: true, message: "Placement mis à jour." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

// ---------------------------------------------------------------------------
// Candidats / personnes
// ---------------------------------------------------------------------------

async function personValues(ctx: OrgContext, formData: FormData) {
  const rawCiv = str(formData, "civility", 10);
  const rawPostal = str(formData, "postalCode", 10);
  let postalCode: string | null = null;
  if (rawPostal) {
    const r = checkPostalCode(rawPostal);
    if (!r.ok) throw new Error(r.error);
    postalCode = r.value;
  }
  const identifiers: Record<string, string> = {};
  for (const [k, label] of [["franceTravail", "France Travail"], ["cpf", "CPF"], ["ine", "INE"], ["nir", "Sécurité sociale"]] as const) {
    const v = str(formData, `id_${k}`, 40);
    if (v) identifiers[label] = v;
  }
  return {
    civility: rawCiv ? z.enum(CIVILITIES).parse(rawCiv) : null,
    firstName: z.string().trim().min(1, "Prénom requis").max(80).parse(formData.get("firstName")),
    lastName: z.string().trim().min(1, "Nom requis").max(80).parse(formData.get("lastName")),
    birthName: str(formData, "birthName", 80),
    birthDate: isoDate(formData, "birthDate"),
    birthPlace: str(formData, "birthPlace", 120),
    nationality: str(formData, "nationality", 80),
    email: optEmail(formData, "email"),
    phone: str(formData, "phone", 40),
    addressLine1: str(formData, "addressLine1", 200),
    addressLine2: str(formData, "addressLine2", 200),
    postalCode,
    city: str(formData, "city", 120),
    status: z.enum(PERSON_STATUS).parse(formData.get("status") || "candidat"),
    companyId: await optionalRef(ctx, formData, "companyId", "companies"),
    educationLevel: str(formData, "educationLevel", 120),
    situation: str(formData, "situation", 120),
    identifiers,
    hasAccommodations: bool(formData, "hasAccommodations"),
    accommodations: bool(formData, "hasAccommodations") ? str(formData, "accommodations", 2000) : null,
    source: str(formData, "source", 120),
    tags: tagList(str(formData, "tags", 1000)),
  };
}

export async function createPersonAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let orgId = "";
  let id = "";
  try {
    orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const values = await personValues(ctx, formData);
    if (!bool(formData, "ignoreDuplicates")) {
      const dups = await findPersonDuplicates(ctx.org.id, values);
      const w = duplicateWarning("personne", dups, (r: { firstName: string; lastName: string; email: string | null; birthDate: string | null }) => `${r.firstName} ${r.lastName}${r.email ? ` (${r.email})` : ""}${r.birthDate ? `, né(e) le ${r.birthDate.split("-").reverse().join("/")}` : ""}`);
      if (w) return { error: `${w} Cochez « Créer malgré tout » si c'est bien une autre personne.` };
    }
    const [row] = await db.insert(schema.persons).values({ ...values, orgId: ctx.org.id, isDemo: ctx.org.isDemo }).returning({ id: schema.persons.id });
    await audit({ action: "person.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "person", entityId: row.id, after: { firstName: values.firstName, lastName: values.lastName, status: values.status } });
    revalidatePath(`${base(orgId)}/candidats`);
    id = row.id;
  } catch (e) {
    return fail(e, "Création impossible.");
  }
  redirect(`${base(orgId)}/candidats/${id}`);
}

export async function updatePersonAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const before = await loadPerson(ctx, uuid.parse(formData.get("personId")));
    const values = await personValues(ctx, formData);
    await db.update(schema.persons).set(values).where(eq(schema.persons.id, before.id));
    await audit({ action: "person.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "person", entityId: before.id, before: { firstName: before.firstName, lastName: before.lastName, status: before.status, email: before.email }, after: { firstName: values.firstName, lastName: values.lastName, status: values.status, email: values.email } });
    revalidatePath(`${base(orgId)}/candidats/${before.id}`);
    revalidatePath(`${base(orgId)}/candidats`);
    return { ok: true, message: "Fiche enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Notes sensibles (recrutement) : lecture et écriture réservées à candidates.cv.view. */
export async function updateConfidentialNotesAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage", "candidates.cv.view");
    const p = await loadPerson(ctx, uuid.parse(formData.get("personId")));
    const notes = str(formData, "confidentialNotes", 10000);
    await db.update(schema.persons).set({ confidentialNotes: notes }).where(eq(schema.persons.id, p.id));
    await audit({ action: "person.confidential_notes.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "person", entityId: p.id, after: { length: notes?.length ?? 0 } });
    revalidatePath(`${base(orgId)}/candidats/${p.id}`);
    return { ok: true, message: "Notes sensibles enregistrées." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Dépôt de CV : document catégorie cv, visibilité confidentiel, lié à persons.cvDocumentId (nouvelle version si un CV existe). */
export async function uploadCvAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage", "candidates.cv.view");
    const p = await loadPerson(ctx, uuid.parse(formData.get("personId")));
    const file = formData.get("file");
    if (!(file instanceof File) || !file.size) return { error: "Choisissez un fichier." };
    const data = Buffer.from(await file.arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head: data.subarray(0, 8) });
    if (!check.ok) return { error: check.error };
    const doc = await createDocument({
      orgId: ctx.org.id,
      personId: p.id,
      category: "cv",
      visibility: "confidentiel",
      status: "valide",
      title: `CV ${fullName(p)}`,
      fileName: file.name,
      mimeType: check.mime,
      data,
      sourceType: "person",
      sourceId: p.id,
      uploadedBy: ctx.user.id,
      previousVersionId: p.cvDocumentId,
      isDemo: ctx.org.isDemo,
    });
    await db.update(schema.persons).set({ cvDocumentId: doc.id }).where(eq(schema.persons.id, p.id));
    await audit({ action: "person.cv.upload", userId: ctx.user.id, orgId: ctx.org.id, entityType: "person", entityId: p.id, after: { documentId: doc.id, version: doc.version } });
    revalidatePath(`${base(orgId)}/candidats/${p.id}`);
    return { ok: true, message: `CV déposé (version ${doc.version}).` };
  } catch (e) {
    return fail(e, "Dépôt impossible.");
  }
}

/** Téléchargement d'un document lié au CRM / catalogue / formateurs : lien temporaire puis redirection. */
export async function downloadDocumentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let url = "";
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "documents.view");
    const id = uuid.parse(formData.get("documentId"));
    const [doc] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, id), eq(schema.documents.orgId, ctx.org.id))).limit(1);
    if (!doc) return { error: "Document introuvable." };
    if ((doc.category === "cv" || doc.visibility === "confidentiel") && !ctx.permissions.has("candidates.cv.view")) return { error: "Accès non attribué : ce document est réservé aux personnes habilitées (CV et notes sensibles)." };
    if (doc.visibility === "administratif" && !ctx.permissions.has("dossier.admin_docs.view")) return { error: "Accès non attribué : pièce administrative." };
    url = await issueDownloadLink(doc.id, ctx.user.id);
  } catch (e) {
    return fail(e, "Téléchargement impossible.");
  }
  redirect(url);
}

// ---------------------------------------------------------------------------
// Catalogue public : demande d'information (sans session, limitée en débit)
// ---------------------------------------------------------------------------

export async function publicInfoRequestAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ip = await clientIp();
    const rl = await hit("public:catalogue", ip, { limit: 10, windowSeconds: 60 * 60 });
    if (!rl.ok) return { error: tooManyMessage(rl) };
    if (str(formData, "website_url", 200)) return { ok: true, message: "Merci, votre demande a été transmise." }; // pot de miel anti-robot
    const orgId = uuid.parse(formData.get("orgId"));
    const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
    if (!org) return { error: "Organisme introuvable." };
    const d = z
      .object({
        firstName: z.string().trim().min(1, "Prénom requis").max(80),
        lastName: z.string().trim().min(1, "Nom requis").max(80),
        email: z.string().trim().toLowerCase().email("Adresse e-mail invalide"),
        phone: z.string().trim().max(40).optional(),
        company: z.string().trim().max(200).optional(),
        message: z.string().trim().max(3000).optional(),
        programId: z.string().uuid().optional().or(z.literal("")),
        consent: z.literal("on", { error: "Acceptez le traitement de votre demande pour continuer." }),
      })
      .parse(Object.fromEntries(formData));
    let program: { id: string; title: string } | null = null;
    if (d.programId) {
      const [pr] = await db.select({ id: schema.programs.id, title: schema.programs.title }).from(schema.programs).where(and(eq(schema.programs.id, d.programId), eq(schema.programs.orgId, org.id), eq(schema.programs.isPublished, true))).limit(1);
      program = pr ?? null;
    }
    const needId = await db.transaction(async (tx) => {
      let companyId: string | null = null;
      let contactId: string | null = null;
      let personId: string | null = null;
      if (d.company) {
        const [c] = await tx.insert(schema.companies).values({ orgId: org.id, name: d.company, status: "prospect", source: "catalogue public", isDemo: org.isDemo }).returning({ id: schema.companies.id });
        companyId = c.id;
        const [ct] = await tx.insert(schema.contacts).values({ orgId: org.id, companyId, firstName: d.firstName, lastName: d.lastName, email: d.email, phone: d.phone || null, gdprConsentAt: new Date() }).returning({ id: schema.contacts.id });
        contactId = ct.id;
      } else {
        const [p] = await tx.insert(schema.persons).values({ orgId: org.id, firstName: d.firstName, lastName: d.lastName, email: d.email, phone: d.phone || null, status: "candidat", source: "catalogue public", gdprConsentAt: new Date(), isDemo: org.isDemo }).returning({ id: schema.persons.id });
        personId = p.id;
      }
      const [n] = await tx
        .insert(schema.needs)
        .values({
          orgId: org.id,
          companyId,
          contactId,
          personId,
          kind: "formation",
          title: program ? `Demande d'information : ${program.title}` : `Demande d'information (${d.firstName} ${d.lastName})`,
          description: [d.message, d.phone ? `Téléphone : ${d.phone}` : null, `E-mail : ${d.email}`].filter(Boolean).join("\n"),
          programId: program?.id ?? null,
          stage: "nouveau",
          source: "catalogue public",
          nextAction: "Rappeler le demandeur",
          nextActionAt: todayParis(),
          isDemo: org.isDemo,
        })
        .returning({ id: schema.needs.id });
      await tx.insert(schema.interactions).values({ orgId: org.id, companyId, contactId, personId, needId: n.id, kind: "note", subject: "Demande d'information reçue depuis le catalogue public", body: d.message || null });
      return n.id;
    });
    await createTaskOnce({
      orgId: org.id,
      title: `Rappeler ${d.firstName} ${d.lastName} (demande catalogue)`,
      description: program ? `Demande d'information sur « ${program.title} » reçue depuis le catalogue public.` : "Demande d'information reçue depuis le catalogue public.",
      family: "commercial",
      entityType: "need",
      entityId: needId,
      entityLabel: `${d.firstName} ${d.lastName}`,
      href: `${base(org.id)}/besoins/${needId}`,
      assigneeRole: "sales",
      dueDate: todayParis(),
      priority: "haute",
      idempotencyKey: `need:${needId}:public_request`,
      isDemo: org.isDemo,
    });
    await audit({ action: "need.public_request", orgId: org.id, entityType: "need", entityId: needId, after: { email: d.email, programId: program?.id ?? null, ip } });
    return { ok: true, message: "Merci, votre demande a été transmise. L'organisme vous recontactera rapidement." };
  } catch (e) {
    return fail(e, "Envoi impossible.");
  }
}
