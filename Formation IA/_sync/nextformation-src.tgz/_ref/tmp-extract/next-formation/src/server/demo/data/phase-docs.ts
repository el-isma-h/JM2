/**
 * Phase documents : fichiers réels (PDF pdfkit, texte, SVG) via createDocument, logo et plan d'accès,
 * RIB central, CV formateurs, pièces déposées, puis feuilles d'émargement des périodes clôturées.
 */
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { createDocument } from "@/server/documents/store";
import { putObject, buildKey } from "@/server/storage";
import { encrypt } from "@/lib/crypto";
import { fmtMinutes } from "@/lib/time";
import { addD, daysAgo, logoSvg, simplePdf, slugify } from "./util";
import { PROGRAMS } from "./programs";
import { COMPANIES } from "./people";
import { bump, type State } from "./state";

const DEMO_FOOTER = "Document de démonstration : données fictives, sans valeur contractuelle.";

export async function phaseDocuments(s: State) {
  const { orgId, users } = s;
  const org = s.org;
  let n = 0;
  const doc = async (input: Parameters<typeof createDocument>[0]) => {
    const row = await createDocument({ ...input, isDemo: true });
    n++;
    return row.id;
  };

  /* ---------- Logo, plan d'accès, RIB ---------- */
  const logoKey = buildKey(orgId, "charte", "logo.svg");
  await putObject(logoKey, Buffer.from(logoSvg("AM", "#4b2a7f"), "utf8"));
  const planPdf = await simplePdf({ org, kicker: "Plan d'accès", title: "Venir au site Paris 11e", paragraphs: ["14 rue des Tanneurs, 75011 Paris. Métro Voltaire (ligne 9) ou Charonne (ligne 9), bus 46 et 56.", "Entrée par le porche, interphone « Atelier Méridien ». Ascenseur jusqu'au 2e étage. Accueil ouvert de 8 h 30 à 18 h.", "Accessibilité : place PMR devant le 12, boucle magnétique à l'accueil, sanitaires adaptés à chaque étage."], footer: DEMO_FOOTER });
  const planId = await doc({ orgId, category: "plan_acces", visibility: "public", status: "valide", title: "Plan d'accès : site Paris 11e", fileName: "plan-acces-paris-11.pdf", mimeType: "application/pdf", data: planPdf, sourceType: "site", sourceId: s.siteIds.paris, uploadedBy: users.direction });
  const [planDoc] = await db.select({ key: schema.documents.storageKey }).from(schema.documents).where(eq(schema.documents.id, planId)).limit(1);
  await db.update(schema.sites).set({ accessPlanKey: planDoc.key }).where(eq(schema.sites.id, s.siteIds.paris));
  const ribPdf = await simplePdf({ org, kicker: "Relevé d'identité bancaire", title: "RIB de l'organisme (document confidentiel)", paragraphs: ["Titulaire : Atelier Méridien Formation SAS", "IBAN : FR76 3000 4000 0312 3456 7890 143 (fictif)", "BIC : BNPAFRPPXXX (fictif)", "Domiciliation : agence Paris Voltaire."], footer: DEMO_FOOTER });
  s.documents.rib = await doc({ orgId, category: "rib", visibility: "confidentiel", status: "valide", title: "RIB central de l'organisme", fileName: "rib-atelier-meridien.pdf", mimeType: "application/pdf", data: ribPdf, sourceType: "org_rib", sourceId: orgId, uploadedBy: users.direction });
  let ribEnc: string | null = null;
  try {
    ribEnc = encrypt("FR7630004000031234567890143", "rib");
  } catch {
    ribEnc = null;
  }
  await db.update(schema.organismes).set({ logoKey, ribIbanEnc: ribEnc, ribIbanLast4: "0143", ribBic: "BNPAFRPPXXX", ribHolder: "Atelier Méridien Formation SAS", documentFooter: "Atelier Méridien Formation SAS, 14 rue des Tanneurs 75011 Paris. SIRET 913 245 676 00022. Déclaration d'activité n° 11 75 61234 75 (ne vaut pas agrément de l'État)." }).where(eq(schema.organismes.id, orgId));

  /* ---------- Programmes ---------- */
  for (const p of PROGRAMS) {
    const info = s.programs[p.key];
    const pdf = await simplePdf({ org, kicker: "Programme de formation", title: p.title, paragraphs: [`Objectifs : ${p.version.objectives}`, `Prérequis : ${p.version.prerequisites}`, `Public : ${p.version.audience}`, `Durée : ${p.version.durationHours} heures (${p.version.durationDays} jours). Modalité : ${p.version.modality}.`, `Contenu : ${p.version.content}`, `Méthodes : ${p.version.methods}`, `Évaluation : ${p.version.evaluationMethods}`, `Accessibilité : ${p.version.accessibility}`, `Tarif : ${p.version.priceCents ? `${(p.version.priceCents / 100).toLocaleString("fr-FR")} € HT` : "sur devis"}. ${p.version.priceNote}`, `Délai d'accès : ${p.version.accessDelay}`], footer: DEMO_FOOTER });
    s.documents[`programme:${p.key}`] = await doc({ orgId, category: "programme", visibility: "public", status: "valide", title: `Programme : ${p.title}`, fileName: `programme-${slugify(p.code)}.pdf`, mimeType: "application/pdf", data: pdf, templateCode: "programme_v1", generationData: { programId: info.id, versionId: info.versionId, version: 1 }, sourceType: "program_version", sourceId: info.versionId, uploadedBy: users.pedagogy });
  }

  /* ---------- Conventions signées, convocations, attestations, certificats ---------- */
  const byCompanySession = new Map<string, State["enrollments"]>();
  for (const e of s.enrollments) {
    if (e.contractKind !== "convention_formation" || !e.companyKey) continue;
    if (!["sst1", "xls1", "mgt", "elec", "xls2", "intra"].includes(e.sessionKey)) continue;
    const k = `${e.sessionKey}:${e.companyKey}`;
    byCompanySession.set(k, [...(byCompanySession.get(k) ?? []), e]);
  }
  for (const [k, list] of byCompanySession) {
    const first = list[0];
    const sess = s.sessions[first.sessionKey];
    const signed = sess.status === "terminee" || sess.status === "confirmee" || first.companyKey === "distrimarche";
    const pdf = await simplePdf({ org, kicker: "Convention de formation professionnelle", title: `Convention n° CONV-${first.reference.slice(4)} : ${s.programs[sess.programKey].title}`, paragraphs: [`Entre l'organisme de formation Atelier Méridien Formation et l'entreprise ${COMPANIES.find((c) => c.key === first.companyKey)?.name ?? first.companyKey}, il est convenu l'action de formation suivante.`, `Dates : du ${sess.startDate} au ${sess.endDate}. Lieu : ${sess.siteId ? "centre de formation" : "locaux du client"}.`, `Stagiaires (${list.length}) : ${list.map((e) => e.personName).join(", ")}.`, "Prix, modalités de règlement, conditions d'annulation et de report selon les conditions générales de vente annexées.", signed ? "Signé électroniquement par les deux parties." : "En attente de signature de l'entreprise."], footer: DEMO_FOOTER });
    s.documents[`convention:${k}`] = await doc({ orgId, enrollmentId: first.id, sessionId: sess.id, companyId: first.companyId, category: "convention", visibility: "entreprise", status: signed ? "signe" : "transmis", title: `Convention de formation : ${s.programs[sess.programKey].title} (${list.length} stagiaire${list.length > 1 ? "s" : ""})`, fileName: `convention-${slugify(k)}.pdf`, mimeType: "application/pdf", data: pdf, templateCode: "convention_v1", generationData: { sessionId: sess.id, enrollmentIds: list.map((e) => e.id) }, sourceType: "enrollment", sourceId: first.id, uploadedBy: users.admin });
    if (signed) await db.update(schema.documents).set({ transmittedAt: new Date(`${addD(sess.startDate, -20)}T10:00:00Z`), signedAt: new Date(`${addD(sess.startDate, -14)}T15:20:00Z`) }).where(eq(schema.documents.id, s.documents[`convention:${k}`]));
    else await db.update(schema.documents).set({ transmittedAt: new Date(`${daysAgo(s.today, 6)}T10:00:00Z`) }).where(eq(schema.documents.id, s.documents[`convention:${k}`]));
  }
  for (const e of s.enrollments.filter((x) => ["mgt", "elec", "intra"].includes(x.sessionKey) && x.status === "inscrit")) {
    const sess = s.sessions[e.sessionKey];
    const pdf = await simplePdf({ org, kicker: "Convocation", title: `Convocation : ${s.programs[sess.programKey].title}`, paragraphs: [`${e.personName}, vous êtes attendu(e) le ${sess.startDate} à 9 h 00.`, sess.siteId ? "Lieu : 14 rue des Tanneurs, 75011 Paris (plan d'accès joint)." : "Lieu : dans les locaux de votre établissement.", "Horaires : 9 h 00 à 12 h 00 et 14 h 00 à 17 h 00. Merci de vous munir d'une pièce d'identité.", "Le règlement intérieur et le programme sont joints à ce courrier."], footer: DEMO_FOOTER });
    s.documents[`convocation:${e.id}`] = await doc({ orgId, enrollmentId: e.id, personId: e.personId, sessionId: sess.id, category: "convocation", visibility: "apprenant", status: "transmis", title: `Convocation : ${e.personName}`, fileName: `convocation-${e.reference}.pdf`, mimeType: "application/pdf", data: pdf, templateCode: "convocation_v1", generationData: { enrollmentId: e.id }, sourceType: "enrollment", sourceId: e.id, uploadedBy: users.admin });
  }
  for (const e of s.enrollments.filter((x) => (x.sessionKey === "sst1" || x.sessionKey === "xls1") && x.status === "termine")) {
    const sess = s.sessions[e.sessionKey];
    const hours = s.programs[sess.programKey].durationHours;
    const att = await simplePdf({ org, kicker: "Attestation de fin de formation", title: `Attestation : ${e.personName}`, paragraphs: [`Nous attestons que ${e.personName} a suivi la formation « ${s.programs[sess.programKey].title} » du ${sess.startDate} au ${sess.endDate}, d'une durée de ${hours} heures.`, "Objectifs et résultats de l'évaluation : voir l'annexe pédagogique.", `Fait à Paris le ${addD(sess.endDate, 2)}. La directrice, Élise Marchetti.`], footer: DEMO_FOOTER });
    s.documents[`attestation:${e.id}`] = await doc({ orgId, enrollmentId: e.id, personId: e.personId, sessionId: sess.id, category: "attestation", visibility: "apprenant", status: "transmis", title: `Attestation de fin de formation : ${e.personName}`, fileName: `attestation-${e.reference}.pdf`, mimeType: "application/pdf", data: att, templateCode: "attestation_v1", generationData: { enrollmentId: e.id, hours }, sourceType: "enrollment", sourceId: e.id, uploadedBy: users.admin });
    const cert = await simplePdf({ org, kicker: "Certificat de réalisation", title: `Certificat de réalisation : ${e.personName}`, paragraphs: [`Action : ${s.programs[sess.programKey].title}. Nature : action de formation. Dates : du ${sess.startDate} au ${sess.endDate}.`, `Durée réalisée : ${fmtMinutes(hours * 60)} sur ${fmtMinutes(hours * 60)} prévues (émargements par demi-journée clôturés).`, `Fait à Paris le ${addD(sess.endDate, 2)}.`], footer: DEMO_FOOTER });
    s.documents[`certificat:${e.id}`] = await doc({ orgId, enrollmentId: e.id, personId: e.personId, sessionId: sess.id, companyId: e.companyId, category: "certificat_realisation", visibility: "entreprise", status: "valide", title: `Certificat de réalisation : ${e.personName}`, fileName: `certificat-realisation-${e.reference}.pdf`, mimeType: "application/pdf", data: cert, templateCode: "certificat_realisation_v1", generationData: { enrollmentId: e.id, hours }, sourceType: "enrollment", sourceId: e.id, uploadedBy: users.admin });
  }

  /* ---------- CV formateurs ---------- */
  for (const t of [{ key: "claire", name: "Claire Vasseur", body: "Formatrice bureautique depuis 2014. Certification TOSA Excel expert (2024). Master MIAGE. Interventions : Excel, Power Query, Power BI." }, { key: "isabelle", name: "Isabelle Tanguy", body: "Ancienne DRH en PME industrielle (18 ans). Titre professionnel formateur pour adultes (2021). Coach certifiée. Interventions : RH, management, paie." }]) {
    const pdf = await simplePdf({ org, kicker: "Curriculum vitae", title: t.name, paragraphs: [t.body, "Références disponibles sur demande."], footer: DEMO_FOOTER });
    s.documents[`cv:${t.key}`] = await doc({ orgId, trainerId: s.trainers[t.key], category: "cv", visibility: "confidentiel", status: "valide", title: `CV : ${t.name}`, fileName: `cv-${slugify(t.name)}.pdf`, mimeType: "application/pdf", data: pdf, sourceType: "trainer", sourceId: s.trainers[t.key], uploadedBy: users.pedagogy });
  }
  bump(s, "documents", n);
}

/** Pièces déposées (fichiers texte légers) pour les dossiers du groupe A du BTS et de la session titre pro. */
export async function createPieceDocument(s: State, e: State["enrollments"][number], piece: State["requiredPieces"][number]) {
  const row = await createDocument({ orgId: s.orgId, enrollmentId: e.id, personId: e.personId, category: piece.category as "justificatif", visibility: "administratif", status: "valide", title: `${piece.code.replace(/_/g, " ")} : ${e.personName}`, fileName: `${piece.code}-${e.reference}.txt`, mimeType: "text/plain", data: Buffer.from(`Pièce « ${piece.code} » déposée pour ${e.personName} (${e.reference}).\nDocument de démonstration, contenu fictif.\n`, "utf8"), sourceType: "piece", sourceId: e.id, uploadedBy: s.users.admin, isDemo: true });
  bump(s, "documents", 1);
  return row.id;
}

/** Feuilles d'émargement des périodes clôturées (sessions courtes terminées et dernières semaines des sessions en cours). */
export async function phaseAttendanceSheets(s: State) {
  const closed = s.periods.filter((p) => p.status === "cloturee");
  const short = closed.filter((p) => p.sessionKey === "sst1" || p.sessionKey === "xls1");
  const recentArh = closed.filter((p) => p.sessionKey === "arh").slice(-8);
  const recentBts = closed.filter((p) => p.sessionKey === "bts" && p.groupIdx === 0).slice(-6);
  const targets = [...short, ...recentArh, ...recentBts];
  const attRows = await db
    .select({ periodId: schema.attendances.periodId, enrollmentId: schema.attendances.enrollmentId, status: schema.attendances.status, minutes: schema.attendances.minutesCounted })
    .from(schema.attendances)
    .where(eq(schema.attendances.orgId, s.orgId));
  const nameOf = new Map(s.enrollments.map((e) => [e.id, e.personName]));
  for (const p of targets) {
    const sess = s.sessions[p.sessionKey];
    const rows = attRows.filter((a) => a.periodId === p.id).map((a) => [nameOf.get(a.enrollmentId) ?? "", a.status, fmtMinutes(a.minutes), a.status === "absent" || a.status === "absent_justifie" ? "" : "signé (tablette / QR)"]);
    const pdf = await simplePdf({ org: s.org, kicker: "Feuille d'émargement", title: `${s.programs[sess.programKey].title} : ${p.date}, ${p.part === "matin" ? "matin (9 h 00 à 12 h 00)" : "après-midi (14 h 00 à 17 h 00)"}`, paragraphs: [`Session ${sess.id.slice(0, 8)}. Période clôturée par le formateur après signature de fin ; aucune modification possible sans circuit de correction.`], table: { head: ["Stagiaire", "Statut", "Durée comptée", "Signature"], rows }, footer: DEMO_FOOTER });
    const row = await createDocument({ orgId: s.orgId, sessionId: sess.id, category: "feuille_emargement", visibility: "interne", status: "valide", title: `Feuille d'émargement : ${p.date} ${p.part === "matin" ? "matin" : "après-midi"}`, fileName: `emargement-${p.date}-${p.part}${p.groupIdx !== null ? `-g${p.groupIdx + 1}` : ""}.pdf`, mimeType: "application/pdf", data: pdf, templateCode: "feuille_emargement_v1", generationData: { periodId: p.id }, sourceType: "period", sourceId: p.id, uploadedBy: s.users.pedagogy, isDemo: true });
    s.documents[`emargement:${p.id}`] = row.id;
    bump(s, "documents", 1);
  }
}
