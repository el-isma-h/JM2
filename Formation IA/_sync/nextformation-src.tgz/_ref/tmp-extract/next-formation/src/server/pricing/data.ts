/**
 * Grille tarifaire Next Formation = grille publique Digiforma (digiforma.com/prix, relevée le 23/10/2026) × 0,90.
 * Aucun prix n'est inventé : chaque ligne porte son prix de référence, sa source et sa date de relevé.
 * Montants en centimes HT. `priceCents` : engagement annuel ; `priceMonthlyCents` : sans engagement.
 */
const REF_URL = "https://www.digiforma.com/prix/";
const REF_DATE = "2026-10-23";
const RATE = 0.9;
const r = (euros: number) => Math.round(euros * 100 * RATE);

type Row = {
  code: string;
  name: string;
  description: string;
  isOption: boolean;
  unit: "forfait_mois" | "option_mois" | "par_apprenant_an" | "par_organisme_mois" | "sur_devis" | "inclus";
  priceCents: number | null;
  priceMonthlyCents: number | null;
  referencePriceCents: number | null;
  referenceMonthlyCents: number | null;
  referenceLabel: string;
  referenceUrl: string;
  referenceCheckedAt: string;
  discountRate: number;
  limits: Record<string, unknown>;
  features: string[];
  calculationNote: string;
  sortOrder: number;
};

const COMMON = [
  "CRM et pipeline commercial",
  "Catalogue et programmes versionnés",
  "Sessions, inscriptions OF et CFA",
  "Planning et émargement par demi-journée",
  "Documents générés (conventions, convocations, attestations)",
  "Financements, factures et règlements",
  "Conformité qualité explicable (Qualiopi)",
  "Tâches, relais et pilotage par rôle",
  "Extranets apprenant, entreprise et formateur",
  "Assistant IA avec validation humaine",
  "Hébergement en France, sauvegardes quotidiennes",
];

export const PRICING_ROWS: Row[] = [
  {
    code: "indep",
    name: "Indépendant",
    description: "Formateur indépendant ou micro-organisme : jusqu'à 200 apprenants par an, 1 utilisateur, 1 formateur.",
    isOption: false,
    unit: "forfait_mois",
    priceCents: r(49),
    priceMonthlyCents: r(59),
    referencePriceCents: 4900,
    referenceMonthlyCents: 5900,
    referenceLabel: "Digiforma Indep : 49 € HT/mois (engagement annuel), 59 € sans engagement",
    referenceUrl: REF_URL,
    referenceCheckedAt: REF_DATE,
    discountRate: 1000,
    limits: { learnersPerYear: 200, users: 1, trainers: 1 },
    features: COMMON,
    calculationNote: "49 € × 0,90 = 44,10 € ; 59 € × 0,90 = 53,10 €",
    sortOrder: 1,
  },
  {
    code: "equipe",
    name: "Équipe",
    description: "Petit organisme : jusqu'à 500 apprenants par an, 4 utilisateurs, 20 formateurs.",
    isOption: false,
    unit: "forfait_mois",
    priceCents: r(199),
    priceMonthlyCents: r(239),
    referencePriceCents: 19900,
    referenceMonthlyCents: 23900,
    referenceLabel: "Digiforma Equipe : 199 € HT/mois (engagement annuel), 239 € sans engagement",
    referenceUrl: REF_URL,
    referenceCheckedAt: REF_DATE,
    discountRate: 1000,
    limits: { learnersPerYear: 500, users: 4, trainers: 20 },
    features: COMMON,
    calculationNote: "199 € × 0,90 = 179,10 € ; 239 € × 0,90 = 215,10 €",
    sortOrder: 2,
  },
  {
    code: "orga",
    name: "Organisme",
    description: "Organisme structuré : jusqu'à 1 500 apprenants par an, 8 utilisateurs, formateurs illimités, accompagnement individuel.",
    isOption: false,
    unit: "forfait_mois",
    priceCents: r(349),
    priceMonthlyCents: r(419),
    referencePriceCents: 34900,
    referenceMonthlyCents: 41900,
    referenceLabel: "Digiforma Orga : 349 € HT/mois (engagement annuel), 419 € sans engagement",
    referenceUrl: REF_URL,
    referenceCheckedAt: REF_DATE,
    discountRate: 1000,
    limits: { learnersPerYear: 1500, users: 8, trainers: null },
    features: [...COMMON, "Accompagnement individuel au démarrage"],
    calculationNote: "349 € × 0,90 = 314,10 € ; 419 € × 0,90 = 377,10 €",
    sortOrder: 3,
  },
  {
    code: "orga_plus",
    name: "Organisme +",
    description: "Organisme multi-activités ou CFA : jusqu'à 2 500 apprenants par an, 12 utilisateurs, formateurs illimités, support prioritaire.",
    isOption: false,
    unit: "forfait_mois",
    priceCents: r(499),
    priceMonthlyCents: r(599),
    referencePriceCents: 49900,
    referenceMonthlyCents: 59900,
    referenceLabel: "Digiforma Orga+ : 499 € HT/mois (engagement annuel), 599 € sans engagement",
    referenceUrl: REF_URL,
    referenceCheckedAt: REF_DATE,
    discountRate: 1000,
    limits: { learnersPerYear: 2500, users: 12, trainers: null },
    features: [...COMMON, "Accompagnement individuel", "Support prioritaire"],
    calculationNote: "499 € × 0,90 = 449,10 € ; 599 € × 0,90 = 539,10 €",
    sortOrder: 4,
  },
  {
    code: "leader",
    name: "Groupe",
    description: "Plus de 2 500 apprenants par an, utilisateurs et formateurs illimités, multi-organismes, référent de compte.",
    isOption: false,
    unit: "sur_devis",
    priceCents: r(699),
    priceMonthlyCents: r(839),
    referencePriceCents: 69900,
    referenceMonthlyCents: 83900,
    referenceLabel: "Digiforma Leader : dès 699 € HT/mois (engagement annuel), à partir de 839 € sans engagement",
    referenceUrl: REF_URL,
    referenceCheckedAt: REF_DATE,
    discountRate: 1000,
    limits: { learnersPerYear: null, users: null, trainers: null },
    features: [...COMMON, "Multi-organismes et groupe", "Référent de compte", "Support prioritaire"],
    calculationNote: "À partir de 699 € × 0,90 = 629,10 € ; devis selon périmètre",
    sortOrder: 5,
  },
  { code: "opt_admin", name: "Administration +", description: "Espaces entreprise étendus, personnalisation avancée des documents et des portails.", isOption: true, unit: "option_mois", priceCents: r(29), priceMonthlyCents: r(29), referencePriceCents: 2900, referenceMonthlyCents: 2900, referenceLabel: "Digiforma Admin+ : à partir de 29 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "29 € × 0,90 = 26,10 €", sortOrder: 10 },
  { code: "opt_lms", name: "E-learning +", description: "LMS complet : import SCORM / xAPI, connexion Moodle, parcours mixtes, temps à distance validé.", isOption: true, unit: "option_mois", priceCents: r(59), priceMonthlyCents: r(59), referencePriceCents: 5900, referenceMonthlyCents: 5900, referenceLabel: "Digiforma LMS+ : à partir de 59 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "59 € × 0,90 = 53,10 €", sortOrder: 11 },
  { code: "opt_pedagogie", name: "Pédagogie +", description: "Livrets d'apprentissage avancés, suivi en entreprise, évaluations par compétences.", isOption: true, unit: "option_mois", priceCents: r(29), priceMonthlyCents: r(29), referencePriceCents: 2900, referenceMonthlyCents: 2900, referenceLabel: "Digiforma Pédagogie+ : à partir de 29 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "29 € × 0,90 = 26,10 €", sortOrder: 12 },
  { code: "opt_finance", name: "Finance +", description: "Paiement en ligne, relances automatiques, rapprochement bancaire, exports comptables.", isOption: true, unit: "option_mois", priceCents: r(29), priceMonthlyCents: r(29), referencePriceCents: 2900, referenceMonthlyCents: 2900, referenceLabel: "Digiforma Finance+ : à partir de 29 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "29 € × 0,90 = 26,10 €", sortOrder: 13 },
  { code: "opt_signature", name: "Signature électronique", description: "Signature électronique des conventions, contrats et documents avec preuve horodatée.", isOption: true, unit: "option_mois", priceCents: r(29), priceMonthlyCents: r(29), referencePriceCents: 2900, referenceMonthlyCents: 2900, referenceLabel: "Digiforma Signature électronique : à partir de 29 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "29 € × 0,90 = 26,10 €", sortOrder: 14 },
  { code: "opt_emargement", name: "Émargement sécurisé", description: "Émargement par QR code tournant, tablette et e-mail, horodatage serveur, verrouillage des périodes.", isOption: true, unit: "option_mois", priceCents: r(29), priceMonthlyCents: r(29), referencePriceCents: 2900, referenceMonthlyCents: 2900, referenceLabel: "Digiforma Émargement Sécurisé : à partir de 29 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "29 € × 0,90 = 26,10 €", sortOrder: 15 },
  { code: "opt_multi", name: "Multi-centres", description: "Plusieurs organismes ou sites isolés dans un même groupe, consolidation du pilotage.", isOption: true, unit: "option_mois", priceCents: r(99), priceMonthlyCents: r(99), referencePriceCents: 9900, referenceMonthlyCents: 9900, referenceLabel: "Digiforma Multi-centres : à partir de 99 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "99 € × 0,90 = 89,10 €", sortOrder: 16 },
  { code: "opt_api", name: "API et webhooks", description: "API REST, webhooks, Zapier, connexion Microsoft 365 et outils métier.", isOption: true, unit: "option_mois", priceCents: r(29), priceMonthlyCents: r(29), referencePriceCents: 2900, referenceMonthlyCents: 2900, referenceLabel: "Digiforma API : à partir de 29 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "29 € × 0,90 = 26,10 €", sortOrder: 17 },
  { code: "opt_wordpress", name: "Catalogue WordPress", description: "Catalogue de formations synchronisé sur votre site WordPress, inscriptions en ligne.", isOption: true, unit: "option_mois", priceCents: r(29), priceMonthlyCents: r(29), referencePriceCents: 2900, referenceMonthlyCents: 2900, referenceLabel: "Digiforma Catalogue WordPress : 29 € HT/mois", referenceUrl: REF_URL, referenceCheckedAt: REF_DATE, discountRate: 1000, limits: {}, features: [], calculationNote: "29 € × 0,90 = 26,10 €", sortOrder: 18 },
];
