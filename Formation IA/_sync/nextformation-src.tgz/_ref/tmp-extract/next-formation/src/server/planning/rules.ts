/**
 * Règles de planification pures (F05) : génération de séances en série et détection de conflits.
 * Testées dans __tests__/planning-rules.test.ts.
 */

import { minutesBetween } from "../../lib/time";

export type Rhythm = { weekdays?: number[]; centerDays?: number; companyDays?: number; label?: string };
export type Schedule = { morning?: { start: string; end: string }; afternoon?: { start: string; end: string } };

export const DEFAULT_SCHEDULE: Required<Schedule> = { morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } };

/** Horaires effectifs : session, sinon organisme, sinon défaut. */
export function resolveSchedule(session: Schedule | null | undefined, org: Schedule | null | undefined): Required<Schedule> {
  return {
    morning: session?.morning?.start && session.morning.end ? session.morning : org?.morning?.start && org.morning.end ? org.morning : DEFAULT_SCHEDULE.morning,
    afternoon: session?.afternoon?.start && session.afternoon.end ? session.afternoon : org?.afternoon?.start && org.afternoon.end ? org.afternoon : DEFAULT_SCHEDULE.afternoon,
  };
}

function addDays(iso: string, n: number): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/** Jour de semaine ISO (1 = lundi … 7 = dimanche) d'une date ISO. */
export function isoWeekday(iso: string): number {
  const d = new Date(`${iso}T00:00:00Z`).getUTCDay();
  return d === 0 ? 7 : d;
}

export type ClosureRange = { startDate: string; endDate: string; siteId?: string | null };

export function isClosed(date: string, closures: ClosureRange[], siteId?: string | null): boolean {
  return closures.some((c) => date >= c.startDate && date <= c.endDate && (!c.siteId || !siteId || c.siteId === siteId));
}

/**
 * Dates des séances d'une série : entre deux dates, selon les jours de centre du rythme
 * (jours de semaine ISO ; par défaut lundi à vendredi), hors fermetures et jours exclus.
 */
export function generateSeriesDates(input: { from: string; to: string; weekdays?: number[]; closures?: ClosureRange[]; siteId?: string | null; excluded?: string[]; max?: number }): string[] {
  const weekdays = input.weekdays?.length ? input.weekdays : [1, 2, 3, 4, 5];
  const out: string[] = [];
  const max = input.max ?? 400;
  if (input.from > input.to) return out;
  for (let d = input.from; d <= input.to && out.length < max; d = addDays(d, 1)) {
    if (!weekdays.includes(isoWeekday(d))) continue;
    if (input.excluded?.includes(d)) continue;
    if (isClosed(d, input.closures ?? [], input.siteId)) continue;
    out.push(d);
  }
  return out;
}

export type PlannedPeriod = { date: string; startTime: string; endTime: string; part: "matin" | "apres_midi" | "journee" | "soir" };

export type ExistingPeriod = {
  periodId: string;
  slotId: string;
  date: string;
  startTime: string;
  endTime: string;
  trainerId?: string | null;
  roomId?: string | null;
  groupId?: string | null;
  sessionId?: string | null;
  sessionCode?: string | null;
  status?: string | null;
};

export type Unavailability = { trainerId: string; startDate: string; endDate: string; part?: string | null };

export type Conflict = { date: string; startTime: string; endTime: string; kind: "formateur" | "salle" | "groupe" | "indisponibilite" | "fermeture"; message: string };

export function overlaps(a: { startTime: string; endTime: string }, b: { startTime: string; endTime: string }): boolean {
  return a.startTime < b.endTime && b.startTime < a.endTime && minutesBetween(a.startTime, a.endTime) > 0 && minutesBetween(b.startTime, b.endTime) > 0;
}

/**
 * Détecte les conflits des périodes à créer : même créneau pour le même formateur, la même salle ou le même groupe,
 * indisponibilité du formateur, fermeture de l'organisme / du site. Les périodes annulées n'entrent pas en conflit.
 */
export function findConflicts(input: {
  planned: PlannedPeriod[];
  trainerId?: string | null;
  roomId?: string | null;
  groupId?: string | null;
  siteId?: string | null;
  existing: ExistingPeriod[];
  unavailabilities?: Unavailability[];
  closures?: ClosureRange[];
  /** Séance en cours de modification : ses propres périodes sont ignorées. */
  ignoreSlotId?: string | null;
}): Conflict[] {
  const out: Conflict[] = [];
  for (const p of input.planned) {
    if (isClosed(p.date, input.closures ?? [], input.siteId)) {
      out.push({ ...p, kind: "fermeture", message: `${p.date} : fermeture de l'organisme ou du site.` });
    }
    if (input.trainerId) {
      for (const u of input.unavailabilities ?? []) {
        if (u.trainerId !== input.trainerId) continue;
        if (p.date < u.startDate || p.date > u.endDate) continue;
        if (u.part && u.part !== "journee" && u.part !== p.part) continue;
        out.push({ ...p, kind: "indisponibilite", message: `${p.date} ${p.startTime}-${p.endTime} : formateur indisponible.` });
      }
    }
    for (const e of input.existing) {
      if (e.date !== p.date) continue;
      if (input.ignoreSlotId && e.slotId === input.ignoreSlotId) continue;
      if (e.status === "annulee") continue;
      if (!overlaps(p, e)) continue;
      const where = e.sessionCode ? ` (session ${e.sessionCode})` : "";
      if (input.trainerId && e.trainerId === input.trainerId) out.push({ ...p, kind: "formateur", message: `${p.date} ${p.startTime}-${p.endTime} : le formateur anime déjà une période${where}.` });
      if (input.roomId && e.roomId === input.roomId) out.push({ ...p, kind: "salle", message: `${p.date} ${p.startTime}-${p.endTime} : la salle est déjà occupée${where}.` });
      if (input.groupId && e.groupId === input.groupId) out.push({ ...p, kind: "groupe", message: `${p.date} ${p.startTime}-${p.endTime} : le groupe a déjà une période${where}.` });
    }
  }
  return out;
}

/** Périodes d'une séance selon les parties demandées. */
export function periodsForDay(date: string, parts: ("matin" | "apres_midi")[], schedule: Required<Schedule>): PlannedPeriod[] {
  const out: PlannedPeriod[] = [];
  if (parts.includes("matin")) out.push({ date, part: "matin", startTime: schedule.morning.start, endTime: schedule.morning.end });
  if (parts.includes("apres_midi")) out.push({ date, part: "apres_midi", startTime: schedule.afternoon.start, endTime: schedule.afternoon.end });
  return out;
}
