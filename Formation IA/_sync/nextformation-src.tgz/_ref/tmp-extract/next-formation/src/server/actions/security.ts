"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { sha256 } from "@/lib/crypto";
import { appUrl } from "@/lib/env";
import { issueToken, verifyPassword } from "@/server/auth";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { layoutMail, sendMail } from "@/server/mail";
import { notify } from "@/server/notify";
import { requireSecurityAdmin } from "@/server/security/access";
import { canReceiveOwnership, normalizePermissionOverrides, normalizeRoles } from "@/server/security/rules";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

function paths(orgId: string) {
  revalidatePath(`/app/${orgId}/securite`);
  revalidatePath(`/app/${orgId}`, "layout");
}

async function loadMembership(orgId: string, membershipId: string) {
  const [m] = await db.select().from(schema.memberships).where(and(eq(schema.memberships.id, membershipId), eq(schema.memberships.orgId, orgId))).limit(1);
  if (!m) throw new Error("Membre introuvable dans cet organisme.");
  return m;
}

/** Rôles additifs d'un membre (cases à cocher). Le propriétaire reste propriétaire quels que soient ses rôles. */
export async function updateMemberRolesAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const membershipId = uuid.parse(formData.get("membershipId"));
    const m = await loadMembership(orgId, membershipId);
    const current = Array.isArray(m.roles) ? (m.roles as string[]) : [];
    const kept = current.filter((r) => r === "learner" || r === "employer");
    const roles = [...normalizeRoles(formData.getAll("roles")), ...kept];
    await db.update(schema.memberships).set({ roles }).where(eq(schema.memberships.id, m.id));
    await audit({ action: "security.member.roles", userId: ctx.user.id, orgId, entityType: "membership", entityId: m.id, before: { roles: current }, after: { roles } });
    paths(orgId);
    return { ok: true, message: roles.length ? "Rôles enregistrés." : "Aucun rôle : le membre n'a plus accès à l'espace organisme (sauf s'il est propriétaire)." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Permissions fines : champs `perm:<permission>` = inherit | grant | deny. Les permissions propriétaire sont toujours rejetées. */
export async function updateMemberPermissionsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const membershipId = uuid.parse(formData.get("membershipId"));
    const m = await loadMembership(orgId, membershipId);
    const raw: Record<string, unknown> = {};
    for (const [k, v] of formData.entries()) {
      if (!k.startsWith("perm:")) continue;
      const perm = k.slice(5);
      if (v === "grant") raw[perm] = true;
      else if (v === "deny") raw[perm] = false;
    }
    const { overrides, rejected } = normalizePermissionOverrides(raw);
    await db.update(schema.memberships).set({ permissions: overrides }).where(eq(schema.memberships.id, m.id));
    await audit({ action: "security.member.permissions", userId: ctx.user.id, orgId, entityType: "membership", entityId: m.id, before: { permissions: m.permissions }, after: { permissions: overrides, rejected } });
    paths(orgId);
    return { ok: true, message: rejected.length ? `Permissions enregistrées. Ignorées (réservées au propriétaire) : ${rejected.join(", ")}.` : "Permissions fines enregistrées." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function setMemberActiveAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const membershipId = uuid.parse(formData.get("membershipId"));
    const active = formData.get("active") === "1";
    const m = await loadMembership(orgId, membershipId);
    if (m.userId === ctx.user.id && !active) return { error: "Vous ne pouvez pas désactiver votre propre accès de propriétaire : transférez d'abord la propriété." };
    await db.update(schema.memberships).set({ active }).where(eq(schema.memberships.id, m.id));
    if (!active) await db.delete(schema.sessions).where(eq(schema.sessions.userId, m.userId));
    await audit({ action: active ? "security.member.activate" : "security.member.deactivate", userId: ctx.user.id, orgId, entityType: "membership", entityId: m.id, before: { active: m.active }, after: { active } });
    paths(orgId);
    return { ok: true, message: active ? "Membre réactivé." : "Membre désactivé : plus aucun accès à cet organisme, sessions fermées." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

export async function setMemberExpiryAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const membershipId = uuid.parse(formData.get("membershipId"));
    const raw = String(formData.get("expiresAt") ?? "").trim();
    const m = await loadMembership(orgId, membershipId);
    let expiresAt: Date | null = null;
    if (raw) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return { error: "Date d'expiration invalide." };
      expiresAt = new Date(`${raw}T23:59:59+02:00`);
      if (m.userId === ctx.user.id && expiresAt.getTime() <= Date.now()) return { error: "Vous ne pouvez pas faire expirer votre propre accès de propriétaire." };
    }
    await db.update(schema.memberships).set({ expiresAt }).where(eq(schema.memberships.id, m.id));
    await audit({ action: "security.member.expiry", userId: ctx.user.id, orgId, entityType: "membership", entityId: m.id, before: { expiresAt: m.expiresAt }, after: { expiresAt } });
    paths(orgId);
    return { ok: true, message: expiresAt ? "Date d'expiration enregistrée." : "Expiration retirée." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

/** Rattachement formateur : lie le compte à une fiche formateur de l'organisme (périmètre 0045). */
export async function setMemberTrainerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const membershipId = uuid.parse(formData.get("membershipId"));
    const raw = String(formData.get("trainerId") ?? "").trim();
    const m = await loadMembership(orgId, membershipId);
    let trainerId: string | null = null;
    if (raw) {
      if (!/^[0-9a-f-]{36}$/i.test(raw)) return { error: "Formateur invalide." };
      const [t] = await db.select({ id: schema.trainers.id, userId: schema.trainers.userId }).from(schema.trainers).where(and(eq(schema.trainers.id, raw), eq(schema.trainers.orgId, orgId))).limit(1);
      if (!t) return { error: "Fiche formateur introuvable dans cet organisme." };
      if (t.userId && t.userId !== m.userId) return { error: "Cette fiche formateur est déjà rattachée à un autre compte." };
      trainerId = t.id;
    }
    await db.transaction(async (tx) => {
      if (m.trainerId && m.trainerId !== trainerId) await tx.update(schema.trainers).set({ userId: null }).where(and(eq(schema.trainers.id, m.trainerId), eq(schema.trainers.orgId, orgId), eq(schema.trainers.userId, m.userId)));
      await tx.update(schema.memberships).set({ trainerId }).where(eq(schema.memberships.id, m.id));
      if (trainerId) await tx.update(schema.trainers).set({ userId: m.userId }).where(and(eq(schema.trainers.id, trainerId), eq(schema.trainers.orgId, orgId)));
    });
    await audit({ action: "security.member.trainer", userId: ctx.user.id, orgId, entityType: "membership", entityId: m.id, before: { trainerId: m.trainerId }, after: { trainerId } });
    paths(orgId);
    return { ok: true, message: trainerId ? "Rattachement formateur enregistré." : "Rattachement formateur retiré." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

async function sendInvitationMail(orgName: string, email: string, token: string, isDemo: boolean) {
  const url = `${appUrl()}/invitation/${token}`;
  const res = await sendMail({
    to: email,
    subject: `Invitation à rejoindre ${orgName} sur Next Formation`,
    html: layoutMail("Vous êtes invité(e)", `<p>Un propriétaire de ${orgName} vous invite à rejoindre son espace Next Formation. Ce lien est valable 7 jours.</p>`, { label: "Accepter l'invitation", url }),
    text: `Acceptez l'invitation (valable 7 jours) : ${url}`,
    isDemo,
  });
  return { url, status: res.status };
}

/** Invitation : e-mail + rôles additifs (+ rattachement formateur facultatif). Sans service e-mail, le lien est affiché à transmettre. */
export async function inviteMemberAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const email = z.string().trim().toLowerCase().email("Adresse e-mail invalide.").parse(formData.get("email"));
    const roles = normalizeRoles(formData.getAll("roles"));
    if (!roles.length) return { error: "Choisissez au moins un rôle." };
    const trainerRaw = String(formData.get("trainerId") ?? "").trim();
    let trainerId: string | null = null;
    if (trainerRaw) {
      const [t] = await db.select({ id: schema.trainers.id }).from(schema.trainers).where(and(eq(schema.trainers.id, trainerRaw), eq(schema.trainers.orgId, orgId))).limit(1);
      if (!t) return { error: "Fiche formateur introuvable." };
      trainerId = t.id;
    }
    const [existingUser] = await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, email)).limit(1);
    if (existingUser) {
      const [m] = await db.select({ id: schema.memberships.id }).from(schema.memberships).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, existingUser.id))).limit(1);
      if (m) return { error: "Cette personne est déjà membre de l'organisme : modifiez ses rôles dans la liste." };
    }
    const [pending] = await db.select({ id: schema.invitations.id }).from(schema.invitations).where(and(eq(schema.invitations.orgId, orgId), eq(schema.invitations.email, email), eq(schema.invitations.status, "pending"))).limit(1);
    if (pending) return { error: "Une invitation est déjà en attente pour cette adresse : renvoyez-la ou révoquez-la." };
    const invitationId = randomUUID();
    const token = await issueToken("invite", { email, payload: { invitationId }, ttlMinutes: 7 * 24 * 60 });
    await db.insert(schema.invitations).values({ id: invitationId, tenantId: ctx.tenant.id, orgId, email, roles, trainerId, invitedBy: ctx.user.id, tokenHash: sha256(token), expiresAt: new Date(Date.now() + 7 * 86400_000) });
    const r = await sendInvitationMail(ctx.org.tradeName ?? ctx.org.legalName, email, token, ctx.org.isDemo);
    await audit({ action: "security.invitation.create", userId: ctx.user.id, orgId, entityType: "invitation", entityId: invitationId, after: { email, roles, trainerId, mail: r.status } });
    paths(orgId);
    return r.status === "sent" ? { ok: true, message: `Invitation envoyée à ${email}.` } : { ok: true, message: ctx.org.isDemo ? "Démonstration : aucun e-mail ne part. Transmettez ce lien (valable 7 jours) :" : "Service e-mail non configuré : transmettez ce lien (valable 7 jours) :", data: { link: r.url } };
  } catch (e) {
    return fail(e, "Invitation impossible.");
  }
}

export async function resendInvitationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const id = uuid.parse(formData.get("invitationId"));
    const [inv] = await db.select().from(schema.invitations).where(and(eq(schema.invitations.id, id), eq(schema.invitations.orgId, orgId))).limit(1);
    if (!inv || inv.status !== "pending") return { error: "Invitation introuvable ou déjà traitée." };
    const token = await issueToken("invite", { email: inv.email, payload: { invitationId: inv.id }, ttlMinutes: 7 * 24 * 60 });
    await db.update(schema.invitations).set({ tokenHash: sha256(token), expiresAt: new Date(Date.now() + 7 * 86400_000) }).where(eq(schema.invitations.id, inv.id));
    const r = await sendInvitationMail(ctx.org.tradeName ?? ctx.org.legalName, inv.email, token, ctx.org.isDemo);
    await audit({ action: "security.invitation.resend", userId: ctx.user.id, orgId, entityType: "invitation", entityId: inv.id, after: { email: inv.email, mail: r.status } });
    paths(orgId);
    return r.status === "sent" ? { ok: true, message: `Invitation renvoyée à ${inv.email}.` } : { ok: true, message: "E-mail non envoyé (service non configuré ou démonstration) : transmettez ce nouveau lien :", data: { link: r.url } };
  } catch (e) {
    return fail(e, "Renvoi impossible.");
  }
}

export async function revokeInvitationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const id = uuid.parse(formData.get("invitationId"));
    const [inv] = await db.select().from(schema.invitations).where(and(eq(schema.invitations.id, id), eq(schema.invitations.orgId, orgId))).limit(1);
    if (!inv || inv.status !== "pending") return { error: "Invitation introuvable ou déjà traitée." };
    await db.update(schema.invitations).set({ status: "revoked" }).where(eq(schema.invitations.id, inv.id));
    await db.update(schema.oneTimeTokens).set({ usedAt: new Date() }).where(eq(schema.oneTimeTokens.tokenHash, inv.tokenHash));
    await audit({ action: "security.invitation.revoke", userId: ctx.user.id, orgId, entityType: "invitation", entityId: inv.id, before: { email: inv.email, roles: inv.roles } });
    paths(orgId);
    return { ok: true, message: "Invitation révoquée : le lien ne fonctionne plus." };
  } catch (e) {
    return fail(e, "Révocation impossible.");
  }
}

/** Transfert de propriété : membre actif cible, confirmation par le mot de passe du propriétaire, audité. */
export async function transferOwnershipAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSecurityAdmin(orgId);
    const targetUserId = uuid.parse(formData.get("targetUserId"));
    const password = String(formData.get("password") ?? "");
    if (!password) return { error: "Confirmez avec votre mot de passe." };
    const [me] = await db.select({ hash: schema.users.passwordHash }).from(schema.users).where(eq(schema.users.id, ctx.user.id)).limit(1);
    if (!me || !(await verifyPassword(password, me.hash))) {
      await audit({ action: "security.owner.transfer_denied", userId: ctx.user.id, orgId, entityType: "organisme", entityId: orgId, after: { targetUserId, reason: "mot de passe incorrect" } });
      return { error: "Mot de passe incorrect." };
    }
    const [target] = await db.select().from(schema.memberships).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, targetUserId))).limit(1);
    if (!target) return { error: "La personne choisie n'est pas membre de cet organisme." };
    const check = canReceiveOwnership({ userId: target.userId, active: target.active, expiresAt: target.expiresAt, roles: target.roles }, ctx.org.ownerUserId);
    if (!check.ok) return { error: check.reason };
    const [targetUser] = await db.select({ id: schema.users.id, disabledAt: schema.users.disabledAt, firstName: schema.users.firstName, lastName: schema.users.lastName }).from(schema.users).where(eq(schema.users.id, targetUserId)).limit(1);
    if (!targetUser || targetUser.disabledAt) return { error: "Le compte cible est désactivé." };
    await db.update(schema.organismes).set({ ownerUserId: targetUserId }).where(and(eq(schema.organismes.id, orgId), eq(schema.organismes.ownerUserId, ctx.user.id)));
    await audit({ action: "security.owner.transfer", userId: ctx.user.id, orgId, tenantId: ctx.tenant.id, entityType: "organisme", entityId: orgId, before: { ownerUserId: ctx.user.id }, after: { ownerUserId: targetUserId } });
    await notify({ orgId, userId: targetUserId, title: `Vous êtes désormais propriétaire de ${ctx.org.tradeName ?? ctx.org.legalName}`, href: `/app/${orgId}/securite`, kind: "security", dedupeKey: `owner:${orgId}:${targetUserId}` });
    paths(orgId);
    return { ok: true, message: `Propriété transférée à ${targetUser.firstName} ${targetUser.lastName}. Vous n'avez plus accès à l'administration de la sécurité.` };
  } catch (e) {
    return fail(e, "Transfert impossible.");
  }
}
