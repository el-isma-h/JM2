/** Libellés français (purs) du module qualité : niveaux, périmètres, enquêtes, veille, réclamations. */

export const levelLabels: Record<"individuel" | "collectif" | "organisationnel", string> = {
  individuel: "Individuel (par apprenant)",
  collectif: "Collectif (session / programme)",
  organisationnel: "Organisationnel",
};

export const levelShort: Record<"individuel" | "collectif" | "organisationnel", string> = {
  individuel: "Individuel",
  collectif: "Collectif",
  organisationnel: "Organisationnel",
};

export const scopeLabels: Record<"organisme" | "session" | "inscription" | "programme", string> = {
  organisme: "Organisme",
  session: "Session",
  inscription: "Inscription",
  programme: "Programme",
};

export const surveyKindLabels: Record<string, string> = {
  positionnement: "Positionnement (entrée)",
  satisfaction_chaud: "Satisfaction à chaud",
  satisfaction_froid: "Satisfaction à froid",
  employeur: "Employeur / tuteur",
  formateur: "Formateur",
  financeur: "Financeur",
  competences: "Acquis et compétences",
  besoins: "Recueil des besoins",
};

export const surveyStatusLabels: Record<string, string> = {
  brouillon: "Brouillon",
  active: "Active",
  cloturee: "Clôturée",
};

export const watchKindLabels: Record<string, string> = {
  reglementaire: "Réglementaire",
  pedagogique: "Pédagogique et technologique",
  handicap: "Handicap",
  metiers: "Métiers et compétences",
};

/** Indicateur Qualiopi alimenté par chaque type de veille (IND_23 à IND_26). */
export const watchKindIndicator: Record<string, string> = {
  reglementaire: "IND_23",
  metiers: "IND_24",
  pedagogique: "IND_25",
  handicap: "IND_26",
};

export const complaintSourceLabels: Record<string, string> = {
  apprenant: "Apprenant",
  entreprise: "Entreprise / tuteur",
  financeur: "Financeur",
  formateur: "Formateur",
  partenaire: "Partenaire",
  interne: "Interne (aléa)",
  autre: "Autre",
};

export const actionOriginLabels: Record<string, string> = {
  audit: "Audit",
  reclamation: "Réclamation",
  enquete: "Enquête",
  veille: "Veille",
  analyse: "Analyse de conformité",
  revue: "Revue de direction",
  autre: "Autre",
};

export const evidenceSourceLabels: Record<string, string> = {
  document: "Document",
  period: "Période (séance)",
  survey_response: "Réponse d'enquête",
  watch_item: "Veille",
  complaint: "Réclamation",
  quality_action: "Action qualité",
  manual: "Saisie manuelle",
};
