/**
 * Phase administrative et financière : pièces attendues, demandes de signature, financements,
 * factures (numérotation continue), règlements, dépenses.
 */
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { addD, daysAgo } from "./util";
import { createPieceDocument } from "./phase-docs";
import { COMPANIES } from "./people";
import { bump, type State, type Tx } from "./state";

type PieceStatus = (typeof schema.pieceStatusEnum.enumValues)[number];

/** Pièces attendues : une ligne par pièce applicable (contrat × financement), statuts selon l'avancement du dossier. */
export async function phasePieces(s: State) {
  const rows = await db.select().from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, s.orgId), eq(schema.requiredPieces.isActive, true)));
  s.requiredPieces = rows.map((r) => ({ id: r.id, code: r.code, category: r.category, appliesTo: r.appliesTo as { contractKinds: string[]; fundingKinds: string[] }, isRequired: r.isRequired, dueDaysBeforeStart: r.dueDaysBeforeStart }));
  const applies = (p: State["requiredPieces"][number], e: State["enrollments"][number]) => {
    const ck = p.appliesTo.contractKinds ?? ["*"];
    const fk = p.appliesTo.fundingKinds ?? ["*"];
    return (ck.includes("*") || ck.includes(e.contractKind)) && (fk.includes("*") || fk.includes(e.fundingKind));
  };
  const values: (typeof schema.pieceSubmissions.$inferInsert)[] = [];
  let withDoc = 0;
  for (const e of s.enrollments) {
    const sess = s.sessions[e.sessionKey];
    const detailed = (e.sessionKey === "bts" && e.groupIdx === 0) || e.sessionKey === "arh";
    for (const p of s.requiredPieces) {
      if (!applies(p, e)) continue;
      let status: PieceStatus;
      if (e.isInes && p.code === "cerfa_apprentissage") status = "attendue";
      else if (e.status === "annule") status = "non_applicable";
      else if (e.status === "termine" || e.status === "en_cours" || e.status === "abandon") status = s.rng.chance(0.9) ? "acceptee" : "deposee";
      else if (e.status === "inscrit") status = s.rng.pick(["acceptee", "deposee", "attendue", "refusee"]);
      else status = "attendue";
      if (!p.isRequired && status === "attendue" && s.rng.chance(0.5)) status = "non_applicable";
      const due = p.dueDaysBeforeStart === null ? null : addD(sess.startDate, -p.dueDaysBeforeStart);
      const submitted = status === "deposee" || status === "acceptee" || status === "refusee";
      const submittedAt = submitted ? new Date(`${addD(sess.startDate, -s.rng.int(1, 25))}T10:00:00Z`) : null;
      const documentId = submitted && detailed ? await createPieceDocument(s, e, p) : null;
      if (documentId) withDoc++;
      values.push({
        orgId: s.orgId,
        enrollmentId: e.id,
        requiredPieceId: p.id,
        documentId,
        status,
        dueDate: due,
        submittedAt,
        submittedBy: submitted ? s.users.admin : null,
        reviewedBy: status === "acceptee" || status === "refusee" ? s.users.admin : null,
        reviewedAt: status === "acceptee" || status === "refusee" ? new Date((submittedAt ?? s.now).getTime() + 2 * 86400_000) : null,
        refusalReason: status === "refusee" ? "Document illisible ou incomplet : merci de le déposer à nouveau." : null,
        naReason: status === "non_applicable" ? (e.status === "annule" ? "Inscription annulée." : "Pièce facultative non demandée pour ce dossier.") : null,
      });
    }
  }
  await db.transaction(async (tx) => {
    for (let i = 0; i < values.length; i += 500) await tx.insert(schema.pieceSubmissions).values(values.slice(i, i + 500));
  });
  bump(s, "piece_submissions", values.length);
  return withDoc;
}

export async function phaseSignatures(tx: Tx, s: State) {
  const signedDoc = s.documents["convention:intra:clinique"];
  const pendingDoc = s.documents["convention:mgt:distrimarche"] ?? s.documents["convention:mgt:nolwen"];
  const values: (typeof schema.signatureRequests.$inferInsert)[] = [];
  const clinique = s.contacts.clinique.find((c) => c.isSignatory)!;
  if (signedDoc) values.push({ orgId: s.orgId, documentId: signedDoc, provider: "interne", status: "signee", signers: [{ name: clinique.name, email: clinique.email, role: "employer", signedAt: new Date(`${daysAgo(s.today, 14)}T15:20:00Z`).toISOString(), ip: "82.64.11.9" }, { name: "Élise Marchetti", email: "elise.marchetti@atelier-meridien.exemple.fr", role: "other", signedAt: new Date(`${daysAgo(s.today, 14)}T16:02:00Z`).toISOString(), ip: "10.12.4.3" }], signedDocumentId: signedDoc, proof: { signedAt: new Date(`${daysAgo(s.today, 14)}T16:02:00Z`).toISOString(), signers: [{ name: clinique.name, signedAt: new Date(`${daysAgo(s.today, 14)}T15:20:00Z`).toISOString() }, { name: "Élise Marchetti", signedAt: new Date(`${daysAgo(s.today, 14)}T16:02:00Z`).toISOString() }], sha256: "demo" }, requestedBy: s.users.admin });
  if (pendingDoc) {
    const dm = s.contacts.distrimarche.find((c) => c.isSignatory)!;
    values.push({ orgId: s.orgId, documentId: pendingDoc, provider: "interne", status: "envoyee", signers: [{ name: dm.name, email: dm.email, role: "employer" }, { name: "Élise Marchetti", email: "elise.marchetti@atelier-meridien.exemple.fr", role: "other" }], expiresAt: new Date(`${addD(s.today, 14)}T23:59:00Z`), requestedBy: s.users.admin });
  }
  if (values.length) await tx.insert(schema.signatureRequests).values(values);
  bump(s, "signature_requests", values.length);
}

/* ---------- Finance ---------- */

type InvoiceStatus = (typeof schema.invoiceStatusEnum.enumValues)[number];
type InvoiceDef = { kind: "facture" | "avoir" | "acompte"; status: InvoiceStatus; issueDate: string; billTo: { kind: string; name: string; addressLine1: string; postalCode: string; city: string; siret: string; email: string }; companyKey?: string; funderKey?: keyof State["funders"]; personId?: string; sessionKey: keyof State["sessions"]; enrollmentIds: string[]; lines: { label: string; unitCents: number; qty?: number; enrollmentId?: string }[]; paidPct?: number; creditOf?: number; notes?: string };

export async function phaseFinance(tx: Tx, s: State) {
  const { orgId, users, rng } = s;
  const year = Number(s.today.slice(0, 4));
  const S = s.sessions;
  const companyName = (k: string) => COMPANIES.find((c) => c.key === k)!;
  const billToCompany = (k: string) => {
    const c = companyName(k);
    return { kind: "entreprise", name: c.name, addressLine1: c.address, postalCode: c.postalCode, city: c.city, siret: "", email: `compta@${c.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.exemple.fr` };
  };
  const billToFunder = (name: string, address: string, postalCode: string, city: string) => ({ kind: "financeur", name, addressLine1: address, postalCode, city, siret: "", email: "" });
  const FT = billToFunder("France Travail Île-de-France", "3 rue Galilée", "93160", "Noisy-le-Grand");
  const REG = billToFunder("Région Île-de-France", "2 rue Simone-Veil", "93400", "Saint-Ouen");
  const ATLAS = billToFunder("OPCO Atlas", "25 quai Panhard-et-Levassor", "75013", "Paris");
  const OPCO2I = billToFunder("OPCO 2i", "55 rue de Châteaudun", "75009", "Paris");
  const CDC = billToFunder("Caisse des Dépôts (Mon compte formation)", "56 rue de Lille", "75007", "Paris");

  /* ---------- Financements ---------- */
  const fundingValues: (typeof schema.fundings.$inferInsert)[] = [];
  const fundingMeta: string[] = [];
  const quarters = (start: string, total: number) => [0, 3, 6, 9].map((m, i) => ({ label: `Échéance ${i + 1}`, dueDate: addD(start, 30 + m * 30), amountCents: Math.round(total / 4) + (i === 3 ? total - 4 * Math.round(total / 4) : 0), invoiceId: null as string | null }));
  for (const e of s.enrollments) {
    const sess = S[e.sessionKey];
    const base = { orgId, enrollmentId: e.id };
    if (e.sessionKey === "bts") {
      const isAtlas = ["fournel", "nolwen"].includes(e.companyKey ?? "") || rng.chance(0.4);
      const status = e.status === "annule" ? "annule" : e.isInes ? "demande" : e.status === "abandon" ? "accorde" : rng.chance(0.82) ? "accorde" : "demande";
      fundingValues.push({ ...base, funderId: isAtlas ? s.funders.atlas : s.funders.opco2i, kind: "opco", label: `Prise en charge ${isAtlas ? "OPCO Atlas" : "OPCO 2i"} (NPEC, année 1)`, amountCents: 790000, status, agreementRef: status === "accorde" ? `PEC-${year}-${rng.int(100000, 999999)}` : null, agreementDate: status === "accorde" ? addD(sess.startDate, -rng.int(5, 30)) : null, agreementSource: status === "accorde" ? "Accord de prise en charge reçu par e-mail (portail OPCO)" : null, validFrom: sess.startDate, validUntil: addD(sess.startDate, 364), rateNote: "NPEC BTS Gestion de la PME : 7 900 € / an (barème France compétences, 2026).", schedule: quarters(sess.startDate, 790000), notes: e.isInes ? "Accord suspendu à la réception du CERFA signé." : null });
      fundingMeta.push(`bts:${e.id}`);
    } else if (e.sessionKey === "arh" || e.sessionKey === "arhA") {
      const done = e.sessionKey === "arhA";
      const fk = e.fundingKind;
      const funderId = fk === "france_travail" ? s.funders.franceTravail : fk === "region" ? s.funders.region : fk === "cpf" ? s.funders.particulier : s.funders.distrimarche;
      const label = fk === "france_travail" ? "Aide individuelle à la formation (AIF)" : fk === "region" ? "Programme régional de formation (PRFE)" : fk === "cpf" ? "Mon compte formation (CPF)" : "Prise en charge employeur (plan de développement des compétences)";
      const status = done ? "solde" : e.status === "abandon" ? "facture" : fk === "cpf" ? "accorde" : rng.chance(0.75) ? "accorde" : "demande";
      fundingValues.push({ ...base, funderId, kind: fk as "opco", label, amountCents: fk === "cpf" ? 720000 : 798000, status, agreementRef: status === "demande" ? null : fk === "france_travail" ? `AIF-${rng.int(1000000, 9999999)}` : fk === "region" ? `PRFE-${year}-${rng.int(1000, 9999)}` : fk === "cpf" ? `EDOF-${rng.int(10000000, 99999999)}` : `BC-${year}-${rng.int(100, 999)}`, agreementDate: status === "demande" ? null : addD(sess.startDate, -rng.int(3, 20)), agreementSource: status === "demande" ? null : fk === "cpf" ? "Dossier EDOF validé" : "Notification écrite du financeur", validFrom: sess.startDate, validUntil: sess.endDate, schedule: fk === "cpf" ? [{ label: "Solde à la fin de formation", dueDate: addD(sess.endDate, 15), amountCents: 720000, invoiceId: null }] : [{ label: "Acompte 40 %", dueDate: addD(sess.startDate, 30), amountCents: 319200, invoiceId: null }, { label: "Solde 60 %", dueDate: addD(sess.endDate, 15), amountCents: 478800, invoiceId: null }] });
      fundingMeta.push(`${e.sessionKey}:${e.id}`);
    } else if (e.status !== "annule") {
      const fk = e.fundingKind;
      const amount = e.sessionKey.startsWith("sst") ? 29000 : e.sessionKey.startsWith("xls") ? 79000 : e.sessionKey === "mgt" ? 145000 : e.sessionKey === "elec" ? 24000 : e.sessionKey === "intra" ? 43333 : 180000;
      const funderId = fk === "cpf" ? s.funders.particulier : e.companyKey === "clinique" ? s.funders.clinique : e.companyKey === "distrimarche" ? s.funders.distrimarche : e.companyKey === "berard" ? s.funders.berard : fk === "opco" ? s.funders.atlas : null;
      const status = e.status === "termine" ? (rng.chance(0.7) ? "solde" : "facture") : e.status === "inscrit" ? (rng.chance(0.6) ? "accorde" : "prevu") : "prevu";
      fundingValues.push({ ...base, funderId, kind: fk as "opco", label: fk === "cpf" ? "Mon compte formation (CPF)" : fk === "opco" ? "Prise en charge OPCO Atlas (actions collectives)" : `Prise en charge employeur : ${e.companyKey ? companyName(e.companyKey).name : ""}`, amountCents: amount, status, agreementRef: status === "prevu" ? null : fk === "cpf" ? `EDOF-${rng.int(10000000, 99999999)}` : `BC-${year}-${rng.int(100, 999)}`, agreementDate: status === "prevu" ? null : addD(sess.startDate, -rng.int(3, 30)), agreementSource: status === "prevu" ? null : fk === "cpf" ? "Dossier EDOF validé" : "Bon de commande de l'entreprise", validFrom: sess.startDate, validUntil: addD(sess.endDate, 60), schedule: [{ label: "Facture à l'issue de la formation", dueDate: addD(sess.endDate, 30), amountCents: amount, invoiceId: null }] });
      fundingMeta.push(`${e.sessionKey}:${e.id}`);
    }
  }
  const fundingRows: { id: string }[] = [];
  for (let i = 0; i < fundingValues.length; i += 500) fundingRows.push(...(await tx.insert(schema.fundings).values(fundingValues.slice(i, i + 500)).returning({ id: schema.fundings.id })));
  fundingMeta.forEach((k, i) => (s.fundingIds[k] = fundingRows[i].id));
  bump(s, "fundings", fundingRows.length);

  /* ---------- Factures ---------- */
  const by = (key: keyof State["sessions"], companyKey?: string) => s.enrollments.filter((e) => e.sessionKey === key && (companyKey === undefined || e.companyKey === companyKey) && e.status !== "annule");
  const arhA = by("arhA");
  const bts = by("bts").filter((e) => e.status !== "annule");
  const defs: InvoiceDef[] = [];
  const perEnrollment = (list: State["enrollments"], label: string, unitCents: number) => list.map((e) => ({ label: `${label} : ${e.personName}`, unitCents, enrollmentId: e.id }));
  // Session ARH A (terminée) : France Travail (3 factures) et Région (2 payées, 1 partielle).
  const ftA = arhA.filter((e) => e.fundingKind === "france_travail");
  const regA = arhA.filter((e) => e.fundingKind === "region");
  defs.push({ kind: "facture", status: "payee", issueDate: addD(S.arhA.startDate, 32), billTo: FT, funderKey: "franceTravail", sessionKey: "arhA", enrollmentIds: ftA.slice(0, 2).map((e) => e.id), lines: perEnrollment(ftA.slice(0, 2), "Acompte 40 % AIF, titre pro ARH", 319200), paidPct: 100 });
  defs.push({ kind: "facture", status: "payee", issueDate: addD(S.arhA.startDate, 33), billTo: FT, funderKey: "franceTravail", sessionKey: "arhA", enrollmentIds: ftA.slice(2, 6).map((e) => e.id), lines: perEnrollment(ftA.slice(2, 6), "Acompte 40 % AIF, titre pro ARH", 319200), paidPct: 100 });
  defs.push({ kind: "facture", status: "payee", issueDate: addD(S.arhA.endDate, 8), billTo: FT, funderKey: "franceTravail", sessionKey: "arhA", enrollmentIds: ftA.map((e) => e.id), lines: perEnrollment(ftA, "Solde 60 % AIF, titre pro ARH", 478800), paidPct: 100 });
  defs.push({ kind: "facture", status: "payee", issueDate: addD(S.arhA.startDate, 35), billTo: REG, funderKey: "region", sessionKey: "arhA", enrollmentIds: regA.map((e) => e.id), lines: perEnrollment(regA, "Acompte 40 % PRFE, titre pro ARH", 319200), paidPct: 100 });
  defs.push({ kind: "facture", status: "payee", issueDate: addD(S.arhA.endDate, 9), billTo: REG, funderKey: "region", sessionKey: "arhA", enrollmentIds: regA.slice(0, 2).map((e) => e.id), lines: perEnrollment(regA.slice(0, 2), "Solde 60 % PRFE, titre pro ARH", 478800), paidPct: 100 });
  defs.push({ kind: "facture", status: "partiellement_payee", issueDate: addD(S.arhA.endDate, 9), billTo: REG, funderKey: "region", sessionKey: "arhA", enrollmentIds: regA.slice(2).map((e) => e.id), lines: perEnrollment(regA.slice(2), "Solde 60 % PRFE, titre pro ARH", 478800), paidPct: 50, notes: "Règlement partiel reçu : attente du complément après contrôle de service fait." });
  // SST terminée : 3 entreprises.
  defs.push({ kind: "facture", status: "payee", issueDate: addD(S.sst1.endDate, 3), billTo: billToCompany("berard"), companyKey: "berard", funderKey: "berard", sessionKey: "sst1", enrollmentIds: by("sst1", "berard").map((e) => e.id), lines: perEnrollment(by("sst1", "berard"), "Formation SST initiale (14 h)", 29000), paidPct: 100 });
  defs.push({ kind: "facture", status: "envoyee", issueDate: addD(S.sst1.endDate, 3), billTo: billToCompany("tilleuls"), companyKey: "tilleuls", sessionKey: "sst1", enrollmentIds: by("sst1", "tilleuls").map((e) => e.id), lines: perEnrollment(by("sst1", "tilleuls"), "Formation SST initiale (14 h)", 29000), notes: "Un avoir partiel a été émis pour un stagiaire non certifié (geste commercial)." });
  defs.push({ kind: "facture", status: "en_retard", issueDate: addD(S.sst1.endDate, 3), billTo: billToCompany("moretti"), companyKey: "moretti", sessionKey: "sst1", enrollmentIds: by("sst1", "moretti").map((e) => e.id), lines: perEnrollment(by("sst1", "moretti"), "Formation SST initiale (14 h)", 29000) });
  // Excel terminée.
  defs.push({ kind: "facture", status: "payee", issueDate: addD(S.xls1.endDate, 2), billTo: billToCompany("fournel"), companyKey: "fournel", sessionKey: "xls1", enrollmentIds: by("xls1", "fournel").map((e) => e.id), lines: perEnrollment(by("xls1", "fournel"), "Excel avancé (14 h)", 79000), paidPct: 100 });
  defs.push({ kind: "facture", status: "emise", issueDate: addD(S.xls1.endDate, 2), billTo: billToCompany("mairie"), companyKey: "mairie", sessionKey: "xls1", enrollmentIds: by("xls1", "mairie").map((e) => e.id), lines: perEnrollment(by("xls1", "mairie"), "Excel avancé (14 h)", 79000), notes: "À déposer sur Chorus Pro." });
  defs.push({ kind: "facture", status: "en_retard", issueDate: addD(S.xls1.endDate, 2), billTo: billToCompany("vauclair"), companyKey: "vauclair", sessionKey: "xls1", enrollmentIds: by("xls1", "vauclair").map((e) => e.id), lines: perEnrollment(by("xls1", "vauclair"), "Excel avancé (14 h)", 79000) });
  const cpfXls = by("xls1").find((e) => e.fundingKind === "cpf")!;
  defs.push({ kind: "facture", status: "envoyee", issueDate: addD(S.xls1.endDate, 4), billTo: CDC, funderKey: "particulier", personId: cpfXls.personId, sessionKey: "xls1", enrollmentIds: [cpfXls.id], lines: [{ label: `Excel avancé (14 h), CPF : ${cpfXls.personName}`, unitCents: 79000, enrollmentId: cpfXls.id }] });
  // BTS : première échéance OPCO (8 factures groupées par OPCO et entreprise).
  const btsGroups = new Map<string, State["enrollments"]>();
  for (const e of bts) {
    if (e.isInes) continue;
    const k = e.companyKey ?? "";
    btsGroups.set(k, [...(btsGroups.get(k) ?? []), e]);
  }
  const btsStatuses: InvoiceStatus[] = ["payee", "envoyee", "payee", "en_retard", "envoyee", "payee", "emise", "envoyee"];
  [...btsGroups.entries()].slice(0, 8).forEach(([ck, list], i) => {
    const atlas = i % 2 === 0;
    defs.push({ kind: "facture", status: btsStatuses[i], issueDate: addD(S.bts.startDate, 28 + i * 2), billTo: atlas ? ATLAS : OPCO2I, funderKey: atlas ? "atlas" : "opco2i", companyKey: ck, sessionKey: "bts", enrollmentIds: list.map((e) => e.id), lines: perEnrollment(list, `BTS GPME, échéance 1/4 (${companyName(ck).name})`, 197500), paidPct: btsStatuses[i] === "payee" ? 100 : undefined });
  });
  // Intra clinique : acompte 30 %.
  defs.push({ kind: "acompte", status: "emise", issueDate: daysAgo(s.today, 10), billTo: billToCompany("clinique"), companyKey: "clinique", funderKey: "clinique", sessionKey: "intra", enrollmentIds: by("intra").map((e) => e.id), lines: [{ label: "Acompte 30 % : formation intra « Accueil en établissement de santé »", unitCents: 78000 }] });
  // ARH en cours : acomptes Région et France Travail.
  const regB = by("arh").filter((e) => e.fundingKind === "region");
  const ftB = by("arh").filter((e) => e.fundingKind === "france_travail");
  defs.push({ kind: "facture", status: "envoyee", issueDate: addD(S.arh.startDate, 31), billTo: REG, funderKey: "region", sessionKey: "arh", enrollmentIds: regB.map((e) => e.id), lines: perEnrollment(regB, "Acompte 40 % PRFE, titre pro ARH session B", 319200) });
  defs.push({ kind: "facture", status: "emise", issueDate: addD(S.arh.startDate, 32), billTo: FT, funderKey: "franceTravail", sessionKey: "arh", enrollmentIds: ftB.map((e) => e.id), lines: perEnrollment(ftB, "Acompte 40 % AIF, titre pro ARH session B", 319200) });
  // Avoir partiel sur la facture Tilleuls (SST).
  const tilleulsIdx = defs.findIndex((d) => d.companyKey === "tilleuls");
  defs.push({ kind: "avoir", status: "emise", issueDate: addD(S.sst1.endDate, 12), billTo: billToCompany("tilleuls"), companyKey: "tilleuls", sessionKey: "sst1", enrollmentIds: [], lines: [{ label: "Avoir partiel : stagiaire non certifié, geste commercial (50 %)", unitCents: -14500 }], creditOf: tilleulsIdx });

  const factures = defs.map((d, i) => ({ d, i })).filter((x) => x.d.kind !== "avoir").sort((a, b) => a.d.issueDate.localeCompare(b.d.issueDate));
  const numbers = new Map<number, string>();
  factures.forEach((x, seq) => numbers.set(x.i, `F-${year}-${String(seq + 1).padStart(5, "0")}`));
  defs.forEach((d, i) => {
    if (d.kind === "avoir") numbers.set(i, `AV-${year}-00001`);
  });
  const values = defs.map((d, i) => {
    const totalHt = d.lines.reduce((a, l) => a + Math.round((l.qty ?? 1) * l.unitCents), 0);
    const paid = d.paidPct ? Math.round((totalHt * d.paidPct) / 100) : 0;
    return {
      orgId,
      number: numbers.get(i)!,
      kind: d.kind,
      status: d.status,
      companyId: d.companyKey ? s.companies[d.companyKey] : null,
      funderId: d.funderKey ? s.funders[d.funderKey] : null,
      personId: d.personId ?? null,
      enrollmentId: d.enrollmentIds.length === 1 ? d.enrollmentIds[0] : null,
      sessionId: S[d.sessionKey].id,
      fundingId: d.enrollmentIds.length === 1 ? s.fundingIds[`${d.sessionKey}:${d.enrollmentIds[0]}`] ?? null : null,
      billTo: d.billTo,
      issueDate: d.issueDate,
      dueDate: addD(d.issueDate, 30),
      servicePeriodStart: S[d.sessionKey].startDate,
      servicePeriodEnd: S[d.sessionKey].endDate,
      totalHtCents: totalHt,
      vatCents: 0,
      totalTtcCents: totalHt,
      paidCents: paid,
      vatExempt: true,
      vatMention: "TVA non applicable, exonération art. 261-4-4° a du CGI (organisme de formation professionnelle continue).",
      paymentTerms: "Paiement à 30 jours date de facture, par virement bancaire.",
      notes: d.notes ?? null,
      sentAt: ["envoyee", "payee", "partiellement_payee", "en_retard"].includes(d.status) ? new Date(`${d.issueDate}T14:00:00Z`) : null,
      paidAt: d.status === "payee" ? new Date(`${addD(d.issueDate, rng.int(8, 28))}T09:00:00Z`) : null,
      issuedBy: users.finance,
      isDemo: true,
    };
  });
  const invoiceRows = await tx.insert(schema.invoices).values(values).returning({ id: schema.invoices.id });
  s.invoiceIds = invoiceRows.map((r, i) => ({ id: r.id, number: values[i].number, status: values[i].status, enrollmentId: values[i].enrollmentId }));
  const lineValues = defs.flatMap((d, i) => d.lines.map((l, pos) => ({ invoiceId: invoiceRows[i].id, position: pos, label: l.label, quantity: (l.qty ?? 1) * 1000, unit: "forfait", unitCents: l.unitCents, vatRateBp: 0, totalHtCents: Math.round((l.qty ?? 1) * l.unitCents), enrollmentId: l.enrollmentId ?? null })));
  await tx.insert(schema.invoiceLines).values(lineValues);
  const avoirIdx = defs.findIndex((d) => d.kind === "avoir");
  if (avoirIdx >= 0 && defs[avoirIdx].creditOf !== undefined) await tx.update(schema.invoices).set({ creditOfInvoiceId: invoiceRows[defs[avoirIdx].creditOf!].id }).where(eq(schema.invoices.id, invoiceRows[avoirIdx].id));
  const paymentValues = values.flatMap((v, i) => (v.paidCents > 0 ? [{ orgId, invoiceId: invoiceRows[i].id, amountCents: v.paidCents, date: addD(v.issueDate, rng.int(8, 28)), method: "virement" as const, reference: `VIR ${v.number}`, recordedBy: users.finance, reconciledAt: rng.chance(0.7) ? new Date(`${addD(v.issueDate, 30)}T08:00:00Z`) : null }] : []));
  await tx.insert(schema.payments).values(paymentValues);
  await tx
    .insert(schema.invoiceSequences)
    .values([
      { orgId, kind: "facture", year, next: factures.length + 1 },
      { orgId, kind: "avoir", year, next: 2 },
    ])
    .onConflictDoNothing();
  // Rattachement des échéances facturées (échéance 1) sur les financements OPCO du BTS.
  for (const [i, d] of defs.entries()) {
    if (d.sessionKey !== "bts" || d.kind !== "facture") continue;
    for (const eid of d.enrollmentIds) {
      const fid = s.fundingIds[`bts:${eid}`];
      if (!fid) continue;
      const [f] = await tx.select({ schedule: schema.fundings.schedule, status: schema.fundings.status }).from(schema.fundings).where(eq(schema.fundings.id, fid)).limit(1);
      const sched = (f?.schedule as { label: string; dueDate: string; amountCents: number; invoiceId: string | null }[]) ?? [];
      if (sched[0]) sched[0].invoiceId = invoiceRows[i].id;
      await tx.update(schema.fundings).set({ schedule: sched, status: f?.status === "accorde" ? "facture" : f?.status }).where(eq(schema.fundings.id, fid));
    }
  }
  bump(s, "invoices", invoiceRows.length);
  bump(s, "invoice_lines", lineValues.length);
  bump(s, "payments", paymentValues.length);
  bump(s, "invoice_sequences", 4);

  /* ---------- Dépenses ---------- */
  const expenses: (typeof schema.expenses.$inferInsert)[] = [
    { orgId, date: addD(S.sst1.endDate, 5), label: "Sous-traitance formation SST (Prévenlys)", category: "sous_traitance", supplier: "Prévenlys SAS", amountHtCents: 100800, vatCents: 20160, sessionId: S.sst1.id, trainerId: s.trainers.antoine },
    { orgId, date: addD(S.xls1.endDate, 4), label: "Honoraires formatrice Excel (14 h)", category: "sous_traitance", supplier: "Claire Vasseur Formation", amountHtCents: 91000, vatCents: 0, sessionId: S.xls1.id, trainerId: s.trainers.claire },
    { orgId, date: `${s.today.slice(0, 7)}-01`, label: "Loyer antenne de Montreuil", category: "locaux", supplier: "SCI Mont-Louis", amountHtCents: 180000, vatCents: 36000 },
    { orgId, date: daysAgo(s.today, 40), label: "Mannequins de secourisme et défibrillateur de formation", category: "materiel", supplier: "Médiprévention", amountHtCents: 215000, vatCents: 43000 },
    { orgId, date: daysAgo(s.today, 25), label: "Licences suite bureautique (12 postes, annuel)", category: "logiciel", supplier: "Éditeur fictif", amountHtCents: 96000, vatCents: 19200 },
    { orgId, date: daysAgo(s.today, 18), label: "Assurance responsabilité civile professionnelle", category: "assurance", supplier: "Assureur fictif", amountHtCents: 142000, vatCents: 0 },
    { orgId, date: daysAgo(s.today, 7), label: "Fournitures pédagogiques (supports imprimés BTS)", category: "fournitures", supplier: "Imprimerie du Marais", amountHtCents: 38500, vatCents: 7700, sessionId: S.bts.id },
    { orgId, date: daysAgo(s.today, 3), label: "Hébergement plateforme Moodle (trimestre)", category: "logiciel", supplier: "Hébergeur fictif", amountHtCents: 27000, vatCents: 5400 },
  ];
  await tx.insert(schema.expenses).values(expenses);
  bump(s, "expenses", expenses.length);
}
