import "server-only";
import { and, asc, desc, eq, ilike, inArray, isNull, or, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { trainerSessionIds, type OrgContext, type Permission } from "@/server/authz";
import { attendanceForEnrollment } from "@/server/extranet/queries";
import { fmtMinutes } from "@/lib/time";
import { redactForAi } from "./redact";

/**
 * Outils en lecture seule de l'assistant. Chaque outil applique le même contrôle d'accès que les pages :
 * permission requise (`ctx.permissions`), périmètre formateur (`trainerSessionIds`), isolation `orgId`.
 * Les résultats passent par `redactForAi` avant d'être transmis au modèle (jamais de NIR, IBAN, notes confidentielles).
 */

export type ToolDef = {
  name: string;
  description: string;
  params: z.ZodType;
  perm?: Permission;
  run: (ctx: OrgContext, args: never) => Promise<unknown>;
};

const uuid = z.string().uuid();

type Scope = { sessionIds: string[] | null };

async function scopeOf(ctx: OrgContext): Promise<Scope> {
  return { sessionIds: await trainerSessionIds(ctx) };
}

function sessionFilter(scope: Scope) {
  if (!scope.sessionIds) return undefined;
  return scope.sessionIds.length ? inArray(schema.enrollments.sessionId, scope.sessionIds) : isNull(schema.enrollments.id);
}

/** Résumé d'inscription réutilisé par les agents (dossier, relances, qualité) et par la page sans IA. */
export async function enrollmentSummary(ctx: OrgContext, enrollmentId: string) {
  const scope = await scopeOf(ctx);
  const [row] = await db
    .select({ e: schema.enrollments, p: schema.persons, s: schema.trainingSessions, companyName: schema.companies.name })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
    .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, ctx.org.id), sessionFilter(scope)))
    .limit(1);
  if (!row) return null;
  const canAdmin = ctx.permissions.has("dossier.admin_docs.view");
  const canFinance = ctx.permissions.has("finance.view");
  const canTasks = ctx.permissions.has("tasks.view_all") || ctx.permissions.has("tasks.manage");
  const { hours } = await attendanceForEnrollment(ctx.org.id, row.e.id, row.e.hoursPlanned, row.e.legacyHours);
  const pieces = canAdmin
    ? await db
        .select({ label: schema.requiredPieces.label, code: schema.requiredPieces.code, status: schema.pieceSubmissions.status, dueDate: schema.pieceSubmissions.dueDate, providedBy: schema.requiredPieces.providedBy, refusalReason: schema.pieceSubmissions.refusalReason })
        .from(schema.pieceSubmissions)
        .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
        .where(and(eq(schema.pieceSubmissions.orgId, ctx.org.id), eq(schema.pieceSubmissions.enrollmentId, row.e.id)))
    : null;
  const fundings = canFinance
    ? await db
        .select({ label: schema.fundings.label, kind: schema.fundings.kind, amountCents: schema.fundings.amountCents, status: schema.fundings.status, agreementRef: schema.fundings.agreementRef, validUntil: schema.fundings.validUntil })
        .from(schema.fundings)
        .where(and(eq(schema.fundings.orgId, ctx.org.id), eq(schema.fundings.enrollmentId, row.e.id)))
    : null;
  const invoices = canFinance
    ? await db
        .select({ number: schema.invoices.number, status: schema.invoices.status, totalTtcCents: schema.invoices.totalTtcCents, paidCents: schema.invoices.paidCents, dueDate: schema.invoices.dueDate })
        .from(schema.invoices)
        .where(and(eq(schema.invoices.orgId, ctx.org.id), eq(schema.invoices.enrollmentId, row.e.id)))
    : null;
  const tasks = canTasks
    ? await db
        .select({ id: schema.tasks.id, title: schema.tasks.title, status: schema.tasks.status, assigneeRole: schema.tasks.assigneeRole, assigneeUserId: schema.tasks.assigneeUserId, dueDate: schema.tasks.dueDate, blockedReason: schema.tasks.blockedReason, priority: schema.tasks.priority })
        .from(schema.tasks)
        .where(and(eq(schema.tasks.orgId, ctx.org.id), eq(schema.tasks.entityType, "enrollment"), eq(schema.tasks.entityId, row.e.id), inArray(schema.tasks.status, ["a_faire", "en_cours", "bloquee"])))
        .orderBy(asc(schema.tasks.dueDate))
    : null;
  const documents = ctx.permissions.has("documents.view")
    ? await db
        .select({ title: schema.documents.title, category: schema.documents.category, status: schema.documents.status, visibility: schema.documents.visibility, createdAt: schema.documents.createdAt })
        .from(schema.documents)
        .where(and(eq(schema.documents.orgId, ctx.org.id), eq(schema.documents.enrollmentId, row.e.id)))
        .orderBy(desc(schema.documents.createdAt))
        .limit(20)
    : null;
  const [nextSlot] = await db
    .select({ date: schema.slots.date, title: schema.slots.title })
    .from(schema.slots)
    .where(and(eq(schema.slots.orgId, ctx.org.id), eq(schema.slots.sessionId, row.e.sessionId), sql`${schema.slots.date} >= current_date`, sql`${schema.slots.status} <> 'annulee'`))
    .orderBy(asc(schema.slots.date))
    .limit(1);
  return redactForAi({
    enrollment: {
      id: row.e.id,
      reference: row.e.reference,
      status: row.e.status,
      commercialStatus: row.e.commercialStatus,
      progression: row.e.progression,
      fundingState: row.e.fundingState,
      examState: row.e.examState,
      contractKind: row.e.contractKind,
      startDate: row.e.startDate ?? row.s.startDate,
      endDate: row.e.endDate ?? row.s.endDate,
      hoursPlanned: row.e.hoursPlanned,
      company: row.companyName,
    },
    person: { firstName: row.p.firstName, lastName: row.p.lastName, email: canAdmin ? row.p.email : undefined, status: row.p.status, hasAccommodations: row.p.hasAccommodations },
    session: { id: row.s.id, code: row.s.code, title: row.s.title, status: row.s.status, startDate: row.s.startDate, endDate: row.s.endDate, modality: row.s.modality },
    hours: { prevues: fmtMinutes(hours.planned), programmees: fmtMinutes(hours.scheduled), effectuees: fmtMinutes(hours.done), justifiees: fmtMinutes(hours.justified), validees: fmtMinutes(hours.validated), legacy: fmtMinutes(hours.legacy) },
    pieces: pieces ?? "non accessible avec vos habilitations",
    fundings: fundings ?? "non accessible avec vos habilitations",
    invoices: invoices ?? "non accessible avec vos habilitations",
    openTasks: tasks ?? "non accessible avec vos habilitations",
    documents: documents ?? "non accessible avec vos habilitations",
    nextSlot: nextSlot ?? null,
  });
}

export async function sessionSummary(ctx: OrgContext, sessionId: string) {
  const scope = await scopeOf(ctx);
  if (scope.sessionIds && !scope.sessionIds.includes(sessionId)) return null;
  const [s] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, sessionId), eq(schema.trainingSessions.orgId, ctx.org.id))).limit(1);
  if (!s) return null;
  const [{ enrolled }] = await db.select({ enrolled: sql<number>`count(*)::int` }).from(schema.enrollments).where(and(eq(schema.enrollments.sessionId, s.id), inArray(schema.enrollments.status, ["inscrit", "en_cours"])));
  const periods = await db
    .select({ status: schema.periods.status, n: sql<number>`count(*)::int` })
    .from(schema.periods)
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .where(and(eq(schema.slots.sessionId, s.id), eq(schema.periods.orgId, ctx.org.id)))
    .groupBy(schema.periods.status);
  const trainers = await db
    .select({ firstName: schema.trainers.firstName, lastName: schema.trainers.lastName, role: schema.sessionTrainers.role })
    .from(schema.sessionTrainers)
    .innerJoin(schema.trainers, eq(schema.trainers.id, schema.sessionTrainers.trainerId))
    .where(eq(schema.sessionTrainers.sessionId, s.id));
  const tasks = ctx.permissions.has("tasks.view_all")
    ? await db
        .select({ title: schema.tasks.title, status: schema.tasks.status, dueDate: schema.tasks.dueDate, assigneeRole: schema.tasks.assigneeRole })
        .from(schema.tasks)
        .where(and(eq(schema.tasks.orgId, ctx.org.id), eq(schema.tasks.entityType, "session"), eq(schema.tasks.entityId, s.id), inArray(schema.tasks.status, ["a_faire", "en_cours", "bloquee"])))
    : "non accessible avec vos habilitations";
  return redactForAi({
    session: { id: s.id, code: s.code, title: s.title, status: s.status, kind: s.kind, startDate: s.startDate, endDate: s.endDate, modality: s.modality, capacity: s.capacity, isApprenticeship: s.isApprenticeship, rhythm: s.rhythm },
    enrolled,
    periodsByStatus: Object.fromEntries(periods.map((p) => [p.status, p.n])),
    trainers: trainers.map((t) => `${t.firstName} ${t.lastName} (${t.role})`),
    openTasks: tasks,
  });
}

export async function companySummary(ctx: OrgContext, companyId: string) {
  const [c] = await db.select().from(schema.companies).where(and(eq(schema.companies.id, companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1);
  if (!c) return null;
  const contacts = await db
    .select({ firstName: schema.contacts.firstName, lastName: schema.contacts.lastName, jobTitle: schema.contacts.jobTitle, isTutor: schema.contacts.isTutor, isSignatory: schema.contacts.isSignatory, email: schema.contacts.email })
    .from(schema.contacts)
    .where(and(eq(schema.contacts.orgId, ctx.org.id), eq(schema.contacts.companyId, c.id)));
  const enrollments = await db
    .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, status: schema.enrollments.status, person: sql<string>`${schema.persons.firstName} || ' ' || ${schema.persons.lastName}`, session: schema.trainingSessions.title })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .where(and(eq(schema.enrollments.orgId, ctx.org.id), eq(schema.enrollments.companyId, c.id)))
    .limit(30);
  const invoices = ctx.permissions.has("finance.view")
    ? await db
        .select({ number: schema.invoices.number, status: schema.invoices.status, totalTtcCents: schema.invoices.totalTtcCents, paidCents: schema.invoices.paidCents, dueDate: schema.invoices.dueDate })
        .from(schema.invoices)
        .where(and(eq(schema.invoices.orgId, ctx.org.id), eq(schema.invoices.companyId, c.id), inArray(schema.invoices.status, ["emise", "envoyee", "partiellement_payee", "en_retard"])))
    : "non accessible avec vos habilitations";
  return redactForAi({ company: { id: c.id, name: c.name, status: c.status, sector: c.sector, opco: c.opco, city: c.city, email: c.email, headcount: c.headcount }, contacts, enrollments, openInvoices: invoices });
}

export async function qualitySummary(ctx: OrgContext, scope: "organisme" | "session" | "inscription" | "programme", scopeId?: string | null) {
  const conds = [eq(schema.qualityAnalyses.orgId, ctx.org.id), eq(schema.qualityAnalyses.scope, scope)];
  if (scopeId) conds.push(eq(schema.qualityAnalyses.scopeId, scopeId));
  const [analysis] = await db.select().from(schema.qualityAnalyses).where(and(...conds)).orderBy(desc(schema.qualityAnalyses.createdAt)).limit(1);
  const evConds = [eq(schema.qualityEvidences.orgId, ctx.org.id), eq(schema.qualityEvidences.status, "valide")];
  if (scope === "session" && scopeId) evConds.push(eq(schema.qualityEvidences.sessionId, scopeId));
  if (scope === "inscription" && scopeId) evConds.push(eq(schema.qualityEvidences.enrollmentId, scopeId));
  if (scope === "programme" && scopeId) evConds.push(eq(schema.qualityEvidences.programId, scopeId));
  const evidences = await db
    .select({ indicatorCode: schema.qualityEvidences.indicatorCode, n: sql<number>`count(*)::int` })
    .from(schema.qualityEvidences)
    .where(and(...evConds))
    .groupBy(schema.qualityEvidences.indicatorCode)
    .orderBy(asc(schema.qualityEvidences.indicatorCode));
  return redactForAi({
    analysis: analysis ? { id: analysis.id, referenceDate: analysis.referenceDate, engineVersion: analysis.engineVersion, summary: analysis.summary, controls: analysis.controls } : "aucune analyse : aucune photographie disponible (ne pas conclure sur la conformité)",
    evidencesByIndicator: Object.fromEntries(evidences.map((e) => [e.indicatorCode, e.n])),
  });
}

export const TOOLS: ToolDef[] = [
  {
    name: "find_enrollment",
    description: "Recherche une inscription par référence ou par nom / prénom de l'apprenant. Retourne jusqu'à 5 résultats (id, référence, nom, session, statut).",
    params: z.object({ query: z.string().min(2) }),
    perm: "enrollments.view",
    run: async (ctx, args: { query: string }) => {
      const scope = await scopeOf(ctx);
      const q = `%${args.query.trim()}%`;
      const rows = await db
        .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, status: schema.enrollments.status, firstName: schema.persons.firstName, lastName: schema.persons.lastName, session: schema.trainingSessions.title })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
        .where(and(eq(schema.enrollments.orgId, ctx.org.id), sessionFilter(scope), or(ilike(schema.enrollments.reference, q), ilike(schema.persons.lastName, q), ilike(schema.persons.firstName, q), sql`(${schema.persons.firstName} || ' ' || ${schema.persons.lastName}) ilike ${q}`)))
        .limit(5);
      return rows;
    },
  },
  {
    name: "get_enrollment",
    description: "Résumé complet d'une inscription (statuts distincts, heures, pièces, financements, factures, tâches ouvertes, prochaine séance) selon vos habilitations.",
    params: z.object({ enrollmentId: uuid }),
    perm: "enrollments.view",
    run: async (ctx, args: { enrollmentId: string }) => (await enrollmentSummary(ctx, args.enrollmentId)) ?? { error: "Inscription introuvable ou hors de votre périmètre." },
  },
  {
    name: "find_session",
    description: "Recherche une session par code ou titre. Jusqu'à 5 résultats.",
    params: z.object({ query: z.string().min(2) }),
    perm: "sessions.view",
    run: async (ctx, args: { query: string }) => {
      const scope = await scopeOf(ctx);
      const q = `%${args.query.trim()}%`;
      const conds = [eq(schema.trainingSessions.orgId, ctx.org.id), or(ilike(schema.trainingSessions.code, q), ilike(schema.trainingSessions.title, q))];
      if (scope.sessionIds) conds.push(scope.sessionIds.length ? inArray(schema.trainingSessions.id, scope.sessionIds) : isNull(schema.trainingSessions.id));
      return db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title, status: schema.trainingSessions.status, startDate: schema.trainingSessions.startDate, endDate: schema.trainingSessions.endDate }).from(schema.trainingSessions).where(and(...conds)).limit(5);
    },
  },
  {
    name: "get_session",
    description: "Résumé d'une session : dates, effectif inscrit, périodes par état, formateurs, tâches ouvertes.",
    params: z.object({ sessionId: uuid }),
    perm: "sessions.view",
    run: async (ctx, args: { sessionId: string }) => (await sessionSummary(ctx, args.sessionId)) ?? { error: "Session introuvable ou hors de votre périmètre." },
  },
  {
    name: "find_company",
    description: "Recherche une entreprise par nom ou SIRET. Jusqu'à 5 résultats.",
    params: z.object({ query: z.string().min(2) }),
    perm: "crm.view",
    run: async (ctx, args: { query: string }) => {
      const q = `%${args.query.trim()}%`;
      return db.select({ id: schema.companies.id, name: schema.companies.name, status: schema.companies.status, city: schema.companies.city }).from(schema.companies).where(and(eq(schema.companies.orgId, ctx.org.id), or(ilike(schema.companies.name, q), ilike(schema.companies.siret, q)))).limit(5);
    },
  },
  {
    name: "get_company",
    description: "Résumé d'une entreprise : contacts, inscriptions rattachées, factures ouvertes (si finance.view).",
    params: z.object({ companyId: uuid }),
    perm: "crm.view",
    run: async (ctx, args: { companyId: string }) => (await companySummary(ctx, args.companyId)) ?? { error: "Entreprise introuvable." },
  },
  {
    name: "list_open_tasks",
    description: "Tâches ouvertes de l'organisme (toutes si tasks.view_all, sinon celles qui me sont affectées), filtrables par entité.",
    params: z.object({ entityType: z.string().optional(), entityId: uuid.optional(), limit: z.number().int().min(1).max(50).optional() }),
    run: async (ctx, args: { entityType?: string; entityId?: string; limit?: number }) => {
      const conds = [eq(schema.tasks.orgId, ctx.org.id), inArray(schema.tasks.status, ["a_faire", "en_cours", "bloquee"])];
      if (!ctx.permissions.has("tasks.view_all")) conds.push(or(eq(schema.tasks.assigneeUserId, ctx.user.id), ctx.roles.length ? inArray(schema.tasks.assigneeRole, ctx.roles) : isNull(schema.tasks.id))!);
      if (args.entityType) conds.push(eq(schema.tasks.entityType, args.entityType));
      if (args.entityId) conds.push(eq(schema.tasks.entityId, args.entityId));
      return db
        .select({ id: schema.tasks.id, title: schema.tasks.title, status: schema.tasks.status, family: schema.tasks.family, dueDate: schema.tasks.dueDate, priority: schema.tasks.priority, assigneeRole: schema.tasks.assigneeRole, entityType: schema.tasks.entityType, entityId: schema.tasks.entityId, entityLabel: schema.tasks.entityLabel, blockedReason: schema.tasks.blockedReason })
        .from(schema.tasks)
        .where(and(...conds))
        .orderBy(asc(schema.tasks.dueDate))
        .limit(args.limit ?? 20);
    },
  },
  {
    name: "missing_pieces",
    description: "Pièces attendues non reçues (statut attendue ou refusée) d'une inscription, avec échéance et déposant.",
    params: z.object({ enrollmentId: uuid }),
    perm: "dossier.admin_docs.view",
    run: async (ctx, args: { enrollmentId: string }) => {
      const scope = await scopeOf(ctx);
      const [e] = await db.select({ id: schema.enrollments.id }).from(schema.enrollments).where(and(eq(schema.enrollments.id, args.enrollmentId), eq(schema.enrollments.orgId, ctx.org.id), sessionFilter(scope))).limit(1);
      if (!e) return { error: "Inscription introuvable ou hors périmètre." };
      return db
        .select({ label: schema.requiredPieces.label, code: schema.requiredPieces.code, providedBy: schema.requiredPieces.providedBy, status: schema.pieceSubmissions.status, dueDate: schema.pieceSubmissions.dueDate, refusalReason: schema.pieceSubmissions.refusalReason })
        .from(schema.pieceSubmissions)
        .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
        .where(and(eq(schema.pieceSubmissions.orgId, ctx.org.id), eq(schema.pieceSubmissions.enrollmentId, e.id), inArray(schema.pieceSubmissions.status, ["attendue", "refusee"])));
    },
  },
  {
    name: "finance_summary",
    description: "Résumé financier d'une inscription ou d'une entreprise : financements (statut, référence d'accord), factures et reste dû.",
    params: z.object({ enrollmentId: uuid.optional(), companyId: uuid.optional() }),
    perm: "finance.view",
    run: async (ctx, args: { enrollmentId?: string; companyId?: string }) => {
      if (args.enrollmentId) {
        const s = (await enrollmentSummary(ctx, args.enrollmentId)) as Record<string, unknown> | null;
        return s ? { fundings: s.fundings, invoices: s.invoices, fundingState: (s.enrollment as Record<string, unknown>).fundingState } : { error: "Inscription introuvable." };
      }
      if (args.companyId) {
        const s = (await companySummary(ctx, args.companyId)) as Record<string, unknown> | null;
        return s ? { openInvoices: s.openInvoices } : { error: "Entreprise introuvable." };
      }
      return { error: "Précisez enrollmentId ou companyId." };
    },
  },
  {
    name: "quality_summary",
    description: "Dernière analyse qualité (photographie immuable) et nombre de preuves valides par indicateur, pour l'organisme, une session, une inscription ou un programme. Un pourcentage n'est pas une attestation.",
    params: z.object({ scope: z.enum(["organisme", "session", "inscription", "programme"]), scopeId: uuid.optional() }),
    perm: "quality.view",
    run: async (ctx, args: { scope: "organisme" | "session" | "inscription" | "programme"; scopeId?: string }) => qualitySummary(ctx, args.scope, args.scopeId),
  },
];

/** Outils disponibles pour ce contexte (permission requise présente). */
export function availableTools(ctx: OrgContext): ToolDef[] {
  return TOOLS.filter((t) => !t.perm || ctx.permissions.has(t.perm));
}

/** Exécute un outil par nom après validation des arguments et de la permission. */
export async function runTool(ctx: OrgContext, name: string, rawArgs: unknown): Promise<unknown> {
  const tool = availableTools(ctx).find((t) => t.name === name);
  if (!tool) return { error: `Outil « ${name} » indisponible avec vos habilitations.` };
  const parsed = tool.params.safeParse(rawArgs ?? {});
  if (!parsed.success) return { error: `Arguments invalides pour ${name} : ${parsed.error.issues[0]?.message ?? "paramètres"}` };
  try {
    return redactForAi(await tool.run(ctx, parsed.data as never));
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Erreur d'exécution de l'outil." };
  }
}
