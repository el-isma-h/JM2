import "server-only";
import { and, asc, desc, eq, gte, inArray, isNull, lte, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { aggregateHours, type AttendanceLike, type HoursAggregate, type PeriodLike } from "@/server/planning/hours";
import { todayParis } from "@/lib/time";

/**
 * Requêtes en lecture des extranets. Chaque fonction reçoit l'orgId et des identifiants déjà filtrés par le
 * contexte (inscriptions de l'apprenant, de l'entreprise, sessions du formateur) : jamais de requête sans ce périmètre.
 */

export type SlotWithPeriods = {
  slot: typeof schema.slots.$inferSelect;
  periods: (typeof schema.periods.$inferSelect)[];
  sessionTitle: string;
  sessionId: string;
  siteName: string | null;
  roomName: string | null;
  trainerName: string | null;
  moduleTitle: string | null;
};

/** Séances (et leurs périodes) des sessions données, triées par date. */
export async function listSlotsForSessions(orgId: string, sessionIds: string[], range?: { from?: string; to?: string }): Promise<SlotWithPeriods[]> {
  if (!sessionIds.length) return [];
  const conds = [eq(schema.slots.orgId, orgId), inArray(schema.slots.sessionId, sessionIds)];
  if (range?.from) conds.push(gte(schema.slots.date, range.from));
  if (range?.to) conds.push(lte(schema.slots.date, range.to));
  const rows = await db
    .select({
      slot: schema.slots,
      sessionTitle: schema.trainingSessions.title,
      siteName: schema.sites.name,
      roomName: schema.rooms.name,
      trainerFirst: schema.trainers.firstName,
      trainerLast: schema.trainers.lastName,
      moduleTitle: schema.modules.title,
    })
    .from(schema.slots)
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.slots.sessionId))
    .leftJoin(schema.sites, eq(schema.sites.id, schema.slots.siteId))
    .leftJoin(schema.rooms, eq(schema.rooms.id, schema.slots.roomId))
    .leftJoin(schema.trainers, eq(schema.trainers.id, schema.slots.trainerId))
    .leftJoin(schema.modules, eq(schema.modules.id, schema.slots.moduleId))
    .where(and(...conds))
    .orderBy(asc(schema.slots.date));
  const slotIds = rows.map((r) => r.slot.id);
  const periods = slotIds.length
    ? await db
        .select()
        .from(schema.periods)
        .where(and(eq(schema.periods.orgId, orgId), inArray(schema.periods.slotId, slotIds)))
        .orderBy(asc(schema.periods.startTime))
    : [];
  const byslot = new Map<string, (typeof periods)[number][]>();
  for (const p of periods) byslot.set(p.slotId, [...(byslot.get(p.slotId) ?? []), p]);
  return rows.map((r) => ({
    slot: r.slot,
    periods: byslot.get(r.slot.id) ?? [],
    sessionTitle: r.sessionTitle,
    sessionId: r.slot.sessionId,
    siteName: r.siteName,
    roomName: r.roomName,
    trainerName: r.trainerFirst ? `${r.trainerFirst} ${r.trainerLast}` : null,
    moduleTitle: r.moduleTitle,
  }));
}

/** Prochaine séance non annulée à partir d'aujourd'hui (heure de Paris). */
export async function nextSlotForSessions(orgId: string, sessionIds: string[]): Promise<SlotWithPeriods | null> {
  const all = await listSlotsForSessions(orgId, sessionIds, { from: todayParis() });
  return all.find((s) => s.slot.status !== "annulee") ?? null;
}

export type AttendanceRow = {
  attendance: typeof schema.attendances.$inferSelect;
  period: typeof schema.periods.$inferSelect;
  slotDate: string;
  slotStatus: (typeof schema.slots.$inferSelect)["status"];
  sessionTitle: string;
};

/** Présences courantes d'une inscription, avec les agrégats d'heures (jamais additionnés entre eux). */
export async function attendanceForEnrollment(orgId: string, enrollmentId: string, hoursPlanned: number, legacyHours = 0): Promise<{ rows: AttendanceRow[]; hours: HoursAggregate }> {
  const [enr] = await db.select({ sessionId: schema.enrollments.sessionId }).from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
  if (!enr) return { rows: [], hours: aggregateHours({ hoursPlanned, periods: [], attendances: [] }) };
  const periodRows = await db
    .select({ period: schema.periods, slotDate: schema.slots.date, slotStatus: schema.slots.status, sessionTitle: schema.trainingSessions.title })
    .from(schema.periods)
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.slots.sessionId))
    .where(and(eq(schema.periods.orgId, orgId), eq(schema.slots.sessionId, enr.sessionId)))
    .orderBy(asc(schema.slots.date), asc(schema.periods.startTime));
  const periodIds = periodRows.map((p) => p.period.id);
  const atts = periodIds.length
    ? await db
        .select()
        .from(schema.attendances)
        .where(and(eq(schema.attendances.orgId, orgId), eq(schema.attendances.enrollmentId, enrollmentId), eq(schema.attendances.isCurrent, true), inArray(schema.attendances.periodId, periodIds)))
    : [];
  const byPeriod = new Map(atts.map((a) => [a.periodId, a]));
  const periods: PeriodLike[] = periodRows.map((p) => ({ id: p.period.id, startTime: p.period.startTime, endTime: p.period.endTime, breakMinutes: p.period.breakMinutes, status: p.period.status, slotStatus: p.slotStatus }));
  const attendances: AttendanceLike[] = atts.map((a) => ({ periodId: a.periodId, status: a.status, arrivedAt: a.arrivedAt, leftAt: a.leftAt, isCurrent: a.isCurrent }));
  const hours = aggregateHours({ hoursPlanned, periods, attendances, legacyMinutes: legacyHours * 60 });
  const rows: AttendanceRow[] = periodRows
    .filter((p) => byPeriod.has(p.period.id))
    .map((p) => ({ attendance: byPeriod.get(p.period.id)!, period: p.period, slotDate: p.slotDate, slotStatus: p.slotStatus, sessionTitle: p.sessionTitle }));
  return { rows, hours };
}

type Visibility = (typeof schema.documentVisibilityEnum.enumValues)[number];

/** Documents d'un périmètre (inscriptions, personne, entreprise, formateur) limités à une visibilité. */
export async function listVisibleDocuments(orgId: string, scope: { enrollmentIds?: string[]; personId?: string; companyId?: string; trainerId?: string; sessionIds?: string[] }, visibilities: Visibility[]) {
  const ors = [];
  if (scope.enrollmentIds?.length) ors.push(inArray(schema.documents.enrollmentId, scope.enrollmentIds));
  if (scope.personId) ors.push(eq(schema.documents.personId, scope.personId));
  if (scope.companyId) ors.push(eq(schema.documents.companyId, scope.companyId));
  if (scope.trainerId) ors.push(eq(schema.documents.trainerId, scope.trainerId));
  if (scope.sessionIds?.length) ors.push(inArray(schema.documents.sessionId, scope.sessionIds));
  if (!ors.length) return [];
  return db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), inArray(schema.documents.visibility, visibilities), or(...ors)))
    .orderBy(desc(schema.documents.createdAt));
}

/** Vérifie qu'un document est bien dans le périmètre donné (recharge la ligne : l'identifiant transmis n'est jamais une autorisation). */
export async function findVisibleDocument(orgId: string, documentId: string, scope: Parameters<typeof listVisibleDocuments>[1], visibilities: Visibility[]) {
  const docs = await listVisibleDocuments(orgId, scope, visibilities);
  return docs.find((d) => d.id === documentId) ?? null;
}

export type PieceRow = {
  submission: typeof schema.pieceSubmissions.$inferSelect;
  piece: typeof schema.requiredPieces.$inferSelect;
  document: { id: string; title: string; fileName: string; createdAt: Date } | null;
};

/** Pièces attendues des inscriptions données (option : seulement celles à fournir par un déposant). */
export async function listPieces(orgId: string, enrollmentIds: string[], providedBy?: string[]): Promise<PieceRow[]> {
  if (!enrollmentIds.length) return [];
  const conds = [eq(schema.pieceSubmissions.orgId, orgId), inArray(schema.pieceSubmissions.enrollmentId, enrollmentIds)];
  if (providedBy?.length) conds.push(inArray(schema.requiredPieces.providedBy, providedBy));
  const rows = await db
    .select({ submission: schema.pieceSubmissions, piece: schema.requiredPieces, document: { id: schema.documents.id, title: schema.documents.title, fileName: schema.documents.fileName, createdAt: schema.documents.createdAt } })
    .from(schema.pieceSubmissions)
    .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
    .leftJoin(schema.documents, eq(schema.documents.id, schema.pieceSubmissions.documentId))
    .where(and(...conds))
    .orderBy(asc(schema.requiredPieces.position), asc(schema.requiredPieces.label));
  return rows.map((r) => ({ submission: r.submission, piece: r.piece, document: r.document?.id ? r.document : null }));
}

/** Entrées de livret visibles par l'apprenant ou l'entreprise. */
export async function listRecordEntries(orgId: string, enrollmentIds: string[], audience: "learner" | "company") {
  if (!enrollmentIds.length) return [];
  const flag = audience === "learner" ? eq(schema.recordEntries.visibleToLearner, true) : eq(schema.recordEntries.visibleToCompany, true);
  return db
    .select()
    .from(schema.recordEntries)
    .where(and(eq(schema.recordEntries.orgId, orgId), inArray(schema.recordEntries.enrollmentId, enrollmentIds), flag))
    .orderBy(desc(schema.recordEntries.date), desc(schema.recordEntries.createdAt));
}

/** Évaluations (résultats) des inscriptions données. Le commentaire interne n'est jamais exposé : seul le résultat l'est. */
export async function listEvaluations(orgId: string, enrollmentIds: string[]) {
  if (!enrollmentIds.length) return [];
  return db
    .select({
      id: schema.evaluations.id,
      enrollmentId: schema.evaluations.enrollmentId,
      kind: schema.evaluations.kind,
      title: schema.evaluations.title,
      date: schema.evaluations.date,
      score: schema.evaluations.score,
      maxScore: schema.evaluations.maxScore,
      result: schema.evaluations.result,
      skills: schema.evaluations.skills,
      moduleTitle: schema.modules.title,
    })
    .from(schema.evaluations)
    .leftJoin(schema.modules, eq(schema.modules.id, schema.evaluations.moduleId))
    .where(and(eq(schema.evaluations.orgId, orgId), inArray(schema.evaluations.enrollmentId, enrollmentIds)))
    .orderBy(desc(schema.evaluations.date));
}

export type ElearningRow = {
  module: typeof schema.elearningModules.$inferSelect;
  enrollmentId: string;
  progress: typeof schema.elearningProgress.$inferSelect | null;
};

/** Modules e-learning actifs des versions de programme des inscriptions, avec la progression de l'apprenant. */
export async function listElearning(orgId: string, enrollments: { id: string; programVersionId: string | null; sessionVersionId: string }[]): Promise<ElearningRow[]> {
  const out: ElearningRow[] = [];
  for (const e of enrollments) {
    const versionId = e.programVersionId ?? e.sessionVersionId;
    const modules = await db
      .select()
      .from(schema.elearningModules)
      .where(and(eq(schema.elearningModules.orgId, orgId), eq(schema.elearningModules.programVersionId, versionId), eq(schema.elearningModules.isActive, true)))
      .orderBy(asc(schema.elearningModules.position));
    if (!modules.length) continue;
    const progress = await db
      .select()
      .from(schema.elearningProgress)
      .where(and(eq(schema.elearningProgress.orgId, orgId), eq(schema.elearningProgress.enrollmentId, e.id), inArray(schema.elearningProgress.elearningModuleId, modules.map((m) => m.id))));
    const byModule = new Map(progress.map((p) => [p.elearningModuleId, p]));
    for (const m of modules) out.push({ module: m, enrollmentId: e.id, progress: byModule.get(m.id) ?? null });
  }
  return out;
}

export type SurveyRow = { response: typeof schema.surveyResponses.$inferSelect; survey: typeof schema.surveys.$inferSelect };

/** Enquêtes dont une réponse existe pour le périmètre (inscriptions ou contacts), répondues ou en attente. */
export async function listSurveys(orgId: string, scope: { enrollmentIds?: string[]; contactIds?: string[]; trainerId?: string }): Promise<SurveyRow[]> {
  const ors = [];
  if (scope.enrollmentIds?.length) ors.push(inArray(schema.surveyResponses.enrollmentId, scope.enrollmentIds));
  if (scope.contactIds?.length) ors.push(inArray(schema.surveyResponses.contactId, scope.contactIds));
  if (scope.trainerId) ors.push(eq(schema.surveyResponses.trainerId, scope.trainerId));
  if (!ors.length) return [];
  return db
    .select({ response: schema.surveyResponses, survey: schema.surveys })
    .from(schema.surveyResponses)
    .innerJoin(schema.surveys, eq(schema.surveys.id, schema.surveyResponses.surveyId))
    .where(and(eq(schema.surveyResponses.orgId, orgId), or(...ors)))
    .orderBy(desc(schema.surveyResponses.createdAt));
}

/** Suivis en entreprise des inscriptions données (lecture pour le tuteur). */
export async function listCompanyFollowups(orgId: string, enrollmentIds: string[]) {
  if (!enrollmentIds.length) return [];
  return db
    .select()
    .from(schema.companyFollowups)
    .where(and(eq(schema.companyFollowups.orgId, orgId), inArray(schema.companyFollowups.enrollmentId, enrollmentIds)))
    .orderBy(desc(schema.companyFollowups.date));
}

/** Factures adressées à une entreprise (hors brouillons). */
export async function listCompanyInvoices(orgId: string, companyId: string) {
  return db
    .select()
    .from(schema.invoices)
    .where(and(eq(schema.invoices.orgId, orgId), eq(schema.invoices.companyId, companyId), sql`${schema.invoices.status} <> 'brouillon'`))
    .orderBy(desc(schema.invoices.issueDate));
}

/** Demandes de signature en attente sur les documents donnés. */
export async function listPendingSignatures(orgId: string, documentIds: string[]) {
  if (!documentIds.length) return [];
  return db
    .select()
    .from(schema.signatureRequests)
    .where(and(eq(schema.signatureRequests.orgId, orgId), inArray(schema.signatureRequests.documentId, documentIds), inArray(schema.signatureRequests.status, ["envoyee", "signee_partiellement"])))
    .orderBy(desc(schema.signatureRequests.createdAt));
}

/** Apprenants (inscriptions actives) des sessions données : nom, groupe, session. Aucune donnée administrative. */
export async function listLearnersForSessions(orgId: string, sessionIds: string[]) {
  if (!sessionIds.length) return [];
  return db
    .select({
      enrollmentId: schema.enrollments.id,
      status: schema.enrollments.status,
      sessionId: schema.enrollments.sessionId,
      sessionTitle: schema.trainingSessions.title,
      groupName: schema.groups.name,
      firstName: schema.persons.firstName,
      lastName: schema.persons.lastName,
      hasAccommodations: schema.persons.hasAccommodations,
    })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .leftJoin(schema.groups, eq(schema.groups.id, schema.enrollments.groupId))
    .where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.sessionId, sessionIds), inArray(schema.enrollments.status, ["inscrit", "en_cours", "preinscrit"])))
    .orderBy(asc(schema.trainingSessions.startDate), asc(schema.persons.lastName), asc(schema.persons.firstName));
}

/** Présences récentes (périodes passées, lignes courantes) des inscriptions données. */
export async function recentAttendances(orgId: string, enrollmentIds: string[], limitDays = 30) {
  if (!enrollmentIds.length) return [];
  const from = new Date(Date.now() - limitDays * 86400_000).toISOString().slice(0, 10);
  return db
    .select({ enrollmentId: schema.attendances.enrollmentId, status: schema.attendances.status, date: schema.slots.date, part: schema.periods.part })
    .from(schema.attendances)
    .innerJoin(schema.periods, eq(schema.periods.id, schema.attendances.periodId))
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .where(and(eq(schema.attendances.orgId, orgId), inArray(schema.attendances.enrollmentId, enrollmentIds), eq(schema.attendances.isCurrent, true), gte(schema.slots.date, from), lte(schema.slots.date, todayParis())))
    .orderBy(desc(schema.slots.date));
}

/** Tâches ouvertes liées à des entités (lecture : utilisé par l'assistant et le résumé de dossier). */
export async function openTasksFor(orgId: string, entityType: string, entityIds: string[]) {
  if (!entityIds.length) return [];
  return db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, orgId), eq(schema.tasks.entityType, entityType), inArray(schema.tasks.entityId, entityIds), inArray(schema.tasks.status, ["a_faire", "en_cours", "bloquee"]), isNull(schema.tasks.completedAt)))
    .orderBy(asc(schema.tasks.dueDate));
}
