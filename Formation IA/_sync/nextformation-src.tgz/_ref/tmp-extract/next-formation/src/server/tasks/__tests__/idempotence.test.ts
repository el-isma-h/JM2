import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, sql } from "drizzle-orm";

/**
 * Test d'intégration (R10) : un même événement ne crée qu'une seule tâche, même en envois simultanés.
 * Nécessite la base locale ; ignoré si elle n'est pas joignable.
 */
let available = false;
let orgId = "";
let tenantId = "";
let dbMod: typeof import("../../../db") | null = null;
let service: typeof import("../service") | null = null;

beforeAll(async () => {
  try {
    dbMod = await import("../../../db");
    await dbMod.db.execute(sql`select 1`);
    service = await import("../service");
    const { db, schema } = dbMod;
    const [tenant] = await db.insert(schema.tenants).values({ name: "Test idempotence", kind: "organisme", slug: `test-idem-${Date.now()}`, isDemo: true }).returning();
    const [org] = await db.insert(schema.organismes).values({ tenantId: tenant.id, legalName: "Organisme test idempotence", isDemo: true }).returning();
    tenantId = tenant.id;
    orgId = org.id;
    available = true;
  } catch (e) {
    available = false;
    console.warn("Base locale indisponible, test d'intégration ignoré :", e instanceof Error ? e.message : e);
  }
}, 30_000);

afterAll(async () => {
  if (available && dbMod) {
    await dbMod.db.delete(dbMod.schema.tenants).where(eq(dbMod.schema.tenants.id, tenantId));
    await dbMod.pool.end();
  }
});

describe("createTaskOnce (idempotence F14 / R10)", () => {
  it("ne crée qu'une tâche pour une même clé, même en envois simultanés", async () => {
    if (!available || !service || !dbMod) return;
    console.info("Test d'intégration exécuté sur la base locale (organisme", orgId, ")");
    const key = `piece:${orgId}:convention_signee`;
    const input = { orgId, title: "Convention signée à obtenir", idempotencyKey: key, assigneeRole: "admin_staff", isDemo: true };
    const results = await Promise.all([service.createTaskOnce(input), service.createTaskOnce(input), service.createTaskOnce(input), service.createTaskOnce(input)]);
    const created = results.filter((r) => r.created).length;
    expect(created).toBe(1);
    expect(new Set(results.map((r) => r.task.id)).size).toBe(1);
    const rows = await dbMod.db.select().from(dbMod.schema.tasks).where(eq(dbMod.schema.tasks.orgId, orgId));
    expect(rows.length).toBe(1);
    expect(rows[0].status).toBe("a_faire");
    // Nouvelle tentative après résolution : la tâche résolue n'est pas recréée, ni supprimée.
    const resolved = await service.resolveTaskByKey(orgId, key, "Pièce reçue");
    expect(resolved?.status).toBe("terminee");
    const again = await service.createTaskOnce(input);
    expect(again.created).toBe(false);
    expect(again.task.status).toBe("terminee");
    const all = await dbMod.db.select().from(dbMod.schema.tasks).where(eq(dbMod.schema.tasks.orgId, orgId));
    expect(all.length).toBe(1);
  }, 30_000);

  it("isole les organismes : la même clé dans un autre organisme crée une autre tâche", async () => {
    if (!available || !service || !dbMod) return;
    const { db, schema } = dbMod;
    const [other] = await db.insert(schema.organismes).values({ tenantId, legalName: "Autre organisme", isDemo: true }).returning();
    const key = `piece:${orgId}:convention_signee`;
    const r = await service.createTaskOnce({ orgId: other.id, title: "Même clé, autre organisme", idempotencyKey: key, isDemo: true });
    expect(r.created).toBe(true);
    const mine = await db.select().from(schema.tasks).where(eq(schema.tasks.orgId, orgId));
    expect(mine.length).toBe(1);
  }, 30_000);
});
