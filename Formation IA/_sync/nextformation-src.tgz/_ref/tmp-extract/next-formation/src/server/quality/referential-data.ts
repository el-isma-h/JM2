/**
 * Référentiel National Qualité (Qualiopi) : 7 critères, 32 indicateurs.
 * Données pures (aucun accès base) : libellés reformulés d'après le guide de lecture publié par le ministère
 * du Travail, sans invention. Ce référentiel est seulement PROPOSÉ (statut brouillon, orgId null) :
 * chaque organisme doit le copier, vérifier les textes, saisir la version et les dates d'effet, puis le valider
 * par un humain habilité avant qu'il ne devienne applicable (CDC « Applicabilité réglementaire »).
 */

export type EvidenceLevel = "individuel" | "collectif" | "organisationnel";
export type Activity = "of" | "cfa";
export type AnalysisScope = "organisme" | "session" | "inscription" | "programme";

export type IndicatorDef = {
  /** Code stable : IND_1 … IND_32. */
  code: string;
  number: number;
  label: string;
  /** Critère de rattachement (1 à 7). */
  criterion: number;
  /** Niveau de preuve attendu : individuel (par apprenant), collectif (par session / programme), organisationnel. */
  level: EvidenceLevel;
  /** Vrai quand l'indicateur demande une appréciation humaine (adaptation, amélioration continue…) : jamais « prouvé » automatiquement. */
  requiresHuman: boolean;
  /** Activités concernées : ["of","cfa"] = tous ; ["cfa"] = apprentissage uniquement. */
  applicability: Activity[];
  /** Condition d'applicabilité à apprécier par l'organisme (ex. prestations certifiantes, alternance, seuil réglementaire). */
  condition?: string;
  /** Preuves du logiciel qui comptent pour cet indicateur. */
  evidenceHints: string[];
};

export type CriterionDef = { code: string; number: number; label: string; indicators: IndicatorDef[] };

export type ReferentialDef = {
  code: string;
  title: string;
  version: string;
  source: string;
  sourceUrl: string;
  scope: "both";
  criteria: CriterionDef[];
};

const ALL: Activity[] = ["of", "cfa"];
const CFA: Activity[] = ["cfa"];

function ind(
  number: number,
  label: string,
  criterion: number,
  level: EvidenceLevel,
  opts: { requiresHuman?: boolean; applicability?: Activity[]; condition?: string; evidenceHints: string[] },
): IndicatorDef {
  return {
    code: `IND_${number}`,
    number,
    label,
    criterion,
    level,
    requiresHuman: opts.requiresHuman ?? false,
    applicability: opts.applicability ?? ALL,
    condition: opts.condition,
    evidenceHints: opts.evidenceHints,
  };
}

export const QUALIOPI_INDICATORS: IndicatorDef[] = [
  // Critère 1 : information du public
  ind(1, "Le prestataire diffuse une information accessible au public, détaillée et vérifiable sur les prestations proposées : prérequis, objectifs, durée, modalités et délais d'accès, tarifs, contacts, méthodes mobilisées et modalités d'évaluation, accessibilité aux personnes handicapées.", 1, "organisationnel", {
    evidenceHints: ["Programme publié sur le catalogue public", "Fiche formation avec délais d'accès et tarifs", "Mention de l'accessibilité handicap"],
  }),
  ind(2, "Le prestataire diffuse des indicateurs de résultats adaptés à la nature des prestations mises en œuvre et aux publics accueillis.", 1, "organisationnel", {
    evidenceHints: ["Indicateurs publiés : taux de satisfaction, de retour, d'abandon, de réussite (avec définition et dénominateur)", "Page de résultats du catalogue public"],
  }),
  ind(3, "Lorsque le prestataire met en œuvre des prestations conduisant à une certification professionnelle, il informe sur les taux d'obtention des certifications, les possibilités de valider un ou des blocs de compétences, les équivalences, passerelles, suites de parcours et débouchés.", 1, "organisationnel", {
    condition: "Prestations certifiantes (et apprentissage).",
    evidenceHints: ["Taux d'obtention publié par certification", "Fiche formation mentionnant blocs, passerelles et débouchés", "Lien vers la fiche RNCP / RS"],
  }),

  // Critère 2 : objectifs et adaptation
  ind(4, "Le prestataire analyse le besoin du bénéficiaire en lien avec l'entreprise et/ou le financeur concerné(s).", 2, "individuel", {
    evidenceHints: ["Besoin qualifié (CRM) relié à l'inscription", "Fiche d'analyse du besoin", "Convention ou contrat mentionnant les objectifs du bénéficiaire"],
  }),
  ind(5, "Le prestataire définit les objectifs opérationnels et évaluables de la prestation.", 2, "collectif", {
    evidenceHints: ["Programme (version contractualisée) avec objectifs évaluables", "Annexe de parcours"],
  }),
  ind(6, "Le prestataire établit les contenus et les modalités de mise en œuvre de la prestation, adaptés aux objectifs définis et aux publics bénéficiaires.", 2, "collectif", {
    requiresHuman: true,
    evidenceHints: ["Programme détaillé (contenus, méthodes, modalités)", "Déroulé pédagogique de la session", "Appréciation humaine de l'adaptation aux publics"],
  }),
  ind(7, "Lorsque le prestataire met en œuvre des prestations conduisant à une certification professionnelle, il s'assure de l'adéquation du ou des contenus de la prestation aux exigences de la certification visée.", 2, "collectif", {
    requiresHuman: true,
    condition: "Prestations certifiantes (et apprentissage).",
    evidenceHints: ["Référentiel de certification relié au programme", "Tableau de correspondance contenus / blocs de compétences", "Habilitation du certificateur"],
  }),
  ind(8, "Le prestataire détermine les procédures de positionnement et d'évaluation des acquis à l'entrée de la prestation.", 2, "individuel", {
    evidenceHints: ["Positionnement enregistré dans le dossier", "Enquête de positionnement reçue", "Test de niveau"],
  }),

  // Critère 3 : accueil, accompagnement, suivi, évaluation
  ind(9, "Le prestataire informe les publics bénéficiaires des conditions de déroulement de la prestation.", 3, "individuel", {
    evidenceHints: ["Convocation transmise", "Règlement intérieur remis", "Livret d'accueil", "Convention ou contrat signé"],
  }),
  ind(10, "Le prestataire met en œuvre et adapte la prestation, l'accompagnement et le suivi aux publics bénéficiaires.", 3, "individuel", {
    requiresHuman: true,
    evidenceHints: ["Plan individuel de formation", "Aménagements enregistrés (handicap, rythme)", "Suivi pédagogique (livret, entretiens)"],
  }),
  ind(11, "Le prestataire évalue l'atteinte par les publics bénéficiaires des objectifs de la prestation.", 3, "individuel", {
    evidenceHints: ["Évaluations pendant le parcours (suivi des acquis)", "Livret de compétences", "Attestation de fin de formation avec résultats"],
  }),
  ind(12, "Le prestataire décrit et met en œuvre les mesures pour favoriser l'engagement des bénéficiaires et prévenir les ruptures de parcours.", 3, "individuel", {
    requiresHuman: true,
    evidenceHints: ["Suivi des absences et relances", "Entretiens de suivi", "Procédure de prévention des ruptures"],
  }),
  ind(13, "Pour les formations en alternance, le prestataire, en lien avec l'entreprise, assure la coordination et la progressivité des apprentissages entre le centre et l'entreprise.", 3, "individuel", {
    condition: "Formations en alternance (apprentissage, professionnalisation).",
    evidenceHints: ["Livret d'alternance", "Visites et suivi en entreprise", "Rythme centre / entreprise de la session"],
  }),
  ind(14, "Le prestataire met en œuvre un accompagnement socio-professionnel, éducatif et citoyen lorsqu'il est prévu.", 3, "individuel", {
    requiresHuman: true,
    applicability: CFA,
    condition: "Apprentissage uniquement (CFA).",
    evidenceHints: ["Entretiens d'accompagnement", "Actions socio-éducatives ou citoyennes", "Référent de l'apprenti"],
  }),
  ind(15, "Le prestataire informe les apprentis de leurs droits et devoirs en tant qu'apprentis et salariés ainsi que des règles applicables en matière de santé et de sécurité en milieu professionnel.", 3, "individuel", {
    applicability: CFA,
    condition: "Apprentissage uniquement (CFA).",
    evidenceHints: ["Document droits et devoirs remis", "Règlement intérieur signé", "Information santé-sécurité"],
  }),
  ind(16, "Lorsque le prestataire met en œuvre des prestations conduisant à une certification professionnelle, il s'assure que les conditions de présentation des bénéficiaires à la certification respectent les exigences formelles de l'autorité de certification.", 3, "individuel", {
    condition: "Prestations certifiantes (et apprentissage).",
    evidenceHints: ["Inscription à la cohorte d'examen (éligibilité contrôlée)", "Convocation à l'examen", "Résultat enregistré sur le bon membre"],
  }),

  // Critère 4 : moyens
  ind(17, "Le prestataire met à disposition ou s'assure de la mise à disposition des moyens humains et techniques adaptés et d'un environnement approprié (conditions, locaux, équipements, plateaux techniques…).", 4, "collectif", {
    evidenceHints: ["Site et salle affectés à la session", "Formateur affecté", "Inventaire des moyens techniques"],
  }),
  ind(18, "Le prestataire mobilise et coordonne les différents intervenants internes et/ou externes (pédagogiques, administratifs, logistiques, commerciaux…).", 4, "collectif", {
    evidenceHints: ["Affectations formateurs et responsables de session", "Réunions de coordination", "Planning partagé"],
  }),
  ind(19, "Le prestataire met à disposition du bénéficiaire des ressources pédagogiques et permet à celui-ci de se les approprier.", 4, "collectif", {
    condition: "Formation à distance : suivi et référent pédagogique selon le seuil fixé par arrêté.",
    evidenceHints: ["Ressources déposées (supports, e-learning)", "Accès extranet apprenant", "Référent pédagogique désigné"],
  }),
  ind(20, "Le prestataire dispose d'un personnel dédié à l'appui à la mobilité nationale et internationale, d'un référent handicap et d'un conseil de perfectionnement.", 4, "organisationnel", {
    applicability: CFA,
    condition: "Apprentissage uniquement (CFA) ; seuils fixés par arrêté.",
    evidenceHints: ["Référent handicap désigné", "Référent mobilité désigné", "Comptes rendus du conseil de perfectionnement"],
  }),

  // Critère 5 : personnels
  ind(21, "Le prestataire détermine, mobilise et évalue les compétences des différents intervenants internes et/ou externes, adaptées aux prestations.", 5, "organisationnel", {
    evidenceHints: ["CV et qualifications des formateurs", "Habilitations", "Évaluation des intervenants (enquête formateur)"],
  }),
  ind(22, "Le prestataire entretient et développe les compétences de ses salariés, adaptées aux prestations qu'il délivre.", 5, "organisationnel", {
    evidenceHints: ["Plan de développement des compétences", "Attestations de formation des salariés", "Entretiens professionnels"],
  }),

  // Critère 6 : environnement professionnel
  ind(23, "Le prestataire réalise une veille légale et réglementaire sur le champ de la formation professionnelle et en exploite les enseignements.", 6, "organisationnel", {
    evidenceHints: ["Entrées de veille réglementaire partagées", "Actions issues de la veille"],
  }),
  ind(24, "Le prestataire réalise une veille sur les évolutions des compétences, des métiers et des emplois dans ses secteurs d'intervention et en exploite les enseignements.", 6, "organisationnel", {
    evidenceHints: ["Entrées de veille métiers / compétences", "Mise à jour des programmes consécutive"],
  }),
  ind(25, "Le prestataire réalise une veille sur les innovations pédagogiques et technologiques permettant une évolution de ses prestations et en exploite les enseignements.", 6, "organisationnel", {
    evidenceHints: ["Entrées de veille pédagogique", "Expérimentations et évolutions de modalités"],
  }),
  ind(26, "Le prestataire mobilise les expertises, outils et réseaux nécessaires pour accueillir, accompagner ou former ou orienter les publics en situation de handicap.", 6, "organisationnel", {
    evidenceHints: ["Veille handicap et réseau de partenaires", "Référent handicap", "Aménagements mis en œuvre"],
  }),
  ind(27, "Lorsque le prestataire fait appel à la sous-traitance ou au portage salarial, il s'assure du respect de la conformité au présent référentiel.", 6, "organisationnel", {
    condition: "Seulement si l'organisme recourt à la sous-traitance ou au portage salarial.",
    evidenceHints: ["Contrats de sous-traitance avec clause qualité", "Vérification des sous-traitants (fiche formateur sous-traitant)"],
  }),
  ind(28, "Lorsque les prestations dispensées au bénéficiaire comprennent des périodes de formation en situation de travail, le prestataire mobilise son réseau de partenaires socio-économiques pour co-construire l'ingénierie de formation et favoriser l'accueil en entreprise.", 6, "organisationnel", {
    condition: "Formations comprenant des périodes en situation de travail (alternance, stages).",
    evidenceHints: ["Partenariats entreprises (CRM)", "Placements réalisés", "Conventions de stage"],
  }),
  ind(29, "Le prestataire développe des actions qui concourent à l'insertion professionnelle ou la poursuite d'étude par la voie de l'apprentissage ou par toute autre voie.", 6, "organisationnel", {
    applicability: CFA,
    condition: "Apprentissage uniquement (CFA).",
    evidenceHints: ["Actions d'insertion (forums, ateliers)", "Suivi de l'insertion à 6 mois", "Enquête à froid"],
  }),

  // Critère 7 : appréciations et réclamations
  ind(30, "Le prestataire recueille les appréciations des parties prenantes : bénéficiaires, financeurs, équipes pédagogiques et entreprises concernées.", 7, "collectif", {
    evidenceHints: ["Réponses aux enquêtes de satisfaction (à chaud, à froid)", "Enquête employeur, financeur, formateur"],
  }),
  ind(31, "Le prestataire met en œuvre des modalités de traitement des difficultés rencontrées par les parties prenantes, des réclamations exprimées par ces dernières, des aléas survenus en cours de prestation.", 7, "organisationnel", {
    evidenceHints: ["Réclamations enregistrées et traitées (clôture avec résolution)", "Procédure de traitement des réclamations"],
  }),
  ind(32, "Le prestataire met en œuvre des mesures d'amélioration à partir de l'analyse des appréciations et des réclamations.", 7, "organisationnel", {
    requiresHuman: true,
    evidenceHints: ["Actions qualité issues des enquêtes, réclamations, audits", "Revue de direction", "Analyse des risques"],
  }),
];

export const QUALIOPI_CRITERIA_LABELS: Record<number, string> = {
  1: "Conditions d'information du public sur les prestations, les délais d'accès et les résultats obtenus",
  2: "Identification précise des objectifs des prestations et adaptation aux publics bénéficiaires",
  3: "Adaptation aux publics bénéficiaires des prestations et des modalités d'accueil, d'accompagnement, de suivi et d'évaluation",
  4: "Adéquation des moyens pédagogiques, techniques et d'encadrement aux prestations",
  5: "Qualification et développement des connaissances et compétences des personnels chargés des prestations",
  6: "Inscription et investissement du prestataire dans son environnement professionnel",
  7: "Recueil et prise en compte des appréciations et des réclamations formulées par les parties prenantes",
};

export function buildCriteria(indicators: IndicatorDef[] = QUALIOPI_INDICATORS): CriterionDef[] {
  return Object.entries(QUALIOPI_CRITERIA_LABELS).map(([n, label]) => ({
    code: `CRIT_${n}`,
    number: Number(n),
    label,
    indicators: indicators.filter((i) => i.criterion === Number(n)),
  }));
}

/**
 * Référentiel plateforme proposé. La « version » est celle du guide de lecture saisie par l'organisme lors de la
 * validation ; celle-ci n'est qu'une référence de projet et n'emporte aucune applicabilité.
 */
export const QUALIOPI_RNQ: ReferentialDef = {
  code: "RNQ_QUALIOPI",
  title: "Référentiel National Qualité (Qualiopi)",
  version: "guide-de-lecture-en-vigueur",
  source: "Guide de lecture du RNQ, version en vigueur",
  sourceUrl: "https://travail-emploi.gouv.fr/formation-professionnelle/acteurs-cadre-et-qualite-de-la-formation-professionnelle/article/qualiopi-marque-de-certification-qualite-des-prestataires-de-formation",
  scope: "both",
  criteria: buildCriteria(),
};

/** Lecture tolérante des critères stockés en JSON (référentiel copié par l'organisme). */
export function parseCriteria(raw: unknown): CriterionDef[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((c) => {
      const o = (c ?? {}) as Partial<CriterionDef>;
      const indicators = Array.isArray(o.indicators)
        ? (o.indicators as Partial<IndicatorDef>[]).map((i) => ({
            code: String(i.code ?? ""),
            number: Number(i.number ?? String(i.code ?? "").replace(/\D/g, "")) || 0,
            label: String(i.label ?? ""),
            criterion: Number(i.criterion ?? o.number ?? 0),
            level: (["individuel", "collectif", "organisationnel"].includes(String(i.level)) ? i.level : "organisationnel") as EvidenceLevel,
            requiresHuman: Boolean(i.requiresHuman),
            applicability: (Array.isArray(i.applicability) && i.applicability.length ? i.applicability.filter((a) => a === "of" || a === "cfa") : ALL) as Activity[],
            condition: i.condition ? String(i.condition) : undefined,
            evidenceHints: Array.isArray(i.evidenceHints) ? i.evidenceHints.map(String) : [],
          }))
        : [];
      return { code: String(o.code ?? ""), number: Number(o.number ?? 0), label: String(o.label ?? ""), indicators };
    })
    .filter((c) => c.indicators.length || c.code);
}

export function flattenIndicators(criteria: CriterionDef[]): IndicatorDef[] {
  return criteria.flatMap((c) => c.indicators);
}
