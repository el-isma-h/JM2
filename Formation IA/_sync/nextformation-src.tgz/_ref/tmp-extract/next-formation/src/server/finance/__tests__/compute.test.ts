import { describe, expect, it } from "vitest";
import {
  checkPaymentAmount,
  deriveFundingState,
  formatInvoiceNumber,
  fundingTransitionError,
  invoiceTotals,
  isOverdue,
  lineTotalHt,
  nextScheduleLine,
  overdueScheduleLines,
  parseAmountToCents,
  parseBankCsv,
  paymentStatus,
  proposeMatches,
  salesJournalRows,
  sequenceKindFor,
  toCsv,
  validateSchedule,
  DEFAULT_ACCOUNTING,
} from "../compute";

describe("numérotation continue", () => {
  it("formate F-AAAA-NNNNN et AV-AAAA-NNNNN", () => {
    expect(formatInvoiceNumber("facture", 2026, 1)).toBe("F-2026-00001");
    expect(formatInvoiceNumber("acompte", 2026, 12)).toBe("F-2026-00012");
    expect(formatInvoiceNumber("avoir", 2026, 3)).toBe("AV-2026-00003");
    expect(formatInvoiceNumber("facture", 2027, 100000)).toBe("F-2027-100000");
  });
  it("sépare les séquences par type : factures et acomptes partagent le compteur, les avoirs ont le leur", () => {
    expect(sequenceKindFor("facture")).toBe("facture");
    expect(sequenceKindFor("acompte")).toBe("facture");
    expect(sequenceKindFor("avoir")).toBe("avoir");
    expect(sequenceKindFor("proforma")).toBe("proforma");
  });
  it("refuse un numéro de séquence invalide", () => {
    expect(() => formatInvoiceNumber("facture", 2026, 0)).toThrow();
  });
});

describe("totaux et TVA", () => {
  it("calcule le HT d'une ligne en millièmes sans flottant", () => {
    expect(lineTotalHt({ quantityMilli: 1000, unitCents: 125000 })).toBe(125000);
    expect(lineTotalHt({ quantityMilli: 1500, unitCents: 10000 })).toBe(15000);
    expect(lineTotalHt({ quantityMilli: 333, unitCents: 10000 })).toBe(3330);
    // 7 h × 83,33 € = 583,31 €
    expect(lineTotalHt({ quantityMilli: 7000, unitCents: 8333 })).toBe(58331);
  });
  it("exonération formation : TVA à zéro quel que soit le taux saisi", () => {
    const t = invoiceTotals([{ label: "Formation", quantityMilli: 1000, unit: "forfait", unitCents: 120000, vatRateBp: 2000 }], true);
    expect(t.totalHtCents).toBe(120000);
    expect(t.vatCents).toBe(0);
    expect(t.totalTtcCents).toBe(120000);
    expect(t.lines[0].vatRateBp).toBe(0);
  });
  it("applique la TVA par ligne avec arrondi au centime", () => {
    const t = invoiceTotals(
      [
        { label: "Formation", quantityMilli: 1000, unit: "forfait", unitCents: 100000, vatRateBp: 2000 },
        { label: "Support", quantityMilli: 3000, unit: "unité", unitCents: 1234, vatRateBp: 550 },
      ],
      false,
    );
    expect(t.lines[0].vatCents).toBe(20000);
    expect(t.lines[1].totalHtCents).toBe(3702);
    expect(t.lines[1].vatCents).toBe(204); // 3702 × 5,5 % = 203,61 → 204
    expect(t.totalHtCents).toBe(103702);
    expect(t.vatCents).toBe(20204);
    expect(t.totalTtcCents).toBe(123906);
  });
  it("est reproductible : même entrée, même sortie", () => {
    const lines = [{ label: "x", quantityMilli: 2500, unit: "h", unitCents: 4567, vatRateBp: 1000 }];
    expect(invoiceTotals(lines, false)).toEqual(invoiceTotals(lines, false));
  });
});

describe("règlements et statut de paiement", () => {
  it("refuse le trop-perçu et les montants nuls", () => {
    expect(checkPaymentAmount(100000, 0, 100001)).toMatch(/Trop-perçu/);
    expect(checkPaymentAmount(100000, 60000, 40001)).toMatch(/Trop-perçu/);
    expect(checkPaymentAmount(100000, 100000, 1)).toMatch(/déjà soldée/);
    expect(checkPaymentAmount(100000, 0, 0)).toMatch(/positif/);
    expect(checkPaymentAmount(100000, 60000, 40000)).toBeNull();
  });
  it("recalcule partiellement payée / payée / retour à émise", () => {
    const b = { kind: "facture" as const, totalTtcCents: 100000 };
    expect(paymentStatus({ ...b, status: "emise", paidCents: 40000 })).toBe("partiellement_payee");
    expect(paymentStatus({ ...b, status: "en_retard", paidCents: 100000 })).toBe("payee");
    expect(paymentStatus({ ...b, status: "payee", paidCents: 0 })).toBe("emise");
    expect(paymentStatus({ ...b, status: "payee", paidCents: 0, sentAt: new Date() })).toBe("envoyee");
    expect(paymentStatus({ ...b, status: "emise", paidCents: 0, overdue: true })).toBe("en_retard");
  });
  it("ne touche ni aux brouillons, ni aux annulées, ni aux avoirs", () => {
    expect(paymentStatus({ kind: "facture", status: "brouillon", totalTtcCents: 100, paidCents: 100 })).toBe("brouillon");
    expect(paymentStatus({ kind: "facture", status: "annulee", totalTtcCents: 100, paidCents: 100 })).toBe("annulee");
    expect(paymentStatus({ kind: "avoir", status: "emise", totalTtcCents: 100, paidCents: 0 })).toBe("emise");
  });
  it("détecte le retard sur l'échéance serveur", () => {
    const inv = { kind: "facture" as const, status: "emise" as const, dueDate: "2026-03-01", totalTtcCents: 1000, paidCents: 0 };
    expect(isOverdue(inv, "2026-03-02")).toBe(true);
    expect(isOverdue(inv, "2026-03-01")).toBe(false);
    expect(isOverdue({ ...inv, paidCents: 1000 }, "2026-03-02")).toBe(false);
    expect(isOverdue({ ...inv, kind: "avoir" }, "2026-03-02")).toBe(false);
  });
});

describe("financement : règles de passage « accordé »", () => {
  it("exige référence, source et date de validité", () => {
    expect(fundingTransitionError("demande", "accorde", {})).toMatch(/référence de prise en charge/);
    expect(fundingTransitionError("demande", "accorde", { agreementRef: "OPCO-123" })).toMatch(/source/);
    expect(fundingTransitionError("demande", "accorde", { agreementRef: "OPCO-123", agreementSource: "Portail OPCO" })).toMatch(/validité/);
    expect(fundingTransitionError("demande", "accorde", { agreementRef: "OPCO-123", agreementSource: "Portail OPCO", validUntil: "2026-12-31" })).toBeNull();
  });
  it("refuse une validité inversée", () => {
    expect(fundingTransitionError("prevu", "accorde", { agreementRef: "A", agreementSource: "S", validFrom: "2026-12-31", validUntil: "2026-01-01" })).toMatch(/précéder/);
  });
  it("interdit les transitions incohérentes", () => {
    expect(fundingTransitionError("solde", "prevu", {})).toMatch(/impossible/);
    expect(fundingTransitionError("prevu", "solde", {})).toMatch(/impossible/);
    expect(fundingTransitionError("facture", "facture", {})).toBeNull();
    expect(fundingTransitionError("refuse", "demande", {})).toBeNull();
  });
});

describe("échéancier", () => {
  it("contrôle la somme égale au montant", () => {
    expect(validateSchedule([], 1000)).toBeNull();
    expect(validateSchedule([{ label: "Acompte", dueDate: "2026-01-15", amountCents: 400 }, { label: "Solde", dueDate: "2026-03-15", amountCents: 600 }], 1000)).toBeNull();
    expect(validateSchedule([{ label: "Acompte", dueDate: "2026-01-15", amountCents: 400 }], 1000)).toMatch(/totalise/);
    expect(validateSchedule([{ label: "", dueDate: "2026-01-15", amountCents: 1000 }], 1000)).toMatch(/libellé/);
    expect(validateSchedule([{ label: "x", dueDate: "15/01/2026", amountCents: 1000 }], 1000)).toMatch(/date/);
  });
  it("repère les échéances dépassées sans facture et la prochaine", () => {
    const s = [
      { label: "A", dueDate: "2026-01-15", amountCents: 1, invoiceId: "x" },
      { label: "B", dueDate: "2026-02-15", amountCents: 1 },
      { label: "C", dueDate: "2026-04-15", amountCents: 1 },
    ];
    expect(overdueScheduleLines(s, "2026-03-01").map((l) => l.label)).toEqual(["B"]);
    expect(nextScheduleLine(s)?.label).toBe("B");
  });
});

describe("état de financement de l'inscription", () => {
  it("dérive l'état sans tenir compte de la clôture pédagogique", () => {
    expect(deriveFundingState([])).toBe("a_definir");
    expect(deriveFundingState([{ status: "annule" }])).toBe("a_definir");
    expect(deriveFundingState([{ status: "refuse" }])).toBe("refuse");
    expect(deriveFundingState([{ status: "prevu" }, { status: "demande" }])).toBe("prevu");
    expect(deriveFundingState([{ status: "prevu" }, { status: "accorde" }])).toBe("accorde");
    expect(deriveFundingState([{ status: "accorde" }, { status: "facture" }])).toBe("facture");
    expect(deriveFundingState([{ status: "solde" }, { status: "refuse" }])).toBe("solde");
    expect(deriveFundingState([{ status: "solde" }, { status: "facture" }])).toBe("facture");
  });
});

describe("export comptable", () => {
  it("équilibre débit et crédit, inverse les avoirs", () => {
    const rows = salesJournalRows({ number: "F-2026-00001", kind: "facture", issueDate: "2026-02-01", totalHtCents: 100000, vatCents: 20000, totalTtcCents: 120000, billToName: "Société Bleue" }, DEFAULT_ACCOUNTING);
    expect(rows.reduce((a, r) => a + r.debit, 0)).toBe(rows.reduce((a, r) => a + r.credit, 0));
    expect(rows.find((r) => r.compte === "411000")?.debit).toBe(120000);
    const credit = salesJournalRows({ number: "AV-2026-00001", kind: "avoir", issueDate: "2026-02-01", totalHtCents: 100000, vatCents: 0, totalTtcCents: 100000, billToName: "X" }, DEFAULT_ACCOUNTING);
    expect(credit).toHaveLength(2);
    expect(credit.find((r) => r.compte === "411000")?.credit).toBe(100000);
  });
  it("produit un CSV point-virgule échappé", () => {
    expect(toCsv(["a", "b"], [["x;y", 'q"'], [1, null]])).toBe('a;b\r\n"x;y";"q"""\r\n1;\r\n');
  });
});

describe("montants et relevé bancaire", () => {
  it("lit les montants français", () => {
    expect(parseAmountToCents("1 250,00")).toBe(125000);
    expect(parseAmountToCents("1250.5")).toBe(125050);
    expect(parseAmountToCents("-12,34 €")).toBe(-1234);
    expect(parseAmountToCents("abc")).toBeNull();
  });
  it("parse un relevé avec en-tête et propose un rapprochement par référence puis par montant", () => {
    const csv = "Date;Libellé;Montant;Référence\n02/03/2026;VIR SEPA SOCIETE BLEUE F-2026-00001;1200,00;ABC\n03/03/2026;VIR OPCO;500,00;\n04/03/2026;PRLV EDF;-80,00;\n";
    const { rows, errors } = parseBankCsv(csv);
    expect(errors).toEqual([]);
    expect(rows).toHaveLength(3);
    expect(rows[0].date).toBe("2026-03-02");
    const props = proposeMatches(rows, [
      { id: "i1", number: "F-2026-00001", totalTtcCents: 120000, paidCents: 0, billToName: "Société Bleue" },
      { id: "i2", number: "F-2026-00002", totalTtcCents: 50000, paidCents: 0, billToName: "OPCO" },
    ]);
    expect(props[0].invoice?.id).toBe("i1");
    expect(props[0].confidence).toBe("reference");
    expect(props[1].invoice?.id).toBe("i2");
    expect(props[1].confidence).toBe("montant");
    expect(props[2].invoice).toBeNull();
  });
});
