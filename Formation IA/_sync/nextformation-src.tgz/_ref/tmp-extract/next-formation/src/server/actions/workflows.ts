"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { assertEnrollmentInScope, requireOrg } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { applyWorkflow, completeWorkflowStep } from "@/server/workflows/service";
import { WORKFLOW_CODES, workflowLabels } from "@/server/workflows/templates";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

function refresh(orgId: string, enrollmentId: string) {
  revalidatePath(`/app/${orgId}/inscriptions/${enrollmentId}`);
  revalidatePath(`/app/${orgId}/taches`);
}

/** Applique ou change le parcours de l'inscription (choix humain, ou parcours suggéré si « auto »). */
export async function applyWorkflowAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    await assertEnrollmentInScope(ctx, enrollmentId);
    const raw = z.enum([...WORKFLOW_CODES, "auto"], { message: "Parcours inconnu." }).parse(formData.get("code"));
    const r = await applyWorkflow({ orgId, userId: ctx.user.id }, enrollmentId, raw === "auto" ? null : raw);
    if (!r.applied) return { error: r.reason };
    refresh(orgId, enrollmentId);
    const parts = [`${r.created} étape(s) créée(s)`, r.reopened ? `${r.reopened} rouverte(s)` : null, r.cancelled ? `${r.cancelled} annulée(s)` : null].filter(Boolean).join(", ");
    return { ok: true, message: `Parcours « ${workflowLabels[r.code]} » appliqué : ${parts}.` };
  } catch (e) {
    return fail(e, "Le parcours n'a pas pu être appliqué.");
  }
}

/** Marque une étape du parcours faite ; un motif de dérogation est exigé si des prérequis ne sont pas faits. */
export async function completeWorkflowStepAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    await assertEnrollmentInScope(ctx, enrollmentId);
    const stepCode = z.string().trim().min(1, "Étape manquante.").max(80).regex(/^[a-z0-9_]+$/, "Étape invalide.").parse(formData.get("stepCode"));
    const note = z.string().trim().max(1000, "Note trop longue.").optional().parse(formData.get("note") ?? undefined);
    const override = z.string().trim().max(1000, "Motif trop long.").optional().parse(formData.get("override") ?? undefined);
    const r = await completeWorkflowStep(orgId, enrollmentId, stepCode, ctx.user.id, { note, override });
    refresh(orgId, enrollmentId);
    if (r.already) return { ok: true, message: `« ${r.step.label} » était déjà faite.` };
    return { ok: true, message: `« ${r.step.label} » marquée faite${r.evidenceId ? ", preuve qualité enregistrée" : ""}.` };
  } catch (e) {
    return fail(e, "L'étape n'a pas pu être marquée faite.");
  }
}
