import "server-only";
import PDFDocument from "pdfkit";
import { AlignmentType, Document, HeadingLevel, Packer, Paragraph, TextRun, ShadingType } from "docx";
import { parseMarkdown, type Inline } from "./markdown";

/** Espaces fines insécables (formatage fr-FR) non couvertes par les polices PDF standard. */
const clean = (s: string) => s.replace(/ /g, " ");

export type ExportMeta = { title: string; footer: string; legalWarning?: string | null };

/** Export PDF (pdfkit, polices standard) d'un brouillon Markdown. Les marqueurs restent visibles et surlignés. */
export async function renderPdf(markdown: string, meta: ExportMeta): Promise<Buffer> {
  const doc = new PDFDocument({ size: "A4", bufferPages: true, margins: { top: 64, bottom: 64, left: 64, right: 64 }, info: { Title: meta.title, Creator: "Next Formation" } });
  const chunks: Buffer[] = [];
  doc.on("data", (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });

  const ink = "#2b2925";
  const writeInlines = (inlines: Inline[], size: number, opts: { indent?: number } = {}) => {
    doc.fontSize(size);
    inlines.forEach((i, idx) => {
      const last = idx === inlines.length - 1;
      doc
        .font(i.bold ? "Helvetica-Bold" : "Helvetica")
        .fillColor(i.marker ? "#8a5a00" : ink)
        .text(clean(i.text), { continued: !last, lineGap: 2.5, indent: opts.indent, ...(i.marker ? { underline: true } : { underline: false }) });
    });
    doc.fillColor(ink);
  };

  if (meta.legalWarning) {
    doc.font("Helvetica-Bold").fontSize(8.5).fillColor("#8a5a00").text(clean(meta.legalWarning), { lineGap: 1.5 });
    doc.moveDown(1);
    doc.fillColor(ink);
  }

  for (const b of parseMarkdown(markdown)) {
    if (b.type === "heading") {
      doc.moveDown(b.level === 1 ? 0.2 : 0.6);
      writeInlines(b.inlines.map((i) => ({ ...i, bold: true })), b.level === 1 ? 15 : b.level === 2 ? 11.5 : 10.5);
      doc.moveDown(0.4);
    } else if (b.type === "paragraph") {
      writeInlines(b.inlines, 10);
      doc.moveDown(0.6);
    } else if (b.type === "list") {
      for (const item of b.items) {
        writeInlines([{ text: "-  " }, ...item], 10, { indent: 8 });
      }
      doc.moveDown(0.6);
    } else {
      const y = doc.y + 4;
      doc.moveTo(64, y).lineTo(doc.page.width - 64, y).strokeColor("#d6d2c8").lineWidth(0.6).stroke();
      doc.moveDown(1);
    }
  }

  const range = doc.bufferedPageRange();
  for (let p = range.start; p < range.start + range.count; p++) {
    doc.switchToPage(p);
    // Écrire sous la marge basse sans déclencher l'ajout automatique d'une page.
    const bottom = doc.page.margins.bottom;
    doc.page.margins.bottom = 0;
    doc.font("Helvetica").fontSize(7.5).fillColor("#7a766d");
    doc.text(clean(`${meta.footer}, page ${p + 1} sur ${range.count}`), 64, doc.page.height - 44, { width: doc.page.width - 128, align: "center", lineBreak: false });
    doc.page.margins.bottom = bottom;
  }
  doc.end();
  return done;
}

const runs = (inlines: Inline[]) =>
  inlines.flatMap((i) =>
    i.text.split("\n").map(
      (part, idx) =>
        new TextRun({
          text: part,
          bold: i.bold,
          ...(idx > 0 ? { break: 1 } : {}),
          ...(i.marker ? { highlight: "yellow", color: "7A4F00" } : {}),
        }),
    ),
  );

/** Export DOCX (package `docx`), modifiable dans un traitement de texte. */
export async function renderDocx(markdown: string, meta: ExportMeta): Promise<Buffer> {
  const children: Paragraph[] = [];
  if (meta.legalWarning) {
    children.push(
      new Paragraph({
        children: [new TextRun({ text: meta.legalWarning, bold: true, color: "7A4F00", size: 18 })],
        shading: { type: ShadingType.CLEAR, color: "auto", fill: "FBF1DC" },
        spacing: { after: 240 },
      }),
    );
  }
  for (const b of parseMarkdown(markdown)) {
    if (b.type === "heading") {
      children.push(
        new Paragraph({
          heading: b.level === 1 ? HeadingLevel.HEADING_1 : b.level === 2 ? HeadingLevel.HEADING_2 : HeadingLevel.HEADING_3,
          children: runs(b.inlines),
          spacing: { before: 200, after: 120 },
        }),
      );
    } else if (b.type === "paragraph") {
      children.push(new Paragraph({ children: runs(b.inlines), spacing: { after: 160 }, alignment: AlignmentType.LEFT }));
    } else if (b.type === "list") {
      for (const item of b.items) children.push(new Paragraph({ bullet: { level: 0 }, children: runs(item) }));
    } else {
      children.push(new Paragraph({ border: { bottom: { style: "single", size: 6, color: "D6D2C8", space: 1 } }, children: [] }));
    }
  }
  const doc = new Document({
    creator: "Next Formation",
    title: meta.title,
    styles: { default: { document: { run: { font: "Calibri", size: 21 } } } },
    sections: [{ children }],
  });
  return Packer.toBuffer(doc);
}
