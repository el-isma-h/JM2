import "server-only";
import { NextResponse } from "next/server";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { issueDownloadLink } from "@/server/documents/store";
import { appUrl } from "@/lib/env";
import { findVisibleDocument } from "./queries";

type Scope = Parameters<typeof findVisibleDocument>[2];
type Visibilities = Parameters<typeof findVisibleDocument>[3];

/**
 * Téléchargement depuis un extranet : recharge le document dans le périmètre du contexte (jamais l'identifiant seul),
 * émet un lien temporaire lié à l'utilisateur et redirige vers /telechargement/[token].
 */
export async function extranetDownload<C extends { org: { id: string }; user: { id: string } }>(
  load: () => Promise<C | null>,
  scopeOf: (ctx: C) => { scope: Scope; visibilities: Visibilities },
  documentId: string,
  nextPath: string,
): Promise<Response> {
  let ctx: C | null;
  try {
    ctx = await load();
  } catch (e) {
    if (e instanceof AuthError && e.code === "unauthenticated") return NextResponse.redirect(new URL(`/connexion?next=${encodeURIComponent(nextPath)}`, appUrl()));
    return new NextResponse("Accès refusé.", { status: 403 });
  }
  if (!ctx) return new NextResponse("Aucun rattachement.", { status: 403 });
  if (!/^[0-9a-f-]{36}$/i.test(documentId)) return new NextResponse("Document introuvable.", { status: 404 });
  const { scope, visibilities } = scopeOf(ctx);
  const doc = await findVisibleDocument(ctx.org.id, documentId, scope, visibilities);
  if (!doc) return new NextResponse("Document introuvable dans votre espace.", { status: 404 });
  await audit({ action: "document.extranet_download", userId: ctx.user.id, orgId: ctx.org.id, entityType: "document", entityId: doc.id });
  const link = await issueDownloadLink(doc.id, ctx.user.id);
  return NextResponse.redirect(link, { status: 303 });
}
