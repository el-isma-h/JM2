import "server-only";
import { and, eq, inArray, isNotNull, isNull, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { appUrl } from "@/lib/env";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { todayParis } from "@/lib/time";
import { audit } from "@/server/audit";
import { notify } from "@/server/notify";
import { layoutMail, sendMail } from "@/server/mail";
import { brandFromOrg, orgAddress } from "@/server/documents/brand";
import { renderBrandedPdf } from "@/server/documents/pdf";
import { createDocument } from "@/server/documents/store";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { registerJobHandler } from "@/server/jobs/registry";
import { MISSION_FIRST_LESSON_WORKDAYS, MISSION_GRACE_WORKDAYS, MISSION_REMINDER_WORKDAYS, missionAmountCents, reminderStep, workdaysElapsed } from "./rules";

/**
 * Missions formateurs (process « Mobilisation du formateur » de la cliente) :
 *  1. proposition de mission par e-mail (thème, apprenant, dates, heures en visio / avec formateur, rémunération) ;
 *  2. réponse du formateur (acceptation ou refus), depuis l'espace formateur ou saisie par l'organisme ;
 *  3. relance après 5 jours ouvrés, puis « sans réponse » et tâche « Trouver un remplaçant » ;
 *  4. remplacement : nouvelle mission pour un autre formateur, liée par replacedByMissionId, et information du premier ;
 *  5. contrat de prestation PDF (charte de l'organisme), champs manquants en [À COMPLÉTER : …], puis envoi.
 * Les autorisations (planning.manage, périmètre formateur) sont vérifiées par l'appelant (server actions).
 */

type OrgRow = typeof schema.organismes.$inferSelect;
type Mission = typeof schema.trainerMissions.$inferSelect;
type Trainer = typeof schema.trainers.$inferSelect;
type MissionStatus = (typeof schema.missionStatusEnum.enumValues)[number];

export type MissionActor = { org: OrgRow; userId: string | null };

export class MissionError extends Error {}

const OPEN_FOR_RESPONSE: MissionStatus[] = ["proposee", "sans_reponse"];
const REPLACEABLE: MissionStatus[] = ["proposee", "sans_reponse", "refusee"];

export const missionTaskKeys = {
  replacement: (missionId: string) => `mission:${missionId}:remplacant`,
  contract: (missionId: string) => `mission:${missionId}:contrat`,
  firstLesson: (missionId: string) => `mission:${missionId}:premier_cours`,
};

function esc(s: string | null | undefined) {
  return (s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
const orgName = (o: OrgRow) => o.tradeName ?? o.legalName;
const trainerName = (t: Pick<Trainer, "firstName" | "lastName">) => `${t.firstName} ${t.lastName}`.trim();
const missionsHref = (orgId: string, q = "") => `/app/${orgId}/formateurs/missions${q}`;

/* ------------------------------------------------------------------ */
/* Chargements                                                         */
/* ------------------------------------------------------------------ */

export async function loadMission(orgId: string, missionId: string): Promise<Mission> {
  const [m] = await db.select().from(schema.trainerMissions).where(and(eq(schema.trainerMissions.id, missionId), eq(schema.trainerMissions.orgId, orgId))).limit(1);
  if (!m) throw new MissionError("Mission introuvable dans cet organisme.");
  return m;
}

async function loadTrainer(orgId: string, trainerId: string): Promise<Trainer> {
  const [t] = await db.select().from(schema.trainers).where(and(eq(schema.trainers.id, trainerId), eq(schema.trainers.orgId, orgId))).limit(1);
  if (!t) throw new MissionError("Formateur introuvable dans cet organisme.");
  return t;
}

/** Contexte lisible d'une mission : session, inscription et apprenant (tous filtrés par organisme). */
async function missionContext(orgId: string, m: Pick<Mission, "sessionId" | "enrollmentId">) {
  const [session] = m.sessionId
    ? await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, m.sessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1)
    : [];
  const [enr] = m.enrollmentId
    ? await db
        .select({ e: schema.enrollments, firstName: schema.persons.firstName, lastName: schema.persons.lastName })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .where(and(eq(schema.enrollments.id, m.enrollmentId), eq(schema.enrollments.orgId, orgId)))
        .limit(1)
    : [];
  return { session: session ?? null, enrollment: enr?.e ?? null, learnerName: enr ? `${enr.firstName} ${enr.lastName}` : null };
}

/* ------------------------------------------------------------------ */
/* E-mails                                                             */
/* ------------------------------------------------------------------ */

async function sendProposalMail(actor: MissionActor, m: Mission, t: Trainer, opts: { reminder?: boolean } = {}) {
  if (!t.email) return { status: "no_email" as const };
  const c = await missionContext(actor.org.id, m);
  const rows = [
    ["Thème", m.theme],
    c.learnerName ? ["Apprenant", c.learnerName] : null,
    c.session ? ["Session", `${c.session.title} (${c.session.code})`] : null,
    ["Dates", m.startDate ? `du ${fmtDate(m.startDate)} au ${fmtDate(m.endDate ?? m.startDate)}` : "à convenir"],
    ["Durée", `${m.hours} h avec formateur (visio ou présentiel)`],
    m.location ? ["Lieu", m.location] : null,
    ["Rémunération", `${m.hours} h × ${formatCents(m.hourlyRateCents)} HT = ${formatCents(m.amountCents)} HT`],
  ].filter(Boolean) as [string, string][];
  const list = `<ul>${rows.map(([k, v]) => `<li><strong>${esc(k)} :</strong> ${esc(v)}</li>`).join("")}</ul>`;
  const intro = opts.reminder
    ? `<p>Bonjour ${esc(t.firstName)},</p><p>Nous revenons vers vous au sujet de la mission proposée le ${esc(fmtDate(m.proposedAt))}, restée sans réponse. Pouvez-vous nous indiquer si vous l'acceptez ?</p>`
    : `<p>Bonjour ${esc(t.firstName)},</p><p>${esc(orgName(actor.org))} vous propose la mission de formation suivante :</p>`;
  const how = t.userId
    ? `<p>Vous pouvez l'accepter ou la refuser depuis votre espace formateur. Une fois acceptée, merci de nous indiquer la date du premier cours et le planning prévisionnel.</p>`
    : `<p>Merci de nous faire part de votre réponse${actor.org.email ? ` à ${esc(actor.org.email)}` : ""}. Une fois acceptée, merci de nous indiquer la date du premier cours et le planning prévisionnel.</p>`;
  const subject = `${opts.reminder ? "Relance : " : ""}Proposition de mission : ${m.theme}`;
  const res = await sendMail({
    to: t.email,
    subject,
    html: layoutMail(opts.reminder ? "Relance : proposition de mission" : "Proposition de mission", intro + list + how, t.userId ? { label: "Répondre à la proposition", url: `${appUrl()}/formateur/missions` } : undefined),
    text: rows.map(([k, v]) => `${k} : ${v}`).join("\n"),
    isDemo: actor.org.isDemo,
  });
  return { status: res.status };
}

async function sendReplacedMail(actor: MissionActor, m: Mission, t: Trainer) {
  if (!t.email) return { status: "no_email" as const };
  const html = `<p>Bonjour ${esc(t.firstName)},</p><p>En l'absence de retour de votre part sur la mission « ${esc(m.theme)} » proposée le ${esc(fmtDate(m.proposedAt))}, nous avons mobilisé un autre formateur.</p><p>Merci de votre disponibilité ; nous ne manquerons pas de revenir vers vous pour une prochaine mission.</p>`;
  const res = await sendMail({ to: t.email, subject: `Mission « ${m.theme} » : formateur remplacé`, html: layoutMail("Mission attribuée à un autre formateur", html), text: `La mission « ${m.theme} » a été attribuée à un autre formateur en l'absence de retour.`, isDemo: actor.org.isDemo });
  return { status: res.status };
}

/* ------------------------------------------------------------------ */
/* Proposition                                                         */
/* ------------------------------------------------------------------ */

export type ProposeMissionInput = {
  trainerId: string;
  sessionId?: string | null;
  enrollmentId?: string | null;
  theme: string;
  startDate?: string | null;
  endDate?: string | null;
  hours: number;
  hourlyRateCents: number;
  location?: string | null;
  notes?: string | null;
};

/** Valide formateur, session et inscription dans l'organisme ; déduit la session de l'inscription si besoin. */
async function validateTargets(orgId: string, input: Pick<ProposeMissionInput, "trainerId" | "sessionId" | "enrollmentId" | "startDate" | "endDate">) {
  const trainer = await loadTrainer(orgId, input.trainerId);
  if (!trainer.isActive) throw new MissionError("Ce formateur est inactif : réactivez sa fiche avant de lui proposer une mission.");
  let sessionId = input.sessionId ?? null;
  if (input.enrollmentId) {
    const [e] = await db.select({ id: schema.enrollments.id, sessionId: schema.enrollments.sessionId, status: schema.enrollments.status }).from(schema.enrollments).where(and(eq(schema.enrollments.id, input.enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
    if (!e) throw new MissionError("Inscription introuvable dans cet organisme.");
    if (e.status === "annule" || e.status === "abandon") throw new MissionError("Cette inscription est annulée ou interrompue.");
    if (sessionId && sessionId !== e.sessionId) throw new MissionError("L'inscription choisie n'appartient pas à la session choisie.");
    sessionId = e.sessionId;
  }
  if (sessionId) {
    const [s] = await db.select({ id: schema.trainingSessions.id, status: schema.trainingSessions.status }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, sessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
    if (!s) throw new MissionError("Session introuvable dans cet organisme.");
    if (s.status === "annulee") throw new MissionError("Cette session est annulée.");
  }
  if (input.startDate && input.endDate && input.endDate < input.startDate) throw new MissionError("La date de fin précède la date de début.");
  return { trainer, sessionId };
}

/** Crée la mission (montant = heures × taux) et envoie la proposition au formateur. */
export async function proposeMission(actor: MissionActor, input: ProposeMissionInput) {
  const { trainer, sessionId } = await validateTargets(actor.org.id, input);
  const amountCents = missionAmountCents(input.hours, input.hourlyRateCents);
  const [m] = await db
    .insert(schema.trainerMissions)
    .values({
      orgId: actor.org.id,
      trainerId: trainer.id,
      sessionId,
      enrollmentId: input.enrollmentId ?? null,
      theme: input.theme,
      startDate: input.startDate ?? null,
      endDate: input.endDate ?? input.startDate ?? null,
      hours: input.hours,
      hourlyRateCents: input.hourlyRateCents,
      amountCents,
      location: input.location ?? null,
      notes: input.notes ?? null,
      status: "proposee",
      createdBy: actor.userId,
    })
    .returning();
  const mail = await sendProposalMail(actor, m, trainer);
  await audit({ action: "mission.propose", userId: actor.userId, orgId: actor.org.id, entityType: "trainer_mission", entityId: m.id, after: { trainerId: trainer.id, sessionId, enrollmentId: m.enrollmentId, hours: m.hours, hourlyRateCents: m.hourlyRateCents, amountCents, mail: mail.status } });
  return { mission: m, trainer, mail };
}

/* ------------------------------------------------------------------ */
/* Réponse                                                             */
/* ------------------------------------------------------------------ */

async function assigneeFor(orgId: string, m: Mission) {
  if (m.createdBy) return { assigneeUserId: m.createdBy, assigneeRole: null };
  if (m.sessionId) {
    const [s] = await db.select({ u: schema.trainingSessions.adminManagerUserId, p: schema.trainingSessions.pedagogyManagerUserId }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, m.sessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
    if (s?.p || s?.u) return { assigneeUserId: (s.p ?? s.u)!, assigneeRole: null };
  }
  return { assigneeUserId: null, assigneeRole: "pedagogy_manager" };
}

async function createReplacementTask(actor: MissionActor, m: Mission, t: Trainer, cause: "refusee" | "sans_reponse") {
  const who = await assigneeFor(actor.org.id, m);
  return createTaskOnce({
    orgId: actor.org.id,
    title: `Trouver un remplaçant : ${m.theme}`,
    description: `${trainerName(t)} ${cause === "refusee" ? "a refusé la mission" : "n'a pas répondu à la proposition de mission"} (proposée le ${fmtDate(m.proposedAt)}). Mobilisez un autre formateur depuis la liste des missions (« Remplacer »).`,
    family: "pedagogie",
    entityType: "trainer_mission",
    entityId: m.id,
    entityLabel: `${m.theme} · ${trainerName(t)}`,
    href: missionsHref(actor.org.id, `?statut=${cause}`),
    ...who,
    dueDate: todayParis(),
    priority: "haute",
    isDemo: actor.org.isDemo,
    idempotencyKey: missionTaskKeys.replacement(m.id),
  });
}

/**
 * Acceptation ou refus d'une mission proposée (ou passée « sans réponse » mais pas encore remplacée).
 * `asTrainerId` : réponse donnée par le formateur lui-même (extranet) ; elle doit porter sur SA mission.
 */
export async function respondMission(actor: MissionActor, input: { missionId: string; decision: "acceptee" | "refusee"; firstLessonDate?: string | null; note?: string | null; asTrainerId?: string | null }) {
  const before = await loadMission(actor.org.id, input.missionId);
  if (input.asTrainerId && before.trainerId !== input.asTrainerId) throw new MissionError("Cette mission ne vous est pas adressée.");
  if (!OPEN_FOR_RESPONSE.includes(before.status) || before.replacedByMissionId) throw new MissionError("Cette mission n'attend plus de réponse (déjà traitée ou remplacée).");
  const noteLine = input.note ? `${input.asTrainerId ? "Réponse du formateur" : "Réponse saisie"} (${todayParis()}) : ${input.note}` : null;
  const [m] = await db
    .update(schema.trainerMissions)
    .set({
      status: input.decision,
      respondedAt: new Date(),
      firstLessonDate: input.decision === "acceptee" ? (input.firstLessonDate ?? before.firstLessonDate) : before.firstLessonDate,
      notes: noteLine ? [before.notes, noteLine].filter(Boolean).join("\n") : before.notes,
      updatedAt: new Date(),
    })
    .where(and(eq(schema.trainerMissions.id, before.id), eq(schema.trainerMissions.orgId, actor.org.id), inArray(schema.trainerMissions.status, OPEN_FOR_RESPONSE), isNull(schema.trainerMissions.replacedByMissionId)))
    .returning();
  if (!m) throw new MissionError("Cette mission vient d'être traitée par ailleurs.");
  const t = await loadTrainer(actor.org.id, m.trainerId);
  if (m.status === "acceptee") {
    await resolveTaskByKey(actor.org.id, missionTaskKeys.replacement(m.id), "Mission acceptée par le formateur.", actor.userId);
    const who = await assigneeFor(actor.org.id, m);
    await createTaskOnce({
      orgId: actor.org.id,
      title: `Envoyer le contrat de prestation : ${trainerName(t)}`,
      description: `Mission « ${m.theme} » acceptée. Vérifiez dates, durée et rémunération, générez le contrat puis envoyez-le au formateur.`,
      family: "pedagogie",
      entityType: "trainer_mission",
      entityId: m.id,
      entityLabel: `${m.theme} · ${trainerName(t)}`,
      href: missionsHref(actor.org.id, "?statut=acceptee"),
      ...who,
      dueDate: todayParis(),
      isDemo: actor.org.isDemo,
      idempotencyKey: missionTaskKeys.contract(m.id),
    });
  } else {
    await createReplacementTask(actor, m, t, "refusee");
  }
  if (m.createdBy && m.createdBy !== actor.userId) {
    await notify({ orgId: actor.org.id, userId: m.createdBy, title: `${trainerName(t)} a ${m.status === "acceptee" ? "accepté" : "refusé"} la mission « ${m.theme} »`, href: missionsHref(actor.org.id), kind: "mission", dedupeKey: `mission:${m.id}:reponse` });
  }
  await audit({ action: "mission.respond", userId: actor.userId, orgId: actor.org.id, entityType: "trainer_mission", entityId: m.id, before: { status: before.status }, after: { status: m.status, byTrainer: Boolean(input.asTrainerId), firstLessonDate: m.firstLessonDate } });
  return m;
}

/** Date du premier cours (retour du formateur) : résout la tâche de suivi correspondante. */
export async function setMissionFirstLesson(actor: MissionActor, input: { missionId: string; firstLessonDate: string; asTrainerId?: string | null }) {
  const before = await loadMission(actor.org.id, input.missionId);
  if (input.asTrainerId && before.trainerId !== input.asTrainerId) throw new MissionError("Cette mission ne vous est pas adressée.");
  if (before.status !== "acceptee") throw new MissionError("La date du premier cours se renseigne sur une mission acceptée.");
  const [m] = await db.update(schema.trainerMissions).set({ firstLessonDate: input.firstLessonDate, updatedAt: new Date() }).where(and(eq(schema.trainerMissions.id, before.id), eq(schema.trainerMissions.orgId, actor.org.id))).returning();
  await resolveTaskByKey(actor.org.id, missionTaskKeys.firstLesson(m.id), `Premier cours prévu le ${fmtDate(input.firstLessonDate)}.`, actor.userId);
  await audit({ action: "mission.first_lesson", userId: actor.userId, orgId: actor.org.id, entityType: "trainer_mission", entityId: m.id, before: { firstLessonDate: before.firstLessonDate }, after: { firstLessonDate: m.firstLessonDate } });
  return m;
}

/* ------------------------------------------------------------------ */
/* Remplacement                                                        */
/* ------------------------------------------------------------------ */

/**
 * Remplace une mission refusée ou restée sans réponse : l'ancienne passe en `refusee` ou `sans_reponse`,
 * une nouvelle mission est proposée à un autre formateur, les deux sont liées par replacedByMissionId.
 * Le premier formateur est informé s'il n'avait pas répondu (process de la cliente).
 */
export async function replaceMission(actor: MissionActor, input: { missionId: string; newTrainerId: string; reason: "refusee" | "sans_reponse"; hourlyRateCents: number; hours?: number | null; startDate?: string | null; endDate?: string | null }) {
  const old = await loadMission(actor.org.id, input.missionId);
  if (old.trainerId === input.newTrainerId) throw new MissionError("Choisissez un autre formateur que celui de la mission initiale.");
  const { trainer: newTrainer } = await validateTargets(actor.org.id, { trainerId: input.newTrainerId, sessionId: old.sessionId, enrollmentId: old.enrollmentId, startDate: input.startDate ?? old.startDate, endDate: input.endDate ?? old.endDate });
  const hours = input.hours ?? old.hours;
  const amountCents = missionAmountCents(hours, input.hourlyRateCents);

  const { previous, created } = await db.transaction(async (tx) => {
    const [locked] = await tx.select().from(schema.trainerMissions).where(and(eq(schema.trainerMissions.id, old.id), eq(schema.trainerMissions.orgId, actor.org.id))).for("update").limit(1);
    if (!locked || locked.replacedByMissionId) throw new MissionError("Cette mission a déjà été remplacée.");
    if (!REPLACEABLE.includes(locked.status)) throw new MissionError("Seule une mission proposée, refusée ou sans réponse peut être remplacée.");
    const [n] = await tx
      .insert(schema.trainerMissions)
      .values({
        orgId: actor.org.id,
        trainerId: newTrainer.id,
        sessionId: locked.sessionId,
        enrollmentId: locked.enrollmentId,
        theme: locked.theme,
        startDate: input.startDate ?? locked.startDate,
        endDate: input.endDate ?? locked.endDate,
        hours,
        hourlyRateCents: input.hourlyRateCents,
        amountCents,
        location: locked.location,
        notes: `Remplace la mission proposée à un autre formateur le ${fmtDate(locked.proposedAt)}.`,
        status: "proposee",
        createdBy: actor.userId,
      })
      .returning();
    const nextStatus: MissionStatus = locked.status === "refusee" ? "refusee" : input.reason;
    await tx
      .update(schema.trainerMissions)
      .set({ status: nextStatus, replacedByMissionId: n.id, respondedAt: nextStatus === "refusee" ? (locked.respondedAt ?? new Date()) : locked.respondedAt, updatedAt: new Date() })
      .where(eq(schema.trainerMissions.id, locked.id));
    return { previous: locked, created: n };
  });

  const oldTrainer = await loadTrainer(actor.org.id, previous.trainerId);
  const informed = previous.status !== "refusee" ? await sendReplacedMail(actor, previous, oldTrainer) : { status: "not_needed" as const };
  const mail = await sendProposalMail(actor, created, newTrainer);
  await resolveTaskByKey(actor.org.id, missionTaskKeys.replacement(previous.id), `Remplacé par ${trainerName(newTrainer)}.`, actor.userId);
  await audit({ action: "mission.replace", userId: actor.userId, orgId: actor.org.id, entityType: "trainer_mission", entityId: previous.id, before: { status: previous.status, trainerId: previous.trainerId }, after: { replacedByMissionId: created.id, newTrainerId: newTrainer.id, amountCents, mail: mail.status, informed: informed.status } });
  return { mission: created, trainer: newTrainer, mail, informed };
}

/* ------------------------------------------------------------------ */
/* Clôture                                                             */
/* ------------------------------------------------------------------ */

export async function closeMission(actor: MissionActor, input: { missionId: string; status: "annulee" | "terminee"; reason?: string | null }) {
  const before = await loadMission(actor.org.id, input.missionId);
  if (input.status === "terminee" && before.status !== "acceptee") throw new MissionError("Seule une mission acceptée peut être marquée terminée.");
  if (input.status === "annulee" && !["proposee", "acceptee", "sans_reponse"].includes(before.status)) throw new MissionError("Cette mission ne peut plus être annulée.");
  const noteLine = input.reason ? `${input.status === "annulee" ? "Annulation" : "Fin"} (${todayParis()}) : ${input.reason}` : null;
  const [m] = await db
    .update(schema.trainerMissions)
    .set({ status: input.status, notes: noteLine ? [before.notes, noteLine].filter(Boolean).join("\n") : before.notes, updatedAt: new Date() })
    .where(and(eq(schema.trainerMissions.id, before.id), eq(schema.trainerMissions.orgId, actor.org.id), eq(schema.trainerMissions.status, before.status)))
    .returning();
  if (!m) throw new MissionError("Cette mission vient d'être modifiée par ailleurs.");
  const note = input.status === "annulee" ? "Mission annulée." : "Mission terminée.";
  await resolveTaskByKey(actor.org.id, missionTaskKeys.replacement(m.id), note, actor.userId);
  await resolveTaskByKey(actor.org.id, missionTaskKeys.firstLesson(m.id), note, actor.userId);
  if (input.status === "annulee") await resolveTaskByKey(actor.org.id, missionTaskKeys.contract(m.id), note, actor.userId);
  await audit({ action: "mission.close", userId: actor.userId, orgId: actor.org.id, entityType: "trainer_mission", entityId: m.id, before: { status: before.status }, after: { status: m.status, reason: input.reason ?? null } });
  return m;
}

/* ------------------------------------------------------------------ */
/* Contrat de prestation                                               */
/* ------------------------------------------------------------------ */

const todo = (label: string) => `[À COMPLÉTER : ${label}]`;
const orTodo = (v: string | null | undefined, label: string) => (v && v.trim() ? v.trim() : todo(label));

/** Markdown du contrat de prestation : uniquement des données réelles, sinon un marqueur visible. */
export function buildMissionContractMarkdown(input: { org: OrgRow; trainer: Trainer; mission: Mission; sessionLabel: string | null; learnerName: string | null; today: string }) {
  const { org, trainer: t, mission: m } = input;
  const addr = orgAddress(org);
  const prestataire = [
    `**${[t.civility, t.firstName, t.lastName].filter(Boolean).join(" ")}**`,
    t.companyName ? `agissant pour ${t.companyName}` : null,
    `SIRET ${orTodo(t.siret, "SIRET du prestataire")}`,
    t.nda ? `déclaration d'activité n° ${t.nda}` : null,
    `domicilié(e) ${todo("adresse du prestataire")}`,
    t.email ? `e-mail ${t.email}` : null,
  ].filter(Boolean);
  const md = [
    "# Contrat de prestation de formation",
    "",
    `Mission du ${fmtDate(m.proposedAt)}, contrat établi le ${fmtDate(input.today)}.`,
    "",
    "## Entre les soussignés",
    "",
    `**${org.legalName}**${org.tradeName && org.tradeName !== org.legalName ? ` (${org.tradeName})` : ""}, SIRET ${orTodo(org.siret, "SIRET de l'organisme")}, déclaration d'activité n° ${orTodo(org.nda, "NDA de l'organisme")}, dont le siège est situé ${orTodo(addr, "adresse de l'organisme")}, représenté par ${orTodo(org.signatoryName, "nom du signataire")}, ${orTodo(org.signatoryTitle, "qualité du signataire")}, ci-après « l'organisme de formation »,`,
    "",
    "et",
    "",
    `${prestataire.join(", ")}, ci-après « le prestataire ».`,
    "",
    "## Article 1 : objet",
    "",
    "L'organisme de formation confie au prestataire, qui l'accepte, la réalisation de l'action de formation suivante :",
    "",
    `- Thème : ${m.theme}`,
    input.sessionLabel ? `- Session : ${input.sessionLabel}` : null,
    input.learnerName ? `- Apprenant : ${input.learnerName}` : null,
    `- Lieu ou modalité : ${orTodo(m.location, "lieu ou modalité (visio, présentiel)")}`,
    "",
    "## Article 2 : dates et durée",
    "",
    `- Période : du ${m.startDate ? fmtDate(m.startDate) : todo("date de début")} au ${m.endDate ? fmtDate(m.endDate) : todo("date de fin")}`,
    `- Durée : ${m.hours} heures avec formateur (visio ou présentiel)`,
    `- Date du premier cours : ${m.firstLessonDate ? fmtDate(m.firstLessonDate) : todo("date du premier cours")}`,
    "- Le prestataire transmet à l'organisme le planning prévisionnel des cours.",
    "",
    "## Article 3 : rémunération",
    "",
    `- Taux horaire : ${formatCents(m.hourlyRateCents)} HT`,
    `- Nombre d'heures : ${m.hours}`,
    `- Rémunération totale prévue : **${formatCents(m.amountCents)} HT**`,
    `- Régime de TVA du prestataire : ${todo("régime de TVA")}`,
    `- Modalités de facturation et de paiement : ${todo("modalités de facturation et délai de paiement")}`,
    "",
    "## Article 4 : engagements du prestataire",
    "",
    "- Réaliser la formation conformément au programme et aux objectifs communiqués par l'organisme.",
    "- Faire émarger les apprenants à chaque période et signaler sans délai toute absence.",
    "- Transmettre le bilan pédagogique en fin de formation.",
    "- Respecter la confidentialité des informations relatives aux apprenants.",
    "",
    "## Article 5 : engagements de l'organisme",
    "",
    "- Communiquer au prestataire les informations utiles (programme, entretien d'accueil de l'apprenant, modalités pratiques).",
    "- Régler la rémunération prévue à l'article 3 selon les modalités convenues.",
    "",
    "## Article 6 : annulation et report",
    "",
    todo("conditions d'annulation ou de report"),
    "",
    "## Signatures",
    "",
    `Fait à ${orTodo(org.city, "lieu de signature")}, le ${fmtDate(input.today)}, en deux exemplaires.`,
    "",
    `Pour l'organisme de formation : ${orTodo(org.signatoryName, "nom du signataire")}`,
    "",
    `Le prestataire : ${trainerName(t)}`,
    "",
    "***",
    "",
    "Document généré, non signé.",
  ].filter((l) => l !== null) as string[];
  const text = md.join("\n");
  const missing = [...new Set([...text.matchAll(/\[À COMPLÉTER : ([^\]]+)\]/g)].map((x) => x[1]))];
  return { markdown: text, missing };
}

/** Génère le contrat de prestation PDF (nouvelle version si un contrat existe ; jamais par-dessus un contrat signé). */
export async function generateMissionContract(actor: MissionActor, missionId: string) {
  const m = await loadMission(actor.org.id, missionId);
  if (m.status !== "acceptee" && m.status !== "terminee") throw new MissionError("Le contrat se génère pour une mission acceptée.");
  let previousVersionId: string | null = null;
  if (m.contractDocumentId) {
    const [prev] = await db.select({ id: schema.documents.id, status: schema.documents.status }).from(schema.documents).where(and(eq(schema.documents.id, m.contractDocumentId), eq(schema.documents.orgId, actor.org.id))).limit(1);
    if (prev && (prev.status === "signe" || prev.status === "valide")) throw new MissionError("Le contrat de cette mission est signé : il ne peut pas être régénéré.");
    previousVersionId = prev?.id ?? null;
  }
  const t = await loadTrainer(actor.org.id, m.trainerId);
  const c = await missionContext(actor.org.id, m);
  const today = todayParis();
  const { markdown, missing } = buildMissionContractMarkdown({ org: actor.org, trainer: t, mission: m, sessionLabel: c.session ? `${c.session.title} (${c.session.code})` : null, learnerName: c.learnerName, today });
  const title = `Contrat de prestation : ${trainerName(t)}, ${m.theme}`;
  const pdf = await renderBrandedPdf(markdown, { title, brand: await brandFromOrg(actor.org), reference: `mission ${m.id.slice(0, 8)}` });
  const safe = `${t.lastName}-${m.theme}`.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60).toLowerCase();
  const doc = await createDocument({
    orgId: actor.org.id,
    // Rattaché à la fiche formateur (donc visible dans son espace) seulement à l'envoi : un contrat non vérifié n'est jamais exposé.
    trainerId: null,
    sessionId: m.sessionId,
    category: "contrat",
    // « interne » : visible du formateur (Mes documents) et téléchargeable par l'équipe pédagogique sans droit « pièces administratives ».
    visibility: "interne",
    status: "genere",
    templateCode: "contrat_prestation_formateur",
    generationData: { missionId: m.id, hours: m.hours, hourlyRateCents: m.hourlyRateCents, amountCents: m.amountCents, missing },
    title,
    fileName: `contrat-prestation-${safe || "mission"}.pdf`,
    mimeType: "application/pdf",
    data: pdf,
    sourceType: "trainer_mission",
    sourceId: m.id,
    previousVersionId,
    uploadedBy: actor.userId,
    isDemo: actor.org.isDemo,
  });
  await db.update(schema.trainerMissions).set({ contractDocumentId: doc.id, updatedAt: new Date() }).where(and(eq(schema.trainerMissions.id, m.id), eq(schema.trainerMissions.orgId, actor.org.id)));
  await audit({ action: "document.generate", userId: actor.userId, orgId: actor.org.id, entityType: "document", entityId: doc.id, after: { category: "contrat", missionId: m.id, version: doc.version, missing: missing.length } });
  return { document: doc, missing };
}

/** Transmet le contrat au formateur (e-mail avec lien vers son espace) et le passe « transmis ». */
export async function sendMissionContract(actor: MissionActor, missionId: string) {
  const m = await loadMission(actor.org.id, missionId);
  if (!m.contractDocumentId) throw new MissionError("Générez d'abord le contrat de prestation.");
  const [doc] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, m.contractDocumentId), eq(schema.documents.orgId, actor.org.id))).limit(1);
  if (!doc) throw new MissionError("Contrat introuvable : régénérez-le.");
  const t = await loadTrainer(actor.org.id, m.trainerId);
  if (!t.email) throw new MissionError("Ce formateur n'a pas d'adresse e-mail : complétez sa fiche.");
  const missing = Array.isArray((doc.generationData as { missing?: unknown } | null)?.missing) ? ((doc.generationData as { missing: string[] }).missing) : [];
  // Les champs [À COMPLÉTER] sont visibles dans le PDF ; l'envoi exige une confirmation explicite (case à cocher côté écran).
  const html = `<p>Bonjour ${esc(t.firstName)},</p><p>Vous trouverez votre contrat de prestation pour la mission « ${esc(m.theme)} » (${m.hours} h, ${esc(formatCents(m.amountCents))} HT).</p>${t.userId ? "<p>Il est disponible dans votre espace formateur, rubrique Mes documents.</p>" : `<p>Le document vous sera remis par ${esc(orgName(actor.org))}.</p>`}`;
  const res = await sendMail({ to: t.email, subject: `Contrat de prestation : ${m.theme}`, html: layoutMail("Votre contrat de prestation", html, t.userId ? { label: "Ouvrir mes documents", url: `${appUrl()}/formateur/documents` } : undefined), text: `Contrat de prestation : ${m.theme}`, isDemo: actor.org.isDemo });
  await db
    .update(schema.documents)
    .set({ trainerId: t.id, ...(doc.status === "genere" || doc.status === "brouillon" ? { status: "transmis" as const } : {}), updatedAt: new Date() })
    .where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, actor.org.id)));
  await resolveTaskByKey(actor.org.id, missionTaskKeys.contract(m.id), "Contrat transmis au formateur.", actor.userId);
  await audit({ action: "mission.contract_send", userId: actor.userId, orgId: actor.org.id, entityType: "trainer_mission", entityId: m.id, after: { documentId: doc.id, mail: res.status } });
  return { mail: res.status, hasAccount: Boolean(t.userId), missing: missing.length };
}

/* ------------------------------------------------------------------ */
/* Job missions:remind                                                 */
/* ------------------------------------------------------------------ */

export type MissionReminderReport = { checked: number; reminded: number; noResponse: number; firstLessonTasks: number };

/**
 * Relances quotidiennes :
 *  - mission « proposée » sans réponse depuis 5 jours ouvrés : relance du formateur (une fois) ;
 *  - puis 2 jours ouvrés après la relance : « sans réponse » + tâche « Trouver un remplaçant » ;
 *  - mission acceptée sans date de premier cours 2 jours ouvrés après l'acceptation : tâche de suivi.
 */
export async function runMissionReminders(opts: { orgId?: string | null; today?: string; reminderDays?: number; graceDays?: number } = {}): Promise<MissionReminderReport> {
  const today = opts.today ?? todayParis();
  const report: MissionReminderReport = { checked: 0, reminded: 0, noResponse: 0, firstLessonTasks: 0 };
  const orgCache = new Map<string, OrgRow | null>();
  const orgOf = async (id: string) => {
    if (!orgCache.has(id)) {
      const [o] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, id)).limit(1);
      orgCache.set(id, o ?? null);
    }
    return orgCache.get(id)!;
  };

  const pending = await db
    .select()
    .from(schema.trainerMissions)
    .where(and(eq(schema.trainerMissions.status, "proposee"), isNull(schema.trainerMissions.replacedByMissionId), opts.orgId ? eq(schema.trainerMissions.orgId, opts.orgId) : undefined));
  for (const m of pending) {
    report.checked++;
    const org = await orgOf(m.orgId);
    if (!org) continue;
    const actor: MissionActor = { org, userId: null };
    const step = reminderStep({ proposedOn: todayParis(m.proposedAt), remindedOn: m.reminderSentAt ? todayParis(m.reminderSentAt) : null, today, reminderDays: opts.reminderDays, graceDays: opts.graceDays });
    if (step === "remind") {
      const [claimed] = await db.update(schema.trainerMissions).set({ reminderSentAt: new Date() }).where(and(eq(schema.trainerMissions.id, m.id), isNull(schema.trainerMissions.reminderSentAt), eq(schema.trainerMissions.status, "proposee"))).returning();
      if (!claimed) continue;
      const t = await loadTrainer(org.id, m.trainerId);
      const mail = await sendProposalMail(actor, claimed, t, { reminder: true });
      await audit({ action: "mission.remind", orgId: org.id, entityType: "trainer_mission", entityId: m.id, after: { mail: mail.status } });
      report.reminded++;
    } else if (step === "no_response") {
      const [upd] = await db.update(schema.trainerMissions).set({ status: "sans_reponse", updatedAt: new Date() }).where(and(eq(schema.trainerMissions.id, m.id), eq(schema.trainerMissions.status, "proposee"), isNull(schema.trainerMissions.replacedByMissionId))).returning();
      if (!upd) continue;
      const t = await loadTrainer(org.id, m.trainerId);
      await createReplacementTask(actor, upd, t, "sans_reponse");
      await audit({ action: "mission.no_response", orgId: org.id, entityType: "trainer_mission", entityId: m.id, before: { status: "proposee" }, after: { status: "sans_reponse" } });
      report.noResponse++;
    }
  }

  const accepted = await db
    .select()
    .from(schema.trainerMissions)
    .where(and(eq(schema.trainerMissions.status, "acceptee"), isNull(schema.trainerMissions.firstLessonDate), isNotNull(schema.trainerMissions.respondedAt), opts.orgId ? eq(schema.trainerMissions.orgId, opts.orgId) : undefined));
  for (const m of accepted) {
    report.checked++;
    if (workdaysElapsed(todayParis(m.respondedAt!), today) < MISSION_FIRST_LESSON_WORKDAYS) continue;
    const org = await orgOf(m.orgId);
    if (!org) continue;
    const t = await loadTrainer(org.id, m.trainerId);
    const who = await assigneeFor(org.id, m);
    const r = await createTaskOnce({
      orgId: org.id,
      title: `Obtenir la date du premier cours : ${trainerName(t)}`,
      description: `Mission « ${m.theme} » acceptée le ${fmtDate(m.respondedAt)} : le formateur n'a pas encore communiqué la date du premier cours ni le planning prévisionnel.`,
      family: "pedagogie",
      entityType: "trainer_mission",
      entityId: m.id,
      entityLabel: `${m.theme} · ${trainerName(t)}`,
      href: missionsHref(org.id, "?statut=acceptee"),
      ...who,
      dueDate: today,
      isDemo: org.isDemo,
      idempotencyKey: missionTaskKeys.firstLesson(m.id),
    });
    if (r.created) report.firstLessonTasks++;
  }
  return report;
}

registerJobHandler("missions:remind", async (job) => {
  const r = await runMissionReminders({
    orgId: job.orgId,
    today: typeof job.payload.today === "string" ? job.payload.today : undefined,
    reminderDays: Number(job.payload.reminderDays ?? MISSION_REMINDER_WORKDAYS),
    graceDays: Number(job.payload.graceDays ?? MISSION_GRACE_WORKDAYS),
  });
  return { ...r };
});

/** Compteurs par statut (page missions). */
export async function missionCounts(orgId: string, trainerId: string | null) {
  const rows = await db
    .select({ status: schema.trainerMissions.status, n: sql<number>`count(*)::int` })
    .from(schema.trainerMissions)
    .where(and(eq(schema.trainerMissions.orgId, orgId), trainerId ? eq(schema.trainerMissions.trainerId, trainerId) : undefined))
    .groupBy(schema.trainerMissions.status);
  return Object.fromEntries(rows.map((r) => [r.status, r.n])) as Partial<Record<MissionStatus, number>>;
}
