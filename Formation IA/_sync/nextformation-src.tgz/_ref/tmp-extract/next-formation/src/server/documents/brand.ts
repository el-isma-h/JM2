import "server-only";
import { schema } from "@/db";
import { getObject } from "@/server/storage";
import type { Brand } from "./pdf";

type Org = typeof schema.organismes.$inferSelect;

export function orgAddress(org: Pick<Org, "addressLine1" | "addressLine2" | "postalCode" | "city">): string | null {
  const parts = [org.addressLine1, org.addressLine2, [org.postalCode, org.city].filter(Boolean).join(" ")].filter((p) => p && p.trim());
  return parts.length ? parts.join(", ") : null;
}

/** Lit le logo de l'organisme dans le stockage privé (null si absent ou illisible). */
export async function loadOrgLogo(org: Pick<Org, "logoKey">): Promise<Buffer | null> {
  if (!org.logoKey) return null;
  try {
    return await getObject(org.logoKey);
  } catch {
    return null;
  }
}

export async function loadOrgSignature(org: Pick<Org, "signatureKey">): Promise<Buffer | null> {
  if (!org.signatureKey) return null;
  try {
    return await getObject(org.signatureKey);
  } catch {
    return null;
  }
}

/** Charte institutionnelle de l'organisme concerné uniquement (F09 / F10). */
export async function brandFromOrg(org: Org): Promise<Brand> {
  return {
    legalName: org.legalName,
    tradeName: org.tradeName,
    siret: org.siret,
    nda: org.nda,
    address: orgAddress(org),
    primaryColor: org.primaryColor,
    documentHeader: org.documentHeader,
    documentFooter: org.documentFooter,
    logo: await loadOrgLogo(org),
  };
}
