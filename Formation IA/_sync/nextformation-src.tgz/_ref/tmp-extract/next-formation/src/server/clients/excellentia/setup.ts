import { randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { bootstrapOrgDefaults } from "@/server/org-defaults";
import { issueToken } from "@/server/auth";
import { sha256 } from "@/lib/crypto";
import catalogue from "./catalogue.json";

/**
 * Mise en service du client Excellentia (production) : groupe « Excellentia · ExF », organismes
 * Excellentia Formation (OF) et ExF Éducation (CFA), catalogue 2026 publié (109 formations), formations CFA,
 * grille tarifaire et invitation de la propriétaire (Essi AYIVOR). Idempotent : relançable sans doublon.
 *
 * Données non fournies par la cliente (SIRET, NDA, adresse exacte, durées) : laissées vides, à compléter dans
 * Paramètres. Aucune valeur n'est inventée.
 */

type Entry = { family: string; title: string; slug: string; cpf: boolean; certification: string | null; description: string; objectives: string[] | string; page: number };

export const OWNER_EMAIL = "essiayivor@excellentia-formation.fr";

/** Catégories de la grille « Offre tarifaire ExF » (catalogue 2026, p. 32). Rattachement des familles : à valider par la cliente. */
export const PRICE_GRID = {
  generales: { label: "Formations générales", individualHourlyCents: 9000, interHourlyCents: 4500, intraDailyCents: 120000 },
  techniques: { label: "Formations techniques", individualHourlyCents: 11000, interHourlyCents: 6000, intraDailyCents: 159600 },
  cadres: { label: "Formations cadres et dirigeants", individualHourlyCents: 17100, interHourlyCents: 6500, intraDailyCents: 172500 },
  note: "Intra-entreprise : tarif jour, 3 personnes minimum et 5 maximum (au-delà nous consulter).",
} as const;

export const FAMILY_CATEGORY: Record<string, keyof Omit<typeof PRICE_GRID, "note">> = {
  "Formations pour les cadres et dirigeants": "cadres",
  "Formations en Bureautique": "techniques",
  "Formations en Solutions numériques": "techniques",
  "Formations en Comptabilité et Gestion": "techniques",
  "Formations en Sécurité": "techniques",
  "Formations en Santé": "techniques",
  "Parcours CLEA numérique": "techniques",
  "Formations en Langues": "generales",
  "Formations en Management et RH": "generales",
  "Formations en Développement professionnel": "generales",
  "Formations en Commerce et Vente": "generales",
  "Parcours CléA socle de connaissances et de compétences professionnelles": "generales",
  "Parcours CléA Management": "generales",
  "Formation en Pratiques alternatives": "generales",
};

/** Formations CFA (catalogue 2026, « Tarifs CFA »). Durées et certifications RNCP à compléter. */
export const CFA_PROGRAMS = [
  { title: "Graduate Assistant RH", kind: "titre_professionnel", priceCents: 810000 },
  { title: "TP Formateur Professionnel d'Adultes (en continu)", kind: "titre_professionnel", priceCents: 690200 },
  { title: "Pré-Graduate Conseiller de vente", kind: "titre_professionnel", priceCents: 636000 },
  { title: "TP Gestionnaire de paie (alternance)", kind: "titre_professionnel", priceCents: 675000 },
  { title: "TP Secrétaire Assistant·e Médico-Administratif (alternance)", kind: "titre_professionnel", priceCents: 690000 },
] as const;

const CERTIFIERS: Record<string, { code: string; certifier: string }> = {
  TOSA: { code: "tosa", certifier: "Isograd (TOSA)" },
  "CléA": { code: "clea", certifier: "Certif Pro (CléA)" },
  "CléA Numérique": { code: "clea", certifier: "Certif Pro (CléA numérique)" },
  "CléA Management": { code: "clea", certifier: "Certif Pro (CléA management)" },
  TOEIC: { code: "toeic", certifier: "ETS Global (TOEIC)" },
  "Certificat Voltaire": { code: "voltaire", certifier: "Woonoz (Certificat Voltaire)" },
};

const slugify = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);

const fmtEuros = (c: number) => `${(c / 100).toLocaleString("fr-FR")} €`;

export type SetupReport = { tenantId: string; orgs: { id: string; name: string; kind: string; created: boolean }[]; programs: { inserted: number; existing: number }; invitations: { orgName: string; link: string | null; status: string }[] };

async function ensureOrg(tenantId: string, kind: "of" | "cfa", legalName: string, tradeName: string) {
  const [existing] = await db.select().from(schema.organismes).where(and(eq(schema.organismes.tenantId, tenantId), eq(schema.organismes.legalName, legalName))).limit(1);
  if (existing) return { org: existing, created: false };
  const org = await db.transaction(async (tx) => {
    const [o] = await tx
      .insert(schema.organismes)
      .values({
        tenantId,
        kind,
        legalName,
        tradeName,
        city: "Toulouse",
        country: "FR",
        website: "https://www.excellentia-formation.fr",
        qualiopiScopes: kind === "cfa" ? ["actions de formation par apprentissage"] : ["actions de formation"],
        signatoryName: "Essi AYIVOR",
        settings: {
          morning: { start: "09:00", end: "12:00" },
          afternoon: { start: "14:00", end: "17:00" },
          timezone: "Europe/Paris",
          pendingOwnerEmail: OWNER_EMAIL,
          priceGrid: kind === "of" ? PRICE_GRID : undefined,
        },
        onboardingStep: "identite",
      })
      .returning();
    await bootstrapOrgDefaults(tx, o.id);
    await tx.update(schema.sites).set({ name: "Toulouse", city: "Toulouse" }).where(and(eq(schema.sites.orgId, o.id), eq(schema.sites.isMain, true)));
    return o;
  });
  return { org, created: true };
}

async function ensureCertification(orgId: string, label: string) {
  const [c] = await db.select({ id: schema.certifications.id }).from(schema.certifications).where(and(eq(schema.certifications.orgId, orgId), eq(schema.certifications.title, label))).limit(1);
  if (c) return c.id;
  const [n] = await db.insert(schema.certifications).values({ orgId, title: label, certifier: CERTIFIERS[label]?.certifier ?? null }).returning({ id: schema.certifications.id });
  return n.id;
}

async function insertProgram(orgId: string, p: { code: string; title: string; slug: string; kind: string; category: string; cpf: boolean; certificationId: string | null; externalCertifier: string | null; priceCategory: string | null; apprenticeship: boolean; objectives: string | null; content: string | null; priceCents: number | null; priceNote: string | null }) {
  const [exists] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.orgId, orgId), eq(schema.programs.slug, p.slug))).limit(1);
  if (exists) return false;
  await db.transaction(async (tx) => {
    const [prog] = await tx
      .insert(schema.programs)
      .values({
        orgId,
        code: p.code,
        title: p.title,
        slug: p.slug,
        kind: p.kind as typeof schema.programs.$inferInsert.kind,
        category: p.category,
        certificationId: p.certificationId,
        availableAsApprenticeship: p.apprenticeship,
        availableAsContinuing: !p.apprenticeship,
        status: "actif",
        isPublished: true,
        publishedAt: new Date(),
        cpfEligible: p.cpf,
        externalCertifier: p.externalCertifier,
        priceCategory: p.priceCategory,
        tags: [p.category],
      })
      .returning({ id: schema.programs.id });
    await tx.insert(schema.programVersions).values({
      orgId,
      programId: prog.id,
      version: 1,
      status: "active",
      effectiveFrom: "2026-01-01",
      objectives: p.objectives,
      content: p.content,
      modality: "mixte",
      durationHours: 0,
      priceCents: p.priceCents,
      priceNote: p.priceNote,
      accessibility: "Formation accessible aux personnes en situation de handicap : contactez notre référent·e handicap pour étudier les adaptations.",
    });
  });
  return true;
}

async function ensureOwnerInvitation(tenantId: string, orgId: string, isDemo: boolean) {
  const [pending] = await db.select({ id: schema.invitations.id }).from(schema.invitations).where(and(eq(schema.invitations.orgId, orgId), eq(schema.invitations.email, OWNER_EMAIL))).limit(1);
  const [org] = await db.select({ ownerUserId: schema.organismes.ownerUserId }).from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  if (org?.ownerUserId) return { link: null, status: "propriétaire déjà en place" };
  const invitationId = pending?.id ?? randomUUID();
  const token = await issueToken("invite", { email: OWNER_EMAIL, payload: { invitationId }, ttlMinutes: 14 * 24 * 60 });
  const expiresAt = new Date(Date.now() + 14 * 86400_000);
  if (pending) await db.update(schema.invitations).set({ tokenHash: sha256(token), expiresAt, status: "pending" }).where(eq(schema.invitations.id, pending.id));
  else await db.insert(schema.invitations).values({ id: invitationId, tenantId, orgId, email: OWNER_EMAIL, roles: ["direction"], tokenHash: sha256(token), expiresAt });
  void isDemo;
  const base = (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");
  return { link: `${base}/invitation/${token}`, status: pending ? "invitation renouvelée (14 jours)" : "invitation créée (14 jours)" };
}

export async function setupExcellentia(): Promise<SetupReport> {
  let [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.slug, "excellentia")).limit(1);
  if (!tenant) [tenant] = await db.insert(schema.tenants).values({ name: "Excellentia · ExF", kind: "groupe", slug: "excellentia" }).returning();

  const of = await ensureOrg(tenant.id, "of", "Excellentia Formation", "Excellentia Formation");
  const cfa = await ensureOrg(tenant.id, "cfa", "ExF Éducation", "ExF Éducation");

  let inserted = 0;
  let existing = 0;
  const certCache = new Map<string, string>();
  for (const [i, e] of (catalogue as Entry[]).entries()) {
    let certificationId: string | null = null;
    if (e.certification) {
      if (!certCache.has(e.certification)) certCache.set(e.certification, await ensureCertification(of.org.id, e.certification));
      certificationId = certCache.get(e.certification)!;
    }
    const cat = FAMILY_CATEGORY[e.family] ?? "generales";
    const g = PRICE_GRID[cat];
    const objectives = Array.isArray(e.objectives) ? e.objectives.map((o, k) => `${k + 1}. ${o}`).join("\n") : e.objectives || null;
    const ok = await insertProgram(of.org.id, {
      code: `EXF-${String(i + 1).padStart(3, "0")}`,
      title: e.title,
      slug: slugify(e.slug || e.title),
      kind: e.certification ? "certifiante" : "formation_courte",
      category: e.family,
      cpf: e.cpf,
      certificationId,
      externalCertifier: e.certification ? (CERTIFIERS[e.certification]?.code ?? "autre") : null,
      priceCategory: cat,
      apprenticeship: false,
      objectives,
      content: e.description || null,
      priceCents: null,
      priceNote: `${g.label} : individuel ${fmtEuros(g.individualHourlyCents)}/h, inter-entreprises ${fmtEuros(g.interHourlyCents)}/h, intra-entreprise ${fmtEuros(g.intraDailyCents)}/jour. ${PRICE_GRID.note}`,
    });
    if (ok) inserted++;
    else existing++;
  }
  for (const [i, p] of CFA_PROGRAMS.entries()) {
    const ok = await insertProgram(cfa.org.id, {
      code: `CFA-${String(i + 1).padStart(2, "0")}`,
      title: p.title,
      slug: slugify(p.title),
      kind: p.kind,
      category: "Formations en alternance",
      cpf: false,
      certificationId: null,
      externalCertifier: null,
      priceCategory: null,
      apprenticeship: true,
      objectives: null,
      content: null,
      priceCents: p.priceCents,
      priceNote: "Tarif catalogue 2026 (prise en charge OPCO selon le niveau de prise en charge en vigueur).",
    });
    if (ok) inserted++;
    else existing++;
  }

  const invitations = [];
  for (const o of [of.org, cfa.org]) invitations.push({ orgName: o.legalName, ...(await ensureOwnerInvitation(tenant.id, o.id, o.isDemo)) });

  return {
    tenantId: tenant.id,
    orgs: [
      { id: of.org.id, name: of.org.legalName, kind: "of", created: of.created },
      { id: cfa.org.id, name: cfa.org.legalName, kind: "cfa", created: cfa.created },
    ],
    programs: { inserted, existing },
    invitations,
  };
}
