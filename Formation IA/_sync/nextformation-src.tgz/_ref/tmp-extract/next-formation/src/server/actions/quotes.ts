"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { numberingPrefix } from "@/server/numbering";
import { todayParis } from "@/lib/time";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { createDocument } from "@/server/documents/store";
import { layoutMail, sendMail } from "@/server/mail";
import { fail, isoDate, str, uuid } from "@/server/crm/helpers";
import { computeTotals, formatQuoteNumber, parseLines } from "@/server/crm/quote-math";
import { renderQuotePdf, type QuoteRecipient } from "@/server/crm/quote-pdf";
import { relayWonNeed } from "@/server/crm/relay";
import type { ActionState } from "./auth";

function base(orgId: string) {
  return `/app/${orgId}`;
}

async function loadQuote(ctx: OrgContext, id: string) {
  const [q] = await db.select().from(schema.quotes).where(and(eq(schema.quotes.id, id), eq(schema.quotes.orgId, ctx.org.id))).limit(1);
  if (!q) throw new Error("Devis introuvable dans cet organisme.");
  return q;
}

async function ref(ctx: OrgContext, formData: FormData, key: string, table: "companies" | "contacts" | "persons" | "needs"): Promise<string | null> {
  const raw = str(formData, key, 40);
  if (!raw) return null;
  const id = uuid.parse(raw);
  const t = schema[table];
  const [row] = await db.select({ id: t.id }).from(t).where(and(eq(t.id, id), eq(t.orgId, ctx.org.id))).limit(1);
  if (!row) throw new Error("Élément rattaché introuvable dans cet organisme.");
  return row.id;
}

/**
 * Numérotation DEV-YYYY-NNNN par organisme : séquence atomique (`invoice_sequences`, kind = devis) dans une transaction.
 * Deux créations simultanées obtiennent deux numéros distincts (upsert + returning sous verrou de ligne).
 */
async function nextQuoteNumber(tx: Pick<typeof db, "execute">, orgId: string, year: number): Promise<string> {
  const res = await tx.execute<{ next: number }>(sql`
    insert into invoice_sequences (org_id, kind, year, next) values (${orgId}, 'devis', ${year}, 2)
    on conflict (org_id, kind, year) do update set next = invoice_sequences.next + 1
    returning next - 1 as next
  `);
  const seq = Number(res.rows[0]?.next ?? 1);
  return formatQuoteNumber(year, seq, await numberingPrefix(orgId, "quote", "DEV"));
}

async function quoteValues(ctx: OrgContext, formData: FormData) {
  const companyId = await ref(ctx, formData, "companyId", "companies");
  const contactId = await ref(ctx, formData, "contactId", "contacts");
  const personId = await ref(ctx, formData, "personId", "persons");
  const needId = await ref(ctx, formData, "needId", "needs");
  if (!companyId && !personId) throw new Error("Rattachez le devis à une entreprise ou à une personne.");
  let rawLines: unknown = [];
  try {
    rawLines = JSON.parse(String(formData.get("lines") ?? "[]"));
  } catch {
    throw new Error("Lignes du devis illisibles.");
  }
  const parsed = parseLines(rawLines);
  if (!parsed.ok) throw new Error(parsed.error);
  const totals = computeTotals(parsed.lines);
  return {
    companyId,
    contactId,
    personId,
    needId,
    title: z.string().trim().min(2, "Objet du devis requis").max(200).parse(formData.get("title")),
    lines: parsed.lines,
    totalHtCents: totals.totalHtCents,
    vatCents: totals.vatCents,
    totalTtcCents: totals.totalTtcCents,
    issueDate: isoDate(formData, "issueDate") ?? todayParis(),
    validUntil: isoDate(formData, "validUntil"),
    notes: str(formData, "notes", 5000),
  };
}

export async function createQuoteAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let orgId = "";
  let id = "";
  try {
    orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const values = await quoteValues(ctx, formData);
    const year = Number(values.issueDate.slice(0, 4));
    const row = await db.transaction(async (tx) => {
      const number = await nextQuoteNumber(tx, ctx.org.id, year);
      const [r] = await tx.insert(schema.quotes).values({ ...values, number, orgId: ctx.org.id, status: "brouillon", createdBy: ctx.user.id }).returning({ id: schema.quotes.id, number: schema.quotes.number });
      return r;
    });
    await audit({ action: "quote.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quote", entityId: row.id, after: { number: row.number, totalTtcCents: values.totalTtcCents } });
    revalidatePath(`${base(orgId)}/devis`);
    id = row.id;
  } catch (e) {
    return fail(e, "Création impossible.");
  }
  redirect(`${base(orgId)}/devis/${id}`);
}

export async function updateQuoteAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const q = await loadQuote(ctx, uuid.parse(formData.get("quoteId")));
    if (q.status !== "brouillon") return { error: "Seul un devis en brouillon peut être modifié. Créez un nouveau devis pour une nouvelle proposition." };
    const values = await quoteValues(ctx, formData);
    await db.update(schema.quotes).set(values).where(eq(schema.quotes.id, q.id));
    await audit({ action: "quote.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quote", entityId: q.id, before: { totalTtcCents: q.totalTtcCents }, after: { totalTtcCents: values.totalTtcCents } });
    revalidatePath(`${base(orgId)}/devis/${q.id}`);
    revalidatePath(`${base(orgId)}/devis`);
    return { ok: true, message: `Devis enregistré : ${formatCents(values.totalTtcCents)} TTC.` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

async function recipientFor(ctx: OrgContext, q: typeof schema.quotes.$inferSelect): Promise<QuoteRecipient & { email: string | null; contactName: string | null }> {
  const lines: string[] = [];
  let name = "";
  let email: string | null = null;
  let contactName: string | null = null;
  if (q.companyId) {
    const [c] = await db.select().from(schema.companies).where(and(eq(schema.companies.id, q.companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1);
    if (c) {
      name = c.name;
      if (c.addressLine1) lines.push(c.addressLine1);
      if (c.addressLine2) lines.push(c.addressLine2);
      if (c.postalCode || c.city) lines.push([c.postalCode, c.city].filter(Boolean).join(" "));
      if (c.siret) lines.push(`SIRET ${c.siret}`);
      email = c.email;
    }
  }
  if (q.contactId) {
    const [ct] = await db.select().from(schema.contacts).where(and(eq(schema.contacts.id, q.contactId), eq(schema.contacts.orgId, ctx.org.id))).limit(1);
    if (ct) {
      contactName = `${ct.firstName} ${ct.lastName}`;
      lines.unshift(`À l'attention de ${contactName}${ct.jobTitle ? `, ${ct.jobTitle}` : ""}`);
      if (ct.email) email = ct.email;
    }
  }
  if (q.personId) {
    const [p] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, q.personId), eq(schema.persons.orgId, ctx.org.id))).limit(1);
    if (p) {
      if (!name) name = `${p.firstName} ${p.lastName}`;
      else lines.unshift(`Bénéficiaire : ${p.firstName} ${p.lastName}`);
      if (!q.companyId) {
        if (p.addressLine1) lines.push(p.addressLine1);
        if (p.postalCode || p.city) lines.push([p.postalCode, p.city].filter(Boolean).join(" "));
      }
      if (!email) email = p.email;
      if (!contactName) contactName = `${p.firstName} ${p.lastName}`;
    }
  }
  return { name: name || "[À COMPLÉTER : destinataire]", lines, email, contactName };
}

async function generatePdf(ctx: OrgContext, q: typeof schema.quotes.$inferSelect) {
  const recipient = await recipientFor(ctx, q);
  const pdf = await renderQuotePdf(ctx.org, q, recipient);
  const doc = await createDocument({
    orgId: ctx.org.id,
    companyId: q.companyId,
    personId: q.personId,
    category: "devis",
    visibility: "interne",
    status: "genere",
    title: `Devis ${q.number} : ${q.title}`,
    fileName: `${q.number}.pdf`,
    mimeType: "application/pdf",
    data: pdf,
    sourceType: "quote",
    sourceId: q.id,
    uploadedBy: ctx.user.id,
    previousVersionId: q.documentId,
    generationData: { number: q.number, totalTtcCents: q.totalTtcCents, recipient: recipient.name },
    isDemo: ctx.org.isDemo,
  });
  await db.update(schema.quotes).set({ documentId: doc.id }).where(eq(schema.quotes.id, q.id));
  return { doc, recipient };
}

export async function generateQuotePdfAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage", "documents.generate");
    const q = await loadQuote(ctx, uuid.parse(formData.get("quoteId")));
    const { doc } = await generatePdf(ctx, q);
    await audit({ action: "quote.pdf", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quote", entityId: q.id, after: { documentId: doc.id, version: doc.version } });
    revalidatePath(`${base(orgId)}/devis/${q.id}`);
    return { ok: true, message: `PDF généré (version ${doc.version}).` };
  } catch (e) {
    return fail(e, "Génération impossible.");
  }
}

export async function sendQuoteAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage", "documents.generate");
    const q = await loadQuote(ctx, uuid.parse(formData.get("quoteId")));
    if (q.status === "accepte" || q.status === "refuse") return { error: "Ce devis est déjà clos." };
    const { doc, recipient } = await generatePdf(ctx, q);
    const to = str(formData, "to", 200)?.toLowerCase() || recipient.email;
    if (!to) return { error: "Aucune adresse e-mail : renseignez l'e-mail du contact ou saisissez une adresse." };
    const message = str(formData, "message", 3000);
    const amount = formatCents(q.totalTtcCents);
    const res = await sendMail({
      to,
      subject: `Devis ${q.number} : ${q.title}`,
      html: layoutMail(
        `Devis ${q.number}`,
        `<p>Bonjour${recipient.contactName ? ` ${recipient.contactName}` : ""},</p><p>Veuillez trouver notre proposition « ${q.title} » d'un montant de ${amount} TTC${q.validUntil ? `, valable jusqu'au ${fmtDate(q.validUntil)}` : ""}.</p>${message ? `<p>${message.replace(/\n/g, "<br>")}</p>` : ""}<p>Le document PDF (${doc.fileName}) vous est transmis par ${ctx.org.tradeName ?? ctx.org.legalName}. Pour toute question, répondez à cet e-mail.</p>`,
      ),
      text: `Devis ${q.number} : ${q.title}, ${amount} TTC.${message ? `\n\n${message}` : ""}`,
      isDemo: ctx.org.isDemo,
    });
    await db.update(schema.quotes).set({ status: "envoye", sentAt: new Date() }).where(eq(schema.quotes.id, q.id));
    await db.update(schema.documents).set({ status: "transmis", transmittedAt: new Date() }).where(eq(schema.documents.id, doc.id));
    await audit({ action: "quote.send", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quote", entityId: q.id, after: { to, mail: res.status, documentId: doc.id } });
    if (q.companyId || q.personId) {
      await db.insert(schema.interactions).values({ orgId: ctx.org.id, companyId: q.companyId, contactId: q.contactId, personId: q.personId, needId: q.needId, kind: "email", subject: `Devis ${q.number} envoyé à ${to}`, userId: ctx.user.id });
    }
    revalidatePath(`${base(orgId)}/devis/${q.id}`);
    revalidatePath(`${base(orgId)}/devis`);
    if (ctx.org.isDemo) return { ok: true, message: `Devis marqué envoyé. Espace de démonstration : aucun e-mail réel n'est parti (destinataire ${to}).` };
    if (res.status !== "sent") return { ok: true, message: `Devis marqué envoyé. Service e-mail non configuré : l'e-mail à ${to} est dans la boîte d'envoi, transmettez le PDF manuellement.` };
    return { ok: true, message: `Devis envoyé à ${to}.` };
  } catch (e) {
    return fail(e, "Envoi impossible.");
  }
}

export async function setQuoteStatusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const q = await loadQuote(ctx, uuid.parse(formData.get("quoteId")));
    const status = z.enum(["accepte", "refuse", "expire", "brouillon"]).parse(formData.get("status"));
    if (status === q.status) return { ok: true, message: "Statut inchangé." };
    if (status === "brouillon" && q.status !== "envoye") return { error: "Seul un devis envoyé peut repasser en brouillon." };
    if ((status === "accepte" || status === "refuse") && q.status === "brouillon") return { error: "Envoyez d'abord le devis (ou générez-le) avant d'enregistrer la réponse du client." };
    const patch: Partial<typeof schema.quotes.$inferInsert> = { status };
    if (status === "accepte") patch.acceptedAt = new Date();
    await db.update(schema.quotes).set(patch).where(eq(schema.quotes.id, q.id));
    await audit({ action: `quote.${status}`, userId: ctx.user.id, orgId: ctx.org.id, entityType: "quote", entityId: q.id, before: { status: q.status }, after: { status, reason: str(formData, "reason", 500) } });
    let extra = "";
    if (status === "accepte" && q.needId) {
      const [need] = await db.select().from(schema.needs).where(and(eq(schema.needs.id, q.needId), eq(schema.needs.orgId, ctx.org.id))).limit(1);
      if (need && need.stage !== "gagne") {
        const [won] = await db.update(schema.needs).set({ stage: "gagne", wonAt: new Date(), probability: 100, lostAt: null, lostReason: null }).where(eq(schema.needs.id, need.id)).returning();
        await audit({ action: "need.won", userId: ctx.user.id, orgId: ctx.org.id, entityType: "need", entityId: need.id, before: { stage: need.stage }, after: { stage: "gagne", via: `quote:${q.id}` } });
        await relayWonNeed({ orgId: ctx.org.id, userId: ctx.user.id, isDemo: ctx.org.isDemo }, won);
        extra = " Le besoin lié passe en « gagné ».";
        revalidatePath(`${base(orgId)}/besoins/${need.id}`);
        revalidatePath(`${base(orgId)}/besoins`);
      }
    }
    revalidatePath(`${base(orgId)}/devis/${q.id}`);
    revalidatePath(`${base(orgId)}/devis`);
    return { ok: true, message: `Devis ${status === "accepte" ? "accepté" : status === "refuse" ? "refusé" : status === "expire" ? "marqué expiré" : "repassé en brouillon"}.${extra}` };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

/** Duplique un devis (nouveau numéro, brouillon) : utile pour une nouvelle proposition après refus ou expiration. */
export async function duplicateQuoteAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let orgId = "";
  let id = "";
  try {
    orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "crm.manage");
    const q = await loadQuote(ctx, uuid.parse(formData.get("quoteId")));
    const issueDate = todayParis();
    const row = await db.transaction(async (tx) => {
      const number = await nextQuoteNumber(tx, ctx.org.id, Number(issueDate.slice(0, 4)));
      const [r] = await tx
        .insert(schema.quotes)
        .values({
          orgId: ctx.org.id,
          number,
          companyId: q.companyId,
          contactId: q.contactId,
          personId: q.personId,
          needId: q.needId,
          title: q.title,
          lines: q.lines,
          totalHtCents: q.totalHtCents,
          vatCents: q.vatCents,
          totalTtcCents: q.totalTtcCents,
          issueDate,
          validUntil: null,
          notes: q.notes,
          status: "brouillon",
          createdBy: ctx.user.id,
        })
        .returning({ id: schema.quotes.id, number: schema.quotes.number });
      return r;
    });
    await audit({ action: "quote.duplicate", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quote", entityId: row.id, after: { from: q.number, number: row.number } });
    revalidatePath(`${base(orgId)}/devis`);
    id = row.id;
  } catch (e) {
    return fail(e, "Duplication impossible.");
  }
  redirect(`${base(orgId)}/devis/${id}`);
}
