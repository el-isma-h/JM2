import "server-only";
import { and, asc, desc, eq, ilike, inArray, notInArray, or, sql, type SQL } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { db, schema } from "@/db";

type MissionStatus = (typeof schema.missionStatusEnum.enumValues)[number];

export type MissionRow = Awaited<ReturnType<typeof listMissions>>[number];

/** Missions d'un organisme (toujours filtrées par orgId), avec formateur, session, apprenant et contrat. */
export async function listMissions(orgId: string, f: { status?: string | null; trainerId?: string | null; q?: string | null; limit?: number; offset?: number } = {}) {
  const conds: SQL[] = [eq(schema.trainerMissions.orgId, orgId)];
  if (f.status && (schema.missionStatusEnum.enumValues as readonly string[]).includes(f.status)) conds.push(eq(schema.trainerMissions.status, f.status as MissionStatus));
  if (f.trainerId) conds.push(eq(schema.trainerMissions.trainerId, f.trainerId));
  if (f.q) conds.push(or(ilike(schema.trainerMissions.theme, `%${f.q}%`), ilike(schema.trainers.lastName, `%${f.q}%`), ilike(schema.persons.lastName, `%${f.q}%`), ilike(schema.trainingSessions.title, `%${f.q}%`))!);
  const replacement = alias(schema.trainerMissions, "replacement");
  const replTrainer = alias(schema.trainers, "repl_trainer");
  return db
    .select({
      m: schema.trainerMissions,
      trainer: { id: schema.trainers.id, firstName: schema.trainers.firstName, lastName: schema.trainers.lastName, email: schema.trainers.email, userId: schema.trainers.userId, hourlyRateCents: schema.trainers.hourlyRateCents },
      session: { id: schema.trainingSessions.id, title: schema.trainingSessions.title, code: schema.trainingSessions.code },
      enrollment: { id: schema.enrollments.id, reference: schema.enrollments.reference },
      learner: { firstName: schema.persons.firstName, lastName: schema.persons.lastName },
      contract: { id: schema.documents.id, status: schema.documents.status, version: schema.documents.version, generationData: schema.documents.generationData },
      replacedBy: { firstName: replTrainer.firstName, lastName: replTrainer.lastName },
    })
    .from(schema.trainerMissions)
    .innerJoin(schema.trainers, and(eq(schema.trainers.id, schema.trainerMissions.trainerId), eq(schema.trainers.orgId, orgId)))
    .leftJoin(schema.trainingSessions, and(eq(schema.trainingSessions.id, schema.trainerMissions.sessionId), eq(schema.trainingSessions.orgId, orgId)))
    .leftJoin(schema.enrollments, and(eq(schema.enrollments.id, schema.trainerMissions.enrollmentId), eq(schema.enrollments.orgId, orgId)))
    .leftJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .leftJoin(schema.documents, and(eq(schema.documents.id, schema.trainerMissions.contractDocumentId), eq(schema.documents.orgId, orgId)))
    .leftJoin(replacement, and(eq(replacement.id, schema.trainerMissions.replacedByMissionId), eq(replacement.orgId, orgId)))
    .leftJoin(replTrainer, eq(replTrainer.id, replacement.trainerId))
    .where(and(...conds))
    .orderBy(desc(schema.trainerMissions.proposedAt))
    .limit(f.limit ?? 100)
    .offset(f.offset ?? 0);
}

export async function countMissions(orgId: string, f: { status?: string | null; trainerId?: string | null; q?: string | null } = {}) {
  const conds: SQL[] = [eq(schema.trainerMissions.orgId, orgId)];
  if (f.status && (schema.missionStatusEnum.enumValues as readonly string[]).includes(f.status)) conds.push(eq(schema.trainerMissions.status, f.status as MissionStatus));
  if (f.trainerId) conds.push(eq(schema.trainerMissions.trainerId, f.trainerId));
  if (f.q) conds.push(or(ilike(schema.trainerMissions.theme, `%${f.q}%`), ilike(schema.trainers.lastName, `%${f.q}%`), ilike(schema.persons.lastName, `%${f.q}%`), ilike(schema.trainingSessions.title, `%${f.q}%`))!);
  const [{ n }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.trainerMissions)
    .innerJoin(schema.trainers, eq(schema.trainers.id, schema.trainerMissions.trainerId))
    .leftJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.trainerMissions.sessionId))
    .leftJoin(schema.enrollments, eq(schema.enrollments.id, schema.trainerMissions.enrollmentId))
    .leftJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(...conds));
  return n;
}

export type MissionOptions = Awaited<ReturnType<typeof missionFormOptions>>;

/** Listes du dialogue « Proposer une mission » : formateurs actifs, sessions et inscriptions en cours ou à venir. */
export async function missionFormOptions(orgId: string, opts: { excludeTrainerId?: string | null } = {}) {
  const [trainers, sessions] = await Promise.all([
    db
      .select({ id: schema.trainers.id, firstName: schema.trainers.firstName, lastName: schema.trainers.lastName, hourlyRateCents: schema.trainers.hourlyRateCents, email: schema.trainers.email })
      .from(schema.trainers)
      .where(and(eq(schema.trainers.orgId, orgId), eq(schema.trainers.isActive, true)))
      .orderBy(asc(schema.trainers.lastName), asc(schema.trainers.firstName)),
    db
      .select({ id: schema.trainingSessions.id, title: schema.trainingSessions.title, code: schema.trainingSessions.code, startDate: schema.trainingSessions.startDate, endDate: schema.trainingSessions.endDate })
      .from(schema.trainingSessions)
      .where(and(eq(schema.trainingSessions.orgId, orgId), notInArray(schema.trainingSessions.status, ["annulee", "terminee"])))
      .orderBy(desc(schema.trainingSessions.startDate))
      .limit(200),
  ]);
  const enrollments = sessions.length
    ? await db
        .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, sessionId: schema.enrollments.sessionId, firstName: schema.persons.firstName, lastName: schema.persons.lastName })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.sessionId, sessions.map((s) => s.id)), notInArray(schema.enrollments.status, ["annule", "abandon"])))
        .orderBy(asc(schema.persons.lastName))
        .limit(400)
    : [];
  return { trainers: trainers.filter((t) => t.id !== opts.excludeTrainerId), sessions, enrollments };
}
