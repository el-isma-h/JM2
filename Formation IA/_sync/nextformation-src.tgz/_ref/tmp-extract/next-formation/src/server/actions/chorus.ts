"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { checkSiret } from "@/lib/validators";
import { requireOrg, type OrgContext } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { getIntegration, readSecrets, upsertIntegration } from "@/server/integrations/store";
import { CHORUS_ENDPOINTS, deposerFlux, refreshChorusStatus, testChorusConnection, type ChorusConfig, type ChorusSecrets } from "@/server/integrations/chorus";
import { chorusStatusMeta } from "@/server/integrations/chorus-status";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

/** Configuration : gestion des intégrations ou propriétaire (comme les autres connecteurs). */
async function requireWriter(orgId: string): Promise<OrgContext> {
  const ctx = await requireOrg(orgId, "org.view");
  if (!ctx.isOwner && !ctx.permissions.has("integrations.manage")) throw new AuthError("forbidden");
  return ctx;
}

export async function saveChorusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const env = z.enum(["qualification", "production"], { message: "Choisissez l'environnement (qualification ou production)." }).parse(formData.get("env"));
    let supplierSiret = String(formData.get("supplierSiret") ?? "").trim();
    if (supplierSiret) {
      const r = checkSiret(supplierSiret);
      if (!r.ok) return { error: `SIRET fournisseur : ${r.error}` };
      supplierSiret = r.value;
    }
    const secrets: ChorusSecrets = {};
    for (const k of ["clientId", "clientSecret", "techLogin", "techPassword"] as const) {
      const v = String(formData.get(k) ?? "").trim();
      if (v.length > 300) return { error: "Identifiant trop long." };
      if (v) secrets[k] = v;
    }
    const existing = await getIntegration(orgId, "chorus");
    const prev = (existing?.config ?? {}) as ChorusConfig;
    const prevSecrets = readSecrets<ChorusSecrets>(existing) ?? {};
    const merged = { ...prevSecrets, ...secrets };
    const missing = [!merged.clientId && "client_id PISTE", !merged.clientSecret && "client_secret PISTE", !merged.techLogin && "login du compte technique", !merged.techPassword && "mot de passe du compte technique"].filter(Boolean) as string[];
    // L'identifiant de structure dépend de l'environnement et du SIRET : il est recalculé au prochain test.
    const resetStructure = prev.env !== env || (prev.supplierSiret ?? "") !== supplierSiret;
    const row = await upsertIntegration(orgId, "chorus", {
      config: { env, supplierSiret: supplierSiret || null, ...(resetStructure ? { supplierStructureId: null, supplierName: null } : {}) },
      secrets: Object.keys(secrets).length ? (secrets as Record<string, string>) : undefined,
      status: existing?.status === "desactivee" ? "desactivee" : "configuree",
      lastError: null,
    });
    await audit({ action: "integration.chorus.save", userId: ctx.user.id, orgId, entityType: "org_integration", entityId: row.id, before: { env: prev.env ?? null, supplierSiret: prev.supplierSiret ?? null }, after: { env, supplierSiret: supplierSiret || null, secretsUpdated: Object.keys(secrets) } });
    revalidatePath(`/app/${orgId}/integrations`);
    return missing.length ? { ok: true, message: `Enregistré (${CHORUS_ENDPOINTS[env].label}). Il manque encore : ${missing.join(", ")}.` } : { ok: true, message: `Chorus Pro enregistré (${CHORUS_ENDPOINTS[env].label}) : testez la connexion.` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function testChorusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    try {
      const r = await testChorusConnection(orgId);
      await audit({ action: "integration.chorus.test", userId: ctx.user.id, orgId, entityType: "org_integration", after: { ok: true, env: r.env, structureId: r.structureId } });
      revalidatePath(`/app/${orgId}/integrations`);
      return { ok: true, message: `Connexion réussie (${CHORUS_ENDPOINTS[r.env].label}) : structure ${r.name ?? ""} reconnue (identifiant Chorus ${r.structureId}).` };
    } catch (e) {
      await audit({ action: "integration.chorus.test", userId: ctx.user.id, orgId, entityType: "org_integration", after: { ok: false, error: e instanceof Error ? e.message.slice(0, 300) : "erreur" } });
      revalidatePath(`/app/${orgId}/integrations`);
      throw e;
    }
  } catch (e) {
    return fail(e, "Test impossible.");
  }
}

export async function depositChorusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const invoiceId = uuid.parse(formData.get("invoiceId"));
    const ctx = await requireOrg(orgId, "finance.manage");
    const r = await deposerFlux({ orgId: ctx.org.id, invoiceId, userId: ctx.user.id });
    revalidatePath(`/app/${orgId}/factures/${invoiceId}`);
    return { ok: true, message: `Facture déposée sur Chorus Pro (${CHORUS_ENDPOINTS[r.env].label}, ${r.mode === "flux" ? "flux Factur-X" : "saisie API avec PDF"}) : ${chorusStatusMeta(r.status).label}. Référence ${r.ref}.` };
  } catch (e) {
    const orgId = String(formData.get("orgId") ?? "");
    const invoiceId = String(formData.get("invoiceId") ?? "");
    if (/^[0-9a-f-]{36}$/i.test(orgId) && /^[0-9a-f-]{36}$/i.test(invoiceId)) revalidatePath(`/app/${orgId}/factures/${invoiceId}`);
    return fail(e, "Dépôt impossible.");
  }
}

export async function refreshChorusStatusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const invoiceId = uuid.parse(formData.get("invoiceId"));
    const ctx = await requireOrg(orgId, "finance.manage");
    if (ctx.org.isDemo) return { error: "Démonstration : aucun appel Chorus Pro réel." };
    const r = await refreshChorusStatus({ orgId: ctx.org.id, invoiceId, userId: ctx.user.id });
    revalidatePath(`/app/${orgId}/factures/${invoiceId}`);
    return { ok: true, message: r.changed ? `Statut mis à jour : ${chorusStatusMeta(r.status).label}.` : `Statut inchangé : ${chorusStatusMeta(r.status).label}.` };
  } catch (e) {
    return fail(e, "Consultation impossible.");
  }
}

/**
 * Facture émise : seul le SIRET de l'acheteur public (non imprimé sur le PDF) peut encore être complété.
 * Le bon de commande, le code service et l'engagement juridique figurent sur le PDF : ils se saisissent sur le brouillon.
 */
export async function setInvoiceBuyerSiretAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const invoiceId = uuid.parse(formData.get("invoiceId"));
    const ctx = await requireOrg(orgId, "finance.manage");
    const r = checkSiret(String(formData.get("buyerSiret") ?? "").trim());
    if (!r.ok) return { error: `SIRET de l'acheteur : ${r.error}` };
    const [inv] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, invoiceId), eq(schema.invoices.orgId, ctx.org.id))).limit(1);
    if (!inv) return { error: "Facture introuvable." };
    if (inv.chorusRef && !chorusStatusMeta(inv.chorusStatus).redeposit) return { error: "Facture déjà déposée sur Chorus Pro : le destinataire ne se modifie plus ici." };
    await db.update(schema.invoices).set({ buyerSiret: r.value }).where(eq(schema.invoices.id, inv.id));
    await audit({ action: "invoice.buyer_siret", userId: ctx.user.id, orgId, entityType: "invoice", entityId: inv.id, before: { buyerSiret: inv.buyerSiret }, after: { buyerSiret: r.value } });
    revalidatePath(`/app/${orgId}/factures/${inv.id}`);
    return { ok: true, message: "SIRET de l'acheteur public enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}
