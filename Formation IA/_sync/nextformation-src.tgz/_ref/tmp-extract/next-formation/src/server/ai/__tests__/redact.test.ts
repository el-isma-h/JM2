import { describe, expect, it } from "vitest";
import { redactForAi, redactString, toPromptJson } from "../redact";

describe("redactForAi : minimisation avant prompt", () => {
  it("retire NIR, IBAN, notes confidentielles et adresses complètes à toute profondeur", () => {
    const out = redactForAi({
      person: { firstName: "Camille", lastName: "Aubert", nir: "2 85 03 75 116 004 32", confidentialNotes: "secret", addressLine1: "14 rue des Tanneurs", addressLine2: "Bât. B", postalCode: "75011", city: "Paris" },
      org: { ribIbanEnc: "v1.x.y.z", ribBic: "AGRIFRPP", legalName: "Atelier" },
      list: [{ iban: "FR7630006000011234567890189", label: "ok" }],
    }) as Record<string, Record<string, unknown>> & { list: Record<string, unknown>[] };
    expect(out.person.firstName).toBe("Camille");
    expect(out.person).not.toHaveProperty("nir");
    expect(out.person).not.toHaveProperty("confidentialNotes");
    expect(out.person).not.toHaveProperty("addressLine1");
    expect(out.person).not.toHaveProperty("addressLine2");
    expect(out.person.city).toBe("Paris");
    expect(out.org).not.toHaveProperty("ribIbanEnc");
    expect(out.org).not.toHaveProperty("ribBic");
    expect(out.list[0]).not.toHaveProperty("iban");
    expect(out.list[0].label).toBe("ok");
  });
  it("masque les motifs IBAN et NIR dans les chaînes libres", () => {
    expect(redactString("virement sur FR76 3000 6000 0112 3456 7890 189 merci")).toContain("[IBAN retiré]");
    expect(redactString("NIR 1 85 03 75 116 004 32 à vérifier")).toContain("[NIR retiré]");
    expect(redactString("Session S-2026-014 du 12/03")).toBe("Session S-2026-014 du 12/03");
  });
  it("conserve les dates (ISO) et nombres, ignore les tampons binaires", () => {
    const d = new Date("2026-03-01T09:00:00Z");
    const out = redactForAi({ when: d, n: 3, data: Buffer.from("x"), ok: true }) as Record<string, unknown>;
    expect(out.when).toBe(d.toISOString());
    expect(out.n).toBe(3);
    expect(out.ok).toBe(true);
    expect(out).not.toHaveProperty("data");
    expect(toPromptJson({ nir: "1", a: 1 })).not.toContain("nir");
  });
});
