import "server-only";
import { and, asc, eq, inArray } from "drizzle-orm";
import JSZip from "jszip";
import { db, schema } from "@/db";
import { getOrgContext, trainerSessionIds, type OrgContext } from "@/server/authz";
import { getObject } from "@/server/storage";
import { mimeForPath, parseScormManifest } from "./scorm";

export type ElearningModule = typeof schema.elearningModules.$inferSelect;

/** Lit le manifeste d'un paquet SCORM (.zip) et retourne titre + page de lancement. */
export async function inspectScormPackage(zipData: Buffer) {
  const zip = await JSZip.loadAsync(zipData);
  const entry = zip.file(/(^|\/)imsmanifest\.xml$/i)[0];
  if (!entry) return { ok: false as const, error: "Le paquet ne contient pas de fichier imsmanifest.xml : ce n'est pas un paquet SCORM." };
  const prefix = entry.name.replace(/imsmanifest\.xml$/i, "");
  const manifest = parseScormManifest(await entry.async("string"));
  if (!manifest.launch) return { ok: false as const, error: "Le manifeste ne désigne aucune page de lancement." };
  const launch = `${prefix}${manifest.launch}`;
  if (!zip.file(launch)) return { ok: false as const, error: `La page de lancement « ${launch} » est absente du paquet.` };
  return { ok: true as const, title: manifest.title, launch, schemaVersion: manifest.schemaVersion, files: Object.keys(zip.files).length };
}

/** Sert un fichier du paquet stocké (clé privée) : contenu + type MIME. */
export async function readPackageFile(packageKey: string, path: string): Promise<{ data: Buffer; mime: string } | null> {
  const zipData = await getObject(packageKey).catch(() => null);
  if (!zipData) return null;
  const zip = await JSZip.loadAsync(zipData);
  const f = zip.file(path);
  if (!f || f.dir) return null;
  return { data: await f.async("nodebuffer"), mime: mimeForPath(path) };
}

export type ElearningAccess = { module: ElearningModule; ctx: OrgContext; staff: boolean; enrollmentIds: string[] };

/**
 * Accès à un module e-learning : personnel de l'organisme (catalog.view, périmètre formateur par session),
 * ou apprenant (membership `personId`) inscrit à une session de la version de programme du module.
 */
export async function resolveElearningAccess(orgId: string, moduleId: string): Promise<ElearningAccess | null> {
  if (!/^[0-9a-f-]{36}$/i.test(orgId) || !/^[0-9a-f-]{36}$/i.test(moduleId)) return null;
  const ctx = await getOrgContext(orgId);
  if (!ctx) return null;
  const [module] = await db.select().from(schema.elearningModules).where(and(eq(schema.elearningModules.id, moduleId), eq(schema.elearningModules.orgId, orgId))).limit(1);
  if (!module || !module.isActive) return null;
  const staff = ctx.permissions.has("catalog.view") || ctx.permissions.has("dossier.pedagogy.view");
  if (staff) {
    const scope = await trainerSessionIds(ctx);
    if (scope && module.programVersionId) {
      const sessions = scope.length ? await db.select({ v: schema.trainingSessions.programVersionId }).from(schema.trainingSessions).where(inArray(schema.trainingSessions.id, scope)) : [];
      if (!sessions.some((s) => s.v === module.programVersionId)) return null;
    }
    return { module, ctx, staff: true, enrollmentIds: [] };
  }
  if (!ctx.personId) return null;
  const enrollments = await db
    .select({ id: schema.enrollments.id, programVersionId: schema.enrollments.programVersionId, sessionVersionId: schema.trainingSessions.programVersionId })
    .from(schema.enrollments)
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.personId, ctx.personId), inArray(schema.enrollments.status, ["inscrit", "en_cours"])));
  const ids = enrollments.filter((e) => !module.programVersionId || (e.programVersionId ?? e.sessionVersionId) === module.programVersionId).map((e) => e.id);
  if (!ids.length) return null;
  return { module, ctx, staff: false, enrollmentIds: ids };
}

/** Crée ou met à jour la progression (unique par module × inscription) sans jamais valider le temps : la validation est humaine. */
export async function upsertProgress(orgId: string, moduleId: string, enrollmentId: string, patch: { addMinutes?: number; status?: (typeof schema.progressStatusEnum.enumValues)[number]; score?: number | null; maxScore?: number | null; raw?: unknown }) {
  const [existing] = await db.select().from(schema.elearningProgress).where(and(eq(schema.elearningProgress.orgId, orgId), eq(schema.elearningProgress.elearningModuleId, moduleId), eq(schema.elearningProgress.enrollmentId, enrollmentId))).limit(1);
  const now = new Date();
  const add = Math.max(0, Math.min(240, Math.round(patch.addMinutes ?? 0)));
  if (existing) {
    const status = patch.status ?? (existing.status === "non_commence" ? "en_cours" : existing.status);
    const [upd] = await db
      .update(schema.elearningProgress)
      .set({
        timeSpentMinutes: existing.timeSpentMinutes + add,
        status,
        score: patch.score ?? existing.score,
        maxScore: patch.maxScore ?? existing.maxScore,
        raw: patch.raw ?? existing.raw,
        lastAccessAt: now,
        completedAt: status === "termine" ? (existing.completedAt ?? now) : existing.completedAt,
        // Tout nouveau temps invalide la validation précédente : à revalider par un humain.
        validatedBy: add > 0 ? null : existing.validatedBy,
        validatedAt: add > 0 ? null : existing.validatedAt,
        updatedAt: now,
      })
      .where(eq(schema.elearningProgress.id, existing.id))
      .returning();
    return upd;
  }
  const [ins] = await db
    .insert(schema.elearningProgress)
    .values({ orgId, elearningModuleId: moduleId, enrollmentId, status: patch.status ?? (add > 0 ? "en_cours" : "non_commence"), timeSpentMinutes: add, score: patch.score ?? null, maxScore: patch.maxScore ?? null, raw: patch.raw ?? {}, lastAccessAt: now, completedAt: patch.status === "termine" ? now : null })
    .onConflictDoNothing()
    .returning();
  if (ins) return ins;
  return upsertProgress(orgId, moduleId, enrollmentId, patch);
}

/** Minutes à distance validées par un humain pour une inscription (modules `countsAsHours`). Exposé aux équipes B / G. */
export async function validatedRemoteMinutes(orgId: string, enrollmentId: string): Promise<number> {
  const rows = await db
    .select({ minutes: schema.elearningProgress.timeSpentMinutes, validatedAt: schema.elearningProgress.validatedAt, counts: schema.elearningModules.countsAsHours })
    .from(schema.elearningProgress)
    .innerJoin(schema.elearningModules, eq(schema.elearningModules.id, schema.elearningProgress.elearningModuleId))
    .where(and(eq(schema.elearningProgress.orgId, orgId), eq(schema.elearningProgress.enrollmentId, enrollmentId)));
  return rows.filter((r) => r.counts && r.validatedAt).reduce((n, r) => n + r.minutes, 0);
}

export async function listModules(orgId: string, programVersionId?: string) {
  return db
    .select({ m: schema.elearningModules, versionLabel: schema.programs.title, version: schema.programVersions.version })
    .from(schema.elearningModules)
    .leftJoin(schema.programVersions, eq(schema.programVersions.id, schema.elearningModules.programVersionId))
    .leftJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .where(and(eq(schema.elearningModules.orgId, orgId), programVersionId ? eq(schema.elearningModules.programVersionId, programVersionId) : undefined))
    .orderBy(asc(schema.elearningModules.position), asc(schema.elearningModules.createdAt));
}
