"use server";

import { revalidatePath } from "next/cache";
import { and, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { parseDateInput } from "@/lib/validators";
import { assertSessionInScope, requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { checkSessionTransition, nextSessionCode, normalizeRhythm, sessionPlaces, type SessionStatus } from "@/server/sessions/service";
import { readCarifPublics, readCarifRecruitment, validateCarifRecruitment } from "@/server/declarations/carif";
import { todayParis } from "@/lib/time";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const optUuid = z.string().uuid().optional().or(z.literal(""));

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

function str(fd: FormData, k: string) {
  return String(fd.get(k) ?? "").trim();
}

function base(orgId: string) {
  return `/app/${orgId}/sessions`;
}

async function loadSession(ctx: OrgContext, sessionId: string) {
  const [s] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, sessionId), eq(schema.trainingSessions.orgId, ctx.org.id))).limit(1);
  if (!s) throw new Error("Session introuvable dans cet organisme.");
  await assertSessionInScope(ctx, s.id);
  return s;
}

/** Lecture du rythme depuis le formulaire (préréglage ou personnalisé, horaires matin / après-midi). */
function readRhythm(fd: FormData, org: OrgContext["org"]) {
  const weekdays = fd.getAll("weekdays").map(Number);
  return normalizeRhythm(
    {
      preset: str(fd, "rhythmPreset") as "personnalise",
      label: str(fd, "rhythmLabel"),
      centerDays: Number(str(fd, "centerDays")),
      companyDays: Number(str(fd, "companyDays")),
      weekdays,
      morning: { start: str(fd, "morningStart"), end: str(fd, "morningEnd") },
      afternoon: { start: str(fd, "afternoonStart"), end: str(fd, "afternoonEnd") },
    },
    (org.settings ?? {}) as { morning?: { start: string; end: string }; afternoon?: { start: string; end: string } },
  );
}

const sessionSchema = z.object({
  orgId: uuid,
  programVersionId: uuid.describe("Version de programme requise"),
  title: z.string().trim().min(2, "Intitulé requis").max(200),
  kind: z.enum(["inter", "intra", "cycle", "individuel"]),
  isApprenticeship: z.enum(["of", "cfa"]).default("of"),
  modality: z.enum(["presentiel", "distanciel", "mixte", "afest", "elearning"]).default("presentiel"),
  capacity: z.coerce.number().int().min(1, "Capacité : au moins 1 place").max(500),
  minCapacity: z.coerce.number().int().min(0).max(500).default(1),
  siteId: optUuid,
  roomId: optUuid,
  companyId: optUuid,
  pedagogyManagerUserId: optUuid,
  adminManagerUserId: optUuid,
  notes: z.string().trim().max(4000).optional(),
});

async function sessionValues(ctx: OrgContext, fd: FormData) {
  const d = sessionSchema.parse(Object.fromEntries(fd));
  const startDate = parseDateInput(str(fd, "startDate"));
  const endDate = parseDateInput(str(fd, "endDate"));
  if (!startDate) throw new Error("Date de début invalide (format JJ/MM/AAAA).");
  if (!endDate) throw new Error("Date de fin invalide (format JJ/MM/AAAA).");
  if (endDate < startDate) throw new Error("La date de fin précède la date de début.");
  if (d.minCapacity > d.capacity) throw new Error("Le minimum d'inscrits ne peut pas dépasser la capacité.");
  const [version] = await db.select().from(schema.programVersions).where(and(eq(schema.programVersions.id, d.programVersionId), eq(schema.programVersions.orgId, ctx.org.id))).limit(1);
  if (!version) throw new Error("Version de programme introuvable dans cet organisme.");
  if (d.siteId) {
    const [site] = await db.select({ id: schema.sites.id }).from(schema.sites).where(and(eq(schema.sites.id, d.siteId), eq(schema.sites.orgId, ctx.org.id))).limit(1);
    if (!site) throw new Error("Site introuvable.");
  }
  if (d.roomId) {
    const [room] = await db.select({ siteId: schema.rooms.siteId }).from(schema.rooms).where(and(eq(schema.rooms.id, d.roomId), eq(schema.rooms.orgId, ctx.org.id))).limit(1);
    if (!room) throw new Error("Salle introuvable.");
    if (d.siteId && room.siteId !== d.siteId) throw new Error("La salle n'appartient pas au site choisi.");
  }
  if (d.companyId) {
    const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.id, d.companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1);
    if (!c) throw new Error("Entreprise introuvable.");
  }
  for (const uid of [d.pedagogyManagerUserId, d.adminManagerUserId]) {
    if (!uid) continue;
    const [m] = await db.select({ id: schema.memberships.id }).from(schema.memberships).where(and(eq(schema.memberships.orgId, ctx.org.id), eq(schema.memberships.userId, uid), eq(schema.memberships.active, true))).limit(1);
    if (!m) throw new Error("Le responsable choisi n'est pas membre actif de l'organisme.");
  }
  const price = str(fd, "price");
  const priceCents = price ? Math.round(Number(price.replace(/\s/g, "").replace(",", ".")) * 100) : null;
  if (price && (priceCents === null || Number.isNaN(priceCents) || priceCents < 0)) throw new Error("Prix invalide (ex. 1 250,00).");
  const rhythm = readRhythm(fd, ctx.org);
  return {
    d,
    values: {
      programVersionId: d.programVersionId,
      title: d.title,
      kind: d.kind,
      isApprenticeship: d.isApprenticeship === "cfa",
      startDate,
      endDate,
      siteId: d.siteId || null,
      roomId: d.roomId || null,
      modality: d.modality,
      capacity: d.capacity,
      minCapacity: d.minCapacity,
      rhythm,
      schedule: { morning: rhythm.morning, afternoon: rhythm.afternoon },
      pedagogyManagerUserId: d.pedagogyManagerUserId || null,
      adminManagerUserId: d.adminManagerUserId || null,
      companyId: d.companyId || null,
      priceCents,
      isPublished: fd.get("isPublished") === "on",
      notes: d.notes || null,
    },
  };
}

/** Champs « Déclaration Carif-Oref » (section repliable du formulaire d'édition). */
function carifValues(fd: FormData, before: typeof schema.trainingSessions.$inferSelect, sessionEnd: string) {
  const carifSessionNumber = str(fd, "carifSessionNumber").slice(0, 60) || null;
  const rawTotal = str(fd, "totalCapacity");
  const totalCapacity = rawTotal ? Number(rawTotal) : null;
  if (totalCapacity !== null && (!Number.isInteger(totalCapacity) || totalCapacity < 1 || totalCapacity > 10000)) throw new Error("Effectif total Carif-Oref invalide (nombre entier d'au moins 1).");
  let rawRecruitment: unknown = [];
  let rawPublics: unknown = [];
  try {
    rawRecruitment = JSON.parse(str(fd, "recruitmentJson") || "[]");
    rawPublics = JSON.parse(str(fd, "publicsJson") || "[]");
  } catch {
    throw new Error("Déclaration Carif-Oref illisible : rechargez la page.");
  }
  const recruitment = readCarifRecruitment(rawRecruitment);
  const publics = readCarifPublics(rawPublics);
  const err = validateCarifRecruitment(recruitment, { today: todayParis(), sessionEnd, previous: readCarifRecruitment(before.recruitment) });
  if (err) throw new Error(err);
  return { carifSessionNumber, totalCapacity, recruitment, publics };
}

export async function createSessionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const { values } = await sessionValues(ctx, formData);
    const session = await db.transaction(async (tx) => {
      const code = str(formData, "code") || (await nextSessionCode(tx, orgId, Number(values.startDate.slice(0, 4))));
      const [dup] = await tx.select({ id: schema.trainingSessions.id }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.orgId, orgId), eq(schema.trainingSessions.code, code))).limit(1);
      if (dup) throw new Error(`Le code « ${code} » existe déjà dans cet organisme.`);
      const [s] = await tx.insert(schema.trainingSessions).values({ orgId, code, ...values, isDemo: ctx.org.isDemo }).returning();
      return s;
    });
    await audit({ action: "session.create", userId: ctx.user.id, orgId, entityType: "session", entityId: session.id, after: { code: session.code, title: session.title, startDate: session.startDate, endDate: session.endDate } });
    revalidatePath(base(orgId));
    return { ok: true, message: `Session ${session.code} créée.`, data: { sessionId: session.id, redirect: `${base(orgId)}/${session.id}` } };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function updateSessionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const sessionId = uuid.parse(formData.get("sessionId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const before = await loadSession(ctx, sessionId);
    if (before.status === "terminee") return { error: "Session terminée : les paramètres ne sont plus modifiables." };
    const { values } = await sessionValues(ctx, formData);
    if (values.capacity < before.capacity) {
      const p = await sessionPlaces(before.id);
      if (p.enrolled > values.capacity) return { error: `Impossible de réduire la capacité à ${values.capacity} : ${p.enrolled} inscription(s) active(s).` };
    }
    const carif = formData.get("carifSection") === "1" ? carifValues(formData, before, values.endDate) : null;
    await db.update(schema.trainingSessions).set(carif ? { ...values, ...carif } : values).where(eq(schema.trainingSessions.id, before.id));
    if (carif) await audit({ action: "session.carif.update", userId: ctx.user.id, orgId, entityType: "session", entityId: before.id, before: { carifSessionNumber: before.carifSessionNumber, totalCapacity: before.totalCapacity, recruitment: before.recruitment, publics: before.publics }, after: carif });
    await audit({ action: "session.update", userId: ctx.user.id, orgId, entityType: "session", entityId: before.id, before: { title: before.title, startDate: before.startDate, endDate: before.endDate, capacity: before.capacity, rhythm: before.rhythm }, after: { title: values.title, startDate: values.startDate, endDate: values.endDate, capacity: values.capacity, rhythm: values.rhythm } });
    revalidatePath(`${base(orgId)}/${before.id}`);
    revalidatePath(base(orgId));
    return { ok: true, message: "Session enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Transition de statut contrôlée (brouillon → ouverte → confirmée → en cours → terminée / annulée). Ne solde jamais les financements. */
export async function transitionSessionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const sessionId = uuid.parse(formData.get("sessionId"));
    const to = z.enum(["brouillon", "ouverte", "confirmee", "en_cours", "terminee", "annulee"]).parse(formData.get("to")) as SessionStatus;
    const reason = str(formData, "reason");
    const ctx = await requireOrg(orgId, "sessions.manage");
    const s = await loadSession(ctx, sessionId);
    const check = await checkSessionTransition(s, to);
    if (!check.ok) return { error: check.reason };
    if ((to === "annulee" || (to === "brouillon" && s.status === "annulee")) && !reason) return { error: "Indiquez le motif : il est conservé dans le journal." };
    await db
      .update(schema.trainingSessions)
      .set({ status: to, closedAt: to === "terminee" ? new Date() : to === "annulee" ? s.closedAt : null, notes: reason ? `${s.notes ? `${s.notes}\n` : ""}[${to}] ${reason}` : s.notes })
      .where(eq(schema.trainingSessions.id, s.id));
    await audit({ action: "session.transition", userId: ctx.user.id, orgId, entityType: "session", entityId: s.id, before: { status: s.status }, after: { status: to, reason: reason || null } });
    revalidatePath(`${base(orgId)}/${s.id}`);
    revalidatePath(base(orgId));
    return { ok: true, message: to === "terminee" ? "Session terminée. Les financements des inscriptions restent à solder séparément." : `Statut enregistré : ${to}.` };
  } catch (e) {
    return fail(e, "Changement de statut impossible.");
  }
}

/** Duplique une session (paramètres, groupes, formateurs ; sans inscriptions) en brouillon. */
export async function duplicateSessionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const sessionId = uuid.parse(formData.get("sessionId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const s = await loadSession(ctx, sessionId);
    const startDate = parseDateInput(str(formData, "startDate")) ?? s.startDate;
    const days = Math.round((Date.parse(s.endDate) - Date.parse(s.startDate)) / 86400_000);
    const end = new Date(Date.parse(startDate) + days * 86400_000).toISOString().slice(0, 10);
    const copy = await db.transaction(async (tx) => {
      const code = await nextSessionCode(tx, orgId, Number(startDate.slice(0, 4)));
      const { id: _id, createdAt: _c, updatedAt: _u, closedAt: _cl, ...rest } = s;
      void _id; void _c; void _u; void _cl;
      const [n] = await tx.insert(schema.trainingSessions).values({ ...rest, code, title: `${s.title} (copie)`, status: "brouillon", startDate, endDate: end, isPublished: false }).returning();
      const groups = await tx.select().from(schema.groups).where(eq(schema.groups.sessionId, s.id));
      const groupMap = new Map<string, string>();
      for (const g of groups) {
        const [ng] = await tx.insert(schema.groups).values({ orgId, sessionId: n.id, name: g.name, capacity: g.capacity }).returning({ id: schema.groups.id });
        groupMap.set(g.id, ng.id);
      }
      const trainers = await tx.select().from(schema.sessionTrainers).where(eq(schema.sessionTrainers.sessionId, s.id));
      for (const t of trainers) await tx.insert(schema.sessionTrainers).values({ orgId, sessionId: n.id, trainerId: t.trainerId, role: t.role, groupId: t.groupId ? (groupMap.get(t.groupId) ?? null) : null }).onConflictDoNothing();
      return n;
    });
    await audit({ action: "session.duplicate", userId: ctx.user.id, orgId, entityType: "session", entityId: copy.id, before: { from: s.id, code: s.code }, after: { code: copy.code, startDate, endDate: end } });
    revalidatePath(base(orgId));
    return { ok: true, message: `Session dupliquée : ${copy.code} (brouillon, sans inscription).`, data: { redirect: `${base(orgId)}/${copy.id}` } };
  } catch (e) {
    return fail(e, "Duplication impossible.");
  }
}

export async function saveGroupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const sessionId = uuid.parse(formData.get("sessionId"));
    const groupId = str(formData, "groupId");
    const name = z.string().trim().min(1, "Nom du groupe requis").max(80).parse(formData.get("name"));
    const capRaw = str(formData, "capacity");
    const capacity = capRaw ? z.coerce.number().int().min(1, "Capacité invalide").max(500).parse(capRaw) : null;
    const ctx = await requireOrg(orgId, "sessions.manage");
    const s = await loadSession(ctx, sessionId);
    if (groupId) {
      const [g] = await db.select().from(schema.groups).where(and(eq(schema.groups.id, groupId), eq(schema.groups.sessionId, s.id), eq(schema.groups.orgId, orgId))).limit(1);
      if (!g) return { error: "Groupe introuvable." };
      await db.update(schema.groups).set({ name, capacity }).where(eq(schema.groups.id, g.id));
      await audit({ action: "group.update", userId: ctx.user.id, orgId, entityType: "group", entityId: g.id, before: { name: g.name, capacity: g.capacity }, after: { name, capacity } });
    } else {
      const [g] = await db.insert(schema.groups).values({ orgId, sessionId: s.id, name, capacity }).returning();
      await audit({ action: "group.create", userId: ctx.user.id, orgId, entityType: "group", entityId: g.id, after: { name, capacity, sessionId: s.id } });
    }
    revalidatePath(`${base(orgId)}/${s.id}`);
    return { ok: true, message: groupId ? "Groupe enregistré." : "Groupe créé." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deleteGroupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const groupId = uuid.parse(formData.get("groupId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const [g] = await db.select().from(schema.groups).where(and(eq(schema.groups.id, groupId), eq(schema.groups.orgId, orgId))).limit(1);
    if (!g) return { error: "Groupe introuvable." };
    await loadSession(ctx, g.sessionId);
    const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.enrollments).where(eq(schema.enrollments.groupId, g.id));
    if (n > 0) return { error: `Le groupe compte ${n} inscription(s) : changez-les de groupe avant de le supprimer.` };
    await db.delete(schema.groups).where(eq(schema.groups.id, g.id));
    await audit({ action: "group.delete", userId: ctx.user.id, orgId, entityType: "group", entityId: g.id, before: { name: g.name, sessionId: g.sessionId } });
    revalidatePath(`${base(orgId)}/${g.sessionId}`);
    return { ok: true, message: "Groupe supprimé." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

/** Affectation d'un formateur : un formateur seul ne peut jamais créer sa propre affectation (0045). */
export async function addSessionTrainerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const sessionId = uuid.parse(formData.get("sessionId"));
    const trainerId = uuid.parse(formData.get("trainerId"));
    const role = z.enum(["principal", "intervenant", "jury", "tuteur_pedagogique"]).parse(formData.get("role"));
    const groupId = str(formData, "groupId");
    const ctx = await requireOrg(orgId, "sessions.manage");
    if (ctx.trainerOnly) return { error: "Un formateur ne peut pas gérer les affectations." };
    if (ctx.trainerId === trainerId && !ctx.isOwner && !ctx.permissions.has("planning.manage")) return { error: "Vous ne pouvez pas vous affecter vous-même : demandez au responsable pédagogique." };
    const s = await loadSession(ctx, sessionId);
    const [t] = await db.select().from(schema.trainers).where(and(eq(schema.trainers.id, trainerId), eq(schema.trainers.orgId, orgId))).limit(1);
    if (!t) return { error: "Formateur introuvable dans cet organisme." };
    if (!t.isActive) return { error: "Ce formateur est inactif." };
    if (groupId) {
      const [g] = await db.select({ id: schema.groups.id }).from(schema.groups).where(and(eq(schema.groups.id, groupId), eq(schema.groups.sessionId, s.id))).limit(1);
      if (!g) return { error: "Groupe introuvable pour cette session." };
    }
    const [row] = await db.insert(schema.sessionTrainers).values({ orgId, sessionId: s.id, trainerId, role, groupId: groupId || null }).onConflictDoNothing().returning();
    if (!row) return { error: "Ce formateur est déjà affecté à cette session (même groupe)." };
    await audit({ action: "session.trainer.add", userId: ctx.user.id, orgId, entityType: "session", entityId: s.id, after: { trainerId, role, groupId: groupId || null } });
    revalidatePath(`${base(orgId)}/${s.id}`);
    return { ok: true, message: `${t.firstName} ${t.lastName} affecté(e) comme ${role === "principal" ? "formateur principal" : role}.` };
  } catch (e) {
    return fail(e, "Affectation impossible.");
  }
}

export async function removeSessionTrainerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const id = uuid.parse(formData.get("id"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    if (ctx.trainerOnly) return { error: "Un formateur ne peut pas gérer les affectations." };
    const [row] = await db.select().from(schema.sessionTrainers).where(and(eq(schema.sessionTrainers.id, id), eq(schema.sessionTrainers.orgId, orgId))).limit(1);
    if (!row) return { error: "Affectation introuvable." };
    await loadSession(ctx, row.sessionId);
    await db.delete(schema.sessionTrainers).where(eq(schema.sessionTrainers.id, row.id));
    await audit({ action: "session.trainer.remove", userId: ctx.user.id, orgId, entityType: "session", entityId: row.sessionId, before: { trainerId: row.trainerId, role: row.role } });
    revalidatePath(`${base(orgId)}/${row.sessionId}`);
    return { ok: true, message: "Affectation retirée." };
  } catch (e) {
    return fail(e, "Retrait impossible.");
  }
}
