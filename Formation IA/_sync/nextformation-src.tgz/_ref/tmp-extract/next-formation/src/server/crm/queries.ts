import "server-only";
import { and, desc, eq, ilike, isNotNull, ne, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { todayParis } from "@/lib/time";
import { compact } from "@/lib/validators";

/** Membres actifs de l'organisme pouvant être « commercial référent » (toute personne du back-office). */
export async function listStaffUsers(orgId: string) {
  const rows = await db
    .select({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, roles: schema.memberships.roles })
    .from(schema.memberships)
    .innerJoin(schema.users, eq(schema.users.id, schema.memberships.userId))
    .where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.active, true), sql`${schema.users.disabledAt} is null`))
    .orderBy(schema.users.lastName, schema.users.firstName);
  return rows
    .filter((r) => (Array.isArray(r.roles) ? (r.roles as string[]) : []).some((x) => x !== "learner" && x !== "employer"))
    .map((r) => ({ id: r.id, name: `${r.firstName} ${r.lastName}` }));
}

export async function userNames(ids: (string | null | undefined)[]): Promise<Map<string, string>> {
  const unique = [...new Set(ids.filter((x): x is string => Boolean(x)))];
  if (!unique.length) return new Map();
  const rows = await db
    .select({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName })
    .from(schema.users)
    .where(sql`${schema.users.id} in ${unique}`);
  return new Map(rows.map((r) => [r.id, `${r.firstName} ${r.lastName}`]));
}

export type NextAction = { label: string; date: string | null; overdue: boolean; kind: "relance" | "devis" | "placement" | "besoin" | "aucune"; href?: string };

/** Vrai si la date ISO est strictement avant aujourd'hui (Europe/Paris). */
export function isOverdue(date: string | null | undefined, today = todayParis()): boolean {
  return Boolean(date && date < today);
}

/**
 * Prochaine action d'une entreprise / personne : dernier échange portant une prochaine relance,
 * puis besoins ouverts avec prochaine action, puis devis à envoyer.
 */
export async function nextActionFor(orgId: string, scope: { companyId?: string; personId?: string }): Promise<NextAction> {
  const today = todayParis();
  const scopeCond = scope.companyId ? eq(schema.interactions.companyId, scope.companyId) : eq(schema.interactions.personId, scope.personId ?? "00000000-0000-0000-0000-000000000000");
  const [last] = await db
    .select({ nextAction: schema.interactions.nextAction, nextActionAt: schema.interactions.nextActionAt, kind: schema.interactions.kind })
    .from(schema.interactions)
    .where(and(eq(schema.interactions.orgId, orgId), scopeCond, isNotNull(schema.interactions.nextActionAt)))
    .orderBy(desc(schema.interactions.at))
    .limit(1);
  if (last?.nextActionAt) return { label: last.nextAction || "Relance prévue", date: last.nextActionAt, overdue: isOverdue(last.nextActionAt, today), kind: "relance" };

  const needCond = scope.companyId ? eq(schema.needs.companyId, scope.companyId) : eq(schema.needs.personId, scope.personId ?? "00000000-0000-0000-0000-000000000000");
  const [need] = await db
    .select({ id: schema.needs.id, nextAction: schema.needs.nextAction, nextActionAt: schema.needs.nextActionAt, title: schema.needs.title })
    .from(schema.needs)
    .where(and(eq(schema.needs.orgId, orgId), needCond, ne(schema.needs.stage, "gagne"), ne(schema.needs.stage, "perdu"), isNotNull(schema.needs.nextActionAt)))
    .orderBy(schema.needs.nextActionAt)
    .limit(1);
  if (need?.nextActionAt) return { label: `${need.nextAction || "Prochaine action"} (${need.title})`, date: need.nextActionAt, overdue: isOverdue(need.nextActionAt, today), kind: "besoin", href: `/besoins/${need.id}` };

  const quoteCond = scope.companyId ? eq(schema.quotes.companyId, scope.companyId) : eq(schema.quotes.personId, scope.personId ?? "00000000-0000-0000-0000-000000000000");
  const [quote] = await db
    .select({ id: schema.quotes.id, number: schema.quotes.number, status: schema.quotes.status, validUntil: schema.quotes.validUntil })
    .from(schema.quotes)
    .where(and(eq(schema.quotes.orgId, orgId), quoteCond, or(eq(schema.quotes.status, "brouillon"), eq(schema.quotes.status, "envoye"))))
    .orderBy(desc(schema.quotes.createdAt))
    .limit(1);
  if (quote?.status === "brouillon") return { label: `Devis ${quote.number} à envoyer`, date: null, overdue: false, kind: "devis", href: `/devis/${quote.id}` };
  if (quote?.status === "envoye") return { label: `Devis ${quote.number} en attente de réponse`, date: quote.validUntil, overdue: isOverdue(quote.validUntil, today), kind: "devis", href: `/devis/${quote.id}` };
  return { label: "Aucune action planifiée", date: null, overdue: false, kind: "aucune" };
}

/** Prochaine action d'un besoin : sa propre prochaine action, sinon placement en attente, sinon devis. */
export async function nextActionForNeed(orgId: string, need: { id: string; stage: string; nextAction: string | null; nextActionAt: string | null }): Promise<NextAction> {
  const today = todayParis();
  if (need.stage === "gagne" || need.stage === "perdu") return { label: need.stage === "gagne" ? "Besoin gagné : créer l'inscription si ce n'est pas fait" : "Besoin perdu", date: null, overdue: false, kind: "aucune" };
  if (need.nextActionAt) return { label: need.nextAction || "Prochaine action", date: need.nextActionAt, overdue: isOverdue(need.nextActionAt, today), kind: "besoin" };
  const [pending] = await db
    .select({ id: schema.placements.id, status: schema.placements.status })
    .from(schema.placements)
    .where(and(eq(schema.placements.orgId, orgId), eq(schema.placements.needId, need.id), or(eq(schema.placements.status, "propose"), eq(schema.placements.status, "entretien"))))
    .limit(1);
  if (pending) return { label: pending.status === "propose" ? "Placement proposé : organiser l'entretien" : "Entretien en cours : décider du placement", date: null, overdue: false, kind: "placement" };
  const [quote] = await db
    .select({ id: schema.quotes.id, number: schema.quotes.number, status: schema.quotes.status, validUntil: schema.quotes.validUntil })
    .from(schema.quotes)
    .where(and(eq(schema.quotes.orgId, orgId), eq(schema.quotes.needId, need.id), or(eq(schema.quotes.status, "brouillon"), eq(schema.quotes.status, "envoye"))))
    .orderBy(desc(schema.quotes.createdAt))
    .limit(1);
  if (quote?.status === "brouillon") return { label: `Devis ${quote.number} à envoyer`, date: null, overdue: false, kind: "devis", href: `/devis/${quote.id}` };
  if (quote?.status === "envoye") return { label: `Devis ${quote.number} en attente de réponse`, date: quote.validUntil, overdue: isOverdue(quote.validUntil, today), kind: "devis", href: `/devis/${quote.id}` };
  return { label: "Aucune prochaine action : planifiez une relance", date: null, overdue: false, kind: "aucune" };
}

/** Doublons d'entreprise : même SIRET, ou nom très proche. Jamais de fusion automatique : simple avertissement. */
export async function findCompanyDuplicates(orgId: string, input: { name: string; siret?: string | null }, excludeId?: string) {
  const conds = [ilike(schema.companies.name, input.name.trim())];
  const siret = input.siret ? compact(input.siret) : "";
  if (siret) conds.push(eq(schema.companies.siret, siret));
  const rows = await db
    .select({ id: schema.companies.id, name: schema.companies.name, siret: schema.companies.siret, city: schema.companies.city })
    .from(schema.companies)
    .where(and(eq(schema.companies.orgId, orgId), or(...conds), excludeId ? ne(schema.companies.id, excludeId) : undefined))
    .limit(5);
  return rows;
}

/** Doublons de personne : même nom + date de naissance, ou même e-mail. */
export async function findPersonDuplicates(orgId: string, input: { firstName: string; lastName: string; birthDate?: string | null; email?: string | null }, excludeId?: string) {
  const conds = [];
  if (input.birthDate) conds.push(and(ilike(schema.persons.lastName, input.lastName.trim()), ilike(schema.persons.firstName, input.firstName.trim()), eq(schema.persons.birthDate, input.birthDate)));
  if (input.email) conds.push(eq(schema.persons.email, input.email.toLowerCase()));
  if (!conds.length) return [];
  return db
    .select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email, birthDate: schema.persons.birthDate })
    .from(schema.persons)
    .where(and(eq(schema.persons.orgId, orgId), or(...conds), excludeId ? ne(schema.persons.id, excludeId) : undefined))
    .limit(5);
}

export function duplicateWarning(kind: "entreprise" | "personne", rows: { id: string }[], describe: (r: never) => string): string | null {
  if (!rows.length) return null;
  const list = rows.map((r) => describe(r as never)).join(" ; ");
  return kind === "entreprise"
    ? `Attention : ${rows.length} entreprise(s) semblable(s) existe(nt) déjà (${list}). Aucune fusion automatique : vérifiez avant de poursuivre.`
    : `Attention : ${rows.length} personne(s) semblable(s) existe(nt) déjà (${list}). Aucune fusion automatique : vérifiez avant de poursuivre.`;
}
