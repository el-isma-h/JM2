"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, count, eq, inArray } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { createDocument, issueDownloadLink } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { layoutMail, sendMail } from "@/server/mail";
import { resolveTaskByKey } from "@/server/tasks/service";
import { checkSiret } from "@/lib/validators";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import {
  checkPaymentAmount,
  FUNDER_KINDS,
  FUNDING_STATUSES,
  fundingTransitionError,
  invoiceTotals,
  parseAmountToCents,
  parseBankCsv,
  validateSchedule,
  VAT_EXEMPT_MENTION,
  DEFAULT_PAYMENT_TERMS,
  type FundingStatus,
  type ScheduleLine,
} from "@/server/finance/compute";
import {
  agreementPieceKey,
  issueInvoice,
  markOverdueInvoices,
  readSchedule,
  recalcEnrollmentFundingState,
  recalcInvoicePayment,
  relayFundingGranted,
  relayOverdueSchedules,
  setFundingStatus,
  syncFundingFromInvoices,
  OPEN_INVOICE_STATUSES,
} from "@/server/finance/service";
import { EXPENSE_CATEGORIES } from "@/server/finance/bpf";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const optUuid = z.preprocess((v) => (v === "" || v === undefined ? null : v), uuid.nullable());
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide (AAAA-MM-JJ).");
const optDate = z.preprocess((v) => (v === "" || v === undefined ? null : v), isoDate.nullable());
const optText = (max = 2000) => z.preprocess((v) => (v === undefined || (typeof v === "string" && v.trim() === "") ? null : v), z.string().trim().max(max).nullable());
const euros = z.preprocess((v) => (typeof v === "string" ? v.trim() : v), z.string());

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

function cents(raw: string, field: string): number {
  const c = parseAmountToCents(raw);
  if (c === null) throw new Error(`${field} : montant illisible (ex. 1 250,00).`);
  return c;
}

function fd(formData: FormData): Record<string, string> {
  const o: Record<string, string> = {};
  for (const [k, v] of formData.entries()) if (typeof v === "string") o[k] = v;
  return o;
}

function base(orgId: string) {
  return `/app/${orgId}`;
}

async function requireFinance(orgId: string) {
  return requireOrg(orgId, "finance.manage");
}

async function loadEnrollment(ctx: OrgContext, enrollmentId: string) {
  const [e] = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, ctx.org.id))).limit(1);
  if (!e) throw new Error("Inscription introuvable dans cet organisme.");
  return e;
}

async function loadFunding(ctx: OrgContext, fundingId: string) {
  const [f] = await db.select().from(schema.fundings).where(and(eq(schema.fundings.id, fundingId), eq(schema.fundings.orgId, ctx.org.id))).limit(1);
  if (!f) throw new Error("Financement introuvable dans cet organisme.");
  return f;
}

async function loadInvoice(ctx: OrgContext, invoiceId: string) {
  const [i] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, invoiceId), eq(schema.invoices.orgId, ctx.org.id))).limit(1);
  if (!i) throw new Error("Facture introuvable dans cet organisme.");
  return i;
}

async function loadFunder(ctx: OrgContext, funderId: string) {
  const [f] = await db.select().from(schema.funders).where(and(eq(schema.funders.id, funderId), eq(schema.funders.orgId, ctx.org.id))).limit(1);
  if (!f) throw new Error("Financeur introuvable dans cet organisme.");
  return f;
}

// ---------------------------------------------------------------------------
// Financeurs
// ---------------------------------------------------------------------------

const funderSchema = z.object({
  orgId: uuid,
  name: z.string().trim().min(2, "Nom du financeur requis.").max(160),
  kind: z.enum(FUNDER_KINDS),
  companyId: optUuid,
  contactName: optText(160),
  email: z.preprocess((v) => (v === "" ? null : v), z.string().trim().email("Adresse e-mail invalide.").nullable()),
  phone: optText(40),
  addressLine1: optText(200),
  postalCode: optText(12),
  city: optText(120),
  siret: optText(20),
  notes: optText(4000),
});

async function funderValues(ctx: OrgContext, d: z.infer<typeof funderSchema>) {
  let siret: string | null = null;
  if (d.siret) {
    const r = checkSiret(d.siret);
    if (!r.ok) throw new Error(r.error);
    siret = r.value;
  }
  if (d.companyId) {
    const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.id, d.companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1);
    if (!c) throw new Error("Entreprise introuvable dans cet organisme.");
  }
  return { name: d.name, kind: d.kind, companyId: d.companyId, contactName: d.contactName, email: d.email, phone: d.phone, addressLine1: d.addressLine1, postalCode: d.postalCode, city: d.city, siret, notes: d.notes };
}

export async function createFunderAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = funderSchema.parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const values = await funderValues(ctx, d);
    const [row] = await db.insert(schema.funders).values({ orgId: ctx.org.id, ...values }).returning();
    await audit({ action: "funder.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "funder", entityId: row.id, after: values });
    revalidatePath(`${base(ctx.org.id)}/financeurs`);
    return { ok: true, message: `Financeur « ${row.name} » créé.` };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function updateFunderAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = funderSchema.extend({ funderId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const before = await loadFunder(ctx, d.funderId);
    const values = await funderValues(ctx, d);
    await db.update(schema.funders).set(values).where(eq(schema.funders.id, before.id));
    await audit({ action: "funder.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "funder", entityId: before.id, before, after: values });
    revalidatePath(`${base(ctx.org.id)}/financeurs`);
    revalidatePath(`${base(ctx.org.id)}/financeurs/${before.id}`);
    return { ok: true, message: "Financeur mis à jour." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

export async function deleteFunderAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let orgId = "";
  try {
    const d = z.object({ orgId: uuid, funderId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    orgId = ctx.org.id;
    const before = await loadFunder(ctx, d.funderId);
    const [{ n }] = await db.select({ n: count() }).from(schema.fundings).where(and(eq(schema.fundings.orgId, ctx.org.id), eq(schema.fundings.funderId, before.id)));
    const [{ m }] = await db.select({ m: count() }).from(schema.invoices).where(and(eq(schema.invoices.orgId, ctx.org.id), eq(schema.invoices.funderId, before.id)));
    if (n || m) throw new Error(`Suppression refusée : ce financeur est rattaché à ${n} financement(s) et ${m} facture(s).`);
    await db.delete(schema.funders).where(eq(schema.funders.id, before.id));
    await audit({ action: "funder.delete", userId: ctx.user.id, orgId: ctx.org.id, entityType: "funder", entityId: before.id, before });
    revalidatePath(`${base(ctx.org.id)}/financeurs`);
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
  redirect(`${base(orgId)}/financeurs`);
}

// ---------------------------------------------------------------------------
// Financements
// ---------------------------------------------------------------------------

const fundingBaseSchema = z.object({
  orgId: uuid,
  kind: z.enum(FUNDER_KINDS),
  funderId: optUuid,
  label: z.string().trim().min(2, "Libellé du financement requis.").max(200),
  amount: euros,
  rateNote: optText(1000),
  notes: optText(4000),
  agreementRef: optText(120),
  agreementSource: optText(200),
  agreementDate: optDate,
  validFrom: optDate,
  validUntil: optDate,
});

async function checkFunder(ctx: OrgContext, funderId: string | null) {
  if (funderId) await loadFunder(ctx, funderId);
}

export async function createFundingAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target = "";
  try {
    const d = fundingBaseSchema.extend({ enrollmentId: uuid, status: z.enum(["prevu", "demande"]).default("prevu") }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const enr = await loadEnrollment(ctx, d.enrollmentId);
    await checkFunder(ctx, d.funderId);
    const amountCents = cents(d.amount, "Montant");
    if (amountCents <= 0) throw new Error("Le montant doit être positif.");
    const values = { enrollmentId: enr.id, kind: d.kind, funderId: d.funderId, label: d.label, amountCents, status: d.status, rateNote: d.rateNote, notes: d.notes, agreementRef: d.agreementRef, agreementSource: d.agreementSource, agreementDate: d.agreementDate, validFrom: d.validFrom, validUntil: d.validUntil, schedule: [] as ScheduleLine[] };
    const [row] = await db.insert(schema.fundings).values({ orgId: ctx.org.id, ...values }).returning();
    await audit({ action: "funding.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "funding", entityId: row.id, after: values });
    await recalcEnrollmentFundingState(ctx.org.id, enr.id, ctx.user.id);
    // Parcours automatique : appliqué au premier financement si l'inscription n'en a pas encore (CPF, AIF, public…).
    if (!enr.workflowCode) {
      try {
        const { applyWorkflow } = await import("@/server/workflows/service");
        await applyWorkflow({ orgId: ctx.org.id, userId: ctx.user.id }, enr.id);
      } catch (err) {
        console.error("[workflow] application après financement impossible", err);
      }
    }
    revalidatePath(`${base(ctx.org.id)}/financements`);
    revalidatePath(`${base(ctx.org.id)}/inscriptions/${enr.id}`);
    target = `${base(ctx.org.id)}/financements/${row.id}`;
  } catch (e) {
    return fail(e, "Création impossible.");
  }
  redirect(target);
}

const scheduleSchema = z.array(z.object({ label: z.string().trim().min(1, "Libellé d'échéance requis."), dueDate: isoDate, amountCents: z.number().int(), invoiceId: z.string().uuid().nullable().optional() }));

export async function updateFundingAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = fundingBaseSchema.extend({ fundingId: uuid, scheduleJson: z.string().default("[]") }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const before = await loadFunding(ctx, d.fundingId);
    if (before.status === "solde") throw new Error("Un financement soldé ne se modifie plus.");
    await checkFunder(ctx, d.funderId);
    const amountCents = cents(d.amount, "Montant");
    if (amountCents <= 0) throw new Error("Le montant doit être positif.");
    let parsedSchedule: unknown;
    try {
      parsedSchedule = JSON.parse(d.scheduleJson);
    } catch {
      throw new Error("Échéancier illisible.");
    }
    const incoming = scheduleSchema.parse(parsedSchedule);
    const previous = readSchedule(before.schedule);
    // Les lignes déjà facturées sont conservées à l'identique (montant figé, facture rattachée).
    const schedule: ScheduleLine[] = incoming.map((l) => {
      const prev = previous.find((p) => p.invoiceId && p.dueDate === l.dueDate && p.label === l.label);
      return prev ? prev : { label: l.label, dueDate: l.dueDate, amountCents: l.amountCents, invoiceId: null };
    });
    for (const p of previous) if (p.invoiceId && !schedule.some((s) => s.invoiceId === p.invoiceId)) throw new Error(`L'échéance « ${p.label} » est déjà facturée : elle ne peut pas être retirée.`);
    const err = validateSchedule(schedule, amountCents);
    if (err) throw new Error(err);
    if (["accorde", "facture"].includes(before.status)) {
      const e2 = fundingTransitionError("demande", "accorde", d);
      if (e2) throw new Error(`Financement accordé : ${e2.replace("Le passage à « accordé » exige", "la fiche doit conserver")}`);
    }
    const values = { kind: d.kind, funderId: d.funderId, label: d.label, amountCents, rateNote: d.rateNote, notes: d.notes, agreementRef: d.agreementRef, agreementSource: d.agreementSource, agreementDate: d.agreementDate, validFrom: d.validFrom, validUntil: d.validUntil, schedule };
    await db.update(schema.fundings).set(values).where(eq(schema.fundings.id, before.id));
    await audit({ action: "funding.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "funding", entityId: before.id, before, after: values });
    await relayOverdueSchedules(ctx.org.id);
    revalidatePath(`${base(ctx.org.id)}/financements`);
    revalidatePath(`${base(ctx.org.id)}/financements/${before.id}`);
    revalidatePath(`${base(ctx.org.id)}/inscriptions/${before.enrollmentId}`);
    return { ok: true, message: "Financement enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function changeFundingStatusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z
      .object({ orgId: uuid, fundingId: uuid, status: z.enum(FUNDING_STATUSES), reason: optText(500), agreementRef: optText(120), agreementSource: optText(200), agreementDate: optDate, validFrom: optDate, validUntil: optDate })
      .parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const before = await loadFunding(ctx, d.fundingId);
    const merged = {
      agreementRef: d.agreementRef ?? before.agreementRef,
      agreementSource: d.agreementSource ?? before.agreementSource,
      agreementDate: d.agreementDate ?? before.agreementDate,
      validFrom: d.validFrom ?? before.validFrom,
      validUntil: d.validUntil ?? before.validUntil,
    };
    const err = fundingTransitionError(before.status as FundingStatus, d.status, merged);
    if (err) throw new Error(err);
    if (d.status === "refuse" || d.status === "annule") {
      if (!d.reason) throw new Error("Indiquez le motif du refus ou de l'annulation (conservé dans l'audit).");
    }
    if (d.status === "facture") {
      const [{ n }] = await db.select({ n: count() }).from(schema.invoices).where(and(eq(schema.invoices.orgId, ctx.org.id), eq(schema.invoices.fundingId, before.id), inArray(schema.invoices.status, ["emise", "envoyee", "partiellement_payee", "payee", "en_retard"])));
      if (!n) throw new Error("Aucune facture émise n'est rattachée à ce financement : émettez d'abord la facture.");
    }
    await db.update(schema.fundings).set({ ...merged, notes: d.reason ? `${before.notes ? `${before.notes}\n` : ""}[${todayParis()}] ${d.status} : ${d.reason}` : before.notes }).where(eq(schema.fundings.id, before.id));
    const after = await setFundingStatus(ctx.org.id, before.id, d.status, ctx.user.id, d.reason ?? "Changement manuel");
    if (d.status === "accorde" && after) await relayFundingGranted(ctx.org.id, after, ctx.user.id, ctx.org.isDemo);
    if (d.status === "refuse" || d.status === "annule") await resolveTaskByKey(ctx.org.id, agreementPieceKey(before.id), `Financement ${d.status}.`, ctx.user.id);
    revalidatePath(`${base(ctx.org.id)}/financements`);
    revalidatePath(`${base(ctx.org.id)}/financements/${before.id}`);
    revalidatePath(`${base(ctx.org.id)}/inscriptions/${before.enrollmentId}`);
    return { ok: true, message: `Statut : ${d.status}.` };
  } catch (e) {
    return fail(e, "Changement de statut impossible.");
  }
}

export async function uploadFundingAgreementAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, fundingId: uuid }).parse(fd(formData));
    const file = formData.get("file");
    if (!(file instanceof File) || !file.size) throw new Error("Choisissez le document d'accord (PDF ou image).");
    const ctx = await requireFinance(d.orgId);
    const before = await loadFunding(ctx, d.fundingId);
    const data = Buffer.from(await file.arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head: data.subarray(0, 16) });
    if (!check.ok) throw new Error(check.error);
    const doc = await createDocument({
      orgId: ctx.org.id,
      enrollmentId: before.enrollmentId,
      category: "justificatif",
      visibility: "administratif",
      status: "valide",
      title: `Accord de prise en charge : ${before.label}`,
      fileName: file.name,
      mimeType: file.type || "application/octet-stream",
      data,
      sourceType: "funding",
      sourceId: before.id,
      uploadedBy: ctx.user.id,
      previousVersionId: before.documentId,
      retentionYears: 10,
      isDemo: ctx.org.isDemo,
    });
    await db.update(schema.fundings).set({ documentId: doc.id }).where(eq(schema.fundings.id, before.id));
    await audit({ action: "funding.agreement_upload", userId: ctx.user.id, orgId: ctx.org.id, entityType: "funding", entityId: before.id, before: { documentId: before.documentId }, after: { documentId: doc.id, fileName: file.name } });
    await resolveTaskByKey(ctx.org.id, agreementPieceKey(before.id), "Accord de prise en charge déposé.", ctx.user.id);
    revalidatePath(`${base(ctx.org.id)}/financements/${before.id}`);
    return { ok: true, message: "Document d'accord déposé." };
  } catch (e) {
    return fail(e, "Dépôt impossible.");
  }
}

export async function deleteFundingAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target = "";
  try {
    const d = z.object({ orgId: uuid, fundingId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const before = await loadFunding(ctx, d.fundingId);
    if (!["prevu", "demande", "annule", "refuse"].includes(before.status)) throw new Error("Seul un financement prévu, demandé, refusé ou annulé peut être supprimé ; sinon annulez-le.");
    const [{ n }] = await db.select({ n: count() }).from(schema.invoices).where(and(eq(schema.invoices.orgId, ctx.org.id), eq(schema.invoices.fundingId, before.id)));
    if (n) throw new Error("Des factures sont rattachées à ce financement : suppression refusée.");
    await db.delete(schema.fundings).where(eq(schema.fundings.id, before.id));
    await audit({ action: "funding.delete", userId: ctx.user.id, orgId: ctx.org.id, entityType: "funding", entityId: before.id, before });
    await resolveTaskByKey(ctx.org.id, agreementPieceKey(before.id), "Financement supprimé.", ctx.user.id);
    await recalcEnrollmentFundingState(ctx.org.id, before.enrollmentId, ctx.user.id);
    revalidatePath(`${base(ctx.org.id)}/financements`);
    target = `${base(ctx.org.id)}/financements?enrollment=${before.enrollmentId}`;
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
  redirect(target);
}

// ---------------------------------------------------------------------------
// Factures
// ---------------------------------------------------------------------------

const lineSchema = z.object({
  label: z.string().trim().min(1, "Libellé de ligne requis.").max(300),
  description: z.string().trim().max(1000).nullable().optional(),
  quantityMilli: z.number().int().positive("Quantité invalide."),
  unit: z.string().trim().min(1).max(30).default("forfait"),
  unitCents: z.number().int("Prix unitaire invalide."),
  vatRateBp: z.number().int().min(0).max(10000).default(0),
});

const invoiceSchema = z.object({
  orgId: uuid,
  kind: z.enum(["facture", "avoir", "acompte", "proforma"]).default("facture"),
  enrollmentId: optUuid,
  sessionId: optUuid,
  companyId: optUuid,
  funderId: optUuid,
  personId: optUuid,
  fundingId: optUuid,
  creditOfInvoiceId: optUuid,
  scheduleIndex: z.preprocess((v) => (v === "" || v === undefined ? null : Number(v)), z.number().int().min(0).nullable()),
  billToKind: z.enum(["entreprise", "financeur", "particulier"]).default("entreprise"),
  billToName: z.string().trim().min(2, "Nom du destinataire requis.").max(200),
  billToAddressLine1: z.string().trim().max(200).default(""),
  billToAddressLine2: z.string().trim().max(200).default(""),
  billToPostalCode: z.string().trim().max(12).default(""),
  billToCity: z.string().trim().max(120).default(""),
  billToSiret: z.string().trim().max(20).default(""),
  billToVatNumber: z.string().trim().max(20).default(""),
  billToEmail: z.string().trim().max(200).default(""),
  vatExempt: z.preprocess((v) => v === "on" || v === "1" || v === "true", z.boolean()),
  vatMention: optText(300),
  dueDate: optDate,
  servicePeriodStart: optDate,
  servicePeriodEnd: optDate,
  paymentTerms: optText(500),
  notes: optText(2000),
  linesJson: z.string().default("[]"),
  /** Acheteur public (Chorus Pro) : bon de commande, code service, engagement juridique, SIRET de l'acheteur. */
  purchaseOrderNumber: optText(60),
  serviceCode: optText(100),
  legalCommitment: optText(60),
  buyerSiret: optText(20),
});

async function invoiceValues(ctx: OrgContext, d: z.infer<typeof invoiceSchema>) {
  const orgId = ctx.org.id;
  if (d.enrollmentId) await loadEnrollment(ctx, d.enrollmentId);
  if (d.fundingId) {
    const f = await loadFunding(ctx, d.fundingId);
    if (d.enrollmentId && f.enrollmentId !== d.enrollmentId) throw new Error("Le financement n'appartient pas à cette inscription.");
    if (!["accorde", "facture", "solde"].includes(f.status)) throw new Error("Seul un financement accordé peut être facturé (passez-le d'abord au statut « accordé » avec sa référence de prise en charge).");
  }
  if (d.funderId) await loadFunder(ctx, d.funderId);
  if (d.companyId) {
    const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.id, d.companyId), eq(schema.companies.orgId, orgId))).limit(1);
    if (!c) throw new Error("Entreprise introuvable dans cet organisme.");
  }
  if (d.personId) {
    const [p] = await db.select({ id: schema.persons.id }).from(schema.persons).where(and(eq(schema.persons.id, d.personId), eq(schema.persons.orgId, orgId))).limit(1);
    if (!p) throw new Error("Personne introuvable dans cet organisme.");
  }
  if (d.sessionId) {
    const [s] = await db.select({ id: schema.trainingSessions.id }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, d.sessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
    if (!s) throw new Error("Session introuvable dans cet organisme.");
  }
  if (d.creditOfInvoiceId) {
    const o = await loadInvoice(ctx, d.creditOfInvoiceId);
    if (o.status === "brouillon") throw new Error("Un avoir ne peut viser qu'une facture émise.");
    if (d.kind !== "avoir") throw new Error("Seul un avoir peut viser une facture d'origine.");
  }
  if (d.billToSiret) {
    const r = checkSiret(d.billToSiret);
    if (!r.ok) throw new Error(`Destinataire : ${r.error}`);
    d.billToSiret = r.value;
  }
  if (d.billToEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.billToEmail)) throw new Error("Adresse e-mail du destinataire invalide.");
  if (d.buyerSiret) {
    const r = checkSiret(d.buyerSiret);
    if (!r.ok) throw new Error(`Acheteur public : ${r.error}`);
    d.buyerSiret = r.value;
  }
  let parsedLines: unknown;
  try {
    parsedLines = JSON.parse(d.linesJson);
  } catch {
    throw new Error("Lignes illisibles.");
  }
  const lines = z.array(lineSchema).parse(parsedLines);
  const totals = invoiceTotals(lines, d.vatExempt);
  if (d.servicePeriodStart && d.servicePeriodEnd && d.servicePeriodStart > d.servicePeriodEnd) throw new Error("La période de prestation est inversée.");
  const billTo = { kind: d.billToKind, name: d.billToName, addressLine1: d.billToAddressLine1, addressLine2: d.billToAddressLine2, postalCode: d.billToPostalCode, city: d.billToCity, siret: d.billToSiret, vatNumber: d.billToVatNumber, email: d.billToEmail };
  return {
    values: {
      kind: d.kind,
      enrollmentId: d.enrollmentId,
      sessionId: d.sessionId,
      companyId: d.companyId,
      funderId: d.funderId,
      personId: d.personId,
      fundingId: d.fundingId,
      creditOfInvoiceId: d.creditOfInvoiceId,
      billTo,
      vatExempt: d.vatExempt,
      vatMention: d.vatExempt ? VAT_EXEMPT_MENTION : d.vatMention,
      dueDate: d.dueDate,
      servicePeriodStart: d.servicePeriodStart,
      servicePeriodEnd: d.servicePeriodEnd,
      paymentTerms: d.paymentTerms ?? DEFAULT_PAYMENT_TERMS,
      notes: d.notes,
      purchaseOrderNumber: d.purchaseOrderNumber,
      serviceCode: d.serviceCode,
      legalCommitment: d.legalCommitment,
      buyerSiret: d.buyerSiret,
      totalHtCents: totals.totalHtCents,
      vatCents: totals.vatCents,
      totalTtcCents: totals.totalTtcCents,
      isDemo: ctx.org.isDemo,
    },
    lines: totals.lines,
  };
}

export async function createInvoiceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target = "";
  try {
    const d = invoiceSchema.parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const { values, lines } = await invoiceValues(ctx, d);
    const row = await db.transaction(async (tx) => {
      const [inv] = await tx.insert(schema.invoices).values({ orgId: ctx.org.id, status: "brouillon", issueDate: todayParis(), ...values }).returning();
      if (lines.length) {
        await tx.insert(schema.invoiceLines).values(lines.map((l, i) => ({ invoiceId: inv.id, position: i, label: l.label, description: l.description ?? null, quantity: l.quantityMilli, unit: l.unit, unitCents: l.unitCents, vatRateBp: l.vatRateBp, totalHtCents: l.totalHtCents, enrollmentId: values.enrollmentId })));
      }
      if (values.fundingId && d.scheduleIndex !== null) {
        const [f] = await tx.select({ schedule: schema.fundings.schedule }).from(schema.fundings).where(eq(schema.fundings.id, values.fundingId)).limit(1);
        const sched = readSchedule(f?.schedule);
        const line = sched[d.scheduleIndex];
        if (!line) throw new Error("Échéance introuvable.");
        if (line.invoiceId) throw new Error("Cette échéance est déjà facturée.");
        sched[d.scheduleIndex] = { ...line, invoiceId: inv.id };
        await tx.update(schema.fundings).set({ schedule: sched }).where(eq(schema.fundings.id, values.fundingId));
      }
      return inv;
    });
    await audit({ action: "invoice.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "invoice", entityId: row.id, after: { ...values, lines: lines.length } });
    revalidatePath(`${base(ctx.org.id)}/factures`);
    if (values.fundingId) revalidatePath(`${base(ctx.org.id)}/financements/${values.fundingId}`);
    target = `${base(ctx.org.id)}/factures/${row.id}`;
  } catch (e) {
    return fail(e, "Création impossible.");
  }
  redirect(target);
}

export async function updateInvoiceDraftAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = invoiceSchema.extend({ invoiceId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const before = await loadInvoice(ctx, d.invoiceId);
    if (before.status !== "brouillon") throw new Error("Une facture émise ne se modifie plus : créez un avoir.");
    const { values, lines } = await invoiceValues(ctx, d);
    await db.transaction(async (tx) => {
      await tx.update(schema.invoices).set(values).where(eq(schema.invoices.id, before.id));
      await tx.delete(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, before.id));
      if (lines.length) {
        await tx.insert(schema.invoiceLines).values(lines.map((l, i) => ({ invoiceId: before.id, position: i, label: l.label, description: l.description ?? null, quantity: l.quantityMilli, unit: l.unit, unitCents: l.unitCents, vatRateBp: l.vatRateBp, totalHtCents: l.totalHtCents, enrollmentId: values.enrollmentId })));
      }
    });
    await audit({ action: "invoice.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "invoice", entityId: before.id, before, after: { ...values, lines: lines.length } });
    revalidatePath(`${base(ctx.org.id)}/factures/${before.id}`);
    return { ok: true, message: "Brouillon enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deleteInvoiceDraftAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target = "";
  try {
    const d = z.object({ orgId: uuid, invoiceId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const before = await loadInvoice(ctx, d.invoiceId);
    if (before.status !== "brouillon") throw new Error("Seul un brouillon peut être supprimé ; une facture émise s'annule par un avoir.");
    if (before.fundingId) {
      const f = await loadFunding(ctx, before.fundingId);
      const sched = readSchedule(f.schedule).map((l) => (l.invoiceId === before.id ? { ...l, invoiceId: null } : l));
      await db.update(schema.fundings).set({ schedule: sched }).where(eq(schema.fundings.id, f.id));
    }
    await db.delete(schema.invoices).where(eq(schema.invoices.id, before.id));
    await audit({ action: "invoice.delete_draft", userId: ctx.user.id, orgId: ctx.org.id, entityType: "invoice", entityId: before.id, before });
    revalidatePath(`${base(ctx.org.id)}/factures`);
    target = `${base(ctx.org.id)}/factures`;
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
  redirect(target);
}

export async function issueInvoiceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, invoiceId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const inv = await issueInvoice(ctx, d.invoiceId);
    revalidatePath(`${base(ctx.org.id)}/factures`);
    revalidatePath(`${base(ctx.org.id)}/factures/${inv.id}`);
    if (inv.fundingId) revalidatePath(`${base(ctx.org.id)}/financements/${inv.fundingId}`);
    if (inv.enrollmentId) revalidatePath(`${base(ctx.org.id)}/inscriptions/${inv.enrollmentId}`);
    return { ok: true, message: `${inv.kind === "avoir" ? "Avoir" : "Facture"} ${inv.number} émis(e) et archivé(e) en PDF.` };
  } catch (e) {
    return fail(e, "Émission impossible.");
  }
}

export async function downloadInvoicePdfAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, invoiceId: uuid }).parse(fd(formData));
    const ctx = await requireOrg(d.orgId, "finance.view");
    const inv = await loadInvoice(ctx, d.invoiceId);
    if (!inv.documentId) throw new Error("Aucun PDF archivé : la facture n'est pas encore émise.");
    const link = await issueDownloadLink(inv.documentId, ctx.user.id);
    await audit({ action: "invoice.download", userId: ctx.user.id, orgId: ctx.org.id, entityType: "invoice", entityId: inv.id });
    return { ok: true, message: "Lien de téléchargement (valable 15 minutes) :", data: { link } };
  } catch (e) {
    return fail(e, "Téléchargement impossible.");
  }
}

function invoiceMail(ctx: OrgContext, inv: typeof schema.invoices.$inferSelect, reminder: boolean) {
  const billTo = inv.billTo as { name?: string };
  const orgName = ctx.org.tradeName ?? ctx.org.legalName;
  const remaining = inv.totalTtcCents - inv.paidCents;
  const title = reminder ? `Rappel : ${inv.kind === "avoir" ? "avoir" : "facture"} ${inv.number} en attente de règlement` : `${inv.kind === "avoir" ? "Avoir" : "Facture"} ${inv.number} de ${orgName}`;
  const body = `<p>Bonjour,</p><p>${reminder ? `Sauf erreur de notre part, la facture <strong>${inv.number}</strong> du ${fmtDate(inv.issueDate)}, échue le ${inv.dueDate ? fmtDate(inv.dueDate) : "-"}, reste à régler pour <strong>${formatCents(remaining)}</strong>.` : `Veuillez trouver ci-dessous les éléments de ${inv.kind === "avoir" ? "l'avoir" : "la facture"} <strong>${inv.number}</strong> émis(e) le ${fmtDate(inv.issueDate)} par ${orgName}.`}</p>
<table style="border-collapse:collapse;font-size:14px"><tr><td style="padding:4px 12px 4px 0">Destinataire</td><td>${billTo.name ?? ""}</td></tr><tr><td style="padding:4px 12px 4px 0">Montant HT</td><td>${formatCents(inv.totalHtCents)}</td></tr><tr><td style="padding:4px 12px 4px 0">${inv.vatExempt ? "Net à payer" : "Total TTC"}</td><td>${formatCents(inv.totalTtcCents)}</td></tr>${inv.paidCents ? `<tr><td style="padding:4px 12px 4px 0">Déjà réglé</td><td>${formatCents(inv.paidCents)}</td></tr><tr><td style="padding:4px 12px 4px 0">Reste à payer</td><td>${formatCents(remaining)}</td></tr>` : ""}<tr><td style="padding:4px 12px 4px 0">Échéance</td><td>${inv.dueDate ? fmtDate(inv.dueDate) : "-"}</td></tr></table>
<p>${inv.paymentTerms ?? ""}</p><p>${inv.vatMention ?? ""}</p><p>Le document PDF numéroté vous est transmis par ${orgName} ; il reste consultable auprès de votre interlocuteur habituel.</p><p>${orgName}${ctx.org.siret ? ` · SIRET ${ctx.org.siret}` : ""}${ctx.org.nda ? ` · NDA ${ctx.org.nda}` : ""}</p>`;
  return { subject: title, html: layoutMail(title, body), text: `${title}\nMontant : ${formatCents(inv.totalTtcCents)}\nReste à payer : ${formatCents(remaining)}\nÉchéance : ${inv.dueDate ?? "-"}` };
}

export async function sendInvoiceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, invoiceId: uuid, to: z.string().trim().email("Adresse e-mail du destinataire invalide."), reminder: z.string().optional() }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const inv = await loadInvoice(ctx, d.invoiceId);
    if (inv.status === "brouillon") throw new Error("Émettez la facture avant de l'envoyer.");
    if (inv.status === "annulee") throw new Error("Facture annulée.");
    const reminder = d.reminder === "1";
    if (reminder && inv.paidCents >= inv.totalTtcCents) throw new Error("Cette facture est soldée : aucune relance nécessaire.");
    const m = invoiceMail(ctx, inv, reminder);
    const res = await sendMail({ to: d.to, subject: m.subject, html: m.html, text: m.text, isDemo: ctx.org.isDemo });
    const billTo = inv.billTo as Record<string, string>;
    if (!reminder) await db.update(schema.invoices).set({ status: inv.status === "emise" ? "envoyee" : inv.status, sentAt: new Date(), billTo: { ...billTo, email: billTo.email || d.to } }).where(eq(schema.invoices.id, inv.id));
    else await db.update(schema.invoices).set({ notes: `${inv.notes ? `${inv.notes}\n` : ""}[${todayParis()}] Relance envoyée à ${d.to} (${res.status}).` }).where(eq(schema.invoices.id, inv.id));
    await audit({ action: reminder ? "invoice.remind" : "invoice.send", userId: ctx.user.id, orgId: ctx.org.id, entityType: "invoice", entityId: inv.id, after: { to: d.to, mailStatus: res.status } });
    revalidatePath(`${base(ctx.org.id)}/factures/${inv.id}`);
    revalidatePath(`${base(ctx.org.id)}/factures`);
    const note = res.status === "sent" ? "E-mail envoyé." : ctx.org.isDemo ? "Espace de démonstration : l'e-mail est journalisé mais ne part pas." : "E-mail journalisé dans la boîte d'envoi ; le service e-mail (RESEND_API_KEY) n'est pas configuré, rien n'est parti.";
    return { ok: true, message: `${reminder ? "Relance enregistrée." : "Facture marquée envoyée."} ${note}` };
  } catch (e) {
    return fail(e, "Envoi impossible.");
  }
}

export async function addPaymentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, invoiceId: uuid, amount: euros, date: isoDate, method: z.enum(schema.paymentMethodEnum.enumValues), reference: optText(120), note: optText(500) }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const inv = await loadInvoice(ctx, d.invoiceId);
    if (!OPEN_INVOICE_STATUSES.includes(inv.status) && inv.status !== "payee") throw new Error("Un règlement ne s'enregistre que sur une facture émise.");
    if (inv.kind === "avoir" || inv.kind === "proforma") throw new Error("Un avoir ou une pro forma ne reçoit pas de règlement ; utilisez le mode « compensation » sur la facture concernée.");
    if (d.date > todayParis()) throw new Error("La date du règlement ne peut pas être dans le futur.");
    const amountCents = cents(d.amount, "Montant");
    const err = checkPaymentAmount(inv.totalTtcCents, inv.paidCents, amountCents);
    if (err) throw new Error(err);
    if (d.method === "compensation" && !d.reference) throw new Error("Indiquez le numéro de l'avoir compensé en référence.");
    const [p] = await db.insert(schema.payments).values({ orgId: ctx.org.id, invoiceId: inv.id, amountCents, date: d.date, method: d.method, reference: d.reference, note: d.note, recordedBy: ctx.user.id }).returning();
    await audit({ action: "payment.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "payment", entityId: p.id, after: { invoiceId: inv.id, amountCents, date: d.date, method: d.method, reference: d.reference } });
    const upd = await recalcInvoicePayment(ctx.org.id, inv.id, ctx.user.id);
    if (inv.enrollmentId) await recalcEnrollmentFundingState(ctx.org.id, inv.enrollmentId, ctx.user.id);
    revalidatePath(`${base(ctx.org.id)}/factures/${inv.id}`);
    revalidatePath(`${base(ctx.org.id)}/factures`);
    return { ok: true, message: `Règlement de ${formatCents(amountCents)} enregistré. Statut : ${upd?.status}.` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deletePaymentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, paymentId: uuid, reason: z.string().trim().min(3, "Motif requis (conservé dans l'audit).") }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const [p] = await db.select().from(schema.payments).where(and(eq(schema.payments.id, d.paymentId), eq(schema.payments.orgId, ctx.org.id))).limit(1);
    if (!p) throw new Error("Règlement introuvable.");
    await db.delete(schema.payments).where(eq(schema.payments.id, p.id));
    await audit({ action: "payment.delete", userId: ctx.user.id, orgId: ctx.org.id, entityType: "payment", entityId: p.id, before: p, after: { reason: d.reason } });
    await recalcInvoicePayment(ctx.org.id, p.invoiceId, ctx.user.id);
    revalidatePath(`${base(ctx.org.id)}/factures/${p.invoiceId}`);
    return { ok: true, message: "Règlement retiré ; statut recalculé." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

export async function runOverdueAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const n = await markOverdueInvoices(ctx.org.id);
    const r = await relayOverdueSchedules(ctx.org.id);
    await audit({ action: "finance.overdue_run", userId: ctx.user.id, orgId: ctx.org.id, after: { invoices: n, ...r } });
    revalidatePath(`${base(ctx.org.id)}/factures`);
    revalidatePath(`${base(ctx.org.id)}/financements`);
    return { ok: true, message: `${n} facture(s) passée(s) en retard ; ${r.created} tâche(s) d'échéance créée(s), ${r.resolved} résolue(s).` };
  } catch (e) {
    return fail(e, "Recalcul impossible.");
  }
}

export async function updateAccountingSettingsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const acct = z.string().trim().regex(/^\d{3,12}$/, "Numéro de compte : 3 à 12 chiffres.");
    const d = z.object({ orgId: uuid, salesAccount: acct, customerAccount: acct, vatAccount: acct, journal: z.string().trim().regex(/^[A-Z0-9]{1,6}$/, "Code journal : 1 à 6 lettres ou chiffres en capitales.") }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const settings = (ctx.org.settings ?? {}) as Record<string, unknown>;
    const before = settings.accounting ?? null;
    const accounting = { salesAccount: d.salesAccount, customerAccount: d.customerAccount, vatAccount: d.vatAccount, journal: d.journal };
    await db.update(schema.organismes).set({ settings: { ...settings, accounting } }).where(eq(schema.organismes.id, ctx.org.id));
    await audit({ action: "finance.accounting_settings", userId: ctx.user.id, orgId: ctx.org.id, entityType: "organisme", entityId: ctx.org.id, before, after: accounting });
    revalidatePath(`${base(ctx.org.id)}/factures`);
    return { ok: true, message: "Comptes paramétrés." };
  } catch (e) {
    return fail(e, "Paramétrage impossible.");
  }
}

export async function cancelInvoiceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, invoiceId: uuid, reason: z.string().trim().min(3, "Motif requis.") }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const inv = await loadInvoice(ctx, d.invoiceId);
    if (inv.status === "brouillon" || inv.status === "annulee") throw new Error("Statut incompatible.");
    if (inv.paidCents > 0) throw new Error("Des règlements sont enregistrés : retirez-les ou émettez un avoir.");
    const credits = await db.select({ id: schema.invoices.id, total: schema.invoices.totalTtcCents }).from(schema.invoices).where(and(eq(schema.invoices.orgId, ctx.org.id), eq(schema.invoices.creditOfInvoiceId, inv.id), eq(schema.invoices.kind, "avoir"), inArray(schema.invoices.status, ["emise", "envoyee", "payee", "partiellement_payee"])));
    const credited = credits.reduce((a, c) => a + c.total, 0);
    if (credited < inv.totalTtcCents) throw new Error(`Une facture émise ne s'annule que par un avoir du même montant (avoirs émis : ${formatCents(credited)} sur ${formatCents(inv.totalTtcCents)}).`);
    await db.update(schema.invoices).set({ status: "annulee", notes: `${inv.notes ? `${inv.notes}\n` : ""}[${todayParis()}] Annulée : ${d.reason}` }).where(eq(schema.invoices.id, inv.id));
    await audit({ action: "invoice.cancel", userId: ctx.user.id, orgId: ctx.org.id, entityType: "invoice", entityId: inv.id, before: { status: inv.status }, after: { status: "annulee", reason: d.reason, credits: credits.map((c) => c.id) } });
    if (inv.fundingId) await syncFundingFromInvoices(ctx.org.id, inv.fundingId, ctx.user.id);
    revalidatePath(`${base(ctx.org.id)}/factures/${inv.id}`);
    revalidatePath(`${base(ctx.org.id)}/factures`);
    return { ok: true, message: "Facture annulée (soldée par avoir)." };
  } catch (e) {
    return fail(e, "Annulation impossible.");
  }
}

// ---------------------------------------------------------------------------
// Rapprochement bancaire
// ---------------------------------------------------------------------------

export async function importBankStatementAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target = "";
  try {
    const d = z.object({ orgId: uuid }).parse(fd(formData));
    const file = formData.get("file");
    if (!(file instanceof File) || !file.size) throw new Error("Choisissez un relevé bancaire au format CSV.");
    if (file.size > 2 * 1024 * 1024) throw new Error("Relevé trop volumineux (2 Mo maximum).");
    const ctx = await requireFinance(d.orgId);
    const text = Buffer.from(await file.arrayBuffer()).toString("utf8");
    const { rows, errors } = parseBankCsv(text);
    if (!rows.length) throw new Error(`Aucune ligne exploitable. ${errors.slice(0, 3).join(" ")}`);
    const doc = await createDocument({
      orgId: ctx.org.id,
      category: "autre",
      visibility: "interne",
      status: "genere",
      title: `Relevé bancaire importé le ${todayParis()} (${file.name})`,
      fileName: file.name.replace(/[^a-zA-Z0-9._-]/g, "_") || "releve.csv",
      mimeType: "text/csv",
      data: Buffer.from(text, "utf8"),
      sourceType: "bank_statement",
      generationData: { rows, errors, importedBy: ctx.user.id },
      uploadedBy: ctx.user.id,
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "bank.import", userId: ctx.user.id, orgId: ctx.org.id, entityType: "document", entityId: doc.id, after: { rows: rows.length, ignored: errors.length } });
    target = `${base(ctx.org.id)}/factures/rapprochement?releve=${doc.id}`;
  } catch (e) {
    return fail(e, "Import impossible.");
  }
  redirect(target);
}

export async function reconcilePaymentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, documentId: uuid, line: z.coerce.number().int(), invoiceId: uuid, amount: euros, date: isoDate, reference: optText(200) }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const inv = await loadInvoice(ctx, d.invoiceId);
    if (!OPEN_INVOICE_STATUSES.includes(inv.status)) throw new Error("Cette facture n'est pas ouverte au règlement.");
    const [doc] = await db.select({ id: schema.documents.id }).from(schema.documents).where(and(eq(schema.documents.id, d.documentId), eq(schema.documents.orgId, ctx.org.id))).limit(1);
    if (!doc) throw new Error("Relevé introuvable.");
    const amountCents = cents(d.amount, "Montant");
    const err = checkPaymentAmount(inv.totalTtcCents, inv.paidCents, amountCents);
    if (err) throw new Error(err);
    const ref = `RELEVE:${d.documentId}:${d.line}`;
    const [dup] = await db.select({ id: schema.payments.id }).from(schema.payments).where(and(eq(schema.payments.orgId, ctx.org.id), eq(schema.payments.note, ref))).limit(1);
    if (dup) throw new Error("Cette ligne de relevé est déjà rapprochée.");
    const [p] = await db.insert(schema.payments).values({ orgId: ctx.org.id, invoiceId: inv.id, amountCents, date: d.date, method: "virement", reference: d.reference, note: ref, recordedBy: ctx.user.id, reconciledAt: new Date() }).returning();
    await audit({ action: "payment.reconcile", userId: ctx.user.id, orgId: ctx.org.id, entityType: "payment", entityId: p.id, after: { invoiceId: inv.id, amountCents, date: d.date, statementLine: d.line, documentId: d.documentId } });
    await recalcInvoicePayment(ctx.org.id, inv.id, ctx.user.id);
    if (inv.enrollmentId) await recalcEnrollmentFundingState(ctx.org.id, inv.enrollmentId, ctx.user.id);
    revalidatePath(`${base(ctx.org.id)}/factures/rapprochement`);
    revalidatePath(`${base(ctx.org.id)}/factures/${inv.id}`);
    revalidatePath(`${base(ctx.org.id)}/factures`);
    return { ok: true, message: `Règlement rapproché sur ${inv.number}.` };
  } catch (e) {
    return fail(e, "Rapprochement impossible.");
  }
}

// ---------------------------------------------------------------------------
// BPF : dépenses
// ---------------------------------------------------------------------------

const expenseSchema = z.object({
  orgId: uuid,
  date: isoDate,
  label: z.string().trim().min(2, "Libellé requis.").max(200),
  category: z.string().trim().refine((c) => c in EXPENSE_CATEGORIES, "Catégorie inconnue."),
  supplier: optText(160),
  amountHt: euros,
  vat: z.preprocess((v) => (typeof v === "string" && v.trim() === "" ? "0" : v), euros),
  sessionId: optUuid,
});

export async function createExpenseAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = expenseSchema.parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    if (d.sessionId) {
      const [s] = await db.select({ id: schema.trainingSessions.id }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, d.sessionId), eq(schema.trainingSessions.orgId, ctx.org.id))).limit(1);
      if (!s) throw new Error("Session introuvable.");
    }
    const values = { date: d.date, label: d.label, category: d.category, supplier: d.supplier, amountHtCents: cents(d.amountHt, "Montant HT"), vatCents: cents(d.vat, "TVA"), sessionId: d.sessionId };
    if (values.amountHtCents < 0 || values.vatCents < 0) throw new Error("Montants négatifs refusés.");
    const [row] = await db.insert(schema.expenses).values({ orgId: ctx.org.id, ...values }).returning();
    await audit({ action: "expense.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "expense", entityId: row.id, after: values });
    revalidatePath(`${base(ctx.org.id)}/bpf/depenses`);
    revalidatePath(`${base(ctx.org.id)}/bpf`);
    return { ok: true, message: "Dépense enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function updateExpenseAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = expenseSchema.extend({ expenseId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const [before] = await db.select().from(schema.expenses).where(and(eq(schema.expenses.id, d.expenseId), eq(schema.expenses.orgId, ctx.org.id))).limit(1);
    if (!before) throw new Error("Dépense introuvable.");
    const values = { date: d.date, label: d.label, category: d.category, supplier: d.supplier, amountHtCents: cents(d.amountHt, "Montant HT"), vatCents: cents(d.vat, "TVA"), sessionId: d.sessionId };
    await db.update(schema.expenses).set(values).where(eq(schema.expenses.id, before.id));
    await audit({ action: "expense.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "expense", entityId: before.id, before, after: values });
    revalidatePath(`${base(ctx.org.id)}/bpf/depenses`);
    revalidatePath(`${base(ctx.org.id)}/bpf`);
    return { ok: true, message: "Dépense mise à jour." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

export async function deleteExpenseAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, expenseId: uuid }).parse(fd(formData));
    const ctx = await requireFinance(d.orgId);
    const [before] = await db.select().from(schema.expenses).where(and(eq(schema.expenses.id, d.expenseId), eq(schema.expenses.orgId, ctx.org.id))).limit(1);
    if (!before) throw new Error("Dépense introuvable.");
    await db.delete(schema.expenses).where(eq(schema.expenses.id, before.id));
    await audit({ action: "expense.delete", userId: ctx.user.id, orgId: ctx.org.id, entityType: "expense", entityId: before.id, before });
    revalidatePath(`${base(ctx.org.id)}/bpf/depenses`);
    revalidatePath(`${base(ctx.org.id)}/bpf`);
    return { ok: true, message: "Dépense supprimée." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

/** Lien de téléchargement d'un document rattaché (accord de prise en charge, relevé) pour finance.view. */
export async function downloadFinanceDocumentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = z.object({ orgId: uuid, documentId: uuid }).parse(fd(formData));
    const ctx = await requireOrg(d.orgId, "finance.view");
    const [doc] = await db.select({ id: schema.documents.id, category: schema.documents.category }).from(schema.documents).where(and(eq(schema.documents.id, d.documentId), eq(schema.documents.orgId, ctx.org.id))).limit(1);
    if (!doc) throw new Error("Document introuvable.");
    if (!["facture", "avoir", "justificatif", "autre", "bpf", "export"].includes(doc.category)) throw new Error("Ce document n'est pas consultable depuis la finance.");
    const link = await issueDownloadLink(doc.id, ctx.user.id);
    await audit({ action: "document.download", userId: ctx.user.id, orgId: ctx.org.id, entityType: "document", entityId: doc.id });
    return { ok: true, message: "Lien de téléchargement (valable 15 minutes) :", data: { link } };
  } catch (e) {
    return fail(e, "Téléchargement impossible.");
  }
}
