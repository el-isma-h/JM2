"use server";

import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requirePlatformAdmin } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { calculationNote, checkPrice, proposePrice } from "@/server/pricing/compute";
import type { ActionState } from "./auth";

const UNITS = schema.pricingUnitEnum.enumValues;

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

/** « 2,79 » ou « 2.79 » → 279 centimes (entiers, sans flottant). */
function eurosToCents(raw: FormDataEntryValue | null): number | null {
  const s = String(raw ?? "").replace(/[\s€]/g, "").replace(",", ".");
  if (!s) return null;
  const m = /^(\d+)(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new z.ZodError([{ code: "custom", message: `Montant invalide : « ${String(raw)} » (format 2,79).`, path: [], input: raw }]);
  return Number(m[1]) * 100 + Number((m[2] ?? "").padEnd(2, "0"));
}

const planSchema = z.object({
  id: z.string().uuid().optional().or(z.literal("")),
  code: z.string().trim().min(2).max(60).regex(/^[a-z0-9_]+$/, "Code : minuscules, chiffres et _ uniquement"),
  name: z.string().trim().min(2, "Nom requis").max(120),
  description: z.string().trim().max(500).optional(),
  unit: z.enum(UNITS),
  referenceLabel: z.string().trim().max(200).optional(),
  referenceUrl: z.string().trim().url("Adresse de la source invalide").optional().or(z.literal("")),
  referenceCheckedAt: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date de relevé invalide").optional().or(z.literal("")),
  discountPercent: z.string().trim().regex(/^\d{1,3}([.,]\d{1,2})?$/, "Remise invalide").default("10"),
  calculationNote: z.string().trim().max(500).optional(),
  sortOrder: z.coerce.number().int().min(0).max(10000).default(0),
  features: z.string().trim().max(4000).optional(),
});

/**
 * Enregistre une ligne de la grille (plan ou option). Règle : jamais au-dessus de 90 % de la référence (checkPrice) ;
 * un prix au-dessus du plafond est refusé, pas seulement signalé.
 */
export async function savePricingPlanAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const d = planSchema.parse(Object.fromEntries(formData));
    const discountRate = Math.round(Number(d.discountPercent.replace(",", ".")) * 100);
    if (discountRate > 10000) return { error: "La remise ne peut pas dépasser 100 %." };
    const referencePriceCents = eurosToCents(formData.get("reference"));
    const referenceMonthlyCents = eurosToCents(formData.get("referenceMonthly"));
    let priceCents = eurosToCents(formData.get("price"));
    let priceMonthlyCents = eurosToCents(formData.get("priceMonthly"));
    if (d.unit === "sur_devis") {
      priceCents = null;
      priceMonthlyCents = null;
    } else if (d.unit === "inclus") {
      priceCents = 0;
      priceMonthlyCents = 0;
    } else {
      if (priceCents === null) priceCents = proposePrice(referencePriceCents, discountRate);
      if (priceMonthlyCents === null) priceMonthlyCents = proposePrice(referenceMonthlyCents, discountRate);
    }
    if (d.unit !== "sur_devis" && d.unit !== "inclus" && priceCents === null) return { error: "Indiquez un prix Next Formation ou un prix de référence pour le calculer." };
    const check = checkPrice({ priceCents, referencePriceCents, discountRate, unit: d.unit });
    if (check.level === "danger") return { error: `Refusé : ${check.message}` };
    if (priceMonthlyCents !== null && referenceMonthlyCents !== null) {
      const m = checkPrice({ priceCents: priceMonthlyCents, referencePriceCents: referenceMonthlyCents, discountRate, unit: d.unit });
      if (m.level === "danger") return { error: `Refusé (prix sans engagement) : ${m.message}` };
    }
    const features = (d.features ?? "")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
    const values = {
      code: d.code,
      name: d.name,
      description: d.description || null,
      isOption: formData.get("isOption") === "on",
      unit: d.unit,
      priceCents,
      priceMonthlyCents,
      referencePriceCents,
      referenceMonthlyCents,
      referenceLabel: d.referenceLabel || null,
      referenceUrl: d.referenceUrl || null,
      referenceCheckedAt: d.referenceCheckedAt || null,
      discountRate,
      calculationNote: d.calculationNote || calculationNote(referencePriceCents, discountRate),
      features,
      isActive: formData.get("isActive") === "on",
      sortOrder: d.sortOrder,
    };
    let id = d.id || null;
    if (id) {
      const [before] = await db.select().from(schema.pricingPlans).where(eq(schema.pricingPlans.id, id)).limit(1);
      if (!before) return { error: "Ligne introuvable." };
      await db.update(schema.pricingPlans).set(values).where(eq(schema.pricingPlans.id, id));
      await audit({ action: "admin.pricing.update", userId: admin.id, entityType: "pricing_plan", entityId: id, before, after: values });
    } else {
      const [dup] = await db.select({ id: schema.pricingPlans.id }).from(schema.pricingPlans).where(eq(schema.pricingPlans.code, d.code)).limit(1);
      if (dup) return { error: "Ce code existe déjà." };
      const [row] = await db.insert(schema.pricingPlans).values(values).returning({ id: schema.pricingPlans.id });
      id = row.id;
      await audit({ action: "admin.pricing.create", userId: admin.id, entityType: "pricing_plan", entityId: id, after: values });
    }
    revalidatePath("/admin/tarifs");
    revalidatePath("/tarifs");
    revalidatePath("/");
    return { ok: true, message: check.level === "info" ? `Tarif enregistré. ${check.message}` : "Tarif enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}
