import "server-only";
import { db, schema } from "@/db";

/** Notification interne sans doublon (dedupeKey) : affichée dans l'application, jamais envoyée deux fois. */
export async function notify(input: { orgId: string; userId: string; title: string; body?: string; href?: string; kind?: string; dedupeKey?: string }) {
  await db
    .insert(schema.notifications)
    .values({ orgId: input.orgId, userId: input.userId, title: input.title, body: input.body ?? null, href: input.href ?? null, kind: input.kind ?? "info", dedupeKey: input.dedupeKey ?? null })
    .onConflictDoNothing();
}
