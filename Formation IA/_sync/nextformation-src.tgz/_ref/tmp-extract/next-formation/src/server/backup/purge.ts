import "server-only";
import { and, eq, inArray, isNotNull, notInArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { deleteObject } from "@/server/storage";

/**
 * Suppression définitive d'un tenant : lignes (cascade depuis `tenants`), fichiers de stockage,
 * utilisateurs rattachés qui n'ont aucun accès ailleurs. Les administrateurs plateforme ne sont jamais supprimés.
 * Le journal d'audit est conservé (pas de clé étrangère).
 */
export async function purgeTenant(tenantId: string): Promise<{ orgs: number; users: number; files: number }> {
  const orgs = await db.select({ id: schema.organismes.id, logoKey: schema.organismes.logoKey, signatureKey: schema.organismes.signatureKey }).from(schema.organismes).where(eq(schema.organismes.tenantId, tenantId));
  const orgIds = orgs.map((o) => o.id);

  const keys: string[] = [];
  for (const o of orgs) {
    if (o.logoKey) keys.push(o.logoKey);
    if (o.signatureKey) keys.push(o.signatureKey);
  }
  if (orgIds.length) {
    const docs = await db.select({ k: schema.documents.storageKey }).from(schema.documents).where(inArray(schema.documents.orgId, orgIds));
    keys.push(...docs.map((d) => d.k));
    const sigs = await db
      .select({ k: schema.attendances.signatureKey })
      .from(schema.attendances)
      .where(and(inArray(schema.attendances.orgId, orgIds), isNotNull(schema.attendances.signatureKey)));
    keys.push(...sigs.map((s) => s.k!).filter(Boolean));
    const periodSigs = await db
      .select({ k: schema.periods.trainerSignatureKey })
      .from(schema.periods)
      .where(and(inArray(schema.periods.orgId, orgIds), isNotNull(schema.periods.trainerSignatureKey)));
    keys.push(...periodSigs.map((s) => s.k!).filter(Boolean));
    const packages = await db
      .select({ k: schema.elearningModules.packageKey })
      .from(schema.elearningModules)
      .where(and(inArray(schema.elearningModules.orgId, orgIds), isNotNull(schema.elearningModules.packageKey)));
    keys.push(...packages.map((s) => s.k!).filter(Boolean));
    const plans = await db.select({ k: schema.sites.accessPlanKey }).from(schema.sites).where(and(inArray(schema.sites.orgId, orgIds), isNotNull(schema.sites.accessPlanKey)));
    keys.push(...plans.map((s) => s.k!).filter(Boolean));
  }
  const backups = await db.select({ k: schema.backups.storageKey }).from(schema.backups).where(eq(schema.backups.tenantId, tenantId));
  keys.push(...backups.map((b) => b.k));

  // Utilisateurs du tenant : supprimés sauf s'ils ont un accès à un organisme d'un autre tenant.
  const tenantUsers = await db
    .select({ id: schema.users.id, role: schema.users.platformRole })
    .from(schema.users)
    .where(eq(schema.users.tenantId, tenantId));
  let deletedUsers = 0;
  await db.transaction(async (tx) => {
    for (const u of tenantUsers) {
      if (u.role === "platform_admin") {
        await tx.update(schema.users).set({ tenantId: null }).where(eq(schema.users.id, u.id));
        continue;
      }
      const elsewhere = await tx
        .select({ id: schema.memberships.id })
        .from(schema.memberships)
        .where(orgIds.length ? and(eq(schema.memberships.userId, u.id), notInArray(schema.memberships.orgId, orgIds)) : eq(schema.memberships.userId, u.id))
        .limit(1);
      if (elsewhere.length) {
        await tx.update(schema.users).set({ tenantId: null }).where(eq(schema.users.id, u.id));
      } else {
        await tx.delete(schema.users).where(eq(schema.users.id, u.id));
        deletedUsers++;
      }
    }
    // memberships.user_id n'a pas de clé étrangère : la cascade depuis organismes les supprime.
    await tx.delete(schema.jobs).where(eq(schema.jobs.tenantId, tenantId));
    await tx.delete(schema.tenants).where(eq(schema.tenants.id, tenantId));
  });

  let files = 0;
  for (const k of new Set(keys)) {
    await deleteObject(k);
    files++;
  }
  return { orgs: orgIds.length, users: deletedUsers, files };
}
