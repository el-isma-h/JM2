/**
 * Phase qualité : référentiel validé, preuves reliées à des actions réelles, deux analyses immuables,
 * actions, réclamations, veille, enquêtes et réponses.
 */
import { and, eq, isNull } from "drizzle-orm";
import { schema } from "@/db";
import { addD, daysAgo } from "./util";
import { ALL_INDICATORS, MINIMAL_REFERENTIAL, type IndicatorSeed } from "./referential";
import { bump, type State, type Tx } from "./state";

type Level = (typeof schema.evidenceLevelEnum.enumValues)[number];
type EvidenceSeed = { key: string; indicator: string; level: Level; title: string; sourceType: string; sourceId: string; date: string; documentId?: string; sessionId?: string; enrollmentId?: string; programId?: string; note?: string; invalidated?: string };

export async function phaseQuality(tx: Tx, s: State) {
  const { orgId, users, rng } = s;
  const S = s.sessions;

  /* ---------- Référentiel : copie plateforme si elle existe, sinon référentiel minimal ---------- */
  const [platform] = await tx.select().from(schema.referentials).where(and(isNull(schema.referentials.orgId), eq(schema.referentials.status, "valide"))).limit(1);
  const [platformAny] = platform ? [platform] : await tx.select().from(schema.referentials).where(isNull(schema.referentials.orgId)).limit(1);
  const source = platformAny ?? null;
  const [ref] = await tx
    .insert(schema.referentials)
    .values({
      orgId,
      code: source?.code ?? "RNQ",
      title: source?.title ?? "Référentiel national qualité (Qualiopi), synthèse 7 critères / 32 indicateurs",
      version: source?.version ?? "v9-demo",
      source: source?.source ?? "Ministère du Travail, guide de lecture du RNQ (synthèse de démonstration)",
      sourceUrl: source?.sourceUrl ?? "https://travail-emploi.gouv.fr/qualiopi",
      effectiveFrom: source?.effectiveFrom ?? "2024-01-01",
      scope: "both",
      status: "actif",
      criteria: source?.criteria ?? MINIMAL_REFERENTIAL,
      validatedBy: users.quality,
      validatedAt: new Date(`${daysAgo(s.today, 60)}T10:00:00Z`),
    })
    .returning({ id: schema.referentials.id, criteria: schema.referentials.criteria });
  s.referentialId = ref.id;
  bump(s, "referentials", 1);
  const indicators: IndicatorSeed[] = (() => {
    const crit = ref.criteria as { indicators?: IndicatorSeed[] }[];
    const flat = Array.isArray(crit) ? crit.flatMap((c) => c.indicators ?? []) : [];
    return flat.length ? flat.map((i) => ({ ...i, requiresHuman: Boolean(i.requiresHuman), level: i.level ?? "organisationnel", evidenceHints: i.evidenceHints ?? [] })) : ALL_INDICATORS;
  })();

  /* ---------- Enquêtes ---------- */
  const scaleQ = (key: string, label: string) => ({ key, label, type: "scale", required: true, indicator: "IND_30" });
  const surveyRows = await tx
    .insert(schema.surveys)
    .values([
      { orgId, kind: "satisfaction_chaud", title: "Satisfaction à chaud : SST initial", description: "Envoyée le dernier jour de la session. Dénominateur : stagiaires présents à la dernière période ; exclusion des abandons.", questions: [scaleQ("q1", "Qualité de l'animation"), scaleQ("q2", "Adéquation du contenu avec vos besoins"), scaleQ("q3", "Organisation et accueil"), scaleQ("q4", "Mises en situation pratiques"), scaleQ("q5", "Recommanderiez-vous cette formation ?"), { key: "q6", label: "Commentaire libre", type: "text", required: false }], sessionId: S.sst1.id, programId: s.programs.sst.id, status: "cloturee", automation: { trigger: "session_end", delayDays: 0 }, createdBy: users.quality },
      { orgId, kind: "satisfaction_froid", title: "Satisfaction à froid (3 semaines) : Excel avancé", description: "Envoyée 21 jours après la fin de session. Dénominateur : stagiaires terminés.", questions: [scaleQ("q1", "Utilisez-vous les acquis dans votre travail ?"), scaleQ("q2", "Les objectifs annoncés ont-ils été atteints ?"), { key: "q3", label: "Qu'auriez-vous souhaité approfondir ?", type: "text", required: false }], sessionId: S.xls1.id, programId: s.programs.excel.id, status: "active", automation: { trigger: "session_end", delayDays: 21 }, createdBy: users.quality },
      { orgId, kind: "employeur", title: "Enquête employeurs : apprentis BTS GPME, premier mois", description: "Adressée aux maîtres d'apprentissage. Dénominateur : entreprises d'accueil avec apprenti en cours.", questions: [scaleQ("q1", "Intégration de l'apprenti dans l'entreprise"), scaleQ("q2", "Qualité des échanges avec le CFA"), scaleQ("q3", "Adéquation du rythme d'alternance"), { key: "q4", label: "Suggestions", type: "text", required: false }], sessionId: S.bts.id, programId: s.programs.bts.id, status: "active", automation: {}, createdBy: users.quality },
    ])
    .returning({ id: schema.surveys.id });
  s.surveyIds = { chaud: surveyRows[0].id, froid: surveyRows[1].id, employeur: surveyRows[2].id };
  const responses: (typeof schema.surveyResponses.$inferInsert)[] = [];
  const sst = s.enrollments.filter((e) => e.sessionKey === "sst1");
  for (const e of sst) {
    const a = { q1: rng.int(3, 5), q2: rng.int(3, 5), q3: rng.int(4, 5), q4: rng.int(4, 5), q5: rng.int(3, 5), q6: rng.pick(["Formateur très pédagogue.", "Plus de pratique sur le défibrillateur.", "", "Salle un peu petite pour les mises en situation.", "Parfait."]) };
    const score = Math.round(((a.q1 + a.q2 + a.q3 + a.q4 + a.q5) / 25) * 100);
    responses.push({ orgId, surveyId: surveyRows[0].id, enrollmentId: e.id, sentAt: new Date(`${S.sst1.endDate}T16:30:00Z`), answers: a, score, submittedAt: new Date(`${addD(S.sst1.endDate, rng.int(0, 3))}T18:00:00Z`) });
  }
  const xls = s.enrollments.filter((e) => e.sessionKey === "xls1");
  xls.forEach((e, i) => {
    const done = i < 2;
    const a = done ? { q1: rng.int(3, 5), q2: rng.int(4, 5), q3: rng.pick(["Power Query plus en détail.", "Les macros."]) } : {};
    responses.push({ orgId, surveyId: surveyRows[1].id, enrollmentId: e.id, sentAt: new Date(`${addD(S.xls1.endDate, 21)}T09:00:00Z`), answers: a, score: done ? Math.round((((a as { q1: number }).q1 + (a as { q2: number }).q2) / 10) * 100) : null, submittedAt: done ? new Date(`${addD(S.xls1.endDate, 22 + i)}T12:00:00Z`) : null });
  });
  const tutors = ["deschamps", "fournel", "distrimarche"].map((k) => s.contacts[k].find((c) => c.isTutor)!);
  tutors.forEach((c, i) => {
    const done = i === 1;
    responses.push({ orgId, surveyId: surveyRows[2].id, contactId: c.id, sentAt: new Date(`${daysAgo(s.today, 7)}T09:00:00Z`), answers: done ? { q1: 5, q2: 4, q3: 4, q4: "Prévoir un point mensuel avec le tuteur pédagogique." } : {}, score: done ? 87 : null, submittedAt: done ? new Date(`${daysAgo(s.today, 5)}T10:30:00Z`) : null });
  });
  await tx.insert(schema.surveyResponses).values(responses);
  bump(s, "surveys", 3);
  bump(s, "survey_responses", responses.length);

  /* ---------- Réclamations et veille ---------- */
  const complaintRows = await tx
    .insert(schema.complaints)
    .values([
      { orgId, source: "apprenant", personId: xls[2]?.personId ?? null, sessionId: S.xls1.id, receivedAt: addD(S.xls1.endDate, 1), subject: "Postes informatiques lents pendant la formation Excel", description: "Plusieurs postes de la salle informatique ont ralenti les exercices sur Power Query.", status: "traitee", resolution: "Remplacement de 4 postes (commande du 10 du mois), vérification avant chaque session bureautique ajoutée à la check-list.", resolvedAt: addD(S.xls1.endDate, 9), assigneeUserId: users.quality },
      { orgId, source: "entreprise", companyId: s.companies.distrimarche, sessionId: S.bts.id, receivedAt: daysAgo(s.today, 4), subject: "Convocation au BTS blanc reçue tardivement", description: "Le tuteur indique avoir reçu la convocation 10 jours avant l'épreuve, trop tard pour organiser l'absence de l'apprenti.", status: "en_cours", assigneeUserId: users.quality },
    ])
    .returning({ id: schema.complaints.id });
  s.complaintIds = complaintRows.map((r) => r.id);
  const watchRows = await tx
    .insert(schema.watchItems)
    .values([
      { orgId, kind: "reglementaire", title: "Niveaux de prise en charge des contrats d'apprentissage : mise à jour des NPEC", url: "https://www.francecompetences.fr/", summary: "Nouvelle grille applicable aux contrats signés à compter du 1er septembre.", date: daysAgo(s.today, 50), impact: "Vérifier les montants des financements OPCO du BTS GPME.", authorId: users.quality },
      { orgId, kind: "reglementaire", title: "Rappel : mentions obligatoires du certificat de réalisation", url: "https://travail-emploi.gouv.fr/", summary: "Modèle actualisé et attendus des financeurs en cas de contrôle de service fait.", date: daysAgo(s.today, 38), impact: "Modèle de certificat vérifié, conforme.", authorId: users.quality },
      { orgId, kind: "metiers", title: "Évolution des compétences attendues des assistants RH (observatoire de branche)", summary: "Montée en puissance des outils SIRH et de la paie dématérialisée.", date: daysAgo(s.today, 30), impact: "Renforcer le module paie du titre ARH (version 2 du programme).", authorId: users.pedagogy },
      { orgId, kind: "pedagogique", title: "Classe inversée et quiz formatifs : retour d'expérience en BTS", summary: "Article de la revue pédagogique fictive : usage des quiz avant séance.", date: daysAgo(s.today, 22), impact: "Expérimenter sur le bloc 1 (quiz e-learning déjà en place).", authorId: users.pedagogy },
      { orgId, kind: "handicap", title: "Ressource handicap formation : fiches d'aménagement actualisées", url: "https://www.agefiph.fr/", summary: "Fiches pratiques par type de handicap et aménagements d'épreuves.", date: daysAgo(s.today, 15), impact: "Diffusée aux formateurs ; appliquée au dossier avec tiers-temps.", authorId: users.quality },
      { orgId, kind: "reglementaire", title: "Sous-traitance : exigences de conformité des prestataires (indicateur 27)", summary: "Contrôle du NDA, de l'assurance et du CV du sous-traitant à chaque convention.", date: daysAgo(s.today, 6), impact: "Dossier Prévenlys à compléter (contrat de sous-traitance signé manquant).", authorId: users.quality },
    ])
    .returning({ id: schema.watchItems.id });
  s.watchIds = watchRows.map((r) => r.id);
  bump(s, "complaints", 2);
  bump(s, "watch_items", watchRows.length);

  /* ---------- Preuves ---------- */
  const D = s.documents;
  const closedArh = s.periods.filter((p) => p.sessionKey === "arh" && p.status === "cloturee");
  const closedBts = s.periods.filter((p) => p.sessionKey === "bts" && p.groupIdx === 0 && p.status === "cloturee");
  const ines = s.enrollments.find((e) => e.isInes)!;
  const btsA = s.enrollments.filter((e) => e.sessionKey === "bts" && e.groupIdx === 0 && e.status === "en_cours");
  const sstDone = s.enrollments.filter((e) => e.sessionKey === "sst1");
  const seeds: EvidenceSeed[] = [
    { key: "prog_bts", indicator: "IND_1", level: "organisationnel", title: "Programme publié : BTS Gestion de la PME", sourceType: "document", sourceId: D["programme:bts"], documentId: D["programme:bts"], programId: s.programs.bts.id, date: daysAgo(s.today, 58) },
    { key: "prog_arh", indicator: "IND_1", level: "organisationnel", title: "Programme publié : titre pro ARH", sourceType: "document", sourceId: D["programme:arh"], documentId: D["programme:arh"], programId: s.programs.arh.id, date: daysAgo(s.today, 58) },
    { key: "prog_sst", indicator: "IND_1", level: "organisationnel", title: "Programme publié : SST", sourceType: "document", sourceId: D["programme:sst"], documentId: D["programme:sst"], programId: s.programs.sst.id, date: daysAgo(s.today, 58) },
    { key: "obj_bts", indicator: "IND_5", level: "collectif", title: "Objectifs opérationnels de la version 1 du BTS GPME", sourceType: "program_version", sourceId: s.programs.bts.versionId, programId: s.programs.bts.id, date: daysAgo(s.today, 58) },
    { key: "obj_arh", indicator: "IND_5", level: "collectif", title: "Objectifs opérationnels de la version 1 du titre ARH", sourceType: "program_version", sourceId: s.programs.arh.versionId, programId: s.programs.arh.id, date: daysAgo(s.today, 58) },
    { key: "mod_arh", indicator: "IND_6", level: "collectif", title: "Modules et modalités du titre ARH (720 h, mixte)", sourceType: "program_version", sourceId: s.programs.arh.versionId, programId: s.programs.arh.id, date: daysAgo(s.today, 58) },
    { key: "cert_arh", indicator: "IND_7", level: "collectif", title: "Alignement des modules sur les CCP du titre ARH (RNCP35030)", sourceType: "certification", sourceId: s.certifications.rncp_arh, programId: s.programs.arh.id, date: daysAgo(s.today, 58), note: "À examiner par un humain : vérification du référentiel de certification." },
    { key: "pos_ines", indicator: "IND_8", level: "individuel", title: `Positionnement d'entrée : ${ines.personName}`, sourceType: "enrollment", sourceId: ines.id, enrollmentId: ines.id, sessionId: S.bts.id, date: S.bts.startDate },
    { key: "pos_arh", indicator: "IND_8", level: "individuel", title: `Positionnement d'entrée : ${s.enrollments.find((e) => e.sessionKey === "arh")!.personName}`, sourceType: "enrollment", sourceId: s.enrollments.find((e) => e.sessionKey === "arh")!.id, enrollmentId: s.enrollments.find((e) => e.sessionKey === "arh")!.id, sessionId: S.arh.id, date: S.arh.startDate },
    { key: "need_clinique", indicator: "IND_4", level: "individuel", title: "Analyse du besoin : Clinique Sainte-Odile (intra accueil)", sourceType: "need", sourceId: s.companies.clinique, date: daysAgo(s.today, 22) },
    ...s.enrollments.filter((e) => e.sessionKey === "mgt" && D[`convocation:${e.id}`]).slice(0, 2).map((e, i) => ({ key: `conv_${i}`, indicator: "IND_9", level: "individuel" as Level, title: `Convocation transmise : ${e.personName}`, sourceType: "document", sourceId: D[`convocation:${e.id}`], documentId: D[`convocation:${e.id}`], enrollmentId: e.id, sessionId: S.mgt.id, date: daysAgo(s.today, 2) })),
    { key: "plan_indiv", indicator: "IND_10", level: "individuel", title: "Plan individuel avec aménagements (tiers-temps, supports agrandis)", sourceType: "enrollment", sourceId: btsA[7]?.id ?? ines.id, enrollmentId: btsA[7]?.id ?? ines.id, sessionId: S.bts.id, date: addD(S.bts.startDate, 3), note: "Aménagements validés avec la référente handicap ; à examiner par un humain." },
    ...sstDone.slice(0, 3).map((e, i) => ({ key: `cert_${i}`, indicator: "IND_11", level: "individuel" as Level, title: `Certificat de réalisation : ${e.personName}`, sourceType: "document", sourceId: D[`certificat:${e.id}`], documentId: D[`certificat:${e.id}`], enrollmentId: e.id, sessionId: S.sst1.id, date: addD(S.sst1.endDate, 2) })),
    ...closedArh.slice(-3).map((p, i) => ({ key: `per_arh_${i}`, indicator: "IND_12", level: "collectif" as Level, title: `Période clôturée (émargement) : ${p.date} ${p.part}`, sourceType: "period", sourceId: p.id, documentId: D[`emargement:${p.id}`], sessionId: S.arh.id, date: p.date })),
    ...closedBts.slice(-2).map((p, i) => ({ key: `per_bts_${i}`, indicator: "IND_12", level: "collectif" as Level, title: `Période clôturée (émargement) : ${p.date} ${p.part}`, sourceType: "period", sourceId: p.id, documentId: D[`emargement:${p.id}`], sessionId: S.bts.id, date: p.date })),
    { key: "suivi_ines", indicator: "IND_13", level: "individuel", title: `Visite en entreprise : ${ines.personName} (Deschamps Agencement)`, sourceType: "enrollment", sourceId: ines.id, enrollmentId: ines.id, sessionId: S.bts.id, date: daysAgo(s.today, 12) },
    { key: "livret_bts", indicator: "IND_13", level: "collectif", title: "Livret d'apprentissage partagé avec les maîtres d'apprentissage (groupe A)", sourceType: "session", sourceId: S.bts.id, sessionId: S.bts.id, date: addD(S.bts.startDate, 21) },
    { key: "droits", indicator: "IND_15", level: "collectif", title: "Règlement intérieur et livret d'accueil remis à la rentrée (BTS)", sourceType: "session", sourceId: S.bts.id, sessionId: S.bts.id, date: S.bts.startDate },
    { key: "blanc", indicator: "IND_16", level: "collectif", title: "BTS blanc n° 1 programmé (cohorte convoquée)", sourceType: "cohort", sourceId: s.cohorts.btsBlanc, sessionId: S.bts.id, date: daysAgo(s.today, 3) },
    { key: "jury", indicator: "IND_16", level: "collectif", title: "Jury titre ARH session A : résultats enregistrés", sourceType: "cohort", sourceId: s.cohorts.arhA, sessionId: S.arhA.id, date: addD(S.arhA.endDate, 19) },
    { key: "sites", indicator: "IND_17", level: "organisationnel", title: "Sites, salles et équipements (Paris 11e, Montreuil)", sourceType: "site", sourceId: s.siteIds.paris, date: daysAgo(s.today, 58) },
    { key: "coord", indicator: "IND_18", level: "organisationnel", title: "Affectation des formateurs par session et réunion pédagogique de rentrée", sourceType: "session", sourceId: S.bts.id, sessionId: S.bts.id, date: addD(S.bts.startDate, -7) },
    { key: "elearning", indicator: "IND_19", level: "collectif", title: "Ressources e-learning du titre ARH (paie, droit social)", sourceType: "elearning_module", sourceId: s.elearningIds[0], date: daysAgo(s.today, 45) },
    { key: "cv_claire", indicator: "IND_21", level: "organisationnel", title: "CV et certification TOSA : Claire Vasseur", sourceType: "document", sourceId: D["cv:claire"], documentId: D["cv:claire"], date: daysAgo(s.today, 40) },
    { key: "cv_isabelle", indicator: "IND_21", level: "organisationnel", title: "CV et titre de formateur : Isabelle Tanguy", sourceType: "document", sourceId: D["cv:isabelle"], documentId: D["cv:isabelle"], date: daysAgo(s.today, 40) },
    { key: "veille_1", indicator: "IND_23", level: "organisationnel", title: "Veille réglementaire : NPEC apprentissage", sourceType: "watch_item", sourceId: s.watchIds[0], date: daysAgo(s.today, 50) },
    { key: "veille_2", indicator: "IND_23", level: "organisationnel", title: "Veille réglementaire : certificat de réalisation", sourceType: "watch_item", sourceId: s.watchIds[1], date: daysAgo(s.today, 38) },
    { key: "veille_3", indicator: "IND_24", level: "organisationnel", title: "Veille métiers : compétences des assistants RH", sourceType: "watch_item", sourceId: s.watchIds[2], date: daysAgo(s.today, 30) },
    { key: "veille_4", indicator: "IND_25", level: "organisationnel", title: "Veille pédagogique : classe inversée et quiz", sourceType: "watch_item", sourceId: s.watchIds[3], date: daysAgo(s.today, 22) },
    { key: "handicap", indicator: "IND_26", level: "organisationnel", title: "Référente handicap désignée et fiches d'aménagement diffusées", sourceType: "watch_item", sourceId: s.watchIds[4], date: daysAgo(s.today, 15) },
    { key: "soustraitance", indicator: "IND_27", level: "organisationnel", title: "Contrat de sous-traitance Prévenlys (SST)", sourceType: "trainer", sourceId: s.trainers.antoine, date: daysAgo(s.today, 45), invalidated: "Le document joint est le devis, pas le contrat de sous-traitance signé : preuve invalidée, contrat à produire." },
    { key: "situations", indicator: "IND_28", level: "individuel", title: "Articulation centre / entreprise : activités consignées au livret (groupe A)", sourceType: "enrollment", sourceId: btsA[1]?.id ?? ines.id, enrollmentId: btsA[1]?.id ?? ines.id, sessionId: S.bts.id, date: addD(S.bts.startDate, 21) },
    { key: "enq_chaud", indicator: "IND_30", level: "collectif", title: "Enquête de satisfaction à chaud SST : 9 réponses sur 9", sourceType: "survey", sourceId: surveyRows[0].id, sessionId: S.sst1.id, date: addD(S.sst1.endDate, 3) },
    { key: "enq_emp", indicator: "IND_30", level: "collectif", title: "Enquête employeurs BTS : première réponse reçue", sourceType: "survey", sourceId: surveyRows[2].id, sessionId: S.bts.id, date: daysAgo(s.today, 5) },
    { key: "reclam", indicator: "IND_31", level: "organisationnel", title: "Réclamation traitée : postes informatiques (Excel avancé)", sourceType: "complaint", sourceId: complaintRows[0].id, sessionId: S.xls1.id, date: addD(S.xls1.endDate, 9) },
    { key: "amelio", indicator: "IND_32", level: "organisationnel", title: "Plan d'amélioration : actions issues de la réclamation et de l'enquête à chaud", sourceType: "complaint", sourceId: complaintRows[0].id, date: addD(S.xls1.endDate, 10), note: "À examiner par un humain : efficacité des actions à vérifier à 3 mois." },
    { key: "resultats", indicator: "IND_2", level: "organisationnel", title: "Indicateurs de résultats 2025 publiés sur le site (satisfaction 92 %, réussite ARH 80 %)", sourceType: "site", sourceId: s.siteIds.paris, date: daysAgo(s.today, 100), note: "À examiner par un humain : vérifier la méthode de calcul affichée." },
    { key: "taux_certif", indicator: "IND_3", level: "organisationnel", title: "Taux d'obtention du titre ARH session A : 6 admis sur 10", sourceType: "cohort", sourceId: s.cohorts.arhA, date: addD(S.arhA.endDate, 19), note: "À examiner par un humain." },
  ];
  const evidenceRows = await tx
    .insert(schema.qualityEvidences)
    .values(
      seeds.map((e) => ({
        orgId,
        referentialId: ref.id,
        indicatorCode: e.indicator,
        level: e.level,
        enrollmentId: e.enrollmentId ?? null,
        sessionId: e.sessionId ?? null,
        programId: e.programId ?? null,
        documentId: e.documentId ?? null,
        sourceType: e.sourceType,
        sourceId: e.sourceId,
        title: e.title,
        note: e.note ?? null,
        evidenceDate: e.date,
        status: e.invalidated ? ("invalidee" as const) : ("valide" as const),
        invalidatedAt: e.invalidated ? new Date(`${daysAgo(s.today, 6)}T11:00:00Z`) : null,
        invalidatedBy: e.invalidated ? users.quality : null,
        invalidationReason: e.invalidated ?? null,
        createdBy: users.quality,
      })),
    )
    .returning({ id: schema.qualityEvidences.id });
  seeds.forEach((e, i) => (s.evidenceIds[e.key] = evidenceRows[i].id));
  bump(s, "quality_evidences", evidenceRows.length);

  /* ---------- Analyses immuables (ancienne puis récente) ---------- */
  const NOT_APPLICABLE = new Set(["IND_20"]);
  const build = (referenceDate: string, includeInvalidated: boolean) => {
    const controls = indicators.map((ind) => {
      const ev = seeds.map((e, i) => ({ e, id: evidenceRows[i].id })).filter(({ e }) => e.indicator === ind.code && e.date <= referenceDate && (includeInvalidated || !e.invalidated));
      const status = NOT_APPLICABLE.has(ind.code) ? "non_applicable" : ev.length === 0 ? "absent" : ind.requiresHuman || ev.some(({ e }) => e.note?.startsWith("À examiner")) ? "a_examiner" : "prouve";
      return { indicator: ind.code, label: ind.label, status, evidenceIds: ev.map((x) => x.id), note: status === "non_applicable" ? "Aucune demande de mobilité sur la période." : status === "absent" ? "Aucune preuve reliée à une action réelle." : status === "a_examiner" ? "Preuve présente, validation humaine requise." : null };
    });
    const count = (st: string) => controls.filter((c) => c.status === st).length;
    const total = controls.length;
    const notApplicable = count("non_applicable");
    const summary = { total, proven: count("prouve"), missing: count("absent"), notApplicable, humanReview: count("a_examiner"), coveragePct: Math.round((count("prouve") / Math.max(1, total - notApplicable)) * 100), disclaimer: "Un pourcentage n'est pas une attestation de conformité." };
    return { controls, summary };
  };
  const oldDate = daysAgo(s.today, 30);
  const older = build(oldDate, true);
  const recent = build(s.today, false);
  const [oldRow] = await tx.insert(schema.qualityAnalyses).values({ orgId, referentialId: ref.id, scope: "organisme", engineVersion: "1.0.0", referenceDate: oldDate, controls: older.controls, summary: older.summary, createdBy: users.quality, createdAt: new Date(`${oldDate}T09:00:00Z`) }).returning({ id: schema.qualityAnalyses.id });
  const [recentRow] = await tx.insert(schema.qualityAnalyses).values({ orgId, referentialId: ref.id, scope: "organisme", engineVersion: "1.0.0", referenceDate: s.today, controls: recent.controls, summary: recent.summary, createdBy: users.quality }).returning({ id: schema.qualityAnalyses.id });
  await tx.update(schema.qualityAnalyses).set({ supersededById: recentRow.id }).where(eq(schema.qualityAnalyses.id, oldRow.id));
  s.analysisIds = { old: oldRow.id, recent: recentRow.id };
  bump(s, "quality_analyses", 2);

  /* ---------- Actions qualité ---------- */
  const actionRows = await tx
    .insert(schema.qualityActions)
    .values([
      { orgId, analysisId: recentRow.id, indicatorCode: "IND_27", title: "Obtenir le contrat de sous-traitance signé de Prévenlys", description: "La preuve enregistrée était un devis ; le contrat signé avec NDA et attestation d'assurance est à produire.", assigneeUserId: users.quality, dueDate: addD(s.today, 7), status: "en_cours", origin: "analyse" },
      { orgId, analysisId: recentRow.id, indicatorCode: "IND_2", title: "Publier les indicateurs de résultats 2026 avec la méthode de calcul", description: "Mettre à jour la page « résultats » du site avec les dénominateurs utilisés.", assigneeUserId: users.direction, dueDate: addD(s.today, 30), status: "a_faire", origin: "analyse" },
      { orgId, indicatorCode: "IND_31", title: "Renouveler les postes de la salle informatique", description: "Issue de la réclamation sur la session Excel avancé.", assigneeUserId: users.admin, dueDate: addD(S.xls1.endDate, 9), status: "terminee", origin: "reclamation", closedAt: new Date(`${addD(S.xls1.endDate, 9)}T16:00:00Z`) },
      { orgId, indicatorCode: "IND_9", title: "Envoyer les convocations d'examen 21 jours avant l'épreuve", description: "Issue de la réclamation Distrimarché : règle à inscrire dans la procédure examens.", assigneeUserId: users.pedagogy, dueDate: addD(s.today, 14), status: "a_faire", origin: "reclamation" },
    ])
    .returning({ id: schema.qualityActions.id });
  s.qualityActionIds = actionRows.map((r) => r.id);
  await tx.update(schema.complaints).set({ qualityActionId: actionRows[2].id }).where(eq(schema.complaints.id, complaintRows[0].id));
  await tx.update(schema.complaints).set({ qualityActionId: actionRows[3].id }).where(eq(schema.complaints.id, complaintRows[1].id));
  bump(s, "quality_actions", actionRows.length);
}
