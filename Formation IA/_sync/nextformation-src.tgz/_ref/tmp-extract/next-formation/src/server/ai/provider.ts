/**
 * Abstraction multi-fournisseurs pour l'assistant et les agents IA.
 * Une seule clé suffit : Anthropic (ANTHROPIC_API_KEY), OpenAI (OPENAI_API_KEY) ou xAI Grok (XAI_API_KEY).
 * Ordre par défaut : Anthropic, OpenAI, xAI ; surchargeable par AI_PROVIDER=anthropic|openai|xai.
 * Module pur (sans accès base) : `pickProvider` et `aiStatus` sont testés dans __tests__/provider.test.ts.
 */

export type ProviderName = "anthropic" | "openai" | "xai";

export type ProviderConfig = { name: ProviderName; apiKey: string; model: string; baseUrl?: string };

export type ChatMessage = { role: "user" | "assistant"; content: string };

export type CompleteInput = {
  system: string;
  messages: ChatMessage[];
  /** Demande une réponse JSON (objet) : le texte retourné est le JSON brut. */
  json?: boolean;
  maxTokens?: number;
  temperature?: number;
};

export type CompleteResult = { text: string; provider: ProviderName; model: string; usage?: { input?: number; output?: number } };

export const PROVIDER_ORDER: ProviderName[] = ["anthropic", "openai", "xai"];

export const PROVIDER_LABELS: Record<ProviderName, string> = { anthropic: "Anthropic (Claude)", openai: "OpenAI", xai: "xAI (Grok)" };

export const DEFAULT_MODELS: Record<ProviderName, string> = { anthropic: "claude-sonnet-4-5", openai: "gpt-4o-mini", xai: "grok-3-mini" };

const ENV_KEYS: Record<ProviderName, { key: string; model: string }> = {
  anthropic: { key: "ANTHROPIC_API_KEY", model: "ANTHROPIC_MODEL" },
  openai: { key: "OPENAI_API_KEY", model: "OPENAI_MODEL" },
  xai: { key: "XAI_API_KEY", model: "XAI_MODEL" },
};

export type Env = Record<string, string | undefined>;

function configFor(name: ProviderName, env: Env): ProviderConfig | null {
  const key = (env[ENV_KEYS[name].key] ?? "").trim();
  if (!key) return null;
  const model = (env[ENV_KEYS[name].model] ?? "").trim() || DEFAULT_MODELS[name];
  return { name, apiKey: key, model, baseUrl: name === "xai" ? "https://api.x.ai/v1" : name === "openai" ? (env.OPENAI_BASE_URL ?? "https://api.openai.com/v1") : undefined };
}

/** Fournisseurs configurés, dans l'ordre de priorité (surcharge AI_PROVIDER placée en tête si configurée). */
export function configuredProviders(env: Env = process.env): ProviderConfig[] {
  const forced = (env.AI_PROVIDER ?? "").trim().toLowerCase() as ProviderName | "";
  const order = forced && PROVIDER_ORDER.includes(forced) ? [forced, ...PROVIDER_ORDER.filter((p) => p !== forced)] : PROVIDER_ORDER;
  return order.map((n) => configFor(n, env)).filter((c): c is ProviderConfig => Boolean(c));
}

/** Premier fournisseur configuré, ou null. */
export function pickProvider(env: Env = process.env): ProviderConfig | null {
  return configuredProviders(env)[0] ?? null;
}

export type AiStatus = { configured: true; provider: ProviderName; model: string; label: string } | { configured: false; explanation: string; envVars: string[] };

/** État de configuration lisible (affiché sur l'écran assistant sans clé). */
export function aiStatus(env: Env = process.env): AiStatus {
  const p = pickProvider(env);
  if (p) return { configured: true, provider: p.name, model: p.model, label: PROVIDER_LABELS[p.name] };
  return {
    configured: false,
    explanation: "Aucune clé d'API IA n'est renseignée. Une seule clé suffit : ANTHROPIC_API_KEY, OPENAI_API_KEY ou XAI_API_KEY (modèle facultatif : ANTHROPIC_MODEL, OPENAI_MODEL, XAI_MODEL ; priorité : AI_PROVIDER).",
    envVars: ["ANTHROPIC_API_KEY", "OPENAI_API_KEY", "XAI_API_KEY"],
  };
}

export class AiNotConfiguredError extends Error {
  constructor() {
    super("Assistant IA non configuré : renseignez ANTHROPIC_API_KEY, OPENAI_API_KEY ou XAI_API_KEY.");
  }
}

/** Extrait un objet JSON d'une réponse de modèle (tolère les balises ``` et le texte autour). */
export function extractJson(text: string): unknown {
  const trimmed = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  try {
    return JSON.parse(trimmed);
  } catch {
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(trimmed.slice(start, end + 1));
      } catch {
        return null;
      }
    }
    return null;
  }
}

/** Appel de complétion sur le fournisseur configuré. Lève AiNotConfiguredError sans clé. */
export async function complete(input: CompleteInput, env: Env = process.env): Promise<CompleteResult> {
  const p = pickProvider(env);
  if (!p) throw new AiNotConfiguredError();
  const maxTokens = input.maxTokens ?? 1500;
  const temperature = input.temperature ?? 0.2;
  const system = input.json ? `${input.system}\n\nRéponds uniquement par un objet JSON valide, sans texte autour.` : input.system;

  if (p.name === "anthropic") {
    const { default: Anthropic } = await import("@anthropic-ai/sdk");
    const client = new Anthropic({ apiKey: p.apiKey });
    const res = await client.messages.create({
      model: p.model,
      max_tokens: maxTokens,
      temperature,
      system,
      messages: input.messages.map((m) => ({ role: m.role, content: m.content })),
    });
    const text = res.content
      .map((b) => (b.type === "text" ? b.text : ""))
      .filter(Boolean)
      .join("\n");
    return { text, provider: p.name, model: p.model, usage: { input: res.usage?.input_tokens, output: res.usage?.output_tokens } };
  }

  // OpenAI et xAI : API REST « chat completions » compatible, sans SDK.
  const body: Record<string, unknown> = {
    model: p.model,
    max_tokens: maxTokens,
    temperature,
    messages: [{ role: "system", content: system }, ...input.messages.map((m) => ({ role: m.role, content: m.content }))],
  };
  if (input.json) body.response_format = { type: "json_object" };
  const res = await fetch(`${p.baseUrl}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${p.apiKey}` },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const detail = (await res.text()).slice(0, 300);
    throw new Error(`Fournisseur ${PROVIDER_LABELS[p.name]} : réponse ${res.status}. ${detail}`);
  }
  const data = (await res.json()) as { choices?: { message?: { content?: string } }[]; usage?: { prompt_tokens?: number; completion_tokens?: number } };
  const text = data.choices?.[0]?.message?.content ?? "";
  return { text, provider: p.name, model: p.model, usage: { input: data.usage?.prompt_tokens, output: data.usage?.completion_tokens } };
}
