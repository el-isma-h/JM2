/**
 * Rendu de modèles de documents (pur, sans dépendance serveur : testé dans __tests__/render.test.ts).
 *
 * Syntaxe :
 *   {{employee.firstName}}                 variable (chemin pointé)
 *   {{#if answers.trial}} ... {{/if}}      section conditionnelle (valeur renseignée)
 *   {{#if contract.type == "CDD"}} ... {{else}} ... {{/if}}
 *   {{#if contract.type != "CDI"}} ... {{/if}}
 *   {{#unless answers.x}} ... {{/unless}}
 *
 * Règle absolue : une variable absente ne produit jamais une chaîne vide ni une valeur inventée,
 * mais un marqueur visible « [À COMPLÉTER : libellé] », et elle est listée dans `missing`.
 */

export type RenderData = Record<string, unknown>;

export type MissingItem = { key: string; label: string; reason?: string };

export type RenderResult = { text: string; missing: MissingItem[] };

export type RenderOptions = {
  /** Libellés lisibles par chemin (ex. "employee.firstName" -> "Prénom du salarié"). */
  labels?: Record<string, string>;
  /** Données volontairement non transmises, avec la raison (ex. habilitation manquante). */
  withheld?: Record<string, string>;
};

export const MARKER_PREFIX = "[À COMPLÉTER : ";
export const MARKER_RE = /\[À COMPLÉTER : ([^\]]+)\]/g;

export function marker(label: string): string {
  return `${MARKER_PREFIX}${label.replace(/[[\]]/g, "")}]`;
}

/** Marqueurs encore présents dans un texte (après édition manuelle par exemple). */
export function listMarkers(text: string): string[] {
  const out: string[] = [];
  for (const m of text.matchAll(MARKER_RE)) {
    if (!out.includes(m[1])) out.push(m[1]);
  }
  return out;
}

/** Libellés par défaut des variables courantes. */
export const DEFAULT_LABELS: Record<string, string> = {
  "company.legalName": "Raison sociale de l'entreprise",
  "company.legalForm": "Forme juridique",
  "company.siren": "SIREN",
  "company.siret": "SIRET de l'établissement",
  "company.address": "Adresse de l'entreprise",
  "company.city": "Ville de l'entreprise",
  "company.collectiveAgreement": "Intitulé de la convention collective",
  "company.idcc": "Code IDCC",
  "company.retirementFund": "Caisse de retraite complémentaire",
  "company.providentFund": "Organisme de prévoyance",
  "signatory.fullName": "Nom du signataire",
  "employee.civility": "Civilité du salarié",
  "employee.firstName": "Prénom du salarié",
  "employee.lastName": "Nom du salarié",
  "employee.fullName": "Nom complet du salarié",
  "employee.birthDate": "Date de naissance du salarié",
  "employee.birthPlace": "Lieu de naissance du salarié",
  "employee.nationality": "Nationalité du salarié",
  "employee.address": "Adresse du salarié",
  "employee.jobTitle": "Poste occupé",
  "employee.department": "Service",
  "employee.hireDate": "Date d'entrée",
  "employee.leaveDate": "Date de sortie",
  "employee.leaveReason": "Motif de sortie",
  "employee.employeeNumber": "Matricule",
  "contract.typeLabel": "Type de contrat",
  "contract.startDate": "Date de début du contrat",
  "contract.endDate": "Date de fin du contrat",
  "contract.trialEndDate": "Date de fin de la période d'essai",
  "contract.trialRenewedUntil": "Date de fin de la période d'essai renouvelée",
  "contract.jobTitle": "Intitulé du poste au contrat",
  "contract.classification": "Classification conventionnelle",
  "contract.coefficient": "Coefficient",
  "contract.categoryLabel": "Catégorie (cadre, non-cadre)",
  "contract.weeklyHours": "Durée hebdomadaire de travail",
  "contract.monthlyHours": "Durée mensuelle de travail",
  "contract.workTimeLabel": "Mode d'organisation du temps de travail",
  "contract.cddReason": "Motif du recours au CDD",
  "compensation.grossMonthly": "Rémunération brute",
  "compensation.basisLabel": "Base de la rémunération",
  "compensation.effectiveDate": "Date d'effet de la rémunération",
};

function humanize(path: string): string {
  const last = path.split(".").pop() ?? path;
  const spaced = last.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_-]+/g, " ").toLowerCase();
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

export function getPath(data: RenderData, path: string): unknown {
  let cur: unknown = data;
  for (const part of path.split(".")) {
    if (cur === null || cur === undefined || typeof cur !== "object") return undefined;
    cur = (cur as Record<string, unknown>)[part];
  }
  return cur;
}

export function isBlank(v: unknown): boolean {
  return v === undefined || v === null || (typeof v === "string" && v.trim() === "") || (Array.isArray(v) && v.length === 0);
}

function isTruthy(v: unknown): boolean {
  if (isBlank(v)) return false;
  if (v === false || v === 0) return false;
  // « non » est une réponse renseignée (vraie) : comparer explicitement avec == "oui" pour un choix oui/non.
  if (typeof v === "string" && v.trim().toLowerCase() === "false") return false;
  return true;
}

function formatValue(v: unknown): string {
  if (typeof v === "boolean") return v ? "oui" : "non";
  if (typeof v === "number") return new Intl.NumberFormat("fr-FR").format(v);
  if (Array.isArray(v)) return v.map(formatValue).join(", ");
  return String(v);
}

// ---------- Analyse ----------

type Node =
  | { kind: "text"; value: string }
  | { kind: "var"; path: string }
  | { kind: "if"; cond: Cond; negate: boolean; then: Node[]; else: Node[] };

type Cond = { path: string; op?: "==" | "!="; value?: string };

const TAG_RE = /\{\{\s*(#if|#unless|else|\/if|\/unless)?\s*([^}]*?)\s*\}\}/g;

function parseCond(src: string): Cond {
  const m = src.match(/^([\w.]+)\s*(==|!=)\s*"([^"]*)"$/);
  if (m) return { path: m[1], op: m[2] as "==" | "!=", value: m[3] };
  const path = src.trim();
  if (!/^[\w.]+$/.test(path)) throw new TemplateError(`Condition invalide : ${src}`);
  return { path };
}

export class TemplateError extends Error {}

export function parseTemplate(body: string): Node[] {
  const root: Node[] = [];
  const stack: { node: Extract<Node, { kind: "if" }>; inElse: boolean; tag: "if" | "unless" }[] = [];
  const target = () => {
    const top = stack[stack.length - 1];
    if (!top) return root;
    return top.inElse ? top.node.else : top.node.then;
  };
  let last = 0;
  for (const m of body.matchAll(TAG_RE)) {
    const idx = m.index ?? 0;
    if (idx > last) target().push({ kind: "text", value: body.slice(last, idx) });
    last = idx + m[0].length;
    const kw = m[1];
    const arg = (m[2] ?? "").trim();
    if (kw === "#if" || kw === "#unless") {
      const node: Extract<Node, { kind: "if" }> = { kind: "if", cond: parseCond(arg), negate: kw === "#unless", then: [], else: [] };
      target().push(node);
      stack.push({ node, inElse: false, tag: kw === "#if" ? "if" : "unless" });
    } else if (kw === "else") {
      const top = stack[stack.length - 1];
      if (!top) throw new TemplateError("{{else}} sans {{#if}}");
      top.inElse = true;
    } else if (kw === "/if" || kw === "/unless") {
      const top = stack.pop();
      if (!top || `/${top.tag}` !== kw) throw new TemplateError(`Fermeture inattendue : {{${kw}}}`);
    } else {
      if (!/^[\w.]+$/.test(arg)) throw new TemplateError(`Variable invalide : {{${arg}}}`);
      target().push({ kind: "var", path: arg });
    }
  }
  if (last < body.length) target().push({ kind: "text", value: body.slice(last) });
  if (stack.length) throw new TemplateError("Section conditionnelle non fermée");
  return root;
}

/** Chemins de variables utilisés par un modèle (pour savoir quelles données lire). */
export function templateVariables(body: string): string[] {
  const out = new Set<string>();
  const walk = (nodes: Node[]) => {
    for (const n of nodes) {
      if (n.kind === "var") out.add(n.path);
      else if (n.kind === "if") {
        out.add(n.cond.path);
        walk(n.then);
        walk(n.else);
      }
    }
  };
  walk(parseTemplate(body));
  return [...out];
}

// ---------- Rendu ----------

export function renderTemplate(body: string, data: RenderData, opts: RenderOptions = {}): RenderResult {
  const labels = { ...DEFAULT_LABELS, ...(opts.labels ?? {}) };
  const withheld = opts.withheld ?? {};
  const missing: MissingItem[] = [];
  const addMissing = (key: string): string => {
    const reason = withheld[key] ?? withheld[key.split(".")[0]];
    const base = labels[key] ?? humanize(key);
    const label = reason ? `${base} (${reason})` : base;
    if (!missing.some((m) => m.key === key)) missing.push({ key, label, ...(reason ? { reason } : {}) });
    return marker(label);
  };

  const evalCond = (c: Cond): boolean => {
    const v = getPath(data, c.path);
    if (!c.op) return isTruthy(v);
    const s = isBlank(v) ? "" : String(v);
    return c.op === "==" ? s === c.value : s !== c.value;
  };

  const out = (nodes: Node[]): string => {
    let s = "";
    for (const n of nodes) {
      if (n.kind === "text") s += n.value;
      else if (n.kind === "var") {
        const v = getPath(data, n.path);
        s += isBlank(v) ? addMissing(n.path) : formatValue(v);
      } else {
        const ok = evalCond(n.cond) !== n.negate;
        s += out(ok ? n.then : n.else);
      }
    }
    return s;
  };

  const text = out(parseTemplate(body))
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  return { text: `${text}\n`, missing };
}
