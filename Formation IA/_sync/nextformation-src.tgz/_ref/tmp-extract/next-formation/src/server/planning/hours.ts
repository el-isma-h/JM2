/**
 * Moteur d'heures (F05 / F06) : module pur, sans accès base, testé dans __tests__/hours.test.ts.
 *
 * Cinq compteurs distincts, jamais additionnés entre eux :
 *  - prévues      : durée contractuelle du parcours (version de programme ou `hoursPlanned` de l'inscription) ;
 *  - programmées  : somme des périodes planifiées (séances non annulées), pause exclue ;
 *  - effectuées   : minutes réellement comptées par présence (retards et départs anticipés déduits) ;
 *  - justifiées   : durée des périodes où l'apprenant est absent avec justificatif ;
 *  - validées     : minutes effectuées sur des périodes clôturées (verrouillées).
 *  - legacy       : solde historique non réconcilié (anciennes feuilles), toujours à part.
 *
 * Journée 9h-12h / 14h-17h : deux périodes indépendantes de 180 min ; présence complète = 360 ; matin seul = 180.
 * La pause méridienne n'existe pas comme durée : elle est l'intervalle entre deux périodes. Un `breakMinutes`
 * propre à une période (pause intra-période) est déduit de sa durée.
 */

import { minutesBetween } from "../../lib/time";

export type PeriodLike = {
  id: string;
  startTime: string;
  endTime: string;
  breakMinutes?: number | null;
  status: "prevue" | "ouverte" | "cloturee" | "annulee";
  /** Statut de la séance parente : une séance annulée ne programme rien. */
  slotStatus?: "prevue" | "confirmee" | "annulee" | "reportee" | null;
};

export type AttendanceStatus = "non_saisie" | "present" | "retard" | "depart_anticipe" | "retard_et_depart" | "absent" | "absent_justifie" | "excuse";

export type AttendanceLike = {
  periodId: string;
  status: AttendanceStatus;
  arrivedAt?: string | null;
  leftAt?: string | null;
  isCurrent?: boolean;
};

export type HoursAggregate = {
  planned: number;
  scheduled: number;
  done: number;
  justified: number;
  validated: number;
  legacy: number;
};

/** Heure PostgreSQL « HH:mm:ss » ou « HH:mm » ramenée à HH:mm. */
export function hm(t: string): string {
  return t.length > 5 ? t.slice(0, 5) : t;
}

/** Borne une heure HH:mm dans [min, max] (comparaison lexicographique valide sur ce format). */
function clampTime(t: string, min: string, max: string): string {
  t = hm(t);
  if (t < min) return min;
  if (t > max) return max;
  return t;
}

/** Durée d'une période en minutes : fin - début - pause intra-période, jamais négative. */
export function periodMinutes(p: Pick<PeriodLike, "startTime" | "endTime" | "breakMinutes">): number {
  const gross = minutesBetween(hm(p.startTime), hm(p.endTime));
  return Math.max(0, gross - Math.max(0, p.breakMinutes ?? 0));
}

/**
 * Minutes comptées pour une présence sur une période, selon le statut :
 *  - present : toute la période ;
 *  - retard : de l'heure d'arrivée (bornée) à la fin ;
 *  - depart_anticipe : du début à l'heure de départ (bornée) ;
 *  - retard_et_depart : de l'arrivée au départ ;
 *  - absent, absent_justifie, excuse, non_saisie : 0.
 * Une pause intra-période est déduite proportionnellement au temps couvert (plafonnée à la pause).
 */
export function countedMinutes(p: Pick<PeriodLike, "startTime" | "endTime" | "breakMinutes">, a: Pick<AttendanceLike, "status" | "arrivedAt" | "leftAt">): number {
  const full = periodMinutes(p);
  if (full === 0) return 0;
  switch (a.status) {
    case "present":
      return full;
    case "retard":
    case "depart_anticipe":
    case "retard_et_depart": {
      const start = hm(p.startTime);
      const end = hm(p.endTime);
      const from = a.status === "depart_anticipe" || !a.arrivedAt ? start : clampTime(a.arrivedAt, start, end);
      const to = a.status === "retard" || !a.leftAt ? end : clampTime(a.leftAt, start, end);
      const gross = minutesBetween(from, to);
      const grossFull = minutesBetween(start, end);
      const brk = Math.max(0, p.breakMinutes ?? 0);
      const deducted = grossFull > 0 ? Math.min(brk, Math.round((brk * gross) / grossFull)) : 0;
      return Math.max(0, Math.min(full, gross - deducted));
    }
    default:
      return 0;
  }
}

export function isJustifiedAbsence(status: AttendanceStatus): boolean {
  return status === "absent_justifie";
}

/** Période qui compte comme programmée : non annulée, séance non annulée. */
export function isScheduled(p: PeriodLike): boolean {
  return p.status !== "annulee" && p.slotStatus !== "annulee";
}

/**
 * Agrégats d'une inscription. Les présences non courantes (`isCurrent === false`) sont ignorées :
 * une correction remplace sans jamais s'ajouter. Plusieurs lignes courantes pour la même période
 * (impossible grâce à l'index unique, mais défensif) ne comptent qu'une fois : la dernière gagne.
 */
export function aggregateHours(input: { hoursPlanned: number; periods: PeriodLike[]; attendances: AttendanceLike[]; legacyMinutes?: number }): HoursAggregate {
  const byPeriod = new Map<string, PeriodLike>();
  for (const p of input.periods) byPeriod.set(p.id, p);

  // Une seule présence courante par période.
  const current = new Map<string, AttendanceLike>();
  for (const a of input.attendances) {
    if (a.isCurrent === false) continue;
    current.set(a.periodId, a);
  }

  let scheduled = 0;
  let done = 0;
  let justified = 0;
  let validated = 0;
  for (const p of byPeriod.values()) {
    if (!isScheduled(p)) continue;
    const full = periodMinutes(p);
    scheduled += full;
    const a = current.get(p.id);
    if (!a) continue;
    const minutes = countedMinutes(p, a);
    done += minutes;
    if (isJustifiedAbsence(a.status)) justified += full;
    if (p.status === "cloturee") validated += minutes;
  }
  return {
    planned: Math.max(0, Math.round(input.hoursPlanned * 60)),
    scheduled,
    done,
    justified,
    validated,
    legacy: Math.max(0, input.legacyMinutes ?? 0),
  };
}

/* ---------- Règles temporelles (F06) : fonctions pures, `now` en paramètre, heure serveur Europe/Paris ---------- */

import { hasEnded, hasStarted } from "../../lib/time";

export type PeriodTiming = { date: string; startTime: string; endTime: string; status: PeriodLike["status"] };

export type RuleResult = { ok: true } | { ok: false; reason: string };

/** Préparation (ouverture de la feuille) : possible à tout moment avant ou pendant, jamais après clôture. */
export function canPrepare(p: PeriodTiming): RuleResult {
  if (p.status === "cloturee") return { ok: false, reason: "Cette période est clôturée : elle ne peut plus être modifiée." };
  if (p.status === "annulee") return { ok: false, reason: "Cette période est annulée." };
  return { ok: true };
}

/** Saisie d'une présence : seulement après le début réel de la période (heure serveur), jamais sur une période clôturée. */
export function canRecordAttendance(p: PeriodTiming, now: Date): RuleResult {
  const prep = canPrepare(p);
  if (!prep.ok) return prep;
  if (!hasStarted(p.date, p.startTime, now)) return { ok: false, reason: `La période n'a pas commencé (début ${p.startTime}, heure de Paris) : aucune présence ne peut être saisie avant.` };
  return { ok: true };
}

/** Signature de fin du formateur et clôture : seulement après la fin réelle. */
export function canCloseOrSign(p: PeriodTiming, now: Date): RuleResult {
  const prep = canPrepare(p);
  if (!prep.ok) return prep;
  if (!hasEnded(p.date, p.endTime, now)) return { ok: false, reason: `La période n'est pas terminée (fin ${p.endTime}, heure de Paris) : signature de fin et clôture sont refusées avant.` };
  return { ok: true };
}

/** Modification directe d'une période ou de ses présences : refusée si clôturée. */
export function canEditDirectly(p: Pick<PeriodTiming, "status">): RuleResult {
  if (p.status === "cloturee") return { ok: false, reason: "Période clôturée : modification et suppression directes refusées. Passez par une demande de correction." };
  return { ok: true };
}

/** Une évaluation ne peut porter une date future (F07). */
export function isFutureDate(dateIso: string, todayIso: string): boolean {
  return dateIso > todayIso;
}
