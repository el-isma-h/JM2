import "server-only";
import { and, asc, eq, gte, inArray, isNull, lte, ne, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { trainerSessionIds } from "@/server/authz";
import { aggregateHours, countedMinutes, hm, type HoursAggregate } from "./hours";
import { type ExistingPeriod } from "./rules";

export type { HoursAggregate };

type PeriodRow = typeof schema.periods.$inferSelect;
type AttendanceRow = typeof schema.attendances.$inferSelect;

/** Les colonnes `time` reviennent en « HH:mm:ss » : tout le module travaille en HH:mm. */
export function normalizePeriod<T extends { period: PeriodRow }>(row: T): T {
  return { ...row, period: { ...row.period, startTime: hm(row.period.startTime), endTime: hm(row.period.endTime) } };
}
export function normalizeAttendance(a: AttendanceRow): AttendanceRow {
  return { ...a, arrivedAt: a.arrivedAt ? hm(a.arrivedAt) : a.arrivedAt, leftAt: a.leftAt ? hm(a.leftAt) : a.leftAt };
}

/* ---------- Agrégats d'heures : utilisés par les équipes B (dossier), F (finance), G (extranets) ---------- */

/**
 * Agrégats d'heures d'une inscription en minutes : prévues / programmées / effectuées / justifiées / validées + solde historique.
 * Jamais additionnés entre eux. `legacy` reste distinct des heures justifiées (F06).
 */
export async function hoursForEnrollment(orgId: string, enrollmentId: string): Promise<HoursAggregate & { legacyNote: string | null }> {
  const [e] = await db
    .select({ hoursPlanned: schema.enrollments.hoursPlanned, programVersionId: schema.enrollments.programVersionId, sessionId: schema.enrollments.sessionId, legacyHours: schema.enrollments.legacyHours, legacyHoursNote: schema.enrollments.legacyHoursNote, groupId: schema.enrollments.groupId })
    .from(schema.enrollments)
    .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)))
    .limit(1);
  if (!e) return { planned: 0, scheduled: 0, done: 0, justified: 0, validated: 0, legacy: 0, legacyNote: null };
  let planned = e.hoursPlanned;
  if (!planned && e.programVersionId) {
    const [v] = await db.select({ h: schema.programVersions.durationHours }).from(schema.programVersions).where(eq(schema.programVersions.id, e.programVersionId)).limit(1);
    planned = v?.h ?? 0;
  }
  const periods = await periodsForEnrollment(orgId, enrollmentId);
  const attendances = await db
    .select({ periodId: schema.attendances.periodId, status: schema.attendances.status, arrivedAt: schema.attendances.arrivedAt, leftAt: schema.attendances.leftAt, isCurrent: schema.attendances.isCurrent })
    .from(schema.attendances)
    .where(and(eq(schema.attendances.orgId, orgId), eq(schema.attendances.enrollmentId, enrollmentId), eq(schema.attendances.isCurrent, true)))
    .then((rows) => rows.map((a) => ({ ...a, arrivedAt: a.arrivedAt ? hm(a.arrivedAt) : null, leftAt: a.leftAt ? hm(a.leftAt) : null })));
  const legacySheets = await db
    .select({ minutes: sql<number>`coalesce(sum(${schema.legacyAttendanceSheets.hours}),0)::int` })
    .from(schema.legacyAttendanceSheets)
    .where(and(eq(schema.legacyAttendanceSheets.orgId, orgId), eq(schema.legacyAttendanceSheets.enrollmentId, enrollmentId), eq(schema.legacyAttendanceSheets.reconciled, false)));
  const legacyMinutes = Math.max(e.legacyHours * 60, legacySheets[0]?.minutes ?? 0);
  const agg = aggregateHours({
    hoursPlanned: planned,
    periods: periods.map((p) => ({ id: p.period.id, startTime: p.period.startTime, endTime: p.period.endTime, breakMinutes: p.period.breakMinutes, status: p.period.status, slotStatus: p.slot.status })),
    attendances,
    legacyMinutes,
  });
  return { ...agg, legacyNote: e.legacyHoursNote };
}

/** Périodes (avec séance) de la session d'une inscription, restreintes au groupe de l'inscription si la séance vise un groupe. */
export async function periodsForEnrollment(orgId: string, enrollmentId: string) {
  const [e] = await db.select({ sessionId: schema.enrollments.sessionId, groupId: schema.enrollments.groupId }).from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
  if (!e) return [];
  return db
    .select({ period: schema.periods, slot: schema.slots })
    .from(schema.periods)
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .where(and(eq(schema.periods.orgId, orgId), eq(schema.slots.sessionId, e.sessionId), e.groupId ? or(isNull(schema.slots.groupId), eq(schema.slots.groupId, e.groupId)) : isNull(schema.slots.groupId)))
    .orderBy(asc(schema.slots.date), asc(schema.periods.startTime))
    .then((rows) => rows.map(normalizePeriod));
}

export type DateRange = { from: string; to: string };

/** Périodes d'un formateur sur un intervalle (affectation par séance ou par période). */
export async function periodsForTrainer(orgId: string, trainerId: string, range: DateRange) {
  return db
    .select({ period: schema.periods, slot: schema.slots, session: { id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title } })
    .from(schema.periods)
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.slots.sessionId))
    .where(and(eq(schema.periods.orgId, orgId), gte(schema.slots.date, range.from), lte(schema.slots.date, range.to), or(eq(schema.periods.trainerId, trainerId), and(isNull(schema.periods.trainerId), eq(schema.slots.trainerId, trainerId)))))
    .orderBy(asc(schema.slots.date), asc(schema.periods.startTime))
    .then((rows) => rows.map(normalizePeriod));
}

/* ---------- Listes pour les écrans ---------- */

export type PlanningFilters = { sessionId?: string; trainerId?: string; roomId?: string; siteId?: string };

/** Séances + périodes d'un organisme sur un intervalle, filtrées ; périmètre formateur appliqué. */
export async function listPeriods(ctx: OrgContext, range: DateRange, f: PlanningFilters = {}) {
  const scope = await trainerSessionIds(ctx);
  if (scope && scope.length === 0) return [];
  const conds: SQL[] = [eq(schema.periods.orgId, ctx.org.id), gte(schema.slots.date, range.from), lte(schema.slots.date, range.to)];
  if (scope) conds.push(inArray(schema.slots.sessionId, scope));
  if (f.sessionId) conds.push(eq(schema.slots.sessionId, f.sessionId));
  if (f.trainerId) conds.push(or(eq(schema.periods.trainerId, f.trainerId), and(isNull(schema.periods.trainerId), eq(schema.slots.trainerId, f.trainerId)))!);
  if (f.roomId) conds.push(or(eq(schema.periods.roomId, f.roomId), and(isNull(schema.periods.roomId), eq(schema.slots.roomId, f.roomId)))!);
  if (f.siteId) conds.push(eq(schema.slots.siteId, f.siteId));
  return db
    .select({
      period: schema.periods,
      slot: schema.slots,
      session: { id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title },
      moduleTitle: schema.modules.title,
      trainerFirst: schema.trainers.firstName,
      trainerLast: schema.trainers.lastName,
      roomName: schema.rooms.name,
      groupName: schema.groups.name,
    })
    .from(schema.periods)
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.slots.sessionId))
    .leftJoin(schema.modules, eq(schema.modules.id, schema.slots.moduleId))
    .leftJoin(schema.trainers, eq(schema.trainers.id, sql`coalesce(${schema.periods.trainerId}, ${schema.slots.trainerId})`))
    .leftJoin(schema.rooms, eq(schema.rooms.id, sql`coalesce(${schema.periods.roomId}, ${schema.slots.roomId})`))
    .leftJoin(schema.groups, eq(schema.groups.id, schema.slots.groupId))
    .where(and(...conds))
    .orderBy(asc(schema.slots.date), asc(schema.periods.startTime))
    .then((rows) => rows.map(normalizePeriod));
}

/** Périodes existantes (non annulées) sur des dates, pour la détection de conflits. */
export async function existingPeriodsOn(orgId: string, dates: string[]): Promise<ExistingPeriod[]> {
  if (!dates.length) return [];
  const rows = await db
    .select({
      periodId: schema.periods.id,
      slotId: schema.slots.id,
      date: schema.slots.date,
      startTime: schema.periods.startTime,
      endTime: schema.periods.endTime,
      trainerId: sql<string | null>`coalesce(${schema.periods.trainerId}, ${schema.slots.trainerId})`,
      roomId: sql<string | null>`coalesce(${schema.periods.roomId}, ${schema.slots.roomId})`,
      groupId: schema.slots.groupId,
      sessionId: schema.slots.sessionId,
      sessionCode: schema.trainingSessions.code,
      status: schema.periods.status,
    })
    .from(schema.periods)
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.slots.sessionId))
    .where(and(eq(schema.periods.orgId, orgId), inArray(schema.slots.date, dates), ne(schema.periods.status, "annulee"), ne(schema.slots.status, "annulee")));
  return rows.map((r) => ({ ...r, startTime: hm(r.startTime), endTime: hm(r.endTime) }));
}

/** Charge une période de l'organisme avec sa séance et sa session ; null si hors organisme. */
export async function loadPeriod(orgId: string, periodId: string) {
  const [row] = await db
    .select({ period: schema.periods, slot: schema.slots, session: schema.trainingSessions })
    .from(schema.periods)
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.slots.sessionId))
    .where(and(eq(schema.periods.id, periodId), eq(schema.periods.orgId, orgId)))
    .limit(1);
  return row ? normalizePeriod(row) : null;
}

/** Inscrits attendus à une période : inscriptions actives de la session (et du groupe de la séance s'il y en a un). */
export async function expectedEnrollments(orgId: string, sessionId: string, groupId: string | null) {
  return db
    .select({ enrollment: schema.enrollments, person: { id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email } })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.sessionId, sessionId), inArray(schema.enrollments.status, ["inscrit", "en_cours", "termine"]), groupId ? eq(schema.enrollments.groupId, groupId) : sql`true`))
    .orderBy(asc(schema.persons.lastName), asc(schema.persons.firstName));
}

/** Présences courantes d'une période. */
export async function currentAttendances(orgId: string, periodId: string) {
  return db
    .select()
    .from(schema.attendances)
    .where(and(eq(schema.attendances.orgId, orgId), eq(schema.attendances.periodId, periodId), eq(schema.attendances.isCurrent, true)))
    .then((rows) => rows.map(normalizeAttendance));
}

/** Recalcule les minutes comptées d'une présence (côté serveur, jamais le navigateur). */
export function minutesFor(period: { startTime: string; endTime: string; breakMinutes: number }, a: { status: (typeof schema.attendanceStatusEnum.enumValues)[number]; arrivedAt?: string | null; leftAt?: string | null }) {
  return countedMinutes(period, a);
}

/* ---------- Export iCal ---------- */

function icsEscape(s: string) {
  return s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n");
}

function icsLocal(date: string, time: string) {
  return `${date.replace(/-/g, "")}T${hm(time).replace(":", "")}00`;
}

/** Agenda iCal d'un formateur (heures locales Europe/Paris, TZID). */
export function buildTrainerIcs(input: { calendarName: string; items: { uid: string; date: string; startTime: string; endTime: string; summary: string; location?: string | null; description?: string | null; cancelled?: boolean }[] }) {
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Next Formation//Planning//FR",
    "CALSCALE:GREGORIAN",
    `X-WR-CALNAME:${icsEscape(input.calendarName)}`,
    "X-WR-TIMEZONE:Europe/Paris",
  ];
  for (const it of input.items) {
    lines.push("BEGIN:VEVENT", `UID:${it.uid}@nextformation`, `DTSTART;TZID=Europe/Paris:${icsLocal(it.date, it.startTime)}`, `DTEND;TZID=Europe/Paris:${icsLocal(it.date, it.endTime)}`, `SUMMARY:${icsEscape(it.summary)}`);
    if (it.location) lines.push(`LOCATION:${icsEscape(it.location)}`);
    if (it.description) lines.push(`DESCRIPTION:${icsEscape(it.description)}`);
    if (it.cancelled) lines.push("STATUS:CANCELLED");
    lines.push("END:VEVENT");
  }
  lines.push("END:VCALENDAR");
  return lines.join("\r\n") + "\r\n";
}
