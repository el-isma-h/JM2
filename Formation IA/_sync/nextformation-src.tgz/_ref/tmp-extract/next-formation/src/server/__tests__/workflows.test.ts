import { describe, expect, it } from "vitest";
import { addBusinessDays, addCalendarDays, businessDaysBetween, computeDueDate, delayLabel, easterSunday, frenchHolidays, isBusinessDay, midpoint } from "@/server/workflows/calendar";
import { WORKFLOW_CODES, WORKFLOW_TEMPLATES, applicableSteps, pickWorkflowCode, stepHref, workflowTaskKey } from "@/server/workflows/templates";

describe("jours fériés et jours ouvrés", () => {
  it("calcule Pâques", () => {
    expect(easterSunday(2024)).toBe("2024-03-31");
    expect(easterSunday(2025)).toBe("2025-04-20");
    expect(easterSunday(2026)).toBe("2026-04-05");
  });

  it("liste les 11 jours fériés, dont les fêtes mobiles", () => {
    const h = frenchHolidays(2026);
    expect(h.size).toBe(11);
    expect(h.has("2026-04-06")).toBe(true); // lundi de Pâques
    expect(h.has("2026-05-14")).toBe(true); // Ascension
    expect(h.has("2026-05-25")).toBe(true); // lundi de Pentecôte
    expect(h.has("2026-11-11")).toBe(true);
  });

  it("exclut week-ends et jours fériés", () => {
    expect(isBusinessDay("2026-10-28")).toBe(true); // mercredi
    expect(isBusinessDay("2026-10-31")).toBe(false); // samedi
    expect(isBusinessDay("2026-11-01")).toBe(false); // dimanche
    expect(isBusinessDay("2026-11-11")).toBe(false); // mercredi férié
  });

  it("ajoute des jours ouvrés en sautant week-end et férié", () => {
    expect(addBusinessDays("2026-10-30", 1)).toBe("2026-11-02"); // vendredi + 1 = lundi
    expect(addBusinessDays("2026-11-10", 1)).toBe("2026-11-12"); // le 11 est férié
    expect(addBusinessDays("2026-10-28", 5)).toBe("2026-11-04");
    expect(addBusinessDays("2026-11-02", -1)).toBe("2026-10-30");
    expect(addBusinessDays("2026-10-31", 0)).toBe("2026-11-02"); // samedi ramené au lundi
    expect(addBusinessDays("2026-12-24", 1)).toBe("2026-12-28"); // Noël puis week-end
  });

  it("compte les jours ouvrés entre deux dates", () => {
    expect(businessDaysBetween("2026-10-28", "2026-11-04")).toBe(5);
    expect(businessDaysBetween("2026-11-04", "2026-10-28")).toBe(-5);
    expect(businessDaysBetween("2026-10-28", "2026-10-28")).toBe(0);
  });

  it("gère les changements d'année et le milieu de période", () => {
    expect(addCalendarDays("2026-12-31", 1)).toBe("2027-01-01");
    expect(addBusinessDays("2026-12-31", 1)).toBe("2027-01-04"); // 1er janvier férié puis week-end
    expect(midpoint("2026-11-02", "2026-11-30")).toBe("2026-11-16");
    expect(midpoint("2026-11-02", "2026-11-02")).toBe("2026-11-02");
  });
});

describe("échéances relatives", () => {
  const anchors = { inscription: "2026-10-28", debut: "2026-11-16", fin: "2026-12-18" };
  it("J-7 avant le début, J+1 après la fin, ouvrés après l'étape précédente", () => {
    expect(computeDueDate({ anchor: "debut", offset: -7 }, anchors)).toBe("2026-11-09");
    expect(computeDueDate({ anchor: "fin", offset: 1 }, anchors)).toBe("2026-12-19");
    expect(computeDueDate({ anchor: "precedente", offset: 5, unit: "ouvres" }, { ...anchors, precedente: "2026-11-09" })).toBe("2026-11-17"); // le 11 est férié
    expect(computeDueDate({ anchor: "inscription", offset: 2, unit: "ouvres" }, anchors)).toBe("2026-10-30");
    expect(computeDueDate({ anchor: "milieu", offset: 0 }, anchors)).toBe("2026-12-02");
  });
  it("sans étape précédente, l'ancre est l'inscription", () => {
    expect(computeDueDate({ anchor: "precedente", offset: 1 }, anchors)).toBe("2026-10-29");
  });
  it("libellés lisibles, sans tiret cadratin", () => {
    expect(delayLabel({ anchor: "debut", offset: -7 })).toBe("J-7 avant le début");
    expect(delayLabel({ anchor: "fin", offset: 1, unit: "ouvres" })).toBe("J+1 ouvré après la fin");
    expect(delayLabel({ anchor: "precedente", offset: 5, unit: "ouvres" })).toBe("5 jours ouvrés après l'étape précédente");
    expect(delayLabel({ anchor: "milieu", offset: 0 })).toBe("Milieu de la formation");
  });
});

describe("parcours", () => {
  it("chaque parcours a des codes d'étape uniques et des prérequis antérieurs du même parcours", () => {
    for (const code of WORKFLOW_CODES) {
      const steps = WORKFLOW_TEMPLATES[code].steps;
      const codes = steps.map((s) => s.code);
      expect(new Set(codes).size, code).toBe(codes.length);
      steps.forEach((s, i) => {
        for (const p of s.prerequisites) expect(codes.slice(0, i), `${code}.${s.code} -> ${p}`).toContain(p);
        expect(s.code).toMatch(/^[a-z0-9_]+$/);
        expect(`${s.label} ${s.description ?? ""}`).not.toMatch(/[—–]/);
      });
    }
  });

  it("le parcours CPF couvre les étapes EDOF, entretiens, e-learning, certification, enquête et avis", () => {
    const codes = WORKFLOW_TEMPLATES.cpf.steps.map((s) => s.code);
    for (const c of [
      "edof_validation",
      "entretien_accueil",
      "recap_inscription",
      "elearning_acces",
      "elearning_premiere_connexion",
      "edof_entree",
      "certification_inscription",
      "entretien_mi_parcours",
      "certification_passage",
      "entretien_bilan",
      "edof_sortie",
      "edof_facturation",
      "enquete_froid",
      "avis_google",
    ])
      expect(codes).toContain(c);
    expect(codes.indexOf("edof_entree")).toBeGreaterThan(codes.indexOf("elearning_premiere_connexion"));
    expect(codes.indexOf("edof_facturation")).toBeGreaterThan(codes.indexOf("edof_sortie"));
  });

  it("le parcours public ne dépose sur Chorus Pro qu'après la facture", () => {
    const codes = WORKFLOW_TEMPLATES.public.steps.map((s) => s.code);
    expect(codes.indexOf("chorus_depot")).toBeGreaterThan(codes.indexOf("facture_emission"));
    expect(codes.indexOf("facture_emission")).toBeGreaterThan(codes.indexOf("bc_conformite"));
  });

  it("filtre les étapes conditionnelles (certification, OPCO)", () => {
    const without = applicableSteps(WORKFLOW_TEMPLATES.cpf, { certification: false, opco: false }).map((s) => s.code);
    expect(without).not.toContain("certification_inscription");
    expect(without).not.toContain("certification_passage");
    const withCert = applicableSteps(WORKFLOW_TEMPLATES.cpf, { certification: true, opco: false }).map((s) => s.code);
    expect(withCert).toContain("certification_passage");
    expect(applicableSteps(WORKFLOW_TEMPLATES.entreprise, { certification: false, opco: true }).map((s) => s.code)).toContain("opco_prise_en_charge");
    expect(applicableSteps(WORKFLOW_TEMPLATES.entreprise, { certification: false, opco: false }).map((s) => s.code)).not.toContain("opco_prise_en_charge");
  });

  it("choisit le parcours d'après le contrat et les financements", () => {
    const base = { contractKind: "convention_formation", isApprenticeship: false, fundingKinds: [] as string[], companyId: null };
    expect(pickWorkflowCode({ ...base, contractKind: "contrat_apprentissage" })).toBe("cfa");
    expect(pickWorkflowCode({ ...base, isApprenticeship: true, fundingKinds: ["cpf"] })).toBe("cfa");
    expect(pickWorkflowCode({ ...base, contractKind: "cpf" })).toBe("cpf");
    expect(pickWorkflowCode({ ...base, fundingKinds: ["cpf", "entreprise"] })).toBe("cpf");
    expect(pickWorkflowCode({ ...base, fundingKinds: ["france_travail"] })).toBe("aif");
    expect(pickWorkflowCode({ ...base, fundingKinds: ["etat"] })).toBe("public");
    expect(pickWorkflowCode({ ...base, fundingKinds: ["opco"] })).toBe("entreprise");
    expect(pickWorkflowCode({ ...base, companyId: "c1" })).toBe("entreprise");
    expect(pickWorkflowCode(base)).toBeNull();
  });

  it("clé d'idempotence et liens", () => {
    expect(workflowTaskKey("e1", "edof_entree")).toBe("wf:e1:edof_entree");
    const ids = { orgId: "o", enrollmentId: "e", sessionId: "s" };
    expect(stepHref({ page: "financements" }, ids)).toBe("/app/o/inscriptions/e?onglet=financements");
    expect(stepHref({ page: "session" }, ids)).toBe("/app/o/sessions/s");
    expect(stepHref({ page: "suivi_entreprise" }, ids)).toBe("/app/o/suivi-entreprise");
  });
});
