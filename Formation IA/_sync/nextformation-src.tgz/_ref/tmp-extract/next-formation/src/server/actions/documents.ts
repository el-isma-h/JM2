"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg, assertEnrollmentInScope, assertSessionInScope, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { layoutMail, sendMail } from "@/server/mail";
import { generateDocument, getTemplate, type GenerateScope } from "@/server/documents/generate";
import { getVisibleDocument } from "@/server/documents/queries";
import { planVersion } from "@/server/documents/rules";
import { createDocument, issueDownloadLink, issuePublicDownloadLink } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { parseTemplate, TemplateError, templateVariables } from "@/server/documents/render";
import { TEMPLATE_VARIABLES, type TemplateQuestion } from "@/server/documents/templates-data";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const optUuid = z.string().uuid().optional().or(z.literal(""));
const CATEGORIES = schema.documentCategoryEnum.enumValues;
const VISIBILITIES = schema.documentVisibilityEnum.enumValues;

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const orEmpty = (v: string | undefined) => (v ? v : null);

/** Vérifie que les rattachements transmis par formulaire appartiennent bien à l'organisme (un identifiant n'est jamais une autorisation). */
async function checkScope(ctx: OrgContext, scope: GenerateScope) {
  const orgId = ctx.org.id;
  if (scope.enrollmentId) {
    const [e] = await db.select({ id: schema.enrollments.id }).from(schema.enrollments).where(and(eq(schema.enrollments.id, scope.enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
    if (!e) throw new Error("Inscription introuvable dans cet organisme.");
    await assertEnrollmentInScope(ctx, scope.enrollmentId);
  }
  if (scope.sessionId) {
    const [s] = await db.select({ id: schema.trainingSessions.id }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, scope.sessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
    if (!s) throw new Error("Session introuvable dans cet organisme.");
    await assertSessionInScope(ctx, scope.sessionId);
  }
  if (scope.companyId) {
    const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.id, scope.companyId), eq(schema.companies.orgId, orgId))).limit(1);
    if (!c) throw new Error("Entreprise introuvable dans cet organisme.");
  }
  if (scope.personId) {
    const [p] = await db.select({ id: schema.persons.id }).from(schema.persons).where(and(eq(schema.persons.id, scope.personId), eq(schema.persons.orgId, orgId))).limit(1);
    if (!p) throw new Error("Personne introuvable dans cet organisme.");
  }
}

function readScope(fd: FormData): GenerateScope {
  const s = z
    .object({ enrollmentId: optUuid, sessionId: optUuid, companyId: optUuid, personId: optUuid })
    .parse({ enrollmentId: str(fd, "enrollmentId"), sessionId: str(fd, "sessionId"), companyId: str(fd, "companyId"), personId: str(fd, "personId") });
  return { enrollmentId: orEmpty(s.enrollmentId), sessionId: orEmpty(s.sessionId), companyId: orEmpty(s.companyId), personId: orEmpty(s.personId) };
}

/* ---------- Dépôt manuel ---------- */

export async function uploadDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const input = z
      .object({
        title: z.string().trim().min(2, "Titre requis.").max(200),
        category: z.enum(CATEGORIES, { message: "Catégorie invalide." }),
        visibility: z.enum(VISIBILITIES, { message: "Visibilité invalide." }),
      })
      .parse({ title: str(fd, "title"), category: str(fd, "category"), visibility: str(fd, "visibility") });
    const scope = readScope(fd);
    const needsAdmin = input.visibility === "administratif" || input.visibility === "confidentiel";
    const ctx = await requireOrg(orgId, needsAdmin ? "dossier.admin_docs.manage" : "documents.generate");
    await checkScope(ctx, scope);
    const file = fd.get("file");
    if (!(file instanceof File) || !file.size) return { error: "Choisissez un fichier." };
    const head = new Uint8Array(await file.slice(0, 8).arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head });
    if (!check.ok) return { error: check.error };
    const data = Buffer.from(await file.arrayBuffer());
    const doc = await createDocument({
      orgId,
      ...scope,
      category: input.category,
      visibility: input.visibility,
      status: "genere",
      title: input.title,
      fileName: file.name,
      mimeType: check.mime,
      data,
      uploadedBy: ctx.user.id,
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "document.upload", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, after: { title: doc.title, category: doc.category, visibility: doc.visibility, scope } });
    revalidatePath(`/app/${orgId}/documents`);
    return { ok: true, message: `Document « ${doc.title} » déposé.`, data: { documentId: doc.id } };
  } catch (e) {
    return fail(e, "Dépôt impossible.");
  }
}

/** Nouvelle version d'un document par dépôt d'un fichier (un document signé ou validé est conservé, les deux restent listés). */
export async function replaceDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const documentId = uuid.parse(str(fd, "documentId"));
    const ctx = await requireOrg(orgId, "documents.generate");
    const doc = await getVisibleDocument(ctx, documentId);
    if (!doc) return { error: "Document introuvable." };
    if (doc.sourceType === "org_rib") return { error: "Le RIB central se gère depuis la page dédiée." };
    if ((doc.visibility === "administratif" || doc.visibility === "confidentiel") && !ctx.permissions.has("dossier.admin_docs.manage")) return { error: "Vous n'avez pas l'habilitation nécessaire pour cette action." };
    const file = fd.get("file");
    if (!(file instanceof File) || !file.size) return { error: "Choisissez un fichier." };
    const head = new Uint8Array(await file.slice(0, 8).arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head });
    if (!check.ok) return { error: check.error };
    const plan = planVersion({ id: doc.id, version: doc.version, status: doc.status });
    const data = Buffer.from(await file.arrayBuffer());
    const next = await createDocument({
      orgId,
      enrollmentId: doc.enrollmentId,
      sessionId: doc.sessionId,
      companyId: doc.companyId,
      personId: doc.personId,
      trainerId: doc.trainerId,
      category: doc.category,
      visibility: doc.visibility,
      status: "genere",
      templateCode: doc.templateCode,
      title: doc.title,
      fileName: file.name,
      mimeType: check.mime,
      data,
      uploadedBy: ctx.user.id,
      previousVersionId: doc.id,
      isDemo: ctx.org.isDemo,
    });
    if (plan.archivePrevious) await db.update(schema.documents).set({ status: "archive" }).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, orgId)));
    await audit({ action: "document.new_version", userId: ctx.user.id, orgId, entityType: "document", entityId: next.id, before: { previous: doc.id, status: doc.status }, after: { version: next.version, keptPrevious: !plan.archivePrevious } });
    revalidatePath(`/app/${orgId}/documents`);
    revalidatePath(`/app/${orgId}/documents/${doc.id}`);
    return { ok: true, message: plan.archivePrevious ? `Version ${next.version} enregistrée ; la précédente est archivée.` : `Version ${next.version} enregistrée ; la version ${doc.version} (${doc.status === "signe" ? "signée" : "validée"}) est conservée.`, data: { documentId: next.id } };
  } catch (e) {
    return fail(e, "Nouvelle version impossible.");
  }
}

/* ---------- Génération ---------- */

export async function generateDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const templateCode = z.string().trim().min(1, "Modèle requis.").max(80).parse(str(fd, "templateCode"));
    const scope = readScope(fd);
    const ctx = await requireOrg(orgId, "documents.generate");
    await checkScope(ctx, scope);
    const template = await getTemplate(orgId, templateCode);
    if (!template) return { error: "Modèle introuvable." };
    const answers: Record<string, string> = {};
    for (const q of (template.questions as TemplateQuestion[]) ?? []) {
      const v = str(fd, `answers.${q.key}`);
      if (q.required && !v && str(fd, "allowMissing") !== "1") return { error: `Réponse requise : ${q.label}.` };
      if (v) answers[q.key] = v;
    }
    const visibility = str(fd, "visibility");
    const res = await generateDocument({ ctx, templateCode, scope, answers, visibility: visibility && (VISIBILITIES as readonly string[]).includes(visibility) ? (visibility as (typeof VISIBILITIES)[number]) : undefined });
    revalidatePath(`/app/${orgId}/documents`);
    if (scope.enrollmentId) revalidatePath(`/app/${orgId}/inscriptions/${scope.enrollmentId}`);
    const warn = res.missing.length ? ` ${res.missing.length} donnée(s) manquante(s) restent signalées par un marqueur « À COMPLÉTER ».` : "";
    const kept = res.keptLockedPrevious ? " La version précédente, signée ou validée, est conservée." : "";
    return { ok: true, message: `Document généré (version ${res.version}).${warn}${kept}`, data: { documentId: res.document.id } };
  } catch (e) {
    return fail(e, "Génération impossible.");
  }
}

/* ---------- Téléchargement, transmission, validation ---------- */

export async function downloadDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const documentId = uuid.parse(str(fd, "documentId"));
    const ctx = await requireOrg(orgId, "documents.view");
    const doc = await getVisibleDocument(ctx, documentId);
    if (!doc) return { error: "Document introuvable ou habilitation nécessaire." };
    if (doc.sourceType === "org_rib") await audit({ action: "rib.view", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id });
    const url = await issueDownloadLink(doc.id, ctx.user.id);
    return { ok: true, data: { url } };
  } catch (e) {
    return fail(e, "Téléchargement impossible.");
  }
}

export async function transmitDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const documentId = uuid.parse(str(fd, "documentId"));
    const input = z.object({ to: z.string().trim().toLowerCase().email("Adresse e-mail invalide."), message: z.string().trim().max(2000).optional() }).parse({ to: str(fd, "to"), message: str(fd, "message") });
    const ctx = await requireOrg(orgId, "documents.generate");
    const doc = await getVisibleDocument(ctx, documentId);
    if (!doc) return { error: "Document introuvable." };
    if (doc.status === "archive" || doc.status === "invalide") return { error: "Un document archivé ou invalidé ne peut pas être transmis." };
    // Lien public temporaire (24 h), lié à l'adresse du destinataire, sans compte requis.
    const url = await issuePublicDownloadLink(doc.id, input.to, 24 * 60);
    const res = await sendMail({
      to: input.to,
      subject: `${ctx.org.legalName} : ${doc.title}`,
      html: layoutMail("Document transmis", `<p>${ctx.org.legalName} vous transmet le document <strong>${doc.title}</strong>.</p>${input.message ? `<p>${input.message.replace(/</g, "&lt;")}</p>` : ""}<p>Le lien de téléchargement est valable 24 heures.</p>`, { label: "Télécharger le document", url }),
      text: `${ctx.org.legalName} vous transmet le document « ${doc.title} » : ${url}`,
      isDemo: ctx.org.isDemo,
    });
    if (doc.status === "genere" || doc.status === "brouillon") {
      await db.update(schema.documents).set({ status: "transmis", transmittedAt: new Date() }).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, orgId)));
    }
    await audit({ action: "document.transmit", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, before: { status: doc.status }, after: { to: input.to, mailStatus: res.status, status: "transmis" } });
    revalidatePath(`/app/${orgId}/documents/${doc.id}`);
    revalidatePath(`/app/${orgId}/documents`);
    const note = res.status === "sent" ? "E-mail envoyé." : ctx.org.isDemo ? "Démonstration : aucun e-mail ne part, le lien est affiché ci-dessous." : "E-mail non configuré (RESEND_API_KEY) : transmettez ce lien vous-même.";
    return { ok: true, message: `Document marqué transmis à ${input.to}. ${note}`, data: res.status === "sent" ? {} : { link: `Lien de téléchargement (24 h) : ${url}` } };
  } catch (e) {
    return fail(e, "Transmission impossible.");
  }
}

export async function validateDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const documentId = uuid.parse(str(fd, "documentId"));
    const ctx = await requireOrg(orgId, "documents.generate");
    const doc = await getVisibleDocument(ctx, documentId);
    if (!doc) return { error: "Document introuvable." };
    if (doc.sourceType === "org_rib") return { error: "Le RIB central se valide depuis la page dédiée." };
    if ((doc.visibility === "administratif" || doc.visibility === "confidentiel") && !ctx.permissions.has("dossier.admin_docs.manage")) return { error: "Vous n'avez pas l'habilitation nécessaire pour cette action." };
    if (doc.status === "valide") return { error: "Ce document est déjà validé." };
    if (doc.status === "archive" || doc.status === "invalide") return { error: "Un document archivé ou invalidé ne peut pas être validé." };
    await db.update(schema.documents).set({ status: "valide", validatedAt: new Date(), validatedBy: ctx.user.id }).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, orgId)));
    await audit({ action: "document.validate", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, before: { status: doc.status }, after: { status: "valide" } });
    revalidatePath(`/app/${orgId}/documents/${doc.id}`);
    revalidatePath(`/app/${orgId}/documents`);
    return { ok: true, message: "Document marqué validé." };
  } catch (e) {
    return fail(e, "Validation impossible.");
  }
}

export async function archiveDocumentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const documentId = uuid.parse(str(fd, "documentId"));
    const reason = z.string().trim().min(3, "Indiquez le motif.").max(500).parse(str(fd, "reason"));
    const ctx = await requireOrg(orgId, "documents.generate");
    const doc = await getVisibleDocument(ctx, documentId);
    if (!doc) return { error: "Document introuvable." };
    if (doc.sourceType === "org_rib") return { error: "Le RIB central se gère depuis la page dédiée." };
    if (doc.status === "signe") return { error: "Un document signé ne peut pas être archivé : il reste conservé avec sa preuve." };
    if ((doc.visibility === "administratif" || doc.visibility === "confidentiel") && !ctx.permissions.has("dossier.admin_docs.manage")) return { error: "Vous n'avez pas l'habilitation nécessaire pour cette action." };
    await db.update(schema.documents).set({ status: "archive" }).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, orgId)));
    await audit({ action: "document.archive", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, before: { status: doc.status }, after: { status: "archive", reason } });
    revalidatePath(`/app/${orgId}/documents/${doc.id}`);
    revalidatePath(`/app/${orgId}/documents`);
    return { ok: true, message: "Document archivé (conservé dans l'historique)." };
  } catch (e) {
    return fail(e, "Archivage impossible.");
  }
}

/* ---------- Modèles propres à l'organisme ---------- */

export async function copyTemplateAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const templateCode = z.string().trim().min(1).max(80).parse(str(fd, "templateCode"));
    const ctx = await requireOrg(orgId, "documents.generate");
    if (ctx.trainerOnly) return { error: "Vous n'avez pas l'habilitation nécessaire pour cette action." };
    const [exists] = await db.select({ id: schema.documentTemplates.id }).from(schema.documentTemplates).where(and(eq(schema.documentTemplates.orgId, orgId), eq(schema.documentTemplates.code, templateCode))).limit(1);
    if (exists) return { error: "Un modèle propre à l'organisme existe déjà pour ce code.", data: { templateId: exists.id } };
    const source = await getTemplate(orgId, templateCode);
    if (!source) return { error: "Modèle plateforme introuvable." };
    const [row] = await db
      .insert(schema.documentTemplates)
      .values({ orgId, code: source.code, category: source.category, title: source.title, description: source.description, body: source.body, scope: source.scope, activity: source.activity, questions: source.questions, version: 1, isActive: true })
      .returning();
    await audit({ action: "template.copy", userId: ctx.user.id, orgId, entityType: "document_template", entityId: row.id, after: { from: source.id, code: source.code } });
    revalidatePath(`/app/${orgId}/documents/modeles`);
    return { ok: true, message: "Modèle copié : vous pouvez maintenant l'adapter.", data: { templateId: row.id } };
  } catch (e) {
    return fail(e, "Copie impossible.");
  }
}

export async function updateTemplateAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const templateId = uuid.parse(str(fd, "templateId"));
    const input = z
      .object({ title: z.string().trim().min(2, "Titre requis.").max(200), description: z.string().trim().max(500), body: z.string().min(20, "Le corps du modèle est trop court.").max(200_000) })
      .parse({ title: str(fd, "title"), description: str(fd, "description"), body: String(fd.get("body") ?? "") });
    const ctx = await requireOrg(orgId, "documents.generate");
    if (ctx.trainerOnly) return { error: "Vous n'avez pas l'habilitation nécessaire pour cette action." };
    const [t] = await db.select().from(schema.documentTemplates).where(and(eq(schema.documentTemplates.id, templateId), eq(schema.documentTemplates.orgId, orgId))).limit(1);
    if (!t) return { error: "Modèle introuvable (seuls les modèles propres à l'organisme sont modifiables)." };
    try {
      parseTemplate(input.body);
    } catch (e) {
      return { error: e instanceof TemplateError ? `Syntaxe du modèle : ${e.message}` : "Syntaxe du modèle invalide." };
    }
    const unknown = templateVariables(input.body).filter((v) => !(v in TEMPLATE_VARIABLES) && !v.startsWith("answers."));
    await db
      .update(schema.documentTemplates)
      .set({ title: input.title, description: input.description || null, body: input.body, version: t.body === input.body ? t.version : t.version + 1, verifiedAt: null, verifiedNote: null })
      .where(eq(schema.documentTemplates.id, t.id));
    await audit({ action: "template.update", userId: ctx.user.id, orgId, entityType: "document_template", entityId: t.id, before: { title: t.title, version: t.version }, after: { title: input.title, version: t.body === input.body ? t.version : t.version + 1 } });
    revalidatePath(`/app/${orgId}/documents/modeles`);
    revalidatePath(`/app/${orgId}/documents/modeles/${t.id}`);
    return { ok: true, message: unknown.length ? `Modèle enregistré. Variables inconnues (elles produiront un marqueur) : ${unknown.join(", ")}.` : "Modèle enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function toggleTemplateAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const templateId = uuid.parse(str(fd, "templateId"));
    const ctx = await requireOrg(orgId, "documents.generate");
    if (ctx.trainerOnly) return { error: "Vous n'avez pas l'habilitation nécessaire pour cette action." };
    const [t] = await db.select().from(schema.documentTemplates).where(and(eq(schema.documentTemplates.id, templateId), eq(schema.documentTemplates.orgId, orgId))).limit(1);
    if (!t) return { error: "Modèle introuvable." };
    await db.update(schema.documentTemplates).set({ isActive: !t.isActive }).where(eq(schema.documentTemplates.id, t.id));
    await audit({ action: "template.toggle", userId: ctx.user.id, orgId, entityType: "document_template", entityId: t.id, before: { isActive: t.isActive }, after: { isActive: !t.isActive } });
    revalidatePath(`/app/${orgId}/documents/modeles`);
    return { ok: true, message: t.isActive ? "Modèle désactivé : le modèle plateforme de même code redevient utilisé." : "Modèle activé." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}
