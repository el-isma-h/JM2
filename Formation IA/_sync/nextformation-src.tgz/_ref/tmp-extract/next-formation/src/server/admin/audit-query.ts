import "server-only";
import { and, eq, gte, ilike, lt, or, type SQL } from "drizzle-orm";
import { addDays, parseISO } from "date-fns";
import { schema } from "@/db";

export type AuditFilters = { user?: string; company?: string; action?: string; from?: string; to?: string };

const UUID = /^[0-9a-f-]{36}$/;
const DAY = /^\d{4}-\d{2}-\d{2}$/;

export function readAuditFilters(sp: Record<string, string | string[] | undefined>): AuditFilters {
  const one = (k: string) => {
    const v = sp[k];
    const s = (Array.isArray(v) ? v[0] : v)?.trim();
    return s ? s : undefined;
  };
  return { user: one("user"), company: one("company"), action: one("action"), from: one("from"), to: one("to") };
}

/** Conditions SQL du journal d'audit (utilisateur par identifiant ou e-mail, entreprise, préfixe d'action, période). */
export function auditWhere(f: AuditFilters): SQL | undefined {
  const c: SQL[] = [];
  if (f.user) c.push(UUID.test(f.user) ? eq(schema.auditLogs.userId, f.user) : ilike(schema.users.email, `%${f.user}%`));
  if (f.company && UUID.test(f.company)) c.push(or(eq(schema.auditLogs.orgId, f.company), eq(schema.auditLogs.tenantId, f.company))!);
  if (f.action) c.push(ilike(schema.auditLogs.action, `${f.action.replace(/[%_]/g, "")}%`));
  if (f.from && DAY.test(f.from)) c.push(gte(schema.auditLogs.createdAt, parseISO(f.from)));
  if (f.to && DAY.test(f.to)) c.push(lt(schema.auditLogs.createdAt, addDays(parseISO(f.to), 1)));
  return c.length ? and(...c) : undefined;
}
