import "server-only";
import { and, eq, isNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { QUALIOPI_RNQ } from "./referential-data";

/**
 * Insère le référentiel plateforme (orgId null, statut brouillon) s'il n'existe pas déjà (idempotent par code + version).
 * Il n'est jamais activé ici : chaque organisme en fait une copie qu'un humain habilité valide (textes, version, dates d'effet).
 */
export async function seedReferentials(): Promise<{ inserted: number; total: number; code: string; version: string }> {
  const [existing] = await db
    .select({ id: schema.referentials.id })
    .from(schema.referentials)
    .where(and(isNull(schema.referentials.orgId), eq(schema.referentials.code, QUALIOPI_RNQ.code), eq(schema.referentials.version, QUALIOPI_RNQ.version)))
    .limit(1);
  if (existing) return { inserted: 0, total: 1, code: QUALIOPI_RNQ.code, version: QUALIOPI_RNQ.version };
  await db.insert(schema.referentials).values({
    orgId: null,
    code: QUALIOPI_RNQ.code,
    title: QUALIOPI_RNQ.title,
    version: QUALIOPI_RNQ.version,
    source: QUALIOPI_RNQ.source,
    sourceUrl: QUALIOPI_RNQ.sourceUrl,
    scope: QUALIOPI_RNQ.scope,
    status: "brouillon",
    criteria: QUALIOPI_RNQ.criteria,
  });
  return { inserted: 1, total: 1, code: QUALIOPI_RNQ.code, version: QUALIOPI_RNQ.version };
}
