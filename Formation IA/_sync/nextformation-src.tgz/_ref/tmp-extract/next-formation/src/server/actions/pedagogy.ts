"use server";

import { revalidatePath } from "next/cache";
import { and, asc, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { assertEnrollmentInScope, requireOrg, type OrgContext } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { createDocument } from "@/server/documents/store";
import { recordEvidence } from "@/server/quality/evidence";
import { todayParis } from "@/lib/time";
import { isFutureDate } from "@/server/planning/hours";
import { hoursForEnrollment } from "@/server/planning/service";
import { renderLivretPdf, resolveFollowupReminder } from "@/server/pedagogy/service";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const optUuid = z.preprocess((v) => (v === "" || v == null ? undefined : v), uuid.optional());
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide (AAAA-MM-JJ)");
const optInt = z.preprocess((v) => (v === "" || v == null ? undefined : Number(v)), z.number().int().min(0).max(10000).optional());

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

async function orgIdOf(formData: FormData) {
  return uuid.parse(formData.get("orgId"));
}

/** Charge une inscription de l'organisme dans le périmètre (formateur affecté uniquement). */
async function loadEnrollment(ctx: OrgContext, enrollmentId: string) {
  const [e] = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, ctx.org.id))).limit(1);
  if (!e) throw new Error("Inscription introuvable.");
  await assertEnrollmentInScope(ctx, e.id);
  return e;
}

const evaluationSchema = z.object({
  enrollmentId: uuid,
  moduleId: optUuid,
  kind: z.enum(["positionnement", "formative", "sommative", "finale", "auto_evaluation", "competences"]),
  title: z.string().trim().min(2, "Intitulé requis").max(160),
  date: isoDate,
  score: optInt,
  maxScore: optInt,
  result: z.enum(["acquis", "en_cours", "non_acquis", "partiel", "non_evalue"]).default("non_evalue"),
  comment: z.string().trim().max(2000).optional(),
  skills: z.string().trim().max(4000).optional(),
});

/** Évaluation d'une inscription : la date future est refusée côté serveur (F07). */
export async function createEvaluationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "dossier.pedagogy.manage");
    const d = evaluationSchema.parse(Object.fromEntries(formData));
    if (isFutureDate(d.date, todayParis())) return { error: "La date de l'évaluation est dans le futur : un résultat ne peut pas être enregistré par anticipation." };
    const e = await loadEnrollment(ctx, d.enrollmentId);
    if (d.moduleId) {
      const [m] = await db.select({ id: schema.modules.id, programVersionId: schema.modules.programVersionId }).from(schema.modules).where(and(eq(schema.modules.id, d.moduleId), eq(schema.modules.orgId, ctx.org.id))).limit(1);
      if (!m) return { error: "Module inconnu." };
      const [s] = await db.select({ programVersionId: schema.trainingSessions.programVersionId }).from(schema.trainingSessions).where(eq(schema.trainingSessions.id, e.sessionId)).limit(1);
      if (m.programVersionId !== (e.programVersionId ?? s?.programVersionId)) return { error: "Ce module n'appartient pas au parcours de l'inscription." };
    }
    if (d.score != null && d.maxScore != null && d.score > d.maxScore) return { error: "La note dépasse le barème." };
    const skills = d.skills
      ? d.skills
          .split("\n")
          .map((l) => l.trim())
          .filter(Boolean)
          .map((l) => {
            const [label, level] = l.split("|").map((x) => x.trim());
            return { label, level: level ?? "" };
          })
      : [];
    const [row] = await db
      .insert(schema.evaluations)
      .values({ orgId: ctx.org.id, enrollmentId: e.id, moduleId: d.moduleId ?? null, kind: d.kind, title: d.title, date: d.date, score: d.score ?? null, maxScore: d.maxScore ?? null, result: d.result, skills, comment: d.comment || null, evaluatorId: ctx.user.id })
      .returning({ id: schema.evaluations.id });
    await audit({ action: "evaluation.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "evaluation", entityId: row.id, after: { enrollmentId: e.id, kind: d.kind, date: d.date, result: d.result } });
    if (d.kind === "positionnement") {
      await recordEvidence({ orgId: ctx.org.id, indicatorCode: "IND_8", level: "individuel", title: `Positionnement : ${d.title}`, sourceType: "evaluation", sourceId: row.id, evidenceDate: d.date, enrollmentId: e.id, sessionId: e.sessionId, createdBy: ctx.user.id });
    } else if (d.kind === "finale" || d.kind === "sommative") {
      await recordEvidence({ orgId: ctx.org.id, indicatorCode: "IND_11", level: "individuel", title: `Évaluation des acquis : ${d.title}`, sourceType: "evaluation", sourceId: row.id, evidenceDate: d.date, enrollmentId: e.id, sessionId: e.sessionId, createdBy: ctx.user.id });
    }
    revalidatePath(`/app/${ctx.org.id}/evaluations`);
    return { ok: true, message: "Évaluation enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Progression pédagogique de l'inscription : décision explicite du responsable pédagogique, jamais automatique. */
export async function setProgressionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "dossier.pedagogy.manage");
    if (ctx.trainerOnly) return { error: "La progression est déclarée par le responsable pédagogique." };
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const progression = z.enum(["non_commencee", "en_cours", "acquise", "partielle", "non_acquise"]).parse(formData.get("progression"));
    const reason = z.string().trim().max(500).optional().parse(formData.get("reason") ?? undefined);
    const e = await loadEnrollment(ctx, enrollmentId);
    if (e.progression === progression) return { ok: true, message: "Progression inchangée." };
    await db.transaction(async (tx) => {
      await tx.update(schema.enrollments).set({ progression, updatedAt: new Date() }).where(eq(schema.enrollments.id, e.id));
      await tx.insert(schema.enrollmentEvents).values({ enrollmentId: e.id, kind: "progression", fromValue: e.progression, toValue: progression, reason: reason || null, userId: ctx.user.id });
    });
    await audit({ action: "enrollment.progression", userId: ctx.user.id, orgId: ctx.org.id, entityType: "enrollment", entityId: e.id, before: { progression: e.progression }, after: { progression, reason } });
    revalidatePath(`/app/${ctx.org.id}/evaluations`);
    revalidatePath(`/app/${ctx.org.id}/inscriptions/${e.id}`);
    return { ok: true, message: "Progression mise à jour (la clôture pédagogique ne solde pas le financier)." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

const entrySchema = z.object({
  enrollmentId: uuid,
  kind: z.enum(["objectif", "activite", "competence", "bilan", "observation", "entreprise", "aide"]),
  date: isoDate,
  title: z.string().trim().min(2, "Intitulé requis").max(160),
  body: z.string().trim().max(4000).optional(),
  visibleToLearner: z.preprocess((v) => v === "1" || v === "on", z.boolean()).optional(),
  visibleToCompany: z.preprocess((v) => v === "1" || v === "on", z.boolean()).optional(),
});

/** Entrée de livret datée, avec visibilité apprenant / entreprise. */
export async function addRecordEntryAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "dossier.pedagogy.manage");
    const d = entrySchema.parse(Object.fromEntries(formData));
    if (isFutureDate(d.date, todayParis())) return { error: "La date de l'entrée est dans le futur." };
    const e = await loadEnrollment(ctx, d.enrollmentId);
    const [row] = await db
      .insert(schema.recordEntries)
      .values({ orgId: ctx.org.id, enrollmentId: e.id, kind: d.kind, date: d.date, title: d.title, body: d.body || null, authorId: ctx.user.id, authorRole: ctx.roles.join(","), visibleToLearner: d.visibleToLearner ?? false, visibleToCompany: d.visibleToCompany ?? false })
      .returning({ id: schema.recordEntries.id });
    await audit({ action: "record_entry.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "record_entry", entityId: row.id, after: { enrollmentId: e.id, kind: d.kind, visibleToLearner: d.visibleToLearner, visibleToCompany: d.visibleToCompany } });
    revalidatePath(`/app/${ctx.org.id}/evaluations`);
    return { ok: true, message: "Entrée ajoutée au livret." };
  } catch (e) {
    return fail(e, "Ajout impossible.");
  }
}

/** Génération du livret PDF (catégorie livret, visibilité pédagogie). Une régénération crée une nouvelle version. */
export async function generateLivretAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "documents.generate");
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const e = await loadEnrollment(ctx, enrollmentId);
    const [person] = await db.select({ firstName: schema.persons.firstName, lastName: schema.persons.lastName }).from(schema.persons).where(eq(schema.persons.id, e.personId)).limit(1);
    const [session] = await db.select({ code: schema.trainingSessions.code, title: schema.trainingSessions.title, programVersionId: schema.trainingSessions.programVersionId }).from(schema.trainingSessions).where(eq(schema.trainingSessions.id, e.sessionId)).limit(1);
    const [program] = await db
      .select({ title: schema.programs.title })
      .from(schema.programVersions)
      .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
      .where(eq(schema.programVersions.id, e.programVersionId ?? session.programVersionId))
      .limit(1);
    const [evaluations, entries, followups, hours, previous] = await Promise.all([
      db
        .select({ date: schema.evaluations.date, kind: schema.evaluations.kind, title: schema.evaluations.title, moduleTitle: schema.modules.title, result: schema.evaluations.result, score: schema.evaluations.score, maxScore: schema.evaluations.maxScore, comment: schema.evaluations.comment })
        .from(schema.evaluations)
        .leftJoin(schema.modules, eq(schema.modules.id, schema.evaluations.moduleId))
        .where(and(eq(schema.evaluations.orgId, ctx.org.id), eq(schema.evaluations.enrollmentId, e.id)))
        .orderBy(asc(schema.evaluations.date)),
      db.select().from(schema.recordEntries).where(and(eq(schema.recordEntries.orgId, ctx.org.id), eq(schema.recordEntries.enrollmentId, e.id))).orderBy(asc(schema.recordEntries.date)),
      db.select().from(schema.companyFollowups).where(and(eq(schema.companyFollowups.orgId, ctx.org.id), eq(schema.companyFollowups.enrollmentId, e.id))).orderBy(asc(schema.companyFollowups.date)),
      hoursForEnrollment(ctx.org.id, e.id),
      db.select({ id: schema.documents.id }).from(schema.documents).where(and(eq(schema.documents.orgId, ctx.org.id), eq(schema.documents.enrollmentId, e.id), eq(schema.documents.category, "livret"))).orderBy(desc(schema.documents.createdAt)).limit(1),
    ]);
    const pdf = await renderLivretPdf({ org: ctx.org, person, enrollment: e, session, program: program ?? null, evaluations, entries, followups, hours });
    const doc = await createDocument({
      orgId: ctx.org.id,
      enrollmentId: e.id,
      personId: e.personId,
      sessionId: e.sessionId,
      category: "livret",
      visibility: "pedagogie",
      status: "genere",
      title: `Livret de suivi ${e.reference}`,
      fileName: `livret-${e.reference}.pdf`,
      mimeType: "application/pdf",
      data: pdf,
      sourceType: "enrollment",
      sourceId: e.id,
      previousVersionId: previous[0]?.id ?? null,
      generationData: { evaluations: evaluations.length, entries: entries.length, followups: followups.length, hours },
      uploadedBy: ctx.user.id,
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "document.generate", userId: ctx.user.id, orgId: ctx.org.id, entityType: "document", entityId: doc.id, after: { category: "livret", enrollmentId: e.id, version: doc.version } });
    revalidatePath(`/app/${ctx.org.id}/evaluations`);
    return { ok: true, message: `Livret généré (version ${doc.version}). Retrouvez-le dans les documents de l'inscription.` };
  } catch (e) {
    return fail(e, "Génération impossible.");
  }
}

const followupSchema = z.object({
  enrollmentId: uuid,
  kind: z.enum(["visite", "appel", "visio", "bilan_intermediaire", "bilan_final", "echange_tuteur", "incident"]),
  date: isoDate,
  tutorContactId: optUuid,
  summary: z.string().trim().min(3, "Résumé requis").max(4000),
  actions: z.string().trim().max(2000).optional(),
  nextDate: z.preprocess((v) => (v === "" || v == null ? undefined : v), isoDate.optional()),
});

/** Suivi en entreprise (visite, appel, bilan avec le tuteur) avec prochaine échéance ; résout le rappel en retard. */
export async function createFollowupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "dossier.pedagogy.manage");
    const d = followupSchema.parse(Object.fromEntries(formData));
    if (isFutureDate(d.date, todayParis())) return { error: "La date du suivi est dans le futur : enregistrez-le une fois réalisé (la prochaine date sert à planifier)." };
    const e = await loadEnrollment(ctx, d.enrollmentId);
    if (d.tutorContactId) {
      const [c] = await db.select({ id: schema.contacts.id }).from(schema.contacts).where(and(eq(schema.contacts.id, d.tutorContactId), eq(schema.contacts.orgId, ctx.org.id))).limit(1);
      if (!c) return { error: "Tuteur inconnu." };
    }
    const [last] = await db.select({ nextDate: schema.companyFollowups.nextDate }).from(schema.companyFollowups).where(and(eq(schema.companyFollowups.orgId, ctx.org.id), eq(schema.companyFollowups.enrollmentId, e.id))).orderBy(desc(schema.companyFollowups.date)).limit(1);
    const [row] = await db
      .insert(schema.companyFollowups)
      .values({ orgId: ctx.org.id, enrollmentId: e.id, kind: d.kind, date: d.date, tutorContactId: d.tutorContactId ?? e.tutorContactId ?? null, summary: d.summary, actions: d.actions || null, nextDate: d.nextDate ?? null, authorId: ctx.user.id })
      .returning({ id: schema.companyFollowups.id });
    await resolveFollowupReminder(ctx.org.id, e.id, last?.nextDate ?? null, ctx.user.id);
    await audit({ action: "followup.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "company_followup", entityId: row.id, after: { enrollmentId: e.id, kind: d.kind, date: d.date, nextDate: d.nextDate } });
    if (d.kind !== "incident") {
      await recordEvidence({ orgId: ctx.org.id, indicatorCode: "IND_12", level: "individuel", title: `Suivi en entreprise (${d.kind}) du ${d.date}`, sourceType: "company_followup", sourceId: row.id, evidenceDate: d.date, enrollmentId: e.id, sessionId: e.sessionId, createdBy: ctx.user.id });
    }
    revalidatePath(`/app/${ctx.org.id}/suivi-entreprise`);
    return { ok: true, message: "Suivi enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}
