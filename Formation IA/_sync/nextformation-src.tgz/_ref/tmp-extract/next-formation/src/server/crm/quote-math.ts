/**
 * Calculs de devis (fonctions pures, testées) : totaux en centimes entiers, numérotation DEV-YYYY-NNNN.
 * Les montants ne passent jamais par un flottant en euros : prix unitaire en centimes, TVA en points de base (2000 = 20 %).
 */

export type QuoteLine = { label: string; description?: string | null; qty: number; unitCents: number; vatRateBp: number };

export type QuoteTotals = { totalHtCents: number; vatCents: number; totalTtcCents: number; byRate: { rateBp: number; baseCents: number; vatCents: number }[] };

/** Taux de TVA proposés (points de base). La formation professionnelle peut être exonérée (art. 261-4-4° CGI) : 0 %. */
export const VAT_RATES_BP = [0, 550, 1000, 2000] as const;

export function lineHtCents(line: Pick<QuoteLine, "qty" | "unitCents">): number {
  return Math.round(line.qty * line.unitCents);
}

/** TVA d'une ligne : base × taux / 10000, arrondi au centime le plus proche (demi vers le haut). */
export function lineVatCents(line: Pick<QuoteLine, "qty" | "unitCents" | "vatRateBp">): number {
  const base = lineHtCents(line);
  return Math.round((base * line.vatRateBp) / 10000 + Number.EPSILON);
}

/** Totaux d'un devis : HT = somme des lignes ; TVA calculée par taux sur la base agrégée (évite les écarts d'arrondi ligne à ligne). */
export function computeTotals(lines: QuoteLine[]): QuoteTotals {
  const byRateMap = new Map<number, number>();
  let totalHtCents = 0;
  for (const l of lines) {
    const base = lineHtCents(l);
    totalHtCents += base;
    byRateMap.set(l.vatRateBp, (byRateMap.get(l.vatRateBp) ?? 0) + base);
  }
  const byRate = [...byRateMap.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([rateBp, baseCents]) => ({ rateBp, baseCents, vatCents: Math.round((baseCents * rateBp) / 10000 + Number.EPSILON) }));
  const vatCents = byRate.reduce((a, r) => a + r.vatCents, 0);
  return { totalHtCents, vatCents, totalTtcCents: totalHtCents + vatCents, byRate };
}

/** Numéro de devis : DEV-2026-0001 (séquence par organisme et par année). */
export function formatQuoteNumber(year: number, seq: number, prefix = "DEV"): string {
  return `${prefix}-${year}-${String(seq).padStart(4, "0")}`;
}

export function vatRateLabel(bp: number): string {
  return `${(bp / 100).toLocaleString("fr-FR", { maximumFractionDigits: 2 })} %`;
}

/** Valide et normalise les lignes transmises par le formulaire (JSON). */
export function parseLines(raw: unknown): { ok: true; lines: QuoteLine[] } | { ok: false; error: string } {
  if (!Array.isArray(raw)) return { ok: false, error: "Lignes du devis invalides." };
  if (raw.length === 0) return { ok: false, error: "Ajoutez au moins une ligne au devis." };
  if (raw.length > 100) return { ok: false, error: "Un devis ne peut pas dépasser 100 lignes." };
  const lines: QuoteLine[] = [];
  for (const [i, item] of raw.entries()) {
    const o = (item ?? {}) as Record<string, unknown>;
    const label = typeof o.label === "string" ? o.label.trim() : "";
    if (!label) return { ok: false, error: `Ligne ${i + 1} : libellé requis.` };
    if (label.length > 300) return { ok: false, error: `Ligne ${i + 1} : libellé trop long.` };
    const description = typeof o.description === "string" && o.description.trim() ? o.description.trim().slice(0, 1000) : null;
    const qty = Number(o.qty);
    if (!Number.isFinite(qty) || qty <= 0 || qty > 100000) return { ok: false, error: `Ligne ${i + 1} : quantité invalide.` };
    const unitCents = Number(o.unitCents);
    if (!Number.isInteger(unitCents) || unitCents < 0 || unitCents > 1_000_000_000) return { ok: false, error: `Ligne ${i + 1} : prix unitaire invalide.` };
    const vatRateBp = Number(o.vatRateBp);
    if (!Number.isInteger(vatRateBp) || vatRateBp < 0 || vatRateBp > 10000) return { ok: false, error: `Ligne ${i + 1} : taux de TVA invalide.` };
    lines.push({ label, description, qty: Math.round(qty * 100) / 100, unitCents, vatRateBp });
  }
  return { ok: true, lines };
}
