import "server-only";
import type { OrgContext } from "@/server/authz";
import { assertEnrollmentInScope, assertSessionInScope } from "@/server/authz";
import { qualitySummary } from "../tools";
import type { Agent, AgentInput, ProposalDraft } from "../store";
import { askJson, baseRationale, requireEntity, toPromptJson } from "./shared";

export type QualitePayload = {
  scope: "organisme" | "session" | "inscription" | "programme";
  scopeId: string | null;
  proven: string[];
  missing: string[];
  review: string[];
  text: string;
  /** Tâches proposées pour les manques (créées seulement après validation, jamais une preuve). */
  proposedTasks: { title: string; indicatorCode?: string }[];
};

type Control = { indicator: string; status: "prouve" | "absent" | "non_applicable" | "a_examiner"; note?: string };

const scopeOfEntity: Record<string, QualitePayload["scope"]> = { organisme: "organisme", session: "session", enrollment: "inscription", program: "programme" };

/** Synthèse déterministe : lecture de la dernière photographie d'analyse et des preuves par indicateur. */
export function deterministicQualite(summary: { analysis: { summary?: Record<string, unknown>; controls?: Control[]; referenceDate?: string } | string; evidencesByIndicator: Record<string, number> }): Omit<QualitePayload, "scope" | "scopeId"> {
  const proven: string[] = [];
  const missing: string[] = [];
  const review: string[] = [];
  if (typeof summary.analysis === "string") {
    review.push("Aucune analyse qualité enregistrée : lancer une analyse pour obtenir une photographie. Sans photographie, aucune conclusion de conformité n'est possible.");
  } else {
    for (const c of summary.analysis.controls ?? []) {
      const label = `${c.indicator}${c.note ? ` : ${c.note}` : ""}`;
      if (c.status === "prouve") proven.push(label);
      else if (c.status === "absent") missing.push(label);
      else if (c.status === "a_examiner") review.push(label);
    }
  }
  for (const [code, n] of Object.entries(summary.evidencesByIndicator)) if (!proven.some((p) => p.startsWith(code))) proven.push(`${code} : ${n} preuve(s) valide(s) enregistrée(s)`);
  const text = [
    typeof summary.analysis === "string" ? "Aucune photographie d'analyse." : `Analyse du ${summary.analysis.referenceDate ?? "?"} (photographie immuable).`,
    `Prouvé : ${proven.length ? proven.join(" ; ") : "rien de prouvé selon la photographie"}.`,
    `Manquant : ${missing.length ? missing.join(" ; ") : "aucun manque identifié"}.`,
    `À examiner par un humain : ${review.length ? review.join(" ; ") : "rien"}.`,
    "Un pourcentage de couverture n'est pas une attestation de conformité.",
  ].join("\n");
  return { proven, missing, review, text, proposedTasks: missing.map((m) => ({ title: `Produire la preuve manquante : ${m}`, indicatorCode: m.split(" ")[0] })) };
}

export const qualiteAgent: Agent = {
  name: "qualite",
  label: "Synthèse qualité explicable",
  description: "Ce qui est prouvé, manquant ou à examiner pour un dossier, une session ou l'organisme, à partir des analyses et preuves existantes. Ne crée jamais une preuve.",
  requires: "quality.view",
  accepts: ["organisme", "session", "enrollment", "program"],
  async run(ctx: OrgContext, input: AgentInput): Promise<ProposalDraft> {
    const entityType = input.entityType && input.entityType in scopeOfEntity ? input.entityType : "organisme";
    const scope = scopeOfEntity[entityType];
    let scopeId: string | null = null;
    if (scope !== "organisme") {
      scopeId = requireEntity(input, ["session", "enrollment", "program"]).entityId;
      if (scope === "session") await assertSessionInScope(ctx, scopeId);
      if (scope === "inscription") await assertEnrollmentInScope(ctx, scopeId);
    }
    const summary = (await qualitySummary(ctx, scope, scopeId)) as Parameters<typeof deterministicQualite>[0];
    const det = deterministicQualite(summary);
    const ai = await askJson<Partial<Omit<QualitePayload, "scope" | "scopeId">> & { certainty?: "A" | "B" | "C" }>(
      `Rédige une synthèse qualité explicable (référentiel Qualiopi). Réponds en JSON : {"proven": string[], "missing": string[], "review": string[], "text": string, "certainty": "A"|"B"|"C"}. Tu ne déclares jamais un indicateur prouvé sans preuve listée ; sans analyse, tu dis qu'il n'y a pas de photographie.`,
      `Données qualité :\n${toPromptJson(summary)}\n\nLecture déterministe :\n${JSON.stringify(det)}`,
    );
    const merged = ai?.data?.text ? { ...det, ...ai.data, proven: Array.isArray(ai.data.proven) ? ai.data.proven : det.proven, missing: Array.isArray(ai.data.missing) ? ai.data.missing : det.missing, review: Array.isArray(ai.data.review) ? ai.data.review : det.review } : det;
    const payload: QualitePayload = { scope, scopeId, proven: merged.proven, missing: merged.missing, review: merged.review, text: merged.text, proposedTasks: det.proposedTasks };
    return {
      agent: "qualite",
      kind: "synthese_qualite",
      title: `Synthèse qualité : ${scope}${scopeId ? ` ${scopeId.slice(0, 8)}` : ""}`,
      summary: `${payload.proven.length} prouvé(s), ${payload.missing.length} manquant(s), ${payload.review.length} à examiner`,
      entityType,
      entityId: scopeId,
      payload: payload as unknown as Record<string, unknown>,
      rationale: baseRationale(
        [{ type: "quality_analysis", label: "Dernière analyse (photographie immuable)" }, { type: "quality_evidences", label: "Preuves valides par indicateur" }],
        ai?.data?.certainty ?? "A",
        !ai,
        ["Le système n'invente jamais une preuve : validation = création de tâches « produire la preuve » pour le rôle qualité, rien d'autre.", "Un pourcentage n'est pas une attestation (F13)."],
      ),
      provider: ai?.result.provider ?? null,
      model: ai?.result.model ?? null,
    };
  },
};
