import "server-only";
import { and, asc, desc, eq, inArray, isNotNull, ne, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { trainerSessionIds, type OrgContext } from "@/server/authz";
import { fmtDate } from "@/lib/dates";
import { carifPerimeterLabel, carifRecruitmentTypeLabel, readCarifPublics, readCarifRecruitment } from "./carif";

/**
 * Déclarations externes préparées depuis les données (Carif-Oref par session, Kairos AIF et EDOF par inscription).
 * Chaque champ porte sa valeur ou `null` (affiché « À compléter ») : aucune valeur n'est inventée.
 * Heures : uniquement les heures prévues (inscription, sinon durée de la version de programme), jamais additionnées à
 * d'autres types d'heures.
 */

export type DeclField = { key: string; label: string; value: string | null; help?: string; group: string };
export type DeclRow = { id: string; title: string; subtitle: string; href: string; fields: DeclField[] };

/* ---------- Statuts de dossier (alignés sur les parcours automatiques cpf / aif) ---------- */

export const KAIROS_STATUSES = [
  { value: "transmis", label: "Devis saisi et transmis au demandeur d'emploi" },
  { value: "valide_de", label: "Devis validé par le demandeur d'emploi" },
  { value: "accorde", label: "Accord France Travail" },
  { value: "refuse", label: "Refus France Travail" },
  { value: "entree", label: "Entrée en formation déclarée" },
  { value: "sortie", label: "Sortie de formation déclarée" },
] as const;

export const EDOF_STATUSES = [
  { value: "valide", label: "Commande validée" },
  { value: "entree", label: "Entrée en formation déclarée" },
  { value: "sortie", label: "Sortie de formation déclarée" },
  { value: "facture", label: "Facturé sur EDOF" },
] as const;

export const kairosStatusLabel = (v: string | null | undefined) => (v ? (KAIROS_STATUSES.find((s) => s.value === v)?.label ?? v) : "Non renseigné");
export const edofStatusLabel = (v: string | null | undefined) => (v ? (EDOF_STATUSES.find((s) => s.value === v)?.label ?? v) : "Non renseigné");

/* ---------- Formats ---------- */

const d = (v: string | null | undefined) => (v ? fmtDate(v, "dd/MM/yyyy") : null);
const euros = (c: number | null | undefined) => (c === null || c === undefined ? null : (c / 100).toFixed(2).replace(".", ","));
const txt = (v: string | null | undefined) => (v && v.trim() ? v.trim() : null);
const num = (v: number | null | undefined) => (v === null || v === undefined ? null : String(v));

/** Modalité Carif-Oref : présentiel, à distance, alternance, alternance à distance (onglet 7). */
function carifModality(modality: string, apprenticeship: boolean): string | null {
  const remote = modality === "distanciel" || modality === "elearning";
  if (apprenticeship) return remote ? "En alternance à distance" : "En alternance";
  if (modality === "presentiel") return "En présentiel";
  if (remote) return "À distance";
  return null;
}

function identifier(raw: unknown, keys: string[]): string | null {
  const ids = (raw ?? {}) as Record<string, unknown>;
  for (const k of keys) {
    const v = ids[k];
    if (typeof v === "string" && v.trim()) return v.trim();
  }
  return null;
}

async function orgIdentity(orgId: string) {
  const [o] = await db.select({ legalName: schema.organismes.legalName, siret: schema.organismes.siret, nda: schema.organismes.nda, uai: schema.organismes.uaiCode }).from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  return o ?? { legalName: null, siret: null, nda: null, uai: null };
}

function orgFields(o: Awaited<ReturnType<typeof orgIdentity>>): DeclField[] {
  return [
    { group: "Organisme", key: "org_raison_sociale", label: "Raison sociale", value: txt(o.legalName) },
    { group: "Organisme", key: "org_siret", label: "SIRET", value: txt(o.siret), help: "Paramètres de l'organisme." },
    { group: "Organisme", key: "org_nda", label: "Numéro de déclaration d'activité", value: txt(o.nda) },
  ];
}

async function scopeCondition(ctx: OrgContext): Promise<SQL | undefined> {
  const ids = await trainerSessionIds(ctx);
  if (!ids) return undefined;
  return ids.length ? inArray(schema.trainingSessions.id, ids) : sql`false`;
}

/* ---------- Carif-Oref (par session) ---------- */

export async function carifDeclarations(ctx: OrgContext, opts: { sessionId?: string | null } = {}): Promise<DeclRow[]> {
  const orgId = ctx.org.id;
  const org = await orgIdentity(orgId);
  const rows = await db
    .select({ s: schema.trainingSessions, v: schema.programVersions, p: schema.programs, c: schema.certifications, site: schema.sites })
    .from(schema.trainingSessions)
    .innerJoin(schema.programVersions, and(eq(schema.programVersions.id, schema.trainingSessions.programVersionId), eq(schema.programVersions.orgId, orgId)))
    .innerJoin(schema.programs, and(eq(schema.programs.id, schema.programVersions.programId), eq(schema.programs.orgId, orgId)))
    .leftJoin(schema.certifications, and(eq(schema.certifications.id, schema.programs.certificationId), eq(schema.certifications.orgId, orgId)))
    .leftJoin(schema.sites, and(eq(schema.sites.id, schema.trainingSessions.siteId), eq(schema.sites.orgId, orgId)))
    .where(and(eq(schema.trainingSessions.orgId, orgId), ne(schema.trainingSessions.status, "annulee"), opts.sessionId ? eq(schema.trainingSessions.id, opts.sessionId) : undefined, await scopeCondition(ctx)))
    .orderBy(desc(schema.trainingSessions.startDate))
    .limit(300);
  return rows.map(({ s, v, p, c, site }) => {
    const recruitment = readCarifRecruitment(s.recruitment);
    const publics = readCarifPublics(s.publics);
    const rhythm = (s.rhythm ?? {}) as { label?: string };
    const fields: DeclField[] = [
      ...orgFields(org),
      { group: "Formation", key: "formation_intitule", label: "Intitulé de la formation", value: txt(p.title) },
      { group: "Formation", key: "formation_code", label: "Code programme", value: txt(p.code) },
      { group: "Formation", key: "formacode", label: "Formacode", value: txt(p.formacode), help: "Fiche programme (catalogue)." },
      { group: "Formation", key: "code_rncp", label: "Code RNCP", value: txt(c?.rncpCode) },
      { group: "Formation", key: "code_rs", label: "Code RS", value: txt(c?.rsCode) },
      { group: "Session", key: "session_carif", label: "Numéro de session Carif-Oref", value: txt(s.carifSessionNumber), help: "Section « Déclaration Carif-Oref » de la session." },
      { group: "Session", key: "session_code", label: "Code session (interne)", value: txt(s.code) },
      { group: "Session", key: "session_intitule", label: "Intitulé de la session", value: txt(s.title) },
      { group: "Session", key: "modalite", label: "Modalité", value: carifModality(s.modality, s.isApprenticeship), help: s.modality === "mixte" || s.modality === "afest" ? "Modalité mixte ou AFEST : choisir sur le Carif entre présentiel et à distance." : undefined },
      { group: "Session", key: "date_debut", label: "Date de début", value: d(s.startDate) },
      { group: "Session", key: "date_fin", label: "Date de fin", value: d(s.endDate) },
      { group: "Session", key: "duree_heures", label: "Durée prévue (heures)", value: v.durationHours ? String(v.durationHours) : null },
      ...(s.isApprenticeship ? [{ group: "Session", key: "heures_entreprise", label: "Dont heures en entreprise", value: v.companyHours ? String(v.companyHours) : null }, { group: "Session", key: "rythme", label: "Rythme alternance", value: txt(rhythm.label) }] : []),
      { group: "Effectif", key: "effectif_minimal", label: "Effectif minimal", value: num(s.minCapacity) },
      { group: "Effectif", key: "effectif_simultane", label: "Effectif simultané", value: num(s.capacity) },
      { group: "Effectif", key: "effectif_total", label: "Effectif total", value: num(s.totalCapacity), help: "Section « Déclaration Carif-Oref » de la session." },
      { group: "Lieu", key: "lieu_nom", label: "Lieu", value: txt(site?.name) },
      { group: "Lieu", key: "lieu_adresse", label: "Adresse", value: txt(site?.addressLine1) },
      { group: "Lieu", key: "lieu_cp", label: "Code postal", value: txt(site?.postalCode) },
      { group: "Lieu", key: "lieu_ville", label: "Ville", value: txt(site?.city) },
      ...(s.isApprenticeship ? [{ group: "Lieu", key: "uai", label: "UAI", value: txt(org.uai), help: "Demandé pour les formations en apprentissage." }] : []),
      { group: "Tarif", key: "prix_ht", label: "Prix HT (euros)", value: euros(s.priceCents ?? v.priceCents) },
      {
        group: "Recrutement",
        key: "recrutement",
        label: "Recrutement",
        value: recruitment.length ? recruitment.map((r) => [carifRecruitmentTypeLabel(r.type), r.perimeter ? `périmètre ${carifPerimeterLabel(r.perimeter).toLowerCase()}` : null, r.date ? `${d(r.date)}${r.startTime ? ` ${r.startTime}-${r.endTime}` : ""}` : null, r.details || null].filter(Boolean).join(", ")).join(" | ") : null,
      },
      { group: "Recrutement", key: "publics", label: "Publics et financements", value: publics.length ? publics.map((x) => [x.audience, x.modalities, x.funder].filter(Boolean).join(", ")).join(" | ") : null },
    ];
    return { id: s.id, title: `${s.code} · ${s.title}`, subtitle: `${fmtDate(s.startDate)} au ${fmtDate(s.endDate)}`, href: `/app/${orgId}/sessions/${s.id}`, fields };
  });
}

/* ---------- Inscriptions (Kairos / EDOF) ---------- */

type EnrollmentRow = {
  e: typeof schema.enrollments.$inferSelect;
  s: typeof schema.trainingSessions.$inferSelect;
  person: typeof schema.persons.$inferSelect;
  v: typeof schema.programVersions.$inferSelect | null;
  p: typeof schema.programs.$inferSelect | null;
  c: typeof schema.certifications.$inferSelect | null;
};

async function enrollmentRows(ctx: OrgContext, kind: "aif" | "cpf", opts: { sessionId?: string | null; enrollmentId?: string | null }): Promise<EnrollmentRow[]> {
  const orgId = ctx.org.id;
  const fundingKind = kind === "aif" ? "france_travail" : "cpf";
  const hasFunding = sql`exists (select 1 from ${schema.fundings} f where f.enrollment_id = ${schema.enrollments.id} and f.org_id = ${orgId} and f.kind = ${fundingKind} and f.status <> 'annule')`;
  const population =
    kind === "aif"
      ? or(isNotNull(schema.enrollments.kairosStatus), eq(schema.enrollments.workflowCode, "aif"), hasFunding)
      : or(isNotNull(schema.enrollments.edofStatus), eq(schema.enrollments.workflowCode, "cpf"), eq(schema.enrollments.contractKind, "cpf"), hasFunding);
  return db
    .select({ e: schema.enrollments, s: schema.trainingSessions, person: schema.persons, v: schema.programVersions, p: schema.programs, c: schema.certifications })
    .from(schema.enrollments)
    .innerJoin(schema.trainingSessions, and(eq(schema.trainingSessions.id, schema.enrollments.sessionId), eq(schema.trainingSessions.orgId, orgId)))
    .innerJoin(schema.persons, and(eq(schema.persons.id, schema.enrollments.personId), eq(schema.persons.orgId, orgId)))
    .leftJoin(schema.programVersions, and(eq(schema.programVersions.id, sql`coalesce(${schema.enrollments.programVersionId}, ${schema.trainingSessions.programVersionId})`), eq(schema.programVersions.orgId, orgId)))
    .leftJoin(schema.programs, and(eq(schema.programs.id, schema.programVersions.programId), eq(schema.programs.orgId, orgId)))
    .leftJoin(schema.certifications, and(eq(schema.certifications.id, schema.programs.certificationId), eq(schema.certifications.orgId, orgId)))
    .where(
      and(
        eq(schema.enrollments.orgId, orgId),
        inArray(schema.enrollments.status, ["preinscrit", "inscrit", "en_cours", "termine", "abandon", "reporte"]),
        population,
        opts.sessionId ? eq(schema.enrollments.sessionId, opts.sessionId) : undefined,
        opts.enrollmentId ? eq(schema.enrollments.id, opts.enrollmentId) : undefined,
        await scopeCondition(ctx),
      ),
    )
    .orderBy(desc(schema.trainingSessions.startDate), asc(schema.persons.lastName))
    .limit(300);
}

async function fundingsFor(orgId: string, enrollmentIds: string[], kind: "france_travail" | "cpf") {
  if (!enrollmentIds.length) return new Map<string, typeof schema.fundings.$inferSelect>();
  const rows = await db
    .select()
    .from(schema.fundings)
    .where(and(eq(schema.fundings.orgId, orgId), inArray(schema.fundings.enrollmentId, enrollmentIds), eq(schema.fundings.kind, kind), ne(schema.fundings.status, "annule")))
    .orderBy(desc(schema.fundings.createdAt));
  const map = new Map<string, typeof schema.fundings.$inferSelect>();
  for (const f of rows) if (!map.has(f.enrollmentId)) map.set(f.enrollmentId, f);
  return map;
}

const plannedHours = (r: EnrollmentRow) => (r.e.hoursPlanned > 0 ? String(r.e.hoursPlanned) : r.v?.durationHours ? String(r.v.durationHours) : null);
const price = (r: EnrollmentRow) => euros(r.e.priceCents ?? r.s.priceCents ?? r.v?.priceCents ?? null);

export type EnrollmentDecl = DeclRow & { status: string | null; statusLabel: string; enrollmentId: string; reference: string; ref?: string | null; entryAt?: string | null; exitAt?: string | null; startDate: string; firstLoginAt?: Date | null };

export async function kairosDeclarations(ctx: OrgContext, opts: { sessionId?: string | null; enrollmentId?: string | null } = {}): Promise<EnrollmentDecl[]> {
  const orgId = ctx.org.id;
  const [org, rows] = await Promise.all([orgIdentity(orgId), enrollmentRows(ctx, "aif", opts)]);
  const fundings = await fundingsFor(orgId, rows.map((r) => r.e.id), "france_travail");
  return rows.map((r) => {
    const f = fundings.get(r.e.id);
    const fields: DeclField[] = [
      { group: "Demandeur d'emploi", key: "de_nom", label: "Nom", value: txt(r.person.lastName) },
      { group: "Demandeur d'emploi", key: "de_prenom", label: "Prénom", value: txt(r.person.firstName) },
      { group: "Demandeur d'emploi", key: "de_identifiant", label: "Identifiant France Travail", value: identifier(r.person.identifiers, ["France Travail", "france_travail", "franceTravail"]), help: "Fiche apprenant, identifiants. À demander au prospect avant la saisie du devis." },
      { group: "Demandeur d'emploi", key: "de_zone", label: "Zone géographique", value: null, help: "À demander au demandeur d'emploi : elle n'est pas enregistrée dans Next Formation." },
      { group: "Demandeur d'emploi", key: "de_cp", label: "Code postal (adresse)", value: txt(r.person.postalCode) },
      ...orgFields(org),
      { group: "Formation", key: "session_carif", label: "Numéro de session Carif-Oref", value: txt(r.s.carifSessionNumber), help: "Renseigné sur la session (section « Déclaration Carif-Oref »)." },
      { group: "Formation", key: "formation_intitule", label: "Intitulé de la formation", value: txt(r.p?.title ?? r.s.title) },
      { group: "Formation", key: "formation_reglementee", label: "Formation réglementée", value: "Non", help: "Process interne de saisie Kairos : cocher « non ». À corriger si la formation est réglementée." },
      { group: "Formation", key: "date_debut", label: "Date de début", value: d(r.e.startDate ?? r.s.startDate) },
      { group: "Formation", key: "date_fin", label: "Date de fin", value: d(r.e.endDate ?? r.s.endDate) },
      { group: "Formation", key: "heures", label: "Durée prévue (heures)", value: plannedHours(r) },
      { group: "Formation", key: "prix_ht", label: "Prix HT (euros)", value: price(r) },
      { group: "Formation", key: "montant_pec", label: "Montant de prise en charge France Travail (euros)", value: f ? euros(f.amountCents) : null, help: "Financement de type France Travail de l'inscription." },
      { group: "Suivi", key: "kairos_devis", label: "Référence du devis Kairos", value: txt(r.e.kairosDevisRef) },
      { group: "Suivi", key: "kairos_statut", label: "Statut Kairos", value: r.e.kairosStatus ? kairosStatusLabel(r.e.kairosStatus) : null },
    ];
    return {
      id: r.e.id,
      enrollmentId: r.e.id,
      reference: r.e.reference,
      title: `${r.person.lastName.toUpperCase()} ${r.person.firstName}`,
      subtitle: `${r.e.reference} · ${r.s.code} · ${fmtDate(r.e.startDate ?? r.s.startDate)}`,
      href: `/app/${orgId}/inscriptions/${r.e.id}`,
      fields,
      status: r.e.kairosStatus,
      statusLabel: kairosStatusLabel(r.e.kairosStatus),
      ref: r.e.kairosDevisRef,
      startDate: r.e.startDate ?? r.s.startDate,
    };
  });
}

export async function edofDeclarations(ctx: OrgContext, opts: { sessionId?: string | null; enrollmentId?: string | null } = {}): Promise<EnrollmentDecl[]> {
  const orgId = ctx.org.id;
  const [org, rows] = await Promise.all([orgIdentity(orgId), enrollmentRows(ctx, "cpf", opts)]);
  const fundings = await fundingsFor(orgId, rows.map((r) => r.e.id), "cpf");
  return rows.map((r) => {
    const f = fundings.get(r.e.id);
    const fields: DeclField[] = [
      { group: "Titulaire", key: "titulaire_nom", label: "Nom", value: txt(r.person.lastName) },
      { group: "Titulaire", key: "titulaire_prenom", label: "Prénom", value: txt(r.person.firstName) },
      { group: "Titulaire", key: "titulaire_email", label: "E-mail", value: txt(r.person.email) },
      { group: "Titulaire", key: "dossier_cpf", label: "Numéro de dossier CPF", value: txt(f?.agreementRef) ?? txt(r.e.contractNumber), help: "Référence du financement CPF (ou numéro de contrat de l'inscription)." },
      ...orgFields(org),
      { group: "Formation", key: "formation_intitule", label: "Intitulé de la formation", value: txt(r.p?.title ?? r.s.title) },
      { group: "Formation", key: "code_rncp", label: "Code RNCP", value: txt(r.c?.rncpCode) },
      { group: "Formation", key: "code_rs", label: "Code RS", value: txt(r.c?.rsCode) },
      { group: "Formation", key: "certificateur", label: "Certificateur", value: txt(r.c?.certifier) },
      { group: "Formation", key: "session_code", label: "Code session", value: txt(r.s.code) },
      { group: "Formation", key: "date_debut", label: "Date de début prévue", value: d(r.e.startDate ?? r.s.startDate) },
      { group: "Formation", key: "date_fin", label: "Date de fin prévue", value: d(r.e.endDate ?? r.s.endDate) },
      { group: "Formation", key: "heures", label: "Durée prévue (heures)", value: plannedHours(r) },
      { group: "Formation", key: "prix", label: "Prix (euros)", value: f ? euros(f.amountCents) : price(r), help: f ? "Montant du financement CPF." : "Prix de l'inscription, de la session ou du programme." },
      { group: "Déclarations", key: "connexion_elearning", label: "Première connexion e-learning", value: r.e.elearningFirstLoginAt ? fmtDate(r.e.elearningFirstLoginAt, "dd/MM/yyyy HH:mm") : null, help: "L'entrée en formation sur EDOF n'est possible qu'avec une trace de connexion." },
      { group: "Déclarations", key: "edof_entree", label: "Entrée en formation déclarée le", value: d(r.e.edofEntryAt) },
      { group: "Déclarations", key: "edof_sortie", label: "Sortie de formation déclarée le", value: d(r.e.edofExitAt) },
      { group: "Déclarations", key: "edof_statut", label: "Statut EDOF", value: r.e.edofStatus ? edofStatusLabel(r.e.edofStatus) : null },
    ];
    return {
      id: r.e.id,
      enrollmentId: r.e.id,
      reference: r.e.reference,
      title: `${r.person.lastName.toUpperCase()} ${r.person.firstName}`,
      subtitle: `${r.e.reference} · ${r.s.code} · ${fmtDate(r.e.startDate ?? r.s.startDate)}`,
      href: `/app/${orgId}/inscriptions/${r.e.id}`,
      fields,
      status: r.e.edofStatus,
      statusLabel: edofStatusLabel(r.e.edofStatus),
      entryAt: r.e.edofEntryAt,
      exitAt: r.e.edofExitAt,
      startDate: r.e.startDate ?? r.s.startDate,
      firstLoginAt: r.e.elearningFirstLoginAt,
    };
  });
}

/* ---------- Export CSV ---------- */

/** CSV « ; » UTF-8 avec BOM ; cellules neutralisées contre l'injection de formules. Champ manquant = cellule vide. */
export function declarationsCsv(rows: DeclRow[]): string {
  const headers = rows[0]?.fields.map((f) => f.label) ?? [];
  const esc = (v: string | null) => {
    let s = v ?? "";
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
    return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  // Les lignes peuvent avoir des champs conditionnels (apprentissage) : alignement par clé.
  const keys: { key: string; label: string }[] = [];
  for (const r of rows) for (const f of r.fields) if (!keys.some((k) => k.key === f.key)) keys.push({ key: f.key, label: f.label });
  const head = keys.length ? keys.map((k) => k.label) : headers;
  const body = rows.map((r) => keys.map((k) => esc(r.fields.find((f) => f.key === k.key)?.value ?? null)).join(";"));
  return `﻿${head.map((h) => esc(h)).join(";")}\n${body.join("\n")}\n`;
}
