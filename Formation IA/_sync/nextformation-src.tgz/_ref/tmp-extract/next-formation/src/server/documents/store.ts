import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { buildKey, getObject, putObject } from "@/server/storage";
import { issueToken, peekToken } from "@/server/auth";
import { appUrl } from "@/lib/env";

type Category = (typeof schema.documentCategoryEnum.enumValues)[number];
type Visibility = (typeof schema.documentVisibilityEnum.enumValues)[number];
type Status = (typeof schema.documentStatusEnum.enumValues)[number];

/** Enregistre un fichier dans le stockage privé et crée la ligne `documents`. Retourne la ligne. */
export async function createDocument(input: {
  orgId: string;
  personId?: string | null;
  enrollmentId?: string | null;
  sessionId?: string | null;
  companyId?: string | null;
  trainerId?: string | null;
  category: Category;
  visibility?: Visibility;
  status?: Status;
  templateCode?: string | null;
  generationData?: unknown;
  title: string;
  fileName: string;
  mimeType: string;
  data: Buffer;
  sourceType?: string;
  sourceId?: string | null;
  uploadedBy?: string | null;
  previousVersionId?: string | null;
  retentionYears?: number;
  isDemo?: boolean;
}) {
  const key = buildKey(input.orgId, input.category, input.fileName);
  const stored = await putObject(key, input.data);
  let version = 1;
  if (input.previousVersionId) {
    const [prev] = await db.select({ v: schema.documents.version }).from(schema.documents).where(eq(schema.documents.id, input.previousVersionId)).limit(1);
    version = (prev?.v ?? 0) + 1;
  }
  const retentionUntil = input.retentionYears ? new Date(Date.now() + input.retentionYears * 365.25 * 86400_000) : null;
  const [row] = await db
    .insert(schema.documents)
    .values({
      orgId: input.orgId,
      personId: input.personId ?? null,
      enrollmentId: input.enrollmentId ?? null,
      sessionId: input.sessionId ?? null,
      companyId: input.companyId ?? null,
      trainerId: input.trainerId ?? null,
      category: input.category,
      visibility: input.visibility ?? "interne",
      status: input.status ?? "genere",
      templateCode: input.templateCode ?? null,
      generationData: input.generationData ?? null,
      title: input.title,
      fileName: input.fileName,
      mimeType: input.mimeType,
      sizeBytes: stored.size,
      storageKey: key,
      sha256: stored.sha256,
      version,
      previousVersionId: input.previousVersionId ?? null,
      sourceType: input.sourceType,
      sourceId: input.sourceId ?? null,
      retentionUntil,
      uploadedBy: input.uploadedBy ?? null,
      isDemo: input.isDemo ?? false,
    })
    .returning();
  return row;
}

export async function readDocument(documentId: string) {
  const [doc] = await db.select().from(schema.documents).where(eq(schema.documents.id, documentId)).limit(1);
  if (!doc) return null;
  return { doc, data: await getObject(doc.storageKey) };
}

/** Lien de téléchargement temporaire (15 min), lié à l'utilisateur qui l'a demandé. */
export async function issueDownloadLink(documentId: string, userId: string, ttlMinutes = 15) {
  const token = await issueToken("download", { userId, payload: { documentId }, ttlMinutes });
  return `${appUrl()}/telechargement/${token}`;
}

export async function resolveDownloadToken(token: string) {
  const row = await peekToken("download", token);
  const payload = row?.payload as { documentId?: string } | undefined;
  if (!row || !payload?.documentId) return null;
  return { documentId: payload.documentId, userId: row.userId };
}

export async function listEnrollmentDocuments(orgId: string, enrollmentId: string) {
  return db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.enrollmentId, enrollmentId)))
    .orderBy(schema.documents.createdAt);
}

export async function listPersonDocuments(orgId: string, personId: string) {
  return db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.personId, personId)))
    .orderBy(schema.documents.createdAt);
}

/**
 * Lien de téléchargement temporaire pour un destinataire externe sans compte (transmission par e-mail, F09) :
 * jeton sans utilisateur, lié à l'adresse destinataire, résolu par la route publique /signer/document/[token].
 */
export async function issuePublicDownloadLink(documentId: string, email: string, ttlMinutes = 24 * 60) {
  const token = await issueToken("download", { email, payload: { documentId, public: true }, ttlMinutes });
  return `${appUrl()}/signer/document/${token}`;
}

export async function resolvePublicDownloadToken(token: string) {
  const row = await peekToken("download", token);
  const payload = row?.payload as { documentId?: string; public?: boolean } | undefined;
  if (!row || !payload?.documentId || payload.public !== true || row.userId) return null;
  return { documentId: payload.documentId, email: row.email };
}
