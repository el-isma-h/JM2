"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { assertEnrollmentInScope, requireOrg } from "@/server/authz";
import { fail, isoDate, str, uuid } from "@/server/crm/helpers";
import { CERT_STATUSES } from "@/server/certifications/rules";
import { loadRegistration, runCertificationReminders, syncCertificationRegistrations, updateCertificationRegistration } from "@/server/certifications/service";
import type { ActionState } from "./auth";

/** Actions des certifications externes (TOSA, ICDL, TOEIC, Certificat Voltaire, CléA). Aucun identifiant de plateforme n'est stocké. */

function revalidate(orgId: string, enrollmentId?: string) {
  revalidatePath(`/app/${orgId}/examens/certifications`);
  if (enrollmentId) revalidatePath(`/app/${orgId}/inscriptions/${enrollmentId}`);
}

export async function updateCertificationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "exams.manage");
    const id = uuid.parse(formData.get("registrationId"));
    const reg = await loadRegistration(ctx.org.id, id);
    await assertEnrollmentInScope(ctx, reg.enrollmentId);
    const status = z.enum(CERT_STATUSES, { message: "Statut invalide." }).parse(formData.get("status"));
    const r = await updateCertificationRegistration(
      { orgId: ctx.org.id, userId: ctx.user.id },
      id,
      {
        status,
        module: str(formData, "module", 200),
        positioningScore: str(formData, "positioningScore", 100),
        voucherRef: str(formData, "voucherRef", 100),
        examDate: isoDate(formData, "examDate"),
        score: str(formData, "score", 100),
        resultNote: str(formData, "resultNote", 1000),
      },
    );
    revalidate(ctx.org.id, r.enrollmentId);
    return { ok: true, message: "Certification mise à jour." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

/** Crée les inscriptions à la certification manquantes (formations dont le certificateur externe est renseigné). */
export async function syncCertificationsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "exams.manage");
    const r = await syncCertificationRegistrations(ctx.org.id, { userId: ctx.user.id });
    revalidate(ctx.org.id);
    return { ok: true, message: r.created ? `${r.created} inscription(s) à la certification créée(s).` : "Aucune inscription manquante : toutes les inscriptions concernées sont suivies." };
  } catch (e) {
    return fail(e, "Synchronisation impossible.");
  }
}

/** Lance immédiatement les alertes J-15 (même traitement que le job quotidien certifications:remind) pour cet organisme. */
export async function runCertificationRemindersAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "exams.manage");
    const r = await runCertificationReminders({ orgId: ctx.org.id });
    revalidate(ctx.org.id);
    const created = r.voltaireAlerts + r.toRegisterAlerts;
    return { ok: true, message: created ? `${created} tâche(s) d'alerte créée(s) (Voltaire : ${r.voltaireAlerts}, à inscrire : ${r.toRegisterAlerts}).` : "Aucune nouvelle alerte : les échéances à 15 jours sont déjà couvertes." };
  } catch (e) {
    return fail(e, "Vérification impossible.");
  }
}
