"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { runAgent } from "@/server/ai/agents";
import { pickProvider } from "@/server/ai/provider";
import { mailTemplateDefault } from "@/server/mail-templates/defaults";
import { ensureOrgMailTemplate, saveOrgMailTemplate } from "@/server/mail-templates/service";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const code = z.string().refine((c) => Boolean(mailTemplateDefault(c)), "Modèle d'e-mail inconnu.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

export async function updateMailTemplateAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "documents.generate");
    const d = z
      .object({
        code,
        subject: z.string().trim().min(3, "Objet requis.").max(200, "Objet trop long (200 caractères)."),
        body: z.string().trim().min(10, "Le corps du modèle est trop court.").max(20_000, "Corps trop long."),
      })
      .parse({ code: formData.get("code"), subject: formData.get("subject"), body: formData.get("body") });
    const { row, changed } = await saveOrgMailTemplate(ctx, d.code, { subject: d.subject, body: d.body.replace(/\r\n/g, "\n") }, "manuel");
    revalidatePath(`/app/${orgId}/modeles-emails`);
    return { ok: true, message: changed ? `Modèle enregistré en version ${row.version}.` : "Aucune modification." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Revient au texte par défaut : nouvelle version (la précédente reste tracée dans le journal d'audit). */
export async function resetMailTemplateAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "documents.generate");
    const c = code.parse(formData.get("code"));
    const def = mailTemplateDefault(c)!;
    const { row, changed } = await saveOrgMailTemplate(ctx, c, { subject: def.subject, body: def.body }, "reinitialisation");
    revalidatePath(`/app/${orgId}/modeles-emails`);
    return { ok: true, message: changed ? `Texte par défaut rétabli (version ${row.version}).` : "Le modèle est déjà le texte par défaut." };
  } catch (e) {
    return fail(e, "Réinitialisation impossible.");
  }
}

export async function setGoogleReviewUrlAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "documents.generate");
    const raw = z.string().trim().max(500).parse(formData.get("googleReviewUrl") ?? "");
    let url: string | null = null;
    if (raw) {
      let parsed: URL;
      try {
        parsed = new URL(raw);
      } catch {
        return { error: "Lien invalide : collez l'adresse complète (https://…)." };
      }
      if (parsed.protocol !== "https:") return { error: "Le lien doit commencer par https://." };
      if (!/(^|\.)(google\.[a-z.]+|g\.page|goo\.gl)$/i.test(parsed.hostname)) return { error: "Ce lien ne pointe pas vers Google (g.page, google.com/maps, search.google.com…)." };
      url = parsed.toString();
    }
    await db.update(schema.organismes).set({ googleReviewUrl: url }).where(eq(schema.organismes.id, ctx.org.id));
    await audit({ action: "org.google_review_url.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "organisme", entityId: ctx.org.id, before: { googleReviewUrl: ctx.org.googleReviewUrl }, after: { googleReviewUrl: url } });
    revalidatePath(`/app/${orgId}/modeles-emails`);
    return { ok: true, message: url ? "Lien d'avis Google enregistré." : "Lien d'avis Google retiré : la variable affichera « [À COMPLÉTER] »." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** « Rédiger avec l'IA » : crée une proposition (statut proposée) et ouvre l'écran des propositions. Aucun effet avant validation. */
export async function draftMailTemplateWithAiAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target: string | null = null;
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "documents.generate");
    const c = code.parse(formData.get("code"));
    const instructions = z.string().trim().max(1500, "Consigne trop longue (1500 caractères).").parse(formData.get("instructions") ?? "");
    if (!pickProvider()) return { error: "Assistant IA non configuré : un administrateur de la plateforme doit renseigner une clé (Admin, Clés API : ANTHROPIC_API_KEY, OPENAI_API_KEY ou XAI_API_KEY)." };
    const row = await ensureOrgMailTemplate(ctx.org.id, c, ctx.user.id);
    const proposal = await runAgent(ctx, "modeles", { entityType: "mail_template", entityId: row.id, params: { instructions } });
    const back = `/app/${orgId}/modeles-emails`;
    target = `/app/${orgId}/assistant/propositions?p=${proposal.id}&back=${encodeURIComponent(back)}`;
  } catch (e) {
    return fail(e, "La rédaction n'a pas pu être proposée.");
  }
  revalidatePath(target);
  redirect(target);
}
