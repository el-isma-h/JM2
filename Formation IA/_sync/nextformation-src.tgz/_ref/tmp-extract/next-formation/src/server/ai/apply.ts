import "server-only";
import { and, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { layoutMail, sendMail } from "@/server/mail";
import { createTaskOnce } from "@/server/tasks/service";
import { generateDocument } from "@/server/documents/generate";
import { slugify } from "@/lib/utils";
import { todayParis } from "@/lib/time";
import { isApplicable, isDecidable, transitionProposal, type ProposalStatus } from "./proposals";
import { getProposal, type ProposalRow } from "./store";
import type { DossierPayload } from "./agents/dossier";
import type { RelancePayload } from "./agents/relances";
import type { PiecesPayload } from "./agents/pieces";
import type { QualitePayload } from "./agents/qualite";
import type { ProgrammePayload } from "./agents/programme";
import type { PlanningPayload } from "./agents/planning";
import type { DocumentsPayload } from "./agents/documents";
import { applyMailTemplateProposal, type MailTemplatePayload } from "@/server/mail-templates/service";

export type ApplyResult = { ok: true; message: string; href?: string } | { ok: false; reason: string };

/** Permission nécessaire pour décider (valider / refuser) selon l'agent. */
const DECIDE_PERMS: Record<string, Parameters<OrgContext["permissions"]["has"]>[0]> = {
  documents: "documents.generate",
  pieces: "dossier.admin_docs.manage",
  relances: "tasks.manage",
  qualite: "quality.manage",
  programme: "catalog.manage",
  planning: "planning.manage",
  dossier: "tasks.manage",
  modeles: "documents.generate",
};

function canDecide(ctx: OrgContext, p: ProposalRow) {
  const perm = DECIDE_PERMS[p.agent];
  return !perm || ctx.permissions.has(perm) || ctx.isOwner;
}

/** Refus d'une proposition avec motif (obligatoire) : aucun effet, trace conservée. */
export async function refuseProposal(ctx: OrgContext, proposalId: string, reason: string): Promise<ApplyResult> {
  const p = await getProposal(ctx.org.id, proposalId);
  if (!p) return { ok: false, reason: "Proposition introuvable." };
  if (!canDecide(ctx, p)) throw new AuthError("forbidden");
  const t = transitionProposal(p.status, "refuser");
  if (!t.ok) return { ok: false, reason: t.reason };
  if (!reason.trim()) return { ok: false, reason: "Indiquez le motif du refus." };
  await db.update(schema.aiProposals).set({ status: t.status, decidedBy: ctx.user.id, decidedAt: new Date(), decisionNote: reason.trim() }).where(eq(schema.aiProposals.id, p.id));
  await audit({ action: "ai.proposal.refuse", userId: ctx.user.id, orgId: ctx.org.id, entityType: "ai_proposal", entityId: p.id, before: { status: p.status }, after: { status: t.status, reason } });
  return { ok: true, message: "Proposition refusée. Aucun effet n'a été produit." };
}

/**
 * Validation puis application : la proposition passe `validee` puis `appliquee` dans la même décision humaine.
 * Si l'effet échoue, la proposition reste `validee` (jamais appliquée deux fois, jamais perdue) et le motif est retourné.
 */
export async function applyProposal(ctx: OrgContext, proposalId: string, note?: string): Promise<ApplyResult> {
  const p = await getProposal(ctx.org.id, proposalId);
  if (!p) return { ok: false, reason: "Proposition introuvable." };
  if (!canDecide(ctx, p)) throw new AuthError("forbidden");
  let status: ProposalStatus = p.status;
  if (isDecidable(status)) {
    const t = transitionProposal(status, "valider");
    if (!t.ok) return { ok: false, reason: t.reason };
    status = t.status;
    await db.update(schema.aiProposals).set({ status, decidedBy: ctx.user.id, decidedAt: new Date(), decisionNote: note?.trim() || null }).where(eq(schema.aiProposals.id, p.id));
    await audit({ action: "ai.proposal.validate", userId: ctx.user.id, orgId: ctx.org.id, entityType: "ai_proposal", entityId: p.id, before: { status: p.status }, after: { status } });
  }
  if (!isApplicable(status)) {
    const t = transitionProposal(status, "appliquer");
    return { ok: false, reason: t.ok ? "État inattendu." : t.reason };
  }
  // Verrou optimiste : un seul passage validee → appliquee, même en cas de double envoi.
  const [locked] = await db
    .update(schema.aiProposals)
    .set({ status: "appliquee", appliedAt: new Date() })
    .where(and(eq(schema.aiProposals.id, p.id), eq(schema.aiProposals.status, "validee")))
    .returning({ id: schema.aiProposals.id });
  if (!locked) return { ok: false, reason: "Cette proposition est déjà en cours d'application." };
  try {
    const result = await executeEffect(ctx, { ...p, status: "validee" });
    if (!result.ok) throw new Error(result.reason);
    await audit({ action: "ai.proposal.apply", userId: ctx.user.id, orgId: ctx.org.id, entityType: "ai_proposal", entityId: p.id, after: { kind: p.kind, result: result.message } });
    return result;
  } catch (e) {
    // Retour à `validee` : l'effet n'a pas eu lieu, l'humain peut réessayer ou refuser.
    await db.update(schema.aiProposals).set({ status: "validee", appliedAt: null }).where(eq(schema.aiProposals.id, p.id));
    const reason = e instanceof Error ? e.message : "Échec de l'application.";
    await audit({ action: "ai.proposal.apply_failed", userId: ctx.user.id, orgId: ctx.org.id, entityType: "ai_proposal", entityId: p.id, after: { reason } });
    return { ok: false, reason };
  }
}

async function executeEffect(ctx: OrgContext, p: ProposalRow): Promise<ApplyResult> {
  const base = `/app/${ctx.org.id}`;
  switch (p.kind) {
    case "email": {
      const d = p.payload as unknown as RelancePayload;
      if (!d.to || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.to)) return { ok: false, reason: "Aucune adresse e-mail valide pour le destinataire : renseignez-la dans la fiche puis relancez l'agent." };
      const res = await sendMail({ to: d.to, subject: d.subject, html: layoutMail(d.subject, d.html ?? `<p>${d.text}</p>`), text: d.text, isDemo: ctx.org.isDemo });
      const status = res.status === "sent" ? "envoyé" : res.status === "skipped_not_configured" ? (ctx.org.isDemo ? "journalisé (démonstration : aucun envoi)" : "journalisé dans la boîte d'envoi (e-mail non configuré)") : "échec d'envoi";
      if (res.status === "failed") return { ok: false, reason: "L'envoi a échoué (voir la boîte d'envoi)." };
      return { ok: true, message: `E-mail à ${d.to} : ${status}.` };
    }
    case "resume": {
      const d = p.payload as unknown as DossierPayload;
      if (!d.createTask || !p.entityId) return { ok: true, message: "Résumé pris en compte. Aucune tâche créée (une tâche ouverte existe déjà ou rien ne manque)." };
      const { task, created } = await createTaskOnce({
        orgId: ctx.org.id,
        title: d.nextAction.slice(0, 200),
        description: d.text,
        family: d.responsible === "finance" ? "finance" : d.responsible === "pedagogy_manager" ? "pedagogie" : "administratif",
        entityType: "enrollment",
        entityId: p.entityId,
        href: `${base}/inscriptions/${p.entityId}`,
        assigneeRole: d.responsible,
        dueDate: todayParis(),
        idempotencyKey: `ai:dossier:${p.id}`,
        createdBy: ctx.user.id,
        source: "assistant",
        isDemo: ctx.org.isDemo,
      });
      return { ok: true, message: created ? `Tâche créée pour ${d.responsible} : ${task.title}` : "Tâche déjà existante.", href: `${base}/taches` };
    }
    case "piece_classement": {
      const d = p.payload as unknown as PiecesPayload;
      if (!d.suggestedSubmissionId) return { ok: false, reason: "Aucune pièce attendue proposée : rien à rattacher." };
      const [sub] = await db.select().from(schema.pieceSubmissions).where(and(eq(schema.pieceSubmissions.id, d.suggestedSubmissionId), eq(schema.pieceSubmissions.orgId, ctx.org.id), eq(schema.pieceSubmissions.enrollmentId, d.enrollmentId))).limit(1);
      if (!sub) return { ok: false, reason: "Pièce attendue introuvable." };
      if (sub.status === "acceptee") return { ok: false, reason: "Cette pièce est déjà acceptée : aucun remplacement automatique." };
      await db.update(schema.pieceSubmissions).set({ status: "deposee", documentId: d.documentId, submittedAt: new Date(), submittedBy: ctx.user.id }).where(eq(schema.pieceSubmissions.id, sub.id));
      await audit({ action: "piece.classify", userId: ctx.user.id, orgId: ctx.org.id, entityType: "piece_submission", entityId: sub.id, before: { status: sub.status, documentId: sub.documentId }, after: { status: "deposee", documentId: d.documentId, proposalId: p.id } });
      return { ok: true, message: `Document rattaché à « ${d.suggestedLabel} » (déposée). Le contrôle d'acceptation reste à faire.`, href: `${base}/inscriptions/${d.enrollmentId}` };
    }
    case "synthese_qualite": {
      const d = p.payload as unknown as QualitePayload;
      let n = 0;
      for (const t of d.proposedTasks.slice(0, 20)) {
        const { created } = await createTaskOnce({
          orgId: ctx.org.id,
          title: t.title.slice(0, 200),
          description: "Proposée par la synthèse qualité : produire une preuve réelle (document, action), jamais une déclaration.",
          family: "qualite",
          entityType: p.entityType === "organisme" ? null : p.entityType,
          entityId: p.entityId,
          assigneeRole: "quality",
          indicatorCode: t.indicatorCode ?? null,
          idempotencyKey: `ai:qualite:${p.id}:${slugify(t.title).slice(0, 40)}`,
          createdBy: ctx.user.id,
          source: "assistant",
          isDemo: ctx.org.isDemo,
        });
        if (created) n++;
      }
      return { ok: true, message: n ? `${n} tâche(s) qualité créée(s) pour les preuves manquantes.` : "Synthèse prise en compte, aucune tâche à créer.", href: `${base}/qualite/actions` };
    }
    case "programme_version": {
      const d = p.payload as unknown as ProgrammePayload;
      let programId = d.programId;
      if (programId) {
        const [prog] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.id, programId), eq(schema.programs.orgId, ctx.org.id))).limit(1);
        if (!prog) return { ok: false, reason: "Formation introuvable." };
      } else {
        const code = `PRG-${Date.now().toString(36).toUpperCase()}`;
        const [prog] = await db.insert(schema.programs).values({ orgId: ctx.org.id, code, title: d.title, slug: `${slugify(d.title)}-${code.slice(-4).toLowerCase()}`, status: "brouillon", isDemo: ctx.org.isDemo }).returning({ id: schema.programs.id });
        programId = prog.id;
      }
      const [{ max }] = await db.select({ max: sql<number>`coalesce(max(${schema.programVersions.version}), 0)::int` }).from(schema.programVersions).where(eq(schema.programVersions.programId, programId));
      const [v] = await db
        .insert(schema.programVersions)
        .values({
          orgId: ctx.org.id,
          programId,
          version: max + 1,
          status: "brouillon",
          objectives: d.objectives,
          prerequisites: d.prerequisites,
          audience: d.audience,
          modality: d.modality,
          durationHours: d.durationHours,
          content: d.content,
          methods: d.methods,
          evaluationMethods: d.evaluationMethods,
          accessibility: d.accessibility,
          accessDelay: d.accessDelay,
          trainerProfile: d.trainerProfile,
          createdBy: ctx.user.id,
        })
        .returning({ id: schema.programVersions.id });
      let pos = 0;
      for (const m of d.modules) await db.insert(schema.modules).values({ orgId: ctx.org.id, programVersionId: v.id, title: m.title, description: m.description, hours: m.hours, position: pos++, skills: m.skills.map((s) => ({ label: s })) });
      await audit({ action: "program_version.create_from_ai", userId: ctx.user.id, orgId: ctx.org.id, entityType: "program_version", entityId: v.id, after: { programId, version: max + 1, proposalId: p.id } });
      return { ok: true, message: `Version ${max + 1} créée en brouillon (${d.modules.length} module(s)). Elle reste inactive jusqu'à validation du catalogue.`, href: `${base}/catalogue/${programId}` };
    }
    case "calendrier": {
      const d = p.payload as unknown as PlanningPayload;
      const lines = d.slots.map((s) => `${s.date} : ${s.parts.join(" + ")}`).join("\n");
      const { task, created } = await createTaskOnce({
        orgId: ctx.org.id,
        title: `Saisir le calendrier proposé (${d.slots.length} séances)`,
        description: `Calendrier proposé par l'assistant (aucune séance écrite automatiquement) :\n${lines}${d.skipped.length ? `\n\nJours exclus :\n${d.skipped.map((s) => `${s.date} : ${s.reason}`).join("\n")}` : ""}`,
        family: "pedagogie",
        entityType: "session",
        entityId: d.sessionId,
        href: `${base}/planning?session=${d.sessionId}`,
        assigneeRole: "pedagogy_manager",
        idempotencyKey: `ai:planning:${p.id}`,
        createdBy: ctx.user.id,
        source: "assistant",
        isDemo: ctx.org.isDemo,
      });
      return { ok: true, message: created ? `Tâche de saisie créée : ${task.title}` : "Tâche déjà existante.", href: `${base}/planning?session=${d.sessionId}` };
    }
    case "document_reponses": {
      const d = p.payload as unknown as DocumentsPayload;
      // Génération via le module documents (équipe documents) : brouillon généré, jamais signé ; marqueurs « [À COMPLÉTER] » pour les réponses absentes.
      try {
        const r = await generateDocument({ ctx, templateCode: d.templateCode, scope: { enrollmentId: d.enrollmentId }, answers: d.answers });
        return { ok: true, message: `Document « ${d.templateTitle} » généré (version ${r.version}, statut généré)${r.missing.length ? `, ${r.missing.length} champ(s) à compléter` : ""}.`, href: `${base}/documents/${r.document.id}` };
      } catch (e) {
        if (e instanceof AuthError) throw e;
        // Génération impossible (modèle inactif, données manquantes) : repli sur une tâche pour l'administratif.
      }
      const { task, created } = await createTaskOnce({
        orgId: ctx.org.id,
        title: `Générer « ${d.templateTitle} » avec les réponses proposées`,
        description: `Réponses validées :\n${Object.entries(d.answers)
          .map(([k, v]) => `${k} : ${v}`)
          .join("\n")}${d.missing.length ? `\n\nÀ compléter : ${d.missing.join(", ")}` : ""}`,
        family: "administratif",
        entityType: "enrollment",
        entityId: d.enrollmentId,
        href: `${base}/inscriptions/${d.enrollmentId}`,
        assigneeRole: "admin_staff",
        idempotencyKey: `ai:documents:${p.id}`,
        createdBy: ctx.user.id,
        source: "assistant",
        isDemo: ctx.org.isDemo,
      });
      return { ok: true, message: created ? `Réponses validées : tâche de génération créée (${task.title}).` : "Tâche déjà existante.", href: `${base}/inscriptions/${d.enrollmentId}` };
    }
    case "modele_email":
      // Nouvelle version du modèle d'e-mail de l'organisme ; aucun e-mail n'est envoyé.
      return applyMailTemplateProposal(ctx, p.id, p.payload as unknown as MailTemplatePayload);
    default:
      return { ok: false, reason: `Effet « ${p.kind} » inconnu.` };
  }
}
