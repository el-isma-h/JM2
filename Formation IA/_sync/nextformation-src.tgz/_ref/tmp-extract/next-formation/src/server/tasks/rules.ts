/**
 * Règles des tâches et relais (F14). Module pur : transitions avec prérequis explicites, retards, familles.
 */

export type TaskStatus = "a_faire" | "en_cours" | "bloquee" | "terminee" | "annulee";
export type TaskPriority = "basse" | "normale" | "haute" | "urgente";

export const TASK_STATUSES: TaskStatus[] = ["a_faire", "en_cours", "bloquee", "terminee", "annulee"];
export const TASK_PRIORITIES: TaskPriority[] = ["basse", "normale", "haute", "urgente"];

export const TASK_FAMILIES = ["commercial", "administratif", "pedagogie", "finance", "qualite", "examen", "direction"] as const;
export type TaskFamily = (typeof TASK_FAMILIES)[number];

export const taskFamilyLabels: Record<TaskFamily, string> = {
  commercial: "Commercial",
  administratif: "Administratif",
  pedagogie: "Pédagogie",
  finance: "Finance",
  qualite: "Qualité",
  examen: "Examen",
  direction: "Direction",
};

export const taskStatusLabels: Record<TaskStatus, string> = {
  a_faire: "À faire",
  en_cours: "En cours",
  bloquee: "Bloquée",
  terminee: "Terminée",
  annulee: "Annulée",
};

export const taskPriorityLabels: Record<TaskPriority, string> = {
  basse: "Basse",
  normale: "Normale",
  haute: "Haute",
  urgente: "Urgente",
};

/** Rôles destinataires d'un relais (sans responsable nommé). */
export const TASK_ROLES = ["direction", "agency_manager", "pedagogy_manager", "trainer", "admin_staff", "finance", "quality", "sales"] as const;

export const entityTypeLabels: Record<string, string> = {
  enrollment: "Inscription",
  session: "Session",
  company: "Entreprise",
  person: "Personne",
  invoice: "Facture",
  cohort: "Cohorte d'examen",
  document: "Document",
  funding: "Financement",
  period: "Période",
  survey: "Enquête",
  complaint: "Réclamation",
  quality_action: "Action qualité",
  organisme: "Organisme",
};

/** Prérequis explicite d'une transition : donnée présente, pièce validée ou décision humaine requise. */
export type Prerequisite = { label: string; done?: boolean; kind?: "donnee" | "piece" | "decision" };

export function parsePrerequisites(raw: unknown): Prerequisite[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((p) => {
      if (typeof p === "string") return { label: p, done: false } as Prerequisite;
      if (p && typeof p === "object" && typeof (p as { label?: unknown }).label === "string") {
        const o = p as { label: string; done?: unknown; kind?: unknown };
        return { label: o.label, done: o.done === true, kind: typeof o.kind === "string" ? (o.kind as Prerequisite["kind"]) : undefined };
      }
      return null;
    })
    .filter((p): p is Prerequisite => p !== null);
}

/** Transitions permises depuis chaque statut. */
export const TASK_TRANSITIONS: Record<TaskStatus, TaskStatus[]> = {
  a_faire: ["en_cours", "bloquee", "terminee", "annulee"],
  en_cours: ["a_faire", "bloquee", "terminee", "annulee"],
  bloquee: ["a_faire", "en_cours", "annulee"],
  terminee: ["a_faire"],
  annulee: ["a_faire"],
};

export type TransitionInput = {
  status: TaskStatus;
  prerequisites?: unknown;
  blockedReason?: string | null;
};

export type TransitionResult = { ok: true; blockedReason: string | null } | { ok: false; reason: string; pending?: Prerequisite[] };

/**
 * Vérifie une transition de statut.
 * - `bloquee` exige un motif (ce qui bloque le passage à l'étape suivante).
 * - `terminee` exige que tous les prérequis explicites soient satisfaits, sauf dérogation motivée (`override`),
 *   dont le motif est conservé dans l'historique par l'appelant.
 * - Une tâche bloquée se débloque en revenant à « à faire » ou « en cours » ; le motif est alors effacé.
 */
export function checkTransition(task: TransitionInput, to: TaskStatus, opts: { note?: string | null; override?: boolean } = {}): TransitionResult {
  if (task.status === to) return { ok: false, reason: `La tâche est déjà « ${taskStatusLabels[to]} ».` };
  if (!TASK_TRANSITIONS[task.status]?.includes(to)) {
    return { ok: false, reason: `Passage de « ${taskStatusLabels[task.status]} » à « ${taskStatusLabels[to]} » non permis.` };
  }
  const note = opts.note?.trim() ?? "";
  if (to === "bloquee") {
    if (!note) return { ok: false, reason: "Indiquez ce qui bloque (motif obligatoire)." };
    return { ok: true, blockedReason: note };
  }
  if (to === "terminee") {
    const pending = parsePrerequisites(task.prerequisites).filter((p) => !p.done);
    if (pending.length && !opts.override) {
      return { ok: false, reason: `Prérequis non satisfaits : ${pending.map((p) => p.label).join(", ")}.`, pending };
    }
    if (pending.length && opts.override && !note) {
      return { ok: false, reason: "Une clôture malgré des prérequis non satisfaits exige un motif." };
    }
    return { ok: true, blockedReason: null };
  }
  if (to === "annulee" && !note) return { ok: false, reason: "Indiquez le motif d'annulation." };
  return { ok: true, blockedReason: null };
}

export const OPEN_STATUSES: TaskStatus[] = ["a_faire", "en_cours", "bloquee"];

export function isOpen(status: string): boolean {
  return (OPEN_STATUSES as readonly string[]).includes(status);
}

/** Retard : échéance strictement passée et tâche encore ouverte. */
export function isOverdue(task: { status: string; dueDate: string | null }, todayIso: string): boolean {
  return isOpen(task.status) && Boolean(task.dueDate) && (task.dueDate as string) < todayIso;
}

/** Report d'échéance : nouvelle date ISO valide, postérieure à l'ancienne ou à aujourd'hui, motif obligatoire. */
export function checkPostpone(input: { current: string | null; next: string; today: string; reason: string }): { ok: true } | { ok: false; reason: string } {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.next)) return { ok: false, reason: "Date d'échéance invalide." };
  if (!input.reason.trim()) return { ok: false, reason: "Indiquez le motif du report." };
  if (input.current && input.next === input.current) return { ok: false, reason: "L'échéance est inchangée." };
  if (input.next < input.today) return { ok: false, reason: "Une échéance reportée ne peut pas être dans le passé." };
  return { ok: true };
}

/** Clé d'idempotence d'une tâche manuelle : unique par création (aucun regroupement d'événements). */
export function manualIdempotencyKey(id: string): string {
  return `manuel:${id}`;
}
