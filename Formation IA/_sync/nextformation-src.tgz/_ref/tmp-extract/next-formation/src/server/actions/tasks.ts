"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { and, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { notify } from "@/server/notify";
import { todayParis } from "@/lib/time";
import { createTaskOnce } from "@/server/tasks/service";
import { canActOnTask, orgStaff, taskById, type TaskRow } from "@/server/tasks/queries";
import { checkPostpone, checkTransition, manualIdempotencyKey, parsePrerequisites, TASK_FAMILIES, TASK_PRIORITIES, TASK_ROLES, TASK_STATUSES, type TaskStatus } from "@/server/tasks/rules";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

function paths(orgId: string, taskId?: string) {
  revalidatePath(`/app/${orgId}/taches`);
  revalidatePath(`/app/${orgId}/taches/supervision`);
  revalidatePath(`/app/${orgId}`);
  if (taskId) revalidatePath(`/app/${orgId}/taches/${taskId}`);
}

/** Charge la tâche dans l'organisme du contexte et vérifie le droit d'agir. */
async function loadActionable(ctx: OrgContext, taskId: string): Promise<TaskRow> {
  const task = await taskById(ctx.org.id, taskId);
  if (!task) throw new Error("Tâche introuvable.");
  if (!canActOnTask(ctx, task)) throw new Error("Vous n'êtes pas responsable de cette tâche.");
  return task;
}

async function event(taskId: string, kind: (typeof schema.taskEventKindEnum.enumValues)[number], userId: string, data: { from?: string | null; to?: string | null; note?: string | null }) {
  await db.insert(schema.taskEvents).values({ taskId, kind, fromValue: data.from ?? null, toValue: data.to ?? null, note: data.note ?? null, userId });
}

/** Prendre en charge : devient responsable nommé ; une tâche « à faire » passe « en cours ». */
export async function takeTaskAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "tasks.manage");
    const taskId = uuid.parse(formData.get("taskId"));
    const task = await taskById(orgId, taskId);
    if (!task) return { error: "Tâche introuvable." };
    const allowed = canActOnTask(ctx, task) || (!task.assigneeUserId && !task.assigneeRole);
    if (!allowed) return { error: "Cette tâche est affectée à une autre personne ou à un autre rôle." };
    if (task.assigneeUserId === ctx.user.id) return { ok: true, message: "Vous êtes déjà responsable de cette tâche." };
    const nextStatus: TaskStatus = task.status === "a_faire" ? "en_cours" : task.status;
    await db.update(schema.tasks).set({ assigneeUserId: ctx.user.id, status: nextStatus }).where(and(eq(schema.tasks.id, task.id), eq(schema.tasks.orgId, orgId)));
    await event(task.id, "reaffectation", ctx.user.id, { from: task.assigneeUserId ?? (task.assigneeRole ? `role:${task.assigneeRole}` : null), to: ctx.user.id, note: "Prise en charge" });
    if (nextStatus !== task.status) await event(task.id, "statut", ctx.user.id, { from: task.status, to: nextStatus });
    await audit({ action: "task.take", userId: ctx.user.id, orgId, entityType: "task", entityId: task.id, before: { assigneeUserId: task.assigneeUserId, assigneeRole: task.assigneeRole }, after: { assigneeUserId: ctx.user.id } });
    paths(orgId, task.id);
    return { ok: true, message: "Tâche prise en charge." };
  } catch (e) {
    return fail(e, "Prise en charge impossible.");
  }
}

export async function commentTaskAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "tasks.manage");
    const taskId = uuid.parse(formData.get("taskId"));
    const note = z.string().trim().min(1, "Le commentaire est vide.").max(2000).parse(formData.get("note"));
    const task = await loadActionable(ctx, taskId);
    await event(task.id, "commentaire", ctx.user.id, { note });
    paths(orgId, task.id);
    return { ok: true, message: "Commentaire ajouté." };
  } catch (e) {
    return fail(e, "Commentaire impossible.");
  }
}

/** Changement de statut avec prérequis : bloquée exige un motif ; terminée exige les prérequis ou une dérogation motivée. */
export async function setTaskStatusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "tasks.manage");
    const taskId = uuid.parse(formData.get("taskId"));
    const to = z.enum(TASK_STATUSES).parse(formData.get("to"));
    const note = String(formData.get("note") ?? "").trim() || null;
    const override = formData.get("override") === "on" || formData.get("override") === "1";
    const task = await loadActionable(ctx, taskId);
    const check = checkTransition({ status: task.status, prerequisites: task.prerequisites, blockedReason: task.blockedReason }, to, { note, override });
    if (!check.ok) return { error: check.reason };
    const done = to === "terminee";
    await db
      .update(schema.tasks)
      .set({
        status: to,
        blockedReason: check.blockedReason,
        completedAt: done ? new Date() : null,
        completedBy: done ? ctx.user.id : null,
        resolutionNote: done ? note : task.resolutionNote,
      })
      .where(and(eq(schema.tasks.id, task.id), eq(schema.tasks.orgId, orgId)));
    if (to === "bloquee") await event(task.id, "blocage", ctx.user.id, { from: task.status, to, note });
    else if (task.status === "bloquee") await event(task.id, "deblocage", ctx.user.id, { from: task.status, to, note });
    else await event(task.id, "statut", ctx.user.id, { from: task.status, to, note: override && note ? `Dérogation : ${note}` : note });
    await audit({ action: "task.status", userId: ctx.user.id, orgId, entityType: "task", entityId: task.id, before: { status: task.status }, after: { status: to, note, override } });
    if (done && task.createdBy && task.createdBy !== ctx.user.id) {
      await notify({ orgId, userId: task.createdBy, title: `Tâche terminée : ${task.title}`, href: `/app/${orgId}/taches/${task.id}`, kind: "task", dedupeKey: `task:${task.id}:done` });
    }
    paths(orgId, task.id);
    return { ok: true, message: done ? "Tâche terminée." : `Statut : ${to === "bloquee" ? "bloquée" : to === "en_cours" ? "en cours" : to === "a_faire" ? "à faire" : "annulée"}.` };
  } catch (e) {
    return fail(e, "Changement de statut impossible.");
  }
}

/** Coche ou décoche un prérequis explicite (donnée obtenue, pièce validée, décision prise) : tracé dans l'historique. */
export async function togglePrerequisiteAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "tasks.manage");
    const taskId = uuid.parse(formData.get("taskId"));
    const index = z.coerce.number().int().min(0).parse(formData.get("index"));
    const done = formData.get("done") === "1";
    const task = await loadActionable(ctx, taskId);
    const list = parsePrerequisites(task.prerequisites);
    const item = list[index];
    if (!item) return { error: "Prérequis introuvable." };
    list[index] = { ...item, done };
    await db.update(schema.tasks).set({ prerequisites: list }).where(and(eq(schema.tasks.id, task.id), eq(schema.tasks.orgId, orgId)));
    await event(task.id, "commentaire", ctx.user.id, { note: `Prérequis ${done ? "satisfait" : "rouvert"} : ${item.label}` });
    paths(orgId, task.id);
    return { ok: true, message: done ? "Prérequis satisfait." : "Prérequis rouvert." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

/** Réaffectation : vers un membre nommé ou un rôle ; la trace est conservée dans task_events. */
export async function reassignTaskAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "tasks.manage");
    const taskId = uuid.parse(formData.get("taskId"));
    const target = String(formData.get("target") ?? "").trim();
    const note = String(formData.get("note") ?? "").trim() || null;
    const task = await loadActionable(ctx, taskId);
    const r = await applyReassign(ctx, task, target, note);
    if (r.error) return { error: r.error };
    paths(orgId, task.id);
    return { ok: true, message: "Tâche réaffectée." };
  } catch (e) {
    return fail(e, "Réaffectation impossible.");
  }
}

async function applyReassign(ctx: OrgContext, task: TaskRow, target: string, note: string | null): Promise<{ error?: string }> {
  let set: { assigneeUserId: string | null; assigneeRole: string | null };
  let label: string;
  if (target.startsWith("role:")) {
    const role = target.slice(5);
    if (!(TASK_ROLES as readonly string[]).includes(role)) return { error: "Rôle destinataire inconnu." };
    set = { assigneeUserId: null, assigneeRole: role };
    label = target;
  } else if (target === "") {
    set = { assigneeUserId: null, assigneeRole: null };
    label = "sans responsable";
  } else {
    if (!/^[0-9a-f-]{36}$/i.test(target)) return { error: "Membre invalide." };
    const staff = await orgStaff(ctx.org.id);
    const member = staff.find((s) => s.id === target);
    if (!member) return { error: "Le membre choisi n'est pas actif dans cet organisme." };
    set = { assigneeUserId: member.id, assigneeRole: task.assigneeRole };
    label = member.id;
  }
  const from = task.assigneeUserId ?? (task.assigneeRole ? `role:${task.assigneeRole}` : "sans responsable");
  if (from === label) return { error: "Le responsable est inchangé." };
  await db.update(schema.tasks).set(set).where(and(eq(schema.tasks.id, task.id), eq(schema.tasks.orgId, ctx.org.id)));
  await event(task.id, "reaffectation", ctx.user.id, { from, to: label, note });
  await audit({ action: "task.reassign", userId: ctx.user.id, orgId: ctx.org.id, entityType: "task", entityId: task.id, before: { from }, after: { to: label, note } });
  if (set.assigneeUserId && set.assigneeUserId !== ctx.user.id) {
    await notify({ orgId: ctx.org.id, userId: set.assigneeUserId, title: `Tâche affectée : ${task.title}`, body: note ?? undefined, href: `/app/${ctx.org.id}/taches/${task.id}`, kind: "task", dedupeKey: `task:${task.id}:assign:${set.assigneeUserId}:${Date.now()}` });
  }
  return {};
}

/** Réaffectation en masse (supervision). */
export async function bulkReassignAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "tasks.view_all", "tasks.manage");
    const ids = formData.getAll("taskIds").map(String).filter((s) => /^[0-9a-f-]{36}$/i.test(s));
    if (!ids.length) return { error: "Sélectionnez au moins une tâche." };
    const target = String(formData.get("target") ?? "").trim();
    const note = String(formData.get("note") ?? "").trim() || "Réaffectation en masse";
    const rows = await db.select().from(schema.tasks).where(and(eq(schema.tasks.orgId, orgId), inArray(schema.tasks.id, ids)));
    let n = 0;
    for (const t of rows) {
      const r = await applyReassign(ctx, t, target, note);
      if (!r.error) n++;
    }
    paths(orgId);
    return { ok: true, message: `${n} tâche(s) réaffectée(s) sur ${rows.length}.` };
  } catch (e) {
    return fail(e, "Réaffectation impossible.");
  }
}

/** Report d'échéance avec motif (trace conservée). */
export async function postponeTaskAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "tasks.manage");
    const taskId = uuid.parse(formData.get("taskId"));
    const next = String(formData.get("dueDate") ?? "").trim();
    const reason = String(formData.get("reason") ?? "").trim();
    const task = await loadActionable(ctx, taskId);
    const check = checkPostpone({ current: task.dueDate, next, today: todayParis(), reason });
    if (!check.ok) return { error: check.reason };
    await db.update(schema.tasks).set({ dueDate: next }).where(and(eq(schema.tasks.id, task.id), eq(schema.tasks.orgId, orgId)));
    await event(task.id, "echeance", ctx.user.id, { from: task.dueDate, to: next, note: reason });
    await audit({ action: "task.postpone", userId: ctx.user.id, orgId, entityType: "task", entityId: task.id, before: { dueDate: task.dueDate }, after: { dueDate: next, reason } });
    paths(orgId, task.id);
    return { ok: true, message: "Échéance reportée." };
  } catch (e) {
    return fail(e, "Report impossible.");
  }
}

const createSchema = z.object({
  title: z.string().trim().min(3, "Objet de la tâche requis (3 caractères minimum).").max(200),
  description: z.string().trim().max(4000).optional(),
  family: z.enum(TASK_FAMILIES),
  priority: z.enum(TASK_PRIORITIES).default("normale"),
  dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Échéance invalide.").optional().or(z.literal("")),
  target: z.string().trim().optional(),
  entityType: z.string().trim().max(30).optional(),
  entityId: z.string().uuid().optional().or(z.literal("")),
  prerequisites: z.string().trim().max(2000).optional(),
});

/** Tâche manuelle liée à un dossier (inscription, session, entreprise, personne, facture). */
export async function createTaskAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "tasks.manage");
    const d = createSchema.parse(Object.fromEntries(formData));
    let assigneeUserId: string | null = null;
    let assigneeRole: string | null = null;
    const target = d.target ?? "";
    if (target.startsWith("role:")) {
      const role = target.slice(5);
      if (!(TASK_ROLES as readonly string[]).includes(role)) return { error: "Rôle destinataire inconnu." };
      assigneeRole = role;
    } else if (target === "me") {
      assigneeUserId = ctx.user.id;
    } else if (target) {
      const staff = await orgStaff(orgId);
      if (!staff.some((s) => s.id === target)) return { error: "Le membre choisi n'est pas actif dans cet organisme." };
      assigneeUserId = target;
    }
    let entity: { type: string; id: string; label: string; href: string } | null = null;
    if (d.entityType && d.entityId) {
      entity = await resolveEntity(orgId, d.entityType, d.entityId);
      if (!entity) return { error: "Dossier lié introuvable dans cet organisme." };
    }
    const prerequisites = (d.prerequisites ?? "")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean)
      .map((label) => ({ label, done: false }));
    const id = randomUUID();
    const { task } = await createTaskOnce({
      orgId,
      title: d.title,
      description: d.description || null,
      family: d.family,
      priority: d.priority,
      dueDate: d.dueDate || null,
      assigneeUserId,
      assigneeRole,
      entityType: entity?.type ?? null,
      entityId: entity?.id ?? null,
      entityLabel: entity?.label ?? null,
      href: entity?.href ?? null,
      prerequisites,
      createdBy: ctx.user.id,
      source: "manuel",
      isDemo: ctx.org.isDemo,
      idempotencyKey: manualIdempotencyKey(id),
    });
    await audit({ action: "task.create", userId: ctx.user.id, orgId, entityType: "task", entityId: task.id, after: { title: d.title, family: d.family, assigneeUserId, assigneeRole, entity } });
    if (assigneeUserId && assigneeUserId !== ctx.user.id) {
      await notify({ orgId, userId: assigneeUserId, title: `Nouvelle tâche : ${d.title}`, href: `/app/${orgId}/taches/${task.id}`, kind: "task", dedupeKey: `task:${task.id}:created` });
    }
    paths(orgId);
    return { ok: true, message: "Tâche créée.", data: { taskId: task.id } };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

async function resolveEntity(orgId: string, type: string, id: string): Promise<{ type: string; id: string; label: string; href: string } | null> {
  const base = `/app/${orgId}`;
  switch (type) {
    case "enrollment": {
      const [r] = await db
        .select({ id: schema.enrollments.id, ref: schema.enrollments.reference, first: schema.persons.firstName, last: schema.persons.lastName })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .where(and(eq(schema.enrollments.id, id), eq(schema.enrollments.orgId, orgId)))
        .limit(1);
      return r ? { type, id, label: `${r.ref} : ${r.first} ${r.last}`, href: `${base}/inscriptions/${id}` } : null;
    }
    case "session": {
      const [r] = await db.select({ code: schema.trainingSessions.code, title: schema.trainingSessions.title }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, id), eq(schema.trainingSessions.orgId, orgId))).limit(1);
      return r ? { type, id, label: `${r.code} : ${r.title}`, href: `${base}/sessions/${id}` } : null;
    }
    case "company": {
      const [r] = await db.select({ name: schema.companies.name }).from(schema.companies).where(and(eq(schema.companies.id, id), eq(schema.companies.orgId, orgId))).limit(1);
      return r ? { type, id, label: r.name, href: `${base}/entreprises/${id}` } : null;
    }
    case "person": {
      const [r] = await db.select({ first: schema.persons.firstName, last: schema.persons.lastName, status: schema.persons.status }).from(schema.persons).where(and(eq(schema.persons.id, id), eq(schema.persons.orgId, orgId))).limit(1);
      return r ? { type, id, label: `${r.first} ${r.last}`, href: `${base}/${r.status === "candidat" ? "candidats" : "apprenants"}/${id}` } : null;
    }
    case "invoice": {
      const [r] = await db.select({ number: schema.invoices.number, total: schema.invoices.totalTtcCents }).from(schema.invoices).where(and(eq(schema.invoices.id, id), eq(schema.invoices.orgId, orgId))).limit(1);
      return r ? { type, id, label: `Facture ${r.number ?? "(brouillon)"}`, href: `${base}/factures/${id}` } : null;
    }
    default:
      return null;
  }
}

/** Recherche d'un dossier à lier (sélecteur) : résultats renvoyés en JSON dans `data.results`. */
export async function searchEntitiesAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    await requireOrg(orgId, "tasks.manage");
    const type = z.enum(["enrollment", "session", "company", "person", "invoice"]).parse(formData.get("entityType"));
    const q = String(formData.get("q") ?? "").trim().slice(0, 60);
    if (q.length < 2) return { ok: true, message: "", data: { results: "[]" } };
    const like = `%${q}%`;
    let results: { id: string; label: string }[] = [];
    if (type === "enrollment") {
      const rows = await db
        .select({ id: schema.enrollments.id, ref: schema.enrollments.reference, first: schema.persons.firstName, last: schema.persons.lastName })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .where(and(eq(schema.enrollments.orgId, orgId), or(ilike(schema.enrollments.reference, like), ilike(schema.persons.lastName, like), ilike(schema.persons.firstName, like))))
        .limit(10);
      results = rows.map((r) => ({ id: r.id, label: `${r.ref} : ${r.first} ${r.last}` }));
    } else if (type === "session") {
      const rows = await db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.orgId, orgId), or(ilike(schema.trainingSessions.code, like), ilike(schema.trainingSessions.title, like)))).limit(10);
      results = rows.map((r) => ({ id: r.id, label: `${r.code} : ${r.title}` }));
    } else if (type === "company") {
      const rows = await db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(and(eq(schema.companies.orgId, orgId), ilike(schema.companies.name, like))).limit(10);
      results = rows.map((r) => ({ id: r.id, label: r.name }));
    } else if (type === "person") {
      const rows = await db.select({ id: schema.persons.id, first: schema.persons.firstName, last: schema.persons.lastName }).from(schema.persons).where(and(eq(schema.persons.orgId, orgId), or(ilike(schema.persons.lastName, like), ilike(schema.persons.firstName, like), ilike(sql`${schema.persons.firstName} || ' ' || ${schema.persons.lastName}`, like)))).limit(10);
      results = rows.map((r) => ({ id: r.id, label: `${r.first} ${r.last}` }));
    } else {
      const rows = await db.select({ id: schema.invoices.id, number: schema.invoices.number }).from(schema.invoices).where(and(eq(schema.invoices.orgId, orgId), ilike(schema.invoices.number, like))).limit(10);
      results = rows.map((r) => ({ id: r.id, label: `Facture ${r.number ?? "(brouillon)"}` }));
    }
    return { ok: true, message: "", data: { results: JSON.stringify(results) } };
  } catch (e) {
    return fail(e, "Recherche impossible.");
  }
}
