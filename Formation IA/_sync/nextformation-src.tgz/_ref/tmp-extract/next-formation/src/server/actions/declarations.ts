"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { todayParis } from "@/lib/time";
import { assertEnrollmentInScope, requireOrg } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { EDOF_STATUSES, KAIROS_STATUSES } from "@/server/declarations/service";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const isoOrEmpty = z.string().trim().regex(/^(\d{4}-\d{2}-\d{2})?$/, "Date invalide (AAAA-MM-JJ).");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

async function load(orgId: string, enrollmentId: string) {
  const ctx = await requireOrg(orgId, "enrollments.view", "sessions.view", "enrollments.manage");
  await assertEnrollmentInScope(ctx, enrollmentId);
  const [e] = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, ctx.org.id))).limit(1);
  if (!e) throw new Error("Inscription introuvable dans cet organisme.");
  return { ctx, e };
}

function done(orgId: string, enrollmentId: string) {
  revalidatePath(`/app/${orgId}/declarations`);
  revalidatePath(`/app/${orgId}/inscriptions/${enrollmentId}`);
}

/** Suivi du devis AIF saisi sur Kairos : statut et référence du devis. */
export async function updateKairosAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const { ctx, e } = await load(orgId, enrollmentId);
    const status = String(formData.get("kairosStatus") ?? "").trim();
    if (status && !KAIROS_STATUSES.some((s) => s.value === status)) return { error: "Statut Kairos inconnu." };
    const ref = z.string().trim().max(60, "Référence trop longue (60 caractères).").parse(String(formData.get("kairosDevisRef") ?? ""));
    if (status && status !== "transmis" && !ref && !e.kairosDevisRef) return { error: "Indiquez la référence du devis Kairos avant de faire avancer le dossier." };
    const after = { kairosStatus: status || null, kairosDevisRef: ref || null };
    await db.update(schema.enrollments).set(after).where(eq(schema.enrollments.id, e.id));
    await audit({ action: "enrollment.kairos.update", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { kairosStatus: e.kairosStatus, kairosDevisRef: e.kairosDevisRef }, after });
    done(orgId, e.id);
    return { ok: true, message: "Dossier Kairos enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Suivi EDOF (CPF) : statut, dates d'entrée et de sortie déclarées. Aucune date future (référence : jour Paris). */
export async function updateEdofAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const { ctx, e } = await load(orgId, enrollmentId);
    const status = String(formData.get("edofStatus") ?? "").trim();
    if (status && !EDOF_STATUSES.some((s) => s.value === status)) return { error: "Statut EDOF inconnu." };
    const entry = isoOrEmpty.parse(String(formData.get("edofEntryAt") ?? "")) || null;
    const exit = isoOrEmpty.parse(String(formData.get("edofExitAt") ?? "")) || null;
    const today = todayParis();
    if (entry && entry > today) return { error: "La date d'entrée déclarée ne peut pas être dans le futur." };
    if (exit && exit > today) return { error: "La date de sortie déclarée ne peut pas être dans le futur." };
    if (exit && !entry) return { error: "Déclarez l'entrée en formation avant la sortie." };
    if (entry && exit && exit < entry) return { error: "La sortie précède l'entrée en formation." };
    if ((status === "entree" || status === "sortie" || status === "facture") && !entry) return { error: "Statut incompatible : indiquez la date d'entrée déclarée sur EDOF." };
    if ((status === "sortie" || status === "facture") && !exit) return { error: "Statut incompatible : indiquez la date de sortie déclarée sur EDOF." };
    const after = { edofStatus: status || null, edofEntryAt: entry, edofExitAt: exit };
    await db.update(schema.enrollments).set(after).where(eq(schema.enrollments.id, e.id));
    await audit({ action: "enrollment.edof.update", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { edofStatus: e.edofStatus, edofEntryAt: e.edofEntryAt, edofExitAt: e.edofExitAt }, after });
    done(orgId, e.id);
    const warn = entry && !e.elearningFirstLoginAt && !e.edofEntryAt ? " Attention : aucune connexion e-learning n'est enregistrée ; EDOF n'accepte l'entrée qu'avec une trace de connexion." : "";
    return { ok: true, message: `Dossier EDOF enregistré.${warn}` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}
