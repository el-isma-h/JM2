import "server-only";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db, schema, type Db } from "@/db";
import { numberingPrefix } from "@/server/numbering";
import { todayParis } from "@/lib/time";
import { ACTIVE_ENROLLMENT_STATUSES, CONFIRMED_ENROLLMENT_STATUSES } from "@/server/enrollments/rules";
import { canTransitionSession, normalizeRhythm, type Rhythm, type SessionCounts, type SessionStatus } from "./rules";

export { canTransitionSession, normalizeRhythm, nextSessionStatuses, rhythmLabel, sessionStatusLabels, RHYTHM_PRESETS, WEEKDAY_LABELS } from "./rules";
export type { Rhythm, SessionStatus, SessionCounts, TransitionResult } from "./rules";

type Tx = Pick<Db, "select" | "insert" | "update" | "execute">;

export type SessionPlaces = { capacity: number; minCapacity: number; enrolled: number; confirmed: number; remaining: number };

/**
 * Places d'une session : capacité, inscriptions actives (préinscrit, inscrit, en cours), confirmées
 * (inscrit, en cours) et places restantes. Réutilisable par toutes les équipes (planning, extranets, pilotage).
 */
export async function sessionPlaces(sessionId: string, tx: Tx = db): Promise<SessionPlaces> {
  const [s] = await tx.select({ capacity: schema.trainingSessions.capacity, minCapacity: schema.trainingSessions.minCapacity }).from(schema.trainingSessions).where(eq(schema.trainingSessions.id, sessionId)).limit(1);
  if (!s) return { capacity: 0, minCapacity: 0, enrolled: 0, confirmed: 0, remaining: 0 };
  const [c] = await tx
    .select({
      enrolled: sql<number>`count(*) filter (where ${schema.enrollments.status} in ('preinscrit','inscrit','en_cours'))::int`,
      confirmed: sql<number>`count(*) filter (where ${schema.enrollments.status} in ('inscrit','en_cours'))::int`,
    })
    .from(schema.enrollments)
    .where(eq(schema.enrollments.sessionId, sessionId));
  const enrolled = c?.enrolled ?? 0;
  const confirmed = c?.confirmed ?? 0;
  return { capacity: s.capacity, minCapacity: s.minCapacity, enrolled, confirmed, remaining: Math.max(0, s.capacity - enrolled) };
}

/** Places par groupe : inscriptions actives rattachées à chaque groupe de la session. */
export async function groupPlaces(sessionId: string) {
  const rows = await db
    .select({ groupId: schema.enrollments.groupId, n: sql<number>`count(*)::int` })
    .from(schema.enrollments)
    .where(and(eq(schema.enrollments.sessionId, sessionId), inArray(schema.enrollments.status, ACTIVE_ENROLLMENT_STATUSES)))
    .groupBy(schema.enrollments.groupId);
  const map = new Map<string | null, number>();
  for (const r of rows) map.set(r.groupId, r.n);
  return map;
}

/** Compteurs nécessaires à `canTransitionSession`, calculés côté serveur (date Paris incluse). */
export async function sessionCounts(sessionId: string): Promise<SessionCounts> {
  const p = await sessionPlaces(sessionId);
  return { enrolled: p.enrolled, confirmed: p.confirmed, today: todayParis() };
}

/** Vérifie une transition pour une session chargée en base (avec compteurs réels). */
export async function checkSessionTransition(session: typeof schema.trainingSessions.$inferSelect, to: SessionStatus) {
  const counts = await sessionCounts(session.id);
  return canTransitionSession({ status: session.status, startDate: session.startDate, endDate: session.endDate, minCapacity: session.minCapacity, capacity: session.capacity }, to, counts);
}

/** Numéro de session atomique : SES-AAAA-NNNN (séquence `invoice_sequences`, kind "session"). */
export async function nextSessionCode(tx: Tx, orgId: string, year = new Date().getFullYear()): Promise<string> {
  const [row] = await tx
    .insert(schema.invoiceSequences)
    .values({ orgId, kind: "session", year, next: 2 })
    .onConflictDoUpdate({ target: [schema.invoiceSequences.orgId, schema.invoiceSequences.kind, schema.invoiceSequences.year], set: { next: sql`${schema.invoiceSequences.next} + 1` } })
    .returning({ next: schema.invoiceSequences.next });
  return `${await numberingPrefix(orgId, "session", "SES")}-${year}-${String(row.next - 1).padStart(4, "0")}`;
}

/** Rythme effectif d'une session (JSON stocké normalisé, horaires de l'organisme en repli). */
export function sessionRhythm(session: { rhythm: unknown }, org: { settings: unknown }): Rhythm {
  const settings = (org.settings ?? {}) as { morning?: { start: string; end: string }; afternoon?: { start: string; end: string } };
  return normalizeRhythm((session.rhythm ?? {}) as Partial<Rhythm>, settings);
}

/** Utilisateurs membres actifs de l'organisme (pour les responsables pédagogique / administratif). */
export async function orgMembers(orgId: string) {
  return db
    .select({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, roles: schema.memberships.roles })
    .from(schema.memberships)
    .innerJoin(schema.users, eq(schema.users.id, schema.memberships.userId))
    .where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.active, true)))
    .orderBy(schema.users.lastName, schema.users.firstName);
}

export { CONFIRMED_ENROLLMENT_STATUSES };
