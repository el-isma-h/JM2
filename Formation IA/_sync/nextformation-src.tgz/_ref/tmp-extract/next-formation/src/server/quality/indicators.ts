import "server-only";
import { and, eq, inArray, isNotNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { dropoutFrom, parseQuestions, responseRateFrom, satisfactionFromResponses, successFrom, type IndicatorValue } from "./indicator-math";

export type { IndicatorValue };

type SurveyScope = { sessionId?: string | null; programId?: string | null; surveyId?: string | null; kinds?: ("satisfaction_chaud" | "satisfaction_froid" | "employeur" | "formateur" | "financeur")[] };

async function surveysInScope(orgId: string, scope: SurveyScope) {
  const conds = [eq(schema.surveys.orgId, orgId)];
  if (scope.surveyId) conds.push(eq(schema.surveys.id, scope.surveyId));
  if (scope.sessionId) conds.push(eq(schema.surveys.sessionId, scope.sessionId));
  if (scope.programId) conds.push(eq(schema.surveys.programId, scope.programId));
  if (scope.kinds?.length) conds.push(inArray(schema.surveys.kind, scope.kinds));
  return db.select().from(schema.surveys).where(and(...conds));
}

function scopeLabel(scope: SurveyScope): string {
  if (scope.surveyId) return "enquête";
  if (scope.sessionId) return "session";
  if (scope.programId) return "programme";
  return "organisme";
}

/** Taux de satisfaction (F15) : réponses ≥ 4/5 à la question globale / répondants l'ayant renseignée. */
export async function satisfactionRate(orgId: string, scope: SurveyScope = {}): Promise<IndicatorValue> {
  const now = new Date().toISOString();
  const surveys = await surveysInScope(orgId, { kinds: ["satisfaction_chaud", "satisfaction_froid", "employeur", "formateur", "financeur"], ...scope });
  if (!surveys.length) return { ...satisfactionFromResponses([], now), scope: scopeLabel(scope) };
  const responses = await db
    .select({ surveyId: schema.surveyResponses.surveyId, answers: schema.surveyResponses.answers })
    .from(schema.surveyResponses)
    .where(and(eq(schema.surveyResponses.orgId, orgId), inArray(schema.surveyResponses.surveyId, surveys.map((s) => s.id)), isNotNull(schema.surveyResponses.submittedAt)));
  const byId = new Map(surveys.map((s) => [s.id, parseQuestions(s.questions)]));
  return { ...satisfactionFromResponses(responses.map((r) => ({ answers: r.answers as Record<string, string | number | null>, questions: byId.get(r.surveyId) ?? [] })), now), scope: scopeLabel(scope) };
}

/** Taux de retour : questionnaires soumis / questionnaires envoyés. */
export async function responseRate(orgId: string, scope: SurveyScope = {}): Promise<IndicatorValue> {
  const now = new Date().toISOString();
  const surveys = await surveysInScope(orgId, scope);
  if (!surveys.length) return { ...responseRateFrom(0, 0, now), scope: scopeLabel(scope) };
  const rows = await db
    .select({ sentAt: schema.surveyResponses.sentAt, submittedAt: schema.surveyResponses.submittedAt })
    .from(schema.surveyResponses)
    .where(and(eq(schema.surveyResponses.orgId, orgId), inArray(schema.surveyResponses.surveyId, surveys.map((s) => s.id))));
  const sent = rows.filter((r) => r.sentAt).length;
  const submitted = rows.filter((r) => r.sentAt && r.submittedAt).length;
  return { ...responseRateFrom(sent, submitted, now), scope: scopeLabel(scope) };
}

async function sessionEnrollments(orgId: string, sessionId: string) {
  return db
    .select({ status: schema.enrollments.status, examState: schema.enrollments.examState })
    .from(schema.enrollments)
    .where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.sessionId, sessionId)));
}

/** Taux d'abandon d'une session : abandons / inscriptions entrées en formation. */
export async function dropoutRate(orgId: string, sessionId: string): Promise<IndicatorValue> {
  return { ...dropoutFrom(await sessionEnrollments(orgId, sessionId), new Date().toISOString()), scope: "session" };
}

/** Taux de réussite d'une session : admis / présentés à l'examen. */
export async function successRate(orgId: string, sessionId: string): Promise<IndicatorValue> {
  return { ...successFrom(await sessionEnrollments(orgId, sessionId), new Date().toISOString()), scope: "session" };
}
