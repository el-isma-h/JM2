/**
 * Modèles de documents plateforme (orgId null), en Markdown avec variables `{{chemin}}` et sections `{{#if …}}`.
 * Rendu par `renderTemplate` : toute variable absente devient un marqueur « [À COMPLÉTER : …] » (jamais une valeur inventée).
 *
 * Variables disponibles (voir `TEMPLATE_VARIABLES` et `collectTemplateData` dans generate.ts) :
 *   org.*            identité institutionnelle de l'organisme de l'inscription (jamais d'un autre organisme)
 *   enrollment.*     inscription (référence, dates, heures, prix) + enrollment.person.* + enrollment.tutor.*
 *   session.*        session (titre, dates, lieu, formateurs, planningList, learnerList)
 *   programVersion.* programme contractualisé (objectifs, prérequis, contenu, durée, modalités…)
 *   company.*        entreprise (nom, SIRET, adresse, signataire)
 *   funding.*        financement principal (montant, financeur, accord)
 *   answers.*        réponses aux questions du modèle
 *   today, document.* (date d'émission, numéro)
 *
 * Ce fichier est pur (aucune dépendance serveur) : il peut être testé et importé partout.
 */

export type TemplateQuestion = {
  key: string;
  label: string;
  help?: string;
  kind: "text" | "textarea" | "date" | "choice" | "number";
  options?: { value: string; label: string }[];
  required?: boolean;
};

export type TemplateScope = "enrollment" | "session" | "company" | "person" | "org";

export type TemplateDefinition = {
  code: string;
  category:
    | "convention"
    | "contrat"
    | "cerfa"
    | "convocation"
    | "annexe_parcours"
    | "programme"
    | "reglement_interieur"
    | "attestation"
    | "certificat_realisation"
    | "feuille_emargement"
    | "livret"
    | "autre";
  title: string;
  description: string;
  scope: TemplateScope;
  activity: "of" | "cfa" | "both";
  /** Visibilité du document produit. */
  visibility: "interne" | "administratif" | "pedagogie" | "apprenant" | "entreprise";
  questions: TemplateQuestion[];
  body: string;
};

/** Libellés lisibles des variables (affichés dans les marqueurs et dans l'aide à l'édition des modèles). */
export const TEMPLATE_VARIABLES: Record<string, string> = {
  today: "Date du jour",
  "document.date": "Date d'émission du document",
  "document.reference": "Référence du document",
  "org.legalName": "Raison sociale de l'organisme",
  "org.tradeName": "Nom commercial de l'organisme",
  "org.legalForm": "Forme juridique de l'organisme",
  "org.siret": "SIRET de l'organisme",
  "org.siren": "SIREN de l'organisme",
  "org.nda": "Numéro de déclaration d'activité (NDA)",
  "org.ndaRegion": "Région d'enregistrement du NDA",
  "org.uaiCode": "Code UAI (CFA)",
  "org.address": "Adresse de l'organisme",
  "org.postalCode": "Code postal de l'organisme",
  "org.city": "Ville de l'organisme",
  "org.email": "E-mail de l'organisme",
  "org.phone": "Téléphone de l'organisme",
  "org.website": "Site web de l'organisme",
  "org.signatoryName": "Nom du signataire de l'organisme",
  "org.signatoryTitle": "Fonction du signataire de l'organisme",
  "org.qualiopiNumber": "Numéro de certification Qualiopi",
  "org.qualiopiCertifier": "Certificateur Qualiopi",
  "org.kindLabel": "Nature de l'organisme (OF, CFA)",
  "enrollment.reference": "Référence de l'inscription",
  "enrollment.contractKindLabel": "Type de contractualisation",
  "enrollment.contractNumber": "Numéro de contrat",
  "enrollment.startDate": "Date de début du parcours",
  "enrollment.endDate": "Date de fin du parcours",
  "enrollment.hoursPlanned": "Heures prévues du parcours",
  "enrollment.hoursDone": "Heures effectuées (périodes clôturées)",
  "enrollment.hoursJustified": "Heures d'absence justifiées",
  "enrollment.absenceHours": "Heures d'absence",
  "enrollment.price": "Prix de la prestation (HT)",
  "enrollment.priceTtc": "Prix de la prestation (TTC)",
  "enrollment.person.fullName": "Nom complet de l'apprenant",
  "enrollment.person.civility": "Civilité de l'apprenant",
  "enrollment.person.firstName": "Prénom de l'apprenant",
  "enrollment.person.lastName": "Nom de l'apprenant",
  "enrollment.person.birthDate": "Date de naissance de l'apprenant",
  "enrollment.person.birthPlace": "Lieu de naissance de l'apprenant",
  "enrollment.person.address": "Adresse de l'apprenant",
  "enrollment.person.email": "E-mail de l'apprenant",
  "enrollment.person.phone": "Téléphone de l'apprenant",
  "enrollment.person.educationLevel": "Niveau de formation de l'apprenant",
  "enrollment.tutor.fullName": "Nom du tuteur en entreprise",
  "enrollment.tutor.jobTitle": "Fonction du tuteur",
  "enrollment.tutor.email": "E-mail du tuteur",
  "enrollment.tutor.phone": "Téléphone du tuteur",
  "session.title": "Intitulé de la session",
  "session.code": "Code de la session",
  "session.startDate": "Date de début de la session",
  "session.endDate": "Date de fin de la session",
  "session.kindLabel": "Type de session (inter, intra…)",
  "session.modalityLabel": "Modalité de la session",
  "session.site.name": "Nom du lieu de formation",
  "session.site.address": "Adresse du lieu de formation",
  "session.site.accessibilityNote": "Accessibilité du lieu",
  "session.trainers": "Formateurs de la session",
  "session.planningList": "Planning des séances (liste)",
  "session.slotCount": "Nombre de séances planifiées",
  "session.learnerList": "Liste des apprenants inscrits",
  "session.learnerCount": "Nombre d'apprenants inscrits",
  "session.scheduleMorning": "Horaires du matin",
  "session.scheduleAfternoon": "Horaires de l'après-midi",
  "programVersion.title": "Intitulé de la formation",
  "programVersion.code": "Code du programme",
  "programVersion.version": "Version du programme",
  "programVersion.objectives": "Objectifs de la formation",
  "programVersion.prerequisites": "Prérequis",
  "programVersion.audience": "Public visé",
  "programVersion.modalityLabel": "Modalité pédagogique",
  "programVersion.durationHours": "Durée totale (heures)",
  "programVersion.durationDays": "Durée (jours)",
  "programVersion.companyHours": "Heures en entreprise",
  "programVersion.remoteHours": "Heures à distance",
  "programVersion.content": "Contenu de la formation",
  "programVersion.methods": "Méthodes pédagogiques",
  "programVersion.evaluationMethods": "Modalités d'évaluation",
  "programVersion.resources": "Moyens pédagogiques et techniques",
  "programVersion.accessibility": "Accessibilité aux personnes en situation de handicap",
  "programVersion.accessDelay": "Délai d'accès",
  "programVersion.price": "Tarif public (HT)",
  "programVersion.certification": "Certification visée",
  "programVersion.modulesList": "Modules du programme (liste)",
  "programVersion.trainerProfile": "Profil des formateurs",
  "company.name": "Raison sociale de l'entreprise",
  "company.siret": "SIRET de l'entreprise",
  "company.address": "Adresse de l'entreprise",
  "company.opco": "OPCO de l'entreprise",
  "company.idcc": "Code IDCC de l'entreprise",
  "company.email": "E-mail de l'entreprise",
  "company.phone": "Téléphone de l'entreprise",
  "company.signatory.fullName": "Nom du signataire de l'entreprise",
  "company.signatory.jobTitle": "Fonction du signataire de l'entreprise",
  "funding.label": "Libellé du financement",
  "funding.amount": "Montant du financement",
  "funding.kindLabel": "Type de financeur",
  "funding.funderName": "Nom du financeur",
  "funding.agreementRef": "Référence de l'accord de prise en charge",
  "funding.agreementDate": "Date de l'accord de prise en charge",
  "answers.signaturePlace": "Lieu de signature",
  "answers.paymentTerms": "Conditions de règlement",
  "answers.arrivalTime": "Heure d'arrivée demandée",
  "answers.arrivalInstructions": "Consignes d'accueil",
  "answers.resultSummary": "Résultats de l'évaluation des acquis",
  "answers.actionNature": "Nature de l'action",
  "answers.remiseDate": "Date de remise",
  "answers.gratification": "Gratification de stage",
  "answers.weeklyHours": "Durée hebdomadaire",
  "answers.missionDescription": "Missions confiées",
  "answers.salaryPercent": "Rémunération (pourcentage du SMIC)",
  "answers.apprenticeshipMaster": "Maître d'apprentissage",
  "answers.contractStart": "Date de début du contrat",
  "answers.contractEnd": "Date de fin du contrat",
  "answers.weeklyHoursCompany": "Durée hebdomadaire de travail",
  "answers.additionalRules": "Dispositions particulières",
  "answers.emergencyContact": "Contact d'urgence de l'organisme",
};

const ORG_BLOCK = `**{{org.legalName}}**{{#if org.legalForm}}, {{org.legalForm}}{{/if}}
{{org.address}}
SIRET : {{org.siret}}
Déclaration d'activité enregistrée sous le numéro {{org.nda}} auprès de la préfecture de la région {{org.ndaRegion}}. Cet enregistrement ne vaut pas agrément de l'État.
{{#if org.qualiopiNumber}}Certification qualité Qualiopi n° {{org.qualiopiNumber}}.{{/if}}
Représenté par {{org.signatoryName}}, {{org.signatoryTitle}}.`;

const SIGNATURE_ORG = `**Pour l'organisme de formation**
{{org.legalName}}
{{org.signatoryName}}, {{org.signatoryTitle}}
Date et signature :`;

export const PLATFORM_TEMPLATES: TemplateDefinition[] = [
  /* ------------------------------------------------------------------ */
  {
    code: "convention_formation",
    category: "convention",
    title: "Convention de formation professionnelle (entreprise)",
    description: "Convention bipartite entre l'organisme et l'entreprise cliente pour un salarié inscrit (articles L.6353-1 et L.6353-2 du Code du travail).",
    scope: "enrollment",
    activity: "of",
    visibility: "administratif",
    questions: [
      { key: "signaturePlace", label: "Lieu de signature", kind: "text", required: true },
      { key: "paymentTerms", label: "Conditions de règlement", kind: "textarea", help: "Ex. : 30 % à la signature, solde à réception de facture à l'issue de la formation.", required: true },
    ],
    body: `# Convention de formation professionnelle

Convention établie en application des articles L.6353-1 et L.6353-2 du Code du travail.
Référence : {{enrollment.reference}}

## Entre les soussignés

${ORG_BLOCK}

Ci-après dénommé « l'organisme de formation »,

**et**

**{{company.name}}**
{{company.address}}
SIRET : {{company.siret}}
Représentée par {{company.signatory.fullName}}, {{company.signatory.jobTitle}}.

Ci-après dénommée « l'entreprise »,

Il est convenu ce qui suit.

## Article 1 : Objet

L'entreprise confie à l'organisme de formation, qui l'accepte, la réalisation de l'action de formation suivante :

- Intitulé : **{{programVersion.title}}**
- Nature de l'action (article L.6313-1 du Code du travail) : action de formation
- Session : {{session.title}} ({{session.code}})
- Stagiaire : {{enrollment.person.fullName}}
- Dates : du {{enrollment.startDate}} au {{enrollment.endDate}}
- Durée : {{enrollment.hoursPlanned}} heures
- Modalité : {{programVersion.modalityLabel}}
- Lieu : {{session.site.name}}, {{session.site.address}}

## Article 2 : Objectifs et programme

{{programVersion.objectives}}

Le programme détaillé, les prérequis, les méthodes et les modalités d'évaluation figurent dans le programme de formation remis à l'entreprise, qui fait partie intégrante de la présente convention.

## Article 3 : Public et prérequis

Public visé : {{programVersion.audience}}
Prérequis : {{programVersion.prerequisites}}

## Article 4 : Organisation et moyens

L'action est animée par des formateurs qualifiés de l'organisme. Moyens pédagogiques et techniques : {{programVersion.resources}}
Modalités d'évaluation des acquis : {{programVersion.evaluationMethods}}
Modalités de suivi : feuilles d'émargement par période (matin et après-midi) signées par le stagiaire et le formateur ; une attestation de fin de formation et un certificat de réalisation sont délivrés à l'issue de l'action.

## Article 5 : Prix et conditions de règlement

Le prix de la prestation est fixé à **{{enrollment.price}} HT**, soit {{enrollment.priceTtc}} TTC.
{{#if funding.label}}Prise en charge prévue : {{funding.label}} ({{funding.funderName}}) pour un montant de {{funding.amount}}{{#if funding.agreementRef}}, accord n° {{funding.agreementRef}} du {{funding.agreementDate}}{{/if}}. L'entreprise reste redevable de toute somme non prise en charge par le financeur.{{/if}}

Conditions de règlement : {{answers.paymentTerms}}

## Article 6 : Dédit et absences

En cas d'annulation par l'entreprise moins de dix jours ouvrés avant le début de l'action, l'organisme facturera à titre de dédit une somme égale à 30 % du prix. En cas de réalisation partielle imputable à l'entreprise ou au stagiaire, seules les heures effectivement réalisées sont facturées au titre de la formation ; les heures non réalisées font l'objet d'une facturation distincte de dédommagement, non imputable sur l'obligation de participation au développement de la formation professionnelle.

En cas de force majeure dûment reconnue, la convention est résiliée de plein droit ; seules les prestations effectivement dispensées sont dues au prorata de leur valeur.

## Article 7 : Règlement intérieur et obligations

Le stagiaire est tenu de respecter le règlement intérieur de l'organisme, qui lui est remis avant le début de l'action. L'organisme s'engage à la confidentialité des informations recueillies et au respect de la réglementation relative à la protection des données personnelles.

## Article 8 : Différends

En cas de litige non résolu à l'amiable, le tribunal compétent est celui du siège de l'organisme de formation.

***

Fait en deux exemplaires à {{answers.signaturePlace}}, le {{document.date}}.

${SIGNATURE_ORG}

**Pour l'entreprise**
{{company.name}}
{{company.signatory.fullName}}, {{company.signatory.jobTitle}}
Date, signature et cachet :`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "contrat_formation_particulier",
    category: "contrat",
    title: "Contrat de formation professionnelle (particulier)",
    description: "Contrat conclu avec une personne physique qui entreprend une formation à titre individuel et à ses frais (articles L.6353-3 à L.6353-7 du Code du travail).",
    scope: "enrollment",
    activity: "of",
    visibility: "administratif",
    questions: [
      { key: "signaturePlace", label: "Lieu de signature", kind: "text", required: true },
      { key: "paymentTerms", label: "Conditions de règlement", kind: "textarea", help: "Aucune somme ne peut être exigée avant l'expiration du délai de rétractation ; l'acompte ne peut dépasser 30 % du prix.", required: true },
    ],
    body: `# Contrat de formation professionnelle

Contrat conclu en application des articles L.6353-3 à L.6353-7 du Code du travail.
Référence : {{enrollment.reference}}

## Entre les soussignés

${ORG_BLOCK}

Ci-après dénommé « l'organisme de formation »,

**et**

{{enrollment.person.civility}} **{{enrollment.person.fullName}}**
Né(e) le {{enrollment.person.birthDate}} à {{enrollment.person.birthPlace}}
Demeurant {{enrollment.person.address}}
E-mail : {{enrollment.person.email}}

Ci-après dénommé(e) « le stagiaire »,

Il est convenu ce qui suit.

## Article 1 : Objet

L'organisme de formation s'engage à organiser l'action de formation suivante :

- Intitulé : **{{programVersion.title}}**
- Nature de l'action (article L.6313-1 du Code du travail) : action de formation
- Session : {{session.title}}
- Dates : du {{enrollment.startDate}} au {{enrollment.endDate}}
- Durée : {{enrollment.hoursPlanned}} heures
- Modalité : {{programVersion.modalityLabel}}
- Lieu : {{session.site.name}}, {{session.site.address}}

## Article 2 : Objectifs, programme et niveau requis

Objectifs : {{programVersion.objectives}}
Prérequis et niveau de connaissances préalables requis : {{programVersion.prerequisites}}
Le programme détaillé est annexé au présent contrat.

## Article 3 : Organisation de l'action

Moyens pédagogiques et techniques : {{programVersion.resources}}
Modalités d'évaluation des acquis : {{programVersion.evaluationMethods}}
Sanction de la formation : attestation de fin de formation et certificat de réalisation{{#if programVersion.certification}} ; certification visée : {{programVersion.certification}}{{/if}}.

## Article 4 : Délai de rétractation

À compter de la date de signature du présent contrat, le stagiaire dispose d'un délai de dix jours pour se rétracter, par lettre recommandée avec accusé de réception. Aucune somme ne peut être exigée du stagiaire avant l'expiration de ce délai.

## Article 5 : Prix et conditions de règlement

Le prix de l'action de formation est fixé à **{{enrollment.price}} HT**, soit {{enrollment.priceTtc}} TTC.
À l'expiration du délai de rétractation, un acompte ne pouvant excéder 30 % du prix peut être demandé. Le solde est réglé selon l'échéancier suivant, au fur et à mesure du déroulement de l'action : {{answers.paymentTerms}}

## Article 6 : Interruption de l'action

En cas de cessation anticipée de la formation du fait de l'organisme ou d'abandon par le stagiaire pour un motif autre que la force majeure dûment reconnue, le présent contrat est résilié ; seules les prestations effectivement dispensées sont dues au prorata de leur valeur prévue au contrat.
Si le stagiaire est empêché de suivre la formation par suite de force majeure dûment reconnue, le contrat est résilié et seules les prestations effectivement dispensées sont dues.

## Article 7 : Règlement intérieur

Le stagiaire déclare avoir pris connaissance du règlement intérieur de l'organisme et s'engage à le respecter.

## Article 8 : Différends

En cas de litige non résolu à l'amiable, le tribunal compétent est celui du lieu de résidence du stagiaire.

***

Fait en deux exemplaires à {{answers.signaturePlace}}, le {{document.date}}.

${SIGNATURE_ORG}

**Le stagiaire**
{{enrollment.person.fullName}}
Date et signature, précédée de la mention « lu et approuvé » :`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "convocation",
    category: "convocation",
    title: "Convocation à la formation (avec annexe de parcours)",
    description: "Convocation individuelle reprenant les dates, le lieu, les horaires, puis l'annexe de parcours listant toutes les séances planifiées (plusieurs pages si nécessaire).",
    scope: "enrollment",
    activity: "both",
    visibility: "apprenant",
    questions: [
      { key: "arrivalTime", label: "Heure d'arrivée demandée le premier jour", kind: "text", help: "Ex. : 08h45", required: true },
      { key: "arrivalInstructions", label: "Consignes d'accueil", kind: "textarea", help: "Pièces à apporter, accès, contact sur place." },
    ],
    body: `# Convocation

{{org.city}}, le {{document.date}}

{{enrollment.person.civility}} {{enrollment.person.fullName}}
{{enrollment.person.address}}

Référence : {{enrollment.reference}}

Madame, Monsieur,

Nous avons le plaisir de vous confirmer votre inscription à la formation **{{programVersion.title}}** et vous prions de bien vouloir vous présenter :

- Session : {{session.title}} ({{session.code}})
- Premier jour : **{{enrollment.startDate}}** à {{answers.arrivalTime}}
- Dernier jour : {{enrollment.endDate}}
- Lieu : {{session.site.name}}, {{session.site.address}}
- Horaires habituels : {{session.scheduleMorning}} et {{session.scheduleAfternoon}}
- Durée totale : {{enrollment.hoursPlanned}} heures
- Formateur(s) : {{session.trainers}}

{{#if answers.arrivalInstructions}}Consignes d'accueil : {{answers.arrivalInstructions}}{{/if}}

{{#if session.site.accessibilityNote}}Accessibilité : {{session.site.accessibilityNote}}{{/if}}

Nous vous rappelons que l'émargement est obligatoire à chaque période (matin et après-midi) et que toute absence doit être signalée au plus tôt à l'organisme. Le règlement intérieur, le programme et le livret d'accueil vous ont été remis ou sont joints à la présente.

Pour toute question, vous pouvez nous joindre au {{org.phone}} ou à l'adresse {{org.email}}.

Nous vous prions d'agréer, Madame, Monsieur, l'expression de nos salutations distinguées.

{{org.signatoryName}}
{{org.signatoryTitle}}, {{org.legalName}}

***

# Annexe de parcours : planning des séances

Session {{session.title}}, du {{session.startDate}} au {{session.endDate}}, {{session.slotCount}} séance(s) planifiée(s).
Chaque séance comporte une ou deux périodes indépendantes (matin, après-midi) avec leurs propres horaires et leur propre émargement.

{{session.planningList}}

Ce planning est donné à titre prévisionnel ; toute modification vous sera notifiée par l'organisme.`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "annexe_parcours",
    category: "annexe_parcours",
    title: "Annexe de parcours (planning individuel)",
    description: "Planning détaillé des séances du parcours, à joindre à une convention, un contrat ou une convocation.",
    scope: "enrollment",
    activity: "both",
    visibility: "apprenant",
    questions: [],
    body: `# Annexe de parcours

Apprenant : **{{enrollment.person.fullName}}** (référence {{enrollment.reference}})
Formation : {{programVersion.title}}
Session : {{session.title}} ({{session.code}}), du {{enrollment.startDate}} au {{enrollment.endDate}}
Lieu : {{session.site.name}}, {{session.site.address}}
Durée prévue : {{enrollment.hoursPlanned}} heures, {{session.slotCount}} séance(s) planifiée(s)

## Séances planifiées

{{session.planningList}}

## Rappels

- Les heures prévues au planning sont distinctes des heures effectuées, qui résultent des présences constatées et des périodes clôturées.
- Toute absence doit être justifiée auprès de l'organisme ; les absences justifiées ne sont jamais comptées comme des heures effectuées.

Édité le {{document.date}} par {{org.legalName}}.`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "programme_formation",
    category: "programme",
    title: "Programme de formation",
    description: "Programme détaillé de la version de programme contractualisée (objectifs, prérequis, contenu, méthodes, évaluation, accessibilité).",
    scope: "session",
    activity: "both",
    visibility: "entreprise",
    questions: [],
    body: `# Programme de formation

## {{programVersion.title}}

{{#if programVersion.certification}}Certification visée : {{programVersion.certification}}{{/if}}
Version du programme : {{programVersion.version}}{{#if session.title}} ; session {{session.title}} du {{session.startDate}} au {{session.endDate}}{{/if}}

## Objectifs

{{programVersion.objectives}}

## Public visé et prérequis

Public : {{programVersion.audience}}
Prérequis : {{programVersion.prerequisites}}

## Durée et modalités

- Durée totale : {{programVersion.durationHours}} heures{{#if programVersion.durationDays}} ({{programVersion.durationDays}} jours){{/if}}
- Modalité : {{programVersion.modalityLabel}}
{{#if programVersion.companyHours}}- Dont heures en entreprise : {{programVersion.companyHours}}{{/if}}
{{#if programVersion.remoteHours}}- Dont heures à distance : {{programVersion.remoteHours}}{{/if}}
- Délai d'accès : {{programVersion.accessDelay}}

## Contenu

{{programVersion.content}}

{{#if programVersion.modulesList}}## Modules

{{programVersion.modulesList}}{{/if}}

## Méthodes pédagogiques

{{programVersion.methods}}

## Moyens pédagogiques et techniques

{{programVersion.resources}}

## Modalités d'évaluation et de suivi

{{programVersion.evaluationMethods}}
Suivi de l'exécution : émargement par période, attestation de fin de formation, certificat de réalisation.

## Profil des formateurs

{{programVersion.trainerProfile}}

## Accessibilité aux personnes en situation de handicap

{{programVersion.accessibility}}

## Tarif

{{programVersion.price}}

***

{{org.legalName}}, {{org.address}}. NDA {{org.nda}}. Édité le {{document.date}}.`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "reglement_interieur",
    category: "reglement_interieur",
    title: "Règlement intérieur (remise au stagiaire)",
    description: "Règlement intérieur applicable aux stagiaires et apprentis (articles L.6352-3 à L.6352-5 et R.6352-1 et suivants du Code du travail), avec accusé de remise.",
    scope: "enrollment",
    activity: "both",
    visibility: "apprenant",
    questions: [{ key: "additionalRules", label: "Dispositions particulières du site", kind: "textarea", help: "Consignes propres au lieu de formation (accès, stationnement, matériel)." }],
    body: `# Règlement intérieur applicable aux stagiaires et apprentis

Établi en application des articles L.6352-3 à L.6352-5 et R.6352-1 et suivants du Code du travail.

## Article 1 : Objet et champ d'application

Le présent règlement s'applique à toute personne inscrite à une action de formation organisée par {{org.legalName}}, pour toute la durée de la formation, quel que soit le lieu de son déroulement. Chaque stagiaire est considéré comme ayant accepté les termes du présent règlement lorsqu'il suit une formation dispensée par l'organisme.

## Article 2 : Hygiène et sécurité

Chaque stagiaire doit veiller à sa sécurité personnelle et à celle des autres en respectant les consignes générales et particulières de sécurité et d'hygiène en vigueur sur le lieu de formation. Lorsque la formation se déroule dans une entreprise ou un établissement déjà doté d'un règlement intérieur, les mesures de sécurité et d'hygiène applicables sont celles de ce dernier règlement.

- Il est interdit de fumer et de vapoter dans les locaux de formation.
- L'introduction ou la consommation de boissons alcoolisées ou de substances illicites est interdite.
- Les consignes d'incendie et d'évacuation affichées dans les locaux doivent être respectées.
- Tout accident ou incident survenu à l'occasion de la formation doit être immédiatement déclaré à l'organisme.

## Article 3 : Discipline

Les stagiaires sont tenus de respecter les horaires de formation fixés par l'organisme. L'émargement est effectué à chaque période (matin et après-midi). Toute absence ou retard doit être justifié auprès de l'organisme ; les absences non justifiées peuvent être signalées à l'employeur ou au financeur.

Il est interdit d'avoir un comportement susceptible de porter atteinte au respect dû aux personnes, de dégrader le matériel mis à disposition, ou de faire un usage des outils numériques contraire à la loi ou aux consignes de l'organisme.

## Article 4 : Sanctions

Tout manquement du stagiaire à l'une des prescriptions du présent règlement peut faire l'objet d'une sanction prononcée par le responsable de l'organisme ou son représentant : avertissement écrit, blâme, exclusion temporaire ou définitive de la formation. Les amendes ou autres sanctions pécuniaires sont interdites.

## Article 5 : Procédure disciplinaire

Aucune sanction ne peut être infligée au stagiaire sans que celui-ci ait été informé au préalable des griefs retenus contre lui. Lorsque la sanction envisagée est de nature à affecter immédiatement ou non la présence du stagiaire en formation, celui-ci est convoqué à un entretien, par lettre recommandée ou remise contre décharge, indiquant l'objet, la date, l'heure et le lieu de l'entretien ; il peut se faire assister par une personne de son choix, stagiaire ou salarié de l'organisme. La sanction, motivée, est notifiée par écrit au stagiaire, et le cas échéant à son employeur et au financeur, au plus tôt un jour franc et au plus tard quinze jours après l'entretien.

## Article 6 : Représentation des stagiaires

Pour les actions de formation d'une durée supérieure à cinq cents heures, il est procédé à l'élection d'un délégué titulaire et d'un délégué suppléant, au scrutin uninominal à deux tours, dans les conditions prévues aux articles R.6352-9 et suivants du Code du travail.

## Article 7 : Protection des données

Les informations recueillies font l'objet d'un traitement destiné à la gestion administrative et pédagogique de la formation. Le stagiaire dispose d'un droit d'accès, de rectification et d'opposition auprès de {{org.email}}.

{{#if answers.additionalRules}}## Article 8 : Dispositions particulières du site

{{answers.additionalRules}}{{/if}}

***

## Accusé de remise

Je soussigné(e) **{{enrollment.person.fullName}}**, inscrit(e) à la formation {{programVersion.title}} (session {{session.title}}, référence {{enrollment.reference}}), reconnais avoir reçu un exemplaire du présent règlement intérieur et m'engage à le respecter.

Fait à {{org.city}}, le {{document.date}}.

Signature du stagiaire :`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "attestation_fin_formation",
    category: "attestation",
    title: "Attestation de fin de formation",
    description: "Attestation délivrée au stagiaire à l'issue de l'action : objectifs, nature, durée et résultats de l'évaluation des acquis.",
    scope: "enrollment",
    activity: "both",
    visibility: "apprenant",
    questions: [{ key: "resultSummary", label: "Résultats de l'évaluation des acquis", kind: "textarea", help: "Synthèse factuelle issue des évaluations réalisées ; ne pas inventer un résultat.", required: true }],
    body: `# Attestation de fin de formation

Je soussigné(e) **{{org.signatoryName}}**, {{org.signatoryTitle}} de **{{org.legalName}}** (SIRET {{org.siret}}, déclaration d'activité n° {{org.nda}}), atteste que :

{{enrollment.person.civility}} **{{enrollment.person.fullName}}**, né(e) le {{enrollment.person.birthDate}},

a suivi l'action de formation suivante :

- Intitulé : **{{programVersion.title}}**
- Nature de l'action : action de formation (article L.6313-1 du Code du travail)
- Session : {{session.title}} ({{session.code}})
- Dates : du {{enrollment.startDate}} au {{enrollment.endDate}}
- Durée effectivement suivie : **{{enrollment.hoursDone}} heures**, sur {{enrollment.hoursPlanned}} heures prévues
- Modalité : {{programVersion.modalityLabel}}

## Objectifs de l'action

{{programVersion.objectives}}

## Résultats de l'évaluation des acquis

{{answers.resultSummary}}

Cette attestation est délivrée pour servir et valoir ce que de droit. Elle ne constitue ni un diplôme ni une certification.

Fait à {{org.city}}, le {{document.date}}.

{{org.signatoryName}}
{{org.signatoryTitle}}
Signature et cachet de l'organisme :`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "certificat_realisation",
    category: "certificat_realisation",
    title: "Certificat de réalisation",
    description: "Certificat de réalisation selon le modèle officiel : nature de l'action, dates, heures réalisées (issues des périodes clôturées), signature du responsable.",
    scope: "enrollment",
    activity: "both",
    visibility: "administratif",
    questions: [
      {
        key: "actionNature",
        label: "Nature de l'action",
        kind: "choice",
        required: true,
        options: [
          { value: "Action de formation", label: "Action de formation" },
          { value: "Bilan de compétences", label: "Bilan de compétences" },
          { value: "Action de validation des acquis de l'expérience", label: "Action de VAE" },
          { value: "Action de formation par apprentissage", label: "Action de formation par apprentissage" },
        ],
      },
    ],
    body: `# Certificat de réalisation

Je soussigné(e) **{{org.signatoryName}}**, {{org.signatoryTitle}}, représentant légal du dispensateur de l'action :

**{{org.legalName}}**
{{org.address}}
SIRET : {{org.siret}}
Numéro de déclaration d'activité : {{org.nda}}

atteste que {{enrollment.person.civility}} **{{enrollment.person.fullName}}**{{#if company.name}}, salarié(e) de {{company.name}} (SIRET {{company.siret}}){{/if}}, a suivi l'action suivante :

- Nature de l'action concourant au développement des compétences (article L.6313-1 du Code du travail) : **{{answers.actionNature}}**
- Intitulé : {{programVersion.title}}
- Référence : {{enrollment.reference}}{{#if funding.agreementRef}} ; prise en charge n° {{funding.agreementRef}}{{/if}}
- Période de réalisation : du **{{enrollment.startDate}}** au **{{enrollment.endDate}}**
- Durée réalisée : **{{enrollment.hoursDone}} heures**{{#if enrollment.hoursJustified}} (dont absences justifiées non comptées : {{enrollment.hoursJustified}} heures){{/if}}
- Modalité : {{programVersion.modalityLabel}}

Les heures réalisées sont établies à partir des feuilles d'émargement par période, clôturées et conservées par l'organisme ; les pièces justificatives sont tenues à disposition du financeur.

Fait à {{org.city}}, le {{document.date}}.

{{org.signatoryName}}, {{org.signatoryTitle}}
Signature et cachet :

***

Mentions : le présent certificat est établi conformément au modèle de certificat de réalisation diffusé par le ministère chargé du Travail. Toute fausse déclaration expose son auteur aux sanctions prévues par la loi.`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "feuille_emargement",
    category: "feuille_emargement",
    title: "Feuille d'émargement vierge (session)",
    description: "Feuille d'émargement papier par séance et par période (matin, après-midi), listant les apprenants inscrits à la session. Les signatures papier ne remplacent pas l'émargement numérique.",
    scope: "session",
    activity: "both",
    visibility: "pedagogie",
    questions: [],
    body: `# Feuille d'émargement

Organisme : **{{org.legalName}}** (NDA {{org.nda}})
Formation : **{{programVersion.title}}**
Session : {{session.title}} ({{session.code}}), du {{session.startDate}} au {{session.endDate}}
Lieu : {{session.site.name}}, {{session.site.address}}
Formateur(s) : {{session.trainers}}

Date de la séance : ______________________

Période du matin ({{session.scheduleMorning}}) et période de l'après-midi ({{session.scheduleAfternoon}}) : chaque période est émargée séparément. La pause méridienne n'est jamais comptée.

## Apprenants inscrits ({{session.learnerCount}})

Pour chaque apprenant : signature du matin, signature de l'après-midi.

{{session.learnerList}}

## Formateur

Nom : {{session.trainers}}
Signature de fin de période du matin : ______________________
Signature de fin de période de l'après-midi : ______________________

Observations (retards, départs anticipés, absences justifiées) :

__________________________________________________________________________

__________________________________________________________________________

***

Cette feuille papier constitue une pièce de secours. Les présences sont saisies et clôturées dans l'application par période ; seules les périodes clôturées produisent des heures validées.`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "attestation_assiduite",
    category: "attestation",
    title: "Attestation d'assiduité",
    description: "Attestation des heures de présence constatées (périodes clôturées) et des absences, pour le financeur ou l'employeur.",
    scope: "enrollment",
    activity: "both",
    visibility: "administratif",
    questions: [],
    body: `# Attestation d'assiduité

Je soussigné(e) **{{org.signatoryName}}**, {{org.signatoryTitle}} de **{{org.legalName}}** (SIRET {{org.siret}}, NDA {{org.nda}}), atteste que :

{{enrollment.person.civility}} **{{enrollment.person.fullName}}**{{#if company.name}}, salarié(e) de {{company.name}}{{/if}},

inscrit(e) à la formation **{{programVersion.title}}** (session {{session.title}}, référence {{enrollment.reference}}) du {{enrollment.startDate}} au {{enrollment.endDate}}, a été présent(e) selon le décompte suivant, établi à partir des périodes d'émargement clôturées :

- Heures prévues au parcours : {{enrollment.hoursPlanned}} heures
- **Heures effectuées : {{enrollment.hoursDone}} heures**
- Heures d'absence justifiées : {{enrollment.hoursJustified}} heures
- Heures d'absence non justifiées : {{enrollment.absenceHours}} heures

Les heures effectuées, justifiées et prévues sont décomptées séparément et ne sont jamais additionnées entre elles. Les feuilles d'émargement par période sont conservées par l'organisme et tenues à disposition.

Fait à {{org.city}}, le {{document.date}}, pour servir et valoir ce que de droit.

{{org.signatoryName}}, {{org.signatoryTitle}}
Signature et cachet :`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "livret_accueil",
    category: "livret",
    title: "Livret d'accueil du stagiaire",
    description: "Présentation de l'organisme, du déroulement de la formation, des interlocuteurs, des règles de vie et de l'accessibilité.",
    scope: "enrollment",
    activity: "both",
    visibility: "apprenant",
    questions: [{ key: "emergencyContact", label: "Contact de l'organisme en cas d'urgence", kind: "text", help: "Nom et téléphone joignables pendant la formation.", required: true }],
    body: `# Livret d'accueil

Bienvenue, {{enrollment.person.firstName}}.

Ce livret vous accompagne tout au long de votre formation **{{programVersion.title}}** (session {{session.title}}, du {{enrollment.startDate}} au {{enrollment.endDate}}).

## L'organisme

**{{org.legalName}}**{{#if org.tradeName}} ({{org.tradeName}}){{/if}}, {{org.kindLabel}}
{{org.address}}
Téléphone : {{org.phone}} ; e-mail : {{org.email}}{{#if org.website}} ; site : {{org.website}}{{/if}}
Déclaration d'activité n° {{org.nda}}{{#if org.qualiopiNumber}} ; certification Qualiopi n° {{org.qualiopiNumber}}{{/if}}.

## Vos interlocuteurs

- Formateur(s) : {{session.trainers}}
- Direction : {{org.signatoryName}}, {{org.signatoryTitle}}
- Urgence pendant la formation : {{answers.emergencyContact}}

## Le lieu de formation

{{session.site.name}}, {{session.site.address}}
{{#if session.site.accessibilityNote}}Accessibilité du site : {{session.site.accessibilityNote}}{{/if}}
Horaires habituels : {{session.scheduleMorning}} et {{session.scheduleAfternoon}}.

## Déroulement de la formation

Objectifs : {{programVersion.objectives}}
Méthodes : {{programVersion.methods}}
Évaluation des acquis : {{programVersion.evaluationMethods}}
Durée prévue de votre parcours : {{enrollment.hoursPlanned}} heures.

À chaque période (matin et après-midi), vous émargez dans l'application ou sur la tablette mise à disposition. Seules les périodes clôturées par le formateur produisent des heures validées.

## Règles de vie

Le règlement intérieur vous a été remis. En résumé : ponctualité, respect des personnes et du matériel, signalement immédiat de toute absence, interdiction de fumer ou de vapoter dans les locaux.

## Accessibilité et handicap

{{programVersion.accessibility}}
Si vous avez besoin d'un aménagement, signalez-le dès que possible à votre interlocuteur : un référent handicap étudiera avec vous les solutions possibles.

## Satisfaction et réclamations

Votre avis compte : un questionnaire de satisfaction vous sera adressé en fin de formation. Toute réclamation peut être adressée à {{org.email}} ; elle est enregistrée et traitée par l'organisme.

Édité le {{document.date}}.`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "convention_stage",
    category: "convention",
    title: "Convention de stage",
    description: "Convention tripartite de stage entre l'organisme de formation, l'organisme d'accueil et le stagiaire (articles L.124-1 et suivants du Code de l'éducation).",
    scope: "enrollment",
    activity: "both",
    visibility: "administratif",
    questions: [
      { key: "missionDescription", label: "Activités confiées au stagiaire", kind: "textarea", required: true },
      { key: "weeklyHours", label: "Durée hebdomadaire de présence", kind: "text", help: "Ex. : 35 heures", required: true },
      { key: "gratification", label: "Gratification", kind: "text", help: "Montant horaire ou mensuel, ou « sans gratification » si la durée le permet.", required: true },
      { key: "signaturePlace", label: "Lieu de signature", kind: "text", required: true },
    ],
    body: `# Convention de stage

Convention établie en application des articles L.124-1 et suivants du Code de l'éducation.
Référence : {{enrollment.reference}}

## Entre

${ORG_BLOCK}

Ci-après « l'organisme de formation »,

**L'organisme d'accueil**
**{{company.name}}**
{{company.address}}
SIRET : {{company.siret}}
Représenté par {{company.signatory.fullName}}, {{company.signatory.jobTitle}}
Tuteur de stage : {{enrollment.tutor.fullName}}, {{enrollment.tutor.jobTitle}} ({{enrollment.tutor.email}})

**et le stagiaire**
{{enrollment.person.civility}} **{{enrollment.person.fullName}}**, né(e) le {{enrollment.person.birthDate}}
Demeurant {{enrollment.person.address}}

## Article 1 : Objet et finalité du stage

Le stage s'inscrit dans le cadre de la formation **{{programVersion.title}}** (session {{session.title}}). Il a pour finalité de permettre au stagiaire de mettre en pratique les acquis de sa formation. Activités confiées : {{answers.missionDescription}}

## Article 2 : Dates et durée

Du {{enrollment.startDate}} au {{enrollment.endDate}}. Durée hebdomadaire de présence : {{answers.weeklyHours}}. Le stagiaire est soumis aux règles de l'organisme d'accueil en matière d'horaires, d'hygiène et de sécurité.

## Article 3 : Gratification

{{answers.gratification}}

## Article 4 : Encadrement et suivi

Le stagiaire est suivi par le tuteur désigné par l'organisme d'accueil et par un référent pédagogique de l'organisme de formation. Un bilan intermédiaire et un bilan final sont réalisés ; une attestation de stage est délivrée par l'organisme d'accueil à l'issue du stage.

## Article 5 : Protection sociale et responsabilité civile

Le stagiaire conserve son régime de protection sociale. L'organisme d'accueil et l'organisme de formation attestent chacun être couverts par une assurance de responsabilité civile pour les dommages causés ou subis par le stagiaire dans le cadre du stage.

## Article 6 : Absences, interruption et confidentialité

Toute absence est signalée aux deux organismes. La convention peut être interrompue d'un commun accord ou en cas de manquement grave, après échange entre les parties. Le stagiaire est tenu à une obligation de confidentialité sur les informations de l'organisme d'accueil.

***

Fait en trois exemplaires à {{answers.signaturePlace}}, le {{document.date}}.

${SIGNATURE_ORG}

**Pour l'organisme d'accueil**
{{company.signatory.fullName}}, {{company.signatory.jobTitle}}
Signature et cachet :

**Le stagiaire**
{{enrollment.person.fullName}}
Signature :`,
  },

  /* ------------------------------------------------------------------ */
  {
    code: "cerfa_apprentissage_recap",
    category: "cerfa",
    title: "Contrat d'apprentissage : fiche récapitulative des champs CERFA",
    description: "Fiche de préparation du formulaire officiel du contrat d'apprentissage (CERFA FA 13) : reprend les champs connus du dossier pour saisie ou vérification. Ne remplace pas le formulaire officiel.",
    scope: "enrollment",
    activity: "cfa",
    visibility: "administratif",
    questions: [
      { key: "apprenticeshipMaster", label: "Maître d'apprentissage (nom, prénom, date de naissance)", kind: "text", required: true },
      { key: "contractStart", label: "Date de début d'exécution du contrat", kind: "date", required: true },
      { key: "contractEnd", label: "Date de fin du contrat", kind: "date", required: true },
      { key: "weeklyHoursCompany", label: "Durée hebdomadaire de travail", kind: "text", help: "Ex. : 35 heures", required: true },
      { key: "salaryPercent", label: "Rémunération (pourcentage du SMIC ou du SMC)", kind: "text", required: true },
    ],
    body: `# Contrat d'apprentissage : fiche récapitulative CERFA

Document de préparation interne : il reprend les données connues du dossier pour renseigner ou vérifier le formulaire officiel du contrat d'apprentissage (CERFA FA 13 et sa notice). Il ne constitue pas le contrat, qui relève des articles L.6221-1 et suivants du Code du travail et doit être établi sur le formulaire officiel puis transmis à l'opérateur de compétences.

Référence du dossier : {{enrollment.reference}}

## L'employeur

- Raison sociale : {{company.name}}
- SIRET de l'établissement d'exécution du contrat : {{company.siret}}
- Adresse : {{company.address}}
- Téléphone : {{company.phone}} ; e-mail : {{company.email}}
- Code IDCC de la convention collective applicable : {{company.idcc}}
- OPCO : {{company.opco}}
- Signataire : {{company.signatory.fullName}}, {{company.signatory.jobTitle}}

## L'apprenti

- Nom et prénom : {{enrollment.person.lastName}} {{enrollment.person.firstName}}
- Date et lieu de naissance : {{enrollment.person.birthDate}}, {{enrollment.person.birthPlace}}
- Adresse : {{enrollment.person.address}}
- E-mail : {{enrollment.person.email}} ; téléphone : {{enrollment.person.phone}}
- Dernier diplôme ou niveau de formation : {{enrollment.person.educationLevel}}

## Le maître d'apprentissage

{{answers.apprenticeshipMaster}}

## Le contrat

- Date de début d'exécution : {{answers.contractStart}}
- Date de fin : {{answers.contractEnd}}
- Durée hebdomadaire de travail : {{answers.weeklyHoursCompany}}
- Rémunération : {{answers.salaryPercent}}

## La formation

- Organisme de formation (CFA) : {{org.legalName}}, SIRET {{org.siret}}, NDA {{org.nda}}{{#if org.uaiCode}}, UAI {{org.uaiCode}}{{/if}}
- Adresse du CFA : {{org.address}}
- Diplôme ou titre visé : {{programVersion.certification}}
- Intitulé précis : {{programVersion.title}}
- Session : {{session.title}}, du {{session.startDate}} au {{session.endDate}}
- Durée de la formation : {{programVersion.durationHours}} heures{{#if programVersion.companyHours}} (dont {{programVersion.companyHours}} heures en entreprise){{/if}}
- Lieu de formation : {{session.site.name}}, {{session.site.address}}

## Points à vérifier avant transmission

- Visite d'information et de prévention (médecine du travail) planifiée.
- Pièces d'identité et justificatifs du niveau de formation reçus (pièces attendues du dossier).
- Convention de formation annexée et signée par les parties.
- Dépôt auprès de l'opérateur de compétences dans les délais réglementaires.

Édité le {{document.date}} par {{org.legalName}}.`,
  },
];

export const PLATFORM_TEMPLATE_CODES = PLATFORM_TEMPLATES.map((t) => t.code);
