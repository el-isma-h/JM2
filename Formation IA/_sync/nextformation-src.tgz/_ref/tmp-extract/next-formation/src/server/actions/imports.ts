"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { checkUpload } from "@/server/documents/upload-rules";
import { autoMap, IMPORT_KINDS, isImportKind, type ImportKind } from "@/server/imports/kinds";
import { applyImport, applyMapping, parseImportFile, validateImport, type RowDuplicate, type RowError } from "@/server/imports/service";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

function base(orgId: string) {
  return `/app/${orgId}/imports`;
}

async function loadImport(ctx: OrgContext, id: string) {
  const [row] = await db.select().from(schema.dataImports).where(and(eq(schema.dataImports.id, id), eq(schema.dataImports.orgId, ctx.org.id))).limit(1);
  if (!row) throw new Error("Import introuvable.");
  if (!isImportKind(row.kind)) throw new Error("Type d'import inconnu.");
  return row as typeof row & { kind: ImportKind };
}

/** Étape 1 : dépôt du fichier, lecture, aperçu et association automatique des colonnes. */
export async function uploadImportAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const kind = String(formData.get("kind") ?? "");
    if (!isImportKind(kind)) return { error: "Choisissez le type de données à importer." };
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const file = formData.get("file");
    if (!(file instanceof File) || !file.size) return { error: "Choisissez un fichier CSV ou Excel." };
    const buf = Buffer.from(await file.arrayBuffer());
    const ext = (file.name.split(".").pop() ?? "").toLowerCase();
    if (!["csv", "txt", "xlsx", "xls"].includes(ext)) return { error: "Format accepté : CSV (.csv) ou Excel (.xlsx)." };
    if (ext === "csv" || ext === "txt") {
      const check = checkUpload({ name: file.name, type: file.type, size: file.size, head: buf.subarray(0, 8) });
      if (!check.ok) return { error: check.error };
    }
    const parsed = await parseImportFile(file.name, buf);
    if (!parsed.ok) return { error: parsed.error };
    if (!parsed.file.rows.length) return { error: "Le fichier ne contient aucune ligne de données." };
    const mapping = autoMap(kind, parsed.file.headers);
    const [row] = await db
      .insert(schema.dataImports)
      .values({
        orgId,
        kind,
        fileName: file.name,
        status: "uploaded",
        preview: { headers: parsed.file.headers, sample: parsed.file.rows.slice(0, 5), total: parsed.file.rows.length, truncated: parsed.file.truncated },
        mapping,
        rows: parsed.file.rows,
        createdBy: ctx.user.id,
      })
      .returning({ id: schema.dataImports.id });
    await audit({ action: "import.upload", userId: ctx.user.id, orgId, entityType: "data_import", entityId: row.id, after: { kind, fileName: file.name, rows: parsed.file.rows.length } });
    revalidatePath(base(orgId));
    return { ok: true, message: `${parsed.file.rows.length} ligne(s) lue(s)${parsed.file.truncated ? " (fichier tronqué à 5 000 lignes)" : ""}. Vérifiez l'association des colonnes.`, data: { redirect: `${base(orgId)}/${row.id}` } };
  } catch (e) {
    return fail(e, "Lecture du fichier impossible.");
  }
}

/** Étape 2 : association des colonnes (mapping) puis validation ligne par ligne. */
export async function mapImportAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const importId = uuid.parse(formData.get("importId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const imp = await loadImport(ctx, importId);
    if (imp.status === "applied") return { error: "Import déjà appliqué." };
    const def = IMPORT_KINDS[imp.kind];
    const headers = ((imp.preview as { headers?: string[] }).headers ?? []) as string[];
    const mapping: Record<string, string> = {};
    for (const f of def.fields) {
      const col = String(formData.get(`map_${f.key}`) ?? "").trim();
      if (col) {
        if (!headers.includes(col)) return { error: `Colonne « ${col} » absente du fichier.` };
        mapping[f.key] = col;
      }
    }
    const missing = def.fields.filter((f) => f.required && !mapping[f.key]);
    if (missing.length) return { error: `Associez les colonnes obligatoires : ${missing.map((f) => f.label).join(", ")}.` };
    const rows = applyMapping(imp.kind, imp.rows as Record<string, string>[], mapping);
    const result = await validateImport(orgId, imp.kind, rows);
    await db.update(schema.dataImports).set({ mapping, status: "validated", errors: result.errors, duplicates: result.duplicates }).where(eq(schema.dataImports.id, imp.id));
    await audit({ action: "import.validate", userId: ctx.user.id, orgId, entityType: "data_import", entityId: imp.id, after: { errors: result.errors.length, duplicates: result.duplicates.length, valid: result.validCount } });
    revalidatePath(`${base(orgId)}/${imp.id}`);
    return { ok: true, message: `Validation terminée : ${result.validCount} ligne(s) prête(s), ${result.errors.length} erreur(s), ${result.duplicates.length} doublon(s) détecté(s).` };
  } catch (e) {
    return fail(e, "Validation impossible.");
  }
}

/** Étape 3 : application des lignes valides uniquement (doublons et erreurs ignorés, listés). */
export async function applyImportAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const importId = uuid.parse(formData.get("importId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const imp = await loadImport(ctx, importId);
    if (imp.status !== "validated") return { error: "Validez d'abord l'import (association des colonnes)." };
    if (formData.get("understood") !== "on") return { error: "Cochez la case de confirmation." };
    const rows = applyMapping(imp.kind, imp.rows as Record<string, string>[], imp.mapping as Record<string, string>);
    // Revalidation juste avant application : l'état de la base a pu changer depuis.
    const check = await validateImport(orgId, imp.kind, rows);
    const skip = new Set<number>([...check.errors.map((e: RowError) => e.row), ...check.duplicates.map((d: RowDuplicate) => d.row)]);
    const res = await applyImport(ctx, imp.kind, rows, skip);
    await db.update(schema.dataImports).set({ status: res.failures.length && !res.applied ? "failed" : "applied", appliedCount: res.applied, appliedAt: new Date(), errors: [...check.errors, ...res.failures], duplicates: check.duplicates }).where(eq(schema.dataImports.id, imp.id));
    await audit({ action: "import.apply", userId: ctx.user.id, orgId, entityType: "data_import", entityId: imp.id, after: { kind: imp.kind, applied: res.applied, skipped: res.skipped, failures: res.failures.length } });
    revalidatePath(`${base(orgId)}/${imp.id}`);
    revalidatePath(base(orgId));
    for (const p of ["entreprises", "contacts", "apprenants", "inscriptions", "candidats"]) revalidatePath(`/app/${orgId}/${p}`);
    return { ok: true, message: `${res.applied} ligne(s) appliquée(s), ${res.skipped} ignorée(s) (erreurs ou doublons)${res.failures.length ? `, ${res.failures.length} échec(s) à l'application` : ""}.` };
  } catch (e) {
    return fail(e, "Application impossible.");
  }
}

export async function deleteImportAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const importId = uuid.parse(formData.get("importId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const imp = await loadImport(ctx, importId);
    if (imp.status === "applied") return { error: "Un import appliqué est conservé comme trace (T03)." };
    await db.delete(schema.dataImports).where(eq(schema.dataImports.id, imp.id));
    await audit({ action: "import.delete", userId: ctx.user.id, orgId, entityType: "data_import", entityId: imp.id, before: { kind: imp.kind, fileName: imp.fileName, status: imp.status } });
    revalidatePath(base(orgId));
    return { ok: true, message: "Import abandonné.", data: { redirect: base(orgId) } };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}
