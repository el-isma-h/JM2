import "server-only";
import { and, eq, gte, inArray, isNotNull, lte, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import type { Period } from "./period";
import { DROPOUT_DEFINITION, DROPOUT_EXCLUSIONS, parseQuestions, RESPONSE_RATE_DEFINITION, RESPONSE_RATE_EXCLUSIONS, SATISFACTION_DEFINITION, SATISFACTION_EXCLUSIONS, satisfactionFromResponses, SUCCESS_DEFINITION, type SurveyAnswers } from "@/server/quality/indicator-math";

/**
 * Indicateurs à définition explicite (F15) : satisfaction, retour d'enquêtes, abandon, réussite.
 * Chaque résultat porte son numérateur, son dénominateur, ses exclusions et sa définition en clair :
 * un pourcentage sans dénominateur n'est pas un résultat.
 */
export type DefinedIndicator = {
  key: "satisfaction" | "retour_enquetes" | "abandon" | "reussite";
  label: string;
  definition: string;
  numeratorLabel: string;
  denominatorLabel: string;
  exclusions: string;
  numerator: number;
  denominator: number;
  /** Valeur en pourcentage (0 à 100), null si dénominateur nul. */
  value: number | null;
  unit: "%";
  href: string;
};

function pct(n: number, d: number): number | null {
  return d > 0 ? Math.round((n / d) * 1000) / 10 : null;
}

export async function definedIndicators(orgId: string, period: Period): Promise<DefinedIndicator[]> {
  const base = `/app/${orgId}`;
  const from = new Date(`${period.from}T00:00:00Z`);
  const to = new Date(`${period.to}T23:59:59Z`);

  // Satisfaction : mêmes règles que le module qualité (question globale ≥ 4/5), réponses soumises dans la période.
  const satRows = await db
    .select({ answers: schema.surveyResponses.answers, questions: schema.surveys.questions })
    .from(schema.surveyResponses)
    .innerJoin(schema.surveys, eq(schema.surveys.id, schema.surveyResponses.surveyId))
    .where(and(eq(schema.surveyResponses.orgId, orgId), inArray(schema.surveys.kind, ["satisfaction_chaud", "satisfaction_froid", "employeur", "formateur", "financeur"]), isNotNull(schema.surveyResponses.submittedAt), gte(schema.surveyResponses.submittedAt, from), lte(schema.surveyResponses.submittedAt, to)));
  const sat = satisfactionFromResponses(satRows.map((r) => ({ answers: (r.answers ?? {}) as SurveyAnswers, questions: parseQuestions(r.questions) })), new Date().toISOString());

  // Retour d'enquêtes : réponses soumises / questionnaires envoyés dans la période (toutes enquêtes), hors brouillons jamais envoyés.
  const [ret] = await db
    .select({ n: sql<number>`count(*) filter (where ${schema.surveyResponses.submittedAt} is not null)::int`, d: sql<number>`count(*)::int` })
    .from(schema.surveyResponses)
    .where(and(eq(schema.surveyResponses.orgId, orgId), isNotNull(schema.surveyResponses.sentAt), gte(schema.surveyResponses.sentAt, from), lte(schema.surveyResponses.sentAt, to)));

  // Abandon : inscriptions passées en abandon (date de sortie dans la période) / inscriptions ayant démarré (statut en cours, terminé ou abandon) dont le début est antérieur à la fin de période ; exclusions : préinscrits, annulés avant démarrage, reportés.
  const [ab] = await db
    .select({
      n: sql<number>`count(*) filter (where ${schema.enrollments.status} = 'abandon' and coalesce(${schema.enrollments.exitDate}, ${schema.enrollments.endDate}) between ${period.from} and ${period.to})::int`,
      d: sql<number>`count(*) filter (where ${schema.enrollments.status} in ('en_cours','termine','abandon') and coalesce(${schema.enrollments.startDate}, ${period.from}) <= ${period.to})::int`,
    })
    .from(schema.enrollments)
    .where(eq(schema.enrollments.orgId, orgId));

  // Réussite : membres de cohortes d'examen présents avec résultat « admis » / présents avec un résultat enregistré, cohortes datées dans la période ; exclusions : absents, désistés, sans résultat.
  const [su] = await db
    .select({
      n: sql<number>`count(*) filter (where ${schema.examMembers.result} = 'admis')::int`,
      d: sql<number>`count(*) filter (where ${schema.examMembers.result} in ('admis','ajourne','partiel','rattrapage'))::int`,
    })
    .from(schema.examMembers)
    .innerJoin(schema.examCohorts, eq(schema.examCohorts.id, schema.examMembers.cohortId))
    .where(and(eq(schema.examMembers.orgId, orgId), inArray(schema.examMembers.status, ["present", "convoque", "inscrit"]), gte(schema.examCohorts.date, period.from), lte(schema.examCohorts.date, period.to)));

  return [
    {
      key: "satisfaction",
      label: "Satisfaction",
      definition: SATISFACTION_DEFINITION,
      numeratorLabel: "réponses ≥ 4/5 (ou ≥ 8/10) à la question globale",
      denominatorLabel: "répondants ayant renseigné la question globale, réponses soumises dans la période (enquêtes satisfaction, employeur, formateur, financeur)",
      exclusions: SATISFACTION_EXCLUSIONS,
      numerator: sat.numerator,
      denominator: sat.denominator,
      value: sat.value,
      unit: "%",
      href: `${base}/enquetes?from=${period.from}&to=${period.to}`,
    },
    {
      key: "retour_enquetes",
      label: "Retour d'enquêtes",
      definition: RESPONSE_RATE_DEFINITION,
      numeratorLabel: "questionnaires avec réponse soumise",
      denominatorLabel: "questionnaires envoyés dans la période (toutes enquêtes)",
      exclusions: RESPONSE_RATE_EXCLUSIONS,
      numerator: ret?.n ?? 0,
      denominator: ret?.d ?? 0,
      value: pct(ret?.n ?? 0, ret?.d ?? 0),
      unit: "%",
      href: `${base}/enquetes?from=${period.from}&to=${period.to}`,
    },
    {
      key: "abandon",
      label: "Abandon",
      definition: `${DROPOUT_DEFINITION} Ici : abandons dont la date de sortie tombe dans la période, rapportés aux inscriptions entrées en formation avant la fin de période.`,
      numeratorLabel: "inscriptions en abandon (sortie dans la période)",
      denominatorLabel: "inscriptions ayant démarré (en cours, terminées ou en abandon) avant la fin de période",
      exclusions: DROPOUT_EXCLUSIONS,
      numerator: ab?.n ?? 0,
      denominator: ab?.d ?? 0,
      value: pct(ab?.n ?? 0, ab?.d ?? 0),
      unit: "%",
      href: `${base}/inscriptions?status=abandon&from=${period.from}&to=${period.to}`,
    },
    {
      key: "reussite",
      label: "Réussite aux examens",
      definition: `${SUCCESS_DEFINITION} Ici : membres des cohortes d'examen datées dans la période.`,
      numeratorLabel: "membres admis",
      denominatorLabel: "membres avec un résultat (admis, ajourné, partiel, rattrapage)",
      exclusions: "absents, désistés, membres sans résultat saisi",
      numerator: su?.n ?? 0,
      denominator: su?.d ?? 0,
      value: pct(su?.n ?? 0, su?.d ?? 0),
      unit: "%",
      href: `${base}/examens?from=${period.from}&to=${period.to}`,
    },
  ];
}
