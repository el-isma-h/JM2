/**
 * Lecture minimale d'un manifeste SCORM (imsmanifest.xml) : titre et page de lancement.
 * Module pur (testé dans __tests__/scorm.test.ts). Pas de lecteur SCORM complet : le paquet est servi tel quel
 * depuis une route protégée et le temps est enregistré de façon basique, puis validé par un humain.
 */

export type ScormManifest = { title: string | null; launch: string | null; schemaVersion: string | null };

function decodeEntities(s: string) {
  return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").trim();
}

export function parseScormManifest(xml: string): ScormManifest {
  const schemaVersion = xml.match(/<(?:\w+:)?schemaversion>\s*([^<]+)\s*<\/(?:\w+:)?schemaversion>/i)?.[1]?.trim() ?? null;
  // Titre : première organisation, sinon premier <title> rencontré.
  const orgBlock = xml.match(/<(?:\w+:)?organization\b[^>]*>([\s\S]*?)<\/(?:\w+:)?organization>/i)?.[1] ?? "";
  const title = decodeEntities(orgBlock.match(/<(?:\w+:)?title>\s*([^<]*)\s*<\/(?:\w+:)?title>/i)?.[1] ?? xml.match(/<(?:\w+:)?title>\s*([^<]*)\s*<\/(?:\w+:)?title>/i)?.[1] ?? "") || null;
  // Lancement : ressource référencée par le premier item, sinon première ressource de type webcontent avec href.
  const firstItemRef = orgBlock.match(/<(?:\w+:)?item\b[^>]*identifierref="([^"]+)"/i)?.[1];
  let launch: string | null = null;
  if (firstItemRef) {
    const res = xml.match(new RegExp(`<(?:\\w+:)?resource\\b[^>]*identifier="${firstItemRef.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}"[^>]*>`, "i"))?.[0];
    launch = res?.match(/\bhref="([^"]+)"/i)?.[1] ?? null;
  }
  if (!launch) launch = xml.match(/<(?:\w+:)?resource\b[^>]*\bhref="([^"]+)"/i)?.[1] ?? null;
  if (launch) launch = decodeEntities(launch).replace(/^\.?\//, "");
  return { title, launch, schemaVersion };
}

/** Chemin sûr à l'intérieur d'un paquet : pas de remontée, pas d'absolu. */
export function safePackagePath(parts: string[]): string | null {
  const joined = parts.join("/");
  if (!joined || joined.includes("..") || joined.startsWith("/") || /[\0]/.test(joined)) return null;
  return joined.replace(/\/+/g, "/");
}

export const PACKAGE_MIME: Record<string, string> = {
  html: "text/html; charset=utf-8",
  htm: "text/html; charset=utf-8",
  js: "application/javascript; charset=utf-8",
  mjs: "application/javascript; charset=utf-8",
  css: "text/css; charset=utf-8",
  json: "application/json; charset=utf-8",
  xml: "application/xml; charset=utf-8",
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  svg: "image/svg+xml",
  webp: "image/webp",
  mp3: "audio/mpeg",
  mp4: "video/mp4",
  webm: "video/webm",
  woff: "font/woff",
  woff2: "font/woff2",
  ttf: "font/ttf",
  pdf: "application/pdf",
  txt: "text/plain; charset=utf-8",
};

export function mimeForPath(p: string): string {
  const ext = (p.split(".").pop() ?? "").toLowerCase();
  return PACKAGE_MIME[ext] ?? "application/octet-stream";
}
