"use server";

import { revalidatePath } from "next/cache";
import { and, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { isEmail } from "@/lib/validators";
import { fmtDate } from "@/lib/dates";
import { requireOrg } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { layoutMail, sendMail } from "@/server/mail";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

const pieceSchema = z.object({
  orgId: uuid,
  pieceId: z.string().uuid().optional().or(z.literal("")),
  code: z.string().trim().min(2, "Code requis").max(60).regex(/^[a-z0-9_]+$/, "Code : minuscules, chiffres et _ uniquement"),
  label: z.string().trim().min(2, "Libellé requis").max(160),
  description: z.string().trim().max(1000).optional().or(z.literal("")),
  category: z.enum(schema.documentCategoryEnum.enumValues),
  providedBy: z.enum(["apprenant", "entreprise", "organisme", "financeur"]),
  dueDaysBeforeStart: z.string().trim().optional().or(z.literal("")),
  position: z.coerce.number().int().min(0).max(1000).default(0),
});

/** Création / modification d'une pièce attendue (libellé, catégorie, fournisseur, obligatoire, déclencheurs, échéance). */
export async function savePieceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = pieceSchema.parse(Object.fromEntries(formData));
    const ctx = await requireOrg(d.orgId, "dossier.admin_docs.manage");
    const contractKinds = formData.getAll("contractKinds").map(String).filter(Boolean);
    const fundingKinds = formData.getAll("fundingKinds").map(String).filter(Boolean);
    const activity = formData.getAll("activity").map(String).filter(Boolean);
    const appliesTo = {
      contractKinds: contractKinds.length && !contractKinds.includes("*") ? contractKinds : ["*"],
      fundingKinds: fundingKinds.length && !fundingKinds.includes("*") ? fundingKinds : ["*"],
      ...(activity.length && !activity.includes("*") ? { activity } : {}),
    };
    const due = d.dueDaysBeforeStart ? Number(d.dueDaysBeforeStart) : null;
    if (due !== null && (!Number.isInteger(due) || due < 0 || due > 365)) return { error: "Échéance : nombre de jours entre 0 et 365." };
    const values = {
      code: d.code,
      label: d.label,
      description: d.description || null,
      category: d.category,
      providedBy: d.providedBy,
      isRequired: formData.get("isRequired") === "on",
      appliesTo,
      dueDaysBeforeStart: due,
      position: d.position,
      isActive: formData.get("isActive") !== "off",
    };
    if (d.pieceId) {
      const [before] = await db.select().from(schema.requiredPieces).where(and(eq(schema.requiredPieces.id, d.pieceId), eq(schema.requiredPieces.orgId, ctx.org.id))).limit(1);
      if (!before) return { error: "Pièce introuvable." };
      const [clash] = await db.select({ id: schema.requiredPieces.id }).from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, ctx.org.id), eq(schema.requiredPieces.code, d.code), sql`${schema.requiredPieces.id} <> ${before.id}`)).limit(1);
      if (clash) return { error: `Le code « ${d.code} » est déjà utilisé.` };
      await db.update(schema.requiredPieces).set(values).where(eq(schema.requiredPieces.id, before.id));
      await audit({ action: "piece.config.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "required_piece", entityId: before.id, before: { label: before.label, appliesTo: before.appliesTo, isRequired: before.isRequired }, after: values });
    } else {
      const [clash] = await db.select({ id: schema.requiredPieces.id }).from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, ctx.org.id), eq(schema.requiredPieces.code, d.code))).limit(1);
      if (clash) return { error: `Le code « ${d.code} » est déjà utilisé.` };
      const [row] = await db.insert(schema.requiredPieces).values({ orgId: ctx.org.id, ...values }).returning({ id: schema.requiredPieces.id });
      await audit({ action: "piece.config.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "required_piece", entityId: row.id, after: values });
    }
    revalidatePath(`/app/${ctx.org.id}/pieces`);
    return { ok: true, message: d.pieceId ? "Pièce attendue enregistrée. Les dossiers existants gardent leurs pièces ; utilisez « Recalculer » sur un dossier pour ajouter les nouvelles." : "Pièce attendue créée. Elle s'appliquera aux prochaines inscriptions." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function togglePieceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const pieceId = uuid.parse(formData.get("pieceId"));
    const ctx = await requireOrg(orgId, "dossier.admin_docs.manage");
    const [p] = await db.select().from(schema.requiredPieces).where(and(eq(schema.requiredPieces.id, pieceId), eq(schema.requiredPieces.orgId, orgId))).limit(1);
    if (!p) return { error: "Pièce introuvable." };
    await db.update(schema.requiredPieces).set({ isActive: !p.isActive }).where(eq(schema.requiredPieces.id, p.id));
    await audit({ action: "piece.config.toggle", userId: ctx.user.id, orgId, entityType: "required_piece", entityId: p.id, before: { isActive: p.isActive }, after: { isActive: !p.isActive } });
    revalidatePath(`/app/${orgId}/pieces`);
    return { ok: true, message: p.isActive ? "Pièce désactivée : elle ne sera plus attendue pour les nouvelles inscriptions." : "Pièce réactivée." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

/** Relance par e-mail d'une pièce manquante, à la personne ou à l'entreprise selon `providedBy`. Jamais d'envoi réel en démo. */
export async function remindPieceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const submissionId = uuid.parse(formData.get("submissionId"));
    const ctx = await requireOrg(orgId, "dossier.admin_docs.manage");
    const [row] = await db
      .select({ s: schema.pieceSubmissions, p: schema.requiredPieces, e: schema.enrollments })
      .from(schema.pieceSubmissions)
      .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
      .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.pieceSubmissions.enrollmentId))
      .where(and(eq(schema.pieceSubmissions.id, submissionId), eq(schema.pieceSubmissions.orgId, orgId), eq(schema.enrollments.orgId, orgId)))
      .limit(1);
    if (!row) return { error: "Pièce introuvable." };
    if (!["attendue", "refusee"].includes(row.s.status)) return { error: "Cette pièce n'est pas en attente." };
    const [person] = await db.select({ firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email }).from(schema.persons).where(eq(schema.persons.id, row.e.personId)).limit(1);
    let to: string | null = null;
    let recipient = "";
    if (row.p.providedBy === "entreprise") {
      if (row.e.tutorContactId) {
        const [t] = await db.select({ email: schema.contacts.email, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName }).from(schema.contacts).where(eq(schema.contacts.id, row.e.tutorContactId)).limit(1);
        if (t?.email) {
          to = t.email;
          recipient = `${t.firstName} ${t.lastName} (tuteur)`;
        }
      }
      if (!to && row.e.companyId) {
        const [c] = await db.select({ email: schema.companies.email, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.id, row.e.companyId)).limit(1);
        if (c?.email) {
          to = c.email;
          recipient = c.name;
        }
      }
      if (!to) return { error: "Aucune adresse e-mail connue pour l'entreprise ou le tuteur de ce dossier : complétez la fiche entreprise." };
    } else if (row.p.providedBy === "financeur") {
      return { error: "Les pièces attendues du financeur se relancent depuis le financement (module finance)." };
    } else {
      to = person?.email ?? null;
      recipient = `${person?.firstName ?? ""} ${person?.lastName ?? ""}`.trim();
      if (!to || !isEmail(to)) return { error: "Aucune adresse e-mail valide pour cette personne : complétez sa fiche." };
    }
    const orgName = ctx.org.tradeName ?? ctx.org.legalName;
    const due = row.s.dueDate ? ` avant le ${fmtDate(row.s.dueDate)}` : "";
    const res = await sendMail({
      to,
      subject: `${orgName} : pièce attendue (${row.p.label})`,
      html: layoutMail(
        "Pièce attendue pour votre dossier",
        `<p>Bonjour,</p><p>Pour finaliser le dossier d'inscription ${row.e.reference} de ${person?.firstName ?? ""} ${person?.lastName ?? ""}, ${orgName} attend la pièce suivante${due} :</p><p><strong>${row.p.label}</strong>${row.p.description ? `<br/>${row.p.description}` : ""}${row.s.status === "refusee" && row.s.refusalReason ? `<br/>Dépôt précédent refusé : ${row.s.refusalReason}` : ""}</p><p>Merci de la transmettre à ${orgName}${ctx.org.email ? ` (${ctx.org.email})` : ""}.</p>`,
      ),
      text: `Pièce attendue pour le dossier ${row.e.reference} : ${row.p.label}${due}.`,
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "piece.remind", userId: ctx.user.id, orgId, entityType: "piece_submission", entityId: row.s.id, after: { to, mail: res.status } });
    revalidatePath(`/app/${orgId}/pieces`);
    if (ctx.org.isDemo) return { ok: true, message: `Démonstration : relance journalisée pour ${recipient}, aucun e-mail ne part.` };
    if (res.status === "sent") return { ok: true, message: `Relance envoyée à ${recipient} (${to}).` };
    return { ok: true, message: `Service e-mail non configuré (RESEND_API_KEY) : la relance pour ${recipient} est dans la boîte d'envoi sans être partie.` };
  } catch (e) {
    return fail(e, "Relance impossible.");
  }
}
