"use server";

import { revalidatePath } from "next/cache";
import { and, eq, isNull } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { parisToInstant } from "@/lib/time";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

const eventSchema = z.object({
  title: z.string().trim().min(2, "Titre requis.").max(160),
  kind: z.enum(["rdv", "visio", "reunion", "autre"]).default("rdv"),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide."),
  start: z.string().regex(/^\d{2}:\d{2}$/, "Heure de début invalide."),
  end: z.string().regex(/^\d{2}:\d{2}$/, "Heure de fin invalide."),
  location: z.string().trim().max(200).optional(),
  notes: z.string().trim().max(2000).optional(),
});

/** Crée un événement personnel d'agenda (heure serveur Europe/Paris). */
export async function createAgendaEventAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId);
    const d = eventSchema.parse(Object.fromEntries(formData));
    if (d.end <= d.start) return { error: "L'heure de fin doit suivre l'heure de début." };
    const [row] = await db
      .insert(schema.agendaEvents)
      .values({ orgId, userId: ctx.user.id, title: d.title, kind: d.kind, startAt: parisToInstant(d.date, d.start), endAt: parisToInstant(d.date, d.end), location: d.location || null, notes: d.notes || null, createdBy: ctx.user.id })
      .returning({ id: schema.agendaEvents.id });
    await audit({ action: "agenda.event.create", userId: ctx.user.id, orgId, entityType: "agenda_event", entityId: row.id, after: { title: d.title, date: d.date } });
    revalidatePath(`/app/${orgId}/agenda`);
    return { ok: true, message: "Événement ajouté à votre agenda." };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function deleteAgendaEventAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId);
    const id = uuid.parse(formData.get("eventId"));
    const [row] = await db.select().from(schema.agendaEvents).where(and(eq(schema.agendaEvents.id, id), eq(schema.agendaEvents.orgId, orgId))).limit(1);
    if (!row) return { error: "Événement introuvable." };
    if (row.userId !== ctx.user.id && row.createdBy !== ctx.user.id) return { error: "Vous ne pouvez supprimer que vos propres événements." };
    await db.delete(schema.agendaEvents).where(eq(schema.agendaEvents.id, id));
    await audit({ action: "agenda.event.delete", userId: ctx.user.id, orgId, entityType: "agenda_event", entityId: id, before: { title: row.title, startAt: row.startAt } });
    revalidatePath(`/app/${orgId}/agenda`);
    return { ok: true, message: "Événement supprimé." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

/** Marque une notification (ou toutes) comme lue pour l'utilisateur courant. */
export async function markNotificationsReadAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId);
    const id = String(formData.get("notificationId") ?? "");
    const where = id && /^[0-9a-f-]{36}$/i.test(id) ? and(eq(schema.notifications.id, id), eq(schema.notifications.userId, ctx.user.id), eq(schema.notifications.orgId, orgId)) : and(eq(schema.notifications.userId, ctx.user.id), eq(schema.notifications.orgId, orgId), isNull(schema.notifications.readAt));
    await db.update(schema.notifications).set({ readAt: new Date() }).where(where);
    revalidatePath(`/app/${orgId}`, "layout");
    return { ok: true, message: id ? "Notification lue." : "Toutes les notifications sont lues." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}
