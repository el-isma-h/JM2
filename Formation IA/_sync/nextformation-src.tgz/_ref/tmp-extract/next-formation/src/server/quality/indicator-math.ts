/**
 * Calculs purs des indicateurs de pilotage qualité (F15) : chaque résultat porte sa définition, son numérateur,
 * son dénominateur, ses exclusions et sa date de calcul. Un objectif n'est jamais un résultat mesuré.
 */

export type IndicatorValue = {
  /** Pourcentage arrondi à une décimale ; null si le dénominateur est nul (« non calculable »). */
  value: number | null;
  numerator: number;
  denominator: number;
  definition: string;
  exclusions: string;
  computedAt: string;
  /** Périmètre et période lisibles (origine du calcul). */
  scope?: string;
};

export function rate(numerator: number, denominator: number): number | null {
  if (denominator <= 0) return null;
  return Math.round((numerator / denominator) * 1000) / 10;
}

export type SurveyQuestion = {
  key: string;
  label: string;
  type: "scale" | "text" | "choice" | "yesno";
  /** Échelle : valeur maximale (5 ou 10). */
  max?: number;
  options?: string[];
  required?: boolean;
  /** Rôle dans un indicateur : "satisfaction" (question globale), "recommandation"… */
  indicator?: string;
};

export type SurveyAnswers = Record<string, string | number | null | undefined>;

/** Seuil de satisfaction : réponse ≥ 80 % de l'échelle (4/5 ou 8/10). */
export function isSatisfied(value: number, max: number): boolean {
  return value >= Math.ceil(max * 0.8);
}

export const SATISFACTION_DEFINITION = "Taux de satisfaction = réponses ≥ 4/5 (ou ≥ 8/10) à la question globale de satisfaction / répondants ayant renseigné cette question.";
export const SATISFACTION_EXCLUSIONS = "Réponses incomplètes (question globale non renseignée), réponses non soumises, enquêtes sans question globale.";

/** Satisfaction à partir des réponses soumises d'une ou plusieurs enquêtes. */
export function satisfactionFromResponses(responses: { answers: SurveyAnswers; questions: SurveyQuestion[] }[], computedAt: string): IndicatorValue {
  let numerator = 0;
  let denominator = 0;
  for (const r of responses) {
    const q = r.questions.find((x) => x.indicator === "satisfaction" && x.type === "scale");
    if (!q) continue;
    const raw = r.answers[q.key];
    const v = typeof raw === "number" ? raw : raw != null && raw !== "" ? Number(raw) : NaN;
    if (!Number.isFinite(v)) continue; // réponse incomplète : exclue du dénominateur
    denominator++;
    if (isSatisfied(v, q.max ?? 5)) numerator++;
  }
  return { value: rate(numerator, denominator), numerator, denominator, definition: SATISFACTION_DEFINITION, exclusions: SATISFACTION_EXCLUSIONS, computedAt };
}

export const RESPONSE_RATE_DEFINITION = "Taux de retour = questionnaires soumis / questionnaires envoyés (un jeton individuel par destinataire).";
export const RESPONSE_RATE_EXCLUSIONS = "Destinataires sans envoi effectif (pas de jeton émis), enquêtes en brouillon.";

export function responseRateFrom(sent: number, submitted: number, computedAt: string): IndicatorValue {
  return { value: rate(submitted, sent), numerator: submitted, denominator: sent, definition: RESPONSE_RATE_DEFINITION, exclusions: RESPONSE_RATE_EXCLUSIONS, computedAt };
}

export type EnrollmentForRates = { status: string; examState: string };

export const DROPOUT_DEFINITION = "Taux d'abandon = inscriptions au statut « abandon » / inscriptions entrées en formation (inscrit, en cours, terminé, abandon).";
export const DROPOUT_EXCLUSIONS = "Préinscriptions, inscriptions annulées ou reportées (jamais entrées en formation).";

export function dropoutFrom(enrollments: EnrollmentForRates[], computedAt: string): IndicatorValue {
  const entered = enrollments.filter((e) => ["inscrit", "en_cours", "termine", "abandon"].includes(e.status));
  const dropped = entered.filter((e) => e.status === "abandon");
  return { value: rate(dropped.length, entered.length), numerator: dropped.length, denominator: entered.length, definition: DROPOUT_DEFINITION, exclusions: DROPOUT_EXCLUSIONS, computedAt };
}

export const SUCCESS_DEFINITION = "Taux de réussite = inscriptions avec résultat « admis » / inscriptions présentées à l'examen (admis, ajourné, absent à l'épreuve, rattrapage).";
export const SUCCESS_EXCLUSIONS = "Inscriptions non concernées par un examen, à inscrire ou inscrites sans résultat enregistré ; inscriptions annulées.";

export function successFrom(enrollments: EnrollmentForRates[], computedAt: string): IndicatorValue {
  const presented = enrollments.filter((e) => e.status !== "annule" && ["admis", "ajourne", "absent", "rattrapage"].includes(e.examState));
  const admitted = presented.filter((e) => e.examState === "admis");
  return { value: rate(admitted.length, presented.length), numerator: admitted.length, denominator: presented.length, definition: SUCCESS_DEFINITION, exclusions: SUCCESS_EXCLUSIONS, computedAt };
}

/** Score global d'une réponse (0 à 100) : moyenne des échelles renseignées, null si aucune. */
export function responseScore(answers: SurveyAnswers, questions: SurveyQuestion[]): number | null {
  const vals: number[] = [];
  for (const q of questions) {
    if (q.type !== "scale") continue;
    const raw = answers[q.key];
    const v = typeof raw === "number" ? raw : raw != null && raw !== "" ? Number(raw) : NaN;
    if (!Number.isFinite(v)) continue;
    vals.push((v / (q.max ?? 5)) * 100);
  }
  if (!vals.length) return null;
  return Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
}

/** Agrégation par question : effectif, moyenne (échelles), répartition (choix / oui-non). */
export function aggregateAnswers(responses: SurveyAnswers[], questions: SurveyQuestion[]) {
  return questions.map((q) => {
    const raw = responses.map((r) => r[q.key]).filter((v) => v != null && v !== "");
    if (q.type === "scale") {
      const nums = raw.map(Number).filter((n) => Number.isFinite(n));
      const mean = nums.length ? Math.round((nums.reduce((a, b) => a + b, 0) / nums.length) * 10) / 10 : null;
      const dist: Record<string, number> = {};
      for (const n of nums) dist[String(n)] = (dist[String(n)] ?? 0) + 1;
      return { question: q, n: nums.length, mean, distribution: dist, texts: [] as string[] };
    }
    if (q.type === "text") return { question: q, n: raw.length, mean: null, distribution: {} as Record<string, number>, texts: raw.map(String) };
    const dist: Record<string, number> = {};
    for (const v of raw) dist[String(v)] = (dist[String(v)] ?? 0) + 1;
    return { question: q, n: raw.length, mean: null, distribution: dist, texts: [] as string[] };
  });
}

/** Validation d'une soumission : questions obligatoires renseignées, échelles dans les bornes. Retourne les réponses normalisées. */
export function validateSubmission(questions: SurveyQuestion[], raw: Record<string, string>): { ok: true; answers: SurveyAnswers } | { ok: false; error: string } {
  const answers: SurveyAnswers = {};
  for (const q of questions) {
    const v = (raw[q.key] ?? "").trim();
    if (!v) {
      if (q.required) return { ok: false, error: `La question « ${q.label} » est obligatoire.` };
      answers[q.key] = null;
      continue;
    }
    if (q.type === "scale") {
      const n = Number(v);
      const max = q.max ?? 5;
      if (!Number.isInteger(n) || n < 1 || n > max) return { ok: false, error: `Réponse invalide pour « ${q.label} » (de 1 à ${max}).` };
      answers[q.key] = n;
    } else if (q.type === "yesno") {
      if (v !== "oui" && v !== "non") return { ok: false, error: `Réponse invalide pour « ${q.label} ».` };
      answers[q.key] = v;
    } else if (q.type === "choice") {
      if (!(q.options ?? []).includes(v)) return { ok: false, error: `Réponse invalide pour « ${q.label} ».` };
      answers[q.key] = v;
    } else {
      answers[q.key] = v.slice(0, 4000);
    }
  }
  return { ok: true, answers };
}

/** Lecture tolérante des questions stockées en JSON. */
export function parseQuestions(raw: unknown): SurveyQuestion[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((q) => {
      const o = (q ?? {}) as Partial<SurveyQuestion>;
      const type = (["scale", "text", "choice", "yesno"].includes(String(o.type)) ? o.type : "text") as SurveyQuestion["type"];
      return {
        key: String(o.key ?? ""),
        label: String(o.label ?? ""),
        type,
        max: type === "scale" ? (o.max === 10 ? 10 : 5) : undefined,
        options: Array.isArray(o.options) ? o.options.map(String) : undefined,
        required: Boolean(o.required),
        indicator: o.indicator ? String(o.indicator) : undefined,
      };
    })
    .filter((q) => q.key && q.label);
}
