import "server-only";
import { and, desc, eq, inArray, isNotNull, isNull, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";

/** Membres actifs de l'organisme (responsables affectables). */
export async function orgMembers(orgId: string) {
  const rows = await db
    .select({ userId: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, roles: schema.memberships.roles })
    .from(schema.memberships)
    .innerJoin(schema.users, eq(schema.users.id, schema.memberships.userId))
    .where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.active, true), isNull(schema.users.disabledAt)))
    .orderBy(schema.users.lastName, schema.users.firstName);
  return rows.map((r) => ({ ...r, name: `${r.firstName} ${r.lastName}`, roles: (Array.isArray(r.roles) ? r.roles : []) as string[] }));
}

export async function memberNames(orgId: string): Promise<Map<string, string>> {
  return new Map((await orgMembers(orgId)).map((m) => [m.userId, m.name]));
}

export async function orgSessions(orgId: string) {
  return db
    .select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code, title: schema.trainingSessions.title, startDate: schema.trainingSessions.startDate, endDate: schema.trainingSessions.endDate, status: schema.trainingSessions.status })
    .from(schema.trainingSessions)
    .where(eq(schema.trainingSessions.orgId, orgId))
    .orderBy(desc(schema.trainingSessions.startDate))
    .limit(300);
}

export async function orgEnrollments(orgId: string, sessionId?: string | null) {
  return db
    .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, sessionId: schema.enrollments.sessionId, firstName: schema.persons.firstName, lastName: schema.persons.lastName, status: schema.enrollments.status })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.enrollments.orgId, orgId), sessionId ? eq(schema.enrollments.sessionId, sessionId) : undefined))
    .orderBy(schema.persons.lastName)
    .limit(500);
}

export async function orgPrograms(orgId: string) {
  return db.select({ id: schema.programs.id, code: schema.programs.code, title: schema.programs.title }).from(schema.programs).where(eq(schema.programs.orgId, orgId)).orderBy(schema.programs.title).limit(300);
}

export async function orgDocuments(orgId: string, limit = 200) {
  return db
    .select({ id: schema.documents.id, title: schema.documents.title, category: schema.documents.category, status: schema.documents.status, createdAt: schema.documents.createdAt })
    .from(schema.documents)
    .where(eq(schema.documents.orgId, orgId))
    .orderBy(desc(schema.documents.createdAt))
    .limit(limit);
}

export type EvidenceFilters = { indicator?: string; level?: string; sessionId?: string; enrollmentId?: string; status?: string };

export async function listEvidences(orgId: string, f: EvidenceFilters, page: number, pageSize: number) {
  const conds: SQL[] = [eq(schema.qualityEvidences.orgId, orgId)];
  if (f.indicator) conds.push(eq(schema.qualityEvidences.indicatorCode, f.indicator));
  if (f.level && ["individuel", "collectif", "organisationnel"].includes(f.level)) conds.push(eq(schema.qualityEvidences.level, f.level as "individuel"));
  if (f.status && ["valide", "invalidee", "remplacee"].includes(f.status)) conds.push(eq(schema.qualityEvidences.status, f.status as "valide"));
  if (f.sessionId) conds.push(eq(schema.qualityEvidences.sessionId, f.sessionId));
  if (f.enrollmentId) conds.push(eq(schema.qualityEvidences.enrollmentId, f.enrollmentId));
  const where = and(...conds);
  const [rows, [{ total }]] = await Promise.all([
    db.select().from(schema.qualityEvidences).where(where).orderBy(desc(schema.qualityEvidences.createdAt)).limit(pageSize).offset((page - 1) * pageSize),
    db.select({ total: sql<number>`count(*)::int` }).from(schema.qualityEvidences).where(where),
  ]);
  return { rows, total };
}

export async function evidenceCounts(orgId: string) {
  const rows = await db
    .select({ level: schema.qualityEvidences.level, status: schema.qualityEvidences.status, n: sql<number>`count(*)::int` })
    .from(schema.qualityEvidences)
    .where(eq(schema.qualityEvidences.orgId, orgId))
    .groupBy(schema.qualityEvidences.level, schema.qualityEvidences.status);
  return rows;
}

export async function listReferentials(orgId: string) {
  return db
    .select()
    .from(schema.referentials)
    .where(or(eq(schema.referentials.orgId, orgId), isNull(schema.referentials.orgId)))
    .orderBy(desc(schema.referentials.createdAt));
}

export async function listQualityActions(orgId: string, status?: string) {
  return db
    .select()
    .from(schema.qualityActions)
    .where(and(eq(schema.qualityActions.orgId, orgId), status && ["a_faire", "en_cours", "terminee", "abandonnee"].includes(status) ? eq(schema.qualityActions.status, status as "a_faire") : undefined))
    .orderBy(desc(schema.qualityActions.createdAt))
    .limit(200);
}

export async function openQualityActions(orgId: string) {
  return db
    .select()
    .from(schema.qualityActions)
    .where(and(eq(schema.qualityActions.orgId, orgId), inArray(schema.qualityActions.status, ["a_faire", "en_cours"])))
    .orderBy(schema.qualityActions.dueDate)
    .limit(50);
}

export async function listComplaints(orgId: string, status?: string) {
  return db
    .select()
    .from(schema.complaints)
    .where(and(eq(schema.complaints.orgId, orgId), status && ["recue", "en_cours", "traitee", "close"].includes(status) ? eq(schema.complaints.status, status as "recue") : undefined))
    .orderBy(desc(schema.complaints.receivedAt))
    .limit(200);
}

export async function listWatchItems(orgId: string, kind?: string) {
  return db
    .select()
    .from(schema.watchItems)
    .where(and(eq(schema.watchItems.orgId, orgId), kind ? eq(schema.watchItems.kind, kind) : undefined))
    .orderBy(desc(schema.watchItems.date))
    .limit(200);
}

export async function listSurveys(orgId: string) {
  const rows = await db
    .select({
      s: schema.surveys,
      sessionTitle: schema.trainingSessions.title,
      sent: sql<number>`(select count(*)::int from ${schema.surveyResponses} r where r.survey_id = ${schema.surveys.id} and r.sent_at is not null)`,
      submitted: sql<number>`(select count(*)::int from ${schema.surveyResponses} r where r.survey_id = ${schema.surveys.id} and r.submitted_at is not null)`,
    })
    .from(schema.surveys)
    .leftJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.surveys.sessionId))
    .where(eq(schema.surveys.orgId, orgId))
    .orderBy(desc(schema.surveys.createdAt))
    .limit(300);
  return rows;
}

export async function surveyResponses(orgId: string, surveyId: string) {
  return db
    .select({ r: schema.surveyResponses, firstName: schema.persons.firstName, lastName: schema.persons.lastName, reference: schema.enrollments.reference })
    .from(schema.surveyResponses)
    .leftJoin(schema.enrollments, eq(schema.enrollments.id, schema.surveyResponses.enrollmentId))
    .leftJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.surveyResponses.orgId, orgId), eq(schema.surveyResponses.surveyId, surveyId)))
    .orderBy(desc(schema.surveyResponses.submittedAt), desc(schema.surveyResponses.sentAt));
}

/** Tâches qualité ouvertes (alertes affectées) : famille qualite. */
export async function openQualityTasks(orgId: string) {
  return db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, orgId), eq(schema.tasks.family, "qualite"), inArray(schema.tasks.status, ["a_faire", "en_cours", "bloquee"]), isNotNull(schema.tasks.indicatorCode)))
    .orderBy(schema.tasks.dueDate, desc(schema.tasks.createdAt))
    .limit(100);
}
