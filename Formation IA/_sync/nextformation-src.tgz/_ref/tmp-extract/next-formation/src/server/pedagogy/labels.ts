/** Libellés métier du suivi pédagogique (F07), partagés entre pages, PDF et extranets. */

export const EVALUATION_KIND_LABELS: Record<string, string> = {
  positionnement: "Positionnement",
  formative: "Évaluation formative (en cours de formation)",
  sommative: "Évaluation sommative",
  finale: "Résultat final",
  auto_evaluation: "Auto-évaluation",
  competences: "Évaluation de compétences",
};

export const RECORD_KIND_LABELS: Record<string, string> = {
  objectif: "Objectif",
  activite: "Activité",
  competence: "Compétence",
  bilan: "Bilan",
  observation: "Observation",
  entreprise: "Entreprise",
  aide: "Aide / accompagnement",
};

export const FOLLOWUP_KIND_LABELS: Record<string, string> = {
  visite: "Visite en entreprise",
  appel: "Appel téléphonique",
  visio: "Visioconférence",
  bilan_intermediaire: "Bilan intermédiaire",
  bilan_final: "Bilan final",
  echange_tuteur: "Échange avec le tuteur",
  incident: "Incident (interne)",
};

export const PROGRESSION_LABELS: Record<string, string> = {
  non_commencee: "Non commencée",
  en_cours: "En cours",
  partielle: "Partielle",
  acquise: "Acquise",
  non_acquise: "Non acquise",
};
