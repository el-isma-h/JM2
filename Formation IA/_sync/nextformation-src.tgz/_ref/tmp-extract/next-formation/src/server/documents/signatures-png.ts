/** Contrôle pur de la structure d'un PNG (testé dans __tests__/rules.test.ts). */
/** Vérifie la structure des chunks PNG (IHDR … IEND) : un PNG tronqué ferait boucler le décodeur de pdf-lib. */
export function pngStructureOk(buf: Buffer): boolean {
  let pos = 8;
  let first = true;
  while (pos + 12 <= buf.length) {
    const len = buf.readUInt32BE(pos);
    const type = buf.toString("ascii", pos + 4, pos + 8);
    if (first && type !== "IHDR") return false;
    first = false;
    pos += 12 + len;
    if (type === "IEND") return pos === buf.length;
  }
  return false;
}
