import "server-only";
import { eq as eqId } from "drizzle-orm";
import { db, schema } from "@/db";
import { hashPassword } from "@/server/auth";
import { randomToken } from "@/lib/crypto";
import { bootstrapOrgDefaults } from "@/server/org-defaults";
import { seedDemoContent } from "./content";

export type DemoProfile = "direction" | "admin" | "pedagogy" | "trainer" | "learner" | "employer" | "finance" | "quality";

export type DemoResult = { tenantId: string; orgId: string; users: Record<DemoProfile, string> };

/**
 * Crée un tenant de démonstration complet (organisme fictif OF + CFA « Atelier Méridien Formation »),
 * ses utilisateurs par profil et son contenu (catalogue, sessions, inscriptions, planning, finance, qualité).
 * Toutes les données sont fictives ; l'espace est supprimé automatiquement après 24 heures.
 */
export async function seedDemo(): Promise<DemoResult> {
  const suffix = randomToken(6).toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 6);
  const password = await hashPassword(`Demo-${randomToken(12)}`);
  const result = await db.transaction(async (tx) => {
    const [tenant] = await tx.insert(schema.tenants).values({ name: "Atelier Méridien Formation (démo)", kind: "organisme", slug: `demo-${suffix}`, isDemo: true }).returning();
    const [org] = await tx
      .insert(schema.organismes)
      .values({
        tenantId: tenant.id,
        kind: "of_cfa",
        legalName: "Atelier Méridien Formation",
        tradeName: "Atelier Méridien",
        legalForm: "SAS",
        siren: "913245676",
        siret: "91324567600022",
        nda: "11 75 61234 75",
        ndaRegion: "Île-de-France",
        addressLine1: "14 rue des Tanneurs",
        postalCode: "75011",
        city: "Paris",
        email: "contact@atelier-meridien.example",
        phone: "01 84 60 12 34",
        qualiopiNumber: "FR-QUAL-2024-07318",
        qualiopiCertifier: "Certificateur fictif",
        qualiopiValidUntil: "2027-09-30",
        qualiopiScopes: ["actions de formation", "actions de formation par apprentissage"],
        signatoryName: "Élise Marchetti",
        signatoryTitle: "Directrice",
        onboardingStep: "termine",
        onboardingCompletedAt: new Date(),
        isDemo: true,
      })
      .returning();
    await bootstrapOrgDefaults(tx, org.id);

    const people: { key: DemoProfile; firstName: string; lastName: string; roles: string[]; isOwner?: boolean }[] = [
      { key: "direction", firstName: "Élise", lastName: "Marchetti", roles: ["direction"], isOwner: true },
      { key: "admin", firstName: "Karim", lastName: "Benali", roles: ["admin_staff"] },
      { key: "pedagogy", firstName: "Nathalie", lastName: "Roussel", roles: ["trainer", "agency_manager", "pedagogy_manager"] },
      { key: "trainer", firstName: "Thomas", lastName: "Lefebvre", roles: ["trainer"] },
      { key: "finance", firstName: "Sophie", lastName: "Garnier", roles: ["finance"] },
      { key: "quality", firstName: "Mehdi", lastName: "Ouali", roles: ["quality"] },
      { key: "learner", firstName: "Inès", lastName: "Carvalho", roles: ["learner"] },
      { key: "employer", firstName: "Julien", lastName: "Deschamps", roles: ["employer"] },
    ];
    const users = {} as Record<DemoProfile, string>;
    for (const p of people) {
      const [u] = await tx
        .insert(schema.users)
        .values({
          email: `${p.firstName.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()}.${p.lastName.toLowerCase()}@demo-${suffix}.nextformation.local`,
          passwordHash: password,
          firstName: p.firstName,
          lastName: p.lastName,
          tenantId: tenant.id,
          emailVerifiedAt: new Date(),
          termsAcceptedAt: new Date(),
          termsVersion: "demo",
        })
        .returning();
      users[p.key] = u.id;
      await tx.insert(schema.memberships).values({ orgId: org.id, userId: u.id, roles: p.roles, title: p.key });
      if (p.isOwner) await tx.update(schema.organismes).set({ ownerUserId: u.id }).where(eqId(schema.organismes.id, org.id));
    }
    // Nathalie : cumul formateur + responsable d'agence + responsable pédagogique avec consultation financière attribuée (cas impératif CDC).
    await tx.update(schema.memberships).set({ permissions: { "finance.view": true } }).where(eqId(schema.memberships.userId, users.pedagogy));
    return { tenantId: tenant.id, orgId: org.id, users };
  });
  await seedDemoContent(result);
  return result;
}


