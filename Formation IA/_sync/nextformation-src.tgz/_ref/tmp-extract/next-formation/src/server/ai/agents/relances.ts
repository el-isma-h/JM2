import "server-only";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { assertEnrollmentInScope } from "@/server/authz";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import type { Agent, AgentInput, ProposalDraft } from "../store";
import { askJson, baseRationale, forbidden, orgLabel, requireEntity, toPromptJson } from "./shared";

export type RelancePayload = {
  to: string;
  toLabel: string;
  recipientKind: "apprenant" | "entreprise" | "financeur";
  subject: string;
  text: string;
  html?: string;
  cause: "pieces_manquantes" | "facture_en_retard" | "enquete_non_repondue";
};

function esc(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export function textToHtml(text: string): string {
  return text
    .split(/\n{2,}/)
    .map((p) => `<p>${esc(p).replace(/\n/g, "<br>")}</p>`)
    .join("");
}

type Target = { cause: RelancePayload["cause"]; recipientKind: RelancePayload["recipientKind"]; to: string | null; toLabel: string; facts: Record<string, unknown>; entityType: string; entityId: string; sources: { type: string; id?: string | null; label: string }[] };

/** Détermine destinataire et faits selon l'entité : inscription (pièces), facture (retard), réponse d'enquête (non répondue). */
async function resolveTarget(ctx: OrgContext, input: AgentInput): Promise<Target> {
  const { entityType, entityId } = requireEntity(input, ["enrollment", "invoice", "survey_response"]);
  if (entityType === "enrollment") {
    if (!ctx.permissions.has("dossier.admin_docs.view")) forbidden();
    await assertEnrollmentInScope(ctx, entityId);
    const [row] = await db
      .select({ e: schema.enrollments, p: schema.persons, s: schema.trainingSessions, companyName: schema.companies.name, companyEmail: schema.companies.email })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .leftJoin(schema.companies, eq(schema.companies.id, schema.enrollments.companyId))
      .where(and(eq(schema.enrollments.id, entityId), eq(schema.enrollments.orgId, ctx.org.id)))
      .limit(1);
    if (!row) throw new Error("Inscription introuvable.");
    const pieces = await db
      .select({ label: schema.requiredPieces.label, providedBy: schema.requiredPieces.providedBy, status: schema.pieceSubmissions.status, dueDate: schema.pieceSubmissions.dueDate, refusalReason: schema.pieceSubmissions.refusalReason })
      .from(schema.pieceSubmissions)
      .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
      .where(and(eq(schema.pieceSubmissions.orgId, ctx.org.id), eq(schema.pieceSubmissions.enrollmentId, entityId), inArray(schema.pieceSubmissions.status, ["attendue", "refusee"])));
    if (!pieces.length) throw new Error("Aucune pièce manquante sur cette inscription : rien à relancer.");
    const byCompany = pieces.every((p) => p.providedBy === "entreprise") && row.companyName;
    const toContact = byCompany ? await db.select({ email: schema.contacts.email, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName }).from(schema.contacts).where(and(eq(schema.contacts.orgId, ctx.org.id), eq(schema.contacts.companyId, row.e.companyId!))).limit(1) : [];
    const to = byCompany ? (toContact[0]?.email ?? row.companyEmail ?? null) : (row.p.email ?? null);
    return {
      cause: "pieces_manquantes",
      recipientKind: byCompany ? "entreprise" : "apprenant",
      to,
      toLabel: byCompany ? `${row.companyName}${toContact[0] ? ` (${toContact[0].firstName} ${toContact[0].lastName})` : ""}` : `${row.p.firstName} ${row.p.lastName}`,
      facts: { apprenant: `${row.p.firstName} ${row.p.lastName}`, formation: row.s.title, debut: row.s.startDate, pieces: pieces.map((p) => ({ label: p.label, status: p.status, dueDate: p.dueDate, refusalReason: p.refusalReason, providedBy: p.providedBy })), entreprise: row.companyName },
      entityType,
      entityId,
      sources: [{ type: "enrollment", id: entityId, label: `Inscription ${row.e.reference}` }, { type: "pieces", label: `${pieces.length} pièce(s) attendue(s) ou refusée(s)` }],
    };
  }
  if (entityType === "invoice") {
    if (!ctx.permissions.has("finance.view")) forbidden();
    const [inv] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, entityId), eq(schema.invoices.orgId, ctx.org.id))).limit(1);
    if (!inv) throw new Error("Facture introuvable.");
    if (!["en_retard", "emise", "envoyee", "partiellement_payee"].includes(inv.status)) throw new Error("Cette facture n'est pas en attente de règlement.");
    const billTo = (inv.billTo ?? {}) as { name?: string; email?: string };
    let to = billTo.email ?? null;
    let toLabel = billTo.name ?? "Destinataire de la facture";
    let kind: RelancePayload["recipientKind"] = "entreprise";
    if (inv.companyId) {
      const [c] = await db.select({ name: schema.companies.name, email: schema.companies.email }).from(schema.companies).where(eq(schema.companies.id, inv.companyId)).limit(1);
      const [billing] = await db.select({ email: schema.contacts.email, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName }).from(schema.contacts).where(and(eq(schema.contacts.companyId, inv.companyId), eq(schema.contacts.isBilling, true))).limit(1);
      to = to ?? billing?.email ?? c?.email ?? null;
      toLabel = c?.name ?? toLabel;
    } else if (inv.funderId) {
      const [f] = await db.select({ name: schema.funders.name, email: schema.funders.email }).from(schema.funders).where(eq(schema.funders.id, inv.funderId)).limit(1);
      to = to ?? f?.email ?? null;
      toLabel = f?.name ?? toLabel;
      kind = "financeur";
    } else if (inv.personId) {
      const [p] = await db.select({ firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email }).from(schema.persons).where(eq(schema.persons.id, inv.personId)).limit(1);
      to = to ?? p?.email ?? null;
      toLabel = p ? `${p.firstName} ${p.lastName}` : toLabel;
      kind = "apprenant";
    }
    return {
      cause: "facture_en_retard",
      recipientKind: kind,
      to,
      toLabel,
      facts: { numero: inv.number, emiseLe: inv.issueDate, echeance: inv.dueDate, montantTtc: formatCents(inv.totalTtcCents), resteDu: formatCents(inv.totalTtcCents - inv.paidCents), statut: inv.status },
      entityType,
      entityId,
      sources: [{ type: "invoice", id: entityId, label: `Facture ${inv.number ?? ""}` }],
    };
  }
  if (!ctx.permissions.has("quality.view")) forbidden();
  const [r] = await db.select({ r: schema.surveyResponses, s: schema.surveys }).from(schema.surveyResponses).innerJoin(schema.surveys, eq(schema.surveys.id, schema.surveyResponses.surveyId)).where(and(eq(schema.surveyResponses.id, entityId), eq(schema.surveyResponses.orgId, ctx.org.id))).limit(1);
  if (!r) throw new Error("Réponse d'enquête introuvable.");
  if (r.r.submittedAt) throw new Error("Cette enquête a déjà été répondue : rien à relancer.");
  let to: string | null = null;
  let toLabel = "Destinataire";
  let kind: RelancePayload["recipientKind"] = "apprenant";
  if (r.r.enrollmentId) {
    await assertEnrollmentInScope(ctx, r.r.enrollmentId);
    const [p] = await db.select({ firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email }).from(schema.enrollments).innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId)).where(eq(schema.enrollments.id, r.r.enrollmentId)).limit(1);
    to = p?.email ?? null;
    toLabel = p ? `${p.firstName} ${p.lastName}` : toLabel;
  } else if (r.r.contactId) {
    const [c] = await db.select({ firstName: schema.contacts.firstName, lastName: schema.contacts.lastName, email: schema.contacts.email }).from(schema.contacts).where(eq(schema.contacts.id, r.r.contactId)).limit(1);
    to = c?.email ?? null;
    toLabel = c ? `${c.firstName} ${c.lastName}` : toLabel;
    kind = "entreprise";
  }
  return {
    cause: "enquete_non_repondue",
    recipientKind: kind,
    to,
    toLabel,
    facts: { enquete: r.s.title, type: r.s.kind, envoyeeLe: r.r.sentAt ? fmtDate(r.r.sentAt) : null },
    entityType,
    entityId,
    sources: [{ type: "survey_response", id: entityId, label: `Enquête « ${r.s.title} »` }],
  };
}

/** Gabarit déterministe (sans modèle) adapté au destinataire. */
export function deterministicRelance(t: Target, org: string, signer: string): { subject: string; text: string } {
  const greeting = t.recipientKind === "apprenant" ? "Bonjour," : "Madame, Monsieur,";
  const closing = `\n\nNous restons à votre disposition.\n\n${signer}\n${org}`;
  if (t.cause === "pieces_manquantes") {
    const f = t.facts as { apprenant: string; formation: string; debut: string; pieces: { label: string; status: string; refusalReason?: string | null; dueDate?: string | null }[] };
    const list = f.pieces.map((p) => `- ${p.label}${p.status === "refusee" ? ` (document précédent refusé${p.refusalReason ? ` : ${p.refusalReason}` : ""})` : ""}${p.dueDate ? `, attendue avant le ${fmtDate(p.dueDate)}` : ""}`).join("\n");
    const who = t.recipientKind === "entreprise" ? `le dossier de ${f.apprenant}` : "votre dossier";
    return {
      subject: `Pièces à fournir pour ${t.recipientKind === "entreprise" ? f.apprenant : "votre inscription"} : ${f.formation}`,
      text: `${greeting}\n\nPour finaliser ${who} d'inscription à la formation « ${f.formation} » (début le ${fmtDate(f.debut)}), il nous manque les pièces suivantes :\n${list}\n\nVous pouvez les déposer depuis votre espace en ligne ou nous les transmettre par retour de ce message.${closing}`,
    };
  }
  if (t.cause === "facture_en_retard") {
    const f = t.facts as { numero: string | null; emiseLe: string; echeance: string | null; resteDu: string; montantTtc: string };
    return {
      subject: `Rappel de règlement : facture ${f.numero ?? ""}`,
      text: `${greeting}\n\nSauf erreur de notre part, la facture ${f.numero ?? ""} du ${fmtDate(f.emiseLe)}${f.echeance ? `, échue le ${fmtDate(f.echeance)}` : ""}, d'un montant de ${f.montantTtc} TTC, reste à régler pour ${f.resteDu}.\n\nSi le règlement a déjà été effectué, merci de ne pas tenir compte de ce message et de nous en indiquer la référence.${closing}`,
    };
  }
  const f = t.facts as { enquete: string; envoyeeLe: string | null };
  return {
    subject: `Votre avis compte : ${f.enquete}`,
    text: `${greeting}\n\nNous vous avons adressé${f.envoyeeLe ? ` le ${f.envoyeeLe}` : ""} le questionnaire « ${f.enquete} ». Vos réponses nous aident à améliorer nos formations ; elles ne prennent que quelques minutes.\n\nMerci de bien vouloir y répondre via le lien reçu, ou depuis votre espace en ligne.${closing}`,
  };
}

export const relancesAgent: Agent = {
  name: "relances",
  label: "Rédaction de relance",
  description: "E-mail de relance : pièces manquantes (inscription), facture en retard, enquête non répondue. Envoyé seulement après validation.",
  accepts: ["enrollment", "invoice", "survey_response"],
  async run(ctx: OrgContext, input: AgentInput): Promise<ProposalDraft> {
    const t = await resolveTarget(ctx, input);
    const signer = ctx.org.signatoryName ?? `${ctx.user.firstName} ${ctx.user.lastName}`;
    const det = deterministicRelance(t, orgLabel(ctx), signer);
    const ai = await askJson<{ subject?: string; text?: string; certainty?: "A" | "B" | "C" }>(
      `Rédige un e-mail de relance courtois et précis, adapté au destinataire (${t.recipientKind}). Réponds en JSON : {"subject": string, "text": string, "certainty": "A"|"B"|"C"}. Le texte est en clair (pas de HTML), signé « ${signer}, ${orgLabel(ctx)} ». N'ajoute aucune information absente des faits.`,
      `Cause : ${t.cause}\nDestinataire : ${t.toLabel}\nFaits :\n${toPromptJson(t.facts)}\n\nGabarit de référence :\n${JSON.stringify(det)}`,
    );
    const subject = ai?.data?.subject?.trim() || det.subject;
    const text = ai?.data?.text?.trim() || det.text;
    const payload: RelancePayload = { to: t.to ?? "", toLabel: t.toLabel, recipientKind: t.recipientKind, subject, text, html: textToHtml(text), cause: t.cause };
    const notes = [t.to ? `Destinataire : ${t.to}` : "Aucune adresse e-mail connue pour ce destinataire : l'envoi sera refusé à l'application tant qu'elle n'est pas renseignée."];
    if (ctx.org.isDemo) notes.push("Organisme de démonstration : aucun e-mail ne part jamais.");
    return {
      agent: "relances",
      kind: "email",
      title: `Relance ${t.cause.replace(/_/g, " ")} : ${t.toLabel}`,
      summary: subject,
      entityType: t.entityType,
      entityId: t.entityId,
      payload: payload as unknown as Record<string, unknown>,
      rationale: baseRationale(t.sources, ai?.data?.certainty ?? "A", !ai, ["Validation = envoi de l'e-mail via la boîte d'envoi (journalisé)."], notes),
      provider: ai?.result.provider ?? null,
      model: ai?.result.model ?? null,
    };
  },
};
