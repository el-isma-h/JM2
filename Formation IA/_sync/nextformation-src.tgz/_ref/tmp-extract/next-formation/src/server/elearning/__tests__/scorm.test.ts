import { describe, expect, it } from "vitest";
import { mimeForPath, parseScormManifest, safePackagePath } from "../scorm";

const manifest = `<?xml version="1.0"?>
<manifest identifier="M1" xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2">
  <metadata><schema>ADL SCORM</schema><schemaversion>1.2</schemaversion></metadata>
  <organizations default="ORG1">
    <organization identifier="ORG1"><title>S&amp;curit&#39; au travail</title>
      <item identifier="I1" identifierref="RES1"><title>Chapitre 1</title></item>
    </organization>
  </organizations>
  <resources>
    <resource identifier="RES2" type="webcontent" adlcp:scormtype="asset" href="assets/style.css"/>
    <resource identifier="RES1" type="webcontent" adlcp:scormtype="sco" href="./content/index.html"><file href="content/index.html"/></resource>
  </resources>
</manifest>`;

describe("manifeste SCORM", () => {
  it("lit le titre, la version et la page de lancement du premier item", () => {
    const m = parseScormManifest(manifest);
    expect(m.title).toBe("S&curit' au travail");
    expect(m.schemaVersion).toBe("1.2");
    expect(m.launch).toBe("content/index.html");
  });
  it("retombe sur la première ressource avec href", () => {
    const m = parseScormManifest(`<manifest><resources><resource href="index.html"/></resources></manifest>`);
    expect(m.launch).toBe("index.html");
    expect(m.title).toBeNull();
  });
  it("refuse les chemins dangereux", () => {
    expect(safePackagePath(["..", "etc", "passwd"])).toBeNull();
    expect(safePackagePath(["content", "index.html"])).toBe("content/index.html");
    expect(mimeForPath("a/b.js")).toContain("javascript");
    expect(mimeForPath("x.bin")).toBe("application/octet-stream");
  });
});
