"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq, gt, isNull } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { sha256 } from "@/lib/crypto";
import { appUrl } from "@/lib/env";
import { checkSiret } from "@/lib/validators";
import { todayParis } from "@/lib/time";
import { issueToken } from "@/server/auth";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { createDocument } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { layoutMail, sendMail } from "@/server/mail";
import { recordEvidence } from "@/server/quality/evidence";
import { bool, fail, fullName, isoDate, optEmail, str, tagList, uuid } from "@/server/crm/helpers";
import type { ActionState } from "./auth";

const KINDS = schema.trainerKindEnum.enumValues;
const PARTS = schema.periodPartEnum.enumValues;

function base(orgId: string) {
  return `/app/${orgId}`;
}

async function loadTrainer(ctx: OrgContext, id: string) {
  const [t] = await db.select().from(schema.trainers).where(and(eq(schema.trainers.id, id), eq(schema.trainers.orgId, ctx.org.id))).limit(1);
  if (!t) throw new Error("Formateur introuvable dans cet organisme.");
  return t;
}

function trainerValues(formData: FormData) {
  const rawSiret = str(formData, "siret", 20);
  let siret: string | null = null;
  if (rawSiret) {
    const r = checkSiret(rawSiret);
    if (!r.ok) throw new Error(r.error);
    siret = r.value;
  }
  const rateRaw = str(formData, "hourlyRateEuros", 20);
  let hourlyRateCents: number | null = null;
  if (rateRaw) {
    const v = rateRaw.replace(/[\s €]/g, "").replace(",", ".");
    if (!/^\d+(\.\d{1,2})?$/.test(v)) throw new Error("Tarif horaire invalide (ex. 65,00).");
    const [i, d = ""] = v.split(".");
    hourlyRateCents = Number(i) * 100 + Number(d.padEnd(2, "0"));
  }
  return {
    civility: str(formData, "civility", 10),
    firstName: z.string().trim().min(1, "Prénom requis").max(80).parse(formData.get("firstName")),
    lastName: z.string().trim().min(1, "Nom requis").max(80).parse(formData.get("lastName")),
    email: optEmail(formData, "email"),
    phone: str(formData, "phone", 40),
    kind: z.enum(KINDS).parse(formData.get("kind") || "interne"),
    companyName: str(formData, "companyName", 200),
    siret,
    nda: str(formData, "nda", 40),
    skills: tagList(str(formData, "skills", 2000)),
    qualifications: str(formData, "qualifications", 5000),
    hourlyRateCents,
    isActive: formData.has("isActivePresent") ? bool(formData, "isActive") : true,
    notes: str(formData, "notes", 5000),
  };
}

export async function createTrainerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let orgId = "";
  let id = "";
  try {
    orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const values = trainerValues(formData);
    const [row] = await db.insert(schema.trainers).values({ ...values, orgId: ctx.org.id, isDemo: ctx.org.isDemo }).returning({ id: schema.trainers.id });
    await audit({ action: "trainer.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "trainer", entityId: row.id, after: { firstName: values.firstName, lastName: values.lastName, kind: values.kind } });
    revalidatePath(`${base(orgId)}/formateurs`);
    id = row.id;
  } catch (e) {
    return fail(e, "Création impossible.");
  }
  redirect(`${base(orgId)}/formateurs/${id}`);
}

export async function updateTrainerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const before = await loadTrainer(ctx, uuid.parse(formData.get("trainerId")));
    const values = trainerValues(formData);
    await db.update(schema.trainers).set(values).where(eq(schema.trainers.id, before.id));
    await audit({ action: "trainer.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "trainer", entityId: before.id, before: { ...before, notes: undefined }, after: { ...values, notes: undefined } });
    revalidatePath(`${base(orgId)}/formateurs/${before.id}`);
    revalidatePath(`${base(orgId)}/formateurs`);
    return { ok: true, message: "Fiche formateur enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Dépôt de CV / diplôme / habilitation : preuve Qualiopi IND_21 (qualification des formateurs) enregistrée si le formateur a un compte. */
export async function uploadTrainerDocumentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const t = await loadTrainer(ctx, uuid.parse(formData.get("trainerId")));
    const category = z.enum(["cv", "diplome", "justificatif"]).parse(formData.get("category") || "cv");
    const file = formData.get("file");
    if (!(file instanceof File) || !file.size) return { error: "Choisissez un fichier." };
    const data = Buffer.from(await file.arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head: data.subarray(0, 8) });
    if (!check.ok) return { error: check.error };
    const label = category === "cv" ? "CV" : category === "diplome" ? "Diplôme" : "Habilitation / justificatif";
    const title = str(formData, "title", 200) ?? `${label} ${fullName(t)}`;
    const doc = await createDocument({
      orgId: ctx.org.id,
      trainerId: t.id,
      category,
      visibility: "interne",
      status: "valide",
      title,
      fileName: file.name,
      mimeType: check.mime,
      data,
      sourceType: "trainer",
      sourceId: t.id,
      uploadedBy: ctx.user.id,
      isDemo: ctx.org.isDemo,
    });
    let evidence = "";
    if (t.userId && (category === "cv" || category === "diplome")) {
      const r = await recordEvidence({
        orgId: ctx.org.id,
        indicatorCode: "IND_21",
        level: "organisationnel",
        title: `Qualification du formateur ${fullName(t)} : ${title}`,
        sourceType: "trainer_document",
        sourceId: doc.id,
        documentId: doc.id,
        evidenceDate: todayParis(),
        createdBy: ctx.user.id,
      });
      evidence = r.created ? " Preuve qualité « qualification des formateurs » (indicateur 21) enregistrée." : "";
    } else if (category === "cv" || category === "diplome") {
      evidence = " La preuve qualité sera enregistrée une fois le formateur invité à l'espace formateur (compte rattaché).";
    }
    await audit({ action: "trainer.document.upload", userId: ctx.user.id, orgId: ctx.org.id, entityType: "trainer", entityId: t.id, after: { documentId: doc.id, category } });
    revalidatePath(`${base(orgId)}/formateurs/${t.id}`);
    return { ok: true, message: `${label} déposé.${evidence}` };
  } catch (e) {
    return fail(e, "Dépôt impossible.");
  }
}

export async function addUnavailabilityAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const t = await loadTrainer(ctx, uuid.parse(formData.get("trainerId")));
    const startDate = isoDate(formData, "startDate");
    const endDate = isoDate(formData, "endDate") ?? startDate;
    if (!startDate || !endDate) return { error: "Indiquez la date de début." };
    if (endDate < startDate) return { error: "La date de fin précède la date de début." };
    const rawPart = str(formData, "part", 20);
    const part = rawPart ? z.enum(PARTS).parse(rawPart) : null;
    const [row] = await db.insert(schema.trainerUnavailabilities).values({ orgId: ctx.org.id, trainerId: t.id, startDate, endDate, part, reason: str(formData, "reason", 300) }).returning({ id: schema.trainerUnavailabilities.id });
    await audit({ action: "trainer.unavailability.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "trainer", entityId: t.id, after: { id: row.id, startDate, endDate, part } });
    revalidatePath(`${base(orgId)}/formateurs/${t.id}`);
    return { ok: true, message: "Indisponibilité enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deleteUnavailabilityAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const id = uuid.parse(formData.get("unavailabilityId"));
    const [u] = await db.select().from(schema.trainerUnavailabilities).where(and(eq(schema.trainerUnavailabilities.id, id), eq(schema.trainerUnavailabilities.orgId, ctx.org.id))).limit(1);
    if (!u) return { error: "Indisponibilité introuvable." };
    await db.delete(schema.trainerUnavailabilities).where(eq(schema.trainerUnavailabilities.id, u.id));
    await audit({ action: "trainer.unavailability.delete", userId: ctx.user.id, orgId: ctx.org.id, entityType: "trainer", entityId: u.trainerId, before: u });
    revalidatePath(`${base(orgId)}/formateurs/${u.trainerId}`);
    return { ok: true, message: "Indisponibilité retirée." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

/** Invitation à l'espace formateur : invitation (rôle trainer, trainerId) + jeton 7 jours + e-mail /invitation/[token]. */
export async function inviteTrainerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "sessions.manage");
    const t = await loadTrainer(ctx, uuid.parse(formData.get("trainerId")));
    if (t.userId) return { error: "Ce formateur dispose déjà d'un compte rattaché." };
    const email = (str(formData, "email", 200) ?? t.email ?? "").toLowerCase();
    const parsed = z.string().email("Adresse e-mail invalide").safeParse(email);
    if (!parsed.success) return { error: "Renseignez une adresse e-mail valide pour le formateur." };
    const [pending] = await db
      .select({ id: schema.invitations.id })
      .from(schema.invitations)
      .where(and(eq(schema.invitations.trainerId, t.id), eq(schema.invitations.status, "pending"), gt(schema.invitations.expiresAt, new Date()), isNull(schema.invitations.acceptedAt)))
      .limit(1);
    if (pending && !bool(formData, "resend")) return { error: "Une invitation est déjà en attente pour ce formateur. Cochez « Renvoyer » pour en émettre une nouvelle." };
    if (!t.email || t.email !== email) await db.update(schema.trainers).set({ email }).where(eq(schema.trainers.id, t.id));
    const invitationId = randomUUID();
    const token = await issueToken("invite", { email, payload: { invitationId }, ttlMinutes: 7 * 24 * 60 });
    await db.insert(schema.invitations).values({ id: invitationId, tenantId: ctx.tenant.id, orgId: ctx.org.id, email, roles: ["trainer"], trainerId: t.id, invitedBy: ctx.user.id, tokenHash: sha256(token), expiresAt: new Date(Date.now() + 7 * 86400_000) });
    const url = `${appUrl()}/invitation/${token}`;
    const orgName = ctx.org.tradeName ?? ctx.org.legalName;
    const res = await sendMail({
      to: email,
      subject: `Votre espace formateur : ${orgName}`,
      html: layoutMail("Votre espace formateur", `<p>Bonjour ${t.firstName},</p><p>${orgName} vous ouvre un accès à son espace formateur Next Formation : planning, émargement et suivi des séances qui vous sont affectées. Ce lien est valable 7 jours.</p>`, { label: "Accepter l'invitation", url }),
      text: `Acceptez l'invitation à l'espace formateur de ${orgName} (valable 7 jours) : ${url}`,
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "trainer.invite", userId: ctx.user.id, orgId: ctx.org.id, entityType: "trainer", entityId: t.id, after: { email, invitationId, mail: res.status } });
    revalidatePath(`${base(orgId)}/formateurs/${t.id}`);
    if (res.status === "sent") return { ok: true, message: `Invitation envoyée à ${email}.` };
    return { ok: true, message: ctx.org.isDemo ? "Démonstration : aucun e-mail réel. Transmettez ce lien au formateur (valable 7 jours) :" : "Service e-mail non configuré : transmettez ce lien au formateur (valable 7 jours) :", data: { link: url } };
  } catch (e) {
    return fail(e, "Invitation impossible.");
  }
}
