/**
 * Markdown minimal des brouillons (pur, partagé entre l'aperçu client et l'export PDF/DOCX).
 * Pris en charge : titres #, ##, ###, paragraphes (sauts de ligne conservés), listes « - », gras **texte**, séparateur « *** »,
 * et marqueurs [À COMPLÉTER : …] mis en évidence. Aucun HTML n'est interprété.
 */

export type Inline = { text: string; bold?: boolean; marker?: boolean };
export type Block =
  | { type: "heading"; level: 1 | 2 | 3; inlines: Inline[] }
  | { type: "paragraph"; inlines: Inline[] }
  | { type: "list"; items: Inline[][] }
  | { type: "rule" };

const MARKER_SPLIT = /(\[À COMPLÉTER : [^\]]+\])/g;

export function parseInline(src: string): Inline[] {
  const out: Inline[] = [];
  const boldParts = src.split(/(\*\*[^*]+\*\*)/g);
  for (const part of boldParts) {
    if (!part) continue;
    const bold = part.startsWith("**") && part.endsWith("**") && part.length > 4;
    const inner = bold ? part.slice(2, -2) : part;
    for (const seg of inner.split(MARKER_SPLIT)) {
      if (!seg) continue;
      const isMarker = seg.startsWith("[À COMPLÉTER : ");
      out.push({ text: seg, ...(bold ? { bold: true } : {}), ...(isMarker ? { marker: true } : {}) });
    }
  }
  return out;
}

export function parseMarkdown(src: string): Block[] {
  const blocks: Block[] = [];
  const lines = src.replace(/\r\n?/g, "\n").split("\n");
  let para: string[] = [];
  let list: Inline[][] | null = null;
  const flush = () => {
    if (para.length) blocks.push({ type: "paragraph", inlines: parseInline(para.join("\n")) });
    para = [];
    if (list) blocks.push({ type: "list", items: list });
    list = null;
  };
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (!line.trim()) {
      flush();
      continue;
    }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      flush();
      blocks.push({ type: "heading", level: h[1].length as 1 | 2 | 3, inlines: parseInline(h[2]) });
      continue;
    }
    if (/^\s*\*\*\*\s*$/.test(line)) {
      flush();
      blocks.push({ type: "rule" });
      continue;
    }
    const li = line.match(/^\s*-\s+(.*)$/);
    if (li) {
      if (para.length) {
        blocks.push({ type: "paragraph", inlines: parseInline(para.join("\n")) });
        para = [];
      }
      list = list ?? [];
      list.push(parseInline(li[1]));
      continue;
    }
    if (list) {
      blocks.push({ type: "list", items: list });
      list = null;
    }
    para.push(line.trim());
  }
  flush();
  return blocks;
}

export function inlineText(inlines: Inline[]): string {
  return inlines.map((i) => i.text).join("");
}
