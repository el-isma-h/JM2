import "server-only";
import PDFDocument from "pdfkit";
import { AlignmentType, Document, Footer, Header, HeadingLevel, ImageRun, Packer, PageNumber, Paragraph, TextRun } from "docx";
import { parseMarkdown, type Inline } from "./markdown";

/**
 * Rendu PDF et DOCX d'un document du parcours avec la charte institutionnelle de l'organisme (F10) :
 * en-tête (logo, raison sociale, SIRET, NDA, texte d'en-tête), filets à la couleur principale,
 * pied de page (texte de pied de page, pagination « page x / y »). Polices standard (Helvetica).
 */

export type Brand = {
  legalName: string;
  tradeName?: string | null;
  siret?: string | null;
  nda?: string | null;
  address?: string | null;
  primaryColor?: string | null;
  documentHeader?: string | null;
  documentFooter?: string | null;
  /** Logo PNG ou JPEG (autres formats ignorés). */
  logo?: Buffer | null;
};

export type BrandedMeta = { title: string; brand: Brand; reference?: string | null };

const clean = (s: string) => s.replace(/[  ]/g, " ");

export function imageKind(buf: Buffer | null | undefined): "png" | "jpeg" | null {
  if (!buf || buf.length < 4) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "png";
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpeg";
  return null;
}

export function safeHex(color: string | null | undefined, fallback = "#4b2a7f"): string {
  return color && /^#[0-9a-fA-F]{6}$/.test(color) ? color : fallback;
}

export function defaultFooter(b: Brand): string {
  const parts = [b.legalName, b.address, b.siret ? `SIRET ${b.siret}` : null, b.nda ? `NDA ${b.nda}` : null].filter(Boolean);
  return parts.join(", ");
}

const M = { left: 56, right: 56, top: 110, bottom: 70 };

export async function renderBrandedPdf(markdown: string, meta: BrandedMeta): Promise<Buffer> {
  const brand = meta.brand;
  const accent = safeHex(brand.primaryColor);
  const ink = "#1d1c1a";
  const muted = "#6b6760";
  const doc = new PDFDocument({ size: "A4", bufferPages: true, margins: M, info: { Title: meta.title, Creator: "Next Formation", Author: brand.legalName } });
  const chunks: Buffer[] = [];
  doc.on("data", (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });
  const width = doc.page.width;
  const contentWidth = width - M.left - M.right;
  const logoKind = imageKind(brand.logo);

  const drawHeader = () => {
    const savedY = doc.y;
    let x = M.left;
    if (logoKind && brand.logo) {
      try {
        doc.image(brand.logo, M.left, 30, { fit: [96, 44] });
        x = M.left + 108;
      } catch {
        x = M.left;
      }
    }
    doc.font("Helvetica-Bold").fontSize(10).fillColor(ink).text(clean(brand.tradeName ?? brand.legalName), x, 32, { width: width - x - M.right, lineBreak: false });
    const line2 = brand.documentHeader?.trim() || [brand.legalName !== (brand.tradeName ?? brand.legalName) ? brand.legalName : null, brand.siret ? `SIRET ${brand.siret}` : null, brand.nda ? `NDA ${brand.nda}` : null].filter(Boolean).join("  |  ");
    doc.font("Helvetica").fontSize(7.5).fillColor(muted).text(clean(line2), x, 46, { width: width - x - M.right, height: 30, lineGap: 1 });
    doc.moveTo(M.left, 84).lineTo(width - M.right, 84).strokeColor(accent).lineWidth(1.2).stroke();
    doc.fillColor(ink);
    doc.y = savedY;
  };
  doc.on("pageAdded", () => {
    drawHeader();
    doc.x = M.left;
    doc.y = M.top;
  });
  drawHeader();
  doc.x = M.left;
  doc.y = M.top;

  const writeInlines = (inlines: Inline[], size: number, opts: { indent?: number; color?: string; bold?: boolean } = {}) => {
    doc.fontSize(size);
    inlines.forEach((i, idx) => {
      const last = idx === inlines.length - 1;
      doc
        .font(i.bold || opts.bold ? "Helvetica-Bold" : "Helvetica")
        .fillColor(i.marker ? "#8a5a00" : (opts.color ?? ink))
        .text(clean(i.text), { continued: !last, lineGap: 2.5, indent: opts.indent, width: contentWidth, ...(i.marker ? { underline: true } : { underline: false }) });
    });
    doc.fillColor(ink);
  };

  let first = true;
  for (const b of parseMarkdown(markdown)) {
    if (b.type === "heading") {
      if (b.level === 1) {
        if (!first) doc.moveDown(0.6);
        writeInlines(b.inlines, 17, { bold: true, color: accent });
        const y = doc.y + 3;
        doc.moveTo(M.left, y).lineTo(M.left + 60, y).strokeColor(accent).lineWidth(1.5).stroke();
        doc.moveDown(0.9);
      } else if (b.level === 2) {
        doc.moveDown(0.5);
        writeInlines(b.inlines, 11.5, { bold: true, color: accent });
        doc.moveDown(0.35);
      } else {
        doc.moveDown(0.4);
        writeInlines(b.inlines, 10.5, { bold: true });
        doc.moveDown(0.3);
      }
    } else if (b.type === "paragraph") {
      writeInlines(b.inlines, 10);
      doc.moveDown(0.6);
    } else if (b.type === "list") {
      for (const item of b.items) writeInlines([{ text: "-  " }, ...item], 10, { indent: 8 });
      doc.moveDown(0.6);
    } else {
      const y = doc.y + 4;
      doc.moveTo(M.left, y).lineTo(width - M.right, y).strokeColor("#d6d2c8").lineWidth(0.6).stroke();
      doc.moveDown(1);
    }
    first = false;
  }

  const footer = clean(brand.documentFooter?.trim() || defaultFooter(brand));
  const range = doc.bufferedPageRange();
  for (let p = range.start; p < range.start + range.count; p++) {
    doc.switchToPage(p);
    const bottom = doc.page.margins.bottom;
    doc.page.margins.bottom = 0;
    const y = doc.page.height - 48;
    doc.moveTo(M.left, y - 8).lineTo(width - M.right, y - 8).strokeColor(accent).lineWidth(0.6).stroke();
    doc.font("Helvetica").fontSize(7).fillColor(muted);
    doc.text(footer, M.left, y, { width: contentWidth - 90, lineBreak: false, ellipsis: true });
    doc.text(`page ${p + 1} / ${range.count}`, width - M.right - 80, y, { width: 80, align: "right", lineBreak: false });
    if (meta.reference) doc.text(clean(`Réf. ${meta.reference}`), M.left, y + 10, { width: contentWidth, lineBreak: false });
    doc.page.margins.bottom = bottom;
  }
  doc.end();
  return done;
}

const runs = (inlines: Inline[]) =>
  inlines.flatMap((i) =>
    i.text.split("\n").map(
      (part, idx) =>
        new TextRun({
          text: part,
          bold: i.bold,
          ...(idx > 0 ? { break: 1 } : {}),
          ...(i.marker ? { highlight: "yellow", color: "7A4F00" } : {}),
        }),
    ),
  );

/** Export DOCX avec en-tête (logo, raison sociale) et pied de page (texte, numéro de page). */
export async function renderBrandedDocx(markdown: string, meta: BrandedMeta): Promise<Buffer> {
  const brand = meta.brand;
  const accent = safeHex(brand.primaryColor).slice(1).toUpperCase();
  const logoKind = imageKind(brand.logo);
  const headerChildren: Paragraph[] = [];
  if (logoKind && brand.logo) {
    headerChildren.push(
      new Paragraph({
        children: [new ImageRun({ type: logoKind === "png" ? "png" : "jpg", data: brand.logo, transformation: { width: 96, height: 40 }, altText: { title: "Logo", description: "Logo de l'organisme", name: "logo" } })],
      }),
    );
  }
  headerChildren.push(new Paragraph({ children: [new TextRun({ text: brand.tradeName ?? brand.legalName, bold: true, size: 20 })] }));
  const line2 = brand.documentHeader?.trim() || [brand.siret ? `SIRET ${brand.siret}` : null, brand.nda ? `NDA ${brand.nda}` : null].filter(Boolean).join("  |  ");
  headerChildren.push(new Paragraph({ children: [new TextRun({ text: line2, size: 15, color: "6B6760" })], border: { bottom: { style: "single", size: 8, color: accent, space: 4 } } }));

  const children: Paragraph[] = [];
  for (const b of parseMarkdown(markdown)) {
    if (b.type === "heading") {
      children.push(
        new Paragraph({
          heading: b.level === 1 ? HeadingLevel.HEADING_1 : b.level === 2 ? HeadingLevel.HEADING_2 : HeadingLevel.HEADING_3,
          children: b.inlines.flatMap((i) => i.text.split("\n").map((part, idx) => new TextRun({ text: part, bold: true, color: b.level < 3 ? accent : undefined, ...(idx > 0 ? { break: 1 } : {}) }))),
          spacing: { before: 240, after: 120 },
        }),
      );
    } else if (b.type === "paragraph") {
      children.push(new Paragraph({ children: runs(b.inlines), spacing: { after: 160 }, alignment: AlignmentType.LEFT }));
    } else if (b.type === "list") {
      for (const item of b.items) children.push(new Paragraph({ bullet: { level: 0 }, children: runs(item) }));
    } else {
      children.push(new Paragraph({ border: { bottom: { style: "single", size: 6, color: "D6D2C8", space: 1 } }, children: [] }));
    }
  }
  const footerText = brand.documentFooter?.trim() || defaultFooter(brand);
  const doc = new Document({
    creator: "Next Formation",
    title: meta.title,
    styles: { default: { document: { run: { font: "Calibri", size: 21 } } } },
    sections: [
      {
        headers: { default: new Header({ children: headerChildren }) },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                children: [new TextRun({ text: `${footerText}   `, size: 14, color: "6B6760" }), new TextRun({ children: ["page ", PageNumber.CURRENT, " / ", PageNumber.TOTAL_PAGES], size: 14, color: "6B6760" })],
                alignment: AlignmentType.CENTER,
              }),
            ],
          }),
        },
        children,
      },
    ],
  });
  return Packer.toBuffer(doc);
}
