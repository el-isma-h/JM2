import "server-only";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";

export type NumberingKey = "enrollment" | "session" | "invoice" | "credit" | "quote";

/**
 * Préfixe de numérotation paramétré (`settings.numbering`, écran Paramètres) avec repli sur le préfixe historique.
 * Lecture simple : la séquence elle-même reste atomique dans la transaction appelante.
 */
export async function numberingPrefix(orgId: string, key: NumberingKey, fallback: string): Promise<string> {
  const [org] = await db.select({ settings: schema.organismes.settings }).from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  const numbering = ((org?.settings ?? {}) as { numbering?: Partial<Record<NumberingKey, string>> }).numbering ?? {};
  const v = numbering[key];
  return typeof v === "string" && /^[A-Z0-9]{1,6}$/.test(v) ? v : fallback;
}
