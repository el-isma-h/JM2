/**
 * Moteur d'analyse de conformité (F13) : fonctions pures, sans accès base, testées.
 * La persistance (photographie immuable `quality_analyses`) est dans `./analysis.ts`.
 *
 * Pour un périmètre (organisme / session / inscription / programme) et une date de référence, chaque indicateur
 * applicable du référentiel actif est classé :
 *  - prouve         : au moins une preuve valide reliée au périmètre et datée au plus tard à la date de référence ;
 *  - absent         : aucune preuve valide ;
 *  - non_applicable : hors activité (OF / CFA) ou niveau de preuve sans objet pour le périmètre ;
 *  - a_examiner     : l'indicateur demande une appréciation humaine (preuve présente), ou la seule preuve
 *                     disponible a été invalidée ou remplacée depuis.
 * Une preuve collective (session) compte une fois, jamais une fois par apprenant.
 * Un pourcentage de preuves n'est pas une attestation de conformité.
 */

import type { Activity, AnalysisScope, CriterionDef, EvidenceLevel, IndicatorDef } from "./referential-data";
import { flattenIndicators } from "./referential-data";

export const ENGINE_VERSION = "1.0.0";
export const COVERAGE_DISCLAIMER = "Un pourcentage de preuves n'est pas une attestation de conformité.";

export type ControlStatus = "prouve" | "absent" | "non_applicable" | "a_examiner";

export type EvidenceInput = {
  id: string;
  indicatorCode: string;
  level: EvidenceLevel;
  status: "valide" | "invalidee" | "remplacee";
  /** Date ISO YYYY-MM-DD de la preuve (à défaut, date de création). */
  evidenceDate: string | null;
  createdAt: string;
  enrollmentId: string | null;
  sessionId: string | null;
  programId: string | null;
  invalidationReason?: string | null;
};

/** Contexte du périmètre : entités rattachées (calculées par l'appelant à partir de la base). */
export type ScopeContext = {
  scope: AnalysisScope;
  scopeId: string | null;
  /** Sessions du périmètre (session elle-même, sessions du programme, session de l'inscription). */
  sessionIds: string[];
  /** Inscriptions du périmètre. */
  enrollmentIds: string[];
  programIds: string[];
};

export type Control = {
  indicator: string;
  number: number;
  criterion: number;
  label: string;
  level: EvidenceLevel;
  requiresHuman: boolean;
  status: ControlStatus;
  evidenceIds: string[];
  evidenceCount: number;
  note: string;
};

export type Summary = {
  total: number;
  proven: number;
  missing: number;
  notApplicable: number;
  humanReview: number;
  /** prouvé / (total - non applicable), arrondi ; 0 si aucun indicateur applicable. */
  coveragePct: number;
  disclaimer: string;
};

export type AnalysisResult = { engineVersion: string; referenceDate: string; controls: Control[]; summary: Summary };

/** Activités d'un organisme selon son type. */
export function orgActivities(kind: "of" | "cfa" | "of_cfa"): Activity[] {
  return kind === "of_cfa" ? ["of", "cfa"] : [kind];
}

/** Niveaux de preuve pertinents selon le périmètre analysé. */
export function levelsForScope(scope: AnalysisScope): EvidenceLevel[] {
  switch (scope) {
    case "organisme":
      return ["individuel", "collectif", "organisationnel"];
    case "session":
    case "programme":
      return ["individuel", "collectif"];
    case "inscription":
      return ["individuel", "collectif"];
  }
}

/** Vrai si la preuve est reliée au périmètre (organisme : toutes ; session : session ou inscriptions de la session…). */
export function evidenceInScope(e: EvidenceInput, ctx: ScopeContext): boolean {
  if (ctx.scope === "organisme") return true;
  if (ctx.scope === "inscription") {
    if (e.enrollmentId && e.enrollmentId === ctx.scopeId) return true;
    // Preuve collective de la session de l'inscription (comptée une fois, non dupliquée par apprenant).
    if (e.level === "collectif" && e.sessionId && ctx.sessionIds.includes(e.sessionId) && !e.enrollmentId) return true;
    return false;
  }
  if (e.sessionId && ctx.sessionIds.includes(e.sessionId)) return true;
  if (e.enrollmentId && ctx.enrollmentIds.includes(e.enrollmentId)) return true;
  if (e.programId && ctx.programIds.includes(e.programId)) return true;
  return false;
}

function effectiveDate(e: EvidenceInput): string {
  return e.evidenceDate ?? e.createdAt.slice(0, 10);
}

function uniq<T>(xs: T[]): T[] {
  return [...new Set(xs)];
}

/** Classement d'un indicateur à partir des preuves du périmètre. */
export function classifyIndicator(def: IndicatorDef, evidences: EvidenceInput[], ctx: ScopeContext, referenceDate: string, activities: Activity[]): Control {
  const base = { indicator: def.code, number: def.number, criterion: def.criterion, label: def.label, level: def.level, requiresHuman: def.requiresHuman };
  if (!def.applicability.some((a) => activities.includes(a))) {
    return { ...base, status: "non_applicable", evidenceIds: [], evidenceCount: 0, note: `Indicateur réservé à l'activité ${def.applicability.map((a) => a.toUpperCase()).join(" / ")} : hors périmètre de l'organisme.` };
  }
  if (!levelsForScope(ctx.scope).includes(def.level)) {
    return { ...base, status: "non_applicable", evidenceIds: [], evidenceCount: 0, note: `Preuve de niveau ${def.level} : sans objet pour une analyse de périmètre « ${ctx.scope} » (voir l'analyse de l'organisme).` };
  }
  const related = evidences.filter((e) => e.indicatorCode === def.code && evidenceInScope(e, ctx));
  const dated = related.filter((e) => effectiveDate(e) <= referenceDate);
  const ignoredFuture = related.length - dated.length;
  const valid = dated.filter((e) => e.status === "valide");
  const invalidated = dated.filter((e) => e.status !== "valide");
  const validIds = uniq(valid.map((e) => e.id));
  const suffix = ignoredFuture ? ` ${ignoredFuture} preuve(s) postérieure(s) à la date de référence ignorée(s).` : "";

  if (validIds.length) {
    if (def.requiresHuman) {
      return { ...base, status: "a_examiner", evidenceIds: validIds, evidenceCount: validIds.length, note: `${validIds.length} preuve(s) reliée(s) : cet indicateur demande une appréciation humaine, il n'est jamais prouvé automatiquement.${suffix}` };
    }
    return { ...base, status: "prouve", evidenceIds: validIds, evidenceCount: validIds.length, note: `${validIds.length} preuve(s) valide(s) reliée(s) au périmètre.${suffix}` };
  }
  if (invalidated.length) {
    const reasons = uniq(invalidated.map((e) => e.invalidationReason).filter(Boolean) as string[]);
    return {
      ...base,
      status: "a_examiner",
      evidenceIds: uniq(invalidated.map((e) => e.id)),
      evidenceCount: 0,
      note: `Aucune preuve valide : ${invalidated.length} preuve(s) invalidée(s) ou remplacée(s) depuis${reasons.length ? ` (${reasons.join(" ; ")})` : ""}. À examiner par un humain.${suffix}`,
    };
  }
  return { ...base, status: "absent", evidenceIds: [], evidenceCount: 0, note: `Aucune preuve reliée au périmètre à la date de référence.${def.requiresHuman ? " Une fois la preuve produite, une appréciation humaine restera nécessaire." : ""}${suffix}` };
}

export function summarize(controls: Control[]): Summary {
  const total = controls.length;
  const proven = controls.filter((c) => c.status === "prouve").length;
  const missing = controls.filter((c) => c.status === "absent").length;
  const notApplicable = controls.filter((c) => c.status === "non_applicable").length;
  const humanReview = controls.filter((c) => c.status === "a_examiner").length;
  const applicable = total - notApplicable;
  return { total, proven, missing, notApplicable, humanReview, coveragePct: applicable ? Math.round((proven / applicable) * 100) : 0, disclaimer: COVERAGE_DISCLAIMER };
}

/** Analyse complète (pure) : référentiel (critères), activités de l'organisme, périmètre, preuves, date de référence. */
export function analyze(input: { criteria: CriterionDef[]; activities: Activity[]; ctx: ScopeContext; evidences: EvidenceInput[]; referenceDate: string }): AnalysisResult {
  const defs = flattenIndicators(input.criteria).sort((a, b) => a.number - b.number);
  const controls = defs.map((d) => classifyIndicator(d, input.evidences, input.ctx, input.referenceDate, input.activities));
  return { engineVersion: ENGINE_VERSION, referenceDate: input.referenceDate, controls, summary: summarize(controls) };
}

/**
 * Vrai si une preuve du périmètre a été créée ou modifiée (invalidation, remplacement) après l'instant de l'analyse :
 * l'analyse reste inchangée, l'écran invite à en relancer une nouvelle.
 */
export function evidencesChangedSince(evidences: { updatedAt: string | Date; createdAt: string | Date }[], analysedAt: string | Date): boolean {
  const t = new Date(analysedAt).getTime();
  return evidences.some((e) => new Date(e.updatedAt).getTime() > t || new Date(e.createdAt).getTime() > t);
}

export const controlStatusLabels: Record<ControlStatus, string> = {
  prouve: "Prouvé",
  absent: "Absent",
  non_applicable: "Non applicable",
  a_examiner: "À examiner (humain)",
};
