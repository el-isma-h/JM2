import { addDays, format, parseISO } from "date-fns";

/** Règles pures de l'envoi automatique des enquêtes (testées sans base). */

export type Automation = { trigger?: string; delayDays?: number; fromSurveyId?: string; lastRunAt?: string };

export function readAutomation(raw: unknown): Automation {
  const o = (raw && typeof raw === "object" ? raw : {}) as Automation;
  return { trigger: o.trigger, delayDays: Number.isFinite(Number(o.delayDays)) ? Math.max(0, Number(o.delayDays)) : 0, fromSurveyId: o.fromSurveyId, lastRunAt: o.lastRunAt };
}

/** Vrai si la session (terminée) est éligible à l'envoi : date de fin + délai ≤ aujourd'hui (Europe/Paris). */
export function sessionDue(endDate: string, delayDays: number, today: string): boolean {
  return format(addDays(parseISO(endDate), delayDays), "yyyy-MM-dd") <= today;
}
