import { describe, expect, it } from "vitest";
import { applicablePieces, canTransitionEnrollment, formatReference, parseAppliesTo, pieceApplies, pieceDueDate } from "../rules";

const base = { isActive: true, isRequired: true };

describe("pièces attendues : appliesTo", () => {
  it("« * » s'applique à tout contrat et tout financement", () => {
    const p = { ...base, code: "piece_identite", appliesTo: { contractKinds: ["*"], fundingKinds: ["*"] } };
    expect(pieceApplies(p, { contractKind: "convention_formation" })).toBe(true);
    expect(pieceApplies(p, { contractKind: "contrat_apprentissage", fundingKinds: ["opco"] })).toBe(true);
  });

  it("filtre par type de contrat", () => {
    const p = { ...base, code: "cerfa", appliesTo: { contractKinds: ["contrat_apprentissage"], fundingKinds: ["*"] } };
    expect(pieceApplies(p, { contractKind: "contrat_apprentissage" })).toBe(true);
    expect(pieceApplies(p, { contractKind: "convention_formation" })).toBe(false);
  });

  it("une pièce liée au financement n'est pas attendue tant que le financement est à définir", () => {
    const p = { ...base, code: "accord", appliesTo: { contractKinds: ["*"], fundingKinds: ["opco", "cpf"] } };
    expect(pieceApplies(p, { contractKind: "convention_formation" })).toBe(false);
    expect(pieceApplies(p, { contractKind: "convention_formation", fundingKinds: ["entreprise"] })).toBe(false);
    expect(pieceApplies(p, { contractKind: "convention_formation", fundingKinds: ["cpf"] })).toBe(true);
  });

  it("une pièce inactive n'est jamais attendue", () => {
    const p = { ...base, isActive: false, code: "x", appliesTo: { contractKinds: ["*"], fundingKinds: ["*"] } };
    expect(pieceApplies(p, { contractKind: "cpf" })).toBe(false);
  });

  it("filtre par activité (OF / CFA) quand précisé", () => {
    const p = { ...base, code: "x", appliesTo: { contractKinds: ["*"], fundingKinds: ["*"], activity: ["cfa"] } };
    expect(pieceApplies(p, { contractKind: "contrat_apprentissage", activity: "cfa" })).toBe(true);
    expect(pieceApplies(p, { contractKind: "contrat_apprentissage", activity: "of" })).toBe(false);
    expect(pieceApplies(p, { contractKind: "contrat_apprentissage" })).toBe(true);
  });

  it("tolère un JSON vide ou mal formé (= tout)", () => {
    expect(parseAppliesTo(null)).toEqual({ contractKinds: ["*"], fundingKinds: ["*"], activity: ["*"] });
    expect(parseAppliesTo({ contractKinds: [] })).toEqual({ contractKinds: ["*"], fundingKinds: ["*"], activity: ["*"] });
    expect(parseAppliesTo("n'importe quoi")).toEqual({ contractKinds: ["*"], fundingKinds: ["*"], activity: ["*"] });
  });

  it("applicablePieces conserve l'ordre et ne garde que les pièces pertinentes", () => {
    const pieces = [
      { ...base, code: "a", appliesTo: { contractKinds: ["*"] } },
      { ...base, code: "b", appliesTo: { contractKinds: ["stage"] } },
      { ...base, code: "c", appliesTo: { contractKinds: ["*"], fundingKinds: ["opco"] } },
    ];
    expect(applicablePieces(pieces, { contractKind: "stage", fundingKinds: ["opco"] }).map((p) => p.code)).toEqual(["a", "b", "c"]);
    expect(applicablePieces(pieces, { contractKind: "cpf" }).map((p) => p.code)).toEqual(["a"]);
  });

  it("calcule l'échéance N jours avant le début", () => {
    expect(pieceDueDate({ dueDaysBeforeStart: 7 }, "2026-03-02")).toBe("2026-02-23");
    expect(pieceDueDate({ dueDaysBeforeStart: 0 }, "2026-03-02")).toBe("2026-03-02");
    expect(pieceDueDate({ dueDaysBeforeStart: null }, "2026-03-02")).toBeNull();
    expect(pieceDueDate({ dueDaysBeforeStart: 3 }, null)).toBeNull();
  });
});

describe("transitions de statut d'inscription", () => {
  it("suit le cycle préinscrit → inscrit → en cours → terminé", () => {
    expect(canTransitionEnrollment("preinscrit", "inscrit")).toEqual({ ok: true });
    expect(canTransitionEnrollment("inscrit", "en_cours")).toEqual({ ok: true });
    expect(canTransitionEnrollment("en_cours", "termine")).toEqual({ ok: true });
  });

  it("refuse les sauts et les retours non tracés", () => {
    expect(canTransitionEnrollment("preinscrit", "termine").ok).toBe(false);
    expect(canTransitionEnrollment("termine", "en_cours").ok).toBe(false);
    expect(canTransitionEnrollment("inscrit", "inscrit").ok).toBe(false);
  });

  it("exige un motif pour les sorties", () => {
    expect(canTransitionEnrollment("en_cours", "abandon").ok).toBe(false);
    expect(canTransitionEnrollment("en_cours", "abandon", { reason: "Rupture du contrat" })).toEqual({ ok: true });
    expect(canTransitionEnrollment("inscrit", "annule", { reason: " " }).ok).toBe(false);
  });

  it("formate la référence INS-AAAA-NNNN", () => {
    expect(formatReference("INS", 2026, 7)).toBe("INS-2026-0007");
    expect(formatReference("INS", 2026, 12345)).toBe("INS-2026-12345");
  });
});
