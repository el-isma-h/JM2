/**
 * Définition des imports guidés (T03) : colonnes attendues par entité, exemples et clés de doublon.
 * Pur (sans accès serveur) : réutilisé par les modèles CSV, l'association de colonnes et la validation.
 */

export type ImportKind = "entreprises" | "contacts" | "personnes" | "inscriptions" | "heures";

export type ImportField = { key: string; label: string; required?: boolean; hint?: string; aliases?: string[] };

export type ImportKindDef = {
  kind: ImportKind;
  label: string;
  description: string;
  target: string;
  fields: ImportField[];
  /** Règle de détection des doublons (affichée à l'utilisateur). */
  duplicateRule: string;
  example: Record<string, string>;
};

export const IMPORT_KINDS: Record<ImportKind, ImportKindDef> = {
  entreprises: {
    kind: "entreprises",
    label: "Entreprises",
    description: "Employeurs, entreprises d'accueil, prospects.",
    target: "companies",
    duplicateRule: "SIRET identique, sinon raison sociale identique (insensible à la casse).",
    fields: [
      { key: "name", label: "Raison sociale", required: true, aliases: ["raison sociale", "nom", "entreprise", "societe", "société"] },
      { key: "siret", label: "SIRET", aliases: ["siret"] },
      { key: "siren", label: "SIREN", aliases: ["siren"] },
      { key: "apeCode", label: "Code APE", aliases: ["ape", "naf", "code ape", "code naf"] },
      { key: "opco", label: "OPCO", aliases: ["opco"] },
      { key: "addressLine1", label: "Adresse", aliases: ["adresse", "rue"] },
      { key: "postalCode", label: "Code postal", aliases: ["cp", "code postal"] },
      { key: "city", label: "Ville", aliases: ["ville", "commune"] },
      { key: "email", label: "E-mail", aliases: ["email", "e-mail", "mail", "courriel"] },
      { key: "phone", label: "Téléphone", aliases: ["telephone", "téléphone", "tel", "tél"] },
      { key: "status", label: "Statut (prospect, client, partenaire, inactif)", hint: "Par défaut : client", aliases: ["statut"] },
    ],
    example: { name: "Menuiserie Vautrin", siret: "83912345600017", siren: "839123456", apeCode: "1623Z", opco: "Constructys", addressLine1: "4 impasse des Chênes", postalCode: "54000", city: "Nancy", email: "contact@vautrin.example", phone: "03 83 00 00 00", status: "client" },
  },
  contacts: {
    kind: "contacts",
    label: "Contacts d'entreprise",
    description: "Dirigeants, RH, tuteurs, signataires.",
    target: "contacts",
    duplicateRule: "E-mail identique dans l'organisme.",
    fields: [
      { key: "lastName", label: "Nom", required: true, aliases: ["nom", "nom de famille"] },
      { key: "firstName", label: "Prénom", required: true, aliases: ["prenom", "prénom"] },
      { key: "email", label: "E-mail", aliases: ["email", "e-mail", "mail", "courriel"] },
      { key: "phone", label: "Téléphone", aliases: ["telephone", "téléphone", "tel"] },
      { key: "jobTitle", label: "Fonction", aliases: ["fonction", "poste"] },
      { key: "companySiret", label: "SIRET de l'entreprise", hint: "Ou raison sociale ci-dessous", aliases: ["siret", "siret entreprise"] },
      { key: "companyName", label: "Raison sociale de l'entreprise", aliases: ["entreprise", "raison sociale", "societe", "société"] },
      { key: "isTutor", label: "Tuteur (oui/non)", aliases: ["tuteur"] },
      { key: "isSignatory", label: "Signataire (oui/non)", aliases: ["signataire"] },
    ],
    example: { lastName: "Vautrin", firstName: "Claire", email: "claire.vautrin@vautrin.example", phone: "06 12 34 56 78", jobTitle: "Gérante", companySiret: "83912345600017", companyName: "Menuiserie Vautrin", isTutor: "oui", isSignatory: "oui" },
  },
  personnes: {
    kind: "personnes",
    label: "Personnes (candidats, apprenants)",
    description: "Fiches individuelles réutilisées par les inscriptions.",
    target: "persons",
    duplicateRule: "E-mail identique, sinon nom + prénom + date de naissance identiques.",
    fields: [
      { key: "lastName", label: "Nom", required: true, aliases: ["nom", "nom de famille"] },
      { key: "firstName", label: "Prénom", required: true, aliases: ["prenom", "prénom"] },
      { key: "birthDate", label: "Date de naissance", hint: "JJ/MM/AAAA ou AAAA-MM-JJ", aliases: ["date de naissance", "naissance", "ddn"] },
      { key: "civility", label: "Civilité (M, Mme)", aliases: ["civilite", "civilité"] },
      { key: "email", label: "E-mail", aliases: ["email", "e-mail", "mail", "courriel"] },
      { key: "phone", label: "Téléphone", aliases: ["telephone", "téléphone", "tel", "portable"] },
      { key: "addressLine1", label: "Adresse", aliases: ["adresse"] },
      { key: "postalCode", label: "Code postal", aliases: ["cp", "code postal"] },
      { key: "city", label: "Ville", aliases: ["ville"] },
      { key: "status", label: "Statut (candidat, apprenant, ancien)", hint: "Par défaut : candidat", aliases: ["statut"] },
      { key: "companySiret", label: "SIRET employeur", aliases: ["siret employeur", "siret"] },
      { key: "externalId", label: "Identifiant d'origine", hint: "Conservé dans les identifiants (reprise)", aliases: ["id", "identifiant", "id galaxy", "ancien id"] },
    ],
    example: { lastName: "Okonkwo", firstName: "Adaeze", birthDate: "14/03/2001", civility: "Mme", email: "adaeze.okonkwo@example.net", phone: "07 11 22 33 44", addressLine1: "12 rue Pasteur", postalCode: "69007", city: "Lyon", status: "apprenant", companySiret: "", externalId: "GLX-10482" },
  },
  inscriptions: {
    kind: "inscriptions",
    label: "Inscriptions",
    description: "Historique et inscriptions en cours : la personne et la session doivent déjà exister.",
    target: "enrollments",
    duplicateRule: "Référence identique, ou même personne déjà inscrite (statut actif) sur la même session.",
    fields: [
      { key: "personEmail", label: "E-mail de la personne", hint: "Ou nom + prénom + date de naissance", aliases: ["email", "e-mail", "mail"] },
      { key: "lastName", label: "Nom", aliases: ["nom"] },
      { key: "firstName", label: "Prénom", aliases: ["prenom", "prénom"] },
      { key: "birthDate", label: "Date de naissance", aliases: ["date de naissance", "naissance"] },
      { key: "sessionCode", label: "Code de la session", required: true, aliases: ["session", "code session", "code"] },
      { key: "reference", label: "Référence d'inscription", hint: "Conservée si fournie (ex. ancienne référence), sinon générée", aliases: ["reference", "référence", "ref"] },
      { key: "status", label: "Statut (preinscrit, inscrit, en_cours, termine, abandon, annule)", hint: "Par défaut : inscrit", aliases: ["statut", "etat", "état"] },
      { key: "contractKind", label: "Type de contrat", hint: "convention_formation, contrat_apprentissage, contrat_professionnalisation, cpf, stage, contrat_particulier, autre", aliases: ["contrat", "type de contrat"] },
      { key: "startDate", label: "Début du parcours", aliases: ["debut", "début", "date debut", "date de début"] },
      { key: "endDate", label: "Fin du parcours", aliases: ["fin", "date fin", "date de fin"] },
      { key: "hoursPlanned", label: "Heures prévues", aliases: ["heures", "heures prevues", "heures prévues", "duree", "durée"] },
      { key: "companySiret", label: "SIRET entreprise", aliases: ["siret", "siret entreprise"] },
      { key: "legacyHours", label: "Solde d'heures historique", hint: "Heures d'anciennes feuilles non réconciliées (distinct des heures justifiées)", aliases: ["solde heures", "heures historiques"] },
    ],
    example: { personEmail: "adaeze.okonkwo@example.net", lastName: "Okonkwo", firstName: "Adaeze", birthDate: "14/03/2001", sessionCode: "SES-2025-0003", reference: "GLX-INS-2210", status: "termine", contractKind: "contrat_apprentissage", startDate: "02/09/2024", endDate: "27/06/2025", hoursPlanned: "675", companySiret: "83912345600017", legacyHours: "612" },
  },
  heures: {
    kind: "heures",
    label: "Historique d'heures (anciennes feuilles)",
    description: "Feuilles journalières historiques : conservées telles quelles, jamais converties en présences par période.",
    target: "legacy_attendance_sheets",
    duplicateRule: "Même inscription et même date déjà importées.",
    fields: [
      { key: "reference", label: "Référence d'inscription", hint: "Ou e-mail + code de session", aliases: ["reference", "référence", "ref", "inscription"] },
      { key: "personEmail", label: "E-mail de la personne", aliases: ["email", "e-mail", "mail"] },
      { key: "sessionCode", label: "Code de la session", aliases: ["session", "code session"] },
      { key: "date", label: "Date", required: true, aliases: ["date", "jour"] },
      { key: "hours", label: "Heures (ex. 6 ou 3,5)", required: true, aliases: ["heures", "duree", "durée", "nb heures"] },
      { key: "signed", label: "Signée (oui/non)", aliases: ["signe", "signé", "signee", "signée", "emargee", "émargée"] },
      { key: "source", label: "Source", hint: "Ex. feuille papier, Galaxy", aliases: ["source", "origine"] },
      { key: "note", label: "Note", aliases: ["note", "commentaire", "observation"] },
    ],
    example: { reference: "GLX-INS-2210", personEmail: "", sessionCode: "", date: "16/09/2024", hours: "6", signed: "oui", source: "Feuille papier scannée", note: "" },
  },
};

export const IMPORT_KIND_LIST = Object.values(IMPORT_KINDS);

export function isImportKind(v: unknown): v is ImportKind {
  return typeof v === "string" && v in IMPORT_KINDS;
}

function norm(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

/** Association automatique des colonnes du fichier aux champs attendus (nom exact, alias, puis inclusion). */
export function autoMap(kind: ImportKind, headers: string[]): Record<string, string> {
  const def = IMPORT_KINDS[kind];
  const mapping: Record<string, string> = {};
  const used = new Set<string>();
  const normalized = headers.map((h) => ({ raw: h, n: norm(h) }));
  for (const f of def.fields) {
    const candidates = [f.key, f.label, ...(f.aliases ?? [])].map(norm);
    let hit = normalized.find((h) => !used.has(h.raw) && candidates.includes(h.n));
    if (!hit) hit = normalized.find((h) => !used.has(h.raw) && candidates.some((c) => c.length > 2 && (h.n === c || h.n.startsWith(`${c} `) || h.n.endsWith(` ${c}`))));
    if (hit) {
      mapping[f.key] = hit.raw;
      used.add(hit.raw);
    }
  }
  return mapping;
}

/** Génère le modèle CSV (en-têtes = clés techniques lisibles, une ligne d'exemple), séparateur point-virgule. */
export function templateCsv(kind: ImportKind): string {
  const def = IMPORT_KINDS[kind];
  const esc = (v: string) => (/[;"\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);
  const header = def.fields.map((f) => esc(f.label)).join(";");
  const row = def.fields.map((f) => esc(def.example[f.key] ?? "")).join(";");
  return `﻿${header}\n${row}\n`;
}

export function toCsv(headers: string[], rows: (string | number | null | undefined)[][]): string {
  const esc = (v: string | number | null | undefined) => {
    const s = v === null || v === undefined ? "" : String(v);
    return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return `﻿${headers.map(esc).join(";")}\n${rows.map((r) => r.map(esc).join(";")).join("\n")}\n`;
}

export function parseBool(v: string | undefined | null): boolean {
  const s = (v ?? "").trim().toLowerCase();
  return ["oui", "o", "yes", "y", "true", "1", "x", "vrai"].includes(s);
}

/** « 3,5 » / « 3.5 » / « 3h30 » → minutes ; null si invalide. */
export function parseHoursToMinutes(v: string | undefined | null): number | null {
  const s = (v ?? "").trim().toLowerCase().replace(/\s/g, "");
  if (!s) return null;
  const hm = /^(\d{1,3})h(\d{1,2})?$/.exec(s);
  if (hm) return Number(hm[1]) * 60 + Number(hm[2] ?? 0);
  const dec = s.replace(",", ".");
  if (!/^\d{1,3}(\.\d{1,2})?$/.test(dec)) return null;
  return Math.round(Number(dec) * 60);
}
