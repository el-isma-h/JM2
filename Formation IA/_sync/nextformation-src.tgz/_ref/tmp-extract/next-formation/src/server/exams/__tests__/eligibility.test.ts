import { describe, expect, it } from "vitest";
import { checkEligibility, examStateForResult, resultAllowed } from "../eligibility";

const cohort = { orgId: "A", programId: "P1", capacity: 2, status: "ouverte", membersCount: 0 };

describe("éligibilité examen (R06)", () => {
  it("inscription terminée de la même formation : éligible", () => {
    expect(checkEligibility({ cohort, enrollment: { orgId: "A", programId: "P1", status: "termine" }, alreadyMember: false }).ok).toBe(true);
    expect(checkEligibility({ cohort, enrollment: { orgId: "A", programId: "P1", status: "en_cours" }, alreadyMember: false }).ok).toBe(true);
  });
  it("autre organisme, autre formation, statut non admis : refusés", () => {
    expect(checkEligibility({ cohort, enrollment: { orgId: "B", programId: "P1", status: "inscrit" }, alreadyMember: false }).ok).toBe(false);
    expect(checkEligibility({ cohort, enrollment: { orgId: "A", programId: "P2", status: "inscrit" }, alreadyMember: false }).ok).toBe(false);
    expect(checkEligibility({ cohort, enrollment: { orgId: "A", programId: "P1", status: "abandon" }, alreadyMember: false }).ok).toBe(false);
    expect(checkEligibility({ cohort, enrollment: { orgId: "A", programId: "P1", status: "preinscrit" }, alreadyMember: false }).ok).toBe(false);
    expect(checkEligibility({ cohort, enrollment: null, alreadyMember: false }).ok).toBe(false);
  });
  it("doublon et capacité", () => {
    expect(checkEligibility({ cohort, enrollment: { orgId: "A", programId: "P1", status: "inscrit" }, alreadyMember: true }).ok).toBe(false);
    expect(checkEligibility({ cohort: { ...cohort, membersCount: 2 }, enrollment: { orgId: "A", programId: "P1", status: "inscrit" }, alreadyMember: false }).ok).toBe(false);
  });
  it("cohorte terminée ou annulée", () => {
    expect(checkEligibility({ cohort: { ...cohort, status: "terminee" }, enrollment: { orgId: "A", programId: "P1", status: "inscrit" }, alreadyMember: false }).ok).toBe(false);
  });
  it("état d'examen de l'inscription selon le résultat", () => {
    expect(examStateForResult("admis")).toBe("admis");
    expect(examStateForResult("ajourne")).toBe("ajourne");
    expect(examStateForResult("partiel")).toBe("rattrapage");
    expect(examStateForResult("absent")).toBe("absent");
  });
  it("options partiel / rattrapage de la cohorte", () => {
    expect(resultAllowed("partiel", { partial: false }).ok).toBe(false);
    expect(resultAllowed("rattrapage", { retake: true }).ok).toBe(true);
    expect(resultAllowed("admis", null).ok).toBe(true);
  });
});
