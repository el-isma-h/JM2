import "server-only";
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { fmtDateTime } from "@/lib/dates";
import type { NotificationItem } from "@/components/app/notifications";

/** Dernières notifications de l'utilisateur dans cet organisme, avec le nombre de non lues. */
export async function listNotifications(ctx: OrgContext, limit = 20): Promise<{ items: NotificationItem[]; unread: number }> {
  const [rows, [u]] = await Promise.all([
    db
      .select()
      .from(schema.notifications)
      .where(and(eq(schema.notifications.orgId, ctx.org.id), eq(schema.notifications.userId, ctx.user.id)))
      .orderBy(desc(schema.notifications.createdAt))
      .limit(limit),
    db
      .select({ n: sql<number>`count(*)::int` })
      .from(schema.notifications)
      .where(and(eq(schema.notifications.orgId, ctx.org.id), eq(schema.notifications.userId, ctx.user.id), isNull(schema.notifications.readAt))),
  ]);
  return {
    items: rows.map((r) => ({ id: r.id, title: r.title, body: r.body, href: r.href, kind: r.kind, createdAt: fmtDateTime(r.createdAt), read: Boolean(r.readAt) })),
    unread: u?.n ?? 0,
  };
}
