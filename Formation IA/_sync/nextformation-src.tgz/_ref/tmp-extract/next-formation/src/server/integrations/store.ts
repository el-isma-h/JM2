import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { decrypt, encrypt } from "@/lib/crypto";

export type IntegrationKind = (typeof schema.integrationKindEnum.enumValues)[number];
export type IntegrationStatus = (typeof schema.integrationStatusEnum.enumValues)[number];
export type IntegrationRow = typeof schema.orgIntegrations.$inferSelect;

export const integrationKindLabels: Record<IntegrationKind, string> = {
  moodle: "Moodle",
  microsoft365: "Microsoft 365 / SharePoint",
  edof: "EDOF (Mon Compte Formation)",
  zapier: "Zapier",
  webhook: "Webhooks",
  wordpress: "WordPress (catalogue)",
  yousign: "Signature électronique",
  stripe: "Paiement en ligne (Stripe)",
  comptabilite: "Export comptable",
  sms: "SMS",
  chorus: "Chorus Pro (factures publiques)",
};

export async function listIntegrations(orgId: string): Promise<Record<string, IntegrationRow>> {
  const rows = await db.select().from(schema.orgIntegrations).where(eq(schema.orgIntegrations.orgId, orgId));
  return Object.fromEntries(rows.map((r) => [r.kind, r]));
}

export async function getIntegration(orgId: string, kind: IntegrationKind): Promise<IntegrationRow | null> {
  const [r] = await db.select().from(schema.orgIntegrations).where(and(eq(schema.orgIntegrations.orgId, orgId), eq(schema.orgIntegrations.kind, kind))).limit(1);
  return r ?? null;
}

/** Secrets déchiffrés d'une intégration (jamais renvoyés au navigateur). */
export function readSecrets<T extends Record<string, string>>(row: IntegrationRow | null): T | null {
  if (!row?.secretsEnc) return null;
  try {
    return JSON.parse(decrypt(row.secretsEnc, "integration")) as T;
  } catch {
    return null;
  }
}

export async function upsertIntegration(orgId: string, kind: IntegrationKind, input: { config?: Record<string, unknown>; secrets?: Record<string, string> | null; status?: IntegrationStatus; lastError?: string | null; lastSyncAt?: Date | null }) {
  const existing = await getIntegration(orgId, kind);
  const config = { ...((existing?.config as Record<string, unknown>) ?? {}), ...(input.config ?? {}) };
  let secretsEnc = existing?.secretsEnc ?? null;
  if (input.secrets !== undefined) {
    if (input.secrets === null) secretsEnc = null;
    else {
      const prev = readSecrets<Record<string, string>>(existing) ?? {};
      const merged = { ...prev, ...Object.fromEntries(Object.entries(input.secrets).filter(([, v]) => v !== "")) };
      secretsEnc = Object.keys(merged).length ? encrypt(JSON.stringify(merged), "integration") : null;
    }
  }
  const values = { config, secretsEnc, status: input.status ?? existing?.status ?? "configuree", lastError: input.lastError === undefined ? (existing?.lastError ?? null) : input.lastError, lastSyncAt: input.lastSyncAt === undefined ? (existing?.lastSyncAt ?? null) : input.lastSyncAt };
  if (existing) {
    const [row] = await db.update(schema.orgIntegrations).set(values).where(eq(schema.orgIntegrations.id, existing.id)).returning();
    return row;
  }
  const [row] = await db.insert(schema.orgIntegrations).values({ orgId, kind, ...values }).returning();
  return row;
}
