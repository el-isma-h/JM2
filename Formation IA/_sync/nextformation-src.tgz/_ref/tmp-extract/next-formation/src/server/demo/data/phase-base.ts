/**
 * Phase A du seed de démonstration : sites, fermetures, CRM, formateurs, catalogue, sessions, inscriptions.
 */
import { and, eq } from "drizzle-orm";
import { schema } from "@/db";
import { addD, centerDays, daysAgo, emailOf, expandClosures, fakeSiret, mondayOf, slugify } from "./util";
import { COMPANIES, EXTERNAL_TRAINERS, FIRST_NAMES_F, FIRST_NAMES_M, INTERNAL_TRAINERS, LAST_NAMES, CITIES, STREETS } from "./people";
import { CERTIFICATIONS, ELEARNING, PROGRAMS } from "./programs";
import { bump, type EnrollmentInfo, type SessionInfo, type SessionKey, type State, type Tx } from "./state";

const HOLIDAYS: { startDate: string; endDate: string; reason: string }[] = [
  { startDate: "2026-11-01", endDate: "2026-11-01", reason: "Toussaint" },
  { startDate: "2026-11-11", endDate: "2026-11-11", reason: "Armistice 1918" },
  { startDate: "2026-12-24", endDate: "2027-01-03", reason: "Fermeture de fin d'année" },
  { startDate: "2027-04-05", endDate: "2027-04-05", reason: "Lundi de Pâques" },
  { startDate: "2027-05-01", endDate: "2027-05-01", reason: "Fête du Travail" },
  { startDate: "2027-05-06", endDate: "2027-05-07", reason: "Ascension et pont" },
  { startDate: "2027-05-08", endDate: "2027-05-08", reason: "Victoire 1945" },
  { startDate: "2027-05-17", endDate: "2027-05-17", reason: "Lundi de Pentecôte" },
  { startDate: "2027-07-14", endDate: "2027-07-14", reason: "Fête nationale" },
  { startDate: "2027-08-02", endDate: "2027-08-20", reason: "Fermeture estivale" },
  { startDate: "2027-11-01", endDate: "2027-11-01", reason: "Toussaint" },
  { startDate: "2027-11-11", endDate: "2027-11-11", reason: "Armistice 1918" },
  { startDate: "2027-12-24", endDate: "2028-01-02", reason: "Fermeture de fin d'année" },
];

export const CLOSED_DAYS = expandClosures(HOLIDAYS);

/** Retire une clé technique avant insertion (sans avertissement de variable inutilisée). */
function stripKey<T extends object, K extends keyof T>(obj: T, key: K): Omit<T, K> {
  const copy = { ...obj };
  delete copy[key];
  return copy;
}

/** Identité fictive unique (prénom / nom), sans doublon dans l'organisme. */
function makeNamer(s: State) {
  const used = new Set<string>();
  return (sex: "F" | "M") => {
    for (let i = 0; i < 50; i++) {
      const firstName = s.rng.pick(sex === "F" ? FIRST_NAMES_F : FIRST_NAMES_M);
      const lastName = s.rng.pick(LAST_NAMES);
      const k = `${firstName} ${lastName}`;
      if (!used.has(k)) {
        used.add(k);
        return { firstName, lastName };
      }
    }
    throw new Error("Plus de noms disponibles");
  };
}

function birthDate(s: State, ageMin: number, ageMax: number): string {
  const age = s.rng.int(ageMin, ageMax);
  const y = Number(s.today.slice(0, 4)) - age;
  return `${y}-${String(s.rng.int(1, 12)).padStart(2, "0")}-${String(s.rng.int(1, 28)).padStart(2, "0")}`;
}

type PersonSpec = { sex: "F" | "M"; ageMin: number; ageMax: number; status: "candidat" | "apprenant" | "ancien"; companyKey?: string; hasAccommodations?: boolean; fixed?: { firstName: string; lastName: string; userId: string } };

export async function phaseBase(tx: Tx, s: State) {
  const { orgId, users, rng } = s;

  /* ---------- Sites, salles, fermetures ---------- */
  const [main] = await tx.select({ id: schema.sites.id }).from(schema.sites).where(and(eq(schema.sites.orgId, orgId), eq(schema.sites.isMain, true))).limit(1);
  const parisSite = main
    ? (await tx.update(schema.sites).set({ name: "Paris 11e (siège)", addressLine1: "14 rue des Tanneurs", postalCode: "75011", city: "Paris", capacity: 90, accessibilityNote: "Ascenseur, sanitaires adaptés, boucle magnétique à l'accueil. Référente handicap : Nathalie Roussel." }).where(eq(schema.sites.id, main.id)).returning())[0]
    : (await tx.insert(schema.sites).values({ orgId, name: "Paris 11e (siège)", isMain: true, addressLine1: "14 rue des Tanneurs", postalCode: "75011", city: "Paris", capacity: 90 }).returning())[0];
  const [montreuil] = await tx.insert(schema.sites).values({ orgId, name: "Antenne de Montreuil", addressLine1: "5 rue Marcel-Sembat", postalCode: "93100", city: "Montreuil", capacity: 30, accessibilityNote: "Rez-de-chaussée de plain-pied, place PMR devant l'entrée." }).returning();
  s.siteIds = { paris: parisSite.id, montreuil: montreuil.id };
  const rooms = await tx
    .insert(schema.rooms)
    .values([
      { orgId, siteId: parisSite.id, name: "Salle Colette", capacity: 16, equipment: ["vidéoprojecteur", "tableau blanc", "paperboard"] },
      { orgId, siteId: parisSite.id, name: "Salle Camus", capacity: 16, equipment: ["vidéoprojecteur", "tableau blanc"] },
      { orgId, siteId: parisSite.id, name: "Salle informatique", capacity: 12, equipment: ["12 postes", "vidéoprojecteur", "imprimante"] },
      { orgId, siteId: parisSite.id, name: "Salle Simone-Veil", capacity: 24, equipment: ["écran interactif", "visioconférence"] },
      { orgId, siteId: montreuil.id, name: "Salle Mont-Louis", capacity: 14, equipment: ["vidéoprojecteur", "mannequins SST", "défibrillateur de formation"] },
      { orgId, siteId: montreuil.id, name: "Bureau d'entretien", capacity: 3, equipment: ["poste informatique"] },
    ])
    .returning({ id: schema.rooms.id });
  s.roomIds = { paris: rooms.slice(0, 4).map((r) => r.id), montreuil: rooms.slice(4).map((r) => r.id) };
  await tx.insert(schema.closures).values(HOLIDAYS.map((h) => ({ orgId, ...h })));
  bump(s, "sites", 1);
  bump(s, "rooms", 6);
  bump(s, "closures", HOLIDAYS.length);

  /* ---------- Entreprises et contacts ---------- */
  const companyRows = await tx
    .insert(schema.companies)
    .values(
      COMPANIES.map((c) => {
        const { siren, siret } = fakeSiret(c.base8);
        return {
          orgId,
          name: c.name,
          siren,
          siret,
          apeCode: c.ape,
          idcc: c.idcc || null,
          opco: c.opco || null,
          sector: c.sector,
          headcount: c.headcount,
          addressLine1: c.address,
          postalCode: c.postalCode,
          city: c.city,
          email: `contact@${slugify(c.name)}.exemple.fr`,
          phone: `01 ${rng.int(40, 49)} ${rng.int(10, 99)} ${rng.int(10, 99)} ${rng.int(10, 99)}`,
          status: c.status,
          source: rng.pick(["Recommandation", "Site web", "Salon", "Ancien client", "Prospection téléphonique"]),
          assignedUserId: users.direction,
          tags: c.status === "client" ? ["client 2026"] : [],
          isDemo: true,
        };
      }),
    )
    .returning({ id: schema.companies.id, name: schema.companies.name });
  COMPANIES.forEach((c, i) => (s.companies[c.key] = companyRows[i].id));
  bump(s, "companies", companyRows.length);

  const contactValues = COMPANIES.flatMap((c) =>
    c.contacts.map((k) => ({
      orgId,
      companyId: s.companies[c.key],
      civility: k.civility,
      firstName: k.firstName,
      lastName: k.lastName,
      jobTitle: k.jobTitle,
      email: emailOf(k.firstName, k.lastName, `${slugify(c.name)}.exemple.fr`),
      phone: `01 ${rng.int(40, 49)} ${rng.int(10, 99)} ${rng.int(10, 99)} ${rng.int(10, 99)}`,
      mobile: k.isTutor ? `06 ${rng.int(10, 99)} ${rng.int(10, 99)} ${rng.int(10, 99)} ${rng.int(10, 99)}` : null,
      isSignatory: Boolean(k.isSignatory),
      isTutor: Boolean(k.isTutor),
      isBilling: Boolean(k.isBilling),
      userId: c.key === "deschamps" && k.firstName === "Julien" ? users.employer : null,
      gdprConsentAt: new Date(s.now.getTime() - rng.int(30, 400) * 86400_000),
      _key: c.key,
    })),
  );
  const contactRows = await tx.insert(schema.contacts).values(contactValues.map((v) => stripKey(v, "_key"))).returning({ id: schema.contacts.id });
  contactValues.forEach((v, i) => {
    (s.contacts[v._key] ??= []).push({ id: contactRows[i].id, name: `${v.firstName} ${v.lastName}`, email: v.email, companyKey: v._key, isTutor: v.isTutor, isSignatory: v.isSignatory, isBilling: v.isBilling });
  });
  bump(s, "contacts", contactRows.length);

  /* ---------- Formateurs ---------- */
  const trainerRows = await tx
    .insert(schema.trainers)
    .values([
      { orgId, userId: users.trainer, civility: "M", firstName: "Thomas", lastName: "Lefebvre", email: "thomas.lefebvre@atelier-meridien.exemple.fr", kind: "interne", ...INTERNAL_TRAINERS.thomas, isDemo: true },
      { orgId, userId: users.pedagogy, civility: "Mme", firstName: "Nathalie", lastName: "Roussel", email: "nathalie.roussel@atelier-meridien.exemple.fr", kind: "interne", ...INTERNAL_TRAINERS.nathalie, isDemo: true },
      ...EXTERNAL_TRAINERS.map((t) => ({
        orgId,
        civility: t.civility,
        firstName: t.firstName,
        lastName: t.lastName,
        email: emailOf(t.firstName, t.lastName, "exemple.fr"),
        kind: t.kind,
        companyName: t.companyName,
        siret: t.base8 ? fakeSiret(t.base8).siret : null,
        nda: t.nda,
        skills: t.skills,
        qualifications: t.qualifications,
        hourlyRateCents: t.hourlyRateCents,
        isDemo: true,
      })),
    ])
    .returning({ id: schema.trainers.id });
  s.trainers = { thomas: trainerRows[0].id, nathalie: trainerRows[1].id, claire: trainerRows[2].id, antoine: trainerRows[3].id, isabelle: trainerRows[4].id };
  await tx.update(schema.memberships).set({ trainerId: s.trainers.thomas }).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, users.trainer)));
  await tx.update(schema.memberships).set({ trainerId: s.trainers.nathalie }).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, users.pedagogy)));
  await tx.insert(schema.trainerUnavailabilities).values([
    { orgId, trainerId: s.trainers.claire, startDate: addD(s.today, 10), endDate: addD(s.today, 14), reason: "Congés" },
    { orgId, trainerId: s.trainers.antoine, startDate: addD(s.today, 3), endDate: addD(s.today, 3), part: "apres_midi", reason: "Recyclage formateur INRS" },
  ]);
  bump(s, "trainers", 5);
  bump(s, "trainer_unavailabilities", 2);

  /* ---------- Catalogue ---------- */
  const certRows = await tx
    .insert(schema.certifications)
    .values(
      (["rncp_bts", "rncp_arh", "rs_sst"] as const).map((k) => {
        const c = CERTIFICATIONS[k];
        return { orgId, title: c.title, rncpCode: "rncpCode" in c ? c.rncpCode : null, rsCode: "rsCode" in c ? c.rsCode : null, certifier: c.certifier, level: c.level, validUntil: c.validUntil, blocks: [...c.blocks], habilitationRef: c.habilitationRef, habilitationValidUntil: c.habilitationValidUntil };
      }),
    )
    .returning({ id: schema.certifications.id });
  s.certifications = { rncp_bts: certRows[0].id, rncp_arh: certRows[1].id, rs_sst: certRows[2].id };
  bump(s, "certifications", 3);

  const programRows = await tx
    .insert(schema.programs)
    .values(
      PROGRAMS.map((p) => ({
        orgId,
        code: p.code,
        title: p.title,
        slug: slugify(p.title),
        kind: p.kind,
        category: p.category,
        certificationId: p.certification ? s.certifications[p.certification] : null,
        availableAsApprenticeship: p.availableAsApprenticeship,
        availableAsContinuing: p.availableAsContinuing,
        status: "actif" as const,
        isPublished: p.isPublished,
        publishedAt: p.isPublished ? new Date("2026-01-15T09:00:00Z") : null,
        specialty: p.specialty,
        formacode: p.formacode,
        cpfEligible: p.cpfEligible,
        tags: [p.category],
        isDemo: true,
      })),
    )
    .returning({ id: schema.programs.id });
  const versionRows = await tx
    .insert(schema.programVersions)
    .values(
      PROGRAMS.map((p, i) => ({
        orgId,
        programId: programRows[i].id,
        version: 1,
        status: "active" as const,
        effectiveFrom: "2026-01-01",
        ...p.version,
        createdBy: users.pedagogy,
        validatedBy: users.direction,
        validatedAt: new Date("2026-01-10T10:00:00Z"),
      })),
    )
    .returning({ id: schema.programVersions.id });
  const moduleValues = PROGRAMS.flatMap((p, i) => p.modules.map((m, j) => ({ orgId, programVersionId: versionRows[i].id, blockCode: m.blockCode ?? null, code: m.code, title: m.title, description: m.description ?? null, hours: m.hours, position: j, skills: m.skills ?? [], _p: p.key })));
  const moduleRows = await tx.insert(schema.modules).values(moduleValues.map((v) => stripKey(v, "_p"))).returning({ id: schema.modules.id });
  PROGRAMS.forEach((p, i) => {
    s.programs[p.key] = { id: programRows[i].id, versionId: versionRows[i].id, title: p.title, moduleIds: moduleValues.map((m, j) => (m._p === p.key ? moduleRows[j].id : null)).filter((x): x is string => Boolean(x)), durationHours: p.version.durationHours };
  });
  const elRows = await tx
    .insert(schema.elearningModules)
    .values(ELEARNING.map((e, i) => ({ orgId, programVersionId: s.programs[e.program].versionId, moduleId: s.programs[e.program].moduleIds[e.program === "arh" ? 1 : 3] ?? null, kind: e.kind, title: e.title, description: e.description, url: e.url ?? null, externalId: e.externalId ?? null, content: e.content, durationMinutes: e.durationMinutes, countsAsHours: e.countsAsHours, position: i })))
    .returning({ id: schema.elearningModules.id });
  s.elearningIds = elRows.map((r) => r.id);
  bump(s, "programs", PROGRAMS.length);
  bump(s, "program_versions", PROGRAMS.length);
  bump(s, "modules", moduleRows.length);
  bump(s, "elearning_modules", elRows.length);

  /* ---------- Sessions ---------- */
  const btsStart = mondayOf(daysAgo(s.today, 56));
  const arhStart = mondayOf(daysAgo(s.today, 49));
  const arhAEnd = addD(mondayOf(daysAgo(s.today, 42)), 4);
  const sst1 = addD(mondayOf(daysAgo(s.today, 28)), 3);
  const xls1 = addD(mondayOf(daysAgo(s.today, 21)), 1);
  const mgt = mondayOf(addD(s.today, 21));
  const elec = addD(mondayOf(addD(s.today, 35)), 3);
  const xls2 = addD(mondayOf(addD(s.today, 49)), 1);
  const intra = addD(mondayOf(addD(s.today, 28)), 1);
  const sst2 = mondayOf(daysAgo(s.today, 7));
  const P = s.programs;
  const rhythm = (key: keyof typeof P) => PROGRAMS.find((p) => p.key === key)!.version.rhythm;
  const sched = { morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } };
  type SessionDef = { key: SessionKey; programKey: keyof typeof P; code: string; title: string; kind: "inter" | "intra" | "cycle" | "individuel"; isApprenticeship: boolean; startDate: string; endDate: string; status: SessionInfo["status"]; site: "paris" | "montreuil" | null; rooms: number[]; capacity: number; minCapacity: number; weekdays: number[]; slotsFrom: string; trainer: keyof State["trainers"] | null; trainerUser: string | null; companyKey?: string; priceCents?: number | null; notes?: string; groups?: string[]; closedAt?: Date | null; isPublished?: boolean };
  const defs: SessionDef[] = [
    { key: "bts", programKey: "bts", code: `BTS-GPME-${btsStart.slice(0, 4)}-28`, title: "BTS Gestion de la PME, promotion 2026-2028", kind: "cycle", isApprenticeship: true, startDate: btsStart, endDate: "2028-06-30", status: "en_cours", site: "paris", rooms: [0, 1], capacity: 24, minCapacity: 12, weekdays: [1, 2], slotsFrom: btsStart, trainer: "thomas", trainerUser: users.trainer, groups: ["Groupe A", "Groupe B"], isPublished: true },
    { key: "arh", programKey: "arh", code: `TP-ARH-${arhStart.slice(0, 4)}-B`, title: "Titre pro Assistant RH, session B (automne)", kind: "inter", isApprenticeship: false, startDate: arhStart, endDate: addD(arhStart, 24 * 7 - 3), status: "en_cours", site: "paris", rooms: [3], capacity: 14, minCapacity: 6, weekdays: [1, 2, 3, 4, 5], slotsFrom: addD(arhStart, 14), trainer: "nathalie", trainerUser: users.pedagogy, notes: "Les deux premières semaines ont été émargées sur feuilles journalières papier (reprise), avant la mise en service de l'émargement par demi-journée.", isPublished: true },
    { key: "arhA", programKey: "arh", code: `TP-ARH-${arhAEnd.slice(0, 4)}-A`, title: "Titre pro Assistant RH, session A (printemps)", kind: "inter", isApprenticeship: false, startDate: addD(arhAEnd, -(24 * 7) + 4), endDate: arhAEnd, status: "terminee", site: "paris", rooms: [3], capacity: 14, minCapacity: 6, weekdays: [1, 2, 3, 4, 5], slotsFrom: addD(arhAEnd, 1), trainer: "nathalie", trainerUser: users.pedagogy, notes: "Session reprise de l'ancien outil : heures sur feuilles journalières, non réconciliées.", closedAt: new Date(`${addD(arhAEnd, 3)}T16:00:00Z`) },
    { key: "sst1", programKey: "sst", code: `SST-${sst1.slice(0, 7).replace("-", "")}`, title: "SST initial, inter-entreprises", kind: "inter", isApprenticeship: false, startDate: sst1, endDate: addD(sst1, 1), status: "terminee", site: "montreuil", rooms: [0], capacity: 10, minCapacity: 4, weekdays: [1, 2, 3, 4, 5], slotsFrom: sst1, trainer: "antoine", trainerUser: null, closedAt: new Date(`${addD(sst1, 4)}T10:00:00Z`) },
    { key: "xls1", programKey: "excel", code: `XLS2-${xls1.slice(0, 7).replace("-", "")}`, title: "Excel avancé, inter", kind: "inter", isApprenticeship: false, startDate: xls1, endDate: addD(xls1, 1), status: "terminee", site: "paris", rooms: [2], capacity: 10, minCapacity: 3, weekdays: [1, 2, 3, 4, 5], slotsFrom: xls1, trainer: "claire", trainerUser: null, closedAt: new Date(`${addD(xls1, 3)}T09:30:00Z`) },
    { key: "mgt", programKey: "management", code: `MGT-${mgt.slice(0, 7).replace("-", "")}`, title: "Management d'équipe, inter", kind: "inter", isApprenticeship: false, startDate: mgt, endDate: addD(mgt, 2), status: "ouverte", site: "paris", rooms: [3], capacity: 12, minCapacity: 4, weekdays: [1, 2, 3, 4, 5], slotsFrom: mgt, trainer: "isabelle", trainerUser: null, isPublished: true },
    { key: "elec", programKey: "elec", code: `HAB-${elec.slice(0, 7).replace("-", "")}`, title: "Habilitation électrique B0/H0V", kind: "inter", isApprenticeship: false, startDate: elec, endDate: elec, status: "confirmee", site: "montreuil", rooms: [0], capacity: 10, minCapacity: 4, weekdays: [1, 2, 3, 4, 5], slotsFrom: elec, trainer: "antoine", trainerUser: null, isPublished: true },
    { key: "xls2", programKey: "excel", code: `XLS2-${xls2.slice(0, 7).replace("-", "")}`, title: "Excel avancé, inter (décembre)", kind: "inter", isApprenticeship: false, startDate: xls2, endDate: addD(xls2, 1), status: "ouverte", site: "paris", rooms: [2], capacity: 10, minCapacity: 3, weekdays: [1, 2, 3, 4, 5], slotsFrom: xls2, trainer: "claire", trainerUser: null, isPublished: true },
    { key: "intra", programKey: "accueil", code: `INTRA-ACC-${intra.slice(0, 7).replace("-", "")}`, title: "Accueil en établissement de santé, intra Clinique Sainte-Odile", kind: "intra", isApprenticeship: false, startDate: intra, endDate: addD(intra, 1), status: "confirmee", site: null, rooms: [], capacity: 10, minCapacity: 6, weekdays: [1, 2, 3, 4, 5], slotsFrom: intra, trainer: "nathalie", trainerUser: users.pedagogy, companyKey: "clinique", priceCents: 260000, notes: "Dans les locaux de la clinique (salle de réunion du 2e étage)." },
    { key: "bilan", programKey: "bilan", code: "BILAN-2027-01", title: "Bilan de compétences, accompagnement individuel", kind: "individuel", isApprenticeship: false, startDate: addD(mondayOf(addD(s.today, 80)), 0), endDate: addD(mondayOf(addD(s.today, 80)), 53), status: "brouillon", site: "montreuil", rooms: [1], capacity: 1, minCapacity: 1, weekdays: [], slotsFrom: addD(s.today, 80), trainer: null, trainerUser: null },
    { key: "sst2", programKey: "sst", code: `SST-${sst2.slice(0, 7).replace("-", "")}B`, title: "SST initial, inter (session annulée)", kind: "inter", isApprenticeship: false, startDate: sst2, endDate: addD(sst2, 1), status: "annulee", site: "montreuil", rooms: [0], capacity: 10, minCapacity: 4, weekdays: [], slotsFrom: sst2, trainer: "antoine", trainerUser: null, notes: "Annulée 8 jours avant : effectif insuffisant (2 inscrits pour un minimum de 4). Stagiaires reportés sur la session suivante.", closedAt: new Date(`${daysAgo(s.today, 15)}T11:00:00Z`) },
  ];
  const sessionRows = await tx
    .insert(schema.trainingSessions)
    .values(
      defs.map((d) => ({
        orgId,
        programVersionId: P[d.programKey].versionId,
        code: d.code,
        title: d.title,
        kind: d.kind,
        isApprenticeship: d.isApprenticeship,
        startDate: d.startDate,
        endDate: d.endDate,
        siteId: d.site ? s.siteIds[d.site] : null,
        roomId: d.site && d.rooms.length ? s.roomIds[d.site][d.rooms[0]] : null,
        capacity: d.capacity,
        minCapacity: d.minCapacity,
        rhythm: rhythm(d.programKey),
        schedule: sched,
        status: d.status as "en_cours",
        pedagogyManagerUserId: users.pedagogy,
        adminManagerUserId: users.admin,
        companyId: d.companyKey ? s.companies[d.companyKey] : null,
        priceCents: d.priceCents ?? null,
        isPublished: Boolean(d.isPublished),
        notes: d.notes ?? null,
        closedAt: d.closedAt ?? null,
        isDemo: true,
      })),
    )
    .returning({ id: schema.trainingSessions.id });
  defs.forEach((d, i) => {
    s.sessions[d.key] = { id: sessionRows[i].id, key: d.key, programKey: d.programKey, versionId: P[d.programKey].versionId, startDate: d.startDate, endDate: d.endDate, status: d.status, weekdays: d.weekdays, slotsFrom: d.slotsFrom, siteId: d.site ? s.siteIds[d.site] : null, roomIds: d.site ? d.rooms.map((r) => s.roomIds[d.site!][r]) : [], groupIds: [], trainerUserId: d.trainerUser, trainerId: d.trainer ? s.trainers[d.trainer] : null, isApprenticeship: d.isApprenticeship };
  });
  const groupRows = await tx
    .insert(schema.groups)
    .values([
      { orgId, sessionId: s.sessions.bts.id, name: "Groupe A", capacity: 12 },
      { orgId, sessionId: s.sessions.bts.id, name: "Groupe B", capacity: 12 },
    ])
    .returning({ id: schema.groups.id });
  s.sessions.bts.groupIds = groupRows.map((g) => g.id);
  const T = s.trainers;
  const S = s.sessions;
  // Thomas : BTS (principal), SST terminée, management à venir. Jamais sur la session titre pro en cours (R03).
  await tx.insert(schema.sessionTrainers).values([
    { orgId, sessionId: S.bts.id, trainerId: T.thomas, role: "principal" },
    { orgId, sessionId: S.bts.id, trainerId: T.isabelle, role: "intervenant" },
    { orgId, sessionId: S.bts.id, trainerId: T.nathalie, role: "tuteur_pedagogique" },
    { orgId, sessionId: S.arh.id, trainerId: T.nathalie, role: "principal" },
    { orgId, sessionId: S.arh.id, trainerId: T.isabelle, role: "intervenant" },
    { orgId, sessionId: S.arhA.id, trainerId: T.nathalie, role: "principal" },
    { orgId, sessionId: S.arhA.id, trainerId: T.isabelle, role: "jury" },
    { orgId, sessionId: S.sst1.id, trainerId: T.antoine, role: "principal" },
    { orgId, sessionId: S.sst1.id, trainerId: T.thomas, role: "intervenant" },
    { orgId, sessionId: S.xls1.id, trainerId: T.claire, role: "principal" },
    { orgId, sessionId: S.mgt.id, trainerId: T.isabelle, role: "principal" },
    { orgId, sessionId: S.mgt.id, trainerId: T.thomas, role: "intervenant" },
    { orgId, sessionId: S.elec.id, trainerId: T.antoine, role: "principal" },
    { orgId, sessionId: S.xls2.id, trainerId: T.claire, role: "principal" },
    { orgId, sessionId: S.intra.id, trainerId: T.nathalie, role: "principal" },
    { orgId, sessionId: S.sst2.id, trainerId: T.antoine, role: "principal" },
  ]);
  bump(s, "sessions_formation", defs.length);
  bump(s, "groups", 2);
  bump(s, "session_trainers", 16);

  /* ---------- Personnes et inscriptions ---------- */
  const name = makeNamer(s);
  type EnrSpec = { sessionKey: SessionKey; groupIdx: number | null; person: PersonSpec; status: EnrollmentInfo["status"]; contractKind: EnrollmentInfo["contractKind"]; fundingKind: string; companyKey?: string; exitDate?: string; exitReason?: string; legacyHours?: number; isInes?: boolean };
  const specs: EnrSpec[] = [];
  const btsCompanies = ["deschamps", "deschamps", "deschamps", "fournel", "fournel", "distrimarche", "distrimarche", "distrimarche", "distrimarche", "moretti", "moretti", "pharmacie", "berard", "berard", "berard", "tilleuls", "tilleuls", "clinique", "clinique", "clinique", "vauclair", "vauclair", "hotel", "hotel"];
  btsCompanies.forEach((ck, i) => {
    const isInes = i === 0;
    const status = i === 21 ? "abandon" : i === 23 ? "annule" : "en_cours";
    specs.push({ sessionKey: "bts", groupIdx: i < 12 ? 0 : 1, person: { sex: i % 3 === 0 ? "F" : "M", ageMin: 18, ageMax: 21, status: "apprenant", companyKey: ck, hasAccommodations: i === 7, fixed: isInes ? { firstName: "Inès", lastName: "Carvalho", userId: users.learner } : undefined }, status, contractKind: "contrat_apprentissage", fundingKind: "opco", companyKey: ck, exitDate: status === "abandon" ? daysAgo(s.today, 20) : undefined, exitReason: status === "abandon" ? "Rupture du contrat d'apprentissage pendant la période d'essai, à l'initiative de l'apprenti (réorientation)." : status === "annule" ? "Contrat non signé par l'employeur avant l'entrée en formation." : undefined, isInes });
  });
  const arhFunding = ["france_travail", "france_travail", "france_travail", "france_travail", "france_travail", "region", "region", "region", "region", "cpf", "cpf", "entreprise"];
  arhFunding.forEach((fk, i) => {
    const status = i === 11 ? "abandon" : "en_cours";
    specs.push({ sessionKey: "arh", groupIdx: null, person: { sex: i % 4 === 3 ? "M" : "F", ageMin: 24, ageMax: 47, status: "apprenant", hasAccommodations: i === 4, companyKey: fk === "entreprise" ? "distrimarche" : undefined }, status, contractKind: fk === "cpf" ? "cpf" : fk === "entreprise" ? "convention_formation" : "contrat_particulier", fundingKind: fk, companyKey: fk === "entreprise" ? "distrimarche" : undefined, exitDate: status === "abandon" ? daysAgo(s.today, 12) : undefined, exitReason: status === "abandon" ? "Reprise d'un emploi en CDI (sortie positive avant terme)." : undefined });
  });
  for (let i = 0; i < 10; i++) specs.push({ sessionKey: "arhA", groupIdx: null, person: { sex: i % 3 === 1 ? "M" : "F", ageMin: 25, ageMax: 50, status: "ancien" }, status: "termine", contractKind: "contrat_particulier", fundingKind: i < 6 ? "france_travail" : "region", legacyHours: i < 5 ? [702, 690, 714, 648, 720][i] : 0 });
  const sstCompanies = ["berard", "berard", "berard", "berard", "tilleuls", "tilleuls", "tilleuls", "moretti", "moretti"];
  sstCompanies.forEach((ck) => specs.push({ sessionKey: "sst1", groupIdx: null, person: { sex: s.rng.chance(0.5) ? "F" : "M", ageMin: 22, ageMax: 58, status: "ancien", companyKey: ck }, status: "termine", contractKind: "convention_formation", fundingKind: "entreprise", companyKey: ck }));
  const xlsCompanies = ["fournel", "fournel", "mairie", "mairie", "vauclair", null];
  xlsCompanies.forEach((ck) => specs.push({ sessionKey: "xls1", groupIdx: null, person: { sex: s.rng.chance(0.6) ? "F" : "M", ageMin: 24, ageMax: 55, status: "ancien", companyKey: ck ?? undefined }, status: "termine", contractKind: ck ? "convention_formation" : "cpf", fundingKind: ck ? "entreprise" : "cpf", companyKey: ck ?? undefined }));
  (["nolwen", "distrimarche", "distrimarche", "clinique", "berard"] as const).forEach((ck, i) => specs.push({ sessionKey: "mgt", groupIdx: null, person: { sex: i % 2 ? "M" : "F", ageMin: 28, ageMax: 52, status: "apprenant", companyKey: ck }, status: i < 3 ? "inscrit" : "preinscrit", contractKind: "convention_formation", fundingKind: ck === "nolwen" ? "opco" : "entreprise", companyKey: ck }));
  (["clinique", "clinique", "tilleuls", "tilleuls"] as const).forEach((ck, i) => specs.push({ sessionKey: "elec", groupIdx: null, person: { sex: i % 2 ? "F" : "M", ageMin: 24, ageMax: 60, status: "apprenant", companyKey: ck }, status: "inscrit", contractKind: "convention_formation", fundingKind: "entreprise", companyKey: ck }));
  ([null, null, "hotel"] as const).forEach((ck, i) => specs.push({ sessionKey: "xls2", groupIdx: null, person: { sex: i === 1 ? "M" : "F", ageMin: 26, ageMax: 50, status: "candidat", companyKey: ck ?? undefined }, status: i === 2 ? "inscrit" : "preinscrit", contractKind: ck ? "convention_formation" : "cpf", fundingKind: ck ? "entreprise" : "cpf", companyKey: ck ?? undefined }));
  for (let i = 0; i < 6; i++) specs.push({ sessionKey: "intra", groupIdx: null, person: { sex: i === 2 ? "M" : "F", ageMin: 23, ageMax: 59, status: "apprenant", companyKey: "clinique" }, status: "inscrit", contractKind: "convention_formation", fundingKind: "entreprise", companyKey: "clinique" });
  specs.push({ sessionKey: "bilan", groupIdx: null, person: { sex: "F", ageMin: 38, ageMax: 48, status: "candidat" }, status: "preinscrit", contractKind: "cpf", fundingKind: "cpf" });
  for (let i = 0; i < 2; i++) specs.push({ sessionKey: "sst2", groupIdx: null, person: { sex: "M", ageMin: 30, ageMax: 50, status: "candidat", companyKey: "berard" }, status: "annule", contractKind: "convention_formation", fundingKind: "entreprise", companyKey: "berard", exitReason: "Session annulée (effectif insuffisant) : report proposé sur la session suivante." });

  const candidateSpecs: PersonSpec[] = [
    { sex: "F", ageMin: 19, ageMax: 23, status: "candidat" },
    { sex: "M", ageMin: 20, ageMax: 26, status: "candidat" },
    { sex: "F", ageMin: 30, ageMax: 44, status: "candidat", hasAccommodations: true },
    { sex: "M", ageMin: 18, ageMax: 20, status: "candidat" },
  ];
  const allPersonSpecs = [...specs.map((x) => x.person), ...candidateSpecs];
  const personValues = allPersonSpecs.map((p) => {
    const n = p.fixed ?? name(p.sex);
    const city = rng.pick(CITIES);
    return {
      orgId,
      civility: p.sex === "F" ? ("Mme" as const) : ("M" as const),
      firstName: n.firstName,
      lastName: n.lastName,
      birthDate: birthDate(s, p.ageMin, p.ageMax),
      birthPlace: rng.pick(["Paris", "Montreuil", "Créteil", "Bobigny", "Lyon", "Lille", "Marseille", "Dakar", "Alger", "Lisbonne", "Nantes", "Toulouse"]),
      nationality: "Française",
      email: emailOf(n.firstName, n.lastName, "exemple.fr"),
      phone: `06 ${rng.int(10, 99)} ${rng.int(10, 99)} ${rng.int(10, 99)} ${rng.int(10, 99)}`,
      addressLine1: `${rng.int(1, 120)} ${rng.pick(STREETS)}`,
      postalCode: city.postalCode,
      city: city.city,
      status: p.status,
      companyId: p.companyKey ? s.companies[p.companyKey] : null,
      educationLevel: p.ageMax <= 23 ? "Baccalauréat" : rng.pick(["Baccalauréat", "BTS", "Licence", "Master", "CAP", "Niveau 3e"]),
      situation: p.ageMax <= 23 ? "Apprenti" : rng.pick(["Salarié", "Demandeur d'emploi", "Salarié", "Indépendant"]),
      identifiers: p.status === "apprenant" && p.ageMax > 23 ? { france_travail: `FT${rng.int(1000000, 9999999)}` } : {},
      hasAccommodations: Boolean(p.hasAccommodations),
      accommodations: p.hasAccommodations ? "Tiers-temps aux évaluations, supports en police agrandie (RQTH)." : null,
      source: rng.pick(["Site web", "France Travail", "Bouche à oreille", "Entreprise", "Salon", "Mission locale"]),
      tags: [],
      userId: p.fixed?.userId ?? null,
      gdprConsentAt: new Date(s.now.getTime() - rng.int(20, 300) * 86400_000),
      isDemo: true,
    };
  });
  const personRows = await tx.insert(schema.persons).values(personValues).returning({ id: schema.persons.id });
  s.persons = personRows.map((r, i) => ({ id: r.id, firstName: personValues[i].firstName, lastName: personValues[i].lastName, email: personValues[i].email }));
  bump(s, "persons", personRows.length);
  await tx.update(schema.memberships).set({ personId: personRows[0].id }).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, users.learner)));
  await tx.update(schema.memberships).set({ companyId: s.companies.deschamps }).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, users.employer)));

  const tutorOf = (ck: string | undefined) => (ck ? s.contacts[ck]?.find((c) => c.isTutor)?.id ?? null : null);
  const year = Number(s.today.slice(0, 4));
  const enrollmentValues = specs.map((e, i) => {
    const sess = s.sessions[e.sessionKey];
    const examState = e.sessionKey === "arhA" ? "inscrit" : e.sessionKey === "bts" && e.status === "en_cours" ? "a_inscrire" : "non_concerne";
    return {
      orgId,
      sessionId: sess.id,
      personId: personRows[i].id,
      groupId: e.groupIdx === null ? null : sess.groupIds[e.groupIdx],
      programVersionId: sess.versionId,
      reference: `INS-${year}-${String(i + 1).padStart(4, "0")}`,
      companyId: e.companyKey ? s.companies[e.companyKey] : null,
      tutorContactId: e.contractKind === "contrat_apprentissage" ? tutorOf(e.companyKey) : null,
      commercialStatus: (e.companyKey ? "accepte" : "sans_objet") as "accepte",
      status: e.status as "inscrit",
      progression: (e.status === "termine" ? "acquise" : e.status === "en_cours" ? "en_cours" : e.status === "abandon" ? "partielle" : "non_commencee") as "en_cours",
      fundingState: (e.status === "termine" ? "solde" : e.status === "en_cours" ? "accorde" : e.status === "annule" ? "a_definir" : "prevu") as "prevu",
      examState: examState as "inscrit",
      contractKind: e.contractKind as "convention_formation",
      contractNumber: e.contractKind === "contrat_apprentissage" ? `CA-${year}-${String(1000 + i).slice(1)}` : e.contractKind === "convention_formation" ? `CONV-${year}-${String(i + 1).padStart(3, "0")}` : null,
      startDate: sess.startDate,
      endDate: sess.endDate,
      exitDate: e.exitDate ?? null,
      exitReason: e.exitReason ?? null,
      hoursPlanned: P[sess.programKey as keyof typeof P].durationHours,
      positioning: e.sessionKey === "arh" || e.sessionKey === "bts" ? { date: sess.startDate, level: rng.pick(["débutant", "intermédiaire", "confirmé"]), note: "Entretien et test de positionnement réalisés à l'entrée." } : {},
      individualPlan: e.sessionKey === "arh" ? { remoteModules: ["Les bases du bulletin de paie"], internshipCompany: e.companyKey ?? "à définir", objectives: "Obtenir le titre complet (CCP1 + CCP2)." } : {},
      priceCents: e.sessionKey === "bts" ? 790000 : e.sessionKey === "arh" || e.sessionKey === "arhA" ? 798000 : e.sessionKey === "sst1" || e.sessionKey === "sst2" ? 29000 : e.sessionKey.startsWith("xls") ? 79000 : e.sessionKey === "mgt" ? 145000 : e.sessionKey === "elec" ? 24000 : e.sessionKey === "bilan" ? 180000 : null,
      legacyHours: e.legacyHours ?? 0,
      legacyHoursNote: e.legacyHours ? "Solde repris de l'ancien outil (feuilles journalières papier), non réconcilié avec les heures justifiées." : null,
      closedAt: e.status === "termine" ? new Date(`${addD(sess.endDate, 3)}T15:00:00Z`) : null,
      closedBy: e.status === "termine" ? users.pedagogy : null,
      isDemo: true,
    };
  });
  const enrollmentRows = await tx.insert(schema.enrollments).values(enrollmentValues).returning({ id: schema.enrollments.id });
  s.enrollments = specs.map((e, i) => ({ id: enrollmentRows[i].id, reference: enrollmentValues[i].reference, sessionKey: e.sessionKey, personId: personRows[i].id, personName: `${personValues[i].firstName} ${personValues[i].lastName}`, groupIdx: e.groupIdx, companyKey: e.companyKey ?? null, companyId: enrollmentValues[i].companyId, tutorContactId: enrollmentValues[i].tutorContactId, status: e.status, contractKind: e.contractKind, fundingKind: e.fundingKind, exitDate: e.exitDate ?? null, isInes: Boolean(e.isInes) }));
  await tx
    .insert(schema.invoiceSequences)
    .values({ orgId, kind: "inscription", year, next: specs.length + 1 })
    .onConflictDoUpdate({ target: [schema.invoiceSequences.orgId, schema.invoiceSequences.kind, schema.invoiceSequences.year], set: { next: specs.length + 1 } });
  bump(s, "enrollments", enrollmentRows.length);

  // Historique et notes de dossier.
  const events: (typeof schema.enrollmentEvents.$inferInsert)[] = [];
  const notes: (typeof schema.dossierNotes.$inferInsert)[] = [];
  s.enrollments.forEach((e) => {
    const sess = s.sessions[e.sessionKey];
    const created = new Date(`${addD(sess.startDate, -rng.int(10, 45))}T10:00:00Z`);
    events.push({ enrollmentId: e.id, kind: "statut", fromValue: null, toValue: "preinscrit", reason: "Création du dossier", userId: users.admin, at: created });
    if (e.status !== "preinscrit") events.push({ enrollmentId: e.id, kind: "statut", fromValue: "preinscrit", toValue: "inscrit", reason: "Dossier complet, inscription confirmée", userId: users.admin, at: new Date(created.getTime() + 5 * 86400_000) });
    if (e.status === "en_cours" || e.status === "termine" || e.status === "abandon") events.push({ enrollmentId: e.id, kind: "statut", fromValue: "inscrit", toValue: "en_cours", reason: "Entrée en formation", userId: users.pedagogy, at: new Date(`${sess.startDate}T08:30:00Z`) });
    if (e.status === "termine") events.push({ enrollmentId: e.id, kind: "statut", fromValue: "en_cours", toValue: "termine", reason: "Clôture pédagogique", userId: users.pedagogy, at: new Date(`${addD(sess.endDate, 3)}T15:00:00Z`) });
    if (e.status === "abandon") events.push({ enrollmentId: e.id, kind: "statut", fromValue: "en_cours", toValue: "abandon", reason: "Sortie anticipée", userId: users.pedagogy, at: new Date(`${e.exitDate}T17:00:00Z`) });
    if (e.status === "annule") events.push({ enrollmentId: e.id, kind: "statut", fromValue: "inscrit", toValue: "annule", reason: "Annulation", userId: users.admin, at: new Date(`${addD(sess.startDate, -3)}T09:00:00Z`) });
  });
  const noteTargets = s.enrollments.filter((e) => e.sessionKey === "bts" || e.sessionKey === "arh").slice(0, 16);
  for (const e of noteTargets) {
    notes.push({ orgId, enrollmentId: e.id, personId: e.personId, section: "commentaire", body: e.isInes ? "Appel du maître d'apprentissage (Julien Deschamps) : très satisfait de l'intégration. CERFA signé toujours attendu côté employeur." : rng.pick(["Entretien d'accueil réalisé, apprenant motivé.", "Demande d'attestation d'inscription pour le logement transmise.", "A prévenu d'un retard récurrent le lundi matin (transports)."]), authorId: users.admin, pinned: e.isInes });
    notes.push({ orgId, enrollmentId: e.id, personId: e.personId, section: "interne", body: rng.pick(["Financement à surveiller : accord OPCO reçu, échéancier à vérifier avant facturation.", "Tuteur peu joignable, privilégier l'e-mail.", "Dossier repris depuis Excel : vérifier la date de naissance."]), authorId: users.direction });
    notes.push({ orgId, enrollmentId: e.id, personId: e.personId, section: "pedagogique", body: rng.pick(["Bon niveau en bureautique, difficultés en expression écrite : accompagnement renforcé en CGE.", "Positionnement : niveau confirmé sur le bloc 1, à consolider sur le bloc 3.", "Projet professionnel clair ; viser la poursuite en licence pro."]), authorId: users.pedagogy });
    notes.push({ orgId, enrollmentId: e.id, personId: e.personId, section: "administratif", body: rng.pick(["Pièce d'identité reçue et contrôlée.", "Règlement intérieur signé le jour de la rentrée.", "Convention retournée signée par l'entreprise."]), authorId: users.admin });
  }
  await tx.insert(schema.enrollmentEvents).values(events);
  await tx.insert(schema.dossierNotes).values(notes);
  bump(s, "enrollment_events", events.length);
  bump(s, "dossier_notes", notes.length);
}

/** Dates de centre d'une session, bornées à six semaines après aujourd'hui. */
export function sessionCenterDays(s: State, info: SessionInfo): string[] {
  if (!info.weekdays.length) return [];
  const end = info.endDate < addD(s.today, 42) ? info.endDate : addD(s.today, 42);
  return centerDays(info.slotsFrom, end, info.weekdays, CLOSED_DAYS);
}
