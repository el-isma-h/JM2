import "server-only";
import { createHash } from "node:crypto";
import { clientIp, hit, tooManyMessage } from "@/server/rate-limit";

/**
 * En-têtes communs de l'API publique du catalogue (lecture seule, sans session) : CORS ouvert en lecture,
 * cache navigateur 5 min, cache partagé (CDN, proxy) 10 min, service d'une copie périmée pendant 1 jour.
 */
export const PUBLIC_CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
  "Access-Control-Allow-Headers": "If-None-Match, Content-Type",
  "Access-Control-Max-Age": "86400",
  "Access-Control-Expose-Headers": "ETag",
};
export const PUBLIC_CACHE = "public, max-age=300, s-maxage=600, stale-while-revalidate=86400";

export function preflight() {
  return new Response(null, { status: 204, headers: PUBLIC_CORS });
}

/** Limite de débit par IP (partagée avec /api/public/catalogue/[orgSlug]) ; null si autorisé. */
export async function limitPublic(): Promise<Response | null> {
  const ip = await clientIp();
  const rl = await hit("public:catalogue:api", ip, { limit: 120, windowSeconds: 60 * 60 });
  if (rl.ok) return null;
  return Response.json({ error: tooManyMessage(rl) }, { status: 429, headers: { ...PUBLIC_CORS, "Retry-After": String(rl.retryAfterSeconds) } });
}

/** Réponse avec ETag (hors date de génération) et 304 si le client a déjà la même version. */
export function cachedResponse(req: Request, body: string, contentType: string, etagSource: string): Response {
  const etag = `"${createHash("sha256").update(etagSource).digest("base64url").slice(0, 27)}"`;
  const headers = { ...PUBLIC_CORS, "Cache-Control": PUBLIC_CACHE, ETag: etag, Vary: "Origin", "X-Robots-Tag": "noindex" };
  if (req.headers.get("if-none-match") === etag) return new Response(null, { status: 304, headers });
  return new Response(req.method === "HEAD" ? null : body, { status: 200, headers: { ...headers, "Content-Type": contentType } });
}
