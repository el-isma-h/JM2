/**
 * Phase CRM : besoins, placements, interactions, devis, financeurs, abonnement, objectifs.
 */
import { schema } from "@/db";
import { addD, daysAgo } from "./util";
import { bump, type State, type Tx } from "./state";

export async function phaseCrm(tx: Tx, s: State) {
  const { orgId, users, rng } = s;
  const C = s.companies;
  const contact = (ck: string, pred: (c: State["contacts"][string][number]) => boolean = () => true) => s.contacts[ck].find(pred)?.id ?? null;
  const signatory = (ck: string) => contact(ck, (c) => c.isSignatory);
  const year = Number(s.today.slice(0, 4));

  /* ---------- Besoins (pipeline) ---------- */
  const needValues: (typeof schema.needs.$inferInsert)[] = [
    { orgId, companyId: C.nolwen, contactId: signatory("nolwen"), kind: "formation", title: "Management d'équipe pour 3 leads techniques", programId: s.programs.management.id, headcount: 3, amountCents: 435000, stage: "proposition", probability: 60, expectedCloseDate: addD(s.today, 12), nextActionAt: daysAgo(s.today, 4), nextAction: "Relancer Maud Kerjean sur le devis envoyé", assignedUserId: users.direction, source: "Site web", isDemo: true },
    { orgId, companyId: C.hotel, contactId: signatory("hotel"), kind: "alternance", title: "Recrutement d'un apprenti BTS GPME pour la réception", programId: s.programs.bts.id, headcount: 1, amountCents: 790000, stage: "qualifie", probability: 40, expectedCloseDate: addD(s.today, 30), nextActionAt: daysAgo(s.today, 9), nextAction: "Proposer deux candidats (entretiens)", assignedUserId: users.direction, source: "Salon", isDemo: true },
    { orgId, companyId: C.clinique, contactId: signatory("clinique"), kind: "formation", title: "Accueil en établissement de santé (intra, 6 agents)", programId: s.programs.accueil.id, headcount: 6, amountCents: 260000, stage: "gagne", probability: 100, expectedCloseDate: daysAgo(s.today, 20), wonAt: new Date(`${daysAgo(s.today, 18)}T14:00:00Z`), assignedUserId: users.direction, source: "Ancien client", isDemo: true },
    { orgId, companyId: C.distrimarche, contactId: signatory("distrimarche"), kind: "formation", title: "SST initial pour 8 employés de rayon", programId: s.programs.sst.id, headcount: 8, amountCents: 169000, stage: "negociation", probability: 75, expectedCloseDate: addD(s.today, 8), nextActionAt: addD(s.today, 2), nextAction: "Envoyer la proposition intra révisée", assignedUserId: users.direction, source: "Prospection téléphonique", isDemo: true },
    { orgId, companyId: C.vauclair, contactId: signatory("vauclair"), kind: "formation", title: "Excel avancé pour le service gestion locative", programId: s.programs.excel.id, headcount: 4, amountCents: 316000, stage: "perdu", probability: 0, lostAt: new Date(`${daysAgo(s.today, 33)}T10:00:00Z`), lostReason: "Choix d'un prestataire en ligne moins cher.", assignedUserId: users.direction, source: "Ancien client", isDemo: true },
    { orgId, companyId: C.mairie, contactId: signatory("mairie"), kind: "formation", title: "Plan de formation 2027 : bureautique et accueil", headcount: 12, amountCents: 960000, stage: "nouveau", probability: 20, expectedCloseDate: addD(s.today, 90), nextActionAt: addD(s.today, 6), nextAction: "Rendez-vous de cadrage avec la DRH", assignedUserId: users.direction, source: "Appel entrant", isDemo: true },
    { orgId, companyId: C.berard, contactId: signatory("berard"), kind: "alternance", title: "Deux apprentis BTS GPME (exploitation et administration)", programId: s.programs.bts.id, headcount: 2, amountCents: 1580000, stage: "gagne", probability: 100, wonAt: new Date(`${daysAgo(s.today, 70)}T09:00:00Z`), assignedUserId: users.direction, source: "Ancien client", isDemo: true },
    { orgId, companyId: C.tilleuls, contactId: signatory("tilleuls"), kind: "formation", title: "Habilitation électrique pour 2 agents de maintenance", programId: s.programs.elec.id, headcount: 2, amountCents: 48000, stage: "gagne", probability: 100, wonAt: new Date(`${daysAgo(s.today, 10)}T16:00:00Z`), assignedUserId: users.direction, source: "Ancien client", isDemo: true },
    { orgId, personId: s.persons[s.persons.length - 2].id, kind: "formation", title: "Bilan de compétences (financement CPF)", programId: s.programs.bilan.id, headcount: 1, amountCents: 180000, stage: "qualifie", probability: 50, expectedCloseDate: addD(s.today, 40), nextActionAt: addD(s.today, 3), nextAction: "Entretien préalable gratuit (visio)", assignedUserId: users.pedagogy, source: "Site web", isDemo: true },
    { orgId, companyId: C.moretti, contactId: signatory("moretti"), kind: "recrutement", title: "Recrutement d'un apprenti pour l'atelier (rentrée 2027)", headcount: 1, amountCents: 790000, stage: "nouveau", probability: 20, expectedCloseDate: addD(s.today, 200), nextActionAt: addD(s.today, 20), nextAction: "Qualifier le poste et le tuteur", assignedUserId: users.direction, source: "Ancien client", isDemo: true },
  ];
  const needRows = await tx.insert(schema.needs).values(needValues).returning({ id: schema.needs.id });
  bump(s, "needs", needRows.length);

  /* ---------- Placements ---------- */
  const candidates = s.persons.slice(-4);
  const btsEnrs = s.enrollments.filter((e) => e.sessionKey === "bts");
  const placementValues: (typeof schema.placements.$inferInsert)[] = [
    { orgId, needId: needRows[1].id, personId: candidates[0].id, status: "entretien", proposedAt: new Date(`${daysAgo(s.today, 6)}T09:00:00Z`), interviewAt: new Date(`${addD(s.today, 4)}T10:00:00Z`), notes: "Profil accueil, anglais B2.", createdBy: users.direction },
    { orgId, needId: needRows[1].id, personId: candidates[3].id, status: "propose", proposedAt: new Date(`${daysAgo(s.today, 2)}T15:00:00Z`), notes: "Bac pro AGOrA, cherche un contrat d'apprentissage.", createdBy: users.direction },
    { orgId, needId: needRows[6].id, personId: btsEnrs[12].personId, status: "place", proposedAt: new Date(`${daysAgo(s.today, 85)}T09:00:00Z`), decidedAt: new Date(`${daysAgo(s.today, 72)}T09:00:00Z`), enrollmentId: btsEnrs[12].id, createdBy: users.direction },
    { orgId, needId: needRows[6].id, personId: btsEnrs[13].personId, status: "place", proposedAt: new Date(`${daysAgo(s.today, 85)}T09:00:00Z`), decidedAt: new Date(`${daysAgo(s.today, 72)}T09:00:00Z`), enrollmentId: btsEnrs[13].id, createdBy: users.direction },
    { orgId, needId: needRows[6].id, personId: candidates[1].id, status: "refuse", proposedAt: new Date(`${daysAgo(s.today, 85)}T09:00:00Z`), decidedAt: new Date(`${daysAgo(s.today, 78)}T09:00:00Z`), notes: "Entreprise a préféré un autre profil.", createdBy: users.direction },
    { orgId, needId: needRows[9].id, personId: candidates[2].id, status: "propose", proposedAt: new Date(`${daysAgo(s.today, 1)}T11:00:00Z`), notes: "Reconversion, RQTH : vérifier les aménagements du poste.", createdBy: users.direction },
  ];
  await tx.insert(schema.placements).values(placementValues);
  bump(s, "placements", placementValues.length);

  /* ---------- Interactions ---------- */
  const kinds = ["appel", "email", "rdv", "visio", "note", "relance", "courrier", "sms"] as const;
  const subjects = ["Point sur le besoin de formation", "Envoi du programme et des tarifs", "Relance devis", "Rendez-vous de cadrage", "Retour sur la session", "Demande de convention", "Question sur le financement OPCO", "Confirmation des dates"];
  const interactionValues: (typeof schema.interactions.$inferInsert)[] = [];
  const companyKeys = Object.keys(C);
  for (let i = 0; i < 20; i++) {
    const ck = companyKeys[i % companyKeys.length];
    interactionValues.push({ orgId, companyId: C[ck], contactId: contact(ck), needId: i < needRows.length ? needRows[i].id : null, kind: kinds[i % kinds.length], subject: subjects[i % subjects.length], body: rng.pick(["Échange cordial, intérêt confirmé.", "Attend la validation budgétaire interne.", "Souhaite un démarrage avant la fin de l'année.", "A transmis la liste des participants.", null]), at: new Date(`${daysAgo(s.today, rng.int(0, 60))}T${String(rng.int(9, 17)).padStart(2, "0")}:${rng.pick(["00", "15", "30", "45"])}:00Z`), nextActionAt: i % 5 === 0 ? addD(s.today, rng.int(1, 14)) : null, nextAction: i % 5 === 0 ? "Rappeler" : null, userId: i % 3 === 0 ? users.direction : users.admin });
  }
  await tx.insert(schema.interactions).values(interactionValues);
  bump(s, "interactions", interactionValues.length);

  /* ---------- Devis ---------- */
  /** Totaux en centimes : HT = somme des lignes, TVA calculée par taux (même règle que le module devis). */
  const q = (lines: { label: string; description?: string; qty: number; unitCents: number; vatRateBp: number }[]) => {
    const totalHtCents = lines.reduce((a, l) => a + Math.round(l.qty * l.unitCents), 0);
    const vatCents = lines.reduce((a, l) => a + Math.round((Math.round(l.qty * l.unitCents) * l.vatRateBp) / 10000), 0);
    return { lines, totalHtCents, vatCents, totalTtcCents: totalHtCents + vatCents };
  };
  const quoteDefs = [
    { number: `DEV-${year}-0001`, companyKey: "clinique", needIdx: 2, title: "Accueil en établissement de santé : formation intra (6 agents)", status: "accepte" as const, issueDate: daysAgo(s.today, 24), validUntil: daysAgo(s.today, -6), sentAt: daysAgo(s.today, 24), acceptedAt: daysAgo(s.today, 18), ...q([{ label: "Formation intra « Accueil en établissement de santé », 2 jours, 6 participants", qty: 1, unitCents: 260000, vatRateBp: 0 }]) },
    { number: `DEV-${year}-0002`, companyKey: "nolwen", needIdx: 0, title: "Management d'équipe : 3 participants, session inter de novembre", status: "envoye" as const, issueDate: daysAgo(s.today, 11), validUntil: addD(s.today, 19), sentAt: daysAgo(s.today, 11), acceptedAt: null, ...q([{ label: "Management d'équipe : les fondamentaux (3 jours), par participant", qty: 3, unitCents: 145000, vatRateBp: 0 }]) },
    { number: `DEV-${year}-0003`, companyKey: "vauclair", needIdx: 4, title: "Excel avancé : 4 participants", status: "refuse" as const, issueDate: daysAgo(s.today, 45), validUntil: daysAgo(s.today, 15), sentAt: daysAgo(s.today, 45), acceptedAt: null, ...q([{ label: "Excel avancé (2 jours), par participant", qty: 4, unitCents: 79000, vatRateBp: 0 }, { label: "Certification TOSA Excel (option)", qty: 4, unitCents: 9500, vatRateBp: 2000 }]) },
    { number: `DEV-${year}-0004`, companyKey: "distrimarche", needIdx: 3, title: "SST initial en intra : 8 employés", status: "brouillon" as const, issueDate: daysAgo(s.today, 1), validUntil: addD(s.today, 29), sentAt: null, acceptedAt: null, ...q([{ label: "Formation SST intra, 2 jours, groupe de 4 à 10 stagiaires", qty: 1, unitCents: 169000, vatRateBp: 0 }, { label: "Location de matériel de simulation", qty: 1, unitCents: 12000, vatRateBp: 2000 }]) },
  ];
  await tx.insert(schema.quotes).values(
    quoteDefs.map((d) => ({
      orgId,
      number: d.number,
      companyId: C[d.companyKey],
      contactId: signatory(d.companyKey),
      needId: needRows[d.needIdx].id,
      title: d.title,
      status: d.status,
      lines: d.lines,
      totalHtCents: d.totalHtCents,
      vatCents: d.vatCents,
      totalTtcCents: d.totalTtcCents,
      issueDate: d.issueDate,
      validUntil: d.validUntil,
      sentAt: d.sentAt ? new Date(`${d.sentAt}T10:00:00Z`) : null,
      acceptedAt: d.acceptedAt ? new Date(`${d.acceptedAt}T10:00:00Z`) : null,
      createdBy: users.direction,
    })),
  );
  await tx.insert(schema.invoiceSequences).values({ orgId, kind: "devis", year, next: 5 }).onConflictDoUpdate({ target: [schema.invoiceSequences.orgId, schema.invoiceSequences.kind, schema.invoiceSequences.year], set: { next: 5 } });
  bump(s, "quotes", 4);

  /* ---------- Financeurs ---------- */
  const funderRows = await tx
    .insert(schema.funders)
    .values([
      { orgId, name: "OPCO Atlas", kind: "opco", contactName: "Service apprentissage", email: "apprentissage@opco-atlas.exemple.fr", addressLine1: "25 quai Panhard-et-Levassor", postalCode: "75013", city: "Paris" },
      { orgId, name: "OPCO 2i", kind: "opco", contactName: "Pôle alternance Île-de-France", email: "alternance-idf@opco2i.exemple.fr", addressLine1: "55 rue de Châteaudun", postalCode: "75009", city: "Paris" },
      { orgId, name: "France Travail Île-de-France", kind: "france_travail", contactName: "Service AIF", email: "aif.idf@francetravail.exemple.fr", addressLine1: "3 rue Galilée", postalCode: "93160", city: "Noisy-le-Grand" },
      { orgId, name: "Région Île-de-France", kind: "region", contactName: "Direction de la formation professionnelle", email: "formation@iledefrance.exemple.fr", addressLine1: "2 rue Simone-Veil", postalCode: "93400", city: "Saint-Ouen" },
      { orgId, name: "Clinique Sainte-Odile", kind: "entreprise", companyId: C.clinique, contactName: "Nathalie Pons (comptabilité)", email: "compta@clinique-sainte-odile.exemple.fr" },
      { orgId, name: "Distrimarché Île-de-France", kind: "entreprise", companyId: C.distrimarche, contactName: "Loïc Garnier", email: "compta@distrimarche-ile-de-france.exemple.fr" },
      { orgId, name: "Transports Bérard", kind: "entreprise", companyId: C.berard, contactName: "Gilles Bérard", email: "gilles.berard@transports-berard.exemple.fr" },
      { orgId, name: "Particuliers (autofinancement et CPF)", kind: "particulier", notes: "Dossiers CPF via EDOF ; paiement direct pour les autres." },
    ])
    .returning({ id: schema.funders.id });
  s.funders = { atlas: funderRows[0].id, opco2i: funderRows[1].id, franceTravail: funderRows[2].id, region: funderRows[3].id, clinique: funderRows[4].id, distrimarche: funderRows[5].id, berard: funderRows[6].id, particulier: funderRows[7].id };
  bump(s, "funders", funderRows.length);

  /* ---------- Abonnement et objectifs ---------- */
  await tx.insert(schema.subscriptions).values({ orgId, planCode: "orga", options: ["opt_signature", "opt_emargement", "opt_lms"], status: "active", billingCycle: "annual", startedAt: `${year}-01-01` });
  await tx.insert(schema.objectives).values([
    { orgId, metric: "enrollments", label: "Inscriptions sur l'année civile", periodStart: `${year}-01-01`, periodEnd: `${year}-12-31`, target: 120, unit: "count" },
    { orgId, metric: "satisfaction", label: "Satisfaction à chaud (moyenne)", periodStart: `${year}-01-01`, periodEnd: `${year}-12-31`, target: 90, unit: "percent" },
    { orgId, metric: "revenue", label: "Chiffre d'affaires facturé", periodStart: `${year}-01-01`, periodEnd: `${year}-12-31`, target: 48000000, unit: "cents" },
  ]);
  bump(s, "subscriptions", 1);
  bump(s, "objectives", 3);
}
