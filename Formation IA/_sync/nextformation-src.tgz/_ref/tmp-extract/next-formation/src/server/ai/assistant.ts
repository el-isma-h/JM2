import "server-only";
import { and, asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { complete, extractJson, pickProvider, type ChatMessage } from "./provider";
import { availableTools, enrollmentSummary, runTool } from "./tools";
import { agentsForEntity } from "./agents";
import { deterministicDossier } from "./agents/dossier";
import { AGENT_SYSTEM_BASE } from "./agents/shared";

export type ConversationRow = typeof schema.assistantConversations.$inferSelect;
export type MessageRow = typeof schema.assistantMessages.$inferSelect;

export type AssistantContext = { entityType?: string | null; entityId?: string | null };

const MAX_TOOL_CALLS = 6;

export async function getConversation(ctx: OrgContext, id: string): Promise<ConversationRow | null> {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const [c] = await db.select().from(schema.assistantConversations).where(and(eq(schema.assistantConversations.id, id), eq(schema.assistantConversations.orgId, ctx.org.id), eq(schema.assistantConversations.userId, ctx.user.id))).limit(1);
  return c ?? null;
}

export async function listConversations(ctx: OrgContext, limit = 15): Promise<ConversationRow[]> {
  return db.select().from(schema.assistantConversations).where(and(eq(schema.assistantConversations.orgId, ctx.org.id), eq(schema.assistantConversations.userId, ctx.user.id))).orderBy(desc(schema.assistantConversations.updatedAt)).limit(limit);
}

export async function listMessages(conversationId: string): Promise<MessageRow[]> {
  return db.select().from(schema.assistantMessages).where(eq(schema.assistantMessages.conversationId, conversationId)).orderBy(asc(schema.assistantMessages.createdAt));
}

export async function createConversation(ctx: OrgContext, context: AssistantContext, title: string): Promise<ConversationRow> {
  const [c] = await db
    .insert(schema.assistantConversations)
    .values({ userId: ctx.user.id, orgId: ctx.org.id, title: title.slice(0, 120), context: { entityType: context.entityType ?? null, entityId: context.entityId ?? null } })
    .returning();
  return c;
}

function systemPrompt(ctx: OrgContext, context: AssistantContext): string {
  const tools = availableTools(ctx)
    .map((t) => `- ${t.name} : ${t.description}`)
    .join("\n");
  const agents = agentsForEntity(ctx, context.entityType)
    .map((a) => `- ${a.name} : ${a.description}`)
    .join("\n");
  return `${AGENT_SYSTEM_BASE}

Tu es l'assistant de ${ctx.org.tradeName ?? ctx.org.legalName}. L'utilisateur est ${ctx.user.firstName} ${ctx.user.lastName} (rôles : ${ctx.roles.join(", ") || "aucun"}). Tu n'as accès qu'aux outils de lecture ci-dessous, déjà filtrés par ses habilitations : si une information n'est pas accessible, dis-le, ne la devine pas.
${context.entityType && context.entityId ? `Contexte courant : ${context.entityType} ${context.entityId}.` : "Aucun contexte d'entité."}

Outils (lecture seule) :
${tools || "- aucun"}

Agents disponibles (ils produisent des propositions soumises à validation humaine ; tu ne les lances pas toi-même, tu invites l'utilisateur à cliquer « Proposer ») :
${agents || "- aucun"}

Protocole de réponse, en JSON strict, un objet par tour :
- pour consulter un outil : {"tool": "<nom>", "args": {...}}
- pour répondre : {"answer": "<réponse en français, concise, structurée, sans tiret cadratin>", "suggest": ["<nom d'agent>", ...]}
Tu peux enchaîner au plus ${MAX_TOOL_CALLS} outils avant de répondre. Cite les références (numéro d'inscription, session) utilisées.`;
}

export type AssistantTurn = { text: string; meta: Record<string, unknown>; provider: string | null; model: string | null };

/** Réponse sans modèle : résumé déterministe du dossier en contexte, sinon explication de la configuration. */
async function deterministicTurn(ctx: OrgContext, context: AssistantContext, question: string): Promise<AssistantTurn> {
  if (context.entityType === "enrollment" && context.entityId) {
    const s = await enrollmentSummary(ctx, context.entityId);
    if (s) {
      const d = deterministicDossier(s as Parameters<typeof deterministicDossier>[0]);
      return { text: d.text, meta: { deterministic: true, tools: ["get_enrollment"], question }, provider: null, model: null };
    }
  }
  const m = question.match(/(?:inscription|dossier|apprenant)\s+([\p{L}' -]{3,})$/iu);
  if (m) {
    const found = (await runTool(ctx, "find_enrollment", { query: m[1].trim() })) as { id: string; reference: string; firstName: string; lastName: string; session: string; status: string }[] | { error: string };
    if (Array.isArray(found) && found.length) {
      const lines = found.map((f) => `- ${f.reference} : ${f.firstName} ${f.lastName}, ${f.session} (${f.status})`).join("\n");
      return { text: `Sans clé IA, je peux chercher et résumer. Inscriptions trouvées :\n${lines}\n\nOuvrez l'assistant avec le contexte d'une inscription (bouton « Analyser avec l'assistant » du dossier) pour obtenir son résumé.`, meta: { deterministic: true, tools: ["find_enrollment"] }, provider: null, model: null };
    }
  }
  return {
    text: "L'assistant conversationnel n'est pas configuré (aucune clé ANTHROPIC_API_KEY, OPENAI_API_KEY ou XAI_API_KEY). Sans clé, je fournis les actions déterministes : résumé de dossier (ouvrez l'assistant depuis une inscription), proposition de calendrier, synthèse qualité, relances à partir de gabarits. Demandez au propriétaire de l'organisme de renseigner une clé pour les réponses libres.",
    meta: { deterministic: true },
    provider: null,
    model: null,
  };
}

/** Un tour de conversation : boucle outils (lecture seule) puis réponse. Sans clé : repli déterministe. */
export async function runAssistantTurn(ctx: OrgContext, context: AssistantContext, history: MessageRow[], question: string): Promise<AssistantTurn> {
  if (!pickProvider()) return deterministicTurn(ctx, context, question);
  const system = systemPrompt(ctx, context);
  const messages: ChatMessage[] = history
    .filter((m) => m.role === "user" || m.role === "assistant")
    .slice(-12)
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));
  messages.push({ role: "user", content: question });
  const toolsUsed: { tool: string; args: unknown }[] = [];
  let provider: string | null = null;
  let model: string | null = null;
  for (let i = 0; i <= MAX_TOOL_CALLS; i++) {
    const res = await complete({ system, messages, json: true, maxTokens: 1500 });
    provider = res.provider;
    model = res.model;
    const parsed = extractJson(res.text) as { tool?: string; args?: unknown; answer?: string; suggest?: unknown } | null;
    if (!parsed) return { text: res.text.trim() || "Je n'ai pas pu formuler de réponse.", meta: { tools: toolsUsed }, provider, model };
    if (parsed.tool && i < MAX_TOOL_CALLS) {
      const out = await runTool(ctx, parsed.tool, parsed.args);
      toolsUsed.push({ tool: parsed.tool, args: parsed.args });
      await audit({ action: "ai.tool.read", userId: ctx.user.id, orgId: ctx.org.id, entityType: "assistant_tool", after: { tool: parsed.tool, args: parsed.args } });
      messages.push({ role: "assistant", content: JSON.stringify({ tool: parsed.tool, args: parsed.args }) });
      messages.push({ role: "user", content: `Résultat de ${parsed.tool} :\n${JSON.stringify(out).slice(0, 12000)}` });
      continue;
    }
    const suggest = Array.isArray(parsed.suggest) ? parsed.suggest.filter((s): s is string => typeof s === "string") : [];
    return { text: parsed.answer ?? res.text, meta: { tools: toolsUsed, suggest }, provider, model };
  }
  return { text: "Trop d'étapes de recherche : reformulez votre question.", meta: { tools: toolsUsed }, provider, model };
}
