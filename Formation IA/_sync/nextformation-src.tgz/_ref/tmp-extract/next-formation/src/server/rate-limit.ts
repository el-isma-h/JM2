import "server-only";
import { headers } from "next/headers";
import { sql } from "drizzle-orm";
import { db } from "@/db";

/**
 * Limitation de débit à fenêtre fixe, stockée en base (table `rate_limits`) : partagée entre instances
 * et conservée au redémarrage. Un seul aller-retour SQL atomique par tentative.
 *
 *   const rl = await hit("login:ip", ip, { limit: 20, windowSeconds: 900 });
 *   if (!rl.ok) return { error: tooManyMessage(rl) };
 */

export type RateLimitRule = { limit: number; windowSeconds: number };
export type RateLimitResult = { ok: boolean; remaining: number; retryAfterSeconds: number };

export const RATE_LIMITS = {
  loginIp: { limit: 30, windowSeconds: 15 * 60 },
  loginEmail: { limit: 8, windowSeconds: 15 * 60 },
  signupIp: { limit: 5, windowSeconds: 60 * 60 },
  resetIp: { limit: 10, windowSeconds: 60 * 60 },
  resetEmail: { limit: 3, windowSeconds: 60 * 60 },
  resendVerification: { limit: 5, windowSeconds: 60 * 60 },
  invitationIp: { limit: 20, windowSeconds: 60 * 60 },
  elevate: { limit: 8, windowSeconds: 15 * 60 },
  demoIp: { limit: 10, windowSeconds: 60 * 60 },
} satisfies Record<string, RateLimitRule>;

/** Adresse IP du client. Derrière un proxy (Caddy, Nginx, load balancer), c'est la dernière entrée de X-Forwarded-For qu'il a ajoutée. */
export async function clientIp(): Promise<string> {
  const h = await headers();
  const real = h.get("x-real-ip")?.trim();
  const forwarded = (h.get("x-forwarded-for") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  const ip = real || forwarded.at(-1) || "";
  return /^[0-9a-f.:]{2,45}$/i.test(ip) ? ip : "inconnue";
}

export async function hit(scope: string, subject: string, rule: RateLimitRule): Promise<RateLimitResult> {
  const key = `${scope}:${subject.toLowerCase()}`.slice(0, 300);
  const interval = `${rule.windowSeconds} seconds`;
  const res = await db.execute<{ count: number; elapsed: number }>(sql`
    insert into rate_limits (key, count, window_start) values (${key}, 1, now())
    on conflict (key) do update set
      count = case when rate_limits.window_start < now() - ${interval}::interval then 1 else rate_limits.count + 1 end,
      window_start = case when rate_limits.window_start < now() - ${interval}::interval then now() else rate_limits.window_start end
    returning count, extract(epoch from (now() - window_start))::int as elapsed
  `);
  const row = res.rows[0];
  const count = Number(row?.count ?? 1);
  const elapsed = Number(row?.elapsed ?? 0);
  return { ok: count <= rule.limit, remaining: Math.max(0, rule.limit - count), retryAfterSeconds: Math.max(1, rule.windowSeconds - elapsed) };
}

/** Remet un compteur à zéro (ex. connexion réussie pour cet e-mail). */
export async function resetHits(scope: string, subject: string) {
  await db.execute(sql`delete from rate_limits where key = ${`${scope}:${subject.toLowerCase()}`.slice(0, 300)}`);
}

export function tooManyMessage(r: RateLimitResult): string {
  const minutes = Math.ceil(r.retryAfterSeconds / 60);
  return `Trop de tentatives. Réessayez dans ${minutes} minute${minutes > 1 ? "s" : ""}.`;
}

/** Purge des fenêtres expirées (tâche maintenance:purge). */
export async function purgeRateLimits(): Promise<number> {
  const res = await db.execute(sql`delete from rate_limits where window_start < now() - interval '1 day'`);
  return res.rowCount ?? 0;
}
