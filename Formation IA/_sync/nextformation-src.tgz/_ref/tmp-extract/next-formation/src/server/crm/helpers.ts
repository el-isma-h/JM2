import { z } from "zod";
import { authErrorMessage } from "@/server/guard";
import type { ActionState } from "@/server/actions/auth";

/** Helpers communs aux actions du module commercial / catalogue / formateurs (fichiers non « use server »). */

export const uuid = z.string().uuid("Identifiant invalide");

export function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

/** Chaîne de formulaire : trim, vide → null. */
export function str(formData: FormData, key: string, max = 2000): string | null {
  const v = formData.get(key);
  if (typeof v !== "string") return null;
  const t = v.trim();
  if (!t) return null;
  if (t.length > max) throw new z.ZodError([{ code: "custom", message: `Le champ « ${key} » est trop long (${max} caractères maximum).`, path: [key], input: v }]);
  return t;
}

export function int(formData: FormData, key: string, opts: { min?: number; max?: number } = {}): number | null {
  const raw = str(formData, key, 20);
  if (raw === null) return null;
  const n = Number(raw.replace(/\s/g, "").replace(",", "."));
  if (!Number.isFinite(n) || !Number.isInteger(n)) throw new z.ZodError([{ code: "custom", message: `Le champ « ${key} » doit être un nombre entier.`, path: [key], input: raw }]);
  if (opts.min !== undefined && n < opts.min) throw new z.ZodError([{ code: "custom", message: `Le champ « ${key} » doit être au moins ${opts.min}.`, path: [key], input: raw }]);
  if (opts.max !== undefined && n > opts.max) throw new z.ZodError([{ code: "custom", message: `Le champ « ${key} » doit être au plus ${opts.max}.`, path: [key], input: raw }]);
  return n;
}

export function bool(formData: FormData, key: string): boolean {
  const v = formData.get(key);
  return v === "on" || v === "1" || v === "true";
}

/** Liste de valeurs séparées par des virgules ou retours à la ligne → tableau dédoublonné. */
export function tagList(raw: string | null): string[] {
  if (!raw) return [];
  return [...new Set(raw.split(/[,\n;]/).map((t) => t.trim()).filter(Boolean))].slice(0, 50);
}

export function isoDate(formData: FormData, key: string): string | null {
  const raw = str(formData, key, 20);
  if (!raw) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) throw new z.ZodError([{ code: "custom", message: "Date invalide (format AAAA-MM-JJ).", path: [key], input: raw }]);
  return raw;
}

export function optEmail(formData: FormData, key = "email"): string | null {
  const raw = str(formData, key, 200);
  if (!raw) return null;
  const r = z.string().email("Adresse e-mail invalide").safeParse(raw.toLowerCase());
  if (!r.success) throw new z.ZodError(r.error.issues);
  return r.data;
}

export function fullName(p: { firstName: string; lastName: string }) {
  return `${p.firstName} ${p.lastName}`.trim();
}
