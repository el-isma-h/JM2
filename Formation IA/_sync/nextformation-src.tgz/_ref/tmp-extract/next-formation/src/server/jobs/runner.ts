import "server-only";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { getJobHandler } from "./registry";
import "./handlers";

/**
 * Runner des tâches de fond (table `jobs`).
 * - Prise atomique des tâches dues (`queued`, `run_after <= now()`) avec `FOR UPDATE SKIP LOCKED` :
 *   deux runners simultanés (cron + bouton admin) ne prennent jamais la même tâche.
 * - Tentatives : 3 au maximum, nouvel essai différé (2, 4 puis 8 minutes) ; au-delà, statut `failed`.
 * - Une tâche `running` depuis plus de 30 minutes (processus interrompu) est remise en file.
 * - Les tâches récurrentes (nettoyage démo, rappels de tâches) sont replanifiées automatiquement.
 */

export const MAX_ATTEMPTS = 3;
const STALE_MINUTES = 30;

/** Tâches récurrentes : intervalle en minutes. */
export const RECURRING_JOBS: Record<string, number> = {
  "demo:cleanup": 60,
  "maintenance:purge": 60,
  "tasks:remind": 24 * 60,
  "finance:overdue": 24 * 60,
  "surveys:dispatch": 24 * 60,
  "followups:remind": 24 * 60,
  "chorus:status": 6 * 60,
  "workflows:remind": 24 * 60,
  "missions:remind": 24 * 60,
  "certifications:remind": 24 * 60,
};

export type JobRow = typeof schema.jobs.$inferSelect;

export async function enqueueJob(input: { kind: string; payload?: Record<string, unknown>; tenantId?: string | null; orgId?: string | null; runAfter?: Date }) {
  const [row] = await db
    .insert(schema.jobs)
    .values({ kind: input.kind, payload: input.payload ?? {}, tenantId: input.tenantId ?? null, orgId: input.orgId ?? null, runAfter: input.runAfter ?? new Date() })
    .returning();
  return row;
}

/**
 * Planifie `kind` s'il n'existe aucune occurrence en file (ou en cours, si `includeRunning`).
 * Verrou consultatif transactionnel : deux runners simultanés ne créent pas de doublon.
 */
async function scheduleIfAbsent(kind: string, runAfter: Date, includeRunning: boolean): Promise<boolean> {
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${`nextformation:jobs:${kind}`}))`);
    const [pending] = await tx
      .select({ id: schema.jobs.id })
      .from(schema.jobs)
      .where(and(eq(schema.jobs.kind, kind), inArray(schema.jobs.status, includeRunning ? ["queued", "running"] : ["queued"])))
      .limit(1);
    if (pending) return false;
    await tx.insert(schema.jobs).values({ kind, runAfter });
    return true;
  });
}

/** Garantit qu'une occurrence de chaque tâche récurrente est planifiée. */
export async function ensureRecurringJobs(): Promise<string[]> {
  const created: string[] = [];
  for (const kind of Object.keys(RECURRING_JOBS)) {
    if (await scheduleIfAbsent(kind, new Date(), true)) created.push(kind);
  }
  return created;
}

type Claimed = { id: string; kind: string; payload: Record<string, unknown>; attempts: string; tenant_id: string | null; org_id: string | null };

async function claim(limit: number): Promise<Claimed[]> {
  const res = await db.execute<Claimed>(sql`
    UPDATE ${schema.jobs} AS j
    SET status = 'running', started_at = now(), finished_at = NULL, attempts = ((j.attempts)::int + 1)::text
    WHERE j.id IN (
      SELECT id FROM ${schema.jobs}
      WHERE status = 'queued' AND run_after <= now()
      ORDER BY run_after
      LIMIT ${limit}
      FOR UPDATE SKIP LOCKED
    )
    RETURNING j.id, j.kind, j.payload, j.attempts, j.tenant_id, j.org_id
  `);
  return res.rows;
}

async function recoverStale(): Promise<number> {
  const res = await db.execute(sql`
    UPDATE ${schema.jobs} SET status = 'queued', error = 'Reprise après interruption (tâche bloquée en cours)'
    WHERE status = 'running' AND started_at < now() - (${STALE_MINUTES} * interval '1 minute')
  `);
  return res.rowCount ?? 0;
}

export type RunReport = { claimed: number; done: number; failed: number; retried: number; recovered: number; scheduled: string[]; results: { id: string; kind: string; status: string; error?: string }[] };

export async function runDueJobs(opts: { limit?: number } = {}): Promise<RunReport> {
  const recovered = await recoverStale();
  const scheduled = await ensureRecurringJobs();
  const jobs = await claim(opts.limit ?? 10);
  const report: RunReport = { claimed: jobs.length, done: 0, failed: 0, retried: 0, recovered, scheduled, results: [] };

  for (const job of jobs) {
    const attempts = Number(job.attempts) || 1;
    const handler = getJobHandler(job.kind);
    try {
      if (!handler) throw new Error(`Aucun traitement n'est défini pour le type de tâche « ${job.kind} ».`);
      const result = await handler({ id: job.id, kind: job.kind, payload: job.payload ?? {}, tenantId: job.tenant_id, orgId: job.org_id });
      await db
        .update(schema.jobs)
        .set({ status: "done", result: (result ?? null) as Record<string, unknown> | null, error: null, finishedAt: new Date() })
        .where(eq(schema.jobs.id, job.id));
      report.done++;
      report.results.push({ id: job.id, kind: job.kind, status: "done" });
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      const retry = handler && attempts < MAX_ATTEMPTS;
      await db
        .update(schema.jobs)
        .set(
          retry
            ? { status: "queued", error: `Tentative ${attempts} : ${message}`, runAfter: new Date(Date.now() + 2 ** attempts * 60_000) }
            : { status: "failed", error: message, finishedAt: new Date() },
        )
        .where(eq(schema.jobs.id, job.id));
      if (retry) report.retried++;
      else report.failed++;
      report.results.push({ id: job.id, kind: job.kind, status: retry ? "queued" : "failed", error: message });
    }
    const interval = RECURRING_JOBS[job.kind];
    if (interval) await scheduleIfAbsent(job.kind, new Date(Date.now() + interval * 60_000), false);
  }
  return report;
}

/** Remet une tâche en file immédiatement (relance manuelle depuis l'admin). */
export async function requeueJob(jobId: string) {
  const [row] = await db
    .update(schema.jobs)
    .set({ status: "queued", runAfter: new Date(), error: null, attempts: "0", finishedAt: null })
    .where(and(eq(schema.jobs.id, jobId), inArray(schema.jobs.status, ["failed", "done", "queued"])))
    .returning();
  return row ?? null;
}
