import { describe, expect, it } from "vitest";
import { certificationAlert, credentialLeak, normalizeCertifier } from "../rules";

describe("certifications : certificateur", () => {
  it("normalise les libellés du catalogue", () => {
    expect(normalizeCertifier("tosa")).toBe("tosa");
    expect(normalizeCertifier("Certificat Voltaire")).toBe("voltaire");
    expect(normalizeCertifier("CléA Numérique")).toBe("clea");
    expect(normalizeCertifier("Bright")).toBe("autre");
    expect(normalizeCertifier("  ")).toBeNull();
    expect(normalizeCertifier(null)).toBeNull();
  });
});

describe("certifications : alertes J-15", () => {
  it("Voltaire : alerte 15 jours avant l'examen tant que la session n'est pas organisée", () => {
    const base = { certifier: "voltaire" as const, examDate: "2026-12-01", sessionEndDate: "2026-12-10" };
    expect(certificationAlert({ ...base, status: "a_inscrire", today: "2026-11-15" })).toBeNull();
    expect(certificationAlert({ ...base, status: "a_inscrire", today: "2026-11-16" })).toEqual({ kind: "voltaire_j15", due: "2026-11-16" });
    expect(certificationAlert({ ...base, status: "session_planifiee", today: "2026-11-20" })).toBeNull();
    expect(certificationAlert({ ...base, status: "reussie", today: "2026-11-20" })).toBeNull();
  });
  it("autres certificateurs : alerte si encore à inscrire 15 jours avant la fin de session", () => {
    const base = { certifier: "tosa" as const, examDate: null, sessionEndDate: "2026-12-10" };
    expect(certificationAlert({ ...base, status: "a_inscrire", today: "2026-11-24" })).toBeNull();
    expect(certificationAlert({ ...base, status: "a_inscrire", today: "2026-11-25" })).toEqual({ kind: "a_inscrire_j15", due: "2026-11-25" });
    expect(certificationAlert({ ...base, status: "inscrit", today: "2026-12-01" })).toBeNull();
  });
  it("Voltaire sans date d'examen : règle générale", () => {
    expect(certificationAlert({ certifier: "voltaire", status: "a_inscrire", examDate: null, sessionEndDate: "2026-12-10", today: "2026-11-30" })).toEqual({ kind: "a_inscrire_j15", due: "2026-11-25" });
  });
});

describe("certifications : aucun identifiant stocké", () => {
  it("détecte les identifiants et mots de passe", () => {
    expect(credentialLeak("login: candidat42 / mdp Azerty")).not.toBeNull();
    expect(credentialLeak("Mot de passe envoyé par mail")).not.toBeNull();
    expect(credentialLeak("Voucher 12 months 4 skills, CPF")).toBeNull();
    expect(credentialLeak(null)).toBeNull();
  });
});
