import { describe, expect, it } from "vitest";
import { isApplicable, isDecidable, isExpired, transitionProposal } from "../proposals";

describe("transitionProposal : validation humaine systématique", () => {
  it("proposee → validee → appliquee, une seule fois", () => {
    const v = transitionProposal("proposee", "valider");
    expect(v).toEqual({ ok: true, status: "validee" });
    const a = transitionProposal("validee", "appliquer");
    expect(a).toEqual({ ok: true, status: "appliquee" });
    expect(transitionProposal("appliquee", "appliquer").ok).toBe(false);
    expect(transitionProposal("appliquee", "refuser").ok).toBe(false);
  });
  it("refuse d'appliquer une proposition non validée", () => {
    const r = transitionProposal("proposee", "appliquer");
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toMatch(/validée/);
  });
  it("refus possible depuis proposee et validee, puis état final", () => {
    expect(transitionProposal("proposee", "refuser")).toEqual({ ok: true, status: "refusee" });
    expect(transitionProposal("validee", "refuser")).toEqual({ ok: true, status: "refusee" });
    expect(transitionProposal("refusee", "valider").ok).toBe(false);
    expect(transitionProposal("expiree", "valider").ok).toBe(false);
  });
  it("prédicats et expiration", () => {
    expect(isDecidable("proposee")).toBe(true);
    expect(isDecidable("validee")).toBe(false);
    expect(isApplicable("validee")).toBe(true);
    expect(isApplicable("proposee")).toBe(false);
    expect(isExpired(new Date("2026-01-01"), new Date("2026-02-15"))).toBe(true);
    expect(isExpired(new Date("2026-01-01"), new Date("2026-01-20"))).toBe(false);
  });
});
