"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { randomToken, sha256 } from "@/lib/crypto";
import { todayParis } from "@/lib/time";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { assertEnrollmentInExtranetScope, getEmployerContext } from "@/server/extranet/context";
import { listPendingSignatures, listPieces, listVisibleDocuments } from "@/server/extranet/queries";
import { createDocument } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

async function requireEmployer() {
  const ctx = await getEmployerContext();
  if (!ctx) throw new Error("Aucune entreprise rattachée à votre compte.");
  return ctx;
}

const commentSchema = z.object({
  enrollmentId: uuid,
  title: z.string().trim().min(3, "Titre requis (3 caractères minimum)").max(120),
  body: z.string().trim().min(5, "Commentaire requis (5 caractères minimum)").max(4000),
});

/**
 * Commentaire du tuteur dans le livret de l'apprenti / salarié : entrée `record_entries` de type `entreprise`,
 * visible par l'entreprise et par l'apprenant, auteur = contact de l'entreprise connecté.
 */
export async function addCompanyCommentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireEmployer();
    const d = commentSchema.parse(Object.fromEntries(formData));
    assertEnrollmentInExtranetScope(ctx, d.enrollmentId);
    const authorName = ctx.contact ? `${ctx.contact.firstName} ${ctx.contact.lastName}` : `${ctx.user.firstName} ${ctx.user.lastName}`;
    const [row] = await db
      .insert(schema.recordEntries)
      .values({
        orgId: ctx.org.id,
        enrollmentId: d.enrollmentId,
        kind: "entreprise",
        date: todayParis(),
        title: d.title,
        body: d.body,
        authorId: ctx.user.id,
        authorRole: `Tuteur entreprise (${authorName}, ${ctx.company.name})`,
        visibleToLearner: true,
        visibleToCompany: true,
      })
      .returning({ id: schema.recordEntries.id });
    await audit({ action: "record_entry.company_comment", userId: ctx.user.id, orgId: ctx.org.id, entityType: "record_entry", entityId: row.id, after: { enrollmentId: d.enrollmentId, title: d.title } });
    revalidatePath("/entreprise/suivi");
    revalidatePath(`/entreprise/apprenants/${d.enrollmentId}`);
    return { ok: true, message: "Commentaire ajouté au livret. L'équipe pédagogique et l'apprenant le voient." };
  } catch (e) {
    return fail(e, "Le commentaire n'a pas pu être enregistré.");
  }
}

/**
 * Ouvre une demande de signature en attente pour un contact de l'entreprise : régénère le jeton du signataire
 * correspondant à l'utilisateur connecté (seule l'empreinte est stockée) et redirige vers /signer/[token].
 */
export async function openSignatureAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target: string | null = null;
  try {
    const ctx = await requireEmployer();
    const requestId = uuid.parse(formData.get("requestId"));
    const docs = await listVisibleDocuments(ctx.org.id, { enrollmentIds: ctx.enrollmentIds, companyId: ctx.company.id }, ["entreprise", "public"]);
    const pending = await listPendingSignatures(ctx.org.id, docs.map((d) => d.id));
    const req = pending.find((r) => r.id === requestId);
    if (!req) return { error: "Demande de signature introuvable ou déjà traitée." };
    const emails = new Set([ctx.user.email.toLowerCase(), ...(ctx.contact?.email ? [ctx.contact.email.toLowerCase()] : [])]);
    const signers = (Array.isArray(req.signers) ? req.signers : []) as { name?: string; email?: string; role?: string; tokenHash?: string; signedAt?: string | null }[];
    const idx = signers.findIndex((s) => s.email && emails.has(s.email.toLowerCase()) && !s.signedAt);
    if (idx < 0) return { error: "Aucune signature n'est attendue de votre part sur ce document (vérifiez l'adresse e-mail du signataire désigné)." };
    const token = randomToken(24);
    signers[idx] = { ...signers[idx], tokenHash: sha256(token) };
    await db.update(schema.signatureRequests).set({ signers }).where(and(eq(schema.signatureRequests.id, req.id), eq(schema.signatureRequests.orgId, ctx.org.id)));
    await audit({ action: "signature.open_from_extranet", userId: ctx.user.id, orgId: ctx.org.id, entityType: "signature_request", entityId: req.id });
    target = `/signer/${token}`;
  } catch (e) {
    return fail(e, "Impossible d'ouvrir la signature.");
  }
  redirect(target);
}

/** Ouvre une enquête employeur en attente (jeton régénéré pour le contact connecté). */
export async function openEmployerSurveyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target: string | null = null;
  try {
    const ctx = await requireEmployer();
    const responseId = uuid.parse(formData.get("responseId"));
    const contactIds = ctx.contacts.map((c) => c.id);
    const [r] = await db.select().from(schema.surveyResponses).where(and(eq(schema.surveyResponses.id, responseId), eq(schema.surveyResponses.orgId, ctx.org.id))).limit(1);
    if (!r || !r.contactId || !contactIds.includes(r.contactId)) return { error: "Enquête introuvable." };
    if (r.submittedAt) return { error: "Cette enquête a déjà été répondue." };
    const token = randomToken(24);
    await db.update(schema.surveyResponses).set({ tokenHash: sha256(token) }).where(eq(schema.surveyResponses.id, r.id));
    await audit({ action: "survey.open_from_extranet", userId: ctx.user.id, orgId: ctx.org.id, entityType: "survey_response", entityId: r.id });
    target = `/enquete/${token}`;
  } catch (e) {
    return fail(e, "Impossible d'ouvrir l'enquête.");
  }
  redirect(target);
}

/** Dépôt par l'entreprise d'une pièce attendue qu'elle doit fournir (ex. CERFA signé) : statut « déposée », relais résolu, contrôle administratif. */
export async function uploadCompanyPieceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireEmployer();
    const submissionId = uuid.parse(formData.get("submissionId"));
    const rows = await listPieces(ctx.org.id, ctx.enrollmentIds, ["entreprise"]);
    const row = rows.find((r) => r.submission.id === submissionId);
    if (!row) return { error: "Pièce introuvable parmi celles attendues de votre entreprise." };
    if (row.submission.status === "acceptee") return { error: "Cette pièce a déjà été acceptée par l'organisme." };
    if (row.submission.status === "non_applicable") return { error: "Cette pièce n'est pas applicable." };
    const f = formData.get("file");
    if (!(f instanceof File) || !f.size) return { error: "Sélectionnez un fichier à déposer." };
    const data = Buffer.from(await f.arrayBuffer());
    const check = checkUpload({ name: f.name, type: f.type, size: f.size, head: data.subarray(0, 8) });
    if (!check.ok) return { error: check.error };
    const e = ctx.enrollments.find((x) => x.enrollment.id === row.submission.enrollmentId);
    const doc = await createDocument({
      orgId: ctx.org.id,
      enrollmentId: row.submission.enrollmentId,
      personId: e?.person.id ?? null,
      companyId: ctx.company.id,
      category: row.piece.category,
      visibility: "administratif",
      status: "transmis",
      title: row.piece.label,
      fileName: f.name,
      mimeType: check.mime,
      data,
      sourceType: "piece_submission",
      sourceId: row.submission.id,
      uploadedBy: ctx.user.id,
      previousVersionId: row.submission.documentId ?? null,
      isDemo: ctx.org.isDemo,
    });
    const before = { status: row.submission.status, documentId: row.submission.documentId };
    await db
      .update(schema.pieceSubmissions)
      .set({ status: "deposee", documentId: doc.id, submittedAt: new Date(), submittedBy: ctx.user.id, refusalReason: null, version: row.submission.version + (row.submission.documentId ? 1 : 0) })
      .where(and(eq(schema.pieceSubmissions.id, row.submission.id), eq(schema.pieceSubmissions.orgId, ctx.org.id)));
    for (const k of [`piece:${row.submission.enrollmentId}:${row.piece.code}`, `piece:${row.submission.id}:attendue`, `piece:${row.submission.id}:manquante`]) await resolveTaskByKey(ctx.org.id, k, "Pièce déposée par l'entreprise depuis l'extranet.", ctx.user.id);
    const who = e ? `${e.person.firstName} ${e.person.lastName}` : ctx.company.name;
    await createTaskOnce({
      orgId: ctx.org.id,
      title: `Pièce à contrôler : ${row.piece.label} (${who}, déposée par ${ctx.company.name})`,
      description: "Pièce déposée depuis l'extranet entreprise : accepter ou refuser avec motif.",
      family: "administratif",
      entityType: "enrollment",
      entityId: row.submission.enrollmentId,
      entityLabel: who,
      href: `/app/${ctx.org.id}/inscriptions/${row.submission.enrollmentId}`,
      assigneeRole: "admin_staff",
      idempotencyKey: `piece_controle:${row.submission.id}:v${doc.version}`,
      createdBy: ctx.user.id,
      source: "extranet",
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "piece.submit", userId: ctx.user.id, orgId: ctx.org.id, entityType: "piece_submission", entityId: row.submission.id, before, after: { status: "deposee", documentId: doc.id, by: "entreprise" } });
    revalidatePath("/entreprise/documents");
    revalidatePath("/entreprise");
    return { ok: true, message: `« ${row.piece.label} » déposée. L'organisme la contrôle et vous informe en cas de refus.` };
  } catch (e) {
    return fail(e, "Le dépôt de la pièce a échoué.");
  }
}
