import "server-only";
import { and, eq, gte, inArray } from "drizzle-orm";
import Papa from "papaparse";
import { db, schema } from "@/db";

/**
 * Export EDOF (Mon Compte Formation) des sessions publiées : un enregistrement par session avec l'action
 * de formation, la certification (RNCP / RS), les dates, la modalité, le lieu, la capacité et le prix.
 * Format pivot documenté ci-dessous ; l'import dans EDOF se fait par dépôt du fichier côté organisme.
 */
export type EdofRow = {
  code_session: string;
  intitule: string;
  code_programme: string;
  code_rncp: string;
  code_rs: string;
  certificateur: string;
  date_debut: string;
  date_fin: string;
  modalite: string;
  duree_heures: number;
  lieu: string;
  code_postal: string;
  ville: string;
  capacite: number;
  prix_ht_cents: number | null;
  nda: string;
  siret: string;
};

export async function edofRows(orgId: string, fromDate: string): Promise<EdofRow[]> {
  const [org] = await db.select({ nda: schema.organismes.nda, siret: schema.organismes.siret }).from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  const rows = await db
    .select({ s: schema.trainingSessions, v: schema.programVersions, p: schema.programs, c: schema.certifications, site: schema.sites })
    .from(schema.trainingSessions)
    .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
    .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .leftJoin(schema.certifications, eq(schema.certifications.id, schema.programs.certificationId))
    .leftJoin(schema.sites, eq(schema.sites.id, schema.trainingSessions.siteId))
    .where(and(eq(schema.trainingSessions.orgId, orgId), eq(schema.trainingSessions.isPublished, true), inArray(schema.trainingSessions.status, ["ouverte", "confirmee"]), gte(schema.trainingSessions.endDate, fromDate)))
    .orderBy(schema.trainingSessions.startDate);
  return rows.map(({ s, v, p, c, site }) => ({
    code_session: s.code,
    intitule: s.title,
    code_programme: p.code,
    code_rncp: c?.rncpCode ?? "",
    code_rs: c?.rsCode ?? "",
    certificateur: c?.certifier ?? "",
    date_debut: s.startDate,
    date_fin: s.endDate,
    modalite: s.modality,
    duree_heures: v.durationHours,
    lieu: site?.name ?? "",
    code_postal: site?.postalCode ?? "",
    ville: site?.city ?? "",
    capacite: s.capacity,
    prix_ht_cents: s.priceCents ?? v.priceCents ?? null,
    nda: org?.nda ?? "",
    siret: org?.siret ?? "",
  }));
}

const esc = (s: string | number | null) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export function edofXml(rows: EdofRow[]): string {
  const items = rows
    .map(
      (r) => `  <session>
    <codeSession>${esc(r.code_session)}</codeSession>
    <intitule>${esc(r.intitule)}</intitule>
    <codeProgramme>${esc(r.code_programme)}</codeProgramme>
    <certification rncp="${esc(r.code_rncp)}" rs="${esc(r.code_rs)}" certificateur="${esc(r.certificateur)}"/>
    <dateDebut>${esc(r.date_debut)}</dateDebut>
    <dateFin>${esc(r.date_fin)}</dateFin>
    <modalite>${esc(r.modalite)}</modalite>
    <dureeHeures>${r.duree_heures}</dureeHeures>
    <lieu nom="${esc(r.lieu)}" codePostal="${esc(r.code_postal)}" ville="${esc(r.ville)}"/>
    <capacite>${r.capacite}</capacite>
    <prixHT>${r.prix_ht_cents === null ? "" : (r.prix_ht_cents / 100).toFixed(2)}</prixHT>
  </session>`,
    )
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<catalogue xmlns="urn:nextformation:edof:1" nda="${esc(rows[0]?.nda ?? "")}" siret="${esc(rows[0]?.siret ?? "")}" genere="${new Date().toISOString()}">\n${items}\n</catalogue>\n`;
}

export function edofCsv(rows: EdofRow[]): string {
  return `﻿${Papa.unparse(rows.map((r) => ({ ...r, prix_ht: r.prix_ht_cents === null ? "" : (r.prix_ht_cents / 100).toFixed(2), prix_ht_cents: undefined })), { delimiter: ";", escapeFormulae: true })}`;
}
