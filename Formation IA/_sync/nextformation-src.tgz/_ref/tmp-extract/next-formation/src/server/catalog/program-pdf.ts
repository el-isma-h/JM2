import "server-only";
import type { schema } from "@/db";
import { formatCents } from "@/lib/money";
import { clean, INK, MUTED, newPdf, para, section, writeFooter, writeOrgHeader, type Org } from "@/server/crm/pdf-base";

type Program = typeof schema.programs.$inferSelect;
type Version = typeof schema.programVersions.$inferSelect;
type Module = typeof schema.modules.$inferSelect;
type Certification = typeof schema.certifications.$inferSelect;

export const modalityLabels: Record<string, string> = { presentiel: "Présentiel", distanciel: "À distance", mixte: "Mixte (présentiel et distance)", afest: "AFEST", elearning: "E-learning" };

/** Programme de formation (document Qualiopi) : objectifs, prérequis, public, modalités, durée, contenu, méthodes, évaluation, accessibilité, délai d'accès, tarif. */
export async function renderProgramPdf(org: Org, program: Program, version: Version, modules: Module[], certification: Certification | null): Promise<Buffer> {
  const { doc, done } = newPdf(`Programme ${program.code} v${version.version}`);
  writeOrgHeader(doc, org, "Programme de formation");

  doc.font("Helvetica-Bold").fontSize(16).fillColor(INK).text(clean(program.title));
  doc.font("Helvetica").fontSize(9).fillColor(MUTED).text(clean(`Référence ${program.code} · version ${version.version}${version.effectiveFrom ? ` applicable à partir du ${version.effectiveFrom.split("-").reverse().join("/")}` : ""}`));
  if (certification) {
    doc.text(clean(`Certification visée : ${certification.title}${certification.rncpCode ? ` (RNCP ${certification.rncpCode})` : certification.rsCode ? ` (RS ${certification.rsCode})` : ""}${certification.level ? `, niveau ${certification.level}` : ""}`));
  }
  doc.fillColor(INK);

  section(doc, "Objectifs");
  para(doc, version.objectives, "[À COMPLÉTER : objectifs]");
  section(doc, "Public visé");
  para(doc, version.audience, "[À COMPLÉTER : public]");
  section(doc, "Prérequis");
  para(doc, version.prerequisites, "[À COMPLÉTER : prérequis]");
  section(doc, "Durée et modalités");
  const dur = [
    `${version.durationHours} h${version.durationDays ? ` (${version.durationDays} jour${version.durationDays > 1 ? "s" : ""})` : ""}`,
    version.companyHours ? `dont ${version.companyHours} h en entreprise` : null,
    version.remoteHours ? `dont ${version.remoteHours} h à distance` : null,
    modalityLabels[version.modality] ?? version.modality,
  ]
    .filter(Boolean)
    .join(" · ");
  para(doc, dur);
  section(doc, "Contenu");
  para(doc, version.content, "[À COMPLÉTER : contenu]");
  if (modules.length) {
    doc.moveDown(0.3);
    const total = modules.reduce((a, m) => a + m.hours, 0);
    for (const m of modules) {
      doc.font("Helvetica-Bold").fontSize(9.5).fillColor(INK).text(clean(`${m.blockCode ? `${m.blockCode} · ` : ""}${m.code ? `${m.code} ` : ""}${m.title}`), { continued: true });
      doc.font("Helvetica").fontSize(9).fillColor(MUTED).text(clean(`   ${m.hours} h`));
      if (m.description) doc.font("Helvetica").fontSize(9).fillColor(INK).text(clean(m.description), { indent: 12, lineGap: 1.5 });
    }
    doc.font("Helvetica").fontSize(8.5).fillColor(MUTED).text(clean(`Total des modules : ${total} h${total !== version.durationHours ? ` (durée de la version : ${version.durationHours} h)` : ""}`));
    doc.fillColor(INK);
  }
  section(doc, "Méthodes et moyens pédagogiques");
  para(doc, version.methods, "[À COMPLÉTER : méthodes]");
  if (version.resources) {
    section(doc, "Ressources");
    para(doc, version.resources);
  }
  section(doc, "Modalités d'évaluation");
  para(doc, version.evaluationMethods, "[À COMPLÉTER : évaluation]");
  section(doc, "Accessibilité aux personnes en situation de handicap");
  para(doc, version.accessibility, "[À COMPLÉTER : accessibilité]");
  section(doc, "Délai d'accès");
  para(doc, version.accessDelay, "[À COMPLÉTER : délai d'accès]");
  section(doc, "Tarif");
  para(doc, version.priceCents !== null ? `${formatCents(version.priceCents)} HT${version.priceNote ? ` (${version.priceNote})` : ""}` : version.priceNote || "Sur devis");
  if (version.trainerProfile) {
    section(doc, "Profil des intervenants");
    para(doc, version.trainerProfile);
  }
  if (org.qualiopiNumber) {
    doc.moveDown(1);
    doc.font("Helvetica").fontSize(8).fillColor(MUTED).text(clean(`Organisme certifié Qualiopi n° ${org.qualiopiNumber}${org.qualiopiScopes && Array.isArray(org.qualiopiScopes) && org.qualiopiScopes.length ? ` au titre des catégories : ${(org.qualiopiScopes as string[]).join(", ")}` : ""}.`));
  }
  writeFooter(doc, org, `${program.code} v${version.version}`);
  doc.end();
  return done;
}
