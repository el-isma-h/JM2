/**
 * Règles pures des sessions (F03) : rythmes paramétrables et transitions de statut.
 * Aucune dépendance serveur : testable en isolation (vitest).
 */

export type SessionStatus = "brouillon" | "ouverte" | "confirmee" | "en_cours" | "terminee" | "annulee";

export type RhythmPreset = "1_4" | "2_8" | "continu" | "personnalise";

/** Rythme réellement retenu pour une session : jamais codé en dur, toujours paramétrable. */
export type Rhythm = {
  preset: RhythmPreset;
  label: string;
  /** Jours de centre par cycle (ex. 1 jour / 4 jours : centerDays = 1, companyDays = 4). */
  centerDays: number;
  companyDays: number;
  /** Jours de centre dans la semaine (1 = lundi … 5 = vendredi) pour un rythme personnalisé. */
  weekdays: number[];
  morning: { start: string; end: string };
  afternoon: { start: string; end: string };
};

export const RHYTHM_PRESETS: Record<RhythmPreset, { label: string; centerDays: number; companyDays: number; weekdays: number[] }> = {
  "1_4": { label: "1 jour / 4 jours", centerDays: 1, companyDays: 4, weekdays: [1] },
  "2_8": { label: "2 jours / 8 jours", centerDays: 2, companyDays: 8, weekdays: [1, 2] },
  continu: { label: "Continu (temps plein en centre)", centerDays: 5, companyDays: 0, weekdays: [1, 2, 3, 4, 5] },
  personnalise: { label: "Personnalisé", centerDays: 0, companyDays: 0, weekdays: [] },
};

export const WEEKDAY_LABELS: Record<number, string> = { 1: "Lundi", 2: "Mardi", 3: "Mercredi", 4: "Jeudi", 5: "Vendredi", 6: "Samedi", 7: "Dimanche" };

export const DEFAULT_SCHEDULE = { morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } };

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

/** Normalise un rythme depuis une saisie (formulaire) ou une valeur JSON stockée ; valeurs sûres par défaut. */
export function normalizeRhythm(input: Partial<Rhythm> & { preset?: string } = {}, orgSchedule: { morning?: { start: string; end: string }; afternoon?: { start: string; end: string } } = {}): Rhythm {
  const preset: RhythmPreset = (["1_4", "2_8", "continu", "personnalise"] as const).includes(input.preset as RhythmPreset) ? (input.preset as RhythmPreset) : "personnalise";
  const base = RHYTHM_PRESETS[preset];
  const weekdays = preset === "personnalise" ? uniqWeekdays(input.weekdays ?? []) : base.weekdays;
  const centerDays = preset === "personnalise" ? clampInt(input.centerDays, 0, 7, weekdays.length) : base.centerDays;
  const companyDays = preset === "personnalise" ? clampInt(input.companyDays, 0, 31, 0) : base.companyDays;
  const label = preset === "personnalise" ? (input.label?.trim() || customLabel(centerDays, companyDays, weekdays)) : base.label;
  const morning = pickSlot(input.morning, orgSchedule.morning, DEFAULT_SCHEDULE.morning);
  const afternoon = pickSlot(input.afternoon, orgSchedule.afternoon, DEFAULT_SCHEDULE.afternoon);
  return { preset, label, centerDays, companyDays, weekdays, morning, afternoon };
}

function uniqWeekdays(v: unknown): number[] {
  if (!Array.isArray(v)) return [];
  return [...new Set(v.map(Number).filter((n) => Number.isInteger(n) && n >= 1 && n <= 7))].sort((a, b) => a - b);
}

function clampInt(v: unknown, min: number, max: number, fallback: number): number {
  const n = Number(v);
  if (!Number.isInteger(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function pickSlot(v: unknown, org: { start: string; end: string } | undefined, def: { start: string; end: string }) {
  const o = (v ?? {}) as { start?: string; end?: string };
  const start = typeof o.start === "string" && TIME_RE.test(o.start) ? o.start : org?.start ?? def.start;
  const end = typeof o.end === "string" && TIME_RE.test(o.end) ? o.end : org?.end ?? def.end;
  return { start, end };
}

function customLabel(centerDays: number, companyDays: number, weekdays: number[]): string {
  if (centerDays && companyDays) return `${centerDays} jour${centerDays > 1 ? "s" : ""} / ${companyDays} jour${companyDays > 1 ? "s" : ""}`;
  if (weekdays.length) return `Centre : ${weekdays.map((d) => WEEKDAY_LABELS[d]).join(", ")}`;
  return "Rythme personnalisé";
}

/** Libellé lisible d'un rythme stocké (JSON brut) sans jamais inventer une valeur. */
export function rhythmLabel(raw: unknown): string {
  const r = (raw ?? {}) as Partial<Rhythm>;
  if (typeof r.label === "string" && r.label.trim()) return r.label;
  return "Non renseigné";
}

/* ---------- Transitions de statut (brouillon → ouverte → confirmée → en cours → terminée / annulée) ---------- */

export const SESSION_STATUSES: SessionStatus[] = ["brouillon", "ouverte", "confirmee", "en_cours", "terminee", "annulee"];

const ALLOWED: Record<SessionStatus, SessionStatus[]> = {
  brouillon: ["ouverte", "annulee"],
  ouverte: ["confirmee", "brouillon", "annulee"],
  confirmee: ["en_cours", "ouverte", "annulee"],
  en_cours: ["terminee", "annulee"],
  terminee: [],
  annulee: ["brouillon"],
};

export type SessionLike = { status: SessionStatus; startDate: string; endDate: string; minCapacity: number; capacity: number; programVersionId?: string | null };

export type SessionCounts = {
  /** Inscriptions actives (préinscrit, inscrit, en cours). */
  enrolled: number;
  /** Inscriptions confirmées (inscrit, en cours) comptant pour le minimum. */
  confirmed: number;
  /** Date du jour (Europe/Paris, ISO) fournie par le serveur. */
  today: string;
};

export type TransitionResult = { ok: true } | { ok: false; reason: string };

/**
 * Vérifie une transition de statut de session et explique précisément ce qui bloque.
 * - confirmée : exige au moins `minCapacity` inscriptions confirmées (inscrit / en cours) ;
 * - en cours : exige une session confirmée et une date de début atteinte ;
 * - terminée : exige une date de fin passée ;
 * - annulée : toujours possible sauf si terminée ;
 * Clôturer une session ne solde jamais les financements des inscriptions (F03).
 */
export function canTransitionSession(session: SessionLike, to: SessionStatus, counts: SessionCounts): TransitionResult {
  if (session.status === to) return { ok: false, reason: `La session est déjà au statut « ${to} ».` };
  if (!ALLOWED[session.status]?.includes(to)) return { ok: false, reason: `Passage de « ${session.status} » à « ${to} » non autorisé.` };
  if (to === "ouverte" && session.endDate < session.startDate) return { ok: false, reason: "La date de fin précède la date de début." };
  if (to === "confirmee" && counts.confirmed < session.minCapacity) {
    return { ok: false, reason: `Confirmation impossible : ${counts.confirmed} inscription(s) confirmée(s) pour un minimum de ${session.minCapacity}.` };
  }
  if (to === "en_cours" && counts.today < session.startDate) {
    return { ok: false, reason: `La session ne commence que le ${frDate(session.startDate)} : elle ne peut pas être « en cours » avant.` };
  }
  if (to === "terminee" && counts.today <= session.endDate) {
    return { ok: false, reason: `La date de fin (${frDate(session.endDate)}) n'est pas passée : la session ne peut pas être terminée.` };
  }
  return { ok: true };
}

/** Transitions atteignables depuis un statut (pour afficher uniquement les boutons pertinents). */
export function nextSessionStatuses(status: SessionStatus): SessionStatus[] {
  return ALLOWED[status] ?? [];
}

function frDate(iso: string): string {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export const sessionStatusLabels: Record<SessionStatus, string> = {
  brouillon: "Brouillon",
  ouverte: "Ouverte",
  confirmee: "Confirmée",
  en_cours: "En cours",
  terminee: "Terminée",
  annulee: "Annulée",
};

export const sessionKindLabels: Record<string, string> = { inter: "Inter-entreprises", intra: "Intra-entreprise", cycle: "Cycle", individuel: "Individuel" };
export const modalityLabels: Record<string, string> = { presentiel: "Présentiel", distanciel: "Distanciel", mixte: "Mixte", afest: "AFEST", elearning: "E-learning" };
