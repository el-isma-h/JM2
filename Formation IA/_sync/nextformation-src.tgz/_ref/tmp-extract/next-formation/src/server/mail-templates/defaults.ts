/**
 * Modèles d'e-mails par défaut proposés à chaque organisme (module pur, sans dépendance serveur).
 *
 * Syntaxe de `renderTemplate` (src/server/documents/render.ts) : {{chemin}}, {{#if chemin}} … {{else}} … {{/if}}.
 * Une variable absente au rendu devient « [À COMPLÉTER : libellé] », jamais une valeur inventée. Les marqueurs
 * écrits en dur « [À COMPLÉTER : …] » signalent un texte propre à l'organisme qu'il doit rédiger avant usage.
 * Le corps est du texte brut (paragraphes séparés par une ligne vide), converti en HTML par `mailTextToHtml`.
 */

export type MailTemplateDefault = {
  code: string;
  title: string;
  /** Usage, affiché dans l'écran des modèles et transmis à l'IA. */
  purpose: string;
  recipient: "apprenant" | "formateur" | "entreprise";
  subject: string;
  body: string;
  /** Variables utilisables dans ce modèle (sous-ensemble de MAIL_TEMPLATE_VARIABLES). */
  variables: string[];
};

/** Libellés des variables (affichés dans l'aide et dans les marqueurs « [À COMPLÉTER : …] »). */
export const MAIL_TEMPLATE_VARIABLES: Record<string, string> = {
  "org.name": "Nom de l'organisme",
  "org.legalName": "Raison sociale de l'organisme",
  "org.email": "E-mail de l'organisme",
  "org.phone": "Téléphone de l'organisme",
  "org.website": "Site web de l'organisme",
  "org.address": "Adresse de l'organisme",
  "org.nda": "Numéro de déclaration d'activité",
  "org.googleReviewUrl": "Lien pour laisser un avis Google",
  "signer.fullName": "Nom de la personne qui signe l'e-mail",
  "signer.title": "Fonction de la personne qui signe l'e-mail",
  "person.civility": "Civilité du destinataire",
  "person.firstName": "Prénom du destinataire",
  "person.lastName": "Nom du destinataire",
  "enrollment.reference": "Référence de l'inscription",
  "enrollment.plannedHours": "Durée prévue (heures)",
  "enrollment.price": "Prix de la formation",
  "session.title": "Intitulé de la session",
  "session.startDate": "Date de début de la session",
  "session.endDate": "Date de fin de la session",
  "session.schedule": "Horaires de la session",
  "session.location": "Lieu de la formation",
  "session.modality": "Modalité (présentiel, distanciel…)",
  "program.title": "Intitulé de la formation",
  "funding.label": "Financement retenu",
  "funding.isCpf": "Financement CPF (oui / non)",
  "extranet.url": "Lien vers l'espace en ligne",
  "pieces.list": "Liste des pièces attendues",
  "pieces.dueDate": "Date limite de dépôt des pièces",
  "trainer.firstName": "Prénom du formateur",
  "mission.dates": "Dates de la mission",
  "mission.hours": "Volume horaire de la mission",
  "mission.location": "Lieu de la mission",
  "mission.rate": "Rémunération proposée",
  "mission.replyBefore": "Date limite de réponse",
  "elearning.platform": "Nom de la plateforme e-learning",
  "elearning.url": "Lien de connexion e-learning",
  "elearning.login": "Identifiant de connexion",
  "elearning.passwordInstructions": "Modalité de transmission du mot de passe",
  "elearning.expiresAt": "Date de fin d'accès",
  "elearning.durationHours": "Durée estimée du parcours (heures)",
  "elearning.lastLogin": "Dernière connexion",
  "elearning.progress": "Progression",
  "survey.url": "Lien du questionnaire de fin de formation",
};

const SIGNATURE = `Bien cordialement,

{{signer.fullName}}
{{signer.title}}
{{org.name}}
{{org.phone}} · {{org.email}}`;

export const MAIL_TEMPLATE_DEFAULTS: MailTemplateDefault[] = [
  {
    code: "inscription_recapitulatif",
    title: "Récapitulatif d'inscription",
    purpose: "Confirmer à l'apprenant son inscription : formation, dates, horaires, lieu, financement, pièces attendues et accès à l'espace en ligne.",
    recipient: "apprenant",
    subject: "Votre inscription : {{program.title}} du {{session.startDate}}",
    variables: ["person.civility", "person.firstName", "person.lastName", "enrollment.reference", "enrollment.plannedHours", "enrollment.price", "program.title", "session.title", "session.startDate", "session.endDate", "session.schedule", "session.location", "session.modality", "funding.label", "pieces.list", "pieces.dueDate", "extranet.url", "org.name", "org.phone", "org.email", "signer.fullName", "signer.title"],
    body: `Bonjour {{person.firstName}},

Nous vous confirmons votre inscription à la formation « {{program.title}} » (référence {{enrollment.reference}}).

Dates : du {{session.startDate}} au {{session.endDate}}
Horaires : {{session.schedule}}
Durée prévue : {{enrollment.plannedHours}} heures
Modalité : {{session.modality}}
Lieu : {{session.location}}
Financement : {{funding.label}}

{{#if pieces.list}}Pour finaliser votre dossier, merci de nous transmettre avant le {{pieces.dueDate}} :
{{pieces.list}}

{{/if}}Votre espace en ligne vous permet de retrouver votre convocation, vos documents et de déposer vos pièces : {{extranet.url}}

[À COMPLÉTER : informations pratiques (accès, stationnement, restauration) et contact du référent handicap]

${SIGNATURE}`,
  },
  {
    code: "mission_formateur",
    title: "Proposition de mission formateur",
    purpose: "Proposer une mission d'animation à un formateur (dates, volume, lieu, rémunération) et lui demander une réponse avant une date.",
    recipient: "formateur",
    subject: "Proposition de mission : {{session.title}} ({{mission.dates}})",
    variables: ["trainer.firstName", "session.title", "program.title", "mission.dates", "mission.hours", "mission.location", "mission.rate", "mission.replyBefore", "session.modality", "org.name", "org.phone", "org.email", "signer.fullName", "signer.title"],
    body: `Bonjour {{trainer.firstName}},

Nous souhaiterions vous confier l'animation de la session « {{session.title}} » (formation « {{program.title}} »).

Dates : {{mission.dates}}
Volume : {{mission.hours}} heures
Modalité : {{session.modality}}
Lieu : {{mission.location}}
Rémunération proposée : {{mission.rate}}

[À COMPLÉTER : public attendu, nombre de participants et attendus pédagogiques]

[À COMPLÉTER : conditions de facturation et documents à fournir (contrat de prestation, attestation URSSAF, CV à jour)]

Pouvez-vous nous indiquer votre disponibilité avant le {{mission.replyBefore}} ? Cette proposition ne vaut pas affectation tant qu'elle n'est pas confirmée par écrit des deux côtés.

${SIGNATURE}`,
  },
  {
    code: "elearning_acces",
    title: "Envoi des accès e-learning",
    purpose: "Transmettre à l'apprenant ses accès à la plateforme e-learning, la durée estimée et la date de fin d'accès.",
    recipient: "apprenant",
    subject: "Vos accès à la formation en ligne : {{program.title}}",
    variables: ["person.firstName", "program.title", "elearning.platform", "elearning.url", "elearning.login", "elearning.passwordInstructions", "elearning.expiresAt", "elearning.durationHours", "org.name", "org.phone", "org.email", "signer.fullName", "signer.title"],
    body: `Bonjour {{person.firstName}},

Votre parcours en ligne « {{program.title}} » est ouvert sur {{elearning.platform}}.

Lien de connexion : {{elearning.url}}
Identifiant : {{elearning.login}}
Mot de passe : {{elearning.passwordInstructions}}

Durée estimée du parcours : {{elearning.durationHours}} heures
Accès ouvert jusqu'au : {{elearning.expiresAt}}

Votre temps de connexion et votre progression sont enregistrés : ils servent à attester de votre suivi de la formation.

[À COMPLÉTER : contact et horaires de l'assistance technique et pédagogique]

${SIGNATURE}`,
  },
  {
    code: "elearning_relance",
    title: "Relance accès e-learning non utilisé",
    purpose: "Relancer un apprenant qui ne s'est pas connecté (ou peu) à son parcours e-learning, en rappelant le lien et la date de fin d'accès.",
    recipient: "apprenant",
    subject: "Votre formation en ligne vous attend : {{program.title}}",
    variables: ["person.firstName", "program.title", "elearning.platform", "elearning.url", "elearning.lastLogin", "elearning.progress", "elearning.expiresAt", "org.name", "org.phone", "org.email", "signer.fullName", "signer.title"],
    body: `Bonjour {{person.firstName}},

Votre parcours « {{program.title}} » sur {{elearning.platform}} est toujours ouvert.

Dernière connexion : {{elearning.lastLogin}}
Progression : {{elearning.progress}}
Fin de l'accès : {{elearning.expiresAt}}

Pour reprendre là où vous en étiez : {{elearning.url}}

Si vous rencontrez une difficulté (connexion, organisation, contenu), répondez simplement à ce message : nous vous recontactons.

${SIGNATURE}`,
  },
  {
    code: "evaluation_fin_formation",
    title: "Évaluation de fin de formation",
    purpose: "Demander à l'apprenant de répondre au questionnaire de fin de formation, l'inviter à laisser un avis Google et, en cas de financement CPF, lui rappeler l'évaluation sur Mon Compte Formation.",
    recipient: "apprenant",
    subject: "Votre avis sur la formation {{program.title}}",
    variables: ["person.firstName", "program.title", "session.endDate", "survey.url", "org.googleReviewUrl", "funding.isCpf", "org.name", "org.phone", "org.email", "signer.fullName", "signer.title"],
    body: `Bonjour {{person.firstName}},

Votre formation « {{program.title}} » s'est terminée le {{session.endDate}}. Merci pour votre participation.

Votre avis nous aide à améliorer nos formations. Le questionnaire prend quelques minutes : {{survey.url}}

{{#if funding.isCpf}}Votre formation étant financée par votre compte personnel de formation, Mon Compte Formation vous proposera également de l'évaluer depuis votre espace sur moncompteformation.gouv.fr. Merci d'y répondre : elle aide les futurs stagiaires à choisir leur formation.

{{/if}}Si vous avez apprécié la formation, vous pouvez aussi laisser un avis sur Google : {{org.googleReviewUrl}}

${SIGNATURE}`,
  },
  {
    code: "pieces_relance",
    title: "Relance de pièces",
    purpose: "Relancer l'apprenant (ou l'entreprise) pour les pièces du dossier encore attendues ou refusées, avec la date limite et le lien de dépôt.",
    recipient: "apprenant",
    subject: "Pièces à fournir pour votre inscription : {{program.title}}",
    variables: ["person.firstName", "program.title", "session.startDate", "pieces.list", "pieces.dueDate", "extranet.url", "org.name", "org.phone", "org.email", "signer.fullName", "signer.title"],
    body: `Bonjour {{person.firstName}},

Pour finaliser votre dossier d'inscription à la formation « {{program.title}} » (début le {{session.startDate}}), il nous manque encore :
{{pieces.list}}

Merci de nous les transmettre avant le {{pieces.dueDate}}, depuis votre espace en ligne : {{extranet.url}}

Sans ces pièces, [À COMPLÉTER : conséquence pour le dossier (report, financement non engagé…)].

${SIGNATURE}`,
  },
];

export function mailTemplateDefault(code: string): MailTemplateDefault | null {
  return MAIL_TEMPLATE_DEFAULTS.find((t) => t.code === code) ?? null;
}

/** Variables utilisées dans un texte ({{x}} et {{#if x}}). */
export function usedVariables(text: string): string[] {
  const out = new Set<string>();
  for (const m of text.matchAll(/\{\{\s*(?:#if\s+|#unless\s+)?([a-zA-Z][\w.]*)/g)) out.add(m[1]);
  return [...out];
}

function esc(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/** Texte brut rendu → HTML simple (paragraphes, retours à la ligne, liens cliquables). */
export function mailTextToHtml(text: string): string {
  return text
    .split(/\n{2,}/)
    .map((p) => `<p>${esc(p).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1">$1</a>').replace(/\n/g, "<br>")}</p>`)
    .join("");
}
