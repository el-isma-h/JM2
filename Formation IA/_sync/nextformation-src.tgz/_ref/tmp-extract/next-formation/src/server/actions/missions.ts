"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireOrg, type OrgContext } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { getTrainerContext } from "@/server/extranet/context";
import { fail, isoDate, str, uuid } from "@/server/crm/helpers";
import { eurosToCents } from "@/server/missions/rules";
import { closeMission, generateMissionContract, loadMission, proposeMission, replaceMission, respondMission, sendMissionContract, setMissionFirstLesson, type MissionActor } from "@/server/missions/service";
import type { ActionState } from "./auth";

/** Actions des missions formateurs : proposition, réponse, remplacement, contrat de prestation, clôture. */

function revalidate(orgId: string, trainerIds: (string | null | undefined)[] = []) {
  revalidatePath(`/app/${orgId}/formateurs/missions`);
  for (const t of trainerIds) if (t) revalidatePath(`/app/${orgId}/formateurs/${t}`);
  revalidatePath("/formateur");
  revalidatePath("/formateur/missions");
}

function actorOf(ctx: OrgContext): MissionActor {
  return { org: ctx.org, userId: ctx.user.id };
}

function mailMessage(status: string, who: string): string {
  switch (status) {
    case "sent":
      return `E-mail envoyé à ${who}.`;
    case "no_email":
      return `${who} n'a pas d'adresse e-mail : transmettez-lui la proposition directement.`;
    case "skipped_not_configured":
      return "E-mail non envoyé : envoi d'e-mails non configuré ou organisme de démonstration (voir Intégrations).";
    case "failed":
      return "L'envoi de l'e-mail a échoué : vérifiez l'adresse puis renvoyez la proposition.";
    default:
      return "";
  }
}

function hoursOf(formData: FormData, key = "hours"): number {
  const raw = str(formData, key, 10);
  if (!raw) throw new Error("Nombre d'heures requis.");
  const n = Number(raw.replace(",", "."));
  if (!Number.isInteger(n) || n <= 0 || n > 2000) throw new Error("Nombre d'heures invalide (nombre entier d'heures, ex. 21).");
  return n;
}

function rateOf(formData: FormData, key = "hourlyRateEuros"): number {
  const cents = eurosToCents(str(formData, key, 20));
  if (cents === null) throw new Error("Taux horaire requis : saisissez le taux convenu avec le formateur (fiche formateur, informations complémentaires).");
  if (cents <= 0) throw new Error("Le taux horaire doit être positif.");
  return cents;
}

/* ------------------------------------------------------------------ */
/* Organisme                                                           */
/* ------------------------------------------------------------------ */

export async function proposeMissionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "planning.manage");
    const trainerId = uuid.parse(formData.get("trainerId"));
    if (ctx.trainerOnly || (ctx.trainerId && ctx.trainerId === trainerId)) throw new AuthError("forbidden");
    const target = str(formData, "target", 80);
    let sessionId: string | null = null;
    let enrollmentId: string | null = null;
    if (target?.startsWith("s:")) sessionId = uuid.parse(target.slice(2));
    else if (target?.startsWith("e:")) enrollmentId = uuid.parse(target.slice(2));
    const theme = z.string().trim().min(2, "Thème requis").max(200).parse(formData.get("theme"));
    const r = await proposeMission(actorOf(ctx), {
      trainerId,
      sessionId,
      enrollmentId,
      theme,
      startDate: isoDate(formData, "startDate"),
      endDate: isoDate(formData, "endDate"),
      hours: hoursOf(formData),
      hourlyRateCents: rateOf(formData),
      location: str(formData, "location", 200),
      notes: str(formData, "notes", 2000),
    });
    revalidate(ctx.org.id, [trainerId]);
    return { ok: true, message: `Mission proposée à ${r.trainer.firstName} ${r.trainer.lastName}. ${mailMessage(r.mail.status, `${r.trainer.firstName} ${r.trainer.lastName}`)}`.trim() };
  } catch (e) {
    return fail(e, "Proposition impossible.");
  }
}

/** Réponse saisie par l'organisme (réponse reçue par téléphone ou e-mail), ou par un formateur seul sur SA mission. */
export async function respondMissionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "planning.view");
    const missionId = uuid.parse(formData.get("missionId"));
    const m = await loadMission(ctx.org.id, missionId);
    const own = Boolean(ctx.trainerId && ctx.trainerId === m.trainerId);
    if (!ctx.permissions.has("planning.manage") && !own) throw new AuthError("forbidden");
    if (ctx.trainerOnly && !own) throw new AuthError("forbidden");
    const decision = z.enum(["acceptee", "refusee"], { message: "Choisissez acceptée ou refusée." }).parse(formData.get("decision"));
    const r = await respondMission(actorOf(ctx), { missionId, decision, firstLessonDate: isoDate(formData, "firstLessonDate"), note: str(formData, "note", 1000), asTrainerId: ctx.trainerOnly ? ctx.trainerId : null });
    revalidate(ctx.org.id, [r.trainerId]);
    return { ok: true, message: decision === "acceptee" ? "Mission acceptée. Tâche créée : envoyer le contrat de prestation." : "Mission refusée. Tâche créée : trouver un remplaçant." };
  } catch (e) {
    return fail(e, "Enregistrement de la réponse impossible.");
  }
}

export async function setMissionFirstLessonAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "planning.view");
    const missionId = uuid.parse(formData.get("missionId"));
    const m = await loadMission(ctx.org.id, missionId);
    const own = Boolean(ctx.trainerId && ctx.trainerId === m.trainerId);
    if ((!ctx.permissions.has("planning.manage") && !own) || (ctx.trainerOnly && !own)) throw new AuthError("forbidden");
    const date = isoDate(formData, "firstLessonDate");
    if (!date) throw new Error("Date du premier cours requise.");
    await setMissionFirstLesson(actorOf(ctx), { missionId, firstLessonDate: date, asTrainerId: ctx.trainerOnly ? ctx.trainerId : null });
    revalidate(ctx.org.id, [m.trainerId]);
    return { ok: true, message: "Date du premier cours enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function replaceMissionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "planning.manage");
    const missionId = uuid.parse(formData.get("missionId"));
    const newTrainerId = uuid.parse(formData.get("newTrainerId"));
    if (ctx.trainerOnly || (ctx.trainerId && ctx.trainerId === newTrainerId)) throw new AuthError("forbidden");
    const reason = z.enum(["refusee", "sans_reponse"], { message: "Motif requis." }).parse(formData.get("reason") || "sans_reponse");
    const hoursRaw = str(formData, "hours", 10);
    const r = await replaceMission(actorOf(ctx), {
      missionId,
      newTrainerId,
      reason,
      hourlyRateCents: rateOf(formData),
      hours: hoursRaw ? hoursOf(formData) : null,
      startDate: isoDate(formData, "startDate"),
      endDate: isoDate(formData, "endDate"),
    });
    const who = `${r.trainer.firstName} ${r.trainer.lastName}`;
    const informed = r.informed.status === "sent" ? " Le premier formateur a été informé." : r.informed.status === "no_email" ? " Le premier formateur n'a pas d'e-mail : informez-le directement." : "";
    revalidate(ctx.org.id, [r.mission.trainerId]);
    return { ok: true, message: `Nouvelle mission proposée à ${who}. ${mailMessage(r.mail.status, who)}${informed}`.trim() };
  } catch (e) {
    return fail(e, "Remplacement impossible.");
  }
}

export async function generateMissionContractAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "planning.manage", "documents.generate");
    const missionId = uuid.parse(formData.get("missionId"));
    const r = await generateMissionContract(actorOf(ctx), missionId);
    const m = await loadMission(ctx.org.id, missionId);
    revalidate(ctx.org.id, [m.trainerId]);
    return {
      ok: true,
      message: r.missing.length
        ? `Contrat généré (version ${r.document.version}) avec ${r.missing.length} champ(s) à compléter : ${r.missing.join(", ")}. Complétez les fiches (organisme, formateur, mission) puis régénérez-le avant envoi.`
        : `Contrat généré (version ${r.document.version}). Vérifiez dates, durée et rémunération avant de l'envoyer.`,
    };
  } catch (e) {
    return fail(e, "Génération du contrat impossible.");
  }
}

export async function sendMissionContractAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "planning.manage");
    const missionId = uuid.parse(formData.get("missionId"));
    if (formData.get("hasMissing") === "1" && formData.get("checkedMissing") !== "on") throw new Error("Confirmez que les champs « à compléter » du contrat ont été vérifiés avec le formateur.");
    const r = await sendMissionContract(actorOf(ctx), missionId);
    const m = await loadMission(ctx.org.id, missionId);
    revalidate(ctx.org.id, [m.trainerId]);
    const mail = r.mail === "sent" ? "E-mail envoyé au formateur." : "E-mail non envoyé : envoi non configuré ou démonstration.";
    const missing = r.missing ? ` ${r.missing} champ(s) restent à compléter avant signature.` : "";
    return { ok: true, message: `Contrat marqué transmis. ${mail}${r.hasAccount ? " Il est disponible dans son espace formateur." : " Le formateur n'a pas d'espace formateur : remettez-lui le PDF."}${missing}` };
  } catch (e) {
    return fail(e, "Envoi du contrat impossible.");
  }
}

export async function closeMissionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "planning.manage");
    const missionId = uuid.parse(formData.get("missionId"));
    const status = z.enum(["annulee", "terminee"]).parse(formData.get("status"));
    const m = await closeMission(actorOf(ctx), { missionId, status, reason: str(formData, "reason", 500) });
    revalidate(ctx.org.id, [m.trainerId]);
    return { ok: true, message: status === "annulee" ? "Mission annulée." : "Mission marquée terminée." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

/* ------------------------------------------------------------------ */
/* Espace formateur (extranet)                                         */
/* ------------------------------------------------------------------ */

async function requireTrainerExtranet() {
  const ctx = await getTrainerContext();
  if (!ctx) throw new Error("Aucune fiche formateur rattachée à votre compte.");
  return ctx;
}

/** Le formateur connecté accepte ou refuse SA mission (jamais celle d'un autre). */
export async function trainerRespondMissionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireTrainerExtranet();
    const missionId = uuid.parse(formData.get("missionId"));
    const decision = z.enum(["acceptee", "refusee"], { message: "Réponse invalide." }).parse(formData.get("decision"));
    await respondMission({ org: ctx.org, userId: ctx.user.id }, { missionId, decision, firstLessonDate: isoDate(formData, "firstLessonDate"), note: str(formData, "note", 1000), asTrainerId: ctx.trainer.id });
    revalidate(ctx.org.id, [ctx.trainer.id]);
    return { ok: true, message: decision === "acceptee" ? "Merci, mission acceptée. L'organisme vous transmettra le contrat de prestation." : "Votre refus a été transmis à l'organisme." };
  } catch (e) {
    return fail(e, "Réponse impossible.");
  }
}

export async function trainerSetFirstLessonAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireTrainerExtranet();
    const missionId = uuid.parse(formData.get("missionId"));
    const date = isoDate(formData, "firstLessonDate");
    if (!date) throw new Error("Date du premier cours requise.");
    await setMissionFirstLesson({ org: ctx.org, userId: ctx.user.id }, { missionId, firstLessonDate: date, asTrainerId: ctx.trainer.id });
    revalidate(ctx.org.id, [ctx.trainer.id]);
    return { ok: true, message: "Date du premier cours transmise à l'organisme." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}
