/**
 * Statuts Chorus Pro affichés dans l'interface (module pur, importable côté client).
 * - Codes de flux (`etatCourantFlux` de consulterCR) : préfixe IN_.
 * - Codes de facture (`statutFacture` / `statut` des consultations fournisseur).
 * - `echec_depot` : statut local quand l'appel de dépôt a échoué (rien n'a été reçu par Chorus Pro).
 * Un code inconnu est affiché tel quel, jamais réinterprété.
 */
export type ChorusTone = "neutral" | "info" | "ok" | "warn" | "danger";

export const CHORUS_STATUS: Record<string, { label: string; tone: ChorusTone; final?: boolean; redeposit?: boolean }> = {
  echec_depot: { label: "Échec du dépôt (non reçu)", tone: "danger", final: true, redeposit: true },
  // Flux
  IN_RECU: { label: "Flux reçu", tone: "info" },
  IN_TRAITE_SE_CPP: { label: "Flux transmis à Chorus Pro", tone: "info" },
  IN_EN_ATTENTE_TRAITEMENT_CPP: { label: "Flux en attente de traitement", tone: "info" },
  IN_EN_COURS_TRAITEMENT_CPP: { label: "Flux en cours de traitement", tone: "info" },
  IN_EN_ATTENTE_RETRAITEMENT_CPP: { label: "Flux bloqué (intervention Chorus)", tone: "warn" },
  IN_INCIDENTE: { label: "Flux en incident : à redéposer", tone: "danger", final: true, redeposit: true },
  IN_REJETE: { label: "Flux rejeté", tone: "danger", final: true, redeposit: true },
  IN_INTEGRE: { label: "Flux intégré", tone: "ok" },
  IN_INTEGRE_PARTIEL: { label: "Flux intégré partiellement", tone: "warn" },
  // Facture
  DEPOSEE: { label: "Déposée", tone: "info" },
  EN_COURS_ACHEMINEMENT: { label: "En cours d'acheminement", tone: "info" },
  MISE_A_DISPOSITION: { label: "Mise à disposition de l'acheteur", tone: "info" },
  A_RECYCLER: { label: "À recycler (destinataire à corriger)", tone: "warn" },
  SUSPENDUE: { label: "Suspendue (pièce à compléter)", tone: "warn" },
  COMPLETEE: { label: "Complétée", tone: "info" },
  SERVICE_FAIT: { label: "Service fait", tone: "ok" },
  MANDATEE: { label: "Mandatée", tone: "ok" },
  MISE_A_DISPOSITION_COMPTABLE: { label: "Mise à disposition du comptable", tone: "ok" },
  COMPTABILISEE: { label: "Comptabilisée", tone: "ok" },
  MISE_EN_PAIEMENT: { label: "Mise en paiement", tone: "ok", final: true },
  REJETEE: { label: "Rejetée par l'acheteur", tone: "danger", final: true, redeposit: true },
};

export function chorusStatusMeta(code: string | null | undefined) {
  if (!code) return { label: "Non déposée", tone: "neutral" as ChorusTone, final: false, redeposit: true };
  const m = CHORUS_STATUS[code];
  return m ? { final: false, redeposit: false, ...m } : { label: code, tone: "neutral" as ChorusTone, final: false, redeposit: false };
}

export const CHORUS_FINAL_STATUSES = Object.entries(CHORUS_STATUS)
  .filter(([, v]) => v.final)
  .map(([k]) => k);
