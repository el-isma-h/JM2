import { describe, expect, it } from "vitest";
import { listMarkers, renderTemplate } from "../../documents/render";
import { MAIL_TEMPLATE_DEFAULTS, MAIL_TEMPLATE_VARIABLES, mailTextToHtml, usedVariables } from "../defaults";

describe("modèles d'e-mails par défaut", () => {
  it("n'utilisent que les variables déclarées, toutes libellées", () => {
    for (const t of MAIL_TEMPLATE_DEFAULTS) {
      for (const v of usedVariables(`${t.subject}\n${t.body}`)) expect(t.variables, `${t.code} : ${v}`).toContain(v);
      for (const v of t.variables) expect(MAIL_TEMPLATE_VARIABLES[v], v).toBeTruthy();
    }
  });
  it("sans données : marqueurs « À COMPLÉTER », jamais de valeur inventée ni de balise restante", () => {
    for (const t of MAIL_TEMPLATE_DEFAULTS) {
      const r = renderTemplate(t.body, {}, { labels: MAIL_TEMPLATE_VARIABLES });
      expect(r.text).not.toMatch(/\{\{/);
      expect(listMarkers(r.text).length).toBeGreaterThan(0);
      expect(r.text).not.toMatch(/[—–]/);
    }
  });
  it("évaluation : paragraphe CPF seulement si financement CPF, lien Google en variable", () => {
    const t = MAIL_TEMPLATE_DEFAULTS.find((x) => x.code === "evaluation_fin_formation")!;
    const cpf = renderTemplate(t.body, { funding: { isCpf: true }, org: { googleReviewUrl: "https://g.page/r/abc/review" } }, { labels: MAIL_TEMPLATE_VARIABLES });
    const other = renderTemplate(t.body, { funding: { isCpf: false } }, { labels: MAIL_TEMPLATE_VARIABLES });
    expect(cpf.text).toMatch(/Mon Compte Formation/);
    expect(cpf.text).toContain("https://g.page/r/abc/review");
    expect(other.text).not.toMatch(/Mon Compte Formation/);
    expect(other.text).toMatch(/\[À COMPLÉTER : Lien pour laisser un avis Google\]/);
  });
  it("conversion HTML échappée", () => {
    expect(mailTextToHtml("a <b>\nhttps://x.fr/y\n\nc")).toBe('<p>a &lt;b&gt;<br><a href="https://x.fr/y">https://x.fr/y</a></p><p>c</p>');
  });
});
