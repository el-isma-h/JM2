import "server-only";
import { and, asc, desc, eq, inArray, lt, ne, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { todayParis } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { INK, MUTED, clean, newPdf, para, section, writeFooter, writeOrgHeader, type Org } from "@/server/crm/pdf-base";
import { statusMeta } from "@/components/ui/badge";
import { EVALUATION_KIND_LABELS, FOLLOWUP_KIND_LABELS, PROGRESSION_LABELS, RECORD_KIND_LABELS } from "./labels";

/* ---------- Suivi en entreprise (F07) ---------- */

/** Suivis en entreprise visibles par un employeur / tuteur : inscriptions rattachées à son entreprise, hors incidents internes. Utilisé par l'extranet (équipe G). */
export async function listFollowupsForCompany(orgId: string, companyId: string) {
  return db
    .select({ followup: schema.companyFollowups, enrollment: { id: schema.enrollments.id, reference: schema.enrollments.reference }, person: { firstName: schema.persons.firstName, lastName: schema.persons.lastName } })
    .from(schema.companyFollowups)
    .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.companyFollowups.enrollmentId))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.companyFollowups.orgId, orgId), eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.companyId, companyId), ne(schema.companyFollowups.kind, "incident")))
    .orderBy(desc(schema.companyFollowups.date));
}

/** Entrées de livret visibles par l'entreprise (`visibleToCompany`) pour ses inscriptions. */
export async function listRecordEntriesForCompany(orgId: string, companyId: string) {
  return db
    .select({ entry: schema.recordEntries, enrollment: { id: schema.enrollments.id, reference: schema.enrollments.reference }, person: { firstName: schema.persons.firstName, lastName: schema.persons.lastName } })
    .from(schema.recordEntries)
    .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.recordEntries.enrollmentId))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.recordEntries.orgId, orgId), eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.companyId, companyId), eq(schema.recordEntries.visibleToCompany, true)))
    .orderBy(desc(schema.recordEntries.date));
}

/** Entrées de livret visibles par l'apprenant (`visibleToLearner`). Utilisé par l'extranet apprenant. */
export async function listRecordEntriesForLearner(orgId: string, enrollmentId: string) {
  return db
    .select()
    .from(schema.recordEntries)
    .where(and(eq(schema.recordEntries.orgId, orgId), eq(schema.recordEntries.enrollmentId, enrollmentId), eq(schema.recordEntries.visibleToLearner, true)))
    .orderBy(desc(schema.recordEntries.date));
}

/**
 * Rappels de suivi : pour chaque inscription dont le dernier suivi fixe une prochaine date dépassée,
 * une tâche unique (clé `followup:<enrollmentId>:<date>`) pour le responsable pédagogique. Idempotent, rejouable.
 */
export async function createOverdueFollowupTasks(orgId: string, isDemo = false) {
  const today = todayParis();
  const last = db
    .select({ enrollmentId: schema.companyFollowups.enrollmentId, maxDate: sql<string>`max(${schema.companyFollowups.date})`.as("max_date") })
    .from(schema.companyFollowups)
    .where(eq(schema.companyFollowups.orgId, orgId))
    .groupBy(schema.companyFollowups.enrollmentId)
    .as("last");
  const rows = await db
    .select({ f: schema.companyFollowups, reference: schema.enrollments.reference, sessionId: schema.enrollments.sessionId, pedagogyManagerUserId: schema.trainingSessions.pedagogyManagerUserId, firstName: schema.persons.firstName, lastName: schema.persons.lastName })
    .from(schema.companyFollowups)
    .innerJoin(last, and(eq(last.enrollmentId, schema.companyFollowups.enrollmentId), eq(last.maxDate, schema.companyFollowups.date)))
    .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.companyFollowups.enrollmentId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.companyFollowups.orgId, orgId), lt(schema.companyFollowups.nextDate, today), inArray(schema.enrollments.status, ["inscrit", "en_cours"])));
  let created = 0;
  for (const r of rows) {
    const key = `followup:${r.f.enrollmentId}:${r.f.nextDate}`;
    const res = await createTaskOnce({
      orgId,
      title: `Suivi en entreprise en retard : ${r.firstName} ${r.lastName}`,
      description: `Le suivi prévu le ${fmtDate(r.f.nextDate)} n'a pas été enregistré (dernier suivi : ${fmtDate(r.f.date)}).`,
      family: "pedagogie",
      entityType: "enrollment",
      entityId: r.f.enrollmentId,
      entityLabel: r.reference,
      href: `/app/${orgId}/suivi-entreprise?enrollment=${r.f.enrollmentId}`,
      assigneeUserId: r.pedagogyManagerUserId ?? null,
      assigneeRole: r.pedagogyManagerUserId ? null : "pedagogy_manager",
      dueDate: r.f.nextDate,
      priority: "haute",
      idempotencyKey: key,
      source: "automatique",
      isDemo,
    });
    if (res.created) created++;
  }
  return { checked: rows.length, created };
}

/** Quand un nouveau suivi est enregistré, la tâche de rappel liée à la date dépassée est résolue (jamais supprimée). */
export async function resolveFollowupReminder(orgId: string, enrollmentId: string, previousNextDate: string | null, userId: string) {
  if (!previousNextDate) return;
  await resolveTaskByKey(orgId, `followup:${enrollmentId}:${previousNextDate}`, "Suivi enregistré.", userId);
}

/* ---------- Évaluations et progression ---------- */

/** Grille d'une session : inscriptions × modules avec le dernier résultat par module. */
export async function sessionProgressionGrid(orgId: string, sessionId: string) {
  const [session] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, sessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
  if (!session) return null;
  const [enrollments, modules] = await Promise.all([
    db
      .select({ enrollment: schema.enrollments, person: { id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName } })
      .from(schema.enrollments)
      .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
      .where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.sessionId, sessionId), inArray(schema.enrollments.status, ["inscrit", "en_cours", "termine"])))
      .orderBy(asc(schema.persons.lastName), asc(schema.persons.firstName)),
    db.select().from(schema.modules).where(and(eq(schema.modules.orgId, orgId), eq(schema.modules.programVersionId, session.programVersionId))).orderBy(asc(schema.modules.position)),
  ]);
  const ids = enrollments.map((e) => e.enrollment.id);
  const evals = ids.length
    ? await db
        .select({ enrollmentId: schema.evaluations.enrollmentId, moduleId: schema.evaluations.moduleId, result: schema.evaluations.result, kind: schema.evaluations.kind, date: schema.evaluations.date })
        .from(schema.evaluations)
        .where(and(eq(schema.evaluations.orgId, orgId), inArray(schema.evaluations.enrollmentId, ids)))
        .orderBy(asc(schema.evaluations.date))
    : [];
  const cell = new Map<string, { result: string; kind: string; date: string; count: number }>();
  for (const ev of evals) {
    const key = `${ev.enrollmentId}:${ev.moduleId ?? "general"}`;
    const prev = cell.get(key);
    cell.set(key, { result: ev.result, kind: ev.kind, date: ev.date, count: (prev?.count ?? 0) + 1 });
  }
  return { session, enrollments, modules, cell };
}

/* ---------- Livret PDF ---------- */

export async function renderLivretPdf(input: {
  org: Org;
  person: { firstName: string; lastName: string };
  enrollment: { reference: string; progression: string; startDate: string | null; endDate: string | null };
  session: { code: string; title: string };
  program: { title: string } | null;
  evaluations: { date: string; kind: string; title: string; moduleTitle?: string | null; result: string; score?: number | null; maxScore?: number | null; comment?: string | null }[];
  entries: { date: string; kind: string; title: string; body?: string | null; authorRole?: string | null }[];
  followups: { date: string; kind: string; summary: string; actions?: string | null; nextDate?: string | null }[];
  hours: { planned: number; scheduled: number; done: number; justified: number; validated: number };
}): Promise<Buffer> {
  const { doc, done } = newPdf(`Livret ${input.enrollment.reference}`);
  writeOrgHeader(doc, input.org, "Livret de suivi du parcours");
  doc.font("Helvetica-Bold").fontSize(13).fillColor(INK).text(clean(`${input.person.firstName} ${input.person.lastName.toUpperCase()}`));
  doc.font("Helvetica").fontSize(9.5).fillColor(MUTED);
  doc.text(clean(`Inscription ${input.enrollment.reference} · ${input.session.code} : ${input.session.title}`));
  if (input.program) doc.text(clean(`Formation : ${input.program.title}`));
  doc.text(clean(`Parcours du ${input.enrollment.startDate ? fmtDate(input.enrollment.startDate) : "[À COMPLÉTER : date de début]"} au ${input.enrollment.endDate ? fmtDate(input.enrollment.endDate) : "[À COMPLÉTER : date de fin]"}`));
  doc.text(clean(`Progression pédagogique : ${PROGRESSION_LABELS[input.enrollment.progression] ?? input.enrollment.progression} (déclarée par le responsable pédagogique)`));
  doc.fillColor(INK);

  section(doc, "Heures (compteurs distincts, jamais additionnés)");
  const h = input.hours;
  const fm = (m: number) => `${Math.floor(m / 60)} h${m % 60 ? ` ${String(m % 60).padStart(2, "0")}` : ""}`;
  para(doc, `Prévues : ${fm(h.planned)} · Programmées : ${fm(h.scheduled)} · Effectuées : ${fm(h.done)} · Justifiées : ${fm(h.justified)} · Validées (périodes clôturées) : ${fm(h.validated)}`);

  section(doc, "Évaluations");
  if (!input.evaluations.length) para(doc, "Aucune évaluation enregistrée.", "");
  for (const ev of input.evaluations) {
    doc.font("Helvetica-Bold").fontSize(9.5).fillColor(INK).text(clean(`${fmtDate(ev.date)} · ${EVALUATION_KIND_LABELS[ev.kind] ?? ev.kind} · ${ev.title}${ev.moduleTitle ? ` (${ev.moduleTitle})` : ""}`));
    doc.font("Helvetica").fontSize(9).fillColor(MUTED).text(clean(`Résultat : ${statusMeta[ev.result]?.label ?? ev.result}${ev.score != null && ev.maxScore ? ` · ${ev.score} / ${ev.maxScore}` : ""}`));
    if (ev.comment) doc.text(clean(ev.comment));
    doc.moveDown(0.4);
  }
  doc.fillColor(INK);

  section(doc, "Livret : entrées datées");
  if (!input.entries.length) para(doc, "Aucune entrée.", "");
  for (const en of input.entries) {
    doc.font("Helvetica-Bold").fontSize(9.5).fillColor(INK).text(clean(`${fmtDate(en.date)} · ${RECORD_KIND_LABELS[en.kind] ?? en.kind} · ${en.title}`));
    if (en.body) doc.font("Helvetica").fontSize(9).fillColor(MUTED).text(clean(en.body));
    doc.moveDown(0.4);
  }
  doc.fillColor(INK);

  if (input.followups.length) {
    section(doc, "Suivi en entreprise");
    for (const f of input.followups) {
      doc.font("Helvetica-Bold").fontSize(9.5).fillColor(INK).text(clean(`${fmtDate(f.date)} · ${FOLLOWUP_KIND_LABELS[f.kind] ?? f.kind}`));
      doc.font("Helvetica").fontSize(9).fillColor(MUTED).text(clean(f.summary));
      if (f.actions) doc.text(clean(`Actions : ${f.actions}`));
      if (f.nextDate) doc.text(clean(`Prochaine échéance : ${fmtDate(f.nextDate)}`));
      doc.moveDown(0.4);
    }
    doc.fillColor(INK);
  }
  writeFooter(doc, input.org, "Livret de suivi (F07) : document généré, non signé");
  doc.end();
  return done;
}
