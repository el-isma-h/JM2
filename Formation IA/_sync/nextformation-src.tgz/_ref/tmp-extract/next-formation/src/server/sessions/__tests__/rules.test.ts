import { describe, expect, it } from "vitest";
import { canTransitionSession, nextSessionStatuses, normalizeRhythm, rhythmLabel } from "../rules";

const session = { status: "ouverte" as const, startDate: "2026-09-07", endDate: "2027-06-25", minCapacity: 6, capacity: 12 };
const counts = { enrolled: 8, confirmed: 7, today: "2026-05-10" };

describe("transitions de statut de session", () => {
  it("brouillon → ouverte", () => {
    expect(canTransitionSession({ ...session, status: "brouillon" }, "ouverte", counts)).toEqual({ ok: true });
  });

  it("confirmée exige le minimum d'inscriptions confirmées, avec un message explicite", () => {
    expect(canTransitionSession(session, "confirmee", counts)).toEqual({ ok: true });
    const r = canTransitionSession(session, "confirmee", { ...counts, confirmed: 3 });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toContain("3 inscription(s) confirmée(s) pour un minimum de 6");
  });

  it("en cours exige la date de début atteinte", () => {
    const s = { ...session, status: "confirmee" as const };
    expect(canTransitionSession(s, "en_cours", counts).ok).toBe(false);
    expect(canTransitionSession(s, "en_cours", { ...counts, today: "2026-09-07" })).toEqual({ ok: true });
  });

  it("terminée exige la date de fin passée", () => {
    const s = { ...session, status: "en_cours" as const };
    expect(canTransitionSession(s, "terminee", { ...counts, today: "2027-06-25" }).ok).toBe(false);
    expect(canTransitionSession(s, "terminee", { ...counts, today: "2027-06-26" })).toEqual({ ok: true });
  });

  it("refuse les transitions hors cycle et le même statut", () => {
    expect(canTransitionSession(session, "terminee", counts).ok).toBe(false);
    expect(canTransitionSession(session, "ouverte", counts).ok).toBe(false);
    expect(canTransitionSession({ ...session, status: "terminee" }, "annulee", counts).ok).toBe(false);
    expect(nextSessionStatuses("terminee")).toEqual([]);
    expect(nextSessionStatuses("annulee")).toEqual(["brouillon"]);
  });
});

describe("rythmes paramétrables", () => {
  it("applique les préréglages 1 jour / 4 jours et 2 jours / 8 jours", () => {
    const r1 = normalizeRhythm({ preset: "1_4" });
    expect(r1.label).toBe("1 jour / 4 jours");
    expect(r1.centerDays).toBe(1);
    expect(r1.companyDays).toBe(4);
    const r2 = normalizeRhythm({ preset: "2_8" });
    expect(r2.label).toBe("2 jours / 8 jours");
    expect(r2.weekdays).toEqual([1, 2]);
  });

  it("rythme personnalisé : jours de centre, horaires, libellé calculé", () => {
    const r = normalizeRhythm({ preset: "personnalise", weekdays: [3, 1, 1, 9], morning: { start: "08:30", end: "12:00" }, afternoon: { start: "13:30", end: "16:30" } });
    expect(r.weekdays).toEqual([1, 3]);
    expect(r.centerDays).toBe(2);
    expect(r.label).toBe("Centre : Lundi, Mercredi");
    expect(r.morning).toEqual({ start: "08:30", end: "12:00" });
    expect(r.afternoon).toEqual({ start: "13:30", end: "16:30" });
  });

  it("horaires invalides : reprend ceux de l'organisme puis les valeurs par défaut", () => {
    const r = normalizeRhythm({ preset: "continu", morning: { start: "9h", end: "12:00" } }, { morning: { start: "08:45", end: "12:15" } });
    expect(r.morning).toEqual({ start: "08:45", end: "12:00" });
    expect(r.afternoon).toEqual({ start: "14:00", end: "17:00" });
  });

  it("libellé d'un rythme stocké sans inventer", () => {
    expect(rhythmLabel({ label: "1 jour / 4 jours" })).toBe("1 jour / 4 jours");
    expect(rhythmLabel({})).toBe("Non renseigné");
    expect(rhythmLabel(null)).toBe("Non renseigné");
  });
});
