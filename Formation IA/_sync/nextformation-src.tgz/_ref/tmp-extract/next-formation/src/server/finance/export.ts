import "server-only";
import { and, asc, eq, inArray, isNull, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { accountingSettingsFrom, centsToDecimal, salesJournalRows, toCsv } from "./compute";
import { ISSUED_STATUSES } from "./service";

export type SalesExportInput = { orgId: string; from: string; to: string; onlyNew: boolean; mark: boolean; userId: string; settings: unknown };

/** Journal des ventes (date ; pièce ; compte ; libellé ; débit ; crédit) et marquage du lot exporté. */
export async function exportSalesJournal(input: SalesExportInput): Promise<{ csv: string; count: number; batch: string | null }> {
  const acc = accountingSettingsFrom(input.settings);
  const rows = await db
    .select()
    .from(schema.invoices)
    .where(
      and(
        eq(schema.invoices.orgId, input.orgId),
        inArray(schema.invoices.status, ISSUED_STATUSES),
        inArray(schema.invoices.kind, ["facture", "acompte", "avoir"]),
        sql`${schema.invoices.issueDate} >= ${input.from}`,
        sql`${schema.invoices.issueDate} <= ${input.to}`,
        input.onlyNew ? isNull(schema.invoices.exportedAt) : undefined,
      ),
    )
    .orderBy(asc(schema.invoices.issueDate), asc(schema.invoices.number));
  const journal = rows.flatMap((i) =>
    salesJournalRows({ number: i.number ?? "", kind: i.kind, issueDate: i.issueDate, totalHtCents: i.totalHtCents, vatCents: i.vatCents, totalTtcCents: i.totalTtcCents, billToName: (i.billTo as { name?: string })?.name ?? "" }, acc),
  );
  const csv = toCsv(
    ["journal", "date", "piece", "compte", "libelle", "debit", "credit"],
    journal.map((r) => [acc.journal, r.date, r.piece, r.compte, r.libelle, centsToDecimal(r.debit), centsToDecimal(r.credit)]),
  );
  let batch: string | null = null;
  if (input.mark && rows.length) {
    batch = `VE-${new Date().toISOString().slice(0, 19).replace(/[-:T]/g, "")}`;
    const ids = rows.filter((r) => !r.exportedAt).map((r) => r.id);
    if (ids.length) await db.update(schema.invoices).set({ exportedAt: new Date(), exportBatch: batch }).where(and(eq(schema.invoices.orgId, input.orgId), inArray(schema.invoices.id, ids)));
    await audit({ action: "invoice.export", userId: input.userId, orgId: input.orgId, entityType: "export", after: { batch, from: input.from, to: input.to, invoices: rows.length, marked: ids.length } });
  } else {
    await audit({ action: "invoice.export", userId: input.userId, orgId: input.orgId, entityType: "export", after: { batch: null, from: input.from, to: input.to, invoices: rows.length, marked: 0 } });
  }
  return { csv, count: rows.length, batch };
}
