"use server";

import { redirect } from "next/navigation";
import { and, eq, gt, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { createSession } from "@/server/auth";
import { audit } from "@/server/audit";
import { seedDemo, type DemoProfile } from "@/server/demo/seed";
import { clientIp, hit, RATE_LIMITS, tooManyMessage } from "@/server/rate-limit";
import type { ActionState } from "./auth";

/** Plafond global de démonstrations créées par heure (protection contre l'abus). */
const MAX_DEMOS_PER_HOUR = 300;

/**
 * Crée un espace de démonstration neuf pour ce visiteur, ouvre une session et redirige.
 * L'espace est supprimé automatiquement après 24 heures (tâche demo:cleanup).
 */
export async function enterDemoAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const asRaw = String(formData.get("as") ?? "direction");
  const as = (["direction", "admin", "pedagogy", "trainer", "learner", "employer", "finance", "quality"].includes(asRaw) ? asRaw : "direction") as DemoProfile;
  const rl = await hit("demo:ip", await clientIp(), RATE_LIMITS.demoIp);
  if (!rl.ok) return { error: tooManyMessage(rl) };
  const [{ n }] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.tenants)
    .where(and(eq(schema.tenants.isDemo, true), gt(schema.tenants.createdAt, new Date(Date.now() - 3600_000))));
  if (n >= MAX_DEMOS_PER_HOUR) return { error: "Trop de démonstrations ont été ouvertes ces dernières minutes. Réessayez dans un moment." };

  let target: string;
  try {
    const demo = await seedDemo();
    const userId = demo.users[as] ?? demo.users.direction;
    await createSession(userId);
    await audit({ action: "demo.enter", userId, tenantId: demo.tenantId, orgId: demo.orgId, entityType: "tenant", entityId: demo.tenantId, after: { as } });
    target = as === "learner" ? "/moi" : as === "trainer" ? "/formateur" : as === "employer" ? "/entreprise" : `/app/${demo.orgId}`;
  } catch (e) {
    console.error("demo.enter", e);
    return { error: "La démonstration n'a pas pu être préparée. Réessayez dans un instant." };
  }
  redirect(target);
}
