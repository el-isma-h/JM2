import "server-only";

/**
 * Registre des traitements de tâches de fond, séparé de `handlers.ts` pour éviter tout cycle d'import :
 * les modules métier (`finance/jobs`, `quality/jobs`, `integrations/jobs`…) importent ce fichier,
 * `handlers.ts` les importe à son tour pour garantir leur enregistrement. Le registre vit sur `globalThis`
 * pour survivre au rechargement à chaud du serveur de développement.
 */
export type JobContext = { id: string; kind: string; payload: Record<string, unknown>; tenantId: string | null; orgId: string | null };
export type JobHandler = (job: JobContext) => Promise<Record<string, unknown> | void>;

const g = globalThis as unknown as { __nfJobHandlers?: Map<string, JobHandler> };
const handlers = (g.__nfJobHandlers ??= new Map<string, JobHandler>());

export function registerJobHandler(kind: string, handler: JobHandler) {
  handlers.set(kind, handler);
}
export function getJobHandler(kind: string): JobHandler | undefined {
  return handlers.get(kind);
}
export function knownJobKinds(): string[] {
  return [...handlers.keys()].sort();
}
