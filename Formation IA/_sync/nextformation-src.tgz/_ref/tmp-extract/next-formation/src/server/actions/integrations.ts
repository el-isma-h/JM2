"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { randomToken, sha256 } from "@/lib/crypto";
import { appUrl } from "@/lib/env";
import { requireOrg, type OrgContext } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { createDocument, issueDownloadLink } from "@/server/documents/store";
import { todayParis } from "@/lib/time";
import { getIntegration, readSecrets, upsertIntegration, type IntegrationKind } from "@/server/integrations/store";
import { testMoodleConnection } from "@/server/integrations/moodle";
import { queueWebhookJob, WEBHOOK_EVENTS } from "@/server/integrations/webhooks";
import { edofCsv, edofRows, edofXml } from "@/server/integrations/edof";
import { API_SCOPES } from "@/server/integrations/api-auth";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

/** Lecture org.view ; écriture integrations.manage ou propriétaire. */
async function requireWriter(orgId: string): Promise<OrgContext> {
  const ctx = await requireOrg(orgId, "org.view");
  if (!ctx.isOwner && !ctx.permissions.has("integrations.manage")) throw new AuthError("forbidden");
  return ctx;
}

function done(orgId: string) {
  revalidatePath(`/app/${orgId}/integrations`);
}

/* ---------- Moodle ---------- */

export async function saveMoodleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const url = z.string().trim().url("Adresse Moodle invalide (https://…).").parse(formData.get("url"));
    const token = String(formData.get("token") ?? "").trim();
    const row = await upsertIntegration(orgId, "moodle", { config: { url }, secrets: token ? { token } : undefined, status: "configuree", lastError: null });
    const hasToken = Boolean(readSecrets(row));
    await audit({ action: "integration.moodle.save", userId: ctx.user.id, orgId, entityType: "org_integration", entityId: row.id, after: { url, tokenSet: hasToken } });
    done(orgId);
    return { ok: true, message: hasToken ? "Moodle enregistré : testez la connexion." : "Adresse enregistrée. Saisissez le jeton de service web pour pouvoir tester la connexion." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function testMoodleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const row = await getIntegration(orgId, "moodle");
    const cfg = (row?.config ?? {}) as { url?: string };
    const secrets = readSecrets<{ token?: string }>(row);
    if (!cfg.url || !secrets?.token) return { error: "Moodle non configuré : renseignez l'adresse et le jeton de service web (Administration du site, Serveur, Services web, Jetons)." };
    const r = await testMoodleConnection(cfg.url, secrets.token);
    await upsertIntegration(orgId, "moodle", { status: r.ok ? "connectee" : "erreur", lastError: r.ok ? null : r.error, lastSyncAt: r.ok ? new Date() : undefined, config: r.ok ? { sitename: r.info.sitename, release: r.info.release ?? null } : {} });
    await audit({ action: "integration.moodle.test", userId: ctx.user.id, orgId, entityType: "org_integration", entityId: row?.id ?? null, after: { ok: r.ok, error: r.ok ? null : r.error } });
    done(orgId);
    return r.ok ? { ok: true, message: `Connexion réussie : ${r.info.sitename}${r.info.release ? ` (${r.info.release})` : ""}, utilisateur ${r.info.username ?? "?"}.` } : { error: r.error };
  } catch (e) {
    return fail(e, "Test impossible.");
  }
}

/* ---------- Microsoft 365 / SharePoint ---------- */

export async function saveMicrosoftAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const d = z.object({ tenantId: z.string().trim().min(8, "Identifiant de tenant requis.").max(120), clientId: z.string().trim().min(8, "Identifiant d'application (client id) requis.").max(120), siteUrl: z.string().trim().url("Adresse SharePoint invalide.").optional().or(z.literal("")) }).parse(Object.fromEntries(formData));
    const secret = String(formData.get("clientSecret") ?? "").trim();
    const row = await upsertIntegration(orgId, "microsoft365", { config: { tenantId: d.tenantId, clientId: d.clientId, siteUrl: d.siteUrl || null }, secrets: secret ? { clientSecret: secret } : undefined, status: "configuree", lastError: null });
    await audit({ action: "integration.microsoft365.save", userId: ctx.user.id, orgId, entityType: "org_integration", entityId: row.id, after: { tenantId: d.tenantId, clientId: d.clientId, secretSet: Boolean(readSecrets(row)) } });
    done(orgId);
    return { ok: true, message: "Microsoft 365 enregistré (statut configuré). La synchronisation SharePoint reste à brancher : voir l'explication sur la carte." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/* ---------- Zapier / webhooks ---------- */

export async function saveWebhookAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const kind = z.enum(["webhook", "zapier"]).parse(formData.get("kind"));
    const url = z.string().trim().url("Adresse du webhook invalide (https://…).").parse(formData.get("url"));
    if (!url.startsWith("https://")) return { error: "Le webhook doit utiliser https://." };
    const events = formData.getAll("events").map(String).filter((e) => WEBHOOK_EVENTS.some((w) => w.key === e));
    if (!events.length) return { error: "Choisissez au moins un événement." };
    const existing = await getIntegration(orgId, kind);
    let secret = String(formData.get("secret") ?? "").trim();
    let generated = false;
    if (!secret && !readSecrets(existing)) {
      secret = randomToken(24);
      generated = true;
    }
    const row = await upsertIntegration(orgId, kind, { config: { url, events }, secrets: secret ? { secret } : undefined, status: "configuree", lastError: null });
    await audit({ action: `integration.${kind}.save`, userId: ctx.user.id, orgId, entityType: "org_integration", entityId: row.id, after: { url, events, secretGenerated: generated } });
    done(orgId);
    return generated ? { ok: true, message: "Webhook enregistré. Secret de signature généré (affiché une seule fois, à configurer chez le destinataire pour vérifier X-NextFormation-Signature) :", data: { link: secret } } : { ok: true, message: "Webhook enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function testWebhookAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const kind = z.enum(["webhook", "zapier"]).parse(formData.get("kind"));
    const row = await getIntegration(orgId, kind);
    if (!row || !(row.config as { url?: string }).url || !readSecrets(row)) return { error: "Webhook non configuré (adresse ou secret absent)." };
    if (ctx.org.isDemo) return { error: "Démonstration : aucun envoi externe." };
    const job = await queueWebhookJob(orgId, { integrationId: row.id, event: "test.ping", data: { message: "Test depuis Next Formation" }, at: new Date().toISOString() });
    await audit({ action: `integration.${kind}.test`, userId: ctx.user.id, orgId, entityType: "org_integration", entityId: row.id, after: { jobId: job.id } });
    done(orgId);
    return { ok: true, message: "Envoi de test mis en file (tâche de fond webhooks:dispatch) : le statut passera à « connectée » ou « erreur » après exécution." };
  } catch (e) {
    return fail(e, "Test impossible.");
  }
}

/* ---------- Activation / désactivation ---------- */

export async function toggleIntegrationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const kind = z.enum(schema.integrationKindEnum.enumValues).parse(formData.get("kind")) as IntegrationKind;
    const row = await getIntegration(orgId, kind);
    if (!row) return { error: "Intégration non configurée." };
    const next = row.status === "desactivee" ? "configuree" : "desactivee";
    await upsertIntegration(orgId, kind, { status: next });
    await audit({ action: "integration.toggle", userId: ctx.user.id, orgId, entityType: "org_integration", entityId: row.id, before: { status: row.status }, after: { status: next } });
    done(orgId);
    return { ok: true, message: next === "desactivee" ? "Intégration désactivée." : "Intégration réactivée." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

/* ---------- EDOF ---------- */

export async function generateEdofExportAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "org.view", "exports.run");
    const format = z.enum(["xml", "csv"]).parse(formData.get("format"));
    const rows = await edofRows(orgId, todayParis());
    if (!rows.length) return { error: "Aucune session publiée (statut ouverte ou confirmée, non terminée) : rien à exporter vers EDOF." };
    const body = format === "xml" ? edofXml(rows) : edofCsv(rows);
    const fileName = `edof-sessions-${todayParis()}.${format}`;
    const doc = await createDocument({ orgId, category: "export", visibility: "interne", status: "genere", title: `Export EDOF (${rows.length} session(s))`, fileName, mimeType: format === "xml" ? "application/xml" : "text/csv", data: Buffer.from(body, "utf8"), sourceType: "edof_export", uploadedBy: ctx.user.id, isDemo: ctx.org.isDemo });
    await upsertIntegration(orgId, "edof", { status: "configuree", lastSyncAt: new Date(), lastError: null, config: { lastCount: rows.length, lastFormat: format } });
    const link = await issueDownloadLink(doc.id, ctx.user.id);
    await audit({ action: "integration.edof.export", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, after: { format, rows: rows.length } });
    done(orgId);
    return { ok: true, message: `Fichier EDOF généré (${rows.length} session(s)). Lien valable 15 minutes :`, data: { link } };
  } catch (e) {
    return fail(e, "Export impossible.");
  }
}

/* ---------- Clés API ---------- */

export async function createApiKeyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const name = z.string().trim().min(2, "Nom de la clé requis.").max(80).parse(formData.get("name"));
    const scopes = formData.getAll("scopes").map(String).filter((s) => API_SCOPES.some((x) => x.key === s));
    if (!scopes.length) return { error: "Choisissez au moins une portée." };
    const token = `nf_${randomToken(32)}`;
    const [row] = await db.insert(schema.apiKeys).values({ orgId, name, keyHash: sha256(token), prefix: token.slice(0, 11), scopes, createdBy: ctx.user.id }).returning({ id: schema.apiKeys.id });
    await audit({ action: "integration.apikey.create", userId: ctx.user.id, orgId, entityType: "api_key", entityId: row.id, after: { name, scopes, prefix: token.slice(0, 11) } });
    done(orgId);
    return { ok: true, message: "Clé créée. Elle n'est affichée qu'une seule fois : copiez-la maintenant.", data: { link: token } };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function revokeApiKeyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireWriter(orgId);
    const id = uuid.parse(formData.get("keyId"));
    const [key] = await db.select().from(schema.apiKeys).where(and(eq(schema.apiKeys.id, id), eq(schema.apiKeys.orgId, orgId))).limit(1);
    if (!key) return { error: "Clé introuvable." };
    if (key.revokedAt) return { ok: true, message: "Clé déjà révoquée." };
    await db.update(schema.apiKeys).set({ revokedAt: new Date() }).where(eq(schema.apiKeys.id, id));
    await audit({ action: "integration.apikey.revoke", userId: ctx.user.id, orgId, entityType: "api_key", entityId: id, before: { name: key.name, prefix: key.prefix } });
    done(orgId);
    return { ok: true, message: "Clé révoquée : les appels avec cette clé sont refusés immédiatement." };
  } catch (e) {
    return fail(e, "Révocation impossible.");
  }
}

/* ---------- Stripe : lien de paiement pour une facture ---------- */

export async function createStripePaymentLinkAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "finance.manage");
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) return { error: "Paiement en ligne non configuré : définissez STRIPE_SECRET_KEY (clé secrète Stripe) dans l'environnement du serveur." };
    if (ctx.org.isDemo) return { error: "Démonstration : aucun appel Stripe réel." };
    const invoiceId = uuid.parse(formData.get("invoiceId"));
    const [inv] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, invoiceId), eq(schema.invoices.orgId, orgId))).limit(1);
    if (!inv) return { error: "Facture introuvable." };
    if (!inv.number || inv.status === "brouillon" || inv.status === "annulee" || inv.status === "payee") return { error: "Seule une facture émise, non soldée, peut recevoir un lien de paiement." };
    const due = inv.totalTtcCents - inv.paidCents;
    if (due <= 0) return { error: "Aucun reste à payer." };
    const params = new URLSearchParams();
    params.set("mode", "payment");
    params.set("success_url", `${appUrl()}/app/${orgId}/factures/${inv.id}?paiement=ok`);
    params.set("cancel_url", `${appUrl()}/app/${orgId}/factures/${inv.id}?paiement=annule`);
    params.set("line_items[0][quantity]", "1");
    params.set("line_items[0][price_data][currency]", "eur");
    params.set("line_items[0][price_data][unit_amount]", String(due));
    params.set("line_items[0][price_data][product_data][name]", `Facture ${inv.number}`);
    params.set("metadata[invoiceId]", inv.id);
    params.set("metadata[orgId]", orgId);
    const res = await fetch("https://api.stripe.com/v1/checkout/sessions", { method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/x-www-form-urlencoded" }, body: params.toString() });
    const body = (await res.json()) as { url?: string; id?: string; error?: { message?: string } };
    if (!res.ok || !body.url) return { error: `Stripe : ${body.error?.message ?? `réponse ${res.status}`}.` };
    await upsertIntegration(orgId, "stripe", { status: "connectee", lastSyncAt: new Date(), lastError: null });
    await audit({ action: "integration.stripe.checkout", userId: ctx.user.id, orgId, entityType: "invoice", entityId: inv.id, after: { sessionId: body.id, amountCents: due } });
    return { ok: true, message: `Lien de paiement Stripe créé pour ${inv.number} (le règlement devra être rapproché manuellement ou via webhook Stripe, non branché) :`, data: { link: body.url } };
  } catch (e) {
    return fail(e, "Création du lien impossible.");
  }
}
