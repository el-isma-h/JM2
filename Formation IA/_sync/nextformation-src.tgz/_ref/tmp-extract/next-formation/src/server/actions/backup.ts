"use server";

import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requirePlatformAdmin } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { backupTenant, readBackup, restoreTenant } from "@/server/backup";
import type { ActionState } from "./auth";

const uuid = z.string().uuid();

export async function backupTenantAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const tenantId = uuid.parse(formData.get("tenantId"));
    const r = await backupTenant(tenantId, admin.id);
    await audit({ action: "admin.backup.create", userId: admin.id, tenantId, entityType: "backup", entityId: r.backupId, after: { sizeBytes: r.sizeBytes, sha256: r.sha256, counts: r.counts } });
    revalidatePath("/admin/sauvegardes");
    const rows = Object.values(r.counts).reduce((a, b) => a + b, 0);
    return { ok: true, message: `Sauvegarde créée : ${rows} lignes, ${(r.sizeBytes / 1024).toFixed(1)} Ko compressés.` };
  } catch (e) {
    if (e instanceof z.ZodError) return { error: "Choisissez une organisation." };
    return { error: authErrorMessage(e) ?? (e instanceof Error ? e.message : "Sauvegarde impossible.") };
  }
}

export async function verifyBackupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const backupId = uuid.parse(formData.get("backupId"));
    const { payload } = await readBackup(backupId);
    await audit({ action: "admin.backup.verify", userId: admin.id, entityType: "backup", entityId: backupId });
    const rows = Object.values(payload.counts).reduce((a, b) => a + b, 0);
    return { ok: true, message: `Empreinte sha256 vérifiée. ${rows} lignes, ${Object.keys(payload.files).length} fichiers.` };
  } catch (e) {
    return { error: authErrorMessage(e) ?? (e instanceof Error ? e.message : "Vérification impossible.") };
  }
}

/** Restauration vers un NOUVEAU tenant (jamais d'écrasement). Confirmation par saisie du mot RESTAURER. */
export async function restoreBackupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const backupId = uuid.parse(formData.get("backupId"));
    if (String(formData.get("confirm") ?? "").trim().toUpperCase() !== "RESTAURER") return { error: "Saisissez RESTAURER pour confirmer." };
    const name = String(formData.get("name") ?? "").trim() || undefined;
    const [b] = await db.select().from(schema.backups).where(eq(schema.backups.id, backupId)).limit(1);
    const r = await restoreTenant(backupId, { name });
    await audit({ action: "admin.backup.restore", userId: admin.id, tenantId: r.tenantId, entityType: "backup", entityId: backupId, before: { sourceTenantId: b?.tenantId ?? null }, after: { tenantId: r.tenantId, counts: r.counts, skipped: r.skipped, missingFiles: r.missingFiles } });
    revalidatePath("/admin/sauvegardes");
    revalidatePath("/admin/organisations");
    const rows = Object.values(r.counts).reduce((a, x) => a + x, 0);
    return {
      ok: true,
      message: `Restauré dans la nouvelle organisation « ${r.tenantName} » : ${rows} lignes${r.missingFiles ? `, ${r.missingFiles} fichiers absents de la sauvegarde` : ""}.`,
      data: { tenantId: r.tenantId },
    };
  } catch (e) {
    return { error: authErrorMessage(e) ?? (e instanceof Error ? e.message : "Restauration impossible.") };
  }
}
