import "server-only";
import { and, eq, inArray, isNull, or } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { assertSessionInScope } from "@/server/authz";
import { frenchHolidays } from "@/lib/dates";
import type { Agent, AgentInput, ProposalDraft } from "../store";
import { baseRationale, requireEntity } from "./shared";
import { generateCalendar, type PlanningInput } from "./calendar";

export type { PlanningInput };

export type PlanningPayload = {
  sessionId: string;
  startDate: string;
  endDate: string;
  targetMinutes: number;
  plannedMinutes: number;
  weekdays: number[];
  parts: { part: "matin" | "apres_midi"; start: string; end: string }[];
  slots: { date: string; parts: ("matin" | "apres_midi")[] }[];
  skipped: { date: string; reason: string }[];
};

export const planningAgent: Agent = {
  name: "planning",
  label: "Proposition de calendrier",
  description: "Calendrier de séances selon le rythme de la session, les fermetures et les indisponibilités formateur. Rien n'est écrit : la saisie reste une action humaine.",
  requires: "planning.view",
  accepts: ["session"],
  async run(ctx: OrgContext, input: AgentInput): Promise<ProposalDraft> {
    const { entityId } = requireEntity(input, ["session"]);
    await assertSessionInScope(ctx, entityId);
    const [s] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, entityId), eq(schema.trainingSessions.orgId, ctx.org.id))).limit(1);
    if (!s) throw new Error("Session introuvable.");
    const [version] = await db.select({ durationHours: schema.programVersions.durationHours, companyHours: schema.programVersions.companyHours, rhythm: schema.programVersions.rhythm }).from(schema.programVersions).where(eq(schema.programVersions.id, s.programVersionId)).limit(1);
    const orgSettings = (ctx.org.settings ?? {}) as { morning?: { start: string; end: string }; afternoon?: { start: string; end: string } };
    const sched = (s.schedule ?? {}) as { morning?: { start: string; end: string }; afternoon?: { start: string; end: string } };
    const morning = sched.morning ?? orgSettings.morning ?? { start: "09:00", end: "12:00" };
    const afternoon = sched.afternoon ?? orgSettings.afternoon ?? { start: "14:00", end: "17:00" };
    const rhythm = ((Object.keys(s.rhythm ?? {}).length ? s.rhythm : version?.rhythm) ?? {}) as { weekdays?: number[]; label?: string };
    const weekdays = Array.isArray(rhythm.weekdays) && rhythm.weekdays.length ? rhythm.weekdays.filter((d) => d >= 1 && d <= 7) : [1, 2, 3, 4, 5];
    const centerHours = Math.max(0, (version?.durationHours ?? 0) - (version?.companyHours ?? 0));
    const targetMinutes = (input.params?.hours ? Number(input.params.hours) * 60 : centerHours * 60) || 7 * 60;
    const closures = await db.select({ startDate: schema.closures.startDate, endDate: schema.closures.endDate, reason: schema.closures.reason }).from(schema.closures).where(and(eq(schema.closures.orgId, ctx.org.id), s.siteId ? or(isNull(schema.closures.siteId), eq(schema.closures.siteId, s.siteId)) : isNull(schema.closures.siteId)));
    const trainerIds = (await db.select({ id: schema.sessionTrainers.trainerId }).from(schema.sessionTrainers).where(eq(schema.sessionTrainers.sessionId, s.id))).map((r) => r.id);
    const unavailabilities = trainerIds.length
      ? await db.select({ startDate: schema.trainerUnavailabilities.startDate, endDate: schema.trainerUnavailabilities.endDate, part: schema.trainerUnavailabilities.part, reason: schema.trainerUnavailabilities.reason }).from(schema.trainerUnavailabilities).where(and(eq(schema.trainerUnavailabilities.orgId, ctx.org.id), inArray(schema.trainerUnavailabilities.trainerId, trainerIds)))
      : [];
    const years = [...new Set([Number(s.startDate.slice(0, 4)), Number(s.endDate.slice(0, 4))])];
    const parts: PlanningPayload["parts"] = [
      { part: "matin", start: morning.start, end: morning.end },
      { part: "apres_midi", start: afternoon.start, end: afternoon.end },
    ];
    const gen = generateCalendar({ startDate: s.startDate, endDate: s.endDate, targetMinutes, weekdays, parts, closures: closures.map((c) => ({ ...c, reason: c.reason })), unavailabilities, holidays: years.flatMap(frenchHolidays) });
    const payload: PlanningPayload = { sessionId: s.id, startDate: s.startDate, endDate: s.endDate, targetMinutes, plannedMinutes: gen.plannedMinutes, weekdays, parts, slots: gen.slots, skipped: gen.skipped };
    const notes = [];
    if (gen.plannedMinutes < targetMinutes) notes.push(`La fenêtre de la session ne permet de programmer que ${Math.round(gen.plannedMinutes / 60)} h sur ${Math.round(targetMinutes / 60)} h cibles.`);
    if (!trainerIds.length) notes.push("Aucun formateur affecté : les indisponibilités n'ont pas pu être prises en compte.");
    return {
      agent: "planning",
      kind: "calendrier",
      title: `Calendrier proposé : ${s.title} (${gen.slots.length} séance(s))`,
      summary: `${Math.round(gen.plannedMinutes / 60)} h programmables sur ${Math.round(targetMinutes / 60)} h, ${gen.skipped.length} jour(s) exclu(s)`,
      entityType: "session",
      entityId: s.id,
      payload: payload as unknown as Record<string, unknown>,
      rationale: baseRationale(
        [{ type: "session", id: s.id, label: `Session ${s.code} (${rhythm.label ?? `jours ${weekdays.join(",")}`})` }, { type: "closures", label: `${closures.length} fermeture(s)` }, { type: "trainer_unavailabilities", label: `${unavailabilities.length} indisponibilité(s)` }, { type: "holidays", label: "Jours fériés France métropolitaine" }],
        "A",
        true,
        ["Calcul déterministe : aucun modèle n'intervient.", "Validation = tâche « saisir le calendrier » pour la planification ; aucune séance n'est écrite automatiquement."],
        notes,
      ),
    };
  },
};
