/**
 * Utilitaires purs du jeu de démonstration : générateur pseudo-aléatoire déterministe, dates ISO,
 * SIRET fictifs à clé de Luhn valide, petits PDF. Aucune dépendance serveur.
 */
import { addDays, format, getISODay, parseISO } from "date-fns";
import PDFDocument from "pdfkit";
import { luhnValid } from "@/lib/validators";

/** PRNG mulberry32 : même graine, mêmes données (lisibilité des recettes). */
export function makeRng(seed: number) {
  let a = seed >>> 0;
  const next = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return {
    next,
    int: (min: number, max: number) => min + Math.floor(next() * (max - min + 1)),
    pick: <T>(arr: readonly T[]): T => arr[Math.floor(next() * arr.length)],
    chance: (p: number) => next() < p,
  };
}
export type Rng = ReturnType<typeof makeRng>;

export const iso = (d: Date) => format(d, "yyyy-MM-dd");
export const addD = (date: string, n: number) => iso(addDays(parseISO(date), n));
export const weekday = (date: string) => getISODay(parseISO(date));
/** Lundi de la semaine contenant `date`. */
export const mondayOf = (date: string) => addD(date, 1 - weekday(date));
/** Instant décalé de n minutes. */
export const plusMin = (d: Date, n: number) => new Date(d.getTime() + n * 60_000);
export const daysAgo = (today: string, n: number) => addD(today, -n);

/** Jours ouvrés (lundi à vendredi) entre deux dates incluses, selon les jours de centre et hors fermetures. */
export function centerDays(start: string, end: string, weekdays: number[], closed: Set<string>): string[] {
  const out: string[] = [];
  for (let d = start; d <= end; d = addD(d, 1)) {
    if (weekdays.includes(weekday(d)) && !closed.has(d)) out.push(d);
  }
  return out;
}

export function expandClosures(closures: { startDate: string; endDate: string }[]): Set<string> {
  const s = new Set<string>();
  for (const c of closures) for (let d = c.startDate; d <= c.endDate; d = addD(d, 1)) s.add(d);
  return s;
}

/** Chiffre de contrôle de Luhn pour compléter une suite de chiffres. */
function luhnCheckDigit(partial: string): string {
  for (let c = 0; c <= 9; c++) if (luhnValid(partial + c)) return String(c);
  throw new Error("Luhn impossible");
}

/** SIREN + SIRET fictifs mais valides (clé de Luhn), à partir de 8 chiffres et d'un NIC de 4 chiffres. */
export function fakeSiret(base8: string, nic4 = "0001"): { siren: string; siret: string } {
  const siren = base8 + luhnCheckDigit(base8);
  const siret = siren + nic4 + luhnCheckDigit(siren + nic4);
  return { siren, siret };
}

/** Partage une liste en paquets (insertions par lots). */
export function chunk<T>(arr: T[], size = 500): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

export const slugify = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

export const emailOf = (first: string, last: string, domain: string) => `${slugify(first)}.${slugify(last)}@${domain}`;

const clean = (s: string) => s.replace(/[  ]/g, " ");

/** Petit PDF A4 (pdfkit) : en-tête institutionnel, titre, paragraphes, tableau optionnel. */
export function simplePdf(input: { org: { name: string; address: string; nda: string; siret: string }; kicker: string; title: string; paragraphs: string[]; table?: { head: string[]; rows: string[][] }; footer?: string }): Promise<Buffer> {
  const doc = new PDFDocument({ size: "A4", margins: { top: 56, bottom: 56, left: 56, right: 56 }, info: { Title: input.title, Creator: "Next Formation (démonstration)" } });
  const chunks: Buffer[] = [];
  doc.on("data", (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });
  doc.font("Helvetica-Bold").fontSize(14).fillColor("#0a0b0d").text(clean(input.org.name));
  doc.font("Helvetica").fontSize(8.5).fillColor("#6b6760").text(clean(input.org.address)).text(clean(`SIRET ${input.org.siret} · Déclaration d'activité n° ${input.org.nda}`));
  doc.moveDown(0.8);
  doc.fontSize(9).fillColor("#4b2a7f").text(input.kicker.toUpperCase(), { characterSpacing: 2 });
  doc.moveTo(56, doc.y + 4).lineTo(doc.page.width - 56, doc.y + 4).strokeColor("#4b2a7f").lineWidth(1).stroke();
  doc.moveDown(1);
  doc.font("Helvetica-Bold").fontSize(16).fillColor("#0a0b0d").text(clean(input.title));
  doc.moveDown(0.6);
  doc.font("Helvetica").fontSize(10);
  for (const p of input.paragraphs) {
    doc.text(clean(p), { lineGap: 2 });
    doc.moveDown(0.5);
  }
  if (input.table) {
    doc.moveDown(0.4);
    const widths = input.table.head.map(() => (doc.page.width - 112) / input.table!.head.length);
    const row = (cells: string[], bold = false) => {
      const y = doc.y;
      doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(9);
      cells.forEach((c, i) => doc.text(clean(c), 56 + widths.slice(0, i).reduce((a, b) => a + b, 0), y, { width: widths[i] - 6 }));
      doc.y = y + 16;
    };
    row(input.table.head, true);
    doc.moveTo(56, doc.y - 3).lineTo(doc.page.width - 56, doc.y - 3).strokeColor("#d9d5cb").stroke();
    for (const r of input.table.rows) row(r);
  }
  doc.moveDown(1.2);
  doc.font("Helvetica").fontSize(7.5).fillColor("#6b6760").text(clean(input.footer ?? "Document de démonstration : données fictives, sans valeur contractuelle."));
  doc.end();
  return done;
}

/** Logo SVG minimal de l'organisme (monogramme). */
export function logoSvg(initials: string, color: string): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="96" viewBox="0 0 240 96"><rect width="240" height="96" fill="#f3f0e8"/><rect x="8" y="8" width="80" height="80" fill="${color}"/><text x="48" y="64" font-family="Helvetica, Arial, sans-serif" font-size="40" font-weight="700" fill="#f3f0e8" text-anchor="middle">${initials}</text><text x="104" y="46" font-family="Helvetica, Arial, sans-serif" font-size="18" letter-spacing="3" fill="#0a0b0d">ATELIER</text><text x="104" y="70" font-family="Helvetica, Arial, sans-serif" font-size="18" letter-spacing="3" fill="${color}">MÉRIDIEN</text></svg>`;
}
