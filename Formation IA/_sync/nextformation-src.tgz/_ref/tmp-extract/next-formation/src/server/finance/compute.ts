/**
 * Règles de calcul financières (F11) : fonctions pures, sans accès base, testées par vitest.
 * Tous les montants sont en centimes entiers ; quantités en millièmes ; taux de TVA en points de base (2000 = 20 %).
 */

export type InvoiceKind = "facture" | "avoir" | "acompte" | "proforma";
export type InvoiceStatus = "brouillon" | "emise" | "envoyee" | "partiellement_payee" | "payee" | "annulee" | "en_retard";
export type FundingStatus = "prevu" | "demande" | "accorde" | "refuse" | "facture" | "solde" | "annule";
export type FundingState = "a_definir" | "prevu" | "accorde" | "facture" | "solde" | "refuse";

export const VAT_EXEMPT_MENTION = "TVA non applicable, exonération art. 261-4-4° a du CGI (organisme de formation professionnelle continue).";
export const LATE_PENALTY_MENTION = "Pénalités de retard : trois fois le taux d'intérêt légal en vigueur, exigibles sans rappel dès le lendemain de la date d'échéance (art. L441-10 C. com.).";
export const RECOVERY_FEE_MENTION = "Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40 € (art. D441-5 C. com.).";
export const DEFAULT_PAYMENT_TERMS = "Paiement à 30 jours date de facture, par virement bancaire.";

export const FUNDING_STATUSES: FundingStatus[] = ["prevu", "demande", "accorde", "refuse", "facture", "solde", "annule"];
export const FUNDER_KINDS = ["opco", "entreprise", "france_travail", "region", "cpf", "particulier", "etat", "agefiph", "transition_pro", "autre"] as const;
export type FunderKind = (typeof FUNDER_KINDS)[number];

export const funderKindLabels: Record<FunderKind, string> = {
  opco: "OPCO",
  entreprise: "Entreprise",
  france_travail: "France Travail",
  region: "Région",
  cpf: "CPF (Caisse des Dépôts)",
  particulier: "Particulier",
  etat: "État",
  agefiph: "Agefiph",
  transition_pro: "Transitions Pro",
  autre: "Autre",
};

export const invoiceKindLabels: Record<InvoiceKind, string> = { facture: "Facture", avoir: "Avoir", acompte: "Facture d'acompte", proforma: "Pro forma" };

export const paymentMethodLabels: Record<string, string> = {
  virement: "Virement",
  cheque: "Chèque",
  cb: "Carte bancaire",
  prelevement: "Prélèvement",
  especes: "Espèces",
  compensation: "Compensation (avoir)",
  autre: "Autre",
};

/* ---------- Lignes et totaux ---------- */

export type LineInput = {
  label: string;
  description?: string | null;
  /** Quantité en millièmes (1000 = 1). */
  quantityMilli: number;
  unit: string;
  unitCents: number;
  /** Taux de TVA en points de base (2000 = 20 %). Ignoré si la facture est exonérée. */
  vatRateBp: number;
};

export type ComputedLine = LineInput & { totalHtCents: number; vatCents: number };

export type InvoiceTotals = { totalHtCents: number; vatCents: number; totalTtcCents: number; lines: ComputedLine[] };

/** Arrondi au centime le plus proche (demi vers le haut), sur des entiers : pas de flottant. */
function roundDiv(numerator: number, denominator: number): number {
  const sign = numerator < 0 ? -1 : 1;
  const n = Math.abs(numerator);
  return sign * Math.floor((n + denominator / 2) / denominator);
}

export function lineTotalHt(line: Pick<LineInput, "quantityMilli" | "unitCents">): number {
  return roundDiv(line.quantityMilli * line.unitCents, 1000);
}

/** Totaux d'une facture : HT par ligne, TVA par ligne (0 si exonération), TTC. Reproductible à l'identique. */
export function invoiceTotals(lines: LineInput[], vatExempt: boolean): InvoiceTotals {
  const computed = lines.map((l) => {
    const totalHtCents = lineTotalHt(l);
    const vatCents = vatExempt ? 0 : roundDiv(totalHtCents * l.vatRateBp, 10000);
    return { ...l, vatRateBp: vatExempt ? 0 : l.vatRateBp, totalHtCents, vatCents };
  });
  const totalHtCents = computed.reduce((a, l) => a + l.totalHtCents, 0);
  const vatCents = computed.reduce((a, l) => a + l.vatCents, 0);
  return { totalHtCents, vatCents, totalTtcCents: totalHtCents + vatCents, lines: computed };
}

/* ---------- Numérotation ---------- */

/** Famille de séquence : les avoirs ont leur propre compteur ; factures, acomptes et pro forma partagent celui des factures. */
export function sequenceKindFor(kind: InvoiceKind): "facture" | "avoir" | "proforma" {
  if (kind === "avoir") return "avoir";
  if (kind === "proforma") return "proforma";
  return "facture";
}

export function formatInvoiceNumber(kind: InvoiceKind, year: number, seq: number, prefixOverride?: string): string {
  if (!Number.isInteger(seq) || seq < 1) throw new Error("Numéro de séquence invalide.");
  const prefix = prefixOverride ?? (kind === "avoir" ? "AV" : kind === "proforma" ? "PRO" : "F");
  return `${prefix}-${year}-${String(seq).padStart(5, "0")}`;
}

/* ---------- Règlements ---------- */

/** Trop-perçu refusé : un règlement ne peut pas dépasser le solde restant dû. */
export function checkPaymentAmount(totalTtcCents: number, paidCents: number, amountCents: number): string | null {
  if (!Number.isInteger(amountCents) || amountCents <= 0) return "Le montant du règlement doit être un nombre positif.";
  const remaining = totalTtcCents - paidCents;
  if (remaining <= 0) return "Cette facture est déjà soldée : aucun règlement supplémentaire n'est possible.";
  if (amountCents > remaining) return `Trop-perçu refusé : le règlement (${(amountCents / 100).toFixed(2)} €) dépasse le solde restant dû (${(remaining / 100).toFixed(2)} €).`;
  return null;
}

/**
 * Statut de paiement recalculé à partir des règlements enregistrés.
 * Un brouillon ou une facture annulée ne change jamais ; un avoir n'est pas « payé ».
 */
export function paymentStatus(input: { kind: InvoiceKind; status: InvoiceStatus; totalTtcCents: number; paidCents: number; sentAt?: Date | null; overdue?: boolean }): InvoiceStatus {
  const { kind, status, totalTtcCents, paidCents } = input;
  if (status === "brouillon" || status === "annulee") return status;
  if (kind === "avoir" || kind === "proforma") return status === "payee" || status === "partiellement_payee" ? "emise" : status;
  if (totalTtcCents > 0 && paidCents >= totalTtcCents) return "payee";
  if (paidCents > 0) return "partiellement_payee";
  if (input.overdue) return "en_retard";
  if (status === "payee" || status === "partiellement_payee" || status === "en_retard") return input.sentAt ? "envoyee" : "emise";
  return status;
}

/** Vrai si la facture est en retard : échue, non soldée, non annulée, non brouillon. */
export function isOverdue(input: { status: InvoiceStatus; dueDate: string | null; totalTtcCents: number; paidCents: number; kind: InvoiceKind }, today: string): boolean {
  if (input.kind === "avoir" || input.kind === "proforma") return false;
  if (input.status === "brouillon" || input.status === "annulee" || input.status === "payee") return false;
  if (!input.dueDate) return false;
  return input.dueDate < today && input.paidCents < input.totalTtcCents;
}

/* ---------- Financements ---------- */

export type ScheduleLine = { label: string; dueDate: string; amountCents: number; invoiceId?: string | null };

const TRANSITIONS: Record<FundingStatus, FundingStatus[]> = {
  prevu: ["demande", "accorde", "refuse", "annule"],
  demande: ["accorde", "refuse", "prevu", "annule"],
  accorde: ["facture", "solde", "refuse", "annule"],
  refuse: ["prevu", "demande", "annule"],
  facture: ["solde", "annule"],
  solde: [],
  annule: ["prevu"],
};

export function allowedFundingTransitions(from: FundingStatus): FundingStatus[] {
  return TRANSITIONS[from] ?? [];
}

export type FundingAgreement = { agreementRef?: string | null; agreementSource?: string | null; validUntil?: string | null; validFrom?: string | null };

/**
 * Règle de passage « accordé » : référence de prise en charge, sa source et sa date de validité sont obligatoires.
 * Retourne un message d'erreur ou null.
 */
export function fundingTransitionError(from: FundingStatus, to: FundingStatus, data: FundingAgreement): string | null {
  if (from === to) return null;
  if (!allowedFundingTransitions(from).includes(to)) return `Passage de « ${from} » à « ${to} » impossible.`;
  if (to === "accorde" || to === "facture" || to === "solde") {
    const missing: string[] = [];
    if (!data.agreementRef?.trim()) missing.push("la référence de prise en charge");
    if (!data.agreementSource?.trim()) missing.push("la source de l'accord");
    if (!data.validUntil) missing.push("la date de fin de validité");
    if (missing.length) return `Le passage à « accordé » exige ${missing.join(", ")}.`;
    if (data.validFrom && data.validUntil && data.validFrom > data.validUntil) return "La date de début de validité doit précéder la date de fin.";
  }
  return null;
}

/** L'échéancier doit totaliser exactement le montant du financement (ou être vide). */
export function validateSchedule(schedule: ScheduleLine[], amountCents: number): string | null {
  if (!schedule.length) return null;
  for (const [i, l] of schedule.entries()) {
    if (!l.label?.trim()) return `Échéance ${i + 1} : libellé manquant.`;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(l.dueDate ?? "")) return `Échéance ${i + 1} : date invalide.`;
    if (!Number.isInteger(l.amountCents) || l.amountCents <= 0) return `Échéance ${i + 1} : montant invalide.`;
  }
  const sum = schedule.reduce((a, l) => a + l.amountCents, 0);
  if (sum !== amountCents) return `L'échéancier totalise ${(sum / 100).toFixed(2)} € alors que le financement est de ${(amountCents / 100).toFixed(2)} €.`;
  return null;
}

/** Échéances dépassées sans facture rattachée. */
export function overdueScheduleLines(schedule: ScheduleLine[], today: string): ScheduleLine[] {
  return schedule.filter((l) => !l.invoiceId && l.dueDate < today);
}

/** Prochaine échéance non facturée (la plus proche), ou null. */
export function nextScheduleLine(schedule: ScheduleLine[]): ScheduleLine | null {
  const open = schedule.filter((l) => !l.invoiceId).sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  return open[0] ?? null;
}

/**
 * État de financement de l'inscription, dérivé de ses financements. Jamais modifié par la clôture pédagogique.
 * - aucun financement actif : à définir ; tous refusés : refusé ; tous soldés : soldé ;
 * - au moins un facturé : facturé ; au moins un accordé : accordé ; sinon prévu.
 */
export function deriveFundingState(fundings: { status: FundingStatus }[]): FundingState {
  const active = fundings.filter((f) => f.status !== "annule");
  if (!active.length) return "a_definir";
  const notRefused = active.filter((f) => f.status !== "refuse");
  if (!notRefused.length) return "refuse";
  if (notRefused.every((f) => f.status === "solde")) return "solde";
  if (notRefused.some((f) => f.status === "facture" || f.status === "solde")) return "facture";
  if (notRefused.some((f) => f.status === "accorde")) return "accorde";
  return "prevu";
}

/* ---------- Export comptable ---------- */

export type AccountingSettings = { salesAccount: string; customerAccount: string; vatAccount: string; journal: string };
export const DEFAULT_ACCOUNTING: AccountingSettings = { salesAccount: "706000", customerAccount: "411000", vatAccount: "445710", journal: "VE" };

export function accountingSettingsFrom(settings: unknown): AccountingSettings {
  const a = (settings as { accounting?: Partial<AccountingSettings> } | null)?.accounting ?? {};
  return {
    salesAccount: a.salesAccount?.trim() || DEFAULT_ACCOUNTING.salesAccount,
    customerAccount: a.customerAccount?.trim() || DEFAULT_ACCOUNTING.customerAccount,
    vatAccount: a.vatAccount?.trim() || DEFAULT_ACCOUNTING.vatAccount,
    journal: a.journal?.trim() || DEFAULT_ACCOUNTING.journal,
  };
}

export type JournalRow = { date: string; piece: string; compte: string; libelle: string; debit: number; credit: number };

/** Écritures du journal des ventes pour une facture (débit 411 TTC, crédit 706 HT, crédit 445 TVA) ; un avoir est inversé. */
export function salesJournalRows(
  inv: { number: string; kind: InvoiceKind; issueDate: string; totalHtCents: number; vatCents: number; totalTtcCents: number; billToName: string },
  acc: AccountingSettings,
): JournalRow[] {
  const credit = inv.kind === "avoir";
  const lbl = `${inv.number} ${inv.billToName}`.trim();
  const rows: JournalRow[] = [];
  rows.push({ date: inv.issueDate, piece: inv.number, compte: acc.customerAccount, libelle: lbl, debit: credit ? 0 : inv.totalTtcCents, credit: credit ? inv.totalTtcCents : 0 });
  rows.push({ date: inv.issueDate, piece: inv.number, compte: acc.salesAccount, libelle: lbl, debit: credit ? inv.totalHtCents : 0, credit: credit ? 0 : inv.totalHtCents });
  if (inv.vatCents) rows.push({ date: inv.issueDate, piece: inv.number, compte: acc.vatAccount, libelle: lbl, debit: credit ? inv.vatCents : 0, credit: credit ? 0 : inv.vatCents });
  return rows;
}

/* ---------- CSV ---------- */

export function csvEscape(v: string | number | null | undefined): string {
  const s = v === null || v === undefined ? "" : String(v);
  return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function toCsv(header: string[], rows: (string | number | null | undefined)[][]): string {
  return [header, ...rows].map((r) => r.map(csvEscape).join(";")).join("\r\n") + "\r\n";
}

export function centsToDecimal(c: number): string {
  return (c / 100).toFixed(2).replace(".", ",");
}

/** Valeur d'un champ de saisie en euros (« 1250,00 ») à partir de centimes. */
export function centsToInput(c: number): string {
  return (c / 100).toFixed(2).replace(".", ",");
}

/** Analyse « 1 234,56 » ou « 1234.56 » en centimes ; null si illisible. */
export function parseAmountToCents(raw: string): number | null {
  const s = raw.replace(/\s| |€/g, "").replace(",", ".");
  if (!/^-?\d+(\.\d{1,2})?$/.test(s)) return null;
  const [int, dec = ""] = s.replace("-", "").split(".");
  const cents = Number(int) * 100 + Number((dec + "00").slice(0, 2));
  return s.startsWith("-") ? -cents : cents;
}

/* ---------- Relevé bancaire ---------- */

export type BankRow = { line: number; date: string; label: string; amountCents: number; reference: string };

/** Lit un relevé CSV (séparateur ; , ou tabulation ; colonnes date, libellé, montant, référence détectées par en-tête ou par position). */
export function parseBankCsv(text: string): { rows: BankRow[]; errors: string[] } {
  const lines = text.replace(/^﻿/, "").split(/\r?\n/).filter((l) => l.trim());
  const errors: string[] = [];
  if (!lines.length) return { rows: [], errors: ["Fichier vide."] };
  const sep = [";", ",", "\t"].sort((a, b) => lines[0].split(b).length - lines[0].split(a).length)[0];
  const split = (l: string) => {
    const out: string[] = [];
    let cur = "";
    let q = false;
    for (let i = 0; i < l.length; i++) {
      const c = l[i];
      if (c === '"') {
        if (q && l[i + 1] === '"') {
          cur += '"';
          i++;
        } else q = !q;
      } else if (c === sep && !q) {
        out.push(cur);
        cur = "";
      } else cur += c;
    }
    out.push(cur);
    return out.map((s) => s.trim());
  };
  const header = split(lines[0]).map((h) => h.toLowerCase());
  const find = (...names: string[]) => header.findIndex((h) => names.some((n) => h.includes(n)));
  let iDate = find("date");
  let iLabel = find("libell", "label", "description", "motif");
  let iAmount = find("montant", "amount", "credit", "crédit");
  let iRef = find("réf", "ref");
  const hasHeader = iDate >= 0 || iAmount >= 0;
  if (!hasHeader) {
    iDate = 0;
    iLabel = 1;
    iAmount = 2;
    iRef = 3;
  }
  const rows: BankRow[] = [];
  lines.slice(hasHeader ? 1 : 0).forEach((l, idx) => {
    const cells = split(l);
    const n = idx + (hasHeader ? 2 : 1);
    const date = normalizeDate(cells[iDate] ?? "");
    const amount = parseAmountToCents(cells[iAmount] ?? "");
    if (!date || amount === null) {
      errors.push(`Ligne ${n} ignorée : date ou montant illisible.`);
      return;
    }
    rows.push({ line: n, date, label: cells[iLabel] ?? "", amountCents: amount, reference: iRef >= 0 ? (cells[iRef] ?? "") : "" });
  });
  return { rows, errors };
}

/** « 31/12/2026 », « 2026-12-31 » ou « 31-12-2026 » en ISO. */
export function normalizeDate(raw: string): string | null {
  const s = raw.trim();
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = s.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/);
  if (m) return `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  return null;
}

export type MatchCandidate = { id: string; number: string; totalTtcCents: number; paidCents: number; billToName: string };
export type MatchProposal = { row: BankRow; invoice: MatchCandidate | null; confidence: "reference" | "montant" | "aucune"; reason: string };

/** Proposition de rapprochement : référence (numéro de facture dans le libellé) prioritaire, sinon montant exact du solde. Validation humaine obligatoire. */
export function proposeMatches(rows: BankRow[], invoices: MatchCandidate[]): MatchProposal[] {
  const used = new Set<string>();
  return rows.map((row) => {
    if (row.amountCents <= 0) return { row, invoice: null, confidence: "aucune", reason: "Débit : non concerné par les ventes." };
    const hay = `${row.label} ${row.reference}`.toUpperCase();
    const byRef = invoices.find((i) => !used.has(i.id) && hay.includes(i.number.toUpperCase()));
    if (byRef) {
      used.add(byRef.id);
      return { row, invoice: byRef, confidence: "reference", reason: `Numéro ${byRef.number} présent dans le libellé.` };
    }
    const byAmount = invoices.filter((i) => !used.has(i.id) && i.totalTtcCents - i.paidCents === row.amountCents);
    if (byAmount.length === 1) {
      used.add(byAmount[0].id);
      return { row, invoice: byAmount[0], confidence: "montant", reason: "Montant égal au solde restant dû (à vérifier)." };
    }
    if (byAmount.length > 1) return { row, invoice: null, confidence: "aucune", reason: `${byAmount.length} factures ont ce solde : choisir manuellement.` };
    return { row, invoice: null, confidence: "aucune", reason: "Aucune facture ouverte ne correspond." };
  });
}
