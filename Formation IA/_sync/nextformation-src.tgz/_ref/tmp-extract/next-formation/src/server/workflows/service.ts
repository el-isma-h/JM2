import "server-only";
import { and, eq, inArray, like, ne } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { recordEvidence } from "@/server/quality/evidence";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { todayParis } from "@/lib/time";
import { computeDueDate, delayLabel } from "./calendar";
import { applicableSteps, getStep, getWorkflow, pickWorkflowCode, stepHref, workflowTaskKey, type WorkflowCode, type WorkflowStep, type WorkflowTemplate } from "./templates";

/**
 * Parcours automatiques de financement : application à une inscription (une tâche de relais par étape,
 * clé `wf:<enrollmentId>:<stepCode>`), passage d'une étape à « faite » par un humain, avancement.
 * Le système ne marque jamais une étape faite de lui-même : il crée et relance des tâches.
 */

export type WorkflowActor = { orgId: string; userId: string | null };

type Enrollment = typeof schema.enrollments.$inferSelect;
type Task = typeof schema.tasks.$inferSelect;
type StepPrerequisite = { label: string; done: boolean; kind: "decision"; step: string };

const OPEN_STATUSES = ["a_faire", "en_cours", "bloquee"] as const;

async function loadContext(orgId: string, enrollmentId: string) {
  const [row] = await db
    .select({ e: schema.enrollments, s: schema.trainingSessions, p: schema.persons, certificationId: schema.programs.certificationId })
    .from(schema.enrollments)
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .leftJoin(schema.programVersions, eq(schema.programVersions.id, schema.enrollments.programVersionId))
    .leftJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)))
    .limit(1);
  if (!row) return null;
  const fundings = await db
    .select({ kind: schema.fundings.kind })
    .from(schema.fundings)
    .where(and(eq(schema.fundings.orgId, orgId), eq(schema.fundings.enrollmentId, enrollmentId), ne(schema.fundings.status, "annule")));
  const fundingKinds = fundings.map((f) => f.kind as string);
  const flags = { certification: Boolean(row.certificationId) || row.e.examState !== "non_concerne", opco: fundingKinds.includes("opco") };
  return { ...row, fundingKinds, flags };
}

async function workflowTasks(orgId: string, enrollmentId: string): Promise<Map<string, Task>> {
  const prefix = workflowTaskKey(enrollmentId, "");
  const rows = await db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, orgId), like(schema.tasks.idempotencyKey, `${prefix}%`)));
  const map = new Map<string, Task>();
  for (const t of rows) if (t.idempotencyKey) map.set(t.idempotencyKey.slice(prefix.length), t);
  return map;
}

/** Échéances de toutes les étapes applicables, calculées à partir des dates du parcours (inscription, sinon session). */
export function plannedDueDates(steps: WorkflowStep[], e: Pick<Enrollment, "createdAt" | "startDate" | "endDate">, s: { startDate: string; endDate: string }): Map<string, string> {
  const anchors = { inscription: todayParis(e.createdAt), debut: e.startDate ?? s.startDate, fin: e.endDate ?? s.endDate };
  const out = new Map<string, string>();
  let previous: string | null = null;
  for (const step of steps) {
    const due = computeDueDate(step.delay, { ...anchors, precedente: previous });
    out.set(step.code, due);
    previous = due;
  }
  return out;
}

function prerequisitesFor(step: WorkflowStep, applicable: Map<string, WorkflowStep>, done: Set<string>): StepPrerequisite[] {
  return step.prerequisites
    .filter((c) => applicable.has(c))
    .map((c) => ({ label: `Étape : ${applicable.get(c)!.label}`, done: done.has(c), kind: "decision" as const, step: c }));
}

/**
 * Applique un parcours à une inscription. Sans `code`, le parcours est choisi d'après le contrat, la session
 * et les financements connus ; si rien ne permet de trancher, rien n'est appliqué (choix humain).
 * Idempotent : une étape déjà créée n'est jamais dupliquée ; une étape annulée par un changement de parcours
 * est rouverte si le nouveau parcours la comporte ; les étapes ouvertes absentes du nouveau parcours sont annulées.
 */
export async function applyWorkflow(actor: WorkflowActor, enrollmentId: string, code?: WorkflowCode | null) {
  const c = await loadContext(actor.orgId, enrollmentId);
  if (!c) throw new Error("Inscription introuvable dans cet organisme.");
  const { e, s, p } = c;
  const chosen = code ?? pickWorkflowCode({ contractKind: e.contractKind, isApprenticeship: s.isApprenticeship, fundingKinds: c.fundingKinds, companyId: e.companyId });
  if (!chosen) return { applied: false as const, reason: "Aucun financement ni contrat ne permet de choisir le parcours : choisissez-le sur le dossier." };
  const template = getWorkflow(chosen)!;
  const steps = applicableSteps(template, c.flags);
  const applicable = new Map(steps.map((x) => [x.code, x]));
  const dues = plannedDueDates(steps, e, s);
  const existing = await workflowTasks(actor.orgId, e.id);
  const done = new Set([...existing].filter(([, t]) => t.status === "terminee").map(([k]) => k));
  const personLabel = `${p.firstName} ${p.lastName}`;
  const ids = { orgId: actor.orgId, enrollmentId: e.id, sessionId: s.id };

  let created = 0;
  let reopened = 0;
  for (const step of steps) {
    const key = workflowTaskKey(e.id, step.code);
    const prerequisites = prerequisitesFor(step, applicable, done);
    const prev = existing.get(step.code);
    if (prev?.status === "annulee") {
      await db
        .update(schema.tasks)
        .set({ status: "a_faire", dueDate: dues.get(step.code) ?? null, prerequisites, completedAt: null, completedBy: null, resolutionNote: null })
        .where(eq(schema.tasks.id, prev.id));
      await db.insert(schema.taskEvents).values({ taskId: prev.id, kind: "statut", fromValue: "annulee", toValue: "a_faire", note: `Parcours « ${template.label} » appliqué`, userId: actor.userId });
      reopened++;
      continue;
    }
    if (prev) continue;
    const r = await createTaskOnce({
      orgId: actor.orgId,
      title: `${step.label} (${personLabel})`,
      description: [step.description, `Parcours : ${template.label}. Délai : ${delayLabel(step.delay)}.`].filter(Boolean).join("\n"),
      family: step.family,
      entityType: "enrollment",
      entityId: e.id,
      entityLabel: `${e.reference} · ${personLabel}`,
      href: stepHref(step, ids),
      assigneeRole: step.role,
      assigneeUserId: step.role === "admin_staff" ? s.adminManagerUserId : step.role === "pedagogy_manager" ? s.pedagogyManagerUserId : null,
      dueDate: dues.get(step.code) ?? null,
      prerequisites,
      indicatorCode: step.evidence?.indicatorCode ?? null,
      createdBy: actor.userId,
      source: "parcours",
      isDemo: e.isDemo,
      idempotencyKey: key,
    });
    if (r.created) created++;
  }

  // Étapes ouvertes de l'ancien parcours absentes du nouveau : annulées (jamais supprimées), motif conservé.
  let cancelled = 0;
  for (const [stepCode, t] of existing) {
    if (applicable.has(stepCode) || !(OPEN_STATUSES as readonly string[]).includes(t.status)) continue;
    await db.update(schema.tasks).set({ status: "annulee", resolutionNote: `Étape absente du parcours « ${template.label} »` }).where(eq(schema.tasks.id, t.id));
    await db.insert(schema.taskEvents).values({ taskId: t.id, kind: "statut", fromValue: t.status, toValue: "annulee", note: `Parcours remplacé par « ${template.label} »`, userId: actor.userId });
    cancelled++;
  }

  if (e.workflowCode !== chosen) {
    await db.update(schema.enrollments).set({ workflowCode: chosen }).where(and(eq(schema.enrollments.id, e.id), eq(schema.enrollments.orgId, actor.orgId)));
    await db.insert(schema.enrollmentEvents).values({ enrollmentId: e.id, kind: "parcours", fromValue: e.workflowCode, toValue: chosen, reason: `Parcours « ${template.label} » appliqué${code ? "" : " automatiquement"}.`, userId: actor.userId });
  }
  await audit({ action: "workflow.apply", userId: actor.userId, orgId: actor.orgId, entityType: "enrollment", entityId: e.id, before: { workflowCode: e.workflowCode }, after: { workflowCode: chosen, created, reopened, cancelled } });
  return { applied: true as const, code: chosen, created, reopened, cancelled, steps: steps.length };
}

/**
 * Marque une étape faite (action humaine) : résout sa tâche, met à jour les champs EDOF / Kairos / e-learning
 * de l'inscription, coche le prérequis dans les étapes suivantes et enregistre la preuve qualité prévue.
 * Des prérequis non faits exigent un motif de dérogation (`override`), conservé avec son auteur.
 */
export async function completeWorkflowStep(orgId: string, enrollmentId: string, stepCode: string, userId: string | null, opts: { note?: string | null; override?: string | null } = {}) {
  const c = await loadContext(orgId, enrollmentId);
  if (!c) throw new Error("Inscription introuvable dans cet organisme.");
  const { e, s } = c;
  const template = getWorkflow(e.workflowCode);
  if (!template) throw new Error("Aucun parcours n'est appliqué à cette inscription.");
  const step = getStep(template.code, stepCode);
  if (!step) throw new Error("Étape inconnue pour ce parcours.");
  const steps = applicableSteps(template, c.flags);
  const applicable = new Map(steps.map((x) => [x.code, x]));
  if (!applicable.has(step.code)) throw new Error("Cette étape ne concerne pas cette inscription.");

  const tasks = await workflowTasks(orgId, e.id);
  const key = workflowTaskKey(e.id, step.code);
  let task = tasks.get(step.code);
  if (task?.status === "terminee") return { already: true as const, step };
  if (!task || task.status === "annulee") {
    await applyWorkflow({ orgId, userId }, e.id, template.code);
    task = (await workflowTasks(orgId, e.id)).get(step.code);
    if (!task) throw new Error("Tâche de l'étape introuvable.");
  }

  const pending = step.prerequisites.filter((p) => applicable.has(p) && tasks.get(p)?.status !== "terminee");
  const override = opts.override?.trim() || null;
  if (pending.length && !override) {
    throw new Error(`Prérequis non faits : ${pending.map((p) => applicable.get(p)!.label).join(", ")}. Indiquez un motif de dérogation pour passer outre.`);
  }
  const note = [opts.note?.trim(), override ? `Dérogation aux prérequis (${pending.join(", ")}) : ${override}` : null].filter(Boolean).join(" · ") || `Étape « ${step.label} » faite`;
  await resolveTaskByKey(orgId, key, note, userId);

  // Effets sur l'inscription (EDOF, Kairos, e-learning) : uniquement ceux prévus par l'étape.
  const today = todayParis();
  const set: Partial<Enrollment> = {};
  if (step.effect?.edofStatus) set.edofStatus = step.effect.edofStatus;
  if (step.effect?.edofEntry) set.edofEntryAt = today;
  if (step.effect?.edofExit) set.edofExitAt = today;
  if (step.effect?.kairosStatus) set.kairosStatus = step.effect.kairosStatus;
  if (step.effect?.elearningAccessSent) set.elearningAccessSentAt = new Date();
  if (Object.keys(set).length) {
    await db.update(schema.enrollments).set(set).where(and(eq(schema.enrollments.id, e.id), eq(schema.enrollments.orgId, orgId)));
  }
  await db.insert(schema.enrollmentEvents).values({ enrollmentId: e.id, kind: "parcours_etape", fromValue: task.status, toValue: step.code, reason: note, userId });

  // Les étapes qui attendaient celle-ci voient leur prérequis coché.
  const dependents = steps.filter((x) => x.prerequisites.includes(step.code)).map((x) => tasks.get(x.code)).filter((t): t is Task => Boolean(t));
  for (const t of dependents) {
    const list = Array.isArray(t.prerequisites) ? (t.prerequisites as Record<string, unknown>[]) : [];
    const next = list.map((pr) => (pr && typeof pr === "object" && pr.step === step.code ? { ...pr, done: true } : pr));
    await db.update(schema.tasks).set({ prerequisites: next }).where(eq(schema.tasks.id, t.id));
  }

  let evidenceId: string | null = null;
  if (step.evidence) {
    const r = await recordEvidence({
      orgId,
      indicatorCode: step.evidence.indicatorCode,
      level: "individuel",
      title: step.evidence.title,
      note,
      evidenceDate: today,
      sourceType: "workflow_step",
      sourceId: task.id,
      enrollmentId: e.id,
      sessionId: s.id,
      createdBy: userId,
    });
    evidenceId = r.id;
  }
  await audit({ action: "workflow.step_complete", userId, orgId, entityType: "enrollment", entityId: e.id, before: { status: task.status }, after: { step: step.code, ...set, override: override ?? undefined, evidenceId } });
  return { already: false as const, step, effects: set, evidenceId };
}

export type WorkflowStepProgress = {
  code: string;
  label: string;
  description: string | null;
  role: string;
  delay: string;
  dueDate: string | null;
  status: "a_faire" | "en_cours" | "bloquee" | "terminee" | "annulee" | "absente";
  late: boolean;
  href: string;
  taskId: string | null;
  completedAt: Date | null;
  resolutionNote: string | null;
  prerequisites: { code: string; label: string; done: boolean }[];
  source: WorkflowStep["source"];
};

export type WorkflowProgress = {
  code: WorkflowCode | null;
  template: Pick<WorkflowTemplate, "code" | "label" | "description"> | null;
  suggested: WorkflowCode | null;
  steps: WorkflowStepProgress[];
  done: number;
  total: number;
  late: number;
  next: WorkflowStepProgress | null;
  enrollment: Pick<Enrollment, "edofStatus" | "edofEntryAt" | "edofExitAt" | "kairosStatus" | "kairosDevisRef" | "elearningAccessSentAt" | "elearningFirstLoginAt">;
};

/** Avancement du parcours d'une inscription (étapes, statut de leur tâche, échéance, retard). */
export async function workflowProgress(orgId: string, enrollmentId: string): Promise<WorkflowProgress | null> {
  const c = await loadContext(orgId, enrollmentId);
  if (!c) return null;
  const { e, s } = c;
  const suggested = pickWorkflowCode({ contractKind: e.contractKind, isApprenticeship: s.isApprenticeship, fundingKinds: c.fundingKinds, companyId: e.companyId });
  const enrollment = {
    edofStatus: e.edofStatus,
    edofEntryAt: e.edofEntryAt,
    edofExitAt: e.edofExitAt,
    kairosStatus: e.kairosStatus,
    kairosDevisRef: e.kairosDevisRef,
    elearningAccessSentAt: e.elearningAccessSentAt,
    elearningFirstLoginAt: e.elearningFirstLoginAt,
  };
  const template = getWorkflow(e.workflowCode);
  if (!template) return { code: null, template: null, suggested, steps: [], done: 0, total: 0, late: 0, next: null, enrollment };
  const steps = applicableSteps(template, c.flags);
  const applicable = new Map(steps.map((x) => [x.code, x]));
  const planned = plannedDueDates(steps, e, s);
  const tasks = await workflowTasks(orgId, e.id);
  const today = todayParis();
  const ids = { orgId, enrollmentId: e.id, sessionId: s.id };
  const list: WorkflowStepProgress[] = steps.map((step) => {
    const t = tasks.get(step.code);
    const status = (t?.status ?? "absente") as WorkflowStepProgress["status"];
    const dueDate = t?.dueDate ?? planned.get(step.code) ?? null;
    return {
      code: step.code,
      label: step.label,
      description: step.description ?? null,
      role: step.role,
      delay: delayLabel(step.delay),
      dueDate,
      status,
      late: Boolean(dueDate && dueDate < today && (OPEN_STATUSES as readonly string[]).includes(status)),
      href: t?.href ?? stepHref(step, ids),
      taskId: t?.id ?? null,
      completedAt: t?.completedAt ?? null,
      resolutionNote: t?.resolutionNote ?? null,
      prerequisites: step.prerequisites.filter((p) => applicable.has(p)).map((p) => ({ code: p, label: applicable.get(p)!.label, done: tasks.get(p)?.status === "terminee" })),
      source: step.source,
    };
  });
  const done = list.filter((x) => x.status === "terminee").length;
  return {
    code: template.code,
    template: { code: template.code, label: template.label, description: template.description },
    suggested,
    steps: list,
    done,
    total: list.length,
    late: list.filter((x) => x.late).length,
    next: list.find((x) => x.status !== "terminee" && x.status !== "annulee") ?? null,
    enrollment,
  };
}

/** Tâches de parcours ouvertes et échues (échéance strictement passée), tous organismes ou un seul. */
export async function overdueWorkflowTasks(orgId: string | null, today = todayParis()) {
  const rows = await db
    .select({ id: schema.tasks.id, orgId: schema.tasks.orgId, title: schema.tasks.title, dueDate: schema.tasks.dueDate, href: schema.tasks.href, assigneeUserId: schema.tasks.assigneeUserId, assigneeRole: schema.tasks.assigneeRole })
    .from(schema.tasks)
    .where(and(like(schema.tasks.idempotencyKey, "wf:%"), inArray(schema.tasks.status, [...OPEN_STATUSES]), eq(schema.tasks.isDemo, false), orgId ? eq(schema.tasks.orgId, orgId) : undefined));
  return rows.filter((t) => t.dueDate && t.dueDate < today);
}
