"use server";

import { revalidatePath } from "next/cache";
import { and, eq, inArray, isNull, ne, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { todayParis } from "@/lib/time";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { notify } from "@/server/notify";
import { createDocument } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { recordEvidence } from "@/server/quality/evidence";
import { runAnalysis } from "@/server/quality/analysis";
import { parseCriteria, QUALIOPI_RNQ } from "@/server/quality/referential-data";
import { watchKindIndicator } from "@/server/quality/labels";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const optUuid = z.string().uuid().optional().or(z.literal("")).transform((v) => (v ? v : null));
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide (AAAA-MM-JJ)");
const INDICATOR = z.string().regex(/^IND_([1-9]|[12][0-9]|3[0-2])$/, "Indicateur invalide (IND_1 à IND_32)");
const LEVEL = z.enum(["individuel", "collectif", "organisationnel"], { message: "Niveau de preuve invalide" });

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}
const str = (fd: FormData, key: string, max = 2000) => {
  const v = String(fd.get(key) ?? "").trim();
  return v ? v.slice(0, max) : null;
};
const base = (orgId: string) => `/app/${orgId}/qualite`;

async function manage(formData: FormData): Promise<OrgContext> {
  const orgId = uuid.parse(formData.get("orgId"));
  return requireOrg(orgId, "quality.view", "quality.manage");
}

// ---------------------------------------------------------------------------
// Référentiel (copie, édition, validation humaine, retrait)
// ---------------------------------------------------------------------------

/** Copie le référentiel plateforme dans l'organisme (brouillon) : rien n'est applicable avant validation humaine. */
export async function copyPlatformReferentialAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const [platform] = await db
      .select()
      .from(schema.referentials)
      .where(and(isNull(schema.referentials.orgId), eq(schema.referentials.code, QUALIOPI_RNQ.code)))
      .orderBy(schema.referentials.createdAt)
      .limit(1);
    const source = platform ?? { code: QUALIOPI_RNQ.code, title: QUALIOPI_RNQ.title, version: QUALIOPI_RNQ.version, source: QUALIOPI_RNQ.source, sourceUrl: QUALIOPI_RNQ.sourceUrl, scope: QUALIOPI_RNQ.scope, criteria: QUALIOPI_RNQ.criteria };
    const [draft] = await db.select({ id: schema.referentials.id }).from(schema.referentials).where(and(eq(schema.referentials.orgId, ctx.org.id), eq(schema.referentials.status, "brouillon"))).limit(1);
    if (draft) return { error: "Un brouillon existe déjà : complétez-le ou retirez-le avant d'en créer un autre." };
    const [row] = await db
      .insert(schema.referentials)
      .values({
        orgId: ctx.org.id,
        code: source.code,
        title: source.title,
        version: "",
        source: source.source,
        sourceUrl: source.sourceUrl,
        scope: ctx.org.kind === "of_cfa" ? "both" : ctx.org.kind,
        status: "brouillon",
        criteria: source.criteria,
      })
      .returning({ id: schema.referentials.id });
    await audit({ action: "quality.referential.copy", userId: ctx.user.id, orgId: ctx.org.id, entityType: "referential", entityId: row.id, after: { from: platform?.id ?? "code", code: source.code } });
    revalidatePath(`${base(ctx.org.id)}/referentiel`);
    return { ok: true, message: "Référentiel copié en brouillon. Vérifiez les textes, saisissez la version et les dates d'effet, puis validez." };
  } catch (e) {
    return fail(e, "Copie impossible.");
  }
}

const refSchema = z.object({
  referentialId: uuid,
  version: z.string().trim().max(80),
  source: z.string().trim().max(300).optional().or(z.literal("")),
  effectiveFrom: isoDate.optional().or(z.literal("")),
  effectiveTo: isoDate.optional().or(z.literal("")),
  scope: z.enum(["of", "cfa", "both"]),
});

export async function updateReferentialAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const d = refSchema.parse(Object.fromEntries(formData));
    const [ref] = await db.select().from(schema.referentials).where(and(eq(schema.referentials.id, d.referentialId), eq(schema.referentials.orgId, ctx.org.id))).limit(1);
    if (!ref) return { error: "Référentiel introuvable." };
    if (ref.status !== "brouillon") return { error: "Seul un brouillon est modifiable : un référentiel validé est figé (retirez-le et copiez-en un nouveau)." };
    if (d.effectiveFrom && d.effectiveTo && d.effectiveTo < d.effectiveFrom) return { error: "La date de fin d'effet précède la date de début." };
    const before = { version: ref.version, source: ref.source, effectiveFrom: ref.effectiveFrom, effectiveTo: ref.effectiveTo, scope: ref.scope };
    const after = { version: d.version, source: d.source || ref.source, effectiveFrom: d.effectiveFrom || null, effectiveTo: d.effectiveTo || null, scope: d.scope };
    await db.update(schema.referentials).set(after).where(eq(schema.referentials.id, ref.id));
    await audit({ action: "quality.referential.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "referential", entityId: ref.id, before, after });
    revalidatePath(`${base(ctx.org.id)}/referentiel`);
    return { ok: true, message: "Référentiel enregistré (toujours en brouillon)." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Validation humaine : version, dates d'effet et périmètre vérifiés par un responsable habilité. Le précédent référentiel actif est retiré. */
export async function validateReferentialAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const referentialId = uuid.parse(formData.get("referentialId"));
    if (formData.get("attest") !== "on") return { error: "Cochez l'attestation de vérification des textes et des dates d'effet." };
    const [ref] = await db.select().from(schema.referentials).where(and(eq(schema.referentials.id, referentialId), eq(schema.referentials.orgId, ctx.org.id))).limit(1);
    if (!ref) return { error: "Référentiel introuvable." };
    if (ref.status !== "brouillon") return { error: "Ce référentiel n'est pas en brouillon." };
    if (!ref.version.trim()) return { error: "Saisissez la version du guide de lecture appliquée (ex. celle indiquée sur le site du ministère) avant de valider." };
    if (!ref.effectiveFrom) return { error: "Saisissez la date de début d'effet avant de valider." };
    if (!parseCriteria(ref.criteria).length) return { error: "Le référentiel ne contient aucun critère." };
    const today = todayParis();
    const status = ref.effectiveFrom <= today ? "actif" : "valide";
    const retired = await db
      .update(schema.referentials)
      .set({ status: "retire" })
      .where(and(eq(schema.referentials.orgId, ctx.org.id), inArray(schema.referentials.status, ["actif", "valide"]), ne(schema.referentials.id, ref.id)))
      .returning({ id: schema.referentials.id });
    await db.update(schema.referentials).set({ status, validatedBy: ctx.user.id, validatedAt: new Date() }).where(eq(schema.referentials.id, ref.id));
    await audit({ action: "quality.referential.validate", userId: ctx.user.id, orgId: ctx.org.id, entityType: "referential", entityId: ref.id, before: { status: ref.status }, after: { status, version: ref.version, effectiveFrom: ref.effectiveFrom, effectiveTo: ref.effectiveTo, scope: ref.scope, retired: retired.map((r) => r.id) } });
    revalidatePath(base(ctx.org.id));
    revalidatePath(`${base(ctx.org.id)}/referentiel`);
    return { ok: true, message: status === "actif" ? `Référentiel validé et applicable depuis le ${ref.effectiveFrom}.${retired.length ? " Le référentiel précédent a été retiré." : ""}` : `Référentiel validé ; il deviendra applicable le ${ref.effectiveFrom}.` };
  } catch (e) {
    return fail(e, "Validation impossible.");
  }
}

export async function retireReferentialAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const referentialId = uuid.parse(formData.get("referentialId"));
    const reason = str(formData, "reason", 500);
    const [ref] = await db.select().from(schema.referentials).where(and(eq(schema.referentials.id, referentialId), eq(schema.referentials.orgId, ctx.org.id))).limit(1);
    if (!ref) return { error: "Référentiel introuvable." };
    if (ref.status === "retire") return { error: "Déjà retiré." };
    await db.update(schema.referentials).set({ status: "retire", effectiveTo: ref.effectiveTo ?? todayParis() }).where(eq(schema.referentials.id, ref.id));
    await audit({ action: "quality.referential.retire", userId: ctx.user.id, orgId: ctx.org.id, entityType: "referential", entityId: ref.id, before: { status: ref.status }, after: { status: "retire", reason } });
    revalidatePath(base(ctx.org.id));
    revalidatePath(`${base(ctx.org.id)}/referentiel`);
    return { ok: true, message: "Référentiel retiré. Les analyses passées restent inchangées." };
  } catch (e) {
    return fail(e, "Retrait impossible.");
  }
}

// ---------------------------------------------------------------------------
// Analyses (photographies immuables)
// ---------------------------------------------------------------------------

export async function runAnalysisAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const scope = z.enum(["organisme", "session", "inscription", "programme"]).parse(formData.get("scope") ?? "organisme");
    const scopeId = scope === "organisme" ? null : uuid.parse(formData.get("scopeId"));
    const referenceDate = str(formData, "referenceDate", 10) ?? todayParis();
    isoDate.parse(referenceDate);
    if (referenceDate > todayParis()) return { error: "La date de référence ne peut pas être dans le futur : le système n'anticipe jamais une preuve." };
    const r = await runAnalysis(ctx, scope, scopeId, referenceDate);
    revalidatePath(base(ctx.org.id));
    revalidatePath(`${base(ctx.org.id)}/analyses/${r.analysis.id}`);
    if (scope === "inscription" && scopeId) revalidatePath(`/app/${ctx.org.id}/inscriptions/${scopeId}`);
    if (scope === "session" && scopeId) revalidatePath(`/app/${ctx.org.id}/sessions/${scopeId}`);
    const s = r.result.summary;
    return {
      ok: true,
      message: `Analyse enregistrée (moteur ${r.result.engineVersion}, date de référence ${referenceDate}) : ${s.proven} prouvé(s), ${s.missing} absent(s), ${s.humanReview} à examiner, ${s.notApplicable} non applicable(s).${r.tasksCreated ? ` ${r.tasksCreated} tâche(s) créée(s).` : ""}${r.tasksResolved ? ` ${r.tasksResolved} tâche(s) résolue(s).` : ""}`,
      data: { analysisId: r.analysis.id },
    };
  } catch (e) {
    return fail(e, "Analyse impossible.");
  }
}

// ---------------------------------------------------------------------------
// Preuves (ajout relié à une action réelle, invalidation, remplacement : jamais de suppression)
// ---------------------------------------------------------------------------

async function checkLinks(ctx: OrgContext, d: { sessionId: string | null; enrollmentId: string | null; programId: string | null; documentId: string | null }) {
  if (d.sessionId) {
    const [s] = await db.select({ id: schema.trainingSessions.id }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, d.sessionId), eq(schema.trainingSessions.orgId, ctx.org.id))).limit(1);
    if (!s) throw new Error("Session introuvable dans cet organisme.");
  }
  if (d.enrollmentId) {
    const [e] = await db.select({ id: schema.enrollments.id, sessionId: schema.enrollments.sessionId }).from(schema.enrollments).where(and(eq(schema.enrollments.id, d.enrollmentId), eq(schema.enrollments.orgId, ctx.org.id))).limit(1);
    if (!e) throw new Error("Inscription introuvable dans cet organisme.");
    if (!d.sessionId) d.sessionId = e.sessionId;
  }
  if (d.programId) {
    const [p] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.id, d.programId), eq(schema.programs.orgId, ctx.org.id))).limit(1);
    if (!p) throw new Error("Programme introuvable dans cet organisme.");
  }
  if (d.documentId) {
    const [doc] = await db.select({ id: schema.documents.id }).from(schema.documents).where(and(eq(schema.documents.id, d.documentId), eq(schema.documents.orgId, ctx.org.id))).limit(1);
    if (!doc) throw new Error("Document introuvable dans cet organisme.");
  }
}

const evidenceSchema = z.object({
  indicatorCode: INDICATOR,
  level: LEVEL,
  title: z.string().trim().min(3, "Intitulé requis (3 caractères minimum)").max(200),
  evidenceDate: isoDate,
  sessionId: optUuid,
  enrollmentId: optUuid,
  programId: optUuid,
  documentId: optUuid,
});

/** Crée une preuve manuelle reliée à un document existant ou déposé (catégorie preuve). Jamais sans source réelle. */
async function createManualEvidence(ctx: OrgContext, formData: FormData, replacesId: string | null): Promise<{ id: string; title: string }> {
  const d = evidenceSchema.parse(Object.fromEntries(formData));
  const note = str(formData, "note", 2000);
  if (d.evidenceDate > todayParis()) throw new Error("La date de la preuve ne peut pas être dans le futur.");
  const links = { sessionId: d.sessionId, enrollmentId: d.enrollmentId, programId: d.programId, documentId: d.documentId };
  await checkLinks(ctx, links);
  if (d.level === "individuel" && !links.enrollmentId) throw new Error("Une preuve individuelle doit être reliée à une inscription.");
  if (d.level === "collectif" && !links.sessionId && !links.programId) throw new Error("Une preuve collective doit être reliée à une session ou à un programme.");

  let documentId = links.documentId;
  const file = formData.get("file");
  if (file instanceof File && file.size) {
    const data = Buffer.from(await file.arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head: data.subarray(0, 8) });
    if (!check.ok) throw new Error(check.error);
    const doc = await createDocument({
      orgId: ctx.org.id,
      enrollmentId: links.enrollmentId,
      sessionId: links.sessionId,
      category: "preuve",
      visibility: "interne",
      status: "valide",
      title: d.title,
      fileName: file.name,
      mimeType: check.mime,
      data,
      sourceType: "quality_evidence",
      uploadedBy: ctx.user.id,
      isDemo: ctx.org.isDemo,
    });
    documentId = doc.id;
  }
  if (!documentId) throw new Error("Une preuve doit être reliée à une action réelle : choisissez un document existant ou déposez un fichier.");

  const [row] = await db
    .insert(schema.qualityEvidences)
    .values({
      orgId: ctx.org.id,
      indicatorCode: d.indicatorCode,
      level: d.level,
      title: d.title,
      note,
      evidenceDate: d.evidenceDate,
      sourceType: "document",
      sourceId: documentId,
      documentId,
      sessionId: links.sessionId,
      enrollmentId: links.enrollmentId,
      programId: links.programId,
      createdBy: ctx.user.id,
    })
    .returning({ id: schema.qualityEvidences.id, title: schema.qualityEvidences.title });
  await audit({ action: "quality.evidence.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quality_evidence", entityId: row.id, after: { ...d, documentId, replaces: replacesId } });
  return row;
}

export async function createEvidenceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const row = await createManualEvidence(ctx, formData, null);
    revalidatePath(`${base(ctx.org.id)}/preuves`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: `Preuve « ${row.title} » enregistrée. Une nouvelle analyse est nécessaire pour la prendre en compte.` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function invalidateEvidenceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const evidenceId = uuid.parse(formData.get("evidenceId"));
    const reason = z.string().trim().min(5, "Motif requis (5 caractères minimum)").max(500).parse(formData.get("reason"));
    const [ev] = await db.select().from(schema.qualityEvidences).where(and(eq(schema.qualityEvidences.id, evidenceId), eq(schema.qualityEvidences.orgId, ctx.org.id))).limit(1);
    if (!ev) return { error: "Preuve introuvable." };
    if (ev.status !== "valide") return { error: "Cette preuve n'est plus valide." };
    await db.update(schema.qualityEvidences).set({ status: "invalidee", invalidatedAt: new Date(), invalidatedBy: ctx.user.id, invalidationReason: reason }).where(eq(schema.qualityEvidences.id, ev.id));
    await audit({ action: "quality.evidence.invalidate", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quality_evidence", entityId: ev.id, before: { status: ev.status }, after: { status: "invalidee", reason } });
    revalidatePath(`${base(ctx.org.id)}/preuves`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: "Preuve invalidée (événement conservé). Les analyses passées restent inchangées : relancez une analyse." };
  } catch (e) {
    return fail(e, "Invalidation impossible.");
  }
}

/** Remplacement : nouvelle preuve créée, l'ancienne passe en « remplacée » avec motif, auteur et lien vers la nouvelle. */
export async function replaceEvidenceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const evidenceId = uuid.parse(formData.get("evidenceId"));
    const reason = z.string().trim().min(5, "Motif requis (5 caractères minimum)").max(500).parse(formData.get("reason"));
    const [ev] = await db.select().from(schema.qualityEvidences).where(and(eq(schema.qualityEvidences.id, evidenceId), eq(schema.qualityEvidences.orgId, ctx.org.id))).limit(1);
    if (!ev) return { error: "Preuve introuvable." };
    if (ev.status !== "valide") return { error: "Seule une preuve valide peut être remplacée." };
    const created = await createManualEvidence(ctx, formData, ev.id);
    await db.update(schema.qualityEvidences).set({ status: "remplacee", replacedById: created.id, invalidatedAt: new Date(), invalidatedBy: ctx.user.id, invalidationReason: reason }).where(eq(schema.qualityEvidences.id, ev.id));
    await audit({ action: "quality.evidence.replace", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quality_evidence", entityId: ev.id, before: { status: "valide" }, after: { status: "remplacee", replacedById: created.id, reason } });
    revalidatePath(`${base(ctx.org.id)}/preuves`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: "Preuve remplacée : l'originale est conservée avec le motif. Relancez une analyse." };
  } catch (e) {
    return fail(e, "Remplacement impossible.");
  }
}

// ---------------------------------------------------------------------------
// Actions qualité (plan d'amélioration) et réclamations
// ---------------------------------------------------------------------------

async function assertMember(ctx: OrgContext, userId: string | null) {
  if (!userId) return;
  const [m] = await db.select({ id: schema.memberships.id }).from(schema.memberships).where(and(eq(schema.memberships.orgId, ctx.org.id), eq(schema.memberships.userId, userId), eq(schema.memberships.active, true))).limit(1);
  if (!m) throw new Error("Le responsable choisi n'est pas membre actif de l'organisme.");
}

const actionSchema = z.object({
  title: z.string().trim().min(3, "Intitulé requis").max(200),
  indicatorCode: INDICATOR.optional().or(z.literal("")),
  origin: z.enum(["audit", "reclamation", "enquete", "veille", "analyse", "revue", "autre"]),
  assigneeUserId: optUuid,
  dueDate: isoDate.optional().or(z.literal("")),
  analysisId: optUuid,
  complaintId: optUuid,
});

async function insertQualityAction(ctx: OrgContext, d: z.infer<typeof actionSchema>, description: string | null) {
  await assertMember(ctx, d.assigneeUserId);
  if (d.analysisId) {
    const [a] = await db.select({ id: schema.qualityAnalyses.id }).from(schema.qualityAnalyses).where(and(eq(schema.qualityAnalyses.id, d.analysisId), eq(schema.qualityAnalyses.orgId, ctx.org.id))).limit(1);
    if (!a) throw new Error("Analyse introuvable.");
  }
  const assignee = d.assigneeUserId ?? ctx.user.id;
  const [row] = await db
    .insert(schema.qualityActions)
    .values({ orgId: ctx.org.id, title: d.title, description, indicatorCode: d.indicatorCode || null, origin: d.origin, assigneeUserId: assignee, dueDate: d.dueDate || null, analysisId: d.analysisId, status: "a_faire" })
    .returning();
  const { task } = await createTaskOnce({
    orgId: ctx.org.id,
    title: `Action qualité : ${d.title}`,
    description,
    family: "qualite",
    entityType: "quality_action",
    entityId: row.id,
    entityLabel: d.title,
    href: `${base(ctx.org.id)}/actions`,
    assigneeUserId: assignee,
    assigneeRole: "quality",
    dueDate: d.dueDate || null,
    indicatorCode: d.indicatorCode || null,
    createdBy: ctx.user.id,
    source: "manuel",
    isDemo: ctx.org.isDemo,
    idempotencyKey: `quality_action:${row.id}:realisation`,
  });
  await db.update(schema.qualityActions).set({ taskId: task.id }).where(eq(schema.qualityActions.id, row.id));
  await audit({ action: "quality.action.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quality_action", entityId: row.id, after: { ...d, assignee, taskId: task.id } });
  return row;
}

export async function createQualityActionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const d = actionSchema.parse(Object.fromEntries(formData));
    const row = await insertQualityAction(ctx, d, str(formData, "description", 4000));
    if (d.complaintId) {
      const [c] = await db.select({ id: schema.complaints.id }).from(schema.complaints).where(and(eq(schema.complaints.id, d.complaintId), eq(schema.complaints.orgId, ctx.org.id))).limit(1);
      if (c) await db.update(schema.complaints).set({ qualityActionId: row.id }).where(eq(schema.complaints.id, c.id));
    }
    revalidatePath(`${base(ctx.org.id)}/actions`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: "Action qualité créée et tâche affectée au responsable." };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function updateQualityActionStatusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const actionId = uuid.parse(formData.get("actionId"));
    const status = z.enum(["a_faire", "en_cours", "terminee", "abandonnee"]).parse(formData.get("status"));
    const note = str(formData, "note", 1000);
    const [a] = await db.select().from(schema.qualityActions).where(and(eq(schema.qualityActions.id, actionId), eq(schema.qualityActions.orgId, ctx.org.id))).limit(1);
    if (!a) return { error: "Action introuvable." };
    if (a.status === status) return { error: "Statut inchangé." };
    if ((status === "terminee" || status === "abandonnee") && !note) return { error: "Indiquez ce qui a été fait (ou pourquoi l'action est abandonnée)." };
    const closed = status === "terminee" || status === "abandonnee";
    await db.update(schema.qualityActions).set({ status, closedAt: closed ? new Date() : null, description: note ? `${a.description ?? ""}\n\n[${todayParis()}] ${note}`.trim() : a.description }).where(eq(schema.qualityActions.id, a.id));
    if (closed) await resolveTaskByKey(ctx.org.id, `quality_action:${a.id}:realisation`, `${status === "terminee" ? "Action réalisée" : "Action abandonnée"} : ${note}`, ctx.user.id);
    if (status === "terminee") {
      await recordEvidence({ orgId: ctx.org.id, indicatorCode: "IND_32", level: "organisationnel", title: `Action d'amélioration réalisée : ${a.title}`, sourceType: "quality_action", sourceId: a.id, evidenceDate: todayParis(), note: note ?? undefined, createdBy: ctx.user.id });
    }
    await audit({ action: "quality.action.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quality_action", entityId: a.id, before: { status: a.status }, after: { status, note } });
    revalidatePath(`${base(ctx.org.id)}/actions`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: status === "terminee" ? "Action terminée : preuve d'amélioration continue (indicateur 32, à examiner) enregistrée." : "Statut mis à jour." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

const complaintSchema = z.object({
  source: z.enum(["apprenant", "entreprise", "financeur", "formateur", "partenaire", "interne", "autre"]),
  subject: z.string().trim().min(3, "Objet requis").max(200),
  receivedAt: isoDate,
  sessionId: optUuid,
  personId: optUuid,
  companyId: optUuid,
  assigneeUserId: optUuid,
});

export async function createComplaintAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const d = complaintSchema.parse(Object.fromEntries(formData));
    const description = str(formData, "description", 4000);
    if (d.receivedAt > todayParis()) return { error: "La date de réception ne peut pas être dans le futur." };
    await assertMember(ctx, d.assigneeUserId);
    await checkLinks(ctx, { sessionId: d.sessionId, enrollmentId: null, programId: null, documentId: null });
    if (d.personId) {
      const [p] = await db.select({ id: schema.persons.id }).from(schema.persons).where(and(eq(schema.persons.id, d.personId), eq(schema.persons.orgId, ctx.org.id))).limit(1);
      if (!p) return { error: "Personne introuvable." };
    }
    if (d.companyId) {
      const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.id, d.companyId), eq(schema.companies.orgId, ctx.org.id))).limit(1);
      if (!c) return { error: "Entreprise introuvable." };
    }
    const assignee = d.assigneeUserId ?? ctx.user.id;
    const [row] = await db
      .insert(schema.complaints)
      .values({ orgId: ctx.org.id, source: d.source, subject: d.subject, description, receivedAt: d.receivedAt, sessionId: d.sessionId, personId: d.personId, companyId: d.companyId, assigneeUserId: assignee, status: "recue" })
      .returning();
    await createTaskOnce({
      orgId: ctx.org.id,
      title: `Traiter la réclamation : ${d.subject}`,
      description,
      family: "qualite",
      entityType: "complaint",
      entityId: row.id,
      entityLabel: d.subject,
      href: `${base(ctx.org.id)}/actions`,
      assigneeUserId: assignee,
      assigneeRole: "quality",
      priority: "haute",
      indicatorCode: "IND_31",
      createdBy: ctx.user.id,
      source: "manuel",
      isDemo: ctx.org.isDemo,
      idempotencyKey: `complaint:${row.id}:traitement`,
    });
    await audit({ action: "quality.complaint.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "complaint", entityId: row.id, after: { ...d, assignee } });
    revalidatePath(`${base(ctx.org.id)}/actions`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: "Réclamation enregistrée et tâche de traitement affectée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Avancement d'une réclamation ; la clôture (traitée) exige une résolution et crée la preuve IND_31. */
export async function updateComplaintAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const complaintId = uuid.parse(formData.get("complaintId"));
    const status = z.enum(["recue", "en_cours", "traitee", "close"]).parse(formData.get("status"));
    const resolution = str(formData, "resolution", 4000);
    const createAction = formData.get("createAction") === "on";
    const [c] = await db.select().from(schema.complaints).where(and(eq(schema.complaints.id, complaintId), eq(schema.complaints.orgId, ctx.org.id))).limit(1);
    if (!c) return { error: "Réclamation introuvable." };
    const closing = status === "traitee" || status === "close";
    if (closing && !(resolution ?? c.resolution)) return { error: "Décrivez la résolution apportée avant de clôturer la réclamation." };
    const patch: Partial<typeof schema.complaints.$inferInsert> = { status, resolution: resolution ?? c.resolution };
    if (closing && !c.resolvedAt) patch.resolvedAt = todayParis();
    let actionMsg = "";
    if (createAction && !c.qualityActionId) {
      const row = await insertQualityAction(ctx, { title: `Suite à réclamation : ${c.subject}`, indicatorCode: "IND_32", origin: "reclamation", assigneeUserId: c.assigneeUserId, dueDate: "", analysisId: null, complaintId: c.id }, resolution ?? c.description);
      patch.qualityActionId = row.id;
      actionMsg = " Action qualité liée créée.";
    }
    await db.update(schema.complaints).set(patch).where(eq(schema.complaints.id, c.id));
    if (closing) {
      await resolveTaskByKey(ctx.org.id, `complaint:${c.id}:traitement`, `Réclamation ${status === "traitee" ? "traitée" : "close"} : ${resolution ?? c.resolution ?? ""}`, ctx.user.id);
      await recordEvidence({ orgId: ctx.org.id, indicatorCode: "IND_31", level: "organisationnel", title: `Réclamation traitée : ${c.subject}`, sourceType: "complaint", sourceId: c.id, sessionId: c.sessionId, evidenceDate: patch.resolvedAt ?? c.resolvedAt ?? todayParis(), note: resolution ?? c.resolution, createdBy: ctx.user.id });
    }
    await audit({ action: "quality.complaint.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "complaint", entityId: c.id, before: { status: c.status }, after: { status, resolution: Boolean(resolution ?? c.resolution), createAction } });
    revalidatePath(`${base(ctx.org.id)}/actions`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: closing ? `Réclamation ${status === "traitee" ? "traitée" : "close"} : preuve de traitement (indicateur 31) enregistrée.${actionMsg}` : `Statut mis à jour.${actionMsg}` };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

// ---------------------------------------------------------------------------
// Veille (chaque entrée = preuve organisationnelle IND_23 à IND_26)
// ---------------------------------------------------------------------------

const watchSchema = z.object({
  kind: z.enum(["reglementaire", "pedagogique", "handicap", "metiers"]),
  title: z.string().trim().min(3, "Titre requis").max(200),
  url: z.string().trim().url("Adresse invalide").max(500).optional().or(z.literal("")),
  date: isoDate,
  sharedWithTeam: z.string().optional(),
});

export async function createWatchItemAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const d = watchSchema.parse(Object.fromEntries(formData));
    const summary = str(formData, "summary", 4000);
    const impact = str(formData, "impact", 2000);
    if (d.date > todayParis()) return { error: "La date ne peut pas être dans le futur." };
    const shared = d.sharedWithTeam === "on";
    const [row] = await db
      .insert(schema.watchItems)
      .values({ orgId: ctx.org.id, kind: d.kind, title: d.title, url: d.url || null, summary, date: d.date, impact, authorId: ctx.user.id, sharedWithTeam: shared })
      .returning();
    const indicator = watchKindIndicator[d.kind];
    await recordEvidence({ orgId: ctx.org.id, indicatorCode: indicator, level: "organisationnel", title: `Veille ${d.kind} : ${d.title}`, sourceType: "watch_item", sourceId: row.id, evidenceDate: d.date, note: impact ?? summary, createdBy: ctx.user.id });
    if (shared) {
      const members = await db
        .select({ userId: schema.memberships.userId })
        .from(schema.memberships)
        .where(and(eq(schema.memberships.orgId, ctx.org.id), eq(schema.memberships.active, true), sql`${schema.memberships.roles} ?| array['quality','direction','pedagogy_manager','agency_manager']`));
      for (const m of members) {
        if (m.userId === ctx.user.id) continue;
        await notify({ orgId: ctx.org.id, userId: m.userId, title: `Veille partagée : ${d.title}`, body: summary ?? undefined, href: `${base(ctx.org.id)}/veille`, kind: "veille", dedupeKey: `watch:${row.id}:${m.userId}` });
      }
    }
    await audit({ action: "quality.watch.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "watch_item", entityId: row.id, after: { ...d, indicator, shared } });
    revalidatePath(`${base(ctx.org.id)}/veille`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: `Entrée de veille enregistrée : preuve organisationnelle ${indicator.replace("IND_", "indicateur ")} créée${shared ? ", équipe notifiée" : ""}.` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}
