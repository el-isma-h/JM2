"use server";

import { revalidatePath } from "next/cache";
import { and, eq, ilike, or, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg, type OrgContext } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { canEditSettings } from "@/server/security/rules";
import { buildPersonExport } from "@/server/security/rgpd";
import { createDocument, issueDownloadLink } from "@/server/documents/store";
import { ONBOARDING_STEPS } from "@/components/dashboard/onboarding";
import { OBJECTIVE_METRICS } from "@/server/pilotage/objectives";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

/** Paramètres : lecture org.view ; écriture direction ou propriétaire. */
async function requireSettingsWriter(orgId: string): Promise<OrgContext> {
  const ctx = await requireOrg(orgId, "org.view");
  if (!canEditSettings(ctx)) throw new AuthError("forbidden");
  return ctx;
}

type OrgSettings = {
  morning?: { start: string; end: string };
  afternoon?: { start: string; end: string };
  timezone?: string;
  rhythms?: { label: string; centerDays: number; companyDays: number; weekdays: number[] }[];
  numbering?: { enrollment?: string; session?: string; invoice?: string; credit?: string; quote?: string };
  [k: string]: unknown;
};

function settingsOf(ctx: OrgContext): OrgSettings {
  return ((ctx.org.settings ?? {}) as OrgSettings) || {};
}

async function saveSettings(ctx: OrgContext, next: OrgSettings, action: string, before: unknown, after: unknown) {
  await db.update(schema.organismes).set({ settings: next }).where(eq(schema.organismes.id, ctx.org.id));
  await audit({ action, userId: ctx.user.id, orgId: ctx.org.id, entityType: "organisme", entityId: ctx.org.id, before, after });
  revalidatePath(`/app/${ctx.org.id}/parametres`);
  revalidatePath(`/app/${ctx.org.id}`, "layout");
}

const identitySchema = z.object({
  email: z.string().trim().email("Adresse e-mail invalide.").optional().or(z.literal("")),
  phone: z.string().trim().max(30).optional(),
  website: z.string().trim().url("Adresse du site invalide (https://…).").optional().or(z.literal("")),
  kind: z.enum(["of", "cfa", "of_cfa"]),
});

/** Identité non institutionnelle : e-mail, téléphone, site, activité. La charte (logo, SIRET, NDA, signataire) est gérée sur /charte par le propriétaire. */
export async function updateIdentityAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSettingsWriter(orgId);
    const d = identitySchema.parse(Object.fromEntries(formData));
    const values = { email: d.email || null, phone: d.phone || null, website: d.website || null, kind: d.kind };
    await db.update(schema.organismes).set(values).where(eq(schema.organismes.id, orgId));
    await audit({ action: "org.settings.identity", userId: ctx.user.id, orgId, entityType: "organisme", entityId: orgId, before: { email: ctx.org.email, phone: ctx.org.phone, website: ctx.org.website, kind: ctx.org.kind }, after: values });
    revalidatePath(`/app/${orgId}/parametres`);
    revalidatePath(`/app/${orgId}`, "layout");
    return { ok: true, message: "Identité enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

const scheduleSchema = z.object({
  morningStart: z.string().regex(HHMM, "Heure invalide (HH:mm)."),
  morningEnd: z.string().regex(HHMM, "Heure invalide (HH:mm)."),
  afternoonStart: z.string().regex(HHMM, "Heure invalide (HH:mm)."),
  afternoonEnd: z.string().regex(HHMM, "Heure invalide (HH:mm)."),
  timezone: z.enum(["Europe/Paris"]).default("Europe/Paris"),
});

/** Horaires par défaut matin / après-midi (règle F06 : pause méridienne exclue, périodes indépendantes). */
export async function updateScheduleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSettingsWriter(orgId);
    const d = scheduleSchema.parse(Object.fromEntries(formData));
    if (d.morningEnd <= d.morningStart) return { error: "La fin de matinée doit suivre le début." };
    if (d.afternoonEnd <= d.afternoonStart) return { error: "La fin d'après-midi doit suivre le début." };
    if (d.afternoonStart < d.morningEnd) return { error: "L'après-midi doit commencer après la fin de la matinée (pause méridienne exclue du décompte)." };
    const before = settingsOf(ctx);
    const next: OrgSettings = { ...before, morning: { start: d.morningStart, end: d.morningEnd }, afternoon: { start: d.afternoonStart, end: d.afternoonEnd }, timezone: d.timezone };
    await saveSettings(ctx, next, "org.settings.schedule", { morning: before.morning, afternoon: before.afternoon }, { morning: next.morning, afternoon: next.afternoon });
    return { ok: true, message: "Horaires par défaut enregistrés." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Rythmes types : « label | jours centre | jours entreprise | jours de la semaine (1-5, séparés par des virgules) », un par ligne. */
export async function updateRhythmsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSettingsWriter(orgId);
    const raw = String(formData.get("rhythms") ?? "");
    const rhythms: NonNullable<OrgSettings["rhythms"]> = [];
    for (const line of raw.split("\n").map((l) => l.trim()).filter(Boolean)) {
      const [label, c, e, w] = line.split("|").map((x) => x.trim());
      const centerDays = Number(c);
      const companyDays = Number(e);
      if (!label || !Number.isInteger(centerDays) || !Number.isInteger(companyDays) || centerDays < 0 || companyDays < 0) return { error: `Ligne invalide : « ${line} ». Format : libellé | jours centre | jours entreprise | jours (1-7).` };
      const weekdays = (w ?? "")
        .split(",")
        .map((x) => Number(x.trim()))
        .filter((x) => Number.isInteger(x) && x >= 1 && x <= 7);
      rhythms.push({ label, centerDays, companyDays, weekdays });
    }
    if (rhythms.length > 20) return { error: "20 rythmes au maximum." };
    const before = settingsOf(ctx);
    await saveSettings(ctx, { ...before, rhythms }, "org.settings.rhythms", { rhythms: before.rhythms }, { rhythms });
    return { ok: true, message: `${rhythms.length} rythme(s) enregistré(s).` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

const prefix = z.string().trim().regex(/^[A-Z0-9]{1,6}$/, "Préfixe : 1 à 6 lettres ou chiffres en capitales.");

export async function updateNumberingAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSettingsWriter(orgId);
    const d = z.object({ enrollment: prefix, session: prefix, invoice: prefix, credit: prefix, quote: prefix }).parse(Object.fromEntries(formData));
    const before = settingsOf(ctx);
    await saveSettings(ctx, { ...before, numbering: d }, "org.settings.numbering", { numbering: before.numbering }, { numbering: d });
    return { ok: true, message: "Préfixes enregistrés." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Politique de conservation (T04) : durée en mois et action (anonymiser, supprimer, conserver) par catégorie. */
export async function updateRetentionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSettingsWriter(orgId);
    const id = uuid.parse(formData.get("policyId"));
    const months = z.coerce.number().int().min(1, "Durée : 1 mois minimum.").max(1200, "Durée : 100 ans maximum.").parse(formData.get("retentionMonths"));
    const action = z.enum(["anonymiser", "supprimer", "conserver"]).parse(formData.get("action"));
    const legalBasis = String(formData.get("legalBasis") ?? "").trim().slice(0, 300) || null;
    const [before] = await db.select().from(schema.retentionPolicies).where(and(eq(schema.retentionPolicies.id, id), eq(schema.retentionPolicies.orgId, orgId))).limit(1);
    if (!before) return { error: "Politique introuvable." };
    await db.update(schema.retentionPolicies).set({ retentionMonths: months, action, legalBasis }).where(eq(schema.retentionPolicies.id, id));
    await audit({ action: "org.retention.update", userId: ctx.user.id, orgId, entityType: "retention_policy", entityId: id, before: { retentionMonths: before.retentionMonths, action: before.action, legalBasis: before.legalBasis }, after: { retentionMonths: months, action, legalBasis } });
    revalidatePath(`/app/${orgId}/parametres`);
    return { ok: true, message: `Politique « ${before.label} » mise à jour.` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Export RGPD d'une personne : ZIP JSON + documents, enregistré comme document « export », lien temporaire. Exige exports.run (renforcé). */
export async function exportPersonDataAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "org.view", "exports.run");
    if (!canEditSettings(ctx) && !ctx.permissions.has("dossier.admin_docs.manage")) throw new AuthError("forbidden");
    const personId = uuid.parse(formData.get("personId"));
    const reason = z.string().trim().min(3, "Indiquez le motif de la demande (demande de la personne, référence).").max(300).parse(formData.get("reason"));
    const r = await buildPersonExport(orgId, personId, { includeConfidential: ctx.permissions.has("candidates.cv.view") });
    if (!r) return { error: "Personne introuvable dans cet organisme." };
    const doc = await createDocument({ orgId, personId, category: "export", visibility: "confidentiel", status: "genere", title: `Export RGPD : ${r.fileName}`, fileName: r.fileName, mimeType: "application/zip", data: r.zip, sourceType: "rgpd_export", uploadedBy: ctx.user.id, retentionYears: 1, isDemo: ctx.org.isDemo });
    const link = await issueDownloadLink(doc.id, ctx.user.id);
    await audit({ action: "rgpd.export", userId: ctx.user.id, orgId, entityType: "person", entityId: personId, after: { reason, documentId: doc.id, counts: r.counts } });
    revalidatePath(`/app/${orgId}/parametres`);
    return { ok: true, message: `Export généré (${r.counts.inscriptions} inscription(s), ${r.counts.documents} document(s)). Lien valable 15 minutes :`, data: { link } };
  } catch (e) {
    return fail(e, "Export impossible.");
  }
}

/** Onboarding guidé : avancer d'une étape ou revenir ; « termine » pose la date de fin. */
export async function setOnboardingStepAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSettingsWriter(orgId);
    const step = z.enum(ONBOARDING_STEPS.map((s) => s.key) as [string, ...string[]]).parse(formData.get("step"));
    const done = step === "termine";
    await db.update(schema.organismes).set({ onboardingStep: step, onboardingCompletedAt: done ? new Date() : null }).where(eq(schema.organismes.id, orgId));
    await audit({ action: "org.onboarding.step", userId: ctx.user.id, orgId, entityType: "organisme", entityId: orgId, before: { step: ctx.org.onboardingStep }, after: { step } });
    revalidatePath(`/app/${orgId}/parametres`);
    revalidatePath(`/app/${orgId}`);
    return { ok: true, message: done ? "Mise en route terminée." : "Étape enregistrée." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

/** Recherche d'une personne (pour l'export RGPD) : résultats JSON. */
export async function searchPersonsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    await requireOrg(orgId, "org.view");
    const q = String(formData.get("q") ?? "").trim().slice(0, 60);
    if (q.length < 2) return { ok: true, message: "", data: { results: "[]" } };
    const like = `%${q}%`;
    const rows = await db
      .select({ id: schema.persons.id, first: schema.persons.firstName, last: schema.persons.lastName, email: schema.persons.email })
      .from(schema.persons)
      .where(and(eq(schema.persons.orgId, orgId), or(ilike(schema.persons.lastName, like), ilike(schema.persons.firstName, like), ilike(schema.persons.email, like), ilike(sql`${schema.persons.firstName} || ' ' || ${schema.persons.lastName}`, like))))
      .limit(10);
    return { ok: true, message: "", data: { results: JSON.stringify(rows.map((r) => ({ id: r.id, label: `${r.first} ${r.last}${r.email ? ` (${r.email})` : ""}` }))) } };
  } catch (e) {
    return fail(e, "Recherche impossible.");
  }
}

/* ---------- Objectifs de pilotage (F15) ---------- */

export async function saveObjectiveAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSettingsWriter(orgId);
    const d = z
      .object({
        id: z.string().uuid().optional().or(z.literal("")),
        metric: z.enum(OBJECTIVE_METRICS.map((m) => m.key) as [string, ...string[]]),
        periodStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date de début invalide."),
        periodEnd: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date de fin invalide."),
        target: z.string().trim().min(1, "Cible requise."),
      })
      .parse(Object.fromEntries(formData));
    if (d.periodEnd < d.periodStart) return { error: "La fin de période précède le début." };
    const meta = OBJECTIVE_METRICS.find((m) => m.key === d.metric)!;
    const raw = d.target.replace(/[\s€%]/g, "").replace(",", ".");
    const num = Number(raw);
    if (!Number.isFinite(num) || num < 0) return { error: "Cible invalide." };
    const target = meta.unit === "cents" ? Math.round(num * 100) : Math.round(num);
    if (meta.unit === "percent" && target > 100) return { error: "Un objectif en pourcentage ne dépasse pas 100." };
    const values = { orgId, metric: d.metric, label: meta.label, unit: meta.unit, periodStart: d.periodStart, periodEnd: d.periodEnd, target };
    if (d.id) {
      const [before] = await db.select().from(schema.objectives).where(and(eq(schema.objectives.id, d.id), eq(schema.objectives.orgId, orgId))).limit(1);
      if (!before) return { error: "Objectif introuvable." };
      await db.update(schema.objectives).set(values).where(eq(schema.objectives.id, d.id));
      await audit({ action: "pilotage.objective.update", userId: ctx.user.id, orgId, entityType: "objective", entityId: d.id, before, after: values });
    } else {
      const [row] = await db.insert(schema.objectives).values(values).returning({ id: schema.objectives.id });
      await audit({ action: "pilotage.objective.create", userId: ctx.user.id, orgId, entityType: "objective", entityId: row.id, after: values });
    }
    revalidatePath(`/app/${orgId}/pilotage/objectifs`);
    revalidatePath(`/app/${orgId}/pilotage`);
    revalidatePath(`/app/${orgId}`);
    return { ok: true, message: "Objectif enregistré (cible affichée à côté des indicateurs, jamais comme résultat)." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deleteObjectiveAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireSettingsWriter(orgId);
    const id = uuid.parse(formData.get("id"));
    const [before] = await db.select().from(schema.objectives).where(and(eq(schema.objectives.id, id), eq(schema.objectives.orgId, orgId))).limit(1);
    if (!before) return { error: "Objectif introuvable." };
    await db.delete(schema.objectives).where(eq(schema.objectives.id, id));
    await audit({ action: "pilotage.objective.delete", userId: ctx.user.id, orgId, entityType: "objective", entityId: id, before });
    revalidatePath(`/app/${orgId}/pilotage/objectifs`);
    revalidatePath(`/app/${orgId}/pilotage`);
    return { ok: true, message: "Objectif supprimé." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}
