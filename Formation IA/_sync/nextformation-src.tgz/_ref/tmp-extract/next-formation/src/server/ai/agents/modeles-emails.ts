import "server-only";
import type { OrgContext } from "@/server/authz";
import { AiNotConfiguredError } from "../provider";
import type { Agent, AgentInput, ProposalDraft } from "../store";
import { askJson, baseRationale, orgLabel, requireEntity } from "./shared";
import { MAIL_TEMPLATE_VARIABLES, mailTemplateDefault, usedVariables } from "@/server/mail-templates/defaults";
import { getOrgMailTemplateById, type MailTemplatePayload } from "@/server/mail-templates/service";
import { marker } from "@/server/documents/render";

type ModelAnswer = { subject?: string; body?: string; notes?: string[]; certainty?: "A" | "B" | "C" };

/** Retire les tirets cadratin / demi-cadratin (règle de rédaction) et remplace les variables hors liste par un marqueur. */
function sanitize(text: string, allowed: string[], unknown: Set<string>): string {
  const noDash = text.replace(/\s*[—–]\s*/g, " - ");
  return noDash.replace(/\{\{\s*(#if\s+|#unless\s+)?([a-zA-Z][\w.]*)\s*\}\}/g, (all, kw: string | undefined, path: string) => {
    if (allowed.includes(path) || (!kw && path === "else")) return all;
    unknown.add(path);
    return kw ? "{{#if variable_inconnue}}" : marker(`variable non prise en charge : ${path}`);
  });
}

/**
 * Rédaction ou réécriture d'un modèle d'e-mail de l'organisme. La proposition (statut proposée) n'a aucun effet
 * avant validation humaine ; validée, elle crée une nouvelle version du modèle.
 */
export const modelesEmailsAgent: Agent = {
  name: "modeles",
  label: "Rédaction de modèle d'e-mail",
  description: "Propose une rédaction d'un modèle d'e-mail (objet et corps) avec les variables autorisées et des marqueurs « [À COMPLÉTER] » pour ce qui n'est pas connu.",
  requires: "documents.generate",
  accepts: ["mail_template"],
  async run(ctx: OrgContext, input: AgentInput): Promise<ProposalDraft> {
    const { entityId } = requireEntity(input, ["mail_template"]);
    const row = await getOrgMailTemplateById(ctx.org.id, entityId);
    if (!row) throw new Error("Modèle d'e-mail introuvable.");
    const def = mailTemplateDefault(row.code);
    if (!def) throw new Error("Modèle d'e-mail inconnu.");
    const instructions = (input.params?.instructions ?? "").trim().slice(0, 1500);
    const variables = def.variables.map((v) => `{{${v}}} : ${MAIL_TEMPLATE_VARIABLES[v] ?? v}`).join("\n");
    const system = `Tu rédiges des modèles d'e-mails pour un organisme de formation. Un modèle contient des variables {{chemin}} remplacées à l'envoi, et des sections {{#if chemin}} … {{/if}}.
Contraintes :
- n'utilise que les variables de la liste fournie, sans en créer ;
- ce que tu ne sais pas sur l'organisme (horaires, adresse, conditions, montants, procédures) reste un marqueur « [À COMPLÉTER : description] » ; n'invente aucun fait, chiffre ni engagement ;
- conserve les marqueurs « [À COMPLÉTER : …] » existants, sauf si la consigne donne explicitement l'information ;
- texte brut, paragraphes séparés par une ligne vide, vouvoiement (sauf si la consigne demande le tutoiement), ton professionnel et chaleureux, concis ;
- objet de 90 caractères au plus.
Réponds par un objet JSON : {"subject": string, "body": string, "notes": string[] (points à vérifier par l'humain), "certainty": "A"|"B"|"C"}.`;
    const user = `Organisme : ${orgLabel(ctx)}
Modèle : ${def.title} (destinataire : ${def.recipient})
Usage : ${def.purpose}
Variables autorisées :
${variables}

Version actuelle (v${row.version}) :
Objet : ${row.subject}
Corps :
${row.body}

Consigne de l'utilisateur : ${instructions || "améliorer la clarté et le ton, sans changer le fond."}`;
    const r = await askJson<ModelAnswer>(system, user, 1800);
    if (!r) throw new AiNotConfiguredError();
    const subjectRaw = typeof r.data?.subject === "string" ? r.data.subject.trim() : "";
    const bodyRaw = typeof r.data?.body === "string" ? r.data.body.trim() : "";
    if (!subjectRaw || !bodyRaw) throw new Error("Le modèle IA n'a pas renvoyé de rédaction exploitable : réessayez ou reformulez la consigne.");
    const unknown = new Set<string>();
    const subject = sanitize(subjectRaw, def.variables, unknown).slice(0, 200);
    // Une condition sur une variable inconnue devient {{#if variable_inconnue}} : bloc masqué, à revoir par l'humain.
    const body = sanitize(bodyRaw, def.variables, unknown);
    const notes = (Array.isArray(r.data?.notes) ? r.data!.notes : []).filter((n): n is string => typeof n === "string").slice(0, 8);
    if (unknown.size) notes.push(`Variables non prises en charge remplacées par un marqueur : ${[...unknown].join(", ")}.`);
    const lost = usedVariables(row.body).filter((v) => def.variables.includes(v) && !usedVariables(body).includes(v));
    if (lost.length) notes.push(`Variables présentes dans la version actuelle et absentes de la proposition : ${lost.join(", ")}.`);
    const payload: MailTemplatePayload = { mailTemplateId: row.id, code: row.code, title: def.title, subject, body, baseVersion: row.version, unknownVariables: [...unknown] };
    const certainty = r.data?.certainty === "A" || r.data?.certainty === "B" ? r.data.certainty : "C";
    return {
      agent: "modeles",
      kind: "modele_email",
      title: `Modèle d'e-mail : ${def.title}`,
      summary: instructions ? `Consigne : ${instructions.slice(0, 200)}` : "Réécriture de la version actuelle.",
      entityType: "mail_template",
      entityId: row.id,
      payload: payload as unknown as Record<string, unknown>,
      rationale: baseRationale(
        [{ type: "mail_template", id: row.id, label: `${def.title}, version ${row.version}` }],
        certainty,
        false,
        ["Variables limitées à la liste du modèle", "Informations inconnues laissées en « [À COMPLÉTER : …] »", "Validée, la proposition crée une nouvelle version du modèle ; aucun e-mail n'est envoyé"],
        notes,
      ),
      provider: r.result.provider,
      model: r.result.model,
    };
  },
};
