"use server";

import { revalidatePath } from "next/cache";
import { and, eq, isNull } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requirePlatformAdmin } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { seedReferentials } from "@/server/quality/referential-seed";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const DAY = /^\d{4}-\d{2}-\d{2}$/;

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

const criteriaSchema = z.array(
  z.object({
    code: z.string().min(1),
    label: z.string().min(1),
    indicators: z.array(z.object({ code: z.string().min(1), label: z.string().min(1) }).passthrough()).default([]),
  }).passthrough(),
);

/** Import JSON d'un référentiel plateforme (orgId null, statut brouillon) : { code, title, version, source?, sourceUrl?, scope?, effectiveFrom?, criteria[] }. */
export async function importReferentialAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const raw = String(formData.get("json") ?? "").trim();
    if (!raw) return { error: "Collez le JSON du référentiel." };
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return { error: "JSON invalide." };
    }
    const d = z
      .object({
        code: z.string().trim().min(2).max(60),
        title: z.string().trim().min(2).max(200),
        version: z.string().trim().min(1).max(40),
        source: z.string().trim().max(300).optional(),
        sourceUrl: z.string().trim().url().optional().or(z.literal("")),
        scope: z.enum(["of", "cfa", "both"]).default("both"),
        effectiveFrom: z.string().regex(DAY).optional().or(z.literal("")),
        effectiveTo: z.string().regex(DAY).optional().or(z.literal("")),
        criteria: criteriaSchema,
      })
      .parse(parsed);
    const [dup] = await db.select({ id: schema.referentials.id }).from(schema.referentials).where(and(isNull(schema.referentials.orgId), eq(schema.referentials.code, d.code), eq(schema.referentials.version, d.version))).limit(1);
    if (dup) return { error: `Le référentiel ${d.code} version ${d.version} existe déjà sur la plateforme.` };
    const [row] = await db
      .insert(schema.referentials)
      .values({ orgId: null, code: d.code, title: d.title, version: d.version, source: d.source || null, sourceUrl: d.sourceUrl || null, scope: d.scope, effectiveFrom: d.effectiveFrom || null, effectiveTo: d.effectiveTo || null, status: "brouillon", criteria: d.criteria })
      .returning({ id: schema.referentials.id });
    const indicators = d.criteria.reduce((a, c) => a + c.indicators.length, 0);
    await audit({ action: "admin.referential.import", userId: admin.id, entityType: "referential", entityId: row.id, after: { code: d.code, version: d.version, criteria: d.criteria.length, indicators } });
    revalidatePath("/admin/referentiels");
    return { ok: true, message: `Référentiel ${d.code} ${d.version} importé (${d.criteria.length} critères, ${indicators} indicateurs). Chaque organisme en fera une copie validée par un humain avant activation.` };
  } catch (e) {
    return fail(e, "Import impossible.");
  }
}

/** Dates d'effet d'un référentiel plateforme. */
export async function updateReferentialDatesAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const from = String(formData.get("effectiveFrom") ?? "").trim();
    const to = String(formData.get("effectiveTo") ?? "").trim();
    if (from && !DAY.test(from)) return { error: "Date d'effet invalide." };
    if (to && !DAY.test(to)) return { error: "Date de fin invalide." };
    if (from && to && to < from) return { error: "La fin d'effet précède le début." };
    const [before] = await db.select().from(schema.referentials).where(and(eq(schema.referentials.id, id), isNull(schema.referentials.orgId))).limit(1);
    if (!before) return { error: "Référentiel plateforme introuvable." };
    await db.update(schema.referentials).set({ effectiveFrom: from || null, effectiveTo: to || null }).where(eq(schema.referentials.id, id));
    await audit({ action: "admin.referential.dates", userId: admin.id, entityType: "referential", entityId: id, before: { effectiveFrom: before.effectiveFrom, effectiveTo: before.effectiveTo }, after: { effectiveFrom: from || null, effectiveTo: to || null } });
    revalidatePath("/admin/referentiels");
    return { ok: true, message: "Dates d'effet enregistrées (les copies des organismes ne sont pas modifiées)." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Retire un référentiel plateforme de la proposition (statut retiré) ; les copies validées par les organismes restent intactes. */
export async function withdrawReferentialAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const [before] = await db.select().from(schema.referentials).where(and(eq(schema.referentials.id, id), isNull(schema.referentials.orgId))).limit(1);
    if (!before) return { error: "Référentiel plateforme introuvable." };
    const next = before.status === "retire" ? "brouillon" : "retire";
    await db.update(schema.referentials).set({ status: next }).where(eq(schema.referentials.id, id));
    await audit({ action: "admin.referential.status", userId: admin.id, entityType: "referential", entityId: id, before: { status: before.status }, after: { status: next } });
    revalidatePath("/admin/referentiels");
    return { ok: true, message: next === "retire" ? "Référentiel retiré de la proposition." : "Référentiel de nouveau proposé." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

export async function seedReferentialsAction(): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const r = await seedReferentials();
    await audit({ action: "admin.referential.seed", userId: admin.id, entityType: "referential", after: r });
    revalidatePath("/admin/referentiels");
    return { ok: true, message: r.inserted ? `Référentiel ${r.code} ${r.version} chargé.` : `Référentiel ${r.code} ${r.version} déjà présent.` };
  } catch (e) {
    return fail(e, "Chargement impossible.");
  }
}
