import "server-only";
import { and, desc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext, Permission } from "@/server/authz";
import { audit } from "@/server/audit";
import type { AgentName, Rationale } from "./proposals";

/** Proposition produite par un agent, avant enregistrement (statut `proposee`, jamais appliquée sans validation). */
export type ProposalDraft = {
  agent: AgentName;
  /** Nature de l'effet si validée : email, resume, piece_classement, synthese_qualite, programme_version, calendrier, document_reponses. */
  kind: string;
  title: string;
  summary?: string;
  entityType?: string | null;
  entityId?: string | null;
  payload: Record<string, unknown>;
  rationale: Rationale;
  provider?: string | null;
  model?: string | null;
};

export type AgentInput = { entityType?: string | null; entityId?: string | null; params?: Record<string, string> };

export type Agent = {
  name: AgentName;
  label: string;
  description: string;
  /** Permission minimale pour déclencher l'agent (le périmètre formateur s'applique en plus). */
  requires?: Permission;
  /** Entités acceptées en contexte. */
  accepts: string[];
  run: (ctx: OrgContext, input: AgentInput) => Promise<ProposalDraft>;
};

export type ProposalRow = typeof schema.aiProposals.$inferSelect;

export async function saveProposal(ctx: OrgContext, draft: ProposalDraft): Promise<ProposalRow> {
  const [row] = await db
    .insert(schema.aiProposals)
    .values({
      orgId: ctx.org.id,
      agent: draft.agent,
      kind: draft.kind,
      title: draft.title,
      summary: draft.summary ?? null,
      entityType: draft.entityType ?? null,
      entityId: draft.entityId ?? null,
      payload: draft.payload,
      rationale: draft.rationale,
      status: "proposee",
      provider: draft.provider ?? null,
      model: draft.model ?? null,
      createdBy: ctx.user.id,
    })
    .returning();
  await audit({ action: "ai.proposal.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "ai_proposal", entityId: row.id, after: { agent: row.agent, kind: row.kind, entityType: row.entityType, entityId: row.entityId } });
  return row;
}

export async function getProposal(orgId: string, id: string): Promise<ProposalRow | null> {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const [row] = await db.select().from(schema.aiProposals).where(and(eq(schema.aiProposals.id, id), eq(schema.aiProposals.orgId, orgId))).limit(1);
  return row ?? null;
}

export async function listProposals(orgId: string, statuses: ProposalRow["status"][] = ["proposee"], limit = 100): Promise<ProposalRow[]> {
  return db
    .select()
    .from(schema.aiProposals)
    .where(and(eq(schema.aiProposals.orgId, orgId), inArray(schema.aiProposals.status, statuses)))
    .orderBy(desc(schema.aiProposals.createdAt))
    .limit(limit);
}

export async function listProposalsForEntity(orgId: string, entityType: string, entityId: string): Promise<ProposalRow[]> {
  return db
    .select()
    .from(schema.aiProposals)
    .where(and(eq(schema.aiProposals.orgId, orgId), eq(schema.aiProposals.entityType, entityType), eq(schema.aiProposals.entityId, entityId)))
    .orderBy(desc(schema.aiProposals.createdAt))
    .limit(20);
}
