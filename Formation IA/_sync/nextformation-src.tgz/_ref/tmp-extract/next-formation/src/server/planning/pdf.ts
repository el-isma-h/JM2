import "server-only";
import { INK, LINE, MUTED, clean, newPdf, section, writeFooter, writeOrgHeader, type Org } from "@/server/crm/pdf-base";
import { fmtDate } from "@/lib/dates";
import { fmtMinutes } from "@/lib/time";

export type SheetRow = {
  lastName: string;
  firstName: string;
  reference: string;
  status: string;
  statusLabel: string;
  arrivedAt?: string | null;
  leftAt?: string | null;
  minutes: number;
  signedAt?: Date | null;
  method?: string | null;
  signature?: Buffer | null;
};

/**
 * Feuille d'émargement PDF d'une période clôturée : identité de l'organisme concerné, session, séance, période,
 * liste des inscrits avec statut, heures et signature (image si tablette). Signature de fin du formateur.
 */
export async function renderAttendanceSheetPdf(input: {
  org: Org;
  session: { code: string; title: string };
  date: string;
  part: string;
  startTime: string;
  endTime: string;
  moduleTitle?: string | null;
  trainerName?: string | null;
  roomName?: string | null;
  rows: SheetRow[];
  trainerSignedAt?: Date | null;
  trainerSignature?: Buffer | null;
  closedAt: Date;
  closedByName?: string | null;
}): Promise<Buffer> {
  const { doc, done } = newPdf(`Feuille d'émargement ${input.session.code} ${input.date}`);
  writeOrgHeader(doc, input.org, "Feuille d'émargement par période");
  doc.font("Helvetica-Bold").fontSize(12).fillColor(INK).text(clean(`${input.session.code} : ${input.session.title}`));
  doc.font("Helvetica").fontSize(9.5).fillColor(MUTED);
  const partLabel: Record<string, string> = { matin: "Matin", apres_midi: "Après-midi", journee: "Journée", soir: "Soir" };
  doc.text(clean(`${fmtDate(input.date, "EEEE d MMMM yyyy")} · ${partLabel[input.part] ?? input.part} · ${input.startTime} à ${input.endTime} (heure de Paris)`));
  if (input.moduleTitle) doc.text(clean(`Module : ${input.moduleTitle}`));
  if (input.trainerName) doc.text(clean(`Formateur : ${input.trainerName}`));
  if (input.roomName) doc.text(clean(`Salle : ${input.roomName}`));
  doc.fillColor(INK);

  section(doc, "Présences");
  const left = doc.page.margins.left;
  const width = doc.page.width - left - doc.page.margins.right;
  const cols = [0.3, 0.17, 0.17, 0.1, 0.26];
  const xs = cols.reduce<number[]>((acc, c, i) => [...acc, (acc[i] ?? left) + (i ? cols[i - 1] * width : 0)], []);
  const header = ["Apprenant", "Statut", "Arrivée / départ", "Durée", "Signature"];
  doc.font("Helvetica-Bold").fontSize(8).fillColor(MUTED);
  let y = doc.y;
  header.forEach((h, i) => doc.text(h, xs[i], y, { width: cols[i] * width - 6 }));
  y += 14;
  doc.moveTo(left, y).lineTo(left + width, y).strokeColor(LINE).lineWidth(0.5).stroke();
  y += 4;
  for (const r of input.rows) {
    const rowH = 30;
    if (y + rowH > doc.page.height - doc.page.margins.bottom) {
      doc.addPage();
      y = doc.page.margins.top;
    }
    doc.font("Helvetica").fontSize(9).fillColor(INK);
    doc.text(clean(`${r.lastName.toUpperCase()} ${r.firstName}`), xs[0], y + 4, { width: cols[0] * width - 6 });
    doc.font("Helvetica").fontSize(7.5).fillColor(MUTED).text(clean(r.reference), xs[0], y + 16, { width: cols[0] * width - 6 });
    doc.font("Helvetica").fontSize(9).fillColor(INK).text(clean(r.statusLabel), xs[1], y + 4, { width: cols[1] * width - 6 });
    const times = [r.arrivedAt ? `arr. ${r.arrivedAt}` : null, r.leftAt ? `dép. ${r.leftAt}` : null].filter(Boolean).join(" / ") || "-";
    doc.text(clean(times), xs[2], y + 4, { width: cols[2] * width - 6 });
    doc.text(fmtMinutes(r.minutes), xs[3], y + 4, { width: cols[3] * width - 6, align: "right" });
    if (r.signature) {
      try {
        doc.image(r.signature, xs[4], y + 1, { fit: [cols[4] * width - 10, rowH - 4] });
      } catch {
        doc.fontSize(8).fillColor(MUTED).text("Signature illisible", xs[4], y + 4);
      }
    } else if (r.signedAt) {
      doc.fontSize(8).fillColor(MUTED).text(clean(`Signé (${r.method ?? "en ligne"}) ${fmtDate(r.signedAt, "d/MM HH:mm")}`), xs[4], y + 4, { width: cols[4] * width - 6 });
    } else {
      doc.fontSize(8).fillColor(MUTED).text("Non signé", xs[4], y + 4, { width: cols[4] * width - 6 });
    }
    y += rowH;
    doc.moveTo(left, y).lineTo(left + width, y).strokeColor(LINE).lineWidth(0.3).stroke();
    y += 2;
  }
  doc.y = y + 10;
  doc.x = left;
  section(doc, "Signature de fin du formateur");
  doc.font("Helvetica").fontSize(9.5).fillColor(INK);
  if (input.trainerSignedAt) {
    doc.text(clean(`Signée le ${fmtDate(input.trainerSignedAt, "d MMMM yyyy 'à' HH:mm")} (heure de Paris).`));
    if (input.trainerSignature) {
      try {
        doc.image(input.trainerSignature, left, doc.y + 4, { fit: [160, 50] });
        doc.y += 58;
      } catch {
        // image invalide : la mention textuelle suffit
      }
    }
  } else {
    doc.fillColor("#8a5a00").text("Aucune signature de fin du formateur enregistrée.");
    doc.fillColor(INK);
  }
  doc.moveDown(0.5);
  doc.font("Helvetica").fontSize(8.5).fillColor(MUTED).text(clean(`Période clôturée le ${fmtDate(input.closedAt, "d MMMM yyyy 'à' HH:mm")}${input.closedByName ? ` par ${input.closedByName}` : ""}. Les présences sont verrouillées ; toute correction suit le circuit tracé (demande, décision, application) sans effacer l'original.`));
  writeFooter(doc, input.org, "Feuille d'émargement par période (F06)");
  doc.end();
  return done;
}
