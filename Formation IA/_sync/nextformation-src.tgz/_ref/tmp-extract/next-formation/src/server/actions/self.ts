"use server";

import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { randomToken, sha256 } from "@/lib/crypto";
import { todayParis } from "@/lib/time";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { createDocument } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { assertEnrollmentInExtranetScope, EXTRANET_ORG_COOKIE, getLearnerContext } from "@/server/extranet/context";
import { listPieces } from "@/server/extranet/queries";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

async function requireLearner() {
  const ctx = await getLearnerContext();
  if (!ctx) throw new Error("Aucun dossier apprenant rattaché à votre compte.");
  return ctx;
}

async function readFile(formData: FormData, field = "file"): Promise<{ name: string; mime: string; data: Buffer }> {
  const f = formData.get(field);
  if (!(f instanceof File) || !f.size) throw new Error("Sélectionnez un fichier à déposer.");
  const data = Buffer.from(await f.arrayBuffer());
  const check = checkUpload({ name: f.name, type: f.type, size: f.size, head: data.subarray(0, 8) });
  if (!check.ok) throw new Error(check.error);
  return { name: f.name, mime: check.mime, data };
}

/* ------------------------------------------------------------------ */
/* Sélecteur d'organisme (tous extranets)                              */
/* ------------------------------------------------------------------ */

/** Mémorise l'organisme choisi quand l'utilisateur a plusieurs rattachements (cookie, 1 an). */
export async function switchExtranetOrgAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const jar = await cookies();
    jar.set(EXTRANET_ORG_COOKIE, orgId, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 365 * 86400 });
    return { ok: true };
  } catch (e) {
    return fail(e, "Impossible de changer d'organisme.");
  }
}

/* ------------------------------------------------------------------ */
/* Apprenant : justificatif d'absence                                  */
/* ------------------------------------------------------------------ */

/**
 * Dépôt d'un justificatif d'absence par l'apprenant : document catégorie `justificatif` relié à l'inscription,
 * tâche de contrôle pour l'administratif. La présence elle-même n'est jamais modifiée ici : seul l'organisme
 * décide d'une absence justifiée (F06), et une période clôturée passe par une correction tracée.
 */
export async function uploadJustificationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireLearner();
    const attendanceId = uuid.parse(formData.get("attendanceId"));
    const note = z.string().trim().max(500, "500 caractères maximum").optional().parse(formData.get("note") ?? undefined);
    const [att] = await db
      .select({ a: schema.attendances, date: schema.slots.date, part: schema.periods.part })
      .from(schema.attendances)
      .innerJoin(schema.periods, eq(schema.periods.id, schema.attendances.periodId))
      .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
      .where(and(eq(schema.attendances.id, attendanceId), eq(schema.attendances.orgId, ctx.org.id), eq(schema.attendances.isCurrent, true)))
      .limit(1);
    if (!att) return { error: "Présence introuvable." };
    assertEnrollmentInExtranetScope(ctx, att.a.enrollmentId);
    if (!["absent", "absent_justifie", "excuse", "retard", "depart_anticipe", "retard_et_depart"].includes(att.a.status)) {
      return { error: "Un justificatif ne peut être déposé que pour une absence, un retard ou un départ anticipé." };
    }
    const file = await readFile(formData);
    const partLabel = att.part === "matin" ? "matin" : att.part === "apres_midi" ? "après-midi" : att.part;
    const doc = await createDocument({
      orgId: ctx.org.id,
      personId: ctx.person.id,
      enrollmentId: att.a.enrollmentId,
      category: "justificatif",
      visibility: "administratif",
      status: "transmis",
      title: `Justificatif d'absence du ${att.date} (${partLabel})`,
      fileName: file.name,
      mimeType: file.mime,
      data: file.data,
      sourceType: "attendance",
      sourceId: att.a.id,
      uploadedBy: ctx.user.id,
      isDemo: ctx.org.isDemo,
    });
    await createTaskOnce({
      orgId: ctx.org.id,
      title: `Justificatif d'absence à contrôler : ${ctx.person.firstName} ${ctx.person.lastName} (${att.date}, ${partLabel})`,
      description: note ? `Message de l'apprenant : ${note}` : "Justificatif déposé depuis l'extranet apprenant. Décider si l'absence est justifiée.",
      family: "administratif",
      entityType: "enrollment",
      entityId: att.a.enrollmentId,
      entityLabel: `${ctx.person.firstName} ${ctx.person.lastName}`,
      href: `/app/${ctx.org.id}/inscriptions/${att.a.enrollmentId}`,
      assigneeRole: "admin_staff",
      dueDate: todayParis(),
      priority: "normale",
      idempotencyKey: `justificatif:${att.a.id}:depose`,
      createdBy: ctx.user.id,
      source: "extranet",
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "attendance.justification_upload", userId: ctx.user.id, orgId: ctx.org.id, entityType: "attendance", entityId: att.a.id, after: { documentId: doc.id } });
    revalidatePath("/moi/presences");
    return { ok: true, message: "Justificatif transmis à l'organisme. Il sera examiné par l'équipe administrative ; votre présence sera mise à jour après décision." };
  } catch (e) {
    return fail(e, "Le dépôt du justificatif a échoué.");
  }
}

/* ------------------------------------------------------------------ */
/* Apprenant : pièces attendues                                        */
/* ------------------------------------------------------------------ */

/** Dépôt d'une pièce attendue : document relié à l'inscription, statut `deposee`, tâche de relais résolue si elle existe. */
export async function uploadPieceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireLearner();
    const submissionId = uuid.parse(formData.get("submissionId"));
    const rows = await listPieces(ctx.org.id, ctx.enrollmentIds);
    const row = rows.find((r) => r.submission.id === submissionId);
    if (!row) return { error: "Pièce introuvable dans votre dossier." };
    if (row.piece.providedBy !== "apprenant") return { error: "Cette pièce n'est pas à fournir par vous." };
    if (row.submission.status === "acceptee") return { error: "Cette pièce a déjà été acceptée par l'organisme." };
    if (row.submission.status === "non_applicable") return { error: "Cette pièce n'est pas applicable à votre dossier." };
    const file = await readFile(formData);
    const doc = await createDocument({
      orgId: ctx.org.id,
      personId: ctx.person.id,
      enrollmentId: row.submission.enrollmentId,
      category: row.piece.category,
      visibility: "administratif",
      status: "transmis",
      title: row.piece.label,
      fileName: file.name,
      mimeType: file.mime,
      data: file.data,
      sourceType: "piece_submission",
      sourceId: row.submission.id,
      uploadedBy: ctx.user.id,
      previousVersionId: row.submission.documentId ?? null,
      isDemo: ctx.org.isDemo,
    });
    const before = { status: row.submission.status, documentId: row.submission.documentId };
    await db
      .update(schema.pieceSubmissions)
      .set({ status: "deposee", documentId: doc.id, submittedAt: new Date(), submittedBy: ctx.user.id, refusalReason: null, version: row.submission.version + (row.submission.documentId ? 1 : 0) })
      .where(and(eq(schema.pieceSubmissions.id, row.submission.id), eq(schema.pieceSubmissions.orgId, ctx.org.id)));
    // Relais F14 : la cause (pièce manquante) disparaît, la tâche de relais est résolue (jamais supprimée).
    const keys = [`piece:${row.submission.enrollmentId}:${row.piece.code}`, `piece:${row.submission.id}:attendue`, `piece:${row.submission.id}:manquante`];
    for (const k of keys) await resolveTaskByKey(ctx.org.id, k, "Pièce déposée par l'apprenant depuis l'extranet.", ctx.user.id);
    await createTaskOnce({
      orgId: ctx.org.id,
      title: `Pièce à contrôler : ${row.piece.label} (${ctx.person.firstName} ${ctx.person.lastName})`,
      description: "Pièce déposée depuis l'extranet apprenant : accepter ou refuser avec motif.",
      family: "administratif",
      entityType: "enrollment",
      entityId: row.submission.enrollmentId,
      entityLabel: `${ctx.person.firstName} ${ctx.person.lastName}`,
      href: `/app/${ctx.org.id}/inscriptions/${row.submission.enrollmentId}`,
      assigneeRole: "admin_staff",
      idempotencyKey: `piece_controle:${row.submission.id}:v${doc.version}`,
      createdBy: ctx.user.id,
      source: "extranet",
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "piece.submit", userId: ctx.user.id, orgId: ctx.org.id, entityType: "piece_submission", entityId: row.submission.id, before, after: { status: "deposee", documentId: doc.id } });
    revalidatePath("/moi/pieces");
    revalidatePath("/moi");
    return { ok: true, message: `« ${row.piece.label} » déposée. L'organisme la contrôle et vous informe en cas de refus.` };
  } catch (e) {
    return fail(e, "Le dépôt de la pièce a échoué.");
  }
}

/* ------------------------------------------------------------------ */
/* Apprenant : informations personnelles, RGPD                        */
/* ------------------------------------------------------------------ */

const infoSchema = z.object({
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide").max(160).or(z.literal("")),
  phone: z.string().trim().max(30, "Téléphone trop long").or(z.literal("")),
  addressLine1: z.string().trim().max(160).or(z.literal("")),
  addressLine2: z.string().trim().max(160).or(z.literal("")),
  postalCode: z.string().trim().max(10).or(z.literal("")),
  city: z.string().trim().max(80).or(z.literal("")),
});

/** Mise à jour des coordonnées de l'apprenant (identité, dates et données sensibles : non modifiables ici). */
export async function updateMyInfoAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireLearner();
    const d = infoSchema.parse(Object.fromEntries(formData));
    const before = { email: ctx.person.email, phone: ctx.person.phone, addressLine1: ctx.person.addressLine1, addressLine2: ctx.person.addressLine2, postalCode: ctx.person.postalCode, city: ctx.person.city };
    const after = { email: d.email || null, phone: d.phone || null, addressLine1: d.addressLine1 || null, addressLine2: d.addressLine2 || null, postalCode: d.postalCode || null, city: d.city || null };
    await db.update(schema.persons).set(after).where(and(eq(schema.persons.id, ctx.person.id), eq(schema.persons.orgId, ctx.org.id)));
    await audit({ action: "person.self_update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "person", entityId: ctx.person.id, before, after });
    revalidatePath("/moi/informations");
    return { ok: true, message: "Coordonnées enregistrées." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Demande d'export de mes données (RGPD) : tâche pour la direction, une seule par jour. */
export async function requestGdprExportAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireLearner();
    const kind = z.enum(["export", "rectification", "effacement"]).parse(formData.get("kind") ?? "export");
    const detail = z.string().trim().max(1000).optional().parse(formData.get("detail") ?? undefined);
    const labels = { export: "Export de mes données", rectification: "Rectification de mes données", effacement: "Effacement de mes données" };
    const { created } = await createTaskOnce({
      orgId: ctx.org.id,
      title: `Demande RGPD : ${labels[kind].toLowerCase()} (${ctx.person.firstName} ${ctx.person.lastName})`,
      description: `${labels[kind]} demandé depuis l'extranet apprenant.${detail ? ` Précisions : ${detail}` : ""} Délai légal de réponse : un mois.`,
      family: "direction",
      entityType: "person",
      entityId: ctx.person.id,
      entityLabel: `${ctx.person.firstName} ${ctx.person.lastName}`,
      href: `/app/${ctx.org.id}/apprenants/${ctx.person.id}`,
      assigneeRole: "direction",
      dueDate: new Date(Date.now() + 30 * 86400_000).toISOString().slice(0, 10),
      priority: "haute",
      idempotencyKey: `rgpd:${ctx.person.id}:${kind}:${todayParis()}`,
      createdBy: ctx.user.id,
      source: "extranet",
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "gdpr.request", userId: ctx.user.id, orgId: ctx.org.id, entityType: "person", entityId: ctx.person.id, after: { kind } });
    revalidatePath("/moi/informations");
    return created ? { ok: true, message: "Demande transmise à la direction de l'organisme. Réponse sous un mois." } : { ok: true, message: "Votre demande du jour est déjà enregistrée : la direction la traite." };
  } catch (e) {
    return fail(e, "La demande n'a pas pu être enregistrée.");
  }
}

/** Consentement au traitement des données (horodaté, jamais implicite). */
export async function consentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireLearner();
    if (formData.get("consent") !== "on") return { error: "Cochez la case pour donner votre consentement." };
    await db.update(schema.persons).set({ gdprConsentAt: new Date() }).where(and(eq(schema.persons.id, ctx.person.id), eq(schema.persons.orgId, ctx.org.id)));
    await audit({ action: "person.consent", userId: ctx.user.id, orgId: ctx.org.id, entityType: "person", entityId: ctx.person.id });
    revalidatePath("/moi/informations");
    return { ok: true, message: "Consentement enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/* ------------------------------------------------------------------ */
/* Apprenant : enquêtes                                                */
/* ------------------------------------------------------------------ */

/**
 * Ouvre une enquête en attente : le jeton est à usage unique côté e-mail (seul son empreinte est stockée),
 * on en génère donc un nouveau pour cette réponse et on redirige vers la page publique /enquete/[token].
 */
export async function openSurveyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target: string | null = null;
  try {
    const ctx = await requireLearner();
    const responseId = uuid.parse(formData.get("responseId"));
    const [r] = await db.select().from(schema.surveyResponses).where(and(eq(schema.surveyResponses.id, responseId), eq(schema.surveyResponses.orgId, ctx.org.id))).limit(1);
    if (!r || !r.enrollmentId) return { error: "Enquête introuvable." };
    assertEnrollmentInExtranetScope(ctx, r.enrollmentId);
    if (r.submittedAt) return { error: "Vous avez déjà répondu à cette enquête." };
    const token = randomToken(24);
    await db.update(schema.surveyResponses).set({ tokenHash: sha256(token) }).where(eq(schema.surveyResponses.id, r.id));
    await audit({ action: "survey.open_from_extranet", userId: ctx.user.id, orgId: ctx.org.id, entityType: "survey_response", entityId: r.id });
    target = `/enquete/${token}`;
  } catch (e) {
    return fail(e, "Impossible d'ouvrir l'enquête.");
  }
  redirect(target);
}

/* ------------------------------------------------------------------ */
/* Apprenant : e-learning                                              */
/* ------------------------------------------------------------------ */

/** Lancement d'un module : crée ou met à jour la progression (`en_cours`, dernier accès). Le temps n'est jamais validé ici. */
export async function startElearningAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target: string | null = null;
  try {
    const ctx = await requireLearner();
    const moduleId = uuid.parse(formData.get("moduleId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    assertEnrollmentInExtranetScope(ctx, enrollmentId);
    const [m] = await db.select().from(schema.elearningModules).where(and(eq(schema.elearningModules.id, moduleId), eq(schema.elearningModules.orgId, ctx.org.id), eq(schema.elearningModules.isActive, true))).limit(1);
    if (!m) return { error: "Module introuvable." };
    const enr = ctx.enrollments.find((e) => e.enrollment.id === enrollmentId)!;
    const versionId = enr.enrollment.programVersionId ?? enr.session.programVersionId;
    if (m.programVersionId !== versionId) return { error: "Ce module ne fait pas partie de votre programme." };
    const [existing] = await db.select().from(schema.elearningProgress).where(and(eq(schema.elearningProgress.elearningModuleId, m.id), eq(schema.elearningProgress.enrollmentId, enrollmentId))).limit(1);
    if (existing) {
      await db.update(schema.elearningProgress).set({ lastAccessAt: new Date(), status: existing.status === "non_commence" ? "en_cours" : existing.status }).where(eq(schema.elearningProgress.id, existing.id));
    } else {
      await db.insert(schema.elearningProgress).values({ orgId: ctx.org.id, elearningModuleId: m.id, enrollmentId, status: "en_cours", lastAccessAt: new Date() });
    }
    await audit({ action: "elearning.start", userId: ctx.user.id, orgId: ctx.org.id, entityType: "elearning_module", entityId: m.id, after: { enrollmentId } });
    revalidatePath("/moi/elearning");
    if (m.url && /^https?:\/\//.test(m.url)) target = m.url;
    else return { ok: true, message: `Module « ${m.title} » ouvert. Ce contenu est consultable auprès de l'organisme (aucun lien externe déclaré).` };
  } catch (e) {
    return fail(e, "Impossible d'ouvrir le module.");
  }
  redirect(target);
}
