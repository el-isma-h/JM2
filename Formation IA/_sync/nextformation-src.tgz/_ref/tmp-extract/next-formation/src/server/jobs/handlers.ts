import "server-only";
import { and, asc, eq, inArray, isNull, lt, lte } from "drizzle-orm";
import { addDays, format } from "date-fns";
import { db, schema } from "@/db";
import { appUrl } from "@/lib/env";
import { fmtDate } from "@/lib/dates";
import { layoutMail, sendMail } from "@/server/mail";
import { backupTenant } from "@/server/backup";
import { purgeTenant } from "@/server/backup/purge";
import { purgeRateLimits } from "@/server/rate-limit";
// Modules métier déclarant leurs propres traitements (enregistrement dans ./registry).
import "@/server/finance/jobs";
import "@/server/quality/jobs";
import "@/server/integrations/jobs";
import "@/server/integrations/chorus";
import "@/server/workflows/jobs";
import "@/server/missions/service";
import "@/server/certifications/service";

export { registerJobHandler, getJobHandler, knownJobKinds, type JobContext, type JobHandler } from "./registry";
import { registerJobHandler } from "./registry";
import { createOverdueFollowupTasks } from "@/server/pedagogy/service";

export const DEMO_TTL_HOURS = 24;

// ---------- demo:cleanup ----------
registerJobHandler("demo:cleanup", async (job) => {
  const hours = Number(job.payload.olderThanHours ?? DEMO_TTL_HOURS);
  const cutoff = new Date(Date.now() - hours * 3600_000);
  const stale = await db
    .select({ id: schema.tenants.id })
    .from(schema.tenants)
    .where(and(eq(schema.tenants.isDemo, true), lt(schema.tenants.createdAt, cutoff)));
  let users = 0;
  let files = 0;
  for (const t of stale) {
    const r = await purgeTenant(t.id);
    users += r.users;
    files += r.files;
  }
  return { tenantsDeleted: stale.length, usersDeleted: users, filesDeleted: files, cutoff: cutoff.toISOString() };
});

// ---------- maintenance:purge ----------
// Sessions expirées, jetons à usage unique expirés depuis 7 jours, compteurs de limitation de débit périmés.
registerJobHandler("maintenance:purge", async () => {
  const now = new Date();
  const sessions = await db.delete(schema.sessions).where(lt(schema.sessions.expiresAt, now)).returning({ id: schema.sessions.id });
  const tokens = await db
    .delete(schema.oneTimeTokens)
    .where(lt(schema.oneTimeTokens.expiresAt, new Date(now.getTime() - 7 * 86400_000)))
    .returning({ id: schema.oneTimeTokens.id });
  const rateLimits = await purgeRateLimits();
  return { sessionsDeleted: sessions.length, tokensDeleted: tokens.length, rateLimitsDeleted: rateLimits };
});

// ---------- backup:tenant ----------
registerJobHandler("backup:tenant", async (job) => {
  const tenantId = String(job.payload.tenantId ?? job.tenantId ?? "");
  if (!/^[0-9a-f-]{36}$/.test(tenantId)) throw new Error("Paramètre tenantId manquant.");
  const createdBy = typeof job.payload.userId === "string" ? job.payload.userId : null;
  const r = await backupTenant(tenantId, createdBy);
  return { backupId: r.backupId, sizeBytes: r.sizeBytes, sha256: r.sha256 };
});

// ---------- tasks:remind ----------
// Rappel quotidien des tâches en retard ou dues sous `horizonDays` jours, par responsable (une seule fois par jour et par personne).
registerJobHandler("tasks:remind", async (job) => {
  const horizonDays = Number(job.payload.horizonDays ?? 3);
  const today = format(new Date(), "yyyy-MM-dd");
  const until = format(addDays(new Date(), horizonDays), "yyyy-MM-dd");
  const due = await db
    .select({ id: schema.tasks.id, title: schema.tasks.title, dueDate: schema.tasks.dueDate, orgId: schema.tasks.orgId, assigneeUserId: schema.tasks.assigneeUserId, href: schema.tasks.href })
    .from(schema.tasks)
    .where(
      and(
        inArray(schema.tasks.status, ["a_faire", "en_cours", "bloquee"]),
        eq(schema.tasks.isDemo, false),
        lte(schema.tasks.dueDate, until),
        job.orgId ? eq(schema.tasks.orgId, job.orgId) : undefined,
      ),
    )
    .orderBy(asc(schema.tasks.dueDate));
  const byUser = new Map<string, typeof due>();
  for (const t of due) {
    if (!t.assigneeUserId) continue;
    const list = byUser.get(t.assigneeUserId) ?? [];
    list.push(t);
    byUser.set(t.assigneeUserId, list);
  }
  let mails = 0;
  let notConfigured = 0;
  for (const [userId, list] of byUser) {
    const [u] = await db.select({ email: schema.users.email, firstName: schema.users.firstName }).from(schema.users).where(and(eq(schema.users.id, userId), isNull(schema.users.disabledAt))).limit(1);
    if (!u) continue;
    const late = list.filter((t) => t.dueDate && t.dueDate < today);
    const soon = list.filter((t) => !t.dueDate || t.dueDate >= today);
    const li = (t: (typeof list)[number]) => `<li>${t.dueDate ? fmtDate(t.dueDate) : "sans échéance"} : ${escapeHtml(t.title)}</li>`;
    const html = `<p>Bonjour ${escapeHtml(u.firstName)},</p>${late.length ? `<p><strong>${late.length} tâche(s) en retard</strong></p><ul>${late.map(li).join("")}</ul>` : ""}${soon.length ? `<p>À venir sous ${horizonDays} jours :</p><ul>${soon.map(li).join("")}</ul>` : ""}`;
    const res = await sendMail({
      to: u.email,
      subject: late.length ? `${late.length} tâche(s) en retard et ${soon.length} à venir` : `${soon.length} tâche(s) à venir sous ${horizonDays} jours`,
      html: layoutMail("Vos tâches", html, { label: "Ouvrir mes tâches", url: `${appUrl()}/app/${list[0].orgId}/taches` }),
      text: list.map((t) => `${t.dueDate ?? "-"} : ${t.title}`).join("\n"),
      isDemo: false,
    });
    mails++;
    if (res.status === "skipped_not_configured") notConfigured++;
  }
  return { tasks: due.length, recipients: byUser.size, mails, notConfigured, horizonDays };
});

// ---------- followups:remind ----------
// Suivis en entreprise dont la prochaine date est dépassée : une tâche de relais par inscription et par date.
registerJobHandler("followups:remind", async (job) => {
  const orgs = job.orgId
    ? [{ id: job.orgId }]
    : await db.select({ id: schema.organismes.id }).from(schema.organismes).where(eq(schema.organismes.isDemo, false));
  let created = 0;
  for (const o of orgs) {
    const r = await createOverdueFollowupTasks(o.id);
    created += typeof r === "number" ? r : Array.isArray(r) ? r.length : 0;
  }
  return { organismes: orgs.length, tasksCreated: created };
});

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
