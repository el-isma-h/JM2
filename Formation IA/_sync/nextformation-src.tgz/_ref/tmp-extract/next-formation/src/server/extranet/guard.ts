import "server-only";
import { handleAuthError } from "@/server/guard";
import { getEmployerContext, getLearnerContext, getTrainerContext, type EmployerContext, type LearnerContext, type TrainerContext } from "./context";

/**
 * Gardes de page des extranets : sans session, redirection vers /connexion?next=<page> ;
 * avec session mais sans rattachement, retour null (la page affiche `NoAttachment`).
 */
export async function guardLearner(nextPath: string): Promise<LearnerContext | null> {
  try {
    return await getLearnerContext();
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}

export async function guardEmployer(nextPath: string): Promise<EmployerContext | null> {
  try {
    return await getEmployerContext();
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}

export async function guardTrainer(nextPath: string): Promise<TrainerContext | null> {
  try {
    return await getTrainerContext();
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}
