import "server-only";
import { and, eq, inArray, isNotNull, notInArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { audit } from "@/server/audit";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { registerJobHandler } from "@/server/jobs/registry";
import { CERTIFIER_LABELS, FINAL_CERT_STATUSES, PRE_PLANNING_STATUSES, certificationAlert, credentialLeak, normalizeCertifier, type CertStatus, type Certifier } from "./rules";

/**
 * Certifications externes (TOSA, ICDL, TOEIC, Certificat Voltaire, CléA) : une ligne `certification_registrations`
 * par inscription dont la formation porte un certificateur externe (`programs.externalCertifier`).
 * Suivi du statut (à inscrire → compte créé → inscrit → voucher envoyé → session planifiée → passée → réussie / échouée),
 * du score de positionnement, de la référence de voucher, de la date d'examen et du score.
 * Les identifiants et mots de passe des plateformes certificateurs ne sont JAMAIS stockés ici.
 */

type Registration = typeof schema.certificationRegistrations.$inferSelect;

export class CertificationError extends Error {}

export const certTaskKeys = {
  toRegister: (regId: string) => `certif:${regId}:a_inscrire_j15`,
  voltaire: (regId: string, examDate: string) => `certif:${regId}:voltaire_j15:${examDate}`,
};

const certHref = (orgId: string, certifier?: string) => `/app/${orgId}/examens/certifications${certifier ? `?certificateur=${certifier}` : ""}`;

/** Programme (et certificateur) d'une inscription : version contractualisée, sinon version de la session. */
async function enrollmentProgram(orgId: string, enrollmentId: string) {
  const [row] = await db
    .select({
      e: schema.enrollments,
      externalCertifier: schema.programs.externalCertifier,
      programTitle: schema.programs.title,
    })
    .from(schema.enrollments)
    .innerJoin(schema.trainingSessions, and(eq(schema.trainingSessions.id, schema.enrollments.sessionId), eq(schema.trainingSessions.orgId, orgId)))
    .innerJoin(schema.programVersions, eq(schema.programVersions.id, sql`coalesce(${schema.enrollments.programVersionId}, ${schema.trainingSessions.programVersionId})`))
    .innerJoin(schema.programs, and(eq(schema.programs.id, schema.programVersions.programId), eq(schema.programs.orgId, orgId)))
    .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)))
    .limit(1);
  return row ?? null;
}

/**
 * À appeler après la création (ou la confirmation) d'une inscription : si la formation porte un certificateur externe,
 * crée l'inscription à la certification au statut « à inscrire » (une seule par inscription et par certificateur, idempotent,
 * y compris en cas d'appels simultanés). Retourne null si la formation n'a pas de certification externe.
 */
export async function ensureCertificationRegistration(orgId: string, enrollmentId: string, opts: { userId?: string | null } = {}): Promise<{ registration: Registration; created: boolean } | null> {
  const p = await enrollmentProgram(orgId, enrollmentId);
  if (!p) return null;
  const certifier = normalizeCertifier(p.externalCertifier);
  if (!certifier) return null;
  if (p.e.status === "annule" || p.e.status === "abandon") return null;
  const result = await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${`nextformation:certif:${enrollmentId}:${certifier}`}))`);
    const [existing] = await tx
      .select()
      .from(schema.certificationRegistrations)
      .where(and(eq(schema.certificationRegistrations.orgId, orgId), eq(schema.certificationRegistrations.enrollmentId, enrollmentId), eq(schema.certificationRegistrations.certifier, certifier), notInArray(schema.certificationRegistrations.status, ["annulee"])))
      .limit(1);
    if (existing) return { registration: existing, created: false };
    const [reg] = await tx
      .insert(schema.certificationRegistrations)
      .values({ orgId, enrollmentId, certifier, module: certifier === "autre" ? p.externalCertifier : null, status: "a_inscrire" })
      .returning();
    return { registration: reg, created: true };
  });
  if (result.created) {
    await audit({ action: "certification.create", userId: opts.userId ?? null, orgId, entityType: "certification_registration", entityId: result.registration.id, after: { enrollmentId, certifier, source: "automatique" } });
  }
  return result;
}

/** Rattrapage : crée les inscriptions à la certification manquantes pour toutes les inscriptions actives de l'organisme. */
export async function syncCertificationRegistrations(orgId: string, opts: { userId?: string | null } = {}) {
  const rows = await db
    .select({ id: schema.enrollments.id })
    .from(schema.enrollments)
    .innerJoin(schema.trainingSessions, and(eq(schema.trainingSessions.id, schema.enrollments.sessionId), eq(schema.trainingSessions.orgId, orgId)))
    .innerJoin(schema.programVersions, eq(schema.programVersions.id, sql`coalesce(${schema.enrollments.programVersionId}, ${schema.trainingSessions.programVersionId})`))
    .innerJoin(schema.programs, and(eq(schema.programs.id, schema.programVersions.programId), eq(schema.programs.orgId, orgId)))
    .where(
      and(
        eq(schema.enrollments.orgId, orgId),
        notInArray(schema.enrollments.status, ["annule", "abandon"]),
        isNotNull(schema.programs.externalCertifier),
        sql`trim(${schema.programs.externalCertifier}) <> ''`,
        sql`not exists (select 1 from ${schema.certificationRegistrations} cr where cr.enrollment_id = ${schema.enrollments.id} and cr.org_id = ${orgId} and cr.status <> 'annulee')`,
      ),
    );
  let created = 0;
  for (const r of rows) {
    const res = await ensureCertificationRegistration(orgId, r.id, opts);
    if (res?.created) created++;
  }
  return { checked: rows.length, created };
}

export async function loadRegistration(orgId: string, id: string): Promise<Registration> {
  const [r] = await db.select().from(schema.certificationRegistrations).where(and(eq(schema.certificationRegistrations.id, id), eq(schema.certificationRegistrations.orgId, orgId))).limit(1);
  if (!r) throw new CertificationError("Inscription à la certification introuvable dans cet organisme.");
  return r;
}

export type CertificationPatch = {
  status?: CertStatus;
  module?: string | null;
  positioningScore?: string | null;
  voucherRef?: string | null;
  examDate?: string | null;
  score?: string | null;
  resultNote?: string | null;
};

/** Mise à jour (statut, score, voucher, date d'examen…) ; résout les alertes devenues sans objet. */
export async function updateCertificationRegistration(actor: { orgId: string; userId: string | null }, id: string, patch: CertificationPatch) {
  const before = await loadRegistration(actor.orgId, id);
  for (const v of [patch.module, patch.positioningScore, patch.voucherRef, patch.score, patch.resultNote]) {
    const leak = credentialLeak(v);
    if (leak) throw new CertificationError(leak);
  }
  const next = { ...before, ...Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined)) } as Registration;
  if ((next.status === "reussie" || next.status === "echouee") && !next.examDate) throw new CertificationError("Indiquez la date d'examen avant d'enregistrer un résultat.");
  if (next.status === "session_planifiee" && !next.examDate) throw new CertificationError("Indiquez la date d'examen de la session planifiée.");
  const [r] = await db
    .update(schema.certificationRegistrations)
    .set({ status: next.status, module: next.module, positioningScore: next.positioningScore, voucherRef: next.voucherRef, examDate: next.examDate, score: next.score, resultNote: next.resultNote, updatedAt: new Date() })
    .where(and(eq(schema.certificationRegistrations.id, before.id), eq(schema.certificationRegistrations.orgId, actor.orgId)))
    .returning();
  if (r.status !== "a_inscrire") await resolveTaskByKey(actor.orgId, certTaskKeys.toRegister(r.id), `Statut : ${r.status}.`, actor.userId);
  if (before.examDate && (before.examDate !== r.examDate || !PRE_PLANNING_STATUSES.includes(r.status))) {
    await resolveTaskByKey(actor.orgId, certTaskKeys.voltaire(r.id, before.examDate), before.examDate !== r.examDate ? `Date d'examen modifiée (${r.examDate ?? "aucune"}).` : "Session organisée.", actor.userId);
  }
  await audit({
    action: "certification.update",
    userId: actor.userId,
    orgId: actor.orgId,
    entityType: "certification_registration",
    entityId: r.id,
    before: { status: before.status, examDate: before.examDate, score: before.score, voucherRef: before.voucherRef },
    after: { status: r.status, examDate: r.examDate, score: r.score, voucherRef: r.voucherRef },
  });
  return r;
}

/* ------------------------------------------------------------------ */
/* Job certifications:remind                                           */
/* ------------------------------------------------------------------ */

export type CertificationReminderReport = { checked: number; voltaireAlerts: number; toRegisterAlerts: number };

/**
 * Alertes quotidiennes (une tâche par événement, clé d'idempotence) :
 *  - Certificat Voltaire : 15 jours avant la date d'examen si la session n'est pas encore organisée
 *    (process : « à commander et organiser au moins 15 jours avant la date souhaitée ») ;
 *  - autres certificateurs : statut encore « à inscrire » 15 jours avant la fin de session.
 */
export async function runCertificationReminders(opts: { orgId?: string | null; today?: string } = {}): Promise<CertificationReminderReport> {
  const today = opts.today ?? todayParis();
  const report: CertificationReminderReport = { checked: 0, voltaireAlerts: 0, toRegisterAlerts: 0 };
  const rows = await db
    .select({
      r: schema.certificationRegistrations,
      reference: schema.enrollments.reference,
      enrollmentEnd: schema.enrollments.endDate,
      sessionEnd: schema.trainingSessions.endDate,
      pedagogyManager: schema.trainingSessions.pedagogyManagerUserId,
      adminManager: schema.trainingSessions.adminManagerUserId,
      firstName: schema.persons.firstName,
      lastName: schema.persons.lastName,
      isDemo: schema.organismes.isDemo,
    })
    .from(schema.certificationRegistrations)
    .innerJoin(schema.enrollments, and(eq(schema.enrollments.id, schema.certificationRegistrations.enrollmentId), eq(schema.enrollments.orgId, schema.certificationRegistrations.orgId)))
    .innerJoin(schema.trainingSessions, and(eq(schema.trainingSessions.id, schema.enrollments.sessionId), eq(schema.trainingSessions.orgId, schema.certificationRegistrations.orgId)))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.organismes, eq(schema.organismes.id, schema.certificationRegistrations.orgId))
    .where(and(notInArray(schema.certificationRegistrations.status, FINAL_CERT_STATUSES), notInArray(schema.enrollments.status, ["annule", "abandon"]), opts.orgId ? eq(schema.certificationRegistrations.orgId, opts.orgId) : undefined));

  for (const row of rows) {
    report.checked++;
    const r = row.r;
    const certifier = r.certifier as Certifier;
    const alert = certificationAlert({ certifier, status: r.status as CertStatus, examDate: r.examDate, sessionEndDate: row.enrollmentEnd ?? row.sessionEnd, today });
    if (!alert) continue;
    const who = row.adminManager || row.pedagogyManager ? { assigneeUserId: (row.adminManager ?? row.pedagogyManager)!, assigneeRole: null } : { assigneeUserId: null, assigneeRole: "admin_staff" };
    const learner = `${row.firstName} ${row.lastName}`;
    const label = CERTIFIER_LABELS[certifier] ?? certifier;
    const common = {
      orgId: r.orgId,
      family: "pedagogie",
      entityType: "certification_registration",
      entityId: r.id,
      entityLabel: `${row.reference} · ${learner}`,
      href: certHref(r.orgId, certifier),
      ...who,
      priority: "haute" as const,
      isDemo: row.isDemo,
    };
    if (alert.kind === "voltaire_j15") {
      const res = await createTaskOnce({
        ...common,
        title: `Certificat Voltaire à organiser : ${learner} (examen le ${fmtDate(r.examDate)})`,
        description: `Le Certificat Voltaire se passe uniquement en centre et se commande au moins 15 jours avant la date souhaitée : créez la session sur l'interface du certificateur et importez la grille d'inscription, puis passez le statut à « session planifiée ».`,
        dueDate: r.examDate,
        idempotencyKey: certTaskKeys.voltaire(r.id, r.examDate!),
      });
      if (res.created) report.voltaireAlerts++;
    } else {
      const end = row.enrollmentEnd ?? row.sessionEnd;
      const res = await createTaskOnce({
        ...common,
        title: `Inscrire à la certification ${label} : ${learner}`,
        description: `Fin de formation le ${fmtDate(end)} : l'apprenant n'est pas encore inscrit à la certification ${label}. Effectuez l'inscription sur la plateforme du certificateur puis mettez à jour le statut.`,
        dueDate: end,
        idempotencyKey: certTaskKeys.toRegister(r.id),
      });
      if (res.created) report.toRegisterAlerts++;
    }
  }
  return report;
}

registerJobHandler("certifications:remind", async (job) => {
  const r = await runCertificationReminders({ orgId: job.orgId, today: typeof job.payload.today === "string" ? job.payload.today : undefined });
  return { ...r };
});

/** Compteurs par statut pour la page (filtrés par organisme et éventuellement par sessions du périmètre). */
export async function certificationCounts(orgId: string, sessionIds: string[] | null) {
  const rows = await db
    .select({ status: schema.certificationRegistrations.status, n: sql<number>`count(*)::int` })
    .from(schema.certificationRegistrations)
    .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.certificationRegistrations.enrollmentId))
    .where(and(eq(schema.certificationRegistrations.orgId, orgId), sessionIds ? (sessionIds.length ? inArray(schema.enrollments.sessionId, sessionIds) : sql`false`) : undefined))
    .groupBy(schema.certificationRegistrations.status);
  return Object.fromEntries(rows.map((r) => [r.status, r.n])) as Partial<Record<CertStatus, number>>;
}
