import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";

type Priority = (typeof schema.taskPriorityEnum.enumValues)[number];

export type TaskInput = {
  orgId: string;
  title: string;
  description?: string | null;
  family?: string;
  entityType?: string | null;
  entityId?: string | null;
  entityLabel?: string | null;
  href?: string | null;
  assigneeUserId?: string | null;
  assigneeRole?: string | null;
  dueDate?: string | null;
  priority?: Priority;
  prerequisites?: unknown[];
  blockedReason?: string | null;
  indicatorCode?: string | null;
  createdBy?: string | null;
  source?: string;
  isDemo?: boolean;
  /** Clé d'idempotence : un même événement ne crée qu'une tâche, même après nouvelle tentative (F14). */
  idempotencyKey: string;
};

/**
 * Crée une tâche de relais si elle n'existe pas déjà (même clé d'idempotence dans l'organisme).
 * Retourne { task, created }. Utilisable par tous les modules : pièces manquantes, financement à confirmer,
 * convocation à envoyer, preuve qualité à produire, examen à inscrire…
 */
export async function createTaskOnce(input: TaskInput, tx: Pick<typeof db, "select" | "insert"> = db) {
  const [existing] = await tx
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, input.orgId), eq(schema.tasks.idempotencyKey, input.idempotencyKey)))
    .limit(1);
  if (existing) return { task: existing, created: false as const };
  const [task] = await tx
    .insert(schema.tasks)
    .values({
      orgId: input.orgId,
      title: input.title,
      description: input.description ?? null,
      family: input.family ?? "administratif",
      entityType: input.entityType ?? null,
      entityId: input.entityId ?? null,
      entityLabel: input.entityLabel ?? null,
      href: input.href ?? null,
      assigneeUserId: input.assigneeUserId ?? null,
      assigneeRole: input.assigneeRole ?? null,
      dueDate: input.dueDate ?? null,
      priority: input.priority ?? "normale",
      prerequisites: input.prerequisites ?? [],
      blockedReason: input.blockedReason ?? null,
      status: input.blockedReason ? "bloquee" : "a_faire",
      indicatorCode: input.indicatorCode ?? null,
      createdBy: input.createdBy ?? null,
      source: input.source ?? "automatique",
      isDemo: input.isDemo ?? false,
      idempotencyKey: input.idempotencyKey,
    })
    .onConflictDoNothing({ target: [schema.tasks.orgId, schema.tasks.idempotencyKey] })
    .returning();
  if (!task) {
    const [again] = await tx
      .select()
      .from(schema.tasks)
      .where(and(eq(schema.tasks.orgId, input.orgId), eq(schema.tasks.idempotencyKey, input.idempotencyKey)))
      .limit(1);
    return { task: again, created: false as const };
  }
  await tx.insert(schema.taskEvents).values({ taskId: task.id, kind: "creation", toValue: task.status, userId: input.createdBy ?? null, note: input.source ?? "automatique" });
  return { task, created: true as const };
}

/** Clôture automatique d'une tâche de relais quand sa cause disparaît (ex. pièce reçue). Jamais de suppression. */
export async function resolveTaskByKey(orgId: string, idempotencyKey: string, note: string, userId?: string | null) {
  const [t] = await db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, orgId), eq(schema.tasks.idempotencyKey, idempotencyKey)))
    .limit(1);
  if (!t || t.status === "terminee" || t.status === "annulee") return null;
  const [upd] = await db
    .update(schema.tasks)
    .set({ status: "terminee", completedAt: new Date(), completedBy: userId ?? null, resolutionNote: note, blockedReason: null })
    .where(eq(schema.tasks.id, t.id))
    .returning();
  await db.insert(schema.taskEvents).values({ taskId: t.id, kind: "statut", fromValue: t.status, toValue: "terminee", note, userId: userId ?? null });
  return upd;
}
