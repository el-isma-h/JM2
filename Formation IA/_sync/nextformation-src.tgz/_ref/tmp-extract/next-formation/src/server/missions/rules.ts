/**
 * Règles pures des missions formateurs (testées dans __tests__/rules.test.ts).
 * Process de la cliente : proposition de mission, rappel 5 jours ouvrés plus tard au maximum,
 * puis mobilisation d'un autre formateur en l'absence de réponse ; rémunération = heures × taux horaire.
 */
import { addDays, format, parseISO } from "date-fns";
import { frenchHolidays } from "@/lib/dates";

/** Jours ouvrés avant la relance du formateur (process : « rappel 5 jours ouvrés plus tard maximum »). */
export const MISSION_REMINDER_WORKDAYS = 5;
/** Jours ouvrés laissés après la relance avant de passer la mission en « sans réponse » (paramétrable dans le job). */
export const MISSION_GRACE_WORKDAYS = 2;
/** Jours ouvrés après acceptation pour obtenir la date du premier cours et le planning prévisionnel (process : « rappel 2 j plus tard »). */
export const MISSION_FIRST_LESSON_WORKDAYS = 2;

export const MISSION_STATUS_LABELS: Record<string, string> = {
  proposee: "Proposée",
  acceptee: "Acceptée",
  refusee: "Refusée",
  sans_reponse: "Sans réponse",
  annulee: "Annulée",
  terminee: "Terminée",
};

export const MISSION_STATUS_TONES: Record<string, "neutral" | "ok" | "warn" | "danger" | "info" | "accent"> = {
  proposee: "warn",
  acceptee: "ok",
  refusee: "danger",
  sans_reponse: "danger",
  annulee: "neutral",
  terminee: "neutral",
};

/** Montant de la mission en centimes : heures × taux horaire (centimes). Refuse les valeurs négatives ou non entières. */
export function missionAmountCents(hours: number, hourlyRateCents: number): number {
  if (!Number.isInteger(hours) || hours < 0) throw new Error("Nombre d'heures invalide.");
  if (!Number.isInteger(hourlyRateCents) || hourlyRateCents < 0) throw new Error("Taux horaire invalide.");
  return hours * hourlyRateCents;
}

/** Convertit une saisie en euros (« 25 », « 25,50 », « 25.5 € ») en centimes ; null si vide. */
export function eurosToCents(raw: string | null | undefined): number | null {
  if (raw == null) return null;
  const v = raw.replace(/[\s €]/g, "").replace(",", ".");
  if (!v) return null;
  if (!/^\d+(\.\d{1,2})?$/.test(v)) throw new Error("Montant invalide (ex. 25,00).");
  const [i, d = ""] = v.split(".");
  return Number(i) * 100 + Number(d.padEnd(2, "0"));
}

function holidaysAround(fromIso: string, toIso: string): Set<string> {
  const y1 = Number(fromIso.slice(0, 4));
  const y2 = Number(toIso.slice(0, 4));
  const set = new Set<string>();
  for (let y = Math.min(y1, y2); y <= Math.max(y1, y2) + 1; y++) for (const h of frenchHolidays(y)) set.add(h);
  return set;
}

function isWorkday(iso: string, holidays: Set<string>): boolean {
  const wd = parseISO(iso).getDay();
  return wd !== 0 && wd !== 6 && !holidays.has(iso);
}

/**
 * Jours ouvrés écoulés entre deux dates ISO : le jour de départ n'est pas compté, le jour d'arrivée l'est.
 * Ex. proposition le vendredi, aujourd'hui le lundi suivant : 1 jour ouvré écoulé. Jours fériés français exclus.
 */
export function workdaysElapsed(fromIso: string, toIso: string): number {
  if (toIso <= fromIso) return 0;
  const holidays = holidaysAround(fromIso, toIso);
  let n = 0;
  let d = addDays(parseISO(fromIso), 1);
  const end = parseISO(toIso);
  while (d <= end) {
    if (isWorkday(format(d, "yyyy-MM-dd"), holidays)) n++;
    d = addDays(d, 1);
  }
  return n;
}

/** Date ISO tombant `n` jours ouvrés après `fromIso` (jours fériés français exclus). */
export function addWorkdays(fromIso: string, n: number): string {
  const holidays = holidaysAround(fromIso, format(addDays(parseISO(fromIso), n * 2 + 14), "yyyy-MM-dd"));
  let d = parseISO(fromIso);
  let left = n;
  while (left > 0) {
    d = addDays(d, 1);
    if (isWorkday(format(d, "yyyy-MM-dd"), holidays)) left--;
  }
  return format(d, "yyyy-MM-dd");
}

export type ReminderStep = "none" | "remind" | "no_response";

/**
 * Étape du job missions:remind pour une mission « proposée » :
 *  - relance du formateur après `reminderDays` jours ouvrés sans réponse ;
 *  - puis, `graceDays` jours ouvrés après la relance, passage en « sans réponse » (tâche « Trouver un remplaçant »).
 * `proposedOn` et `remindedOn` sont des dates ISO (Paris).
 */
export function reminderStep(input: { proposedOn: string; remindedOn: string | null; today: string; reminderDays?: number; graceDays?: number }): ReminderStep {
  const reminderDays = input.reminderDays ?? MISSION_REMINDER_WORKDAYS;
  const graceDays = input.graceDays ?? MISSION_GRACE_WORKDAYS;
  if (!input.remindedOn) return workdaysElapsed(input.proposedOn, input.today) >= reminderDays ? "remind" : "none";
  return workdaysElapsed(input.remindedOn, input.today) >= graceDays ? "no_response" : "none";
}
