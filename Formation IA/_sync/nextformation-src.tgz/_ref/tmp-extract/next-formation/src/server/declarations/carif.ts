/**
 * Déclaration Carif-Oref d'une session (onglet 7 « Sessions » du guide de saisie Carif-Oref Occitanie, janvier 2025).
 * Module pur (sans accès base) : importable par le formulaire client et par les actions serveur.
 *
 * Listes reprises du guide :
 * - types de recrutement (bloc « Recrutement ») ;
 * - périmètre de recrutement (Autres, Commune, Département, Région, Interrégion, Pays, International) ;
 * - contraintes horaires : début et fin obligatoires, entre 07:00 et 20:00, fin après début ;
 *   date non antérieure au jour de saisie et pas après la fin de la session.
 * Le guide ne fournit pas de liste fermée pour « Publics / Financement » : ces lignes restent en saisie libre.
 */

export const CARIF_RECRUITMENT_TYPES = [
  { value: "information_inconnue", label: "Information inconnue" },
  { value: "simulation", label: "Méthode de recrutement par simulation" },
  { value: "concours", label: "Concours" },
  { value: "dossier", label: "Dossier" },
  { value: "tests_pratiques", label: "Tests pratiques" },
  { value: "epreuves_ecrites", label: "Épreuves écrites" },
  { value: "epreuves_orales", label: "Épreuves orales" },
  { value: "inscription_candidature", label: "Inscription sur candidature" },
  { value: "entretien_individuel", label: "Entretien ou RDV individuel" },
  { value: "information_collective", label: "Information collective" },
] as const;

export const CARIF_RECRUITMENT_PERIMETERS = [
  { value: "autres", label: "Autres" },
  { value: "commune", label: "Commune" },
  { value: "departement", label: "Département" },
  { value: "region", label: "Région" },
  { value: "interregion", label: "Interrégion" },
  { value: "pays", label: "Pays" },
  { value: "international", label: "International" },
] as const;

export type CarifRecruitmentType = (typeof CARIF_RECRUITMENT_TYPES)[number]["value"];
export type CarifPerimeter = (typeof CARIF_RECRUITMENT_PERIMETERS)[number]["value"];

export type CarifRecruitment = {
  type: CarifRecruitmentType;
  perimeter: CarifPerimeter | "";
  /** Date de l'étape (information collective, épreuve…), AAAA-MM-JJ ; facultative. */
  date: string;
  startTime: string;
  endTime: string;
  details: string;
};

export type CarifPublic = {
  /** Type de public attendu (saisie libre, valeurs proposées par la plateforme Carif-Oref). */
  audience: string;
  /** Modalités pédagogiques. */
  modalities: string;
  /** Financeur(s) de la session. */
  funder: string;
};

export const CARIF_TIME_MIN = "07:00";
export const CARIF_TIME_MAX = "20:00";

export const carifRecruitmentTypeLabel = (v: string) => CARIF_RECRUITMENT_TYPES.find((t) => t.value === v)?.label ?? v;
export const carifPerimeterLabel = (v: string) => CARIF_RECRUITMENT_PERIMETERS.find((t) => t.value === v)?.label ?? v;

const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const s = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

/** Lecture tolérante d'une valeur jsonb stockée (lignes invalides ignorées). */
export function readCarifRecruitment(raw: unknown): CarifRecruitment[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((r): r is Record<string, unknown> => Boolean(r) && typeof r === "object")
    .map((r) => ({
      type: (CARIF_RECRUITMENT_TYPES.some((t) => t.value === r.type) ? r.type : "information_inconnue") as CarifRecruitmentType,
      perimeter: (CARIF_RECRUITMENT_PERIMETERS.some((t) => t.value === r.perimeter) ? r.perimeter : "") as CarifPerimeter | "",
      date: ISO.test(s(r.date, 10)) ? s(r.date, 10) : "",
      startTime: HHMM.test(s(r.startTime, 5)) ? s(r.startTime, 5) : "",
      endTime: HHMM.test(s(r.endTime, 5)) ? s(r.endTime, 5) : "",
      details: s(r.details, 500),
    }));
}

export function readCarifPublics(raw: unknown): CarifPublic[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((r): r is Record<string, unknown> => Boolean(r) && typeof r === "object")
    .map((r) => ({ audience: s(r.audience, 300), modalities: s(r.modalities, 300), funder: s(r.funder, 300) }))
    .filter((p) => p.audience || p.modalities || p.funder);
}

/**
 * Valide les lignes de recrutement saisies selon les règles du guide.
 * `previous` : lignes déjà enregistrées ; une ligne identique déjà présente n'est pas rejetée parce que sa date est passée
 * (la règle « pas antérieure à la date du jour » s'applique à la saisie, pas à l'historique).
 */
export function validateCarifRecruitment(lines: CarifRecruitment[], opts: { today: string; sessionEnd: string; previous: CarifRecruitment[] }): string | null {
  const key = (l: CarifRecruitment) => JSON.stringify([l.type, l.perimeter, l.date, l.startTime, l.endTime, l.details]);
  const known = new Set(opts.previous.map(key));
  for (const [i, l] of lines.entries()) {
    const n = `Recrutement, ligne ${i + 1}`;
    if (!CARIF_RECRUITMENT_TYPES.some((t) => t.value === l.type)) return `${n} : type de recrutement inconnu.`;
    if (l.perimeter && !CARIF_RECRUITMENT_PERIMETERS.some((t) => t.value === l.perimeter)) return `${n} : périmètre inconnu.`;
    const hasSlot = Boolean(l.date || l.startTime || l.endTime);
    if (!hasSlot) continue;
    if (!l.date || !ISO.test(l.date)) return `${n} : date requise (AAAA-MM-JJ) dès qu'un horaire est saisi.`;
    if (!l.startTime || !HHMM.test(l.startTime)) return `${n} : l'heure de début est obligatoire.`;
    if (!l.endTime || !HHMM.test(l.endTime)) return `${n} : l'heure de fin est obligatoire.`;
    if (l.startTime < CARIF_TIME_MIN || l.startTime > CARIF_TIME_MAX) return `${n} : l'heure de début doit être comprise entre 07:00 et 20:00.`;
    if (l.endTime < CARIF_TIME_MIN || l.endTime > CARIF_TIME_MAX) return `${n} : l'heure de fin doit être comprise entre 07:00 et 20:00.`;
    if (l.endTime <= l.startTime) return `${n} : l'heure de fin doit être postérieure à l'heure de début.`;
    if (l.date > opts.sessionEnd) return `${n} : la date ne peut pas être postérieure à la fin de la session.`;
    if (l.date < opts.today && !known.has(key(l))) return `${n} : la date ne peut pas être antérieure à la date du jour.`;
  }
  return null;
}
