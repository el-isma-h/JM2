import "server-only";

export type MoodleSiteInfo = { sitename: string; release?: string; username?: string; functions?: unknown[] };

/** Test de connexion réel à l'API REST Moodle (core_webservice_get_site_info). Aucun secret journalisé. */
export async function testMoodleConnection(baseUrl: string, token: string): Promise<{ ok: true; info: MoodleSiteInfo } | { ok: false; error: string }> {
  let url: URL;
  try {
    url = new URL(baseUrl);
    if (url.protocol !== "https:" && url.protocol !== "http:") throw new Error("protocole");
  } catch {
    return { ok: false, error: "Adresse Moodle invalide (https://moodle.exemple.fr)." };
  }
  const endpoint = new URL("/webservice/rest/server.php", url);
  endpoint.searchParams.set("wstoken", token);
  endpoint.searchParams.set("wsfunction", "core_webservice_get_site_info");
  endpoint.searchParams.set("moodlewsrestformat", "json");
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch(endpoint, { signal: ctrl.signal, headers: { Accept: "application/json" }, cache: "no-store" });
    if (!res.ok) return { ok: false, error: `Le serveur Moodle a répondu ${res.status}.` };
    const body = (await res.json()) as Partial<MoodleSiteInfo> & { exception?: string; message?: string; errorcode?: string };
    if (body.exception || body.errorcode) return { ok: false, error: `Moodle : ${body.message ?? body.errorcode ?? "jeton refusé"}.` };
    if (!body.sitename) return { ok: false, error: "Réponse Moodle inattendue (sitename absent)." };
    return { ok: true, info: { sitename: body.sitename, release: body.release, username: body.username, functions: body.functions } };
  } catch (e) {
    const msg = e instanceof Error && e.name === "AbortError" ? "délai dépassé (8 s)" : e instanceof Error ? e.message : "erreur réseau";
    return { ok: false, error: `Connexion impossible : ${msg}.` };
  } finally {
    clearTimeout(timer);
  }
}
