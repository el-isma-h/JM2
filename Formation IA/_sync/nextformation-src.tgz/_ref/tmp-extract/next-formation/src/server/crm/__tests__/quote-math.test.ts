import { describe, expect, it } from "vitest";
import { computeTotals, formatQuoteNumber, lineVatCents, parseLines } from "../quote-math";

describe("devis : totaux en centimes", () => {
  it("additionne HT et calcule la TVA par taux", () => {
    const t = computeTotals([
      { label: "Formation", qty: 2, unitCents: 120000, vatRateBp: 2000 },
      { label: "Support", qty: 1, unitCents: 1550, vatRateBp: 2000 },
      { label: "Action exonérée", qty: 3, unitCents: 50000, vatRateBp: 0 },
    ]);
    expect(t.totalHtCents).toBe(240000 + 1550 + 150000);
    expect(t.vatCents).toBe(Math.round((241550 * 2000) / 10000));
    expect(t.totalTtcCents).toBe(t.totalHtCents + t.vatCents);
    expect(t.byRate.map((r) => r.rateBp)).toEqual([0, 2000]);
  });
  it("arrondit au centime le plus proche", () => {
    expect(lineVatCents({ qty: 1, unitCents: 1, vatRateBp: 2000 })).toBe(0);
    expect(lineVatCents({ qty: 1, unitCents: 3, vatRateBp: 2000 })).toBe(1);
    expect(lineVatCents({ qty: 0.5, unitCents: 999, vatRateBp: 550 })).toBe(Math.round((500 * 550) / 10000));
  });
  it("numérote DEV-AAAA-NNNN", () => {
    expect(formatQuoteNumber(2026, 1)).toBe("DEV-2026-0001");
    expect(formatQuoteNumber(2026, 12345)).toBe("DEV-2026-12345");
  });
  it("refuse les lignes invalides", () => {
    expect(parseLines([]).ok).toBe(false);
    expect(parseLines([{ label: "", qty: 1, unitCents: 10, vatRateBp: 0 }]).ok).toBe(false);
    expect(parseLines([{ label: "x", qty: 0, unitCents: 10, vatRateBp: 0 }]).ok).toBe(false);
    expect(parseLines([{ label: "x", qty: 1, unitCents: 10.5, vatRateBp: 0 }]).ok).toBe(false);
    const ok = parseLines([{ label: " Formation ", qty: "2", unitCents: "1000", vatRateBp: "2000", description: "" }]);
    expect(ok.ok && ok.lines[0]).toEqual({ label: "Formation", description: null, qty: 2, unitCents: 1000, vatRateBp: 2000 });
  });
});
