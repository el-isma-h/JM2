import "server-only";
import { registerJobHandler, type JobHandler } from "@/server/jobs/registry";
import { notify } from "@/server/notify";
import { orgStaff } from "@/server/tasks/queries";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { overdueWorkflowTasks } from "./service";

/**
 * workflows:remind : notification interne pour chaque étape de parcours en retard (tâche `wf:*` ouverte et échue).
 * Destinataire : le responsable nommé, sinon les membres actifs du rôle assigné. Une notification par tâche,
 * par personne et par jour (dedupeKey). À planifier quotidiennement (RECURRING_JOBS).
 */
export const workflowsRemindJob: JobHandler = async (job) => {
  const today = typeof job.payload.today === "string" ? job.payload.today : todayParis();
  const overdue = await overdueWorkflowTasks(job.orgId, today);
  const staffByOrg = new Map<string, Awaited<ReturnType<typeof orgStaff>>>();
  let notifications = 0;
  let unassigned = 0;
  for (const t of overdue) {
    let recipients: string[] = [];
    if (t.assigneeUserId) recipients = [t.assigneeUserId];
    else if (t.assigneeRole) {
      let staff = staffByOrg.get(t.orgId);
      if (!staff) {
        staff = await orgStaff(t.orgId);
        staffByOrg.set(t.orgId, staff);
      }
      recipients = staff.filter((u) => u.roles.includes(t.assigneeRole!)).map((u) => u.id);
    }
    if (!recipients.length) {
      unassigned++;
      continue;
    }
    for (const userId of recipients) {
      await notify({
        orgId: t.orgId,
        userId,
        title: `Étape de parcours en retard : ${t.title}`,
        body: `Échéance dépassée depuis le ${fmtDate(t.dueDate!)}.`,
        href: t.href ?? `/app/${t.orgId}/taches`,
        kind: "task",
        dedupeKey: `wf-remind:${t.id}:${today}`,
      });
      notifications++;
    }
  }
  return { today, overdue: overdue.length, notifications, unassigned };
};

registerJobHandler("workflows:remind", workflowsRemindJob);
