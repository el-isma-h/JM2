import "server-only";
import { and, asc, eq, gte, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { todayParis } from "@/lib/time";

/**
 * Catalogue public d'un organisme repéré par le slug de son tenant (sans session).
 * Si le tenant gère plusieurs organismes, le premier organisme ayant au moins un programme publié est retenu.
 */
export async function loadPublicCatalogue(orgSlug: string) {
  if (!/^[a-z0-9-]{1,64}$/.test(orgSlug)) return null;
  const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.slug, orgSlug)).limit(1);
  if (!tenant || (tenant.settings as { archive?: unknown })?.archive) return null;
  const orgs = await db.select().from(schema.organismes).where(eq(schema.organismes.tenantId, tenant.id)).orderBy(asc(schema.organismes.createdAt));
  if (!orgs.length) return null;
  let org = orgs[0];
  if (orgs.length > 1) {
    for (const o of orgs) {
      const [p] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.orgId, o.id), eq(schema.programs.isPublished, true))).limit(1);
      if (p) {
        org = o;
        break;
      }
    }
  }
  return loadCatalogueForOrg(tenant, org);
}

/**
 * Catalogue public repéré par le slug du tenant (comme `loadPublicCatalogue`) ou par l'identifiant de
 * l'organisme (UUID) : utile quand un tenant gère plusieurs organismes (API, widget, plugin WordPress).
 */
export async function loadPublicCatalogueByRef(ref: string) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(ref)) return loadPublicCatalogue(ref);
  const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, ref)).limit(1);
  if (!org) return null;
  const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, org.tenantId)).limit(1);
  if (!tenant || (tenant.settings as { archive?: unknown })?.archive) return null;
  return loadCatalogueForOrg(tenant, org);
}

async function loadCatalogueForOrg(tenant: typeof schema.tenants.$inferSelect, org: typeof schema.organismes.$inferSelect) {
  const programs = await db
    .select()
    .from(schema.programs)
    .where(and(eq(schema.programs.orgId, org.id), eq(schema.programs.isPublished, true), eq(schema.programs.status, "actif")))
    .orderBy(asc(schema.programs.title));
  const programIds = programs.map((p) => p.id);
  const versions = programIds.length
    ? await db.select().from(schema.programVersions).where(and(eq(schema.programVersions.orgId, org.id), inArray(schema.programVersions.programId, programIds), eq(schema.programVersions.status, "active")))
    : [];
  const versionIds = versions.map((v) => v.id);
  const sessions = versionIds.length
    ? await db
        .select({ id: schema.trainingSessions.id, programVersionId: schema.trainingSessions.programVersionId, title: schema.trainingSessions.title, startDate: schema.trainingSessions.startDate, endDate: schema.trainingSessions.endDate, modality: schema.trainingSessions.modality, capacity: schema.trainingSessions.capacity, kind: schema.trainingSessions.kind, priceCents: schema.trainingSessions.priceCents, status: schema.trainingSessions.status })
        .from(schema.trainingSessions)
        .where(and(eq(schema.trainingSessions.orgId, org.id), inArray(schema.trainingSessions.programVersionId, versionIds), eq(schema.trainingSessions.isPublished, true), gte(schema.trainingSessions.startDate, todayParis()), inArray(schema.trainingSessions.status, ["ouverte", "confirmee"])))
        .orderBy(asc(schema.trainingSessions.startDate))
    : [];
  const certIds = [...new Set(programs.map((p) => p.certificationId).filter((x): x is string => Boolean(x)))];
  const certs = certIds.length ? await db.select().from(schema.certifications).where(and(eq(schema.certifications.orgId, org.id), inArray(schema.certifications.id, certIds))) : [];

  const items = programs.map((p) => {
    const version = versions.find((v) => v.programId === p.id) ?? null;
    const cert = certs.find((c) => c.id === p.certificationId) ?? null;
    return {
      program: p,
      version,
      certification: cert,
      sessions: version ? sessions.filter((s) => s.programVersionId === version.id) : [],
    };
  });
  return { tenant, org, items };
}

export type PublicCatalogue = NonNullable<Awaited<ReturnType<typeof loadPublicCatalogue>>>;

/** Clé de famille comparable (catégorie du programme) : minuscules, sans accents ni ponctuation. */
export function familyKey(v: string | null | undefined): string {
  return (v ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/** Familles présentes (catégories des programmes publiés), triées. */
export function catalogueFamilies(data: PublicCatalogue): { key: string; label: string }[] {
  const out = new Map<string, string>();
  for (const { program } of data.items) if (program.category?.trim()) out.set(familyKey(program.category), program.category.trim());
  return [...out.entries()].map(([key, label]) => ({ key, label })).sort((a, b) => a.label.localeCompare(b.label, "fr"));
}

/** Filtre par famille (catégorie) ; famille vide = tout le catalogue. */
export function filterByFamily(data: PublicCatalogue, famille: string | null | undefined): PublicCatalogue {
  const k = familyKey(famille);
  if (!k) return data;
  return { ...data, items: data.items.filter(({ program }) => familyKey(program.category) === k) };
}

export function publicCatalogueJson(data: NonNullable<Awaited<ReturnType<typeof loadPublicCatalogue>>>) {
  const { org, items } = data;
  return {
    organisme: {
      nom: org.tradeName ?? org.legalName,
      raisonSociale: org.legalName,
      siret: org.siret,
      nda: org.nda,
      ville: org.city,
      siteWeb: org.website,
      qualiopi: org.qualiopiNumber ? { numero: org.qualiopiNumber, certificateur: org.qualiopiCertifier, validite: org.qualiopiValidUntil } : null,
      couleur: org.primaryColor,
    },
    formations: items.map(({ program, version, certification, sessions }) => ({
      id: program.id,
      code: program.code,
      slug: program.slug,
      titre: program.title,
      type: program.kind,
      categorie: program.category,
      apprentissage: program.availableAsApprenticeship,
      formationContinue: program.availableAsContinuing,
      eligibleCpf: program.cpfEligible,
      certification: certification ? { titre: certification.title, rncp: certification.rncpCode, rs: certification.rsCode, niveau: certification.level } : null,
      programme: version
        ? {
            version: version.version,
            objectifs: version.objectives,
            prerequis: version.prerequisites,
            public: version.audience,
            modalite: version.modality,
            dureeHeures: version.durationHours,
            dureeJours: version.durationDays,
            contenu: version.content,
            methodes: version.methods,
            evaluation: version.evaluationMethods,
            accessibilite: version.accessibility,
            delaiAcces: version.accessDelay,
            tarifHtCents: version.priceCents,
            tarifNote: version.priceNote,
          }
        : null,
      sessions: sessions.map((s) => ({ id: s.id, titre: s.title, debut: s.startDate, fin: s.endDate, modalite: s.modality, type: s.kind, places: s.capacity, tarifCents: s.priceCents })),
    })),
    generéLe: new Date().toISOString(),
  };
}
