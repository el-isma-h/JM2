import "server-only";
import { and, desc, eq, ne } from "drizzle-orm";
import { db, schema } from "@/db";

/** Listes de rattachement pour le formulaire de devis (entreprises, contacts, personnes, besoins ouverts). */
export async function quoteFormOptions(orgId: string) {
  const [companies, contacts, persons, needs] = await Promise.all([
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, orgId)).orderBy(schema.companies.name).limit(500),
    db
      .select({ id: schema.contacts.id, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName, companyId: schema.contacts.companyId, companyName: schema.companies.name })
      .from(schema.contacts)
      .leftJoin(schema.companies, eq(schema.companies.id, schema.contacts.companyId))
      .where(eq(schema.contacts.orgId, orgId))
      .orderBy(schema.contacts.lastName)
      .limit(500),
    db.select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName }).from(schema.persons).where(eq(schema.persons.orgId, orgId)).orderBy(schema.persons.lastName).limit(500),
    db
      .select({ id: schema.needs.id, title: schema.needs.title, companyId: schema.needs.companyId, personId: schema.needs.personId, contactId: schema.needs.contactId, programId: schema.needs.programId, amountCents: schema.needs.amountCents, headcount: schema.needs.headcount, companyName: schema.companies.name })
      .from(schema.needs)
      .leftJoin(schema.companies, eq(schema.companies.id, schema.needs.companyId))
      .where(and(eq(schema.needs.orgId, orgId), ne(schema.needs.stage, "perdu")))
      .orderBy(desc(schema.needs.updatedAt))
      .limit(300),
  ]);
  return {
    companies,
    contacts: contacts.map((c) => ({ id: c.id, name: `${c.firstName} ${c.lastName}${c.companyName ? ` (${c.companyName})` : ""}`, companyId: c.companyId })),
    persons: persons.map((p) => ({ id: p.id, name: `${p.firstName} ${p.lastName}` })),
    needs: needs.map((n) => ({ id: n.id, name: `${n.title}${n.companyName ? ` (${n.companyName})` : ""}`, companyId: n.companyId, personId: n.personId, contactId: n.contactId, programId: n.programId, amountCents: n.amountCents, headcount: n.headcount })),
  };
}
