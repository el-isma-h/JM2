"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { parseQuestions, validateSubmission } from "@/server/quality/indicator-math";
import { parseQuestionLines, surveyTemplate } from "@/server/quality/survey-templates";
import { findResponseByToken, sendSurveyToSession, submitResponse } from "@/server/quality/surveys";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const optUuid = z.string().uuid().optional().or(z.literal("")).transform((v) => (v ? v : null));
const KIND = z.enum(["positionnement", "satisfaction_chaud", "satisfaction_froid", "employeur", "formateur", "financeur", "competences", "besoins"], { message: "Type d'enquête invalide" });

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}
const str = (fd: FormData, key: string, max = 2000) => {
  const v = String(fd.get(key) ?? "").trim();
  return v ? v.slice(0, max) : null;
};
const base = (orgId: string) => `/app/${orgId}/enquetes`;

async function manage(formData: FormData): Promise<OrgContext> {
  return requireOrg(uuid.parse(formData.get("orgId")), "quality.view", "quality.manage");
}

async function loadSurvey(ctx: OrgContext, surveyId: string) {
  const [s] = await db.select().from(schema.surveys).where(and(eq(schema.surveys.id, surveyId), eq(schema.surveys.orgId, ctx.org.id))).limit(1);
  if (!s) throw new Error("Enquête introuvable.");
  return s;
}

const createSchema = z.object({
  kind: KIND,
  title: z.string().trim().max(200).optional().or(z.literal("")),
  sessionId: optUuid,
  automation: z.string().optional(),
  delayDays: z.coerce.number().int().min(0).max(365).optional(),
});

/** Crée une enquête depuis le modèle de son type (questions et définitions d'indicateurs), reliée ou non à une session. */
export async function createSurveyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const d = createSchema.parse(Object.fromEntries(formData));
    const tpl = surveyTemplate(d.kind);
    if (!tpl) return { error: "Modèle introuvable." };
    let programId: string | null = null;
    let sessionTitle = "";
    if (d.sessionId) {
      const [s] = await db
        .select({ id: schema.trainingSessions.id, title: schema.trainingSessions.title, programId: schema.programVersions.programId })
        .from(schema.trainingSessions)
        .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
        .where(and(eq(schema.trainingSessions.id, d.sessionId), eq(schema.trainingSessions.orgId, ctx.org.id)))
        .limit(1);
      if (!s) return { error: "Session introuvable dans cet organisme." };
      programId = s.programId;
      sessionTitle = s.title;
    }
    const automationOn = d.automation === "on" && tpl.automation;
    const automation = automationOn ? { trigger: "session_end", delayDays: d.delayDays ?? tpl.automation!.delayDays } : {};
    const [row] = await db
      .insert(schema.surveys)
      .values({
        orgId: ctx.org.id,
        kind: d.kind,
        title: d.title || (sessionTitle ? `${tpl.title} : ${sessionTitle}` : tpl.title),
        description: tpl.description,
        questions: tpl.questions,
        sessionId: d.sessionId,
        programId,
        status: "brouillon",
        automation,
        createdBy: ctx.user.id,
      })
      .returning({ id: schema.surveys.id });
    await audit({ action: "survey.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "survey", entityId: row.id, after: { kind: d.kind, sessionId: d.sessionId, automation } });
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: "Enquête créée en brouillon : relisez les questions puis activez-la.", data: { surveyId: row.id } };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function updateSurveyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const s = await loadSurvey(ctx, uuid.parse(formData.get("surveyId")));
    if (s.status !== "brouillon") return { error: "Seule une enquête en brouillon est modifiable (les réponses reçues doivent rester comparables)." };
    const title = z.string().trim().min(3, "Titre requis").max(200).parse(formData.get("title"));
    const description = str(formData, "description", 1000);
    const parsed = parseQuestionLines(String(formData.get("questions") ?? ""));
    if (!parsed.ok) return { error: parsed.error };
    const automationOn = formData.get("automation") === "on";
    const delayDays = Math.max(0, Math.min(365, Number(formData.get("delayDays") ?? 0) || 0));
    const automation = automationOn ? { trigger: "session_end", delayDays } : {};
    await db.update(schema.surveys).set({ title, description, questions: parsed.questions, automation }).where(eq(schema.surveys.id, s.id));
    await audit({ action: "survey.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "survey", entityId: s.id, before: { title: s.title, questions: (s.questions as unknown[]).length }, after: { title, questions: parsed.questions.length, automation } });
    revalidatePath(`${base(ctx.org.id)}/${s.id}`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: `Enquête enregistrée (${parsed.questions.length} question(s)).` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function setSurveyStatusAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const s = await loadSurvey(ctx, uuid.parse(formData.get("surveyId")));
    const status = z.enum(["active", "cloturee"]).parse(formData.get("status"));
    if (s.status === status) return { error: "Statut inchangé." };
    if (status === "active" && !parseQuestions(s.questions).length) return { error: "Ajoutez au moins une question avant d'activer l'enquête." };
    if (status === "active" && s.status === "cloturee") return { error: "Une enquête clôturée ne se rouvre pas : créez-en une nouvelle." };
    await db.update(schema.surveys).set({ status }).where(eq(schema.surveys.id, s.id));
    let scheduled = false;
    if (status === "active" && (s.automation as { trigger?: string })?.trigger === "session_end") {
      const { scheduleNextDispatch } = await import("@/server/quality/jobs");
      scheduled = await scheduleNextDispatch(0);
    }
    await audit({ action: status === "active" ? "survey.activate" : "survey.close", userId: ctx.user.id, orgId: ctx.org.id, entityType: "survey", entityId: s.id, before: { status: s.status }, after: { status, scheduled } });
    revalidatePath(`${base(ctx.org.id)}/${s.id}`);
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: status === "active" ? `Enquête activée.${scheduled ? " Envoi automatique planifié (tâche surveys:dispatch)." : ""}` : "Enquête clôturée : plus aucune réponse ne sera acceptée." };
  } catch (e) {
    return fail(e, "Mise à jour impossible.");
  }
}

/** Envoi manuel aux inscrits de la session (jetons individuels). En démonstration, les liens sont affichés, rien ne part. */
export async function sendSurveyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const s = await loadSurvey(ctx, uuid.parse(formData.get("surveyId")));
    if (s.status !== "active") return { error: "Activez l'enquête avant de l'envoyer." };
    if (!s.sessionId) return { error: "Cette enquête n'est reliée à aucune session : l'envoi automatique créera une enquête par session terminée, ou créez une enquête reliée à une session." };
    const r = await sendSurveyToSession(s, { orgId: ctx.org.id, isDemo: ctx.org.isDemo, orgName: ctx.org.tradeName ?? ctx.org.legalName });
    await audit({ action: "survey.send", userId: ctx.user.id, orgId: ctx.org.id, entityType: "survey", entityId: s.id, after: { recipients: r.recipients, sent: r.sent, skippedAlready: r.skippedAlready, skippedNoEmail: r.skippedNoEmail, notConfigured: r.notConfigured } });
    revalidatePath(`${base(ctx.org.id)}/${s.id}`);
    revalidatePath(base(ctx.org.id));
    const parts = [`${r.sent} invitation(s) émise(s) sur ${r.recipients} inscrit(s)`];
    if (r.skippedAlready) parts.push(`${r.skippedAlready} déjà invitée(s)`);
    if (r.skippedNoEmail) parts.push(`${r.skippedNoEmail} sans adresse e-mail`);
    const links = r.links.map((l) => `${l.name} : ${l.url}`).join("\n");
    return {
      ok: true,
      message: `${parts.join(", ")}.${r.notConfigured ? (ctx.org.isDemo ? " En démonstration, aucun e-mail ne part : transmettez les liens ci-dessous." : " L'e-mail n'est pas configuré : transmettez les liens ci-dessous.") : ""}`,
      data: links ? { links } : undefined,
    };
  } catch (e) {
    return fail(e, "Envoi impossible.");
  }
}

/** Exécute immédiatement l'envoi automatique (même traitement que la tâche de fond `surveys:dispatch`) pour cet organisme. */
export async function runSurveyDispatchAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await manage(formData);
    const { dispatchDueSurveys } = await import("@/server/quality/jobs");
    const r = await dispatchDueSurveys(ctx.org.id);
    await audit({ action: "survey.dispatch.run", userId: ctx.user.id, orgId: ctx.org.id, entityType: "survey", after: { ...r } });
    revalidatePath(base(ctx.org.id));
    return { ok: true, message: `Envoi automatique exécuté : ${r.surveysChecked} enquête(s) examinée(s), ${r.created} créée(s) pour des sessions terminées, ${r.dispatched} envoi(s), ${r.sent} invitation(s), ${r.skipped} ignorée(s) (délai non atteint ou déjà envoyée).` };
  } catch (e) {
    return fail(e, "Exécution impossible.");
  }
}

// ---------------------------------------------------------------------------
// Page publique /enquete/[token] : sans session, une seule soumission par jeton
// ---------------------------------------------------------------------------

export async function submitSurveyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const token = z.string().min(20).max(200).parse(formData.get("token"));
    const found = await findResponseByToken(token);
    if (!found) return { error: "Ce lien n'est pas valide." };
    if (found.response.submittedAt) return { error: "Ce questionnaire a déjà été soumis. Merci pour votre participation." };
    if (found.survey.status !== "active") return { error: "Cette enquête n'est plus ouverte." };
    const questions = parseQuestions(found.survey.questions);
    const raw: Record<string, string> = {};
    for (const q of questions) raw[q.key] = String(formData.get(`q_${q.key}`) ?? "");
    const v = validateSubmission(questions, raw);
    if (!v.ok) return { error: v.error };
    const res = await submitResponse(found.response.id, v.answers);
    if (!res.ok) return { error: res.error };
    await audit({ action: "survey.response.submit", orgId: found.response.orgId, entityType: "survey_response", entityId: found.response.id, after: { surveyId: found.survey.id, questions: questions.length } });
    revalidatePath(`/app/${found.response.orgId}/enquetes/${found.survey.id}`);
    return { ok: true, message: "Merci, vos réponses ont bien été enregistrées." };
  } catch (e) {
    return fail(e, "Envoi impossible.");
  }
}
