import "server-only";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { registerJobHandler, type JobHandler } from "@/server/jobs/registry";
import { readSecrets } from "./store";
import { signPayload } from "./webhooks";

/**
 * webhooks:dispatch : envoie un événement (POST JSON signé HMAC-SHA256) à l'URL du webhook de l'organisme.
 * En-têtes : X-NextFormation-Event, X-NextFormation-Timestamp, X-NextFormation-Signature (hex de HMAC(secret, "<timestamp>.<corps>")).
 * Échec HTTP → erreur (le runner réessaie 3 fois) et statut « erreur » sur l'intégration.
 */
const dispatch: JobHandler = async (job) => {
  const integrationId = String(job.payload.integrationId ?? "");
  if (!/^[0-9a-f-]{36}$/i.test(integrationId)) throw new Error("integrationId manquant.");
  const [row] = await db.select().from(schema.orgIntegrations).where(eq(schema.orgIntegrations.id, integrationId)).limit(1);
  if (!row) throw new Error("Intégration introuvable.");
  if (job.orgId && row.orgId !== job.orgId) throw new Error("Intégration hors organisme.");
  const cfg = row.config as { url?: string };
  const secrets = readSecrets<{ secret?: string }>(row);
  if (!cfg.url || !secrets?.secret) throw new Error("Webhook non configuré (URL ou secret absent).");
  const body = JSON.stringify({ event: job.payload.event, data: job.payload.data ?? {}, at: job.payload.at ?? new Date().toISOString(), orgId: row.orgId });
  const timestamp = String(Math.floor(Date.now() / 1000));
  const signature = signPayload(secrets.secret, timestamp, body);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 10_000);
  try {
    const res = await fetch(cfg.url, { method: "POST", body, signal: ctrl.signal, headers: { "Content-Type": "application/json", "User-Agent": "NextFormation-Webhook/1", "X-NextFormation-Event": String(job.payload.event ?? ""), "X-NextFormation-Timestamp": timestamp, "X-NextFormation-Signature": signature } });
    if (!res.ok) {
      await db.update(schema.orgIntegrations).set({ status: "erreur", lastError: `HTTP ${res.status}` }).where(eq(schema.orgIntegrations.id, row.id));
      throw new Error(`Le destinataire a répondu ${res.status}.`);
    }
    await db.update(schema.orgIntegrations).set({ status: "connectee", lastError: null, lastSyncAt: new Date() }).where(eq(schema.orgIntegrations.id, row.id));
    return { status: res.status, event: job.payload.event };
  } catch (e) {
    if (!(e instanceof Error && e.message.startsWith("Le destinataire"))) {
      await db.update(schema.orgIntegrations).set({ status: "erreur", lastError: e instanceof Error ? e.message : "erreur réseau" }).where(eq(schema.orgIntegrations.id, row.id));
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
};

registerJobHandler("webhooks:dispatch", dispatch);
