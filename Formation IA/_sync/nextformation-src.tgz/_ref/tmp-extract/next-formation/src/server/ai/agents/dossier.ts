import "server-only";
import type { OrgContext } from "@/server/authz";
import { enrollmentSummary } from "../tools";
import type { Agent, AgentInput, ProposalDraft } from "../store";
import { askJson, baseRationale, requireEntity, toPromptJson } from "./shared";

type Summary = {
  enrollment: Record<string, unknown> & { reference: string; status: string; fundingState: string; progression: string; examState: string; endDate?: string | null };
  person: { firstName: string; lastName: string };
  session: { title: string; code: string; status: string };
  hours: Record<string, string>;
  pieces: { label: string; status: string; dueDate?: string | null; providedBy: string }[] | string;
  fundings: { label: string; status: string; agreementRef?: string | null; validUntil?: string | null }[] | string;
  invoices: { number: string | null; status: string; totalTtcCents: number; paidCents: number; dueDate?: string | null }[] | string;
  openTasks: { id: string; title: string; status: string; assigneeRole?: string | null; dueDate?: string | null; blockedReason?: string | null }[] | string;
  nextSlot: { date: string; title?: string | null } | null;
};

export type DossierPayload = {
  state: string;
  missing: string[];
  nextAction: string;
  responsible: string;
  text: string;
  createTask: boolean;
};

const roleForMissing = (label: string) => (/financ|facture|accord|opco|prise en charge/i.test(label) ? "finance" : /pièce|cerfa|convention|contrat|signature/i.test(label) ? "admin_staff" : "pedagogy_manager");

/** Résumé déterministe (sans modèle) : où en est le dossier, ce qui manque, prochaine action, responsable. */
export function deterministicDossier(s: Summary): DossierPayload {
  const missing: string[] = [];
  if (Array.isArray(s.pieces)) for (const p of s.pieces) if (p.status === "attendue" || p.status === "refusee") missing.push(`Pièce « ${p.label} » ${p.status === "refusee" ? "refusée, à redéposer" : "attendue"} (déposant : ${p.providedBy}${p.dueDate ? `, échéance ${p.dueDate}` : ""})`);
  if (s.enrollment.fundingState === "a_definir") missing.push("Financement à définir");
  if (Array.isArray(s.fundings)) for (const f of s.fundings) if (f.status === "prevu" || f.status === "demande") missing.push(`Accord de prise en charge « ${f.label} » non reçu (${f.status})`);
  if (Array.isArray(s.invoices)) for (const i of s.invoices) if (i.status === "en_retard") missing.push(`Facture ${i.number ?? ""} en retard de règlement`);
  if (Array.isArray(s.openTasks)) for (const t of s.openTasks) if (t.status === "bloquee") missing.push(`Tâche bloquée : ${t.title}${t.blockedReason ? ` (${t.blockedReason})` : ""}`);
  const firstTask = Array.isArray(s.openTasks) ? s.openTasks[0] : undefined;
  const nextAction = firstTask ? firstTask.title : missing[0] ? `Traiter : ${missing[0]}` : s.enrollment.status === "preinscrit" ? "Confirmer l'inscription" : s.nextSlot ? `Prochaine séance le ${s.nextSlot.date}` : "Aucune action identifiée : dossier à jour selon les données";
  const responsible = firstTask?.assigneeRole ?? (missing[0] ? roleForMissing(missing[0]) : "admin_staff");
  const state = `${s.person.firstName} ${s.person.lastName}, ${s.session.title} (${s.session.code}) : inscription ${s.enrollment.status}, progression ${s.enrollment.progression}, financement ${s.enrollment.fundingState}, examen ${s.enrollment.examState}. Heures effectuées ${s.hours.effectuees} sur ${s.hours.prevues} prévues (justifiées ${s.hours.justifiees}).`;
  const text = [state, missing.length ? `Ce qui manque : ${missing.join(" ; ")}.` : "Rien ne manque selon les données accessibles.", `Prochaine action : ${nextAction}. Responsable : ${responsible}.`].join("\n");
  return { state, missing, nextAction, responsible, text, createTask: !firstTask && missing.length > 0 };
}

export const dossierAgent: Agent = {
  name: "dossier",
  label: "Résumé de dossier",
  description: "Où en est ce dossier, ce qui manque, prochaine action et responsable, à partir des tâches, pièces et financements.",
  requires: "enrollments.view",
  accepts: ["enrollment"],
  async run(ctx: OrgContext, input: AgentInput): Promise<ProposalDraft> {
    const { entityId } = requireEntity(input, ["enrollment"]);
    const s = (await enrollmentSummary(ctx, entityId)) as Summary | null;
    if (!s) throw new Error("Inscription introuvable ou hors de votre périmètre.");
    const det = deterministicDossier(s);
    const sources = [
      { type: "enrollment", id: entityId, label: `Inscription ${s.enrollment.reference}` },
      { type: "tasks", label: "Tâches ouvertes du dossier" },
      { type: "pieces", label: "Pièces attendues" },
      { type: "fundings", label: "Financements et factures" },
    ];
    const ai = await askJson<Partial<DossierPayload>>(
      `Rédige un résumé de dossier d'inscription. Réponds en JSON : {"state": string, "missing": string[], "nextAction": string, "responsible": string, "text": string, "certainty": "A"|"B"|"C"}. "responsible" est un rôle parmi admin_staff, pedagogy_manager, finance, direction, quality. Ne mentionne que ce que les données contiennent ; les blocs « non accessible » ne doivent pas être interprétés comme vides.`,
      `Données du dossier :\n${toPromptJson(s)}\n\nSynthèse déterministe déjà calculée (à enrichir, pas à contredire) :\n${JSON.stringify(det)}`,
    );
    const payload: DossierPayload = ai?.data?.text ? { ...det, ...ai.data, missing: Array.isArray(ai.data.missing) ? ai.data.missing : det.missing, createTask: det.createTask } : det;
    const certainty = (ai?.data as { certainty?: "A" | "B" | "C" } | null)?.certainty ?? "A";
    return {
      agent: "dossier",
      kind: "resume",
      title: `Résumé du dossier ${s.enrollment.reference} (${s.person.firstName} ${s.person.lastName})`,
      summary: payload.nextAction,
      entityType: "enrollment",
      entityId,
      payload: payload as unknown as Record<string, unknown>,
      rationale: baseRationale(sources, ai ? certainty : "A", !ai, ["Statuts distincts : la clôture pédagogique ne solde pas le financier.", "Heures prévues, effectuées et justifiées ne sont jamais additionnées."], payload.createTask ? ["Validation = création d'une tâche « prochaine action » pour le responsable indiqué."] : ["Validation = simple prise d'acte (aucune tâche créée : une tâche ouverte existe déjà ou rien ne manque)."]),
      provider: ai?.result.provider ?? null,
      model: ai?.result.model ?? null,
    };
  },
};
