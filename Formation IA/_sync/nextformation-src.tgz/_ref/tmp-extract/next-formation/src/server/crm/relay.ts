import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { createTaskOnce } from "@/server/tasks/service";

/** Relais F14 : un besoin gagné sans inscription crée une seule tâche « Créer l'inscription » pour l'administratif (clé need:<id>:won). */
export async function relayWonNeed(input: { orgId: string; userId: string | null; isDemo: boolean }, need: { id: string; title: string }) {
  const [enr] = await db
    .select({ id: schema.enrollments.id })
    .from(schema.enrollments)
    .innerJoin(schema.placements, eq(schema.placements.enrollmentId, schema.enrollments.id))
    .where(and(eq(schema.placements.needId, need.id), eq(schema.enrollments.orgId, input.orgId)))
    .limit(1);
  if (enr) return { created: false as const };
  return createTaskOnce({
    orgId: input.orgId,
    title: `Créer l'inscription : ${need.title}`,
    description: "Le besoin est passé en « gagné » sans inscription créée. Créez l'inscription depuis le placement retenu ou depuis la fiche besoin.",
    family: "commercial",
    entityType: "need",
    entityId: need.id,
    entityLabel: need.title,
    href: `/app/${input.orgId}/besoins/${need.id}`,
    assigneeRole: "admin_staff",
    priority: "haute",
    idempotencyKey: `need:${need.id}:won`,
    createdBy: input.userId,
    isDemo: input.isDemo,
  });
}
