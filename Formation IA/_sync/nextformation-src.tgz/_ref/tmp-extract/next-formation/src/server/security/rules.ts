/**
 * Règles de sécurité propriétaire (S01, cas « Nathalie »). Module pur : aucune dépendance serveur,
 * testable en vitest et réutilisable dans les pages comme dans les actions.
 */
import { ORG_ROLES, type OrgRole } from "../../db/schema/tenancy";
import type { Permission } from "../authz";

/** Permissions réservées au propriétaire : jamais accordables en permission fine, jamais suffisantes sans `isOwner`. */
export const OWNER_ONLY_PERMISSIONS: Permission[] = ["users.manage", "roles.manage", "audit.view"];

/** Rôles attribuables depuis la page Sécurité (apprenant et entreprise sont rattachés depuis leurs modules). */
export const ASSIGNABLE_ROLES: OrgRole[] = ORG_ROLES.filter((r) => r !== "learner" && r !== "employer");

/** Permissions fines modulables par membre (ajout ou retrait), hors permissions propriétaire. */
export const FINE_PERMISSIONS: Permission[] = [
  "org.view", "users.view", "roles.view", "crm.view", "crm.manage", "candidates.cv.view", "catalog.view", "catalog.manage",
  "sessions.view", "sessions.manage", "enrollments.view", "enrollments.manage", "dossier.admin_docs.view", "dossier.admin_docs.manage",
  "dossier.internal.view", "dossier.pedagogy.view", "dossier.pedagogy.manage", "planning.view", "planning.manage", "attendance.record",
  "attendance.close", "attendance.correct", "exams.view", "exams.manage", "documents.view", "documents.generate", "finance.view",
  "finance.manage", "quality.view", "quality.manage", "tasks.view_all", "tasks.manage", "dashboards.view", "exports.run", "integrations.manage",
];

export type SecurityContextLike = {
  isOwner: boolean;
  roles: readonly OrgRole[];
  permissions: Set<Permission> | ReadonlySet<Permission>;
  membership?: { active: boolean; expiresAt: Date | null } | null;
  isPlatformAdmin?: boolean;
};

/**
 * Seul le propriétaire actif du tenant administre la sécurité (membres, rôles, permissions, invitations,
 * transfert de propriété, journal d'audit). Les permissions `users.manage`, `roles.manage`, `audit.view`,
 * qu'elles viennent d'un rôle ou d'une permission fine, n'y suffisent jamais ; le cumul de rôles non plus ;
 * l'administrateur plateforme non plus (il n'est jamais propriétaire d'un tenant).
 */
export function canAdministerSecurity(ctx: SecurityContextLike, now: Date = new Date()): boolean {
  if (!ctx.isOwner) return false;
  if (ctx.membership) {
    if (!ctx.membership.active) return false;
    if (ctx.membership.expiresAt && ctx.membership.expiresAt.getTime() <= now.getTime()) return false;
  }
  return true;
}

/** Les paramètres généraux (hors sécurité) sont modifiables par la direction ou le propriétaire. */
export function canEditSettings(ctx: SecurityContextLike): boolean {
  return ctx.isOwner || ctx.roles.includes("direction");
}

/** Normalise une liste de rôles reçue d'un formulaire : rôles connus, attribuables, sans doublon. */
export function normalizeRoles(input: unknown): OrgRole[] {
  const list = Array.isArray(input) ? input : typeof input === "string" ? [input] : [];
  const out: OrgRole[] = [];
  for (const r of list) {
    if (typeof r !== "string") continue;
    if (!(ASSIGNABLE_ROLES as readonly string[]).includes(r)) continue;
    if (!out.includes(r as OrgRole)) out.push(r as OrgRole);
  }
  return out;
}

/**
 * Normalise les permissions fines : seules les permissions modulables sont conservées ; une permission
 * propriétaire est toujours rejetée (elle ne peut être ni accordée ni retirée par ce biais).
 */
export function normalizePermissionOverrides(input: Record<string, unknown>): { overrides: Partial<Record<Permission, boolean>>; rejected: string[] } {
  const overrides: Partial<Record<Permission, boolean>> = {};
  const rejected: string[] = [];
  for (const [k, v] of Object.entries(input)) {
    if ((OWNER_ONLY_PERMISSIONS as readonly string[]).includes(k)) {
      rejected.push(k);
      continue;
    }
    if (!(FINE_PERMISSIONS as readonly string[]).includes(k)) continue;
    if (v === true || v === "true" || v === "1") overrides[k as Permission] = true;
    else if (v === false || v === "false" || v === "0") overrides[k as Permission] = false;
  }
  return { overrides, rejected };
}

/** Un transfert de propriété exige un membre cible actif, distinct du propriétaire courant, non expiré. */
export function canReceiveOwnership(target: { userId: string; active: boolean; expiresAt: Date | null; roles: unknown }, currentOwnerId: string | null, now: Date = new Date()): { ok: true } | { ok: false; reason: string } {
  if (target.userId === currentOwnerId) return { ok: false, reason: "Ce membre est déjà le propriétaire." };
  if (!target.active) return { ok: false, reason: "Le membre cible est inactif : réactivez-le d'abord." };
  if (target.expiresAt && target.expiresAt.getTime() <= now.getTime()) return { ok: false, reason: "L'accès du membre cible est expiré." };
  const roles = Array.isArray(target.roles) ? (target.roles as string[]) : [];
  if (roles.length && roles.every((r) => r === "learner" || r === "employer")) return { ok: false, reason: "Un apprenant ou une entreprise ne peut pas devenir propriétaire." };
  return { ok: true };
}
