import "server-only";
import Papa from "papaparse";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { checkSiret, isEmail, parseDateInput } from "@/lib/validators";
import type { OrgContext } from "@/server/authz";
import { createEnrollment, logEnrollmentEvent, nextEnrollmentReference, ACTIVE_ENROLLMENT_STATUSES } from "@/server/enrollments/service";
import { IMPORT_KINDS, parseBool, parseHoursToMinutes, type ImportKind } from "./kinds";

export const MAX_IMPORT_ROWS = 5000;

export type ParsedFile = { headers: string[]; rows: Record<string, string>[]; truncated: boolean };

/** Lecture d'un fichier CSV (papaparse, séparateur détecté) ou .xlsx (si la librairie `xlsx` est installée). */
export async function parseImportFile(name: string, buf: Buffer): Promise<{ ok: true; file: ParsedFile } | { ok: false; error: string }> {
  const ext = (name.split(".").pop() ?? "").toLowerCase();
  if (ext === "xlsx" || ext === "xls") {
    const mod = await loadXlsx();
    if (!mod) return { ok: false, error: "Lecture des fichiers Excel non disponible sur ce serveur (librairie « xlsx » absente). Enregistrez votre feuille au format CSV (UTF-8, séparateur ; ou ,) puis déposez-la : le résultat est identique." };
    try {
      const wb = mod.read(buf, { type: "buffer", cellDates: false });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const data = mod.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "", raw: false });
      const headers = data.length ? Object.keys(data[0]) : [];
      const rows = data.slice(0, MAX_IMPORT_ROWS).map((r) => Object.fromEntries(headers.map((h) => [h, String(r[h] ?? "").trim()])));
      return { ok: true, file: { headers, rows, truncated: data.length > MAX_IMPORT_ROWS } };
    } catch {
      return { ok: false, error: "Fichier Excel illisible." };
    }
  }
  let text = buf.toString("utf8");
  if (text.includes("�")) text = buf.toString("latin1");
  text = text.replace(/^﻿/, "");
  const res = Papa.parse<Record<string, string>>(text, { header: true, skipEmptyLines: "greedy", transformHeader: (h) => h.trim(), transform: (v) => (typeof v === "string" ? v.trim() : v) });
  const headers = (res.meta.fields ?? []).filter(Boolean);
  if (!headers.length) return { ok: false, error: "Aucune colonne détectée : la première ligne doit contenir les en-têtes." };
  const rows = res.data.filter((r) => Object.values(r).some((v) => String(v ?? "").trim()));
  return { ok: true, file: { headers, rows: rows.slice(0, MAX_IMPORT_ROWS), truncated: rows.length > MAX_IMPORT_ROWS } };
}

type XlsxModule = { read: (data: Buffer, opts: Record<string, unknown>) => { SheetNames: string[]; Sheets: Record<string, unknown> }; utils: { sheet_to_json: <T>(sheet: unknown, opts: Record<string, unknown>) => T[] } };

async function loadXlsx(): Promise<XlsxModule | null> {
  try {
    const specifier = "xlsx";
    const mod = (await import(/* webpackIgnore: true */ specifier)) as unknown as Partial<XlsxModule> & { default?: Partial<XlsxModule> };
    const m = typeof mod.default?.read === "function" ? mod.default : typeof mod.read === "function" ? mod : null;
    return m && typeof m.read === "function" && m.utils ? (m as XlsxModule) : null;
  } catch {
    return null;
  }
}

export type RowError = { row: number; field?: string; message: string };
export type RowDuplicate = { row: number; reason: string; existingId?: string | null; label?: string };
export type ValidationResult = { rows: Record<string, string>[]; errors: RowError[]; duplicates: RowDuplicate[]; validCount: number };

/** Applique l'association de colonnes : ligne brute → objet par clé de champ. */
export function applyMapping(kind: ImportKind, raw: Record<string, string>[], mapping: Record<string, string>): Record<string, string>[] {
  const def = IMPORT_KINDS[kind];
  return raw.map((r) => {
    const o: Record<string, string> = {};
    for (const f of def.fields) {
      const col = mapping[f.key];
      o[f.key] = col ? String(r[col] ?? "").trim() : "";
    }
    return o;
  });
}

/**
 * Validation ligne par ligne (erreurs explicites) et détection des doublons en base et dans le fichier :
 * les doublons sont listés, jamais fusionnés ni appliqués.
 */
export async function validateImport(orgId: string, kind: ImportKind, rows: Record<string, string>[]): Promise<ValidationResult> {
  const def = IMPORT_KINDS[kind];
  const errors: RowError[] = [];
  const duplicates: RowDuplicate[] = [];
  const seen = new Map<string, number>();
  const err = (row: number, message: string, field?: string) => errors.push({ row, field, message });
  const dup = (row: number, reason: string, existingId?: string | null, label?: string) => duplicates.push({ row, reason, existingId: existingId ?? null, label });

  rows.forEach((r, i) => {
    const n = i + 2; // numéro de ligne dans le fichier (en-tête = 1)
    for (const f of def.fields) if (f.required && !r[f.key]) err(n, `${f.label} manquant`, f.key);
    if (r.email && !isEmail(r.email)) err(n, `E-mail invalide « ${r.email} »`, "email");
    if (r.personEmail && !isEmail(r.personEmail)) err(n, `E-mail invalide « ${r.personEmail} »`, "personEmail");
    for (const k of ["birthDate", "startDate", "endDate", "date"]) if (r[k] && !parseDateInput(r[k])) err(n, `Date invalide « ${r[k]} » (JJ/MM/AAAA)`, k);
    for (const k of ["siret", "companySiret"]) {
      if (r[k]) {
        const c = checkSiret(r[k]);
        if (!c.ok) err(n, `${k === "siret" ? "SIRET" : "SIRET entreprise"} : ${c.error}`, k);
      }
    }
    if (kind === "inscriptions" && !r.personEmail && !(r.lastName && r.firstName && r.birthDate)) err(n, "Personne non identifiable : e-mail, ou nom + prénom + date de naissance", "personEmail");
    if (kind === "inscriptions" && r.status && !(schema.enrollmentStatusEnum.enumValues as readonly string[]).includes(r.status)) err(n, `Statut inconnu « ${r.status} »`, "status");
    if (kind === "inscriptions" && r.contractKind && !(schema.contractKindEnum.enumValues as readonly string[]).includes(r.contractKind)) err(n, `Type de contrat inconnu « ${r.contractKind} »`, "contractKind");
    if (kind === "inscriptions" && r.hoursPlanned && !/^\d{1,5}$/.test(r.hoursPlanned)) err(n, "Heures prévues : nombre entier attendu", "hoursPlanned");
    if (kind === "inscriptions" && r.legacyHours && !/^\d{1,6}$/.test(r.legacyHours)) err(n, "Solde historique : nombre entier d'heures attendu", "legacyHours");
    if (kind === "heures") {
      if (r.hours && parseHoursToMinutes(r.hours) === null) err(n, `Durée invalide « ${r.hours} » (ex. 6, 3,5 ou 3h30)`, "hours");
      if (!r.reference && !(r.personEmail && r.sessionCode)) err(n, "Inscription non identifiable : référence, ou e-mail + code de session", "reference");
    }
    if (kind === "entreprises" && r.status && !(schema.companyStatusEnum.enumValues as readonly string[]).includes(r.status)) err(n, `Statut inconnu « ${r.status} »`, "status");
    if (kind === "personnes" && r.status && !(schema.personStatusEnum.enumValues as readonly string[]).includes(r.status)) err(n, `Statut inconnu « ${r.status} »`, "status");
    // Doublons internes au fichier
    const key = fileKey(kind, r);
    if (key) {
      const prev = seen.get(key);
      if (prev !== undefined) dup(n, `Doublon dans le fichier : identique à la ligne ${prev}`, null);
      else seen.set(key, n);
    }
  });

  // Doublons en base (par lots)
  if (kind === "entreprises") {
    const sirets = rows.map((r) => r.siret.replace(/\s/g, "")).filter(Boolean);
    const names = rows.map((r) => r.name.toLowerCase()).filter(Boolean);
    const ex = sirets.length || names.length
      ? await db.select({ id: schema.companies.id, siret: schema.companies.siret, name: schema.companies.name }).from(schema.companies).where(and(eq(schema.companies.orgId, orgId), sql`(${sirets.length ? inArray(schema.companies.siret, sirets) : sql`false`} or lower(${schema.companies.name}) in (${names.length ? sql.join(names.map((x) => sql`${x}`), sql`, `) : sql`''`}))`))
      : [];
    rows.forEach((r, i) => {
      const s = r.siret.replace(/\s/g, "");
      const hit = ex.find((c) => (s && c.siret === s) || c.name.toLowerCase() === r.name.toLowerCase());
      if (hit) dup(i + 2, s && hit.siret === s ? "SIRET déjà présent" : "Raison sociale déjà présente", hit.id, hit.name);
    });
  } else if (kind === "contacts") {
    const emails = rows.map((r) => r.email.toLowerCase()).filter(Boolean);
    const ex = emails.length ? await db.select({ id: schema.contacts.id, email: schema.contacts.email, firstName: schema.contacts.firstName, lastName: schema.contacts.lastName }).from(schema.contacts).where(and(eq(schema.contacts.orgId, orgId), sql`lower(${schema.contacts.email}) in (${sql.join(emails.map((x) => sql`${x}`), sql`, `)})`)) : [];
    rows.forEach((r, i) => {
      const hit = r.email && ex.find((c) => c.email?.toLowerCase() === r.email.toLowerCase());
      if (hit) dup(i + 2, "E-mail déjà présent", hit.id, `${hit.firstName} ${hit.lastName}`);
    });
  } else if (kind === "personnes") {
    const found = await findPersons(orgId, rows.map((r) => ({ email: r.email, lastName: r.lastName, firstName: r.firstName, birthDate: parseDateInput(r.birthDate) })));
    found.forEach((hit, i) => {
      if (hit) dup(i + 2, hit.by === "email" ? "E-mail déjà présent" : "Nom, prénom et date de naissance déjà présents", hit.id, hit.label);
    });
  } else if (kind === "inscriptions") {
    const refs = rows.map((r) => r.reference).filter(Boolean);
    const exRefs = refs.length ? await db.select({ id: schema.enrollments.id, reference: schema.enrollments.reference }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.reference, refs))) : [];
    const persons = await findPersons(orgId, rows.map((r) => ({ email: r.personEmail, lastName: r.lastName, firstName: r.firstName, birthDate: parseDateInput(r.birthDate) })));
    const codes = [...new Set(rows.map((r) => r.sessionCode).filter(Boolean))];
    const sessions = codes.length ? await db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.orgId, orgId), inArray(schema.trainingSessions.code, codes))) : [];
    const pairs = rows.map((r, i) => ({ p: persons[i]?.id, s: sessions.find((x) => x.code === r.sessionCode)?.id })).filter((x) => x.p && x.s);
    const exPairs = pairs.length
      ? await db.select({ personId: schema.enrollments.personId, sessionId: schema.enrollments.sessionId, reference: schema.enrollments.reference, id: schema.enrollments.id }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.status, ACTIVE_ENROLLMENT_STATUSES), inArray(schema.enrollments.personId, pairs.map((x) => x.p!))))
      : [];
    rows.forEach((r, i) => {
      const n = i + 2;
      const refHit = r.reference && exRefs.find((x) => x.reference === r.reference);
      if (refHit) dup(n, "Référence d'inscription déjà présente", refHit.id, refHit.reference);
      const p = persons[i];
      if (!p && !errors.some((e) => e.row === n && e.field === "personEmail")) err(n, "Personne introuvable : importez d'abord les personnes", "personEmail");
      const s = sessions.find((x) => x.code === r.sessionCode);
      if (r.sessionCode && !s) err(n, `Session « ${r.sessionCode} » introuvable : créez-la d'abord`, "sessionCode");
      if (p && s) {
        const hit = exPairs.find((x) => x.personId === p.id && x.sessionId === s.id);
        if (hit) dup(n, "Personne déjà inscrite (statut actif) sur cette session", hit.id, hit.reference);
      }
    });
  } else if (kind === "heures") {
    const resolved = await resolveEnrollmentsForHours(orgId, rows);
    const pairs = resolved.map((e, i) => ({ e, d: parseDateInput(rows[i].date) })).filter((x) => x.e && x.d);
    const ex = pairs.length
      ? await db.select({ enrollmentId: schema.legacyAttendanceSheets.enrollmentId, date: schema.legacyAttendanceSheets.date }).from(schema.legacyAttendanceSheets).where(and(eq(schema.legacyAttendanceSheets.orgId, orgId), inArray(schema.legacyAttendanceSheets.enrollmentId, [...new Set(pairs.map((x) => x.e!.id))])))
      : [];
    rows.forEach((r, i) => {
      const n = i + 2;
      const e = resolved[i];
      if (!e && !errors.some((x) => x.row === n && x.field === "reference")) err(n, "Inscription introuvable (référence ou e-mail + code de session)", "reference");
      const d = parseDateInput(r.date);
      if (e && d && ex.some((x) => x.enrollmentId === e.id && x.date === d)) dup(n, "Feuille déjà importée pour cette inscription et cette date", e.id, e.reference);
    });
  }

  const badRows = new Set([...errors.map((e) => e.row), ...duplicates.map((d) => d.row)]);
  return { rows, errors, duplicates, validCount: rows.length - [...badRows].filter((r) => r >= 2 && r - 2 < rows.length).length };
}

function fileKey(kind: ImportKind, r: Record<string, string>): string | null {
  switch (kind) {
    case "entreprises":
      return r.siret ? `siret:${r.siret.replace(/\s/g, "")}` : r.name ? `name:${r.name.toLowerCase()}` : null;
    case "contacts":
      return r.email ? `email:${r.email.toLowerCase()}` : null;
    case "personnes":
      return r.email ? `email:${r.email.toLowerCase()}` : r.lastName && r.firstName && r.birthDate ? `id:${r.lastName.toLowerCase()}|${r.firstName.toLowerCase()}|${parseDateInput(r.birthDate)}` : null;
    case "inscriptions":
      return r.reference ? `ref:${r.reference}` : r.personEmail && r.sessionCode ? `pe:${r.personEmail.toLowerCase()}|${r.sessionCode}` : null;
    case "heures":
      return r.date ? `${r.reference || `${r.personEmail}|${r.sessionCode}`}|${parseDateInput(r.date)}` : null;
  }
}

type PersonHit = { id: string; by: "email" | "identity"; label: string } | null;

async function findPersons(orgId: string, keys: { email: string; lastName: string; firstName: string; birthDate: string | null }[]): Promise<PersonHit[]> {
  const emails = [...new Set(keys.map((k) => k.email.toLowerCase()).filter(Boolean))];
  const lastNames = [...new Set(keys.map((k) => k.lastName.toLowerCase()).filter(Boolean))];
  if (!emails.length && !lastNames.length) return keys.map(() => null);
  const rows = await db
    .select({ id: schema.persons.id, email: schema.persons.email, firstName: schema.persons.firstName, lastName: schema.persons.lastName, birthDate: schema.persons.birthDate })
    .from(schema.persons)
    .where(and(eq(schema.persons.orgId, orgId), sql`(${emails.length ? sql`lower(${schema.persons.email}) in (${sql.join(emails.map((x) => sql`${x}`), sql`, `)})` : sql`false`} or ${lastNames.length ? sql`lower(${schema.persons.lastName}) in (${sql.join(lastNames.map((x) => sql`${x}`), sql`, `)})` : sql`false`})`));
  return keys.map((k) => {
    if (k.email) {
      const hit = rows.find((p) => p.email?.toLowerCase() === k.email.toLowerCase());
      if (hit) return { id: hit.id, by: "email", label: `${hit.firstName} ${hit.lastName}` };
    }
    if (k.lastName && k.firstName && k.birthDate) {
      const hit = rows.find((p) => p.lastName.toLowerCase() === k.lastName.toLowerCase() && p.firstName.toLowerCase() === k.firstName.toLowerCase() && p.birthDate === k.birthDate);
      if (hit) return { id: hit.id, by: "identity", label: `${hit.firstName} ${hit.lastName}` };
    }
    return null;
  });
}

async function resolveEnrollmentsForHours(orgId: string, rows: Record<string, string>[]) {
  const refs = [...new Set(rows.map((r) => r.reference).filter(Boolean))];
  const byRef = refs.length ? await db.select({ id: schema.enrollments.id, reference: schema.enrollments.reference }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.reference, refs))) : [];
  const needLookup = rows.filter((r) => !r.reference && r.personEmail && r.sessionCode);
  const persons = await findPersons(orgId, needLookup.map((r) => ({ email: r.personEmail, lastName: "", firstName: "", birthDate: null })));
  const codes = [...new Set(needLookup.map((r) => r.sessionCode))];
  const sessions = codes.length ? await db.select({ id: schema.trainingSessions.id, code: schema.trainingSessions.code }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.orgId, orgId), inArray(schema.trainingSessions.code, codes))) : [];
  const pids = persons.filter(Boolean).map((p) => p!.id);
  const byPair = pids.length ? await db.select({ id: schema.enrollments.id, reference: schema.enrollments.reference, personId: schema.enrollments.personId, sessionId: schema.enrollments.sessionId }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.personId, pids))) : [];
  let j = 0;
  return rows.map((r) => {
    if (r.reference) return byRef.find((e) => e.reference === r.reference) ?? null;
    if (r.personEmail && r.sessionCode) {
      const p = persons[j++];
      const s = sessions.find((x) => x.code === r.sessionCode);
      if (!p || !s) return null;
      const e = byPair.find((x) => x.personId === p.id && x.sessionId === s.id);
      return e ? { id: e.id, reference: e.reference } : null;
    }
    return null;
  });
}

/** Application des lignes valides (les lignes en erreur ou en doublon sont ignorées et comptées). Retourne le nombre appliqué. */
export async function applyImport(ctx: OrgContext, kind: ImportKind, rows: Record<string, string>[], skipRows: Set<number>): Promise<{ applied: number; skipped: number; failures: RowError[] }> {
  const orgId = ctx.org.id;
  let applied = 0;
  const failures: RowError[] = [];
  const todo = rows.map((r, i) => ({ r, n: i + 2 })).filter((x) => !skipRows.has(x.n));
  const companyBySiret = async (siret: string) => {
    if (!siret) return null;
    const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.orgId, orgId), eq(schema.companies.siret, siret.replace(/\s/g, "")))).limit(1);
    return c?.id ?? null;
  };
  const companyByName = async (name: string) => {
    if (!name) return null;
    const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.orgId, orgId), sql`lower(${schema.companies.name}) = ${name.toLowerCase()}`)).limit(1);
    return c?.id ?? null;
  };

  for (const { r, n } of todo) {
    try {
      if (kind === "entreprises") {
        const siret = r.siret.replace(/\s/g, "") || null;
        await db.insert(schema.companies).values({
          orgId,
          name: r.name,
          siret,
          siren: r.siren.replace(/\s/g, "") || (siret ? siret.slice(0, 9) : null),
          apeCode: r.apeCode || null,
          opco: r.opco || null,
          addressLine1: r.addressLine1 || null,
          postalCode: r.postalCode || null,
          city: r.city || null,
          email: r.email || null,
          phone: r.phone || null,
          status: (r.status as "client") || "client",
          source: "import",
          isDemo: ctx.org.isDemo,
        });
      } else if (kind === "contacts") {
        const companyId = (await companyBySiret(r.companySiret)) ?? (await companyByName(r.companyName));
        await db.insert(schema.contacts).values({ orgId, companyId, firstName: r.firstName, lastName: r.lastName, email: r.email || null, phone: r.phone || null, jobTitle: r.jobTitle || null, isTutor: parseBool(r.isTutor), isSignatory: parseBool(r.isSignatory) });
      } else if (kind === "personnes") {
        const companyId = await companyBySiret(r.companySiret);
        await db.insert(schema.persons).values({
          orgId,
          firstName: r.firstName,
          lastName: r.lastName,
          birthDate: parseDateInput(r.birthDate),
          civility: r.civility === "M" || r.civility === "Mme" ? r.civility : null,
          email: r.email || null,
          phone: r.phone || null,
          addressLine1: r.addressLine1 || null,
          postalCode: r.postalCode || null,
          city: r.city || null,
          status: (r.status as "candidat") || "candidat",
          companyId,
          identifiers: r.externalId ? { externalId: r.externalId } : {},
          source: "import",
          isDemo: ctx.org.isDemo,
        });
      } else if (kind === "inscriptions") {
        const [person] = await findPersons(orgId, [{ email: r.personEmail, lastName: r.lastName, firstName: r.firstName, birthDate: parseDateInput(r.birthDate) }]);
        const [session] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.orgId, orgId), eq(schema.trainingSessions.code, r.sessionCode))).limit(1);
        if (!person || !session) throw new Error("Personne ou session introuvable.");
        const status = (r.status || "inscrit") as (typeof schema.enrollmentStatusEnum.enumValues)[number];
        const contractKind = (r.contractKind || "convention_formation") as (typeof schema.contractKindEnum.enumValues)[number];
        const companyId = await companyBySiret(r.companySiret);
        const startDate = parseDateInput(r.startDate) ?? session.startDate;
        const endDate = parseDateInput(r.endDate) ?? session.endDate;
        const hoursPlanned = r.hoursPlanned ? Number(r.hoursPlanned) : null;
        const legacyHours = r.legacyHours ? Number(r.legacyHours) : 0;
        if ((ACTIVE_ENROLLMENT_STATUSES as string[]).includes(status) && session.status !== "terminee" && session.status !== "annulee") {
          const res = await createEnrollment(ctx, { personId: person.id, sessionId: session.id, companyId, contractKind, startDate, endDate, hoursPlanned, status, legacyHours, legacyHoursNote: legacyHours ? "Import : solde d'anciennes feuilles" : null });
          if (r.reference) await db.update(schema.enrollments).set({ reference: r.reference }).where(eq(schema.enrollments.id, res.enrollment.id));
        } else {
          // Inscription historique : insérée telle quelle (version de programme de la session), sans pièces ni tâches.
          const id = await db.transaction(async (tx) => {
            const reference = r.reference || (await nextEnrollmentReference(tx, orgId, Number(startDate.slice(0, 4)) || new Date().getFullYear()));
            const [e] = await tx
              .insert(schema.enrollments)
              .values({ orgId, sessionId: session.id, personId: person.id, programVersionId: session.programVersionId, reference, companyId, status, contractKind, startDate, endDate, hoursPlanned: hoursPlanned ?? 0, legacyHours, legacyHoursNote: legacyHours ? "Import : solde d'anciennes feuilles" : null, closedAt: new Date(), closedBy: ctx.user.id, isDemo: ctx.org.isDemo })
              .returning({ id: schema.enrollments.id });
            return e.id;
          });
          await logEnrollmentEvent(id, "import", { to: status, reason: `Inscription historique importée (session ${session.code})`, userId: ctx.user.id });
        }
      } else if (kind === "heures") {
        const [e] = await resolveEnrollmentsForHours(orgId, [r]);
        const date = parseDateInput(r.date);
        const minutes = parseHoursToMinutes(r.hours);
        if (!e || !date || minutes === null) throw new Error("Inscription, date ou durée invalide.");
        await db.insert(schema.legacyAttendanceSheets).values({ orgId, enrollmentId: e.id, date, hours: minutes, signed: parseBool(r.signed), source: r.source || "import", note: r.note || null });
      }
      applied++;
    } catch (e) {
      failures.push({ row: n, message: e instanceof Error ? e.message : "Erreur inconnue" });
    }
  }
  return { applied, skipped: rows.length - todo.length, failures };
}
