import { describe, expect, it } from "vitest";
import { parseTemplate, renderTemplate, templateVariables, listMarkers } from "../render";
import { PLATFORM_TEMPLATES, TEMPLATE_VARIABLES } from "../templates-data";

describe("Modèles plateforme", () => {
  it("tous les modèles obligatoires sont présents et analysables", () => {
    const codes = PLATFORM_TEMPLATES.map((t) => t.code);
    for (const c of ["convention_formation", "contrat_formation_particulier", "convocation", "programme_formation", "reglement_interieur", "attestation_fin_formation", "certificat_realisation", "feuille_emargement", "attestation_assiduite", "livret_accueil", "convention_stage", "cerfa_apprentissage_recap", "annexe_parcours"]) {
      expect(codes).toContain(c);
    }
    for (const t of PLATFORM_TEMPLATES) expect(() => parseTemplate(t.body)).not.toThrow();
  });

  it("toutes les variables utilisées ont un libellé (ou sont des réponses déclarées)", () => {
    for (const t of PLATFORM_TEMPLATES) {
      const qkeys = t.questions.map((q) => `answers.${q.key}`);
      for (const v of templateVariables(t.body)) {
        expect(v in TEMPLATE_VARIABLES || qkeys.includes(v), `${t.code} : ${v}`).toBe(true);
      }
    }
  });

  it("la convention cite les articles du Code du travail et rend des marqueurs pour les données absentes", () => {
    const t = PLATFORM_TEMPLATES.find((x) => x.code === "convention_formation")!;
    const { text, missing } = renderTemplate(
      t.body,
      {
        org: { legalName: "Atelier Méridien Formation", address: "14 rue des Tanneurs, 75011 Paris", siret: "91324567800021", nda: "11 75 61234 75", ndaRegion: "Île-de-France", signatoryName: "Élise Marchetti", signatoryTitle: "Directrice" },
        enrollment: { reference: "INS-2026-001", startDate: "2 mars 2026", endDate: "6 mars 2026", hoursPlanned: 35, price: "1 800,00 €", priceTtc: "2 160,00 €", person: { fullName: "Camille Dorval" } },
        company: { name: "Société Varenne", address: "3 allée des Peupliers, 92000 Nanterre", siret: "", signatory: {} },
        programVersion: { title: "Gestion de projet agile", objectives: "Piloter un projet.", modalityLabel: "Présentiel" },
        session: { title: "GPA-03", code: "GPA-03", site: { name: "Site principal" } },
        answers: { signaturePlace: "Paris" },
        document: { date: "1 février 2026" },
      },
      { labels: TEMPLATE_VARIABLES },
    );
    expect(text).toContain("L.6353-1");
    expect(text).toContain("Atelier Méridien Formation");
    expect(text).toContain("[À COMPLÉTER : SIRET de l'entreprise]");
    expect(text).toContain("[À COMPLÉTER : Conditions de règlement]");
    const keys = missing.map((m) => m.key);
    expect(keys).toContain("company.siret");
    expect(keys).toContain("company.signatory.fullName");
    expect(keys).toContain("answers.paymentTerms");
    expect(keys).not.toContain("org.legalName");
    expect(listMarkers(text).length).toBe(missing.length);
    // Section conditionnelle : aucun financement renseigné, pas de mention de prise en charge.
    expect(text).not.toContain("Prise en charge prévue");
  });

  it("le certificat de réalisation reprend les heures réalisées et la nature de l'action", () => {
    const t = PLATFORM_TEMPLATES.find((x) => x.code === "certificat_realisation")!;
    const { text } = renderTemplate(t.body, { org: { legalName: "OF", signatoryName: "A", signatoryTitle: "B", address: "x", siret: "1", nda: "2", city: "Paris" }, enrollment: { reference: "R", startDate: "1 mars 2026", endDate: "5 mars 2026", hoursDone: "21", person: { fullName: "P", civility: "Madame" } }, programVersion: { title: "T", modalityLabel: "Présentiel" }, answers: { actionNature: "Action de formation" }, document: { date: "6 mars 2026" } }, { labels: TEMPLATE_VARIABLES });
    expect(text).toContain("**21 heures**");
    expect(text).toContain("**Action de formation**");
    expect(text).toContain("L.6313-1");
    expect(listMarkers(text)).toEqual([]);
  });
});
