import { describe, expect, it } from "vitest";
import { findConflicts, generateSeriesDates, isoWeekday, overlaps, periodsForDay, resolveSchedule } from "../rules";

describe("génération en série", () => {
  it("jours de centre du rythme, hors fermetures", () => {
    const dates = generateSeriesDates({ from: "2026-09-07", to: "2026-09-18", weekdays: [1, 2], closures: [{ startDate: "2026-09-14", endDate: "2026-09-14" }] });
    expect(dates).toEqual(["2026-09-07", "2026-09-08", "2026-09-15"]);
  });
  it("lundi à vendredi par défaut", () => {
    expect(generateSeriesDates({ from: "2026-09-07", to: "2026-09-13" })).toHaveLength(5);
    expect(isoWeekday("2026-09-13")).toBe(7);
  });
  it("fermeture d'un autre site ignorée", () => {
    const dates = generateSeriesDates({ from: "2026-09-07", to: "2026-09-07", siteId: "A", closures: [{ startDate: "2026-09-07", endDate: "2026-09-07", siteId: "B" }] });
    expect(dates).toEqual(["2026-09-07"]);
  });
});

describe("conflits", () => {
  const schedule = resolveSchedule({ morning: { start: "08:30", end: "12:00" } }, null);
  const planned = periodsForDay("2026-09-07", ["matin", "apres_midi"], schedule);
  it("horaires : session puis organisme puis défaut", () => {
    expect(schedule.morning.start).toBe("08:30");
    expect(schedule.afternoon.start).toBe("14:00");
  });
  it("formateur, salle et groupe sur le même créneau", () => {
    const existing = [{ periodId: "p1", slotId: "s1", date: "2026-09-07", startTime: "09:00", endTime: "12:00", trainerId: "T", roomId: "R", groupId: "G", sessionCode: "S-1" }];
    const c = findConflicts({ planned, trainerId: "T", roomId: "R", groupId: "G", existing });
    expect(c.map((x) => x.kind).sort()).toEqual(["formateur", "groupe", "salle"]);
    expect(c[0].message).toContain("S-1");
  });
  it("pas de conflit sur un créneau différent ni avec une période annulée ni avec la séance modifiée", () => {
    const existing = [
      { periodId: "p1", slotId: "s1", date: "2026-09-07", startTime: "14:00", endTime: "17:00", trainerId: "T", status: "annulee" },
      { periodId: "p2", slotId: "self", date: "2026-09-07", startTime: "09:00", endTime: "12:00", trainerId: "T" },
      { periodId: "p3", slotId: "s3", date: "2026-09-08", startTime: "09:00", endTime: "12:00", trainerId: "T" },
    ];
    expect(findConflicts({ planned, trainerId: "T", existing, ignoreSlotId: "self" })).toHaveLength(0);
  });
  it("indisponibilité formateur (matin seulement) et fermeture", () => {
    const c = findConflicts({ planned, trainerId: "T", existing: [], unavailabilities: [{ trainerId: "T", startDate: "2026-09-07", endDate: "2026-09-07", part: "matin" }], closures: [{ startDate: "2026-09-07", endDate: "2026-09-07" }] });
    expect(c.filter((x) => x.kind === "indisponibilite")).toHaveLength(1);
    expect(c.filter((x) => x.kind === "fermeture")).toHaveLength(2);
  });
  it("chevauchement strict", () => {
    expect(overlaps({ startTime: "09:00", endTime: "12:00" }, { startTime: "12:00", endTime: "14:00" })).toBe(false);
    expect(overlaps({ startTime: "09:00", endTime: "12:00" }, { startTime: "11:00", endTime: "14:00" })).toBe(true);
  });
});
