import { and, eq, isNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { PLATFORM_TEMPLATES } from "./templates-data";

/**
 * Insère ou met à jour les modèles plateforme (orgId null), idempotent par `code`.
 * Un modèle déjà présent est mis à jour (corps, questions, titre) sans changer son identifiant :
 * les documents déjà générés conservent leur `generationData` et restent reproductibles.
 */
export async function seedDocumentTemplates(): Promise<{ inserted: number; updated: number; total: number }> {
  let inserted = 0;
  let updated = 0;
  for (const t of PLATFORM_TEMPLATES) {
    const [existing] = await db
      .select({ id: schema.documentTemplates.id, body: schema.documentTemplates.body, version: schema.documentTemplates.version })
      .from(schema.documentTemplates)
      .where(and(isNull(schema.documentTemplates.orgId), eq(schema.documentTemplates.code, t.code)))
      .limit(1);
    const values = {
      code: t.code,
      category: t.category,
      title: t.title,
      description: t.description,
      body: t.body,
      scope: t.scope,
      activity: t.activity,
      questions: t.questions,
      isActive: true,
    };
    if (!existing) {
      await db.insert(schema.documentTemplates).values({ ...values, orgId: null, verifiedAt: new Date(), verifiedNote: "Modèle plateforme relu (mentions légales usuelles)." });
      inserted++;
    } else if (existing.body !== t.body) {
      await db
        .update(schema.documentTemplates)
        .set({ ...values, version: existing.version + 1 })
        .where(eq(schema.documentTemplates.id, existing.id));
      updated++;
    }
  }
  return { inserted, updated, total: PLATFORM_TEMPLATES.length };
}
