import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import type { Agent, AgentInput, ProposalDraft } from "../store";
import { askJson, baseRationale, forbidden } from "./shared";

export type ProgrammePayload = {
  programId: string | null;
  title: string;
  objectives: string;
  prerequisites: string;
  audience: string;
  modality: "presentiel" | "distanciel" | "mixte" | "afest" | "elearning";
  durationHours: number;
  methods: string;
  content: string;
  modules: { title: string; hours: number; description: string; skills: string[] }[];
  evaluationMethods: string;
  accessibility: string;
  accessDelay: string;
  trainerProfile: string;
};

const MARK = (l: string) => `[À COMPLÉTER : ${l}]`;

/** Squelette déterministe (sans modèle) : structure Qualiopi complète, chaque rubrique explicitement à compléter. */
export function skeletonProgramme(title: string, objectives: string, programId: string | null, durationHours: number): ProgrammePayload {
  return {
    programId,
    title,
    objectives: objectives || MARK("objectifs pédagogiques opérationnels"),
    prerequisites: MARK("prérequis"),
    audience: MARK("public visé"),
    modality: "presentiel",
    durationHours,
    methods: MARK("moyens et méthodes pédagogiques"),
    content: MARK("contenu détaillé"),
    modules: [{ title: MARK("module 1"), hours: durationHours, description: "", skills: [] }],
    evaluationMethods: MARK("modalités d'évaluation des acquis"),
    accessibility: "Accessibilité aux personnes en situation de handicap : contacter le référent handicap de l'organisme pour étudier les aménagements possibles.",
    accessDelay: MARK("délai d'accès (ex. 15 jours après signature de la convention)"),
    trainerProfile: MARK("profil du formateur"),
  };
}

export const programmeAgent: Agent = {
  name: "programme",
  label: "Proposition de programme",
  description: "Programme complet au format Qualiopi (objectifs, prérequis, public, modalités, modules, évaluation, accessibilité) à partir d'un titre et d'objectifs ; crée une version en brouillon après validation.",
  requires: "catalog.manage",
  accepts: ["program", "none"],
  async run(ctx: OrgContext, input: AgentInput): Promise<ProposalDraft> {
    if (!ctx.permissions.has("catalog.manage")) forbidden();
    const params = input.params ?? {};
    let programId: string | null = input.entityType === "program" && input.entityId ? input.entityId : null;
    let title = (params.title ?? "").trim();
    if (programId) {
      const [p] = await db.select({ id: schema.programs.id, title: schema.programs.title }).from(schema.programs).where(and(eq(schema.programs.id, programId), eq(schema.programs.orgId, ctx.org.id))).limit(1);
      if (!p) throw new Error("Formation introuvable.");
      title = title || p.title;
    } else programId = null;
    if (!title) throw new Error("Indiquez un titre de formation.");
    const objectives = (params.objectives ?? "").trim();
    const durationHours = Math.max(1, Math.min(2000, Number(params.durationHours) || 14));
    const det = skeletonProgramme(title, objectives, programId, durationHours);
    const ai = await askJson<Partial<ProgrammePayload> & { certainty?: "A" | "B" | "C" }>(
      `Propose un programme de formation conforme aux attentes Qualiopi (indicateurs 1 à 8 et 26). Réponds en JSON avec exactement ces clés : {"objectives": string, "prerequisites": string, "audience": string, "modality": "presentiel"|"distanciel"|"mixte", "durationHours": number, "methods": string, "content": string, "modules": [{"title": string, "hours": number, "description": string, "skills": string[]}], "evaluationMethods": string, "accessibility": string, "accessDelay": string, "trainerProfile": string, "certainty": "A"|"B"|"C"}. La somme des heures des modules égale durationHours. Objectifs formulés en compétences observables. Ne cite aucune certification (RNCP) non fournie.`,
      `Titre : ${title}\nObjectifs souhaités : ${objectives || "(non précisés)"}\nDurée totale : ${durationHours} h\nOrganisme : ${ctx.org.kind === "cfa" ? "CFA" : "organisme de formation"}`,
      3000,
    );
    const d = ai?.data ?? null;
    const modules = Array.isArray(d?.modules) && d!.modules.length ? d!.modules.map((m) => ({ title: String(m.title ?? ""), hours: Number(m.hours) || 0, description: String(m.description ?? ""), skills: Array.isArray(m.skills) ? m.skills.map(String) : [] })) : det.modules;
    const payload: ProgrammePayload = d
      ? {
          programId,
          title,
          objectives: d.objectives || det.objectives,
          prerequisites: d.prerequisites || det.prerequisites,
          audience: d.audience || det.audience,
          modality: (["presentiel", "distanciel", "mixte", "afest", "elearning"] as const).includes(d.modality as never) ? (d.modality as ProgrammePayload["modality"]) : "presentiel",
          durationHours: Number(d.durationHours) || durationHours,
          methods: d.methods || det.methods,
          content: d.content || det.content,
          modules,
          evaluationMethods: d.evaluationMethods || det.evaluationMethods,
          accessibility: d.accessibility || det.accessibility,
          accessDelay: d.accessDelay || det.accessDelay,
          trainerProfile: d.trainerProfile || det.trainerProfile,
        }
      : det;
    const hoursSum = payload.modules.reduce((a, m) => a + m.hours, 0);
    const notes = hoursSum !== payload.durationHours ? [`La somme des heures des modules (${hoursSum} h) diffère de la durée totale (${payload.durationHours} h) : à ajuster avant activation.`] : [];
    if (!ai) notes.push("Sans clé IA : squelette avec rubriques à compléter ; la version créée reste un brouillon.");
    return {
      agent: "programme",
      kind: "programme_version",
      title: `Programme proposé : ${title}`,
      summary: `${payload.durationHours} h, ${payload.modules.length} module(s), ${payload.modality}`,
      entityType: programId ? "program" : null,
      entityId: programId,
      payload: payload as unknown as Record<string, unknown>,
      rationale: baseRationale([{ type: "params", label: `Titre et objectifs saisis par ${ctx.user.firstName} ${ctx.user.lastName}` }, ...(programId ? [{ type: "program", id: programId, label: "Fiche formation existante" }] : [])], d?.certainty ?? (ai ? "B" : "C"), !ai, ["Validation = création d'une version de programme en brouillon (jamais active) ; l'activation reste une décision humaine."], notes),
      provider: ai?.result.provider ?? null,
      model: ai?.result.model ?? null,
    };
  },
};
