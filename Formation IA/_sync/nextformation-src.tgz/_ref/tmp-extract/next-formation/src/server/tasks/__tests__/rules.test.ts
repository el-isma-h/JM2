import { describe, expect, it } from "vitest";
import { checkPostpone, checkTransition, isOverdue, parsePrerequisites } from "../rules";

describe("transitions de tâches avec prérequis (F14)", () => {
  it("à faire → en cours → terminée sans prérequis", () => {
    expect(checkTransition({ status: "a_faire" }, "en_cours")).toEqual({ ok: true, blockedReason: null });
    expect(checkTransition({ status: "en_cours" }, "terminee")).toEqual({ ok: true, blockedReason: null });
  });

  it("bloquée exige un motif, qui devient blockedReason", () => {
    expect(checkTransition({ status: "a_faire" }, "bloquee").ok).toBe(false);
    expect(checkTransition({ status: "a_faire" }, "bloquee", { note: "Convention non signée" })).toEqual({ ok: true, blockedReason: "Convention non signée" });
  });

  it("refuse la clôture tant qu'un prérequis explicite n'est pas satisfait", () => {
    const task = { status: "en_cours" as const, prerequisites: [{ label: "Pièce d'identité acceptée", done: false }, { label: "Convention signée", done: true }] };
    const r = checkTransition(task, "terminee");
    expect(r.ok).toBe(false);
    if (!r.ok) {
      expect(r.reason).toContain("Pièce d'identité acceptée");
      expect(r.pending?.map((p) => p.label)).toEqual(["Pièce d'identité acceptée"]);
    }
  });

  it("autorise la clôture par dérogation motivée uniquement", () => {
    const task = { status: "en_cours" as const, prerequisites: ["Décision de la direction"] };
    expect(checkTransition(task, "terminee", { override: true }).ok).toBe(false);
    expect(checkTransition(task, "terminee", { override: true, note: "Décision prise en réunion du 12/10" }).ok).toBe(true);
  });

  it("une tâche bloquée se débloque vers à faire ou en cours, jamais directement vers terminée", () => {
    expect(checkTransition({ status: "bloquee", blockedReason: "x" }, "terminee").ok).toBe(false);
    expect(checkTransition({ status: "bloquee", blockedReason: "x" }, "en_cours")).toEqual({ ok: true, blockedReason: null });
  });

  it("refuse le même statut et les transitions inconnues", () => {
    expect(checkTransition({ status: "en_cours" }, "en_cours").ok).toBe(false);
    expect(checkTransition({ status: "terminee" }, "bloquee").ok).toBe(false);
  });

  it("annulation motivée ; réouverture d'une tâche terminée", () => {
    expect(checkTransition({ status: "a_faire" }, "annulee").ok).toBe(false);
    expect(checkTransition({ status: "a_faire" }, "annulee", { note: "Doublon" }).ok).toBe(true);
    expect(checkTransition({ status: "terminee" }, "a_faire").ok).toBe(true);
  });
});

describe("prérequis, retards et reports", () => {
  it("analyse des prérequis en chaînes ou objets", () => {
    expect(parsePrerequisites(["A", { label: "B", done: true, kind: "piece" }, 42, { nope: 1 }])).toEqual([
      { label: "A", done: false },
      { label: "B", done: true, kind: "piece" },
    ]);
  });
  it("retard = échéance passée et tâche ouverte", () => {
    expect(isOverdue({ status: "a_faire", dueDate: "2026-10-20" }, "2026-10-23")).toBe(true);
    expect(isOverdue({ status: "terminee", dueDate: "2026-10-20" }, "2026-10-23")).toBe(false);
    expect(isOverdue({ status: "a_faire", dueDate: null }, "2026-10-23")).toBe(false);
    expect(isOverdue({ status: "a_faire", dueDate: "2026-10-23" }, "2026-10-23")).toBe(false);
  });
  it("report : date valide, motif, jamais dans le passé", () => {
    expect(checkPostpone({ current: "2026-10-20", next: "2026-10-30", today: "2026-10-23", reason: "Attente OPCO" }).ok).toBe(true);
    expect(checkPostpone({ current: "2026-10-20", next: "2026-10-30", today: "2026-10-23", reason: " " }).ok).toBe(false);
    expect(checkPostpone({ current: "2026-10-20", next: "2026-10-01", today: "2026-10-23", reason: "x" }).ok).toBe(false);
    expect(checkPostpone({ current: "2026-10-20", next: "2026-10-20", today: "2026-10-23", reason: "x" }).ok).toBe(false);
    expect(checkPostpone({ current: null, next: "30/10/2026", today: "2026-10-23", reason: "x" }).ok).toBe(false);
  });
});
