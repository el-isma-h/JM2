import "server-only";
import { createHmac } from "node:crypto";
import { db, schema } from "@/db";
import { getIntegration, readSecrets } from "./store";

/** Mise en file d'un job `webhooks:dispatch` (insertion directe : évite d'importer le runner et son graphe de handlers). */
export async function queueWebhookJob(orgId: string, payload: Record<string, unknown>) {
  const [row] = await db.insert(schema.jobs).values({ kind: "webhooks:dispatch", payload, orgId, runAfter: new Date() }).returning({ id: schema.jobs.id });
  return row;
}

/** Événements publiables vers Zapier / webhooks. */
export const WEBHOOK_EVENTS = [
  { key: "enrollment.created", label: "Inscription créée" },
  { key: "enrollment.status_changed", label: "Statut d'inscription modifié" },
  { key: "session.created", label: "Session créée" },
  { key: "session.status_changed", label: "Statut de session modifié" },
  { key: "invoice.issued", label: "Facture émise" },
  { key: "payment.recorded", label: "Règlement enregistré" },
  { key: "task.created", label: "Tâche créée" },
  { key: "document.signed", label: "Document signé" },
  { key: "survey.answered", label: "Enquête répondue" },
] as const;
export type WebhookEvent = (typeof WEBHOOK_EVENTS)[number]["key"];

export function signPayload(secret: string, timestamp: string, body: string): string {
  return createHmac("sha256", secret).update(`${timestamp}.${body}`).digest("hex");
}

/**
 * Publie un événement : si un webhook est configuré pour cet organisme et abonné à l'événement,
 * un job `webhooks:dispatch` est mis en file (envoi POST signé HMAC-SHA256, 3 tentatives). Jamais d'envoi en démo.
 * Utilisable par tous les modules : `await emitWebhookEvent(orgId, "enrollment.created", { id })`.
 */
export async function emitWebhookEvent(orgId: string, event: WebhookEvent, payload: Record<string, unknown>, opts: { isDemo?: boolean } = {}) {
  if (opts.isDemo) return { queued: false, reason: "demo" as const };
  for (const kind of ["webhook", "zapier"] as const) {
    const row = await getIntegration(orgId, kind);
    if (!row || row.status === "desactivee" || row.status === "non_configuree") continue;
    const cfg = row.config as { url?: string; events?: string[] };
    if (!cfg.url || !(cfg.events ?? []).includes(event)) continue;
    const secrets = readSecrets<{ secret?: string }>(row);
    if (!secrets?.secret) continue;
    await queueWebhookJob(orgId, { integrationId: row.id, event, data: payload, at: new Date().toISOString() });
    return { queued: true as const };
  }
  return { queued: false, reason: "not_configured" as const };
}
