import type { SurveyQuestion } from "./indicator-math";
import { SATISFACTION_DEFINITION, SATISFACTION_EXCLUSIONS } from "./indicator-math";

export type SurveyKind = "positionnement" | "satisfaction_chaud" | "satisfaction_froid" | "employeur" | "formateur" | "financeur" | "competences" | "besoins";

export type SurveyTemplate = {
  kind: SurveyKind;
  title: string;
  description: string;
  /** Qui répond : apprenant, tuteur / entreprise, formateur, financeur. */
  audience: "apprenant" | "entreprise" | "formateur" | "financeur";
  questions: SurveyQuestion[];
  /** Indicateurs calculés à partir de ce modèle, avec définition et exclusions explicites (F15). */
  indicators: { name: string; definition: string; exclusions: string }[];
  /** Envoi automatique proposé : fin de session + délai en jours. */
  automation: { trigger: "session_end"; delayDays: number } | null;
  /** Indicateur Qualiopi alimenté par chaque réponse reçue. */
  qualiopiIndicator: string;
};

const scale = (key: string, label: string, max: 5 | 10 = 5, extra: Partial<SurveyQuestion> = {}): SurveyQuestion => ({ key, label, type: "scale", max, required: true, ...extra });
const text = (key: string, label: string, required = false): SurveyQuestion => ({ key, label, type: "text", required });
const yesno = (key: string, label: string, required = true): SurveyQuestion => ({ key, label, type: "yesno", required });
const choice = (key: string, label: string, options: string[], required = true): SurveyQuestion => ({ key, label, type: "choice", options, required });

const SATISFACTION = { name: "Taux de satisfaction", definition: SATISFACTION_DEFINITION, exclusions: SATISFACTION_EXCLUSIONS };
const RETOUR = { name: "Taux de retour", definition: "Questionnaires soumis / questionnaires envoyés (un jeton par destinataire).", exclusions: "Destinataires sans jeton émis ; enquêtes en brouillon." };

export const SURVEY_TEMPLATES: SurveyTemplate[] = [
  {
    kind: "positionnement",
    title: "Questionnaire de positionnement",
    description: "Avant l'entrée en formation : attentes, niveau estimé, contraintes et besoins d'aménagement (indicateurs 4 et 8).",
    audience: "apprenant",
    questions: [
      text("attentes", "Quelles sont vos attentes vis-à-vis de cette formation ?", true),
      scale("niveau", "Comment estimez-vous votre niveau actuel sur les compétences visées ?"),
      choice("experience", "Avez-vous déjà pratiqué le domaine de la formation ?", ["Jamais", "Occasionnellement", "Régulièrement", "Professionnellement"]),
      yesno("amenagement", "Avez-vous besoin d'un aménagement particulier (handicap, rythme, matériel) ?"),
      text("amenagement_detail", "Si oui, précisez (ces informations restent limitées à l'équipe habilitée)."),
      text("contraintes", "Contraintes à prendre en compte (disponibilités, déplacements, autres)."),
    ],
    indicators: [RETOUR],
    automation: null,
    qualiopiIndicator: "IND_8",
  },
  {
    kind: "satisfaction_chaud",
    title: "Satisfaction à chaud",
    description: "Envoyée à la fin de la session : appréciation globale, contenus, formateur, organisation (indicateur 30).",
    audience: "apprenant",
    questions: [
      scale("global", "Globalement, quel est votre niveau de satisfaction concernant cette formation ?", 5, { indicator: "satisfaction" }),
      scale("objectifs", "Les objectifs annoncés ont-ils été atteints ?"),
      scale("contenu", "Les contenus et supports étaient-ils adaptés ?"),
      scale("formateur", "Le formateur a-t-il été clair, disponible et à l'écoute ?"),
      scale("organisation", "L'organisation (accueil, locaux, horaires, informations) vous a-t-elle convenu ?"),
      scale("recommandation", "Recommanderiez-vous cette formation ? (1 = non, 10 = certainement)", 10, { indicator: "recommandation" }),
      text("points_forts", "Points forts de la formation"),
      text("ameliorations", "Ce que nous pourrions améliorer"),
    ],
    indicators: [SATISFACTION, RETOUR, { name: "Score de recommandation", definition: "Moyenne des réponses à la question de recommandation (1 à 10).", exclusions: "Réponses sans note de recommandation." }],
    automation: { trigger: "session_end", delayDays: 0 },
    qualiopiIndicator: "IND_30",
  },
  {
    kind: "satisfaction_froid",
    title: "Satisfaction à froid",
    description: "Envoyée quelques semaines après la fin : mise en pratique, impact sur le poste, suite de parcours (indicateurs 30, 2, 29).",
    audience: "apprenant",
    questions: [
      scale("global", "Avec le recul, quel est votre niveau de satisfaction concernant cette formation ?", 5, { indicator: "satisfaction" }),
      scale("application", "Avez-vous pu mettre en pratique les acquis dans votre activité ?"),
      choice("situation", "Quelle est votre situation aujourd'hui ?", ["En emploi (même poste)", "En emploi (nouveau poste)", "En poursuite d'études", "En recherche d'emploi", "Autre"]),
      yesno("certification", "Avez-vous obtenu la certification visée (si applicable) ?", false),
      text("besoins", "Quels besoins de formation complémentaires identifiez-vous ?"),
    ],
    indicators: [SATISFACTION, RETOUR, { name: "Taux de mise en pratique", definition: "Réponses ≥ 4/5 à la question de mise en pratique / répondants l'ayant renseignée.", exclusions: "Réponses incomplètes." }],
    automation: { trigger: "session_end", delayDays: 90 },
    qualiopiIndicator: "IND_30",
  },
  {
    kind: "employeur",
    title: "Enquête employeur / tuteur",
    description: "Appréciation de l'entreprise : adéquation au besoin, progression de l'apprenant, relation avec l'organisme (indicateurs 30, 13).",
    audience: "entreprise",
    questions: [
      scale("global", "Quel est votre niveau de satisfaction concernant la formation suivie par votre salarié ou apprenti ?", 5, { indicator: "satisfaction" }),
      scale("adequation", "La formation répond-elle au besoin exprimé ?"),
      scale("progression", "Constatez-vous une progression des compétences ?"),
      scale("relation", "La communication avec l'organisme (suivi, informations, documents) est-elle satisfaisante ?"),
      text("remarques", "Remarques et suggestions"),
    ],
    indicators: [SATISFACTION, RETOUR],
    automation: null,
    qualiopiIndicator: "IND_30",
  },
  {
    kind: "formateur",
    title: "Bilan formateur",
    description: "Retour de l'intervenant sur la session : groupe, moyens, coordination (indicateurs 17, 18, 30).",
    audience: "formateur",
    questions: [
      scale("global", "Globalement, comment s'est déroulée la session ?", 5, { indicator: "satisfaction" }),
      scale("moyens", "Les moyens techniques et les locaux étaient-ils adaptés ?"),
      scale("coordination", "La coordination avec l'équipe de l'organisme a-t-elle été satisfaisante ?"),
      scale("groupe", "Le niveau et l'homogénéité du groupe permettaient-ils d'atteindre les objectifs ?"),
      text("difficultes", "Difficultés rencontrées et aléas"),
      text("ameliorations", "Propositions d'amélioration"),
    ],
    indicators: [SATISFACTION, RETOUR],
    automation: null,
    qualiopiIndicator: "IND_30",
  },
  {
    kind: "financeur",
    title: "Enquête financeur",
    description: "Appréciation du financeur (OPCO, entreprise, France Travail…) sur la prestation et la relation administrative (indicateur 30).",
    audience: "financeur",
    questions: [
      scale("global", "Quel est votre niveau de satisfaction concernant cette prestation ?", 5, { indicator: "satisfaction" }),
      scale("administratif", "Les documents (convention, factures, attestations) étaient-ils conformes et transmis dans les délais ?"),
      scale("information", "Avez-vous été informé du déroulement et des résultats ?"),
      text("remarques", "Remarques"),
    ],
    indicators: [SATISFACTION, RETOUR],
    automation: null,
    qualiopiIndicator: "IND_30",
  },
  {
    kind: "competences",
    title: "Auto-évaluation des acquis",
    description: "En fin de parcours : auto-positionnement sur les compétences visées, à croiser avec les évaluations (indicateur 11).",
    audience: "apprenant",
    questions: [
      scale("maitrise", "Comment évaluez-vous votre maîtrise des compétences visées en fin de formation ?"),
      scale("progression", "Quelle progression constatez-vous par rapport à votre niveau d'entrée ?"),
      text("acquis", "Quels acquis principaux retenez-vous ?"),
      text("manques", "Quelles compétences restent à consolider ?"),
    ],
    indicators: [RETOUR],
    automation: { trigger: "session_end", delayDays: 0 },
    qualiopiIndicator: "IND_11",
  },
  {
    kind: "besoins",
    title: "Recueil des besoins",
    description: "Avant une proposition : besoins de l'entreprise ou du bénéficiaire, objectifs, contraintes (indicateur 4).",
    audience: "entreprise",
    questions: [
      text("contexte", "Contexte et objectifs visés par la formation", true),
      choice("public", "Public concerné", ["Salariés", "Alternants", "Demandeurs d'emploi", "Particuliers", "Mixte"]),
      text("competences", "Compétences à développer"),
      choice("modalite", "Modalité souhaitée", ["Présentiel", "Distanciel", "Mixte", "En situation de travail"]),
      text("contraintes", "Contraintes (dates, lieux, budget, accessibilité)"),
    ],
    indicators: [RETOUR],
    automation: null,
    qualiopiIndicator: "IND_4",
  },
];

export function surveyTemplate(kind: string): SurveyTemplate | undefined {
  return SURVEY_TEMPLATES.find((t) => t.kind === kind);
}

/* ---------- Éditeur de questions en texte (une question par ligne) ----------
 * Format : [*]type: Libellé [| option A ; option B] [#indicateur]
 *   types : echelle5, echelle10, texte, ouinon, choix ; « * » en tête = obligatoire ; « #satisfaction » marque la question globale.
 */

const TYPE_IN: Record<string, { type: SurveyQuestion["type"]; max?: 5 | 10 }> = {
  echelle5: { type: "scale", max: 5 },
  echelle10: { type: "scale", max: 10 },
  texte: { type: "text" },
  ouinon: { type: "yesno" },
  choix: { type: "choice" },
};

export function parseQuestionLines(text: string): { ok: true; questions: SurveyQuestion[] } | { ok: false; error: string } {
  const questions: SurveyQuestion[] = [];
  const keys = new Set<string>();
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  for (const [i, line] of lines.entries()) {
    const m = /^(\*?)\s*([a-z0-9]+)\s*:\s*(.+)$/i.exec(line);
    if (!m) return { ok: false, error: `Ligne ${i + 1} : format attendu « type: Libellé » (types : echelle5, echelle10, texte, ouinon, choix).` };
    const spec = TYPE_IN[m[2].toLowerCase()];
    if (!spec) return { ok: false, error: `Ligne ${i + 1} : type « ${m[2]} » inconnu.` };
    let rest = m[3];
    let indicator: string | undefined;
    const tag = /#([a-z_]+)\s*$/i.exec(rest);
    if (tag) {
      indicator = tag[1].toLowerCase();
      rest = rest.slice(0, tag.index).trim();
    }
    let options: string[] | undefined;
    if (spec.type === "choice") {
      const [label, opts] = rest.split("|");
      options = (opts ?? "").split(";").map((o) => o.trim()).filter(Boolean);
      if (options.length < 2) return { ok: false, error: `Ligne ${i + 1} : un choix demande au moins deux options séparées par « ; » après « | ».` };
      rest = label.trim();
    }
    if (!rest) return { ok: false, error: `Ligne ${i + 1} : libellé manquant.` };
    if (indicator === "satisfaction" && spec.type !== "scale") return { ok: false, error: `Ligne ${i + 1} : la question globale de satisfaction doit être une échelle.` };
    let key = `q${i + 1}`;
    while (keys.has(key)) key = `${key}_`;
    keys.add(key);
    questions.push({ key, label: rest.slice(0, 300), type: spec.type, max: spec.max, options, required: m[1] === "*", indicator });
  }
  if (!questions.length) return { ok: false, error: "Saisissez au moins une question." };
  if (questions.length > 40) return { ok: false, error: "40 questions au maximum." };
  return { ok: true, questions };
}

export function formatQuestionLines(questions: SurveyQuestion[]): string {
  return questions
    .map((q) => {
      const type = q.type === "scale" ? (q.max === 10 ? "echelle10" : "echelle5") : q.type === "text" ? "texte" : q.type === "yesno" ? "ouinon" : "choix";
      const opts = q.type === "choice" ? ` | ${(q.options ?? []).join(" ; ")}` : "";
      const tag = q.indicator ? ` #${q.indicator}` : "";
      return `${q.required ? "*" : ""}${type}: ${q.label}${opts}${tag}`;
    })
    .join("\n");
}
