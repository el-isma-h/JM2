import "server-only";
import { and, asc, eq, ne } from "drizzle-orm";
import { db, schema } from "@/db";
import { orgMembers } from "./service";

/** Données de référence pour le formulaire de session (versions de programme, sites, salles, membres, entreprises). */
export async function sessionFormData(orgId: string) {
  const [versions, sites, rooms, members, companies] = await Promise.all([
    db
      .select({ id: schema.programVersions.id, version: schema.programVersions.version, status: schema.programVersions.status, durationHours: schema.programVersions.durationHours, programTitle: schema.programs.title, programCode: schema.programs.code })
      .from(schema.programVersions)
      .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
      .where(and(eq(schema.programVersions.orgId, orgId), ne(schema.programVersions.status, "archivee"), ne(schema.programs.status, "archive")))
      .orderBy(asc(schema.programs.title), asc(schema.programVersions.version)),
    db.select({ id: schema.sites.id, name: schema.sites.name }).from(schema.sites).where(eq(schema.sites.orgId, orgId)).orderBy(asc(schema.sites.name)),
    db.select({ id: schema.rooms.id, name: schema.rooms.name, siteId: schema.rooms.siteId }).from(schema.rooms).where(eq(schema.rooms.orgId, orgId)).orderBy(asc(schema.rooms.name)),
    orgMembers(orgId),
    db.select({ id: schema.companies.id, name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.orgId, orgId)).orderBy(asc(schema.companies.name)),
  ]);
  return {
    versions: versions.map((v) => ({ id: v.id, label: `v${v.version}`, programTitle: `${v.programCode} · ${v.programTitle}`, durationHours: v.durationHours, status: v.status })),
    sites,
    rooms,
    members: members.map((m) => ({ id: m.id, name: `${m.firstName} ${m.lastName}` })),
    companies,
  };
}

/** Programmes et sites (filtres de liste). */
export async function sessionFilters(orgId: string) {
  const [programs, sites] = await Promise.all([
    db.select({ id: schema.programs.id, title: schema.programs.title, code: schema.programs.code }).from(schema.programs).where(eq(schema.programs.orgId, orgId)).orderBy(asc(schema.programs.title)),
    db.select({ id: schema.sites.id, name: schema.sites.name }).from(schema.sites).where(eq(schema.sites.orgId, orgId)).orderBy(asc(schema.sites.name)),
  ]);
  return { programs, sites };
}
