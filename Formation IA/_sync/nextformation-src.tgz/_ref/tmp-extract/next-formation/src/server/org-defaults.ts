import "server-only";
import type { Db } from "@/db";
import { schema } from "@/db";

type Tx = Parameters<Parameters<Db["transaction"]>[0]>[0];

/** Pièces attendues par défaut (paramétrables ensuite par l'organisme, F09). */
export const DEFAULT_REQUIRED_PIECES = [
  { code: "piece_identite", label: "Pièce d'identité", category: "piece_identite", providedBy: "apprenant", appliesTo: { contractKinds: ["*"], fundingKinds: ["*"] }, dueDaysBeforeStart: 7 },
  { code: "cv", label: "CV", category: "cv", providedBy: "apprenant", appliesTo: { contractKinds: ["*"], fundingKinds: ["*"] }, isRequired: false },
  { code: "diplome", label: "Dernier diplôme ou attestation de niveau", category: "diplome", providedBy: "apprenant", appliesTo: { contractKinds: ["contrat_apprentissage", "contrat_professionnalisation"], fundingKinds: ["*"] } },
  { code: "convention_signee", label: "Convention de formation signée", category: "convention", providedBy: "entreprise", appliesTo: { contractKinds: ["convention_formation"], fundingKinds: ["*"] }, dueDaysBeforeStart: 1 },
  { code: "cerfa_apprentissage", label: "CERFA du contrat d'apprentissage signé", category: "cerfa", providedBy: "entreprise", appliesTo: { contractKinds: ["contrat_apprentissage"], fundingKinds: ["*"] }, dueDaysBeforeStart: 0 },
  { code: "accord_prise_en_charge", label: "Accord de prise en charge du financeur", category: "justificatif", providedBy: "financeur", appliesTo: { contractKinds: ["*"], fundingKinds: ["opco", "france_travail", "region", "cpf", "transition_pro", "agefiph"] } },
  { code: "reglement_interieur", label: "Règlement intérieur remis et signé", category: "reglement_interieur", providedBy: "apprenant", appliesTo: { contractKinds: ["*"], fundingKinds: ["*"] } },
  { code: "attestation_assurance", label: "Attestation de responsabilité civile", category: "justificatif", providedBy: "apprenant", appliesTo: { contractKinds: ["stage", "contrat_apprentissage"], fundingKinds: ["*"] }, isRequired: false },
] as const;

export const DEFAULT_RETENTION = [
  { category: "dossier_apprenant", label: "Dossier apprenant (inscription, émargements, évaluations)", retentionMonths: 36, legalBasis: "Obligation de justification auprès des financeurs (3 ans minimum)", action: "anonymiser" },
  { category: "documents_financiers", label: "Factures, règlements, conventions", retentionMonths: 120, legalBasis: "Obligations comptables et fiscales (10 ans)", action: "conserver" },
  { category: "candidatures", label: "Candidatures non abouties (CV, notes)", retentionMonths: 24, legalBasis: "Recommandation CNIL (2 ans)", action: "supprimer" },
  { category: "preuves_qualite", label: "Preuves qualité et analyses", retentionMonths: 48, legalBasis: "Cycle de certification qualité", action: "conserver" },
  { category: "journaux", label: "Journaux d'audit et de connexion", retentionMonths: 12, legalBasis: "Sécurité (CNIL : 6 mois à 1 an)", action: "supprimer" },
] as const;

/** Données de base d'un nouvel organisme : site principal, pièces attendues, politiques de conservation. */
export async function bootstrapOrgDefaults(tx: Tx | Db, orgId: string) {
  await tx.insert(schema.sites).values({ orgId, name: "Site principal", isMain: true });
  await tx.insert(schema.requiredPieces).values(
    DEFAULT_REQUIRED_PIECES.map((p, i) => ({
      orgId,
      code: p.code,
      label: p.label,
      category: p.category,
      providedBy: p.providedBy,
      appliesTo: p.appliesTo,
      isRequired: "isRequired" in p ? p.isRequired : true,
      dueDaysBeforeStart: "dueDaysBeforeStart" in p ? p.dueDaysBeforeStart : null,
      position: i,
    })),
  );
  await tx.insert(schema.retentionPolicies).values(DEFAULT_RETENTION.map((r) => ({ orgId, ...r })));
}
