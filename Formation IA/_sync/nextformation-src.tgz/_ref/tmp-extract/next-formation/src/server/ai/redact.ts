/**
 * Minimisation des données transmises aux modèles (T04) : module pur, testé dans __tests__/redact.test.ts.
 * Retire les identifiants et données sensibles (NIR, IBAN, notes confidentielles, adresses complètes, pièces d'identité,
 * mots de passe et secrets) de tout objet avant construction d'un prompt. Jamais de pièce d'identité, jamais de note confidentielle.
 */

/** Clés retirées quel que soit le niveau de profondeur (comparaison insensible à la casse, sur le nom exact). */
export const REDACTED_KEYS = new Set(
  [
    "nir",
    "socialSecurityNumber",
    "numeroSecu",
    "iban",
    "ibanEnc",
    "ribIbanEnc",
    "ribIbanLast4",
    "bic",
    "ribBic",
    "confidentialNotes",
    "notes_confidentielles",
    "addressLine1",
    "addressLine2",
    "address_line1",
    "address_line2",
    "birthPlace",
    "nationality",
    "identifiers",
    "accommodations",
    "passwordHash",
    "password",
    "secretsEnc",
    "totpSecretEnc",
    "tokenHash",
    "signatureKey",
    "signatureIp",
    "ip",
    "userAgent",
    "pieceIdentite",
    "idDocument",
    "cvDocumentId",
  ].map((k) => k.toLowerCase()),
);

/** Motifs retirés dans les chaînes : IBAN français / européen et NIR (15 chiffres, avec ou sans espaces). */
const IBAN_RE = /\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){3,7}(?:[ ]?[A-Z0-9]{1,4})?\b/g;
const NIR_RE = /\b[12]\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3}\s?\d{2}\b/g;

export function redactString(s: string): string {
  return s.replace(IBAN_RE, "[IBAN retiré]").replace(NIR_RE, "[NIR retiré]");
}

/**
 * Copie profonde d'un objet sans les clés sensibles et avec les motifs IBAN / NIR masqués dans les chaînes.
 * Les dates, nombres et booléens sont conservés ; les tableaux sont parcourus ; les Date deviennent des ISO.
 */
export function redactForAi<T>(value: T): T extends object ? Record<string, unknown> | unknown[] : T {
  return walk(value, 0) as never;
}

function walk(v: unknown, depth: number): unknown {
  if (depth > 12) return undefined;
  if (v === null || v === undefined) return v;
  if (typeof v === "string") return redactString(v);
  if (typeof v !== "object") return v;
  if (v instanceof Date) return v.toISOString();
  if (Buffer.isBuffer(v)) return undefined;
  if (Array.isArray(v)) return v.map((x) => walk(x, depth + 1)).filter((x) => x !== undefined);
  const out: Record<string, unknown> = {};
  for (const [k, x] of Object.entries(v as Record<string, unknown>)) {
    if (REDACTED_KEYS.has(k.toLowerCase())) continue;
    const w = walk(x, depth + 1);
    if (w !== undefined) out[k] = w;
  }
  return out;
}

/** Sérialisation compacte pour prompt (après minimisation). */
export function toPromptJson(value: unknown): string {
  return JSON.stringify(redactForAi(value), null, 1);
}
