/**
 * Phase pilotage : tâches et relais (createTaskOnce, une tâche par événement), historique, agenda, notifications.
 */
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { createTaskOnce, type TaskInput } from "@/server/tasks/service";
import { parisToInstant } from "@/lib/time";
import { addD, daysAgo } from "./util";
import { bump, type State } from "./state";

export async function phaseTasks(s: State) {
  const { orgId, users } = s;
  const S = s.sessions;
  const app = `/app/${orgId}`;
  const ines = s.enrollments.find((e) => e.isInes)!;
  const btsB = s.enrollments.filter((e) => e.sessionKey === "bts" && e.groupIdx === 1 && e.status === "en_cours");
  const arh = s.enrollments.filter((e) => e.sessionKey === "arh" && e.status === "en_cours");
  const mgtNolwen = s.enrollments.find((e) => e.sessionKey === "mgt" && e.companyKey === "nolwen")!;
  const elecFirst = s.enrollments.find((e) => e.sessionKey === "elec")!;
  const abandon = s.enrollments.find((e) => e.sessionKey === "arh" && e.status === "abandon")!;
  const late = s.invoiceIds.filter((i) => i.status === "en_retard");
  const enr = (e: State["enrollments"][number]) => ({ entityType: "enrollment", entityId: e.id, entityLabel: `${e.reference} : ${e.personName}`, href: `${app}/inscriptions/${e.id}` });
  const common = { orgId, isDemo: true, createdBy: null as string | null };

  type Def = TaskInput & { done?: { at: string; note: string; by: string }; events?: { kind: "statut" | "commentaire" | "reaffectation" | "echeance"; from?: string; to?: string; note: string; by: string }[] };
  const defs: Def[] = [
    // Pièce manquante emblématique (démonstration attendue du CDC) : relais vers l'administratif.
    { ...common, idempotencyKey: `piece:${ines.id}:cerfa_apprentissage`, title: "Pièce manquante : CERFA du contrat d'apprentissage signé", description: "Le CERFA signé par l'employeur (Deschamps Agencement) n'a pas été reçu. Sans ce document, l'accord OPCO reste suspendu et l'inscription ne peut pas être confirmée définitivement.", family: "administratif", ...enr(ines), assigneeRole: "admin_staff", dueDate: S.bts.startDate, priority: "haute", prerequisites: [{ label: "CERFA signé reçu de l'employeur", done: false }, { label: "Contrôle de la pièce par l'administratif", done: false }], source: "automatique", events: [{ kind: "commentaire", note: "Employeur relancé par téléphone le mois dernier ; promet un retour sous huit jours.", by: users.admin }] },
    { ...common, idempotencyKey: `piece:${btsB[2].id}:piece_identite`, title: "Pièce manquante : pièce d'identité", family: "administratif", ...enr(btsB[2]), assigneeRole: "admin_staff", dueDate: addD(S.bts.startDate, -7), priority: "normale", source: "automatique" },
    { ...common, idempotencyKey: `piece:${arh[3].id}:accord_prise_en_charge`, title: "Pièce manquante : accord de prise en charge (Région)", family: "administratif", ...enr(arh[3]), assigneeUserId: users.finance, dueDate: addD(s.today, 5), priority: "normale", source: "automatique" },
    { ...common, idempotencyKey: `piece:${mgtNolwen.id}:convention_signee`, title: "Pièce manquante : convention de formation signée (Nolwen Technologies)", family: "administratif", ...enr(mgtNolwen), assigneeRole: "admin_staff", dueDate: addD(S.mgt.startDate, -1), priority: "normale", source: "automatique", blockedReason: "Le devis DEV-2026-0002 n'est pas encore accepté : la convention ne peut pas être établie.", prerequisites: [{ label: "Devis accepté par le client", done: false }] },
    { ...common, idempotencyKey: `piece:${elecFirst.id}:reglement_interieur`, title: "Pièce manquante : règlement intérieur signé", family: "administratif", ...enr(elecFirst), assigneeRole: "admin_staff", dueDate: S.elec.startDate, priority: "basse", source: "automatique" },
    { ...common, idempotencyKey: `piece:${btsB[5].id}:diplome`, title: "Pièce manquante : dernier diplôme", family: "administratif", ...enr(btsB[5]), assigneeRole: "admin_staff", dueDate: addD(S.bts.startDate, 10), priority: "normale", source: "automatique", done: { at: addD(S.bts.startDate, 8), note: "Relevé de notes du baccalauréat déposé et accepté.", by: users.admin } },
    // Financements à confirmer.
    { ...common, idempotencyKey: `funding:${s.fundingIds[`bts:${ines.id}`]}:confirm`, title: "Financement à confirmer : prise en charge OPCO (NPEC) en attente", family: "finance", entityType: "funding", entityId: s.fundingIds[`bts:${ines.id}`], entityLabel: ines.reference, href: `${app}/financements`, assigneeUserId: users.finance, dueDate: daysAgo(s.today, 3), priority: "haute", source: "automatique", prerequisites: [{ label: "CERFA signé transmis à l'OPCO", done: false }] },
    { ...common, idempotencyKey: `funding:${s.fundingIds[`arh:${arh[4].id}`]}:confirm`, title: "Financement à confirmer : AIF France Travail (accord non reçu)", family: "finance", entityType: "funding", entityId: s.fundingIds[`arh:${arh[4].id}`], entityLabel: arh[4].reference, href: `${app}/financements`, assigneeUserId: users.finance, dueDate: addD(s.today, 4), priority: "normale", source: "automatique" },
    { ...common, idempotencyKey: `funding:${s.fundingIds[`mgt:${mgtNolwen.id}`]}:confirm`, title: "Financement à confirmer : OPCO Atlas, actions collectives (Nolwen)", family: "finance", entityType: "funding", entityId: s.fundingIds[`mgt:${mgtNolwen.id}`], entityLabel: mgtNolwen.reference, href: `${app}/financements`, assigneeUserId: users.finance, dueDate: addD(S.mgt.startDate, -5), priority: "normale", source: "automatique" },
    // Convocations.
    { ...common, idempotencyKey: `session:${S.mgt.id}:convocations`, title: "Envoyer les convocations restantes : Management d'équipe", family: "administratif", entityType: "session", entityId: S.mgt.id, entityLabel: "Management d'équipe, inter", href: `${app}/sessions/${S.mgt.id}`, assigneeRole: "admin_staff", dueDate: addD(S.mgt.startDate, -10), priority: "normale", source: "automatique", events: [{ kind: "statut", from: "a_faire", to: "en_cours", note: "3 convocations envoyées sur 5.", by: users.admin }] },
    { ...common, idempotencyKey: `session:${S.elec.id}:convocations`, title: "Envoyer les convocations : Habilitation électrique", family: "administratif", entityType: "session", entityId: S.elec.id, entityLabel: "Habilitation électrique B0/H0V", href: `${app}/sessions/${S.elec.id}`, assigneeRole: "admin_staff", dueDate: addD(S.elec.startDate, -10), priority: "normale", source: "automatique" },
    { ...common, idempotencyKey: `session:${S.intra.id}:convocations`, title: "Confirmer la logistique intra avec la Clinique Sainte-Odile", description: "Salle, vidéoprojecteur, liste définitive des 6 participants.", family: "pedagogie", entityType: "session", entityId: S.intra.id, entityLabel: "Accueil en établissement de santé (intra)", href: `${app}/sessions/${S.intra.id}`, assigneeUserId: users.pedagogy, dueDate: addD(S.intra.startDate, -7), priority: "normale", source: "manuel" },
    // Qualité.
    { ...common, idempotencyKey: `quality:IND_27:preuve`, title: "Preuve à produire : contrat de sous-traitance Prévenlys signé (indicateur 27)", family: "qualite", entityType: "indicator", entityLabel: "IND_27", href: `${app}/qualite/preuves`, assigneeUserId: users.quality, dueDate: daysAgo(s.today, 2), priority: "haute", indicatorCode: "IND_27", source: "automatique", events: [{ kind: "commentaire", note: "Preuve précédente invalidée (devis au lieu du contrat).", by: users.quality }] },
    { ...common, idempotencyKey: `quality:IND_2:indicateurs-2026`, title: "Publier les indicateurs de résultats 2026 (indicateur 2)", family: "qualite", entityType: "indicator", entityLabel: "IND_2", href: `${app}/qualite`, assigneeUserId: users.direction, dueDate: addD(s.today, 30), priority: "normale", indicatorCode: "IND_2", source: "automatique" },
    { ...common, idempotencyKey: `quality:action:${s.qualityActionIds[1]}`, title: "Action qualité : méthode de calcul des indicateurs sur le site", family: "qualite", entityType: "quality_action", entityId: s.qualityActionIds[1], href: `${app}/qualite/actions`, assigneeUserId: users.direction, dueDate: addD(s.today, 30), priority: "basse", indicatorCode: "IND_2", source: "automatique", blockedReason: "En attente du retour du certificateur sur le format attendu des indicateurs.", prerequisites: [{ label: "Réponse du certificateur", done: false }] },
    { ...common, idempotencyKey: `quality:action:${s.qualityActionIds[3]}`, title: "Action qualité : inscrire le délai de convocation (21 jours) dans la procédure examens", family: "qualite", entityType: "quality_action", entityId: s.qualityActionIds[3], href: `${app}/qualite/actions`, assigneeUserId: users.pedagogy, dueDate: addD(s.today, 14), priority: "normale", indicatorCode: "IND_9", source: "automatique" },
    { ...common, idempotencyKey: `complaint:${s.complaintIds[1]}:traiter`, title: "Réclamation à traiter : convocation tardive (Distrimarché)", family: "qualite", entityType: "complaint", entityId: s.complaintIds[1], href: `${app}/qualite`, assigneeUserId: users.quality, dueDate: addD(s.today, 10), priority: "haute", indicatorCode: "IND_31", source: "automatique" },
    // Examens.
    { ...common, idempotencyKey: `exam:${s.cohorts.btsBlanc}:convocations-groupe-b`, title: "BTS blanc : convoquer le groupe B (8 inscrits, 4 à inscrire)", family: "examen", entityType: "cohort", entityId: s.cohorts.btsBlanc, entityLabel: "BTS blanc n° 1", href: `${app}/examens/${s.cohorts.btsBlanc}`, assigneeUserId: users.pedagogy, dueDate: addD(s.today, 12), priority: "haute", source: "automatique" },
    { ...common, idempotencyKey: `exam:${s.cohorts.arhA}:pv-jury`, title: "Jury ARH session A : transmettre le procès-verbal à la DREETS", family: "examen", entityType: "cohort", entityId: s.cohorts.arhA, entityLabel: "Jury titre ARH, session A", href: `${app}/examens/${s.cohorts.arhA}`, assigneeUserId: users.pedagogy, dueDate: addD(S.arhA.endDate, 25), priority: "normale", source: "automatique", done: { at: addD(S.arhA.endDate, 23), note: "PV transmis par la plateforme de la DREETS.", by: users.pedagogy } },
    // Pédagogie.
    { ...common, idempotencyKey: `followup:${btsB[0].id}:visite`, title: "Visite en entreprise à replanifier (reportée par l'employeur)", family: "pedagogie", ...enr(btsB[0]), assigneeUserId: users.trainer, dueDate: daysAgo(s.today, 9), priority: "normale", source: "automatique" },
    { ...common, idempotencyKey: `correction:${S.bts.id}:attente`, title: "Demande de correction d'émargement à décider (groupe A)", description: "Le formateur demande de passer une absence en présence sur une période clôturée. Décision du responsable pédagogique requise ; l'original est conservé.", family: "pedagogie", entityType: "session", entityId: S.bts.id, entityLabel: "BTS GPME, promotion 2026-2028", href: `${app}/emargement`, assigneeUserId: users.pedagogy, dueDate: addD(s.today, 2), priority: "normale", source: "automatique" },
    // Finance : relances.
    ...late.map((inv) => ({ ...common, idempotencyKey: `invoice:${inv.id}:relance`, title: `Relancer la facture ${inv.number} (échéance dépassée)`, family: "finance", entityType: "invoice", entityId: inv.id, entityLabel: inv.number, href: `${app}/factures/${inv.id}`, assigneeUserId: users.finance, dueDate: daysAgo(s.today, 1), priority: "haute" as const, source: "automatique" })),
    { ...common, idempotencyKey: `survey:${s.surveyIds.froid}:relance`, title: "Relancer l'enquête à froid Excel avancé (4 réponses manquantes)", family: "qualite", entityType: "survey", entityId: s.surveyIds.froid, href: `${app}/enquetes`, assigneeRole: "admin_staff", dueDate: addD(s.today, 3), priority: "basse", source: "automatique" },
    { ...common, idempotencyKey: `session:${S.sst2.id}:annulation`, title: "Informer les inscrits de l'annulation et proposer un report", family: "administratif", entityType: "session", entityId: S.sst2.id, entityLabel: "SST initial (session annulée)", href: `${app}/sessions/${S.sst2.id}`, assigneeRole: "admin_staff", dueDate: daysAgo(s.today, 14), priority: "normale", source: "automatique", done: { at: daysAgo(s.today, 14), note: "Deux stagiaires reportés sur la session suivante, e-mails envoyés.", by: users.admin } },
    { ...common, idempotencyKey: `enrollment:${abandon.id}:solde-financement`, title: "Abandon : solder le financement au prorata des heures validées", family: "finance", ...enr(abandon), assigneeUserId: users.finance, dueDate: addD(s.today, 6), priority: "normale", source: "automatique", prerequisites: [{ label: "Heures validées arrêtées à la date de sortie", done: true }, { label: "Avenant de financement transmis", done: false }] },
  ];

  let created = 0;
  let events = 0;
  for (const d of defs) {
    const { done, events: evs, ...input } = d;
    const { task, created: isNew } = await createTaskOnce(input);
    if (!isNew) continue;
    created++;
    for (const ev of evs ?? []) {
      await db.insert(schema.taskEvents).values({ taskId: task.id, kind: ev.kind, fromValue: ev.from ?? null, toValue: ev.to ?? null, note: ev.note, userId: ev.by });
      if (ev.kind === "statut" && ev.to) await db.update(schema.tasks).set({ status: ev.to as "en_cours" }).where(eq(schema.tasks.id, task.id));
      events++;
    }
    if (done) {
      await db.update(schema.tasks).set({ status: "terminee", completedAt: new Date(`${done.at}T16:00:00Z`), completedBy: done.by, resolutionNote: done.note }).where(eq(schema.tasks.id, task.id));
      await db.insert(schema.taskEvents).values({ taskId: task.id, kind: "statut", fromValue: "a_faire", toValue: "terminee", note: done.note, userId: done.by, at: new Date(`${done.at}T16:00:00Z`) });
      events++;
    }
  }
  bump(s, "tasks", created);
  bump(s, "task_events", created + events);
  // Rattachement des actions qualité à leur tâche.
  for (const key of [1, 3]) {
    const [t] = await db.select({ id: schema.tasks.id }).from(schema.tasks).where(eq(schema.tasks.idempotencyKey, `quality:action:${s.qualityActionIds[key]}`)).limit(1);
    if (t) await db.update(schema.qualityActions).set({ taskId: t.id }).where(eq(schema.qualityActions.id, s.qualityActionIds[key]));
  }

  /* ---------- Agenda ---------- */
  const at = (date: string, time: string) => parisToInstant(date, time);
  const agenda: (typeof schema.agendaEvents.$inferInsert)[] = [
    { orgId, userId: users.pedagogy, title: "Réunion pédagogique BTS : préparation du BTS blanc", kind: "reunion", startAt: at(addD(s.today, 2), "13:00"), endAt: at(addD(s.today, 2), "14:00"), location: "Salle Simone-Veil", entityType: "cohort", entityId: s.cohorts.btsBlanc, href: `${app}/examens/${s.cohorts.btsBlanc}`, createdBy: users.pedagogy },
    { orgId, userId: users.trainer, title: `Visite en entreprise : ${btsB[0].personName}`, kind: "rdv", startAt: at(addD(s.today, 5), "10:00"), endAt: at(addD(s.today, 5), "11:00"), location: "Montreuil", entityType: "enrollment", entityId: btsB[0].id, href: `${app}/inscriptions/${btsB[0].id}`, createdBy: users.trainer },
    { orgId, userId: users.quality, title: "Comité qualité mensuel", kind: "reunion", startAt: at(addD(s.today, 7), "09:30"), endAt: at(addD(s.today, 7), "11:00"), location: "Salle Camus", href: `${app}/qualite`, createdBy: users.quality },
    { orgId, userId: users.finance, title: "Échéance : relances factures en retard", kind: "echeance", startAt: at(addD(s.today, 1), "09:00"), endAt: at(addD(s.today, 1), "09:30"), href: `${app}/factures`, createdBy: users.finance },
    { orgId, userId: users.direction, title: "Entretien préalable bilan de compétences (visio)", kind: "rdv", startAt: at(addD(s.today, 3), "17:00"), endAt: at(addD(s.today, 3), "17:45"), location: "Visioconférence", createdBy: users.direction },
    { orgId, userId: users.pedagogy, title: "BTS blanc n° 1 : surveillance des épreuves", kind: "jury", startAt: at(addD(S.bts.startDate, 112), "09:00"), endAt: at(addD(S.bts.startDate, 113), "17:00"), location: "Salle Simone-Veil", entityType: "cohort", entityId: s.cohorts.btsBlanc, href: `${app}/examens/${s.cohorts.btsBlanc}`, createdBy: users.pedagogy },
    { orgId, userId: users.admin, title: "Rendez-vous de cadrage : Ville de Montreuil (plan 2027)", kind: "rdv", startAt: at(addD(s.today, 6), "14:30"), endAt: at(addD(s.today, 6), "15:30"), location: "Hôtel de ville de Montreuil", entityType: "company", entityId: s.companies.mairie, href: `${app}/entreprises/${s.companies.mairie}`, createdBy: users.direction },
    { orgId, userId: users.trainer, title: "Séance BTS groupe A : CEJM", kind: "seance", startAt: at(addD(s.today, 7), "09:00"), endAt: at(addD(s.today, 7), "12:00"), location: "Salle Colette", entityType: "session", entityId: S.bts.id, href: `${app}/sessions/${S.bts.id}`, createdBy: users.pedagogy },
  ];
  await db.insert(schema.agendaEvents).values(agenda);
  bump(s, "agenda_events", agenda.length);

  /* ---------- Notifications ---------- */
  const notifs: (typeof schema.notifications.$inferInsert)[] = [
    { orgId, userId: users.admin, title: "Pièce manquante : CERFA signé (Inès Carvalho)", body: "L'accord OPCO reste suspendu tant que le CERFA n'est pas reçu.", href: `${app}/inscriptions/${ines.id}`, kind: "warning", dedupeKey: `piece:${ines.id}:cerfa_apprentissage` },
    { orgId, userId: users.pedagogy, title: "Demande de correction d'émargement en attente", body: "Thomas Lefebvre demande une correction sur une période clôturée du groupe A.", href: `${app}/emargement`, kind: "info", dedupeKey: `correction:${S.bts.id}:attente` },
    { orgId, userId: users.finance, title: `${late.length} factures en retard de paiement`, href: `${app}/factures`, kind: "warning", dedupeKey: "invoices:overdue" },
    { orgId, userId: users.quality, title: "Preuve invalidée : contrat de sous-traitance (indicateur 27)", body: "Une nouvelle analyse a été produite ; l'ancienne photographie est conservée.", href: `${app}/qualite/preuves`, kind: "warning", dedupeKey: "evidence:IND_27:invalidated" },
    { orgId, userId: users.direction, title: "Devis DEV-2026-0002 en attente de réponse (Nolwen Technologies)", href: `${app}/devis`, kind: "info", dedupeKey: "quote:0002:pending" },
    { orgId, userId: users.trainer, title: "Visite en entreprise à replanifier", href: `${app}/inscriptions/${btsB[0].id}`, kind: "info", dedupeKey: `followup:${btsB[0].id}:visite` },
    { orgId, userId: users.learner, title: "Votre convocation au BTS blanc est disponible", href: "/moi", kind: "info", dedupeKey: `exam:${s.cohorts.btsBlanc}:learner`, readAt: new Date(s.now.getTime() - 3600_000) },
    { orgId, userId: users.employer, title: "Enquête employeur : votre avis sur le premier mois d'Inès", href: "/entreprise", kind: "info", dedupeKey: `survey:${s.surveyIds.employeur}:employer` },
    { orgId, userId: users.pedagogy, title: "BTS blanc : 4 apprentis du groupe B restent à inscrire", href: `${app}/examens/${s.cohorts.btsBlanc}`, kind: "info", dedupeKey: `exam:${s.cohorts.btsBlanc}:remaining` },
    { orgId, userId: users.direction, title: "Réclamation en cours : convocation tardive (Distrimarché)", href: `${app}/qualite`, kind: "warning", dedupeKey: `complaint:${s.complaintIds[1]}` },
  ];
  await db.insert(schema.notifications).values(notifs).onConflictDoNothing();
  bump(s, "notifications", notifs.length);
}
