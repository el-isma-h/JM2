import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { layoutMail } from "@/server/mail";
import { renderTemplate, type MissingItem, type RenderData } from "@/server/documents/render";
import { MAIL_TEMPLATE_DEFAULTS, MAIL_TEMPLATE_VARIABLES, mailTemplateDefault, mailTextToHtml, type MailTemplateDefault } from "./defaults";

export type MailTemplateRow = typeof schema.mailTemplates.$inferSelect;

export type OrgMailTemplate = {
  def: MailTemplateDefault;
  row: MailTemplateRow | null;
  subject: string;
  body: string;
  version: number;
  isDefault: boolean;
  updatedAt: Date | null;
};

/** Modèles par défaut, remplacés par la copie de l'organisme quand elle existe (filtre orgId strict). */
export async function listOrgMailTemplates(orgId: string): Promise<OrgMailTemplate[]> {
  const rows = await db.select().from(schema.mailTemplates).where(eq(schema.mailTemplates.orgId, orgId));
  return MAIL_TEMPLATE_DEFAULTS.map((def) => {
    const row = rows.find((r) => r.code === def.code) ?? null;
    return row
      ? { def, row, subject: row.subject, body: row.body, version: row.version, isDefault: row.isDefault, updatedAt: row.updatedAt }
      : { def, row: null, subject: def.subject, body: def.body, version: 1, isDefault: true, updatedAt: null };
  });
}

/** Ligne de l'organisme pour ce modèle (créée à partir du modèle par défaut si absente). */
export async function ensureOrgMailTemplate(orgId: string, code: string, userId: string): Promise<MailTemplateRow> {
  const def = mailTemplateDefault(code);
  if (!def) throw new Error("Modèle d'e-mail inconnu.");
  await db.insert(schema.mailTemplates).values({ orgId, code, title: def.title, subject: def.subject, body: def.body, updatedBy: userId }).onConflictDoNothing();
  const [row] = await db.select().from(schema.mailTemplates).where(and(eq(schema.mailTemplates.orgId, orgId), eq(schema.mailTemplates.code, code))).limit(1);
  if (!row) throw new Error("Modèle d'e-mail introuvable.");
  return row;
}

export async function getOrgMailTemplateById(orgId: string, id: string): Promise<MailTemplateRow | null> {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const [row] = await db.select().from(schema.mailTemplates).where(and(eq(schema.mailTemplates.id, id), eq(schema.mailTemplates.orgId, orgId))).limit(1);
  return row ?? null;
}

/** Enregistre objet et corps : nouvelle version si le contenu change. `source` est conservé dans l'audit. */
export async function saveOrgMailTemplate(ctx: OrgContext, code: string, content: { subject: string; body: string }, source: "manuel" | "reinitialisation" | "ia", proposalId?: string): Promise<{ row: MailTemplateRow; changed: boolean }> {
  const def = mailTemplateDefault(code);
  if (!def) throw new Error("Modèle d'e-mail inconnu.");
  const before = await ensureOrgMailTemplate(ctx.org.id, code, ctx.user.id);
  const changed = before.subject !== content.subject || before.body !== content.body;
  if (!changed) return { row: before, changed };
  const isDefault = content.subject === def.subject && content.body === def.body;
  const [row] = await db
    .update(schema.mailTemplates)
    .set({ subject: content.subject, body: content.body, version: before.version + 1, isDefault, updatedBy: ctx.user.id, updatedAt: new Date() })
    .where(and(eq(schema.mailTemplates.id, before.id), eq(schema.mailTemplates.orgId, ctx.org.id)))
    .returning();
  await audit({
    action: "mail_template.update",
    userId: ctx.user.id,
    orgId: ctx.org.id,
    entityType: "mail_template",
    entityId: before.id,
    before: { version: before.version, subject: before.subject, body: before.body },
    after: { version: row.version, subject: row.subject, bodyLength: row.body.length, source, proposalId: proposalId ?? null },
  });
  return { row, changed };
}

/** Variables communes : identité de l'organisme et signataire (utilisateur courant). */
export function baseMailData(ctx: OrgContext): RenderData {
  const o = ctx.org;
  const address = [o.addressLine1, o.addressLine2, [o.postalCode, o.city].filter(Boolean).join(" ")].filter(Boolean).join(", ");
  return {
    org: { name: o.tradeName ?? o.legalName, legalName: o.legalName, email: o.email ?? undefined, phone: o.phone ?? undefined, website: o.website ?? undefined, address: address || undefined, nda: o.nda ?? undefined, googleReviewUrl: o.googleReviewUrl ?? undefined },
    signer: { fullName: `${ctx.user.firstName} ${ctx.user.lastName}` },
  };
}

function deepMerge(a: RenderData, b: RenderData): RenderData {
  const out: RenderData = { ...a };
  for (const [k, v] of Object.entries(b)) {
    const cur = out[k];
    out[k] = v && typeof v === "object" && !Array.isArray(v) && cur && typeof cur === "object" && !Array.isArray(cur) ? deepMerge(cur as RenderData, v as RenderData) : v;
  }
  return out;
}

export type RenderedMail = { subject: string; text: string; html: string; missing: MissingItem[] };

/** Rendu d'un modèle de l'organisme : variable absente → « [À COMPLÉTER : …] » (listée dans `missing`). */
export async function renderOrgMailTemplate(ctx: OrgContext, code: string, data: RenderData = {}): Promise<RenderedMail> {
  const tpl = (await listOrgMailTemplates(ctx.org.id)).find((t) => t.def.code === code);
  if (!tpl) throw new Error("Modèle d'e-mail inconnu.");
  const all = deepMerge(baseMailData(ctx), data);
  const s = renderTemplate(tpl.subject, all, { labels: MAIL_TEMPLATE_VARIABLES });
  const b = renderTemplate(tpl.body, all, { labels: MAIL_TEMPLATE_VARIABLES });
  const missing = [...s.missing, ...b.missing.filter((m) => !s.missing.some((x) => x.key === m.key))];
  return { subject: s.text.replace(/\s+/g, " ").trim(), text: b.text, html: layoutMail(s.text, mailTextToHtml(b.text)), missing };
}

export type MailTemplatePayload = { mailTemplateId: string; code: string; title: string; subject: string; body: string; baseVersion: number; unknownVariables: string[] };

/** Effet d'une proposition IA validée : enregistre la rédaction comme nouvelle version (appelé par src/server/ai/apply.ts). */
export async function applyMailTemplateProposal(ctx: OrgContext, proposalId: string, d: MailTemplatePayload): Promise<{ ok: true; message: string; href: string } | { ok: false; reason: string }> {
  const row = await getOrgMailTemplateById(ctx.org.id, d.mailTemplateId);
  if (!row || row.code !== d.code) return { ok: false, reason: "Modèle d'e-mail introuvable." };
  if (row.version !== d.baseVersion) return { ok: false, reason: `Le modèle a été modifié depuis la proposition (version ${d.baseVersion} → ${row.version}) : relancez la rédaction pour partir de la version actuelle.` };
  const { row: saved, changed } = await saveOrgMailTemplate(ctx, d.code, { subject: d.subject, body: d.body }, "ia", proposalId);
  return { ok: true, message: changed ? `Modèle « ${d.title} » enregistré en version ${saved.version}.` : "Rédaction identique au modèle actuel : aucune nouvelle version.", href: `/app/${ctx.org.id}/modeles-emails#${d.code}` };
}
