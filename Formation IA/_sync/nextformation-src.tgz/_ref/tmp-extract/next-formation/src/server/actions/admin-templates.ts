"use server";

import { revalidatePath } from "next/cache";
import { and, eq, isNull } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requirePlatformAdmin } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { seedDocumentTemplates } from "@/server/documents/templates-seed";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

/** Édition du Markdown d'un modèle plateforme (orgId null) : nouvelle version, jamais de remplacement silencieux. */
export async function updateTemplateBodyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const d = z.object({ title: z.string().trim().min(2, "Titre requis.").max(200), description: z.string().trim().max(500).optional(), body: z.string().min(10, "Le corps du modèle est trop court.").max(200_000) }).parse(Object.fromEntries(formData));
    const [before] = await db.select().from(schema.documentTemplates).where(and(eq(schema.documentTemplates.id, id), isNull(schema.documentTemplates.orgId))).limit(1);
    if (!before) return { error: "Modèle plateforme introuvable." };
    const changed = before.body !== d.body;
    await db
      .update(schema.documentTemplates)
      .set({ title: d.title, description: d.description || null, body: d.body, version: changed ? before.version + 1 : before.version, verifiedAt: changed ? null : before.verifiedAt, verifiedNote: changed ? null : before.verifiedNote })
      .where(eq(schema.documentTemplates.id, id));
    await audit({ action: "admin.template.update", userId: admin.id, entityType: "document_template", entityId: id, before: { title: before.title, version: before.version, bodyLength: before.body.length }, after: { title: d.title, version: changed ? before.version + 1 : before.version, bodyLength: d.body.length } });
    revalidatePath("/admin/modeles");
    return { ok: true, message: changed ? `Modèle enregistré en version ${before.version + 1} (vérification à refaire).` : "Modèle enregistré (corps inchangé)." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function toggleTemplateActiveAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const [before] = await db.select().from(schema.documentTemplates).where(and(eq(schema.documentTemplates.id, id), isNull(schema.documentTemplates.orgId))).limit(1);
    if (!before) return { error: "Modèle plateforme introuvable." };
    await db.update(schema.documentTemplates).set({ isActive: !before.isActive }).where(eq(schema.documentTemplates.id, id));
    await audit({ action: "admin.template.toggle", userId: admin.id, entityType: "document_template", entityId: id, before: { isActive: before.isActive }, after: { isActive: !before.isActive } });
    revalidatePath("/admin/modeles");
    return { ok: true, message: before.isActive ? "Modèle désactivé : plus proposé aux organismes." : "Modèle activé." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

export async function verifyTemplateAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const note = z.string().trim().min(3, "Indiquez ce qui a été vérifié (mentions légales, variables).").max(500).parse(formData.get("note"));
    const [before] = await db.select().from(schema.documentTemplates).where(and(eq(schema.documentTemplates.id, id), isNull(schema.documentTemplates.orgId))).limit(1);
    if (!before) return { error: "Modèle plateforme introuvable." };
    await db.update(schema.documentTemplates).set({ verifiedAt: new Date(), verifiedNote: note }).where(eq(schema.documentTemplates.id, id));
    await audit({ action: "admin.template.verify", userId: admin.id, entityType: "document_template", entityId: id, after: { version: before.version, note } });
    revalidatePath("/admin/modeles");
    return { ok: true, message: "Vérification humaine enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function seedTemplatesAction(): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const r = await seedDocumentTemplates();
    await audit({ action: "admin.template.seed", userId: admin.id, entityType: "document_template", after: r });
    revalidatePath("/admin/modeles");
    return { ok: true, message: `${r.inserted} modèle(s) ajouté(s), ${r.updated} mis à jour, ${r.total} au total.` };
  } catch (e) {
    return fail(e, "Chargement impossible.");
  }
}
