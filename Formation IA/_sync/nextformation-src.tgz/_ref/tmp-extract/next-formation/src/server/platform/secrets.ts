/**
 * Clés et réglages de la plateforme saisis depuis /admin/cles-api (table `platform_secrets`, valeur chiffrée
 * AES-256-GCM avec `encrypt(…, "platform-secret")`, jamais renvoyée en clair à l'interface ni journalisée).
 *
 * Règle de priorité (documentée dans /admin/cles-api) :
 *   1. Une variable déjà définie dans l'environnement du serveur (.env, docker-compose, orchestrateur) au moment
 *      du chargement garde la priorité : la valeur enregistrée en base est conservée mais ignorée (source
 *      « environnement », valeur en base « masquée »). Raison : l'hébergeur garde toujours la main, et une base
 *      restaurée ne peut pas remplacer silencieusement une clé posée par l'exploitation.
 *   2. Sinon la valeur de la base est écrite dans `process.env[key]` et la clé est mémorisée dans l'ensemble
 *      `fromDb` (partagé sur globalThis, donc commun à toutes les copies du module dans le processus). Une variable
 *      présente dans `process.env` mais issue de la base n'est pas « définie par le serveur » : un rechargement
 *      ou une mise à jour depuis l'admin l'écrase bien.
 *   3. `setPlatformSecret` écrit immédiatement dans `process.env` (sans redémarrage), sauf si la clé est fixée
 *      par l'environnement du serveur (règle 1) : la valeur est alors enregistrée et un message l'explique.
 *   4. `deletePlatformSecret` retire la ligne et, si la valeur active venait de la base, la retire de `process.env`.
 *   Plusieurs instances : chaque instance lit la base au démarrage ; une modification depuis l'admin est appliquée
 *   immédiatement sur l'instance qui la reçoit, et sur les autres au prochain chargement (redémarrage ou ouverture
 *   de /admin/cles-api, qui recharge).
 *
 * Ce module n'importe pas "server-only" ni l'audit au niveau du module : il est chargé par src/instrumentation.ts.
 */
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { decrypt, encrypt } from "@/lib/crypto";

const PURPOSE = "platform-secret";

export type SecretKind = "secret" | "text" | "boolean";

export type PlatformSecretDef = {
  key: string;
  label: string;
  kind: SecretKind;
  group: "ia" | "mail";
  help: string;
  /** Contrôle de forme (jamais un appel réseau). */
  validate: (v: string) => string | null;
  /** Fournisseur IA testable (aligné sur src/server/ai/provider.ts). */
  provider?: "anthropic" | "openai" | "xai";
};

const noSpace = (v: string) => (/\s/.test(v) ? "La valeur ne doit pas contenir d'espace." : null);
const prefixed = (prefix: string, label: string) => (v: string) => noSpace(v) ?? (v.startsWith(prefix) && v.length >= prefix.length + 16 ? null : `Une clé ${label} commence par « ${prefix} » et compte au moins ${prefix.length + 16} caractères.`);

/**
 * Liste blanche. Les fournisseurs IA suivent src/server/ai/provider.ts (Anthropic, OpenAI, xAI Grok) :
 * Mistral n'y est pas pris en charge, sa clé n'est donc pas proposée (elle n'aurait aucun effet).
 */
export const PLATFORM_SECRETS: PlatformSecretDef[] = [
  { key: "ANTHROPIC_API_KEY", label: "Anthropic (Claude)", kind: "secret", group: "ia", provider: "anthropic", help: "Clé de la console Anthropic, commence par sk-ant-.", validate: prefixed("sk-ant-", "Anthropic") },
  { key: "OPENAI_API_KEY", label: "OpenAI", kind: "secret", group: "ia", provider: "openai", help: "Clé de platform.openai.com, commence par sk-.", validate: prefixed("sk-", "OpenAI") },
  { key: "XAI_API_KEY", label: "xAI (Grok)", kind: "secret", group: "ia", provider: "xai", help: "Clé de console.x.ai, commence par xai-.", validate: prefixed("xai-", "xAI") },
  { key: "RESEND_API_KEY", label: "Resend", kind: "secret", group: "mail", help: "Clé de resend.com, commence par re_. Sans MAIL_ENABLED=true, aucun e-mail ne part.", validate: prefixed("re_", "Resend") },
  {
    key: "MAIL_FROM",
    label: "Expéditeur",
    kind: "text",
    group: "mail",
    help: "Ex. Next Formation <no-reply@votre-domaine.fr> : domaine vérifié chez Resend.",
    validate: (v) => (/^([^<>]{1,80}<)?[^@\s<>]+@[^@\s<>]+\.[a-z]{2,}>?$/i.test(v.trim()) && !/example\.com/i.test(v) ? null : "Adresse d'expéditeur invalide (ex. Next Formation <no-reply@votre-domaine.fr>)."),
  },
  { key: "MAIL_ENABLED", label: "Envoi activé", kind: "boolean", group: "mail", help: "true : les e-mails partent via Resend. false (par défaut) : ils restent dans la boîte d'envoi.", validate: (v) => (v === "true" || v === "false" ? null : "Valeur attendue : true ou false.") },
];

export const PLATFORM_SECRET_KEYS = PLATFORM_SECRETS.map((s) => s.key);

export function secretDef(key: string): PlatformSecretDef | null {
  return PLATFORM_SECRETS.find((s) => s.key === key) ?? null;
}

type SecretsState = { fromDb: Set<string>; loadedAt: Date | null };
const g = globalThis as unknown as { __platformSecrets?: SecretsState };
function state(): SecretsState {
  if (!g.__platformSecrets) g.__platformSecrets = { fromDb: new Set(), loadedAt: null };
  return g.__platformSecrets;
}

/** Vrai si la variable est fixée par l'environnement du serveur (et non par une valeur chargée depuis la base). */
function pinnedByServerEnv(key: string): boolean {
  return Boolean(process.env[key]?.trim()) && !state().fromDb.has(key);
}

function last4Of(v: string) {
  return v.length <= 4 ? v : v.slice(-4);
}

/**
 * Charge les secrets de la base dans process.env (démarrage, puis ouverture de /admin/cles-api).
 * Ne lève jamais : une base indisponible ou un APP_SECRET absent laisse l'environnement tel quel.
 */
export async function loadPlatformSecretsIntoEnv(): Promise<{ loaded: string[]; shadowed: string[]; errors: string[] }> {
  const st = state();
  const loaded: string[] = [];
  const shadowed: string[] = [];
  const errors: string[] = [];
  let rows: (typeof schema.platformSecrets.$inferSelect)[] = [];
  try {
    rows = await db.select().from(schema.platformSecrets);
  } catch {
    return { loaded, shadowed, errors: ["lecture de platform_secrets impossible"] };
  }
  const present = new Set<string>();
  for (const r of rows) {
    if (!PLATFORM_SECRET_KEYS.includes(r.key) || !r.valueEnc) continue;
    present.add(r.key);
    if (pinnedByServerEnv(r.key)) {
      shadowed.push(r.key);
      continue;
    }
    try {
      process.env[r.key] = decrypt(r.valueEnc, PURPOSE);
      st.fromDb.add(r.key);
      loaded.push(r.key);
    } catch {
      errors.push(`${r.key} : déchiffrement impossible (APP_SECRET modifié ?)`);
    }
  }
  // Ligne supprimée par une autre instance : la valeur venue de la base disparaît aussi ici.
  for (const k of [...st.fromDb]) {
    if (!present.has(k)) {
      delete process.env[k];
      st.fromDb.delete(k);
    }
  }
  st.loadedAt = new Date();
  return { loaded, shadowed, errors };
}

export type PlatformSecretSource = "base" | "environnement" | "absente";

export type PlatformSecretListItem = {
  key: string;
  last4: string | null;
  updatedAt: Date | null;
  source: PlatformSecretSource;
  /** Une valeur existe en base mais l'environnement du serveur garde la priorité. */
  shadowed: boolean;
};

/** Clés de la liste blanche avec last4, date et source. Jamais de valeur, chiffrée ou non. */
export async function listPlatformSecrets(): Promise<PlatformSecretListItem[]> {
  const rows = await db.select({ key: schema.platformSecrets.key, last4: schema.platformSecrets.last4, updatedAt: schema.platformSecrets.updatedAt, hasValue: schema.platformSecrets.valueEnc }).from(schema.platformSecrets);
  return PLATFORM_SECRETS.map(({ key }) => {
    const r = rows.find((x) => x.key === key && x.hasValue);
    const fromDb = state().fromDb.has(key);
    const envSet = Boolean(process.env[key]?.trim());
    const source: PlatformSecretSource = fromDb ? "base" : envSet ? "environnement" : "absente";
    return { key, last4: r?.last4 ?? null, updatedAt: r?.updatedAt ?? null, source, shadowed: Boolean(r) && source === "environnement" };
  });
}

export type SetSecretResult = { applied: boolean; message: string };

/** Chiffre et enregistre une valeur de la liste blanche, l'applique à process.env et audite (sans la valeur). */
export async function setPlatformSecret(key: string, value: string, userId: string): Promise<SetSecretResult> {
  const def = secretDef(key);
  if (!def) throw new Error("Clé non autorisée.");
  const v = value.trim();
  if (!v) throw new Error("Valeur vide.");
  const invalid = def.validate(v);
  if (invalid) throw new Error(invalid);
  const [before] = await db.select({ key: schema.platformSecrets.key }).from(schema.platformSecrets).where(eq(schema.platformSecrets.key, key)).limit(1);
  const row = { valueEnc: encrypt(v, PURPOSE), last4: last4Of(v),updatedBy: userId, updatedAt: new Date() };
  await db
    .insert(schema.platformSecrets)
    .values({ key, ...row })
    .onConflictDoUpdate({ target: schema.platformSecrets.key, set: row });
  const pinned = pinnedByServerEnv(key);
  if (!pinned) {
    process.env[key] = v;
    state().fromDb.add(key);
  }
  const { audit } = await import("@/server/audit");
  await audit({ action: "platform.secret.set", userId, entityType: "platform_secret", after: { key, replaced: Boolean(before), appliedToEnv: !pinned } });
  return pinned
    ? { applied: false, message: `${key} enregistrée, mais la variable définie dans l'environnement du serveur garde la priorité : retirez-la du .env (puis redémarrez) pour utiliser cette valeur.` }
    : { applied: true, message: `${key} enregistrée et appliquée immédiatement.` };
}

/** Supprime la valeur enregistrée ; si la valeur active venait de la base, elle est retirée de process.env. */
export async function deletePlatformSecret(key: string, userId: string): Promise<{ deleted: boolean; message: string }> {
  if (!secretDef(key)) throw new Error("Clé non autorisée.");
  const res = await db.delete(schema.platformSecrets).where(eq(schema.platformSecrets.key, key)).returning({ key: schema.platformSecrets.key });
  const st = state();
  const wasActive = st.fromDb.has(key);
  if (wasActive) {
    delete process.env[key];
    st.fromDb.delete(key);
  }
  const { audit } = await import("@/server/audit");
  await audit({ action: "platform.secret.delete", userId, entityType: "platform_secret", after: { key, existed: res.length > 0, removedFromEnv: wasActive } });
  if (!res.length) return { deleted: false, message: `Aucune valeur enregistrée pour ${key}.` };
  return { deleted: true, message: wasActive ? `${key} supprimée : elle n'est plus active.` : `${key} supprimée de la base. La variable de l'environnement du serveur reste active.` };
}
