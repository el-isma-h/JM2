import { describe, expect, it } from "vitest";
import { aiStatus, configuredProviders, extractJson, pickProvider } from "../provider";

describe("pickProvider : une seule clé suffit, ordre Anthropic > OpenAI > xAI", () => {
  it("retourne null sans aucune clé", () => {
    expect(pickProvider({})).toBeNull();
    expect(pickProvider({ ANTHROPIC_API_KEY: "   " })).toBeNull();
  });
  it("prend Anthropic en premier quand plusieurs clés sont présentes", () => {
    const p = pickProvider({ ANTHROPIC_API_KEY: "a", OPENAI_API_KEY: "o", XAI_API_KEY: "x" });
    expect(p?.name).toBe("anthropic");
    expect(p?.model).toBe("claude-sonnet-4-5");
  });
  it("prend OpenAI puis xAI quand Anthropic manque", () => {
    expect(pickProvider({ OPENAI_API_KEY: "o", XAI_API_KEY: "x" })?.name).toBe("openai");
    const x = pickProvider({ XAI_API_KEY: "x", XAI_MODEL: "grok-4" });
    expect(x?.name).toBe("xai");
    expect(x?.model).toBe("grok-4");
    expect(x?.baseUrl).toBe("https://api.x.ai/v1");
  });
  it("AI_PROVIDER force un fournisseur configuré, sinon retombe sur l'ordre par défaut", () => {
    expect(pickProvider({ ANTHROPIC_API_KEY: "a", OPENAI_API_KEY: "o", AI_PROVIDER: "openai" })?.name).toBe("openai");
    expect(pickProvider({ ANTHROPIC_API_KEY: "a", AI_PROVIDER: "xai" })?.name).toBe("anthropic");
    expect(configuredProviders({ ANTHROPIC_API_KEY: "a", OPENAI_API_KEY: "o", XAI_API_KEY: "x", AI_PROVIDER: "XAI" }).map((p) => p.name)).toEqual(["xai", "anthropic", "openai"]);
  });
  it("aiStatus explique la configuration manquante", () => {
    const s = aiStatus({});
    expect(s.configured).toBe(false);
    if (!s.configured) expect(s.envVars).toEqual(["ANTHROPIC_API_KEY", "OPENAI_API_KEY", "XAI_API_KEY"]);
    const ok = aiStatus({ OPENAI_API_KEY: "o", OPENAI_MODEL: "gpt-4.1" });
    expect(ok).toMatchObject({ configured: true, provider: "openai", model: "gpt-4.1" });
  });
});

describe("extractJson", () => {
  it("tolère les balises de code et le texte autour", () => {
    expect(extractJson('```json\n{"a":1}\n```')).toEqual({ a: 1 });
    expect(extractJson('Voici : {"answer":"ok"} merci')).toEqual({ answer: "ok" });
    expect(extractJson("pas de json")).toBeNull();
  });
});
