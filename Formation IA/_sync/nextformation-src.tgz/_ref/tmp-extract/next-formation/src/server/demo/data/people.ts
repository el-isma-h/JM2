/**
 * Identités fictives (noms français variés) : apprenants, candidats, contacts, formateurs.
 * Aucune personne réelle ; e-mails en @exemple.fr.
 */

export const FIRST_NAMES_F = ["Inès", "Camille", "Léa", "Manon", "Chloé", "Sarah", "Nour", "Aïcha", "Louise", "Clara", "Jade", "Lina", "Emma", "Maëlle", "Océane", "Salomé", "Anaïs", "Romane", "Fatoumata", "Yasmine", "Margaux", "Zoé", "Élodie", "Audrey", "Céline", "Laetitia", "Nadia", "Sandrine", "Valérie", "Hélène", "Agnès", "Delphine", "Mélanie", "Samira", "Awa", "Pauline", "Justine", "Amandine", "Solène", "Bérénice"];
export const FIRST_NAMES_M = ["Lucas", "Hugo", "Enzo", "Nathan", "Mathis", "Yanis", "Rayan", "Ilyes", "Noah", "Théo", "Adam", "Gabriel", "Sofiane", "Malik", "Bastien", "Quentin", "Florian", "Kévin", "Jérémy", "Maxime", "Romain", "Arnaud", "Cédric", "Sébastien", "Olivier", "Laurent", "Fabrice", "Stéphane", "Moussa", "Abdel", "Thibault", "Corentin", "Alexis", "Damien", "Benoît", "Grégory", "Mickaël", "Pierre-Louis", "Ousmane", "Bilal"];
export const LAST_NAMES = ["Carvalho", "Lemoine", "Bouaziz", "Perrin", "Da Silva", "Nguyen", "Martel", "Chevalier", "Diallo", "Roux", "Fontaine", "Benkacem", "Girard", "Mercier", "Lambert", "Aubry", "Moreno", "Keita", "Leroy", "Bonnet", "Dumas", "Faure", "Rousseau", "Gauthier", "Traoré", "Hamidi", "Picard", "Renard", "Sanchez", "Vidal", "Lacroix", "Guillot", "Noël", "Barbier", "Charpentier", "Ferreira", "Morel", "Benoît", "Delorme", "Jacquet", "Meunier", "Pelletier", "Ricard", "Schmitt", "Tessier", "Vasseur", "Weber", "Ziani", "Okafor", "Lefèvre", "Collet", "Brunet", "Marchal", "Sow", "Petitjean", "Royer", "Prévost", "Guérin", "Hamon", "Cousin"];

export const CITIES = [
  { city: "Paris", postalCode: "75011" },
  { city: "Paris", postalCode: "75020" },
  { city: "Montreuil", postalCode: "93100" },
  { city: "Bagnolet", postalCode: "93170" },
  { city: "Vincennes", postalCode: "94300" },
  { city: "Saint-Denis", postalCode: "93200" },
  { city: "Pantin", postalCode: "93500" },
  { city: "Ivry-sur-Seine", postalCode: "94200" },
  { city: "Noisy-le-Sec", postalCode: "93130" },
  { city: "Fontenay-sous-Bois", postalCode: "94120" },
  { city: "Gennevilliers", postalCode: "92230" },
  { city: "Créteil", postalCode: "94000" },
];

export const STREETS = ["rue de la Roquette", "avenue Gambetta", "rue des Pyrénées", "boulevard Voltaire", "rue de Bagnolet", "allée des Peupliers", "rue Jean-Jaurès", "avenue de la République", "rue Marcel-Sembat", "rue des Lilas", "impasse du Moulin", "rue Paul-Éluard"];

export type CompanySeed = {
  key: string;
  name: string;
  base8: string;
  sector: string;
  ape: string;
  idcc: string;
  opco: string;
  headcount: number;
  address: string;
  postalCode: string;
  city: string;
  status: "prospect" | "client" | "partenaire" | "inactif";
  contacts: { civility: "M" | "Mme"; firstName: string; lastName: string; jobTitle: string; isSignatory?: boolean; isTutor?: boolean; isBilling?: boolean }[];
};

/** 12 entreprises de secteurs variés. `base8` : 8 premiers chiffres du SIREN fictif (clé calculée). */
export const COMPANIES: CompanySeed[] = [
  {
    key: "deschamps",
    name: "Deschamps Agencement",
    base8: "84215307",
    sector: "Industrie : menuiserie et agencement",
    ape: "16.23Z",
    idcc: "1596",
    opco: "OPCO 2i",
    headcount: 46,
    address: "23 rue des Frères-Lumière",
    postalCode: "93100",
    city: "Montreuil",
    status: "client",
    contacts: [
      { civility: "M", firstName: "Julien", lastName: "Deschamps", jobTitle: "Dirigeant, maître d'apprentissage", isSignatory: true, isTutor: true },
      { civility: "Mme", firstName: "Patricia", lastName: "Verdier", jobTitle: "Assistante de gestion", isBilling: true },
    ],
  },
  {
    key: "clinique",
    name: "Clinique Sainte-Odile",
    base8: "51902374",
    sector: "Santé : clinique privée",
    ape: "86.10Z",
    idcc: "2264",
    opco: "OPCO Santé",
    headcount: 310,
    address: "118 rue de Bagnolet",
    postalCode: "75020",
    city: "Paris",
    status: "client",
    contacts: [
      { civility: "Mme", firstName: "Véronique", lastName: "Lestrade", jobTitle: "Directrice des ressources humaines", isSignatory: true },
      { civility: "M", firstName: "Frédéric", lastName: "Amsellem", jobTitle: "Cadre de santé, tuteur", isTutor: true },
      { civility: "Mme", firstName: "Nathalie", lastName: "Pons", jobTitle: "Comptabilité fournisseurs", isBilling: true },
    ],
  },
  {
    key: "fournel",
    name: "Cabinet Fournel & Associés",
    base8: "38041592",
    sector: "Expertise comptable",
    ape: "69.20Z",
    idcc: "0787",
    opco: "Atlas",
    headcount: 28,
    address: "9 boulevard Voltaire",
    postalCode: "75011",
    city: "Paris",
    status: "client",
    contacts: [
      { civility: "M", firstName: "Étienne", lastName: "Fournel", jobTitle: "Expert-comptable associé", isSignatory: true, isTutor: true },
      { civility: "Mme", firstName: "Sabrina", lastName: "Haddad", jobTitle: "Responsable administrative", isBilling: true },
    ],
  },
  {
    key: "distrimarche",
    name: "Distrimarché Île-de-France",
    base8: "42778130",
    sector: "Enseigne de distribution alimentaire",
    ape: "47.11D",
    idcc: "2216",
    opco: "OPCOmmerce",
    headcount: 1240,
    address: "4 avenue de la Résistance",
    postalCode: "93100",
    city: "Montreuil",
    status: "client",
    contacts: [
      { civility: "Mme", firstName: "Karine", lastName: "Boulanger", jobTitle: "Responsable formation régionale", isSignatory: true },
      { civility: "M", firstName: "Samuel", lastName: "Ndiaye", jobTitle: "Directeur de magasin, tuteur", isTutor: true },
      { civility: "M", firstName: "Loïc", lastName: "Garnier", jobTitle: "Service comptabilité", isBilling: true },
    ],
  },
  {
    key: "mairie",
    name: "Ville de Montreuil",
    base8: "21930048",
    sector: "Collectivité territoriale",
    ape: "84.11Z",
    idcc: "",
    opco: "",
    headcount: 2800,
    address: "Place Jean-Jaurès",
    postalCode: "93100",
    city: "Montreuil",
    status: "client",
    contacts: [
      { civility: "Mme", firstName: "Isabelle", lastName: "Quéré", jobTitle: "Chargée de formation, DRH", isSignatory: true, isBilling: true },
      { civility: "M", firstName: "Hervé", lastName: "Lafon", jobTitle: "Responsable du service accueil", isTutor: true },
    ],
  },
  {
    key: "nolwen",
    name: "Nolwen Technologies",
    base8: "90312564",
    sector: "Start-up : logiciel",
    ape: "62.01Z",
    idcc: "1486",
    opco: "Atlas",
    headcount: 19,
    address: "61 rue de la Folie-Méricourt",
    postalCode: "75011",
    city: "Paris",
    status: "prospect",
    contacts: [
      { civility: "Mme", firstName: "Maud", lastName: "Kerjean", jobTitle: "Cofondatrice, COO", isSignatory: true, isBilling: true },
      { civility: "M", firstName: "Aurélien", lastName: "Brossard", jobTitle: "Office manager" },
    ],
  },
  {
    key: "berard",
    name: "Transports Bérard",
    base8: "33457829",
    sector: "Transport routier de marchandises",
    ape: "49.41A",
    idcc: "0016",
    opco: "OPCO Mobilités",
    headcount: 72,
    address: "ZA des Marais, 12 rue Ampère",
    postalCode: "93500",
    city: "Pantin",
    status: "client",
    contacts: [
      { civility: "M", firstName: "Gilles", lastName: "Bérard", jobTitle: "Gérant", isSignatory: true, isBilling: true },
      { civility: "Mme", firstName: "Sonia", lastName: "Rahmani", jobTitle: "Responsable exploitation, tutrice", isTutor: true },
    ],
  },
  {
    key: "tilleuls",
    name: "Résidence Les Tilleuls",
    base8: "47906215",
    sector: "Médico-social : EHPAD",
    ape: "87.10A",
    idcc: "2264",
    opco: "OPCO Santé",
    headcount: 85,
    address: "37 rue des Lilas",
    postalCode: "93170",
    city: "Bagnolet",
    status: "client",
    contacts: [
      { civility: "Mme", firstName: "Dominique", lastName: "Rivoal", jobTitle: "Directrice d'établissement", isSignatory: true, isBilling: true },
      { civility: "Mme", firstName: "Élise", lastName: "Camara", jobTitle: "Infirmière coordinatrice, tutrice", isTutor: true },
    ],
  },
  {
    key: "pharmacie",
    name: "Pharmacie du Canal",
    base8: "52831470",
    sector: "Commerce : pharmacie d'officine",
    ape: "47.73Z",
    idcc: "1996",
    opco: "OPCO EP",
    headcount: 9,
    address: "2 quai de Jemmapes",
    postalCode: "75010",
    city: "Paris",
    status: "client",
    contacts: [{ civility: "Mme", firstName: "Hélène", lastName: "Marty", jobTitle: "Pharmacienne titulaire", isSignatory: true, isTutor: true, isBilling: true }],
  },
  {
    key: "moretti",
    name: "Garage Moretti",
    base8: "41265903",
    sector: "Réparation automobile",
    ape: "45.20A",
    idcc: "1090",
    opco: "OPCO Mobilités",
    headcount: 14,
    address: "88 avenue Gambetta",
    postalCode: "93170",
    city: "Bagnolet",
    status: "client",
    contacts: [
      { civility: "M", firstName: "Paolo", lastName: "Moretti", jobTitle: "Gérant, maître d'apprentissage", isSignatory: true, isTutor: true },
      { civility: "Mme", firstName: "Christelle", lastName: "Moretti", jobTitle: "Gestion administrative", isBilling: true },
    ],
  },
  {
    key: "hotel",
    name: "Hôtel Parc Royal",
    base8: "78123905",
    sector: "Hôtellerie",
    ape: "55.10Z",
    idcc: "1979",
    opco: "AKTO",
    headcount: 52,
    address: "15 rue de Charonne",
    postalCode: "75011",
    city: "Paris",
    status: "prospect",
    contacts: [
      { civility: "M", firstName: "Nicolas", lastName: "Thuillier", jobTitle: "Directeur général", isSignatory: true },
      { civility: "Mme", firstName: "Leïla", lastName: "Benamar", jobTitle: "Cheffe de réception, tutrice", isTutor: true },
    ],
  },
  {
    key: "vauclair",
    name: "Groupe Vauclair Immobilier",
    base8: "36984127",
    sector: "Immobilier : administration de biens",
    ape: "68.32A",
    idcc: "1527",
    opco: "OPCO EP",
    headcount: 160,
    address: "30 rue de Vincennes",
    postalCode: "93100",
    city: "Montreuil",
    status: "inactif",
    contacts: [
      { civility: "Mme", firstName: "Anne-Laure", lastName: "Vauclair", jobTitle: "Présidente", isSignatory: true },
      { civility: "M", firstName: "Thierry", lastName: "Espinosa", jobTitle: "DRH", isBilling: true },
    ],
  },
];

export type TrainerSeed = {
  key: "thomas" | "nathalie" | "claire" | "antoine" | "isabelle";
  civility: "M" | "Mme";
  firstName: string;
  lastName: string;
  kind: "interne" | "externe" | "sous_traitant";
  companyName?: string;
  base8?: string;
  nda?: string;
  skills: string[];
  qualifications: string;
  hourlyRateCents: number;
};

export const EXTERNAL_TRAINERS: TrainerSeed[] = [
  { key: "claire", civility: "Mme", firstName: "Claire", lastName: "Vasseur", kind: "externe", companyName: "Claire Vasseur Formation (EI)", base8: "88430162", nda: "11 93 08567 93", skills: ["Bureautique", "Excel avancé", "Power Query"], qualifications: "Formatrice bureautique depuis 2014, certification TOSA Excel niveau expert (2024), master MIAGE.", hourlyRateCents: 6500 },
  { key: "antoine", civility: "M", firstName: "Antoine", lastName: "Mbarga", kind: "sous_traitant", companyName: "Prévenlys SAS", base8: "81209476", nda: "11 75 59012 75", skills: ["SST", "Habilitation électrique", "Prévention des risques"], qualifications: "Formateur SST certifié INRS (recyclage 2025), formateur habilitation électrique NF C 18-510, 12 ans en bureau de contrôle.", hourlyRateCents: 7200 },
  { key: "isabelle", civility: "Mme", firstName: "Isabelle", lastName: "Tanguy", kind: "externe", companyName: "IT Conseil RH", base8: "79456201", nda: "11 92 24310 92", skills: ["Ressources humaines", "Management", "Paie et administration du personnel"], qualifications: "Ancienne DRH (18 ans en PME industrielle), titre professionnel formateur pour adultes (2021), coach certifiée.", hourlyRateCents: 8000 },
];

export const INTERNAL_TRAINERS: Record<"thomas" | "nathalie", { skills: string[]; qualifications: string; hourlyRateCents: number }> = {
  thomas: { skills: ["Gestion de la PME", "Comptabilité", "Communication professionnelle"], qualifications: "Professeur certifié d'économie-gestion, DSCG, 9 ans d'enseignement en BTS Gestion de la PME.", hourlyRateCents: 4800 },
  nathalie: { skills: ["Ressources humaines", "Ingénierie pédagogique", "Droit du travail"], qualifications: "Master GRH, responsable pédagogique depuis 2017, habilitée jury titre professionnel ARH.", hourlyRateCents: 5200 },
};
