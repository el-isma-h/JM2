import "server-only";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { formatCents } from "@/lib/money";
import { fmtMinutes } from "@/lib/time";
import { ISSUED_STATUSES } from "./service";
import type { FunderKind } from "./compute";

/**
 * Bilan pédagogique et financier (BPF) : calcul préparatoire pour une année civile.
 * Chaque indicateur porte sa définition, son dénominateur, ses exclusions et sa date de calcul (CDC F15),
 * et ouvre la liste qui le compose (`detail`).
 */

export type BpfIndicator = {
  code: string;
  label: string;
  value: number;
  display: string;
  unit: "euros" | "nombre" | "heures";
  definition: string;
  denominator: string;
  exclusions: string;
  count: number;
};

export type BpfSection = { code: string; title: string; indicators: BpfIndicator[] };

export type BpfDetailRow = { id: string; href: string; label: string; sub: string; value: string };

export type BpfReport = { year: number; computedAt: string; sections: BpfSection[] };

export const EXPENSE_CATEGORIES: Record<string, string> = {
  sous_traitance: "Sous-traitance pédagogique",
  salaires: "Salaires et charges (formateurs, administratif)",
  locaux: "Locaux et équipements",
  materiel: "Matériel et fournitures pédagogiques",
  deplacements: "Déplacements",
  marketing: "Communication et commercial",
  logiciels: "Logiciels et services",
  certification: "Certification et examens",
  autre: "Autres charges",
};

/** Rubrique de produits BPF selon le destinataire de la facture ou le type de financeur. */
export function revenueBucket(billToKind: string | null | undefined, funderKind: FunderKind | null | undefined, hasPerson: boolean): "entreprises" | "opco" | "pouvoirs_publics" | "particuliers" | "autres" {
  if (funderKind) {
    if (funderKind === "opco") return "opco";
    if (funderKind === "france_travail" || funderKind === "region" || funderKind === "etat" || funderKind === "agefiph") return "pouvoirs_publics";
    if (funderKind === "entreprise") return "entreprises";
    if (funderKind === "particulier") return "particuliers";
    return "autres";
  }
  if (billToKind === "particulier" || (billToKind !== "entreprise" && hasPerson)) return "particuliers";
  if (billToKind === "entreprise") return "entreprises";
  return "autres";
}

const bucketLabels = { entreprises: "Entreprises (fonds propres)", opco: "OPCO et fonds mutualisés", pouvoirs_publics: "Pouvoirs publics (État, Région, France Travail, Agefiph)", particuliers: "Particuliers (fonds propres)", autres: "Autres produits (CPF, Transitions Pro, autres financeurs)" } as const;

async function invoicesOfYear(orgId: string, year: number) {
  return db
    .select({ i: schema.invoices, funderKind: schema.funders.kind })
    .from(schema.invoices)
    .leftJoin(schema.funders, eq(schema.funders.id, schema.invoices.funderId))
    .where(and(eq(schema.invoices.orgId, orgId), inArray(schema.invoices.status, ISSUED_STATUSES), inArray(schema.invoices.kind, ["facture", "acompte", "avoir"]), sql`extract(year from ${schema.invoices.issueDate}) = ${year}`));
}

async function enrollmentsOfYear(orgId: string, year: number) {
  const start = `${year}-01-01`;
  const end = `${year}-12-31`;
  return db
    .select({ e: schema.enrollments, s: schema.trainingSessions, formacode: schema.programs.formacode, programTitle: schema.programs.title, person: { firstName: schema.persons.firstName, lastName: schema.persons.lastName } })
    .from(schema.enrollments)
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
    .innerJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(
      and(
        eq(schema.enrollments.orgId, orgId),
        inArray(schema.enrollments.status, ["inscrit", "en_cours", "termine", "abandon"]),
        sql`coalesce(${schema.enrollments.startDate}, ${schema.trainingSessions.startDate}) <= ${end}`,
        sql`coalesce(${schema.enrollments.exitDate}, ${schema.enrollments.endDate}, ${schema.trainingSessions.endDate}) >= ${start}`,
      ),
    );
}

/** Minutes validées par inscription (périodes clôturées, lignes de présence courantes) sur l'année. */
async function validatedMinutes(orgId: string, year: number): Promise<Map<string, number>> {
  const rows = await db
    .select({ enrollmentId: schema.attendances.enrollmentId, minutes: sql<number>`coalesce(sum(${schema.attendances.minutesCounted}), 0)::int` })
    .from(schema.attendances)
    .innerJoin(schema.periods, eq(schema.periods.id, schema.attendances.periodId))
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .where(and(eq(schema.attendances.orgId, orgId), eq(schema.attendances.isCurrent, true), eq(schema.periods.status, "cloturee"), sql`extract(year from ${schema.slots.date}) = ${year}`))
    .groupBy(schema.attendances.enrollmentId);
  return new Map(rows.map((r) => [r.enrollmentId, r.minutes]));
}

export async function computeBpf(orgId: string, year: number): Promise<BpfReport> {
  const computedAt = new Date().toISOString();
  const [invoices, expenses, enrollments, minutes] = await Promise.all([
    invoicesOfYear(orgId, year),
    db.select().from(schema.expenses).where(and(eq(schema.expenses.orgId, orgId), sql`extract(year from ${schema.expenses.date}) = ${year}`)),
    enrollmentsOfYear(orgId, year),
    validatedMinutes(orgId, year),
  ]);

  const defExcl = { denominator: "Factures et avoirs émis (numérotés) dont la date d'émission est dans l'année civile, montants HT figés à l'émission.", exclusions: "Brouillons, pro forma et factures annulées ; les règlements encaissés ne sont pas pris en compte (comptabilité d'engagement)." };
  const buckets: Record<keyof typeof bucketLabels, { sum: number; n: number }> = { entreprises: { sum: 0, n: 0 }, opco: { sum: 0, n: 0 }, pouvoirs_publics: { sum: 0, n: 0 }, particuliers: { sum: 0, n: 0 }, autres: { sum: 0, n: 0 } };
  for (const { i, funderKind } of invoices) {
    const b = revenueBucket((i.billTo as { kind?: string })?.kind, funderKind as FunderKind | null, Boolean(i.personId));
    buckets[b].sum += (i.kind === "avoir" ? -1 : 1) * i.totalHtCents;
    buckets[b].n++;
  }
  const produits: BpfIndicator[] = (Object.keys(bucketLabels) as (keyof typeof bucketLabels)[]).map((k) => ({
    code: `produits_${k}`,
    label: bucketLabels[k],
    value: buckets[k].sum,
    display: formatCents(buckets[k].sum),
    unit: "euros",
    definition: `Somme HT des factures émises (moins les avoirs) dont le financeur est de type « ${bucketLabels[k]} ».`,
    ...defExcl,
    count: buckets[k].n,
  }));
  const totalProduits = produits.reduce((a, p) => a + p.value, 0);
  produits.push({ code: "produits_total", label: "Total des produits", value: totalProduits, display: formatCents(totalProduits), unit: "euros", definition: "Somme des rubriques précédentes.", ...defExcl, count: invoices.length });

  const byCat = new Map<string, { sum: number; n: number }>();
  for (const x of expenses) {
    const c = byCat.get(x.category) ?? { sum: 0, n: 0 };
    c.sum += x.amountHtCents;
    c.n++;
    byCat.set(x.category, c);
  }
  const chargesDef = { denominator: "Dépenses saisies dans « BPF / Dépenses » datées dans l'année civile, montants HT.", exclusions: "Dépenses sans date ou hors année ; aucune donnée de comptabilité générale n'est importée." };
  const charges: BpfIndicator[] = [...byCat.entries()]
    .sort((a, b) => b[1].sum - a[1].sum)
    .map(([cat, v]) => ({ code: `charges_${cat}`, label: EXPENSE_CATEGORIES[cat] ?? cat, value: v.sum, display: formatCents(v.sum), unit: "euros", definition: `Dépenses de catégorie « ${EXPENSE_CATEGORIES[cat] ?? cat} ».`, ...chargesDef, count: v.n }));
  const totalCharges = expenses.reduce((a, x) => a + x.amountHtCents, 0);
  charges.push({ code: "charges_total", label: "Total des charges", value: totalCharges, display: formatCents(totalCharges), unit: "euros", definition: "Somme de toutes les dépenses de l'année.", ...chargesDef, count: expenses.length });

  const stagDef = { denominator: "Inscriptions (statut inscrit, en cours, terminé ou abandon) dont le parcours comporte au moins un jour dans l'année civile.", exclusions: "Préinscriptions, inscriptions annulées ou reportées ; une personne inscrite deux fois compte deux fois (une inscription = un stagiaire par action)." };
  const fc = enrollments.filter((x) => !x.s.isApprenticeship);
  const app = enrollments.filter((x) => x.s.isApprenticeship);
  const sumMin = (list: typeof enrollments) => list.reduce((a, x) => a + (minutes.get(x.e.id) ?? 0), 0);
  const heuresDef = { denominator: "Minutes de présence comptées (lignes courantes) sur les périodes clôturées de l'année, converties en heures.", exclusions: "Périodes non clôturées, présences non saisies, absences, heures prévues ou programmées, heures historiques non réconciliées." };
  const stagiaires: BpfIndicator[] = [
    { code: "stagiaires_fc", label: "Stagiaires en formation continue", value: fc.length, display: String(fc.length), unit: "nombre", definition: "Nombre d'inscriptions à des sessions hors apprentissage.", ...stagDef, count: fc.length },
    { code: "heures_fc", label: "Heures-stagiaires validées (formation continue)", value: sumMin(fc), display: fmtMinutes(sumMin(fc)), unit: "heures", definition: "Somme des heures validées des stagiaires en formation continue.", ...heuresDef, count: fc.length },
    { code: "stagiaires_app", label: "Apprentis (contrats d'apprentissage)", value: app.length, display: String(app.length), unit: "nombre", definition: "Nombre d'inscriptions à des sessions en apprentissage.", ...stagDef, count: app.length },
    { code: "heures_app", label: "Heures-stagiaires validées (apprentissage)", value: sumMin(app), display: fmtMinutes(sumMin(app)), unit: "heures", definition: "Somme des heures validées des apprentis.", ...heuresDef, count: app.length },
  ];

  const bySpec = new Map<string, number>();
  for (const x of enrollments) {
    const k = x.formacode?.trim() || "sans_formacode";
    bySpec.set(k, (bySpec.get(k) ?? 0) + 1);
  }
  const specDef = { denominator: "Mêmes inscriptions que la rubrique « stagiaires », regroupées par le formacode de la formation.", exclusions: "Les formations sans formacode apparaissent dans « Sans formacode » : à compléter dans le catalogue." };
  const specialites: BpfIndicator[] = [...bySpec.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([k, n]) => ({ code: `spec_${k}`, label: k === "sans_formacode" ? "Sans formacode" : `Formacode ${k}`, value: n, display: String(n), unit: "nombre", definition: `Stagiaires inscrits à une formation de spécialité ${k === "sans_formacode" ? "non renseignée" : k}.`, ...specDef, count: n }));

  return {
    year,
    computedAt,
    sections: [
      { code: "produits", title: "Produits par type de financeur", indicators: produits },
      { code: "charges", title: "Charges", indicators: charges },
      { code: "stagiaires", title: "Stagiaires et heures-stagiaires", indicators: stagiaires },
      { code: "specialites", title: "Formations par spécialité (formacode)", indicators: specialites },
    ],
  };
}

/** Liste composant un indicateur (F15 : chaque indicateur ouvre la liste qui le compose). */
export async function bpfDetail(orgId: string, year: number, code: string): Promise<BpfDetailRow[]> {
  const base = `/app/${orgId}`;
  if (code.startsWith("produits_")) {
    const bucket = code.slice("produits_".length);
    const rows = await invoicesOfYear(orgId, year);
    return rows
      .filter(({ i, funderKind }) => bucket === "total" || revenueBucket((i.billTo as { kind?: string })?.kind, funderKind as FunderKind | null, Boolean(i.personId)) === bucket)
      .map(({ i }) => ({ id: i.id, href: `${base}/factures/${i.id}`, label: `${i.number ?? "?"} · ${(i.billTo as { name?: string })?.name ?? ""}`, sub: `${i.kind} · ${i.issueDate}`, value: formatCents((i.kind === "avoir" ? -1 : 1) * i.totalHtCents) }));
  }
  if (code.startsWith("charges_")) {
    const cat = code.slice("charges_".length);
    const rows = await db.select().from(schema.expenses).where(and(eq(schema.expenses.orgId, orgId), sql`extract(year from ${schema.expenses.date}) = ${year}`, cat === "total" ? undefined : eq(schema.expenses.category, cat)));
    return rows.map((x) => ({ id: x.id, href: `${base}/bpf/depenses`, label: x.label, sub: `${EXPENSE_CATEGORIES[x.category] ?? x.category} · ${x.date}${x.supplier ? ` · ${x.supplier}` : ""}`, value: formatCents(x.amountHtCents) }));
  }
  const enrollments = await enrollmentsOfYear(orgId, year);
  const minutes = await validatedMinutes(orgId, year);
  let list = enrollments;
  if (code === "stagiaires_fc" || code === "heures_fc") list = enrollments.filter((x) => !x.s.isApprenticeship);
  else if (code === "stagiaires_app" || code === "heures_app") list = enrollments.filter((x) => x.s.isApprenticeship);
  else if (code.startsWith("spec_")) {
    const k = code.slice("spec_".length);
    list = enrollments.filter((x) => (x.formacode?.trim() || "sans_formacode") === k);
  }
  return list.map((x) => ({
    id: x.e.id,
    href: `${base}/inscriptions/${x.e.id}`,
    label: `${x.e.reference} · ${x.person.firstName} ${x.person.lastName}`,
    sub: `${x.s.code} · ${x.programTitle}${x.s.isApprenticeship ? " · apprentissage" : ""}`,
    value: code.startsWith("heures_") ? fmtMinutes(minutes.get(x.e.id) ?? 0) : x.e.status,
  }));
}
