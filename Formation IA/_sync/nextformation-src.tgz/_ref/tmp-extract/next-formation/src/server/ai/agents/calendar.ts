/**
 * Génération déterministe d'un calendrier de séances (module pur, testé dans ../__tests__/planning-calendar.test.ts).
 * Aucune écriture : la proposition est saisie par un humain après validation.
 */

export type CalendarSlot = { date: string; parts: ("matin" | "apres_midi")[] };
export type CalendarSkipped = { date: string; reason: string };

function minutes(start: string, end: string) {
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  return Math.max(0, eh * 60 + em - (sh * 60 + sm));
}

export type PlanningInput = {
  startDate: string;
  endDate: string;
  targetMinutes: number;
  weekdays: number[];
  parts: { part: "matin" | "apres_midi"; start: string; end: string }[];
  closures: { startDate: string; endDate: string; reason: string }[];
  unavailabilities: { startDate: string; endDate: string; part: string | null; reason: string | null }[];
  holidays: string[];
};

/** Génération déterministe d'un calendrier de séances (pure) : jours ouvrés du rythme, fermetures et indisponibilités exclues, jusqu'à la durée cible. */
export function generateCalendar(input: PlanningInput): { slots: CalendarSlot[]; skipped: CalendarSkipped[]; plannedMinutes: number } {
  const slots: CalendarSlot[] = [];
  const skipped: CalendarSkipped[] = [];
  let planned = 0;
  const perPart = Object.fromEntries(input.parts.map((p) => [p.part, minutes(p.start, p.end)])) as Record<string, number>;
  const cur = new Date(`${input.startDate}T00:00:00Z`);
  const end = new Date(`${input.endDate}T00:00:00Z`);
  let guard = 0;
  while (cur <= end && planned < input.targetMinutes && guard++ < 800) {
    const iso = cur.toISOString().slice(0, 10);
    const wd = cur.getUTCDay() === 0 ? 7 : cur.getUTCDay();
    if (input.weekdays.includes(wd)) {
      if (input.holidays.includes(iso)) skipped.push({ date: iso, reason: "jour férié" });
      else {
        const closure = input.closures.find((c) => c.startDate <= iso && iso <= c.endDate);
        if (closure) skipped.push({ date: iso, reason: `fermeture : ${closure.reason}` });
        else {
          const parts: ("matin" | "apres_midi")[] = [];
          for (const p of input.parts) {
            if (planned >= input.targetMinutes) break;
            const unav = input.unavailabilities.find((u) => u.startDate <= iso && iso <= u.endDate && (!u.part || u.part === p.part || u.part === "journee"));
            if (unav) {
              skipped.push({ date: iso, reason: `formateur indisponible (${p.part})${unav.reason ? ` : ${unav.reason}` : ""}` });
              continue;
            }
            parts.push(p.part);
            planned += perPart[p.part] ?? 0;
          }
          if (parts.length) slots.push({ date: iso, parts });
        }
      }
    }
    cur.setUTCDate(cur.getUTCDate() + 1);
  }
  return { slots, skipped, plannedMinutes: planned };
}

