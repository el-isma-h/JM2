import "server-only";
import { and, desc, eq, ilike, inArray, isNull, ne, or, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { trainerSessionIds, type OrgContext } from "@/server/authz";
import { canSeeDocumentRules, rightsOf, type DocLike } from "./rules";

export type DocumentRow = typeof schema.documents.$inferSelect;
type Category = (typeof schema.documentCategoryEnum.enumValues)[number];
type Visibility = (typeof schema.documentVisibilityEnum.enumValues)[number];
type Status = (typeof schema.documentStatusEnum.enumValues)[number];

export type ListDocumentsInput = {
  orgId: string;
  enrollmentId?: string | null;
  personId?: string | null;
  companyId?: string | null;
  sessionId?: string | null;
  visibility?: Visibility | Visibility[] | null;
  category?: Category | Category[] | null;
  status?: Status | Status[] | null;
  q?: string | null;
  /** Inclure les versions archivées (historique). */
  includeArchived?: boolean;
  /** Inclure les fichiers Word dérivés d'un PDF généré. */
  includeDerived?: boolean;
  limit?: number;
  offset?: number;
};

function listConds(input: ListDocumentsInput): SQL[] {
  const conds: SQL[] = [eq(schema.documents.orgId, input.orgId)];
  if (input.enrollmentId) conds.push(eq(schema.documents.enrollmentId, input.enrollmentId));
  if (input.personId) conds.push(eq(schema.documents.personId, input.personId));
  if (input.companyId) conds.push(eq(schema.documents.companyId, input.companyId));
  if (input.sessionId) conds.push(eq(schema.documents.sessionId, input.sessionId));
  if (input.visibility) conds.push(Array.isArray(input.visibility) ? inArray(schema.documents.visibility, input.visibility) : eq(schema.documents.visibility, input.visibility));
  if (input.category) conds.push(Array.isArray(input.category) ? inArray(schema.documents.category, input.category) : eq(schema.documents.category, input.category));
  if (input.status) conds.push(Array.isArray(input.status) ? inArray(schema.documents.status, input.status) : eq(schema.documents.status, input.status));
  else if (!input.includeArchived) conds.push(ne(schema.documents.status, "archive"));
  if (!input.includeDerived) conds.push(or(isNull(schema.documents.sourceType), ne(schema.documents.sourceType, "docx_of"))!);
  if (input.q) conds.push(or(ilike(schema.documents.title, `%${input.q}%`), ilike(schema.documents.fileName, `%${input.q}%`))!);
  return conds;
}

/**
 * Documents d'un organisme filtrés par rattachement (inscription, personne, entreprise, session) et visibilité.
 * Isolation `orgId` systématique. Les droits de l'utilisateur sont appliqués ensuite avec `canSeeDocument` / `filterVisible`.
 */
export async function listDocumentsFor(input: ListDocumentsInput): Promise<DocumentRow[]> {
  return db
    .select()
    .from(schema.documents)
    .where(and(...listConds(input)))
    .orderBy(desc(schema.documents.createdAt))
    .limit(input.limit ?? 500)
    .offset(input.offset ?? 0);
}

/** Droit de voir un document (règles CDC §8 : pièces admin, pédagogie, CV, RIB central, périmètre formateur). */
export async function canSeeDocument(ctx: OrgContext, doc: DocLike): Promise<boolean> {
  const scope = ctx.trainerOnly ? await trainerSessionIds(ctx) : null;
  return canSeeDocumentRules(rightsOf(ctx), doc, scope);
}

/** Filtre une liste de documents selon les droits du contexte (une seule lecture du périmètre formateur). */
export async function filterVisible<T extends DocLike>(ctx: OrgContext, docs: T[]): Promise<T[]> {
  const scope = ctx.trainerOnly ? await trainerSessionIds(ctx) : null;
  const rights = rightsOf(ctx);
  return docs.filter((d) => canSeeDocumentRules(rights, d, scope));
}

/** Charge un document de l'organisme et vérifie le droit de le voir ; null sinon. */
export async function getVisibleDocument(ctx: OrgContext, documentId: string): Promise<DocumentRow | null> {
  if (!/^[0-9a-f-]{36}$/i.test(documentId)) return null;
  const [doc] = await db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.id, documentId), eq(schema.documents.orgId, ctx.org.id)))
    .limit(1);
  if (!doc) return null;
  return (await canSeeDocument(ctx, doc)) ? doc : null;
}

/** Chaîne des versions d'un document (de la plus récente à la première), via previousVersionId. */
export async function listVersions(orgId: string, doc: DocumentRow): Promise<DocumentRow[]> {
  const chain: DocumentRow[] = [];
  // Versions postérieures (qui pointent vers celle-ci ou ses successeurs).
  let cur: DocumentRow | undefined = doc;
  const seen = new Set<string>();
  while (cur && !seen.has(cur.id)) {
    seen.add(cur.id);
    const [next] = await db
      .select()
      .from(schema.documents)
      .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.previousVersionId, cur.id)))
      .limit(1);
    if (!next) break;
    chain.unshift(next);
    cur = next;
  }
  chain.push(doc);
  let prevId = doc.previousVersionId;
  while (prevId && !seen.has(prevId)) {
    seen.add(prevId);
    const [prev] = await db
      .select()
      .from(schema.documents)
      .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.id, prevId)))
      .limit(1);
    if (!prev) break;
    chain.push(prev);
    prevId = prev.previousVersionId;
  }
  return chain;
}

export const CATEGORY_LABELS: Record<Category, string> = {
  convention: "Convention",
  contrat: "Contrat",
  cerfa: "CERFA",
  convocation: "Convocation",
  annexe_parcours: "Annexe de parcours",
  programme: "Programme",
  reglement_interieur: "Règlement intérieur",
  attestation: "Attestation",
  certificat_realisation: "Certificat de réalisation",
  feuille_emargement: "Feuille d'émargement",
  livret: "Livret",
  releve_heures: "Relevé d'heures",
  evaluation: "Évaluation",
  enquete: "Enquête",
  devis: "Devis",
  facture: "Facture",
  avoir: "Avoir",
  rib: "RIB",
  piece_identite: "Pièce d'identité",
  cv: "CV",
  diplome: "Diplôme",
  justificatif: "Justificatif",
  kbis: "Kbis",
  charte: "Charte",
  plan_acces: "Plan d'accès",
  preuve: "Preuve",
  procedure: "Procédure",
  bpf: "BPF",
  export: "Export",
  autre: "Autre",
};

export const VISIBILITY_LABELS: Record<Visibility, string> = {
  interne: "Interne",
  administratif: "Administratif",
  pedagogie: "Pédagogie",
  apprenant: "Apprenant",
  entreprise: "Entreprise",
  public: "Public",
  confidentiel: "Confidentiel",
};

export const STATUS_LABELS: Record<Status, string> = {
  brouillon: "Brouillon",
  genere: "Généré",
  transmis: "Transmis",
  signe: "Signé",
  valide: "Validé",
  archive: "Archivé",
  invalide: "Invalidé",
};
