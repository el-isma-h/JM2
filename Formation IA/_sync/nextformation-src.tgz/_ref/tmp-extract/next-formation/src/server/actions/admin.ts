"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { and, eq, inArray, ne, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { sha256 } from "@/lib/crypto";
import { appUrl, integrations } from "@/lib/env";
import { slugify } from "@/lib/utils";
import { checkSiren } from "@/lib/validators";
import { issueToken } from "@/server/auth";
import { requirePlatformAdmin } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { layoutMail, sendMail } from "@/server/mail";
import { bootstrapOrgDefaults } from "@/server/org-defaults";
import { proposePrice, calculationNote, checkPrice } from "@/server/pricing/compute";
import { seedPricing } from "@/server/pricing/seed";
import { seedRegistry } from "@/server/registry/seed";
import { backupTenant } from "@/server/backup";
import { purgeTenant } from "@/server/backup/purge";
import { enqueueJob, requeueJob, runDueJobs } from "@/server/jobs/runner";
import { knownJobKinds } from "@/server/jobs/handlers";
import type { ActionState } from "./auth";

const uuid = z.string().uuid();

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

type TenantSettings = { archive?: { archivedAt: string; by: string; disabledUserIds: string[] } } & Record<string, unknown>;

// ---------------------------------------------------------------------------
// Organisations et entreprises
// ---------------------------------------------------------------------------

const tenantSchema = z.object({
  name: z.string().trim().min(2, "Nom de l'organisation requis").max(120),
  kind: z.enum(["organisme", "groupe"]),
  orgKind: z.enum(["of", "cfa", "of_cfa"]).default("of"),
  legalName: z.string().trim().min(2, "Raison sociale de l'organisme requise").max(160),
  ownerEmail: z.string().trim().toLowerCase().email("Adresse e-mail invalide").optional().or(z.literal("")),
});

async function uniqueSlug(base: string) {
  let slug = slugify(base) || "organisation";
  const [clash] = await db.select({ id: schema.tenants.id }).from(schema.tenants).where(eq(schema.tenants.slug, slug)).limit(1);
  if (clash) slug = `${slug}-${randomUUID().slice(0, 4)}`;
  return slug;
}

async function inviteOwner(tenantId: string, orgId: string, orgName: string, email: string, invitedBy: string) {
  const invitationId = randomUUID();
  const token = await issueToken("invite", { email, payload: { invitationId, makeOwner: true }, ttlMinutes: 7 * 24 * 60 });
  await db.insert(schema.invitations).values({ id: invitationId, tenantId, orgId, email, roles: ["direction"], invitedBy, tokenHash: sha256(token), expiresAt: new Date(Date.now() + 7 * 86400_000) });
  const url = `${appUrl()}/invitation/${token}`;
  const res = await sendMail({
    to: email,
    subject: `Votre espace Next Formation : ${orgName}`,
    html: layoutMail("Votre espace Next Formation est prêt", `<p>Un espace a été ouvert pour ${orgName}. Acceptez l'invitation pour en devenir le propriétaire. Ce lien est valable 7 jours.</p>`, { label: "Accepter l'invitation", url }),
    text: `Acceptez l'invitation : ${url}`,
  });
  return { url, status: res.status, invitationId };
}

export async function createTenantAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const d = tenantSchema.parse(Object.fromEntries(formData));
    const slug = await uniqueSlug(d.name);
    const { tenant, org } = await db.transaction(async (tx) => {
      const [tenant] = await tx.insert(schema.tenants).values({ name: d.name, kind: d.kind, slug }).returning();
      const [org] = await tx.insert(schema.organismes).values({ tenantId: tenant.id, legalName: d.legalName, kind: d.orgKind }).returning();
      await bootstrapOrgDefaults(tx, org.id);
      return { tenant, org };
    });
    let link: string | undefined;
    let mail = "none";
    if (d.ownerEmail) {
      const inv = await inviteOwner(tenant.id, org.id, org.legalName, d.ownerEmail, admin.id);
      mail = inv.status;
      if (inv.status !== "sent") link = inv.url;
    }
    await audit({ action: "admin.tenant.create", userId: admin.id, tenantId: tenant.id, orgId: org.id, entityType: "tenant", entityId: tenant.id, after: { name: d.name, kind: d.kind, ownerEmail: d.ownerEmail || null, mail } });
    revalidatePath("/admin/organisations");
    return {
      ok: true,
      message: link ? "Organisation créée. L'e-mail d'invitation n'est pas parti (service non configuré) : transmettez ce lien au propriétaire." : "Organisation créée.",
      data: { tenantId: tenant.id, ...(link ? { link } : {}) },
    };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function createOrgAdminAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const tenantId = uuid.parse(formData.get("tenantId"));
    const legalName = z.string().trim().min(2, "Raison sociale requise").max(160).parse(formData.get("legalName"));
    const tradeName = String(formData.get("tradeName") ?? "").trim() || null;
    const rawSiren = String(formData.get("siren") ?? "").trim();
    let siren: string | null = null;
    if (rawSiren) {
      const s = checkSiren(rawSiren);
      if (!s.ok) return { error: s.error };
      siren = s.value;
    }
    const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, tenantId)).limit(1);
    if (!tenant) return { error: "Organisation introuvable." };
    const org = await db.transaction(async (tx) => {
      const [c] = await tx.insert(schema.organismes).values({ tenantId, legalName, tradeName, siren, isDemo: tenant.isDemo }).returning();
      await bootstrapOrgDefaults(tx, c.id);
      return c;
    });
    await audit({ action: "admin.org.create", userId: admin.id, tenantId, orgId: org.id, entityType: "organisme", entityId: org.id, after: { legalName, siren } });
    revalidatePath(`/admin/organisations/${tenantId}`);
    return { ok: true, message: `Organisme « ${legalName} » ajouté.` };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

/** Archivage (désactivation réversible) : comptes du tenant désactivés, sessions fermées. Confirmation : identifiant du tenant (slug). */
export async function archiveTenantAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const tenantId = uuid.parse(formData.get("tenantId"));
    const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, tenantId)).limit(1);
    if (!tenant) return { error: "Organisation introuvable." };
    if (String(formData.get("confirm") ?? "").trim() !== tenant.slug) return { error: `Saisissez exactement « ${tenant.slug} » pour confirmer.` };
    const settings = (tenant.settings ?? {}) as TenantSettings;
    if (settings.archive) return { error: "Organisation déjà archivée." };
    const users = await db
      .select({ id: schema.users.id })
      .from(schema.users)
      .where(and(eq(schema.users.tenantId, tenantId), ne(schema.users.platformRole, "platform_admin"), sql`${schema.users.disabledAt} is null`));
    const ids = users.map((u) => u.id);
    await db.transaction(async (tx) => {
      if (ids.length) {
        await tx.update(schema.users).set({ disabledAt: new Date() }).where(inArray(schema.users.id, ids));
        await tx.delete(schema.sessions).where(inArray(schema.sessions.userId, ids));
      }
      await tx
        .update(schema.tenants)
        .set({ settings: { ...settings, archive: { archivedAt: new Date().toISOString(), by: admin.id, disabledUserIds: ids } } })
        .where(eq(schema.tenants.id, tenantId));
    });
    await audit({ action: "admin.tenant.archive", userId: admin.id, tenantId, entityType: "tenant", entityId: tenantId, after: { disabledUsers: ids.length } });
    revalidatePath("/admin/organisations");
    revalidatePath(`/admin/organisations/${tenantId}`);
    return { ok: true, message: `Organisation archivée : ${ids.length} compte(s) désactivé(s).` };
  } catch (e) {
    return fail(e, "Archivage impossible.");
  }
}

export async function unarchiveTenantAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const tenantId = uuid.parse(formData.get("tenantId"));
    const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, tenantId)).limit(1);
    if (!tenant) return { error: "Organisation introuvable." };
    const settings = (tenant.settings ?? {}) as TenantSettings;
    if (!settings.archive) return { error: "Organisation non archivée." };
    const ids = settings.archive.disabledUserIds ?? [];
    const rest = { ...settings };
    delete rest.archive;
    await db.transaction(async (tx) => {
      if (ids.length) await tx.update(schema.users).set({ disabledAt: null }).where(inArray(schema.users.id, ids));
      await tx.update(schema.tenants).set({ settings: rest }).where(eq(schema.tenants.id, tenantId));
    });
    await audit({ action: "admin.tenant.unarchive", userId: admin.id, tenantId, entityType: "tenant", entityId: tenantId, after: { reenabledUsers: ids.length } });
    revalidatePath("/admin/organisations");
    revalidatePath(`/admin/organisations/${tenantId}`);
    return { ok: true, message: `Organisation réactivée : ${ids.length} compte(s) réactivé(s).` };
  } catch (e) {
    return fail(e, "Réactivation impossible.");
  }
}

/**
 * Suppression définitive : uniquement pour une organisation archivée ou de démonstration.
 * Une sauvegarde est créée juste avant (sauf démonstration). Confirmation : slug + case cochée.
 */
export async function deleteTenantAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const tenantId = uuid.parse(formData.get("tenantId"));
    const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, tenantId)).limit(1);
    if (!tenant) return { error: "Organisation introuvable." };
    const settings = (tenant.settings ?? {}) as TenantSettings;
    if (!tenant.isDemo && !settings.archive) return { error: "Archivez d'abord l'organisation : la suppression n'est possible que pour une organisation archivée." };
    if (String(formData.get("confirm") ?? "").trim() !== tenant.slug) return { error: `Saisissez exactement « ${tenant.slug} » pour confirmer.` };
    if (formData.get("understood") !== "on") return { error: "Cochez la case de confirmation." };
    if (admin.tenantId === tenantId) return { error: "Vous ne pouvez pas supprimer votre propre organisation." };
    let backupNote = "";
    if (!tenant.isDemo) {
      const b = await backupTenant(tenantId, admin.id);
      // La ligne `backups` est supprimée avec le tenant (cascade) : on conserve sa trace dans l'audit et le fichier reste sur le stockage.
      backupNote = ` Sauvegarde préalable : ${b.storageKey} (sha256 ${b.sha256.slice(0, 12)}…).`;
      await audit({ action: "admin.backup.create", userId: admin.id, tenantId, entityType: "backup", entityId: b.backupId, after: { reason: "avant suppression", storageKey: b.storageKey, sha256: b.sha256 } });
      await db.update(schema.backups).set({ tenantId: null }).where(eq(schema.backups.id, b.backupId));
    }
    const r = await purgeTenant(tenantId);
    await audit({ action: "admin.tenant.delete", userId: admin.id, tenantId, entityType: "tenant", entityId: tenantId, before: { name: tenant.name, slug: tenant.slug, isDemo: tenant.isDemo }, after: r });
    revalidatePath("/admin/organisations");
    return { ok: true, message: `Organisation supprimée (${r.orgs} organisme(s), ${r.users} compte(s), ${r.files} fichier(s)).${backupNote}` };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

// ---------------------------------------------------------------------------
// Utilisateurs
// ---------------------------------------------------------------------------

async function targetUser(formData: FormData) {
  const userId = uuid.parse(formData.get("userId"));
  const [u] = await db.select().from(schema.users).where(eq(schema.users.id, userId)).limit(1);
  if (!u) throw new Error("Utilisateur introuvable.");
  return u;
}

export async function setUserDisabledAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const u = await targetUser(formData);
    const disable = formData.get("disable") === "1";
    if (u.id === admin.id && disable) return { error: "Vous ne pouvez pas désactiver votre propre compte." };
    await db.update(schema.users).set({ disabledAt: disable ? new Date() : null }).where(eq(schema.users.id, u.id));
    if (disable) await db.delete(schema.sessions).where(eq(schema.sessions.userId, u.id));
    await audit({ action: disable ? "admin.user.disable" : "admin.user.enable", userId: admin.id, entityType: "user", entityId: u.id, before: { disabledAt: u.disabledAt }, after: { email: u.email } });
    revalidatePath(`/admin/utilisateurs/${u.id}`);
    revalidatePath("/admin/utilisateurs");
    return { ok: true, message: disable ? "Compte désactivé, sessions fermées." : "Compte réactivé." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

export async function forceVerifyEmailAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const u = await targetUser(formData);
    if (u.emailVerifiedAt) return { ok: true, message: "Adresse déjà vérifiée." };
    await db.update(schema.users).set({ emailVerifiedAt: new Date() }).where(eq(schema.users.id, u.id));
    await audit({ action: "admin.user.force_verify", userId: admin.id, entityType: "user", entityId: u.id, after: { email: u.email } });
    revalidatePath(`/admin/utilisateurs/${u.id}`);
    return { ok: true, message: "Adresse marquée comme vérifiée." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

export async function sendPasswordResetAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const u = await targetUser(formData);
    const token = await issueToken("reset_password", { userId: u.id, email: u.email, ttlMinutes: 30 });
    const url = `${appUrl()}/reinitialiser?token=${token}`;
    const res = await sendMail({
      to: u.email,
      subject: "Réinitialisation de votre mot de passe",
      html: layoutMail("Réinitialiser votre mot de passe", `<p>Un administrateur Next Formation a demandé la réinitialisation de votre mot de passe. Ce lien est valable 30 minutes.</p>`, { label: "Choisir un nouveau mot de passe", url }),
      text: `Réinitialisez votre mot de passe (valable 30 minutes) : ${url}`,
      isDemo: u.email.endsWith("@demo.nextformation.invalid"),
    });
    await audit({ action: "admin.user.reset_sent", userId: admin.id, entityType: "user", entityId: u.id, after: { mail: res.status } });
    return res.status === "sent"
      ? { ok: true, message: `E-mail de réinitialisation envoyé à ${u.email}.` }
      : { ok: true, message: "Service e-mail non configuré : l'e-mail est dans la boîte d'envoi. Lien valable 30 minutes, à transmettre à l'utilisateur :", data: { link: url } };
  } catch (e) {
    return fail(e, "Envoi impossible.");
  }
}

export async function revokeSessionsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const u = await targetUser(formData);
    const res = await db.delete(schema.sessions).where(eq(schema.sessions.userId, u.id)).returning({ id: schema.sessions.id });
    await audit({ action: "admin.user.sessions_revoke", userId: admin.id, entityType: "user", entityId: u.id, after: { count: res.length } });
    revalidatePath(`/admin/utilisateurs/${u.id}`);
    return { ok: true, message: `${res.length} session(s) fermée(s).` };
  } catch (e) {
    return fail(e, "Opération impossible.");
  }
}

/** Promotion / rétrogradation admin plateforme. Confirmation : saisie de l'adresse e-mail du compte. */
export async function setPlatformRoleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const u = await targetUser(formData);
    const role = z.enum(["user", "platform_admin"]).parse(formData.get("role"));
    if (String(formData.get("confirm") ?? "").trim().toLowerCase() !== u.email) return { error: "Saisissez l'adresse e-mail du compte pour confirmer." };
    if (u.platformRole === role) return { ok: true, message: "Aucun changement." };
    if (role === "user") {
      if (u.id === admin.id) return { error: "Vous ne pouvez pas retirer vos propres droits d'administration." };
      const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.users).where(and(eq(schema.users.platformRole, "platform_admin"), sql`${schema.users.disabledAt} is null`));
      if (n <= 1) return { error: "Il doit rester au moins un administrateur plateforme actif." };
    }
    if (role === "platform_admin" && (!u.emailVerifiedAt || u.disabledAt)) return { error: "Le compte doit être actif et avoir une adresse vérifiée." };
    await db.update(schema.users).set({ platformRole: role }).where(eq(schema.users.id, u.id));
    // Les sessions existantes de l'utilisateur sont fermées pour que le changement de droits prenne effet partout.
    if (u.id !== admin.id) await db.delete(schema.sessions).where(eq(schema.sessions.userId, u.id));
    await audit({ action: role === "platform_admin" ? "admin.user.promote" : "admin.user.demote", userId: admin.id, entityType: "user", entityId: u.id, before: { platformRole: u.platformRole }, after: { platformRole: role } });
    revalidatePath(`/admin/utilisateurs/${u.id}`);
    revalidatePath("/admin/utilisateurs");
    return { ok: true, message: role === "platform_admin" ? "Compte promu administrateur plateforme." : "Droits d'administration retirés." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

// ---------------------------------------------------------------------------
// Tarifs
// ---------------------------------------------------------------------------

const UNITS = schema.pricingUnitEnum.enumValues;

/** « 2,79 » ou « 2.79 » → 279 centimes (sans passer par un flottant). */
function eurosToCents(raw: FormDataEntryValue | null): number | null {
  const s = String(raw ?? "").replace(/[\s€]/g, "").replace(",", ".");
  if (!s) return null;
  const m = /^(\d+)(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new z.ZodError([{ code: "custom", message: `Montant invalide : « ${String(raw)} » (format 2,79).`, path: [], input: raw }]);
  return Number(m[1]) * 100 + Number((m[2] ?? "").padEnd(2, "0"));
}

const planSchema = z.object({
  id: z.string().uuid().optional().or(z.literal("")),
  code: z.string().trim().min(2).max(60).regex(/^[a-z0-9_]+$/, "Code : minuscules, chiffres et _ uniquement"),
  name: z.string().trim().min(2, "Nom requis").max(120),
  description: z.string().trim().max(500).optional(),
  unit: z.enum(UNITS),
  referenceLabel: z.string().trim().max(200).optional(),
  referenceUrl: z.string().trim().url("Adresse de la source invalide").optional().or(z.literal("")),
  referenceCheckedAt: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date de consultation invalide").optional().or(z.literal("")),
  discountPercent: z.string().trim().regex(/^\d{1,3}([.,]\d{1,2})?$/, "Remise invalide").default("10"),
  calculationNote: z.string().trim().max(500).optional(),
  sortOrder: z.coerce.number().int().min(0).max(10000).default(0),
});

export async function savePricingPlanAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const d = planSchema.parse(Object.fromEntries(formData));
    const discountRate = Math.round(Number(d.discountPercent.replace(",", ".")) * 100);
    if (discountRate > 10000) return { error: "La remise ne peut pas dépasser 100 %." };
    const referencePriceCents = eurosToCents(formData.get("reference"));
    let priceCents = eurosToCents(formData.get("price"));
    if (d.unit === "sur_devis") priceCents = null;
    else if (d.unit === "inclus") priceCents = 0;
    else if (priceCents === null) priceCents = proposePrice(referencePriceCents, discountRate);
    if (d.unit !== "sur_devis" && d.unit !== "inclus" && priceCents === null) return { error: "Indiquez un prix Next Formation ou un prix de référence pour le calculer." };
    const values = {
      code: d.code,
      name: d.name,
      description: d.description || null,
      isService: formData.get("isService") === "on",
      unit: d.unit,
      priceCents,
      referencePriceCents,
      referenceLabel: d.referenceLabel || null,
      referenceUrl: d.referenceUrl || null,
      referenceCheckedAt: d.referenceCheckedAt || null,
      discountRate,
      calculationNote: d.calculationNote || calculationNote(referencePriceCents, discountRate),
      isActive: formData.get("isActive") === "on",
      sortOrder: d.sortOrder,
    };
    const check = checkPrice({ priceCents, referencePriceCents, discountRate, unit: d.unit });
    let id = d.id || null;
    if (id) {
      const [before] = await db.select().from(schema.pricingPlans).where(eq(schema.pricingPlans.id, id)).limit(1);
      if (!before) return { error: "Ligne introuvable." };
      await db.update(schema.pricingPlans).set(values).where(eq(schema.pricingPlans.id, id));
      await audit({ action: "admin.pricing.update", userId: admin.id, entityType: "pricing_plan", entityId: id, before, after: values });
    } else {
      const [dup] = await db.select({ id: schema.pricingPlans.id }).from(schema.pricingPlans).where(eq(schema.pricingPlans.code, d.code)).limit(1);
      if (dup) return { error: "Ce code existe déjà." };
      const [row] = await db.insert(schema.pricingPlans).values(values).returning({ id: schema.pricingPlans.id });
      id = row.id;
      await audit({ action: "admin.pricing.create", userId: admin.id, entityType: "pricing_plan", entityId: id, after: values });
    }
    revalidatePath("/admin/tarifs");
    revalidatePath("/");
    return check.level === "danger" ? { ok: true, message: `Enregistré, mais à corriger : ${check.message}` } : { ok: true, message: "Tarif enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function togglePricingActiveAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const [p] = await db.select().from(schema.pricingPlans).where(eq(schema.pricingPlans.id, id)).limit(1);
    if (!p) return { error: "Ligne introuvable." };
    await db.update(schema.pricingPlans).set({ isActive: !p.isActive }).where(eq(schema.pricingPlans.id, id));
    await audit({ action: "admin.pricing.toggle", userId: admin.id, entityType: "pricing_plan", entityId: id, before: { isActive: p.isActive }, after: { isActive: !p.isActive } });
    revalidatePath("/admin/tarifs");
    revalidatePath("/");
    return { ok: true, message: p.isActive ? "Ligne masquée de la page publique." : "Ligne publiée." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

export async function deletePricingPlanAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const [p] = await db.select().from(schema.pricingPlans).where(eq(schema.pricingPlans.id, id)).limit(1);
    if (!p) return { error: "Ligne introuvable." };
    if (String(formData.get("confirm") ?? "").trim() !== p.code) return { error: `Saisissez « ${p.code} » pour confirmer.` };
    await db.delete(schema.pricingPlans).where(eq(schema.pricingPlans.id, id));
    await audit({ action: "admin.pricing.delete", userId: admin.id, entityType: "pricing_plan", entityId: id, before: p });
    revalidatePath("/admin/tarifs");
    revalidatePath("/");
    return { ok: true, message: "Ligne supprimée." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

export async function reseedPricingAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const overwrite = formData.get("overwrite") === "1";
    if (overwrite && String(formData.get("confirm") ?? "").trim().toUpperCase() !== "REALIGNER") return { error: "Saisissez REALIGNER pour confirmer." };
    const r = await seedPricing({ overwrite });
    await audit({ action: overwrite ? "admin.pricing.realign" : "admin.pricing.seed", userId: admin.id, entityType: "pricing_plan", after: r });
    revalidatePath("/admin/tarifs");
    revalidatePath("/");
    return { ok: true, message: `Grille sourcée : ${r.inserted} ligne(s) ajoutée(s), ${r.updated} réalignée(s), ${r.total} au total.` };
  } catch (e) {
    return fail(e, "Chargement impossible.");
  }
}

// ---------------------------------------------------------------------------
// Boîte d'envoi
// ---------------------------------------------------------------------------

export async function resendMailAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    if (!integrations.mail()) return { error: "Service e-mail désactivé (RESEND_API_KEY ou MAIL_ENABLED=true dans Admin › Clés API) : copiez le lien contenu dans l'e-mail." };
    const [m] = await db.select().from(schema.mailOutbox).where(eq(schema.mailOutbox.id, id)).limit(1);
    if (!m) return { error: "E-mail introuvable." };
    if (m.isDemo) return { error: "Démonstration : aucun envoi réel." };
    const res = await sendMail({ to: m.to, subject: m.subject, html: m.html, text: m.text ?? undefined });
    await audit({ action: "admin.mail.resend", userId: admin.id, entityType: "mail", entityId: id, after: { newId: res.id, status: res.status } });
    revalidatePath("/admin/boite-envoi");
    return res.status === "sent" ? { ok: true, message: "E-mail renvoyé." } : { error: "Le renvoi a échoué : voir le détail du nouvel envoi." };
  } catch (e) {
    return fail(e, "Renvoi impossible.");
  }
}

// ---------------------------------------------------------------------------
// Tâches
// ---------------------------------------------------------------------------

export async function retryJobAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const row = await requeueJob(id);
    if (!row) return { error: "Tâche introuvable ou en cours d'exécution." };
    await audit({ action: "admin.job.retry", userId: admin.id, entityType: "job", entityId: id, after: { kind: row.kind } });
    revalidatePath("/admin/taches");
    return { ok: true, message: "Tâche remise en file." };
  } catch (e) {
    return fail(e, "Relance impossible.");
  }
}

export async function runJobsNowAction(): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const r = await runDueJobs({ limit: 20 });
    await audit({ action: "admin.job.run", userId: admin.id, entityType: "job", after: { claimed: r.claimed, done: r.done, failed: r.failed, retried: r.retried } });
    revalidatePath("/admin/taches");
    return { ok: true, message: `${r.claimed} tâche(s) exécutée(s) : ${r.done} terminée(s), ${r.retried} replanifiée(s), ${r.failed} en échec.` };
  } catch (e) {
    return fail(e, "Exécution impossible.");
  }
}

export async function enqueueJobAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const kind = String(formData.get("kind") ?? "");
    if (!knownJobKinds().includes(kind)) return { error: "Type de tâche inconnu." };
    const tenantId = String(formData.get("tenantId") ?? "") || null;
    if (kind === "backup:tenant" && !tenantId) return { error: "Choisissez l'organisation à sauvegarder." };
    const job = await enqueueJob({ kind, tenantId, payload: tenantId ? { tenantId, userId: admin.id } : {} });
    await audit({ action: "admin.job.enqueue", userId: admin.id, tenantId, entityType: "job", entityId: job.id, after: { kind } });
    revalidatePath("/admin/taches");
    return { ok: true, message: "Tâche ajoutée à la file : elle s'exécutera au prochain passage du runner." };
  } catch (e) {
    return fail(e, "Ajout impossible.");
  }
}

// ---------------------------------------------------------------------------
// Registre des traitements
// ---------------------------------------------------------------------------

const registrySchema = z.object({
  id: z.string().uuid().optional().or(z.literal("")),
  name: z.string().trim().min(2, "Nom du traitement requis").max(160),
  purpose: z.string().trim().min(5, "Finalité requise").max(1000),
  categories: z.string().trim().min(1, "Au moins une catégorie de données"),
  processor: z.string().trim().max(300).optional(),
  location: z.string().trim().max(300).optional(),
  retention: z.string().trim().min(2, "Durée de conservation requise").max(1000),
  legalBasis: z.string().trim().min(2, "Base légale requise").max(500),
});

/** Catégories saisies une par ligne : « Catégorie | durée | texte de référence ». */
function parseCategories(raw: string) {
  return raw
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => {
      const [name, retention, basis] = l.split("|").map((x) => x.trim());
      return { name, retention: retention ?? "", basis: basis ?? "" };
    });
}

export async function saveRegistryAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const d = registrySchema.parse(Object.fromEntries(formData));
    const values = { name: d.name, purpose: d.purpose, dataCategories: parseCategories(d.categories), processor: d.processor || null, location: d.location || null, retention: d.retention, legalBasis: d.legalBasis };
    if (d.id) {
      const [before] = await db.select().from(schema.processingRegistry).where(eq(schema.processingRegistry.id, d.id)).limit(1);
      if (!before) return { error: "Traitement introuvable." };
      await db.update(schema.processingRegistry).set(values).where(eq(schema.processingRegistry.id, d.id));
      await audit({ action: "admin.registry.update", userId: admin.id, entityType: "processing_registry", entityId: d.id, before, after: values });
    } else {
      const [row] = await db.insert(schema.processingRegistry).values(values).returning({ id: schema.processingRegistry.id });
      await audit({ action: "admin.registry.create", userId: admin.id, entityType: "processing_registry", entityId: row.id, after: values });
    }
    revalidatePath("/admin/registre");
    return { ok: true, message: "Traitement enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deleteRegistryAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const id = uuid.parse(formData.get("id"));
    const [row] = await db.select().from(schema.processingRegistry).where(eq(schema.processingRegistry.id, id)).limit(1);
    if (!row) return { error: "Traitement introuvable." };
    if (String(formData.get("confirm") ?? "").trim().toUpperCase() !== "SUPPRIMER") return { error: "Saisissez SUPPRIMER pour confirmer." };
    await db.delete(schema.processingRegistry).where(eq(schema.processingRegistry.id, id));
    await audit({ action: "admin.registry.delete", userId: admin.id, entityType: "processing_registry", entityId: id, before: row });
    revalidatePath("/admin/registre");
    return { ok: true, message: "Traitement supprimé du registre." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

export async function reseedRegistryAction(): Promise<ActionState> {
  try {
    const admin = await requirePlatformAdmin();
    const r = await seedRegistry();
    await audit({ action: "admin.registry.seed", userId: admin.id, entityType: "processing_registry", after: r });
    revalidatePath("/admin/registre");
    return { ok: true, message: `${r.inserted} traitement(s) ajouté(s) sur ${r.total} (les traitements existants sont conservés).` };
  } catch (e) {
    return fail(e, "Chargement impossible.");
  }
}
