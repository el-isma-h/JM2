/** Substitut de `server-only` pour vitest : les modules serveur deviennent importables dans les tests. */
export {};
