import type { RelativeDelay } from "./calendar";

/**
 * Parcours automatiques de financement (« workflow templates »).
 *
 * Chaque parcours est une liste ordonnée d'étapes. Appliqué à une inscription, il crée une tâche de relais
 * par étape (clé `wf:<enrollmentId>:<stepCode>`), avec responsable (rôle), échéance relative, prérequis et
 * lien vers la page concernée. Les étapes suivent les procédures internes de l'organisme :
 * - `process_suivi_formation` : PROCESS SUIVI FORMATION (CPF / EDOF, entretiens, e-learning, certifications) ;
 * - `process_inrae` : PROCESS INRAE, formation avec bon de commande (Chorus Pro) ;
 * - `saisie_devis_kairos` : SAISIE DE DEVIS KAIROS (AIF France Travail) ;
 * - `reglementaire` : étape réglementaire évidente non décrite dans les procédures (à valider par l'organisme).
 *
 * Les délais non précisés par les procédures sont des valeurs par défaut à valider par l'organisme ;
 * ils ne créent aucune obligation et chaque étape reste marquée « faite » par un humain.
 */

export const WORKFLOW_CODES = ["cpf", "aif", "public", "entreprise", "cfa"] as const;
export type WorkflowCode = (typeof WORKFLOW_CODES)[number];

export type WorkflowRole = "direction" | "agency_manager" | "pedagogy_manager" | "trainer" | "admin_staff" | "finance" | "quality" | "sales";
export type WorkflowFamily = "commercial" | "administratif" | "pedagogie" | "finance" | "qualite" | "examen" | "direction";

/** Page de l'application concernée par l'étape. */
export type WorkflowPage =
  | "dossier"
  | "pieces"
  | "parcours"
  | "documents"
  | "financements"
  | "examens"
  | "journal"
  | "session"
  | "devis"
  | "factures"
  | "enquetes"
  | "elearning"
  | "emargement"
  | "suivi_entreprise"
  | "signatures";

export type WorkflowSource = "process_suivi_formation" | "process_inrae" | "saisie_devis_kairos" | "reglementaire";

/** Condition d'application : l'étape n'est créée que si l'inscription la concerne. */
export type StepCondition = "certification" | "opco";

/** Effet sur l'inscription quand l'étape est marquée faite. */
export type StepEffect = {
  edofStatus?: string;
  /** Date d'entrée EDOF = date du jour (Paris). */
  edofEntry?: boolean;
  /** Date de sortie EDOF = date du jour (Paris). */
  edofExit?: boolean;
  kairosStatus?: string;
  /** Horodatage de l'envoi des accès e-learning. */
  elearningAccessSent?: boolean;
};

export type WorkflowStep = {
  code: string;
  label: string;
  description?: string;
  role: WorkflowRole;
  family: WorkflowFamily;
  delay: RelativeDelay;
  /** Codes des étapes à terminer avant celle-ci (dans le même parcours). */
  prerequisites: string[];
  page: WorkflowPage;
  when?: StepCondition;
  effect?: StepEffect;
  /** Preuve qualité enregistrée quand l'étape est faite (action réelle déclarée par un humain). */
  evidence?: { indicatorCode: string; title: string };
  source: WorkflowSource;
};

export type WorkflowTemplate = {
  code: WorkflowCode;
  label: string;
  description: string;
  steps: WorkflowStep[];
};

/* ---------- Étapes communes (même code d'un parcours à l'autre : une étape faite le reste après changement de parcours) ---------- */

const entretienAccueil = (prerequisites: string[], delay: RelativeDelay = { anchor: "precedente", offset: 2, unit: "ouvres" }): WorkflowStep => ({
  code: "entretien_accueil",
  label: "Entretien d'accueil",
  description:
    "Par téléphone de préférence, envoi par e-mail si le stagiaire est indisponible ; relancer si le formulaire n'est pas revenu. Renseigner tous les champs : plus on a d'informations, plus on peut individualiser la formation.",
  role: "admin_staff",
  family: "pedagogie",
  delay,
  prerequisites,
  page: "parcours",
  evidence: { indicatorCode: "IND_4", title: "Entretien d'accueil réalisé (analyse du besoin)" },
  source: "process_suivi_formation",
});

const testPositionnement = (prerequisites: string[]): WorkflowStep => ({
  code: "test_positionnement",
  label: "Test de positionnement envoyé et niveau de départ renseigné",
  description: "ICDL et TOSA : envoi via la plateforme ; Voltaire et Busuu : test sur la plateforme ; anglais : test en ligne. Reporter le niveau de départ dans le dossier.",
  role: "admin_staff",
  family: "pedagogie",
  delay: { anchor: "debut", offset: -3, unit: "ouvres" },
  prerequisites,
  page: "parcours",
  evidence: { indicatorCode: "IND_8", title: "Positionnement à l'entrée réalisé" },
  source: "process_suivi_formation",
});

const mobilisationFormateur: WorkflowStep[] = [
  {
    code: "formateur_proposition",
    label: "Proposition de mission envoyée au formateur",
    description: "Mail type « Proposition de mission » : nom du stagiaire, thème, dates, durée (heures en visio uniquement), entretien d'accueil joint.",
    role: "admin_staff",
    family: "administratif",
    delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
    prerequisites: ["entretien_accueil"],
    page: "session",
    source: "process_suivi_formation",
  },
  {
    code: "formateur_acceptation",
    label: "Acceptation de la mission par le formateur vérifiée",
    description: "Au plus tard 5 jours ouvrés après la proposition. Sans réponse : mobiliser un autre formateur et en informer le premier.",
    role: "admin_staff",
    family: "administratif",
    delay: { anchor: "precedente", offset: 5, unit: "ouvres" },
    prerequisites: ["formateur_proposition"],
    page: "session",
    source: "process_suivi_formation",
  },
  {
    code: "formateur_planning",
    label: "Date du premier cours et planning prévisionnel reçus du formateur",
    role: "admin_staff",
    family: "administratif",
    delay: { anchor: "precedente", offset: 2 },
    prerequisites: ["formateur_acceptation"],
    page: "session",
    source: "process_suivi_formation",
  },
  {
    code: "formateur_contrat",
    label: "Contrat de prestation envoyé au formateur",
    description: "Vérifier dates, durée en visio et rémunération globale (taux horaire de la fiche intervenant) avant l'envoi.",
    role: "admin_staff",
    family: "administratif",
    delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
    prerequisites: ["formateur_acceptation"],
    page: "session",
    source: "process_suivi_formation",
  },
];

const entretienMiParcours: WorkflowStep = {
  code: "entretien_mi_parcours",
  label: "Entretien de suivi mi-parcours",
  description: "Même procédure que l'entretien d'accueil : téléphone de préférence, sinon e-mail, relance si besoin.",
  role: "admin_staff",
  family: "pedagogie",
  delay: { anchor: "milieu", offset: 0 },
  prerequisites: [],
  page: "parcours",
  evidence: { indicatorCode: "IND_10", title: "Entretien de suivi mi-parcours réalisé" },
  source: "process_suivi_formation",
};

const verifFin: WorkflowStep = {
  code: "verification_fin",
  label: "Date du dernier cours vérifiée",
  description: "Une semaine avant la fin officielle : vérifier le planning prévisionnel ou appeler le formateur.",
  role: "admin_staff",
  family: "pedagogie",
  delay: { anchor: "fin", offset: -7 },
  prerequisites: [],
  page: "session",
  source: "process_suivi_formation",
};

const evaluationPost: WorkflowStep = {
  code: "evaluation_post_formation",
  label: "Évaluation post formation 1 envoyée",
  description: "Avant le dernier cours prévu : mail type avec le lien du questionnaire, le lien Google et la marche à suivre pour le questionnaire CPF le cas échéant.",
  role: "admin_staff",
  family: "qualite",
  delay: { anchor: "fin", offset: -2, unit: "ouvres" },
  prerequisites: [],
  page: "enquetes",
  source: "process_suivi_formation",
};

const entretienBilan = (prerequisites: string[]): WorkflowStep => ({
  code: "entretien_bilan",
  label: "Entretien bilan",
  description: "Une fois le dernier cours effectué, même procédure que les entretiens d'accueil et mi-parcours. Informer le stagiaire de l'envoi du questionnaire d'évaluation.",
  role: "admin_staff",
  family: "pedagogie",
  delay: { anchor: "fin", offset: 1, unit: "ouvres" },
  prerequisites,
  page: "parcours",
  evidence: { indicatorCode: "IND_11", title: "Entretien bilan de fin de formation réalisé" },
  source: "process_suivi_formation",
});

const bilanPedagogique: WorkflowStep = {
  code: "bilan_pedagogique",
  label: "Bilan pédagogique demandé au formateur et reçu",
  role: "admin_staff",
  family: "pedagogie",
  delay: { anchor: "fin", offset: 1, unit: "ouvres" },
  prerequisites: [],
  page: "parcours",
  source: "process_suivi_formation",
};

const attestationFin = (prerequisites: string[]): WorkflowStep => ({
  code: "attestation_fin",
  label: "Attestation de fin de formation éditée et envoyée",
  description: "Compléter « résultats de l'évaluation des acquis » avec le bilan pédagogique du formateur et le résultat de la certification si elle est déjà passée.",
  role: "admin_staff",
  family: "administratif",
  delay: { anchor: "precedente", offset: 2, unit: "ouvres" },
  prerequisites,
  page: "documents",
  source: "process_suivi_formation",
});

const enqueteFroid = (prerequisites: string[]): WorkflowStep => ({
  code: "enquete_froid",
  label: "Enquête à froid envoyée",
  description: "Délai par défaut de 3 mois après la fin, à ajuster selon la politique qualité de l'organisme.",
  role: "quality",
  family: "qualite",
  delay: { anchor: "fin", offset: 90 },
  prerequisites,
  page: "enquetes",
  source: "reglementaire",
});

const inscriptionCertification = (delay: RelativeDelay): WorkflowStep => ({
  code: "certification_inscription",
  label: "Inscription à la certification",
  description:
    "ICDL : convertir le compte éval en compte ICDL puis affecter le module. TOSA : inscrire à un test « Certification ». TOEIC : voucher (CPF : 12 months 4 skills). Voltaire : en centre, à commander au moins 15 jours avant. CléA si la formation le prévoit.",
  role: "pedagogy_manager",
  family: "examen",
  delay,
  prerequisites: [],
  page: "examens",
  when: "certification",
  source: "process_suivi_formation",
});

const passageCertification: WorkflowStep = {
  code: "certification_passage",
  label: "Passage de la certification vérifié",
  description: "Vérifier régulièrement le passage (TOEIC : voucher « inutilisé » = relancer le candidat) et reporter le résultat.",
  role: "pedagogy_manager",
  family: "examen",
  delay: { anchor: "fin", offset: 5, unit: "ouvres" },
  prerequisites: ["certification_inscription"],
  page: "examens",
  when: "certification",
  source: "process_suivi_formation",
};

/* ---------- CPF / EDOF ---------- */

const cpf: WorkflowTemplate = {
  code: "cpf",
  label: "CPF (Mon Compte Formation, EDOF)",
  description: "Suivi d'un dossier CPF de la commande EDOF jusqu'à la facturation, l'enquête à froid et l'avis Google.",
  steps: [
    {
      code: "edof_validation",
      label: "Commande validée sur EDOF",
      description: "Accepter la demande d'inscription du titulaire sur EDOF et reporter le numéro de dossier CPF dans le financement.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "inscription", offset: 2, unit: "ouvres" },
      prerequisites: [],
      page: "financements",
      effect: { edofStatus: "valide" },
      source: "reglementaire",
    },
    entretienAccueil(["edof_validation"]),
    {
      code: "recap_inscription",
      label: "Récapitulatif d'inscription envoyé",
      description: "Mail type « mail recap suite inscription » avec les dates de formation (penser à modifier les astérisques).",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
      prerequisites: ["edof_validation"],
      page: "dossier",
      source: "process_suivi_formation",
    },
    {
      code: "convention_livret",
      label: "Convention et livret d'accueil envoyés",
      description: "Modèles « Convention de formation » et « Accueil stagiaire », envoi par e-mail ; la convention passe en acceptée à la signature en ligne. Rattacher l'entretien d'accueil à la convention.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
      prerequisites: ["recap_inscription"],
      page: "documents",
      source: "process_suivi_formation",
    },
    ...mobilisationFormateur,
    testPositionnement(["entretien_accueil"]),
    {
      code: "elearning_acces",
      label: "Accès e-learning envoyés",
      description: "Le jour du début de formation officiel : envoyer les identifiants de la plateforme correspondant au thème.",
      role: "admin_staff",
      family: "pedagogie",
      delay: { anchor: "debut", offset: 0 },
      prerequisites: ["edof_validation"],
      page: "elearning",
      effect: { elearningAccessSent: true },
      source: "process_suivi_formation",
    },
    {
      code: "elearning_premiere_connexion",
      label: "Première connexion e-learning vérifiée",
      description: "Appeler le stagiaire dans la journée pour s'assurer de la réception des identifiants et l'inviter à se connecter : l'entrée en formation EDOF exige une trace de connexion.",
      role: "admin_staff",
      family: "pedagogie",
      delay: { anchor: "debut", offset: 0 },
      prerequisites: ["elearning_acces"],
      page: "elearning",
      source: "process_suivi_formation",
    },
    {
      code: "entretien_premier_cours",
      label: "Point après le premier cours",
      description: "Non formalisé, possible par e-mail : s'assurer que le premier cours s'est déroulé conformément aux attentes.",
      role: "admin_staff",
      family: "pedagogie",
      delay: { anchor: "debut", offset: 1, unit: "ouvres" },
      prerequisites: [],
      page: "parcours",
      source: "process_suivi_formation",
    },
    {
      code: "edof_entree",
      label: "Entrée en formation déclarée sur EDOF",
      description: "Uniquement après une trace de connexion e-learning du stagiaire.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "debut", offset: 1, unit: "ouvres" },
      prerequisites: ["elearning_premiere_connexion"],
      page: "financements",
      effect: { edofStatus: "entree", edofEntry: true },
      source: "process_suivi_formation",
    },
    {
      code: "elearning_suivi_connexions",
      label: "Suivi des connexions e-learning",
      description: "Au moins une fois par semaine ; relancer en cas de connexion insuffisante (temps moyen hebdomadaire = heures totales / nombre de semaines).",
      role: "admin_staff",
      family: "pedagogie",
      delay: { anchor: "debut", offset: 7 },
      prerequisites: ["edof_entree"],
      page: "elearning",
      source: "process_suivi_formation",
    },
    inscriptionCertification({ anchor: "fin", offset: -21 }),
    entretienMiParcours,
    verifFin,
    evaluationPost,
    entretienBilan([]),
    passageCertification,
    bilanPedagogique,
    attestationFin(["bilan_pedagogique"]),
    {
      code: "edof_sortie",
      label: "Sortie de formation déclarée sur EDOF",
      description: "Une fois la certification passée si la formation en prévoit une.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "fin", offset: 1 },
      prerequisites: ["edof_entree", "certification_passage"],
      page: "financements",
      effect: { edofStatus: "sortie", edofExit: true },
      source: "process_suivi_formation",
    },
    {
      code: "edof_facturation",
      label: "Facturation sur EDOF",
      description: "Déclarer le service fait et facturer la Caisse des Dépôts sur EDOF ; vérifier que le coût total correspond au dossier.",
      role: "finance",
      family: "finance",
      delay: { anchor: "precedente", offset: 2, unit: "ouvres" },
      prerequisites: ["edof_sortie"],
      page: "factures",
      effect: { edofStatus: "facture" },
      source: "reglementaire",
    },
    enqueteFroid(["entretien_bilan"]),
    {
      code: "avis_google",
      label: "Avis Google et questionnaire CPF sollicités",
      description: "Encourager le stagiaire à laisser un avis Google (lien dans le mail d'évaluation) et à répondre au questionnaire de satisfaction du CPF.",
      role: "admin_staff",
      family: "qualite",
      delay: { anchor: "fin", offset: 2, unit: "ouvres" },
      prerequisites: ["entretien_bilan"],
      page: "enquetes",
      source: "process_suivi_formation",
    },
  ],
};

/* ---------- AIF (France Travail, Kairos) ---------- */

const aif: WorkflowTemplate = {
  code: "aif",
  label: "AIF France Travail (Kairos)",
  description: "Aide individuelle à la formation : devis saisi sur Kairos, validation par le demandeur d'emploi puis par son conseiller, suivi jusqu'à la sortie.",
  steps: [
    {
      code: "carif_session",
      label: "Numéro de session Carif relevé",
      description: "Rechercher la formation dans Kairos et noter son numéro de session Carif (colonne de gauche).",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "inscription", offset: 1, unit: "ouvres" },
      prerequisites: [],
      page: "session",
      source: "saisie_devis_kairos",
    },
    {
      code: "kairos_devis",
      label: "Devis AIF saisi et transmis sur Kairos",
      description: "« Gérer DE » puis « Saisir un devis AIF » avec le numéro de session Carif ; « Formation réglementée » : non ; champs à astérisque ; cocher les trois certifications de l'organisme ; nom et qualité ; transmettre puis confirmer.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
      prerequisites: ["carif_session"],
      page: "financements",
      effect: { kairosStatus: "transmis" },
      source: "saisie_devis_kairos",
    },
    {
      code: "kairos_validation_de",
      label: "Devis validé par le demandeur d'emploi",
      description: "Le devis est transmis au demandeur d'emploi qui doit le valider pour transmission à son conseiller : suivre le tableau de bord Kairos.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "precedente", offset: 3, unit: "ouvres" },
      prerequisites: ["kairos_devis"],
      page: "financements",
      effect: { kairosStatus: "valide_de" },
      source: "saisie_devis_kairos",
    },
    {
      code: "kairos_accord",
      label: "Décision France Travail reçue sur Kairos",
      description: "Consulter régulièrement le tableau de bord Kairos pour suivre le statut du devis. Reporter la référence et la date d'accord dans le financement.",
      role: "admin_staff",
      family: "finance",
      delay: { anchor: "debut", offset: -3, unit: "ouvres" },
      prerequisites: ["kairos_validation_de"],
      page: "financements",
      effect: { kairosStatus: "accorde" },
      source: "saisie_devis_kairos",
    },
    entretienAccueil([], { anchor: "inscription", offset: 3, unit: "ouvres" }),
    {
      code: "recap_inscription",
      label: "Récapitulatif d'inscription envoyé",
      description: "Mail type « mail recap suite inscription » avec les dates de formation.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
      prerequisites: ["kairos_accord"],
      page: "dossier",
      source: "process_suivi_formation",
    },
    ...mobilisationFormateur,
    testPositionnement(["entretien_accueil"]),
    {
      code: "kairos_entree",
      label: "Entrée en formation déclarée sur Kairos",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "debut", offset: 1, unit: "ouvres" },
      prerequisites: ["kairos_accord"],
      page: "financements",
      effect: { kairosStatus: "entree" },
      source: "reglementaire",
    },
    inscriptionCertification({ anchor: "fin", offset: -21 }),
    entretienMiParcours,
    verifFin,
    evaluationPost,
    entretienBilan([]),
    passageCertification,
    bilanPedagogique,
    attestationFin(["bilan_pedagogique"]),
    {
      code: "kairos_sortie",
      label: "Sortie de formation déclarée sur Kairos",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "fin", offset: 1, unit: "ouvres" },
      prerequisites: ["kairos_entree"],
      page: "financements",
      effect: { kairosStatus: "sortie" },
      source: "reglementaire",
    },
    {
      code: "facturation_financeur",
      label: "Facture émise au financeur",
      description: "Selon les modalités de l'accord France Travail ; joindre les justificatifs de réalisation demandés.",
      role: "finance",
      family: "finance",
      delay: { anchor: "precedente", offset: 3, unit: "ouvres" },
      prerequisites: ["kairos_sortie"],
      page: "factures",
      source: "reglementaire",
    },
    enqueteFroid(["entretien_bilan"]),
  ],
};

/* ---------- Acheteur public (bon de commande, Chorus Pro) ---------- */

const publicBuyer: WorkflowTemplate = {
  code: "public",
  label: "Acheteur public (bon de commande, Chorus Pro)",
  description: "Devis, bon de commande signé, organisation, clôture pédagogique puis facture déposée sur Chorus Pro. Aucune action Chorus Pro avant la facturation.",
  steps: [
    {
      code: "devis_envoye",
      label: "Devis émis et envoyé",
      role: "sales",
      family: "commercial",
      delay: { anchor: "inscription", offset: 1, unit: "ouvres" },
      prerequisites: [],
      page: "devis",
      source: "process_inrae",
    },
    {
      code: "bc_reception",
      label: "Bon de commande signé reçu",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "debut", offset: -10, unit: "ouvres" },
      prerequisites: ["devis_envoye"],
      page: "pieces",
      source: "process_inrae",
    },
    {
      code: "bc_conformite",
      label: "Conformité du bon de commande vérifiée",
      description: "Intitulé de la formation, dates et durée, montant HT / TTC, référence du devis. Aucune action sur Chorus Pro à ce stade.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
      prerequisites: ["bc_reception"],
      page: "pieces",
      source: "process_inrae",
    },
    {
      code: "bc_confirmation",
      label: "Bon de commande et devis classés, confirmation de commande envoyée",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
      prerequisites: ["bc_conformite"],
      page: "documents",
      source: "process_inrae",
    },
    {
      code: "planification",
      label: "Session planifiée et intervenant confirmé",
      role: "pedagogy_manager",
      family: "pedagogie",
      delay: { anchor: "debut", offset: -10 },
      prerequisites: ["bc_conformite"],
      page: "session",
      source: "process_inrae",
    },
    {
      code: "convocations",
      label: "Convocations envoyées",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "debut", offset: -7 },
      prerequisites: ["planification"],
      page: "documents",
      source: "process_inrae",
    },
    {
      code: "preparation",
      label: "Programme, feuilles d'émargement et supports préparés",
      role: "pedagogy_manager",
      family: "pedagogie",
      delay: { anchor: "debut", offset: -2, unit: "ouvres" },
      prerequisites: ["planification"],
      page: "session",
      source: "process_inrae",
    },
    {
      code: "emargements",
      label: "Émargements signés pendant la formation",
      description: "Signature par période (matin / après-midi) ; une période se clôture après sa fin réelle.",
      role: "trainer",
      family: "pedagogie",
      delay: { anchor: "fin", offset: 0 },
      prerequisites: ["preparation"],
      page: "emargement",
      source: "process_inrae",
    },
    {
      code: "cloture_pedagogique",
      label: "Émargements signés et évaluations récupérés",
      role: "admin_staff",
      family: "pedagogie",
      delay: { anchor: "fin", offset: 2, unit: "ouvres" },
      prerequisites: ["emargements"],
      page: "parcours",
      source: "process_inrae",
    },
    { ...attestationFin(["cloture_pedagogique"]), source: "process_inrae" },
    {
      code: "facture_emission",
      label: "Facture émise avec les mentions obligatoires",
      description: "Numéro de bon de commande, code service, engagement juridique si requis ; facture convertie en PDF.",
      role: "finance",
      family: "finance",
      delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
      prerequisites: ["cloture_pedagogique", "bc_conformite"],
      page: "factures",
      source: "process_inrae",
    },
    {
      code: "chorus_depot",
      label: "Facture déposée sur Chorus Pro",
      description: "Déposer la facture uniquement, joindre le PDF, renseigner le bon de commande et le code service, valider l'envoi.",
      role: "finance",
      family: "finance",
      delay: { anchor: "precedente", offset: 1, unit: "ouvres" },
      prerequisites: ["facture_emission"],
      page: "factures",
      source: "process_inrae",
    },
    {
      code: "chorus_suivi",
      label: "Statut Chorus Pro suivi, relance si nécessaire",
      description: "Délai de paiement public de 30 jours à compter de la réception de la facture.",
      role: "finance",
      family: "finance",
      delay: { anchor: "precedente", offset: 30 },
      prerequisites: ["chorus_depot"],
      page: "factures",
      source: "process_inrae",
    },
    {
      code: "archivage",
      label: "Dossier complet archivé",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "precedente", offset: 5, unit: "ouvres" },
      prerequisites: ["chorus_suivi"],
      page: "documents",
      source: "process_inrae",
    },
  ],
};

/* ---------- Entreprise (financement direct ou OPCO) ---------- */

const entreprise: WorkflowTemplate = {
  code: "entreprise",
  label: "Entreprise (financement direct ou OPCO)",
  description: "Devis et convention avec l'entreprise, prise en charge OPCO le cas échéant, suivi pédagogique et facturation.",
  steps: [
    {
      code: "devis_envoye",
      label: "Devis émis et envoyé",
      description: "Dates, nombre total d'heures, répartition visio / e-learning / certification, coût horaire.",
      role: "sales",
      family: "commercial",
      delay: { anchor: "inscription", offset: 1, unit: "ouvres" },
      prerequisites: [],
      page: "devis",
      source: "process_suivi_formation",
    },
    {
      code: "opco_prise_en_charge",
      label: "Demande de prise en charge OPCO déposée et accord reçu",
      description: "Reporter la référence, la date et la source de l'accord dans le financement.",
      role: "finance",
      family: "finance",
      delay: { anchor: "debut", offset: -10, unit: "ouvres" },
      prerequisites: ["devis_envoye"],
      page: "financements",
      when: "opco",
      source: "reglementaire",
    },
    {
      code: "convention_livret",
      label: "Convention et livret d'accueil envoyés",
      description: "La convention passe en acceptée à la signature.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "debut", offset: -7 },
      prerequisites: ["devis_envoye"],
      page: "documents",
      source: "process_suivi_formation",
    },
    entretienAccueil(["devis_envoye"]),
    ...mobilisationFormateur,
    testPositionnement(["entretien_accueil"]),
    inscriptionCertification({ anchor: "fin", offset: -21 }),
    entretienMiParcours,
    verifFin,
    evaluationPost,
    entretienBilan([]),
    passageCertification,
    bilanPedagogique,
    attestationFin(["bilan_pedagogique"]),
    {
      code: "facture_emission",
      label: "Facture émise",
      description: "À l'entreprise ou à l'OPCO selon l'accord de prise en charge.",
      role: "finance",
      family: "finance",
      delay: { anchor: "fin", offset: 3, unit: "ouvres" },
      prerequisites: ["attestation_fin"],
      page: "factures",
      source: "reglementaire",
    },
    enqueteFroid(["entretien_bilan"]),
  ],
};

/* ---------- CFA (apprentissage) ---------- */

const cfa: WorkflowTemplate = {
  code: "cfa",
  label: "Apprentissage (CFA, OPCO)",
  description: "Contrat d'apprentissage, convention CFA / employeur, dépôt et prise en charge OPCO, suivi en entreprise et facturation OPCO.",
  steps: [
    {
      code: "contrat_apprentissage",
      label: "Contrat d'apprentissage (Cerfa) signé recueilli",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "debut", offset: -7 },
      prerequisites: [],
      page: "pieces",
      source: "reglementaire",
    },
    {
      code: "convention_cfa",
      label: "Convention de formation CFA / employeur signée",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "debut", offset: -7 },
      prerequisites: [],
      page: "documents",
      source: "reglementaire",
    },
    entretienAccueil([], { anchor: "debut", offset: -5, unit: "ouvres" }),
    {
      code: "opco_depot",
      label: "Dépôt du contrat auprès de l'OPCO vérifié",
      description: "L'employeur transmet le contrat à l'OPCO dans les 5 jours qui suivent le début d'exécution.",
      role: "admin_staff",
      family: "administratif",
      delay: { anchor: "debut", offset: 5 },
      prerequisites: ["contrat_apprentissage", "convention_cfa"],
      page: "financements",
      source: "reglementaire",
    },
    {
      code: "opco_prise_en_charge",
      label: "Accord de prise en charge OPCO reçu",
      description: "Reporter le niveau de prise en charge appliqué, sa source et sa date dans le financement.",
      role: "finance",
      family: "finance",
      delay: { anchor: "precedente", offset: 15 },
      prerequisites: ["opco_depot"],
      page: "financements",
      source: "reglementaire",
    },
    testPositionnement(["entretien_accueil"]),
    {
      code: "suivi_entreprise_initial",
      label: "Premier contact de suivi avec le maître d'apprentissage",
      role: "pedagogy_manager",
      family: "pedagogie",
      delay: { anchor: "debut", offset: 30 },
      prerequisites: [],
      page: "suivi_entreprise",
      source: "reglementaire",
    },
    {
      code: "fin_periode_essai",
      label: "Point de fin de période d'essai",
      description: "Échéance indicative : la période d'essai court sur 45 jours de formation pratique en entreprise, à recalculer selon le rythme d'alternance.",
      role: "pedagogy_manager",
      family: "pedagogie",
      delay: { anchor: "debut", offset: 45 },
      prerequisites: [],
      page: "suivi_entreprise",
      source: "reglementaire",
    },
    {
      code: "facturation_opco",
      label: "Première facture OPCO émise",
      description: "Selon l'échéancier de prise en charge.",
      role: "finance",
      family: "finance",
      delay: { anchor: "precedente", offset: 5, unit: "ouvres" },
      prerequisites: ["opco_prise_en_charge"],
      page: "factures",
      source: "reglementaire",
    },
    entretienMiParcours,
    inscriptionCertification({ anchor: "fin", offset: -60 }),
    entretienBilan([]),
    passageCertification,
    attestationFin([]),
    enqueteFroid(["entretien_bilan"]),
  ],
};

export const WORKFLOW_TEMPLATES: Record<WorkflowCode, WorkflowTemplate> = { cpf, aif, public: publicBuyer, entreprise, cfa };

export const workflowLabels: Record<WorkflowCode, string> = Object.fromEntries(WORKFLOW_CODES.map((c) => [c, WORKFLOW_TEMPLATES[c].label])) as Record<WorkflowCode, string>;

export function isWorkflowCode(v: unknown): v is WorkflowCode {
  return typeof v === "string" && (WORKFLOW_CODES as readonly string[]).includes(v);
}

export function getWorkflow(code: string | null | undefined): WorkflowTemplate | null {
  return isWorkflowCode(code) ? WORKFLOW_TEMPLATES[code] : null;
}

export function getStep(code: WorkflowCode, stepCode: string): WorkflowStep | null {
  return WORKFLOW_TEMPLATES[code].steps.find((s) => s.code === stepCode) ?? null;
}

/** Clé d'idempotence de la tâche d'une étape. */
export function workflowTaskKey(enrollmentId: string, stepCode: string): string {
  return `wf:${enrollmentId}:${stepCode}`;
}

/** Lien vers la page concernée par l'étape. */
export function stepHref(step: Pick<WorkflowStep, "page">, ids: { orgId: string; enrollmentId: string; sessionId: string }): string {
  const base = `/app/${ids.orgId}`;
  const dossier = `${base}/inscriptions/${ids.enrollmentId}`;
  switch (step.page) {
    case "dossier":
      return dossier;
    case "pieces":
    case "parcours":
    case "documents":
    case "financements":
    case "examens":
    case "journal":
      return `${dossier}?onglet=${step.page}`;
    case "session":
      return `${base}/sessions/${ids.sessionId}`;
    case "devis":
      return `${base}/devis`;
    case "factures":
      return `${base}/factures`;
    case "enquetes":
      return `${base}/enquetes`;
    case "elearning":
      return `${base}/elearning`;
    case "emargement":
      return `${base}/emargement`;
    case "suivi_entreprise":
      return `${base}/suivi-entreprise`;
    case "signatures":
      return `${base}/signatures`;
  }
}

/* ---------- Choix automatique du parcours ---------- */

export type FundingKind = "opco" | "entreprise" | "france_travail" | "region" | "cpf" | "particulier" | "etat" | "agefiph" | "transition_pro" | "autre";

/**
 * Choisit le parcours d'après le contrat, la session et les financements connus (non annulés).
 * Ordre : apprentissage → CPF → AIF (France Travail) → acheteur public (État, région) → entreprise / OPCO.
 * Retourne null quand rien ne permet de trancher (particulier sans financement connu) : le choix reste humain.
 */
export function pickWorkflowCode(input: { contractKind: string; isApprenticeship: boolean; fundingKinds: string[]; companyId: string | null }): WorkflowCode | null {
  const kinds = new Set(input.fundingKinds);
  if (input.contractKind === "contrat_apprentissage" || input.isApprenticeship) return "cfa";
  if (input.contractKind === "cpf" || kinds.has("cpf")) return "cpf";
  if (kinds.has("france_travail")) return "aif";
  if (kinds.has("etat") || kinds.has("region")) return "public";
  if (kinds.has("opco") || kinds.has("entreprise") || input.companyId) return "entreprise";
  return null;
}

/** Étapes applicables selon les conditions de l'inscription (certification prévue, financement OPCO). */
export function applicableSteps(template: WorkflowTemplate, flags: { certification: boolean; opco: boolean }): WorkflowStep[] {
  return template.steps.filter((s) => !s.when || (s.when === "certification" ? flags.certification : flags.opco));
}
