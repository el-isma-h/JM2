/**
 * Catalogue de démonstration : 8 programmes avec version active complète, modules cohérents avec la durée,
 * 2 certifications (RNCP et RS) et 3 modules e-learning.
 */

export type ModuleSeed = { blockCode?: string; code: string; title: string; hours: number; description?: string; skills?: { code: string; label: string }[] };

export type ProgramSeed = {
  key: "bts" | "arh" | "sst" | "management" | "excel" | "elec" | "bilan" | "accueil";
  code: string;
  title: string;
  kind: "bts" | "titre_professionnel" | "formation_courte" | "habilitation" | "bilan";
  category: string;
  certification?: "rncp_bts" | "rncp_arh" | "rs_sst";
  availableAsApprenticeship: boolean;
  availableAsContinuing: boolean;
  cpfEligible: boolean;
  formacode: string;
  specialty: string;
  isPublished: boolean;
  version: {
    objectives: string;
    prerequisites: string;
    audience: string;
    modality: "presentiel" | "mixte" | "distanciel";
    durationHours: number;
    durationDays: number;
    companyHours: number;
    remoteHours: number;
    content: string;
    methods: string;
    evaluationMethods: string;
    resources: string;
    accessibility: string;
    accessDelay: string;
    priceCents: number | null;
    priceNote: string;
    rhythm: Record<string, unknown>;
    trainerProfile: string;
  };
  modules: ModuleSeed[];
};

const ACCESS = "Locaux accessibles aux personnes à mobilité réduite (ascenseur, sanitaires adaptés). Référente handicap : Nathalie Roussel. Chaque situation fait l'objet d'un entretien pour adapter les modalités (supports, rythme, aménagements d'épreuves).";

export const CERTIFICATIONS = {
  rncp_bts: {
    title: "BTS Gestion de la PME",
    rncpCode: "RNCP38363",
    certifier: "Ministère de l'Enseignement supérieur et de la Recherche",
    level: "5 (Bac+2)",
    validUntil: "2028-08-31",
    blocks: [
      { code: "BC01", label: "Gérer la relation avec les clients et les fournisseurs de la PME", description: "Recherche de clientèle, administration des ventes, suivi des achats." },
      { code: "BC02", label: "Participer à la gestion des risques de la PME", description: "Veille, gestion des risques financiers et non financiers." },
      { code: "BC03", label: "Gérer le personnel et contribuer à la GRH", description: "Administration du personnel, paie, participation à la GRH." },
      { code: "BC04", label: "Soutenir le fonctionnement et le développement de la PME", description: "Organisation, communication, développement commercial." },
    ],
    habilitationRef: "UAI 0932987X (déclaration d'ouverture section BTS, rectorat de Créteil)",
    habilitationValidUntil: "2028-08-31",
  },
  rncp_arh: {
    title: "Titre professionnel Assistant ressources humaines",
    rncpCode: "RNCP35030",
    certifier: "Ministère du Travail, du Plein emploi et de l'Insertion",
    level: "5 (Bac+2)",
    validUntil: "2027-07-20",
    blocks: [
      { code: "CCP1", label: "Assurer les missions opérationnelles de la gestion des ressources humaines", description: "Administration du personnel, paie, recrutement, formation." },
      { code: "CCP2", label: "Contribuer au développement des ressources humaines", description: "Projets RH, communication interne, indicateurs sociaux." },
    ],
    habilitationRef: "Agrément DREETS Île-de-France n° 2024-IDF-0417",
    habilitationValidUntil: "2027-07-20",
  },
  rs_sst: {
    title: "Sauveteur secouriste du travail (SST)",
    rsCode: "RS5761",
    certifier: "INRS / Assurance Maladie - Risques professionnels",
    level: "Sans niveau",
    validUntil: "2027-12-31",
    blocks: [
      { code: "D1", label: "Intervenir face à une situation d'accident du travail", description: "Protéger, examiner, alerter, secourir." },
      { code: "D2", label: "Contribuer à la prévention des risques professionnels", description: "Situer son rôle, repérer les dangers, informer." },
    ],
    habilitationRef: "Habilitation INRS n° 1204567/2024/SST-01/O/11",
    habilitationValidUntil: "2027-12-31",
  },
} as const;

export const PROGRAMS: ProgramSeed[] = [
  {
    key: "bts",
    code: "BTS-GPME",
    title: "BTS Gestion de la PME en apprentissage",
    kind: "bts",
    category: "Gestion et administration",
    certification: "rncp_bts",
    availableAsApprenticeship: true,
    availableAsContinuing: false,
    cpfEligible: false,
    formacode: "32054",
    specialty: "Gestion, administration des entreprises",
    isPublished: true,
    version: {
      objectives: "Préparer le diplôme d'État BTS Gestion de la PME (niveau 5). À l'issue du parcours, l'apprenti est capable de gérer la relation clients et fournisseurs, de participer à la gestion des risques, d'administrer le personnel et de soutenir le fonctionnement de la PME.",
      prerequisites: "Baccalauréat (toutes séries) ou équivalent. Contrat d'apprentissage signé avec une entreprise d'accueil. Entretien de motivation et test de positionnement.",
      audience: "Jeunes de 16 à 29 ans révolus en contrat d'apprentissage ; bénéficiaires RQTH sans limite d'âge.",
      modality: "presentiel",
      durationHours: 1350,
      durationDays: 193,
      companyHours: 2200,
      remoteHours: 60,
      content: "Culture générale et expression, langue vivante anglais, culture économique juridique et managériale, gérer la relation avec les clients et les fournisseurs (bloc 1), participer à la gestion des risques (bloc 2), gérer le personnel (bloc 3), soutenir le fonctionnement et le développement de la PME (bloc 4), ateliers de professionnalisation, communication.",
      methods: "Alternance 2 jours en centre / 8 jours en entreprise. Cours, études de cas issus des entreprises d'accueil, ateliers de professionnalisation, projets tutorés, livret d'apprentissage partagé avec le maître d'apprentissage.",
      evaluationMethods: "Évaluations formatives par bloc, BTS blanc en décembre et mai, épreuves finales selon le règlement d'examen (épreuves ponctuelles et CCF).",
      resources: "Salles équipées, PGI de démonstration, suite bureautique, accès plateforme e-learning, centre de ressources documentaires.",
      accessibility: ACCESS,
      accessDelay: "Entrée en formation de septembre à novembre selon la date de signature du contrat (délai légal de 3 mois).",
      priceCents: null,
      priceNote: "Prise en charge par l'OPCO de l'employeur selon le niveau de prise en charge (NPEC) de la branche. Aucun reste à charge pour l'apprenti.",
      rhythm: { preset: "2_8", label: "2 jours / 8 jours", centerDays: 2, companyDays: 8, weekdays: [1, 2], morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } },
      trainerProfile: "Enseignants certifiés en économie-gestion et professionnels en activité (experts-comptables, responsables RH).",
    },
    modules: [
      { code: "CGE", title: "Culture générale et expression", hours: 120 },
      { code: "LV1", title: "Anglais professionnel", hours: 120 },
      { code: "CEJM", title: "Culture économique, juridique et managériale", hours: 180 },
      { blockCode: "BC01", code: "B1", title: "Gérer la relation avec les clients et les fournisseurs", hours: 270, skills: [{ code: "B1.1", label: "Rechercher et prospecter la clientèle" }, { code: "B1.2", label: "Administrer les ventes" }, { code: "B1.3", label: "Suivre les achats" }] },
      { blockCode: "BC02", code: "B2", title: "Participer à la gestion des risques", hours: 150, skills: [{ code: "B2.1", label: "Conduire une veille" }, { code: "B2.2", label: "Gérer les risques financiers" }] },
      { blockCode: "BC03", code: "B3", title: "Gérer le personnel et contribuer à la GRH", hours: 180, skills: [{ code: "B3.1", label: "Administrer le personnel" }, { code: "B3.2", label: "Préparer la paie" }] },
      { blockCode: "BC04", code: "B4", title: "Soutenir le fonctionnement et le développement", hours: 210, skills: [{ code: "B4.1", label: "Organiser le fonctionnement" }, { code: "B4.2", label: "Contribuer au développement commercial" }] },
      { code: "ATP", title: "Ateliers de professionnalisation", hours: 120 },
    ],
  },
  {
    key: "arh",
    code: "TP-ARH",
    title: "Titre professionnel Assistant ressources humaines",
    kind: "titre_professionnel",
    category: "Ressources humaines",
    certification: "rncp_arh",
    availableAsApprenticeship: true,
    availableAsContinuing: true,
    cpfEligible: true,
    formacode: "33054",
    specialty: "Ressources humaines",
    isPublished: true,
    version: {
      objectives: "Obtenir le titre professionnel Assistant ressources humaines (niveau 5) : assurer les missions opérationnelles de la gestion RH (administration du personnel, paie, recrutement, formation) et contribuer au développement des ressources humaines.",
      prerequisites: "Niveau 4 (baccalauréat) ou expérience administrative d'un an ; maîtrise de la bureautique ; positionnement d'entrée.",
      audience: "Demandeurs d'emploi, salariés en reconversion, personnes en transition professionnelle.",
      modality: "mixte",
      durationHours: 720,
      durationDays: 120,
      companyHours: 210,
      remoteHours: 90,
      content: "CCP1 : administration du personnel (dossiers, contrats, absences, paie), recrutement et intégration, plan de développement des compétences. CCP2 : projets RH, communication interne, indicateurs sociaux, veille juridique. Période en entreprise de 6 semaines. Préparation à la session d'examen (dossier professionnel, mise en situation).",
      methods: "Temps plein en centre (lundi à vendredi), 90 heures à distance sur la plateforme e-learning (modules de paie et de droit social), stage pratique en entreprise, accompagnement individuel au projet.",
      evaluationMethods: "Évaluations en cours de formation (ECF) par compétence, dossier professionnel, mise en situation professionnelle devant jury, entretien final.",
      resources: "Logiciel de paie de démonstration, SIRH, code du travail, plateforme e-learning, salle informatique.",
      accessibility: ACCESS,
      accessDelay: "Deux entrées par an (septembre, mars). Délai d'accès : 15 jours après l'entretien de positionnement, sous réserve de l'accord de financement.",
      priceCents: 798000,
      priceNote: "Tarif public HT par stagiaire. Finançable CPF, France Travail (AIF), Région Île-de-France, Transitions Pro.",
      rhythm: { preset: "continu", label: "Continu (temps plein en centre)", centerDays: 5, companyDays: 0, weekdays: [1, 2, 3, 4, 5], morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } },
      trainerProfile: "Professionnels RH en activité ou anciens DRH, formateurs habilités jury titre professionnel.",
    },
    modules: [
      { code: "M0", title: "Positionnement et projet professionnel", hours: 24 },
      { blockCode: "CCP1", code: "M1", title: "Administration du personnel et paie", hours: 210, skills: [{ code: "C1", label: "Assurer la gestion administrative du personnel" }, { code: "C2", label: "Préparer les éléments de paie" }] },
      { blockCode: "CCP1", code: "M2", title: "Recrutement, intégration et formation", hours: 120, skills: [{ code: "C3", label: "Contribuer au recrutement" }, { code: "C4", label: "Participer au plan de développement des compétences" }] },
      { blockCode: "CCP2", code: "M3", title: "Projets RH et communication interne", hours: 96, skills: [{ code: "C5", label: "Contribuer aux projets RH" }] },
      { blockCode: "CCP2", code: "M4", title: "Indicateurs sociaux et veille juridique", hours: 60, skills: [{ code: "C6", label: "Produire et analyser des indicateurs" }] },
      { code: "M5", title: "Période en entreprise", hours: 210, description: "Stage pratique de 6 semaines." },
    ],
  },
  {
    key: "sst",
    code: "SST-INIT",
    title: "Sauveteur secouriste du travail (formation initiale)",
    kind: "habilitation",
    category: "Sécurité et prévention",
    certification: "rs_sst",
    availableAsApprenticeship: false,
    availableAsContinuing: true,
    cpfEligible: false,
    formacode: "42866",
    specialty: "Secourisme",
    isPublished: true,
    version: {
      objectives: "Intervenir efficacement face à une situation d'accident du travail et contribuer à la prévention des risques professionnels dans son entreprise. Obtenir le certificat SST (validité 24 mois).",
      prerequisites: "Aucun prérequis. Aptitude physique à réaliser les gestes de secours.",
      audience: "Tout salarié désigné sauveteur secouriste du travail.",
      modality: "presentiel",
      durationHours: 14,
      durationDays: 2,
      companyHours: 0,
      remoteHours: 0,
      content: "Rôle du SST, cadre juridique, protéger, examiner, faire alerter, secourir (saignement, étouffement, malaise, brûlure, traumatisme, plaie, arrêt cardiaque avec défibrillateur), situations inhérentes aux risques spécifiques de l'entreprise, contribution à la prévention.",
      methods: "Exposés courts, démonstrations pratiques, mises en situation d'accidents simulés, cas concrets adaptés aux risques des entreprises des stagiaires.",
      evaluationMethods: "Épreuves certificatives (deux mises en situation) selon le référentiel INRS, grille de certification. Délivrance du certificat SST par le réseau Assurance Maladie - Risques professionnels.",
      resources: "Mannequins adulte, enfant, nourrisson ; défibrillateur de formation ; matériel de simulation.",
      accessibility: ACCESS,
      accessDelay: "Inscription jusqu'à 5 jours ouvrés avant la session (inter) ; intra sous 3 semaines.",
      priceCents: 29000,
      priceNote: "Tarif inter-entreprises HT par stagiaire, repas non compris. Intra : 1 690 € HT pour 4 à 10 stagiaires.",
      rhythm: { preset: "continu", label: "2 jours consécutifs", centerDays: 2, companyDays: 0, weekdays: [1, 2, 3, 4, 5], morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } },
      trainerProfile: "Formateur SST certifié INRS, à jour de son maintien et actualisation des compétences.",
    },
    modules: [
      { blockCode: "D1", code: "SST1", title: "Intervenir face à une situation d'accident", hours: 9 },
      { blockCode: "D2", code: "SST2", title: "Contribuer à la prévention des risques", hours: 3 },
      { code: "SST3", title: "Épreuves certificatives", hours: 2 },
    ],
  },
  {
    key: "management",
    code: "MGT-EQ",
    title: "Management d'équipe : les fondamentaux",
    kind: "formation_courte",
    category: "Management",
    availableAsApprenticeship: false,
    availableAsContinuing: true,
    cpfEligible: false,
    formacode: "32032",
    specialty: "Management d'équipe",
    isPublished: true,
    version: {
      objectives: "Se positionner dans son rôle de manager, organiser le travail de l'équipe, conduire des entretiens individuels, donner un feedback constructif et gérer les situations tendues.",
      prerequisites: "Encadrer une équipe ou être en prise de poste de manager dans les 6 mois.",
      audience: "Managers de proximité, chefs d'équipe, responsables de service.",
      modality: "presentiel",
      durationHours: 21,
      durationDays: 3,
      companyHours: 0,
      remoteHours: 0,
      content: "Jour 1 : rôle et posture du manager, styles de management, délégation. Jour 2 : communication managériale, entretiens individuels, feedback, motivation. Jour 3 : gestion des tensions, conduite de réunion, plan d'action personnel.",
      methods: "Apports théoriques courts, jeux de rôle filmés, analyse de situations apportées par les participants, co-développement, plan d'action individuel.",
      evaluationMethods: "Auto-positionnement en début et fin de formation, mises en situation évaluées, questionnaire de satisfaction à chaud et à froid (3 mois).",
      resources: "Salle modulable, supports remis, accès aux fiches outils en ligne pendant 6 mois.",
      accessibility: ACCESS,
      accessDelay: "Sessions inter programmées chaque trimestre ; inscription jusqu'à 10 jours avant.",
      priceCents: 145000,
      priceNote: "Tarif inter HT par participant, 3 jours. Intra sur devis.",
      rhythm: { preset: "continu", label: "3 jours consécutifs", centerDays: 3, companyDays: 0, weekdays: [1, 2, 3, 4, 5], morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } },
      trainerProfile: "Formateur ayant exercé des fonctions de management (10 ans minimum) et formé à l'animation.",
    },
    modules: [
      { code: "MG1", title: "Rôle et posture du manager", hours: 7 },
      { code: "MG2", title: "Communication et entretiens", hours: 7 },
      { code: "MG3", title: "Situations difficiles et plan d'action", hours: 7 },
    ],
  },
  {
    key: "excel",
    code: "BUR-XLS2",
    title: "Excel avancé : tableaux croisés, fonctions et automatisation",
    kind: "formation_courte",
    category: "Bureautique",
    availableAsApprenticeship: false,
    availableAsContinuing: true,
    cpfEligible: true,
    formacode: "35066",
    specialty: "Logiciels tableurs",
    isPublished: true,
    version: {
      objectives: "Exploiter des bases de données sous Excel, construire des tableaux croisés dynamiques, utiliser les fonctions avancées (RECHERCHEX, SI imbriqués, INDEX/EQUIV), automatiser des traitements simples avec Power Query.",
      prerequisites: "Pratique régulière d'Excel : saisie, mise en forme, formules simples. Test de positionnement en ligne.",
      audience: "Assistants, gestionnaires, contrôleurs de gestion, toute personne exploitant des données.",
      modality: "presentiel",
      durationHours: 14,
      durationDays: 2,
      companyHours: 0,
      remoteHours: 0,
      content: "Structurer une base de données, trier et filtrer, fonctions logiques et de recherche, tableaux et graphiques croisés dynamiques, segments, Power Query (import, nettoyage, fusion), protection et partage.",
      methods: "Un poste par stagiaire, exercices progressifs sur des fichiers métiers, cas pratique de synthèse.",
      evaluationMethods: "Exercices évalués en cours de formation, cas final noté ; possibilité de passer la certification TOSA Excel (option).",
      resources: "Salle informatique, fichiers d'exercices, aide-mémoire.",
      accessibility: ACCESS,
      accessDelay: "Inscription jusqu'à 5 jours ouvrés avant la session.",
      priceCents: 79000,
      priceNote: "Tarif inter HT par stagiaire, 2 jours. Certification TOSA en option : 95 € HT.",
      rhythm: { preset: "continu", label: "2 jours consécutifs", centerDays: 2, companyDays: 0, weekdays: [1, 2, 3, 4, 5], morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } },
      trainerProfile: "Formateur bureautique certifié TOSA niveau expert.",
    },
    modules: [
      { code: "XL1", title: "Bases de données et fonctions avancées", hours: 7 },
      { code: "XL2", title: "Tableaux croisés dynamiques et Power Query", hours: 7 },
    ],
  },
  {
    key: "elec",
    code: "HAB-B0H0V",
    title: "Préparation à l'habilitation électrique B0 / H0V (non électricien)",
    kind: "habilitation",
    category: "Sécurité et prévention",
    availableAsApprenticeship: false,
    availableAsContinuing: true,
    cpfEligible: false,
    formacode: "24054",
    specialty: "Habilitation électrique",
    isPublished: true,
    version: {
      objectives: "Permettre à l'employeur de délivrer l'habilitation B0 / H0V : connaître les risques électriques, les zones d'environnement, les prescriptions de sécurité pour réaliser des travaux non électriques à proximité d'installations.",
      prerequisites: "Aucune connaissance en électricité requise. Comprendre les consignes de sécurité en français.",
      audience: "Personnel non électricien intervenant en environnement électrique (agents de maintenance, nettoyage, peintres, maçons).",
      modality: "presentiel",
      durationHours: 7,
      durationDays: 1,
      companyHours: 0,
      remoteHours: 0,
      content: "Grandeurs électriques, effets du courant sur le corps humain, zones d'environnement, symboles d'habilitation, rôle des acteurs, prescriptions de sécurité, équipements de protection, conduite à tenir en cas d'accident.",
      methods: "Exposés, vidéos, étude de cas, mise en situation pratique sur armoire pédagogique.",
      evaluationMethods: "Évaluation théorique (QCM) et pratique selon la norme NF C 18-510 ; avis préparatoire à l'habilitation remis à l'employeur.",
      resources: "Armoire électrique pédagogique, EPI, supports NF C 18-510.",
      accessibility: ACCESS,
      accessDelay: "Inscription jusqu'à 5 jours ouvrés avant la session.",
      priceCents: 24000,
      priceNote: "Tarif inter HT par stagiaire, 1 jour.",
      rhythm: { preset: "continu", label: "1 jour", centerDays: 1, companyDays: 0, weekdays: [1, 2, 3, 4, 5], morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } },
      trainerProfile: "Formateur habilité, expérience en bureau de contrôle ou maintenance électrique.",
    },
    modules: [
      { code: "EL1", title: "Risques électriques et environnement", hours: 4 },
      { code: "EL2", title: "Prescriptions de sécurité et évaluation", hours: 3 },
    ],
  },
  {
    key: "bilan",
    code: "BILAN-24",
    title: "Bilan de compétences",
    kind: "bilan",
    category: "Orientation et évolution professionnelle",
    availableAsApprenticeship: false,
    availableAsContinuing: true,
    cpfEligible: true,
    formacode: "15081",
    specialty: "Bilan professionnel",
    isPublished: false,
    version: {
      objectives: "Analyser ses compétences, aptitudes et motivations pour définir un projet professionnel ou de formation réaliste, conformément aux articles L6313-4 et R6313-4 à 8 du code du travail.",
      prerequisites: "Aucun. Entretien préalable gratuit et sans engagement.",
      audience: "Salariés, demandeurs d'emploi, indépendants souhaitant faire le point sur leur parcours.",
      modality: "mixte",
      durationHours: 24,
      durationDays: 8,
      companyHours: 0,
      remoteHours: 8,
      content: "Phase préliminaire (analyse de la demande, information sur la démarche), phase d'investigation (parcours, compétences, intérêts, valeurs, tests, exploration de pistes), phase de conclusion (synthèse écrite, plan d'action, entretien de suivi à 6 mois).",
      methods: "Entretiens individuels en présentiel ou à distance, questionnaires et tests validés, travail personnel guidé, enquêtes métiers.",
      evaluationMethods: "Document de synthèse remis au bénéficiaire (seul destinataire), questionnaire de satisfaction, entretien de suivi à 6 mois.",
      resources: "Bureau individuel confidentiel, outils de tests, documentation métiers et formations.",
      accessibility: ACCESS,
      accessDelay: "Démarrage sous 15 jours après l'entretien préalable et l'accord de financement.",
      priceCents: 180000,
      priceNote: "Forfait HT 24 heures. Finançable par le CPF.",
      rhythm: { preset: "personnalise", label: "Rendez-vous individuels (2 à 3 heures)", centerDays: 0, companyDays: 0, weekdays: [], morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } },
      trainerProfile: "Consultant en bilan de compétences, psychologue du travail ou conseiller en évolution professionnelle certifié.",
    },
    modules: [
      { code: "BC-P1", title: "Phase préliminaire", hours: 3 },
      { code: "BC-P2", title: "Phase d'investigation", hours: 16 },
      { code: "BC-P3", title: "Phase de conclusion et suivi", hours: 5 },
    ],
  },
  {
    key: "accueil",
    code: "INTRA-ACC-SANTE",
    title: "Accueil en établissement de santé : qualité relationnelle et situations difficiles",
    kind: "formation_courte",
    category: "Relation client et accueil",
    availableAsApprenticeship: false,
    availableAsContinuing: true,
    cpfEligible: false,
    formacode: "35028",
    specialty: "Accueil",
    isPublished: false,
    version: {
      objectives: "Professionnaliser l'accueil physique et téléphonique des patients et de leurs proches, gérer l'attente et les situations d'agressivité, respecter la confidentialité et le secret professionnel.",
      prerequisites: "Exercer une fonction d'accueil ou de secrétariat médical dans l'établissement.",
      audience: "Agents d'accueil, secrétaires médicales, standardistes de la Clinique Sainte-Odile (formation intra).",
      modality: "presentiel",
      durationHours: 14,
      durationDays: 2,
      companyHours: 0,
      remoteHours: 0,
      content: "Les attentes du patient à l'accueil, communication verbale et non verbale, accueil téléphonique, gestion de l'attente, désamorcer l'agressivité, confidentialité et RGPD en établissement de santé, charte d'accueil de l'établissement.",
      methods: "Mises en situation construites à partir des cas réels de l'établissement, jeux de rôle, analyse de pratiques.",
      evaluationMethods: "Grille d'observation en mise en situation, questionnaire de fin de formation, bilan avec la direction.",
      resources: "Salle de réunion de l'établissement, supports personnalisés.",
      accessibility: ACCESS,
      accessDelay: "Programmation selon disponibilités de l'établissement (délai moyen 4 semaines).",
      priceCents: 260000,
      priceNote: "Forfait intra HT pour un groupe de 6 à 10 personnes, 2 jours, dans les locaux du client.",
      rhythm: { preset: "continu", label: "2 jours consécutifs", centerDays: 2, companyDays: 0, weekdays: [1, 2, 3, 4, 5], morning: { start: "09:00", end: "12:00" }, afternoon: { start: "14:00", end: "17:00" } },
      trainerProfile: "Formateur en relation client avec expérience en milieu hospitalier.",
    },
    modules: [
      { code: "AC1", title: "Accueil physique et téléphonique", hours: 7 },
      { code: "AC2", title: "Situations difficiles et confidentialité", hours: 7 },
    ],
  },
];

export type ElearningSeed = { program: ProgramSeed["key"]; kind: "contenu" | "moodle" | "quiz"; title: string; description: string; durationMinutes: number; countsAsHours: boolean; url?: string; externalId?: string; content: Record<string, unknown> };

export const ELEARNING: ElearningSeed[] = [
  {
    program: "arh",
    kind: "contenu",
    title: "Les bases du bulletin de paie",
    description: "Lecture d'un bulletin, cotisations, net à payer, mentions obligatoires.",
    durationMinutes: 90,
    countsAsHours: true,
    content: { format: "markdown", body: "# Le bulletin de paie\n\n## 1. Structure\nBrut, cotisations salariales et patronales, net imposable, net à payer.\n\n## 2. Mentions obligatoires\nIdentité de l'employeur, convention collective, période, durée du travail...\n\n## 3. Exercice\nReconstituer le net à payer à partir du brut fourni." },
  },
  {
    program: "arh",
    kind: "moodle",
    title: "Droit social : le contrat de travail (cours Moodle)",
    description: "Parcours Moodle de 6 séquences : CDI, CDD, période d'essai, modification, rupture.",
    durationMinutes: 240,
    countsAsHours: true,
    url: "https://moodle.atelier-meridien.example/course/view.php?id=42",
    externalId: "42",
    content: { provider: "moodle", courseId: 42 },
  },
  {
    program: "bts",
    kind: "quiz",
    title: "Quiz : la relation fournisseurs (bloc 1)",
    description: "10 questions pour vérifier les acquis de la séquence « Suivre les achats ».",
    durationMinutes: 20,
    countsAsHours: false,
    content: {
      questions: [
        { q: "Quel document formalise la commande auprès d'un fournisseur ?", options: ["Le devis", "Le bon de commande", "La facture", "L'avoir"], answer: 1 },
        { q: "Le délai de paiement légal par défaut entre professionnels est de :", options: ["15 jours", "30 jours", "60 jours", "90 jours"], answer: 1 },
        { q: "Un avoir correspond à :", options: ["Une remise commerciale", "Un document annulant tout ou partie d'une facture", "Un acompte", "Une relance"], answer: 1 },
      ],
      passScore: 70,
    },
  },
];
