import "server-only";
import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { INK, MUTED, clean, newPdf, para, section, writeFooter, writeOrgHeader, type Org } from "@/server/crm/pdf-base";
import { fmtDate } from "@/lib/dates";
import { checkEligibility } from "./eligibility";
import type { CohortFormData } from "@/components/pedagogy/cohort-form";

export type Cohort = typeof schema.examCohorts.$inferSelect;

/** Charge uniquement la cohorte demandée, dans l'organisme (jamais une autre). */
export async function loadCohort(orgId: string, cohortId: string): Promise<Cohort | null> {
  if (!/^[0-9a-f-]{36}$/i.test(cohortId)) return null;
  const [c] = await db.select().from(schema.examCohorts).where(and(eq(schema.examCohorts.id, cohortId), eq(schema.examCohorts.orgId, orgId))).limit(1);
  return c ?? null;
}

/** Membres de la cohorte (filtrés par cohortId ET orgId), avec inscription et personne. */
export async function listMembers(orgId: string, cohortId: string) {
  return db
    .select({ member: schema.examMembers, enrollment: { id: schema.enrollments.id, reference: schema.enrollments.reference, status: schema.enrollments.status, examState: schema.enrollments.examState, sessionId: schema.enrollments.sessionId }, person: { id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email } })
    .from(schema.examMembers)
    .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.examMembers.enrollmentId))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.examMembers.orgId, orgId), eq(schema.examMembers.cohortId, cohortId)))
    .orderBy(asc(schema.persons.lastName), asc(schema.persons.firstName));
}

/** Inscriptions candidates à l'affectation : même organisme, même formation, statut éligible, pas encore membres. */
export async function listCandidates(orgId: string, cohort: Cohort) {
  return db
    .select({ id: schema.enrollments.id, reference: schema.enrollments.reference, status: schema.enrollments.status, examState: schema.enrollments.examState, firstName: schema.persons.firstName, lastName: schema.persons.lastName, sessionCode: schema.trainingSessions.code })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .innerJoin(schema.programVersions, eq(schema.programVersions.id, sql`coalesce(${schema.enrollments.programVersionId}, ${schema.trainingSessions.programVersionId})`))
    .where(
      and(
        eq(schema.enrollments.orgId, orgId),
        eq(schema.programVersions.programId, cohort.programId),
        sql`${schema.enrollments.status} in ('inscrit','en_cours','termine')`,
        sql`not exists (select 1 from ${schema.examMembers} m where m.cohort_id = ${cohort.id} and m.enrollment_id = "enrollments"."id")`,
      ),
    )
    .orderBy(asc(schema.persons.lastName));
}

export type AssignResult = { ok: true; memberId: string } | { ok: false; reason: string };

/**
 * Affectation contrôlée : transaction avec verrou `SELECT … FOR UPDATE` sur la cohorte (envois simultanés sérialisés),
 * vérification de l'organisme, de la formation (programme de la version de l'inscription), de l'éligibilité,
 * de la capacité et du doublon (index unique `exam_members_unique` en dernier rempart).
 */
export async function assignMember(orgId: string, cohortId: string, enrollmentId: string, userId: string): Promise<AssignResult> {
  return db.transaction(async (tx) => {
    const locked = await tx.execute(sql`select id, org_id, program_id, capacity, status from ${schema.examCohorts} where id = ${cohortId} and org_id = ${orgId} for update`);
    const cohortRow = (locked.rows[0] ?? null) as { id: string; org_id: string; program_id: string; capacity: number; status: string } | null;
    if (!cohortRow) return { ok: false, reason: "Cohorte introuvable." };
    const [enr] = await tx
      .select({ orgId: schema.enrollments.orgId, status: schema.enrollments.status, programId: schema.programVersions.programId })
      .from(schema.enrollments)
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
      .leftJoin(schema.programVersions, eq(schema.programVersions.id, sql`coalesce(${schema.enrollments.programVersionId}, ${schema.trainingSessions.programVersionId})`))
      .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)))
      .limit(1);
    const [{ n }] = await tx.select({ n: sql<number>`count(*)::int` }).from(schema.examMembers).where(and(eq(schema.examMembers.cohortId, cohortId), eq(schema.examMembers.orgId, orgId)));
    const [dup] = await tx.select({ id: schema.examMembers.id }).from(schema.examMembers).where(and(eq(schema.examMembers.cohortId, cohortId), eq(schema.examMembers.enrollmentId, enrollmentId))).limit(1);
    const check = checkEligibility({
      cohort: { orgId: cohortRow.org_id, programId: cohortRow.program_id, capacity: cohortRow.capacity, status: cohortRow.status, membersCount: n },
      enrollment: enr ? { orgId: enr.orgId, programId: enr.programId ?? null, status: enr.status } : null,
      alreadyMember: Boolean(dup),
    });
    if (!check.ok) return check;
    const [m] = await tx.insert(schema.examMembers).values({ orgId, cohortId, enrollmentId, status: "inscrit", assignedBy: userId }).onConflictDoNothing().returning({ id: schema.examMembers.id });
    if (!m) return { ok: false, reason: "Cette inscription est déjà membre de la cohorte." };
    await tx.update(schema.enrollments).set({ examState: "inscrit", updatedAt: new Date() }).where(and(eq(schema.enrollments.id, enrollmentId), sql`${schema.enrollments.examState} in ('non_concerne','a_inscrire')`));
    return { ok: true, memberId: m.id };
  });
}

export async function renderConvocationPdf(input: {
  org: Org;
  person: { firstName: string; lastName: string };
  enrollment: { reference: string };
  cohort: Cohort;
  program: { title: string };
  site: { name: string; addressLine1: string | null; postalCode: string | null; city: string | null } | null;
  manager: { firstName: string; lastName: string } | null;
  blocks: { code: string; label: string }[];
  periods: { date: string; startTime: string; endTime: string; title: string }[];
}): Promise<Buffer> {
  const { doc, done } = newPdf(`Convocation ${input.enrollment.reference}`);
  writeOrgHeader(doc, input.org, "Convocation à l'examen");
  doc.font("Helvetica-Bold").fontSize(13).fillColor(INK).text(clean(`${input.person.firstName} ${input.person.lastName.toUpperCase()}`));
  doc.font("Helvetica").fontSize(9.5).fillColor(MUTED).text(clean(`Inscription ${input.enrollment.reference}`));
  doc.moveDown(0.8);
  doc.fillColor(INK).fontSize(10.5);
  para(doc, `Vous êtes convoqué(e) à l'examen « ${input.cohort.label} » (${input.cohort.code}) de la formation ${input.program.title}.`);
  section(doc, "Dates et lieu");
  para(doc, `Le ${fmtDate(input.cohort.date, "EEEE d MMMM yyyy")}${input.cohort.endDate && input.cohort.endDate !== input.cohort.date ? ` au ${fmtDate(input.cohort.endDate, "EEEE d MMMM yyyy")}` : ""}.`);
  para(doc, input.site ? `Lieu : ${input.site.name}${input.site.addressLine1 ? `, ${input.site.addressLine1}` : ""}${input.site.postalCode || input.site.city ? `, ${[input.site.postalCode, input.site.city].filter(Boolean).join(" ")}` : ""}` : null, "[À COMPLÉTER : lieu de l'examen]");
  if (input.manager) para(doc, `Responsable de la session d'examen : ${input.manager.firstName} ${input.manager.lastName}.`);
  section(doc, "Périmètre");
  if (input.cohort.scope === "complet") para(doc, "Examen complet (ensemble des blocs de compétences).");
  else if (input.blocks.length) for (const b of input.blocks) para(doc, `${b.code} : ${b.label}`);
  else para(doc, null, "[À COMPLÉTER : blocs concernés]");
  if (input.periods.length) {
    section(doc, "Annexe : planning du parcours");
    doc.font("Helvetica").fontSize(9).fillColor(INK);
    for (const p of input.periods) doc.text(clean(`${fmtDate(p.date, "EEE d MMM yyyy")} · ${p.startTime}-${p.endTime} · ${p.title}`), { lineGap: 1.5 });
  }
  section(doc, "Consignes");
  para(doc, "Présentez-vous muni(e) d'une pièce d'identité en cours de validité, au moins 15 minutes avant le début. Signalez tout besoin d'aménagement d'épreuve à l'organisme avant la date.");
  if (input.cohort.notes) para(doc, input.cohort.notes);
  doc.moveDown(1);
  para(doc, input.org.signatoryName ? `${input.org.signatoryName}${input.org.signatoryTitle ? `, ${input.org.signatoryTitle}` : ""}` : null, "[À COMPLÉTER : signataire]");
  writeFooter(doc, input.org, "Convocation (F08 / F09) : document généré, non signé");
  doc.end();
  return done;
}

/** Données des formulaires de cohorte (formations, sites, membres, blocs des certifications). */
export async function loadCohortFormData(orgId: string): Promise<Omit<CohortFormData, "cohort" | "defaultDate">> {
  const [programs, sites, members, certs] = await Promise.all([
    db.select({ id: schema.programs.id, title: schema.programs.title, code: schema.programs.code, certificationId: schema.programs.certificationId }).from(schema.programs).where(and(eq(schema.programs.orgId, orgId), inArray(schema.programs.status, ["actif", "brouillon"]))).orderBy(asc(schema.programs.title)),
    db.select({ id: schema.sites.id, name: schema.sites.name }).from(schema.sites).where(eq(schema.sites.orgId, orgId)).orderBy(asc(schema.sites.name)),
    db
      .select({ userId: schema.memberships.userId, firstName: schema.users.firstName, lastName: schema.users.lastName })
      .from(schema.memberships)
      .innerJoin(schema.users, eq(schema.users.id, schema.memberships.userId))
      .where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.active, true)))
      .orderBy(asc(schema.users.lastName)),
    db.select({ id: schema.certifications.id, blocks: schema.certifications.blocks }).from(schema.certifications).where(eq(schema.certifications.orgId, orgId)),
  ]);
  const blocks: CohortFormData["blocks"] = [];
  for (const p of programs) {
    const c = certs.find((x) => x.id === p.certificationId);
    for (const b of (c?.blocks ?? []) as { code: string; label: string }[]) blocks.push({ programId: p.id, code: b.code, label: b.label });
  }
  return { programs, sites, members: members.map((m) => ({ userId: m.userId, name: `${m.firstName} ${m.lastName}` })), blocks };
}
