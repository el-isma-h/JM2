import "server-only";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { assertEnrollmentInScope } from "@/server/authz";
import { readDocument } from "@/server/documents/store";
import { getVisibleDocument } from "@/server/documents/queries";
import type { Agent, AgentInput, ProposalDraft } from "../store";
import { redactString } from "../redact";
import { askJson, baseRationale, forbidden, requireEntity } from "./shared";

export type PiecesPayload = {
  documentId: string;
  enrollmentId: string;
  /** Pièce attendue proposée (soumission) ; null si aucune correspondance. */
  suggestedSubmissionId: string | null;
  suggestedLabel: string | null;
  confidence: "A" | "B" | "C";
  /** Incohérences détectées (nom, date, type de document). */
  inconsistencies: string[];
  textSource: "pdf" | "texte" | "metadonnees";
  excerpt: string;
};

/**
 * Extraction de texte : PDF via `pdf-parse` si le paquet est installé (import dynamique tolérant), fichiers texte en UTF-8,
 * sinon métadonnées (titre, nom de fichier, catégorie). Jamais d'image analysée ; le texte est minimisé avant tout prompt.
 */
export async function extractDocumentText(doc: { mimeType: string; title: string; fileName: string; category: string }, data: Buffer): Promise<{ text: string; source: PiecesPayload["textSource"] }> {
  if (doc.mimeType === "application/pdf") {
    try {
      const modName = "pdf-parse";
      const mod = (await import(/* webpackIgnore: true */ modName)) as { default?: (b: Buffer) => Promise<{ text: string }> } | ((b: Buffer) => Promise<{ text: string }>);
      const fn = typeof mod === "function" ? mod : mod.default;
      if (fn) {
        const r = await fn(data);
        if (r.text?.trim()) return { text: r.text.slice(0, 6000), source: "pdf" };
      }
    } catch {
      // pdf-parse absent ou PDF non textuel : repli sur les métadonnées.
    }
  }
  if (doc.mimeType.startsWith("text/")) return { text: data.toString("utf8").slice(0, 6000), source: "texte" };
  return { text: `Titre : ${doc.title}\nFichier : ${doc.fileName}\nCatégorie déclarée : ${doc.category}`, source: "metadonnees" };
}

const KEYWORDS: Record<string, RegExp> = {
  piece_identite: /carte nationale d'identit|passeport|titre de s[ée]jour|cni\b/i,
  cv: /curriculum|\bcv\b|exp[ée]riences? professionnelle/i,
  diplome: /dipl[ôo]me|baccalaur[ée]at|licence|master|\bbts\b|relev[ée] de notes/i,
  rib: /\briB\b|iban|relev[ée] d'identit[ée] bancaire/i,
  kbis: /kbis|extrait k\b|registre du commerce/i,
  convention: /convention de formation/i,
  contrat: /contrat d'apprentissage|contrat de professionnalisation|cerfa/i,
  justificatif: /certificat m[ée]dical|arr[êe]t de travail|justificatif/i,
  attestation: /attestation/i,
};

/** Classification déterministe par mots-clés sur le texte et le nom de fichier. */
export function classifyByKeywords(text: string, candidates: { id: string; label: string; category: string; code: string }[]): { id: string; score: number }[] {
  const hay = text.toLowerCase();
  return candidates
    .map((c) => {
      let score = 0;
      const re = KEYWORDS[c.category];
      if (re && re.test(hay)) score += 3;
      for (const w of c.label.toLowerCase().split(/[^a-zà-ÿ]+/).filter((w) => w.length > 3)) if (hay.includes(w)) score += 1;
      return { id: c.id, score };
    })
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score);
}

export function detectInconsistencies(text: string, person: { firstName: string; lastName: string; birthDate: string | null }): string[] {
  const out: string[] = [];
  const hay = text.toLowerCase();
  const hasName = hay.includes(person.lastName.toLowerCase()) || hay.includes(person.firstName.toLowerCase());
  if (text.length > 200 && !hasName) out.push(`Le nom de l'apprenant (${person.firstName} ${person.lastName}) n'apparaît pas dans le texte lu.`);
  if (person.birthDate && text.length > 200) {
    const [y, m, d] = person.birthDate.split("-");
    const fr = `${d}/${m}/${y}`;
    if (/\d{2}\/\d{2}\/\d{4}/.test(text) && !text.includes(fr)) out.push(`La date de naissance du dossier (${fr}) ne correspond à aucune date lue dans le document.`);
  }
  const years = [...text.matchAll(/\b(20\d{2})\b/g)].map((m) => Number(m[1]));
  const future = years.find((y) => y > new Date().getFullYear() + 1);
  if (future) out.push(`Une année future (${future}) apparaît dans le document.`);
  return out;
}

export const piecesAgent: Agent = {
  name: "pieces",
  label: "Lecture et classement d'une pièce",
  description: "Lit un document déposé, propose la pièce attendue correspondante et signale les incohérences (nom, date).",
  requires: "dossier.admin_docs.view",
  accepts: ["document"],
  async run(ctx: OrgContext, input: AgentInput): Promise<ProposalDraft> {
    const { entityId } = requireEntity(input, ["document"]);
    const visible = await getVisibleDocument(ctx, entityId);
    if (!visible) throw new Error("Document introuvable ou hors de vos habilitations.");
    // Jamais de pièce d'identité ; CV réservé à candidates.cv.view (notes sensibles).
    if (visible.category === "piece_identite" || (visible.category === "cv" && !ctx.permissions.has("candidates.cv.view"))) forbidden();
    if (!visible.enrollmentId) throw new Error("Ce document n'est rattaché à aucune inscription : impossible de le classer parmi les pièces attendues.");
    await assertEnrollmentInScope(ctx, visible.enrollmentId);
    const found = await readDocument(visible.id);
    if (!found) throw new Error("Fichier introuvable.");
    const doc = found.doc;
    const enrollmentId = visible.enrollmentId;
    const [row] = await db.select({ p: schema.persons, reference: schema.enrollments.reference }).from(schema.enrollments).innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId)).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, ctx.org.id))).limit(1);
    if (!row) throw new Error("Inscription introuvable.");
    const candidates = await db
      .select({ id: schema.pieceSubmissions.id, label: schema.requiredPieces.label, category: schema.requiredPieces.category, code: schema.requiredPieces.code, status: schema.pieceSubmissions.status })
      .from(schema.pieceSubmissions)
      .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
      .where(and(eq(schema.pieceSubmissions.orgId, ctx.org.id), eq(schema.pieceSubmissions.enrollmentId, enrollmentId), inArray(schema.pieceSubmissions.status, ["attendue", "refusee", "deposee"])));
    const { text, source } = await extractDocumentText(doc, found.data);
    const safeText = redactString(text);
    const ranked = classifyByKeywords(`${doc.fileName} ${doc.title} ${safeText}`, candidates);
    const inconsistencies = detectInconsistencies(safeText, { firstName: row.p.firstName, lastName: row.p.lastName, birthDate: row.p.birthDate });
    let best = ranked[0] ? candidates.find((c) => c.id === ranked[0].id)! : null;
    let confidence: PiecesPayload["confidence"] = ranked[0] && ranked[0].score >= 3 ? "B" : "C";
    const ai = candidates.length
      ? await askJson<{ submissionId?: string | null; confidence?: "A" | "B" | "C"; inconsistencies?: string[] }>(
          `Classe un document parmi des pièces attendues. Réponds en JSON : {"submissionId": string|null, "confidence": "A"|"B"|"C", "inconsistencies": string[]}. Choisis null si aucune pièce ne correspond clairement. Ne lis que le texte fourni ; n'invente rien.`,
          `Apprenant : ${row.p.firstName} ${row.p.lastName}\nPièces attendues : ${JSON.stringify(candidates.map((c) => ({ submissionId: c.id, label: c.label, category: c.category, status: c.status })))}\nDocument (source : ${source}) :\n${safeText.slice(0, 4000)}`,
        )
      : null;
    if (ai?.data?.submissionId && candidates.some((c) => c.id === ai.data!.submissionId)) {
      best = candidates.find((c) => c.id === ai.data!.submissionId)!;
      confidence = ai.data.confidence ?? "B";
    }
    const allInconsistencies = [...new Set([...inconsistencies, ...(Array.isArray(ai?.data?.inconsistencies) ? ai!.data!.inconsistencies : [])])];
    const payload: PiecesPayload = { documentId: doc.id, enrollmentId, suggestedSubmissionId: best?.id ?? null, suggestedLabel: best?.label ?? null, confidence, inconsistencies: allInconsistencies, textSource: source, excerpt: safeText.slice(0, 600) };
    return {
      agent: "pieces",
      kind: "piece_classement",
      title: best ? `Classer « ${doc.title} » comme « ${best.label} »` : `Aucune pièce attendue ne correspond à « ${doc.title} »`,
      summary: allInconsistencies.length ? `${allInconsistencies.length} incohérence(s) à examiner` : "Aucune incohérence détectée",
      entityType: "document",
      entityId: doc.id,
      payload: payload as unknown as Record<string, unknown>,
      rationale: baseRationale(
        [{ type: "document", id: doc.id, label: doc.title }, { type: "enrollment", id: enrollmentId, label: `Inscription ${row.reference}` }, { type: "pieces", label: `${candidates.length} pièce(s) attendue(s)` }],
        confidence,
        !ai,
        [source === "metadonnees" ? "Texte non extrait (pdf-parse absent ou document non textuel) : classement sur les métadonnées seulement." : `Texte extrait (${source}).`, "Validation = rattachement du document à la pièce (statut « déposée »), le contrôle humain d'acceptation reste à faire."],
        allInconsistencies,
      ),
      provider: ai?.result.provider ?? null,
      model: ai?.result.model ?? null,
    };
  },
};
