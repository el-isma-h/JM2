import "server-only";
import { and, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { myTaskCondition } from "@/server/tasks/queries";
import { OPEN_STATUSES } from "@/server/tasks/rules";
import type { Period } from "./period";

export type MetricUnit = "count" | "hours" | "cents";
export type Metric = {
  key: string;
  label: string;
  value: number;
  unit: MetricUnit;
  /** Liste qui compose l'indicateur (lien avec filtres). */
  href: string;
  /** Filtre appliqué, en clair. */
  filter: string;
  /** Période de référence, en clair (« inscriptions actives » = instantané). */
  scope: string;
  tone?: "danger" | "warn" | "ok" | "neutral";
};
export type MetricGroup = { key: string; title: string; description?: string; metrics: Metric[] };

const count = sql<number>`count(*)::int`;
const n = (v: number | null | undefined) => Number(v ?? 0) || 0;

/** Tableau de bord adapté au rôle (F15) : chaque indicateur renvoie vers la liste qui le compose. */
export async function dashboardMetrics(ctx: OrgContext, period: Period, today: string): Promise<{ groups: MetricGroup[]; updatedAt: Date }> {
  const orgId = ctx.org.id;
  const base = `/app/${orgId}`;
  const p = ctx.permissions;
  const has = (k: Parameters<typeof p.has>[0]) => p.has(k);
  const groups: MetricGroup[] = [];
  const snapshot = `au ${today.split("-").reverse().join("/")}`;
  const inPeriod = period.label;

  // ---------- Mes tâches (tout le monde) ----------
  {
    const [mine] = await db
      .select({ open: sql<number>`count(*) filter (where ${schema.tasks.status} in ('a_faire','en_cours','bloquee'))::int`, late: sql<number>`count(*) filter (where ${schema.tasks.status} in ('a_faire','en_cours','bloquee') and ${schema.tasks.dueDate} < ${today})::int`, blocked: sql<number>`count(*) filter (where ${schema.tasks.status} = 'bloquee')::int` })
      .from(schema.tasks)
      .where(and(eq(schema.tasks.orgId, orgId), myTaskCondition(ctx)));
    const metrics: Metric[] = [
      { key: "tasks_mine_open", label: "Mes tâches ouvertes", value: n(mine?.open), unit: "count", href: `${base}/taches`, filter: "affectées à moi ou à mes rôles, statut à faire, en cours ou bloquée", scope: snapshot },
      { key: "tasks_mine_late", label: "Mes tâches en retard", value: n(mine?.late), unit: "count", href: `${base}/taches?late=1`, filter: "échéance strictement passée", scope: snapshot, tone: n(mine?.late) ? "danger" : "ok" },
      { key: "tasks_mine_blocked", label: "Bloquées", value: n(mine?.blocked), unit: "count", href: `${base}/taches?status=bloquee`, filter: "statut bloquée (motif visible)", scope: snapshot, tone: n(mine?.blocked) ? "warn" : "neutral" },
    ];
    if (has("tasks.view_all")) {
      const [all] = await db
        .select({ late: sql<number>`count(*) filter (where ${schema.tasks.dueDate} < ${today})::int`, unassigned: sql<number>`count(*) filter (where ${schema.tasks.assigneeUserId} is null and ${schema.tasks.assigneeRole} is null)::int` })
        .from(schema.tasks)
        .where(and(eq(schema.tasks.orgId, orgId), inArray(schema.tasks.status, OPEN_STATUSES)));
      metrics.push(
        { key: "tasks_all_late", label: "Tâches en retard (organisme)", value: n(all?.late), unit: "count", href: `${base}/taches/supervision?late=1`, filter: "toutes tâches ouvertes, échéance passée", scope: snapshot, tone: n(all?.late) ? "danger" : "ok" },
        { key: "tasks_unassigned", label: "Tâches à affecter", value: n(all?.unassigned), unit: "count", href: `${base}/taches/supervision?unassigned=1`, filter: "sans responsable ni rôle", scope: snapshot, tone: n(all?.unassigned) ? "warn" : "neutral" },
      );
    }
    groups.push({ key: "taches", title: "Tâches et relais", metrics });
  }

  // ---------- Formateur : ses séances du jour ----------
  if (ctx.trainerId) {
    const [r] = await db
      .select({ today: sql<number>`count(*) filter (where ${schema.slots.date} = ${today})::int`, week: sql<number>`count(*) filter (where ${schema.slots.date} between ${today} and (${today}::date + 6))::int`, toClose: sql<number>`count(*) filter (where ${schema.slots.date} < ${today} and ${schema.periods.status} in ('prevue','ouverte'))::int` })
      .from(schema.periods)
      .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
      .where(and(eq(schema.periods.orgId, orgId), inArray(schema.slots.status, ["prevue", "confirmee"]), inArray(schema.periods.status, ["prevue", "ouverte", "cloturee"]), sql`coalesce(${schema.periods.trainerId}, ${schema.slots.trainerId}) = ${ctx.trainerId}`));
    groups.push({
      key: "formateur",
      title: "Mes séances",
      metrics: [
        { key: "trainer_today", label: "Périodes aujourd'hui", value: n(r?.today), unit: "count", href: `${base}/agenda?view=semaine&d=${today}`, filter: "périodes où je suis formateur, date du jour", scope: snapshot },
        { key: "trainer_week", label: "Périodes sous 7 jours", value: n(r?.week), unit: "count", href: `${base}/agenda?view=semaine&d=${today}`, filter: "périodes où je suis formateur, 7 prochains jours", scope: snapshot },
        { key: "trainer_toclose", label: "Émargements à clôturer", value: n(r?.toClose), unit: "count", href: `${base}/emargement?horizon=passe`, filter: "périodes passées non clôturées, où je suis formateur", scope: snapshot, tone: n(r?.toClose) ? "warn" : "ok" },
      ],
    });
  }
  if (ctx.trainerOnly) return { groups, updatedAt: new Date() };

  // ---------- Direction / agence : candidatures, placements, inscriptions ----------
  if (has("crm.view") || has("enrollments.view")) {
    const metrics: Metric[] = [];
    if (has("crm.view")) {
      const [c] = await db.select({ candidates: sql<number>`count(*) filter (where ${schema.persons.status} = 'candidat')::int` }).from(schema.persons).where(eq(schema.persons.orgId, orgId));
      const [pl] = await db
        .select({ open: sql<number>`count(*) filter (where ${schema.placements.status} in ('propose','entretien','retenu'))::int`, placed: sql<number>`count(*) filter (where ${schema.placements.status} = 'place' and ${schema.placements.decidedAt} >= ${period.from}::date and ${schema.placements.decidedAt} < (${period.to}::date + 1))::int` })
        .from(schema.placements)
        .where(eq(schema.placements.orgId, orgId));
      const [needs] = await db.select({ open: sql<number>`count(*) filter (where ${schema.needs.stage} in ('nouveau','qualifie','proposition','negociation'))::int` }).from(schema.needs).where(eq(schema.needs.orgId, orgId));
      metrics.push(
        { key: "candidates", label: "Candidats", value: n(c?.candidates), unit: "count", href: `${base}/candidats?status=candidat`, filter: "personnes au statut candidat", scope: snapshot },
        { key: "placements_open", label: "Placements en cours", value: n(pl?.open), unit: "count", href: `${base}/candidats?placement=en_cours`, filter: "placements proposés, en entretien ou retenus", scope: snapshot },
        { key: "placements_done", label: "Placements réalisés", value: n(pl?.placed), unit: "count", href: `${base}/candidats?placement=place&from=${period.from}&to=${period.to}`, filter: "placements au statut placé, décision dans la période", scope: inPeriod },
        { key: "needs_open", label: "Besoins en cours", value: n(needs?.open), unit: "count", href: `${base}/besoins`, filter: "besoins non gagnés ni perdus", scope: snapshot },
      );
    }
    if (has("enrollments.view")) {
      const [e] = await db
        .select({ active: sql<number>`count(*) filter (where ${schema.enrollments.status} in ('inscrit','en_cours'))::int`, pre: sql<number>`count(*) filter (where ${schema.enrollments.status} = 'preinscrit')::int`, started: sql<number>`count(*) filter (where ${schema.enrollments.startDate} between ${period.from} and ${period.to})::int` })
        .from(schema.enrollments)
        .where(eq(schema.enrollments.orgId, orgId));
      metrics.push(
        { key: "enrollments_active", label: "Inscriptions actives", value: n(e?.active), unit: "count", href: `${base}/inscriptions?statut=actives`, filter: "statut inscrit ou en cours", scope: snapshot },
        { key: "enrollments_pre", label: "Préinscriptions", value: n(e?.pre), unit: "count", href: `${base}/inscriptions?statut=preinscrit`, filter: "statut préinscrit", scope: snapshot },
        { key: "enrollments_started", label: "Entrées en formation", value: n(e?.started), unit: "count", href: `${base}/inscriptions?du=${period.from}&au=${period.to}`, filter: "date de début du parcours dans la période", scope: inPeriod },
      );
    }
    groups.push({ key: "activite", title: "Candidatures, placements et inscriptions", metrics });
  }

  // ---------- Administratif : pièces, convocations, documents ----------
  if (has("dossier.admin_docs.view") || has("documents.view")) {
    const metrics: Metric[] = [];
    if (has("dossier.admin_docs.view")) {
      const [pc] = await db
        .select({ missing: sql<number>`count(*) filter (where ${schema.pieceSubmissions.status} in ('attendue','refusee') and ${schema.enrollments.status} in ('preinscrit','inscrit','en_cours'))::int`, toReview: sql<number>`count(*) filter (where ${schema.pieceSubmissions.status} = 'deposee')::int`, late: sql<number>`count(*) filter (where ${schema.pieceSubmissions.status} in ('attendue','refusee') and ${schema.pieceSubmissions.dueDate} < ${today})::int` })
        .from(schema.pieceSubmissions)
        .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.pieceSubmissions.enrollmentId))
        .where(eq(schema.pieceSubmissions.orgId, orgId));
      metrics.push(
        { key: "pieces_missing", label: "Pièces manquantes", value: n(pc?.missing), unit: "count", href: `${base}/pieces?statut=attendue`, filter: "pièces attendues ou refusées, inscriptions non closes", scope: snapshot, tone: n(pc?.missing) ? "warn" : "ok" },
        { key: "pieces_late", label: "Pièces en retard", value: n(pc?.late), unit: "count", href: `${base}/pieces?statut=attendue&retard=1`, filter: "date limite dépassée", scope: snapshot, tone: n(pc?.late) ? "danger" : "ok" },
        { key: "pieces_review", label: "Pièces à contrôler", value: n(pc?.toReview), unit: "count", href: `${base}/pieces?statut=deposee`, filter: "pièces déposées, non encore acceptées", scope: snapshot },
      );
    }
    if (has("documents.view")) {
      const [d] = await db
        .select({ convocations: sql<number>`count(*) filter (where ${schema.documents.category} = 'convocation' and ${schema.documents.status} = 'genere')::int`, toSend: sql<number>`count(*) filter (where ${schema.documents.status} = 'genere' and ${schema.documents.category} in ('convention','contrat','cerfa','convocation','attestation','certificat_realisation'))::int`, toSign: sql<number>`count(*) filter (where ${schema.documents.status} = 'transmis' and ${schema.documents.category} in ('convention','contrat','cerfa'))::int` })
        .from(schema.documents)
        .where(eq(schema.documents.orgId, orgId));
      metrics.push(
        { key: "convocations", label: "Convocations à transmettre", value: n(d?.convocations), unit: "count", href: `${base}/documents?category=convocation&status=genere`, filter: "convocations générées, non transmises", scope: snapshot },
        { key: "docs_to_send", label: "Documents à transmettre", value: n(d?.toSend), unit: "count", href: `${base}/documents?status=genere`, filter: "conventions, contrats, CERFA, convocations, attestations générés non transmis", scope: snapshot },
        { key: "docs_to_sign", label: "En attente de signature", value: n(d?.toSign), unit: "count", href: `${base}/signatures?status=envoyee`, filter: "conventions, contrats et CERFA transmis non signés", scope: snapshot },
      );
    }
    groups.push({ key: "administratif", title: "Pièces et documents", metrics });
  }

  // ---------- Pédagogie : séances du jour, émargements, évaluations, heures, absences ----------
  if (has("planning.view") || has("attendance.record")) {
    const [s] = await db
      .select({ today: sql<number>`count(*) filter (where ${schema.slots.date} = ${today})::int`, toClose: sql<number>`count(*) filter (where ${schema.slots.date} < ${today} and ${schema.periods.status} in ('prevue','ouverte'))::int` })
      .from(schema.periods)
      .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
      .where(and(eq(schema.periods.orgId, orgId), inArray(schema.slots.status, ["prevue", "confirmee"]), inArray(schema.periods.status, ["prevue", "ouverte", "cloturee"])));
    const [h] = await db
      .select({
        done: sql<number>`coalesce(sum(${schema.attendances.minutesCounted}) filter (where ${schema.attendances.isCurrent}), 0)::int`,
        validated: sql<number>`coalesce(sum(${schema.attendances.minutesCounted}) filter (where ${schema.attendances.isCurrent} and ${schema.periods.status} = 'cloturee'), 0)::int`,
        absences: sql<number>`count(*) filter (where ${schema.attendances.isCurrent} and ${schema.attendances.status} = 'absent')::int`,
        justified: sql<number>`count(*) filter (where ${schema.attendances.isCurrent} and ${schema.attendances.status} = 'absent_justifie')::int`,
      })
      .from(schema.attendances)
      .innerJoin(schema.periods, eq(schema.periods.id, schema.attendances.periodId))
      .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
      .where(and(eq(schema.attendances.orgId, orgId), gte(schema.slots.date, period.from), lte(schema.slots.date, period.to)));
    const [planned] = await db.select({ h: sql<number>`coalesce(sum(${schema.enrollments.hoursPlanned}), 0)::int` }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.status, ["inscrit", "en_cours"])));
    const metrics: Metric[] = [
      { key: "slots_today", label: "Périodes aujourd'hui", value: n(s?.today), unit: "count", href: `${base}/planning?date=${today}`, filter: "périodes planifiées, date du jour", scope: snapshot },
      { key: "periods_to_close", label: "Émargements à clôturer", value: n(s?.toClose), unit: "count", href: `${base}/emargement?horizon=passe`, filter: "périodes passées non clôturées", scope: snapshot, tone: n(s?.toClose) ? "warn" : "ok" },
      { key: "hours_planned", label: "Heures prévues", value: n(planned?.h) * 60, unit: "hours", href: `${base}/inscriptions?statut=actives`, filter: "somme des heures prévues des inscriptions actives (jamais additionnées aux heures réalisées)", scope: snapshot },
      { key: "hours_done", label: "Heures réalisées", value: n(h?.done), unit: "hours", href: `${base}/emargement?horizon=passe`, filter: "minutes comptées des présences courantes, séances de la période", scope: inPeriod },
      { key: "hours_validated", label: "Heures validées", value: n(h?.validated), unit: "hours", href: `${base}/emargement?horizon=passe`, filter: "présences de périodes clôturées uniquement", scope: inPeriod },
      { key: "absences", label: "Absences", value: n(h?.absences), unit: "count", href: `${base}/emargement?horizon=passe`, filter: "présences au statut absent (non justifié)", scope: inPeriod, tone: n(h?.absences) ? "warn" : "neutral" },
      { key: "absences_justified", label: "Absences justifiées", value: n(h?.justified), unit: "count", href: `${base}/emargement?horizon=passe`, filter: "présences au statut absent justifié", scope: inPeriod },
    ];
    if (has("dossier.pedagogy.view")) {
      const [ev] = await db.select({ pending: sql<number>`count(*) filter (where ${schema.evaluations.result} = 'non_evalue' and ${schema.evaluations.date} <= ${today})::int` }).from(schema.evaluations).where(eq(schema.evaluations.orgId, orgId));
      metrics.push({ key: "evaluations_pending", label: "Évaluations en attente", value: n(ev?.pending), unit: "count", href: `${base}/evaluations`, filter: "évaluations datées non évaluées", scope: snapshot });
    }
    groups.push({ key: "pedagogie", title: "Séances, heures et absences", description: "Heures prévues, réalisées et validées sont distinctes et ne s'additionnent jamais.", metrics });
  }

  // ---------- Examens ----------
  if (has("exams.view")) {
    const [x] = await db.select({ upcoming: sql<number>`count(*) filter (where ${schema.examCohorts.date} >= ${today} and ${schema.examCohorts.status} <> 'annulee')::int` }).from(schema.examCohorts).where(eq(schema.examCohorts.orgId, orgId));
    const [m] = await db.select({ toRegister: sql<number>`count(*) filter (where ${schema.enrollments.examState} = 'a_inscrire' and ${schema.enrollments.status} in ('inscrit','en_cours'))::int` }).from(schema.enrollments).where(eq(schema.enrollments.orgId, orgId));
    groups.push({
      key: "examens",
      title: "Examens",
      metrics: [
        { key: "cohorts_upcoming", label: "Cohortes à venir", value: n(x?.upcoming), unit: "count", href: `${base}/examens`, filter: "cohortes datées aujourd'hui ou après, non annulées", scope: snapshot },
        { key: "exam_to_register", label: "Candidats à inscrire", value: n(m?.toRegister), unit: "count", href: `${base}/inscriptions?examen=a_inscrire`, filter: "inscriptions actives à l'état examen « à inscrire »", scope: snapshot, tone: n(m?.toRegister) ? "warn" : "neutral" },
      ],
    });
  }

  // ---------- Finance ----------
  if (has("finance.view")) {
    const [inv] = await db
      .select({
        late: sql<number>`count(*) filter (where (${schema.invoices.status} = 'en_retard' or (${schema.invoices.status} in ('emise','envoyee','partiellement_payee') and ${schema.invoices.dueDate} < ${today})))::int`,
        lateCents: sql<number>`coalesce(sum(${schema.invoices.totalTtcCents} - ${schema.invoices.paidCents}) filter (where (${schema.invoices.status} = 'en_retard' or (${schema.invoices.status} in ('emise','envoyee','partiellement_payee') and ${schema.invoices.dueDate} < ${today}))), 0)::bigint`,
        issued: sql<number>`coalesce(sum(${schema.invoices.totalHtCents}) filter (where ${schema.invoices.kind} = 'facture' and ${schema.invoices.status} not in ('brouillon','annulee') and ${schema.invoices.issueDate} between ${period.from} and ${period.to}), 0)::bigint`,
      })
      .from(schema.invoices)
      .where(eq(schema.invoices.orgId, orgId));
    const [pay] = await db.select({ cents: sql<number>`coalesce(sum(${schema.payments.amountCents}), 0)::bigint` }).from(schema.payments).where(and(eq(schema.payments.orgId, orgId), gte(schema.payments.date, period.from), lte(schema.payments.date, period.to)));
    const [fund] = await db.select({ granted: sql<number>`coalesce(sum(${schema.fundings.amountCents}) filter (where ${schema.fundings.status} = 'accorde'), 0)::bigint`, grantedCount: sql<number>`count(*) filter (where ${schema.fundings.status} = 'accorde')::int`, pending: sql<number>`count(*) filter (where ${schema.fundings.status} in ('prevu','demande'))::int` }).from(schema.fundings).where(eq(schema.fundings.orgId, orgId));
    groups.push({
      key: "finance",
      title: "Financements et encaissements",
      metrics: [
        { key: "invoices_late", label: "Factures en retard", value: n(inv?.late), unit: "count", href: `${base}/factures?status=en_retard`, filter: "factures émises ou envoyées, échéance dépassée, non soldées", scope: snapshot, tone: n(inv?.late) ? "danger" : "ok" },
        { key: "invoices_late_cents", label: "Reste à encaisser en retard", value: n(inv?.lateCents), unit: "cents", href: `${base}/factures?status=en_retard`, filter: "montant TTC restant dû des factures en retard", scope: snapshot },
        { key: "invoiced", label: "Facturé HT", value: n(inv?.issued), unit: "cents", href: `${base}/factures?from=${period.from}&to=${period.to}`, filter: "factures (hors avoirs, brouillons, annulées) émises dans la période", scope: inPeriod },
        { key: "payments", label: "Encaissements", value: n(pay?.cents), unit: "cents", href: `${base}/factures?from=${period.from}&to=${period.to}`, filter: "règlements datés dans la période", scope: inPeriod },
        { key: "fundings_granted", label: "Financements accordés non facturés", value: n(fund?.granted), unit: "cents", href: `${base}/financements?status=accorde`, filter: `${n(fund?.grantedCount)} accord(s) au statut accordé, pas encore facturés`, scope: snapshot },
        { key: "fundings_pending", label: "Financements à confirmer", value: n(fund?.pending), unit: "count", href: `${base}/financements?status=a_confirmer`, filter: "financements prévus ou demandés", scope: snapshot, tone: n(fund?.pending) ? "warn" : "neutral" },
      ],
    });
  }

  // ---------- Qualité ----------
  if (has("quality.view")) {
    const [ref] = await db.select({ criteria: schema.referentials.criteria }).from(schema.referentials).where(and(eq(schema.referentials.orgId, orgId), eq(schema.referentials.status, "actif"))).limit(1);
    const codes = new Set<string>();
    if (ref && Array.isArray(ref.criteria)) {
      for (const c of ref.criteria as { indicators?: { code?: string }[] }[]) for (const i of c.indicators ?? []) if (i.code) codes.add(i.code);
    }
    const proven = await db.selectDistinct({ code: schema.qualityEvidences.indicatorCode }).from(schema.qualityEvidences).where(and(eq(schema.qualityEvidences.orgId, orgId), eq(schema.qualityEvidences.status, "valide")));
    const provenSet = new Set(proven.map((r) => r.code));
    const missing = [...codes].filter((c) => !provenSet.has(c)).length;
    const [ev] = await db.select({ n: count }).from(schema.qualityEvidences).where(and(eq(schema.qualityEvidences.orgId, orgId), eq(schema.qualityEvidences.status, "valide"), gte(schema.qualityEvidences.createdAt, new Date(`${period.from}T00:00:00Z`)), lte(schema.qualityEvidences.createdAt, new Date(`${period.to}T23:59:59Z`))));
    const [act] = await db.select({ open: sql<number>`count(*) filter (where ${schema.qualityActions.status} in ('a_faire','en_cours'))::int`, late: sql<number>`count(*) filter (where ${schema.qualityActions.status} in ('a_faire','en_cours') and ${schema.qualityActions.dueDate} < ${today})::int` }).from(schema.qualityActions).where(eq(schema.qualityActions.orgId, orgId));
    const [cp] = await db.select({ open: sql<number>`count(*) filter (where ${schema.complaints.status} in ('recue','en_cours'))::int` }).from(schema.complaints).where(eq(schema.complaints.orgId, orgId));
    const [sv] = await db.select({ pending: sql<number>`count(*) filter (where ${schema.surveyResponses.sentAt} is not null and ${schema.surveyResponses.submittedAt} is null)::int` }).from(schema.surveyResponses).where(eq(schema.surveyResponses.orgId, orgId));
    groups.push({
      key: "qualite",
      title: "Preuves et actions qualité",
      description: codes.size ? undefined : "Aucun référentiel actif validé : les indicateurs sans preuve ne peuvent pas être calculés.",
      metrics: [
        { key: "indicators_missing", label: "Indicateurs sans preuve", value: missing, unit: "count", href: `${base}/qualite`, filter: codes.size ? `sur ${codes.size} indicateurs du référentiel actif, aucune preuve valide` : "aucun référentiel actif", scope: snapshot, tone: missing ? "warn" : codes.size ? "ok" : "neutral" },
        { key: "evidences", label: "Preuves enregistrées", value: n(ev?.n), unit: "count", href: `${base}/qualite/preuves`, filter: "preuves valides créées dans la période", scope: inPeriod },
        { key: "quality_actions", label: "Actions qualité ouvertes", value: n(act?.open), unit: "count", href: `${base}/qualite/actions?statut=en_cours`, filter: `${n(act?.late)} en retard`, scope: snapshot, tone: n(act?.late) ? "danger" : "neutral" },
        { key: "complaints", label: "Réclamations ouvertes", value: n(cp?.open), unit: "count", href: `${base}/qualite/actions?reclamation=en_cours`, filter: "réclamations reçues ou en cours", scope: snapshot, tone: n(cp?.open) ? "warn" : "ok" },
        { key: "surveys_pending", label: "Enquêtes sans réponse", value: n(sv?.pending), unit: "count", href: `${base}/enquetes`, filter: "questionnaires envoyés, non soumis", scope: snapshot },
      ],
    });
  }

  return { groups, updatedAt: new Date() };
}

/** Séries mensuelles pour le pilotage détaillé (graphiques sobres). */
export async function monthlySeries(ctx: OrgContext, months: string[]): Promise<{ month: string; entrees: number; heures: number; encaissements: number; absences: number }[]> {
  const orgId = ctx.org.id;
  if (!months.length) return [];
  const from = `${months[0]}-01`;
  const last = months[months.length - 1];
  const to = `${last}-31`;
  const p = ctx.permissions;
  const out = months.map((m) => ({ month: m, entrees: 0, heures: 0, encaissements: 0, absences: 0 }));
  const idx = new Map(months.map((m, i) => [m, i]));
  if (p.has("enrollments.view")) {
    const rows = await db.select({ m: sql<string>`to_char(${schema.enrollments.startDate}, 'YYYY-MM')`, n: count }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), gte(schema.enrollments.startDate, from), lte(schema.enrollments.startDate, to))).groupBy(sql`1`);
    for (const r of rows) {
      const i = idx.get(r.m);
      if (i !== undefined) out[i].entrees = n(r.n);
    }
  }
  if (p.has("planning.view") || p.has("attendance.record")) {
    const rows = await db
      .select({ m: sql<string>`to_char(${schema.slots.date}, 'YYYY-MM')`, minutes: sql<number>`coalesce(sum(${schema.attendances.minutesCounted}), 0)::int`, absences: sql<number>`count(*) filter (where ${schema.attendances.status} = 'absent')::int` })
      .from(schema.attendances)
      .innerJoin(schema.periods, eq(schema.periods.id, schema.attendances.periodId))
      .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
      .where(and(eq(schema.attendances.orgId, orgId), eq(schema.attendances.isCurrent, true), gte(schema.slots.date, from), lte(schema.slots.date, to)))
      .groupBy(sql`1`);
    for (const r of rows) {
      const i = idx.get(r.m);
      if (i !== undefined) {
        out[i].heures = Math.round(n(r.minutes) / 60);
        out[i].absences = n(r.absences);
      }
    }
  }
  if (p.has("finance.view")) {
    const rows = await db.select({ m: sql<string>`to_char(${schema.payments.date}, 'YYYY-MM')`, cents: sql<number>`coalesce(sum(${schema.payments.amountCents}), 0)::bigint` }).from(schema.payments).where(and(eq(schema.payments.orgId, orgId), gte(schema.payments.date, from), lte(schema.payments.date, to))).groupBy(sql`1`);
    for (const r of rows) {
      const i = idx.get(r.m);
      if (i !== undefined) out[i].encaissements = Math.round(n(r.cents) / 100);
    }
  }
  return out;
}

/** Objectifs de la période : affichés à côté des indicateurs, jamais comme un résultat mesuré. */
export async function objectivesFor(orgId: string, period: Period) {
  return db
    .select()
    .from(schema.objectives)
    .where(and(eq(schema.objectives.orgId, orgId), lte(schema.objectives.periodStart, period.to), gte(schema.objectives.periodEnd, period.from)))
    .orderBy(schema.objectives.periodStart, schema.objectives.metric);
}
