/** Périodes de pilotage (module pur). Dates ISO Europe/Paris. */
import { addDays, addMonths, endOfMonth, endOfYear, format, parseISO, startOfMonth, startOfYear, subMonths } from "date-fns";
import { fr } from "date-fns/locale";

export type Period = { key: string; from: string; to: string; label: string };

const iso = (d: Date) => format(d, "yyyy-MM-dd");

export const PERIOD_PRESETS = [
  { key: "mois", label: "Mois en cours" },
  { key: "mois_precedent", label: "Mois précédent" },
  { key: "trimestre", label: "Trimestre en cours" },
  { key: "annee", label: "Année civile" },
  { key: "12_mois", label: "12 derniers mois" },
  { key: "personnalise", label: "Personnalisée" },
] as const;

export function resolvePeriod(sp: Record<string, string | string[] | undefined>, todayIso: string): Period {
  const one = (k: string) => {
    const v = sp[k];
    const s = Array.isArray(v) ? v[0] : v;
    return s?.trim() || undefined;
  };
  const today = parseISO(todayIso);
  const key = one("periode") ?? "mois";
  const from = one("from");
  const to = one("to");
  const DAY = /^\d{4}-\d{2}-\d{2}$/;
  if (key === "personnalise" && from && to && DAY.test(from) && DAY.test(to) && from <= to) {
    return { key, from, to, label: `du ${format(parseISO(from), "d MMM yyyy", { locale: fr })} au ${format(parseISO(to), "d MMM yyyy", { locale: fr })}` };
  }
  if (key === "mois_precedent") {
    const m = subMonths(today, 1);
    return { key, from: iso(startOfMonth(m)), to: iso(endOfMonth(m)), label: format(m, "MMMM yyyy", { locale: fr }) };
  }
  if (key === "trimestre") {
    const q = Math.floor(today.getMonth() / 3);
    const start = new Date(today.getFullYear(), q * 3, 1);
    const end = endOfMonth(addMonths(start, 2));
    return { key, from: iso(start), to: iso(end), label: `${q + 1}e trimestre ${today.getFullYear()}` };
  }
  if (key === "annee") return { key, from: iso(startOfYear(today)), to: iso(endOfYear(today)), label: `année ${today.getFullYear()}` };
  if (key === "12_mois") return { key, from: iso(addDays(subMonths(today, 12), 1)), to: todayIso, label: "12 derniers mois" };
  return { key: "mois", from: iso(startOfMonth(today)), to: iso(endOfMonth(today)), label: format(today, "MMMM yyyy", { locale: fr }) };
}

/** Mois ISO (YYYY-MM) couverts par une période, pour les séries de graphiques. */
export function monthsOf(period: Period): string[] {
  const out: string[] = [];
  let d = startOfMonth(parseISO(period.from));
  const end = parseISO(period.to);
  while (d <= end && out.length < 36) {
    out.push(format(d, "yyyy-MM"));
    d = addMonths(d, 1);
  }
  return out;
}

export function monthShort(ym: string): string {
  return format(parseISO(`${ym}-01`), "MMM yy", { locale: fr });
}
