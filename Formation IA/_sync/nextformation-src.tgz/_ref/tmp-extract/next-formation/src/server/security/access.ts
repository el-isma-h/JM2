import "server-only";
import { AuthError } from "@/server/auth";
import { requireOwner, type OrgContext } from "@/server/authz";
import { handleAuthError } from "@/server/guard";
import { canAdministerSecurity } from "./rules";

/**
 * S01 : administration de la sécurité réservée au propriétaire actif, avec session renforcée.
 * Vérifié côté serveur à chaque action, indépendamment du menu et des permissions users.manage / roles.manage / audit.view.
 */
export async function requireSecurityAdmin(orgId: string, opts: { elevated?: boolean } = { elevated: true }): Promise<OrgContext> {
  const ctx = await requireOwner(orgId);
  if (!canAdministerSecurity(ctx)) throw new AuthError("forbidden");
  if (opts.elevated !== false && !ctx.user.elevated) throw new AuthError("elevation_required");
  return ctx;
}

/** Variante page : redirige (connexion, vérification renforcée) ou renvoie 404 pour un non-propriétaire. */
export async function guardSecurityAdmin(orgId: string, nextPath: string, opts: { elevated?: boolean } = { elevated: true }): Promise<OrgContext> {
  try {
    return await requireSecurityAdmin(orgId, opts);
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}
