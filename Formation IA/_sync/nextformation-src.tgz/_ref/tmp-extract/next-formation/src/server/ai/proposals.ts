/**
 * Cycle de vie des propositions IA (module pur, testé dans __tests__/proposals.test.ts).
 *
 *   proposee ──valider──▶ validee ──appliquer──▶ appliquee
 *   proposee ──refuser──▶ refusee
 *   proposee ──expirer──▶ expiree
 *   validee  ──refuser──▶ refusee   (refus possible tant que rien n'a été appliqué)
 *
 * Une proposition n'a jamais d'effet avant `validee`, et l'effet n'est exécuté qu'une fois (`appliquee`).
 */

export type ProposalStatus = "proposee" | "validee" | "refusee" | "appliquee" | "expiree";
export type ProposalEvent = "valider" | "refuser" | "appliquer" | "expirer";

export type Certainty = "A" | "B" | "C";

export const CERTAINTY_LABELS: Record<Certainty, string> = {
  A: "A : établi à partir des données du dossier",
  B: "B : déduit, à vérifier",
  C: "C : hypothèse, à confirmer par un humain",
};

/** Explication jointe à toute proposition : sources consultées, règles, niveau de certitude. */
export type Rationale = {
  sources: { type: string; id?: string | null; label: string }[];
  rules?: string[];
  certainty: Certainty;
  notes?: string[];
  /** Vrai si la proposition a été construite sans modèle (déterministe). */
  deterministic?: boolean;
};

export type AgentName = "documents" | "pieces" | "relances" | "qualite" | "programme" | "planning" | "dossier" | "modeles";

export const AGENT_LABELS: Record<AgentName, string> = {
  documents: "Pré-remplissage de document",
  pieces: "Lecture et classement d'une pièce",
  relances: "Rédaction de relance",
  qualite: "Synthèse qualité explicable",
  programme: "Proposition de programme",
  planning: "Proposition de calendrier",
  dossier: "Résumé de dossier",
  modeles: "Rédaction de modèle d'e-mail",
};

const TRANSITIONS: Record<ProposalStatus, Partial<Record<ProposalEvent, ProposalStatus>>> = {
  proposee: { valider: "validee", refuser: "refusee", expirer: "expiree" },
  validee: { appliquer: "appliquee", refuser: "refusee" },
  refusee: {},
  appliquee: {},
  expiree: {},
};

export type TransitionResult = { ok: true; status: ProposalStatus } | { ok: false; reason: string };

/** Transition d'état : refuse tout ce qui n'est pas prévu, avec un motif lisible. */
export function transitionProposal(current: ProposalStatus, event: ProposalEvent): TransitionResult {
  const next = TRANSITIONS[current]?.[event];
  if (!next) {
    const reasons: Record<ProposalStatus, string> = {
      proposee: "Cette proposition doit d'abord être validée.",
      validee: "Cette proposition est déjà validée.",
      refusee: "Cette proposition a été refusée : elle ne peut plus changer d'état.",
      appliquee: "Cette proposition a déjà été appliquée : aucun second effet n'est possible.",
      expiree: "Cette proposition a expiré : relancez l'agent pour en obtenir une nouvelle.",
    };
    return { ok: false, reason: reasons[current] };
  }
  return { ok: true, status: next };
}

/** Une proposition peut-elle encore être décidée par un humain ? */
export function isDecidable(status: ProposalStatus): boolean {
  return status === "proposee";
}

/** Une proposition est-elle prête à produire son effet ? */
export function isApplicable(status: ProposalStatus): boolean {
  return status === "validee";
}

/** Durée de validité d'une proposition (jours) avant expiration automatique. */
export const PROPOSAL_TTL_DAYS = 30;

export function isExpired(createdAt: Date, now: Date, ttlDays = PROPOSAL_TTL_DAYS): boolean {
  return now.getTime() - createdAt.getTime() > ttlDays * 86400_000;
}
