import "server-only";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { timeParis, todayParis } from "@/lib/time";
import type { DemoResult } from "./seed";
import { makeRng } from "./data/util";
import { phaseBase } from "./data/phase-base";
import { phaseCrm } from "./data/phase-crm";
import { phasePlanning } from "./data/phase-planning";
import { phaseAttendanceSheets, phaseDocuments } from "./data/phase-docs";
import { phaseFinance, phasePieces, phaseSignatures } from "./data/phase-admin";
import { phaseQuality } from "./data/phase-quality";
import { phaseTasks } from "./data/phase-tasks";
import type { State } from "./data/state";

/** Résumé renvoyé au script de vérification (identifiants des dossiers emblématiques). */
export type DemoContentSummary = {
  durationMs: number;
  counts: Record<string, number>;
  today: string;
  splitDate: string;
  witnessDay: string;
  inesEnrollmentId: string;
  inesReference: string;
  titreProSessionId: string;
  btsSessionId: string;
  witnessEnrollmentIds: [string, string];
  cohorts: { arhA: string; btsBlanc: string };
  analysisIds: { old: string; recent: string };
  invalidatedEvidenceId: string;
};

/**
 * Contenu de démonstration de l'organisme « Atelier Méridien Formation » (OF + CFA) : sites, CRM, catalogue,
 * sessions, inscriptions, pièces, planning et émargements, examens, documents réels, finance, qualité, tâches.
 * Données fictives, cohérentes et relatives à la date du jour (sessions « en cours » autour d'aujourd'hui).
 * Idempotent par espace de démonstration : chaque appel de seedDemo() crée un organisme neuf ; les relais
 * passent par createTaskOnce (clé d'idempotence). Objectif : moins de 20 secondes (insertions par lots).
 */
export async function seedDemoContent(demo: DemoResult): Promise<DemoContentSummary> {
  const t0 = Date.now();
  const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, demo.orgId)).limit(1);
  if (!org) throw new Error("Organisme de démonstration introuvable.");
  const now = new Date();
  const s: State = {
    demo,
    orgId: demo.orgId,
    org: { name: org.legalName, address: `${org.addressLine1 ?? ""}, ${org.postalCode ?? ""} ${org.city ?? ""}`, nda: org.nda ?? "", siret: org.siret ?? "" },
    users: demo.users,
    rng: makeRng(20260923),
    now,
    today: todayParis(now),
    nowTime: timeParis(now),
    splitDate: "",
    witnessDay: "",
    siteIds: { paris: "", montreuil: "" },
    roomIds: { paris: [], montreuil: [] },
    companies: {},
    contacts: {},
    trainers: {},
    certifications: {},
    programs: {},
    elearningIds: [],
    persons: [],
    sessions: {} as State["sessions"],
    enrollments: [],
    periods: [],
    requiredPieces: [],
    documents: {},
    funders: {},
    fundingIds: {},
    invoiceIds: [],
    cohorts: { arhA: "", btsBlanc: "" },
    surveyIds: {},
    complaintIds: [],
    watchIds: [],
    evidenceIds: {},
    referentialId: "",
    analysisIds: { old: "", recent: "" },
    qualityActionIds: [],
    corrections: 0,
    counts: {},
  };

  // A. Référentiel de base, CRM, catalogue, sessions, inscriptions (une transaction).
  await db.transaction(async (tx) => {
    await phaseBase(tx, s);
    await phaseCrm(tx, s);
  });
  // B. Documents réels (fichiers) : hors transaction, les lignes parentes sont validées.
  await phaseDocuments(s);
  // C. Pièces attendues (avec fichiers pour les dossiers détaillés).
  await phasePieces(s);
  // D. Planning, présences, pédagogie, examens, finance, signatures (une transaction).
  await db.transaction(async (tx) => {
    await phasePlanning(tx, s);
    await phaseSignatures(tx, s);
    await phaseFinance(tx, s);
  });
  // E. Feuilles d'émargement des périodes clôturées (fichiers).
  await phaseAttendanceSheets(s);
  // F. Qualité (référentiel, preuves, analyses, actions, enquêtes).
  await db.transaction(async (tx) => {
    await phaseQuality(tx, s);
  });
  // G. Tâches et relais, agenda, notifications (services partagés).
  await phaseTasks(s);

  const ines = s.enrollments.find((e) => e.isInes)!;
  const arh = s.enrollments.filter((e) => e.sessionKey === "arh");
  return {
    durationMs: Date.now() - t0,
    counts: s.counts,
    today: s.today,
    splitDate: s.splitDate,
    witnessDay: s.witnessDay,
    inesEnrollmentId: ines.id,
    inesReference: ines.reference,
    titreProSessionId: s.sessions.arh.id,
    btsSessionId: s.sessions.bts.id,
    witnessEnrollmentIds: [arh[0].id, arh[1].id],
    cohorts: s.cohorts,
    analysisIds: s.analysisIds,
    invalidatedEvidenceId: s.evidenceIds.soustraitance,
  };
}
