import "server-only";
import { and, eq, inArray, isNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { randomToken, sha256 } from "@/lib/crypto";
import { appUrl } from "@/lib/env";
import { todayParis } from "@/lib/time";
import { layoutMail, sendMail } from "@/server/mail";
import { recordEvidence } from "./evidence";
import { parseQuestions, responseScore, type SurveyAnswers } from "./indicator-math";
import { surveyTemplate } from "./survey-templates";

export type Survey = typeof schema.surveys.$inferSelect;
export type SurveyResponse = typeof schema.surveyResponses.$inferSelect;

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}

export type SendReport = { recipients: number; sent: number; skippedAlready: number; skippedNoEmail: number; notConfigured: number; links: { name: string; url: string }[] };

/**
 * Envoie l'enquête aux inscrits de sa session : un jeton individuel par inscription (hash stocké), e-mail via sendMail
 * (jamais envoyé en démonstration). Idempotent : une inscription déjà destinataire n'est pas réinvitée.
 * Les liens sont retournés quand l'e-mail n'est pas parti (service non configuré ou démo) pour transmission manuelle.
 */
export async function sendSurveyToSession(survey: Survey, opts: { orgId: string; isDemo: boolean; orgName: string }): Promise<SendReport> {
  if (survey.orgId !== opts.orgId) throw new Error("Enquête hors organisme.");
  if (!survey.sessionId) throw new Error("Cette enquête n'est pas reliée à une session.");
  const enrollments = await db
    .select({ id: schema.enrollments.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email })
    .from(schema.enrollments)
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.enrollments.orgId, opts.orgId), eq(schema.enrollments.sessionId, survey.sessionId), inArray(schema.enrollments.status, ["inscrit", "en_cours", "termine"])));
  const existing = await db
    .select({ enrollmentId: schema.surveyResponses.enrollmentId })
    .from(schema.surveyResponses)
    .where(and(eq(schema.surveyResponses.surveyId, survey.id), eq(schema.surveyResponses.orgId, opts.orgId)));
  const already = new Set(existing.map((e) => e.enrollmentId).filter(Boolean));
  const report: SendReport = { recipients: enrollments.length, sent: 0, skippedAlready: 0, skippedNoEmail: 0, notConfigured: 0, links: [] };
  for (const e of enrollments) {
    if (already.has(e.id)) {
      report.skippedAlready++;
      continue;
    }
    if (!e.email) {
      report.skippedNoEmail++;
      continue;
    }
    const token = randomToken(32);
    const url = `${appUrl()}/enquete/${token}`;
    await db.insert(schema.surveyResponses).values({ orgId: opts.orgId, surveyId: survey.id, enrollmentId: e.id, tokenHash: sha256(token), sentAt: new Date() });
    const res = await sendMail({
      to: e.email,
      subject: `${opts.orgName} : ${survey.title}`,
      html: layoutMail(survey.title, `<p>Bonjour ${escapeHtml(e.firstName)},</p><p>${escapeHtml(opts.orgName)} vous invite à répondre à un court questionnaire. Vos réponses nous aident à améliorer nos formations. Ce lien est personnel.</p>`, { label: "Répondre au questionnaire", url }),
      text: `Répondez au questionnaire : ${url}`,
      isDemo: opts.isDemo,
    });
    report.sent++;
    if (res.status !== "sent") {
      report.notConfigured++;
      report.links.push({ name: `${e.firstName} ${e.lastName}`, url });
    }
  }
  return report;
}

export async function findResponseByToken(token: string): Promise<{ response: SurveyResponse; survey: Survey; org: { legalName: string; tradeName: string | null } } | null> {
  if (!token || token.length < 20 || token.length > 200) return null;
  const [row] = await db
    .select({ response: schema.surveyResponses, survey: schema.surveys, legalName: schema.organismes.legalName, tradeName: schema.organismes.tradeName })
    .from(schema.surveyResponses)
    .innerJoin(schema.surveys, eq(schema.surveys.id, schema.surveyResponses.surveyId))
    .innerJoin(schema.organismes, eq(schema.organismes.id, schema.surveyResponses.orgId))
    .where(eq(schema.surveyResponses.tokenHash, sha256(token)))
    .limit(1);
  if (!row) return null;
  return { response: row.response, survey: row.survey, org: { legalName: row.legalName, tradeName: row.tradeName } };
}

/**
 * Enregistre une soumission (une seule par jeton) et crée la preuve Qualiopi correspondante
 * (niveau collectif par session, source réelle = la réponse).
 */
export async function submitResponse(responseId: string, answers: SurveyAnswers): Promise<{ ok: true } | { ok: false; error: string }> {
  const [r] = await db.select().from(schema.surveyResponses).where(eq(schema.surveyResponses.id, responseId)).limit(1);
  if (!r) return { ok: false, error: "Questionnaire introuvable." };
  if (r.submittedAt) return { ok: false, error: "Ce questionnaire a déjà été soumis." };
  const [survey] = await db.select().from(schema.surveys).where(eq(schema.surveys.id, r.surveyId)).limit(1);
  if (!survey || survey.status !== "active") return { ok: false, error: "Cette enquête n'est plus ouverte." };
  const questions = parseQuestions(survey.questions);
  // Une seule soumission par jeton, y compris en cas de double envoi simultané (condition « non encore soumis » dans l'UPDATE).
  const updated = await db
    .update(schema.surveyResponses)
    .set({ answers, score: responseScore(answers, questions), submittedAt: new Date() })
    .where(and(eq(schema.surveyResponses.id, r.id), isNull(schema.surveyResponses.submittedAt)))
    .returning({ id: schema.surveyResponses.id });
  if (!updated.length) return { ok: false, error: "Ce questionnaire a déjà été soumis." };
  const indicator = surveyTemplate(survey.kind)?.qualiopiIndicator ?? "IND_30";
  await recordEvidence({
    orgId: r.orgId,
    indicatorCode: indicator,
    level: "collectif",
    title: `Réponse reçue : ${survey.title}`,
    sourceType: "survey_response",
    sourceId: r.id,
    sessionId: survey.sessionId,
    programId: survey.programId,
    enrollmentId: indicator === "IND_30" ? null : r.enrollmentId,
    evidenceDate: todayParis(),
    note: "Preuve créée automatiquement à la réception d'une réponse d'enquête.",
  });
  return { ok: true };
}
