import "server-only";
import { and, desc, eq, inArray, isNull, lte, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { todayParis } from "@/lib/time";
import { audit } from "@/server/audit";
import type { OrgContext } from "@/server/authz";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { analyze, evidencesChangedSince, orgActivities, type AnalysisResult, type Control, type EvidenceInput, type ScopeContext, type Summary } from "./engine";
import { parseCriteria, type AnalysisScope, type CriterionDef } from "./referential-data";

export type Analysis = typeof schema.qualityAnalyses.$inferSelect;
export type Referential = typeof schema.referentials.$inferSelect;
export type Evidence = typeof schema.qualityEvidences.$inferSelect;

/**
 * Référentiel applicable de l'organisme : validé par un humain (statut actif ou validé), dates d'effet couvrant la date.
 * Aucun référentiel plateforme (orgId null) n'est jamais applicable directement.
 */
export async function activeReferential(orgId: string, date = todayParis()): Promise<Referential | null> {
  const rows = await db
    .select()
    .from(schema.referentials)
    .where(
      and(
        eq(schema.referentials.orgId, orgId),
        inArray(schema.referentials.status, ["actif", "valide"]),
        sql`${schema.referentials.validatedAt} is not null`,
        or(isNull(schema.referentials.effectiveFrom), lte(schema.referentials.effectiveFrom, date)),
        or(isNull(schema.referentials.effectiveTo), sql`${schema.referentials.effectiveTo} >= ${date}`),
      ),
    )
    .orderBy(desc(schema.referentials.validatedAt))
    .limit(1);
  return rows[0] ?? null;
}

export function referentialCriteria(r: Referential): CriterionDef[] {
  return parseCriteria(r.criteria);
}

/** Entités rattachées au périmètre (sessions, inscriptions, programmes), toujours filtrées par organisme. */
export async function scopeContext(orgId: string, scope: AnalysisScope, scopeId: string | null): Promise<ScopeContext> {
  const ctx: ScopeContext = { scope, scopeId, sessionIds: [], enrollmentIds: [], programIds: [] };
  if (scope === "organisme") return ctx;
  if (!scopeId) throw new Error("Périmètre sans identifiant.");
  if (scope === "session") {
    const [s] = await db.select({ id: schema.trainingSessions.id }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, scopeId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
    if (!s) throw new Error("Session introuvable.");
    ctx.sessionIds = [s.id];
  } else if (scope === "inscription") {
    const [e] = await db.select({ id: schema.enrollments.id, sessionId: schema.enrollments.sessionId }).from(schema.enrollments).where(and(eq(schema.enrollments.id, scopeId), eq(schema.enrollments.orgId, orgId))).limit(1);
    if (!e) throw new Error("Inscription introuvable.");
    ctx.enrollmentIds = [e.id];
    ctx.sessionIds = [e.sessionId];
    return ctx;
  } else if (scope === "programme") {
    const [p] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.id, scopeId), eq(schema.programs.orgId, orgId))).limit(1);
    if (!p) throw new Error("Programme introuvable.");
    ctx.programIds = [p.id];
    const sessions = await db
      .select({ id: schema.trainingSessions.id })
      .from(schema.trainingSessions)
      .innerJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
      .where(and(eq(schema.trainingSessions.orgId, orgId), eq(schema.programVersions.programId, p.id)));
    ctx.sessionIds = sessions.map((s) => s.id);
  }
  if (ctx.sessionIds.length) {
    const enr = await db.select({ id: schema.enrollments.id }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.sessionId, ctx.sessionIds)));
    ctx.enrollmentIds = enr.map((e) => e.id);
  }
  return ctx;
}

/** Preuves candidates du périmètre (tous statuts : le moteur distingue valides et invalidées). */
export async function scopeEvidences(orgId: string, ctx: ScopeContext): Promise<Evidence[]> {
  if (ctx.scope === "organisme") return db.select().from(schema.qualityEvidences).where(eq(schema.qualityEvidences.orgId, orgId));
  const conds = [];
  if (ctx.sessionIds.length) conds.push(inArray(schema.qualityEvidences.sessionId, ctx.sessionIds));
  if (ctx.enrollmentIds.length) conds.push(inArray(schema.qualityEvidences.enrollmentId, ctx.enrollmentIds));
  if (ctx.programIds.length) conds.push(inArray(schema.qualityEvidences.programId, ctx.programIds));
  if (!conds.length) return [];
  return db
    .select()
    .from(schema.qualityEvidences)
    .where(and(eq(schema.qualityEvidences.orgId, orgId), or(...conds)));
}

export function toEngineEvidence(e: Evidence): EvidenceInput {
  return {
    id: e.id,
    indicatorCode: e.indicatorCode,
    level: e.level,
    status: e.status,
    evidenceDate: e.evidenceDate,
    createdAt: e.createdAt.toISOString(),
    enrollmentId: e.enrollmentId,
    sessionId: e.sessionId,
    programId: e.programId,
    invalidationReason: e.invalidationReason,
  };
}

export type RunResult = { analysis: Analysis; result: AnalysisResult; tasksCreated: number; tasksResolved: number };

/**
 * Lance une analyse et enregistre une photographie immuable (jamais d'update ; la précédente du même périmètre
 * reçoit `supersededById`). Pour le périmètre organisme, chaque indicateur absent crée une tâche (une par
 * indicateur et par analyse) affectée au responsable qualité identifiable.
 */
export async function runAnalysis(ctx: OrgContext, scope: AnalysisScope, scopeId: string | null, referenceDate = todayParis()): Promise<RunResult> {
  const ref = await activeReferential(ctx.org.id, referenceDate);
  if (!ref) throw new Error("Aucun référentiel validé n'est applicable à cette date : validez-en un dans « Référentiel ».");
  const sctx = await scopeContext(ctx.org.id, scope, scopeId);
  const evidences = await scopeEvidences(ctx.org.id, sctx);
  const result = analyze({ criteria: referentialCriteria(ref), activities: orgActivities(ctx.org.kind), ctx: sctx, evidences: evidences.map(toEngineEvidence), referenceDate });

  const previous = await latestAnalysis(ctx.org.id, scope, scopeId);
  const [analysis] = await db
    .insert(schema.qualityAnalyses)
    .values({
      orgId: ctx.org.id,
      referentialId: ref.id,
      scope,
      scopeId,
      engineVersion: result.engineVersion,
      referenceDate,
      controls: result.controls,
      summary: result.summary,
      createdBy: ctx.user.id,
    })
    .returning();
  if (previous) {
    // Seule écriture autorisée sur une ancienne analyse : le lien vers celle qui la remplace (contenu inchangé).
    await db.update(schema.qualityAnalyses).set({ supersededById: analysis.id }).where(and(eq(schema.qualityAnalyses.id, previous.id), isNull(schema.qualityAnalyses.supersededById)));
  }
  await audit({ action: "quality.analysis.run", userId: ctx.user.id, orgId: ctx.org.id, entityType: "quality_analysis", entityId: analysis.id, after: { scope, scopeId, referenceDate, referentialId: ref.id, summary: result.summary, supersedes: previous?.id ?? null } });

  let tasksCreated = 0;
  let tasksResolved = 0;
  if (scope === "organisme") {
    const assignee = await qualityAssignee(ctx);
    const href = `/app/${ctx.org.id}/qualite/analyses/${analysis.id}`;
    const prevControls = previous ? (previous.controls as Control[]) : [];
    for (const c of result.controls) {
      const prev = prevControls.find((p) => p.indicator === c.indicator);
      if (previous && prev?.status === "absent") {
        const note = c.status === "absent" ? `Toujours absent dans l'analyse du ${referenceDate} : nouvelle tâche créée.` : `Cause disparue : indicateur ${c.indicator} classé « ${c.status} » dans l'analyse du ${referenceDate}.`;
        if (await resolveTaskByKey(ctx.org.id, `quality:${c.indicator}:${previous.id}`, note, ctx.user.id)) tasksResolved++;
      }
      if (c.status !== "absent") continue;
      const r = await createTaskOnce({
        orgId: ctx.org.id,
        title: `Produire une preuve : indicateur ${c.number} (${c.level})`,
        description: `${c.label}\n\n${c.note}`,
        family: "qualite",
        entityType: "quality_analysis",
        entityId: analysis.id,
        entityLabel: `Analyse du ${referenceDate}`,
        href,
        assigneeUserId: assignee,
        assigneeRole: "quality",
        priority: "normale",
        indicatorCode: c.indicator,
        createdBy: ctx.user.id,
        source: "automatique",
        isDemo: ctx.org.isDemo,
        idempotencyKey: `quality:${c.indicator}:${analysis.id}`,
      });
      if (r.created) tasksCreated++;
    }
  }
  return { analysis, result, tasksCreated, tasksResolved };
}

/** Responsable qualité identifiable : premier membre actif portant le rôle quality, sinon l'auteur de l'analyse. */
async function qualityAssignee(ctx: OrgContext): Promise<string> {
  const rows = await db
    .select({ userId: schema.memberships.userId })
    .from(schema.memberships)
    .where(and(eq(schema.memberships.orgId, ctx.org.id), eq(schema.memberships.active, true), sql`${schema.memberships.roles} @> '["quality"]'::jsonb`))
    .limit(1);
  return rows[0]?.userId ?? ctx.user.id;
}

export async function latestAnalysis(orgId: string, scope: AnalysisScope, scopeId: string | null): Promise<Analysis | null> {
  const rows = await db
    .select()
    .from(schema.qualityAnalyses)
    .where(and(eq(schema.qualityAnalyses.orgId, orgId), eq(schema.qualityAnalyses.scope, scope), scopeId ? eq(schema.qualityAnalyses.scopeId, scopeId) : isNull(schema.qualityAnalyses.scopeId)))
    .orderBy(desc(schema.qualityAnalyses.createdAt))
    .limit(1);
  return rows[0] ?? null;
}

export async function analysisById(orgId: string, analysisId: string): Promise<Analysis | null> {
  const [a] = await db.select().from(schema.qualityAnalyses).where(and(eq(schema.qualityAnalyses.id, analysisId), eq(schema.qualityAnalyses.orgId, orgId))).limit(1);
  return a ?? null;
}

export async function listAnalyses(orgId: string, limit = 30): Promise<Analysis[]> {
  return db.select().from(schema.qualityAnalyses).where(eq(schema.qualityAnalyses.orgId, orgId)).orderBy(desc(schema.qualityAnalyses.createdAt)).limit(limit);
}

/** Vrai si des preuves du périmètre ont changé depuis la photographie : l'écran invite à relancer l'analyse. */
export async function analysisIsStale(orgId: string, analysis: Analysis): Promise<boolean> {
  const sctx = await scopeContext(orgId, analysis.scope, analysis.scopeId);
  const evidences = await scopeEvidences(orgId, sctx);
  return evidencesChangedSince(evidences, analysis.createdAt);
}

/**
 * Synthèse du dossier d'inscription : lit la MÊME photographie que l'analyse complète. Sans photographie : null
 * (l'écran affiche « aucune analyse »).
 */
export async function analysisSummaryForEnrollment(orgId: string, enrollmentId: string): Promise<{ analysisId: string; referenceDate: string; engineVersion: string; analysedAt: Date; summary: Summary; humanReview: Control[]; missing: Control[]; stale: boolean } | null> {
  const a = await latestAnalysis(orgId, "inscription", enrollmentId);
  if (!a) return null;
  const controls = a.controls as Control[];
  return {
    analysisId: a.id,
    referenceDate: a.referenceDate,
    engineVersion: a.engineVersion,
    analysedAt: a.createdAt,
    summary: a.summary as Summary,
    humanReview: controls.filter((c) => c.status === "a_examiner"),
    missing: controls.filter((c) => c.status === "absent"),
    stale: await analysisIsStale(orgId, a),
  };
}

/** Preuves référencées par une analyse (pour l'affichage des liens). */
export async function analysisEvidences(orgId: string, analysis: Analysis): Promise<Map<string, Evidence>> {
  const ids = [...new Set((analysis.controls as Control[]).flatMap((c) => c.evidenceIds))];
  if (!ids.length) return new Map();
  const rows = await db.select().from(schema.qualityEvidences).where(and(eq(schema.qualityEvidences.orgId, orgId), inArray(schema.qualityEvidences.id, ids)));
  return new Map(rows.map((r) => [r.id, r]));
}
