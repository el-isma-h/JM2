import "server-only";
import { headers } from "next/headers";
import { db, schema } from "@/db";

export async function audit(entry: {
  action: string;
  userId?: string | null;
  tenantId?: string | null;
  orgId?: string | null;
  entityType?: string;
  entityId?: string | null;
  before?: unknown;
  after?: unknown;
}) {
  let ip: string | null = null;
  let userAgent: string | null = null;
  try {
    const h = await headers();
    const raw = (h.get("x-forwarded-for") ?? "").split(",")[0].trim();
    ip = raw && /^[0-9a-f.:]+$/i.test(raw) ? raw : null;
    userAgent = h.get("user-agent")?.slice(0, 300) ?? null;
  } catch {
    // hors requête (job)
  }
  await db.insert(schema.auditLogs).values({
    action: entry.action,
    userId: entry.userId ?? null,
    tenantId: entry.tenantId ?? null,
    orgId: entry.orgId ?? null,
    entityType: entry.entityType,
    entityId: entry.entityId ?? null,
    before: entry.before ?? null,
    after: entry.after ?? null,
    ip,
    userAgent,
  });
}
