import "server-only";
import { AuthError, type SessionUser } from "@/server/auth";
import type { OrgContext } from "@/server/authz";
import { complete, extractJson, pickProvider, type CompleteResult } from "../provider";
import { toPromptJson } from "../redact";
import type { Rationale } from "../proposals";

/** Consignes communes à tous les agents : français, prudence, pas d'invention, sources citées. */
export const AGENT_SYSTEM_BASE = `Tu es un assistant d'un organisme de formation français (OF / CFA) utilisant Next Formation.
Règles absolues :
- Tu n'inventes jamais une donnée, une preuve, une présence ou une signature. Ce qui n'est pas dans les données fournies est « à compléter » ou « inconnu ».
- Tu rédiges en français clair, vouvoiement, sans tiret cadratin.
- Tu proposes, tu n'agis pas : un humain valide chaque proposition avant tout effet.
- Tu indiques un niveau de certitude : A (établi à partir des données), B (déduit, à vérifier), C (hypothèse).`;

export function requireEntity(input: { entityType?: string | null; entityId?: string | null }, expected: string[]): { entityType: string; entityId: string } {
  if (!input.entityType || !input.entityId || !expected.includes(input.entityType) || !/^[0-9a-f-]{36}$/i.test(input.entityId)) {
    throw new Error(`Cet agent attend un contexte : ${expected.join(" ou ")}.`);
  }
  return { entityType: input.entityType, entityId: input.entityId };
}

export function forbidden(): never {
  throw new AuthError("forbidden");
}

export function userLabel(u: SessionUser) {
  return `${u.firstName} ${u.lastName}`;
}

/**
 * Appel JSON au modèle, avec repli : si aucune clé n'est configurée, retourne null et l'agent produit
 * une proposition déterministe (rationale.deterministic = true).
 */
export async function askJson<T>(system: string, user: string, maxTokens = 1800): Promise<{ data: T | null; result: CompleteResult } | null> {
  if (!pickProvider()) return null;
  const result = await complete({ system: `${AGENT_SYSTEM_BASE}\n\n${system}`, messages: [{ role: "user", content: user }], json: true, maxTokens });
  const data = extractJson(result.text) as T | null;
  return { data, result };
}

export function baseRationale(sources: Rationale["sources"], certainty: Rationale["certainty"], deterministic: boolean, rules: string[] = [], notes: string[] = []): Rationale {
  return { sources, certainty, deterministic, rules, notes };
}

export function orgLabel(ctx: OrgContext) {
  return ctx.org.tradeName ?? ctx.org.legalName;
}

export { toPromptJson };
