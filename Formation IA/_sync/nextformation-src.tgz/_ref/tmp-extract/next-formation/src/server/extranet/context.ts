import "server-only";
import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { cookies } from "next/headers";
import { cache } from "react";
import { db, schema } from "@/db";
import { ORG_ROLES, type OrgRole } from "@/db/schema/tenancy";
import { AuthError, requireUser, type SessionUser } from "@/server/auth";
import { STAFF_ROLES } from "@/server/authz";
import { emailAccessOk } from "@/lib/env";

/**
 * Contextes des extranets (apprenant /moi, entreprise-tuteur /entreprise, formateur externe /formateur).
 * Périmètre strict : un apprenant ne voit que ses propres inscriptions, une entreprise que les inscriptions
 * rattachées à elle (`enrollments.companyId`), un formateur que ses sessions affectées.
 * Tout accès dépend d'un utilisateur actif, d'une affectation active et du rattachement (personId / companyId / trainerId).
 */

export const EXTRANET_ORG_COOKIE = "nf_extranet_org";

export type ExtranetKind = "learner" | "employer" | "trainer";

export type ExtranetChoice = { orgId: string; orgName: string };

type MembershipRow = typeof schema.memberships.$inferSelect;
type OrgRow = typeof schema.organismes.$inferSelect;

function parseRoles(v: unknown): OrgRole[] {
  if (!Array.isArray(v)) return [];
  return v.filter((r): r is OrgRole => typeof r === "string" && (ORG_ROLES as readonly string[]).includes(r));
}

/** Affectations actives de l'utilisateur portant le rôle demandé, avec l'organisme. */
async function membershipsWithRole(user: SessionUser, role: ExtranetKind): Promise<{ m: MembershipRow; o: OrgRow; roles: OrgRole[] }[]> {
  const rows = await db
    .select({ m: schema.memberships, o: schema.organismes })
    .from(schema.memberships)
    .innerJoin(schema.organismes, eq(schema.organismes.id, schema.memberships.orgId))
    .where(and(eq(schema.memberships.userId, user.id), eq(schema.memberships.active, true)))
    .orderBy(asc(schema.organismes.legalName));
  const now = new Date();
  return rows
    .filter((r) => !r.m.expiresAt || r.m.expiresAt > now)
    .map((r) => ({ ...r, roles: parseRoles(r.m.roles) }))
    .filter((r) => r.roles.includes(role));
}

/** Organisme choisi quand l'utilisateur a plusieurs rattachements (cookie posé par `switchExtranetOrgAction`). */
async function preferredOrgId(): Promise<string | null> {
  try {
    const jar = await cookies();
    const v = jar.get(EXTRANET_ORG_COOKIE)?.value ?? null;
    return v && /^[0-9a-f-]{36}$/i.test(v) ? v : null;
  } catch {
    return null;
  }
}

function pick<T extends { o: OrgRow }>(rows: T[], preferred: string | null): T | null {
  if (!rows.length) return null;
  return rows.find((r) => r.o.id === preferred) ?? rows[0];
}

async function currentUserForExtranet(): Promise<SessionUser> {
  const user = await requireUser();
  if (!emailAccessOk(user)) throw new AuthError("email_unverified");
  return user;
}

/* ------------------------------------------------------------------ */
/* Apprenant                                                           */
/* ------------------------------------------------------------------ */

export type LearnerEnrollment = {
  enrollment: typeof schema.enrollments.$inferSelect;
  session: typeof schema.trainingSessions.$inferSelect;
  program: { id: string; title: string } | null;
  group: { id: string; name: string } | null;
};

export type LearnerContext = {
  kind: "learner";
  user: SessionUser;
  org: OrgRow;
  membership: MembershipRow;
  person: typeof schema.persons.$inferSelect;
  enrollments: LearnerEnrollment[];
  enrollmentIds: string[];
  /** Autres rattachements disponibles (sélecteur). */
  choices: ExtranetChoice[];
};

/**
 * Contexte apprenant : affectation active avec le rôle `learner` et un `personId` renseigné.
 * Retourne null si aucun rattachement exploitable (l'écran affiche alors un état vide explicite).
 * Lève AuthError("unauthenticated") sans session : le layout redirige vers /connexion?next=.
 */
export const getLearnerContext = cache(async (): Promise<LearnerContext | null> => {
  const user = await currentUserForExtranet();
  const rows = (await membershipsWithRole(user, "learner")).filter((r) => Boolean(r.m.personId));
  const chosen = pick(rows, await preferredOrgId());
  if (!chosen) return null;
  const [person] = await db
    .select()
    .from(schema.persons)
    .where(and(eq(schema.persons.id, chosen.m.personId!), eq(schema.persons.orgId, chosen.o.id)))
    .limit(1);
  if (!person) return null;
  const enrollments = await loadEnrollments(chosen.o.id, { personId: person.id });
  return {
    kind: "learner",
    user,
    org: chosen.o,
    membership: chosen.m,
    person,
    enrollments,
    enrollmentIds: enrollments.map((e) => e.enrollment.id),
    choices: rows.map((r) => ({ orgId: r.o.id, orgName: r.o.tradeName ?? r.o.legalName })),
  };
});

/* ------------------------------------------------------------------ */
/* Entreprise / tuteur                                                 */
/* ------------------------------------------------------------------ */

export type EmployerEnrollment = LearnerEnrollment & { person: { id: string; firstName: string; lastName: string; email: string | null } };

export type EmployerContext = {
  kind: "employer";
  user: SessionUser;
  org: OrgRow;
  membership: MembershipRow;
  company: typeof schema.companies.$inferSelect;
  contacts: (typeof schema.contacts.$inferSelect)[];
  /** Contact de l'entreprise correspondant à l'utilisateur connecté (par `contacts.userId`, sinon par e-mail), s'il existe. */
  contact: typeof schema.contacts.$inferSelect | null;
  enrollments: EmployerEnrollment[];
  enrollmentIds: string[];
  choices: ExtranetChoice[];
};

export const getEmployerContext = cache(async (): Promise<EmployerContext | null> => {
  const user = await currentUserForExtranet();
  const rows = (await membershipsWithRole(user, "employer")).filter((r) => Boolean(r.m.companyId));
  const chosen = pick(rows, await preferredOrgId());
  if (!chosen) return null;
  const [company] = await db
    .select()
    .from(schema.companies)
    .where(and(eq(schema.companies.id, chosen.m.companyId!), eq(schema.companies.orgId, chosen.o.id)))
    .limit(1);
  if (!company) return null;
  const contacts = await db
    .select()
    .from(schema.contacts)
    .where(and(eq(schema.contacts.orgId, chosen.o.id), eq(schema.contacts.companyId, company.id)))
    .orderBy(asc(schema.contacts.lastName));
  const contact = contacts.find((c) => c.userId === user.id) ?? contacts.find((c) => (c.email ?? "").toLowerCase() === user.email.toLowerCase()) ?? null;
  const base = await loadEnrollments(chosen.o.id, { companyId: company.id });
  const personIds = [...new Set(base.map((e) => e.enrollment.personId))];
  const persons = personIds.length
    ? await db
        .select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName, email: schema.persons.email })
        .from(schema.persons)
        .where(and(eq(schema.persons.orgId, chosen.o.id), inArray(schema.persons.id, personIds)))
    : [];
  const byPerson = new Map(persons.map((p) => [p.id, p]));
  const enrollments: EmployerEnrollment[] = base
    .map((e) => ({ ...e, person: byPerson.get(e.enrollment.personId)! }))
    .filter((e) => Boolean(e.person));
  return {
    kind: "employer",
    user,
    org: chosen.o,
    membership: chosen.m,
    company,
    contacts,
    contact,
    enrollments,
    enrollmentIds: enrollments.map((e) => e.enrollment.id),
    choices: rows.map((r) => ({ orgId: r.o.id, orgName: r.o.tradeName ?? r.o.legalName })),
  };
});

/* ------------------------------------------------------------------ */
/* Formateur externe                                                   */
/* ------------------------------------------------------------------ */

export type TrainerContext = {
  kind: "trainer";
  user: SessionUser;
  org: OrgRow;
  membership: MembershipRow;
  trainer: typeof schema.trainers.$inferSelect;
  /** Sessions affectées (affectation de session ou séance) : périmètre 0045. */
  sessionIds: string[];
  sessions: (typeof schema.trainingSessions.$inferSelect)[];
  /** Vrai si l'utilisateur cumule un autre rôle staff : il doit utiliser l'application principale (/app). */
  hasOtherStaffRole: boolean;
  choices: ExtranetChoice[];
};

export const getTrainerContext = cache(async (): Promise<TrainerContext | null> => {
  const user = await currentUserForExtranet();
  const rows = (await membershipsWithRole(user, "trainer")).filter((r) => Boolean(r.m.trainerId));
  const chosen = pick(rows, await preferredOrgId());
  if (!chosen) return null;
  const [trainer] = await db
    .select()
    .from(schema.trainers)
    .where(and(eq(schema.trainers.id, chosen.m.trainerId!), eq(schema.trainers.orgId, chosen.o.id)))
    .limit(1);
  if (!trainer) return null;
  const viaAssign = await db
    .select({ sessionId: schema.sessionTrainers.sessionId })
    .from(schema.sessionTrainers)
    .where(and(eq(schema.sessionTrainers.orgId, chosen.o.id), eq(schema.sessionTrainers.trainerId, trainer.id)));
  const viaSlots = await db
    .select({ sessionId: schema.slots.sessionId })
    .from(schema.slots)
    .where(and(eq(schema.slots.orgId, chosen.o.id), eq(schema.slots.trainerId, trainer.id)));
  const sessionIds = [...new Set([...viaAssign.map((r) => r.sessionId), ...viaSlots.map((r) => r.sessionId)])];
  const sessions = sessionIds.length
    ? await db
        .select()
        .from(schema.trainingSessions)
        .where(and(eq(schema.trainingSessions.orgId, chosen.o.id), inArray(schema.trainingSessions.id, sessionIds)))
        .orderBy(desc(schema.trainingSessions.startDate))
    : [];
  const hasOtherStaffRole = chosen.roles.some((r) => r !== "trainer" && STAFF_ROLES.includes(r)) || chosen.o.ownerUserId === user.id;
  return {
    kind: "trainer",
    user,
    org: chosen.o,
    membership: chosen.m,
    trainer,
    sessionIds,
    sessions,
    hasOtherStaffRole,
    choices: rows.map((r) => ({ orgId: r.o.id, orgName: r.o.tradeName ?? r.o.legalName })),
  };
});

/* ------------------------------------------------------------------ */
/* Helpers partagés                                                    */
/* ------------------------------------------------------------------ */

async function loadEnrollments(orgId: string, by: { personId?: string; companyId?: string }): Promise<LearnerEnrollment[]> {
  const cond = by.personId ? eq(schema.enrollments.personId, by.personId) : eq(schema.enrollments.companyId, by.companyId!);
  const rows = await db
    .select({
      enrollment: schema.enrollments,
      session: schema.trainingSessions,
      program: { id: schema.programs.id, title: schema.programs.title },
      group: { id: schema.groups.id, name: schema.groups.name },
    })
    .from(schema.enrollments)
    .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.enrollments.sessionId))
    .leftJoin(schema.programVersions, eq(schema.programVersions.id, schema.trainingSessions.programVersionId))
    .leftJoin(schema.programs, eq(schema.programs.id, schema.programVersions.programId))
    .leftJoin(schema.groups, eq(schema.groups.id, schema.enrollments.groupId))
    .where(and(eq(schema.enrollments.orgId, orgId), cond))
    .orderBy(desc(schema.trainingSessions.startDate));
  return rows.map((r) => ({ enrollment: r.enrollment, session: r.session, program: r.program?.id ? r.program : null, group: r.group?.id ? r.group : null }));
}

/** Vérifie qu'une inscription appartient au périmètre du contexte (apprenant ou entreprise) ; lève sinon. */
export function assertEnrollmentInExtranetScope(ctx: { enrollmentIds: string[] }, enrollmentId: string) {
  if (!ctx.enrollmentIds.includes(enrollmentId)) throw new AuthError("forbidden");
}

/** Une session est-elle dans le périmètre du formateur ? */
export function assertSessionInTrainerScope(ctx: TrainerContext, sessionId: string) {
  if (!ctx.sessionIds.includes(sessionId)) throw new AuthError("forbidden");
}

/** Libellés lisibles des statuts d'inscription pour l'extranet (jamais un code brut). */
export const enrollmentStatusLabels: Record<string, string> = {
  preinscrit: "Préinscription en cours",
  inscrit: "Inscription confirmée",
  en_cours: "Formation en cours",
  termine: "Formation terminée",
  abandon: "Parcours interrompu",
  annule: "Inscription annulée",
  reporte: "Inscription reportée",
};
