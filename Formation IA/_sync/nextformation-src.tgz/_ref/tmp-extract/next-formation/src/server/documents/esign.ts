import "server-only";
import { integrations } from "@/lib/env";

/**
 * Adaptateur de signature électronique. Aucun prestataire n'est branché par défaut :
 * pour en ajouter un, implémenter `ESignAdapter` et l'enregistrer dans `ADAPTERS` sous la valeur de ESIGN_PROVIDER.
 * Tant qu'aucun adaptateur ne correspond, aucune demande ne part et le statut reste explicite.
 */

export type ESignSigner = { name: string; email: string; role: "employer" | "employee" | "other" };

export type ESignSendResult = { providerRef: string; status: "sent" | "requested" };
export type ESignStatus = "requested" | "sent" | "signed" | "declined" | "expired";
export type ESignProof = { signedAt: string; signers: { name: string; signedAt: string }[]; evidenceUrl?: string; sha256?: string };

export interface ESignAdapter {
  readonly name: string;
  send(input: { documentId: string; fileName: string; data: Buffer; title: string; signers: ESignSigner[] }): Promise<ESignSendResult>;
  status(providerRef: string): Promise<ESignStatus>;
  proof(providerRef: string): Promise<ESignProof | null>;
}

/** Registre des prestataires disponibles (vide : à compléter lors de l'intégration d'un prestataire). */
const ADAPTERS: Record<string, () => ESignAdapter> = {};

export type ESignAvailability =
  | { ok: true; adapter: ESignAdapter }
  | { ok: false; status: "not_configured"; message: string };

export const ESIGN_NOT_CONFIGURED_MESSAGE =
  "Signature électronique non configurée : définissez les variables ESIGN_PROVIDER et ESIGN_API_KEY. La demande est enregistrée avec le statut « Non configuré » et rien n'a été envoyé.";

export function getESignAdapter(): ESignAvailability {
  if (!integrations.esign()) return { ok: false, status: "not_configured", message: ESIGN_NOT_CONFIGURED_MESSAGE };
  const provider = (process.env.ESIGN_PROVIDER ?? "").toLowerCase();
  const factory = ADAPTERS[provider];
  if (!factory) {
    return {
      ok: false,
      status: "not_configured",
      message: `Le prestataire « ${provider} » défini dans ESIGN_PROVIDER n'a pas d'adaptateur dans src/server/documents/esign.ts. La demande est enregistrée avec le statut « Non configuré » et rien n'a été envoyé.`,
    };
  }
  return { ok: true, adapter: factory() };
}
