import "server-only";
import type { OrgContext } from "@/server/authz";
import { AuthError } from "@/server/auth";
import type { AgentName } from "../proposals";
import { saveProposal, type Agent, type AgentInput, type ProposalRow } from "../store";
import { documentsAgent } from "./documents";
import { dossierAgent } from "./dossier";
import { piecesAgent } from "./pieces";
import { planningAgent } from "./planning";
import { programmeAgent } from "./programme";
import { qualiteAgent } from "./qualite";
import { relancesAgent } from "./relances";
import { modelesEmailsAgent } from "./modeles-emails";

export const AGENTS: Record<AgentName, Agent> = {
  documents: documentsAgent,
  pieces: piecesAgent,
  relances: relancesAgent,
  qualite: qualiteAgent,
  programme: programmeAgent,
  planning: planningAgent,
  dossier: dossierAgent,
  modeles: modelesEmailsAgent,
};

export function isAgentName(v: unknown): v is AgentName {
  return typeof v === "string" && v in AGENTS;
}

/** Agents déclenchables par ce contexte (permission minimale). */
export function availableAgents(ctx: OrgContext): Agent[] {
  return Object.values(AGENTS).filter((a) => !a.requires || ctx.permissions.has(a.requires));
}

/** Agents pertinents pour une entité donnée. */
export function agentsForEntity(ctx: OrgContext, entityType: string | null | undefined): Agent[] {
  return availableAgents(ctx).filter((a) => (entityType ? a.accepts.includes(entityType) : a.accepts.includes("none") || a.accepts.includes("organisme")));
}

/** Exécute un agent et enregistre sa proposition (statut `proposee`). Aucun effet avant validation humaine. */
export async function runAgent(ctx: OrgContext, name: AgentName, input: AgentInput): Promise<ProposalRow> {
  const agent = AGENTS[name];
  if (!agent) throw new Error("Agent inconnu.");
  if (agent.requires && !ctx.permissions.has(agent.requires)) throw new AuthError("forbidden");
  const draft = await agent.run(ctx, input);
  return saveProposal(ctx, draft);
}
