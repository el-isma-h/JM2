import "server-only";
import type { OrgContext } from "@/server/authz";
import { assertEnrollmentInScope } from "@/server/authz";
import { listTemplates } from "@/server/documents/generate";
import { enrollmentSummary } from "../tools";
import type { Agent, AgentInput, ProposalDraft } from "../store";
import { askJson, baseRationale, forbidden, requireEntity, toPromptJson } from "./shared";

export type DocumentsPayload = {
  templateCode: string;
  templateTitle: string;
  enrollmentId: string;
  /** Réponses proposées aux questions du modèle : clé → valeur ; les valeurs inconnues sont absentes (marqueur à la génération). */
  answers: Record<string, string>;
  missing: string[];
  /** Fonction de génération attendue : `generateDocument` de src/server/documents/generate.ts (équipe documents). */
  generation: "generate.ts" | "task";
};

type Question = { key: string; label: string; type?: string; required?: boolean; help?: string };

/** Réponses déterministes : correspondance directe entre clés de question et champs du dossier. */
export function deterministicAnswers(questions: Question[], s: Record<string, unknown>): { answers: Record<string, string>; missing: string[] } {
  const e = (s.enrollment ?? {}) as Record<string, unknown>;
  const p = (s.person ?? {}) as Record<string, unknown>;
  const sess = (s.session ?? {}) as Record<string, unknown>;
  const known: Record<string, unknown> = {
    firstName: p.firstName,
    lastName: p.lastName,
    fullName: p.firstName && p.lastName ? `${p.firstName} ${p.lastName}` : undefined,
    email: p.email,
    sessionTitle: sess.title,
    sessionCode: sess.code,
    startDate: e.startDate,
    endDate: e.endDate,
    hoursPlanned: e.hoursPlanned,
    reference: e.reference,
    company: e.company,
    contractKind: e.contractKind,
    modality: sess.modality,
  };
  const answers: Record<string, string> = {};
  const missing: string[] = [];
  for (const q of questions) {
    const direct = known[q.key] ?? known[q.key.split(".").pop() ?? ""];
    if (direct !== undefined && direct !== null && direct !== "") answers[q.key] = String(direct);
    else missing.push(q.label ?? q.key);
  }
  return { answers, missing };
}

export const documentsAgent: Agent = {
  name: "documents",
  label: "Pré-remplissage de document",
  description: "Propose les réponses aux questions d'un modèle de document à partir du dossier ; la génération n'a lieu qu'après validation.",
  requires: "documents.generate",
  accepts: ["enrollment"],
  async run(ctx: OrgContext, input: AgentInput): Promise<ProposalDraft> {
    if (!ctx.permissions.has("documents.generate")) forbidden();
    const { entityId } = requireEntity(input, ["enrollment"]);
    await assertEnrollmentInScope(ctx, entityId);
    const templates = (await listTemplates(ctx.org.id, { scope: "enrollment" })).filter((t) => t.activity === "both" || ctx.org.kind === "of_cfa" || t.activity === ctx.org.kind);
    const code = (input.params?.templateCode ?? "").trim();
    const tpl = templates.find((t) => t.code === code) ?? (templates.length === 1 ? templates[0] : null);
    if (!tpl) throw new Error(templates.length ? `Choisissez un modèle (templateCode) parmi : ${templates.map((t) => t.code).join(", ")}.` : "Aucun modèle de document actif pour cet organisme.");
    const s = (await enrollmentSummary(ctx, entityId)) as Record<string, unknown> | null;
    if (!s) throw new Error("Inscription introuvable ou hors de votre périmètre.");
    const questions = (Array.isArray(tpl.questions) ? tpl.questions : []) as Question[];
    const det = deterministicAnswers(questions, s);
    const ai = questions.length
      ? await askJson<{ answers?: Record<string, string>; certainty?: "A" | "B" | "C" }>(
          `Propose des réponses aux questions d'un modèle de document à partir du dossier. Réponds en JSON : {"answers": {"<clé>": "<valeur>"}, "certainty": "A"|"B"|"C"}. Omet toute clé dont la valeur n'est pas établie par les données (ne jamais inventer une date, un montant ou un nom).`,
          `Questions : ${JSON.stringify(questions)}\nDossier :\n${toPromptJson(s)}\nRéponses déjà établies : ${JSON.stringify(det.answers)}`,
        )
      : null;
    const answers = { ...det.answers };
    if (ai?.data?.answers && typeof ai.data.answers === "object") {
      for (const [k, v] of Object.entries(ai.data.answers)) if (questions.some((q) => q.key === k) && typeof v === "string" && v.trim() && !answers[k]) answers[k] = v.trim();
    }
    const missing = questions.filter((q) => !answers[q.key]).map((q) => q.label ?? q.key);
    const payload: DocumentsPayload = { templateCode: tpl.code, templateTitle: tpl.title, enrollmentId: entityId, answers, missing, generation: "generate.ts" };
    const ref = String((s.enrollment as Record<string, unknown>).reference ?? "");
    return {
      agent: "documents",
      kind: "document_reponses",
      title: `Pré-remplir « ${tpl.title} » pour l'inscription ${ref}`,
      summary: `${Object.keys(answers).length} réponse(s) proposée(s), ${missing.length} à compléter`,
      entityType: "enrollment",
      entityId,
      payload: payload as unknown as Record<string, unknown>,
      rationale: baseRationale(
        [{ type: "document_template", label: `Modèle ${tpl.code} (${tpl.orgId ? "organisme" : "plateforme"})` }, { type: "enrollment", id: entityId, label: `Inscription ${ref}` }],
        ai?.data?.certainty ?? (ai ? "B" : "A"),
        !ai,
        ["Les réponses issues du modèle sont marquées B : à relire avant génération.", "Validation = génération du document (brouillon, jamais signé) via le module documents ; à défaut, tâche pour l'administratif."],
        missing.length ? [`À compléter à la génération : ${missing.join(", ")} (marqueur « [À COMPLÉTER] », jamais une valeur inventée).`] : [],
      ),
      provider: ai?.result.provider ?? null,
      model: ai?.result.model ?? null,
    };
  },
};
