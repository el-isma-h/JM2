import "server-only";
import { and, asc, desc, eq, inArray, ne, sql } from "drizzle-orm";
import { db, schema, type Db } from "@/db";
import { numberingPrefix } from "@/server/numbering";
import type { OrgContext } from "@/server/authz";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { minutesBetween } from "@/lib/time";
import { sessionPlaces } from "@/server/sessions/service";
import { applyWorkflow } from "@/server/workflows/service";
import { ensureCertificationRegistration } from "@/server/certifications/service";
import { ACTIVE_ENROLLMENT_STATUSES, applicablePieces, formatReference, pieceDueDate, type ContractKind, type EnrollmentStatus } from "./rules";

export * from "./rules";

type Tx = Parameters<Parameters<Db["transaction"]>[0]>[0];

export type CreateEnrollmentInput = {
  personId: string;
  sessionId: string;
  groupId?: string | null;
  companyId?: string | null;
  tutorContactId?: string | null;
  contractKind: ContractKind;
  contractNumber?: string | null;
  startDate?: string | null;
  endDate?: string | null;
  /** Heures prévues ; par défaut la durée de la version de programme figée. */
  hoursPlanned?: number | null;
  priceCents?: number | null;
  placementId?: string | null;
  quoteId?: string | null;
  commercialStatus?: (typeof schema.commercialStatusEnum.enumValues)[number];
  status?: EnrollmentStatus;
  legacyHours?: number | null;
  legacyHoursNote?: string | null;
};

/** Référence atomique INS-AAAA-NNNN (séquence `invoice_sequences`, kind "inscription"). */
export async function nextEnrollmentReference(tx: Pick<Db, "insert">, orgId: string, year = new Date().getFullYear()): Promise<string> {
  const [row] = await tx
    .insert(schema.invoiceSequences)
    .values({ orgId, kind: "inscription", year, next: 2 })
    .onConflictDoUpdate({ target: [schema.invoiceSequences.orgId, schema.invoiceSequences.kind, schema.invoiceSequences.year], set: { next: sql`${schema.invoiceSequences.next} + 1` } })
    .returning({ next: schema.invoiceSequences.next });
  return formatReference(await numberingPrefix(orgId, "enrollment", "INS"), year, row.next - 1);
}

/**
 * Crée une inscription complète (F03) : réutilise la personne, fige la version de programme active,
 * calcule les heures prévues, crée les pièces attendues applicables et une tâche par pièce obligatoire
 * manquante (rôle administratif), rattache le placement et journalise. Lève une Error lisible en cas de blocage.
 */
export async function createEnrollment(ctx: OrgContext, input: CreateEnrollmentInput) {
  const orgId = ctx.org.id;
  const [session] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, input.sessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
  if (!session) throw new Error("Session introuvable dans cet organisme.");
  if (session.status === "terminee" || session.status === "annulee") throw new Error(`La session est ${session.status === "terminee" ? "terminée" : "annulée"} : aucune inscription possible.`);
  const [person] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, input.personId), eq(schema.persons.orgId, orgId))).limit(1);
  if (!person) throw new Error("Personne introuvable dans cet organisme.");
  if (person.anonymizedAt) throw new Error("Cette personne a été anonymisée : aucune nouvelle inscription possible.");

  let group: typeof schema.groups.$inferSelect | null = null;
  if (input.groupId) {
    const [g] = await db.select().from(schema.groups).where(and(eq(schema.groups.id, input.groupId), eq(schema.groups.sessionId, session.id), eq(schema.groups.orgId, orgId))).limit(1);
    if (!g) throw new Error("Groupe introuvable pour cette session.");
    group = g;
  }
  let companyId: string | null = null;
  if (input.companyId) {
    const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.id, input.companyId), eq(schema.companies.orgId, orgId))).limit(1);
    if (!c) throw new Error("Entreprise introuvable dans cet organisme.");
    companyId = c.id;
  }
  let tutorContactId: string | null = null;
  if (input.tutorContactId) {
    const [t] = await db.select({ id: schema.contacts.id, companyId: schema.contacts.companyId }).from(schema.contacts).where(and(eq(schema.contacts.id, input.tutorContactId), eq(schema.contacts.orgId, orgId))).limit(1);
    if (!t) throw new Error("Tuteur introuvable.");
    if (companyId && t.companyId !== companyId) throw new Error("Le tuteur doit être un contact de l'entreprise choisie.");
    tutorContactId = t.id;
  }
  let placement: typeof schema.placements.$inferSelect | null = null;
  if (input.placementId) {
    const [p] = await db.select().from(schema.placements).where(and(eq(schema.placements.id, input.placementId), eq(schema.placements.orgId, orgId))).limit(1);
    if (!p) throw new Error("Placement introuvable.");
    if (p.personId !== person.id) throw new Error("Le placement ne concerne pas cette personne.");
    placement = p;
  }

  const [dup] = await db
    .select({ id: schema.enrollments.id, reference: schema.enrollments.reference })
    .from(schema.enrollments)
    .where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.personId, person.id), eq(schema.enrollments.sessionId, session.id), inArray(schema.enrollments.status, ACTIVE_ENROLLMENT_STATUSES)))
    .limit(1);
  if (dup) throw new Error(`${person.firstName} ${person.lastName} a déjà une inscription active sur cette session (${dup.reference}).`);

  const places = await sessionPlaces(session.id);
  if (places.remaining <= 0) throw new Error(`Session complète : ${places.enrolled} inscription(s) pour ${places.capacity} place(s).`);
  if (group?.capacity) {
    const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.enrollments).where(and(eq(schema.enrollments.groupId, group.id), inArray(schema.enrollments.status, ACTIVE_ENROLLMENT_STATUSES)));
    if (n >= group.capacity) throw new Error(`Le groupe « ${group.name} » est complet (${n}/${group.capacity}).`);
  }

  // Version de programme figée : la version active du programme si elle existe, sinon celle de la session.
  const [sessionVersion] = await db.select().from(schema.programVersions).where(eq(schema.programVersions.id, session.programVersionId)).limit(1);
  let version = sessionVersion ?? null;
  if (version && version.status !== "active") {
    const [active] = await db.select().from(schema.programVersions).where(and(eq(schema.programVersions.programId, version.programId), eq(schema.programVersions.status, "active"))).orderBy(desc(schema.programVersions.version)).limit(1);
    if (active) version = active;
  }
  const hoursPlanned = input.hoursPlanned ?? version?.durationHours ?? 0;
  const startDate = input.startDate ?? session.startDate;
  const endDate = input.endDate ?? session.endDate;
  if (endDate < startDate) throw new Error("La date de fin du parcours précède sa date de début.");

  const pieces = await db.select().from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, orgId), eq(schema.requiredPieces.isActive, true))).orderBy(asc(schema.requiredPieces.position));
  const activity = session.isApprenticeship ? "cfa" : "of";
  const applicable = applicablePieces(pieces, { contractKind: input.contractKind, fundingKinds: [], activity });

  const enrollment = await db.transaction(async (tx) => {
    const reference = await nextEnrollmentReference(tx, orgId, Number(startDate.slice(0, 4)) || new Date().getFullYear());
    const [e] = await tx
      .insert(schema.enrollments)
      .values({
        orgId,
        sessionId: session.id,
        personId: person.id,
        groupId: group?.id ?? null,
        programVersionId: version?.id ?? session.programVersionId,
        reference,
        companyId,
        tutorContactId,
        commercialStatus: input.commercialStatus ?? (placement ? "accepte" : "sans_objet"),
        status: input.status ?? "preinscrit",
        contractKind: input.contractKind,
        contractNumber: input.contractNumber ?? null,
        startDate,
        endDate,
        hoursPlanned,
        priceCents: input.priceCents ?? session.priceCents ?? version?.priceCents ?? null,
        legacyHours: input.legacyHours ?? 0,
        legacyHoursNote: input.legacyHoursNote ?? null,
        placementId: placement?.id ?? null,
        quoteId: input.quoteId ?? null,
        examState: version && (await hasCertification(tx, version.programId)) ? "a_inscrire" : "non_concerne",
        isDemo: ctx.org.isDemo,
      })
      .returning();

    const personLabel = `${person.firstName} ${person.lastName}`;
    for (const p of applicable) {
      await tx.insert(schema.pieceSubmissions).values({ orgId, enrollmentId: e.id, requiredPieceId: p.id, status: "attendue", dueDate: pieceDueDate(p, startDate) });
      if (p.isRequired) {
        await createTaskOnce(
          {
            orgId,
            title: `Pièce manquante : ${p.label} (${personLabel})`,
            description: `Pièce attendue de ${p.providedBy === "entreprise" ? "l'entreprise" : p.providedBy === "financeur" ? "le financeur" : "l'apprenant"} pour l'inscription ${reference}.`,
            family: "administratif",
            entityType: "enrollment",
            entityId: e.id,
            entityLabel: `${reference} · ${personLabel}`,
            href: `/app/${orgId}/inscriptions/${e.id}?onglet=pieces`,
            assigneeRole: "admin_staff",
            dueDate: pieceDueDate(p, startDate),
            priority: "normale",
            createdBy: ctx.user.id,
            source: "automatique",
            isDemo: ctx.org.isDemo,
            idempotencyKey: `piece:${e.id}:${p.code}`,
          },
          tx,
        );
      }
    }
    if (placement) await tx.update(schema.placements).set({ enrollmentId: e.id, status: "place", decidedAt: placement.decidedAt ?? new Date() }).where(eq(schema.placements.id, placement.id));
    if (person.status === "candidat") await tx.update(schema.persons).set({ status: "apprenant" }).where(eq(schema.persons.id, person.id));
    await tx.insert(schema.enrollmentEvents).values({ enrollmentId: e.id, kind: "creation", toValue: e.status, reason: `Inscription ${reference} créée sur ${session.code} (version de programme figée).`, userId: ctx.user.id });
    return e;
  });
  // Placement (équipe A / CRM) : le besoin gagné est relayé ; sa tâche « need:<needId>:won » est résolue, jamais supprimée.
  if (placement) await resolveTaskByKey(orgId, `need:${placement.needId}:won`, `Inscription ${enrollment.reference} créée`, ctx.user.id);
  // Parcours automatique de financement : un échec ne remet jamais en cause l'inscription créée.
  try {
    await applyWorkflow({ orgId, userId: ctx.user.id }, enrollment.id);
  } catch (err) {
    console.error(`[workflows] Parcours non appliqué à l'inscription ${enrollment.reference} :`, err);
  }
  // Certification externe (TOSA, ICDL, TOEIC, Voltaire, CléA) prévue par la formation : inscription à suivre créée.
  try {
    await ensureCertificationRegistration(orgId, enrollment.id, { userId: ctx.user.id });
  } catch (err) {
    console.error(`[certifications] Inscription certification non créée pour ${enrollment.reference} :`, err);
  }
  return { enrollment, session, person, piecesCreated: applicable.length };
}

async function hasCertification(tx: Tx, programId: string) {
  const [p] = await tx.select({ c: schema.programs.certificationId }).from(schema.programs).where(eq(schema.programs.id, programId)).limit(1);
  return Boolean(p?.c);
}

/**
 * Recalcule les pièces attendues d'une inscription (changement de contrat ou financement connu) :
 * ajoute les pièces manquantes et leurs tâches, ne supprime jamais une pièce déjà déposée.
 */
export async function syncEnrollmentPieces(orgId: string, enrollmentId: string, userId: string | null) {
  const [e] = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
  if (!e) return { added: 0 };
  const [session] = await db.select({ isApprenticeship: schema.trainingSessions.isApprenticeship, startDate: schema.trainingSessions.startDate }).from(schema.trainingSessions).where(eq(schema.trainingSessions.id, e.sessionId)).limit(1);
  const [person] = await db.select({ firstName: schema.persons.firstName, lastName: schema.persons.lastName }).from(schema.persons).where(eq(schema.persons.id, e.personId)).limit(1);
  const fundings = await db.select({ kind: schema.fundings.kind }).from(schema.fundings).where(and(eq(schema.fundings.enrollmentId, e.id), eq(schema.fundings.orgId, orgId), ne(schema.fundings.status, "annule")));
  const pieces = await db.select().from(schema.requiredPieces).where(and(eq(schema.requiredPieces.orgId, orgId), eq(schema.requiredPieces.isActive, true))).orderBy(asc(schema.requiredPieces.position));
  const applicable = applicablePieces(pieces, { contractKind: e.contractKind, fundingKinds: fundings.map((f) => f.kind), activity: session?.isApprenticeship ? "cfa" : "of" });
  const existing = await db.select({ requiredPieceId: schema.pieceSubmissions.requiredPieceId }).from(schema.pieceSubmissions).where(eq(schema.pieceSubmissions.enrollmentId, e.id));
  const have = new Set(existing.map((x) => x.requiredPieceId));
  let added = 0;
  const startDate = e.startDate ?? session?.startDate ?? null;
  for (const p of applicable) {
    if (have.has(p.id)) continue;
    await db.insert(schema.pieceSubmissions).values({ orgId, enrollmentId: e.id, requiredPieceId: p.id, status: "attendue", dueDate: pieceDueDate(p, startDate) });
    if (p.isRequired) {
      await createTaskOnce({
        orgId,
        title: `Pièce manquante : ${p.label} (${person?.firstName ?? ""} ${person?.lastName ?? ""})`,
        family: "administratif",
        entityType: "enrollment",
        entityId: e.id,
        entityLabel: e.reference,
        href: `/app/${orgId}/inscriptions/${e.id}?onglet=pieces`,
        assigneeRole: "admin_staff",
        dueDate: pieceDueDate(p, startDate),
        createdBy: userId,
        isDemo: e.isDemo,
        idempotencyKey: `piece:${e.id}:${p.code}`,
      });
    }
    added++;
  }
  return { added };
}

/* ---------- Synthèse du dossier (F04) ---------- */

export type HoursSummary = {
  /** Heures prévues (plan) en heures entières. */
  plannedHours: number;
  /** Minutes programmées (séances planifiées non annulées, pause exclue). */
  scheduledMinutes: number;
  /** Minutes effectuées (présences comptées, lignes courantes). */
  doneMinutes: number;
  /** Minutes d'absences justifiées (durée des périodes concernées). */
  justifiedMinutes: number;
  /** Minutes validées (présences de périodes clôturées). */
  validatedMinutes: number;
  /** Solde historique (anciennes feuilles) : distinct, jamais additionné aux précédentes. */
  legacyHours: number;
  legacySheetsMinutes: number;
  legacyHoursNote: string | null;
};

export type MissingPiece = { submissionId: string; code: string; label: string; status: string; isRequired: boolean; providedBy: string; dueDate: string | null };

export type EnrollmentSummary = {
  enrollment: typeof schema.enrollments.$inferSelect;
  statuses: { commercial: string; enrollment: string; progression: string; funding: string; exam: string };
  hours: HoursSummary;
  missingPieces: MissingPiece[];
  openTasks: (typeof schema.tasks.$inferSelect)[];
  /** Prochaines actions lisibles (pièces, financement, examen, tâches) : la « prochaine action claire » du CDC. */
  nextActions: { label: string; href?: string; dueDate?: string | null; owner?: string | null; kind: "piece" | "funding" | "exam" | "task" | "status" }[];
};

const PRESENT_STATUSES = ["present", "retard", "depart_anticipe", "retard_et_depart"] as const;

/** Heures d'une inscription en lisant `attendances` + `periods` (0 si rien), solde historique séparé. */
export async function enrollmentHours(orgId: string, enrollmentId: string): Promise<HoursSummary | null> {
  const [e] = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
  if (!e) return null;
  const slotCond = e.groupId ? sql`(${schema.slots.groupId} is null or ${schema.slots.groupId} = ${e.groupId})` : sql`true`;
  const [sched] = await db
    .select({ minutes: sql<number>`coalesce(sum(greatest(0, (extract(epoch from (${schema.periods.endTime} - ${schema.periods.startTime})) / 60)::int - ${schema.periods.breakMinutes})), 0)::int` })
    .from(schema.periods)
    .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
    .where(and(eq(schema.slots.orgId, orgId), eq(schema.slots.sessionId, e.sessionId), ne(schema.slots.status, "annulee"), ne(schema.periods.status, "annulee"), slotCond));
  const att = await db
    .select({ status: schema.attendances.status, minutes: schema.attendances.minutesCounted, periodStatus: schema.periods.status, start: schema.periods.startTime, end: schema.periods.endTime, brk: schema.periods.breakMinutes })
    .from(schema.attendances)
    .innerJoin(schema.periods, eq(schema.periods.id, schema.attendances.periodId))
    .where(and(eq(schema.attendances.orgId, orgId), eq(schema.attendances.enrollmentId, e.id), eq(schema.attendances.isCurrent, true)));
  let doneMinutes = 0;
  let justifiedMinutes = 0;
  let validatedMinutes = 0;
  for (const a of att) {
    if ((PRESENT_STATUSES as readonly string[]).includes(a.status)) {
      doneMinutes += a.minutes;
      if (a.periodStatus === "cloturee") validatedMinutes += a.minutes;
    } else if (a.status === "absent_justifie") {
      justifiedMinutes += Math.max(0, minutesBetween(String(a.start).slice(0, 5), String(a.end).slice(0, 5)) - a.brk);
    }
  }
  const [legacy] = await db.select({ minutes: sql<number>`coalesce(sum(${schema.legacyAttendanceSheets.hours}), 0)::int` }).from(schema.legacyAttendanceSheets).where(and(eq(schema.legacyAttendanceSheets.orgId, orgId), eq(schema.legacyAttendanceSheets.enrollmentId, e.id)));
  return {
    plannedHours: e.hoursPlanned,
    scheduledMinutes: sched?.minutes ?? 0,
    doneMinutes,
    justifiedMinutes,
    validatedMinutes,
    legacyHours: e.legacyHours,
    legacySheetsMinutes: legacy?.minutes ?? 0,
    legacyHoursNote: e.legacyHoursNote,
  };
}

/**
 * Synthèse réutilisable du dossier : statuts distincts, heures (prévues / programmées / effectuées / justifiées /
 * validées, solde historique à part), pièces manquantes et tâches ouvertes liées (`tasks.entityType = "enrollment"`).
 */
export async function enrollmentSummary(orgId: string, enrollmentId: string): Promise<EnrollmentSummary | null> {
  const [e] = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
  if (!e) return null;
  const hours = (await enrollmentHours(orgId, e.id))!;
  const pieces = await db
    .select({
      submissionId: schema.pieceSubmissions.id,
      status: schema.pieceSubmissions.status,
      dueDate: schema.pieceSubmissions.dueDate,
      code: schema.requiredPieces.code,
      label: schema.requiredPieces.label,
      isRequired: schema.requiredPieces.isRequired,
      providedBy: schema.requiredPieces.providedBy,
    })
    .from(schema.pieceSubmissions)
    .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
    .where(and(eq(schema.pieceSubmissions.orgId, orgId), eq(schema.pieceSubmissions.enrollmentId, e.id), inArray(schema.pieceSubmissions.status, ["attendue", "refusee", "deposee"])))
    .orderBy(asc(schema.requiredPieces.position));
  const missingPieces: MissingPiece[] = pieces.map((p) => ({ ...p }));
  const openTasks = await db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, orgId), eq(schema.tasks.entityType, "enrollment"), eq(schema.tasks.entityId, e.id), inArray(schema.tasks.status, ["a_faire", "en_cours", "bloquee"])))
    .orderBy(asc(schema.tasks.dueDate), asc(schema.tasks.createdAt));

  const base = `/app/${orgId}/inscriptions/${e.id}`;
  const nextActions: EnrollmentSummary["nextActions"] = [];
  for (const p of missingPieces.filter((p) => p.isRequired && p.status !== "deposee")) {
    nextActions.push({ kind: "piece", label: `${p.status === "refusee" ? "Pièce refusée à redéposer" : "Pièce attendue"} : ${p.label}`, href: `${base}?onglet=pieces`, dueDate: p.dueDate, owner: p.providedBy });
  }
  for (const p of missingPieces.filter((p) => p.status === "deposee")) {
    nextActions.push({ kind: "piece", label: `Pièce à contrôler : ${p.label}`, href: `${base}?onglet=pieces`, dueDate: p.dueDate, owner: "organisme" });
  }
  if (e.fundingState === "a_definir") nextActions.push({ kind: "funding", label: "Financement à définir", href: `/app/${orgId}/financements?enrollment=${e.id}`, owner: "finance" });
  if (e.examState === "a_inscrire") nextActions.push({ kind: "exam", label: "Examen : inscription à une cohorte à faire", href: `/app/${orgId}/examens`, owner: "pedagogy_manager" });
  for (const t of openTasks) {
    if (t.idempotencyKey?.startsWith(`piece:${e.id}:`)) continue; // déjà représentée par la pièce
    nextActions.push({ kind: "task", label: t.title, href: t.href ?? `/app/${orgId}/taches`, dueDate: t.dueDate, owner: t.assigneeRole ?? (t.assigneeUserId ? "utilisateur" : null) });
  }
  return {
    enrollment: e,
    statuses: { commercial: e.commercialStatus, enrollment: e.status, progression: e.progression, funding: e.fundingState, exam: e.examState },
    hours,
    missingPieces,
    openTasks,
    nextActions,
  };
}

/** Journalise un événement du dossier (jamais effacé). */
export async function logEnrollmentEvent(enrollmentId: string, kind: string, opts: { from?: string | null; to?: string | null; reason?: string | null; userId?: string | null } = {}) {
  await db.insert(schema.enrollmentEvents).values({ enrollmentId, kind, fromValue: opts.from ?? null, toValue: opts.to ?? null, reason: opts.reason ?? null, userId: opts.userId ?? null });
}

/** Pièces manquantes (attendues ou refusées) sur un ensemble d'inscriptions : vue transversale `/pieces`. */
export async function missingPiecesCount(orgId: string, enrollmentIds: string[]) {
  if (!enrollmentIds.length) return new Map<string, number>();
  const rows = await db
    .select({ enrollmentId: schema.pieceSubmissions.enrollmentId, n: sql<number>`count(*)::int` })
    .from(schema.pieceSubmissions)
    .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
    .where(and(eq(schema.pieceSubmissions.orgId, orgId), inArray(schema.pieceSubmissions.enrollmentId, enrollmentIds), inArray(schema.pieceSubmissions.status, ["attendue", "refusee"]), eq(schema.requiredPieces.isRequired, true)))
    .groupBy(schema.pieceSubmissions.enrollmentId);
  return new Map(rows.map((r) => [r.enrollmentId, r.n]));
}
