/** Métriques pouvant recevoir un objectif (F15). Module pur. */
export const OBJECTIVE_METRICS = [
  { key: "enrollments_started", label: "Entrées en formation", unit: "count" },
  { key: "enrollments_active", label: "Inscriptions actives", unit: "count" },
  { key: "placements_done", label: "Placements réalisés", unit: "count" },
  { key: "hours_done", label: "Heures réalisées", unit: "hours" },
  { key: "invoiced", label: "Facturé HT", unit: "cents" },
  { key: "payments", label: "Encaissements", unit: "cents" },
  { key: "satisfaction", label: "Satisfaction à chaud", unit: "percent" },
  { key: "retour_enquetes", label: "Retour d'enquêtes", unit: "percent" },
  { key: "abandon", label: "Abandon (maximum)", unit: "percent" },
  { key: "reussite", label: "Réussite aux examens", unit: "percent" },
  { key: "evidences", label: "Preuves qualité enregistrées", unit: "count" },
] as const;

export type ObjectiveUnit = (typeof OBJECTIVE_METRICS)[number]["unit"];

export function formatObjectiveTarget(target: number, unit: string): string {
  if (unit === "cents") return `${(target / 100).toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €`;
  if (unit === "percent") return `${target} %`;
  if (unit === "hours") return `${target} h`;
  return String(target);
}
