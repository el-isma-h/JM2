import "server-only";
import { and, eq, gte, ilike, lt, type SQL } from "drizzle-orm";
import { addDays, parseISO } from "date-fns";
import { schema } from "@/db";

export type OrgAuditFilters = { user?: string; action?: string; entityType?: string; entityId?: string; from?: string; to?: string };

const UUID = /^[0-9a-f-]{36}$/i;
const DAY = /^\d{4}-\d{2}-\d{2}$/;

export function readOrgAuditFilters(sp: Record<string, string | string[] | undefined>): OrgAuditFilters {
  const one = (k: string) => {
    const v = sp[k];
    const s = (Array.isArray(v) ? v[0] : v)?.trim();
    return s ? s.slice(0, 80) : undefined;
  };
  return { user: one("user"), action: one("action"), entityType: one("entityType"), entityId: one("entityId"), from: one("from"), to: one("to") };
}

/** Conditions du journal d'un organisme : toujours filtré par orgId (isolation), puis par action, utilisateur, période, entité. */
export function orgAuditWhere(orgId: string, f: OrgAuditFilters): SQL {
  const c: SQL[] = [eq(schema.auditLogs.orgId, orgId)];
  if (f.user) c.push(UUID.test(f.user) ? eq(schema.auditLogs.userId, f.user) : ilike(schema.users.email, `%${f.user.replace(/[%_]/g, "")}%`));
  if (f.action) c.push(ilike(schema.auditLogs.action, `${f.action.replace(/[%_]/g, "")}%`));
  if (f.entityType && /^[a-z_]{2,40}$/.test(f.entityType)) c.push(eq(schema.auditLogs.entityType, f.entityType));
  if (f.entityId && UUID.test(f.entityId)) c.push(eq(schema.auditLogs.entityId, f.entityId));
  if (f.from && DAY.test(f.from)) c.push(gte(schema.auditLogs.createdAt, parseISO(f.from)));
  if (f.to && DAY.test(f.to)) c.push(lt(schema.auditLogs.createdAt, addDays(parseISO(f.to), 1)));
  return and(...c)!;
}
