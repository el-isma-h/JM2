/**
 * Règles d'éligibilité à une cohorte d'examen (F08), pures et testées dans __tests__/eligibility.test.ts.
 * Vérifiées côté serveur à chaque affectation : même organisme, même formation, statut d'inscription admis
 * (une inscription terminée reste éligible), capacité, absence de doublon. Une information transmise par
 * formulaire n'est jamais une autorisation.
 */

export const ELIGIBLE_ENROLLMENT_STATUSES = ["inscrit", "en_cours", "termine"] as const;

export type EligibilityInput = {
  cohort: { orgId: string; programId: string; capacity: number; status: string; membersCount: number };
  enrollment: { orgId: string; programId: string | null; status: string } | null;
  alreadyMember: boolean;
};

export type Eligibility = { ok: true } | { ok: false; reason: string };

export function checkEligibility(input: EligibilityInput): Eligibility {
  const { cohort, enrollment } = input;
  if (!enrollment) return { ok: false, reason: "Inscription introuvable dans cet organisme." };
  if (enrollment.orgId !== cohort.orgId) return { ok: false, reason: "L'inscription n'appartient pas au même organisme que la cohorte." };
  if (cohort.status === "terminee" || cohort.status === "annulee") return { ok: false, reason: "La cohorte est terminée ou annulée : aucune affectation possible." };
  if (!enrollment.programId || enrollment.programId !== cohort.programId) return { ok: false, reason: "La formation de l'inscription (programme de sa version) ne correspond pas à celle de la cohorte." };
  if (!(ELIGIBLE_ENROLLMENT_STATUSES as readonly string[]).includes(enrollment.status)) return { ok: false, reason: `Statut d'inscription « ${enrollment.status} » non éligible (attendu : inscrit, en cours ou terminé).` };
  if (input.alreadyMember) return { ok: false, reason: "Cette inscription est déjà membre de la cohorte." };
  if (cohort.membersCount >= cohort.capacity) return { ok: false, reason: `Capacité atteinte (${cohort.capacity} places).` };
  return { ok: true };
}

export type ExamResult = "admis" | "ajourne" | "partiel" | "rattrapage" | "absent";

/** Passage de l'état d'examen de l'inscription selon le résultat enregistré sur le membre. */
export function examStateForResult(result: ExamResult): "admis" | "ajourne" | "absent" | "rattrapage" {
  switch (result) {
    case "admis":
      return "admis";
    case "absent":
      return "absent";
    case "rattrapage":
    case "partiel":
      return "rattrapage";
    default:
      return "ajourne";
  }
}

/** Résultats partiels / rattrapage autorisés selon les options de la cohorte. */
export function resultAllowed(result: ExamResult, options: { partial?: boolean; retake?: boolean } | null | undefined): Eligibility {
  if (result === "partiel" && options?.partial === false) return { ok: false, reason: "Les résultats partiels ne sont pas retenus pour cette cohorte." };
  if (result === "rattrapage" && options?.retake === false) return { ok: false, reason: "Le rattrapage n'est pas retenu pour cette cohorte." };
  return { ok: true };
}
