import "server-only";
import { registerJobHandler, type JobHandler } from "@/server/jobs/registry";
import { markOverdueInvoices, relayOverdueSchedules } from "./service";
import { todayParis } from "@/lib/time";

/**
 * finance:overdue : marque « en retard » les factures échues non soldées et crée (ou résout) les tâches
 * d'échéancier dépassé sans facture (clé funding:<id>:due:<date>). À planifier quotidiennement
 * (RECURRING_JOBS du runner, géré par l'intégrateur) ; relançable depuis la page Factures.
 */
export const financeOverdueJob: JobHandler = async (job) => {
  const today = typeof job.payload.today === "string" ? job.payload.today : todayParis();
  const overdue = await markOverdueInvoices(job.orgId, today);
  const schedules = await relayOverdueSchedules(job.orgId, today);
  return { today, invoicesMarkedOverdue: overdue, ...schedules };
};

/**
 * Enregistré dans le registre partagé (`src/server/jobs/registry.ts`), sans cycle d'import.
 */
registerJobHandler("finance:overdue", financeOverdueJob);
