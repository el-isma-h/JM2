"use server";

import { revalidatePath } from "next/cache";
import { and, eq, gte, inArray, lte } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { assertSessionInScope, requireOrg, type OrgContext } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { existingPeriodsOn } from "@/server/planning/service";
import { findConflicts, generateSeriesDates, periodsForDay, resolveSchedule, type Conflict, type Rhythm, type Schedule } from "@/server/planning/rules";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const optUuid = z.preprocess((v) => (v === "" || v == null ? undefined : v), uuid.optional());
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide (AAAA-MM-JJ)");
const hhmm = z.string().regex(/^\d{2}:\d{2}$/, "Heure invalide (HH:mm)");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

function conflictMessage(conflicts: Conflict[]): string {
  const shown = conflicts.slice(0, 6).map((c) => c.message);
  const more = conflicts.length > 6 ? ` … et ${conflicts.length - 6} autre(s).` : "";
  return `Conflits détectés, aucune séance créée : ${shown.join(" ")}${more}`;
}

/** Vérifie que les références d'un formulaire appartiennent à l'organisme (un identifiant transmis n'est jamais une autorisation). */
async function checkRefs(ctx: OrgContext, refs: { moduleId?: string; trainerId?: string; roomId?: string; siteId?: string; groupId?: string; sessionId: string; programVersionId: string }) {
  if (refs.trainerId) {
    const [t] = await db.select({ id: schema.trainers.id }).from(schema.trainers).where(and(eq(schema.trainers.id, refs.trainerId), eq(schema.trainers.orgId, ctx.org.id))).limit(1);
    if (!t) throw new Error("Formateur inconnu dans cet organisme.");
  }
  if (refs.roomId) {
    const [r] = await db.select({ id: schema.rooms.id, siteId: schema.rooms.siteId }).from(schema.rooms).where(and(eq(schema.rooms.id, refs.roomId), eq(schema.rooms.orgId, ctx.org.id))).limit(1);
    if (!r) throw new Error("Salle inconnue dans cet organisme.");
    if (refs.siteId && r.siteId !== refs.siteId) throw new Error("La salle n'appartient pas au site choisi.");
  }
  if (refs.siteId) {
    const [s] = await db.select({ id: schema.sites.id }).from(schema.sites).where(and(eq(schema.sites.id, refs.siteId), eq(schema.sites.orgId, ctx.org.id))).limit(1);
    if (!s) throw new Error("Site inconnu dans cet organisme.");
  }
  if (refs.groupId) {
    const [g] = await db.select({ id: schema.groups.id }).from(schema.groups).where(and(eq(schema.groups.id, refs.groupId), eq(schema.groups.sessionId, refs.sessionId), eq(schema.groups.orgId, ctx.org.id))).limit(1);
    if (!g) throw new Error("Groupe inconnu pour cette session.");
  }
  if (refs.moduleId) {
    const [m] = await db.select({ id: schema.modules.id }).from(schema.modules).where(and(eq(schema.modules.id, refs.moduleId), eq(schema.modules.orgId, ctx.org.id), eq(schema.modules.programVersionId, refs.programVersionId))).limit(1);
    if (!m) throw new Error("Module inconnu pour le programme de cette session.");
  }
}

async function loadSession(ctx: OrgContext, sessionId: string) {
  const [s] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, sessionId), eq(schema.trainingSessions.orgId, ctx.org.id))).limit(1);
  if (!s) throw new Error("Session introuvable.");
  await assertSessionInScope(ctx, s.id);
  return s;
}

async function conflictContext(ctx: OrgContext, dates: string[], trainerId?: string) {
  if (!dates.length) return { existing: [], unavailabilities: [], closures: [] };
  const from = dates.reduce((a, b) => (a < b ? a : b));
  const to = dates.reduce((a, b) => (a > b ? a : b));
  const [existing, unavailabilities, closures] = await Promise.all([
    existingPeriodsOn(ctx.org.id, dates),
    trainerId
      ? db
          .select({ trainerId: schema.trainerUnavailabilities.trainerId, startDate: schema.trainerUnavailabilities.startDate, endDate: schema.trainerUnavailabilities.endDate, part: schema.trainerUnavailabilities.part })
          .from(schema.trainerUnavailabilities)
          .where(and(eq(schema.trainerUnavailabilities.orgId, ctx.org.id), eq(schema.trainerUnavailabilities.trainerId, trainerId), lte(schema.trainerUnavailabilities.startDate, to), gte(schema.trainerUnavailabilities.endDate, from)))
      : Promise.resolve([]),
    db
      .select({ startDate: schema.closures.startDate, endDate: schema.closures.endDate, siteId: schema.closures.siteId })
      .from(schema.closures)
      .where(and(eq(schema.closures.orgId, ctx.org.id), lte(schema.closures.startDate, to), gte(schema.closures.endDate, from))),
  ]);
  return { existing, unavailabilities, closures };
}

const partsSchema = z.preprocess((v) => (Array.isArray(v) ? v : v ? [v] : []), z.array(z.enum(["matin", "apres_midi"])).min(1, "Choisissez au moins une période (matin, après-midi)."));

const seriesSchema = z.object({
  sessionId: uuid,
  from: isoDate,
  to: isoDate,
  parts: partsSchema,
  moduleId: optUuid,
  trainerId: optUuid,
  roomId: optUuid,
  siteId: optUuid,
  groupId: optUuid,
  title: z.string().trim().max(160).optional(),
  weekdays: z.preprocess((v) => (Array.isArray(v) ? v : v ? [v] : []), z.array(z.coerce.number().int().min(1).max(7))).optional(),
  morningStart: hhmm.optional().or(z.literal("")),
  morningEnd: hhmm.optional().or(z.literal("")),
  afternoonStart: hhmm.optional().or(z.literal("")),
  afternoonEnd: hhmm.optional().or(z.literal("")),
  force: z.preprocess((v) => v === "1" || v === "on", z.boolean()).optional(),
});

function readForm(formData: FormData) {
  const obj: Record<string, unknown> = {};
  for (const [k, v] of formData.entries()) {
    if (k in obj) obj[k] = Array.isArray(obj[k]) ? [...(obj[k] as unknown[]), v] : [obj[k], v];
    else obj[k] = v;
  }
  return obj;
}

/**
 * Création de séances en série (F05) : dates selon le rythme de la session (jours de centre), horaires de la session
 * sinon de l'organisme, une ou deux périodes indépendantes par jour. Conflits détectés avant toute écriture.
 */
export async function createSlotSeriesAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "planning.manage");
    const d = seriesSchema.parse(readForm(formData));
    if (d.from > d.to) return { error: "La date de fin précède la date de début." };
    const session = await loadSession(ctx, d.sessionId);
    await checkRefs(ctx, { ...d, sessionId: session.id, programVersionId: session.programVersionId });
    const rhythm = (session.rhythm ?? {}) as Rhythm;
    const weekdays = d.weekdays?.length ? d.weekdays : rhythm.weekdays;
    const orgSchedule = (ctx.org.settings ?? {}) as Schedule;
    const base = resolveSchedule(session.schedule as Schedule, orgSchedule);
    const schedule = {
      morning: d.morningStart && d.morningEnd ? { start: d.morningStart, end: d.morningEnd } : base.morning,
      afternoon: d.afternoonStart && d.afternoonEnd ? { start: d.afternoonStart, end: d.afternoonEnd } : base.afternoon,
    };
    for (const p of [schedule.morning, schedule.afternoon]) if (p.start >= p.end) return { error: "Horaires incohérents : la fin doit suivre le début." };
    const siteId = d.siteId ?? session.siteId ?? undefined;
    const closures = await db
      .select({ startDate: schema.closures.startDate, endDate: schema.closures.endDate, siteId: schema.closures.siteId })
      .from(schema.closures)
      .where(and(eq(schema.closures.orgId, ctx.org.id), lte(schema.closures.startDate, d.to), gte(schema.closures.endDate, d.from)));
    const dates = generateSeriesDates({ from: d.from, to: d.to, weekdays, closures, siteId });
    if (!dates.length) return { error: "Aucune date ne correspond : vérifiez les jours de centre et les fermetures." };
    const planned = dates.flatMap((date) => periodsForDay(date, d.parts, schedule));
    const trainerId = d.trainerId ?? undefined;
    const roomId = d.roomId ?? session.roomId ?? undefined;
    const cc = await conflictContext(ctx, dates, trainerId);
    const conflicts = findConflicts({ planned, trainerId, roomId, groupId: d.groupId, siteId, ...cc });
    if (conflicts.length && !d.force) return { error: conflictMessage(conflicts) };

    const created = await db.transaction(async (tx) => {
      let n = 0;
      for (const date of dates) {
        const [slot] = await tx
          .insert(schema.slots)
          .values({ orgId: ctx.org.id, sessionId: session.id, groupId: d.groupId ?? null, date, title: d.title || null, moduleId: d.moduleId ?? null, siteId: siteId ?? null, roomId: roomId ?? null, trainerId: trainerId ?? null, modality: session.modality, status: "prevue" })
          .returning({ id: schema.slots.id });
        for (const p of periodsForDay(date, d.parts, schedule)) {
          await tx.insert(schema.periods).values({ orgId: ctx.org.id, slotId: slot.id, part: p.part, startTime: p.startTime, endTime: p.endTime, trainerId: trainerId ?? null, roomId: roomId ?? null, status: "prevue" });
          n++;
        }
      }
      return n;
    });
    await audit({ action: "slot.series.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "session", entityId: session.id, after: { from: d.from, to: d.to, parts: d.parts, dates: dates.length, periods: created, forcedConflicts: conflicts.length } });
    revalidatePath(`/app/${ctx.org.id}/planning`);
    return { ok: true, message: `${dates.length} séance(s) et ${created} période(s) créées.${conflicts.length ? ` ${conflicts.length} conflit(s) accepté(s) explicitement.` : ""}` };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

async function orgIdOf(formData: FormData) {
  return uuid.parse(formData.get("orgId"));
}

const slotUpdateSchema = z.object({
  slotId: uuid,
  moduleId: optUuid,
  trainerId: optUuid,
  roomId: optUuid,
  siteId: optUuid,
  groupId: optUuid,
  title: z.string().trim().max(160).optional(),
  notes: z.string().trim().max(2000).optional(),
  status: z.enum(["prevue", "confirmee", "reportee"]).optional(),
  force: z.preprocess((v) => v === "1" || v === "on", z.boolean()).optional(),
});

/** Modification d'une séance : refusée si une de ses périodes est clôturée ; conflits vérifiés. */
export async function updateSlotAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "planning.manage");
    const d = slotUpdateSchema.parse(readForm(formData));
    const [slot] = await db.select().from(schema.slots).where(and(eq(schema.slots.id, d.slotId), eq(schema.slots.orgId, ctx.org.id))).limit(1);
    if (!slot) return { error: "Séance introuvable." };
    const session = await loadSession(ctx, slot.sessionId);
    await checkRefs(ctx, { ...d, sessionId: session.id, programVersionId: session.programVersionId });
    const periods = await db.select().from(schema.periods).where(eq(schema.periods.slotId, slot.id));
    if (periods.some((p) => p.status === "cloturee")) return { error: "Séance verrouillée : une de ses périodes est clôturée. Passez par une demande de correction." };
    const trainerId = d.trainerId ?? undefined;
    const roomId = d.roomId ?? undefined;
    const cc = await conflictContext(ctx, [slot.date], trainerId);
    const conflicts = findConflicts({ planned: periods.filter((p) => p.status !== "annulee").map((p) => ({ date: slot.date, startTime: p.startTime, endTime: p.endTime, part: p.part })), trainerId, roomId, groupId: d.groupId, siteId: d.siteId, ...cc, ignoreSlotId: slot.id });
    if (conflicts.length && !d.force) return { error: conflictMessage(conflicts) };
    await db.transaction(async (tx) => {
      await tx
        .update(schema.slots)
        .set({ moduleId: d.moduleId ?? null, trainerId: trainerId ?? null, roomId: roomId ?? null, siteId: d.siteId ?? null, groupId: d.groupId ?? null, title: d.title || null, notes: d.notes || null, status: d.status ?? slot.status, updatedAt: new Date() })
        .where(eq(schema.slots.id, slot.id));
      await tx.update(schema.periods).set({ trainerId: trainerId ?? null, roomId: roomId ?? null, updatedAt: new Date() }).where(and(eq(schema.periods.slotId, slot.id), inArray(schema.periods.status, ["prevue", "ouverte"])));
    });
    await audit({ action: "slot.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "slot", entityId: slot.id, before: slot, after: d });
    revalidatePath(`/app/${ctx.org.id}/planning`);
    return { ok: true, message: "Séance mise à jour." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

/** Annulation d'une séance non clôturée (statut, jamais de suppression). */
export async function cancelSlotAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "planning.manage");
    const slotId = uuid.parse(formData.get("slotId"));
    const reason = z.string().trim().min(3, "Indiquez le motif d'annulation.").max(500).parse(formData.get("reason"));
    const [slot] = await db.select().from(schema.slots).where(and(eq(schema.slots.id, slotId), eq(schema.slots.orgId, ctx.org.id))).limit(1);
    if (!slot) return { error: "Séance introuvable." };
    await assertSessionInScope(ctx, slot.sessionId);
    const periods = await db.select().from(schema.periods).where(eq(schema.periods.slotId, slot.id));
    if (periods.some((p) => p.status === "cloturee")) return { error: "Séance verrouillée : une de ses périodes est clôturée, annulation refusée." };
    await db.transaction(async (tx) => {
      await tx.update(schema.slots).set({ status: "annulee", notes: [slot.notes, `Annulée : ${reason}`].filter(Boolean).join("\n"), updatedAt: new Date() }).where(eq(schema.slots.id, slot.id));
      await tx.update(schema.periods).set({ status: "annulee", updatedAt: new Date() }).where(eq(schema.periods.slotId, slot.id));
    });
    await audit({ action: "slot.cancel", userId: ctx.user.id, orgId: ctx.org.id, entityType: "slot", entityId: slot.id, before: { status: slot.status }, after: { status: "annulee", reason } });
    revalidatePath(`/app/${ctx.org.id}/planning`);
    return { ok: true, message: "Séance annulée (conservée dans l'historique)." };
  } catch (e) {
    return fail(e, "Annulation impossible.");
  }
}

const unavailabilitySchema = z.object({ trainerId: uuid, startDate: isoDate, endDate: isoDate, part: z.enum(["matin", "apres_midi", "journee"]).default("journee"), reason: z.string().trim().max(200).optional() });

/** Indisponibilité d'un formateur (prise en compte par la détection de conflits). */
export async function addUnavailabilityAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "planning.manage");
    const d = unavailabilitySchema.parse(Object.fromEntries(formData));
    if (d.startDate > d.endDate) return { error: "La date de fin précède la date de début." };
    const [t] = await db.select({ id: schema.trainers.id }).from(schema.trainers).where(and(eq(schema.trainers.id, d.trainerId), eq(schema.trainers.orgId, ctx.org.id))).limit(1);
    if (!t) return { error: "Formateur inconnu." };
    const [row] = await db.insert(schema.trainerUnavailabilities).values({ orgId: ctx.org.id, trainerId: d.trainerId, startDate: d.startDate, endDate: d.endDate, part: d.part, reason: d.reason || null }).returning({ id: schema.trainerUnavailabilities.id });
    await audit({ action: "trainer.unavailability.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "trainer_unavailability", entityId: row.id, after: d });
    revalidatePath(`/app/${ctx.org.id}/planning`);
    return { ok: true, message: "Indisponibilité enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

const closureSchema = z.object({ startDate: isoDate, endDate: isoDate, reason: z.string().trim().min(2, "Motif requis").max(200), siteId: optUuid });

/** Fermeture de l'organisme ou d'un site (jours fériés, congés) : exclue de la génération en série. */
export async function addClosureAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "planning.manage");
    const d = closureSchema.parse(Object.fromEntries(formData));
    if (d.startDate > d.endDate) return { error: "La date de fin précède la date de début." };
    if (d.siteId) {
      const [s] = await db.select({ id: schema.sites.id }).from(schema.sites).where(and(eq(schema.sites.id, d.siteId), eq(schema.sites.orgId, ctx.org.id))).limit(1);
      if (!s) return { error: "Site inconnu." };
    }
    const [row] = await db.insert(schema.closures).values({ orgId: ctx.org.id, startDate: d.startDate, endDate: d.endDate, reason: d.reason, siteId: d.siteId ?? null }).returning({ id: schema.closures.id });
    await audit({ action: "closure.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "closure", entityId: row.id, after: d });
    revalidatePath(`/app/${ctx.org.id}/planning`);
    return { ok: true, message: "Fermeture enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}
