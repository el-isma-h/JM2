import { describe, expect, it } from "vitest";
import { addWorkdays, eurosToCents, missionAmountCents, reminderStep, workdaysElapsed } from "../rules";

describe("missions : montant", () => {
  it("multiplie heures et taux horaire (centimes)", () => {
    expect(missionAmountCents(21, 2500)).toBe(52500);
    expect(missionAmountCents(0, 2500)).toBe(0);
  });
  it("refuse les valeurs invalides", () => {
    expect(() => missionAmountCents(-1, 2500)).toThrow();
    expect(() => missionAmountCents(1.5, 2500)).toThrow();
    expect(() => missionAmountCents(2, -10)).toThrow();
  });
  it("convertit une saisie en euros", () => {
    expect(eurosToCents("25")).toBe(2500);
    expect(eurosToCents("25,5")).toBe(2550);
    expect(eurosToCents("32.75 €")).toBe(3275);
    expect(eurosToCents("")).toBeNull();
    expect(() => eurosToCents("abc")).toThrow();
  });
});

describe("missions : jours ouvrés", () => {
  it("ne compte ni le jour de départ, ni les week-ends", () => {
    // vendredi 30 octobre 2026 → lundi 2 novembre 2026
    expect(workdaysElapsed("2026-10-30", "2026-11-02")).toBe(1);
    expect(workdaysElapsed("2026-10-30", "2026-10-30")).toBe(0);
  });
  it("exclut les jours fériés (11 novembre)", () => {
    expect(workdaysElapsed("2026-11-04", "2026-11-12")).toBe(5);
    expect(addWorkdays("2026-11-04", 5)).toBe("2026-11-12");
  });
});

describe("missions : relance puis sans réponse", () => {
  it("relance après 5 jours ouvrés", () => {
    expect(reminderStep({ proposedOn: "2026-11-04", remindedOn: null, today: "2026-11-10" })).toBe("none");
    expect(reminderStep({ proposedOn: "2026-11-04", remindedOn: null, today: "2026-11-12" })).toBe("remind");
  });
  it("passe en sans réponse après le délai de grâce suivant la relance", () => {
    expect(reminderStep({ proposedOn: "2026-11-04", remindedOn: "2026-11-12", today: "2026-11-13" })).toBe("none");
    expect(reminderStep({ proposedOn: "2026-11-04", remindedOn: "2026-11-12", today: "2026-11-16" })).toBe("no_response");
    expect(reminderStep({ proposedOn: "2026-11-04", remindedOn: "2026-11-12", today: "2026-11-13", graceDays: 1 })).toBe("no_response");
  });
});
