import "server-only";
import PDFDocument from "pdfkit";
import type { schema } from "@/db";

export type Org = typeof schema.organismes.$inferSelect;

/** Polices PDF standard : retire les espaces fines insécables produites par Intl (fr-FR). */
export const clean = (s: string | null | undefined) => (s ?? "").replace(/[  ]/g, " ");

export const INK = "#0a0b0d";
export const MUTED = "#6b6760";
export const LINE = "#d9d5cb";

export function newPdf(title: string) {
  const doc = new PDFDocument({ size: "A4", bufferPages: true, margins: { top: 56, bottom: 64, left: 56, right: 56 }, info: { Title: title, Creator: "Next Formation" } });
  const chunks: Buffer[] = [];
  doc.on("data", (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });
  return { doc, done };
}

/** En-tête : identité institutionnelle de l'organisme concerné uniquement (F10). */
export function writeOrgHeader(doc: PDFKit.PDFDocument, org: Org, kicker: string) {
  const accent = /^#[0-9a-f]{6}$/i.test(org.primaryColor) ? org.primaryColor : "#4b2a7f";
  doc.font("Helvetica-Bold").fontSize(14).fillColor(INK).text(clean(org.tradeName ?? org.legalName));
  doc.font("Helvetica").fontSize(8.5).fillColor(MUTED);
  const lines = [
    org.tradeName && org.tradeName !== org.legalName ? org.legalName : null,
    [org.addressLine1, org.addressLine2].filter(Boolean).join(", ") || null,
    [org.postalCode, org.city].filter(Boolean).join(" ") || null,
    org.siret ? `SIRET ${org.siret}` : org.siren ? `SIREN ${org.siren}` : null,
    org.nda ? `Déclaration d'activité n° ${org.nda}${org.ndaRegion ? ` (${org.ndaRegion})` : ""}` : null,
    org.vatNumber ? `TVA ${org.vatNumber}` : null,
    [org.email, org.phone].filter(Boolean).join(" · ") || null,
  ].filter(Boolean) as string[];
  for (const l of lines) doc.text(clean(l));
  doc.moveDown(0.8);
  doc.font("Helvetica").fontSize(9).fillColor(accent).text(kicker.toUpperCase(), { characterSpacing: 2 });
  doc.moveTo(doc.page.margins.left, doc.y + 4).lineTo(doc.page.width - doc.page.margins.right, doc.y + 4).strokeColor(accent).lineWidth(1).stroke();
  doc.moveDown(1);
  doc.fillColor(INK);
}

export function writeFooter(doc: PDFKit.PDFDocument, org: Org, extra?: string) {
  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);
    const y = doc.page.height - doc.page.margins.bottom + 16;
    doc.font("Helvetica").fontSize(7.5).fillColor(MUTED);
    const text = [org.documentFooter, extra, `Page ${i - range.start + 1} / ${range.count}`].filter(Boolean).map(clean).join("   ·   ");
    doc.text(text, doc.page.margins.left, y, { width: doc.page.width - doc.page.margins.left - doc.page.margins.right, align: "center", lineBreak: false });
  }
}

export function section(doc: PDFKit.PDFDocument, title: string) {
  doc.moveDown(0.6);
  doc.font("Helvetica-Bold").fontSize(10.5).fillColor(INK).text(clean(title));
  doc.moveDown(0.2);
  doc.font("Helvetica").fontSize(9.5);
}

export function para(doc: PDFKit.PDFDocument, text: string | null | undefined, fallback = "[À COMPLÉTER]") {
  const t = clean(text);
  doc.font("Helvetica").fontSize(9.5).fillColor(t ? INK : "#8a5a00").text(t || fallback, { lineGap: 2 });
  doc.fillColor(INK);
}
