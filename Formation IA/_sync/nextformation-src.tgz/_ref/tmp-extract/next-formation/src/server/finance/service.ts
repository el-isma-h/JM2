import "server-only";
import { and, asc, desc, eq, inArray, ne, sql } from "drizzle-orm";
import { addDays, format, parseISO } from "date-fns";
import { db, schema } from "@/db";
import { numberingPrefix } from "@/server/numbering";
import type { OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { createDocument } from "@/server/documents/store";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { todayParis } from "@/lib/time";
import {
  deriveFundingState,
  formatInvoiceNumber,
  invoiceTotals,
  isOverdue,
  nextScheduleLine,
  overdueScheduleLines,
  paymentStatus,
  sequenceKindFor,
  VAT_EXEMPT_MENTION,
  DEFAULT_PAYMENT_TERMS,
  type FundingStatus,
  type InvoiceKind,
  type InvoiceStatus,
  type ScheduleLine,
} from "./compute";
import { renderInvoicePdf, type BillTo } from "./pdf";

export type Invoice = typeof schema.invoices.$inferSelect;
export type Funding = typeof schema.fundings.$inferSelect;

export const OPEN_INVOICE_STATUSES: InvoiceStatus[] = ["emise", "envoyee", "partiellement_payee", "en_retard"];
export const ISSUED_STATUSES: InvoiceStatus[] = ["emise", "envoyee", "partiellement_payee", "payee", "en_retard"];

export function readSchedule(v: unknown): ScheduleLine[] {
  if (!Array.isArray(v)) return [];
  return v
    .filter((l): l is ScheduleLine => Boolean(l) && typeof l === "object" && typeof (l as ScheduleLine).dueDate === "string")
    .map((l) => ({ label: String(l.label ?? ""), dueDate: l.dueDate, amountCents: Number(l.amountCents) || 0, invoiceId: l.invoiceId ?? null }));
}

export function readBillTo(v: unknown): BillTo {
  const b = (v ?? {}) as Partial<BillTo>;
  return {
    kind: b.kind ?? "entreprise",
    name: b.name ?? "",
    addressLine1: b.addressLine1 ?? "",
    addressLine2: b.addressLine2 ?? "",
    postalCode: b.postalCode ?? "",
    city: b.city ?? "",
    siret: b.siret ?? "",
    vatNumber: b.vatNumber ?? "",
    email: b.email ?? "",
  };
}

/* ---------- Inscription : état de financement ---------- */

/** Recalcule `enrollments.fundingState` à partir des financements. Jamais appelé par la clôture pédagogique. */
export async function recalcEnrollmentFundingState(orgId: string, enrollmentId: string, userId?: string | null) {
  const rows = await db
    .select({ status: schema.fundings.status })
    .from(schema.fundings)
    .where(and(eq(schema.fundings.orgId, orgId), eq(schema.fundings.enrollmentId, enrollmentId)));
  const next = deriveFundingState(rows);
  const [e] = await db.select({ fundingState: schema.enrollments.fundingState }).from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
  if (!e || e.fundingState === next) return next;
  await db.update(schema.enrollments).set({ fundingState: next }).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId)));
  await db.insert(schema.enrollmentEvents).values({ enrollmentId, kind: "funding_state", fromValue: e.fundingState, toValue: next, reason: "Recalcul depuis les financements", userId: userId ?? null });
  return next;
}

/** Met un financement dans un nouveau statut (sans vérifier les règles : l'appelant a validé). */
export async function setFundingStatus(orgId: string, fundingId: string, to: FundingStatus, userId: string | null, reason: string) {
  const [before] = await db.select().from(schema.fundings).where(and(eq(schema.fundings.id, fundingId), eq(schema.fundings.orgId, orgId))).limit(1);
  if (!before || before.status === to) return before ?? null;
  const [after] = await db.update(schema.fundings).set({ status: to }).where(eq(schema.fundings.id, fundingId)).returning();
  await audit({ action: "funding.status", userId, orgId, entityType: "funding", entityId: fundingId, before: { status: before.status }, after: { status: to, reason } });
  await recalcEnrollmentFundingState(orgId, before.enrollmentId, userId);
  return after;
}

/* ---------- Relais (F14) ---------- */

export const agreementPieceKey = (fundingId: string) => `funding:${fundingId}:accord_prise_en_charge`;
export const scheduleDueKey = (fundingId: string, dueDate: string) => `funding:${fundingId}:due:${dueDate}`;

/** Passage « accordé » : tâche admin_staff « Pièce : accord de prise en charge », résolue si le document est déjà déposé. */
export async function relayFundingGranted(orgId: string, funding: Funding, userId: string | null, isDemo: boolean) {
  const key = agreementPieceKey(funding.id);
  if (funding.documentId) {
    await resolveTaskByKey(orgId, key, "Accord de prise en charge déjà déposé.", userId);
    return;
  }
  const [enr] = await db.select({ reference: schema.enrollments.reference, startDate: schema.enrollments.startDate }).from(schema.enrollments).where(eq(schema.enrollments.id, funding.enrollmentId)).limit(1);
  await createTaskOnce({
    orgId,
    title: "Pièce : accord de prise en charge",
    description: `Déposer l'accord de prise en charge du financeur (${funding.label}) sur le financement.`,
    family: "administratif",
    entityType: "funding",
    entityId: funding.id,
    entityLabel: enr?.reference ?? funding.label,
    href: `/app/${orgId}/financements/${funding.id}`,
    assigneeRole: "admin_staff",
    dueDate: enr?.startDate ?? null,
    prerequisites: [{ label: "Document d'accord reçu du financeur", done: false }],
    createdBy: userId,
    idempotencyKey: key,
    isDemo,
  });
}

/** Échéances dépassées sans facture : une tâche finance par échéance (clé funding:<id>:due:<date>). */
export async function relayOverdueSchedules(orgId: string | null, today = todayParis()) {
  const rows = await db
    .select({ f: schema.fundings, isDemo: schema.enrollments.isDemo, reference: schema.enrollments.reference })
    .from(schema.fundings)
    .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.fundings.enrollmentId))
    .where(and(orgId ? eq(schema.fundings.orgId, orgId) : undefined, inArray(schema.fundings.status, ["accorde", "facture"])));
  let created = 0;
  let resolved = 0;
  for (const { f, isDemo, reference } of rows) {
    const schedule = readSchedule(f.schedule);
    for (const line of overdueScheduleLines(schedule, today)) {
      const r = await createTaskOnce({
        orgId: f.orgId,
        title: `Échéance dépassée à facturer : ${line.label}`,
        description: `L'échéance du ${line.dueDate} (${(line.amountCents / 100).toFixed(2)} €) du financement « ${f.label} » n'a pas de facture.`,
        family: "finance",
        entityType: "funding",
        entityId: f.id,
        entityLabel: reference,
        href: `/app/${f.orgId}/financements/${f.id}`,
        assigneeRole: "finance",
        dueDate: line.dueDate,
        priority: "haute",
        idempotencyKey: scheduleDueKey(f.id, line.dueDate),
        isDemo,
      });
      if (r.created) created++;
    }
    for (const line of schedule.filter((l) => l.invoiceId)) {
      if (await resolveTaskByKey(f.orgId, scheduleDueKey(f.id, line.dueDate), "Échéance facturée.")) resolved++;
    }
  }
  return { fundings: rows.length, created, resolved };
}

/* ---------- Factures ---------- */

/** Recalcule `paidCents` et le statut de paiement depuis les règlements (trop-perçu interdit en amont). */
export async function recalcInvoicePayment(orgId: string, invoiceId: string, userId?: string | null) {
  const [inv] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, invoiceId), eq(schema.invoices.orgId, orgId))).limit(1);
  if (!inv) return null;
  const [{ paid }] = await db.select({ paid: sql<number>`coalesce(sum(${schema.payments.amountCents}), 0)::int` }).from(schema.payments).where(and(eq(schema.payments.invoiceId, invoiceId), eq(schema.payments.orgId, orgId)));
  const today = todayParis();
  const overdue = isOverdue({ status: inv.status, dueDate: inv.dueDate, totalTtcCents: inv.totalTtcCents, paidCents: paid, kind: inv.kind }, today);
  const status = paymentStatus({ kind: inv.kind, status: inv.status, totalTtcCents: inv.totalTtcCents, paidCents: paid, sentAt: inv.sentAt, overdue });
  const paidAt = status === "payee" ? (inv.paidAt ?? new Date()) : null;
  const [upd] = await db.update(schema.invoices).set({ paidCents: paid, status, paidAt }).where(eq(schema.invoices.id, invoiceId)).returning();
  if (inv.status !== status) {
    await audit({ action: "invoice.payment_status", userId, orgId, entityType: "invoice", entityId: invoiceId, before: { status: inv.status, paidCents: inv.paidCents }, after: { status, paidCents: paid } });
  }
  if (inv.fundingId) await syncFundingFromInvoices(orgId, inv.fundingId, userId);
  return upd;
}

/** Un financement est « facturé » dès qu'une facture émise lui est rattachée et « soldé » quand toutes sont payées. */
export async function syncFundingFromInvoices(orgId: string, fundingId: string, userId?: string | null) {
  const [f] = await db.select().from(schema.fundings).where(and(eq(schema.fundings.id, fundingId), eq(schema.fundings.orgId, orgId))).limit(1);
  if (!f || f.status === "annule" || f.status === "refuse") return;
  const invs = await db
    .select({ status: schema.invoices.status, kind: schema.invoices.kind, totalTtcCents: schema.invoices.totalTtcCents, paidCents: schema.invoices.paidCents })
    .from(schema.invoices)
    .where(and(eq(schema.invoices.orgId, orgId), eq(schema.invoices.fundingId, fundingId), inArray(schema.invoices.status, ISSUED_STATUSES), inArray(schema.invoices.kind, ["facture", "acompte"])));
  if (!invs.length) return;
  const billed = invs.reduce((a, i) => a + i.totalTtcCents, 0);
  const paid = invs.reduce((a, i) => a + i.paidCents, 0);
  const target: FundingStatus = billed >= f.amountCents && paid >= billed ? "solde" : "facture";
  if (f.status !== target && (f.status === "accorde" || f.status === "facture")) {
    await setFundingStatus(orgId, fundingId, target, userId ?? null, target === "solde" ? "Toutes les factures sont payées" : "Facture émise");
  }
}

/** Numéro suivant pour (organisme, famille, année) dans une transaction verrouillée. */
async function nextNumber(tx: Parameters<Parameters<typeof db.transaction>[0]>[0], orgId: string, kind: InvoiceKind, year: number): Promise<string> {
  const seqKind = sequenceKindFor(kind);
  await tx.insert(schema.invoiceSequences).values({ orgId, kind: seqKind, year, next: 1 }).onConflictDoNothing();
  const res = await tx.execute<{ id: string; next: number }>(
    sql`select id, next from ${schema.invoiceSequences} where org_id = ${orgId} and kind = ${seqKind} and year = ${year} for update`,
  );
  const row = res.rows[0];
  if (!row) throw new Error("Compteur de numérotation introuvable.");
  const seq = Number(row.next);
  await tx.update(schema.invoiceSequences).set({ next: seq + 1 }).where(eq(schema.invoiceSequences.id, row.id));
  const prefix = kind === "avoir" ? await numberingPrefix(orgId, "credit", "AV") : kind === "proforma" ? undefined : await numberingPrefix(orgId, "invoice", "F");
  return formatInvoiceNumber(kind, year, seq, prefix);
}

export async function orgIdentity(orgId: string) {
  const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  return org ?? null;
}

/**
 * Émission d'une facture ou d'un avoir : numérotation continue (verrou), montants figés depuis les lignes,
 * mentions légales, PDF archivé (catégorie facture / avoir), audit. Un brouillon sans ligne ou sans destinataire est refusé.
 */
export async function issueInvoice(ctx: OrgContext, invoiceId: string): Promise<Invoice> {
  const orgId = ctx.org.id;
  const [inv] = await db.select().from(schema.invoices).where(and(eq(schema.invoices.id, invoiceId), eq(schema.invoices.orgId, orgId))).limit(1);
  if (!inv) throw new Error("Facture introuvable.");
  if (inv.status !== "brouillon") throw new Error("Cette facture est déjà émise : elle ne peut plus être modifiée. Créez un avoir si nécessaire.");
  const lines = await db.select().from(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, invoiceId)).orderBy(asc(schema.invoiceLines.position));
  if (!lines.length) throw new Error("Ajoutez au moins une ligne avant d'émettre la facture.");
  const billTo = readBillTo(inv.billTo);
  if (!billTo.name.trim()) throw new Error("Le destinataire de la facture doit être renseigné (nom et adresse).");
  const totals = invoiceTotals(
    lines.map((l) => ({ label: l.label, description: l.description, quantityMilli: l.quantity, unit: l.unit, unitCents: l.unitCents, vatRateBp: l.vatRateBp })),
    inv.vatExempt,
  );
  if (totals.totalTtcCents <= 0 && inv.kind !== "avoir") throw new Error("Le total de la facture doit être positif.");
  const today = todayParis();
  const year = Number(today.slice(0, 4));
  const issueDate = today;
  const dueDate = inv.dueDate && inv.dueDate >= issueDate ? inv.dueDate : format(addDays(parseISO(issueDate), 30), "yyyy-MM-dd");

  const issued = await db.transaction(async (tx) => {
    const number = await nextNumber(tx, orgId, inv.kind, year);
    for (const [i, l] of totals.lines.entries()) {
      await tx.update(schema.invoiceLines).set({ totalHtCents: l.totalHtCents, vatRateBp: l.vatRateBp, position: i }).where(eq(schema.invoiceLines.id, lines[i].id));
    }
    const [row] = await tx
      .update(schema.invoices)
      .set({
        number,
        status: "emise",
        issueDate,
        dueDate,
        totalHtCents: totals.totalHtCents,
        vatCents: totals.vatCents,
        totalTtcCents: totals.totalTtcCents,
        vatMention: inv.vatExempt ? VAT_EXEMPT_MENTION : inv.vatMention ?? null,
        paymentTerms: inv.paymentTerms ?? DEFAULT_PAYMENT_TERMS,
        billTo,
        issuedBy: ctx.user.id,
      })
      .where(eq(schema.invoices.id, invoiceId))
      .returning();
    return row;
  });

  const org = ctx.org;
  const pdf = await renderInvoicePdf({ org, invoice: issued, lines: totals.lines });
  const doc = await createDocument({
    orgId,
    enrollmentId: issued.enrollmentId,
    companyId: issued.companyId,
    sessionId: issued.sessionId,
    personId: issued.personId,
    category: issued.kind === "avoir" ? "avoir" : "facture",
    visibility: "administratif",
    status: "genere",
    title: `${issued.kind === "avoir" ? "Avoir" : "Facture"} ${issued.number}`,
    fileName: `${issued.number}.pdf`,
    mimeType: "application/pdf",
    data: pdf,
    templateCode: "invoice_pdf_v1",
    generationData: { invoiceId: issued.id, number: issued.number, totals: { ht: issued.totalHtCents, tva: issued.vatCents, ttc: issued.totalTtcCents }, billTo },
    sourceType: "invoice",
    sourceId: issued.id,
    uploadedBy: ctx.user.id,
    retentionYears: 10,
    isDemo: ctx.org.isDemo,
  });
  await db.update(schema.invoices).set({ documentId: doc.id }).where(eq(schema.invoices.id, invoiceId));
  await audit({ action: "invoice.issue", userId: ctx.user.id, orgId, entityType: "invoice", entityId: invoiceId, before: { status: "brouillon" }, after: { status: "emise", number: issued.number, totalTtcCents: issued.totalTtcCents, documentId: doc.id } });

  if (issued.fundingId) {
    await markScheduleInvoiced(orgId, issued.fundingId, issued.id);
    await syncFundingFromInvoices(orgId, issued.fundingId, ctx.user.id);
  }
  if (issued.enrollmentId) await recalcEnrollmentFundingState(orgId, issued.enrollmentId, ctx.user.id);
  return { ...issued, documentId: doc.id };
}

/** Résout les tâches d'échéance dont la ligne porte cette facture. */
async function markScheduleInvoiced(orgId: string, fundingId: string, invoiceId: string) {
  const [f] = await db.select({ schedule: schema.fundings.schedule }).from(schema.fundings).where(and(eq(schema.fundings.id, fundingId), eq(schema.fundings.orgId, orgId))).limit(1);
  if (!f) return;
  for (const l of readSchedule(f.schedule)) {
    if (l.invoiceId === invoiceId) await resolveTaskByKey(orgId, scheduleDueKey(fundingId, l.dueDate), "Échéance facturée.");
  }
}

/* ---------- Synthèses ---------- */

export type FinanceSummary = {
  enrollmentId: string;
  fundingState: string;
  plannedCents: number;
  grantedCents: number;
  billedCents: number;
  paidCents: number;
  balanceCents: number;
  nextDue: { label: string; dueDate: string; amountCents: number; fundingId: string } | null;
  fundings: { id: string; label: string; kind: string; status: string; amountCents: number; funderName: string | null; agreementRef: string | null; validUntil: string | null }[];
  invoices: { id: string; number: string | null; kind: string; status: string; totalTtcCents: number; paidCents: number; dueDate: string | null; issueDate: string }[];
  computedAt: string;
};

/** Tableau financier d'une inscription (dossier central) : prévision, accordé, facturé, encaissé, solde, prochaine échéance. */
export async function financeSummary(orgId: string, enrollmentId: string): Promise<FinanceSummary> {
  const [enr] = await db.select({ fundingState: schema.enrollments.fundingState }).from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
  const fundings = await db
    .select({ f: schema.fundings, funderName: schema.funders.name })
    .from(schema.fundings)
    .leftJoin(schema.funders, eq(schema.funders.id, schema.fundings.funderId))
    .where(and(eq(schema.fundings.orgId, orgId), eq(schema.fundings.enrollmentId, enrollmentId)))
    .orderBy(asc(schema.fundings.createdAt));
  const invoices = await db
    .select()
    .from(schema.invoices)
    .where(and(eq(schema.invoices.orgId, orgId), eq(schema.invoices.enrollmentId, enrollmentId), ne(schema.invoices.status, "annulee")))
    .orderBy(desc(schema.invoices.issueDate));
  const active = fundings.filter((x) => x.f.status !== "annule" && x.f.status !== "refuse");
  const plannedCents = active.reduce((a, x) => a + x.f.amountCents, 0);
  const grantedCents = active.filter((x) => ["accorde", "facture", "solde"].includes(x.f.status)).reduce((a, x) => a + x.f.amountCents, 0);
  const issued = invoices.filter((i) => ISSUED_STATUSES.includes(i.status));
  const sign = (i: Invoice) => (i.kind === "avoir" ? -1 : 1);
  const billedCents = issued.filter((i) => i.kind !== "proforma").reduce((a, i) => a + sign(i) * i.totalTtcCents, 0);
  const paidCents = issued.filter((i) => i.kind !== "proforma").reduce((a, i) => a + sign(i) * i.paidCents, 0);
  let nextDue: FinanceSummary["nextDue"] = null;
  for (const x of active) {
    const n = nextScheduleLine(readSchedule(x.f.schedule));
    if (n && (!nextDue || n.dueDate < nextDue.dueDate)) nextDue = { ...n, fundingId: x.f.id };
  }
  return {
    enrollmentId,
    fundingState: enr?.fundingState ?? "a_definir",
    plannedCents,
    grantedCents,
    billedCents,
    paidCents,
    balanceCents: billedCents - paidCents,
    nextDue,
    fundings: fundings.map((x) => ({ id: x.f.id, label: x.f.label, kind: x.f.kind, status: x.f.status, amountCents: x.f.amountCents, funderName: x.funderName, agreementRef: x.f.agreementRef, validUntil: x.f.validUntil })),
    invoices: invoices.map((i) => ({ id: i.id, number: i.number, kind: i.kind, status: i.status, totalTtcCents: i.totalTtcCents, paidCents: i.paidCents, dueDate: i.dueDate, issueDate: i.issueDate })),
    computedAt: new Date().toISOString(),
  };
}

export type SessionFinanceSummary = { sessionId: string; enrollments: number; plannedCents: number; grantedCents: number; billedCents: number; paidCents: number; computedAt: string };

/** Vue par session : total prévu / accordé / facturé / encaissé. */
export async function financeSummaryForSession(orgId: string, sessionId: string): Promise<SessionFinanceSummary> {
  const enr = await db.select({ id: schema.enrollments.id }).from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.sessionId, sessionId)));
  const ids = enr.map((e) => e.id);
  const out: SessionFinanceSummary = { sessionId, enrollments: ids.length, plannedCents: 0, grantedCents: 0, billedCents: 0, paidCents: 0, computedAt: new Date().toISOString() };
  if (!ids.length) return out;
  const f = await db.select({ status: schema.fundings.status, amountCents: schema.fundings.amountCents }).from(schema.fundings).where(and(eq(schema.fundings.orgId, orgId), inArray(schema.fundings.enrollmentId, ids)));
  for (const x of f) {
    if (x.status === "annule" || x.status === "refuse") continue;
    out.plannedCents += x.amountCents;
    if (["accorde", "facture", "solde"].includes(x.status)) out.grantedCents += x.amountCents;
  }
  const inv = await db
    .select({ kind: schema.invoices.kind, totalTtcCents: schema.invoices.totalTtcCents, paidCents: schema.invoices.paidCents })
    .from(schema.invoices)
    .where(and(eq(schema.invoices.orgId, orgId), inArray(schema.invoices.status, ISSUED_STATUSES), sql`(${schema.invoices.enrollmentId} in ${ids} or ${schema.invoices.sessionId} = ${sessionId})`, ne(schema.invoices.kind, "proforma")));
  for (const i of inv) {
    const s = i.kind === "avoir" ? -1 : 1;
    out.billedCents += s * i.totalTtcCents;
    out.paidCents += s * i.paidCents;
  }
  return out;
}

/** Factures émises d'une entreprise (extranet employeur) : jamais les brouillons. */
export async function invoicesForCompany(orgId: string, companyId: string) {
  return db
    .select({ id: schema.invoices.id, number: schema.invoices.number, kind: schema.invoices.kind, status: schema.invoices.status, issueDate: schema.invoices.issueDate, dueDate: schema.invoices.dueDate, totalTtcCents: schema.invoices.totalTtcCents, paidCents: schema.invoices.paidCents, documentId: schema.invoices.documentId })
    .from(schema.invoices)
    .where(and(eq(schema.invoices.orgId, orgId), eq(schema.invoices.companyId, companyId), inArray(schema.invoices.status, ISSUED_STATUSES)))
    .orderBy(desc(schema.invoices.issueDate));
}

/** Marque en retard les factures échues non soldées (job finance:overdue et bouton manuel). */
export async function markOverdueInvoices(orgId: string | null, today = todayParis()) {
  const rows = await db
    .select({ id: schema.invoices.id, orgId: schema.invoices.orgId })
    .from(schema.invoices)
    .where(and(orgId ? eq(schema.invoices.orgId, orgId) : undefined, inArray(schema.invoices.status, ["emise", "envoyee"]), inArray(schema.invoices.kind, ["facture", "acompte"]), sql`${schema.invoices.dueDate} < ${today}`, sql`${schema.invoices.paidCents} < ${schema.invoices.totalTtcCents}`));
  for (const r of rows) {
    await db.update(schema.invoices).set({ status: "en_retard" }).where(eq(schema.invoices.id, r.id));
    await audit({ action: "invoice.overdue", orgId: r.orgId, entityType: "invoice", entityId: r.id, after: { status: "en_retard", today } });
  }
  return rows.length;
}
