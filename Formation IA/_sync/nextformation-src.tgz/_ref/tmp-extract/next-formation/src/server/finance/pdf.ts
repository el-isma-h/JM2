import "server-only";
import PDFDocument from "pdfkit";
import type { schema } from "@/db";
import { getObject } from "@/server/storage";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { invoiceKindLabels, LATE_PENALTY_MENTION, RECOVERY_FEE_MENTION, type ComputedLine } from "./compute";

export type BillTo = { kind: "entreprise" | "financeur" | "particulier"; name: string; addressLine1: string; addressLine2?: string; postalCode: string; city: string; siret?: string; vatNumber?: string; email?: string };

type Org = typeof schema.organismes.$inferSelect;
type Invoice = typeof schema.invoices.$inferSelect;

/** Espaces fines insécables (fr-FR) non couvertes par les polices PDF standard. */
const clean = (s: string) => s.replace(/[  ]/g, " ");
const money = (c: number) => clean(formatCents(c));

function newDoc(title: string) {
  const doc = new PDFDocument({ size: "A4", bufferPages: true, margins: { top: 56, bottom: 64, left: 56, right: 56 }, info: { Title: title, Creator: "Next Formation" } });
  const chunks: Buffer[] = [];
  doc.on("data", (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });
  return { doc, done };
}

async function drawHeader(doc: PDFKit.PDFDocument, org: Org, accent: string) {
  const left = doc.page.margins.left;
  let y = doc.page.margins.top;
  if (org.logoKey) {
    try {
      const img = await getObject(org.logoKey);
      doc.image(img, left, y, { fit: [120, 48] });
    } catch {
      // logo illisible : on continue sans
    }
  }
  const x = left + (org.logoKey ? 136 : 0);
  doc.font("Helvetica-Bold").fontSize(13).fillColor(accent).text(clean(org.tradeName ?? org.legalName), x, y, { width: 300 });
  doc.font("Helvetica").fontSize(8.5).fillColor("#2b2925");
  const addr = [org.legalName !== (org.tradeName ?? org.legalName) ? org.legalName : null, org.addressLine1, org.addressLine2, [org.postalCode, org.city].filter(Boolean).join(" "), org.email, org.phone].filter(Boolean);
  for (const a of addr) doc.text(clean(String(a)), x, doc.y, { width: 300 });
  const ident = [org.siret ? `SIRET ${org.siret}` : null, org.vatNumber ? `TVA ${org.vatNumber}` : null, org.nda ? `NDA ${org.nda}${org.ndaRegion ? ` (${org.ndaRegion})` : ""}` : null].filter(Boolean);
  for (const i of ident) doc.text(clean(String(i)), x, doc.y, { width: 300 });
  y = Math.max(doc.y, y + 56) + 8;
  doc.moveTo(left, y).lineTo(doc.page.width - doc.page.margins.right, y).lineWidth(1).strokeColor(accent).stroke();
  return y + 14;
}

function drawFooter(doc: PDFKit.PDFDocument, org: Org) {
  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);
    const bottom = doc.page.margins.bottom;
    // Marge basse neutralisée le temps d'écrire le pied de page : sinon pdfkit ajoute une page vide.
    doc.page.margins.bottom = 0;
    const y = doc.page.height - bottom + 16;
    doc.font("Helvetica").fontSize(7.5).fillColor("#6b6760");
    const footer = org.documentFooter?.trim() || clean([org.legalName, org.legalForm, org.siret ? `SIRET ${org.siret}` : null, org.nda ? `Déclaration d'activité ${org.nda}` : null, "Cet enregistrement ne vaut pas agrément de l'État."].filter(Boolean).join(" · "));
    doc.text(footer, doc.page.margins.left, y, { width: doc.page.width - doc.page.margins.left - doc.page.margins.right - 60, lineBreak: true, height: 30 });
    doc.text(`${i + 1} / ${range.count}`, doc.page.width - doc.page.margins.right - 50, y, { width: 50, align: "right" });
    doc.page.margins.bottom = bottom;
  }
}

/** PDF de facture ou d'avoir : identité de l'organisme, mentions obligatoires, lignes et totaux figés. */
export async function renderInvoicePdf(input: { org: Org; invoice: Invoice; lines: ComputedLine[] }): Promise<Buffer> {
  const { org, invoice, lines } = input;
  const accent = /^#[0-9a-f]{6}$/i.test(org.primaryColor) ? org.primaryColor : "#4b2a7f";
  const ink = "#2b2925";
  const billTo = (invoice.billTo ?? {}) as Partial<BillTo>;
  const title = `${invoiceKindLabels[invoice.kind]} ${invoice.number ?? "(brouillon)"}`;
  const { doc, done } = newDoc(title);
  const left = doc.page.margins.left;
  const right = doc.page.width - doc.page.margins.right;
  const width = right - left;

  let y = await drawHeader(doc, org, accent);

  // Titre et destinataire
  doc.font("Helvetica-Bold").fontSize(18).fillColor(ink).text(clean(title.toUpperCase()), left, y, { characterSpacing: 1.2, width: width * 0.5 });
  if (invoice.status === "brouillon") doc.font("Helvetica").fontSize(9).fillColor("#8a5a00").text("BROUILLON : sans valeur comptable, non numéroté.", left, doc.y + 2, { width: width * 0.5 });
  const metaY = y;
  doc.font("Helvetica").fontSize(9).fillColor(ink);
  const meta: [string, string][] = [
    ["Date d'émission", fmtDate(invoice.issueDate)],
    ["Date d'échéance", invoice.dueDate ? fmtDate(invoice.dueDate) : "-"],
  ];
  if (invoice.servicePeriodStart || invoice.servicePeriodEnd) meta.push(["Période de prestation", `${invoice.servicePeriodStart ? fmtDate(invoice.servicePeriodStart) : "…"} au ${invoice.servicePeriodEnd ? fmtDate(invoice.servicePeriodEnd) : "…"}`]);
  // Acheteur public (Chorus Pro) : mentions imprimées uniquement si renseignées.
  if (invoice.purchaseOrderNumber?.trim()) meta.push(["Bon de commande", invoice.purchaseOrderNumber.trim()]);
  if (invoice.serviceCode?.trim()) meta.push(["Code service", invoice.serviceCode.trim()]);
  if (invoice.legalCommitment?.trim()) meta.push(["Engagement juridique", invoice.legalCommitment.trim()]);
  let my = metaY;
  for (const [k, v] of meta) {
    doc.font("Helvetica").fillColor("#6b6760").text(clean(k), left + width * 0.55, my, { width: 110, lineBreak: false });
    doc.font("Helvetica-Bold").fillColor(ink).text(clean(v), left + width * 0.55 + 112, my, { width: width * 0.45 - 112 });
    my = Math.max(my + 14, doc.y + 2);
  }
  y = Math.max(doc.y, my) + 18;

  doc.font("Helvetica").fontSize(8).fillColor("#6b6760").text("FACTURÉ À", left, y, { characterSpacing: 1 });
  doc.font("Helvetica-Bold").fontSize(10.5).fillColor(ink).text(clean(billTo.name ?? ""), left, doc.y + 2, { width: width / 2 });
  doc.font("Helvetica").fontSize(9);
  for (const l of [billTo.addressLine1, billTo.addressLine2, [billTo.postalCode, billTo.city].filter(Boolean).join(" "), billTo.siret ? `SIRET ${billTo.siret}` : null, billTo.vatNumber ? `TVA ${billTo.vatNumber}` : null].filter(Boolean)) {
    doc.text(clean(String(l)), left, doc.y, { width: width / 2 });
  }
  y = doc.y + 20;

  // Tableau des lignes
  const cols = { label: left, qty: left + width * 0.52, unit: left + width * 0.62, pu: left + width * 0.72, tva: left + width * 0.85, total: left + width * 0.88 };
  const colW = { label: width * 0.5, qty: width * 0.09, unit: width * 0.09, pu: width * 0.12, tva: width * 0.03, total: width * 0.12 };
  const header = () => {
    doc.rect(left, y, width, 18).fill(accent);
    doc.font("Helvetica-Bold").fontSize(8).fillColor("#ffffff");
    doc.text("Désignation", cols.label + 4, y + 5, { width: colW.label });
    doc.text("Qté", cols.qty, y + 5, { width: colW.qty, align: "right" });
    doc.text("Unité", cols.unit + 4, y + 5, { width: colW.unit });
    doc.text("PU HT", cols.pu, y + 5, { width: colW.pu, align: "right" });
    if (!invoice.vatExempt) doc.text("TVA", cols.tva, y + 5, { width: colW.tva + 10, align: "right" });
    doc.text("Total HT", cols.total, y + 5, { width: colW.total, align: "right" });
    y += 22;
  };
  header();
  doc.font("Helvetica").fontSize(9).fillColor(ink);
  for (const l of lines) {
    const h = Math.max(doc.heightOfString(clean(l.label), { width: colW.label - 8 }) + (l.description ? doc.heightOfString(clean(l.description), { width: colW.label - 8 }) + 2 : 0), 12);
    if (y + h + 10 > doc.page.height - doc.page.margins.bottom - 120) {
      doc.addPage();
      y = doc.page.margins.top;
      header();
      doc.font("Helvetica").fontSize(9).fillColor(ink);
    }
    doc.font("Helvetica").fillColor(ink).text(clean(l.label), cols.label + 4, y, { width: colW.label - 8 });
    if (l.description) doc.fontSize(8).fillColor("#6b6760").text(clean(l.description), cols.label + 4, doc.y, { width: colW.label - 8 }).fontSize(9).fillColor(ink);
    doc.text(clean((l.quantityMilli / 1000).toLocaleString("fr-FR", { maximumFractionDigits: 3 })), cols.qty, y, { width: colW.qty, align: "right" });
    doc.text(clean(l.unit), cols.unit + 4, y, { width: colW.unit });
    doc.text(money(l.unitCents), cols.pu, y, { width: colW.pu, align: "right" });
    if (!invoice.vatExempt) doc.text(`${(l.vatRateBp / 100).toLocaleString("fr-FR")} %`, cols.tva, y, { width: colW.tva + 10, align: "right" });
    doc.text(money(l.totalHtCents), cols.total, y, { width: colW.total, align: "right" });
    y += h + 8;
    doc.moveTo(left, y - 3).lineTo(right, y - 3).lineWidth(0.5).strokeColor("#e3e0d8").stroke();
  }

  // Totaux
  y += 6;
  const totals: [string, string, boolean][] = [["Total HT", money(invoice.totalHtCents), false]];
  if (!invoice.vatExempt) totals.push(["TVA", money(invoice.vatCents), false]);
  totals.push([invoice.vatExempt ? "Net à payer (exonéré de TVA)" : "Total TTC", money(invoice.totalTtcCents), true]);
  if (invoice.paidCents > 0 && invoice.kind !== "avoir") {
    totals.push(["Déjà réglé", money(invoice.paidCents), false]);
    totals.push(["Reste à payer", money(invoice.totalTtcCents - invoice.paidCents), true]);
  }
  for (const [k, v, bold] of totals) {
    doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(bold ? 10.5 : 9).fillColor(ink);
    doc.text(clean(k), cols.pu - 90, y, { width: 150, align: "right" });
    doc.text(v, cols.total - 10, y, { width: colW.total + 10, align: "right" });
    y += bold ? 16 : 13;
  }

  // Mentions
  y += 14;
  doc.font("Helvetica").fontSize(8).fillColor(ink);
  const mentions = [
    invoice.vatMention,
    invoice.kind === "avoir" && invoice.creditOfInvoiceId ? "Avoir émis en annulation partielle ou totale de la facture d'origine mentionnée dans les notes." : null,
    invoice.paymentTerms,
    invoice.kind !== "avoir" ? LATE_PENALTY_MENTION : null,
    invoice.kind !== "avoir" ? RECOVERY_FEE_MENTION : null,
    "Aucun escompte pour paiement anticipé.",
    invoice.notes,
  ].filter(Boolean) as string[];
  for (const m of mentions) {
    if (y > doc.page.height - doc.page.margins.bottom - 40) {
      doc.addPage();
      y = doc.page.margins.top;
    }
    doc.text(clean(m), left, y, { width, lineGap: 1 });
    y = doc.y + 4;
  }
  drawFooter(doc, org);
  doc.end();
  return done;
}

export type BpfPdfSection = { title: string; rows: { label: string; value: string; note?: string }[] };

/** Récapitulatif PDF du Bilan pédagogique et financier (rubriques calculées, définitions et date de calcul). */
export async function renderBpfPdf(input: { org: Org; year: number; computedAt: string; sections: BpfPdfSection[] }): Promise<Buffer> {
  const { org, year, sections } = input;
  const accent = /^#[0-9a-f]{6}$/i.test(org.primaryColor) ? org.primaryColor : "#4b2a7f";
  const ink = "#2b2925";
  const { doc, done } = newDoc(`Bilan pédagogique et financier ${year}`);
  const left = doc.page.margins.left;
  const right = doc.page.width - doc.page.margins.right;
  const width = right - left;
  let y = await drawHeader(doc, org, accent);
  doc.font("Helvetica-Bold").fontSize(16).fillColor(ink).text(clean(`BILAN PÉDAGOGIQUE ET FINANCIER ${year}`), left, y, { characterSpacing: 1 });
  doc.font("Helvetica").fontSize(8.5).fillColor("#6b6760").text(clean(`Récapitulatif préparatoire calculé le ${fmtDate(new Date(input.computedAt), "d MMM yyyy 'à' HH:mm")} à partir des factures émises, des dépenses, des inscriptions et des heures validées. Ce document aide à remplir la déclaration officielle ; il ne la remplace pas.`), left, doc.y + 4, { width });
  y = doc.y + 16;
  for (const s of sections) {
    if (y > doc.page.height - doc.page.margins.bottom - 80) {
      doc.addPage();
      y = doc.page.margins.top;
    }
    doc.rect(left, y, width, 18).fill(accent);
    doc.font("Helvetica-Bold").fontSize(9).fillColor("#ffffff").text(clean(s.title), left + 4, y + 5, { width: width - 8 });
    y += 24;
    for (const r of s.rows) {
      if (y > doc.page.height - doc.page.margins.bottom - 40) {
        doc.addPage();
        y = doc.page.margins.top;
      }
      doc.font("Helvetica").fontSize(9).fillColor(ink).text(clean(r.label), left + 4, y, { width: width * 0.6 });
      doc.font("Helvetica-Bold").text(clean(r.value), left + width * 0.62, y, { width: width * 0.38 - 4, align: "right" });
      let ny = doc.y;
      if (r.note) {
        doc.font("Helvetica").fontSize(7.5).fillColor("#6b6760").text(clean(r.note), left + 4, ny + 1, { width: width - 8 });
        ny = doc.y;
      }
      y = ny + 6;
      doc.moveTo(left, y - 2).lineTo(right, y - 2).lineWidth(0.5).strokeColor("#e3e0d8").stroke();
    }
    y += 10;
  }
  drawFooter(doc, org);
  doc.end();
  return done;
}
