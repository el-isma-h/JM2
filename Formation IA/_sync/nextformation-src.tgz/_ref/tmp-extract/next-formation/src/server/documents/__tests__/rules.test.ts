import { describe, expect, it } from "vitest";
import type { Permission } from "@/server/authz";
import { canManageRib, canSeeDocumentRules, canViewRib, planVersion } from "../rules";

const ctx = (perms: Permission[], extra: { isOwner?: boolean; trainerOnly?: boolean } = {}) => ({ isOwner: extra.isOwner ?? false, trainerOnly: extra.trainerOnly ?? false, permissions: new Set<Permission>(perms), orgId: "org-1" });

describe("F12 : droits sur le RIB central", () => {
  it("le propriétaire lit et gère, quelles que soient ses permissions", () => {
    const owner = ctx([], { isOwner: true });
    expect(canViewRib(owner)).toBe(true);
    expect(canManageRib(owner)).toBe(true);
  });
  it("finance.view seul (cas Nathalie) lit mais ne gère pas", () => {
    const nathalie = ctx(["org.view", "sessions.manage", "dossier.internal.view", "finance.view"]);
    expect(canViewRib(nathalie)).toBe(true);
    expect(canManageRib(nathalie)).toBe(false);
  });
  it("finance.manage gère", () => {
    expect(canManageRib(ctx(["finance.view", "finance.manage"]))).toBe(true);
  });
  it("sans finance.* ni propriété : ni lecture ni gestion, même avec users.manage / roles.manage / audit.view", () => {
    const c = ctx(["users.manage", "roles.manage", "audit.view", "documents.view", "dossier.admin_docs.view"]);
    expect(canViewRib(c)).toBe(false);
    expect(canManageRib(c)).toBe(false);
  });
});

describe("F09 : versions à la régénération", () => {
  it("premier document : version 1", () => {
    expect(planVersion(null)).toEqual({ version: 1, previousVersionId: null, archivePrevious: false });
  });
  it("document généré ou transmis : remplacé (archivé), version + 1", () => {
    expect(planVersion({ id: "a", version: 2, status: "transmis" })).toEqual({ version: 3, previousVersionId: "a", archivePrevious: true });
  });
  it("document signé : la nouvelle version ne le remplace pas", () => {
    const plan = planVersion({ id: "s", version: 1, status: "signe" });
    expect(plan.version).toBe(2);
    expect(plan.previousVersionId).toBe("s");
    expect(plan.archivePrevious).toBe(false);
  });
  it("document validé : conservé lui aussi", () => {
    expect(planVersion({ id: "v", version: 4, status: "valide" }).archivePrevious).toBe(false);
  });
});

describe("Visibilité des documents (CDC §8)", () => {
  const base = { orgId: "org-1", sessionId: "s1", sourceType: null };
  it("isolation : un document d'un autre organisme n'est jamais visible", () => {
    expect(canSeeDocumentRules(ctx([], { isOwner: true }), { ...base, orgId: "org-2", category: "autre", visibility: "interne" }, null)).toBe(false);
  });
  it("pièce administrative : exige dossier.admin_docs.view", () => {
    const doc = { ...base, category: "convention", visibility: "administratif" };
    expect(canSeeDocumentRules(ctx(["documents.view"]), doc, null)).toBe(false);
    expect(canSeeDocumentRules(ctx(["documents.view", "dossier.admin_docs.view"]), doc, null)).toBe(true);
  });
  it("pédagogie : exige dossier.pedagogy.view ; CV : candidates.cv.view", () => {
    expect(canSeeDocumentRules(ctx(["documents.view"]), { ...base, category: "livret", visibility: "pedagogie" }, null)).toBe(false);
    expect(canSeeDocumentRules(ctx(["documents.view", "dossier.pedagogy.view"]), { ...base, category: "livret", visibility: "pedagogie" }, null)).toBe(true);
    expect(canSeeDocumentRules(ctx(["documents.view", "dossier.admin_docs.view"]), { ...base, category: "cv", visibility: "interne" }, null)).toBe(false);
  });
  it("RIB central : identifié par sourceType, lecture par propriétaire ou finance.view uniquement", () => {
    const rib = { ...base, sessionId: null, category: "rib", visibility: "confidentiel", sourceType: "org_rib" };
    expect(canSeeDocumentRules(ctx(["dossier.admin_docs.view", "documents.view"]), rib, null)).toBe(false);
    expect(canSeeDocumentRules(ctx(["finance.view"]), rib, null)).toBe(true);
    expect(canSeeDocumentRules(ctx([], { isOwner: true }), rib, null)).toBe(true);
  });
  it("formateur seul : uniquement ses sessions, visibilité pédagogie / interne, jamais une pièce admin", () => {
    const trainer = ctx(["documents.view", "dossier.pedagogy.view"], { trainerOnly: true });
    expect(canSeeDocumentRules(trainer, { ...base, category: "livret", visibility: "pedagogie" }, ["s1"])).toBe(true);
    expect(canSeeDocumentRules(trainer, { ...base, category: "livret", visibility: "pedagogie" }, ["s2"])).toBe(false);
    expect(canSeeDocumentRules(trainer, { ...base, category: "livret", visibility: "pedagogie" }, [])).toBe(false);
    expect(canSeeDocumentRules(trainer, { ...base, category: "convocation", visibility: "apprenant" }, ["s1"])).toBe(false);
    expect(canSeeDocumentRules(trainer, { ...base, category: "certificat_realisation", visibility: "interne" }, ["s1"])).toBe(false);
  });
});

describe("Signature : contrôle de structure PNG", () => {
  it("refuse un PNG tronqué ou sans IEND, accepte un PNG complet", async () => {
    const { pngStructureOk } = await import("../signatures-png");
    const sig = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==", "base64");
    expect(pngStructureOk(sig)).toBe(true);
    expect(pngStructureOk(sig.subarray(0, sig.length - 8))).toBe(false);
    expect(pngStructureOk(Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAGQAAAAyCAYAAACqNX6+AAAAWElEQVR4nO3BMQEAAADCoPVPbQwfoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPgxvCgAAVFVrRwAAAAASUVORK5CYII=", "base64"))).toBe(false);
  });
});
