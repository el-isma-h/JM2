/**
 * Référentiel minimal (7 critères, 32 indicateurs, libellés courts) utilisé seulement si aucun référentiel
 * plateforme n'existe en base. Les textes officiels restent à valider par l'organisme avant activation (F13).
 */

export type IndicatorSeed = { code: string; label: string; level: "individuel" | "collectif" | "organisationnel"; requiresHuman: boolean; evidenceHints: string[] };
export type CriterionSeed = { code: string; label: string; indicators: IndicatorSeed[] };

const ind = (n: number, label: string, level: IndicatorSeed["level"], requiresHuman = false, hints: string[] = []): IndicatorSeed => ({ code: `IND_${n}`, label, level, requiresHuman, evidenceHints: hints });

export const MINIMAL_REFERENTIAL: CriterionSeed[] = [
  {
    code: "C1",
    label: "Information du public",
    indicators: [
      ind(1, "Information accessible sur les prestations (prérequis, objectifs, durée, tarifs, délais, accessibilité)", "organisationnel", false, ["programme publié", "catalogue public"]),
      ind(2, "Indicateurs de résultats diffusés", "organisationnel", true, ["taux de satisfaction", "taux de réussite"]),
      ind(3, "Taux d'obtention des certifications et débouchés", "organisationnel", true, ["résultats d'examen"]),
    ],
  },
  {
    code: "C2",
    label: "Identification des objectifs et adaptation",
    indicators: [
      ind(4, "Analyse du besoin du bénéficiaire et du financeur", "individuel", false, ["besoin CRM", "entretien"]),
      ind(5, "Objectifs opérationnels et évaluables", "collectif", false, ["programme"]),
      ind(6, "Contenus et modalités adaptés aux objectifs", "collectif", false, ["programme", "modules"]),
      ind(7, "Adéquation des contenus avec la certification visée", "collectif", true, ["référentiel de certification"]),
      ind(8, "Positionnement et évaluation des acquis à l'entrée", "individuel", false, ["évaluation de positionnement"]),
    ],
  },
  {
    code: "C3",
    label: "Adaptation aux publics et accompagnement",
    indicators: [
      ind(9, "Information sur les conditions de déroulement", "individuel", false, ["convocation", "règlement intérieur"]),
      ind(10, "Adaptation de la prestation et de l'accompagnement", "individuel", true, ["plan individuel", "aménagements"]),
      ind(11, "Évaluation de l'atteinte des objectifs", "individuel", false, ["évaluation finale", "attestation"]),
      ind(12, "Engagement des bénéficiaires et prévention des ruptures", "individuel", false, ["suivi des absences", "relances"]),
      ind(13, "Coordination des apprentis entre centre et entreprise (CFA)", "individuel", false, ["suivi en entreprise", "livret"]),
      ind(14, "Exercice de la citoyenneté des apprentis (CFA)", "collectif", true, ["actions citoyennes"]),
      ind(15, "Information des apprentis sur leurs droits et devoirs (CFA)", "collectif", false, ["livret d'accueil"]),
      ind(16, "Préparation à l'épreuve de certification", "collectif", false, ["examen blanc", "cohorte"]),
    ],
  },
  {
    code: "C4",
    label: "Moyens pédagogiques, techniques et d'encadrement",
    indicators: [
      ind(17, "Moyens humains et techniques adaptés", "organisationnel", false, ["sites et salles", "équipements"]),
      ind(18, "Coordination des intervenants", "organisationnel", false, ["affectations", "réunions pédagogiques"]),
      ind(19, "Ressources pédagogiques et modalités d'accès", "collectif", false, ["e-learning", "supports"]),
      ind(20, "Dispositifs de mobilité des apprentis (CFA)", "organisationnel", true, ["information mobilité"]),
    ],
  },
  {
    code: "C5",
    label: "Qualification et développement des compétences du personnel",
    indicators: [
      ind(21, "Compétences des intervenants", "organisationnel", false, ["CV formateur", "habilitations"]),
      ind(22, "Développement des compétences des salariés", "organisationnel", true, ["plan de formation interne"]),
    ],
  },
  {
    code: "C6",
    label: "Inscription dans l'environnement professionnel",
    indicators: [
      ind(23, "Veille légale et réglementaire", "organisationnel", false, ["veille"]),
      ind(24, "Veille sur les compétences, métiers et emplois", "organisationnel", false, ["veille"]),
      ind(25, "Veille sur les innovations pédagogiques et technologiques", "organisationnel", false, ["veille"]),
      ind(26, "Référent handicap et réseau de partenaires", "organisationnel", false, ["référent", "partenariats"]),
      ind(27, "Conformité de la sous-traitance et du portage", "organisationnel", true, ["contrat de sous-traitance", "NDA"]),
      ind(28, "Articulation centre / entreprise et situations de travail", "individuel", false, ["suivi en entreprise"]),
      ind(29, "Insertion professionnelle et poursuite d'études (CFA)", "organisationnel", true, ["enquête à froid", "partenariats"]),
    ],
  },
  {
    code: "C7",
    label: "Recueil des appréciations et amélioration continue",
    indicators: [
      ind(30, "Recueil des appréciations des parties prenantes", "collectif", false, ["enquête à chaud", "enquête employeur"]),
      ind(31, "Traitement des réclamations et aléas", "organisationnel", false, ["réclamation traitée"]),
      ind(32, "Démarche d'amélioration continue", "organisationnel", true, ["actions qualité", "analyse"]),
    ],
  },
];

export const ALL_INDICATORS = MINIMAL_REFERENTIAL.flatMap((c) => c.indicators);
