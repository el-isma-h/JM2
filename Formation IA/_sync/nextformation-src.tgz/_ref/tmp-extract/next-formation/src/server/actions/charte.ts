"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { checkPostalCode, checkSiren, checkSiret } from "@/lib/validators";
import { requireOrg, requireOwner } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { buildKey, deleteObject, putObject } from "@/server/storage";
import { checkUpload } from "@/server/documents/upload-rules";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const HEX = /^#[0-9a-fA-F]{6}$/;

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

const CHARTE_FIELDS = ["legalName", "tradeName", "legalForm", "siren", "siret", "nda", "ndaRegion", "uaiCode", "addressLine1", "addressLine2", "postalCode", "city", "email", "phone", "website", "signatoryName", "signatoryTitle", "primaryColor", "secondaryColor", "documentHeader", "documentFooter"] as const;

const charteSchema = z.object({
  legalName: z.string().trim().min(2, "Raison sociale requise.").max(160),
  tradeName: z.string().trim().max(160),
  legalForm: z.enum([...schema.legalFormEnum.enumValues, ""]),
  siren: z.string().trim().max(20),
  siret: z.string().trim().max(20),
  nda: z.string().trim().max(40),
  ndaRegion: z.string().trim().max(80),
  uaiCode: z.string().trim().max(12),
  addressLine1: z.string().trim().max(160),
  addressLine2: z.string().trim().max(160),
  postalCode: z.string().trim().max(10),
  city: z.string().trim().max(120),
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide.").or(z.literal("")),
  phone: z.string().trim().max(30),
  website: z.string().trim().max(200),
  signatoryName: z.string().trim().max(120),
  signatoryTitle: z.string().trim().max(120),
  primaryColor: z.string().trim().regex(HEX, "Couleur principale : format #rrggbb attendu."),
  secondaryColor: z.string().trim().regex(HEX, "Couleur secondaire : format #rrggbb attendu."),
  documentHeader: z.string().trim().max(300),
  documentFooter: z.string().trim().max(400),
});

/** F10 : modification de la charte institutionnelle, propriétaire actif uniquement (requireOwner, indépendamment des rôles). */
export async function updateCharteAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireOwner(orgId);
    const raw = Object.fromEntries(CHARTE_FIELDS.map((k) => [k, str(fd, k)]));
    const input = charteSchema.parse(raw);
    let siren: string | null = null;
    let siret: string | null = null;
    if (input.siren) {
      const r = checkSiren(input.siren);
      if (!r.ok) return { error: `SIREN : ${r.error}` };
      siren = r.value;
    }
    if (input.siret) {
      const r = checkSiret(input.siret, siren);
      if (!r.ok) return { error: `SIRET : ${r.error}` };
      siret = r.value;
      if (!siren) siren = siret.slice(0, 9);
    }
    if (input.postalCode) {
      const r = checkPostalCode(input.postalCode);
      if (!r.ok) return { error: `Code postal : ${r.error}` };
    }
    const before = Object.fromEntries(CHARTE_FIELDS.map((k) => [k, ctx.org[k] ?? null]));
    const after = {
      legalName: input.legalName,
      tradeName: input.tradeName || null,
      legalForm: input.legalForm || null,
      siren,
      siret,
      nda: input.nda || null,
      ndaRegion: input.ndaRegion || null,
      uaiCode: input.uaiCode || null,
      addressLine1: input.addressLine1 || null,
      addressLine2: input.addressLine2 || null,
      postalCode: input.postalCode || null,
      city: input.city || null,
      email: input.email || null,
      phone: input.phone || null,
      website: input.website || null,
      signatoryName: input.signatoryName || null,
      signatoryTitle: input.signatoryTitle || null,
      primaryColor: input.primaryColor.toLowerCase(),
      secondaryColor: input.secondaryColor.toLowerCase(),
      documentHeader: input.documentHeader || null,
      documentFooter: input.documentFooter || null,
    };
    await db.update(schema.organismes).set(after).where(eq(schema.organismes.id, orgId));
    const changed = Object.fromEntries(Object.entries(after).filter(([k, v]) => (before as Record<string, unknown>)[k] !== v));
    await audit({ action: "charte.update", userId: ctx.user.id, orgId, entityType: "organisme", entityId: orgId, before: Object.fromEntries(Object.keys(changed).map((k) => [k, (before as Record<string, unknown>)[k]])), after: changed });
    revalidatePath(`/app/${orgId}/charte`);
    revalidatePath(`/app/${orgId}/charte/modifier`);
    return { ok: true, message: Object.keys(changed).length ? `Charte enregistrée (${Object.keys(changed).length} champ(s) modifié(s)).` : "Aucune modification." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

async function readImage(fd: FormData, maxBytes: number): Promise<{ ok: true; data: Buffer; name: string; mime: string } | { ok: false; error: string }> {
  const file = fd.get("file");
  if (!(file instanceof File) || !file.size) return { ok: false, error: "Choisissez une image PNG ou JPEG." };
  if (file.size > maxBytes) return { ok: false, error: `L'image dépasse ${Math.round(maxBytes / 1024 / 1024)} Mo.` };
  const head = new Uint8Array(await file.slice(0, 8).arrayBuffer());
  const check = checkUpload({ name: file.name, type: file.type, size: file.size, head });
  if (!check.ok) return { ok: false, error: check.error };
  if (check.mime !== "image/png" && check.mime !== "image/jpeg") return { ok: false, error: "Seules les images PNG ou JPEG sont acceptées." };
  return { ok: true, data: Buffer.from(await file.arrayBuffer()), name: file.name, mime: check.mime };
}

export async function uploadLogoAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireOwner(orgId);
    const img = await readImage(fd, 2 * 1024 * 1024);
    if (!img.ok) return { error: img.error };
    const key = buildKey(orgId, "charte", `logo-${img.name}`);
    await putObject(key, img.data);
    const before = ctx.org.logoKey;
    await db.update(schema.organismes).set({ logoKey: key }).where(eq(schema.organismes.id, orgId));
    if (before) await deleteObject(before);
    await audit({ action: "charte.update", userId: ctx.user.id, orgId, entityType: "organisme", entityId: orgId, before: { logoKey: before }, after: { logoKey: key } });
    revalidatePath(`/app/${orgId}/charte`);
    revalidatePath(`/app/${orgId}/charte/modifier`);
    return { ok: true, message: "Logo enregistré (stockage privé)." };
  } catch (e) {
    return fail(e, "Dépôt du logo impossible.");
  }
}

export async function removeLogoAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireOwner(orgId);
    if (!ctx.org.logoKey) return { error: "Aucun logo à retirer." };
    await db.update(schema.organismes).set({ logoKey: null }).where(eq(schema.organismes.id, orgId));
    await deleteObject(ctx.org.logoKey);
    await audit({ action: "charte.update", userId: ctx.user.id, orgId, entityType: "organisme", entityId: orgId, before: { logoKey: ctx.org.logoKey }, after: { logoKey: null } });
    revalidatePath(`/app/${orgId}/charte`);
    revalidatePath(`/app/${orgId}/charte/modifier`);
    return { ok: true, message: "Logo retiré." };
  } catch (e) {
    return fail(e, "Retrait impossible.");
  }
}

export async function uploadSignatureImageAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireOwner(orgId);
    const img = await readImage(fd, 1024 * 1024);
    if (!img.ok) return { error: img.error };
    const key = buildKey(orgId, "charte", `signature-${img.name}`);
    await putObject(key, img.data);
    const before = ctx.org.signatureKey;
    await db.update(schema.organismes).set({ signatureKey: key }).where(eq(schema.organismes.id, orgId));
    if (before) await deleteObject(before);
    await audit({ action: "charte.update", userId: ctx.user.id, orgId, entityType: "organisme", entityId: orgId, before: { signatureKey: before }, after: { signatureKey: key } });
    revalidatePath(`/app/${orgId}/charte`);
    revalidatePath(`/app/${orgId}/charte/modifier`);
    return { ok: true, message: "Signature du signataire enregistrée (stockage privé)." };
  } catch (e) {
    return fail(e, "Dépôt de la signature impossible.");
  }
}

export async function removeSignatureImageAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireOwner(orgId);
    if (!ctx.org.signatureKey) return { error: "Aucune signature à retirer." };
    await db.update(schema.organismes).set({ signatureKey: null }).where(eq(schema.organismes.id, orgId));
    await deleteObject(ctx.org.signatureKey);
    await audit({ action: "charte.update", userId: ctx.user.id, orgId, entityType: "organisme", entityId: orgId, before: { signatureKey: ctx.org.signatureKey }, after: { signatureKey: null } });
    revalidatePath(`/app/${orgId}/charte`);
    revalidatePath(`/app/${orgId}/charte/modifier`);
    return { ok: true, message: "Signature retirée." };
  } catch (e) {
    return fail(e, "Retrait impossible.");
  }
}

/* ---------- Sites et salles (F10 : non bloqués par la charte ; org.view + sessions.manage) ---------- */

const siteSchema = z.object({
  name: z.string().trim().min(2, "Nom du site requis.").max(120),
  addressLine1: z.string().trim().max(160),
  postalCode: z.string().trim().max(10),
  city: z.string().trim().max(120),
  capacity: z.string().trim().max(5),
  accessibilityNote: z.string().trim().max(600),
});

function siteValues(input: z.infer<typeof siteSchema>) {
  if (input.postalCode) {
    const r = checkPostalCode(input.postalCode);
    if (!r.ok) throw new Error(`Code postal : ${r.error}`);
  }
  const cap = input.capacity ? Number(input.capacity) : null;
  if (cap !== null && (!Number.isInteger(cap) || cap < 0)) throw new Error("Capacité : nombre entier attendu.");
  return { name: input.name, addressLine1: input.addressLine1 || null, postalCode: input.postalCode || null, city: input.city || null, capacity: cap, accessibilityNote: input.accessibilityNote || null };
}

export async function createSiteAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const input = siteSchema.parse(Object.fromEntries(["name", "addressLine1", "postalCode", "city", "capacity", "accessibilityNote"].map((k) => [k, str(fd, k)])));
    const ctx = await requireOrg(orgId, "org.view", "sessions.manage");
    const [row] = await db.insert(schema.sites).values({ orgId, ...siteValues(input), isMain: false }).returning();
    await audit({ action: "site.create", userId: ctx.user.id, orgId, entityType: "site", entityId: row.id, after: { name: row.name } });
    revalidatePath(`/app/${orgId}/charte/sites`);
    return { ok: true, message: `Site « ${row.name} » créé.` };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function updateSiteAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const siteId = uuid.parse(str(fd, "siteId"));
    const input = siteSchema.parse(Object.fromEntries(["name", "addressLine1", "postalCode", "city", "capacity", "accessibilityNote"].map((k) => [k, str(fd, k)])));
    const ctx = await requireOrg(orgId, "org.view", "sessions.manage");
    const [site] = await db.select().from(schema.sites).where(and(eq(schema.sites.id, siteId), eq(schema.sites.orgId, orgId))).limit(1);
    if (!site) return { error: "Site introuvable." };
    const values = siteValues(input);
    const makeMain = str(fd, "isMain") === "1";
    if (makeMain) await db.update(schema.sites).set({ isMain: false }).where(and(eq(schema.sites.orgId, orgId), eq(schema.sites.isMain, true)));
    await db.update(schema.sites).set({ ...values, isMain: makeMain ? true : site.isMain }).where(eq(schema.sites.id, site.id));
    await audit({ action: "site.update", userId: ctx.user.id, orgId, entityType: "site", entityId: site.id, before: { name: site.name, addressLine1: site.addressLine1, city: site.city }, after: values });
    revalidatePath(`/app/${orgId}/charte/sites`);
    return { ok: true, message: "Site enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deleteSiteAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const siteId = uuid.parse(str(fd, "siteId"));
    const ctx = await requireOrg(orgId, "org.view", "sessions.manage");
    const [site] = await db.select().from(schema.sites).where(and(eq(schema.sites.id, siteId), eq(schema.sites.orgId, orgId))).limit(1);
    if (!site) return { error: "Site introuvable." };
    if (site.isMain) return { error: "Le site principal ne peut pas être supprimé : désignez d'abord un autre site principal." };
    const [used] = await db.select({ id: schema.trainingSessions.id }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.siteId, site.id), eq(schema.trainingSessions.orgId, orgId))).limit(1);
    if (used) return { error: "Ce site est utilisé par au moins une session : il ne peut pas être supprimé." };
    await db.delete(schema.sites).where(eq(schema.sites.id, site.id));
    if (site.accessPlanKey) await deleteObject(site.accessPlanKey);
    await audit({ action: "site.delete", userId: ctx.user.id, orgId, entityType: "site", entityId: site.id, before: { name: site.name } });
    revalidatePath(`/app/${orgId}/charte/sites`);
    return { ok: true, message: "Site supprimé." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

export async function uploadAccessPlanAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const siteId = uuid.parse(str(fd, "siteId"));
    const ctx = await requireOrg(orgId, "org.view", "sessions.manage");
    const [site] = await db.select().from(schema.sites).where(and(eq(schema.sites.id, siteId), eq(schema.sites.orgId, orgId))).limit(1);
    if (!site) return { error: "Site introuvable." };
    const file = fd.get("file");
    if (!(file instanceof File) || !file.size) return { error: "Choisissez un fichier PDF, PNG ou JPEG." };
    if (file.size > 10 * 1024 * 1024) return { error: "Le plan d'accès dépasse 10 Mo." };
    const head = new Uint8Array(await file.slice(0, 8).arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head });
    if (!check.ok) return { error: check.error };
    if (!["application/pdf", "image/png", "image/jpeg"].includes(check.mime)) return { error: "Le plan d'accès doit être un PDF, un PNG ou un JPEG." };
    const key = buildKey(orgId, "plan_acces", file.name);
    await putObject(key, Buffer.from(await file.arrayBuffer()));
    await db.update(schema.sites).set({ accessPlanKey: key }).where(eq(schema.sites.id, site.id));
    if (site.accessPlanKey) await deleteObject(site.accessPlanKey);
    await audit({ action: "site.access_plan", userId: ctx.user.id, orgId, entityType: "site", entityId: site.id, before: { accessPlanKey: site.accessPlanKey }, after: { accessPlanKey: key } });
    revalidatePath(`/app/${orgId}/charte/sites`);
    return { ok: true, message: "Plan d'accès enregistré (document public du site)." };
  } catch (e) {
    return fail(e, "Dépôt impossible.");
  }
}

export async function removeAccessPlanAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const siteId = uuid.parse(str(fd, "siteId"));
    const ctx = await requireOrg(orgId, "org.view", "sessions.manage");
    const [site] = await db.select().from(schema.sites).where(and(eq(schema.sites.id, siteId), eq(schema.sites.orgId, orgId))).limit(1);
    if (!site?.accessPlanKey) return { error: "Aucun plan d'accès à retirer." };
    await db.update(schema.sites).set({ accessPlanKey: null }).where(eq(schema.sites.id, site.id));
    await deleteObject(site.accessPlanKey);
    await audit({ action: "site.access_plan", userId: ctx.user.id, orgId, entityType: "site", entityId: site.id, before: { accessPlanKey: site.accessPlanKey }, after: { accessPlanKey: null } });
    revalidatePath(`/app/${orgId}/charte/sites`);
    return { ok: true, message: "Plan d'accès retiré." };
  } catch (e) {
    return fail(e, "Retrait impossible.");
  }
}

export async function createRoomAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const siteId = uuid.parse(str(fd, "siteId"));
    const input = z.object({ name: z.string().trim().min(1, "Nom de la salle requis.").max(80), capacity: z.string().trim().max(5), equipment: z.string().trim().max(300) }).parse({ name: str(fd, "name"), capacity: str(fd, "capacity"), equipment: str(fd, "equipment") });
    const ctx = await requireOrg(orgId, "org.view", "sessions.manage");
    const [site] = await db.select({ id: schema.sites.id }).from(schema.sites).where(and(eq(schema.sites.id, siteId), eq(schema.sites.orgId, orgId))).limit(1);
    if (!site) return { error: "Site introuvable." };
    const cap = input.capacity ? Number(input.capacity) : null;
    if (cap !== null && (!Number.isInteger(cap) || cap < 0)) return { error: "Capacité : nombre entier attendu." };
    const [room] = await db
      .insert(schema.rooms)
      .values({ orgId, siteId: site.id, name: input.name, capacity: cap, equipment: input.equipment ? input.equipment.split(",").map((s) => s.trim()).filter(Boolean) : [] })
      .returning();
    await audit({ action: "room.create", userId: ctx.user.id, orgId, entityType: "room", entityId: room.id, after: { name: room.name, siteId: site.id } });
    revalidatePath(`/app/${orgId}/charte/sites`);
    return { ok: true, message: `Salle « ${room.name} » créée.` };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

export async function deleteRoomAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const roomId = uuid.parse(str(fd, "roomId"));
    const ctx = await requireOrg(orgId, "org.view", "sessions.manage");
    const [room] = await db.select().from(schema.rooms).where(and(eq(schema.rooms.id, roomId), eq(schema.rooms.orgId, orgId))).limit(1);
    if (!room) return { error: "Salle introuvable." };
    const [used] = await db.select({ id: schema.slots.id }).from(schema.slots).where(and(eq(schema.slots.roomId, room.id), eq(schema.slots.orgId, orgId))).limit(1);
    if (used) return { error: "Cette salle est utilisée par au moins une séance : elle ne peut pas être supprimée." };
    await db.delete(schema.rooms).where(eq(schema.rooms.id, room.id));
    await audit({ action: "room.delete", userId: ctx.user.id, orgId, entityType: "room", entityId: room.id, before: { name: room.name } });
    revalidatePath(`/app/${orgId}/charte/sites`);
    return { ok: true, message: "Salle supprimée." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}
