import "server-only";
import { and, asc, desc, eq, inArray, isNull, lt, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { todayParis } from "@/lib/time";
import { OPEN_STATUSES, TASK_FAMILIES, TASK_PRIORITIES, TASK_STATUSES, type TaskFamily, type TaskPriority, type TaskStatus } from "./rules";

export type TaskRow = typeof schema.tasks.$inferSelect;

/**
 * Condition « mes tâches » : tâches assignées à l'utilisateur, ou à l'un de ses rôles sans responsable nommé.
 * Un utilisateur sans rôle (propriétaire sans rôle métier) ne reçoit que ses tâches nommées.
 */
export function myTaskCondition(ctx: OrgContext): SQL {
  const roles = ctx.roles as string[];
  const byRole = roles.length ? and(isNull(schema.tasks.assigneeUserId), inArray(schema.tasks.assigneeRole, roles)) : undefined;
  return or(eq(schema.tasks.assigneeUserId, ctx.user.id), byRole ?? sql`false`)!;
}

export type TaskFilters = {
  status?: string;
  family?: string;
  late?: boolean;
  entityType?: string;
  entityId?: string;
  priority?: string;
  q?: string;
  assignee?: string;
  role?: string;
  unassigned?: boolean;
};

export function readTaskFilters(sp: Record<string, string | string[] | undefined>): TaskFilters {
  const one = (k: string) => {
    const v = sp[k];
    const s = (Array.isArray(v) ? v[0] : v)?.trim();
    return s ? s : undefined;
  };
  const f: TaskFilters = {};
  const status = one("status");
  if (status && ((TASK_STATUSES as readonly string[]).includes(status) || status === "ouvertes" || status === "toutes")) f.status = status;
  const family = one("family");
  if (family && (TASK_FAMILIES as readonly string[]).includes(family)) f.family = family;
  const priority = one("priority");
  if (priority && (TASK_PRIORITIES as readonly string[]).includes(priority)) f.priority = priority;
  if (one("late") === "1") f.late = true;
  if (one("unassigned") === "1") f.unassigned = true;
  const et = one("entityType");
  if (et && /^[a-z_]{2,30}$/.test(et)) f.entityType = et;
  const eid = one("entityId");
  if (eid && /^[0-9a-f-]{36}$/i.test(eid)) f.entityId = eid;
  const q = one("q");
  if (q) f.q = q.slice(0, 80);
  const assignee = one("assignee");
  if (assignee && /^[0-9a-f-]{36}$/i.test(assignee)) f.assignee = assignee;
  const role = one("role");
  if (role && /^[a-z_]{2,30}$/.test(role)) f.role = role;
  return f;
}

export function taskFilterConditions(f: TaskFilters, today: string): SQL[] {
  const c: SQL[] = [];
  if (!f.status || f.status === "ouvertes") c.push(inArray(schema.tasks.status, OPEN_STATUSES));
  else if (f.status !== "toutes") c.push(eq(schema.tasks.status, f.status as TaskStatus));
  if (f.family) c.push(eq(schema.tasks.family, f.family as TaskFamily));
  if (f.priority) c.push(eq(schema.tasks.priority, f.priority as TaskPriority));
  if (f.late) c.push(and(inArray(schema.tasks.status, OPEN_STATUSES), lt(schema.tasks.dueDate, today))!);
  if (f.entityType) c.push(eq(schema.tasks.entityType, f.entityType));
  if (f.entityId) c.push(eq(schema.tasks.entityId, f.entityId));
  if (f.q) c.push(or(sql`${schema.tasks.title} ilike ${`%${f.q}%`}`, sql`${schema.tasks.entityLabel} ilike ${`%${f.q}%`}`)!);
  if (f.assignee) c.push(eq(schema.tasks.assigneeUserId, f.assignee));
  if (f.role) c.push(and(isNull(schema.tasks.assigneeUserId), eq(schema.tasks.assigneeRole, f.role))!);
  if (f.unassigned) c.push(and(isNull(schema.tasks.assigneeUserId), isNull(schema.tasks.assigneeRole))!);
  return c;
}

const ORDER = [sql`case ${schema.tasks.status} when 'bloquee' then 0 when 'en_cours' then 1 when 'a_faire' then 2 else 3 end`, sql`${schema.tasks.dueDate} asc nulls last`, desc(schema.tasks.priority), asc(schema.tasks.createdAt)];

/** Tâches ouvertes liées à un dossier (inscription, session, entreprise, personne, facture…). Utilisable par tous les modules. */
export async function openTasksFor(orgId: string, ref: { entityType: string; entityId: string }): Promise<TaskRow[]> {
  return db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, orgId), eq(schema.tasks.entityType, ref.entityType), eq(schema.tasks.entityId, ref.entityId), inArray(schema.tasks.status, OPEN_STATUSES)))
    .orderBy(...ORDER)
    .limit(100);
}

/** « Mes tâches » : assignées à l'utilisateur, ou à l'un de ses rôles sans responsable nommé. Filtres optionnels. */
export async function myTasks(ctx: OrgContext, filters: TaskFilters = {}, limit = 200): Promise<TaskRow[]> {
  const today = todayParis();
  return db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, ctx.org.id), myTaskCondition(ctx), ...taskFilterConditions(filters, today)))
    .orderBy(...ORDER)
    .limit(limit);
}

/** Nombre de tâches en retard de l'utilisateur (ou de ses rôles). */
export async function overdueCount(ctx: OrgContext): Promise<number> {
  const today = todayParis();
  const [r] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, ctx.org.id), myTaskCondition(ctx), inArray(schema.tasks.status, OPEN_STATUSES), lt(schema.tasks.dueDate, today)));
  return r?.n ?? 0;
}

/** Supervision (tasks.view_all) : toutes les tâches de l'organisme avec filtres. */
export async function allTasks(orgId: string, filters: TaskFilters = {}, limit = 500): Promise<TaskRow[]> {
  const today = todayParis();
  return db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, orgId), ...taskFilterConditions(filters, today)))
    .orderBy(...ORDER)
    .limit(limit);
}

/** Une tâche de l'organisme (jamais sans filtre orgId). */
export async function taskById(orgId: string, taskId: string): Promise<TaskRow | null> {
  if (!/^[0-9a-f-]{36}$/i.test(taskId)) return null;
  const [t] = await db.select().from(schema.tasks).where(and(eq(schema.tasks.id, taskId), eq(schema.tasks.orgId, orgId))).limit(1);
  return t ?? null;
}

export async function taskEvents(taskId: string) {
  return db
    .select({ e: schema.taskEvents, firstName: schema.users.firstName, lastName: schema.users.lastName })
    .from(schema.taskEvents)
    .leftJoin(schema.users, eq(schema.users.id, schema.taskEvents.userId))
    .where(eq(schema.taskEvents.taskId, taskId))
    .orderBy(asc(schema.taskEvents.at));
}

/** Membres actifs de l'organisme (pour l'affectation) : id, nom, rôles. */
export async function orgStaff(orgId: string) {
  const rows = await db
    .select({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, roles: schema.memberships.roles, active: schema.memberships.active })
    .from(schema.memberships)
    .innerJoin(schema.users, eq(schema.users.id, schema.memberships.userId))
    .where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.active, true), isNull(schema.users.disabledAt)))
    .orderBy(asc(schema.users.lastName), asc(schema.users.firstName));
  return rows
    .map((r) => ({ id: r.id, name: `${r.firstName} ${r.lastName}`, roles: (Array.isArray(r.roles) ? (r.roles as string[]) : []).filter((x) => x !== "learner" && x !== "employer") }))
    .filter((r) => r.roles.length > 0);
}

/** Peut agir sur une tâche : responsable nommé, membre du rôle destinataire, ou superviseur (tasks.view_all). */
export function canActOnTask(ctx: OrgContext, task: TaskRow): boolean {
  if (ctx.permissions.has("tasks.view_all")) return true;
  if (task.assigneeUserId === ctx.user.id) return true;
  if (!task.assigneeUserId && task.assigneeRole && (ctx.roles as string[]).includes(task.assigneeRole)) return true;
  return false;
}

/** Peut voir une tâche : idem, plus toute personne ayant tasks.manage pour une tâche sans responsable (à affecter). */
export function canViewTask(ctx: OrgContext, task: TaskRow): boolean {
  if (canActOnTask(ctx, task)) return true;
  return !task.assigneeUserId && !task.assigneeRole && ctx.permissions.has("tasks.manage");
}
