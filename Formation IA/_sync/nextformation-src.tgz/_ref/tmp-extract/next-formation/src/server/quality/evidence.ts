import "server-only";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";

type Level = (typeof schema.evidenceLevelEnum.enumValues)[number];

/**
 * Enregistre une preuve qualité reliée à une action réelle (document généré, période clôturée, enquête reçue…).
 * Idempotent par (orgId, indicatorCode, sourceType, sourceId). Le système n'invente jamais une preuve :
 * l'appelant transmet toujours la source réelle. Une preuve ajoutée après une analyse exige une nouvelle analyse (F13).
 */
export async function recordEvidence(input: {
  orgId: string;
  indicatorCode: string;
  level: Level;
  title: string;
  sourceType: string;
  sourceId: string;
  note?: string | null;
  evidenceDate?: string | null;
  enrollmentId?: string | null;
  sessionId?: string | null;
  programId?: string | null;
  documentId?: string | null;
  createdBy?: string | null;
}) {
  const [existing] = await db
    .select({ id: schema.qualityEvidences.id })
    .from(schema.qualityEvidences)
    .where(
      and(
        eq(schema.qualityEvidences.orgId, input.orgId),
        eq(schema.qualityEvidences.indicatorCode, input.indicatorCode),
        eq(schema.qualityEvidences.sourceType, input.sourceType),
        eq(schema.qualityEvidences.sourceId, input.sourceId),
        eq(schema.qualityEvidences.status, "valide"),
      ),
    )
    .limit(1);
  if (existing) return { id: existing.id, created: false as const };
  const [row] = await db
    .insert(schema.qualityEvidences)
    .values({
      orgId: input.orgId,
      indicatorCode: input.indicatorCode,
      level: input.level,
      title: input.title,
      note: input.note ?? null,
      evidenceDate: input.evidenceDate ?? null,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      enrollmentId: input.enrollmentId ?? null,
      sessionId: input.sessionId ?? null,
      programId: input.programId ?? null,
      documentId: input.documentId ?? null,
      createdBy: input.createdBy ?? null,
    })
    .returning({ id: schema.qualityEvidences.id });
  return { id: row.id, created: true as const };
}
