/**
 * Phase planning et pédagogie : séances, périodes, présences, corrections, feuilles historiques,
 * évaluations, livret, suivi en entreprise, progression e-learning, cohortes d'examen.
 */
import { and, eq, inArray } from "drizzle-orm";
import { schema } from "@/db";
import { parisToInstant } from "@/lib/time";
import { addD, chunk, daysAgo, plusMin, weekday } from "./util";
import { sessionCenterDays } from "./phase-base";
import { bump, type PeriodInfo, type SessionKey, type State, type Tx } from "./state";

const PARTS = [
  { part: "matin" as const, startTime: "09:00", endTime: "12:00" },
  { part: "apres_midi" as const, startTime: "14:00", endTime: "17:00" },
];

export async function phasePlanning(tx: Tx, s: State) {
  const { orgId, users, rng } = s;
  const S = s.sessions;

  /* ---------- Journée fractionnée (R04) et journée témoin ---------- */
  const arhDays = sessionCenterDays(s, S.arh);
  const closedOrMorningClosed = arhDays.filter((d) => d < s.today || (d === s.today && s.nowTime >= "12:00"));
  s.splitDate = closedOrMorningClosed[closedOrMorningClosed.length - 1];
  const before = arhDays.filter((d) => d < s.splitDate);
  s.witnessDay = before[before.length - 1];

  /* ---------- Séances et périodes ---------- */
  type SlotMeta = { sessionKey: SessionKey; groupIdx: number | null; date: string };
  const slotMeta: SlotMeta[] = [];
  const slotValues: (typeof schema.slots.$inferInsert)[] = [];
  const withSlots: SessionKey[] = ["bts", "arh", "sst1", "xls1", "mgt", "elec", "xls2", "intra"];
  for (const key of withSlots) {
    const info = S[key];
    const days = sessionCenterDays(s, info);
    const groups = key === "bts" ? [0, 1] : [null];
    for (const date of days) {
      for (const g of groups) {
        const moduleIds = s.programs[info.programKey].moduleIds;
        slotMeta.push({ sessionKey: key, groupIdx: g, date });
        slotValues.push({
          orgId,
          sessionId: info.id,
          groupId: g === null ? null : info.groupIds[g],
          date,
          title: key === "bts" ? (weekday(date) === 1 ? "Blocs 1 et 3 : gestion et personnel" : "CEJM, anglais et ateliers") : undefined,
          moduleId: moduleIds[(weekday(date) + (g ?? 0)) % moduleIds.length] ?? null,
          siteId: info.siteId,
          roomId: g === null ? info.roomIds[0] ?? null : info.roomIds[g] ?? null,
          trainerId: info.trainerId,
          status: date >= s.today && key === "mgt" && date === days[0] ? "confirmee" : "prevue",
        });
      }
    }
  }
  const slotRows: { id: string }[] = [];
  for (const c of chunk(slotValues, 500)) slotRows.push(...(await tx.insert(schema.slots).values(c).returning({ id: schema.slots.id })));
  bump(s, "slots", slotRows.length);

  const periodValues: (typeof schema.periods.$inferInsert)[] = [];
  const periodMeta: Omit<PeriodInfo, "id">[] = [];
  slotMeta.forEach((m, i) => {
    const info = S[m.sessionKey];
    const closer = info.trainerUserId ?? users.pedagogy;
    for (const p of PARTS) {
      const forcedOpenAfternoon = m.sessionKey === "arh" && m.date === s.splitDate && p.part === "apres_midi";
      const closed = !forcedOpenAfternoon && (m.date < s.today || (m.date === s.today && s.nowTime >= p.endTime));
      const open = !closed && !forcedOpenAfternoon && m.date === s.today && s.nowTime >= p.startTime;
      const status = closed ? "cloturee" : open ? "ouverte" : "prevue";
      const start = parisToInstant(m.date, p.startTime);
      const end = parisToInstant(m.date, p.endTime);
      const signed = closed ? plusMin(end, rng.int(2, 14)) : null;
      periodMeta.push({ slotId: slotRows[i].id, sessionKey: m.sessionKey, groupIdx: m.groupIdx, date: m.date, part: p.part, startTime: p.startTime, endTime: p.endTime, status });
      periodValues.push({
        orgId,
        slotId: slotRows[i].id,
        part: p.part,
        startTime: p.startTime,
        endTime: p.endTime,
        breakMinutes: 0,
        trainerId: info.trainerId,
        roomId: slotValues[i].roomId ?? null,
        status,
        openedAt: closed || open ? plusMin(start, -rng.int(2, 8)) : null,
        openedBy: closed || open ? closer : null,
        trainerSignedAt: signed,
        closedAt: signed ? plusMin(signed, rng.int(1, 4)) : null,
        closedBy: signed ? closer : null,
      });
    }
  });
  const periodRows: { id: string }[] = [];
  for (const c of chunk(periodValues, 500)) periodRows.push(...(await tx.insert(schema.periods).values(c).returning({ id: schema.periods.id })));
  s.periods = periodMeta.map((m, i) => ({ id: periodRows[i].id, ...m }));
  bump(s, "periods", periodRows.length);

  /* ---------- Présences ---------- */
  const active = (sessionKey: SessionKey, groupIdx: number | null, date: string) =>
    s.enrollments.filter((e) => e.sessionKey === sessionKey && (groupIdx === null || e.groupIdx === groupIdx) && (e.status === "en_cours" || e.status === "termine" || (e.status === "abandon" && e.exitDate !== null && date <= e.exitDate)));
  const arhEnrs = s.enrollments.filter((e) => e.sessionKey === "arh");
  const btsA = s.enrollments.filter((e) => e.sessionKey === "bts" && e.groupIdx === 0);
  const attValues: (typeof schema.attendances.$inferInsert)[] = [];
  let correctionPeriod: PeriodInfo | null = null;
  const closedBtsA = s.periods.filter((p) => p.sessionKey === "bts" && p.groupIdx === 0 && p.status === "cloturee");
  correctionPeriod = closedBtsA[closedBtsA.length - 1] ?? null;
  const correctionEnrollment = btsA[3];

  for (const p of s.periods) {
    if (p.status === "prevue") continue;
    const info = S[p.sessionKey];
    const recorder = info.trainerUserId ?? users.pedagogy;
    const start = parisToInstant(p.date, p.startTime);
    for (const e of active(p.sessionKey, p.groupIdx, p.date)) {
      let status: (typeof schema.attendanceStatusEnum.enumValues)[number] = "present";
      let arrivedAt: string | null = null;
      let leftAt: string | null = null;
      let minutes = 180;
      let note: string | null = null;
      if (p.status === "ouverte") {
        if (!rng.chance(0.75)) {
          attValues.push({ orgId, periodId: p.id, enrollmentId: e.id, status: "non_saisie", minutesCounted: 0, isCurrent: true });
          continue;
        }
      } else if (p.sessionKey === "arh" && p.date === s.witnessDay && e.id === arhEnrs[1].id && p.part === "apres_midi") {
        status = "absent_justifie";
        minutes = 0;
        note = "Rendez-vous médical (justificatif reçu).";
      } else if (p.sessionKey === "arh" && p.date === s.witnessDay && (e.id === arhEnrs[0].id || e.id === arhEnrs[1].id)) {
        status = "present";
      } else if (correctionPeriod && p.id === correctionPeriod.id && e.id === correctionEnrollment?.id) {
        status = "absent";
        minutes = 0;
      } else {
        const r = rng.next();
        if (r < 0.88) status = "present";
        else if (r < 0.92) {
          status = "retard";
          arrivedAt = p.part === "matin" ? "09:25" : "14:20";
          minutes = p.part === "matin" ? 155 : 160;
        } else if (r < 0.94) {
          status = "depart_anticipe";
          leftAt = p.part === "matin" ? "11:30" : "16:15";
          minutes = p.part === "matin" ? 150 : 135;
        } else if (r < 0.97) {
          status = "absent_justifie";
          minutes = 0;
          note = rng.pick(["Arrêt maladie (justificatif reçu).", "Convocation administrative.", "Enfant malade, certificat fourni."]);
        } else {
          status = "absent";
          minutes = 0;
        }
      }
      const signedAt = status === "present" || status === "depart_anticipe" ? plusMin(start, rng.int(0, 9)) : status === "retard" ? parisToInstant(p.date, arrivedAt!) : null;
      attValues.push({ orgId, periodId: p.id, enrollmentId: e.id, status, arrivedAt, leftAt, minutesCounted: minutes, justificationNote: note, learnerSignedAt: signedAt, signatureMethod: signedAt ? (rng.chance(0.6) ? "tablette" : "qr") : null, signatureIp: signedAt ? "10.12.4.21" : null, recordedBy: recorder, recordedAt: signedAt ?? plusMin(start, 15), isCurrent: true });
    }
  }
  for (const c of chunk(attValues, 500)) await tx.insert(schema.attendances).values(c);
  bump(s, "attendances", attValues.length);

  /* ---------- Demande de correction en attente ---------- */
  if (correctionPeriod && correctionEnrollment) {
    const [att] = await tx.select({ id: schema.attendances.id }).from(schema.attendances).where(and(eq(schema.attendances.periodId, correctionPeriod.id), eq(schema.attendances.enrollmentId, correctionEnrollment.id), eq(schema.attendances.isCurrent, true))).limit(1);
    await tx.insert(schema.attendanceCorrections).values({ orgId, periodId: correctionPeriod.id, attendanceId: att?.id ?? null, enrollmentId: correctionEnrollment.id, reason: "L'apprenti était présent (travail de groupe en salle Camus) mais n'a pas signé la tablette avant la clôture.", requested: { status: "present", arrivedAt: null, leftAt: null, justificationNote: "Présence attestée par le formateur." }, before: { status: "absent", minutesCounted: 0 }, status: "demandee", requestedBy: users.trainer });
    s.corrections = 1;
    bump(s, "attendance_corrections", 1);
  }

  /* ---------- Feuilles historiques (reprise, jamais converties) ---------- */
  const legacyEnrs = s.enrollments.filter((e) => e.sessionKey === "arhA").slice(0, 3);
  await tx.insert(schema.legacyAttendanceSheets).values(
    legacyEnrs.map((e, i) => ({ orgId, enrollmentId: e.id, date: addD(S.arhA.startDate, 7 + i), hours: 360, signed: true, source: "Feuille journalière papier (classeur 2026-A)", reconciled: false, note: "Signature journalière unique : non convertible en deux périodes." })),
  );
  bump(s, "legacy_attendance_sheets", legacyEnrs.length);

  /* ---------- Évaluations ---------- */
  const evalValues: (typeof schema.evaluations.$inferInsert)[] = [];
  const P = s.programs;
  for (const e of s.enrollments) {
    const info = S[e.sessionKey];
    const mods = P[info.programKey].moduleIds;
    const evaluator = info.trainerUserId ?? users.pedagogy;
    if (e.sessionKey === "bts" && e.status !== "annule") {
      evalValues.push({ orgId, enrollmentId: e.id, kind: "positionnement", title: "Test de positionnement d'entrée (gestion, expression, anglais)", date: info.startDate, score: rng.int(8, 18), maxScore: 20, result: "non_evalue", evaluatorId: users.pedagogy, comment: "Positionnement d'entrée : sert à adapter le parcours, pas à noter." });
      if (e.status === "en_cours") evalValues.push({ orgId, enrollmentId: e.id, moduleId: mods[3], kind: "formative", title: "Bloc 1 : étude de cas « relation fournisseurs »", date: addD(info.startDate, 35), score: rng.int(7, 19), maxScore: 20, result: rng.pick(["acquis", "en_cours", "partiel"]), skills: [{ code: "B1.3", label: "Suivre les achats", level: rng.pick(["acquis", "en cours"]) }], evaluatorId: evaluator });
    }
    if (e.sessionKey === "arh" && e.status !== "annule") {
      evalValues.push({ orgId, enrollmentId: e.id, kind: "positionnement", title: "Positionnement RH et bureautique", date: info.startDate, result: "non_evalue", skills: [{ code: "C1", label: "Administration du personnel", level: rng.pick(["débutant", "intermédiaire"]) }], evaluatorId: users.pedagogy });
      evalValues.push({ orgId, enrollmentId: e.id, moduleId: mods[1], kind: "formative", title: "ECF 1 : dossier d'embauche et DPAE", date: addD(info.startDate, 28), score: rng.int(9, 20), maxScore: 20, result: rng.pick(["acquis", "acquis", "partiel"]), evaluatorId: users.pedagogy });
    }
    if (e.sessionKey === "arhA") {
      evalValues.push({ orgId, enrollmentId: e.id, kind: "positionnement", title: "Positionnement RH et bureautique", date: info.startDate, result: "non_evalue", evaluatorId: users.pedagogy });
      evalValues.push({ orgId, enrollmentId: e.id, kind: "sommative", title: "ECF 2 : préparation d'un bulletin de paie", date: addD(info.startDate, 90), score: rng.int(10, 20), maxScore: 20, result: "acquis", evaluatorId: users.pedagogy });
    }
    if (e.sessionKey === "sst1") evalValues.push({ orgId, enrollmentId: e.id, kind: "finale", title: "Épreuves certificatives SST (mises en situation)", date: info.endDate, result: e === s.enrollments.filter((x) => x.sessionKey === "sst1")[8] ? "non_acquis" : "acquis", comment: "Grille de certification INRS.", evaluatorId: users.pedagogy });
    if (e.sessionKey === "xls1") evalValues.push({ orgId, enrollmentId: e.id, kind: "finale", title: "Cas final : synthèse des ventes (TCD et Power Query)", date: info.endDate, score: rng.int(11, 20), maxScore: 20, result: "acquis", evaluatorId: users.pedagogy });
  }
  for (const c of chunk(evalValues, 500)) await tx.insert(schema.evaluations).values(c);
  bump(s, "evaluations", evalValues.length);

  /* ---------- Livret et suivi en entreprise ---------- */
  const recordValues: (typeof schema.recordEntries.$inferInsert)[] = [];
  for (const e of btsA.filter((x) => x.status === "en_cours")) {
    recordValues.push({ orgId, enrollmentId: e.id, kind: "objectif", date: S.bts.startDate, title: "Objectifs de la première période", body: "Découvrir l'organisation de l'entreprise, prendre en main les outils de gestion commerciale, participer au suivi des commandes.", authorId: users.pedagogy, authorRole: "pedagogy_manager", visibleToCompany: true });
    recordValues.push({ orgId, enrollmentId: e.id, kind: "activite", date: addD(S.bts.startDate, 21), title: "Activités réalisées en entreprise", body: rng.pick(["Saisie des devis clients, relance des impayés avec la comptable.", "Mise à jour de la base fournisseurs et comparatif de tarifs.", "Préparation des éléments variables de paie du mois."]), authorId: null, authorRole: "learner", visibleToCompany: true });
    if (e.isInes) recordValues.push({ orgId, enrollmentId: e.id, kind: "entreprise", date: daysAgo(s.today, 8), title: "Observation du maître d'apprentissage", body: "Inès est autonome sur l'accueil téléphonique et commence le suivi des commandes fournisseurs. Point à faire sur l'orthographe des courriers.", authorId: users.employer, authorRole: "employer", visibleToCompany: true });
  }
  for (const e of arhEnrs.slice(0, 4)) recordValues.push({ orgId, enrollmentId: e.id, kind: "bilan", date: addD(S.arh.startDate, 30), title: "Bilan intermédiaire à un mois", body: "Progression conforme ; recherche de stage engagée (deux candidatures).", authorId: users.pedagogy, authorRole: "pedagogy_manager" });
  await tx.insert(schema.recordEntries).values(recordValues);
  bump(s, "record_entries", recordValues.length);

  const followTargets = s.enrollments.filter((e) => e.sessionKey === "bts" && e.status === "en_cours").slice(0, 6);
  await tx.insert(schema.companyFollowups).values(
    followTargets.map((e, i) => ({
      orgId,
      enrollmentId: e.id,
      kind: (["visite", "appel", "echange_tuteur", "visio", "visite", "bilan_intermediaire"] as const)[i],
      date: daysAgo(s.today, [12, 20, 5, 30, 40, 15][i]),
      tutorContactId: e.tutorContactId,
      summary: e.isInes ? "Visite en entreprise : poste adapté, tuteur disponible. Rappel : CERFA signé à retourner au CFA." : rng.pick(["Point téléphonique avec le tuteur : intégration satisfaisante.", "Visite de l'atelier, présentation des missions du semestre.", "Échange sur les horaires et le livret, rien à signaler."]),
      actions: i === 2 ? "Replanifier la visite reportée par l'entreprise." : i === 0 ? "Relancer l'employeur pour le CERFA signé." : null,
      nextDate: i === 2 ? daysAgo(s.today, 9) : addD(s.today, [25, 40, 0, 60, 70, 35][i]),
      authorId: i % 2 ? users.pedagogy : users.trainer,
    })),
  );
  bump(s, "company_followups", followTargets.length);

  /* ---------- Progression e-learning ---------- */
  const progress: (typeof schema.elearningProgress.$inferInsert)[] = [];
  arhEnrs.filter((e) => e.status === "en_cours").slice(0, 8).forEach((e, i) => {
    const done = i < 7;
    progress.push({ orgId, elearningModuleId: s.elearningIds[0], enrollmentId: e.id, status: done ? "termine" : "en_cours", timeSpentMinutes: done ? rng.int(80, 110) : 35, score: done ? rng.int(12, 20) : null, maxScore: done ? 20 : null, lastAccessAt: new Date(s.now.getTime() - rng.int(1, 10) * 86400_000), completedAt: done ? new Date(s.now.getTime() - rng.int(1, 9) * 86400_000) : null, validatedBy: done && i < 5 ? users.pedagogy : null, validatedAt: done && i < 5 ? new Date(s.now.getTime() - 86400_000) : null, raw: { source: "contenu" } });
    if (i < 4) progress.push({ orgId, elearningModuleId: s.elearningIds[1], enrollmentId: e.id, status: "en_cours", timeSpentMinutes: rng.int(40, 150), lastAccessAt: new Date(s.now.getTime() - rng.int(1, 5) * 86400_000), raw: { provider: "moodle", completion: rng.int(20, 70) } });
  });
  s.enrollments.filter((e) => e.sessionKey === "bts" && e.status === "en_cours").slice(0, 10).forEach((e) => progress.push({ orgId, elearningModuleId: s.elearningIds[2], enrollmentId: e.id, status: "termine", score: rng.int(5, 10), maxScore: 10, timeSpentMinutes: rng.int(8, 20), completedAt: new Date(s.now.getTime() - rng.int(2, 20) * 86400_000), lastAccessAt: new Date(s.now.getTime() - rng.int(2, 20) * 86400_000), raw: { attempts: 1 } }));
  await tx.insert(schema.elearningProgress).values(progress);
  bump(s, "elearning_progress", progress.length);

  /* ---------- Cohortes d'examen ---------- */
  const arhA = s.enrollments.filter((e) => e.sessionKey === "arhA");
  const juryDate = addD(S.arhA.endDate, 17);
  const blancDate = addD(S.bts.startDate, 112);
  const cohortRows = await tx
    .insert(schema.examCohorts)
    .values([
      { orgId, programId: P.arh.id, code: `JURY-ARH-${juryDate.slice(0, 7)}`, label: "Jury titre professionnel ARH, session A", date: juryDate, endDate: addD(juryDate, 1), capacity: 12, managerUserId: users.pedagogy, siteId: s.siteIds.paris, scope: "complet", status: "terminee", notes: "Jury de 3 membres, 2 jours de mises en situation. Résultats transmis à la DREETS." },
      { orgId, programId: P.bts.id, code: `BTS-BLANC-${blancDate.slice(0, 7)}`, label: "BTS blanc n° 1 (blocs 1 et 3)", date: blancDate, endDate: addD(blancDate, 1), capacity: 24, managerUserId: users.pedagogy, siteId: s.siteIds.paris, scope: "blocs", blocks: ["BC01", "BC03"], status: "convoquee", notes: "Épreuves écrites en salle Simone-Veil, convocations envoyées au groupe A ; groupe B à convoquer." },
    ])
    .returning({ id: schema.examCohorts.id });
  s.cohorts = { arhA: cohortRows[0].id, btsBlanc: cohortRows[1].id };
  const results = ["admis", "admis", "admis", "admis", "admis", "admis", "ajourne", "ajourne", "partiel", "absent"] as const;
  const examStates = { admis: "admis", ajourne: "rattrapage", partiel: "rattrapage", absent: "absent" } as const;
  const memberValues: (typeof schema.examMembers.$inferInsert)[] = arhA.map((e, i) => ({
    orgId,
    cohortId: cohortRows[0].id,
    enrollmentId: e.id,
    status: results[i] === "absent" ? "absent" : "present",
    result: results[i],
    blockResults: results[i] === "partiel" ? [{ code: "CCP1", result: "admis", score: 14 }, { code: "CCP2", result: "ajourne", score: 8 }] : results[i] === "admis" ? [{ code: "CCP1", result: "admis" }, { code: "CCP2", result: "admis" }] : [],
    score: results[i] === "absent" ? null : rng.int(8, 18),
    observations: results[i] === "ajourne" ? "Dossier professionnel incomplet, mise en situation insuffisante sur la paie. Rattrapage possible à la prochaine session." : results[i] === "absent" ? "Absence justifiée (hospitalisation) : report à la session suivante." : results[i] === "partiel" ? "CCP1 validé ; CCP2 à repasser." : "Félicitations du jury.",
    convokedAt: new Date(`${addD(juryDate, -21)}T09:00:00Z`),
    resultRecordedBy: users.pedagogy,
    resultRecordedAt: new Date(`${addD(juryDate, 2)}T17:30:00Z`),
    assignedBy: users.pedagogy,
  }));
  const btsEn = s.enrollments.filter((e) => e.sessionKey === "bts" && e.status === "en_cours");
  const convoked = btsEn.filter((e) => e.groupIdx === 0);
  const registered = btsEn.filter((e) => e.groupIdx === 1).slice(0, 8);
  for (const e of convoked) memberValues.push({ orgId, cohortId: cohortRows[1].id, enrollmentId: e.id, status: "convoque", convokedAt: new Date(`${daysAgo(s.today, 3)}T11:00:00Z`), assignedBy: users.pedagogy, accommodations: s.persons.find((p) => p.id === e.personId) && e === btsA[7] ? "Tiers-temps" : null });
  for (const e of registered) memberValues.push({ orgId, cohortId: cohortRows[1].id, enrollmentId: e.id, status: "inscrit", assignedBy: users.pedagogy });
  await tx.insert(schema.examMembers).values(memberValues);
  for (const [i, e] of arhA.entries()) await tx.update(schema.enrollments).set({ examState: examStates[results[i]] }).where(eq(schema.enrollments.id, e.id));
  await tx.update(schema.enrollments).set({ examState: "inscrit" }).where(inArray(schema.enrollments.id, [...convoked, ...registered].map((e) => e.id)));
  bump(s, "exam_cohorts", 2);
  bump(s, "exam_members", memberValues.length);
}
