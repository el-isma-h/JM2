import "server-only";
import { and, desc, eq, sql } from "drizzle-orm";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { db, schema } from "@/db";
import { randomToken, sha256 } from "@/lib/crypto";
import { appUrl, integrations } from "@/lib/env";
import { fmtDateTime } from "@/lib/dates";
import { AuthError } from "@/server/auth";
import type { OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { layoutMail, sendMail } from "@/server/mail";
import { recordEvidence } from "@/server/quality/evidence";
import { buildKey, getObject, putObject } from "@/server/storage";
import { getESignAdapter } from "./esign";
import { pngStructureOk } from "./signatures-png";
import { getVisibleDocument } from "./queries";
import { createDocument, issueDownloadLink, readDocument } from "./store";

/* ---------- Types ---------- */

export const SIGNER_ROLES = ["organisme", "entreprise", "apprenant", "tuteur", "autre"] as const;
export type SignerRole = (typeof SIGNER_ROLES)[number];
export const SIGNER_ROLE_LABELS: Record<SignerRole, string> = { organisme: "Organisme de formation", entreprise: "Entreprise", apprenant: "Apprenant / stagiaire", tuteur: "Tuteur", autre: "Autre signataire" };

export type Signer = {
  id: string;
  name: string;
  email: string;
  role: SignerRole;
  /** Jeton d'accès hashé (sha256) ; le jeton clair n'est envoyé que par e-mail. */
  tokenHash: string;
  otpHash?: string | null;
  otpExpiresAt?: string | null;
  otpAttempts?: number;
  otpSentAt?: string | null;
  consentAt?: string | null;
  signedAt?: string | null;
  ip?: string | null;
  userAgent?: string | null;
  signatureKey?: string | null;
  signatureSha256?: string | null;
};

export type SignatureRequestRow = typeof schema.signatureRequests.$inferSelect;

export const OTP_TTL_MINUTES = 10;
export const OTP_MAX_ATTEMPTS = 5;
export const REQUEST_TTL_DAYS = 30;

function signersOf(r: SignatureRequestRow): Signer[] {
  return Array.isArray(r.signers) ? (r.signers as Signer[]) : [];
}

/** Vue publique d'un signataire : jamais de hash ni de code. */
export function publicSigner(s: Signer) {
  return { id: s.id, name: s.name, email: s.email, role: s.role, signedAt: s.signedAt ?? null, consentAt: s.consentAt ?? null, ip: s.ip ?? null, userAgent: s.userAgent ?? null };
}

/* ---------- Création ---------- */

export async function createSignatureRequest(input: {
  ctx: OrgContext;
  documentId: string;
  signers: { name: string; email: string; role: SignerRole }[];
  message?: string | null;
}): Promise<{ request: SignatureRequestRow; links: { name: string; email: string; url: string }[]; mailStatus: string; notConfiguredMessage?: string }> {
  const { ctx } = input;
  if (!ctx.permissions.has("documents.generate")) throw new AuthError("forbidden");
  const doc = await getVisibleDocument(ctx, input.documentId);
  if (!doc) throw new Error("Document introuvable.");
  if (doc.mimeType !== "application/pdf") throw new Error("Seul un document PDF peut être soumis à signature.");
  if (!["genere", "transmis", "brouillon"].includes(doc.status)) throw new Error(`Ce document est « ${doc.status} » : il ne peut plus être soumis à signature. Générez une nouvelle version.`);
  if (!input.signers.length) throw new Error("Ajoutez au moins un signataire.");
  const [pending] = await db
    .select({ id: schema.signatureRequests.id })
    .from(schema.signatureRequests)
    .where(and(eq(schema.signatureRequests.orgId, ctx.org.id), eq(schema.signatureRequests.documentId, doc.id), sql`${schema.signatureRequests.status} in ('envoyee','signee_partiellement')`))
    .limit(1);
  if (pending) throw new Error("Une demande de signature est déjà en cours pour ce document.");

  const expiresAt = new Date(Date.now() + REQUEST_TTL_DAYS * 86400_000);
  const tokens: { signer: Signer; token: string }[] = input.signers.map((s) => {
    const token = randomToken(32);
    return { token, signer: { id: randomToken(8), name: s.name, email: s.email.toLowerCase(), role: s.role, tokenHash: sha256(token), otpAttempts: 0 } };
  });

  // Prestataire externe si configuré, sinon signature interne.
  const esign = getESignAdapter();
  let provider = "interne";
  let providerRef: string | null = null;
  let status: SignatureRequestRow["status"] = "envoyee";
  let notConfiguredMessage: string | undefined;
  if (process.env.ESIGN_PROVIDER) {
    if (esign.ok) {
      const data = await getObject(doc.storageKey);
      const res = await esign.adapter.send({ documentId: doc.id, fileName: doc.fileName, data, title: doc.title, signers: tokens.map((t) => ({ name: t.signer.name, email: t.signer.email, role: t.signer.role === "entreprise" ? "employer" : t.signer.role === "apprenant" ? "employee" : "other" })) });
      provider = esign.adapter.name;
      providerRef = res.providerRef;
    } else {
      provider = process.env.ESIGN_PROVIDER;
      status = "non_configure";
      notConfiguredMessage = esign.message;
    }
  }

  const [request] = await db
    .insert(schema.signatureRequests)
    .values({ orgId: ctx.org.id, documentId: doc.id, provider, providerRef, status, signers: tokens.map((t) => t.signer), expiresAt, requestedBy: ctx.user.id })
    .returning();

  const links: { name: string; email: string; url: string }[] = [];
  let mailStatus = "non_envoye";
  if (provider === "interne") {
    for (const t of tokens) {
      const url = `${appUrl()}/signer/${t.token}`;
      links.push({ name: t.signer.name, email: t.signer.email, url });
      const res = await sendMail({
        to: t.signer.email,
        subject: `Document à signer : ${doc.title}`,
        html: layoutMail(
          "Un document attend votre signature",
          `<p>Bonjour ${t.signer.name},</p><p>${ctx.org.legalName} vous invite à signer électroniquement le document <strong>${doc.title}</strong>.</p>${input.message ? `<p>${input.message}</p>` : ""}<p>Le lien est personnel et valable ${REQUEST_TTL_DAYS} jours. Un code de confirmation vous sera envoyé par e-mail au moment de signer.</p>`,
          { label: "Lire et signer", url },
        ),
        text: `Bonjour ${t.signer.name}, ${ctx.org.legalName} vous invite à signer le document « ${doc.title} » : ${url}`,
        isDemo: ctx.org.isDemo,
      });
      mailStatus = res.status;
    }
    if (doc.status === "genere" || doc.status === "brouillon") {
      await db.update(schema.documents).set({ status: "transmis", transmittedAt: new Date() }).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, ctx.org.id)));
    }
  }
  await audit({ action: "signature.request", userId: ctx.user.id, orgId: ctx.org.id, entityType: "signature_request", entityId: request.id, after: { documentId: doc.id, provider, status, signers: tokens.map((t) => ({ name: t.signer.name, email: t.signer.email, role: t.signer.role })) } });
  return { request, links, mailStatus, notConfiguredMessage };
}

export async function cancelSignatureRequest(ctx: OrgContext, requestId: string, reason: string) {
  if (!ctx.permissions.has("documents.generate")) throw new AuthError("forbidden");
  const [r] = await db.select().from(schema.signatureRequests).where(and(eq(schema.signatureRequests.id, requestId), eq(schema.signatureRequests.orgId, ctx.org.id))).limit(1);
  if (!r) throw new Error("Demande introuvable.");
  if (r.status === "signee") throw new Error("Une demande entièrement signée ne peut pas être annulée.");
  await db
    .update(schema.signatureRequests)
    .set({ status: "annulee", proof: { ...((r.proof as Record<string, unknown>) ?? {}), cancelledAt: new Date().toISOString(), cancelledBy: ctx.user.id, reason } })
    .where(eq(schema.signatureRequests.id, r.id));
  await audit({ action: "signature.cancel", userId: ctx.user.id, orgId: ctx.org.id, entityType: "signature_request", entityId: r.id, before: { status: r.status }, after: { status: "annulee", reason } });
}

/** Renvoie les liens de signature aux signataires qui n'ont pas encore signé (nouveaux jetons, anciens invalidés). */
export async function resendSignatureLinks(ctx: OrgContext, requestId: string) {
  if (!ctx.permissions.has("documents.generate")) throw new AuthError("forbidden");
  const [r] = await db.select().from(schema.signatureRequests).where(and(eq(schema.signatureRequests.id, requestId), eq(schema.signatureRequests.orgId, ctx.org.id))).limit(1);
  if (!r) throw new Error("Demande introuvable.");
  if (r.provider !== "interne" || !["envoyee", "signee_partiellement"].includes(r.status)) throw new Error("Cette demande ne peut pas être relancée.");
  const [doc] = await db.select().from(schema.documents).where(eq(schema.documents.id, r.documentId)).limit(1);
  const signers = signersOf(r);
  const links: { name: string; email: string; url: string }[] = [];
  const updated = await Promise.all(
    signers.map(async (s) => {
      if (s.signedAt) return s;
      const token = randomToken(32);
      const url = `${appUrl()}/signer/${token}`;
      links.push({ name: s.name, email: s.email, url });
      await sendMail({
        to: s.email,
        subject: `Rappel : document à signer : ${doc?.title ?? "document"}`,
        html: layoutMail("Rappel : un document attend votre signature", `<p>Bonjour ${s.name},</p><p>${ctx.org.legalName} vous rappelle que le document <strong>${doc?.title ?? ""}</strong> attend votre signature.</p>`, { label: "Lire et signer", url }),
        isDemo: ctx.org.isDemo,
      });
      return { ...s, tokenHash: sha256(token), otpHash: null, otpExpiresAt: null, otpAttempts: 0 };
    }),
  );
  await db.update(schema.signatureRequests).set({ signers: updated, expiresAt: new Date(Date.now() + REQUEST_TTL_DAYS * 86400_000) }).where(eq(schema.signatureRequests.id, r.id));
  await audit({ action: "signature.resend", userId: ctx.user.id, orgId: ctx.org.id, entityType: "signature_request", entityId: r.id, after: { to: links.map((l) => l.email) } });
  return links;
}

/* ---------- Côté signataire (public, sans session) ---------- */

export type TokenContext = { request: SignatureRequestRow; signer: Signer; index: number; document: typeof schema.documents.$inferSelect; org: typeof schema.organismes.$inferSelect };

/** Résout un jeton de signature (hash) : demande interne en cours, signataire correspondant, non expirée. */
export async function findByToken(token: string): Promise<TokenContext | null> {
  if (!token || token.length < 20 || token.length > 128) return null;
  const hash = sha256(token);
  const [r] = await db
    .select()
    .from(schema.signatureRequests)
    .where(and(eq(schema.signatureRequests.provider, "interne"), sql`${schema.signatureRequests.signers} @> ${JSON.stringify([{ tokenHash: hash }])}::jsonb`))
    .orderBy(desc(schema.signatureRequests.createdAt))
    .limit(1);
  if (!r) return null;
  const signers = signersOf(r);
  const index = signers.findIndex((s) => s.tokenHash === hash);
  if (index < 0) return null;
  const [document] = await db.select().from(schema.documents).where(and(eq(schema.documents.id, r.documentId), eq(schema.documents.orgId, r.orgId))).limit(1);
  const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, r.orgId)).limit(1);
  if (!document || !org) return null;
  return { request: r, signer: signers[index], index, document, org };
}

export function tokenState(tc: TokenContext): "ok" | "expired" | "closed" | "already_signed" {
  if (tc.signer.signedAt) return "already_signed";
  if (!["envoyee", "signee_partiellement"].includes(tc.request.status)) return "closed";
  if (tc.request.expiresAt && tc.request.expiresAt < new Date()) return "expired";
  return "ok";
}

async function saveSigner(r: SignatureRequestRow, index: number, patch: Partial<Signer>) {
  const signers = signersOf(r);
  signers[index] = { ...signers[index], ...patch };
  await db.update(schema.signatureRequests).set({ signers }).where(eq(schema.signatureRequests.id, r.id));
  return signers;
}

/** Envoie un code OTP à 6 chiffres au signataire (valable 10 minutes). Retourne le code uniquement en démonstration ou sans e-mail configuré. */
export async function sendOtp(token: string): Promise<{ ok: true; demoCode: string | null; mailStatus: string } | { ok: false; error: string }> {
  const tc = await findByToken(token);
  if (!tc) return { ok: false, error: "Lien de signature invalide." };
  const state = tokenState(tc);
  if (state !== "ok") return { ok: false, error: state === "already_signed" ? "Vous avez déjà signé ce document." : state === "expired" ? "Ce lien a expiré." : "Cette demande de signature est close." };
  if (tc.signer.otpSentAt && Date.now() - new Date(tc.signer.otpSentAt).getTime() < 30_000) return { ok: false, error: "Un code vient d'être envoyé : patientez trente secondes avant d'en demander un autre." };
  const code = String(Math.floor(100000 + Math.random() * 900000));
  await saveSigner(tc.request, tc.index, { otpHash: sha256(`${tc.signer.tokenHash}:${code}`), otpExpiresAt: new Date(Date.now() + OTP_TTL_MINUTES * 60_000).toISOString(), otpAttempts: 0, otpSentAt: new Date().toISOString() });
  const res = await sendMail({
    to: tc.signer.email,
    subject: `Votre code de signature : ${tc.document.title}`,
    html: layoutMail("Code de confirmation de signature", `<p>Bonjour ${tc.signer.name},</p><p>Votre code de confirmation pour signer le document <strong>${tc.document.title}</strong> est :</p><p style="font-size:28px;letter-spacing:.3em;font-family:monospace"><strong>${code}</strong></p><p>Il est valable ${OTP_TTL_MINUTES} minutes. Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.</p>`),
    text: `Votre code de confirmation de signature : ${code} (valable ${OTP_TTL_MINUTES} minutes).`,
    isDemo: tc.org.isDemo,
  });
  const reveal = tc.org.isDemo || !integrations.mail();
  return { ok: true, demoCode: reveal ? code : null, mailStatus: res.status };
}

/** Signature par le signataire : consentement, code OTP vérifié côté serveur, image de signature, horodatage serveur, IP, user-agent. */
export async function signWithToken(input: { token: string; otp: string; signaturePngBase64: string; consent: boolean; ip: string | null; userAgent: string | null }): Promise<{ ok: true; completed: boolean } | { ok: false; error: string }> {
  const tc = await findByToken(input.token);
  if (!tc) return { ok: false, error: "Lien de signature invalide." };
  const state = tokenState(tc);
  if (state !== "ok") return { ok: false, error: state === "already_signed" ? "Vous avez déjà signé ce document." : state === "expired" ? "Ce lien a expiré." : "Cette demande de signature est close." };
  if (!input.consent) return { ok: false, error: "Vous devez déclarer avoir lu le document et consentir à le signer électroniquement." };
  const s = tc.signer;
  if (!s.otpHash || !s.otpExpiresAt) return { ok: false, error: "Demandez d'abord un code de confirmation." };
  if (new Date(s.otpExpiresAt) < new Date()) return { ok: false, error: "Le code a expiré : demandez-en un nouveau." };
  if ((s.otpAttempts ?? 0) >= OTP_MAX_ATTEMPTS) {
    await saveSigner(tc.request, tc.index, { otpHash: null, otpExpiresAt: null });
    return { ok: false, error: "Trop de tentatives : demandez un nouveau code." };
  }
  const code = input.otp.replace(/\D/g, "");
  if (code.length !== 6 || sha256(`${s.tokenHash}:${code}`) !== s.otpHash) {
    await saveSigner(tc.request, tc.index, { otpAttempts: (s.otpAttempts ?? 0) + 1 });
    return { ok: false, error: "Code incorrect." };
  }
  const png = parsePng(input.signaturePngBase64);
  if (!png) return { ok: false, error: "Dessinez votre signature avant de valider." };
  const key = buildKey(tc.org.id, "signature", `${tc.request.id}-${s.id}.png`);
  const stored = await putObject(key, png);
  const now = new Date().toISOString();
  const signers = await saveSigner(tc.request, tc.index, { signedAt: now, consentAt: now, ip: input.ip, userAgent: input.userAgent?.slice(0, 300) ?? null, signatureKey: key, signatureSha256: stored.sha256, otpHash: null, otpExpiresAt: null });
  await audit({ action: "signature.sign", orgId: tc.org.id, entityType: "signature_request", entityId: tc.request.id, after: { signer: s.email, role: s.role, signedAt: now, ip: input.ip } });
  const allSigned = signers.every((x) => x.signedAt);
  if (!allSigned) {
    await db.update(schema.signatureRequests).set({ status: "signee_partiellement" }).where(eq(schema.signatureRequests.id, tc.request.id));
    return { ok: true, completed: false };
  }
  await finalizeSignedDocument(tc.request.id);
  return { ok: true, completed: true };
}

function parsePng(dataUrl: string): Buffer | null {
  const m = dataUrl.match(/^data:image\/png;base64,([A-Za-z0-9+/=]+)$/);
  if (!m) return null;
  const buf = Buffer.from(m[1], "base64");
  if (buf.length < 100 || buf.length > 500_000) return null;
  if (!(buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47)) return null;
  return pngStructureOk(buf) ? buf : null;
}



/** Caractères encodables en WinAnsi (polices standard pdf-lib) ; les autres sont remplacés. */
const ansi = (s: string) => s.replace(/[^\x20-\x7e\xa0-\xffŒœ€‘’“”…]/g, "?");

/**
 * À la dernière signature : PDF signé (document original + tampon de chaque page + page de preuve avec les images),
 * enregistré comme nouveau document (statut `signe`, même catégorie et portée), preuve JSON et preuve qualité.
 */
export async function finalizeSignedDocument(requestId: string) {
  const [r] = await db.select().from(schema.signatureRequests).where(eq(schema.signatureRequests.id, requestId)).limit(1);
  if (!r || r.signedDocumentId) return r?.signedDocumentId ?? null;
  const found = await readDocument(r.documentId);
  if (!found || found.doc.orgId !== r.orgId) throw new Error("Document d'origine introuvable.");
  const { doc, data } = found;
  const signers = signersOf(r);
  const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, r.orgId)).limit(1);

  const pdf = await PDFDocument.load(data, { ignoreEncryption: true });
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const originalSha = sha256(data);
  const stamp = ansi(`Signé électroniquement via Next Formation, demande ${r.id.slice(0, 8)}, empreinte ${originalSha.slice(0, 16)}`);
  for (const page of pdf.getPages()) {
    const { width } = page.getSize();
    page.drawText(stamp, { x: 40, y: 14, size: 6.5, font, color: rgb(0.42, 0.4, 0.38), maxWidth: width - 80 });
  }
  const proofPage = pdf.addPage([595.28, 841.89]);
  let y = 790;
  const wrap = (text: string, size: number, f: typeof font, max: number): string[] => {
    const out: string[] = [];
    for (const para of ansi(text).split("\n")) {
      let cur = "";
      for (const word of para.split(" ")) {
        const next = cur ? `${cur} ${word}` : word;
        if (f.widthOfTextAtSize(next, size) > max && cur) {
          out.push(cur);
          cur = word;
        } else cur = next;
      }
      out.push(cur);
    }
    return out;
  };
  const line = (text: string, size = 10, f = font, color = rgb(0.11, 0.11, 0.1)) => {
    for (const l of wrap(text, size, f, 483)) {
      proofPage.drawText(l, { x: 56, y, size, font: f, color });
      y -= size + 5;
    }
    y -= 1;
  };
  line("Page de preuve de signature électronique", 16, bold);
  y -= 6;
  line(`Document : ${doc.title}`);
  line(`Organisme : ${org?.legalName ?? ""}`);
  line(`Empreinte SHA-256 du document d'origine : ${originalSha}`, 8);
  line(`Demande n° ${r.id}, procédé : signature électronique interne (consentement, code de confirmation par e-mail, horodatage serveur).`, 8);
  y -= 10;
  for (const s of signers) {
    if (y < 160) {
      y = 790;
      pdf.addPage([595.28, 841.89]);
    }
    const page = pdf.getPages()[pdf.getPageCount() - 1];
    const drawLine = (text: string, size = 9.5, f = font) => {
      for (const l of wrap(text, size, f, 300)) {
        page.drawText(l, { x: 56, y, size, font: f, color: rgb(0.11, 0.11, 0.1) });
        y -= size + 5;
      }
    };
    const top = y;
    drawLine(`${s.name} (${SIGNER_ROLE_LABELS[s.role] ?? s.role})`, 11, bold);
    drawLine(`E-mail : ${s.email}`);
    drawLine(`Consentement : ${s.consentAt ? fmtDateTime(new Date(s.consentAt)) : "-"}`);
    drawLine(`Signé le : ${s.signedAt ? fmtDateTime(new Date(s.signedAt)) : "-"} (heure du serveur)`);
    drawLine(`Adresse IP : ${s.ip ?? "-"}`);
    drawLine(`Navigateur : ${(s.userAgent ?? "-").slice(0, 70)}`);
    if (s.signatureKey) {
      try {
        const img = await pdf.embedPng(await getObject(s.signatureKey));
        const dims = img.scaleToFit(170, 70);
        page.drawRectangle({ x: 370, y: top - 76, width: 180, height: 80, borderColor: rgb(0.84, 0.82, 0.78), borderWidth: 0.6 });
        page.drawImage(img, { x: 375 + (170 - dims.width) / 2, y: top - 71 + (70 - dims.height) / 2, width: dims.width, height: dims.height });
      } catch {
        // image illisible : la preuve textuelle reste
      }
    }
    y = Math.min(y, top - 90) - 10;
  }
  const signedBytes = Buffer.from(await pdf.save());
  const signedAt = new Date();
  const signedDoc = await createDocument({
    orgId: doc.orgId,
    enrollmentId: doc.enrollmentId,
    sessionId: doc.sessionId,
    personId: doc.personId,
    companyId: doc.companyId,
    category: doc.category,
    visibility: doc.visibility,
    status: "signe",
    templateCode: doc.templateCode,
    generationData: { signedFrom: doc.id, signatureRequestId: r.id },
    title: `${doc.title} (signé)`,
    fileName: doc.fileName.replace(/\.pdf$/i, "") + "-signe.pdf",
    mimeType: "application/pdf",
    data: signedBytes,
    sourceType: "signed_of",
    sourceId: doc.id,
    uploadedBy: r.requestedBy,
    isDemo: doc.isDemo,
  });
  await db.update(schema.documents).set({ signedAt }).where(eq(schema.documents.id, signedDoc.id));
  const proof = {
    provider: "interne",
    completedAt: signedAt.toISOString(),
    originalDocumentId: doc.id,
    originalSha256: originalSha,
    signedDocumentId: signedDoc.id,
    signedSha256: sha256(signedBytes),
    signers: signers.map((s) => ({ ...publicSigner(s), signatureSha256: s.signatureSha256 ?? null })),
  };
  await db.update(schema.signatureRequests).set({ status: "signee", signedDocumentId: signedDoc.id, proof }).where(eq(schema.signatureRequests.id, r.id));
  await audit({ action: "signature.complete", orgId: r.orgId, entityType: "signature_request", entityId: r.id, after: { signedDocumentId: signedDoc.id, signedSha256: proof.signedSha256 } });
  if (doc.category === "convention" || doc.category === "contrat" || doc.category === "cerfa") {
    await recordEvidence({
      orgId: r.orgId,
      indicatorCode: "IND_1",
      level: "individuel",
      title: `Contractualisation signée : ${doc.title}`,
      sourceType: "signature_request",
      sourceId: r.id,
      evidenceDate: signedAt.toISOString().slice(0, 10),
      enrollmentId: doc.enrollmentId,
      sessionId: doc.sessionId,
      documentId: signedDoc.id,
      createdBy: r.requestedBy,
    });
  }
  return signedDoc.id;
}

/* ---------- Listes ---------- */

export async function listSignatureRequests(orgId: string, opts: { status?: string | null; limit?: number } = {}) {
  return db
    .select({ r: schema.signatureRequests, doc: schema.documents })
    .from(schema.signatureRequests)
    .innerJoin(schema.documents, eq(schema.documents.id, schema.signatureRequests.documentId))
    .where(and(eq(schema.signatureRequests.orgId, orgId), ...(opts.status ? [eq(schema.signatureRequests.status, opts.status as SignatureRequestRow["status"])] : [])))
    .orderBy(desc(schema.signatureRequests.createdAt))
    .limit(opts.limit ?? 200);
}

export async function listRequestsForDocument(orgId: string, documentId: string) {
  return db
    .select()
    .from(schema.signatureRequests)
    .where(and(eq(schema.signatureRequests.orgId, orgId), eq(schema.signatureRequests.documentId, documentId)))
    .orderBy(desc(schema.signatureRequests.createdAt));
}

export { signersOf, issueDownloadLink };
