/**
 * Contrôles d'upload (purs) : type MIME autorisé, extension cohérente, signature binaire, taille maximale.
 */

export const MAX_UPLOAD_BYTES = 20 * 1024 * 1024;

type Rule = { mime: string; exts: string[]; label: string; magic?: number[][] };

export const ALLOWED_TYPES: Rule[] = [
  { mime: "application/pdf", exts: ["pdf"], label: "PDF", magic: [[0x25, 0x50, 0x44, 0x46]] },
  { mime: "image/png", exts: ["png"], label: "PNG", magic: [[0x89, 0x50, 0x4e, 0x47]] },
  { mime: "image/jpeg", exts: ["jpg", "jpeg"], label: "JPEG", magic: [[0xff, 0xd8, 0xff]] },
  {
    mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    exts: ["docx"],
    label: "Word (.docx)",
    magic: [[0x50, 0x4b, 0x03, 0x04]],
  },
  {
    mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    exts: ["xlsx"],
    label: "Excel (.xlsx)",
    magic: [[0x50, 0x4b, 0x03, 0x04]],
  },
  { mime: "application/vnd.oasis.opendocument.text", exts: ["odt"], label: "OpenDocument texte", magic: [[0x50, 0x4b, 0x03, 0x04]] },
  { mime: "text/csv", exts: ["csv"], label: "CSV" },
  { mime: "text/plain", exts: ["txt"], label: "Texte" },
];

export const ACCEPT_ATTR = ALLOWED_TYPES.map((r) => r.exts.map((e) => `.${e}`).join(",")).join(",");
export const ALLOWED_LABEL = ALLOWED_TYPES.map((r) => r.label).join(", ");

export type UploadCheck = { ok: true; mime: string } | { ok: false; error: string };

export function checkUpload(input: { name: string; type: string; size: number; head: Uint8Array }): UploadCheck {
  if (!input.size) return { ok: false, error: "Le fichier est vide." };
  if (input.size > MAX_UPLOAD_BYTES) return { ok: false, error: "Le fichier dépasse 20 Mo." };
  const ext = (input.name.split(".").pop() ?? "").toLowerCase();
  const rule = ALLOWED_TYPES.find((r) => r.exts.includes(ext));
  if (!rule) return { ok: false, error: `Format non accepté. Formats autorisés : ${ALLOWED_LABEL}.` };
  // Le navigateur peut envoyer un type vide ou générique : on se fie alors à l'extension + signature.
  const declared = (input.type || "").toLowerCase();
  const generic = !declared || declared === "application/octet-stream" || (rule.mime === "text/csv" && declared.startsWith("application/vnd.ms-excel"));
  if (!generic && declared !== rule.mime) return { ok: false, error: "Le type du fichier ne correspond pas à son extension." };
  if (rule.magic) {
    const match = rule.magic.some((sig) => sig.every((b, i) => input.head[i] === b));
    if (!match) return { ok: false, error: "Le contenu du fichier ne correspond pas à son format déclaré." };
  } else {
    // Textes : refuser les contenus binaires (octet nul dans l'en-tête).
    if (input.head.some((b) => b === 0)) return { ok: false, error: "Le fichier texte contient des données binaires." };
  }
  return { ok: true, mime: rule.mime };
}
