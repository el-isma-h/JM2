import "server-only";
import type { schema } from "@/db";
import { formatCents } from "@/lib/money";
import { fmtDate } from "@/lib/dates";
import { clean, INK, LINE, MUTED, newPdf, para, section, writeFooter, writeOrgHeader, type Org } from "./pdf-base";
import { computeTotals, vatRateLabel, type QuoteLine } from "./quote-math";

type Quote = typeof schema.quotes.$inferSelect;

export type QuoteRecipient = { name: string; lines: string[] };

/** PDF du devis : identité de l'organisme, destinataire, lignes, totaux par taux de TVA, signataire. */
export async function renderQuotePdf(org: Org, quote: Quote, recipient: QuoteRecipient): Promise<Buffer> {
  const { doc, done } = newPdf(`Devis ${quote.number}`);
  writeOrgHeader(doc, org, `Devis ${quote.number}`);

  const left = doc.page.margins.left;
  const right = doc.page.width - doc.page.margins.right;
  const width = right - left;
  const top = doc.y;

  doc.font("Helvetica-Bold").fontSize(9).fillColor(MUTED).text("DESTINATAIRE", left, top, { characterSpacing: 1 });
  doc.font("Helvetica-Bold").fontSize(10).fillColor(INK).text(clean(recipient.name), left, doc.y + 2, { width: width * 0.55 });
  doc.font("Helvetica").fontSize(9);
  for (const l of recipient.lines) doc.text(clean(l), { width: width * 0.55 });
  const afterRecipient = doc.y;

  doc.font("Helvetica").fontSize(9).fillColor(MUTED);
  const metaX = left + width * 0.62;
  doc.text(`Date d'émission : ${fmtDate(quote.issueDate)}`, metaX, top + 14, { width: width * 0.38 });
  if (quote.validUntil) doc.text(`Valable jusqu'au : ${fmtDate(quote.validUntil)}`, metaX, doc.y, { width: width * 0.38 });
  doc.fillColor(INK);
  doc.y = Math.max(afterRecipient, doc.y) + 14;
  doc.x = left;

  doc.font("Helvetica-Bold").fontSize(12).text(clean(quote.title), left, doc.y, { width });
  doc.moveDown(0.8);

  // Tableau des lignes
  const lines = (Array.isArray(quote.lines) ? quote.lines : []) as QuoteLine[];
  const cols = { label: width * 0.5, qty: width * 0.1, unit: width * 0.16, vat: width * 0.09, total: width * 0.15 };
  const header = () => {
    const y = doc.y;
    doc.font("Helvetica-Bold").fontSize(8.5).fillColor(MUTED);
    doc.text("Désignation", left, y, { width: cols.label });
    doc.text("Qté", left + cols.label, y, { width: cols.qty, align: "right" });
    doc.text("P.U. HT", left + cols.label + cols.qty, y, { width: cols.unit, align: "right" });
    doc.text("TVA", left + cols.label + cols.qty + cols.unit, y, { width: cols.vat, align: "right" });
    doc.text("Total HT", left + cols.label + cols.qty + cols.unit + cols.vat, y, { width: cols.total, align: "right" });
    doc.moveTo(left, doc.y + 3).lineTo(right, doc.y + 3).strokeColor(LINE).lineWidth(0.5).stroke();
    doc.y += 8;
    doc.fillColor(INK).font("Helvetica").fontSize(9.5);
  };
  header();
  for (const l of lines) {
    if (doc.y > doc.page.height - doc.page.margins.bottom - 90) {
      doc.addPage();
      header();
    }
    const y = doc.y;
    doc.font("Helvetica").fontSize(9.5).fillColor(INK).text(clean(l.label), left, y, { width: cols.label - 8 });
    if (l.description) doc.font("Helvetica").fontSize(8).fillColor(MUTED).text(clean(l.description), left, doc.y, { width: cols.label - 8 });
    const endY = doc.y;
    doc.font("Helvetica").fontSize(9.5).fillColor(INK);
    doc.text(l.qty.toLocaleString("fr-FR"), left + cols.label, y, { width: cols.qty, align: "right" });
    doc.text(clean(formatCents(l.unitCents)), left + cols.label + cols.qty, y, { width: cols.unit, align: "right" });
    doc.text(clean(vatRateLabel(l.vatRateBp)), left + cols.label + cols.qty + cols.unit, y, { width: cols.vat, align: "right" });
    doc.text(clean(formatCents(Math.round(l.qty * l.unitCents))), left + cols.label + cols.qty + cols.unit + cols.vat, y, { width: cols.total, align: "right" });
    doc.y = endY + 6;
    doc.moveTo(left, doc.y).lineTo(right, doc.y).strokeColor(LINE).lineWidth(0.3).stroke();
    doc.y += 6;
  }

  // Totaux
  const totals = computeTotals(lines);
  doc.moveDown(0.5);
  const totalsX = left + width * 0.55;
  const tw = width * 0.45;
  const row = (label: string, value: string, bold = false) => {
    const y = doc.y;
    doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(bold ? 10.5 : 9.5).fillColor(INK);
    doc.text(clean(label), totalsX, y, { width: tw * 0.6 });
    doc.text(clean(value), totalsX + tw * 0.6, y, { width: tw * 0.4, align: "right" });
    doc.y = y + (bold ? 16 : 14);
  };
  row("Total HT", formatCents(totals.totalHtCents));
  for (const r of totals.byRate) if (r.rateBp > 0) row(`TVA ${vatRateLabel(r.rateBp)} sur ${formatCents(r.baseCents)}`, formatCents(r.vatCents));
  if (totals.byRate.some((r) => r.rateBp === 0)) row("Exonération de TVA (formation professionnelle, art. 261-4-4° CGI)", formatCents(0));
  doc.moveTo(totalsX, doc.y).lineTo(right, doc.y).strokeColor(INK).lineWidth(0.6).stroke();
  doc.y += 6;
  row("Total TTC", formatCents(totals.totalTtcCents), true);
  doc.x = left;

  if (quote.notes) {
    section(doc, "Conditions et remarques");
    para(doc, quote.notes, "");
  }

  section(doc, "Acceptation");
  para(doc, "Bon pour accord (date, nom, qualité et signature du client) :", "");
  doc.moveDown(2.5);
  doc.font("Helvetica").fontSize(9).fillColor(MUTED).text(clean(`Pour ${org.tradeName ?? org.legalName} : ${org.signatoryName ?? "[À COMPLÉTER : signataire]"}${org.signatoryTitle ? `, ${org.signatoryTitle}` : ""}`));
  doc.fillColor(INK);

  writeFooter(doc, org, `Devis ${quote.number}`);
  doc.end();
  return done;
}
