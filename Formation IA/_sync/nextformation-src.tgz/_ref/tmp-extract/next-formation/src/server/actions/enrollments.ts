"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { and, eq, inArray, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { sha256 } from "@/lib/crypto";
import { appUrl } from "@/lib/env";
import { isEmail, parseDateInput } from "@/lib/validators";
import { issueToken } from "@/server/auth";
import { assertEnrollmentInScope, requireOrg, type OrgContext, type Permission } from "@/server/authz";
import { audit } from "@/server/audit";
import { createDocument } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { authErrorMessage } from "@/server/guard";
import { layoutMail, sendMail } from "@/server/mail";
import { resolveTaskByKey } from "@/server/tasks/service";
import { recordEvidence } from "@/server/quality/evidence";
import { sessionPlaces } from "@/server/sessions/service";
import { ACTIVE_ENROLLMENT_STATUSES, CLOSED_ENROLLMENT_STATUSES, canTransitionEnrollment, createEnrollment, logEnrollmentEvent, syncEnrollmentPieces, type ContractKind, type EnrollmentStatus } from "@/server/enrollments/service";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const CONTRACT_KINDS = schema.contractKindEnum.enumValues;

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

function str(fd: FormData, k: string) {
  return String(fd.get(k) ?? "").trim();
}

function dossierPath(orgId: string, enrollmentId: string) {
  return `/app/${orgId}/inscriptions/${enrollmentId}`;
}

async function loadEnrollment(ctx: OrgContext, enrollmentId: string) {
  const [e] = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, ctx.org.id))).limit(1);
  if (!e) throw new Error("Inscription introuvable dans cet organisme.");
  await assertEnrollmentInScope(ctx, e.id);
  return e;
}

function revalidateDossier(orgId: string, enrollmentId: string, sessionId?: string) {
  revalidatePath(dossierPath(orgId, enrollmentId));
  revalidatePath(`/app/${orgId}/inscriptions`);
  if (sessionId) revalidatePath(`/app/${orgId}/sessions/${sessionId}`);
}

// ---------------------------------------------------------------------------
// Création : réutilise une personne existante, ou la crée seulement si absente
// ---------------------------------------------------------------------------

const newPersonSchema = z.object({
  firstName: z.string().trim().min(1, "Prénom requis").max(80),
  lastName: z.string().trim().min(1, "Nom requis").max(80),
  email: z.string().trim().toLowerCase().max(160).optional().or(z.literal("")),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  civility: z.enum(["M", "Mme", "autre"]).optional().or(z.literal("")),
});

export async function createEnrollmentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const sessionId = uuid.parse(formData.get("sessionId") || "");
    let personId = str(formData, "personId");
    if (!personId) {
      const p = newPersonSchema.parse(Object.fromEntries(formData));
      if (p.email && !isEmail(p.email)) return { error: "Adresse e-mail invalide." };
      const birthDate = parseDateInput(str(formData, "birthDate"));
      if (str(formData, "birthDate") && !birthDate) return { error: "Date de naissance invalide (JJ/MM/AAAA)." };
      // Réutilisation : même e-mail, ou même nom + date de naissance → on refuse de créer un doublon.
      const conds = [];
      if (p.email) conds.push(sql`lower(${schema.persons.email}) = ${p.email}`);
      if (birthDate) conds.push(sql`lower(${schema.persons.lastName}) = ${p.lastName.toLowerCase()} and lower(${schema.persons.firstName}) = ${p.firstName.toLowerCase()} and ${schema.persons.birthDate} = ${birthDate}`);
      if (conds.length) {
        const [existing] = await db.select({ id: schema.persons.id, firstName: schema.persons.firstName, lastName: schema.persons.lastName }).from(schema.persons).where(and(eq(schema.persons.orgId, orgId), sql`(${sql.join(conds, sql` or `)})`)).limit(1);
        if (existing) return { error: `${existing.firstName} ${existing.lastName} existe déjà dans cet organisme : sélectionnez cette personne au lieu d'en créer une nouvelle.`, data: { existingPersonId: existing.id } };
      }
      const [created] = await db
        .insert(schema.persons)
        .values({ orgId, firstName: p.firstName, lastName: p.lastName, email: p.email || null, phone: p.phone || null, civility: p.civility || null, birthDate, status: "candidat", source: "inscription", isDemo: ctx.org.isDemo })
        .returning({ id: schema.persons.id });
      personId = created.id;
      await audit({ action: "person.create", userId: ctx.user.id, orgId, entityType: "person", entityId: personId, after: { firstName: p.firstName, lastName: p.lastName, source: "inscription" } });
    }
    const contractKind = z.enum(CONTRACT_KINDS).parse(formData.get("contractKind") || "convention_formation") as ContractKind;
    const hoursRaw = str(formData, "hoursPlanned");
    const hoursPlanned = hoursRaw ? z.coerce.number().int().min(0, "Heures prévues invalides").max(10000).parse(hoursRaw) : null;
    const startDate = str(formData, "startDate") ? parseDateInput(str(formData, "startDate")) : null;
    const endDate = str(formData, "endDate") ? parseDateInput(str(formData, "endDate")) : null;
    if (str(formData, "startDate") && !startDate) return { error: "Date de début invalide (JJ/MM/AAAA)." };
    if (str(formData, "endDate") && !endDate) return { error: "Date de fin invalide (JJ/MM/AAAA)." };
    const r = await createEnrollment(ctx, {
      personId,
      sessionId,
      groupId: str(formData, "groupId") || null,
      companyId: str(formData, "companyId") || null,
      tutorContactId: str(formData, "tutorContactId") || null,
      contractKind,
      contractNumber: str(formData, "contractNumber") || null,
      startDate,
      endDate,
      hoursPlanned,
      placementId: str(formData, "placementId") || null,
      quoteId: str(formData, "quoteId") || null,
      status: formData.get("status") === "inscrit" ? "inscrit" : "preinscrit",
    });
    await audit({ action: "enrollment.create", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: r.enrollment.id, after: { reference: r.enrollment.reference, personId, sessionId, contractKind, pieces: r.piecesCreated } });
    revalidateDossier(orgId, r.enrollment.id, sessionId);
    revalidatePath(`/app/${orgId}/apprenants`);
    return { ok: true, message: `Inscription ${r.enrollment.reference} créée (${r.piecesCreated} pièce(s) attendue(s)).`, data: { redirect: dossierPath(orgId, r.enrollment.id) } };
  } catch (e) {
    return fail(e, "Inscription impossible.");
  }
}

// ---------------------------------------------------------------------------
// Statuts, rattachements, sortie, clôture, réouverture (tout est journalisé)
// ---------------------------------------------------------------------------

export async function transitionEnrollmentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const to = z.enum(schema.enrollmentStatusEnum.enumValues).parse(formData.get("to")) as EnrollmentStatus;
    const reason = str(formData, "reason");
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const e = await loadEnrollment(ctx, enrollmentId);
    const check = canTransitionEnrollment(e.status, to, { reason });
    if (!check.ok) return { error: check.reason };
    if ((to === "inscrit" || to === "en_cours") && e.status === "preinscrit") {
      const p = await sessionPlaces(e.sessionId);
      if (p.capacity && p.enrolled > p.capacity) return { error: "La session est en surcapacité : libérez une place avant de confirmer." };
    }
    const exit = ["abandon", "annule", "reporte"].includes(to);
    await db
      .update(schema.enrollments)
      .set({ status: to, exitDate: exit ? (parseDateInput(str(formData, "exitDate")) ?? e.exitDate) : e.exitDate, exitReason: exit ? reason : e.exitReason, closedAt: to === "termine" || to === "abandon" || to === "annule" ? new Date() : null, closedBy: to === "termine" || to === "abandon" || to === "annule" ? ctx.user.id : null })
      .where(eq(schema.enrollments.id, e.id));
    await logEnrollmentEvent(e.id, "statut", { from: e.status, to, reason: reason || null, userId: ctx.user.id });
    await audit({ action: "enrollment.transition", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { status: e.status }, after: { status: to, reason: reason || null } });
    if (to === "inscrit") await recordEvidence({ orgId, indicatorCode: "IND_4", level: "individuel", title: `Inscription confirmée ${e.reference}`, sourceType: "enrollment", sourceId: e.id }).catch(() => null);
    revalidateDossier(orgId, e.id, e.sessionId);
    return { ok: true, message: `Statut d'inscription enregistré : ${to}. Le financement (${e.fundingState}) reste inchangé.` };
  } catch (e) {
    return fail(e, "Changement de statut impossible.");
  }
}

/** Changement de groupe ou de session : même organisme, capacité vérifiée, journalisé ; heures et pièces restent sur l'inscription. */
export async function moveEnrollmentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const reason = str(formData, "reason");
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const e = await loadEnrollment(ctx, enrollmentId);
    if (CLOSED_ENROLLMENT_STATUSES.includes(e.status)) return { error: "Dossier clos : rouvrez-le avant de le déplacer." };
    if (!reason) return { error: "Indiquez le motif du changement : il est conservé dans le journal." };
    const targetSessionId = str(formData, "sessionId") || e.sessionId;
    const targetGroupId = str(formData, "groupId") || null;
    const [target] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, targetSessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
    if (!target) return { error: "Session cible introuvable dans cet organisme." };
    if (target.status === "terminee" || target.status === "annulee") return { error: "La session cible est close." };
    if (targetSessionId !== e.sessionId) {
      const [cur] = await db.select({ programVersionId: schema.trainingSessions.programVersionId }).from(schema.trainingSessions).where(eq(schema.trainingSessions.id, e.sessionId)).limit(1);
      const [pvCur] = await db.select({ programId: schema.programVersions.programId }).from(schema.programVersions).where(eq(schema.programVersions.id, cur!.programVersionId)).limit(1);
      const [pvTgt] = await db.select({ programId: schema.programVersions.programId }).from(schema.programVersions).where(eq(schema.programVersions.id, target.programVersionId)).limit(1);
      if (pvCur?.programId !== pvTgt?.programId && formData.get("allowOtherProgram") !== "on") return { error: "La session cible concerne une autre formation : cochez la confirmation pour autoriser ce transfert (la version de programme figée reste celle du dossier)." };
      const p = await sessionPlaces(target.id);
      if (p.remaining <= 0) return { error: `Session cible complète (${p.enrolled}/${p.capacity}).` };
      const [dup] = await db.select({ id: schema.enrollments.id }).from(schema.enrollments).where(and(eq(schema.enrollments.personId, e.personId), eq(schema.enrollments.sessionId, target.id), inArray(schema.enrollments.status, ACTIVE_ENROLLMENT_STATUSES))).limit(1);
      if (dup) return { error: "Cette personne a déjà une inscription active sur la session cible." };
    }
    if (targetGroupId) {
      const [g] = await db.select().from(schema.groups).where(and(eq(schema.groups.id, targetGroupId), eq(schema.groups.sessionId, target.id), eq(schema.groups.orgId, orgId))).limit(1);
      if (!g) return { error: "Groupe introuvable sur la session cible." };
      if (g.capacity) {
        const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.enrollments).where(and(eq(schema.enrollments.groupId, g.id), inArray(schema.enrollments.status, ACTIVE_ENROLLMENT_STATUSES), sql`${schema.enrollments.id} <> ${e.id}`));
        if (n >= g.capacity) return { error: `Groupe « ${g.name} » complet (${n}/${g.capacity}).` };
      }
    }
    if (targetSessionId === e.sessionId && targetGroupId === e.groupId) return { error: "Aucun changement : même session et même groupe." };
    await db.update(schema.enrollments).set({ sessionId: target.id, groupId: targetGroupId }).where(eq(schema.enrollments.id, e.id));
    if (targetSessionId !== e.sessionId) await logEnrollmentEvent(e.id, "session", { from: e.sessionId, to: target.id, reason, userId: ctx.user.id });
    if (targetGroupId !== e.groupId) await logEnrollmentEvent(e.id, "groupe", { from: e.groupId, to: targetGroupId, reason, userId: ctx.user.id });
    await audit({ action: "enrollment.move", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { sessionId: e.sessionId, groupId: e.groupId }, after: { sessionId: target.id, groupId: targetGroupId, reason } });
    revalidateDossier(orgId, e.id, e.sessionId);
    revalidatePath(`/app/${orgId}/sessions/${target.id}`);
    return { ok: true, message: "Rattachement modifié. Les heures et les pièces restent liées à cette inscription." };
  } catch (e) {
    return fail(e, "Changement impossible.");
  }
}

export async function earlyExitAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const e = await loadEnrollment(ctx, enrollmentId);
    const exitDate = parseDateInput(str(formData, "exitDate"));
    const reason = str(formData, "reason");
    if (!exitDate) return { error: "Date de sortie invalide (JJ/MM/AAAA)." };
    if (!reason) return { error: "Le motif de sortie anticipée est obligatoire." };
    if (e.startDate && exitDate < e.startDate) return { error: "La date de sortie précède le début du parcours." };
    const to: EnrollmentStatus = formData.get("to") === "termine" ? "termine" : "abandon";
    const check = canTransitionEnrollment(e.status, to, { reason });
    if (!check.ok) return { error: check.reason };
    await db.update(schema.enrollments).set({ status: to, exitDate, exitReason: reason, endDate: exitDate, closedAt: new Date(), closedBy: ctx.user.id }).where(eq(schema.enrollments.id, e.id));
    await logEnrollmentEvent(e.id, "sortie_anticipee", { from: e.status, to, reason: `${reason} (sortie le ${exitDate})`, userId: ctx.user.id });
    await audit({ action: "enrollment.early_exit", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { status: e.status, endDate: e.endDate }, after: { status: to, exitDate, reason } });
    revalidateDossier(orgId, e.id, e.sessionId);
    return { ok: true, message: `Sortie anticipée enregistrée au ${exitDate}. Le financement reste à traiter séparément.` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Clôture pédagogique : progression finale et statut terminé. Ne touche jamais `fundingState`. */
export async function closePedagogyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const progression = z.enum(["acquise", "partielle", "non_acquise"]).parse(formData.get("progression"));
    const note = str(formData, "note");
    const ctx = await requireOrg(orgId, "dossier.pedagogy.manage");
    const e = await loadEnrollment(ctx, enrollmentId);
    if (e.status !== "en_cours") return { error: `La clôture pédagogique s'applique à un dossier en cours (statut actuel : ${e.status}).` };
    await db.update(schema.enrollments).set({ status: "termine", progression, closedAt: new Date(), closedBy: ctx.user.id }).where(eq(schema.enrollments.id, e.id));
    await logEnrollmentEvent(e.id, "cloture_pedagogique", { from: e.progression, to: progression, reason: note || null, userId: ctx.user.id });
    await audit({ action: "enrollment.close_pedagogy", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { status: e.status, progression: e.progression, fundingState: e.fundingState }, after: { status: "termine", progression, fundingState: e.fundingState } });
    revalidateDossier(orgId, e.id, e.sessionId);
    return { ok: true, message: `Clôture pédagogique enregistrée (${progression}). Le dossier financier (${e.fundingState}) n'est pas soldé par cette action.` };
  } catch (e) {
    return fail(e, "Clôture impossible.");
  }
}

export async function reopenEnrollmentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const reason = str(formData, "reason");
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const e = await loadEnrollment(ctx, enrollmentId);
    if (!CLOSED_ENROLLMENT_STATUSES.includes(e.status)) return { error: "Ce dossier n'est pas clos." };
    if (!reason) return { error: "Le motif de réouverture est obligatoire (traçabilité)." };
    const to: EnrollmentStatus = e.status === "annule" ? "preinscrit" : "en_cours";
    await db.update(schema.enrollments).set({ status: to, closedAt: null, closedBy: null, exitDate: null, exitReason: null }).where(eq(schema.enrollments.id, e.id));
    await logEnrollmentEvent(e.id, "reouverture", { from: e.status, to, reason, userId: ctx.user.id });
    await audit({ action: "enrollment.reopen", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { status: e.status, exitDate: e.exitDate }, after: { status: to, reason } });
    revalidateDossier(orgId, e.id, e.sessionId);
    return { ok: true, message: `Dossier rouvert (statut : ${to}). La réouverture est tracée dans le journal.` };
  } catch (e) {
    return fail(e, "Réouverture impossible.");
  }
}

const detailsSchema = z.object({
  contractKind: z.enum(CONTRACT_KINDS),
  contractNumber: z.string().trim().max(80).optional().or(z.literal("")),
  hoursPlanned: z.coerce.number().int().min(0, "Heures prévues invalides").max(10000),
  companyId: z.string().uuid().optional().or(z.literal("")),
  tutorContactId: z.string().uuid().optional().or(z.literal("")),
  legacyHours: z.coerce.number().int().min(0).max(100000).default(0),
  legacyHoursNote: z.string().trim().max(500).optional().or(z.literal("")),
  commercialStatus: z.enum(schema.commercialStatusEnum.enumValues),
});

export async function updateEnrollmentDetailsAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const e = await loadEnrollment(ctx, enrollmentId);
    const d = detailsSchema.parse(Object.fromEntries(formData));
    const startDate = parseDateInput(str(formData, "startDate"));
    const endDate = parseDateInput(str(formData, "endDate"));
    if (!startDate || !endDate) return { error: "Dates du parcours invalides (JJ/MM/AAAA)." };
    if (endDate < startDate) return { error: "La date de fin précède la date de début." };
    if (d.companyId) {
      const [c] = await db.select({ id: schema.companies.id }).from(schema.companies).where(and(eq(schema.companies.id, d.companyId), eq(schema.companies.orgId, orgId))).limit(1);
      if (!c) return { error: "Entreprise introuvable." };
    }
    if (d.tutorContactId) {
      const [t] = await db.select({ companyId: schema.contacts.companyId }).from(schema.contacts).where(and(eq(schema.contacts.id, d.tutorContactId), eq(schema.contacts.orgId, orgId))).limit(1);
      if (!t) return { error: "Tuteur introuvable." };
      if (d.companyId && t.companyId !== d.companyId) return { error: "Le tuteur doit appartenir à l'entreprise choisie." };
    }
    const values = {
      contractKind: d.contractKind,
      contractNumber: d.contractNumber || null,
      hoursPlanned: d.hoursPlanned,
      companyId: d.companyId || null,
      tutorContactId: d.tutorContactId || null,
      startDate,
      endDate,
      legacyHours: d.legacyHours,
      legacyHoursNote: d.legacyHoursNote || null,
      commercialStatus: d.commercialStatus,
    };
    await db.update(schema.enrollments).set(values).where(eq(schema.enrollments.id, e.id));
    const changes: string[] = [];
    if (e.contractKind !== d.contractKind) changes.push(`contrat : ${e.contractKind} → ${d.contractKind}`);
    if (e.hoursPlanned !== d.hoursPlanned) changes.push(`heures prévues : ${e.hoursPlanned} → ${d.hoursPlanned}`);
    if (e.companyId !== values.companyId) changes.push("entreprise modifiée");
    if (e.legacyHours !== d.legacyHours) changes.push(`solde historique : ${e.legacyHours} → ${d.legacyHours} h`);
    if (changes.length) await logEnrollmentEvent(e.id, "modification", { reason: changes.join(" ; "), userId: ctx.user.id });
    let added = 0;
    if (e.contractKind !== d.contractKind) added = (await syncEnrollmentPieces(orgId, e.id, ctx.user.id)).added;
    await audit({ action: "enrollment.update", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { contractKind: e.contractKind, hoursPlanned: e.hoursPlanned, companyId: e.companyId, legacyHours: e.legacyHours }, after: values });
    revalidateDossier(orgId, e.id, e.sessionId);
    return { ok: true, message: added ? `Dossier enregistré : ${added} pièce(s) attendue(s) ajoutée(s) suite au changement de contrat.` : "Dossier enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

// ---------------------------------------------------------------------------
// Notes par section (droits distincts) et parcours (plan individuel, positionnement)
// ---------------------------------------------------------------------------

const SECTION_PERM: Record<string, Permission | null> = { commentaire: null, interne: "dossier.internal.view", pedagogique: "dossier.pedagogy.view", administratif: "dossier.admin_docs.view" };

export async function addNoteAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const section = z.enum(schema.noteSectionEnum.enumValues).parse(formData.get("section"));
    const body = z.string().trim().min(1, "Note vide").max(5000).parse(formData.get("body"));
    const ctx = await requireOrg(orgId, "org.view");
    if (!ctx.permissions.has("enrollments.view") && !(ctx.trainerOnly && ctx.permissions.has("dossier.pedagogy.view"))) return { error: "Vous n'avez pas accès à ce dossier." };
    const perm = SECTION_PERM[section];
    if (perm && !ctx.permissions.has(perm)) return { error: "Vous n'avez pas accès à cette section du dossier." };
    if (ctx.trainerOnly && section !== "pedagogique" && section !== "commentaire") return { error: "Un formateur ne peut écrire que dans les sections pédagogique et commentaires." };
    const e = await loadEnrollment(ctx, enrollmentId);
    const [n] = await db.insert(schema.dossierNotes).values({ orgId, enrollmentId: e.id, personId: e.personId, section, body, authorId: ctx.user.id, pinned: formData.get("pinned") === "on" }).returning({ id: schema.dossierNotes.id });
    await audit({ action: "enrollment.note.add", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, after: { noteId: n.id, section } });
    revalidateDossier(orgId, e.id);
    return { ok: true, message: "Note enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

const PLAN_FIELDS = ["objectifs", "prerequis_verifies", "niveau_entree", "besoins_specifiques", "modalites_adaptees", "observations"] as const;
const POSITIONING_FIELDS = ["date", "methode", "resultat", "niveau", "preconisations"] as const;

export async function savePlanAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const ctx = await requireOrg(orgId, "dossier.pedagogy.manage");
    const e = await loadEnrollment(ctx, enrollmentId);
    const individualPlan: Record<string, string> = {};
    for (const k of PLAN_FIELDS) {
      const v = str(formData, `plan_${k}`).slice(0, 4000);
      if (v) individualPlan[k] = v;
    }
    const positioning: Record<string, string> = {};
    for (const k of POSITIONING_FIELDS) {
      const v = str(formData, `pos_${k}`).slice(0, 4000);
      if (v) positioning[k] = v;
    }
    if (positioning.date && !parseDateInput(positioning.date)) return { error: "Date de positionnement invalide (JJ/MM/AAAA)." };
    if (positioning.date) positioning.date = parseDateInput(positioning.date)!;
    const progression = z.enum(schema.progressionEnum.enumValues).optional().or(z.literal("")).parse(formData.get("progression") ?? "");
    await db.update(schema.enrollments).set({ individualPlan, positioning, ...(progression ? { progression } : {}) }).where(eq(schema.enrollments.id, e.id));
    if (progression && progression !== e.progression) await logEnrollmentEvent(e.id, "progression", { from: e.progression, to: progression, userId: ctx.user.id });
    await audit({ action: "enrollment.plan.update", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, before: { individualPlan: e.individualPlan, positioning: e.positioning }, after: { individualPlan, positioning, progression: progression || e.progression } });
    revalidateDossier(orgId, e.id);
    return { ok: true, message: "Parcours enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

// ---------------------------------------------------------------------------
// Pièces administratives : dépôt, acceptation, refus motivé, non applicable (versions, tâches résolues)
// ---------------------------------------------------------------------------

async function loadSubmission(ctx: OrgContext, submissionId: string) {
  const [row] = await db
    .select({ s: schema.pieceSubmissions, p: schema.requiredPieces })
    .from(schema.pieceSubmissions)
    .innerJoin(schema.requiredPieces, eq(schema.requiredPieces.id, schema.pieceSubmissions.requiredPieceId))
    .where(and(eq(schema.pieceSubmissions.id, submissionId), eq(schema.pieceSubmissions.orgId, ctx.org.id)))
    .limit(1);
  if (!row) throw new Error("Pièce introuvable.");
  const e = await loadEnrollment(ctx, row.s.enrollmentId);
  return { ...row, e };
}

export async function uploadPieceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const submissionId = uuid.parse(formData.get("submissionId"));
    const ctx = await requireOrg(orgId, "dossier.admin_docs.manage");
    const { s, p, e } = await loadSubmission(ctx, submissionId);
    const file = formData.get("file");
    if (!(file instanceof File) || !file.size) return { error: "Choisissez un fichier à déposer." };
    const buf = Buffer.from(await file.arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head: buf.subarray(0, 8) });
    if (!check.ok) return { error: check.error };
    const doc = await createDocument({
      orgId,
      enrollmentId: e.id,
      personId: e.personId,
      sessionId: e.sessionId,
      companyId: e.companyId,
      category: p.category,
      visibility: "administratif",
      status: "transmis",
      title: `${p.label} · ${e.reference}`,
      fileName: file.name,
      mimeType: check.mime,
      data: buf,
      sourceType: "piece_submission",
      sourceId: s.id,
      uploadedBy: ctx.user.id,
      previousVersionId: s.documentId,
      isDemo: ctx.org.isDemo,
    });
    const version = s.documentId ? s.version + 1 : s.version;
    await db.update(schema.pieceSubmissions).set({ documentId: doc.id, status: "deposee", submittedAt: new Date(), submittedBy: ctx.user.id, version, refusalReason: null, reviewedAt: null, reviewedBy: null }).where(eq(schema.pieceSubmissions.id, s.id));
    await logEnrollmentEvent(e.id, "piece", { from: s.status, to: "deposee", reason: `${p.label} (version ${version})`, userId: ctx.user.id });
    await audit({ action: "piece.upload", userId: ctx.user.id, orgId, entityType: "piece_submission", entityId: s.id, before: { status: s.status, version: s.version }, after: { status: "deposee", version, documentId: doc.id } });
    revalidateDossier(orgId, e.id);
    revalidatePath(`/app/${orgId}/pieces`);
    return { ok: true, message: `${p.label} déposée (version ${version}). Elle reste à contrôler.` };
  } catch (e) {
    return fail(e, "Dépôt impossible.");
  }
}

export async function reviewPieceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const submissionId = uuid.parse(formData.get("submissionId"));
    const decision = z.enum(["acceptee", "refusee", "non_applicable", "attendue"]).parse(formData.get("decision"));
    const reason = str(formData, "reason");
    const ctx = await requireOrg(orgId, "dossier.admin_docs.manage");
    const { s, p, e } = await loadSubmission(ctx, submissionId);
    if (decision === "acceptee" && s.status !== "deposee") return { error: "Seule une pièce déposée peut être acceptée." };
    if (decision === "refusee" && !reason) return { error: "Le refus doit être motivé." };
    if (decision === "non_applicable" && !reason) return { error: "Indiquez pourquoi cette pièce n'est pas applicable à ce dossier." };
    if (decision === "refusee" && s.status !== "deposee") return { error: "Seule une pièce déposée peut être refusée." };
    await db
      .update(schema.pieceSubmissions)
      .set({ status: decision, reviewedAt: decision === "attendue" ? null : new Date(), reviewedBy: decision === "attendue" ? null : ctx.user.id, refusalReason: decision === "refusee" ? reason : null, naReason: decision === "non_applicable" ? reason : null })
      .where(eq(schema.pieceSubmissions.id, s.id));
    if (s.documentId && decision === "acceptee") await db.update(schema.documents).set({ status: "valide", validatedAt: new Date(), validatedBy: ctx.user.id }).where(eq(schema.documents.id, s.documentId));
    if (s.documentId && decision === "refusee") await db.update(schema.documents).set({ status: "invalide" }).where(eq(schema.documents.id, s.documentId));
    const key = `piece:${e.id}:${p.code}`;
    if (decision === "attendue" && p.isRequired) {
      // La cause réapparaît : la tâche de relais (même clé) est rouverte, jamais dupliquée.
      const [t] = await db.select({ id: schema.tasks.id, status: schema.tasks.status }).from(schema.tasks).where(and(eq(schema.tasks.orgId, orgId), eq(schema.tasks.idempotencyKey, key))).limit(1);
      if (t && t.status === "terminee") {
        await db.update(schema.tasks).set({ status: "a_faire", completedAt: null, completedBy: null, resolutionNote: null }).where(eq(schema.tasks.id, t.id));
        await db.insert(schema.taskEvents).values({ taskId: t.id, kind: "statut", fromValue: "terminee", toValue: "a_faire", note: "Pièce remise en attente", userId: ctx.user.id });
      }
    }
    if (decision !== "attendue") {
      // Tâches « pièce à contrôler » créées au dépôt extranet (clé piece_controle:<submissionId>:v<n>) : la décision les résout.
      const controls = await db.select({ key: schema.tasks.idempotencyKey }).from(schema.tasks).where(and(eq(schema.tasks.orgId, orgId), sql`${schema.tasks.idempotencyKey} like ${`piece_controle:${s.id}:%`}`));
      for (const c of controls) if (c.key) await resolveTaskByKey(orgId, c.key, `Pièce contrôlée : ${decision}`, ctx.user.id);
    }
    if (decision === "acceptee" || decision === "non_applicable") {
      await resolveTaskByKey(orgId, key, decision === "acceptee" ? `Pièce acceptée (${p.label})` : `Pièce non applicable : ${reason}`, ctx.user.id);
      if (decision === "acceptee" && p.category === "convention") await recordEvidence({ orgId, indicatorCode: "IND_1", level: "individuel", title: `Convention signée acceptée ${e.reference}`, sourceType: "piece_submission", sourceId: s.id }).catch(() => null);
    }
    await logEnrollmentEvent(e.id, "piece", { from: s.status, to: decision, reason: `${p.label}${reason ? ` : ${reason}` : ""}`, userId: ctx.user.id });
    await audit({ action: `piece.${decision}`, userId: ctx.user.id, orgId, entityType: "piece_submission", entityId: s.id, before: { status: s.status }, after: { status: decision, reason: reason || null } });
    revalidateDossier(orgId, e.id);
    revalidatePath(`/app/${orgId}/pieces`);
    revalidatePath(`/app/${orgId}/taches`);
    return { ok: true, message: { acceptee: "Pièce acceptée : la tâche de relais est résolue.", refusee: "Pièce refusée : l'apprenant devra la redéposer.", non_applicable: "Pièce marquée non applicable (motif conservé).", attendue: "Pièce remise en attente." }[decision] };
  } catch (e) {
    return fail(e, "Décision impossible.");
  }
}

export async function resyncPiecesAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const ctx = await requireOrg(orgId, "dossier.admin_docs.manage");
    const e = await loadEnrollment(ctx, enrollmentId);
    const r = await syncEnrollmentPieces(orgId, e.id, ctx.user.id);
    await audit({ action: "piece.resync", userId: ctx.user.id, orgId, entityType: "enrollment", entityId: e.id, after: r });
    revalidateDossier(orgId, e.id);
    return { ok: true, message: r.added ? `${r.added} pièce(s) attendue(s) ajoutée(s).` : "Aucune pièce supplémentaire : le dossier est à jour du paramétrage." };
  } catch (e) {
    return fail(e, "Recalcul impossible.");
  }
}

// ---------------------------------------------------------------------------
// Apprenants : invitation à l'espace apprenant, anonymisation RGPD (T04)
// ---------------------------------------------------------------------------

export async function inviteLearnerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const personId = uuid.parse(formData.get("personId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    const [p] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, personId), eq(schema.persons.orgId, orgId))).limit(1);
    if (!p) return { error: "Personne introuvable." };
    if (p.anonymizedAt) return { error: "Personne anonymisée : invitation impossible." };
    const email = (str(formData, "email") || p.email || "").toLowerCase();
    if (!email || !isEmail(email)) return { error: "Renseignez une adresse e-mail valide pour cette personne." };
    if (p.userId) return { error: "Cette personne dispose déjà d'un accès à l'espace apprenant." };
    const [pending] = await db.select({ id: schema.invitations.id }).from(schema.invitations).where(and(eq(schema.invitations.orgId, orgId), eq(schema.invitations.personId, p.id), eq(schema.invitations.status, "pending"), sql`${schema.invitations.expiresAt} > now()`)).limit(1);
    if (pending) await db.update(schema.invitations).set({ status: "revoked" }).where(eq(schema.invitations.id, pending.id));
    const invitationId = randomUUID();
    const token = await issueToken("invite", { email, payload: { invitationId }, ttlMinutes: 7 * 24 * 60 });
    await db.insert(schema.invitations).values({ id: invitationId, tenantId: ctx.tenant.id, orgId, email, roles: ["learner"], personId: p.id, invitedBy: ctx.user.id, tokenHash: sha256(token), expiresAt: new Date(Date.now() + 7 * 86400_000) });
    if (!p.email) await db.update(schema.persons).set({ email }).where(eq(schema.persons.id, p.id));
    const url = `${appUrl()}/invitation/${token}`;
    const orgName = ctx.org.tradeName ?? ctx.org.legalName;
    const res = await sendMail({
      to: email,
      subject: `Votre espace apprenant : ${orgName}`,
      html: layoutMail("Votre espace apprenant est prêt", `<p>Bonjour ${p.firstName},</p><p>${orgName} vous ouvre un accès à votre espace apprenant (planning, émargement, documents, livret). Ce lien est valable 7 jours.</p>`, { label: "Activer mon espace", url }),
      text: `Activez votre espace apprenant (valable 7 jours) : ${url}`,
      isDemo: ctx.org.isDemo,
    });
    await audit({ action: "person.invite_learner", userId: ctx.user.id, orgId, entityType: "person", entityId: p.id, after: { email, mail: res.status } });
    revalidatePath(`/app/${orgId}/apprenants/${p.id}`);
    return res.status === "sent"
      ? { ok: true, message: `Invitation envoyée à ${email}.` }
      : { ok: true, message: ctx.org.isDemo ? "Démonstration : aucun e-mail ne part. Lien d'activation à transmettre :" : "Service e-mail non configuré : transmettez ce lien d'activation (valable 7 jours).", data: { link: url } };
  } catch (e) {
    return fail(e, "Invitation impossible.");
  }
}

/** Anonymisation RGPD : remplace les données nominatives, conserve heures et documents financiers. Propriétaire ou direction. */
export async function anonymizePersonAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const personId = uuid.parse(formData.get("personId"));
    const ctx = await requireOrg(orgId, "enrollments.manage");
    if (!ctx.isOwner && !ctx.roles.includes("direction")) return { error: "L'anonymisation est réservée au propriétaire ou à la direction." };
    if (String(formData.get("confirm") ?? "").trim().toUpperCase() !== "ANONYMISER") return { error: "Saisissez ANONYMISER pour confirmer." };
    const [p] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, personId), eq(schema.persons.orgId, orgId))).limit(1);
    if (!p) return { error: "Personne introuvable." };
    if (p.anonymizedAt) return { error: "Personne déjà anonymisée." };
    const [active] = await db.select({ id: schema.enrollments.id }).from(schema.enrollments).where(and(eq(schema.enrollments.personId, p.id), inArray(schema.enrollments.status, ACTIVE_ENROLLMENT_STATUSES))).limit(1);
    if (active) return { error: "Cette personne a une inscription active : clôturez-la avant d'anonymiser." };
    const anonymized = {
      firstName: "Anonymisé",
      lastName: "Anonymisé",
      birthName: null,
      birthDate: null,
      birthPlace: null,
      nationality: null,
      email: null,
      phone: null,
      addressLine1: null,
      addressLine2: null,
      postalCode: null,
      city: null,
      identifiers: {},
      accommodations: null,
      hasAccommodations: false,
      confidentialNotes: null,
      cvDocumentId: null,
      tags: [],
      userId: null,
      status: "inactif" as const,
      anonymizedAt: new Date(),
    };
    await db.transaction(async (tx) => {
      await tx.update(schema.persons).set(anonymized).where(eq(schema.persons.id, p.id));
      // Notes nominatives supprimées ; heures (attendances, legacy) et documents financiers conservés.
      await tx.delete(schema.dossierNotes).where(and(eq(schema.dossierNotes.orgId, orgId), eq(schema.dossierNotes.personId, p.id)));
      await tx.update(schema.documents).set({ status: "archive" }).where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.personId, p.id), inArray(schema.documents.category, ["cv", "piece_identite", "justificatif", "diplome"])));
      if (p.userId) await tx.update(schema.memberships).set({ active: false }).where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, p.userId)));
    });
    await audit({ action: "person.anonymize", userId: ctx.user.id, orgId, entityType: "person", entityId: p.id, before: { hadEmail: Boolean(p.email), status: p.status }, after: { anonymizedAt: anonymized.anonymizedAt } });
    revalidatePath(`/app/${orgId}/apprenants/${p.id}`);
    revalidatePath(`/app/${orgId}/apprenants`);
    return { ok: true, message: "Personne anonymisée. Les heures et les documents financiers sont conservés ; les pièces personnelles sont archivées." };
  } catch (e) {
    return fail(e, "Anonymisation impossible.");
  }
}
