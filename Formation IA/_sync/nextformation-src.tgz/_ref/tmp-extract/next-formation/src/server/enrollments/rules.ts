/**
 * Règles pures du dossier d'inscription (F03, F04, F09) : pièces attendues applicables,
 * transitions de statut d'inscription, échéances des pièces. Testables sans serveur.
 */

export type EnrollmentStatus = "preinscrit" | "inscrit" | "en_cours" | "termine" | "abandon" | "annule" | "reporte";
export type ContractKind = "convention_formation" | "contrat_apprentissage" | "contrat_professionnalisation" | "contrat_particulier" | "cpf" | "stage" | "autre";

export type AppliesTo = { contractKinds?: string[]; fundingKinds?: string[]; activity?: string[] };

export type RequiredPieceLike = {
  id?: string;
  code: string;
  label?: string;
  isActive: boolean;
  isRequired: boolean;
  providedBy?: string;
  dueDaysBeforeStart?: number | null;
  appliesTo: unknown;
};

export type EnrollmentContext = {
  contractKind: string;
  /** Types de financement connus (fundings.kind) ; vide tant que le financement est à définir. */
  fundingKinds?: string[];
  /** Activité de la session : "of" ou "cfa". */
  activity?: "of" | "cfa";
};

function asList(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
}

/** Lit `applies_to` (JSON libre) de manière tolérante : liste absente ou vide = « * ». */
export function parseAppliesTo(raw: unknown): Required<AppliesTo> {
  const o = (raw && typeof raw === "object" ? raw : {}) as AppliesTo;
  const contractKinds = asList(o.contractKinds);
  const fundingKinds = asList(o.fundingKinds);
  const activity = asList(o.activity);
  return {
    contractKinds: contractKinds.length ? contractKinds : ["*"],
    fundingKinds: fundingKinds.length ? fundingKinds : ["*"],
    activity: activity.length ? activity : ["*"],
  };
}

/**
 * Une pièce s'applique à une inscription si elle est active et que chacun de ses déclencheurs
 * accepte le dossier (« * » = toujours). Un financement non encore défini ne déclenche que les
 * pièces indépendantes du financement : elles seront recalculées quand le financement sera connu.
 */
export function pieceApplies(piece: RequiredPieceLike, ctx: EnrollmentContext): boolean {
  if (!piece.isActive) return false;
  const a = parseAppliesTo(piece.appliesTo);
  if (!a.contractKinds.includes("*") && !a.contractKinds.includes(ctx.contractKind)) return false;
  if (!a.fundingKinds.includes("*")) {
    const kinds = ctx.fundingKinds ?? [];
    if (!kinds.some((k) => a.fundingKinds.includes(k))) return false;
  }
  if (!a.activity.includes("*") && ctx.activity && !a.activity.includes(ctx.activity)) return false;
  return true;
}

/** Pièces applicables, dans l'ordre de position. */
export function applicablePieces<T extends RequiredPieceLike>(pieces: T[], ctx: EnrollmentContext): T[] {
  return pieces.filter((p) => pieceApplies(p, ctx));
}

/** Échéance d'une pièce : N jours avant le début de la session (ISO), ou null. */
export function pieceDueDate(piece: Pick<RequiredPieceLike, "dueDaysBeforeStart">, startDate: string | null | undefined): string | null {
  if (piece.dueDaysBeforeStart === null || piece.dueDaysBeforeStart === undefined || !startDate) return null;
  const [y, m, d] = startDate.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() - piece.dueDaysBeforeStart);
  return dt.toISOString().slice(0, 10);
}

/* ---------- Statut d'inscription (distinct du statut commercial, de la progression, du financement, de l'examen) ---------- */

const ALLOWED: Record<EnrollmentStatus, EnrollmentStatus[]> = {
  preinscrit: ["inscrit", "annule", "reporte"],
  inscrit: ["en_cours", "annule", "reporte", "preinscrit"],
  en_cours: ["termine", "abandon"],
  termine: [],
  abandon: [],
  annule: ["preinscrit"],
  reporte: ["preinscrit", "inscrit", "annule"],
};

export type EnrollmentTransitionResult = { ok: true } | { ok: false; reason: string };

/**
 * Transition contrôlée du statut d'inscription. Les sorties (abandon, annulation, report) exigent un motif.
 * Terminé exige que le dossier ait été en cours. Terminer une inscription ne solde jamais le financement.
 */
export function canTransitionEnrollment(from: EnrollmentStatus, to: EnrollmentStatus, opts: { reason?: string | null } = {}): EnrollmentTransitionResult {
  if (from === to) return { ok: false, reason: `L'inscription est déjà au statut « ${from} ».` };
  if (!ALLOWED[from]?.includes(to)) return { ok: false, reason: `Passage de « ${from} » à « ${to} » non autorisé. Pour rouvrir un dossier clos, utilisez la réouverture tracée.` };
  if (["abandon", "annule", "reporte"].includes(to) && !opts.reason?.trim()) return { ok: false, reason: "Indiquez le motif de cette sortie : il est conservé dans le journal du dossier." };
  return { ok: true };
}

export function nextEnrollmentStatuses(status: EnrollmentStatus): EnrollmentStatus[] {
  return ALLOWED[status] ?? [];
}

/** Statuts qui occupent une place dans la session. */
export const ACTIVE_ENROLLMENT_STATUSES: EnrollmentStatus[] = ["preinscrit", "inscrit", "en_cours"];
/** Statuts comptant pour le minimum de confirmation d'une session. */
export const CONFIRMED_ENROLLMENT_STATUSES: EnrollmentStatus[] = ["inscrit", "en_cours"];
/** Statuts clos : la réouverture est tracée. */
export const CLOSED_ENROLLMENT_STATUSES: EnrollmentStatus[] = ["termine", "abandon", "annule"];

/** Référence d'inscription : INS-AAAA-NNNN. */
export function formatReference(prefix: string, year: number, n: number): string {
  return `${prefix}-${year}-${String(n).padStart(4, "0")}`;
}

export const enrollmentStatusLabels: Record<EnrollmentStatus, string> = {
  preinscrit: "Préinscrit",
  inscrit: "Inscrit",
  en_cours: "En cours",
  termine: "Terminé",
  abandon: "Abandon",
  annule: "Annulé",
  reporte: "Reporté",
};

export const contractKindLabels: Record<ContractKind, string> = {
  convention_formation: "Convention de formation",
  contrat_apprentissage: "Contrat d'apprentissage",
  contrat_professionnalisation: "Contrat de professionnalisation",
  contrat_particulier: "Contrat particulier",
  cpf: "CPF",
  stage: "Stage",
  autre: "Autre",
};

export const providedByLabels: Record<string, string> = { apprenant: "Apprenant", entreprise: "Entreprise", organisme: "Organisme", financeur: "Financeur" };

export const commercialStatusLabels: Record<string, string> = { prospect: "Prospect", devis_envoye: "Devis envoyé", accepte: "Accepté", refuse: "Refusé", sans_objet: "Sans objet" };
export const progressionLabels: Record<string, string> = { non_commencee: "Non commencée", en_cours: "En cours", acquise: "Acquise", partielle: "Partielle", non_acquise: "Non acquise" };
export const fundingStateLabels: Record<string, string> = { a_definir: "À définir", prevu: "Prévu", accorde: "Accordé", facture: "Facturé", solde: "Soldé", refuse: "Refusé" };
export const examStateLabels: Record<string, string> = { non_concerne: "Non concerné", a_inscrire: "À inscrire", inscrit: "Inscrit", admis: "Admis", ajourne: "Ajourné", absent: "Absent", rattrapage: "Rattrapage" };
