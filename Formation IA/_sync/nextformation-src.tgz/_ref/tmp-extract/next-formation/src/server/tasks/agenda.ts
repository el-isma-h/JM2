import "server-only";
import { and, asc, eq, gte, inArray, lte, isNull, or } from "drizzle-orm";
import { db, schema } from "@/db";
import type { OrgContext } from "@/server/authz";
import { parisToInstant } from "@/lib/time";
import { OPEN_STATUSES } from "./rules";
import { myTaskCondition } from "./queries";

export type AgendaItem = {
  id: string;
  kind: "rdv" | "seance" | "tache" | "examen" | "autre";
  title: string;
  start: Date;
  end: Date;
  allDay: boolean;
  location?: string | null;
  href?: string | null;
  detail?: string | null;
  /** Vrai pour un événement personnel supprimable. */
  own?: boolean;
};

/**
 * Agenda par personne : événements personnels, séances où l'utilisateur est formateur (via le rattachement
 * `trainerId` de son affectation), échéances de ses tâches et examens dont il est responsable.
 * Fenêtre [from, to] en dates ISO (Europe/Paris).
 */
export async function agendaFor(ctx: OrgContext, from: string, to: string): Promise<AgendaItem[]> {
  const orgId = ctx.org.id;
  const base = `/app/${orgId}`;
  const fromAt = parisToInstant(from, "00:00");
  const toAt = parisToInstant(to, "23:59");
  const items: AgendaItem[] = [];

  const events = await db
    .select()
    .from(schema.agendaEvents)
    .where(and(eq(schema.agendaEvents.orgId, orgId), or(eq(schema.agendaEvents.userId, ctx.user.id), and(isNull(schema.agendaEvents.userId), eq(schema.agendaEvents.createdBy, ctx.user.id))), gte(schema.agendaEvents.startAt, fromAt), lte(schema.agendaEvents.startAt, toAt)))
    .orderBy(asc(schema.agendaEvents.startAt));
  for (const e of events) {
    items.push({ id: `ev:${e.id}`, kind: (e.kind as AgendaItem["kind"]) === "seance" || e.kind === "examen" || e.kind === "tache" ? "autre" : (e.kind as AgendaItem["kind"]) || "rdv", title: e.title, start: e.startAt, end: e.endAt, allDay: false, location: e.location, href: e.href, detail: e.notes, own: true });
  }

  if (ctx.trainerId) {
    const rows = await db
      .select({ p: schema.periods, slot: schema.slots, session: { code: schema.trainingSessions.code, title: schema.trainingSessions.title } })
      .from(schema.periods)
      .innerJoin(schema.slots, eq(schema.slots.id, schema.periods.slotId))
      .innerJoin(schema.trainingSessions, eq(schema.trainingSessions.id, schema.slots.sessionId))
      .where(
        and(
          eq(schema.periods.orgId, orgId),
          gte(schema.slots.date, from),
          lte(schema.slots.date, to),
          inArray(schema.periods.status, ["prevue", "ouverte", "cloturee"]),
          inArray(schema.slots.status, ["prevue", "confirmee"]),
          or(eq(schema.periods.trainerId, ctx.trainerId), and(isNull(schema.periods.trainerId), eq(schema.slots.trainerId, ctx.trainerId))),
        ),
      )
      .orderBy(asc(schema.slots.date), asc(schema.periods.startTime));
    for (const r of rows) {
      items.push({
        id: `pe:${r.p.id}`,
        kind: "seance",
        title: r.slot.title ?? `${r.session.code} : ${r.session.title}`,
        start: parisToInstant(r.slot.date, r.p.startTime),
        end: parisToInstant(r.slot.date, r.p.endTime),
        allDay: false,
        href: `${base}/emargement/${r.p.id}`,
        detail: `${r.session.code}, ${r.p.part === "matin" ? "matin" : r.p.part === "apres_midi" ? "après-midi" : r.p.part}`,
      });
    }
  }

  const tasks = await db
    .select({ id: schema.tasks.id, title: schema.tasks.title, dueDate: schema.tasks.dueDate, status: schema.tasks.status })
    .from(schema.tasks)
    .where(and(eq(schema.tasks.orgId, orgId), myTaskCondition(ctx), inArray(schema.tasks.status, OPEN_STATUSES), gte(schema.tasks.dueDate, from), lte(schema.tasks.dueDate, to)))
    .orderBy(asc(schema.tasks.dueDate));
  for (const t of tasks) {
    if (!t.dueDate) continue;
    items.push({ id: `ta:${t.id}`, kind: "tache", title: t.title, start: parisToInstant(t.dueDate, "00:00"), end: parisToInstant(t.dueDate, "23:59"), allDay: true, href: `${base}/taches/${t.id}`, detail: t.status === "bloquee" ? "bloquée" : "échéance" });
  }

  const cohorts = await db
    .select({ id: schema.examCohorts.id, label: schema.examCohorts.label, date: schema.examCohorts.date, endDate: schema.examCohorts.endDate, code: schema.examCohorts.code })
    .from(schema.examCohorts)
    .where(and(eq(schema.examCohorts.orgId, orgId), eq(schema.examCohorts.managerUserId, ctx.user.id), gte(schema.examCohorts.date, from), lte(schema.examCohorts.date, to)))
    .orderBy(asc(schema.examCohorts.date));
  for (const c of cohorts) {
    items.push({ id: `co:${c.id}`, kind: "examen", title: `Examen : ${c.label}`, start: parisToInstant(c.date, "00:00"), end: parisToInstant(c.endDate ?? c.date, "23:59"), allDay: true, href: `${base}/examens/${c.id}`, detail: c.code });
  }

  return items.sort((a, b) => a.start.getTime() - b.start.getTime());
}

const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
const stamp = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
const day = (d: Date) => d.toISOString().slice(0, 10).replace(/-/g, "");

/** Export iCal (RFC 5545) des éléments d'agenda. */
export function toICal(items: AgendaItem[], calendarName: string): string {
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Next Formation//Agenda//FR", "CALSCALE:GREGORIAN", `X-WR-CALNAME:${esc(calendarName)}`];
  for (const it of items) {
    lines.push("BEGIN:VEVENT", `UID:${it.id}@nextformation`, `DTSTAMP:${stamp(new Date())}`, `SUMMARY:${esc(it.title)}`);
    if (it.allDay) {
      const endNext = new Date(it.end.getTime() + 1000);
      lines.push(`DTSTART;VALUE=DATE:${day(it.start)}`, `DTEND;VALUE=DATE:${day(endNext)}`);
    } else lines.push(`DTSTART:${stamp(it.start)}`, `DTEND:${stamp(it.end)}`);
    if (it.location) lines.push(`LOCATION:${esc(it.location)}`);
    if (it.detail) lines.push(`DESCRIPTION:${esc(it.detail)}`);
    lines.push(`CATEGORIES:${it.kind}`, "END:VEVENT");
  }
  lines.push("END:VCALENDAR");
  return lines.join("\r\n") + "\r\n";
}
