import "server-only";
import { NextResponse, type NextRequest } from "next/server";
import { and, eq, isNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { sha256 } from "@/lib/crypto";
import { hit } from "@/server/rate-limit";

export const API_SCOPES = [
  { key: "catalog.read", label: "Lire le catalogue (programmes)" },
  { key: "sessions.read", label: "Lire les sessions" },
  { key: "enrollments.read", label: "Lire les inscriptions (données personnelles)" },
] as const;
export type ApiScope = (typeof API_SCOPES)[number]["key"];

export const API_RATE_LIMIT = { limit: 600, windowSeconds: 60 } as const;

export type ApiAuth = { orgId: string; keyId: string; scopes: string[] };

export function apiError(status: number, error: string, extra: Record<string, unknown> = {}) {
  return NextResponse.json({ error, ...extra }, { status, headers: { "Cache-Control": "no-store" } });
}

/**
 * Authentifie `Authorization: Bearer nf_…` : clé hachée SHA-256, non révoquée, scope requis, limitation de débit
 * (600 requêtes par minute et par clé). Isolation : la clé porte l'organisme, jamais la requête.
 */
export async function authenticateApiKey(req: NextRequest, scope: ApiScope): Promise<{ ok: true; auth: ApiAuth } | { ok: false; response: NextResponse }> {
  const header = req.headers.get("authorization") ?? "";
  const m = /^Bearer\s+([A-Za-z0-9_\-.]{20,200})$/.exec(header);
  if (!m) return { ok: false, response: apiError(401, "Clé API requise : en-tête Authorization: Bearer <clé>.") };
  const token = m[1];
  const [key] = await db.select().from(schema.apiKeys).where(and(eq(schema.apiKeys.keyHash, sha256(token)), isNull(schema.apiKeys.revokedAt))).limit(1);
  if (!key) return { ok: false, response: apiError(401, "Clé API inconnue ou révoquée.") };
  const scopes = Array.isArray(key.scopes) ? (key.scopes as string[]) : [];
  if (!scopes.includes(scope)) return { ok: false, response: apiError(403, `Portée « ${scope} » absente de cette clé.`) };
  const rl = await hit("api:key", key.id, API_RATE_LIMIT);
  if (!rl.ok) return { ok: false, response: apiError(429, "Trop de requêtes : réessayez plus tard.", { retryAfterSeconds: rl.retryAfterSeconds }) };
  await db.update(schema.apiKeys).set({ lastUsedAt: new Date() }).where(eq(schema.apiKeys.id, key.id));
  return { ok: true, auth: { orgId: key.orgId, keyId: key.id, scopes } };
}

export function readPagination(req: NextRequest): { limit: number; offset: number } {
  const sp = req.nextUrl.searchParams;
  const limit = Math.min(200, Math.max(1, Number(sp.get("limit") ?? 50) || 50));
  const offset = Math.max(0, Number(sp.get("offset") ?? 0) || 0);
  return { limit, offset };
}
