import { describe, expect, it } from "vitest";
import { aggregateAnswers, dropoutFrom, isSatisfied, parseQuestions, rate, responseRateFrom, responseScore, satisfactionFromResponses, successFrom, validateSubmission, type SurveyQuestion } from "../indicator-math";
import { formatQuestionLines, parseQuestionLines, SURVEY_TEMPLATES } from "../survey-templates";
import { readAutomation, sessionDue } from "../jobs-rules";

const NOW = "2026-10-20T10:00:00.000Z";
const Q: SurveyQuestion[] = [
  { key: "global", label: "Satisfaction globale", type: "scale", max: 5, required: true, indicator: "satisfaction" },
  { key: "reco", label: "Recommandation", type: "scale", max: 10, required: true },
  { key: "libre", label: "Commentaire", type: "text" },
];

describe("taux : dénominateurs explicites", () => {
  it("rate retourne null quand le dénominateur est nul", () => {
    expect(rate(0, 0)).toBeNull();
    expect(rate(1, 3)).toBe(33.3);
  });
  it("satisfaction : réponses ≥ 4/5 à la question globale / répondants l'ayant renseignée ; réponses incomplètes exclues", () => {
    const r = satisfactionFromResponses(
      [
        { answers: { global: 5, reco: 9 }, questions: Q },
        { answers: { global: 4 }, questions: Q },
        { answers: { global: 2 }, questions: Q },
        { answers: { reco: 8 }, questions: Q }, // question globale absente : exclue du dénominateur
        { answers: { global: "" }, questions: Q },
      ],
      NOW,
    );
    expect(r.numerator).toBe(2);
    expect(r.denominator).toBe(3);
    expect(r.value).toBe(66.7);
    expect(r.definition).toMatch(/4\/5/);
    expect(r.exclusions).toMatch(/incomplètes/);
    expect(r.computedAt).toBe(NOW);
  });
  it("satisfaction sur échelle 10 : seuil 8", () => {
    expect(isSatisfied(8, 10)).toBe(true);
    expect(isSatisfied(7, 10)).toBe(false);
    expect(isSatisfied(4, 5)).toBe(true);
    expect(isSatisfied(3, 5)).toBe(false);
  });
  it("taux de retour : soumis / envoyés", () => {
    const r = responseRateFrom(8, 5, NOW);
    expect(r.value).toBe(62.5);
    expect(r.denominator).toBe(8);
    expect(responseRateFrom(0, 0, NOW).value).toBeNull();
  });
  it("abandon : abandons / entrés en formation (préinscrits, annulés et reportés exclus)", () => {
    const r = dropoutFrom(
      [
        { status: "inscrit", examState: "non_concerne" },
        { status: "en_cours", examState: "non_concerne" },
        { status: "termine", examState: "admis" },
        { status: "abandon", examState: "non_concerne" },
        { status: "preinscrit", examState: "non_concerne" },
        { status: "annule", examState: "non_concerne" },
        { status: "reporte", examState: "non_concerne" },
      ],
      NOW,
    );
    expect(r.numerator).toBe(1);
    expect(r.denominator).toBe(4);
    expect(r.value).toBe(25);
  });
  it("réussite : admis / présentés (non concernés, à inscrire, inscrits sans résultat exclus)", () => {
    const r = successFrom(
      [
        { status: "termine", examState: "admis" },
        { status: "termine", examState: "admis" },
        { status: "termine", examState: "ajourne" },
        { status: "termine", examState: "absent" },
        { status: "termine", examState: "rattrapage" },
        { status: "termine", examState: "inscrit" },
        { status: "termine", examState: "non_concerne" },
        { status: "annule", examState: "admis" },
      ],
      NOW,
    );
    expect(r.numerator).toBe(2);
    expect(r.denominator).toBe(5);
    expect(r.value).toBe(40);
  });
});

describe("réponses d'enquête", () => {
  it("score global : moyenne des échelles ramenée sur 100", () => {
    expect(responseScore({ global: 4, reco: 10 }, Q)).toBe(90);
    expect(responseScore({ libre: "x" }, Q)).toBeNull();
  });
  it("validation : obligatoire, bornes d'échelle, choix et oui/non", () => {
    expect(validateSubmission(Q, { global: "", reco: "5" })).toEqual({ ok: false, error: expect.stringContaining("obligatoire") });
    expect(validateSubmission(Q, { global: "6", reco: "5" })).toEqual({ ok: false, error: expect.stringContaining("1 à 5") });
    const ok = validateSubmission(Q, { global: "5", reco: "9", libre: " bien " });
    expect(ok).toEqual({ ok: true, answers: { global: 5, reco: 9, libre: "bien" } });
    const yn: SurveyQuestion[] = [{ key: "a", label: "A", type: "yesno", required: true }, { key: "c", label: "C", type: "choice", options: ["x", "y"], required: true }];
    expect(validateSubmission(yn, { a: "peut-être", c: "x" }).ok).toBe(false);
    expect(validateSubmission(yn, { a: "oui", c: "z" }).ok).toBe(false);
    expect(validateSubmission(yn, { a: "non", c: "y" })).toEqual({ ok: true, answers: { a: "non", c: "y" } });
  });
  it("agrégation par question", () => {
    const agg = aggregateAnswers([{ global: 5, libre: "top" }, { global: 3 }, { global: 4, libre: "" }], Q);
    expect(agg[0].n).toBe(3);
    expect(agg[0].mean).toBe(4);
    expect(agg[0].distribution).toEqual({ "5": 1, "3": 1, "4": 1 });
    expect(agg[2].texts).toEqual(["top"]);
  });
  it("parseQuestions tolère un JSON incomplet", () => {
    expect(parseQuestions([{ key: "k", label: "L", type: "scale", max: 7 }, { label: "sans clé" }, null])).toEqual([{ key: "k", label: "L", type: "scale", max: 5, options: undefined, required: false, indicator: undefined }]);
  });
});

describe("modèles d'enquêtes et éditeur en lignes", () => {
  it("chaque modèle de satisfaction porte une question globale #satisfaction et des définitions", () => {
    for (const t of SURVEY_TEMPLATES) {
      expect(t.questions.length).toBeGreaterThan(0);
      expect(t.indicators.length).toBeGreaterThan(0);
      if (t.kind.startsWith("satisfaction")) expect(t.questions.some((q) => q.indicator === "satisfaction" && q.type === "scale")).toBe(true);
    }
  });
  it("aller-retour format texte", () => {
    const text = "*echelle5: Globalement ? #satisfaction\ntexte: Remarques\n*choix: Situation | A ; B ; C\nouinon: Handicap ?\necchelle10: x";
    const bad = parseQuestionLines(text);
    expect(bad.ok).toBe(false);
    const good = parseQuestionLines(text.split("\n").slice(0, 4).join("\n"));
    expect(good.ok).toBe(true);
    if (good.ok) {
      expect(good.questions[0]).toMatchObject({ type: "scale", max: 5, required: true, indicator: "satisfaction" });
      expect(good.questions[2]).toMatchObject({ type: "choice", options: ["A", "B", "C"], required: true });
      expect(parseQuestionLines(formatQuestionLines(good.questions))).toEqual({ ok: true, questions: good.questions });
    }
  });
  it("refuse une question #satisfaction qui n'est pas une échelle et un choix sans options", () => {
    expect(parseQuestionLines("texte: Avis #satisfaction").ok).toBe(false);
    expect(parseQuestionLines("choix: Quoi | A").ok).toBe(false);
  });
});

describe("envoi automatique", () => {
  it("session due quand fin + délai ≤ aujourd'hui", () => {
    expect(sessionDue("2026-10-20", 0, "2026-10-20")).toBe(true);
    expect(sessionDue("2026-10-20", 90, "2027-01-17")).toBe(false);
    expect(sessionDue("2026-10-20", 90, "2027-01-18")).toBe(true);
  });
  it("lit l'automatisation stockée en JSON", () => {
    expect(readAutomation({ trigger: "session_end", delayDays: "90" })).toMatchObject({ trigger: "session_end", delayDays: 90 });
    expect(readAutomation(null).delayDays).toBe(0);
  });
});
