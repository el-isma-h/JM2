"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { encrypt } from "@/lib/crypto";
import { checkBic, checkIban } from "@/lib/validators";
import { AuthError } from "@/server/auth";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { canManageRib, canViewRib, getRibDocument, RIB_SOURCE_TYPE } from "@/server/documents/rib";
import { createDocument, issueDownloadLink } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { deleteObject } from "@/server/storage";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide.");
const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

/**
 * F12 : la gestion (dépôt, remplacement, validation, refus, suppression) exige le propriétaire ou `finance.manage`.
 * `finance.view` seul (cas « Nathalie ») est refusé ici même par appel direct de l'action.
 */
async function requireRibManager(orgId: string): Promise<OrgContext> {
  const ctx = await requireOrg(orgId);
  if (!canManageRib(ctx)) throw new AuthError("forbidden");
  return ctx;
}

const path = (orgId: string) => `/app/${orgId}/finance/rib`;

export async function uploadRibAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireRibManager(orgId);
    const input = z.object({ iban: z.string().trim().min(1, "IBAN requis."), bic: z.string().trim(), holder: z.string().trim().min(2, "Titulaire du compte requis.").max(160) }).parse({ iban: str(fd, "iban"), bic: str(fd, "bic"), holder: str(fd, "holder") });
    const iban = checkIban(input.iban);
    if (!iban.ok) return { error: `IBAN : ${iban.error}` };
    let bic: string | null = null;
    if (input.bic) {
      const b = checkBic(input.bic);
      if (!b.ok) return { error: `BIC : ${b.error}` };
      bic = b.value;
    }
    const file = fd.get("file");
    if (!(file instanceof File) || !file.size) return { error: "Joignez le RIB (PDF, PNG ou JPEG)." };
    const head = new Uint8Array(await file.slice(0, 8).arrayBuffer());
    const check = checkUpload({ name: file.name, type: file.type, size: file.size, head });
    if (!check.ok) return { error: check.error };
    if (!["application/pdf", "image/png", "image/jpeg"].includes(check.mime)) return { error: "Le RIB doit être un PDF, un PNG ou un JPEG." };
    const previous = await getRibDocument(orgId);
    const doc = await createDocument({
      orgId,
      category: "rib",
      visibility: "confidentiel",
      status: "genere",
      title: "RIB central de l'organisme",
      fileName: file.name,
      mimeType: check.mime,
      data: Buffer.from(await file.arrayBuffer()),
      sourceType: RIB_SOURCE_TYPE,
      sourceId: orgId,
      uploadedBy: ctx.user.id,
      previousVersionId: previous?.id ?? null,
      isDemo: ctx.org.isDemo,
    });
    if (previous) await db.update(schema.documents).set({ status: "archive" }).where(and(eq(schema.documents.id, previous.id), eq(schema.documents.orgId, orgId)));
    await db
      .update(schema.organismes)
      .set({ ribIbanEnc: encrypt(iban.value, "rib"), ribIbanLast4: iban.value.slice(-4), ribBic: bic, ribHolder: input.holder })
      .where(eq(schema.organismes.id, orgId));
    await audit({ action: previous ? "rib.replace" : "rib.upload", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, before: previous ? { documentId: previous.id, version: previous.version, last4: ctx.org.ribIbanLast4 } : null, after: { documentId: doc.id, version: doc.version, last4: iban.value.slice(-4), bic, holder: input.holder } });
    revalidatePath(path(orgId));
    return { ok: true, message: previous ? `RIB remplacé (version ${doc.version}) ; l'ancien est archivé. Pensez à le valider.` : "RIB déposé. Pensez à le valider après vérification." };
  } catch (e) {
    return fail(e, "Dépôt impossible.");
  }
}

export async function validateRibAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireRibManager(orgId);
    const doc = await getRibDocument(orgId);
    if (!doc) return { error: "Aucun RIB déposé." };
    if (doc.status === "valide") return { error: "Ce RIB est déjà validé." };
    await db.update(schema.documents).set({ status: "valide", validatedAt: new Date(), validatedBy: ctx.user.id }).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, orgId)));
    await audit({ action: "rib.validate", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, before: { status: doc.status }, after: { status: "valide" } });
    revalidatePath(path(orgId));
    return { ok: true, message: "RIB validé." };
  } catch (e) {
    return fail(e, "Validation impossible.");
  }
}

export async function refuseRibAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const reason = z.string().trim().min(3, "Indiquez le motif du refus.").max(500).parse(str(fd, "reason"));
    const ctx = await requireRibManager(orgId);
    const doc = await getRibDocument(orgId);
    if (!doc) return { error: "Aucun RIB déposé." };
    await db.update(schema.documents).set({ status: "invalide", generationData: { ...((doc.generationData as Record<string, unknown>) ?? {}), refusal: { reason, by: ctx.user.id, at: new Date().toISOString() } } }).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, orgId)));
    await audit({ action: "rib.refuse", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, before: { status: doc.status }, after: { status: "invalide", reason } });
    revalidatePath(path(orgId));
    return { ok: true, message: "RIB refusé : déposez un nouveau fichier." };
  } catch (e) {
    return fail(e, "Refus impossible.");
  }
}

export async function deleteRibAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireRibManager(orgId);
    const doc = await getRibDocument(orgId);
    if (!doc) return { error: "Aucun RIB déposé." };
    await db.delete(schema.documents).where(and(eq(schema.documents.id, doc.id), eq(schema.documents.orgId, orgId)));
    await deleteObject(doc.storageKey);
    await db.update(schema.organismes).set({ ribIbanEnc: null, ribIbanLast4: null, ribBic: null, ribHolder: null }).where(eq(schema.organismes.id, orgId));
    await audit({ action: "rib.delete", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, before: { documentId: doc.id, version: doc.version, last4: ctx.org.ribIbanLast4 } });
    revalidatePath(path(orgId));
    return { ok: true, message: "RIB supprimé (fichier et coordonnées bancaires)." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

/** Lien de téléchargement temporaire du RIB : propriétaire ou finance.view ; lecture auditée `rib.view`. */
export async function ribDownloadLinkAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(str(fd, "orgId"));
    const ctx = await requireOrg(orgId);
    if (!canViewRib(ctx)) throw new AuthError("forbidden");
    const doc = await getRibDocument(orgId);
    if (!doc) return { error: "Aucun RIB déposé." };
    await audit({ action: "rib.view", userId: ctx.user.id, orgId, entityType: "document", entityId: doc.id, after: { mode: "download" } });
    const url = await issueDownloadLink(doc.id, ctx.user.id);
    return { ok: true, data: { url } };
  } catch (e) {
    return fail(e, "Téléchargement impossible.");
  }
}
