"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, asc, desc, eq, ne, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { slugify } from "@/lib/utils";
import { todayParis } from "@/lib/time";
import { requireOrg, type OrgContext } from "@/server/authz";
import { audit } from "@/server/audit";
import { createDocument } from "@/server/documents/store";
import { recordEvidence } from "@/server/quality/evidence";
import { bool, fail, int, isoDate, str, tagList, uuid } from "@/server/crm/helpers";
import { renderProgramPdf } from "@/server/catalog/program-pdf";
import type { ActionState } from "./auth";

const PROGRAM_KINDS = schema.programKindEnum.enumValues;
const PROGRAM_STATUS = schema.programStatusEnum.enumValues;
const MODALITIES = schema.modalityEnum.enumValues;

function base(orgId: string) {
  return `/app/${orgId}`;
}

async function loadProgram(ctx: OrgContext, id: string) {
  const [p] = await db.select().from(schema.programs).where(and(eq(schema.programs.id, id), eq(schema.programs.orgId, ctx.org.id))).limit(1);
  if (!p) throw new Error("Formation introuvable dans cet organisme.");
  return p;
}
async function loadVersion(ctx: OrgContext, id: string) {
  const [v] = await db.select().from(schema.programVersions).where(and(eq(schema.programVersions.id, id), eq(schema.programVersions.orgId, ctx.org.id))).limit(1);
  if (!v) throw new Error("Version introuvable dans cet organisme.");
  return v;
}
async function loadCertification(ctx: OrgContext, id: string) {
  const [c] = await db.select().from(schema.certifications).where(and(eq(schema.certifications.id, id), eq(schema.certifications.orgId, ctx.org.id))).limit(1);
  if (!c) throw new Error("Certification introuvable dans cet organisme.");
  return c;
}

function eurosToCents(raw: string | null): number | null {
  if (!raw) return null;
  const v = raw.replace(/[\s €]/g, "").replace(",", ".");
  if (!/^\d+(\.\d{1,2})?$/.test(v)) throw new Error("Tarif invalide (ex. 1 450,00).");
  const [i, d = ""] = v.split(".");
  return Number(i) * 100 + Number(d.padEnd(2, "0"));
}

// ---------------------------------------------------------------------------
// Certifications
// ---------------------------------------------------------------------------

function certificationValues(formData: FormData) {
  const rawBlocks = str(formData, "blocks", 5000);
  const blocks = rawBlocks
    ? rawBlocks
        .split("\n")
        .map((l) => l.trim())
        .filter(Boolean)
        .map((l) => {
          const [code, label, description] = l.split("|").map((x) => x.trim());
          return { code: code ?? "", label: label ?? code ?? "", description: description ?? "" };
        })
    : [];
  return {
    title: z.string().trim().min(2, "Intitulé requis").max(250).parse(formData.get("title")),
    rncpCode: str(formData, "rncpCode", 20),
    rsCode: str(formData, "rsCode", 20),
    certifier: str(formData, "certifier", 200),
    level: str(formData, "level", 40),
    validUntil: isoDate(formData, "validUntil"),
    blocks,
    habilitationRef: str(formData, "habilitationRef", 120),
    habilitationValidUntil: isoDate(formData, "habilitationValidUntil"),
  };
}

export async function saveCertificationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const values = certificationValues(formData);
    const rawId = str(formData, "certificationId", 40);
    if (rawId) {
      const before = await loadCertification(ctx, uuid.parse(rawId));
      await db.update(schema.certifications).set(values).where(eq(schema.certifications.id, before.id));
      await audit({ action: "certification.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "certification", entityId: before.id, before, after: values });
    } else {
      const [row] = await db.insert(schema.certifications).values({ ...values, orgId: ctx.org.id }).returning({ id: schema.certifications.id });
      await audit({ action: "certification.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "certification", entityId: row.id, after: values });
    }
    revalidatePath(`${base(orgId)}/catalogue/certifications`);
    revalidatePath(`${base(orgId)}/catalogue`);
    return { ok: true, message: "Certification enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deleteCertificationAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const c = await loadCertification(ctx, uuid.parse(formData.get("certificationId")));
    const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.programs).where(and(eq(schema.programs.orgId, ctx.org.id), eq(schema.programs.certificationId, c.id)));
    if (n > 0) return { error: `${n} formation(s) visent cette certification : détachez-les avant de la supprimer.` };
    await db.delete(schema.certifications).where(eq(schema.certifications.id, c.id));
    await audit({ action: "certification.delete", userId: ctx.user.id, orgId: ctx.org.id, entityType: "certification", entityId: c.id, before: c });
    revalidatePath(`${base(orgId)}/catalogue/certifications`);
    return { ok: true, message: "Certification supprimée." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

// ---------------------------------------------------------------------------
// Formations (programs)
// ---------------------------------------------------------------------------

async function programValues(ctx: OrgContext, formData: FormData, current?: typeof schema.programs.$inferSelect) {
  const title = z.string().trim().min(2, "Intitulé requis").max(250).parse(formData.get("title"));
  const code = z.string().trim().min(1, "Code requis").max(40).regex(/^[A-Za-z0-9._-]+$/, "Code : lettres, chiffres, point, tiret ou souligné").parse(formData.get("code")).toUpperCase();
  const rawSlug = str(formData, "slug", 80);
  const slug = slugify(rawSlug || title) || code.toLowerCase();
  const certRaw = str(formData, "certificationId", 40);
  const certificationId = certRaw ? (await loadCertification(ctx, uuid.parse(certRaw))).id : null;
  const [codeClash] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.orgId, ctx.org.id), eq(schema.programs.code, code), current ? ne(schema.programs.id, current.id) : undefined)).limit(1);
  if (codeClash) throw new Error(`Le code « ${code} » est déjà utilisé par une autre formation.`);
  const [slugClash] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.orgId, ctx.org.id), eq(schema.programs.slug, slug), current ? ne(schema.programs.id, current.id) : undefined)).limit(1);
  if (slugClash) throw new Error(`L'adresse publique « ${slug} » est déjà utilisée par une autre formation.`);
  return {
    code,
    title,
    slug,
    kind: z.enum(PROGRAM_KINDS).parse(formData.get("kind") || "formation_courte"),
    category: str(formData, "category", 120),
    certificationId,
    availableAsApprenticeship: bool(formData, "availableAsApprenticeship"),
    availableAsContinuing: bool(formData, "availableAsContinuing"),
    status: z.enum(PROGRAM_STATUS).parse(formData.get("status") || "brouillon"),
    specialty: str(formData, "specialty", 120),
    formacode: str(formData, "formacode", 40),
    cpfEligible: bool(formData, "cpfEligible"),
    tags: tagList(str(formData, "tags", 1000)),
  };
}

export async function createProgramAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let orgId = "";
  let id = "";
  try {
    orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const values = await programValues(ctx, formData);
    const row = await db.transaction(async (tx) => {
      const [p] = await tx.insert(schema.programs).values({ ...values, orgId: ctx.org.id, isDemo: ctx.org.isDemo }).returning({ id: schema.programs.id });
      await tx.insert(schema.programVersions).values({
        orgId: ctx.org.id,
        programId: p.id,
        version: 1,
        status: "brouillon",
        modality: z.enum(MODALITIES).parse(formData.get("modality") || "presentiel"),
        durationHours: int(formData, "durationHours", { min: 0, max: 100000 }) ?? 0,
        createdBy: ctx.user.id,
      });
      return p;
    });
    await audit({ action: "program.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "program", entityId: row.id, after: values });
    revalidatePath(`${base(orgId)}/catalogue`);
    id = row.id;
  } catch (e) {
    return fail(e, "Création impossible.");
  }
  redirect(`${base(orgId)}/catalogue/${id}`);
}

export async function updateProgramAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const before = await loadProgram(ctx, uuid.parse(formData.get("programId")));
    const values = await programValues(ctx, formData, before);
    await db.update(schema.programs).set(values).where(eq(schema.programs.id, before.id));
    await audit({ action: "program.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "program", entityId: before.id, before, after: values });
    revalidatePath(`${base(orgId)}/catalogue/${before.id}`);
    revalidatePath(`${base(orgId)}/catalogue`);
    return { ok: true, message: "Formation enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Publication au catalogue public : exige une version active. */
export async function setProgramPublishedAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const p = await loadProgram(ctx, uuid.parse(formData.get("programId")));
    const publish = formData.get("publish") === "1";
    if (publish) {
      const [active] = await db.select({ id: schema.programVersions.id }).from(schema.programVersions).where(and(eq(schema.programVersions.programId, p.id), eq(schema.programVersions.status, "active"))).limit(1);
      if (!active) return { error: "Activez d'abord une version du programme : le catalogue public n'affiche que des versions actives." };
      if (p.status !== "actif") return { error: "Passez la formation au statut « Actif » avant de la publier." };
    }
    await db.update(schema.programs).set({ isPublished: publish, publishedAt: publish ? new Date() : p.publishedAt }).where(eq(schema.programs.id, p.id));
    await audit({ action: publish ? "program.publish" : "program.unpublish", userId: ctx.user.id, orgId: ctx.org.id, entityType: "program", entityId: p.id, before: { isPublished: p.isPublished }, after: { isPublished: publish } });
    revalidatePath(`${base(orgId)}/catalogue/${p.id}`);
    revalidatePath(`${base(orgId)}/catalogue`);
    revalidatePath(`/catalogue-public/${ctx.tenant.slug}`);
    return { ok: true, message: publish ? `Formation publiée sur le catalogue public (/catalogue-public/${ctx.tenant.slug}).` : "Formation retirée du catalogue public." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

// ---------------------------------------------------------------------------
// Versions de programme
// ---------------------------------------------------------------------------

function versionValues(formData: FormData) {
  return {
    effectiveFrom: isoDate(formData, "effectiveFrom"),
    objectives: str(formData, "objectives", 10000),
    prerequisites: str(formData, "prerequisites", 5000),
    audience: str(formData, "audience", 5000),
    modality: z.enum(MODALITIES).parse(formData.get("modality") || "presentiel"),
    durationHours: int(formData, "durationHours", { min: 0, max: 100000 }) ?? 0,
    durationDays: int(formData, "durationDays", { min: 0, max: 10000 }),
    companyHours: int(formData, "companyHours", { min: 0, max: 100000 }) ?? 0,
    remoteHours: int(formData, "remoteHours", { min: 0, max: 100000 }) ?? 0,
    content: str(formData, "content", 20000),
    methods: str(formData, "methods", 10000),
    evaluationMethods: str(formData, "evaluationMethods", 10000),
    resources: str(formData, "resources", 5000),
    accessibility: str(formData, "accessibility", 5000),
    accessDelay: str(formData, "accessDelay", 1000),
    priceCents: eurosToCents(str(formData, "priceEuros", 30)),
    priceNote: str(formData, "priceNote", 500),
    rhythm: str(formData, "rhythmLabel", 200) ? { label: str(formData, "rhythmLabel", 200) } : {},
    trainerProfile: str(formData, "trainerProfile", 3000),
  };
}

export async function updateVersionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const v = await loadVersion(ctx, uuid.parse(formData.get("versionId")));
    if (v.status === "archivee") return { error: "Une version archivée n'est plus modifiable : créez une nouvelle version." };
    const values = versionValues(formData);
    await db.update(schema.programVersions).set(values).where(eq(schema.programVersions.id, v.id));
    await audit({ action: "program_version.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "program_version", entityId: v.id, before: { durationHours: v.durationHours, priceCents: v.priceCents }, after: { durationHours: values.durationHours, priceCents: values.priceCents } });
    revalidatePath(`${base(orgId)}/catalogue/${v.programId}`);
    return { ok: true, message: v.status === "active" ? "Version active enregistrée. Les inscriptions déjà contractualisées conservent le contenu figé à leur date." : "Version enregistrée." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Nouvelle version = copie de la dernière (champs et modules) en brouillon. */
export async function createVersionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const p = await loadProgram(ctx, uuid.parse(formData.get("programId")));
    const [draft] = await db.select({ id: schema.programVersions.id, version: schema.programVersions.version }).from(schema.programVersions).where(and(eq(schema.programVersions.programId, p.id), eq(schema.programVersions.status, "brouillon"))).limit(1);
    if (draft) return { error: `Une version brouillon (v${draft.version}) existe déjà : modifiez-la ou activez-la avant d'en créer une autre.` };
    const [last] = await db.select().from(schema.programVersions).where(eq(schema.programVersions.programId, p.id)).orderBy(desc(schema.programVersions.version)).limit(1);
    const next = (last?.version ?? 0) + 1;
    const created = await db.transaction(async (tx) => {
      const [v] = await tx
        .insert(schema.programVersions)
        .values({
          orgId: ctx.org.id,
          programId: p.id,
          version: next,
          status: "brouillon",
          effectiveFrom: null,
          objectives: last?.objectives ?? null,
          prerequisites: last?.prerequisites ?? null,
          audience: last?.audience ?? null,
          modality: last?.modality ?? "presentiel",
          durationHours: last?.durationHours ?? 0,
          durationDays: last?.durationDays ?? null,
          companyHours: last?.companyHours ?? 0,
          remoteHours: last?.remoteHours ?? 0,
          content: last?.content ?? null,
          methods: last?.methods ?? null,
          evaluationMethods: last?.evaluationMethods ?? null,
          resources: last?.resources ?? null,
          accessibility: last?.accessibility ?? null,
          accessDelay: last?.accessDelay ?? null,
          priceCents: last?.priceCents ?? null,
          priceNote: last?.priceNote ?? null,
          rhythm: last?.rhythm ?? {},
          trainerProfile: last?.trainerProfile ?? null,
          createdBy: ctx.user.id,
        })
        .returning();
      if (last) {
        const mods = await tx.select().from(schema.modules).where(eq(schema.modules.programVersionId, last.id)).orderBy(asc(schema.modules.position));
        for (const m of mods) {
          await tx.insert(schema.modules).values({ orgId: ctx.org.id, programVersionId: v.id, blockCode: m.blockCode, code: m.code, title: m.title, description: m.description, hours: m.hours, position: m.position, modality: m.modality, skills: m.skills });
        }
      }
      return v;
    });
    await audit({ action: "program_version.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "program_version", entityId: created.id, after: { version: next, copiedFrom: last?.id ?? null } });
    revalidatePath(`${base(orgId)}/catalogue/${p.id}`);
    return { ok: true, message: `Version ${next} créée en brouillon${last ? ` (copie de la version ${last.version})` : ""}.` };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

/** Activation : la version précédente est archivée ; les inscriptions existantes (program_version_id figé) ne sont jamais touchées. */
export async function activateVersionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const v = await loadVersion(ctx, uuid.parse(formData.get("versionId")));
    if (v.status !== "brouillon") return { error: "Seule une version brouillon peut être activée." };
    const effectiveFrom = isoDate(formData, "effectiveFrom") ?? v.effectiveFrom ?? todayParis();
    const archived = await db.transaction(async (tx) => {
      const prev = await tx
        .update(schema.programVersions)
        .set({ status: "archivee" })
        .where(and(eq(schema.programVersions.programId, v.programId), eq(schema.programVersions.status, "active"), ne(schema.programVersions.id, v.id)))
        .returning({ id: schema.programVersions.id, version: schema.programVersions.version });
      await tx.update(schema.programVersions).set({ status: "active", effectiveFrom, validatedBy: ctx.user.id, validatedAt: new Date() }).where(eq(schema.programVersions.id, v.id));
      return prev;
    });
    await audit({ action: "program_version.activate", userId: ctx.user.id, orgId: ctx.org.id, entityType: "program_version", entityId: v.id, before: { archived: archived.map((a) => a.version) }, after: { version: v.version, effectiveFrom } });
    revalidatePath(`${base(orgId)}/catalogue/${v.programId}`);
    revalidatePath(`${base(orgId)}/catalogue`);
    return { ok: true, message: `Version ${v.version} activée${archived.length ? ` ; version ${archived.map((a) => a.version).join(", ")} archivée` : ""}. Les parcours déjà contractualisés ne sont pas modifiés.` };
  } catch (e) {
    return fail(e, "Activation impossible.");
  }
}

// ---------------------------------------------------------------------------
// Modules / blocs
// ---------------------------------------------------------------------------

export async function saveModuleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const v = await loadVersion(ctx, uuid.parse(formData.get("versionId")));
    if (v.status === "archivee") return { error: "Version archivée : les modules ne sont plus modifiables." };
    const rawMod = str(formData, "modality", 20);
    const skills = tagList(str(formData, "skills", 2000)).map((label) => ({ code: slugify(label), label }));
    const values = {
      blockCode: str(formData, "blockCode", 40),
      code: str(formData, "code", 40),
      title: z.string().trim().min(1, "Intitulé du module requis").max(250).parse(formData.get("title")),
      description: str(formData, "description", 5000),
      hours: int(formData, "hours", { min: 0, max: 100000 }) ?? 0,
      modality: rawMod ? z.enum(MODALITIES).parse(rawMod) : null,
      skills,
    };
    const rawId = str(formData, "moduleId", 40);
    if (rawId) {
      const id = uuid.parse(rawId);
      const [m] = await db.select().from(schema.modules).where(and(eq(schema.modules.id, id), eq(schema.modules.programVersionId, v.id), eq(schema.modules.orgId, ctx.org.id))).limit(1);
      if (!m) return { error: "Module introuvable." };
      await db.update(schema.modules).set(values).where(eq(schema.modules.id, m.id));
      await audit({ action: "module.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "module", entityId: m.id, before: m, after: values });
    } else {
      const [{ max }] = await db.select({ max: sql<number>`coalesce(max(position), 0)::int` }).from(schema.modules).where(eq(schema.modules.programVersionId, v.id));
      const [row] = await db.insert(schema.modules).values({ ...values, orgId: ctx.org.id, programVersionId: v.id, position: max + 1 }).returning({ id: schema.modules.id });
      await audit({ action: "module.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "module", entityId: row.id, after: values });
    }
    revalidatePath(`${base(orgId)}/catalogue/${v.programId}`);
    return { ok: true, message: "Module enregistré." };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function moveModuleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const id = uuid.parse(formData.get("moduleId"));
    const dir = z.enum(["up", "down"]).parse(formData.get("direction"));
    const [m] = await db.select().from(schema.modules).where(and(eq(schema.modules.id, id), eq(schema.modules.orgId, ctx.org.id))).limit(1);
    if (!m) return { error: "Module introuvable." };
    const v = await loadVersion(ctx, m.programVersionId);
    if (v.status === "archivee") return { error: "Version archivée." };
    const all = await db.select().from(schema.modules).where(eq(schema.modules.programVersionId, v.id)).orderBy(asc(schema.modules.position), asc(schema.modules.createdAt));
    const idx = all.findIndex((x) => x.id === m.id);
    const swap = dir === "up" ? idx - 1 : idx + 1;
    if (swap < 0 || swap >= all.length) return { ok: true, message: "Ordre inchangé." };
    const reordered = [...all];
    [reordered[idx], reordered[swap]] = [reordered[swap], reordered[idx]];
    await db.transaction(async (tx) => {
      for (const [i, mod] of reordered.entries()) await tx.update(schema.modules).set({ position: i + 1 }).where(eq(schema.modules.id, mod.id));
    });
    revalidatePath(`${base(orgId)}/catalogue/${v.programId}`);
    return { ok: true, message: "Ordre mis à jour." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

export async function deleteModuleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage");
    const id = uuid.parse(formData.get("moduleId"));
    const [m] = await db.select().from(schema.modules).where(and(eq(schema.modules.id, id), eq(schema.modules.orgId, ctx.org.id))).limit(1);
    if (!m) return { error: "Module introuvable." };
    const v = await loadVersion(ctx, m.programVersionId);
    if (v.status === "archivee") return { error: "Version archivée : les modules ne sont plus modifiables." };
    await db.delete(schema.modules).where(eq(schema.modules.id, m.id));
    await audit({ action: "module.delete", userId: ctx.user.id, orgId: ctx.org.id, entityType: "module", entityId: m.id, before: m });
    revalidatePath(`${base(orgId)}/catalogue/${v.programId}`);
    return { ok: true, message: "Module supprimé." };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

// ---------------------------------------------------------------------------
// PDF du programme
// ---------------------------------------------------------------------------

export async function generateProgramPdfAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId, "catalog.manage", "documents.generate");
    const v = await loadVersion(ctx, uuid.parse(formData.get("versionId")));
    const p = await loadProgram(ctx, v.programId);
    const mods = await db.select().from(schema.modules).where(eq(schema.modules.programVersionId, v.id)).orderBy(asc(schema.modules.position));
    const cert = p.certificationId ? await loadCertification(ctx, p.certificationId).catch(() => null) : null;
    const pdf = await renderProgramPdf(ctx.org, p, v, mods, cert);
    const [prev] = await db
      .select({ id: schema.documents.id })
      .from(schema.documents)
      .where(and(eq(schema.documents.orgId, ctx.org.id), eq(schema.documents.sourceType, "program_version"), eq(schema.documents.sourceId, v.id)))
      .orderBy(desc(schema.documents.version))
      .limit(1);
    const doc = await createDocument({
      orgId: ctx.org.id,
      category: "programme",
      visibility: "public",
      status: "genere",
      title: `Programme ${p.code} v${v.version} : ${p.title}`,
      fileName: `programme-${p.slug}-v${v.version}.pdf`,
      mimeType: "application/pdf",
      data: pdf,
      sourceType: "program_version",
      sourceId: v.id,
      uploadedBy: ctx.user.id,
      previousVersionId: prev?.id ?? null,
      generationData: { programId: p.id, versionId: v.id, version: v.version },
      isDemo: ctx.org.isDemo,
    });
    await recordEvidence({ orgId: ctx.org.id, indicatorCode: "IND_1", level: "organisationnel", title: `Programme formalisé : ${p.title} (v${v.version})`, sourceType: "program_document", sourceId: doc.id, programId: p.id, documentId: doc.id, evidenceDate: todayParis(), createdBy: ctx.user.id });
    await audit({ action: "program.pdf", userId: ctx.user.id, orgId: ctx.org.id, entityType: "program_version", entityId: v.id, after: { documentId: doc.id, version: doc.version } });
    revalidatePath(`${base(orgId)}/catalogue/${p.id}`);
    return { ok: true, message: `Programme PDF généré (document version ${doc.version}).` };
  } catch (e) {
    return fail(e, "Génération impossible.");
  }
}
