/**
 * État partagé entre les phases du seed de démonstration (identifiants créés, calendrier de référence).
 */
import type { Db } from "@/db";
import type { DemoResult } from "../seed";
import type { Rng } from "./util";

export type Tx = Parameters<Parameters<Db["transaction"]>[0]>[0];

export type SessionKey = "bts" | "arh" | "arhA" | "sst1" | "xls1" | "mgt" | "elec" | "xls2" | "intra" | "bilan" | "sst2";

export type SessionInfo = {
  id: string;
  key: SessionKey;
  programKey: string;
  versionId: string;
  startDate: string;
  endDate: string;
  status: string;
  weekdays: number[];
  /** Première date de séance planifiée dans l'outil (ARH : après la période des feuilles papier). */
  slotsFrom: string;
  siteId: string | null;
  roomIds: string[];
  groupIds: string[];
  trainerUserId: string | null;
  trainerId: string | null;
  isApprenticeship: boolean;
};

export type EnrollmentInfo = {
  id: string;
  reference: string;
  sessionKey: SessionKey;
  personId: string;
  personName: string;
  groupIdx: number | null;
  companyKey: string | null;
  companyId: string | null;
  tutorContactId: string | null;
  status: string;
  contractKind: string;
  fundingKind: string;
  exitDate: string | null;
  isInes: boolean;
};

export type PeriodInfo = { id: string; slotId: string; sessionKey: SessionKey; groupIdx: number | null; date: string; part: "matin" | "apres_midi"; startTime: string; endTime: string; status: string };

export type State = {
  demo: DemoResult;
  orgId: string;
  org: { name: string; address: string; nda: string; siret: string };
  users: DemoResult["users"];
  rng: Rng;
  now: Date;
  today: string;
  nowTime: string;
  /** Journée fractionnée (R04) : matin clôturé, après-midi encore prévu. */
  splitDate: string;
  /** Journée témoin entièrement clôturée (360 / 180 minutes). */
  witnessDay: string;
  siteIds: { paris: string; montreuil: string };
  roomIds: { paris: string[]; montreuil: string[] };
  companies: Record<string, string>;
  contacts: Record<string, { id: string; name: string; email: string; companyKey: string; isTutor: boolean; isSignatory: boolean; isBilling: boolean }[]>;
  trainers: Record<string, string>;
  certifications: Record<string, string>;
  programs: Record<string, { id: string; versionId: string; title: string; moduleIds: string[]; durationHours: number }>;
  elearningIds: string[];
  persons: { id: string; firstName: string; lastName: string; email: string }[];
  sessions: Record<SessionKey, SessionInfo>;
  enrollments: EnrollmentInfo[];
  periods: PeriodInfo[];
  requiredPieces: { id: string; code: string; category: string; appliesTo: { contractKinds: string[]; fundingKinds: string[] }; isRequired: boolean; dueDaysBeforeStart: number | null }[];
  documents: Record<string, string>;
  funders: Record<string, string>;
  fundingIds: Record<string, string>;
  invoiceIds: { id: string; number: string; status: string; enrollmentId: string | null }[];
  cohorts: { arhA: string; btsBlanc: string };
  surveyIds: Record<string, string>;
  complaintIds: string[];
  watchIds: string[];
  evidenceIds: Record<string, string>;
  referentialId: string;
  analysisIds: { old: string; recent: string };
  qualityActionIds: string[];
  corrections: number;
  counts: Record<string, number>;
};

export const bump = (s: State, table: string, n: number) => {
  s.counts[table] = (s.counts[table] ?? 0) + n;
};
