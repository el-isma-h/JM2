/**
 * Règles pures (sans dépendance serveur, testées dans __tests__/rules.test.ts) :
 * droits sur le RIB central (F12), visibilité des documents (F09, périmètre formateur), versions (régénération).
 */
import type { OrgContext, Permission } from "@/server/authz";

export type RightsCtx = { isOwner: boolean; permissions: ReadonlySet<Permission>; trainerOnly?: boolean };

/** F12 : lecture du RIB central par le propriétaire ou `finance.view`. */
export function canViewRib(ctx: RightsCtx): boolean {
  return ctx.isOwner || ctx.permissions.has("finance.view");
}

/** F12 : dépôt, remplacement, validation, refus et suppression par le propriétaire ou `finance.manage` uniquement. */
export function canManageRib(ctx: RightsCtx): boolean {
  return ctx.isOwner || ctx.permissions.has("finance.manage");
}

/** Catégories qui constituent des pièces administratives ou financières : jamais visibles par un formateur seul. */
export const ADMIN_CATEGORIES = new Set(["convention", "contrat", "cerfa", "rib", "piece_identite", "cv", "kbis", "justificatif", "facture", "avoir", "devis", "bpf", "export", "certificat_realisation"]);

export type DocLike = {
  orgId: string;
  category: string;
  visibility: string;
  sessionId: string | null;
  sourceType: string | null;
  uploadedBy?: string | null;
};

/**
 * Visibilité d'un document selon le contexte (règles CDC §8) :
 * - isolation `orgId` ;
 * - `rib` central (sourceType org_rib) : propriétaire ou finance.view ;
 * - catégorie `cv` : candidates.cv.view ;
 * - visibilité administratif / confidentiel : dossier.admin_docs.view ;
 * - visibilité pedagogie : dossier.pedagogy.view ;
 * - formateur seul : uniquement les documents des sessions de son périmètre, visibilité pedagogie / interne, hors pièces admin.
 * `trainerSessions` : identifiants des sessions du formateur (null = pas de restriction).
 */
export function canSeeDocumentRules(ctx: RightsCtx & { orgId: string }, doc: DocLike, trainerSessions: string[] | null): boolean {
  if (doc.orgId !== ctx.orgId) return false;
  if (doc.sourceType === "org_rib" || (doc.category === "rib" && doc.sourceType === "org_rib")) return canViewRib(ctx);
  if (doc.category === "cv" && !ctx.permissions.has("candidates.cv.view")) return false;
  if ((doc.visibility === "administratif" || doc.visibility === "confidentiel") && !ctx.permissions.has("dossier.admin_docs.view")) return false;
  if (doc.visibility === "pedagogie" && !ctx.permissions.has("dossier.pedagogy.view")) return false;
  if (ctx.trainerOnly) {
    if (!doc.sessionId || !trainerSessions || !trainerSessions.includes(doc.sessionId)) return false;
    if (doc.visibility !== "pedagogie" && doc.visibility !== "interne") return false;
    if (ADMIN_CATEGORIES.has(doc.category)) return false;
  }
  return true;
}

export type ExistingVersion = { id: string; version: number; status: string };

/**
 * Plan de version lors d'une régénération (F09) :
 * - aucun document existant : version 1 ;
 * - existant « brouillon / généré / transmis » : la nouvelle version le remplace (previousVersionId, version + 1, l'ancien passe en `archive`) ;
 * - existant « signé » ou « validé » : la nouvelle version s'ajoute (previousVersionId, version + 1) mais l'existant est conservé tel quel, les deux restent listés.
 */
export function planVersion(existing: ExistingVersion | null): { version: number; previousVersionId: string | null; archivePrevious: boolean } {
  if (!existing) return { version: 1, previousVersionId: null, archivePrevious: false };
  const locked = existing.status === "signe" || existing.status === "valide";
  return { version: existing.version + 1, previousVersionId: existing.id, archivePrevious: !locked };
}

export function rightsOf(ctx: OrgContext): RightsCtx & { orgId: string } {
  return { isOwner: ctx.isOwner, permissions: ctx.permissions, trainerOnly: ctx.trainerOnly, orgId: ctx.org.id };
}
