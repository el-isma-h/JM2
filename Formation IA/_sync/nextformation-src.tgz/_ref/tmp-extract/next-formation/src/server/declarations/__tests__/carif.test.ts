import { describe, expect, it } from "vitest";
import { readCarifRecruitment, validateCarifRecruitment, type CarifRecruitment } from "../carif";
import { chorusStatusMeta } from "@/server/integrations/chorus-status";

const line = (p: Partial<CarifRecruitment>): CarifRecruitment => ({ type: "information_collective", perimeter: "", date: "", startTime: "", endTime: "", details: "", ...p });
const opts = { today: "2026-10-28", sessionEnd: "2026-12-18", previous: [] as CarifRecruitment[] };

describe("validateCarifRecruitment (guide Carif-Oref, onglet 7)", () => {
  it("accepte une ligne sans créneau", () => {
    expect(validateCarifRecruitment([line({ type: "dossier" })], opts)).toBeNull();
  });
  it("exige début et fin entre 07:00 et 20:00, fin après début", () => {
    expect(validateCarifRecruitment([line({ date: "2026-11-05", startTime: "06:30", endTime: "08:00" })], opts)).toMatch(/07:00 et 20:00/);
    expect(validateCarifRecruitment([line({ date: "2026-11-05", startTime: "09:00", endTime: "20:30" })], opts)).toMatch(/07:00 et 20:00/);
    expect(validateCarifRecruitment([line({ date: "2026-11-05", startTime: "10:00", endTime: "10:00" })], opts)).toMatch(/postérieure/);
    expect(validateCarifRecruitment([line({ date: "2026-11-05", startTime: "09:30" })], opts)).toMatch(/fin est obligatoire/);
    expect(validateCarifRecruitment([line({ date: "2026-11-05", startTime: "09:30", endTime: "11:00" })], opts)).toBeNull();
  });
  it("refuse une date passée ou postérieure à la fin de session", () => {
    expect(validateCarifRecruitment([line({ date: "2026-10-27", startTime: "09:30", endTime: "11:00" })], opts)).toMatch(/antérieure/);
    expect(validateCarifRecruitment([line({ date: "2026-12-19", startTime: "09:30", endTime: "11:00" })], opts)).toMatch(/fin de la session/);
  });
  it("conserve une ligne déjà enregistrée dont la date est passée", () => {
    const old = line({ date: "2026-10-01", startTime: "09:30", endTime: "11:00" });
    expect(validateCarifRecruitment([old], { ...opts, previous: [old] })).toBeNull();
  });
  it("lit le jsonb de façon tolérante", () => {
    expect(readCarifRecruitment([{ type: "inconnu", perimeter: "region", date: "x" }, null])).toEqual([line({ type: "information_inconnue", perimeter: "region" })]);
    expect(readCarifRecruitment("pas une liste")).toEqual([]);
  });
});

describe("chorusStatusMeta", () => {
  it("autorise le redépôt après rejet ou échec, pas après un dépôt en cours", () => {
    expect(chorusStatusMeta(null).redeposit).toBe(true);
    expect(chorusStatusMeta("REJETEE").redeposit).toBe(true);
    expect(chorusStatusMeta("echec_depot").redeposit).toBe(true);
    expect(chorusStatusMeta("DEPOSEE").redeposit).toBe(false);
    expect(chorusStatusMeta("CODE_INCONNU").label).toBe("CODE_INCONNU");
  });
});
