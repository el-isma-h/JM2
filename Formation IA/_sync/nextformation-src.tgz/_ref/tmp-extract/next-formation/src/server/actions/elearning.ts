"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { assertEnrollmentInScope, requireOrg } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { putObject } from "@/server/storage";
import { inspectScormPackage, resolveElearningAccess, upsertProgress } from "@/server/elearning/service";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const optUuid = z.preprocess((v) => (v === "" || v == null ? undefined : v), uuid.optional());
const MAX_PACKAGE = 200 * 1024 * 1024;

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

async function orgIdOf(formData: FormData) {
  return uuid.parse(formData.get("orgId"));
}

const moduleSchema = z.object({
  kind: z.enum(["contenu", "quiz", "moodle", "lien", "scorm"]),
  title: z.string().trim().min(2, "Titre requis").max(160),
  description: z.string().trim().max(2000).optional(),
  programVersionId: optUuid,
  moduleId: optUuid,
  durationMinutes: z.preprocess((v) => (v === "" || v == null ? 0 : Number(v)), z.number().int().min(0).max(100000)),
  countsAsHours: z.preprocess((v) => v === "1" || v === "on", z.boolean()).optional(),
  url: z.string().trim().url("URL invalide").max(500).optional().or(z.literal("")),
  externalId: z.string().trim().max(120).optional(),
  markdown: z.string().max(100000).optional(),
  quiz: z.string().max(100000).optional(),
});

/** Création d'un module e-learning : contenu propre (Markdown / quiz), lien Moodle (URL + identifiant), lien externe ou paquet SCORM (.zip). */
export async function createElearningModuleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "catalog.manage");
    const d = moduleSchema.parse(Object.fromEntries(formData));
    if (d.programVersionId) {
      const [v] = await db.select({ id: schema.programVersions.id }).from(schema.programVersions).where(and(eq(schema.programVersions.id, d.programVersionId), eq(schema.programVersions.orgId, ctx.org.id))).limit(1);
      if (!v) return { error: "Version de programme inconnue." };
    }
    if (d.moduleId) {
      const [m] = await db.select({ id: schema.modules.id, v: schema.modules.programVersionId }).from(schema.modules).where(and(eq(schema.modules.id, d.moduleId), eq(schema.modules.orgId, ctx.org.id))).limit(1);
      if (!m) return { error: "Module de programme inconnu." };
      if (d.programVersionId && m.v !== d.programVersionId) return { error: "Le module n'appartient pas à cette version de programme." };
    }
    let content: Record<string, unknown> = {};
    let packageKey: string | null = null;
    let url: string | null = null;
    let externalId: string | null = null;
    if (d.kind === "contenu" || d.kind === "quiz") {
      if (!d.markdown?.trim() && !d.quiz?.trim()) return { error: "Renseignez un contenu Markdown ou un quiz." };
      let quiz: unknown = null;
      if (d.quiz?.trim()) {
        try {
          quiz = JSON.parse(d.quiz);
        } catch {
          return { error: "Le quiz doit être un JSON valide : [{\"question\":\"…\",\"choices\":[\"…\"],\"answer\":0}]." };
        }
        const parsed = z.array(z.object({ question: z.string().min(1), choices: z.array(z.string().min(1)).min(2), answer: z.number().int().min(0) })).safeParse(quiz);
        if (!parsed.success) return { error: "Structure du quiz invalide : question, choices (2 minimum), answer (index)." };
        quiz = parsed.data;
      }
      content = { markdown: d.markdown ?? "", quiz };
    } else if (d.kind === "moodle") {
      if (!d.url) return { error: "URL du cours Moodle requise." };
      url = d.url;
      externalId = d.externalId || null;
    } else if (d.kind === "lien") {
      if (!d.url) return { error: "URL requise." };
      url = d.url;
    } else if (d.kind === "scorm") {
      const file = formData.get("package");
      if (!(file instanceof File) || !file.size) return { error: "Déposez le paquet SCORM (.zip)." };
      if (!/\.zip$/i.test(file.name)) return { error: "Le paquet doit être un fichier .zip." };
      if (file.size > MAX_PACKAGE) return { error: "Paquet trop volumineux (200 Mo maximum)." };
      const buf = Buffer.from(await file.arrayBuffer());
      if (!(buf[0] === 0x50 && buf[1] === 0x4b)) return { error: "Le fichier n'est pas une archive zip valide." };
      const info = await inspectScormPackage(buf);
      if (!info.ok) return { error: info.error };
      packageKey = `${ctx.org.id}/scorm/${randomUUID()}.zip`;
      await putObject(packageKey, buf);
      content = { launch: info.launch, manifestTitle: info.title, schemaVersion: info.schemaVersion, files: info.files, fileName: file.name };
    }
    const [row] = await db
      .insert(schema.elearningModules)
      .values({ orgId: ctx.org.id, programVersionId: d.programVersionId ?? null, moduleId: d.moduleId ?? null, kind: d.kind, title: d.title, description: d.description || null, packageKey, externalId, url, content, durationMinutes: d.durationMinutes, countsAsHours: d.countsAsHours ?? false })
      .returning({ id: schema.elearningModules.id });
    await audit({ action: "elearning.module.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "elearning_module", entityId: row.id, after: { kind: d.kind, title: d.title, packageKey } });
    revalidatePath(`/app/${ctx.org.id}/elearning`);
    return { ok: true, message: d.kind === "scorm" ? `Paquet SCORM importé (${(content.files as number) ?? 0} fichiers, lancement : ${content.launch}).` : "Module créé." };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

/** Activation / désactivation d'un module (jamais de suppression : les progressions sont conservées). */
export async function toggleElearningModuleAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "catalog.manage");
    const moduleId = uuid.parse(formData.get("moduleId"));
    const [m] = await db.select().from(schema.elearningModules).where(and(eq(schema.elearningModules.id, moduleId), eq(schema.elearningModules.orgId, ctx.org.id))).limit(1);
    if (!m) return { error: "Module introuvable." };
    await db.update(schema.elearningModules).set({ isActive: !m.isActive, updatedAt: new Date() }).where(eq(schema.elearningModules.id, m.id));
    await audit({ action: "elearning.module.toggle", userId: ctx.user.id, orgId: ctx.org.id, entityType: "elearning_module", entityId: m.id, before: { isActive: m.isActive }, after: { isActive: !m.isActive } });
    revalidatePath(`/app/${ctx.org.id}/elearning`);
    return { ok: true, message: m.isActive ? "Module désactivé." : "Module activé." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

const progressSchema = z.object({
  moduleId: uuid,
  enrollmentId: uuid,
  minutes: z.preprocess((v) => (v === "" || v == null ? 0 : Number(v)), z.number().int().min(0).max(240)),
  status: z.enum(["non_commence", "en_cours", "termine", "echoue"]).optional(),
  score: z.preprocess((v) => (v === "" || v == null ? undefined : Number(v)), z.number().int().min(0).optional()),
  maxScore: z.preprocess((v) => (v === "" || v == null ? undefined : Number(v)), z.number().int().min(1).optional()),
});

/** Enregistrement manuel (personnel) ou automatique (apprenant sur sa propre inscription) du temps passé : jamais validé automatiquement. */
export async function recordProgressAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = await orgIdOf(formData);
    const d = progressSchema.parse(Object.fromEntries(formData));
    const access = await resolveElearningAccess(orgId, d.moduleId);
    if (!access) return { error: "Accès refusé à ce module." };
    if (access.staff) {
      await requireOrg(orgId, "dossier.pedagogy.manage");
      await assertEnrollmentInScope(access.ctx, d.enrollmentId);
      const [e] = await db.select({ id: schema.enrollments.id }).from(schema.enrollments).where(and(eq(schema.enrollments.id, d.enrollmentId), eq(schema.enrollments.orgId, orgId))).limit(1);
      if (!e) return { error: "Inscription inconnue." };
    } else if (!access.enrollmentIds.includes(d.enrollmentId)) {
      return { error: "Cette inscription n'est pas la vôtre." };
    }
    const row = await upsertProgress(orgId, d.moduleId, d.enrollmentId, { addMinutes: d.minutes, status: d.status, score: d.score ?? null, maxScore: d.maxScore ?? null });
    await audit({ action: "elearning.progress.record", userId: access.ctx.user.id, orgId, entityType: "elearning_progress", entityId: row.id, after: { addMinutes: d.minutes, status: row.status, total: row.timeSpentMinutes } });
    revalidatePath(`/app/${orgId}/elearning`);
    return { ok: true, message: `Temps enregistré : ${row.timeSpentMinutes} min au total (à valider par un responsable avant de compter des heures).` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

/** Validation humaine du temps à distance : seule cette validation permet de compter des heures (F06, autonomie maîtrisée). */
export async function validateProgressAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "dossier.pedagogy.manage");
    if (ctx.trainerOnly) return { error: "La validation du temps à distance revient au responsable pédagogique." };
    const progressId = uuid.parse(formData.get("progressId"));
    const [p] = await db.select().from(schema.elearningProgress).where(and(eq(schema.elearningProgress.id, progressId), eq(schema.elearningProgress.orgId, ctx.org.id))).limit(1);
    if (!p) return { error: "Progression introuvable." };
    await assertEnrollmentInScope(ctx, p.enrollmentId);
    if (p.validatedAt) return { error: "Déjà validée." };
    if (!p.timeSpentMinutes) return { error: "Aucun temps à valider." };
    await db.update(schema.elearningProgress).set({ validatedBy: ctx.user.id, validatedAt: new Date(), updatedAt: new Date() }).where(eq(schema.elearningProgress.id, p.id));
    await audit({ action: "elearning.progress.validate", userId: ctx.user.id, orgId: ctx.org.id, entityType: "elearning_progress", entityId: p.id, after: { minutes: p.timeSpentMinutes } });
    revalidatePath(`/app/${ctx.org.id}/elearning`);
    return { ok: true, message: `${p.timeSpentMinutes} min validées comme temps à distance.` };
  } catch (e) {
    return fail(e, "Validation impossible.");
  }
}
