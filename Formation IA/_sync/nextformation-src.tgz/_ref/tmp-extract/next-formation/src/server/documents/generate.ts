import "server-only";
import { and, asc, desc, eq, inArray, isNull, ne, or } from "drizzle-orm";
import { db, schema } from "@/db";
import { fmtDate } from "@/lib/dates";
import { formatCents } from "@/lib/money";
import { minutesBetween, todayParis } from "@/lib/time";
import type { OrgContext } from "@/server/authz";
import { AuthError } from "@/server/auth";
import { assertEnrollmentInScope, assertSessionInScope } from "@/server/authz";
import { audit } from "@/server/audit";
import { brandFromOrg, orgAddress } from "./brand";
import { renderBrandedDocx, renderBrandedPdf } from "./pdf";
import { renderTemplate, type MissingItem, type RenderData } from "./render";
import { planVersion } from "./rules";
import { createDocument } from "./store";
import { TEMPLATE_VARIABLES, type TemplateQuestion, type TemplateScope } from "./templates-data";

export type GenerateScope = { enrollmentId?: string | null; sessionId?: string | null; companyId?: string | null; personId?: string | null };

export type TemplateRow = typeof schema.documentTemplates.$inferSelect;

type Category = (typeof schema.documentCategoryEnum.enumValues)[number];
type Visibility = (typeof schema.documentVisibilityEnum.enumValues)[number];

const CONTRACT_LABELS: Record<string, string> = {
  convention_formation: "Convention de formation professionnelle",
  contrat_apprentissage: "Contrat d'apprentissage",
  contrat_professionnalisation: "Contrat de professionnalisation",
  contrat_particulier: "Contrat de formation (particulier)",
  cpf: "Compte personnel de formation",
  stage: "Convention de stage",
  autre: "Autre",
};
const SESSION_KIND_LABELS: Record<string, string> = { inter: "Inter-entreprises", intra: "Intra-entreprise", cycle: "Cycle", individuel: "Individuel" };
const MODALITY_LABELS: Record<string, string> = { presentiel: "Présentiel", distanciel: "À distance", mixte: "Mixte (présentiel et distance)", afest: "AFEST", elearning: "E-learning" };
const FUNDER_LABELS: Record<string, string> = {
  opco: "OPCO",
  entreprise: "Entreprise",
  france_travail: "France Travail",
  region: "Conseil régional",
  cpf: "CPF",
  particulier: "Particulier",
  etat: "État",
  agefiph: "Agefiph",
  transition_pro: "Transitions Pro",
  autre: "Autre financeur",
};
const ORG_KIND_LABELS: Record<string, string> = { of: "organisme de formation", cfa: "centre de formation d'apprentis", of_cfa: "organisme de formation et CFA" };

/** Visibilité par défaut du document produit selon le modèle (celle du modèle plateforme sinon la catégorie). */
export const DEFAULT_VISIBILITY: Record<string, Visibility> = {
  // Visibilité par défaut : l'extranet entreprise liste « entreprise », l'extranet apprenant « apprenant » (F09).
  convention: "entreprise",
  contrat: "apprenant",
  cerfa: "administratif",
  certificat_realisation: "entreprise",
  convocation: "apprenant",
  annexe_parcours: "apprenant",
  programme: "entreprise",
  reglement_interieur: "apprenant",
  attestation: "apprenant",
  feuille_emargement: "pedagogie",
  livret: "apprenant",
};

const longDate = (d: string | Date | null | undefined) => (d ? fmtDate(d, "d MMMM yyyy") : undefined);
const hours = (minutes: number) => {
  const h = minutes / 60;
  return Number.isInteger(h) ? String(h) : h.toFixed(1).replace(".", ",");
};
const euros = (cents: number | null | undefined) => (cents === null || cents === undefined ? undefined : formatCents(cents));

function questionsOf(t: TemplateRow): TemplateQuestion[] {
  return Array.isArray(t.questions) ? (t.questions as TemplateQuestion[]) : [];
}

/**
 * Modèles disponibles pour un organisme : modèles plateforme (orgId null) et modèles propres ;
 * un modèle propre portant le même `code` qu'un modèle plateforme le remplace.
 */
export async function listTemplates(orgId: string, opts: { scope?: TemplateScope; includeInactive?: boolean } = {}): Promise<TemplateRow[]> {
  const rows = await db
    .select()
    .from(schema.documentTemplates)
    .where(and(or(isNull(schema.documentTemplates.orgId), eq(schema.documentTemplates.orgId, orgId)), ...(opts.scope ? [eq(schema.documentTemplates.scope, opts.scope)] : [])))
    .orderBy(asc(schema.documentTemplates.category), asc(schema.documentTemplates.title));
  const byCode = new Map<string, TemplateRow>();
  for (const r of rows) {
    if (!opts.includeInactive && !r.isActive) continue;
    const cur = byCode.get(r.code);
    if (!cur || (cur.orgId === null && r.orgId === orgId)) byCode.set(r.code, r);
  }
  return [...byCode.values()];
}

export async function getTemplate(orgId: string, templateCode: string): Promise<TemplateRow | null> {
  const all = await listTemplates(orgId, { includeInactive: true });
  return all.find((t) => t.code === templateCode) ?? null;
}

export type CollectedData = {
  data: RenderData;
  refs: {
    enrollment: typeof schema.enrollments.$inferSelect | null;
    session: typeof schema.trainingSessions.$inferSelect | null;
    person: typeof schema.persons.$inferSelect | null;
    company: typeof schema.companies.$inferSelect | null;
  };
};

/**
 * Collecte les données d'une portée (inscription, session, entreprise, personne) pour un organisme donné.
 * L'identité institutionnelle est celle de `orgId` uniquement : toute entité d'un autre organisme est ignorée.
 */
export async function collectTemplateData(orgId: string, scope: GenerateScope, answers: Record<string, unknown> = {}): Promise<CollectedData> {
  const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  if (!org) throw new Error("Organisme introuvable.");
  const data: RenderData = {
    today: longDate(todayParis()),
    document: { date: longDate(todayParis()) },
    answers,
    org: {
      legalName: org.legalName,
      tradeName: org.tradeName ?? undefined,
      legalForm: org.legalForm ?? undefined,
      siret: org.siret ?? undefined,
      siren: org.siren ?? undefined,
      nda: org.nda ?? undefined,
      ndaRegion: org.ndaRegion ?? undefined,
      uaiCode: org.uaiCode ?? undefined,
      address: orgAddress(org) ?? undefined,
      postalCode: org.postalCode ?? undefined,
      city: org.city ?? undefined,
      email: org.email ?? undefined,
      phone: org.phone ?? undefined,
      website: org.website ?? undefined,
      signatoryName: org.signatoryName ?? undefined,
      signatoryTitle: org.signatoryTitle ?? undefined,
      qualiopiNumber: org.qualiopiNumber ?? undefined,
      qualiopiCertifier: org.qualiopiCertifier ?? undefined,
      kindLabel: ORG_KIND_LABELS[org.kind],
    },
  };
  const refs: CollectedData["refs"] = { enrollment: null, session: null, person: null, company: null };

  let sessionId = scope.sessionId ?? null;
  let companyId = scope.companyId ?? null;
  let personId = scope.personId ?? null;
  let programVersionId: string | null = null;

  if (scope.enrollmentId) {
    const [e] = await db
      .select()
      .from(schema.enrollments)
      .where(and(eq(schema.enrollments.id, scope.enrollmentId), eq(schema.enrollments.orgId, orgId)))
      .limit(1);
    if (!e) throw new Error("Inscription introuvable dans cet organisme.");
    refs.enrollment = e;
    sessionId = e.sessionId;
    companyId = e.companyId ?? companyId;
    personId = e.personId;
    programVersionId = e.programVersionId;
    const att = await attendanceSummary(orgId, e.id);
    const tutor = e.tutorContactId ? (await db.select().from(schema.contacts).where(and(eq(schema.contacts.id, e.tutorContactId), eq(schema.contacts.orgId, orgId))).limit(1))[0] : undefined;
    data.enrollment = {
      reference: e.reference,
      contractKindLabel: CONTRACT_LABELS[e.contractKind],
      contractNumber: e.contractNumber ?? undefined,
      startDate: longDate(e.startDate),
      endDate: longDate(e.endDate),
      hoursPlanned: e.hoursPlanned || undefined,
      price: euros(e.priceCents),
      priceTtc: e.priceCents !== null && e.priceCents !== undefined ? formatCents(Math.round(e.priceCents * 1.2)) : undefined,
      status: e.status,
      hoursDone: att.closedPeriods > 0 ? hours(att.doneMinutes) : undefined,
      hoursJustified: att.closedPeriods > 0 ? hours(att.justifiedMinutes) : undefined,
      absenceHours: att.closedPeriods > 0 ? hours(att.absentMinutes) : undefined,
      tutor: tutor
        ? { fullName: `${tutor.firstName} ${tutor.lastName}`, jobTitle: tutor.jobTitle ?? undefined, email: tutor.email ?? undefined, phone: tutor.phone ?? tutor.mobile ?? undefined }
        : {},
    };
  }

  if (personId) {
    const [p] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, personId), eq(schema.persons.orgId, orgId))).limit(1);
    if (p) {
      refs.person = p;
      const civ = p.civility === "M" ? "Monsieur" : p.civility === "Mme" ? "Madame" : undefined;
      const person = {
        fullName: `${p.firstName} ${p.lastName}`,
        firstName: p.firstName,
        lastName: p.lastName,
        civility: civ,
        birthDate: longDate(p.birthDate),
        birthPlace: p.birthPlace ?? undefined,
        address: orgAddress(p) ?? undefined,
        email: p.email ?? undefined,
        phone: p.phone ?? undefined,
        educationLevel: p.educationLevel ?? undefined,
      };
      data.enrollment = { ...((data.enrollment as Record<string, unknown>) ?? {}), person };
      data.person = person;
      if (!companyId) companyId = p.companyId ?? null;
    }
  }

  if (sessionId) {
    const [s] = await db.select().from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, sessionId), eq(schema.trainingSessions.orgId, orgId))).limit(1);
    if (s) {
      refs.session = s;
      programVersionId = programVersionId ?? s.programVersionId;
      if (!companyId) companyId = s.companyId ?? null;
      const site = s.siteId ? (await db.select().from(schema.sites).where(and(eq(schema.sites.id, s.siteId), eq(schema.sites.orgId, orgId))).limit(1))[0] : undefined;
      const trainers = await db
        .select({ firstName: schema.trainers.firstName, lastName: schema.trainers.lastName })
        .from(schema.sessionTrainers)
        .innerJoin(schema.trainers, eq(schema.trainers.id, schema.sessionTrainers.trainerId))
        .where(and(eq(schema.sessionTrainers.sessionId, s.id), eq(schema.sessionTrainers.orgId, orgId)));
      const sched = { ...(org.settings as Record<string, { start: string; end: string }>), ...(s.schedule as Record<string, { start: string; end: string }>) };
      const planning = await planningList(orgId, s.id);
      const learners = await db
        .select({ firstName: schema.persons.firstName, lastName: schema.persons.lastName })
        .from(schema.enrollments)
        .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
        .where(and(eq(schema.enrollments.sessionId, s.id), eq(schema.enrollments.orgId, orgId), inArray(schema.enrollments.status, ["inscrit", "en_cours", "termine"])))
        .orderBy(asc(schema.persons.lastName), asc(schema.persons.firstName));
      data.session = {
        title: s.title,
        code: s.code,
        startDate: longDate(s.startDate),
        endDate: longDate(s.endDate),
        kindLabel: SESSION_KIND_LABELS[s.kind],
        modalityLabel: MODALITY_LABELS[s.modality] ?? s.modality,
        site: site ? { name: site.name, address: orgAddress({ addressLine1: site.addressLine1, addressLine2: null, postalCode: site.postalCode, city: site.city }) ?? undefined, accessibilityNote: site.accessibilityNote ?? undefined } : {},
        trainers: trainers.length ? trainers.map((t) => `${t.firstName} ${t.lastName}`).join(", ") : undefined,
        planningList: planning.text,
        slotCount: planning.count || undefined,
        learnerList: learners.length ? learners.map((l) => `- ${l.lastName.toUpperCase()} ${l.firstName} : matin ______________________ ; après-midi ______________________`).join("\n") : undefined,
        learnerCount: learners.length,
        scheduleMorning: sched.morning ? `${sched.morning.start} à ${sched.morning.end}` : undefined,
        scheduleAfternoon: sched.afternoon ? `${sched.afternoon.start} à ${sched.afternoon.end}` : undefined,
      };
    }
  }

  if (programVersionId) {
    const [pv] = await db.select().from(schema.programVersions).where(and(eq(schema.programVersions.id, programVersionId), eq(schema.programVersions.orgId, orgId))).limit(1);
    if (pv) {
      const [prog] = await db.select().from(schema.programs).where(eq(schema.programs.id, pv.programId)).limit(1);
      const cert = prog?.certificationId ? (await db.select().from(schema.certifications).where(eq(schema.certifications.id, prog.certificationId)).limit(1))[0] : undefined;
      const mods = await db.select().from(schema.modules).where(eq(schema.modules.programVersionId, pv.id)).orderBy(asc(schema.modules.position));
      data.programVersion = {
        title: prog?.title,
        code: prog?.code,
        version: pv.version,
        objectives: pv.objectives ?? undefined,
        prerequisites: pv.prerequisites ?? undefined,
        audience: pv.audience ?? undefined,
        modalityLabel: MODALITY_LABELS[pv.modality] ?? pv.modality,
        durationHours: pv.durationHours || undefined,
        durationDays: pv.durationDays ?? undefined,
        companyHours: pv.companyHours || undefined,
        remoteHours: pv.remoteHours || undefined,
        content: pv.content ?? undefined,
        methods: pv.methods ?? undefined,
        evaluationMethods: pv.evaluationMethods ?? undefined,
        resources: pv.resources ?? undefined,
        accessibility: pv.accessibility ?? undefined,
        accessDelay: pv.accessDelay ?? undefined,
        price: pv.priceCents !== null && pv.priceCents !== undefined ? `${formatCents(pv.priceCents)} HT${pv.priceNote ? ` (${pv.priceNote})` : ""}` : (pv.priceNote ?? undefined),
        certification: cert ? `${cert.title}${cert.rncpCode ? ` (RNCP ${cert.rncpCode})` : ""}` : undefined,
        modulesList: mods.length ? mods.map((m) => `- ${m.title}${m.hours ? ` (${m.hours} h)` : ""}${m.description ? ` : ${m.description}` : ""}`).join("\n") : undefined,
        trainerProfile: pv.trainerProfile ?? undefined,
      };
    }
  }

  if (companyId) {
    const [c] = await db.select().from(schema.companies).where(and(eq(schema.companies.id, companyId), eq(schema.companies.orgId, orgId))).limit(1);
    if (c) {
      refs.company = c;
      const [sig] = await db
        .select()
        .from(schema.contacts)
        .where(and(eq(schema.contacts.companyId, c.id), eq(schema.contacts.orgId, orgId), eq(schema.contacts.isSignatory, true)))
        .limit(1);
      data.company = {
        name: c.name,
        siret: c.siret ?? undefined,
        siren: c.siren ?? undefined,
        address: orgAddress(c) ?? undefined,
        opco: c.opco ?? undefined,
        idcc: c.idcc ?? undefined,
        email: c.email ?? undefined,
        phone: c.phone ?? undefined,
        signatory: sig ? { fullName: `${sig.firstName} ${sig.lastName}`, jobTitle: sig.jobTitle ?? undefined, email: sig.email ?? undefined } : {},
      };
    }
  }

  if (refs.enrollment) {
    const [f] = await db
      .select({ f: schema.fundings, funderName: schema.funders.name })
      .from(schema.fundings)
      .leftJoin(schema.funders, eq(schema.funders.id, schema.fundings.funderId))
      .where(and(eq(schema.fundings.enrollmentId, refs.enrollment.id), eq(schema.fundings.orgId, orgId), ne(schema.fundings.status, "annule")))
      .orderBy(desc(schema.fundings.amountCents))
      .limit(1);
    if (f) {
      data.funding = {
        label: f.f.label,
        amount: euros(f.f.amountCents),
        kindLabel: FUNDER_LABELS[f.f.kind],
        funderName: f.funderName ?? FUNDER_LABELS[f.f.kind],
        agreementRef: f.f.agreementRef ?? undefined,
        agreementDate: longDate(f.f.agreementDate),
      };
    }
  }
  return { data, refs };
}

/** Heures effectuées / justifiées / absences sur les périodes clôturées uniquement (jamais additionnées entre elles). */
async function attendanceSummary(orgId: string, enrollmentId: string) {
  const rows = await db
    .select({ status: schema.attendances.status, minutes: schema.attendances.minutesCounted, start: schema.periods.startTime, end: schema.periods.endTime, brk: schema.periods.breakMinutes })
    .from(schema.attendances)
    .innerJoin(schema.periods, eq(schema.periods.id, schema.attendances.periodId))
    .where(and(eq(schema.attendances.orgId, orgId), eq(schema.attendances.enrollmentId, enrollmentId), eq(schema.attendances.isCurrent, true), eq(schema.periods.status, "cloturee")));
  let doneMinutes = 0;
  let justifiedMinutes = 0;
  let absentMinutes = 0;
  for (const r of rows) {
    const duration = Math.max(0, minutesBetween(r.start.slice(0, 5), r.end.slice(0, 5)) - r.brk);
    if (r.status === "absent_justifie" || r.status === "excuse") justifiedMinutes += duration;
    else if (r.status === "absent") absentMinutes += duration;
    else doneMinutes += r.minutes;
  }
  return { closedPeriods: rows.length, doneMinutes, justifiedMinutes, absentMinutes };
}

const PART_LABELS: Record<string, string> = { matin: "matin", apres_midi: "après-midi", journee: "journée", soir: "soir" };

/** Liste Markdown des séances planifiées (annexe de parcours), une ligne par séance. */
async function planningList(orgId: string, sessionId: string): Promise<{ text: string | undefined; count: number }> {
  const slots = await db
    .select({ slot: schema.slots, room: schema.rooms.name, site: schema.sites.name, trainerFirst: schema.trainers.firstName, trainerLast: schema.trainers.lastName })
    .from(schema.slots)
    .leftJoin(schema.rooms, eq(schema.rooms.id, schema.slots.roomId))
    .leftJoin(schema.sites, eq(schema.sites.id, schema.slots.siteId))
    .leftJoin(schema.trainers, eq(schema.trainers.id, schema.slots.trainerId))
    .where(and(eq(schema.slots.orgId, orgId), eq(schema.slots.sessionId, sessionId), ne(schema.slots.status, "annulee")))
    .orderBy(asc(schema.slots.date));
  if (!slots.length) return { text: undefined, count: 0 };
  const periods = await db
    .select({ slotId: schema.periods.slotId, part: schema.periods.part, start: schema.periods.startTime, end: schema.periods.endTime, status: schema.periods.status })
    .from(schema.periods)
    .where(and(eq(schema.periods.orgId, orgId), inArray(schema.periods.slotId, slots.map((s) => s.slot.id)), ne(schema.periods.status, "annulee")))
    .orderBy(asc(schema.periods.startTime));
  const byslot = new Map<string, typeof periods>();
  for (const p of periods) byslot.set(p.slotId, [...(byslot.get(p.slotId) ?? []), p]);
  const lines = slots.map((s) => {
    const ps = byslot.get(s.slot.id) ?? [];
    const parts = ps.length ? ps.map((p) => `${PART_LABELS[p.part] ?? p.part} ${p.start.slice(0, 5)} à ${p.end.slice(0, 5)}`).join(", ") : "horaires à confirmer";
    const where = [s.site, s.room].filter(Boolean).join(", ");
    const who = s.trainerFirst ? `${s.trainerFirst} ${s.trainerLast}` : null;
    return `- ${fmtDate(s.slot.date, "EEEE d MMMM yyyy")} : ${parts}${s.slot.title ? ` ; ${s.slot.title}` : ""}${where ? ` ; ${where}` : ""}${who ? ` ; formateur : ${who}` : ""}`;
  });
  return { text: lines.join("\n"), count: slots.length };
}

export type PreviewResult = { template: TemplateRow; text: string; missing: MissingItem[]; refs: CollectedData["refs"]; questions: TemplateQuestion[] };

/** Rendu Markdown avec marqueurs, sans enregistrement : sert à afficher les données manquantes avant génération. */
export async function previewDocument(input: { orgId: string; templateCode: string; scope: GenerateScope; answers?: Record<string, unknown> }): Promise<PreviewResult> {
  const template = await getTemplate(input.orgId, input.templateCode);
  if (!template || !template.isActive) throw new Error("Modèle introuvable ou désactivé.");
  const collected = await collectTemplateData(input.orgId, input.scope, input.answers ?? {});
  const labels = { ...TEMPLATE_VARIABLES };
  for (const q of questionsOf(template)) labels[`answers.${q.key}`] = q.label;
  const { text, missing } = renderTemplate(template.body, collected.data, { labels });
  return { template, text, missing, refs: collected.refs, questions: questionsOf(template) };
}

export type GenerateResult = {
  document: typeof schema.documents.$inferSelect;
  docx: typeof schema.documents.$inferSelect;
  missing: MissingItem[];
  version: number;
  keptLockedPrevious: boolean;
};

/**
 * Génère un document depuis un modèle : rend le Markdown, produit le PDF (charte de l'organisme de l'inscription)
 * et le DOCX, enregistre les deux lignes `documents` (statut `genere`, jamais « signé »), gère les versions :
 * un document de même modèle et même portée est remplacé (archivé) sauf s'il est signé ou validé, auquel cas
 * les deux versions restent listées.
 */
export async function generateDocument(input: {
  ctx: OrgContext;
  templateCode: string;
  scope: GenerateScope;
  answers?: Record<string, unknown>;
  /** Permet d'enregistrer un rendu édité manuellement (texte final). */
  overrideText?: string | null;
  visibility?: Visibility;
}): Promise<GenerateResult> {
  const { ctx } = input;
  if (!ctx.permissions.has("documents.generate")) throw new AuthError("forbidden");
  const orgId = ctx.org.id;
  if (input.scope.enrollmentId) await assertEnrollmentInScope(ctx, input.scope.enrollmentId);
  if (input.scope.sessionId) await assertSessionInScope(ctx, input.scope.sessionId);
  const preview = await previewDocument({ orgId, templateCode: input.templateCode, scope: input.scope, answers: input.answers });
  const text = input.overrideText?.trim() ? input.overrideText : preview.text;
  const template = preview.template;
  const { refs } = preview;

  const enrollmentId = refs.enrollment?.id ?? null;
  const sessionId = refs.session?.id ?? null;
  const personId = refs.person?.id ?? null;
  const companyId = refs.company?.id ?? null;

  // Version précédente : même modèle, même portée principale, dans cet organisme (hors DOCX dérivé et archives).
  const scopeCond = enrollmentId
    ? eq(schema.documents.enrollmentId, enrollmentId)
    : sessionId
      ? and(eq(schema.documents.sessionId, sessionId), isNull(schema.documents.enrollmentId))!
      : companyId
        ? and(eq(schema.documents.companyId, companyId), isNull(schema.documents.enrollmentId))!
        : personId
          ? and(eq(schema.documents.personId, personId), isNull(schema.documents.enrollmentId))!
          : isNull(schema.documents.enrollmentId);
  const [previous] = await db
    .select({ id: schema.documents.id, version: schema.documents.version, status: schema.documents.status })
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.templateCode, template.code), scopeCond, isNull(schema.documents.sourceType), ne(schema.documents.status, "archive")))
    .orderBy(desc(schema.documents.version))
    .limit(1);
  const plan = planVersion(previous ?? null);

  const brand = await brandFromOrg(ctx.org);
  const reference = refs.enrollment?.reference ?? refs.session?.code ?? null;
  const title = `${template.title}${refs.person ? ` : ${refs.person.firstName} ${refs.person.lastName}` : refs.session ? ` : ${refs.session.title}` : refs.company ? ` : ${refs.company.name}` : ""}`;
  const [pdf, docxBuf] = await Promise.all([renderBrandedPdf(text, { title, brand, reference }), renderBrandedDocx(text, { title, brand, reference })]);
  const base = `${template.code}-${(reference ?? "document").replace(/[^a-zA-Z0-9-]/g, "_")}-v${plan.version}`;
  const visibility = input.visibility ?? DEFAULT_VISIBILITY[template.category] ?? "interne";
  const generationData = {
    templateId: template.id,
    templateVersion: template.version,
    scope: { enrollmentId, sessionId, personId, companyId },
    answers: input.answers ?? {},
    missing: preview.missing,
    text,
    generatedAt: new Date().toISOString(),
    generatedBy: ctx.user.id,
    orgId,
  };
  const common = { orgId, enrollmentId, sessionId, personId, companyId, category: template.category as Category, visibility, status: "genere" as const, templateCode: template.code, uploadedBy: ctx.user.id, isDemo: ctx.org.isDemo };
  const document = await createDocument({
    ...common,
    title,
    fileName: `${base}.pdf`,
    mimeType: "application/pdf",
    data: pdf,
    generationData,
    previousVersionId: plan.previousVersionId,
  });
  const docx = await createDocument({
    ...common,
    title: `${title} (Word)`,
    fileName: `${base}.docx`,
    mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    data: docxBuf,
    generationData: { pdfDocumentId: document.id },
    sourceType: "docx_of",
    sourceId: document.id,
  });
  if (plan.archivePrevious && previous) {
    await db.update(schema.documents).set({ status: "archive" }).where(and(eq(schema.documents.id, previous.id), eq(schema.documents.orgId, orgId)));
    await db.update(schema.documents).set({ status: "archive" }).where(and(eq(schema.documents.sourceType, "docx_of"), eq(schema.documents.sourceId, previous.id), eq(schema.documents.orgId, orgId)));
  }
  await audit({
    action: "document.generate",
    userId: ctx.user.id,
    orgId,
    entityType: "document",
    entityId: document.id,
    after: { templateCode: template.code, version: document.version, previousVersionId: plan.previousVersionId, keptLockedPrevious: Boolean(previous && !plan.archivePrevious), missing: preview.missing.map((m) => m.key) },
  });
  return { document, docx, missing: preview.missing, version: document.version, keptLockedPrevious: Boolean(previous && !plan.archivePrevious) };
}
