import "server-only";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { REGISTRY_ROWS } from "./data";

/** Charge le registre des traitements. Idempotent par nom : une ligne existante n'est modifiée que si `overwrite`. */
export async function seedRegistry(opts: { overwrite?: boolean } = {}): Promise<{ inserted: number; updated: number; total: number }> {
  let inserted = 0;
  let updated = 0;
  for (const row of REGISTRY_ROWS) {
    const [existing] = await db.select({ id: schema.processingRegistry.id }).from(schema.processingRegistry).where(eq(schema.processingRegistry.name, row.name)).limit(1);
    if (!existing) {
      await db.insert(schema.processingRegistry).values(row);
      inserted++;
    } else if (opts.overwrite) {
      await db.update(schema.processingRegistry).set(row).where(eq(schema.processingRegistry.id, existing.id));
      updated++;
    }
  }
  return { inserted, updated, total: REGISTRY_ROWS.length };
}
