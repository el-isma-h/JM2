"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requirePlatformAdmin } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { hit, tooManyMessage } from "@/server/rate-limit";
import { deletePlatformSecret, PLATFORM_SECRET_KEYS, secretDef, setPlatformSecret } from "@/server/platform/secrets";
import { complete, DEFAULT_MODELS, PROVIDER_LABELS } from "@/server/ai/provider";
import type { ActionState } from "./auth";

/** 30 opérations (enregistrement, suppression, test) par administrateur et par 10 minutes. */
const RULE = { limit: 30, windowSeconds: 10 * 60 };

const keySchema = z.string().refine((k) => PLATFORM_SECRET_KEYS.includes(k), "Clé non autorisée.");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

async function guard() {
  const admin = await requirePlatformAdmin();
  const rl = await hit("admin:secrets", admin.id, RULE);
  if (!rl.ok) return { admin, limited: tooManyMessage(rl) };
  return { admin, limited: null };
}

export async function setPlatformSecretAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const { admin, limited } = await guard();
    if (limited) return { error: limited };
    const key = keySchema.parse(formData.get("key"));
    const value = z.string().trim().min(1, "Saisissez une valeur.").max(4000, "Valeur trop longue.").parse(formData.get("value"));
    const r = await setPlatformSecret(key, value, admin.id);
    revalidatePath("/admin/cles-api");
    revalidatePath("/admin/integrations");
    return { ok: true, message: r.message };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}

export async function deletePlatformSecretAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const { admin, limited } = await guard();
    if (limited) return { error: limited };
    const key = keySchema.parse(formData.get("key"));
    const r = await deletePlatformSecret(key, admin.id);
    revalidatePath("/admin/cles-api");
    revalidatePath("/admin/integrations");
    return r.deleted ? { ok: true, message: r.message } : { error: r.message };
  } catch (e) {
    return fail(e, "Suppression impossible.");
  }
}

/** Test d'une clé active (process.env) : petit appel au fournisseur IA, ou lecture des domaines Resend. Aucun e-mail n'est envoyé. */
export async function testPlatformSecretAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const { admin, limited } = await guard();
    if (limited) return { error: limited };
    const key = keySchema.parse(formData.get("key"));
    const def = secretDef(key);
    const value = process.env[key]?.trim();
    if (!value) return { error: `${key} n'est pas définie : enregistrez-la d'abord.` };
    let result: ActionState;
    if (def?.provider) {
      const p = def.provider;
      const modelVar = { anthropic: "ANTHROPIC_MODEL", openai: "OPENAI_MODEL", xai: "XAI_MODEL" }[p];
      // Environnement réduit à ce seul fournisseur : on teste exactement cette clé, pas le premier fournisseur configuré.
      const env = { [key]: value, [modelVar]: process.env[modelVar], OPENAI_BASE_URL: process.env.OPENAI_BASE_URL, AI_PROVIDER: p };
      try {
        const r = await complete({ system: "Test de connexion. Réponds uniquement par le mot OK.", messages: [{ role: "user", content: "Test" }], maxTokens: 10, temperature: 0 }, env);
        result = { ok: true, message: `${PROVIDER_LABELS[p]} répond (modèle ${r.model || DEFAULT_MODELS[p]}).` };
      } catch (e) {
        result = { error: `${PROVIDER_LABELS[p]} : échec du test. ${(e instanceof Error ? e.message : String(e)).replace(value, "••••").slice(0, 300)}` };
      }
    } else if (key === "RESEND_API_KEY") {
      try {
        const res = await fetch("https://api.resend.com/domains", { headers: { Authorization: `Bearer ${value}` }, signal: AbortSignal.timeout(10_000) });
        const body = (await res.json().catch(() => ({}))) as { data?: { name?: string; status?: string }[]; name?: string; message?: string };
        if (res.ok) {
          const domains = body.data ?? [];
          const verified = domains.filter((d) => d.status === "verified").map((d) => d.name);
          result = { ok: true, message: `Clé Resend valide : ${domains.length} domaine(s), ${verified.length ? `vérifié(s) : ${verified.join(", ")}` : "aucun vérifié (MAIL_FROM doit utiliser un domaine vérifié)"}.` };
        } else if (body.name === "restricted_api_key") {
          result = { ok: true, message: "Clé Resend valide (accès limité à l'envoi : la liste des domaines n'est pas lisible). Aucun e-mail n'a été envoyé." };
        } else {
          result = { error: `Resend refuse la clé (réponse ${res.status}${body.message ? ` : ${body.message}` : ""}).` };
        }
      } catch (e) {
        result = { error: `Resend injoignable : ${e instanceof Error ? e.message : String(e)}` };
      }
    } else {
      return { error: "Aucun test disponible pour ce réglage." };
    }
    await audit({ action: "platform.secret.test", userId: admin.id, entityType: "platform_secret", after: { key, ok: Boolean(result.ok) } });
    return result;
  } catch (e) {
    return fail(e, "Test impossible.");
  }
}
