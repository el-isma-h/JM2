import { describe, expect, it } from "vitest";
import { permissionsForRoles } from "../../authz";
import { canAdministerSecurity, canReceiveOwnership, normalizePermissionOverrides, normalizeRoles } from "../rules";

describe("canAdministerSecurity (S01)", () => {
  it("accepte le propriétaire actif", () => {
    const permissions = permissionsForRoles(["direction"]);
    expect(canAdministerSecurity({ isOwner: true, roles: ["direction"], permissions, membership: { active: true, expiresAt: null } })).toBe(true);
  });

  it("refuse un membre avec users.manage accordé en permission fine sans être propriétaire", () => {
    const permissions = permissionsForRoles(["direction"], { "users.manage": true, "roles.manage": true, "audit.view": true });
    expect(permissions.has("users.manage")).toBe(true);
    expect(canAdministerSecurity({ isOwner: false, roles: ["direction"], permissions, membership: { active: true, expiresAt: null } })).toBe(false);
  });

  it("refuse le cumul « Nathalie » (trainer + agency_manager + pedagogy_manager + finance.view)", () => {
    const roles = ["trainer", "agency_manager", "pedagogy_manager"] as const;
    const permissions = permissionsForRoles([...roles], { "finance.view": true });
    // La supervision opérationnelle est conservée…
    expect(permissions.has("tasks.view_all")).toBe(true);
    expect(permissions.has("dossier.internal.view")).toBe(true);
    expect(permissions.has("finance.view")).toBe(true);
    // … mais jamais l'administration de la sécurité.
    expect(canAdministerSecurity({ isOwner: false, roles: [...roles], permissions, membership: { active: true, expiresAt: null } })).toBe(false);
  });

  it("refuse un propriétaire expiré ou inactif", () => {
    const permissions = permissionsForRoles(["direction"]);
    const past = new Date(Date.now() - 1000);
    expect(canAdministerSecurity({ isOwner: true, roles: ["direction"], permissions, membership: { active: true, expiresAt: past } })).toBe(false);
    expect(canAdministerSecurity({ isOwner: true, roles: ["direction"], permissions, membership: { active: false, expiresAt: null } })).toBe(false);
  });

  it("refuse l'administrateur plateforme non propriétaire", () => {
    const permissions = permissionsForRoles(["direction"]);
    expect(canAdministerSecurity({ isOwner: false, roles: ["direction"], permissions, membership: null, isPlatformAdmin: true })).toBe(false);
  });
});

describe("normalisation des rôles et permissions fines", () => {
  it("ne conserve que les rôles attribuables, sans doublon", () => {
    expect(normalizeRoles(["direction", "learner", "direction", "inconnu", "finance"])).toEqual(["direction", "finance"]);
  });
  it("rejette les permissions propriétaire", () => {
    const r = normalizePermissionOverrides({ "finance.view": "true", "users.manage": "true", "audit.view": "false", "candidates.cv.view": "false", "x.y": "true" });
    expect(r.overrides).toEqual({ "finance.view": true, "candidates.cv.view": false });
    expect(r.rejected.sort()).toEqual(["audit.view", "users.manage"]);
  });
});

describe("transfert de propriété", () => {
  const now = new Date("2026-10-23T10:00:00Z");
  it("refuse le propriétaire courant, un membre inactif, expiré ou extranet", () => {
    expect(canReceiveOwnership({ userId: "a", active: true, expiresAt: null, roles: ["direction"] }, "a", now).ok).toBe(false);
    expect(canReceiveOwnership({ userId: "b", active: false, expiresAt: null, roles: ["direction"] }, "a", now).ok).toBe(false);
    expect(canReceiveOwnership({ userId: "b", active: true, expiresAt: new Date("2026-01-01"), roles: ["direction"] }, "a", now).ok).toBe(false);
    expect(canReceiveOwnership({ userId: "b", active: true, expiresAt: null, roles: ["learner"] }, "a", now).ok).toBe(false);
  });
  it("accepte un membre actif", () => {
    expect(canReceiveOwnership({ userId: "b", active: true, expiresAt: null, roles: ["admin_staff"] }, "a", now)).toEqual({ ok: true });
  });
});
