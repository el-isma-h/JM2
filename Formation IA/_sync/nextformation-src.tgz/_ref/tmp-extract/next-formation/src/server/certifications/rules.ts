/**
 * Règles pures des certifications externes (TOSA, ICDL, TOEIC, Certificat Voltaire, CléA).
 * Process de la cliente : Certificat Voltaire uniquement en centre, à commander et organiser au moins 15 jours
 * avant la date souhaitée ; pour les autres certificateurs, l'inscription se fait sur la plateforme du certificateur
 * avant la fin de la formation. Aucun identifiant de plateforme n'est jamais stocké.
 */
import { addDays, format, parseISO } from "date-fns";

export const CERTIFIERS = ["tosa", "icdl", "toeic", "voltaire", "clea", "autre"] as const;
export type Certifier = (typeof CERTIFIERS)[number];

export const CERT_STATUSES = ["a_inscrire", "compte_cree", "inscrit", "voucher_envoye", "session_planifiee", "passee", "reussie", "echouee", "annulee"] as const;
export type CertStatus = (typeof CERT_STATUSES)[number];

export const CERTIFIER_LABELS: Record<Certifier, string> = {
  tosa: "TOSA",
  icdl: "ICDL",
  toeic: "TOEIC",
  voltaire: "Certificat Voltaire",
  clea: "CléA",
  autre: "Autre certificateur",
};

export const CERT_STATUS_LABELS: Record<CertStatus, string> = {
  a_inscrire: "À inscrire",
  compte_cree: "Compte candidat créé",
  inscrit: "Inscrit",
  voucher_envoye: "Voucher envoyé",
  session_planifiee: "Session planifiée",
  passee: "Passée (résultat attendu)",
  reussie: "Réussie",
  echouee: "Échouée",
  annulee: "Annulée",
};

/** Statuts terminaux : plus aucune alerte. */
export const FINAL_CERT_STATUSES: CertStatus[] = ["reussie", "echouee", "annulee"];
/** Statuts antérieurs à l'organisation de la session d'examen (alerte Voltaire J-15). */
export const PRE_PLANNING_STATUSES: CertStatus[] = ["a_inscrire", "compte_cree", "inscrit", "voucher_envoye"];

export const ALERT_DAYS_BEFORE = 15;

/** Valeur libre `programs.externalCertifier` (ex. « tosa », « TOSA », « Certificat Voltaire ») → certificateur connu. */
export function normalizeCertifier(raw: string | null | undefined): Certifier | null {
  if (!raw) return null;
  const v = raw.trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  if (!v) return null;
  if (v.includes("tosa")) return "tosa";
  if (v.includes("icdl")) return "icdl";
  if (v.includes("toeic")) return "toeic";
  if (v.includes("voltaire")) return "voltaire";
  if (v.includes("clea")) return "clea";
  return "autre";
}

export function minusDays(iso: string, n: number): string {
  return format(addDays(parseISO(iso), -n), "yyyy-MM-dd");
}

export type CertAlert = { kind: "voltaire_j15"; due: string } | { kind: "a_inscrire_j15"; due: string } | null;

/**
 * Alerte à créer pour une inscription à la certification, à la date `today` :
 *  - Voltaire avec date d'examen : à partir de J-15 si la session n'est pas encore organisée ;
 *  - autres certificateurs (et Voltaire sans date d'examen) : statut encore « à inscrire » à J-15 de la fin de session.
 */
export function certificationAlert(input: { certifier: Certifier; status: CertStatus; examDate: string | null; sessionEndDate: string | null; today: string }): CertAlert {
  if (FINAL_CERT_STATUSES.includes(input.status)) return null;
  if (input.certifier === "voltaire" && input.examDate) {
    const from = minusDays(input.examDate, ALERT_DAYS_BEFORE);
    if (input.today >= from && PRE_PLANNING_STATUSES.includes(input.status)) return { kind: "voltaire_j15", due: from };
    return null;
  }
  if (input.status === "a_inscrire" && input.sessionEndDate) {
    const from = minusDays(input.sessionEndDate, ALERT_DAYS_BEFORE);
    if (input.today >= from) return { kind: "a_inscrire_j15", due: from };
  }
  return null;
}

/**
 * Garde-fou : aucun identifiant ni mot de passe de plateforme certificateur dans les champs libres.
 * Retourne un message d'erreur si le texte ressemble à des identifiants de connexion.
 */
export function credentialLeak(text: string | null | undefined): string | null {
  if (!text) return null;
  const t = text.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  if (/(mot\s*de\s*passe|password|passwd|\bmdp\b|\bpwd\b|login\s*[:=]|identifiant\s*[:=]|\buser(name)?\s*[:=])/.test(t)) {
    return "N'enregistrez jamais d'identifiant ni de mot de passe de plateforme certificateur : ils restent dans le coffre de l'organisme.";
  }
  return null;
}
