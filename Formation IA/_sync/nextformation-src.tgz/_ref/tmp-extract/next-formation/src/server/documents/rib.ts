import "server-only";
import { and, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { decrypt, maskIban } from "@/lib/crypto";
import { formatIbanGroups } from "@/lib/validators";
import type { OrgContext } from "@/server/authz";
import { canManageRib, canViewRib } from "./rules";

export { canManageRib, canViewRib };

export const RIB_SOURCE_TYPE = "org_rib";

/**
 * F12 : lien du dossier financier vers le RIB central selon les droits :
 * « Gérer le RIB central » (propriétaire ou finance.manage), « Consulter le RIB central » (finance.view), null sinon.
 */
export function ribLinkLabel(ctx: OrgContext): { label: string; href: string; mode: "manage" | "view" } | null {
  const href = `/app/${ctx.org.id}/finance/rib`;
  if (canManageRib(ctx)) return { label: "Gérer le RIB central", href, mode: "manage" };
  if (canViewRib(ctx)) return { label: "Consulter le RIB central", href, mode: "view" };
  return null;
}

/** Document RIB courant de l'organisme (catégorie rib, sourceType org_rib, sourceId = orgId), hors archives. */
export async function getRibDocument(orgId: string) {
  const [doc] = await db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.category, "rib"), eq(schema.documents.sourceType, RIB_SOURCE_TYPE), eq(schema.documents.sourceId, orgId)))
    .orderBy(desc(schema.documents.version), desc(schema.documents.createdAt))
    .limit(1);
  return doc && doc.status !== "archive" ? doc : null;
}

/** Historique complet (versions, archives) du RIB central. */
export async function listRibHistory(orgId: string) {
  return db
    .select()
    .from(schema.documents)
    .where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.category, "rib"), eq(schema.documents.sourceType, RIB_SOURCE_TYPE), eq(schema.documents.sourceId, orgId)))
    .orderBy(desc(schema.documents.createdAt));
}

export type RibDetails = { ibanMasked: string | null; ibanFull: string | null; bic: string | null; holder: string | null };

/** Coordonnées bancaires : IBAN masqué (toujours), IBAN complet uniquement si `reveal` (lecture auditée par l'appelant). */
export function ribDetails(org: Pick<typeof schema.organismes.$inferSelect, "ribIbanEnc" | "ribIbanLast4" | "ribBic" | "ribHolder">, reveal = false): RibDetails {
  let ibanFull: string | null = null;
  if (reveal && org.ribIbanEnc) {
    try {
      ibanFull = formatIbanGroups(decrypt(org.ribIbanEnc, "rib"));
    } catch {
      ibanFull = null;
    }
  }
  return { ibanMasked: org.ribIbanLast4 ? maskIban(org.ribIbanLast4) : null, ibanFull, bic: org.ribBic, holder: org.ribHolder };
}
