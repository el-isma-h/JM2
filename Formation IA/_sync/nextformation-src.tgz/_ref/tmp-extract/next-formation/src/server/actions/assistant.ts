"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { requireOrg } from "@/server/authz";
import { audit } from "@/server/audit";
import { authErrorMessage } from "@/server/guard";
import { createConversation, getConversation, listMessages, runAssistantTurn } from "@/server/ai/assistant";
import { isAgentName, runAgent } from "@/server/ai/agents";
import { applyProposal, refuseProposal } from "@/server/ai/apply";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

const entitySchema = z.object({
  entityType: z.string().trim().max(40).optional().or(z.literal("")),
  entityId: uuid.optional().or(z.literal("")),
});

/** Envoi d'un message à l'assistant : crée la conversation au besoin, enregistre question et réponse, redirige vers la conversation. */
export async function sendAssistantMessageAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target: string | null = null;
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId);
    const content = z.string().trim().min(2, "Écrivez une question.").max(4000, "4000 caractères maximum").parse(formData.get("content"));
    const ent = entitySchema.parse({ entityType: formData.get("entityType") ?? "", entityId: formData.get("entityId") ?? "" });
    const context = { entityType: ent.entityType || null, entityId: ent.entityId || null };
    const rawConv = formData.get("conversationId");
    let conv = typeof rawConv === "string" && rawConv ? await getConversation(ctx, rawConv) : null;
    if (!conv) conv = await createConversation(ctx, context, content);
    const history = await listMessages(conv.id);
    await db.insert(schema.assistantMessages).values({ conversationId: conv.id, role: "user", content });
    const turn = await runAssistantTurn(ctx, (conv.context as { entityType?: string | null; entityId?: string | null }) ?? context, history, content);
    await db.insert(schema.assistantMessages).values({ conversationId: conv.id, role: "assistant", content: turn.text, meta: turn.meta, provider: turn.provider, model: turn.model });
    await db.update(schema.assistantConversations).set({ updatedAt: new Date() }).where(eq(schema.assistantConversations.id, conv.id));
    await audit({ action: "ai.assistant.message", userId: ctx.user.id, orgId: ctx.org.id, entityType: "assistant_conversation", entityId: conv.id, after: { provider: turn.provider, tools: (turn.meta as { tools?: unknown }).tools } });
    target = `/app/${orgId}/assistant?c=${conv.id}`;
  } catch (e) {
    return fail(e, "L'assistant n'a pas pu répondre.");
  }
  revalidatePath(target);
  redirect(target);
}

/** Déclenche un agent sur une entité : la proposition est créée (statut proposée) et l'écran des propositions s'ouvre. */
export async function proposeAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  let target: string | null = null;
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId);
    const agent = formData.get("agent");
    if (!isAgentName(agent)) return { error: "Agent inconnu." };
    const ent = entitySchema.parse({ entityType: formData.get("entityType") ?? "", entityId: formData.get("entityId") ?? "" });
    const params: Record<string, string> = {};
    for (const [k, v] of formData.entries()) if (k.startsWith("param_") && typeof v === "string") params[k.slice(6)] = v;
    const row = await runAgent(ctx, agent, { entityType: ent.entityType || null, entityId: ent.entityId || null, params });
    const back = typeof formData.get("back") === "string" ? String(formData.get("back")) : "";
    target = `/app/${orgId}/assistant/propositions?p=${row.id}${back && back.startsWith("/") ? `&back=${encodeURIComponent(back)}` : ""}`;
  } catch (e) {
    return fail(e, "L'agent n'a pas pu produire de proposition.");
  }
  revalidatePath(target);
  redirect(target);
}

/** Décision humaine sur une proposition : validation (et application immédiate) ou refus motivé. */
export async function decideProposalAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const orgId = uuid.parse(formData.get("orgId"));
    const ctx = await requireOrg(orgId);
    const proposalId = uuid.parse(formData.get("proposalId"));
    const decision = z.enum(["valider", "refuser"]).parse(formData.get("decision"));
    const note = z.string().trim().max(1000).optional().parse(formData.get("note") ?? undefined) ?? "";
    const result = decision === "valider" ? await applyProposal(ctx, proposalId, note) : await refuseProposal(ctx, proposalId, note);
    revalidatePath(`/app/${orgId}/assistant/propositions`);
    revalidatePath(`/app/${orgId}/assistant`);
    if (!result.ok) return { error: result.reason };
    return { ok: true, message: result.message, data: result.href ? { href: result.href } : undefined };
  } catch (e) {
    return fail(e, "La décision n'a pas pu être enregistrée.");
  }
}
