import { describe, expect, it } from "vitest";
import { generateCalendar } from "../agents/calendar";

const parts = [
  { part: "matin" as const, start: "09:00", end: "12:00" },
  { part: "apres_midi" as const, start: "14:00", end: "17:00" },
];

describe("generateCalendar : calendrier proposé sans écriture", () => {
  it("programme des journées de 6 h (3 h + 3 h), jours fériés et fermetures exclus, jusqu'à la durée cible", () => {
    const r = generateCalendar({ startDate: "2026-05-04", endDate: "2026-05-29", targetMinutes: 18 * 60, weekdays: [1, 2, 3, 4, 5], parts, closures: [{ startDate: "2026-05-05", endDate: "2026-05-05", reason: "pont" }], unavailabilities: [], holidays: ["2026-05-08"] });
    expect(r.plannedMinutes).toBe(18 * 60);
    expect(r.slots.map((s) => s.date)).toEqual(["2026-05-04", "2026-05-06", "2026-05-07"]);
    expect(r.skipped).toEqual([{ date: "2026-05-05", reason: "fermeture : pont" }]);
  });
  it("saute la période où le formateur est indisponible et s'arrête à la demi-journée", () => {
    const r = generateCalendar({ startDate: "2026-05-04", endDate: "2026-05-08", targetMinutes: 9 * 60, weekdays: [1, 2, 3, 4, 5], parts, closures: [], unavailabilities: [{ startDate: "2026-05-04", endDate: "2026-05-04", part: "matin", reason: "jury" }], holidays: [] });
    expect(r.slots).toEqual([
      { date: "2026-05-04", parts: ["apres_midi"] },
      { date: "2026-05-05", parts: ["matin", "apres_midi"] },
    ]);
    expect(r.plannedMinutes).toBe(9 * 60);
    expect(r.skipped[0].reason).toMatch(/indisponible/);
  });
});
