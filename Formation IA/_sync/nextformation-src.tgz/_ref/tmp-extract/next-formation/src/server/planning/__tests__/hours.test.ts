import { describe, expect, it } from "vitest";
import { aggregateHours, canCloseOrSign, canEditDirectly, canPrepare, canRecordAttendance, countedMinutes, isFutureDate, periodMinutes, type AttendanceLike, type PeriodLike } from "../hours";

const matin: PeriodLike = { id: "m", startTime: "09:00", endTime: "12:00", breakMinutes: 0, status: "prevue" };
const apresMidi: PeriodLike = { id: "a", startTime: "14:00", endTime: "17:00", breakMinutes: 0, status: "prevue" };

describe("durée d'une période", () => {
  it("9h-12h = 180 min, pause méridienne exclue par construction", () => {
    expect(periodMinutes(matin)).toBe(180);
    expect(periodMinutes(apresMidi)).toBe(180);
  });
  it("déduit une pause intra-période et ne devient jamais négative", () => {
    expect(periodMinutes({ startTime: "09:00", endTime: "12:30", breakMinutes: 15 })).toBe(195);
    expect(periodMinutes({ startTime: "09:00", endTime: "09:10", breakMinutes: 30 })).toBe(0);
    expect(periodMinutes({ startTime: "12:00", endTime: "09:00" })).toBe(0);
  });
});

describe("minutes comptées par présence", () => {
  it("présent : toute la période ; absent : 0", () => {
    expect(countedMinutes(matin, { status: "present" })).toBe(180);
    expect(countedMinutes(matin, { status: "absent" })).toBe(0);
    expect(countedMinutes(matin, { status: "absent_justifie" })).toBe(0);
    expect(countedMinutes(matin, { status: "non_saisie" })).toBe(0);
  });
  it("retard : de l'arrivée à la fin", () => {
    expect(countedMinutes(matin, { status: "retard", arrivedAt: "09:30" })).toBe(150);
  });
  it("départ anticipé : du début au départ", () => {
    expect(countedMinutes(apresMidi, { status: "depart_anticipe", leftAt: "16:00" })).toBe(120);
  });
  it("retard et départ : entre les deux, bornés à la période", () => {
    expect(countedMinutes(matin, { status: "retard_et_depart", arrivedAt: "08:00", leftAt: "11:00" })).toBe(120);
    expect(countedMinutes(matin, { status: "retard_et_depart", arrivedAt: "09:15", leftAt: "13:00" })).toBe(165);
  });
  it("retard sans heure d'arrivée : compte toute la période (à corriger par le formateur)", () => {
    expect(countedMinutes(matin, { status: "retard" })).toBe(180);
  });
});

describe("agrégats par inscription (recette R04)", () => {
  const periods = [matin, apresMidi];
  it("présence complète sur 9-12 / 14-17 = 360 min effectuées, jamais 6 h + 6 h", () => {
    const attendances: AttendanceLike[] = [
      { periodId: "m", status: "present" },
      { periodId: "a", status: "present" },
    ];
    const h = aggregateHours({ hoursPlanned: 6, periods, attendances });
    expect(h.scheduled).toBe(360);
    expect(h.done).toBe(360);
    expect(h.validated).toBe(0);
    expect(h.planned).toBe(360);
  });
  it("matin seul = 180 min", () => {
    const h = aggregateHours({ hoursPlanned: 6, periods, attendances: [{ periodId: "m", status: "present" }] });
    expect(h.done).toBe(180);
    expect(h.scheduled).toBe(360);
  });
  it("clôture du matin ne touche pas l'après-midi", () => {
    const h = aggregateHours({
      hoursPlanned: 6,
      periods: [{ ...matin, status: "cloturee" }, apresMidi],
      attendances: [
        { periodId: "m", status: "present" },
        { periodId: "a", status: "present" },
      ],
    });
    expect(h.validated).toBe(180);
    expect(h.done).toBe(360);
  });
  it("actualisation / double envoi : plusieurs lignes pour une même période ne comptent qu'une fois", () => {
    const h = aggregateHours({
      hoursPlanned: 6,
      periods,
      attendances: [
        { periodId: "m", status: "present" },
        { periodId: "m", status: "present" },
        { periodId: "m", status: "present", isCurrent: false },
      ],
    });
    expect(h.done).toBe(180);
  });
  it("une correction remplace sans s'ajouter (ancienne ligne non courante)", () => {
    const h = aggregateHours({
      hoursPlanned: 6,
      periods,
      attendances: [
        { periodId: "m", status: "absent", isCurrent: false },
        { periodId: "m", status: "present", isCurrent: true },
      ],
    });
    expect(h.done).toBe(180);
  });
  it("absence justifiée : heures justifiées à part, 0 effectuée", () => {
    const h = aggregateHours({ hoursPlanned: 6, periods, attendances: [{ periodId: "m", status: "absent_justifie" }] });
    expect(h.justified).toBe(180);
    expect(h.done).toBe(0);
  });
  it("période annulée : non programmée ; solde historique distinct", () => {
    const h = aggregateHours({ hoursPlanned: 6, periods: [matin, { ...apresMidi, status: "annulee" }], attendances: [], legacyMinutes: 420 });
    expect(h.scheduled).toBe(180);
    expect(h.legacy).toBe(420);
    expect(h.done).toBe(0);
  });
});

describe("règles temporelles (heure serveur Europe/Paris, `now` injecté)", () => {
  // 2026-07-15 : UTC+2. Période 09:00-12:00 Paris = 07:00Z-10:00Z.
  const p = { date: "2026-07-15", startTime: "09:00", endTime: "12:00", status: "prevue" as const };
  it("préparation possible la veille, présence refusée avant le début", () => {
    const veille = new Date("2026-07-14T10:00:00Z");
    expect(canPrepare(p).ok).toBe(true);
    expect(canRecordAttendance(p, veille).ok).toBe(false);
    expect(canRecordAttendance(p, new Date("2026-07-15T06:59:00Z")).ok).toBe(false);
    expect(canRecordAttendance(p, new Date("2026-07-15T07:00:00Z")).ok).toBe(true);
  });
  it("signature de fin et clôture refusées avant la fin réelle", () => {
    expect(canCloseOrSign(p, new Date("2026-07-15T09:59:00Z")).ok).toBe(false);
    expect(canCloseOrSign(p, new Date("2026-07-15T10:00:00Z")).ok).toBe(true);
  });
  it("changement d'heure : 29 mars 2026 (passage à UTC+2 à 2h) : 09:00 Paris = 07:00Z", () => {
    const q = { ...p, date: "2026-03-29" };
    expect(canRecordAttendance(q, new Date("2026-03-29T06:30:00Z")).ok).toBe(false);
    expect(canRecordAttendance(q, new Date("2026-03-29T07:00:00Z")).ok).toBe(true);
    // 25 octobre 2026 : retour à UTC+1 à 3h : 14:00 Paris = 13:00Z
    const r = { ...p, date: "2026-10-25", startTime: "14:00", endTime: "17:00" };
    expect(canRecordAttendance(r, new Date("2026-10-25T12:59:00Z")).ok).toBe(false);
    expect(canRecordAttendance(r, new Date("2026-10-25T13:00:00Z")).ok).toBe(true);
  });
  it("période clôturée : aucune modification directe", () => {
    expect(canEditDirectly({ status: "cloturee" }).ok).toBe(false);
    expect(canRecordAttendance({ ...p, status: "cloturee" }, new Date("2026-07-15T08:00:00Z")).ok).toBe(false);
    expect(canCloseOrSign({ ...p, status: "cloturee" }, new Date("2026-07-15T11:00:00Z")).ok).toBe(false);
  });
  it("évaluation à date future refusée", () => {
    expect(isFutureDate("2026-07-16", "2026-07-15")).toBe(true);
    expect(isFutureDate("2026-07-15", "2026-07-15")).toBe(false);
  });
});
