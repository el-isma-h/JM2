/**
 * Calendrier des parcours automatiques : jours ouvrés (lundi à vendredi hors jours fériés français)
 * et calcul des échéances relatives. Fonctions pures sur des dates ISO `YYYY-MM-DD` (aucun fuseau :
 * les dates métier sont déjà exprimées en Europe/Paris par l'appelant, cf. `todayParis`).
 */

export type IsoDate = string;

function parse(d: IsoDate): Date {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) throw new Error(`Date invalide : ${d}`);
  const [y, m, day] = d.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, day));
}

function iso(d: Date): IsoDate {
  return d.toISOString().slice(0, 10);
}

export function addCalendarDays(d: IsoDate, n: number): IsoDate {
  const x = parse(d);
  x.setUTCDate(x.getUTCDate() + n);
  return iso(x);
}

/** Dimanche de Pâques (algorithme de Meeus / Butcher, calendrier grégorien). */
export function easterSunday(year: number): IsoDate {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

/** Jours fériés légaux en France métropolitaine (hors Alsace-Moselle). */
export function frenchHolidays(year: number): Set<IsoDate> {
  const easter = easterSunday(year);
  const y = String(year);
  return new Set([
    `${y}-01-01`, // Jour de l'an
    addCalendarDays(easter, 1), // Lundi de Pâques
    `${y}-05-01`, // Fête du travail
    `${y}-05-08`, // Victoire 1945
    addCalendarDays(easter, 39), // Ascension
    addCalendarDays(easter, 50), // Lundi de Pentecôte
    `${y}-07-14`, // Fête nationale
    `${y}-08-15`, // Assomption
    `${y}-11-01`, // Toussaint
    `${y}-11-11`, // Armistice
    `${y}-12-25`, // Noël
  ]);
}

const holidayCache = new Map<number, Set<IsoDate>>();
function isHoliday(d: IsoDate): boolean {
  const year = Number(d.slice(0, 4));
  let set = holidayCache.get(year);
  if (!set) {
    set = frenchHolidays(year);
    holidayCache.set(year, set);
  }
  return set.has(d);
}

/** Jour ouvré : du lundi au vendredi, hors jour férié. */
export function isBusinessDay(d: IsoDate): boolean {
  const wd = parse(d).getUTCDay();
  return wd !== 0 && wd !== 6 && !isHoliday(d);
}

/**
 * Ajoute `n` jours ouvrés (n négatif : recule). Avec n = 0, la date est ramenée au premier jour ouvré
 * suivant si elle tombe un week-end ou un jour férié.
 */
export function addBusinessDays(d: IsoDate, n: number): IsoDate {
  let cur = d;
  if (n === 0) {
    while (!isBusinessDay(cur)) cur = addCalendarDays(cur, 1);
    return cur;
  }
  const step = n > 0 ? 1 : -1;
  let left = Math.abs(n);
  while (left > 0) {
    cur = addCalendarDays(cur, step);
    if (isBusinessDay(cur)) left--;
  }
  return cur;
}

/** Nombre de jours ouvrés strictement après `from` et jusqu'à `to` inclus (négatif si `to` < `from`). */
export function businessDaysBetween(from: IsoDate, to: IsoDate): number {
  if (from === to) return 0;
  const forward = from < to;
  let cur = from;
  let n = 0;
  while (cur !== to) {
    cur = addCalendarDays(cur, forward ? 1 : -1);
    if (isBusinessDay(cur)) n++;
  }
  return forward ? n : -n;
}

/** Milieu calendaire de [start, end] (arrondi au jour inférieur). */
export function midpoint(start: IsoDate, end: IsoDate): IsoDate {
  const a = parse(start).getTime();
  const b = parse(end).getTime();
  if (b <= a) return start;
  const days = Math.floor((b - a) / 86_400_000 / 2);
  return addCalendarDays(start, days);
}

/* ---------- Délais relatifs ---------- */

/**
 * Point d'ancrage d'un délai :
 * - `inscription` : date de création de l'inscription ;
 * - `debut` / `fin` : dates du parcours (inscription, sinon session) ;
 * - `milieu` : milieu calendaire entre début et fin ;
 * - `precedente` : échéance de l'étape précédente du parcours.
 */
export type DelayAnchor = "inscription" | "debut" | "fin" | "milieu" | "precedente";

export type RelativeDelay = {
  anchor: DelayAnchor;
  /** Décalage : négatif = avant l'ancre (J-7), positif = après (J+1). */
  offset: number;
  /** `ouvres` : jours ouvrés ; `calendaires` par défaut. */
  unit?: "calendaires" | "ouvres";
};

export type DelayAnchors = { inscription: IsoDate; debut: IsoDate; fin: IsoDate; precedente?: IsoDate | null };

export function computeDueDate(delay: RelativeDelay, anchors: DelayAnchors): IsoDate {
  const base =
    delay.anchor === "inscription"
      ? anchors.inscription
      : delay.anchor === "debut"
        ? anchors.debut
        : delay.anchor === "fin"
          ? anchors.fin
          : delay.anchor === "milieu"
            ? midpoint(anchors.debut, anchors.fin)
            : (anchors.precedente ?? anchors.inscription);
  return delay.unit === "ouvres" ? addBusinessDays(base, delay.offset) : addCalendarDays(base, delay.offset);
}

/** Libellé court du délai : « J-7 avant le début », « 5 jours ouvrés après l'étape précédente »… */
export function delayLabel(delay: RelativeDelay): string {
  const n = Math.abs(delay.offset);
  const unit = delay.unit === "ouvres" ? (n > 1 ? "jours ouvrés" : "jour ouvré") : n > 1 ? "jours" : "jour";
  const anchorLabel: Record<DelayAnchor, string> = {
    inscription: "l'inscription",
    debut: "le début",
    fin: "la fin",
    milieu: "le milieu de la formation",
    precedente: "l'étape précédente",
  };
  if (delay.anchor === "debut" || delay.anchor === "fin") {
    if (delay.offset === 0) return delay.anchor === "debut" ? "Jour du début" : "Jour de la fin";
    const j = `J${delay.offset > 0 ? "+" : "-"}${n}${delay.unit === "ouvres" ? " ouvré" + (n > 1 ? "s" : "") : ""}`;
    return `${j} ${delay.offset > 0 ? "après" : "avant"} ${anchorLabel[delay.anchor]}`;
  }
  if (delay.offset === 0) return delay.anchor === "milieu" ? "Milieu de la formation" : `Même jour que ${anchorLabel[delay.anchor]}`;
  return `${n} ${unit} ${delay.offset > 0 ? "après" : "avant"} ${anchorLabel[delay.anchor]}`;
}
