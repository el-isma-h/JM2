import "server-only";
import JSZip from "jszip";
import { and, eq, inArray, type AnyColumn } from "drizzle-orm";
import { db, schema } from "@/db";
import { readDocument } from "@/server/documents/store";

/**
 * Export RGPD d'une personne (T04) : archive ZIP contenant les données structurées (JSON) et les documents
 * qui la concernent. Les journaux n'embarquent ni mots de passe ni clés ; les notes confidentielles ne sont
 * exportées que si l'appelant y a droit (`includeConfidential`).
 */
export async function buildPersonExport(orgId: string, personId: string, opts: { includeConfidential: boolean }): Promise<{ zip: Buffer; fileName: string; counts: Record<string, number> } | null> {
  const [person] = await db.select().from(schema.persons).where(and(eq(schema.persons.id, personId), eq(schema.persons.orgId, orgId))).limit(1);
  if (!person) return null;
  const enrollments = await db.select().from(schema.enrollments).where(and(eq(schema.enrollments.orgId, orgId), eq(schema.enrollments.personId, personId)));
  const enrollmentIds = enrollments.map((e) => e.id);
  const [attendances, evaluations, fundings, invoices, placements, surveyResponses, documents, pieces] = await Promise.all([
    enrollmentIds.length ? db.select().from(schema.attendances).where(and(eq(schema.attendances.orgId, orgId), eq(schema.attendances.isCurrent, true), inList(schema.attendances.enrollmentId, enrollmentIds))) : [],
    enrollmentIds.length ? db.select().from(schema.evaluations).where(and(eq(schema.evaluations.orgId, orgId), inList(schema.evaluations.enrollmentId, enrollmentIds))) : [],
    enrollmentIds.length ? db.select().from(schema.fundings).where(and(eq(schema.fundings.orgId, orgId), inList(schema.fundings.enrollmentId, enrollmentIds))) : [],
    db.select().from(schema.invoices).where(and(eq(schema.invoices.orgId, orgId), eq(schema.invoices.personId, personId))),
    db.select().from(schema.placements).where(and(eq(schema.placements.orgId, orgId), eq(schema.placements.personId, personId))),
    enrollmentIds.length ? db.select().from(schema.surveyResponses).where(and(eq(schema.surveyResponses.orgId, orgId), inList(schema.surveyResponses.enrollmentId, enrollmentIds))) : [],
    db.select().from(schema.documents).where(and(eq(schema.documents.orgId, orgId), eq(schema.documents.personId, personId))),
    enrollmentIds.length ? db.select().from(schema.pieceSubmissions).where(and(eq(schema.pieceSubmissions.orgId, orgId), inList(schema.pieceSubmissions.enrollmentId, enrollmentIds))) : [],
  ]);
  const enrollmentDocs = enrollmentIds.length ? await db.select().from(schema.documents).where(and(eq(schema.documents.orgId, orgId), inList(schema.documents.enrollmentId, enrollmentIds))) : [];
  const allDocs = [...documents, ...enrollmentDocs.filter((d) => !documents.some((x) => x.id === d.id))];

  const safePerson = { ...person, confidentialNotes: opts.includeConfidential ? person.confidentialNotes : "[non exporté : accès réservé]" };
  const zip = new JSZip();
  const strip = (o: unknown) => JSON.parse(JSON.stringify(o, (k, v) => (/(hash|enc|token|secret|key)$/i.test(k) ? undefined : v)));
  zip.file("personne.json", JSON.stringify(strip(safePerson), null, 2));
  zip.file("inscriptions.json", JSON.stringify(strip(enrollments), null, 2));
  zip.file("presences.json", JSON.stringify(strip(attendances), null, 2));
  zip.file("evaluations.json", JSON.stringify(strip(evaluations), null, 2));
  zip.file("financements.json", JSON.stringify(strip(fundings), null, 2));
  zip.file("factures.json", JSON.stringify(strip(invoices), null, 2));
  zip.file("placements.json", JSON.stringify(strip(placements), null, 2));
  zip.file("enquetes.json", JSON.stringify(strip(surveyResponses), null, 2));
  zip.file("pieces.json", JSON.stringify(strip(pieces), null, 2));
  zip.file("documents.json", JSON.stringify(strip(allDocs.map((d) => ({ id: d.id, title: d.title, category: d.category, status: d.status, fileName: d.fileName, version: d.version, createdAt: d.createdAt }))), null, 2));
  let files = 0;
  for (const d of allDocs) {
    if (d.category === "cv" && !opts.includeConfidential) continue;
    try {
      const r = await readDocument(d.id);
      if (!r) continue;
      zip.file(`documents/${d.id.slice(0, 8)}-${d.fileName.replace(/[^\w.\-]+/g, "_")}`, r.data);
      files++;
    } catch {
      // document introuvable sur le stockage : ignoré, listé dans documents.json
    }
  }
  zip.file("LISEZMOI.txt", `Export des données personnelles de ${person.firstName} ${person.lastName}\nGénéré le ${new Date().toISOString()} par Next Formation.\nContenu : données structurées (JSON) et ${files} document(s).\nLes empreintes, jetons et secrets techniques ne sont jamais exportés.\n`);
  const buf = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
  const fileName = `export-rgpd-${person.lastName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${person.firstName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${new Date().toISOString().slice(0, 10)}.zip`;
  return { zip: buf, fileName, counts: { inscriptions: enrollments.length, presences: attendances.length, evaluations: evaluations.length, documents: files, factures: invoices.length } };
}

function inList(col: AnyColumn, ids: string[]) {
  return inArray(col, ids);
}
