import "server-only";
import { and, eq, inArray, lte, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { todayParis } from "@/lib/time";
import { registerJobHandler, type JobHandler } from "@/server/jobs/registry";
import { sendSurveyToSession } from "./surveys";
import { readAutomation, sessionDue } from "./jobs-rules";

/**
 * Tâche de fond `surveys:dispatch` : envoi automatique des enquêtes selon `surveys.automation`
 * ({ trigger: "session_end", delayDays: N }).
 *  - Une enquête ACTIVE reliée à une session : envoyée quand la session est terminée depuis N jours et qu'aucun
 *    destinataire n'a encore reçu de jeton.
 *  - Une enquête ACTIVE sans session (modèle d'organisme) : pour chaque session terminée depuis N jours sans enquête
 *    de ce modèle, une enquête fille est créée (automation.fromSurveyId) puis envoyée.
 * En démonstration, aucun e-mail ne part (sendMail) ; les jetons existent et les liens sont consultables sur l'enquête.
 */

export { readAutomation, sessionDue, type Automation } from "./jobs-rules";

export type DispatchReport = { surveysChecked: number; dispatched: number; created: number; sent: number; skipped: number; orgIds: string[] };

export async function dispatchDueSurveys(onlyOrgId: string | null = null): Promise<DispatchReport> {
  const today = todayParis();
  const report: DispatchReport = { surveysChecked: 0, dispatched: 0, created: 0, sent: 0, skipped: 0, orgIds: [] };
  const surveys = await db
    .select()
    .from(schema.surveys)
    .where(and(eq(schema.surveys.status, "active"), sql`${schema.surveys.automation} ->> 'trigger' = 'session_end'`, onlyOrgId ? eq(schema.surveys.orgId, onlyOrgId) : undefined));
  const orgCache = new Map<string, { legalName: string; tradeName: string | null; isDemo: boolean }>();
  async function orgInfo(orgId: string) {
    const c = orgCache.get(orgId);
    if (c) return c;
    const [o] = await db.select({ legalName: schema.organismes.legalName, tradeName: schema.organismes.tradeName, isDemo: schema.organismes.isDemo }).from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
    const info = o ?? { legalName: "Organisme", tradeName: null, isDemo: true };
    orgCache.set(orgId, info);
    return info;
  }

  for (const s of surveys) {
    report.surveysChecked++;
    const auto = readAutomation(s.automation);
    const org = await orgInfo(s.orgId);
    if (!report.orgIds.includes(s.orgId)) report.orgIds.push(s.orgId);

    if (s.sessionId) {
      const [sess] = await db.select({ endDate: schema.trainingSessions.endDate, status: schema.trainingSessions.status }).from(schema.trainingSessions).where(and(eq(schema.trainingSessions.id, s.sessionId), eq(schema.trainingSessions.orgId, s.orgId))).limit(1);
      if (!sess || sess.status === "annulee" || !sessionDue(sess.endDate, auto.delayDays ?? 0, today)) {
        report.skipped++;
        continue;
      }
      const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.surveyResponses).where(eq(schema.surveyResponses.surveyId, s.id));
      if (n > 0) {
        report.skipped++;
        continue;
      }
      const r = await sendSurveyToSession(s, { orgId: s.orgId, isDemo: org.isDemo, orgName: org.tradeName ?? org.legalName });
      report.dispatched++;
      report.sent += r.sent;
      continue;
    }

    // Modèle d'organisme : sessions terminées (ou dont la date de fin est passée) depuis N jours, sans enquête fille.
    const delay = auto.delayDays ?? 0;
    const sessions = await db
      .select({ id: schema.trainingSessions.id, title: schema.trainingSessions.title, endDate: schema.trainingSessions.endDate, programVersionId: schema.trainingSessions.programVersionId })
      .from(schema.trainingSessions)
      .where(and(eq(schema.trainingSessions.orgId, s.orgId), or(eq(schema.trainingSessions.status, "terminee"), lte(schema.trainingSessions.endDate, today)), inArray(schema.trainingSessions.status, ["confirmee", "en_cours", "terminee"])));
    const children = await db
      .select({ sessionId: schema.surveys.sessionId })
      .from(schema.surveys)
      .where(and(eq(schema.surveys.orgId, s.orgId), sql`${schema.surveys.automation} ->> 'fromSurveyId' = ${s.id}`));
    const covered = new Set(children.map((c) => c.sessionId));
    for (const sess of sessions) {
      if (covered.has(sess.id) || !sessionDue(sess.endDate, delay, today)) {
        report.skipped++;
        continue;
      }
      const [pv] = await db.select({ programId: schema.programVersions.programId }).from(schema.programVersions).where(eq(schema.programVersions.id, sess.programVersionId)).limit(1);
      const [child] = await db
        .insert(schema.surveys)
        .values({
          orgId: s.orgId,
          kind: s.kind,
          title: `${s.title} : ${sess.title}`,
          description: s.description,
          questions: s.questions,
          sessionId: sess.id,
          programId: pv?.programId ?? null,
          status: "active",
          automation: { fromSurveyId: s.id, delayDays: delay, createdAt: new Date().toISOString() },
          createdBy: s.createdBy,
        })
        .returning();
      report.created++;
      const r = await sendSurveyToSession(child, { orgId: s.orgId, isDemo: org.isDemo, orgName: org.tradeName ?? org.legalName });
      report.dispatched++;
      report.sent += r.sent;
    }
    await db.update(schema.surveys).set({ automation: { ...auto, lastRunAt: new Date().toISOString() } }).where(eq(schema.surveys.id, s.id));
  }
  return report;
}

export const surveysDispatchHandler: JobHandler = async (job) => {
  const report = await dispatchDueSurveys(job.orgId ?? (typeof job.payload.orgId === "string" ? job.payload.orgId : null));
  await scheduleNextDispatch();
  return { ...report };
};

/** Replanifie l'occurrence suivante (quotidienne) si aucune n'est en file : la tâche s'auto-entretient. */
export async function scheduleNextDispatch(hours = 24): Promise<boolean> {
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(hashtext('nextformation:jobs:surveys:dispatch'))`);
    const [pending] = await tx.select({ id: schema.jobs.id }).from(schema.jobs).where(and(eq(schema.jobs.kind, "surveys:dispatch"), eq(schema.jobs.status, "queued"))).limit(1);
    if (pending) return false;
    await tx.insert(schema.jobs).values({ kind: "surveys:dispatch", runAfter: new Date(Date.now() + hours * 3600_000) });
    return true;
  });
}

registerJobHandler("surveys:dispatch", surveysDispatchHandler);
