import { describe, expect, it } from "vitest";
import { analyze, classifyIndicator, ENGINE_VERSION, evidenceInScope, evidencesChangedSince, levelsForScope, orgActivities, summarize, type EvidenceInput, type ScopeContext } from "../engine";
import { buildCriteria, QUALIOPI_INDICATORS, type IndicatorDef } from "../referential-data";

const REF = "2026-10-20";
const ORG: ScopeContext = { scope: "organisme", scopeId: null, sessionIds: [], enrollmentIds: [], programIds: [] };
const byCode = (code: string) => QUALIOPI_INDICATORS.find((i) => i.code === code)!;

function ev(p: Partial<EvidenceInput> & { id: string; indicatorCode: string }): EvidenceInput {
  return { level: "organisationnel", status: "valide", evidenceDate: "2026-10-01", createdAt: "2026-10-01T10:00:00.000Z", enrollmentId: null, sessionId: null, programId: null, ...p };
}

describe("référentiel", () => {
  it("contient 7 critères et 32 indicateurs IND_1 à IND_32", () => {
    const criteria = buildCriteria();
    expect(criteria).toHaveLength(7);
    expect(criteria.flatMap((c) => c.indicators)).toHaveLength(32);
    expect(QUALIOPI_INDICATORS.map((i) => i.code)).toEqual(Array.from({ length: 32 }, (_, i) => `IND_${i + 1}`));
  });
  it("réserve les indicateurs 14, 15, 20 et 29 à l'apprentissage", () => {
    for (const n of [14, 15, 20, 29]) expect(byCode(`IND_${n}`).applicability).toEqual(["cfa"]);
    expect(byCode("IND_1").applicability).toEqual(["of", "cfa"]);
  });
});

describe("classement d'un indicateur", () => {
  it("prouvé : une preuve valide reliée, antérieure à la date de référence", () => {
    const c = classifyIndicator(byCode("IND_1"), [ev({ id: "a", indicatorCode: "IND_1" })], ORG, REF, ["of"]);
    expect(c.status).toBe("prouve");
    expect(c.evidenceIds).toEqual(["a"]);
  });
  it("absent : aucune preuve", () => {
    expect(classifyIndicator(byCode("IND_1"), [], ORG, REF, ["of"]).status).toBe("absent");
  });
  it("non applicable : indicateur CFA pour un organisme OF seul", () => {
    const c = classifyIndicator(byCode("IND_15"), [ev({ id: "a", indicatorCode: "IND_15" })], ORG, REF, ["of"]);
    expect(c.status).toBe("non_applicable");
    expect(c.evidenceIds).toEqual([]);
  });
  it("applicable : indicateur CFA pour un organisme OF + CFA", () => {
    expect(classifyIndicator(byCode("IND_15"), [], ORG, REF, orgActivities("of_cfa")).status).toBe("absent");
  });
  it("non applicable : indicateur organisationnel dans une analyse d'inscription", () => {
    const ctx: ScopeContext = { scope: "inscription", scopeId: "e1", sessionIds: ["s1"], enrollmentIds: ["e1"], programIds: [] };
    expect(classifyIndicator(byCode("IND_23"), [ev({ id: "a", indicatorCode: "IND_23" })], ctx, REF, ["of"]).status).toBe("non_applicable");
    expect(levelsForScope("inscription")).not.toContain("organisationnel");
  });
  it("à examiner : indicateur à appréciation humaine, même avec preuve (jamais prouvé automatiquement)", () => {
    const c = classifyIndicator(byCode("IND_32"), [ev({ id: "a", indicatorCode: "IND_32" })], ORG, REF, ["of"]);
    expect(c.requiresHuman).toBe(true);
    expect(c.status).toBe("a_examiner");
    expect(c.evidenceIds).toEqual(["a"]);
  });
  it("absent : indicateur à appréciation humaine sans preuve (la preuve reste à produire)", () => {
    expect(classifyIndicator(byCode("IND_32"), [], ORG, REF, ["of"]).status).toBe("absent");
  });
  it("à examiner : la seule preuve a été invalidée depuis", () => {
    const c = classifyIndicator(byCode("IND_1"), [ev({ id: "a", indicatorCode: "IND_1", status: "invalidee", invalidationReason: "document erroné" })], ORG, REF, ["of"]);
    expect(c.status).toBe("a_examiner");
    expect(c.evidenceCount).toBe(0);
    expect(c.note).toContain("document erroné");
  });
  it("ignore une preuve postérieure à la date de référence", () => {
    const c = classifyIndicator(byCode("IND_1"), [ev({ id: "a", indicatorCode: "IND_1", evidenceDate: "2026-10-21" })], ORG, REF, ["of"]);
    expect(c.status).toBe("absent");
    expect(c.note).toContain("postérieure");
  });
  it("utilise la date de création quand la preuve n'a pas de date", () => {
    const c = classifyIndicator(byCode("IND_1"), [ev({ id: "a", indicatorCode: "IND_1", evidenceDate: null, createdAt: "2026-10-25T08:00:00.000Z" })], ORG, REF, ["of"]);
    expect(c.status).toBe("absent");
  });
});

describe("périmètres et preuves collectives", () => {
  const session: ScopeContext = { scope: "session", scopeId: "s1", sessionIds: ["s1"], enrollmentIds: ["e1", "e2", "e3"], programIds: [] };
  it("une preuve collective de session compte une fois, pas une fois par apprenant", () => {
    const c = classifyIndicator(byCode("IND_30"), [ev({ id: "coll", indicatorCode: "IND_30", level: "collectif", sessionId: "s1" })], session, REF, ["of"]);
    expect(c.status).toBe("prouve");
    expect(c.evidenceCount).toBe(1);
    expect(c.evidenceIds).toEqual(["coll"]);
  });
  it("une preuve d'une autre session est hors périmètre", () => {
    expect(evidenceInScope(ev({ id: "x", indicatorCode: "IND_30", level: "collectif", sessionId: "s2" }), session)).toBe(false);
    expect(classifyIndicator(byCode("IND_30"), [ev({ id: "x", indicatorCode: "IND_30", level: "collectif", sessionId: "s2" })], session, REF, ["of"]).status).toBe("absent");
  });
  it("inscription : sa preuve individuelle et la preuve collective de sa session comptent, pas celles des autres inscriptions", () => {
    const ctx: ScopeContext = { scope: "inscription", scopeId: "e1", sessionIds: ["s1"], enrollmentIds: ["e1"], programIds: [] };
    expect(evidenceInScope(ev({ id: "a", indicatorCode: "IND_9", level: "individuel", enrollmentId: "e1", sessionId: "s1" }), ctx)).toBe(true);
    expect(evidenceInScope(ev({ id: "b", indicatorCode: "IND_9", level: "individuel", enrollmentId: "e2", sessionId: "s1" }), ctx)).toBe(false);
    expect(evidenceInScope(ev({ id: "c", indicatorCode: "IND_30", level: "collectif", sessionId: "s1" }), ctx)).toBe(true);
  });
  it("organisme : toute preuve est dans le périmètre", () => {
    expect(evidenceInScope(ev({ id: "a", indicatorCode: "IND_9", level: "individuel", enrollmentId: "e9" }), ORG)).toBe(true);
  });
});

describe("analyse complète et synthèse", () => {
  const criteria = buildCriteria();
  it("produit 32 contrôles, une synthèse cohérente et l'avertissement sur le pourcentage", () => {
    const r = analyze({ criteria, activities: ["of"], ctx: ORG, evidences: [ev({ id: "a", indicatorCode: "IND_1" }), ev({ id: "b", indicatorCode: "IND_32" })], referenceDate: REF });
    expect(r.engineVersion).toBe(ENGINE_VERSION);
    expect(r.controls).toHaveLength(32);
    const s = r.summary;
    expect(s.total).toBe(32);
    expect(s.notApplicable).toBe(4); // 14, 15, 20, 29 : CFA uniquement
    expect(s.proven).toBe(1);
    expect(s.humanReview).toBe(1);
    expect(s.proven + s.missing + s.notApplicable + s.humanReview).toBe(32);
    expect(s.coveragePct).toBe(Math.round((1 / 28) * 100));
    expect(s.disclaimer).toMatch(/n'est pas une attestation de conformité/);
  });
  it("coveragePct vaut 0 sans indicateur applicable", () => {
    expect(summarize([]).coveragePct).toBe(0);
  });
  it("R08 : invalider une preuve change la nouvelle analyse, l'ancienne reste intacte", () => {
    const before = [ev({ id: "a", indicatorCode: "IND_1" })];
    const first = analyze({ criteria, activities: ["of"], ctx: ORG, evidences: before, referenceDate: REF });
    const frozen = JSON.stringify(first);
    const after = [{ ...before[0], status: "invalidee" as const, invalidationReason: "signature manquante" }];
    const second = analyze({ criteria, activities: ["of"], ctx: ORG, evidences: after, referenceDate: REF });
    expect(JSON.stringify(first)).toBe(frozen);
    expect(first.controls.find((c) => c.indicator === "IND_1")!.status).toBe("prouve");
    expect(second.controls.find((c) => c.indicator === "IND_1")!.status).toBe("a_examiner");
    expect(second.summary.proven).toBe(first.summary.proven - 1);
    expect(second.summary.humanReview).toBe(first.summary.humanReview + 1);
  });
  it("signale des preuves modifiées depuis la photographie", () => {
    const at = "2026-10-20T10:00:00.000Z";
    expect(evidencesChangedSince([{ createdAt: "2026-10-01T00:00:00Z", updatedAt: "2026-10-01T00:00:00Z" }], at)).toBe(false);
    expect(evidencesChangedSince([{ createdAt: "2026-10-01T00:00:00Z", updatedAt: "2026-10-21T00:00:00Z" }], at)).toBe(true);
    expect(evidencesChangedSince([{ createdAt: "2026-10-22T00:00:00Z", updatedAt: "2026-10-22T00:00:00Z" }], at)).toBe(true);
  });
  it("un indicateur sans applicabilité connue est traité comme OF et CFA", () => {
    const def: IndicatorDef = { ...byCode("IND_1"), applicability: ["of", "cfa"] };
    expect(classifyIndicator(def, [], ORG, REF, ["cfa"]).status).toBe("absent");
  });
});
