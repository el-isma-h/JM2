"use server";

import { revalidatePath } from "next/cache";
import { and, asc, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { audit } from "@/server/audit";
import { requireOrg, type OrgContext } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { createDocument } from "@/server/documents/store";
import { layoutMail, sendMail } from "@/server/mail";
import { recordEvidence } from "@/server/quality/evidence";
import { createTaskOnce, resolveTaskByKey } from "@/server/tasks/service";
import { fmtDate } from "@/lib/dates";
import { todayParis } from "@/lib/time";
import { assignMember, loadCohort, renderConvocationPdf, type Cohort } from "@/server/exams/service";
import { examStateForResult, resultAllowed, type ExamResult } from "@/server/exams/eligibility";
import { periodsForEnrollment } from "@/server/planning/service";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const optUuid = z.preprocess((v) => (v === "" || v == null ? undefined : v), uuid.optional());
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide (AAAA-MM-JJ)");

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

async function orgIdOf(formData: FormData) {
  return uuid.parse(formData.get("orgId"));
}

function paths(ctx: OrgContext, cohortId?: string) {
  revalidatePath(`/app/${ctx.org.id}/examens`);
  if (cohortId) revalidatePath(`/app/${ctx.org.id}/examens/${cohortId}`);
}

const cohortSchema = z.object({
  programId: uuid,
  code: z.string().trim().min(2, "Code requis").max(40),
  label: z.string().trim().min(2, "Libellé requis").max(160),
  date: isoDate,
  endDate: z.preprocess((v) => (v === "" || v == null ? undefined : v), isoDate.optional()),
  capacity: z.preprocess((v) => Number(v), z.number().int().min(1, "Capacité d'au moins 1").max(1000)),
  managerUserId: optUuid,
  siteId: optUuid,
  scope: z.enum(["complet", "blocs"]).default("complet"),
  blocks: z.preprocess((v) => (Array.isArray(v) ? v : v ? [v] : []), z.array(z.string().trim().min(1).max(80))).optional(),
  allowPartial: z.preprocess((v) => v === "1" || v === "on", z.boolean()).optional(),
  allowRetake: z.preprocess((v) => v === "1" || v === "on", z.boolean()).optional(),
  notes: z.string().trim().max(2000).optional(),
});

function readForm(formData: FormData) {
  const obj: Record<string, unknown> = {};
  for (const [k, v] of formData.entries()) {
    if (k in obj) obj[k] = Array.isArray(obj[k]) ? [...(obj[k] as unknown[]), v] : [obj[k], v];
    else obj[k] = v;
  }
  return obj;
}

async function checkCohortRefs(ctx: OrgContext, d: { programId: string; managerUserId?: string; siteId?: string; scope: string; blocks?: string[] }) {
  const [p] = await db.select({ id: schema.programs.id }).from(schema.programs).where(and(eq(schema.programs.id, d.programId), eq(schema.programs.orgId, ctx.org.id))).limit(1);
  if (!p) throw new Error("Formation inconnue dans cet organisme.");
  if (d.siteId) {
    const [s] = await db.select({ id: schema.sites.id }).from(schema.sites).where(and(eq(schema.sites.id, d.siteId), eq(schema.sites.orgId, ctx.org.id))).limit(1);
    if (!s) throw new Error("Site inconnu.");
  }
  if (d.managerUserId) {
    const [m] = await db.select({ id: schema.memberships.id }).from(schema.memberships).where(and(eq(schema.memberships.orgId, ctx.org.id), eq(schema.memberships.userId, d.managerUserId), eq(schema.memberships.active, true))).limit(1);
    if (!m) throw new Error("Le responsable doit être un membre actif de l'organisme.");
  }
  if (d.scope === "blocs" && !d.blocks?.length) throw new Error("Choisissez au moins un bloc pour un périmètre « blocs ».");
}

/** Création d'une cohorte d'examen : formation, code, libellé, date, capacité, responsable, périmètre complet / blocs. */
export async function createCohortAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "exams.manage");
    const d = cohortSchema.parse(readForm(formData));
    await checkCohortRefs(ctx, d);
    if (d.endDate && d.endDate < d.date) return { error: "La date de fin précède la date de début." };
    const [row] = await db
      .insert(schema.examCohorts)
      .values({ orgId: ctx.org.id, programId: d.programId, code: d.code, label: d.label, date: d.date, endDate: d.endDate ?? null, capacity: d.capacity, managerUserId: d.managerUserId ?? null, siteId: d.siteId ?? null, scope: d.scope, blocks: d.scope === "blocs" ? d.blocks ?? [] : [], allowsPartial: { partial: d.allowPartial ?? true, retake: d.allowRetake ?? true }, notes: d.notes || null })
      .onConflictDoNothing({ target: [schema.examCohorts.orgId, schema.examCohorts.code] })
      .returning({ id: schema.examCohorts.id });
    if (!row) return { error: `Le code « ${d.code} » existe déjà dans cet organisme.` };
    await audit({ action: "cohort.create", userId: ctx.user.id, orgId: ctx.org.id, entityType: "exam_cohort", entityId: row.id, after: { code: d.code, label: d.label, date: d.date, capacity: d.capacity, scope: d.scope } });
    paths(ctx);
    return { ok: true, message: `Cohorte « ${d.code} » créée.`, data: { cohortId: row.id } };
  } catch (e) {
    return fail(e, "Création impossible.");
  }
}

/** Modification de la cohorte sélectionnée uniquement (identifiant vérifié dans l'organisme ; aucune autre cohorte touchée). */
export async function updateCohortAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "exams.manage");
    const cohortId = uuid.parse(formData.get("cohortId"));
    const cohort = await loadCohort(ctx.org.id, cohortId);
    if (!cohort) return { error: "Cohorte introuvable." };
    const d = cohortSchema.extend({ status: z.enum(["preparation", "ouverte", "convoquee", "terminee", "annulee"]).optional() }).parse(readForm(formData));
    await checkCohortRefs(ctx, d);
    if (d.endDate && d.endDate < d.date) return { error: "La date de fin précède la date de début." };
    if (cohort.programId !== d.programId) {
      const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(schema.examMembers).where(and(eq(schema.examMembers.cohortId, cohort.id), eq(schema.examMembers.orgId, ctx.org.id)));
      if (n > 0) return { error: "La formation ne peut plus changer : des membres sont déjà affectés." };
    }
    const [updated] = await db
      .update(schema.examCohorts)
      .set({ programId: d.programId, code: d.code, label: d.label, date: d.date, endDate: d.endDate ?? null, capacity: d.capacity, managerUserId: d.managerUserId ?? null, siteId: d.siteId ?? null, scope: d.scope, blocks: d.scope === "blocs" ? d.blocks ?? [] : [], allowsPartial: { partial: d.allowPartial ?? true, retake: d.allowRetake ?? true }, notes: d.notes || null, status: d.status ?? cohort.status, updatedAt: new Date() })
      .where(and(eq(schema.examCohorts.id, cohort.id), eq(schema.examCohorts.orgId, ctx.org.id)))
      .returning({ id: schema.examCohorts.id });
    if (!updated) return { error: "Mise à jour refusée." };
    await audit({ action: "cohort.update", userId: ctx.user.id, orgId: ctx.org.id, entityType: "exam_cohort", entityId: cohort.id, before: { code: cohort.code, label: cohort.label, date: cohort.date, capacity: cohort.capacity, status: cohort.status }, after: { code: d.code, label: d.label, date: d.date, capacity: d.capacity, status: d.status ?? cohort.status } });
    paths(ctx, cohort.id);
    return { ok: true, message: "Cohorte mise à jour." };
  } catch (e) {
    return fail(e, "Modification impossible.");
  }
}

/** Affectation d'une inscription : contrôles serveur (organisme, formation, éligibilité, capacité, doublon) sous verrou. */
export async function assignMemberAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "exams.manage");
    const cohortId = uuid.parse(formData.get("cohortId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const cohort = await loadCohort(ctx.org.id, cohortId);
    if (!cohort) return { error: "Cohorte introuvable." };
    const res = await assignMember(ctx.org.id, cohort.id, enrollmentId, ctx.user.id);
    if (!res.ok) return { error: res.reason };
    await audit({ action: "cohort.member.assign", userId: ctx.user.id, orgId: ctx.org.id, entityType: "exam_member", entityId: res.memberId, after: { cohortId: cohort.id, enrollmentId } });
    await resolveTaskByKey(ctx.org.id, `exam:${enrollmentId}:a_inscrire`, `Affecté à la cohorte ${cohort.code}.`, ctx.user.id);
    paths(ctx, cohort.id);
    return { ok: true, message: "Inscription affectée à la cohorte." };
  } catch (e) {
    return fail(e, "Affectation impossible.");
  }
}

/** Retrait d'un membre non convoqué et sans résultat (statut « désisté » sinon). */
export async function removeMemberAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "exams.manage");
    const cohortId = uuid.parse(formData.get("cohortId"));
    const memberId = uuid.parse(formData.get("memberId"));
    const [m] = await db.select().from(schema.examMembers).where(and(eq(schema.examMembers.id, memberId), eq(schema.examMembers.cohortId, cohortId), eq(schema.examMembers.orgId, ctx.org.id))).limit(1);
    if (!m) return { error: "Membre introuvable dans cette cohorte." };
    if (m.result) return { error: "Un résultat est enregistré : le membre ne peut plus être retiré." };
    if (m.convokedAt) {
      await db.update(schema.examMembers).set({ status: "desiste", updatedAt: new Date() }).where(eq(schema.examMembers.id, m.id));
      await audit({ action: "cohort.member.withdraw", userId: ctx.user.id, orgId: ctx.org.id, entityType: "exam_member", entityId: m.id, before: { status: m.status }, after: { status: "desiste" } });
      paths(ctx, cohortId);
      return { ok: true, message: "Membre marqué désisté (convocation déjà émise, conservée)." };
    }
    await db.transaction(async (tx) => {
      await tx.delete(schema.examMembers).where(eq(schema.examMembers.id, m.id));
      await tx.update(schema.enrollments).set({ examState: "a_inscrire", updatedAt: new Date() }).where(and(eq(schema.enrollments.id, m.enrollmentId), eq(schema.enrollments.examState, "inscrit")));
    });
    await audit({ action: "cohort.member.remove", userId: ctx.user.id, orgId: ctx.org.id, entityType: "exam_member", entityId: m.id, before: { cohortId, enrollmentId: m.enrollmentId } });
    paths(ctx, cohortId);
    return { ok: true, message: "Membre retiré de la cohorte." };
  } catch (e) {
    return fail(e, "Retrait impossible.");
  }
}

async function convoke(ctx: OrgContext, cohort: Cohort, memberId: string) {
  const [row] = await db
    .select({ member: schema.examMembers, enrollment: schema.enrollments, person: schema.persons })
    .from(schema.examMembers)
    .innerJoin(schema.enrollments, eq(schema.enrollments.id, schema.examMembers.enrollmentId))
    .innerJoin(schema.persons, eq(schema.persons.id, schema.enrollments.personId))
    .where(and(eq(schema.examMembers.id, memberId), eq(schema.examMembers.cohortId, cohort.id), eq(schema.examMembers.orgId, ctx.org.id)))
    .limit(1);
  if (!row) throw new Error("Membre introuvable dans cette cohorte.");
  if (row.member.status === "desiste") return { skipped: "désisté" };
  const [program] = await db.select({ title: schema.programs.title, certificationId: schema.programs.certificationId }).from(schema.programs).where(eq(schema.programs.id, cohort.programId)).limit(1);
  const [site] = cohort.siteId ? await db.select().from(schema.sites).where(eq(schema.sites.id, cohort.siteId)).limit(1) : [];
  const [manager] = cohort.managerUserId ? await db.select({ firstName: schema.users.firstName, lastName: schema.users.lastName }).from(schema.users).where(eq(schema.users.id, cohort.managerUserId)).limit(1) : [];
  const [cert] = program?.certificationId ? await db.select({ blocks: schema.certifications.blocks }).from(schema.certifications).where(eq(schema.certifications.id, program.certificationId)).limit(1) : [];
  const allBlocks = ((cert?.blocks ?? []) as { code: string; label: string }[]) ?? [];
  const codes = (cohort.blocks as string[]) ?? [];
  const blocks = codes.map((c) => allBlocks.find((b) => b.code === c) ?? { code: c, label: "" });
  const periods = (await periodsForEnrollment(ctx.org.id, row.enrollment.id)).filter((p) => p.period.status !== "annulee" && p.slot.status !== "annulee");
  const pdf = await renderConvocationPdf({
    org: ctx.org,
    person: row.person,
    enrollment: row.enrollment,
    cohort,
    program: { title: program?.title ?? "[À COMPLÉTER : formation]" },
    site: site ?? null,
    manager: manager ?? null,
    blocks,
    periods: periods.map((p) => ({ date: p.slot.date, startTime: p.period.startTime, endTime: p.period.endTime, title: p.slot.title ?? `Séance (${p.period.part})` })),
  });
  const doc = await createDocument({
    orgId: ctx.org.id,
    enrollmentId: row.enrollment.id,
    personId: row.person.id,
    sessionId: row.enrollment.sessionId,
    category: "convocation",
    visibility: "apprenant",
    status: "genere",
    title: `Convocation examen ${cohort.code}`,
    fileName: `convocation-${cohort.code}-${row.enrollment.reference}.pdf`,
    mimeType: "application/pdf",
    data: pdf,
    sourceType: "exam_member",
    sourceId: row.member.id,
    previousVersionId: row.member.convocationDocumentId ?? null,
    generationData: { cohortId: cohort.id, date: cohort.date, endDate: cohort.endDate, siteId: cohort.siteId, periods: periods.length },
    uploadedBy: ctx.user.id,
    isDemo: ctx.org.isDemo,
  });
  const now = new Date();
  await db.update(schema.examMembers).set({ status: row.member.result ? row.member.status : "convoque", convokedAt: now, convocationDocumentId: doc.id, updatedAt: now }).where(eq(schema.examMembers.id, row.member.id));
  let mail = "none";
  if (row.person.email) {
    const res = await sendMail({
      to: row.person.email,
      subject: `Convocation : ${cohort.label} (${fmtDate(cohort.date)})`,
      html: layoutMail("Votre convocation à l'examen", `<p>Bonjour ${row.person.firstName},</p><p>Vous êtes convoqué(e) à l'examen « ${cohort.label} » le ${fmtDate(cohort.date, "EEEE d MMMM yyyy")}${site ? ` à ${site.name}` : ""}. Votre convocation est disponible dans votre espace (Mes documents).</p>`),
      text: `Convocation à l'examen ${cohort.label} le ${fmtDate(cohort.date)}.`,
      isDemo: ctx.org.isDemo,
    });
    mail = res.status;
  }
  await recordEvidence({ orgId: ctx.org.id, indicatorCode: "IND_3", level: "individuel", title: `Convocation à l'examen ${cohort.code}`, sourceType: "exam_member", sourceId: row.member.id, evidenceDate: todayParis(), enrollmentId: row.enrollment.id, sessionId: row.enrollment.sessionId, documentId: doc.id, createdBy: ctx.user.id });
  await audit({ action: "cohort.member.convoke", userId: ctx.user.id, orgId: ctx.org.id, entityType: "exam_member", entityId: row.member.id, after: { documentId: doc.id, version: doc.version, mail } });
  return { documentId: doc.id, mail };
}

/** Convocation (PDF rattaché à l'inscription, e-mail) d'un membre ou de tous les membres de la cohorte sélectionnée. */
export async function convokeAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "exams.manage");
    const cohortId = uuid.parse(formData.get("cohortId"));
    const memberId = optUuid.parse(formData.get("memberId") ?? undefined);
    const cohort = await loadCohort(ctx.org.id, cohortId);
    if (!cohort) return { error: "Cohorte introuvable." };
    if (cohort.status === "annulee") return { error: "Cohorte annulée." };
    const ids = memberId ? [memberId] : (await db.select({ id: schema.examMembers.id }).from(schema.examMembers).where(and(eq(schema.examMembers.cohortId, cohort.id), eq(schema.examMembers.orgId, ctx.org.id), sql`${schema.examMembers.status} <> 'desiste'`)).orderBy(asc(schema.examMembers.createdAt))).map((m) => m.id);
    if (!ids.length) return { error: "Aucun membre à convoquer." };
    let n = 0;
    for (const id of ids) {
      const r = await convoke(ctx, cohort, id);
      if (!("skipped" in r)) n++;
    }
    if (!memberId && cohort.status !== "terminee") await db.update(schema.examCohorts).set({ status: "convoquee", updatedAt: new Date() }).where(eq(schema.examCohorts.id, cohort.id));
    paths(ctx, cohort.id);
    return { ok: true, message: `${n} convocation(s) générée(s)${ctx.org.isDemo ? " (démonstration : aucun e-mail ne part)" : ""}.` };
  } catch (e) {
    return fail(e, "Convocation impossible.");
  }
}

const resultSchema = z.object({
  cohortId: uuid,
  memberId: uuid,
  result: z.enum(["admis", "ajourne", "partiel", "rattrapage", "absent"]),
  score: z.preprocess((v) => (v === "" || v == null ? undefined : Number(v)), z.number().int().min(0).max(10000).optional()),
  observations: z.string().trim().max(2000).optional(),
  accommodations: z.string().trim().max(1000).optional(),
  blockResults: z.string().max(20000).optional(),
});

/** Résultat enregistré sur le bon membre de la bonne cohorte : le membre est rechargé par (cohortId, id, orgId). */
export async function recordResultAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "exams.manage");
    const d = resultSchema.parse(Object.fromEntries(formData));
    const cohort = await loadCohort(ctx.org.id, d.cohortId);
    if (!cohort) return { error: "Cohorte introuvable." };
    if (cohort.date > todayParis()) return { error: "L'examen n'a pas encore eu lieu : aucun résultat ne peut être enregistré par anticipation." };
    const allowed = resultAllowed(d.result as ExamResult, cohort.allowsPartial as { partial?: boolean; retake?: boolean });
    if (!allowed.ok) return { error: allowed.reason };
    const [m] = await db.select().from(schema.examMembers).where(and(eq(schema.examMembers.id, d.memberId), eq(schema.examMembers.cohortId, cohort.id), eq(schema.examMembers.orgId, ctx.org.id))).limit(1);
    if (!m) return { error: "Membre introuvable dans la cohorte sélectionnée." };
    let blockResults: { code: string; result: string; score?: number | null }[] = [];
    if (d.blockResults?.trim()) {
      const parsed = z.array(z.object({ code: z.string().min(1), result: z.enum(["admis", "ajourne", "absent"]), score: z.number().nullable().optional() })).safeParse(JSON.parse(d.blockResults));
      if (!parsed.success) return { error: "Résultats par bloc invalides." };
      blockResults = parsed.data;
    } else {
      // Formulaire par bloc : champs block:<code>
      for (const [k, v] of formData.entries()) {
        if (k.startsWith("block:") && typeof v === "string" && v) blockResults.push({ code: k.slice(6), result: v });
      }
    }
    const now = new Date();
    const examState = examStateForResult(d.result as ExamResult);
    await db.transaction(async (tx) => {
      await tx
        .update(schema.examMembers)
        .set({ result: d.result, status: d.result === "absent" ? "absent" : "present", score: d.score ?? null, observations: d.observations || null, accommodations: d.accommodations || null, blockResults, resultRecordedBy: ctx.user.id, resultRecordedAt: now, updatedAt: now })
        .where(and(eq(schema.examMembers.id, m.id), eq(schema.examMembers.cohortId, cohort.id), eq(schema.examMembers.orgId, ctx.org.id)));
      await tx.update(schema.enrollments).set({ examState, updatedAt: now }).where(and(eq(schema.enrollments.id, m.enrollmentId), eq(schema.enrollments.orgId, ctx.org.id)));
      await tx.insert(schema.enrollmentEvents).values({ enrollmentId: m.enrollmentId, kind: "examen", fromValue: m.result ?? null, toValue: d.result, reason: `Cohorte ${cohort.code}`, userId: ctx.user.id });
    });
    if (d.result === "rattrapage" || d.result === "partiel") {
      await createTaskOnce({ orgId: ctx.org.id, title: `Rattrapage à organiser : ${cohort.code}`, family: "examen", entityType: "enrollment", entityId: m.enrollmentId, href: `/app/${ctx.org.id}/examens/${cohort.id}`, assigneeRole: "pedagogy_manager", idempotencyKey: `exam:${m.id}:rattrapage`, createdBy: ctx.user.id, isDemo: ctx.org.isDemo });
    }
    await recordEvidence({ orgId: ctx.org.id, indicatorCode: "IND_11", level: "individuel", title: `Résultat d'examen ${cohort.code} : ${d.result}`, sourceType: "exam_member", sourceId: m.id, evidenceDate: cohort.date, enrollmentId: m.enrollmentId, createdBy: ctx.user.id });
    await audit({ action: "cohort.result.record", userId: ctx.user.id, orgId: ctx.org.id, entityType: "exam_member", entityId: m.id, before: { result: m.result, score: m.score }, after: { cohortId: cohort.id, result: d.result, score: d.score, examState, blocks: blockResults.length } });
    paths(ctx, cohort.id);
    return { ok: true, message: `Résultat « ${d.result} » enregistré sur ce membre de la cohorte ${cohort.code}.` };
  } catch (e) {
    return fail(e, "Enregistrement impossible.");
  }
}
