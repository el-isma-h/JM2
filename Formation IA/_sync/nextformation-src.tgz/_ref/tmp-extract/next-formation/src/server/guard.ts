import "server-only";
import { notFound, redirect } from "next/navigation";
import { AuthError } from "./auth";
import { requireOrg, requireOwner, requirePlatformAdmin, type OrgContext, type Permission } from "./authz";

/**
 * À utiliser dans les pages serveur : vérifie l'accès et redirige proprement
 * (connexion, vérification e-mail, vérification renforcée) au lieu de lever une erreur.
 */
export async function guardOrg(orgId: string, nextPath: string, ...perms: Permission[]): Promise<OrgContext> {
  try {
    return await requireOrg(orgId, ...perms);
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}

/** Pages réservées au propriétaire actif (sécurité, charte, RIB central en gestion). */
export async function guardOwner(orgId: string, nextPath: string): Promise<OrgContext> {
  try {
    return await requireOwner(orgId);
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}

export async function guardAdmin(nextPath: string) {
  try {
    return await requirePlatformAdmin();
  } catch (e) {
    handleAuthError(e, nextPath);
    throw e;
  }
}

export function handleAuthError(e: unknown, nextPath: string): never {
  if (e instanceof AuthError) {
    if (e.code === "unauthenticated") redirect(`/connexion?next=${encodeURIComponent(nextPath)}`);
    if (e.code === "email_unverified") redirect("/verification");
    if (e.code === "elevation_required") redirect(`/securite?next=${encodeURIComponent(nextPath)}`);
    notFound();
  }
  throw e;
}

/** Dans une server action : convertit une AuthError en message lisible. */
export function authErrorMessage(e: unknown): string | null {
  if (e instanceof AuthError) {
    return {
      unauthenticated: "Session expirée : reconnectez-vous.",
      forbidden: "Vous n'avez pas l'habilitation nécessaire pour cette action.",
      elevation_required: "Cette action demande une vérification renforcée (code d'authentification).",
      email_unverified: "Vérifiez votre adresse e-mail avant de continuer.",
    }[e.code];
  }
  return null;
}
