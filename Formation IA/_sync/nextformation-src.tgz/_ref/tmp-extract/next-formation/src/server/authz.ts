import "server-only";
import { and, eq, inArray, isNull } from "drizzle-orm";
import { cache } from "react";
import { db, schema } from "@/db";
import { ORG_ROLES, type OrgRole } from "@/db/schema/tenancy";
import { AuthError, getCurrentUser, requireUser, type SessionUser } from "./auth";
import { emailAccessOk } from "@/lib/env";

export type { OrgRole };

/**
 * Permissions (CDC §8). Les rôles sont additifs ; leur cumul ne confère jamais le statut de propriétaire.
 * Les actions de sécurité et la charte (S01, F10) exigent le propriétaire actif, vérifié indépendamment
 * de users.manage / roles.manage / audit.view.
 */
export type Permission =
  | "org.view"
  | "users.view"
  | "users.manage"
  | "roles.view"
  | "roles.manage"
  | "audit.view"
  | "crm.view"
  | "crm.manage"
  | "candidates.cv.view"
  | "catalog.view"
  | "catalog.manage"
  | "sessions.view"
  | "sessions.manage"
  | "enrollments.view"
  | "enrollments.manage"
  | "dossier.admin_docs.view"
  | "dossier.admin_docs.manage"
  | "dossier.internal.view"
  | "dossier.pedagogy.view"
  | "dossier.pedagogy.manage"
  | "planning.view"
  | "planning.manage"
  | "attendance.record"
  | "attendance.close"
  | "attendance.correct"
  | "exams.view"
  | "exams.manage"
  | "documents.view"
  | "documents.generate"
  | "finance.view"
  | "finance.manage"
  | "quality.view"
  | "quality.manage"
  | "tasks.view_all"
  | "tasks.manage"
  | "dashboards.view"
  | "exports.run"
  | "integrations.manage"
  | "self.view";

const ALL_OPERATIONAL: Permission[] = [
  "org.view", "users.view", "roles.view", "crm.view", "crm.manage", "candidates.cv.view", "catalog.view", "catalog.manage",
  "sessions.view", "sessions.manage", "enrollments.view", "enrollments.manage", "dossier.admin_docs.view", "dossier.admin_docs.manage",
  "dossier.internal.view", "dossier.pedagogy.view", "dossier.pedagogy.manage", "planning.view", "planning.manage", "attendance.record",
  "attendance.close", "attendance.correct", "exams.view", "exams.manage", "documents.view", "documents.generate", "finance.view",
  "finance.manage", "quality.view", "quality.manage", "tasks.view_all", "tasks.manage", "dashboards.view", "exports.run", "self.view",
];

/** Matrice rôles → permissions (ajustable par membre via `memberships.permissions`). */
export const ROLE_MATRIX: Record<OrgRole, Permission[]> = {
  direction: ALL_OPERATIONAL,
  agency_manager: [
    "org.view", "users.view", "crm.view", "crm.manage", "catalog.view", "sessions.view", "sessions.manage", "enrollments.view", "enrollments.manage",
    "dossier.admin_docs.view", "dossier.internal.view", "dossier.pedagogy.view", "planning.view", "planning.manage", "attendance.record", "attendance.close",
    "exams.view", "documents.view", "documents.generate", "quality.view", "tasks.view_all", "tasks.manage", "dashboards.view", "self.view",
  ],
  pedagogy_manager: [
    "org.view", "catalog.view", "catalog.manage", "sessions.view", "sessions.manage", "enrollments.view", "dossier.internal.view", "dossier.pedagogy.view",
    "dossier.pedagogy.manage", "planning.view", "planning.manage", "attendance.record", "attendance.close", "attendance.correct", "exams.view", "exams.manage",
    "documents.view", "documents.generate", "quality.view", "tasks.view_all", "tasks.manage", "dashboards.view", "self.view",
  ],
  trainer: ["org.view", "sessions.view", "planning.view", "attendance.record", "attendance.close", "dossier.pedagogy.view", "dossier.pedagogy.manage", "documents.view", "self.view"],
  admin_staff: [
    "org.view", "crm.view", "catalog.view", "sessions.view", "enrollments.view", "enrollments.manage", "dossier.admin_docs.view", "dossier.admin_docs.manage",
    "planning.view", "exams.view", "documents.view", "documents.generate", "tasks.manage", "dashboards.view", "self.view",
  ],
  finance: ["org.view", "enrollments.view", "finance.view", "finance.manage", "documents.view", "documents.generate", "dashboards.view", "exports.run", "tasks.manage", "self.view"],
  quality: ["org.view", "catalog.view", "sessions.view", "enrollments.view", "planning.view", "documents.view", "quality.view", "quality.manage", "tasks.view_all", "tasks.manage", "dashboards.view", "self.view"],
  auditor: ["org.view", "catalog.view", "sessions.view", "quality.view", "documents.view", "self.view"],
  sales: ["org.view", "crm.view", "crm.manage", "catalog.view", "sessions.view", "enrollments.view", "tasks.manage", "dashboards.view", "self.view"],
  learner: ["self.view"],
  employer: ["self.view"],
};

/** Permissions nécessitant une session renforcée (TOTP récent) : exports massifs et gestion de sécurité. */
export const SENSITIVE: Permission[] = ["exports.run", "users.manage", "roles.manage"];

/** Rôles qui ouvrent l'accès au back-office (espace organisme). */
export const STAFF_ROLES: OrgRole[] = ["direction", "agency_manager", "pedagogy_manager", "trainer", "admin_staff", "finance", "quality", "auditor", "sales"];

export type OrgContext = {
  user: SessionUser;
  org: typeof schema.organismes.$inferSelect;
  tenant: typeof schema.tenants.$inferSelect;
  membership: typeof schema.memberships.$inferSelect | null;
  roles: OrgRole[];
  /** Propriétaire actif du tenant (S01) : vérifié indépendamment des rôles et permissions. */
  isOwner: boolean;
  permissions: Set<Permission>;
  /** Identifiant formateur rattaché (périmètre 0045) ; null si l'utilisateur n'est pas formateur. */
  trainerId: string | null;
  personId: string | null;
  companyId: string | null;
  /** Vrai si l'utilisateur est « formateur seul » : accès limité aux séances et apprenants affectés. */
  trainerOnly: boolean;
  isPlatformAdmin: boolean;
};

function parseRoles(v: unknown): OrgRole[] {
  if (!Array.isArray(v)) return [];
  return v.filter((r): r is OrgRole => typeof r === "string" && (ORG_ROLES as readonly string[]).includes(r));
}

export function permissionsForRoles(roles: OrgRole[], extra: Partial<Record<Permission, boolean>> = {}): Set<Permission> {
  const set = new Set<Permission>();
  for (const r of roles) for (const p of ROLE_MATRIX[r] ?? []) set.add(p);
  for (const [k, v] of Object.entries(extra)) {
    if (v) set.add(k as Permission);
    else set.delete(k as Permission);
  }
  return set;
}

/** Contexte d'accès à un organisme pour l'utilisateur courant. null si aucun accès. */
export const getOrgContext = cache(async (orgId: string): Promise<OrgContext | null> => {
  const user = await getCurrentUser();
  if (!user) return null;
  if (!/^[0-9a-f-]{36}$/i.test(orgId)) return null;
  const [org] = await db.select().from(schema.organismes).where(eq(schema.organismes.id, orgId)).limit(1);
  if (!org) return null;
  const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, org.tenantId)).limit(1);
  if (!tenant) return null;

  const [m] = await db
    .select()
    .from(schema.memberships)
    .where(and(eq(schema.memberships.orgId, orgId), eq(schema.memberships.userId, user.id), eq(schema.memberships.active, true)))
    .limit(1);
  const isPlatformAdmin = user.platformRole === "platform_admin";
  const membership = m && (!m.expiresAt || m.expiresAt > new Date()) ? m : null;
  if (!membership && !isPlatformAdmin) return null;

  const roles = membership ? parseRoles(membership.roles) : (["direction"] as OrgRole[]);
  const extra = (membership?.permissions as Partial<Record<Permission, boolean>>) ?? {};
  const permissions = permissionsForRoles(roles, extra);
  /** Propriétaire actif : désigné sur l'organisme, membre actif, compte actif. L'admin plateforme n'est jamais owner d'un tenant. */
  const isOwner = Boolean(membership && org.ownerUserId === user.id);
  if (isOwner) for (const p of ALL_OPERATIONAL) permissions.add(p);
  if (isOwner) for (const p of ["users.manage", "roles.manage", "audit.view", "integrations.manage"] as Permission[]) permissions.add(p);

  const trainerOnly = roles.length === 1 && roles[0] === "trainer" && !isOwner;
  // Rattachement formateur : la membership d'abord, sinon la fiche formateur portant ce compte (repli).
  let trainerId = membership?.trainerId ?? null;
  if (!trainerId && roles.includes("trainer")) {
    const [tr] = await db
      .select({ id: schema.trainers.id })
      .from(schema.trainers)
      .where(and(eq(schema.trainers.orgId, orgId), eq(schema.trainers.userId, user.id)))
      .limit(1);
    trainerId = tr?.id ?? null;
  }
  return {
    user,
    org,
    tenant,
    membership,
    roles,
    isOwner,
    permissions,
    trainerId,
    personId: membership?.personId ?? null,
    companyId: membership?.companyId ?? null,
    trainerOnly,
    isPlatformAdmin,
  };
});

/** Contrôle côté serveur : lève AuthError si l'accès n'est pas autorisé. */
export async function requireOrg(orgId: string, ...perms: Permission[]): Promise<OrgContext> {
  const user = await requireUser();
  if (!emailAccessOk(user)) throw new AuthError("email_unverified");
  const ctx = await getOrgContext(orgId);
  if (!ctx) throw new AuthError("forbidden");
  for (const p of perms) {
    if (!ctx.permissions.has(p)) throw new AuthError("forbidden");
    if (SENSITIVE.includes(p) && !ctx.user.elevated) throw new AuthError("elevation_required");
  }
  return ctx;
}

/**
 * S01 : administration de la sécurité et charte institutionnelle réservées au propriétaire actif,
 * quelles que soient les permissions users.manage / roles.manage / audit.view.
 */
export async function requireOwner(orgId: string): Promise<OrgContext> {
  const ctx = await requireOrg(orgId);
  if (!ctx.isOwner) throw new AuthError("forbidden");
  return ctx;
}

export function assertOwner(ctx: OrgContext) {
  if (!ctx.isOwner) throw new AuthError("forbidden");
}

export function hasRole(ctx: OrgContext, ...roles: OrgRole[]) {
  return roles.some((r) => ctx.roles.includes(r));
}

export async function requirePlatformAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.platformRole !== "platform_admin") throw new AuthError("forbidden");
  return user;
}

/** Organismes accessibles à l'utilisateur courant (affectations actives ; admin plateforme : tous). */
export async function listAccessibleOrgs(user: SessionUser) {
  if (user.platformRole === "platform_admin") {
    return db.select().from(schema.organismes).orderBy(schema.organismes.legalName);
  }
  const rows = await db
    .select({ o: schema.organismes, roles: schema.memberships.roles })
    .from(schema.memberships)
    .innerJoin(schema.organismes, eq(schema.organismes.id, schema.memberships.orgId))
    .where(and(eq(schema.memberships.userId, user.id), eq(schema.memberships.active, true)));
  return rows
    .filter((r) => parseRoles(r.roles).some((role) => STAFF_ROLES.includes(role)))
    .map((r) => r.o)
    .sort((a, b) => a.legalName.localeCompare(b.legalName));
}

/** Affectations extranet (apprenant / employeur) de l'utilisateur courant. */
export async function listExtranetMemberships(user: SessionUser) {
  const rows = await db
    .select({ m: schema.memberships, o: schema.organismes })
    .from(schema.memberships)
    .innerJoin(schema.organismes, eq(schema.organismes.id, schema.memberships.orgId))
    .where(and(eq(schema.memberships.userId, user.id), eq(schema.memberships.active, true)));
  return rows.filter((r) => parseRoles(r.m.roles).some((role) => role === "learner" || role === "employer"));
}

/**
 * Périmètre formateur (0045) : identifiants des sessions auxquelles le formateur est affecté.
 * Un formateur non affecté ne voit aucun apprenant et ne peut pas s'attribuer une affectation par écriture directe.
 */
export async function trainerSessionIds(ctx: OrgContext): Promise<string[] | null> {
  if (!ctx.trainerOnly) return null;
  if (!ctx.trainerId) return [];
  const rows = await db
    .select({ sessionId: schema.sessionTrainers.sessionId })
    .from(schema.sessionTrainers)
    .where(and(eq(schema.sessionTrainers.orgId, ctx.org.id), eq(schema.sessionTrainers.trainerId, ctx.trainerId)));
  const viaSlots = await db
    .select({ sessionId: schema.slots.sessionId })
    .from(schema.slots)
    .where(and(eq(schema.slots.orgId, ctx.org.id), eq(schema.slots.trainerId, ctx.trainerId)));
  return [...new Set([...rows.map((r) => r.sessionId), ...viaSlots.map((r) => r.sessionId)])];
}

/** Vérifie qu'une session est dans le périmètre (formateur seul) ; les autres rôles passent. */
export async function assertSessionInScope(ctx: OrgContext, sessionId: string) {
  const ids = await trainerSessionIds(ctx);
  if (ids && !ids.includes(sessionId)) throw new AuthError("forbidden");
}

/** Vérifie qu'une inscription est dans le périmètre formateur (session affectée). */
export async function assertEnrollmentInScope(ctx: OrgContext, enrollmentId: string) {
  const ids = await trainerSessionIds(ctx);
  if (!ids) return;
  const [e] = await db
    .select({ sessionId: schema.enrollments.sessionId })
    .from(schema.enrollments)
    .where(and(eq(schema.enrollments.id, enrollmentId), eq(schema.enrollments.orgId, ctx.org.id), ids.length ? inArray(schema.enrollments.sessionId, ids) : isNull(schema.enrollments.id)))
    .limit(1);
  if (!e) throw new AuthError("forbidden");
}

export const roleLabels: Record<OrgRole, string> = {
  direction: "Direction",
  agency_manager: "Responsable d'agence",
  pedagogy_manager: "Responsable pédagogique",
  trainer: "Formateur",
  admin_staff: "Administratif",
  finance: "Finance",
  quality: "Qualité",
  auditor: "Auditeur (lecture seule)",
  sales: "Commercial / recrutement",
  learner: "Apprenant",
  employer: "Entreprise / tuteur",
};

export const permissionLabels: Record<Permission, string> = {
  "org.view": "Consulter l'organisme",
  "users.view": "Voir les utilisateurs",
  "users.manage": "Gérer les utilisateurs (propriétaire)",
  "roles.view": "Voir les rôles",
  "roles.manage": "Gérer les rôles (propriétaire)",
  "audit.view": "Consulter le journal d'audit",
  "crm.view": "Consulter le CRM",
  "crm.manage": "Gérer entreprises, contacts et besoins",
  "candidates.cv.view": "Consulter les CV et notes sensibles",
  "catalog.view": "Consulter le catalogue",
  "catalog.manage": "Gérer le catalogue et les programmes",
  "sessions.view": "Consulter les sessions",
  "sessions.manage": "Gérer les sessions et groupes",
  "enrollments.view": "Consulter les inscriptions",
  "enrollments.manage": "Gérer les inscriptions",
  "dossier.admin_docs.view": "Consulter les pièces administratives",
  "dossier.admin_docs.manage": "Gérer les pièces administratives",
  "dossier.internal.view": "Consulter les informations internes",
  "dossier.pedagogy.view": "Consulter le suivi pédagogique",
  "dossier.pedagogy.manage": "Gérer le suivi pédagogique",
  "planning.view": "Consulter le planning",
  "planning.manage": "Planifier et affecter",
  "attendance.record": "Saisir les présences",
  "attendance.close": "Clôturer les périodes",
  "attendance.correct": "Décider des corrections exceptionnelles",
  "exams.view": "Consulter les examens",
  "exams.manage": "Gérer les cohortes et résultats",
  "documents.view": "Consulter les documents",
  "documents.generate": "Générer et transmettre des documents",
  "finance.view": "Consulter la finance",
  "finance.manage": "Gérer financements, factures et règlements",
  "quality.view": "Consulter la qualité",
  "quality.manage": "Gérer preuves, analyses et actions qualité",
  "tasks.view_all": "Superviser toutes les tâches",
  "tasks.manage": "Créer et traiter des tâches",
  "dashboards.view": "Consulter le pilotage",
  "exports.run": "Exporter des données (renforcé)",
  "integrations.manage": "Gérer les intégrations",
  "self.view": "Accéder à son espace",
};
