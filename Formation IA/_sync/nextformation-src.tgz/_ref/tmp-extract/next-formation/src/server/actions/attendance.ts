"use server";

import { createHmac, randomInt } from "node:crypto";
import { revalidatePath } from "next/cache";
import { headers } from "next/headers";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import QRCode from "qrcode";
import { db, schema } from "@/db";
import { appUrl } from "@/lib/env";
import { randomToken, safeEqual, sha256 } from "@/lib/crypto";
import { serverNow } from "@/lib/time";
import { fmtDate } from "@/lib/dates";
import { audit } from "@/server/audit";
import { assertSessionInScope, requireOrg, type OrgContext } from "@/server/authz";
import { authErrorMessage } from "@/server/guard";
import { createDocument } from "@/server/documents/store";
import { checkUpload } from "@/server/documents/upload-rules";
import { layoutMail, sendMail } from "@/server/mail";
import { getObject, putObject } from "@/server/storage";
import { recordEvidence } from "@/server/quality/evidence";
import { canCloseOrSign, canEditDirectly, canRecordAttendance } from "@/server/planning/hours";
import { currentAttendances, expectedEnrollments, loadPeriod, minutesFor } from "@/server/planning/service";
import { renderAttendanceSheetPdf } from "@/server/planning/pdf";
import { statusMeta } from "@/components/ui/badge";
import type { ActionState } from "./auth";

const uuid = z.string().uuid("Identifiant invalide");
const hhmm = z.string().regex(/^\d{2}:\d{2}$/, "Heure invalide (HH:mm)");
const optTime = z.preprocess((v) => (v === "" || v == null ? undefined : v), hhmm.optional());
const attendanceStatus = z.enum(["present", "retard", "depart_anticipe", "retard_et_depart", "absent", "absent_justifie", "excuse"]);

function fail(e: unknown, fallback: string): ActionState {
  if (e instanceof z.ZodError) return { error: e.issues[0]?.message ?? "Paramètres invalides." };
  return { error: authErrorMessage(e) ?? (e instanceof Error && e.message ? e.message : fallback) };
}

async function orgIdOf(formData: FormData) {
  return uuid.parse(formData.get("orgId"));
}

/** Charge la période de l'organisme et vérifie le périmètre formateur (un non affecté ne lit ni n'écrit). */
async function loadPeriodInScope(ctx: OrgContext, periodId: string) {
  const row = await loadPeriod(ctx.org.id, periodId);
  if (!row) throw new Error("Période introuvable.");
  await assertSessionInScope(ctx, row.session.id);
  return row;
}

function timing(row: { period: { startTime: string; endTime: string; status: "prevue" | "ouverte" | "cloturee" | "annulee" }; slot: { date: string } }) {
  return { date: row.slot.date, startTime: row.period.startTime, endTime: row.period.endTime, status: row.period.status };
}

async function requestIp() {
  try {
    const h = await headers();
    const raw = (h.get("x-forwarded-for") ?? "").split(",")[0].trim();
    return raw && /^[0-9a-f.:]+$/i.test(raw) ? raw : null;
  } catch {
    return null;
  }
}

/** Décode une signature PNG (data URL) : image PNG, 400 Ko maximum. */
function decodeSignature(dataUrl: unknown): Buffer | null {
  if (typeof dataUrl !== "string" || !dataUrl.startsWith("data:image/png;base64,")) return null;
  const buf = Buffer.from(dataUrl.slice("data:image/png;base64,".length), "base64");
  if (buf.length < 100 || buf.length > 400 * 1024) return null;
  if (buf[0] !== 0x89 || buf[1] !== 0x50 || buf[2] !== 0x4e || buf[3] !== 0x47) return null;
  return buf;
}

/** Lien de signature par e-mail : HMAC (période, inscription) avec le secret applicatif, invérifiable sans lui. */
function signLinkKey(periodId: string, enrollmentId: string) {
  return createHmac("sha256", process.env.APP_SECRET ?? "next-formation-dev").update(`emarger:${periodId}:${enrollmentId}`).digest("hex").slice(0, 40);
}

/* ---------- Ouverture (préparation) ---------- */

/** Ouverture de la feuille : possible avant la séance (préparation). Génère le jeton public de la page QR. */
export async function openPeriodAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.record");
    const periodId = uuid.parse(formData.get("periodId"));
    const row = await loadPeriodInScope(ctx, periodId);
    if (row.period.status === "cloturee") return { error: "Période clôturée." };
    if (row.period.status === "annulee") return { error: "Période annulée." };
    if (row.slot.status === "annulee") return { error: "Séance annulée." };
    if (row.period.status === "ouverte") return { ok: true, message: "La feuille est déjà ouverte." };
    await db
      .update(schema.periods)
      .set({ status: "ouverte", openedAt: new Date(), openedBy: ctx.user.id, publicToken: row.period.publicToken ?? randomToken(18), updatedAt: new Date() })
      .where(eq(schema.periods.id, periodId));
    await audit({ action: "period.open", userId: ctx.user.id, orgId: ctx.org.id, entityType: "period", entityId: periodId, before: { status: row.period.status }, after: { status: "ouverte" } });
    revalidatePath(`/app/${ctx.org.id}/emargement/${periodId}`);
    revalidatePath(`/app/${ctx.org.id}/emargement`);
    return { ok: true, message: "Feuille d'émargement ouverte. Les présences se saisissent à partir du début réel de la période." };
  } catch (e) {
    return fail(e, "Ouverture impossible.");
  }
}

/* ---------- Saisie des présences ---------- */

/** Crée ou met à jour la ligne courante (une seule par période × inscription) : idempotent. */
async function upsertAttendance(
  ctx: { orgId: string; userId: string | null },
  period: { id: string; startTime: string; endTime: string; breakMinutes: number },
  enrollmentId: string,
  values: Partial<typeof schema.attendances.$inferInsert> & { status: (typeof schema.attendanceStatusEnum.enumValues)[number] },
) {
  const [existing] = await db
    .select()
    .from(schema.attendances)
    .where(and(eq(schema.attendances.orgId, ctx.orgId), eq(schema.attendances.periodId, period.id), eq(schema.attendances.enrollmentId, enrollmentId), eq(schema.attendances.isCurrent, true)))
    .limit(1);
  const minutesCounted = minutesFor(period, { status: values.status, arrivedAt: values.arrivedAt ?? existing?.arrivedAt, leftAt: values.leftAt ?? existing?.leftAt });
  if (existing) {
    const [upd] = await db
      .update(schema.attendances)
      .set({ ...values, minutesCounted, recordedBy: ctx.userId, recordedAt: new Date(), updatedAt: new Date() })
      .where(eq(schema.attendances.id, existing.id))
      .returning();
    return { row: upd, before: existing };
  }
  const [ins] = await db
    .insert(schema.attendances)
    .values({ orgId: ctx.orgId, periodId: period.id, enrollmentId, ...values, minutesCounted, recordedBy: ctx.userId, recordedAt: new Date(), isCurrent: true })
    .onConflictDoNothing()
    .returning();
  if (ins) return { row: ins, before: null };
  // Envoi simultané : la ligne vient d'être créée par une autre requête, on la met à jour.
  return upsertAttendance(ctx, period, enrollmentId, values);
}

const recordSchema = z.object({
  periodId: uuid,
  enrollmentId: uuid,
  status: attendanceStatus,
  arrivedAt: optTime,
  leftAt: optTime,
  justificationNote: z.string().trim().max(500).optional(),
});

/** Saisie d'une présence par le formateur ou l'administratif : seulement après le début réel (heure serveur Paris). */
export async function recordAttendanceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.record");
    const d = recordSchema.parse(Object.fromEntries(formData));
    const row = await loadPeriodInScope(ctx, d.periodId);
    const rule = canRecordAttendance(timing(row), serverNow());
    if (!rule.ok) return { error: rule.reason };
    if (row.period.status !== "ouverte") return { error: "Ouvrez d'abord la feuille d'émargement." };
    const expected = await expectedEnrollments(ctx.org.id, row.session.id, row.slot.groupId);
    const target = expected.find((e) => e.enrollment.id === d.enrollmentId);
    if (!target) return { error: "Cette inscription n'est pas attendue à cette période." };
    if ((d.status === "retard" || d.status === "retard_et_depart") && !d.arrivedAt) return { error: "Indiquez l'heure d'arrivée." };
    if ((d.status === "depart_anticipe" || d.status === "retard_et_depart") && !d.leftAt) return { error: "Indiquez l'heure de départ." };
    if (d.status === "absent_justifie" && !d.justificationNote) return { error: "Indiquez le motif de l'absence justifiée." };

    let justificationDocumentId: string | null = null;
    const file = formData.get("justificatif");
    if (file instanceof File && file.size > 0) {
      if (d.status !== "absent_justifie") return { error: "Un justificatif accompagne une absence justifiée." };
      const buf = Buffer.from(await file.arrayBuffer());
      const check = checkUpload({ name: file.name, type: file.type, size: file.size, head: buf.subarray(0, 8) });
      if (!check.ok) return { error: check.error };
      const doc = await createDocument({
        orgId: ctx.org.id,
        enrollmentId: d.enrollmentId,
        personId: target.person.id,
        sessionId: row.session.id,
        category: "justificatif",
        visibility: "administratif",
        status: "valide",
        title: `Justificatif d'absence du ${fmtDate(row.slot.date)}`,
        fileName: file.name,
        mimeType: check.mime,
        data: buf,
        sourceType: "period",
        sourceId: d.periodId,
        uploadedBy: ctx.user.id,
        isDemo: ctx.org.isDemo,
      });
      justificationDocumentId = doc.id;
    }
    const values: Parameters<typeof upsertAttendance>[3] = {
      status: d.status,
      arrivedAt: d.status === "retard" || d.status === "retard_et_depart" ? d.arrivedAt : null,
      leftAt: d.status === "depart_anticipe" || d.status === "retard_et_depart" ? d.leftAt : null,
      justificationNote: d.status === "absent_justifie" ? d.justificationNote : null,
      ...(justificationDocumentId ? { justificationDocumentId } : {}),
    };
    const { row: att, before } = await upsertAttendance({ orgId: ctx.org.id, userId: ctx.user.id }, row.period, d.enrollmentId, values);
    await audit({ action: "attendance.record", userId: ctx.user.id, orgId: ctx.org.id, entityType: "attendance", entityId: att.id, before: before ? { status: before.status, minutesCounted: before.minutesCounted } : null, after: { status: att.status, minutesCounted: att.minutesCounted } });
    revalidatePath(`/app/${ctx.org.id}/emargement/${d.periodId}`);
    return { ok: true, message: `${statusMeta[att.status]?.label ?? att.status} : ${att.minutesCounted} min comptées.` };
  } catch (e) {
    return fail(e, "Saisie impossible.");
  }
}

/** Signature de l'apprenant sur tablette (canvas) : image PNG stockée, méthode « tablette ». Présence requise (après début réel). */
export async function signLearnerTabletAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.record");
    const periodId = uuid.parse(formData.get("periodId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const sig = decodeSignature(formData.get("signature"));
    if (!sig) return { error: "Signature manquante ou illisible : signez dans le cadre puis validez." };
    const row = await loadPeriodInScope(ctx, periodId);
    const rule = canRecordAttendance(timing(row), serverNow());
    if (!rule.ok) return { error: rule.reason };
    if (row.period.status !== "ouverte") return { error: "Ouvrez d'abord la feuille d'émargement." };
    const expected = await expectedEnrollments(ctx.org.id, row.session.id, row.slot.groupId);
    if (!expected.some((e) => e.enrollment.id === enrollmentId)) return { error: "Cette inscription n'est pas attendue à cette période." };
    const current = (await currentAttendances(ctx.org.id, periodId)).find((a) => a.enrollmentId === enrollmentId);
    if (current && (current.status === "absent" || current.status === "absent_justifie" || current.status === "excuse")) return { error: "Cet apprenant est enregistré absent : modifiez d'abord sa présence." };
    const key = `${ctx.org.id}/signatures/${periodId}/${enrollmentId}-${randomToken(6)}.png`;
    await putObject(key, sig);
    const status = current && current.status !== "non_saisie" ? current.status : "present";
    const { row: att } = await upsertAttendance({ orgId: ctx.org.id, userId: ctx.user.id }, row.period, enrollmentId, { status, learnerSignedAt: new Date(), signatureKey: key, signatureMethod: "tablette", signatureIp: await requestIp() });
    await audit({ action: "attendance.sign", userId: ctx.user.id, orgId: ctx.org.id, entityType: "attendance", entityId: att.id, after: { method: "tablette" } });
    revalidatePath(`/app/${ctx.org.id}/emargement/${periodId}`);
    return { ok: true, message: "Signature enregistrée." };
  } catch (e) {
    return fail(e, "Signature impossible.");
  }
}

/* ---------- QR code tournant et lien e-mail ---------- */

const CODE_TTL_MS = 2 * 60 * 1000;

/** Code à 6 chiffres renouvelé toutes les 2 minutes (hash stocké), page publique /emarger/[token]. */
export async function getSignCodeAction(orgId: string, periodId: string): Promise<{ error?: string; code?: string; expiresAt?: string; url?: string; qr?: string }> {
  try {
    const ctx = await requireOrg(uuid.parse(orgId), "attendance.record");
    const row = await loadPeriodInScope(ctx, uuid.parse(periodId));
    if (row.period.status !== "ouverte") return { error: "Ouvrez d'abord la feuille." };
    const rule = canRecordAttendance(timing(row), serverNow());
    if (!rule.ok) return { error: rule.reason };
    const token = row.period.publicToken ?? randomToken(18);
    const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
    const expiresAt = new Date(Date.now() + CODE_TTL_MS);
    await db.update(schema.periods).set({ signCodeHash: sha256(`${row.period.id}:${code}`), signCodeExpiresAt: expiresAt, publicToken: token }).where(eq(schema.periods.id, row.period.id));
    const url = `${appUrl()}/emarger/${token}`;
    const qr = await QRCode.toDataURL(url, { margin: 1, width: 220, color: { dark: "#0a0b0d", light: "#ffffff" } });
    return { code, expiresAt: expiresAt.toISOString(), url, qr };
  } catch (e) {
    return { error: authErrorMessage(e) ?? (e instanceof Error ? e.message : "Erreur") };
  }
}

/** Envoi aux inscrits d'un lien de signature personnel par e-mail (en démo, rien ne part). */
export async function sendSignLinksAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.record");
    const periodId = uuid.parse(formData.get("periodId"));
    const row = await loadPeriodInScope(ctx, periodId);
    if (row.period.status !== "ouverte") return { error: "Ouvrez d'abord la feuille." };
    const rule = canRecordAttendance(timing(row), serverNow());
    if (!rule.ok) return { error: rule.reason };
    const token = row.period.publicToken ?? randomToken(18);
    if (!row.period.publicToken) await db.update(schema.periods).set({ publicToken: token }).where(eq(schema.periods.id, periodId));
    const expected = await expectedEnrollments(ctx.org.id, row.session.id, row.slot.groupId);
    let sent = 0;
    let missing = 0;
    for (const e of expected) {
      if (!e.person.email) {
        missing++;
        continue;
      }
      const url = `${appUrl()}/emarger/${token}?e=${e.enrollment.id}&k=${signLinkKey(periodId, e.enrollment.id)}`;
      await sendMail({
        to: e.person.email,
        subject: `Émargement : ${row.session.title} (${fmtDate(row.slot.date)}, ${row.period.startTime}-${row.period.endTime})`,
        html: layoutMail("Signez votre présence", `<p>Bonjour ${e.person.firstName},</p><p>Confirmez votre présence à la période du ${fmtDate(row.slot.date)} de ${row.period.startTime} à ${row.period.endTime} (${row.session.title}). Ce lien vous est personnel.</p>`, { label: "Signer ma présence", url }),
        text: `Signez votre présence : ${url}`,
        isDemo: ctx.org.isDemo,
      });
      sent++;
    }
    await audit({ action: "period.sign_links.send", userId: ctx.user.id, orgId: ctx.org.id, entityType: "period", entityId: periodId, after: { sent, missing } });
    return { ok: true, message: ctx.org.isDemo ? `${sent} lien(s) préparé(s) (démonstration : aucun e-mail ne part).` : `${sent} lien(s) envoyé(s)${missing ? `, ${missing} inscrit(s) sans adresse e-mail` : ""}.` };
  } catch (e) {
    return fail(e, "Envoi impossible.");
  }
}

const publicSignSchema = z.object({
  token: z.string().min(8).max(64),
  email: z.string().trim().toLowerCase().email("Adresse e-mail invalide").optional().or(z.literal("")),
  code: z.string().trim().regex(/^\d{6}$/, "Code à 6 chiffres attendu").optional().or(z.literal("")),
  e: z.string().uuid().optional().or(z.literal("")),
  k: z.string().max(80).optional().or(z.literal("")),
});

/** Signature publique (QR + code tournant, ou lien e-mail) : aucune session requise, contrôles serveur stricts. */
export async function publicSignAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const d = publicSignSchema.parse(Object.fromEntries(formData));
    const [period] = await db.select().from(schema.periods).where(eq(schema.periods.publicToken, d.token)).limit(1);
    if (!period) return { error: "Lien d'émargement inconnu ou expiré." };
    const row = await loadPeriod(period.orgId, period.id);
    if (!row) return { error: "Période introuvable." };
    if (row.period.status !== "ouverte") return { error: row.period.status === "cloturee" ? "Cette période est clôturée : la signature n'est plus possible." : "La feuille d'émargement n'est pas ouverte." };
    const rule = canRecordAttendance(timing(row), serverNow());
    if (!rule.ok) return { error: rule.reason };
    const expected = await expectedEnrollments(period.orgId, row.session.id, row.slot.groupId);

    let target: (typeof expected)[number] | undefined;
    let method: "qr" | "email";
    if (d.e && d.k) {
      if (!safeEqual(d.k, signLinkKey(period.id, d.e))) return { error: "Lien de signature invalide." };
      target = expected.find((x) => x.enrollment.id === d.e);
      method = "email";
    } else {
      if (!d.email || !d.code) return { error: "Saisissez votre adresse e-mail et le code affiché en salle." };
      if (!period.signCodeHash || !period.signCodeExpiresAt || period.signCodeExpiresAt.getTime() < Date.now()) return { error: "Le code a expiré : demandez le nouveau code affiché en salle." };
      if (!safeEqual(sha256(`${period.id}:${d.code}`), period.signCodeHash)) return { error: "Code incorrect." };
      target = expected.find((x) => (x.person.email ?? "").toLowerCase() === d.email);
      method = "qr";
    }
    if (!target) return { error: "Aucune inscription attendue à cette période ne correspond." };
    const sig = decodeSignature(formData.get("signature"));
    let key: string | null = null;
    if (sig) {
      key = `${period.orgId}/signatures/${period.id}/${target.enrollment.id}-${randomToken(6)}.png`;
      await putObject(key, sig);
    }
    const current = (await currentAttendances(period.orgId, period.id)).find((a) => a.enrollmentId === target!.enrollment.id);
    if (current && (current.status === "absent" || current.status === "absent_justifie" || current.status === "excuse")) return { error: "Vous êtes enregistré absent : rapprochez-vous du formateur." };
    const status = current && current.status !== "non_saisie" ? current.status : "present";
    const { row: att } = await upsertAttendance({ orgId: period.orgId, userId: null }, row.period, target.enrollment.id, { status, learnerSignedAt: new Date(), signatureKey: key ?? current?.signatureKey ?? null, signatureMethod: method, signatureIp: await requestIp() });
    await audit({ action: "attendance.sign", orgId: period.orgId, entityType: "attendance", entityId: att.id, after: { method, enrollmentId: target.enrollment.id } });
    return { ok: true, message: `Présence signée pour ${target.person.firstName} ${target.person.lastName} (${row.period.startTime}-${row.period.endTime}).` };
  } catch (e) {
    return fail(e, "Signature impossible.");
  }
}

/* ---------- Signature de fin et clôture ---------- */

/** Signature de fin du formateur : refusée avant la fin réelle de la période. */
export async function trainerSignAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.record");
    const periodId = uuid.parse(formData.get("periodId"));
    const row = await loadPeriodInScope(ctx, periodId);
    const rule = canCloseOrSign(timing(row), serverNow());
    if (!rule.ok) return { error: rule.reason };
    if (row.period.status !== "ouverte") return { error: "Ouvrez d'abord la feuille." };
    const sig = decodeSignature(formData.get("signature"));
    let key: string | null = null;
    if (sig) {
      key = `${ctx.org.id}/signatures/${periodId}/formateur-${randomToken(6)}.png`;
      await putObject(key, sig);
    }
    await db.update(schema.periods).set({ trainerSignedAt: new Date(), trainerSignatureKey: key, updatedAt: new Date() }).where(eq(schema.periods.id, periodId));
    await audit({ action: "period.trainer_sign", userId: ctx.user.id, orgId: ctx.org.id, entityType: "period", entityId: periodId, after: { signature: Boolean(key) } });
    revalidatePath(`/app/${ctx.org.id}/emargement/${periodId}`);
    return { ok: true, message: "Signature de fin enregistrée. Vous pouvez clôturer la période." };
  } catch (e) {
    return fail(e, "Signature impossible.");
  }
}

/**
 * Clôture : refusée avant la fin réelle. Marque absents les non saisis, verrouille, génère la feuille PDF
 * (catégorie feuille_emargement, rattachée à la session) et enregistre la preuve qualité IND_11.
 */
export async function closePeriodAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.close");
    const periodId = uuid.parse(formData.get("periodId"));
    const row = await loadPeriodInScope(ctx, periodId);
    const rule = canCloseOrSign(timing(row), serverNow());
    if (!rule.ok) return { error: rule.reason };
    if (row.period.status !== "ouverte") return { error: "Seule une feuille ouverte peut être clôturée." };
    if (!row.period.trainerSignedAt && formData.get("withoutTrainerSignature") !== "1") return { error: "La signature de fin du formateur manque. Signez d'abord, ou cochez « clôturer sans signature de fin » (mention conservée sur la feuille)." };

    const expected = await expectedEnrollments(ctx.org.id, row.session.id, row.slot.groupId);
    const current = await currentAttendances(ctx.org.id, periodId);
    const byEnrollment = new Map(current.map((a) => [a.enrollmentId, a]));
    // Non saisis : absents (le système ne déclare jamais une présence, seulement l'absence constatée).
    for (const e of expected) {
      const a = byEnrollment.get(e.enrollment.id);
      if (!a) {
        const { row: created } = await upsertAttendance({ orgId: ctx.org.id, userId: ctx.user.id }, row.period, e.enrollment.id, { status: "absent" });
        byEnrollment.set(e.enrollment.id, created);
      } else if (a.status === "non_saisie") {
        const { row: upd } = await upsertAttendance({ orgId: ctx.org.id, userId: ctx.user.id }, row.period, e.enrollment.id, { status: "absent" });
        byEnrollment.set(e.enrollment.id, upd);
      }
    }
    const closedAt = new Date();
    await db.update(schema.periods).set({ status: "cloturee", closedAt, closedBy: ctx.user.id, signCodeHash: null, signCodeExpiresAt: null, updatedAt: closedAt }).where(eq(schema.periods.id, periodId));

    const [moduleRow] = row.slot.moduleId ? await db.select({ title: schema.modules.title }).from(schema.modules).where(eq(schema.modules.id, row.slot.moduleId)).limit(1) : [];
    const trainerId = row.period.trainerId ?? row.slot.trainerId;
    const [trainer] = trainerId ? await db.select({ firstName: schema.trainers.firstName, lastName: schema.trainers.lastName }).from(schema.trainers).where(eq(schema.trainers.id, trainerId)).limit(1) : [];
    const roomId = row.period.roomId ?? row.slot.roomId;
    const [room] = roomId ? await db.select({ name: schema.rooms.name }).from(schema.rooms).where(eq(schema.rooms.id, roomId)).limit(1) : [];
    const rows = [];
    for (const e of expected) {
      const a = byEnrollment.get(e.enrollment.id)!;
      let signature: Buffer | null = null;
      if (a.signatureKey) signature = await getObject(a.signatureKey).catch(() => null);
      rows.push({ lastName: e.person.lastName, firstName: e.person.firstName, reference: e.enrollment.reference, status: a.status, statusLabel: statusMeta[a.status]?.label ?? a.status, arrivedAt: a.arrivedAt, leftAt: a.leftAt, minutes: a.minutesCounted, signedAt: a.learnerSignedAt, method: a.signatureMethod, signature });
    }
    const trainerSignature = row.period.trainerSignatureKey ? await getObject(row.period.trainerSignatureKey).catch(() => null) : null;
    const pdf = await renderAttendanceSheetPdf({
      org: ctx.org,
      session: { code: row.session.code, title: row.session.title },
      date: row.slot.date,
      part: row.period.part,
      startTime: row.period.startTime,
      endTime: row.period.endTime,
      moduleTitle: moduleRow?.title ?? null,
      trainerName: trainer ? `${trainer.firstName} ${trainer.lastName}` : null,
      roomName: room?.name ?? null,
      rows,
      trainerSignedAt: row.period.trainerSignedAt,
      trainerSignature,
      closedAt,
      closedByName: `${ctx.user.firstName} ${ctx.user.lastName}`,
    });
    const doc = await createDocument({
      orgId: ctx.org.id,
      sessionId: row.session.id,
      category: "feuille_emargement",
      visibility: "interne",
      status: "genere",
      title: `Feuille d'émargement ${row.session.code} ${row.slot.date} ${row.period.part}`,
      fileName: `emargement-${row.session.code}-${row.slot.date}-${row.period.part}.pdf`,
      mimeType: "application/pdf",
      data: pdf,
      sourceType: "period",
      sourceId: periodId,
      generationData: { periodId, expected: expected.length, present: rows.filter((r) => r.minutes > 0).length },
      uploadedBy: ctx.user.id,
      isDemo: ctx.org.isDemo,
    });
    await recordEvidence({
      orgId: ctx.org.id,
      indicatorCode: "IND_11",
      level: "collectif",
      title: `Émargement clôturé : ${row.session.code} ${fmtDate(row.slot.date)} (${row.period.startTime}-${row.period.endTime})`,
      sourceType: "period",
      sourceId: periodId,
      evidenceDate: row.slot.date,
      sessionId: row.session.id,
      documentId: doc.id,
      createdBy: ctx.user.id,
      note: "Suivi de l'exécution : feuille d'émargement par période, verrouillée.",
    });
    await audit({ action: "period.close", userId: ctx.user.id, orgId: ctx.org.id, entityType: "period", entityId: periodId, before: { status: "ouverte" }, after: { status: "cloturee", documentId: doc.id, attendances: rows.length } });
    revalidatePath(`/app/${ctx.org.id}/emargement/${periodId}`);
    revalidatePath(`/app/${ctx.org.id}/emargement`);
    return { ok: true, message: "Période clôturée et verrouillée. Feuille d'émargement PDF générée et preuve qualité enregistrée." };
  } catch (e) {
    return fail(e, "Clôture impossible.");
  }
}

/* ---------- Corrections exceptionnelles (période clôturée) ---------- */

const correctionSchema = z.object({
  periodId: uuid,
  enrollmentId: uuid,
  status: attendanceStatus,
  arrivedAt: optTime,
  leftAt: optTime,
  justificationNote: z.string().trim().max(500).optional(),
  reason: z.string().trim().min(5, "Motif de la correction requis (5 caractères minimum).").max(1000),
});

/** Demande de correction d'une présence sur une période clôturée (formateur ou administratif), avec motif. */
export async function requestCorrectionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.record");
    const d = correctionSchema.parse(Object.fromEntries(formData));
    const row = await loadPeriodInScope(ctx, d.periodId);
    if (row.period.status !== "cloturee") return { error: "La période n'est pas clôturée : modifiez directement la présence." };
    const current = (await currentAttendances(ctx.org.id, d.periodId)).find((a) => a.enrollmentId === d.enrollmentId);
    if (!current) return { error: "Aucune présence courante pour cette inscription sur cette période." };
    const [c] = await db
      .insert(schema.attendanceCorrections)
      .values({ orgId: ctx.org.id, periodId: d.periodId, attendanceId: current.id, enrollmentId: d.enrollmentId, reason: d.reason, requested: { status: d.status, arrivedAt: d.arrivedAt ?? null, leftAt: d.leftAt ?? null, justificationNote: d.justificationNote ?? null }, before: { status: current.status, arrivedAt: current.arrivedAt, leftAt: current.leftAt, minutesCounted: current.minutesCounted }, requestedBy: ctx.user.id })
      .returning({ id: schema.attendanceCorrections.id });
    await audit({ action: "attendance.correction.request", userId: ctx.user.id, orgId: ctx.org.id, entityType: "attendance_correction", entityId: c.id, after: { periodId: d.periodId, enrollmentId: d.enrollmentId, reason: d.reason } });
    revalidatePath(`/app/${ctx.org.id}/emargement/${d.periodId}`);
    return { ok: true, message: "Demande de correction enregistrée : elle attend une décision (habilitation « corriger »)." };
  } catch (e) {
    return fail(e, "Demande impossible.");
  }
}

/** Décision (approbation / refus) puis application : nouvelle ligne courante, l'originale conservée (`isCurrent=false`, `supersededById`). */
export async function decideCorrectionAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.correct");
    const correctionId = uuid.parse(formData.get("correctionId"));
    const decision = z.enum(["approuvee", "refusee"]).parse(formData.get("decision"));
    const note = z.string().trim().max(1000).optional().parse(formData.get("decisionNote") ?? undefined);
    const [c] = await db.select().from(schema.attendanceCorrections).where(and(eq(schema.attendanceCorrections.id, correctionId), eq(schema.attendanceCorrections.orgId, ctx.org.id))).limit(1);
    if (!c) return { error: "Demande introuvable." };
    const row = await loadPeriodInScope(ctx, c.periodId);
    if (c.status !== "demandee") return { error: "Cette demande a déjà été traitée." };
    const now = new Date();
    if (decision === "refusee") {
      await db.update(schema.attendanceCorrections).set({ status: "refusee", decidedBy: ctx.user.id, decidedAt: now, decisionNote: note ?? null, updatedAt: now }).where(eq(schema.attendanceCorrections.id, c.id));
      await audit({ action: "attendance.correct", userId: ctx.user.id, orgId: ctx.org.id, entityType: "attendance_correction", entityId: c.id, after: { decision: "refusee", note } });
      revalidatePath(`/app/${ctx.org.id}/emargement/${c.periodId}`);
      return { ok: true, message: "Demande refusée (conservée dans l'historique)." };
    }
    const requested = c.requested as { status: (typeof schema.attendanceStatusEnum.enumValues)[number]; arrivedAt?: string | null; leftAt?: string | null; justificationNote?: string | null };
    const [original] = c.attendanceId ? await db.select().from(schema.attendances).where(and(eq(schema.attendances.id, c.attendanceId), eq(schema.attendances.orgId, ctx.org.id))).limit(1) : [];
    if (!original || !original.isCurrent) return { error: "La présence d'origine n'est plus la ligne courante : nouvelle demande nécessaire." };
    const minutesCounted = minutesFor(row.period, { status: requested.status, arrivedAt: requested.arrivedAt, leftAt: requested.leftAt });
    await db.transaction(async (tx) => {
      await tx.update(schema.attendances).set({ isCurrent: false, updatedAt: now }).where(eq(schema.attendances.id, original.id));
      const [fresh] = await tx
        .insert(schema.attendances)
        .values({
          orgId: ctx.org.id,
          periodId: c.periodId,
          enrollmentId: original.enrollmentId,
          status: requested.status,
          arrivedAt: requested.arrivedAt ?? null,
          leftAt: requested.leftAt ?? null,
          minutesCounted,
          justificationNote: requested.justificationNote ?? original.justificationNote,
          justificationDocumentId: original.justificationDocumentId,
          learnerSignedAt: original.learnerSignedAt,
          signatureKey: original.signatureKey,
          signatureMethod: original.signatureMethod,
          signatureIp: original.signatureIp,
          recordedBy: ctx.user.id,
          recordedAt: now,
          isCurrent: true,
          correctionId: c.id,
        })
        .returning({ id: schema.attendances.id });
      await tx.update(schema.attendances).set({ supersededById: fresh.id }).where(eq(schema.attendances.id, original.id));
      await tx.update(schema.attendanceCorrections).set({ status: "appliquee", decidedBy: ctx.user.id, decidedAt: now, decisionNote: note ?? null, appliedAt: now, updatedAt: now }).where(eq(schema.attendanceCorrections.id, c.id));
    });
    await audit({ action: "attendance.correct", userId: ctx.user.id, orgId: ctx.org.id, entityType: "attendance", entityId: original.id, before: { status: original.status, minutesCounted: original.minutesCounted }, after: { status: requested.status, minutesCounted, correctionId: c.id, note } });
    revalidatePath(`/app/${ctx.org.id}/emargement/${c.periodId}`);
    return { ok: true, message: `Correction approuvée et appliquée : ${statusMeta[requested.status]?.label ?? requested.status}, ${minutesCounted} min. L'original est conservé.` };
  } catch (e) {
    return fail(e, "Décision impossible.");
  }
}

/** Suppression directe d'une présence : seulement sur période non clôturée (remise à « non saisie »). */
export async function clearAttendanceAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const ctx = await requireOrg(await orgIdOf(formData), "attendance.record");
    const periodId = uuid.parse(formData.get("periodId"));
    const enrollmentId = uuid.parse(formData.get("enrollmentId"));
    const row = await loadPeriodInScope(ctx, periodId);
    const rule = canEditDirectly(row.period);
    if (!rule.ok) return { error: rule.reason };
    const current = (await currentAttendances(ctx.org.id, periodId)).find((a) => a.enrollmentId === enrollmentId);
    if (!current) return { error: "Aucune présence à effacer." };
    await db.update(schema.attendances).set({ status: "non_saisie", arrivedAt: null, leftAt: null, minutesCounted: 0, learnerSignedAt: null, signatureKey: null, signatureMethod: null, updatedAt: new Date() }).where(eq(schema.attendances.id, current.id));
    await audit({ action: "attendance.clear", userId: ctx.user.id, orgId: ctx.org.id, entityType: "attendance", entityId: current.id, before: { status: current.status } });
    revalidatePath(`/app/${ctx.org.id}/emargement/${periodId}`);
    return { ok: true, message: "Présence remise à « non saisie »." };
  } catch (e) {
    return fail(e, "Effacement impossible.");
  }
}
